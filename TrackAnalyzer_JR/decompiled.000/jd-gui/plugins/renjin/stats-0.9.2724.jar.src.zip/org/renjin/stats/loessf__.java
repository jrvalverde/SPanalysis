package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.BooleanPtr;
import org.renjin.gcc.runtime.Builtins;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.math.Blas;
import org.renjin.nmath.d1mach;

public class loessf__ {
  public static double machep$2928;
  
  public static int execnt$2909;
  
  public static double[] c$3541 = new double[48];
  
  public static double[] vval$3688 = new double[20];
  
  public static int nv$3683;
  
  public static double[] v$3685 = new double[10];
  
  public static int[] c$3676 = new int[34];
  
  public static int[] hi$3679 = new int[17];
  
  public static int[] lo$3681 = new int[17];
  
  public static double[] xi$3690 = new double[17];
  
  public static int[] a$3674 = new int[17];
  
  public static int vc$3686;
  
  public static int nc$3682;
  
  public static int d$3677;
  
  public static double machin$4254;
  
  public static int execnt$4251;
  
  public static double machin$4300;
  
  public static int execnt$4296;
  
  public static double $ehg126_$machin;
  
  public static int $ehg126_$execnt;
  
  public static double $ehg129_$machin;
  
  public static int $ehg129_$execnt;
  
  public static double[] $ehg176_$xi = new double[17];
  
  public static double[] $ehg176_$vval = new double[20];
  
  public static int[] $ehg176_$vc = new int[1];
  
  public static double[] $ehg176_$v = new double[10];
  
  public static int[] $ehg176_$nv = new int[1];
  
  public static int[] $ehg176_$nc = new int[1];
  
  public static int[] $ehg176_$lo = new int[17];
  
  public static int[] $ehg176_$hi = new int[17];
  
  public static int[] $ehg176_$d = new int[1];
  
  public static int[] $ehg176_$c = new int[34];
  
  public static int[] $ehg176_$a = new int[17];
  
  public static double[] $ehg141_$c = new double[48];
  
  public static double $ehg127_$machep;
  
  public static int $ehg127_$execnt;
  
  static {
    machep$2928 = 0.0D;
    execnt$2909 = 0;
    c$3541$$clinit();
    vval$3688$$clinit();
    nv$3683 = 10;
    v$3685$$clinit();
    c$3676$$clinit();
    hi$3679$$clinit();
    lo$3681$$clinit();
    xi$3690$$clinit();
    a$3674$$clinit();
    vc$3686 = 2;
    nc$3682 = 17;
    d$3677 = 1;
    machin$4254 = 0.0D;
    execnt$4251 = 0;
    machin$4300 = 0.0D;
    execnt$4296 = 0;
    $ehg126_$machin = 0.0D;
    $ehg126_$execnt = 0;
    $ehg129_$machin = 0.0D;
    $ehg129_$execnt = 0;
    double[] arrayOfDouble2 = new double[17];
    arrayOfDouble2[0] = 0.3705D;
    arrayOfDouble2[1] = 0.2017D;
    arrayOfDouble2[2] = 0.5591D;
    arrayOfDouble2[3] = 0.1204D;
    arrayOfDouble2[4] = 0.2815D;
    arrayOfDouble2[5] = 0.4536D;
    arrayOfDouble2[6] = 0.7132D;
    arrayOfDouble2[7] = 0.8751D;
    System.arraycopy(arrayOfDouble2, 0, $ehg176_$xi, 0, 17);
    arrayOfDouble2 = new double[20];
    arrayOfDouble2[0] = -0.090572D;
    arrayOfDouble2[1] = 4.4844D;
    arrayOfDouble2[2] = -0.010856D;
    arrayOfDouble2[3] = -0.7736D;
    arrayOfDouble2[4] = -0.053718D;
    arrayOfDouble2[5] = -0.3495D;
    arrayOfDouble2[6] = 0.026152D;
    arrayOfDouble2[7] = -0.7286D;
    arrayOfDouble2[8] = -0.058387D;
    arrayOfDouble2[9] = 0.1611D;
    arrayOfDouble2[10] = 0.095807D;
    arrayOfDouble2[11] = -0.7978D;
    arrayOfDouble2[12] = -0.031926D;
    arrayOfDouble2[13] = -0.4457D;
    arrayOfDouble2[14] = -0.06417D;
    arrayOfDouble2[15] = 0.032813D;
    arrayOfDouble2[16] = -0.020636D;
    arrayOfDouble2[17] = 0.335D;
    arrayOfDouble2[18] = 0.040172D;
    arrayOfDouble2[19] = -0.041032D;
    System.arraycopy(arrayOfDouble2, 0, $ehg176_$vval, 0, 20);
    $ehg176_$vc[0] = 2;
    arrayOfDouble2 = new double[10];
    arrayOfDouble2[0] = -0.005D;
    arrayOfDouble2[1] = 1.005D;
    arrayOfDouble2[2] = 0.3705D;
    arrayOfDouble2[3] = 0.2017D;
    arrayOfDouble2[4] = 0.5591D;
    arrayOfDouble2[5] = 0.1204D;
    arrayOfDouble2[6] = 0.2815D;
    arrayOfDouble2[7] = 0.4536D;
    arrayOfDouble2[8] = 0.7132D;
    arrayOfDouble2[9] = 0.8751D;
    System.arraycopy(arrayOfDouble2, 0, $ehg176_$v, 0, 10);
    $ehg176_$nv[0] = 10;
    $ehg176_$nc[0] = 17;
    int[] arrayOfInt = new int[17];
    arrayOfInt[0] = 2;
    arrayOfInt[1] = 4;
    arrayOfInt[2] = 6;
    arrayOfInt[3] = 8;
    arrayOfInt[4] = 10;
    arrayOfInt[5] = 12;
    arrayOfInt[6] = 14;
    arrayOfInt[7] = 16;
    System.arraycopy(arrayOfInt, 0, $ehg176_$lo, 0, 17);
    arrayOfInt = new int[17];
    arrayOfInt[0] = 3;
    arrayOfInt[1] = 5;
    arrayOfInt[2] = 7;
    arrayOfInt[3] = 9;
    arrayOfInt[4] = 11;
    arrayOfInt[5] = 13;
    arrayOfInt[6] = 15;
    arrayOfInt[7] = 17;
    System.arraycopy(arrayOfInt, 0, $ehg176_$hi, 0, 17);
    $ehg176_$d[0] = 1;
    arrayOfInt = new int[34];
    arrayOfInt[0] = 1;
    arrayOfInt[1] = 2;
    arrayOfInt[2] = 1;
    arrayOfInt[3] = 3;
    arrayOfInt[4] = 3;
    arrayOfInt[5] = 2;
    arrayOfInt[6] = 1;
    arrayOfInt[7] = 4;
    arrayOfInt[8] = 4;
    arrayOfInt[9] = 3;
    arrayOfInt[10] = 3;
    arrayOfInt[11] = 5;
    arrayOfInt[12] = 5;
    arrayOfInt[13] = 2;
    arrayOfInt[14] = 1;
    arrayOfInt[15] = 6;
    arrayOfInt[16] = 6;
    arrayOfInt[17] = 4;
    arrayOfInt[18] = 4;
    arrayOfInt[19] = 7;
    arrayOfInt[20] = 7;
    arrayOfInt[21] = 3;
    arrayOfInt[22] = 3;
    arrayOfInt[23] = 8;
    arrayOfInt[24] = 8;
    arrayOfInt[25] = 5;
    arrayOfInt[26] = 5;
    arrayOfInt[27] = 9;
    arrayOfInt[28] = 9;
    arrayOfInt[29] = 2;
    arrayOfInt[30] = 9;
    arrayOfInt[31] = 10;
    arrayOfInt[32] = 10;
    arrayOfInt[33] = 2;
    System.arraycopy(arrayOfInt, 0, $ehg176_$c, 0, 34);
    arrayOfInt = new int[17];
    arrayOfInt[0] = 1;
    arrayOfInt[1] = 1;
    arrayOfInt[2] = 1;
    arrayOfInt[3] = 1;
    arrayOfInt[4] = 1;
    arrayOfInt[5] = 1;
    arrayOfInt[6] = 1;
    arrayOfInt[7] = 0;
    arrayOfInt[8] = 0;
    arrayOfInt[9] = 0;
    arrayOfInt[10] = 0;
    arrayOfInt[11] = 0;
    arrayOfInt[12] = 0;
    arrayOfInt[13] = 0;
    arrayOfInt[14] = 1;
    arrayOfInt[15] = 0;
    arrayOfInt[16] = 0;
    System.arraycopy(arrayOfInt, 0, $ehg176_$a, 0, 17);
    double[] arrayOfDouble1 = new double[48];
    arrayOfDouble1[0] = 0.297162D;
    arrayOfDouble1[1] = 0.380266D;
    arrayOfDouble1[2] = 0.5886043D;
    arrayOfDouble1[3] = 0.4263766D;
    arrayOfDouble1[4] = 0.3346498D;
    arrayOfDouble1[5] = 0.6271053D;
    arrayOfDouble1[6] = 0.5241198D;
    arrayOfDouble1[7] = 0.3484836D;
    arrayOfDouble1[8] = 0.6687687D;
    arrayOfDouble1[9] = 0.6338795D;
    arrayOfDouble1[10] = 0.4076457D;
    arrayOfDouble1[11] = 0.7207693D;
    arrayOfDouble1[12] = 0.1611761D;
    arrayOfDouble1[13] = 0.3091323D;
    arrayOfDouble1[14] = 0.4401023D;
    arrayOfDouble1[15] = 0.2939609D;
    arrayOfDouble1[16] = 0.3580278D;
    arrayOfDouble1[17] = 0.5555741D;
    arrayOfDouble1[18] = 0.397239D;
    arrayOfDouble1[19] = 0.4171278D;
    arrayOfDouble1[20] = 0.6293196D;
    arrayOfDouble1[21] = 0.4675173D;
    arrayOfDouble1[22] = 0.469907D;
    arrayOfDouble1[23] = 0.6674802D;
    arrayOfDouble1[24] = 0.2848308D;
    arrayOfDouble1[25] = 0.2254512D;
    arrayOfDouble1[26] = 0.2914126D;
    arrayOfDouble1[27] = 0.5393624D;
    arrayOfDouble1[28] = 0.251723D;
    arrayOfDouble1[29] = 0.389897D;
    arrayOfDouble1[30] = 0.7603231D;
    arrayOfDouble1[31] = 0.2969113D;
    arrayOfDouble1[32] = 0.474013D;
    arrayOfDouble1[33] = 0.9664956D;
    arrayOfDouble1[34] = 0.3629838D;
    arrayOfDouble1[35] = 0.5348889D;
    arrayOfDouble1[36] = 0.207567D;
    arrayOfDouble1[37] = 0.2822574D;
    arrayOfDouble1[38] = 0.2369957D;
    arrayOfDouble1[39] = 0.3911566D;
    arrayOfDouble1[40] = 0.2981154D;
    arrayOfDouble1[41] = 0.3623232D;
    arrayOfDouble1[42] = 0.5508869D;
    arrayOfDouble1[43] = 0.3501989D;
    arrayOfDouble1[44] = 0.4371032D;
    arrayOfDouble1[45] = 0.7002667D;
    arrayOfDouble1[46] = 0.4291632D;
    arrayOfDouble1[47] = 0.493037D;
    System.arraycopy(arrayOfDouble1, 0, $ehg141_$c, 0, 48);
    $ehg127_$machep = 0.0D;
    $ehg127_$execnt = 0;
  }
  
  static void a$3674$$clinit() {
    int[] arrayOfInt = new int[17];
    arrayOfInt[0] = 1;
    arrayOfInt[1] = 1;
    arrayOfInt[2] = 1;
    arrayOfInt[3] = 1;
    arrayOfInt[4] = 1;
    arrayOfInt[5] = 1;
    arrayOfInt[6] = 1;
    arrayOfInt[7] = 0;
    arrayOfInt[8] = 0;
    arrayOfInt[9] = 0;
    arrayOfInt[10] = 0;
    arrayOfInt[11] = 0;
    arrayOfInt[12] = 0;
    arrayOfInt[13] = 0;
    arrayOfInt[14] = 1;
    arrayOfInt[15] = 0;
    arrayOfInt[16] = 0;
    System.arraycopy(arrayOfInt, 0, a$3674, 0, 17);
  }
  
  static void c$3541$$clinit() {
    double[] arrayOfDouble = new double[48];
    arrayOfDouble[0] = 0.297162D;
    arrayOfDouble[1] = 0.380266D;
    arrayOfDouble[2] = 0.5886043D;
    arrayOfDouble[3] = 0.4263766D;
    arrayOfDouble[4] = 0.3346498D;
    arrayOfDouble[5] = 0.6271053D;
    arrayOfDouble[6] = 0.5241198D;
    arrayOfDouble[7] = 0.3484836D;
    arrayOfDouble[8] = 0.6687687D;
    arrayOfDouble[9] = 0.6338795D;
    arrayOfDouble[10] = 0.4076457D;
    arrayOfDouble[11] = 0.7207693D;
    arrayOfDouble[12] = 0.1611761D;
    arrayOfDouble[13] = 0.3091323D;
    arrayOfDouble[14] = 0.4401023D;
    arrayOfDouble[15] = 0.2939609D;
    arrayOfDouble[16] = 0.3580278D;
    arrayOfDouble[17] = 0.5555741D;
    arrayOfDouble[18] = 0.397239D;
    arrayOfDouble[19] = 0.4171278D;
    arrayOfDouble[20] = 0.6293196D;
    arrayOfDouble[21] = 0.4675173D;
    arrayOfDouble[22] = 0.469907D;
    arrayOfDouble[23] = 0.6674802D;
    arrayOfDouble[24] = 0.2848308D;
    arrayOfDouble[25] = 0.2254512D;
    arrayOfDouble[26] = 0.2914126D;
    arrayOfDouble[27] = 0.5393624D;
    arrayOfDouble[28] = 0.251723D;
    arrayOfDouble[29] = 0.389897D;
    arrayOfDouble[30] = 0.7603231D;
    arrayOfDouble[31] = 0.2969113D;
    arrayOfDouble[32] = 0.474013D;
    arrayOfDouble[33] = 0.9664956D;
    arrayOfDouble[34] = 0.3629838D;
    arrayOfDouble[35] = 0.5348889D;
    arrayOfDouble[36] = 0.207567D;
    arrayOfDouble[37] = 0.2822574D;
    arrayOfDouble[38] = 0.2369957D;
    arrayOfDouble[39] = 0.3911566D;
    arrayOfDouble[40] = 0.2981154D;
    arrayOfDouble[41] = 0.3623232D;
    arrayOfDouble[42] = 0.5508869D;
    arrayOfDouble[43] = 0.3501989D;
    arrayOfDouble[44] = 0.4371032D;
    arrayOfDouble[45] = 0.7002667D;
    arrayOfDouble[46] = 0.4291632D;
    arrayOfDouble[47] = 0.493037D;
    System.arraycopy(arrayOfDouble, 0, c$3541, 0, 48);
  }
  
  static void c$3676$$clinit() {
    int[] arrayOfInt = new int[34];
    arrayOfInt[0] = 1;
    arrayOfInt[1] = 2;
    arrayOfInt[2] = 1;
    arrayOfInt[3] = 3;
    arrayOfInt[4] = 3;
    arrayOfInt[5] = 2;
    arrayOfInt[6] = 1;
    arrayOfInt[7] = 4;
    arrayOfInt[8] = 4;
    arrayOfInt[9] = 3;
    arrayOfInt[10] = 3;
    arrayOfInt[11] = 5;
    arrayOfInt[12] = 5;
    arrayOfInt[13] = 2;
    arrayOfInt[14] = 1;
    arrayOfInt[15] = 6;
    arrayOfInt[16] = 6;
    arrayOfInt[17] = 4;
    arrayOfInt[18] = 4;
    arrayOfInt[19] = 7;
    arrayOfInt[20] = 7;
    arrayOfInt[21] = 3;
    arrayOfInt[22] = 3;
    arrayOfInt[23] = 8;
    arrayOfInt[24] = 8;
    arrayOfInt[25] = 5;
    arrayOfInt[26] = 5;
    arrayOfInt[27] = 9;
    arrayOfInt[28] = 9;
    arrayOfInt[29] = 2;
    arrayOfInt[30] = 9;
    arrayOfInt[31] = 10;
    arrayOfInt[32] = 10;
    arrayOfInt[33] = 2;
    System.arraycopy(arrayOfInt, 0, c$3676, 0, 34);
  }
  
  public static void ehg106_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int k = Math.max(paramPtr4.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr7.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    int i = paramPtr1.getInt();
    for (int j = paramPtr2.getInt(); i < j; j = n + -1) {
      double d = paramPtr5.getAlignedDouble(paramPtr6.getAlignedInt(paramPtr3.getInt() + -1) * k + m + 1);
      int i1 = i;
      int n = j;
      int i2 = paramPtr6.getAlignedInt(i + -1);
      paramPtr6.setAlignedInt(i + -1, paramPtr6.getAlignedInt(paramPtr3.getInt() + -1));
      paramPtr6.setAlignedInt(paramPtr3.getInt() + -1, i2);
      if (paramPtr5.getAlignedDouble(paramPtr6.getAlignedInt(j + -1) * k + m + 1) > d) {
        i2 = paramPtr6.getAlignedInt(i + -1);
        paramPtr6.setAlignedInt(i + -1, paramPtr6.getAlignedInt(j + -1));
        paramPtr6.setAlignedInt(j + -1, i2);
      } 
      label39: while (i1 < n) {
        i2 = paramPtr6.getAlignedInt(i1 + -1);
        paramPtr6.setAlignedInt(i1 + -1, paramPtr6.getAlignedInt(n + -1));
        paramPtr6.setAlignedInt(n + -1, i2);
        i1++;
        n--;
        while (true) {
          if (paramPtr5.getAlignedDouble(paramPtr6.getAlignedInt(i1 + -1) * k + m + 1) >= d) {
            i2 = 0;
          } else {
            i2 = 1;
          } 
          if ((i2 ^ 0x1) == 0) {
            i1++;
            continue;
          } 
          break;
        } 
        while (true) {
          if (paramPtr5.getAlignedDouble(paramPtr6.getAlignedInt(n + -1) * k + m + 1) <= d) {
            i2 = 0;
          } else {
            i2 = 1;
          } 
          if ((i2 ^ 0x1) == 0) {
            n--;
            continue;
          } 
          continue label39;
        } 
      } 
      if (paramPtr5.getAlignedDouble(paramPtr6.getAlignedInt(i + -1) * k + m + 1) != d) {
        n++;
        i1 = paramPtr6.getAlignedInt(j + -1);
        paramPtr6.setAlignedInt(j + -1, paramPtr6.getAlignedInt(n + -1));
        paramPtr6.setAlignedInt(n + -1, i1);
      } else {
        i1 = paramPtr6.getAlignedInt(i + -1);
        paramPtr6.setAlignedInt(i + -1, paramPtr6.getAlignedInt(n + -1));
        paramPtr6.setAlignedInt(n + -1, i1);
      } 
      if (paramPtr3.getInt() >= n)
        i = n + 1; 
      if (paramPtr3.getInt() > n)
        continue; 
    } 
  }
  
  public static void ehg124_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    double[] arrayOfDouble1 = new double[8];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int[] arrayOfInt7 = new int[1];
    int[] arrayOfInt8 = new int[1];
    int[] arrayOfInt9 = new int[1];
    double[] arrayOfDouble2 = new double[8];
    int[] arrayOfInt10 = new int[1];
    arrayOfInt4[0] = 0;
    arrayOfInt5[0] = 0;
    arrayOfInt6[0] = 0;
    arrayOfInt8[0] = 0;
    arrayOfInt9[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    int i = Math.max(paramPtr18.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr3.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    int k = Math.max(paramPtr8.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr7.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int n = Math.max(paramPtr4.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr3.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr18.getInt(), 0));
    arrayOfInt5[0] = 1;
    arrayOfInt8[0] = paramPtr1.getInt();
    arrayOfInt4[0] = paramPtr2.getInt();
    paramPtr13.setAlignedInt(arrayOfInt5[0] + -1, arrayOfInt8[0]);
    paramPtr14.setAlignedInt(arrayOfInt5[0] + -1, arrayOfInt4[0]);
    while (paramPtr6.getInt() >= arrayOfInt5[0]) {
      boolean bool = paramPtr21.getInt();
      byte b = 1;
      if (true <= bool)
        while (true) {
          boolean bool1;
          arrayOfDouble2[b + -1] = paramPtr16.getAlignedDouble(b * i + j + paramPtr15.getAlignedInt(arrayOfInt5[0] * k + m + paramPtr8.getInt())) - paramPtr16.getAlignedDouble(b * i + j + paramPtr15.getAlignedInt(arrayOfInt5[0] * k + m + 1));
          if (b != bool) {
            bool1 = false;
          } else {
            bool1 = true;
          } 
          b++;
          if (!bool1)
            continue; 
          break;
        }  
      double d = 0.0D;
      bool = paramPtr21.getInt();
      b = 1;
      if (true <= bool)
        while (true) {
          boolean bool1;
          d += arrayOfDouble2[b + -1] * arrayOfDouble2[b + -1];
          if (b != bool) {
            bool1 = false;
          } else {
            bool1 = true;
          } 
          b++;
          if (!bool1)
            continue; 
          break;
        }  
      d = Mathlib.sqrt(d);
      if (arrayOfInt4[0] - arrayOfInt8[0] + 1 > paramPtr19.getInt()) {
        if (paramPtr20.getDouble() < d) {
          bool = false;
        } else {
          bool = true;
        } 
        bool = bool;
      } else {
        bool = true;
      } 
      if (bool == 0) {
        if (paramPtr7.getInt() >= paramPtr6.getInt() + 2) {
          if (paramPtr18.getInt() >= paramPtr5.getInt() + paramPtr8.getInt() / 2.0D) {
            bool = false;
          } else {
            bool = true;
          } 
          bool = bool;
        } else {
          bool = true;
        } 
        bool = bool;
      } else {
        bool = true;
      } 
      if ((bool ^ true) != 0) {
        ehg129_((Ptr)new IntPtr(arrayOfInt8, 0), (Ptr)new IntPtr(arrayOfInt4, 0), paramPtr21, paramPtr9, paramPtr10, paramPtr4, (Ptr)new DoublePtr(arrayOfDouble1, 0));
        arrayOfInt9[0] = Blas.idamax_(paramPtr21, (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(new int[] { 1 }, 0));
        arrayOfInt6[0] = (int)((arrayOfInt8[0] + arrayOfInt4[0]) / 2.0D);
        Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt8, 0);
        Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt4, 0);
        Ptr ptr3 = (Ptr)new IntPtr(arrayOfInt6, 0);
        Ptr ptr4 = (Ptr)new IntPtr(new int[] { 1 }, 0);
        Ptr ptr5 = paramPtr9.pointerPlus((arrayOfInt9[0] * n + i1 + 1) * 8);
        ehg106_(ptr1, ptr2, ptr3, ptr4, ptr5, paramPtr10, paramPtr4);
        for (byte b1 = 0; arrayOfInt6[0] + b1 < arrayOfInt4[0] && arrayOfInt6[0] + b1 >= arrayOfInt8[0]; b1++) {
          if (b1 >= 0) {
            arrayOfInt7[0] = arrayOfInt6[0] + b1 + 1;
            arrayOfInt10[0] = arrayOfInt7[0];
            arrayOfInt3[0] = arrayOfInt4[0];
          } else {
            arrayOfInt7[0] = arrayOfInt8[0];
            arrayOfInt10[0] = arrayOfInt6[0] + b1;
            arrayOfInt3[0] = arrayOfInt10[0];
          } 
          ptr1 = (Ptr)new IntPtr(arrayOfInt7, 0);
          ptr2 = (Ptr)new IntPtr(arrayOfInt3, 0);
          ptr3 = (Ptr)new IntPtr(arrayOfInt10, 0);
          ptr4 = (Ptr)new IntPtr(new int[] { 1 }, 0);
          ptr5 = paramPtr9.pointerPlus((arrayOfInt9[0] * n + i1 + 1) * 8);
          ehg106_(ptr1, ptr2, ptr3, ptr4, ptr5, paramPtr10, paramPtr4);
          if (paramPtr9.getAlignedDouble(arrayOfInt9[0] * n + i1 + paramPtr10.getAlignedInt(arrayOfInt6[0] + b1 + -1)) != paramPtr9.getAlignedDouble(arrayOfInt9[0] * n + i1 + paramPtr10.getAlignedInt(arrayOfInt6[0] + b1))) {
            arrayOfInt6[0] = arrayOfInt6[0] + b1;
            break;
          } 
          b1 = -b1;
          if (b1 < 0)
            continue; 
        } 
        if (paramPtr16.getAlignedDouble(arrayOfInt9[0] * i + j + paramPtr15.getAlignedInt(arrayOfInt5[0] * k + m + 1)) != paramPtr9.getAlignedDouble(arrayOfInt9[0] * n + i1 + paramPtr10.getAlignedInt(arrayOfInt6[0] + -1))) {
          if (paramPtr16.getAlignedDouble(arrayOfInt9[0] * i + j + paramPtr15.getAlignedInt(arrayOfInt5[0] * k + m + paramPtr8.getInt())) != paramPtr9.getAlignedDouble(arrayOfInt9[0] * n + i1 + paramPtr10.getAlignedInt(arrayOfInt6[0] + -1))) {
            bool1 = false;
          } else {
            bool1 = true;
          } 
          boolean bool1 = bool1;
        } else {
          bool = true;
        } 
      } 
      if (!bool) {
        paramPtr11.setAlignedInt(arrayOfInt5[0] + -1, arrayOfInt9[0]);
        paramPtr12.setAlignedDouble(arrayOfInt5[0] + -1, paramPtr9.getAlignedDouble(arrayOfInt9[0] * n + i1 + paramPtr10.getAlignedInt(arrayOfInt6[0] + -1)));
        paramPtr6.setInt(paramPtr6.getInt() + 1);
        paramPtr13.setAlignedInt(arrayOfInt5[0] + -1, paramPtr6.getInt());
        paramPtr13.setAlignedInt(paramPtr6.getInt() + -1, arrayOfInt8[0]);
        paramPtr14.setAlignedInt(paramPtr6.getInt() + -1, arrayOfInt6[0]);
        paramPtr6.setInt(paramPtr6.getInt() + 1);
        paramPtr14.setAlignedInt(arrayOfInt5[0] + -1, paramPtr6.getInt());
        paramPtr13.setAlignedInt(paramPtr6.getInt() + -1, arrayOfInt6[0] + 1);
        paramPtr14.setAlignedInt(paramPtr6.getInt() + -1, arrayOfInt4[0]);
        arrayOfInt1[0] = Builtins._gfortran_pow_i4_i4(2, arrayOfInt9[0] + -1);
        arrayOfInt2[0] = Builtins._gfortran_pow_i4_i4(2, paramPtr3.getInt() - arrayOfInt9[0]);
        Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt5, 0);
        Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt9, 0);
        Ptr ptr3 = paramPtr12.pointerPlus((arrayOfInt5[0] + -1) * 8);
        Ptr ptr4 = (Ptr)new IntPtr(arrayOfInt1, 0);
        Ptr ptr5 = (Ptr)new IntPtr(arrayOfInt2, 0);
        Ptr ptr6 = paramPtr15.pointerPlus((arrayOfInt5[0] * k + m + 1) * 4);
        Ptr ptr7 = paramPtr15.pointerPlus((paramPtr13.getAlignedInt(arrayOfInt5[0] + -1) * k + m + 1) * 4);
        Ptr ptr8 = paramPtr15.pointerPlus((paramPtr14.getAlignedInt(arrayOfInt5[0] + -1) * k + m + 1) * 4);
        ehg125_(ptr1, paramPtr5, paramPtr16, paramPtr17, paramPtr18, paramPtr3, ptr2, ptr3, ptr4, ptr5, ptr6, ptr7, ptr8);
      } else {
        paramPtr11.setAlignedInt(arrayOfInt5[0] + -1, 0);
      } 
      arrayOfInt5[0] = arrayOfInt5[0] + 1;
      arrayOfInt8[0] = paramPtr13.getAlignedInt(arrayOfInt5[0] + -1);
      arrayOfInt4[0] = paramPtr14.getAlignedInt(arrayOfInt5[0] + -1);
    } 
  }
  
  public static void ehg125_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13) {
    int j = Math.max(paramPtr5.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr6.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    int m = Math.max(paramPtr9.getInt(), 0);
    int n = Math.max(m * 2, 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr10.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    int i2 = Math.max(paramPtr9.getInt(), 0);
    int i3 = Math.max(i2 * 2, 0);
    Integer.toUnsignedLong(Math.max(i3 * paramPtr10.getInt(), 0));
    int i4 = i3 ^ 0xFFFFFFFF;
    int i5 = Math.max(paramPtr9.getInt(), 0);
    int i6 = Math.max(i5 * 2, 0);
    Integer.toUnsignedLong(Math.max(i6 * paramPtr10.getInt(), 0));
    int i7 = i6 ^ 0xFFFFFFFF;
    int i8 = paramPtr2.getInt();
    int i = paramPtr9.getInt();
    byte b = 1;
    if (1 <= i)
      while (true) {
        int i9 = paramPtr10.getInt();
        byte b1 = 1;
        if (1 <= i9)
          while (true) {
            i8++;
            int i10 = paramPtr6.getInt();
            byte b2 = 1;
            if (1 <= i10)
              while (true) {
                boolean bool;
                paramPtr3.setAlignedDouble(b2 * j + k + i8, paramPtr3.getAlignedDouble(b2 * j + k + paramPtr11.getAlignedInt(b1 * n + i1 + b)));
                if (b2 != i10) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b2++;
                if (!bool)
                  continue; 
                break;
              }  
            paramPtr3.setAlignedDouble(paramPtr7.getInt() * j + k + i8, paramPtr8.getDouble());
            b2 = 0;
            i10 = 1;
            while (true) {
              byte b3;
              if ((b2 ^ 0x1) == 0) {
                b3 = 0;
              } else {
                if (paramPtr2.getInt() < i10) {
                  b3 = 0;
                } else {
                  b3 = 1;
                } 
                b3 = b3;
              } 
              if ((b3 ^ 0x1) == 0) {
                if (paramPtr3.getAlignedDouble(k + j + i10) != paramPtr3.getAlignedDouble(k + j + i8)) {
                  b2 = 0;
                } else {
                  b2 = 1;
                } 
                b2 = b2;
                b3 = 2;
                while (true) {
                  boolean bool;
                  if (b2 == 0) {
                    bool = false;
                  } else {
                    if (paramPtr6.getInt() < b3) {
                      bool = false;
                    } else {
                      bool = true;
                    } 
                    bool = bool;
                  } 
                  if ((bool ^ true) == 0) {
                    if (paramPtr3.getAlignedDouble(b3 * j + k + i10) != paramPtr3.getAlignedDouble(b3 * j + k + i8)) {
                      b2 = 0;
                    } else {
                      b2 = 1;
                    } 
                    b2 = b2;
                    b3++;
                    continue;
                  } 
                  i10++;
                } 
              } 
              i10--;
              if (b2 == 0) {
                i10 = i8;
                if (paramPtr4.getInt() >= 0)
                  paramPtr4.setAlignedInt(i8 + -1, paramPtr1.getInt()); 
              } else {
                i8--;
              } 
              paramPtr12.setAlignedInt(b1 * i3 + i4 + b, paramPtr11.getAlignedInt(b1 * n + i1 + b));
              paramPtr12.setAlignedInt(b1 * i3 + i4 + i2 + b, i10);
              paramPtr13.setAlignedInt(b1 * i6 + i7 + b, i10);
              paramPtr13.setAlignedInt(b1 * i6 + i7 + i5 + b, paramPtr11.getAlignedInt(b1 * n + i1 + m + b));
              if (b1 != i9) {
                i10 = 0;
              } else {
                i10 = 1;
              } 
              b1++;
              break;
            } 
            if (i10 == 0)
              continue; 
            break;
          }  
        if (b != i) {
          i9 = 0;
        } else {
          i9 = 1;
        } 
        b++;
        if (i9 == 0)
          continue; 
        break;
      }  
    paramPtr2.setInt(i8);
    if (paramPtr2.getInt() > paramPtr5.getInt())
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 180 }, 0)); 
  }
  
  public static void ehg126_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    int k = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr1.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int j = Math.max(paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr1.getInt(), 0));
    int n = j ^ 0xFFFFFFFF;
    $ehg126_$execnt++;
    if ($ehg126_$execnt == 1)
      $ehg126_$machin = d1mach.d1mach_((Ptr)new IntPtr(new int[] { 2 }, 0)); 
    int i1 = paramPtr1.getInt();
    byte b2 = 1;
    if (1 <= i1)
      while (true) {
        double d4 = $ehg126_$machin;
        double d3 = -$ehg126_$machin;
        int i2 = paramPtr2.getInt();
        byte b = 1;
        if (1 <= i2)
          while (true) {
            boolean bool2;
            double d6 = paramPtr4.getAlignedDouble(b2 * k + m + b);
            double d5 = d4;
            if (d6 >= d4) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            boolean bool1 = bool1;
            if (!Double.isNaN(d5) && !Double.isNaN(d5)) {
              bool2 = false;
            } else {
              bool2 = true;
            } 
            if ((bool1 | bool2 & true) != 0)
              d5 = d6; 
            d4 = d5;
            d5 = d3;
            if (d6 <= d3) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            bool1 = bool1;
            if (!Double.isNaN(d5) && !Double.isNaN(d5)) {
              bool2 = false;
            } else {
              bool2 = true;
            } 
            if ((bool1 | bool2 & true) != 0)
              d5 = d6; 
            d3 = d5;
            if (b != i2) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b++;
            if (!bool1)
              continue; 
            break;
          }  
        double d2 = Math.abs(d4);
        double d1 = Math.abs(d3);
        if (d1 <= d2) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        i2 = i2;
        if (!Double.isNaN(d2) && !Double.isNaN(d2)) {
          b = 0;
        } else {
          b = 1;
        } 
        if ((i2 | b & 0x1) != 0)
          d2 = d1; 
        d1 = d3 - d4;
        d2 = d2 * 1.0E-10D + 1.0E-30D;
        if (d2 <= d1) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        i2 = i2;
        if (!Double.isNaN(d1) && !Double.isNaN(d1)) {
          b = 0;
        } else {
          b = 1;
        } 
        if ((i2 | b & 0x1) != 0)
          d1 = d2; 
        d3 = d1 * 0.005D;
        d4 -= d3;
        d3 += d3;
        paramPtr5.setAlignedDouble(b2 * j + n + 1, d4);
        paramPtr5.setAlignedDouble(b2 * j + n + paramPtr3.getInt(), d3);
        if (b2 != i1) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        b2++;
        if (i2 == 0)
          continue; 
        break;
      }  
    int i = paramPtr3.getInt() + -1;
    byte b1 = 2;
    if (2 <= i)
      while (true) {
        k = b1 + -1;
        m = paramPtr1.getInt();
        i1 = 1;
        if (1 <= m)
          while (true) {
            paramPtr5.setAlignedDouble(i1 * j + n + b1, paramPtr5.getAlignedDouble(i1 * j + n + k % 2 * (paramPtr3.getInt() + -1) + 1));
            k = (int)(k / 2.0D);
            if (i1 != m) {
              b2 = 0;
            } else {
              b2 = 1;
            } 
            i1++;
            if (b2 == 0)
              continue; 
            break;
          }  
        if (b1 != i) {
          k = 0;
        } else {
          k = 1;
        } 
        b1++;
        if (k == 0)
          continue; 
        break;
      }  
  }
  
  public static void ehg127_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    double[] arrayOfDouble3 = new double[15];
    double[] arrayOfDouble4 = new double[15];
    arrayOfDouble2[0] = 0.0D;
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    int m = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr3.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int i1 = Math.max(paramPtr4.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i1 * paramPtr11.getInt(), 0));
    int i2 = i1 ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr15.getInt() + 1, 0));
    $ehg127_$execnt++;
    if ($ehg127_$execnt == 1)
      $ehg127_$machep = d1mach.d1mach_((Ptr)new IntPtr(new int[] { 4 }, 0)); 
    int i3 = paramPtr2.getInt();
    byte b3 = 1;
    if (1 <= i3)
      while (true) {
        boolean bool;
        paramPtr12.setAlignedDouble(b3 + -1, 0.0D);
        if (b3 != i3) {
          bool = false;
        } else {
          bool = true;
        } 
        b3++;
        if (!bool)
          continue; 
        break;
      }  
    i3 = paramPtr26.getInt();
    b3 = 1;
    if (1 <= i3)
      while (true) {
        double d = paramPtr1.getAlignedDouble(b3 + -1);
        int i4 = paramPtr2.getInt();
        byte b = 1;
        if (1 <= i4)
          while (true) {
            boolean bool;
            paramPtr12.setAlignedDouble(b + -1, (paramPtr6.getAlignedDouble(b3 * m + n + b) - d) * (paramPtr6.getAlignedDouble(b3 * m + n + b) - d) + paramPtr12.getAlignedDouble(b + -1));
            if (b != i4) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        if (b3 != i3) {
          i4 = 0;
        } else {
          i4 = 1;
        } 
        b3++;
        if (i4 == 0)
          continue; 
        break;
      }  
    ehg106_((Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr2, paramPtr4, (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr12, paramPtr7, paramPtr2);
    double d2 = 1.0D;
    double d1 = paramPtr5.getDouble();
    if (d1 <= 1.0D) {
      j = 0;
    } else {
      j = 1;
    } 
    int j = j;
    if (!Double.isNaN(1.0D) && !Double.isNaN(1.0D)) {
      k = 0;
    } else {
      k = 1;
    } 
    if ((j | k & 0x1) != 0)
      d2 = d1; 
    arrayOfDouble2[0] = paramPtr12.getAlignedDouble(paramPtr7.getAlignedInt(paramPtr4.getInt() + -1) + -1) * d2;
    if (arrayOfDouble2[0] <= 0.0D)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 120 }, 0)); 
    if (paramPtr10.getInt() != 2) {
      j = paramPtr4.getInt();
      k = 1;
      if (1 <= j)
        while (true) {
          boolean bool;
          paramPtr16.setAlignedDouble(k + -1, Mathlib.sqrt(paramPtr12.getAlignedDouble(paramPtr7.getAlignedInt(k + -1) + -1) / arrayOfDouble2[0]));
          if (k != j) {
            bool = false;
          } else {
            bool = true;
          } 
          k++;
          if (!bool)
            continue; 
          break;
        }  
      j = paramPtr4.getInt();
      k = 1;
      if (1 <= j)
        while (true) {
          boolean bool;
          d1 = paramPtr9.getAlignedDouble(paramPtr7.getAlignedInt(k + -1) + -1);
          paramPtr16.setAlignedDouble(k + -1, Mathlib.sqrt(Builtins.powi(1.0D - Builtins.powi(paramPtr16.getAlignedDouble(k + -1), 3), 3) * d1));
          if (k != j) {
            bool = false;
          } else {
            bool = true;
          } 
          k++;
          if (!bool)
            continue; 
          break;
        }  
    } else {
      j = paramPtr4.getInt();
      k = 1;
      if (1 <= j)
        while (true) {
          boolean bool;
          if (paramPtr12.getAlignedDouble(paramPtr7.getAlignedInt(k + -1) + -1) >= arrayOfDouble2[0]) {
            d1 = 0.0D;
          } else {
            d1 = Mathlib.sqrt(paramPtr9.getAlignedDouble(paramPtr7.getAlignedInt(k + -1) + -1));
          } 
          paramPtr16.setAlignedDouble(k + -1, d1);
          if (k != j) {
            bool = false;
          } else {
            bool = true;
          } 
          k++;
          if (!bool)
            continue; 
          break;
        }  
    } 
    if (paramPtr16.getAlignedDouble(Blas.idamax_(paramPtr4, paramPtr16, (Ptr)new IntPtr(new int[] { 1 }, 0)) + -1) == 0.0D) {
      ehg184_((Ptr)new BytePtr("at ".getBytes(), 0), paramPtr1, paramPtr26, (Ptr)new IntPtr(new int[] { 1 }, 0), 3);
      ehg184_((Ptr)new BytePtr("radius ".getBytes(), 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 7);
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 121 }, 0));
    } 
    j = 1;
    int k = paramPtr4.getInt();
    byte b2 = 1;
    if (1 <= k)
      while (true) {
        boolean bool;
        paramPtr14.setAlignedDouble(1 * i1 + i2 + b2, paramPtr16.getAlignedDouble(b2 + -1));
        if (b2 != k) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    if (paramPtr27.getInt() > 0) {
      k = paramPtr3.getInt();
      b2 = 1;
      if (1 <= k)
        while (true) {
          boolean bool;
          if (paramPtr28.getAlignedInt(b2 + -1) > 0) {
            j++;
            d1 = paramPtr1.getAlignedDouble(b2 + -1);
            bool = paramPtr4.getInt();
            byte b = 1;
            if (true <= bool)
              while (true) {
                boolean bool1;
                paramPtr14.setAlignedDouble(j * i1 + i2 + b, paramPtr16.getAlignedDouble(b + -1) * (paramPtr6.getAlignedDouble(b2 * m + n + paramPtr7.getAlignedInt(b + -1)) - d1));
                if (b != bool) {
                  bool1 = false;
                } else {
                  bool1 = true;
                } 
                b++;
                if (!bool1)
                  continue; 
                break;
              }  
          } 
          if (b2 != k) {
            bool = false;
          } else {
            bool = true;
          } 
          b2++;
          if (!bool)
            continue; 
          break;
        }  
    } 
    if (paramPtr27.getInt() > 1) {
      k = paramPtr3.getInt();
      b2 = 1;
      if (1 <= k)
        while (true) {
          boolean bool;
          if (paramPtr28.getAlignedInt(b2 + -1) > 0) {
            if (paramPtr28.getAlignedInt(b2 + -1) > 1) {
              j++;
              d1 = paramPtr1.getAlignedDouble(b2 + -1);
              int i5 = paramPtr4.getInt();
              byte b = 1;
              if (1 <= i5)
                while (true) {
                  boolean bool1;
                  paramPtr14.setAlignedDouble(j * i1 + i2 + b, (paramPtr6.getAlignedDouble(b2 * m + n + paramPtr7.getAlignedInt(b + -1)) - d1) * (paramPtr6.getAlignedDouble(b2 * m + n + paramPtr7.getAlignedInt(b + -1)) - d1) * paramPtr16.getAlignedDouble(b + -1));
                  if (b != i5) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b++;
                  if (!bool1)
                    continue; 
                  break;
                }  
            } 
            bool = paramPtr3.getInt();
            int i4;
            if ((i4 = b2 + 1) <= bool)
              while (true) {
                boolean bool1;
                if (paramPtr28.getAlignedInt(i4 + -1) > 0) {
                  j++;
                  d1 = paramPtr1.getAlignedDouble(b2 + -1);
                  d2 = paramPtr1.getAlignedDouble(i4 + -1);
                  bool1 = paramPtr4.getInt();
                  byte b = 1;
                  if (true <= bool1)
                    while (true) {
                      paramPtr14.setAlignedDouble(j * i1 + i2 + b, paramPtr16.getAlignedDouble(b + -1) * (paramPtr6.getAlignedDouble(b2 * m + n + paramPtr7.getAlignedInt(b + -1)) - d1) * (paramPtr6.getAlignedDouble(i4 * m + n + paramPtr7.getAlignedInt(b + -1)) - d2));
                      if (b != bool1) {
                        i3 = 0;
                      } else {
                        i3 = 1;
                      } 
                      b++;
                      if (i3 == 0)
                        continue; 
                      break;
                    }  
                } 
                if (i4 != bool) {
                  bool1 = false;
                } else {
                  bool1 = true;
                } 
                i4++;
                if (!bool1)
                  continue; 
                break;
              }  
          } 
          if (b2 != k) {
            bool = false;
          } else {
            bool = true;
          } 
          b2++;
          if (!bool)
            continue; 
          break;
        }  
      paramPtr11.setInt(j);
    } 
    j = paramPtr4.getInt();
    k = 1;
    if (1 <= j)
      while (true) {
        boolean bool;
        paramPtr13.setAlignedDouble(k + -1, paramPtr16.getAlignedDouble(k + -1) * paramPtr8.getAlignedDouble(paramPtr7.getAlignedInt(k + -1) + -1));
        if (k != j) {
          bool = false;
        } else {
          bool = true;
        } 
        k++;
        if (!bool)
          continue; 
        break;
      }  
    j = paramPtr11.getInt();
    k = 1;
    if (1 <= j)
      while (true) {
        d1 = 0.0D;
        int i4 = paramPtr4.getInt();
        byte b = 1;
        if (1 <= i4)
          while (true) {
            boolean bool;
            d1 += paramPtr14.getAlignedDouble(k * i1 + i2 + b) * paramPtr14.getAlignedDouble(k * i1 + i2 + b);
            if (b != i4) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        d1 = Mathlib.sqrt(d1);
        if (d1 <= 0.0D) {
          arrayOfDouble4[k + -1] = 1.0D;
        } else {
          i4 = paramPtr4.getInt();
          b = 1;
          if (1 <= i4)
            while (true) {
              boolean bool;
              paramPtr14.setAlignedDouble(k * i1 + i2 + b, paramPtr14.getAlignedDouble(k * i1 + i2 + b) / d1);
              if (b != i4) {
                bool = false;
              } else {
                bool = true;
              } 
              b++;
              if (!bool)
                continue; 
              break;
            }  
          arrayOfDouble4[k + -1] = d1;
        } 
        if (k != j) {
          i4 = 0;
        } else {
          i4 = 1;
        } 
        k++;
        if (i4 == 0)
          continue; 
        break;
      }  
    Appl.dqrdc_(paramPtr14, paramPtr4, paramPtr4, paramPtr11, paramPtr23, (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr24, (Ptr)new IntPtr(new int[] { 0 }, 0));
    Appl.dqrsl_(paramPtr14, paramPtr4, paramPtr4, paramPtr11, paramPtr23, paramPtr13, paramPtr24, paramPtr13, paramPtr13, paramPtr24, paramPtr24, (Ptr)new IntPtr(new int[] { 1000 }, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
    j = paramPtr11.getInt();
    byte b1 = 1;
    if (1 <= j)
      while (true) {
        k = paramPtr11.getInt();
        byte b = 1;
        if (1 <= k)
          while (true) {
            boolean bool;
            paramPtr20.setAlignedDouble(b1 * 15 + b + -16, 0.0D);
            if (b != k) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        if (b1 != j) {
          k = 0;
        } else {
          k = 1;
        } 
        b1++;
        if (k == 0)
          continue; 
        break;
      }  
    j = paramPtr11.getInt();
    b1 = 1;
    if (1 <= j)
      while (true) {
        k = paramPtr11.getInt();
        byte b = b1;
        if (b1 <= k)
          while (true) {
            boolean bool;
            paramPtr20.setAlignedDouble(b * 15 + b1 + -16, paramPtr14.getAlignedDouble(b * i1 + i2 + b1));
            if (b != k) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        if (b1 != j) {
          k = 0;
        } else {
          k = 1;
        } 
        b1++;
        if (k == 0)
          continue; 
        break;
      }  
    Appl.dsvdc_(paramPtr20, (Ptr)new IntPtr(new int[] { 15 }, 0), paramPtr11, paramPtr11, paramPtr19, (Ptr)new DoublePtr(arrayOfDouble3, 0), paramPtr20, (Ptr)new IntPtr(new int[] { 15 }, 0), paramPtr21, (Ptr)new IntPtr(new int[] { 15 }, 0), paramPtr24, (Ptr)new IntPtr(new int[] { 21 }, 0), (Ptr)new IntPtr(arrayOfInt2, 0));
    if (arrayOfInt2[0] != 0)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 182 }, 0)); 
    paramPtr25.setDouble(paramPtr19.getDouble() * $ehg127_$machep * 100.0D);
    d2 = paramPtr17.getDouble();
    d1 = paramPtr19.getAlignedDouble(paramPtr11.getInt() + -1) / paramPtr19.getDouble();
    if (d1 >= d2) {
      j = 0;
    } else {
      j = 1;
    } 
    j = j;
    if (!Double.isNaN(d2) && !Double.isNaN(d2)) {
      b1 = 0;
    } else {
      b1 = 1;
    } 
    if ((j | b1 & 0x1) != 0)
      d2 = d1; 
    paramPtr17.setDouble(d2);
    if (paramPtr19.getAlignedDouble(paramPtr11.getInt() + -1) <= paramPtr25.getDouble()) {
      paramPtr18.setInt(paramPtr18.getInt() + 1);
      if (paramPtr18.getInt() != 1) {
        if (paramPtr18.getInt() == 2)
          ehg184_((Ptr)new BytePtr("There are other near singularities as well.".getBytes(), 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 43); 
      } else {
        ehg184_((Ptr)new BytePtr("pseudoinverse used at".getBytes(), 0), paramPtr1, paramPtr3, (Ptr)new IntPtr(new int[] { 1 }, 0), 21);
        arrayOfDouble1[0] = Mathlib.sqrt(arrayOfDouble2[0]);
        ehg184_((Ptr)new BytePtr("neighborhood radius".getBytes(), 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 19);
        ehg184_((Ptr)new BytePtr("reciprocal condition number ".getBytes(), 0), paramPtr17, (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 28);
      } 
    } 
    int i = paramPtr11.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        d1 = arrayOfDouble4[j + -1];
        int i4 = paramPtr11.getInt();
        b1 = 1;
        if (1 <= i4)
          while (true) {
            paramPtr21.setAlignedDouble(b1 * 15 + j + -16, paramPtr21.getAlignedDouble(b1 * 15 + j + -16) / d1);
            if (b1 != i4) {
              k = 0;
            } else {
              k = 1;
            } 
            b1++;
            if (k == 0)
              continue; 
            break;
          }  
        if (j != i) {
          i4 = 0;
        } else {
          i4 = 1;
        } 
        j++;
        if (i4 == 0)
          continue; 
        break;
      }  
    i = paramPtr11.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        if (paramPtr25.getDouble() >= paramPtr19.getAlignedDouble(j + -1)) {
          d1 = 0.0D;
        } else {
          d1 = Blas.ddot_(paramPtr11, paramPtr20.pointerPlus((j + -1) * 15 * 8), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr13, (Ptr)new IntPtr(new int[] { 1 }, 0)) / paramPtr19.getAlignedDouble(j + -1);
        } 
        paramPtr22.setAlignedDouble(j + -1, d1);
        if (j != i) {
          bool = false;
        } else {
          bool = true;
        } 
        j++;
        if (!bool)
          continue; 
        break;
      }  
    i = paramPtr15.getInt();
    j = 0;
    if (i >= 0)
      while (true) {
        boolean bool;
        if (paramPtr11.getInt() <= j) {
          paramPtr29.setAlignedDouble(j, 0.0D);
        } else {
          paramPtr29.setAlignedDouble(j, Blas.ddot_(paramPtr11, paramPtr21.pointerPlus(j * 8), (Ptr)new IntPtr(new int[] { 15 }, 0), paramPtr22, (Ptr)new IntPtr(new int[] { 1 }, 0)));
        } 
        if (j != i) {
          bool = false;
        } else {
          bool = true;
        } 
        j++;
        if (!bool)
          continue; 
        break;
      }  
  }
  
  public static double ehg128_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    int[] arrayOfInt = new int[20];
    double[] arrayOfDouble1 = new double[9];
    double[] arrayOfDouble2 = new double[9];
    double[] arrayOfDouble3 = new double[2304];
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    int k = Math.max(paramPtr2.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr11.getInt(), 0));
    int m = -k;
    int n = Math.max(paramPtr4.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr3.getInt(), 0));
    int i = n ^ 0xFFFFFFFF;
    int i1 = Math.max(paramPtr11.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i1 * paramPtr2.getInt(), 0));
    int i2 = i1 ^ 0xFFFFFFFF;
    byte b = 1;
    arrayOfInt[0] = 1;
    int i3;
    for (i3 = 1; paramPtr5.getAlignedInt(i3 + -1) != 0; i3 = arrayOfInt[b + -1]) {
      int i7;
      b++;
      if (paramPtr1.getAlignedDouble(paramPtr5.getAlignedInt(i3 + -1) + -1) > paramPtr6.getAlignedDouble(i3 + -1)) {
        i7 = paramPtr8.getAlignedInt(i3 + -1);
      } else {
        i7 = paramPtr7.getAlignedInt(i3 + -1);
      } 
      arrayOfInt[b + -1] = i7;
      if (b > 19)
        loessc__.ehg182_((Ptr)new IntPtr(new int[] { 181 }, 0)); 
    } 
    int i4 = paramPtr4.getInt();
    int i5 = 1;
    if (1 <= i4)
      while (true) {
        int i7 = paramPtr2.getInt();
        byte b1 = 0;
        if (i7 >= 0)
          while (true) {
            boolean bool;
            arrayOfDouble3[i5 * 9 + b1 + -9] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + i5) * k + m + b1);
            if (b1 != i7) {
              bool = false;
            } else {
              bool = true;
            } 
            b1++;
            if (!bool)
              continue; 
            break;
          }  
        if (i5 != i4) {
          i7 = 0;
        } else {
          i7 = 1;
        } 
        i5++;
        if (i7 == 0)
          continue; 
        break;
      }  
    i5 = paramPtr4.getInt();
    i4 = paramPtr9.getAlignedInt(i3 * n + i + 1);
    int j = paramPtr9.getAlignedInt(i3 * n + i + paramPtr4.getInt());
    int i6 = paramPtr2.getInt();
    if (i6 > 0)
      while (true) {
        double d1 = (paramPtr1.getAlignedDouble(i6 + -1) - paramPtr10.getAlignedDouble(i6 * i1 + i2 + i4)) / (paramPtr10.getAlignedDouble(i6 * i1 + i2 + j) - paramPtr10.getAlignedDouble(i6 * i1 + i2 + i4));
        if (d1 >= -0.001D) {
          if (d1 > 1.001D) {
            ehg184_((Ptr)new BytePtr("eval ".getBytes(), 0), paramPtr1, paramPtr2, (Ptr)new IntPtr(new int[] { 1 }, 0), 5);
            Ptr ptr1 = (Ptr)new BytePtr("upperlimit ".getBytes(), 0);
            Ptr ptr2 = paramPtr10.pointerPlus((i2 + i1 + j) * 8);
            ehg184_(ptr1, ptr2, paramPtr2, paramPtr11, 11);
          } 
        } else {
          ehg184_((Ptr)new BytePtr("eval ".getBytes(), 0), paramPtr1, paramPtr2, (Ptr)new IntPtr(new int[] { 1 }, 0), 5);
          Ptr ptr1 = (Ptr)new BytePtr("lowerlimit ".getBytes(), 0);
          Ptr ptr2 = paramPtr10.pointerPlus((i2 + i1 + i4) * 8);
          ehg184_(ptr1, ptr2, paramPtr2, paramPtr11, 11);
        } 
        if (d1 < -0.001D) {
          i7 = 0;
        } else {
          if (d1 > 1.001D) {
            i7 = 0;
          } else {
            i7 = 1;
          } 
          i7 = i7;
        } 
        if ((i7 ^ 0x1) != 0)
          loessc__.ehg182_((Ptr)new IntPtr(new int[] { 122 }, 0)); 
        i5 = (int)(i5 / 2.0D);
        int i7 = i5;
        byte b1 = 1;
        if (1 <= i5)
          while (true) {
            double d3 = (1.0D - d1) * (1.0D - d1) * (d1 * 2.0D + 1.0D);
            double d4 = d1 * d1 * (3.0D - d1 * 2.0D);
            double d2 = arrayOfDouble3[(b1 + -1) * 9] * d3 + arrayOfDouble3[(b1 + i5 + -1) * 9] * d4;
            arrayOfDouble3[(b1 + -1) * 9] = (d1 * (1.0D - d1) * (1.0D - d1) * arrayOfDouble3[b1 * 9 + i6 + -9] + arrayOfDouble3[(b1 + i5) * 9 + i6 + -9] * d1 * d1 * (d1 - 1.0D)) * (paramPtr10.getAlignedDouble(i6 * i1 + i2 + j) - paramPtr10.getAlignedDouble(i6 * i1 + i2 + i4)) + d2;
            int i8 = i6 + -1;
            byte b2 = 1;
            if (1 <= i8)
              while (true) {
                boolean bool;
                arrayOfDouble3[b1 * 9 + b2 + -9] = arrayOfDouble3[b1 * 9 + b2 + -9] * d3 + arrayOfDouble3[(b1 + i5) * 9 + b2 + -9] * d4;
                if (b2 != i8) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b2++;
                if (!bool)
                  continue; 
                break;
              }  
            if (b1 != i7) {
              i8 = 0;
            } else {
              i8 = 1;
            } 
            b1++;
            if (i8 == 0)
              continue; 
            break;
          }  
        if (i6 != 1) {
          i7 = 0;
        } else {
          i7 = 1;
        } 
        i6--;
        if (i7 == 0)
          continue; 
        break;
      }  
    double d = arrayOfDouble3[0];
    if (paramPtr2.getInt() == 2) {
      double d1 = paramPtr10.getAlignedDouble(i2 + i1 + i4);
      double d2 = paramPtr10.getAlignedDouble(i2 + i1 + j);
      int i7 = paramPtr2.getInt();
      int i8 = 0;
      if (i7 >= 0)
        while (true) {
          arrayOfDouble2[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 3) * k + m + i8);
          if (i8 != i7) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          i8++;
          if (i5 == 0)
            continue; 
          break;
        }  
      i7 = paramPtr2.getInt();
      i8 = 0;
      if (i7 >= 0)
        while (true) {
          arrayOfDouble1[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 4) * k + m + i8);
          if (i8 != i7) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          i8++;
          if (i5 == 0)
            continue; 
          break;
        }  
      double d3 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + j);
      i7 = b + -1;
      while (true) {
        if (i7 != 0) {
          if (paramPtr5.getAlignedInt(arrayOfInt[i7 + -1] + -1) != 2) {
            i8 = 0;
          } else {
            if (paramPtr6.getAlignedDouble(arrayOfInt[i7 + -1] + -1) != d3) {
              i8 = 0;
            } else {
              i8 = 1;
            } 
            i8 = i8;
          } 
          i8 = i8;
        } else {
          i8 = 1;
        } 
        if (i8 == 0) {
          i7--;
          continue;
        } 
        if (i7 > 0) {
          for (i7 = paramPtr8.getAlignedInt(arrayOfInt[i7 + -1] + -1); paramPtr5.getAlignedInt(i7 + -1) != 0; i7 = paramPtr7.getAlignedInt(i7 + -1)) {
            if (paramPtr1.getAlignedDouble(paramPtr5.getAlignedInt(i7 + -1) + -1) > paramPtr6.getAlignedDouble(i7 + -1)) {
              i7 = paramPtr8.getAlignedInt(i7 + -1);
              continue;
            } 
          } 
          if (paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 1)) > d1) {
            d1 = paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 1));
            i8 = paramPtr2.getInt();
            i5 = 0;
            if (i8 >= 0)
              while (true) {
                arrayOfDouble2[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 1) * k + m + i5);
                if (i5 != i8) {
                  i6 = 0;
                } else {
                  i6 = 1;
                } 
                i5++;
                if (i6 == 0)
                  continue; 
                break;
              }  
          } 
          if (paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 2)) < d2) {
            d2 = paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 2));
            i8 = paramPtr2.getInt();
            i5 = 0;
            if (i8 >= 0)
              while (true) {
                arrayOfDouble1[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 2) * k + m + i5);
                if (i5 != i8) {
                  i6 = 0;
                } else {
                  i6 = 1;
                } 
                i5++;
                if (i6 == 0)
                  continue; 
                break;
              }  
          } 
        } 
        double d4 = (paramPtr1.getDouble() - d1) / (d2 - d1);
        d3 = (1.0D - d4) * (1.0D - d4) * (d4 * 2.0D + 1.0D);
        double d5 = d4 * d4 * (3.0D - d4 * 2.0D);
        d1 = (d4 * (1.0D - d4) * (1.0D - d4) * arrayOfDouble2[1] + arrayOfDouble1[1] * d4 * d4 * (d4 - 1.0D)) * (d2 - d1) + arrayOfDouble2[0] * d3 + arrayOfDouble1[0] * d5;
        d2 = arrayOfDouble2[2] * d3 + arrayOfDouble1[2] * d5;
        d3 = paramPtr10.getAlignedDouble(i2 + i1 + i4);
        d5 = paramPtr10.getAlignedDouble(i2 + i1 + j);
        i7 = paramPtr2.getInt();
        i8 = 0;
        if (i7 >= 0)
          while (true) {
            arrayOfDouble2[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 1) * k + m + i8);
            if (i8 != i7) {
              i5 = 0;
            } else {
              i5 = 1;
            } 
            i8++;
            if (i5 == 0)
              continue; 
            break;
          }  
        i7 = paramPtr2.getInt();
        i8 = 0;
        if (i7 >= 0)
          while (true) {
            arrayOfDouble1[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 2) * k + m + i8);
            if (i8 != i7) {
              i5 = 0;
            } else {
              i5 = 1;
            } 
            i8++;
            if (i5 == 0)
              continue; 
            break;
          }  
        d4 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4);
        i7 = b + -1;
        while (true) {
          if (i7 != 0) {
            if (paramPtr5.getAlignedInt(arrayOfInt[i7 + -1] + -1) != 2) {
              i8 = 0;
            } else {
              if (paramPtr6.getAlignedDouble(arrayOfInt[i7 + -1] + -1) != d4) {
                i8 = 0;
              } else {
                i8 = 1;
              } 
              i8 = i8;
            } 
            i8 = i8;
          } else {
            i8 = 1;
          } 
          if (i8 == 0) {
            i7--;
            continue;
          } 
          if (i7 > 0) {
            for (i7 = paramPtr7.getAlignedInt(arrayOfInt[i7 + -1] + -1); paramPtr5.getAlignedInt(i7 + -1) != 0; i7 = paramPtr7.getAlignedInt(i7 + -1)) {
              if (paramPtr1.getAlignedDouble(paramPtr5.getAlignedInt(i7 + -1) + -1) > paramPtr6.getAlignedDouble(i7 + -1)) {
                i7 = paramPtr8.getAlignedInt(i7 + -1);
                continue;
              } 
            } 
            if (paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 3)) > d3) {
              d3 = paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 3));
              i8 = paramPtr2.getInt();
              i5 = 0;
              if (i8 >= 0)
                while (true) {
                  arrayOfDouble2[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 3) * k + m + i5);
                  if (i5 != i8) {
                    i6 = 0;
                  } else {
                    i6 = 1;
                  } 
                  i5++;
                  if (i6 == 0)
                    continue; 
                  break;
                }  
            } 
            if (paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 4)) < d5) {
              d5 = paramPtr10.getAlignedDouble(i2 + i1 + paramPtr9.getAlignedInt(i7 * n + i + 4));
              i8 = paramPtr2.getInt();
              i5 = 0;
              if (i8 >= 0)
                while (true) {
                  arrayOfDouble1[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 4) * k + m + i5);
                  if (i5 != i8) {
                    i6 = 0;
                  } else {
                    i6 = 1;
                  } 
                  i5++;
                  if (i6 == 0)
                    continue; 
                  break;
                }  
            } 
          } 
          double d6 = (paramPtr1.getDouble() - d3) / (d5 - d3);
          d4 = (1.0D - d6) * (1.0D - d6) * (d6 * 2.0D + 1.0D);
          double d7 = d6 * d6 * (3.0D - d6 * 2.0D);
          d3 = (d6 * (1.0D - d6) * (1.0D - d6) * arrayOfDouble2[1] + arrayOfDouble1[1] * d6 * d6 * (d6 - 1.0D)) * (d5 - d3) + arrayOfDouble2[0] * d4 + arrayOfDouble1[0] * d7;
          d5 = arrayOfDouble2[2] * d4 + arrayOfDouble1[2] * d7;
          d4 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4);
          d7 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + j);
          i7 = paramPtr2.getInt();
          i8 = 0;
          if (i7 >= 0)
            while (true) {
              arrayOfDouble2[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 2) * k + m + i8);
              if (i8 != i7) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i8++;
              if (i5 == 0)
                continue; 
              break;
            }  
          i7 = paramPtr2.getInt();
          i8 = 0;
          if (i7 >= 0)
            while (true) {
              arrayOfDouble1[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 4) * k + m + i8);
              if (i8 != i7) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i8++;
              if (i5 == 0)
                continue; 
              break;
            }  
          d6 = paramPtr10.getAlignedDouble(i2 + i1 + j);
          i7 = b + -1;
          while (true) {
            if (i7 != 0) {
              if (paramPtr5.getAlignedInt(arrayOfInt[i7 + -1] + -1) != 1) {
                i8 = 0;
              } else {
                if (paramPtr6.getAlignedDouble(arrayOfInt[i7 + -1] + -1) != d6) {
                  i8 = 0;
                } else {
                  i8 = 1;
                } 
                i8 = i8;
              } 
              i8 = i8;
            } else {
              i8 = 1;
            } 
            if (i8 == 0) {
              i7--;
              continue;
            } 
            if (i7 > 0) {
              for (i7 = paramPtr8.getAlignedInt(arrayOfInt[i7 + -1] + -1); paramPtr5.getAlignedInt(i7 + -1) != 0; i7 = paramPtr7.getAlignedInt(i7 + -1)) {
                if (paramPtr1.getAlignedDouble(paramPtr5.getAlignedInt(i7 + -1) + -1) > paramPtr6.getAlignedDouble(i7 + -1)) {
                  i7 = paramPtr8.getAlignedInt(i7 + -1);
                  continue;
                } 
              } 
              if (paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 1)) > d4) {
                d4 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 1));
                i8 = paramPtr2.getInt();
                i5 = 0;
                if (i8 >= 0)
                  while (true) {
                    arrayOfDouble2[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 1) * k + m + i5);
                    if (i5 != i8) {
                      i6 = 0;
                    } else {
                      i6 = 1;
                    } 
                    i5++;
                    if (i6 == 0)
                      continue; 
                    break;
                  }  
              } 
              if (paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 3)) < d7) {
                d7 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 3));
                i8 = paramPtr2.getInt();
                i5 = 0;
                if (i8 >= 0)
                  while (true) {
                    arrayOfDouble1[i5] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 3) * k + m + i5);
                    if (i5 != i8) {
                      i6 = 0;
                    } else {
                      i6 = 1;
                    } 
                    i5++;
                    if (i6 == 0)
                      continue; 
                    break;
                  }  
              } 
            } 
            double d8 = (paramPtr1.getAlignedDouble(1) - d4) / (d7 - d4);
            d6 = (1.0D - d8) * (1.0D - d8) * (d8 * 2.0D + 1.0D);
            double d9 = d8 * d8 * (3.0D - d8 * 2.0D);
            d4 = (d8 * (1.0D - d8) * (1.0D - d8) * arrayOfDouble2[2] + arrayOfDouble1[2] * d8 * d8 * (d8 - 1.0D)) * (d7 - d4) + arrayOfDouble2[0] * d6 + arrayOfDouble1[0] * d9;
            d7 = arrayOfDouble2[1] * d6 + arrayOfDouble1[1] * d9;
            d6 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4);
            d9 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + j);
            i7 = paramPtr2.getInt();
            i8 = 0;
            if (i7 >= 0)
              while (true) {
                arrayOfDouble2[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 1) * k + m + i8);
                if (i8 != i7) {
                  i5 = 0;
                } else {
                  i5 = 1;
                } 
                i8++;
                if (i5 == 0)
                  continue; 
                break;
              }  
            i7 = paramPtr2.getInt();
            i8 = 0;
            if (i7 >= 0)
              while (true) {
                arrayOfDouble1[i8] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i3 * n + i + 3) * k + m + i8);
                if (i8 != i7) {
                  i5 = 0;
                } else {
                  i5 = 1;
                } 
                i8++;
                if (i5 == 0)
                  continue; 
                break;
              }  
            d8 = paramPtr10.getAlignedDouble(i2 + i1 + i4);
            i7 = b + -1;
            while (true) {
              if (i7 != 0) {
                if (paramPtr5.getAlignedInt(arrayOfInt[i7 + -1] + -1) != 1) {
                  b = 0;
                } else {
                  if (paramPtr6.getAlignedDouble(arrayOfInt[i7 + -1] + -1) != d8) {
                    b = 0;
                  } else {
                    b = 1;
                  } 
                  b = b;
                } 
                b = b;
              } else {
                b = 1;
              } 
              if (b == 0) {
                i7--;
                continue;
              } 
              if (i7 > 0) {
                for (i7 = paramPtr7.getAlignedInt(arrayOfInt[i7 + -1] + -1); paramPtr5.getAlignedInt(i7 + -1) != 0; i7 = paramPtr7.getAlignedInt(i7 + -1)) {
                  if (paramPtr1.getAlignedDouble(paramPtr5.getAlignedInt(i7 + -1) + -1) > paramPtr6.getAlignedDouble(i7 + -1)) {
                    i7 = paramPtr8.getAlignedInt(i7 + -1);
                    continue;
                  } 
                } 
                if (paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 2)) > d6) {
                  d6 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 2));
                  int i9 = paramPtr2.getInt();
                  byte b1 = 0;
                  if (i9 >= 0)
                    while (true) {
                      boolean bool;
                      arrayOfDouble2[b1] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 2) * k + m + b1);
                      if (b1 != i9) {
                        bool = false;
                      } else {
                        bool = true;
                      } 
                      b1++;
                      if (!bool)
                        continue; 
                      break;
                    }  
                } 
                if (paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 4)) < d9) {
                  d9 = paramPtr10.getAlignedDouble(i1 * 2 + i2 + paramPtr9.getAlignedInt(i7 * n + i + 4));
                  int i9 = paramPtr2.getInt();
                  byte b1 = 0;
                  if (i9 >= 0)
                    while (true) {
                      boolean bool;
                      arrayOfDouble1[b1] = paramPtr12.getAlignedDouble(paramPtr9.getAlignedInt(i7 * n + i + 4) * k + m + b1);
                      if (b1 != i9) {
                        bool = false;
                      } else {
                        bool = true;
                      } 
                      b1++;
                      if (!bool)
                        continue; 
                      break;
                    }  
                } 
              } 
              d8 = (paramPtr1.getAlignedDouble(1) - d6) / (d9 - d6);
              double d10 = (1.0D - d8) * (1.0D - d8) * (d8 * 2.0D + 1.0D);
              double d11 = d8 * d8 * (3.0D - d8 * 2.0D);
              d6 = arrayOfDouble2[1] * d10 + arrayOfDouble1[1] * d11;
              d9 = (paramPtr1.getAlignedDouble(1) - paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4)) / (paramPtr10.getAlignedDouble(i1 * 2 + i2 + j) - paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4));
              d1 = (1.0D - d9) * (1.0D - d9) * (d9 * 2.0D + 1.0D) * d3 + d9 * d9 * (3.0D - d9 * 2.0D) * d1 + (d9 * (1.0D - d9) * (1.0D - d9) * d5 + d9 * d9 * (d9 - 1.0D) * d2) * (paramPtr10.getAlignedDouble(i1 * 2 + i2 + j) - paramPtr10.getAlignedDouble(i1 * 2 + i2 + i4));
              d2 = (paramPtr1.getDouble() - paramPtr10.getAlignedDouble(i2 + i1 + i4)) / (paramPtr10.getAlignedDouble(i2 + i1 + j) - paramPtr10.getAlignedDouble(i2 + i1 + i4));
              d = ((d8 * (1.0D - d8) * (1.0D - d8) * arrayOfDouble2[2] + arrayOfDouble1[2] * d8 * d8 * (d8 - 1.0D)) * (d9 - d6) + arrayOfDouble2[0] * d10 + arrayOfDouble1[0] * d11) * (1.0D - d2) * (1.0D - d2) * (d2 * 2.0D + 1.0D) + d2 * d2 * (3.0D - d2 * 2.0D) * d4 + (d2 * (1.0D - d2) * (1.0D - d2) * d6 + d2 * d2 * (d2 - 1.0D) * d7) * (paramPtr10.getAlignedDouble(i2 + i1 + j) - paramPtr10.getAlignedDouble(i2 + i1 + i4)) + d1 - d;
              break;
            } 
            break;
          } 
          break;
        } 
        break;
      } 
    } 
    return d;
  }
  
  public static void ehg129_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int j = Math.max(paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr3.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    $ehg129_$execnt++;
    if ($ehg129_$execnt == 1)
      $ehg129_$machin = d1mach.d1mach_((Ptr)new IntPtr(new int[] { 2 }, 0)); 
    int i = paramPtr3.getInt();
    byte b = 1;
    if (1 <= i)
      while (true) {
        double d1 = $ehg129_$machin;
        double d2 = -$ehg129_$machin;
        int m = paramPtr2.getInt();
        int n;
        if ((n = paramPtr1.getInt()) <= m)
          while (true) {
            boolean bool2;
            double d4 = paramPtr4.getAlignedDouble(b * j + k + paramPtr5.getAlignedInt(n + -1));
            double d5 = d1;
            double d3 = paramPtr4.getAlignedDouble(b * j + k + paramPtr5.getAlignedInt(n + -1));
            if (d3 >= d1) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            boolean bool1 = bool1;
            if (!Double.isNaN(d5) && !Double.isNaN(d5)) {
              bool2 = false;
            } else {
              bool2 = true;
            } 
            if ((bool1 | bool2 & true) != 0)
              d5 = d3; 
            d1 = d5;
            d3 = d2;
            if (d4 <= d2) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            bool1 = bool1;
            if (!Double.isNaN(d3) && !Double.isNaN(d3)) {
              bool2 = false;
            } else {
              bool2 = true;
            } 
            if ((bool1 | bool2 & true) != 0)
              d3 = d4; 
            d2 = d3;
            if (n != m) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            n++;
            if (!bool1)
              continue; 
            break;
          }  
        paramPtr7.setAlignedDouble(b + -1, d2 - d1);
        if (b != i) {
          m = 0;
        } else {
          m = 1;
        } 
        b++;
        if (m == 0)
          continue; 
        break;
      }  
  }
  
  public static void ehg131_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38, Ptr paramPtr39, Ptr paramPtr40, Ptr paramPtr41) {
    double[] arrayOfDouble = new double[8];
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr8.getInt(), 0) * paramPtr9.getInt(), 0));
    int j = Math.max(paramPtr14.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr9.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    int m = Math.max(paramPtr12.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr11.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr14.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr11.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr11.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr11.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr11.getInt(), 0));
    int i1 = Math.max(paramPtr9.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(i1 * paramPtr14.getInt(), 0));
    int i2 = -i1;
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr15.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr15.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr14.getInt(), 0) * paramPtr15.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(Math.max(paramPtr9.getInt() + 1, 0) * paramPtr14.getInt(), 0) * paramPtr15.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr9.getInt() + 1, 0) * paramPtr14.getInt(), 0));
    if (paramPtr9.getInt() > 8)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 101 }, 0)); 
    ehg126_(paramPtr9, paramPtr8, paramPtr12, paramPtr1, paramPtr23, paramPtr14);
    paramPtr13.setInt(paramPtr12.getInt());
    paramPtr10.setInt(1);
    int i3 = paramPtr12.getInt();
    byte b = 1;
    if (1 <= i3)
      while (true) {
        boolean bool;
        paramPtr18.setAlignedInt(paramPtr10.getInt() * m + n + b, b);
        paramPtr24.setAlignedInt(b + -1, 0);
        if (b != i3) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    m = paramPtr9.getInt();
    n = 1;
    if (1 <= m)
      while (true) {
        arrayOfDouble[n + -1] = paramPtr23.getAlignedDouble(n * j + k + paramPtr12.getInt()) - paramPtr23.getAlignedDouble(n * j + k + 1);
        if (n != m) {
          i3 = 0;
        } else {
          i3 = 1;
        } 
        n++;
        if (i3 == 0)
          continue; 
        break;
      }  
    paramPtr31.setDouble(paramPtr31.getDouble() * Blas.dnrm2_(paramPtr9, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(new int[] { 1 }, 0)));
    int i = paramPtr8.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        paramPtr21.setAlignedInt(j + -1, j);
        if (j != i) {
          k = 0;
        } else {
          k = 1;
        } 
        j++;
        if (k == 0)
          continue; 
        break;
      }  
    ehg124_((Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr8, paramPtr9, paramPtr8, paramPtr13, paramPtr10, paramPtr11, paramPtr12, paramPtr1, paramPtr21, paramPtr17, paramPtr26, paramPtr20, paramPtr19, paramPtr18, paramPtr23, paramPtr24, paramPtr14, paramPtr30, paramPtr31, paramPtr36);
    if (paramPtr4.getDouble() != 0.0D) {
      int i4 = paramPtr13.getInt();
      byte b1 = 1;
      if (1 <= i4)
        while (true) {
          int i5 = paramPtr9.getInt();
          i = 0;
          if (i5 >= 0)
            while (true) {
              paramPtr33.setAlignedDouble(b1 * i1 + i2 + i, 0.0D);
              if (i != i5) {
                j = 0;
              } else {
                j = 1;
              } 
              i++;
              if (j == 0)
                continue; 
              break;
            }  
          if (b1 != i4) {
            i5 = 0;
          } else {
            i5 = 1;
          } 
          b1++;
          if (i5 == 0)
            continue; 
          break;
        }  
    } 
    ehg139_(paramPtr23, paramPtr14, paramPtr13, paramPtr8, paramPtr9, paramPtr15, paramPtr16, paramPtr1, paramPtr21, paramPtr22, paramPtr2, paramPtr3, paramPtr4, paramPtr6, paramPtr7, paramPtr27, paramPtr27, paramPtr28, paramPtr29, paramPtr9, paramPtr32, paramPtr5, paramPtr33, paramPtr10, paramPtr12, paramPtr17, paramPtr26, paramPtr20, paramPtr19, paramPtr18, paramPtr24, paramPtr34, paramPtr35, paramPtr36, paramPtr37, paramPtr38, paramPtr39, paramPtr40, paramPtr41, paramPtr25);
  }
  
  public static void ehg133_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    double[] arrayOfDouble = new double[8];
    int i = Math.max(paramPtr14.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr2.getInt(), 0));
    int k = i ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr14.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr3.getInt(), 0) * paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr4.getInt(), 0) * paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr2.getInt() + 1, 0) * paramPtr4.getInt(), 0));
    int j = paramPtr14.getInt();
    byte b = 1;
    if (1 <= j)
      while (true) {
        int m = paramPtr2.getInt();
        byte b1 = 1;
        if (1 <= m)
          while (true) {
            boolean bool;
            arrayOfDouble[b1 + -1] = paramPtr15.getAlignedDouble(b1 * i + k + b);
            if (b1 != m) {
              bool = false;
            } else {
              bool = true;
            } 
            b1++;
            if (!bool)
              continue; 
            break;
          }  
        paramPtr16.setAlignedDouble(b + -1, ehg128_((Ptr)new DoublePtr(arrayOfDouble, 0), paramPtr2, paramPtr6, paramPtr3, paramPtr7, paramPtr13, paramPtr10, paramPtr9, paramPtr8, paramPtr11, paramPtr4, paramPtr12));
        if (b != j) {
          m = 0;
        } else {
          m = 1;
        } 
        b++;
        if (m == 0)
          continue; 
        break;
      }  
  }
  
  public static void ehg136_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26) {
    double[] arrayOfDouble1 = new double[15];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[15];
    double[] arrayOfDouble4 = new double[15];
    double[] arrayOfDouble5 = new double[8];
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble6 = new double[225];
    double[] arrayOfDouble7 = new double[225];
    double[] arrayOfDouble8 = new double[15];
    arrayOfDouble2[0] = 0.0D;
    arrayOfInt[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int i = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr5.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr4.getInt(), 0) * paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr6.getInt(), 0) * paramPtr13.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    int k = Math.max(paramPtr17.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr3.getInt(), 0));
    int m = -k;
    int n = Math.max(paramPtr3.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr4.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    if (paramPtr13.getInt() > paramPtr6.getInt() + -1)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 104 }, 0)); 
    if (paramPtr13.getInt() > 15)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 105 }, 0)); 
    int i2 = paramPtr4.getInt();
    byte b = 1;
    if (1 <= i2)
      while (true) {
        boolean bool;
        paramPtr9.setAlignedInt(b + -1, b);
        if (b != i2) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    i2 = paramPtr3.getInt();
    b = 1;
    if (1 <= i2)
      while (true) {
        boolean bool;
        int i3 = paramPtr5.getInt();
        byte b1 = 1;
        if (1 <= i3)
          while (true) {
            boolean bool1;
            arrayOfDouble5[b1 + -1] = paramPtr1.getAlignedDouble(b1 * i + j + b);
            if (b1 != i3) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b1++;
            if (!bool1)
              continue; 
            break;
          }  
        Ptr ptr1 = (Ptr)new DoublePtr(arrayOfDouble5, 0);
        Ptr ptr2 = (Ptr)new DoublePtr(arrayOfDouble3, 0);
        Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble7, 0);
        Ptr ptr4 = (Ptr)new DoublePtr(arrayOfDouble6, 0);
        Ptr ptr5 = (Ptr)new DoublePtr(arrayOfDouble8, 0);
        Ptr ptr6 = (Ptr)new DoublePtr(arrayOfDouble4, 0);
        Ptr ptr7 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
        Ptr ptr8 = (Ptr)new DoublePtr(arrayOfDouble2, 0);
        Ptr ptr9 = paramPtr26.pointerPlus((b * k + m) * 8);
        ehg127_(ptr1, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17, paramPtr20, paramPtr21, paramPtr22, ptr2, ptr3, ptr4, ptr5, ptr6, ptr7, ptr8, paramPtr23, paramPtr24, paramPtr25, ptr9);
        if (paramPtr19.getInt() != 1) {
          if (paramPtr19.getInt() == 2) {
            bool = paramPtr4.getInt();
            byte b2 = 1;
            if (true <= bool)
              while (true) {
                boolean bool1;
                paramPtr18.setAlignedDouble(b2 * n + i1 + b, 0.0D);
                if (b2 != bool) {
                  bool1 = false;
                } else {
                  bool1 = true;
                } 
                b2++;
                if (!bool1)
                  continue; 
                break;
              }  
            bool = paramPtr13.getInt();
            b2 = 1;
            if (true <= bool)
              while (true) {
                double d;
                int i4 = paramPtr6.getInt();
                byte b3 = 1;
                if (1 <= i4)
                  while (true) {
                    boolean bool1;
                    paramPtr15.setAlignedDouble(b3 + -1, 0.0D);
                    if (b3 != i4) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    b3++;
                    if (!bool1)
                      continue; 
                    break;
                  }  
                i4 = paramPtr13.getInt();
                b3 = 1;
                if (1 <= i4)
                  while (true) {
                    boolean bool1;
                    paramPtr15.setAlignedDouble(b3 + -1, arrayOfDouble7[b2 * 15 + b3 + -16]);
                    if (b3 != i4) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    b3++;
                    if (!bool1)
                      continue; 
                    break;
                  }  
                Appl.dqrsl_(paramPtr16, paramPtr6, paramPtr6, paramPtr13, (Ptr)new DoublePtr(arrayOfDouble4, 0), paramPtr15, paramPtr15, (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new IntPtr(new int[] { 10000 }, 0), (Ptr)new IntPtr(arrayOfInt, 0));
                if (arrayOfDouble3[b2 + -1] <= arrayOfDouble2[0]) {
                  d = 0.0D;
                } else {
                  d = 1.0D / arrayOfDouble3[b2 + -1];
                } 
                i4 = paramPtr6.getInt();
                b3 = 1;
                if (1 <= i4)
                  while (true) {
                    boolean bool1;
                    paramPtr15.setAlignedDouble(b3 + -1, paramPtr15.getAlignedDouble(b3 + -1) * paramPtr20.getAlignedDouble(b3 + -1) * d);
                    if (b3 != i4) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    b3++;
                    if (!bool1)
                      continue; 
                    break;
                  }  
                i4 = paramPtr6.getInt();
                b3 = 1;
                if (1 <= i4)
                  while (true) {
                    boolean bool1;
                    paramPtr18.setAlignedDouble(paramPtr9.getAlignedInt(b3 + -1) * n + i1 + b, paramPtr18.getAlignedDouble(paramPtr9.getAlignedInt(b3 + -1) * n + i1 + b) + arrayOfDouble6[(b2 + -1) * 15] * paramPtr15.getAlignedDouble(b3 + -1));
                    if (b3 != i4) {
                      bool1 = false;
                    } else {
                      bool1 = true;
                    } 
                    b3++;
                    if (!bool1)
                      continue; 
                    break;
                  }  
                if (b2 != bool) {
                  i4 = 0;
                } else {
                  i4 = 1;
                } 
                b2++;
                if (i4 == 0)
                  continue; 
                break;
              }  
          } 
        } else {
          if (paramPtr3.getInt() != paramPtr4.getInt())
            loessc__.ehg182_((Ptr)new IntPtr(new int[] { 123 }, 0)); 
          bool = true;
          while (paramPtr9.getAlignedInt(bool + -1) != b) {
            if (paramPtr6.getInt() > ++bool)
              continue; 
            loessc__.ehg182_((Ptr)new IntPtr(new int[] { 123 }, 0));
          } 
          int i4 = paramPtr6.getInt();
          int i5 = 1;
          if (1 <= i4)
            while (true) {
              boolean bool1;
              paramPtr15.setAlignedDouble(i5 + -1, 0.0D);
              if (i5 != i4) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              i5++;
              if (!bool1)
                continue; 
              break;
            }  
          paramPtr15.setAlignedDouble(bool + -1, paramPtr20.getAlignedDouble(bool + -1));
          Appl.dqrsl_(paramPtr16, paramPtr6, paramPtr6, paramPtr13, (Ptr)new DoublePtr(arrayOfDouble4, 0), paramPtr15, paramPtr15, paramPtr15, paramPtr15, paramPtr15, paramPtr15, (Ptr)new IntPtr(new int[] { 1000 }, 0), (Ptr)new IntPtr(arrayOfInt, 0));
          bool = paramPtr13.getInt();
          i4 = 1;
          if (true <= bool)
            while (true) {
              arrayOfDouble8[i4 + -1] = 0.0D;
              if (i4 != bool) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i4++;
              if (i5 == 0)
                continue; 
              break;
            }  
          bool = paramPtr13.getInt();
          i4 = 1;
          if (true <= bool)
            while (true) {
              double d = paramPtr15.getAlignedDouble(i4 + -1);
              i5 = paramPtr13.getInt();
              byte b2 = 1;
              if (1 <= i5)
                while (true) {
                  boolean bool1;
                  arrayOfDouble8[b2 + -1] = arrayOfDouble8[b2 + -1] + arrayOfDouble7[b2 * 15 + i4 + -16] * d;
                  if (b2 != i5) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b2++;
                  if (!bool1)
                    continue; 
                  break;
                }  
              if (i4 != bool) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i4++;
              if (i5 == 0)
                continue; 
              break;
            }  
          bool = paramPtr13.getInt();
          i4 = 1;
          if (true <= bool)
            while (true) {
              if (arrayOfDouble3[i4 + -1] <= arrayOfDouble2[0]) {
                arrayOfDouble8[i4 + -1] = 0.0D;
              } else {
                arrayOfDouble8[i4 + -1] = arrayOfDouble8[i4 + -1] / arrayOfDouble3[i4 + -1];
              } 
              if (i4 != bool) {
                i5 = 0;
              } else {
                i5 = 1;
              } 
              i4++;
              if (i5 == 0)
                continue; 
              break;
            }  
          paramPtr18.setAlignedDouble(i1 + n + b, Blas.ddot_(paramPtr13, (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new IntPtr(new int[] { 15 }, 0), (Ptr)new DoublePtr(arrayOfDouble8, 0), (Ptr)new IntPtr(new int[] { 1 }, 0)));
        } 
        if (b != i2) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
  }
  
  public static void ehg137_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    int[] arrayOfInt = new int[20];
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    int j = 0;
    int i = 1;
    paramPtr4.setInt(0);
    while (i) {
      if (paramPtr9.getAlignedInt(i + -1) != 0) {
        if (paramPtr1.getAlignedDouble(paramPtr9.getAlignedInt(i + -1) + -1) != paramPtr10.getAlignedDouble(i + -1)) {
          if (paramPtr1.getAlignedDouble(paramPtr9.getAlignedInt(i + -1) + -1) > paramPtr10.getAlignedDouble(i + -1)) {
            i = paramPtr12.getAlignedInt(i + -1);
            continue;
          } 
          i = paramPtr11.getAlignedInt(i + -1);
          continue;
        } 
        if (++j > 20)
          loessc__.ehg182_((Ptr)new IntPtr(new int[] { 187 }, 0)); 
        arrayOfInt[j + -1] = paramPtr12.getAlignedInt(i + -1);
        i = paramPtr11.getAlignedInt(i + -1);
        continue;
      } 
      paramPtr4.setInt(paramPtr4.getInt() + 1);
      paramPtr3.setAlignedInt(paramPtr4.getInt() + -1, i);
      if (j <= 0) {
        i = 0;
      } else {
        i = arrayOfInt[j + -1];
      } 
      int k = 0;
      if (--j > 0)
        k = j; 
      j = k;
    } 
    if (paramPtr4.getInt() > 256)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 185 }, 0)); 
  }
  
  public static int ehg138_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr7.getInt(), 0));
    int i = paramPtr1.getInt();
    while (true) {
      boolean bool;
      if (paramPtr3.getAlignedInt(i + -1) == 0) {
        bool = false;
      } else {
        if (paramPtr2.getAlignedDouble(paramPtr3.getAlignedInt(i + -1) + -1) == paramPtr4.getAlignedDouble(i + -1)) {
          bool = false;
        } else {
          bool = true;
        } 
        bool = bool;
      } 
      if ((bool ^ true) == 0) {
        if (paramPtr2.getAlignedDouble(paramPtr3.getAlignedInt(i + -1) + -1) > paramPtr4.getAlignedDouble(i + -1)) {
          i = paramPtr6.getAlignedInt(i + -1);
          continue;
        } 
        i = paramPtr5.getAlignedInt(i + -1);
        continue;
      } 
      return i;
    } 
  }
  
  public static void ehg139_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27, Ptr paramPtr28, Ptr paramPtr29, Ptr paramPtr30, Ptr paramPtr31, Ptr paramPtr32, Ptr paramPtr33, Ptr paramPtr34, Ptr paramPtr35, Ptr paramPtr36, Ptr paramPtr37, Ptr paramPtr38, Ptr paramPtr39, Ptr paramPtr40) {
    double[] arrayOfDouble1 = new double[8];
    double[] arrayOfDouble2 = new double[15];
    double[] arrayOfDouble3 = new double[225];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[15];
    double[] arrayOfDouble6 = new double[15];
    double[] arrayOfDouble7 = new double[8];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[256];
    int[] arrayOfInt3 = new int[1];
    double[] arrayOfDouble8 = new double[225];
    double[] arrayOfDouble9 = new double[15];
    arrayOfDouble4[0] = 0.0D;
    arrayOfInt1[0] = 0;
    arrayOfInt3[0] = 0;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int i = Math.max(paramPtr5.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr3.getInt(), 0));
    int j = -i;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int k = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr5.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int n = Math.max(paramPtr4.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr5.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr6.getInt(), 0) * paramPtr15.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr6.getInt(), 0));
    int i2 = Math.max(paramPtr20.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(i2 * paramPtr3.getInt(), 0));
    int i3 = -i2;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr24.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr24.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr24.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr24.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr25.getInt(), 0) * paramPtr24.getInt(), 0));
    int i4 = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i4 * paramPtr6.getInt(), 0));
    int i5 = i4 ^ 0xFFFFFFFF;
    int i6 = Math.max(paramPtr5.getInt() + 1, 0);
    int i7 = Math.max(i6 * paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i7 * paramPtr6.getInt(), 0));
    int i8 = -i6 - i7;
    if (paramPtr15.getInt() > paramPtr6.getInt() + -1)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 104 }, 0)); 
    if (paramPtr15.getInt() > 15)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 105 }, 0)); 
    if (paramPtr13.getDouble() != 0.0D) {
      int i10 = paramPtr4.getInt();
      byte b1 = 1;
      if (1 <= i10)
        while (true) {
          boolean bool;
          paramPtr22.setAlignedDouble(b1 + -1, 0.0D);
          if (b1 != i10) {
            bool = false;
          } else {
            bool = true;
          } 
          b1++;
          if (!bool)
            continue; 
          break;
        }  
      i10 = paramPtr3.getInt();
      b1 = 1;
      if (1 <= i10)
        while (true) {
          int i11 = paramPtr5.getInt();
          byte b2 = 0;
          if (i11 >= 0)
            while (true) {
              boolean bool;
              paramPtr23.setAlignedDouble(b1 * i + j + b2, 0.0D);
              if (b2 != i11) {
                bool = false;
              } else {
                bool = true;
              } 
              b2++;
              if (!bool)
                continue; 
              break;
            }  
          if (b1 != i10) {
            i11 = 0;
          } else {
            i11 = 1;
          } 
          b1++;
          if (i11 == 0)
            continue; 
          break;
        }  
    } 
    int i9 = paramPtr4.getInt();
    byte b = 1;
    if (1 <= i9)
      while (true) {
        boolean bool;
        paramPtr10.setAlignedInt(b + -1, b);
        if (b != i9) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    i9 = paramPtr3.getInt();
    b = 1;
    if (1 <= i9)
      while (true) {
        boolean bool;
        int i10 = paramPtr5.getInt();
        byte b1 = 1;
        if (1 <= i10)
          while (true) {
            boolean bool1;
            arrayOfDouble7[b1 + -1] = paramPtr1.getAlignedDouble(b1 * k + m + b);
            if (b1 != i10) {
              bool1 = false;
            } else {
              bool1 = true;
            } 
            b1++;
            if (!bool1)
              continue; 
            break;
          }  
        Ptr ptr2 = (Ptr)new DoublePtr(arrayOfDouble7, 0);
        Ptr ptr3 = (Ptr)new DoublePtr(arrayOfDouble5, 0);
        Ptr ptr4 = (Ptr)new DoublePtr(arrayOfDouble3, 0);
        Ptr ptr5 = (Ptr)new DoublePtr(arrayOfDouble8, 0);
        Ptr ptr1 = (Ptr)new DoublePtr(arrayOfDouble9, 0);
        Ptr ptr6 = (Ptr)new DoublePtr(arrayOfDouble6, 0);
        Ptr ptr7 = (Ptr)new DoublePtr(arrayOfDouble2, 0);
        Ptr ptr8 = (Ptr)new DoublePtr(arrayOfDouble4, 0);
        Ptr ptr9 = paramPtr40.pointerPlus((b * i2 + i3) * 8);
        ehg127_(ptr2, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, paramPtr10, paramPtr11, paramPtr12, paramPtr14, paramPtr15, paramPtr16, paramPtr18, paramPtr19, paramPtr20, paramPtr21, paramPtr32, paramPtr33, ptr3, ptr4, ptr5, ptr1, ptr6, ptr7, ptr8, paramPtr34, paramPtr35, paramPtr36, ptr9);
        if (paramPtr13.getDouble() != 0.0D) {
          int i11 = paramPtr4.getInt();
          byte b3 = 1;
          if (1 <= i11)
            while (true) {
              boolean bool1;
              paramPtr17.setAlignedDouble(b3 + -1, 0.0D);
              if (b3 != i11) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b3++;
              if (!bool1)
                continue; 
              break;
            }  
          i11 = paramPtr6.getInt();
          b3 = 1;
          if (1 <= i11)
            while (true) {
              boolean bool1;
              paramPtr17.setAlignedDouble(paramPtr10.getAlignedInt(b3 + -1) + -1, b3);
              if (b3 != i11) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b3++;
              if (!bool1)
                continue; 
              break;
            }  
          i11 = paramPtr5.getInt();
          b3 = 1;
          if (1 <= i11)
            while (true) {
              boolean bool1;
              arrayOfDouble1[b3 + -1] = paramPtr1.getAlignedDouble(b3 * k + m + b);
              if (b3 != i11) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b3++;
              if (!bool1)
                continue; 
              break;
            }  
          Ptr ptr10 = (Ptr)new DoublePtr(arrayOfDouble1, 0);
          Ptr ptr11 = paramPtr31.pointerPlus((b + -1) * 4);
          ehg137_(ptr10, ptr11, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr5, paramPtr3, paramPtr2, paramPtr24, paramPtr26, paramPtr27, paramPtr28, paramPtr29);
          bool = arrayOfInt1[0];
          byte b2 = 1;
          if (true <= bool)
            while (true) {
              int i12 = paramPtr29.getAlignedInt(arrayOfInt2[b2 + -1] + -1);
              int i13;
              if ((i13 = paramPtr28.getAlignedInt(arrayOfInt2[b2 + -1] + -1)) <= i12)
                while (true) {
                  int i14 = (int)paramPtr17.getAlignedDouble(paramPtr9.getAlignedInt(i13 + -1) + -1);
                  if (i14 != 0) {
                    if (paramPtr10.getAlignedInt(i14 + -1) != paramPtr9.getAlignedInt(i13 + -1))
                      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 194 }, 0)); 
                    int i15 = paramPtr6.getInt();
                    byte b4 = 1;
                    if (1 <= i15)
                      while (true) {
                        boolean bool1;
                        paramPtr18.setAlignedDouble(b4 + -1, 0.0D);
                        if (b4 != i15) {
                          bool1 = false;
                        } else {
                          bool1 = true;
                        } 
                        b4++;
                        if (!bool1)
                          continue; 
                        break;
                      }  
                    paramPtr18.setAlignedDouble(i14 + -1, paramPtr21.getAlignedDouble(i14 + -1));
                    Appl.dqrsl_(paramPtr19, paramPtr6, paramPtr6, paramPtr15, (Ptr)new DoublePtr(arrayOfDouble6, 0), paramPtr18, (Ptr)new DoublePtr(arrayOfDouble2, 0), paramPtr18, paramPtr18, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(new int[] { 1000 }, 0), (Ptr)new IntPtr(arrayOfInt3, 0));
                    i14 = paramPtr15.getInt();
                    i15 = 1;
                    if (1 <= i14)
                      while (true) {
                        double d1;
                        if (arrayOfDouble5[i15 + -1] <= arrayOfDouble4[0]) {
                          d1 = 0.0D;
                        } else {
                          d1 = Blas.ddot_(paramPtr15, (Ptr)new DoublePtr(arrayOfDouble3, (i15 + -1) * 15), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr18, (Ptr)new IntPtr(new int[] { 1 }, 0)) / arrayOfDouble5[i15 + -1];
                        } 
                        arrayOfDouble9[i15 + -1] = d1;
                        if (i15 != i14) {
                          b4 = 0;
                        } else {
                          b4 = 1;
                        } 
                        i15++;
                        if (b4 == 0)
                          continue; 
                        break;
                      }  
                    i14 = paramPtr5.getInt() + 1;
                    i15 = 1;
                    if (1 <= i14)
                      while (true) {
                        if (paramPtr15.getInt() < i15) {
                          paramPtr23.setAlignedDouble(b * i + j + i15 + -1, 0.0D);
                        } else {
                          paramPtr23.setAlignedDouble(b * i + j + i15 + -1, Blas.ddot_(paramPtr15, (Ptr)new DoublePtr(arrayOfDouble8, i15 + -1), (Ptr)new IntPtr(new int[] { 15 }, 0), (Ptr)new DoublePtr(arrayOfDouble9, 0), (Ptr)new IntPtr(new int[] { 1 }, 0)));
                        } 
                        if (i15 != i14) {
                          b4 = 0;
                        } else {
                          b4 = 1;
                        } 
                        i15++;
                        if (b4 == 0)
                          continue; 
                        break;
                      }  
                    i14 = paramPtr5.getInt();
                    i15 = 1;
                    if (1 <= i14)
                      while (true) {
                        arrayOfDouble1[i15 + -1] = paramPtr8.getAlignedDouble(i15 * n + i1 + paramPtr9.getAlignedInt(i13 + -1));
                        if (i15 != i14) {
                          b4 = 0;
                        } else {
                          b4 = 1;
                        } 
                        i15++;
                        if (b4 == 0)
                          continue; 
                        break;
                      }  
                    i14 = paramPtr9.getAlignedInt(i13 + -1) + -1;
                    double d = ehg128_((Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr5, paramPtr24, paramPtr25, paramPtr26, paramPtr27, paramPtr28, paramPtr29, paramPtr30, paramPtr1, paramPtr2, paramPtr23) + paramPtr22.getAlignedDouble(paramPtr9.getAlignedInt(i13 + -1) + -1);
                    paramPtr22.setAlignedDouble(i14, d);
                    i14 = paramPtr5.getInt();
                    i15 = 0;
                    if (i14 >= 0)
                      while (true) {
                        paramPtr23.setAlignedDouble(b * i + j + i15, 0.0D);
                        if (i15 != i14) {
                          b4 = 0;
                        } else {
                          b4 = 1;
                        } 
                        i15++;
                        if (b4 == 0)
                          continue; 
                        break;
                      }  
                  } 
                  if (i13 != i12) {
                    i14 = 0;
                  } else {
                    i14 = 1;
                  } 
                  i13++;
                  if (i14 == 0)
                    continue; 
                  break;
                }  
              if (b2 != bool) {
                i12 = 0;
              } else {
                i12 = 1;
              } 
              b2++;
              if (i12 == 0)
                continue; 
              break;
            }  
        } 
        if (paramPtr39.getBoolean()) {
          if (paramPtr15.getInt() < paramPtr5.getInt() + 1)
            loessc__.ehg182_((Ptr)new IntPtr(new int[] { 196 }, 0)); 
          bool = paramPtr6.getInt();
          byte b2 = 1;
          if (true <= bool)
            while (true) {
              boolean bool1;
              paramPtr37.setAlignedInt(b2 * i4 + i5 + b, paramPtr10.getAlignedInt(b2 + -1));
              if (b2 != bool) {
                bool1 = false;
              } else {
                bool1 = true;
              } 
              b2++;
              if (!bool1)
                continue; 
              break;
            }  
          bool = paramPtr6.getInt();
          b2 = 1;
          if (true <= bool)
            while (true) {
              int i11 = paramPtr5.getInt();
              byte b3 = 0;
              if (i11 >= 0)
                while (true) {
                  boolean bool1;
                  paramPtr38.setAlignedDouble(b2 * i7 + i8 + b * i6 + b3, 0.0D);
                  if (b3 != i11) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b3++;
                  if (!bool1)
                    continue; 
                  break;
                }  
              if (b2 != bool) {
                i11 = 0;
              } else {
                i11 = 1;
              } 
              b2++;
              if (i11 == 0)
                continue; 
              break;
            }  
          bool = paramPtr15.getInt();
          b2 = 1;
          if (true <= bool)
            while (true) {
              double d;
              int i11 = paramPtr6.getInt();
              byte b3 = 1;
              if (1 <= i11)
                while (true) {
                  boolean bool1;
                  paramPtr18.setAlignedDouble(b3 + -1, 0.0D);
                  if (b3 != i11) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b3++;
                  if (!bool1)
                    continue; 
                  break;
                }  
              i11 = paramPtr15.getInt();
              b3 = 1;
              if (1 <= i11)
                while (true) {
                  boolean bool1;
                  paramPtr18.setAlignedDouble(b3 + -1, arrayOfDouble3[b2 * 15 + b3 + -16]);
                  if (b3 != i11) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b3++;
                  if (!bool1)
                    continue; 
                  break;
                }  
              Appl.dqrsl_(paramPtr19, paramPtr6, paramPtr6, paramPtr15, (Ptr)new DoublePtr(arrayOfDouble6, 0), paramPtr18, paramPtr18, (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(new int[] { 10000 }, 0), (Ptr)new IntPtr(arrayOfInt3, 0));
              if (arrayOfDouble5[b2 + -1] <= arrayOfDouble4[0]) {
                d = 0.0D;
              } else {
                d = 1.0D / arrayOfDouble5[b2 + -1];
              } 
              i11 = paramPtr6.getInt();
              b3 = 1;
              if (1 <= i11)
                while (true) {
                  boolean bool1;
                  paramPtr18.setAlignedDouble(b3 + -1, paramPtr18.getAlignedDouble(b3 + -1) * paramPtr21.getAlignedDouble(b3 + -1) * d);
                  if (b3 != i11) {
                    bool1 = false;
                  } else {
                    bool1 = true;
                  } 
                  b3++;
                  if (!bool1)
                    continue; 
                  break;
                }  
              i11 = paramPtr6.getInt();
              b3 = 1;
              if (1 <= i11)
                while (true) {
                  d = paramPtr18.getAlignedDouble(b3 + -1);
                  int i12 = paramPtr5.getInt();
                  byte b4 = 0;
                  if (i12 >= 0)
                    while (true) {
                      boolean bool1;
                      if (paramPtr15.getInt() <= b4) {
                        paramPtr38.setAlignedDouble(b3 * i7 + i8 + b * i6 + b4, 0.0D);
                      } else {
                        paramPtr38.setAlignedDouble(b3 * i7 + i8 + b * i6 + b4, paramPtr38.getAlignedDouble(b3 * i7 + i8 + b * i6 + b4) + arrayOfDouble8[b2 * 15 + b4 + 1 + -16] * d);
                      } 
                      if (b4 != i12) {
                        bool1 = false;
                      } else {
                        bool1 = true;
                      } 
                      b4++;
                      if (!bool1)
                        continue; 
                      break;
                    }  
                  if (b3 != i11) {
                    i12 = 0;
                  } else {
                    i12 = 1;
                  } 
                  b3++;
                  if (i12 == 0)
                    continue; 
                  break;
                }  
              if (b2 != bool) {
                i11 = 0;
              } else {
                i11 = 1;
              } 
              b2++;
              if (i11 == 0)
                continue; 
              break;
            }  
        } 
        if (b != i9) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
    if (paramPtr13.getDouble() != 0.0D) {
      if (paramPtr4.getInt() > 0) {
        int i10 = paramPtr4.getInt() + -1;
        double d = paramPtr22.getAlignedDouble(i10);
        i10 = paramPtr4.getInt() + -1;
        if (i10 > 0)
          while (true) {
            boolean bool;
            d = paramPtr22.getAlignedDouble(i10 + -1) + d;
            if (i10 != 1) {
              bool = false;
            } else {
              bool = true;
            } 
            i10--;
            if (!bool)
              continue; 
            break;
          }  
        paramPtr13.setDouble(d);
        return;
      } 
      paramPtr13.setDouble(0.0D);
    } 
  }
  
  public static void ehg140_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    paramPtr1.setAlignedInt(paramPtr2.getInt() + -1, paramPtr3.getInt());
  }
  
  public static void ehg141_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    boolean bool;
    double d6;
    double d7;
    double[] arrayOfDouble = new double[1];
    if (paramPtr3.getInt() == 0)
      paramPtr7.setInt(1); 
    if (paramPtr3.getInt() == 1)
      paramPtr7.setInt(paramPtr5.getInt() + 1); 
    if (paramPtr3.getInt() == 2)
      paramPtr7.setInt((int)(((paramPtr5.getInt() + 2) * (paramPtr5.getInt() + 1)) / 2.0D)); 
    double d1 = Mathlib.sqrt(paramPtr4.getInt() / paramPtr2.getInt());
    double d2 = (Mathlib.sqrt(paramPtr4.getInt() / paramPtr1.getDouble()) - d1) / (1.0D - d1);
    if (paramPtr6.getInt() == 0 && d2 > 1.0D)
      ehg184_((Ptr)new BytePtr("Chernobyl! trL<k".getBytes(), 0), paramPtr1, (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 16); 
    if (d2 < 0.0D)
      ehg184_((Ptr)new BytePtr("Chernobyl! trL>n".getBytes(), 0), paramPtr1, (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 16); 
    d1 = 0.0D;
    if (d2 <= 0.0D) {
      j = 0;
    } else {
      j = 1;
    } 
    int j = j;
    if (!Double.isNaN(0.0D) && !Double.isNaN(0.0D)) {
      bool = false;
    } else {
      bool = true;
    } 
    if ((j | bool & true) != 0)
      d1 = d2; 
    double d4 = 1.0D;
    if (d1 >= 1.0D) {
      j = 0;
    } else {
      j = 1;
    } 
    j = j;
    if (!Double.isNaN(1.0D) && !Double.isNaN(1.0D)) {
      bool = false;
    } else {
      bool = true;
    } 
    if ((j | bool & true) != 0)
      d4 = d1; 
    d2 = d4;
    arrayOfDouble[0] = d4;
    d1 = Math.exp(ehg176_((Ptr)new DoublePtr(arrayOfDouble, 0)));
    j = paramPtr5.getInt();
    if (j > 4)
      j = 4; 
    int i = (j + -1) * 3 + (paramPtr3.getInt() + -1) * 12 + 1;
    if (paramPtr5.getInt() > 4) {
      d5 = $ehg141_$c[i + -1] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i + -1] - $ehg141_$c[i + -4]);
      d6 = $ehg141_$c[i] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i] - $ehg141_$c[i + -3]);
      d7 = $ehg141_$c[i + 1] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i + 1] - $ehg141_$c[i + -2]);
    } else {
      d5 = $ehg141_$c[i + -1];
      d6 = $ehg141_$c[i];
      d7 = $ehg141_$c[i + 1];
    } 
    d4 = paramPtr2.getInt();
    double d3 = paramPtr1.getDouble();
    double d5 = Mathlib.pow(d2, d6) * d5;
    d3 = Math.exp(Mathlib.pow(1.0D - d2, d7) * d5 * d1) * d3;
    paramPtr8.setDouble(d4 - d3);
    i += 24;
    if (paramPtr5.getInt() > 4) {
      d5 = $ehg141_$c[i + -1] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i + -1] - $ehg141_$c[i + -4]);
      d6 = $ehg141_$c[i] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i] - $ehg141_$c[i + -3]);
      d7 = $ehg141_$c[i + 1] + (paramPtr5.getInt() + -4) * ($ehg141_$c[i + 1] - $ehg141_$c[i + -2]);
    } else {
      d5 = $ehg141_$c[i + -1];
      d6 = $ehg141_$c[i];
      d7 = $ehg141_$c[i + 1];
    } 
    d4 = paramPtr2.getInt();
    d3 = paramPtr1.getDouble();
    d2 = Mathlib.pow(d2, d6) * d5;
    d1 = Math.exp(Mathlib.pow(1.0D - d2, d7) * d2 * d1) * d3;
    paramPtr9.setDouble(d4 - d1);
  }
  
  public static void ehg169_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    arrayOfInt5[0] = 0;
    int k = Math.max(paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr1.getInt(), 0));
    int m = k ^ 0xFFFFFFFF;
    int n = Math.max(paramPtr2.getInt(), 0);
    Integer.toUnsignedLong(Math.max(n * paramPtr4.getInt(), 0));
    int i1 = n ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int j = paramPtr2.getInt() + -1;
    byte b2 = 2;
    if (2 <= j)
      while (true) {
        int i2 = b2 + -1;
        int i3 = paramPtr1.getInt();
        arrayOfInt6[0] = 1;
        if (arrayOfInt6[0] <= i3)
          while (true) {
            boolean bool;
            paramPtr7.setAlignedDouble(arrayOfInt6[0] * k + m + b2, paramPtr7.getAlignedDouble(arrayOfInt6[0] * k + m + i2 % 2 * (paramPtr2.getInt() + -1) + 1));
            arrayOfDouble[0] = i2 / 2.0D;
            i2 = ifloor_((Ptr)new DoublePtr(arrayOfDouble, 0));
            if (arrayOfInt6[0] != i3) {
              bool = false;
            } else {
              bool = true;
            } 
            arrayOfInt6[0] = arrayOfInt6[0] + 1;
            if (!bool)
              continue; 
            break;
          }  
        if (b2 != j) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        b2++;
        if (i2 == 0)
          continue; 
        break;
      }  
    j = 1;
    arrayOfInt5[0] = paramPtr2.getInt();
    arrayOfInt4[0] = -1;
    int i = paramPtr2.getInt();
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        paramPtr10.setAlignedInt(1 * n + i1 + b1, b1);
        if (b1 != i) {
          k = 0;
        } else {
          k = 1;
        } 
        b1++;
        if (k == 0)
          continue; 
        break;
      }  
    arrayOfInt3[0] = 1;
    while (paramPtr3.getInt() >= arrayOfInt3[0]) {
      if (paramPtr8.getAlignedInt(arrayOfInt3[0] + -1) != 0) {
        arrayOfInt6[0] = paramPtr8.getAlignedInt(arrayOfInt3[0] + -1);
        i = j + 1;
        paramPtr12.setAlignedInt(arrayOfInt3[0] + -1, i);
        j = i + 1;
        paramPtr11.setAlignedInt(arrayOfInt3[0] + -1, j);
        arrayOfInt1[0] = Builtins._gfortran_pow_i4_i4(2, arrayOfInt6[0] + -1);
        arrayOfInt2[0] = Builtins._gfortran_pow_i4_i4(2, paramPtr1.getInt() - arrayOfInt6[0]);
        Ptr ptr1 = (Ptr)new IntPtr(arrayOfInt3, 0);
        Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt5, 0);
        Ptr ptr3 = (Ptr)new IntPtr(arrayOfInt4, 0);
        Ptr ptr4 = (Ptr)new IntPtr(arrayOfInt6, 0);
        Ptr ptr5 = paramPtr9.pointerPlus((arrayOfInt3[0] + -1) * 8);
        Ptr ptr6 = (Ptr)new IntPtr(arrayOfInt1, 0);
        Ptr ptr7 = (Ptr)new IntPtr(arrayOfInt2, 0);
        Ptr ptr8 = paramPtr10.pointerPlus((arrayOfInt3[0] * n + i1 + 1) * 4);
        Ptr ptr9 = paramPtr10.pointerPlus((paramPtr12.getAlignedInt(arrayOfInt3[0] + -1) * n + i1 + 1) * 4);
        Ptr ptr10 = paramPtr10.pointerPlus((paramPtr11.getAlignedInt(arrayOfInt3[0] + -1) * n + i1 + 1) * 4);
        ehg125_(ptr1, ptr2, paramPtr7, ptr3, paramPtr6, paramPtr1, ptr4, ptr5, ptr6, ptr7, ptr8, ptr9, ptr10);
      } 
      arrayOfInt3[0] = arrayOfInt3[0] + 1;
    } 
    if (paramPtr3.getInt() != j)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 193 }, 0)); 
    if (paramPtr5.getInt() != arrayOfInt5[0])
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 193 }, 0)); 
  }
  
  public static double ehg176_(Ptr paramPtr) {
    return ehg128_(paramPtr, (Ptr)new IntPtr($ehg176_$d, 0), (Ptr)new IntPtr($ehg176_$nc, 0), (Ptr)new IntPtr($ehg176_$vc, 0), (Ptr)new IntPtr($ehg176_$a, 0), (Ptr)new DoublePtr($ehg176_$xi, 0), (Ptr)new IntPtr($ehg176_$lo, 0), (Ptr)new IntPtr($ehg176_$hi, 0), (Ptr)new IntPtr($ehg176_$c, 0), (Ptr)new DoublePtr($ehg176_$v, 0), (Ptr)new IntPtr($ehg176_$nv, 0), (Ptr)new DoublePtr($ehg176_$vval, 0));
  }
  
  public static void ehg183_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt) {
    int[] arrayOfInt = new int[1];
    Integer.toUnsignedLong(paramInt);
    arrayOfInt[0] = paramInt;
    loessc__.ehg183a_(paramPtr1, (Ptr)new IntPtr(arrayOfInt, 0), paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void ehg184_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt) {
    int[] arrayOfInt = new int[1];
    Integer.toUnsignedLong(paramInt);
    arrayOfInt[0] = paramInt;
    loessc__.ehg184a_(paramPtr1, (Ptr)new IntPtr(arrayOfInt, 0), paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static void ehg191_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19) {
    double[] arrayOfDouble = new double[8];
    int j = Math.max(paramPtr4.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr16.getInt(), 0));
    int k = -j;
    int m = Math.max(paramPtr16.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr6.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    int i1 = Math.max(paramPtr4.getInt() + 1, 0);
    int i2 = Math.max(i1 * paramPtr16.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i2 * paramPtr6.getInt(), 0));
    int i3 = -i1 - i2;
    int i4 = Math.max(paramPtr1.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i4 * paramPtr4.getInt(), 0));
    int i5 = i4 ^ 0xFFFFFFFF;
    int i6 = Math.max(paramPtr1.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i6 * paramPtr5.getInt(), 0));
    int i7 = i6 ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr9.getInt(), 0) * paramPtr8.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr16.getInt(), 0) * paramPtr4.getInt(), 0));
    int i = paramPtr5.getInt();
    byte b = 1;
    if (1 <= i)
      while (true) {
        int i8 = paramPtr7.getInt();
        byte b1 = 1;
        if (1 <= i8)
          while (true) {
            int i9 = paramPtr4.getInt();
            byte b2 = 0;
            if (i9 >= 0)
              while (true) {
                boolean bool;
                paramPtr17.setAlignedDouble(b1 * j + k + b2, 0.0D);
                if (b2 != i9) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b2++;
                if (!bool)
                  continue; 
                break;
              }  
            if (b1 != i8) {
              i9 = 0;
            } else {
              i9 = 1;
            } 
            b1++;
            if (i9 == 0)
              continue; 
            break;
          }  
        i8 = paramPtr7.getInt();
        b1 = 1;
        if (1 <= i8)
          while (true) {
            int i10 = paramPtr19.getAlignedInt(n + m + b1);
            paramPtr19.setAlignedInt(n + m + b1, b);
            int i9;
            for (i9 = paramPtr6.getInt(); paramPtr19.getAlignedInt(i9 * m + n + b1) != b; i9--);
            paramPtr19.setAlignedInt(n + m + b1, i10);
            if (paramPtr19.getAlignedInt(i9 * m + n + b1) == b) {
              i10 = paramPtr4.getInt();
              byte b2 = 0;
              if (i10 >= 0)
                while (true) {
                  boolean bool;
                  paramPtr17.setAlignedDouble(b1 * j + k + b2, paramPtr18.getAlignedDouble(i9 * i2 + i3 + b1 * i1 + b2));
                  if (b2 != i10) {
                    bool = false;
                  } else {
                    bool = true;
                  } 
                  b2++;
                  if (!bool)
                    continue; 
                  break;
                }  
            } 
            if (b1 != i8) {
              i9 = 0;
            } else {
              i9 = 1;
            } 
            b1++;
            if (i9 == 0)
              continue; 
            break;
          }  
        i8 = paramPtr1.getInt();
        b1 = 1;
        if (1 <= i8)
          while (true) {
            int i9 = paramPtr4.getInt();
            byte b2 = 1;
            if (1 <= i9)
              while (true) {
                boolean bool;
                arrayOfDouble[b2 + -1] = paramPtr2.getAlignedDouble(b2 * i4 + i5 + b1);
                if (b2 != i9) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b2++;
                if (!bool)
                  continue; 
                break;
              }  
            paramPtr3.setAlignedDouble(b * i6 + i7 + b1, ehg128_((Ptr)new DoublePtr(arrayOfDouble, 0), paramPtr4, paramPtr8, paramPtr9, paramPtr10, paramPtr11, paramPtr12, paramPtr13, paramPtr14, paramPtr15, paramPtr16, paramPtr17));
            if (b1 != i8) {
              i9 = 0;
            } else {
              i9 = 1;
            } 
            b1++;
            if (i9 == 0)
              continue; 
            break;
          }  
        if (b != i) {
          i8 = 0;
        } else {
          i8 = 1;
        } 
        b++;
        if (i8 == 0)
          continue; 
        break;
      }  
  }
  
  public static void ehg192_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    int m = Math.max(paramPtr2.getInt() + 1, 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr6.getInt(), 0));
    int n = -m;
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    int i = Math.max(paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr4.getInt(), 0));
    int i1 = i ^ 0xFFFFFFFF;
    int i2 = Math.max(paramPtr2.getInt() + 1, 0);
    int k = Math.max(i2 * paramPtr6.getInt(), 0);
    Integer.toUnsignedLong(Math.max(k * paramPtr4.getInt(), 0));
    int i3 = -i2 - k;
    int i4 = paramPtr5.getInt();
    int i5 = 1;
    if (1 <= i4)
      while (true) {
        int i6 = paramPtr2.getInt();
        byte b = 0;
        if (i6 >= 0)
          while (true) {
            boolean bool;
            paramPtr7.setAlignedDouble(i5 * m + n + b, 0.0D);
            if (b != i6) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        if (i5 != i4) {
          i6 = 0;
        } else {
          i6 = 1;
        } 
        i5++;
        if (i6 == 0)
          continue; 
        break;
      }  
    int j = paramPtr5.getInt();
    i4 = 1;
    if (1 <= j)
      while (true) {
        i5 = paramPtr4.getInt();
        byte b = 1;
        if (1 <= i5)
          while (true) {
            double d = paramPtr1.getAlignedDouble(paramPtr9.getAlignedInt(b * i + i1 + i4) + -1);
            int i6 = paramPtr2.getInt();
            byte b1 = 0;
            if (i6 >= 0)
              while (true) {
                boolean bool;
                paramPtr7.setAlignedDouble(i4 * m + n + b1, paramPtr7.getAlignedDouble(i4 * m + n + b1) + paramPtr8.getAlignedDouble(b * k + i3 + i4 * i2 + b1) * d);
                if (b1 != i6) {
                  bool = false;
                } else {
                  bool = true;
                } 
                b1++;
                if (!bool)
                  continue; 
                break;
              }  
            if (b != i5) {
              i6 = 0;
            } else {
              i6 = 1;
            } 
            b++;
            if (i6 == 0)
              continue; 
            break;
          }  
        if (i4 != j) {
          i5 = 0;
        } else {
          i5 = 1;
        } 
        i4++;
        if (i5 == 0)
          continue; 
        break;
      }  
  }
  
  public static void ehg196_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    ehg197_((Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr1, paramPtr2, paramPtr3, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    ehg197_((Ptr)new IntPtr(new int[] { 2 }, 0), paramPtr1, paramPtr2, paramPtr3, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    double d = (paramPtr1.getInt() - arrayOfInt2[0]) / (arrayOfInt1[0] - arrayOfInt2[0]);
    paramPtr4.setDouble((1.0D - d) * arrayOfDouble2[0] + d * arrayOfDouble1[0]);
  }
  
  public static void ehg197_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    boolean bool2;
    paramPtr5.setInt(0);
    if (paramPtr1.getInt() == 1)
      paramPtr5.setInt(paramPtr3.getInt() + 1); 
    if (paramPtr1.getInt() == 2)
      paramPtr5.setInt((int)(((paramPtr3.getInt() + 2) * (paramPtr3.getInt() + 1)) / 2.0D)); 
    double d2 = 0.0D;
    double d1 = ((0.13D - paramPtr3.getInt() * 0.08125D) * paramPtr3.getInt() + 1.05D - paramPtr4.getDouble()) / paramPtr4.getDouble();
    if (d1 <= 0.0D) {
      bool1 = false;
    } else {
      bool1 = true;
    } 
    boolean bool1 = bool1;
    if (!Double.isNaN(0.0D) && !Double.isNaN(0.0D)) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    if ((bool1 | bool2 & true) != 0)
      d2 = d1; 
    paramPtr6.setDouble(paramPtr5.getInt() * (d2 + 1.0D));
  }
  
  static void hi$3679$$clinit() {
    int[] arrayOfInt = new int[17];
    arrayOfInt[0] = 3;
    arrayOfInt[1] = 5;
    arrayOfInt[2] = 7;
    arrayOfInt[3] = 9;
    arrayOfInt[4] = 11;
    arrayOfInt[5] = 13;
    arrayOfInt[6] = 15;
    arrayOfInt[7] = 17;
    System.arraycopy(arrayOfInt, 0, hi$3679, 0, 17);
  }
  
  public static int ifloor_(Ptr paramPtr) {
    int i = (int)paramPtr.getDouble();
    if (i > paramPtr.getDouble())
      i--; 
    return i;
  }
  
  static void lo$3681$$clinit() {
    int[] arrayOfInt = new int[17];
    arrayOfInt[0] = 2;
    arrayOfInt[1] = 4;
    arrayOfInt[2] = 6;
    arrayOfInt[3] = 8;
    arrayOfInt[4] = 10;
    arrayOfInt[5] = 12;
    arrayOfInt[6] = 14;
    arrayOfInt[7] = 16;
    System.arraycopy(arrayOfInt, 0, lo$3681, 0, 17);
  }
  
  public static void lowesa_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    arrayOfDouble1[0] = 0.0D;
    arrayOfDouble2[0] = 0.0D;
    arrayOfDouble3[0] = 0.0D;
    arrayOfDouble4[0] = 0.0D;
    ehg141_(paramPtr1, paramPtr2, (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr4, paramPtr3, paramPtr5, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0));
    ehg141_(paramPtr1, paramPtr2, (Ptr)new IntPtr(new int[] { 2 }, 0), paramPtr4, paramPtr3, paramPtr5, (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0));
    double d = (paramPtr4.getInt() - arrayOfInt2[0]) / (arrayOfInt1[0] - arrayOfInt2[0]);
    paramPtr6.setDouble((1.0D - d) * arrayOfDouble4[0] + d * arrayOfDouble3[0]);
    paramPtr7.setDouble((1.0D - d) * arrayOfDouble2[0] + d * arrayOfDouble1[0]);
  }
  
  public static void lowesb_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    boolean bool;
    double[] arrayOfDouble1 = new double[1];
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble2 = new double[1];
    boolean[] arrayOfBoolean = new boolean[1];
    if (paramPtr6.getAlignedInt(27) == 173)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 174 }, 0)); 
    if (paramPtr6.getAlignedInt(27) != 172 && paramPtr6.getAlignedInt(27) != 171)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 171 }, 0)); 
    paramPtr6.setAlignedInt(27, 173);
    if (!paramPtr5.getBoolean()) {
      arrayOfDouble2[0] = 0.0D;
    } else {
      arrayOfDouble2[0] = 1.0D;
    } 
    if (paramPtr6.getAlignedInt(26) == paramPtr6.getAlignedInt(24)) {
      bool = false;
    } else {
      bool = true;
    } 
    arrayOfBoolean[0] = bool;
    arrayOfDouble1[0] = paramPtr6.getAlignedInt(2) * paramPtr9.getAlignedDouble(1);
    arrayOfInt[0] = ifloor_((Ptr)new DoublePtr(arrayOfDouble1, 0));
    paramPtr1 = (Ptr)new DoublePtr(arrayOfDouble2, 0);
    paramPtr2 = paramPtr6.pointerPlus(76);
    paramPtr3 = paramPtr6.pointerPlus(112);
    Ptr ptr1 = paramPtr6.pointerPlus(8);
    Ptr ptr2 = paramPtr6.pointerPlus(4);
    Ptr ptr4 = paramPtr6.pointerPlus(16);
    Ptr ptr5 = paramPtr6.pointerPlus(64);
    Ptr ptr6 = paramPtr6.pointerPlus(12);
    Ptr ptr7 = paramPtr6.pointerPlus(20);
    Ptr ptr8 = paramPtr6.pointerPlus(52);
    Ptr ptr9 = paramPtr6.pointerPlus(72);
    Ptr ptr10 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(6) + -1) * 4);
    Ptr ptr11 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(7) + -1) * 4);
    Ptr ptr12 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(8) + -1) * 4);
    Ptr ptr13 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(9) + -1) * 4);
    Ptr ptr14 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(21) + -1) * 4);
    Ptr ptr15 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(26) + -1) * 4);
    Ptr ptr16 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(10) + -1) * 8);
    Ptr ptr17 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(22) + -1) * 4);
    Ptr ptr18 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(12) + -1) * 8);
    Ptr ptr19 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(11) + -1) * 8);
    Ptr ptr20 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(14) + -1) * 8);
    Ptr ptr21 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(15) + -1) * 8);
    Ptr ptr22 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(17) + -1) * 8);
    Ptr ptr3 = (Ptr)new IntPtr(arrayOfInt, 0);
    Ptr ptr23 = paramPtr9.pointerPlus(16);
    Ptr ptr24 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(25) + -1) * 8);
    Ptr ptr25 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(23) + -1) * 8);
    Ptr ptr26 = paramPtr9.pointerPlus(24);
    Ptr ptr27 = paramPtr6.pointerPlus(116);
    Ptr ptr28 = paramPtr6.pointerPlus(128);
    Ptr ptr29 = paramPtr6.pointerPlus(124);
    Ptr ptr30 = paramPtr6.pointerPlus(160);
    Ptr ptr31 = paramPtr6.pointerPlus((paramPtr6.getAlignedInt(24) + -1) * 4);
    Ptr ptr32 = paramPtr9.pointerPlus((paramPtr6.getAlignedInt(33) + -1) * 8);
    ehg131_(paramPtr1, paramPtr2, paramPtr3, paramPtr1, paramPtr4, paramPtr2, paramPtr3, ptr1, ptr2, ptr4, ptr5, ptr6, ptr7, ptr8, ptr9, paramPtr9, ptr10, ptr11, ptr12, ptr13, ptr14, ptr15, ptr16, ptr17, ptr18, ptr19, ptr20, ptr21, ptr22, ptr3, ptr23, ptr24, ptr25, ptr26, ptr27, ptr28, ptr29, ptr30, ptr31, ptr32, (Ptr)new BooleanPtr(arrayOfBoolean, 0));
    if (paramPtr6.getAlignedInt(13) >= paramPtr6.getAlignedInt(5) + paramPtr6.getAlignedInt(3) / 2.0D) {
      if (paramPtr6.getAlignedInt(16) < paramPtr6.getAlignedInt(4) + 2)
        ehg183_((Ptr)new BytePtr("k-d tree limited by memory. ncmax=".getBytes(), 0), paramPtr6.pointerPlus(64), (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 34); 
      return;
    } 
    ehg183_((Ptr)new BytePtr("k-d tree limited by memory; nvmax=".getBytes(), 0), paramPtr6.pointerPlus(52), (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), 34);
  }
  
  public static void lowesc_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    int j = Math.max(paramPtr1.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr1.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    int m = Math.max(paramPtr1.getInt(), 0);
    Integer.toUnsignedLong(Math.max(m * paramPtr1.getInt(), 0));
    int n = m ^ 0xFFFFFFFF;
    int i1 = paramPtr1.getInt();
    byte b2 = 1;
    if (1 <= i1)
      while (true) {
        boolean bool;
        paramPtr2.setAlignedDouble(b2 * j + k + b2, paramPtr2.getAlignedDouble(b2 * j + k + b2) - 1.0D);
        if (b2 != i1) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    i1 = paramPtr1.getInt();
    b2 = 1;
    if (1 <= i1)
      while (true) {
        byte b3 = b2;
        byte b4 = 1;
        if (1 <= b2)
          while (true) {
            boolean bool;
            Ptr ptr1 = paramPtr2.pointerPlus((k + j + b2) * 8);
            Ptr ptr2 = paramPtr2.pointerPlus((k + j + b4) * 8);
            paramPtr3.setAlignedDouble(b4 * m + n + b2, Blas.ddot_(paramPtr1, ptr1, paramPtr1, ptr2, paramPtr1));
            if (b4 != b3) {
              bool = false;
            } else {
              bool = true;
            } 
            b4++;
            if (!bool)
              continue; 
            break;
          }  
        if (b2 != i1) {
          b3 = 0;
        } else {
          b3 = 1;
        } 
        b2++;
        if (b3 == 0)
          continue; 
        break;
      }  
    i1 = paramPtr1.getInt();
    b2 = 1;
    if (1 <= i1)
      while (true) {
        int i2 = paramPtr1.getInt();
        int i3;
        if ((i3 = b2 + 1) <= i2)
          while (true) {
            boolean bool;
            paramPtr3.setAlignedDouble(i3 * m + n + b2, paramPtr3.getAlignedDouble(b2 * m + n + i3));
            if (i3 != i2) {
              bool = false;
            } else {
              bool = true;
            } 
            i3++;
            if (!bool)
              continue; 
            break;
          }  
        if (b2 != i1) {
          i2 = 0;
        } else {
          i2 = 1;
        } 
        b2++;
        if (i2 == 0)
          continue; 
        break;
      }  
    i1 = paramPtr1.getInt();
    b2 = 1;
    if (1 <= i1)
      while (true) {
        boolean bool;
        paramPtr2.setAlignedDouble(b2 * j + k + b2, paramPtr2.getAlignedDouble(b2 * j + k + b2) + 1.0D);
        if (b2 != i1) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    paramPtr4.setDouble(0.0D);
    paramPtr5.setDouble(0.0D);
    i1 = paramPtr1.getInt();
    b2 = 1;
    if (1 <= i1)
      while (true) {
        boolean bool;
        paramPtr4.setDouble(paramPtr4.getDouble() + paramPtr2.getAlignedDouble(b2 * j + k + b2));
        paramPtr5.setDouble(paramPtr5.getDouble() + paramPtr3.getAlignedDouble(b2 * m + n + b2));
        if (b2 != i1) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    paramPtr6.setDouble(0.0D);
    int i = paramPtr1.getInt();
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr5 = paramPtr3.pointerPlus((n + m + b1) * 8);
        Ptr ptr = paramPtr3.pointerPlus((b1 * m + n + 1) * 8);
        paramPtr6.setDouble(paramPtr6.getDouble() + Blas.ddot_(paramPtr1, paramPtr5, paramPtr1, ptr, (Ptr)new IntPtr(new int[] { 1 }, 0)));
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
  }
  
  public static void lowesd_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    double[] arrayOfDouble = new double[1];
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    int j = 0;
    if (paramPtr1.getInt() != 106)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 100 }, 0)); 
    paramPtr2.setAlignedInt(27, 171);
    paramPtr2.setAlignedInt(1, paramPtr6.getInt());
    paramPtr2.setAlignedInt(2, paramPtr7.getInt());
    int k = Builtins._gfortran_pow_i4_i4(2, paramPtr6.getInt());
    paramPtr2.setAlignedInt(3, k);
    if (paramPtr8.getDouble() <= 0.0D) {
      i = 0;
    } else {
      i = 1;
    } 
    if ((i ^ 0x1) != 0)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 120 }, 0)); 
    arrayOfDouble[0] = paramPtr7.getInt() * paramPtr8.getDouble();
    int m = paramPtr7.getInt();
    int i = ifloor_((Ptr)new DoublePtr(arrayOfDouble, 0));
    if (i < m)
      m = i; 
    i = m;
    paramPtr2.setAlignedInt(18, m);
    paramPtr2.setAlignedInt(19, 1);
    if (paramPtr9.getInt() != 0) {
      if (paramPtr9.getInt() != 1) {
        if (paramPtr9.getInt() == 2)
          j = (int)(((paramPtr6.getInt() + 2) * (paramPtr6.getInt() + 1)) / 2.0D); 
      } else {
        j = paramPtr6.getInt() + 1;
      } 
    } else {
      j = 1;
    } 
    paramPtr2.setAlignedInt(28, j);
    paramPtr2.setAlignedInt(20, 1);
    paramPtr2.setAlignedInt(13, paramPtr10.getInt());
    j = paramPtr10.getInt();
    paramPtr2.setAlignedInt(16, j);
    paramPtr2.setAlignedInt(29, 0);
    paramPtr2.setAlignedInt(31, paramPtr9.getInt());
    if (paramPtr9.getInt() < 0)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 195 }, 0)); 
    if (paramPtr9.getInt() > 2)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 195 }, 0)); 
    paramPtr2.setAlignedInt(32, paramPtr6.getInt());
    byte b = 41;
    while (true) {
      paramPtr2.setAlignedInt(b + -1, paramPtr9.getInt());
      if (b != 49) {
        m = 0;
      } else {
        m = 1;
      } 
      b++;
      if (m == 0)
        continue; 
      paramPtr2.setAlignedInt(6, 50);
      paramPtr2.setAlignedInt(7, paramPtr2.getAlignedInt(6) + j);
      paramPtr2.setAlignedInt(8, paramPtr2.getAlignedInt(7) + k * j);
      paramPtr2.setAlignedInt(9, paramPtr2.getAlignedInt(8) + j);
      paramPtr2.setAlignedInt(21, paramPtr2.getAlignedInt(9) + j);
      int n = paramPtr2.getAlignedInt(21) + -1;
      k = paramPtr7.getInt();
      b = 1;
      if (1 <= k)
        while (true) {
          paramPtr2.setAlignedInt(n + b + -1, b);
          if (b != k) {
            m = 0;
          } else {
            m = 1;
          } 
          b++;
          if (m == 0)
            continue; 
          break;
        }  
      paramPtr2.setAlignedInt(22, paramPtr2.getAlignedInt(21) + paramPtr7.getInt());
      paramPtr2.setAlignedInt(24, paramPtr2.getAlignedInt(22) + paramPtr10.getInt());
      if (!paramPtr11.getBoolean()) {
        paramPtr2.setAlignedInt(26, paramPtr2.getAlignedInt(24));
      } else {
        paramPtr2.setAlignedInt(26, paramPtr2.getAlignedInt(24) + paramPtr10.getInt() * i);
      } 
      if (paramPtr2.getAlignedInt(26) + paramPtr7.getInt() + -1 > paramPtr3.getInt())
        loessc__.ehg182_((Ptr)new IntPtr(new int[] { 102 }, 0)); 
      paramPtr2.setAlignedInt(10, 50);
      paramPtr2.setAlignedInt(12, paramPtr2.getAlignedInt(10) + paramPtr10.getInt() * paramPtr6.getInt());
      paramPtr2.setAlignedInt(11, paramPtr2.getAlignedInt(12) + (paramPtr6.getInt() + 1) * paramPtr10.getInt());
      paramPtr2.setAlignedInt(14, paramPtr2.getAlignedInt(11) + j);
      paramPtr2.setAlignedInt(15, paramPtr2.getAlignedInt(14) + paramPtr7.getInt());
      paramPtr2.setAlignedInt(17, paramPtr2.getAlignedInt(15) + i);
      paramPtr2.setAlignedInt(23, paramPtr2.getAlignedInt(17) + paramPtr2.getAlignedInt(28) * i);
      paramPtr2.setAlignedInt(33, paramPtr2.getAlignedInt(23) + (paramPtr6.getInt() + 1) * paramPtr10.getInt());
      if (!paramPtr11.getBoolean()) {
        paramPtr2.setAlignedInt(25, paramPtr2.getAlignedInt(33));
      } else {
        paramPtr2.setAlignedInt(25, paramPtr2.getAlignedInt(33) + (paramPtr6.getInt() + 1) * paramPtr10.getInt() * i);
      } 
      if (paramPtr2.getAlignedInt(25) + i + -1 > paramPtr4.getInt())
        loessc__.ehg182_((Ptr)new IntPtr(new int[] { 103 }, 0)); 
      paramPtr5.setDouble(paramPtr8.getDouble());
      paramPtr5.setAlignedDouble(1, 0.05D);
      paramPtr5.setAlignedDouble(2, 0.0D);
      paramPtr5.setAlignedDouble(3, 1.0D);
      return;
    } 
  }
  
  public static void lowese_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr5.getInt(), 0), 0));
    Integer.toUnsignedLong(Math.max(paramPtr5.getInt(), 0));
    if (paramPtr1.getAlignedInt(27) == 172)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 172 }, 0)); 
    if (paramPtr1.getAlignedInt(27) != 173)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 173 }, 0)); 
    paramPtr2 = paramPtr1.pointerPlus(8);
    paramPtr3 = paramPtr1.pointerPlus(4);
    paramPtr4 = paramPtr1.pointerPlus(12);
    Ptr ptr1 = paramPtr1.pointerPlus(52);
    Ptr ptr2 = paramPtr1.pointerPlus(16);
    paramPtr1 = paramPtr1.pointerPlus(64);
    Ptr ptr3 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(6) + -1) * 4);
    Ptr ptr4 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(7) + -1) * 4);
    Ptr ptr5 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(8) + -1) * 4);
    Ptr ptr6 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(9) + -1) * 4);
    Ptr ptr7 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(10) + -1) * 8);
    Ptr ptr8 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(12) + -1) * 8);
    Ptr ptr9 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(11) + -1) * 8);
    ehg133_(paramPtr2, paramPtr3, paramPtr4, ptr1, ptr2, paramPtr1, ptr3, ptr4, ptr5, ptr6, ptr7, ptr8, ptr9, paramPtr5, paramPtr6, paramPtr7);
  }
  
  public static void lowesf_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    boolean bool;
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr8.getInt(), 0), 0));
    Math.max(paramPtr8.getInt(), 0);
    Integer.toUnsignedLong(Math.max(paramPtr8.getInt(), 0));
    if (paramPtr4.getAlignedInt(27) <= 170) {
      bool = false;
    } else {
      if (paramPtr4.getAlignedInt(27) > 174) {
        bool = false;
      } else {
        bool = true;
      } 
      bool = bool;
    } 
    if ((bool ^ true) != 0)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 171 }, 0)); 
    paramPtr4.setAlignedInt(27, 172);
    if (paramPtr4.getAlignedInt(13) < paramPtr4.getAlignedInt(18))
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 186 }, 0)); 
    Ptr ptr1 = paramPtr4.pointerPlus(8);
    paramPtr6 = paramPtr4.pointerPlus(4);
    paramPtr8 = paramPtr4.pointerPlus(72);
    paramPtr9 = paramPtr4.pointerPlus((paramPtr4.getAlignedInt(21) + -1) * 4);
    Ptr ptr2 = paramPtr4.pointerPlus(76);
    Ptr ptr3 = paramPtr4.pointerPlus(112);
    Ptr ptr4 = paramPtr7.pointerPlus((paramPtr4.getAlignedInt(14) + -1) * 8);
    Ptr ptr5 = paramPtr7.pointerPlus((paramPtr4.getAlignedInt(15) + -1) * 8);
    Ptr ptr6 = paramPtr7.pointerPlus((paramPtr4.getAlignedInt(17) + -1) * 8);
    Ptr ptr7 = (Ptr)new IntPtr(new int[] { 0 }, 0);
    Ptr ptr8 = paramPtr7.pointerPlus((paramPtr4.getAlignedInt(25) + -1) * 8);
    ehg136_(paramPtr9, paramPtr8, paramPtr8, ptr1, paramPtr6, paramPtr8, paramPtr7, paramPtr1, paramPtr9, paramPtr2, paramPtr3, ptr2, ptr3, ptr4, ptr5, ptr6, ptr7, paramPtr10, paramPtr11, ptr8, paramPtr7.pointerPlus(24), paramPtr4.pointerPlus(116), paramPtr4.pointerPlus(128), paramPtr4.pointerPlus(124), paramPtr4.pointerPlus(160), paramPtr12);
  }
  
  public static void lowesl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr5.getInt(), 0), 0));
    Math.max(paramPtr5.getInt(), 0);
    if (paramPtr1.getAlignedInt(27) == 172)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 172 }, 0)); 
    if (paramPtr1.getAlignedInt(27) != 173)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 173 }, 0)); 
    if (paramPtr1.getAlignedInt(25) == paramPtr1.getAlignedInt(33))
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 175 }, 0)); 
    paramPtr2 = paramPtr1.pointerPlus(4);
    paramPtr3 = paramPtr1.pointerPlus(8);
    paramPtr4 = paramPtr1.pointerPlus(72);
    paramPtr5 = paramPtr1.pointerPlus(20);
    paramPtr6 = paramPtr1.pointerPlus(64);
    paramPtr7 = paramPtr1.pointerPlus(12);
    Ptr ptr1 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(6) + -1) * 4);
    Ptr ptr2 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(11) + -1) * 8);
    Ptr ptr3 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(9) + -1) * 4);
    Ptr ptr4 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(8) + -1) * 4);
    Ptr ptr5 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(7) + -1) * 4);
    Ptr ptr6 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(10) + -1) * 8);
    paramPtr1 = paramPtr1.pointerPlus(52);
    Ptr ptr7 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(23) + -1) * 8);
    Ptr ptr8 = paramPtr4.pointerPlus((paramPtr1.getAlignedInt(33) + -1) * 8);
    Ptr ptr9 = paramPtr1.pointerPlus((paramPtr1.getAlignedInt(24) + -1) * 4);
    ehg191_(paramPtr5, paramPtr6, paramPtr7, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, ptr1, ptr2, ptr3, ptr4, ptr5, ptr6, paramPtr1, ptr7, ptr8, ptr9);
  }
  
  public static void lowesp_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt3 = new int[1];
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    int m = paramPtr1.getInt();
    byte b2 = 1;
    if (1 <= m)
      while (true) {
        boolean bool;
        paramPtr7.setAlignedDouble(b2 + -1, Math.abs(paramPtr2.getAlignedDouble(b2 + -1) - paramPtr3.getAlignedDouble(b2 + -1)) * Mathlib.sqrt(paramPtr4.getAlignedDouble(b2 + -1)));
        paramPtr6.setAlignedInt(b2 + -1, b2);
        if (b2 != m) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    arrayOfDouble[0] = paramPtr1.getInt() / 2.0D;
    arrayOfInt3[0] = ifloor_((Ptr)new DoublePtr(arrayOfDouble, 0)) + 1;
    ehg106_((Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr1, (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr7, paramPtr6, paramPtr1);
    if (paramPtr1.getInt() - arrayOfInt3[0] + 1 >= arrayOfInt3[0]) {
      d = paramPtr7.getAlignedDouble(paramPtr6.getAlignedInt(arrayOfInt3[0] + -1) + -1);
    } else {
      arrayOfInt1[0] = arrayOfInt3[0] + -1;
      arrayOfInt2[0] = arrayOfInt3[0] + -1;
      ehg106_((Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr7, paramPtr6, paramPtr1);
      d = (paramPtr7.getAlignedDouble(paramPtr6.getAlignedInt(arrayOfInt3[0] + -2) + -1) + paramPtr7.getAlignedDouble(paramPtr6.getAlignedInt(arrayOfInt3[0] + -1) + -1)) / 2.0D;
    } 
    double d = d * 6.0D * d * 6.0D / 5.0D;
    int k = paramPtr1.getInt();
    byte b1 = 1;
    if (1 <= k)
      while (true) {
        boolean bool;
        paramPtr7.setAlignedDouble(b1 + -1, 1.0D - (paramPtr2.getAlignedDouble(b1 + -1) - paramPtr3.getAlignedDouble(b1 + -1)) * (paramPtr2.getAlignedDouble(b1 + -1) - paramPtr3.getAlignedDouble(b1 + -1)) * paramPtr4.getAlignedDouble(b1 + -1) / d);
        if (b1 != k) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
    int j = paramPtr1.getInt();
    k = 1;
    if (1 <= j)
      while (true) {
        paramPtr7.setAlignedDouble(k + -1, paramPtr7.getAlignedDouble(k + -1) * Mathlib.sqrt(paramPtr5.getAlignedDouble(k + -1)));
        if (k != j) {
          b1 = 0;
        } else {
          b1 = 1;
        } 
        k++;
        if (b1 == 0)
          continue; 
        break;
      }  
    if (paramPtr1.getInt() > 0) {
      j = paramPtr1.getInt() + -1;
      d = paramPtr7.getAlignedDouble(j);
      j = paramPtr1.getInt() + -1;
      if (j > 0)
        while (true) {
          d = paramPtr7.getAlignedDouble(j + -1) + d;
          if (j != 1) {
            k = 0;
          } else {
            k = 1;
          } 
          j--;
          if (k == 0)
            continue; 
          break;
        }  
      d = d;
    } else {
      d = 0.0D;
    } 
    d = paramPtr1.getInt() / d;
    int i = paramPtr1.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        paramPtr7.setAlignedDouble(j + -1, paramPtr3.getAlignedDouble(j + -1) + paramPtr5.getAlignedDouble(j + -1) * d * (paramPtr2.getAlignedDouble(j + -1) - paramPtr3.getAlignedDouble(j + -1)));
        if (j != i) {
          k = 0;
        } else {
          k = 1;
        } 
        j++;
        if (k == 0)
          continue; 
        break;
      }  
  }
  
  public static void lowesr_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    if (paramPtr2.getAlignedInt(27) == 172)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 172 }, 0)); 
    if (paramPtr2.getAlignedInt(27) != 173)
      loessc__.ehg182_((Ptr)new IntPtr(new int[] { 173 }, 0)); 
    paramPtr1 = paramPtr2.pointerPlus(4);
    paramPtr3 = paramPtr2.pointerPlus(8);
    paramPtr4 = paramPtr2.pointerPlus(72);
    paramPtr5 = paramPtr2.pointerPlus(20);
    paramPtr2 = paramPtr2.pointerPlus(52);
    Ptr ptr1 = paramPtr5.pointerPlus((paramPtr2.getAlignedInt(12) + -1) * 8);
    Ptr ptr2 = paramPtr5.pointerPlus((paramPtr2.getAlignedInt(33) + -1) * 8);
    Ptr ptr3 = paramPtr2.pointerPlus((paramPtr2.getAlignedInt(24) + -1) * 4);
    ehg192_(paramPtr1, paramPtr1, paramPtr3, paramPtr4, paramPtr5, paramPtr2, ptr1, ptr2, ptr3);
  }
  
  public static void lowesw_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    double d;
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    double[] arrayOfDouble = new double[1];
    int[] arrayOfInt3 = new int[1];
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr2.getInt(), 0));
    int j = paramPtr2.getInt();
    byte b2 = 1;
    if (1 <= j)
      while (true) {
        boolean bool;
        paramPtr3.setAlignedDouble(b2 + -1, Math.abs(paramPtr1.getAlignedDouble(b2 + -1)));
        if (b2 != j) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    int i = paramPtr2.getInt();
    j = 1;
    if (1 <= i)
      while (true) {
        paramPtr4.setAlignedInt(j + -1, j);
        if (j != i) {
          b2 = 0;
        } else {
          b2 = 1;
        } 
        j++;
        if (b2 == 0)
          continue; 
        break;
      }  
    arrayOfDouble[0] = paramPtr2.getInt() / 2.0D;
    arrayOfInt3[0] = ifloor_((Ptr)new DoublePtr(arrayOfDouble, 0)) + 1;
    ehg106_((Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr2, (Ptr)new IntPtr(arrayOfInt3, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr3, paramPtr4, paramPtr2);
    if (paramPtr2.getInt() - arrayOfInt3[0] + 1 >= arrayOfInt3[0]) {
      d = paramPtr3.getAlignedDouble(paramPtr4.getAlignedInt(arrayOfInt3[0] + -1) + -1) * 6.0D;
    } else {
      arrayOfInt1[0] = arrayOfInt3[0] + -1;
      arrayOfInt2[0] = arrayOfInt3[0] + -1;
      ehg106_((Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(arrayOfInt1, 0), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(new int[] { 1 }, 0), paramPtr3, paramPtr4, paramPtr2);
      d = (paramPtr3.getAlignedDouble(paramPtr4.getAlignedInt(arrayOfInt3[0] + -1) + -1) + paramPtr3.getAlignedDouble(paramPtr4.getAlignedInt(arrayOfInt3[0] + -2) + -1)) * 3.0D;
    } 
    if (d >= d1mach.d1mach_((Ptr)new IntPtr(new int[] { 1 }, 0))) {
      i = paramPtr2.getInt();
      b1 = 1;
      if (1 <= i)
        while (true) {
          boolean bool;
          if (d * 0.999D >= paramPtr3.getAlignedDouble(b1 + -1)) {
            if (d * 0.001D >= paramPtr3.getAlignedDouble(b1 + -1)) {
              paramPtr3.setAlignedDouble(b1 + -1, 1.0D);
            } else {
              paramPtr3.setAlignedDouble(b1 + -1, (1.0D - paramPtr3.getAlignedDouble(b1 + -1) / d * paramPtr3.getAlignedDouble(b1 + -1) / d) * (1.0D - paramPtr3.getAlignedDouble(b1 + -1) / d * paramPtr3.getAlignedDouble(b1 + -1) / d));
            } 
          } else {
            paramPtr3.setAlignedDouble(b1 + -1, 0.0D);
          } 
          if (b1 != i) {
            bool = false;
          } else {
            bool = true;
          } 
          b1++;
          if (!bool)
            continue; 
          break;
        }  
      return;
    } 
    i = b1.getInt();
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        paramPtr3.setAlignedDouble(b1 + -1, 1.0D);
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
  }
  
  static void v$3685$$clinit() {
    double[] arrayOfDouble = new double[10];
    arrayOfDouble[0] = -0.005D;
    arrayOfDouble[1] = 1.005D;
    arrayOfDouble[2] = 0.3705D;
    arrayOfDouble[3] = 0.2017D;
    arrayOfDouble[4] = 0.5591D;
    arrayOfDouble[5] = 0.1204D;
    arrayOfDouble[6] = 0.2815D;
    arrayOfDouble[7] = 0.4536D;
    arrayOfDouble[8] = 0.7132D;
    arrayOfDouble[9] = 0.8751D;
    System.arraycopy(arrayOfDouble, 0, v$3685, 0, 10);
  }
  
  static void vval$3688$$clinit() {
    double[] arrayOfDouble = new double[20];
    arrayOfDouble[0] = -0.090572D;
    arrayOfDouble[1] = 4.4844D;
    arrayOfDouble[2] = -0.010856D;
    arrayOfDouble[3] = -0.7736D;
    arrayOfDouble[4] = -0.053718D;
    arrayOfDouble[5] = -0.3495D;
    arrayOfDouble[6] = 0.026152D;
    arrayOfDouble[7] = -0.7286D;
    arrayOfDouble[8] = -0.058387D;
    arrayOfDouble[9] = 0.1611D;
    arrayOfDouble[10] = 0.095807D;
    arrayOfDouble[11] = -0.7978D;
    arrayOfDouble[12] = -0.031926D;
    arrayOfDouble[13] = -0.4457D;
    arrayOfDouble[14] = -0.06417D;
    arrayOfDouble[15] = 0.032813D;
    arrayOfDouble[16] = -0.020636D;
    arrayOfDouble[17] = 0.335D;
    arrayOfDouble[18] = 0.040172D;
    arrayOfDouble[19] = -0.041032D;
    System.arraycopy(arrayOfDouble, 0, vval$3688, 0, 20);
  }
  
  static void xi$3690$$clinit() {
    double[] arrayOfDouble = new double[17];
    arrayOfDouble[0] = 0.3705D;
    arrayOfDouble[1] = 0.2017D;
    arrayOfDouble[2] = 0.5591D;
    arrayOfDouble[3] = 0.1204D;
    arrayOfDouble[4] = 0.2815D;
    arrayOfDouble[5] = 0.4536D;
    arrayOfDouble[6] = 0.7132D;
    arrayOfDouble[7] = 0.8751D;
    System.arraycopy(arrayOfDouble, 0, xi$3690, 0, 17);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/loessf__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */