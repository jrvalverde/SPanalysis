package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;

public class kmeans__ {
  static {
  
  }
  
  public static void kmeans_Lloyd(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    int i = paramPtr2.getInt();
    int k = paramPtr5.getInt();
    int j = paramPtr3.getInt();
    int m = paramPtr7.getInt();
    int n = 0;
    byte b2;
    for (b2 = 0; b2 < i; b2++)
      paramPtr6.setInt(b2 * 4, -1); 
    b2 = 0;
    while (b2 < m) {
      byte b = 0;
      int i1;
      for (i1 = 0; i1 < i; i1++) {
        double d = Arith.R_PosInf;
        for (byte b3 = 0; b3 < k; b3++) {
          double d1 = 0.0D;
          for (byte b4 = 0; b4 < j; b4++)
            d1 = (paramPtr1.getDouble((i * b4 + i1) * 8) - paramPtr4.getDouble((k * b4 + b3) * 8)) * (paramPtr1.getDouble((i * b4 + i1) * 8) - paramPtr4.getDouble((k * b4 + b3) * 8)) + d1; 
          if (d1 < d) {
            d = d1;
            n = b3 + 1;
          } 
        } 
        if (paramPtr6.getInt(i1 * 4) != n) {
          b = 1;
          paramPtr6.setInt(i1 * 4, n);
        } 
      } 
      if (b) {
        for (b = 0; k * j > b; b++)
          paramPtr4.setDouble(b * 8, 0.0D); 
        for (b = 0; b < k; b++)
          paramPtr8.setInt(b * 4, 0); 
        for (b = 0; b < i; b++) {
          i1 = paramPtr6.getInt(b * 4) + -1;
          int i3 = i1 * 4;
          int i2 = paramPtr8.getInt(i3) + 1;
          paramPtr8.setInt(i3, i2);
          for (i2 = 0; i2 < j; i2++)
            paramPtr4.setDouble((i2 * k + i1) * 8, paramPtr4.getDouble((i2 * k + i1) * 8) + paramPtr1.getDouble((i2 * i + b) * 8)); 
        } 
        for (b = 0; k * j > b; b++)
          paramPtr4.setDouble(b * 8, paramPtr4.getDouble(b * 8) / paramPtr8.getInt(b % k * 4)); 
        b2++;
        continue;
      } 
      break;
    } 
    paramPtr7.setInt(b2 + 1);
    byte b1;
    for (b1 = 0; b1 < k; b1++)
      paramPtr9.setDouble(b1 * 8, 0.0D); 
    for (b1 = 0; b1 < i; b1++) {
      int i1 = paramPtr6.getInt(b1 * 4) + -1;
      for (m = 0; m < j; m++)
        paramPtr9.setDouble(i1 * 8, (paramPtr1.getDouble((i * m + b1) * 8) - paramPtr4.getDouble((k * m + i1) * 8)) * (paramPtr1.getDouble((i * m + b1) * 8) - paramPtr4.getDouble((k * m + i1) * 8)) + paramPtr9.getDouble(i1 * 8)); 
    } 
  }
  
  public static void kmeans_MacQueen(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    int i = paramPtr2.getInt();
    int k = paramPtr5.getInt();
    int j = paramPtr3.getInt();
    int m = paramPtr7.getInt();
    int n = 0;
    byte b2;
    for (b2 = 0; b2 < i; b2++) {
      double d = Arith.R_PosInf;
      for (byte b = 0; b < k; b++) {
        double d1 = 0.0D;
        for (byte b3 = 0; b3 < j; b3++)
          d1 = (paramPtr1.getDouble((i * b3 + b2) * 8) - paramPtr4.getDouble((k * b3 + b) * 8)) * (paramPtr1.getDouble((i * b3 + b2) * 8) - paramPtr4.getDouble((k * b3 + b) * 8)) + d1; 
        if (d1 < d) {
          d = d1;
          n = b + 1;
        } 
      } 
      if (paramPtr6.getInt(b2 * 4) != n)
        paramPtr6.setInt(b2 * 4, n); 
    } 
    for (b2 = 0; k * j > b2; b2++)
      paramPtr4.setDouble(b2 * 8, 0.0D); 
    for (b2 = 0; b2 < k; b2++)
      paramPtr8.setInt(b2 * 4, 0); 
    for (b2 = 0; b2 < i; b2++) {
      int i3 = paramPtr6.getInt(b2 * 4) + -1;
      int i2 = i3 * 4;
      int i1 = paramPtr8.getInt(i2) + 1;
      paramPtr8.setInt(i2, i1);
      for (i1 = 0; i1 < j; i1++)
        paramPtr4.setDouble((i1 * k + i3) * 8, paramPtr4.getDouble((i1 * k + i3) * 8) + paramPtr1.getDouble((i1 * i + b2) * 8)); 
    } 
    for (b2 = 0; k * j > b2; b2++)
      paramPtr4.setDouble(b2 * 8, paramPtr4.getDouble(b2 * 8) / paramPtr8.getInt(b2 % k * 4)); 
    b2 = 0;
    while (b2 < m) {
      boolean bool = false;
      for (byte b = 0; b < i; b++) {
        double d = Arith.R_PosInf;
        int i1;
        for (i1 = 0; i1 < k; i1++) {
          double d1 = 0.0D;
          for (byte b3 = 0; b3 < j; b3++)
            d1 = (paramPtr1.getDouble((i * b3 + b) * 8) - paramPtr4.getDouble((k * b3 + i1) * 8)) * (paramPtr1.getDouble((i * b3 + b) * 8) - paramPtr4.getDouble((k * b3 + i1) * 8)) + d1; 
          if (d1 < d) {
            d = d1;
            n = i1;
          } 
        } 
        i1 = paramPtr6.getInt(b * 4) + -1;
        if (i1 != n) {
          bool = true;
          paramPtr6.setInt(b * 4, n + 1);
          int i3 = i1 * 4;
          int i2 = paramPtr8.getInt(i3) - 1;
          paramPtr8.setInt(i3, i2);
          i3 = n * 4;
          i2 = paramPtr8.getInt(i3) + 1;
          paramPtr8.setInt(i3, i2);
          for (i2 = 0; i2 < j; i2++) {
            paramPtr4.setDouble((k * i2 + i1) * 8, paramPtr4.getDouble((k * i2 + i1) * 8) + (paramPtr4.getDouble((k * i2 + i1) * 8) - paramPtr1.getDouble((i * i2 + b) * 8)) / paramPtr8.getInt(i1 * 4));
            paramPtr4.setDouble((k * i2 + n) * 8, paramPtr4.getDouble((k * i2 + n) * 8) + (paramPtr1.getDouble((i * i2 + b) * 8) - paramPtr4.getDouble((k * i2 + n) * 8)) / paramPtr8.getInt(n * 4));
          } 
        } 
      } 
      if (bool) {
        b2++;
        continue;
      } 
      break;
    } 
    paramPtr7.setInt(b2 + 1);
    byte b1;
    for (b1 = 0; b1 < k; b1++)
      paramPtr9.setDouble(b1 * 8, 0.0D); 
    for (b1 = 0; b1 < i; b1++) {
      int i1 = paramPtr6.getInt(b1 * 4) + -1;
      for (m = 0; m < j; m++)
        paramPtr9.setDouble(i1 * 8, (paramPtr1.getDouble((i * m + b1) * 8) - paramPtr4.getDouble((k * m + i1) * 8)) * (paramPtr1.getDouble((i * m + b1) * 8) - paramPtr4.getDouble((k * m + i1) * 8)) + paramPtr9.getDouble(i1 * 8)); 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/kmeans__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */