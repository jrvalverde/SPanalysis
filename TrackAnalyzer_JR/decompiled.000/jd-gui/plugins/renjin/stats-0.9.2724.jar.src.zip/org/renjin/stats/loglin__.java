package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class loglin__ {
  static {
  
  }
  
  public static void adjust(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: pop
    //   5: iconst_0
    //   6: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   9: pop
    //   10: aload_0
    //   11: invokeinterface getInt : ()I
    //   16: iconst_1
    //   17: iadd
    //   18: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   21: astore #5
    //   23: aload_0
    //   24: invokeinterface getInt : ()I
    //   29: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   32: astore #6
    //   34: aload #9
    //   36: bipush #-4
    //   38: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   43: astore #7
    //   45: aload #8
    //   47: bipush #-4
    //   49: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   54: astore #8
    //   56: aload_1
    //   57: bipush #-8
    //   59: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   64: astore_1
    //   65: aload_2
    //   66: bipush #-8
    //   68: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   73: astore_2
    //   74: aload_3
    //   75: bipush #-8
    //   77: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   82: astore_3
    //   83: aload #5
    //   85: iconst_0
    //   86: iconst_1
    //   87: invokeinterface setInt : (II)V
    //   92: iconst_1
    //   93: istore #11
    //   95: goto -> 159
    //   98: aload #7
    //   100: iload #11
    //   102: iconst_4
    //   103: imul
    //   104: invokeinterface getInt : (I)I
    //   109: istore #9
    //   111: iload #9
    //   113: ifeq -> 180
    //   116: aload #5
    //   118: iconst_0
    //   119: iload #11
    //   121: iconst_4
    //   122: imul
    //   123: iadd
    //   124: aload #5
    //   126: iconst_0
    //   127: iload #11
    //   129: iconst_m1
    //   130: iadd
    //   131: iconst_4
    //   132: imul
    //   133: iadd
    //   134: invokeinterface getInt : (I)I
    //   139: aload #8
    //   141: iload #9
    //   143: iconst_4
    //   144: imul
    //   145: invokeinterface getInt : (I)I
    //   150: imul
    //   151: invokeinterface setInt : (II)V
    //   156: iinc #11, 1
    //   159: aload_0
    //   160: invokeinterface getInt : ()I
    //   165: iload #11
    //   167: if_icmpge -> 98
    //   170: aload_0
    //   171: invokeinterface getInt : ()I
    //   176: iconst_1
    //   177: iadd
    //   178: istore #11
    //   180: iload #11
    //   182: iconst_m1
    //   183: iadd
    //   184: istore #9
    //   186: aload #5
    //   188: iconst_0
    //   189: iload #11
    //   191: iconst_m1
    //   192: iadd
    //   193: iconst_4
    //   194: imul
    //   195: iadd
    //   196: invokeinterface getInt : (I)I
    //   201: istore #11
    //   203: iconst_1
    //   204: istore #12
    //   206: aload #4
    //   208: invokeinterface getInt : ()I
    //   213: istore #13
    //   215: iconst_1
    //   216: istore #14
    //   218: goto -> 340
    //   221: aload_3
    //   222: iload #13
    //   224: bipush #8
    //   226: imul
    //   227: invokeinterface getDouble : (I)D
    //   232: aload_2
    //   233: iload #12
    //   235: bipush #8
    //   237: imul
    //   238: invokeinterface getDouble : (I)D
    //   243: dsub
    //   244: dconst_0
    //   245: dcmpl
    //   246: ifge -> 252
    //   249: goto -> 280
    //   252: aload_3
    //   253: iload #13
    //   255: bipush #8
    //   257: imul
    //   258: invokeinterface getDouble : (I)D
    //   263: aload_2
    //   264: iload #12
    //   266: bipush #8
    //   268: imul
    //   269: invokeinterface getDouble : (I)D
    //   274: dsub
    //   275: dstore #15
    //   277: goto -> 306
    //   280: aload_3
    //   281: iload #13
    //   283: bipush #8
    //   285: imul
    //   286: invokeinterface getDouble : (I)D
    //   291: aload_2
    //   292: iload #12
    //   294: bipush #8
    //   296: imul
    //   297: invokeinterface getDouble : (I)D
    //   302: dsub
    //   303: dneg
    //   304: dstore #15
    //   306: aload #10
    //   308: invokeinterface getDouble : ()D
    //   313: dload #15
    //   315: dcmpg
    //   316: iflt -> 322
    //   319: goto -> 331
    //   322: aload #10
    //   324: dload #15
    //   326: invokeinterface setDouble : (D)V
    //   331: iinc #12, 1
    //   334: iinc #13, 1
    //   337: iinc #14, 1
    //   340: iload #14
    //   342: iload #11
    //   344: if_icmple -> 221
    //   347: iconst_0
    //   348: istore #10
    //   350: goto -> 370
    //   353: aload #6
    //   355: iconst_0
    //   356: iload #10
    //   358: iconst_4
    //   359: imul
    //   360: iadd
    //   361: iconst_0
    //   362: invokeinterface setInt : (II)V
    //   367: iinc #10, 1
    //   370: aload_0
    //   371: invokeinterface getInt : ()I
    //   376: iload #10
    //   378: if_icmpgt -> 353
    //   381: iconst_1
    //   382: istore #10
    //   384: iconst_0
    //   385: istore #11
    //   387: iconst_1
    //   388: istore #12
    //   390: goto -> 441
    //   393: aload #6
    //   395: iconst_0
    //   396: aload #7
    //   398: iload #12
    //   400: iconst_4
    //   401: imul
    //   402: invokeinterface getInt : (I)I
    //   407: iconst_m1
    //   408: iadd
    //   409: iconst_4
    //   410: imul
    //   411: iadd
    //   412: invokeinterface getInt : (I)I
    //   417: aload #5
    //   419: iconst_0
    //   420: iload #12
    //   422: iconst_m1
    //   423: iadd
    //   424: iconst_4
    //   425: imul
    //   426: iadd
    //   427: invokeinterface getInt : (I)I
    //   432: imul
    //   433: iload #11
    //   435: iadd
    //   436: istore #11
    //   438: iinc #12, 1
    //   441: iload #12
    //   443: iload #9
    //   445: if_icmple -> 393
    //   448: aload #4
    //   450: invokeinterface getInt : ()I
    //   455: iload #11
    //   457: iadd
    //   458: istore #12
    //   460: iload #11
    //   462: iconst_1
    //   463: iadd
    //   464: istore #11
    //   466: aload_2
    //   467: iload #11
    //   469: bipush #8
    //   471: imul
    //   472: invokeinterface getDouble : (I)D
    //   477: dconst_0
    //   478: dcmpg
    //   479: ifle -> 485
    //   482: goto -> 497
    //   485: aload_1
    //   486: iload #10
    //   488: bipush #8
    //   490: imul
    //   491: dconst_0
    //   492: invokeinterface setDouble : (ID)V
    //   497: aload_2
    //   498: iload #11
    //   500: bipush #8
    //   502: imul
    //   503: invokeinterface getDouble : (I)D
    //   508: dconst_0
    //   509: dcmpl
    //   510: ifgt -> 516
    //   513: goto -> 562
    //   516: aload_1
    //   517: iload #10
    //   519: bipush #8
    //   521: imul
    //   522: aload_1
    //   523: iload #10
    //   525: bipush #8
    //   527: imul
    //   528: invokeinterface getDouble : (I)D
    //   533: aload_3
    //   534: iload #12
    //   536: bipush #8
    //   538: imul
    //   539: invokeinterface getDouble : (I)D
    //   544: dmul
    //   545: aload_2
    //   546: iload #11
    //   548: bipush #8
    //   550: imul
    //   551: invokeinterface getDouble : (I)D
    //   556: ddiv
    //   557: invokeinterface setDouble : (ID)V
    //   562: iinc #10, 1
    //   565: iconst_1
    //   566: istore #13
    //   568: goto -> 653
    //   571: aload #6
    //   573: aload #6
    //   575: iconst_0
    //   576: iload #13
    //   578: iconst_m1
    //   579: iadd
    //   580: iconst_4
    //   581: imul
    //   582: iadd
    //   583: istore #12
    //   585: iload #12
    //   587: invokeinterface getInt : (I)I
    //   592: iconst_1
    //   593: iadd
    //   594: istore #11
    //   596: iload #12
    //   598: iload #11
    //   600: invokeinterface setInt : (II)V
    //   605: aload #6
    //   607: iconst_0
    //   608: iload #13
    //   610: iconst_m1
    //   611: iadd
    //   612: iconst_4
    //   613: imul
    //   614: iadd
    //   615: invokeinterface getInt : (I)I
    //   620: aload #8
    //   622: iload #13
    //   624: iconst_4
    //   625: imul
    //   626: invokeinterface getInt : (I)I
    //   631: if_icmplt -> 384
    //   634: aload #6
    //   636: iconst_0
    //   637: iload #13
    //   639: iconst_m1
    //   640: iadd
    //   641: iconst_4
    //   642: imul
    //   643: iadd
    //   644: iconst_0
    //   645: invokeinterface setInt : (II)V
    //   650: iinc #13, 1
    //   653: aload_0
    //   654: invokeinterface getInt : ()I
    //   659: iload #13
    //   661: if_icmpge -> 571
    //   664: return
  }
  
  public static void collap(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    // Byte code:
    //   0: iconst_0
    //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4: pop
    //   5: iconst_0
    //   6: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   9: pop
    //   10: aload_0
    //   11: invokeinterface getInt : ()I
    //   16: iconst_1
    //   17: iadd
    //   18: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   21: astore #4
    //   23: aload_0
    //   24: invokeinterface getInt : ()I
    //   29: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   32: astore #5
    //   34: aload #7
    //   36: bipush #-4
    //   38: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   43: astore #7
    //   45: aload #6
    //   47: bipush #-4
    //   49: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   54: astore #6
    //   56: aload_1
    //   57: bipush #-8
    //   59: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   64: astore_1
    //   65: aload_2
    //   66: bipush #-8
    //   68: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   73: astore_2
    //   74: aload #4
    //   76: iconst_0
    //   77: iconst_1
    //   78: invokeinterface setInt : (II)V
    //   83: iconst_1
    //   84: istore #10
    //   86: goto -> 150
    //   89: aload #7
    //   91: iload #10
    //   93: iconst_4
    //   94: imul
    //   95: invokeinterface getInt : (I)I
    //   100: istore #11
    //   102: iload #11
    //   104: ifeq -> 171
    //   107: aload #4
    //   109: iconst_0
    //   110: iload #10
    //   112: iconst_4
    //   113: imul
    //   114: iadd
    //   115: aload #4
    //   117: iconst_0
    //   118: iload #10
    //   120: iconst_m1
    //   121: iadd
    //   122: iconst_4
    //   123: imul
    //   124: iadd
    //   125: invokeinterface getInt : (I)I
    //   130: aload #6
    //   132: iload #11
    //   134: iconst_4
    //   135: imul
    //   136: invokeinterface getInt : (I)I
    //   141: imul
    //   142: invokeinterface setInt : (II)V
    //   147: iinc #10, 1
    //   150: aload_0
    //   151: invokeinterface getInt : ()I
    //   156: iload #10
    //   158: if_icmpge -> 89
    //   161: aload_0
    //   162: invokeinterface getInt : ()I
    //   167: iconst_1
    //   168: iadd
    //   169: istore #10
    //   171: iload #10
    //   173: iconst_m1
    //   174: iadd
    //   175: istore #11
    //   177: aload_3
    //   178: invokeinterface getInt : ()I
    //   183: aload #4
    //   185: iconst_0
    //   186: iload #10
    //   188: iconst_m1
    //   189: iadd
    //   190: iconst_4
    //   191: imul
    //   192: iadd
    //   193: invokeinterface getInt : (I)I
    //   198: iadd
    //   199: iconst_m1
    //   200: iadd
    //   201: istore #10
    //   203: aload_3
    //   204: invokeinterface getInt : ()I
    //   209: istore #8
    //   211: goto -> 229
    //   214: aload_2
    //   215: iload #8
    //   217: bipush #8
    //   219: imul
    //   220: dconst_0
    //   221: invokeinterface setDouble : (ID)V
    //   226: iinc #8, 1
    //   229: iload #8
    //   231: iload #10
    //   233: if_icmple -> 214
    //   236: iconst_0
    //   237: istore #10
    //   239: goto -> 259
    //   242: aload #5
    //   244: iconst_0
    //   245: iload #10
    //   247: iconst_4
    //   248: imul
    //   249: iadd
    //   250: iconst_0
    //   251: invokeinterface setInt : (II)V
    //   256: iinc #10, 1
    //   259: aload_0
    //   260: invokeinterface getInt : ()I
    //   265: iload #10
    //   267: if_icmpgt -> 242
    //   270: iconst_1
    //   271: istore #10
    //   273: aload_3
    //   274: invokeinterface getInt : ()I
    //   279: istore #8
    //   281: iconst_1
    //   282: istore #9
    //   284: goto -> 335
    //   287: aload #5
    //   289: iconst_0
    //   290: aload #7
    //   292: iload #9
    //   294: iconst_4
    //   295: imul
    //   296: invokeinterface getInt : (I)I
    //   301: iconst_m1
    //   302: iadd
    //   303: iconst_4
    //   304: imul
    //   305: iadd
    //   306: invokeinterface getInt : (I)I
    //   311: aload #4
    //   313: iconst_0
    //   314: iload #9
    //   316: iconst_m1
    //   317: iadd
    //   318: iconst_4
    //   319: imul
    //   320: iadd
    //   321: invokeinterface getInt : (I)I
    //   326: imul
    //   327: iload #8
    //   329: iadd
    //   330: istore #8
    //   332: iinc #9, 1
    //   335: iload #9
    //   337: iload #11
    //   339: if_icmple -> 287
    //   342: aload_2
    //   343: iload #8
    //   345: bipush #8
    //   347: imul
    //   348: aload_2
    //   349: iload #8
    //   351: bipush #8
    //   353: imul
    //   354: invokeinterface getDouble : (I)D
    //   359: aload_1
    //   360: iload #10
    //   362: bipush #8
    //   364: imul
    //   365: invokeinterface getDouble : (I)D
    //   370: dadd
    //   371: invokeinterface setDouble : (ID)V
    //   376: iinc #10, 1
    //   379: iconst_1
    //   380: istore #12
    //   382: goto -> 467
    //   385: aload #5
    //   387: aload #5
    //   389: iconst_0
    //   390: iload #12
    //   392: iconst_m1
    //   393: iadd
    //   394: iconst_4
    //   395: imul
    //   396: iadd
    //   397: istore #9
    //   399: iload #9
    //   401: invokeinterface getInt : (I)I
    //   406: iconst_1
    //   407: iadd
    //   408: istore #8
    //   410: iload #9
    //   412: iload #8
    //   414: invokeinterface setInt : (II)V
    //   419: aload #5
    //   421: iconst_0
    //   422: iload #12
    //   424: iconst_m1
    //   425: iadd
    //   426: iconst_4
    //   427: imul
    //   428: iadd
    //   429: invokeinterface getInt : (I)I
    //   434: aload #6
    //   436: iload #12
    //   438: iconst_4
    //   439: imul
    //   440: invokeinterface getInt : (I)I
    //   445: if_icmplt -> 273
    //   448: aload #5
    //   450: iconst_0
    //   451: iload #12
    //   453: iconst_m1
    //   454: iadd
    //   455: iconst_4
    //   456: imul
    //   457: iadd
    //   458: iconst_0
    //   459: invokeinterface setInt : (II)V
    //   464: iinc #12, 1
    //   467: aload_0
    //   468: invokeinterface getInt : ()I
    //   473: iload #12
    //   475: if_icmpge -> 385
    //   478: return
  }
  
  public static void loglin(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray double
    //   3: astore #17
    //   5: iconst_1
    //   6: newarray int
    //   8: astore #18
    //   10: aload #17
    //   12: iconst_0
    //   13: dconst_0
    //   14: dastore
    //   15: aload #18
    //   17: iconst_0
    //   18: iconst_0
    //   19: iastore
    //   20: iconst_0
    //   21: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   24: pop
    //   25: iconst_0
    //   26: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   29: pop
    //   30: aload #18
    //   32: iconst_0
    //   33: iconst_1
    //   34: iastore
    //   35: aload_0
    //   36: invokeinterface getInt : ()I
    //   41: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   44: astore #19
    //   46: aload_0
    //   47: invokeinterface getInt : ()I
    //   52: invokestatic lvector : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   55: astore #23
    //   57: aload_1
    //   58: bipush #-4
    //   60: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   65: astore_1
    //   66: aload #7
    //   68: bipush #-4
    //   70: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   75: astore #7
    //   77: aload_3
    //   78: aload_0
    //   79: invokeinterface getInt : ()I
    //   84: iconst_m1
    //   85: ixor
    //   86: iconst_4
    //   87: imul
    //   88: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   93: astore_3
    //   94: aload #6
    //   96: bipush #-8
    //   98: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   103: astore #6
    //   105: aload #5
    //   107: bipush #-8
    //   109: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   114: astore #24
    //   116: aload #9
    //   118: bipush #-8
    //   120: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   125: astore #5
    //   127: aload #11
    //   129: bipush #-8
    //   131: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   136: astore #9
    //   138: aload #14
    //   140: bipush #-8
    //   142: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   147: astore #11
    //   149: aload #16
    //   151: iconst_0
    //   152: invokeinterface setInt : (I)V
    //   157: aload #15
    //   159: iconst_0
    //   160: invokeinterface setInt : (I)V
    //   165: aload_0
    //   166: invokeinterface getInt : ()I
    //   171: ifgt -> 177
    //   174: goto -> 187
    //   177: aload #13
    //   179: invokeinterface getInt : ()I
    //   184: ifgt -> 198
    //   187: aload #16
    //   189: iconst_4
    //   190: invokeinterface setInt : (I)V
    //   195: goto -> 1179
    //   198: iconst_1
    //   199: istore #14
    //   201: iconst_1
    //   202: istore #20
    //   204: goto -> 238
    //   207: aload_1
    //   208: iload #20
    //   210: iconst_4
    //   211: imul
    //   212: invokeinterface getInt : (I)I
    //   217: ifle -> 187
    //   220: aload_1
    //   221: iload #20
    //   223: iconst_4
    //   224: imul
    //   225: invokeinterface getInt : (I)I
    //   230: iload #14
    //   232: imul
    //   233: istore #14
    //   235: iinc #20, 1
    //   238: aload_0
    //   239: invokeinterface getInt : ()I
    //   244: iload #20
    //   246: if_icmpge -> 207
    //   249: aload #4
    //   251: invokeinterface getInt : ()I
    //   256: iload #14
    //   258: if_icmpge -> 272
    //   261: aload #16
    //   263: iconst_2
    //   264: invokeinterface setInt : (I)V
    //   269: goto -> 1179
    //   272: dconst_0
    //   273: dstore #25
    //   275: dconst_0
    //   276: dstore #27
    //   278: iconst_1
    //   279: istore #20
    //   281: goto -> 355
    //   284: aload #24
    //   286: iload #20
    //   288: bipush #8
    //   290: imul
    //   291: invokeinterface getDouble : (I)D
    //   296: dconst_0
    //   297: dcmpg
    //   298: iflt -> 187
    //   301: aload #6
    //   303: iload #20
    //   305: bipush #8
    //   307: imul
    //   308: invokeinterface getDouble : (I)D
    //   313: dconst_0
    //   314: dcmpg
    //   315: iflt -> 187
    //   318: aload #24
    //   320: iload #20
    //   322: bipush #8
    //   324: imul
    //   325: invokeinterface getDouble : (I)D
    //   330: dload #25
    //   332: dadd
    //   333: dstore #25
    //   335: aload #6
    //   337: iload #20
    //   339: bipush #8
    //   341: imul
    //   342: invokeinterface getDouble : (I)D
    //   347: dload #27
    //   349: dadd
    //   350: dstore #27
    //   352: iinc #20, 1
    //   355: iload #20
    //   357: iload #14
    //   359: if_icmple -> 284
    //   362: dload #27
    //   364: dconst_0
    //   365: dcmpl
    //   366: ifeq -> 187
    //   369: dload #25
    //   371: dload #27
    //   373: ddiv
    //   374: dstore #25
    //   376: iconst_1
    //   377: istore #20
    //   379: goto -> 412
    //   382: aload #6
    //   384: iload #20
    //   386: bipush #8
    //   388: imul
    //   389: aload #6
    //   391: iload #20
    //   393: bipush #8
    //   395: imul
    //   396: invokeinterface getDouble : (I)D
    //   401: dload #25
    //   403: dmul
    //   404: invokeinterface setDouble : (ID)V
    //   409: iinc #20, 1
    //   412: iload #20
    //   414: iload #14
    //   416: if_icmple -> 382
    //   419: aload_2
    //   420: invokeinterface getInt : ()I
    //   425: ifle -> 1179
    //   428: aload_3
    //   429: aload_0
    //   430: invokeinterface getInt : ()I
    //   435: iconst_1
    //   436: iadd
    //   437: iconst_4
    //   438: imul
    //   439: invokeinterface getInt : (I)I
    //   444: ifeq -> 1179
    //   447: iconst_1
    //   448: istore #14
    //   450: iconst_1
    //   451: istore #20
    //   453: goto -> 676
    //   456: aload_3
    //   457: aload_0
    //   458: invokeinterface getInt : ()I
    //   463: iload #20
    //   465: imul
    //   466: iconst_1
    //   467: iadd
    //   468: iconst_4
    //   469: imul
    //   470: invokeinterface getInt : (I)I
    //   475: ifeq -> 697
    //   478: iconst_1
    //   479: istore #21
    //   481: iconst_0
    //   482: istore #22
    //   484: goto -> 504
    //   487: aload #19
    //   489: iconst_0
    //   490: iload #22
    //   492: iconst_4
    //   493: imul
    //   494: iadd
    //   495: iconst_0
    //   496: invokeinterface setInt : (II)V
    //   501: iinc #22, 1
    //   504: aload_0
    //   505: invokeinterface getInt : ()I
    //   510: iload #22
    //   512: if_icmpgt -> 487
    //   515: iconst_1
    //   516: istore #22
    //   518: goto -> 630
    //   521: aload_3
    //   522: aload_0
    //   523: invokeinterface getInt : ()I
    //   528: iload #20
    //   530: imul
    //   531: iload #22
    //   533: iadd
    //   534: iconst_4
    //   535: imul
    //   536: invokeinterface getInt : (I)I
    //   541: istore #29
    //   543: iload #29
    //   545: ifeq -> 641
    //   548: iload #29
    //   550: ifge -> 556
    //   553: goto -> 567
    //   556: aload_0
    //   557: invokeinterface getInt : ()I
    //   562: iload #29
    //   564: if_icmpge -> 578
    //   567: aload #16
    //   569: iconst_1
    //   570: invokeinterface setInt : (I)V
    //   575: goto -> 1179
    //   578: aload #19
    //   580: iconst_0
    //   581: iload #29
    //   583: iconst_m1
    //   584: iadd
    //   585: iconst_4
    //   586: imul
    //   587: iadd
    //   588: invokeinterface getInt : (I)I
    //   593: ifne -> 567
    //   596: aload #19
    //   598: iconst_0
    //   599: iload #29
    //   601: iconst_m1
    //   602: iadd
    //   603: iconst_4
    //   604: imul
    //   605: iadd
    //   606: iconst_1
    //   607: invokeinterface setInt : (II)V
    //   612: aload_1
    //   613: iload #29
    //   615: iconst_4
    //   616: imul
    //   617: invokeinterface getInt : (I)I
    //   622: iload #21
    //   624: imul
    //   625: istore #21
    //   627: iinc #22, 1
    //   630: aload_0
    //   631: invokeinterface getInt : ()I
    //   636: iload #22
    //   638: if_icmpge -> 521
    //   641: aload #10
    //   643: invokeinterface getInt : ()I
    //   648: iload #21
    //   650: if_icmplt -> 261
    //   653: aload #7
    //   655: iload #20
    //   657: iconst_4
    //   658: imul
    //   659: iload #14
    //   661: invokeinterface setInt : (II)V
    //   666: iload #14
    //   668: iload #21
    //   670: iadd
    //   671: istore #14
    //   673: iinc #20, 1
    //   676: aload_2
    //   677: invokeinterface getInt : ()I
    //   682: iload #20
    //   684: if_icmpge -> 456
    //   687: aload_2
    //   688: invokeinterface getInt : ()I
    //   693: iconst_1
    //   694: iadd
    //   695: istore #20
    //   697: iload #20
    //   699: iconst_m1
    //   700: iadd
    //   701: istore_2
    //   702: aload #8
    //   704: invokeinterface getInt : ()I
    //   709: iconst_1
    //   710: iadd
    //   711: iload #14
    //   713: if_icmplt -> 261
    //   716: iconst_1
    //   717: istore #14
    //   719: goto -> 844
    //   722: iconst_1
    //   723: istore #19
    //   725: goto -> 766
    //   728: aload #23
    //   730: iconst_0
    //   731: iload #19
    //   733: iconst_m1
    //   734: iadd
    //   735: iconst_4
    //   736: imul
    //   737: iadd
    //   738: aload_3
    //   739: aload_0
    //   740: invokeinterface getInt : ()I
    //   745: iload #14
    //   747: imul
    //   748: iload #19
    //   750: iadd
    //   751: iconst_4
    //   752: imul
    //   753: invokeinterface getInt : (I)I
    //   758: invokeinterface setInt : (II)V
    //   763: iinc #19, 1
    //   766: aload_0
    //   767: invokeinterface getInt : ()I
    //   772: iload #19
    //   774: if_icmpge -> 728
    //   777: aload_0
    //   778: aload #7
    //   780: iload #14
    //   782: iconst_4
    //   783: imul
    //   784: aload #24
    //   786: bipush #8
    //   788: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   793: astore #19
    //   795: aload #5
    //   797: bipush #8
    //   799: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   804: astore #20
    //   806: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   811: astore #21
    //   813: aload #19
    //   815: aload #20
    //   817: aload #21
    //   819: aload #4
    //   821: aload #8
    //   823: aload_1
    //   824: iconst_4
    //   825: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   830: aload #23
    //   832: iconst_0
    //   833: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   838: invokestatic collap : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   841: iinc #14, 1
    //   844: iload #14
    //   846: iload_2
    //   847: if_icmple -> 722
    //   850: iconst_1
    //   851: istore #14
    //   853: goto -> 1111
    //   856: aload #17
    //   858: iconst_0
    //   859: dconst_0
    //   860: dastore
    //   861: iconst_1
    //   862: istore #24
    //   864: goto -> 1071
    //   867: iconst_1
    //   868: istore #19
    //   870: goto -> 911
    //   873: aload #23
    //   875: iconst_0
    //   876: iload #19
    //   878: iconst_m1
    //   879: iadd
    //   880: iconst_4
    //   881: imul
    //   882: iadd
    //   883: aload_3
    //   884: aload_0
    //   885: invokeinterface getInt : ()I
    //   890: iload #24
    //   892: imul
    //   893: iload #19
    //   895: iadd
    //   896: iconst_4
    //   897: imul
    //   898: invokeinterface getInt : (I)I
    //   903: invokeinterface setInt : (II)V
    //   908: iinc #19, 1
    //   911: aload_0
    //   912: invokeinterface getInt : ()I
    //   917: iload #19
    //   919: if_icmpge -> 873
    //   922: aload_0
    //   923: aload #6
    //   925: bipush #8
    //   927: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   932: aload #9
    //   934: bipush #8
    //   936: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   941: new org/renjin/gcc/runtime/IntPtr
    //   944: dup
    //   945: aload #18
    //   947: iconst_0
    //   948: invokespecial <init> : ([II)V
    //   951: checkcast org/renjin/gcc/runtime/Ptr
    //   954: aload #4
    //   956: aload #10
    //   958: aload_1
    //   959: iconst_4
    //   960: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   965: aload #23
    //   967: iconst_0
    //   968: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   973: invokestatic collap : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   976: aload_0
    //   977: aload #7
    //   979: iload #24
    //   981: iconst_4
    //   982: imul
    //   983: aload #6
    //   985: bipush #8
    //   987: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   992: astore #19
    //   994: aload #9
    //   996: bipush #8
    //   998: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1003: astore #20
    //   1005: aload #5
    //   1007: bipush #8
    //   1009: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1014: astore #21
    //   1016: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1021: astore #22
    //   1023: aload #19
    //   1025: aload #20
    //   1027: aload #21
    //   1029: aload #22
    //   1031: aload #4
    //   1033: aload #10
    //   1035: aload #8
    //   1037: aload_1
    //   1038: iconst_4
    //   1039: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1044: aload #23
    //   1046: iconst_0
    //   1047: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1052: new org/renjin/gcc/runtime/DoublePtr
    //   1055: dup
    //   1056: aload #17
    //   1058: iconst_0
    //   1059: invokespecial <init> : ([DI)V
    //   1062: checkcast org/renjin/gcc/runtime/Ptr
    //   1065: invokestatic adjust : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1068: iinc #24, 1
    //   1071: iload #24
    //   1073: iload_2
    //   1074: if_icmple -> 867
    //   1077: aload #11
    //   1079: iload #14
    //   1081: bipush #8
    //   1083: imul
    //   1084: aload #17
    //   1086: iconst_0
    //   1087: daload
    //   1088: invokeinterface setDouble : (ID)V
    //   1093: aload #12
    //   1095: invokeinterface getDouble : ()D
    //   1100: aload #17
    //   1102: iconst_0
    //   1103: daload
    //   1104: dcmpl
    //   1105: ifgt -> 1170
    //   1108: iinc #14, 1
    //   1111: aload #13
    //   1113: invokeinterface getInt : ()I
    //   1118: iload #14
    //   1120: if_icmpge -> 856
    //   1123: aload #13
    //   1125: invokeinterface getInt : ()I
    //   1130: iconst_1
    //   1131: if_icmpgt -> 1145
    //   1134: aload #15
    //   1136: iconst_1
    //   1137: invokeinterface setInt : (I)V
    //   1142: goto -> 1179
    //   1145: aload #16
    //   1147: iconst_3
    //   1148: invokeinterface setInt : (I)V
    //   1153: aload #15
    //   1155: aload #13
    //   1157: invokeinterface getInt : ()I
    //   1162: invokeinterface setInt : (I)V
    //   1167: goto -> 1179
    //   1170: aload #15
    //   1172: iload #14
    //   1174: invokeinterface setInt : (I)V
    //   1179: return
  }
  
  public static Ptr lvector(int paramInt) {
    return (Ptr)IntPtr.malloc(paramInt * 4);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/loglin__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */