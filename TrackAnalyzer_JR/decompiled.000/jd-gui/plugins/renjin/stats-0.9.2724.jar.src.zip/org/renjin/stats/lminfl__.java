package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;

public class lminfl__ {
  static {
  
  }
  
  public static void lminfl_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11) {
    int[] arrayOfInt = new int[1];
    double[] arrayOfDouble = new double[1];
    arrayOfInt[0] = 0;
    arrayOfDouble[0] = 0.0D;
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    Integer.toUnsignedLong(Math.max(Math.max(paramPtr2.getInt(), 0) * paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr4.getInt(), 0));
    Integer.toUnsignedLong(Math.max(paramPtr3.getInt(), 0));
    int j = Math.max(paramPtr3.getInt(), 0);
    Integer.toUnsignedLong(Math.max(j * paramPtr4.getInt(), 0));
    int k = j ^ 0xFFFFFFFF;
    int m = paramPtr3.getInt();
    byte b2 = 1;
    if (1 <= m)
      while (true) {
        boolean bool;
        paramPtr8.setAlignedDouble(b2 + -1, 0.0D);
        if (b2 != m) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    m = paramPtr4.getInt();
    b2 = 1;
    if (1 <= m)
      while (true) {
        int n = paramPtr3.getInt();
        byte b = 1;
        if (1 <= n)
          while (true) {
            boolean bool;
            paramPtr10.setAlignedDouble(b + -1, 0.0D);
            if (b != n) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        paramPtr10.setAlignedDouble(b2 + -1, 1.0D);
        Appl.dqrsl_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr6, paramPtr10, paramPtr10, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(new int[] { 10000 }, 0), (Ptr)new IntPtr(arrayOfInt, 0));
        n = paramPtr3.getInt();
        b = 1;
        if (1 <= n)
          while (true) {
            boolean bool;
            paramPtr8.setAlignedDouble(b + -1, paramPtr8.getAlignedDouble(b + -1) + paramPtr10.getAlignedDouble(b + -1) * paramPtr10.getAlignedDouble(b + -1));
            if (b != n) {
              bool = false;
            } else {
              bool = true;
            } 
            b++;
            if (!bool)
              continue; 
            break;
          }  
        if (b2 != m) {
          n = 0;
        } else {
          n = 1;
        } 
        b2++;
        if (n == 0)
          continue; 
        break;
      }  
    m = paramPtr3.getInt();
    b2 = 1;
    if (1 <= m)
      while (true) {
        boolean bool;
        if (paramPtr8.getAlignedDouble(b2 + -1) >= 1.0D - paramPtr11.getDouble())
          paramPtr8.setAlignedDouble(b2 + -1, 1.0D); 
        if (b2 != m) {
          bool = false;
        } else {
          bool = true;
        } 
        b2++;
        if (!bool)
          continue; 
        break;
      }  
    if (paramPtr5.getInt() != 0) {
      int n = paramPtr3.getInt();
      byte b = 1;
      if (1 <= n)
        while (true) {
          m = paramPtr3.getInt();
          b2 = 1;
          if (1 <= m)
            while (true) {
              boolean bool;
              paramPtr10.setAlignedDouble(b2 + -1, 0.0D);
              if (b2 != m) {
                bool = false;
              } else {
                bool = true;
              } 
              b2++;
              if (!bool)
                continue; 
              break;
            }  
          if (paramPtr8.getAlignedDouble(b + -1) < 1.0D) {
            paramPtr10.setAlignedDouble(b + -1, paramPtr7.getAlignedDouble(b + -1) / (1.0D - paramPtr8.getAlignedDouble(b + -1)));
            Appl.dqrsl_(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr6, paramPtr10, (Ptr)new DoublePtr(arrayOfDouble, 0), paramPtr10, (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new DoublePtr(arrayOfDouble, 0), (Ptr)new IntPtr(new int[] { 1000 }, 0), (Ptr)new IntPtr(arrayOfInt, 0));
            Appl.dtrsl_(paramPtr1, paramPtr2, paramPtr4, paramPtr10, (Ptr)new IntPtr(new int[] { 1 }, 0), (Ptr)new IntPtr(arrayOfInt, 0));
          } 
          m = paramPtr4.getInt();
          b2 = 1;
          if (1 <= m)
            while (true) {
              boolean bool;
              paramPtr9.setAlignedDouble(b2 * j + k + b, paramPtr10.getAlignedDouble(b2 + -1));
              if (b2 != m) {
                bool = false;
              } else {
                bool = true;
              } 
              b2++;
              if (!bool)
                continue; 
              break;
            }  
          if (b != n) {
            m = 0;
          } else {
            m = 1;
          } 
          b++;
          if (m == 0)
            continue; 
          break;
        }  
    } 
    double d1 = (paramPtr3.getInt() - paramPtr4.getInt() + -1);
    double d2 = 0.0D;
    int i = paramPtr3.getInt();
    byte b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        d2 = paramPtr7.getAlignedDouble(b1 + -1) * paramPtr7.getAlignedDouble(b1 + -1) + d2;
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
    i = paramPtr3.getInt();
    b1 = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        if (paramPtr8.getAlignedDouble(b1 + -1) >= 1.0D) {
          paramPtr10.setAlignedDouble(b1 + -1, Mathlib.sqrt(d2 / d1));
        } else {
          paramPtr10.setAlignedDouble(b1 + -1, Mathlib.sqrt((d2 - paramPtr7.getAlignedDouble(b1 + -1) * paramPtr7.getAlignedDouble(b1 + -1) / (1.0D - paramPtr8.getAlignedDouble(b1 + -1))) / d1));
        } 
        if (b1 != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b1++;
        if (!bool)
          continue; 
        break;
      }  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/lminfl__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */