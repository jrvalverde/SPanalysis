package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;

public class approx__ {
  static {
  
  }
  
  public static void R_approx(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    MixedPtr mixedPtr = MixedPtr.malloc(36);
    mixedPtr.setDouble(0.0D);
    mixedPtr.setAlignedDouble(1, 0.0D);
    mixedPtr.setAlignedDouble(2, 0.0D);
    mixedPtr.setAlignedDouble(3, 0.0D);
    mixedPtr.setAlignedInt(8, 0);
    switch (paramPtr6.getInt()) {
      case 1:
        break;
      case 2:
        if (Arith.R_finite(paramPtr9.getDouble()) == 0 || paramPtr9.getDouble() < 0.0D || paramPtr9.getDouble() > 1.0D)
          Error.Rf_error(GetText.gettext(new BytePtr("approx(): invalid f value\000".getBytes(), 0)), new Object[0]); 
        mixedPtr.setAlignedDouble(3, paramPtr9.getDouble());
        mixedPtr.setAlignedDouble(2, 1.0D - paramPtr9.getDouble());
        break;
      default:
        Error.Rf_error(GetText.gettext(new BytePtr("approx(): invalid interpolation method\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    for (byte b2 = 0; paramPtr3.getInt() > b2; b2++) {
      if (Arith.R_IsNA(paramPtr1.getDouble(b2 * 8)) != 0 || Arith.R_IsNA(paramPtr2.getDouble(b2 * 8)) != 0)
        Error.Rf_error(GetText.gettext(new BytePtr("approx(): attempted to interpolate NA values\000".getBytes(), 0)), new Object[0]); 
    } 
    mixedPtr.setAlignedInt(8, paramPtr6.getInt());
    mixedPtr.setDouble(paramPtr7.getDouble());
    mixedPtr.setAlignedDouble(1, paramPtr8.getDouble());
    for (byte b1 = 0; paramPtr5.getInt() > b1; b1++) {
      if (Arith.R_IsNA(paramPtr4.getDouble(b1 * 8)) == 0) {
        int i = paramPtr3.getInt();
        paramPtr4.setDouble(b1 * 8, approx1(paramPtr4.getDouble(b1 * 8), paramPtr1, paramPtr2, i, (Ptr)mixedPtr));
      } 
    } 
  }
  
  public static void R_approxfun(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9) {
    MixedPtr mixedPtr = MixedPtr.malloc(36);
    mixedPtr.setDouble(0.0D);
    mixedPtr.setAlignedDouble(1, 0.0D);
    mixedPtr.setAlignedDouble(2, 0.0D);
    mixedPtr.setAlignedDouble(3, 0.0D);
    mixedPtr.setAlignedInt(8, 0);
    mixedPtr.setAlignedDouble(3, paramPtr9.getDouble());
    mixedPtr.setAlignedDouble(2, 1.0D - paramPtr9.getDouble());
    mixedPtr.setAlignedInt(8, paramPtr6.getInt());
    mixedPtr.setDouble(paramPtr7.getDouble());
    mixedPtr.setAlignedDouble(1, paramPtr8.getDouble());
    for (byte b = 0; paramPtr5.getInt() > b; b++) {
      if (Arith.R_IsNA(paramPtr4.getDouble(b * 8)) == 0) {
        int i = paramPtr3.getInt();
        paramPtr4.setDouble(b * 8, approx1(paramPtr4.getDouble(b * 8), paramPtr1, paramPtr2, i, (Ptr)mixedPtr));
      } 
    } 
  }
  
  public static void R_approxtest(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    switch (paramPtr4.getInt()) {
      case 1:
        break;
      case 2:
        if (Arith.R_finite(paramPtr5.getDouble()) != 0 && paramPtr5.getDouble() >= 0.0D && paramPtr5.getDouble() <= 1.0D)
          break; 
        Error.Rf_error(GetText.gettext(new BytePtr("approx(): invalid f value\000".getBytes(), 0)), new Object[0]);
        break;
      default:
        Error.Rf_error(GetText.gettext(new BytePtr("approx(): invalid interpolation method\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    for (byte b = 0; paramPtr3.getInt() > b; b++) {
      if (Arith.R_IsNA(paramPtr1.getDouble(b * 8)) != 0 || Arith.R_IsNA(paramPtr2.getDouble(b * 8)) != 0)
        Error.Rf_error(GetText.gettext(new BytePtr("approx(): attempted to interpolate NA values\000".getBytes(), 0)), new Object[0]); 
    } 
  }
  
  public static double approx1(double paramDouble, Ptr paramPtr1, Ptr paramPtr2, int paramInt, Ptr paramPtr3) {
    if (paramInt != 0) {
      int i = 0;
      int j = paramInt + -1;
      if (paramPtr1.getDouble(0) <= paramDouble) {
        if (paramPtr1.getDouble(j * 8) >= paramDouble) {
          while (j + -1 > i) {
            paramInt = (i + j) / 2;
            if (paramPtr1.getDouble(paramInt * 8) <= paramDouble) {
              i = paramInt;
              continue;
            } 
            j = paramInt;
          } 
          return (paramPtr1.getDouble(j * 8) != paramDouble) ? ((paramPtr1.getDouble(i * 8) != paramDouble) ? ((paramPtr3.getAlignedInt(8) != 1) ? (paramPtr2.getDouble(i * 8) * paramPtr3.getAlignedDouble(2) + paramPtr2.getDouble(j * 8) * paramPtr3.getAlignedDouble(3)) : (paramPtr2.getDouble(i * 8) + (paramPtr2.getDouble(j * 8) - paramPtr2.getDouble(i * 8)) * (paramDouble - paramPtr1.getDouble(i * 8)) / (paramPtr1.getDouble(j * 8) - paramPtr1.getDouble(i * 8)))) : paramPtr2.getDouble(i * 8)) : paramPtr2.getDouble(j * 8);
        } 
        return paramPtr3.getAlignedDouble(1);
      } 
      return paramPtr3.getDouble();
    } 
    return Arith.R_NaN;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/approx__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */