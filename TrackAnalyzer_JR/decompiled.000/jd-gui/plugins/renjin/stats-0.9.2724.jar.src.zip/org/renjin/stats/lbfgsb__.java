package org.renjin.stats;

import org.renjin.appl.Appl;
import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntFieldPtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Mathlib;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gcc.runtime.Stdlib;
import org.renjin.gnur.api.Print;
import org.renjin.math.Blas;

public class lbfgsb__ {
  public static int lwa$4116;
  
  public static int lt$4114;
  
  public static int ld$4112;
  
  public static int lr$4113;
  
  public static int lz$4115;
  
  public static int lsnd$4111;
  
  public static int lwn$4117;
  
  public static int lwt$4120;
  
  public static int lss$4118;
  
  public static int lsy$4121;
  
  public static int lwy$4122;
  
  public static int lws$4119;
  
  public static int boxed$4172;
  
  public static int cnstnd$4171;
  
  public static int prjctd$4170;
  
  public static int info$4184;
  
  public static double tol$4193;
  
  public static int nfree$4187;
  
  public static int nskip$4176;
  
  public static int nintol$4174;
  
  public static int nint$4182;
  
  public static int nfgv$4183;
  
  public static int iter$4180;
  
  public static int nenter$4190;
  
  public static int ileave$4189;
  
  public static int nact$4188;
  
  public static int iword$4186;
  
  public static int ifun$4185;
  
  public static int itail$4179;
  
  public static int iback$4175;
  
  public static int updatd$4173;
  
  public static int iupdat$4181;
  
  public static double theta$4191;
  
  public static int head$4177;
  
  public static int col$4178;
  
  public static double dtd$4201;
  
  public static double gdold$4200;
  
  public static double stpmx$4197;
  
  public static double stp$4199;
  
  public static double sbgnrm$4198;
  
  public static double gd$4196;
  
  public static double dnorm$4194;
  
  public static double fold$4192;
  
  public static double epsmch$4195;
  
  public static double stmax$4848;
  
  public static double stmin$4847;
  
  public static double gy$4841;
  
  public static double fy$4844;
  
  public static double sty$4846;
  
  public static double gx$4840;
  
  public static double fx$4843;
  
  public static double stx$4845;
  
  public static double width1$4850;
  
  public static double width$4849;
  
  public static double gtest$4839;
  
  public static double ginit$4838;
  
  public static double finit$4842;
  
  public static int stage$4836;
  
  public static int brackt$4837;
  
  public static int c__11;
  
  public static int c__1;
  
  public static double $dcsrch$width1;
  
  public static double $dcsrch$width;
  
  public static double[] $dcsrch$stmax = new double[1];
  
  public static double[] $dcsrch$stmin = new double[1];
  
  public static double[] $dcsrch$sty = new double[1];
  
  public static double[] $dcsrch$stx = new double[1];
  
  public static double[] $dcsrch$fy = new double[1];
  
  public static double[] $dcsrch$fx = new double[1];
  
  public static double $dcsrch$finit;
  
  public static double[] $dcsrch$gy = new double[1];
  
  public static double[] $dcsrch$gx = new double[1];
  
  public static double $dcsrch$gtest;
  
  public static double $dcsrch$ginit;
  
  public static int[] $dcsrch$brackt = new int[1];
  
  public static int $dcsrch$stage;
  
  public static double[] $mainlb$dtd = new double[1];
  
  public static double[] $mainlb$gdold = new double[1];
  
  public static double[] $mainlb$stp = new double[1];
  
  public static double[] $mainlb$sbgnrm = new double[1];
  
  public static double[] $mainlb$stpmx = new double[1];
  
  public static double[] $mainlb$gd = new double[1];
  
  public static double[] $mainlb$epsmch = new double[1];
  
  public static double[] $mainlb$dnorm = new double[1];
  
  public static double $mainlb$tol;
  
  public static double[] $mainlb$fold = new double[1];
  
  public static double[] $mainlb$theta = new double[1];
  
  public static int[] $mainlb$nenter = new int[1];
  
  public static int[] $mainlb$ileave = new int[1];
  
  public static int $mainlb$nact;
  
  public static int[] $mainlb$nfree = new int[1];
  
  public static int[] $mainlb$iword = new int[1];
  
  public static int[] $mainlb$ifun = new int[1];
  
  public static int[] $mainlb$info = new int[1];
  
  public static int[] $mainlb$nfgv = new int[1];
  
  public static int[] $mainlb$nint = new int[1];
  
  public static int[] $mainlb$iupdat = new int[1];
  
  public static int[] $mainlb$iter = new int[1];
  
  public static int[] $mainlb$itail = new int[1];
  
  public static int[] $mainlb$col = new int[1];
  
  public static int[] $mainlb$head = new int[1];
  
  public static int $mainlb$nskip;
  
  public static int[] $mainlb$iback = new int[1];
  
  public static int $mainlb$nintol;
  
  public static int[] $mainlb$updatd = new int[1];
  
  public static int[] $mainlb$boxed = new int[1];
  
  public static int[] $mainlb$cnstnd = new int[1];
  
  public static int[] $mainlb$prjctd = new int[1];
  
  public static int $setulb$lwy;
  
  public static int $setulb$lsy;
  
  public static int $setulb$lwt;
  
  public static int $setulb$lws;
  
  public static int $setulb$lss;
  
  public static int $setulb$lwn;
  
  public static int $setulb$lwa;
  
  public static int $setulb$lz;
  
  public static int $setulb$lt;
  
  public static int $setulb$lr;
  
  public static int $setulb$ld;
  
  public static int $setulb$lsnd;
  
  static {
    lwa$4116 = 0;
    lt$4114 = 0;
    ld$4112 = 0;
    lr$4113 = 0;
    lz$4115 = 0;
    lsnd$4111 = 0;
    lwn$4117 = 0;
    lwt$4120 = 0;
    lss$4118 = 0;
    lsy$4121 = 0;
    lwy$4122 = 0;
    lws$4119 = 0;
    boxed$4172 = 0;
    cnstnd$4171 = 0;
    prjctd$4170 = 0;
    info$4184 = 0;
    tol$4193 = 0.0D;
    nfree$4187 = 0;
    nskip$4176 = 0;
    nintol$4174 = 0;
    nint$4182 = 0;
    nfgv$4183 = 0;
    iter$4180 = 0;
    nenter$4190 = 0;
    ileave$4189 = 0;
    nact$4188 = 0;
    iword$4186 = 0;
    ifun$4185 = 0;
    itail$4179 = 0;
    iback$4175 = 0;
    updatd$4173 = 0;
    iupdat$4181 = 0;
    theta$4191 = 0.0D;
    head$4177 = 0;
    col$4178 = 0;
    dtd$4201 = 0.0D;
    gdold$4200 = 0.0D;
    stpmx$4197 = 0.0D;
    stp$4199 = 0.0D;
    sbgnrm$4198 = 0.0D;
    gd$4196 = 0.0D;
    dnorm$4194 = 0.0D;
    fold$4192 = 0.0D;
    epsmch$4195 = 0.0D;
    stmax$4848 = 0.0D;
    stmin$4847 = 0.0D;
    gy$4841 = 0.0D;
    fy$4844 = 0.0D;
    sty$4846 = 0.0D;
    gx$4840 = 0.0D;
    fx$4843 = 0.0D;
    stx$4845 = 0.0D;
    width1$4850 = 0.0D;
    width$4849 = 0.0D;
    gtest$4839 = 0.0D;
    ginit$4838 = 0.0D;
    finit$4842 = 0.0D;
    stage$4836 = 0;
    brackt$4837 = 0;
    c__11 = 11;
    c__1 = 1;
    $dcsrch$width1 = 0.0D;
    $dcsrch$width = 0.0D;
    $dcsrch$stmax[0] = 0.0D;
    $dcsrch$stmin[0] = 0.0D;
    $dcsrch$sty[0] = 0.0D;
    $dcsrch$stx[0] = 0.0D;
    $dcsrch$fy[0] = 0.0D;
    $dcsrch$fx[0] = 0.0D;
    $dcsrch$finit = 0.0D;
    $dcsrch$gy[0] = 0.0D;
    $dcsrch$gx[0] = 0.0D;
    $dcsrch$gtest = 0.0D;
    $dcsrch$ginit = 0.0D;
    $dcsrch$brackt[0] = 0;
    $dcsrch$stage = 0;
    $mainlb$dtd[0] = 0.0D;
    $mainlb$gdold[0] = 0.0D;
    $mainlb$stp[0] = 0.0D;
    $mainlb$sbgnrm[0] = 0.0D;
    $mainlb$stpmx[0] = 0.0D;
    $mainlb$gd[0] = 0.0D;
    $mainlb$epsmch[0] = 0.0D;
    $mainlb$dnorm[0] = 0.0D;
    $mainlb$tol = 0.0D;
    $mainlb$fold[0] = 0.0D;
    $mainlb$theta[0] = 0.0D;
    $mainlb$nenter[0] = 0;
    $mainlb$ileave[0] = 0;
    $mainlb$nact = 0;
    $mainlb$nfree[0] = 0;
    $mainlb$iword[0] = 0;
    $mainlb$ifun[0] = 0;
    $mainlb$info[0] = 0;
    $mainlb$nfgv[0] = 0;
    $mainlb$nint[0] = 0;
    $mainlb$iupdat[0] = 0;
    $mainlb$iter[0] = 0;
    $mainlb$itail[0] = 0;
    $mainlb$col[0] = 0;
    $mainlb$head[0] = 0;
    $mainlb$nskip = 0;
    $mainlb$iback[0] = 0;
    $mainlb$nintol = 0;
    $mainlb$updatd[0] = 0;
    $mainlb$boxed[0] = 0;
    $mainlb$cnstnd[0] = 0;
    $mainlb$prjctd[0] = 0;
    $setulb$lwy = 0;
    $setulb$lsy = 0;
    $setulb$lwt = 0;
    $setulb$lws = 0;
    $setulb$lss = 0;
    $setulb$lwn = 0;
    $setulb$lwa = 0;
    $setulb$lz = 0;
    $setulb$lt = 0;
    $setulb$lr = 0;
    $setulb$ld = 0;
    $setulb$lsnd = 0;
  }
  
  public static void active(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, int paramInt2, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8) {
    paramPtr5 = paramPtr5.pointerPlus(-4);
    paramPtr4 = paramPtr4.pointerPlus(-8);
    paramPtr3 = paramPtr3.pointerPlus(-4);
    paramPtr2 = paramPtr2.pointerPlus(-8);
    paramPtr1 = paramPtr1.pointerPlus(-8);
    byte b2 = 0;
    paramPtr6.setInt(0);
    paramPtr7.setInt(0);
    paramPtr8.setInt(1);
    for (byte b3 = 1; b3 <= paramInt1; b3++) {
      if (paramPtr3.getInt(b3 * 4) > 0)
        if (paramPtr3.getInt(b3 * 4) > 2 || paramPtr4.getDouble(b3 * 8) > paramPtr1.getDouble(b3 * 8)) {
          if (paramPtr3.getInt(b3 * 4) > 1 && paramPtr4.getDouble(b3 * 8) >= paramPtr2.getDouble(b3 * 8)) {
            if (paramPtr4.getDouble(b3 * 8) > paramPtr2.getDouble(b3 * 8)) {
              paramPtr6.setInt(1);
              paramPtr4.setDouble(b3 * 8, paramPtr2.getDouble(b3 * 8));
            } 
            b2++;
          } 
        } else {
          if (paramPtr4.getDouble(b3 * 8) < paramPtr1.getDouble(b3 * 8)) {
            paramPtr6.setInt(1);
            paramPtr4.setDouble(b3 * 8, paramPtr1.getDouble(b3 * 8));
          } 
          b2++;
        }  
    } 
    for (byte b1 = 1; b1 <= paramInt1; b1++) {
      if (paramPtr3.getInt(b1 * 4) != 2)
        paramPtr8.setInt(0); 
      if (paramPtr3.getInt(b1 * 4) != 0) {
        paramPtr7.setInt(1);
        if (paramPtr3.getInt(b1 * 4) != 2 || paramPtr2.getDouble(b1 * 8) - paramPtr1.getDouble(b1 * 8) > 0.0D) {
          paramPtr5.setInt(b1 * 4, 0);
        } else {
          paramPtr5.setInt(b1 * 4, 3);
        } 
      } else {
        paramPtr5.setInt(b1 * 4, -1);
      } 
    } 
    if (paramInt2 >= 0) {
      if (paramPtr6.getInt() != 0)
        Print.Rprintf(new BytePtr("The initial X is infeasible.  Restart with its projection.\n\000".getBytes(), 0), new Object[0]); 
      if (paramPtr7.getInt() == 0)
        Print.Rprintf(new BytePtr("This problem is unconstrained.\n\000".getBytes(), 0), new Object[0]); 
    } 
    if (paramInt2 > 0)
      Print.Rprintf(new BytePtr("At X0, %d variables are exactly at the bounds\n\000".getBytes(), 0), new Object[] { Integer.valueOf(b2) }); 
  }
  
  public static void bmv(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = paramInt;
    int i = arrayOfInt[0] + 1;
    Ptr ptr = paramPtr2.pointerPlus(-(i * 8));
    paramInt = arrayOfInt[0];
    paramPtr1 = paramPtr1.pointerPlus(-((paramInt + 1) * 8));
    paramPtr2 = paramPtr5.pointerPlus(-8);
    paramPtr5 = paramPtr4.pointerPlus(-8);
    if (paramPtr3.getInt() != 0) {
      int j = paramPtr3.getInt();
      paramPtr2.setDouble((paramPtr3.getInt() + 1) * 8, paramPtr5.getDouble((paramPtr3.getInt() + 1) * 8));
      for (byte b = 2; b <= j; b++) {
        int k = paramPtr3.getInt() + b;
        double d = 0.0D;
        for (byte b1 = 1; b + -1 >= b1; b1++)
          d = paramPtr1.getDouble((b1 * paramInt + b) * 8) * paramPtr5.getDouble(b1 * 8) / paramPtr1.getDouble((paramInt + 1) * 8 * b1) + d; 
        paramPtr2.setDouble(k * 8, paramPtr5.getDouble(k * 8) + d);
      } 
      Ptr ptr1 = ptr.pointerPlus(i * 8);
      Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt, 0);
      Ptr ptr3 = paramPtr2.pointerPlus((paramPtr3.getInt() + 1) * 8);
      Appl.dtrsl_(ptr1, ptr2, paramPtr3, ptr3, IntFieldPtr.addressOf(lbfgsb__.class, "c__11"), paramPtr6);
      if (paramPtr6.getInt() == 0) {
        for (byte b1 = 1; b1 <= j; b1++)
          paramPtr2.setDouble(b1 * 8, paramPtr5.getDouble(b1 * 8) / Mathlib.sqrt(paramPtr1.getDouble((paramInt + 1) * 8 * b1))); 
        paramPtr5 = ptr.pointerPlus(i * 8);
        Ptr ptr4 = (Ptr)new IntPtr(arrayOfInt, 0);
        Ptr ptr5 = paramPtr2.pointerPlus((paramPtr3.getInt() + 1) * 8);
        Appl.dtrsl_(paramPtr5, ptr4, paramPtr3, ptr5, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"), paramPtr6);
        if (paramPtr6.getInt() == 0) {
          byte b2;
          for (b2 = 1; b2 <= j; b2++)
            paramPtr2.setDouble(b2 * 8, -paramPtr2.getDouble(b2 * 8) / Mathlib.sqrt(paramPtr1.getDouble((paramInt + 1) * 8 * b2))); 
          for (b2 = 1; b2 <= j; b2++) {
            double d = 0.0D;
            for (int k = b2 + 1; k <= j; k++)
              d = paramPtr1.getDouble((b2 * paramInt + k) * 8) * paramPtr2.getDouble((paramPtr3.getInt() + k) * 8) / paramPtr1.getDouble((paramInt + 1) * 8 * b2) + d; 
            paramPtr2.setDouble(b2 * 8, paramPtr2.getDouble(b2 * 8) + d);
          } 
        } 
      } 
    } 
  }
  
  public static void cauchy(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, int paramInt2, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, int paramInt3, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray int
    //   3: astore #40
    //   5: aload #40
    //   7: iconst_0
    //   8: iload_0
    //   9: iastore
    //   10: iconst_1
    //   11: newarray int
    //   13: astore #28
    //   15: iconst_1
    //   16: newarray double
    //   18: astore #34
    //   20: iconst_1
    //   21: newarray double
    //   23: astore #37
    //   25: iconst_1
    //   26: newarray double
    //   28: astore #38
    //   30: iconst_1
    //   31: newarray double
    //   33: astore #39
    //   35: aload #28
    //   37: iconst_0
    //   38: iconst_0
    //   39: iastore
    //   40: aload #38
    //   42: iconst_0
    //   43: dconst_0
    //   44: dastore
    //   45: dconst_0
    //   46: dstore #46
    //   48: dconst_0
    //   49: dstore #48
    //   51: aload #10
    //   53: bipush #-8
    //   55: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   60: astore_0
    //   61: aload #9
    //   63: bipush #-8
    //   65: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   70: astore #9
    //   72: aload #8
    //   74: bipush #-8
    //   76: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   81: astore #8
    //   83: aload #7
    //   85: bipush #-4
    //   87: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   92: astore #7
    //   94: aload #6
    //   96: bipush #-4
    //   98: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   103: astore #6
    //   105: aload #5
    //   107: bipush #-8
    //   109: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   114: astore #41
    //   116: aload #4
    //   118: bipush #-4
    //   120: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   125: astore #42
    //   127: aload_3
    //   128: bipush #-8
    //   130: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   135: astore_3
    //   136: aload_2
    //   137: bipush #-8
    //   139: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   144: astore_2
    //   145: aload_1
    //   146: bipush #-8
    //   148: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   153: astore #5
    //   155: aload #22
    //   157: bipush #-8
    //   159: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   164: astore #10
    //   166: aload #21
    //   168: bipush #-8
    //   170: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   175: astore #21
    //   177: aload #20
    //   179: bipush #-8
    //   181: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   186: astore_1
    //   187: aload #19
    //   189: bipush #-8
    //   191: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   196: astore #4
    //   198: iload #11
    //   200: iconst_1
    //   201: iadd
    //   202: istore #19
    //   204: aload #15
    //   206: iload #19
    //   208: bipush #8
    //   210: imul
    //   211: ineg
    //   212: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   217: astore #15
    //   219: iload #11
    //   221: iconst_1
    //   222: iadd
    //   223: istore #20
    //   225: aload #14
    //   227: iload #20
    //   229: bipush #8
    //   231: imul
    //   232: ineg
    //   233: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   238: astore #14
    //   240: aload #40
    //   242: iconst_0
    //   243: iaload
    //   244: istore #22
    //   246: aload #13
    //   248: iload #22
    //   250: iconst_1
    //   251: iadd
    //   252: bipush #8
    //   254: imul
    //   255: ineg
    //   256: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   261: astore #13
    //   263: aload #40
    //   265: iconst_0
    //   266: iaload
    //   267: istore #50
    //   269: aload #12
    //   271: iload #50
    //   273: iconst_1
    //   274: iadd
    //   275: bipush #8
    //   277: imul
    //   278: ineg
    //   279: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   284: astore #12
    //   286: aload #25
    //   288: invokeinterface getDouble : ()D
    //   293: dconst_0
    //   294: dcmpg
    //   295: ifle -> 301
    //   298: goto -> 382
    //   301: iload #24
    //   303: ifge -> 309
    //   306: goto -> 330
    //   309: new org/renjin/gcc/runtime/BytePtr
    //   312: dup
    //   313: ldc_w 'Subgnorm = 0.  GCP = X.\\n '
    //   316: invokevirtual getBytes : ()[B
    //   319: iconst_0
    //   320: invokespecial <init> : ([BI)V
    //   323: iconst_0
    //   324: anewarray java/lang/Object
    //   327: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   330: new org/renjin/gcc/runtime/IntPtr
    //   333: dup
    //   334: aload #40
    //   336: iconst_0
    //   337: invokespecial <init> : ([II)V
    //   340: checkcast org/renjin/gcc/runtime/Ptr
    //   343: aload #5
    //   345: bipush #8
    //   347: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   352: ldc org/renjin/stats/lbfgsb__
    //   354: ldc_w 'c__1'
    //   357: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   360: aload_0
    //   361: bipush #8
    //   363: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   368: ldc org/renjin/stats/lbfgsb__
    //   370: ldc_w 'c__1'
    //   373: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   376: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   379: goto -> 3492
    //   382: iconst_1
    //   383: istore #25
    //   385: aload #40
    //   387: iconst_0
    //   388: iaload
    //   389: iconst_1
    //   390: iadd
    //   391: istore #45
    //   393: iconst_0
    //   394: istore #51
    //   396: iconst_0
    //   397: istore #52
    //   399: dconst_0
    //   400: dstore #53
    //   402: aload #28
    //   404: iconst_0
    //   405: aload #17
    //   407: invokeinterface getInt : ()I
    //   412: iconst_1
    //   413: ishl
    //   414: iastore
    //   415: dconst_0
    //   416: dstore #55
    //   418: iload #24
    //   420: bipush #98
    //   422: if_icmpgt -> 428
    //   425: goto -> 449
    //   428: new org/renjin/gcc/runtime/BytePtr
    //   431: dup
    //   432: ldc_w '\\n---------------- CAUCHY entered-------------------\\n\\n '
    //   435: invokevirtual getBytes : ()[B
    //   438: iconst_0
    //   439: invokespecial <init> : ([BI)V
    //   442: iconst_0
    //   443: anewarray java/lang/Object
    //   446: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   449: iconst_1
    //   450: istore #43
    //   452: goto -> 471
    //   455: aload #4
    //   457: iload #43
    //   459: bipush #8
    //   461: imul
    //   462: dconst_0
    //   463: invokeinterface setDouble : (ID)V
    //   468: iinc #43, 1
    //   471: iload #43
    //   473: aload #28
    //   475: iconst_0
    //   476: iaload
    //   477: if_icmple -> 455
    //   480: iconst_1
    //   481: istore #43
    //   483: goto -> 1304
    //   486: aload #41
    //   488: iload #43
    //   490: bipush #8
    //   492: imul
    //   493: invokeinterface getDouble : (I)D
    //   498: dneg
    //   499: dstore #57
    //   501: aload #7
    //   503: iload #43
    //   505: iconst_4
    //   506: imul
    //   507: invokeinterface getInt : (I)I
    //   512: iconst_3
    //   513: if_icmpne -> 519
    //   516: goto -> 807
    //   519: aload #7
    //   521: iload #43
    //   523: iconst_4
    //   524: imul
    //   525: invokeinterface getInt : (I)I
    //   530: iconst_m1
    //   531: if_icmpne -> 537
    //   534: goto -> 807
    //   537: aload #42
    //   539: iload #43
    //   541: iconst_4
    //   542: imul
    //   543: invokeinterface getInt : (I)I
    //   548: iconst_2
    //   549: if_icmple -> 555
    //   552: goto -> 581
    //   555: aload #5
    //   557: iload #43
    //   559: bipush #8
    //   561: imul
    //   562: invokeinterface getDouble : (I)D
    //   567: aload_2
    //   568: iload #43
    //   570: bipush #8
    //   572: imul
    //   573: invokeinterface getDouble : (I)D
    //   578: dsub
    //   579: dstore #46
    //   581: aload #42
    //   583: iload #43
    //   585: iconst_4
    //   586: imul
    //   587: invokeinterface getInt : (I)I
    //   592: iconst_1
    //   593: if_icmpgt -> 599
    //   596: goto -> 625
    //   599: aload_3
    //   600: iload #43
    //   602: bipush #8
    //   604: imul
    //   605: invokeinterface getDouble : (I)D
    //   610: aload #5
    //   612: iload #43
    //   614: bipush #8
    //   616: imul
    //   617: invokeinterface getDouble : (I)D
    //   622: dsub
    //   623: dstore #48
    //   625: aload #42
    //   627: iload #43
    //   629: iconst_4
    //   630: imul
    //   631: invokeinterface getInt : (I)I
    //   636: iconst_2
    //   637: if_icmple -> 643
    //   640: goto -> 659
    //   643: dload #46
    //   645: dconst_0
    //   646: dcmpg
    //   647: ifle -> 653
    //   650: goto -> 659
    //   653: iconst_1
    //   654: istore #29
    //   656: goto -> 662
    //   659: iconst_0
    //   660: istore #29
    //   662: iload #29
    //   664: istore #29
    //   666: aload #42
    //   668: iload #43
    //   670: iconst_4
    //   671: imul
    //   672: invokeinterface getInt : (I)I
    //   677: iconst_1
    //   678: if_icmpgt -> 684
    //   681: goto -> 700
    //   684: dload #48
    //   686: dconst_0
    //   687: dcmpg
    //   688: ifle -> 694
    //   691: goto -> 700
    //   694: iconst_1
    //   695: istore #44
    //   697: goto -> 703
    //   700: iconst_0
    //   701: istore #44
    //   703: aload #7
    //   705: iload #43
    //   707: iconst_4
    //   708: imul
    //   709: iconst_0
    //   710: invokeinterface setInt : (II)V
    //   715: iload #29
    //   717: ifne -> 723
    //   720: goto -> 748
    //   723: dload #57
    //   725: dconst_0
    //   726: dcmpg
    //   727: ifle -> 733
    //   730: goto -> 807
    //   733: aload #7
    //   735: iload #43
    //   737: iconst_4
    //   738: imul
    //   739: iconst_1
    //   740: invokeinterface setInt : (II)V
    //   745: goto -> 807
    //   748: iload #44
    //   750: ifne -> 756
    //   753: goto -> 781
    //   756: dload #57
    //   758: dconst_0
    //   759: dcmpl
    //   760: ifge -> 766
    //   763: goto -> 807
    //   766: aload #7
    //   768: iload #43
    //   770: iconst_4
    //   771: imul
    //   772: iconst_2
    //   773: invokeinterface setInt : (II)V
    //   778: goto -> 807
    //   781: dload #57
    //   783: invokestatic abs : (D)D
    //   786: dconst_0
    //   787: dcmpg
    //   788: ifle -> 794
    //   791: goto -> 807
    //   794: aload #7
    //   796: iload #43
    //   798: iconst_4
    //   799: imul
    //   800: bipush #-3
    //   802: invokeinterface setInt : (II)V
    //   807: aload #18
    //   809: invokeinterface getInt : ()I
    //   814: istore #29
    //   816: aload #7
    //   818: iload #43
    //   820: iconst_4
    //   821: imul
    //   822: invokeinterface getInt : (I)I
    //   827: ifne -> 833
    //   830: goto -> 867
    //   833: aload #7
    //   835: iload #43
    //   837: iconst_4
    //   838: imul
    //   839: invokeinterface getInt : (I)I
    //   844: iconst_m1
    //   845: if_icmpne -> 851
    //   848: goto -> 867
    //   851: aload #9
    //   853: iload #43
    //   855: bipush #8
    //   857: imul
    //   858: dconst_0
    //   859: invokeinterface setDouble : (ID)V
    //   864: goto -> 1301
    //   867: aload #9
    //   869: iload #43
    //   871: bipush #8
    //   873: imul
    //   874: dload #57
    //   876: invokeinterface setDouble : (ID)V
    //   881: dload #55
    //   883: dload #57
    //   885: dload #57
    //   887: dmul
    //   888: dsub
    //   889: dstore #55
    //   891: aload #17
    //   893: invokeinterface getInt : ()I
    //   898: istore #44
    //   900: iconst_1
    //   901: istore #59
    //   903: goto -> 1026
    //   906: aload #4
    //   908: iload #59
    //   910: bipush #8
    //   912: imul
    //   913: aload #4
    //   915: iload #59
    //   917: bipush #8
    //   919: imul
    //   920: invokeinterface getDouble : (I)D
    //   925: aload #12
    //   927: iload #29
    //   929: iload #50
    //   931: imul
    //   932: iload #43
    //   934: iadd
    //   935: bipush #8
    //   937: imul
    //   938: invokeinterface getDouble : (I)D
    //   943: dload #57
    //   945: dmul
    //   946: dadd
    //   947: invokeinterface setDouble : (ID)V
    //   952: aload #4
    //   954: aload #17
    //   956: invokeinterface getInt : ()I
    //   961: iload #59
    //   963: iadd
    //   964: bipush #8
    //   966: imul
    //   967: aload #4
    //   969: aload #17
    //   971: invokeinterface getInt : ()I
    //   976: iload #59
    //   978: iadd
    //   979: bipush #8
    //   981: imul
    //   982: invokeinterface getDouble : (I)D
    //   987: aload #13
    //   989: iload #29
    //   991: iload #22
    //   993: imul
    //   994: iload #43
    //   996: iadd
    //   997: bipush #8
    //   999: imul
    //   1000: invokeinterface getDouble : (I)D
    //   1005: dload #57
    //   1007: dmul
    //   1008: dadd
    //   1009: invokeinterface setDouble : (ID)V
    //   1014: iload #29
    //   1016: iload #11
    //   1018: irem
    //   1019: iconst_1
    //   1020: iadd
    //   1021: istore #29
    //   1023: iinc #59, 1
    //   1026: iload #59
    //   1028: iload #44
    //   1030: if_icmple -> 906
    //   1033: aload #42
    //   1035: iload #43
    //   1037: iconst_4
    //   1038: imul
    //   1039: invokeinterface getInt : (I)I
    //   1044: iconst_2
    //   1045: if_icmple -> 1051
    //   1048: goto -> 1160
    //   1051: aload #42
    //   1053: iload #43
    //   1055: iconst_4
    //   1056: imul
    //   1057: invokeinterface getInt : (I)I
    //   1062: ifne -> 1068
    //   1065: goto -> 1160
    //   1068: dload #57
    //   1070: dconst_0
    //   1071: dcmpg
    //   1072: iflt -> 1078
    //   1075: goto -> 1160
    //   1078: iinc #51, 1
    //   1081: aload #6
    //   1083: iload #51
    //   1085: iconst_4
    //   1086: imul
    //   1087: iload #43
    //   1089: invokeinterface setInt : (II)V
    //   1094: aload #8
    //   1096: iload #51
    //   1098: bipush #8
    //   1100: imul
    //   1101: dload #46
    //   1103: dload #57
    //   1105: dneg
    //   1106: ddiv
    //   1107: invokeinterface setDouble : (ID)V
    //   1112: iload #51
    //   1114: iconst_1
    //   1115: if_icmpeq -> 1139
    //   1118: aload #8
    //   1120: iload #51
    //   1122: bipush #8
    //   1124: imul
    //   1125: invokeinterface getDouble : (I)D
    //   1130: dload #53
    //   1132: dcmpg
    //   1133: iflt -> 1139
    //   1136: goto -> 1301
    //   1139: aload #8
    //   1141: iload #51
    //   1143: bipush #8
    //   1145: imul
    //   1146: invokeinterface getDouble : (I)D
    //   1151: dstore #53
    //   1153: iload #51
    //   1155: istore #52
    //   1157: goto -> 1301
    //   1160: aload #42
    //   1162: iload #43
    //   1164: iconst_4
    //   1165: imul
    //   1166: invokeinterface getInt : (I)I
    //   1171: iconst_1
    //   1172: if_icmpgt -> 1178
    //   1175: goto -> 1269
    //   1178: dload #57
    //   1180: dconst_0
    //   1181: dcmpl
    //   1182: ifgt -> 1188
    //   1185: goto -> 1269
    //   1188: iinc #51, 1
    //   1191: aload #6
    //   1193: iload #51
    //   1195: iconst_4
    //   1196: imul
    //   1197: iload #43
    //   1199: invokeinterface setInt : (II)V
    //   1204: aload #8
    //   1206: iload #51
    //   1208: bipush #8
    //   1210: imul
    //   1211: dload #48
    //   1213: dload #57
    //   1215: ddiv
    //   1216: invokeinterface setDouble : (ID)V
    //   1221: iload #51
    //   1223: iconst_1
    //   1224: if_icmpeq -> 1248
    //   1227: aload #8
    //   1229: iload #51
    //   1231: bipush #8
    //   1233: imul
    //   1234: invokeinterface getDouble : (I)D
    //   1239: dload #53
    //   1241: dcmpg
    //   1242: iflt -> 1248
    //   1245: goto -> 1301
    //   1248: aload #8
    //   1250: iload #51
    //   1252: bipush #8
    //   1254: imul
    //   1255: invokeinterface getDouble : (I)D
    //   1260: dstore #53
    //   1262: iload #51
    //   1264: istore #52
    //   1266: goto -> 1301
    //   1269: iinc #45, -1
    //   1272: aload #6
    //   1274: iload #45
    //   1276: iconst_4
    //   1277: imul
    //   1278: iload #43
    //   1280: invokeinterface setInt : (II)V
    //   1285: dload #57
    //   1287: invokestatic abs : (D)D
    //   1290: dconst_0
    //   1291: dcmpl
    //   1292: ifgt -> 1298
    //   1295: goto -> 1301
    //   1298: iconst_0
    //   1299: istore #25
    //   1301: iinc #43, 1
    //   1304: iload #43
    //   1306: aload #40
    //   1308: iconst_0
    //   1309: iaload
    //   1310: if_icmple -> 486
    //   1313: aload #16
    //   1315: invokeinterface getDouble : ()D
    //   1320: dconst_1
    //   1321: dcmpl
    //   1322: ifne -> 1328
    //   1325: goto -> 1362
    //   1328: aload #17
    //   1330: aload #16
    //   1332: aload #4
    //   1334: aload #17
    //   1336: invokeinterface getInt : ()I
    //   1341: iconst_1
    //   1342: iadd
    //   1343: bipush #8
    //   1345: imul
    //   1346: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1351: ldc org/renjin/stats/lbfgsb__
    //   1353: ldc_w 'c__1'
    //   1356: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1359: invokestatic dscal_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1362: new org/renjin/gcc/runtime/IntPtr
    //   1365: dup
    //   1366: aload #40
    //   1368: iconst_0
    //   1369: invokespecial <init> : ([II)V
    //   1372: checkcast org/renjin/gcc/runtime/Ptr
    //   1375: aload #5
    //   1377: bipush #8
    //   1379: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1384: ldc org/renjin/stats/lbfgsb__
    //   1386: ldc_w 'c__1'
    //   1389: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1392: aload_0
    //   1393: bipush #8
    //   1395: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1400: ldc org/renjin/stats/lbfgsb__
    //   1402: ldc_w 'c__1'
    //   1405: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1408: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1411: iload #51
    //   1413: ifeq -> 1419
    //   1416: goto -> 1545
    //   1419: aload #40
    //   1421: iconst_0
    //   1422: iaload
    //   1423: iconst_1
    //   1424: iadd
    //   1425: iload #45
    //   1427: if_icmpeq -> 1433
    //   1430: goto -> 1545
    //   1433: iload #24
    //   1435: bipush #100
    //   1437: if_icmpgt -> 1443
    //   1440: goto -> 3492
    //   1443: new org/renjin/gcc/runtime/BytePtr
    //   1446: dup
    //   1447: ldc_w 'Cauchy X =   '
    //   1450: invokevirtual getBytes : ()[B
    //   1453: iconst_0
    //   1454: invokespecial <init> : ([BI)V
    //   1457: iconst_0
    //   1458: anewarray java/lang/Object
    //   1461: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1464: iconst_1
    //   1465: istore_3
    //   1466: goto -> 1513
    //   1469: iconst_1
    //   1470: anewarray java/lang/Object
    //   1473: astore_2
    //   1474: aload_2
    //   1475: iconst_0
    //   1476: aload_0
    //   1477: iload_3
    //   1478: bipush #8
    //   1480: imul
    //   1481: invokeinterface getDouble : (I)D
    //   1486: new org/renjin/gcc/runtime/BytePtr
    //   1489: astore_1
    //   1490: aload_1
    //   1491: ldc_w '%g  '
    //   1494: invokevirtual getBytes : ()[B
    //   1497: iconst_0
    //   1498: invokespecial <init> : ([BI)V
    //   1501: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1504: aastore
    //   1505: aload_1
    //   1506: aload_2
    //   1507: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1510: iinc #3, 1
    //   1513: iload_3
    //   1514: aload #40
    //   1516: iconst_0
    //   1517: iaload
    //   1518: if_icmple -> 1469
    //   1521: new org/renjin/gcc/runtime/BytePtr
    //   1524: dup
    //   1525: ldc_w '\\n '
    //   1528: invokevirtual getBytes : ()[B
    //   1531: iconst_0
    //   1532: invokespecial <init> : ([BI)V
    //   1535: iconst_0
    //   1536: anewarray java/lang/Object
    //   1539: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1542: goto -> 3492
    //   1545: iconst_1
    //   1546: istore #41
    //   1548: goto -> 1566
    //   1551: aload_1
    //   1552: iload #41
    //   1554: bipush #8
    //   1556: imul
    //   1557: dconst_0
    //   1558: invokeinterface setDouble : (ID)V
    //   1563: iinc #41, 1
    //   1566: iload #41
    //   1568: aload #28
    //   1570: iconst_0
    //   1571: iaload
    //   1572: if_icmple -> 1551
    //   1575: aload #16
    //   1577: invokeinterface getDouble : ()D
    //   1582: dneg
    //   1583: dload #55
    //   1585: dmul
    //   1586: dstore #46
    //   1588: dload #46
    //   1590: dstore #48
    //   1592: aload #17
    //   1594: invokeinterface getInt : ()I
    //   1599: ifgt -> 1605
    //   1602: goto -> 1729
    //   1605: iload #11
    //   1607: aload #15
    //   1609: iload #19
    //   1611: bipush #8
    //   1613: imul
    //   1614: aload #14
    //   1616: iload #20
    //   1618: bipush #8
    //   1620: imul
    //   1621: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1626: astore #41
    //   1628: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1633: astore #42
    //   1635: aload #41
    //   1637: aload #42
    //   1639: aload #17
    //   1641: aload #4
    //   1643: bipush #8
    //   1645: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1650: aload #10
    //   1652: bipush #8
    //   1654: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1659: aload #26
    //   1661: invokestatic bmv : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1664: aload #26
    //   1666: invokeinterface getInt : ()I
    //   1671: ifne -> 3492
    //   1674: dload #46
    //   1676: new org/renjin/gcc/runtime/IntPtr
    //   1679: dup
    //   1680: aload #28
    //   1682: iconst_0
    //   1683: invokespecial <init> : ([II)V
    //   1686: checkcast org/renjin/gcc/runtime/Ptr
    //   1689: aload #10
    //   1691: bipush #8
    //   1693: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1698: ldc org/renjin/stats/lbfgsb__
    //   1700: ldc_w 'c__1'
    //   1703: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1706: aload #4
    //   1708: bipush #8
    //   1710: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1715: ldc org/renjin/stats/lbfgsb__
    //   1717: ldc_w 'c__1'
    //   1720: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1723: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   1726: dsub
    //   1727: dstore #46
    //   1729: aload #34
    //   1731: iconst_0
    //   1732: dload #55
    //   1734: dneg
    //   1735: dload #46
    //   1737: ddiv
    //   1738: dastore
    //   1739: aload #38
    //   1741: iconst_0
    //   1742: dconst_0
    //   1743: dastore
    //   1744: aload #23
    //   1746: iconst_1
    //   1747: invokeinterface setInt : (I)V
    //   1752: iload #24
    //   1754: bipush #98
    //   1756: if_icmpgt -> 1762
    //   1759: goto -> 1791
    //   1762: new org/renjin/gcc/runtime/BytePtr
    //   1765: dup
    //   1766: ldc_w 'There are %d  breakpoints\\n '
    //   1769: invokevirtual getBytes : ()[B
    //   1772: iconst_0
    //   1773: invokespecial <init> : ([BI)V
    //   1776: iconst_1
    //   1777: anewarray java/lang/Object
    //   1780: dup
    //   1781: iconst_0
    //   1782: iload #51
    //   1784: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1787: aastore
    //   1788: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1791: iload #51
    //   1793: ifeq -> 3061
    //   1796: iload #51
    //   1798: istore #41
    //   1800: iconst_1
    //   1801: istore #42
    //   1803: dconst_0
    //   1804: dstore #57
    //   1806: dload #57
    //   1808: dstore #35
    //   1810: iload #42
    //   1812: iconst_1
    //   1813: if_icmpeq -> 1819
    //   1816: goto -> 1839
    //   1819: dload #53
    //   1821: dstore #57
    //   1823: aload #6
    //   1825: iload #52
    //   1827: iconst_4
    //   1828: imul
    //   1829: invokeinterface getInt : (I)I
    //   1834: istore #45
    //   1836: goto -> 1958
    //   1839: iload #42
    //   1841: iconst_2
    //   1842: if_icmpeq -> 1848
    //   1845: goto -> 1904
    //   1848: iload #52
    //   1850: iload #51
    //   1852: if_icmpne -> 1858
    //   1855: goto -> 1904
    //   1858: aload #8
    //   1860: iload #52
    //   1862: bipush #8
    //   1864: imul
    //   1865: aload #8
    //   1867: iload #51
    //   1869: bipush #8
    //   1871: imul
    //   1872: invokeinterface getDouble : (I)D
    //   1877: invokeinterface setDouble : (ID)V
    //   1882: aload #6
    //   1884: iload #52
    //   1886: iconst_4
    //   1887: imul
    //   1888: aload #6
    //   1890: iload #51
    //   1892: iconst_4
    //   1893: imul
    //   1894: invokeinterface getInt : (I)I
    //   1899: invokeinterface setInt : (II)V
    //   1904: iload #41
    //   1906: aload #8
    //   1908: bipush #8
    //   1910: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1915: aload #6
    //   1917: iconst_4
    //   1918: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1923: iload #42
    //   1925: bipush #-2
    //   1927: iadd
    //   1928: invokestatic hpsolb : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1931: aload #8
    //   1933: iload #41
    //   1935: bipush #8
    //   1937: imul
    //   1938: invokeinterface getDouble : (I)D
    //   1943: dstore #57
    //   1945: aload #6
    //   1947: iload #41
    //   1949: iconst_4
    //   1950: imul
    //   1951: invokeinterface getInt : (I)I
    //   1956: istore #45
    //   1958: aload #37
    //   1960: iconst_0
    //   1961: dload #57
    //   1963: dload #35
    //   1965: dsub
    //   1966: dastore
    //   1967: aload #37
    //   1969: iconst_0
    //   1970: daload
    //   1971: dconst_0
    //   1972: dcmpl
    //   1973: ifne -> 1979
    //   1976: goto -> 2137
    //   1979: iload #24
    //   1981: bipush #99
    //   1983: if_icmpgt -> 1989
    //   1986: goto -> 2137
    //   1989: aload #23
    //   1991: invokeinterface getInt : ()I
    //   1996: new org/renjin/gcc/runtime/BytePtr
    //   1999: astore #43
    //   2001: aload #43
    //   2003: ldc_w '\\nPiece    %3i f1, f2 at start point %11.4e %11.4e\\n '
    //   2006: invokevirtual getBytes : ()[B
    //   2009: iconst_0
    //   2010: invokespecial <init> : ([BI)V
    //   2013: iconst_3
    //   2014: anewarray java/lang/Object
    //   2017: astore #29
    //   2019: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   2022: astore #44
    //   2024: aload #29
    //   2026: iconst_0
    //   2027: aload #44
    //   2029: aastore
    //   2030: aload #29
    //   2032: iconst_1
    //   2033: dload #55
    //   2035: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2038: aastore
    //   2039: aload #29
    //   2041: iconst_2
    //   2042: dload #46
    //   2044: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2047: aastore
    //   2048: aload #43
    //   2050: aload #29
    //   2052: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2055: iconst_1
    //   2056: anewarray java/lang/Object
    //   2059: astore #29
    //   2061: aload #29
    //   2063: iconst_0
    //   2064: aload #37
    //   2066: iconst_0
    //   2067: daload
    //   2068: new org/renjin/gcc/runtime/BytePtr
    //   2071: astore #43
    //   2073: aload #43
    //   2075: ldc_w 'Distance to the next break point =  %11.4e\\n '
    //   2078: invokevirtual getBytes : ()[B
    //   2081: iconst_0
    //   2082: invokespecial <init> : ([BI)V
    //   2085: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2088: aastore
    //   2089: aload #43
    //   2091: aload #29
    //   2093: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2096: iconst_1
    //   2097: anewarray java/lang/Object
    //   2100: astore #29
    //   2102: aload #29
    //   2104: iconst_0
    //   2105: aload #34
    //   2107: iconst_0
    //   2108: daload
    //   2109: new org/renjin/gcc/runtime/BytePtr
    //   2112: astore #43
    //   2114: aload #43
    //   2116: ldc_w 'Distance to the stationary point =  %11.4e\\n '
    //   2119: invokevirtual getBytes : ()[B
    //   2122: iconst_0
    //   2123: invokespecial <init> : ([BI)V
    //   2126: invokestatic valueOf : (D)Ljava/lang/Double;
    //   2129: aastore
    //   2130: aload #43
    //   2132: aload #29
    //   2134: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2137: aload #34
    //   2139: iconst_0
    //   2140: daload
    //   2141: aload #37
    //   2143: iconst_0
    //   2144: daload
    //   2145: dcmpg
    //   2146: iflt -> 3061
    //   2149: aload #38
    //   2151: iconst_0
    //   2152: aload #38
    //   2154: iconst_0
    //   2155: daload
    //   2156: aload #37
    //   2158: iconst_0
    //   2159: daload
    //   2160: dadd
    //   2161: dastore
    //   2162: iinc #41, -1
    //   2165: iinc #42, 1
    //   2168: aload #9
    //   2170: iload #45
    //   2172: bipush #8
    //   2174: imul
    //   2175: invokeinterface getDouble : (I)D
    //   2180: dstore #35
    //   2182: aload #9
    //   2184: iload #45
    //   2186: bipush #8
    //   2188: imul
    //   2189: dconst_0
    //   2190: invokeinterface setDouble : (ID)V
    //   2195: dload #35
    //   2197: dconst_0
    //   2198: dcmpl
    //   2199: ifgt -> 2205
    //   2202: goto -> 2268
    //   2205: aload_3
    //   2206: iload #45
    //   2208: bipush #8
    //   2210: imul
    //   2211: invokeinterface getDouble : (I)D
    //   2216: aload #5
    //   2218: iload #45
    //   2220: bipush #8
    //   2222: imul
    //   2223: invokeinterface getDouble : (I)D
    //   2228: dsub
    //   2229: dstore #30
    //   2231: aload_0
    //   2232: iload #45
    //   2234: bipush #8
    //   2236: imul
    //   2237: aload_3
    //   2238: iload #45
    //   2240: bipush #8
    //   2242: imul
    //   2243: invokeinterface getDouble : (I)D
    //   2248: invokeinterface setDouble : (ID)V
    //   2253: aload #7
    //   2255: iload #45
    //   2257: iconst_4
    //   2258: imul
    //   2259: iconst_2
    //   2260: invokeinterface setInt : (II)V
    //   2265: goto -> 2328
    //   2268: aload_2
    //   2269: iload #45
    //   2271: bipush #8
    //   2273: imul
    //   2274: invokeinterface getDouble : (I)D
    //   2279: aload #5
    //   2281: iload #45
    //   2283: bipush #8
    //   2285: imul
    //   2286: invokeinterface getDouble : (I)D
    //   2291: dsub
    //   2292: dstore #30
    //   2294: aload_0
    //   2295: iload #45
    //   2297: bipush #8
    //   2299: imul
    //   2300: aload_2
    //   2301: iload #45
    //   2303: bipush #8
    //   2305: imul
    //   2306: invokeinterface getDouble : (I)D
    //   2311: invokeinterface setDouble : (ID)V
    //   2316: aload #7
    //   2318: iload #45
    //   2320: iconst_4
    //   2321: imul
    //   2322: iconst_1
    //   2323: invokeinterface setInt : (II)V
    //   2328: iload #24
    //   2330: bipush #99
    //   2332: if_icmpgt -> 2338
    //   2335: goto -> 2367
    //   2338: new org/renjin/gcc/runtime/BytePtr
    //   2341: dup
    //   2342: ldc_w 'Variable  %d  is fixed.\\n '
    //   2345: invokevirtual getBytes : ()[B
    //   2348: iconst_0
    //   2349: invokespecial <init> : ([BI)V
    //   2352: iconst_1
    //   2353: anewarray java/lang/Object
    //   2356: dup
    //   2357: iconst_0
    //   2358: iload #45
    //   2360: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   2363: aastore
    //   2364: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2367: iload #41
    //   2369: ifeq -> 2375
    //   2372: goto -> 2398
    //   2375: iload #51
    //   2377: aload #40
    //   2379: iconst_0
    //   2380: iaload
    //   2381: if_icmpeq -> 2387
    //   2384: goto -> 2398
    //   2387: aload #34
    //   2389: iconst_0
    //   2390: aload #37
    //   2392: iconst_0
    //   2393: daload
    //   2394: dastore
    //   2395: goto -> 3277
    //   2398: aload #23
    //   2400: aload #23
    //   2402: invokeinterface getInt : ()I
    //   2407: iconst_1
    //   2408: iadd
    //   2409: invokeinterface setInt : (I)V
    //   2414: dload #35
    //   2416: dload #35
    //   2418: dmul
    //   2419: dstore #60
    //   2421: aload #37
    //   2423: iconst_0
    //   2424: daload
    //   2425: dload #46
    //   2427: dmul
    //   2428: dload #60
    //   2430: dadd
    //   2431: aload #16
    //   2433: invokeinterface getDouble : ()D
    //   2438: dload #35
    //   2440: dmul
    //   2441: dload #30
    //   2443: dmul
    //   2444: dsub
    //   2445: dload #55
    //   2447: dadd
    //   2448: dstore #55
    //   2450: dload #46
    //   2452: aload #16
    //   2454: invokeinterface getDouble : ()D
    //   2459: dload #60
    //   2461: dmul
    //   2462: dsub
    //   2463: dstore #46
    //   2465: aload #17
    //   2467: invokeinterface getInt : ()I
    //   2472: ifgt -> 2478
    //   2475: goto -> 2975
    //   2478: new org/renjin/gcc/runtime/IntPtr
    //   2481: dup
    //   2482: aload #28
    //   2484: iconst_0
    //   2485: invokespecial <init> : ([II)V
    //   2488: checkcast org/renjin/gcc/runtime/Ptr
    //   2491: new org/renjin/gcc/runtime/DoublePtr
    //   2494: dup
    //   2495: aload #37
    //   2497: iconst_0
    //   2498: invokespecial <init> : ([DI)V
    //   2501: checkcast org/renjin/gcc/runtime/Ptr
    //   2504: aload #4
    //   2506: bipush #8
    //   2508: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2513: ldc org/renjin/stats/lbfgsb__
    //   2515: ldc_w 'c__1'
    //   2518: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2521: aload_1
    //   2522: bipush #8
    //   2524: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2529: ldc org/renjin/stats/lbfgsb__
    //   2531: ldc_w 'c__1'
    //   2534: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2537: invokestatic daxpy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2540: aload #18
    //   2542: invokeinterface getInt : ()I
    //   2547: istore #43
    //   2549: iconst_1
    //   2550: istore #29
    //   2552: goto -> 2643
    //   2555: aload #21
    //   2557: iload #29
    //   2559: bipush #8
    //   2561: imul
    //   2562: aload #12
    //   2564: iload #43
    //   2566: iload #50
    //   2568: imul
    //   2569: iload #45
    //   2571: iadd
    //   2572: bipush #8
    //   2574: imul
    //   2575: invokeinterface getDouble : (I)D
    //   2580: invokeinterface setDouble : (ID)V
    //   2585: aload #21
    //   2587: aload #17
    //   2589: invokeinterface getInt : ()I
    //   2594: iload #29
    //   2596: iadd
    //   2597: bipush #8
    //   2599: imul
    //   2600: aload #16
    //   2602: invokeinterface getDouble : ()D
    //   2607: aload #13
    //   2609: iload #43
    //   2611: iload #22
    //   2613: imul
    //   2614: iload #45
    //   2616: iadd
    //   2617: bipush #8
    //   2619: imul
    //   2620: invokeinterface getDouble : (I)D
    //   2625: dmul
    //   2626: invokeinterface setDouble : (ID)V
    //   2631: iload #43
    //   2633: iload #11
    //   2635: irem
    //   2636: iconst_1
    //   2637: iadd
    //   2638: istore #43
    //   2640: iinc #29, 1
    //   2643: aload #17
    //   2645: invokeinterface getInt : ()I
    //   2650: iload #29
    //   2652: if_icmpge -> 2555
    //   2655: iload #11
    //   2657: aload #15
    //   2659: iload #19
    //   2661: bipush #8
    //   2663: imul
    //   2664: aload #14
    //   2666: iload #20
    //   2668: bipush #8
    //   2670: imul
    //   2671: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2676: astore #45
    //   2678: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2683: astore #43
    //   2685: aload #45
    //   2687: aload #43
    //   2689: aload #17
    //   2691: aload #21
    //   2693: bipush #8
    //   2695: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2700: aload #10
    //   2702: bipush #8
    //   2704: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2709: aload #26
    //   2711: invokestatic bmv : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2714: aload #26
    //   2716: invokeinterface getInt : ()I
    //   2721: ifne -> 3492
    //   2724: dload #35
    //   2726: new org/renjin/gcc/runtime/IntPtr
    //   2729: dup
    //   2730: aload #28
    //   2732: iconst_0
    //   2733: invokespecial <init> : ([II)V
    //   2736: checkcast org/renjin/gcc/runtime/Ptr
    //   2739: aload_1
    //   2740: bipush #8
    //   2742: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2747: ldc org/renjin/stats/lbfgsb__
    //   2749: ldc_w 'c__1'
    //   2752: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2755: aload #10
    //   2757: bipush #8
    //   2759: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2764: ldc org/renjin/stats/lbfgsb__
    //   2766: ldc_w 'c__1'
    //   2769: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2772: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   2775: new org/renjin/gcc/runtime/IntPtr
    //   2778: dup
    //   2779: aload #28
    //   2781: iconst_0
    //   2782: invokespecial <init> : ([II)V
    //   2785: checkcast org/renjin/gcc/runtime/Ptr
    //   2788: aload #4
    //   2790: bipush #8
    //   2792: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2797: ldc org/renjin/stats/lbfgsb__
    //   2799: ldc_w 'c__1'
    //   2802: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2805: aload #10
    //   2807: bipush #8
    //   2809: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2814: ldc org/renjin/stats/lbfgsb__
    //   2816: ldc_w 'c__1'
    //   2819: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2822: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   2825: dstore #32
    //   2827: new org/renjin/gcc/runtime/IntPtr
    //   2830: dup
    //   2831: aload #28
    //   2833: iconst_0
    //   2834: invokespecial <init> : ([II)V
    //   2837: checkcast org/renjin/gcc/runtime/Ptr
    //   2840: aload #21
    //   2842: bipush #8
    //   2844: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2849: ldc org/renjin/stats/lbfgsb__
    //   2851: ldc_w 'c__1'
    //   2854: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2857: aload #10
    //   2859: bipush #8
    //   2861: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2866: ldc org/renjin/stats/lbfgsb__
    //   2868: ldc_w 'c__1'
    //   2871: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2874: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   2877: dstore #30
    //   2879: aload #39
    //   2881: iconst_0
    //   2882: dload #35
    //   2884: dneg
    //   2885: dastore
    //   2886: new org/renjin/gcc/runtime/IntPtr
    //   2889: dup
    //   2890: aload #28
    //   2892: iconst_0
    //   2893: invokespecial <init> : ([II)V
    //   2896: checkcast org/renjin/gcc/runtime/Ptr
    //   2899: new org/renjin/gcc/runtime/DoublePtr
    //   2902: dup
    //   2903: aload #39
    //   2905: iconst_0
    //   2906: invokespecial <init> : ([DI)V
    //   2909: checkcast org/renjin/gcc/runtime/Ptr
    //   2912: aload #21
    //   2914: bipush #8
    //   2916: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2921: ldc org/renjin/stats/lbfgsb__
    //   2923: ldc_w 'c__1'
    //   2926: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2929: aload #4
    //   2931: bipush #8
    //   2933: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2938: ldc org/renjin/stats/lbfgsb__
    //   2940: ldc_w 'c__1'
    //   2943: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   2946: invokestatic daxpy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2949: dmul
    //   2950: dload #55
    //   2952: dadd
    //   2953: dstore #55
    //   2955: dload #35
    //   2957: ldc2_w 2.0
    //   2960: dmul
    //   2961: dload #32
    //   2963: dmul
    //   2964: dload #60
    //   2966: dload #30
    //   2968: dmul
    //   2969: dsub
    //   2970: dload #46
    //   2972: dadd
    //   2973: dstore #46
    //   2975: aload #39
    //   2977: iconst_0
    //   2978: aload #27
    //   2980: invokeinterface getDouble : ()D
    //   2985: dload #48
    //   2987: dmul
    //   2988: dastore
    //   2989: aload #39
    //   2991: iconst_0
    //   2992: daload
    //   2993: dload #46
    //   2995: dcmpl
    //   2996: ifgt -> 3002
    //   2999: goto -> 3008
    //   3002: aload #39
    //   3004: iconst_0
    //   3005: daload
    //   3006: dstore #46
    //   3008: iload #41
    //   3010: ifgt -> 3016
    //   3013: goto -> 3029
    //   3016: aload #34
    //   3018: iconst_0
    //   3019: dload #55
    //   3021: dneg
    //   3022: dload #46
    //   3024: ddiv
    //   3025: dastore
    //   3026: goto -> 1806
    //   3029: iload #25
    //   3031: ifne -> 3037
    //   3034: goto -> 3051
    //   3037: dconst_0
    //   3038: dstore #55
    //   3040: dconst_0
    //   3041: dstore #46
    //   3043: aload #34
    //   3045: iconst_0
    //   3046: dconst_0
    //   3047: dastore
    //   3048: goto -> 3061
    //   3051: aload #34
    //   3053: iconst_0
    //   3054: dload #55
    //   3056: dneg
    //   3057: dload #46
    //   3059: ddiv
    //   3060: dastore
    //   3061: iload #24
    //   3063: bipush #98
    //   3065: if_icmpgt -> 3071
    //   3068: goto -> 3185
    //   3071: new org/renjin/gcc/runtime/BytePtr
    //   3074: dup
    //   3075: ldc_w '\\nGCP found in this segment\\n '
    //   3078: invokevirtual getBytes : ()[B
    //   3081: iconst_0
    //   3082: invokespecial <init> : ([BI)V
    //   3085: iconst_0
    //   3086: anewarray java/lang/Object
    //   3089: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3092: aload #23
    //   3094: invokeinterface getInt : ()I
    //   3099: new org/renjin/gcc/runtime/BytePtr
    //   3102: astore_2
    //   3103: aload_2
    //   3104: ldc_w 'Piece    %3i f1, f2 at start point %11.4e %11.4e\\n '
    //   3107: invokevirtual getBytes : ()[B
    //   3110: iconst_0
    //   3111: invokespecial <init> : ([BI)V
    //   3114: iconst_3
    //   3115: anewarray java/lang/Object
    //   3118: astore_3
    //   3119: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   3122: astore #5
    //   3124: aload_3
    //   3125: iconst_0
    //   3126: aload #5
    //   3128: aastore
    //   3129: aload_3
    //   3130: iconst_1
    //   3131: dload #55
    //   3133: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3136: aastore
    //   3137: aload_3
    //   3138: iconst_2
    //   3139: dload #46
    //   3141: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3144: aastore
    //   3145: aload_2
    //   3146: aload_3
    //   3147: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3150: iconst_1
    //   3151: anewarray java/lang/Object
    //   3154: astore_3
    //   3155: aload_3
    //   3156: iconst_0
    //   3157: aload #34
    //   3159: iconst_0
    //   3160: daload
    //   3161: new org/renjin/gcc/runtime/BytePtr
    //   3164: astore_2
    //   3165: aload_2
    //   3166: ldc_w 'Distance to the stationary point =  %11.4e\\n '
    //   3169: invokevirtual getBytes : ()[B
    //   3172: iconst_0
    //   3173: invokespecial <init> : ([BI)V
    //   3176: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3179: aastore
    //   3180: aload_2
    //   3181: aload_3
    //   3182: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3185: aload #34
    //   3187: iconst_0
    //   3188: daload
    //   3189: dconst_0
    //   3190: dcmpg
    //   3191: ifle -> 3197
    //   3194: goto -> 3202
    //   3197: aload #34
    //   3199: iconst_0
    //   3200: dconst_0
    //   3201: dastore
    //   3202: aload #38
    //   3204: iconst_0
    //   3205: aload #38
    //   3207: iconst_0
    //   3208: daload
    //   3209: aload #34
    //   3211: iconst_0
    //   3212: daload
    //   3213: dadd
    //   3214: dastore
    //   3215: new org/renjin/gcc/runtime/IntPtr
    //   3218: dup
    //   3219: aload #40
    //   3221: iconst_0
    //   3222: invokespecial <init> : ([II)V
    //   3225: checkcast org/renjin/gcc/runtime/Ptr
    //   3228: new org/renjin/gcc/runtime/DoublePtr
    //   3231: dup
    //   3232: aload #38
    //   3234: iconst_0
    //   3235: invokespecial <init> : ([DI)V
    //   3238: checkcast org/renjin/gcc/runtime/Ptr
    //   3241: aload #9
    //   3243: bipush #8
    //   3245: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3250: ldc org/renjin/stats/lbfgsb__
    //   3252: ldc_w 'c__1'
    //   3255: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3258: aload_0
    //   3259: bipush #8
    //   3261: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3266: ldc org/renjin/stats/lbfgsb__
    //   3268: ldc_w 'c__1'
    //   3271: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3274: invokestatic daxpy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3277: aload #17
    //   3279: invokeinterface getInt : ()I
    //   3284: ifgt -> 3290
    //   3287: goto -> 3352
    //   3290: new org/renjin/gcc/runtime/IntPtr
    //   3293: dup
    //   3294: aload #28
    //   3296: iconst_0
    //   3297: invokespecial <init> : ([II)V
    //   3300: checkcast org/renjin/gcc/runtime/Ptr
    //   3303: new org/renjin/gcc/runtime/DoublePtr
    //   3306: dup
    //   3307: aload #34
    //   3309: iconst_0
    //   3310: invokespecial <init> : ([DI)V
    //   3313: checkcast org/renjin/gcc/runtime/Ptr
    //   3316: aload #4
    //   3318: bipush #8
    //   3320: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3325: ldc org/renjin/stats/lbfgsb__
    //   3327: ldc_w 'c__1'
    //   3330: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3333: aload_1
    //   3334: bipush #8
    //   3336: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3341: ldc org/renjin/stats/lbfgsb__
    //   3343: ldc_w 'c__1'
    //   3346: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3349: invokestatic daxpy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3352: iload #24
    //   3354: bipush #99
    //   3356: if_icmpgt -> 3362
    //   3359: goto -> 3461
    //   3362: new org/renjin/gcc/runtime/BytePtr
    //   3365: dup
    //   3366: ldc_w 'Cauchy X =   '
    //   3369: invokevirtual getBytes : ()[B
    //   3372: iconst_0
    //   3373: invokespecial <init> : ([BI)V
    //   3376: iconst_0
    //   3377: anewarray java/lang/Object
    //   3380: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3383: iconst_1
    //   3384: istore_3
    //   3385: goto -> 3432
    //   3388: iconst_1
    //   3389: anewarray java/lang/Object
    //   3392: astore_2
    //   3393: aload_2
    //   3394: iconst_0
    //   3395: aload_0
    //   3396: iload_3
    //   3397: bipush #8
    //   3399: imul
    //   3400: invokeinterface getDouble : (I)D
    //   3405: new org/renjin/gcc/runtime/BytePtr
    //   3408: astore_1
    //   3409: aload_1
    //   3410: ldc_w '%g  '
    //   3413: invokevirtual getBytes : ()[B
    //   3416: iconst_0
    //   3417: invokespecial <init> : ([BI)V
    //   3420: invokestatic valueOf : (D)Ljava/lang/Double;
    //   3423: aastore
    //   3424: aload_1
    //   3425: aload_2
    //   3426: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3429: iinc #3, 1
    //   3432: iload_3
    //   3433: aload #40
    //   3435: iconst_0
    //   3436: iaload
    //   3437: if_icmple -> 3388
    //   3440: new org/renjin/gcc/runtime/BytePtr
    //   3443: dup
    //   3444: ldc_w '\\n '
    //   3447: invokevirtual getBytes : ()[B
    //   3450: iconst_0
    //   3451: invokespecial <init> : ([BI)V
    //   3454: iconst_0
    //   3455: anewarray java/lang/Object
    //   3458: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3461: iload #24
    //   3463: bipush #98
    //   3465: if_icmpgt -> 3471
    //   3468: goto -> 3492
    //   3471: new org/renjin/gcc/runtime/BytePtr
    //   3474: dup
    //   3475: ldc_w '\\n---------------- exit CAUCHY----------------------\\n\\n '
    //   3478: invokevirtual getBytes : ()[B
    //   3481: iconst_0
    //   3482: invokespecial <init> : ([BI)V
    //   3485: iconst_0
    //   3486: anewarray java/lang/Object
    //   3489: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3492: return
  }
  
  public static void cmprlb(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    paramPtr10 = paramPtr10.pointerPlus(-4);
    paramPtr8 = paramPtr8.pointerPlus(-8);
    paramPtr7 = paramPtr7.pointerPlus(-8);
    Ptr ptr1 = paramPtr2.pointerPlus(-8);
    Ptr ptr2 = paramPtr1.pointerPlus(-8);
    paramPtr1 = paramPtr9.pointerPlus(-8);
    int j = paramInt2 + 1;
    paramPtr6 = paramPtr6.pointerPlus(-(j * 8));
    int k = paramInt2 + 1;
    Ptr ptr3 = paramPtr5.pointerPlus(-(k * 8));
    paramPtr2 = paramPtr4.pointerPlus(-((paramInt1 + 1) * 8));
    paramPtr3 = paramPtr3.pointerPlus(-((paramInt1 + 1) * 8));
    int i = paramPtr12.getInt();
    if (paramPtr15.getInt() != 0 || i <= 0) {
      int m = paramPtr14.getInt();
      for (byte b = 1; b <= m; b++) {
        int n = paramPtr10.getInt(b * 4);
        paramPtr8.setDouble(b * 8, -paramPtr11.getDouble() * (paramPtr7.getDouble(n * 8) - ptr2.getDouble(n * 8)) - ptr1.getDouble(n * 8));
      } 
      paramPtr6 = ptr3.pointerPlus(k * 8);
      paramPtr7 = paramPtr6.pointerPlus(j * 8);
      Ptr ptr = paramPtr1.pointerPlus(((paramInt2 << 1) + 1) * 8);
      bmv(paramInt2, paramPtr6, paramPtr7, paramPtr12, ptr, paramPtr1.pointerPlus(8), paramPtr16);
      if (paramPtr16.getInt() == 0) {
        int n = paramPtr13.getInt();
        for (byte b1 = 1; b1 <= i; b1++) {
          double d1 = paramPtr1.getDouble(b1 * 8);
          double d2 = paramPtr11.getDouble() * paramPtr1.getDouble((i + b1) * 8);
          for (byte b2 = 1; b2 <= m; b2++) {
            int i1 = paramPtr10.getInt(b2 * 4);
            paramPtr8.setDouble(b2 * 8, paramPtr8.getDouble(b2 * 8) + paramPtr2.getDouble((n * paramInt1 + i1) * 8) * d1 + paramPtr3.getDouble((n * paramInt1 + i1) * 8) * d2);
          } 
          n = n % paramInt2 + 1;
        } 
        return;
      } 
      paramPtr16.setInt(-8);
      return;
    } 
    for (paramInt2 = 1; paramInt2 <= paramInt1; paramInt2++)
      paramPtr8.setDouble(paramInt2 * 8, -ptr1.getDouble(paramInt2 * 8)); 
  }
  
  public static void dcsrch(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr4) {
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    double[] arrayOfDouble3 = new double[1];
    double[] arrayOfDouble4 = new double[1];
    double[] arrayOfDouble5 = new double[1];
    double[] arrayOfDouble6 = new double[1];
    if (Stdlib.strncmp(paramPtr4, (Ptr)new BytePtr("START\000".getBytes(), 0), 5) != 0) {
      paramDouble1 = paramPtr3.getDouble() * $dcsrch$gtest + $dcsrch$finit;
      if ($dcsrch$stage == 1 && paramPtr1.getDouble() <= paramDouble1 && paramPtr2.getDouble() >= 0.0D)
        $dcsrch$stage = 2; 
      if ($dcsrch$brackt[0] != 0 && (paramPtr3.getDouble() <= $dcsrch$stmin[0] || paramPtr3.getDouble() >= $dcsrch$stmax[0]))
        paramPtr4.memcpy((Ptr)new BytePtr("WARNING: ROUNDING ERRORS PREVENT PROGRESS\000".getBytes(), 0), 42); 
      if ($dcsrch$brackt[0] != 0 && $dcsrch$stmax[0] - $dcsrch$stmin[0] <= paramDouble3 * $dcsrch$stmax[0])
        paramPtr4.memcpy((Ptr)new BytePtr("WARNING: XTOL TEST SATISFIED\000".getBytes(), 0), 29); 
      if (paramPtr3.getDouble() == paramDouble5 && paramPtr1.getDouble() <= paramDouble1 && paramPtr2.getDouble() <= $dcsrch$gtest)
        paramPtr4.memcpy((Ptr)new BytePtr("WARNING: STP = STPMAX\000".getBytes(), 0), 22); 
      if (paramPtr3.getDouble() == paramDouble4 && (paramPtr1.getDouble() > paramDouble1 || paramPtr2.getDouble() >= $dcsrch$gtest))
        paramPtr4.memcpy((Ptr)new BytePtr("WARNING: STP = STPMIN\000".getBytes(), 0), 22); 
      if (paramPtr1.getDouble() <= paramDouble1 && Math.abs(paramPtr2.getDouble()) <= -$dcsrch$ginit * paramDouble2)
        paramPtr4.memcpy((Ptr)new BytePtr("CONVERGENCE\000".getBytes(), 0), 12); 
      if (Stdlib.strncmp(paramPtr4, (Ptr)new BytePtr("WARN\000".getBytes(), 0), 4) != 0 && Stdlib.strncmp(paramPtr4, (Ptr)new BytePtr("CONV\000".getBytes(), 0), 4) != 0) {
        if ($dcsrch$stage != 1 || paramPtr1.getDouble() > $dcsrch$fx[0] || paramPtr1.getDouble() <= paramDouble1) {
          dcstep((Ptr)new DoublePtr($dcsrch$stx, 0), (Ptr)new DoublePtr($dcsrch$fx, 0), (Ptr)new DoublePtr($dcsrch$gx, 0), (Ptr)new DoublePtr($dcsrch$sty, 0), (Ptr)new DoublePtr($dcsrch$fy, 0), (Ptr)new DoublePtr($dcsrch$gy, 0), paramPtr3, paramPtr1, paramPtr2, (Ptr)new IntPtr($dcsrch$brackt, 0), (Ptr)new DoublePtr($dcsrch$stmin, 0), (Ptr)new DoublePtr($dcsrch$stmax, 0));
        } else {
          arrayOfDouble6[0] = paramPtr1.getDouble() - paramPtr3.getDouble() * $dcsrch$gtest;
          arrayOfDouble4[0] = $dcsrch$fx[0] - $dcsrch$stx[0] * $dcsrch$gtest;
          arrayOfDouble3[0] = $dcsrch$fy[0] - $dcsrch$sty[0] * $dcsrch$gtest;
          arrayOfDouble5[0] = paramPtr2.getDouble() - $dcsrch$gtest;
          arrayOfDouble2[0] = $dcsrch$gx[0] - $dcsrch$gtest;
          arrayOfDouble1[0] = $dcsrch$gy[0] - $dcsrch$gtest;
          dcstep((Ptr)new DoublePtr($dcsrch$stx, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr($dcsrch$sty, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble1, 0), paramPtr3, (Ptr)new DoublePtr(arrayOfDouble6, 0), (Ptr)new DoublePtr(arrayOfDouble5, 0), (Ptr)new IntPtr($dcsrch$brackt, 0), (Ptr)new DoublePtr($dcsrch$stmin, 0), (Ptr)new DoublePtr($dcsrch$stmax, 0));
          $dcsrch$fx[0] = $dcsrch$stx[0] * $dcsrch$gtest + arrayOfDouble4[0];
          $dcsrch$fy[0] = $dcsrch$sty[0] * $dcsrch$gtest + arrayOfDouble3[0];
          $dcsrch$gx[0] = arrayOfDouble2[0] + $dcsrch$gtest;
          $dcsrch$gy[0] = arrayOfDouble1[0] + $dcsrch$gtest;
        } 
        if ($dcsrch$brackt[0] != 0) {
          if (Math.abs($dcsrch$sty[0] - $dcsrch$stx[0]) >= $dcsrch$width1 * 0.66D)
            paramPtr3.setDouble(($dcsrch$sty[0] - $dcsrch$stx[0]) * 0.5D + $dcsrch$stx[0]); 
          $dcsrch$width1 = $dcsrch$width;
          $dcsrch$width = Math.abs($dcsrch$sty[0] - $dcsrch$stx[0]);
        } 
        if ($dcsrch$brackt[0] == 0) {
          paramDouble1 = paramPtr3.getDouble() + (paramPtr3.getDouble() - $dcsrch$stx[0]) * 1.1D;
          $dcsrch$stmin[0] = paramDouble1;
          paramDouble1 = paramPtr3.getDouble() + (paramPtr3.getDouble() - $dcsrch$stx[0]) * 4.0D;
          $dcsrch$stmax[0] = paramDouble1;
        } else {
          if ($dcsrch$stx[0] <= $dcsrch$sty[0]) {
            paramDouble1 = $dcsrch$stx[0];
          } else {
            paramDouble1 = $dcsrch$sty[0];
          } 
          $dcsrch$stmin[0] = paramDouble1;
          if ($dcsrch$stx[0] >= $dcsrch$sty[0]) {
            paramDouble1 = $dcsrch$stx[0];
          } else {
            paramDouble1 = $dcsrch$sty[0];
          } 
          $dcsrch$stmax[0] = paramDouble1;
        } 
        if (paramPtr3.getDouble() < paramDouble4)
          paramPtr3.setDouble(paramDouble4); 
        if (paramPtr3.getDouble() > paramDouble5)
          paramPtr3.setDouble(paramDouble5); 
        if (($dcsrch$brackt[0] != 0 && (paramPtr3.getDouble() <= $dcsrch$stmin[0] || paramPtr3.getDouble() >= $dcsrch$stmax[0])) || ($dcsrch$brackt[0] != 0 && $dcsrch$stmax[0] - $dcsrch$stmin[0] <= paramDouble3 * $dcsrch$stmax[0]))
          paramPtr3.setDouble($dcsrch$stx[0]); 
        paramPtr4.memcpy((Ptr)new BytePtr("FG\000".getBytes(), 0), 3);
      } 
      return;
    } 
    if (paramPtr3.getDouble() < paramDouble4)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: STP .LT. STPMIN\000".getBytes(), 0), 23); 
    if (paramPtr3.getDouble() > paramDouble5)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: STP .GT. STPMAX\000".getBytes(), 0), 23); 
    if (paramPtr2.getDouble() >= 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: INITIAL G .GE. ZERO\000".getBytes(), 0), 27); 
    if (paramDouble1 < 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: FTOL .LT. ZERO\000".getBytes(), 0), 22); 
    if (paramDouble2 < 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: GTOL .LT. ZERO\000".getBytes(), 0), 22); 
    if (paramDouble3 < 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: XTOL .LT. ZERO\000".getBytes(), 0), 22); 
    if (paramDouble4 < 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: STPMIN .LT. ZERO\000".getBytes(), 0), 24); 
    if (paramDouble5 < paramDouble4)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: STPMAX .LT. STPMIN\000".getBytes(), 0), 26); 
    if (Stdlib.strncmp(paramPtr4, (Ptr)new BytePtr("ERROR\000".getBytes(), 0), 5) != 0) {
      $dcsrch$brackt[0] = 0;
      $dcsrch$stage = 1;
      $dcsrch$finit = paramPtr1.getDouble();
      $dcsrch$ginit = paramPtr2.getDouble();
      $dcsrch$gtest = paramDouble1 * $dcsrch$ginit;
      $dcsrch$width = paramDouble5 - paramDouble4;
      $dcsrch$width1 = $dcsrch$width / 0.5D;
      $dcsrch$stx[0] = 0.0D;
      $dcsrch$fx[0] = $dcsrch$finit;
      $dcsrch$gx[0] = $dcsrch$ginit;
      $dcsrch$sty[0] = 0.0D;
      $dcsrch$fy[0] = $dcsrch$finit;
      $dcsrch$gy[0] = $dcsrch$ginit;
      $dcsrch$stmin[0] = 0.0D;
      paramDouble1 = paramPtr3.getDouble() + paramPtr3.getDouble() * 4.0D;
      $dcsrch$stmax[0] = paramDouble1;
      paramPtr4.memcpy((Ptr)new BytePtr("FG\000".getBytes(), 0), 3);
    } 
  }
  
  public static void dcstep(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12) {
    double d2;
    double d1 = paramPtr9.getDouble() * paramPtr3.getDouble() / Math.abs(paramPtr3.getDouble());
    if (paramPtr8.getDouble() <= paramPtr2.getDouble()) {
      if (d1 >= 0.0D) {
        if (Math.abs(paramPtr9.getDouble()) >= Math.abs(paramPtr3.getDouble())) {
          if (paramPtr10.getInt() == 0) {
            if (paramPtr7.getDouble() <= paramPtr1.getDouble()) {
              d2 = paramPtr11.getDouble();
            } else {
              d2 = paramPtr12.getDouble();
            } 
          } else {
            d2 = (paramPtr8.getDouble() - paramPtr5.getDouble()) * 3.0D / (paramPtr4.getDouble() - paramPtr7.getDouble()) + paramPtr6.getDouble() + paramPtr9.getDouble();
            double d3 = Math.abs(d2);
            double d4 = Math.abs(paramPtr6.getDouble());
            if (d3 >= d4) {
              d3 = d3;
            } else {
              d3 = d4;
            } 
            d4 = Math.abs(paramPtr9.getDouble());
            if (d3 >= d4) {
              d3 = d3;
            } else {
              d3 = d4;
            } 
            d3 = Mathlib.sqrt(d2 / d3 * d2 / d3 - paramPtr6.getDouble() / d3 * paramPtr9.getDouble() / d3) * d3;
            if (paramPtr7.getDouble() > paramPtr4.getDouble())
              d3 = -d3; 
            d2 = paramPtr7.getDouble();
            d2 = (d3 - paramPtr9.getDouble() + d2) / (d3 - paramPtr9.getDouble() + d3 + paramPtr6.getDouble()) * (paramPtr4.getDouble() - paramPtr7.getDouble()) + d2;
          } 
        } else {
          d2 = (paramPtr2.getDouble() - paramPtr8.getDouble()) * 3.0D / (paramPtr7.getDouble() - paramPtr1.getDouble()) + paramPtr3.getDouble() + paramPtr9.getDouble();
          double d3 = Math.abs(d2);
          double d4 = Math.abs(paramPtr3.getDouble());
          if (d3 >= d4) {
            d3 = d3;
          } else {
            d3 = d4;
          } 
          d4 = Math.abs(paramPtr9.getDouble());
          if (d3 >= d4) {
            d3 = d3;
          } else {
            d3 = d4;
          } 
          d4 = d2 / d3 * d2 / d3 - paramPtr3.getDouble() / d3 * paramPtr9.getDouble() / d3;
          if (d4 >= 0.0D) {
            d4 = Mathlib.sqrt(d4) * d3;
          } else {
            d4 = 0.0D;
          } 
          d3 = d4;
          if (paramPtr7.getDouble() > paramPtr1.getDouble())
            d3 = -d4; 
          d2 = (d3 - paramPtr9.getDouble() + d2) / (paramPtr3.getDouble() - paramPtr9.getDouble() + d3 + d3);
          if (d2 >= 0.0D || d3 == 0.0D) {
            if (paramPtr7.getDouble() <= paramPtr1.getDouble()) {
              d2 = paramPtr11.getDouble();
            } else {
              d2 = paramPtr12.getDouble();
            } 
          } else {
            d2 = paramPtr7.getDouble() + (paramPtr1.getDouble() - paramPtr7.getDouble()) * d2;
          } 
          d3 = paramPtr7.getDouble() + paramPtr9.getDouble() / (paramPtr9.getDouble() - paramPtr3.getDouble()) * (paramPtr1.getDouble() - paramPtr7.getDouble());
          if (paramPtr10.getInt() == 0) {
            if (Math.abs(d2 - paramPtr7.getDouble()) <= Math.abs(d3 - paramPtr7.getDouble())) {
              d2 = d3;
            } else {
              d2 = d2;
            } 
            if (paramPtr12.getDouble() <= d2) {
              d2 = paramPtr12.getDouble();
            } else {
              d2 = d2;
            } 
            if (paramPtr11.getDouble() >= d2) {
              d2 = paramPtr11.getDouble();
            } else {
              d2 = d2;
            } 
            d2 = d2;
          } else {
            if (Math.abs(d2 - paramPtr7.getDouble()) >= Math.abs(d3 - paramPtr7.getDouble())) {
              d2 = d3;
            } else {
              d2 = d2;
            } 
            d3 = paramPtr7.getDouble() + (paramPtr4.getDouble() - paramPtr7.getDouble()) * 0.66D;
            if (paramPtr7.getDouble() <= paramPtr1.getDouble()) {
              if (d3 >= d2) {
                d2 = d3;
              } else {
                d2 = d2;
              } 
              d2 = d2;
            } else {
              if (d3 <= d2) {
                d2 = d3;
              } else {
                d2 = d2;
              } 
              d2 = d2;
            } 
          } 
        } 
      } else {
        d2 = (paramPtr2.getDouble() - paramPtr8.getDouble()) * 3.0D / (paramPtr7.getDouble() - paramPtr1.getDouble()) + paramPtr3.getDouble() + paramPtr9.getDouble();
        double d3 = Math.abs(d2);
        double d4 = Math.abs(paramPtr3.getDouble());
        if (d3 >= d4) {
          d3 = d3;
        } else {
          d3 = d4;
        } 
        d4 = Math.abs(paramPtr9.getDouble());
        if (d3 >= d4) {
          d3 = d3;
        } else {
          d3 = d4;
        } 
        d3 = Mathlib.sqrt(d2 / d3 * d2 / d3 - paramPtr3.getDouble() / d3 * paramPtr9.getDouble() / d3) * d3;
        if (paramPtr7.getDouble() > paramPtr1.getDouble())
          d3 = -d3; 
        d2 = paramPtr7.getDouble();
        d2 = (d3 - paramPtr9.getDouble() + d2) / (d3 - paramPtr9.getDouble() + d3 + paramPtr3.getDouble()) * (paramPtr1.getDouble() - paramPtr7.getDouble()) + d2;
        d3 = paramPtr7.getDouble() + paramPtr9.getDouble() / (paramPtr9.getDouble() - paramPtr3.getDouble()) * (paramPtr1.getDouble() - paramPtr7.getDouble());
        if (Math.abs(d2 - paramPtr7.getDouble()) <= Math.abs(d3 - paramPtr7.getDouble())) {
          d2 = d3;
        } else {
          d2 = d2;
        } 
        paramPtr10.setInt(1);
      } 
    } else {
      d2 = (paramPtr2.getDouble() - paramPtr8.getDouble()) * 3.0D / (paramPtr7.getDouble() - paramPtr1.getDouble()) + paramPtr3.getDouble() + paramPtr9.getDouble();
      double d3 = Math.abs(d2);
      double d4 = Math.abs(paramPtr3.getDouble());
      if (d3 >= d4) {
        d3 = d3;
      } else {
        d3 = d4;
      } 
      d4 = Math.abs(paramPtr9.getDouble());
      if (d3 >= d4) {
        d3 = d3;
      } else {
        d3 = d4;
      } 
      d3 = Mathlib.sqrt(d2 / d3 * d2 / d3 - paramPtr3.getDouble() / d3 * paramPtr9.getDouble() / d3) * d3;
      if (paramPtr7.getDouble() < paramPtr1.getDouble())
        d3 = -d3; 
      d2 = paramPtr1.getDouble();
      d2 = (d3 - paramPtr3.getDouble() + d2) / (d3 - paramPtr3.getDouble() + d3 + paramPtr9.getDouble()) * (paramPtr7.getDouble() - paramPtr1.getDouble()) + d2;
      d3 = paramPtr1.getDouble() + paramPtr3.getDouble() / ((paramPtr2.getDouble() - paramPtr8.getDouble()) / (paramPtr7.getDouble() - paramPtr1.getDouble()) + paramPtr3.getDouble()) / 2.0D * (paramPtr7.getDouble() - paramPtr1.getDouble());
      if (Math.abs(d2 - paramPtr1.getDouble()) >= Math.abs(d3 - paramPtr1.getDouble())) {
        d2 = (d3 - d2) / 2.0D + d2;
      } else {
        d2 = d2;
      } 
      paramPtr10.setInt(1);
    } 
    if (paramPtr8.getDouble() <= paramPtr2.getDouble()) {
      if (d1 < 0.0D) {
        paramPtr4.setDouble(paramPtr1.getDouble());
        paramPtr5.setDouble(paramPtr2.getDouble());
        paramPtr6.setDouble(paramPtr3.getDouble());
      } 
      paramPtr1.setDouble(paramPtr7.getDouble());
      paramPtr2.setDouble(paramPtr8.getDouble());
      paramPtr3.setDouble(paramPtr9.getDouble());
    } else {
      paramPtr4.setDouble(paramPtr7.getDouble());
      paramPtr5.setDouble(paramPtr8.getDouble());
      paramPtr6.setDouble(paramPtr9.getDouble());
    } 
    paramPtr7.setDouble(d2);
  }
  
  public static void errclb(int paramInt1, int paramInt2, double paramDouble, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    paramPtr3 = paramPtr3.pointerPlus(-4);
    paramPtr2 = paramPtr2.pointerPlus(-8);
    paramPtr1 = paramPtr1.pointerPlus(-8);
    if (paramInt1 <= 0)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: N .LE. 0\000".getBytes(), 0), 16); 
    if (paramInt2 <= 0)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: M .LE. 0\000".getBytes(), 0), 16); 
    if (paramDouble < 0.0D)
      paramPtr4.memcpy((Ptr)new BytePtr("ERROR: FACTR .LT. 0\000".getBytes(), 0), 20); 
    for (paramInt2 = 1; paramInt2 <= paramInt1; paramInt2++) {
      if (paramPtr3.getInt(paramInt2 * 4) < 0 || paramPtr3.getInt(paramInt2 * 4) > 3) {
        paramPtr4.memcpy((Ptr)new BytePtr("ERROR: INVALID NBD\000".getBytes(), 0), 19);
        paramPtr5.setInt(-6);
        paramPtr6.setInt(paramInt2);
      } 
      if (paramPtr3.getInt(paramInt2 * 4) == 2 && paramPtr1.getDouble(paramInt2 * 8) > paramPtr2.getDouble(paramInt2 * 8)) {
        paramPtr4.memcpy((Ptr)new BytePtr("ERROR: NO FEASIBLE SOLUTION\000".getBytes(), 0), 28);
        paramPtr5.setInt(-7);
        paramPtr6.setInt(paramInt2);
      } 
    } 
  }
  
  public static void formk(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, int paramInt2, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16) {
    int i;
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    arrayOfInt2[0] = 0;
    Ptr ptr1 = paramPtr5.pointerPlus(-4);
    Ptr ptr2 = paramPtr2.pointerPlus(-4);
    paramPtr12 = paramPtr12.pointerPlus(-((paramInt2 + 1) * 8));
    Ptr ptr3 = paramPtr11.pointerPlus(-((paramInt1 + 1) * 8));
    Ptr ptr4 = paramPtr10.pointerPlus(-((paramInt1 + 1) * 8));
    int i1 = paramInt2 * 2;
    paramPtr11 = paramPtr9.pointerPlus(-((i1 + 1) * 8));
    int j = paramInt2 * 2;
    int n = j + 1;
    paramPtr5 = paramPtr8.pointerPlus(-(n * 8));
    if (paramPtr7.getInt() == 0) {
      i = paramPtr14.getInt();
    } else {
      if (paramPtr6.getInt() > paramInt2)
        for (byte b1 = 1; paramInt2 + -1 >= b1; b1++) {
          int i7 = paramInt2 + b1;
          arrayOfInt1[0] = paramInt2 - b1;
          paramPtr7 = (Ptr)new IntPtr(arrayOfInt1, 0);
          paramPtr8 = paramPtr11.pointerPlus((i1 + 1) * 8 * (b1 + 1));
          Ptr ptr5 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
          Ptr ptr6 = paramPtr11.pointerPlus((i1 + 1) * 8 * b1);
          Blas.dcopy_(paramPtr7, paramPtr8, ptr5, ptr6, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
          paramPtr7 = (Ptr)new IntPtr(arrayOfInt1, 0);
          paramPtr8 = paramPtr11.pointerPlus((i1 + 1) * 8 * (i7 + 1));
          ptr5 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
          ptr6 = paramPtr11.pointerPlus((i1 + 1) * 8 * i7);
          Blas.dcopy_(paramPtr7, paramPtr8, ptr5, ptr6, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
          arrayOfInt1[0] = paramInt2 + -1;
          paramPtr7 = (Ptr)new IntPtr(arrayOfInt1, 0);
          paramPtr8 = paramPtr11.pointerPlus((paramInt2 + 2) * 8 + (b1 + 1) * 8 * i1);
          ptr5 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
          ptr6 = paramPtr11.pointerPlus((paramInt2 + 1 + b1 * i1) * 8);
          Blas.dcopy_(paramPtr7, paramPtr8, ptr5, ptr6, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
        }  
      int i2 = i.getInt();
      i = i.getInt() + 1;
      int i3 = paramPtr14.getInt();
      int i4 = paramPtr14.getInt() + paramInt2;
      int i5 = paramPtr15.getInt() + paramPtr14.getInt() + -1;
      if (i5 > paramInt2)
        i5 -= paramInt2; 
      int i6 = paramPtr15.getInt();
      byte b;
      for (b = 1; paramPtr14.getInt() >= b; b++) {
        int i7 = paramInt2 + b;
        double d1 = 0.0D;
        double d2 = 0.0D;
        double d3 = 0.0D;
        int i8;
        for (i8 = 1; i8 <= i2; i8++) {
          int i9 = ptr2.getInt(i8 * 4);
          d1 = ptr3.getDouble((i5 * paramInt1 + i9) * 8) * ptr3.getDouble((i6 * paramInt1 + i9) * 8) + d1;
        } 
        for (i8 = i; i8 <= paramInt1; i8++) {
          int i9 = ptr2.getInt(i8 * 4);
          d2 = ptr4.getDouble((i5 * paramInt1 + i9) * 8) * ptr4.getDouble((i6 * paramInt1 + i9) * 8) + d2;
          d3 = ptr4.getDouble((i5 * paramInt1 + i9) * 8) * ptr3.getDouble((i6 * paramInt1 + i9) * 8) + d3;
        } 
        paramPtr11.setDouble((b * i1 + i3) * 8, d1);
        paramPtr11.setDouble((i7 * i1 + i4) * 8, d2);
        paramPtr11.setDouble((b * i1 + i4) * 8, d3);
        i6 = i6 % paramInt2 + 1;
      } 
      i = paramPtr14.getInt();
      i3 = paramPtr15.getInt() + paramPtr14.getInt() + -1;
      if (i3 > paramInt2)
        i3 -= paramInt2; 
      i4 = paramPtr15.getInt();
      for (i5 = 1; paramPtr14.getInt() >= i5; i5++) {
        i6 = paramInt2 + i5;
        double d = 0.0D;
        for (b = 1; b <= i2; b++) {
          int i7 = ptr2.getInt(b * 4);
          d = ptr4.getDouble((i4 * paramInt1 + i7) * 8) * ptr3.getDouble((i3 * paramInt1 + i7) * 8) + d;
        } 
        i4 = i4 % paramInt2 + 1;
        paramPtr11.setDouble((i * i1 + i6) * 8, d);
      } 
      i = paramPtr14.getInt() + -1;
    } 
    int k = paramPtr15.getInt();
    int m;
    for (m = 1; m <= i; m++) {
      int i2 = paramInt2 + m;
      int i3 = paramPtr15.getInt();
      for (byte b = 1; b <= m; b++) {
        int i4 = paramInt2 + b;
        double d1 = 0.0D;
        double d2 = 0.0D;
        double d3 = 0.0D;
        double d4 = 0.0D;
        int i5;
        for (i5 = 1; paramPtr3.getInt() >= i5; i5++) {
          int i6 = ptr1.getInt(i5 * 4);
          d1 = ptr3.getDouble((k * paramInt1 + i6) * 8) * ptr3.getDouble((i3 * paramInt1 + i6) * 8) + d1;
          d2 = ptr4.getDouble((k * paramInt1 + i6) * 8) * ptr4.getDouble((i3 * paramInt1 + i6) * 8) + d2;
        } 
        for (i5 = paramPtr4.getInt(); i5 <= paramInt1; i5++) {
          int i6 = ptr1.getInt(i5 * 4);
          d3 = ptr3.getDouble((k * paramInt1 + i6) * 8) * ptr3.getDouble((i3 * paramInt1 + i6) * 8) + d3;
          d4 = ptr4.getDouble((k * paramInt1 + i6) * 8) * ptr4.getDouble((i3 * paramInt1 + i6) * 8) + d4;
        } 
        paramPtr11.setDouble((b * i1 + m) * 8, paramPtr11.getDouble((b * i1 + m) * 8) + d1 - d3);
        paramPtr11.setDouble((i4 * i1 + i2) * 8, paramPtr11.getDouble((i4 * i1 + i2) * 8) - d2 + d4);
        i3 = i3 % paramInt2 + 1;
      } 
      k = k % paramInt2 + 1;
    } 
    k = paramPtr15.getInt();
    for (m = paramInt2 + 1; paramInt2 + i >= m; m++) {
      int i2 = paramPtr15.getInt();
      for (byte b = 1; b <= i; b++) {
        double d1 = 0.0D;
        double d2 = 0.0D;
        int i3;
        for (i3 = 1; paramPtr3.getInt() >= i3; i3++) {
          int i4 = ptr1.getInt(i3 * 4);
          d1 = ptr4.getDouble((k * paramInt1 + i4) * 8) * ptr3.getDouble((i2 * paramInt1 + i4) * 8) + d1;
        } 
        for (i3 = paramPtr4.getInt(); i3 <= paramInt1; i3++) {
          int i4 = ptr1.getInt(i3 * 4);
          d2 = ptr4.getDouble((k * paramInt1 + i4) * 8) * ptr3.getDouble((i2 * paramInt1 + i4) * 8) + d2;
        } 
        if (b + paramInt2 < m) {
          paramPtr11.setDouble((b * i1 + m) * 8, paramPtr11.getDouble((b * i1 + m) * 8) + d2 - d1);
        } else {
          paramPtr11.setDouble((b * i1 + m) * 8, paramPtr11.getDouble((b * i1 + m) * 8) + d1 - d2);
        } 
        i2 = i2 % paramInt2 + 1;
      } 
      k = k % paramInt2 + 1;
    } 
    arrayOfInt2[0] = paramInt2 << 1;
    for (paramInt1 = 1; paramPtr14.getInt() >= paramInt1; paramInt1++) {
      i = paramPtr14.getInt() + paramInt1;
      int i2 = paramInt2 + paramInt1;
      int i3;
      for (i3 = 1; i3 <= paramInt1; i3++) {
        paramPtr5.setDouble((paramInt1 * j + i3) * 8, paramPtr11.getDouble((i3 * i1 + paramInt1) * 8) / paramPtr13.getDouble());
        paramPtr5.setDouble((paramPtr14.getInt() + i3 + i * j) * 8, paramPtr11.getDouble(((paramInt2 + i3) * i1 + i2) * 8) * paramPtr13.getDouble());
      } 
      for (i3 = 1; paramInt1 + -1 >= i3; i3++)
        paramPtr5.setDouble((i * j + i3) * 8, -paramPtr11.getDouble((i3 * i1 + i2) * 8)); 
      for (i3 = paramInt1; paramPtr14.getInt() >= i3; i3++)
        paramPtr5.setDouble((i * j + i3) * 8, paramPtr11.getDouble((i3 * i1 + i2) * 8)); 
      paramPtr5.setDouble((j + 1) * 8 * paramInt1, paramPtr5.getDouble((j + 1) * 8 * paramInt1) + paramPtr12.getDouble((paramInt2 + 1) * 8 * paramInt1));
    } 
    Appl.dpofa_(paramPtr5.pointerPlus(n * 8), (Ptr)new IntPtr(arrayOfInt2, 0), paramPtr14, paramPtr16);
    if (paramPtr16.getInt() == 0) {
      paramInt1 = paramPtr14.getInt() << 1;
      for (k = paramPtr14.getInt() + 1; k <= paramInt1; k++) {
        Ptr ptr = paramPtr5.pointerPlus(n * 8);
        paramPtr3 = (Ptr)new IntPtr(arrayOfInt2, 0);
        paramPtr4 = paramPtr5.pointerPlus((k * j + 1) * 8);
        Appl.dtrsl_(ptr, paramPtr3, paramPtr14, paramPtr4, IntFieldPtr.addressOf(lbfgsb__.class, "c__11"), paramPtr16);
      } 
      for (k = paramPtr14.getInt() + 1; k <= paramInt1; k++) {
        for (m = k; m <= paramInt1; m++) {
          Ptr ptr = paramPtr5.pointerPlus((k * j + 1) * 8);
          paramPtr3 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
          paramPtr4 = paramPtr5.pointerPlus((m * j + 1) * 8);
          paramPtr5.setDouble((m * j + k) * 8, paramPtr5.getDouble((m * j + k) * 8) + Blas.ddot_(paramPtr14, ptr, paramPtr3, paramPtr4, IntFieldPtr.addressOf(lbfgsb__.class, "c__1")));
        } 
      } 
      Appl.dpofa_(paramPtr5.pointerPlus((j + 1) * 8 * (paramPtr14.getInt() + 1)), (Ptr)new IntPtr(arrayOfInt2, 0), paramPtr14, paramPtr16);
      if (paramPtr16.getInt() != 0)
        paramPtr16.setInt(-2); 
      return;
    } 
    paramPtr16.setInt(-1);
  }
  
  public static void formt(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = paramInt;
    paramInt = arrayOfInt[0];
    paramPtr3 = paramPtr3.pointerPlus(-((paramInt + 1) * 8));
    int i = arrayOfInt[0];
    paramPtr2 = paramPtr2.pointerPlus(-((i + 1) * 8));
    int j = arrayOfInt[0];
    int k = j + 1;
    paramPtr1 = paramPtr1.pointerPlus(-(k * 8));
    byte b;
    for (b = 1; paramPtr4.getInt() >= b; b++)
      paramPtr1.setDouble((b * j + 1) * 8, paramPtr5.getDouble() * paramPtr3.getDouble((b * paramInt + 1) * 8)); 
    for (b = 2; paramPtr4.getInt() >= b; b++) {
      for (byte b1 = b; paramPtr4.getInt() >= b1; b1++) {
        if (b > b1) {
          m = b1;
        } else {
          m = b + -1;
        } 
        int m = m;
        double d = 0.0D;
        for (byte b2 = 1; b2 <= m; b2++)
          d = paramPtr2.getDouble((b2 * i + b) * 8) * paramPtr2.getDouble((b2 * i + b1) * 8) / paramPtr2.getDouble((i + 1) * 8 * b2) + d; 
        paramPtr1.setDouble((b1 * j + b) * 8, paramPtr5.getDouble() * paramPtr3.getDouble((b1 * paramInt + b) * 8) + d);
      } 
    } 
    Appl.dpofa_(paramPtr1.pointerPlus(k * 8), (Ptr)new IntPtr(arrayOfInt, 0), paramPtr4, paramPtr6);
    if (paramPtr6.getInt() != 0)
      paramPtr6.setInt(-3); 
  }
  
  public static void freev(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, int paramInt2, Ptr paramPtr10) {
    paramPtr6 = paramPtr6.pointerPlus(-4);
    paramPtr5 = paramPtr5.pointerPlus(-4);
    paramPtr2 = paramPtr2.pointerPlus(-4);
    paramPtr3.setInt(0);
    paramPtr4.setInt(paramInt1 + 1);
    if (paramPtr10.getInt() > 0 && paramPtr9.getInt() != 0) {
      int j;
      for (j = 1; paramPtr1.getInt() >= j; j++) {
        int k = paramPtr2.getInt(j * 4);
        if (paramPtr6.getInt(k * 4) > 0) {
          paramPtr4.setInt(paramPtr4.getInt() - 1);
          paramPtr5.setInt(paramPtr4.getInt() * 4, k);
          if (paramInt2 > 99)
            Print.Rprintf(new BytePtr("Variable %d leaves the set of free variables\n\000".getBytes(), 0), new Object[] { Integer.valueOf(k) }); 
        } 
      } 
      for (j = paramPtr1.getInt() + 1; j <= paramInt1; j++) {
        int k = paramPtr2.getInt(j * 4);
        if (paramPtr6.getInt(k * 4) <= 0) {
          paramPtr3.setInt(paramPtr3.getInt() + 1);
          paramPtr5.setInt(paramPtr3.getInt() * 4, k);
          if (paramInt2 > 99)
            Print.Rprintf(new BytePtr("Variable %d enters the set of free variables\n\000".getBytes(), 0), new Object[] { Integer.valueOf(k) }); 
        } 
        if (paramInt2 > 99) {
          BytePtr bytePtr = new BytePtr();
          this("%d variables leave; %d variables enter\n\000".getBytes(), 0);
          Object[] arrayOfObject = new Object[2];
          Integer integer = Integer.valueOf(paramInt1 + 1 - paramPtr4.getInt());
          arrayOfObject[0] = integer;
          integer = Integer.valueOf(paramPtr3.getInt());
          arrayOfObject[1] = integer;
          Print.Rprintf(bytePtr, arrayOfObject);
        } 
      } 
    } 
    if (paramPtr4.getInt() >= paramInt1 + 1 && paramPtr3.getInt() <= 0 && paramPtr8.getInt() == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    paramPtr7.setInt(i);
    paramPtr1.setInt(0);
    int i = paramInt1 + 1;
    for (byte b = 1; b <= paramInt1; b++) {
      if (paramPtr6.getInt(b * 4) > 0) {
        paramPtr2.setInt(--i * 4, b);
      } else {
        paramPtr1.setInt(paramPtr1.getInt() + 1);
        paramPtr2.setInt(paramPtr1.getInt() * 4, b);
      } 
    } 
    if (paramInt2 > 98) {
      BytePtr bytePtr = new BytePtr();
      this("%d  variables are free at GCP on iteration %d\n\000".getBytes(), 0);
      Object[] arrayOfObject = new Object[2];
      Integer integer = Integer.valueOf(paramPtr1.getInt());
      arrayOfObject[0] = integer;
      integer = Integer.valueOf(paramPtr10.getInt() + 1);
      arrayOfObject[1] = integer;
      Print.Rprintf(bytePtr, arrayOfObject);
    } 
  }
  
  public static void hpsolb(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, int paramInt2) {
    paramPtr2 = paramPtr2.pointerPlus(-4);
    paramPtr1 = paramPtr1.pointerPlus(-8);
    if (paramInt2 == 0)
      for (paramInt2 = 2; paramInt2 <= paramInt1; paramInt2++) {
        double d = paramPtr1.getDouble(paramInt2 * 8);
        int i = paramPtr2.getInt(paramInt2 * 4);
        int j;
        for (j = paramInt2; j > 1; j = k) {
          int k = j / 2;
          if (paramPtr1.getDouble(k * 8) <= d)
            break; 
          paramPtr1.setDouble(j * 8, paramPtr1.getDouble(k * 8));
          paramPtr2.setInt(j * 4, paramPtr2.getInt(k * 4));
        } 
        paramPtr1.setDouble(j * 8, d);
        paramPtr2.setInt(j * 4, i);
      }  
    if (paramInt1 > 1) {
      paramInt2 = 1;
      double d1 = paramPtr1.getAlignedDouble(1);
      int i = paramPtr2.getAlignedInt(1);
      double d2 = paramPtr1.getDouble(paramInt1 * 8);
      int j = paramPtr2.getInt(paramInt1 * 4);
      while (true) {
        int k = paramInt2 + paramInt2;
        if (paramInt1 + -1 < k)
          break; 
        if (paramPtr1.getDouble((k + 1) * 8) < paramPtr1.getDouble(k * 8))
          k++; 
        if (paramPtr1.getDouble(k * 8) >= d2)
          break; 
        paramPtr1.setDouble(paramInt2 * 8, paramPtr1.getDouble(k * 8));
        paramPtr2.setInt(paramInt2 * 4, paramPtr2.getInt(k * 4));
        paramInt2 = k;
      } 
      paramPtr1.setDouble(paramInt2 * 8, d2);
      paramPtr2.setInt(paramInt2 * 4, j);
      paramPtr1.setDouble(paramInt1 * 8, d1);
      paramPtr2.setInt(paramInt1 * 4, i);
    } 
  }
  
  public static void lnsrlb(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, Ptr paramPtr24, Ptr paramPtr25, Ptr paramPtr26, Ptr paramPtr27) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray int
    //   3: astore #30
    //   5: aload #30
    //   7: iconst_0
    //   8: iload_0
    //   9: iastore
    //   10: aload #13
    //   12: bipush #-8
    //   14: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   19: astore_0
    //   20: aload #12
    //   22: bipush #-8
    //   24: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   29: astore #12
    //   31: aload #11
    //   33: bipush #-8
    //   35: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   40: astore #11
    //   42: aload #10
    //   44: bipush #-8
    //   46: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   51: astore #10
    //   53: aload #9
    //   55: bipush #-8
    //   57: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   62: astore #9
    //   64: aload #4
    //   66: bipush #-8
    //   68: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   73: astore #4
    //   75: aload_3
    //   76: bipush #-4
    //   78: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   83: astore_3
    //   84: aload_2
    //   85: bipush #-8
    //   87: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   92: astore_2
    //   93: aload_1
    //   94: bipush #-8
    //   96: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   101: astore_1
    //   102: aload #24
    //   104: new org/renjin/gcc/runtime/BytePtr
    //   107: dup
    //   108: ldc_w 'FG_LN '
    //   111: invokevirtual getBytes : ()[B
    //   114: iconst_0
    //   115: invokespecial <init> : ([BI)V
    //   118: checkcast org/renjin/gcc/runtime/Ptr
    //   121: iconst_5
    //   122: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   125: ifeq -> 752
    //   128: aload #16
    //   130: new org/renjin/gcc/runtime/IntPtr
    //   133: dup
    //   134: aload #30
    //   136: iconst_0
    //   137: invokespecial <init> : ([II)V
    //   140: checkcast org/renjin/gcc/runtime/Ptr
    //   143: aload #10
    //   145: bipush #8
    //   147: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   152: ldc org/renjin/stats/lbfgsb__
    //   154: ldc_w 'c__1'
    //   157: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   160: aload #10
    //   162: bipush #8
    //   164: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   169: ldc org/renjin/stats/lbfgsb__
    //   171: ldc_w 'c__1'
    //   174: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   177: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   180: invokeinterface setDouble : (D)V
    //   185: aload #15
    //   187: aload #16
    //   189: invokeinterface getDouble : ()D
    //   194: invokestatic sqrt : (D)D
    //   197: invokeinterface setDouble : (D)V
    //   202: aload #18
    //   204: ldc2_w 1.0E10
    //   207: invokeinterface setDouble : (D)V
    //   212: aload #26
    //   214: invokeinterface getInt : ()I
    //   219: ifne -> 225
    //   222: goto -> 510
    //   225: aload #19
    //   227: invokeinterface getInt : ()I
    //   232: ifeq -> 238
    //   235: goto -> 249
    //   238: aload #18
    //   240: dconst_1
    //   241: invokeinterface setDouble : (D)V
    //   246: goto -> 510
    //   249: iconst_1
    //   250: istore #13
    //   252: goto -> 501
    //   255: aload #10
    //   257: iload #13
    //   259: bipush #8
    //   261: imul
    //   262: invokeinterface getDouble : (I)D
    //   267: dstore #28
    //   269: aload_3
    //   270: iload #13
    //   272: iconst_4
    //   273: imul
    //   274: invokeinterface getInt : (I)I
    //   279: ifne -> 285
    //   282: goto -> 498
    //   285: dload #28
    //   287: dconst_0
    //   288: dcmpg
    //   289: iflt -> 295
    //   292: goto -> 393
    //   295: aload_3
    //   296: iload #13
    //   298: iconst_4
    //   299: imul
    //   300: invokeinterface getInt : (I)I
    //   305: iconst_2
    //   306: if_icmple -> 312
    //   309: goto -> 393
    //   312: aload_1
    //   313: iload #13
    //   315: bipush #8
    //   317: imul
    //   318: invokeinterface getDouble : (I)D
    //   323: aload #4
    //   325: iload #13
    //   327: bipush #8
    //   329: imul
    //   330: invokeinterface getDouble : (I)D
    //   335: dsub
    //   336: dstore #31
    //   338: dload #31
    //   340: dconst_0
    //   341: dcmpl
    //   342: ifge -> 348
    //   345: goto -> 359
    //   348: aload #18
    //   350: dconst_0
    //   351: invokeinterface setDouble : (D)V
    //   356: goto -> 498
    //   359: aload #18
    //   361: invokeinterface getDouble : ()D
    //   366: dload #28
    //   368: dmul
    //   369: dload #31
    //   371: dcmpg
    //   372: iflt -> 378
    //   375: goto -> 498
    //   378: aload #18
    //   380: dload #31
    //   382: dload #28
    //   384: ddiv
    //   385: invokeinterface setDouble : (D)V
    //   390: goto -> 498
    //   393: dload #28
    //   395: dconst_0
    //   396: dcmpl
    //   397: ifgt -> 403
    //   400: goto -> 498
    //   403: aload_3
    //   404: iload #13
    //   406: iconst_4
    //   407: imul
    //   408: invokeinterface getInt : (I)I
    //   413: iconst_1
    //   414: if_icmpgt -> 420
    //   417: goto -> 498
    //   420: aload_2
    //   421: iload #13
    //   423: bipush #8
    //   425: imul
    //   426: invokeinterface getDouble : (I)D
    //   431: aload #4
    //   433: iload #13
    //   435: bipush #8
    //   437: imul
    //   438: invokeinterface getDouble : (I)D
    //   443: dsub
    //   444: dstore #31
    //   446: dload #31
    //   448: dconst_0
    //   449: dcmpg
    //   450: ifle -> 456
    //   453: goto -> 467
    //   456: aload #18
    //   458: dconst_0
    //   459: invokeinterface setDouble : (D)V
    //   464: goto -> 498
    //   467: aload #18
    //   469: invokeinterface getDouble : ()D
    //   474: dload #28
    //   476: dmul
    //   477: dload #31
    //   479: dcmpl
    //   480: ifgt -> 486
    //   483: goto -> 498
    //   486: aload #18
    //   488: dload #31
    //   490: dload #28
    //   492: ddiv
    //   493: invokeinterface setDouble : (D)V
    //   498: iinc #13, 1
    //   501: iload #13
    //   503: aload #30
    //   505: iconst_0
    //   506: iaload
    //   507: if_icmple -> 255
    //   510: aload #19
    //   512: invokeinterface getInt : ()I
    //   517: ifeq -> 523
    //   520: goto -> 591
    //   523: aload #25
    //   525: invokeinterface getInt : ()I
    //   530: ifeq -> 536
    //   533: goto -> 591
    //   536: dconst_1
    //   537: aload #15
    //   539: invokeinterface getDouble : ()D
    //   544: ddiv
    //   545: dstore #28
    //   547: aload #18
    //   549: invokeinterface getDouble : ()D
    //   554: dload #28
    //   556: dcmpg
    //   557: iflt -> 563
    //   560: goto -> 575
    //   563: aload #18
    //   565: invokeinterface getDouble : ()D
    //   570: dstore #28
    //   572: goto -> 579
    //   575: dload #28
    //   577: dstore #28
    //   579: aload #14
    //   581: dload #28
    //   583: invokeinterface setDouble : (D)V
    //   588: goto -> 599
    //   591: aload #14
    //   593: dconst_1
    //   594: invokeinterface setDouble : (D)V
    //   599: new org/renjin/gcc/runtime/IntPtr
    //   602: dup
    //   603: aload #30
    //   605: iconst_0
    //   606: invokespecial <init> : ([II)V
    //   609: checkcast org/renjin/gcc/runtime/Ptr
    //   612: aload #4
    //   614: bipush #8
    //   616: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   621: ldc org/renjin/stats/lbfgsb__
    //   623: ldc_w 'c__1'
    //   626: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   629: aload #12
    //   631: bipush #8
    //   633: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   638: ldc org/renjin/stats/lbfgsb__
    //   640: ldc_w 'c__1'
    //   643: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   646: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   649: new org/renjin/gcc/runtime/IntPtr
    //   652: dup
    //   653: aload #30
    //   655: iconst_0
    //   656: invokespecial <init> : ([II)V
    //   659: checkcast org/renjin/gcc/runtime/Ptr
    //   662: aload #9
    //   664: bipush #8
    //   666: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   671: ldc org/renjin/stats/lbfgsb__
    //   673: ldc_w 'c__1'
    //   676: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   679: aload #11
    //   681: bipush #8
    //   683: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   688: ldc org/renjin/stats/lbfgsb__
    //   690: ldc_w 'c__1'
    //   693: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   696: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   699: aload #6
    //   701: aload #5
    //   703: invokeinterface getDouble : ()D
    //   708: invokeinterface setDouble : (D)V
    //   713: aload #20
    //   715: iconst_0
    //   716: invokeinterface setInt : (I)V
    //   721: aload #21
    //   723: iconst_0
    //   724: invokeinterface setInt : (I)V
    //   729: aload #27
    //   731: new org/renjin/gcc/runtime/BytePtr
    //   734: dup
    //   735: ldc_w 'START '
    //   738: invokevirtual getBytes : ()[B
    //   741: iconst_0
    //   742: invokespecial <init> : ([BI)V
    //   745: bipush #6
    //   747: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   752: aload #7
    //   754: new org/renjin/gcc/runtime/IntPtr
    //   757: dup
    //   758: aload #30
    //   760: iconst_0
    //   761: invokespecial <init> : ([II)V
    //   764: checkcast org/renjin/gcc/runtime/Ptr
    //   767: aload #9
    //   769: bipush #8
    //   771: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   776: ldc org/renjin/stats/lbfgsb__
    //   778: ldc_w 'c__1'
    //   781: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   784: aload #10
    //   786: bipush #8
    //   788: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   793: ldc org/renjin/stats/lbfgsb__
    //   795: ldc_w 'c__1'
    //   798: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   801: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   804: invokeinterface setDouble : (D)V
    //   809: aload #20
    //   811: invokeinterface getInt : ()I
    //   816: ifeq -> 822
    //   819: goto -> 863
    //   822: aload #8
    //   824: aload #7
    //   826: invokeinterface getDouble : ()D
    //   831: invokeinterface setDouble : (D)V
    //   836: aload #7
    //   838: invokeinterface getDouble : ()D
    //   843: dconst_0
    //   844: dcmpl
    //   845: ifge -> 851
    //   848: goto -> 863
    //   851: aload #23
    //   853: bipush #-4
    //   855: invokeinterface setInt : (I)V
    //   860: goto -> 1193
    //   863: aload #5
    //   865: aload #7
    //   867: aload #14
    //   869: ldc2_w 0.001
    //   872: ldc2_w 0.9
    //   875: ldc2_w 0.1
    //   878: dconst_0
    //   879: aload #18
    //   881: invokeinterface getDouble : ()D
    //   886: aload #27
    //   888: invokestatic dcsrch : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;DDDDDLorg/renjin/gcc/runtime/Ptr;)V
    //   891: aload #17
    //   893: aload #14
    //   895: invokeinterface getDouble : ()D
    //   900: aload #15
    //   902: invokeinterface getDouble : ()D
    //   907: dmul
    //   908: invokeinterface setDouble : (D)V
    //   913: aload #27
    //   915: new org/renjin/gcc/runtime/BytePtr
    //   918: dup
    //   919: ldc_w 'CONV '
    //   922: invokevirtual getBytes : ()[B
    //   925: iconst_0
    //   926: invokespecial <init> : ([BI)V
    //   929: checkcast org/renjin/gcc/runtime/Ptr
    //   932: iconst_4
    //   933: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   936: ifne -> 942
    //   939: goto -> 1170
    //   942: aload #27
    //   944: new org/renjin/gcc/runtime/BytePtr
    //   947: dup
    //   948: ldc_w 'WARN '
    //   951: invokevirtual getBytes : ()[B
    //   954: iconst_0
    //   955: invokespecial <init> : ([BI)V
    //   958: checkcast org/renjin/gcc/runtime/Ptr
    //   961: iconst_4
    //   962: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   965: ifne -> 971
    //   968: goto -> 1170
    //   971: aload #24
    //   973: new org/renjin/gcc/runtime/BytePtr
    //   976: dup
    //   977: ldc_w 'FG_LNSRCH '
    //   980: invokevirtual getBytes : ()[B
    //   983: iconst_0
    //   984: invokespecial <init> : ([BI)V
    //   987: bipush #10
    //   989: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   994: aload #20
    //   996: aload #20
    //   998: invokeinterface getInt : ()I
    //   1003: iconst_1
    //   1004: iadd
    //   1005: invokeinterface setInt : (I)V
    //   1010: aload #22
    //   1012: aload #22
    //   1014: invokeinterface getInt : ()I
    //   1019: iconst_1
    //   1020: iadd
    //   1021: invokeinterface setInt : (I)V
    //   1026: aload #21
    //   1028: aload #20
    //   1030: invokeinterface getInt : ()I
    //   1035: iconst_m1
    //   1036: iadd
    //   1037: invokeinterface setInt : (I)V
    //   1042: aload #14
    //   1044: invokeinterface getDouble : ()D
    //   1049: dconst_1
    //   1050: dcmpl
    //   1051: ifeq -> 1057
    //   1054: goto -> 1109
    //   1057: new org/renjin/gcc/runtime/IntPtr
    //   1060: dup
    //   1061: aload #30
    //   1063: iconst_0
    //   1064: invokespecial <init> : ([II)V
    //   1067: checkcast org/renjin/gcc/runtime/Ptr
    //   1070: aload_0
    //   1071: bipush #8
    //   1073: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1078: ldc org/renjin/stats/lbfgsb__
    //   1080: ldc_w 'c__1'
    //   1083: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1086: aload #4
    //   1088: bipush #8
    //   1090: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1095: ldc org/renjin/stats/lbfgsb__
    //   1097: ldc_w 'c__1'
    //   1100: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1103: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1106: goto -> 1193
    //   1109: iconst_1
    //   1110: istore_0
    //   1111: goto -> 1159
    //   1114: aload #4
    //   1116: iload_0
    //   1117: bipush #8
    //   1119: imul
    //   1120: aload #14
    //   1122: invokeinterface getDouble : ()D
    //   1127: aload #10
    //   1129: iload_0
    //   1130: bipush #8
    //   1132: imul
    //   1133: invokeinterface getDouble : (I)D
    //   1138: dmul
    //   1139: aload #12
    //   1141: iload_0
    //   1142: bipush #8
    //   1144: imul
    //   1145: invokeinterface getDouble : (I)D
    //   1150: dadd
    //   1151: invokeinterface setDouble : (ID)V
    //   1156: iinc #0, 1
    //   1159: iload_0
    //   1160: aload #30
    //   1162: iconst_0
    //   1163: iaload
    //   1164: if_icmple -> 1114
    //   1167: goto -> 1193
    //   1170: aload #24
    //   1172: new org/renjin/gcc/runtime/BytePtr
    //   1175: dup
    //   1176: ldc_w 'NEW_X '
    //   1179: invokevirtual getBytes : ()[B
    //   1182: iconst_0
    //   1183: invokespecial <init> : ([BI)V
    //   1186: bipush #6
    //   1188: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1193: return
  }
  
  public static void mainlb(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, double paramDouble, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, Ptr paramPtr16, Ptr paramPtr17, Ptr paramPtr18, Ptr paramPtr19, Ptr paramPtr20, Ptr paramPtr21, Ptr paramPtr22, Ptr paramPtr23, int paramInt3, Ptr paramPtr24, Ptr paramPtr25) {
    // Byte code:
    //   0: iconst_1
    //   1: newarray int
    //   3: astore #39
    //   5: aload #39
    //   7: iconst_0
    //   8: iload_0
    //   9: iastore
    //   10: iconst_1
    //   11: newarray int
    //   13: astore #30
    //   15: iconst_1
    //   16: newarray double
    //   18: astore #31
    //   20: iconst_1
    //   21: newarray double
    //   23: astore #32
    //   25: iconst_1
    //   26: newarray double
    //   28: astore #33
    //   30: iconst_1
    //   31: newarray int
    //   33: astore #34
    //   35: iconst_4
    //   36: newarray byte
    //   38: astore_0
    //   39: aload #30
    //   41: iconst_0
    //   42: iconst_0
    //   43: iastore
    //   44: aload #33
    //   46: iconst_0
    //   47: dconst_0
    //   48: dastore
    //   49: aload #34
    //   51: iconst_0
    //   52: iconst_0
    //   53: iastore
    //   54: aload #34
    //   56: iconst_0
    //   57: iconst_0
    //   58: iastore
    //   59: aload #33
    //   61: iconst_0
    //   62: dconst_0
    //   63: dastore
    //   64: aload #25
    //   66: bipush #-4
    //   68: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   73: astore #25
    //   75: aload #24
    //   77: bipush #-4
    //   79: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   84: astore #24
    //   86: aload #23
    //   88: bipush #-4
    //   90: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   95: astore #23
    //   97: aload #21
    //   99: bipush #-8
    //   101: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   106: astore #21
    //   108: aload #20
    //   110: bipush #-8
    //   112: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   117: astore #20
    //   119: aload #19
    //   121: bipush #-8
    //   123: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   128: astore #19
    //   130: aload #18
    //   132: bipush #-8
    //   134: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   139: astore #18
    //   141: aload #7
    //   143: bipush #-8
    //   145: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   150: astore #7
    //   152: aload #5
    //   154: bipush #-4
    //   156: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   161: astore #5
    //   163: aload #4
    //   165: bipush #-8
    //   167: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   172: astore #4
    //   174: aload_3
    //   175: bipush #-8
    //   177: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   182: astore_3
    //   183: aload_2
    //   184: bipush #-8
    //   186: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   191: astore_2
    //   192: aload #22
    //   194: bipush #-8
    //   196: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   201: astore #22
    //   203: aload #26
    //   205: new org/renjin/gcc/runtime/BytePtr
    //   208: dup
    //   209: ldc_w 'START '
    //   212: invokevirtual getBytes : ()[B
    //   215: iconst_0
    //   216: invokespecial <init> : ([BI)V
    //   219: checkcast org/renjin/gcc/runtime/Ptr
    //   222: iconst_5
    //   223: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   226: ifeq -> 232
    //   229: goto -> 792
    //   232: getstatic org/renjin/stats/lbfgsb__.$mainlb$epsmch : [D
    //   235: iconst_0
    //   236: ldc2_w 2.220446049250313E-16
    //   239: dastore
    //   240: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   243: iconst_0
    //   244: dconst_0
    //   245: dastore
    //   246: getstatic org/renjin/stats/lbfgsb__.$mainlb$dnorm : [D
    //   249: iconst_0
    //   250: dconst_0
    //   251: dastore
    //   252: getstatic org/renjin/stats/lbfgsb__.$mainlb$gd : [D
    //   255: iconst_0
    //   256: dconst_0
    //   257: dastore
    //   258: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   261: iconst_0
    //   262: dconst_0
    //   263: dastore
    //   264: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   267: iconst_0
    //   268: dconst_0
    //   269: dastore
    //   270: aload #33
    //   272: iconst_0
    //   273: dconst_0
    //   274: dastore
    //   275: getstatic org/renjin/stats/lbfgsb__.$mainlb$stpmx : [D
    //   278: iconst_0
    //   279: dconst_0
    //   280: dastore
    //   281: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   284: iconst_0
    //   285: dconst_0
    //   286: dastore
    //   287: getstatic org/renjin/stats/lbfgsb__.$mainlb$dtd : [D
    //   290: iconst_0
    //   291: dconst_0
    //   292: dastore
    //   293: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   296: iconst_0
    //   297: iconst_0
    //   298: iastore
    //   299: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   302: iconst_0
    //   303: iconst_1
    //   304: iastore
    //   305: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   308: iconst_0
    //   309: dconst_1
    //   310: dastore
    //   311: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   314: iconst_0
    //   315: iconst_0
    //   316: iastore
    //   317: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   320: iconst_0
    //   321: iconst_0
    //   322: iastore
    //   323: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   326: iconst_0
    //   327: iconst_0
    //   328: iastore
    //   329: getstatic org/renjin/stats/lbfgsb__.$mainlb$itail : [I
    //   332: iconst_0
    //   333: iconst_0
    //   334: iastore
    //   335: getstatic org/renjin/stats/lbfgsb__.$mainlb$ifun : [I
    //   338: iconst_0
    //   339: iconst_0
    //   340: iastore
    //   341: getstatic org/renjin/stats/lbfgsb__.$mainlb$iword : [I
    //   344: iconst_0
    //   345: iconst_0
    //   346: iastore
    //   347: iconst_0
    //   348: putstatic org/renjin/stats/lbfgsb__.$mainlb$nact : I
    //   351: getstatic org/renjin/stats/lbfgsb__.$mainlb$ileave : [I
    //   354: iconst_0
    //   355: iconst_0
    //   356: iastore
    //   357: getstatic org/renjin/stats/lbfgsb__.$mainlb$nenter : [I
    //   360: iconst_0
    //   361: iconst_0
    //   362: iastore
    //   363: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   366: iconst_0
    //   367: iconst_0
    //   368: iastore
    //   369: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   372: iconst_0
    //   373: iconst_0
    //   374: iastore
    //   375: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   378: iconst_0
    //   379: iconst_0
    //   380: iastore
    //   381: iconst_0
    //   382: putstatic org/renjin/stats/lbfgsb__.$mainlb$nintol : I
    //   385: iconst_0
    //   386: putstatic org/renjin/stats/lbfgsb__.$mainlb$nskip : I
    //   389: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   392: iconst_0
    //   393: aload #39
    //   395: iconst_0
    //   396: iaload
    //   397: iastore
    //   398: dload #8
    //   400: getstatic org/renjin/stats/lbfgsb__.$mainlb$epsmch : [D
    //   403: iconst_0
    //   404: daload
    //   405: dmul
    //   406: putstatic org/renjin/stats/lbfgsb__.$mainlb$tol : D
    //   409: ldc_w '--- '
    //   412: invokevirtual getBytes : ()[B
    //   415: iconst_0
    //   416: aload_0
    //   417: iconst_0
    //   418: iconst_4
    //   419: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   422: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   425: iconst_0
    //   426: iconst_0
    //   427: iastore
    //   428: aload #39
    //   430: iconst_0
    //   431: iaload
    //   432: iload_1
    //   433: dload #8
    //   435: aload_3
    //   436: bipush #8
    //   438: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   443: aload #4
    //   445: bipush #8
    //   447: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   452: aload #5
    //   454: iconst_4
    //   455: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   460: aload #26
    //   462: new org/renjin/gcc/runtime/IntPtr
    //   465: dup
    //   466: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   469: iconst_0
    //   470: invokespecial <init> : ([II)V
    //   473: checkcast org/renjin/gcc/runtime/Ptr
    //   476: new org/renjin/gcc/runtime/IntPtr
    //   479: dup
    //   480: aload #34
    //   482: iconst_0
    //   483: invokespecial <init> : ([II)V
    //   486: checkcast org/renjin/gcc/runtime/Ptr
    //   489: invokestatic errclb : (IIDLorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   492: aload #26
    //   494: new org/renjin/gcc/runtime/BytePtr
    //   497: dup
    //   498: ldc_w 'ERROR '
    //   501: invokevirtual getBytes : ()[B
    //   504: iconst_0
    //   505: invokespecial <init> : ([BI)V
    //   508: checkcast org/renjin/gcc/runtime/Ptr
    //   511: iconst_5
    //   512: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   515: ifeq -> 521
    //   518: goto -> 653
    //   521: aload #34
    //   523: iconst_0
    //   524: iaload
    //   525: istore_1
    //   526: aload #33
    //   528: iconst_0
    //   529: daload
    //   530: dstore #37
    //   532: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   535: iconst_0
    //   536: daload
    //   537: dstore #35
    //   539: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   542: iconst_0
    //   543: iaload
    //   544: istore #13
    //   546: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   549: iconst_0
    //   550: iaload
    //   551: istore #12
    //   553: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   556: iconst_0
    //   557: daload
    //   558: dstore #8
    //   560: getstatic org/renjin/stats/lbfgsb__.$mainlb$nact : I
    //   563: istore #11
    //   565: getstatic org/renjin/stats/lbfgsb__.$mainlb$nskip : I
    //   568: istore #10
    //   570: getstatic org/renjin/stats/lbfgsb__.$mainlb$nintol : I
    //   573: istore #7
    //   575: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   578: iconst_0
    //   579: iaload
    //   580: istore #5
    //   582: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   585: iconst_0
    //   586: iaload
    //   587: istore #4
    //   589: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   592: iconst_0
    //   593: iaload
    //   594: istore_3
    //   595: aload #39
    //   597: iconst_0
    //   598: iaload
    //   599: aload_2
    //   600: bipush #8
    //   602: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   607: aload #6
    //   609: aload #26
    //   611: iload #27
    //   613: iload_3
    //   614: iload #4
    //   616: iload #5
    //   618: iload #7
    //   620: iload #10
    //   622: iload #11
    //   624: dload #8
    //   626: iload #12
    //   628: new org/renjin/gcc/runtime/BytePtr
    //   631: dup
    //   632: aload_0
    //   633: iconst_0
    //   634: invokespecial <init> : ([BI)V
    //   637: checkcast org/renjin/gcc/runtime/Ptr
    //   640: iload #13
    //   642: dload #35
    //   644: dload #37
    //   646: iload_1
    //   647: invokestatic prn3lb : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IIIIIIIDILorg/renjin/gcc/runtime/Ptr;IDDI)V
    //   650: goto -> 4882
    //   653: getstatic org/renjin/stats/lbfgsb__.$mainlb$epsmch : [D
    //   656: iconst_0
    //   657: daload
    //   658: dstore #8
    //   660: aload #39
    //   662: iconst_0
    //   663: iaload
    //   664: iload_1
    //   665: aload_3
    //   666: bipush #8
    //   668: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   673: aload #4
    //   675: bipush #8
    //   677: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   682: aload_2
    //   683: bipush #8
    //   685: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   690: iload #27
    //   692: dload #8
    //   694: invokestatic prn1lb : (IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ID)V
    //   697: aload #39
    //   699: iconst_0
    //   700: iaload
    //   701: aload_3
    //   702: bipush #8
    //   704: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   709: aload #4
    //   711: bipush #8
    //   713: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   718: aload #5
    //   720: iconst_4
    //   721: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   726: aload_2
    //   727: bipush #8
    //   729: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   734: aload #24
    //   736: iconst_4
    //   737: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   742: iload #27
    //   744: new org/renjin/gcc/runtime/IntPtr
    //   747: dup
    //   748: getstatic org/renjin/stats/lbfgsb__.$mainlb$prjctd : [I
    //   751: iconst_0
    //   752: invokespecial <init> : ([II)V
    //   755: checkcast org/renjin/gcc/runtime/Ptr
    //   758: new org/renjin/gcc/runtime/IntPtr
    //   761: dup
    //   762: getstatic org/renjin/stats/lbfgsb__.$mainlb$cnstnd : [I
    //   765: iconst_0
    //   766: invokespecial <init> : ([II)V
    //   769: checkcast org/renjin/gcc/runtime/Ptr
    //   772: new org/renjin/gcc/runtime/IntPtr
    //   775: dup
    //   776: getstatic org/renjin/stats/lbfgsb__.$mainlb$boxed : [I
    //   779: iconst_0
    //   780: invokespecial <init> : ([II)V
    //   783: checkcast org/renjin/gcc/runtime/Ptr
    //   786: invokestatic active : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   789: goto -> 1049
    //   792: aload #26
    //   794: new org/renjin/gcc/runtime/BytePtr
    //   797: dup
    //   798: ldc_w 'FG_LN '
    //   801: invokevirtual getBytes : ()[B
    //   804: iconst_0
    //   805: invokespecial <init> : ([BI)V
    //   808: checkcast org/renjin/gcc/runtime/Ptr
    //   811: iconst_5
    //   812: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   815: ifeq -> 2934
    //   818: aload #26
    //   820: new org/renjin/gcc/runtime/BytePtr
    //   823: dup
    //   824: ldc_w 'NEW_X '
    //   827: invokevirtual getBytes : ()[B
    //   830: iconst_0
    //   831: invokespecial <init> : ([BI)V
    //   834: checkcast org/renjin/gcc/runtime/Ptr
    //   837: iconst_5
    //   838: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   841: ifeq -> 3841
    //   844: aload #26
    //   846: new org/renjin/gcc/runtime/BytePtr
    //   849: dup
    //   850: ldc_w 'FG_ST '
    //   853: invokevirtual getBytes : ()[B
    //   856: iconst_0
    //   857: invokespecial <init> : ([BI)V
    //   860: checkcast org/renjin/gcc/runtime/Ptr
    //   863: iconst_5
    //   864: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   867: ifeq -> 1075
    //   870: aload #26
    //   872: new org/renjin/gcc/runtime/BytePtr
    //   875: dup
    //   876: ldc_w 'STOP '
    //   879: invokevirtual getBytes : ()[B
    //   882: iconst_0
    //   883: invokespecial <init> : ([BI)V
    //   886: checkcast org/renjin/gcc/runtime/Ptr
    //   889: iconst_4
    //   890: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   893: ifeq -> 899
    //   896: goto -> 1049
    //   899: aload #26
    //   901: bipush #6
    //   903: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   908: new org/renjin/gcc/runtime/BytePtr
    //   911: dup
    //   912: ldc_w 'CPU '
    //   915: invokevirtual getBytes : ()[B
    //   918: iconst_0
    //   919: invokespecial <init> : ([BI)V
    //   922: checkcast org/renjin/gcc/runtime/Ptr
    //   925: iconst_3
    //   926: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   929: ifeq -> 935
    //   932: goto -> 4739
    //   935: new org/renjin/gcc/runtime/IntPtr
    //   938: dup
    //   939: aload #39
    //   941: iconst_0
    //   942: invokespecial <init> : ([II)V
    //   945: checkcast org/renjin/gcc/runtime/Ptr
    //   948: aload #21
    //   950: bipush #8
    //   952: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   957: ldc org/renjin/stats/lbfgsb__
    //   959: ldc_w 'c__1'
    //   962: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   965: aload_2
    //   966: bipush #8
    //   968: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   973: ldc org/renjin/stats/lbfgsb__
    //   975: ldc_w 'c__1'
    //   978: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   981: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   984: new org/renjin/gcc/runtime/IntPtr
    //   987: dup
    //   988: aload #39
    //   990: iconst_0
    //   991: invokespecial <init> : ([II)V
    //   994: checkcast org/renjin/gcc/runtime/Ptr
    //   997: aload #19
    //   999: bipush #8
    //   1001: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1006: ldc org/renjin/stats/lbfgsb__
    //   1008: ldc_w 'c__1'
    //   1011: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1014: aload #7
    //   1016: bipush #8
    //   1018: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1023: ldc org/renjin/stats/lbfgsb__
    //   1025: ldc_w 'c__1'
    //   1028: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1031: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1034: aload #6
    //   1036: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   1039: iconst_0
    //   1040: daload
    //   1041: invokeinterface setDouble : (D)V
    //   1046: goto -> 4739
    //   1049: aload #26
    //   1051: new org/renjin/gcc/runtime/BytePtr
    //   1054: dup
    //   1055: ldc_w 'FG_START '
    //   1058: invokevirtual getBytes : ()[B
    //   1061: iconst_0
    //   1062: invokespecial <init> : ([BI)V
    //   1065: bipush #9
    //   1067: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1072: goto -> 4739
    //   1075: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   1078: iconst_0
    //   1079: iconst_1
    //   1080: iastore
    //   1081: aload #39
    //   1083: iconst_0
    //   1084: iaload
    //   1085: aload_3
    //   1086: bipush #8
    //   1088: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1093: aload #4
    //   1095: bipush #8
    //   1097: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1102: aload #5
    //   1104: iconst_4
    //   1105: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1110: aload_2
    //   1111: bipush #8
    //   1113: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1118: aload #7
    //   1120: bipush #8
    //   1122: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1127: new org/renjin/gcc/runtime/DoublePtr
    //   1130: dup
    //   1131: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   1134: iconst_0
    //   1135: invokespecial <init> : ([DI)V
    //   1138: checkcast org/renjin/gcc/runtime/Ptr
    //   1141: invokestatic projgr : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1144: iload #27
    //   1146: ifgt -> 1152
    //   1149: goto -> 1232
    //   1152: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   1155: iconst_0
    //   1156: daload
    //   1157: aload #6
    //   1159: invokeinterface getDouble : ()D
    //   1164: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   1167: iconst_0
    //   1168: iaload
    //   1169: new org/renjin/gcc/runtime/BytePtr
    //   1172: astore #14
    //   1174: aload #14
    //   1176: ldc_w 'At iterate %5d  f= %12.5g  |proj g|= %12.5g\\n '
    //   1179: invokevirtual getBytes : ()[B
    //   1182: iconst_0
    //   1183: invokespecial <init> : ([BI)V
    //   1186: iconst_3
    //   1187: anewarray java/lang/Object
    //   1190: astore #31
    //   1192: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1195: astore #32
    //   1197: aload #31
    //   1199: iconst_0
    //   1200: aload #32
    //   1202: aastore
    //   1203: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1206: astore #32
    //   1208: aload #31
    //   1210: iconst_1
    //   1211: aload #32
    //   1213: aastore
    //   1214: invokestatic valueOf : (D)Ljava/lang/Double;
    //   1217: astore #32
    //   1219: aload #31
    //   1221: iconst_2
    //   1222: aload #32
    //   1224: aastore
    //   1225: aload #14
    //   1227: aload #31
    //   1229: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1232: aload #10
    //   1234: invokeinterface getDouble : ()D
    //   1239: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   1242: iconst_0
    //   1243: daload
    //   1244: dcmpl
    //   1245: ifge -> 1251
    //   1248: goto -> 1277
    //   1251: aload #26
    //   1253: new org/renjin/gcc/runtime/BytePtr
    //   1256: dup
    //   1257: ldc_w 'CONVERGENCE: NORM OF PROJECTED GRADIENT <= PGTOL '
    //   1260: invokevirtual getBytes : ()[B
    //   1263: iconst_0
    //   1264: invokespecial <init> : ([BI)V
    //   1267: bipush #49
    //   1269: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1274: goto -> 4739
    //   1277: iload #27
    //   1279: bipush #98
    //   1281: if_icmpgt -> 1287
    //   1284: goto -> 1329
    //   1287: iconst_1
    //   1288: anewarray java/lang/Object
    //   1291: astore #14
    //   1293: aload #14
    //   1295: iconst_0
    //   1296: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   1299: iconst_0
    //   1300: iaload
    //   1301: new org/renjin/gcc/runtime/BytePtr
    //   1304: astore #10
    //   1306: aload #10
    //   1308: ldc_w 'Iteration %5d\\n '
    //   1311: invokevirtual getBytes : ()[B
    //   1314: iconst_0
    //   1315: invokespecial <init> : ([BI)V
    //   1318: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1321: aastore
    //   1322: aload #10
    //   1324: aload #14
    //   1326: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1329: getstatic org/renjin/stats/lbfgsb__.$mainlb$iword : [I
    //   1332: iconst_0
    //   1333: iconst_m1
    //   1334: iastore
    //   1335: getstatic org/renjin/stats/lbfgsb__.$mainlb$cnstnd : [I
    //   1338: iconst_0
    //   1339: iaload
    //   1340: ifeq -> 1346
    //   1343: goto -> 1424
    //   1346: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   1349: iconst_0
    //   1350: iaload
    //   1351: ifgt -> 1357
    //   1354: goto -> 1424
    //   1357: new org/renjin/gcc/runtime/IntPtr
    //   1360: dup
    //   1361: aload #39
    //   1363: iconst_0
    //   1364: invokespecial <init> : ([II)V
    //   1367: checkcast org/renjin/gcc/runtime/Ptr
    //   1370: aload_2
    //   1371: bipush #8
    //   1373: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1378: ldc org/renjin/stats/lbfgsb__
    //   1380: ldc_w 'c__1'
    //   1383: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1386: aload #18
    //   1388: bipush #8
    //   1390: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1395: ldc org/renjin/stats/lbfgsb__
    //   1397: ldc_w 'c__1'
    //   1400: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   1403: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1406: aload #30
    //   1408: iconst_0
    //   1409: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   1412: iconst_0
    //   1413: iaload
    //   1414: iastore
    //   1415: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   1418: iconst_0
    //   1419: iconst_0
    //   1420: iastore
    //   1421: goto -> 2064
    //   1424: aload #22
    //   1426: iload_1
    //   1427: bipush #48
    //   1429: imul
    //   1430: bipush #8
    //   1432: iadd
    //   1433: aload #22
    //   1435: iload_1
    //   1436: iconst_2
    //   1437: ishl
    //   1438: iconst_1
    //   1439: iadd
    //   1440: bipush #8
    //   1442: imul
    //   1443: aload #22
    //   1445: iload_1
    //   1446: iconst_1
    //   1447: ishl
    //   1448: iconst_1
    //   1449: iadd
    //   1450: bipush #8
    //   1452: imul
    //   1453: aload #39
    //   1455: iconst_0
    //   1456: iaload
    //   1457: istore #10
    //   1459: aload_2
    //   1460: bipush #8
    //   1462: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1467: astore #14
    //   1469: aload_3
    //   1470: bipush #8
    //   1472: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1477: astore #31
    //   1479: aload #4
    //   1481: bipush #8
    //   1483: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1488: astore #32
    //   1490: aload #5
    //   1492: iconst_4
    //   1493: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1498: astore #40
    //   1500: aload #7
    //   1502: bipush #8
    //   1504: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1509: astore #41
    //   1511: aload #25
    //   1513: iconst_4
    //   1514: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1519: astore #42
    //   1521: aload #24
    //   1523: iconst_4
    //   1524: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1529: astore #43
    //   1531: aload #21
    //   1533: bipush #8
    //   1535: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1540: astore #44
    //   1542: aload #20
    //   1544: bipush #8
    //   1546: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1551: astore #45
    //   1553: aload #18
    //   1555: bipush #8
    //   1557: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1562: astore #46
    //   1564: aload #12
    //   1566: iconst_0
    //   1567: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1572: astore #47
    //   1574: aload #11
    //   1576: iconst_0
    //   1577: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1582: astore #48
    //   1584: aload #13
    //   1586: iconst_0
    //   1587: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1592: astore #49
    //   1594: aload #15
    //   1596: iconst_0
    //   1597: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1602: astore #50
    //   1604: new org/renjin/gcc/runtime/DoublePtr
    //   1607: dup
    //   1608: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   1611: iconst_0
    //   1612: invokespecial <init> : ([DI)V
    //   1615: checkcast org/renjin/gcc/runtime/Ptr
    //   1618: astore #51
    //   1620: new org/renjin/gcc/runtime/IntPtr
    //   1623: dup
    //   1624: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   1627: iconst_0
    //   1628: invokespecial <init> : ([II)V
    //   1631: checkcast org/renjin/gcc/runtime/Ptr
    //   1634: astore #52
    //   1636: new org/renjin/gcc/runtime/IntPtr
    //   1639: dup
    //   1640: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   1643: iconst_0
    //   1644: invokespecial <init> : ([II)V
    //   1647: checkcast org/renjin/gcc/runtime/Ptr
    //   1650: astore #53
    //   1652: aload #22
    //   1654: bipush #8
    //   1656: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1661: astore #54
    //   1663: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1668: astore #55
    //   1670: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1675: astore #56
    //   1677: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1682: astore #57
    //   1684: iload #10
    //   1686: aload #14
    //   1688: aload #31
    //   1690: aload #32
    //   1692: aload #40
    //   1694: aload #41
    //   1696: aload #42
    //   1698: aload #43
    //   1700: aload #44
    //   1702: aload #45
    //   1704: aload #46
    //   1706: iload_1
    //   1707: aload #47
    //   1709: aload #48
    //   1711: aload #49
    //   1713: aload #50
    //   1715: aload #51
    //   1717: aload #52
    //   1719: aload #53
    //   1721: aload #54
    //   1723: aload #55
    //   1725: aload #56
    //   1727: aload #57
    //   1729: new org/renjin/gcc/runtime/IntPtr
    //   1732: dup
    //   1733: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   1736: iconst_0
    //   1737: invokespecial <init> : ([II)V
    //   1740: checkcast org/renjin/gcc/runtime/Ptr
    //   1743: iload #27
    //   1745: new org/renjin/gcc/runtime/DoublePtr
    //   1748: dup
    //   1749: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   1752: iconst_0
    //   1753: invokespecial <init> : ([DI)V
    //   1756: checkcast org/renjin/gcc/runtime/Ptr
    //   1759: new org/renjin/gcc/runtime/IntPtr
    //   1762: dup
    //   1763: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   1766: iconst_0
    //   1767: invokespecial <init> : ([II)V
    //   1770: checkcast org/renjin/gcc/runtime/Ptr
    //   1773: new org/renjin/gcc/runtime/DoublePtr
    //   1776: dup
    //   1777: getstatic org/renjin/stats/lbfgsb__.$mainlb$epsmch : [D
    //   1780: iconst_0
    //   1781: invokespecial <init> : ([DI)V
    //   1784: checkcast org/renjin/gcc/runtime/Ptr
    //   1787: invokestatic cauchy : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   1790: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   1793: iconst_0
    //   1794: iaload
    //   1795: ifne -> 1801
    //   1798: goto -> 1909
    //   1801: iload #27
    //   1803: ifgt -> 1809
    //   1806: goto -> 1870
    //   1809: new org/renjin/gcc/runtime/BytePtr
    //   1812: dup
    //   1813: ldc_w '%s\\n%s\\n '
    //   1816: invokevirtual getBytes : ()[B
    //   1819: iconst_0
    //   1820: invokespecial <init> : ([BI)V
    //   1823: iconst_2
    //   1824: anewarray java/lang/Object
    //   1827: astore #10
    //   1829: aload #10
    //   1831: iconst_0
    //   1832: new org/renjin/gcc/runtime/BytePtr
    //   1835: dup
    //   1836: ldc_w 'Singular triangular system detected; '
    //   1839: invokevirtual getBytes : ()[B
    //   1842: iconst_0
    //   1843: invokespecial <init> : ([BI)V
    //   1846: aastore
    //   1847: aload #10
    //   1849: iconst_1
    //   1850: new org/renjin/gcc/runtime/BytePtr
    //   1853: dup
    //   1854: ldc_w '   refresh the lbfgs memory and restart the iteration. '
    //   1857: invokevirtual getBytes : ()[B
    //   1860: iconst_0
    //   1861: invokespecial <init> : ([BI)V
    //   1864: aastore
    //   1865: aload #10
    //   1867: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   1870: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   1873: iconst_0
    //   1874: iconst_0
    //   1875: iastore
    //   1876: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   1879: iconst_0
    //   1880: iconst_0
    //   1881: iastore
    //   1882: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   1885: iconst_0
    //   1886: iconst_1
    //   1887: iastore
    //   1888: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   1891: iconst_0
    //   1892: dconst_1
    //   1893: dastore
    //   1894: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   1897: iconst_0
    //   1898: iconst_0
    //   1899: iastore
    //   1900: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   1903: iconst_0
    //   1904: iconst_0
    //   1905: iastore
    //   1906: goto -> 1277
    //   1909: getstatic org/renjin/stats/lbfgsb__.$mainlb$nintol : I
    //   1912: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   1915: iconst_0
    //   1916: iaload
    //   1917: iadd
    //   1918: putstatic org/renjin/stats/lbfgsb__.$mainlb$nintol : I
    //   1921: aload #39
    //   1923: iconst_0
    //   1924: iaload
    //   1925: new org/renjin/gcc/runtime/IntPtr
    //   1928: dup
    //   1929: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   1932: iconst_0
    //   1933: invokespecial <init> : ([II)V
    //   1936: checkcast org/renjin/gcc/runtime/Ptr
    //   1939: aload #23
    //   1941: iconst_4
    //   1942: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1947: new org/renjin/gcc/runtime/IntPtr
    //   1950: dup
    //   1951: getstatic org/renjin/stats/lbfgsb__.$mainlb$nenter : [I
    //   1954: iconst_0
    //   1955: invokespecial <init> : ([II)V
    //   1958: checkcast org/renjin/gcc/runtime/Ptr
    //   1961: new org/renjin/gcc/runtime/IntPtr
    //   1964: dup
    //   1965: getstatic org/renjin/stats/lbfgsb__.$mainlb$ileave : [I
    //   1968: iconst_0
    //   1969: invokespecial <init> : ([II)V
    //   1972: checkcast org/renjin/gcc/runtime/Ptr
    //   1975: aload #25
    //   1977: iconst_4
    //   1978: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1983: aload #24
    //   1985: iconst_4
    //   1986: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1991: new org/renjin/gcc/runtime/IntPtr
    //   1994: dup
    //   1995: aload #30
    //   1997: iconst_0
    //   1998: invokespecial <init> : ([II)V
    //   2001: checkcast org/renjin/gcc/runtime/Ptr
    //   2004: new org/renjin/gcc/runtime/IntPtr
    //   2007: dup
    //   2008: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   2011: iconst_0
    //   2012: invokespecial <init> : ([II)V
    //   2015: checkcast org/renjin/gcc/runtime/Ptr
    //   2018: new org/renjin/gcc/runtime/IntPtr
    //   2021: dup
    //   2022: getstatic org/renjin/stats/lbfgsb__.$mainlb$cnstnd : [I
    //   2025: iconst_0
    //   2026: invokespecial <init> : ([II)V
    //   2029: checkcast org/renjin/gcc/runtime/Ptr
    //   2032: iload #27
    //   2034: new org/renjin/gcc/runtime/IntPtr
    //   2037: dup
    //   2038: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   2041: iconst_0
    //   2042: invokespecial <init> : ([II)V
    //   2045: checkcast org/renjin/gcc/runtime/Ptr
    //   2048: invokestatic freev : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
    //   2051: aload #39
    //   2053: iconst_0
    //   2054: iaload
    //   2055: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   2058: iconst_0
    //   2059: iaload
    //   2060: isub
    //   2061: putstatic org/renjin/stats/lbfgsb__.$mainlb$nact : I
    //   2064: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   2067: iconst_0
    //   2068: iaload
    //   2069: ifeq -> 2880
    //   2072: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2075: iconst_0
    //   2076: iaload
    //   2077: ifeq -> 2880
    //   2080: aload #30
    //   2082: iconst_0
    //   2083: iaload
    //   2084: ifne -> 2090
    //   2087: goto -> 2280
    //   2090: aload #39
    //   2092: iconst_0
    //   2093: iaload
    //   2094: new org/renjin/gcc/runtime/IntPtr
    //   2097: dup
    //   2098: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   2101: iconst_0
    //   2102: invokespecial <init> : ([II)V
    //   2105: checkcast org/renjin/gcc/runtime/Ptr
    //   2108: aload #23
    //   2110: iconst_4
    //   2111: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2116: new org/renjin/gcc/runtime/IntPtr
    //   2119: dup
    //   2120: getstatic org/renjin/stats/lbfgsb__.$mainlb$nenter : [I
    //   2123: iconst_0
    //   2124: invokespecial <init> : ([II)V
    //   2127: checkcast org/renjin/gcc/runtime/Ptr
    //   2130: new org/renjin/gcc/runtime/IntPtr
    //   2133: dup
    //   2134: getstatic org/renjin/stats/lbfgsb__.$mainlb$ileave : [I
    //   2137: iconst_0
    //   2138: invokespecial <init> : ([II)V
    //   2141: checkcast org/renjin/gcc/runtime/Ptr
    //   2144: aload #25
    //   2146: iconst_4
    //   2147: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2152: new org/renjin/gcc/runtime/IntPtr
    //   2155: dup
    //   2156: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   2159: iconst_0
    //   2160: invokespecial <init> : ([II)V
    //   2163: checkcast org/renjin/gcc/runtime/Ptr
    //   2166: new org/renjin/gcc/runtime/IntPtr
    //   2169: dup
    //   2170: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   2173: iconst_0
    //   2174: invokespecial <init> : ([II)V
    //   2177: checkcast org/renjin/gcc/runtime/Ptr
    //   2180: aload #16
    //   2182: iconst_0
    //   2183: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2188: aload #17
    //   2190: iconst_0
    //   2191: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2196: iload_1
    //   2197: aload #11
    //   2199: iconst_0
    //   2200: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2205: aload #12
    //   2207: iconst_0
    //   2208: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2213: aload #13
    //   2215: iconst_0
    //   2216: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2221: new org/renjin/gcc/runtime/DoublePtr
    //   2224: dup
    //   2225: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   2228: iconst_0
    //   2229: invokespecial <init> : ([DI)V
    //   2232: checkcast org/renjin/gcc/runtime/Ptr
    //   2235: new org/renjin/gcc/runtime/IntPtr
    //   2238: dup
    //   2239: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2242: iconst_0
    //   2243: invokespecial <init> : ([II)V
    //   2246: checkcast org/renjin/gcc/runtime/Ptr
    //   2249: new org/renjin/gcc/runtime/IntPtr
    //   2252: dup
    //   2253: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   2256: iconst_0
    //   2257: invokespecial <init> : ([II)V
    //   2260: checkcast org/renjin/gcc/runtime/Ptr
    //   2263: new org/renjin/gcc/runtime/IntPtr
    //   2266: dup
    //   2267: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2270: iconst_0
    //   2271: invokespecial <init> : ([II)V
    //   2274: checkcast org/renjin/gcc/runtime/Ptr
    //   2277: invokestatic formk : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2280: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2283: iconst_0
    //   2284: iaload
    //   2285: ifne -> 2291
    //   2288: goto -> 2399
    //   2291: iload #27
    //   2293: ifge -> 2299
    //   2296: goto -> 2360
    //   2299: new org/renjin/gcc/runtime/BytePtr
    //   2302: dup
    //   2303: ldc_w '%s\\n%s\\n '
    //   2306: invokevirtual getBytes : ()[B
    //   2309: iconst_0
    //   2310: invokespecial <init> : ([BI)V
    //   2313: iconst_2
    //   2314: anewarray java/lang/Object
    //   2317: astore #10
    //   2319: aload #10
    //   2321: iconst_0
    //   2322: new org/renjin/gcc/runtime/BytePtr
    //   2325: dup
    //   2326: ldc_w 'Nonpositive definiteness in Cholesky factorization in formk; '
    //   2329: invokevirtual getBytes : ()[B
    //   2332: iconst_0
    //   2333: invokespecial <init> : ([BI)V
    //   2336: aastore
    //   2337: aload #10
    //   2339: iconst_1
    //   2340: new org/renjin/gcc/runtime/BytePtr
    //   2343: dup
    //   2344: ldc_w '   refresh the lbfgs memory and restart the iteration. '
    //   2347: invokevirtual getBytes : ()[B
    //   2350: iconst_0
    //   2351: invokespecial <init> : ([BI)V
    //   2354: aastore
    //   2355: aload #10
    //   2357: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2360: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2363: iconst_0
    //   2364: iconst_0
    //   2365: iastore
    //   2366: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2369: iconst_0
    //   2370: iconst_0
    //   2371: iastore
    //   2372: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   2375: iconst_0
    //   2376: iconst_1
    //   2377: iastore
    //   2378: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   2381: iconst_0
    //   2382: dconst_1
    //   2383: dastore
    //   2384: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   2387: iconst_0
    //   2388: iconst_0
    //   2389: iastore
    //   2390: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   2393: iconst_0
    //   2394: iconst_0
    //   2395: iastore
    //   2396: goto -> 1277
    //   2399: aload #39
    //   2401: iconst_0
    //   2402: iaload
    //   2403: iload_1
    //   2404: aload_2
    //   2405: bipush #8
    //   2407: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2412: aload #7
    //   2414: bipush #8
    //   2416: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2421: aload #11
    //   2423: iconst_0
    //   2424: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2429: aload #12
    //   2431: iconst_0
    //   2432: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2437: aload #13
    //   2439: iconst_0
    //   2440: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2445: aload #15
    //   2447: iconst_0
    //   2448: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2453: aload #18
    //   2455: bipush #8
    //   2457: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2462: aload #19
    //   2464: bipush #8
    //   2466: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2471: aload #22
    //   2473: bipush #8
    //   2475: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2480: aload #23
    //   2482: iconst_4
    //   2483: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2488: new org/renjin/gcc/runtime/DoublePtr
    //   2491: dup
    //   2492: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   2495: iconst_0
    //   2496: invokespecial <init> : ([DI)V
    //   2499: checkcast org/renjin/gcc/runtime/Ptr
    //   2502: new org/renjin/gcc/runtime/IntPtr
    //   2505: dup
    //   2506: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2509: iconst_0
    //   2510: invokespecial <init> : ([II)V
    //   2513: checkcast org/renjin/gcc/runtime/Ptr
    //   2516: new org/renjin/gcc/runtime/IntPtr
    //   2519: dup
    //   2520: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   2523: iconst_0
    //   2524: invokespecial <init> : ([II)V
    //   2527: checkcast org/renjin/gcc/runtime/Ptr
    //   2530: new org/renjin/gcc/runtime/IntPtr
    //   2533: dup
    //   2534: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   2537: iconst_0
    //   2538: invokespecial <init> : ([II)V
    //   2541: checkcast org/renjin/gcc/runtime/Ptr
    //   2544: new org/renjin/gcc/runtime/IntPtr
    //   2547: dup
    //   2548: getstatic org/renjin/stats/lbfgsb__.$mainlb$cnstnd : [I
    //   2551: iconst_0
    //   2552: invokespecial <init> : ([II)V
    //   2555: checkcast org/renjin/gcc/runtime/Ptr
    //   2558: new org/renjin/gcc/runtime/IntPtr
    //   2561: dup
    //   2562: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2565: iconst_0
    //   2566: invokespecial <init> : ([II)V
    //   2569: checkcast org/renjin/gcc/runtime/Ptr
    //   2572: invokestatic cmprlb : (IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   2575: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2578: iconst_0
    //   2579: iaload
    //   2580: ifne -> 2761
    //   2583: aload #39
    //   2585: iconst_0
    //   2586: iaload
    //   2587: iload_1
    //   2588: new org/renjin/gcc/runtime/IntPtr
    //   2591: dup
    //   2592: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfree : [I
    //   2595: iconst_0
    //   2596: invokespecial <init> : ([II)V
    //   2599: checkcast org/renjin/gcc/runtime/Ptr
    //   2602: aload #23
    //   2604: iconst_4
    //   2605: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2610: aload_3
    //   2611: bipush #8
    //   2613: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2618: aload #4
    //   2620: bipush #8
    //   2622: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2627: aload #5
    //   2629: iconst_4
    //   2630: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2635: aload #18
    //   2637: bipush #8
    //   2639: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2644: aload #19
    //   2646: bipush #8
    //   2648: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2653: aload #11
    //   2655: iconst_0
    //   2656: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2661: aload #12
    //   2663: iconst_0
    //   2664: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2669: new org/renjin/gcc/runtime/DoublePtr
    //   2672: dup
    //   2673: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   2676: iconst_0
    //   2677: invokespecial <init> : ([DI)V
    //   2680: checkcast org/renjin/gcc/runtime/Ptr
    //   2683: new org/renjin/gcc/runtime/IntPtr
    //   2686: dup
    //   2687: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2690: iconst_0
    //   2691: invokespecial <init> : ([II)V
    //   2694: checkcast org/renjin/gcc/runtime/Ptr
    //   2697: new org/renjin/gcc/runtime/IntPtr
    //   2700: dup
    //   2701: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   2704: iconst_0
    //   2705: invokespecial <init> : ([II)V
    //   2708: checkcast org/renjin/gcc/runtime/Ptr
    //   2711: new org/renjin/gcc/runtime/IntPtr
    //   2714: dup
    //   2715: getstatic org/renjin/stats/lbfgsb__.$mainlb$iword : [I
    //   2718: iconst_0
    //   2719: invokespecial <init> : ([II)V
    //   2722: checkcast org/renjin/gcc/runtime/Ptr
    //   2725: aload #22
    //   2727: bipush #8
    //   2729: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2734: aload #16
    //   2736: iconst_0
    //   2737: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2742: iload #27
    //   2744: new org/renjin/gcc/runtime/IntPtr
    //   2747: dup
    //   2748: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2751: iconst_0
    //   2752: invokespecial <init> : ([II)V
    //   2755: checkcast org/renjin/gcc/runtime/Ptr
    //   2758: invokestatic subsm : (IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
    //   2761: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2764: iconst_0
    //   2765: iaload
    //   2766: ifne -> 2772
    //   2769: goto -> 2880
    //   2772: iload #27
    //   2774: ifgt -> 2780
    //   2777: goto -> 2841
    //   2780: new org/renjin/gcc/runtime/BytePtr
    //   2783: dup
    //   2784: ldc_w '%s\\n%s\\n '
    //   2787: invokevirtual getBytes : ()[B
    //   2790: iconst_0
    //   2791: invokespecial <init> : ([BI)V
    //   2794: iconst_2
    //   2795: anewarray java/lang/Object
    //   2798: astore #10
    //   2800: aload #10
    //   2802: iconst_0
    //   2803: new org/renjin/gcc/runtime/BytePtr
    //   2806: dup
    //   2807: ldc_w 'Singular triangular system detected; '
    //   2810: invokevirtual getBytes : ()[B
    //   2813: iconst_0
    //   2814: invokespecial <init> : ([BI)V
    //   2817: aastore
    //   2818: aload #10
    //   2820: iconst_1
    //   2821: new org/renjin/gcc/runtime/BytePtr
    //   2824: dup
    //   2825: ldc_w '   refresh the lbfgs memory and restart the iteration. '
    //   2828: invokevirtual getBytes : ()[B
    //   2831: iconst_0
    //   2832: invokespecial <init> : ([BI)V
    //   2835: aastore
    //   2836: aload #10
    //   2838: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   2841: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   2844: iconst_0
    //   2845: iconst_0
    //   2846: iastore
    //   2847: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   2850: iconst_0
    //   2851: iconst_0
    //   2852: iastore
    //   2853: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   2856: iconst_0
    //   2857: iconst_1
    //   2858: iastore
    //   2859: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   2862: iconst_0
    //   2863: dconst_1
    //   2864: dastore
    //   2865: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   2868: iconst_0
    //   2869: iconst_0
    //   2870: iastore
    //   2871: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   2874: iconst_0
    //   2875: iconst_0
    //   2876: iastore
    //   2877: goto -> 1277
    //   2880: iconst_1
    //   2881: istore #10
    //   2883: goto -> 2925
    //   2886: aload #20
    //   2888: iload #10
    //   2890: bipush #8
    //   2892: imul
    //   2893: aload #18
    //   2895: iload #10
    //   2897: bipush #8
    //   2899: imul
    //   2900: invokeinterface getDouble : (I)D
    //   2905: aload_2
    //   2906: iload #10
    //   2908: bipush #8
    //   2910: imul
    //   2911: invokeinterface getDouble : (I)D
    //   2916: dsub
    //   2917: invokeinterface setDouble : (ID)V
    //   2922: iinc #10, 1
    //   2925: iload #10
    //   2927: aload #39
    //   2929: iconst_0
    //   2930: iaload
    //   2931: if_icmple -> 2886
    //   2934: aload #39
    //   2936: iconst_0
    //   2937: iaload
    //   2938: aload_3
    //   2939: bipush #8
    //   2941: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2946: aload #4
    //   2948: bipush #8
    //   2950: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2955: aload #5
    //   2957: iconst_4
    //   2958: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2963: aload_2
    //   2964: bipush #8
    //   2966: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2971: aload #6
    //   2973: new org/renjin/gcc/runtime/DoublePtr
    //   2976: dup
    //   2977: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   2980: iconst_0
    //   2981: invokespecial <init> : ([DI)V
    //   2984: checkcast org/renjin/gcc/runtime/Ptr
    //   2987: new org/renjin/gcc/runtime/DoublePtr
    //   2990: dup
    //   2991: getstatic org/renjin/stats/lbfgsb__.$mainlb$gd : [D
    //   2994: iconst_0
    //   2995: invokespecial <init> : ([DI)V
    //   2998: checkcast org/renjin/gcc/runtime/Ptr
    //   3001: new org/renjin/gcc/runtime/DoublePtr
    //   3004: dup
    //   3005: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   3008: iconst_0
    //   3009: invokespecial <init> : ([DI)V
    //   3012: checkcast org/renjin/gcc/runtime/Ptr
    //   3015: aload #7
    //   3017: bipush #8
    //   3019: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3024: aload #20
    //   3026: bipush #8
    //   3028: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3033: aload #19
    //   3035: bipush #8
    //   3037: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3042: aload #21
    //   3044: bipush #8
    //   3046: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3051: aload #18
    //   3053: bipush #8
    //   3055: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3060: new org/renjin/gcc/runtime/DoublePtr
    //   3063: dup
    //   3064: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   3067: iconst_0
    //   3068: invokespecial <init> : ([DI)V
    //   3071: checkcast org/renjin/gcc/runtime/Ptr
    //   3074: new org/renjin/gcc/runtime/DoublePtr
    //   3077: dup
    //   3078: getstatic org/renjin/stats/lbfgsb__.$mainlb$dnorm : [D
    //   3081: iconst_0
    //   3082: invokespecial <init> : ([DI)V
    //   3085: checkcast org/renjin/gcc/runtime/Ptr
    //   3088: new org/renjin/gcc/runtime/DoublePtr
    //   3091: dup
    //   3092: getstatic org/renjin/stats/lbfgsb__.$mainlb$dtd : [D
    //   3095: iconst_0
    //   3096: invokespecial <init> : ([DI)V
    //   3099: checkcast org/renjin/gcc/runtime/Ptr
    //   3102: new org/renjin/gcc/runtime/DoublePtr
    //   3105: dup
    //   3106: aload #33
    //   3108: iconst_0
    //   3109: invokespecial <init> : ([DI)V
    //   3112: checkcast org/renjin/gcc/runtime/Ptr
    //   3115: new org/renjin/gcc/runtime/DoublePtr
    //   3118: dup
    //   3119: getstatic org/renjin/stats/lbfgsb__.$mainlb$stpmx : [D
    //   3122: iconst_0
    //   3123: invokespecial <init> : ([DI)V
    //   3126: checkcast org/renjin/gcc/runtime/Ptr
    //   3129: new org/renjin/gcc/runtime/IntPtr
    //   3132: dup
    //   3133: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3136: iconst_0
    //   3137: invokespecial <init> : ([II)V
    //   3140: checkcast org/renjin/gcc/runtime/Ptr
    //   3143: new org/renjin/gcc/runtime/IntPtr
    //   3146: dup
    //   3147: getstatic org/renjin/stats/lbfgsb__.$mainlb$ifun : [I
    //   3150: iconst_0
    //   3151: invokespecial <init> : ([II)V
    //   3154: checkcast org/renjin/gcc/runtime/Ptr
    //   3157: new org/renjin/gcc/runtime/IntPtr
    //   3160: dup
    //   3161: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   3164: iconst_0
    //   3165: invokespecial <init> : ([II)V
    //   3168: checkcast org/renjin/gcc/runtime/Ptr
    //   3171: new org/renjin/gcc/runtime/IntPtr
    //   3174: dup
    //   3175: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3178: iconst_0
    //   3179: invokespecial <init> : ([II)V
    //   3182: checkcast org/renjin/gcc/runtime/Ptr
    //   3185: new org/renjin/gcc/runtime/IntPtr
    //   3188: dup
    //   3189: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3192: iconst_0
    //   3193: invokespecial <init> : ([II)V
    //   3196: checkcast org/renjin/gcc/runtime/Ptr
    //   3199: aload #26
    //   3201: new org/renjin/gcc/runtime/IntPtr
    //   3204: dup
    //   3205: getstatic org/renjin/stats/lbfgsb__.$mainlb$boxed : [I
    //   3208: iconst_0
    //   3209: invokespecial <init> : ([II)V
    //   3212: checkcast org/renjin/gcc/runtime/Ptr
    //   3215: new org/renjin/gcc/runtime/IntPtr
    //   3218: dup
    //   3219: getstatic org/renjin/stats/lbfgsb__.$mainlb$cnstnd : [I
    //   3222: iconst_0
    //   3223: invokespecial <init> : ([II)V
    //   3226: checkcast org/renjin/gcc/runtime/Ptr
    //   3229: aload #28
    //   3231: invokestatic lnsrlb : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3234: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3237: iconst_0
    //   3238: iaload
    //   3239: ifne -> 3255
    //   3242: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   3245: iconst_0
    //   3246: iaload
    //   3247: bipush #19
    //   3249: if_icmpgt -> 3255
    //   3252: goto -> 3623
    //   3255: new org/renjin/gcc/runtime/IntPtr
    //   3258: dup
    //   3259: aload #39
    //   3261: iconst_0
    //   3262: invokespecial <init> : ([II)V
    //   3265: checkcast org/renjin/gcc/runtime/Ptr
    //   3268: aload #21
    //   3270: bipush #8
    //   3272: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3277: ldc org/renjin/stats/lbfgsb__
    //   3279: ldc_w 'c__1'
    //   3282: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3285: aload_2
    //   3286: bipush #8
    //   3288: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3293: ldc org/renjin/stats/lbfgsb__
    //   3295: ldc_w 'c__1'
    //   3298: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3301: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3304: new org/renjin/gcc/runtime/IntPtr
    //   3307: dup
    //   3308: aload #39
    //   3310: iconst_0
    //   3311: invokespecial <init> : ([II)V
    //   3314: checkcast org/renjin/gcc/runtime/Ptr
    //   3317: aload #19
    //   3319: bipush #8
    //   3321: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3326: ldc org/renjin/stats/lbfgsb__
    //   3328: ldc_w 'c__1'
    //   3331: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3334: aload #7
    //   3336: bipush #8
    //   3338: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3343: ldc org/renjin/stats/lbfgsb__
    //   3345: ldc_w 'c__1'
    //   3348: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   3351: invokestatic dcopy_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3354: aload #6
    //   3356: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   3359: iconst_0
    //   3360: daload
    //   3361: invokeinterface setDouble : (D)V
    //   3366: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   3369: iconst_0
    //   3370: iaload
    //   3371: ifeq -> 3377
    //   3374: goto -> 3469
    //   3377: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3380: iconst_0
    //   3381: iaload
    //   3382: ifeq -> 3388
    //   3385: goto -> 3431
    //   3388: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3391: iconst_0
    //   3392: bipush #-9
    //   3394: iastore
    //   3395: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3398: iconst_0
    //   3399: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3402: iconst_0
    //   3403: iaload
    //   3404: iconst_1
    //   3405: isub
    //   3406: iastore
    //   3407: getstatic org/renjin/stats/lbfgsb__.$mainlb$ifun : [I
    //   3410: iconst_0
    //   3411: getstatic org/renjin/stats/lbfgsb__.$mainlb$ifun : [I
    //   3414: iconst_0
    //   3415: iaload
    //   3416: iconst_1
    //   3417: isub
    //   3418: iastore
    //   3419: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   3422: iconst_0
    //   3423: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   3426: iconst_0
    //   3427: iaload
    //   3428: iconst_1
    //   3429: isub
    //   3430: iastore
    //   3431: aload #26
    //   3433: new org/renjin/gcc/runtime/BytePtr
    //   3436: dup
    //   3437: ldc_w 'ERROR: ABNORMAL_TERMINATION_IN_LNSRCH '
    //   3440: invokevirtual getBytes : ()[B
    //   3443: iconst_0
    //   3444: invokespecial <init> : ([BI)V
    //   3447: bipush #38
    //   3449: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   3454: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3457: iconst_0
    //   3458: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3461: iconst_0
    //   3462: iaload
    //   3463: iconst_1
    //   3464: iadd
    //   3465: iastore
    //   3466: goto -> 4739
    //   3469: iload #27
    //   3471: ifgt -> 3477
    //   3474: goto -> 3538
    //   3477: new org/renjin/gcc/runtime/BytePtr
    //   3480: dup
    //   3481: ldc_w '%s\\n%s\\n '
    //   3484: invokevirtual getBytes : ()[B
    //   3487: iconst_0
    //   3488: invokespecial <init> : ([BI)V
    //   3491: iconst_2
    //   3492: anewarray java/lang/Object
    //   3495: astore #10
    //   3497: aload #10
    //   3499: iconst_0
    //   3500: new org/renjin/gcc/runtime/BytePtr
    //   3503: dup
    //   3504: ldc_w 'Bad direction in the line search; '
    //   3507: invokevirtual getBytes : ()[B
    //   3510: iconst_0
    //   3511: invokespecial <init> : ([BI)V
    //   3514: aastore
    //   3515: aload #10
    //   3517: iconst_1
    //   3518: new org/renjin/gcc/runtime/BytePtr
    //   3521: dup
    //   3522: ldc_w '   refresh the lbfgs memory and restart the iteration. '
    //   3525: invokevirtual getBytes : ()[B
    //   3528: iconst_0
    //   3529: invokespecial <init> : ([BI)V
    //   3532: aastore
    //   3533: aload #10
    //   3535: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   3538: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3541: iconst_0
    //   3542: iaload
    //   3543: ifeq -> 3549
    //   3546: goto -> 3561
    //   3549: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3552: iconst_0
    //   3553: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3556: iconst_0
    //   3557: iaload
    //   3558: iconst_1
    //   3559: isub
    //   3560: iastore
    //   3561: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   3564: iconst_0
    //   3565: iconst_0
    //   3566: iastore
    //   3567: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   3570: iconst_0
    //   3571: iconst_0
    //   3572: iastore
    //   3573: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   3576: iconst_0
    //   3577: iconst_1
    //   3578: iastore
    //   3579: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   3582: iconst_0
    //   3583: dconst_1
    //   3584: dastore
    //   3585: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   3588: iconst_0
    //   3589: iconst_0
    //   3590: iastore
    //   3591: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   3594: iconst_0
    //   3595: iconst_0
    //   3596: iastore
    //   3597: aload #26
    //   3599: new org/renjin/gcc/runtime/BytePtr
    //   3602: dup
    //   3603: ldc_w 'RESTART_FROM_LNSRCH '
    //   3606: invokevirtual getBytes : ()[B
    //   3609: iconst_0
    //   3610: invokespecial <init> : ([BI)V
    //   3613: bipush #20
    //   3615: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   3620: goto -> 1277
    //   3623: aload #26
    //   3625: new org/renjin/gcc/runtime/BytePtr
    //   3628: dup
    //   3629: ldc_w 'FG_LN '
    //   3632: invokevirtual getBytes : ()[B
    //   3635: iconst_0
    //   3636: invokespecial <init> : ([BI)V
    //   3639: checkcast org/renjin/gcc/runtime/Ptr
    //   3642: iconst_5
    //   3643: invokestatic strncmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
    //   3646: ifeq -> 4739
    //   3649: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3652: iconst_0
    //   3653: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3656: iconst_0
    //   3657: iaload
    //   3658: iconst_1
    //   3659: iadd
    //   3660: iastore
    //   3661: aload #39
    //   3663: iconst_0
    //   3664: iaload
    //   3665: aload_3
    //   3666: bipush #8
    //   3668: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3673: aload #4
    //   3675: bipush #8
    //   3677: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3682: aload #5
    //   3684: iconst_4
    //   3685: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3690: aload_2
    //   3691: bipush #8
    //   3693: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3698: aload #7
    //   3700: bipush #8
    //   3702: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3707: new org/renjin/gcc/runtime/DoublePtr
    //   3710: dup
    //   3711: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   3714: iconst_0
    //   3715: invokespecial <init> : ([DI)V
    //   3718: checkcast org/renjin/gcc/runtime/Ptr
    //   3721: invokestatic projgr : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   3724: aload #33
    //   3726: iconst_0
    //   3727: daload
    //   3728: dstore #37
    //   3730: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   3733: iconst_0
    //   3734: daload
    //   3735: dstore #35
    //   3737: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   3740: iconst_0
    //   3741: iaload
    //   3742: istore #11
    //   3744: getstatic org/renjin/stats/lbfgsb__.$mainlb$iword : [I
    //   3747: iconst_0
    //   3748: iaload
    //   3749: istore #10
    //   3751: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   3754: iconst_0
    //   3755: iaload
    //   3756: istore #5
    //   3758: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   3761: iconst_0
    //   3762: daload
    //   3763: dstore #8
    //   3765: getstatic org/renjin/stats/lbfgsb__.$mainlb$nact : I
    //   3768: istore #4
    //   3770: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   3773: iconst_0
    //   3774: iaload
    //   3775: istore_3
    //   3776: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   3779: iconst_0
    //   3780: iaload
    //   3781: istore_1
    //   3782: aload #39
    //   3784: iconst_0
    //   3785: iaload
    //   3786: aload_2
    //   3787: bipush #8
    //   3789: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3794: aload #6
    //   3796: aload #7
    //   3798: bipush #8
    //   3800: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   3805: iload #27
    //   3807: iload_1
    //   3808: iload_3
    //   3809: iload #4
    //   3811: dload #8
    //   3813: iload #5
    //   3815: new org/renjin/gcc/runtime/BytePtr
    //   3818: dup
    //   3819: aload_0
    //   3820: iconst_0
    //   3821: invokespecial <init> : ([BI)V
    //   3824: checkcast org/renjin/gcc/runtime/Ptr
    //   3827: iload #10
    //   3829: iload #11
    //   3831: dload #35
    //   3833: dload #37
    //   3835: invokestatic prn2lb : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IIIIDILorg/renjin/gcc/runtime/Ptr;IIDD)V
    //   3838: goto -> 4739
    //   3841: aload #10
    //   3843: invokeinterface getDouble : ()D
    //   3848: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   3851: iconst_0
    //   3852: daload
    //   3853: dcmpl
    //   3854: ifge -> 3860
    //   3857: goto -> 3886
    //   3860: aload #26
    //   3862: new org/renjin/gcc/runtime/BytePtr
    //   3865: dup
    //   3866: ldc_w 'CONVERGENCE: NORM OF PROJECTED GRADIENT <= PGTOL '
    //   3869: invokevirtual getBytes : ()[B
    //   3872: iconst_0
    //   3873: invokespecial <init> : ([BI)V
    //   3876: bipush #49
    //   3878: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   3883: goto -> 4739
    //   3886: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   3889: iconst_0
    //   3890: daload
    //   3891: invokestatic abs : (D)D
    //   3894: dstore #35
    //   3896: aload #6
    //   3898: invokeinterface getDouble : ()D
    //   3903: invokestatic abs : (D)D
    //   3906: dstore #8
    //   3908: dload #35
    //   3910: dload #8
    //   3912: dcmpg
    //   3913: iflt -> 3919
    //   3916: goto -> 3926
    //   3919: dload #8
    //   3921: dstore #8
    //   3923: goto -> 3930
    //   3926: dload #35
    //   3928: dstore #8
    //   3930: dload #8
    //   3932: dconst_1
    //   3933: dcmpg
    //   3934: iflt -> 3940
    //   3937: goto -> 3946
    //   3940: dconst_1
    //   3941: dstore #8
    //   3943: goto -> 3950
    //   3946: dload #8
    //   3948: dstore #8
    //   3950: getstatic org/renjin/stats/lbfgsb__.$mainlb$fold : [D
    //   3953: iconst_0
    //   3954: daload
    //   3955: aload #6
    //   3957: invokeinterface getDouble : ()D
    //   3962: dsub
    //   3963: getstatic org/renjin/stats/lbfgsb__.$mainlb$tol : D
    //   3966: dload #8
    //   3968: dmul
    //   3969: dcmpg
    //   3970: ifle -> 3976
    //   3973: goto -> 4022
    //   3976: aload #26
    //   3978: new org/renjin/gcc/runtime/BytePtr
    //   3981: dup
    //   3982: ldc_w 'CONVERGENCE: REL_REDUCTION_OF_F <= FACTR*EPSMCH '
    //   3985: invokevirtual getBytes : ()[B
    //   3988: iconst_0
    //   3989: invokespecial <init> : ([BI)V
    //   3992: bipush #48
    //   3994: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   3999: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   4002: iconst_0
    //   4003: iaload
    //   4004: bipush #9
    //   4006: if_icmpgt -> 4012
    //   4009: goto -> 4739
    //   4012: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   4015: iconst_0
    //   4016: bipush #-5
    //   4018: iastore
    //   4019: goto -> 4739
    //   4022: iconst_1
    //   4023: istore #10
    //   4025: goto -> 4068
    //   4028: aload #19
    //   4030: iload #10
    //   4032: bipush #8
    //   4034: imul
    //   4035: aload #7
    //   4037: iload #10
    //   4039: bipush #8
    //   4041: imul
    //   4042: invokeinterface getDouble : (I)D
    //   4047: aload #19
    //   4049: iload #10
    //   4051: bipush #8
    //   4053: imul
    //   4054: invokeinterface getDouble : (I)D
    //   4059: dsub
    //   4060: invokeinterface setDouble : (ID)V
    //   4065: iinc #10, 1
    //   4068: iload #10
    //   4070: aload #39
    //   4072: iconst_0
    //   4073: iaload
    //   4074: if_icmple -> 4028
    //   4077: aload #31
    //   4079: iconst_0
    //   4080: new org/renjin/gcc/runtime/IntPtr
    //   4083: dup
    //   4084: aload #39
    //   4086: iconst_0
    //   4087: invokespecial <init> : ([II)V
    //   4090: checkcast org/renjin/gcc/runtime/Ptr
    //   4093: aload #19
    //   4095: bipush #8
    //   4097: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4102: ldc org/renjin/stats/lbfgsb__
    //   4104: ldc_w 'c__1'
    //   4107: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   4110: aload #19
    //   4112: bipush #8
    //   4114: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4119: ldc org/renjin/stats/lbfgsb__
    //   4121: ldc_w 'c__1'
    //   4124: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   4127: invokestatic ddot_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)D
    //   4130: dastore
    //   4131: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4134: iconst_0
    //   4135: daload
    //   4136: dconst_1
    //   4137: dcmpl
    //   4138: ifeq -> 4144
    //   4141: goto -> 4170
    //   4144: aload #32
    //   4146: iconst_0
    //   4147: getstatic org/renjin/stats/lbfgsb__.$mainlb$gd : [D
    //   4150: iconst_0
    //   4151: daload
    //   4152: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   4155: iconst_0
    //   4156: daload
    //   4157: dsub
    //   4158: dastore
    //   4159: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   4162: iconst_0
    //   4163: daload
    //   4164: dneg
    //   4165: dstore #8
    //   4167: goto -> 4252
    //   4170: aload #32
    //   4172: iconst_0
    //   4173: getstatic org/renjin/stats/lbfgsb__.$mainlb$gd : [D
    //   4176: iconst_0
    //   4177: daload
    //   4178: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   4181: iconst_0
    //   4182: daload
    //   4183: dsub
    //   4184: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4187: iconst_0
    //   4188: daload
    //   4189: dmul
    //   4190: dastore
    //   4191: new org/renjin/gcc/runtime/IntPtr
    //   4194: dup
    //   4195: aload #39
    //   4197: iconst_0
    //   4198: invokespecial <init> : ([II)V
    //   4201: checkcast org/renjin/gcc/runtime/Ptr
    //   4204: new org/renjin/gcc/runtime/DoublePtr
    //   4207: dup
    //   4208: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4211: iconst_0
    //   4212: invokespecial <init> : ([DI)V
    //   4215: checkcast org/renjin/gcc/runtime/Ptr
    //   4218: aload #20
    //   4220: bipush #8
    //   4222: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4227: ldc org/renjin/stats/lbfgsb__
    //   4229: ldc_w 'c__1'
    //   4232: invokestatic addressOf : (Ljava/lang/Class;Ljava/lang/String;)Lorg/renjin/gcc/runtime/Ptr;
    //   4235: invokestatic dscal_ : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   4238: getstatic org/renjin/stats/lbfgsb__.$mainlb$gdold : [D
    //   4241: iconst_0
    //   4242: daload
    //   4243: dneg
    //   4244: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4247: iconst_0
    //   4248: daload
    //   4249: dmul
    //   4250: dstore #8
    //   4252: getstatic org/renjin/stats/lbfgsb__.$mainlb$epsmch : [D
    //   4255: iconst_0
    //   4256: daload
    //   4257: dload #8
    //   4259: dmul
    //   4260: aload #32
    //   4262: iconst_0
    //   4263: daload
    //   4264: dcmpl
    //   4265: ifge -> 4271
    //   4268: goto -> 4350
    //   4271: getstatic org/renjin/stats/lbfgsb__.$mainlb$nskip : I
    //   4274: iconst_1
    //   4275: iadd
    //   4276: putstatic org/renjin/stats/lbfgsb__.$mainlb$nskip : I
    //   4279: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   4282: iconst_0
    //   4283: iconst_0
    //   4284: iastore
    //   4285: iload #27
    //   4287: ifgt -> 4293
    //   4290: goto -> 1277
    //   4293: aload #32
    //   4295: iconst_0
    //   4296: daload
    //   4297: new org/renjin/gcc/runtime/BytePtr
    //   4300: astore #10
    //   4302: aload #10
    //   4304: ldc_w 'ys=%10.3e  -gs=%10.3e, BFGS update SKIPPED\\n '
    //   4307: invokevirtual getBytes : ()[B
    //   4310: iconst_0
    //   4311: invokespecial <init> : ([BI)V
    //   4314: iconst_2
    //   4315: anewarray java/lang/Object
    //   4318: astore #14
    //   4320: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4323: astore #31
    //   4325: aload #14
    //   4327: iconst_0
    //   4328: aload #31
    //   4330: aastore
    //   4331: aload #14
    //   4333: iconst_1
    //   4334: dload #8
    //   4336: invokestatic valueOf : (D)Ljava/lang/Double;
    //   4339: aastore
    //   4340: aload #10
    //   4342: aload #14
    //   4344: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   4347: goto -> 1277
    //   4350: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   4353: iconst_0
    //   4354: iconst_1
    //   4355: iastore
    //   4356: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   4359: iconst_0
    //   4360: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   4363: iconst_0
    //   4364: iaload
    //   4365: iconst_1
    //   4366: iadd
    //   4367: iastore
    //   4368: aload #39
    //   4370: iconst_0
    //   4371: iaload
    //   4372: iload_1
    //   4373: aload #11
    //   4375: iconst_0
    //   4376: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4381: aload #12
    //   4383: iconst_0
    //   4384: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4389: aload #13
    //   4391: iconst_0
    //   4392: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4397: aload #14
    //   4399: iconst_0
    //   4400: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4405: aload #20
    //   4407: bipush #8
    //   4409: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4414: aload #19
    //   4416: bipush #8
    //   4418: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4423: new org/renjin/gcc/runtime/IntPtr
    //   4426: dup
    //   4427: getstatic org/renjin/stats/lbfgsb__.$mainlb$itail : [I
    //   4430: iconst_0
    //   4431: invokespecial <init> : ([II)V
    //   4434: checkcast org/renjin/gcc/runtime/Ptr
    //   4437: new org/renjin/gcc/runtime/IntPtr
    //   4440: dup
    //   4441: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   4444: iconst_0
    //   4445: invokespecial <init> : ([II)V
    //   4448: checkcast org/renjin/gcc/runtime/Ptr
    //   4451: new org/renjin/gcc/runtime/IntPtr
    //   4454: dup
    //   4455: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   4458: iconst_0
    //   4459: invokespecial <init> : ([II)V
    //   4462: checkcast org/renjin/gcc/runtime/Ptr
    //   4465: new org/renjin/gcc/runtime/IntPtr
    //   4468: dup
    //   4469: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   4472: iconst_0
    //   4473: invokespecial <init> : ([II)V
    //   4476: checkcast org/renjin/gcc/runtime/Ptr
    //   4479: new org/renjin/gcc/runtime/DoublePtr
    //   4482: dup
    //   4483: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   4486: iconst_0
    //   4487: invokespecial <init> : ([DI)V
    //   4490: checkcast org/renjin/gcc/runtime/Ptr
    //   4493: new org/renjin/gcc/runtime/DoublePtr
    //   4496: dup
    //   4497: aload #31
    //   4499: iconst_0
    //   4500: invokespecial <init> : ([DI)V
    //   4503: checkcast org/renjin/gcc/runtime/Ptr
    //   4506: new org/renjin/gcc/runtime/DoublePtr
    //   4509: dup
    //   4510: aload #32
    //   4512: iconst_0
    //   4513: invokespecial <init> : ([DI)V
    //   4516: checkcast org/renjin/gcc/runtime/Ptr
    //   4519: new org/renjin/gcc/runtime/DoublePtr
    //   4522: dup
    //   4523: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4526: iconst_0
    //   4527: invokespecial <init> : ([DI)V
    //   4530: checkcast org/renjin/gcc/runtime/Ptr
    //   4533: new org/renjin/gcc/runtime/DoublePtr
    //   4536: dup
    //   4537: getstatic org/renjin/stats/lbfgsb__.$mainlb$dtd : [D
    //   4540: iconst_0
    //   4541: invokespecial <init> : ([DI)V
    //   4544: checkcast org/renjin/gcc/runtime/Ptr
    //   4547: invokestatic matupd : (IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   4550: iload_1
    //   4551: aload #15
    //   4553: iconst_0
    //   4554: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4559: aload #13
    //   4561: iconst_0
    //   4562: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4567: aload #14
    //   4569: iconst_0
    //   4570: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4575: new org/renjin/gcc/runtime/IntPtr
    //   4578: dup
    //   4579: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   4582: iconst_0
    //   4583: invokespecial <init> : ([II)V
    //   4586: checkcast org/renjin/gcc/runtime/Ptr
    //   4589: new org/renjin/gcc/runtime/DoublePtr
    //   4592: dup
    //   4593: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   4596: iconst_0
    //   4597: invokespecial <init> : ([DI)V
    //   4600: checkcast org/renjin/gcc/runtime/Ptr
    //   4603: new org/renjin/gcc/runtime/IntPtr
    //   4606: dup
    //   4607: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   4610: iconst_0
    //   4611: invokespecial <init> : ([II)V
    //   4614: checkcast org/renjin/gcc/runtime/Ptr
    //   4617: invokestatic formt : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
    //   4620: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   4623: iconst_0
    //   4624: iaload
    //   4625: ifne -> 4631
    //   4628: goto -> 1277
    //   4631: iload #27
    //   4633: ifge -> 4639
    //   4636: goto -> 4700
    //   4639: new org/renjin/gcc/runtime/BytePtr
    //   4642: dup
    //   4643: ldc_w '%s\\n%s\\n '
    //   4646: invokevirtual getBytes : ()[B
    //   4649: iconst_0
    //   4650: invokespecial <init> : ([BI)V
    //   4653: iconst_2
    //   4654: anewarray java/lang/Object
    //   4657: astore #10
    //   4659: aload #10
    //   4661: iconst_0
    //   4662: new org/renjin/gcc/runtime/BytePtr
    //   4665: dup
    //   4666: ldc_w 'Nonpositive definiteness in Cholesky factorization in formk; '
    //   4669: invokevirtual getBytes : ()[B
    //   4672: iconst_0
    //   4673: invokespecial <init> : ([BI)V
    //   4676: aastore
    //   4677: aload #10
    //   4679: iconst_1
    //   4680: new org/renjin/gcc/runtime/BytePtr
    //   4683: dup
    //   4684: ldc_w '   refresh the lbfgs memory and restart the iteration. '
    //   4687: invokevirtual getBytes : ()[B
    //   4690: iconst_0
    //   4691: invokespecial <init> : ([BI)V
    //   4694: aastore
    //   4695: aload #10
    //   4697: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
    //   4700: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   4703: iconst_0
    //   4704: iconst_0
    //   4705: iastore
    //   4706: getstatic org/renjin/stats/lbfgsb__.$mainlb$col : [I
    //   4709: iconst_0
    //   4710: iconst_0
    //   4711: iastore
    //   4712: getstatic org/renjin/stats/lbfgsb__.$mainlb$head : [I
    //   4715: iconst_0
    //   4716: iconst_1
    //   4717: iastore
    //   4718: getstatic org/renjin/stats/lbfgsb__.$mainlb$theta : [D
    //   4721: iconst_0
    //   4722: dconst_1
    //   4723: dastore
    //   4724: getstatic org/renjin/stats/lbfgsb__.$mainlb$iupdat : [I
    //   4727: iconst_0
    //   4728: iconst_0
    //   4729: iastore
    //   4730: getstatic org/renjin/stats/lbfgsb__.$mainlb$updatd : [I
    //   4733: iconst_0
    //   4734: iconst_0
    //   4735: iastore
    //   4736: goto -> 1277
    //   4739: aload #29
    //   4741: bipush #48
    //   4743: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   4746: iconst_0
    //   4747: iaload
    //   4748: invokeinterface setInt : (II)V
    //   4753: aload #34
    //   4755: iconst_0
    //   4756: iaload
    //   4757: istore_1
    //   4758: aload #33
    //   4760: iconst_0
    //   4761: daload
    //   4762: dstore #37
    //   4764: getstatic org/renjin/stats/lbfgsb__.$mainlb$stp : [D
    //   4767: iconst_0
    //   4768: daload
    //   4769: dstore #35
    //   4771: getstatic org/renjin/stats/lbfgsb__.$mainlb$iback : [I
    //   4774: iconst_0
    //   4775: iaload
    //   4776: istore #13
    //   4778: getstatic org/renjin/stats/lbfgsb__.$mainlb$nint : [I
    //   4781: iconst_0
    //   4782: iaload
    //   4783: istore #12
    //   4785: getstatic org/renjin/stats/lbfgsb__.$mainlb$sbgnrm : [D
    //   4788: iconst_0
    //   4789: daload
    //   4790: dstore #8
    //   4792: getstatic org/renjin/stats/lbfgsb__.$mainlb$nact : I
    //   4795: istore #11
    //   4797: getstatic org/renjin/stats/lbfgsb__.$mainlb$nskip : I
    //   4800: istore #10
    //   4802: getstatic org/renjin/stats/lbfgsb__.$mainlb$nintol : I
    //   4805: istore #7
    //   4807: getstatic org/renjin/stats/lbfgsb__.$mainlb$nfgv : [I
    //   4810: iconst_0
    //   4811: iaload
    //   4812: istore #5
    //   4814: getstatic org/renjin/stats/lbfgsb__.$mainlb$iter : [I
    //   4817: iconst_0
    //   4818: iaload
    //   4819: istore #4
    //   4821: getstatic org/renjin/stats/lbfgsb__.$mainlb$info : [I
    //   4824: iconst_0
    //   4825: iaload
    //   4826: istore_3
    //   4827: aload #39
    //   4829: iconst_0
    //   4830: iaload
    //   4831: aload_2
    //   4832: bipush #8
    //   4834: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4839: aload #6
    //   4841: aload #26
    //   4843: iload #27
    //   4845: iload_3
    //   4846: iload #4
    //   4848: iload #5
    //   4850: iload #7
    //   4852: iload #10
    //   4854: iload #11
    //   4856: dload #8
    //   4858: iload #12
    //   4860: new org/renjin/gcc/runtime/BytePtr
    //   4863: dup
    //   4864: aload_0
    //   4865: iconst_0
    //   4866: invokespecial <init> : ([BI)V
    //   4869: checkcast org/renjin/gcc/runtime/Ptr
    //   4872: iload #13
    //   4874: dload #35
    //   4876: dload #37
    //   4878: iload_1
    //   4879: invokestatic prn3lb : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IIIIIIIDILorg/renjin/gcc/runtime/Ptr;IDDI)V
    //   4882: return
  }
  
  public static void matupd(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15) {
    int[] arrayOfInt3 = new int[1];
    arrayOfInt3[0] = paramInt1;
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    Ptr ptr6 = paramPtr6.pointerPlus(-8);
    Ptr ptr1 = paramPtr5.pointerPlus(-8);
    paramPtr4 = paramPtr4.pointerPlus(-((paramInt2 + 1) * 8));
    paramPtr3 = paramPtr3.pointerPlus(-((paramInt2 + 1) * 8));
    int i = arrayOfInt3[0];
    paramPtr2 = paramPtr2.pointerPlus(-((i + 1) * 8));
    int j = arrayOfInt3[0];
    paramPtr1 = paramPtr1.pointerPlus(-((j + 1) * 8));
    if (paramPtr8.getInt() > paramInt2) {
      paramPtr7.setInt(paramPtr7.getInt() % paramInt2 + 1);
      paramPtr10.setInt(paramPtr10.getInt() % paramInt2 + 1);
    } else {
      paramPtr9.setInt(paramPtr8.getInt());
      paramPtr7.setInt((paramPtr10.getInt() + paramPtr8.getInt() + -2) % paramInt2 + 1);
    } 
    Ptr ptr2 = (Ptr)new IntPtr(arrayOfInt3, 0);
    Ptr ptr3 = ptr1.pointerPlus(8);
    Ptr ptr4 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
    Ptr ptr5 = paramPtr1.pointerPlus((paramPtr7.getInt() * j + 1) * 8);
    Blas.dcopy_(ptr2, ptr3, ptr4, ptr5, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
    paramPtr7 = (Ptr)new IntPtr(arrayOfInt3, 0);
    ptr6 = ptr6.pointerPlus(8);
    ptr2 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
    ptr3 = paramPtr2.pointerPlus((paramPtr7.getInt() * i + 1) * 8);
    Blas.dcopy_(paramPtr7, ptr6, ptr2, ptr3, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
    paramPtr11.setDouble(paramPtr12.getDouble() / paramPtr13.getDouble());
    if (paramPtr8.getInt() > paramInt2) {
      arrayOfInt2[0] = 1;
      while (paramPtr9.getInt() + -1 >= arrayOfInt2[0]) {
        paramPtr7 = (Ptr)new IntPtr(arrayOfInt2, 0);
        paramPtr8 = paramPtr4.pointerPlus((arrayOfInt2[0] + 1) * 8 * paramInt2 + 16);
        paramPtr11 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
        paramPtr12 = paramPtr4.pointerPlus((arrayOfInt2[0] * paramInt2 + 1) * 8);
        Blas.dcopy_(paramPtr7, paramPtr8, paramPtr11, paramPtr12, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
        arrayOfInt1[0] = paramPtr9.getInt() - arrayOfInt2[0];
        paramPtr7 = (Ptr)new IntPtr(arrayOfInt1, 0);
        paramPtr8 = paramPtr3.pointerPlus((paramInt2 + 1) * 8 * (arrayOfInt2[0] + 1));
        paramPtr11 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
        paramPtr12 = paramPtr3.pointerPlus((paramInt2 + 1) * 8 * arrayOfInt2[0]);
        Blas.dcopy_(paramPtr7, paramPtr8, paramPtr11, paramPtr12, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"));
        arrayOfInt2[0] = arrayOfInt2[0] + 1;
      } 
    } 
    int k = paramPtr10.getInt();
    for (byte b = 1; paramPtr9.getInt() + -1 >= b; b++) {
      paramPtr10 = (Ptr)new IntPtr(arrayOfInt3, 0);
      paramPtr11 = ptr1.pointerPlus(8);
      paramPtr12 = IntFieldPtr.addressOf(lbfgsb__.class, "c__1");
      Ptr ptr = paramPtr2.pointerPlus((k * i + 1) * 8);
      paramPtr3.setDouble((paramPtr9.getInt() + b * paramInt2) * 8, Blas.ddot_(paramPtr10, paramPtr11, paramPtr12, ptr, IntFieldPtr.addressOf(lbfgsb__.class, "c__1")));
      paramPtr10 = (Ptr)new IntPtr(arrayOfInt3, 0);
      paramPtr11 = paramPtr1.pointerPlus((k * j + 1) * 8);
      paramPtr4.setDouble((paramPtr9.getInt() * paramInt2 + b) * 8, Blas.ddot_(paramPtr10, paramPtr11, IntFieldPtr.addressOf(lbfgsb__.class, "c__1"), ptr1.pointerPlus(8), IntFieldPtr.addressOf(lbfgsb__.class, "c__1")));
      k = k % paramInt2 + 1;
    } 
    if (paramPtr14.getDouble() != 1.0D) {
      paramPtr4.setDouble((paramInt2 + 1) * 8 * paramPtr9.getInt(), paramPtr14.getDouble() * paramPtr14.getDouble() * paramPtr15.getDouble());
    } else {
      paramPtr4.setDouble((paramInt2 + 1) * 8 * paramPtr9.getInt(), paramPtr15.getDouble());
    } 
    paramPtr3.setDouble((paramInt2 + 1) * 8 * paramPtr9.getInt(), paramPtr13.getDouble());
  }
  
  public static void prn1lb(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt3, double paramDouble) {
    if (paramInt3 >= 0) {
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = Integer.valueOf(paramInt1);
      arrayOfObject[1] = Integer.valueOf(paramInt2);
      arrayOfObject[2] = Double.valueOf(paramDouble);
      Print.Rprintf(new BytePtr("N = %d, M = %d machine precision = %g\n\000".getBytes(), 0), arrayOfObject);
      if (paramInt3 > 99) {
        pvector((Ptr)new BytePtr("L =\000".getBytes(), 0), paramPtr1, paramInt1);
        pvector((Ptr)new BytePtr("X0 =\000".getBytes(), 0), paramPtr3, paramInt1);
        pvector((Ptr)new BytePtr("U =\000".getBytes(), 0), paramPtr2, paramInt1);
      } 
    } 
  }
  
  public static void prn2lb(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble1, int paramInt6, Ptr paramPtr4, int paramInt7, int paramInt8, double paramDouble2, double paramDouble3) {
    BytePtr bytePtr;
    Object[] arrayOfObject1;
    if (paramInt2 <= 98) {
      if (paramInt2 > 0 && paramInt3 % paramInt2 == 0) {
        bytePtr = new BytePtr();
        this("At iterate %5d  f = %12.5g  |proj g|=  %12.5g\n\000".getBytes(), 0);
        arrayOfObject1 = new Object[3];
        arrayOfObject1[0] = Integer.valueOf(paramInt3);
        Double double_ = Double.valueOf(paramPtr2.getDouble());
        arrayOfObject1[1] = double_;
        arrayOfObject1[2] = Double.valueOf(paramDouble1);
        Print.Rprintf(bytePtr, arrayOfObject1);
      } 
      return;
    } 
    Object[] arrayOfObject2 = new Object[2];
    arrayOfObject2[0] = Integer.valueOf(paramInt8);
    arrayOfObject2[1] = Double.valueOf(paramDouble3);
    Print.Rprintf(new BytePtr("LINE SEARCH %d times; norm of step = %g\n\000".getBytes(), 0), arrayOfObject2);
    if (paramInt2 > 100) {
      pvector((Ptr)new BytePtr("X =\000".getBytes(), 0), (Ptr)arrayOfObject1, bytePtr);
      pvector((Ptr)new BytePtr("G =\000".getBytes(), 0), paramPtr3, bytePtr);
    } 
  }
  
  public static void prn3lb(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, double paramDouble1, int paramInt9, Ptr paramPtr4, int paramInt10, double paramDouble2, double paramDouble3, int paramInt11) {
    if (Stdlib.strncmp(paramPtr3, (Ptr)new BytePtr("CONV\000".getBytes(), 0), 4) == 0) {
      if (paramInt2 >= 0) {
        BytePtr bytePtr = new BytePtr();
        this("\niterations %d\nfunction evaluations %d\nsegments explored during Cauchy searches %d\nBFGS updates skipped %d\nactive bounds at final generalized Cauchy point %d\nnorm of the final projected gradient %g\nfinal function value %g\n\n\000".getBytes(), 0);
        Object[] arrayOfObject = new Object[7];
        arrayOfObject[0] = Integer.valueOf(paramInt4);
        arrayOfObject[1] = Integer.valueOf(paramInt5);
        arrayOfObject[2] = Integer.valueOf(paramInt6);
        arrayOfObject[3] = Integer.valueOf(paramInt7);
        arrayOfObject[4] = Integer.valueOf(paramInt8);
        arrayOfObject[5] = Double.valueOf(paramDouble1);
        Double double_ = Double.valueOf(paramPtr2.getDouble());
        arrayOfObject[6] = double_;
        Print.Rprintf(bytePtr, arrayOfObject);
      } 
      if (paramInt2 > 99)
        pvector((Ptr)new BytePtr("X =\000".getBytes(), 0), paramPtr1, paramInt1); 
      if (paramInt2 > 0) {
        Object[] arrayOfObject = new Object[1];
        BytePtr bytePtr = new BytePtr();
        this("F = %g\n\000".getBytes(), 0);
        arrayOfObject[0] = Double.valueOf(paramPtr2.getDouble());
        Print.Rprintf(bytePtr, arrayOfObject);
      } 
    } 
    if (paramInt2 >= 0) {
      Object[] arrayOfObject;
      switch (paramInt3) {
        case -1:
          Print.Rprintf(new BytePtr("Matrix in 1st Cholesky factorization in formk is not Pos. Def.\000".getBytes(), 0), new Object[0]);
          break;
        case -2:
          Print.Rprintf(new BytePtr("Matrix in 2st Cholesky factorization in formk is not Pos. Def.\000".getBytes(), 0), new Object[0]);
          break;
        case -3:
          Print.Rprintf(new BytePtr("Matrix in the Cholesky factorization in formt is not Pos. Def.\000".getBytes(), 0), new Object[0]);
          break;
        case -4:
          Print.Rprintf(new BytePtr("Derivative >= 0, backtracking line search impossible.\000".getBytes(), 0), new Object[0]);
          break;
        case -5:
          arrayOfObject = new Object[2];
          arrayOfObject[0] = Integer.valueOf(paramInt11);
          arrayOfObject[1] = Integer.valueOf(paramInt11);
          Print.Rprintf(new BytePtr("l(%d) > u(%d).  No feasible solution\000".getBytes(), 0), arrayOfObject);
          break;
        case -6:
          Print.Rprintf(new BytePtr("Input nbd(%d) is invalid\000".getBytes(), 0), new Object[] { Integer.valueOf(paramInt11) });
          break;
        case -7:
          Print.Rprintf(new BytePtr("Warning:  more than 10 function and gradient evaluations\n   in the last line search\n\000".getBytes(), 0), new Object[0]);
          break;
        case -8:
          Print.Rprintf(new BytePtr("The triangular system is singular.\000".getBytes(), 0), new Object[0]);
          break;
        case -9:
          arrayOfObject = new Object[2];
          arrayOfObject[0] = new BytePtr("Line search cannot locate an adequate point after 20 function\000".getBytes(), 0);
          arrayOfObject[1] = new BytePtr("and gradient evaluations\000".getBytes(), 0);
          Print.Rprintf(new BytePtr("%s\n%s\n\000".getBytes(), 0), arrayOfObject);
          break;
      } 
    } 
  }
  
  public static void projgr(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    paramPtr6.setDouble(0.0D);
    for (byte b = 0; b < paramInt; b++) {
      double d = paramPtr5.getDouble(b * 8);
      if (paramPtr3.getInt(b * 4) != 0)
        if (d >= 0.0D) {
          if (paramPtr3.getInt(b * 4) <= 2) {
            double d1 = paramPtr4.getDouble(b * 8) - paramPtr1.getDouble(b * 8);
            if (d1 < d)
              d = d1; 
          } 
        } else if (paramPtr3.getInt(b * 4) > 1) {
          double d1 = paramPtr4.getDouble(b * 8) - paramPtr2.getDouble(b * 8);
          if (d1 > d)
            d = d1; 
        }  
      d = Math.abs(d);
      if (paramPtr6.getDouble() < d)
        paramPtr6.setDouble(d); 
    } 
  }
  
  public static void pvector(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    Print.Rprintf(new BytePtr("%s \000".getBytes(), 0), new Object[] { paramPtr1 });
    for (byte b = 0; b < paramInt; b++) {
      Object[] arrayOfObject = new Object[1];
      BytePtr bytePtr = new BytePtr();
      this("%g \000".getBytes(), 0);
      arrayOfObject[0] = Double.valueOf(paramPtr2.getDouble(b * 8));
      Print.Rprintf(bytePtr, arrayOfObject);
    } 
    Print.Rprintf(new BytePtr("\n\000".getBytes(), 0), new Object[0]);
  }
  
  public static void setulb(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, double paramDouble, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, int paramInt3, Ptr paramPtr11) {
    byte[] arrayOfByte = new byte[60];
    arrayOfByte[0] = (byte)0;
    paramPtr8 = paramPtr8.pointerPlus(-8);
    if (Stdlib.strncmp(paramPtr10, (Ptr)new BytePtr("START\000".getBytes(), 0), 5) == 0) {
      $setulb$lws = 1;
      $setulb$lwy = paramInt2 * paramInt1 + $setulb$lws;
      $setulb$lsy = paramInt2 * paramInt1 + $setulb$lwy;
      $setulb$lss = paramInt2 * paramInt2 + $setulb$lsy;
      $setulb$lwt = paramInt2 * paramInt2 + $setulb$lss;
      $setulb$lwn = paramInt2 * paramInt2 + $setulb$lwt;
      $setulb$lsnd = (paramInt2 * paramInt2 << 2) + $setulb$lwn;
      $setulb$lz = (paramInt2 * paramInt2 << 2) + $setulb$lsnd;
      $setulb$lr = $setulb$lz + paramInt1;
      $setulb$ld = $setulb$lr + paramInt1;
      $setulb$lt = $setulb$ld + paramInt1;
      $setulb$lwa = $setulb$lt + paramInt1;
    } 
    Ptr ptr1 = paramPtr8.pointerPlus($setulb$lws * 8);
    Ptr ptr2 = paramPtr8.pointerPlus($setulb$lwy * 8);
    paramPtr1 = paramPtr8.pointerPlus($setulb$lsy * 8);
    paramPtr2 = paramPtr8.pointerPlus($setulb$lss * 8);
    paramPtr3 = paramPtr8.pointerPlus($setulb$lwt * 8);
    paramPtr4 = paramPtr8.pointerPlus($setulb$lwn * 8);
    paramPtr5 = paramPtr8.pointerPlus($setulb$lsnd * 8);
    paramPtr6 = paramPtr8.pointerPlus($setulb$lz * 8);
    paramPtr7 = paramPtr8.pointerPlus($setulb$lr * 8);
    paramPtr8 = paramPtr8.pointerPlus($setulb$ld * 8);
    Ptr ptr3 = paramPtr8.pointerPlus($setulb$lt * 8);
    Ptr ptr4 = paramPtr8.pointerPlus($setulb$lwa * 8);
    Ptr ptr5 = paramPtr9.pointerPlus(paramInt1 * 4);
    Ptr ptr6 = paramPtr9.pointerPlus((paramInt1 << 1) * 4);
    mainlb(paramInt1, paramInt2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramDouble, paramPtr7, ptr1, ptr2, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramPtr8, ptr3, ptr4, paramPtr9, ptr5, ptr6, paramPtr10, paramInt3, (Ptr)new BytePtr(arrayOfByte, 0), paramPtr11);
  }
  
  public static void subsm(int paramInt1, int paramInt2, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, Ptr paramPtr8, Ptr paramPtr9, Ptr paramPtr10, Ptr paramPtr11, Ptr paramPtr12, Ptr paramPtr13, Ptr paramPtr14, Ptr paramPtr15, int paramInt3, Ptr paramPtr16) {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    paramInt3 = 0;
    paramPtr7 = paramPtr7.pointerPlus(-8);
    paramPtr4 = paramPtr4.pointerPlus(-8);
    paramPtr3 = paramPtr3.pointerPlus(-8);
    paramPtr6 = paramPtr6.pointerPlus(-8);
    paramPtr2 = paramPtr2.pointerPlus(-4);
    paramPtr5 = paramPtr5.pointerPlus(-4);
    paramPtr14 = paramPtr14.pointerPlus(-8);
    int k = paramInt2 * 2 + 1;
    paramPtr15 = paramPtr15.pointerPlus(-(k * 8));
    int j = -((paramInt1 + 1) * 8);
    paramPtr8 = paramPtr8.pointerPlus(j);
    Ptr ptr = paramPtr9.pointerPlus(-((paramInt1 + 1) * 8));
    int i = paramPtr1.getInt();
    if (i > 0) {
      int m = paramPtr12.getInt();
      for (byte b = 1; paramPtr11.getInt() >= b; b++) {
        double d1 = 0.0D;
        double d2 = 0.0D;
        for (byte b1 = 1; b1 <= i; b1++) {
          int n = paramPtr2.getInt(b1 * 4);
          d1 = ptr.getDouble((m * paramInt1 + n) * 8) * paramPtr7.getDouble(b1 * 8) + d1;
          d2 = paramPtr8.getDouble((m * paramInt1 + n) * 8) * paramPtr7.getDouble(b1 * 8) + d2;
        } 
        paramPtr14.setDouble(b * 8, d1);
        paramPtr14.setDouble((paramPtr11.getInt() + b) * 8, paramPtr10.getDouble() * d2);
        m = m % paramInt2 + 1;
      } 
      arrayOfInt2[0] = paramInt2 << 1;
      arrayOfInt1[0] = paramPtr11.getInt() << 1;
      Appl.dtrsl_(paramPtr15.pointerPlus(k * 8), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr14.pointerPlus(8), IntFieldPtr.addressOf(lbfgsb__.class, "c__11"), paramPtr16);
      if (paramPtr16.getInt() == 0) {
        for (m = 1; paramPtr11.getInt() >= m; m++)
          paramPtr14.setDouble(m * 8, -paramPtr14.getDouble(m * 8)); 
        Appl.dtrsl_(paramPtr15.pointerPlus(k * 8), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0), paramPtr14.pointerPlus(8), IntFieldPtr.addressOf(lbfgsb__.class, "c__1"), paramPtr16);
        if (paramPtr16.getInt() == 0) {
          int n = paramPtr12.getInt();
          for (byte b1 = 1; paramPtr11.getInt() >= b1; b1++) {
            int i1 = paramPtr11.getInt() + b1;
            for (byte b2 = 1; b2 <= i; b2++) {
              int i2 = paramPtr2.getInt(b2 * 4);
              paramPtr7.setDouble(b2 * 8, paramPtr7.getDouble(b2 * 8) + ptr.getDouble((n * paramInt1 + i2) * 8) * paramPtr14.getDouble(b1 * 8) / paramPtr10.getDouble() + paramPtr8.getDouble((n * paramInt1 + i2) * 8) * paramPtr14.getDouble(i1 * 8));
            } 
            n = n % paramInt2 + 1;
          } 
          for (paramInt1 = 1; paramInt1 <= i; paramInt1++)
            paramPtr7.setDouble(paramInt1 * 8, paramPtr7.getDouble(paramInt1 * 8) / paramPtr10.getDouble()); 
          double d1 = 1.0D;
          double d2 = 1.0D;
          for (paramInt1 = 1; paramInt1 <= i; paramInt1++) {
            paramInt2 = paramPtr2.getInt(paramInt1 * 4);
            double d = paramPtr7.getDouble(paramInt1 * 8);
            if (paramPtr5.getInt(paramInt2 * 4) != 0) {
              if (d >= 0.0D || paramPtr5.getInt(paramInt2 * 4) > 2) {
                if (d > 0.0D && paramPtr5.getInt(paramInt2 * 4) > 1) {
                  double d3 = paramPtr4.getDouble(paramInt2 * 8) - paramPtr6.getDouble(paramInt2 * 8);
                  if (d3 > 0.0D) {
                    if (d * d1 > d3)
                      d2 = d3 / d; 
                  } else {
                    d2 = 0.0D;
                  } 
                } 
              } else {
                double d3 = paramPtr3.getDouble(paramInt2 * 8) - paramPtr6.getDouble(paramInt2 * 8);
                if (d3 < 0.0D) {
                  if (d * d1 < d3)
                    d2 = d3 / d; 
                } else {
                  d2 = 0.0D;
                } 
              } 
              if (d2 < d1) {
                d1 = d2;
                paramInt3 = paramInt1;
              } 
            } 
          } 
          if (d1 < 1.0D) {
            d2 = paramPtr7.getDouble(paramInt3 * 8);
            paramInt1 = paramPtr2.getInt(paramInt3 * 4);
            if (d2 <= 0.0D) {
              if (d2 < 0.0D) {
                paramPtr6.setDouble(paramInt1 * 8, paramPtr3.getDouble(paramInt1 * 8));
                paramPtr7.setDouble(paramInt3 * 8, 0.0D);
              } 
            } else {
              paramPtr6.setDouble(paramInt1 * 8, paramPtr4.getDouble(paramInt1 * 8));
              paramPtr7.setDouble(paramInt3 * 8, 0.0D);
            } 
          } 
          for (paramInt1 = 1; paramInt1 <= i; paramInt1++)
            paramPtr6.setDouble(paramPtr2.getInt(paramInt1 * 4) * 8, paramPtr6.getDouble(paramPtr2.getInt(paramInt1 * 4) * 8) + paramPtr7.getDouble(paramInt1 * 8) * d1); 
          if (d1 >= 1.0D) {
            paramInt1 = 0;
          } else {
            paramInt1 = 1;
          } 
          paramPtr13.setInt(paramInt1);
        } 
      } 
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/lbfgsb__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */