package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.MixedPtr;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.gnur.api.Arith;
import org.renjin.gnur.api.Error;
import org.renjin.gnur.api.GetText;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class fourier__ {
  static {
  
  }
  
  public static SEXP fft(SEXP paramSEXP1, SEXP paramSEXP2) {
    MixedPtr mixedPtr = MixedPtr.malloc(100);
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    SEXP sEXP = (SEXP)BytePtr.of(0).getArray();
    switch (Rinternals.TYPEOF(paramSEXP1)) {
      case 10:
      case 13:
      case 14:
        paramSEXP1 = Rinternals.Rf_coerceVector(paramSEXP1, 15);
        break;
      case 15:
        if (Rinternals.NAMED(paramSEXP1) == 0)
          break; 
        paramSEXP1 = Rinternals.Rf_duplicate(paramSEXP1);
        break;
      default:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("non-numeric argument\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    Rinternals.Rf_protect(paramSEXP1);
    int i = Rinternals.Rf_asLogical(paramSEXP2);
    if (i != Arith.R_NaInt && i != 0) {
      i = 2;
    } else {
      i = -2;
    } 
    if (Rinternals.LENGTH(paramSEXP1) > 1) {
      sEXP = Rinternals.Rf_getAttrib(paramSEXP1, Rinternals.R_DimSymbol);
      if (Rinternals.TYPEOF(sEXP) != 0) {
        int i2 = 1;
        int m = 1;
        int i1 = Rinternals.LENGTH(sEXP);
        int n;
        for (n = 0; n < i1; n++) {
          if (Rinternals2.INTEGER(sEXP).getInt(0 + n * 4) > 1) {
            fft__.fft_factor((Ptr)mixedPtr, Rinternals2.INTEGER(sEXP).getInt(0 + n * 4), (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
            if (arrayOfInt2[0] == 0)
              Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("fft factorization error\000".getBytes(), 0)), new Object[0]); 
            if (arrayOfInt2[0] > i2)
              i2 = arrayOfInt2[0]; 
            if (arrayOfInt1[0] > m)
              m = arrayOfInt1[0]; 
          } 
        } 
        n = i2;
        if (Integer.compareUnsigned(i2, 1073741823) > 0)
          Error.Rf_error(new BytePtr("fft too large\000".getBytes(), 0), new Object[0]); 
        DoublePtr doublePtr1 = DoublePtr.malloc(n * 32);
        IntPtr intPtr1 = IntPtr.malloc(m * 4);
        int i3 = Rinternals.LENGTH(paramSEXP1);
        int i4 = 1;
        int i5 = 1;
        for (byte b = 0; b < i1; b++) {
          if (Rinternals2.INTEGER(sEXP).getInt(0 + b * 4) > 1) {
            i5 *= i4;
            i4 = Rinternals2.INTEGER(sEXP).getInt(0 + b * 4);
            i3 /= i4;
            fft__.fft_factor((Ptr)mixedPtr, i4, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
            DoublePtr doublePtr2 = Rinternals.COMPLEX(paramSEXP1);
            Ptr ptr = Rinternals.COMPLEX(paramSEXP1).pointerPlus(8);
            fft__.fft_work((Ptr)mixedPtr, (Ptr)doublePtr2, ptr, i3, i4, i5, i, doublePtr1.pointerPlus(0), intPtr1.pointerPlus(0));
          } 
        } 
        return paramSEXP1;
      } 
      int k = Rinternals.Rf_length(paramSEXP1);
      fft__.fft_factor((Ptr)mixedPtr, k, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
      if (arrayOfInt2[0] == 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("fft factorization error\000".getBytes(), 0)), new Object[0]); 
      int j = arrayOfInt2[0];
      if (Integer.compareUnsigned(j, 1073741823) > 0)
        Error.Rf_error(new BytePtr("fft too large\000".getBytes(), 0), new Object[0]); 
      IntPtr intPtr = IntPtr.malloc(arrayOfInt1[0] * 4);
      DoublePtr doublePtr = Rinternals.COMPLEX(paramSEXP1);
      Ptr ptr1 = Rinternals.COMPLEX(paramSEXP1).pointerPlus(8);
      Ptr ptr2 = DoublePtr.malloc(j * 32).pointerPlus(0);
      fft__.fft_work((Ptr)mixedPtr, (Ptr)doublePtr, ptr1, 1, k, 1, i, ptr2, intPtr.pointerPlus(0));
    } 
    return paramSEXP1;
  }
  
  public static SEXP mvfft(SEXP paramSEXP1, SEXP paramSEXP2) {
    MixedPtr mixedPtr = MixedPtr.malloc(100);
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    BytePtr.of(0);
    BytePtr.of(0);
    arrayOfInt1[0] = 0;
    arrayOfInt2[0] = 0;
    SEXP sEXP = Rinternals.Rf_getAttrib(paramSEXP1, Rinternals.R_DimSymbol);
    if (sEXP == Rinternals.R_NilValue || Rinternals.Rf_length(sEXP) > 2)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("vector-valued (multivariate) series required\000".getBytes(), 0)), new Object[0]); 
    int k = Rinternals2.INTEGER(sEXP).getInt();
    int j = Rinternals2.INTEGER(sEXP).getInt(4);
    switch (Rinternals.TYPEOF(paramSEXP1)) {
      case 10:
      case 13:
      case 14:
        paramSEXP1 = Rinternals.Rf_coerceVector(paramSEXP1, 15);
        break;
      case 15:
        if (Rinternals.NAMED(paramSEXP1) == 0)
          break; 
        paramSEXP1 = Rinternals.Rf_duplicate(paramSEXP1);
        break;
      default:
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("non-numeric argument\000".getBytes(), 0)), new Object[0]);
        break;
    } 
    Rinternals.Rf_protect(paramSEXP1);
    int i = Rinternals.Rf_asLogical(paramSEXP2);
    if (i != Arith.R_NaInt && i != 0) {
      i = 2;
    } else {
      i = -2;
    } 
    if (k > 1) {
      fft__.fft_factor((Ptr)mixedPtr, k, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
      if (arrayOfInt2[0] == 0)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("fft factorization error\000".getBytes(), 0)), new Object[0]); 
      int m = arrayOfInt2[0];
      if (Integer.compareUnsigned(m, 1073741823) > 0)
        Error.Rf_error(new BytePtr("fft too large\000".getBytes(), 0), new Object[0]); 
      DoublePtr doublePtr = DoublePtr.malloc(m * 32);
      IntPtr intPtr = IntPtr.malloc(arrayOfInt1[0] * 4);
      for (byte b = 0; b < j; b++) {
        fft__.fft_factor((Ptr)mixedPtr, k, (Ptr)new IntPtr(arrayOfInt2, 0), (Ptr)new IntPtr(arrayOfInt1, 0));
        Ptr ptr1 = Rinternals.COMPLEX(paramSEXP1).pointerPlus(0 + b * k * 16);
        Ptr ptr2 = Rinternals.COMPLEX(paramSEXP1).pointerPlus(0 + b * k * 16 + 8);
        fft__.fft_work((Ptr)mixedPtr, ptr1, ptr2, 1, k, 1, i, doublePtr.pointerPlus(0), intPtr.pointerPlus(0));
      } 
    } 
    return paramSEXP1;
  }
  
  public static SEXP nextn(SEXP paramSEXP1, SEXP paramSEXP2) {
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    sEXP1 = (SEXP)BytePtr.of(0).getArray();
    paramSEXP1 = Rinternals.Rf_coerceVector(paramSEXP1, 13);
    Rinternals.Rf_protect(paramSEXP1);
    paramSEXP2 = Rinternals.Rf_coerceVector(paramSEXP2, 13);
    Rinternals.Rf_protect(paramSEXP2);
    int i = Rinternals.LENGTH(paramSEXP1);
    int j = Rinternals.LENGTH(paramSEXP2);
    if (j == 0)
      Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("no factors\000".getBytes(), 0)), new Object[0]); 
    for (byte b1 = 0; b1 < j; b1++) {
      if (Rinternals2.INTEGER(paramSEXP2).getInt(0 + b1 * 4) == Arith.R_NaInt || Rinternals2.INTEGER(paramSEXP2).getInt(0 + b1 * 4) <= 1)
        Error.Rf_error(GetText.dgettext(new BytePtr("stats\000".getBytes(), 0), new BytePtr("invalid factors\000".getBytes(), 0)), new Object[0]); 
    } 
    SEXP sEXP2 = Rinternals.Rf_allocVector(13, i);
    for (byte b2 = 0; b2 < i; b2++) {
      if (Rinternals2.INTEGER(paramSEXP1).getInt(0 + b2 * 4) != Arith.R_NaInt) {
        if (Rinternals2.INTEGER(paramSEXP1).getInt(0 + b2 * 4) > 1) {
          Ptr ptr = Rinternals2.INTEGER(paramSEXP2);
          Rinternals2.INTEGER(sEXP2).setInt(0 + b2 * 4, nextn0(Rinternals2.INTEGER(paramSEXP1).getInt(0 + b2 * 4), ptr, j));
        } else {
          Rinternals2.INTEGER(sEXP2).setInt(0 + b2 * 4, 1);
        } 
      } else {
        Rinternals2.INTEGER(sEXP2).setInt(0 + b2 * 4, Arith.R_NaInt);
      } 
    } 
    return sEXP2;
  }
  
  public static int nextn0(int paramInt1, Ptr paramPtr, int paramInt2) {
    while (ok_n(paramInt1, paramPtr, paramInt2) == 0)
      paramInt1++; 
    return paramInt1;
  }
  
  public static int ok_n(int paramInt1, Ptr paramPtr, int paramInt2) {
    for (byte b = 0; b < paramInt2; b++) {
      while (paramInt1 % paramPtr.getInt(b * 4) == 0) {
        paramInt1 /= paramPtr.getInt(b * 4);
        if (paramInt1 != 1)
          continue; 
        paramInt1 = 1;
        // Byte code: goto -> 66
      } 
    } 
    if (paramInt1 != 1) {
      paramInt1 = 0;
    } else {
      paramInt1 = 1;
    } 
    return paramInt1;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/fourier__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */