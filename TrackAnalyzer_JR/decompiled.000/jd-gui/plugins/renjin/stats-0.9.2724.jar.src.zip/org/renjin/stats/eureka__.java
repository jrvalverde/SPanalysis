package org.renjin.stats;

import org.renjin.gcc.runtime.Ptr;

public class eureka__ {
  static {
  
  }
  
  public static void eureka_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt() + 1, 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    int i = Math.max(paramPtr1.getInt(), 0);
    Integer.toUnsignedLong(Math.max(i * paramPtr1.getInt(), 0));
    int j = i ^ 0xFFFFFFFF;
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt() + 1, 0));
    Integer.toUnsignedLong(Math.max(paramPtr1.getInt(), 0));
    double d1 = paramPtr2.getDouble();
    double d2 = paramPtr2.getAlignedDouble(1);
    paramPtr6.setDouble(1.0D);
    paramPtr4.setAlignedDouble(j + i + 1, paramPtr3.getAlignedDouble(1) / d1);
    double d3 = paramPtr4.getAlignedDouble(j + i + 1) * paramPtr2.getAlignedDouble(1);
    paramPtr5.setDouble((1.0D - paramPtr4.getAlignedDouble(j + i + 1) * paramPtr4.getAlignedDouble(j + i + 1)) * paramPtr2.getDouble());
    if (paramPtr1.getInt() != 1) {
      int k = paramPtr1.getInt();
      byte b = 2;
      if (2 <= k)
        while (true) {
          paramPtr6.setAlignedDouble(b + -1, -(d2 / d1));
          if (b > 2) {
            int n = (b + -2) / 2;
            int i1 = n + 1;
            byte b2 = 2;
            if (2 <= i1)
              while (true) {
                int i2 = b - b2 + 1;
                paramPtr6.setAlignedDouble(b2 + -1, paramPtr6.getAlignedDouble(b2 + -1) + paramPtr6.getAlignedDouble(b + -1) * paramPtr6.getAlignedDouble(i2 + -1));
                double d = paramPtr6.getAlignedDouble(i2 + -1);
                d = paramPtr6.getAlignedDouble(b2 + -1) * paramPtr6.getAlignedDouble(b + -1) + d;
                paramPtr6.setAlignedDouble(i2 + -1, d);
                if (b2 != i1) {
                  i2 = 0;
                } else {
                  i2 = 1;
                } 
                b2++;
                if (i2 == 0)
                  continue; 
                break;
              }  
            if (n * 2 != b + -2)
              paramPtr6.setAlignedDouble(i1, paramPtr6.getAlignedDouble(i1) * (paramPtr6.getAlignedDouble(b + -1) + 1.0D)); 
          } 
          d1 = paramPtr6.getAlignedDouble(b + -1) * d2 + d1;
          paramPtr4.setAlignedDouble(b * i + j + b, (paramPtr3.getAlignedDouble(b) - d3) / d1);
          int m = b + -1;
          byte b1 = 1;
          if (1 <= m)
            while (true) {
              boolean bool;
              paramPtr4.setAlignedDouble(b1 * i + j + b, paramPtr4.getAlignedDouble(b1 * i + j + b + -1) + paramPtr4.getAlignedDouble(b * i + j + b) * paramPtr6.getAlignedDouble(b - b1));
              if (b1 != m) {
                bool = false;
              } else {
                bool = true;
              } 
              b1++;
              if (!bool)
                continue; 
              break;
            }  
          paramPtr5.setAlignedDouble(b + -1, paramPtr5.getAlignedDouble(b + -2) * (1.0D - paramPtr4.getAlignedDouble(b * i + j + b) * paramPtr4.getAlignedDouble(b * i + j + b)));
          if (paramPtr1.getInt() != b) {
            d2 = 0.0D;
            d3 = 0.0D;
            m = b;
            b1 = 1;
            if (1 <= b)
              while (true) {
                int n = b - b1 + 2 + -1;
                d2 = paramPtr6.getAlignedDouble(b1 + -1) * paramPtr2.getAlignedDouble(n) + d2;
                double d = paramPtr4.getAlignedDouble(b1 * i + j + b);
                d3 = paramPtr2.getAlignedDouble(b - b1 + 2 + -1) * d + d3;
                if (b1 != m) {
                  n = 0;
                } else {
                  n = 1;
                } 
                b1++;
                if (n == 0)
                  continue; 
                break;
              }  
            if (b != k) {
              m = 0;
            } else {
              m = 1;
            } 
            b++;
            if (m == 0)
              continue; 
          } 
          break;
        }  
    } 
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/eureka__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */