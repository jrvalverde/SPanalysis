package org.renjin.stats;

import org.renjin.gcc.runtime.BytePtr;
import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gnur.api.Rinternals;
import org.renjin.gnur.api.Rinternals2;
import org.renjin.sexp.SEXP;

public class hclust_utils__ {
  static {
  
  }
  
  public static SEXP R_cutree(SEXP paramSEXP1, SEXP paramSEXP2) {
    BytePtr.of(0);
    BytePtr.of(0);
    BytePtr.of(0);
    SEXP sEXP1 = (SEXP)BytePtr.of(0).getArray();
    int j = 0;
    SEXP sEXP2 = Rinternals.Rf_coerceVector(paramSEXP1, 13);
    Rinternals.Rf_protect(sEXP2);
    paramSEXP1 = Rinternals.Rf_coerceVector(paramSEXP2, 13);
    Rinternals.Rf_protect(paramSEXP1);
    int i = Rinternals.Rf_nrows(sEXP2) + 1;
    IntPtr intPtr1 = IntPtr.malloc(i * 4);
    IntPtr intPtr2 = IntPtr.malloc(i * 4);
    IntPtr intPtr3 = IntPtr.malloc(i * 4);
    sEXP1 = Rinternals.Rf_allocMatrix(13, i, Rinternals.LENGTH(paramSEXP1));
    Rinternals.Rf_protect(sEXP1);
    byte b;
    for (b = 1; b <= i; b++) {
      intPtr1.setInt(-4 + b * 4, 1);
      intPtr2.setInt(-4 + b * 4, 0);
    } 
    for (b = 1; i + -1 >= b; b++) {
      int k = Rinternals2.INTEGER(sEXP2).getInt(0 + (b + -1) * 4);
      int m = Rinternals2.INTEGER(sEXP2).getInt(0 + (i + -1 + b + -1) * 4);
      if (k >= 0 || m >= 0) {
        if (k >= 0 && m >= 0) {
          for (byte b1 = 1; b1 <= i; b1++) {
            if (intPtr2.getInt(-4 + b1 * 4) == k || intPtr2.getInt(-4 + b1 * 4) == m)
              intPtr2.setInt(-4 + b1 * 4, b); 
          } 
        } else {
          int n;
          if (k >= 0) {
            n = -m;
          } else {
            n = -k;
            k = m;
          } 
          for (m = 1; m <= i; m++) {
            if (intPtr2.getInt(-4 + m * 4) == k)
              intPtr2.setInt(-4 + m * 4, b); 
          } 
          intPtr2.setInt(-4 + n * 4, b);
          intPtr1.setInt(-4 + n * 4, 0);
        } 
      } else {
        int n = -4 + m * -4;
        intPtr2.setInt(n, b);
        intPtr2.setInt(-4 + k * -4, intPtr2.getInt(n));
        k = -4 + m * -4;
        intPtr1.setInt(k, 0);
        intPtr1.setInt(-4 + k * -4, intPtr1.getInt(k));
      } 
      k = 0;
      for (m = 0; Rinternals.LENGTH(paramSEXP1) > m; m++) {
        if (Rinternals2.INTEGER(paramSEXP1).getInt(0 + m * 4) == i - b)
          if (k != 0) {
            byte b1 = 1;
            int n = m * i;
            for (int i1 = j; b1 <= i; i1++) {
              Rinternals2.INTEGER(sEXP1).setInt(0 + n * 4, Rinternals2.INTEGER(sEXP1).getInt(0 + i1 * 4));
              b1++;
              n++;
            } 
          } else {
            k = 1;
            for (j = 1; j <= i; j++)
              intPtr3.setInt(-4 + j * 4, 0); 
            byte b1 = 0;
            j = m * i;
            byte b2 = 1;
            for (int n = j; b2 <= i; n++) {
              if (intPtr1.getInt(-4 + b2 * 4) == 0) {
                if (intPtr3.getInt(-4 + intPtr2.getInt(-4 + b2 * 4) * 4) == 0)
                  intPtr3.setInt(-4 + intPtr2.getInt(-4 + b2 * 4) * 4, ++b1); 
                Rinternals2.INTEGER(sEXP1).setInt(0 + n * 4, intPtr3.getInt(-4 + intPtr2.getInt(-4 + b2 * 4) * 4));
              } else {
                Rinternals2.INTEGER(sEXP1).setInt(0 + n * 4, ++b1);
              } 
              b2++;
            } 
          }  
      } 
    } 
    for (j = 0; Rinternals.LENGTH(paramSEXP1) > j; j++) {
      if (Rinternals2.INTEGER(paramSEXP1).getInt(0 + j * 4) == i) {
        byte b1 = 1;
        for (int k = j * i; b1 <= i; k++) {
          Rinternals2.INTEGER(sEXP1).setInt(0 + k * 4, b1);
          b1++;
        } 
      } 
    } 
    return sEXP1;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/hclust_utils__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */