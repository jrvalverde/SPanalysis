package org.renjin.stats;

import org.renjin.gcc.runtime.IntPtr;
import org.renjin.gcc.runtime.Ptr;

public class bvalus__ {
  static {
  
  }
  
  public static void bvalus_(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7) {
    int i = paramPtr1.getInt();
    byte b = 1;
    if (1 <= i)
      while (true) {
        boolean bool;
        Ptr ptr1 = (Ptr)new IntPtr(new int[] { 4 }, 0);
        Ptr ptr2 = paramPtr5.pointerPlus((b + -1) * 8);
        paramPtr6.setAlignedDouble(b + -1, bvalue__.bvalue_(paramPtr2, paramPtr3, paramPtr4, ptr1, ptr2, paramPtr7));
        if (b != i) {
          bool = false;
        } else {
          bool = true;
        } 
        b++;
        if (!bool)
          continue; 
        break;
      }  
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/bvalus__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */