package org.renjin.stats.nls;

import org.renjin.sexp.ListVector;

class NlsControl {
  private final int maxIter;
  
  private final double tolerance;
  
  private final double minFac;
  
  private final boolean warnOnly;
  
  private final boolean printEval;
  
  NlsControl(ListVector paramListVector) {
    boolean bool1;
    boolean bool2;
    this.maxIter = paramListVector.getElementAsInt("maxiter");
    this.tolerance = paramListVector.getElementAsDouble("tol");
    this.minFac = paramListVector.getElementAsDouble("minFactor");
    if (paramListVector.getElementAsInt("warnOnly") == 1) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.warnOnly = bool2;
    if (paramListVector.getElementAsInt("printEval") == 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.printEval = bool1;
  }
  
  public int getMaxIterations() {
    return this.maxIter;
  }
  
  public double getMinFactor() {
    return this.minFac;
  }
  
  public double getTolerance() {
    return this.tolerance;
  }
  
  public boolean isPrintEval() {
    return this.printEval;
  }
  
  public boolean isWarnOnly() {
    return this.warnOnly;
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/stats-0.9.2724.jar!/org/renjin/stats/nls/NlsControl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */