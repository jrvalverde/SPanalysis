/*     */ package org.renjin.cran.randomForest;
/*     */ 
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gnur.api.S;
/*     */ import org.renjin.gnur.api.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class rfutils__
/*     */ {
/*     */   public static void zeroInt(IntPtr x, int length) {
/*  19 */     x$array = x.array; x$offset = x.offset; int i = length * 4; IntPtr.memset(x$array, x$offset, 0, i);
/*     */   }
/*     */   
/*     */   public static void zeroDouble(DoublePtr x, int length) {
/*  23 */     x$array = x.array; x$offset = x.offset; int i = length * 8; DoublePtr.memset(x$array, x$offset, 0, i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void createClass(DoublePtr x, int realN, int totalN, int mdim) {
/*  29 */     for (x$array = x.array, x$offset = x.offset, i = 0, i = realN; i < totalN; i++) {
/*  30 */       for (j = 0; j < mdim; j++) {
/*  31 */         double d3 = S.unif_rand(), d2 = realN; k = (int)(long)(d3 * d2);
/*  32 */         int i2 = (i * mdim + j) * 8; double[] arrayOfDouble2 = x$array; int i1 = x$offset + i2 / 8, n = (k * mdim + j) * 8; double[] arrayOfDouble1 = x$array; int m = x$offset + n / 8; double d1 = arrayOfDouble1[m]; arrayOfDouble2[i1] = d1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void normClassWt(IntPtr cl, int nsample, int nclass, int useWt, DoublePtr classwt, IntPtr classFreq) {
/*  40 */     cl$array = cl.array; cl$offset = cl.offset; classwt$array = classwt.array; classwt$offset = classwt.offset; classFreq$array = classFreq.array; classFreq$offset = classFreq.offset; sumwt = 0.0D; sumwt = 0.0D;
/*     */     
/*  42 */     if (useWt == 0)
/*     */     
/*     */     { 
/*     */ 
/*     */       
/*  47 */       for (i = 0; i < nclass; i++)
/*  48 */       { int n = i * 8; double[] arrayOfDouble = classwt$array; int m = classwt$offset + n / 8, k = i * 4, arrayOfInt[] = classFreq$array, j = classFreq$offset + k / 4; double d3 = arrayOfInt[j], d2 = nsample, d1 = d3 / d2; arrayOfDouble[m] = d1; }  } else { for (i = 0; i < nclass; ) { int k = i * 8; double[] arrayOfDouble = classwt$array; int j = classwt$offset + k / 8; sumwt = arrayOfDouble[j] + sumwt; i++; }
/*     */        for (i = 0; i < nclass; ) { int n = i * 8; double[] arrayOfDouble2 = classwt$array; int m = classwt$offset + n / 8, k = i * 8; double[] arrayOfDouble1 = classwt$array; int j = classwt$offset + k / 8; double d = arrayOfDouble1[j] / sumwt; arrayOfDouble2[m] = d; i++; }
/*     */        }
/*  51 */      for (i = 0; i < nclass; i++) {
/*  52 */       int n = i * 8; double[] arrayOfDouble = classwt$array; int m = classwt$offset + n / 8, k = i * 4, arrayOfInt[] = classFreq$array, j = classFreq$offset + k / 4; if (arrayOfInt[j] == 0) { iftmp$48 = 0.0D; } else { int i4 = i * 8; double[] arrayOfDouble1 = classwt$array; int i3 = classwt$offset + i4 / 8; double d4 = arrayOfDouble1[i3], d3 = nsample, d2 = d4 * d3; int i2 = i * 4, arrayOfInt1[] = classFreq$array, i1 = classFreq$offset + i2 / 4; double d1 = arrayOfInt1[i1]; iftmp$48 = d2 / d1; }  arrayOfDouble[m] = iftmp$48;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void makeA(DoublePtr x, int mdim, int nsample, IntPtr cat, IntPtr a, IntPtr b) {
/*  67 */     x$array = x.array; x$offset = x.offset; cat$array = cat.array; cat$offset = cat.offset; a$array = a.array; a$offset = a.offset; b$array = b.array; b$offset = b.offset; v = null; v$offset = 0; index = null; index$offset = 0; i = 0; v = new double[nsample * 8 / 8]; v$offset = 0;
/*  68 */     index = new int[nsample * 4 / 4]; index$offset = 0;
/*     */     
/*  70 */     for (i = 0; i < mdim; i++) {
/*  71 */       int m = i * 4, arrayOfInt[] = cat$array, k = cat$offset + m / 4; if (arrayOfInt[k] != 1)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  91 */         for (j = 0; j < nsample; j++)
/*  92 */         { int i4 = (j * mdim + i) * 4, arrayOfInt1[] = a$array, i3 = a$offset + i4 / 4, i2 = (j * mdim + i) * 8; double[] arrayOfDouble = x$array; int i1 = x$offset + i2 / 8, n = (int)(long)arrayOfDouble[i1]; arrayOfInt1[i3] = n; }  } else { for (j = 0; j < nsample; j++) { int i11 = j * 8; double[] arrayOfDouble2 = v; int i10 = v$offset + i11 / 8, i9 = (j * mdim + i) * 8; double[] arrayOfDouble1 = x$array; int i8 = x$offset + i9 / 8; double d = arrayOfDouble1[i8]; arrayOfDouble2[i10] = d; int i7 = j * 4, arrayOfInt3[] = index, i6 = index$offset + i7 / 4, i5 = j + 1; arrayOfInt3[i6] = i5; }  Utils.R_qsort_I(new DoublePtr(v, v$offset), new IntPtr(index, index$offset), 1, nsample); for (j = 0; nsample + -1 > j; j++) { int i16 = j * 4, arrayOfInt6[] = index, i15 = index$offset + i16 / 4; n1 = arrayOfInt6[i15]; int i14 = (j + 1) * 4, arrayOfInt5[] = index, i13 = index$offset + i14 / 4; n2 = arrayOfInt5[i13]; int i12 = (j * mdim + i) * 4, arrayOfInt4[] = a$array, i11 = a$offset + i12 / 4; arrayOfInt4[i11] = n1; if (j == 0) { int i18 = ((n1 + -1) * mdim + i) * 4, arrayOfInt7[] = b$array, i17 = b$offset + i18 / 4; arrayOfInt7[i17] = 1; }  int i10 = ((n2 + -1) * mdim + i) * 4, arrayOfInt3[] = b$array, i9 = b$offset + i10 / 4, i8 = j * 8; double[] arrayOfDouble2 = v; int i7 = v$offset + i8 / 8; double d2 = arrayOfDouble2[i7]; int i6 = (j + 1) * 8; double[] arrayOfDouble1 = v; int i5 = v$offset + i6 / 8; double d1 = arrayOfDouble1[i5]; if (((d2 >= d1) ? false : true) == false) { int i18 = ((n1 + -1) * mdim + i) * 4, arrayOfInt7[] = b$array, i17 = b$offset + i18 / 4; iftmp$38 = arrayOfInt7[i17]; } else { int i18 = ((n1 + -1) * mdim + i) * 4, arrayOfInt7[] = b$array, i17 = b$offset + i18 / 4; iftmp$38 = arrayOfInt7[i17] + 1; }  arrayOfInt3[i9] = iftmp$38; }
/*     */          int i4 = ((nsample + -1) * mdim + i) * 4, arrayOfInt2[] = a$array, i3 = a$offset + i4 / 4, i2 = (nsample + -1) * 4, arrayOfInt1[] = index, i1 = index$offset + i2 / 4, n = arrayOfInt1[i1]; arrayOfInt2[i3] = n; }
/*     */     
/*  95 */     }  index = null; index$offset = 0;
/*  96 */     v = null; v$offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modA(IntPtr a, IntPtr nuse, int nsample, int mdim, IntPtr cat, int maxcat, IntPtr ncase, IntPtr jin) {
/* 104 */     a$array = a.array; a$offset = a.offset; nuse$array = nuse.array; nuse$offset = nuse.offset; cat$array = cat.array; cat$offset = cat.offset; ncase$array = ncase.array; ncase$offset = ncase.offset; jin$array = jin.array; jin$offset = jin.offset; nt = 0; k = 0; j = 0; i = 0; nuse$array[nuse$offset] = 0;
/* 105 */     for (i = 0; i < nsample; ) { int i1 = i * 4, arrayOfInt[] = jin$array, n = jin$offset + i1 / 4; if (arrayOfInt[n] != 0) { int i2 = nuse$array[nuse$offset] + 1; nuse$array[nuse$offset] = i2; }  i++; }
/*     */     
/* 107 */     for (i = 0; i < mdim; i++) {
/* 108 */       k = 0;
/* 109 */       nt = 0;
/* 110 */       int i1 = i * 4, arrayOfInt[] = cat$array, n = cat$offset + i1 / 4; if (arrayOfInt[n] == 1)
/* 111 */         for (j = 0; j < nsample; ) {
/* 112 */           int i5 = (k * mdim + i) * 4, arrayOfInt2[] = a$array, i4 = a$offset + i5 / 4, i3 = (arrayOfInt2[i4] + -1) * 4, arrayOfInt1[] = jin$array, i2 = jin$offset + i3 / 4; if (arrayOfInt1[i2] == 0) {
/*     */ 
/*     */ 
/*     */             
/* 116 */             for (m = 0; nsample - k > m; ) {
/* 117 */               int i14 = ((k + m) * mdim + i) * 4, arrayOfInt6[] = a$array, i13 = a$offset + i14 / 4, i12 = (arrayOfInt6[i13] + -1) * 4, arrayOfInt5[] = jin$array, i11 = jin$offset + i12 / 4; if (arrayOfInt5[i11] == 0) { m++; continue; }
/* 118 */                int i10 = (nt * mdim + i) * 4, arrayOfInt4[] = a$array, i9 = a$offset + i10 / 4, i8 = ((k + m) * mdim + i) * 4, arrayOfInt3[] = a$array, i7 = a$offset + i8 / 4, i6 = arrayOfInt3[i7]; arrayOfInt4[i9] = i6;
/* 119 */               k = m + 1 + k; break;
/*     */             } 
/*     */           } else {
/*     */             int i10 = (nt * mdim + i) * 4, arrayOfInt4[] = a$array, i9 = a$offset + i10 / 4, i8 = (k * mdim + i) * 4, arrayOfInt3[] = a$array, i7 = a$offset + i8 / 4, i6 = arrayOfInt3[i7]; arrayOfInt4[i9] = i6; k++;
/*     */           } 
/* 124 */           nt++;
/* 125 */           if (nuse$array[nuse$offset] > nt) {
/*     */             j++; continue;
/*     */           }  break;
/*     */         }  
/* 129 */     }  if (maxcat > 1) {
/* 130 */       k = 0;
/* 131 */       nt = 0;
/* 132 */       for (i = 0; i < nsample; ) {
/* 133 */         int i1 = k * 4, arrayOfInt[] = jin$array, n = jin$offset + i1 / 4; if (arrayOfInt[n] == 0) {
/*     */ 
/*     */ 
/*     */           
/* 137 */           for (j = 0; nsample - k > j; ) {
/* 138 */             int i6 = (k + j) * 4, arrayOfInt2[] = jin$array, i5 = jin$offset + i6 / 4; if (arrayOfInt2[i5] == 0) { j++; continue; }
/* 139 */              int i4 = nt * 4, arrayOfInt1[] = ncase$array, i3 = ncase$offset + i4 / 4, i2 = k + j + 1; arrayOfInt1[i3] = i2;
/* 140 */             k = j + 1 + k; break;
/*     */           } 
/*     */         } else {
/*     */           k++; int i3 = nt * 4, arrayOfInt1[] = ncase$array, i2 = ncase$offset + i3 / 4; arrayOfInt1[i2] = k;
/*     */         } 
/* 145 */         nt++;
/* 146 */         if (nuse$array[nuse$offset] > nt) {
/*     */           i++;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Xtranslate(DoublePtr x, int mdim, int nrnodes, int nsample, IntPtr bestvar, IntPtr bestsplit, IntPtr bestsplitnext, DoublePtr xbestsplit, IntPtr nodestatus, IntPtr cat, int treeSize) {
/* 163 */     for (x$array = x.array, x$offset = x.offset, bestvar$array = bestvar.array, bestvar$offset = bestvar.offset, bestsplit$array = bestsplit.array, bestsplit$offset = bestsplit.offset, bestsplitnext$array = bestsplitnext.array, bestsplitnext$offset = bestsplitnext.offset, xbestsplit$array = xbestsplit.array, xbestsplit$offset = xbestsplit.offset, nodestatus$array = nodestatus.array, nodestatus$offset = nodestatus.offset, cat$array = cat.array, cat$offset = cat.offset, i = 0; i < treeSize; i++) {
/* 164 */       int k = i * 4, arrayOfInt[] = nodestatus$array, j = nodestatus$offset + k / 4; if (arrayOfInt[j] == 1) {
/* 165 */         int i3 = i * 4, arrayOfInt2[] = bestvar$array, i2 = bestvar$offset + i3 / 4; m = arrayOfInt2[i2] + -1;
/* 166 */         int i1 = m * 4, arrayOfInt1[] = cat$array, n = cat$offset + i1 / 4; if (arrayOfInt1[n] != 1) {
/*     */ 
/*     */ 
/*     */           
/* 170 */           int i7 = i * 8; double[] arrayOfDouble = xbestsplit$array; int i6 = xbestsplit$offset + i7 / 8, i5 = i * 4, arrayOfInt3[] = bestsplit$array, i4 = bestsplit$offset + i5 / 4; double d = arrayOfInt3[i4]; arrayOfDouble[i6] = d;
/*     */         } else {
/*     */           int i13 = i * 8;
/*     */           double[] arrayOfDouble3 = xbestsplit$array;
/*     */           int i12 = xbestsplit$offset + i13 / 8, i11 = i * 4, arrayOfInt4[] = bestsplit$array, i10 = bestsplit$offset + i11 / 4, i9 = ((arrayOfInt4[i10] + -1) * mdim + m) * 8;
/*     */           double[] arrayOfDouble2 = x$array;
/*     */           int i8 = x$offset + i9 / 8;
/*     */           double d3 = arrayOfDouble2[i8];
/*     */           int i7 = i * 4, arrayOfInt3[] = bestsplitnext$array, i6 = bestsplitnext$offset + i7 / 4, i5 = ((arrayOfInt3[i6] + -1) * mdim + m) * 8;
/*     */           double[] arrayOfDouble1 = x$array;
/*     */           int i4 = x$offset + i5 / 8;
/*     */           double d2 = arrayOfDouble1[i4];
/*     */           double d1 = (d3 + d2) * 0.5D;
/*     */           arrayOfDouble3[i12] = d1;
/*     */         } 
/*     */       } 
/* 186 */     }  } public static void permuteOOB(int m, DoublePtr x, IntPtr in, int nsample, int mdim) { x$array = x.array; x$offset = x.offset; in$array = in.array; in$offset = in.offset; nOOB = 0; tp = null; tp$offset = 0; nOOB = 0;
/*     */     
/* 188 */     tp = new double[nsample * 8 / 8]; tp$offset = 0;
/*     */     
/* 190 */     for (i = 0; i < nsample; i++) {
/*     */       
/* 192 */       int n = i * 4, arrayOfInt[] = in$array, j = in$offset + n / 4; if (arrayOfInt[j] == 0) {
/* 193 */         int i4 = nOOB * 8; double[] arrayOfDouble2 = tp; int i3 = tp$offset + i4 / 8, i2 = (i * mdim + m) * 8; double[] arrayOfDouble1 = x$array; int i1 = x$offset + i2 / 8; double d = arrayOfDouble1[i1]; arrayOfDouble2[i3] = d;
/* 194 */         nOOB++;
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     last = nOOB;
/* 199 */     for (i = 0; i < nOOB; i++) {
/* 200 */       double d3 = last, d2 = S.unif_rand(); k = (int)(long)(d3 * d2);
/* 201 */       int i6 = (last + -1) * 8; double[] arrayOfDouble4 = tp; int i5 = tp$offset + i6 / 8; tmp = arrayOfDouble4[i5];
/* 202 */       int i4 = (last + -1) * 8; double[] arrayOfDouble3 = tp; int i3 = tp$offset + i4 / 8, i2 = k * 8; double[] arrayOfDouble2 = tp; int i1 = tp$offset + i2 / 8; double d1 = arrayOfDouble2[i1]; arrayOfDouble3[i3] = d1;
/* 203 */       int n = k * 8; double[] arrayOfDouble1 = tp; int j = tp$offset + n / 8; arrayOfDouble1[j] = tmp;
/* 204 */       last--;
/*     */     } 
/*     */ 
/*     */     
/* 208 */     nOOB = 0;
/* 209 */     for (i = 0; i < nsample; i++) {
/* 210 */       int n = i * 4, arrayOfInt[] = in$array, j = in$offset + n / 4; if (arrayOfInt[j] == 0) {
/* 211 */         int i4 = (i * mdim + m) * 8; double[] arrayOfDouble2 = x$array; int i3 = x$offset + i4 / 8, i2 = nOOB * 8; double[] arrayOfDouble1 = tp; int i1 = tp$offset + i2 / 8; double d = arrayOfDouble1[i1]; arrayOfDouble2[i3] = d;
/* 212 */         nOOB++;
/*     */       } 
/*     */     } 
/* 215 */     tp = null; tp$offset = 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void computeProximity(DoublePtr prox, int oobprox, IntPtr node, IntPtr inbag, IntPtr oobpair, int n) {
/* 230 */     for (prox$array = prox.array, prox$offset = prox.offset, node$array = node.array, node$offset = node.offset, inbag$array = inbag.array, inbag$offset = inbag.offset, oobpair$array = oobpair.array, oobpair$offset = oobpair.offset, i = 0, i = 0; i < n; i++) {
/* 231 */       for (j = i + 1; j < n; j++) {
/* 232 */         if (oobprox == 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 242 */           int i4 = i * 4, arrayOfInt2[] = node$array, i3 = node$offset + i4 / 4, i2 = arrayOfInt2[i3], i1 = j * 4, arrayOfInt1[] = node$array, m = node$offset + i1 / 4, k = arrayOfInt1[m]; if (i2 == k) {
/* 243 */             int i12 = (j * n + i) * 8; double[] arrayOfDouble4 = prox$array; int i11 = prox$offset + i12 / 8, i10 = (j * n + i) * 8; double[] arrayOfDouble3 = prox$array; int i9 = prox$offset + i10 / 8; double d2 = arrayOfDouble3[i9] + 1.0D; arrayOfDouble4[i11] = d2;
/* 244 */             int i8 = (i * n + j) * 8; double[] arrayOfDouble2 = prox$array; int i7 = prox$offset + i8 / 8, i6 = (i * n + j) * 8; double[] arrayOfDouble1 = prox$array; int i5 = prox$offset + i6 / 8; double d1 = arrayOfDouble1[i5] + 1.0D; arrayOfDouble2[i7] = d1;
/*     */           }  }
/*     */         else { int m = i * 4, arrayOfInt[] = inbag$array, k = inbag$offset + m / 4; if (arrayOfInt[k] <= 0) { int i2 = j * 4, arrayOfInt1[] = inbag$array, i1 = inbag$offset + i2 / 4; if (arrayOfInt1[i1] <= 0) { int i14 = (j * n + i) * 4, arrayOfInt5[] = oobpair$array, i13 = oobpair$offset + i14 / 4, i12 = arrayOfInt5[i13] + 1; arrayOfInt5[i13] = i12; int i11 = (i * n + j) * 4, arrayOfInt4[] = oobpair$array, i10 = oobpair$offset + i11 / 4, i9 = arrayOfInt4[i10] + 1; arrayOfInt4[i10] = i9; int i8 = i * 4, arrayOfInt3[] = node$array, i7 = node$offset + i8 / 4, i6 = arrayOfInt3[i7], i5 = j * 4, arrayOfInt2[] = node$array, i4 = node$offset + i5 / 4, i3 = arrayOfInt2[i4]; if (i6 == i3) { int i22 = (j * n + i) * 8; double[] arrayOfDouble4 = prox$array; int i21 = prox$offset + i22 / 8, i20 = (j * n + i) * 8; double[] arrayOfDouble3 = prox$array; int i19 = prox$offset + i20 / 8; double d2 = arrayOfDouble3[i19] + 1.0D; arrayOfDouble4[i21] = d2; int i18 = (i * n + j) * 8; double[] arrayOfDouble2 = prox$array; int i17 = prox$offset + i18 / 8, i16 = (i * n + j) * 8; double[] arrayOfDouble1 = prox$array; int i15 = prox$offset + i16 / 8; double d1 = arrayOfDouble1[i15] + 1.0D; arrayOfDouble2[i17] = d1; }
/*     */                }
/*     */              }
/*     */            }
/*     */       
/*     */       } 
/* 252 */     }  } public static double pack(int nBits, IntPtr bits) { bits$array = bits.array; bits$offset = bits.offset; i = nBits + -1;
/* 253 */     int k = i * 4, arrayOfInt[] = bits$array, j = bits$offset + k / 4; pack = arrayOfInt[j];
/* 254 */     for (i = nBits + -1; i > 0; ) { double d2 = pack * 2.0D; int n = (i + -1) * 4, arrayOfInt1[] = bits$array, m = bits$offset + n / 4; double d1 = arrayOfInt1[m]; pack = d2 + d1; i--; }
/* 255 */      return pack; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unpack(double pack, int nBits, IntPtr bits) {
/* 260 */     bits$array = bits.array; bits$offset = bits.offset; x = pack;
/* 261 */     for (i = 0; i <= nBits; i++) {
/* 262 */       int m = i * 4, arrayOfInt[] = bits$array, k = bits$offset + m / 4, j = (int)(long)x & 0x1; arrayOfInt[k] = j;
/* 263 */       x /= 2.0D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unpack_(DoublePtr pack, IntPtr nBits, IntPtr bits) {
/* 282 */     pack$array = pack.array; pack$offset = pack.offset; nBits$array = nBits.array; nBits$offset = nBits.offset; bits$array = bits.array; bits$offset = bits.offset; int i = nBits$array[nBits$offset]; unpack(pack$array[pack$offset], i, new IntPtr(bits$array, bits$offset));
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/rfutils__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */