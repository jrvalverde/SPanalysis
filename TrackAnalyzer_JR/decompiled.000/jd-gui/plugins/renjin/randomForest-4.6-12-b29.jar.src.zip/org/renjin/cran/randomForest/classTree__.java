/*     */ package org.renjin.cran.randomForest;
/*     */ 
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Mathlib;
/*     */ import org.renjin.gnur.api.S;
/*     */ import org.renjin.gnur.api.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class classTree__
/*     */ {
/*     */   public static void catmax_(DoublePtr parentDen, DoublePtr tclasscat, DoublePtr tclasspop, IntPtr nclass, IntPtr lcat, DoublePtr catsp, DoublePtr critmax, IntPtr nhit, IntPtr maxcat, IntPtr ncmax, IntPtr ncsplit) {
/* 308 */     parentDen$array = parentDen.array; parentDen$offset = parentDen.offset; tclasscat$array = tclasscat.array; tclasscat$offset = tclasscat.offset; tclasspop$array = tclasspop.array; tclasspop$offset = tclasspop.offset; nclass$array = nclass.array; nclass$offset = nclass.offset; lcat$array = lcat.array; lcat$offset = lcat.offset; catsp$array = catsp.array; catsp$offset = catsp.offset; critmax$array = critmax.array; critmax$offset = critmax.offset; nhit$array = nhit.array; nhit$offset = nhit.offset; maxcat$array = maxcat.array; maxcat$offset = maxcat.offset; ncmax$array = ncmax.array; ncmax$offset = ncmax.offset; ncsplit$array = ncsplit.array; ncsplit$offset = ncsplit.offset; icat = new int[53]; leftCatClassCount = null; leftCatClassCount$offset = 0; leftDen = 0.0D; leftNum = 0.0D; nsplit = 0; n = 0; j = 0; leftCatClassCount = new double[nclass$array[nclass$offset] * 8 / 8]; leftCatClassCount$offset = 0;
/* 309 */     nhit$array[nhit$offset] = 0;
/* 310 */     int m = lcat$array[lcat$offset], i = ncmax$array[ncmax$offset];
/* 311 */     if (m <= i) { double d = lcat$array[lcat$offset] - 1.0D; iftmp$20 = (int)(long)Mathlib.pow(2.0D, d) + -1; } else { iftmp$20 = ncsplit$array[ncsplit$offset]; }
/*     */      nsplit = iftmp$20;
/* 313 */     for (n = 0; n < nsplit; n++) {
/* 314 */       rfutils__.zeroInt(new IntPtr(icat, 0), 53);
/* 315 */       int i2 = lcat$array[lcat$offset], i1 = ncmax$array[ncmax$offset]; if (i2 <= i1)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */         
/* 321 */         int i3 = lcat$array[lcat$offset]; rfutils__.unpack(n + 1.0D, i3, new IntPtr(icat, 0)); } else { for (j = 0; lcat$array[lcat$offset] > j; ) { boolean bool = (S.unif_rand() <= 0.5D) ? false : true; icat[0 + j] = bool; j++; }
/*     */          }
/* 323 */        for (j = 0; nclass$array[nclass$offset] > j; j++) {
/* 324 */         int i4 = j * 8; double[] arrayOfDouble = leftCatClassCount; int i3 = leftCatClassCount$offset + i4 / 8; arrayOfDouble[i3] = 0.0D;
/* 325 */         for (k = 0; lcat$array[lcat$offset] > k; k++) {
/* 326 */           if (icat[0 + k] != 0) {
/* 327 */             int i10 = j * 8; double[] arrayOfDouble3 = leftCatClassCount; int i9 = leftCatClassCount$offset + i10 / 8, i8 = j * 8; double[] arrayOfDouble2 = leftCatClassCount; int i7 = leftCatClassCount$offset + i8 / 8; double d3 = arrayOfDouble2[i7]; int i6 = (nclass$array[nclass$offset] * k + j) * 8; double[] arrayOfDouble1 = tclasscat$array; int i5 = tclasscat$offset + i6 / 8; double d2 = arrayOfDouble1[i5], d1 = d3 + d2; arrayOfDouble3[i9] = d1;
/*     */           } 
/*     */         } 
/*     */       } 
/* 331 */       leftNum = 0.0D;
/* 332 */       leftDen = 0.0D;
/* 333 */       for (j = 0; nclass$array[nclass$offset] > j; j++) {
/* 334 */         int i8 = j * 8; double[] arrayOfDouble3 = leftCatClassCount; int i7 = leftCatClassCount$offset + i8 / 8; double d2 = arrayOfDouble3[i7]; int i6 = j * 8; double[] arrayOfDouble2 = leftCatClassCount; int i5 = leftCatClassCount$offset + i6 / 8; double d1 = arrayOfDouble2[i5]; leftNum = d2 * d1 + leftNum;
/* 335 */         int i4 = j * 8; double[] arrayOfDouble1 = leftCatClassCount; int i3 = leftCatClassCount$offset + i4 / 8; leftDen = arrayOfDouble1[i3] + leftDen;
/*     */       } 
/*     */       
/* 338 */       if (((leftDen > 1.0E-8D) ? false : true) == false && ((parentDen$array[parentDen$offset] - leftDen > 1.0E-5D) ? false : true) == false) {
/* 339 */         rightNum = 0.0D;
/* 340 */         for (j = 0; nclass$array[nclass$offset] > j; j++) {
/* 341 */           int i12 = j * 8; double[] arrayOfDouble5 = leftCatClassCount; int i11 = leftCatClassCount$offset + i12 / 8, i10 = j * 8; double[] arrayOfDouble4 = tclasspop$array; int i9 = tclasspop$offset + i10 / 8; double d8 = arrayOfDouble4[i9]; int i8 = j * 8; double[] arrayOfDouble3 = leftCatClassCount; int i7 = leftCatClassCount$offset + i8 / 8; double d7 = arrayOfDouble3[i7], d6 = d8 - d7; arrayOfDouble5[i11] = d6;
/* 342 */           int i6 = j * 8; double[] arrayOfDouble2 = leftCatClassCount; int i5 = leftCatClassCount$offset + i6 / 8; double d5 = arrayOfDouble2[i5]; int i4 = j * 8; double[] arrayOfDouble1 = leftCatClassCount; int i3 = leftCatClassCount$offset + i4 / 8; double d4 = arrayOfDouble1[i3]; rightNum = d5 * d4 + rightNum;
/*     */         } 
/* 344 */         double d3 = leftNum / leftDen, d2 = parentDen$array[parentDen$offset] - leftDen, d1 = rightNum / d2; decGini = d3 + d1;
/* 345 */         if (((critmax$array[critmax$offset] >= decGini) ? false : true) != false) {
/* 346 */           critmax$array[critmax$offset] = decGini;
/* 347 */           nhit$array[nhit$offset] = 1;
/* 348 */           int i4 = lcat$array[lcat$offset], i3 = ncmax$array[ncmax$offset]; if (i4 <= i3) { iftmp$32 = (n + 1); } else { iftmp$32 = rfutils__.pack(lcat$array[lcat$offset], new IntPtr(icat, 0)); }  catsp$array[catsp$offset] = iftmp$32;
/*     */         } 
/*     */       } 
/* 351 */     }  leftCatClassCount = null; leftCatClassCount$offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void catmaxb_(DoublePtr totalWt, DoublePtr tclasscat, DoublePtr classCount, IntPtr nclass, IntPtr nCat, DoublePtr best, DoublePtr critmax, IntPtr nhit, DoublePtr catCount) {
/* 364 */     totalWt$array = totalWt.array; totalWt$offset = totalWt.offset; tclasscat$array = tclasscat.array; tclasscat$offset = tclasscat.offset; classCount$array = classCount.array; classCount$offset = classCount.offset; nclass$array = nclass.array; nclass$offset = nclass.offset; nCat$array = nCat.array; nCat$offset = nCat.offset; best$array = best.array; best$offset = best.offset; critmax$array = critmax.array; critmax$offset = critmax.offset; nhit$array = nhit.array; nhit$offset = nhit.offset; catCount$array = catCount.array; catCount$offset = catCount.offset; kcat = new int[53]; cm = new double[53]; cp = new double[53]; catProportion = new double[53]; leftDen = 0.0D; rightDen = 0.0D; bestsplit = 0.0D; i = 0; bestsplit = 0.0D;
/*     */     
/* 366 */     nhit$array[nhit$offset] = 0;
/* 367 */     for (i = 0; nCat$array[nCat$offset] > i; i++) {
/* 368 */       int i1 = i * 8; double[] arrayOfDouble = catCount$array; int n = catCount$offset + i1 / 8; if (arrayOfDouble[n] == 
/* 369 */         0.0D) { iftmp$13 = 0.0D; } else { int i5 = nclass$array[nclass$offset] * i * 8; double[] arrayOfDouble2 = tclasscat$array; int i4 = tclasscat$offset + i5 / 8; double d2 = arrayOfDouble2[i4]; int i3 = i * 8; double[] arrayOfDouble1 = catCount$array; int i2 = catCount$offset + i3 / 8; double d1 = arrayOfDouble1[i2]; iftmp$13 = d2 / d1; }
/* 370 */        catProportion[0 + i] = iftmp$13; int m = i + 1; kcat[0 + i] = m;
/*     */     } 
/* 372 */     int k = nCat$array[nCat$offset]; Utils.R_qsort_I(new DoublePtr(catProportion, 0), new IntPtr(kcat, 0), 1, k);
/* 373 */     for (i = 0; nclass$array[nclass$offset] > i; i++) {
/* 374 */       cp[0 + i] = 0.0D;
/* 375 */       int n = i * 8; double[] arrayOfDouble = classCount$array; int m = classCount$offset + n / 8; double d = arrayOfDouble[m]; cm[0 + i] = d;
/*     */     } 
/* 377 */     rightDen = totalWt$array[totalWt$offset];
/* 378 */     leftDen = 0.0D;
/* 379 */     for (i = 0; nCat$array[nCat$offset] + -1 > i; i++) {
/* 380 */       int i3 = (kcat[0 + i] + -1) * 8; double[] arrayOfDouble2 = catCount$array; int i2 = catCount$offset + i3 / 8; leftDen = arrayOfDouble2[i2] + leftDen;
/* 381 */       int i1 = (kcat[0 + i] + -1) * 8; double[] arrayOfDouble1 = catCount$array; int n = catCount$offset + i1 / 8; double d3 = arrayOfDouble1[n]; rightDen -= d3;
/* 382 */       leftNum = 0.0D;
/* 383 */       rightNum = 0.0D;
/* 384 */       for (j = 0; nclass$array[nclass$offset] > j; j++) {
/* 385 */         double d13 = cp[0 + j]; int i11 = kcat[0 + i] + -1, i10 = nclass$array[nclass$offset], i9 = (i11 * i10 + j) * 8; double[] arrayOfDouble4 = tclasscat$array; int i8 = tclasscat$offset + i9 / 8; double d12 = arrayOfDouble4[i8], d11 = d13 + d12; cp[0 + j] = d11;
/* 386 */         double d10 = cm[0 + j]; int i7 = kcat[0 + i] + -1, i6 = nclass$array[nclass$offset], i5 = (i7 * i6 + j) * 8; double[] arrayOfDouble3 = tclasscat$array; int i4 = tclasscat$offset + i5 / 8; double d9 = arrayOfDouble3[i4], d8 = d10 - d9; cm[0 + j] = d8;
/* 387 */         double d7 = cp[0 + j], d6 = cp[0 + j]; leftNum = d7 * d6 + leftNum;
/* 388 */         double d5 = cm[0 + j], d4 = cm[0 + j]; rightNum = d5 * d4 + rightNum;
/*     */       } 
/* 390 */       double d2 = catProportion[0 + i]; int m = i + 1; double d1 = catProportion[0 + m]; if (((d2 >= d1) ? false : true) != false)
/*     */       {
/* 392 */         if (((rightDen <= 1.0E-5D) ? false : true) != false && ((leftDen <= 1.0E-5D) ? false : true) != false) {
/* 393 */           double d5 = leftNum / leftDen, d4 = rightNum / rightDen; crit = d5 + d4;
/* 394 */           if (((critmax$array[critmax$offset] >= crit) ? false : true) != false) {
/* 395 */             critmax$array[critmax$offset] = crit;
/* 396 */             double d7 = catProportion[0 + i]; int i4 = i + 1; double d6 = catProportion[0 + i4]; bestsplit = (d7 + d6) * 0.5D;
/* 397 */             nhit$array[nhit$offset] = 1;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 402 */     if (nhit$array[nhit$offset] == 1) {
/* 403 */       int m = nCat$array[nCat$offset]; rfutils__.zeroInt(new IntPtr(kcat, 0), m);
/* 404 */       for (i = 0; nCat$array[nCat$offset] > i; i++) {
/* 405 */         int i1 = i * 8; double[] arrayOfDouble = catCount$array; int n = catCount$offset + i1 / 8; if (arrayOfDouble[n] == 
/* 406 */           0.0D) { iftmp$17 = 0.0D; } else { int i5 = nclass$array[nclass$offset] * i * 8; double[] arrayOfDouble2 = tclasscat$array; int i4 = tclasscat$offset + i5 / 8; double d2 = arrayOfDouble2[i4]; int i3 = i * 8; double[] arrayOfDouble1 = catCount$array; int i2 = catCount$offset + i3 / 8; double d1 = arrayOfDouble1[i2]; iftmp$17 = d2 / d1; }
/* 407 */          catProportion[0 + i] = iftmp$17; boolean bool = (catProportion[0 + i] >= bestsplit) ? false : true; kcat[0 + i] = bool;
/*     */       } 
/*     */       
/* 410 */       double d = rfutils__.pack(nCat$array[nCat$offset], new IntPtr(kcat, 0)); best$array[best$offset] = d;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictClassTree(DoublePtr x, int n, int mdim, IntPtr treemap, IntPtr nodestatus, DoublePtr xbestsplit, IntPtr bestvar, IntPtr nodeclass, int treeSize, IntPtr cat, int nclass, IntPtr jts, IntPtr nodex, int maxcat) {
/* 426 */     x$array = x.array; x$offset = x.offset; treemap$array = treemap.array; treemap$offset = treemap.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; xbestsplit$array = xbestsplit.array; xbestsplit$offset = xbestsplit.offset; bestvar$array = bestvar.array; bestvar$offset = bestvar.offset; nodeclass$array = nodeclass.array; nodeclass$offset = nodeclass.offset; cat$array = cat.array; cat$offset = cat.offset; jts$array = jts.array; jts$offset = jts.offset; nodex$array = nodex.array; nodex$offset = nodex.offset; cbestsplit = null; cbestsplit$offset = 0; i = 0; if (maxcat > 1) {
/* 427 */       cbestsplit = new int[maxcat * treeSize * 4 / 4]; cbestsplit$offset = 0;
/* 428 */       int i1 = maxcat * treeSize; rfutils__.zeroInt(new IntPtr(cbestsplit, cbestsplit$offset), i1);
/* 429 */       for (i = 0; i < treeSize; i++) {
/* 430 */         int i3 = i * 4, arrayOfInt[] = nodestatus$array, i2 = nodestatus$offset + i3 / 4; if (arrayOfInt[i2] != -1) {
/* 431 */           int i7 = i * 4, arrayOfInt2[] = bestvar$array, i6 = bestvar$offset + i7 / 4, i5 = (arrayOfInt2[i6] + -1) * 4, arrayOfInt1[] = cat$array, i4 = cat$offset + i5 / 4; if (arrayOfInt1[i4] > 1) {
/* 432 */             int i9 = i * 8; double[] arrayOfDouble = xbestsplit$array; int i8 = xbestsplit$offset + i9 / 8; dpack = arrayOfDouble[i8];
/*     */ 
/*     */             
/* 435 */             j = 0; while (true) { int i13 = i * 4, arrayOfInt4[] = bestvar$array, i12 = bestvar$offset + i13 / 4, i11 = (arrayOfInt4[i12] + -1) * 4, arrayOfInt3[] = cat$array, i10 = cat$offset + i11 / 4; if (arrayOfInt3[i10] <= j)
/* 436 */                 break;  int i16 = (i * maxcat + j) * 4, arrayOfInt5[] = cbestsplit, i15 = cbestsplit$offset + i16 / 4, i14 = (int)(long)dpack & 0x1; arrayOfInt5[i15] = i14;
/* 437 */               dpack /= 2.0D; j++; }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 443 */     for (i = 0; i < n; i++) {
/* 444 */       k = 0; while (true) {
/* 445 */         int i10 = k * 4, arrayOfInt4[] = nodestatus$array, i9 = nodestatus$offset + i10 / 4; if (arrayOfInt4[i9] == -1)
/* 446 */           break;  int i18 = k * 4, arrayOfInt6[] = bestvar$array, i17 = bestvar$offset + i18 / 4; m = arrayOfInt6[i17] + -1;
/* 447 */         int i16 = m * 4, arrayOfInt5[] = cat$array, i15 = cat$offset + i16 / 4; if (arrayOfInt5[i15] != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 453 */           int i24 = (i * mdim + m) * 8; double[] arrayOfDouble = x$array; int i23 = x$offset + i24 / 8, i22 = (int)(long)arrayOfDouble[i23] + -1, i21 = k * maxcat, i20 = (i22 + i21) * 4, arrayOfInt[] = cbestsplit, i19 = cbestsplit$offset + i20 / 4; if (arrayOfInt[i19] == 
/* 454 */             0) { int i26 = k * 8 + 4, arrayOfInt7[] = treemap$array, i25 = treemap$offset + i26 / 4; iftmp$8 = arrayOfInt7[i25] + -1; } else { int i26 = k * 8, arrayOfInt7[] = treemap$array, i25 = treemap$offset + i26 / 4; iftmp$8 = arrayOfInt7[i25] + -1; }  k = iftmp$8; continue;
/*     */         }  int i14 = (i * mdim + m) * 8; double[] arrayOfDouble2 = x$array; int i13 = x$offset + i14 / 8; double d2 = arrayOfDouble2[i13]; int i12 = k * 8; double[] arrayOfDouble1 = xbestsplit$array; int i11 = xbestsplit$offset + i12 / 8; double d1 = arrayOfDouble1[i11]; if (((d2 > d1) ? false : true) == false) { int i20 = k * 8 + 4, arrayOfInt[] = treemap$array, i19 = treemap$offset + i20 / 4; iftmp$6 = arrayOfInt[i19] + -1; }
/*     */         else { int i20 = k * 8, arrayOfInt[] = treemap$array, i19 = treemap$offset + i20 / 4; iftmp$6 = arrayOfInt[i19] + -1; }
/*     */          k = iftmp$6;
/* 458 */       }  int i8 = i * 4, arrayOfInt3[] = jts$array, i7 = jts$offset + i8 / 4, i6 = k * 4, arrayOfInt2[] = nodeclass$array, i5 = nodeclass$offset + i6 / 4, i4 = arrayOfInt2[i5]; arrayOfInt3[i7] = i4;
/* 459 */       int i3 = i * 4, arrayOfInt1[] = nodex$array, i2 = nodex$offset + i3 / 4, i1 = k + 1; arrayOfInt1[i2] = i1;
/*     */     } 
/* 461 */     if (maxcat > 1) { cbestsplit = null; cbestsplit$offset = 0; }
/*     */   
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/classTree__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */