package org.renjin.cran.randomForest;

import org.renjin.gcc.runtime.DoublePtr;
import org.renjin.gcc.runtime.IntPtr;

public class randomForest {
  public static void simpleLinReg(int paramInt, DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr) {
    regrf__.simpleLinReg(paramInt, paramDoublePtr1, paramDoublePtr2, paramDoublePtr3, paramDoublePtr4, paramIntPtr);
  }
  
  public static void movedata_(IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, DoublePtr paramDoublePtr, IntPtr paramIntPtr11) {
    rfsub__.movedata_(paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramDoublePtr, paramIntPtr11);
  }
  
  public static void buildtree_(IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, IntPtr paramIntPtr11, IntPtr paramIntPtr12, DoublePtr paramDoublePtr1, IntPtr paramIntPtr13, IntPtr paramIntPtr14, IntPtr paramIntPtr15, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr16, IntPtr paramIntPtr17, IntPtr paramIntPtr18, IntPtr paramIntPtr19, IntPtr paramIntPtr20, IntPtr paramIntPtr21, IntPtr paramIntPtr22, IntPtr paramIntPtr23, IntPtr paramIntPtr24, DoublePtr paramDoublePtr5, DoublePtr paramDoublePtr6, DoublePtr paramDoublePtr7, IntPtr paramIntPtr25, IntPtr paramIntPtr26, IntPtr paramIntPtr27) {
    rfsub__.buildtree_(paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramIntPtr11, paramIntPtr12, paramDoublePtr1, paramIntPtr13, paramIntPtr14, paramIntPtr15, paramDoublePtr2, paramDoublePtr3, paramDoublePtr4, paramIntPtr16, paramIntPtr17, paramIntPtr18, paramIntPtr19, paramIntPtr20, paramIntPtr21, paramIntPtr22, paramIntPtr23, paramIntPtr24, paramDoublePtr5, paramDoublePtr6, paramDoublePtr7, paramIntPtr25, paramIntPtr26, paramIntPtr27);
  }
  
  public static void predictRegTree(DoublePtr paramDoublePtr1, int paramInt1, int paramInt2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr4, int paramInt3, IntPtr paramIntPtr5, int paramInt4, IntPtr paramIntPtr6) {
    regTree__.predictRegTree(paramDoublePtr1, paramInt1, paramInt2, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramDoublePtr2, paramDoublePtr3, paramDoublePtr4, paramIntPtr4, paramInt3, paramIntPtr5, paramInt4, paramIntPtr6);
  }
  
  public static void findBestSplit(DoublePtr paramDoublePtr1, IntPtr paramIntPtr1, DoublePtr paramDoublePtr2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, IntPtr paramIntPtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr3, IntPtr paramIntPtr4, int paramInt5, double paramDouble, int paramInt6, IntPtr paramIntPtr5) {
    regTree__.findBestSplit(paramDoublePtr1, paramIntPtr1, paramDoublePtr2, paramInt1, paramInt2, paramInt3, paramInt4, paramIntPtr2, paramDoublePtr3, paramDoublePtr4, paramIntPtr3, paramIntPtr4, paramInt5, paramDouble, paramInt6, paramIntPtr5);
  }
  
  public static void TestSetError(DoublePtr paramDoublePtr1, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, int paramInt1, int paramInt2, int paramInt3, DoublePtr paramDoublePtr2, int paramInt4, IntPtr paramIntPtr4, DoublePtr paramDoublePtr3) {
    rf__.TestSetError(paramDoublePtr1, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramInt1, paramInt2, paramInt3, paramDoublePtr2, paramInt4, paramIntPtr4, paramDoublePtr3);
  }
  
  public static void regTree(DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, int paramInt1, int paramInt2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr3, int paramInt3, IntPtr paramIntPtr4, int paramInt4, int paramInt5, IntPtr paramIntPtr5, IntPtr paramIntPtr6, DoublePtr paramDoublePtr5, IntPtr paramIntPtr7) {
    regTree__.regTree(paramDoublePtr1, paramDoublePtr2, paramInt1, paramInt2, paramIntPtr1, paramIntPtr2, paramDoublePtr3, paramDoublePtr4, paramIntPtr3, paramInt3, paramIntPtr4, paramInt4, paramInt5, paramIntPtr5, paramIntPtr6, paramDoublePtr5, paramIntPtr7);
  }
  
  public static void zeroDouble(DoublePtr paramDoublePtr, int paramInt) {
    rfutils__.zeroDouble(paramDoublePtr, paramInt);
  }
  
  public static void permuteOOB(int paramInt1, DoublePtr paramDoublePtr, IntPtr paramIntPtr, int paramInt2, int paramInt3) {
    rfutils__.permuteOOB(paramInt1, paramDoublePtr, paramIntPtr, paramInt2, paramInt3);
  }
  
  public static void regForest(DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, IntPtr paramIntPtr11, IntPtr paramIntPtr12, DoublePtr paramDoublePtr5, IntPtr paramIntPtr13, DoublePtr paramDoublePtr6, IntPtr paramIntPtr14, IntPtr paramIntPtr15) {
    regrf__.regForest(paramDoublePtr1, paramDoublePtr2, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramDoublePtr3, paramDoublePtr4, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramIntPtr11, paramIntPtr12, paramDoublePtr5, paramIntPtr13, paramDoublePtr6, paramIntPtr14, paramIntPtr15);
  }
  
  public static void catmaxb_(DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, IntPtr paramIntPtr1, IntPtr paramIntPtr2, DoublePtr paramDoublePtr4, DoublePtr paramDoublePtr5, IntPtr paramIntPtr3, DoublePtr paramDoublePtr6) {
    classTree__.catmaxb_(paramDoublePtr1, paramDoublePtr2, paramDoublePtr3, paramIntPtr1, paramIntPtr2, paramDoublePtr4, paramDoublePtr5, paramIntPtr3, paramDoublePtr6);
  }
  
  public static void oob(int paramInt1, int paramInt2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, DoublePtr paramDoublePtr1, IntPtr paramIntPtr6, DoublePtr paramDoublePtr2) {
    rf__.oob(paramInt1, paramInt2, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramDoublePtr1, paramIntPtr6, paramDoublePtr2);
  }
  
  public static void normClassWt(IntPtr paramIntPtr1, int paramInt1, int paramInt2, int paramInt3, DoublePtr paramDoublePtr, IntPtr paramIntPtr2) {
    rfutils__.normClassWt(paramIntPtr1, paramInt1, paramInt2, paramInt3, paramDoublePtr, paramIntPtr2);
  }
  
  public static void predictClassTree(DoublePtr paramDoublePtr1, int paramInt1, int paramInt2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, DoublePtr paramDoublePtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, int paramInt3, IntPtr paramIntPtr5, int paramInt4, IntPtr paramIntPtr6, IntPtr paramIntPtr7, int paramInt5) {
    classTree__.predictClassTree(paramDoublePtr1, paramInt1, paramInt2, paramIntPtr1, paramIntPtr2, paramDoublePtr2, paramIntPtr3, paramIntPtr4, paramInt3, paramIntPtr5, paramInt4, paramIntPtr6, paramIntPtr7, paramInt5);
  }
  
  public static void computeProximity(DoublePtr paramDoublePtr, int paramInt1, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, int paramInt2) {
    rfutils__.computeProximity(paramDoublePtr, paramInt1, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramInt2);
  }
  
  public static void zeroInt(IntPtr paramIntPtr, int paramInt) {
    rfutils__.zeroInt(paramIntPtr, paramInt);
  }
  
  public static void regRF(DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, IntPtr paramIntPtr11, IntPtr paramIntPtr12, IntPtr paramIntPtr13, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, DoublePtr paramDoublePtr5, DoublePtr paramDoublePtr6, DoublePtr paramDoublePtr7, IntPtr paramIntPtr14, IntPtr paramIntPtr15, IntPtr paramIntPtr16, IntPtr paramIntPtr17, DoublePtr paramDoublePtr8, IntPtr paramIntPtr18, DoublePtr paramDoublePtr9, DoublePtr paramDoublePtr10, IntPtr paramIntPtr19, IntPtr paramIntPtr20, IntPtr paramIntPtr21, DoublePtr paramDoublePtr11, IntPtr paramIntPtr22, DoublePtr paramDoublePtr12, IntPtr paramIntPtr23, DoublePtr paramDoublePtr13, DoublePtr paramDoublePtr14, DoublePtr paramDoublePtr15, DoublePtr paramDoublePtr16, IntPtr paramIntPtr24, IntPtr paramIntPtr25) {
    regrf__.regRF(paramDoublePtr1, paramDoublePtr2, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramIntPtr11, paramIntPtr12, paramIntPtr13, paramDoublePtr3, paramDoublePtr4, paramDoublePtr5, paramDoublePtr6, paramDoublePtr7, paramIntPtr14, paramIntPtr15, paramIntPtr16, paramIntPtr17, paramDoublePtr8, paramIntPtr18, paramDoublePtr9, paramDoublePtr10, paramIntPtr19, paramIntPtr20, paramIntPtr21, paramDoublePtr11, paramIntPtr22, paramDoublePtr12, paramIntPtr23, paramDoublePtr13, paramDoublePtr14, paramDoublePtr15, paramDoublePtr16, paramIntPtr24, paramIntPtr25);
  }
  
  public static void zervr_(DoublePtr paramDoublePtr, IntPtr paramIntPtr) {
    rfsub__.zervr_(paramDoublePtr, paramIntPtr);
  }
  
  public static void catmax_(DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, IntPtr paramIntPtr1, IntPtr paramIntPtr2, DoublePtr paramDoublePtr4, DoublePtr paramDoublePtr5, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6) {
    classTree__.catmax_(paramDoublePtr1, paramDoublePtr2, paramDoublePtr3, paramIntPtr1, paramIntPtr2, paramDoublePtr4, paramDoublePtr5, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6);
  }
  
  public static void findbestsplit_(IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, IntPtr paramIntPtr11, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, IntPtr paramIntPtr12, IntPtr paramIntPtr13, IntPtr paramIntPtr14, DoublePtr paramDoublePtr5, DoublePtr paramDoublePtr6, DoublePtr paramDoublePtr7, IntPtr paramIntPtr15, IntPtr paramIntPtr16) {
    rfsub__.findbestsplit_(paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramDoublePtr1, paramDoublePtr2, paramIntPtr11, paramDoublePtr3, paramDoublePtr4, paramIntPtr12, paramIntPtr13, paramIntPtr14, paramDoublePtr5, paramDoublePtr6, paramDoublePtr7, paramIntPtr15, paramIntPtr16);
  }
  
  public static void zermd_(DoublePtr paramDoublePtr, IntPtr paramIntPtr1, IntPtr paramIntPtr2) {
    rfsub__.zermd_(paramDoublePtr, paramIntPtr1, paramIntPtr2);
  }
  
  public static void makeA(DoublePtr paramDoublePtr, int paramInt1, int paramInt2, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3) {
    rfutils__.makeA(paramDoublePtr, paramInt1, paramInt2, paramIntPtr1, paramIntPtr2, paramIntPtr3);
  }
  
  public static void Xtranslate(DoublePtr paramDoublePtr1, int paramInt1, int paramInt2, int paramInt3, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, DoublePtr paramDoublePtr2, IntPtr paramIntPtr4, IntPtr paramIntPtr5, int paramInt4) {
    rfutils__.Xtranslate(paramDoublePtr1, paramInt1, paramInt2, paramInt3, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramDoublePtr2, paramIntPtr4, paramIntPtr5, paramInt4);
  }
  
  public static void classRF(DoublePtr paramDoublePtr1, IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, IntPtr paramIntPtr11, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, IntPtr paramIntPtr12, IntPtr paramIntPtr13, IntPtr paramIntPtr14, DoublePtr paramDoublePtr4, DoublePtr paramDoublePtr5, DoublePtr paramDoublePtr6, DoublePtr paramDoublePtr7, IntPtr paramIntPtr15, IntPtr paramIntPtr16, IntPtr paramIntPtr17, IntPtr paramIntPtr18, IntPtr paramIntPtr19, IntPtr paramIntPtr20, DoublePtr paramDoublePtr8, DoublePtr paramDoublePtr9, IntPtr paramIntPtr21, DoublePtr paramDoublePtr10, IntPtr paramIntPtr22, IntPtr paramIntPtr23, DoublePtr paramDoublePtr11, IntPtr paramIntPtr24, IntPtr paramIntPtr25, DoublePtr paramDoublePtr12, DoublePtr paramDoublePtr13, IntPtr paramIntPtr26) {
    rf__.classRF(paramDoublePtr1, paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramIntPtr11, paramDoublePtr2, paramDoublePtr3, paramIntPtr12, paramIntPtr13, paramIntPtr14, paramDoublePtr4, paramDoublePtr5, paramDoublePtr6, paramDoublePtr7, paramIntPtr15, paramIntPtr16, paramIntPtr17, paramIntPtr18, paramIntPtr19, paramIntPtr20, paramDoublePtr8, paramDoublePtr9, paramIntPtr21, paramDoublePtr10, paramIntPtr22, paramIntPtr23, paramDoublePtr11, paramIntPtr24, paramIntPtr25, paramDoublePtr12, paramDoublePtr13, paramIntPtr26);
  }
  
  public static void classForest(IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3, IntPtr paramIntPtr4, IntPtr paramIntPtr5, IntPtr paramIntPtr6, DoublePtr paramDoublePtr1, DoublePtr paramDoublePtr2, DoublePtr paramDoublePtr3, DoublePtr paramDoublePtr4, DoublePtr paramDoublePtr5, IntPtr paramIntPtr7, IntPtr paramIntPtr8, IntPtr paramIntPtr9, IntPtr paramIntPtr10, IntPtr paramIntPtr11, IntPtr paramIntPtr12, IntPtr paramIntPtr13, IntPtr paramIntPtr14, IntPtr paramIntPtr15, IntPtr paramIntPtr16, IntPtr paramIntPtr17, DoublePtr paramDoublePtr6, IntPtr paramIntPtr18) {
    rf__.classForest(paramIntPtr1, paramIntPtr2, paramIntPtr3, paramIntPtr4, paramIntPtr5, paramIntPtr6, paramDoublePtr1, paramDoublePtr2, paramDoublePtr3, paramDoublePtr4, paramDoublePtr5, paramIntPtr7, paramIntPtr8, paramIntPtr9, paramIntPtr10, paramIntPtr11, paramIntPtr12, paramIntPtr13, paramIntPtr14, paramIntPtr15, paramIntPtr16, paramIntPtr17, paramDoublePtr6, paramIntPtr18);
  }
  
  public static void unpack_(DoublePtr paramDoublePtr, IntPtr paramIntPtr1, IntPtr paramIntPtr2) {
    rfutils__.unpack_(paramDoublePtr, paramIntPtr1, paramIntPtr2);
  }
  
  public static void rrand_(DoublePtr paramDoublePtr) {
    rf__.rrand_(paramDoublePtr);
  }
  
  public static void zerm_(IntPtr paramIntPtr1, IntPtr paramIntPtr2, IntPtr paramIntPtr3) {
    rfsub__.zerm_(paramIntPtr1, paramIntPtr2, paramIntPtr3);
  }
  
  public static void zermr_(DoublePtr paramDoublePtr, IntPtr paramIntPtr1, IntPtr paramIntPtr2) {
    rfsub__.zermr_(paramDoublePtr, paramIntPtr1, paramIntPtr2);
  }
  
  public static void zerv_(IntPtr paramIntPtr1, IntPtr paramIntPtr2) {
    rfsub__.zerv_(paramIntPtr1, paramIntPtr2);
  }
  
  public static void createClass(DoublePtr paramDoublePtr, int paramInt1, int paramInt2, int paramInt3) {
    rfutils__.createClass(paramDoublePtr, paramInt1, paramInt2, paramInt3);
  }
  
  public static double pack(int paramInt, IntPtr paramIntPtr) {
    return rfutils__.pack(paramInt, paramIntPtr);
  }
  
  public static void modA(IntPtr paramIntPtr1, IntPtr paramIntPtr2, int paramInt1, int paramInt2, IntPtr paramIntPtr3, int paramInt3, IntPtr paramIntPtr4, IntPtr paramIntPtr5) {
    rfutils__.modA(paramIntPtr1, paramIntPtr2, paramInt1, paramInt2, paramIntPtr3, paramInt3, paramIntPtr4, paramIntPtr5);
  }
  
  public static void unpack(double paramDouble, int paramInt, IntPtr paramIntPtr) {
    rfutils__.unpack(paramDouble, paramInt, paramIntPtr);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/randomForest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */