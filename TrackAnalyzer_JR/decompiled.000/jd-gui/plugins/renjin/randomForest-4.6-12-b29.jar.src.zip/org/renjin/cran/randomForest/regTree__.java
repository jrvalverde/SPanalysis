/*     */ package org.renjin.cran.randomForest;
/*     */ 
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gnur.api.Rmath;
/*     */ import org.renjin.gnur.api.S;
/*     */ import org.renjin.gnur.api.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class regTree__
/*     */ {
/*     */   public static void regTree(DoublePtr x, DoublePtr y, int mdim, int nsample, IntPtr lDaughter, IntPtr rDaughter, DoublePtr upper, DoublePtr avnode, IntPtr nodestatus, int nrnodes, IntPtr treeSize, int nthsize, int mtry, IntPtr mbest, IntPtr cat, DoublePtr tgini, IntPtr varUsed) {
/*  37 */     x$array = x.array; x$offset = x.offset; y$array = y.array; y$offset = y.offset; lDaughter$array = lDaughter.array; lDaughter$offset = lDaughter.offset; rDaughter$array = rDaughter.array; rDaughter$offset = rDaughter.offset; upper$array = upper.array; upper$offset = upper.offset; avnode$array = avnode.array; avnode$offset = avnode.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; treeSize$array = treeSize.array; treeSize$offset = treeSize.offset; mbest$array = mbest.array; mbest$offset = mbest.offset; cat$array = cat.array; cat$offset = cat.offset; tgini$array = tgini.array; tgini$offset = tgini.offset; varUsed$array = varUsed.array; varUsed$offset = varUsed.offset; ubest = new double[1]; decsplit = new double[1]; msplit = new int[1]; jstat = new int[1]; ndendl = new int[1]; ubest[0] = 0.0D; msplit[0] = 0; ndendl[0] = 0; ndend = 0; ndstart = 0; nodepop = null; nodepop$offset = 0; nodestart = null; nodestart$offset = 0; jdex = null; jdex$offset = 0; ncur = 0; k = 0; nodestart = new int[nrnodes * 4 / 4]; nodestart$offset = 0;
/*  38 */     nodepop = new int[nrnodes * 4 / 4]; nodepop$offset = 0;
/*     */ 
/*     */     
/*  41 */     rfutils__.zeroInt(new IntPtr(nodestatus$array, nodestatus$offset), nrnodes);
/*  42 */     rfutils__.zeroInt(new IntPtr(nodestart, nodestart$offset), nrnodes);
/*  43 */     rfutils__.zeroInt(new IntPtr(nodepop, nodepop$offset), nrnodes);
/*  44 */     rfutils__.zeroDouble(new DoublePtr(avnode$array, avnode$offset), nrnodes);
/*     */     
/*  46 */     jdex = new int[nsample * 4 / 4]; jdex$offset = 0;
/*  47 */     for (i = 1; i <= nsample; ) { int i1 = (i + -1) * 4, arrayOfInt[] = jdex, n = jdex$offset + i1 / 4; arrayOfInt[n] = i; i++; }
/*     */     
/*  49 */     ncur = 0;
/*  50 */     nodestart[nodestart$offset] = 0;
/*  51 */     nodepop[nodepop$offset] = nsample;
/*  52 */     nodestatus$array[nodestatus$offset] = -2;
/*     */ 
/*     */     
/*  55 */     av = 0.0D;
/*  56 */     ss = 0.0D;
/*  57 */     for (i = 0; i < nsample; i++) {
/*  58 */       int i3 = i * 4, arrayOfInt[] = jdex, i2 = jdex$offset + i3 / 4, i1 = (arrayOfInt[i2] + -1) * 8; double[] arrayOfDouble = y$array; int n = y$offset + i1 / 8; d = arrayOfDouble[n];
/*  59 */       double d8 = i, d7 = av - d, d6 = d8 * d7, d5 = av - d, d4 = d6 * d5, d3 = (i + 1); ss = d4 / d3 + ss;
/*  60 */       double d2 = i * av + d, d1 = (i + 1); av = d2 / d1;
/*     */     } 
/*  62 */     avnode$array[avnode$offset] = av;
/*     */ 
/*     */     
/*  65 */     for (k = 0; nrnodes + -2 > k && 
/*  66 */       k <= ncur && nrnodes + -2 > ncur; k++) {
/*     */       
/*  68 */       int i1 = k * 4, arrayOfInt[] = nodestatus$array, n = nodestatus$offset + i1 / 4; if (arrayOfInt[n] == -2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  75 */         int i9 = k * 4, arrayOfInt3[] = nodestart, i8 = nodestart$offset + i9 / 4; ndstart = arrayOfInt3[i8];
/*  76 */         int i7 = k * 4, arrayOfInt2[] = nodepop, i6 = nodepop$offset + i7 / 4; ndend = arrayOfInt2[i6] + ndstart + -1;
/*  77 */         int i5 = k * 4, arrayOfInt1[] = nodepop, i4 = nodepop$offset + i5 / 4; nodecnt = arrayOfInt1[i4];
/*  78 */         double d2 = nodecnt; int i3 = k * 8; double[] arrayOfDouble = avnode$array; int i2 = avnode$offset + i3 / 8; double d1 = arrayOfDouble[i2]; sumnode = d2 * d1;
/*  79 */         jstat[0] = 0;
/*  80 */         decsplit[0] = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  87 */         findBestSplit(new DoublePtr(x$array, x$offset), new IntPtr(jdex, jdex$offset), new DoublePtr(y$array, y$offset), mdim, nsample, ndstart, ndend, new IntPtr(msplit, 0), new DoublePtr(decsplit, 0), new DoublePtr(ubest, 0), new IntPtr(ndendl, 0), new IntPtr(jstat, 0), mtry, sumnode, nodecnt, new IntPtr(cat$array, cat$offset));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  95 */         if (jstat[0] != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 101 */           int i50 = k * 4, arrayOfInt16[] = mbest$array, i49 = mbest$offset + i50 / 4; msplit$81 = msplit[0]; arrayOfInt16[i49] = msplit$81;
/* 102 */           int i48 = (msplit[0] + -1) * 4, arrayOfInt15[] = varUsed$array, i47 = varUsed$offset + i48 / 4; arrayOfInt15[i47] = 1;
/* 103 */           int i46 = k * 8; double[] arrayOfDouble5 = upper$array; int i45 = upper$offset + i46 / 8; ubest$85 = ubest[0]; arrayOfDouble5[i45] = ubest$85;
/* 104 */           int i44 = (msplit[0] + -1) * 8; double[] arrayOfDouble4 = tgini$array; int i43 = tgini$offset + i44 / 8, i42 = (msplit[0] + -1) * 8; double[] arrayOfDouble3 = tgini$array; int i41 = tgini$offset + i42 / 8; double d4 = arrayOfDouble3[i41]; decsplit$90 = decsplit[0]; double d3 = d4 + decsplit$90; arrayOfDouble4[i43] = d3;
/* 105 */           int i40 = k * 4, arrayOfInt14[] = nodestatus$array, i39 = nodestatus$offset + i40 / 4; arrayOfInt14[i39] = -3;
/*     */ 
/*     */           
/* 108 */           int i38 = (ncur + 1) * 4, arrayOfInt13[] = nodepop, i37 = nodepop$offset + i38 / 4, i36 = ndendl[0] - ndstart + 1; arrayOfInt13[i37] = i36;
/* 109 */           int i35 = (ncur + 2) * 4, arrayOfInt12[] = nodepop, i34 = nodepop$offset + i35 / 4; ndendl$95 = ndendl[0]; int i33 = ndend - ndendl$95; arrayOfInt12[i34] = i33;
/* 110 */           int i32 = (ncur + 1) * 4, arrayOfInt11[] = nodestart, i31 = nodestart$offset + i32 / 4; arrayOfInt11[i31] = ndstart;
/* 111 */           int i30 = (ncur + 2) * 4, arrayOfInt10[] = nodestart, i29 = nodestart$offset + i30 / 4, i28 = ndendl[0] + 1; arrayOfInt10[i29] = i28;
/*     */ 
/*     */           
/* 114 */           av = 0.0D;
/* 115 */           ss = 0.0D;
/* 116 */           j = ndstart; while (true) { ndendl$100 = ndendl[0]; if (j > ndendl$100)
/* 117 */               break;  int i54 = j * 4, arrayOfInt17[] = jdex, i53 = jdex$offset + i54 / 4, i52 = (arrayOfInt17[i53] + -1) * 8; double[] arrayOfDouble6 = y$array; int i51 = y$offset + i52 / 8; d = arrayOfDouble6[i51];
/* 118 */             m = j - ndstart;
/* 119 */             double d12 = m, d11 = av - d, d10 = d12 * d11, d9 = av - d, d8 = d10 * d9, d7 = (m + 1); ss = d8 / d7 + ss;
/* 120 */             double d6 = m * av + d, d5 = (m + 1); av = d6 / d5; j++; }
/*     */           
/* 122 */           int i27 = (ncur + 1) * 8; double[] arrayOfDouble2 = avnode$array; int i26 = avnode$offset + i27 / 8; arrayOfDouble2[i26] = av;
/* 123 */           int i25 = (ncur + 1) * 4, arrayOfInt9[] = nodestatus$array, i24 = nodestatus$offset + i25 / 4; arrayOfInt9[i24] = -2;
/* 124 */           int i23 = (ncur + 1) * 4, arrayOfInt8[] = nodepop, i22 = nodepop$offset + i23 / 4; if (arrayOfInt8[i22] <= nthsize) {
/* 125 */             int i52 = (ncur + 1) * 4, arrayOfInt17[] = nodestatus$array, i51 = nodestatus$offset + i52 / 4; arrayOfInt17[i51] = -1;
/*     */           } 
/*     */ 
/*     */           
/* 129 */           av = 0.0D;
/* 130 */           ss = 0.0D;
/* 131 */           for (j = ndendl[0] + 1; j <= ndend; j++) {
/* 132 */             int i54 = j * 4, arrayOfInt17[] = jdex, i53 = jdex$offset + i54 / 4, i52 = (arrayOfInt17[i53] + -1) * 8; double[] arrayOfDouble6 = y$array; int i51 = y$offset + i52 / 8; d = arrayOfDouble6[i51];
/* 133 */             m = (ndendl[0] ^ 0xFFFFFFFF) + j;
/* 134 */             double d12 = m, d11 = av - d, d10 = d12 * d11, d9 = av - d, d8 = d10 * d9, d7 = (m + 1); ss = d8 / d7 + ss;
/* 135 */             double d6 = m * av + d, d5 = (m + 1); av = d6 / d5;
/*     */           } 
/* 137 */           int i21 = (ncur + 2) * 8; double[] arrayOfDouble1 = avnode$array; int i20 = avnode$offset + i21 / 8; arrayOfDouble1[i20] = av;
/* 138 */           int i19 = (ncur + 2) * 4, arrayOfInt7[] = nodestatus$array, i18 = nodestatus$offset + i19 / 4; arrayOfInt7[i18] = -2;
/* 139 */           int i17 = (ncur + 2) * 4, arrayOfInt6[] = nodepop, i16 = nodepop$offset + i17 / 4; if (arrayOfInt6[i16] <= nthsize) {
/* 140 */             int i52 = (ncur + 2) * 4, arrayOfInt17[] = nodestatus$array, i51 = nodestatus$offset + i52 / 4; arrayOfInt17[i51] = -1;
/*     */           } 
/*     */ 
/*     */           
/* 144 */           int i15 = k * 4, arrayOfInt5[] = lDaughter$array, i14 = lDaughter$offset + i15 / 4, i13 = ncur + 2; arrayOfInt5[i14] = i13;
/* 145 */           int i12 = k * 4, arrayOfInt4[] = rDaughter$array, i11 = rDaughter$offset + i12 / 4, i10 = ncur + 3; arrayOfInt4[i11] = i10;
/*     */           
/* 147 */           ncur += 2;
/*     */         } else {
/*     */           int i11 = k * 4, arrayOfInt4[] = nodestatus$array, i10 = nodestatus$offset + i11 / 4;
/*     */           arrayOfInt4[i10] = -1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     treeSize$array[treeSize$offset] = nrnodes;
/* 155 */     for (k = nrnodes + -1; k >= 0; k--) {
/* 156 */       int i3 = k * 4, arrayOfInt2[] = nodestatus$array, i2 = nodestatus$offset + i3 / 4; if (arrayOfInt2[i2] == 0) { int i4 = treeSize$array[treeSize$offset] - 1; treeSize$array[treeSize$offset] = i4; }
/* 157 */        int i1 = k * 4, arrayOfInt1[] = nodestatus$array, n = nodestatus$offset + i1 / 4; if (arrayOfInt1[n] == -2) {
/* 158 */         int i5 = k * 4, arrayOfInt[] = nodestatus$array, i4 = nodestatus$offset + i5 / 4; arrayOfInt[i4] = -1;
/*     */       } 
/*     */     } 
/* 161 */     nodestart = null; nodestart$offset = 0;
/* 162 */     jdex = null; jdex$offset = 0;
/* 163 */     nodepop = null; nodepop$offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void findBestSplit(DoublePtr x, IntPtr jdex, DoublePtr y, int mdim, int nsample, int ndstart, int ndend, IntPtr msplit, DoublePtr decsplit, DoublePtr ubest, IntPtr ndendl, IntPtr jstat, int mtry, double sumnode, int nodecnt, IntPtr cat) {
/* 176 */     x$array = x.array; x$offset = x.offset; jdex$array = jdex.array; jdex$offset = jdex.offset; y$array = y.array; y$offset = y.offset; msplit$array = msplit.array; msplit$offset = msplit.offset; decsplit$array = decsplit.array; decsplit$offset = decsplit.offset; ubest$array = ubest.array; ubest$offset = ubest.offset; ndendl$array = ndendl.array; ndendl$offset = ndendl.offset; jstat$array = jstat.array; jstat$offset = jstat.offset; cat$array = cat.array; cat$offset = cat.offset; tavcat = new double[53]; avcat = new double[53]; sumcat = new double[53]; icat = new int[53]; ncat = new int[53]; critParent = 0.0D; critvar = 0.0D; critmax = 0.0D; ubestt = 0.0D; yl = null; yl$offset = 0; v = null; v$offset = 0; ut = null; ut$offset = 0; xt = null; xt$offset = 0; ncase = null; ncase$offset = 0; mind = null; mind$offset = 0; kv = 0; i = 0; nr = 0; nl = 0; lc = 0; last = 0; ut = new double[nsample * 8 / 8]; ut$offset = 0;
/* 177 */     xt = new double[nsample * 8 / 8]; xt$offset = 0;
/* 178 */     v = new double[nsample * 8 / 8]; v$offset = 0;
/* 179 */     yl = new double[nsample * 8 / 8]; yl$offset = 0;
/* 180 */     mind = new int[mdim * 4 / 4]; mind$offset = 0;
/* 181 */     ncase = new int[nsample * 4 / 4]; ncase$offset = 0;
/* 182 */     rfutils__.zeroDouble(new DoublePtr(avcat, 0), 53);
/* 183 */     rfutils__.zeroDouble(new DoublePtr(tavcat, 0), 53);
/*     */ 
/*     */     
/* 186 */     msplit$array[msplit$offset] = -1;
/* 187 */     decsplit$array[decsplit$offset] = 0.0D;
/* 188 */     critmax = 0.0D;
/* 189 */     ubestt = 0.0D;
/* 190 */     for (i = 0; i < mdim; ) { int m = i * 4, arrayOfInt[] = mind, k = mind$offset + m / 4; arrayOfInt[k] = i; i++; }
/*     */     
/* 192 */     last = mdim + -1;
/* 193 */     for (i = 0; i < mtry; i++) {
/* 194 */       critvar = 0.0D;
/* 195 */       double d4 = S.unif_rand(), d3 = (last + 1); j = (int)(long)(d4 * d3);
/* 196 */       int i34 = j * 4, arrayOfInt11[] = mind, i33 = mind$offset + i34 / 4; kv = arrayOfInt11[i33];
/* 197 */       int i32 = j * 4, arrayOfInt10[] = mind, i31 = mind$offset + i32 / 4, i30 = j * 4, arrayOfInt9[] = mind, i29 = mind$offset + i30 / 4, i28 = arrayOfInt9[i29], i27 = last * 4, arrayOfInt8[] = mind, i26 = mind$offset + i27 / 4, i25 = arrayOfInt8[i26], i24 = i28 ^ i25; arrayOfInt10[i31] = i24; int i23 = last * 4, arrayOfInt7[] = mind, i22 = mind$offset + i23 / 4, i21 = last * 4, arrayOfInt6[] = mind, i20 = mind$offset + i21 / 4, i19 = arrayOfInt6[i20], i18 = j * 4, arrayOfInt5[] = mind, i17 = mind$offset + i18 / 4, i16 = arrayOfInt5[i17], i15 = i19 ^ i16; arrayOfInt7[i22] = i15; int i14 = j * 4, arrayOfInt4[] = mind, i13 = mind$offset + i14 / 4, i12 = j * 4, arrayOfInt3[] = mind, i11 = mind$offset + i12 / 4, i10 = arrayOfInt3[i11], i9 = last * 4, arrayOfInt2[] = mind, i8 = mind$offset + i9 / 4, i7 = arrayOfInt2[i8], i6 = i10 ^ i7; arrayOfInt4[i13] = i6;
/* 198 */       last--;
/*     */       
/* 200 */       int i5 = kv * 4, arrayOfInt1[] = cat$array, i4 = cat$offset + i5 / 4; lc = arrayOfInt1[i4];
/* 201 */       if (lc != 1)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         rfutils__.zeroInt(new IntPtr(ncat, 0), 53);
/* 210 */         rfutils__.zeroDouble(new DoublePtr(sumcat, 0), 53);
/* 211 */         for (j = ndstart; j <= ndend; j++) {
/* 212 */           int i46 = j * 4, arrayOfInt13[] = jdex$array, i45 = jdex$offset + i46 / 4, i44 = ((arrayOfInt13[i45] + -1) * mdim + kv) * 8; double[] arrayOfDouble4 = x$array; int i43 = x$offset + i44 / 8; l = (int)(long)arrayOfDouble4[i43];
/* 213 */           int i42 = l + -1, i41 = l + -1; double d7 = sumcat[0 + i41]; int i40 = j * 4, arrayOfInt12[] = jdex$array, i39 = jdex$offset + i40 / 4, i38 = (arrayOfInt12[i39] + -1) * 8; double[] arrayOfDouble3 = y$array; int i37 = y$offset + i38 / 8; double d6 = arrayOfDouble3[i37], d5 = d7 + d6; sumcat[0 + i42] = d5;
/* 214 */           int i36 = l + -1, i35 = ncat[0 + i36] + 1; ncat[0 + i36] = i35;
/*     */         } 
/*     */         
/* 217 */         for (j = 0; j < lc; j++) {
/* 218 */           if (ncat[0 + j] == 0) { iftmp$41 = 0.0D; } else { double d6 = sumcat[0 + j], d5 = ncat[0 + j]; iftmp$41 = d6 / d5; }  avcat[0 + j] = iftmp$41;
/*     */         } 
/*     */         
/* 221 */         for (j = 0; j < nsample; j++) {
/* 222 */           int i47 = j * 8; double[] arrayOfDouble6 = xt; int i46 = xt$offset + i47 / 8, i45 = j * 4, arrayOfInt13[] = jdex$array, i44 = jdex$offset + i45 / 4, i43 = ((arrayOfInt13[i44] + -1) * mdim + kv) * 8; double[] arrayOfDouble5 = x$array; int i42 = x$offset + i43 / 8, i41 = (int)(long)arrayOfDouble5[i42] + -1; double d6 = avcat[0 + i41]; arrayOfDouble6[i46] = d6;
/* 223 */           int i40 = j * 8; double[] arrayOfDouble4 = yl; int i39 = yl$offset + i40 / 8, i38 = j * 4, arrayOfInt12[] = jdex$array, i37 = jdex$offset + i38 / 4, i36 = (arrayOfInt12[i37] + -1) * 8; double[] arrayOfDouble3 = y$array; int i35 = y$offset + i36 / 8; double d5 = arrayOfDouble3[i35]; arrayOfDouble4[i39] = d5;
/*     */         }  }
/*     */       else { for (j = ndstart; j <= ndend; j++) { int i46 = j * 8; double[] arrayOfDouble6 = xt; int i45 = xt$offset + i46 / 8, i44 = j * 4, arrayOfInt13[] = jdex$array, i43 = jdex$offset + i44 / 4, i42 = ((arrayOfInt13[i43] + -1) * mdim + kv) * 8; double[] arrayOfDouble5 = x$array; int i41 = x$offset + i42 / 8; double d6 = arrayOfDouble5[i41]; arrayOfDouble6[i45] = d6; int i40 = j * 8; double[] arrayOfDouble4 = yl; int i39 = yl$offset + i40 / 8, i38 = j * 4, arrayOfInt12[] = jdex$array, i37 = jdex$offset + i38 / 4, i36 = (arrayOfInt12[i37] + -1) * 8; double[] arrayOfDouble3 = y$array; int i35 = y$offset + i36 / 8; double d5 = arrayOfDouble3[i35]; arrayOfDouble4[i39] = d5; }
/*     */          }
/* 227 */        for (j = ndstart; j <= ndend; ) { int i38 = j * 8; double[] arrayOfDouble4 = v; int i37 = v$offset + i38 / 8, i36 = j * 8; double[] arrayOfDouble3 = xt; int i35 = xt$offset + i36 / 8; double d5 = arrayOfDouble3[i35]; arrayOfDouble4[i37] = d5; j++; }
/* 228 */        for (j = 1; j <= nsample; ) { int i36 = (j + -1) * 4, arrayOfInt[] = ncase, i35 = ncase$offset + i36 / 4; arrayOfInt[i35] = j; j++; }
/* 229 */        int i3 = ndend + 1, i2 = ndstart + 1; Utils.R_qsort_I(new DoublePtr(v, v$offset), new IntPtr(ncase, ncase$offset), i2, i3);
/* 230 */       int i1 = ndstart * 8; double[] arrayOfDouble2 = v; int n = v$offset + i1 / 8; double d2 = arrayOfDouble2[n]; int m = ndend * 8; double[] arrayOfDouble1 = v; int k = v$offset + m / 8; double d1 = arrayOfDouble1[k]; if (((d2 < d1) ? false : true) == false) {
/*     */ 
/*     */         
/* 233 */         double d6 = sumnode * sumnode, d5 = nodecnt; critParent = d6 / d5;
/* 234 */         suml = 0.0D;
/* 235 */         sumr = sumnode;
/* 236 */         npopl = 0;
/* 237 */         npopr = nodecnt;
/* 238 */         crit = 0.0D;
/*     */         
/* 240 */         j = ndstart;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     decsplit$array[decsplit$offset] = critmax;
/*     */ 
/*     */     
/* 270 */     if (msplit$array[msplit$offset] == -1)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       jstat$array[jstat$offset] = 1; } else { nl = ndstart; for (j = ndstart; j <= ndend; j++) { int i2 = j * 8; double[] arrayOfDouble = ut; int i1 = ut$offset + i2 / 8; double d2 = arrayOfDouble[i1], d1 = ubest$array[ubest$offset]; if (((d2 > d1) ? false : true) != false) { nl++; int i7 = (nl + -1) * 4, arrayOfInt2[] = ncase, i6 = ncase$offset + i7 / 4, i5 = j * 4, arrayOfInt1[] = jdex$array, i4 = jdex$offset + i5 / 4, i3 = arrayOfInt1[i4]; arrayOfInt2[i6] = i3; }  }  int n = Rmath.Rf_imax2(nl + -1, ndstart); ndendl$array[ndendl$offset] = n; nr = ndendl$array[ndendl$offset] + 1; for (j = ndstart; j <= ndend; j++) { int i2 = j * 8; double[] arrayOfDouble = ut; int i1 = ut$offset + i2 / 8; double d2 = arrayOfDouble[i1], d1 = ubest$array[ubest$offset]; if (((d2 <= d1) ? false : true) != false)
/*     */           if (nr < nsample) { nr++; int i7 = (nr + -1) * 4, arrayOfInt2[] = ncase, i6 = ncase$offset + i7 / 4, i5 = j * 4, arrayOfInt1[] = jdex$array, i4 = jdex$offset + i5 / 4, i3 = arrayOfInt1[i4]; arrayOfInt2[i6] = i3; } else { break; }   }  if (ndendl$array[ndendl$offset] >= ndend) { int i1 = ndend + -1; ndendl$array[ndendl$offset] = i1; }  for (j = ndstart; j <= ndend; ) { int i5 = j * 4, arrayOfInt2[] = jdex$array, i4 = jdex$offset + i5 / 4, i3 = j * 4, arrayOfInt1[] = ncase, i2 = ncase$offset + i3 / 4, i1 = arrayOfInt1[i2]; arrayOfInt2[i4] = i1; j++; }  int m = (msplit$array[msplit$offset] + -1) * 4, arrayOfInt[] = cat$array, k = cat$offset + m / 4; lc = arrayOfInt[k]; if (lc > 1) { for (j = 0; j < lc; j++) { double d3 = tavcat[0 + j], d2 = ubest$array[ubest$offset]; boolean bool = (d3 >= d2) ? false : true; icat[0 + j] = bool; }  double d1 = rfutils__.pack(lc, new IntPtr(icat, 0)); ubest$array[ubest$offset] = d1; }  }
/* 299 */      ncase = null; ncase$offset = 0;
/* 300 */     mind = null; mind$offset = 0;
/* 301 */     v = null; v$offset = 0;
/* 302 */     yl = null; yl$offset = 0;
/* 303 */     xt = null; xt$offset = 0;
/* 304 */     ut = null; ut$offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void predictRegTree(DoublePtr x, int nsample, int mdim, IntPtr lDaughter, IntPtr rDaughter, IntPtr nodestatus, DoublePtr ypred, DoublePtr split, DoublePtr nodepred, IntPtr splitVar, int treeSize, IntPtr cat, int maxcat, IntPtr nodex) {
/* 317 */     x$array = x.array; x$offset = x.offset; lDaughter$array = lDaughter.array; lDaughter$offset = lDaughter.offset; rDaughter$array = rDaughter.array; rDaughter$offset = rDaughter.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; ypred$array = ypred.array; ypred$offset = ypred.offset; split$array = split.array; split$offset = split.offset; nodepred$array = nodepred.array; nodepred$offset = nodepred.offset; splitVar$array = splitVar.array; splitVar$offset = splitVar.offset; cat$array = cat.array; cat$offset = cat.offset; nodex$array = nodex.array; nodex$offset = nodex.offset; cbestsplit = null; cbestsplit$offset = 0; i = 0; if (maxcat > 1) {
/* 318 */       cbestsplit = new int[maxcat * treeSize * 4 / 4]; cbestsplit$offset = 0;
/* 319 */       int n = maxcat * treeSize; rfutils__.zeroInt(new IntPtr(cbestsplit, cbestsplit$offset), n);
/* 320 */       for (i = 0; i < treeSize; i++) {
/* 321 */         int i2 = i * 4, arrayOfInt[] = nodestatus$array, i1 = nodestatus$offset + i2 / 4; if (arrayOfInt[i1] != -1) { int i6 = i * 4, arrayOfInt2[] = splitVar$array, i5 = splitVar$offset + i6 / 4, i4 = (arrayOfInt2[i5] + -1) * 4, arrayOfInt1[] = cat$array, i3 = cat$offset + i4 / 4; if (arrayOfInt1[i3] > 1) {
/* 322 */             int i8 = i * 8; double[] arrayOfDouble = split$array; int i7 = split$offset + i8 / 8; dpack = arrayOfDouble[i7];
/*     */ 
/*     */             
/* 325 */             j = 0; while (true) { int i12 = i * 4, arrayOfInt4[] = splitVar$array, i11 = splitVar$offset + i12 / 4, i10 = (arrayOfInt4[i11] + -1) * 4, arrayOfInt3[] = cat$array, i9 = cat$offset + i10 / 4; if (arrayOfInt3[i9] <= j)
/* 326 */                 break;  int i15 = (i * maxcat + j) * 4, arrayOfInt5[] = cbestsplit, i14 = cbestsplit$offset + i15 / 4, i13 = (int)(long)dpack & 0x1; arrayOfInt5[i14] = i13;
/* 327 */               dpack /= 2.0D;
/*     */               j++; }
/*     */           
/*     */           }  }
/*     */       
/*     */       } 
/*     */     } 
/* 334 */     for (i = 0; i < nsample; i++) {
/* 335 */       k = 0; while (true) {
/* 336 */         int i8 = k * 4, arrayOfInt1[] = nodestatus$array, i7 = nodestatus$offset + i8 / 4; if (arrayOfInt1[i7] == -1)
/* 337 */           break;  int i16 = k * 4, arrayOfInt3[] = splitVar$array, i15 = splitVar$offset + i16 / 4; m = arrayOfInt3[i15] + -1;
/* 338 */         int i14 = m * 4, arrayOfInt2[] = cat$array, i13 = cat$offset + i14 / 4; if (arrayOfInt2[i13] != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 343 */           int i22 = (i * mdim + m) * 8; double[] arrayOfDouble = x$array; int i21 = x$offset + i22 / 8, i20 = (int)(long)arrayOfDouble[i21] + -1, i19 = k * maxcat, i18 = (i20 + i19) * 4, arrayOfInt4[] = cbestsplit, i17 = cbestsplit$offset + i18 / 4; if (arrayOfInt4[i17] == 
/* 344 */             0) { int i24 = k * 4, arrayOfInt5[] = rDaughter$array, i23 = rDaughter$offset + i24 / 4; iftmp$10 = arrayOfInt5[i23] + -1; } else { int i24 = k * 4, arrayOfInt5[] = lDaughter$array, i23 = lDaughter$offset + i24 / 4; iftmp$10 = arrayOfInt5[i23] + -1; }  k = iftmp$10; continue;
/*     */         }  int i12 = (i * mdim + m) * 8; double[] arrayOfDouble4 = x$array; int i11 = x$offset + i12 / 8; double d2 = arrayOfDouble4[i11]; int i10 = k * 8; double[] arrayOfDouble3 = split$array; int i9 = split$offset + i10 / 8; double d1 = arrayOfDouble3[i9]; if (((d2 > d1) ? false : true) == false) { int i18 = k * 4, arrayOfInt4[] = rDaughter$array, i17 = rDaughter$offset + i18 / 4; iftmp$6 = arrayOfInt4[i17] + -1; }
/*     */         else { int i18 = k * 4, arrayOfInt4[] = lDaughter$array, i17 = lDaughter$offset + i18 / 4; iftmp$6 = arrayOfInt4[i17] + -1; }
/*     */          k = iftmp$6;
/* 348 */       }  int i6 = i * 8; double[] arrayOfDouble2 = ypred$array; int i5 = ypred$offset + i6 / 8, i4 = k * 8; double[] arrayOfDouble1 = nodepred$array; int i3 = nodepred$offset + i4 / 8; double d = arrayOfDouble1[i3]; arrayOfDouble2[i5] = d;
/* 349 */       int i2 = i * 4, arrayOfInt[] = nodex$array, i1 = nodex$offset + i2 / 4, n = k + 1; arrayOfInt[i1] = n;
/*     */     } 
/* 351 */     if (maxcat > 1) { cbestsplit = null; cbestsplit$offset = 0; }
/*     */   
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/regTree__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */