/*     */ package org.renjin.cran.randomForest;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Mathlib;
/*     */ import org.renjin.gnur.api.Print;
/*     */ import org.renjin.gnur.api.Random;
/*     */ import org.renjin.gnur.api.S;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class regrf__
/*     */ {
/*     */   public static void regRF(DoublePtr x, DoublePtr y, IntPtr xdim, IntPtr sampsize, IntPtr nthsize, IntPtr nrnodes, IntPtr nTree, IntPtr mtry, IntPtr imp, IntPtr cat, IntPtr maxcat, IntPtr jprint, IntPtr doProx, IntPtr oobprox, IntPtr biasCorr, DoublePtr yptr, DoublePtr errimp, DoublePtr impmat, DoublePtr impSD, DoublePtr prox, IntPtr treeSize, IntPtr nodestatus, IntPtr lDaughter, IntPtr rDaughter, DoublePtr avnode, IntPtr mbest, DoublePtr upper, DoublePtr mse, IntPtr keepf, IntPtr replace, IntPtr testdat, DoublePtr xts, IntPtr nts, DoublePtr yts, IntPtr labelts, DoublePtr yTestPred, DoublePtr proxts, DoublePtr msets, DoublePtr coef, IntPtr nout, IntPtr inbag) {
/*  52 */     x$array = x.array; x$offset = x.offset; y$array = y.array; y$offset = y.offset; xdim$array = xdim.array; xdim$offset = xdim.offset; sampsize$array = sampsize.array; sampsize$offset = sampsize.offset; nthsize$array = nthsize.array; nthsize$offset = nthsize.offset; nrnodes$array = nrnodes.array; nrnodes$offset = nrnodes.offset; nTree$array = nTree.array; nTree$offset = nTree.offset; mtry$array = mtry.array; mtry$offset = mtry.offset; imp$array = imp.array; imp$offset = imp.offset; cat$array = cat.array; cat$offset = cat.offset; maxcat$array = maxcat.array; maxcat$offset = maxcat.offset; jprint$array = jprint.array; jprint$offset = jprint.offset; doProx$array = doProx.array; doProx$offset = doProx.offset; oobprox$array = oobprox.array; oobprox$offset = oobprox.offset; biasCorr$array = biasCorr.array; biasCorr$offset = biasCorr.offset; yptr$array = yptr.array; yptr$offset = yptr.offset; errimp$array = errimp.array; errimp$offset = errimp.offset; impmat$array = impmat.array; impmat$offset = impmat.offset; impSD$array = impSD.array; impSD$offset = impSD.offset; prox$array = prox.array; prox$offset = prox.offset; treeSize$array = treeSize.array; treeSize$offset = treeSize.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; lDaughter$array = lDaughter.array; lDaughter$offset = lDaughter.offset; rDaughter$array = rDaughter.array; rDaughter$offset = rDaughter.offset; avnode$array = avnode.array; avnode$offset = avnode.offset; mbest$array = mbest.array; mbest$offset = mbest.offset; upper$array = upper.array; upper$offset = upper.offset; mse$array = mse.array; mse$offset = mse.offset; keepf$array = keepf.array; keepf$offset = keepf.offset; replace$array = replace.array; replace$offset = replace.offset; testdat$array = testdat.array; testdat$offset = testdat.offset; xts$array = xts.array; xts$offset = xts.offset; nts$array = nts.array; nts$offset = nts.offset; yts$array = yts.array; yts$offset = yts.offset; labelts$array = labelts.array; labelts$offset = labelts.offset; yTestPred$array = yTestPred.array; yTestPred$offset = yTestPred.offset; proxts$array = proxts.array; proxts$offset = proxts.offset; msets$array = msets.array; msets$offset = msets.offset; coef$array = coef.array; coef$offset = coef.offset; nout$array = nout.array; nout$offset = nout.offset; inbag$array = inbag.array; inbag$offset = inbag.offset; errb = new double[1]; nodexts = null; nodexts$offset = 0; nodex = null; nodex$offset = 0; nind = null; nind$offset = 0; in = null; in$offset = 0; varUsed = null; varUsed$offset = 0; localImp = 0; varImp = 0; oobpair = null; oobpair$offset = 0; keepInbag = 0; keepF = 0; mdim = 0; nsample = 0; nPerm = 0; last = 0; ntest = 0; idx = 0; jout = 0; j = 0; nOOB = 0; n = 0; mr = 0; m = 0; k = 0; tgini = null; tgini$offset = 0; ytree = null; ytree$offset = 0; ytr = null; ytr$offset = 0; xb = null; xb$offset = 0; xtmp = null; xtmp$offset = 0; yb = null; yb$offset = 0; resOOB = null; resOOB$offset = 0; ooberrperm = 0.0D; ooberr = 0.0D; errb[0] = 0.0D; varYts = 0.0D; varY = 0.0D; errts = 0.0D; errts = 0.0D;
/*  53 */     errb[0] = 0.0D; resid = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     nsample = xdim$array[xdim$offset];
/*  64 */     mdim = xdim$array[xdim$offset + 1];
/*  65 */     ntest = nts$array[nts$offset];
/*  66 */     varImp = imp$array[imp$offset];
/*  67 */     localImp = imp$array[imp$offset + 1];
/*  68 */     nPerm = imp$array[imp$offset + 2];
/*  69 */     keepF = keepf$array[keepf$offset];
/*  70 */     keepInbag = keepf$array[keepf$offset + 1];
/*     */     
/*  72 */     if (jprint$array[jprint$offset] == 0) { int i2 = nTree$array[nTree$offset] + 1; jprint$array[jprint$offset] = i2; }
/*     */     
/*  74 */     yb = new double[sampsize$array[sampsize$offset] * 8 / 8]; yb$offset = 0;
/*  75 */     xb = new double[sampsize$array[sampsize$offset] * mdim * 8 / 8]; xb$offset = 0;
/*  76 */     ytr = new double[nsample * 8 / 8]; ytr$offset = 0;
/*  77 */     xtmp = new double[nsample * 8 / 8]; xtmp$offset = 0;
/*  78 */     resOOB = new double[nsample * 8 / 8]; resOOB$offset = 0;
/*     */     
/*  80 */     in = new int[nsample * 4 / 4]; in$offset = 0;
/*  81 */     nodex = new int[nsample * 4 / 4]; nodex$offset = 0;
/*  82 */     varUsed = new int[mdim * 4 / 4]; varUsed$offset = 0;
/*  83 */     if (replace$array[replace$offset] != 0) { iftmp$30 = null; iftmp$30$offset = 0; } else { iftmp$30 = new int[nsample * 4 / 4]; iftmp$30$offset = 0; }  nind = iftmp$30; nind$offset = iftmp$30$offset;
/*     */     
/*  85 */     if (testdat$array[testdat$offset] != 0) {
/*  86 */       ytree = new double[ntest * 8 / 8]; ytree$offset = 0;
/*  87 */       nodexts = new int[ntest * 4 / 4]; nodexts$offset = 0;
/*     */     } 
/*  89 */     if (doProx$array[doProx$offset] == 
/*  90 */       0 || oobprox$array[oobprox$offset] == 0) { iftmp$34 = null; iftmp$34$offset = 0; } else { iftmp$34 = new int[nsample * nsample * 4 / 4]; iftmp$34$offset = 0; }
/*     */     
/*     */     oobpair = iftmp$34;
/*     */     oobpair$offset = iftmp$34$offset;
/*  94 */     if (varImp == 0) { iftmp$35 = errimp$array; iftmp$35$offset = errimp$offset; } else { int i2 = mdim * 8; iftmp$35 = errimp$array; iftmp$35$offset = errimp$offset + i2 / 8; }  tgini = iftmp$35; tgini$offset = iftmp$35$offset;
/*     */     
/*  96 */     averrb = 0.0D;
/*  97 */     meanY = 0.0D;
/*  98 */     varY = 0.0D;
/*     */     
/* 100 */     rfutils__.zeroDouble(new DoublePtr(yptr$array, yptr$offset), nsample);
/* 101 */     rfutils__.zeroInt(new IntPtr(nout$array, nout$offset), nsample);
/* 102 */     for (n = 0; n < nsample; n++) {
/* 103 */       double d10 = n; int i7 = n * 8; double[] arrayOfDouble3 = y$array; int i6 = y$offset + i7 / 8; double d9 = arrayOfDouble3[i6] - meanY, d8 = d10 * d9; int i5 = n * 8; double[] arrayOfDouble2 = y$array; int i4 = y$offset + i5 / 8; double d7 = arrayOfDouble2[i4] - meanY, d6 = d8 * d7, d5 = (n + 1); varY = d6 / d5 + varY;
/* 104 */       double d4 = n * meanY; int i3 = n * 8; double[] arrayOfDouble1 = y$array; int i2 = y$offset + i3 / 8; double d3 = arrayOfDouble1[i2], d2 = d4 + d3, d1 = (n + 1); meanY = d2 / d1;
/*     */     } 
/* 106 */     double d = nsample; varY /= d;
/*     */     
/* 108 */     varYts = 0.0D;
/* 109 */     meanYts = 0.0D;
/* 110 */     if (testdat$array[testdat$offset] != 0) {
/* 111 */       for (n = 0; n < ntest; n++) {
/* 112 */         double d11 = n; int i7 = n * 8; double[] arrayOfDouble3 = yts$array; int i6 = yts$offset + i7 / 8; double d10 = arrayOfDouble3[i6] - meanYts, d9 = d11 * d10; int i5 = n * 8; double[] arrayOfDouble2 = yts$array; int i4 = yts$offset + i5 / 8; double d8 = arrayOfDouble2[i4] - meanYts, d7 = d9 * d8, d6 = (n + 1); varYts = d7 / d6 + varYts;
/* 113 */         double d5 = n * meanYts; int i3 = n * 8; double[] arrayOfDouble1 = yts$array; int i2 = yts$offset + i3 / 8; double d4 = arrayOfDouble1[i2], d3 = d5 + d4, d2 = (n + 1); meanYts = d3 / d2;
/*     */       } 
/* 115 */       double d1 = ntest; varYts /= d1;
/*     */     } 
/*     */     
/* 118 */     if (doProx$array[doProx$offset] != 0) {
/* 119 */       int i2 = nsample * nsample; rfutils__.zeroDouble(new DoublePtr(prox$array, prox$offset), i2);
/* 120 */       if (testdat$array[testdat$offset] != 0) { int i3 = (nsample + ntest) * ntest; rfutils__.zeroDouble(new DoublePtr(proxts$array, proxts$offset), i3); }
/*     */     
/*     */     } 
/* 123 */     if (varImp == 0)
/*     */     
/*     */     { 
/*     */       
/* 127 */       rfutils__.zeroDouble(new DoublePtr(errimp$array, errimp$offset), mdim); } else { int i2 = mdim * 2; rfutils__.zeroDouble(new DoublePtr(errimp$array, errimp$offset), i2); if (localImp != 0) { int i3 = nsample * mdim; rfutils__.zeroDouble(new DoublePtr(impmat$array, impmat$offset), i3); }
/*     */        }
/* 129 */      if (labelts$array[labelts$offset] != 0) rfutils__.zeroDouble(new DoublePtr(yTestPred$array, yTestPred$offset), ntest);
/*     */ 
/*     */     
/* 132 */     int i1 = jprint$array[jprint$offset], i = nTree$array[nTree$offset]; if (i1 <= i) {
/* 133 */       Print.Rprintf(new BytePtr("     |      Out-of-bag   \000".getBytes(), 0), new Object[0]);
/* 134 */       if (testdat$array[testdat$offset] != 0) Print.Rprintf(new BytePtr("|       Test set    \000".getBytes(), 0), new Object[0]); 
/* 135 */       Print.Rprintf(new BytePtr("|\n\000".getBytes(), 0), new Object[0]);
/* 136 */       Print.Rprintf(new BytePtr("Tree |      MSE  %%Var(y) \000".getBytes(), 0), new Object[0]);
/* 137 */       if (testdat$array[testdat$offset] != 0) Print.Rprintf(new BytePtr("|      MSE  %%Var(y) \000".getBytes(), 0), new Object[0]); 
/* 138 */       Print.Rprintf(new BytePtr("|\n\000".getBytes(), 0), new Object[0]);
/*     */     } 
/* 140 */     Random.GetRNGstate();
/*     */ 
/*     */ 
/*     */     
/* 144 */     for (j = 0; nTree$array[nTree$offset] > j; j++) {
/* 145 */       if (keepF == 0) { iftmp$43 = 0; } else { iftmp$43 = nrnodes$array[nrnodes$offset] * j; }  idx = iftmp$43;
/* 146 */       rfutils__.zeroInt(new IntPtr(in, in$offset), nsample);
/* 147 */       rfutils__.zeroInt(new IntPtr(varUsed, varUsed$offset), mdim);
/*     */       
/* 149 */       if (replace$array[replace$offset] == 0)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 160 */         for (n = 0; n < nsample; ) { int i41 = n * 4, arrayOfInt[] = nind, i40 = nind$offset + i41 / 4; arrayOfInt[i40] = n; n++; }
/* 161 */          last = nsample + -1;
/* 162 */         for (n = 0; sampsize$array[sampsize$offset] > n; n++)
/* 163 */         { double d4 = S.unif_rand(), d3 = (last + 1); ktmp = (int)(long)(d4 * d3);
/* 164 */           int i77 = ktmp * 4, arrayOfInt22[] = nind, i76 = nind$offset + i77 / 4; k = arrayOfInt22[i76];
/* 165 */           int i75 = ktmp * 4, arrayOfInt21[] = nind, i74 = nind$offset + i75 / 4, i73 = ktmp * 4, arrayOfInt20[] = nind, i72 = nind$offset + i73 / 4, i71 = arrayOfInt20[i72], i70 = last * 4, arrayOfInt19[] = nind, i69 = nind$offset + i70 / 4, i68 = arrayOfInt19[i69], i67 = i71 ^ i68; arrayOfInt21[i74] = i67; int i66 = last * 4, arrayOfInt18[] = nind, i65 = nind$offset + i66 / 4, i64 = last * 4, arrayOfInt17[] = nind, i63 = nind$offset + i64 / 4, i62 = arrayOfInt17[i63], i61 = ktmp * 4, arrayOfInt16[] = nind, i60 = nind$offset + i61 / 4, i59 = arrayOfInt16[i60], i58 = i62 ^ i59; arrayOfInt18[i65] = i58; int i57 = ktmp * 4, arrayOfInt15[] = nind, i56 = nind$offset + i57 / 4, i55 = ktmp * 4, arrayOfInt14[] = nind, i54 = nind$offset + i55 / 4, i53 = arrayOfInt14[i54], i52 = last * 4, arrayOfInt13[] = nind, i51 = nind$offset + i52 / 4, i50 = arrayOfInt13[i51], i49 = i53 ^ i50; arrayOfInt15[i56] = i49;
/* 166 */           last--;
/* 167 */           int i48 = k * 4, arrayOfInt12[] = in, i47 = in$offset + i48 / 4, i46 = k * 4, arrayOfInt11[] = in, i45 = in$offset + i46 / 4, i44 = arrayOfInt11[i45] + 1; arrayOfInt12[i47] = i44;
/* 168 */           int i43 = n * 8; double[] arrayOfDouble7 = yb; int i42 = yb$offset + i43 / 8, i41 = k * 8; double[] arrayOfDouble6 = y$array; int i40 = y$offset + i41 / 8; double d2 = arrayOfDouble6[i40]; arrayOfDouble7[i42] = d2;
/* 169 */           for (m = 0; m < mdim; m++)
/* 170 */           { int i81 = (n * mdim + m) * 8; double[] arrayOfDouble9 = xb; int i80 = xb$offset + i81 / 8, i79 = (k * mdim + m) * 8; double[] arrayOfDouble8 = x$array; int i78 = x$offset + i79 / 8; double d5 = arrayOfDouble8[i78]; arrayOfDouble9[i80] = d5; }  }  }
/*     */       else { for (n = 0; sampsize$array[sampsize$offset] > n; n++) { xrand = S.unif_rand(); k = (int)(long)(nsample * xrand); int i48 = k * 4, arrayOfInt12[] = in, i47 = in$offset + i48 / 4, i46 = k * 4, arrayOfInt11[] = in, i45 = in$offset + i46 / 4, i44 = arrayOfInt11[i45] + 1; arrayOfInt12[i47] = i44; int i43 = n * 8; double[] arrayOfDouble7 = yb; int i42 = yb$offset + i43 / 8, i41 = k * 8; double[] arrayOfDouble6 = y$array; int i40 = y$offset + i41 / 8; double d2 = arrayOfDouble6[i40]; arrayOfDouble7[i42] = d2; for (m = 0; m < mdim; m++) { int i52 = (n * mdim + m) * 8; double[] arrayOfDouble9 = xb; int i51 = xb$offset + i52 / 8, i50 = (k * mdim + m) * 8; double[] arrayOfDouble8 = x$array; int i49 = x$offset + i50 / 8; double d3 = arrayOfDouble8[i49]; arrayOfDouble9[i51] = d3; }
/*     */            }
/*     */          }
/* 174 */        if (keepInbag != 0) {
/* 175 */         for (n = 0; n < nsample; ) { int i44 = (j * nsample + n) * 4, arrayOfInt12[] = inbag$array, i43 = inbag$offset + i44 / 4, i42 = n * 4, arrayOfInt11[] = in, i41 = in$offset + i42 / 4, i40 = arrayOfInt11[i41]; arrayOfInt12[i43] = i40; n++; }
/*     */       
/*     */       }
/*     */ 
/*     */       
/* 180 */       int i39 = idx * 4; int arrayOfInt10[] = mbest$array, i38 = mbest$offset + i39 / 4, i37 = mtry$array[mtry$offset], i36 = nthsize$array[nthsize$offset]; int i35 = j * 4; int arrayOfInt9[] = treeSize$array, i34 = treeSize$offset + i35 / 4, i33 = nrnodes$array[nrnodes$offset]; int i32 = idx * 4; int arrayOfInt8[] = nodestatus$array, i31 = nodestatus$offset + i32 / 4; int i30 = idx * 8; double[] arrayOfDouble5 = avnode$array; int i29 = avnode$offset + i30 / 8; int i28 = idx * 8;
/*     */       double[] arrayOfDouble4 = upper$array;
/*     */       int i27 = upper$offset + i28 / 8, i26 = idx * 4, arrayOfInt7[] = rDaughter$array, i25 = rDaughter$offset + i26 / 4, i24 = idx * 4, arrayOfInt6[] = lDaughter$array, i23 = lDaughter$offset + i24 / 4, i22 = sampsize$array[sampsize$offset];
/*     */       regTree__.regTree(new DoublePtr(xb, xb$offset), new DoublePtr(yb, yb$offset), mdim, i22, new IntPtr(arrayOfInt6, i23), new IntPtr(arrayOfInt7, i25), new DoublePtr(arrayOfDouble4, i27), new DoublePtr(arrayOfDouble5, i29), new IntPtr(arrayOfInt8, i31), i33, new IntPtr(arrayOfInt9, i34), i36, i37, new IntPtr(arrayOfInt10, i38), new IntPtr(cat$array, cat$offset), new DoublePtr(tgini, tgini$offset), new IntPtr(varUsed, varUsed$offset));
/* 184 */       int i21 = maxcat$array[maxcat$offset];
/*     */       
/* 186 */       int i20 = j * 4, arrayOfInt5[] = treeSize$array, i19 = treeSize$offset + i20 / 4; int i18 = arrayOfInt5[i19]; int i17 = idx * 4; int arrayOfInt4[] = mbest$array, i16 = mbest$offset + i17 / 4; int i15 = idx * 8; double[] arrayOfDouble3 = avnode$array; int i14 = avnode$offset + i15 / 8; int i13 = idx * 8; double[] arrayOfDouble2 = upper$array; int i12 = upper$offset + i13 / 8; int i11 = idx * 4; int arrayOfInt3[] = nodestatus$array, i10 = nodestatus$offset + i11 / 4; int i9 = idx * 4;
/*     */       int arrayOfInt2[] = rDaughter$array, i8 = rDaughter$offset + i9 / 4, i7 = idx * 4, arrayOfInt1[] = lDaughter$array, i6 = lDaughter$offset + i7 / 4;
/*     */       regTree__.predictRegTree(new DoublePtr(x$array, x$offset), nsample, mdim, new IntPtr(arrayOfInt1, i6), new IntPtr(arrayOfInt2, i8), new IntPtr(arrayOfInt3, i10), new DoublePtr(ytr, ytr$offset), new DoublePtr(arrayOfDouble2, i12), new DoublePtr(arrayOfDouble3, i14), new IntPtr(arrayOfInt4, i16), i18, new IntPtr(cat$array, cat$offset), i21, new IntPtr(nodex, nodex$offset));
/* 189 */       errb[0] = 0.0D;
/* 190 */       ooberr = 0.0D;
/* 191 */       jout = 0;
/* 192 */       nOOB = 0;
/* 193 */       for (n = 0; n < nsample; n++) {
/* 194 */         int i43 = n * 4, arrayOfInt12[] = in, i42 = in$offset + i43 / 4; if (arrayOfInt12[i42] == 0) {
/* 195 */           int i66 = n * 4, arrayOfInt15[] = nout$array, i65 = nout$offset + i66 / 4, i64 = arrayOfInt15[i65] + 1; arrayOfInt15[i65] = i64;
/* 196 */           nOOB++;
/* 197 */           int i63 = n * 8; double[] arrayOfDouble13 = yptr$array; int i62 = yptr$offset + i63 / 8, i61 = n * 4, arrayOfInt14[] = nout$array, i60 = nout$offset + i61 / 4; double d13 = (arrayOfInt14[i60] + -1); int i59 = n * 8; double[] arrayOfDouble12 = yptr$array; int i58 = yptr$offset + i59 / 8; double d12 = arrayOfDouble12[i58], d11 = d13 * d12; int i57 = n * 8; double[] arrayOfDouble11 = ytr; int i56 = ytr$offset + i57 / 8; double d10 = arrayOfDouble11[i56], d9 = d11 + d10; int i55 = n * 4, arrayOfInt13[] = nout$array, i54 = nout$offset + i55 / 4; double d8 = arrayOfInt13[i54], d7 = d9 / d8; arrayOfDouble13[i62] = d7;
/* 198 */           int i53 = n * 8; double[] arrayOfDouble10 = resOOB; int i52 = resOOB$offset + i53 / 8, i51 = n * 8; double[] arrayOfDouble9 = ytr; int i50 = ytr$offset + i51 / 8; double d6 = arrayOfDouble9[i50]; int i49 = n * 8; double[] arrayOfDouble8 = y$array; int i48 = y$offset + i49 / 8; double d5 = arrayOfDouble8[i48], d4 = d6 - d5; arrayOfDouble10[i52] = d4;
/* 199 */           int i47 = n * 8; double[] arrayOfDouble7 = resOOB; int i46 = resOOB$offset + i47 / 8; double d3 = arrayOfDouble7[i46]; int i45 = n * 8; double[] arrayOfDouble6 = resOOB; int i44 = resOOB$offset + i45 / 8; double d2 = arrayOfDouble6[i44]; ooberr = d3 * d2 + ooberr;
/*     */         } 
/* 201 */         int i41 = n * 4, arrayOfInt11[] = nout$array, i40 = nout$offset + i41 / 4; if (arrayOfInt11[i40] != 0) {
/* 202 */           jout++;
/* 203 */           int i51 = n * 8; double[] arrayOfDouble9 = y$array; int i50 = y$offset + i51 / 8; double d8 = arrayOfDouble9[i50]; int i49 = n * 8; double[] arrayOfDouble8 = yptr$array; int i48 = yptr$offset + i49 / 8; double d7 = arrayOfDouble8[i48], d6 = d8 - d7; int i47 = n * 8; double[] arrayOfDouble7 = y$array; int i46 = y$offset + i47 / 8; double d5 = arrayOfDouble7[i46]; int i45 = n * 8; double[] arrayOfDouble6 = yptr$array; int i44 = yptr$offset + i45 / 8; double d4 = arrayOfDouble6[i44], d3 = d5 - d4, d2 = d6 * d3; errb$95 = errb[0]; errb$96 = d2 + errb$95; errb[0] = errb$96;
/*     */         } 
/*     */       } 
/* 206 */       errb$97 = errb[0]; double d1 = jout; errb$98 = errb$97 / d1; errb[0] = errb$98;
/*     */       
/* 208 */       if (biasCorr$array[biasCorr$offset] != 0) simpleLinReg(nsample, new DoublePtr(yptr$array, yptr$offset), new DoublePtr(y$array, y$offset), new DoublePtr(coef$array, coef$offset), new DoublePtr(errb, 0), new IntPtr(nout$array, nout$offset));
/*     */ 
/*     */       
/* 211 */       if (testdat$array[testdat$offset] != 0) {
/* 212 */         int i55 = maxcat$array[maxcat$offset];
/*     */ 
/*     */         
/* 215 */         int i54 = j * 4, arrayOfInt15[] = treeSize$array, i53 = treeSize$offset + i54 / 4; int i52 = arrayOfInt15[i53]; int i51 = idx * 4; int arrayOfInt14[] = mbest$array, i50 = mbest$offset + i51 / 4; int i49 = idx * 8; double[] arrayOfDouble7 = avnode$array; int i48 = avnode$offset + i49 / 8; int i47 = idx * 8; double[] arrayOfDouble6 = upper$array; int i46 = upper$offset + i47 / 8; int i45 = idx * 4; int arrayOfInt13[] = nodestatus$array, i44 = nodestatus$offset + i45 / 4; int i43 = idx * 4;
/*     */         int arrayOfInt12[] = rDaughter$array, i42 = rDaughter$offset + i43 / 4, i41 = idx * 4, arrayOfInt11[] = lDaughter$array, i40 = lDaughter$offset + i41 / 4;
/*     */         regTree__.predictRegTree(new DoublePtr(xts$array, xts$offset), ntest, mdim, new IntPtr(arrayOfInt11, i40), new IntPtr(arrayOfInt12, i42), new IntPtr(arrayOfInt13, i44), new DoublePtr(ytree, ytree$offset), new DoublePtr(arrayOfDouble6, i46), new DoublePtr(arrayOfDouble7, i48), new IntPtr(arrayOfInt14, i50), i52, new IntPtr(cat$array, cat$offset), i55, new IntPtr(nodexts, nodexts$offset));
/* 218 */         errts = 0.0D;
/* 219 */         for (n = 0; n < ntest; n++) {
/* 220 */           int i61 = n * 8; double[] arrayOfDouble10 = yTestPred$array; int i60 = yTestPred$offset + i61 / 8; double d8 = j; int i59 = n * 8; double[] arrayOfDouble9 = yTestPred$array; int i58 = yTestPred$offset + i59 / 8; double d7 = arrayOfDouble9[i58], d6 = d8 * d7; int i57 = n * 8; double[] arrayOfDouble8 = ytree; int i56 = ytree$offset + i57 / 8; double d5 = arrayOfDouble8[i56], d4 = d6 + d5, d3 = (j + 1), d2 = d4 / d3; arrayOfDouble10[i60] = d2;
/*     */         } 
/*     */         
/* 223 */         if (labelts$array[labelts$offset] != 0) {
/* 224 */           for (n = 0; n < ntest; n++) {
/* 225 */             if (biasCorr$array[biasCorr$offset] == 
/* 226 */               0)
/* 227 */             { int i59 = n * 8; double[] arrayOfDouble9 = yts$array; int i58 = yts$offset + i59 / 8; double d4 = arrayOfDouble9[i58]; int i57 = n * 8; double[] arrayOfDouble8 = yTestPred$array; int i56 = yTestPred$offset + i57 / 8; double d3 = arrayOfDouble8[i56]; iftmp$109 = d4 - d3; } else { int i60 = n * 8; double[] arrayOfDouble10 = yts$array; int i59 = yts$offset + i60 / 8; double d8 = arrayOfDouble10[i59], d7 = coef$array[coef$offset], arrayOfDouble9[] = coef$array; int i58 = coef$offset + 1; double d6 = arrayOfDouble9[i58]; int i57 = n * 8; double[] arrayOfDouble8 = yTestPred$array; int i56 = yTestPred$offset + i57 / 8; double d5 = arrayOfDouble8[i56], d4 = d6 * d5, d3 = d7 + d4; iftmp$109 = d8 - d3; }
/* 228 */              resid = iftmp$109; errts = resid * resid + errts;
/*     */           } 
/* 230 */           double d2 = ntest; errts /= d2;
/*     */         } 
/*     */       } 
/*     */       
/* 234 */       int i5 = j + 1, i4 = jprint$array[jprint$offset]; if (i5 % i4 == 0) {
/* 235 */         int i40 = j + 1; Print.Rprintf(new BytePtr("%4d |\000".getBytes(), 0), new Object[] { Integer.valueOf(i40) });
/* 236 */         double d2 = errb[0] * 100.0D / varY; errb$115 = errb[0]; Print.Rprintf(new BytePtr(" %8.4g %8.2f \000".getBytes(), 0), new Object[] { Double.valueOf(errb$115), Double.valueOf(d2) });
/* 237 */         if (labelts$array[labelts$offset] == 1) { double d3 = 
/* 238 */             errts * 100.0D / varYts; Print.Rprintf(new BytePtr("| %8.4g %8.2f \000".getBytes(), 0), new Object[] { Double.valueOf(errts), Double.valueOf(d3) }); }
/* 239 */          Print.Rprintf(new BytePtr("|\n\000".getBytes(), 0), new Object[0]);
/*     */       } 
/* 241 */       int i3 = j * 8; double[] arrayOfDouble1 = mse$array; int i2 = mse$offset + i3 / 8; errb$117 = errb[0]; arrayOfDouble1[i2] = errb$117;
/* 242 */       if (labelts$array[labelts$offset] != 0) { int i41 = j * 8; double[] arrayOfDouble = msets$array; int i40 = msets$offset + i41 / 8; arrayOfDouble[i40] = errts; }
/*     */ 
/*     */       
/* 245 */       if (doProx$array[doProx$offset] != 0) {
/* 246 */         int i40 = oobprox$array[oobprox$offset]; rfutils__.computeProximity(new DoublePtr(prox$array, prox$offset), i40, new IntPtr(nodex, nodex$offset), new IntPtr(in, in$offset), new IntPtr(oobpair, oobpair$offset), nsample);
/*     */         
/* 248 */         if (testdat$array[testdat$offset] != 0) {
/*     */           
/* 250 */           rfutils__.computeProximity(new DoublePtr(proxts$array, proxts$offset), 0, new IntPtr(nodexts, nodexts$offset), new IntPtr(in, in$offset), new IntPtr(oobpair, oobpair$offset), ntest);
/* 251 */           for (n = 0; n < ntest; n++) {
/* 252 */             for (k = 0; k < nsample; k++) {
/* 253 */               int i46 = n * 4, arrayOfInt12[] = nodexts, i45 = nodexts$offset + i46 / 4, i44 = arrayOfInt12[i45], i43 = k * 4, arrayOfInt11[] = nodex, i42 = nodex$offset + i43 / 4, i41 = arrayOfInt11[i42]; if (i44 == i41) {
/* 254 */                 int i50 = ((k + ntest) * ntest + n) * 8; double[] arrayOfDouble7 = proxts$array; int i49 = proxts$offset + i50 / 8, i48 = ((k + ntest) * ntest + n) * 8; double[] arrayOfDouble6 = proxts$array; int i47 = proxts$offset + i48 / 8; double d2 = arrayOfDouble6[i47] + 1.0D; arrayOfDouble7[i49] = d2;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 262 */       if (varImp != 0) {
/* 263 */         for (mr = 0; mr < mdim; mr++) {
/* 264 */           int i41 = mr * 4, arrayOfInt[] = varUsed, i40 = varUsed$offset + i41 / 4; if (arrayOfInt[i40] != 0) {
/*     */             
/* 266 */             for (n = 0; n < nsample; n++) {
/* 267 */               int i53 = n * 8; double[] arrayOfDouble11 = xtmp; int i52 = xtmp$offset + i53 / 8, i51 = (n * mdim + mr) * 8; double[] arrayOfDouble10 = x$array; int i50 = x$offset + i51 / 8; double d9 = arrayOfDouble10[i50]; arrayOfDouble11[i52] = d9;
/* 268 */             }  ooberrperm = 0.0D;
/* 269 */             for (k = 0; k < nPerm; k++) {
/* 270 */               rfutils__.permuteOOB(mr, new DoublePtr(x$array, x$offset), new IntPtr(in, in$offset), nsample, mdim);
/* 271 */               int i65 = maxcat$array[maxcat$offset];
/*     */ 
/*     */               
/* 274 */               int i64 = j * 4, arrayOfInt15[] = treeSize$array, i63 = treeSize$offset + i64 / 4; int i62 = arrayOfInt15[i63]; int i61 = idx * 4; int arrayOfInt14[] = mbest$array, i60 = mbest$offset + i61 / 4; int i59 = idx * 8; double[] arrayOfDouble11 = avnode$array; int i58 = avnode$offset + i59 / 8; int i57 = idx * 8; double[] arrayOfDouble10 = upper$array; int i56 = upper$offset + i57 / 8; int i55 = idx * 4; int arrayOfInt13[] = nodestatus$array, i54 = nodestatus$offset + i55 / 4; int i53 = idx * 4; int arrayOfInt12[] = rDaughter$array, i52 = rDaughter$offset + i53 / 4, i51 = idx * 4, arrayOfInt11[] = lDaughter$array, i50 = lDaughter$offset + i51 / 4; regTree__.predictRegTree(new DoublePtr(x$array, x$offset), nsample, mdim, new IntPtr(arrayOfInt11, i50), new IntPtr(arrayOfInt12, i52), new IntPtr(arrayOfInt13, i54), new DoublePtr(ytr, ytr$offset), new DoublePtr(arrayOfDouble10, i56), new DoublePtr(arrayOfDouble11, i58), new IntPtr(arrayOfInt14, i60), i62, new IntPtr(cat$array, cat$offset), i65, new IntPtr(nodex, nodex$offset));
/* 275 */               for (n = 0; n < nsample; n++) {
/* 276 */                 int i71 = n * 4, arrayOfInt16[] = in, i70 = in$offset + i71 / 4;
/* 277 */                 int i69 = n * 8; double[] arrayOfDouble13 = ytr; int i68 = ytr$offset + i69 / 8; double d10 = arrayOfDouble13[i68]; int i67 = n * 8; double[] arrayOfDouble12 = y$array; int i66 = y$offset + i67 / 8; double d9 = arrayOfDouble12[i66]; r = d10 - d9;
/* 278 */                 ooberrperm = r * r + ooberrperm;
/* 279 */                 if (arrayOfInt16[i70] == 0 && localImp != 0) {
/* 280 */                   int i79 = (n * mdim + mr) * 8; double[] arrayOfDouble17 = impmat$array; int i78 = impmat$offset + i79 / 8, i77 = (n * mdim + mr) * 8; double[] arrayOfDouble16 = impmat$array; int i76 = impmat$offset + i77 / 8; double d19 = arrayOfDouble16[i76];
/* 281 */                   double d18 = r * r; int i75 = n * 8; double[] arrayOfDouble15 = resOOB; int i74 = resOOB$offset + i75 / 8; double d17 = arrayOfDouble15[i74]; int i73 = n * 8; double[] arrayOfDouble14 = resOOB; int i72 = resOOB$offset + i73 / 8; double d16 = arrayOfDouble14[i72], d15 = d17 * d16, d14 = d18 - d15, d13 = nPerm, d12 = d14 / d13; double d11 = d19 + d12;
/*     */                   arrayOfDouble17[i78] = d11;
/*     */                 } 
/*     */               } 
/*     */             } 
/* 286 */             double d8 = nPerm, d7 = ooberrperm / d8 - ooberr, d6 = nOOB; delta = d7 / d6;
/* 287 */             int i49 = mr * 8; double[] arrayOfDouble9 = errimp$array; int i48 = errimp$offset + i49 / 8, i47 = mr * 8; double[] arrayOfDouble8 = errimp$array; int i46 = errimp$offset + i47 / 8; double d5 = arrayOfDouble8[i46] + delta; arrayOfDouble9[i48] = d5;
/* 288 */             int i45 = mr * 8; double[] arrayOfDouble7 = impSD$array; int i44 = impSD$offset + i45 / 8, i43 = mr * 8; double[] arrayOfDouble6 = impSD$array; int i42 = impSD$offset + i43 / 8; double d4 = arrayOfDouble6[i42], d3 = delta * delta, d2 = d4 + d3; arrayOfDouble7[i44] = d2;
/*     */             
/* 290 */             n = 0;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 296 */     Random.PutRNGstate();
/*     */ 
/*     */     
/* 299 */     if (biasCorr$array[biasCorr$offset] != 0) {
/* 300 */       for (n = 0; n < nsample; n++) {
/* 301 */         int i3 = n * 4, arrayOfInt[] = nout$array, i2 = nout$offset + i3 / 4; if (arrayOfInt[i2] != 0) { int i8 = n * 8; double[] arrayOfDouble3 = yptr$array; int i7 = yptr$offset + i8 / 8; double d5 = coef$array[coef$offset], arrayOfDouble2[] = coef$array; int i6 = coef$offset + 1; double d4 = arrayOfDouble2[i6]; int i5 = n * 8; double[] arrayOfDouble1 = yptr$array; int i4 = yptr$offset + i5 / 8; double d3 = arrayOfDouble1[i4], d2 = d4 * d3, d1 = d5 + d2; arrayOfDouble3[i7] = d1; }
/*     */       
/* 303 */       }  if (testdat$array[testdat$offset] != 0) {
/* 304 */         for (n = 0; n < ntest; n++) {
/* 305 */           int i6 = n * 8; double[] arrayOfDouble3 = yTestPred$array; int i5 = yTestPred$offset + i6 / 8; double d5 = coef$array[coef$offset], arrayOfDouble2[] = coef$array; int i4 = coef$offset + 1; double d4 = arrayOfDouble2[i4]; int i3 = n * 8; double[] arrayOfDouble1 = yTestPred$array; int i2 = yTestPred$offset + i3 / 8; double d3 = arrayOfDouble1[i2], d2 = d4 * d3, d1 = d5 + d2; arrayOfDouble3[i5] = d1;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 310 */     if (doProx$array[doProx$offset] != 0) {
/* 311 */       for (n = 0; n < nsample; n++) {
/* 312 */         for (k = n + 1; k < nsample; k++) {
/* 313 */           int i11 = (nsample * k + n) * 8; double[] arrayOfDouble4 = prox$array; int i10 = prox$offset + i11 / 8, i9 = (nsample * k + n) * 8; double[] arrayOfDouble3 = prox$array; int i8 = prox$offset + i9 / 8; double d3 = arrayOfDouble3[i8]; if (oobprox$array[oobprox$offset] == 0) { iftmp$145 = 
/*     */               
/* 315 */               nTree$array[nTree$offset]; } else { int i13 = (nsample * k + n) * 4, arrayOfInt[] = oobpair, i12 = oobpair$offset + i13 / 4; if (arrayOfInt[i12] <= 0) { iftmp$146 = 1.0D; } else { int i15 = (nsample * k + n) * 4, arrayOfInt1[] = oobpair, i14 = oobpair$offset + i15 / 4; iftmp$146 = arrayOfInt1[i14]; }  iftmp$145 = iftmp$146; }
/* 316 */            double d2 = d3 / iftmp$145; arrayOfDouble4[i10] = d2; int i7 = (nsample * n + k) * 8; double[] arrayOfDouble2 = prox$array; int i6 = prox$offset + i7 / 8, i5 = (nsample * k + n) * 8; double[] arrayOfDouble1 = prox$array; int i4 = prox$offset + i5 / 8; double d1 = arrayOfDouble1[i4]; arrayOfDouble2[i6] = d1;
/*     */         } 
/* 318 */         int i3 = (nsample + 1) * 8 * n; double[] arrayOfDouble = prox$array; int i2 = prox$offset + i3 / 8; arrayOfDouble[i2] = 1.0D;
/*     */       } 
/* 320 */       if (testdat$array[testdat$offset] != 0)
/* 321 */         for (n = 0; n < ntest; n++) {
/* 322 */           for (k = 0; ntest + nsample > k; k++) {
/* 323 */             int i5 = (ntest * k + n) * 8; double[] arrayOfDouble2 = proxts$array; int i4 = proxts$offset + i5 / 8, i3 = (ntest * k + n) * 8; double[] arrayOfDouble1 = proxts$array; int i2 = proxts$offset + i3 / 8; double d3 = arrayOfDouble1[i2], d2 = nTree$array[nTree$offset], d1 = d3 / d2; arrayOfDouble2[i4] = d1;
/*     */           } 
/*     */         }  
/*     */     } 
/* 327 */     if (varImp != 0) {
/* 328 */       for (m = 0; m < mdim; m++) {
/* 329 */         int i13 = m * 8; double[] arrayOfDouble6 = errimp$array; int i12 = errimp$offset + i13 / 8, i11 = m * 8; double[] arrayOfDouble5 = errimp$array; int i10 = errimp$offset + i11 / 8; double d12 = arrayOfDouble5[i10], d11 = nTree$array[nTree$offset], d10 = d12 / d11; arrayOfDouble6[i12] = d10;
/* 330 */         int i9 = m * 8; double[] arrayOfDouble4 = impSD$array; int i8 = impSD$offset + i9 / 8, i7 = m * 8; double[] arrayOfDouble3 = impSD$array; int i6 = impSD$offset + i7 / 8; double d9 = arrayOfDouble3[i6], d8 = nTree$array[nTree$offset], d7 = d9 / d8;
/* 331 */         int i5 = m * 8; double[] arrayOfDouble2 = errimp$array; int i4 = errimp$offset + i5 / 8; double d6 = arrayOfDouble2[i4]; int i3 = m * 8; double[] arrayOfDouble1 = errimp$array; int i2 = errimp$offset + i3 / 8; double d5 = arrayOfDouble1[i2], d4 = d6 * d5; double d3 = d7 - d4, d2 = nTree$array[nTree$offset], d1 = Mathlib.sqrt(d3 / d2); arrayOfDouble4[i8] = d1;
/* 332 */         if (localImp != 0) {
/* 333 */           for (n = 0; n < nsample; n++) {
/* 334 */             int i19 = (n * mdim + m) * 8; double[] arrayOfDouble8 = impmat$array; int i18 = impmat$offset + i19 / 8, i17 = (n * mdim + m) * 8; double[] arrayOfDouble7 = impmat$array; int i16 = impmat$offset + i17 / 8; double d15 = arrayOfDouble7[i16]; int i15 = n * 4, arrayOfInt[] = nout$array, i14 = nout$offset + i15 / 4; double d14 = arrayOfInt[i14], d13 = d15 / d14; arrayOfDouble8[i18] = d13;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 339 */     for (m = 0; m < mdim; ) { int i5 = m * 8; double[] arrayOfDouble2 = tgini; int i4 = tgini$offset + i5 / 8, i3 = m * 8; double[] arrayOfDouble1 = tgini; int i2 = tgini$offset + i3 / 8; double d3 = arrayOfDouble1[i2], d2 = nTree$array[nTree$offset], d1 = d3 / d2; arrayOfDouble2[i4] = d1; m++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void regForest(DoublePtr x, DoublePtr ypred, IntPtr mdim, IntPtr n, IntPtr ntree, IntPtr lDaughter, IntPtr rDaughter, IntPtr nodestatus, IntPtr nrnodes, DoublePtr xsplit, DoublePtr avnodes, IntPtr mbest, IntPtr treeSize, IntPtr cat, IntPtr maxcat, IntPtr keepPred, DoublePtr allpred, IntPtr doProx, DoublePtr proxMat, IntPtr nodes, IntPtr nodex) {
/* 352 */     x$array = x.array; x$offset = x.offset; ypred$array = ypred.array; ypred$offset = ypred.offset; mdim$array = mdim.array; mdim$offset = mdim.offset; n$array = n.array; n$offset = n.offset; ntree$array = ntree.array; ntree$offset = ntree.offset; lDaughter$array = lDaughter.array; lDaughter$offset = lDaughter.offset; rDaughter$array = rDaughter.array; rDaughter$offset = rDaughter.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; nrnodes$array = nrnodes.array; nrnodes$offset = nrnodes.offset; xsplit$array = xsplit.array; xsplit$offset = xsplit.offset; avnodes$array = avnodes.array; avnodes$offset = avnodes.offset; mbest$array = mbest.array; mbest$offset = mbest.offset; treeSize$array = treeSize.array; treeSize$offset = treeSize.offset; cat$array = cat.array; cat$offset = cat.offset; maxcat$array = maxcat.array; maxcat$offset = maxcat.offset; keepPred$array = keepPred.array; keepPred$offset = keepPred.offset; allpred$array = allpred.array; allpred$offset = allpred.offset; doProx$array = doProx.array; doProx$offset = doProx.offset; proxMat$array = proxMat.array; proxMat$offset = proxMat.offset; nodes$array = nodes.array; nodes$offset = nodes.offset; nodex$array = nodex.array; nodex$offset = nodex.offset; ytree = null; ytree$offset = 0; junk = null; junk$offset = 0; idx2 = 0; idx1 = 0; i = 0; junk = null; junk$offset = 0;
/* 353 */     ytree = new double[n$array[n$offset] * 8 / 8]; ytree$offset = 0;
/* 354 */     if (nodes$array[nodes$offset] == 0)
/*     */     
/*     */     { 
/* 357 */       int k = n$array[n$offset]; rfutils__.zeroInt(new IntPtr(nodex$array, nodex$offset), k); }
/*     */     else { int i1 = n$array[n$offset], m = ntree$array[ntree$offset], k = i1 * m; rfutils__.zeroInt(new IntPtr(nodex$array, nodex$offset), k); }
/* 359 */      if (doProx$array[doProx$offset] != 0) { int i1 = n$array[n$offset], m = n$array[n$offset], k = i1 * m; rfutils__.zeroDouble(new DoublePtr(proxMat$array, proxMat$offset), k); }
/* 360 */      if (keepPred$array[keepPred$offset] != 0) { int i1 = n$array[n$offset], m = ntree$array[ntree$offset], k = i1 * m; rfutils__.zeroDouble(new DoublePtr(allpred$array, allpred$offset), k); }
/* 361 */      idx1 = 0;
/* 362 */     idx2 = 0;
/* 363 */     for (i = 0; ntree$array[ntree$offset] > i; i++) {
/* 364 */       int i19 = n$array[n$offset]; rfutils__.zeroDouble(new DoublePtr(ytree, ytree$offset), i19);
/*     */ 
/*     */ 
/*     */       
/* 368 */       int i18 = idx2 * 4; int arrayOfInt6[] = nodex$array, i17 = nodex$offset + i18 / 4, i16 = maxcat$array[maxcat$offset]; int i15 = i * 4, arrayOfInt5[] = treeSize$array, i14 = treeSize$offset + i15 / 4; int i13 = arrayOfInt5[i14]; int i12 = idx1 * 4; int arrayOfInt4[] = mbest$array, i11 = mbest$offset + i12 / 4; int i10 = idx1 * 8; double[] arrayOfDouble2 = avnodes$array; int i9 = avnodes$offset + i10 / 8; int i8 = idx1 * 8; double[] arrayOfDouble1 = xsplit$array; int i7 = xsplit$offset + i8 / 8; int i6 = idx1 * 4; int arrayOfInt3[] = nodestatus$array, i5 = nodestatus$offset + i6 / 4, i4 = idx1 * 4, arrayOfInt2[] = rDaughter$array, i3 = rDaughter$offset + i4 / 4, i2 = idx1 * 4, arrayOfInt1[] = lDaughter$array, i1 = lDaughter$offset + i2 / 4, m = mdim$array[mdim$offset], k = n$array[n$offset];
/*     */       regTree__.predictRegTree(new DoublePtr(x$array, x$offset), k, m, new IntPtr(arrayOfInt1, i1), new IntPtr(arrayOfInt2, i3), new IntPtr(arrayOfInt3, i5), new DoublePtr(ytree, ytree$offset), new DoublePtr(arrayOfDouble1, i7), new DoublePtr(arrayOfDouble2, i9), new IntPtr(arrayOfInt4, i11), i13, new IntPtr(cat$array, cat$offset), i16, new IntPtr(arrayOfInt6, i17));
/* 370 */       for (j = 0; n$array[n$offset] > j; ) { int i25 = j * 8; double[] arrayOfDouble5 = ypred$array; int i24 = ypred$offset + i25 / 8, i23 = j * 8; double[] arrayOfDouble4 = ypred$array; int i22 = ypred$offset + i23 / 8; double d3 = arrayOfDouble4[i22]; int i21 = j * 8; double[] arrayOfDouble3 = ytree; int i20 = ytree$offset + i21 / 8; double d2 = arrayOfDouble3[i20], d1 = d3 + d2; arrayOfDouble5[i24] = d1; j++; }
/* 371 */        if (keepPred$array[keepPred$offset] != 0) {
/* 372 */         for (j = 0; n$array[n$offset] > j; ) { int i23 = (n$array[n$offset] * i + j) * 8; double[] arrayOfDouble4 = allpred$array; int i22 = allpred$offset + i23 / 8, i21 = j * 8; double[] arrayOfDouble3 = ytree; int i20 = ytree$offset + i21 / 8; double d = arrayOfDouble3[i20]; arrayOfDouble4[i22] = d; j++; }
/*     */       
/*     */       }
/* 375 */       if (doProx$array[doProx$offset] != 0) { int i22 = n$array[n$offset], i21 = idx2 * 4, arrayOfInt[] = nodex$array, i20 = nodex$offset + i21 / 4; rfutils__.computeProximity(new DoublePtr(proxMat$array, proxMat$offset), 0, new IntPtr(arrayOfInt, i20), new IntPtr(junk, junk$offset), new IntPtr(junk, junk$offset), i22); }
/*     */       
/* 377 */       idx1 = nrnodes$array[nrnodes$offset] + idx1;
/* 378 */       if (nodes$array[nodes$offset] != 0) idx2 = n$array[n$offset] + idx2; 
/*     */     } 
/* 380 */     for (i = 0; n$array[n$offset] > i; ) { int i2 = i * 8; double[] arrayOfDouble2 = ypred$array; int i1 = ypred$offset + i2 / 8, m = i * 8; double[] arrayOfDouble1 = ypred$array; int k = ypred$offset + m / 8; double d3 = arrayOfDouble1[k], d2 = ntree$array[ntree$offset], d1 = d3 / d2; arrayOfDouble2[i1] = d1; i++; }
/* 381 */      if (doProx$array[doProx$offset] != 0) {
/* 382 */       for (i = 0; n$array[n$offset] > i; i++) {
/* 383 */         for (j = i + 1; n$array[n$offset] > j; j++) {
/* 384 */           int i8 = (n$array[n$offset] * j + i) * 8; double[] arrayOfDouble4 = proxMat$array; int i7 = proxMat$offset + i8 / 8, i6 = (n$array[n$offset] * j + i) * 8; double[] arrayOfDouble3 = proxMat$array; int i5 = proxMat$offset + i6 / 8; double d4 = arrayOfDouble3[i5], d3 = ntree$array[ntree$offset], d2 = d4 / d3; arrayOfDouble4[i7] = d2;
/* 385 */           int i4 = (n$array[n$offset] * i + j) * 8; double[] arrayOfDouble2 = proxMat$array; int i3 = proxMat$offset + i4 / 8, i2 = (n$array[n$offset] * j + i) * 8; double[] arrayOfDouble1 = proxMat$array; int i1 = proxMat$offset + i2 / 8; double d1 = arrayOfDouble1[i1]; arrayOfDouble2[i3] = d1;
/*     */         } 
/* 387 */         int m = (n$array[n$offset] + 1) * 8 * i; double[] arrayOfDouble = proxMat$array; int k = proxMat$offset + m / 8; arrayOfDouble[k] = 1.0D;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void simpleLinReg(int nsample, DoublePtr x, DoublePtr y, DoublePtr coef, DoublePtr mse, IntPtr hasPred) {
/* 396 */     x$array = x.array; x$offset = x.offset; y$array = y.array; y$offset = y.offset; coef$array = coef.array; coef$offset = coef.offset; mse$array = mse.array; mse$offset = mse.offset; hasPred$array = hasPred.array; hasPred$offset = hasPred.offset; ybar = 0.0D; xbar = 0.0D; sxy = 0.0D; sxx = 0.0D; nout = 0; nout = 0;
/* 397 */     sxx = 0.0D; sxy = 0.0D; xbar = 0.0D; ybar = 0.0D;
/* 398 */     dx = 0.0D; dy = 0.0D; py = 0.0D;
/*     */     
/* 400 */     for (i = 0; i < nsample; i++) {
/* 401 */       int n = i * 4, arrayOfInt[] = hasPred$array, m = hasPred$offset + n / 4; if (arrayOfInt[m] != 0) {
/* 402 */         nout++;
/* 403 */         int i4 = i * 8; double[] arrayOfDouble4 = x$array; int i3 = x$offset + i4 / 8; xbar = arrayOfDouble4[i3] + xbar;
/* 404 */         int i2 = i * 8; double[] arrayOfDouble3 = y$array; int i1 = y$offset + i2 / 8; ybar = arrayOfDouble3[i1] + ybar;
/*     */       } 
/*     */     } 
/* 407 */     double d8 = nout; xbar /= d8;
/* 408 */     double d7 = nout; ybar /= d7;
/*     */     
/* 410 */     for (i = 0; i < nsample; i++) {
/* 411 */       int n = i * 4, arrayOfInt[] = hasPred$array, m = hasPred$offset + n / 4; if (arrayOfInt[m] != 0) {
/* 412 */         int i4 = i * 8; double[] arrayOfDouble4 = x$array; int i3 = x$offset + i4 / 8; dx = arrayOfDouble4[i3] - xbar;
/* 413 */         int i2 = i * 8; double[] arrayOfDouble3 = y$array; int i1 = y$offset + i2 / 8; dy = arrayOfDouble3[i1] - ybar;
/* 414 */         sxx = dx * dx + sxx;
/* 415 */         sxy = dx * dy + sxy;
/*     */       } 
/*     */     } 
/* 418 */     double[] arrayOfDouble2 = coef$array; int k = coef$offset + 1; double d6 = sxy / sxx; arrayOfDouble2[k] = d6;
/* 419 */     double[] arrayOfDouble1 = coef$array; int j = coef$offset + 1; double d5 = arrayOfDouble1[j] * xbar, d4 = ybar - d5; coef$array[coef$offset] = d4;
/*     */     
/* 421 */     mse$array[mse$offset] = 0.0D;
/* 422 */     for (i = 0; i < nsample; i++) {
/* 423 */       int n = i * 4, arrayOfInt[] = hasPred$array, m = hasPred$offset + n / 4; if (arrayOfInt[m] != 0) {
/* 424 */         double d15 = coef$array[coef$offset], arrayOfDouble5[] = coef$array; int i5 = coef$offset + 1; double d14 = arrayOfDouble5[i5]; int i4 = i * 8; double[] arrayOfDouble4 = x$array; int i3 = x$offset + i4 / 8; double d13 = arrayOfDouble4[i3], d12 = d14 * d13; py = d15 + d12;
/* 425 */         int i2 = i * 8; double[] arrayOfDouble3 = y$array; int i1 = y$offset + i2 / 8; dy = arrayOfDouble3[i1] - py;
/* 426 */         double d11 = mse$array[mse$offset], d10 = dy * dy, d9 = d11 + d10; mse$array[mse$offset] = d9;
/*     */       } 
/*     */     } 
/*     */     
/* 430 */     double d3 = mse$array[mse$offset], d2 = nout, d1 = d3 / d2; mse$array[mse$offset] = d1;
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/regrf__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */