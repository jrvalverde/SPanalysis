/*     */ package org.renjin.cran.randomForest;
/*     */ 
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class rfsub__
/*     */ {
/*     */   public static void buildtree_(IntPtr a, IntPtr b, IntPtr cl, IntPtr cat, IntPtr maxcat, IntPtr mdim, IntPtr nsample, IntPtr nclass, IntPtr treemap, IntPtr bestvar, IntPtr bestsplit, IntPtr bestsplitnext, DoublePtr tgini, IntPtr nodestatus, IntPtr nodepop, IntPtr nodestart, DoublePtr classpop, DoublePtr tclasspop, DoublePtr tclasscat, IntPtr ta, IntPtr nrnodes, IntPtr idmove, IntPtr ndsize, IntPtr ncase, IntPtr mtry, IntPtr iv, IntPtr nodeclass, IntPtr ndbigtree, DoublePtr win, DoublePtr wr, DoublePtr wl, IntPtr mred, IntPtr nuse, IntPtr mind) {
/*  22 */     a$array = a.array; a$offset = a.offset; b$array = b.array; b$offset = b.offset; cl$array = cl.array; cl$offset = cl.offset; cat$array = cat.array; cat$offset = cat.offset; maxcat$array = maxcat.array; maxcat$offset = maxcat.offset; mdim$array = mdim.array; mdim$offset = mdim.offset; nsample$array = nsample.array; nsample$offset = nsample.offset; nclass$array = nclass.array; nclass$offset = nclass.offset; treemap$array = treemap.array; treemap$offset = treemap.offset; bestvar$array = bestvar.array; bestvar$offset = bestvar.offset; bestsplit$array = bestsplit.array; bestsplit$offset = bestsplit.offset; bestsplitnext$array = bestsplitnext.array; bestsplitnext$offset = bestsplitnext.offset; tgini$array = tgini.array; tgini$offset = tgini.offset; nodestatus$array = nodestatus.array; nodestatus$offset = nodestatus.offset; nodepop$array = nodepop.array; nodepop$offset = nodepop.offset; nodestart$array = nodestart.array; nodestart$offset = nodestart.offset; classpop$array = classpop.array; classpop$offset = classpop.offset; tclasspop$array = tclasspop.array; tclasspop$offset = tclasspop.offset; tclasscat$array = tclasscat.array; tclasscat$offset = tclasscat.offset; ta$array = ta.array; ta$offset = ta.offset; nrnodes$array = nrnodes.array; nrnodes$offset = nrnodes.offset; idmove$array = idmove.array; idmove$offset = idmove.offset; ndsize$array = ndsize.array; ndsize$offset = ndsize.offset; ncase$array = ncase.array; ncase$offset = ncase.offset; mtry$array = mtry.array; mtry$offset = mtry.offset; iv$array = iv.array; iv$offset = iv.offset; nodeclass$array = nodeclass.array; nodeclass$offset = nodeclass.offset; ndbigtree$array = ndbigtree.array; ndbigtree$offset = ndbigtree.offset; win$array = win.array; win$offset = win.offset; wr$array = wr.array; wr$offset = wr.offset; wl$array = wl.array; wl$offset = wl.offset; mred$array = mred.array; mred$offset = mred.offset; nuse$array = nuse.array; nuse$offset = nuse.offset; mind$array = mind.array; mind$offset = mind.offset; xrand = new double[1]; ndstart = new int[1]; ndendl = new int[1]; ndend = new int[1]; msplit = new int[1]; jstat = new int[1]; decsplit = new double[1]; best = new double[1]; int i = 0, m = 0, i1 = 0, i2 = 0, i3 = 0, i4 = 0, i5 = 0, i6 = 0, i7 = 0; xrand[0] = 0.0D; pp = 0.0D; popt2 = 0.0D; popt1 = 0.0D; ntie = 0; ndstart[0] = 0; ndendl[0] = 0; ndend[0] = 0; ncur = 0; msplit[0] = 0; kn = 0; kbuild = 0; decsplit[0] = 0.0D; offset$76 = 0; stride$75 = 0; best[0] = 0.0D; offset$56 = 0; stride$55 = 0; size$93 = nrnodes$array[nrnodes$offset]; size$93 = Math.max(size$93, 0); int i9 = size$93 + -1; long l1 = (size$93 & 0xFFFFFFFFL) * 32L; int i8 = size$93 * 4; size$91 = nrnodes$array[nrnodes$offset]; size$91 = Math.max(size$91, 0); int i11 = size$91 + -1; long l2 = (size$91 & 0xFFFFFFFFL) * 32L; int i10 = size$91 * 4; size$89 = nrnodes$array[nrnodes$offset]; size$89 = Math.max(size$89, 0); int i13 = size$89 + -1; long l3 = (size$89 & 0xFFFFFFFFL) * 32L; int i12 = size$89 * 4; stride$75 = nclass$array[nclass$offset]; stride$75 = Math.max(stride$75, 0); ubound$74 = nrnodes$array[nrnodes$offset]; size$77 = stride$75 * ubound$74; size$77 = Math.max(size$77, 0); int i15 = size$77 + -1; long l4 = (size$77 & 0xFFFFFFFFL) * 64L; int i14 = size$77 * 8; offset$76 = stride$75 ^ 0xFFFFFFFF; size$101 = nclass$array[nclass$offset]; size$101 = Math.max(size$101, 0); int i17 = size$101 + -1; long l5 = (size$101 & 0xFFFFFFFFL) * 64L; int i16 = size$101 * 8; stride$55 = mdim$array[mdim$offset]; stride$55 = Math.max(stride$55, 0); ubound$54 = nsample$array[nsample$offset]; size$57 = stride$55 * ubound$54; size$57 = Math.max(size$57, 0); int i19 = size$57 + -1; long l6 = (size$57 & 0xFFFFFFFFL) * 32L; int i18 = size$57 * 4; offset$56 = stride$55 ^ 0xFFFFFFFF; stride$60 = mdim$array[mdim$offset]; stride$60 = Math.max(stride$60, 0); ubound$59 = nsample$array[nsample$offset]; size$62 = stride$60 * ubound$59; size$62 = Math.max(size$62, 0); int i21 = size$62 + -1; long l7 = (size$62 & 0xFFFFFFFFL) * 32L; int i20 = size$62 * 4; offset$61 = stride$60 ^ 0xFFFFFFFF; size$72 = nsample$array[nsample$offset]; size$72 = Math.max(size$72, 0); int i23 = size$72 + -1; long l8 = (size$72 & 0xFFFFFFFFL) * 32L; int i22 = size$72 * 4; size$70 = mdim$array[mdim$offset]; size$70 = Math.max(size$70, 0); int i25 = size$70 + -1; long l9 = (size$70 & 0xFFFFFFFFL) * 32L; int i24 = size$70 * 4;
/*  23 */     stride$97 = nclass$array[nclass$offset]; stride$97 = Math.max(stride$97, 0); size$99 = stride$97 * 53; size$99 = Math.max(size$99, 0); int i27 = size$99 + -1; long l10 = (size$99 & 0xFFFFFFFFL) * 64L; int i26 = size$99 * 8; offset$98 = stride$97 ^ 0xFFFFFFFF; size$85 = nsample$array[nsample$offset]; size$85 = Math.max(size$85, 0); int i29 = size$85 + -1; long l11 = (size$85 & 0xFFFFFFFFL) * 32L; int i28 = size$85 * 4;
/*  24 */     size$107 = nsample$array[nsample$offset]; size$107 = Math.max(size$107, 0); int i31 = size$107 + -1; long l12 = (size$107 & 0xFFFFFFFFL) * 64L; int i30 = size$107 * 8; size$111 = nclass$array[nclass$offset]; size$111 = Math.max(size$111, 0); int i33 = size$111 + -1; long l13 = (size$111 & 0xFFFFFFFFL) * 64L; int i32 = size$111 * 8; size$109 = nclass$array[nclass$offset]; size$109 = Math.max(size$109, 0); int i35 = size$109 + -1; long l14 = (size$109 & 0xFFFFFFFFL) * 64L; int i34 = size$109 * 8; size$83 = mred$array[mred$offset]; size$83 = Math.max(size$83, 0); int i37 = size$83 + -1; long l15 = (size$83 & 0xFFFFFFFFL) * 32L; int i36 = size$83 * 4; size$68 = nrnodes$array[nrnodes$offset]; size$68 = Math.max(size$68, 0); int i39 = size$68 + -1; long l16 = (size$68 & 0xFFFFFFFFL) * 32L; int i38 = size$68 * 4; size$81 = mred$array[mred$offset]; size$81 = Math.max(size$81, 0); int i41 = size$81 + -1; long l17 = (size$81 & 0xFFFFFFFFL) * 32L; int i40 = size$81 * 4; size$103 = mdim$array[mdim$offset]; size$103 = Math.max(size$103, 0); int i43 = size$103 + -1; long l18 = (size$103 & 0xFFFFFFFFL) * 64L; int i42 = size$103 * 8; size$64 = nrnodes$array[nrnodes$offset]; size$64 = Math.max(size$64, 0); int i45 = size$64 + -1; long l19 = (size$64 & 0xFFFFFFFFL) * 32L; int i44 = size$64 * 4; size$66 = nrnodes$array[nrnodes$offset]; size$66 = Math.max(size$66, 0); int i47 = size$66 + -1; long l20 = (size$66 & 0xFFFFFFFFL) * 32L; int i46 = size$66 * 4; size$95 = nsample$array[nsample$offset]; size$95 = Math.max(size$95, 0); int i49 = size$95 + -1; long l21 = (size$95 & 0xFFFFFFFFL) * 32L; int i48 = size$95 * 4; size$79 = nsample$array[nsample$offset]; size$79 = Math.max(size$79, 0); int i51 = size$79 + -1; long l22 = (size$79 & 0xFFFFFFFFL) * 32L; int i50 = size$79 * 4; size$105 = nrnodes$array[nrnodes$offset] * 2; size$105 = Math.max(size$105, 0); int i53 = size$105 + -1; long l23 = (size$105 & 0xFFFFFFFFL) * 32L; int i52 = size$105 * 4; size$87 = nrnodes$array[nrnodes$offset]; size$87 = Math.max(size$87, 0); int i55 = size$87 + -1; long l24 = (size$87 & 0xFFFFFFFFL) * 32L; int i54 = size$87 * 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     msplit[0] = 0;
/*  56 */     zerv_(new IntPtr(nodestatus$array, nodestatus$offset), new IntPtr(nrnodes$array, nrnodes$offset));
/*  57 */     zerv_(new IntPtr(nodestart$array, nodestart$offset), new IntPtr(nrnodes$array, nrnodes$offset));
/*  58 */     zerv_(new IntPtr(nodepop$array, nodepop$offset), new IntPtr(nrnodes$array, nrnodes$offset));
/*  59 */     zermr_(new DoublePtr(classpop$array, classpop$offset), new IntPtr(nclass$array, nclass$offset), new IntPtr(nrnodes$array, nrnodes$offset));
/*     */     
/*  61 */     i7 = nclass$array[nclass$offset]; j = 1; if (j <= i7)
/*  62 */       while (true) { int i59 = j + stride$75 + offset$76, i58 = j + -1; double d = tclasspop$array[tclasspop$offset + i58]; classpop$array[classpop$offset + i59] = d; boolean bool = (j != i7) ? false : true; j++; if (bool == false)
/*     */           continue;  break; }
/*  64 */         ncur = 1;
/*  65 */     nodestart$array[nodestart$offset + 0] = 1;
/*  66 */     int i57 = nuse$array[nuse$offset]; nodepop$array[nodepop$offset + 0] = i57;
/*  67 */     nodestatus$array[nodestatus$offset + 0] = 2;
/*     */     
/*  69 */     i6 = nrnodes$array[nrnodes$offset]; kbuild = 1; if (kbuild <= i6)
/*     */     {
/*     */       
/*  72 */       while (kbuild <= ncur) {
/*  73 */         int i58 = kbuild + -1; if (nodestatus$array[nodestatus$offset + i58] == 2) {
/*     */           
/*  75 */           int i62 = kbuild + -1; ndstart$174 = nodestart$array[nodestart$offset + i62]; ndstart[0] = ndstart$174;
/*  76 */           int i61 = kbuild + -1, i60 = nodepop$array[nodepop$offset + i61]; ndstart$175 = ndstart[0]; ndend$176 = i60 + ndstart$175 + -1; ndend[0] = ndend$176;
/*  77 */           i5 = nclass$array[nclass$offset]; j = 1; if (j <= i5)
/*  78 */             while (true) { int i64 = j + -1, i63 = kbuild * stride$75 + j + offset$76; double d = classpop$array[classpop$offset + i63]; tclasspop$array[tclasspop$offset + i64] = d; boolean bool = (j != i5) ? false : true; j++; if (bool == false)
/*     */                 continue;  break; }
/*  80 */               jstat[0] = 0;
/*     */ 
/*     */ 
/*     */           
/*  84 */           findbestsplit_(new IntPtr(a$array, a$offset), new IntPtr(b$array, b$offset), new IntPtr(cl$array, cl$offset), new IntPtr(mdim$array, mdim$offset), new IntPtr(nsample$array, nsample$offset), new IntPtr(nclass$array, nclass$offset), new IntPtr(cat$array, cat$offset), new IntPtr(maxcat$array, maxcat$offset), new IntPtr(ndstart, 0), new IntPtr(ndend, 0), new DoublePtr(tclasspop$array, tclasspop$offset), new DoublePtr(tclasscat$array, tclasscat$offset), new IntPtr(msplit, 0), new DoublePtr(decsplit, 0), new DoublePtr(best, 0), new IntPtr(ncase$array, ncase$offset), new IntPtr(jstat, 0), new IntPtr(mtry$array, mtry$offset), new DoublePtr(win$array, win$offset), new DoublePtr(wr$array, wr$offset), new DoublePtr(wl$array, wl$offset), new IntPtr(mred$array, mred$offset), new IntPtr(mind$array, mind$offset));
/*     */ 
/*     */ 
/*     */           
/*  88 */           if (jstat[0] != -1)
/*     */           
/*     */           { 
/*     */             
/*  92 */             int i83 = kbuild + -1; msplit$178 = msplit[0]; bestvar$array[bestvar$offset + i83] = msplit$178;
/*  93 */             int i82 = msplit[0] + -1; iv$array[iv$offset + i82] = 1;
/*  94 */             if (((decsplit[0] >= 0.0D) ? false : true) != false) decsplit[0] = 0.0D; 
/*  95 */             int i81 = msplit[0] + -1, i80 = msplit[0] + -1; double d2 = tgini$array[tgini$offset + i80]; decsplit$183 = decsplit[0]; double d1 = d2 + decsplit$183; tgini$array[tgini$offset + i81] = d1;
/*  96 */             int i79 = msplit[0] + -1; if (cat$array[cat$offset + i79] != 1) {
/*     */ 
/*     */ 
/*     */               
/* 100 */               int i86 = kbuild + -1, i85 = (int)(long)best[0]; bestsplit$array[bestsplit$offset + i86] = i85;
/* 101 */               int i84 = kbuild + -1; bestsplitnext$array[bestsplitnext$offset + i84] = 0;
/*     */             } else {
/*     */               int i91 = kbuild + -1, i90 = (int)(long)best[0] * stride$55; msplit$186 = msplit[0]; int i89 = i90 + msplit$186 + offset$56, i88 = (int)(long)a$array[a$offset + i89]; bestsplit$array[bestsplit$offset + i91] = i88; int i87 = kbuild + -1, i86 = ((int)(long)best[0] + 1) * stride$55; msplit$188 = msplit[0]; int i85 = i86 + msplit$188 + offset$56, i84 = (int)(long)a$array[a$offset + i85];
/*     */               bestsplitnext$array[bestsplitnext$offset + i87] = i84;
/*     */             } 
/* 106 */             movedata_(new IntPtr(a$array, a$offset), new IntPtr(ta$array, ta$offset), new IntPtr(mdim$array, mdim$offset), new IntPtr(nsample$array, nsample$offset), new IntPtr(ndstart, 0), new IntPtr(ndend, 0), new IntPtr(idmove$array, idmove$offset), new IntPtr(ncase$array, ncase$offset), new IntPtr(msplit, 0), new IntPtr(cat$array, cat$offset), new DoublePtr(best, 0), new IntPtr(ndendl, 0));
/*     */ 
/*     */ 
/*     */             
/* 110 */             ndendl$190 = ndendl[0]; ndstart$191 = ndstart[0]; int i78 = ndendl$190 - ndstart$191 + 1; nodepop$array[nodepop$offset + ncur] = i78;
/* 111 */             int i77 = ncur + 1; ndend$192 = ndend[0]; ndendl$193 = ndendl[0]; int i76 = ndend$192 - ndendl$193; nodepop$array[nodepop$offset + i77] = i76;
/* 112 */             ndstart$194 = ndstart[0]; nodestart$array[nodestart$offset + ncur] = ndstart$194;
/* 113 */             int i75 = ncur + 1, i74 = ndendl[0] + 1; nodestart$array[nodestart$offset + i75] = i74;
/*     */ 
/*     */             
/* 116 */             n$196 = ndstart[0]; i4 = ndendl[0]; n = n$196; if (n <= i4)
/* 117 */               while (true) { int i88 = n + -1; nc = ncase$array[ncase$offset + i88];
/* 118 */                 int i87 = nc + -1; j = cl$array[cl$offset + i87];
/* 119 */                 int i86 = (ncur + 1) * stride$75 + j + offset$76, i85 = (ncur + 1) * stride$75 + j + offset$76; double d5 = classpop$array[classpop$offset + i85]; int i84 = nc + -1; double d4 = win$array[win$offset + i84], d3 = d5 + d4; classpop$array[classpop$offset + i86] = d3; boolean bool = (n != i4) ? false : true; n++; if (bool == false)
/*     */                   continue;  break; }
/* 121 */                 n$198 = ndendl[0] + 1; i3 = ndend[0]; n = n$198; if (n <= i3)
/* 122 */               while (true) { int i88 = n + -1; nc = ncase$array[ncase$offset + i88];
/* 123 */                 int i87 = nc + -1; j = cl$array[cl$offset + i87];
/* 124 */                 int i86 = (ncur + 2) * stride$75 + j + offset$76, i85 = (ncur + 2) * stride$75 + j + offset$76; double d5 = classpop$array[classpop$offset + i85]; int i84 = nc + -1; double d4 = win$array[win$offset + i84], d3 = d5 + d4; classpop$array[classpop$offset + i86] = d3; boolean bool = (n != i3) ? false : true; n++;
/*     */                 if (bool == false)
/*     */                   continue; 
/*     */                 break; }
/*     */                
/* 129 */             nodestatus$array[nodestatus$offset + ncur] = 2;
/* 130 */             int i73 = ncur + 1; nodestatus$array[nodestatus$offset + i73] = 2;
/* 131 */             int i72 = nodepop$array[nodepop$offset + ncur], i71 = ndsize$array[ndsize$offset]; if (i72 <= i71) nodestatus$array[nodestatus$offset + ncur] = -1; 
/* 132 */             int i70 = ncur + 1, i69 = nodepop$array[nodepop$offset + i70], i68 = ndsize$array[ndsize$offset]; if (i69 <= i68) { int i84 = ncur + 1; nodestatus$array[nodestatus$offset + i84] = -1; }
/* 133 */              popt1 = 0.0D;
/* 134 */             popt2 = 0.0D;
/* 135 */             i2 = nclass$array[nclass$offset]; j = 1; if (j <= i2)
/* 136 */               while (true) { int i85 = (ncur + 1) * stride$75 + j + offset$76; popt1 = classpop$array[classpop$offset + i85] + popt1;
/* 137 */                 int i84 = (ncur + 2) * stride$75 + j + offset$76; popt2 = classpop$array[classpop$offset + i84] + popt2; boolean bool = (j != i2) ? false : true; j++; if (bool == false)
/*     */                   continue;  break; }
/*     */                
/* 140 */             i1 = nclass$array[nclass$offset]; j = 1; if (j <= i1)
/* 141 */               while (true) { int i85 = (ncur + 1) * stride$75 + j + offset$76; if (classpop$array[classpop$offset + i85] == popt1) nodestatus$array[nodestatus$offset + ncur] = -1; 
/* 142 */                 int i84 = (ncur + 2) * stride$75 + j + offset$76; if (classpop$array[classpop$offset + i84] == popt2) { int i86 = ncur + 1; nodestatus$array[nodestatus$offset + i86] = -1; }
/*     */                  boolean bool = (j != i1) ? false : true; j++; if (bool == false)
/*     */                   continue;  break; }
/* 145 */                 int i67 = (kbuild + -1) * 2, i66 = ncur + 1; treemap$array[treemap$offset + i67] = i66;
/* 146 */             int i65 = (kbuild + 1) * 2 + -3, i64 = ncur + 2; treemap$array[treemap$offset + i65] = i64;
/* 147 */             int i63 = kbuild + -1; nodestatus$array[nodestatus$offset + i63] = 1;
/* 148 */             ncur += 2;
/* 149 */             if (nrnodes$array[nrnodes$offset] > ncur)
/*     */               continue;  break; }  int i59 = kbuild + -1; nodestatus$array[nodestatus$offset + i59] = -1;
/*     */         }  continue; bool = (kbuild != i6) ? false : true; kbuild++; if (bool == false)
/*     */           continue;  break;
/* 153 */       }  }  int i56 = nrnodes$array[nrnodes$offset]; ndbigtree$array[ndbigtree$offset] = i56;
/* 154 */     k = nrnodes$array[nrnodes$offset]; if (k > 0)
/* 155 */       while (true) { int i59 = k + -1; if (nodestatus$array[nodestatus$offset + i59] == 0) { int i60 = ndbigtree$array[ndbigtree$offset] + -1; ndbigtree$array[ndbigtree$offset] = i60; }
/* 156 */          int i58 = k + -1; if (nodestatus$array[nodestatus$offset + i58] == 2) { int i60 = k + -1; nodestatus$array[nodestatus$offset + i60] = -1; }
/*     */          boolean bool = (k != 1) ? false : true; k--; if (bool == false)
/*     */           continue;  break; }
/*     */        
/* 160 */     m = ndbigtree$array[ndbigtree$offset]; kn = 1; if (kn <= m) {
/*     */       while (true) {
/* 162 */         int i58 = kn + -1; if (nodestatus$array[nodestatus$offset + i58] == -1) {
/* 163 */           pp = 0.0D;
/* 164 */           ntie = 1;
/* 165 */           i = nclass$array[nclass$offset]; j = 1; if (j <= i) {
/* 166 */             while (true) { int i60 = kn * stride$75 + j + offset$76; if (((classpop$array[classpop$offset + i60] <= pp) ? false : true) != false) {
/* 167 */                 int i62 = kn + -1; nodeclass$array[nodeclass$offset + i62] = j;
/* 168 */                 int i61 = kn * stride$75 + j + offset$76; pp = classpop$array[classpop$offset + i61];
/* 169 */                 ntie = 1;
/*     */               } 
/*     */               
/* 172 */               int i59 = kn * stride$75 + j + offset$76; if (classpop$array[classpop$offset + i59] == pp) {
/* 173 */                 rf__.rrand_(new DoublePtr(xrand, 0));
/* 174 */                 float f = ntie; double d = (1.0F / f); xrand$200 = xrand[0]; if (((d <= xrand$200) ? false : true) != false) {
/* 175 */                   int i62 = kn + -1; nodeclass$array[nodeclass$offset + i62] = j;
/* 176 */                   int i61 = kn * stride$75 + j + offset$76; pp = classpop$array[classpop$offset + i61];
/*     */                 } 
/* 178 */                 ntie++;
/*     */               } 
/*     */               boolean bool1 = (j != i) ? false : true;
/*     */               j++;
/*     */               if (bool1 == false) {
/*     */                 continue;
/*     */               }
/*     */               break; }
/*     */           
/*     */           }
/*     */         } 
/*     */         boolean bool = (kn != m) ? false : true;
/*     */         kn++;
/*     */         if (bool == false) {
/*     */           continue;
/*     */         }
/*     */         break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void findbestsplit_(IntPtr a, IntPtr b, IntPtr cl, IntPtr mdim, IntPtr nsample, IntPtr nclass, IntPtr cat, IntPtr maxcat, IntPtr ndstart, IntPtr ndend, DoublePtr tclasspop, DoublePtr tclasscat, IntPtr msplit, DoublePtr decsplit, DoublePtr best, IntPtr ncase, IntPtr jstat, IntPtr mtry, DoublePtr win, DoublePtr wr, DoublePtr wl, IntPtr mred, IntPtr mind) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield array : [I
/*     */     //   4: astore #23
/*     */     //   6: aload_0
/*     */     //   7: getfield offset : I
/*     */     //   10: istore #24
/*     */     //   12: aload_1
/*     */     //   13: getfield array : [I
/*     */     //   16: astore #25
/*     */     //   18: aload_1
/*     */     //   19: getfield offset : I
/*     */     //   22: istore #26
/*     */     //   24: aload_2
/*     */     //   25: getfield array : [I
/*     */     //   28: astore #27
/*     */     //   30: aload_2
/*     */     //   31: getfield offset : I
/*     */     //   34: istore #28
/*     */     //   36: aload_3
/*     */     //   37: getfield array : [I
/*     */     //   40: astore #29
/*     */     //   42: aload_3
/*     */     //   43: getfield offset : I
/*     */     //   46: istore #30
/*     */     //   48: aload #4
/*     */     //   50: getfield array : [I
/*     */     //   53: astore #31
/*     */     //   55: aload #4
/*     */     //   57: getfield offset : I
/*     */     //   60: istore #32
/*     */     //   62: aload #5
/*     */     //   64: getfield array : [I
/*     */     //   67: astore #33
/*     */     //   69: aload #5
/*     */     //   71: getfield offset : I
/*     */     //   74: istore #34
/*     */     //   76: aload #6
/*     */     //   78: getfield array : [I
/*     */     //   81: astore #35
/*     */     //   83: aload #6
/*     */     //   85: getfield offset : I
/*     */     //   88: istore #36
/*     */     //   90: aload #7
/*     */     //   92: getfield array : [I
/*     */     //   95: astore #37
/*     */     //   97: aload #7
/*     */     //   99: getfield offset : I
/*     */     //   102: istore #38
/*     */     //   104: aload #8
/*     */     //   106: getfield array : [I
/*     */     //   109: astore #39
/*     */     //   111: aload #8
/*     */     //   113: getfield offset : I
/*     */     //   116: istore #40
/*     */     //   118: aload #9
/*     */     //   120: getfield array : [I
/*     */     //   123: astore #41
/*     */     //   125: aload #9
/*     */     //   127: getfield offset : I
/*     */     //   130: istore #42
/*     */     //   132: aload #10
/*     */     //   134: getfield array : [D
/*     */     //   137: astore #43
/*     */     //   139: aload #10
/*     */     //   141: getfield offset : I
/*     */     //   144: istore #44
/*     */     //   146: aload #11
/*     */     //   148: getfield array : [D
/*     */     //   151: astore #45
/*     */     //   153: aload #11
/*     */     //   155: getfield offset : I
/*     */     //   158: istore #46
/*     */     //   160: aload #12
/*     */     //   162: getfield array : [I
/*     */     //   165: astore #47
/*     */     //   167: aload #12
/*     */     //   169: getfield offset : I
/*     */     //   172: istore #48
/*     */     //   174: aload #13
/*     */     //   176: getfield array : [D
/*     */     //   179: astore #49
/*     */     //   181: aload #13
/*     */     //   183: getfield offset : I
/*     */     //   186: istore #50
/*     */     //   188: aload #14
/*     */     //   190: getfield array : [D
/*     */     //   193: astore #51
/*     */     //   195: aload #14
/*     */     //   197: getfield offset : I
/*     */     //   200: istore #52
/*     */     //   202: aload #15
/*     */     //   204: getfield array : [I
/*     */     //   207: astore #53
/*     */     //   209: aload #15
/*     */     //   211: getfield offset : I
/*     */     //   214: istore #54
/*     */     //   216: aload #16
/*     */     //   218: getfield array : [I
/*     */     //   221: astore #55
/*     */     //   223: aload #16
/*     */     //   225: getfield offset : I
/*     */     //   228: istore #56
/*     */     //   230: aload #17
/*     */     //   232: getfield array : [I
/*     */     //   235: astore #57
/*     */     //   237: aload #17
/*     */     //   239: getfield offset : I
/*     */     //   242: istore #58
/*     */     //   244: aload #18
/*     */     //   246: getfield array : [D
/*     */     //   249: astore #59
/*     */     //   251: aload #18
/*     */     //   253: getfield offset : I
/*     */     //   256: istore #60
/*     */     //   258: aload #19
/*     */     //   260: getfield array : [D
/*     */     //   263: astore #61
/*     */     //   265: aload #19
/*     */     //   267: getfield offset : I
/*     */     //   270: istore #62
/*     */     //   272: aload #20
/*     */     //   274: getfield array : [D
/*     */     //   277: astore #63
/*     */     //   279: aload #20
/*     */     //   281: getfield offset : I
/*     */     //   284: istore #64
/*     */     //   286: aload #21
/*     */     //   288: getfield array : [I
/*     */     //   291: astore #65
/*     */     //   293: aload #21
/*     */     //   295: getfield offset : I
/*     */     //   298: istore #66
/*     */     //   300: aload #22
/*     */     //   302: getfield array : [I
/*     */     //   305: astore #67
/*     */     //   307: aload #22
/*     */     //   309: getfield offset : I
/*     */     //   312: istore #68
/*     */     //   314: iconst_1
/*     */     //   315: newarray double
/*     */     //   317: astore #133
/*     */     //   319: iconst_1
/*     */     //   320: newarray double
/*     */     //   322: astore #160
/*     */     //   324: iconst_1
/*     */     //   325: newarray int
/*     */     //   327: astore #165
/*     */     //   329: iconst_1
/*     */     //   330: newarray int
/*     */     //   332: astore #166
/*     */     //   334: iconst_1
/*     */     //   335: newarray int
/*     */     //   337: astore #167
/*     */     //   339: iconst_1
/*     */     //   340: newarray int
/*     */     //   342: astore #175
/*     */     //   344: bipush #53
/*     */     //   346: newarray double
/*     */     //   348: astore #180
/*     */     //   350: iconst_1
/*     */     //   351: newarray double
/*     */     //   353: astore #181
/*     */     //   355: iconst_0
/*     */     //   356: istore #70
/*     */     //   358: iconst_0
/*     */     //   359: istore #72
/*     */     //   361: iconst_0
/*     */     //   362: istore #75
/*     */     //   364: iconst_0
/*     */     //   365: istore #80
/*     */     //   367: iconst_0
/*     */     //   368: istore #82
/*     */     //   370: iconst_0
/*     */     //   371: istore #84
/*     */     //   373: iconst_0
/*     */     //   374: istore #86
/*     */     //   376: iconst_0
/*     */     //   377: istore #88
/*     */     //   379: aload #133
/*     */     //   381: iconst_0
/*     */     //   382: dconst_0
/*     */     //   383: dastore
/*     */     //   384: iconst_0
/*     */     //   385: istore #145
/*     */     //   387: iconst_0
/*     */     //   388: istore #146
/*     */     //   390: dconst_0
/*     */     //   391: dstore #150
/*     */     //   393: dconst_0
/*     */     //   394: dstore #152
/*     */     //   396: dconst_0
/*     */     //   397: dstore #154
/*     */     //   399: dconst_0
/*     */     //   400: dstore #156
/*     */     //   402: dconst_0
/*     */     //   403: dstore #158
/*     */     //   405: aload #160
/*     */     //   407: iconst_0
/*     */     //   408: dconst_0
/*     */     //   409: dastore
/*     */     //   410: iconst_0
/*     */     //   411: istore #161
/*     */     //   413: iconst_0
/*     */     //   414: istore #163
/*     */     //   416: iconst_0
/*     */     //   417: istore #164
/*     */     //   419: aload #166
/*     */     //   421: iconst_0
/*     */     //   422: iconst_0
/*     */     //   423: iastore
/*     */     //   424: aload #167
/*     */     //   426: iconst_0
/*     */     //   427: iconst_0
/*     */     //   428: iastore
/*     */     //   429: iconst_0
/*     */     //   430: istore #171
/*     */     //   432: iconst_0
/*     */     //   433: istore #172
/*     */     //   435: aload #175
/*     */     //   437: iconst_0
/*     */     //   438: iconst_0
/*     */     //   439: iastore
/*     */     //   440: iconst_0
/*     */     //   441: istore #179
/*     */     //   443: aload #181
/*     */     //   445: iconst_0
/*     */     //   446: dconst_0
/*     */     //   447: dastore
/*     */     //   448: dconst_0
/*     */     //   449: dstore #182
/*     */     //   451: iconst_0
/*     */     //   452: istore #191
/*     */     //   454: iconst_0
/*     */     //   455: istore #192
/*     */     //   457: iconst_0
/*     */     //   458: istore #196
/*     */     //   460: iconst_0
/*     */     //   461: istore #197
/*     */     //   463: aload #33
/*     */     //   465: iload #34
/*     */     //   467: iaload
/*     */     //   468: istore #142
/*     */     //   470: iload #142
/*     */     //   472: iconst_0
/*     */     //   473: invokestatic max : (II)I
/*     */     //   476: istore #142
/*     */     //   478: iload #142
/*     */     //   480: iconst_m1
/*     */     //   481: iadd
/*     */     //   482: istore #92
/*     */     //   484: iload #142
/*     */     //   486: i2l
/*     */     //   487: ldc2_w 4294967295
/*     */     //   490: land
/*     */     //   491: ldc2_w 64
/*     */     //   494: lmul
/*     */     //   495: lstore #90
/*     */     //   497: iload #142
/*     */     //   499: bipush #8
/*     */     //   501: imul
/*     */     //   502: istore #89
/*     */     //   504: aload #65
/*     */     //   506: iload #66
/*     */     //   508: iaload
/*     */     //   509: istore #173
/*     */     //   511: iload #173
/*     */     //   513: iconst_0
/*     */     //   514: invokestatic max : (II)I
/*     */     //   517: istore #173
/*     */     //   519: iload #173
/*     */     //   521: iconst_m1
/*     */     //   522: iadd
/*     */     //   523: istore #96
/*     */     //   525: iload #173
/*     */     //   527: i2l
/*     */     //   528: ldc2_w 4294967295
/*     */     //   531: land
/*     */     //   532: ldc2_w 32
/*     */     //   535: lmul
/*     */     //   536: lstore #94
/*     */     //   538: iload #173
/*     */     //   540: iconst_4
/*     */     //   541: imul
/*     */     //   542: istore #93
/*     */     //   544: aload #29
/*     */     //   546: iload #30
/*     */     //   548: iaload
/*     */     //   549: istore #188
/*     */     //   551: iload #188
/*     */     //   553: iconst_0
/*     */     //   554: invokestatic max : (II)I
/*     */     //   557: istore #188
/*     */     //   559: iload #188
/*     */     //   561: iconst_m1
/*     */     //   562: iadd
/*     */     //   563: istore #100
/*     */     //   565: iload #188
/*     */     //   567: i2l
/*     */     //   568: ldc2_w 4294967295
/*     */     //   571: land
/*     */     //   572: ldc2_w 32
/*     */     //   575: lmul
/*     */     //   576: lstore #98
/*     */     //   578: iload #188
/*     */     //   580: iconst_4
/*     */     //   581: imul
/*     */     //   582: istore #97
/*     */     //   584: aload #33
/*     */     //   586: iload #34
/*     */     //   588: iaload
/*     */     //   589: istore #136
/*     */     //   591: iload #136
/*     */     //   593: iconst_0
/*     */     //   594: invokestatic max : (II)I
/*     */     //   597: istore #136
/*     */     //   599: iload #136
/*     */     //   601: iconst_m1
/*     */     //   602: iadd
/*     */     //   603: istore #104
/*     */     //   605: iload #136
/*     */     //   607: i2l
/*     */     //   608: ldc2_w 4294967295
/*     */     //   611: land
/*     */     //   612: ldc2_w 64
/*     */     //   615: lmul
/*     */     //   616: lstore #102
/*     */     //   618: iload #136
/*     */     //   620: bipush #8
/*     */     //   622: imul
/*     */     //   623: istore #101
/*     */     //   625: aload #33
/*     */     //   627: iload #34
/*     */     //   629: iaload
/*     */     //   630: istore #134
/*     */     //   632: iload #134
/*     */     //   634: iconst_0
/*     */     //   635: invokestatic max : (II)I
/*     */     //   638: istore #134
/*     */     //   640: iload #134
/*     */     //   642: iconst_m1
/*     */     //   643: iadd
/*     */     //   644: istore #108
/*     */     //   646: iload #134
/*     */     //   648: i2l
/*     */     //   649: ldc2_w 4294967295
/*     */     //   652: land
/*     */     //   653: ldc2_w 64
/*     */     //   656: lmul
/*     */     //   657: lstore #106
/*     */     //   659: iload #134
/*     */     //   661: bipush #8
/*     */     //   663: imul
/*     */     //   664: istore #105
/*     */     //   666: aload #29
/*     */     //   668: iload #30
/*     */     //   670: iaload
/*     */     //   671: istore #197
/*     */     //   673: iload #197
/*     */     //   675: iconst_0
/*     */     //   676: invokestatic max : (II)I
/*     */     //   679: istore #197
/*     */     //   681: aload #31
/*     */     //   683: iload #32
/*     */     //   685: iaload
/*     */     //   686: istore #198
/*     */     //   688: iload #197
/*     */     //   690: iload #198
/*     */     //   692: imul
/*     */     //   693: istore #195
/*     */     //   695: iload #195
/*     */     //   697: iconst_0
/*     */     //   698: invokestatic max : (II)I
/*     */     //   701: istore #195
/*     */     //   703: iload #195
/*     */     //   705: iconst_m1
/*     */     //   706: iadd
/*     */     //   707: istore #112
/*     */     //   709: iload #195
/*     */     //   711: i2l
/*     */     //   712: ldc2_w 4294967295
/*     */     //   715: land
/*     */     //   716: ldc2_w 32
/*     */     //   719: lmul
/*     */     //   720: lstore #110
/*     */     //   722: iload #195
/*     */     //   724: iconst_4
/*     */     //   725: imul
/*     */     //   726: istore #109
/*     */     //   728: iload #197
/*     */     //   730: iconst_m1
/*     */     //   731: ixor
/*     */     //   732: istore #196
/*     */     //   734: aload #31
/*     */     //   736: iload #32
/*     */     //   738: iaload
/*     */     //   739: istore #138
/*     */     //   741: iload #138
/*     */     //   743: iconst_0
/*     */     //   744: invokestatic max : (II)I
/*     */     //   747: istore #138
/*     */     //   749: iload #138
/*     */     //   751: iconst_m1
/*     */     //   752: iadd
/*     */     //   753: istore #116
/*     */     //   755: iload #138
/*     */     //   757: i2l
/*     */     //   758: ldc2_w 4294967295
/*     */     //   761: land
/*     */     //   762: ldc2_w 64
/*     */     //   765: lmul
/*     */     //   766: lstore #114
/*     */     //   768: iload #138
/*     */     //   770: bipush #8
/*     */     //   772: imul
/*     */     //   773: istore #113
/*     */     //   775: aload #31
/*     */     //   777: iload #32
/*     */     //   779: iaload
/*     */     //   780: istore #186
/*     */     //   782: iload #186
/*     */     //   784: iconst_0
/*     */     //   785: invokestatic max : (II)I
/*     */     //   788: istore #186
/*     */     //   790: iload #186
/*     */     //   792: iconst_m1
/*     */     //   793: iadd
/*     */     //   794: istore #120
/*     */     //   796: iload #186
/*     */     //   798: i2l
/*     */     //   799: ldc2_w 4294967295
/*     */     //   802: land
/*     */     //   803: ldc2_w 32
/*     */     //   806: lmul
/*     */     //   807: lstore #118
/*     */     //   809: iload #186
/*     */     //   811: iconst_4
/*     */     //   812: imul
/*     */     //   813: istore #117
/*     */     //   815: aload #29
/*     */     //   817: iload #30
/*     */     //   819: iaload
/*     */     //   820: istore #192
/*     */     //   822: iload #192
/*     */     //   824: iconst_0
/*     */     //   825: invokestatic max : (II)I
/*     */     //   828: istore #192
/*     */     //   830: aload #31
/*     */     //   832: iload #32
/*     */     //   834: iaload
/*     */     //   835: istore #193
/*     */     //   837: iload #192
/*     */     //   839: iload #193
/*     */     //   841: imul
/*     */     //   842: istore #190
/*     */     //   844: iload #190
/*     */     //   846: iconst_0
/*     */     //   847: invokestatic max : (II)I
/*     */     //   850: istore #190
/*     */     //   852: iload #190
/*     */     //   854: iconst_m1
/*     */     //   855: iadd
/*     */     //   856: istore #124
/*     */     //   858: iload #190
/*     */     //   860: i2l
/*     */     //   861: ldc2_w 4294967295
/*     */     //   864: land
/*     */     //   865: ldc2_w 32
/*     */     //   868: lmul
/*     */     //   869: lstore #122
/*     */     //   871: iload #190
/*     */     //   873: iconst_4
/*     */     //   874: imul
/*     */     //   875: istore #121
/*     */     //   877: iload #192
/*     */     //   879: iconst_m1
/*     */     //   880: ixor
/*     */     //   881: istore #191
/*     */     //   883: aload #33
/*     */     //   885: iload #34
/*     */     //   887: iaload
/*     */     //   888: istore #146
/*     */     //   890: iload #146
/*     */     //   892: iconst_0
/*     */     //   893: invokestatic max : (II)I
/*     */     //   896: istore #146
/*     */     //   898: iload #146
/*     */     //   900: bipush #53
/*     */     //   902: imul
/*     */     //   903: istore #144
/*     */     //   905: iload #144
/*     */     //   907: iconst_0
/*     */     //   908: invokestatic max : (II)I
/*     */     //   911: istore #144
/*     */     //   913: iload #144
/*     */     //   915: iconst_m1
/*     */     //   916: iadd
/*     */     //   917: istore #128
/*     */     //   919: iload #144
/*     */     //   921: i2l
/*     */     //   922: ldc2_w 4294967295
/*     */     //   925: land
/*     */     //   926: ldc2_w 64
/*     */     //   929: lmul
/*     */     //   930: lstore #126
/*     */     //   932: iload #144
/*     */     //   934: bipush #8
/*     */     //   936: imul
/*     */     //   937: istore #125
/*     */     //   939: iload #146
/*     */     //   941: iconst_m1
/*     */     //   942: ixor
/*     */     //   943: istore #145
/*     */     //   945: aload #31
/*     */     //   947: iload #32
/*     */     //   949: iaload
/*     */     //   950: istore #168
/*     */     //   952: iload #168
/*     */     //   954: iconst_0
/*     */     //   955: invokestatic max : (II)I
/*     */     //   958: istore #168
/*     */     //   960: iload #168
/*     */     //   962: iconst_m1
/*     */     //   963: iadd
/*     */     //   964: istore #132
/*     */     //   966: iload #168
/*     */     //   968: i2l
/*     */     //   969: ldc2_w 4294967295
/*     */     //   972: land
/*     */     //   973: ldc2_w 32
/*     */     //   976: lmul
/*     */     //   977: lstore #130
/*     */     //   979: iload #168
/*     */     //   981: iconst_4
/*     */     //   982: imul
/*     */     //   983: istore #129
/*     */     //   985: aload #167
/*     */     //   987: iconst_0
/*     */     //   988: bipush #10
/*     */     //   990: iastore
/*     */     //   991: aload #166
/*     */     //   993: iconst_0
/*     */     //   994: sipush #512
/*     */     //   997: iastore
/*     */     //   998: dconst_0
/*     */     //   999: dstore #158
/*     */     //   1001: aload #160
/*     */     //   1003: iconst_0
/*     */     //   1004: dconst_0
/*     */     //   1005: dastore
/*     */     //   1006: aload #33
/*     */     //   1008: iload #34
/*     */     //   1010: iaload
/*     */     //   1011: istore #88
/*     */     //   1013: iconst_1
/*     */     //   1014: istore #178
/*     */     //   1016: iload #178
/*     */     //   1018: iload #88
/*     */     //   1020: if_icmple -> 1026
/*     */     //   1023: goto -> 1167
/*     */     //   1026: iload #178
/*     */     //   1028: iconst_m1
/*     */     //   1029: iadd
/*     */     //   1030: wide istore #359
/*     */     //   1034: aload #43
/*     */     //   1036: iload #44
/*     */     //   1038: wide iload #359
/*     */     //   1042: iadd
/*     */     //   1043: daload
/*     */     //   1044: wide dstore #357
/*     */     //   1048: iload #178
/*     */     //   1050: iconst_m1
/*     */     //   1051: iadd
/*     */     //   1052: wide istore #356
/*     */     //   1056: aload #43
/*     */     //   1058: iload #44
/*     */     //   1060: wide iload #356
/*     */     //   1064: iadd
/*     */     //   1065: daload
/*     */     //   1066: wide dstore #354
/*     */     //   1070: wide dload #357
/*     */     //   1074: wide dload #354
/*     */     //   1078: dmul
/*     */     //   1079: dload #158
/*     */     //   1081: dadd
/*     */     //   1082: dstore #158
/*     */     //   1084: iload #178
/*     */     //   1086: iconst_m1
/*     */     //   1087: iadd
/*     */     //   1088: wide istore #351
/*     */     //   1092: aload #43
/*     */     //   1094: iload #44
/*     */     //   1096: wide iload #351
/*     */     //   1100: iadd
/*     */     //   1101: daload
/*     */     //   1102: wide dstore #349
/*     */     //   1106: aload #160
/*     */     //   1108: iconst_0
/*     */     //   1109: daload
/*     */     //   1110: wide dstore #347
/*     */     //   1114: wide dload #349
/*     */     //   1118: wide dload #347
/*     */     //   1122: dadd
/*     */     //   1123: wide dstore #345
/*     */     //   1127: aload #160
/*     */     //   1129: iconst_0
/*     */     //   1130: wide dload #345
/*     */     //   1134: dastore
/*     */     //   1135: iload #178
/*     */     //   1137: iload #88
/*     */     //   1139: if_icmpeq -> 1149
/*     */     //   1142: goto -> 1145
/*     */     //   1145: iconst_0
/*     */     //   1146: goto -> 1150
/*     */     //   1149: iconst_1
/*     */     //   1150: istore #87
/*     */     //   1152: iinc #178, 1
/*     */     //   1155: iload #87
/*     */     //   1157: iconst_0
/*     */     //   1158: if_icmpne -> 1167
/*     */     //   1161: goto -> 1164
/*     */     //   1164: goto -> 1026
/*     */     //   1167: aload #160
/*     */     //   1169: iconst_0
/*     */     //   1170: daload
/*     */     //   1171: wide dstore #343
/*     */     //   1175: dload #158
/*     */     //   1177: wide dload #343
/*     */     //   1181: ddiv
/*     */     //   1182: dstore #182
/*     */     //   1184: aload #55
/*     */     //   1186: iload #56
/*     */     //   1188: iconst_0
/*     */     //   1189: iastore
/*     */     //   1190: aload #181
/*     */     //   1192: iconst_0
/*     */     //   1193: ldc2_w -9.999999562023526E24
/*     */     //   1196: dastore
/*     */     //   1197: aload #65
/*     */     //   1199: iload #66
/*     */     //   1201: iaload
/*     */     //   1202: istore #86
/*     */     //   1204: iconst_1
/*     */     //   1205: istore #177
/*     */     //   1207: iload #177
/*     */     //   1209: iload #86
/*     */     //   1211: if_icmple -> 1217
/*     */     //   1214: goto -> 1269
/*     */     //   1217: iload #177
/*     */     //   1219: iconst_m1
/*     */     //   1220: iadd
/*     */     //   1221: wide istore #342
/*     */     //   1225: aload #67
/*     */     //   1227: iload #68
/*     */     //   1229: wide iload #342
/*     */     //   1233: iadd
/*     */     //   1234: iload #177
/*     */     //   1236: iastore
/*     */     //   1237: iload #177
/*     */     //   1239: iload #86
/*     */     //   1241: if_icmpeq -> 1251
/*     */     //   1244: goto -> 1247
/*     */     //   1247: iconst_0
/*     */     //   1248: goto -> 1252
/*     */     //   1251: iconst_1
/*     */     //   1252: istore #85
/*     */     //   1254: iinc #177, 1
/*     */     //   1257: iload #85
/*     */     //   1259: iconst_0
/*     */     //   1260: if_icmpne -> 1269
/*     */     //   1263: goto -> 1266
/*     */     //   1266: goto -> 1217
/*     */     //   1269: aload #65
/*     */     //   1271: iload #66
/*     */     //   1273: iaload
/*     */     //   1274: istore #164
/*     */     //   1276: aload #57
/*     */     //   1278: iload #58
/*     */     //   1280: iaload
/*     */     //   1281: istore #84
/*     */     //   1283: iconst_1
/*     */     //   1284: istore #172
/*     */     //   1286: iload #172
/*     */     //   1288: iload #84
/*     */     //   1290: if_icmple -> 1296
/*     */     //   1293: goto -> 3059
/*     */     //   1296: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   1299: dup
/*     */     //   1300: aload #133
/*     */     //   1302: iconst_0
/*     */     //   1303: invokespecial <init> : ([DI)V
/*     */     //   1306: invokestatic rrand_ : (Lorg/renjin/gcc/runtime/DoublePtr;)V
/*     */     //   1309: iload #164
/*     */     //   1311: i2d
/*     */     //   1312: wide dstore #340
/*     */     //   1316: aload #133
/*     */     //   1318: iconst_0
/*     */     //   1319: daload
/*     */     //   1320: wide dstore #338
/*     */     //   1324: wide dload #340
/*     */     //   1328: wide dload #338
/*     */     //   1332: dmul
/*     */     //   1333: d2l
/*     */     //   1334: l2i
/*     */     //   1335: iconst_1
/*     */     //   1336: iadd
/*     */     //   1337: istore #178
/*     */     //   1339: iload #178
/*     */     //   1341: iconst_m1
/*     */     //   1342: iadd
/*     */     //   1343: wide istore #334
/*     */     //   1347: aload #67
/*     */     //   1349: iload #68
/*     */     //   1351: wide iload #334
/*     */     //   1355: iadd
/*     */     //   1356: iaload
/*     */     //   1357: istore #171
/*     */     //   1359: iload #178
/*     */     //   1361: iconst_m1
/*     */     //   1362: iadd
/*     */     //   1363: wide istore #333
/*     */     //   1367: iload #164
/*     */     //   1369: iconst_m1
/*     */     //   1370: iadd
/*     */     //   1371: wide istore #332
/*     */     //   1375: aload #67
/*     */     //   1377: iload #68
/*     */     //   1379: wide iload #332
/*     */     //   1383: iadd
/*     */     //   1384: iaload
/*     */     //   1385: wide istore #331
/*     */     //   1389: aload #67
/*     */     //   1391: iload #68
/*     */     //   1393: wide iload #333
/*     */     //   1397: iadd
/*     */     //   1398: wide iload #331
/*     */     //   1402: iastore
/*     */     //   1403: iload #164
/*     */     //   1405: iconst_m1
/*     */     //   1406: iadd
/*     */     //   1407: wide istore #330
/*     */     //   1411: aload #67
/*     */     //   1413: iload #68
/*     */     //   1415: wide iload #330
/*     */     //   1419: iadd
/*     */     //   1420: iload #171
/*     */     //   1422: iastore
/*     */     //   1423: iinc #164, -1
/*     */     //   1426: iload #171
/*     */     //   1428: iconst_m1
/*     */     //   1429: iadd
/*     */     //   1430: wide istore #329
/*     */     //   1434: aload #35
/*     */     //   1436: iload #36
/*     */     //   1438: wide iload #329
/*     */     //   1442: iadd
/*     */     //   1443: iaload
/*     */     //   1444: wide istore #328
/*     */     //   1448: aload #175
/*     */     //   1450: iconst_0
/*     */     //   1451: wide iload #328
/*     */     //   1455: iastore
/*     */     //   1456: aload #175
/*     */     //   1458: iconst_0
/*     */     //   1459: iaload
/*     */     //   1460: iconst_1
/*     */     //   1461: if_icmpeq -> 1467
/*     */     //   1464: goto -> 2307
/*     */     //   1467: dload #158
/*     */     //   1469: dstore #150
/*     */     //   1471: aload #160
/*     */     //   1473: iconst_0
/*     */     //   1474: daload
/*     */     //   1475: dstore #152
/*     */     //   1477: dconst_0
/*     */     //   1478: dstore #154
/*     */     //   1480: dconst_0
/*     */     //   1481: dstore #156
/*     */     //   1483: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   1486: dup
/*     */     //   1487: aload #63
/*     */     //   1489: iload #64
/*     */     //   1491: invokespecial <init> : ([DI)V
/*     */     //   1494: new org/renjin/gcc/runtime/IntPtr
/*     */     //   1497: dup
/*     */     //   1498: aload #33
/*     */     //   1500: iload #34
/*     */     //   1502: invokespecial <init> : ([II)V
/*     */     //   1505: invokestatic zervr_ : (Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;)V
/*     */     //   1508: aload #33
/*     */     //   1510: iload #34
/*     */     //   1512: iaload
/*     */     //   1513: istore #82
/*     */     //   1515: iconst_1
/*     */     //   1516: istore #178
/*     */     //   1518: iload #178
/*     */     //   1520: iload #82
/*     */     //   1522: if_icmple -> 1528
/*     */     //   1525: goto -> 1604
/*     */     //   1528: iload #178
/*     */     //   1530: iconst_m1
/*     */     //   1531: iadd
/*     */     //   1532: wide istore #326
/*     */     //   1536: iload #178
/*     */     //   1538: iconst_m1
/*     */     //   1539: iadd
/*     */     //   1540: wide istore #325
/*     */     //   1544: aload #43
/*     */     //   1546: iload #44
/*     */     //   1548: wide iload #325
/*     */     //   1552: iadd
/*     */     //   1553: daload
/*     */     //   1554: wide dstore #323
/*     */     //   1558: aload #61
/*     */     //   1560: iload #62
/*     */     //   1562: wide iload #326
/*     */     //   1566: iadd
/*     */     //   1567: wide dload #323
/*     */     //   1571: dastore
/*     */     //   1572: iload #178
/*     */     //   1574: iload #82
/*     */     //   1576: if_icmpeq -> 1586
/*     */     //   1579: goto -> 1582
/*     */     //   1582: iconst_0
/*     */     //   1583: goto -> 1587
/*     */     //   1586: iconst_1
/*     */     //   1587: istore #81
/*     */     //   1589: iinc #178, 1
/*     */     //   1592: iload #81
/*     */     //   1594: iconst_0
/*     */     //   1595: if_icmpne -> 1604
/*     */     //   1598: goto -> 1601
/*     */     //   1601: goto -> 1528
/*     */     //   1604: iconst_1
/*     */     //   1605: istore #161
/*     */     //   1607: aload #39
/*     */     //   1609: iload #40
/*     */     //   1611: iaload
/*     */     //   1612: istore #79
/*     */     //   1614: aload #41
/*     */     //   1616: iload #42
/*     */     //   1618: iaload
/*     */     //   1619: iconst_m1
/*     */     //   1620: iadd
/*     */     //   1621: istore #80
/*     */     //   1623: iload #79
/*     */     //   1625: istore #162
/*     */     //   1627: iload #162
/*     */     //   1629: iload #80
/*     */     //   1631: if_icmple -> 1637
/*     */     //   1634: goto -> 3027
/*     */     //   1637: iload #162
/*     */     //   1639: iload #197
/*     */     //   1641: imul
/*     */     //   1642: iload #171
/*     */     //   1644: iadd
/*     */     //   1645: iload #196
/*     */     //   1647: iadd
/*     */     //   1648: wide istore #319
/*     */     //   1652: aload #23
/*     */     //   1654: iload #24
/*     */     //   1656: wide iload #319
/*     */     //   1660: iadd
/*     */     //   1661: iaload
/*     */     //   1662: istore #170
/*     */     //   1664: iload #170
/*     */     //   1666: iconst_m1
/*     */     //   1667: iadd
/*     */     //   1668: wide istore #318
/*     */     //   1672: aload #59
/*     */     //   1674: iload #60
/*     */     //   1676: wide iload #318
/*     */     //   1680: iadd
/*     */     //   1681: daload
/*     */     //   1682: dstore #140
/*     */     //   1684: iload #170
/*     */     //   1686: iconst_m1
/*     */     //   1687: iadd
/*     */     //   1688: wide istore #317
/*     */     //   1692: aload #27
/*     */     //   1694: iload #28
/*     */     //   1696: wide iload #317
/*     */     //   1700: iadd
/*     */     //   1701: iaload
/*     */     //   1702: istore #177
/*     */     //   1704: iload #177
/*     */     //   1706: iconst_m1
/*     */     //   1707: iadd
/*     */     //   1708: wide istore #316
/*     */     //   1712: aload #63
/*     */     //   1714: iload #64
/*     */     //   1716: wide iload #316
/*     */     //   1720: iadd
/*     */     //   1721: daload
/*     */     //   1722: ldc2_w 2.0
/*     */     //   1725: dmul
/*     */     //   1726: dload #140
/*     */     //   1728: dadd
/*     */     //   1729: dload #140
/*     */     //   1731: dmul
/*     */     //   1732: dload #154
/*     */     //   1734: dadd
/*     */     //   1735: dstore #154
/*     */     //   1737: iload #177
/*     */     //   1739: iconst_m1
/*     */     //   1740: iadd
/*     */     //   1741: wide istore #305
/*     */     //   1745: aload #61
/*     */     //   1747: iload #62
/*     */     //   1749: wide iload #305
/*     */     //   1753: iadd
/*     */     //   1754: daload
/*     */     //   1755: ldc2_w 2.0
/*     */     //   1758: dmul
/*     */     //   1759: wide dstore #301
/*     */     //   1763: dload #140
/*     */     //   1765: wide dload #301
/*     */     //   1769: dsub
/*     */     //   1770: dload #140
/*     */     //   1772: dmul
/*     */     //   1773: dload #150
/*     */     //   1775: dadd
/*     */     //   1776: dstore #150
/*     */     //   1778: dload #156
/*     */     //   1780: dload #140
/*     */     //   1782: dadd
/*     */     //   1783: dstore #156
/*     */     //   1785: dload #152
/*     */     //   1787: dload #140
/*     */     //   1789: dsub
/*     */     //   1790: dstore #152
/*     */     //   1792: iload #177
/*     */     //   1794: iconst_m1
/*     */     //   1795: iadd
/*     */     //   1796: wide istore #294
/*     */     //   1800: iload #177
/*     */     //   1802: iconst_m1
/*     */     //   1803: iadd
/*     */     //   1804: wide istore #293
/*     */     //   1808: aload #63
/*     */     //   1810: iload #64
/*     */     //   1812: wide iload #293
/*     */     //   1816: iadd
/*     */     //   1817: daload
/*     */     //   1818: dload #140
/*     */     //   1820: dadd
/*     */     //   1821: wide dstore #289
/*     */     //   1825: aload #63
/*     */     //   1827: iload #64
/*     */     //   1829: wide iload #294
/*     */     //   1833: iadd
/*     */     //   1834: wide dload #289
/*     */     //   1838: dastore
/*     */     //   1839: iload #177
/*     */     //   1841: iconst_m1
/*     */     //   1842: iadd
/*     */     //   1843: wide istore #288
/*     */     //   1847: iload #177
/*     */     //   1849: iconst_m1
/*     */     //   1850: iadd
/*     */     //   1851: wide istore #287
/*     */     //   1855: aload #61
/*     */     //   1857: iload #62
/*     */     //   1859: wide iload #287
/*     */     //   1863: iadd
/*     */     //   1864: daload
/*     */     //   1865: dload #140
/*     */     //   1867: dsub
/*     */     //   1868: wide dstore #283
/*     */     //   1872: aload #61
/*     */     //   1874: iload #62
/*     */     //   1876: wide iload #288
/*     */     //   1880: iadd
/*     */     //   1881: wide dload #283
/*     */     //   1885: dastore
/*     */     //   1886: iload #170
/*     */     //   1888: iload #192
/*     */     //   1890: imul
/*     */     //   1891: iload #171
/*     */     //   1893: iadd
/*     */     //   1894: iload #191
/*     */     //   1896: iadd
/*     */     //   1897: wide istore #280
/*     */     //   1901: aload #25
/*     */     //   1903: iload #26
/*     */     //   1905: wide iload #280
/*     */     //   1909: iadd
/*     */     //   1910: iaload
/*     */     //   1911: wide istore #279
/*     */     //   1915: iload #162
/*     */     //   1917: iconst_1
/*     */     //   1918: iadd
/*     */     //   1919: iload #197
/*     */     //   1921: imul
/*     */     //   1922: iload #171
/*     */     //   1924: iadd
/*     */     //   1925: iload #196
/*     */     //   1927: iadd
/*     */     //   1928: wide istore #275
/*     */     //   1932: aload #23
/*     */     //   1934: iload #24
/*     */     //   1936: wide iload #275
/*     */     //   1940: iadd
/*     */     //   1941: iaload
/*     */     //   1942: iload #192
/*     */     //   1944: imul
/*     */     //   1945: iload #171
/*     */     //   1947: iadd
/*     */     //   1948: iload #191
/*     */     //   1950: iadd
/*     */     //   1951: wide istore #271
/*     */     //   1955: aload #25
/*     */     //   1957: iload #26
/*     */     //   1959: wide iload #271
/*     */     //   1963: iadd
/*     */     //   1964: iaload
/*     */     //   1965: wide istore #270
/*     */     //   1969: wide iload #279
/*     */     //   1973: wide iload #270
/*     */     //   1977: if_icmplt -> 1983
/*     */     //   1980: goto -> 2275
/*     */     //   1983: dload #152
/*     */     //   1985: dstore #76
/*     */     //   1987: dload #156
/*     */     //   1989: dload #76
/*     */     //   1991: dcmpg
/*     */     //   1992: iflt -> 2002
/*     */     //   1995: goto -> 1998
/*     */     //   1998: iconst_0
/*     */     //   1999: goto -> 2003
/*     */     //   2002: iconst_1
/*     */     //   2003: wide istore #269
/*     */     //   2007: dload #76
/*     */     //   2009: invokestatic isNaN : (D)Z
/*     */     //   2012: ifne -> 2027
/*     */     //   2015: dload #76
/*     */     //   2017: invokestatic isNaN : (D)Z
/*     */     //   2020: ifne -> 2027
/*     */     //   2023: iconst_0
/*     */     //   2024: goto -> 2028
/*     */     //   2027: iconst_1
/*     */     //   2028: wide istore #268
/*     */     //   2032: wide iload #269
/*     */     //   2036: ifne -> 2050
/*     */     //   2039: wide iload #268
/*     */     //   2043: ifne -> 2050
/*     */     //   2046: iconst_0
/*     */     //   2047: goto -> 2051
/*     */     //   2050: iconst_1
/*     */     //   2051: iconst_0
/*     */     //   2052: if_icmpne -> 2058
/*     */     //   2055: goto -> 2062
/*     */     //   2058: dload #156
/*     */     //   2060: dstore #76
/*     */     //   2062: dload #76
/*     */     //   2064: ldc2_w 9.999999747378752E-6
/*     */     //   2067: dcmpl
/*     */     //   2068: ifgt -> 2078
/*     */     //   2071: goto -> 2074
/*     */     //   2074: iconst_0
/*     */     //   2075: goto -> 2079
/*     */     //   2078: iconst_1
/*     */     //   2079: iconst_0
/*     */     //   2080: if_icmpne -> 2086
/*     */     //   2083: goto -> 2275
/*     */     //   2086: dload #154
/*     */     //   2088: dload #156
/*     */     //   2090: ddiv
/*     */     //   2091: wide dstore #262
/*     */     //   2095: dload #150
/*     */     //   2097: dload #152
/*     */     //   2099: ddiv
/*     */     //   2100: wide dstore #258
/*     */     //   2104: wide dload #262
/*     */     //   2108: wide dload #258
/*     */     //   2112: dadd
/*     */     //   2113: dstore #184
/*     */     //   2115: aload #181
/*     */     //   2117: iconst_0
/*     */     //   2118: daload
/*     */     //   2119: wide dstore #256
/*     */     //   2123: dload #184
/*     */     //   2125: wide dload #256
/*     */     //   2129: dcmpl
/*     */     //   2130: ifgt -> 2140
/*     */     //   2133: goto -> 2136
/*     */     //   2136: iconst_0
/*     */     //   2137: goto -> 2141
/*     */     //   2140: iconst_1
/*     */     //   2141: iconst_0
/*     */     //   2142: if_icmpne -> 2148
/*     */     //   2145: goto -> 2176
/*     */     //   2148: iload #162
/*     */     //   2150: i2d
/*     */     //   2151: dstore #253
/*     */     //   2153: aload #51
/*     */     //   2155: iload #52
/*     */     //   2157: dload #253
/*     */     //   2159: dastore
/*     */     //   2160: aload #181
/*     */     //   2162: iconst_0
/*     */     //   2163: dload #184
/*     */     //   2165: dastore
/*     */     //   2166: aload #47
/*     */     //   2168: iload #48
/*     */     //   2170: iload #171
/*     */     //   2172: iastore
/*     */     //   2173: iconst_1
/*     */     //   2174: istore #161
/*     */     //   2176: aload #181
/*     */     //   2178: iconst_0
/*     */     //   2179: daload
/*     */     //   2180: dstore #251
/*     */     //   2182: dload #184
/*     */     //   2184: dload #251
/*     */     //   2186: dcmpl
/*     */     //   2187: ifeq -> 2193
/*     */     //   2190: goto -> 2275
/*     */     //   2193: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2196: dup
/*     */     //   2197: aload #133
/*     */     //   2199: iconst_0
/*     */     //   2200: invokespecial <init> : ([DI)V
/*     */     //   2203: invokestatic rrand_ : (Lorg/renjin/gcc/runtime/DoublePtr;)V
/*     */     //   2206: iload #161
/*     */     //   2208: i2f
/*     */     //   2209: fstore #250
/*     */     //   2211: fconst_1
/*     */     //   2212: fload #250
/*     */     //   2214: fdiv
/*     */     //   2215: f2d
/*     */     //   2216: dstore #247
/*     */     //   2218: aload #133
/*     */     //   2220: iconst_0
/*     */     //   2221: daload
/*     */     //   2222: dstore #245
/*     */     //   2224: dload #247
/*     */     //   2226: dload #245
/*     */     //   2228: dcmpl
/*     */     //   2229: ifgt -> 2239
/*     */     //   2232: goto -> 2235
/*     */     //   2235: iconst_0
/*     */     //   2236: goto -> 2240
/*     */     //   2239: iconst_1
/*     */     //   2240: iconst_0
/*     */     //   2241: if_icmpne -> 2247
/*     */     //   2244: goto -> 2272
/*     */     //   2247: iload #162
/*     */     //   2249: i2d
/*     */     //   2250: dstore #242
/*     */     //   2252: aload #51
/*     */     //   2254: iload #52
/*     */     //   2256: dload #242
/*     */     //   2258: dastore
/*     */     //   2259: aload #181
/*     */     //   2261: iconst_0
/*     */     //   2262: dload #184
/*     */     //   2264: dastore
/*     */     //   2265: aload #47
/*     */     //   2267: iload #48
/*     */     //   2269: iload #171
/*     */     //   2271: iastore
/*     */     //   2272: iinc #161, 1
/*     */     //   2275: iload #162
/*     */     //   2277: iload #80
/*     */     //   2279: if_icmpeq -> 2289
/*     */     //   2282: goto -> 2285
/*     */     //   2285: iconst_0
/*     */     //   2286: goto -> 2290
/*     */     //   2289: iconst_1
/*     */     //   2290: istore #78
/*     */     //   2292: iinc #162, 1
/*     */     //   2295: iload #78
/*     */     //   2297: iconst_0
/*     */     //   2298: if_icmpne -> 3027
/*     */     //   2301: goto -> 2304
/*     */     //   2304: goto -> 1637
/*     */     //   2307: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2310: dup
/*     */     //   2311: aload #45
/*     */     //   2313: iload #46
/*     */     //   2315: invokespecial <init> : ([DI)V
/*     */     //   2318: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2321: dup
/*     */     //   2322: aload #33
/*     */     //   2324: iload #34
/*     */     //   2326: invokespecial <init> : ([II)V
/*     */     //   2329: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2332: dup
/*     */     //   2333: iconst_1
/*     */     //   2334: newarray int
/*     */     //   2336: dup
/*     */     //   2337: iconst_0
/*     */     //   2338: bipush #53
/*     */     //   2340: iastore
/*     */     //   2341: iconst_0
/*     */     //   2342: invokespecial <init> : ([II)V
/*     */     //   2345: invokestatic zermr_ : (Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;)V
/*     */     //   2348: aload #39
/*     */     //   2350: iload #40
/*     */     //   2352: iaload
/*     */     //   2353: istore #74
/*     */     //   2355: aload #41
/*     */     //   2357: iload #42
/*     */     //   2359: iaload
/*     */     //   2360: istore #75
/*     */     //   2362: iload #74
/*     */     //   2364: istore #162
/*     */     //   2366: iload #162
/*     */     //   2368: iload #75
/*     */     //   2370: if_icmple -> 2376
/*     */     //   2373: goto -> 2568
/*     */     //   2376: iload #162
/*     */     //   2378: iconst_m1
/*     */     //   2379: iadd
/*     */     //   2380: istore #241
/*     */     //   2382: aload #53
/*     */     //   2384: iload #54
/*     */     //   2386: iload #241
/*     */     //   2388: iadd
/*     */     //   2389: iaload
/*     */     //   2390: istore #170
/*     */     //   2392: iload #162
/*     */     //   2394: iconst_m1
/*     */     //   2395: iadd
/*     */     //   2396: istore #240
/*     */     //   2398: aload #53
/*     */     //   2400: iload #54
/*     */     //   2402: iload #240
/*     */     //   2404: iadd
/*     */     //   2405: iaload
/*     */     //   2406: iload #197
/*     */     //   2408: imul
/*     */     //   2409: iload #171
/*     */     //   2411: iadd
/*     */     //   2412: iload #196
/*     */     //   2414: iadd
/*     */     //   2415: istore #236
/*     */     //   2417: aload #23
/*     */     //   2419: iload #24
/*     */     //   2421: iload #236
/*     */     //   2423: iadd
/*     */     //   2424: iaload
/*     */     //   2425: istore #176
/*     */     //   2427: iload #170
/*     */     //   2429: iconst_m1
/*     */     //   2430: iadd
/*     */     //   2431: istore #235
/*     */     //   2433: aload #27
/*     */     //   2435: iload #28
/*     */     //   2437: iload #235
/*     */     //   2439: iadd
/*     */     //   2440: iaload
/*     */     //   2441: istore #234
/*     */     //   2443: iload #176
/*     */     //   2445: iload #146
/*     */     //   2447: imul
/*     */     //   2448: istore #233
/*     */     //   2450: iload #234
/*     */     //   2452: iload #233
/*     */     //   2454: iadd
/*     */     //   2455: iload #145
/*     */     //   2457: iadd
/*     */     //   2458: istore #231
/*     */     //   2460: iload #170
/*     */     //   2462: iconst_m1
/*     */     //   2463: iadd
/*     */     //   2464: istore #230
/*     */     //   2466: aload #27
/*     */     //   2468: iload #28
/*     */     //   2470: iload #230
/*     */     //   2472: iadd
/*     */     //   2473: iaload
/*     */     //   2474: istore #229
/*     */     //   2476: iload #176
/*     */     //   2478: iload #146
/*     */     //   2480: imul
/*     */     //   2481: istore #228
/*     */     //   2483: iload #229
/*     */     //   2485: iload #228
/*     */     //   2487: iadd
/*     */     //   2488: iload #145
/*     */     //   2490: iadd
/*     */     //   2491: istore #226
/*     */     //   2493: aload #45
/*     */     //   2495: iload #46
/*     */     //   2497: iload #226
/*     */     //   2499: iadd
/*     */     //   2500: daload
/*     */     //   2501: dstore #224
/*     */     //   2503: iload #170
/*     */     //   2505: iconst_m1
/*     */     //   2506: iadd
/*     */     //   2507: istore #223
/*     */     //   2509: aload #59
/*     */     //   2511: iload #60
/*     */     //   2513: iload #223
/*     */     //   2515: iadd
/*     */     //   2516: daload
/*     */     //   2517: dstore #221
/*     */     //   2519: dload #224
/*     */     //   2521: dload #221
/*     */     //   2523: dadd
/*     */     //   2524: dstore #219
/*     */     //   2526: aload #45
/*     */     //   2528: iload #46
/*     */     //   2530: iload #231
/*     */     //   2532: iadd
/*     */     //   2533: dload #219
/*     */     //   2535: dastore
/*     */     //   2536: iload #162
/*     */     //   2538: iload #75
/*     */     //   2540: if_icmpeq -> 2550
/*     */     //   2543: goto -> 2546
/*     */     //   2546: iconst_0
/*     */     //   2547: goto -> 2551
/*     */     //   2550: iconst_1
/*     */     //   2551: istore #73
/*     */     //   2553: iinc #162, 1
/*     */     //   2556: iload #73
/*     */     //   2558: iconst_0
/*     */     //   2559: if_icmpne -> 2568
/*     */     //   2562: goto -> 2565
/*     */     //   2565: goto -> 2376
/*     */     //   2568: iconst_0
/*     */     //   2569: istore #163
/*     */     //   2571: aload #175
/*     */     //   2573: iconst_0
/*     */     //   2574: iaload
/*     */     //   2575: istore #72
/*     */     //   2577: iconst_1
/*     */     //   2578: istore #179
/*     */     //   2580: iload #179
/*     */     //   2582: iload #72
/*     */     //   2584: if_icmple -> 2590
/*     */     //   2587: goto -> 2743
/*     */     //   2590: dconst_0
/*     */     //   2591: dstore #148
/*     */     //   2593: aload #33
/*     */     //   2595: iload #34
/*     */     //   2597: iaload
/*     */     //   2598: istore #70
/*     */     //   2600: iconst_1
/*     */     //   2601: istore #178
/*     */     //   2603: iload #178
/*     */     //   2605: iload #70
/*     */     //   2607: if_icmple -> 2613
/*     */     //   2610: goto -> 2671
/*     */     //   2613: iload #179
/*     */     //   2615: iload #146
/*     */     //   2617: imul
/*     */     //   2618: iload #178
/*     */     //   2620: iadd
/*     */     //   2621: iload #145
/*     */     //   2623: iadd
/*     */     //   2624: istore #216
/*     */     //   2626: aload #45
/*     */     //   2628: iload #46
/*     */     //   2630: iload #216
/*     */     //   2632: iadd
/*     */     //   2633: daload
/*     */     //   2634: dload #148
/*     */     //   2636: dadd
/*     */     //   2637: dstore #148
/*     */     //   2639: iload #178
/*     */     //   2641: iload #70
/*     */     //   2643: if_icmpeq -> 2653
/*     */     //   2646: goto -> 2649
/*     */     //   2649: iconst_0
/*     */     //   2650: goto -> 2654
/*     */     //   2653: iconst_1
/*     */     //   2654: istore #69
/*     */     //   2656: iinc #178, 1
/*     */     //   2659: iload #69
/*     */     //   2661: iconst_0
/*     */     //   2662: if_icmpne -> 2671
/*     */     //   2665: goto -> 2668
/*     */     //   2668: goto -> 2613
/*     */     //   2671: iload #179
/*     */     //   2673: iconst_m1
/*     */     //   2674: iadd
/*     */     //   2675: istore #213
/*     */     //   2677: aload #180
/*     */     //   2679: iconst_0
/*     */     //   2680: iload #213
/*     */     //   2682: iadd
/*     */     //   2683: dload #148
/*     */     //   2685: dastore
/*     */     //   2686: dload #148
/*     */     //   2688: dconst_0
/*     */     //   2689: dcmpl
/*     */     //   2690: ifgt -> 2700
/*     */     //   2693: goto -> 2696
/*     */     //   2696: iconst_0
/*     */     //   2697: goto -> 2701
/*     */     //   2700: iconst_1
/*     */     //   2701: iconst_0
/*     */     //   2702: if_icmpne -> 2708
/*     */     //   2705: goto -> 2711
/*     */     //   2708: iinc #163, 1
/*     */     //   2711: iload #179
/*     */     //   2713: iload #72
/*     */     //   2715: if_icmpeq -> 2725
/*     */     //   2718: goto -> 2721
/*     */     //   2721: iconst_0
/*     */     //   2722: goto -> 2726
/*     */     //   2725: iconst_1
/*     */     //   2726: istore #71
/*     */     //   2728: iinc #179, 1
/*     */     //   2731: iload #71
/*     */     //   2733: iconst_0
/*     */     //   2734: if_icmpne -> 2743
/*     */     //   2737: goto -> 2740
/*     */     //   2740: goto -> 2590
/*     */     //   2743: aload #165
/*     */     //   2745: iconst_0
/*     */     //   2746: iconst_0
/*     */     //   2747: iastore
/*     */     //   2748: iload #163
/*     */     //   2750: iconst_1
/*     */     //   2751: if_icmpgt -> 2757
/*     */     //   2754: goto -> 3027
/*     */     //   2757: aload #33
/*     */     //   2759: iload #34
/*     */     //   2761: iaload
/*     */     //   2762: iconst_2
/*     */     //   2763: if_icmpeq -> 2769
/*     */     //   2766: goto -> 2891
/*     */     //   2769: aload #175
/*     */     //   2771: iconst_0
/*     */     //   2772: iaload
/*     */     //   2773: istore #210
/*     */     //   2775: aload #167
/*     */     //   2777: iconst_0
/*     */     //   2778: iaload
/*     */     //   2779: istore #209
/*     */     //   2781: iload #210
/*     */     //   2783: iload #209
/*     */     //   2785: if_icmpgt -> 2791
/*     */     //   2788: goto -> 2891
/*     */     //   2791: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2794: dup
/*     */     //   2795: aload #160
/*     */     //   2797: iconst_0
/*     */     //   2798: invokespecial <init> : ([DI)V
/*     */     //   2801: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2804: dup
/*     */     //   2805: aload #45
/*     */     //   2807: iload #46
/*     */     //   2809: invokespecial <init> : ([DI)V
/*     */     //   2812: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2815: dup
/*     */     //   2816: aload #43
/*     */     //   2818: iload #44
/*     */     //   2820: invokespecial <init> : ([DI)V
/*     */     //   2823: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2826: dup
/*     */     //   2827: aload #33
/*     */     //   2829: iload #34
/*     */     //   2831: invokespecial <init> : ([II)V
/*     */     //   2834: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2837: dup
/*     */     //   2838: aload #175
/*     */     //   2840: iconst_0
/*     */     //   2841: invokespecial <init> : ([II)V
/*     */     //   2844: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2847: dup
/*     */     //   2848: aload #51
/*     */     //   2850: iload #52
/*     */     //   2852: invokespecial <init> : ([DI)V
/*     */     //   2855: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2858: dup
/*     */     //   2859: aload #181
/*     */     //   2861: iconst_0
/*     */     //   2862: invokespecial <init> : ([DI)V
/*     */     //   2865: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2868: dup
/*     */     //   2869: aload #165
/*     */     //   2871: iconst_0
/*     */     //   2872: invokespecial <init> : ([II)V
/*     */     //   2875: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2878: dup
/*     */     //   2879: aload #180
/*     */     //   2881: iconst_0
/*     */     //   2882: invokespecial <init> : ([DI)V
/*     */     //   2885: invokestatic catmaxb_ : (Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/DoublePtr;)V
/*     */     //   2888: goto -> 3009
/*     */     //   2891: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2894: dup
/*     */     //   2895: aload #160
/*     */     //   2897: iconst_0
/*     */     //   2898: invokespecial <init> : ([DI)V
/*     */     //   2901: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2904: dup
/*     */     //   2905: aload #45
/*     */     //   2907: iload #46
/*     */     //   2909: invokespecial <init> : ([DI)V
/*     */     //   2912: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2915: dup
/*     */     //   2916: aload #43
/*     */     //   2918: iload #44
/*     */     //   2920: invokespecial <init> : ([DI)V
/*     */     //   2923: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2926: dup
/*     */     //   2927: aload #33
/*     */     //   2929: iload #34
/*     */     //   2931: invokespecial <init> : ([II)V
/*     */     //   2934: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2937: dup
/*     */     //   2938: aload #175
/*     */     //   2940: iconst_0
/*     */     //   2941: invokespecial <init> : ([II)V
/*     */     //   2944: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2947: dup
/*     */     //   2948: aload #51
/*     */     //   2950: iload #52
/*     */     //   2952: invokespecial <init> : ([DI)V
/*     */     //   2955: new org/renjin/gcc/runtime/DoublePtr
/*     */     //   2958: dup
/*     */     //   2959: aload #181
/*     */     //   2961: iconst_0
/*     */     //   2962: invokespecial <init> : ([DI)V
/*     */     //   2965: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2968: dup
/*     */     //   2969: aload #165
/*     */     //   2971: iconst_0
/*     */     //   2972: invokespecial <init> : ([II)V
/*     */     //   2975: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2978: dup
/*     */     //   2979: aload #37
/*     */     //   2981: iload #38
/*     */     //   2983: invokespecial <init> : ([II)V
/*     */     //   2986: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2989: dup
/*     */     //   2990: aload #167
/*     */     //   2992: iconst_0
/*     */     //   2993: invokespecial <init> : ([II)V
/*     */     //   2996: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2999: dup
/*     */     //   3000: aload #166
/*     */     //   3002: iconst_0
/*     */     //   3003: invokespecial <init> : ([II)V
/*     */     //   3006: invokestatic catmax_ : (Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/DoublePtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;Lorg/renjin/gcc/runtime/IntPtr;)V
/*     */     //   3009: aload #165
/*     */     //   3011: iconst_0
/*     */     //   3012: iaload
/*     */     //   3013: iconst_1
/*     */     //   3014: if_icmpeq -> 3020
/*     */     //   3017: goto -> 3027
/*     */     //   3020: aload #47
/*     */     //   3022: iload #48
/*     */     //   3024: iload #171
/*     */     //   3026: iastore
/*     */     //   3027: iload #172
/*     */     //   3029: iload #84
/*     */     //   3031: if_icmpeq -> 3041
/*     */     //   3034: goto -> 3037
/*     */     //   3037: iconst_0
/*     */     //   3038: goto -> 3042
/*     */     //   3041: iconst_1
/*     */     //   3042: istore #83
/*     */     //   3044: iinc #172, 1
/*     */     //   3047: iload #83
/*     */     //   3049: iconst_0
/*     */     //   3050: if_icmpne -> 3059
/*     */     //   3053: goto -> 3056
/*     */     //   3056: goto -> 1296
/*     */     //   3059: aload #181
/*     */     //   3061: iconst_0
/*     */     //   3062: daload
/*     */     //   3063: ldc2_w -1.0E10
/*     */     //   3066: dcmpg
/*     */     //   3067: iflt -> 3077
/*     */     //   3070: goto -> 3073
/*     */     //   3073: iconst_0
/*     */     //   3074: goto -> 3078
/*     */     //   3077: iconst_1
/*     */     //   3078: iconst_0
/*     */     //   3079: if_icmpne -> 3097
/*     */     //   3082: goto -> 3085
/*     */     //   3085: aload #47
/*     */     //   3087: iload #48
/*     */     //   3089: iaload
/*     */     //   3090: iconst_0
/*     */     //   3091: if_icmpeq -> 3097
/*     */     //   3094: goto -> 3103
/*     */     //   3097: aload #55
/*     */     //   3099: iload #56
/*     */     //   3101: iconst_m1
/*     */     //   3102: iastore
/*     */     //   3103: aload #181
/*     */     //   3105: iconst_0
/*     */     //   3106: daload
/*     */     //   3107: dload #182
/*     */     //   3109: dsub
/*     */     //   3110: dstore #200
/*     */     //   3112: aload #49
/*     */     //   3114: iload #50
/*     */     //   3116: dload #200
/*     */     //   3118: dastore
/*     */     //   3119: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #198	-> 463
/*     */     //   #198	-> 468
/*     */     //   #198	-> 470
/*     */     //   #198	-> 478
/*     */     //   #198	-> 484
/*     */     //   #198	-> 486
/*     */     //   #198	-> 491
/*     */     //   #198	-> 497
/*     */     //   #198	-> 499
/*     */     //   #200	-> 504
/*     */     //   #200	-> 509
/*     */     //   #200	-> 511
/*     */     //   #200	-> 519
/*     */     //   #200	-> 525
/*     */     //   #200	-> 527
/*     */     //   #200	-> 532
/*     */     //   #200	-> 538
/*     */     //   #200	-> 540
/*     */     //   #197	-> 544
/*     */     //   #197	-> 549
/*     */     //   #197	-> 551
/*     */     //   #197	-> 559
/*     */     //   #197	-> 565
/*     */     //   #197	-> 567
/*     */     //   #197	-> 572
/*     */     //   #197	-> 578
/*     */     //   #197	-> 580
/*     */     //   #199	-> 584
/*     */     //   #199	-> 589
/*     */     //   #199	-> 591
/*     */     //   #199	-> 599
/*     */     //   #199	-> 605
/*     */     //   #199	-> 607
/*     */     //   #199	-> 612
/*     */     //   #199	-> 618
/*     */     //   #199	-> 620
/*     */     //   #199	-> 625
/*     */     //   #199	-> 630
/*     */     //   #199	-> 632
/*     */     //   #199	-> 640
/*     */     //   #199	-> 646
/*     */     //   #199	-> 648
/*     */     //   #199	-> 653
/*     */     //   #199	-> 659
/*     */     //   #199	-> 661
/*     */     //   #197	-> 666
/*     */     //   #197	-> 671
/*     */     //   #197	-> 673
/*     */     //   #197	-> 681
/*     */     //   #197	-> 688
/*     */     //   #197	-> 695
/*     */     //   #197	-> 703
/*     */     //   #197	-> 709
/*     */     //   #197	-> 711
/*     */     //   #197	-> 716
/*     */     //   #197	-> 722
/*     */     //   #197	-> 724
/*     */     //   #197	-> 728
/*     */     //   #199	-> 734
/*     */     //   #199	-> 739
/*     */     //   #199	-> 741
/*     */     //   #199	-> 749
/*     */     //   #199	-> 755
/*     */     //   #199	-> 757
/*     */     //   #199	-> 762
/*     */     //   #199	-> 768
/*     */     //   #199	-> 770
/*     */     //   #197	-> 775
/*     */     //   #197	-> 780
/*     */     //   #197	-> 782
/*     */     //   #197	-> 790
/*     */     //   #197	-> 796
/*     */     //   #197	-> 798
/*     */     //   #197	-> 803
/*     */     //   #197	-> 809
/*     */     //   #197	-> 811
/*     */     //   #197	-> 815
/*     */     //   #197	-> 820
/*     */     //   #197	-> 822
/*     */     //   #197	-> 830
/*     */     //   #197	-> 837
/*     */     //   #197	-> 844
/*     */     //   #197	-> 852
/*     */     //   #197	-> 858
/*     */     //   #197	-> 860
/*     */     //   #197	-> 865
/*     */     //   #197	-> 871
/*     */     //   #197	-> 873
/*     */     //   #197	-> 877
/*     */     //   #198	-> 883
/*     */     //   #198	-> 888
/*     */     //   #198	-> 890
/*     */     //   #198	-> 898
/*     */     //   #198	-> 905
/*     */     //   #198	-> 913
/*     */     //   #198	-> 919
/*     */     //   #198	-> 921
/*     */     //   #198	-> 926
/*     */     //   #198	-> 932
/*     */     //   #198	-> 934
/*     */     //   #198	-> 939
/*     */     //   #199	-> 945
/*     */     //   #199	-> 950
/*     */     //   #199	-> 952
/*     */     //   #199	-> 960
/*     */     //   #199	-> 966
/*     */     //   #199	-> 968
/*     */     //   #199	-> 973
/*     */     //   #199	-> 979
/*     */     //   #199	-> 981
/*     */     //   #207	-> 985
/*     */     //   #208	-> 991
/*     */     //   #210	-> 998
/*     */     //   #211	-> 1001
/*     */     //   #212	-> 1006
/*     */     //   #212	-> 1013
/*     */     //   #212	-> 1016
/*     */     //   #213	-> 1026
/*     */     //   #213	-> 1034
/*     */     //   #213	-> 1048
/*     */     //   #213	-> 1056
/*     */     //   #213	-> 1070
/*     */     //   #213	-> 1079
/*     */     //   #214	-> 1084
/*     */     //   #214	-> 1092
/*     */     //   #214	-> 1106
/*     */     //   #214	-> 1114
/*     */     //   #214	-> 1127
/*     */     //   #212	-> 1135
/*     */     //   #212	-> 1152
/*     */     //   #212	-> 1155
/*     */     //   #216	-> 1167
/*     */     //   #216	-> 1175
/*     */     //   #217	-> 1184
/*     */     //   #220	-> 1190
/*     */     //   #221	-> 1197
/*     */     //   #221	-> 1204
/*     */     //   #221	-> 1207
/*     */     //   #222	-> 1217
/*     */     //   #222	-> 1225
/*     */     //   #221	-> 1237
/*     */     //   #221	-> 1254
/*     */     //   #221	-> 1257
/*     */     //   #224	-> 1269
/*     */     //   #226	-> 1276
/*     */     //   #226	-> 1283
/*     */     //   #226	-> 1286
/*     */     //   #227	-> 1296
/*     */     //   #228	-> 1309
/*     */     //   #228	-> 1316
/*     */     //   #228	-> 1324
/*     */     //   #228	-> 1333
/*     */     //   #228	-> 1335
/*     */     //   #229	-> 1339
/*     */     //   #229	-> 1347
/*     */     //   #230	-> 1359
/*     */     //   #230	-> 1367
/*     */     //   #230	-> 1375
/*     */     //   #230	-> 1389
/*     */     //   #231	-> 1403
/*     */     //   #231	-> 1411
/*     */     //   #232	-> 1423
/*     */     //   #233	-> 1426
/*     */     //   #233	-> 1434
/*     */     //   #233	-> 1448
/*     */     //   #234	-> 1456
/*     */     //   #234	-> 1460
/*     */     //   #236	-> 1467
/*     */     //   #237	-> 1471
/*     */     //   #238	-> 1477
/*     */     //   #239	-> 1480
/*     */     //   #240	-> 1483
/*     */     //   #241	-> 1508
/*     */     //   #241	-> 1515
/*     */     //   #241	-> 1518
/*     */     //   #242	-> 1528
/*     */     //   #242	-> 1536
/*     */     //   #242	-> 1544
/*     */     //   #242	-> 1558
/*     */     //   #241	-> 1572
/*     */     //   #241	-> 1589
/*     */     //   #241	-> 1592
/*     */     //   #244	-> 1604
/*     */     //   #245	-> 1607
/*     */     //   #245	-> 1614
/*     */     //   #245	-> 1619
/*     */     //   #245	-> 1623
/*     */     //   #245	-> 1627
/*     */     //   #246	-> 1637
/*     */     //   #246	-> 1642
/*     */     //   #246	-> 1645
/*     */     //   #246	-> 1652
/*     */     //   #247	-> 1664
/*     */     //   #247	-> 1672
/*     */     //   #248	-> 1684
/*     */     //   #248	-> 1692
/*     */     //   #249	-> 1704
/*     */     //   #249	-> 1712
/*     */     //   #249	-> 1722
/*     */     //   #249	-> 1726
/*     */     //   #249	-> 1729
/*     */     //   #249	-> 1729
/*     */     //   #249	-> 1732
/*     */     //   #250	-> 1737
/*     */     //   #250	-> 1745
/*     */     //   #250	-> 1755
/*     */     //   #250	-> 1763
/*     */     //   #250	-> 1770
/*     */     //   #250	-> 1770
/*     */     //   #250	-> 1773
/*     */     //   #251	-> 1778
/*     */     //   #252	-> 1785
/*     */     //   #253	-> 1792
/*     */     //   #253	-> 1800
/*     */     //   #253	-> 1808
/*     */     //   #253	-> 1818
/*     */     //   #253	-> 1825
/*     */     //   #254	-> 1839
/*     */     //   #254	-> 1847
/*     */     //   #254	-> 1855
/*     */     //   #254	-> 1865
/*     */     //   #254	-> 1872
/*     */     //   #255	-> 1886
/*     */     //   #255	-> 1891
/*     */     //   #255	-> 1894
/*     */     //   #255	-> 1901
/*     */     //   #255	-> 1915
/*     */     //   #255	-> 1919
/*     */     //   #255	-> 1922
/*     */     //   #255	-> 1925
/*     */     //   #255	-> 1932
/*     */     //   #255	-> 1942
/*     */     //   #255	-> 1945
/*     */     //   #255	-> 1948
/*     */     //   #255	-> 1955
/*     */     //   #255	-> 1969
/*     */     //   #257	-> 1983
/*     */     //   #257	-> 1987
/*     */     //   #257	-> 2007
/*     */     //   #257	-> 2032
/*     */     //   #257	-> 2051
/*     */     //   #257	-> 2058
/*     */     //   #257	-> 2062
/*     */     //   #257	-> 2079
/*     */     //   #258	-> 2086
/*     */     //   #258	-> 2091
/*     */     //   #258	-> 2095
/*     */     //   #258	-> 2100
/*     */     //   #258	-> 2104
/*     */     //   #259	-> 2115
/*     */     //   #259	-> 2123
/*     */     //   #259	-> 2141
/*     */     //   #260	-> 2148
/*     */     //   #260	-> 2153
/*     */     //   #261	-> 2160
/*     */     //   #262	-> 2166
/*     */     //   #263	-> 2173
/*     */     //   #266	-> 2176
/*     */     //   #266	-> 2182
/*     */     //   #267	-> 2193
/*     */     //   #268	-> 2206
/*     */     //   #268	-> 2211
/*     */     //   #268	-> 2215
/*     */     //   #268	-> 2218
/*     */     //   #268	-> 2224
/*     */     //   #268	-> 2240
/*     */     //   #269	-> 2247
/*     */     //   #269	-> 2252
/*     */     //   #270	-> 2259
/*     */     //   #271	-> 2265
/*     */     //   #273	-> 2272
/*     */     //   #245	-> 2275
/*     */     //   #245	-> 2292
/*     */     //   #245	-> 2295
/*     */     //   #280	-> 2307
/*     */     //   #281	-> 2348
/*     */     //   #281	-> 2355
/*     */     //   #281	-> 2362
/*     */     //   #281	-> 2366
/*     */     //   #282	-> 2376
/*     */     //   #282	-> 2382
/*     */     //   #283	-> 2392
/*     */     //   #283	-> 2398
/*     */     //   #283	-> 2406
/*     */     //   #283	-> 2409
/*     */     //   #283	-> 2412
/*     */     //   #283	-> 2417
/*     */     //   #284	-> 2427
/*     */     //   #284	-> 2433
/*     */     //   #284	-> 2443
/*     */     //   #284	-> 2450
/*     */     //   #284	-> 2455
/*     */     //   #284	-> 2460
/*     */     //   #284	-> 2466
/*     */     //   #284	-> 2476
/*     */     //   #284	-> 2483
/*     */     //   #284	-> 2488
/*     */     //   #284	-> 2493
/*     */     //   #284	-> 2503
/*     */     //   #284	-> 2509
/*     */     //   #284	-> 2519
/*     */     //   #284	-> 2526
/*     */     //   #281	-> 2536
/*     */     //   #281	-> 2553
/*     */     //   #281	-> 2556
/*     */     //   #286	-> 2568
/*     */     //   #287	-> 2571
/*     */     //   #287	-> 2577
/*     */     //   #287	-> 2580
/*     */     //   #288	-> 2590
/*     */     //   #289	-> 2593
/*     */     //   #289	-> 2600
/*     */     //   #289	-> 2603
/*     */     //   #290	-> 2613
/*     */     //   #290	-> 2618
/*     */     //   #290	-> 2621
/*     */     //   #290	-> 2626
/*     */     //   #290	-> 2634
/*     */     //   #289	-> 2639
/*     */     //   #289	-> 2656
/*     */     //   #289	-> 2659
/*     */     //   #292	-> 2671
/*     */     //   #292	-> 2677
/*     */     //   #293	-> 2686
/*     */     //   #293	-> 2701
/*     */     //   #293	-> 2708
/*     */     //   #287	-> 2711
/*     */     //   #287	-> 2728
/*     */     //   #287	-> 2731
/*     */     //   #295	-> 2743
/*     */     //   #296	-> 2748
/*     */     //   #297	-> 2757
/*     */     //   #297	-> 2762
/*     */     //   #297	-> 2769
/*     */     //   #297	-> 2775
/*     */     //   #297	-> 2781
/*     */     //   #299	-> 2791
/*     */     //   #302	-> 2891
/*     */     //   #304	-> 3009
/*     */     //   #304	-> 3013
/*     */     //   #304	-> 3020
/*     */     //   #226	-> 3027
/*     */     //   #226	-> 3044
/*     */     //   #226	-> 3047
/*     */     //   #310	-> 3059
/*     */     //   #310	-> 3063
/*     */     //   #310	-> 3078
/*     */     //   #310	-> 3085
/*     */     //   #310	-> 3090
/*     */     //   #310	-> 3097
/*     */     //   #311	-> 3103
/*     */     //   #311	-> 3107
/*     */     //   #311	-> 3112
/*     */     //   #312	-> 3119
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	3120	0	a	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	1	b	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	2	cl	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	3	mdim	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	4	nsample	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	5	nclass	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	6	cat	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	7	maxcat	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	8	ndstart	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	9	ndend	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	10	tclasspop	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	11	tclasscat	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	12	msplit	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	13	decsplit	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	14	best	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	15	ncase	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	16	jstat	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	17	mtry	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	18	win	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	19	wr	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	20	wl	Lorg/renjin/gcc/runtime/DoublePtr;
/*     */     //   0	3120	21	mred	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	22	mind	Lorg/renjin/gcc/runtime/IntPtr;
/*     */     //   0	3120	23	a$array	[I
/*     */     //   0	3120	24	a$offset	I
/*     */     //   0	3120	25	b$array	[I
/*     */     //   0	3120	26	b$offset	I
/*     */     //   0	3120	27	cl$array	[I
/*     */     //   0	3120	28	cl$offset	I
/*     */     //   0	3120	29	mdim$array	[I
/*     */     //   0	3120	30	mdim$offset	I
/*     */     //   0	3120	31	nsample$array	[I
/*     */     //   0	3120	32	nsample$offset	I
/*     */     //   0	3120	33	nclass$array	[I
/*     */     //   0	3120	34	nclass$offset	I
/*     */     //   0	3120	35	cat$array	[I
/*     */     //   0	3120	36	cat$offset	I
/*     */     //   0	3120	37	maxcat$array	[I
/*     */     //   0	3120	38	maxcat$offset	I
/*     */     //   0	3120	39	ndstart$array	[I
/*     */     //   0	3120	40	ndstart$offset	I
/*     */     //   0	3120	41	ndend$array	[I
/*     */     //   0	3120	42	ndend$offset	I
/*     */     //   0	3120	43	tclasspop$array	[D
/*     */     //   0	3120	44	tclasspop$offset	I
/*     */     //   0	3120	45	tclasscat$array	[D
/*     */     //   0	3120	46	tclasscat$offset	I
/*     */     //   0	3120	47	msplit$array	[I
/*     */     //   0	3120	48	msplit$offset	I
/*     */     //   0	3120	49	decsplit$array	[D
/*     */     //   0	3120	50	decsplit$offset	I
/*     */     //   0	3120	51	best$array	[D
/*     */     //   0	3120	52	best$offset	I
/*     */     //   0	3120	53	ncase$array	[I
/*     */     //   0	3120	54	ncase$offset	I
/*     */     //   0	3120	55	jstat$array	[I
/*     */     //   0	3120	56	jstat$offset	I
/*     */     //   0	3120	57	mtry$array	[I
/*     */     //   0	3120	58	mtry$offset	I
/*     */     //   0	3120	59	win$array	[D
/*     */     //   0	3120	60	win$offset	I
/*     */     //   0	3120	61	wr$array	[D
/*     */     //   0	3120	62	wr$offset	I
/*     */     //   0	3120	63	wl$array	[D
/*     */     //   0	3120	64	wl$offset	I
/*     */     //   0	3120	65	mred$array	[I
/*     */     //   0	3120	66	mred$offset	I
/*     */     //   0	3120	67	mind$array	[I
/*     */     //   0	3120	68	mind$offset	I
/*     */     //   0	3120	74	nsp$239	I
/*     */     //   0	3120	76	M$43	D
/*     */     //   0	3120	79	nsp$235	I
/*     */     //   0	3120	133	xrand	[D
/*     */     //   0	3120	134	size$42	I
/*     */     //   0	3120	135	ubound$41	I
/*     */     //   0	3120	136	size$40	I
/*     */     //   0	3120	137	ubound$39	I
/*     */     //   0	3120	138	size$38	I
/*     */     //   0	3120	139	ubound$37	I
/*     */     //   0	3120	140	u	D
/*     */     //   0	3120	142	size$36	I
/*     */     //   0	3120	143	ubound$35	I
/*     */     //   0	3120	144	size$34	I
/*     */     //   0	3120	145	offset$33	I
/*     */     //   0	3120	146	stride$32	I
/*     */     //   0	3120	147	ubound$31	I
/*     */     //   0	3120	148	su	D
/*     */     //   0	3120	150	rrn	D
/*     */     //   0	3120	152	rrd	D
/*     */     //   0	3120	154	rln	D
/*     */     //   0	3120	156	rld	D
/*     */     //   0	3120	158	pno	D
/*     */     //   0	3120	160	pdo	[D
/*     */     //   0	3120	161	ntie	I
/*     */     //   0	3120	162	nsp	I
/*     */     //   0	3120	163	nnz	I
/*     */     //   0	3120	164	nn	I
/*     */     //   0	3120	165	nhit	[I
/*     */     //   0	3120	166	ncsplit	[I
/*     */     //   0	3120	167	ncmax	[I
/*     */     //   0	3120	168	size$30	I
/*     */     //   0	3120	169	ubound$29	I
/*     */     //   0	3120	170	nc	I
/*     */     //   0	3120	171	mvar	I
/*     */     //   0	3120	172	mt	I
/*     */     //   0	3120	173	size$28	I
/*     */     //   0	3120	174	ubound$27	I
/*     */     //   0	3120	175	lcat	[I
/*     */     //   0	3120	176	l	I
/*     */     //   0	3120	177	k	I
/*     */     //   0	3120	178	j	I
/*     */     //   0	3120	179	i	I
/*     */     //   0	3120	180	dn	[D
/*     */     //   0	3120	181	critmax	[D
/*     */     //   0	3120	182	crit0	D
/*     */     //   0	3120	184	crit	D
/*     */     //   0	3120	186	size$26	I
/*     */     //   0	3120	187	ubound$25	I
/*     */     //   0	3120	188	size$24	I
/*     */     //   0	3120	189	ubound$23	I
/*     */     //   0	3120	190	size$22	I
/*     */     //   0	3120	191	offset$21	I
/*     */     //   0	3120	192	stride$20	I
/*     */     //   0	3120	193	ubound$19	I
/*     */     //   0	3120	194	ubound$18	I
/*     */     //   0	3120	195	size$17	I
/*     */     //   0	3120	196	offset$16	I
/*     */     //   0	3120	197	stride$15	I
/*     */     //   0	3120	198	ubound$14	I
/*     */     //   0	3120	199	ubound$13	I
/*     */     //   0	3120	202	critmax$244	D
/*     */     //   0	3120	206	critmax$243	D
/*     */     //   0	3120	208	nhit$242	I
/*     */     //   0	3120	209	ncmax$241	I
/*     */     //   0	3120	210	lcat$240	I
/*     */     //   0	3120	245	xrand$238	D
/*     */     //   0	3120	251	critmax$237	D
/*     */     //   0	3120	256	critmax$236	D
/*     */     //   0	3120	327	lcat$234	I
/*     */     //   0	3120	328	lcat$233	I
/*     */     //   0	3120	338	xrand$232	D
/*     */     //   0	3120	343	pdo$231	D
/*     */     //   0	3120	345	pdo$230	D
/*     */     //   0	3120	347	pdo$229	D
/*     */     //   0	3120	360	size$228	I
/*     */     //   0	3120	363	size$227	I
/*     */     //   0	3120	364	size$226	I
/*     */     //   0	3120	367	size$225	I
/*     */     //   0	3120	368	size$224	I
/*     */     //   0	3120	371	size$223	I
/*     */     //   0	3120	372	size$222	I
/*     */     //   0	3120	375	size$221	I
/*     */     //   0	3120	376	size$220	I
/*     */     //   0	3120	379	size$219	I
/*     */     //   0	3120	380	size$218	I
/*     */     //   0	3120	383	size$217	I
/*     */     //   0	3120	384	size$216	I
/*     */     //   0	3120	387	size$215	I
/*     */     //   0	3120	388	size$214	I
/*     */     //   0	3120	391	size$213	I
/*     */     //   0	3120	392	size$212	I
/*     */     //   0	3120	395	size$211	I
/*     */     //   0	3120	396	size$210	I
/*     */     //   0	3120	399	size$209	I
/*     */     //   0	3120	400	size$208	I
/*     */     //   0	3120	403	size$207	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void movedata_(IntPtr a, IntPtr ta, IntPtr mdim, IntPtr nsample, IntPtr ndstart, IntPtr ndend, IntPtr idmove, IntPtr ncase, IntPtr msplit, IntPtr cat, DoublePtr best, IntPtr ndendl) {
/* 323 */     a$array = a.array; a$offset = a.offset; ta$array = ta.array; ta$offset = ta.offset; mdim$array = mdim.array; mdim$offset = mdim.offset; nsample$array = nsample.array; nsample$offset = nsample.offset; ndstart$array = ndstart.array; ndstart$offset = ndstart.offset; ndend$array = ndend.array; ndend$offset = ndend.offset; idmove$array = idmove.array; idmove$offset = idmove.offset; ncase$array = ncase.array; ncase$offset = ncase.offset; msplit$array = msplit.array; msplit$offset = msplit.offset; cat$array = cat.array; cat$offset = cat.offset; best$array = best.array; best$offset = best.offset; ndendl$array = ndendl.array; ndendl$offset = ndendl.offset; l = new int[1]; icat = new int[53]; int i = 0, j = 0, m = 0, i1 = 0, i2 = 0, i3 = 0, i4 = 0, i5 = 0, i6 = 0, i7 = 0, i8 = 0, i9 = 0, i10 = 0, i11 = 0, i12 = 0; msh = 0; k = 0; offset$3 = 0; stride$2 = 0; size$6 = mdim$array[mdim$offset]; size$6 = Math.max(size$6, 0); int i14 = size$6 + -1; long l1 = (size$6 & 0xFFFFFFFFL) * 32L; int i13 = size$6 * 4; stride$2 = mdim$array[mdim$offset]; stride$2 = Math.max(stride$2, 0); ubound$1 = nsample$array[nsample$offset]; size$4 = stride$2 * ubound$1; size$4 = Math.max(size$4, 0); int i16 = size$4 + -1; long l2 = (size$4 & 0xFFFFFFFFL) * 32L; int i15 = size$4 * 4; offset$3 = stride$2 ^ 0xFFFFFFFF; size$8 = nsample$array[nsample$offset]; size$8 = Math.max(size$8, 0); int i18 = size$8 + -1; long l3 = (size$8 & 0xFFFFFFFFL) * 32L; int i17 = size$8 * 4; size$10 = nsample$array[nsample$offset]; size$10 = Math.max(size$10, 0); int i20 = size$10 + -1; long l4 = (size$10 & 0xFFFFFFFFL) * 32L; int i19 = size$10 * 4;
/*     */     
/*     */     size$12 = nsample$array[nsample$offset];
/*     */     size$12 = Math.max(size$12, 0);
/*     */     int i22 = size$12 + -1;
/*     */     long l5 = (size$12 & 0xFFFFFFFFL) * 32L;
/*     */     int i21 = size$12 * 4;
/* 330 */     int i24 = msplit$array[msplit$offset] + -1; if (cat$array[cat$offset + i24] != 1)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 341 */       int i26 = ndstart$array[ndstart$offset] + -1; ndendl$array[ndendl$offset] = i26;
/* 342 */       int i25 = msplit$array[msplit$offset] + -1; l$257 = cat$array[cat$offset + i25]; l[0] = l$257;
/* 343 */       rfutils__.unpack_(new DoublePtr(best$array, best$offset), new IntPtr(l, 0), new IntPtr(icat, 0));
/* 344 */       nsp$258 = ndstart$array[ndstart$offset]; i10 = ndend$array[ndend$offset]; nsp = nsp$258; if (nsp <= i10)
/* 345 */         while (true) { int i31 = nsp + -1; nc = ncase$array[ncase$offset + i31];
/* 346 */           int i30 = msplit$array[msplit$offset], i29 = nc * stride$2, i28 = i30 + i29 + offset$3, i27 = a$array[a$offset + i28] + -1; if (icat[0 + i27] != 1)
/*     */           
/*     */           { 
/*     */             
/* 350 */             int i32 = nc + -1; idmove$array[idmove$offset + i32] = 0; } else { int i33 = nc + -1; idmove$array[idmove$offset + i33] = 1; int i32 = ndendl$array[ndendl$offset] + 1; ndendl$array[ndendl$offset] = i32; }  boolean bool = (nsp != i10) ? false : true; nsp++; if (bool == false)
/*     */             continue;  break; }   } else { nsp$255 = ndstart$array[ndstart$offset]; i12 = (int)(long)best$array[best$offset]; nsp = nsp$255; if (nsp <= i12)
/*     */         while (true) { int i29 = msplit$array[msplit$offset], i28 = nsp * stride$2, i27 = i29 + i28 + offset$3; nc = a$array[a$offset + i27]; int i26 = nc + -1; idmove$array[idmove$offset + i26] = 1; boolean bool = (nsp != i12) ? false : true; nsp++; if (bool == false)
/*     */             continue;  break; }   nsp$256 = (int)(long)best$array[best$offset] + 1; i11 = ndend$array[ndend$offset]; nsp = nsp$256; if (nsp <= i11)
/*     */         while (true) { int i29 = msplit$array[msplit$offset], i28 = nsp * stride$2, i27 = i29 + i28 + offset$3; nc = a$array[a$offset + i27]; int i26 = nc + -1; idmove$array[idmove$offset + i26] = 0; boolean bool = (nsp != i11) ? false : true; nsp++; if (bool == false)
/*     */             continue;  break; }
/*     */           int i25 = (int)(long)best$array[best$offset]; ndendl$array[ndendl$offset] = i25; }
/* 357 */      i9 = mdim$array[mdim$offset]; msh = 1; if (msh <= i9)
/* 358 */       while (true) { int i25 = msh + -1; if (cat$array[cat$offset + i25] == 1) {
/* 359 */           k = ndstart$array[ndstart$offset] + -1;
/* 360 */           n$259 = ndstart$array[ndstart$offset]; i8 = ndend$array[ndend$offset]; n = n$259; if (n <= i8)
/* 361 */             while (true) { int i27 = n * stride$2 + msh + offset$3; ih = a$array[a$offset + i27];
/* 362 */               int i26 = ih + -1; if (idmove$array[idmove$offset + i26] == 1) {
/* 363 */                 k++;
/* 364 */                 int i30 = k + -1, i29 = n * stride$2 + msh + offset$3, i28 = a$array[a$offset + i29]; ta$array[ta$offset + i30] = i28;
/*     */               }  boolean bool1 = (n != i8) ? false : true; n++; if (bool1 == false)
/*     */                 continue;  break; }
/* 367 */               n$260 = ndstart$array[ndstart$offset]; i7 = ndend$array[ndend$offset]; n = n$260; if (n <= i7)
/* 368 */             while (true) { int i27 = n * stride$2 + msh + offset$3; ih = a$array[a$offset + i27];
/* 369 */               int i26 = ih + -1; if (idmove$array[idmove$offset + i26] == 0) {
/* 370 */                 k++;
/* 371 */                 int i30 = k + -1, i29 = n * stride$2 + msh + offset$3, i28 = a$array[a$offset + i29]; ta$array[ta$offset + i30] = i28;
/*     */               }  boolean bool1 = (n != i7) ? false : true; n++; if (bool1 == false)
/*     */                 continue;  break; }
/*     */              
/* 375 */           k$261 = ndstart$array[ndstart$offset]; i6 = ndend$array[ndend$offset]; k = k$261; if (k <= i6)
/* 376 */             while (true) { int i28 = k * stride$2 + msh + offset$3, i27 = k + -1, i26 = ta$array[ta$offset + i27]; a$array[a$offset + i28] = i26; boolean bool1 = (k != i6) ? false : true; k++; if (bool1 == false)
/*     */                 continue;  break; }
/*     */              
/*     */         }  boolean bool = (msh != i9) ? false : true; msh++; if (bool == false)
/*     */           continue;  break; }
/* 381 */         if (false == 
/* 382 */       true) {
/* 383 */       i5 = mdim$array[mdim$offset]; msh = 1; if (msh <= i5)
/* 384 */         while (true) { int i25 = msh + -1; if (cat$array[cat$offset + i25] > 1) {
/* 385 */             k = ndstart$array[ndstart$offset] + -1;
/* 386 */             n$262 = ndstart$array[ndstart$offset]; i4 = ndend$array[ndend$offset]; n = n$262; if (n <= i4)
/* 387 */               while (true) { int i27 = n + -1; ih = ncase$array[ncase$offset + i27];
/* 388 */                 int i26 = ih + -1; if (idmove$array[idmove$offset + i26] == 1) {
/* 389 */                   k++;
/* 390 */                   int i30 = k + -1, i29 = ih * stride$2 + msh + offset$3, i28 = a$array[a$offset + i29]; ta$array[ta$offset + i30] = i28;
/*     */                 }  boolean bool1 = (n != i4) ? false : true; n++; if (bool1 == false)
/*     */                   continue;  break; }
/* 393 */                 n$263 = ndstart$array[ndstart$offset]; i3 = ndend$array[ndend$offset]; n = n$263; if (n <= i3)
/* 394 */               while (true) { int i27 = n + -1; ih = ncase$array[ncase$offset + i27];
/* 395 */                 int i26 = ih + -1; if (idmove$array[idmove$offset + i26] == 0) {
/* 396 */                   k++;
/* 397 */                   int i30 = k + -1, i29 = ih * stride$2 + msh + offset$3, i28 = a$array[a$offset + i29]; ta$array[ta$offset + i30] = i28;
/*     */                 }  boolean bool1 = (n != i3) ? false : true; n++; if (bool1 == false)
/*     */                   continue;  break; }
/*     */                
/* 401 */             k$264 = ndstart$array[ndstart$offset]; i2 = ndend$array[ndend$offset]; k = k$264; if (k <= i2)
/* 402 */               while (true) { int i28 = k * stride$2 + msh + offset$3, i27 = k + -1, i26 = ta$array[ta$offset + i27]; a$array[a$offset + i28] = i26; boolean bool1 = (k != i2) ? false : true; k++; if (bool1 == false)
/*     */                   continue;  break; }
/*     */                
/*     */           }  boolean bool = (msh != i5) ? false : true; msh++;
/*     */           if (bool == false)
/*     */             continue; 
/*     */           break; }
/*     */          
/*     */     } 
/* 411 */     int i23 = msplit$array[msplit$offset] + -1; if (cat$array[cat$offset + i23] != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 416 */       k = ndstart$array[ndstart$offset] + -1;
/* 417 */       n$266 = ndstart$array[ndstart$offset]; m = ndend$array[ndend$offset]; n = n$266; if (n <= m)
/* 418 */         while (true) { int i26 = n + -1, i25 = ncase$array[ncase$offset + i26] + -1; if (idmove$array[idmove$offset + i25] == 1) {
/* 419 */             k++;
/* 420 */             int i29 = k + -1, i28 = n + -1, i27 = ncase$array[ncase$offset + i28]; ta$array[ta$offset + i29] = i27;
/*     */           }  boolean bool = (n != m) ? false : true; n++; if (bool == false)
/*     */             continue;  break; }
/* 423 */           n$267 = ndstart$array[ndstart$offset]; j = ndend$array[ndend$offset]; n = n$267; if (n <= j)
/* 424 */         while (true) { int i26 = n + -1, i25 = ncase$array[ncase$offset + i26] + -1; if (idmove$array[idmove$offset + i25] == 0) {
/* 425 */             k++;
/* 426 */             int i29 = k + -1, i28 = n + -1, i27 = ncase$array[ncase$offset + i28]; ta$array[ta$offset + i29] = i27;
/*     */           }  boolean bool = (n != j) ? false : true; n++; if (bool == false)
/*     */             continue;  break; }
/* 429 */           k$268 = ndstart$array[ndstart$offset]; i = ndend$array[ndend$offset]; k = k$268; if (k <= i)
/* 430 */         while (true) { int i27 = k + -1, i26 = k + -1, i25 = ta$array[ta$offset + i26]; ncase$array[ncase$offset + i27] = i25;
/*     */           boolean bool = (k != i) ? false : true;
/*     */           k++;
/*     */           if (bool == false)
/*     */             continue; 
/*     */           break; }
/*     */          
/*     */       return;
/*     */     } 
/*     */     n$265 = ndstart$array[ndstart$offset];
/*     */     i1 = ndend$array[ndend$offset];
/*     */     n = n$265;
/*     */     if (n <= i1)
/*     */       while (true) {
/*     */         int i29 = n + -1, i28 = msplit$array[msplit$offset], i27 = n * stride$2, i26 = i28 + i27 + offset$3, i25 = a$array[a$offset + i26];
/*     */         ncase$array[ncase$offset + i29] = i25;
/*     */         boolean bool = (n != i1) ? false : true;
/*     */         n++;
/*     */         if (bool == false)
/*     */           continue; 
/*     */         break;
/*     */       }  
/*     */   }
/* 453 */   public static void zerv_(IntPtr ix, IntPtr m1) { ix$array = ix.array; ix$offset = ix.offset; m1$array = m1.array; m1$offset = m1.offset; int i = 0; size$52 = m1$array[m1$offset]; size$52 = Math.max(size$52, 0); int k = size$52 + -1; long l = (size$52 & 0xFFFFFFFFL) * 32L; int j = size$52 * 4;
/*     */     
/* 455 */     i = m1$array[m1$offset]; n = 1; if (n <= i)
/* 456 */       while (true) { int m = n + -1; ix$array[ix$offset + m] = 0; boolean bool = (n != i) ? false : true; n++;
/*     */         if (bool == false)
/*     */           continue; 
/*     */         break; }
/* 460 */         } public static void zervr_(DoublePtr rx, IntPtr m1) { rx$array = rx.array; rx$offset = rx.offset; m1$array = m1.array; m1$offset = m1.offset; int i = 0; size$50 = m1$array[m1$offset]; size$50 = Math.max(size$50, 0); int k = size$50 + -1; long l = (size$50 & 0xFFFFFFFFL) * 64L; int j = size$50 * 8;
/*     */     
/* 462 */     i = m1$array[m1$offset]; n = 1; if (n <= i)
/* 463 */       while (true) { int m = n + -1; rx$array[rx$offset + m] = 0.0D; boolean bool = (n != i) ? false : true; n++;
/*     */         if (bool == false)
/*     */           continue; 
/*     */         break; }
/* 467 */         } public static void zerm_(IntPtr mx, IntPtr m1, IntPtr m2) { mx$array = mx.array; mx$offset = mx.offset; m1$array = m1.array; m1$offset = m1.offset; m2$array = m2.array; m2$offset = m2.offset; int k = 0, m = 0; offset$115 = 0; stride$114 = 0; i = 0; stride$114 = m1$array[m1$offset]; stride$114 = Math.max(stride$114, 0); ubound$113 = m2$array[m2$offset]; size$116 = stride$114 * ubound$113; size$116 = Math.max(size$116, 0); int i1 = size$116 + -1; long l = (size$116 & 0xFFFFFFFFL) * 32L; int n = size$116 * 4; offset$115 = stride$114 ^ 0xFFFFFFFF;
/*     */     
/* 469 */     m = m1$array[m1$offset]; i = 1; if (i <= m)
/* 470 */       while (true) { k = m2$array[m2$offset]; j = 1; if (j <= k)
/* 471 */           while (true) { int i2 = j * stride$114 + i + offset$115; mx$array[mx$offset + i2] = 0; boolean bool1 = (j != k) ? false : true; j++; if (bool1 == false)
/*     */               continue;  break; }
/*     */             boolean bool = (i != m) ? false : true; i++; if (bool == false)
/*     */           continue; 
/*     */         break; }
/* 476 */         } public static void zermr_(DoublePtr rx, IntPtr m1, IntPtr m2) { rx$array = rx.array; rx$offset = rx.offset; m1$array = m1.array; m1$offset = m1.offset; m2$array = m2.array; m2$offset = m2.offset; int k = 0, m = 0; offset$47 = 0; stride$46 = 0; i = 0; stride$46 = m1$array[m1$offset]; stride$46 = Math.max(stride$46, 0); ubound$45 = m2$array[m2$offset]; size$48 = stride$46 * ubound$45; size$48 = Math.max(size$48, 0); int i1 = size$48 + -1; long l = (size$48 & 0xFFFFFFFFL) * 64L; int n = size$48 * 8; offset$47 = stride$46 ^ 0xFFFFFFFF;
/*     */     
/* 478 */     m = m1$array[m1$offset]; i = 1; if (i <= m)
/* 479 */       while (true) { k = m2$array[m2$offset]; j = 1; if (j <= k)
/* 480 */           while (true) { int i2 = j * stride$46 + i + offset$47; rx$array[rx$offset + i2] = 0.0D; boolean bool1 = (j != k) ? false : true; j++; if (bool1 == false)
/*     */               continue;  break; }
/*     */             boolean bool = (i != m) ? false : true; i++; if (bool == false)
/*     */           continue; 
/*     */         break; }
/* 485 */         } public static void zermd_(DoublePtr rx, IntPtr m1, IntPtr m2) { rx$array = rx.array; rx$offset = rx.offset; m1$array = m1.array; m1$offset = m1.offset; m2$array = m2.array; m2$offset = m2.offset; int k = 0, m = 0; offset$120 = 0; stride$119 = 0; i = 0; stride$119 = m1$array[m1$offset]; stride$119 = Math.max(stride$119, 0); ubound$118 = m2$array[m2$offset]; size$121 = stride$119 * ubound$118; size$121 = Math.max(size$121, 0); int i1 = size$121 + -1; long l = (size$121 & 0xFFFFFFFFL) * 64L; int n = size$121 * 8; offset$120 = stride$119 ^ 0xFFFFFFFF;
/*     */     
/* 487 */     m = m1$array[m1$offset]; i = 1; if (i <= m)
/* 488 */       while (true) { k = m2$array[m2$offset]; j = 1; if (j <= k)
/* 489 */           while (true) { int i2 = j * stride$119 + i + offset$120; rx$array[rx$offset + i2] = 0.0D;
/*     */             boolean bool1 = (j != k) ? false : true;
/*     */             j++;
/*     */             if (bool1 == false)
/*     */               continue; 
/*     */             break; }
/*     */            
/*     */         boolean bool = (i != m) ? false : true;
/*     */         i++;
/*     */         if (bool == false)
/*     */           continue; 
/*     */         break; }
/*     */         }
/*     */ 
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/randomForest-4.6-12-b29.jar!/org/renjin/cran/randomForest/rfsub__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */