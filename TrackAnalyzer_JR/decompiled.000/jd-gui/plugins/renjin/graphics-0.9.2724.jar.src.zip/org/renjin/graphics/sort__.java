/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import java.lang.invoke.MethodHandle;
/*      */ import org.renjin.gcc.runtime.Builtins;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.gnur.api.Utils;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class sort__
/*      */ {
/*      */   static {
/*      */   
/*      */   }
/*      */   
/*      */   public static int icmp(int x, int y, int nalast) {
/*      */     // Byte code:
/*      */     //   0: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   3: istore #9
/*      */     //   5: iload_0
/*      */     //   6: iload #9
/*      */     //   8: if_icmpeq -> 14
/*      */     //   11: goto -> 34
/*      */     //   14: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   17: istore #8
/*      */     //   19: iload_1
/*      */     //   20: iload #8
/*      */     //   22: if_icmpeq -> 28
/*      */     //   25: goto -> 34
/*      */     //   28: iconst_0
/*      */     //   29: istore #7
/*      */     //   31: goto -> 136
/*      */     //   34: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   37: istore #6
/*      */     //   39: iload_0
/*      */     //   40: iload #6
/*      */     //   42: if_icmpeq -> 48
/*      */     //   45: goto -> 71
/*      */     //   48: iload_2
/*      */     //   49: ifne -> 55
/*      */     //   52: goto -> 61
/*      */     //   55: iconst_1
/*      */     //   56: istore #5
/*      */     //   58: goto -> 64
/*      */     //   61: iconst_m1
/*      */     //   62: istore #5
/*      */     //   64: iload #5
/*      */     //   66: istore #7
/*      */     //   68: goto -> 136
/*      */     //   71: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   74: istore #4
/*      */     //   76: iload_1
/*      */     //   77: iload #4
/*      */     //   79: if_icmpeq -> 85
/*      */     //   82: goto -> 105
/*      */     //   85: iload_2
/*      */     //   86: ifne -> 92
/*      */     //   89: goto -> 97
/*      */     //   92: iconst_m1
/*      */     //   93: istore_3
/*      */     //   94: goto -> 99
/*      */     //   97: iconst_1
/*      */     //   98: istore_3
/*      */     //   99: iload_3
/*      */     //   100: istore #7
/*      */     //   102: goto -> 136
/*      */     //   105: iload_0
/*      */     //   106: iload_1
/*      */     //   107: if_icmplt -> 113
/*      */     //   110: goto -> 119
/*      */     //   113: iconst_m1
/*      */     //   114: istore #7
/*      */     //   116: goto -> 136
/*      */     //   119: iload_0
/*      */     //   120: iload_1
/*      */     //   121: if_icmpgt -> 127
/*      */     //   124: goto -> 133
/*      */     //   127: iconst_1
/*      */     //   128: istore #7
/*      */     //   130: goto -> 136
/*      */     //   133: iconst_0
/*      */     //   134: istore #7
/*      */     //   136: iload #7
/*      */     //   138: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #35	-> 0
/*      */     //   #35	-> 14
/*      */     //   #35	-> 28
/*      */     //   #36	-> 34
/*      */     //   #36	-> 48
/*      */     //   #36	-> 55
/*      */     //   #36	-> 61
/*      */     //   #36	-> 64
/*      */     //   #37	-> 71
/*      */     //   #37	-> 85
/*      */     //   #37	-> 92
/*      */     //   #37	-> 97
/*      */     //   #37	-> 99
/*      */     //   #38	-> 105
/*      */     //   #38	-> 113
/*      */     //   #39	-> 119
/*      */     //   #39	-> 127
/*      */     //   #40	-> 133
/*      */     //   #0	-> 136
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	139	0	x	I
/*      */     //   0	139	1	y	I
/*      */     //   0	139	2	nalast	I
/*      */     //   0	139	3	iftmp$352	I
/*      */     //   0	139	4	R_NaInt$351	I
/*      */     //   0	139	5	iftmp$350	I
/*      */     //   0	139	6	R_NaInt$349	I
/*      */     //   0	139	8	R_NaInt$348	I
/*      */     //   0	139	9	R_NaInt$347	I
/*      */   }
/*      */   
/*      */   public static int rcmp(double x, double y, int nalast) {
/*   45 */     nax = (Builtins.__isnan(x) == 0) ? 0 : 1; nay = (Builtins.__isnan(y) == 0) ? 0 : 1;
/*   46 */     if (nax == 0 || nay == 0) {
/*   47 */       if (nax == 0) {
/*   48 */         if (nay == 0)
/*   49 */           return (x >= y) ? (
/*   50 */             (x <= y) ? 
/*   51 */             0 : 1) : -1;  if (nalast == 0) { iftmp$346 = 1; } else { iftmp$346 = -1; }
/*      */          return iftmp$346;
/*      */       }  if (nalast == 0) { iftmp$345 = -1; }
/*      */       else { iftmp$345 = 1; }
/*      */        return iftmp$345;
/*   56 */     }  return 0; } public static int ccmp(Ptr x, Ptr y, int nalast) { nax = (Builtins.__isnan(x.getDouble()) == 0) ? 0 : 1; nay = (Builtins.__isnan(y.getDouble()) == 0) ? 0 : 1;
/*      */     
/*   58 */     if (nax == 0 || nay == 0) {
/*   59 */       if (nax == 0) {
/*   60 */         if (nay == 0) {
/*   61 */           double d2 = x.getDouble(), d1 = y.getDouble(); if (d2 >= d1) {
/*   62 */             double d4 = x.getDouble(), d3 = y.getDouble(); if (d4 <= d3) {
/*      */               
/*   64 */               nax = (Builtins.__isnan(x.getAlignedDouble(1)) == 0) ? 0 : 1; nay = (Builtins.__isnan(y.getAlignedDouble(1)) == 0) ? 0 : 1;
/*   65 */               if (nax == 0 || nay == 0) {
/*   66 */                 if (nax == 0) {
/*   67 */                   if (nay == 0)
/*   68 */                   { double d6 = x.getAlignedDouble(1), d5 = y.getAlignedDouble(1); if (d6 >= d5)
/*   69 */                     { double d8 = x.getAlignedDouble(1), d7 = y.getAlignedDouble(1); return (d8 <= d7) ? 
/*      */                         
/*   71 */                         0 : 1; }  return -1; }  if (nalast == 0) { iftmp$344 = 1; }
/*      */                   else { iftmp$344 = -1; }
/*      */                    return iftmp$344;
/*      */                 }  if (nalast == 0) { iftmp$343 = -1; }
/*      */                 else { iftmp$343 = 1; }
/*      */                  return iftmp$343;
/*      */               }  return 0;
/*      */             }  return 1;
/*      */           }  return -1;
/*      */         }  if (nalast == 0) { iftmp$342 = 1; }
/*      */         else { iftmp$342 = -1; }
/*      */          return iftmp$342;
/*      */       }  if (nalast == 0) { iftmp$341 = -1; }
/*      */       else { iftmp$341 = 1; }
/*      */        return iftmp$341;
/*      */     }  return 0; }
/*      */   public static int scmp(SEXP x, SEXP y, int nalast) { // Byte code:
/*      */     //   0: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   3: astore #9
/*      */     //   5: aload_0
/*      */     //   6: aload #9
/*      */     //   8: if_acmpeq -> 14
/*      */     //   11: goto -> 34
/*      */     //   14: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   17: astore #8
/*      */     //   19: aload_1
/*      */     //   20: aload #8
/*      */     //   22: if_acmpeq -> 28
/*      */     //   25: goto -> 34
/*      */     //   28: iconst_0
/*      */     //   29: istore #7
/*      */     //   31: goto -> 126
/*      */     //   34: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   37: astore #6
/*      */     //   39: aload_0
/*      */     //   40: aload #6
/*      */     //   42: if_acmpeq -> 48
/*      */     //   45: goto -> 71
/*      */     //   48: iload_2
/*      */     //   49: ifne -> 55
/*      */     //   52: goto -> 61
/*      */     //   55: iconst_1
/*      */     //   56: istore #5
/*      */     //   58: goto -> 64
/*      */     //   61: iconst_m1
/*      */     //   62: istore #5
/*      */     //   64: iload #5
/*      */     //   66: istore #7
/*      */     //   68: goto -> 126
/*      */     //   71: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   74: astore #4
/*      */     //   76: aload_1
/*      */     //   77: aload #4
/*      */     //   79: if_acmpeq -> 85
/*      */     //   82: goto -> 105
/*      */     //   85: iload_2
/*      */     //   86: ifne -> 92
/*      */     //   89: goto -> 97
/*      */     //   92: iconst_m1
/*      */     //   93: istore_3
/*      */     //   94: goto -> 99
/*      */     //   97: iconst_1
/*      */     //   98: istore_3
/*      */     //   99: iload_3
/*      */     //   100: istore #7
/*      */     //   102: goto -> 126
/*      */     //   105: aload_0
/*      */     //   106: aload_1
/*      */     //   107: if_acmpeq -> 113
/*      */     //   110: goto -> 119
/*      */     //   113: iconst_0
/*      */     //   114: istore #7
/*      */     //   116: goto -> 126
/*      */     //   119: aload_0
/*      */     //   120: aload_1
/*      */     //   121: invokestatic Rf_Scollate : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
/*      */     //   124: istore #7
/*      */     //   126: iload #7
/*      */     //   128: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #76	-> 0
/*      */     //   #76	-> 14
/*      */     //   #76	-> 28
/*      */     //   #77	-> 34
/*      */     //   #77	-> 48
/*      */     //   #77	-> 55
/*      */     //   #77	-> 61
/*      */     //   #77	-> 64
/*      */     //   #78	-> 71
/*      */     //   #78	-> 85
/*      */     //   #78	-> 92
/*      */     //   #78	-> 97
/*      */     //   #78	-> 99
/*      */     //   #79	-> 105
/*      */     //   #79	-> 113
/*      */     //   #80	-> 119
/*      */     //   #0	-> 126
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	129	0	x	Lorg/renjin/sexp/SEXP;
/*      */     //   0	129	1	y	Lorg/renjin/sexp/SEXP;
/*      */     //   0	129	2	nalast	I
/*      */     //   0	129	3	iftmp$340	I
/*      */     //   0	129	4	R_NaString$339	Lorg/renjin/sexp/SEXP;
/*      */     //   0	129	5	iftmp$338	I
/*      */     //   0	129	6	R_NaString$337	Lorg/renjin/sexp/SEXP;
/*      */     //   0	129	8	R_NaString$336	Lorg/renjin/sexp/SEXP;
/*   87 */     //   0	129	9	R_NaString$335	Lorg/renjin/sexp/SEXP; } public static int Rf_isUnsorted(SEXP x, int strictly) { n = 0; if (Rinternals.Rf_isVectorAtomic(x)) {
/*      */       
/*   89 */       n = Rinternals.XLENGTH(x);
/*   90 */       if (n > 1)
/*   91 */         switch (Rinternals.TYPEOF(x)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 10:
/*      */           case 13:
/*  100 */             if (strictly == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/*  106 */               for (i = 0; i + 1 < n; )
/*  107 */               { Ptr ptr4 = Rinternals2.INTEGER(x); int i3 = i * 4; Ptr ptr3 = ptr4; int i2 = 0 + i3, i1 = ptr3.getInt(i2); Ptr ptr2 = Rinternals2.INTEGER(x); int m = (i + 1) * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = ptr1.getInt(k); if (i1 <= j) { i++; continue; }
/*  108 */                  boolean bool = true; // Byte code: goto -> 1129 }  break; }  for (i = 0; i + 1 < n; ) { Ptr ptr4 = Rinternals2.INTEGER(x); int i3 = i * 4; Ptr ptr3 = ptr4; int i2 = 0 + i3, i1 = ptr3.getInt(i2); Ptr ptr2 = Rinternals2.INTEGER(x); int m = (i + 1) * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = ptr1.getInt(k); if (i1 < j) { i++; continue; }
/*      */                boolean bool = true; // Byte code: goto -> 1129 }
/*      */              break;
/*      */           case 14:
/*  112 */             if (strictly == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */               
/*  117 */               for (i = 0; i + 1 < n; )
/*  118 */               { Ptr ptr4 = Rinternals2.REAL(x); int i1 = i * 8; Ptr ptr3 = ptr4; int m = 0 + i1; double d2 = ptr3.getDouble(m); Ptr ptr2 = Rinternals2.REAL(x); int k = (i + 1) * 8; Ptr ptr1 = ptr2; int j = 0 + k; double d1 = ptr1.getDouble(j); if (d2 <= d1) { i++; continue; }
/*  119 */                  boolean bool = true; // Byte code: goto -> 1129 }  break; }  for (i = 0; i + 1 < n; ) { Ptr ptr4 = Rinternals2.REAL(x); int i1 = i * 8; Ptr ptr3 = ptr4; int m = 0 + i1; double d2 = ptr3.getDouble(m); Ptr ptr2 = Rinternals2.REAL(x); int k = (i + 1) * 8; Ptr ptr1 = ptr2; int j = 0 + k; double d1 = ptr1.getDouble(j); if (d2 < d1) { i++; continue; }
/*      */                boolean bool = true; // Byte code: goto -> 1129 }
/*      */              break;
/*      */           case 15:
/*  123 */             if (strictly == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */               
/*  128 */               for (i = 0; i + 1 < n; )
/*  129 */               { DoublePtr doublePtr4 = Rinternals.COMPLEX(x); int i1 = (i + 1) * 16; DoublePtr doublePtr3 = doublePtr4; int m = 0 + i1; DoublePtr doublePtr2 = Rinternals.COMPLEX(x); int k = i * 16; DoublePtr doublePtr1 = doublePtr2; int j = 0 + k; if (ccmp(doublePtr1.pointerPlus(j).copyOf(16), doublePtr3.pointerPlus(m).copyOf(16), 1) <= 0) { i++; continue; }
/*  130 */                  boolean bool = true; // Byte code: goto -> 1129 }  break; }  for (i = 0; i + 1 < n; ) { DoublePtr doublePtr4 = Rinternals.COMPLEX(x); int i1 = (i + 1) * 16; DoublePtr doublePtr3 = doublePtr4; int m = 0 + i1; DoublePtr doublePtr2 = Rinternals.COMPLEX(x); int k = i * 16; DoublePtr doublePtr1 = doublePtr2; int j = 0 + k; if (ccmp(doublePtr1.pointerPlus(j).copyOf(16), doublePtr3.pointerPlus(m).copyOf(16), 1) < 0) { i++; continue; }
/*      */                boolean bool = true; // Byte code: goto -> 1129 }
/*      */              break;
/*      */           case 16:
/*  134 */             if (strictly == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/*  140 */               for (i = 0; i + 1 < n; )
/*  141 */               { int j = i + 1; SEXP sEXP = Rinternals.STRING_ELT(x, j); if (scmp(Rinternals.STRING_ELT(x, i), sEXP, 1) <= 0) {
/*      */                   i++; continue;
/*  143 */                 }  boolean bool = true; // Byte code: goto -> 1129 }  break; }  for (i = 0; i + 1 < n; ) { int j = i + 1; SEXP sEXP = Rinternals.STRING_ELT(x, j); if (scmp(Rinternals.STRING_ELT(x, i), sEXP, 1) < 0) { i++; continue; }
/*      */                boolean bool = true; // Byte code: goto -> 1129 }
/*      */              break;
/*      */           case 24:
/*  147 */             if (strictly == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/*  153 */               for (i = 0; i + 1 < n; )
/*  154 */               { BytePtr bytePtr4 = Rinternals.RAW(x); i$333 = i; BytePtr bytePtr3 = bytePtr4; int i2 = 0 + i$333, i1 = bytePtr3.getByte(i2) & 0xFF; BytePtr bytePtr2 = Rinternals.RAW(x); int m = i + 1; BytePtr bytePtr1 = bytePtr2; int k = 0 + m, j = bytePtr1.getByte(k) & 0xFF; if (i1 <= j) { i++; continue; }
/*  155 */                  boolean bool = true; // Byte code: goto -> 1129 }  break; }  for (i = 0; i + 1 < n; ) { BytePtr bytePtr4 = Rinternals.RAW(x); i$331 = i; BytePtr bytePtr3 = bytePtr4; int i2 = 0 + i$331, i1 = bytePtr3.getByte(i2) & 0xFF; BytePtr bytePtr2 = Rinternals.RAW(x); int m = i + 1; BytePtr bytePtr1 = bytePtr2; int k = 0 + m, j = bytePtr1.getByte(k) & 0xFF; if (i1 < j) { i++; continue; }
/*      */                boolean bool = true; // Byte code: goto -> 1129 }
/*      */              break;
/*      */           default:
/*  159 */             Defn.UNIMPLEMENTED_TYPE(new BytePtr("isUnsorted\000".getBytes(), 0), x); break;
/*      */         }  
/*  161 */       return 0;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_"); }
/*      */   
/*      */   public static SEXP do_isunsorted(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*  166 */     ans = new SEXP[1]; ans[0] = (SEXP)BytePtr.of(0).getArray(); Defn.Rf_checkArityCall(op, args, call);
/*      */     
/*  168 */     x = Rinternals.CAR(args);
/*  169 */     throw new UnsatisfiedLinkException("Rf_DispatchOrEval");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_isort(Ptr x, int n) {
/*  217 */     for (h = 0, i = 0, nalast = 0, v = 0, nalast = 1, h = 1; n / 9 >= h; h = h * 3 + 1); while (h > 0) { for (i = h; i < n; ) { Ptr ptr2; int i1, i2; for (i2 = i * 4, ptr2 = x, i1 = i2, v = ptr2.getInt(i1), j = i; j >= h; ) { int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (icmp(ptr3.getInt(i3), v, nalast) <= 0) break;  int i9 = j * 4; Ptr ptr5 = x; int i8 = i9, i7 = (j - h) * 4; Ptr ptr4 = x; int i6 = i7, i5 = ptr4.getInt(i6); ptr5.setInt(i8, i5); j -= h; }  int m = j * 4; Ptr ptr1 = x; int k = m; ptr1.setInt(k, v); i++; }  h /= 3; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_rsort(Ptr x, int n) {
/*  225 */     for (h = 0, i = 0, nalast = 0, v = 0.0D, nalast = 1, h = 1; n / 9 >= h; h = h * 3 + 1); while (h > 0) { for (i = h; i < n; ) { Ptr ptr2; int i1, i2; for (i2 = i * 8, ptr2 = x, i1 = i2, v = ptr2.getDouble(i1), j = i; j >= h; ) { int i4 = (j - h) * 8; Ptr ptr3 = x; int i3 = i4; if (rcmp(ptr3.getDouble(i3), v, nalast) <= 0) break;  int i8 = j * 8; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 8; Ptr ptr4 = x; int i5 = i6; double d = ptr4.getDouble(i5); ptr5.setDouble(i7, d); j -= h; }  int m = j * 8; Ptr ptr1 = x; int k = m; ptr1.setDouble(k, v); i++; }  h /= 3; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_csort(Ptr x, int n) {
/*      */     MixedPtr mixedPtr;
/*  233 */     for (mixedPtr = MixedPtr.malloc(16), h = 0, i = 0, nalast = 0, nalast = 1, h = 1; n / 9 >= h; h = h * 3 + 1); while (h > 0) { for (i = h; i < n; ) { int i2 = i * 16; Ptr ptr2 = x; int i1 = i2; mixedPtr.memcpy(ptr2.pointerPlus(i1), 16); for (j = i; j >= h; ) { int i4 = (j - h) * 16; Ptr ptr3 = x; int i3 = i4; if (ccmp(ptr3.pointerPlus(i3).copyOf(16), mixedPtr.copyOf(16), nalast) <= 0) break;  int i8 = j * 16; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 16; Ptr ptr4 = x; int i5 = i6; ptr5.pointerPlus(i7).memcpy(ptr4.pointerPlus(i5), 16); j -= h; }  int m = j * 16; Ptr ptr1 = x; int k = m; ptr1.pointerPlus(k).memcpy((Ptr)mixedPtr, 16); i++; }  h /= 3; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_ssort(Ptr x, int n) {
/*  243 */     for (h = 0, i = 0, nalast = 0, v = (SEXP)BytePtr.of(0).getArray(), nalast = 1, h = 1; n / 9 >= h; h = h * 3 + 1); while (h > 0) { for (i = h; i < n; ) { Ptr ptr2; int i1, i2; for (i2 = i * 4, ptr2 = x, i1 = i2, v = (SEXP)ptr2.getPointer(i1).getArray(), j = i; j >= h; ) { int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (scmp((SEXP)ptr3.getPointer(i3).getArray(), v, nalast) <= 0) break;  int i8 = j * 4; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 4; Ptr ptr4 = x; int i5 = i6; SEXP sEXP = (SEXP)ptr4.getPointer(i5).getArray(); ptr5.setPointer(i7, (Ptr)new RecordUnitPtr(sEXP)); j -= h; }  int m = j * 4; Ptr ptr1 = x; int k = m; ptr1.setPointer(k, (Ptr)new RecordUnitPtr(v)); i++; }  h /= 3; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rsort_with_index(Ptr x, Ptr indx, int n) {
/*  252 */     for (iv = 0, h = 0, i = 0, v = 0.0D, h = 1; n / 9 >= h; h = h * 3 + 1);
/*  253 */     for (; h > 0; h /= 3) {
/*  254 */       for (i = h; i < n; i++) {
/*  255 */         int i6 = i * 8; Ptr ptr4 = x; int i5 = i6; v = ptr4.getDouble(i5); int i4 = i * 4; Ptr ptr3 = indx; int i3 = i4; iv = ptr3.getInt(i3);
/*  256 */         j = i;
/*  257 */         while (j >= h) { int i8 = (j - h) * 8; Ptr ptr5 = x; int i7 = i8; if (rcmp(ptr5.getDouble(i7), v, 1) <= 0)
/*  258 */             break;  int i17 = j * 8; Ptr ptr9 = x; int i16 = i17, i15 = (j - h) * 8; Ptr ptr8 = x; int i14 = i15; double d = ptr8.getDouble(i14); ptr9.setDouble(i16, d); int i13 = j * 4; Ptr ptr7 = indx; int i12 = i13, i11 = (j - h) * 4; Ptr ptr6 = indx; int i10 = i11, i9 = ptr6.getInt(i10); ptr7.setInt(i12, i9); j -= h; }
/*  259 */          int i2 = j * 8; Ptr ptr2 = x; int i1 = i2; ptr2.setDouble(i1, v); int m = j * 4; Ptr ptr1 = indx; int k = m; ptr1.setInt(k, iv);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_revsort(Ptr a, Ptr ib, int n) {
/*  274 */     ii = 0; ra = 0.0D; i = 0; ir = 0; l = 0; if (n > 1) {
/*      */       
/*  276 */       a = a.pointerPlus(-8); ib = ib.pointerPlus(-4);
/*      */       
/*  278 */       l = (n >> 1) + 1;
/*  279 */       ir = n;
/*      */       
/*      */       while (true) {
/*  282 */         if (l <= 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  288 */           int i11 = ir * 8; Ptr ptr6 = a; int i10 = i11; ra = ptr6.getDouble(i10);
/*  289 */           int i9 = ir * 4; Ptr ptr5 = ib; int i8 = i9; ii = ptr5.getInt(i8);
/*  290 */           int i7 = ir * 8; Ptr ptr4 = a; int i6 = i7; double d = a.getAlignedDouble(1); ptr4.setDouble(i6, d);
/*  291 */           int i5 = ir * 4; Ptr ptr3 = ib; int i4 = i5, i3 = ib.getAlignedInt(1); ptr3.setInt(i4, i3);
/*  292 */           if (--ir == 1) {
/*  293 */             a.setDouble(8, ra);
/*  294 */             ib.setInt(4, ii); break;
/*      */           } 
/*      */         } else {
/*      */           l--; int i6 = l * 8; Ptr ptr4 = a; int i5 = i6; ra = ptr4.getDouble(i5); int i4 = l * 4; Ptr ptr3 = ib; int i3 = i4; ii = ptr3.getInt(i3);
/*  298 */         }  i = l;
/*  299 */         j = l << 1;
/*  300 */         while (j <= ir) {
/*  301 */           if (j < ir) { int i17 = j * 8; Ptr ptr9 = a; int i16 = i17; double d2 = ptr9.getDouble(i16); int i15 = (j + 1) * 8; Ptr ptr8 = a; int i14 = i15; double d1 = ptr8.getDouble(i14); if (d2 > d1) j++;  }
/*  302 */            int i13 = j * 8; Ptr ptr7 = a; int i12 = i13; if (ptr7.getDouble(i12) >= ra) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  308 */             j = ir + 1; continue;
/*      */           }  int i11 = i * 8; Ptr ptr6 = a; int i10 = i11, i9 = j * 8; Ptr ptr5 = a; int i8 = i9; double d = ptr5.getDouble(i8); ptr6.setDouble(i10, d); int i7 = i * 4; Ptr ptr4 = ib; int i6 = i7, i5 = j * 4; Ptr ptr3 = ib; int i4 = i5, i3 = ptr3.getInt(i4); ptr4.setInt(i6, i3); i = j; j = i + j;
/*  310 */         }  int i2 = i * 8; Ptr ptr2 = a; int i1 = i2; ptr2.setDouble(i1, ra);
/*  311 */         int m = i * 4; Ptr ptr1 = ib; int k = m; ptr1.setInt(k, ii);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_sort(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*  321 */     Defn.Rf_checkArityCall(op, args, call);
/*      */     
/*  323 */     decreasing = Rinternals.Rf_asLogical(Rinternals.CADR(args));
/*  324 */     if (Arith.R_NaInt != decreasing) {
/*      */       
/*  326 */       SEXP sEXP = Rinternals.CAR(args); R_NilValue$279 = Rinternals.R_NilValue; if (sEXP != R_NilValue$279) {
/*  327 */         if (Rinternals.Rf_isVectorAtomic(Rinternals.CAR(args))) {
/*      */           
/*  329 */           if (Rinternals.TYPEOF(Rinternals.CAR(args)) != 24) {
/*      */ 
/*      */ 
/*      */             
/*  333 */             ans = Rinternals.Rf_duplicate(Rinternals.CAR(args)); Rinternals.Rf_protect(ans);
/*  334 */             R_NilValue$280 = Rinternals.R_NilValue; Rinternals.SET_ATTRIB(ans, R_NilValue$280);
/*  335 */             Rinternals.SET_OBJECT(ans, 0);
/*  336 */             Rf_sortVector(ans, decreasing);
/*      */             
/*  338 */             return ans;
/*      */           } 
/*      */           throw new UnsatisfiedLinkException("_");
/*      */         } 
/*      */         throw new UnsatisfiedLinkException("_");
/*      */       } 
/*      */       return Rinternals.R_NilValue;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_isort2(Ptr x, int n, int decreasing) {
/*  375 */     t = 0; h = 0; i = 0; v = 0; if (n <= 1) Error.Rf_error(new BytePtr("'n >= 2' is required\000".getBytes(), 0), new Object[0]); 
/*  376 */     for (t = 0; Context.get__sort$incs()[t] > n; t++);
/*  377 */     if (decreasing == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  383 */       for (h = Context.get__sort$incs()[t]; t <= 19; ) { for (i = h; i < n; ) { Ptr ptr2; int i1, i2; for (i2 = i * 4, ptr2 = x, i1 = i2, v = ptr2.getInt(i1), j = i; j >= h; ) { int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (ptr3.getInt(i3) <= v) break;  int i9 = j * 4; Ptr ptr5 = x; int i8 = i9, i7 = (j - h) * 4; Ptr ptr4 = x; int i6 = i7, i5 = ptr4.getInt(i6); ptr5.setInt(i8, i5); j -= h; }  int m = j * 4; Ptr ptr1 = x; int k = m; ptr1.setInt(k, v); i++; }  h = Context.get__sort$incs()[++t]; }
/*      */        return;
/*      */     }  for (h = Context.get__sort$incs()[t]; t <= 19; ) {
/*      */       for (i = h; i < n; ) {
/*      */         Ptr ptr2; int i1, i2; for (i2 = i * 4, ptr2 = x, i1 = i2, v = ptr2.getInt(i1), j = i; j >= h; ) {
/*      */           int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (ptr3.getInt(i3) >= v)
/*      */             break;  int i9 = j * 4; Ptr ptr5 = x; int i8 = i9, i7 = (j - h) * 4; Ptr ptr4 = x; int i6 = i7, i5 = ptr4.getInt(i6); ptr5.setInt(i8, i5); j -= h;
/*      */         }  int m = j * 4; Ptr ptr1 = x; int k = m; ptr1.setInt(k, v); i++;
/*      */       }  h = Context.get__sort$incs()[++t];
/*  392 */     }  } public static void R_rsort2(Ptr x, int n, int decreasing) { t = 0; h = 0; i = 0; v = 0.0D; if (n <= 1) Error.Rf_error(new BytePtr("'n >= 2' is required\000".getBytes(), 0), new Object[0]); 
/*  393 */     for (t = 0; Context.get__sort$incs()[t] > n; t++);
/*  394 */     if (decreasing == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  400 */       for (h = Context.get__sort$incs()[t]; t <= 19; ) { for (i = h; i < n; ) { Ptr ptr2; int i1, i2; for (i2 = i * 8, ptr2 = x, i1 = i2, v = ptr2.getDouble(i1), j = i; j >= h; ) { int i4 = (j - h) * 8; Ptr ptr3 = x; int i3 = i4; if (ptr3.getDouble(i3) <= v) break;  int i8 = j * 8; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 8; Ptr ptr4 = x; int i5 = i6; double d = ptr4.getDouble(i5); ptr5.setDouble(i7, d); j -= h; }  int m = j * 8; Ptr ptr1 = x; int k = m; ptr1.setDouble(k, v); i++; }  h = Context.get__sort$incs()[++t]; }
/*      */        return;
/*      */     }  for (h = Context.get__sort$incs()[t]; t <= 19; ) {
/*      */       for (i = h; i < n; ) {
/*      */         Ptr ptr2; int i1, i2; for (i2 = i * 8, ptr2 = x, i1 = i2, v = ptr2.getDouble(i1), j = i; j >= h; ) {
/*      */           int i4 = (j - h) * 8; Ptr ptr3 = x; int i3 = i4; if (ptr3.getDouble(i3) >= v)
/*      */             break;  int i8 = j * 8; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 8; Ptr ptr4 = x; int i5 = i6; double d = ptr4.getDouble(i5); ptr5.setDouble(i7, d); j -= h;
/*      */         }  int m = j * 8; Ptr ptr1 = x; int k = m; ptr1.setDouble(k, v); i++;
/*      */       }  h = Context.get__sort$incs()[++t];
/*  409 */     }  } public static void R_csort2(Ptr x, int n, int decreasing) { MixedPtr mixedPtr = MixedPtr.malloc(16); t = 0; h = 0; i = 0; if (n <= 1) Error.Rf_error(new BytePtr("'n >= 2' is required\000".getBytes(), 0), new Object[0]); 
/*  410 */     for (t = 0; Context.get__sort$incs()[t] > n; t++);
/*  411 */     for (h = Context.get__sort$incs()[t]; t <= 19; h = Context.get__sort$incs()[++t]) {
/*  412 */       for (i = h; i < n; i++) {
/*  413 */         int i2 = i * 16; Ptr ptr2 = x; int i1 = i2; mixedPtr.memcpy(ptr2.pointerPlus(i1), 16);
/*  414 */         j = i;
/*  415 */         if (decreasing == 0)
/*      */         
/*      */         { 
/*      */ 
/*      */           
/*  420 */           while (j >= h) { int i4 = (j - h) * 16; Ptr ptr3 = x; int i3 = i4; double d2 = ptr3.getDouble(i3), d1 = mixedPtr.getDouble(); if (d2 <= d1)
/*  421 */             { int i12 = (j - h) * 16; Ptr ptr7 = x; int i11 = i12; double d6 = ptr7.getDouble(i11), d5 = mixedPtr.getDouble(); if (d6 != d5) break;  int i10 = (j - h) * 16; Ptr ptr6 = x; int i9 = i10; double d4 = ptr6.getDouble(i9 + 8), d3 = mixedPtr.getAlignedDouble(1); if (d4 <= d3)
/*  422 */                 break;  }  int i8 = j * 16; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 16; Ptr ptr4 = x; int i5 = i6; ptr5.pointerPlus(i7).memcpy(ptr4.pointerPlus(i5), 16); j -= h; }  } else { while (j >= h) { int i4 = (j - h) * 16; Ptr ptr3 = x; int i3 = i4; double d2 = ptr3.getDouble(i3), d1 = mixedPtr.getDouble(); if (d2 >= d1) { int i12 = (j - h) * 16; Ptr ptr7 = x; int i11 = i12; double d6 = ptr7.getDouble(i11), d5 = mixedPtr.getDouble(); if (d6 != d5) break;  int i10 = (j - h) * 16; Ptr ptr6 = x; int i9 = i10; double d4 = ptr6.getDouble(i9 + 8), d3 = mixedPtr.getAlignedDouble(1); if (d4 >= d3)
/*  423 */                 break;  }  int i8 = j * 16; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 16; Ptr ptr4 = x; int i5 = i6; ptr5.pointerPlus(i7).memcpy(ptr4.pointerPlus(i5), 16); j -= h; }  }  int m = j * 16; Ptr ptr1 = x; int k = m; ptr1.pointerPlus(k).memcpy((Ptr)mixedPtr, 16);
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void ssort2(Ptr x, int n, int decreasing) {
/*  432 */     t = 0; h = 0; i = 0; v = (SEXP)BytePtr.of(0).getArray(); if (n <= 1) Error.Rf_error(new BytePtr("'n >= 2' is required\000".getBytes(), 0), new Object[0]); 
/*  433 */     for (t = 0; Context.get__sort$incs()[t] > n; t++);
/*  434 */     for (h = Context.get__sort$incs()[t]; t <= 19; h = Context.get__sort$incs()[++t]) {
/*  435 */       for (i = h; i < n; i++) {
/*  436 */         int i2 = i * 4; Ptr ptr2 = x; int i1 = i2; v = (SEXP)ptr2.getPointer(i1).getArray();
/*  437 */         j = i;
/*  438 */         if (decreasing == 0)
/*      */         
/*      */         { 
/*      */           
/*  442 */           while (j >= h) { int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (scmp((SEXP)ptr3.getPointer(i3).getArray(), v, 1) <= 0)
/*  443 */               break;  int i8 = j * 4; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 4; Ptr ptr4 = x; int i5 = i6; SEXP sEXP = (SEXP)ptr4.getPointer(i5).getArray(); ptr5.setPointer(i7, (Ptr)new RecordUnitPtr(sEXP)); j -= h; }  } else { while (j >= h) { int i4 = (j - h) * 4; Ptr ptr3 = x; int i3 = i4; if (scmp((SEXP)ptr3.getPointer(i3).getArray(), v, 1) >= 0)
/*  444 */               break;  int i8 = j * 4; Ptr ptr5 = x; int i7 = i8, i6 = (j - h) * 4; Ptr ptr4 = x; int i5 = i6; SEXP sEXP = (SEXP)ptr4.getPointer(i5).getArray(); ptr5.setPointer(i7, (Ptr)new RecordUnitPtr(sEXP)); j -= h; }  }  int m = j * 4; Ptr ptr1 = x; int k = m; ptr1.setPointer(k, (Ptr)new RecordUnitPtr(v));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_sortVector(SEXP s, int decreasing) {
/*  451 */     n = Rinternals.XLENGTH(s);
/*  452 */     if (n > 1 && (decreasing != 0 || Rf_isUnsorted(s, 0) != 0)) {
/*  453 */       switch (Rinternals.TYPEOF(s)) {
/*      */         case 10:
/*      */         case 13:
/*  456 */           R_isort2(Rinternals2.INTEGER(s), n, decreasing);
/*      */           return;
/*      */         case 14:
/*  459 */           R_rsort2(Rinternals2.REAL(s), n, decreasing);
/*      */           return;
/*      */         case 15:
/*  462 */           R_csort2((Ptr)Rinternals.COMPLEX(s), n, decreasing);
/*      */           return;
/*      */         case 16:
/*  465 */           throw new UnsatisfiedLinkException("STRING_PTR");
/*      */       } 
/*      */       
/*  468 */       Defn.UNIMPLEMENTED_TYPE(new BytePtr("sortVector\000".getBytes(), 0), s);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void iPsort2(Ptr x, int lo, int hi, int k) {
/*  502 */     for (j = 0, i = 0, R = 0, L = 0, nalast = 0, v = 0, nalast = 1, L = lo, R = hi; L < R; ) { Ptr ptr; int m; int n; for (n = k * 4, ptr = x, m = n, v = ptr.getInt(m), i = L, j = R; i <= j; ) { while (true) { int i2 = i * 4; Ptr ptr1 = x; int i1 = i2; if (icmp(ptr1.getInt(i1), v, nalast) >= 0) break;  i++; }  while (true) { int i3 = j * 4; Ptr ptr1 = x; int i2 = i3, i1 = ptr1.getInt(i2); if (icmp(v, i1, nalast) >= 0) { if (i > j) continue;  int i12 = i * 4; Ptr ptr5 = x; int i11 = i12; w = ptr5.getInt(i11); int i10 = i * 4; Ptr ptr4 = x; int i9 = i10, i8 = j * 4; Ptr ptr3 = x; int i7 = i8, i6 = ptr3.getInt(i7); ptr4.setInt(i9, i6); i++; int i5 = j * 4; Ptr ptr2 = x; int i4 = i5; ptr2.setInt(i4, w); j--; continue; }  j--; }  }  if (j < k) L = i;  if (k >= i) continue;  R = j; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rPsort2(Ptr x, int lo, int hi, int k) {
/*  510 */     for (j = 0, i = 0, R = 0, L = 0, nalast = 0, v = 0.0D, nalast = 1, L = lo, R = hi; L < R; ) { Ptr ptr; int m; int n; for (n = k * 8, ptr = x, m = n, v = ptr.getDouble(m), i = L, j = R; i <= j; ) { while (true) { int i2 = i * 8; Ptr ptr1 = x; int i1 = i2; if (rcmp(ptr1.getDouble(i1), v, nalast) >= 0) break;  i++; }  while (true) { int i2 = j * 8; Ptr ptr1 = x; int i1 = i2; double d = ptr1.getDouble(i1); if (rcmp(v, d, nalast) >= 0) { if (i > j) continue;  int i10 = i * 8; Ptr ptr5 = x; int i9 = i10; w = ptr5.getDouble(i9); int i8 = i * 8; Ptr ptr4 = x; int i7 = i8, i6 = j * 8; Ptr ptr3 = x; int i5 = i6; double d1 = ptr3.getDouble(i5); ptr4.setDouble(i7, d1); i++; int i4 = j * 8; Ptr ptr2 = x; int i3 = i4; ptr2.setDouble(i3, w); j--; continue; }  j--; }  }  if (j < k) L = i;  if (k >= i) continue;  R = j; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cPsort2(Ptr x, int lo, int hi, int k) {
/*  518 */     for (MixedPtr mixedPtr1 = MixedPtr.malloc(16), mixedPtr2 = MixedPtr.malloc(16); L < R; ) { int n = k * 16; Ptr ptr = x; int m = n; mixedPtr2.memcpy(ptr.pointerPlus(m), 16); for (i = L, j = R; i <= j; ) { while (true) { int i2 = i * 16; Ptr ptr1 = x; int i1 = i2; if (ccmp(ptr1.pointerPlus(i1).copyOf(16), mixedPtr2.copyOf(16), nalast) >= 0) break;  i++; }  while (true) { int i2 = j * 16; Ptr ptr1 = x; int i1 = i2; if (ccmp(mixedPtr2.copyOf(16), ptr1.pointerPlus(i1).copyOf(16), nalast) >= 0) { if (i > j) continue;  int i10 = i * 16; Ptr ptr5 = x; int i9 = i10; mixedPtr1.memcpy(ptr5.pointerPlus(i9), 16); int i8 = i * 16; Ptr ptr4 = x; int i7 = i8, i6 = j * 16; Ptr ptr3 = x; int i5 = i6; ptr4.pointerPlus(i7).memcpy(ptr3.pointerPlus(i5), 16); i++; int i4 = j * 16; Ptr ptr2 = x; int i3 = i4; ptr2.pointerPlus(i3).memcpy((Ptr)mixedPtr1, 16); j--; continue; }  j--; }  }  if (j < k) L = i;  if (k >= i) continue;  R = j; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sPsort2(Ptr x, int lo, int hi, int k) {
/*  527 */     for (j = 0, i = 0, R = 0, L = 0, nalast = 0, v = (SEXP)BytePtr.of(0).getArray(), nalast = 1, L = lo, R = hi; L < R; ) { Ptr ptr; int m; int n; for (n = k * 4, ptr = x, m = n, v = (SEXP)ptr.getPointer(m).getArray(), i = L, j = R; i <= j; ) { while (true) { int i2 = i * 4; Ptr ptr1 = x; int i1 = i2; if (scmp((SEXP)ptr1.getPointer(i1).getArray(), v, nalast) >= 0) break;  i++; }  while (true) { int i2 = j * 4; Ptr ptr1 = x; int i1 = i2; SEXP sEXP = (SEXP)ptr1.getPointer(i1).getArray(); if (scmp(v, sEXP, nalast) >= 0) { if (i > j) continue;  int i10 = i * 4; Ptr ptr5 = x; int i9 = i10; w = (SEXP)ptr5.getPointer(i9).getArray(); int i8 = i * 4; Ptr ptr4 = x; int i7 = i8, i6 = j * 4; Ptr ptr3 = x; int i5 = i6; SEXP sEXP1 = (SEXP)ptr3.getPointer(i5).getArray(); ptr4.setPointer(i7, (Ptr)new RecordUnitPtr(sEXP1)); i++; int i4 = j * 4; Ptr ptr2 = x; int i3 = i4; ptr2.setPointer(i3, (Ptr)new RecordUnitPtr(w)); j--; continue; }  j--; }  }  if (j < k) L = i;  if (k >= i) continue;  R = j; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_iPsort(Ptr x, int n, int k) {
/*  535 */     int i = n + -1; iPsort2(x, 0, i, k);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_rPsort(Ptr x, int n, int k) {
/*  540 */     int i = n + -1; rPsort2(x, 0, i, k);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void Rf_cPsort(Ptr x, int n, int k) {
/*  545 */     int i = n + -1; cPsort2(x, 0, i, k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Psort(SEXP x, int lo, int hi, int k) {
/*  552 */     switch (Rinternals.TYPEOF(x)) {
/*      */       case 10:
/*      */       case 13:
/*  555 */         iPsort2(Rinternals2.INTEGER(x), lo, hi, k);
/*      */         return;
/*      */       case 14:
/*  558 */         rPsort2(Rinternals2.REAL(x), lo, hi, k);
/*      */         return;
/*      */       case 15:
/*  561 */         cPsort2((Ptr)Rinternals.COMPLEX(x), lo, hi, k);
/*      */         return;
/*      */       case 16:
/*  564 */         throw new UnsatisfiedLinkException("STRING_PTR");
/*      */     } 
/*      */     
/*  567 */     Defn.UNIMPLEMENTED_TYPE(new BytePtr("Psort\000".getBytes(), 0), x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Psort0(SEXP x, int lo, int hi, Ptr ind, int nind) {
/*  576 */     mid = 0; This = 0; if (nind > 0 && hi - lo > 0) {
/*  577 */       if (nind > 1) {
/*      */ 
/*      */ 
/*      */         
/*  581 */         This = 0;
/*  582 */         mid = (lo + hi) / 2;
/*  583 */         for (i = 0; i < nind; ) { int i6 = i * 4; Ptr ptr = ind; int i5 = i6; if (ptr.getInt(i5) + -1 <= mid) This = i;  i++; }
/*  584 */          int i4 = This * 4; Ptr ptr2 = ind; int i3 = i4; z = ptr2.getInt(i3) + -1;
/*  585 */         Psort(x, lo, hi, z);
/*  586 */         int i2 = z + -1; Psort0(x, lo, i2, ind, This);
/*  587 */         int i1 = nind - This + -1, n = (This + 1) * 4; Ptr ptr1 = ind; int m = n, k = z + 1; Psort0(x, k, hi, ptr1.pointerPlus(m), i1);
/*      */         return;
/*      */       } 
/*      */       int j = ind.getInt() + -1;
/*      */       Psort(x, lo, hi, j);
/*      */     } 
/*      */   }
/*      */   public static SEXP do_psort(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*  595 */     il = BytePtr.of(0); il$offset = 0; rl = BytePtr.of(0); rl$offset = 0; l = BytePtr.of(0); l$offset = 0; nind = 0; n = 0; x = (SEXP)BytePtr.of(0).getArray(); Defn.Rf_checkArityCall(op, args, call);
/*  596 */     x = Rinternals.CAR(args); p = Rinternals.CADR(args);
/*      */     
/*  598 */     if (Rinternals.Rf_isVectorAtomic(x)) {
/*      */       
/*  600 */       if (Rinternals.TYPEOF(x) != 24) {
/*      */         
/*  602 */         n = Rinternals.XLENGTH(x);
/*      */         
/*  604 */         if (Rinternals.IS_LONG_VEC(x) == 0 || Rinternals.TYPEOF(p) != 14) {
/*  605 */           SEXP sEXP1 = Rinternals.Rf_coerceVector(p, 13); Rinternals.SETCADR(args, sEXP1);
/*  606 */         }  p = Rinternals.CADR(args);
/*  607 */         nind = Rinternals.LENGTH(p);
/*  608 */         IntPtr intPtr = IntPtr.malloc(nind * 4); l$offset = 0;
/*  609 */         if (Rinternals.TYPEOF(p) != 14)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  618 */           il = Rinternals2.INTEGER(p); il$offset = 0;
/*  619 */           for (i = 0; i < nind; ) {
/*  620 */             int i3 = i * 4; Ptr ptr = il; int i2 = il$offset + i3, i1 = ptr.getInt(i2); R_NaInt$219 = Arith.R_NaInt; if (i1 != R_NaInt$219) {
/*  621 */               int i8 = i * 4; Ptr ptr2 = il; int i7 = il$offset + i8; if (ptr2.getInt(i7) > 0) { int i10 = i * 4; Ptr ptr3 = il; int i9 = il$offset + i10; if (ptr3.getInt(i9) <= n) {
/*      */                   
/*  623 */                   int i15 = i * 4; IntPtr intPtr1 = intPtr; int i14 = l$offset + i15, i13 = i * 4; Ptr ptr4 = il; int i12 = il$offset + i13, i11 = ptr4.getInt(i12); intPtr1.setInt(i14, i11);
/*      */                   
/*      */                   i++;
/*      */                 }  }
/*      */ 
/*      */               
/*      */               int i6 = i * 4;
/*      */               
/*      */               Ptr ptr1 = il;
/*      */               
/*      */               int i5 = il$offset + i6, i4 = ptr1.getInt(i5);
/*      */               throw new UnsatisfiedLinkException("_");
/*      */             } 
/*      */             throw new UnsatisfiedLinkException("_");
/*      */           } 
/*  638 */           SEXP sEXP1 = Rinternals.Rf_duplicate(x); Rinternals.SETCAR(args, sEXP1);
/*  639 */           R_NilValue$225 = Rinternals.R_NilValue; Rinternals.SET_ATTRIB(Rinternals.CAR(args), R_NilValue$225);
/*  640 */           Rinternals.SET_OBJECT(Rinternals.CAR(args), 0);
/*  641 */           int m = n + -1; Psort0(Rinternals.CAR(args), 0, m, intPtr.pointerPlus(l$offset), nind);
/*  642 */           return Rinternals.CAR(args); }  rl = Rinternals2.REAL(p); rl$offset = 0; for (j = 0; j < nind; ) { int i1 = j * 8; Ptr ptr = rl; int m = rl$offset + i1; if (Arith.R_finite(ptr.getDouble(m)) != 0) { int i11 = j * 4; IntPtr intPtr3 = intPtr; int i10 = l$offset + i11, i9 = j * 8; Ptr ptr1 = rl; int i8 = rl$offset + i9, i7 = (int)ptr1.getDouble(i8); intPtr3.setInt(i10, i7); int i6 = j * 4; IntPtr intPtr2 = intPtr; int i5 = l$offset + i6; if (intPtr2.getInt(i5) > 0) { int i13 = j * 4; IntPtr intPtr4 = intPtr; int i12 = l$offset + i13; if (intPtr4.getInt(i12) <= n) { j++; continue; }  }  int i4 = j * 4; IntPtr intPtr1 = intPtr; int i3 = l$offset + i4, i2 = intPtr1.getInt(i3); throw new UnsatisfiedLinkException("_"); }  throw new UnsatisfiedLinkException("_"); }  SEXP sEXP = Rinternals.Rf_duplicate(x); Rinternals.SETCAR(args, sEXP); R_NilValue$225 = Rinternals.R_NilValue; Rinternals.SET_ATTRIB(Rinternals.CAR(args), R_NilValue$225); Rinternals.SET_OBJECT(Rinternals.CAR(args), 0); int k = n + -1; Psort0(Rinternals.CAR(args), 0, k, intPtr.pointerPlus(l$offset), nind); return Rinternals.CAR(args);
/*      */       } 
/*      */       throw new UnsatisfiedLinkException("_");
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */   
/*      */   public static int equal(int i, int j, SEXP x, int nalast, SEXP rho) {
/*  650 */     c = -1;
/*      */     
/*  652 */     if (!Rinternals.OBJECT(x) || Rinternals.TYPEOF(rho) == 0) {
/*      */       SEXP sEXP; DoublePtr doublePtr1; int k; int m; DoublePtr doublePtr2; DoublePtr doublePtr3; int n; int i1; DoublePtr doublePtr4; Ptr ptr1; int i2; int i3; Ptr ptr2; double d; Ptr ptr3; int i4; int i5; Ptr ptr4; Ptr ptr5; int i6;
/*      */       int i7;
/*      */       Ptr ptr6;
/*      */       int i8;
/*      */       Ptr ptr7;
/*      */       int i9;
/*      */       int i10;
/*      */       Ptr ptr8;
/*  661 */       switch (Rinternals.TYPEOF(x)) {
/*      */         case 10:
/*      */         case 13:
/*  664 */           ptr8 = Rinternals2.INTEGER(x); i10 = j * 4; ptr7 = ptr8; i9 = 0 + i10; i8 = ptr7.getInt(i9); ptr6 = Rinternals2.INTEGER(x); i7 = i * 4; ptr5 = ptr6; i6 = 0 + i7; c = icmp(ptr5.getInt(i6), i8, nalast);
/*      */           break;
/*      */         case 14:
/*  667 */           ptr4 = Rinternals2.REAL(x); i5 = j * 8; ptr3 = ptr4; i4 = 0 + i5; d = ptr3.getDouble(i4); ptr2 = Rinternals2.REAL(x); i3 = i * 8; ptr1 = ptr2; i2 = 0 + i3; c = rcmp(ptr1.getDouble(i2), d, nalast);
/*      */           break;
/*      */         case 15:
/*  670 */           doublePtr4 = Rinternals.COMPLEX(x); i1 = j * 16; doublePtr3 = doublePtr4; n = 0 + i1; doublePtr2 = Rinternals.COMPLEX(x); m = i * 16; doublePtr1 = doublePtr2; k = 0 + m; c = ccmp(doublePtr1.pointerPlus(k).copyOf(16), doublePtr3.pointerPlus(n).copyOf(16), nalast);
/*      */           break;
/*      */         case 16:
/*  673 */           sEXP = Rinternals.STRING_ELT(x, j); c = scmp(Rinternals.STRING_ELT(x, i), sEXP, nalast);
/*      */           break;
/*      */         default:
/*  676 */           Defn.UNIMPLEMENTED_TYPE(new BytePtr("equal\000".getBytes(), 0), x); break;
/*      */       } 
/*      */     } else {
/*      */       si = Rinternals.Rf_ScalarInteger(i + 1); Rinternals.Rf_protect(si); sj = Rinternals.Rf_ScalarInteger(j + 1); Rinternals.Rf_protect(sj); call = Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr(".gt\000".getBytes(), 0)), x, si, sj); Rinternals.Rf_protect(call); c = Rinternals.Rf_asInteger(Rinternals.Rf_eval(call, rho));
/*  680 */     }  return (c != 0) ? 
/*      */       
/*  682 */       0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int greater(int i, int j, SEXP x, int nalast, int decreasing, SEXP rho) {
/*  688 */     c = -1;
/*      */     
/*  690 */     if (!Rinternals.OBJECT(x) || Rinternals.TYPEOF(rho) == 0) {
/*      */       SEXP sEXP; DoublePtr doublePtr1; int k; int m; DoublePtr doublePtr2; DoublePtr doublePtr3; int n; int i1; DoublePtr doublePtr4; Ptr ptr1; int i2; int i3; Ptr ptr2; double d; Ptr ptr3; int i4; int i5; Ptr ptr4; Ptr ptr5; int i6;
/*      */       int i7;
/*      */       Ptr ptr6;
/*      */       int i8;
/*      */       Ptr ptr7;
/*      */       int i9;
/*      */       int i10;
/*      */       Ptr ptr8;
/*  699 */       switch (Rinternals.TYPEOF(x)) {
/*      */         case 10:
/*      */         case 13:
/*  702 */           ptr8 = Rinternals2.INTEGER(x); i10 = j * 4; ptr7 = ptr8; i9 = 0 + i10; i8 = ptr7.getInt(i9); ptr6 = Rinternals2.INTEGER(x); i7 = i * 4; ptr5 = ptr6; i6 = 0 + i7; c = icmp(ptr5.getInt(i6), i8, nalast);
/*      */           break;
/*      */         case 14:
/*  705 */           ptr4 = Rinternals2.REAL(x); i5 = j * 8; ptr3 = ptr4; i4 = 0 + i5; d = ptr3.getDouble(i4); ptr2 = Rinternals2.REAL(x); i3 = i * 8; ptr1 = ptr2; i2 = 0 + i3; c = rcmp(ptr1.getDouble(i2), d, nalast);
/*      */           break;
/*      */         case 15:
/*  708 */           doublePtr4 = Rinternals.COMPLEX(x); i1 = j * 16; doublePtr3 = doublePtr4; n = 0 + i1; doublePtr2 = Rinternals.COMPLEX(x); m = i * 16; doublePtr1 = doublePtr2; k = 0 + m; c = ccmp(doublePtr1.pointerPlus(k).copyOf(16), doublePtr3.pointerPlus(n).copyOf(16), nalast);
/*      */           break;
/*      */         case 16:
/*  711 */           sEXP = Rinternals.STRING_ELT(x, j); c = scmp(Rinternals.STRING_ELT(x, i), sEXP, nalast);
/*      */           break;
/*      */         default:
/*  714 */           Defn.UNIMPLEMENTED_TYPE(new BytePtr("greater\000".getBytes(), 0), x); break;
/*      */       } 
/*      */     } else {
/*      */       si = Rinternals.Rf_ScalarInteger(i + 1); Rinternals.Rf_protect(si); sj = Rinternals.Rf_ScalarInteger(j + 1); Rinternals.Rf_protect(sj); call = Rinternals.Rf_lang4(Rinternals.Rf_install(new BytePtr(".gt\000".getBytes(), 0)), x, si, sj); Rinternals.Rf_protect(call); c = Rinternals.Rf_asInteger(Rinternals.Rf_eval(call, rho));
/*  718 */     }  if (decreasing != 0) c = -c; 
/*  719 */     return (c <= 0 && (c != 0 || j >= i)) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int listgreater(int i, int j, SEXP key, int nalast, int decreasing) {
/*      */     boolean bool;
/*  727 */     c = 0; c = -1;
/*      */     while (true) {
/*  729 */       R_NilValue$198 = Rinternals.R_NilValue; if (key != R_NilValue$198) {
/*  730 */         SEXP sEXP; DoublePtr doublePtr1; int k, m; DoublePtr doublePtr2, doublePtr3; int n, i1; DoublePtr doublePtr4; Ptr ptr1; int i2, i3; Ptr ptr2; double d; Ptr ptr3; int i4, i5; Ptr ptr4, ptr5; int i6, i7; Ptr ptr6; int i8; Ptr ptr7; int i9, i10; Ptr ptr8; x = Rinternals.CAR(key);
/*  731 */         switch (Rinternals.TYPEOF(x)) {
/*      */           case 10:
/*      */           case 13:
/*  734 */             ptr8 = Rinternals2.INTEGER(x); i10 = j * 4; ptr7 = ptr8; i9 = 0 + i10; i8 = ptr7.getInt(i9); ptr6 = Rinternals2.INTEGER(x); i7 = i * 4; ptr5 = ptr6; i6 = 0 + i7; c = icmp(ptr5.getInt(i6), i8, nalast);
/*      */             break;
/*      */           case 14:
/*  737 */             ptr4 = Rinternals2.REAL(x); i5 = j * 8; ptr3 = ptr4; i4 = 0 + i5; d = ptr3.getDouble(i4); ptr2 = Rinternals2.REAL(x); i3 = i * 8; ptr1 = ptr2; i2 = 0 + i3; c = rcmp(ptr1.getDouble(i2), d, nalast);
/*      */             break;
/*      */           case 15:
/*  740 */             doublePtr4 = Rinternals.COMPLEX(x); i1 = j * 16; doublePtr3 = doublePtr4; n = 0 + i1; doublePtr2 = Rinternals.COMPLEX(x); m = i * 16; doublePtr1 = doublePtr2; k = 0 + m; c = ccmp(doublePtr1.pointerPlus(k).copyOf(16), doublePtr3.pointerPlus(n).copyOf(16), nalast);
/*      */             break;
/*      */           case 16:
/*  743 */             sEXP = Rinternals.STRING_ELT(x, j); c = scmp(Rinternals.STRING_ELT(x, i), sEXP, nalast);
/*      */             break;
/*      */           default:
/*  746 */             Defn.UNIMPLEMENTED_TYPE(new BytePtr("listgreater\000".getBytes(), 0), x); break;
/*      */         } 
/*  748 */         if (decreasing != 0) c = -c; 
/*  749 */         if (c <= 0) {
/*      */           
/*  751 */           if (c >= 0)
/*      */           
/*  753 */           { key = Rinternals.CDR(key); continue; }  boolean bool2 = false; break;
/*      */         }  boolean bool1 = true; break;
/*  755 */       }  if (c != 0 || i >= j) { boolean bool1 = true; break; }  bool = false;
/*      */       break;
/*      */     } 
/*      */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void orderVector(Ptr indx, int n, SEXP key, int nalast, int decreasing, MethodHandle greater_sub) {
/*  801 */     itmp = 0; t = 0; h = 0; i = 0; if (n > 1) {
/*  802 */       for (t = 0; Context.get__sort$sincs()[t] > n; t++);
/*  803 */       for (h = Context.get__sort$sincs()[t]; t <= 15; h = Context.get__sort$sincs()[++t]) {
/*  804 */         Utils.R_CheckUserInterrupt();
/*  805 */         for (i = h; i < n; i++) {
/*  806 */           int i2 = i * 4; Ptr ptr2 = indx; int i1 = i2; itmp = ptr2.getInt(i1);
/*  807 */           j = i;
/*  808 */           while (j >= h) {
/*  809 */             int i6 = nalast ^ decreasing, i5 = (j - h) * 4; Ptr ptr3 = indx; int i4 = i5, i3 = ptr3.getInt(i4); if (greater_sub.invoke(i3, itmp, key, i6, decreasing) == 0)
/*      */               break; 
/*  811 */             int i11 = j * 4; Ptr ptr5 = indx; int i10 = i11, i9 = (j - h) * 4; Ptr ptr4 = indx; int i8 = i9, i7 = ptr4.getInt(i8); ptr5.setInt(i10, i7);
/*  812 */             j -= h;
/*      */           } 
/*  814 */           int m = j * 4; Ptr ptr1 = indx; int k = m; ptr1.setInt(k, itmp);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int listgreaterl(int i, int j, SEXP key, int nalast, int decreasing) {
/*      */     boolean bool;
/*  824 */     c = 0; c = -1;
/*      */     while (true) {
/*  826 */       R_NilValue$188 = Rinternals.R_NilValue; if (key != R_NilValue$188) {
/*  827 */         SEXP sEXP; DoublePtr doublePtr1; int k, m; DoublePtr doublePtr2, doublePtr3; int n, i1; DoublePtr doublePtr4; Ptr ptr1; int i2, i3; Ptr ptr2; double d; Ptr ptr3; int i4, i5; Ptr ptr4, ptr5; int i6, i7; Ptr ptr6; int i8; Ptr ptr7; int i9, i10; Ptr ptr8; x = Rinternals.CAR(key);
/*  828 */         switch (Rinternals.TYPEOF(x)) {
/*      */           case 10:
/*      */           case 13:
/*  831 */             ptr8 = Rinternals2.INTEGER(x); i10 = j * 4; ptr7 = ptr8; i9 = 0 + i10; i8 = ptr7.getInt(i9); ptr6 = Rinternals2.INTEGER(x); i7 = i * 4; ptr5 = ptr6; i6 = 0 + i7; c = icmp(ptr5.getInt(i6), i8, nalast);
/*      */             break;
/*      */           case 14:
/*  834 */             ptr4 = Rinternals2.REAL(x); i5 = j * 8; ptr3 = ptr4; i4 = 0 + i5; d = ptr3.getDouble(i4); ptr2 = Rinternals2.REAL(x); i3 = i * 8; ptr1 = ptr2; i2 = 0 + i3; c = rcmp(ptr1.getDouble(i2), d, nalast);
/*      */             break;
/*      */           case 15:
/*  837 */             doublePtr4 = Rinternals.COMPLEX(x); i1 = j * 16; doublePtr3 = doublePtr4; n = 0 + i1; doublePtr2 = Rinternals.COMPLEX(x); m = i * 16; doublePtr1 = doublePtr2; k = 0 + m; c = ccmp(doublePtr1.pointerPlus(k).copyOf(16), doublePtr3.pointerPlus(n).copyOf(16), nalast);
/*      */             break;
/*      */           case 16:
/*  840 */             sEXP = Rinternals.STRING_ELT(x, j); c = scmp(Rinternals.STRING_ELT(x, i), sEXP, nalast);
/*      */             break;
/*      */           default:
/*  843 */             Defn.UNIMPLEMENTED_TYPE(new BytePtr("listgreater\000".getBytes(), 0), x); break;
/*      */         } 
/*  845 */         if (decreasing != 0) c = -c; 
/*  846 */         if (c <= 0) {
/*      */           
/*  848 */           if (c >= 0)
/*      */           
/*  850 */           { key = Rinternals.CDR(key); continue; }  boolean bool2 = false; break;
/*      */         }  boolean bool1 = true; break;
/*  852 */       }  if (c != 0 || i >= j) { boolean bool1 = true; break; }  bool = false;
/*      */       break;
/*      */     } 
/*      */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void orderVectorl(Ptr indx, int n, SEXP key, int nalast, int decreasing, MethodHandle greater_sub) {
/*  864 */     itmp = 0; h = 0; i = 0; t = 0; if (n > 1) {
/*  865 */       for (t = 0; Context.get__sort$incs()[t] > n; t++);
/*  866 */       for (h = Context.get__sort$incs()[t]; t <= 19; h = Context.get__sort$incs()[++t]) {
/*  867 */         Utils.R_CheckUserInterrupt();
/*  868 */         for (i = h; i < n; i++) {
/*  869 */           int i2 = i * 4; Ptr ptr2 = indx; int i1 = i2; itmp = ptr2.getInt(i1);
/*  870 */           j = i;
/*  871 */           while (j >= h) {
/*  872 */             int i6 = nalast ^ decreasing, i5 = (j - h) * 4; Ptr ptr3 = indx; int i4 = i5, i3 = ptr3.getInt(i4); if (greater_sub.invoke(i3, itmp, key, i6, decreasing) == 0)
/*      */               break; 
/*  874 */             int i11 = j * 4; Ptr ptr5 = indx; int i10 = i11, i9 = (j - h) * 4; Ptr ptr4 = indx; int i8 = i9, i7 = ptr4.getInt(i8); ptr5.setInt(i10, i7);
/*  875 */             j -= h;
/*      */           } 
/*  877 */           int m = j * 4; Ptr ptr1 = indx; int k = m; ptr1.setInt(k, itmp);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_orderVector(Ptr indx, int n, SEXP arglist, int nalast, int decreasing) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #5
/*      */     //   3: goto -> 33
/*      */     //   6: iload #5
/*      */     //   8: iconst_4
/*      */     //   9: imul
/*      */     //   10: istore #8
/*      */     //   12: aload_0
/*      */     //   13: astore #6
/*      */     //   15: iload #8
/*      */     //   17: istore #7
/*      */     //   19: aload #6
/*      */     //   21: iload #7
/*      */     //   23: iload #5
/*      */     //   25: invokeinterface setInt : (II)V
/*      */     //   30: iinc #5, 1
/*      */     //   33: iload #5
/*      */     //   35: iload_1
/*      */     //   36: if_icmplt -> 6
/*      */     //   39: goto -> 42
/*      */     //   42: aload_0
/*      */     //   43: iload_1
/*      */     //   44: aload_2
/*      */     //   45: iload_3
/*      */     //   46: iload #4
/*      */     //   48: ldc_w
/*      */     //   51: invokestatic orderVector : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/sexp/SEXP;IILjava/lang/invoke/MethodHandle;)V
/*      */     //   54: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #943	-> 0
/*      */     //   #943	-> 6
/*      */     //   #943	-> 33
/*      */     //   #944	-> 42
/*      */     //   #945	-> 54
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	55	0	indx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	55	1	n	I
/*      */     //   0	55	2	arglist	Lorg/renjin/sexp/SEXP;
/*      */     //   0	55	3	nalast	I
/*      */     //   0	55	4	decreasing	I
/*      */     //   0	55	5	i	I
/*      */     //   0	55	9	i$178	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_orderVector1(Ptr indx, int n, SEXP x, int nalast, int decreasing) {
/*  952 */     for (i = 0; i < n; ) { int k = i * 4; Ptr ptr = indx; int j = k; ptr.setInt(j, i); i++; }
/*  953 */      R_NilValue$177 = Rinternals.R_NilValue; orderVector1(indx, n, x, nalast, decreasing, R_NilValue$177);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void orderVector1(Ptr indx, int n, SEXP key, int nalast, int decreasing, SEXP rho) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4: astore #6
/*      */     //   6: iconst_0
/*      */     //   7: istore #7
/*      */     //   9: iconst_0
/*      */     //   10: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13: astore #8
/*      */     //   15: iconst_0
/*      */     //   16: istore #9
/*      */     //   18: iconst_0
/*      */     //   19: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   22: astore #10
/*      */     //   24: iconst_0
/*      */     //   25: istore #11
/*      */     //   27: iconst_0
/*      */     //   28: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   31: astore #12
/*      */     //   33: iconst_0
/*      */     //   34: istore #13
/*      */     //   36: iconst_0
/*      */     //   37: istore #14
/*      */     //   39: iconst_0
/*      */     //   40: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   43: astore #15
/*      */     //   45: iconst_0
/*      */     //   46: istore #16
/*      */     //   48: iconst_0
/*      */     //   49: istore #17
/*      */     //   51: iconst_0
/*      */     //   52: istore #18
/*      */     //   54: iconst_0
/*      */     //   55: istore #19
/*      */     //   57: iconst_0
/*      */     //   58: istore #20
/*      */     //   60: iconst_0
/*      */     //   61: istore #21
/*      */     //   63: iconst_0
/*      */     //   64: istore #23
/*      */     //   66: iconst_0
/*      */     //   67: istore #19
/*      */     //   69: iload_1
/*      */     //   70: iconst_m1
/*      */     //   71: iadd
/*      */     //   72: istore #18
/*      */     //   74: iconst_0
/*      */     //   75: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   78: astore #15
/*      */     //   80: iconst_0
/*      */     //   81: istore #16
/*      */     //   83: iconst_0
/*      */     //   84: istore #14
/*      */     //   86: iconst_0
/*      */     //   87: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   90: astore #12
/*      */     //   92: iconst_0
/*      */     //   93: istore #13
/*      */     //   95: iconst_0
/*      */     //   96: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   99: astore #10
/*      */     //   101: iconst_0
/*      */     //   102: istore #11
/*      */     //   104: iconst_0
/*      */     //   105: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   108: astore #8
/*      */     //   110: iconst_0
/*      */     //   111: istore #9
/*      */     //   113: iconst_0
/*      */     //   114: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   117: astore #6
/*      */     //   119: iconst_0
/*      */     //   120: istore #7
/*      */     //   122: iload_1
/*      */     //   123: iconst_1
/*      */     //   124: if_icmple -> 130
/*      */     //   127: goto -> 133
/*      */     //   130: goto -> 6486
/*      */     //   133: aload_2
/*      */     //   134: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   137: lookupswitch default -> 235, 10 -> 188, 13 -> 188, 14 -> 200, 15 -> 226, 16 -> 212
/*      */     //   188: aload_2
/*      */     //   189: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   192: astore #12
/*      */     //   194: iconst_0
/*      */     //   195: istore #13
/*      */     //   197: goto -> 235
/*      */     //   200: aload_2
/*      */     //   201: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   204: astore #10
/*      */     //   206: iconst_0
/*      */     //   207: istore #11
/*      */     //   209: goto -> 235
/*      */     //   212: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   215: dup
/*      */     //   216: ldc_w 'STRING_PTR'
/*      */     //   219: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   222: athrow
/*      */     //   223: nop
/*      */     //   224: nop
/*      */     //   225: athrow
/*      */     //   226: aload_2
/*      */     //   227: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   230: astore #8
/*      */     //   232: iconst_0
/*      */     //   233: istore #9
/*      */     //   235: aload #5
/*      */     //   237: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   240: ifeq -> 246
/*      */     //   243: goto -> 1764
/*      */     //   246: iload_1
/*      */     //   247: iconst_4
/*      */     //   248: imul
/*      */     //   249: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   252: astore #15
/*      */     //   254: iconst_0
/*      */     //   255: istore #16
/*      */     //   257: aload_2
/*      */     //   258: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   261: lookupswitch default -> 885, 10 -> 312, 13 -> 312, 14 -> 447, 15 -> 710, 16 -> 567
/*      */     //   312: iconst_0
/*      */     //   313: istore #23
/*      */     //   315: goto -> 435
/*      */     //   318: iload #23
/*      */     //   320: iconst_4
/*      */     //   321: imul
/*      */     //   322: wide istore #687
/*      */     //   326: aload #15
/*      */     //   328: wide astore #685
/*      */     //   332: iload #16
/*      */     //   334: wide iload #687
/*      */     //   338: iadd
/*      */     //   339: wide istore #686
/*      */     //   343: iload #23
/*      */     //   345: iconst_4
/*      */     //   346: imul
/*      */     //   347: wide istore #683
/*      */     //   351: aload #12
/*      */     //   353: wide astore #681
/*      */     //   357: iload #13
/*      */     //   359: wide iload #683
/*      */     //   363: iadd
/*      */     //   364: wide istore #682
/*      */     //   368: wide aload #681
/*      */     //   372: wide iload #682
/*      */     //   376: invokeinterface getInt : (I)I
/*      */     //   381: wide istore #680
/*      */     //   385: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   388: wide istore #679
/*      */     //   392: wide iload #680
/*      */     //   396: wide iload #679
/*      */     //   400: if_icmpeq -> 410
/*      */     //   403: goto -> 406
/*      */     //   406: iconst_0
/*      */     //   407: goto -> 411
/*      */     //   410: iconst_1
/*      */     //   411: wide istore #677
/*      */     //   415: wide aload #685
/*      */     //   419: wide iload #686
/*      */     //   423: wide iload #677
/*      */     //   427: invokeinterface setInt : (II)V
/*      */     //   432: iinc #23, 1
/*      */     //   435: iload #23
/*      */     //   437: iload_1
/*      */     //   438: if_icmplt -> 318
/*      */     //   441: goto -> 444
/*      */     //   444: goto -> 903
/*      */     //   447: iconst_0
/*      */     //   448: istore #23
/*      */     //   450: goto -> 555
/*      */     //   453: iload #23
/*      */     //   455: iconst_4
/*      */     //   456: imul
/*      */     //   457: wide istore #675
/*      */     //   461: aload #15
/*      */     //   463: wide astore #673
/*      */     //   467: iload #16
/*      */     //   469: wide iload #675
/*      */     //   473: iadd
/*      */     //   474: wide istore #674
/*      */     //   478: iload #23
/*      */     //   480: bipush #8
/*      */     //   482: imul
/*      */     //   483: wide istore #671
/*      */     //   487: aload #10
/*      */     //   489: wide astore #669
/*      */     //   493: iload #11
/*      */     //   495: wide iload #671
/*      */     //   499: iadd
/*      */     //   500: wide istore #670
/*      */     //   504: wide aload #669
/*      */     //   508: wide iload #670
/*      */     //   512: invokeinterface getDouble : (I)D
/*      */     //   517: invokestatic __isnan : (D)I
/*      */     //   520: ifne -> 530
/*      */     //   523: goto -> 526
/*      */     //   526: iconst_0
/*      */     //   527: goto -> 531
/*      */     //   530: iconst_1
/*      */     //   531: wide istore #664
/*      */     //   535: wide aload #673
/*      */     //   539: wide iload #674
/*      */     //   543: wide iload #664
/*      */     //   547: invokeinterface setInt : (II)V
/*      */     //   552: iinc #23, 1
/*      */     //   555: iload #23
/*      */     //   557: iload_1
/*      */     //   558: if_icmplt -> 453
/*      */     //   561: goto -> 564
/*      */     //   564: goto -> 903
/*      */     //   567: iconst_0
/*      */     //   568: istore #23
/*      */     //   570: goto -> 698
/*      */     //   573: iload #23
/*      */     //   575: iconst_4
/*      */     //   576: imul
/*      */     //   577: wide istore #662
/*      */     //   581: aload #15
/*      */     //   583: wide astore #660
/*      */     //   587: iload #16
/*      */     //   589: wide iload #662
/*      */     //   593: iadd
/*      */     //   594: wide istore #661
/*      */     //   598: iload #23
/*      */     //   600: iconst_4
/*      */     //   601: imul
/*      */     //   602: wide istore #658
/*      */     //   606: aload #6
/*      */     //   608: wide astore #656
/*      */     //   612: iload #7
/*      */     //   614: wide iload #658
/*      */     //   618: iadd
/*      */     //   619: wide istore #657
/*      */     //   623: wide aload #656
/*      */     //   627: wide iload #657
/*      */     //   631: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   636: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   641: checkcast org/renjin/sexp/SEXP
/*      */     //   644: wide astore #655
/*      */     //   648: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   651: wide astore #654
/*      */     //   655: wide aload #655
/*      */     //   659: wide aload #654
/*      */     //   663: if_acmpeq -> 673
/*      */     //   666: goto -> 669
/*      */     //   669: iconst_0
/*      */     //   670: goto -> 674
/*      */     //   673: iconst_1
/*      */     //   674: wide istore #652
/*      */     //   678: wide aload #660
/*      */     //   682: wide iload #661
/*      */     //   686: wide iload #652
/*      */     //   690: invokeinterface setInt : (II)V
/*      */     //   695: iinc #23, 1
/*      */     //   698: iload #23
/*      */     //   700: iload_1
/*      */     //   701: if_icmplt -> 573
/*      */     //   704: goto -> 707
/*      */     //   707: goto -> 903
/*      */     //   710: iconst_0
/*      */     //   711: istore #23
/*      */     //   713: goto -> 873
/*      */     //   716: iload #23
/*      */     //   718: iconst_4
/*      */     //   719: imul
/*      */     //   720: wide istore #650
/*      */     //   724: aload #15
/*      */     //   726: wide astore #648
/*      */     //   730: iload #16
/*      */     //   732: wide iload #650
/*      */     //   736: iadd
/*      */     //   737: wide istore #649
/*      */     //   741: iload #23
/*      */     //   743: bipush #16
/*      */     //   745: imul
/*      */     //   746: wide istore #645
/*      */     //   750: aload #8
/*      */     //   752: wide astore #643
/*      */     //   756: iload #9
/*      */     //   758: wide iload #645
/*      */     //   762: iadd
/*      */     //   763: wide istore #644
/*      */     //   767: wide aload #643
/*      */     //   771: wide iload #644
/*      */     //   775: invokeinterface getDouble : (I)D
/*      */     //   780: invokestatic __isnan : (D)I
/*      */     //   783: ifne -> 840
/*      */     //   786: goto -> 789
/*      */     //   789: iload #23
/*      */     //   791: bipush #16
/*      */     //   793: imul
/*      */     //   794: wide istore #638
/*      */     //   798: aload #8
/*      */     //   800: wide astore #636
/*      */     //   804: iload #9
/*      */     //   806: wide iload #638
/*      */     //   810: iadd
/*      */     //   811: wide istore #637
/*      */     //   815: wide aload #636
/*      */     //   819: wide iload #637
/*      */     //   823: bipush #8
/*      */     //   825: iadd
/*      */     //   826: invokeinterface getDouble : (I)D
/*      */     //   831: invokestatic __isnan : (D)I
/*      */     //   834: ifne -> 840
/*      */     //   837: goto -> 848
/*      */     //   840: iconst_1
/*      */     //   841: wide istore #647
/*      */     //   845: goto -> 853
/*      */     //   848: iconst_0
/*      */     //   849: wide istore #647
/*      */     //   853: wide aload #648
/*      */     //   857: wide iload #649
/*      */     //   861: wide iload #647
/*      */     //   865: invokeinterface setInt : (II)V
/*      */     //   870: iinc #23, 1
/*      */     //   873: iload #23
/*      */     //   875: iload_1
/*      */     //   876: if_icmplt -> 716
/*      */     //   879: goto -> 882
/*      */     //   882: goto -> 903
/*      */     //   885: new org/renjin/gcc/runtime/BytePtr
/*      */     //   888: dup
/*      */     //   889: ldc_w 'orderVector1 '
/*      */     //   892: invokevirtual getBytes : ()[B
/*      */     //   895: iconst_0
/*      */     //   896: invokespecial <init> : ([BI)V
/*      */     //   899: aload_2
/*      */     //   900: invokestatic UNIMPLEMENTED_TYPE : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/sexp/SEXP;)V
/*      */     //   903: iconst_0
/*      */     //   904: istore #23
/*      */     //   906: goto -> 955
/*      */     //   909: iload #23
/*      */     //   911: iconst_4
/*      */     //   912: imul
/*      */     //   913: wide istore #631
/*      */     //   917: aload #15
/*      */     //   919: wide astore #629
/*      */     //   923: iload #16
/*      */     //   925: wide iload #631
/*      */     //   929: iadd
/*      */     //   930: wide istore #630
/*      */     //   934: wide aload #629
/*      */     //   938: wide iload #630
/*      */     //   942: invokeinterface getInt : (I)I
/*      */     //   947: iload #14
/*      */     //   949: iadd
/*      */     //   950: istore #14
/*      */     //   952: iinc #23, 1
/*      */     //   955: iload #23
/*      */     //   957: iload_1
/*      */     //   958: if_icmplt -> 909
/*      */     //   961: goto -> 964
/*      */     //   964: iload #14
/*      */     //   966: ifne -> 972
/*      */     //   969: goto -> 1764
/*      */     //   972: aload_2
/*      */     //   973: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   976: lookupswitch default -> 1764, 10 -> 1028, 13 -> 1028, 14 -> 1028, 15 -> 1028, 16 -> 1028
/*      */     //   1028: iload_3
/*      */     //   1029: ifeq -> 1035
/*      */     //   1032: goto -> 1148
/*      */     //   1035: iconst_0
/*      */     //   1036: istore #23
/*      */     //   1038: goto -> 1139
/*      */     //   1041: iload #23
/*      */     //   1043: iconst_4
/*      */     //   1044: imul
/*      */     //   1045: wide istore #625
/*      */     //   1049: aload #15
/*      */     //   1051: wide astore #623
/*      */     //   1055: iload #16
/*      */     //   1057: wide iload #625
/*      */     //   1061: iadd
/*      */     //   1062: wide istore #624
/*      */     //   1066: iload #23
/*      */     //   1068: iconst_4
/*      */     //   1069: imul
/*      */     //   1070: wide istore #621
/*      */     //   1074: aload #15
/*      */     //   1076: wide astore #619
/*      */     //   1080: iload #16
/*      */     //   1082: wide iload #621
/*      */     //   1086: iadd
/*      */     //   1087: wide istore #620
/*      */     //   1091: wide aload #619
/*      */     //   1095: wide iload #620
/*      */     //   1099: invokeinterface getInt : (I)I
/*      */     //   1104: ifeq -> 1114
/*      */     //   1107: goto -> 1110
/*      */     //   1110: iconst_0
/*      */     //   1111: goto -> 1115
/*      */     //   1114: iconst_1
/*      */     //   1115: wide istore #616
/*      */     //   1119: wide aload #623
/*      */     //   1123: wide iload #624
/*      */     //   1127: wide iload #616
/*      */     //   1131: invokeinterface setInt : (II)V
/*      */     //   1136: iinc #23, 1
/*      */     //   1139: iload #23
/*      */     //   1141: iload_1
/*      */     //   1142: if_icmplt -> 1041
/*      */     //   1145: goto -> 1148
/*      */     //   1148: iconst_0
/*      */     //   1149: istore #20
/*      */     //   1151: goto -> 1157
/*      */     //   1154: iinc #20, 1
/*      */     //   1157: invokestatic get__sort$sincs : ()[I
/*      */     //   1160: iload #20
/*      */     //   1162: iaload
/*      */     //   1163: iload_1
/*      */     //   1164: if_icmpgt -> 1154
/*      */     //   1167: goto -> 1170
/*      */     //   1170: invokestatic get__sort$sincs : ()[I
/*      */     //   1173: iload #20
/*      */     //   1175: iaload
/*      */     //   1176: istore #21
/*      */     //   1178: goto -> 1707
/*      */     //   1181: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   1184: iload #19
/*      */     //   1186: iload #21
/*      */     //   1188: iadd
/*      */     //   1189: istore #23
/*      */     //   1191: goto -> 1686
/*      */     //   1194: iload #23
/*      */     //   1196: iconst_4
/*      */     //   1197: imul
/*      */     //   1198: wide istore #613
/*      */     //   1202: aload_0
/*      */     //   1203: wide astore #611
/*      */     //   1207: wide iload #613
/*      */     //   1211: wide istore #612
/*      */     //   1215: wide aload #611
/*      */     //   1219: wide iload #612
/*      */     //   1223: invokeinterface getInt : (I)I
/*      */     //   1228: istore #17
/*      */     //   1230: iload #23
/*      */     //   1232: istore #22
/*      */     //   1234: goto -> 1323
/*      */     //   1237: iload #22
/*      */     //   1239: iconst_4
/*      */     //   1240: imul
/*      */     //   1241: wide istore #609
/*      */     //   1245: aload_0
/*      */     //   1246: wide astore #607
/*      */     //   1250: wide iload #609
/*      */     //   1254: wide istore #608
/*      */     //   1258: iload #22
/*      */     //   1260: iload #21
/*      */     //   1262: isub
/*      */     //   1263: iconst_4
/*      */     //   1264: imul
/*      */     //   1265: wide istore #604
/*      */     //   1269: aload_0
/*      */     //   1270: wide astore #602
/*      */     //   1274: wide iload #604
/*      */     //   1278: wide istore #603
/*      */     //   1282: wide aload #602
/*      */     //   1286: wide iload #603
/*      */     //   1290: invokeinterface getInt : (I)I
/*      */     //   1295: wide istore #601
/*      */     //   1299: wide aload #607
/*      */     //   1303: wide iload #608
/*      */     //   1307: wide iload #601
/*      */     //   1311: invokeinterface setInt : (II)V
/*      */     //   1316: iload #22
/*      */     //   1318: iload #21
/*      */     //   1320: isub
/*      */     //   1321: istore #22
/*      */     //   1323: iload #19
/*      */     //   1325: iload #21
/*      */     //   1327: iadd
/*      */     //   1328: iload #22
/*      */     //   1330: if_icmple -> 1336
/*      */     //   1333: goto -> 1647
/*      */     //   1336: iload #22
/*      */     //   1338: iload #21
/*      */     //   1340: isub
/*      */     //   1341: iconst_4
/*      */     //   1342: imul
/*      */     //   1343: wide istore #597
/*      */     //   1347: aload_0
/*      */     //   1348: wide astore #595
/*      */     //   1352: wide iload #597
/*      */     //   1356: wide istore #596
/*      */     //   1360: wide aload #595
/*      */     //   1364: wide iload #596
/*      */     //   1368: invokeinterface getInt : (I)I
/*      */     //   1373: iconst_4
/*      */     //   1374: imul
/*      */     //   1375: wide istore #592
/*      */     //   1379: aload #15
/*      */     //   1381: wide astore #590
/*      */     //   1385: iload #16
/*      */     //   1387: wide iload #592
/*      */     //   1391: iadd
/*      */     //   1392: wide istore #591
/*      */     //   1396: wide aload #590
/*      */     //   1400: wide iload #591
/*      */     //   1404: invokeinterface getInt : (I)I
/*      */     //   1409: wide istore #589
/*      */     //   1413: iload #17
/*      */     //   1415: iconst_4
/*      */     //   1416: imul
/*      */     //   1417: wide istore #587
/*      */     //   1421: aload #15
/*      */     //   1423: wide astore #585
/*      */     //   1427: iload #16
/*      */     //   1429: wide iload #587
/*      */     //   1433: iadd
/*      */     //   1434: wide istore #586
/*      */     //   1438: wide aload #585
/*      */     //   1442: wide iload #586
/*      */     //   1446: invokeinterface getInt : (I)I
/*      */     //   1451: wide istore #584
/*      */     //   1455: wide iload #589
/*      */     //   1459: wide iload #584
/*      */     //   1463: if_icmpgt -> 1237
/*      */     //   1466: goto -> 1469
/*      */     //   1469: iload #22
/*      */     //   1471: iload #21
/*      */     //   1473: isub
/*      */     //   1474: iconst_4
/*      */     //   1475: imul
/*      */     //   1476: wide istore #581
/*      */     //   1480: aload_0
/*      */     //   1481: wide astore #579
/*      */     //   1485: wide iload #581
/*      */     //   1489: wide istore #580
/*      */     //   1493: wide aload #579
/*      */     //   1497: wide iload #580
/*      */     //   1501: invokeinterface getInt : (I)I
/*      */     //   1506: iconst_4
/*      */     //   1507: imul
/*      */     //   1508: wide istore #576
/*      */     //   1512: aload #15
/*      */     //   1514: wide astore #574
/*      */     //   1518: iload #16
/*      */     //   1520: wide iload #576
/*      */     //   1524: iadd
/*      */     //   1525: wide istore #575
/*      */     //   1529: wide aload #574
/*      */     //   1533: wide iload #575
/*      */     //   1537: invokeinterface getInt : (I)I
/*      */     //   1542: wide istore #573
/*      */     //   1546: iload #17
/*      */     //   1548: iconst_4
/*      */     //   1549: imul
/*      */     //   1550: wide istore #571
/*      */     //   1554: aload #15
/*      */     //   1556: wide astore #569
/*      */     //   1560: iload #16
/*      */     //   1562: wide iload #571
/*      */     //   1566: iadd
/*      */     //   1567: wide istore #570
/*      */     //   1571: wide aload #569
/*      */     //   1575: wide iload #570
/*      */     //   1579: invokeinterface getInt : (I)I
/*      */     //   1584: wide istore #568
/*      */     //   1588: wide iload #573
/*      */     //   1592: wide iload #568
/*      */     //   1596: if_icmpeq -> 1602
/*      */     //   1599: goto -> 1647
/*      */     //   1602: iload #22
/*      */     //   1604: iload #21
/*      */     //   1606: isub
/*      */     //   1607: iconst_4
/*      */     //   1608: imul
/*      */     //   1609: wide istore #565
/*      */     //   1613: aload_0
/*      */     //   1614: wide astore #563
/*      */     //   1618: wide iload #565
/*      */     //   1622: wide istore #564
/*      */     //   1626: wide aload #563
/*      */     //   1630: wide iload #564
/*      */     //   1634: invokeinterface getInt : (I)I
/*      */     //   1639: iload #17
/*      */     //   1641: if_icmpgt -> 1237
/*      */     //   1644: goto -> 1647
/*      */     //   1647: iload #22
/*      */     //   1649: iconst_4
/*      */     //   1650: imul
/*      */     //   1651: wide istore #560
/*      */     //   1655: aload_0
/*      */     //   1656: wide astore #558
/*      */     //   1660: wide iload #560
/*      */     //   1664: wide istore #559
/*      */     //   1668: wide aload #558
/*      */     //   1672: wide iload #559
/*      */     //   1676: iload #17
/*      */     //   1678: invokeinterface setInt : (II)V
/*      */     //   1683: iinc #23, 1
/*      */     //   1686: iload #23
/*      */     //   1688: iload #18
/*      */     //   1690: if_icmple -> 1194
/*      */     //   1693: goto -> 1696
/*      */     //   1696: iinc #20, 1
/*      */     //   1699: invokestatic get__sort$sincs : ()[I
/*      */     //   1702: iload #20
/*      */     //   1704: iaload
/*      */     //   1705: istore #21
/*      */     //   1707: iload #20
/*      */     //   1709: bipush #15
/*      */     //   1711: if_icmple -> 1181
/*      */     //   1714: goto -> 1717
/*      */     //   1717: iload_1
/*      */     //   1718: iload #14
/*      */     //   1720: isub
/*      */     //   1721: iconst_1
/*      */     //   1722: if_icmple -> 1728
/*      */     //   1725: goto -> 1740
/*      */     //   1728: iconst_0
/*      */     //   1729: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1732: astore #15
/*      */     //   1734: iconst_0
/*      */     //   1735: istore #16
/*      */     //   1737: goto -> 6486
/*      */     //   1740: iload_3
/*      */     //   1741: ifne -> 1747
/*      */     //   1744: goto -> 1757
/*      */     //   1747: iload #18
/*      */     //   1749: iload #14
/*      */     //   1751: isub
/*      */     //   1752: istore #18
/*      */     //   1754: goto -> 1764
/*      */     //   1757: iload #19
/*      */     //   1759: iload #14
/*      */     //   1761: iadd
/*      */     //   1762: istore #19
/*      */     //   1764: iconst_0
/*      */     //   1765: istore #20
/*      */     //   1767: goto -> 1773
/*      */     //   1770: iinc #20, 1
/*      */     //   1773: invokestatic get__sort$sincs : ()[I
/*      */     //   1776: iload #20
/*      */     //   1778: iaload
/*      */     //   1779: wide istore #556
/*      */     //   1783: iload #18
/*      */     //   1785: iload #19
/*      */     //   1787: isub
/*      */     //   1788: iconst_1
/*      */     //   1789: iadd
/*      */     //   1790: wide istore #554
/*      */     //   1794: wide iload #556
/*      */     //   1798: wide iload #554
/*      */     //   1802: if_icmpgt -> 1770
/*      */     //   1805: goto -> 1808
/*      */     //   1808: aload_2
/*      */     //   1809: invokestatic OBJECT : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   1812: ifne -> 1818
/*      */     //   1815: goto -> 2133
/*      */     //   1818: aload #5
/*      */     //   1820: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1823: ifne -> 1829
/*      */     //   1826: goto -> 2133
/*      */     //   1829: invokestatic get__sort$sincs : ()[I
/*      */     //   1832: iload #20
/*      */     //   1834: iaload
/*      */     //   1835: istore #21
/*      */     //   1837: goto -> 2120
/*      */     //   1840: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   1843: iload #19
/*      */     //   1845: iload #21
/*      */     //   1847: iadd
/*      */     //   1848: istore #23
/*      */     //   1850: goto -> 2099
/*      */     //   1853: iload #23
/*      */     //   1855: iconst_4
/*      */     //   1856: imul
/*      */     //   1857: wide istore #550
/*      */     //   1861: aload_0
/*      */     //   1862: wide astore #548
/*      */     //   1866: wide iload #550
/*      */     //   1870: wide istore #549
/*      */     //   1874: wide aload #548
/*      */     //   1878: wide iload #549
/*      */     //   1882: invokeinterface getInt : (I)I
/*      */     //   1887: istore #17
/*      */     //   1889: iload #23
/*      */     //   1891: istore #22
/*      */     //   1893: goto -> 1982
/*      */     //   1896: iload #22
/*      */     //   1898: iconst_4
/*      */     //   1899: imul
/*      */     //   1900: wide istore #546
/*      */     //   1904: aload_0
/*      */     //   1905: wide astore #544
/*      */     //   1909: wide iload #546
/*      */     //   1913: wide istore #545
/*      */     //   1917: iload #22
/*      */     //   1919: iload #21
/*      */     //   1921: isub
/*      */     //   1922: iconst_4
/*      */     //   1923: imul
/*      */     //   1924: wide istore #541
/*      */     //   1928: aload_0
/*      */     //   1929: wide astore #539
/*      */     //   1933: wide iload #541
/*      */     //   1937: wide istore #540
/*      */     //   1941: wide aload #539
/*      */     //   1945: wide iload #540
/*      */     //   1949: invokeinterface getInt : (I)I
/*      */     //   1954: wide istore #538
/*      */     //   1958: wide aload #544
/*      */     //   1962: wide iload #545
/*      */     //   1966: wide iload #538
/*      */     //   1970: invokeinterface setInt : (II)V
/*      */     //   1975: iload #22
/*      */     //   1977: iload #21
/*      */     //   1979: isub
/*      */     //   1980: istore #22
/*      */     //   1982: iload #19
/*      */     //   1984: iload #21
/*      */     //   1986: iadd
/*      */     //   1987: iload #22
/*      */     //   1989: if_icmple -> 1995
/*      */     //   1992: goto -> 2060
/*      */     //   1995: iload_3
/*      */     //   1996: iload #4
/*      */     //   1998: ixor
/*      */     //   1999: wide istore #536
/*      */     //   2003: iload #22
/*      */     //   2005: iload #21
/*      */     //   2007: isub
/*      */     //   2008: iconst_4
/*      */     //   2009: imul
/*      */     //   2010: wide istore #533
/*      */     //   2014: aload_0
/*      */     //   2015: wide astore #531
/*      */     //   2019: wide iload #533
/*      */     //   2023: wide istore #532
/*      */     //   2027: wide aload #531
/*      */     //   2031: wide iload #532
/*      */     //   2035: invokeinterface getInt : (I)I
/*      */     //   2040: iload #17
/*      */     //   2042: aload_2
/*      */     //   2043: wide iload #536
/*      */     //   2047: iload #4
/*      */     //   2049: aload #5
/*      */     //   2051: invokestatic greater : (IILorg/renjin/sexp/SEXP;IILorg/renjin/sexp/SEXP;)I
/*      */     //   2054: ifne -> 1896
/*      */     //   2057: goto -> 2060
/*      */     //   2060: iload #22
/*      */     //   2062: iconst_4
/*      */     //   2063: imul
/*      */     //   2064: wide istore #527
/*      */     //   2068: aload_0
/*      */     //   2069: wide astore #525
/*      */     //   2073: wide iload #527
/*      */     //   2077: wide istore #526
/*      */     //   2081: wide aload #525
/*      */     //   2085: wide iload #526
/*      */     //   2089: iload #17
/*      */     //   2091: invokeinterface setInt : (II)V
/*      */     //   2096: iinc #23, 1
/*      */     //   2099: iload #23
/*      */     //   2101: iload #18
/*      */     //   2103: if_icmple -> 1853
/*      */     //   2106: goto -> 2109
/*      */     //   2109: iinc #20, 1
/*      */     //   2112: invokestatic get__sort$sincs : ()[I
/*      */     //   2115: iload #20
/*      */     //   2117: iaload
/*      */     //   2118: istore #21
/*      */     //   2120: iload #20
/*      */     //   2122: bipush #15
/*      */     //   2124: if_icmple -> 1840
/*      */     //   2127: goto -> 2130
/*      */     //   2130: goto -> 6457
/*      */     //   2133: aload_2
/*      */     //   2134: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2137: lookupswitch default -> 6224, 10 -> 2188, 13 -> 2188, 14 -> 3293, 15 -> 4410, 16 -> 5513
/*      */     //   2188: iload #4
/*      */     //   2190: ifne -> 2196
/*      */     //   2193: goto -> 2743
/*      */     //   2196: invokestatic get__sort$sincs : ()[I
/*      */     //   2199: iload #20
/*      */     //   2201: iaload
/*      */     //   2202: istore #21
/*      */     //   2204: goto -> 2733
/*      */     //   2207: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   2210: iload #19
/*      */     //   2212: iload #21
/*      */     //   2214: iadd
/*      */     //   2215: istore #23
/*      */     //   2217: goto -> 2712
/*      */     //   2220: iload #23
/*      */     //   2222: iconst_4
/*      */     //   2223: imul
/*      */     //   2224: wide istore #522
/*      */     //   2228: aload_0
/*      */     //   2229: wide astore #520
/*      */     //   2233: wide iload #522
/*      */     //   2237: wide istore #521
/*      */     //   2241: wide aload #520
/*      */     //   2245: wide iload #521
/*      */     //   2249: invokeinterface getInt : (I)I
/*      */     //   2254: istore #17
/*      */     //   2256: iload #23
/*      */     //   2258: istore #22
/*      */     //   2260: goto -> 2349
/*      */     //   2263: iload #22
/*      */     //   2265: iconst_4
/*      */     //   2266: imul
/*      */     //   2267: wide istore #518
/*      */     //   2271: aload_0
/*      */     //   2272: wide astore #516
/*      */     //   2276: wide iload #518
/*      */     //   2280: wide istore #517
/*      */     //   2284: iload #22
/*      */     //   2286: iload #21
/*      */     //   2288: isub
/*      */     //   2289: iconst_4
/*      */     //   2290: imul
/*      */     //   2291: wide istore #513
/*      */     //   2295: aload_0
/*      */     //   2296: wide astore #511
/*      */     //   2300: wide iload #513
/*      */     //   2304: wide istore #512
/*      */     //   2308: wide aload #511
/*      */     //   2312: wide iload #512
/*      */     //   2316: invokeinterface getInt : (I)I
/*      */     //   2321: wide istore #510
/*      */     //   2325: wide aload #516
/*      */     //   2329: wide iload #517
/*      */     //   2333: wide iload #510
/*      */     //   2337: invokeinterface setInt : (II)V
/*      */     //   2342: iload #22
/*      */     //   2344: iload #21
/*      */     //   2346: isub
/*      */     //   2347: istore #22
/*      */     //   2349: iload #19
/*      */     //   2351: iload #21
/*      */     //   2353: iadd
/*      */     //   2354: iload #22
/*      */     //   2356: if_icmple -> 2362
/*      */     //   2359: goto -> 2673
/*      */     //   2362: iload #22
/*      */     //   2364: iload #21
/*      */     //   2366: isub
/*      */     //   2367: iconst_4
/*      */     //   2368: imul
/*      */     //   2369: wide istore #506
/*      */     //   2373: aload_0
/*      */     //   2374: wide astore #504
/*      */     //   2378: wide iload #506
/*      */     //   2382: wide istore #505
/*      */     //   2386: wide aload #504
/*      */     //   2390: wide iload #505
/*      */     //   2394: invokeinterface getInt : (I)I
/*      */     //   2399: iconst_4
/*      */     //   2400: imul
/*      */     //   2401: wide istore #501
/*      */     //   2405: aload #12
/*      */     //   2407: wide astore #499
/*      */     //   2411: iload #13
/*      */     //   2413: wide iload #501
/*      */     //   2417: iadd
/*      */     //   2418: wide istore #500
/*      */     //   2422: wide aload #499
/*      */     //   2426: wide iload #500
/*      */     //   2430: invokeinterface getInt : (I)I
/*      */     //   2435: wide istore #498
/*      */     //   2439: iload #17
/*      */     //   2441: iconst_4
/*      */     //   2442: imul
/*      */     //   2443: wide istore #496
/*      */     //   2447: aload #12
/*      */     //   2449: wide astore #494
/*      */     //   2453: iload #13
/*      */     //   2455: wide iload #496
/*      */     //   2459: iadd
/*      */     //   2460: wide istore #495
/*      */     //   2464: wide aload #494
/*      */     //   2468: wide iload #495
/*      */     //   2472: invokeinterface getInt : (I)I
/*      */     //   2477: wide istore #493
/*      */     //   2481: wide iload #498
/*      */     //   2485: wide iload #493
/*      */     //   2489: if_icmplt -> 2263
/*      */     //   2492: goto -> 2495
/*      */     //   2495: iload #22
/*      */     //   2497: iload #21
/*      */     //   2499: isub
/*      */     //   2500: iconst_4
/*      */     //   2501: imul
/*      */     //   2502: wide istore #490
/*      */     //   2506: aload_0
/*      */     //   2507: wide astore #488
/*      */     //   2511: wide iload #490
/*      */     //   2515: wide istore #489
/*      */     //   2519: wide aload #488
/*      */     //   2523: wide iload #489
/*      */     //   2527: invokeinterface getInt : (I)I
/*      */     //   2532: iconst_4
/*      */     //   2533: imul
/*      */     //   2534: wide istore #485
/*      */     //   2538: aload #12
/*      */     //   2540: wide astore #483
/*      */     //   2544: iload #13
/*      */     //   2546: wide iload #485
/*      */     //   2550: iadd
/*      */     //   2551: wide istore #484
/*      */     //   2555: wide aload #483
/*      */     //   2559: wide iload #484
/*      */     //   2563: invokeinterface getInt : (I)I
/*      */     //   2568: wide istore #482
/*      */     //   2572: iload #17
/*      */     //   2574: iconst_4
/*      */     //   2575: imul
/*      */     //   2576: wide istore #480
/*      */     //   2580: aload #12
/*      */     //   2582: wide astore #478
/*      */     //   2586: iload #13
/*      */     //   2588: wide iload #480
/*      */     //   2592: iadd
/*      */     //   2593: wide istore #479
/*      */     //   2597: wide aload #478
/*      */     //   2601: wide iload #479
/*      */     //   2605: invokeinterface getInt : (I)I
/*      */     //   2610: wide istore #477
/*      */     //   2614: wide iload #482
/*      */     //   2618: wide iload #477
/*      */     //   2622: if_icmpeq -> 2628
/*      */     //   2625: goto -> 2673
/*      */     //   2628: iload #22
/*      */     //   2630: iload #21
/*      */     //   2632: isub
/*      */     //   2633: iconst_4
/*      */     //   2634: imul
/*      */     //   2635: wide istore #474
/*      */     //   2639: aload_0
/*      */     //   2640: wide astore #472
/*      */     //   2644: wide iload #474
/*      */     //   2648: wide istore #473
/*      */     //   2652: wide aload #472
/*      */     //   2656: wide iload #473
/*      */     //   2660: invokeinterface getInt : (I)I
/*      */     //   2665: iload #17
/*      */     //   2667: if_icmpgt -> 2263
/*      */     //   2670: goto -> 2673
/*      */     //   2673: iload #22
/*      */     //   2675: iconst_4
/*      */     //   2676: imul
/*      */     //   2677: wide istore #469
/*      */     //   2681: aload_0
/*      */     //   2682: wide astore #467
/*      */     //   2686: wide iload #469
/*      */     //   2690: wide istore #468
/*      */     //   2694: wide aload #467
/*      */     //   2698: wide iload #468
/*      */     //   2702: iload #17
/*      */     //   2704: invokeinterface setInt : (II)V
/*      */     //   2709: iinc #23, 1
/*      */     //   2712: iload #23
/*      */     //   2714: iload #18
/*      */     //   2716: if_icmple -> 2220
/*      */     //   2719: goto -> 2722
/*      */     //   2722: iinc #20, 1
/*      */     //   2725: invokestatic get__sort$sincs : ()[I
/*      */     //   2728: iload #20
/*      */     //   2730: iaload
/*      */     //   2731: istore #21
/*      */     //   2733: iload #20
/*      */     //   2735: bipush #15
/*      */     //   2737: if_icmple -> 2207
/*      */     //   2740: goto -> 3290
/*      */     //   2743: invokestatic get__sort$sincs : ()[I
/*      */     //   2746: iload #20
/*      */     //   2748: iaload
/*      */     //   2749: istore #21
/*      */     //   2751: goto -> 3280
/*      */     //   2754: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   2757: iload #19
/*      */     //   2759: iload #21
/*      */     //   2761: iadd
/*      */     //   2762: istore #23
/*      */     //   2764: goto -> 3259
/*      */     //   2767: iload #23
/*      */     //   2769: iconst_4
/*      */     //   2770: imul
/*      */     //   2771: wide istore #465
/*      */     //   2775: aload_0
/*      */     //   2776: wide astore #463
/*      */     //   2780: wide iload #465
/*      */     //   2784: wide istore #464
/*      */     //   2788: wide aload #463
/*      */     //   2792: wide iload #464
/*      */     //   2796: invokeinterface getInt : (I)I
/*      */     //   2801: istore #17
/*      */     //   2803: iload #23
/*      */     //   2805: istore #22
/*      */     //   2807: goto -> 2896
/*      */     //   2810: iload #22
/*      */     //   2812: iconst_4
/*      */     //   2813: imul
/*      */     //   2814: wide istore #461
/*      */     //   2818: aload_0
/*      */     //   2819: wide astore #459
/*      */     //   2823: wide iload #461
/*      */     //   2827: wide istore #460
/*      */     //   2831: iload #22
/*      */     //   2833: iload #21
/*      */     //   2835: isub
/*      */     //   2836: iconst_4
/*      */     //   2837: imul
/*      */     //   2838: wide istore #456
/*      */     //   2842: aload_0
/*      */     //   2843: wide astore #454
/*      */     //   2847: wide iload #456
/*      */     //   2851: wide istore #455
/*      */     //   2855: wide aload #454
/*      */     //   2859: wide iload #455
/*      */     //   2863: invokeinterface getInt : (I)I
/*      */     //   2868: wide istore #453
/*      */     //   2872: wide aload #459
/*      */     //   2876: wide iload #460
/*      */     //   2880: wide iload #453
/*      */     //   2884: invokeinterface setInt : (II)V
/*      */     //   2889: iload #22
/*      */     //   2891: iload #21
/*      */     //   2893: isub
/*      */     //   2894: istore #22
/*      */     //   2896: iload #19
/*      */     //   2898: iload #21
/*      */     //   2900: iadd
/*      */     //   2901: iload #22
/*      */     //   2903: if_icmple -> 2909
/*      */     //   2906: goto -> 3220
/*      */     //   2909: iload #22
/*      */     //   2911: iload #21
/*      */     //   2913: isub
/*      */     //   2914: iconst_4
/*      */     //   2915: imul
/*      */     //   2916: wide istore #449
/*      */     //   2920: aload_0
/*      */     //   2921: wide astore #447
/*      */     //   2925: wide iload #449
/*      */     //   2929: wide istore #448
/*      */     //   2933: wide aload #447
/*      */     //   2937: wide iload #448
/*      */     //   2941: invokeinterface getInt : (I)I
/*      */     //   2946: iconst_4
/*      */     //   2947: imul
/*      */     //   2948: wide istore #444
/*      */     //   2952: aload #12
/*      */     //   2954: wide astore #442
/*      */     //   2958: iload #13
/*      */     //   2960: wide iload #444
/*      */     //   2964: iadd
/*      */     //   2965: wide istore #443
/*      */     //   2969: wide aload #442
/*      */     //   2973: wide iload #443
/*      */     //   2977: invokeinterface getInt : (I)I
/*      */     //   2982: wide istore #441
/*      */     //   2986: iload #17
/*      */     //   2988: iconst_4
/*      */     //   2989: imul
/*      */     //   2990: wide istore #439
/*      */     //   2994: aload #12
/*      */     //   2996: wide astore #437
/*      */     //   3000: iload #13
/*      */     //   3002: wide iload #439
/*      */     //   3006: iadd
/*      */     //   3007: wide istore #438
/*      */     //   3011: wide aload #437
/*      */     //   3015: wide iload #438
/*      */     //   3019: invokeinterface getInt : (I)I
/*      */     //   3024: wide istore #436
/*      */     //   3028: wide iload #441
/*      */     //   3032: wide iload #436
/*      */     //   3036: if_icmpgt -> 2810
/*      */     //   3039: goto -> 3042
/*      */     //   3042: iload #22
/*      */     //   3044: iload #21
/*      */     //   3046: isub
/*      */     //   3047: iconst_4
/*      */     //   3048: imul
/*      */     //   3049: wide istore #433
/*      */     //   3053: aload_0
/*      */     //   3054: wide astore #431
/*      */     //   3058: wide iload #433
/*      */     //   3062: wide istore #432
/*      */     //   3066: wide aload #431
/*      */     //   3070: wide iload #432
/*      */     //   3074: invokeinterface getInt : (I)I
/*      */     //   3079: iconst_4
/*      */     //   3080: imul
/*      */     //   3081: wide istore #428
/*      */     //   3085: aload #12
/*      */     //   3087: wide astore #426
/*      */     //   3091: iload #13
/*      */     //   3093: wide iload #428
/*      */     //   3097: iadd
/*      */     //   3098: wide istore #427
/*      */     //   3102: wide aload #426
/*      */     //   3106: wide iload #427
/*      */     //   3110: invokeinterface getInt : (I)I
/*      */     //   3115: wide istore #425
/*      */     //   3119: iload #17
/*      */     //   3121: iconst_4
/*      */     //   3122: imul
/*      */     //   3123: wide istore #423
/*      */     //   3127: aload #12
/*      */     //   3129: wide astore #421
/*      */     //   3133: iload #13
/*      */     //   3135: wide iload #423
/*      */     //   3139: iadd
/*      */     //   3140: wide istore #422
/*      */     //   3144: wide aload #421
/*      */     //   3148: wide iload #422
/*      */     //   3152: invokeinterface getInt : (I)I
/*      */     //   3157: wide istore #420
/*      */     //   3161: wide iload #425
/*      */     //   3165: wide iload #420
/*      */     //   3169: if_icmpeq -> 3175
/*      */     //   3172: goto -> 3220
/*      */     //   3175: iload #22
/*      */     //   3177: iload #21
/*      */     //   3179: isub
/*      */     //   3180: iconst_4
/*      */     //   3181: imul
/*      */     //   3182: wide istore #417
/*      */     //   3186: aload_0
/*      */     //   3187: wide astore #415
/*      */     //   3191: wide iload #417
/*      */     //   3195: wide istore #416
/*      */     //   3199: wide aload #415
/*      */     //   3203: wide iload #416
/*      */     //   3207: invokeinterface getInt : (I)I
/*      */     //   3212: iload #17
/*      */     //   3214: if_icmpgt -> 2810
/*      */     //   3217: goto -> 3220
/*      */     //   3220: iload #22
/*      */     //   3222: iconst_4
/*      */     //   3223: imul
/*      */     //   3224: wide istore #412
/*      */     //   3228: aload_0
/*      */     //   3229: wide astore #410
/*      */     //   3233: wide iload #412
/*      */     //   3237: wide istore #411
/*      */     //   3241: wide aload #410
/*      */     //   3245: wide iload #411
/*      */     //   3249: iload #17
/*      */     //   3251: invokeinterface setInt : (II)V
/*      */     //   3256: iinc #23, 1
/*      */     //   3259: iload #23
/*      */     //   3261: iload #18
/*      */     //   3263: if_icmple -> 2767
/*      */     //   3266: goto -> 3269
/*      */     //   3269: iinc #20, 1
/*      */     //   3272: invokestatic get__sort$sincs : ()[I
/*      */     //   3275: iload #20
/*      */     //   3277: iaload
/*      */     //   3278: istore #21
/*      */     //   3280: iload #20
/*      */     //   3282: bipush #15
/*      */     //   3284: if_icmple -> 2754
/*      */     //   3287: goto -> 3290
/*      */     //   3290: goto -> 6457
/*      */     //   3293: iload #4
/*      */     //   3295: ifne -> 3301
/*      */     //   3298: goto -> 3854
/*      */     //   3301: invokestatic get__sort$sincs : ()[I
/*      */     //   3304: iload #20
/*      */     //   3306: iaload
/*      */     //   3307: istore #21
/*      */     //   3309: goto -> 3844
/*      */     //   3312: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   3315: iload #19
/*      */     //   3317: iload #21
/*      */     //   3319: iadd
/*      */     //   3320: istore #23
/*      */     //   3322: goto -> 3823
/*      */     //   3325: iload #23
/*      */     //   3327: iconst_4
/*      */     //   3328: imul
/*      */     //   3329: wide istore #408
/*      */     //   3333: aload_0
/*      */     //   3334: wide astore #406
/*      */     //   3338: wide iload #408
/*      */     //   3342: wide istore #407
/*      */     //   3346: wide aload #406
/*      */     //   3350: wide iload #407
/*      */     //   3354: invokeinterface getInt : (I)I
/*      */     //   3359: istore #17
/*      */     //   3361: iload #23
/*      */     //   3363: istore #22
/*      */     //   3365: goto -> 3454
/*      */     //   3368: iload #22
/*      */     //   3370: iconst_4
/*      */     //   3371: imul
/*      */     //   3372: wide istore #404
/*      */     //   3376: aload_0
/*      */     //   3377: wide astore #402
/*      */     //   3381: wide iload #404
/*      */     //   3385: wide istore #403
/*      */     //   3389: iload #22
/*      */     //   3391: iload #21
/*      */     //   3393: isub
/*      */     //   3394: iconst_4
/*      */     //   3395: imul
/*      */     //   3396: wide istore #399
/*      */     //   3400: aload_0
/*      */     //   3401: wide astore #397
/*      */     //   3405: wide iload #399
/*      */     //   3409: wide istore #398
/*      */     //   3413: wide aload #397
/*      */     //   3417: wide iload #398
/*      */     //   3421: invokeinterface getInt : (I)I
/*      */     //   3426: wide istore #396
/*      */     //   3430: wide aload #402
/*      */     //   3434: wide iload #403
/*      */     //   3438: wide iload #396
/*      */     //   3442: invokeinterface setInt : (II)V
/*      */     //   3447: iload #22
/*      */     //   3449: iload #21
/*      */     //   3451: isub
/*      */     //   3452: istore #22
/*      */     //   3454: iload #19
/*      */     //   3456: iload #21
/*      */     //   3458: iadd
/*      */     //   3459: iload #22
/*      */     //   3461: if_icmple -> 3467
/*      */     //   3464: goto -> 3784
/*      */     //   3467: iload #22
/*      */     //   3469: iload #21
/*      */     //   3471: isub
/*      */     //   3472: iconst_4
/*      */     //   3473: imul
/*      */     //   3474: wide istore #392
/*      */     //   3478: aload_0
/*      */     //   3479: wide astore #390
/*      */     //   3483: wide iload #392
/*      */     //   3487: wide istore #391
/*      */     //   3491: wide aload #390
/*      */     //   3495: wide iload #391
/*      */     //   3499: invokeinterface getInt : (I)I
/*      */     //   3504: bipush #8
/*      */     //   3506: imul
/*      */     //   3507: wide istore #387
/*      */     //   3511: aload #10
/*      */     //   3513: wide astore #385
/*      */     //   3517: iload #11
/*      */     //   3519: wide iload #387
/*      */     //   3523: iadd
/*      */     //   3524: wide istore #386
/*      */     //   3528: wide aload #385
/*      */     //   3532: wide iload #386
/*      */     //   3536: invokeinterface getDouble : (I)D
/*      */     //   3541: wide dstore #383
/*      */     //   3545: iload #17
/*      */     //   3547: bipush #8
/*      */     //   3549: imul
/*      */     //   3550: wide istore #381
/*      */     //   3554: aload #10
/*      */     //   3556: wide astore #379
/*      */     //   3560: iload #11
/*      */     //   3562: wide iload #381
/*      */     //   3566: iadd
/*      */     //   3567: wide istore #380
/*      */     //   3571: wide aload #379
/*      */     //   3575: wide iload #380
/*      */     //   3579: invokeinterface getDouble : (I)D
/*      */     //   3584: wide dstore #377
/*      */     //   3588: wide dload #383
/*      */     //   3592: wide dload #377
/*      */     //   3596: dcmpg
/*      */     //   3597: iflt -> 3368
/*      */     //   3600: goto -> 3603
/*      */     //   3603: iload #22
/*      */     //   3605: iload #21
/*      */     //   3607: isub
/*      */     //   3608: iconst_4
/*      */     //   3609: imul
/*      */     //   3610: wide istore #374
/*      */     //   3614: aload_0
/*      */     //   3615: wide astore #372
/*      */     //   3619: wide iload #374
/*      */     //   3623: wide istore #373
/*      */     //   3627: wide aload #372
/*      */     //   3631: wide iload #373
/*      */     //   3635: invokeinterface getInt : (I)I
/*      */     //   3640: bipush #8
/*      */     //   3642: imul
/*      */     //   3643: wide istore #369
/*      */     //   3647: aload #10
/*      */     //   3649: wide astore #367
/*      */     //   3653: iload #11
/*      */     //   3655: wide iload #369
/*      */     //   3659: iadd
/*      */     //   3660: wide istore #368
/*      */     //   3664: wide aload #367
/*      */     //   3668: wide iload #368
/*      */     //   3672: invokeinterface getDouble : (I)D
/*      */     //   3677: wide dstore #365
/*      */     //   3681: iload #17
/*      */     //   3683: bipush #8
/*      */     //   3685: imul
/*      */     //   3686: wide istore #363
/*      */     //   3690: aload #10
/*      */     //   3692: wide astore #361
/*      */     //   3696: iload #11
/*      */     //   3698: wide iload #363
/*      */     //   3702: iadd
/*      */     //   3703: wide istore #362
/*      */     //   3707: wide aload #361
/*      */     //   3711: wide iload #362
/*      */     //   3715: invokeinterface getDouble : (I)D
/*      */     //   3720: wide dstore #359
/*      */     //   3724: wide dload #365
/*      */     //   3728: wide dload #359
/*      */     //   3732: dcmpl
/*      */     //   3733: ifeq -> 3739
/*      */     //   3736: goto -> 3784
/*      */     //   3739: iload #22
/*      */     //   3741: iload #21
/*      */     //   3743: isub
/*      */     //   3744: iconst_4
/*      */     //   3745: imul
/*      */     //   3746: wide istore #356
/*      */     //   3750: aload_0
/*      */     //   3751: wide astore #354
/*      */     //   3755: wide iload #356
/*      */     //   3759: wide istore #355
/*      */     //   3763: wide aload #354
/*      */     //   3767: wide iload #355
/*      */     //   3771: invokeinterface getInt : (I)I
/*      */     //   3776: iload #17
/*      */     //   3778: if_icmpgt -> 3368
/*      */     //   3781: goto -> 3784
/*      */     //   3784: iload #22
/*      */     //   3786: iconst_4
/*      */     //   3787: imul
/*      */     //   3788: wide istore #351
/*      */     //   3792: aload_0
/*      */     //   3793: wide astore #349
/*      */     //   3797: wide iload #351
/*      */     //   3801: wide istore #350
/*      */     //   3805: wide aload #349
/*      */     //   3809: wide iload #350
/*      */     //   3813: iload #17
/*      */     //   3815: invokeinterface setInt : (II)V
/*      */     //   3820: iinc #23, 1
/*      */     //   3823: iload #23
/*      */     //   3825: iload #18
/*      */     //   3827: if_icmple -> 3325
/*      */     //   3830: goto -> 3833
/*      */     //   3833: iinc #20, 1
/*      */     //   3836: invokestatic get__sort$sincs : ()[I
/*      */     //   3839: iload #20
/*      */     //   3841: iaload
/*      */     //   3842: istore #21
/*      */     //   3844: iload #20
/*      */     //   3846: bipush #15
/*      */     //   3848: if_icmple -> 3312
/*      */     //   3851: goto -> 4407
/*      */     //   3854: invokestatic get__sort$sincs : ()[I
/*      */     //   3857: iload #20
/*      */     //   3859: iaload
/*      */     //   3860: istore #21
/*      */     //   3862: goto -> 4397
/*      */     //   3865: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   3868: iload #19
/*      */     //   3870: iload #21
/*      */     //   3872: iadd
/*      */     //   3873: istore #23
/*      */     //   3875: goto -> 4376
/*      */     //   3878: iload #23
/*      */     //   3880: iconst_4
/*      */     //   3881: imul
/*      */     //   3882: wide istore #347
/*      */     //   3886: aload_0
/*      */     //   3887: wide astore #345
/*      */     //   3891: wide iload #347
/*      */     //   3895: wide istore #346
/*      */     //   3899: wide aload #345
/*      */     //   3903: wide iload #346
/*      */     //   3907: invokeinterface getInt : (I)I
/*      */     //   3912: istore #17
/*      */     //   3914: iload #23
/*      */     //   3916: istore #22
/*      */     //   3918: goto -> 4007
/*      */     //   3921: iload #22
/*      */     //   3923: iconst_4
/*      */     //   3924: imul
/*      */     //   3925: wide istore #343
/*      */     //   3929: aload_0
/*      */     //   3930: wide astore #341
/*      */     //   3934: wide iload #343
/*      */     //   3938: wide istore #342
/*      */     //   3942: iload #22
/*      */     //   3944: iload #21
/*      */     //   3946: isub
/*      */     //   3947: iconst_4
/*      */     //   3948: imul
/*      */     //   3949: wide istore #338
/*      */     //   3953: aload_0
/*      */     //   3954: wide astore #336
/*      */     //   3958: wide iload #338
/*      */     //   3962: wide istore #337
/*      */     //   3966: wide aload #336
/*      */     //   3970: wide iload #337
/*      */     //   3974: invokeinterface getInt : (I)I
/*      */     //   3979: wide istore #335
/*      */     //   3983: wide aload #341
/*      */     //   3987: wide iload #342
/*      */     //   3991: wide iload #335
/*      */     //   3995: invokeinterface setInt : (II)V
/*      */     //   4000: iload #22
/*      */     //   4002: iload #21
/*      */     //   4004: isub
/*      */     //   4005: istore #22
/*      */     //   4007: iload #19
/*      */     //   4009: iload #21
/*      */     //   4011: iadd
/*      */     //   4012: iload #22
/*      */     //   4014: if_icmple -> 4020
/*      */     //   4017: goto -> 4337
/*      */     //   4020: iload #22
/*      */     //   4022: iload #21
/*      */     //   4024: isub
/*      */     //   4025: iconst_4
/*      */     //   4026: imul
/*      */     //   4027: wide istore #331
/*      */     //   4031: aload_0
/*      */     //   4032: wide astore #329
/*      */     //   4036: wide iload #331
/*      */     //   4040: wide istore #330
/*      */     //   4044: wide aload #329
/*      */     //   4048: wide iload #330
/*      */     //   4052: invokeinterface getInt : (I)I
/*      */     //   4057: bipush #8
/*      */     //   4059: imul
/*      */     //   4060: wide istore #326
/*      */     //   4064: aload #10
/*      */     //   4066: wide astore #324
/*      */     //   4070: iload #11
/*      */     //   4072: wide iload #326
/*      */     //   4076: iadd
/*      */     //   4077: wide istore #325
/*      */     //   4081: wide aload #324
/*      */     //   4085: wide iload #325
/*      */     //   4089: invokeinterface getDouble : (I)D
/*      */     //   4094: wide dstore #322
/*      */     //   4098: iload #17
/*      */     //   4100: bipush #8
/*      */     //   4102: imul
/*      */     //   4103: wide istore #320
/*      */     //   4107: aload #10
/*      */     //   4109: wide astore #318
/*      */     //   4113: iload #11
/*      */     //   4115: wide iload #320
/*      */     //   4119: iadd
/*      */     //   4120: wide istore #319
/*      */     //   4124: wide aload #318
/*      */     //   4128: wide iload #319
/*      */     //   4132: invokeinterface getDouble : (I)D
/*      */     //   4137: wide dstore #316
/*      */     //   4141: wide dload #322
/*      */     //   4145: wide dload #316
/*      */     //   4149: dcmpl
/*      */     //   4150: ifgt -> 3921
/*      */     //   4153: goto -> 4156
/*      */     //   4156: iload #22
/*      */     //   4158: iload #21
/*      */     //   4160: isub
/*      */     //   4161: iconst_4
/*      */     //   4162: imul
/*      */     //   4163: wide istore #313
/*      */     //   4167: aload_0
/*      */     //   4168: wide astore #311
/*      */     //   4172: wide iload #313
/*      */     //   4176: wide istore #312
/*      */     //   4180: wide aload #311
/*      */     //   4184: wide iload #312
/*      */     //   4188: invokeinterface getInt : (I)I
/*      */     //   4193: bipush #8
/*      */     //   4195: imul
/*      */     //   4196: wide istore #308
/*      */     //   4200: aload #10
/*      */     //   4202: wide astore #306
/*      */     //   4206: iload #11
/*      */     //   4208: wide iload #308
/*      */     //   4212: iadd
/*      */     //   4213: wide istore #307
/*      */     //   4217: wide aload #306
/*      */     //   4221: wide iload #307
/*      */     //   4225: invokeinterface getDouble : (I)D
/*      */     //   4230: wide dstore #304
/*      */     //   4234: iload #17
/*      */     //   4236: bipush #8
/*      */     //   4238: imul
/*      */     //   4239: wide istore #302
/*      */     //   4243: aload #10
/*      */     //   4245: wide astore #300
/*      */     //   4249: iload #11
/*      */     //   4251: wide iload #302
/*      */     //   4255: iadd
/*      */     //   4256: wide istore #301
/*      */     //   4260: wide aload #300
/*      */     //   4264: wide iload #301
/*      */     //   4268: invokeinterface getDouble : (I)D
/*      */     //   4273: wide dstore #298
/*      */     //   4277: wide dload #304
/*      */     //   4281: wide dload #298
/*      */     //   4285: dcmpl
/*      */     //   4286: ifeq -> 4292
/*      */     //   4289: goto -> 4337
/*      */     //   4292: iload #22
/*      */     //   4294: iload #21
/*      */     //   4296: isub
/*      */     //   4297: iconst_4
/*      */     //   4298: imul
/*      */     //   4299: wide istore #295
/*      */     //   4303: aload_0
/*      */     //   4304: wide astore #293
/*      */     //   4308: wide iload #295
/*      */     //   4312: wide istore #294
/*      */     //   4316: wide aload #293
/*      */     //   4320: wide iload #294
/*      */     //   4324: invokeinterface getInt : (I)I
/*      */     //   4329: iload #17
/*      */     //   4331: if_icmpgt -> 3921
/*      */     //   4334: goto -> 4337
/*      */     //   4337: iload #22
/*      */     //   4339: iconst_4
/*      */     //   4340: imul
/*      */     //   4341: wide istore #290
/*      */     //   4345: aload_0
/*      */     //   4346: wide astore #288
/*      */     //   4350: wide iload #290
/*      */     //   4354: wide istore #289
/*      */     //   4358: wide aload #288
/*      */     //   4362: wide iload #289
/*      */     //   4366: iload #17
/*      */     //   4368: invokeinterface setInt : (II)V
/*      */     //   4373: iinc #23, 1
/*      */     //   4376: iload #23
/*      */     //   4378: iload #18
/*      */     //   4380: if_icmple -> 3878
/*      */     //   4383: goto -> 4386
/*      */     //   4386: iinc #20, 1
/*      */     //   4389: invokestatic get__sort$sincs : ()[I
/*      */     //   4392: iload #20
/*      */     //   4394: iaload
/*      */     //   4395: istore #21
/*      */     //   4397: iload #20
/*      */     //   4399: bipush #15
/*      */     //   4401: if_icmple -> 3865
/*      */     //   4404: goto -> 4407
/*      */     //   4407: goto -> 6457
/*      */     //   4410: iload #4
/*      */     //   4412: ifne -> 4418
/*      */     //   4415: goto -> 5002
/*      */     //   4418: invokestatic get__sort$sincs : ()[I
/*      */     //   4421: iload #20
/*      */     //   4423: iaload
/*      */     //   4424: istore #21
/*      */     //   4426: goto -> 4992
/*      */     //   4429: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   4432: iload #19
/*      */     //   4434: iload #21
/*      */     //   4436: iadd
/*      */     //   4437: istore #23
/*      */     //   4439: goto -> 4971
/*      */     //   4442: iload #23
/*      */     //   4444: iconst_4
/*      */     //   4445: imul
/*      */     //   4446: wide istore #286
/*      */     //   4450: aload_0
/*      */     //   4451: wide astore #284
/*      */     //   4455: wide iload #286
/*      */     //   4459: wide istore #285
/*      */     //   4463: wide aload #284
/*      */     //   4467: wide iload #285
/*      */     //   4471: invokeinterface getInt : (I)I
/*      */     //   4476: istore #17
/*      */     //   4478: iload #23
/*      */     //   4480: istore #22
/*      */     //   4482: goto -> 4571
/*      */     //   4485: iload #22
/*      */     //   4487: iconst_4
/*      */     //   4488: imul
/*      */     //   4489: wide istore #282
/*      */     //   4493: aload_0
/*      */     //   4494: wide astore #280
/*      */     //   4498: wide iload #282
/*      */     //   4502: wide istore #281
/*      */     //   4506: iload #22
/*      */     //   4508: iload #21
/*      */     //   4510: isub
/*      */     //   4511: iconst_4
/*      */     //   4512: imul
/*      */     //   4513: wide istore #277
/*      */     //   4517: aload_0
/*      */     //   4518: wide astore #275
/*      */     //   4522: wide iload #277
/*      */     //   4526: wide istore #276
/*      */     //   4530: wide aload #275
/*      */     //   4534: wide iload #276
/*      */     //   4538: invokeinterface getInt : (I)I
/*      */     //   4543: wide istore #274
/*      */     //   4547: wide aload #280
/*      */     //   4551: wide iload #281
/*      */     //   4555: wide iload #274
/*      */     //   4559: invokeinterface setInt : (II)V
/*      */     //   4564: iload #22
/*      */     //   4566: iload #21
/*      */     //   4568: isub
/*      */     //   4569: istore #22
/*      */     //   4571: iload #19
/*      */     //   4573: iload #21
/*      */     //   4575: iadd
/*      */     //   4576: iload #22
/*      */     //   4578: if_icmple -> 4584
/*      */     //   4581: goto -> 4944
/*      */     //   4584: iload #17
/*      */     //   4586: bipush #16
/*      */     //   4588: imul
/*      */     //   4589: wide istore #271
/*      */     //   4593: aload #8
/*      */     //   4595: wide astore #269
/*      */     //   4599: iload #9
/*      */     //   4601: wide iload #271
/*      */     //   4605: iadd
/*      */     //   4606: wide istore #270
/*      */     //   4610: iload #22
/*      */     //   4612: iload #21
/*      */     //   4614: isub
/*      */     //   4615: iconst_4
/*      */     //   4616: imul
/*      */     //   4617: wide istore #266
/*      */     //   4621: aload_0
/*      */     //   4622: wide astore #264
/*      */     //   4626: wide iload #266
/*      */     //   4630: wide istore #265
/*      */     //   4634: wide aload #264
/*      */     //   4638: wide iload #265
/*      */     //   4642: invokeinterface getInt : (I)I
/*      */     //   4647: bipush #16
/*      */     //   4649: imul
/*      */     //   4650: wide istore #261
/*      */     //   4654: aload #8
/*      */     //   4656: wide astore #259
/*      */     //   4660: iload #9
/*      */     //   4662: wide iload #261
/*      */     //   4666: iadd
/*      */     //   4667: wide istore #260
/*      */     //   4671: wide aload #259
/*      */     //   4675: wide iload #260
/*      */     //   4679: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4684: bipush #16
/*      */     //   4686: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4691: wide aload #269
/*      */     //   4695: wide iload #270
/*      */     //   4699: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4704: bipush #16
/*      */     //   4706: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4711: iconst_0
/*      */     //   4712: invokestatic ccmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
/*      */     //   4715: iflt -> 4485
/*      */     //   4718: goto -> 4721
/*      */     //   4721: iload #22
/*      */     //   4723: iload #21
/*      */     //   4725: isub
/*      */     //   4726: iconst_4
/*      */     //   4727: imul
/*      */     //   4728: istore #255
/*      */     //   4730: aload_0
/*      */     //   4731: astore #253
/*      */     //   4733: iload #255
/*      */     //   4735: istore #254
/*      */     //   4737: aload #253
/*      */     //   4739: iload #254
/*      */     //   4741: invokeinterface getInt : (I)I
/*      */     //   4746: bipush #16
/*      */     //   4748: imul
/*      */     //   4749: istore #250
/*      */     //   4751: aload #8
/*      */     //   4753: astore #248
/*      */     //   4755: iload #9
/*      */     //   4757: iload #250
/*      */     //   4759: iadd
/*      */     //   4760: istore #249
/*      */     //   4762: aload #248
/*      */     //   4764: iload #249
/*      */     //   4766: invokeinterface getDouble : (I)D
/*      */     //   4771: dstore #246
/*      */     //   4773: iload #17
/*      */     //   4775: bipush #16
/*      */     //   4777: imul
/*      */     //   4778: istore #244
/*      */     //   4780: aload #8
/*      */     //   4782: astore #242
/*      */     //   4784: iload #9
/*      */     //   4786: iload #244
/*      */     //   4788: iadd
/*      */     //   4789: istore #243
/*      */     //   4791: aload #242
/*      */     //   4793: iload #243
/*      */     //   4795: invokeinterface getDouble : (I)D
/*      */     //   4800: dstore #240
/*      */     //   4802: dload #246
/*      */     //   4804: dload #240
/*      */     //   4806: dcmpl
/*      */     //   4807: ifeq -> 4813
/*      */     //   4810: goto -> 4944
/*      */     //   4813: iload #22
/*      */     //   4815: iload #21
/*      */     //   4817: isub
/*      */     //   4818: iconst_4
/*      */     //   4819: imul
/*      */     //   4820: istore #237
/*      */     //   4822: aload_0
/*      */     //   4823: astore #235
/*      */     //   4825: iload #237
/*      */     //   4827: istore #236
/*      */     //   4829: aload #235
/*      */     //   4831: iload #236
/*      */     //   4833: invokeinterface getInt : (I)I
/*      */     //   4838: bipush #16
/*      */     //   4840: imul
/*      */     //   4841: istore #232
/*      */     //   4843: aload #8
/*      */     //   4845: astore #230
/*      */     //   4847: iload #9
/*      */     //   4849: iload #232
/*      */     //   4851: iadd
/*      */     //   4852: istore #231
/*      */     //   4854: aload #230
/*      */     //   4856: iload #231
/*      */     //   4858: bipush #8
/*      */     //   4860: iadd
/*      */     //   4861: invokeinterface getDouble : (I)D
/*      */     //   4866: dstore #228
/*      */     //   4868: iload #17
/*      */     //   4870: bipush #16
/*      */     //   4872: imul
/*      */     //   4873: istore #226
/*      */     //   4875: aload #8
/*      */     //   4877: astore #224
/*      */     //   4879: iload #9
/*      */     //   4881: iload #226
/*      */     //   4883: iadd
/*      */     //   4884: istore #225
/*      */     //   4886: aload #224
/*      */     //   4888: iload #225
/*      */     //   4890: bipush #8
/*      */     //   4892: iadd
/*      */     //   4893: invokeinterface getDouble : (I)D
/*      */     //   4898: dstore #222
/*      */     //   4900: dload #228
/*      */     //   4902: dload #222
/*      */     //   4904: dcmpl
/*      */     //   4905: ifeq -> 4911
/*      */     //   4908: goto -> 4944
/*      */     //   4911: iload #22
/*      */     //   4913: iload #21
/*      */     //   4915: isub
/*      */     //   4916: iconst_4
/*      */     //   4917: imul
/*      */     //   4918: istore #219
/*      */     //   4920: aload_0
/*      */     //   4921: astore #217
/*      */     //   4923: iload #219
/*      */     //   4925: istore #218
/*      */     //   4927: aload #217
/*      */     //   4929: iload #218
/*      */     //   4931: invokeinterface getInt : (I)I
/*      */     //   4936: iload #17
/*      */     //   4938: if_icmpgt -> 4485
/*      */     //   4941: goto -> 4944
/*      */     //   4944: iload #22
/*      */     //   4946: iconst_4
/*      */     //   4947: imul
/*      */     //   4948: istore #214
/*      */     //   4950: aload_0
/*      */     //   4951: astore #212
/*      */     //   4953: iload #214
/*      */     //   4955: istore #213
/*      */     //   4957: aload #212
/*      */     //   4959: iload #213
/*      */     //   4961: iload #17
/*      */     //   4963: invokeinterface setInt : (II)V
/*      */     //   4968: iinc #23, 1
/*      */     //   4971: iload #23
/*      */     //   4973: iload #18
/*      */     //   4975: if_icmple -> 4442
/*      */     //   4978: goto -> 4981
/*      */     //   4981: iinc #20, 1
/*      */     //   4984: invokestatic get__sort$sincs : ()[I
/*      */     //   4987: iload #20
/*      */     //   4989: iaload
/*      */     //   4990: istore #21
/*      */     //   4992: iload #20
/*      */     //   4994: bipush #15
/*      */     //   4996: if_icmple -> 4429
/*      */     //   4999: goto -> 5510
/*      */     //   5002: invokestatic get__sort$sincs : ()[I
/*      */     //   5005: iload #20
/*      */     //   5007: iaload
/*      */     //   5008: istore #21
/*      */     //   5010: goto -> 5500
/*      */     //   5013: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5016: iload #19
/*      */     //   5018: iload #21
/*      */     //   5020: iadd
/*      */     //   5021: istore #23
/*      */     //   5023: goto -> 5479
/*      */     //   5026: iload #23
/*      */     //   5028: iconst_4
/*      */     //   5029: imul
/*      */     //   5030: istore #210
/*      */     //   5032: aload_0
/*      */     //   5033: astore #208
/*      */     //   5035: iload #210
/*      */     //   5037: istore #209
/*      */     //   5039: aload #208
/*      */     //   5041: iload #209
/*      */     //   5043: invokeinterface getInt : (I)I
/*      */     //   5048: istore #17
/*      */     //   5050: iload #23
/*      */     //   5052: istore #22
/*      */     //   5054: goto -> 5115
/*      */     //   5057: iload #22
/*      */     //   5059: iconst_4
/*      */     //   5060: imul
/*      */     //   5061: istore #206
/*      */     //   5063: aload_0
/*      */     //   5064: astore #204
/*      */     //   5066: iload #206
/*      */     //   5068: istore #205
/*      */     //   5070: iload #22
/*      */     //   5072: iload #21
/*      */     //   5074: isub
/*      */     //   5075: iconst_4
/*      */     //   5076: imul
/*      */     //   5077: istore #201
/*      */     //   5079: aload_0
/*      */     //   5080: astore #199
/*      */     //   5082: iload #201
/*      */     //   5084: istore #200
/*      */     //   5086: aload #199
/*      */     //   5088: iload #200
/*      */     //   5090: invokeinterface getInt : (I)I
/*      */     //   5095: istore #198
/*      */     //   5097: aload #204
/*      */     //   5099: iload #205
/*      */     //   5101: iload #198
/*      */     //   5103: invokeinterface setInt : (II)V
/*      */     //   5108: iload #22
/*      */     //   5110: iload #21
/*      */     //   5112: isub
/*      */     //   5113: istore #22
/*      */     //   5115: iload #19
/*      */     //   5117: iload #21
/*      */     //   5119: iadd
/*      */     //   5120: iload #22
/*      */     //   5122: if_icmple -> 5128
/*      */     //   5125: goto -> 5452
/*      */     //   5128: iload #17
/*      */     //   5130: bipush #16
/*      */     //   5132: imul
/*      */     //   5133: istore #195
/*      */     //   5135: aload #8
/*      */     //   5137: astore #193
/*      */     //   5139: iload #9
/*      */     //   5141: iload #195
/*      */     //   5143: iadd
/*      */     //   5144: istore #194
/*      */     //   5146: iload #22
/*      */     //   5148: iload #21
/*      */     //   5150: isub
/*      */     //   5151: iconst_4
/*      */     //   5152: imul
/*      */     //   5153: istore #190
/*      */     //   5155: aload_0
/*      */     //   5156: astore #188
/*      */     //   5158: iload #190
/*      */     //   5160: istore #189
/*      */     //   5162: aload #188
/*      */     //   5164: iload #189
/*      */     //   5166: invokeinterface getInt : (I)I
/*      */     //   5171: bipush #16
/*      */     //   5173: imul
/*      */     //   5174: istore #185
/*      */     //   5176: aload #8
/*      */     //   5178: astore #183
/*      */     //   5180: iload #9
/*      */     //   5182: iload #185
/*      */     //   5184: iadd
/*      */     //   5185: istore #184
/*      */     //   5187: aload #183
/*      */     //   5189: iload #184
/*      */     //   5191: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5196: bipush #16
/*      */     //   5198: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5203: aload #193
/*      */     //   5205: iload #194
/*      */     //   5207: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5212: bipush #16
/*      */     //   5214: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5219: iconst_0
/*      */     //   5220: invokestatic ccmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
/*      */     //   5223: ifgt -> 5057
/*      */     //   5226: goto -> 5229
/*      */     //   5229: iload #22
/*      */     //   5231: iload #21
/*      */     //   5233: isub
/*      */     //   5234: iconst_4
/*      */     //   5235: imul
/*      */     //   5236: istore #179
/*      */     //   5238: aload_0
/*      */     //   5239: astore #177
/*      */     //   5241: iload #179
/*      */     //   5243: istore #178
/*      */     //   5245: aload #177
/*      */     //   5247: iload #178
/*      */     //   5249: invokeinterface getInt : (I)I
/*      */     //   5254: bipush #16
/*      */     //   5256: imul
/*      */     //   5257: istore #174
/*      */     //   5259: aload #8
/*      */     //   5261: astore #172
/*      */     //   5263: iload #9
/*      */     //   5265: iload #174
/*      */     //   5267: iadd
/*      */     //   5268: istore #173
/*      */     //   5270: aload #172
/*      */     //   5272: iload #173
/*      */     //   5274: invokeinterface getDouble : (I)D
/*      */     //   5279: dstore #170
/*      */     //   5281: iload #17
/*      */     //   5283: bipush #16
/*      */     //   5285: imul
/*      */     //   5286: istore #168
/*      */     //   5288: aload #8
/*      */     //   5290: astore #166
/*      */     //   5292: iload #9
/*      */     //   5294: iload #168
/*      */     //   5296: iadd
/*      */     //   5297: istore #167
/*      */     //   5299: aload #166
/*      */     //   5301: iload #167
/*      */     //   5303: invokeinterface getDouble : (I)D
/*      */     //   5308: dstore #164
/*      */     //   5310: dload #170
/*      */     //   5312: dload #164
/*      */     //   5314: dcmpl
/*      */     //   5315: ifeq -> 5321
/*      */     //   5318: goto -> 5452
/*      */     //   5321: iload #22
/*      */     //   5323: iload #21
/*      */     //   5325: isub
/*      */     //   5326: iconst_4
/*      */     //   5327: imul
/*      */     //   5328: istore #161
/*      */     //   5330: aload_0
/*      */     //   5331: astore #159
/*      */     //   5333: iload #161
/*      */     //   5335: istore #160
/*      */     //   5337: aload #159
/*      */     //   5339: iload #160
/*      */     //   5341: invokeinterface getInt : (I)I
/*      */     //   5346: bipush #16
/*      */     //   5348: imul
/*      */     //   5349: istore #156
/*      */     //   5351: aload #8
/*      */     //   5353: astore #154
/*      */     //   5355: iload #9
/*      */     //   5357: iload #156
/*      */     //   5359: iadd
/*      */     //   5360: istore #155
/*      */     //   5362: aload #154
/*      */     //   5364: iload #155
/*      */     //   5366: bipush #8
/*      */     //   5368: iadd
/*      */     //   5369: invokeinterface getDouble : (I)D
/*      */     //   5374: dstore #152
/*      */     //   5376: iload #17
/*      */     //   5378: bipush #16
/*      */     //   5380: imul
/*      */     //   5381: istore #150
/*      */     //   5383: aload #8
/*      */     //   5385: astore #148
/*      */     //   5387: iload #9
/*      */     //   5389: iload #150
/*      */     //   5391: iadd
/*      */     //   5392: istore #149
/*      */     //   5394: aload #148
/*      */     //   5396: iload #149
/*      */     //   5398: bipush #8
/*      */     //   5400: iadd
/*      */     //   5401: invokeinterface getDouble : (I)D
/*      */     //   5406: dstore #146
/*      */     //   5408: dload #152
/*      */     //   5410: dload #146
/*      */     //   5412: dcmpl
/*      */     //   5413: ifeq -> 5419
/*      */     //   5416: goto -> 5452
/*      */     //   5419: iload #22
/*      */     //   5421: iload #21
/*      */     //   5423: isub
/*      */     //   5424: iconst_4
/*      */     //   5425: imul
/*      */     //   5426: istore #143
/*      */     //   5428: aload_0
/*      */     //   5429: astore #141
/*      */     //   5431: iload #143
/*      */     //   5433: istore #142
/*      */     //   5435: aload #141
/*      */     //   5437: iload #142
/*      */     //   5439: invokeinterface getInt : (I)I
/*      */     //   5444: iload #17
/*      */     //   5446: if_icmpgt -> 5057
/*      */     //   5449: goto -> 5452
/*      */     //   5452: iload #22
/*      */     //   5454: iconst_4
/*      */     //   5455: imul
/*      */     //   5456: istore #138
/*      */     //   5458: aload_0
/*      */     //   5459: astore #136
/*      */     //   5461: iload #138
/*      */     //   5463: istore #137
/*      */     //   5465: aload #136
/*      */     //   5467: iload #137
/*      */     //   5469: iload #17
/*      */     //   5471: invokeinterface setInt : (II)V
/*      */     //   5476: iinc #23, 1
/*      */     //   5479: iload #23
/*      */     //   5481: iload #18
/*      */     //   5483: if_icmple -> 5026
/*      */     //   5486: goto -> 5489
/*      */     //   5489: iinc #20, 1
/*      */     //   5492: invokestatic get__sort$sincs : ()[I
/*      */     //   5495: iload #20
/*      */     //   5497: iaload
/*      */     //   5498: istore #21
/*      */     //   5500: iload #20
/*      */     //   5502: bipush #15
/*      */     //   5504: if_icmple -> 5013
/*      */     //   5507: goto -> 5510
/*      */     //   5510: goto -> 6457
/*      */     //   5513: iload #4
/*      */     //   5515: ifne -> 5521
/*      */     //   5518: goto -> 5871
/*      */     //   5521: invokestatic get__sort$sincs : ()[I
/*      */     //   5524: iload #20
/*      */     //   5526: iaload
/*      */     //   5527: istore #21
/*      */     //   5529: goto -> 5861
/*      */     //   5532: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5535: iload #19
/*      */     //   5537: iload #21
/*      */     //   5539: iadd
/*      */     //   5540: istore #23
/*      */     //   5542: goto -> 5840
/*      */     //   5545: iload #23
/*      */     //   5547: iconst_4
/*      */     //   5548: imul
/*      */     //   5549: istore #134
/*      */     //   5551: aload_0
/*      */     //   5552: astore #132
/*      */     //   5554: iload #134
/*      */     //   5556: istore #133
/*      */     //   5558: aload #132
/*      */     //   5560: iload #133
/*      */     //   5562: invokeinterface getInt : (I)I
/*      */     //   5567: istore #17
/*      */     //   5569: iload #23
/*      */     //   5571: istore #22
/*      */     //   5573: goto -> 5634
/*      */     //   5576: iload #22
/*      */     //   5578: iconst_4
/*      */     //   5579: imul
/*      */     //   5580: istore #130
/*      */     //   5582: aload_0
/*      */     //   5583: astore #128
/*      */     //   5585: iload #130
/*      */     //   5587: istore #129
/*      */     //   5589: iload #22
/*      */     //   5591: iload #21
/*      */     //   5593: isub
/*      */     //   5594: iconst_4
/*      */     //   5595: imul
/*      */     //   5596: istore #125
/*      */     //   5598: aload_0
/*      */     //   5599: astore #123
/*      */     //   5601: iload #125
/*      */     //   5603: istore #124
/*      */     //   5605: aload #123
/*      */     //   5607: iload #124
/*      */     //   5609: invokeinterface getInt : (I)I
/*      */     //   5614: istore #122
/*      */     //   5616: aload #128
/*      */     //   5618: iload #129
/*      */     //   5620: iload #122
/*      */     //   5622: invokeinterface setInt : (II)V
/*      */     //   5627: iload #22
/*      */     //   5629: iload #21
/*      */     //   5631: isub
/*      */     //   5632: istore #22
/*      */     //   5634: iload #19
/*      */     //   5636: iload #21
/*      */     //   5638: iadd
/*      */     //   5639: iload #22
/*      */     //   5641: if_icmple -> 5647
/*      */     //   5644: goto -> 5813
/*      */     //   5647: iload #17
/*      */     //   5649: iconst_4
/*      */     //   5650: imul
/*      */     //   5651: istore #119
/*      */     //   5653: aload #6
/*      */     //   5655: astore #117
/*      */     //   5657: iload #7
/*      */     //   5659: iload #119
/*      */     //   5661: iadd
/*      */     //   5662: istore #118
/*      */     //   5664: aload #117
/*      */     //   5666: iload #118
/*      */     //   5668: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5673: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   5678: checkcast org/renjin/sexp/SEXP
/*      */     //   5681: astore #116
/*      */     //   5683: iload #22
/*      */     //   5685: iload #21
/*      */     //   5687: isub
/*      */     //   5688: iconst_4
/*      */     //   5689: imul
/*      */     //   5690: istore #113
/*      */     //   5692: aload_0
/*      */     //   5693: astore #111
/*      */     //   5695: iload #113
/*      */     //   5697: istore #112
/*      */     //   5699: aload #111
/*      */     //   5701: iload #112
/*      */     //   5703: invokeinterface getInt : (I)I
/*      */     //   5708: iconst_4
/*      */     //   5709: imul
/*      */     //   5710: istore #108
/*      */     //   5712: aload #6
/*      */     //   5714: astore #106
/*      */     //   5716: iload #7
/*      */     //   5718: iload #108
/*      */     //   5720: iadd
/*      */     //   5721: istore #107
/*      */     //   5723: aload #106
/*      */     //   5725: iload #107
/*      */     //   5727: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5732: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   5737: checkcast org/renjin/sexp/SEXP
/*      */     //   5740: aload #116
/*      */     //   5742: invokestatic Rf_Scollate : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
/*      */     //   5745: istore #24
/*      */     //   5747: iload #24
/*      */     //   5749: iflt -> 5796
/*      */     //   5752: goto -> 5755
/*      */     //   5755: iload #24
/*      */     //   5757: ifeq -> 5763
/*      */     //   5760: goto -> 5802
/*      */     //   5763: iload #22
/*      */     //   5765: iload #21
/*      */     //   5767: isub
/*      */     //   5768: iconst_4
/*      */     //   5769: imul
/*      */     //   5770: istore #101
/*      */     //   5772: aload_0
/*      */     //   5773: astore #99
/*      */     //   5775: iload #101
/*      */     //   5777: istore #100
/*      */     //   5779: aload #99
/*      */     //   5781: iload #100
/*      */     //   5783: invokeinterface getInt : (I)I
/*      */     //   5788: iload #17
/*      */     //   5790: if_icmpgt -> 5796
/*      */     //   5793: goto -> 5802
/*      */     //   5796: iconst_1
/*      */     //   5797: istore #104
/*      */     //   5799: goto -> 5805
/*      */     //   5802: iconst_0
/*      */     //   5803: istore #104
/*      */     //   5805: iload #104
/*      */     //   5807: ifne -> 5576
/*      */     //   5810: goto -> 5813
/*      */     //   5813: iload #22
/*      */     //   5815: iconst_4
/*      */     //   5816: imul
/*      */     //   5817: istore #96
/*      */     //   5819: aload_0
/*      */     //   5820: astore #94
/*      */     //   5822: iload #96
/*      */     //   5824: istore #95
/*      */     //   5826: aload #94
/*      */     //   5828: iload #95
/*      */     //   5830: iload #17
/*      */     //   5832: invokeinterface setInt : (II)V
/*      */     //   5837: iinc #23, 1
/*      */     //   5840: iload #23
/*      */     //   5842: iload #18
/*      */     //   5844: if_icmple -> 5545
/*      */     //   5847: goto -> 5850
/*      */     //   5850: iinc #20, 1
/*      */     //   5853: invokestatic get__sort$sincs : ()[I
/*      */     //   5856: iload #20
/*      */     //   5858: iaload
/*      */     //   5859: istore #21
/*      */     //   5861: iload #20
/*      */     //   5863: bipush #15
/*      */     //   5865: if_icmple -> 5532
/*      */     //   5868: goto -> 6221
/*      */     //   5871: invokestatic get__sort$sincs : ()[I
/*      */     //   5874: iload #20
/*      */     //   5876: iaload
/*      */     //   5877: istore #21
/*      */     //   5879: goto -> 6211
/*      */     //   5882: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5885: iload #19
/*      */     //   5887: iload #21
/*      */     //   5889: iadd
/*      */     //   5890: istore #23
/*      */     //   5892: goto -> 6190
/*      */     //   5895: iload #23
/*      */     //   5897: iconst_4
/*      */     //   5898: imul
/*      */     //   5899: istore #92
/*      */     //   5901: aload_0
/*      */     //   5902: astore #90
/*      */     //   5904: iload #92
/*      */     //   5906: istore #91
/*      */     //   5908: aload #90
/*      */     //   5910: iload #91
/*      */     //   5912: invokeinterface getInt : (I)I
/*      */     //   5917: istore #17
/*      */     //   5919: iload #23
/*      */     //   5921: istore #22
/*      */     //   5923: goto -> 5984
/*      */     //   5926: iload #22
/*      */     //   5928: iconst_4
/*      */     //   5929: imul
/*      */     //   5930: istore #88
/*      */     //   5932: aload_0
/*      */     //   5933: astore #86
/*      */     //   5935: iload #88
/*      */     //   5937: istore #87
/*      */     //   5939: iload #22
/*      */     //   5941: iload #21
/*      */     //   5943: isub
/*      */     //   5944: iconst_4
/*      */     //   5945: imul
/*      */     //   5946: istore #83
/*      */     //   5948: aload_0
/*      */     //   5949: astore #81
/*      */     //   5951: iload #83
/*      */     //   5953: istore #82
/*      */     //   5955: aload #81
/*      */     //   5957: iload #82
/*      */     //   5959: invokeinterface getInt : (I)I
/*      */     //   5964: istore #80
/*      */     //   5966: aload #86
/*      */     //   5968: iload #87
/*      */     //   5970: iload #80
/*      */     //   5972: invokeinterface setInt : (II)V
/*      */     //   5977: iload #22
/*      */     //   5979: iload #21
/*      */     //   5981: isub
/*      */     //   5982: istore #22
/*      */     //   5984: iload #19
/*      */     //   5986: iload #21
/*      */     //   5988: iadd
/*      */     //   5989: iload #22
/*      */     //   5991: if_icmple -> 5997
/*      */     //   5994: goto -> 6163
/*      */     //   5997: iload #17
/*      */     //   5999: iconst_4
/*      */     //   6000: imul
/*      */     //   6001: istore #77
/*      */     //   6003: aload #6
/*      */     //   6005: astore #75
/*      */     //   6007: iload #7
/*      */     //   6009: iload #77
/*      */     //   6011: iadd
/*      */     //   6012: istore #76
/*      */     //   6014: aload #75
/*      */     //   6016: iload #76
/*      */     //   6018: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6023: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   6028: checkcast org/renjin/sexp/SEXP
/*      */     //   6031: astore #74
/*      */     //   6033: iload #22
/*      */     //   6035: iload #21
/*      */     //   6037: isub
/*      */     //   6038: iconst_4
/*      */     //   6039: imul
/*      */     //   6040: istore #71
/*      */     //   6042: aload_0
/*      */     //   6043: astore #69
/*      */     //   6045: iload #71
/*      */     //   6047: istore #70
/*      */     //   6049: aload #69
/*      */     //   6051: iload #70
/*      */     //   6053: invokeinterface getInt : (I)I
/*      */     //   6058: iconst_4
/*      */     //   6059: imul
/*      */     //   6060: istore #66
/*      */     //   6062: aload #6
/*      */     //   6064: astore #64
/*      */     //   6066: iload #7
/*      */     //   6068: iload #66
/*      */     //   6070: iadd
/*      */     //   6071: istore #65
/*      */     //   6073: aload #64
/*      */     //   6075: iload #65
/*      */     //   6077: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6082: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   6087: checkcast org/renjin/sexp/SEXP
/*      */     //   6090: aload #74
/*      */     //   6092: invokestatic Rf_Scollate : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
/*      */     //   6095: istore #24
/*      */     //   6097: iload #24
/*      */     //   6099: ifgt -> 6146
/*      */     //   6102: goto -> 6105
/*      */     //   6105: iload #24
/*      */     //   6107: ifeq -> 6113
/*      */     //   6110: goto -> 6152
/*      */     //   6113: iload #22
/*      */     //   6115: iload #21
/*      */     //   6117: isub
/*      */     //   6118: iconst_4
/*      */     //   6119: imul
/*      */     //   6120: istore #59
/*      */     //   6122: aload_0
/*      */     //   6123: astore #57
/*      */     //   6125: iload #59
/*      */     //   6127: istore #58
/*      */     //   6129: aload #57
/*      */     //   6131: iload #58
/*      */     //   6133: invokeinterface getInt : (I)I
/*      */     //   6138: iload #17
/*      */     //   6140: if_icmpgt -> 6146
/*      */     //   6143: goto -> 6152
/*      */     //   6146: iconst_1
/*      */     //   6147: istore #62
/*      */     //   6149: goto -> 6155
/*      */     //   6152: iconst_0
/*      */     //   6153: istore #62
/*      */     //   6155: iload #62
/*      */     //   6157: ifne -> 5926
/*      */     //   6160: goto -> 6163
/*      */     //   6163: iload #22
/*      */     //   6165: iconst_4
/*      */     //   6166: imul
/*      */     //   6167: istore #54
/*      */     //   6169: aload_0
/*      */     //   6170: astore #52
/*      */     //   6172: iload #54
/*      */     //   6174: istore #53
/*      */     //   6176: aload #52
/*      */     //   6178: iload #53
/*      */     //   6180: iload #17
/*      */     //   6182: invokeinterface setInt : (II)V
/*      */     //   6187: iinc #23, 1
/*      */     //   6190: iload #23
/*      */     //   6192: iload #18
/*      */     //   6194: if_icmple -> 5895
/*      */     //   6197: goto -> 6200
/*      */     //   6200: iinc #20, 1
/*      */     //   6203: invokestatic get__sort$sincs : ()[I
/*      */     //   6206: iload #20
/*      */     //   6208: iaload
/*      */     //   6209: istore #21
/*      */     //   6211: iload #20
/*      */     //   6213: bipush #15
/*      */     //   6215: if_icmple -> 5882
/*      */     //   6218: goto -> 6221
/*      */     //   6221: goto -> 6457
/*      */     //   6224: invokestatic get__sort$sincs : ()[I
/*      */     //   6227: iload #20
/*      */     //   6229: iaload
/*      */     //   6230: istore #21
/*      */     //   6232: goto -> 6447
/*      */     //   6235: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   6238: iload #19
/*      */     //   6240: iload #21
/*      */     //   6242: iadd
/*      */     //   6243: istore #23
/*      */     //   6245: goto -> 6426
/*      */     //   6248: iload #23
/*      */     //   6250: iconst_4
/*      */     //   6251: imul
/*      */     //   6252: istore #50
/*      */     //   6254: aload_0
/*      */     //   6255: astore #48
/*      */     //   6257: iload #50
/*      */     //   6259: istore #49
/*      */     //   6261: aload #48
/*      */     //   6263: iload #49
/*      */     //   6265: invokeinterface getInt : (I)I
/*      */     //   6270: istore #17
/*      */     //   6272: iload #23
/*      */     //   6274: istore #22
/*      */     //   6276: goto -> 6337
/*      */     //   6279: iload #22
/*      */     //   6281: iconst_4
/*      */     //   6282: imul
/*      */     //   6283: istore #46
/*      */     //   6285: aload_0
/*      */     //   6286: astore #44
/*      */     //   6288: iload #46
/*      */     //   6290: istore #45
/*      */     //   6292: iload #22
/*      */     //   6294: iload #21
/*      */     //   6296: isub
/*      */     //   6297: iconst_4
/*      */     //   6298: imul
/*      */     //   6299: istore #41
/*      */     //   6301: aload_0
/*      */     //   6302: astore #39
/*      */     //   6304: iload #41
/*      */     //   6306: istore #40
/*      */     //   6308: aload #39
/*      */     //   6310: iload #40
/*      */     //   6312: invokeinterface getInt : (I)I
/*      */     //   6317: istore #38
/*      */     //   6319: aload #44
/*      */     //   6321: iload #45
/*      */     //   6323: iload #38
/*      */     //   6325: invokeinterface setInt : (II)V
/*      */     //   6330: iload #22
/*      */     //   6332: iload #21
/*      */     //   6334: isub
/*      */     //   6335: istore #22
/*      */     //   6337: iload #19
/*      */     //   6339: iload #21
/*      */     //   6341: iadd
/*      */     //   6342: iload #22
/*      */     //   6344: if_icmple -> 6350
/*      */     //   6347: goto -> 6399
/*      */     //   6350: iload_3
/*      */     //   6351: iload #4
/*      */     //   6353: ixor
/*      */     //   6354: istore #36
/*      */     //   6356: iload #22
/*      */     //   6358: iload #21
/*      */     //   6360: isub
/*      */     //   6361: iconst_4
/*      */     //   6362: imul
/*      */     //   6363: istore #33
/*      */     //   6365: aload_0
/*      */     //   6366: astore #31
/*      */     //   6368: iload #33
/*      */     //   6370: istore #32
/*      */     //   6372: aload #31
/*      */     //   6374: iload #32
/*      */     //   6376: invokeinterface getInt : (I)I
/*      */     //   6381: iload #17
/*      */     //   6383: aload_2
/*      */     //   6384: iload #36
/*      */     //   6386: iload #4
/*      */     //   6388: aload #5
/*      */     //   6390: invokestatic greater : (IILorg/renjin/sexp/SEXP;IILorg/renjin/sexp/SEXP;)I
/*      */     //   6393: ifne -> 6279
/*      */     //   6396: goto -> 6399
/*      */     //   6399: iload #22
/*      */     //   6401: iconst_4
/*      */     //   6402: imul
/*      */     //   6403: istore #27
/*      */     //   6405: aload_0
/*      */     //   6406: astore #25
/*      */     //   6408: iload #27
/*      */     //   6410: istore #26
/*      */     //   6412: aload #25
/*      */     //   6414: iload #26
/*      */     //   6416: iload #17
/*      */     //   6418: invokeinterface setInt : (II)V
/*      */     //   6423: iinc #23, 1
/*      */     //   6426: iload #23
/*      */     //   6428: iload #18
/*      */     //   6430: if_icmple -> 6248
/*      */     //   6433: goto -> 6436
/*      */     //   6436: iinc #20, 1
/*      */     //   6439: invokestatic get__sort$sincs : ()[I
/*      */     //   6442: iload #20
/*      */     //   6444: iaload
/*      */     //   6445: istore #21
/*      */     //   6447: iload #20
/*      */     //   6449: bipush #15
/*      */     //   6451: if_icmple -> 6235
/*      */     //   6454: goto -> 6457
/*      */     //   6457: aload #15
/*      */     //   6459: iload #16
/*      */     //   6461: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6466: invokeinterface isNull : ()Z
/*      */     //   6471: ifne -> 6486
/*      */     //   6474: goto -> 6477
/*      */     //   6477: iconst_0
/*      */     //   6478: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6481: astore #15
/*      */     //   6483: iconst_0
/*      */     //   6484: istore #16
/*      */     //   6486: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #966	-> 66
/*      */     //   #967	-> 74
/*      */     //   #968	-> 86
/*      */     //   #969	-> 95
/*      */     //   #970	-> 104
/*      */     //   #971	-> 113
/*      */     //   #973	-> 122
/*      */     //   #974	-> 133
/*      */     //   #977	-> 188
/*      */     //   #980	-> 200
/*      */     //   #983	-> 212
/*      */     //   #986	-> 226
/*      */     //   #990	-> 235
/*      */     //   #992	-> 246
/*      */     //   #993	-> 257
/*      */     //   #996	-> 312
/*      */     //   #996	-> 318
/*      */     //   #996	-> 435
/*      */     //   #999	-> 447
/*      */     //   #999	-> 453
/*      */     //   #999	-> 555
/*      */     //   #1002	-> 567
/*      */     //   #1002	-> 573
/*      */     //   #1002	-> 698
/*      */     //   #1005	-> 710
/*      */     //   #1005	-> 716
/*      */     //   #1005	-> 789
/*      */     //   #1005	-> 840
/*      */     //   #1005	-> 848
/*      */     //   #1005	-> 853
/*      */     //   #1005	-> 873
/*      */     //   #1008	-> 885
/*      */     //   #1010	-> 903
/*      */     //   #1010	-> 909
/*      */     //   #1010	-> 955
/*      */     //   #1012	-> 964
/*      */     //   #1013	-> 972
/*      */     //   #1019	-> 1028
/*      */     //   #1019	-> 1035
/*      */     //   #1019	-> 1041
/*      */     //   #1019	-> 1139
/*      */     //   #1020	-> 1148
/*      */     //   #1020	-> 1154
/*      */     //   #1020	-> 1157
/*      */     //   #1022	-> 1170
/*      */     //   #1022	-> 1181
/*      */     //   #1022	-> 1194
/*      */     //   #1022	-> 1237
/*      */     //   #1022	-> 1323
/*      */     //   #1022	-> 1336
/*      */     //   #1022	-> 1469
/*      */     //   #1022	-> 1602
/*      */     //   #1022	-> 1647
/*      */     //   #1022	-> 1686
/*      */     //   #1022	-> 1696
/*      */     //   #1022	-> 1707
/*      */     //   #1024	-> 1717
/*      */     //   #1025	-> 1728
/*      */     //   #1028	-> 1740
/*      */     //   #1028	-> 1747
/*      */     //   #1028	-> 1757
/*      */     //   #1034	-> 1764
/*      */     //   #1034	-> 1770
/*      */     //   #1034	-> 1773
/*      */     //   #1036	-> 1808
/*      */     //   #1036	-> 1818
/*      */     //   #1039	-> 1829
/*      */     //   #1039	-> 1840
/*      */     //   #1039	-> 1853
/*      */     //   #1039	-> 1896
/*      */     //   #1039	-> 1982
/*      */     //   #1039	-> 1995
/*      */     //   #1039	-> 2060
/*      */     //   #1039	-> 2099
/*      */     //   #1039	-> 2109
/*      */     //   #1039	-> 2120
/*      */     //   #1042	-> 2133
/*      */     //   #1045	-> 2188
/*      */     //   #1047	-> 2196
/*      */     //   #1047	-> 2207
/*      */     //   #1047	-> 2220
/*      */     //   #1047	-> 2263
/*      */     //   #1047	-> 2349
/*      */     //   #1047	-> 2362
/*      */     //   #1047	-> 2495
/*      */     //   #1047	-> 2628
/*      */     //   #1047	-> 2673
/*      */     //   #1047	-> 2712
/*      */     //   #1047	-> 2722
/*      */     //   #1047	-> 2733
/*      */     //   #1051	-> 2743
/*      */     //   #1051	-> 2754
/*      */     //   #1051	-> 2767
/*      */     //   #1051	-> 2810
/*      */     //   #1051	-> 2896
/*      */     //   #1051	-> 2909
/*      */     //   #1051	-> 3042
/*      */     //   #1051	-> 3175
/*      */     //   #1051	-> 3220
/*      */     //   #1051	-> 3259
/*      */     //   #1051	-> 3269
/*      */     //   #1051	-> 3280
/*      */     //   #1056	-> 3293
/*      */     //   #1058	-> 3301
/*      */     //   #1058	-> 3312
/*      */     //   #1058	-> 3325
/*      */     //   #1058	-> 3368
/*      */     //   #1058	-> 3454
/*      */     //   #1058	-> 3467
/*      */     //   #1058	-> 3603
/*      */     //   #1058	-> 3739
/*      */     //   #1058	-> 3784
/*      */     //   #1058	-> 3823
/*      */     //   #1058	-> 3833
/*      */     //   #1058	-> 3844
/*      */     //   #1062	-> 3854
/*      */     //   #1062	-> 3865
/*      */     //   #1062	-> 3878
/*      */     //   #1062	-> 3921
/*      */     //   #1062	-> 4007
/*      */     //   #1062	-> 4020
/*      */     //   #1062	-> 4156
/*      */     //   #1062	-> 4292
/*      */     //   #1062	-> 4337
/*      */     //   #1062	-> 4376
/*      */     //   #1062	-> 4386
/*      */     //   #1062	-> 4397
/*      */     //   #1067	-> 4410
/*      */     //   #1069	-> 4418
/*      */     //   #1069	-> 4429
/*      */     //   #1069	-> 4442
/*      */     //   #1069	-> 4485
/*      */     //   #1069	-> 4571
/*      */     //   #1069	-> 4584
/*      */     //   #1069	-> 4721
/*      */     //   #1069	-> 4813
/*      */     //   #1069	-> 4911
/*      */     //   #1069	-> 4944
/*      */     //   #1069	-> 4971
/*      */     //   #1069	-> 4981
/*      */     //   #1069	-> 4992
/*      */     //   #1073	-> 5002
/*      */     //   #1073	-> 5013
/*      */     //   #1073	-> 5026
/*      */     //   #1073	-> 5057
/*      */     //   #1073	-> 5115
/*      */     //   #1073	-> 5128
/*      */     //   #1073	-> 5229
/*      */     //   #1073	-> 5321
/*      */     //   #1073	-> 5419
/*      */     //   #1073	-> 5452
/*      */     //   #1073	-> 5479
/*      */     //   #1073	-> 5489
/*      */     //   #1073	-> 5500
/*      */     //   #1078	-> 5513
/*      */     //   #1080	-> 5521
/*      */     //   #1080	-> 5532
/*      */     //   #1080	-> 5545
/*      */     //   #1080	-> 5576
/*      */     //   #1080	-> 5634
/*      */     //   #1080	-> 5647
/*      */     //   #1080	-> 5755
/*      */     //   #1080	-> 5763
/*      */     //   #1080	-> 5796
/*      */     //   #1080	-> 5802
/*      */     //   #1080	-> 5805
/*      */     //   #1080	-> 5813
/*      */     //   #1080	-> 5840
/*      */     //   #1080	-> 5850
/*      */     //   #1080	-> 5861
/*      */     //   #1084	-> 5871
/*      */     //   #1084	-> 5882
/*      */     //   #1084	-> 5895
/*      */     //   #1084	-> 5926
/*      */     //   #1084	-> 5984
/*      */     //   #1084	-> 5997
/*      */     //   #1084	-> 6105
/*      */     //   #1084	-> 6113
/*      */     //   #1084	-> 6146
/*      */     //   #1084	-> 6152
/*      */     //   #1084	-> 6155
/*      */     //   #1084	-> 6163
/*      */     //   #1084	-> 6190
/*      */     //   #1084	-> 6200
/*      */     //   #1084	-> 6211
/*      */     //   #1089	-> 6224
/*      */     //   #1089	-> 6235
/*      */     //   #1089	-> 6248
/*      */     //   #1089	-> 6279
/*      */     //   #1089	-> 6337
/*      */     //   #1089	-> 6350
/*      */     //   #1089	-> 6399
/*      */     //   #1089	-> 6426
/*      */     //   #1089	-> 6436
/*      */     //   #1089	-> 6447
/*      */     //   #1093	-> 6457
/*      */     //   #1093	-> 6477
/*      */     //   #0	-> 6486
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	6487	0	indx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	1	n	I
/*      */     //   0	6487	2	key	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	3	nalast	I
/*      */     //   0	6487	4	decreasing	I
/*      */     //   0	6487	5	rho	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	6	sx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	7	sx$offset	I
/*      */     //   0	6487	8	cx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	9	cx$offset	I
/*      */     //   0	6487	10	x	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	11	x$offset	I
/*      */     //   0	6487	12	ix	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	13	ix$offset	I
/*      */     //   0	6487	14	numna	I
/*      */     //   0	6487	15	isna	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	16	isna$offset	I
/*      */     //   0	6487	17	itmp	I
/*      */     //   0	6487	18	hi	I
/*      */     //   0	6487	19	lo	I
/*      */     //   0	6487	20	t	I
/*      */     //   0	6487	21	h	I
/*      */     //   0	6487	22	j	I
/*      */     //   0	6487	23	i	I
/*      */     //   0	6487	24	c	I
/*      */     //   0	6487	28	j$175	I
/*      */     //   0	6487	47	j$174	I
/*      */     //   0	6487	51	i$173	I
/*      */     //   0	6487	55	j$172	I
/*      */     //   0	6487	62	iftmp$171	I
/*      */     //   0	6487	78	itmp$170	I
/*      */     //   0	6487	89	j$169	I
/*      */     //   0	6487	93	i$168	I
/*      */     //   0	6487	97	j$167	I
/*      */     //   0	6487	104	iftmp$166	I
/*      */     //   0	6487	120	itmp$165	I
/*      */     //   0	6487	131	j$164	I
/*      */     //   0	6487	135	i$163	I
/*      */     //   0	6487	139	j$162	I
/*      */     //   0	6487	151	itmp$161	I
/*      */     //   0	6487	169	itmp$160	I
/*      */     //   0	6487	196	itmp$159	I
/*      */     //   0	6487	207	j$158	I
/*      */     //   0	6487	211	i$157	I
/*      */     //   0	6487	215	j$156	I
/*      */     //   0	6487	227	itmp$155	I
/*      */     //   0	6487	245	itmp$154	I
/*      */     //   0	6487	272	itmp$153	I
/*      */     //   0	6487	283	j$152	I
/*      */     //   0	6487	287	i$151	I
/*      */     //   0	6487	291	j$150	I
/*      */     //   0	6487	303	itmp$149	I
/*      */     //   0	6487	321	itmp$148	I
/*      */     //   0	6487	344	j$147	I
/*      */     //   0	6487	348	i$146	I
/*      */     //   0	6487	352	j$145	I
/*      */     //   0	6487	364	itmp$144	I
/*      */     //   0	6487	382	itmp$143	I
/*      */     //   0	6487	405	j$142	I
/*      */     //   0	6487	409	i$141	I
/*      */     //   0	6487	413	j$140	I
/*      */     //   0	6487	424	itmp$139	I
/*      */     //   0	6487	440	itmp$138	I
/*      */     //   0	6487	462	j$137	I
/*      */     //   0	6487	466	i$136	I
/*      */     //   0	6487	470	j$135	I
/*      */     //   0	6487	481	itmp$134	I
/*      */     //   0	6487	497	itmp$133	I
/*      */     //   0	6487	519	j$132	I
/*      */     //   0	6487	523	i$131	I
/*      */     //   0	6487	528	j$130	I
/*      */     //   0	6487	547	j$129	I
/*      */     //   0	6487	551	i$128	I
/*      */     //   0	6487	561	j$127	I
/*      */     //   0	6487	572	itmp$126	I
/*      */     //   0	6487	588	itmp$125	I
/*      */     //   0	6487	610	j$124	I
/*      */     //   0	6487	614	i$123	I
/*      */     //   0	6487	622	i$122	I
/*      */     //   0	6487	626	i$121	I
/*      */     //   0	6487	632	i$120	I
/*      */     //   0	6487	639	i$119	I
/*      */     //   0	6487	646	i$118	I
/*      */     //   0	6487	647	iftmp$117	I
/*      */     //   0	6487	651	i$116	I
/*      */     //   0	6487	654	R_NaString$115	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	659	i$114	I
/*      */     //   0	6487	663	i$113	I
/*      */     //   0	6487	672	i$112	I
/*      */     //   0	6487	676	i$111	I
/*      */     //   0	6487	679	R_NaInt$110	I
/*      */     //   0	6487	684	i$109	I
/*      */     //   0	6487	688	i$108	I
/*      */     //   0	6487	690	n$107	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void orderVector1l(Ptr indx, int n, SEXP key, int nalast, int decreasing, SEXP rho) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #6
/*      */     //   3: iconst_0
/*      */     //   4: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7: astore #7
/*      */     //   9: iconst_0
/*      */     //   10: istore #8
/*      */     //   12: iconst_0
/*      */     //   13: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16: astore #9
/*      */     //   18: iconst_0
/*      */     //   19: istore #10
/*      */     //   21: iconst_0
/*      */     //   22: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   25: astore #11
/*      */     //   27: iconst_0
/*      */     //   28: istore #12
/*      */     //   30: iconst_0
/*      */     //   31: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   34: astore #13
/*      */     //   36: iconst_0
/*      */     //   37: istore #14
/*      */     //   39: iconst_0
/*      */     //   40: istore #15
/*      */     //   42: iconst_0
/*      */     //   43: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   46: astore #16
/*      */     //   48: iconst_0
/*      */     //   49: istore #17
/*      */     //   51: iconst_0
/*      */     //   52: istore #18
/*      */     //   54: iconst_0
/*      */     //   55: istore #19
/*      */     //   57: iconst_0
/*      */     //   58: istore #20
/*      */     //   60: iconst_0
/*      */     //   61: istore #21
/*      */     //   63: iconst_0
/*      */     //   64: istore #23
/*      */     //   66: iconst_0
/*      */     //   67: istore #19
/*      */     //   69: iload_1
/*      */     //   70: iconst_m1
/*      */     //   71: iadd
/*      */     //   72: istore #18
/*      */     //   74: iconst_0
/*      */     //   75: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   78: astore #16
/*      */     //   80: iconst_0
/*      */     //   81: istore #17
/*      */     //   83: iconst_0
/*      */     //   84: istore #15
/*      */     //   86: iconst_0
/*      */     //   87: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   90: astore #13
/*      */     //   92: iconst_0
/*      */     //   93: istore #14
/*      */     //   95: iconst_0
/*      */     //   96: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   99: astore #11
/*      */     //   101: iconst_0
/*      */     //   102: istore #12
/*      */     //   104: iconst_0
/*      */     //   105: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   108: astore #9
/*      */     //   110: iconst_0
/*      */     //   111: istore #10
/*      */     //   113: iconst_0
/*      */     //   114: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   117: astore #7
/*      */     //   119: iconst_0
/*      */     //   120: istore #8
/*      */     //   122: iload_1
/*      */     //   123: iconst_1
/*      */     //   124: if_icmple -> 130
/*      */     //   127: goto -> 133
/*      */     //   130: goto -> 6486
/*      */     //   133: aload_2
/*      */     //   134: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   137: lookupswitch default -> 235, 10 -> 188, 13 -> 188, 14 -> 200, 15 -> 226, 16 -> 212
/*      */     //   188: aload_2
/*      */     //   189: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   192: astore #13
/*      */     //   194: iconst_0
/*      */     //   195: istore #14
/*      */     //   197: goto -> 235
/*      */     //   200: aload_2
/*      */     //   201: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   204: astore #11
/*      */     //   206: iconst_0
/*      */     //   207: istore #12
/*      */     //   209: goto -> 235
/*      */     //   212: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   215: dup
/*      */     //   216: ldc_w 'STRING_PTR'
/*      */     //   219: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   222: athrow
/*      */     //   223: nop
/*      */     //   224: nop
/*      */     //   225: athrow
/*      */     //   226: aload_2
/*      */     //   227: invokestatic COMPLEX : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   230: astore #9
/*      */     //   232: iconst_0
/*      */     //   233: istore #10
/*      */     //   235: aload #5
/*      */     //   237: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   240: ifeq -> 246
/*      */     //   243: goto -> 1764
/*      */     //   246: iload_1
/*      */     //   247: iconst_4
/*      */     //   248: imul
/*      */     //   249: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   252: astore #16
/*      */     //   254: iconst_0
/*      */     //   255: istore #17
/*      */     //   257: aload_2
/*      */     //   258: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   261: lookupswitch default -> 885, 10 -> 312, 13 -> 312, 14 -> 447, 15 -> 710, 16 -> 567
/*      */     //   312: iconst_0
/*      */     //   313: istore #23
/*      */     //   315: goto -> 435
/*      */     //   318: iload #23
/*      */     //   320: iconst_4
/*      */     //   321: imul
/*      */     //   322: wide istore #687
/*      */     //   326: aload #16
/*      */     //   328: wide astore #685
/*      */     //   332: iload #17
/*      */     //   334: wide iload #687
/*      */     //   338: iadd
/*      */     //   339: wide istore #686
/*      */     //   343: iload #23
/*      */     //   345: iconst_4
/*      */     //   346: imul
/*      */     //   347: wide istore #683
/*      */     //   351: aload #13
/*      */     //   353: wide astore #681
/*      */     //   357: iload #14
/*      */     //   359: wide iload #683
/*      */     //   363: iadd
/*      */     //   364: wide istore #682
/*      */     //   368: wide aload #681
/*      */     //   372: wide iload #682
/*      */     //   376: invokeinterface getInt : (I)I
/*      */     //   381: wide istore #680
/*      */     //   385: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   388: wide istore #679
/*      */     //   392: wide iload #680
/*      */     //   396: wide iload #679
/*      */     //   400: if_icmpeq -> 410
/*      */     //   403: goto -> 406
/*      */     //   406: iconst_0
/*      */     //   407: goto -> 411
/*      */     //   410: iconst_1
/*      */     //   411: wide istore #677
/*      */     //   415: wide aload #685
/*      */     //   419: wide iload #686
/*      */     //   423: wide iload #677
/*      */     //   427: invokeinterface setInt : (II)V
/*      */     //   432: iinc #23, 1
/*      */     //   435: iload #23
/*      */     //   437: iload_1
/*      */     //   438: if_icmplt -> 318
/*      */     //   441: goto -> 444
/*      */     //   444: goto -> 903
/*      */     //   447: iconst_0
/*      */     //   448: istore #23
/*      */     //   450: goto -> 555
/*      */     //   453: iload #23
/*      */     //   455: iconst_4
/*      */     //   456: imul
/*      */     //   457: wide istore #675
/*      */     //   461: aload #16
/*      */     //   463: wide astore #673
/*      */     //   467: iload #17
/*      */     //   469: wide iload #675
/*      */     //   473: iadd
/*      */     //   474: wide istore #674
/*      */     //   478: iload #23
/*      */     //   480: bipush #8
/*      */     //   482: imul
/*      */     //   483: wide istore #671
/*      */     //   487: aload #11
/*      */     //   489: wide astore #669
/*      */     //   493: iload #12
/*      */     //   495: wide iload #671
/*      */     //   499: iadd
/*      */     //   500: wide istore #670
/*      */     //   504: wide aload #669
/*      */     //   508: wide iload #670
/*      */     //   512: invokeinterface getDouble : (I)D
/*      */     //   517: invokestatic __isnan : (D)I
/*      */     //   520: ifne -> 530
/*      */     //   523: goto -> 526
/*      */     //   526: iconst_0
/*      */     //   527: goto -> 531
/*      */     //   530: iconst_1
/*      */     //   531: wide istore #664
/*      */     //   535: wide aload #673
/*      */     //   539: wide iload #674
/*      */     //   543: wide iload #664
/*      */     //   547: invokeinterface setInt : (II)V
/*      */     //   552: iinc #23, 1
/*      */     //   555: iload #23
/*      */     //   557: iload_1
/*      */     //   558: if_icmplt -> 453
/*      */     //   561: goto -> 564
/*      */     //   564: goto -> 903
/*      */     //   567: iconst_0
/*      */     //   568: istore #23
/*      */     //   570: goto -> 698
/*      */     //   573: iload #23
/*      */     //   575: iconst_4
/*      */     //   576: imul
/*      */     //   577: wide istore #662
/*      */     //   581: aload #16
/*      */     //   583: wide astore #660
/*      */     //   587: iload #17
/*      */     //   589: wide iload #662
/*      */     //   593: iadd
/*      */     //   594: wide istore #661
/*      */     //   598: iload #23
/*      */     //   600: iconst_4
/*      */     //   601: imul
/*      */     //   602: wide istore #658
/*      */     //   606: aload #7
/*      */     //   608: wide astore #656
/*      */     //   612: iload #8
/*      */     //   614: wide iload #658
/*      */     //   618: iadd
/*      */     //   619: wide istore #657
/*      */     //   623: wide aload #656
/*      */     //   627: wide iload #657
/*      */     //   631: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   636: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   641: checkcast org/renjin/sexp/SEXP
/*      */     //   644: wide astore #655
/*      */     //   648: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   651: wide astore #654
/*      */     //   655: wide aload #655
/*      */     //   659: wide aload #654
/*      */     //   663: if_acmpeq -> 673
/*      */     //   666: goto -> 669
/*      */     //   669: iconst_0
/*      */     //   670: goto -> 674
/*      */     //   673: iconst_1
/*      */     //   674: wide istore #652
/*      */     //   678: wide aload #660
/*      */     //   682: wide iload #661
/*      */     //   686: wide iload #652
/*      */     //   690: invokeinterface setInt : (II)V
/*      */     //   695: iinc #23, 1
/*      */     //   698: iload #23
/*      */     //   700: iload_1
/*      */     //   701: if_icmplt -> 573
/*      */     //   704: goto -> 707
/*      */     //   707: goto -> 903
/*      */     //   710: iconst_0
/*      */     //   711: istore #23
/*      */     //   713: goto -> 873
/*      */     //   716: iload #23
/*      */     //   718: iconst_4
/*      */     //   719: imul
/*      */     //   720: wide istore #650
/*      */     //   724: aload #16
/*      */     //   726: wide astore #648
/*      */     //   730: iload #17
/*      */     //   732: wide iload #650
/*      */     //   736: iadd
/*      */     //   737: wide istore #649
/*      */     //   741: iload #23
/*      */     //   743: bipush #16
/*      */     //   745: imul
/*      */     //   746: wide istore #645
/*      */     //   750: aload #9
/*      */     //   752: wide astore #643
/*      */     //   756: iload #10
/*      */     //   758: wide iload #645
/*      */     //   762: iadd
/*      */     //   763: wide istore #644
/*      */     //   767: wide aload #643
/*      */     //   771: wide iload #644
/*      */     //   775: invokeinterface getDouble : (I)D
/*      */     //   780: invokestatic __isnan : (D)I
/*      */     //   783: ifne -> 840
/*      */     //   786: goto -> 789
/*      */     //   789: iload #23
/*      */     //   791: bipush #16
/*      */     //   793: imul
/*      */     //   794: wide istore #638
/*      */     //   798: aload #9
/*      */     //   800: wide astore #636
/*      */     //   804: iload #10
/*      */     //   806: wide iload #638
/*      */     //   810: iadd
/*      */     //   811: wide istore #637
/*      */     //   815: wide aload #636
/*      */     //   819: wide iload #637
/*      */     //   823: bipush #8
/*      */     //   825: iadd
/*      */     //   826: invokeinterface getDouble : (I)D
/*      */     //   831: invokestatic __isnan : (D)I
/*      */     //   834: ifne -> 840
/*      */     //   837: goto -> 848
/*      */     //   840: iconst_1
/*      */     //   841: wide istore #647
/*      */     //   845: goto -> 853
/*      */     //   848: iconst_0
/*      */     //   849: wide istore #647
/*      */     //   853: wide aload #648
/*      */     //   857: wide iload #649
/*      */     //   861: wide iload #647
/*      */     //   865: invokeinterface setInt : (II)V
/*      */     //   870: iinc #23, 1
/*      */     //   873: iload #23
/*      */     //   875: iload_1
/*      */     //   876: if_icmplt -> 716
/*      */     //   879: goto -> 882
/*      */     //   882: goto -> 903
/*      */     //   885: new org/renjin/gcc/runtime/BytePtr
/*      */     //   888: dup
/*      */     //   889: ldc_w 'orderVector1 '
/*      */     //   892: invokevirtual getBytes : ()[B
/*      */     //   895: iconst_0
/*      */     //   896: invokespecial <init> : ([BI)V
/*      */     //   899: aload_2
/*      */     //   900: invokestatic UNIMPLEMENTED_TYPE : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/sexp/SEXP;)V
/*      */     //   903: iconst_0
/*      */     //   904: istore #23
/*      */     //   906: goto -> 955
/*      */     //   909: iload #23
/*      */     //   911: iconst_4
/*      */     //   912: imul
/*      */     //   913: wide istore #631
/*      */     //   917: aload #16
/*      */     //   919: wide astore #629
/*      */     //   923: iload #17
/*      */     //   925: wide iload #631
/*      */     //   929: iadd
/*      */     //   930: wide istore #630
/*      */     //   934: wide aload #629
/*      */     //   938: wide iload #630
/*      */     //   942: invokeinterface getInt : (I)I
/*      */     //   947: iload #15
/*      */     //   949: iadd
/*      */     //   950: istore #15
/*      */     //   952: iinc #23, 1
/*      */     //   955: iload #23
/*      */     //   957: iload_1
/*      */     //   958: if_icmplt -> 909
/*      */     //   961: goto -> 964
/*      */     //   964: iload #15
/*      */     //   966: ifne -> 972
/*      */     //   969: goto -> 1764
/*      */     //   972: aload_2
/*      */     //   973: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   976: lookupswitch default -> 1764, 10 -> 1028, 13 -> 1028, 14 -> 1028, 15 -> 1028, 16 -> 1028
/*      */     //   1028: iload_3
/*      */     //   1029: ifeq -> 1035
/*      */     //   1032: goto -> 1148
/*      */     //   1035: iconst_0
/*      */     //   1036: istore #23
/*      */     //   1038: goto -> 1139
/*      */     //   1041: iload #23
/*      */     //   1043: iconst_4
/*      */     //   1044: imul
/*      */     //   1045: wide istore #625
/*      */     //   1049: aload #16
/*      */     //   1051: wide astore #623
/*      */     //   1055: iload #17
/*      */     //   1057: wide iload #625
/*      */     //   1061: iadd
/*      */     //   1062: wide istore #624
/*      */     //   1066: iload #23
/*      */     //   1068: iconst_4
/*      */     //   1069: imul
/*      */     //   1070: wide istore #621
/*      */     //   1074: aload #16
/*      */     //   1076: wide astore #619
/*      */     //   1080: iload #17
/*      */     //   1082: wide iload #621
/*      */     //   1086: iadd
/*      */     //   1087: wide istore #620
/*      */     //   1091: wide aload #619
/*      */     //   1095: wide iload #620
/*      */     //   1099: invokeinterface getInt : (I)I
/*      */     //   1104: ifeq -> 1114
/*      */     //   1107: goto -> 1110
/*      */     //   1110: iconst_0
/*      */     //   1111: goto -> 1115
/*      */     //   1114: iconst_1
/*      */     //   1115: wide istore #616
/*      */     //   1119: wide aload #623
/*      */     //   1123: wide iload #624
/*      */     //   1127: wide iload #616
/*      */     //   1131: invokeinterface setInt : (II)V
/*      */     //   1136: iinc #23, 1
/*      */     //   1139: iload #23
/*      */     //   1141: iload_1
/*      */     //   1142: if_icmplt -> 1041
/*      */     //   1145: goto -> 1148
/*      */     //   1148: iconst_0
/*      */     //   1149: istore #20
/*      */     //   1151: goto -> 1157
/*      */     //   1154: iinc #20, 1
/*      */     //   1157: invokestatic get__sort$sincs : ()[I
/*      */     //   1160: iload #20
/*      */     //   1162: iaload
/*      */     //   1163: iload_1
/*      */     //   1164: if_icmpgt -> 1154
/*      */     //   1167: goto -> 1170
/*      */     //   1170: invokestatic get__sort$sincs : ()[I
/*      */     //   1173: iload #20
/*      */     //   1175: iaload
/*      */     //   1176: istore #21
/*      */     //   1178: goto -> 1707
/*      */     //   1181: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   1184: iload #19
/*      */     //   1186: iload #21
/*      */     //   1188: iadd
/*      */     //   1189: istore #23
/*      */     //   1191: goto -> 1686
/*      */     //   1194: iload #23
/*      */     //   1196: iconst_4
/*      */     //   1197: imul
/*      */     //   1198: wide istore #613
/*      */     //   1202: aload_0
/*      */     //   1203: wide astore #611
/*      */     //   1207: wide iload #613
/*      */     //   1211: wide istore #612
/*      */     //   1215: wide aload #611
/*      */     //   1219: wide iload #612
/*      */     //   1223: invokeinterface getInt : (I)I
/*      */     //   1228: istore #6
/*      */     //   1230: iload #23
/*      */     //   1232: istore #22
/*      */     //   1234: goto -> 1323
/*      */     //   1237: iload #22
/*      */     //   1239: iconst_4
/*      */     //   1240: imul
/*      */     //   1241: wide istore #609
/*      */     //   1245: aload_0
/*      */     //   1246: wide astore #607
/*      */     //   1250: wide iload #609
/*      */     //   1254: wide istore #608
/*      */     //   1258: iload #22
/*      */     //   1260: iload #21
/*      */     //   1262: isub
/*      */     //   1263: iconst_4
/*      */     //   1264: imul
/*      */     //   1265: wide istore #604
/*      */     //   1269: aload_0
/*      */     //   1270: wide astore #602
/*      */     //   1274: wide iload #604
/*      */     //   1278: wide istore #603
/*      */     //   1282: wide aload #602
/*      */     //   1286: wide iload #603
/*      */     //   1290: invokeinterface getInt : (I)I
/*      */     //   1295: wide istore #601
/*      */     //   1299: wide aload #607
/*      */     //   1303: wide iload #608
/*      */     //   1307: wide iload #601
/*      */     //   1311: invokeinterface setInt : (II)V
/*      */     //   1316: iload #22
/*      */     //   1318: iload #21
/*      */     //   1320: isub
/*      */     //   1321: istore #22
/*      */     //   1323: iload #19
/*      */     //   1325: iload #21
/*      */     //   1327: iadd
/*      */     //   1328: iload #22
/*      */     //   1330: if_icmple -> 1336
/*      */     //   1333: goto -> 1647
/*      */     //   1336: iload #22
/*      */     //   1338: iload #21
/*      */     //   1340: isub
/*      */     //   1341: iconst_4
/*      */     //   1342: imul
/*      */     //   1343: wide istore #597
/*      */     //   1347: aload_0
/*      */     //   1348: wide astore #595
/*      */     //   1352: wide iload #597
/*      */     //   1356: wide istore #596
/*      */     //   1360: wide aload #595
/*      */     //   1364: wide iload #596
/*      */     //   1368: invokeinterface getInt : (I)I
/*      */     //   1373: iconst_4
/*      */     //   1374: imul
/*      */     //   1375: wide istore #592
/*      */     //   1379: aload #16
/*      */     //   1381: wide astore #590
/*      */     //   1385: iload #17
/*      */     //   1387: wide iload #592
/*      */     //   1391: iadd
/*      */     //   1392: wide istore #591
/*      */     //   1396: wide aload #590
/*      */     //   1400: wide iload #591
/*      */     //   1404: invokeinterface getInt : (I)I
/*      */     //   1409: wide istore #589
/*      */     //   1413: iload #6
/*      */     //   1415: iconst_4
/*      */     //   1416: imul
/*      */     //   1417: wide istore #587
/*      */     //   1421: aload #16
/*      */     //   1423: wide astore #585
/*      */     //   1427: iload #17
/*      */     //   1429: wide iload #587
/*      */     //   1433: iadd
/*      */     //   1434: wide istore #586
/*      */     //   1438: wide aload #585
/*      */     //   1442: wide iload #586
/*      */     //   1446: invokeinterface getInt : (I)I
/*      */     //   1451: wide istore #584
/*      */     //   1455: wide iload #589
/*      */     //   1459: wide iload #584
/*      */     //   1463: if_icmpgt -> 1237
/*      */     //   1466: goto -> 1469
/*      */     //   1469: iload #22
/*      */     //   1471: iload #21
/*      */     //   1473: isub
/*      */     //   1474: iconst_4
/*      */     //   1475: imul
/*      */     //   1476: wide istore #581
/*      */     //   1480: aload_0
/*      */     //   1481: wide astore #579
/*      */     //   1485: wide iload #581
/*      */     //   1489: wide istore #580
/*      */     //   1493: wide aload #579
/*      */     //   1497: wide iload #580
/*      */     //   1501: invokeinterface getInt : (I)I
/*      */     //   1506: iconst_4
/*      */     //   1507: imul
/*      */     //   1508: wide istore #576
/*      */     //   1512: aload #16
/*      */     //   1514: wide astore #574
/*      */     //   1518: iload #17
/*      */     //   1520: wide iload #576
/*      */     //   1524: iadd
/*      */     //   1525: wide istore #575
/*      */     //   1529: wide aload #574
/*      */     //   1533: wide iload #575
/*      */     //   1537: invokeinterface getInt : (I)I
/*      */     //   1542: wide istore #573
/*      */     //   1546: iload #6
/*      */     //   1548: iconst_4
/*      */     //   1549: imul
/*      */     //   1550: wide istore #571
/*      */     //   1554: aload #16
/*      */     //   1556: wide astore #569
/*      */     //   1560: iload #17
/*      */     //   1562: wide iload #571
/*      */     //   1566: iadd
/*      */     //   1567: wide istore #570
/*      */     //   1571: wide aload #569
/*      */     //   1575: wide iload #570
/*      */     //   1579: invokeinterface getInt : (I)I
/*      */     //   1584: wide istore #568
/*      */     //   1588: wide iload #573
/*      */     //   1592: wide iload #568
/*      */     //   1596: if_icmpeq -> 1602
/*      */     //   1599: goto -> 1647
/*      */     //   1602: iload #22
/*      */     //   1604: iload #21
/*      */     //   1606: isub
/*      */     //   1607: iconst_4
/*      */     //   1608: imul
/*      */     //   1609: wide istore #565
/*      */     //   1613: aload_0
/*      */     //   1614: wide astore #563
/*      */     //   1618: wide iload #565
/*      */     //   1622: wide istore #564
/*      */     //   1626: wide aload #563
/*      */     //   1630: wide iload #564
/*      */     //   1634: invokeinterface getInt : (I)I
/*      */     //   1639: iload #6
/*      */     //   1641: if_icmpgt -> 1237
/*      */     //   1644: goto -> 1647
/*      */     //   1647: iload #22
/*      */     //   1649: iconst_4
/*      */     //   1650: imul
/*      */     //   1651: wide istore #560
/*      */     //   1655: aload_0
/*      */     //   1656: wide astore #558
/*      */     //   1660: wide iload #560
/*      */     //   1664: wide istore #559
/*      */     //   1668: wide aload #558
/*      */     //   1672: wide iload #559
/*      */     //   1676: iload #6
/*      */     //   1678: invokeinterface setInt : (II)V
/*      */     //   1683: iinc #23, 1
/*      */     //   1686: iload #23
/*      */     //   1688: iload #18
/*      */     //   1690: if_icmple -> 1194
/*      */     //   1693: goto -> 1696
/*      */     //   1696: iinc #20, 1
/*      */     //   1699: invokestatic get__sort$sincs : ()[I
/*      */     //   1702: iload #20
/*      */     //   1704: iaload
/*      */     //   1705: istore #21
/*      */     //   1707: iload #20
/*      */     //   1709: bipush #15
/*      */     //   1711: if_icmple -> 1181
/*      */     //   1714: goto -> 1717
/*      */     //   1717: iload_1
/*      */     //   1718: iload #15
/*      */     //   1720: isub
/*      */     //   1721: iconst_1
/*      */     //   1722: if_icmple -> 1728
/*      */     //   1725: goto -> 1740
/*      */     //   1728: iconst_0
/*      */     //   1729: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1732: astore #16
/*      */     //   1734: iconst_0
/*      */     //   1735: istore #17
/*      */     //   1737: goto -> 6486
/*      */     //   1740: iload_3
/*      */     //   1741: ifne -> 1747
/*      */     //   1744: goto -> 1757
/*      */     //   1747: iload #18
/*      */     //   1749: iload #15
/*      */     //   1751: isub
/*      */     //   1752: istore #18
/*      */     //   1754: goto -> 1764
/*      */     //   1757: iload #19
/*      */     //   1759: iload #15
/*      */     //   1761: iadd
/*      */     //   1762: istore #19
/*      */     //   1764: iconst_0
/*      */     //   1765: istore #20
/*      */     //   1767: goto -> 1773
/*      */     //   1770: iinc #20, 1
/*      */     //   1773: invokestatic get__sort$sincs : ()[I
/*      */     //   1776: iload #20
/*      */     //   1778: iaload
/*      */     //   1779: wide istore #556
/*      */     //   1783: iload #18
/*      */     //   1785: iload #19
/*      */     //   1787: isub
/*      */     //   1788: iconst_1
/*      */     //   1789: iadd
/*      */     //   1790: wide istore #554
/*      */     //   1794: wide iload #556
/*      */     //   1798: wide iload #554
/*      */     //   1802: if_icmpgt -> 1770
/*      */     //   1805: goto -> 1808
/*      */     //   1808: aload_2
/*      */     //   1809: invokestatic OBJECT : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   1812: ifne -> 1818
/*      */     //   1815: goto -> 2133
/*      */     //   1818: aload #5
/*      */     //   1820: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1823: ifne -> 1829
/*      */     //   1826: goto -> 2133
/*      */     //   1829: invokestatic get__sort$sincs : ()[I
/*      */     //   1832: iload #20
/*      */     //   1834: iaload
/*      */     //   1835: istore #21
/*      */     //   1837: goto -> 2120
/*      */     //   1840: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   1843: iload #19
/*      */     //   1845: iload #21
/*      */     //   1847: iadd
/*      */     //   1848: istore #23
/*      */     //   1850: goto -> 2099
/*      */     //   1853: iload #23
/*      */     //   1855: iconst_4
/*      */     //   1856: imul
/*      */     //   1857: wide istore #550
/*      */     //   1861: aload_0
/*      */     //   1862: wide astore #548
/*      */     //   1866: wide iload #550
/*      */     //   1870: wide istore #549
/*      */     //   1874: wide aload #548
/*      */     //   1878: wide iload #549
/*      */     //   1882: invokeinterface getInt : (I)I
/*      */     //   1887: istore #6
/*      */     //   1889: iload #23
/*      */     //   1891: istore #22
/*      */     //   1893: goto -> 1982
/*      */     //   1896: iload #22
/*      */     //   1898: iconst_4
/*      */     //   1899: imul
/*      */     //   1900: wide istore #546
/*      */     //   1904: aload_0
/*      */     //   1905: wide astore #544
/*      */     //   1909: wide iload #546
/*      */     //   1913: wide istore #545
/*      */     //   1917: iload #22
/*      */     //   1919: iload #21
/*      */     //   1921: isub
/*      */     //   1922: iconst_4
/*      */     //   1923: imul
/*      */     //   1924: wide istore #541
/*      */     //   1928: aload_0
/*      */     //   1929: wide astore #539
/*      */     //   1933: wide iload #541
/*      */     //   1937: wide istore #540
/*      */     //   1941: wide aload #539
/*      */     //   1945: wide iload #540
/*      */     //   1949: invokeinterface getInt : (I)I
/*      */     //   1954: wide istore #538
/*      */     //   1958: wide aload #544
/*      */     //   1962: wide iload #545
/*      */     //   1966: wide iload #538
/*      */     //   1970: invokeinterface setInt : (II)V
/*      */     //   1975: iload #22
/*      */     //   1977: iload #21
/*      */     //   1979: isub
/*      */     //   1980: istore #22
/*      */     //   1982: iload #19
/*      */     //   1984: iload #21
/*      */     //   1986: iadd
/*      */     //   1987: iload #22
/*      */     //   1989: if_icmple -> 1995
/*      */     //   1992: goto -> 2060
/*      */     //   1995: iload_3
/*      */     //   1996: iload #4
/*      */     //   1998: ixor
/*      */     //   1999: wide istore #536
/*      */     //   2003: iload #22
/*      */     //   2005: iload #21
/*      */     //   2007: isub
/*      */     //   2008: iconst_4
/*      */     //   2009: imul
/*      */     //   2010: wide istore #533
/*      */     //   2014: aload_0
/*      */     //   2015: wide astore #531
/*      */     //   2019: wide iload #533
/*      */     //   2023: wide istore #532
/*      */     //   2027: wide aload #531
/*      */     //   2031: wide iload #532
/*      */     //   2035: invokeinterface getInt : (I)I
/*      */     //   2040: iload #6
/*      */     //   2042: aload_2
/*      */     //   2043: wide iload #536
/*      */     //   2047: iload #4
/*      */     //   2049: aload #5
/*      */     //   2051: invokestatic greater : (IILorg/renjin/sexp/SEXP;IILorg/renjin/sexp/SEXP;)I
/*      */     //   2054: ifne -> 1896
/*      */     //   2057: goto -> 2060
/*      */     //   2060: iload #22
/*      */     //   2062: iconst_4
/*      */     //   2063: imul
/*      */     //   2064: wide istore #527
/*      */     //   2068: aload_0
/*      */     //   2069: wide astore #525
/*      */     //   2073: wide iload #527
/*      */     //   2077: wide istore #526
/*      */     //   2081: wide aload #525
/*      */     //   2085: wide iload #526
/*      */     //   2089: iload #6
/*      */     //   2091: invokeinterface setInt : (II)V
/*      */     //   2096: iinc #23, 1
/*      */     //   2099: iload #23
/*      */     //   2101: iload #18
/*      */     //   2103: if_icmple -> 1853
/*      */     //   2106: goto -> 2109
/*      */     //   2109: iinc #20, 1
/*      */     //   2112: invokestatic get__sort$sincs : ()[I
/*      */     //   2115: iload #20
/*      */     //   2117: iaload
/*      */     //   2118: istore #21
/*      */     //   2120: iload #20
/*      */     //   2122: bipush #15
/*      */     //   2124: if_icmple -> 1840
/*      */     //   2127: goto -> 2130
/*      */     //   2130: goto -> 6457
/*      */     //   2133: aload_2
/*      */     //   2134: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2137: lookupswitch default -> 6224, 10 -> 2188, 13 -> 2188, 14 -> 3293, 15 -> 4410, 16 -> 5513
/*      */     //   2188: iload #4
/*      */     //   2190: ifne -> 2196
/*      */     //   2193: goto -> 2743
/*      */     //   2196: invokestatic get__sort$sincs : ()[I
/*      */     //   2199: iload #20
/*      */     //   2201: iaload
/*      */     //   2202: istore #21
/*      */     //   2204: goto -> 2733
/*      */     //   2207: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   2210: iload #19
/*      */     //   2212: iload #21
/*      */     //   2214: iadd
/*      */     //   2215: istore #23
/*      */     //   2217: goto -> 2712
/*      */     //   2220: iload #23
/*      */     //   2222: iconst_4
/*      */     //   2223: imul
/*      */     //   2224: wide istore #522
/*      */     //   2228: aload_0
/*      */     //   2229: wide astore #520
/*      */     //   2233: wide iload #522
/*      */     //   2237: wide istore #521
/*      */     //   2241: wide aload #520
/*      */     //   2245: wide iload #521
/*      */     //   2249: invokeinterface getInt : (I)I
/*      */     //   2254: istore #6
/*      */     //   2256: iload #23
/*      */     //   2258: istore #22
/*      */     //   2260: goto -> 2349
/*      */     //   2263: iload #22
/*      */     //   2265: iconst_4
/*      */     //   2266: imul
/*      */     //   2267: wide istore #518
/*      */     //   2271: aload_0
/*      */     //   2272: wide astore #516
/*      */     //   2276: wide iload #518
/*      */     //   2280: wide istore #517
/*      */     //   2284: iload #22
/*      */     //   2286: iload #21
/*      */     //   2288: isub
/*      */     //   2289: iconst_4
/*      */     //   2290: imul
/*      */     //   2291: wide istore #513
/*      */     //   2295: aload_0
/*      */     //   2296: wide astore #511
/*      */     //   2300: wide iload #513
/*      */     //   2304: wide istore #512
/*      */     //   2308: wide aload #511
/*      */     //   2312: wide iload #512
/*      */     //   2316: invokeinterface getInt : (I)I
/*      */     //   2321: wide istore #510
/*      */     //   2325: wide aload #516
/*      */     //   2329: wide iload #517
/*      */     //   2333: wide iload #510
/*      */     //   2337: invokeinterface setInt : (II)V
/*      */     //   2342: iload #22
/*      */     //   2344: iload #21
/*      */     //   2346: isub
/*      */     //   2347: istore #22
/*      */     //   2349: iload #19
/*      */     //   2351: iload #21
/*      */     //   2353: iadd
/*      */     //   2354: iload #22
/*      */     //   2356: if_icmple -> 2362
/*      */     //   2359: goto -> 2673
/*      */     //   2362: iload #22
/*      */     //   2364: iload #21
/*      */     //   2366: isub
/*      */     //   2367: iconst_4
/*      */     //   2368: imul
/*      */     //   2369: wide istore #506
/*      */     //   2373: aload_0
/*      */     //   2374: wide astore #504
/*      */     //   2378: wide iload #506
/*      */     //   2382: wide istore #505
/*      */     //   2386: wide aload #504
/*      */     //   2390: wide iload #505
/*      */     //   2394: invokeinterface getInt : (I)I
/*      */     //   2399: iconst_4
/*      */     //   2400: imul
/*      */     //   2401: wide istore #501
/*      */     //   2405: aload #13
/*      */     //   2407: wide astore #499
/*      */     //   2411: iload #14
/*      */     //   2413: wide iload #501
/*      */     //   2417: iadd
/*      */     //   2418: wide istore #500
/*      */     //   2422: wide aload #499
/*      */     //   2426: wide iload #500
/*      */     //   2430: invokeinterface getInt : (I)I
/*      */     //   2435: wide istore #498
/*      */     //   2439: iload #6
/*      */     //   2441: iconst_4
/*      */     //   2442: imul
/*      */     //   2443: wide istore #496
/*      */     //   2447: aload #13
/*      */     //   2449: wide astore #494
/*      */     //   2453: iload #14
/*      */     //   2455: wide iload #496
/*      */     //   2459: iadd
/*      */     //   2460: wide istore #495
/*      */     //   2464: wide aload #494
/*      */     //   2468: wide iload #495
/*      */     //   2472: invokeinterface getInt : (I)I
/*      */     //   2477: wide istore #493
/*      */     //   2481: wide iload #498
/*      */     //   2485: wide iload #493
/*      */     //   2489: if_icmplt -> 2263
/*      */     //   2492: goto -> 2495
/*      */     //   2495: iload #22
/*      */     //   2497: iload #21
/*      */     //   2499: isub
/*      */     //   2500: iconst_4
/*      */     //   2501: imul
/*      */     //   2502: wide istore #490
/*      */     //   2506: aload_0
/*      */     //   2507: wide astore #488
/*      */     //   2511: wide iload #490
/*      */     //   2515: wide istore #489
/*      */     //   2519: wide aload #488
/*      */     //   2523: wide iload #489
/*      */     //   2527: invokeinterface getInt : (I)I
/*      */     //   2532: iconst_4
/*      */     //   2533: imul
/*      */     //   2534: wide istore #485
/*      */     //   2538: aload #13
/*      */     //   2540: wide astore #483
/*      */     //   2544: iload #14
/*      */     //   2546: wide iload #485
/*      */     //   2550: iadd
/*      */     //   2551: wide istore #484
/*      */     //   2555: wide aload #483
/*      */     //   2559: wide iload #484
/*      */     //   2563: invokeinterface getInt : (I)I
/*      */     //   2568: wide istore #482
/*      */     //   2572: iload #6
/*      */     //   2574: iconst_4
/*      */     //   2575: imul
/*      */     //   2576: wide istore #480
/*      */     //   2580: aload #13
/*      */     //   2582: wide astore #478
/*      */     //   2586: iload #14
/*      */     //   2588: wide iload #480
/*      */     //   2592: iadd
/*      */     //   2593: wide istore #479
/*      */     //   2597: wide aload #478
/*      */     //   2601: wide iload #479
/*      */     //   2605: invokeinterface getInt : (I)I
/*      */     //   2610: wide istore #477
/*      */     //   2614: wide iload #482
/*      */     //   2618: wide iload #477
/*      */     //   2622: if_icmpeq -> 2628
/*      */     //   2625: goto -> 2673
/*      */     //   2628: iload #22
/*      */     //   2630: iload #21
/*      */     //   2632: isub
/*      */     //   2633: iconst_4
/*      */     //   2634: imul
/*      */     //   2635: wide istore #474
/*      */     //   2639: aload_0
/*      */     //   2640: wide astore #472
/*      */     //   2644: wide iload #474
/*      */     //   2648: wide istore #473
/*      */     //   2652: wide aload #472
/*      */     //   2656: wide iload #473
/*      */     //   2660: invokeinterface getInt : (I)I
/*      */     //   2665: iload #6
/*      */     //   2667: if_icmpgt -> 2263
/*      */     //   2670: goto -> 2673
/*      */     //   2673: iload #22
/*      */     //   2675: iconst_4
/*      */     //   2676: imul
/*      */     //   2677: wide istore #469
/*      */     //   2681: aload_0
/*      */     //   2682: wide astore #467
/*      */     //   2686: wide iload #469
/*      */     //   2690: wide istore #468
/*      */     //   2694: wide aload #467
/*      */     //   2698: wide iload #468
/*      */     //   2702: iload #6
/*      */     //   2704: invokeinterface setInt : (II)V
/*      */     //   2709: iinc #23, 1
/*      */     //   2712: iload #23
/*      */     //   2714: iload #18
/*      */     //   2716: if_icmple -> 2220
/*      */     //   2719: goto -> 2722
/*      */     //   2722: iinc #20, 1
/*      */     //   2725: invokestatic get__sort$sincs : ()[I
/*      */     //   2728: iload #20
/*      */     //   2730: iaload
/*      */     //   2731: istore #21
/*      */     //   2733: iload #20
/*      */     //   2735: bipush #15
/*      */     //   2737: if_icmple -> 2207
/*      */     //   2740: goto -> 3290
/*      */     //   2743: invokestatic get__sort$sincs : ()[I
/*      */     //   2746: iload #20
/*      */     //   2748: iaload
/*      */     //   2749: istore #21
/*      */     //   2751: goto -> 3280
/*      */     //   2754: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   2757: iload #19
/*      */     //   2759: iload #21
/*      */     //   2761: iadd
/*      */     //   2762: istore #23
/*      */     //   2764: goto -> 3259
/*      */     //   2767: iload #23
/*      */     //   2769: iconst_4
/*      */     //   2770: imul
/*      */     //   2771: wide istore #465
/*      */     //   2775: aload_0
/*      */     //   2776: wide astore #463
/*      */     //   2780: wide iload #465
/*      */     //   2784: wide istore #464
/*      */     //   2788: wide aload #463
/*      */     //   2792: wide iload #464
/*      */     //   2796: invokeinterface getInt : (I)I
/*      */     //   2801: istore #6
/*      */     //   2803: iload #23
/*      */     //   2805: istore #22
/*      */     //   2807: goto -> 2896
/*      */     //   2810: iload #22
/*      */     //   2812: iconst_4
/*      */     //   2813: imul
/*      */     //   2814: wide istore #461
/*      */     //   2818: aload_0
/*      */     //   2819: wide astore #459
/*      */     //   2823: wide iload #461
/*      */     //   2827: wide istore #460
/*      */     //   2831: iload #22
/*      */     //   2833: iload #21
/*      */     //   2835: isub
/*      */     //   2836: iconst_4
/*      */     //   2837: imul
/*      */     //   2838: wide istore #456
/*      */     //   2842: aload_0
/*      */     //   2843: wide astore #454
/*      */     //   2847: wide iload #456
/*      */     //   2851: wide istore #455
/*      */     //   2855: wide aload #454
/*      */     //   2859: wide iload #455
/*      */     //   2863: invokeinterface getInt : (I)I
/*      */     //   2868: wide istore #453
/*      */     //   2872: wide aload #459
/*      */     //   2876: wide iload #460
/*      */     //   2880: wide iload #453
/*      */     //   2884: invokeinterface setInt : (II)V
/*      */     //   2889: iload #22
/*      */     //   2891: iload #21
/*      */     //   2893: isub
/*      */     //   2894: istore #22
/*      */     //   2896: iload #19
/*      */     //   2898: iload #21
/*      */     //   2900: iadd
/*      */     //   2901: iload #22
/*      */     //   2903: if_icmple -> 2909
/*      */     //   2906: goto -> 3220
/*      */     //   2909: iload #22
/*      */     //   2911: iload #21
/*      */     //   2913: isub
/*      */     //   2914: iconst_4
/*      */     //   2915: imul
/*      */     //   2916: wide istore #449
/*      */     //   2920: aload_0
/*      */     //   2921: wide astore #447
/*      */     //   2925: wide iload #449
/*      */     //   2929: wide istore #448
/*      */     //   2933: wide aload #447
/*      */     //   2937: wide iload #448
/*      */     //   2941: invokeinterface getInt : (I)I
/*      */     //   2946: iconst_4
/*      */     //   2947: imul
/*      */     //   2948: wide istore #444
/*      */     //   2952: aload #13
/*      */     //   2954: wide astore #442
/*      */     //   2958: iload #14
/*      */     //   2960: wide iload #444
/*      */     //   2964: iadd
/*      */     //   2965: wide istore #443
/*      */     //   2969: wide aload #442
/*      */     //   2973: wide iload #443
/*      */     //   2977: invokeinterface getInt : (I)I
/*      */     //   2982: wide istore #441
/*      */     //   2986: iload #6
/*      */     //   2988: iconst_4
/*      */     //   2989: imul
/*      */     //   2990: wide istore #439
/*      */     //   2994: aload #13
/*      */     //   2996: wide astore #437
/*      */     //   3000: iload #14
/*      */     //   3002: wide iload #439
/*      */     //   3006: iadd
/*      */     //   3007: wide istore #438
/*      */     //   3011: wide aload #437
/*      */     //   3015: wide iload #438
/*      */     //   3019: invokeinterface getInt : (I)I
/*      */     //   3024: wide istore #436
/*      */     //   3028: wide iload #441
/*      */     //   3032: wide iload #436
/*      */     //   3036: if_icmpgt -> 2810
/*      */     //   3039: goto -> 3042
/*      */     //   3042: iload #22
/*      */     //   3044: iload #21
/*      */     //   3046: isub
/*      */     //   3047: iconst_4
/*      */     //   3048: imul
/*      */     //   3049: wide istore #433
/*      */     //   3053: aload_0
/*      */     //   3054: wide astore #431
/*      */     //   3058: wide iload #433
/*      */     //   3062: wide istore #432
/*      */     //   3066: wide aload #431
/*      */     //   3070: wide iload #432
/*      */     //   3074: invokeinterface getInt : (I)I
/*      */     //   3079: iconst_4
/*      */     //   3080: imul
/*      */     //   3081: wide istore #428
/*      */     //   3085: aload #13
/*      */     //   3087: wide astore #426
/*      */     //   3091: iload #14
/*      */     //   3093: wide iload #428
/*      */     //   3097: iadd
/*      */     //   3098: wide istore #427
/*      */     //   3102: wide aload #426
/*      */     //   3106: wide iload #427
/*      */     //   3110: invokeinterface getInt : (I)I
/*      */     //   3115: wide istore #425
/*      */     //   3119: iload #6
/*      */     //   3121: iconst_4
/*      */     //   3122: imul
/*      */     //   3123: wide istore #423
/*      */     //   3127: aload #13
/*      */     //   3129: wide astore #421
/*      */     //   3133: iload #14
/*      */     //   3135: wide iload #423
/*      */     //   3139: iadd
/*      */     //   3140: wide istore #422
/*      */     //   3144: wide aload #421
/*      */     //   3148: wide iload #422
/*      */     //   3152: invokeinterface getInt : (I)I
/*      */     //   3157: wide istore #420
/*      */     //   3161: wide iload #425
/*      */     //   3165: wide iload #420
/*      */     //   3169: if_icmpeq -> 3175
/*      */     //   3172: goto -> 3220
/*      */     //   3175: iload #22
/*      */     //   3177: iload #21
/*      */     //   3179: isub
/*      */     //   3180: iconst_4
/*      */     //   3181: imul
/*      */     //   3182: wide istore #417
/*      */     //   3186: aload_0
/*      */     //   3187: wide astore #415
/*      */     //   3191: wide iload #417
/*      */     //   3195: wide istore #416
/*      */     //   3199: wide aload #415
/*      */     //   3203: wide iload #416
/*      */     //   3207: invokeinterface getInt : (I)I
/*      */     //   3212: iload #6
/*      */     //   3214: if_icmpgt -> 2810
/*      */     //   3217: goto -> 3220
/*      */     //   3220: iload #22
/*      */     //   3222: iconst_4
/*      */     //   3223: imul
/*      */     //   3224: wide istore #412
/*      */     //   3228: aload_0
/*      */     //   3229: wide astore #410
/*      */     //   3233: wide iload #412
/*      */     //   3237: wide istore #411
/*      */     //   3241: wide aload #410
/*      */     //   3245: wide iload #411
/*      */     //   3249: iload #6
/*      */     //   3251: invokeinterface setInt : (II)V
/*      */     //   3256: iinc #23, 1
/*      */     //   3259: iload #23
/*      */     //   3261: iload #18
/*      */     //   3263: if_icmple -> 2767
/*      */     //   3266: goto -> 3269
/*      */     //   3269: iinc #20, 1
/*      */     //   3272: invokestatic get__sort$sincs : ()[I
/*      */     //   3275: iload #20
/*      */     //   3277: iaload
/*      */     //   3278: istore #21
/*      */     //   3280: iload #20
/*      */     //   3282: bipush #15
/*      */     //   3284: if_icmple -> 2754
/*      */     //   3287: goto -> 3290
/*      */     //   3290: goto -> 6457
/*      */     //   3293: iload #4
/*      */     //   3295: ifne -> 3301
/*      */     //   3298: goto -> 3854
/*      */     //   3301: invokestatic get__sort$sincs : ()[I
/*      */     //   3304: iload #20
/*      */     //   3306: iaload
/*      */     //   3307: istore #21
/*      */     //   3309: goto -> 3844
/*      */     //   3312: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   3315: iload #19
/*      */     //   3317: iload #21
/*      */     //   3319: iadd
/*      */     //   3320: istore #23
/*      */     //   3322: goto -> 3823
/*      */     //   3325: iload #23
/*      */     //   3327: iconst_4
/*      */     //   3328: imul
/*      */     //   3329: wide istore #408
/*      */     //   3333: aload_0
/*      */     //   3334: wide astore #406
/*      */     //   3338: wide iload #408
/*      */     //   3342: wide istore #407
/*      */     //   3346: wide aload #406
/*      */     //   3350: wide iload #407
/*      */     //   3354: invokeinterface getInt : (I)I
/*      */     //   3359: istore #6
/*      */     //   3361: iload #23
/*      */     //   3363: istore #22
/*      */     //   3365: goto -> 3454
/*      */     //   3368: iload #22
/*      */     //   3370: iconst_4
/*      */     //   3371: imul
/*      */     //   3372: wide istore #404
/*      */     //   3376: aload_0
/*      */     //   3377: wide astore #402
/*      */     //   3381: wide iload #404
/*      */     //   3385: wide istore #403
/*      */     //   3389: iload #22
/*      */     //   3391: iload #21
/*      */     //   3393: isub
/*      */     //   3394: iconst_4
/*      */     //   3395: imul
/*      */     //   3396: wide istore #399
/*      */     //   3400: aload_0
/*      */     //   3401: wide astore #397
/*      */     //   3405: wide iload #399
/*      */     //   3409: wide istore #398
/*      */     //   3413: wide aload #397
/*      */     //   3417: wide iload #398
/*      */     //   3421: invokeinterface getInt : (I)I
/*      */     //   3426: wide istore #396
/*      */     //   3430: wide aload #402
/*      */     //   3434: wide iload #403
/*      */     //   3438: wide iload #396
/*      */     //   3442: invokeinterface setInt : (II)V
/*      */     //   3447: iload #22
/*      */     //   3449: iload #21
/*      */     //   3451: isub
/*      */     //   3452: istore #22
/*      */     //   3454: iload #19
/*      */     //   3456: iload #21
/*      */     //   3458: iadd
/*      */     //   3459: iload #22
/*      */     //   3461: if_icmple -> 3467
/*      */     //   3464: goto -> 3784
/*      */     //   3467: iload #22
/*      */     //   3469: iload #21
/*      */     //   3471: isub
/*      */     //   3472: iconst_4
/*      */     //   3473: imul
/*      */     //   3474: wide istore #392
/*      */     //   3478: aload_0
/*      */     //   3479: wide astore #390
/*      */     //   3483: wide iload #392
/*      */     //   3487: wide istore #391
/*      */     //   3491: wide aload #390
/*      */     //   3495: wide iload #391
/*      */     //   3499: invokeinterface getInt : (I)I
/*      */     //   3504: bipush #8
/*      */     //   3506: imul
/*      */     //   3507: wide istore #387
/*      */     //   3511: aload #11
/*      */     //   3513: wide astore #385
/*      */     //   3517: iload #12
/*      */     //   3519: wide iload #387
/*      */     //   3523: iadd
/*      */     //   3524: wide istore #386
/*      */     //   3528: wide aload #385
/*      */     //   3532: wide iload #386
/*      */     //   3536: invokeinterface getDouble : (I)D
/*      */     //   3541: wide dstore #383
/*      */     //   3545: iload #6
/*      */     //   3547: bipush #8
/*      */     //   3549: imul
/*      */     //   3550: wide istore #381
/*      */     //   3554: aload #11
/*      */     //   3556: wide astore #379
/*      */     //   3560: iload #12
/*      */     //   3562: wide iload #381
/*      */     //   3566: iadd
/*      */     //   3567: wide istore #380
/*      */     //   3571: wide aload #379
/*      */     //   3575: wide iload #380
/*      */     //   3579: invokeinterface getDouble : (I)D
/*      */     //   3584: wide dstore #377
/*      */     //   3588: wide dload #383
/*      */     //   3592: wide dload #377
/*      */     //   3596: dcmpg
/*      */     //   3597: iflt -> 3368
/*      */     //   3600: goto -> 3603
/*      */     //   3603: iload #22
/*      */     //   3605: iload #21
/*      */     //   3607: isub
/*      */     //   3608: iconst_4
/*      */     //   3609: imul
/*      */     //   3610: wide istore #374
/*      */     //   3614: aload_0
/*      */     //   3615: wide astore #372
/*      */     //   3619: wide iload #374
/*      */     //   3623: wide istore #373
/*      */     //   3627: wide aload #372
/*      */     //   3631: wide iload #373
/*      */     //   3635: invokeinterface getInt : (I)I
/*      */     //   3640: bipush #8
/*      */     //   3642: imul
/*      */     //   3643: wide istore #369
/*      */     //   3647: aload #11
/*      */     //   3649: wide astore #367
/*      */     //   3653: iload #12
/*      */     //   3655: wide iload #369
/*      */     //   3659: iadd
/*      */     //   3660: wide istore #368
/*      */     //   3664: wide aload #367
/*      */     //   3668: wide iload #368
/*      */     //   3672: invokeinterface getDouble : (I)D
/*      */     //   3677: wide dstore #365
/*      */     //   3681: iload #6
/*      */     //   3683: bipush #8
/*      */     //   3685: imul
/*      */     //   3686: wide istore #363
/*      */     //   3690: aload #11
/*      */     //   3692: wide astore #361
/*      */     //   3696: iload #12
/*      */     //   3698: wide iload #363
/*      */     //   3702: iadd
/*      */     //   3703: wide istore #362
/*      */     //   3707: wide aload #361
/*      */     //   3711: wide iload #362
/*      */     //   3715: invokeinterface getDouble : (I)D
/*      */     //   3720: wide dstore #359
/*      */     //   3724: wide dload #365
/*      */     //   3728: wide dload #359
/*      */     //   3732: dcmpl
/*      */     //   3733: ifeq -> 3739
/*      */     //   3736: goto -> 3784
/*      */     //   3739: iload #22
/*      */     //   3741: iload #21
/*      */     //   3743: isub
/*      */     //   3744: iconst_4
/*      */     //   3745: imul
/*      */     //   3746: wide istore #356
/*      */     //   3750: aload_0
/*      */     //   3751: wide astore #354
/*      */     //   3755: wide iload #356
/*      */     //   3759: wide istore #355
/*      */     //   3763: wide aload #354
/*      */     //   3767: wide iload #355
/*      */     //   3771: invokeinterface getInt : (I)I
/*      */     //   3776: iload #6
/*      */     //   3778: if_icmpgt -> 3368
/*      */     //   3781: goto -> 3784
/*      */     //   3784: iload #22
/*      */     //   3786: iconst_4
/*      */     //   3787: imul
/*      */     //   3788: wide istore #351
/*      */     //   3792: aload_0
/*      */     //   3793: wide astore #349
/*      */     //   3797: wide iload #351
/*      */     //   3801: wide istore #350
/*      */     //   3805: wide aload #349
/*      */     //   3809: wide iload #350
/*      */     //   3813: iload #6
/*      */     //   3815: invokeinterface setInt : (II)V
/*      */     //   3820: iinc #23, 1
/*      */     //   3823: iload #23
/*      */     //   3825: iload #18
/*      */     //   3827: if_icmple -> 3325
/*      */     //   3830: goto -> 3833
/*      */     //   3833: iinc #20, 1
/*      */     //   3836: invokestatic get__sort$sincs : ()[I
/*      */     //   3839: iload #20
/*      */     //   3841: iaload
/*      */     //   3842: istore #21
/*      */     //   3844: iload #20
/*      */     //   3846: bipush #15
/*      */     //   3848: if_icmple -> 3312
/*      */     //   3851: goto -> 4407
/*      */     //   3854: invokestatic get__sort$sincs : ()[I
/*      */     //   3857: iload #20
/*      */     //   3859: iaload
/*      */     //   3860: istore #21
/*      */     //   3862: goto -> 4397
/*      */     //   3865: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   3868: iload #19
/*      */     //   3870: iload #21
/*      */     //   3872: iadd
/*      */     //   3873: istore #23
/*      */     //   3875: goto -> 4376
/*      */     //   3878: iload #23
/*      */     //   3880: iconst_4
/*      */     //   3881: imul
/*      */     //   3882: wide istore #347
/*      */     //   3886: aload_0
/*      */     //   3887: wide astore #345
/*      */     //   3891: wide iload #347
/*      */     //   3895: wide istore #346
/*      */     //   3899: wide aload #345
/*      */     //   3903: wide iload #346
/*      */     //   3907: invokeinterface getInt : (I)I
/*      */     //   3912: istore #6
/*      */     //   3914: iload #23
/*      */     //   3916: istore #22
/*      */     //   3918: goto -> 4007
/*      */     //   3921: iload #22
/*      */     //   3923: iconst_4
/*      */     //   3924: imul
/*      */     //   3925: wide istore #343
/*      */     //   3929: aload_0
/*      */     //   3930: wide astore #341
/*      */     //   3934: wide iload #343
/*      */     //   3938: wide istore #342
/*      */     //   3942: iload #22
/*      */     //   3944: iload #21
/*      */     //   3946: isub
/*      */     //   3947: iconst_4
/*      */     //   3948: imul
/*      */     //   3949: wide istore #338
/*      */     //   3953: aload_0
/*      */     //   3954: wide astore #336
/*      */     //   3958: wide iload #338
/*      */     //   3962: wide istore #337
/*      */     //   3966: wide aload #336
/*      */     //   3970: wide iload #337
/*      */     //   3974: invokeinterface getInt : (I)I
/*      */     //   3979: wide istore #335
/*      */     //   3983: wide aload #341
/*      */     //   3987: wide iload #342
/*      */     //   3991: wide iload #335
/*      */     //   3995: invokeinterface setInt : (II)V
/*      */     //   4000: iload #22
/*      */     //   4002: iload #21
/*      */     //   4004: isub
/*      */     //   4005: istore #22
/*      */     //   4007: iload #19
/*      */     //   4009: iload #21
/*      */     //   4011: iadd
/*      */     //   4012: iload #22
/*      */     //   4014: if_icmple -> 4020
/*      */     //   4017: goto -> 4337
/*      */     //   4020: iload #22
/*      */     //   4022: iload #21
/*      */     //   4024: isub
/*      */     //   4025: iconst_4
/*      */     //   4026: imul
/*      */     //   4027: wide istore #331
/*      */     //   4031: aload_0
/*      */     //   4032: wide astore #329
/*      */     //   4036: wide iload #331
/*      */     //   4040: wide istore #330
/*      */     //   4044: wide aload #329
/*      */     //   4048: wide iload #330
/*      */     //   4052: invokeinterface getInt : (I)I
/*      */     //   4057: bipush #8
/*      */     //   4059: imul
/*      */     //   4060: wide istore #326
/*      */     //   4064: aload #11
/*      */     //   4066: wide astore #324
/*      */     //   4070: iload #12
/*      */     //   4072: wide iload #326
/*      */     //   4076: iadd
/*      */     //   4077: wide istore #325
/*      */     //   4081: wide aload #324
/*      */     //   4085: wide iload #325
/*      */     //   4089: invokeinterface getDouble : (I)D
/*      */     //   4094: wide dstore #322
/*      */     //   4098: iload #6
/*      */     //   4100: bipush #8
/*      */     //   4102: imul
/*      */     //   4103: wide istore #320
/*      */     //   4107: aload #11
/*      */     //   4109: wide astore #318
/*      */     //   4113: iload #12
/*      */     //   4115: wide iload #320
/*      */     //   4119: iadd
/*      */     //   4120: wide istore #319
/*      */     //   4124: wide aload #318
/*      */     //   4128: wide iload #319
/*      */     //   4132: invokeinterface getDouble : (I)D
/*      */     //   4137: wide dstore #316
/*      */     //   4141: wide dload #322
/*      */     //   4145: wide dload #316
/*      */     //   4149: dcmpl
/*      */     //   4150: ifgt -> 3921
/*      */     //   4153: goto -> 4156
/*      */     //   4156: iload #22
/*      */     //   4158: iload #21
/*      */     //   4160: isub
/*      */     //   4161: iconst_4
/*      */     //   4162: imul
/*      */     //   4163: wide istore #313
/*      */     //   4167: aload_0
/*      */     //   4168: wide astore #311
/*      */     //   4172: wide iload #313
/*      */     //   4176: wide istore #312
/*      */     //   4180: wide aload #311
/*      */     //   4184: wide iload #312
/*      */     //   4188: invokeinterface getInt : (I)I
/*      */     //   4193: bipush #8
/*      */     //   4195: imul
/*      */     //   4196: wide istore #308
/*      */     //   4200: aload #11
/*      */     //   4202: wide astore #306
/*      */     //   4206: iload #12
/*      */     //   4208: wide iload #308
/*      */     //   4212: iadd
/*      */     //   4213: wide istore #307
/*      */     //   4217: wide aload #306
/*      */     //   4221: wide iload #307
/*      */     //   4225: invokeinterface getDouble : (I)D
/*      */     //   4230: wide dstore #304
/*      */     //   4234: iload #6
/*      */     //   4236: bipush #8
/*      */     //   4238: imul
/*      */     //   4239: wide istore #302
/*      */     //   4243: aload #11
/*      */     //   4245: wide astore #300
/*      */     //   4249: iload #12
/*      */     //   4251: wide iload #302
/*      */     //   4255: iadd
/*      */     //   4256: wide istore #301
/*      */     //   4260: wide aload #300
/*      */     //   4264: wide iload #301
/*      */     //   4268: invokeinterface getDouble : (I)D
/*      */     //   4273: wide dstore #298
/*      */     //   4277: wide dload #304
/*      */     //   4281: wide dload #298
/*      */     //   4285: dcmpl
/*      */     //   4286: ifeq -> 4292
/*      */     //   4289: goto -> 4337
/*      */     //   4292: iload #22
/*      */     //   4294: iload #21
/*      */     //   4296: isub
/*      */     //   4297: iconst_4
/*      */     //   4298: imul
/*      */     //   4299: wide istore #295
/*      */     //   4303: aload_0
/*      */     //   4304: wide astore #293
/*      */     //   4308: wide iload #295
/*      */     //   4312: wide istore #294
/*      */     //   4316: wide aload #293
/*      */     //   4320: wide iload #294
/*      */     //   4324: invokeinterface getInt : (I)I
/*      */     //   4329: iload #6
/*      */     //   4331: if_icmpgt -> 3921
/*      */     //   4334: goto -> 4337
/*      */     //   4337: iload #22
/*      */     //   4339: iconst_4
/*      */     //   4340: imul
/*      */     //   4341: wide istore #290
/*      */     //   4345: aload_0
/*      */     //   4346: wide astore #288
/*      */     //   4350: wide iload #290
/*      */     //   4354: wide istore #289
/*      */     //   4358: wide aload #288
/*      */     //   4362: wide iload #289
/*      */     //   4366: iload #6
/*      */     //   4368: invokeinterface setInt : (II)V
/*      */     //   4373: iinc #23, 1
/*      */     //   4376: iload #23
/*      */     //   4378: iload #18
/*      */     //   4380: if_icmple -> 3878
/*      */     //   4383: goto -> 4386
/*      */     //   4386: iinc #20, 1
/*      */     //   4389: invokestatic get__sort$sincs : ()[I
/*      */     //   4392: iload #20
/*      */     //   4394: iaload
/*      */     //   4395: istore #21
/*      */     //   4397: iload #20
/*      */     //   4399: bipush #15
/*      */     //   4401: if_icmple -> 3865
/*      */     //   4404: goto -> 4407
/*      */     //   4407: goto -> 6457
/*      */     //   4410: iload #4
/*      */     //   4412: ifne -> 4418
/*      */     //   4415: goto -> 5002
/*      */     //   4418: invokestatic get__sort$sincs : ()[I
/*      */     //   4421: iload #20
/*      */     //   4423: iaload
/*      */     //   4424: istore #21
/*      */     //   4426: goto -> 4992
/*      */     //   4429: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   4432: iload #19
/*      */     //   4434: iload #21
/*      */     //   4436: iadd
/*      */     //   4437: istore #23
/*      */     //   4439: goto -> 4971
/*      */     //   4442: iload #23
/*      */     //   4444: iconst_4
/*      */     //   4445: imul
/*      */     //   4446: wide istore #286
/*      */     //   4450: aload_0
/*      */     //   4451: wide astore #284
/*      */     //   4455: wide iload #286
/*      */     //   4459: wide istore #285
/*      */     //   4463: wide aload #284
/*      */     //   4467: wide iload #285
/*      */     //   4471: invokeinterface getInt : (I)I
/*      */     //   4476: istore #6
/*      */     //   4478: iload #23
/*      */     //   4480: istore #22
/*      */     //   4482: goto -> 4571
/*      */     //   4485: iload #22
/*      */     //   4487: iconst_4
/*      */     //   4488: imul
/*      */     //   4489: wide istore #282
/*      */     //   4493: aload_0
/*      */     //   4494: wide astore #280
/*      */     //   4498: wide iload #282
/*      */     //   4502: wide istore #281
/*      */     //   4506: iload #22
/*      */     //   4508: iload #21
/*      */     //   4510: isub
/*      */     //   4511: iconst_4
/*      */     //   4512: imul
/*      */     //   4513: wide istore #277
/*      */     //   4517: aload_0
/*      */     //   4518: wide astore #275
/*      */     //   4522: wide iload #277
/*      */     //   4526: wide istore #276
/*      */     //   4530: wide aload #275
/*      */     //   4534: wide iload #276
/*      */     //   4538: invokeinterface getInt : (I)I
/*      */     //   4543: wide istore #274
/*      */     //   4547: wide aload #280
/*      */     //   4551: wide iload #281
/*      */     //   4555: wide iload #274
/*      */     //   4559: invokeinterface setInt : (II)V
/*      */     //   4564: iload #22
/*      */     //   4566: iload #21
/*      */     //   4568: isub
/*      */     //   4569: istore #22
/*      */     //   4571: iload #19
/*      */     //   4573: iload #21
/*      */     //   4575: iadd
/*      */     //   4576: iload #22
/*      */     //   4578: if_icmple -> 4584
/*      */     //   4581: goto -> 4944
/*      */     //   4584: iload #6
/*      */     //   4586: bipush #16
/*      */     //   4588: imul
/*      */     //   4589: wide istore #271
/*      */     //   4593: aload #9
/*      */     //   4595: wide astore #269
/*      */     //   4599: iload #10
/*      */     //   4601: wide iload #271
/*      */     //   4605: iadd
/*      */     //   4606: wide istore #270
/*      */     //   4610: iload #22
/*      */     //   4612: iload #21
/*      */     //   4614: isub
/*      */     //   4615: iconst_4
/*      */     //   4616: imul
/*      */     //   4617: wide istore #266
/*      */     //   4621: aload_0
/*      */     //   4622: wide astore #264
/*      */     //   4626: wide iload #266
/*      */     //   4630: wide istore #265
/*      */     //   4634: wide aload #264
/*      */     //   4638: wide iload #265
/*      */     //   4642: invokeinterface getInt : (I)I
/*      */     //   4647: bipush #16
/*      */     //   4649: imul
/*      */     //   4650: wide istore #261
/*      */     //   4654: aload #9
/*      */     //   4656: wide astore #259
/*      */     //   4660: iload #10
/*      */     //   4662: wide iload #261
/*      */     //   4666: iadd
/*      */     //   4667: wide istore #260
/*      */     //   4671: wide aload #259
/*      */     //   4675: wide iload #260
/*      */     //   4679: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4684: bipush #16
/*      */     //   4686: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4691: wide aload #269
/*      */     //   4695: wide iload #270
/*      */     //   4699: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4704: bipush #16
/*      */     //   4706: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4711: iconst_0
/*      */     //   4712: invokestatic ccmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
/*      */     //   4715: iflt -> 4485
/*      */     //   4718: goto -> 4721
/*      */     //   4721: iload #22
/*      */     //   4723: iload #21
/*      */     //   4725: isub
/*      */     //   4726: iconst_4
/*      */     //   4727: imul
/*      */     //   4728: istore #255
/*      */     //   4730: aload_0
/*      */     //   4731: astore #253
/*      */     //   4733: iload #255
/*      */     //   4735: istore #254
/*      */     //   4737: aload #253
/*      */     //   4739: iload #254
/*      */     //   4741: invokeinterface getInt : (I)I
/*      */     //   4746: bipush #16
/*      */     //   4748: imul
/*      */     //   4749: istore #250
/*      */     //   4751: aload #9
/*      */     //   4753: astore #248
/*      */     //   4755: iload #10
/*      */     //   4757: iload #250
/*      */     //   4759: iadd
/*      */     //   4760: istore #249
/*      */     //   4762: aload #248
/*      */     //   4764: iload #249
/*      */     //   4766: invokeinterface getDouble : (I)D
/*      */     //   4771: dstore #246
/*      */     //   4773: iload #6
/*      */     //   4775: bipush #16
/*      */     //   4777: imul
/*      */     //   4778: istore #244
/*      */     //   4780: aload #9
/*      */     //   4782: astore #242
/*      */     //   4784: iload #10
/*      */     //   4786: iload #244
/*      */     //   4788: iadd
/*      */     //   4789: istore #243
/*      */     //   4791: aload #242
/*      */     //   4793: iload #243
/*      */     //   4795: invokeinterface getDouble : (I)D
/*      */     //   4800: dstore #240
/*      */     //   4802: dload #246
/*      */     //   4804: dload #240
/*      */     //   4806: dcmpl
/*      */     //   4807: ifeq -> 4813
/*      */     //   4810: goto -> 4944
/*      */     //   4813: iload #22
/*      */     //   4815: iload #21
/*      */     //   4817: isub
/*      */     //   4818: iconst_4
/*      */     //   4819: imul
/*      */     //   4820: istore #237
/*      */     //   4822: aload_0
/*      */     //   4823: astore #235
/*      */     //   4825: iload #237
/*      */     //   4827: istore #236
/*      */     //   4829: aload #235
/*      */     //   4831: iload #236
/*      */     //   4833: invokeinterface getInt : (I)I
/*      */     //   4838: bipush #16
/*      */     //   4840: imul
/*      */     //   4841: istore #232
/*      */     //   4843: aload #9
/*      */     //   4845: astore #230
/*      */     //   4847: iload #10
/*      */     //   4849: iload #232
/*      */     //   4851: iadd
/*      */     //   4852: istore #231
/*      */     //   4854: aload #230
/*      */     //   4856: iload #231
/*      */     //   4858: bipush #8
/*      */     //   4860: iadd
/*      */     //   4861: invokeinterface getDouble : (I)D
/*      */     //   4866: dstore #228
/*      */     //   4868: iload #6
/*      */     //   4870: bipush #16
/*      */     //   4872: imul
/*      */     //   4873: istore #226
/*      */     //   4875: aload #9
/*      */     //   4877: astore #224
/*      */     //   4879: iload #10
/*      */     //   4881: iload #226
/*      */     //   4883: iadd
/*      */     //   4884: istore #225
/*      */     //   4886: aload #224
/*      */     //   4888: iload #225
/*      */     //   4890: bipush #8
/*      */     //   4892: iadd
/*      */     //   4893: invokeinterface getDouble : (I)D
/*      */     //   4898: dstore #222
/*      */     //   4900: dload #228
/*      */     //   4902: dload #222
/*      */     //   4904: dcmpl
/*      */     //   4905: ifeq -> 4911
/*      */     //   4908: goto -> 4944
/*      */     //   4911: iload #22
/*      */     //   4913: iload #21
/*      */     //   4915: isub
/*      */     //   4916: iconst_4
/*      */     //   4917: imul
/*      */     //   4918: istore #219
/*      */     //   4920: aload_0
/*      */     //   4921: astore #217
/*      */     //   4923: iload #219
/*      */     //   4925: istore #218
/*      */     //   4927: aload #217
/*      */     //   4929: iload #218
/*      */     //   4931: invokeinterface getInt : (I)I
/*      */     //   4936: iload #6
/*      */     //   4938: if_icmpgt -> 4485
/*      */     //   4941: goto -> 4944
/*      */     //   4944: iload #22
/*      */     //   4946: iconst_4
/*      */     //   4947: imul
/*      */     //   4948: istore #214
/*      */     //   4950: aload_0
/*      */     //   4951: astore #212
/*      */     //   4953: iload #214
/*      */     //   4955: istore #213
/*      */     //   4957: aload #212
/*      */     //   4959: iload #213
/*      */     //   4961: iload #6
/*      */     //   4963: invokeinterface setInt : (II)V
/*      */     //   4968: iinc #23, 1
/*      */     //   4971: iload #23
/*      */     //   4973: iload #18
/*      */     //   4975: if_icmple -> 4442
/*      */     //   4978: goto -> 4981
/*      */     //   4981: iinc #20, 1
/*      */     //   4984: invokestatic get__sort$sincs : ()[I
/*      */     //   4987: iload #20
/*      */     //   4989: iaload
/*      */     //   4990: istore #21
/*      */     //   4992: iload #20
/*      */     //   4994: bipush #15
/*      */     //   4996: if_icmple -> 4429
/*      */     //   4999: goto -> 5510
/*      */     //   5002: invokestatic get__sort$sincs : ()[I
/*      */     //   5005: iload #20
/*      */     //   5007: iaload
/*      */     //   5008: istore #21
/*      */     //   5010: goto -> 5500
/*      */     //   5013: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5016: iload #19
/*      */     //   5018: iload #21
/*      */     //   5020: iadd
/*      */     //   5021: istore #23
/*      */     //   5023: goto -> 5479
/*      */     //   5026: iload #23
/*      */     //   5028: iconst_4
/*      */     //   5029: imul
/*      */     //   5030: istore #210
/*      */     //   5032: aload_0
/*      */     //   5033: astore #208
/*      */     //   5035: iload #210
/*      */     //   5037: istore #209
/*      */     //   5039: aload #208
/*      */     //   5041: iload #209
/*      */     //   5043: invokeinterface getInt : (I)I
/*      */     //   5048: istore #6
/*      */     //   5050: iload #23
/*      */     //   5052: istore #22
/*      */     //   5054: goto -> 5115
/*      */     //   5057: iload #22
/*      */     //   5059: iconst_4
/*      */     //   5060: imul
/*      */     //   5061: istore #206
/*      */     //   5063: aload_0
/*      */     //   5064: astore #204
/*      */     //   5066: iload #206
/*      */     //   5068: istore #205
/*      */     //   5070: iload #22
/*      */     //   5072: iload #21
/*      */     //   5074: isub
/*      */     //   5075: iconst_4
/*      */     //   5076: imul
/*      */     //   5077: istore #201
/*      */     //   5079: aload_0
/*      */     //   5080: astore #199
/*      */     //   5082: iload #201
/*      */     //   5084: istore #200
/*      */     //   5086: aload #199
/*      */     //   5088: iload #200
/*      */     //   5090: invokeinterface getInt : (I)I
/*      */     //   5095: istore #198
/*      */     //   5097: aload #204
/*      */     //   5099: iload #205
/*      */     //   5101: iload #198
/*      */     //   5103: invokeinterface setInt : (II)V
/*      */     //   5108: iload #22
/*      */     //   5110: iload #21
/*      */     //   5112: isub
/*      */     //   5113: istore #22
/*      */     //   5115: iload #19
/*      */     //   5117: iload #21
/*      */     //   5119: iadd
/*      */     //   5120: iload #22
/*      */     //   5122: if_icmple -> 5128
/*      */     //   5125: goto -> 5452
/*      */     //   5128: iload #6
/*      */     //   5130: bipush #16
/*      */     //   5132: imul
/*      */     //   5133: istore #195
/*      */     //   5135: aload #9
/*      */     //   5137: astore #193
/*      */     //   5139: iload #10
/*      */     //   5141: iload #195
/*      */     //   5143: iadd
/*      */     //   5144: istore #194
/*      */     //   5146: iload #22
/*      */     //   5148: iload #21
/*      */     //   5150: isub
/*      */     //   5151: iconst_4
/*      */     //   5152: imul
/*      */     //   5153: istore #190
/*      */     //   5155: aload_0
/*      */     //   5156: astore #188
/*      */     //   5158: iload #190
/*      */     //   5160: istore #189
/*      */     //   5162: aload #188
/*      */     //   5164: iload #189
/*      */     //   5166: invokeinterface getInt : (I)I
/*      */     //   5171: bipush #16
/*      */     //   5173: imul
/*      */     //   5174: istore #185
/*      */     //   5176: aload #9
/*      */     //   5178: astore #183
/*      */     //   5180: iload #10
/*      */     //   5182: iload #185
/*      */     //   5184: iadd
/*      */     //   5185: istore #184
/*      */     //   5187: aload #183
/*      */     //   5189: iload #184
/*      */     //   5191: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5196: bipush #16
/*      */     //   5198: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5203: aload #193
/*      */     //   5205: iload #194
/*      */     //   5207: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5212: bipush #16
/*      */     //   5214: invokeinterface copyOf : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5219: iconst_0
/*      */     //   5220: invokestatic ccmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)I
/*      */     //   5223: ifgt -> 5057
/*      */     //   5226: goto -> 5229
/*      */     //   5229: iload #22
/*      */     //   5231: iload #21
/*      */     //   5233: isub
/*      */     //   5234: iconst_4
/*      */     //   5235: imul
/*      */     //   5236: istore #179
/*      */     //   5238: aload_0
/*      */     //   5239: astore #177
/*      */     //   5241: iload #179
/*      */     //   5243: istore #178
/*      */     //   5245: aload #177
/*      */     //   5247: iload #178
/*      */     //   5249: invokeinterface getInt : (I)I
/*      */     //   5254: bipush #16
/*      */     //   5256: imul
/*      */     //   5257: istore #174
/*      */     //   5259: aload #9
/*      */     //   5261: astore #172
/*      */     //   5263: iload #10
/*      */     //   5265: iload #174
/*      */     //   5267: iadd
/*      */     //   5268: istore #173
/*      */     //   5270: aload #172
/*      */     //   5272: iload #173
/*      */     //   5274: invokeinterface getDouble : (I)D
/*      */     //   5279: dstore #170
/*      */     //   5281: iload #6
/*      */     //   5283: bipush #16
/*      */     //   5285: imul
/*      */     //   5286: istore #168
/*      */     //   5288: aload #9
/*      */     //   5290: astore #166
/*      */     //   5292: iload #10
/*      */     //   5294: iload #168
/*      */     //   5296: iadd
/*      */     //   5297: istore #167
/*      */     //   5299: aload #166
/*      */     //   5301: iload #167
/*      */     //   5303: invokeinterface getDouble : (I)D
/*      */     //   5308: dstore #164
/*      */     //   5310: dload #170
/*      */     //   5312: dload #164
/*      */     //   5314: dcmpl
/*      */     //   5315: ifeq -> 5321
/*      */     //   5318: goto -> 5452
/*      */     //   5321: iload #22
/*      */     //   5323: iload #21
/*      */     //   5325: isub
/*      */     //   5326: iconst_4
/*      */     //   5327: imul
/*      */     //   5328: istore #161
/*      */     //   5330: aload_0
/*      */     //   5331: astore #159
/*      */     //   5333: iload #161
/*      */     //   5335: istore #160
/*      */     //   5337: aload #159
/*      */     //   5339: iload #160
/*      */     //   5341: invokeinterface getInt : (I)I
/*      */     //   5346: bipush #16
/*      */     //   5348: imul
/*      */     //   5349: istore #156
/*      */     //   5351: aload #9
/*      */     //   5353: astore #154
/*      */     //   5355: iload #10
/*      */     //   5357: iload #156
/*      */     //   5359: iadd
/*      */     //   5360: istore #155
/*      */     //   5362: aload #154
/*      */     //   5364: iload #155
/*      */     //   5366: bipush #8
/*      */     //   5368: iadd
/*      */     //   5369: invokeinterface getDouble : (I)D
/*      */     //   5374: dstore #152
/*      */     //   5376: iload #6
/*      */     //   5378: bipush #16
/*      */     //   5380: imul
/*      */     //   5381: istore #150
/*      */     //   5383: aload #9
/*      */     //   5385: astore #148
/*      */     //   5387: iload #10
/*      */     //   5389: iload #150
/*      */     //   5391: iadd
/*      */     //   5392: istore #149
/*      */     //   5394: aload #148
/*      */     //   5396: iload #149
/*      */     //   5398: bipush #8
/*      */     //   5400: iadd
/*      */     //   5401: invokeinterface getDouble : (I)D
/*      */     //   5406: dstore #146
/*      */     //   5408: dload #152
/*      */     //   5410: dload #146
/*      */     //   5412: dcmpl
/*      */     //   5413: ifeq -> 5419
/*      */     //   5416: goto -> 5452
/*      */     //   5419: iload #22
/*      */     //   5421: iload #21
/*      */     //   5423: isub
/*      */     //   5424: iconst_4
/*      */     //   5425: imul
/*      */     //   5426: istore #143
/*      */     //   5428: aload_0
/*      */     //   5429: astore #141
/*      */     //   5431: iload #143
/*      */     //   5433: istore #142
/*      */     //   5435: aload #141
/*      */     //   5437: iload #142
/*      */     //   5439: invokeinterface getInt : (I)I
/*      */     //   5444: iload #6
/*      */     //   5446: if_icmpgt -> 5057
/*      */     //   5449: goto -> 5452
/*      */     //   5452: iload #22
/*      */     //   5454: iconst_4
/*      */     //   5455: imul
/*      */     //   5456: istore #138
/*      */     //   5458: aload_0
/*      */     //   5459: astore #136
/*      */     //   5461: iload #138
/*      */     //   5463: istore #137
/*      */     //   5465: aload #136
/*      */     //   5467: iload #137
/*      */     //   5469: iload #6
/*      */     //   5471: invokeinterface setInt : (II)V
/*      */     //   5476: iinc #23, 1
/*      */     //   5479: iload #23
/*      */     //   5481: iload #18
/*      */     //   5483: if_icmple -> 5026
/*      */     //   5486: goto -> 5489
/*      */     //   5489: iinc #20, 1
/*      */     //   5492: invokestatic get__sort$sincs : ()[I
/*      */     //   5495: iload #20
/*      */     //   5497: iaload
/*      */     //   5498: istore #21
/*      */     //   5500: iload #20
/*      */     //   5502: bipush #15
/*      */     //   5504: if_icmple -> 5013
/*      */     //   5507: goto -> 5510
/*      */     //   5510: goto -> 6457
/*      */     //   5513: iload #4
/*      */     //   5515: ifne -> 5521
/*      */     //   5518: goto -> 5871
/*      */     //   5521: invokestatic get__sort$sincs : ()[I
/*      */     //   5524: iload #20
/*      */     //   5526: iaload
/*      */     //   5527: istore #21
/*      */     //   5529: goto -> 5861
/*      */     //   5532: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5535: iload #19
/*      */     //   5537: iload #21
/*      */     //   5539: iadd
/*      */     //   5540: istore #23
/*      */     //   5542: goto -> 5840
/*      */     //   5545: iload #23
/*      */     //   5547: iconst_4
/*      */     //   5548: imul
/*      */     //   5549: istore #134
/*      */     //   5551: aload_0
/*      */     //   5552: astore #132
/*      */     //   5554: iload #134
/*      */     //   5556: istore #133
/*      */     //   5558: aload #132
/*      */     //   5560: iload #133
/*      */     //   5562: invokeinterface getInt : (I)I
/*      */     //   5567: istore #6
/*      */     //   5569: iload #23
/*      */     //   5571: istore #22
/*      */     //   5573: goto -> 5634
/*      */     //   5576: iload #22
/*      */     //   5578: iconst_4
/*      */     //   5579: imul
/*      */     //   5580: istore #130
/*      */     //   5582: aload_0
/*      */     //   5583: astore #128
/*      */     //   5585: iload #130
/*      */     //   5587: istore #129
/*      */     //   5589: iload #22
/*      */     //   5591: iload #21
/*      */     //   5593: isub
/*      */     //   5594: iconst_4
/*      */     //   5595: imul
/*      */     //   5596: istore #125
/*      */     //   5598: aload_0
/*      */     //   5599: astore #123
/*      */     //   5601: iload #125
/*      */     //   5603: istore #124
/*      */     //   5605: aload #123
/*      */     //   5607: iload #124
/*      */     //   5609: invokeinterface getInt : (I)I
/*      */     //   5614: istore #122
/*      */     //   5616: aload #128
/*      */     //   5618: iload #129
/*      */     //   5620: iload #122
/*      */     //   5622: invokeinterface setInt : (II)V
/*      */     //   5627: iload #22
/*      */     //   5629: iload #21
/*      */     //   5631: isub
/*      */     //   5632: istore #22
/*      */     //   5634: iload #19
/*      */     //   5636: iload #21
/*      */     //   5638: iadd
/*      */     //   5639: iload #22
/*      */     //   5641: if_icmple -> 5647
/*      */     //   5644: goto -> 5813
/*      */     //   5647: iload #6
/*      */     //   5649: iconst_4
/*      */     //   5650: imul
/*      */     //   5651: istore #119
/*      */     //   5653: aload #7
/*      */     //   5655: astore #117
/*      */     //   5657: iload #8
/*      */     //   5659: iload #119
/*      */     //   5661: iadd
/*      */     //   5662: istore #118
/*      */     //   5664: aload #117
/*      */     //   5666: iload #118
/*      */     //   5668: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5673: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   5678: checkcast org/renjin/sexp/SEXP
/*      */     //   5681: astore #116
/*      */     //   5683: iload #22
/*      */     //   5685: iload #21
/*      */     //   5687: isub
/*      */     //   5688: iconst_4
/*      */     //   5689: imul
/*      */     //   5690: istore #113
/*      */     //   5692: aload_0
/*      */     //   5693: astore #111
/*      */     //   5695: iload #113
/*      */     //   5697: istore #112
/*      */     //   5699: aload #111
/*      */     //   5701: iload #112
/*      */     //   5703: invokeinterface getInt : (I)I
/*      */     //   5708: iconst_4
/*      */     //   5709: imul
/*      */     //   5710: istore #108
/*      */     //   5712: aload #7
/*      */     //   5714: astore #106
/*      */     //   5716: iload #8
/*      */     //   5718: iload #108
/*      */     //   5720: iadd
/*      */     //   5721: istore #107
/*      */     //   5723: aload #106
/*      */     //   5725: iload #107
/*      */     //   5727: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5732: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   5737: checkcast org/renjin/sexp/SEXP
/*      */     //   5740: aload #116
/*      */     //   5742: invokestatic Rf_Scollate : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
/*      */     //   5745: istore #24
/*      */     //   5747: iload #24
/*      */     //   5749: iflt -> 5796
/*      */     //   5752: goto -> 5755
/*      */     //   5755: iload #24
/*      */     //   5757: ifeq -> 5763
/*      */     //   5760: goto -> 5802
/*      */     //   5763: iload #22
/*      */     //   5765: iload #21
/*      */     //   5767: isub
/*      */     //   5768: iconst_4
/*      */     //   5769: imul
/*      */     //   5770: istore #101
/*      */     //   5772: aload_0
/*      */     //   5773: astore #99
/*      */     //   5775: iload #101
/*      */     //   5777: istore #100
/*      */     //   5779: aload #99
/*      */     //   5781: iload #100
/*      */     //   5783: invokeinterface getInt : (I)I
/*      */     //   5788: iload #6
/*      */     //   5790: if_icmpgt -> 5796
/*      */     //   5793: goto -> 5802
/*      */     //   5796: iconst_1
/*      */     //   5797: istore #104
/*      */     //   5799: goto -> 5805
/*      */     //   5802: iconst_0
/*      */     //   5803: istore #104
/*      */     //   5805: iload #104
/*      */     //   5807: ifne -> 5576
/*      */     //   5810: goto -> 5813
/*      */     //   5813: iload #22
/*      */     //   5815: iconst_4
/*      */     //   5816: imul
/*      */     //   5817: istore #96
/*      */     //   5819: aload_0
/*      */     //   5820: astore #94
/*      */     //   5822: iload #96
/*      */     //   5824: istore #95
/*      */     //   5826: aload #94
/*      */     //   5828: iload #95
/*      */     //   5830: iload #6
/*      */     //   5832: invokeinterface setInt : (II)V
/*      */     //   5837: iinc #23, 1
/*      */     //   5840: iload #23
/*      */     //   5842: iload #18
/*      */     //   5844: if_icmple -> 5545
/*      */     //   5847: goto -> 5850
/*      */     //   5850: iinc #20, 1
/*      */     //   5853: invokestatic get__sort$sincs : ()[I
/*      */     //   5856: iload #20
/*      */     //   5858: iaload
/*      */     //   5859: istore #21
/*      */     //   5861: iload #20
/*      */     //   5863: bipush #15
/*      */     //   5865: if_icmple -> 5532
/*      */     //   5868: goto -> 6221
/*      */     //   5871: invokestatic get__sort$sincs : ()[I
/*      */     //   5874: iload #20
/*      */     //   5876: iaload
/*      */     //   5877: istore #21
/*      */     //   5879: goto -> 6211
/*      */     //   5882: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   5885: iload #19
/*      */     //   5887: iload #21
/*      */     //   5889: iadd
/*      */     //   5890: istore #23
/*      */     //   5892: goto -> 6190
/*      */     //   5895: iload #23
/*      */     //   5897: iconst_4
/*      */     //   5898: imul
/*      */     //   5899: istore #92
/*      */     //   5901: aload_0
/*      */     //   5902: astore #90
/*      */     //   5904: iload #92
/*      */     //   5906: istore #91
/*      */     //   5908: aload #90
/*      */     //   5910: iload #91
/*      */     //   5912: invokeinterface getInt : (I)I
/*      */     //   5917: istore #6
/*      */     //   5919: iload #23
/*      */     //   5921: istore #22
/*      */     //   5923: goto -> 5984
/*      */     //   5926: iload #22
/*      */     //   5928: iconst_4
/*      */     //   5929: imul
/*      */     //   5930: istore #88
/*      */     //   5932: aload_0
/*      */     //   5933: astore #86
/*      */     //   5935: iload #88
/*      */     //   5937: istore #87
/*      */     //   5939: iload #22
/*      */     //   5941: iload #21
/*      */     //   5943: isub
/*      */     //   5944: iconst_4
/*      */     //   5945: imul
/*      */     //   5946: istore #83
/*      */     //   5948: aload_0
/*      */     //   5949: astore #81
/*      */     //   5951: iload #83
/*      */     //   5953: istore #82
/*      */     //   5955: aload #81
/*      */     //   5957: iload #82
/*      */     //   5959: invokeinterface getInt : (I)I
/*      */     //   5964: istore #80
/*      */     //   5966: aload #86
/*      */     //   5968: iload #87
/*      */     //   5970: iload #80
/*      */     //   5972: invokeinterface setInt : (II)V
/*      */     //   5977: iload #22
/*      */     //   5979: iload #21
/*      */     //   5981: isub
/*      */     //   5982: istore #22
/*      */     //   5984: iload #19
/*      */     //   5986: iload #21
/*      */     //   5988: iadd
/*      */     //   5989: iload #22
/*      */     //   5991: if_icmple -> 5997
/*      */     //   5994: goto -> 6163
/*      */     //   5997: iload #6
/*      */     //   5999: iconst_4
/*      */     //   6000: imul
/*      */     //   6001: istore #77
/*      */     //   6003: aload #7
/*      */     //   6005: astore #75
/*      */     //   6007: iload #8
/*      */     //   6009: iload #77
/*      */     //   6011: iadd
/*      */     //   6012: istore #76
/*      */     //   6014: aload #75
/*      */     //   6016: iload #76
/*      */     //   6018: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6023: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   6028: checkcast org/renjin/sexp/SEXP
/*      */     //   6031: astore #74
/*      */     //   6033: iload #22
/*      */     //   6035: iload #21
/*      */     //   6037: isub
/*      */     //   6038: iconst_4
/*      */     //   6039: imul
/*      */     //   6040: istore #71
/*      */     //   6042: aload_0
/*      */     //   6043: astore #69
/*      */     //   6045: iload #71
/*      */     //   6047: istore #70
/*      */     //   6049: aload #69
/*      */     //   6051: iload #70
/*      */     //   6053: invokeinterface getInt : (I)I
/*      */     //   6058: iconst_4
/*      */     //   6059: imul
/*      */     //   6060: istore #66
/*      */     //   6062: aload #7
/*      */     //   6064: astore #64
/*      */     //   6066: iload #8
/*      */     //   6068: iload #66
/*      */     //   6070: iadd
/*      */     //   6071: istore #65
/*      */     //   6073: aload #64
/*      */     //   6075: iload #65
/*      */     //   6077: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6082: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   6087: checkcast org/renjin/sexp/SEXP
/*      */     //   6090: aload #74
/*      */     //   6092: invokestatic Rf_Scollate : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)I
/*      */     //   6095: istore #24
/*      */     //   6097: iload #24
/*      */     //   6099: ifgt -> 6146
/*      */     //   6102: goto -> 6105
/*      */     //   6105: iload #24
/*      */     //   6107: ifeq -> 6113
/*      */     //   6110: goto -> 6152
/*      */     //   6113: iload #22
/*      */     //   6115: iload #21
/*      */     //   6117: isub
/*      */     //   6118: iconst_4
/*      */     //   6119: imul
/*      */     //   6120: istore #59
/*      */     //   6122: aload_0
/*      */     //   6123: astore #57
/*      */     //   6125: iload #59
/*      */     //   6127: istore #58
/*      */     //   6129: aload #57
/*      */     //   6131: iload #58
/*      */     //   6133: invokeinterface getInt : (I)I
/*      */     //   6138: iload #6
/*      */     //   6140: if_icmpgt -> 6146
/*      */     //   6143: goto -> 6152
/*      */     //   6146: iconst_1
/*      */     //   6147: istore #62
/*      */     //   6149: goto -> 6155
/*      */     //   6152: iconst_0
/*      */     //   6153: istore #62
/*      */     //   6155: iload #62
/*      */     //   6157: ifne -> 5926
/*      */     //   6160: goto -> 6163
/*      */     //   6163: iload #22
/*      */     //   6165: iconst_4
/*      */     //   6166: imul
/*      */     //   6167: istore #54
/*      */     //   6169: aload_0
/*      */     //   6170: astore #52
/*      */     //   6172: iload #54
/*      */     //   6174: istore #53
/*      */     //   6176: aload #52
/*      */     //   6178: iload #53
/*      */     //   6180: iload #6
/*      */     //   6182: invokeinterface setInt : (II)V
/*      */     //   6187: iinc #23, 1
/*      */     //   6190: iload #23
/*      */     //   6192: iload #18
/*      */     //   6194: if_icmple -> 5895
/*      */     //   6197: goto -> 6200
/*      */     //   6200: iinc #20, 1
/*      */     //   6203: invokestatic get__sort$sincs : ()[I
/*      */     //   6206: iload #20
/*      */     //   6208: iaload
/*      */     //   6209: istore #21
/*      */     //   6211: iload #20
/*      */     //   6213: bipush #15
/*      */     //   6215: if_icmple -> 5882
/*      */     //   6218: goto -> 6221
/*      */     //   6221: goto -> 6457
/*      */     //   6224: invokestatic get__sort$sincs : ()[I
/*      */     //   6227: iload #20
/*      */     //   6229: iaload
/*      */     //   6230: istore #21
/*      */     //   6232: goto -> 6447
/*      */     //   6235: invokestatic R_CheckUserInterrupt : ()V
/*      */     //   6238: iload #19
/*      */     //   6240: iload #21
/*      */     //   6242: iadd
/*      */     //   6243: istore #23
/*      */     //   6245: goto -> 6426
/*      */     //   6248: iload #23
/*      */     //   6250: iconst_4
/*      */     //   6251: imul
/*      */     //   6252: istore #50
/*      */     //   6254: aload_0
/*      */     //   6255: astore #48
/*      */     //   6257: iload #50
/*      */     //   6259: istore #49
/*      */     //   6261: aload #48
/*      */     //   6263: iload #49
/*      */     //   6265: invokeinterface getInt : (I)I
/*      */     //   6270: istore #6
/*      */     //   6272: iload #23
/*      */     //   6274: istore #22
/*      */     //   6276: goto -> 6337
/*      */     //   6279: iload #22
/*      */     //   6281: iconst_4
/*      */     //   6282: imul
/*      */     //   6283: istore #46
/*      */     //   6285: aload_0
/*      */     //   6286: astore #44
/*      */     //   6288: iload #46
/*      */     //   6290: istore #45
/*      */     //   6292: iload #22
/*      */     //   6294: iload #21
/*      */     //   6296: isub
/*      */     //   6297: iconst_4
/*      */     //   6298: imul
/*      */     //   6299: istore #41
/*      */     //   6301: aload_0
/*      */     //   6302: astore #39
/*      */     //   6304: iload #41
/*      */     //   6306: istore #40
/*      */     //   6308: aload #39
/*      */     //   6310: iload #40
/*      */     //   6312: invokeinterface getInt : (I)I
/*      */     //   6317: istore #38
/*      */     //   6319: aload #44
/*      */     //   6321: iload #45
/*      */     //   6323: iload #38
/*      */     //   6325: invokeinterface setInt : (II)V
/*      */     //   6330: iload #22
/*      */     //   6332: iload #21
/*      */     //   6334: isub
/*      */     //   6335: istore #22
/*      */     //   6337: iload #19
/*      */     //   6339: iload #21
/*      */     //   6341: iadd
/*      */     //   6342: iload #22
/*      */     //   6344: if_icmple -> 6350
/*      */     //   6347: goto -> 6399
/*      */     //   6350: iload_3
/*      */     //   6351: iload #4
/*      */     //   6353: ixor
/*      */     //   6354: istore #36
/*      */     //   6356: iload #22
/*      */     //   6358: iload #21
/*      */     //   6360: isub
/*      */     //   6361: iconst_4
/*      */     //   6362: imul
/*      */     //   6363: istore #33
/*      */     //   6365: aload_0
/*      */     //   6366: astore #31
/*      */     //   6368: iload #33
/*      */     //   6370: istore #32
/*      */     //   6372: aload #31
/*      */     //   6374: iload #32
/*      */     //   6376: invokeinterface getInt : (I)I
/*      */     //   6381: iload #6
/*      */     //   6383: aload_2
/*      */     //   6384: iload #36
/*      */     //   6386: iload #4
/*      */     //   6388: aload #5
/*      */     //   6390: invokestatic greater : (IILorg/renjin/sexp/SEXP;IILorg/renjin/sexp/SEXP;)I
/*      */     //   6393: ifne -> 6279
/*      */     //   6396: goto -> 6399
/*      */     //   6399: iload #22
/*      */     //   6401: iconst_4
/*      */     //   6402: imul
/*      */     //   6403: istore #27
/*      */     //   6405: aload_0
/*      */     //   6406: astore #25
/*      */     //   6408: iload #27
/*      */     //   6410: istore #26
/*      */     //   6412: aload #25
/*      */     //   6414: iload #26
/*      */     //   6416: iload #6
/*      */     //   6418: invokeinterface setInt : (II)V
/*      */     //   6423: iinc #23, 1
/*      */     //   6426: iload #23
/*      */     //   6428: iload #18
/*      */     //   6430: if_icmple -> 6248
/*      */     //   6433: goto -> 6436
/*      */     //   6436: iinc #20, 1
/*      */     //   6439: invokestatic get__sort$sincs : ()[I
/*      */     //   6442: iload #20
/*      */     //   6444: iaload
/*      */     //   6445: istore #21
/*      */     //   6447: iload #20
/*      */     //   6449: bipush #15
/*      */     //   6451: if_icmple -> 6235
/*      */     //   6454: goto -> 6457
/*      */     //   6457: aload #16
/*      */     //   6459: iload #17
/*      */     //   6461: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6466: invokeinterface isNull : ()Z
/*      */     //   6471: ifne -> 6486
/*      */     //   6474: goto -> 6477
/*      */     //   6477: iconst_0
/*      */     //   6478: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6481: astore #16
/*      */     //   6483: iconst_0
/*      */     //   6484: istore #17
/*      */     //   6486: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1102	-> 66
/*      */     //   #1103	-> 74
/*      */     //   #1104	-> 86
/*      */     //   #1105	-> 95
/*      */     //   #1106	-> 104
/*      */     //   #1107	-> 113
/*      */     //   #1110	-> 122
/*      */     //   #1111	-> 133
/*      */     //   #1114	-> 188
/*      */     //   #1117	-> 200
/*      */     //   #1120	-> 212
/*      */     //   #1123	-> 226
/*      */     //   #1127	-> 235
/*      */     //   #1129	-> 246
/*      */     //   #1130	-> 257
/*      */     //   #1133	-> 312
/*      */     //   #1133	-> 318
/*      */     //   #1133	-> 435
/*      */     //   #1136	-> 447
/*      */     //   #1136	-> 453
/*      */     //   #1136	-> 555
/*      */     //   #1139	-> 567
/*      */     //   #1139	-> 573
/*      */     //   #1139	-> 698
/*      */     //   #1142	-> 710
/*      */     //   #1142	-> 716
/*      */     //   #1142	-> 789
/*      */     //   #1142	-> 840
/*      */     //   #1142	-> 848
/*      */     //   #1142	-> 853
/*      */     //   #1142	-> 873
/*      */     //   #1145	-> 885
/*      */     //   #1147	-> 903
/*      */     //   #1147	-> 909
/*      */     //   #1147	-> 955
/*      */     //   #1149	-> 964
/*      */     //   #1150	-> 972
/*      */     //   #1156	-> 1028
/*      */     //   #1156	-> 1035
/*      */     //   #1156	-> 1041
/*      */     //   #1156	-> 1139
/*      */     //   #1157	-> 1148
/*      */     //   #1157	-> 1154
/*      */     //   #1157	-> 1157
/*      */     //   #1159	-> 1170
/*      */     //   #1159	-> 1181
/*      */     //   #1159	-> 1194
/*      */     //   #1159	-> 1237
/*      */     //   #1159	-> 1323
/*      */     //   #1159	-> 1336
/*      */     //   #1159	-> 1469
/*      */     //   #1159	-> 1602
/*      */     //   #1159	-> 1647
/*      */     //   #1159	-> 1686
/*      */     //   #1159	-> 1696
/*      */     //   #1159	-> 1707
/*      */     //   #1161	-> 1717
/*      */     //   #1162	-> 1728
/*      */     //   #1165	-> 1740
/*      */     //   #1165	-> 1747
/*      */     //   #1165	-> 1757
/*      */     //   #1171	-> 1764
/*      */     //   #1171	-> 1770
/*      */     //   #1171	-> 1773
/*      */     //   #1173	-> 1808
/*      */     //   #1173	-> 1818
/*      */     //   #1176	-> 1829
/*      */     //   #1176	-> 1840
/*      */     //   #1176	-> 1853
/*      */     //   #1176	-> 1896
/*      */     //   #1176	-> 1982
/*      */     //   #1176	-> 1995
/*      */     //   #1176	-> 2060
/*      */     //   #1176	-> 2099
/*      */     //   #1176	-> 2109
/*      */     //   #1176	-> 2120
/*      */     //   #1179	-> 2133
/*      */     //   #1182	-> 2188
/*      */     //   #1184	-> 2196
/*      */     //   #1184	-> 2207
/*      */     //   #1184	-> 2220
/*      */     //   #1184	-> 2263
/*      */     //   #1184	-> 2349
/*      */     //   #1184	-> 2362
/*      */     //   #1184	-> 2495
/*      */     //   #1184	-> 2628
/*      */     //   #1184	-> 2673
/*      */     //   #1184	-> 2712
/*      */     //   #1184	-> 2722
/*      */     //   #1184	-> 2733
/*      */     //   #1188	-> 2743
/*      */     //   #1188	-> 2754
/*      */     //   #1188	-> 2767
/*      */     //   #1188	-> 2810
/*      */     //   #1188	-> 2896
/*      */     //   #1188	-> 2909
/*      */     //   #1188	-> 3042
/*      */     //   #1188	-> 3175
/*      */     //   #1188	-> 3220
/*      */     //   #1188	-> 3259
/*      */     //   #1188	-> 3269
/*      */     //   #1188	-> 3280
/*      */     //   #1193	-> 3293
/*      */     //   #1195	-> 3301
/*      */     //   #1195	-> 3312
/*      */     //   #1195	-> 3325
/*      */     //   #1195	-> 3368
/*      */     //   #1195	-> 3454
/*      */     //   #1195	-> 3467
/*      */     //   #1195	-> 3603
/*      */     //   #1195	-> 3739
/*      */     //   #1195	-> 3784
/*      */     //   #1195	-> 3823
/*      */     //   #1195	-> 3833
/*      */     //   #1195	-> 3844
/*      */     //   #1199	-> 3854
/*      */     //   #1199	-> 3865
/*      */     //   #1199	-> 3878
/*      */     //   #1199	-> 3921
/*      */     //   #1199	-> 4007
/*      */     //   #1199	-> 4020
/*      */     //   #1199	-> 4156
/*      */     //   #1199	-> 4292
/*      */     //   #1199	-> 4337
/*      */     //   #1199	-> 4376
/*      */     //   #1199	-> 4386
/*      */     //   #1199	-> 4397
/*      */     //   #1204	-> 4410
/*      */     //   #1206	-> 4418
/*      */     //   #1206	-> 4429
/*      */     //   #1206	-> 4442
/*      */     //   #1206	-> 4485
/*      */     //   #1206	-> 4571
/*      */     //   #1206	-> 4584
/*      */     //   #1206	-> 4721
/*      */     //   #1206	-> 4813
/*      */     //   #1206	-> 4911
/*      */     //   #1206	-> 4944
/*      */     //   #1206	-> 4971
/*      */     //   #1206	-> 4981
/*      */     //   #1206	-> 4992
/*      */     //   #1210	-> 5002
/*      */     //   #1210	-> 5013
/*      */     //   #1210	-> 5026
/*      */     //   #1210	-> 5057
/*      */     //   #1210	-> 5115
/*      */     //   #1210	-> 5128
/*      */     //   #1210	-> 5229
/*      */     //   #1210	-> 5321
/*      */     //   #1210	-> 5419
/*      */     //   #1210	-> 5452
/*      */     //   #1210	-> 5479
/*      */     //   #1210	-> 5489
/*      */     //   #1210	-> 5500
/*      */     //   #1215	-> 5513
/*      */     //   #1217	-> 5521
/*      */     //   #1217	-> 5532
/*      */     //   #1217	-> 5545
/*      */     //   #1217	-> 5576
/*      */     //   #1217	-> 5634
/*      */     //   #1217	-> 5647
/*      */     //   #1217	-> 5755
/*      */     //   #1217	-> 5763
/*      */     //   #1217	-> 5796
/*      */     //   #1217	-> 5802
/*      */     //   #1217	-> 5805
/*      */     //   #1217	-> 5813
/*      */     //   #1217	-> 5840
/*      */     //   #1217	-> 5850
/*      */     //   #1217	-> 5861
/*      */     //   #1221	-> 5871
/*      */     //   #1221	-> 5882
/*      */     //   #1221	-> 5895
/*      */     //   #1221	-> 5926
/*      */     //   #1221	-> 5984
/*      */     //   #1221	-> 5997
/*      */     //   #1221	-> 6105
/*      */     //   #1221	-> 6113
/*      */     //   #1221	-> 6146
/*      */     //   #1221	-> 6152
/*      */     //   #1221	-> 6155
/*      */     //   #1221	-> 6163
/*      */     //   #1221	-> 6190
/*      */     //   #1221	-> 6200
/*      */     //   #1221	-> 6211
/*      */     //   #1226	-> 6224
/*      */     //   #1226	-> 6235
/*      */     //   #1226	-> 6248
/*      */     //   #1226	-> 6279
/*      */     //   #1226	-> 6337
/*      */     //   #1226	-> 6350
/*      */     //   #1226	-> 6399
/*      */     //   #1226	-> 6426
/*      */     //   #1226	-> 6436
/*      */     //   #1226	-> 6447
/*      */     //   #1230	-> 6457
/*      */     //   #1230	-> 6477
/*      */     //   #0	-> 6486
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	6487	0	indx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	1	n	I
/*      */     //   0	6487	2	key	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	3	nalast	I
/*      */     //   0	6487	4	decreasing	I
/*      */     //   0	6487	5	rho	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	6	itmp	I
/*      */     //   0	6487	7	sx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	8	sx$offset	I
/*      */     //   0	6487	9	cx	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	10	cx$offset	I
/*      */     //   0	6487	11	x	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	12	x$offset	I
/*      */     //   0	6487	13	ix	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	14	ix$offset	I
/*      */     //   0	6487	15	numna	I
/*      */     //   0	6487	16	isna	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	6487	17	isna$offset	I
/*      */     //   0	6487	18	hi	I
/*      */     //   0	6487	19	lo	I
/*      */     //   0	6487	20	t	I
/*      */     //   0	6487	21	h	I
/*      */     //   0	6487	22	j	I
/*      */     //   0	6487	23	i	I
/*      */     //   0	6487	24	c	I
/*      */     //   0	6487	28	j$106	I
/*      */     //   0	6487	47	j$105	I
/*      */     //   0	6487	51	i$104	I
/*      */     //   0	6487	55	j$103	I
/*      */     //   0	6487	62	iftmp$102	I
/*      */     //   0	6487	78	itmp$101	I
/*      */     //   0	6487	89	j$100	I
/*      */     //   0	6487	93	i$99	I
/*      */     //   0	6487	97	j$98	I
/*      */     //   0	6487	104	iftmp$97	I
/*      */     //   0	6487	120	itmp$96	I
/*      */     //   0	6487	131	j$95	I
/*      */     //   0	6487	135	i$94	I
/*      */     //   0	6487	139	j$93	I
/*      */     //   0	6487	151	itmp$92	I
/*      */     //   0	6487	169	itmp$91	I
/*      */     //   0	6487	196	itmp$90	I
/*      */     //   0	6487	207	j$89	I
/*      */     //   0	6487	211	i$88	I
/*      */     //   0	6487	215	j$87	I
/*      */     //   0	6487	227	itmp$86	I
/*      */     //   0	6487	245	itmp$85	I
/*      */     //   0	6487	272	itmp$84	I
/*      */     //   0	6487	283	j$83	I
/*      */     //   0	6487	287	i$82	I
/*      */     //   0	6487	291	j$81	I
/*      */     //   0	6487	303	itmp$80	I
/*      */     //   0	6487	321	itmp$79	I
/*      */     //   0	6487	344	j$78	I
/*      */     //   0	6487	348	i$77	I
/*      */     //   0	6487	352	j$76	I
/*      */     //   0	6487	364	itmp$75	I
/*      */     //   0	6487	382	itmp$74	I
/*      */     //   0	6487	405	j$73	I
/*      */     //   0	6487	409	i$72	I
/*      */     //   0	6487	413	j$71	I
/*      */     //   0	6487	424	itmp$70	I
/*      */     //   0	6487	440	itmp$69	I
/*      */     //   0	6487	462	j$68	I
/*      */     //   0	6487	466	i$67	I
/*      */     //   0	6487	470	j$66	I
/*      */     //   0	6487	481	itmp$65	I
/*      */     //   0	6487	497	itmp$64	I
/*      */     //   0	6487	519	j$63	I
/*      */     //   0	6487	523	i$62	I
/*      */     //   0	6487	528	j$61	I
/*      */     //   0	6487	547	j$60	I
/*      */     //   0	6487	551	i$59	I
/*      */     //   0	6487	561	j$58	I
/*      */     //   0	6487	572	itmp$57	I
/*      */     //   0	6487	588	itmp$56	I
/*      */     //   0	6487	610	j$55	I
/*      */     //   0	6487	614	i$54	I
/*      */     //   0	6487	622	i$53	I
/*      */     //   0	6487	626	i$52	I
/*      */     //   0	6487	632	i$51	I
/*      */     //   0	6487	639	i$50	I
/*      */     //   0	6487	646	i$49	I
/*      */     //   0	6487	647	iftmp$48	I
/*      */     //   0	6487	651	i$47	I
/*      */     //   0	6487	654	R_NaString$46	Lorg/renjin/sexp/SEXP;
/*      */     //   0	6487	659	i$45	I
/*      */     //   0	6487	663	i$44	I
/*      */     //   0	6487	672	i$43	I
/*      */     //   0	6487	676	i$42	I
/*      */     //   0	6487	679	R_NaInt$41	I
/*      */     //   0	6487	684	i$40	I
/*      */     //   0	6487	688	i$39	I
/*      */     //   0	6487	690	n$38	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_order(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #8
/*      */     //   3: iconst_0
/*      */     //   4: istore #9
/*      */     //   6: iconst_0
/*      */     //   7: istore #10
/*      */     //   9: iconst_0
/*      */     //   10: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   18: checkcast org/renjin/sexp/SEXP
/*      */     //   21: astore #12
/*      */     //   23: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   26: astore #12
/*      */     //   28: iconst_0
/*      */     //   29: istore #11
/*      */     //   31: iconst_m1
/*      */     //   32: istore #10
/*      */     //   34: aload_2
/*      */     //   35: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   38: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   41: istore #9
/*      */     //   43: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   46: iload #9
/*      */     //   48: if_icmpeq -> 54
/*      */     //   51: goto -> 96
/*      */     //   54: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   57: dup
/*      */     //   58: ldc '_'
/*      */     //   60: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   63: athrow
/*      */     //   64: nop
/*      */     //   65: nop
/*      */     //   66: nop
/*      */     //   67: nop
/*      */     //   68: athrow
/*      */     //   69: nop
/*      */     //   70: nop
/*      */     //   71: nop
/*      */     //   72: nop
/*      */     //   73: nop
/*      */     //   74: nop
/*      */     //   75: nop
/*      */     //   76: nop
/*      */     //   77: nop
/*      */     //   78: nop
/*      */     //   79: nop
/*      */     //   80: nop
/*      */     //   81: nop
/*      */     //   82: nop
/*      */     //   83: nop
/*      */     //   84: nop
/*      */     //   85: nop
/*      */     //   86: nop
/*      */     //   87: nop
/*      */     //   88: nop
/*      */     //   89: nop
/*      */     //   90: nop
/*      */     //   91: nop
/*      */     //   92: nop
/*      */     //   93: nop
/*      */     //   94: nop
/*      */     //   95: athrow
/*      */     //   96: aload_2
/*      */     //   97: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   100: astore_2
/*      */     //   101: aload_2
/*      */     //   102: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   105: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   108: istore #8
/*      */     //   110: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   113: iload #8
/*      */     //   115: if_icmpeq -> 121
/*      */     //   118: goto -> 146
/*      */     //   121: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   124: dup
/*      */     //   125: ldc '_'
/*      */     //   127: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   130: athrow
/*      */     //   131: nop
/*      */     //   132: nop
/*      */     //   133: nop
/*      */     //   134: nop
/*      */     //   135: athrow
/*      */     //   136: nop
/*      */     //   137: nop
/*      */     //   138: nop
/*      */     //   139: nop
/*      */     //   140: nop
/*      */     //   141: nop
/*      */     //   142: nop
/*      */     //   143: nop
/*      */     //   144: nop
/*      */     //   145: athrow
/*      */     //   146: aload_2
/*      */     //   147: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   150: astore_2
/*      */     //   151: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   154: astore #64
/*      */     //   156: aload_2
/*      */     //   157: aload #64
/*      */     //   159: if_acmpeq -> 165
/*      */     //   162: goto -> 173
/*      */     //   165: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   168: astore #63
/*      */     //   170: goto -> 667
/*      */     //   173: aload_2
/*      */     //   174: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   177: invokestatic Rf_isVector : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   180: ifne -> 186
/*      */     //   183: goto -> 195
/*      */     //   186: aload_2
/*      */     //   187: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   190: invokestatic XLENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   193: istore #10
/*      */     //   195: aload_2
/*      */     //   196: astore #13
/*      */     //   198: goto -> 305
/*      */     //   201: aload #13
/*      */     //   203: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   206: invokestatic Rf_isVector : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   209: ifeq -> 215
/*      */     //   212: goto -> 254
/*      */     //   215: iload #11
/*      */     //   217: iconst_1
/*      */     //   218: iadd
/*      */     //   219: istore #57
/*      */     //   221: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   224: dup
/*      */     //   225: ldc '_'
/*      */     //   227: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   230: athrow
/*      */     //   231: nop
/*      */     //   232: nop
/*      */     //   233: nop
/*      */     //   234: nop
/*      */     //   235: athrow
/*      */     //   236: nop
/*      */     //   237: nop
/*      */     //   238: nop
/*      */     //   239: nop
/*      */     //   240: nop
/*      */     //   241: nop
/*      */     //   242: nop
/*      */     //   243: nop
/*      */     //   244: nop
/*      */     //   245: nop
/*      */     //   246: nop
/*      */     //   247: nop
/*      */     //   248: nop
/*      */     //   249: nop
/*      */     //   250: nop
/*      */     //   251: nop
/*      */     //   252: nop
/*      */     //   253: athrow
/*      */     //   254: aload #13
/*      */     //   256: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   259: invokestatic XLENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   262: iload #10
/*      */     //   264: if_icmpne -> 270
/*      */     //   267: goto -> 295
/*      */     //   270: new org/renjin/gcc/runtime/UnsatisfiedLinkException
/*      */     //   273: dup
/*      */     //   274: ldc '_'
/*      */     //   276: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   279: athrow
/*      */     //   280: nop
/*      */     //   281: nop
/*      */     //   282: nop
/*      */     //   283: nop
/*      */     //   284: athrow
/*      */     //   285: nop
/*      */     //   286: nop
/*      */     //   287: nop
/*      */     //   288: nop
/*      */     //   289: nop
/*      */     //   290: nop
/*      */     //   291: nop
/*      */     //   292: nop
/*      */     //   293: nop
/*      */     //   294: athrow
/*      */     //   295: aload #13
/*      */     //   297: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   300: astore #13
/*      */     //   302: iinc #11, 1
/*      */     //   305: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   308: astore #48
/*      */     //   310: aload #13
/*      */     //   312: aload #48
/*      */     //   314: if_acmpeq -> 320
/*      */     //   317: goto -> 201
/*      */     //   320: iload #10
/*      */     //   322: ifne -> 328
/*      */     //   325: goto -> 659
/*      */     //   328: iload #11
/*      */     //   330: iconst_1
/*      */     //   331: if_icmpeq -> 337
/*      */     //   334: goto -> 500
/*      */     //   337: bipush #13
/*      */     //   339: iload #10
/*      */     //   341: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   344: astore #12
/*      */     //   346: aload #12
/*      */     //   348: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   351: pop
/*      */     //   352: iconst_0
/*      */     //   353: istore #7
/*      */     //   355: goto -> 395
/*      */     //   358: aload #12
/*      */     //   360: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   363: astore #46
/*      */     //   365: iload #7
/*      */     //   367: iconst_4
/*      */     //   368: imul
/*      */     //   369: istore #44
/*      */     //   371: aload #46
/*      */     //   373: astore #42
/*      */     //   375: iconst_0
/*      */     //   376: iload #44
/*      */     //   378: iadd
/*      */     //   379: istore #43
/*      */     //   381: aload #42
/*      */     //   383: iload #43
/*      */     //   385: iload #7
/*      */     //   387: invokeinterface setInt : (II)V
/*      */     //   392: iinc #7, 1
/*      */     //   395: iload #7
/*      */     //   397: iload #10
/*      */     //   399: if_icmplt -> 358
/*      */     //   402: goto -> 405
/*      */     //   405: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   408: astore #41
/*      */     //   410: aload_2
/*      */     //   411: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   414: astore #40
/*      */     //   416: aload #12
/*      */     //   418: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   421: iload #10
/*      */     //   423: aload #40
/*      */     //   425: iload #9
/*      */     //   427: iload #8
/*      */     //   429: aload #41
/*      */     //   431: invokestatic orderVector1 : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/sexp/SEXP;IILorg/renjin/sexp/SEXP;)V
/*      */     //   434: iconst_0
/*      */     //   435: istore #6
/*      */     //   437: goto -> 490
/*      */     //   440: aload #12
/*      */     //   442: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   445: astore #36
/*      */     //   447: iload #6
/*      */     //   449: iconst_4
/*      */     //   450: imul
/*      */     //   451: istore #34
/*      */     //   453: aload #36
/*      */     //   455: astore #32
/*      */     //   457: iconst_0
/*      */     //   458: iload #34
/*      */     //   460: iadd
/*      */     //   461: istore #33
/*      */     //   463: aload #32
/*      */     //   465: iload #33
/*      */     //   467: invokeinterface getInt : (I)I
/*      */     //   472: iconst_1
/*      */     //   473: iadd
/*      */     //   474: istore #30
/*      */     //   476: aload #32
/*      */     //   478: iload #33
/*      */     //   480: iload #30
/*      */     //   482: invokeinterface setInt : (II)V
/*      */     //   487: iinc #6, 1
/*      */     //   490: iload #6
/*      */     //   492: iload #10
/*      */     //   494: if_icmplt -> 440
/*      */     //   497: goto -> 652
/*      */     //   500: bipush #13
/*      */     //   502: iload #10
/*      */     //   504: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   507: astore #12
/*      */     //   509: aload #12
/*      */     //   511: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   514: pop
/*      */     //   515: iconst_0
/*      */     //   516: istore #5
/*      */     //   518: goto -> 558
/*      */     //   521: aload #12
/*      */     //   523: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   526: astore #28
/*      */     //   528: iload #5
/*      */     //   530: iconst_4
/*      */     //   531: imul
/*      */     //   532: istore #26
/*      */     //   534: aload #28
/*      */     //   536: astore #24
/*      */     //   538: iconst_0
/*      */     //   539: iload #26
/*      */     //   541: iadd
/*      */     //   542: istore #25
/*      */     //   544: aload #24
/*      */     //   546: iload #25
/*      */     //   548: iload #5
/*      */     //   550: invokeinterface setInt : (II)V
/*      */     //   555: iinc #5, 1
/*      */     //   558: iload #5
/*      */     //   560: iload #10
/*      */     //   562: if_icmplt -> 521
/*      */     //   565: goto -> 568
/*      */     //   568: aload #12
/*      */     //   570: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   573: iload #10
/*      */     //   575: aload_2
/*      */     //   576: iload #9
/*      */     //   578: iload #8
/*      */     //   580: ldc_w
/*      */     //   583: invokestatic orderVector : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/sexp/SEXP;IILjava/lang/invoke/MethodHandle;)V
/*      */     //   586: iconst_0
/*      */     //   587: istore #4
/*      */     //   589: goto -> 642
/*      */     //   592: aload #12
/*      */     //   594: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   597: astore #20
/*      */     //   599: iload #4
/*      */     //   601: iconst_4
/*      */     //   602: imul
/*      */     //   603: istore #18
/*      */     //   605: aload #20
/*      */     //   607: astore #16
/*      */     //   609: iconst_0
/*      */     //   610: iload #18
/*      */     //   612: iadd
/*      */     //   613: istore #17
/*      */     //   615: aload #16
/*      */     //   617: iload #17
/*      */     //   619: invokeinterface getInt : (I)I
/*      */     //   624: iconst_1
/*      */     //   625: iadd
/*      */     //   626: istore #14
/*      */     //   628: aload #16
/*      */     //   630: iload #17
/*      */     //   632: iload #14
/*      */     //   634: invokeinterface setInt : (II)V
/*      */     //   639: iinc #4, 1
/*      */     //   642: iload #4
/*      */     //   644: iload #10
/*      */     //   646: if_icmplt -> 592
/*      */     //   649: goto -> 652
/*      */     //   652: aload #12
/*      */     //   654: astore #63
/*      */     //   656: goto -> 667
/*      */     //   659: bipush #13
/*      */     //   661: iconst_0
/*      */     //   662: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   665: astore #63
/*      */     //   667: aload #63
/*      */     //   669: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1237	-> 23
/*      */     //   #1238	-> 28
/*      */     //   #1239	-> 31
/*      */     //   #1242	-> 34
/*      */     //   #1243	-> 43
/*      */     //   #1244	-> 54
/*      */     //   #1245	-> 96
/*      */     //   #1246	-> 101
/*      */     //   #1247	-> 110
/*      */     //   #1248	-> 121
/*      */     //   #1249	-> 146
/*      */     //   #1250	-> 151
/*      */     //   #1251	-> 165
/*      */     //   #1253	-> 173
/*      */     //   #1254	-> 186
/*      */     //   #1255	-> 195
/*      */     //   #1256	-> 201
/*      */     //   #1257	-> 215
/*      */     //   #1258	-> 254
/*      */     //   #1259	-> 270
/*      */     //   #1255	-> 295
/*      */     //   #1255	-> 305
/*      */     //   #1262	-> 320
/*      */     //   #1263	-> 328
/*      */     //   #1275	-> 337
/*      */     //   #1276	-> 352
/*      */     //   #1276	-> 358
/*      */     //   #1276	-> 395
/*      */     //   #1277	-> 405
/*      */     //   #1279	-> 434
/*      */     //   #1279	-> 440
/*      */     //   #1279	-> 490
/*      */     //   #1293	-> 500
/*      */     //   #1294	-> 515
/*      */     //   #1294	-> 521
/*      */     //   #1294	-> 558
/*      */     //   #1295	-> 568
/*      */     //   #1297	-> 586
/*      */     //   #1297	-> 592
/*      */     //   #1297	-> 642
/*      */     //   #1300	-> 652
/*      */     //   #1301	-> 652
/*      */     //   #1302	-> 659
/*      */     //   #0	-> 667
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	670	0	call	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	1	op	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	2	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	3	rho	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	4	i	I
/*      */     //   0	670	5	i	I
/*      */     //   0	670	6	i	I
/*      */     //   0	670	7	i	I
/*      */     //   0	670	8	decreasing	I
/*      */     //   0	670	9	nalast	I
/*      */     //   0	670	10	n	I
/*      */     //   0	670	11	narg	I
/*      */     //   0	670	12	ans	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	13	ap	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	19	i$37	I
/*      */     //   0	670	27	i$36	I
/*      */     //   0	670	35	i$31	I
/*      */     //   0	670	41	R_NilValue$30	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	45	i$29	I
/*      */     //   0	670	48	R_NilValue$23	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	64	R_NilValue$22	Lorg/renjin/sexp/SEXP;
/*      */     //   0	670	68	R_NaInt$21	I
/*      */     //   0	670	69	R_NaInt$20	I
/*      */     //   0	670	75	R_NaInt$19	I
/*      */     //   0	670	76	R_NaInt$18	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_rank(SEXP call, SEXP op, SEXP args, SEXP rho) {
/* 1309 */     in = BytePtr.of(0); in$offset = 0; j = 0; i = 0; ptr1 = BytePtr.of(0); m = 0; i2 = 0; i3 = 0; n = 0; ties_kind = 0; rk = BytePtr.of(0); rk$offset = 0; ik = BytePtr.of(0); ik$offset = 0; x = (SEXP)BytePtr.of(0).getArray(); rank = (SEXP)BytePtr.of(0).getArray(); ik = BytePtr.of(0); ik$offset = 0;
/* 1310 */     rk = BytePtr.of(0); rk$offset = 0;
/* 1311 */     ties_kind = 0;
/* 1312 */     isLong = 0;
/*      */     
/* 1314 */     Defn.Rf_checkArityCall(op, args, call);
/* 1315 */     x = Rinternals.CAR(args);
/* 1316 */     if (Rinternals.TYPEOF(x) != 24) {
/*      */ 
/*      */       
/* 1319 */       sn = Rinternals.CADR(args);
/*      */       
/* 1321 */       if (Rinternals.TYPEOF(sn) != 14)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1329 */         nn = Rinternals.Rf_asInteger(sn);
/* 1330 */         R_NaInt$3 = Arith.R_NaInt; if (nn != R_NaInt$3 && nn >= 0)
/*      */         
/* 1332 */         { n = nn; } else { throw new UnsatisfiedLinkException("_"); }  } else { d = Rinternals2.REAL(x).getDouble(); if (Builtins.__isnan(d) == 0) { if (Arith.R_finite(d) != 0) { if (d <= 2.147483647E9D) { n = (int)d; if (n < 0)
/*      */                 throw new UnsatisfiedLinkException("_");  } else { throw new UnsatisfiedLinkException("_"); }  } else { throw new UnsatisfiedLinkException("_"); }  } else { throw new UnsatisfiedLinkException("_"); }  }
/* 1334 */        isLong = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1340 */       BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.Rf_asChar(Rinternals.CADDR(args)));
/* 1341 */       if (Stdlib.strcmp((Ptr)bytePtr, (Ptr)new BytePtr("average\000".getBytes(), 0)) != 0)
/* 1342 */       { if (Stdlib.strcmp((Ptr)bytePtr, (Ptr)new BytePtr("max\000".getBytes(), 0)) != 0)
/* 1343 */         { if (Stdlib.strcmp((Ptr)bytePtr, (Ptr)new BytePtr("min\000".getBytes(), 0)) != 0)
/* 1344 */             throw new UnsatisfiedLinkException("_");  ties_kind = 2; } else { ties_kind = 1; }  } else { ties_kind = 0; }
/* 1345 */        if (ties_kind != 0 && isLong == 0)
/*      */       
/*      */       { 
/*      */         
/* 1349 */         rank = Rinternals.Rf_allocVector(13, n); Rinternals.Rf_protect(rank);
/* 1350 */         ik = Rinternals2.INTEGER(rank); ik$offset = 0; }
/*      */       else { rank = Rinternals.Rf_allocVector(14, n); Rinternals.Rf_protect(rank); rk = Rinternals2.REAL(rank); rk$offset = 0; }
/* 1352 */        if (n > 0)
/*      */       
/* 1354 */       { if (isLong == 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1379 */           IntPtr intPtr1 = IntPtr.malloc(n * 4); in$offset = 0;
/* 1380 */           for (i = 0; i < n; ) { int i5 = i * 4; IntPtr intPtr2 = intPtr1; int i4 = in$offset + i5; intPtr2.setInt(i4, i); i++; }
/* 1381 */            orderVector1(intPtr1.pointerPlus(in$offset), n, x, 1, 0, rho);
/* 1382 */           for (i = 0; i < n; i = j + 1) {
/* 1383 */             j = i;
/* 1384 */             while (n + -1 > j) { int i8 = (j + 1) * 4; IntPtr intPtr3 = intPtr1; int i7 = in$offset + i8, i6 = intPtr3.getInt(i7), i5 = j * 4; IntPtr intPtr2 = intPtr1; int i4 = in$offset + i5; if (equal(intPtr2.getInt(i4), i6, x, 1, rho) == 0) break;  j++; }
/* 1385 */              switch (ties_kind) {
/*      */               case 0:
/* 1387 */                 for (k = i; k <= j; k++) {
/* 1388 */                   int i7 = k * 4; IntPtr intPtr2 = intPtr1; int i6 = in$offset + i7, i5 = intPtr2.getInt(i6) * 8; Ptr ptr = rk; int i4 = rk$offset + i5; double d1 = (i + j + 2) / 2.0D; ptr.setDouble(i4, d1);
/*      */                 }  break;
/*      */               case 1:
/* 1391 */                 for (k = i; k <= j; ) { int i8 = k * 4; IntPtr intPtr2 = intPtr1; int i7 = in$offset + i8, i6 = intPtr2.getInt(i7) * 4; Ptr ptr = ik; int i5 = ik$offset + i6, i4 = j + 1; ptr.setInt(i5, i4); k++; }
/*      */                  break;
/*      */               case 2:
/* 1394 */                 for (k = i; k <= j; ) { int i8 = k * 4; IntPtr intPtr2 = intPtr1; int i7 = in$offset + i8, i6 = intPtr2.getInt(i7) * 4; Ptr ptr = ik; int i5 = ik$offset + i6, i4 = i + 1; ptr.setInt(i5, i4); k++; }
/*      */                 
/*      */                 break;
/*      */             } 
/*      */ 
/*      */           
/*      */           } 
/* 1401 */           return rank; }  IntPtr intPtr = IntPtr.malloc(n * 4); m = 0; for (i3 = 0; i3 < n; ) { int i5 = i3 * 4; IntPtr intPtr1 = intPtr; int i4 = m + i5; intPtr1.setInt(i4, i3); i3++; }  orderVector1l(intPtr.pointerPlus(m), n, x, 1, 0, rho); for (i3 = 0; i3 < n; i3 = i2 + 1) { i2 = i3; while (n + -1 > i2) { int i8 = (i2 + 1) * 4; IntPtr intPtr2 = intPtr; int i7 = m + i8, i6 = intPtr2.getInt(i7), i5 = i2 * 4; IntPtr intPtr1 = intPtr; int i4 = m + i5; if (equal(intPtr1.getInt(i4), i6, x, 1, rho) == 0) break;  i2++; }  switch (ties_kind) { case 0: for (i1 = i3; i1 <= i2; i1++) { int i7 = i1 * 4; IntPtr intPtr1 = intPtr; int i6 = m + i7, i5 = intPtr1.getInt(i6) * 8; Ptr ptr = rk; int i4 = rk$offset + i5; double d1 = (i3 + i2 + 2) / 2.0D; ptr.setDouble(i4, d1); }  break;case 1: for (i1 = i3; i1 <= i2; ) { int i7 = i1 * 4; IntPtr intPtr1 = intPtr; int i6 = m + i7, i5 = intPtr1.getInt(i6) * 8; Ptr ptr = rk; int i4 = rk$offset + i5; double d1 = (i2 + 1); ptr.setDouble(i4, d1); i1++; }  break;case 2: for (i1 = i3; i1 <= i2; ) { int i7 = i1 * 4; IntPtr intPtr1 = intPtr; int i6 = m + i7, i5 = intPtr1.getInt(i6) * 8; Ptr ptr = rk; int i4 = rk$offset + i5; double d1 = (i3 + 1); ptr.setDouble(i4, d1); i1++; }  break; }  }  }  return rank;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP do_xtfrm(SEXP call, SEXP op, SEXP args, SEXP rho) {
/* 1408 */     ans = new SEXP[1]; ans[0] = (SEXP)BytePtr.of(0).getArray(); Defn.Rf_checkArityCall(op, args, call);
/* 1409 */     Defn.Rf_check1arg(args, call, new BytePtr("x\000".getBytes(), 0));
/*      */     
/* 1411 */     throw new UnsatisfiedLinkException("Rf_DispatchOrEval");
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/sort__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */