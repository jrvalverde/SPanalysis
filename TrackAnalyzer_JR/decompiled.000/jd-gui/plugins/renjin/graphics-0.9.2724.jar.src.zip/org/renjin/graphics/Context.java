package org.renjin.graphics;

import java.lang.invoke.MethodHandle;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.primitives.Native;
import org.renjin.sexp.SEXP;

public class Context {
  public byte[] format$buff$6932;
  
  public double[] format$tbl;
  
  public MethodHandle graphics$old_close;
  
  public byte graphics$yaxtsave;
  
  public byte graphics$yaxssave;
  
  public double[] graphics$yaxpsave;
  
  public int graphics$xpdsave;
  
  public byte graphics$xaxtsave;
  
  public byte graphics$xaxssave;
  
  public double[] graphics$xaxpsave;
  
  public double graphics$tclsave;
  
  public double graphics$tcksave;
  
  public double graphics$srtsave;
  
  public int graphics$pchsave;
  
  public double graphics$mkhsave;
  
  public double[] graphics$mgpsave;
  
  public double graphics$lmitresave;
  
  public int graphics$ljoinsave;
  
  public int graphics$lendsave;
  
  public double graphics$lwdsave;
  
  public int graphics$ltysave;
  
  public int graphics$lassave;
  
  public int[] graphics$labsave;
  
  public int graphics$errsave;
  
  public int graphics$fontaxissave;
  
  public int graphics$fontsubsave;
  
  public int graphics$fontlabsave;
  
  public int graphics$fontmainsave;
  
  public int graphics$fontsave;
  
  public byte[] graphics$familysave;
  
  public double graphics$crtsave;
  
  public int graphics$colaxissave;
  
  public int graphics$colsubsave;
  
  public int graphics$collabsave;
  
  public int graphics$colmainsave;
  
  public int graphics$bgsave;
  
  public int graphics$fgsave;
  
  public int graphics$colsave;
  
  public double graphics$cexaxissave;
  
  public double graphics$cexsubsave;
  
  public double graphics$cexlabsave;
  
  public double graphics$cexmainsave;
  
  public double graphics$cexbasesave;
  
  public double graphics$lheightsave;
  
  public double graphics$cexsave;
  
  public byte graphics$btysave;
  
  public int graphics$annsave;
  
  public double graphics$adjsave;
  
  public int[] graphics$baseRegisterIndex;
  
  public Ptr init$ExtEntries;
  
  public Ptr init$CallEntries;
  
  public Ptr par$ParTable;
  
  public double plot$dnd_offset;
  
  public double plot$dnd_hang;
  
  public Ptr plot$dnd_xpos;
  
  public int plot$dnd_xpos$offset;
  
  public Ptr plot$dnd_hght;
  
  public int plot$dnd_hght$offset;
  
  public Ptr plot$dnd_rptr;
  
  public int plot$dnd_rptr$offset;
  
  public Ptr plot$dnd_lptr;
  
  public int plot$dnd_lptr$offset;
  
  public Ptr plot3d$ctr_SegDB;
  
  public int plot3d$ctr_SegDB$offset;
  
  public SEXP plot3d$labelList;
  
  public short[] plot3d$TickVector;
  
  public short[] plot3d$AxisStart;
  
  public short[] plot3d$Edge;
  
  public short[] plot3d$Face;
  
  public short[] plot3d$Vertex;
  
  public int plot3d$DoLighting;
  
  public double plot3d$Shade;
  
  public double[] plot3d$Light;
  
  public double[] plot3d$VT;
  
  public int plot3d$LoadInitFile;
  
  public int plot3d$R_ReadItemDepth;
  
  public int plot3d$R_InitReadItemDepth;
  
  public int plot3d$R_OutputCon;
  
  public double plotmath$OneSixth$7738;
  
  public double plotmath$TwoNinths$7746;
  
  public double plotmath$FiveEighteenths$7754;
  
  public double plotmath$OneEighteenth$7762;
  
  public Ptr plotmath$RelTable;
  
  public Ptr plotmath$OpTable;
  
  public Ptr plotmath$AccentTable;
  
  public Ptr plotmath$BinTable;
  
  public Ptr plotmath$SymbolTable;
  
  public double plotmath$ItalicFactor;
  
  public int plotmath$MetricUnit;
  
  public int[] sort$sincs;
  
  public int[] sort$incs;
  
  public static Context current() {
    return (Context)Native.currentContext().getSingleton(Context.class);
  }
  
  public static byte[] get__format$buff$6932() {
    return (current()).format$buff$6932;
  }
  
  public static void set__format$buff$6932(byte[] paramArrayOfbyte) {
    (current()).format$buff$6932 = paramArrayOfbyte;
  }
  
  public static double[] get__format$tbl() {
    return (current()).format$tbl;
  }
  
  public static void set__format$tbl(double[] paramArrayOfdouble) {
    (current()).format$tbl = paramArrayOfdouble;
  }
  
  public static MethodHandle get__graphics$old_close() {
    return (current()).graphics$old_close;
  }
  
  public static void set__graphics$old_close(MethodHandle paramMethodHandle) {
    (current()).graphics$old_close = paramMethodHandle;
  }
  
  public static byte get__graphics$yaxtsave() {
    return (current()).graphics$yaxtsave;
  }
  
  public static void set__graphics$yaxtsave(byte paramByte) {
    (current()).graphics$yaxtsave = paramByte;
  }
  
  public static byte get__graphics$yaxssave() {
    return (current()).graphics$yaxssave;
  }
  
  public static void set__graphics$yaxssave(byte paramByte) {
    (current()).graphics$yaxssave = paramByte;
  }
  
  public static double[] get__graphics$yaxpsave() {
    return (current()).graphics$yaxpsave;
  }
  
  public static void set__graphics$yaxpsave(double[] paramArrayOfdouble) {
    (current()).graphics$yaxpsave = paramArrayOfdouble;
  }
  
  public static int get__graphics$xpdsave() {
    return (current()).graphics$xpdsave;
  }
  
  public static void set__graphics$xpdsave(int paramInt) {
    (current()).graphics$xpdsave = paramInt;
  }
  
  public static byte get__graphics$xaxtsave() {
    return (current()).graphics$xaxtsave;
  }
  
  public static void set__graphics$xaxtsave(byte paramByte) {
    (current()).graphics$xaxtsave = paramByte;
  }
  
  public static byte get__graphics$xaxssave() {
    return (current()).graphics$xaxssave;
  }
  
  public static void set__graphics$xaxssave(byte paramByte) {
    (current()).graphics$xaxssave = paramByte;
  }
  
  public static double[] get__graphics$xaxpsave() {
    return (current()).graphics$xaxpsave;
  }
  
  public static void set__graphics$xaxpsave(double[] paramArrayOfdouble) {
    (current()).graphics$xaxpsave = paramArrayOfdouble;
  }
  
  public static double get__graphics$tclsave() {
    return (current()).graphics$tclsave;
  }
  
  public static void set__graphics$tclsave(double paramDouble) {
    (current()).graphics$tclsave = paramDouble;
  }
  
  public static double get__graphics$tcksave() {
    return (current()).graphics$tcksave;
  }
  
  public static void set__graphics$tcksave(double paramDouble) {
    (current()).graphics$tcksave = paramDouble;
  }
  
  public static double get__graphics$srtsave() {
    return (current()).graphics$srtsave;
  }
  
  public static void set__graphics$srtsave(double paramDouble) {
    (current()).graphics$srtsave = paramDouble;
  }
  
  public static int get__graphics$pchsave() {
    return (current()).graphics$pchsave;
  }
  
  public static void set__graphics$pchsave(int paramInt) {
    (current()).graphics$pchsave = paramInt;
  }
  
  public static double get__graphics$mkhsave() {
    return (current()).graphics$mkhsave;
  }
  
  public static void set__graphics$mkhsave(double paramDouble) {
    (current()).graphics$mkhsave = paramDouble;
  }
  
  public static double[] get__graphics$mgpsave() {
    return (current()).graphics$mgpsave;
  }
  
  public static void set__graphics$mgpsave(double[] paramArrayOfdouble) {
    (current()).graphics$mgpsave = paramArrayOfdouble;
  }
  
  public static double get__graphics$lmitresave() {
    return (current()).graphics$lmitresave;
  }
  
  public static void set__graphics$lmitresave(double paramDouble) {
    (current()).graphics$lmitresave = paramDouble;
  }
  
  public static int get__graphics$ljoinsave() {
    return (current()).graphics$ljoinsave;
  }
  
  public static void set__graphics$ljoinsave(int paramInt) {
    (current()).graphics$ljoinsave = paramInt;
  }
  
  public static int get__graphics$lendsave() {
    return (current()).graphics$lendsave;
  }
  
  public static void set__graphics$lendsave(int paramInt) {
    (current()).graphics$lendsave = paramInt;
  }
  
  public static double get__graphics$lwdsave() {
    return (current()).graphics$lwdsave;
  }
  
  public static void set__graphics$lwdsave(double paramDouble) {
    (current()).graphics$lwdsave = paramDouble;
  }
  
  public static int get__graphics$ltysave() {
    return (current()).graphics$ltysave;
  }
  
  public static void set__graphics$ltysave(int paramInt) {
    (current()).graphics$ltysave = paramInt;
  }
  
  public static int get__graphics$lassave() {
    return (current()).graphics$lassave;
  }
  
  public static void set__graphics$lassave(int paramInt) {
    (current()).graphics$lassave = paramInt;
  }
  
  public static int[] get__graphics$labsave() {
    return (current()).graphics$labsave;
  }
  
  public static void set__graphics$labsave(int[] paramArrayOfint) {
    (current()).graphics$labsave = paramArrayOfint;
  }
  
  public static int get__graphics$errsave() {
    return (current()).graphics$errsave;
  }
  
  public static void set__graphics$errsave(int paramInt) {
    (current()).graphics$errsave = paramInt;
  }
  
  public static int get__graphics$fontaxissave() {
    return (current()).graphics$fontaxissave;
  }
  
  public static void set__graphics$fontaxissave(int paramInt) {
    (current()).graphics$fontaxissave = paramInt;
  }
  
  public static int get__graphics$fontsubsave() {
    return (current()).graphics$fontsubsave;
  }
  
  public static void set__graphics$fontsubsave(int paramInt) {
    (current()).graphics$fontsubsave = paramInt;
  }
  
  public static int get__graphics$fontlabsave() {
    return (current()).graphics$fontlabsave;
  }
  
  public static void set__graphics$fontlabsave(int paramInt) {
    (current()).graphics$fontlabsave = paramInt;
  }
  
  public static int get__graphics$fontmainsave() {
    return (current()).graphics$fontmainsave;
  }
  
  public static void set__graphics$fontmainsave(int paramInt) {
    (current()).graphics$fontmainsave = paramInt;
  }
  
  public static int get__graphics$fontsave() {
    return (current()).graphics$fontsave;
  }
  
  public static void set__graphics$fontsave(int paramInt) {
    (current()).graphics$fontsave = paramInt;
  }
  
  public static byte[] get__graphics$familysave() {
    return (current()).graphics$familysave;
  }
  
  public static void set__graphics$familysave(byte[] paramArrayOfbyte) {
    (current()).graphics$familysave = paramArrayOfbyte;
  }
  
  public static double get__graphics$crtsave() {
    return (current()).graphics$crtsave;
  }
  
  public static void set__graphics$crtsave(double paramDouble) {
    (current()).graphics$crtsave = paramDouble;
  }
  
  public static int get__graphics$colaxissave() {
    return (current()).graphics$colaxissave;
  }
  
  public static void set__graphics$colaxissave(int paramInt) {
    (current()).graphics$colaxissave = paramInt;
  }
  
  public static int get__graphics$colsubsave() {
    return (current()).graphics$colsubsave;
  }
  
  public static void set__graphics$colsubsave(int paramInt) {
    (current()).graphics$colsubsave = paramInt;
  }
  
  public static int get__graphics$collabsave() {
    return (current()).graphics$collabsave;
  }
  
  public static void set__graphics$collabsave(int paramInt) {
    (current()).graphics$collabsave = paramInt;
  }
  
  public static int get__graphics$colmainsave() {
    return (current()).graphics$colmainsave;
  }
  
  public static void set__graphics$colmainsave(int paramInt) {
    (current()).graphics$colmainsave = paramInt;
  }
  
  public static int get__graphics$bgsave() {
    return (current()).graphics$bgsave;
  }
  
  public static void set__graphics$bgsave(int paramInt) {
    (current()).graphics$bgsave = paramInt;
  }
  
  public static int get__graphics$fgsave() {
    return (current()).graphics$fgsave;
  }
  
  public static void set__graphics$fgsave(int paramInt) {
    (current()).graphics$fgsave = paramInt;
  }
  
  public static int get__graphics$colsave() {
    return (current()).graphics$colsave;
  }
  
  public static void set__graphics$colsave(int paramInt) {
    (current()).graphics$colsave = paramInt;
  }
  
  public static double get__graphics$cexaxissave() {
    return (current()).graphics$cexaxissave;
  }
  
  public static void set__graphics$cexaxissave(double paramDouble) {
    (current()).graphics$cexaxissave = paramDouble;
  }
  
  public static double get__graphics$cexsubsave() {
    return (current()).graphics$cexsubsave;
  }
  
  public static void set__graphics$cexsubsave(double paramDouble) {
    (current()).graphics$cexsubsave = paramDouble;
  }
  
  public static double get__graphics$cexlabsave() {
    return (current()).graphics$cexlabsave;
  }
  
  public static void set__graphics$cexlabsave(double paramDouble) {
    (current()).graphics$cexlabsave = paramDouble;
  }
  
  public static double get__graphics$cexmainsave() {
    return (current()).graphics$cexmainsave;
  }
  
  public static void set__graphics$cexmainsave(double paramDouble) {
    (current()).graphics$cexmainsave = paramDouble;
  }
  
  public static double get__graphics$cexbasesave() {
    return (current()).graphics$cexbasesave;
  }
  
  public static void set__graphics$cexbasesave(double paramDouble) {
    (current()).graphics$cexbasesave = paramDouble;
  }
  
  public static double get__graphics$lheightsave() {
    return (current()).graphics$lheightsave;
  }
  
  public static void set__graphics$lheightsave(double paramDouble) {
    (current()).graphics$lheightsave = paramDouble;
  }
  
  public static double get__graphics$cexsave() {
    return (current()).graphics$cexsave;
  }
  
  public static void set__graphics$cexsave(double paramDouble) {
    (current()).graphics$cexsave = paramDouble;
  }
  
  public static byte get__graphics$btysave() {
    return (current()).graphics$btysave;
  }
  
  public static void set__graphics$btysave(byte paramByte) {
    (current()).graphics$btysave = paramByte;
  }
  
  public static int get__graphics$annsave() {
    return (current()).graphics$annsave;
  }
  
  public static void set__graphics$annsave(int paramInt) {
    (current()).graphics$annsave = paramInt;
  }
  
  public static double get__graphics$adjsave() {
    return (current()).graphics$adjsave;
  }
  
  public static void set__graphics$adjsave(double paramDouble) {
    (current()).graphics$adjsave = paramDouble;
  }
  
  public static int[] get__graphics$baseRegisterIndex() {
    return (current()).graphics$baseRegisterIndex;
  }
  
  public static void set__graphics$baseRegisterIndex(int[] paramArrayOfint) {
    (current()).graphics$baseRegisterIndex = paramArrayOfint;
  }
  
  public static Ptr get__init$ExtEntries() {
    return (current()).init$ExtEntries;
  }
  
  public static void set__init$ExtEntries(Ptr paramPtr) {
    (current()).init$ExtEntries = paramPtr;
  }
  
  public static Ptr get__init$CallEntries() {
    return (current()).init$CallEntries;
  }
  
  public static void set__init$CallEntries(Ptr paramPtr) {
    (current()).init$CallEntries = paramPtr;
  }
  
  public static Ptr get__par$ParTable() {
    return (current()).par$ParTable;
  }
  
  public static void set__par$ParTable(Ptr paramPtr) {
    (current()).par$ParTable = paramPtr;
  }
  
  public static double get__plot$dnd_offset() {
    return (current()).plot$dnd_offset;
  }
  
  public static void set__plot$dnd_offset(double paramDouble) {
    (current()).plot$dnd_offset = paramDouble;
  }
  
  public static double get__plot$dnd_hang() {
    return (current()).plot$dnd_hang;
  }
  
  public static void set__plot$dnd_hang(double paramDouble) {
    (current()).plot$dnd_hang = paramDouble;
  }
  
  public static Ptr get__plot$dnd_xpos() {
    return (current()).plot$dnd_xpos;
  }
  
  public static void set__plot$dnd_xpos(Ptr paramPtr) {
    (current()).plot$dnd_xpos = paramPtr;
  }
  
  public static int get__plot$dnd_xpos$offset() {
    return (current()).plot$dnd_xpos$offset;
  }
  
  public static void set__plot$dnd_xpos$offset(int paramInt) {
    (current()).plot$dnd_xpos$offset = paramInt;
  }
  
  public static Ptr get__plot$dnd_hght() {
    return (current()).plot$dnd_hght;
  }
  
  public static void set__plot$dnd_hght(Ptr paramPtr) {
    (current()).plot$dnd_hght = paramPtr;
  }
  
  public static int get__plot$dnd_hght$offset() {
    return (current()).plot$dnd_hght$offset;
  }
  
  public static void set__plot$dnd_hght$offset(int paramInt) {
    (current()).plot$dnd_hght$offset = paramInt;
  }
  
  public static Ptr get__plot$dnd_rptr() {
    return (current()).plot$dnd_rptr;
  }
  
  public static void set__plot$dnd_rptr(Ptr paramPtr) {
    (current()).plot$dnd_rptr = paramPtr;
  }
  
  public static int get__plot$dnd_rptr$offset() {
    return (current()).plot$dnd_rptr$offset;
  }
  
  public static void set__plot$dnd_rptr$offset(int paramInt) {
    (current()).plot$dnd_rptr$offset = paramInt;
  }
  
  public static Ptr get__plot$dnd_lptr() {
    return (current()).plot$dnd_lptr;
  }
  
  public static void set__plot$dnd_lptr(Ptr paramPtr) {
    (current()).plot$dnd_lptr = paramPtr;
  }
  
  public static int get__plot$dnd_lptr$offset() {
    return (current()).plot$dnd_lptr$offset;
  }
  
  public static void set__plot$dnd_lptr$offset(int paramInt) {
    (current()).plot$dnd_lptr$offset = paramInt;
  }
  
  public static Ptr get__plot3d$ctr_SegDB() {
    return (current()).plot3d$ctr_SegDB;
  }
  
  public static void set__plot3d$ctr_SegDB(Ptr paramPtr) {
    (current()).plot3d$ctr_SegDB = paramPtr;
  }
  
  public static int get__plot3d$ctr_SegDB$offset() {
    return (current()).plot3d$ctr_SegDB$offset;
  }
  
  public static void set__plot3d$ctr_SegDB$offset(int paramInt) {
    (current()).plot3d$ctr_SegDB$offset = paramInt;
  }
  
  public static SEXP get__plot3d$labelList() {
    return (current()).plot3d$labelList;
  }
  
  public static void set__plot3d$labelList(SEXP paramSEXP) {
    (current()).plot3d$labelList = paramSEXP;
  }
  
  public static short[] get__plot3d$TickVector() {
    return (current()).plot3d$TickVector;
  }
  
  public static void set__plot3d$TickVector(short[] paramArrayOfshort) {
    (current()).plot3d$TickVector = paramArrayOfshort;
  }
  
  public static short[] get__plot3d$AxisStart() {
    return (current()).plot3d$AxisStart;
  }
  
  public static void set__plot3d$AxisStart(short[] paramArrayOfshort) {
    (current()).plot3d$AxisStart = paramArrayOfshort;
  }
  
  public static short[] get__plot3d$Edge() {
    return (current()).plot3d$Edge;
  }
  
  public static void set__plot3d$Edge(short[] paramArrayOfshort) {
    (current()).plot3d$Edge = paramArrayOfshort;
  }
  
  public static short[] get__plot3d$Face() {
    return (current()).plot3d$Face;
  }
  
  public static void set__plot3d$Face(short[] paramArrayOfshort) {
    (current()).plot3d$Face = paramArrayOfshort;
  }
  
  public static short[] get__plot3d$Vertex() {
    return (current()).plot3d$Vertex;
  }
  
  public static void set__plot3d$Vertex(short[] paramArrayOfshort) {
    (current()).plot3d$Vertex = paramArrayOfshort;
  }
  
  public static int get__plot3d$DoLighting() {
    return (current()).plot3d$DoLighting;
  }
  
  public static void set__plot3d$DoLighting(int paramInt) {
    (current()).plot3d$DoLighting = paramInt;
  }
  
  public static double get__plot3d$Shade() {
    return (current()).plot3d$Shade;
  }
  
  public static void set__plot3d$Shade(double paramDouble) {
    (current()).plot3d$Shade = paramDouble;
  }
  
  public static double[] get__plot3d$Light() {
    return (current()).plot3d$Light;
  }
  
  public static void set__plot3d$Light(double[] paramArrayOfdouble) {
    (current()).plot3d$Light = paramArrayOfdouble;
  }
  
  public static double[] get__plot3d$VT() {
    return (current()).plot3d$VT;
  }
  
  public static void set__plot3d$VT(double[] paramArrayOfdouble) {
    (current()).plot3d$VT = paramArrayOfdouble;
  }
  
  public static int get__plot3d$LoadInitFile() {
    return (current()).plot3d$LoadInitFile;
  }
  
  public static void set__plot3d$LoadInitFile(int paramInt) {
    (current()).plot3d$LoadInitFile = paramInt;
  }
  
  public static int get__plot3d$R_ReadItemDepth() {
    return (current()).plot3d$R_ReadItemDepth;
  }
  
  public static void set__plot3d$R_ReadItemDepth(int paramInt) {
    (current()).plot3d$R_ReadItemDepth = paramInt;
  }
  
  public static int get__plot3d$R_InitReadItemDepth() {
    return (current()).plot3d$R_InitReadItemDepth;
  }
  
  public static void set__plot3d$R_InitReadItemDepth(int paramInt) {
    (current()).plot3d$R_InitReadItemDepth = paramInt;
  }
  
  public static int get__plot3d$R_OutputCon() {
    return (current()).plot3d$R_OutputCon;
  }
  
  public static void set__plot3d$R_OutputCon(int paramInt) {
    (current()).plot3d$R_OutputCon = paramInt;
  }
  
  public static double get__plotmath$OneSixth$7738() {
    return (current()).plotmath$OneSixth$7738;
  }
  
  public static void set__plotmath$OneSixth$7738(double paramDouble) {
    (current()).plotmath$OneSixth$7738 = paramDouble;
  }
  
  public static double get__plotmath$TwoNinths$7746() {
    return (current()).plotmath$TwoNinths$7746;
  }
  
  public static void set__plotmath$TwoNinths$7746(double paramDouble) {
    (current()).plotmath$TwoNinths$7746 = paramDouble;
  }
  
  public static double get__plotmath$FiveEighteenths$7754() {
    return (current()).plotmath$FiveEighteenths$7754;
  }
  
  public static void set__plotmath$FiveEighteenths$7754(double paramDouble) {
    (current()).plotmath$FiveEighteenths$7754 = paramDouble;
  }
  
  public static double get__plotmath$OneEighteenth$7762() {
    return (current()).plotmath$OneEighteenth$7762;
  }
  
  public static void set__plotmath$OneEighteenth$7762(double paramDouble) {
    (current()).plotmath$OneEighteenth$7762 = paramDouble;
  }
  
  public static Ptr get__plotmath$RelTable() {
    return (current()).plotmath$RelTable;
  }
  
  public static void set__plotmath$RelTable(Ptr paramPtr) {
    (current()).plotmath$RelTable = paramPtr;
  }
  
  public static Ptr get__plotmath$OpTable() {
    return (current()).plotmath$OpTable;
  }
  
  public static void set__plotmath$OpTable(Ptr paramPtr) {
    (current()).plotmath$OpTable = paramPtr;
  }
  
  public static Ptr get__plotmath$AccentTable() {
    return (current()).plotmath$AccentTable;
  }
  
  public static void set__plotmath$AccentTable(Ptr paramPtr) {
    (current()).plotmath$AccentTable = paramPtr;
  }
  
  public static Ptr get__plotmath$BinTable() {
    return (current()).plotmath$BinTable;
  }
  
  public static void set__plotmath$BinTable(Ptr paramPtr) {
    (current()).plotmath$BinTable = paramPtr;
  }
  
  public static Ptr get__plotmath$SymbolTable() {
    return (current()).plotmath$SymbolTable;
  }
  
  public static void set__plotmath$SymbolTable(Ptr paramPtr) {
    (current()).plotmath$SymbolTable = paramPtr;
  }
  
  public static double get__plotmath$ItalicFactor() {
    return (current()).plotmath$ItalicFactor;
  }
  
  public static void set__plotmath$ItalicFactor(double paramDouble) {
    (current()).plotmath$ItalicFactor = paramDouble;
  }
  
  public static int get__plotmath$MetricUnit() {
    return (current()).plotmath$MetricUnit;
  }
  
  public static void set__plotmath$MetricUnit(int paramInt) {
    (current()).plotmath$MetricUnit = paramInt;
  }
  
  public static int[] get__sort$sincs() {
    return (current()).sort$sincs;
  }
  
  public static void set__sort$sincs(int[] paramArrayOfint) {
    (current()).sort$sincs = paramArrayOfint;
  }
  
  public static int[] get__sort$incs() {
    return (current()).sort$incs;
  }
  
  public static void set__sort$incs(int[] paramArrayOfint) {
    (current()).sort$incs = paramArrayOfint;
  }
  
  public Context() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: sipush #1000
    //   8: newarray byte
    //   10: putfield format$buff$6932 : [B
    //   13: aload_0
    //   14: bipush #24
    //   16: newarray double
    //   18: putfield format$tbl : [D
    //   21: aload_0
    //   22: iconst_3
    //   23: newarray double
    //   25: putfield graphics$yaxpsave : [D
    //   28: aload_0
    //   29: iconst_3
    //   30: newarray double
    //   32: putfield graphics$xaxpsave : [D
    //   35: aload_0
    //   36: iconst_3
    //   37: newarray double
    //   39: putfield graphics$mgpsave : [D
    //   42: aload_0
    //   43: iconst_3
    //   44: newarray int
    //   46: putfield graphics$labsave : [I
    //   49: aload_0
    //   50: sipush #201
    //   53: newarray byte
    //   55: putfield graphics$familysave : [B
    //   58: aload_0
    //   59: iconst_1
    //   60: newarray int
    //   62: putfield graphics$baseRegisterIndex : [I
    //   65: aload_0
    //   66: sipush #680
    //   69: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   72: putfield init$ExtEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   75: aload_0
    //   76: bipush #100
    //   78: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   81: putfield init$CallEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   84: aload_0
    //   85: sipush #672
    //   88: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   91: putfield par$ParTable : Lorg/renjin/gcc/runtime/Ptr;
    //   94: aload_0
    //   95: bipush #24
    //   97: newarray short
    //   99: putfield plot3d$TickVector : [S
    //   102: aload_0
    //   103: bipush #8
    //   105: newarray short
    //   107: putfield plot3d$AxisStart : [S
    //   110: aload_0
    //   111: bipush #24
    //   113: newarray short
    //   115: putfield plot3d$Edge : [S
    //   118: aload_0
    //   119: bipush #24
    //   121: newarray short
    //   123: putfield plot3d$Face : [S
    //   126: aload_0
    //   127: bipush #24
    //   129: newarray short
    //   131: putfield plot3d$Vertex : [S
    //   134: aload_0
    //   135: iconst_4
    //   136: newarray double
    //   138: putfield plot3d$Light : [D
    //   141: aload_0
    //   142: bipush #16
    //   144: newarray double
    //   146: putfield plot3d$VT : [D
    //   149: aload_0
    //   150: sipush #232
    //   153: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   156: putfield plotmath$RelTable : Lorg/renjin/gcc/runtime/Ptr;
    //   159: aload_0
    //   160: bipush #96
    //   162: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   165: putfield plotmath$OpTable : Lorg/renjin/gcc/runtime/Ptr;
    //   168: aload_0
    //   169: bipush #40
    //   171: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   174: putfield plotmath$AccentTable : Lorg/renjin/gcc/runtime/Ptr;
    //   177: aload_0
    //   178: bipush #96
    //   180: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   183: putfield plotmath$BinTable : Lorg/renjin/gcc/runtime/Ptr;
    //   186: aload_0
    //   187: sipush #1536
    //   190: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   193: putfield plotmath$SymbolTable : Lorg/renjin/gcc/runtime/Ptr;
    //   196: aload_0
    //   197: bipush #17
    //   199: newarray int
    //   201: putfield sort$sincs : [I
    //   204: aload_0
    //   205: bipush #21
    //   207: newarray int
    //   209: putfield sort$incs : [I
    //   212: bipush #24
    //   214: newarray double
    //   216: dup
    //   217: iconst_0
    //   218: ldc2_w 0.1
    //   221: dastore
    //   222: dup
    //   223: iconst_1
    //   224: dconst_1
    //   225: dastore
    //   226: dup
    //   227: iconst_2
    //   228: ldc2_w 10.0
    //   231: dastore
    //   232: dup
    //   233: iconst_3
    //   234: ldc2_w 100.0
    //   237: dastore
    //   238: dup
    //   239: iconst_4
    //   240: ldc2_w 1000.0
    //   243: dastore
    //   244: dup
    //   245: iconst_5
    //   246: ldc2_w 10000.0
    //   249: dastore
    //   250: dup
    //   251: bipush #6
    //   253: ldc2_w 100000.0
    //   256: dastore
    //   257: dup
    //   258: bipush #7
    //   260: ldc2_w 1000000.0
    //   263: dastore
    //   264: dup
    //   265: bipush #8
    //   267: ldc2_w 1.0E7
    //   270: dastore
    //   271: dup
    //   272: bipush #9
    //   274: ldc2_w 1.0E8
    //   277: dastore
    //   278: dup
    //   279: bipush #10
    //   281: ldc2_w 1.0E9
    //   284: dastore
    //   285: dup
    //   286: bipush #11
    //   288: ldc2_w 1.0E10
    //   291: dastore
    //   292: dup
    //   293: bipush #12
    //   295: ldc2_w 1.0E11
    //   298: dastore
    //   299: dup
    //   300: bipush #13
    //   302: ldc2_w 1.0E12
    //   305: dastore
    //   306: dup
    //   307: bipush #14
    //   309: ldc2_w 1.0E13
    //   312: dastore
    //   313: dup
    //   314: bipush #15
    //   316: ldc2_w 1.0E14
    //   319: dastore
    //   320: dup
    //   321: bipush #16
    //   323: ldc2_w 1.0E15
    //   326: dastore
    //   327: dup
    //   328: bipush #17
    //   330: ldc2_w 1.0E16
    //   333: dastore
    //   334: dup
    //   335: bipush #18
    //   337: ldc2_w 1.0E17
    //   340: dastore
    //   341: dup
    //   342: bipush #19
    //   344: ldc2_w 1.0E18
    //   347: dastore
    //   348: dup
    //   349: bipush #20
    //   351: ldc2_w 1.0E19
    //   354: dastore
    //   355: dup
    //   356: bipush #21
    //   358: ldc2_w 1.0E20
    //   361: dastore
    //   362: dup
    //   363: bipush #22
    //   365: ldc2_w 1.0E21
    //   368: dastore
    //   369: dup
    //   370: bipush #23
    //   372: ldc2_w 1.0E22
    //   375: dastore
    //   376: iconst_0
    //   377: aload_0
    //   378: getfield format$tbl : [D
    //   381: iconst_0
    //   382: bipush #24
    //   384: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   387: aload_0
    //   388: iconst_0
    //   389: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   392: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
    //   397: putfield graphics$old_close : Ljava/lang/invoke/MethodHandle;
    //   400: sipush #680
    //   403: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   406: astore_1
    //   407: aload_1
    //   408: new org/renjin/gcc/runtime/BytePtr
    //   411: dup
    //   412: ldc_w 'C_contour '
    //   415: invokevirtual getBytes : ()[B
    //   418: iconst_0
    //   419: invokespecial <init> : ([BI)V
    //   422: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   427: aload_1
    //   428: iconst_1
    //   429: ldc_w
    //   432: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   435: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   440: aload_1
    //   441: iconst_2
    //   442: iconst_m1
    //   443: invokeinterface setAlignedInt : (II)V
    //   448: aload_1
    //   449: iconst_5
    //   450: new org/renjin/gcc/runtime/BytePtr
    //   453: dup
    //   454: ldc_w 'C_filledcontour '
    //   457: invokevirtual getBytes : ()[B
    //   460: iconst_0
    //   461: invokespecial <init> : ([BI)V
    //   464: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   469: aload_1
    //   470: bipush #6
    //   472: ldc_w
    //   475: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   478: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   483: aload_1
    //   484: bipush #7
    //   486: iconst_5
    //   487: invokeinterface setAlignedInt : (II)V
    //   492: aload_1
    //   493: bipush #10
    //   495: new org/renjin/gcc/runtime/BytePtr
    //   498: dup
    //   499: ldc_w 'C_image '
    //   502: invokevirtual getBytes : ()[B
    //   505: iconst_0
    //   506: invokespecial <init> : ([BI)V
    //   509: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   514: aload_1
    //   515: bipush #11
    //   517: ldc_w
    //   520: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   528: aload_1
    //   529: bipush #12
    //   531: iconst_4
    //   532: invokeinterface setAlignedInt : (II)V
    //   537: aload_1
    //   538: bipush #15
    //   540: new org/renjin/gcc/runtime/BytePtr
    //   543: dup
    //   544: ldc_w 'C_persp '
    //   547: invokevirtual getBytes : ()[B
    //   550: iconst_0
    //   551: invokespecial <init> : ([BI)V
    //   554: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   559: aload_1
    //   560: bipush #16
    //   562: ldc_w
    //   565: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   568: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   573: aload_1
    //   574: bipush #17
    //   576: iconst_m1
    //   577: invokeinterface setAlignedInt : (II)V
    //   582: aload_1
    //   583: bipush #20
    //   585: new org/renjin/gcc/runtime/BytePtr
    //   588: dup
    //   589: ldc_w 'C_abline '
    //   592: invokevirtual getBytes : ()[B
    //   595: iconst_0
    //   596: invokespecial <init> : ([BI)V
    //   599: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   604: aload_1
    //   605: bipush #21
    //   607: ldc_w
    //   610: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   613: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   618: aload_1
    //   619: bipush #22
    //   621: iconst_m1
    //   622: invokeinterface setAlignedInt : (II)V
    //   627: aload_1
    //   628: bipush #25
    //   630: new org/renjin/gcc/runtime/BytePtr
    //   633: dup
    //   634: ldc_w 'C_axis '
    //   637: invokevirtual getBytes : ()[B
    //   640: iconst_0
    //   641: invokespecial <init> : ([BI)V
    //   644: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   649: aload_1
    //   650: bipush #26
    //   652: ldc_w
    //   655: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   663: aload_1
    //   664: bipush #27
    //   666: iconst_m1
    //   667: invokeinterface setAlignedInt : (II)V
    //   672: aload_1
    //   673: bipush #30
    //   675: new org/renjin/gcc/runtime/BytePtr
    //   678: dup
    //   679: ldc_w 'C_arrows '
    //   682: invokevirtual getBytes : ()[B
    //   685: iconst_0
    //   686: invokespecial <init> : ([BI)V
    //   689: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   694: aload_1
    //   695: bipush #31
    //   697: ldc_w
    //   700: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   703: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   708: aload_1
    //   709: bipush #32
    //   711: iconst_m1
    //   712: invokeinterface setAlignedInt : (II)V
    //   717: aload_1
    //   718: bipush #35
    //   720: new org/renjin/gcc/runtime/BytePtr
    //   723: dup
    //   724: ldc_w 'C_box '
    //   727: invokevirtual getBytes : ()[B
    //   730: iconst_0
    //   731: invokespecial <init> : ([BI)V
    //   734: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   739: aload_1
    //   740: bipush #36
    //   742: ldc_w
    //   745: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   748: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   753: aload_1
    //   754: bipush #37
    //   756: iconst_m1
    //   757: invokeinterface setAlignedInt : (II)V
    //   762: aload_1
    //   763: bipush #40
    //   765: new org/renjin/gcc/runtime/BytePtr
    //   768: dup
    //   769: ldc_w 'C_clip '
    //   772: invokevirtual getBytes : ()[B
    //   775: iconst_0
    //   776: invokespecial <init> : ([BI)V
    //   779: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   784: aload_1
    //   785: bipush #41
    //   787: ldc_w
    //   790: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   793: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   798: aload_1
    //   799: bipush #42
    //   801: iconst_m1
    //   802: invokeinterface setAlignedInt : (II)V
    //   807: aload_1
    //   808: bipush #45
    //   810: new org/renjin/gcc/runtime/BytePtr
    //   813: dup
    //   814: ldc_w 'C_convertX '
    //   817: invokevirtual getBytes : ()[B
    //   820: iconst_0
    //   821: invokespecial <init> : ([BI)V
    //   824: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   829: aload_1
    //   830: bipush #46
    //   832: ldc_w
    //   835: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   838: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   843: aload_1
    //   844: bipush #47
    //   846: iconst_3
    //   847: invokeinterface setAlignedInt : (II)V
    //   852: aload_1
    //   853: bipush #50
    //   855: new org/renjin/gcc/runtime/BytePtr
    //   858: dup
    //   859: ldc_w 'C_convertY '
    //   862: invokevirtual getBytes : ()[B
    //   865: iconst_0
    //   866: invokespecial <init> : ([BI)V
    //   869: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   874: aload_1
    //   875: bipush #51
    //   877: ldc_w
    //   880: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   883: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   888: aload_1
    //   889: bipush #52
    //   891: iconst_3
    //   892: invokeinterface setAlignedInt : (II)V
    //   897: aload_1
    //   898: bipush #55
    //   900: new org/renjin/gcc/runtime/BytePtr
    //   903: dup
    //   904: ldc_w 'C_dend '
    //   907: invokevirtual getBytes : ()[B
    //   910: iconst_0
    //   911: invokespecial <init> : ([BI)V
    //   914: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   919: aload_1
    //   920: bipush #56
    //   922: ldc_w
    //   925: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   928: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   933: aload_1
    //   934: bipush #57
    //   936: iconst_m1
    //   937: invokeinterface setAlignedInt : (II)V
    //   942: aload_1
    //   943: bipush #60
    //   945: new org/renjin/gcc/runtime/BytePtr
    //   948: dup
    //   949: ldc_w 'C_dendwindow '
    //   952: invokevirtual getBytes : ()[B
    //   955: iconst_0
    //   956: invokespecial <init> : ([BI)V
    //   959: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   964: aload_1
    //   965: bipush #61
    //   967: ldc_w
    //   970: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   973: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   978: aload_1
    //   979: bipush #62
    //   981: iconst_m1
    //   982: invokeinterface setAlignedInt : (II)V
    //   987: aload_1
    //   988: bipush #65
    //   990: new org/renjin/gcc/runtime/BytePtr
    //   993: dup
    //   994: ldc_w 'C_erase '
    //   997: invokevirtual getBytes : ()[B
    //   1000: iconst_0
    //   1001: invokespecial <init> : ([BI)V
    //   1004: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1009: aload_1
    //   1010: bipush #66
    //   1012: ldc_w
    //   1015: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1018: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1023: aload_1
    //   1024: bipush #67
    //   1026: iconst_m1
    //   1027: invokeinterface setAlignedInt : (II)V
    //   1032: aload_1
    //   1033: bipush #70
    //   1035: new org/renjin/gcc/runtime/BytePtr
    //   1038: dup
    //   1039: ldc_w 'C_layout '
    //   1042: invokevirtual getBytes : ()[B
    //   1045: iconst_0
    //   1046: invokespecial <init> : ([BI)V
    //   1049: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1054: aload_1
    //   1055: bipush #71
    //   1057: ldc_w
    //   1060: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1063: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1068: aload_1
    //   1069: bipush #72
    //   1071: iconst_m1
    //   1072: invokeinterface setAlignedInt : (II)V
    //   1077: aload_1
    //   1078: bipush #75
    //   1080: new org/renjin/gcc/runtime/BytePtr
    //   1083: dup
    //   1084: ldc_w 'C_mtext '
    //   1087: invokevirtual getBytes : ()[B
    //   1090: iconst_0
    //   1091: invokespecial <init> : ([BI)V
    //   1094: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1099: aload_1
    //   1100: bipush #76
    //   1102: ldc_w
    //   1105: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1108: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1113: aload_1
    //   1114: bipush #77
    //   1116: iconst_m1
    //   1117: invokeinterface setAlignedInt : (II)V
    //   1122: aload_1
    //   1123: bipush #80
    //   1125: new org/renjin/gcc/runtime/BytePtr
    //   1128: dup
    //   1129: ldc_w 'C_par '
    //   1132: invokevirtual getBytes : ()[B
    //   1135: iconst_0
    //   1136: invokespecial <init> : ([BI)V
    //   1139: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1144: aload_1
    //   1145: bipush #81
    //   1147: ldc_w
    //   1150: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1153: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1158: aload_1
    //   1159: bipush #82
    //   1161: iconst_m1
    //   1162: invokeinterface setAlignedInt : (II)V
    //   1167: aload_1
    //   1168: bipush #85
    //   1170: new org/renjin/gcc/runtime/BytePtr
    //   1173: dup
    //   1174: ldc_w 'C_path '
    //   1177: invokevirtual getBytes : ()[B
    //   1180: iconst_0
    //   1181: invokespecial <init> : ([BI)V
    //   1184: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1189: aload_1
    //   1190: bipush #86
    //   1192: ldc_w
    //   1195: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1198: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1203: aload_1
    //   1204: bipush #87
    //   1206: iconst_m1
    //   1207: invokeinterface setAlignedInt : (II)V
    //   1212: aload_1
    //   1213: bipush #90
    //   1215: new org/renjin/gcc/runtime/BytePtr
    //   1218: dup
    //   1219: ldc_w 'C_plotXY '
    //   1222: invokevirtual getBytes : ()[B
    //   1225: iconst_0
    //   1226: invokespecial <init> : ([BI)V
    //   1229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1234: aload_1
    //   1235: bipush #91
    //   1237: ldc_w
    //   1240: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1243: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1248: aload_1
    //   1249: bipush #92
    //   1251: iconst_m1
    //   1252: invokeinterface setAlignedInt : (II)V
    //   1257: aload_1
    //   1258: bipush #95
    //   1260: new org/renjin/gcc/runtime/BytePtr
    //   1263: dup
    //   1264: ldc_w 'C_plot_window '
    //   1267: invokevirtual getBytes : ()[B
    //   1270: iconst_0
    //   1271: invokespecial <init> : ([BI)V
    //   1274: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1279: aload_1
    //   1280: bipush #96
    //   1282: ldc_w
    //   1285: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1288: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1293: aload_1
    //   1294: bipush #97
    //   1296: iconst_m1
    //   1297: invokeinterface setAlignedInt : (II)V
    //   1302: aload_1
    //   1303: bipush #100
    //   1305: new org/renjin/gcc/runtime/BytePtr
    //   1308: dup
    //   1309: ldc_w 'C_polygon '
    //   1312: invokevirtual getBytes : ()[B
    //   1315: iconst_0
    //   1316: invokespecial <init> : ([BI)V
    //   1319: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1324: aload_1
    //   1325: bipush #101
    //   1327: ldc_w
    //   1330: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1333: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1338: aload_1
    //   1339: bipush #102
    //   1341: iconst_m1
    //   1342: invokeinterface setAlignedInt : (II)V
    //   1347: aload_1
    //   1348: bipush #105
    //   1350: new org/renjin/gcc/runtime/BytePtr
    //   1353: dup
    //   1354: ldc_w 'C_raster '
    //   1357: invokevirtual getBytes : ()[B
    //   1360: iconst_0
    //   1361: invokespecial <init> : ([BI)V
    //   1364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1369: aload_1
    //   1370: bipush #106
    //   1372: ldc_w
    //   1375: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1378: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1383: aload_1
    //   1384: bipush #107
    //   1386: iconst_m1
    //   1387: invokeinterface setAlignedInt : (II)V
    //   1392: aload_1
    //   1393: bipush #110
    //   1395: new org/renjin/gcc/runtime/BytePtr
    //   1398: dup
    //   1399: ldc_w 'C_rect '
    //   1402: invokevirtual getBytes : ()[B
    //   1405: iconst_0
    //   1406: invokespecial <init> : ([BI)V
    //   1409: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1414: aload_1
    //   1415: bipush #111
    //   1417: ldc_w
    //   1420: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1423: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1428: aload_1
    //   1429: bipush #112
    //   1431: iconst_m1
    //   1432: invokeinterface setAlignedInt : (II)V
    //   1437: aload_1
    //   1438: bipush #115
    //   1440: new org/renjin/gcc/runtime/BytePtr
    //   1443: dup
    //   1444: ldc_w 'C_segments '
    //   1447: invokevirtual getBytes : ()[B
    //   1450: iconst_0
    //   1451: invokespecial <init> : ([BI)V
    //   1454: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1459: aload_1
    //   1460: bipush #116
    //   1462: ldc_w
    //   1465: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1468: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1473: aload_1
    //   1474: bipush #117
    //   1476: iconst_m1
    //   1477: invokeinterface setAlignedInt : (II)V
    //   1482: aload_1
    //   1483: bipush #120
    //   1485: new org/renjin/gcc/runtime/BytePtr
    //   1488: dup
    //   1489: ldc_w 'C_strHeight '
    //   1492: invokevirtual getBytes : ()[B
    //   1495: iconst_0
    //   1496: invokespecial <init> : ([BI)V
    //   1499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1504: aload_1
    //   1505: bipush #121
    //   1507: ldc_w
    //   1510: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1513: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1518: aload_1
    //   1519: bipush #122
    //   1521: iconst_m1
    //   1522: invokeinterface setAlignedInt : (II)V
    //   1527: aload_1
    //   1528: bipush #125
    //   1530: new org/renjin/gcc/runtime/BytePtr
    //   1533: dup
    //   1534: ldc_w 'C_strWidth '
    //   1537: invokevirtual getBytes : ()[B
    //   1540: iconst_0
    //   1541: invokespecial <init> : ([BI)V
    //   1544: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1549: aload_1
    //   1550: bipush #126
    //   1552: ldc_w
    //   1555: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1558: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1563: aload_1
    //   1564: bipush #127
    //   1566: iconst_m1
    //   1567: invokeinterface setAlignedInt : (II)V
    //   1572: aload_1
    //   1573: sipush #130
    //   1576: new org/renjin/gcc/runtime/BytePtr
    //   1579: dup
    //   1580: ldc_w 'C_symbols '
    //   1583: invokevirtual getBytes : ()[B
    //   1586: iconst_0
    //   1587: invokespecial <init> : ([BI)V
    //   1590: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1595: aload_1
    //   1596: sipush #131
    //   1599: ldc_w
    //   1602: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1605: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1610: aload_1
    //   1611: sipush #132
    //   1614: iconst_m1
    //   1615: invokeinterface setAlignedInt : (II)V
    //   1620: aload_1
    //   1621: sipush #135
    //   1624: new org/renjin/gcc/runtime/BytePtr
    //   1627: dup
    //   1628: ldc_w 'C_text '
    //   1631: invokevirtual getBytes : ()[B
    //   1634: iconst_0
    //   1635: invokespecial <init> : ([BI)V
    //   1638: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1643: aload_1
    //   1644: sipush #136
    //   1647: ldc_w
    //   1650: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1653: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1658: aload_1
    //   1659: sipush #137
    //   1662: iconst_m1
    //   1663: invokeinterface setAlignedInt : (II)V
    //   1668: aload_1
    //   1669: sipush #140
    //   1672: new org/renjin/gcc/runtime/BytePtr
    //   1675: dup
    //   1676: ldc_w 'C_title '
    //   1679: invokevirtual getBytes : ()[B
    //   1682: iconst_0
    //   1683: invokespecial <init> : ([BI)V
    //   1686: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1691: aload_1
    //   1692: sipush #141
    //   1695: ldc_w
    //   1698: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1701: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1706: aload_1
    //   1707: sipush #142
    //   1710: iconst_m1
    //   1711: invokeinterface setAlignedInt : (II)V
    //   1716: aload_1
    //   1717: sipush #145
    //   1720: new org/renjin/gcc/runtime/BytePtr
    //   1723: dup
    //   1724: ldc_w 'C_xspline '
    //   1727: invokevirtual getBytes : ()[B
    //   1730: iconst_0
    //   1731: invokespecial <init> : ([BI)V
    //   1734: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1739: aload_1
    //   1740: sipush #146
    //   1743: ldc_w
    //   1746: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1749: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1754: aload_1
    //   1755: sipush #147
    //   1758: iconst_m1
    //   1759: invokeinterface setAlignedInt : (II)V
    //   1764: aload_1
    //   1765: sipush #150
    //   1768: new org/renjin/gcc/runtime/BytePtr
    //   1771: dup
    //   1772: ldc_w 'C_plot_new '
    //   1775: invokevirtual getBytes : ()[B
    //   1778: iconst_0
    //   1779: invokespecial <init> : ([BI)V
    //   1782: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1787: aload_1
    //   1788: sipush #151
    //   1791: ldc_w
    //   1794: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1797: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1802: aload_1
    //   1803: sipush #152
    //   1806: iconst_0
    //   1807: invokeinterface setAlignedInt : (II)V
    //   1812: aload_1
    //   1813: sipush #155
    //   1816: new org/renjin/gcc/runtime/BytePtr
    //   1819: dup
    //   1820: ldc_w 'C_locator '
    //   1823: invokevirtual getBytes : ()[B
    //   1826: iconst_0
    //   1827: invokespecial <init> : ([BI)V
    //   1830: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1835: aload_1
    //   1836: sipush #156
    //   1839: ldc_w
    //   1842: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1845: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1850: aload_1
    //   1851: sipush #157
    //   1854: iconst_m1
    //   1855: invokeinterface setAlignedInt : (II)V
    //   1860: aload_1
    //   1861: sipush #160
    //   1864: new org/renjin/gcc/runtime/BytePtr
    //   1867: dup
    //   1868: ldc_w 'C_identify '
    //   1871: invokevirtual getBytes : ()[B
    //   1874: iconst_0
    //   1875: invokespecial <init> : ([BI)V
    //   1878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1883: aload_1
    //   1884: sipush #161
    //   1887: ldc_w
    //   1890: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1893: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1898: aload_1
    //   1899: sipush #162
    //   1902: iconst_m1
    //   1903: invokeinterface setAlignedInt : (II)V
    //   1908: aload_1
    //   1909: sipush #165
    //   1912: iconst_0
    //   1913: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1916: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1921: aload_1
    //   1922: sipush #166
    //   1925: iconst_0
    //   1926: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1929: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1934: aload_1
    //   1935: sipush #167
    //   1938: iconst_0
    //   1939: invokeinterface setAlignedInt : (II)V
    //   1944: aload_0
    //   1945: getfield init$ExtEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   1948: aload_1
    //   1949: sipush #680
    //   1952: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1957: bipush #100
    //   1959: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   1962: astore_2
    //   1963: aload_2
    //   1964: new org/renjin/gcc/runtime/BytePtr
    //   1967: dup
    //   1968: ldc_w 'C_contourDef '
    //   1971: invokevirtual getBytes : ()[B
    //   1974: iconst_0
    //   1975: invokespecial <init> : ([BI)V
    //   1978: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   1983: aload_2
    //   1984: iconst_1
    //   1985: ldc_w
    //   1988: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   1991: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1996: aload_2
    //   1997: iconst_2
    //   1998: iconst_0
    //   1999: invokeinterface setAlignedInt : (II)V
    //   2004: aload_2
    //   2005: iconst_5
    //   2006: new org/renjin/gcc/runtime/BytePtr
    //   2009: dup
    //   2010: ldc_w 'C_StemLeaf '
    //   2013: invokevirtual getBytes : ()[B
    //   2016: iconst_0
    //   2017: invokespecial <init> : ([BI)V
    //   2020: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2025: aload_2
    //   2026: bipush #6
    //   2028: ldc_w
    //   2031: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2034: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2039: aload_2
    //   2040: bipush #7
    //   2042: iconst_4
    //   2043: invokeinterface setAlignedInt : (II)V
    //   2048: aload_2
    //   2049: bipush #10
    //   2051: new org/renjin/gcc/runtime/BytePtr
    //   2054: dup
    //   2055: ldc_w 'C_BinCount '
    //   2058: invokevirtual getBytes : ()[B
    //   2061: iconst_0
    //   2062: invokespecial <init> : ([BI)V
    //   2065: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2070: aload_2
    //   2071: bipush #11
    //   2073: ldc_w
    //   2076: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2079: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2084: aload_2
    //   2085: bipush #12
    //   2087: iconst_4
    //   2088: invokeinterface setAlignedInt : (II)V
    //   2093: aload_2
    //   2094: bipush #15
    //   2096: new org/renjin/gcc/runtime/BytePtr
    //   2099: dup
    //   2100: ldc_w 'RunregisterBase '
    //   2103: invokevirtual getBytes : ()[B
    //   2106: iconst_0
    //   2107: invokespecial <init> : ([BI)V
    //   2110: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2115: aload_2
    //   2116: bipush #16
    //   2118: ldc_w
    //   2121: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   2124: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2129: aload_2
    //   2130: bipush #17
    //   2132: iconst_0
    //   2133: invokeinterface setAlignedInt : (II)V
    //   2138: aload_2
    //   2139: bipush #20
    //   2141: iconst_0
    //   2142: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2145: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2150: aload_2
    //   2151: bipush #21
    //   2153: iconst_0
    //   2154: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   2157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2162: aload_2
    //   2163: bipush #22
    //   2165: iconst_0
    //   2166: invokeinterface setAlignedInt : (II)V
    //   2171: aload_0
    //   2172: getfield init$CallEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   2175: aload_2
    //   2176: bipush #100
    //   2178: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   2183: sipush #672
    //   2186: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   2189: astore_3
    //   2190: aload_3
    //   2191: new org/renjin/gcc/runtime/BytePtr
    //   2194: dup
    //   2195: ldc_w 'adj '
    //   2198: invokevirtual getBytes : ()[B
    //   2201: iconst_0
    //   2202: invokespecial <init> : ([BI)V
    //   2205: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   2210: aload_3
    //   2211: iconst_1
    //   2212: iconst_0
    //   2213: invokeinterface setAlignedInt : (II)V
    //   2218: aload_3
    //   2219: iconst_2
    //   2220: new org/renjin/gcc/runtime/BytePtr
    //   2223: dup
    //   2224: ldc_w 'ann '
    //   2227: invokevirtual getBytes : ()[B
    //   2230: iconst_0
    //   2231: invokespecial <init> : ([BI)V
    //   2234: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2239: aload_3
    //   2240: iconst_3
    //   2241: iconst_0
    //   2242: invokeinterface setAlignedInt : (II)V
    //   2247: aload_3
    //   2248: iconst_4
    //   2249: new org/renjin/gcc/runtime/BytePtr
    //   2252: dup
    //   2253: ldc_w 'ask '
    //   2256: invokevirtual getBytes : ()[B
    //   2259: iconst_0
    //   2260: invokespecial <init> : ([BI)V
    //   2263: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2268: aload_3
    //   2269: iconst_5
    //   2270: iconst_1
    //   2271: invokeinterface setAlignedInt : (II)V
    //   2276: aload_3
    //   2277: bipush #6
    //   2279: new org/renjin/gcc/runtime/BytePtr
    //   2282: dup
    //   2283: ldc_w 'bg '
    //   2286: invokevirtual getBytes : ()[B
    //   2289: iconst_0
    //   2290: invokespecial <init> : ([BI)V
    //   2293: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2298: aload_3
    //   2299: bipush #7
    //   2301: iconst_0
    //   2302: invokeinterface setAlignedInt : (II)V
    //   2307: aload_3
    //   2308: bipush #8
    //   2310: new org/renjin/gcc/runtime/BytePtr
    //   2313: dup
    //   2314: ldc_w 'bty '
    //   2317: invokevirtual getBytes : ()[B
    //   2320: iconst_0
    //   2321: invokespecial <init> : ([BI)V
    //   2324: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2329: aload_3
    //   2330: bipush #9
    //   2332: iconst_0
    //   2333: invokeinterface setAlignedInt : (II)V
    //   2338: aload_3
    //   2339: bipush #10
    //   2341: new org/renjin/gcc/runtime/BytePtr
    //   2344: dup
    //   2345: ldc_w 'cex '
    //   2348: invokevirtual getBytes : ()[B
    //   2351: iconst_0
    //   2352: invokespecial <init> : ([BI)V
    //   2355: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2360: aload_3
    //   2361: bipush #11
    //   2363: iconst_0
    //   2364: invokeinterface setAlignedInt : (II)V
    //   2369: aload_3
    //   2370: bipush #12
    //   2372: new org/renjin/gcc/runtime/BytePtr
    //   2375: dup
    //   2376: ldc_w 'cex.axis '
    //   2379: invokevirtual getBytes : ()[B
    //   2382: iconst_0
    //   2383: invokespecial <init> : ([BI)V
    //   2386: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2391: aload_3
    //   2392: bipush #13
    //   2394: iconst_0
    //   2395: invokeinterface setAlignedInt : (II)V
    //   2400: aload_3
    //   2401: bipush #14
    //   2403: new org/renjin/gcc/runtime/BytePtr
    //   2406: dup
    //   2407: ldc_w 'cex.lab '
    //   2410: invokevirtual getBytes : ()[B
    //   2413: iconst_0
    //   2414: invokespecial <init> : ([BI)V
    //   2417: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2422: aload_3
    //   2423: bipush #15
    //   2425: iconst_0
    //   2426: invokeinterface setAlignedInt : (II)V
    //   2431: aload_3
    //   2432: bipush #16
    //   2434: new org/renjin/gcc/runtime/BytePtr
    //   2437: dup
    //   2438: ldc_w 'cex.main '
    //   2441: invokevirtual getBytes : ()[B
    //   2444: iconst_0
    //   2445: invokespecial <init> : ([BI)V
    //   2448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2453: aload_3
    //   2454: bipush #17
    //   2456: iconst_0
    //   2457: invokeinterface setAlignedInt : (II)V
    //   2462: aload_3
    //   2463: bipush #18
    //   2465: new org/renjin/gcc/runtime/BytePtr
    //   2468: dup
    //   2469: ldc_w 'cex.sub '
    //   2472: invokevirtual getBytes : ()[B
    //   2475: iconst_0
    //   2476: invokespecial <init> : ([BI)V
    //   2479: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2484: aload_3
    //   2485: bipush #19
    //   2487: iconst_0
    //   2488: invokeinterface setAlignedInt : (II)V
    //   2493: aload_3
    //   2494: bipush #20
    //   2496: new org/renjin/gcc/runtime/BytePtr
    //   2499: dup
    //   2500: ldc_w 'cin '
    //   2503: invokevirtual getBytes : ()[B
    //   2506: iconst_0
    //   2507: invokespecial <init> : ([BI)V
    //   2510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2515: aload_3
    //   2516: bipush #21
    //   2518: iconst_2
    //   2519: invokeinterface setAlignedInt : (II)V
    //   2524: aload_3
    //   2525: bipush #22
    //   2527: new org/renjin/gcc/runtime/BytePtr
    //   2530: dup
    //   2531: ldc_w 'col '
    //   2534: invokevirtual getBytes : ()[B
    //   2537: iconst_0
    //   2538: invokespecial <init> : ([BI)V
    //   2541: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2546: aload_3
    //   2547: bipush #23
    //   2549: iconst_0
    //   2550: invokeinterface setAlignedInt : (II)V
    //   2555: aload_3
    //   2556: bipush #24
    //   2558: new org/renjin/gcc/runtime/BytePtr
    //   2561: dup
    //   2562: ldc_w 'col.axis '
    //   2565: invokevirtual getBytes : ()[B
    //   2568: iconst_0
    //   2569: invokespecial <init> : ([BI)V
    //   2572: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2577: aload_3
    //   2578: bipush #25
    //   2580: iconst_0
    //   2581: invokeinterface setAlignedInt : (II)V
    //   2586: aload_3
    //   2587: bipush #26
    //   2589: new org/renjin/gcc/runtime/BytePtr
    //   2592: dup
    //   2593: ldc_w 'col.lab '
    //   2596: invokevirtual getBytes : ()[B
    //   2599: iconst_0
    //   2600: invokespecial <init> : ([BI)V
    //   2603: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2608: aload_3
    //   2609: bipush #27
    //   2611: iconst_0
    //   2612: invokeinterface setAlignedInt : (II)V
    //   2617: aload_3
    //   2618: bipush #28
    //   2620: new org/renjin/gcc/runtime/BytePtr
    //   2623: dup
    //   2624: ldc_w 'col.main '
    //   2627: invokevirtual getBytes : ()[B
    //   2630: iconst_0
    //   2631: invokespecial <init> : ([BI)V
    //   2634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2639: aload_3
    //   2640: bipush #29
    //   2642: iconst_0
    //   2643: invokeinterface setAlignedInt : (II)V
    //   2648: aload_3
    //   2649: bipush #30
    //   2651: new org/renjin/gcc/runtime/BytePtr
    //   2654: dup
    //   2655: ldc_w 'col.sub '
    //   2658: invokevirtual getBytes : ()[B
    //   2661: iconst_0
    //   2662: invokespecial <init> : ([BI)V
    //   2665: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2670: aload_3
    //   2671: bipush #31
    //   2673: iconst_0
    //   2674: invokeinterface setAlignedInt : (II)V
    //   2679: aload_3
    //   2680: bipush #32
    //   2682: new org/renjin/gcc/runtime/BytePtr
    //   2685: dup
    //   2686: ldc_w 'cra '
    //   2689: invokevirtual getBytes : ()[B
    //   2692: iconst_0
    //   2693: invokespecial <init> : ([BI)V
    //   2696: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2701: aload_3
    //   2702: bipush #33
    //   2704: iconst_2
    //   2705: invokeinterface setAlignedInt : (II)V
    //   2710: aload_3
    //   2711: bipush #34
    //   2713: new org/renjin/gcc/runtime/BytePtr
    //   2716: dup
    //   2717: ldc_w 'crt '
    //   2720: invokevirtual getBytes : ()[B
    //   2723: iconst_0
    //   2724: invokespecial <init> : ([BI)V
    //   2727: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2732: aload_3
    //   2733: bipush #35
    //   2735: iconst_0
    //   2736: invokeinterface setAlignedInt : (II)V
    //   2741: aload_3
    //   2742: bipush #36
    //   2744: new org/renjin/gcc/runtime/BytePtr
    //   2747: dup
    //   2748: ldc_w 'csi '
    //   2751: invokevirtual getBytes : ()[B
    //   2754: iconst_0
    //   2755: invokespecial <init> : ([BI)V
    //   2758: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2763: aload_3
    //   2764: bipush #37
    //   2766: iconst_2
    //   2767: invokeinterface setAlignedInt : (II)V
    //   2772: aload_3
    //   2773: bipush #38
    //   2775: new org/renjin/gcc/runtime/BytePtr
    //   2778: dup
    //   2779: ldc_w 'csy '
    //   2782: invokevirtual getBytes : ()[B
    //   2785: iconst_0
    //   2786: invokespecial <init> : ([BI)V
    //   2789: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2794: aload_3
    //   2795: bipush #39
    //   2797: iconst_0
    //   2798: invokeinterface setAlignedInt : (II)V
    //   2803: aload_3
    //   2804: bipush #40
    //   2806: new org/renjin/gcc/runtime/BytePtr
    //   2809: dup
    //   2810: ldc_w 'cxy '
    //   2813: invokevirtual getBytes : ()[B
    //   2816: iconst_0
    //   2817: invokespecial <init> : ([BI)V
    //   2820: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2825: aload_3
    //   2826: bipush #41
    //   2828: iconst_2
    //   2829: invokeinterface setAlignedInt : (II)V
    //   2834: aload_3
    //   2835: bipush #42
    //   2837: new org/renjin/gcc/runtime/BytePtr
    //   2840: dup
    //   2841: ldc_w 'din '
    //   2844: invokevirtual getBytes : ()[B
    //   2847: iconst_0
    //   2848: invokespecial <init> : ([BI)V
    //   2851: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2856: aload_3
    //   2857: bipush #43
    //   2859: iconst_2
    //   2860: invokeinterface setAlignedInt : (II)V
    //   2865: aload_3
    //   2866: bipush #44
    //   2868: new org/renjin/gcc/runtime/BytePtr
    //   2871: dup
    //   2872: ldc_w 'err '
    //   2875: invokevirtual getBytes : ()[B
    //   2878: iconst_0
    //   2879: invokespecial <init> : ([BI)V
    //   2882: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2887: aload_3
    //   2888: bipush #45
    //   2890: iconst_0
    //   2891: invokeinterface setAlignedInt : (II)V
    //   2896: aload_3
    //   2897: bipush #46
    //   2899: new org/renjin/gcc/runtime/BytePtr
    //   2902: dup
    //   2903: ldc_w 'family '
    //   2906: invokevirtual getBytes : ()[B
    //   2909: iconst_0
    //   2910: invokespecial <init> : ([BI)V
    //   2913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2918: aload_3
    //   2919: bipush #47
    //   2921: iconst_0
    //   2922: invokeinterface setAlignedInt : (II)V
    //   2927: aload_3
    //   2928: bipush #48
    //   2930: new org/renjin/gcc/runtime/BytePtr
    //   2933: dup
    //   2934: ldc_w 'fg '
    //   2937: invokevirtual getBytes : ()[B
    //   2940: iconst_0
    //   2941: invokespecial <init> : ([BI)V
    //   2944: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2949: aload_3
    //   2950: bipush #49
    //   2952: iconst_0
    //   2953: invokeinterface setAlignedInt : (II)V
    //   2958: aload_3
    //   2959: bipush #50
    //   2961: new org/renjin/gcc/runtime/BytePtr
    //   2964: dup
    //   2965: ldc_w 'fig '
    //   2968: invokevirtual getBytes : ()[B
    //   2971: iconst_0
    //   2972: invokespecial <init> : ([BI)V
    //   2975: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2980: aload_3
    //   2981: bipush #51
    //   2983: iconst_1
    //   2984: invokeinterface setAlignedInt : (II)V
    //   2989: aload_3
    //   2990: bipush #52
    //   2992: new org/renjin/gcc/runtime/BytePtr
    //   2995: dup
    //   2996: ldc_w 'fin '
    //   2999: invokevirtual getBytes : ()[B
    //   3002: iconst_0
    //   3003: invokespecial <init> : ([BI)V
    //   3006: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3011: aload_3
    //   3012: bipush #53
    //   3014: iconst_1
    //   3015: invokeinterface setAlignedInt : (II)V
    //   3020: aload_3
    //   3021: bipush #54
    //   3023: new org/renjin/gcc/runtime/BytePtr
    //   3026: dup
    //   3027: ldc_w 'font '
    //   3030: invokevirtual getBytes : ()[B
    //   3033: iconst_0
    //   3034: invokespecial <init> : ([BI)V
    //   3037: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3042: aload_3
    //   3043: bipush #55
    //   3045: iconst_0
    //   3046: invokeinterface setAlignedInt : (II)V
    //   3051: aload_3
    //   3052: bipush #56
    //   3054: new org/renjin/gcc/runtime/BytePtr
    //   3057: dup
    //   3058: ldc_w 'font.axis '
    //   3061: invokevirtual getBytes : ()[B
    //   3064: iconst_0
    //   3065: invokespecial <init> : ([BI)V
    //   3068: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3073: aload_3
    //   3074: bipush #57
    //   3076: iconst_0
    //   3077: invokeinterface setAlignedInt : (II)V
    //   3082: aload_3
    //   3083: bipush #58
    //   3085: new org/renjin/gcc/runtime/BytePtr
    //   3088: dup
    //   3089: ldc_w 'font.lab '
    //   3092: invokevirtual getBytes : ()[B
    //   3095: iconst_0
    //   3096: invokespecial <init> : ([BI)V
    //   3099: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3104: aload_3
    //   3105: bipush #59
    //   3107: iconst_0
    //   3108: invokeinterface setAlignedInt : (II)V
    //   3113: aload_3
    //   3114: bipush #60
    //   3116: new org/renjin/gcc/runtime/BytePtr
    //   3119: dup
    //   3120: ldc_w 'font.main '
    //   3123: invokevirtual getBytes : ()[B
    //   3126: iconst_0
    //   3127: invokespecial <init> : ([BI)V
    //   3130: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3135: aload_3
    //   3136: bipush #61
    //   3138: iconst_0
    //   3139: invokeinterface setAlignedInt : (II)V
    //   3144: aload_3
    //   3145: bipush #62
    //   3147: new org/renjin/gcc/runtime/BytePtr
    //   3150: dup
    //   3151: ldc_w 'font.sub '
    //   3154: invokevirtual getBytes : ()[B
    //   3157: iconst_0
    //   3158: invokespecial <init> : ([BI)V
    //   3161: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3166: aload_3
    //   3167: bipush #63
    //   3169: iconst_0
    //   3170: invokeinterface setAlignedInt : (II)V
    //   3175: aload_3
    //   3176: bipush #64
    //   3178: new org/renjin/gcc/runtime/BytePtr
    //   3181: dup
    //   3182: ldc_w 'lab '
    //   3185: invokevirtual getBytes : ()[B
    //   3188: iconst_0
    //   3189: invokespecial <init> : ([BI)V
    //   3192: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3197: aload_3
    //   3198: bipush #65
    //   3200: iconst_0
    //   3201: invokeinterface setAlignedInt : (II)V
    //   3206: aload_3
    //   3207: bipush #66
    //   3209: new org/renjin/gcc/runtime/BytePtr
    //   3212: dup
    //   3213: ldc_w 'las '
    //   3216: invokevirtual getBytes : ()[B
    //   3219: iconst_0
    //   3220: invokespecial <init> : ([BI)V
    //   3223: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3228: aload_3
    //   3229: bipush #67
    //   3231: iconst_0
    //   3232: invokeinterface setAlignedInt : (II)V
    //   3237: aload_3
    //   3238: bipush #68
    //   3240: new org/renjin/gcc/runtime/BytePtr
    //   3243: dup
    //   3244: ldc_w 'lend '
    //   3247: invokevirtual getBytes : ()[B
    //   3250: iconst_0
    //   3251: invokespecial <init> : ([BI)V
    //   3254: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3259: aload_3
    //   3260: bipush #69
    //   3262: iconst_0
    //   3263: invokeinterface setAlignedInt : (II)V
    //   3268: aload_3
    //   3269: bipush #70
    //   3271: new org/renjin/gcc/runtime/BytePtr
    //   3274: dup
    //   3275: ldc_w 'lheight '
    //   3278: invokevirtual getBytes : ()[B
    //   3281: iconst_0
    //   3282: invokespecial <init> : ([BI)V
    //   3285: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3290: aload_3
    //   3291: bipush #71
    //   3293: iconst_1
    //   3294: invokeinterface setAlignedInt : (II)V
    //   3299: aload_3
    //   3300: bipush #72
    //   3302: new org/renjin/gcc/runtime/BytePtr
    //   3305: dup
    //   3306: ldc_w 'ljoin '
    //   3309: invokevirtual getBytes : ()[B
    //   3312: iconst_0
    //   3313: invokespecial <init> : ([BI)V
    //   3316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3321: aload_3
    //   3322: bipush #73
    //   3324: iconst_0
    //   3325: invokeinterface setAlignedInt : (II)V
    //   3330: aload_3
    //   3331: bipush #74
    //   3333: new org/renjin/gcc/runtime/BytePtr
    //   3336: dup
    //   3337: ldc_w 'lmitre '
    //   3340: invokevirtual getBytes : ()[B
    //   3343: iconst_0
    //   3344: invokespecial <init> : ([BI)V
    //   3347: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3352: aload_3
    //   3353: bipush #75
    //   3355: iconst_0
    //   3356: invokeinterface setAlignedInt : (II)V
    //   3361: aload_3
    //   3362: bipush #76
    //   3364: new org/renjin/gcc/runtime/BytePtr
    //   3367: dup
    //   3368: ldc_w 'lty '
    //   3371: invokevirtual getBytes : ()[B
    //   3374: iconst_0
    //   3375: invokespecial <init> : ([BI)V
    //   3378: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3383: aload_3
    //   3384: bipush #77
    //   3386: iconst_0
    //   3387: invokeinterface setAlignedInt : (II)V
    //   3392: aload_3
    //   3393: bipush #78
    //   3395: new org/renjin/gcc/runtime/BytePtr
    //   3398: dup
    //   3399: ldc_w 'lwd '
    //   3402: invokevirtual getBytes : ()[B
    //   3405: iconst_0
    //   3406: invokespecial <init> : ([BI)V
    //   3409: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3414: aload_3
    //   3415: bipush #79
    //   3417: iconst_0
    //   3418: invokeinterface setAlignedInt : (II)V
    //   3423: aload_3
    //   3424: bipush #80
    //   3426: new org/renjin/gcc/runtime/BytePtr
    //   3429: dup
    //   3430: ldc_w 'mai '
    //   3433: invokevirtual getBytes : ()[B
    //   3436: iconst_0
    //   3437: invokespecial <init> : ([BI)V
    //   3440: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3445: aload_3
    //   3446: bipush #81
    //   3448: iconst_1
    //   3449: invokeinterface setAlignedInt : (II)V
    //   3454: aload_3
    //   3455: bipush #82
    //   3457: new org/renjin/gcc/runtime/BytePtr
    //   3460: dup
    //   3461: ldc_w 'mar '
    //   3464: invokevirtual getBytes : ()[B
    //   3467: iconst_0
    //   3468: invokespecial <init> : ([BI)V
    //   3471: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3476: aload_3
    //   3477: bipush #83
    //   3479: iconst_1
    //   3480: invokeinterface setAlignedInt : (II)V
    //   3485: aload_3
    //   3486: bipush #84
    //   3488: new org/renjin/gcc/runtime/BytePtr
    //   3491: dup
    //   3492: ldc_w 'mex '
    //   3495: invokevirtual getBytes : ()[B
    //   3498: iconst_0
    //   3499: invokespecial <init> : ([BI)V
    //   3502: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3507: aload_3
    //   3508: bipush #85
    //   3510: iconst_1
    //   3511: invokeinterface setAlignedInt : (II)V
    //   3516: aload_3
    //   3517: bipush #86
    //   3519: new org/renjin/gcc/runtime/BytePtr
    //   3522: dup
    //   3523: ldc_w 'mfcol '
    //   3526: invokevirtual getBytes : ()[B
    //   3529: iconst_0
    //   3530: invokespecial <init> : ([BI)V
    //   3533: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3538: aload_3
    //   3539: bipush #87
    //   3541: iconst_1
    //   3542: invokeinterface setAlignedInt : (II)V
    //   3547: aload_3
    //   3548: bipush #88
    //   3550: new org/renjin/gcc/runtime/BytePtr
    //   3553: dup
    //   3554: ldc_w 'mfg '
    //   3557: invokevirtual getBytes : ()[B
    //   3560: iconst_0
    //   3561: invokespecial <init> : ([BI)V
    //   3564: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3569: aload_3
    //   3570: bipush #89
    //   3572: iconst_1
    //   3573: invokeinterface setAlignedInt : (II)V
    //   3578: aload_3
    //   3579: bipush #90
    //   3581: new org/renjin/gcc/runtime/BytePtr
    //   3584: dup
    //   3585: ldc_w 'mfrow '
    //   3588: invokevirtual getBytes : ()[B
    //   3591: iconst_0
    //   3592: invokespecial <init> : ([BI)V
    //   3595: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3600: aload_3
    //   3601: bipush #91
    //   3603: iconst_1
    //   3604: invokeinterface setAlignedInt : (II)V
    //   3609: aload_3
    //   3610: bipush #92
    //   3612: new org/renjin/gcc/runtime/BytePtr
    //   3615: dup
    //   3616: ldc_w 'mgp '
    //   3619: invokevirtual getBytes : ()[B
    //   3622: iconst_0
    //   3623: invokespecial <init> : ([BI)V
    //   3626: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3631: aload_3
    //   3632: bipush #93
    //   3634: iconst_0
    //   3635: invokeinterface setAlignedInt : (II)V
    //   3640: aload_3
    //   3641: bipush #94
    //   3643: new org/renjin/gcc/runtime/BytePtr
    //   3646: dup
    //   3647: ldc_w 'mkh '
    //   3650: invokevirtual getBytes : ()[B
    //   3653: iconst_0
    //   3654: invokespecial <init> : ([BI)V
    //   3657: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3662: aload_3
    //   3663: bipush #95
    //   3665: iconst_0
    //   3666: invokeinterface setAlignedInt : (II)V
    //   3671: aload_3
    //   3672: bipush #96
    //   3674: new org/renjin/gcc/runtime/BytePtr
    //   3677: dup
    //   3678: ldc_w 'new '
    //   3681: invokevirtual getBytes : ()[B
    //   3684: iconst_0
    //   3685: invokespecial <init> : ([BI)V
    //   3688: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3693: aload_3
    //   3694: bipush #97
    //   3696: iconst_1
    //   3697: invokeinterface setAlignedInt : (II)V
    //   3702: aload_3
    //   3703: bipush #98
    //   3705: new org/renjin/gcc/runtime/BytePtr
    //   3708: dup
    //   3709: ldc_w 'oma '
    //   3712: invokevirtual getBytes : ()[B
    //   3715: iconst_0
    //   3716: invokespecial <init> : ([BI)V
    //   3719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3724: aload_3
    //   3725: bipush #99
    //   3727: iconst_1
    //   3728: invokeinterface setAlignedInt : (II)V
    //   3733: aload_3
    //   3734: bipush #100
    //   3736: new org/renjin/gcc/runtime/BytePtr
    //   3739: dup
    //   3740: ldc_w 'omd '
    //   3743: invokevirtual getBytes : ()[B
    //   3746: iconst_0
    //   3747: invokespecial <init> : ([BI)V
    //   3750: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3755: aload_3
    //   3756: bipush #101
    //   3758: iconst_1
    //   3759: invokeinterface setAlignedInt : (II)V
    //   3764: aload_3
    //   3765: bipush #102
    //   3767: new org/renjin/gcc/runtime/BytePtr
    //   3770: dup
    //   3771: ldc_w 'omi '
    //   3774: invokevirtual getBytes : ()[B
    //   3777: iconst_0
    //   3778: invokespecial <init> : ([BI)V
    //   3781: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3786: aload_3
    //   3787: bipush #103
    //   3789: iconst_1
    //   3790: invokeinterface setAlignedInt : (II)V
    //   3795: aload_3
    //   3796: bipush #104
    //   3798: new org/renjin/gcc/runtime/BytePtr
    //   3801: dup
    //   3802: ldc_w 'page '
    //   3805: invokevirtual getBytes : ()[B
    //   3808: iconst_0
    //   3809: invokespecial <init> : ([BI)V
    //   3812: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3817: aload_3
    //   3818: bipush #105
    //   3820: iconst_2
    //   3821: invokeinterface setAlignedInt : (II)V
    //   3826: aload_3
    //   3827: bipush #106
    //   3829: new org/renjin/gcc/runtime/BytePtr
    //   3832: dup
    //   3833: ldc_w 'pch '
    //   3836: invokevirtual getBytes : ()[B
    //   3839: iconst_0
    //   3840: invokespecial <init> : ([BI)V
    //   3843: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3848: aload_3
    //   3849: bipush #107
    //   3851: iconst_0
    //   3852: invokeinterface setAlignedInt : (II)V
    //   3857: aload_3
    //   3858: bipush #108
    //   3860: new org/renjin/gcc/runtime/BytePtr
    //   3863: dup
    //   3864: ldc_w 'pin '
    //   3867: invokevirtual getBytes : ()[B
    //   3870: iconst_0
    //   3871: invokespecial <init> : ([BI)V
    //   3874: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3879: aload_3
    //   3880: bipush #109
    //   3882: iconst_1
    //   3883: invokeinterface setAlignedInt : (II)V
    //   3888: aload_3
    //   3889: bipush #110
    //   3891: new org/renjin/gcc/runtime/BytePtr
    //   3894: dup
    //   3895: ldc_w 'plt '
    //   3898: invokevirtual getBytes : ()[B
    //   3901: iconst_0
    //   3902: invokespecial <init> : ([BI)V
    //   3905: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3910: aload_3
    //   3911: bipush #111
    //   3913: iconst_1
    //   3914: invokeinterface setAlignedInt : (II)V
    //   3919: aload_3
    //   3920: bipush #112
    //   3922: new org/renjin/gcc/runtime/BytePtr
    //   3925: dup
    //   3926: ldc_w 'ps '
    //   3929: invokevirtual getBytes : ()[B
    //   3932: iconst_0
    //   3933: invokespecial <init> : ([BI)V
    //   3936: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3941: aload_3
    //   3942: bipush #113
    //   3944: iconst_1
    //   3945: invokeinterface setAlignedInt : (II)V
    //   3950: aload_3
    //   3951: bipush #114
    //   3953: new org/renjin/gcc/runtime/BytePtr
    //   3956: dup
    //   3957: ldc_w 'pty '
    //   3960: invokevirtual getBytes : ()[B
    //   3963: iconst_0
    //   3964: invokespecial <init> : ([BI)V
    //   3967: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3972: aload_3
    //   3973: bipush #115
    //   3975: iconst_1
    //   3976: invokeinterface setAlignedInt : (II)V
    //   3981: aload_3
    //   3982: bipush #116
    //   3984: new org/renjin/gcc/runtime/BytePtr
    //   3987: dup
    //   3988: ldc_w 'smo '
    //   3991: invokevirtual getBytes : ()[B
    //   3994: iconst_0
    //   3995: invokespecial <init> : ([BI)V
    //   3998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4003: aload_3
    //   4004: bipush #117
    //   4006: iconst_0
    //   4007: invokeinterface setAlignedInt : (II)V
    //   4012: aload_3
    //   4013: bipush #118
    //   4015: new org/renjin/gcc/runtime/BytePtr
    //   4018: dup
    //   4019: ldc_w 'srt '
    //   4022: invokevirtual getBytes : ()[B
    //   4025: iconst_0
    //   4026: invokespecial <init> : ([BI)V
    //   4029: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4034: aload_3
    //   4035: bipush #119
    //   4037: iconst_0
    //   4038: invokeinterface setAlignedInt : (II)V
    //   4043: aload_3
    //   4044: bipush #120
    //   4046: new org/renjin/gcc/runtime/BytePtr
    //   4049: dup
    //   4050: ldc_w 'tck '
    //   4053: invokevirtual getBytes : ()[B
    //   4056: iconst_0
    //   4057: invokespecial <init> : ([BI)V
    //   4060: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4065: aload_3
    //   4066: bipush #121
    //   4068: iconst_0
    //   4069: invokeinterface setAlignedInt : (II)V
    //   4074: aload_3
    //   4075: bipush #122
    //   4077: new org/renjin/gcc/runtime/BytePtr
    //   4080: dup
    //   4081: ldc_w 'tcl '
    //   4084: invokevirtual getBytes : ()[B
    //   4087: iconst_0
    //   4088: invokespecial <init> : ([BI)V
    //   4091: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4096: aload_3
    //   4097: bipush #123
    //   4099: iconst_0
    //   4100: invokeinterface setAlignedInt : (II)V
    //   4105: aload_3
    //   4106: bipush #124
    //   4108: new org/renjin/gcc/runtime/BytePtr
    //   4111: dup
    //   4112: ldc_w 'usr '
    //   4115: invokevirtual getBytes : ()[B
    //   4118: iconst_0
    //   4119: invokespecial <init> : ([BI)V
    //   4122: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4127: aload_3
    //   4128: bipush #125
    //   4130: iconst_1
    //   4131: invokeinterface setAlignedInt : (II)V
    //   4136: aload_3
    //   4137: bipush #126
    //   4139: new org/renjin/gcc/runtime/BytePtr
    //   4142: dup
    //   4143: ldc_w 'xaxp '
    //   4146: invokevirtual getBytes : ()[B
    //   4149: iconst_0
    //   4150: invokespecial <init> : ([BI)V
    //   4153: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4158: aload_3
    //   4159: bipush #127
    //   4161: iconst_0
    //   4162: invokeinterface setAlignedInt : (II)V
    //   4167: aload_3
    //   4168: sipush #128
    //   4171: new org/renjin/gcc/runtime/BytePtr
    //   4174: dup
    //   4175: ldc_w 'xaxs '
    //   4178: invokevirtual getBytes : ()[B
    //   4181: iconst_0
    //   4182: invokespecial <init> : ([BI)V
    //   4185: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4190: aload_3
    //   4191: sipush #129
    //   4194: iconst_0
    //   4195: invokeinterface setAlignedInt : (II)V
    //   4200: aload_3
    //   4201: sipush #130
    //   4204: new org/renjin/gcc/runtime/BytePtr
    //   4207: dup
    //   4208: ldc_w 'xaxt '
    //   4211: invokevirtual getBytes : ()[B
    //   4214: iconst_0
    //   4215: invokespecial <init> : ([BI)V
    //   4218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4223: aload_3
    //   4224: sipush #131
    //   4227: iconst_0
    //   4228: invokeinterface setAlignedInt : (II)V
    //   4233: aload_3
    //   4234: sipush #132
    //   4237: new org/renjin/gcc/runtime/BytePtr
    //   4240: dup
    //   4241: ldc_w 'xlog '
    //   4244: invokevirtual getBytes : ()[B
    //   4247: iconst_0
    //   4248: invokespecial <init> : ([BI)V
    //   4251: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4256: aload_3
    //   4257: sipush #133
    //   4260: iconst_1
    //   4261: invokeinterface setAlignedInt : (II)V
    //   4266: aload_3
    //   4267: sipush #134
    //   4270: new org/renjin/gcc/runtime/BytePtr
    //   4273: dup
    //   4274: ldc_w 'xpd '
    //   4277: invokevirtual getBytes : ()[B
    //   4280: iconst_0
    //   4281: invokespecial <init> : ([BI)V
    //   4284: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4289: aload_3
    //   4290: sipush #135
    //   4293: iconst_0
    //   4294: invokeinterface setAlignedInt : (II)V
    //   4299: aload_3
    //   4300: sipush #136
    //   4303: new org/renjin/gcc/runtime/BytePtr
    //   4306: dup
    //   4307: ldc_w 'yaxp '
    //   4310: invokevirtual getBytes : ()[B
    //   4313: iconst_0
    //   4314: invokespecial <init> : ([BI)V
    //   4317: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4322: aload_3
    //   4323: sipush #137
    //   4326: iconst_0
    //   4327: invokeinterface setAlignedInt : (II)V
    //   4332: aload_3
    //   4333: sipush #138
    //   4336: new org/renjin/gcc/runtime/BytePtr
    //   4339: dup
    //   4340: ldc_w 'yaxs '
    //   4343: invokevirtual getBytes : ()[B
    //   4346: iconst_0
    //   4347: invokespecial <init> : ([BI)V
    //   4350: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4355: aload_3
    //   4356: sipush #139
    //   4359: iconst_0
    //   4360: invokeinterface setAlignedInt : (II)V
    //   4365: aload_3
    //   4366: sipush #140
    //   4369: new org/renjin/gcc/runtime/BytePtr
    //   4372: dup
    //   4373: ldc_w 'yaxt '
    //   4376: invokevirtual getBytes : ()[B
    //   4379: iconst_0
    //   4380: invokespecial <init> : ([BI)V
    //   4383: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4388: aload_3
    //   4389: sipush #141
    //   4392: iconst_0
    //   4393: invokeinterface setAlignedInt : (II)V
    //   4398: aload_3
    //   4399: sipush #142
    //   4402: new org/renjin/gcc/runtime/BytePtr
    //   4405: dup
    //   4406: ldc_w 'ylbias '
    //   4409: invokevirtual getBytes : ()[B
    //   4412: iconst_0
    //   4413: invokespecial <init> : ([BI)V
    //   4416: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4421: aload_3
    //   4422: sipush #143
    //   4425: iconst_1
    //   4426: invokeinterface setAlignedInt : (II)V
    //   4431: aload_3
    //   4432: sipush #144
    //   4435: new org/renjin/gcc/runtime/BytePtr
    //   4438: dup
    //   4439: ldc_w 'ylog '
    //   4442: invokevirtual getBytes : ()[B
    //   4445: iconst_0
    //   4446: invokespecial <init> : ([BI)V
    //   4449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4454: aload_3
    //   4455: sipush #145
    //   4458: iconst_1
    //   4459: invokeinterface setAlignedInt : (II)V
    //   4464: aload_3
    //   4465: sipush #146
    //   4468: new org/renjin/gcc/runtime/BytePtr
    //   4471: dup
    //   4472: ldc_w 'gamma '
    //   4475: invokevirtual getBytes : ()[B
    //   4478: iconst_0
    //   4479: invokespecial <init> : ([BI)V
    //   4482: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4487: aload_3
    //   4488: sipush #147
    //   4491: bipush #-2
    //   4493: invokeinterface setAlignedInt : (II)V
    //   4498: aload_3
    //   4499: sipush #148
    //   4502: new org/renjin/gcc/runtime/BytePtr
    //   4505: dup
    //   4506: ldc_w 'type '
    //   4509: invokevirtual getBytes : ()[B
    //   4512: iconst_0
    //   4513: invokespecial <init> : ([BI)V
    //   4516: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4521: aload_3
    //   4522: sipush #149
    //   4525: bipush #-2
    //   4527: invokeinterface setAlignedInt : (II)V
    //   4532: aload_3
    //   4533: sipush #150
    //   4536: new org/renjin/gcc/runtime/BytePtr
    //   4539: dup
    //   4540: ldc_w 'tmag '
    //   4543: invokevirtual getBytes : ()[B
    //   4546: iconst_0
    //   4547: invokespecial <init> : ([BI)V
    //   4550: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4555: aload_3
    //   4556: sipush #151
    //   4559: bipush #-2
    //   4561: invokeinterface setAlignedInt : (II)V
    //   4566: aload_3
    //   4567: sipush #152
    //   4570: new org/renjin/gcc/runtime/BytePtr
    //   4573: dup
    //   4574: ldc_w 'asp '
    //   4577: invokevirtual getBytes : ()[B
    //   4580: iconst_0
    //   4581: invokespecial <init> : ([BI)V
    //   4584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4589: aload_3
    //   4590: sipush #153
    //   4593: bipush #-3
    //   4595: invokeinterface setAlignedInt : (II)V
    //   4600: aload_3
    //   4601: sipush #154
    //   4604: new org/renjin/gcc/runtime/BytePtr
    //   4607: dup
    //   4608: ldc_w 'main '
    //   4611: invokevirtual getBytes : ()[B
    //   4614: iconst_0
    //   4615: invokespecial <init> : ([BI)V
    //   4618: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4623: aload_3
    //   4624: sipush #155
    //   4627: bipush #-3
    //   4629: invokeinterface setAlignedInt : (II)V
    //   4634: aload_3
    //   4635: sipush #156
    //   4638: new org/renjin/gcc/runtime/BytePtr
    //   4641: dup
    //   4642: ldc_w 'sub '
    //   4645: invokevirtual getBytes : ()[B
    //   4648: iconst_0
    //   4649: invokespecial <init> : ([BI)V
    //   4652: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4657: aload_3
    //   4658: sipush #157
    //   4661: bipush #-3
    //   4663: invokeinterface setAlignedInt : (II)V
    //   4668: aload_3
    //   4669: sipush #158
    //   4672: new org/renjin/gcc/runtime/BytePtr
    //   4675: dup
    //   4676: ldc_w 'xlab '
    //   4679: invokevirtual getBytes : ()[B
    //   4682: iconst_0
    //   4683: invokespecial <init> : ([BI)V
    //   4686: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4691: aload_3
    //   4692: sipush #159
    //   4695: bipush #-3
    //   4697: invokeinterface setAlignedInt : (II)V
    //   4702: aload_3
    //   4703: sipush #160
    //   4706: new org/renjin/gcc/runtime/BytePtr
    //   4709: dup
    //   4710: ldc_w 'ylab '
    //   4713: invokevirtual getBytes : ()[B
    //   4716: iconst_0
    //   4717: invokespecial <init> : ([BI)V
    //   4720: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4725: aload_3
    //   4726: sipush #161
    //   4729: bipush #-3
    //   4731: invokeinterface setAlignedInt : (II)V
    //   4736: aload_3
    //   4737: sipush #162
    //   4740: new org/renjin/gcc/runtime/BytePtr
    //   4743: dup
    //   4744: ldc_w 'xlim '
    //   4747: invokevirtual getBytes : ()[B
    //   4750: iconst_0
    //   4751: invokespecial <init> : ([BI)V
    //   4754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4759: aload_3
    //   4760: sipush #163
    //   4763: bipush #-3
    //   4765: invokeinterface setAlignedInt : (II)V
    //   4770: aload_3
    //   4771: sipush #164
    //   4774: new org/renjin/gcc/runtime/BytePtr
    //   4777: dup
    //   4778: ldc_w 'ylim '
    //   4781: invokevirtual getBytes : ()[B
    //   4784: iconst_0
    //   4785: invokespecial <init> : ([BI)V
    //   4788: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4793: aload_3
    //   4794: sipush #165
    //   4797: bipush #-3
    //   4799: invokeinterface setAlignedInt : (II)V
    //   4804: aload_3
    //   4805: sipush #166
    //   4808: iconst_0
    //   4809: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4812: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4817: aload_3
    //   4818: sipush #167
    //   4821: iconst_m1
    //   4822: invokeinterface setAlignedInt : (II)V
    //   4827: aload_0
    //   4828: getfield par$ParTable : Lorg/renjin/gcc/runtime/Ptr;
    //   4831: aload_3
    //   4832: sipush #672
    //   4835: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   4840: aload_0
    //   4841: iconst_0
    //   4842: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4845: putfield plot$dnd_xpos : Lorg/renjin/gcc/runtime/Ptr;
    //   4848: aload_0
    //   4849: iconst_0
    //   4850: putfield plot$dnd_xpos$offset : I
    //   4853: aload_0
    //   4854: iconst_0
    //   4855: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4858: putfield plot$dnd_hght : Lorg/renjin/gcc/runtime/Ptr;
    //   4861: aload_0
    //   4862: iconst_0
    //   4863: putfield plot$dnd_hght$offset : I
    //   4866: aload_0
    //   4867: iconst_0
    //   4868: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4871: putfield plot$dnd_rptr : Lorg/renjin/gcc/runtime/Ptr;
    //   4874: aload_0
    //   4875: iconst_0
    //   4876: putfield plot$dnd_rptr$offset : I
    //   4879: aload_0
    //   4880: iconst_0
    //   4881: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4884: putfield plot$dnd_lptr : Lorg/renjin/gcc/runtime/Ptr;
    //   4887: aload_0
    //   4888: iconst_0
    //   4889: putfield plot$dnd_lptr$offset : I
    //   4892: aload_0
    //   4893: iconst_0
    //   4894: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4897: putfield plot3d$ctr_SegDB : Lorg/renjin/gcc/runtime/Ptr;
    //   4900: aload_0
    //   4901: iconst_0
    //   4902: putfield plot3d$ctr_SegDB$offset : I
    //   4905: aload_0
    //   4906: iconst_0
    //   4907: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   4910: invokeinterface getArray : ()Ljava/lang/Object;
    //   4915: checkcast org/renjin/sexp/SEXP
    //   4918: putfield plot3d$labelList : Lorg/renjin/sexp/SEXP;
    //   4921: bipush #24
    //   4923: newarray short
    //   4925: dup
    //   4926: iconst_0
    //   4927: iconst_0
    //   4928: i2s
    //   4929: sastore
    //   4930: dup
    //   4931: iconst_1
    //   4932: iconst_m1
    //   4933: i2s
    //   4934: sastore
    //   4935: dup
    //   4936: iconst_2
    //   4937: iconst_m1
    //   4938: i2s
    //   4939: sastore
    //   4940: dup
    //   4941: iconst_3
    //   4942: iconst_m1
    //   4943: i2s
    //   4944: sastore
    //   4945: dup
    //   4946: iconst_4
    //   4947: iconst_0
    //   4948: i2s
    //   4949: sastore
    //   4950: dup
    //   4951: iconst_5
    //   4952: iconst_m1
    //   4953: i2s
    //   4954: sastore
    //   4955: dup
    //   4956: bipush #6
    //   4958: iconst_0
    //   4959: i2s
    //   4960: sastore
    //   4961: dup
    //   4962: bipush #7
    //   4964: iconst_1
    //   4965: i2s
    //   4966: sastore
    //   4967: dup
    //   4968: bipush #8
    //   4970: iconst_m1
    //   4971: i2s
    //   4972: sastore
    //   4973: dup
    //   4974: bipush #9
    //   4976: iconst_1
    //   4977: i2s
    //   4978: sastore
    //   4979: dup
    //   4980: bipush #10
    //   4982: iconst_0
    //   4983: i2s
    //   4984: sastore
    //   4985: dup
    //   4986: bipush #11
    //   4988: iconst_m1
    //   4989: i2s
    //   4990: sastore
    //   4991: dup
    //   4992: bipush #12
    //   4994: iconst_m1
    //   4995: i2s
    //   4996: sastore
    //   4997: dup
    //   4998: bipush #13
    //   5000: iconst_m1
    //   5001: i2s
    //   5002: sastore
    //   5003: dup
    //   5004: bipush #14
    //   5006: iconst_0
    //   5007: i2s
    //   5008: sastore
    //   5009: dup
    //   5010: bipush #15
    //   5012: iconst_1
    //   5013: i2s
    //   5014: sastore
    //   5015: dup
    //   5016: bipush #16
    //   5018: iconst_m1
    //   5019: i2s
    //   5020: sastore
    //   5021: dup
    //   5022: bipush #17
    //   5024: iconst_0
    //   5025: i2s
    //   5026: sastore
    //   5027: dup
    //   5028: bipush #18
    //   5030: iconst_m1
    //   5031: i2s
    //   5032: sastore
    //   5033: dup
    //   5034: bipush #19
    //   5036: iconst_1
    //   5037: i2s
    //   5038: sastore
    //   5039: dup
    //   5040: bipush #20
    //   5042: iconst_0
    //   5043: i2s
    //   5044: sastore
    //   5045: dup
    //   5046: bipush #21
    //   5048: iconst_1
    //   5049: i2s
    //   5050: sastore
    //   5051: dup
    //   5052: bipush #22
    //   5054: iconst_1
    //   5055: i2s
    //   5056: sastore
    //   5057: dup
    //   5058: bipush #23
    //   5060: iconst_0
    //   5061: i2s
    //   5062: sastore
    //   5063: iconst_0
    //   5064: aload_0
    //   5065: getfield plot3d$TickVector : [S
    //   5068: iconst_0
    //   5069: bipush #24
    //   5071: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   5074: bipush #8
    //   5076: newarray short
    //   5078: dup
    //   5079: iconst_0
    //   5080: iconst_0
    //   5081: i2s
    //   5082: sastore
    //   5083: dup
    //   5084: iconst_1
    //   5085: iconst_0
    //   5086: i2s
    //   5087: sastore
    //   5088: dup
    //   5089: iconst_2
    //   5090: iconst_2
    //   5091: i2s
    //   5092: sastore
    //   5093: dup
    //   5094: iconst_3
    //   5095: iconst_4
    //   5096: i2s
    //   5097: sastore
    //   5098: dup
    //   5099: iconst_4
    //   5100: iconst_0
    //   5101: i2s
    //   5102: sastore
    //   5103: dup
    //   5104: iconst_5
    //   5105: iconst_4
    //   5106: i2s
    //   5107: sastore
    //   5108: dup
    //   5109: bipush #6
    //   5111: iconst_2
    //   5112: i2s
    //   5113: sastore
    //   5114: dup
    //   5115: bipush #7
    //   5117: bipush #6
    //   5119: i2s
    //   5120: sastore
    //   5121: iconst_0
    //   5122: aload_0
    //   5123: getfield plot3d$AxisStart : [S
    //   5126: iconst_0
    //   5127: bipush #8
    //   5129: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   5132: bipush #24
    //   5134: newarray short
    //   5136: dup
    //   5137: iconst_0
    //   5138: iconst_0
    //   5139: i2s
    //   5140: sastore
    //   5141: dup
    //   5142: iconst_1
    //   5143: iconst_1
    //   5144: i2s
    //   5145: sastore
    //   5146: dup
    //   5147: iconst_2
    //   5148: iconst_2
    //   5149: i2s
    //   5150: sastore
    //   5151: dup
    //   5152: iconst_3
    //   5153: iconst_3
    //   5154: i2s
    //   5155: sastore
    //   5156: dup
    //   5157: iconst_4
    //   5158: iconst_4
    //   5159: i2s
    //   5160: sastore
    //   5161: dup
    //   5162: iconst_5
    //   5163: iconst_5
    //   5164: i2s
    //   5165: sastore
    //   5166: dup
    //   5167: bipush #6
    //   5169: bipush #6
    //   5171: i2s
    //   5172: sastore
    //   5173: dup
    //   5174: bipush #7
    //   5176: bipush #7
    //   5178: i2s
    //   5179: sastore
    //   5180: dup
    //   5181: bipush #8
    //   5183: bipush #8
    //   5185: i2s
    //   5186: sastore
    //   5187: dup
    //   5188: bipush #9
    //   5190: bipush #7
    //   5192: i2s
    //   5193: sastore
    //   5194: dup
    //   5195: bipush #10
    //   5197: bipush #9
    //   5199: i2s
    //   5200: sastore
    //   5201: dup
    //   5202: bipush #11
    //   5204: iconst_0
    //   5205: i2s
    //   5206: sastore
    //   5207: dup
    //   5208: bipush #12
    //   5210: iconst_2
    //   5211: i2s
    //   5212: sastore
    //   5213: dup
    //   5214: bipush #13
    //   5216: bipush #10
    //   5218: i2s
    //   5219: sastore
    //   5220: dup
    //   5221: bipush #14
    //   5223: iconst_5
    //   5224: i2s
    //   5225: sastore
    //   5226: dup
    //   5227: bipush #15
    //   5229: bipush #11
    //   5231: i2s
    //   5232: sastore
    //   5233: dup
    //   5234: bipush #16
    //   5236: iconst_3
    //   5237: i2s
    //   5238: sastore
    //   5239: dup
    //   5240: bipush #17
    //   5242: bipush #11
    //   5244: i2s
    //   5245: sastore
    //   5246: dup
    //   5247: bipush #18
    //   5249: iconst_4
    //   5250: i2s
    //   5251: sastore
    //   5252: dup
    //   5253: bipush #19
    //   5255: bipush #8
    //   5257: i2s
    //   5258: sastore
    //   5259: dup
    //   5260: bipush #20
    //   5262: bipush #9
    //   5264: i2s
    //   5265: sastore
    //   5266: dup
    //   5267: bipush #21
    //   5269: bipush #6
    //   5271: i2s
    //   5272: sastore
    //   5273: dup
    //   5274: bipush #22
    //   5276: bipush #10
    //   5278: i2s
    //   5279: sastore
    //   5280: dup
    //   5281: bipush #23
    //   5283: iconst_1
    //   5284: i2s
    //   5285: sastore
    //   5286: iconst_0
    //   5287: aload_0
    //   5288: getfield plot3d$Edge : [S
    //   5291: iconst_0
    //   5292: bipush #24
    //   5294: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   5297: bipush #24
    //   5299: newarray short
    //   5301: dup
    //   5302: iconst_0
    //   5303: iconst_0
    //   5304: i2s
    //   5305: sastore
    //   5306: dup
    //   5307: iconst_1
    //   5308: iconst_1
    //   5309: i2s
    //   5310: sastore
    //   5311: dup
    //   5312: iconst_2
    //   5313: iconst_5
    //   5314: i2s
    //   5315: sastore
    //   5316: dup
    //   5317: iconst_3
    //   5318: iconst_4
    //   5319: i2s
    //   5320: sastore
    //   5321: dup
    //   5322: iconst_4
    //   5323: iconst_2
    //   5324: i2s
    //   5325: sastore
    //   5326: dup
    //   5327: iconst_5
    //   5328: bipush #6
    //   5330: i2s
    //   5331: sastore
    //   5332: dup
    //   5333: bipush #6
    //   5335: bipush #7
    //   5337: i2s
    //   5338: sastore
    //   5339: dup
    //   5340: bipush #7
    //   5342: iconst_3
    //   5343: i2s
    //   5344: sastore
    //   5345: dup
    //   5346: bipush #8
    //   5348: iconst_0
    //   5349: i2s
    //   5350: sastore
    //   5351: dup
    //   5352: bipush #9
    //   5354: iconst_2
    //   5355: i2s
    //   5356: sastore
    //   5357: dup
    //   5358: bipush #10
    //   5360: iconst_3
    //   5361: i2s
    //   5362: sastore
    //   5363: dup
    //   5364: bipush #11
    //   5366: iconst_1
    //   5367: i2s
    //   5368: sastore
    //   5369: dup
    //   5370: bipush #12
    //   5372: iconst_4
    //   5373: i2s
    //   5374: sastore
    //   5375: dup
    //   5376: bipush #13
    //   5378: iconst_5
    //   5379: i2s
    //   5380: sastore
    //   5381: dup
    //   5382: bipush #14
    //   5384: bipush #7
    //   5386: i2s
    //   5387: sastore
    //   5388: dup
    //   5389: bipush #15
    //   5391: bipush #6
    //   5393: i2s
    //   5394: sastore
    //   5395: dup
    //   5396: bipush #16
    //   5398: iconst_0
    //   5399: i2s
    //   5400: sastore
    //   5401: dup
    //   5402: bipush #17
    //   5404: iconst_4
    //   5405: i2s
    //   5406: sastore
    //   5407: dup
    //   5408: bipush #18
    //   5410: bipush #6
    //   5412: i2s
    //   5413: sastore
    //   5414: dup
    //   5415: bipush #19
    //   5417: iconst_2
    //   5418: i2s
    //   5419: sastore
    //   5420: dup
    //   5421: bipush #20
    //   5423: iconst_1
    //   5424: i2s
    //   5425: sastore
    //   5426: dup
    //   5427: bipush #21
    //   5429: iconst_3
    //   5430: i2s
    //   5431: sastore
    //   5432: dup
    //   5433: bipush #22
    //   5435: bipush #7
    //   5437: i2s
    //   5438: sastore
    //   5439: dup
    //   5440: bipush #23
    //   5442: iconst_5
    //   5443: i2s
    //   5444: sastore
    //   5445: iconst_0
    //   5446: aload_0
    //   5447: getfield plot3d$Face : [S
    //   5450: iconst_0
    //   5451: bipush #24
    //   5453: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   5456: bipush #24
    //   5458: newarray short
    //   5460: dup
    //   5461: iconst_0
    //   5462: iconst_0
    //   5463: i2s
    //   5464: sastore
    //   5465: dup
    //   5466: iconst_1
    //   5467: iconst_0
    //   5468: i2s
    //   5469: sastore
    //   5470: dup
    //   5471: iconst_2
    //   5472: iconst_0
    //   5473: i2s
    //   5474: sastore
    //   5475: dup
    //   5476: iconst_3
    //   5477: iconst_0
    //   5478: i2s
    //   5479: sastore
    //   5480: dup
    //   5481: iconst_4
    //   5482: iconst_0
    //   5483: i2s
    //   5484: sastore
    //   5485: dup
    //   5486: iconst_5
    //   5487: iconst_1
    //   5488: i2s
    //   5489: sastore
    //   5490: dup
    //   5491: bipush #6
    //   5493: iconst_0
    //   5494: i2s
    //   5495: sastore
    //   5496: dup
    //   5497: bipush #7
    //   5499: iconst_1
    //   5500: i2s
    //   5501: sastore
    //   5502: dup
    //   5503: bipush #8
    //   5505: iconst_0
    //   5506: i2s
    //   5507: sastore
    //   5508: dup
    //   5509: bipush #9
    //   5511: iconst_0
    //   5512: i2s
    //   5513: sastore
    //   5514: dup
    //   5515: bipush #10
    //   5517: iconst_1
    //   5518: i2s
    //   5519: sastore
    //   5520: dup
    //   5521: bipush #11
    //   5523: iconst_1
    //   5524: i2s
    //   5525: sastore
    //   5526: dup
    //   5527: bipush #12
    //   5529: iconst_1
    //   5530: i2s
    //   5531: sastore
    //   5532: dup
    //   5533: bipush #13
    //   5535: iconst_0
    //   5536: i2s
    //   5537: sastore
    //   5538: dup
    //   5539: bipush #14
    //   5541: iconst_0
    //   5542: i2s
    //   5543: sastore
    //   5544: dup
    //   5545: bipush #15
    //   5547: iconst_1
    //   5548: i2s
    //   5549: sastore
    //   5550: dup
    //   5551: bipush #16
    //   5553: iconst_0
    //   5554: i2s
    //   5555: sastore
    //   5556: dup
    //   5557: bipush #17
    //   5559: iconst_1
    //   5560: i2s
    //   5561: sastore
    //   5562: dup
    //   5563: bipush #18
    //   5565: iconst_1
    //   5566: i2s
    //   5567: sastore
    //   5568: dup
    //   5569: bipush #19
    //   5571: iconst_1
    //   5572: i2s
    //   5573: sastore
    //   5574: dup
    //   5575: bipush #20
    //   5577: iconst_0
    //   5578: i2s
    //   5579: sastore
    //   5580: dup
    //   5581: bipush #21
    //   5583: iconst_1
    //   5584: i2s
    //   5585: sastore
    //   5586: dup
    //   5587: bipush #22
    //   5589: iconst_1
    //   5590: i2s
    //   5591: sastore
    //   5592: dup
    //   5593: bipush #23
    //   5595: iconst_1
    //   5596: i2s
    //   5597: sastore
    //   5598: iconst_0
    //   5599: aload_0
    //   5600: getfield plot3d$Vertex : [S
    //   5603: iconst_0
    //   5604: bipush #24
    //   5606: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   5609: aload_0
    //   5610: ldc2_w 0.16666666666666666
    //   5613: putfield plotmath$OneSixth$7738 : D
    //   5616: aload_0
    //   5617: ldc2_w 0.2222222222222222
    //   5620: putfield plotmath$TwoNinths$7746 : D
    //   5623: aload_0
    //   5624: ldc2_w 0.2777777777777778
    //   5627: putfield plotmath$FiveEighteenths$7754 : D
    //   5630: aload_0
    //   5631: ldc2_w 0.05555555555555555
    //   5634: putfield plotmath$OneEighteenth$7762 : D
    //   5637: sipush #232
    //   5640: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   5643: astore #4
    //   5645: aload #4
    //   5647: new org/renjin/gcc/runtime/BytePtr
    //   5650: dup
    //   5651: ldc_w '< '
    //   5654: invokevirtual getBytes : ()[B
    //   5657: iconst_0
    //   5658: invokespecial <init> : ([BI)V
    //   5661: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   5666: aload #4
    //   5668: iconst_1
    //   5669: bipush #60
    //   5671: invokeinterface setAlignedInt : (II)V
    //   5676: aload #4
    //   5678: iconst_2
    //   5679: new org/renjin/gcc/runtime/BytePtr
    //   5682: dup
    //   5683: ldc_w '== '
    //   5686: invokevirtual getBytes : ()[B
    //   5689: iconst_0
    //   5690: invokespecial <init> : ([BI)V
    //   5693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5698: aload #4
    //   5700: iconst_3
    //   5701: bipush #61
    //   5703: invokeinterface setAlignedInt : (II)V
    //   5708: aload #4
    //   5710: iconst_4
    //   5711: new org/renjin/gcc/runtime/BytePtr
    //   5714: dup
    //   5715: ldc_w '> '
    //   5718: invokevirtual getBytes : ()[B
    //   5721: iconst_0
    //   5722: invokespecial <init> : ([BI)V
    //   5725: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5730: aload #4
    //   5732: iconst_5
    //   5733: bipush #62
    //   5735: invokeinterface setAlignedInt : (II)V
    //   5740: aload #4
    //   5742: bipush #6
    //   5744: new org/renjin/gcc/runtime/BytePtr
    //   5747: dup
    //   5748: ldc_w '%=~% '
    //   5751: invokevirtual getBytes : ()[B
    //   5754: iconst_0
    //   5755: invokespecial <init> : ([BI)V
    //   5758: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5763: aload #4
    //   5765: bipush #7
    //   5767: bipush #64
    //   5769: invokeinterface setAlignedInt : (II)V
    //   5774: aload #4
    //   5776: bipush #8
    //   5778: new org/renjin/gcc/runtime/BytePtr
    //   5781: dup
    //   5782: ldc_w '!= '
    //   5785: invokevirtual getBytes : ()[B
    //   5788: iconst_0
    //   5789: invokespecial <init> : ([BI)V
    //   5792: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5797: aload #4
    //   5799: bipush #9
    //   5801: sipush #185
    //   5804: invokeinterface setAlignedInt : (II)V
    //   5809: aload #4
    //   5811: bipush #10
    //   5813: new org/renjin/gcc/runtime/BytePtr
    //   5816: dup
    //   5817: ldc_w '<= '
    //   5820: invokevirtual getBytes : ()[B
    //   5823: iconst_0
    //   5824: invokespecial <init> : ([BI)V
    //   5827: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5832: aload #4
    //   5834: bipush #11
    //   5836: sipush #163
    //   5839: invokeinterface setAlignedInt : (II)V
    //   5844: aload #4
    //   5846: bipush #12
    //   5848: new org/renjin/gcc/runtime/BytePtr
    //   5851: dup
    //   5852: ldc_w '>= '
    //   5855: invokevirtual getBytes : ()[B
    //   5858: iconst_0
    //   5859: invokespecial <init> : ([BI)V
    //   5862: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5867: aload #4
    //   5869: bipush #13
    //   5871: sipush #179
    //   5874: invokeinterface setAlignedInt : (II)V
    //   5879: aload #4
    //   5881: bipush #14
    //   5883: new org/renjin/gcc/runtime/BytePtr
    //   5886: dup
    //   5887: ldc_w '%==% '
    //   5890: invokevirtual getBytes : ()[B
    //   5893: iconst_0
    //   5894: invokespecial <init> : ([BI)V
    //   5897: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5902: aload #4
    //   5904: bipush #15
    //   5906: sipush #186
    //   5909: invokeinterface setAlignedInt : (II)V
    //   5914: aload #4
    //   5916: bipush #16
    //   5918: new org/renjin/gcc/runtime/BytePtr
    //   5921: dup
    //   5922: ldc_w '%~~% '
    //   5925: invokevirtual getBytes : ()[B
    //   5928: iconst_0
    //   5929: invokespecial <init> : ([BI)V
    //   5932: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5937: aload #4
    //   5939: bipush #17
    //   5941: sipush #187
    //   5944: invokeinterface setAlignedInt : (II)V
    //   5949: aload #4
    //   5951: bipush #18
    //   5953: new org/renjin/gcc/runtime/BytePtr
    //   5956: dup
    //   5957: ldc_w '%prop% '
    //   5960: invokevirtual getBytes : ()[B
    //   5963: iconst_0
    //   5964: invokespecial <init> : ([BI)V
    //   5967: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5972: aload #4
    //   5974: bipush #19
    //   5976: sipush #181
    //   5979: invokeinterface setAlignedInt : (II)V
    //   5984: aload #4
    //   5986: bipush #20
    //   5988: new org/renjin/gcc/runtime/BytePtr
    //   5991: dup
    //   5992: ldc_w '%~% '
    //   5995: invokevirtual getBytes : ()[B
    //   5998: iconst_0
    //   5999: invokespecial <init> : ([BI)V
    //   6002: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6007: aload #4
    //   6009: bipush #21
    //   6011: bipush #126
    //   6013: invokeinterface setAlignedInt : (II)V
    //   6018: aload #4
    //   6020: bipush #22
    //   6022: new org/renjin/gcc/runtime/BytePtr
    //   6025: dup
    //   6026: ldc_w '%<->% '
    //   6029: invokevirtual getBytes : ()[B
    //   6032: iconst_0
    //   6033: invokespecial <init> : ([BI)V
    //   6036: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6041: aload #4
    //   6043: bipush #23
    //   6045: sipush #171
    //   6048: invokeinterface setAlignedInt : (II)V
    //   6053: aload #4
    //   6055: bipush #24
    //   6057: new org/renjin/gcc/runtime/BytePtr
    //   6060: dup
    //   6061: ldc_w '%<-% '
    //   6064: invokevirtual getBytes : ()[B
    //   6067: iconst_0
    //   6068: invokespecial <init> : ([BI)V
    //   6071: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6076: aload #4
    //   6078: bipush #25
    //   6080: sipush #172
    //   6083: invokeinterface setAlignedInt : (II)V
    //   6088: aload #4
    //   6090: bipush #26
    //   6092: new org/renjin/gcc/runtime/BytePtr
    //   6095: dup
    //   6096: ldc_w '%up% '
    //   6099: invokevirtual getBytes : ()[B
    //   6102: iconst_0
    //   6103: invokespecial <init> : ([BI)V
    //   6106: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6111: aload #4
    //   6113: bipush #27
    //   6115: sipush #173
    //   6118: invokeinterface setAlignedInt : (II)V
    //   6123: aload #4
    //   6125: bipush #28
    //   6127: new org/renjin/gcc/runtime/BytePtr
    //   6130: dup
    //   6131: ldc_w '%->% '
    //   6134: invokevirtual getBytes : ()[B
    //   6137: iconst_0
    //   6138: invokespecial <init> : ([BI)V
    //   6141: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6146: aload #4
    //   6148: bipush #29
    //   6150: sipush #174
    //   6153: invokeinterface setAlignedInt : (II)V
    //   6158: aload #4
    //   6160: bipush #30
    //   6162: new org/renjin/gcc/runtime/BytePtr
    //   6165: dup
    //   6166: ldc_w '%down% '
    //   6169: invokevirtual getBytes : ()[B
    //   6172: iconst_0
    //   6173: invokespecial <init> : ([BI)V
    //   6176: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6181: aload #4
    //   6183: bipush #31
    //   6185: sipush #175
    //   6188: invokeinterface setAlignedInt : (II)V
    //   6193: aload #4
    //   6195: bipush #32
    //   6197: new org/renjin/gcc/runtime/BytePtr
    //   6200: dup
    //   6201: ldc_w '%<=>% '
    //   6204: invokevirtual getBytes : ()[B
    //   6207: iconst_0
    //   6208: invokespecial <init> : ([BI)V
    //   6211: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6216: aload #4
    //   6218: bipush #33
    //   6220: sipush #219
    //   6223: invokeinterface setAlignedInt : (II)V
    //   6228: aload #4
    //   6230: bipush #34
    //   6232: new org/renjin/gcc/runtime/BytePtr
    //   6235: dup
    //   6236: ldc_w '%<=% '
    //   6239: invokevirtual getBytes : ()[B
    //   6242: iconst_0
    //   6243: invokespecial <init> : ([BI)V
    //   6246: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6251: aload #4
    //   6253: bipush #35
    //   6255: sipush #220
    //   6258: invokeinterface setAlignedInt : (II)V
    //   6263: aload #4
    //   6265: bipush #36
    //   6267: new org/renjin/gcc/runtime/BytePtr
    //   6270: dup
    //   6271: ldc_w '%dblup% '
    //   6274: invokevirtual getBytes : ()[B
    //   6277: iconst_0
    //   6278: invokespecial <init> : ([BI)V
    //   6281: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6286: aload #4
    //   6288: bipush #37
    //   6290: sipush #221
    //   6293: invokeinterface setAlignedInt : (II)V
    //   6298: aload #4
    //   6300: bipush #38
    //   6302: new org/renjin/gcc/runtime/BytePtr
    //   6305: dup
    //   6306: ldc_w '%=>% '
    //   6309: invokevirtual getBytes : ()[B
    //   6312: iconst_0
    //   6313: invokespecial <init> : ([BI)V
    //   6316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6321: aload #4
    //   6323: bipush #39
    //   6325: sipush #222
    //   6328: invokeinterface setAlignedInt : (II)V
    //   6333: aload #4
    //   6335: bipush #40
    //   6337: new org/renjin/gcc/runtime/BytePtr
    //   6340: dup
    //   6341: ldc_w '%dbldown% '
    //   6344: invokevirtual getBytes : ()[B
    //   6347: iconst_0
    //   6348: invokespecial <init> : ([BI)V
    //   6351: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6356: aload #4
    //   6358: bipush #41
    //   6360: sipush #223
    //   6363: invokeinterface setAlignedInt : (II)V
    //   6368: aload #4
    //   6370: bipush #42
    //   6372: new org/renjin/gcc/runtime/BytePtr
    //   6375: dup
    //   6376: ldc_w '%supset% '
    //   6379: invokevirtual getBytes : ()[B
    //   6382: iconst_0
    //   6383: invokespecial <init> : ([BI)V
    //   6386: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6391: aload #4
    //   6393: bipush #43
    //   6395: sipush #201
    //   6398: invokeinterface setAlignedInt : (II)V
    //   6403: aload #4
    //   6405: bipush #44
    //   6407: new org/renjin/gcc/runtime/BytePtr
    //   6410: dup
    //   6411: ldc_w '%supseteq% '
    //   6414: invokevirtual getBytes : ()[B
    //   6417: iconst_0
    //   6418: invokespecial <init> : ([BI)V
    //   6421: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6426: aload #4
    //   6428: bipush #45
    //   6430: sipush #202
    //   6433: invokeinterface setAlignedInt : (II)V
    //   6438: aload #4
    //   6440: bipush #46
    //   6442: new org/renjin/gcc/runtime/BytePtr
    //   6445: dup
    //   6446: ldc_w '%notsubset% '
    //   6449: invokevirtual getBytes : ()[B
    //   6452: iconst_0
    //   6453: invokespecial <init> : ([BI)V
    //   6456: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6461: aload #4
    //   6463: bipush #47
    //   6465: sipush #203
    //   6468: invokeinterface setAlignedInt : (II)V
    //   6473: aload #4
    //   6475: bipush #48
    //   6477: new org/renjin/gcc/runtime/BytePtr
    //   6480: dup
    //   6481: ldc_w '%subset% '
    //   6484: invokevirtual getBytes : ()[B
    //   6487: iconst_0
    //   6488: invokespecial <init> : ([BI)V
    //   6491: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6496: aload #4
    //   6498: bipush #49
    //   6500: sipush #204
    //   6503: invokeinterface setAlignedInt : (II)V
    //   6508: aload #4
    //   6510: bipush #50
    //   6512: new org/renjin/gcc/runtime/BytePtr
    //   6515: dup
    //   6516: ldc_w '%subseteq% '
    //   6519: invokevirtual getBytes : ()[B
    //   6522: iconst_0
    //   6523: invokespecial <init> : ([BI)V
    //   6526: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6531: aload #4
    //   6533: bipush #51
    //   6535: sipush #205
    //   6538: invokeinterface setAlignedInt : (II)V
    //   6543: aload #4
    //   6545: bipush #52
    //   6547: new org/renjin/gcc/runtime/BytePtr
    //   6550: dup
    //   6551: ldc_w '%in% '
    //   6554: invokevirtual getBytes : ()[B
    //   6557: iconst_0
    //   6558: invokespecial <init> : ([BI)V
    //   6561: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6566: aload #4
    //   6568: bipush #53
    //   6570: sipush #206
    //   6573: invokeinterface setAlignedInt : (II)V
    //   6578: aload #4
    //   6580: bipush #54
    //   6582: new org/renjin/gcc/runtime/BytePtr
    //   6585: dup
    //   6586: ldc_w '%notin% '
    //   6589: invokevirtual getBytes : ()[B
    //   6592: iconst_0
    //   6593: invokespecial <init> : ([BI)V
    //   6596: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6601: aload #4
    //   6603: bipush #55
    //   6605: sipush #207
    //   6608: invokeinterface setAlignedInt : (II)V
    //   6613: aload #4
    //   6615: bipush #56
    //   6617: iconst_0
    //   6618: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   6621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6626: aload #4
    //   6628: bipush #57
    //   6630: iconst_0
    //   6631: invokeinterface setAlignedInt : (II)V
    //   6636: aload_0
    //   6637: getfield plotmath$RelTable : Lorg/renjin/gcc/runtime/Ptr;
    //   6640: aload #4
    //   6642: sipush #232
    //   6645: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   6650: bipush #96
    //   6652: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   6655: astore #5
    //   6657: aload #5
    //   6659: new org/renjin/gcc/runtime/BytePtr
    //   6662: dup
    //   6663: ldc_w 'prod '
    //   6666: invokevirtual getBytes : ()[B
    //   6669: iconst_0
    //   6670: invokespecial <init> : ([BI)V
    //   6673: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   6678: aload #5
    //   6680: iconst_1
    //   6681: sipush #213
    //   6684: invokeinterface setAlignedInt : (II)V
    //   6689: aload #5
    //   6691: iconst_2
    //   6692: new org/renjin/gcc/runtime/BytePtr
    //   6695: dup
    //   6696: ldc_w 'sum '
    //   6699: invokevirtual getBytes : ()[B
    //   6702: iconst_0
    //   6703: invokespecial <init> : ([BI)V
    //   6706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6711: aload #5
    //   6713: iconst_3
    //   6714: sipush #229
    //   6717: invokeinterface setAlignedInt : (II)V
    //   6722: aload #5
    //   6724: iconst_4
    //   6725: new org/renjin/gcc/runtime/BytePtr
    //   6728: dup
    //   6729: ldc_w 'union '
    //   6732: invokevirtual getBytes : ()[B
    //   6735: iconst_0
    //   6736: invokespecial <init> : ([BI)V
    //   6739: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6744: aload #5
    //   6746: iconst_5
    //   6747: sipush #200
    //   6750: invokeinterface setAlignedInt : (II)V
    //   6755: aload #5
    //   6757: bipush #6
    //   6759: new org/renjin/gcc/runtime/BytePtr
    //   6762: dup
    //   6763: ldc_w 'intersect '
    //   6766: invokevirtual getBytes : ()[B
    //   6769: iconst_0
    //   6770: invokespecial <init> : ([BI)V
    //   6773: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6778: aload #5
    //   6780: bipush #7
    //   6782: sipush #199
    //   6785: invokeinterface setAlignedInt : (II)V
    //   6790: aload #5
    //   6792: bipush #8
    //   6794: new org/renjin/gcc/runtime/BytePtr
    //   6797: dup
    //   6798: ldc_w 'lim '
    //   6801: invokevirtual getBytes : ()[B
    //   6804: iconst_0
    //   6805: invokespecial <init> : ([BI)V
    //   6808: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6813: aload #5
    //   6815: bipush #9
    //   6817: sipush #1001
    //   6820: invokeinterface setAlignedInt : (II)V
    //   6825: aload #5
    //   6827: bipush #10
    //   6829: new org/renjin/gcc/runtime/BytePtr
    //   6832: dup
    //   6833: ldc_w 'liminf '
    //   6836: invokevirtual getBytes : ()[B
    //   6839: iconst_0
    //   6840: invokespecial <init> : ([BI)V
    //   6843: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6848: aload #5
    //   6850: bipush #11
    //   6852: sipush #1002
    //   6855: invokeinterface setAlignedInt : (II)V
    //   6860: aload #5
    //   6862: bipush #12
    //   6864: new org/renjin/gcc/runtime/BytePtr
    //   6867: dup
    //   6868: ldc_w 'limsup '
    //   6871: invokevirtual getBytes : ()[B
    //   6874: iconst_0
    //   6875: invokespecial <init> : ([BI)V
    //   6878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6883: aload #5
    //   6885: bipush #13
    //   6887: sipush #1002
    //   6890: invokeinterface setAlignedInt : (II)V
    //   6895: aload #5
    //   6897: bipush #14
    //   6899: new org/renjin/gcc/runtime/BytePtr
    //   6902: dup
    //   6903: ldc_w 'inf '
    //   6906: invokevirtual getBytes : ()[B
    //   6909: iconst_0
    //   6910: invokespecial <init> : ([BI)V
    //   6913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6918: aload #5
    //   6920: bipush #15
    //   6922: sipush #1004
    //   6925: invokeinterface setAlignedInt : (II)V
    //   6930: aload #5
    //   6932: bipush #16
    //   6934: new org/renjin/gcc/runtime/BytePtr
    //   6937: dup
    //   6938: ldc_w 'sup '
    //   6941: invokevirtual getBytes : ()[B
    //   6944: iconst_0
    //   6945: invokespecial <init> : ([BI)V
    //   6948: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6953: aload #5
    //   6955: bipush #17
    //   6957: sipush #1005
    //   6960: invokeinterface setAlignedInt : (II)V
    //   6965: aload #5
    //   6967: bipush #18
    //   6969: new org/renjin/gcc/runtime/BytePtr
    //   6972: dup
    //   6973: ldc_w 'min '
    //   6976: invokevirtual getBytes : ()[B
    //   6979: iconst_0
    //   6980: invokespecial <init> : ([BI)V
    //   6983: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6988: aload #5
    //   6990: bipush #19
    //   6992: sipush #1006
    //   6995: invokeinterface setAlignedInt : (II)V
    //   7000: aload #5
    //   7002: bipush #20
    //   7004: new org/renjin/gcc/runtime/BytePtr
    //   7007: dup
    //   7008: ldc_w 'max '
    //   7011: invokevirtual getBytes : ()[B
    //   7014: iconst_0
    //   7015: invokespecial <init> : ([BI)V
    //   7018: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7023: aload #5
    //   7025: bipush #21
    //   7027: sipush #1007
    //   7030: invokeinterface setAlignedInt : (II)V
    //   7035: aload #5
    //   7037: bipush #22
    //   7039: iconst_0
    //   7040: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   7043: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7048: aload #5
    //   7050: bipush #23
    //   7052: iconst_0
    //   7053: invokeinterface setAlignedInt : (II)V
    //   7058: aload_0
    //   7059: getfield plotmath$OpTable : Lorg/renjin/gcc/runtime/Ptr;
    //   7062: aload #5
    //   7064: bipush #96
    //   7066: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   7071: bipush #40
    //   7073: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   7076: astore #6
    //   7078: aload #6
    //   7080: new org/renjin/gcc/runtime/BytePtr
    //   7083: dup
    //   7084: ldc_w 'hat '
    //   7087: invokevirtual getBytes : ()[B
    //   7090: iconst_0
    //   7091: invokespecial <init> : ([BI)V
    //   7094: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   7099: aload #6
    //   7101: iconst_1
    //   7102: bipush #94
    //   7104: invokeinterface setAlignedInt : (II)V
    //   7109: aload #6
    //   7111: iconst_2
    //   7112: new org/renjin/gcc/runtime/BytePtr
    //   7115: dup
    //   7116: ldc_w 'ring '
    //   7119: invokevirtual getBytes : ()[B
    //   7122: iconst_0
    //   7123: invokespecial <init> : ([BI)V
    //   7126: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7131: aload #6
    //   7133: iconst_3
    //   7134: sipush #176
    //   7137: invokeinterface setAlignedInt : (II)V
    //   7142: aload #6
    //   7144: iconst_4
    //   7145: new org/renjin/gcc/runtime/BytePtr
    //   7148: dup
    //   7149: ldc_w 'tilde '
    //   7152: invokevirtual getBytes : ()[B
    //   7155: iconst_0
    //   7156: invokespecial <init> : ([BI)V
    //   7159: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7164: aload #6
    //   7166: iconst_5
    //   7167: bipush #126
    //   7169: invokeinterface setAlignedInt : (II)V
    //   7174: aload #6
    //   7176: bipush #6
    //   7178: new org/renjin/gcc/runtime/BytePtr
    //   7181: dup
    //   7182: ldc_w 'dot '
    //   7185: invokevirtual getBytes : ()[B
    //   7188: iconst_0
    //   7189: invokespecial <init> : ([BI)V
    //   7192: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7197: aload #6
    //   7199: bipush #7
    //   7201: sipush #215
    //   7204: invokeinterface setAlignedInt : (II)V
    //   7209: aload #6
    //   7211: bipush #8
    //   7213: iconst_0
    //   7214: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   7217: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7222: aload #6
    //   7224: bipush #9
    //   7226: iconst_0
    //   7227: invokeinterface setAlignedInt : (II)V
    //   7232: aload_0
    //   7233: getfield plotmath$AccentTable : Lorg/renjin/gcc/runtime/Ptr;
    //   7236: aload #6
    //   7238: bipush #40
    //   7240: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   7245: bipush #96
    //   7247: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   7250: astore #7
    //   7252: aload #7
    //   7254: new org/renjin/gcc/runtime/BytePtr
    //   7257: dup
    //   7258: ldc_w '* '
    //   7261: invokevirtual getBytes : ()[B
    //   7264: iconst_0
    //   7265: invokespecial <init> : ([BI)V
    //   7268: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   7273: aload #7
    //   7275: iconst_1
    //   7276: bipush #42
    //   7278: invokeinterface setAlignedInt : (II)V
    //   7283: aload #7
    //   7285: iconst_2
    //   7286: new org/renjin/gcc/runtime/BytePtr
    //   7289: dup
    //   7290: ldc_w '+ '
    //   7293: invokevirtual getBytes : ()[B
    //   7296: iconst_0
    //   7297: invokespecial <init> : ([BI)V
    //   7300: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7305: aload #7
    //   7307: iconst_3
    //   7308: bipush #43
    //   7310: invokeinterface setAlignedInt : (II)V
    //   7315: aload #7
    //   7317: iconst_4
    //   7318: new org/renjin/gcc/runtime/BytePtr
    //   7321: dup
    //   7322: ldc_w '- '
    //   7325: invokevirtual getBytes : ()[B
    //   7328: iconst_0
    //   7329: invokespecial <init> : ([BI)V
    //   7332: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7337: aload #7
    //   7339: iconst_5
    //   7340: bipush #45
    //   7342: invokeinterface setAlignedInt : (II)V
    //   7347: aload #7
    //   7349: bipush #6
    //   7351: new org/renjin/gcc/runtime/BytePtr
    //   7354: dup
    //   7355: ldc_w '/ '
    //   7358: invokevirtual getBytes : ()[B
    //   7361: iconst_0
    //   7362: invokespecial <init> : ([BI)V
    //   7365: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7370: aload #7
    //   7372: bipush #7
    //   7374: bipush #47
    //   7376: invokeinterface setAlignedInt : (II)V
    //   7381: aload #7
    //   7383: bipush #8
    //   7385: new org/renjin/gcc/runtime/BytePtr
    //   7388: dup
    //   7389: ldc_w ': '
    //   7392: invokevirtual getBytes : ()[B
    //   7395: iconst_0
    //   7396: invokespecial <init> : ([BI)V
    //   7399: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7404: aload #7
    //   7406: bipush #9
    //   7408: bipush #58
    //   7410: invokeinterface setAlignedInt : (II)V
    //   7415: aload #7
    //   7417: bipush #10
    //   7419: new org/renjin/gcc/runtime/BytePtr
    //   7422: dup
    //   7423: ldc_w '%+-% '
    //   7426: invokevirtual getBytes : ()[B
    //   7429: iconst_0
    //   7430: invokespecial <init> : ([BI)V
    //   7433: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7438: aload #7
    //   7440: bipush #11
    //   7442: sipush #177
    //   7445: invokeinterface setAlignedInt : (II)V
    //   7450: aload #7
    //   7452: bipush #12
    //   7454: new org/renjin/gcc/runtime/BytePtr
    //   7457: dup
    //   7458: ldc_w '%*% '
    //   7461: invokevirtual getBytes : ()[B
    //   7464: iconst_0
    //   7465: invokespecial <init> : ([BI)V
    //   7468: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7473: aload #7
    //   7475: bipush #13
    //   7477: sipush #180
    //   7480: invokeinterface setAlignedInt : (II)V
    //   7485: aload #7
    //   7487: bipush #14
    //   7489: new org/renjin/gcc/runtime/BytePtr
    //   7492: dup
    //   7493: ldc_w '%/% '
    //   7496: invokevirtual getBytes : ()[B
    //   7499: iconst_0
    //   7500: invokespecial <init> : ([BI)V
    //   7503: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7508: aload #7
    //   7510: bipush #15
    //   7512: sipush #184
    //   7515: invokeinterface setAlignedInt : (II)V
    //   7520: aload #7
    //   7522: bipush #16
    //   7524: new org/renjin/gcc/runtime/BytePtr
    //   7527: dup
    //   7528: ldc_w '%intersection% '
    //   7531: invokevirtual getBytes : ()[B
    //   7534: iconst_0
    //   7535: invokespecial <init> : ([BI)V
    //   7538: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7543: aload #7
    //   7545: bipush #17
    //   7547: sipush #199
    //   7550: invokeinterface setAlignedInt : (II)V
    //   7555: aload #7
    //   7557: bipush #18
    //   7559: new org/renjin/gcc/runtime/BytePtr
    //   7562: dup
    //   7563: ldc_w '%union% '
    //   7566: invokevirtual getBytes : ()[B
    //   7569: iconst_0
    //   7570: invokespecial <init> : ([BI)V
    //   7573: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7578: aload #7
    //   7580: bipush #19
    //   7582: sipush #200
    //   7585: invokeinterface setAlignedInt : (II)V
    //   7590: aload #7
    //   7592: bipush #20
    //   7594: new org/renjin/gcc/runtime/BytePtr
    //   7597: dup
    //   7598: ldc_w '%.% '
    //   7601: invokevirtual getBytes : ()[B
    //   7604: iconst_0
    //   7605: invokespecial <init> : ([BI)V
    //   7608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7613: aload #7
    //   7615: bipush #21
    //   7617: sipush #215
    //   7620: invokeinterface setAlignedInt : (II)V
    //   7625: aload #7
    //   7627: bipush #22
    //   7629: iconst_0
    //   7630: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   7633: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7638: aload #7
    //   7640: bipush #23
    //   7642: iconst_0
    //   7643: invokeinterface setAlignedInt : (II)V
    //   7648: aload_0
    //   7649: getfield plotmath$BinTable : Lorg/renjin/gcc/runtime/Ptr;
    //   7652: aload #7
    //   7654: bipush #96
    //   7656: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   7661: sipush #1536
    //   7664: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   7667: astore #8
    //   7669: aload #8
    //   7671: new org/renjin/gcc/runtime/BytePtr
    //   7674: dup
    //   7675: ldc_w 'space '
    //   7678: invokevirtual getBytes : ()[B
    //   7681: iconst_0
    //   7682: invokespecial <init> : ([BI)V
    //   7685: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   7690: aload #8
    //   7692: iconst_1
    //   7693: bipush #32
    //   7695: invokeinterface setAlignedInt : (II)V
    //   7700: aload #8
    //   7702: iconst_2
    //   7703: new org/renjin/gcc/runtime/BytePtr
    //   7706: dup
    //   7707: ldc_w 'exclam '
    //   7710: invokevirtual getBytes : ()[B
    //   7713: iconst_0
    //   7714: invokespecial <init> : ([BI)V
    //   7717: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7722: aload #8
    //   7724: iconst_3
    //   7725: bipush #33
    //   7727: invokeinterface setAlignedInt : (II)V
    //   7732: aload #8
    //   7734: iconst_4
    //   7735: new org/renjin/gcc/runtime/BytePtr
    //   7738: dup
    //   7739: ldc_w 'universal '
    //   7742: invokevirtual getBytes : ()[B
    //   7745: iconst_0
    //   7746: invokespecial <init> : ([BI)V
    //   7749: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7754: aload #8
    //   7756: iconst_5
    //   7757: bipush #34
    //   7759: invokeinterface setAlignedInt : (II)V
    //   7764: aload #8
    //   7766: bipush #6
    //   7768: new org/renjin/gcc/runtime/BytePtr
    //   7771: dup
    //   7772: ldc_w 'numbersign '
    //   7775: invokevirtual getBytes : ()[B
    //   7778: iconst_0
    //   7779: invokespecial <init> : ([BI)V
    //   7782: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7787: aload #8
    //   7789: bipush #7
    //   7791: bipush #35
    //   7793: invokeinterface setAlignedInt : (II)V
    //   7798: aload #8
    //   7800: bipush #8
    //   7802: new org/renjin/gcc/runtime/BytePtr
    //   7805: dup
    //   7806: ldc_w 'existential '
    //   7809: invokevirtual getBytes : ()[B
    //   7812: iconst_0
    //   7813: invokespecial <init> : ([BI)V
    //   7816: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7821: aload #8
    //   7823: bipush #9
    //   7825: bipush #36
    //   7827: invokeinterface setAlignedInt : (II)V
    //   7832: aload #8
    //   7834: bipush #10
    //   7836: new org/renjin/gcc/runtime/BytePtr
    //   7839: dup
    //   7840: ldc_w 'percent '
    //   7843: invokevirtual getBytes : ()[B
    //   7846: iconst_0
    //   7847: invokespecial <init> : ([BI)V
    //   7850: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7855: aload #8
    //   7857: bipush #11
    //   7859: bipush #37
    //   7861: invokeinterface setAlignedInt : (II)V
    //   7866: aload #8
    //   7868: bipush #12
    //   7870: new org/renjin/gcc/runtime/BytePtr
    //   7873: dup
    //   7874: ldc_w 'ampersand '
    //   7877: invokevirtual getBytes : ()[B
    //   7880: iconst_0
    //   7881: invokespecial <init> : ([BI)V
    //   7884: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7889: aload #8
    //   7891: bipush #13
    //   7893: bipush #38
    //   7895: invokeinterface setAlignedInt : (II)V
    //   7900: aload #8
    //   7902: bipush #14
    //   7904: new org/renjin/gcc/runtime/BytePtr
    //   7907: dup
    //   7908: ldc_w 'suchthat '
    //   7911: invokevirtual getBytes : ()[B
    //   7914: iconst_0
    //   7915: invokespecial <init> : ([BI)V
    //   7918: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7923: aload #8
    //   7925: bipush #15
    //   7927: bipush #39
    //   7929: invokeinterface setAlignedInt : (II)V
    //   7934: aload #8
    //   7936: bipush #16
    //   7938: new org/renjin/gcc/runtime/BytePtr
    //   7941: dup
    //   7942: ldc_w 'parenleft '
    //   7945: invokevirtual getBytes : ()[B
    //   7948: iconst_0
    //   7949: invokespecial <init> : ([BI)V
    //   7952: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7957: aload #8
    //   7959: bipush #17
    //   7961: bipush #40
    //   7963: invokeinterface setAlignedInt : (II)V
    //   7968: aload #8
    //   7970: bipush #18
    //   7972: new org/renjin/gcc/runtime/BytePtr
    //   7975: dup
    //   7976: ldc_w 'parenright '
    //   7979: invokevirtual getBytes : ()[B
    //   7982: iconst_0
    //   7983: invokespecial <init> : ([BI)V
    //   7986: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7991: aload #8
    //   7993: bipush #19
    //   7995: bipush #41
    //   7997: invokeinterface setAlignedInt : (II)V
    //   8002: aload #8
    //   8004: bipush #20
    //   8006: new org/renjin/gcc/runtime/BytePtr
    //   8009: dup
    //   8010: ldc_w 'asteriskmath '
    //   8013: invokevirtual getBytes : ()[B
    //   8016: iconst_0
    //   8017: invokespecial <init> : ([BI)V
    //   8020: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8025: aload #8
    //   8027: bipush #21
    //   8029: bipush #42
    //   8031: invokeinterface setAlignedInt : (II)V
    //   8036: aload #8
    //   8038: bipush #22
    //   8040: new org/renjin/gcc/runtime/BytePtr
    //   8043: dup
    //   8044: ldc_w 'plus '
    //   8047: invokevirtual getBytes : ()[B
    //   8050: iconst_0
    //   8051: invokespecial <init> : ([BI)V
    //   8054: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8059: aload #8
    //   8061: bipush #23
    //   8063: bipush #43
    //   8065: invokeinterface setAlignedInt : (II)V
    //   8070: aload #8
    //   8072: bipush #24
    //   8074: new org/renjin/gcc/runtime/BytePtr
    //   8077: dup
    //   8078: ldc_w 'comma '
    //   8081: invokevirtual getBytes : ()[B
    //   8084: iconst_0
    //   8085: invokespecial <init> : ([BI)V
    //   8088: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8093: aload #8
    //   8095: bipush #25
    //   8097: bipush #44
    //   8099: invokeinterface setAlignedInt : (II)V
    //   8104: aload #8
    //   8106: bipush #26
    //   8108: new org/renjin/gcc/runtime/BytePtr
    //   8111: dup
    //   8112: ldc_w 'minus '
    //   8115: invokevirtual getBytes : ()[B
    //   8118: iconst_0
    //   8119: invokespecial <init> : ([BI)V
    //   8122: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8127: aload #8
    //   8129: bipush #27
    //   8131: bipush #45
    //   8133: invokeinterface setAlignedInt : (II)V
    //   8138: aload #8
    //   8140: bipush #28
    //   8142: new org/renjin/gcc/runtime/BytePtr
    //   8145: dup
    //   8146: ldc_w 'period '
    //   8149: invokevirtual getBytes : ()[B
    //   8152: iconst_0
    //   8153: invokespecial <init> : ([BI)V
    //   8156: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8161: aload #8
    //   8163: bipush #29
    //   8165: bipush #46
    //   8167: invokeinterface setAlignedInt : (II)V
    //   8172: aload #8
    //   8174: bipush #30
    //   8176: new org/renjin/gcc/runtime/BytePtr
    //   8179: dup
    //   8180: ldc_w 'slash '
    //   8183: invokevirtual getBytes : ()[B
    //   8186: iconst_0
    //   8187: invokespecial <init> : ([BI)V
    //   8190: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8195: aload #8
    //   8197: bipush #31
    //   8199: bipush #47
    //   8201: invokeinterface setAlignedInt : (II)V
    //   8206: aload #8
    //   8208: bipush #32
    //   8210: new org/renjin/gcc/runtime/BytePtr
    //   8213: dup
    //   8214: ldc_w '0 '
    //   8217: invokevirtual getBytes : ()[B
    //   8220: iconst_0
    //   8221: invokespecial <init> : ([BI)V
    //   8224: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8229: aload #8
    //   8231: bipush #33
    //   8233: bipush #48
    //   8235: invokeinterface setAlignedInt : (II)V
    //   8240: aload #8
    //   8242: bipush #34
    //   8244: new org/renjin/gcc/runtime/BytePtr
    //   8247: dup
    //   8248: ldc_w '1 '
    //   8251: invokevirtual getBytes : ()[B
    //   8254: iconst_0
    //   8255: invokespecial <init> : ([BI)V
    //   8258: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8263: aload #8
    //   8265: bipush #35
    //   8267: bipush #49
    //   8269: invokeinterface setAlignedInt : (II)V
    //   8274: aload #8
    //   8276: bipush #36
    //   8278: new org/renjin/gcc/runtime/BytePtr
    //   8281: dup
    //   8282: ldc_w '2 '
    //   8285: invokevirtual getBytes : ()[B
    //   8288: iconst_0
    //   8289: invokespecial <init> : ([BI)V
    //   8292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8297: aload #8
    //   8299: bipush #37
    //   8301: bipush #50
    //   8303: invokeinterface setAlignedInt : (II)V
    //   8308: aload #8
    //   8310: bipush #38
    //   8312: new org/renjin/gcc/runtime/BytePtr
    //   8315: dup
    //   8316: ldc_w '3 '
    //   8319: invokevirtual getBytes : ()[B
    //   8322: iconst_0
    //   8323: invokespecial <init> : ([BI)V
    //   8326: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8331: aload #8
    //   8333: bipush #39
    //   8335: bipush #51
    //   8337: invokeinterface setAlignedInt : (II)V
    //   8342: aload #8
    //   8344: bipush #40
    //   8346: new org/renjin/gcc/runtime/BytePtr
    //   8349: dup
    //   8350: ldc_w '4 '
    //   8353: invokevirtual getBytes : ()[B
    //   8356: iconst_0
    //   8357: invokespecial <init> : ([BI)V
    //   8360: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8365: aload #8
    //   8367: bipush #41
    //   8369: bipush #52
    //   8371: invokeinterface setAlignedInt : (II)V
    //   8376: aload #8
    //   8378: bipush #42
    //   8380: new org/renjin/gcc/runtime/BytePtr
    //   8383: dup
    //   8384: ldc_w '5 '
    //   8387: invokevirtual getBytes : ()[B
    //   8390: iconst_0
    //   8391: invokespecial <init> : ([BI)V
    //   8394: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8399: aload #8
    //   8401: bipush #43
    //   8403: bipush #53
    //   8405: invokeinterface setAlignedInt : (II)V
    //   8410: aload #8
    //   8412: bipush #44
    //   8414: new org/renjin/gcc/runtime/BytePtr
    //   8417: dup
    //   8418: ldc_w '6 '
    //   8421: invokevirtual getBytes : ()[B
    //   8424: iconst_0
    //   8425: invokespecial <init> : ([BI)V
    //   8428: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8433: aload #8
    //   8435: bipush #45
    //   8437: bipush #54
    //   8439: invokeinterface setAlignedInt : (II)V
    //   8444: aload #8
    //   8446: bipush #46
    //   8448: new org/renjin/gcc/runtime/BytePtr
    //   8451: dup
    //   8452: ldc_w '7 '
    //   8455: invokevirtual getBytes : ()[B
    //   8458: iconst_0
    //   8459: invokespecial <init> : ([BI)V
    //   8462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8467: aload #8
    //   8469: bipush #47
    //   8471: bipush #55
    //   8473: invokeinterface setAlignedInt : (II)V
    //   8478: aload #8
    //   8480: bipush #48
    //   8482: new org/renjin/gcc/runtime/BytePtr
    //   8485: dup
    //   8486: ldc_w '8 '
    //   8489: invokevirtual getBytes : ()[B
    //   8492: iconst_0
    //   8493: invokespecial <init> : ([BI)V
    //   8496: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8501: aload #8
    //   8503: bipush #49
    //   8505: bipush #56
    //   8507: invokeinterface setAlignedInt : (II)V
    //   8512: aload #8
    //   8514: bipush #50
    //   8516: new org/renjin/gcc/runtime/BytePtr
    //   8519: dup
    //   8520: ldc_w '9 '
    //   8523: invokevirtual getBytes : ()[B
    //   8526: iconst_0
    //   8527: invokespecial <init> : ([BI)V
    //   8530: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8535: aload #8
    //   8537: bipush #51
    //   8539: bipush #57
    //   8541: invokeinterface setAlignedInt : (II)V
    //   8546: aload #8
    //   8548: bipush #52
    //   8550: new org/renjin/gcc/runtime/BytePtr
    //   8553: dup
    //   8554: ldc_w 'colon '
    //   8557: invokevirtual getBytes : ()[B
    //   8560: iconst_0
    //   8561: invokespecial <init> : ([BI)V
    //   8564: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8569: aload #8
    //   8571: bipush #53
    //   8573: bipush #58
    //   8575: invokeinterface setAlignedInt : (II)V
    //   8580: aload #8
    //   8582: bipush #54
    //   8584: new org/renjin/gcc/runtime/BytePtr
    //   8587: dup
    //   8588: ldc_w 'semicolon '
    //   8591: invokevirtual getBytes : ()[B
    //   8594: iconst_0
    //   8595: invokespecial <init> : ([BI)V
    //   8598: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8603: aload #8
    //   8605: bipush #55
    //   8607: bipush #59
    //   8609: invokeinterface setAlignedInt : (II)V
    //   8614: aload #8
    //   8616: bipush #56
    //   8618: new org/renjin/gcc/runtime/BytePtr
    //   8621: dup
    //   8622: ldc_w 'less '
    //   8625: invokevirtual getBytes : ()[B
    //   8628: iconst_0
    //   8629: invokespecial <init> : ([BI)V
    //   8632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8637: aload #8
    //   8639: bipush #57
    //   8641: bipush #60
    //   8643: invokeinterface setAlignedInt : (II)V
    //   8648: aload #8
    //   8650: bipush #58
    //   8652: new org/renjin/gcc/runtime/BytePtr
    //   8655: dup
    //   8656: ldc_w 'equal '
    //   8659: invokevirtual getBytes : ()[B
    //   8662: iconst_0
    //   8663: invokespecial <init> : ([BI)V
    //   8666: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8671: aload #8
    //   8673: bipush #59
    //   8675: bipush #61
    //   8677: invokeinterface setAlignedInt : (II)V
    //   8682: aload #8
    //   8684: bipush #60
    //   8686: new org/renjin/gcc/runtime/BytePtr
    //   8689: dup
    //   8690: ldc_w 'greater '
    //   8693: invokevirtual getBytes : ()[B
    //   8696: iconst_0
    //   8697: invokespecial <init> : ([BI)V
    //   8700: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8705: aload #8
    //   8707: bipush #61
    //   8709: bipush #62
    //   8711: invokeinterface setAlignedInt : (II)V
    //   8716: aload #8
    //   8718: bipush #62
    //   8720: new org/renjin/gcc/runtime/BytePtr
    //   8723: dup
    //   8724: ldc_w 'question '
    //   8727: invokevirtual getBytes : ()[B
    //   8730: iconst_0
    //   8731: invokespecial <init> : ([BI)V
    //   8734: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8739: aload #8
    //   8741: bipush #63
    //   8743: bipush #63
    //   8745: invokeinterface setAlignedInt : (II)V
    //   8750: aload #8
    //   8752: bipush #64
    //   8754: new org/renjin/gcc/runtime/BytePtr
    //   8757: dup
    //   8758: ldc_w 'congruent '
    //   8761: invokevirtual getBytes : ()[B
    //   8764: iconst_0
    //   8765: invokespecial <init> : ([BI)V
    //   8768: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8773: aload #8
    //   8775: bipush #65
    //   8777: bipush #64
    //   8779: invokeinterface setAlignedInt : (II)V
    //   8784: aload #8
    //   8786: bipush #66
    //   8788: new org/renjin/gcc/runtime/BytePtr
    //   8791: dup
    //   8792: ldc_w 'Alpha '
    //   8795: invokevirtual getBytes : ()[B
    //   8798: iconst_0
    //   8799: invokespecial <init> : ([BI)V
    //   8802: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8807: aload #8
    //   8809: bipush #67
    //   8811: bipush #65
    //   8813: invokeinterface setAlignedInt : (II)V
    //   8818: aload #8
    //   8820: bipush #68
    //   8822: new org/renjin/gcc/runtime/BytePtr
    //   8825: dup
    //   8826: ldc_w 'Beta '
    //   8829: invokevirtual getBytes : ()[B
    //   8832: iconst_0
    //   8833: invokespecial <init> : ([BI)V
    //   8836: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8841: aload #8
    //   8843: bipush #69
    //   8845: bipush #66
    //   8847: invokeinterface setAlignedInt : (II)V
    //   8852: aload #8
    //   8854: bipush #70
    //   8856: new org/renjin/gcc/runtime/BytePtr
    //   8859: dup
    //   8860: ldc_w 'Chi '
    //   8863: invokevirtual getBytes : ()[B
    //   8866: iconst_0
    //   8867: invokespecial <init> : ([BI)V
    //   8870: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8875: aload #8
    //   8877: bipush #71
    //   8879: bipush #67
    //   8881: invokeinterface setAlignedInt : (II)V
    //   8886: aload #8
    //   8888: bipush #72
    //   8890: new org/renjin/gcc/runtime/BytePtr
    //   8893: dup
    //   8894: ldc_w 'Delta '
    //   8897: invokevirtual getBytes : ()[B
    //   8900: iconst_0
    //   8901: invokespecial <init> : ([BI)V
    //   8904: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8909: aload #8
    //   8911: bipush #73
    //   8913: bipush #68
    //   8915: invokeinterface setAlignedInt : (II)V
    //   8920: aload #8
    //   8922: bipush #74
    //   8924: new org/renjin/gcc/runtime/BytePtr
    //   8927: dup
    //   8928: ldc_w 'Epsilon '
    //   8931: invokevirtual getBytes : ()[B
    //   8934: iconst_0
    //   8935: invokespecial <init> : ([BI)V
    //   8938: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8943: aload #8
    //   8945: bipush #75
    //   8947: bipush #69
    //   8949: invokeinterface setAlignedInt : (II)V
    //   8954: aload #8
    //   8956: bipush #76
    //   8958: new org/renjin/gcc/runtime/BytePtr
    //   8961: dup
    //   8962: ldc_w 'Phi '
    //   8965: invokevirtual getBytes : ()[B
    //   8968: iconst_0
    //   8969: invokespecial <init> : ([BI)V
    //   8972: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8977: aload #8
    //   8979: bipush #77
    //   8981: bipush #70
    //   8983: invokeinterface setAlignedInt : (II)V
    //   8988: aload #8
    //   8990: bipush #78
    //   8992: new org/renjin/gcc/runtime/BytePtr
    //   8995: dup
    //   8996: ldc_w 'Gamma '
    //   8999: invokevirtual getBytes : ()[B
    //   9002: iconst_0
    //   9003: invokespecial <init> : ([BI)V
    //   9006: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9011: aload #8
    //   9013: bipush #79
    //   9015: bipush #71
    //   9017: invokeinterface setAlignedInt : (II)V
    //   9022: aload #8
    //   9024: bipush #80
    //   9026: new org/renjin/gcc/runtime/BytePtr
    //   9029: dup
    //   9030: ldc_w 'Eta '
    //   9033: invokevirtual getBytes : ()[B
    //   9036: iconst_0
    //   9037: invokespecial <init> : ([BI)V
    //   9040: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9045: aload #8
    //   9047: bipush #81
    //   9049: bipush #72
    //   9051: invokeinterface setAlignedInt : (II)V
    //   9056: aload #8
    //   9058: bipush #82
    //   9060: new org/renjin/gcc/runtime/BytePtr
    //   9063: dup
    //   9064: ldc_w 'Iota '
    //   9067: invokevirtual getBytes : ()[B
    //   9070: iconst_0
    //   9071: invokespecial <init> : ([BI)V
    //   9074: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9079: aload #8
    //   9081: bipush #83
    //   9083: bipush #73
    //   9085: invokeinterface setAlignedInt : (II)V
    //   9090: aload #8
    //   9092: bipush #84
    //   9094: new org/renjin/gcc/runtime/BytePtr
    //   9097: dup
    //   9098: ldc_w 'theta1 '
    //   9101: invokevirtual getBytes : ()[B
    //   9104: iconst_0
    //   9105: invokespecial <init> : ([BI)V
    //   9108: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9113: aload #8
    //   9115: bipush #85
    //   9117: bipush #74
    //   9119: invokeinterface setAlignedInt : (II)V
    //   9124: aload #8
    //   9126: bipush #86
    //   9128: new org/renjin/gcc/runtime/BytePtr
    //   9131: dup
    //   9132: ldc_w 'vartheta '
    //   9135: invokevirtual getBytes : ()[B
    //   9138: iconst_0
    //   9139: invokespecial <init> : ([BI)V
    //   9142: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9147: aload #8
    //   9149: bipush #87
    //   9151: bipush #74
    //   9153: invokeinterface setAlignedInt : (II)V
    //   9158: aload #8
    //   9160: bipush #88
    //   9162: new org/renjin/gcc/runtime/BytePtr
    //   9165: dup
    //   9166: ldc_w 'Kappa '
    //   9169: invokevirtual getBytes : ()[B
    //   9172: iconst_0
    //   9173: invokespecial <init> : ([BI)V
    //   9176: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9181: aload #8
    //   9183: bipush #89
    //   9185: bipush #75
    //   9187: invokeinterface setAlignedInt : (II)V
    //   9192: aload #8
    //   9194: bipush #90
    //   9196: new org/renjin/gcc/runtime/BytePtr
    //   9199: dup
    //   9200: ldc_w 'Lambda '
    //   9203: invokevirtual getBytes : ()[B
    //   9206: iconst_0
    //   9207: invokespecial <init> : ([BI)V
    //   9210: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9215: aload #8
    //   9217: bipush #91
    //   9219: bipush #76
    //   9221: invokeinterface setAlignedInt : (II)V
    //   9226: aload #8
    //   9228: bipush #92
    //   9230: new org/renjin/gcc/runtime/BytePtr
    //   9233: dup
    //   9234: ldc_w 'Mu '
    //   9237: invokevirtual getBytes : ()[B
    //   9240: iconst_0
    //   9241: invokespecial <init> : ([BI)V
    //   9244: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9249: aload #8
    //   9251: bipush #93
    //   9253: bipush #77
    //   9255: invokeinterface setAlignedInt : (II)V
    //   9260: aload #8
    //   9262: bipush #94
    //   9264: new org/renjin/gcc/runtime/BytePtr
    //   9267: dup
    //   9268: ldc_w 'Nu '
    //   9271: invokevirtual getBytes : ()[B
    //   9274: iconst_0
    //   9275: invokespecial <init> : ([BI)V
    //   9278: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9283: aload #8
    //   9285: bipush #95
    //   9287: bipush #78
    //   9289: invokeinterface setAlignedInt : (II)V
    //   9294: aload #8
    //   9296: bipush #96
    //   9298: new org/renjin/gcc/runtime/BytePtr
    //   9301: dup
    //   9302: ldc_w 'Omicron '
    //   9305: invokevirtual getBytes : ()[B
    //   9308: iconst_0
    //   9309: invokespecial <init> : ([BI)V
    //   9312: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9317: aload #8
    //   9319: bipush #97
    //   9321: bipush #79
    //   9323: invokeinterface setAlignedInt : (II)V
    //   9328: aload #8
    //   9330: bipush #98
    //   9332: new org/renjin/gcc/runtime/BytePtr
    //   9335: dup
    //   9336: ldc_w 'Pi '
    //   9339: invokevirtual getBytes : ()[B
    //   9342: iconst_0
    //   9343: invokespecial <init> : ([BI)V
    //   9346: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9351: aload #8
    //   9353: bipush #99
    //   9355: bipush #80
    //   9357: invokeinterface setAlignedInt : (II)V
    //   9362: aload #8
    //   9364: bipush #100
    //   9366: new org/renjin/gcc/runtime/BytePtr
    //   9369: dup
    //   9370: ldc_w 'Theta '
    //   9373: invokevirtual getBytes : ()[B
    //   9376: iconst_0
    //   9377: invokespecial <init> : ([BI)V
    //   9380: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9385: aload #8
    //   9387: bipush #101
    //   9389: bipush #81
    //   9391: invokeinterface setAlignedInt : (II)V
    //   9396: aload #8
    //   9398: bipush #102
    //   9400: new org/renjin/gcc/runtime/BytePtr
    //   9403: dup
    //   9404: ldc_w 'Rho '
    //   9407: invokevirtual getBytes : ()[B
    //   9410: iconst_0
    //   9411: invokespecial <init> : ([BI)V
    //   9414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9419: aload #8
    //   9421: bipush #103
    //   9423: bipush #82
    //   9425: invokeinterface setAlignedInt : (II)V
    //   9430: aload #8
    //   9432: bipush #104
    //   9434: new org/renjin/gcc/runtime/BytePtr
    //   9437: dup
    //   9438: ldc_w 'Sigma '
    //   9441: invokevirtual getBytes : ()[B
    //   9444: iconst_0
    //   9445: invokespecial <init> : ([BI)V
    //   9448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9453: aload #8
    //   9455: bipush #105
    //   9457: bipush #83
    //   9459: invokeinterface setAlignedInt : (II)V
    //   9464: aload #8
    //   9466: bipush #106
    //   9468: new org/renjin/gcc/runtime/BytePtr
    //   9471: dup
    //   9472: ldc_w 'Tau '
    //   9475: invokevirtual getBytes : ()[B
    //   9478: iconst_0
    //   9479: invokespecial <init> : ([BI)V
    //   9482: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9487: aload #8
    //   9489: bipush #107
    //   9491: bipush #84
    //   9493: invokeinterface setAlignedInt : (II)V
    //   9498: aload #8
    //   9500: bipush #108
    //   9502: new org/renjin/gcc/runtime/BytePtr
    //   9505: dup
    //   9506: ldc_w 'Upsilon '
    //   9509: invokevirtual getBytes : ()[B
    //   9512: iconst_0
    //   9513: invokespecial <init> : ([BI)V
    //   9516: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9521: aload #8
    //   9523: bipush #109
    //   9525: bipush #85
    //   9527: invokeinterface setAlignedInt : (II)V
    //   9532: aload #8
    //   9534: bipush #110
    //   9536: new org/renjin/gcc/runtime/BytePtr
    //   9539: dup
    //   9540: ldc_w 'sigma1 '
    //   9543: invokevirtual getBytes : ()[B
    //   9546: iconst_0
    //   9547: invokespecial <init> : ([BI)V
    //   9550: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9555: aload #8
    //   9557: bipush #111
    //   9559: bipush #86
    //   9561: invokeinterface setAlignedInt : (II)V
    //   9566: aload #8
    //   9568: bipush #112
    //   9570: new org/renjin/gcc/runtime/BytePtr
    //   9573: dup
    //   9574: ldc_w 'varsigma '
    //   9577: invokevirtual getBytes : ()[B
    //   9580: iconst_0
    //   9581: invokespecial <init> : ([BI)V
    //   9584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9589: aload #8
    //   9591: bipush #113
    //   9593: bipush #86
    //   9595: invokeinterface setAlignedInt : (II)V
    //   9600: aload #8
    //   9602: bipush #114
    //   9604: new org/renjin/gcc/runtime/BytePtr
    //   9607: dup
    //   9608: ldc_w 'stigma '
    //   9611: invokevirtual getBytes : ()[B
    //   9614: iconst_0
    //   9615: invokespecial <init> : ([BI)V
    //   9618: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9623: aload #8
    //   9625: bipush #115
    //   9627: bipush #86
    //   9629: invokeinterface setAlignedInt : (II)V
    //   9634: aload #8
    //   9636: bipush #116
    //   9638: new org/renjin/gcc/runtime/BytePtr
    //   9641: dup
    //   9642: ldc_w 'Omega '
    //   9645: invokevirtual getBytes : ()[B
    //   9648: iconst_0
    //   9649: invokespecial <init> : ([BI)V
    //   9652: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9657: aload #8
    //   9659: bipush #117
    //   9661: bipush #87
    //   9663: invokeinterface setAlignedInt : (II)V
    //   9668: aload #8
    //   9670: bipush #118
    //   9672: new org/renjin/gcc/runtime/BytePtr
    //   9675: dup
    //   9676: ldc_w 'Xi '
    //   9679: invokevirtual getBytes : ()[B
    //   9682: iconst_0
    //   9683: invokespecial <init> : ([BI)V
    //   9686: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9691: aload #8
    //   9693: bipush #119
    //   9695: bipush #88
    //   9697: invokeinterface setAlignedInt : (II)V
    //   9702: aload #8
    //   9704: bipush #120
    //   9706: new org/renjin/gcc/runtime/BytePtr
    //   9709: dup
    //   9710: ldc_w 'Psi '
    //   9713: invokevirtual getBytes : ()[B
    //   9716: iconst_0
    //   9717: invokespecial <init> : ([BI)V
    //   9720: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9725: aload #8
    //   9727: bipush #121
    //   9729: bipush #89
    //   9731: invokeinterface setAlignedInt : (II)V
    //   9736: aload #8
    //   9738: bipush #122
    //   9740: new org/renjin/gcc/runtime/BytePtr
    //   9743: dup
    //   9744: ldc_w 'Zeta '
    //   9747: invokevirtual getBytes : ()[B
    //   9750: iconst_0
    //   9751: invokespecial <init> : ([BI)V
    //   9754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9759: aload #8
    //   9761: bipush #123
    //   9763: bipush #90
    //   9765: invokeinterface setAlignedInt : (II)V
    //   9770: aload #8
    //   9772: bipush #124
    //   9774: new org/renjin/gcc/runtime/BytePtr
    //   9777: dup
    //   9778: ldc_w 'bracketleft '
    //   9781: invokevirtual getBytes : ()[B
    //   9784: iconst_0
    //   9785: invokespecial <init> : ([BI)V
    //   9788: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9793: aload #8
    //   9795: bipush #125
    //   9797: bipush #91
    //   9799: invokeinterface setAlignedInt : (II)V
    //   9804: aload #8
    //   9806: bipush #126
    //   9808: new org/renjin/gcc/runtime/BytePtr
    //   9811: dup
    //   9812: ldc_w 'therefore '
    //   9815: invokevirtual getBytes : ()[B
    //   9818: iconst_0
    //   9819: invokespecial <init> : ([BI)V
    //   9822: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9827: aload #8
    //   9829: bipush #127
    //   9831: bipush #92
    //   9833: invokeinterface setAlignedInt : (II)V
    //   9838: aload #8
    //   9840: sipush #128
    //   9843: new org/renjin/gcc/runtime/BytePtr
    //   9846: dup
    //   9847: ldc_w 'bracketright '
    //   9850: invokevirtual getBytes : ()[B
    //   9853: iconst_0
    //   9854: invokespecial <init> : ([BI)V
    //   9857: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9862: aload #8
    //   9864: sipush #129
    //   9867: bipush #93
    //   9869: invokeinterface setAlignedInt : (II)V
    //   9874: aload #8
    //   9876: sipush #130
    //   9879: new org/renjin/gcc/runtime/BytePtr
    //   9882: dup
    //   9883: ldc_w 'perpendicular '
    //   9886: invokevirtual getBytes : ()[B
    //   9889: iconst_0
    //   9890: invokespecial <init> : ([BI)V
    //   9893: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9898: aload #8
    //   9900: sipush #131
    //   9903: bipush #94
    //   9905: invokeinterface setAlignedInt : (II)V
    //   9910: aload #8
    //   9912: sipush #132
    //   9915: new org/renjin/gcc/runtime/BytePtr
    //   9918: dup
    //   9919: ldc_w 'underscore '
    //   9922: invokevirtual getBytes : ()[B
    //   9925: iconst_0
    //   9926: invokespecial <init> : ([BI)V
    //   9929: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9934: aload #8
    //   9936: sipush #133
    //   9939: bipush #95
    //   9941: invokeinterface setAlignedInt : (II)V
    //   9946: aload #8
    //   9948: sipush #134
    //   9951: new org/renjin/gcc/runtime/BytePtr
    //   9954: dup
    //   9955: ldc_w 'radicalex '
    //   9958: invokevirtual getBytes : ()[B
    //   9961: iconst_0
    //   9962: invokespecial <init> : ([BI)V
    //   9965: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9970: aload #8
    //   9972: sipush #135
    //   9975: bipush #96
    //   9977: invokeinterface setAlignedInt : (II)V
    //   9982: aload #8
    //   9984: sipush #136
    //   9987: new org/renjin/gcc/runtime/BytePtr
    //   9990: dup
    //   9991: ldc_w 'alpha '
    //   9994: invokevirtual getBytes : ()[B
    //   9997: iconst_0
    //   9998: invokespecial <init> : ([BI)V
    //   10001: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10006: aload #8
    //   10008: sipush #137
    //   10011: bipush #97
    //   10013: invokeinterface setAlignedInt : (II)V
    //   10018: aload #8
    //   10020: sipush #138
    //   10023: new org/renjin/gcc/runtime/BytePtr
    //   10026: dup
    //   10027: ldc_w 'beta '
    //   10030: invokevirtual getBytes : ()[B
    //   10033: iconst_0
    //   10034: invokespecial <init> : ([BI)V
    //   10037: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10042: aload #8
    //   10044: sipush #139
    //   10047: bipush #98
    //   10049: invokeinterface setAlignedInt : (II)V
    //   10054: aload #8
    //   10056: sipush #140
    //   10059: new org/renjin/gcc/runtime/BytePtr
    //   10062: dup
    //   10063: ldc_w 'chi '
    //   10066: invokevirtual getBytes : ()[B
    //   10069: iconst_0
    //   10070: invokespecial <init> : ([BI)V
    //   10073: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10078: aload #8
    //   10080: sipush #141
    //   10083: bipush #99
    //   10085: invokeinterface setAlignedInt : (II)V
    //   10090: aload #8
    //   10092: sipush #142
    //   10095: new org/renjin/gcc/runtime/BytePtr
    //   10098: dup
    //   10099: ldc_w 'delta '
    //   10102: invokevirtual getBytes : ()[B
    //   10105: iconst_0
    //   10106: invokespecial <init> : ([BI)V
    //   10109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10114: aload #8
    //   10116: sipush #143
    //   10119: bipush #100
    //   10121: invokeinterface setAlignedInt : (II)V
    //   10126: aload #8
    //   10128: sipush #144
    //   10131: new org/renjin/gcc/runtime/BytePtr
    //   10134: dup
    //   10135: ldc_w 'epsilon '
    //   10138: invokevirtual getBytes : ()[B
    //   10141: iconst_0
    //   10142: invokespecial <init> : ([BI)V
    //   10145: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10150: aload #8
    //   10152: sipush #145
    //   10155: bipush #101
    //   10157: invokeinterface setAlignedInt : (II)V
    //   10162: aload #8
    //   10164: sipush #146
    //   10167: new org/renjin/gcc/runtime/BytePtr
    //   10170: dup
    //   10171: ldc_w 'phi '
    //   10174: invokevirtual getBytes : ()[B
    //   10177: iconst_0
    //   10178: invokespecial <init> : ([BI)V
    //   10181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10186: aload #8
    //   10188: sipush #147
    //   10191: bipush #102
    //   10193: invokeinterface setAlignedInt : (II)V
    //   10198: aload #8
    //   10200: sipush #148
    //   10203: new org/renjin/gcc/runtime/BytePtr
    //   10206: dup
    //   10207: ldc_w 'gamma '
    //   10210: invokevirtual getBytes : ()[B
    //   10213: iconst_0
    //   10214: invokespecial <init> : ([BI)V
    //   10217: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10222: aload #8
    //   10224: sipush #149
    //   10227: bipush #103
    //   10229: invokeinterface setAlignedInt : (II)V
    //   10234: aload #8
    //   10236: sipush #150
    //   10239: new org/renjin/gcc/runtime/BytePtr
    //   10242: dup
    //   10243: ldc_w 'eta '
    //   10246: invokevirtual getBytes : ()[B
    //   10249: iconst_0
    //   10250: invokespecial <init> : ([BI)V
    //   10253: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10258: aload #8
    //   10260: sipush #151
    //   10263: bipush #104
    //   10265: invokeinterface setAlignedInt : (II)V
    //   10270: aload #8
    //   10272: sipush #152
    //   10275: new org/renjin/gcc/runtime/BytePtr
    //   10278: dup
    //   10279: ldc_w 'iota '
    //   10282: invokevirtual getBytes : ()[B
    //   10285: iconst_0
    //   10286: invokespecial <init> : ([BI)V
    //   10289: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10294: aload #8
    //   10296: sipush #153
    //   10299: bipush #105
    //   10301: invokeinterface setAlignedInt : (II)V
    //   10306: aload #8
    //   10308: sipush #154
    //   10311: new org/renjin/gcc/runtime/BytePtr
    //   10314: dup
    //   10315: ldc_w 'phi1 '
    //   10318: invokevirtual getBytes : ()[B
    //   10321: iconst_0
    //   10322: invokespecial <init> : ([BI)V
    //   10325: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10330: aload #8
    //   10332: sipush #155
    //   10335: bipush #106
    //   10337: invokeinterface setAlignedInt : (II)V
    //   10342: aload #8
    //   10344: sipush #156
    //   10347: new org/renjin/gcc/runtime/BytePtr
    //   10350: dup
    //   10351: ldc_w 'varphi '
    //   10354: invokevirtual getBytes : ()[B
    //   10357: iconst_0
    //   10358: invokespecial <init> : ([BI)V
    //   10361: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10366: aload #8
    //   10368: sipush #157
    //   10371: bipush #106
    //   10373: invokeinterface setAlignedInt : (II)V
    //   10378: aload #8
    //   10380: sipush #158
    //   10383: new org/renjin/gcc/runtime/BytePtr
    //   10386: dup
    //   10387: ldc_w 'kappa '
    //   10390: invokevirtual getBytes : ()[B
    //   10393: iconst_0
    //   10394: invokespecial <init> : ([BI)V
    //   10397: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10402: aload #8
    //   10404: sipush #159
    //   10407: bipush #107
    //   10409: invokeinterface setAlignedInt : (II)V
    //   10414: aload #8
    //   10416: sipush #160
    //   10419: new org/renjin/gcc/runtime/BytePtr
    //   10422: dup
    //   10423: ldc_w 'lambda '
    //   10426: invokevirtual getBytes : ()[B
    //   10429: iconst_0
    //   10430: invokespecial <init> : ([BI)V
    //   10433: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10438: aload #8
    //   10440: sipush #161
    //   10443: bipush #108
    //   10445: invokeinterface setAlignedInt : (II)V
    //   10450: aload #8
    //   10452: sipush #162
    //   10455: new org/renjin/gcc/runtime/BytePtr
    //   10458: dup
    //   10459: ldc_w 'mu '
    //   10462: invokevirtual getBytes : ()[B
    //   10465: iconst_0
    //   10466: invokespecial <init> : ([BI)V
    //   10469: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10474: aload #8
    //   10476: sipush #163
    //   10479: bipush #109
    //   10481: invokeinterface setAlignedInt : (II)V
    //   10486: aload #8
    //   10488: sipush #164
    //   10491: new org/renjin/gcc/runtime/BytePtr
    //   10494: dup
    //   10495: ldc_w 'nu '
    //   10498: invokevirtual getBytes : ()[B
    //   10501: iconst_0
    //   10502: invokespecial <init> : ([BI)V
    //   10505: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10510: aload #8
    //   10512: sipush #165
    //   10515: bipush #110
    //   10517: invokeinterface setAlignedInt : (II)V
    //   10522: aload #8
    //   10524: sipush #166
    //   10527: new org/renjin/gcc/runtime/BytePtr
    //   10530: dup
    //   10531: ldc_w 'omicron '
    //   10534: invokevirtual getBytes : ()[B
    //   10537: iconst_0
    //   10538: invokespecial <init> : ([BI)V
    //   10541: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10546: aload #8
    //   10548: sipush #167
    //   10551: bipush #111
    //   10553: invokeinterface setAlignedInt : (II)V
    //   10558: aload #8
    //   10560: sipush #168
    //   10563: new org/renjin/gcc/runtime/BytePtr
    //   10566: dup
    //   10567: ldc_w 'pi '
    //   10570: invokevirtual getBytes : ()[B
    //   10573: iconst_0
    //   10574: invokespecial <init> : ([BI)V
    //   10577: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10582: aload #8
    //   10584: sipush #169
    //   10587: bipush #112
    //   10589: invokeinterface setAlignedInt : (II)V
    //   10594: aload #8
    //   10596: sipush #170
    //   10599: new org/renjin/gcc/runtime/BytePtr
    //   10602: dup
    //   10603: ldc_w 'theta '
    //   10606: invokevirtual getBytes : ()[B
    //   10609: iconst_0
    //   10610: invokespecial <init> : ([BI)V
    //   10613: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10618: aload #8
    //   10620: sipush #171
    //   10623: bipush #113
    //   10625: invokeinterface setAlignedInt : (II)V
    //   10630: aload #8
    //   10632: sipush #172
    //   10635: new org/renjin/gcc/runtime/BytePtr
    //   10638: dup
    //   10639: ldc_w 'rho '
    //   10642: invokevirtual getBytes : ()[B
    //   10645: iconst_0
    //   10646: invokespecial <init> : ([BI)V
    //   10649: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10654: aload #8
    //   10656: sipush #173
    //   10659: bipush #114
    //   10661: invokeinterface setAlignedInt : (II)V
    //   10666: aload #8
    //   10668: sipush #174
    //   10671: new org/renjin/gcc/runtime/BytePtr
    //   10674: dup
    //   10675: ldc_w 'sigma '
    //   10678: invokevirtual getBytes : ()[B
    //   10681: iconst_0
    //   10682: invokespecial <init> : ([BI)V
    //   10685: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10690: aload #8
    //   10692: sipush #175
    //   10695: bipush #115
    //   10697: invokeinterface setAlignedInt : (II)V
    //   10702: aload #8
    //   10704: sipush #176
    //   10707: new org/renjin/gcc/runtime/BytePtr
    //   10710: dup
    //   10711: ldc_w 'tau '
    //   10714: invokevirtual getBytes : ()[B
    //   10717: iconst_0
    //   10718: invokespecial <init> : ([BI)V
    //   10721: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10726: aload #8
    //   10728: sipush #177
    //   10731: bipush #116
    //   10733: invokeinterface setAlignedInt : (II)V
    //   10738: aload #8
    //   10740: sipush #178
    //   10743: new org/renjin/gcc/runtime/BytePtr
    //   10746: dup
    //   10747: ldc_w 'upsilon '
    //   10750: invokevirtual getBytes : ()[B
    //   10753: iconst_0
    //   10754: invokespecial <init> : ([BI)V
    //   10757: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10762: aload #8
    //   10764: sipush #179
    //   10767: bipush #117
    //   10769: invokeinterface setAlignedInt : (II)V
    //   10774: aload #8
    //   10776: sipush #180
    //   10779: new org/renjin/gcc/runtime/BytePtr
    //   10782: dup
    //   10783: ldc_w 'omega1 '
    //   10786: invokevirtual getBytes : ()[B
    //   10789: iconst_0
    //   10790: invokespecial <init> : ([BI)V
    //   10793: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10798: aload #8
    //   10800: sipush #181
    //   10803: bipush #118
    //   10805: invokeinterface setAlignedInt : (II)V
    //   10810: aload #8
    //   10812: sipush #182
    //   10815: new org/renjin/gcc/runtime/BytePtr
    //   10818: dup
    //   10819: ldc_w 'omega '
    //   10822: invokevirtual getBytes : ()[B
    //   10825: iconst_0
    //   10826: invokespecial <init> : ([BI)V
    //   10829: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10834: aload #8
    //   10836: sipush #183
    //   10839: bipush #119
    //   10841: invokeinterface setAlignedInt : (II)V
    //   10846: aload #8
    //   10848: sipush #184
    //   10851: new org/renjin/gcc/runtime/BytePtr
    //   10854: dup
    //   10855: ldc_w 'xi '
    //   10858: invokevirtual getBytes : ()[B
    //   10861: iconst_0
    //   10862: invokespecial <init> : ([BI)V
    //   10865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10870: aload #8
    //   10872: sipush #185
    //   10875: bipush #120
    //   10877: invokeinterface setAlignedInt : (II)V
    //   10882: aload #8
    //   10884: sipush #186
    //   10887: new org/renjin/gcc/runtime/BytePtr
    //   10890: dup
    //   10891: ldc_w 'psi '
    //   10894: invokevirtual getBytes : ()[B
    //   10897: iconst_0
    //   10898: invokespecial <init> : ([BI)V
    //   10901: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10906: aload #8
    //   10908: sipush #187
    //   10911: bipush #121
    //   10913: invokeinterface setAlignedInt : (II)V
    //   10918: aload #8
    //   10920: sipush #188
    //   10923: new org/renjin/gcc/runtime/BytePtr
    //   10926: dup
    //   10927: ldc_w 'zeta '
    //   10930: invokevirtual getBytes : ()[B
    //   10933: iconst_0
    //   10934: invokespecial <init> : ([BI)V
    //   10937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10942: aload #8
    //   10944: sipush #189
    //   10947: bipush #122
    //   10949: invokeinterface setAlignedInt : (II)V
    //   10954: aload #8
    //   10956: sipush #190
    //   10959: new org/renjin/gcc/runtime/BytePtr
    //   10962: dup
    //   10963: ldc_w 'braceleft '
    //   10966: invokevirtual getBytes : ()[B
    //   10969: iconst_0
    //   10970: invokespecial <init> : ([BI)V
    //   10973: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10978: aload #8
    //   10980: sipush #191
    //   10983: bipush #123
    //   10985: invokeinterface setAlignedInt : (II)V
    //   10990: aload #8
    //   10992: sipush #192
    //   10995: new org/renjin/gcc/runtime/BytePtr
    //   10998: dup
    //   10999: ldc_w 'bar '
    //   11002: invokevirtual getBytes : ()[B
    //   11005: iconst_0
    //   11006: invokespecial <init> : ([BI)V
    //   11009: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11014: aload #8
    //   11016: sipush #193
    //   11019: bipush #124
    //   11021: invokeinterface setAlignedInt : (II)V
    //   11026: aload #8
    //   11028: sipush #194
    //   11031: new org/renjin/gcc/runtime/BytePtr
    //   11034: dup
    //   11035: ldc_w 'braceright '
    //   11038: invokevirtual getBytes : ()[B
    //   11041: iconst_0
    //   11042: invokespecial <init> : ([BI)V
    //   11045: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11050: aload #8
    //   11052: sipush #195
    //   11055: bipush #125
    //   11057: invokeinterface setAlignedInt : (II)V
    //   11062: aload #8
    //   11064: sipush #196
    //   11067: new org/renjin/gcc/runtime/BytePtr
    //   11070: dup
    //   11071: ldc_w 'similar '
    //   11074: invokevirtual getBytes : ()[B
    //   11077: iconst_0
    //   11078: invokespecial <init> : ([BI)V
    //   11081: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11086: aload #8
    //   11088: sipush #197
    //   11091: bipush #126
    //   11093: invokeinterface setAlignedInt : (II)V
    //   11098: aload #8
    //   11100: sipush #198
    //   11103: new org/renjin/gcc/runtime/BytePtr
    //   11106: dup
    //   11107: ldc_w 'Upsilon1 '
    //   11110: invokevirtual getBytes : ()[B
    //   11113: iconst_0
    //   11114: invokespecial <init> : ([BI)V
    //   11117: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11122: aload #8
    //   11124: sipush #199
    //   11127: sipush #161
    //   11130: invokeinterface setAlignedInt : (II)V
    //   11135: aload #8
    //   11137: sipush #200
    //   11140: new org/renjin/gcc/runtime/BytePtr
    //   11143: dup
    //   11144: ldc_w 'minute '
    //   11147: invokevirtual getBytes : ()[B
    //   11150: iconst_0
    //   11151: invokespecial <init> : ([BI)V
    //   11154: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11159: aload #8
    //   11161: sipush #201
    //   11164: sipush #162
    //   11167: invokeinterface setAlignedInt : (II)V
    //   11172: aload #8
    //   11174: sipush #202
    //   11177: new org/renjin/gcc/runtime/BytePtr
    //   11180: dup
    //   11181: ldc_w 'lessequal '
    //   11184: invokevirtual getBytes : ()[B
    //   11187: iconst_0
    //   11188: invokespecial <init> : ([BI)V
    //   11191: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11196: aload #8
    //   11198: sipush #203
    //   11201: sipush #163
    //   11204: invokeinterface setAlignedInt : (II)V
    //   11209: aload #8
    //   11211: sipush #204
    //   11214: new org/renjin/gcc/runtime/BytePtr
    //   11217: dup
    //   11218: ldc_w 'fraction '
    //   11221: invokevirtual getBytes : ()[B
    //   11224: iconst_0
    //   11225: invokespecial <init> : ([BI)V
    //   11228: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11233: aload #8
    //   11235: sipush #205
    //   11238: sipush #164
    //   11241: invokeinterface setAlignedInt : (II)V
    //   11246: aload #8
    //   11248: sipush #206
    //   11251: new org/renjin/gcc/runtime/BytePtr
    //   11254: dup
    //   11255: ldc_w 'infinity '
    //   11258: invokevirtual getBytes : ()[B
    //   11261: iconst_0
    //   11262: invokespecial <init> : ([BI)V
    //   11265: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11270: aload #8
    //   11272: sipush #207
    //   11275: sipush #165
    //   11278: invokeinterface setAlignedInt : (II)V
    //   11283: aload #8
    //   11285: sipush #208
    //   11288: new org/renjin/gcc/runtime/BytePtr
    //   11291: dup
    //   11292: ldc_w 'florin '
    //   11295: invokevirtual getBytes : ()[B
    //   11298: iconst_0
    //   11299: invokespecial <init> : ([BI)V
    //   11302: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11307: aload #8
    //   11309: sipush #209
    //   11312: sipush #166
    //   11315: invokeinterface setAlignedInt : (II)V
    //   11320: aload #8
    //   11322: sipush #210
    //   11325: new org/renjin/gcc/runtime/BytePtr
    //   11328: dup
    //   11329: ldc_w 'club '
    //   11332: invokevirtual getBytes : ()[B
    //   11335: iconst_0
    //   11336: invokespecial <init> : ([BI)V
    //   11339: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11344: aload #8
    //   11346: sipush #211
    //   11349: sipush #167
    //   11352: invokeinterface setAlignedInt : (II)V
    //   11357: aload #8
    //   11359: sipush #212
    //   11362: new org/renjin/gcc/runtime/BytePtr
    //   11365: dup
    //   11366: ldc_w 'diamond '
    //   11369: invokevirtual getBytes : ()[B
    //   11372: iconst_0
    //   11373: invokespecial <init> : ([BI)V
    //   11376: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11381: aload #8
    //   11383: sipush #213
    //   11386: sipush #168
    //   11389: invokeinterface setAlignedInt : (II)V
    //   11394: aload #8
    //   11396: sipush #214
    //   11399: new org/renjin/gcc/runtime/BytePtr
    //   11402: dup
    //   11403: ldc_w 'heart '
    //   11406: invokevirtual getBytes : ()[B
    //   11409: iconst_0
    //   11410: invokespecial <init> : ([BI)V
    //   11413: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11418: aload #8
    //   11420: sipush #215
    //   11423: sipush #169
    //   11426: invokeinterface setAlignedInt : (II)V
    //   11431: aload #8
    //   11433: sipush #216
    //   11436: new org/renjin/gcc/runtime/BytePtr
    //   11439: dup
    //   11440: ldc_w 'spade '
    //   11443: invokevirtual getBytes : ()[B
    //   11446: iconst_0
    //   11447: invokespecial <init> : ([BI)V
    //   11450: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11455: aload #8
    //   11457: sipush #217
    //   11460: sipush #170
    //   11463: invokeinterface setAlignedInt : (II)V
    //   11468: aload #8
    //   11470: sipush #218
    //   11473: new org/renjin/gcc/runtime/BytePtr
    //   11476: dup
    //   11477: ldc_w 'arrowboth '
    //   11480: invokevirtual getBytes : ()[B
    //   11483: iconst_0
    //   11484: invokespecial <init> : ([BI)V
    //   11487: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11492: aload #8
    //   11494: sipush #219
    //   11497: sipush #171
    //   11500: invokeinterface setAlignedInt : (II)V
    //   11505: aload #8
    //   11507: sipush #220
    //   11510: new org/renjin/gcc/runtime/BytePtr
    //   11513: dup
    //   11514: ldc_w 'arrowleft '
    //   11517: invokevirtual getBytes : ()[B
    //   11520: iconst_0
    //   11521: invokespecial <init> : ([BI)V
    //   11524: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11529: aload #8
    //   11531: sipush #221
    //   11534: sipush #172
    //   11537: invokeinterface setAlignedInt : (II)V
    //   11542: aload #8
    //   11544: sipush #222
    //   11547: new org/renjin/gcc/runtime/BytePtr
    //   11550: dup
    //   11551: ldc_w 'arrowup '
    //   11554: invokevirtual getBytes : ()[B
    //   11557: iconst_0
    //   11558: invokespecial <init> : ([BI)V
    //   11561: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11566: aload #8
    //   11568: sipush #223
    //   11571: sipush #173
    //   11574: invokeinterface setAlignedInt : (II)V
    //   11579: aload #8
    //   11581: sipush #224
    //   11584: new org/renjin/gcc/runtime/BytePtr
    //   11587: dup
    //   11588: ldc_w 'arrowright '
    //   11591: invokevirtual getBytes : ()[B
    //   11594: iconst_0
    //   11595: invokespecial <init> : ([BI)V
    //   11598: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11603: aload #8
    //   11605: sipush #225
    //   11608: sipush #174
    //   11611: invokeinterface setAlignedInt : (II)V
    //   11616: aload #8
    //   11618: sipush #226
    //   11621: new org/renjin/gcc/runtime/BytePtr
    //   11624: dup
    //   11625: ldc_w 'arrowdown '
    //   11628: invokevirtual getBytes : ()[B
    //   11631: iconst_0
    //   11632: invokespecial <init> : ([BI)V
    //   11635: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11640: aload #8
    //   11642: sipush #227
    //   11645: sipush #175
    //   11648: invokeinterface setAlignedInt : (II)V
    //   11653: aload #8
    //   11655: sipush #228
    //   11658: new org/renjin/gcc/runtime/BytePtr
    //   11661: dup
    //   11662: ldc_w 'degree '
    //   11665: invokevirtual getBytes : ()[B
    //   11668: iconst_0
    //   11669: invokespecial <init> : ([BI)V
    //   11672: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11677: aload #8
    //   11679: sipush #229
    //   11682: sipush #176
    //   11685: invokeinterface setAlignedInt : (II)V
    //   11690: aload #8
    //   11692: sipush #230
    //   11695: new org/renjin/gcc/runtime/BytePtr
    //   11698: dup
    //   11699: ldc_w 'plusminus '
    //   11702: invokevirtual getBytes : ()[B
    //   11705: iconst_0
    //   11706: invokespecial <init> : ([BI)V
    //   11709: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11714: aload #8
    //   11716: sipush #231
    //   11719: sipush #177
    //   11722: invokeinterface setAlignedInt : (II)V
    //   11727: aload #8
    //   11729: sipush #232
    //   11732: new org/renjin/gcc/runtime/BytePtr
    //   11735: dup
    //   11736: ldc_w 'second '
    //   11739: invokevirtual getBytes : ()[B
    //   11742: iconst_0
    //   11743: invokespecial <init> : ([BI)V
    //   11746: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11751: aload #8
    //   11753: sipush #233
    //   11756: sipush #178
    //   11759: invokeinterface setAlignedInt : (II)V
    //   11764: aload #8
    //   11766: sipush #234
    //   11769: new org/renjin/gcc/runtime/BytePtr
    //   11772: dup
    //   11773: ldc_w 'greaterequal '
    //   11776: invokevirtual getBytes : ()[B
    //   11779: iconst_0
    //   11780: invokespecial <init> : ([BI)V
    //   11783: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11788: aload #8
    //   11790: sipush #235
    //   11793: sipush #179
    //   11796: invokeinterface setAlignedInt : (II)V
    //   11801: aload #8
    //   11803: sipush #236
    //   11806: new org/renjin/gcc/runtime/BytePtr
    //   11809: dup
    //   11810: ldc_w 'multiply '
    //   11813: invokevirtual getBytes : ()[B
    //   11816: iconst_0
    //   11817: invokespecial <init> : ([BI)V
    //   11820: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11825: aload #8
    //   11827: sipush #237
    //   11830: sipush #180
    //   11833: invokeinterface setAlignedInt : (II)V
    //   11838: aload #8
    //   11840: sipush #238
    //   11843: new org/renjin/gcc/runtime/BytePtr
    //   11846: dup
    //   11847: ldc_w 'proportional '
    //   11850: invokevirtual getBytes : ()[B
    //   11853: iconst_0
    //   11854: invokespecial <init> : ([BI)V
    //   11857: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11862: aload #8
    //   11864: sipush #239
    //   11867: sipush #181
    //   11870: invokeinterface setAlignedInt : (II)V
    //   11875: aload #8
    //   11877: sipush #240
    //   11880: new org/renjin/gcc/runtime/BytePtr
    //   11883: dup
    //   11884: ldc_w 'partialdiff '
    //   11887: invokevirtual getBytes : ()[B
    //   11890: iconst_0
    //   11891: invokespecial <init> : ([BI)V
    //   11894: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11899: aload #8
    //   11901: sipush #241
    //   11904: sipush #182
    //   11907: invokeinterface setAlignedInt : (II)V
    //   11912: aload #8
    //   11914: sipush #242
    //   11917: new org/renjin/gcc/runtime/BytePtr
    //   11920: dup
    //   11921: ldc_w 'bullet '
    //   11924: invokevirtual getBytes : ()[B
    //   11927: iconst_0
    //   11928: invokespecial <init> : ([BI)V
    //   11931: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11936: aload #8
    //   11938: sipush #243
    //   11941: sipush #183
    //   11944: invokeinterface setAlignedInt : (II)V
    //   11949: aload #8
    //   11951: sipush #244
    //   11954: new org/renjin/gcc/runtime/BytePtr
    //   11957: dup
    //   11958: ldc_w 'divide '
    //   11961: invokevirtual getBytes : ()[B
    //   11964: iconst_0
    //   11965: invokespecial <init> : ([BI)V
    //   11968: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11973: aload #8
    //   11975: sipush #245
    //   11978: sipush #184
    //   11981: invokeinterface setAlignedInt : (II)V
    //   11986: aload #8
    //   11988: sipush #246
    //   11991: new org/renjin/gcc/runtime/BytePtr
    //   11994: dup
    //   11995: ldc_w 'notequal '
    //   11998: invokevirtual getBytes : ()[B
    //   12001: iconst_0
    //   12002: invokespecial <init> : ([BI)V
    //   12005: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12010: aload #8
    //   12012: sipush #247
    //   12015: sipush #185
    //   12018: invokeinterface setAlignedInt : (II)V
    //   12023: aload #8
    //   12025: sipush #248
    //   12028: new org/renjin/gcc/runtime/BytePtr
    //   12031: dup
    //   12032: ldc_w 'equivalence '
    //   12035: invokevirtual getBytes : ()[B
    //   12038: iconst_0
    //   12039: invokespecial <init> : ([BI)V
    //   12042: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12047: aload #8
    //   12049: sipush #249
    //   12052: sipush #186
    //   12055: invokeinterface setAlignedInt : (II)V
    //   12060: aload #8
    //   12062: sipush #250
    //   12065: new org/renjin/gcc/runtime/BytePtr
    //   12068: dup
    //   12069: ldc_w 'approxequal '
    //   12072: invokevirtual getBytes : ()[B
    //   12075: iconst_0
    //   12076: invokespecial <init> : ([BI)V
    //   12079: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12084: aload #8
    //   12086: sipush #251
    //   12089: sipush #187
    //   12092: invokeinterface setAlignedInt : (II)V
    //   12097: aload #8
    //   12099: sipush #252
    //   12102: new org/renjin/gcc/runtime/BytePtr
    //   12105: dup
    //   12106: ldc_w 'ellipsis '
    //   12109: invokevirtual getBytes : ()[B
    //   12112: iconst_0
    //   12113: invokespecial <init> : ([BI)V
    //   12116: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12121: aload #8
    //   12123: sipush #253
    //   12126: sipush #188
    //   12129: invokeinterface setAlignedInt : (II)V
    //   12134: aload #8
    //   12136: sipush #254
    //   12139: new org/renjin/gcc/runtime/BytePtr
    //   12142: dup
    //   12143: ldc_w 'arrowvertex '
    //   12146: invokevirtual getBytes : ()[B
    //   12149: iconst_0
    //   12150: invokespecial <init> : ([BI)V
    //   12153: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12158: aload #8
    //   12160: sipush #255
    //   12163: sipush #189
    //   12166: invokeinterface setAlignedInt : (II)V
    //   12171: aload #8
    //   12173: sipush #256
    //   12176: new org/renjin/gcc/runtime/BytePtr
    //   12179: dup
    //   12180: ldc_w 'arrowhorizex '
    //   12183: invokevirtual getBytes : ()[B
    //   12186: iconst_0
    //   12187: invokespecial <init> : ([BI)V
    //   12190: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12195: aload #8
    //   12197: sipush #257
    //   12200: sipush #190
    //   12203: invokeinterface setAlignedInt : (II)V
    //   12208: aload #8
    //   12210: sipush #258
    //   12213: new org/renjin/gcc/runtime/BytePtr
    //   12216: dup
    //   12217: ldc_w 'carriagereturn '
    //   12220: invokevirtual getBytes : ()[B
    //   12223: iconst_0
    //   12224: invokespecial <init> : ([BI)V
    //   12227: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12232: aload #8
    //   12234: sipush #259
    //   12237: sipush #191
    //   12240: invokeinterface setAlignedInt : (II)V
    //   12245: aload #8
    //   12247: sipush #260
    //   12250: new org/renjin/gcc/runtime/BytePtr
    //   12253: dup
    //   12254: ldc_w 'aleph '
    //   12257: invokevirtual getBytes : ()[B
    //   12260: iconst_0
    //   12261: invokespecial <init> : ([BI)V
    //   12264: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12269: aload #8
    //   12271: sipush #261
    //   12274: sipush #192
    //   12277: invokeinterface setAlignedInt : (II)V
    //   12282: aload #8
    //   12284: sipush #262
    //   12287: new org/renjin/gcc/runtime/BytePtr
    //   12290: dup
    //   12291: ldc_w 'Ifraktur '
    //   12294: invokevirtual getBytes : ()[B
    //   12297: iconst_0
    //   12298: invokespecial <init> : ([BI)V
    //   12301: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12306: aload #8
    //   12308: sipush #263
    //   12311: sipush #193
    //   12314: invokeinterface setAlignedInt : (II)V
    //   12319: aload #8
    //   12321: sipush #264
    //   12324: new org/renjin/gcc/runtime/BytePtr
    //   12327: dup
    //   12328: ldc_w 'Rfraktur '
    //   12331: invokevirtual getBytes : ()[B
    //   12334: iconst_0
    //   12335: invokespecial <init> : ([BI)V
    //   12338: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12343: aload #8
    //   12345: sipush #265
    //   12348: sipush #194
    //   12351: invokeinterface setAlignedInt : (II)V
    //   12356: aload #8
    //   12358: sipush #266
    //   12361: new org/renjin/gcc/runtime/BytePtr
    //   12364: dup
    //   12365: ldc_w 'weierstrass '
    //   12368: invokevirtual getBytes : ()[B
    //   12371: iconst_0
    //   12372: invokespecial <init> : ([BI)V
    //   12375: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12380: aload #8
    //   12382: sipush #267
    //   12385: sipush #195
    //   12388: invokeinterface setAlignedInt : (II)V
    //   12393: aload #8
    //   12395: sipush #268
    //   12398: new org/renjin/gcc/runtime/BytePtr
    //   12401: dup
    //   12402: ldc_w 'circlemultiply '
    //   12405: invokevirtual getBytes : ()[B
    //   12408: iconst_0
    //   12409: invokespecial <init> : ([BI)V
    //   12412: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12417: aload #8
    //   12419: sipush #269
    //   12422: sipush #196
    //   12425: invokeinterface setAlignedInt : (II)V
    //   12430: aload #8
    //   12432: sipush #270
    //   12435: new org/renjin/gcc/runtime/BytePtr
    //   12438: dup
    //   12439: ldc_w 'circleplus '
    //   12442: invokevirtual getBytes : ()[B
    //   12445: iconst_0
    //   12446: invokespecial <init> : ([BI)V
    //   12449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12454: aload #8
    //   12456: sipush #271
    //   12459: sipush #197
    //   12462: invokeinterface setAlignedInt : (II)V
    //   12467: aload #8
    //   12469: sipush #272
    //   12472: new org/renjin/gcc/runtime/BytePtr
    //   12475: dup
    //   12476: ldc_w 'emptyset '
    //   12479: invokevirtual getBytes : ()[B
    //   12482: iconst_0
    //   12483: invokespecial <init> : ([BI)V
    //   12486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12491: aload #8
    //   12493: sipush #273
    //   12496: sipush #198
    //   12499: invokeinterface setAlignedInt : (II)V
    //   12504: aload #8
    //   12506: sipush #274
    //   12509: new org/renjin/gcc/runtime/BytePtr
    //   12512: dup
    //   12513: ldc_w 'intersection '
    //   12516: invokevirtual getBytes : ()[B
    //   12519: iconst_0
    //   12520: invokespecial <init> : ([BI)V
    //   12523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12528: aload #8
    //   12530: sipush #275
    //   12533: sipush #199
    //   12536: invokeinterface setAlignedInt : (II)V
    //   12541: aload #8
    //   12543: sipush #276
    //   12546: new org/renjin/gcc/runtime/BytePtr
    //   12549: dup
    //   12550: ldc_w 'union '
    //   12553: invokevirtual getBytes : ()[B
    //   12556: iconst_0
    //   12557: invokespecial <init> : ([BI)V
    //   12560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12565: aload #8
    //   12567: sipush #277
    //   12570: sipush #200
    //   12573: invokeinterface setAlignedInt : (II)V
    //   12578: aload #8
    //   12580: sipush #278
    //   12583: new org/renjin/gcc/runtime/BytePtr
    //   12586: dup
    //   12587: ldc_w 'propersuperset '
    //   12590: invokevirtual getBytes : ()[B
    //   12593: iconst_0
    //   12594: invokespecial <init> : ([BI)V
    //   12597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12602: aload #8
    //   12604: sipush #279
    //   12607: sipush #201
    //   12610: invokeinterface setAlignedInt : (II)V
    //   12615: aload #8
    //   12617: sipush #280
    //   12620: new org/renjin/gcc/runtime/BytePtr
    //   12623: dup
    //   12624: ldc_w 'reflexsuperset '
    //   12627: invokevirtual getBytes : ()[B
    //   12630: iconst_0
    //   12631: invokespecial <init> : ([BI)V
    //   12634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12639: aload #8
    //   12641: sipush #281
    //   12644: sipush #202
    //   12647: invokeinterface setAlignedInt : (II)V
    //   12652: aload #8
    //   12654: sipush #282
    //   12657: new org/renjin/gcc/runtime/BytePtr
    //   12660: dup
    //   12661: ldc_w 'notsubset '
    //   12664: invokevirtual getBytes : ()[B
    //   12667: iconst_0
    //   12668: invokespecial <init> : ([BI)V
    //   12671: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12676: aload #8
    //   12678: sipush #283
    //   12681: sipush #203
    //   12684: invokeinterface setAlignedInt : (II)V
    //   12689: aload #8
    //   12691: sipush #284
    //   12694: new org/renjin/gcc/runtime/BytePtr
    //   12697: dup
    //   12698: ldc_w 'propersubset '
    //   12701: invokevirtual getBytes : ()[B
    //   12704: iconst_0
    //   12705: invokespecial <init> : ([BI)V
    //   12708: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12713: aload #8
    //   12715: sipush #285
    //   12718: sipush #204
    //   12721: invokeinterface setAlignedInt : (II)V
    //   12726: aload #8
    //   12728: sipush #286
    //   12731: new org/renjin/gcc/runtime/BytePtr
    //   12734: dup
    //   12735: ldc_w 'reflexsubset '
    //   12738: invokevirtual getBytes : ()[B
    //   12741: iconst_0
    //   12742: invokespecial <init> : ([BI)V
    //   12745: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12750: aload #8
    //   12752: sipush #287
    //   12755: sipush #205
    //   12758: invokeinterface setAlignedInt : (II)V
    //   12763: aload #8
    //   12765: sipush #288
    //   12768: new org/renjin/gcc/runtime/BytePtr
    //   12771: dup
    //   12772: ldc_w 'element '
    //   12775: invokevirtual getBytes : ()[B
    //   12778: iconst_0
    //   12779: invokespecial <init> : ([BI)V
    //   12782: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12787: aload #8
    //   12789: sipush #289
    //   12792: sipush #206
    //   12795: invokeinterface setAlignedInt : (II)V
    //   12800: aload #8
    //   12802: sipush #290
    //   12805: new org/renjin/gcc/runtime/BytePtr
    //   12808: dup
    //   12809: ldc_w 'notelement '
    //   12812: invokevirtual getBytes : ()[B
    //   12815: iconst_0
    //   12816: invokespecial <init> : ([BI)V
    //   12819: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12824: aload #8
    //   12826: sipush #291
    //   12829: sipush #207
    //   12832: invokeinterface setAlignedInt : (II)V
    //   12837: aload #8
    //   12839: sipush #292
    //   12842: new org/renjin/gcc/runtime/BytePtr
    //   12845: dup
    //   12846: ldc_w 'angle '
    //   12849: invokevirtual getBytes : ()[B
    //   12852: iconst_0
    //   12853: invokespecial <init> : ([BI)V
    //   12856: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12861: aload #8
    //   12863: sipush #293
    //   12866: sipush #208
    //   12869: invokeinterface setAlignedInt : (II)V
    //   12874: aload #8
    //   12876: sipush #294
    //   12879: new org/renjin/gcc/runtime/BytePtr
    //   12882: dup
    //   12883: ldc_w 'nabla '
    //   12886: invokevirtual getBytes : ()[B
    //   12889: iconst_0
    //   12890: invokespecial <init> : ([BI)V
    //   12893: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12898: aload #8
    //   12900: sipush #295
    //   12903: sipush #209
    //   12906: invokeinterface setAlignedInt : (II)V
    //   12911: aload #8
    //   12913: sipush #296
    //   12916: new org/renjin/gcc/runtime/BytePtr
    //   12919: dup
    //   12920: ldc_w 'registerserif '
    //   12923: invokevirtual getBytes : ()[B
    //   12926: iconst_0
    //   12927: invokespecial <init> : ([BI)V
    //   12930: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12935: aload #8
    //   12937: sipush #297
    //   12940: sipush #210
    //   12943: invokeinterface setAlignedInt : (II)V
    //   12948: aload #8
    //   12950: sipush #298
    //   12953: new org/renjin/gcc/runtime/BytePtr
    //   12956: dup
    //   12957: ldc_w 'copyrightserif '
    //   12960: invokevirtual getBytes : ()[B
    //   12963: iconst_0
    //   12964: invokespecial <init> : ([BI)V
    //   12967: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12972: aload #8
    //   12974: sipush #299
    //   12977: sipush #211
    //   12980: invokeinterface setAlignedInt : (II)V
    //   12985: aload #8
    //   12987: sipush #300
    //   12990: new org/renjin/gcc/runtime/BytePtr
    //   12993: dup
    //   12994: ldc_w 'trademarkserif '
    //   12997: invokevirtual getBytes : ()[B
    //   13000: iconst_0
    //   13001: invokespecial <init> : ([BI)V
    //   13004: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13009: aload #8
    //   13011: sipush #301
    //   13014: sipush #212
    //   13017: invokeinterface setAlignedInt : (II)V
    //   13022: aload #8
    //   13024: sipush #302
    //   13027: new org/renjin/gcc/runtime/BytePtr
    //   13030: dup
    //   13031: ldc_w 'product '
    //   13034: invokevirtual getBytes : ()[B
    //   13037: iconst_0
    //   13038: invokespecial <init> : ([BI)V
    //   13041: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13046: aload #8
    //   13048: sipush #303
    //   13051: sipush #213
    //   13054: invokeinterface setAlignedInt : (II)V
    //   13059: aload #8
    //   13061: sipush #304
    //   13064: new org/renjin/gcc/runtime/BytePtr
    //   13067: dup
    //   13068: ldc_w 'radical '
    //   13071: invokevirtual getBytes : ()[B
    //   13074: iconst_0
    //   13075: invokespecial <init> : ([BI)V
    //   13078: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13083: aload #8
    //   13085: sipush #305
    //   13088: sipush #214
    //   13091: invokeinterface setAlignedInt : (II)V
    //   13096: aload #8
    //   13098: sipush #306
    //   13101: new org/renjin/gcc/runtime/BytePtr
    //   13104: dup
    //   13105: ldc_w 'dotmath '
    //   13108: invokevirtual getBytes : ()[B
    //   13111: iconst_0
    //   13112: invokespecial <init> : ([BI)V
    //   13115: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13120: aload #8
    //   13122: sipush #307
    //   13125: sipush #215
    //   13128: invokeinterface setAlignedInt : (II)V
    //   13133: aload #8
    //   13135: sipush #308
    //   13138: new org/renjin/gcc/runtime/BytePtr
    //   13141: dup
    //   13142: ldc_w 'logicaland '
    //   13145: invokevirtual getBytes : ()[B
    //   13148: iconst_0
    //   13149: invokespecial <init> : ([BI)V
    //   13152: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13157: aload #8
    //   13159: sipush #309
    //   13162: sipush #217
    //   13165: invokeinterface setAlignedInt : (II)V
    //   13170: aload #8
    //   13172: sipush #310
    //   13175: new org/renjin/gcc/runtime/BytePtr
    //   13178: dup
    //   13179: ldc_w 'logicalor '
    //   13182: invokevirtual getBytes : ()[B
    //   13185: iconst_0
    //   13186: invokespecial <init> : ([BI)V
    //   13189: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13194: aload #8
    //   13196: sipush #311
    //   13199: sipush #218
    //   13202: invokeinterface setAlignedInt : (II)V
    //   13207: aload #8
    //   13209: sipush #312
    //   13212: new org/renjin/gcc/runtime/BytePtr
    //   13215: dup
    //   13216: ldc_w 'arrowdblboth '
    //   13219: invokevirtual getBytes : ()[B
    //   13222: iconst_0
    //   13223: invokespecial <init> : ([BI)V
    //   13226: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13231: aload #8
    //   13233: sipush #313
    //   13236: sipush #219
    //   13239: invokeinterface setAlignedInt : (II)V
    //   13244: aload #8
    //   13246: sipush #314
    //   13249: new org/renjin/gcc/runtime/BytePtr
    //   13252: dup
    //   13253: ldc_w 'arrowdblleft '
    //   13256: invokevirtual getBytes : ()[B
    //   13259: iconst_0
    //   13260: invokespecial <init> : ([BI)V
    //   13263: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13268: aload #8
    //   13270: sipush #315
    //   13273: sipush #220
    //   13276: invokeinterface setAlignedInt : (II)V
    //   13281: aload #8
    //   13283: sipush #316
    //   13286: new org/renjin/gcc/runtime/BytePtr
    //   13289: dup
    //   13290: ldc_w 'arrowdblup '
    //   13293: invokevirtual getBytes : ()[B
    //   13296: iconst_0
    //   13297: invokespecial <init> : ([BI)V
    //   13300: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13305: aload #8
    //   13307: sipush #317
    //   13310: sipush #221
    //   13313: invokeinterface setAlignedInt : (II)V
    //   13318: aload #8
    //   13320: sipush #318
    //   13323: new org/renjin/gcc/runtime/BytePtr
    //   13326: dup
    //   13327: ldc_w 'arrowdblright '
    //   13330: invokevirtual getBytes : ()[B
    //   13333: iconst_0
    //   13334: invokespecial <init> : ([BI)V
    //   13337: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13342: aload #8
    //   13344: sipush #319
    //   13347: sipush #222
    //   13350: invokeinterface setAlignedInt : (II)V
    //   13355: aload #8
    //   13357: sipush #320
    //   13360: new org/renjin/gcc/runtime/BytePtr
    //   13363: dup
    //   13364: ldc_w 'arrowdbldown '
    //   13367: invokevirtual getBytes : ()[B
    //   13370: iconst_0
    //   13371: invokespecial <init> : ([BI)V
    //   13374: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13379: aload #8
    //   13381: sipush #321
    //   13384: sipush #223
    //   13387: invokeinterface setAlignedInt : (II)V
    //   13392: aload #8
    //   13394: sipush #322
    //   13397: new org/renjin/gcc/runtime/BytePtr
    //   13400: dup
    //   13401: ldc_w 'lozenge '
    //   13404: invokevirtual getBytes : ()[B
    //   13407: iconst_0
    //   13408: invokespecial <init> : ([BI)V
    //   13411: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13416: aload #8
    //   13418: sipush #323
    //   13421: sipush #224
    //   13424: invokeinterface setAlignedInt : (II)V
    //   13429: aload #8
    //   13431: sipush #324
    //   13434: new org/renjin/gcc/runtime/BytePtr
    //   13437: dup
    //   13438: ldc_w 'angleleft '
    //   13441: invokevirtual getBytes : ()[B
    //   13444: iconst_0
    //   13445: invokespecial <init> : ([BI)V
    //   13448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13453: aload #8
    //   13455: sipush #325
    //   13458: sipush #225
    //   13461: invokeinterface setAlignedInt : (II)V
    //   13466: aload #8
    //   13468: sipush #326
    //   13471: new org/renjin/gcc/runtime/BytePtr
    //   13474: dup
    //   13475: ldc_w 'registersans '
    //   13478: invokevirtual getBytes : ()[B
    //   13481: iconst_0
    //   13482: invokespecial <init> : ([BI)V
    //   13485: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13490: aload #8
    //   13492: sipush #327
    //   13495: sipush #226
    //   13498: invokeinterface setAlignedInt : (II)V
    //   13503: aload #8
    //   13505: sipush #328
    //   13508: new org/renjin/gcc/runtime/BytePtr
    //   13511: dup
    //   13512: ldc_w 'copyrightsans '
    //   13515: invokevirtual getBytes : ()[B
    //   13518: iconst_0
    //   13519: invokespecial <init> : ([BI)V
    //   13522: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13527: aload #8
    //   13529: sipush #329
    //   13532: sipush #227
    //   13535: invokeinterface setAlignedInt : (II)V
    //   13540: aload #8
    //   13542: sipush #330
    //   13545: new org/renjin/gcc/runtime/BytePtr
    //   13548: dup
    //   13549: ldc_w 'trademarksans '
    //   13552: invokevirtual getBytes : ()[B
    //   13555: iconst_0
    //   13556: invokespecial <init> : ([BI)V
    //   13559: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13564: aload #8
    //   13566: sipush #331
    //   13569: sipush #228
    //   13572: invokeinterface setAlignedInt : (II)V
    //   13577: aload #8
    //   13579: sipush #332
    //   13582: new org/renjin/gcc/runtime/BytePtr
    //   13585: dup
    //   13586: ldc_w 'summation '
    //   13589: invokevirtual getBytes : ()[B
    //   13592: iconst_0
    //   13593: invokespecial <init> : ([BI)V
    //   13596: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13601: aload #8
    //   13603: sipush #333
    //   13606: sipush #229
    //   13609: invokeinterface setAlignedInt : (II)V
    //   13614: aload #8
    //   13616: sipush #334
    //   13619: new org/renjin/gcc/runtime/BytePtr
    //   13622: dup
    //   13623: ldc_w 'parenlefttp '
    //   13626: invokevirtual getBytes : ()[B
    //   13629: iconst_0
    //   13630: invokespecial <init> : ([BI)V
    //   13633: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13638: aload #8
    //   13640: sipush #335
    //   13643: sipush #230
    //   13646: invokeinterface setAlignedInt : (II)V
    //   13651: aload #8
    //   13653: sipush #336
    //   13656: new org/renjin/gcc/runtime/BytePtr
    //   13659: dup
    //   13660: ldc_w 'parenleftex '
    //   13663: invokevirtual getBytes : ()[B
    //   13666: iconst_0
    //   13667: invokespecial <init> : ([BI)V
    //   13670: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13675: aload #8
    //   13677: sipush #337
    //   13680: sipush #231
    //   13683: invokeinterface setAlignedInt : (II)V
    //   13688: aload #8
    //   13690: sipush #338
    //   13693: new org/renjin/gcc/runtime/BytePtr
    //   13696: dup
    //   13697: ldc_w 'parenleftbt '
    //   13700: invokevirtual getBytes : ()[B
    //   13703: iconst_0
    //   13704: invokespecial <init> : ([BI)V
    //   13707: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13712: aload #8
    //   13714: sipush #339
    //   13717: sipush #232
    //   13720: invokeinterface setAlignedInt : (II)V
    //   13725: aload #8
    //   13727: sipush #340
    //   13730: new org/renjin/gcc/runtime/BytePtr
    //   13733: dup
    //   13734: ldc_w 'bracketlefttp '
    //   13737: invokevirtual getBytes : ()[B
    //   13740: iconst_0
    //   13741: invokespecial <init> : ([BI)V
    //   13744: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13749: aload #8
    //   13751: sipush #341
    //   13754: sipush #233
    //   13757: invokeinterface setAlignedInt : (II)V
    //   13762: aload #8
    //   13764: sipush #342
    //   13767: new org/renjin/gcc/runtime/BytePtr
    //   13770: dup
    //   13771: ldc_w 'bracketleftex '
    //   13774: invokevirtual getBytes : ()[B
    //   13777: iconst_0
    //   13778: invokespecial <init> : ([BI)V
    //   13781: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13786: aload #8
    //   13788: sipush #343
    //   13791: sipush #234
    //   13794: invokeinterface setAlignedInt : (II)V
    //   13799: aload #8
    //   13801: sipush #344
    //   13804: new org/renjin/gcc/runtime/BytePtr
    //   13807: dup
    //   13808: ldc_w 'bracketleftbt '
    //   13811: invokevirtual getBytes : ()[B
    //   13814: iconst_0
    //   13815: invokespecial <init> : ([BI)V
    //   13818: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13823: aload #8
    //   13825: sipush #345
    //   13828: sipush #235
    //   13831: invokeinterface setAlignedInt : (II)V
    //   13836: aload #8
    //   13838: sipush #346
    //   13841: new org/renjin/gcc/runtime/BytePtr
    //   13844: dup
    //   13845: ldc_w 'bracelefttp '
    //   13848: invokevirtual getBytes : ()[B
    //   13851: iconst_0
    //   13852: invokespecial <init> : ([BI)V
    //   13855: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13860: aload #8
    //   13862: sipush #347
    //   13865: sipush #236
    //   13868: invokeinterface setAlignedInt : (II)V
    //   13873: aload #8
    //   13875: sipush #348
    //   13878: new org/renjin/gcc/runtime/BytePtr
    //   13881: dup
    //   13882: ldc_w 'braceleftmid '
    //   13885: invokevirtual getBytes : ()[B
    //   13888: iconst_0
    //   13889: invokespecial <init> : ([BI)V
    //   13892: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13897: aload #8
    //   13899: sipush #349
    //   13902: sipush #237
    //   13905: invokeinterface setAlignedInt : (II)V
    //   13910: aload #8
    //   13912: sipush #350
    //   13915: new org/renjin/gcc/runtime/BytePtr
    //   13918: dup
    //   13919: ldc_w 'braceleftbt '
    //   13922: invokevirtual getBytes : ()[B
    //   13925: iconst_0
    //   13926: invokespecial <init> : ([BI)V
    //   13929: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13934: aload #8
    //   13936: sipush #351
    //   13939: sipush #238
    //   13942: invokeinterface setAlignedInt : (II)V
    //   13947: aload #8
    //   13949: sipush #352
    //   13952: new org/renjin/gcc/runtime/BytePtr
    //   13955: dup
    //   13956: ldc_w 'braceex '
    //   13959: invokevirtual getBytes : ()[B
    //   13962: iconst_0
    //   13963: invokespecial <init> : ([BI)V
    //   13966: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13971: aload #8
    //   13973: sipush #353
    //   13976: sipush #239
    //   13979: invokeinterface setAlignedInt : (II)V
    //   13984: aload #8
    //   13986: sipush #354
    //   13989: new org/renjin/gcc/runtime/BytePtr
    //   13992: dup
    //   13993: ldc_w 'angleright '
    //   13996: invokevirtual getBytes : ()[B
    //   13999: iconst_0
    //   14000: invokespecial <init> : ([BI)V
    //   14003: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14008: aload #8
    //   14010: sipush #355
    //   14013: sipush #241
    //   14016: invokeinterface setAlignedInt : (II)V
    //   14021: aload #8
    //   14023: sipush #356
    //   14026: new org/renjin/gcc/runtime/BytePtr
    //   14029: dup
    //   14030: ldc_w 'integral '
    //   14033: invokevirtual getBytes : ()[B
    //   14036: iconst_0
    //   14037: invokespecial <init> : ([BI)V
    //   14040: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14045: aload #8
    //   14047: sipush #357
    //   14050: sipush #242
    //   14053: invokeinterface setAlignedInt : (II)V
    //   14058: aload #8
    //   14060: sipush #358
    //   14063: new org/renjin/gcc/runtime/BytePtr
    //   14066: dup
    //   14067: ldc_w 'integraltp '
    //   14070: invokevirtual getBytes : ()[B
    //   14073: iconst_0
    //   14074: invokespecial <init> : ([BI)V
    //   14077: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14082: aload #8
    //   14084: sipush #359
    //   14087: sipush #243
    //   14090: invokeinterface setAlignedInt : (II)V
    //   14095: aload #8
    //   14097: sipush #360
    //   14100: new org/renjin/gcc/runtime/BytePtr
    //   14103: dup
    //   14104: ldc_w 'integralex '
    //   14107: invokevirtual getBytes : ()[B
    //   14110: iconst_0
    //   14111: invokespecial <init> : ([BI)V
    //   14114: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14119: aload #8
    //   14121: sipush #361
    //   14124: sipush #244
    //   14127: invokeinterface setAlignedInt : (II)V
    //   14132: aload #8
    //   14134: sipush #362
    //   14137: new org/renjin/gcc/runtime/BytePtr
    //   14140: dup
    //   14141: ldc_w 'integralbt '
    //   14144: invokevirtual getBytes : ()[B
    //   14147: iconst_0
    //   14148: invokespecial <init> : ([BI)V
    //   14151: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14156: aload #8
    //   14158: sipush #363
    //   14161: sipush #245
    //   14164: invokeinterface setAlignedInt : (II)V
    //   14169: aload #8
    //   14171: sipush #364
    //   14174: new org/renjin/gcc/runtime/BytePtr
    //   14177: dup
    //   14178: ldc_w 'parenrighttp '
    //   14181: invokevirtual getBytes : ()[B
    //   14184: iconst_0
    //   14185: invokespecial <init> : ([BI)V
    //   14188: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14193: aload #8
    //   14195: sipush #365
    //   14198: sipush #246
    //   14201: invokeinterface setAlignedInt : (II)V
    //   14206: aload #8
    //   14208: sipush #366
    //   14211: new org/renjin/gcc/runtime/BytePtr
    //   14214: dup
    //   14215: ldc_w 'parenrightex '
    //   14218: invokevirtual getBytes : ()[B
    //   14221: iconst_0
    //   14222: invokespecial <init> : ([BI)V
    //   14225: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14230: aload #8
    //   14232: sipush #367
    //   14235: sipush #247
    //   14238: invokeinterface setAlignedInt : (II)V
    //   14243: aload #8
    //   14245: sipush #368
    //   14248: new org/renjin/gcc/runtime/BytePtr
    //   14251: dup
    //   14252: ldc_w 'parenrightbt '
    //   14255: invokevirtual getBytes : ()[B
    //   14258: iconst_0
    //   14259: invokespecial <init> : ([BI)V
    //   14262: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14267: aload #8
    //   14269: sipush #369
    //   14272: sipush #248
    //   14275: invokeinterface setAlignedInt : (II)V
    //   14280: aload #8
    //   14282: sipush #370
    //   14285: new org/renjin/gcc/runtime/BytePtr
    //   14288: dup
    //   14289: ldc_w 'bracketrighttp '
    //   14292: invokevirtual getBytes : ()[B
    //   14295: iconst_0
    //   14296: invokespecial <init> : ([BI)V
    //   14299: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14304: aload #8
    //   14306: sipush #371
    //   14309: sipush #249
    //   14312: invokeinterface setAlignedInt : (II)V
    //   14317: aload #8
    //   14319: sipush #372
    //   14322: new org/renjin/gcc/runtime/BytePtr
    //   14325: dup
    //   14326: ldc_w 'bracketrightex '
    //   14329: invokevirtual getBytes : ()[B
    //   14332: iconst_0
    //   14333: invokespecial <init> : ([BI)V
    //   14336: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14341: aload #8
    //   14343: sipush #373
    //   14346: sipush #250
    //   14349: invokeinterface setAlignedInt : (II)V
    //   14354: aload #8
    //   14356: sipush #374
    //   14359: new org/renjin/gcc/runtime/BytePtr
    //   14362: dup
    //   14363: ldc_w 'bracketrightbt '
    //   14366: invokevirtual getBytes : ()[B
    //   14369: iconst_0
    //   14370: invokespecial <init> : ([BI)V
    //   14373: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14378: aload #8
    //   14380: sipush #375
    //   14383: sipush #251
    //   14386: invokeinterface setAlignedInt : (II)V
    //   14391: aload #8
    //   14393: sipush #376
    //   14396: new org/renjin/gcc/runtime/BytePtr
    //   14399: dup
    //   14400: ldc_w 'bracerighttp '
    //   14403: invokevirtual getBytes : ()[B
    //   14406: iconst_0
    //   14407: invokespecial <init> : ([BI)V
    //   14410: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14415: aload #8
    //   14417: sipush #377
    //   14420: sipush #252
    //   14423: invokeinterface setAlignedInt : (II)V
    //   14428: aload #8
    //   14430: sipush #378
    //   14433: new org/renjin/gcc/runtime/BytePtr
    //   14436: dup
    //   14437: ldc_w 'bracerightmid '
    //   14440: invokevirtual getBytes : ()[B
    //   14443: iconst_0
    //   14444: invokespecial <init> : ([BI)V
    //   14447: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14452: aload #8
    //   14454: sipush #379
    //   14457: sipush #253
    //   14460: invokeinterface setAlignedInt : (II)V
    //   14465: aload #8
    //   14467: sipush #380
    //   14470: new org/renjin/gcc/runtime/BytePtr
    //   14473: dup
    //   14474: ldc_w 'bracerightbt '
    //   14477: invokevirtual getBytes : ()[B
    //   14480: iconst_0
    //   14481: invokespecial <init> : ([BI)V
    //   14484: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14489: aload #8
    //   14491: sipush #381
    //   14494: sipush #254
    //   14497: invokeinterface setAlignedInt : (II)V
    //   14502: aload #8
    //   14504: sipush #382
    //   14507: iconst_0
    //   14508: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   14511: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14516: aload #8
    //   14518: sipush #383
    //   14521: iconst_0
    //   14522: invokeinterface setAlignedInt : (II)V
    //   14527: aload_0
    //   14528: getfield plotmath$SymbolTable : Lorg/renjin/gcc/runtime/Ptr;
    //   14531: aload #8
    //   14533: sipush #1536
    //   14536: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   14541: aload_0
    //   14542: ldc2_w 0.15
    //   14545: putfield plotmath$ItalicFactor : D
    //   14548: aload_0
    //   14549: iconst_2
    //   14550: putfield plotmath$MetricUnit : I
    //   14553: bipush #17
    //   14555: newarray int
    //   14557: dup
    //   14558: iconst_0
    //   14559: ldc_w 1073790977
    //   14562: iastore
    //   14563: dup
    //   14564: iconst_1
    //   14565: ldc_w 268460033
    //   14568: iastore
    //   14569: dup
    //   14570: iconst_2
    //   14571: ldc_w 67121153
    //   14574: iastore
    //   14575: dup
    //   14576: iconst_3
    //   14577: ldc_w 16783361
    //   14580: iastore
    //   14581: dup
    //   14582: iconst_4
    //   14583: ldc_w 4197377
    //   14586: iastore
    //   14587: dup
    //   14588: iconst_5
    //   14589: ldc_w 1050113
    //   14592: iastore
    //   14593: dup
    //   14594: bipush #6
    //   14596: ldc_w 262913
    //   14599: iastore
    //   14600: dup
    //   14601: bipush #7
    //   14603: ldc_w 65921
    //   14606: iastore
    //   14607: dup
    //   14608: bipush #8
    //   14610: sipush #16577
    //   14613: iastore
    //   14614: dup
    //   14615: bipush #9
    //   14617: sipush #4193
    //   14620: iastore
    //   14621: dup
    //   14622: bipush #10
    //   14624: sipush #1073
    //   14627: iastore
    //   14628: dup
    //   14629: bipush #11
    //   14631: sipush #281
    //   14634: iastore
    //   14635: dup
    //   14636: bipush #12
    //   14638: bipush #77
    //   14640: iastore
    //   14641: dup
    //   14642: bipush #13
    //   14644: bipush #23
    //   14646: iastore
    //   14647: dup
    //   14648: bipush #14
    //   14650: bipush #8
    //   14652: iastore
    //   14653: dup
    //   14654: bipush #15
    //   14656: iconst_1
    //   14657: iastore
    //   14658: dup
    //   14659: bipush #16
    //   14661: iconst_0
    //   14662: iastore
    //   14663: iconst_0
    //   14664: aload_0
    //   14665: getfield sort$sincs : [I
    //   14668: iconst_0
    //   14669: bipush #17
    //   14671: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   14674: bipush #21
    //   14676: newarray int
    //   14678: dup
    //   14679: iconst_0
    //   14680: ldc_w 786433
    //   14683: iastore
    //   14684: dup
    //   14685: iconst_1
    //   14686: ldc_w 393217
    //   14689: iastore
    //   14690: dup
    //   14691: iconst_2
    //   14692: ldc_w 196609
    //   14695: iastore
    //   14696: dup
    //   14697: iconst_3
    //   14698: ldc_w 98305
    //   14701: iastore
    //   14702: dup
    //   14703: iconst_4
    //   14704: ldc_w 1073790977
    //   14707: iastore
    //   14708: dup
    //   14709: iconst_5
    //   14710: ldc_w 268460033
    //   14713: iastore
    //   14714: dup
    //   14715: bipush #6
    //   14717: ldc_w 67121153
    //   14720: iastore
    //   14721: dup
    //   14722: bipush #7
    //   14724: ldc_w 16783361
    //   14727: iastore
    //   14728: dup
    //   14729: bipush #8
    //   14731: ldc_w 4197377
    //   14734: iastore
    //   14735: dup
    //   14736: bipush #9
    //   14738: ldc_w 1050113
    //   14741: iastore
    //   14742: dup
    //   14743: bipush #10
    //   14745: ldc_w 262913
    //   14748: iastore
    //   14749: dup
    //   14750: bipush #11
    //   14752: ldc_w 65921
    //   14755: iastore
    //   14756: dup
    //   14757: bipush #12
    //   14759: sipush #16577
    //   14762: iastore
    //   14763: dup
    //   14764: bipush #13
    //   14766: sipush #4193
    //   14769: iastore
    //   14770: dup
    //   14771: bipush #14
    //   14773: sipush #1073
    //   14776: iastore
    //   14777: dup
    //   14778: bipush #15
    //   14780: sipush #281
    //   14783: iastore
    //   14784: dup
    //   14785: bipush #16
    //   14787: bipush #77
    //   14789: iastore
    //   14790: dup
    //   14791: bipush #17
    //   14793: bipush #23
    //   14795: iastore
    //   14796: dup
    //   14797: bipush #18
    //   14799: bipush #8
    //   14801: iastore
    //   14802: dup
    //   14803: bipush #19
    //   14805: iconst_1
    //   14806: iastore
    //   14807: dup
    //   14808: bipush #20
    //   14810: iconst_0
    //   14811: iastore
    //   14812: iconst_0
    //   14813: aload_0
    //   14814: getfield sort$incs : [I
    //   14817: iconst_0
    //   14818: bipush #21
    //   14820: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   14823: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */