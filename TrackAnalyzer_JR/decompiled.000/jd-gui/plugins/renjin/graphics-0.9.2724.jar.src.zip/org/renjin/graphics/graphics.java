package org.renjin.graphics;

import org.renjin.gcc.runtime.Ptr;
import org.renjin.primitives.packaging.DllInfo;
import org.renjin.sexp.SEXP;

public class graphics {
  public static SEXP C_box(SEXP paramSEXP) {
    return plot__.C_box(paramSEXP);
  }
  
  public static double Rf_GConvertY(double paramDouble, int paramInt1, int paramInt2, Ptr paramPtr) {
    return graphics__.Rf_GConvertY(paramDouble, paramInt1, paramInt2, paramPtr);
  }
  
  public static double Rf_GConvertX(double paramDouble, int paramInt1, int paramInt2, Ptr paramPtr) {
    return graphics__.Rf_GConvertX(paramDouble, paramInt1, paramInt2, paramPtr);
  }
  
  public static void Rf_formatInteger(Ptr paramPtr1, int paramInt, Ptr paramPtr2) {
    format__.Rf_formatInteger(paramPtr1, paramInt, paramPtr2);
  }
  
  public static void Rf_ssort(Ptr paramPtr, int paramInt) {
    sort__.Rf_ssort(paramPtr, paramInt);
  }
  
  public static void Rf_GCheckState(Ptr paramPtr) {
    graphics__.Rf_GCheckState(paramPtr);
  }
  
  public static void Rf_formatComplex(Ptr paramPtr1, int paramInt1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6, Ptr paramPtr7, int paramInt2) {
    format__.Rf_formatComplex(paramPtr1, paramInt1, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6, paramPtr7, paramInt2);
  }
  
  public static void R_rsort(Ptr paramPtr, int paramInt) {
    sort__.R_rsort(paramPtr, paramInt);
  }
  
  public static void Rf_GMode(int paramInt, Ptr paramPtr) {
    graphics__.Rf_GMode(paramInt, paramPtr);
  }
  
  public static SEXP RunregisterBase() {
    return base__.RunregisterBase();
  }
  
  public static void Rf_GRaster(Ptr paramPtr1, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, int paramInt3, Ptr paramPtr2) {
    graphics__.Rf_GRaster(paramPtr1, paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramInt3, paramPtr2);
  }
  
  public static void Rf_GRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr) {
    graphics__.Rf_GRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt1, paramInt2, paramInt3, paramPtr);
  }
  
  public static void Rf_revsort(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    sort__.Rf_revsort(paramPtr1, paramPtr2, paramInt);
  }
  
  public static double Rf_GStrWidth(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2) {
    return graphics__.Rf_GStrWidth(paramPtr1, paramInt1, paramInt2, paramPtr2);
  }
  
  public static SEXP C_persp(SEXP paramSEXP) {
    return plot3d__.C_persp(paramSEXP);
  }
  
  public static void Rf_formatRaw(Ptr paramPtr1, int paramInt, Ptr paramPtr2) {
    format__.Rf_formatRaw(paramPtr1, paramInt, paramPtr2);
  }
  
  public static void Rf_GRestore(Ptr paramPtr) {
    graphics__.Rf_GRestore(paramPtr);
  }
  
  public static void unregisterBase() {
    base__.unregisterBase();
  }
  
  public static void Rf_sortVector(SEXP paramSEXP, int paramInt) {
    sort__.Rf_sortVector(paramSEXP, paramInt);
  }
  
  public static void Rf_GSetupAxis(int paramInt, Ptr paramPtr) {
    graphics__.Rf_GSetupAxis(paramInt, paramPtr);
  }
  
  public static void Rf_GSymbol(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, Ptr paramPtr) {
    graphics__.Rf_GSymbol(paramDouble1, paramDouble2, paramInt1, paramInt2, paramPtr);
  }
  
  public static void Rf_GRestorePars(Ptr paramPtr) {
    graphics__.Rf_GRestorePars(paramPtr);
  }
  
  public static void Rf_GPolygon(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr3) {
    graphics__.Rf_GPolygon(paramInt1, paramPtr1, paramPtr2, paramInt2, paramInt3, paramInt4, paramPtr3);
  }
  
  public static SEXP C_xspline(SEXP paramSEXP) {
    return plot__.C_xspline(paramSEXP);
  }
  
  public static SEXP C_StemLeaf(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stem__.C_StemLeaf(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP C_symbols(SEXP paramSEXP) {
    return plot__.C_symbols(paramSEXP);
  }
  
  public static double Rf_yNPCtoUsr(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_yNPCtoUsr(paramDouble, paramPtr);
  }
  
  public static SEXP C_abline(SEXP paramSEXP) {
    return plot__.C_abline(paramSEXP);
  }
  
  public static void R_orderVector(Ptr paramPtr, int paramInt1, SEXP paramSEXP, int paramInt2, int paramInt3) {
    sort__.R_orderVector(paramPtr, paramInt1, paramSEXP, paramInt2, paramInt3);
  }
  
  public static void Rf_GMathText(double paramDouble1, double paramDouble2, int paramInt, SEXP paramSEXP, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr) {
    graphics__.Rf_GMathText(paramDouble1, paramDouble2, paramInt, paramSEXP, paramDouble3, paramDouble4, paramDouble5, paramPtr);
  }
  
  public static SEXP C_rect(SEXP paramSEXP) {
    return plot__.C_rect(paramSEXP);
  }
  
  public static void R_csort(Ptr paramPtr, int paramInt) {
    sort__.R_csort(paramPtr, paramInt);
  }
  
  public static double Rf_xDevtoNPC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_xDevtoNPC(paramDouble, paramPtr);
  }
  
  public static void Rf_GArrow(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, double paramDouble5, double paramDouble6, int paramInt2, Ptr paramPtr) {
    graphics__.Rf_GArrow(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt1, paramDouble5, paramDouble6, paramInt2, paramPtr);
  }
  
  public static SEXP C_arrows(SEXP paramSEXP) {
    return plot__.C_arrows(paramSEXP);
  }
  
  public static void Rf_GMMathText(SEXP paramSEXP, int paramInt1, double paramDouble1, int paramInt2, double paramDouble2, int paramInt3, double paramDouble3, Ptr paramPtr) {
    graphics__.Rf_GMMathText(paramSEXP, paramInt1, paramDouble1, paramInt2, paramDouble2, paramInt3, paramDouble3, paramPtr);
  }
  
  public static void Rf_GSavePars(Ptr paramPtr) {
    graphics__.Rf_GSavePars(paramPtr);
  }
  
  public static double Rf_GExpressionWidth(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return graphics__.Rf_GExpressionWidth(paramSEXP, paramInt, paramPtr);
  }
  
  public static SEXP do_psort(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_psort(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static double Rf_xDevtoNFC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_xDevtoNFC(paramDouble, paramPtr);
  }
  
  public static double Rf_xDevtoUsr(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_xDevtoUsr(paramDouble, paramPtr);
  }
  
  public static Ptr Rf_GNewPlot(int paramInt) {
    return graphics__.Rf_GNewPlot(paramInt);
  }
  
  public static SEXP C_par(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return par__.C_par(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP C_plot_new(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return plot__.C_plot_new(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static double Rf_xDevtoNDC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_xDevtoNDC(paramDouble, paramPtr);
  }
  
  public static SEXP C_axis(SEXP paramSEXP) {
    return plot__.C_axis(paramSEXP);
  }
  
  public static void R_orderVector1(Ptr paramPtr, int paramInt1, SEXP paramSEXP, int paramInt2, int paramInt3) {
    sort__.R_orderVector1(paramPtr, paramInt1, paramSEXP, paramInt2, paramInt3);
  }
  
  public static void Rf_GAxisPars(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt1, int paramInt2) {
    graphics__.Rf_GAxisPars(paramPtr1, paramPtr2, paramPtr3, paramInt1, paramInt2);
  }
  
  public static void Rf_GCircle(double paramDouble1, double paramDouble2, int paramInt1, double paramDouble3, int paramInt2, int paramInt3, Ptr paramPtr) {
    graphics__.Rf_GCircle(paramDouble1, paramDouble2, paramInt1, paramDouble3, paramInt2, paramInt3, paramPtr);
  }
  
  public static void Rf_formatLogical(Ptr paramPtr1, int paramInt, Ptr paramPtr2) {
    format__.Rf_formatLogical(paramPtr1, paramInt, paramPtr2);
  }
  
  public static SEXP C_identify(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return plot__.C_identify(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static int Rf_isUnsorted(SEXP paramSEXP, int paramInt) {
    return sort__.Rf_isUnsorted(paramSEXP, paramInt);
  }
  
  public static void Rf_GLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt, Ptr paramPtr) {
    graphics__.Rf_GLine(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt, paramPtr);
  }
  
  public static SEXP C_plot_window(SEXP paramSEXP) {
    return plot__.C_plot_window(paramSEXP);
  }
  
  public static SEXP C_convertX(SEXP paramSEXP) {
    return plot__.C_convertX(paramSEXP);
  }
  
  public static SEXP C_convertY(SEXP paramSEXP) {
    return plot__.C_convertY(paramSEXP);
  }
  
  public static SEXP C_erase(SEXP paramSEXP) {
    return plot__.C_erase(paramSEXP);
  }
  
  public static double Rf_xNPCtoUsr(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_xNPCtoUsr(paramDouble, paramPtr);
  }
  
  public static SEXP C_segments(SEXP paramSEXP) {
    return plot__.C_segments(paramSEXP);
  }
  
  public static SEXP C_title(SEXP paramSEXP) {
    return plot__.C_title(paramSEXP);
  }
  
  public static void GEMathText(double paramDouble1, double paramDouble2, SEXP paramSEXP, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr1, Ptr paramPtr2) {
    plotmath__.GEMathText(paramDouble1, paramDouble2, paramSEXP, paramDouble3, paramDouble4, paramDouble5, paramPtr1, paramPtr2);
  }
  
  public static void rsort_with_index(Ptr paramPtr1, Ptr paramPtr2, int paramInt) {
    sort__.rsort_with_index(paramPtr1, paramPtr2, paramInt);
  }
  
  public static void Rf_GMtext(Ptr paramPtr1, int paramInt1, int paramInt2, double paramDouble1, int paramInt3, double paramDouble2, int paramInt4, double paramDouble3, Ptr paramPtr2) {
    graphics__.Rf_GMtext(paramPtr1, paramInt1, paramInt2, paramDouble1, paramInt3, paramDouble2, paramInt4, paramDouble3, paramPtr2);
  }
  
  public static SEXP C_text(SEXP paramSEXP) {
    return plot__.C_text(paramSEXP);
  }
  
  public static Ptr Rf_dpptr(Ptr paramPtr) {
    return base__.Rf_dpptr(paramPtr);
  }
  
  public static int Rf_GLocator(Ptr paramPtr1, Ptr paramPtr2, int paramInt, Ptr paramPtr3) {
    return graphics__.Rf_GLocator(paramPtr1, paramPtr2, paramInt, paramPtr3);
  }
  
  public static void Rf_GSetState(int paramInt, Ptr paramPtr) {
    graphics__.Rf_GSetState(paramInt, paramPtr);
  }
  
  public static SEXP C_path(SEXP paramSEXP) {
    return plot__.C_path(paramSEXP);
  }
  
  public static void Rf_GForceClip(Ptr paramPtr) {
    graphics__.Rf_GForceClip(paramPtr);
  }
  
  public static void Rf_GScale(double paramDouble1, double paramDouble2, int paramInt, Ptr paramPtr) {
    graphics__.Rf_GScale(paramDouble1, paramDouble2, paramInt, paramPtr);
  }
  
  public static SEXP C_raster(SEXP paramSEXP) {
    return plot__.C_raster(paramSEXP);
  }
  
  public static void R_init_graphics(DllInfo paramDllInfo) {
    init__.R_init_graphics(paramDllInfo);
  }
  
  public static SEXP C_layout(SEXP paramSEXP) {
    return par__.C_layout(paramSEXP);
  }
  
  public static void Rf_iPsort(Ptr paramPtr, int paramInt1, int paramInt2) {
    sort__.Rf_iPsort(paramPtr, paramInt1, paramInt2);
  }
  
  public static SEXP C_plotXY(SEXP paramSEXP) {
    return plot__.C_plotXY(paramSEXP);
  }
  
  public static void Rf_GBox(int paramInt, Ptr paramPtr) {
    graphics__.Rf_GBox(paramInt, paramPtr);
  }
  
  public static void registerBase() {
    base__.registerBase();
  }
  
  public static SEXP C_clip(SEXP paramSEXP) {
    return plot__.C_clip(paramSEXP);
  }
  
  public static SEXP Rf_labelformat(SEXP paramSEXP) {
    return plot__.Rf_labelformat(paramSEXP);
  }
  
  public static SEXP Rf_CreateAtVector(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, int paramInt2) {
    return at_vector__.Rf_CreateAtVector(paramPtr1, paramPtr2, paramInt1, paramInt2);
  }
  
  public static void Rf_GClip(Ptr paramPtr) {
    graphics__.Rf_GClip(paramPtr);
  }
  
  public static int Rf_GMapUnits(int paramInt) {
    return graphics__.Rf_GMapUnits(paramInt);
  }
  
  public static double GEExpressionWidth(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    return plotmath__.GEExpressionWidth(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void Rf_GPretty(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    graphics__.Rf_GPretty(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void Rf_GMetricInfo(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2, Ptr paramPtr4) {
    graphics__.Rf_GMetricInfo(paramInt1, paramPtr1, paramPtr2, paramPtr3, paramInt2, paramPtr4);
  }
  
  public static SEXP Rf_FixupCol(SEXP paramSEXP, int paramInt) {
    return plot__.Rf_FixupCol(paramSEXP, paramInt);
  }
  
  public static void gcontextFromGP(Ptr paramPtr1, Ptr paramPtr2) {
    graphics__.gcontextFromGP(paramPtr1, paramPtr2);
  }
  
  public static double Rf_GConvertXUnits(double paramDouble, int paramInt1, int paramInt2, Ptr paramPtr) {
    return graphics__.Rf_GConvertXUnits(paramDouble, paramInt1, paramInt2, paramPtr);
  }
  
  public static void Rf_rPsort(Ptr paramPtr, int paramInt1, int paramInt2) {
    sort__.Rf_rPsort(paramPtr, paramInt1, paramInt2);
  }
  
  public static SEXP do_xtfrm(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_xtfrm(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void Rf_GPath(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, Ptr paramPtr3, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr4) {
    graphics__.Rf_GPath(paramPtr1, paramPtr2, paramInt1, paramPtr3, paramInt2, paramInt3, paramInt4, paramPtr4);
  }
  
  public static void Rf_ProcessInlinePars(SEXP paramSEXP, Ptr paramPtr) {
    par__.Rf_ProcessInlinePars(paramSEXP, paramPtr);
  }
  
  public static double Rf_GStrHeight(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2) {
    return graphics__.Rf_GStrHeight(paramPtr1, paramInt1, paramInt2, paramPtr2);
  }
  
  public static SEXP do_rank(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_rank(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void Rf_GConvert(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, int paramInt2, Ptr paramPtr3) {
    graphics__.Rf_GConvert(paramPtr1, paramPtr2, paramInt1, paramInt2, paramPtr3);
  }
  
  public static SEXP Rf_FixupVFont(SEXP paramSEXP) {
    return plot__.Rf_FixupVFont(paramSEXP);
  }
  
  public static void Rf_formatReal(Ptr paramPtr1, int paramInt1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, int paramInt2) {
    format__.Rf_formatReal(paramPtr1, paramInt1, paramPtr2, paramPtr3, paramPtr4, paramInt2);
  }
  
  public static SEXP C_polygon(SEXP paramSEXP) {
    return plot__.C_polygon(paramSEXP);
  }
  
  public static SEXP C_strWidth(SEXP paramSEXP) {
    return plot__.C_strWidth(paramSEXP);
  }
  
  public static SEXP do_sort(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_sort(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void Rf_GMapWin2Fig(Ptr paramPtr) {
    graphics__.Rf_GMapWin2Fig(paramPtr);
  }
  
  public static void Rf_GInit(Ptr paramPtr) {
    graphics__.Rf_GInit(paramPtr);
  }
  
  public static void Rf_GText(double paramDouble1, double paramDouble2, int paramInt1, Ptr paramPtr1, int paramInt2, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr2) {
    graphics__.Rf_GText(paramDouble1, paramDouble2, paramInt1, paramPtr1, paramInt2, paramDouble3, paramDouble4, paramDouble5, paramPtr2);
  }
  
  public static SEXP C_mtext(SEXP paramSEXP) {
    return plot__.C_mtext(paramSEXP);
  }
  
  public static SEXP C_filledcontour(SEXP paramSEXP) {
    return plot3d__.C_filledcontour(paramSEXP);
  }
  
  public static void Rf_copyGPar(Ptr paramPtr1, Ptr paramPtr2) {
    graphics__.Rf_copyGPar(paramPtr1, paramPtr2);
  }
  
  public static double GEExpressionHeight(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2) {
    return plotmath__.GEExpressionHeight(paramSEXP, paramPtr1, paramPtr2);
  }
  
  public static void orderVector1(Ptr paramPtr, int paramInt1, SEXP paramSEXP1, int paramInt2, int paramInt3, SEXP paramSEXP2) {
    sort__.orderVector1(paramPtr, paramInt1, paramSEXP1, paramInt2, paramInt3, paramSEXP2);
  }
  
  public static void Rf_formatString(Ptr paramPtr1, int paramInt1, Ptr paramPtr2, int paramInt2) {
    format__.Rf_formatString(paramPtr1, paramInt1, paramPtr2, paramInt2);
  }
  
  public static double Rf_yDevtoNDC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_yDevtoNDC(paramDouble, paramPtr);
  }
  
  public static int Rf_GClipPolygon(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, int paramInt2, int paramInt3, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    return graphics__.Rf_GClipPolygon(paramPtr1, paramPtr2, paramInt1, paramInt2, paramInt3, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static void Rf_GReset(Ptr paramPtr) {
    graphics__.Rf_GReset(paramPtr);
  }
  
  public static double Rf_GExpressionHeight(SEXP paramSEXP, int paramInt, Ptr paramPtr) {
    return graphics__.Rf_GExpressionHeight(paramSEXP, paramInt, paramPtr);
  }
  
  public static double Rf_yDevtoNFC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_yDevtoNFC(paramDouble, paramPtr);
  }
  
  public static double Rf_yDevtoUsr(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_yDevtoUsr(paramDouble, paramPtr);
  }
  
  public static SEXP C_contourDef() {
    return plot3d__.C_contourDef();
  }
  
  public static SEXP C_contour(SEXP paramSEXP) {
    return plot3d__.C_contour(paramSEXP);
  }
  
  public static SEXP C_image(SEXP paramSEXP) {
    return plot3d__.C_image(paramSEXP);
  }
  
  public static double Rf_GConvertYUnits(double paramDouble, int paramInt1, int paramInt2, Ptr paramPtr) {
    return graphics__.Rf_GConvertYUnits(paramDouble, paramInt1, paramInt2, paramPtr);
  }
  
  public static double R_Log10(double paramDouble) {
    return graphics__.R_Log10(paramDouble);
  }
  
  public static SEXP C_locator(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return plot__.C_locator(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP C_BinCount(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stem__.C_BinCount(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static Ptr Rf_gpptr(Ptr paramPtr) {
    return base__.Rf_gpptr(paramPtr);
  }
  
  public static int GRecording(SEXP paramSEXP, Ptr paramPtr) {
    return graphics__.GRecording(paramSEXP, paramPtr);
  }
  
  public static void R_isort(Ptr paramPtr, int paramInt) {
    sort__.R_isort(paramPtr, paramInt);
  }
  
  public static SEXP do_order(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_order(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP C_strHeight(SEXP paramSEXP) {
    return plot__.C_strHeight(paramSEXP);
  }
  
  public static void Rf_currentFigureLocation(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    graphics__.Rf_currentFigureLocation(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static double Rf_yDevtoNPC(double paramDouble, Ptr paramPtr) {
    return graphics__.Rf_yDevtoNPC(paramDouble, paramPtr);
  }
  
  public static SEXP Rf_FixupLwd(SEXP paramSEXP, double paramDouble) {
    return plot__.Rf_FixupLwd(paramSEXP, paramDouble);
  }
  
  public static void GEExpressionMetric(SEXP paramSEXP, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    plotmath__.GEExpressionMetric(paramSEXP, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static int isNAcol(SEXP paramSEXP, int paramInt1, int paramInt2) {
    return plot__.isNAcol(paramSEXP, paramInt1, paramInt2);
  }
  
  public static void Rf_cPsort(Ptr paramPtr, int paramInt1, int paramInt2) {
    sort__.Rf_cPsort(paramPtr, paramInt1, paramInt2);
  }
  
  public static SEXP Rf_FixupLty(SEXP paramSEXP, int paramInt) {
    return plot__.Rf_FixupLty(paramSEXP, paramInt);
  }
  
  public static void Rf_GPolyline(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, int paramInt2, Ptr paramPtr3) {
    graphics__.Rf_GPolyline(paramInt1, paramPtr1, paramPtr2, paramInt2, paramPtr3);
  }
  
  public static void Rf_setBaseDevice(int paramInt, Ptr paramPtr) {
    base__.Rf_setBaseDevice(paramInt, paramPtr);
  }
  
  public static void GLPretty(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    graphics__.GLPretty(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static SEXP do_isunsorted(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return sort__.do_isunsorted(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP C_dend(SEXP paramSEXP) {
    return plot__.C_dend(paramSEXP);
  }
  
  public static SEXP C_dendwindow(SEXP paramSEXP) {
    return plot__.C_dendwindow(paramSEXP);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/graphics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */