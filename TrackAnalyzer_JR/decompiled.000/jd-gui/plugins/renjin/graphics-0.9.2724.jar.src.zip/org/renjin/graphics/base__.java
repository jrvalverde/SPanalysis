/*     */ package org.renjin.graphics;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.Stdlib;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.GetText;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.grDevices.baseDevices__;
/*     */ import org.renjin.grDevices.baseEngine__;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class base__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static Ptr dpSavedptr(Ptr dd) {
/*  42 */     if (Context.get__graphics$baseRegisterIndex()[0] == -1)
/*  43 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("no base graphics system is registered\000".getBytes(), 0)), new Object[0]); 
/*  44 */     baseRegisterIndex$19 = Context.get__graphics$baseRegisterIndex()[0];
/*  45 */     Ptr ptr = dd.getPointer(28 + baseRegisterIndex$19 * 4).getPointer(); int i = 0 + 71912; return ptr.pointerPlus(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void restoredpSaved(Ptr dd) {
/*  56 */     nc = 0; nr = 0; Ptr ptr116 = Rf_dpptr(dd); int i39 = dpSavedptr(dd).getInt(); ptr116.setInt(0, i39);
/*     */     
/*  58 */     Ptr ptr115 = Rf_dpptr(dd); double d67 = dpSavedptr(dd).getDouble(8); ptr115.setDouble(8, d67);
/*  59 */     Ptr ptr114 = Rf_dpptr(dd); int i38 = dpSavedptr(dd).getInt(16); ptr114.setInt(16, i38);
/*  60 */     Ptr ptr113 = Rf_dpptr(dd); int i37 = dpSavedptr(dd).getInt(20); ptr113.setInt(20, i37);
/*  61 */     Ptr ptr112 = Rf_dpptr(dd); byte b6 = dpSavedptr(dd).getByte(24); ptr112.setByte(24, b6);
/*  62 */     Ptr ptr111 = Rf_dpptr(dd); double d66 = dpSavedptr(dd).getDouble(28); ptr111.setDouble(28, d66);
/*  63 */     Ptr ptr110 = Rf_gpptr(dd); double d65 = dpSavedptr(dd).getDouble(36); ptr110.setDouble(36, d65);
/*  64 */     Ptr ptr109 = Rf_dpptr(dd); int i36 = dpSavedptr(dd).getInt(44); ptr109.setInt(44, i36);
/*  65 */     Ptr ptr108 = Rf_dpptr(dd); double d64 = dpSavedptr(dd).getDouble(48); ptr108.setDouble(48, d64);
/*  66 */     Ptr ptr107 = Rf_dpptr(dd); int i35 = dpSavedptr(dd).getInt(72); ptr107.setInt(72, i35);
/*  67 */     Ptr ptr106 = Rf_dpptr(dd); int i34 = dpSavedptr(dd).getInt(76); ptr106.setInt(76, i34);
/*  68 */     Ptr ptr105 = dpSavedptr(dd); Stdlib.strncpy(Rf_dpptr(dd).pointerPlus(80), ptr105.pointerPlus(80), 201);
/*  69 */     Ptr ptr104 = Rf_dpptr(dd); int i33 = dpSavedptr(dd).getInt(284); ptr104.setInt(284, i33);
/*  70 */     Ptr ptr103 = Rf_dpptr(dd); double d63 = dpSavedptr(dd).getDouble(288); ptr103.setDouble(288, d63);
/*  71 */     Ptr ptr102 = Rf_dpptr(dd); int i32 = dpSavedptr(dd).getInt(296); ptr102.setInt(296, i32);
/*  72 */     Ptr ptr101 = Rf_dpptr(dd); int i31 = dpSavedptr(dd).getInt(300); ptr101.setInt(300, i31);
/*  73 */     Ptr ptr100 = Rf_dpptr(dd); int i30 = dpSavedptr(dd).getInt(304); ptr100.setInt(304, i30);
/*  74 */     Ptr ptr99 = Rf_dpptr(dd); int i29 = dpSavedptr(dd).getInt(308); ptr99.setInt(308, i29);
/*  75 */     Ptr ptr98 = Rf_dpptr(dd); int i28 = dpSavedptr(dd).getInt(312); ptr98.setInt(312, i28);
/*  76 */     Ptr ptr97 = Rf_dpptr(dd); double d62 = dpSavedptr(dd).getDouble(316); ptr97.setDouble(316, d62);
/*  77 */     Ptr ptr96 = Rf_dpptr(dd); int i27 = dpSavedptr(dd).getInt(324); ptr96.setInt(324, i27);
/*  78 */     Ptr ptr95 = Rf_dpptr(dd); int i26 = dpSavedptr(dd).getInt(328); ptr95.setInt(328, i26);
/*  79 */     Ptr ptr94 = Rf_dpptr(dd); double d61 = dpSavedptr(dd).getDouble(332); ptr94.setDouble(332, d61);
/*  80 */     Ptr ptr93 = Rf_dpptr(dd); double d60 = dpSavedptr(dd).getDouble(340); ptr93.setDouble(340, d60);
/*  81 */     Ptr ptr92 = Rf_dpptr(dd); double d59 = dpSavedptr(dd).getDouble(348); ptr92.setDouble(348, d59);
/*  82 */     Ptr ptr91 = Rf_dpptr(dd); double d58 = dpSavedptr(dd).getDouble(356); ptr91.setDouble(356, d58);
/*  83 */     Ptr ptr90 = Rf_dpptr(dd); double d57 = dpSavedptr(dd).getDouble(364); ptr90.setDouble(364, d57);
/*  84 */     Ptr ptr89 = Rf_dpptr(dd); int i25 = dpSavedptr(dd).getInt(372); ptr89.setInt(372, i25);
/*  85 */     Ptr ptr88 = Rf_dpptr(dd); double d56 = dpSavedptr(dd).getDouble(376); ptr88.setDouble(376, d56);
/*  86 */     Ptr ptr87 = Rf_dpptr(dd); int i24 = dpSavedptr(dd).getInt(384); ptr87.setInt(384, i24);
/*  87 */     Ptr ptr86 = Rf_dpptr(dd); double d55 = dpSavedptr(dd).getDouble(388); ptr86.setDouble(388, d55);
/*  88 */     Ptr ptr85 = Rf_dpptr(dd); double d54 = dpSavedptr(dd).getDouble(396); ptr85.setDouble(396, d54);
/*  89 */     Ptr ptr84 = Rf_dpptr(dd); double d53 = dpSavedptr(dd).getDouble(404); ptr84.setDouble(404, d53);
/*  90 */     Ptr ptr83 = Rf_dpptr(dd); double d52 = dpSavedptr(dd).getDouble(412); ptr83.setDouble(412, d52);
/*  91 */     Ptr ptr82 = Rf_dpptr(dd); double d51 = dpSavedptr(dd).getDouble(420); ptr82.setDouble(420, d51);
/*  92 */     Ptr ptr81 = Rf_dpptr(dd); double d50 = dpSavedptr(dd).getDouble(428); ptr81.setDouble(428, d50);
/*  93 */     Ptr ptr80 = Rf_dpptr(dd); byte b5 = dpSavedptr(dd).getByte(436); ptr80.setByte(436, b5);
/*  94 */     Ptr ptr79 = Rf_dpptr(dd); byte b4 = dpSavedptr(dd).getByte(437); ptr79.setByte(437, b4);
/*  95 */     Ptr ptr78 = Rf_dpptr(dd); int i23 = dpSavedptr(dd).getInt(444); ptr78.setInt(444, i23);
/*     */     
/*  97 */     Ptr ptr77 = Rf_dpptr(dd); int i22 = dpSavedptr(dd).getInt(440); ptr77.setInt(440, i22);
/*  98 */     Ptr ptr76 = Rf_dpptr(dd); double d49 = dpSavedptr(dd).getDouble(452); ptr76.setDouble(452, d49);
/*  99 */     Ptr ptr75 = Rf_dpptr(dd); double d48 = dpSavedptr(dd).getDouble(460); ptr75.setDouble(460, d48);
/* 100 */     Ptr ptr74 = Rf_dpptr(dd); double d47 = dpSavedptr(dd).getDouble(468); ptr74.setDouble(468, d47);
/* 101 */     Ptr ptr73 = Rf_dpptr(dd); byte b3 = dpSavedptr(dd).getByte(476); ptr73.setByte(476, b3);
/* 102 */     Ptr ptr72 = Rf_dpptr(dd); byte b2 = dpSavedptr(dd).getByte(477); ptr72.setByte(477, b2);
/* 103 */     Ptr ptr71 = Rf_dpptr(dd); int i21 = dpSavedptr(dd).getInt(480); ptr71.setInt(480, i21);
/* 104 */     Ptr ptr70 = Rf_dpptr(dd); double d46 = dpSavedptr(dd).getDouble(484); ptr70.setDouble(484, d46);
/* 105 */     Ptr ptr69 = Rf_dpptr(dd); double d45 = dpSavedptr(dd).getDouble(492); ptr69.setDouble(492, d45);
/* 106 */     Ptr ptr68 = Rf_dpptr(dd); double d44 = dpSavedptr(dd).getDouble(500); ptr68.setDouble(500, d44);
/* 107 */     Ptr ptr67 = Rf_dpptr(dd); double d43 = dpSavedptr(dd).getDouble(508); ptr67.setDouble(508, d43);
/* 108 */     Ptr ptr66 = Rf_dpptr(dd); double d42 = dpSavedptr(dd).getDouble(516); ptr66.setDouble(516, d42);
/* 109 */     Ptr ptr65 = Rf_dpptr(dd); int i20 = dpSavedptr(dd).getInt(524); ptr65.setInt(524, i20);
/* 110 */     Ptr ptr64 = Rf_dpptr(dd); int i19 = dpSavedptr(dd).getInt(528); ptr64.setInt(528, i19);
/* 111 */     Ptr ptr63 = Rf_dpptr(dd); int i18 = dpSavedptr(dd).getInt(532); ptr63.setInt(532, i18);
/* 112 */     Ptr ptr62 = Rf_dpptr(dd); int i17 = dpSavedptr(dd).getInt(536); ptr62.setInt(536, i17);
/* 113 */     Ptr ptr61 = Rf_dpptr(dd); int i16 = dpSavedptr(dd).getInt(540); ptr61.setInt(540, i16);
/* 114 */     Ptr ptr60 = Rf_dpptr(dd); int i15 = dpSavedptr(dd).getInt(544); ptr60.setInt(544, i15);
/* 115 */     Ptr ptr59 = Rf_dpptr(dd); int i14 = dpSavedptr(dd).getInt(548); ptr59.setInt(548, i14);
/* 116 */     Ptr ptr58 = Rf_dpptr(dd); int i13 = dpSavedptr(dd).getInt(552); ptr58.setInt(552, i13);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     Ptr ptr57 = Rf_dpptr(dd); int i12 = dpSavedptr(dd).getInt(0 + 35768); ptr57.setInt(0 + 35768, i12);
/* 124 */     Ptr ptr56 = Rf_dpptr(dd); double d41 = dpSavedptr(dd).getDouble(0 + 35408); ptr56.setDouble(0 + 35408, d41);
/* 125 */     Ptr ptr55 = Rf_dpptr(dd); double d40 = dpSavedptr(dd).getDouble(0 + 35408 + 8); ptr55.setDouble(0 + 35408 + 8, d40);
/* 126 */     Ptr ptr54 = Rf_dpptr(dd); double d39 = dpSavedptr(dd).getDouble(0 + 35408 + 16); ptr54.setDouble(0 + 35408 + 16, d39);
/* 127 */     Ptr ptr53 = Rf_dpptr(dd); double d38 = dpSavedptr(dd).getDouble(0 + 35408 + 24); ptr53.setDouble(0 + 35408 + 24, d38);
/* 128 */     Ptr ptr52 = Rf_dpptr(dd); double d37 = dpSavedptr(dd).getDouble(0 + 35440); ptr52.setDouble(0 + 35440, d37);
/* 129 */     Ptr ptr51 = Rf_dpptr(dd); double d36 = dpSavedptr(dd).getDouble(0 + 35440 + 8); ptr51.setDouble(0 + 35440 + 8, d36);
/* 130 */     Ptr ptr50 = Rf_dpptr(dd); int i11 = dpSavedptr(dd).getInt(0 + 35456); ptr50.setInt(0 + 35456, i11);
/* 131 */     Ptr ptr49 = Rf_dpptr(dd); int i10 = dpSavedptr(dd).getInt(0 + 35512); ptr49.setInt(0 + 35512, i10);
/* 132 */     Ptr ptr48 = Rf_dpptr(dd); double d35 = dpSavedptr(dd).getDouble(0 + 35520); ptr48.setDouble(0 + 35520, d35);
/* 133 */     Ptr ptr47 = Rf_dpptr(dd); double d34 = dpSavedptr(dd).getDouble(0 + 35520 + 8); ptr47.setDouble(0 + 35520 + 8, d34);
/* 134 */     Ptr ptr46 = Rf_dpptr(dd); double d33 = dpSavedptr(dd).getDouble(0 + 35520 + 16); ptr46.setDouble(0 + 35520 + 16, d33);
/* 135 */     Ptr ptr45 = Rf_dpptr(dd); double d32 = dpSavedptr(dd).getDouble(0 + 35520 + 24); ptr45.setDouble(0 + 35520 + 24, d32);
/* 136 */     Ptr ptr44 = Rf_dpptr(dd); double d31 = dpSavedptr(dd).getDouble(0 + 35552); ptr44.setDouble(0 + 35552, d31);
/* 137 */     Ptr ptr43 = Rf_dpptr(dd); double d30 = dpSavedptr(dd).getDouble(0 + 35552 + 8); ptr43.setDouble(0 + 35552 + 8, d30);
/* 138 */     Ptr ptr42 = Rf_dpptr(dd); double d29 = dpSavedptr(dd).getDouble(0 + 35552 + 16); ptr42.setDouble(0 + 35552 + 16, d29);
/* 139 */     Ptr ptr41 = Rf_dpptr(dd); double d28 = dpSavedptr(dd).getDouble(0 + 35552 + 24); ptr41.setDouble(0 + 35552 + 24, d28);
/* 140 */     Ptr ptr40 = Rf_dpptr(dd); int i9 = dpSavedptr(dd).getInt(0 + 35584); ptr40.setInt(0 + 35584, i9);
/* 141 */     Ptr ptr39 = Rf_dpptr(dd); double d27 = dpSavedptr(dd).getDouble(0 + 35588); ptr39.setDouble(0 + 35588, d27);
/* 142 */     Ptr ptr38 = Rf_dpptr(dd); int i8 = dpSavedptr(dd).getInt(560); ptr38.setInt(560, i8); nr = ptr38.getInt(560);
/* 143 */     Ptr ptr37 = Rf_dpptr(dd); int i7 = dpSavedptr(dd).getInt(564); ptr37.setInt(564, i7); nc = ptr37.getInt(564);
/* 144 */     Ptr ptr36 = Rf_dpptr(dd); int i6 = dpSavedptr(dd).getInt(568); ptr36.setInt(568, i6);
/* 145 */     Ptr ptr35 = Rf_dpptr(dd); int i5 = dpSavedptr(dd).getInt(572); ptr35.setInt(572, i5);
/* 146 */     for (i = 0; i < nr && i <= 199; i++) {
/* 147 */       Ptr ptr118 = Rf_dpptr(dd); double d = dpSavedptr(dd).getDouble(576 + i * 8); ptr118.setDouble(576 + i * 8, d);
/* 148 */       Ptr ptr117 = Rf_dpptr(dd); int i40 = dpSavedptr(dd).getInt(3776 + i * 4); ptr117.setInt(3776 + i * 4, i40);
/*     */     } 
/* 150 */     for (j = 0; j < nc && j <= 199; j++) {
/* 151 */       Ptr ptr118 = Rf_dpptr(dd); double d = dpSavedptr(dd).getDouble(2176 + j * 8); ptr118.setDouble(2176 + j * 8, d);
/* 152 */       Ptr ptr117 = Rf_dpptr(dd); int i40 = dpSavedptr(dd).getInt(4576 + j * 4); ptr117.setInt(4576 + j * 4, i40);
/*     */     } 
/* 154 */     for (i = 0; nr * nc > i && i <= 10006; i++) {
/* 155 */       Ptr ptr118 = Rf_dpptr(dd); char c = dpSavedptr(dd).getChar(5376 + i * 2); ptr118.setChar(5376 + i * 2, c);
/* 156 */       Ptr ptr117 = Rf_dpptr(dd); int i40 = dpSavedptr(dd).getByte(25396 + i) & 0xFF; ptr117.setByte(25396 + i, i40);
/*     */     } 
/* 158 */     Ptr ptr34 = Rf_dpptr(dd); int i4 = dpSavedptr(dd).getInt(25392); ptr34.setInt(25392, i4);
/* 159 */     Ptr ptr33 = Rf_dpptr(dd); int i3 = dpSavedptr(dd).getInt(556); ptr33.setInt(556, i3);
/* 160 */     Ptr ptr32 = Rf_dpptr(dd); int i2 = dpSavedptr(dd).getInt(0 + 35404); ptr32.setInt(0 + 35404, i2);
/* 161 */     Ptr ptr31 = Rf_dpptr(dd); int i1 = dpSavedptr(dd).getInt(0 + 35764); ptr31.setInt(0 + 35764, i1);
/* 162 */     Ptr ptr30 = Rf_dpptr(dd); double d26 = dpSavedptr(dd).getDouble(0 + 35596); ptr30.setDouble(0 + 35596, d26);
/* 163 */     Ptr ptr29 = Rf_dpptr(dd); double d25 = dpSavedptr(dd).getDouble(0 + 35596 + 8); ptr29.setDouble(0 + 35596 + 8, d25);
/* 164 */     Ptr ptr28 = Rf_dpptr(dd); double d24 = dpSavedptr(dd).getDouble(0 + 35596 + 16); ptr28.setDouble(0 + 35596 + 16, d24);
/* 165 */     Ptr ptr27 = Rf_dpptr(dd); double d23 = dpSavedptr(dd).getDouble(0 + 35596 + 24); ptr27.setDouble(0 + 35596 + 24, d23);
/* 166 */     Ptr ptr26 = Rf_dpptr(dd); double d22 = dpSavedptr(dd).getDouble(0 + 35628); ptr26.setDouble(0 + 35628, d22);
/* 167 */     Ptr ptr25 = Rf_dpptr(dd); double d21 = dpSavedptr(dd).getDouble(0 + 35628 + 8); ptr25.setDouble(0 + 35628 + 8, d21);
/* 168 */     Ptr ptr24 = Rf_dpptr(dd); double d20 = dpSavedptr(dd).getDouble(0 + 35628 + 16); ptr24.setDouble(0 + 35628 + 16, d20);
/* 169 */     Ptr ptr23 = Rf_dpptr(dd); double d19 = dpSavedptr(dd).getDouble(0 + 35628 + 24); ptr23.setDouble(0 + 35628 + 24, d19);
/* 170 */     Ptr ptr22 = Rf_dpptr(dd); double d18 = dpSavedptr(dd).getDouble(0 + 35660); ptr22.setDouble(0 + 35660, d18);
/* 171 */     Ptr ptr21 = Rf_dpptr(dd); double d17 = dpSavedptr(dd).getDouble(0 + 35660 + 8); ptr21.setDouble(0 + 35660 + 8, d17);
/* 172 */     Ptr ptr20 = Rf_dpptr(dd); double d16 = dpSavedptr(dd).getDouble(0 + 35660 + 16); ptr20.setDouble(0 + 35660 + 16, d16);
/* 173 */     Ptr ptr19 = Rf_dpptr(dd); double d15 = dpSavedptr(dd).getDouble(0 + 35660 + 24); ptr19.setDouble(0 + 35660 + 24, d15);
/* 174 */     Ptr ptr18 = Rf_dpptr(dd); int n = dpSavedptr(dd).getInt(0 + 35692); ptr18.setInt(0 + 35692, n);
/* 175 */     Ptr ptr17 = Rf_dpptr(dd); double d14 = dpSavedptr(dd).getDouble(0 + 35460); ptr17.setDouble(0 + 35460, d14);
/* 176 */     Ptr ptr16 = Rf_dpptr(dd); double d13 = dpSavedptr(dd).getDouble(0 + 35460 + 8); ptr16.setDouble(0 + 35460 + 8, d13);
/* 177 */     Ptr ptr15 = Rf_dpptr(dd); double d12 = dpSavedptr(dd).getDouble(0 + 35460 + 16); ptr15.setDouble(0 + 35460 + 16, d12);
/* 178 */     Ptr ptr14 = Rf_dpptr(dd); double d11 = dpSavedptr(dd).getDouble(0 + 35460 + 24); ptr14.setDouble(0 + 35460 + 24, d11);
/* 179 */     Ptr ptr13 = Rf_dpptr(dd); double d10 = dpSavedptr(dd).getDouble(0 + 35492); ptr13.setDouble(0 + 35492, d10);
/* 180 */     Ptr ptr12 = Rf_dpptr(dd); double d9 = dpSavedptr(dd).getDouble(0 + 35492 + 8); ptr12.setDouble(0 + 35492 + 8, d9);
/* 181 */     Ptr ptr11 = Rf_dpptr(dd); int m = dpSavedptr(dd).getInt(0 + 35508); ptr11.setInt(0 + 35508, m);
/* 182 */     Ptr ptr10 = Rf_dpptr(dd); int k = dpSavedptr(dd).getInt(0 + 35516); ptr10.setInt(0 + 35516, k);
/* 183 */     Ptr ptr9 = Rf_dpptr(dd); byte b1 = dpSavedptr(dd).getByte(0 + 35696); ptr9.setByte(0 + 35696, b1);
/* 184 */     Ptr ptr8 = Rf_dpptr(dd); double d8 = dpSavedptr(dd).getDouble(0 + 35700); ptr8.setDouble(0 + 35700, d8);
/* 185 */     Ptr ptr7 = Rf_dpptr(dd); double d7 = dpSavedptr(dd).getDouble(0 + 35700 + 8); ptr7.setDouble(0 + 35700 + 8, d7);
/* 186 */     Ptr ptr6 = Rf_dpptr(dd); double d6 = dpSavedptr(dd).getDouble(0 + 35700 + 16); ptr6.setDouble(0 + 35700 + 16, d6);
/* 187 */     Ptr ptr5 = Rf_dpptr(dd); double d5 = dpSavedptr(dd).getDouble(0 + 35700 + 24); ptr5.setDouble(0 + 35700 + 24, d5);
/* 188 */     Ptr ptr4 = Rf_dpptr(dd); double d4 = dpSavedptr(dd).getDouble(0 + 35732); ptr4.setDouble(0 + 35732, d4);
/* 189 */     Ptr ptr3 = Rf_dpptr(dd); double d3 = dpSavedptr(dd).getDouble(0 + 35732 + 8); ptr3.setDouble(0 + 35732 + 8, d3);
/* 190 */     Ptr ptr2 = Rf_dpptr(dd); double d2 = dpSavedptr(dd).getDouble(0 + 35732 + 16); ptr2.setDouble(0 + 35732 + 16, d2);
/* 191 */     Ptr ptr1 = Rf_dpptr(dd); double d1 = dpSavedptr(dd).getDouble(0 + 35732 + 24); ptr1.setDouble(0 + 35732 + 24, d1); } public static SEXP baseCallback(int task, Ptr dd, SEXP data) { MixedPtr mixedPtr; Ptr ptr2; double d1, d2; Ptr ptr3; int k; Ptr ptr4; int m; Ptr ptr5; int n; SEXP sEXP1, sEXP2; Ptr ptr6; int i1; BytePtr bytePtr; Ptr ptr7; int i2; Ptr ptr8; int i3; Ptr ptr9; int i4; Ptr ptr10; int i5; Ptr ptr11;
/*     */     int i6;
/*     */     Ptr ptr12;
/*     */     int i7;
/*     */     Ptr ptr13;
/*     */     int i8;
/*     */     Ptr ptr14;
/* 198 */     graphicsState = (SEXP)BytePtr.of(0).getArray(); nState = 0; result = (SEXP)BytePtr.of(0).getArray(); result = Rinternals.R_NilValue;
/*     */     
/* 200 */     switch (task) {
/*     */       
/*     */       case 1:
/* 203 */         baseRegisterIndex$7 = Context.get__graphics$baseRegisterIndex()[0]; sd = dd.getPointer(28 + baseRegisterIndex$7 * 4); sd$offset = 0;
/* 204 */         ptr14 = sd.getPointer(sd$offset);
/* 205 */         sd.setPointer(sd$offset, BytePtr.of(0));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/* 212 */         baseRegisterIndex$8 = Context.get__graphics$baseRegisterIndex()[0]; sd = dd.getPointer(28 + baseRegisterIndex$8 * 4); sd$offset = 0;
/* 213 */         dev = dd.getPointer();
/* 214 */         mixedPtr = MixedPtr.malloc(107872); bss$offset = 0;
/* 215 */         sd.setPointer(sd$offset, mixedPtr.pointerPlus(bss$offset));
/*     */         
/* 217 */         if (!mixedPtr.pointerPlus(bss$offset).isNull()) {
/*     */           
/* 219 */           mixedPtr.pointerPlus(bss$offset).memset(0, 107872);
/* 220 */           MixedPtr mixedPtr1 = mixedPtr; j = bss$offset;
/* 221 */           graphics__.Rf_GInit(mixedPtr1.pointerPlus(j));
/*     */           
/* 223 */           double d4 = dev.getDouble(140); mixedPtr1.setDouble(j + 376, d4);
/* 224 */           int i14 = dev.getInt(148); mixedPtr1.setInt(j + 76, i14); int i13 = mixedPtr1.getInt(j + 76); mixedPtr1.setInt(j + 44, i13);
/* 225 */           int i12 = dev.getInt(152); mixedPtr1.setInt(j + 20, i12);
/* 226 */           int i11 = dev.getInt(160); mixedPtr1.setInt(j + 284, i11);
/* 227 */           int i10 = dev.getInt(156); mixedPtr1.setInt(j + 312, i10);
/* 228 */           double d3 = dev.getDouble(164); mixedPtr1.setDouble(j + 288, d3);
/*     */           
/* 230 */           MixedPtr mixedPtr2 = mixedPtr; int i9 = bss$offset + 35956; graphics__.Rf_copyGPar(mixedPtr1.pointerPlus(j), mixedPtr2.pointerPlus(i9));
/* 231 */           graphics__.Rf_GReset(dd);
/*     */ 
/*     */ 
/*     */           
/* 235 */           mixedPtr.setInt(bss$offset + 107868, 0);
/*     */           
/* 237 */           result = Rinternals.R_BlankString;
/*     */           break;
/*     */         } 
/*     */         return result;
/*     */       
/*     */       case 3:
/* 243 */         curdd = baseDevices__.GEcurrentDevice();
/* 244 */         baseRegisterIndex$9 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$9 * 4).getPointer(); bss$offset = 0;
/* 245 */         baseRegisterIndex$10 = Context.get__graphics$baseRegisterIndex()[0]; bss2 = curdd.getPointer(28 + baseRegisterIndex$10 * 4).getPointer();
/* 246 */         ptr13 = bss2; i8 = 0 + 71912; ptr12 = ptr2; i7 = bss$offset + 71912; graphics__.Rf_copyGPar(ptr12.pointerPlus(i7), ptr13.pointerPlus(i8));
/* 247 */         restoredpSaved(curdd);
/* 248 */         ptr11 = bss2; i6 = 0 + 35956; graphics__.Rf_copyGPar(bss2, ptr11.pointerPlus(i6));
/* 249 */         graphics__.Rf_GReset(curdd);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 254 */         baseRegisterIndex$11 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$11 * 4).getPointer(); bss$offset = 0;
/* 255 */         ptr10 = ptr2; i5 = bss$offset + 71912; ptr9 = ptr2; i4 = bss$offset; graphics__.Rf_copyGPar(ptr9.pointerPlus(i4), ptr10.pointerPlus(i5));
/*     */         break;
/*     */       
/*     */       case 6:
/* 259 */         baseRegisterIndex$12 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$12 * 4).getPointer(); bss$offset = 0;
/* 260 */         restoredpSaved(dd);
/* 261 */         ptr8 = ptr2; i3 = bss$offset + 35956; ptr7 = ptr2; i2 = bss$offset; graphics__.Rf_copyGPar(ptr7.pointerPlus(i2), ptr8.pointerPlus(i3));
/* 262 */         graphics__.Rf_GReset(dd);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 268 */         baseRegisterIndex$13 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$13 * 4).getPointer(); bss$offset = 0;
/*     */ 
/*     */         
/* 271 */         result = Rinternals.Rf_allocVector(24, 35956); Rinternals.Rf_protect(result);
/* 272 */         bytePtr = Rinternals.RAW(result); ptr6 = ptr2; i1 = bss$offset + 71912; graphics__.Rf_copyGPar(ptr6.pointerPlus(i1), (Ptr)bytePtr);
/* 273 */         pkgName = Rinternals.Rf_mkString((Ptr)new BytePtr("graphics\000".getBytes(), 0)); Rinternals.Rf_protect(pkgName);
/* 274 */         sEXP2 = Rinternals.Rf_install(new BytePtr("pkgName\000".getBytes(), 0)); Rinternals.Rf_setAttrib(result, sEXP2, pkgName);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 281 */         nState = Rinternals.LENGTH(data) + -1;
/*     */         
/* 283 */         graphicsState = Rinternals.R_NilValue; Rinternals.Rf_protect(graphicsState);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 289 */         sEXP1 = Rinternals.Rf_install(new BytePtr("engineVersion\000".getBytes(), 0)); snapshotEngineVersion = Rinternals.Rf_getAttrib(data, sEXP1); Rinternals.Rf_protect(snapshotEngineVersion);
/*     */         
/* 291 */         if (Rinternals.TYPEOF(snapshotEngineVersion) != 0) {
/*     */ 
/*     */           
/* 294 */           for (i = 0; i < nState; i++) {
/* 295 */             int i9 = i + 1; state = Rinternals.VECTOR_ELT(data, i9);
/* 296 */             SEXP sEXP = Rinternals.Rf_install(new BytePtr("pkgName\000".getBytes(), 0)); if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(Rinternals.Rf_getAttrib(state, sEXP), 0)), (Ptr)new BytePtr("graphics\000".getBytes(), 0)) == 0)
/*     */             {
/*     */ 
/*     */               
/* 300 */               graphicsState = state; } 
/*     */           } 
/*     */         } else {
/*     */           graphicsState = Rinternals.VECTOR_ELT(data, 1);
/* 304 */         }  if (Rinternals.TYPEOF(graphicsState) == 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 310 */         if (Rinternals.LENGTH(graphicsState) != 35956) {
/* 311 */           Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("Incompatible graphics state\000".getBytes(), 0)), new Object[0]);
/*     */         }
/* 313 */         baseRegisterIndex$14 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$14 * 4).getPointer(); bss$offset = 0;
/* 314 */         ptr5 = ptr2; n = bss$offset + 71912; graphics__.Rf_copyGPar((Ptr)Rinternals.RAW(graphicsState), ptr5.pointerPlus(n));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 322 */         restoredpSaved(dd);
/* 323 */         ptr4 = ptr2; m = bss$offset + 35956; ptr3 = ptr2; k = bss$offset; graphics__.Rf_copyGPar(ptr3.pointerPlus(k), ptr4.pointerPlus(m));
/* 324 */         graphics__.Rf_GReset(dd);
/*     */ 
/*     */ 
/*     */         
/* 328 */         ptr2.setInt(bss$offset + 107868, 0);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 337 */         baseRegisterIndex$15 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$15 * 4).getPointer(); bss$offset = 0;
/* 338 */         if (ptr2.getInt(bss$offset + 107868) != 0 && (
/* 339 */           ptr2.getInt(bss$offset + 35956) != 1 || ptr2.getInt(bss$offset + 35956 + 4) == 0)) {
/*     */           iftmp$16 = 0;
/*     */         } else {
/*     */           iftmp$16 = 1;
/*     */         }  result = Rinternals.Rf_ScalarLogical(iftmp$16);
/*     */         break;
/*     */       case 8:
/* 346 */         baseRegisterIndex$17 = Context.get__graphics$baseRegisterIndex()[0]; ptr2 = dd.getPointer(28 + baseRegisterIndex$17 * 4).getPointer(); bss$offset = 0;
/* 347 */         ddp = ptr2; ddp$offset = bss$offset;
/* 348 */         ddpSaved = ptr2; ddpSaved$offset = bss$offset + 71912;
/* 349 */         if (Rinternals.TYPEOF(data) != 14 || Rinternals.LENGTH(data) != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 355 */           Error.Rf_error(new BytePtr("event 'GE_ScalePS' requires a single numeric value\000".getBytes(), 0), new Object[0]); break;
/*     */         }  rf = Rinternals2.REAL(data).getDouble(); d2 = ddp.getDouble(ddp$offset + 35948) * rf; ddp.setDouble(ddp$offset + 35948, d2); d1 = ddpSaved.getDouble(ddpSaved$offset + 35948) * rf; ddpSaved.setDouble(ddpSaved$offset + 35948, d1);
/*     */         break;
/*     */     } 
/* 359 */     return result; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerBase() {
/*     */     // Byte code:
/*     */     //   0: ldc
/*     */     //   2: new org/renjin/gcc/runtime/IntPtr
/*     */     //   5: dup
/*     */     //   6: invokestatic get__graphics$baseRegisterIndex : ()[I
/*     */     //   9: iconst_0
/*     */     //   10: invokespecial <init> : ([II)V
/*     */     //   13: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   16: invokestatic GEregisterSystem : (Ljava/lang/invoke/MethodHandle;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   19: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #366	-> 0
/*     */     //   #367	-> 19
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregisterBase() {
/* 371 */     baseEngine__.GEunregisterSystem(Context.get__graphics$baseRegisterIndex()[0]);
/* 372 */     Context.get__graphics$baseRegisterIndex()[0] = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP RunregisterBase() {
/* 377 */     unregisterBase();
/* 378 */     return Rinternals.R_NilValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr Rf_gpptr(Ptr dd) {
/* 385 */     if (Context.get__graphics$baseRegisterIndex()[0] == -1)
/* 386 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("the base graphics system is not registered\000".getBytes(), 0)), new Object[0]); 
/* 387 */     baseRegisterIndex$5 = Context.get__graphics$baseRegisterIndex()[0];
/* 388 */     Ptr ptr = dd.getPointer(28 + baseRegisterIndex$5 * 4).getPointer(); int i = 0 + 35956; return ptr.pointerPlus(i);
/*     */   }
/*     */   
/*     */   public static Ptr Rf_dpptr(Ptr dd) {
/* 392 */     if (Context.get__graphics$baseRegisterIndex()[0] == -1)
/* 393 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("the base graphics system is not registered\000".getBytes(), 0)), new Object[0]); 
/* 394 */     baseRegisterIndex$3 = Context.get__graphics$baseRegisterIndex()[0]; return dd.getPointer(28 + baseRegisterIndex$3 * 4).getPointer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_setBaseDevice(int val, Ptr dd) {
/* 400 */     if (Context.get__graphics$baseRegisterIndex()[0] == -1)
/* 401 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("the base graphics system is not registered\000".getBytes(), 0)), new Object[0]); 
/* 402 */     baseRegisterIndex$1 = Context.get__graphics$baseRegisterIndex()[0]; dd.getPointer(28 + baseRegisterIndex$1 * 4).getPointer()
/* 403 */       .setInt(0 + 107868, val);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/base__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */