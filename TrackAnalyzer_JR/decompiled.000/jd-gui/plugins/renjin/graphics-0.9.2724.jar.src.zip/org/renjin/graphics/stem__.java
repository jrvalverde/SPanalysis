/*     */ package org.renjin.graphics;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.GetText;
/*     */ import org.renjin.gnur.api.Print;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class stem__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static void stem_print(int close, int dist, int ndigits) {
/*  44 */     if (Integer.compareUnsigned(close + 9, 18) > 0 || dist >= 0) {
/*     */ 
/*     */       
/*  47 */       int i = close / 10; Print.Rprintf(new BytePtr("  %*d | \000".getBytes(), 0), new Object[] { Integer.valueOf(ndigits), Integer.valueOf(i) });
/*     */       return;
/*     */     } 
/*     */     Print.Rprintf(new BytePtr("  %*s | \000".getBytes(), 0), new Object[] { Integer.valueOf(ndigits), new BytePtr("-0\000".getBytes(), 0) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int stem_leaf(Ptr x, int n, double scale, int width, double atom) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore #8
/*     */     //   3: iconst_0
/*     */     //   4: istore #13
/*     */     //   6: iconst_0
/*     */     //   7: istore #14
/*     */     //   9: dconst_0
/*     */     //   10: dstore #16
/*     */     //   12: dconst_0
/*     */     //   13: dstore #18
/*     */     //   15: dconst_0
/*     */     //   16: dstore #20
/*     */     //   18: dconst_0
/*     */     //   19: dstore #24
/*     */     //   21: dconst_0
/*     */     //   22: dstore #26
/*     */     //   24: aload_0
/*     */     //   25: iload_1
/*     */     //   26: invokestatic R_rsort : (Lorg/renjin/gcc/runtime/Ptr;I)V
/*     */     //   29: iload_1
/*     */     //   30: iconst_1
/*     */     //   31: if_icmple -> 37
/*     */     //   34: goto -> 43
/*     */     //   37: iconst_0
/*     */     //   38: istore #218
/*     */     //   40: goto -> 1366
/*     */     //   43: new org/renjin/gcc/runtime/BytePtr
/*     */     //   46: dup
/*     */     //   47: ldc '\\n '
/*     */     //   49: invokevirtual getBytes : ()[B
/*     */     //   52: iconst_0
/*     */     //   53: invokespecial <init> : ([BI)V
/*     */     //   56: iconst_0
/*     */     //   57: anewarray java/lang/Object
/*     */     //   60: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   63: iload_1
/*     */     //   64: iconst_m1
/*     */     //   65: iadd
/*     */     //   66: bipush #8
/*     */     //   68: imul
/*     */     //   69: istore #215
/*     */     //   71: aload_0
/*     */     //   72: astore #213
/*     */     //   74: iload #215
/*     */     //   76: istore #214
/*     */     //   78: aload #213
/*     */     //   80: iload #214
/*     */     //   82: invokeinterface getDouble : (I)D
/*     */     //   87: dstore #211
/*     */     //   89: aload_0
/*     */     //   90: invokeinterface getDouble : ()D
/*     */     //   95: dstore #209
/*     */     //   97: dload #211
/*     */     //   99: dload #209
/*     */     //   101: dcmpl
/*     */     //   102: ifgt -> 108
/*     */     //   105: goto -> 440
/*     */     //   108: iload_1
/*     */     //   109: iconst_m1
/*     */     //   110: iadd
/*     */     //   111: bipush #8
/*     */     //   113: imul
/*     */     //   114: istore #206
/*     */     //   116: aload_0
/*     */     //   117: astore #204
/*     */     //   119: iload #206
/*     */     //   121: istore #205
/*     */     //   123: aload #204
/*     */     //   125: iload #205
/*     */     //   127: invokeinterface getDouble : (I)D
/*     */     //   132: dstore #202
/*     */     //   134: aload_0
/*     */     //   135: invokeinterface getDouble : ()D
/*     */     //   140: dstore #200
/*     */     //   142: dload #202
/*     */     //   144: dload #200
/*     */     //   146: dsub
/*     */     //   147: dload_2
/*     */     //   148: ddiv
/*     */     //   149: dload #5
/*     */     //   151: dadd
/*     */     //   152: dstore #28
/*     */     //   154: dload #28
/*     */     //   156: invokestatic log10 : (D)D
/*     */     //   159: invokestatic floor : (D)D
/*     */     //   162: dstore #192
/*     */     //   164: dconst_1
/*     */     //   165: dload #192
/*     */     //   167: dsub
/*     */     //   168: d2i
/*     */     //   169: istore #189
/*     */     //   171: ldc2_w 10.0
/*     */     //   174: iload #189
/*     */     //   176: invokestatic R_pow_di : (DI)D
/*     */     //   179: dstore #26
/*     */     //   181: dload #28
/*     */     //   183: dload #26
/*     */     //   185: dmul
/*     */     //   186: ldc2_w 25.0
/*     */     //   189: ddiv
/*     */     //   190: d2i
/*     */     //   191: istore #184
/*     */     //   193: iconst_0
/*     */     //   194: iload #184
/*     */     //   196: invokestatic Rf_imax2 : (II)I
/*     */     //   199: istore #183
/*     */     //   201: iconst_2
/*     */     //   202: iload #183
/*     */     //   204: invokestatic Rf_imin2 : (II)I
/*     */     //   207: iconst_3
/*     */     //   208: imul
/*     */     //   209: iconst_2
/*     */     //   210: iadd
/*     */     //   211: istore #181
/*     */     //   213: iload_1
/*     */     //   214: bipush #50
/*     */     //   216: iadd
/*     */     //   217: istore #180
/*     */     //   219: sipush #150
/*     */     //   222: iload #180
/*     */     //   224: idiv
/*     */     //   225: istore #179
/*     */     //   227: iload #181
/*     */     //   229: iload #179
/*     */     //   231: isub
/*     */     //   232: istore #14
/*     */     //   234: iload #14
/*     */     //   236: iconst_m1
/*     */     //   237: iadd
/*     */     //   238: istore #178
/*     */     //   240: iload #14
/*     */     //   242: bipush #-2
/*     */     //   244: iadd
/*     */     //   245: istore #177
/*     */     //   247: iload #178
/*     */     //   249: iload #177
/*     */     //   251: imul
/*     */     //   252: istore #176
/*     */     //   254: iload #14
/*     */     //   256: bipush #-5
/*     */     //   258: iadd
/*     */     //   259: istore #175
/*     */     //   261: iload #176
/*     */     //   263: iload #175
/*     */     //   265: imul
/*     */     //   266: ifeq -> 272
/*     */     //   269: goto -> 280
/*     */     //   272: dload #26
/*     */     //   274: ldc2_w 10.0
/*     */     //   277: dmul
/*     */     //   278: dstore #26
/*     */     //   280: aload_0
/*     */     //   281: invokeinterface getDouble : ()D
/*     */     //   286: invokestatic abs : (D)D
/*     */     //   289: dstore #24
/*     */     //   291: iload_1
/*     */     //   292: iconst_m1
/*     */     //   293: iadd
/*     */     //   294: bipush #8
/*     */     //   296: imul
/*     */     //   297: istore #169
/*     */     //   299: aload_0
/*     */     //   300: astore #167
/*     */     //   302: iload #169
/*     */     //   304: istore #168
/*     */     //   306: aload #167
/*     */     //   308: iload #168
/*     */     //   310: invokeinterface getDouble : (I)D
/*     */     //   315: invokestatic abs : (D)D
/*     */     //   318: dstore #22
/*     */     //   320: dload #22
/*     */     //   322: dload #24
/*     */     //   324: dcmpl
/*     */     //   325: ifgt -> 331
/*     */     //   328: goto -> 335
/*     */     //   331: dload #22
/*     */     //   333: dstore #24
/*     */     //   335: goto -> 346
/*     */     //   338: dload #26
/*     */     //   340: ldc2_w 10.0
/*     */     //   343: ddiv
/*     */     //   344: dstore #26
/*     */     //   346: dload #24
/*     */     //   348: dload #26
/*     */     //   350: dmul
/*     */     //   351: ldc2_w 2.147483647E9
/*     */     //   354: dcmpl
/*     */     //   355: ifgt -> 338
/*     */     //   358: goto -> 361
/*     */     //   361: iload #14
/*     */     //   363: bipush #-4
/*     */     //   365: iadd
/*     */     //   366: iload #14
/*     */     //   368: imul
/*     */     //   369: istore #161
/*     */     //   371: iload #14
/*     */     //   373: bipush #-8
/*     */     //   375: iadd
/*     */     //   376: istore #160
/*     */     //   378: iload #161
/*     */     //   380: iload #160
/*     */     //   382: imul
/*     */     //   383: ifeq -> 389
/*     */     //   386: goto -> 394
/*     */     //   389: ldc2_w 5.0
/*     */     //   392: dstore #20
/*     */     //   394: iload #14
/*     */     //   396: iconst_m1
/*     */     //   397: iadd
/*     */     //   398: istore #158
/*     */     //   400: iload #14
/*     */     //   402: bipush #-5
/*     */     //   404: iadd
/*     */     //   405: istore #157
/*     */     //   407: iload #158
/*     */     //   409: iload #157
/*     */     //   411: imul
/*     */     //   412: istore #156
/*     */     //   414: iload #14
/*     */     //   416: bipush #-6
/*     */     //   418: iadd
/*     */     //   419: istore #155
/*     */     //   421: iload #156
/*     */     //   423: iload #155
/*     */     //   425: imul
/*     */     //   426: ifeq -> 432
/*     */     //   429: goto -> 486
/*     */     //   432: ldc2_w 20.0
/*     */     //   435: dstore #20
/*     */     //   437: goto -> 486
/*     */     //   440: aload_0
/*     */     //   441: invokeinterface getDouble : ()D
/*     */     //   446: invokestatic abs : (D)D
/*     */     //   449: dload_2
/*     */     //   450: ddiv
/*     */     //   451: dload #5
/*     */     //   453: dadd
/*     */     //   454: dstore #28
/*     */     //   456: dload #28
/*     */     //   458: invokestatic log10 : (D)D
/*     */     //   461: invokestatic floor : (D)D
/*     */     //   464: dstore #144
/*     */     //   466: dconst_1
/*     */     //   467: dload #144
/*     */     //   469: dsub
/*     */     //   470: d2i
/*     */     //   471: istore #141
/*     */     //   473: ldc2_w 10.0
/*     */     //   476: iload #141
/*     */     //   478: invokestatic R_pow_di : (DI)D
/*     */     //   481: dstore #26
/*     */     //   483: iconst_2
/*     */     //   484: istore #14
/*     */     //   486: ldc2_w 10.0
/*     */     //   489: dstore #20
/*     */     //   491: iload #14
/*     */     //   493: bipush #-4
/*     */     //   495: iadd
/*     */     //   496: iload #14
/*     */     //   498: imul
/*     */     //   499: istore #139
/*     */     //   501: iload #14
/*     */     //   503: bipush #-8
/*     */     //   505: iadd
/*     */     //   506: istore #138
/*     */     //   508: iload #139
/*     */     //   510: iload #138
/*     */     //   512: imul
/*     */     //   513: ifeq -> 519
/*     */     //   516: goto -> 524
/*     */     //   519: ldc2_w 5.0
/*     */     //   522: dstore #20
/*     */     //   524: iload #14
/*     */     //   526: iconst_m1
/*     */     //   527: iadd
/*     */     //   528: istore #136
/*     */     //   530: iload #14
/*     */     //   532: bipush #-5
/*     */     //   534: iadd
/*     */     //   535: istore #135
/*     */     //   537: iload #136
/*     */     //   539: iload #135
/*     */     //   541: imul
/*     */     //   542: istore #134
/*     */     //   544: iload #14
/*     */     //   546: bipush #-6
/*     */     //   548: iadd
/*     */     //   549: istore #133
/*     */     //   551: iload #134
/*     */     //   553: iload #133
/*     */     //   555: imul
/*     */     //   556: ifeq -> 562
/*     */     //   559: goto -> 567
/*     */     //   562: ldc2_w 20.0
/*     */     //   565: dstore #20
/*     */     //   567: aload_0
/*     */     //   568: invokeinterface getDouble : ()D
/*     */     //   573: dload #26
/*     */     //   575: dmul
/*     */     //   576: dload #20
/*     */     //   578: ddiv
/*     */     //   579: invokestatic floor : (D)D
/*     */     //   582: dload #20
/*     */     //   584: dmul
/*     */     //   585: dstore #18
/*     */     //   587: iload_1
/*     */     //   588: iconst_m1
/*     */     //   589: iadd
/*     */     //   590: bipush #8
/*     */     //   592: imul
/*     */     //   593: istore #121
/*     */     //   595: aload_0
/*     */     //   596: astore #119
/*     */     //   598: iload #121
/*     */     //   600: istore #120
/*     */     //   602: aload #119
/*     */     //   604: iload #120
/*     */     //   606: invokeinterface getDouble : (I)D
/*     */     //   611: dload #26
/*     */     //   613: dmul
/*     */     //   614: dload #20
/*     */     //   616: ddiv
/*     */     //   617: invokestatic floor : (D)D
/*     */     //   620: dload #20
/*     */     //   622: dmul
/*     */     //   623: dstore #16
/*     */     //   625: dload #18
/*     */     //   627: dconst_0
/*     */     //   628: dcmpg
/*     */     //   629: iflt -> 635
/*     */     //   632: goto -> 652
/*     */     //   635: dload #18
/*     */     //   637: dneg
/*     */     //   638: invokestatic log10 : (D)D
/*     */     //   641: invokestatic floor : (D)D
/*     */     //   644: d2i
/*     */     //   645: iconst_1
/*     */     //   646: iadd
/*     */     //   647: istore #110
/*     */     //   649: goto -> 655
/*     */     //   652: iconst_0
/*     */     //   653: istore #110
/*     */     //   655: iload #110
/*     */     //   657: istore #10
/*     */     //   659: dload #16
/*     */     //   661: dconst_0
/*     */     //   662: dcmpl
/*     */     //   663: ifgt -> 669
/*     */     //   666: goto -> 683
/*     */     //   669: dload #16
/*     */     //   671: invokestatic log10 : (D)D
/*     */     //   674: invokestatic floor : (D)D
/*     */     //   677: d2i
/*     */     //   678: istore #102
/*     */     //   680: goto -> 686
/*     */     //   683: iconst_0
/*     */     //   684: istore #102
/*     */     //   686: iload #102
/*     */     //   688: istore #9
/*     */     //   690: iload #10
/*     */     //   692: iload #9
/*     */     //   694: invokestatic max : (II)I
/*     */     //   697: istore #8
/*     */     //   699: dload #18
/*     */     //   701: dconst_0
/*     */     //   702: dcmpg
/*     */     //   703: iflt -> 709
/*     */     //   706: goto -> 737
/*     */     //   709: aload_0
/*     */     //   710: invokeinterface getDouble : ()D
/*     */     //   715: dload #26
/*     */     //   717: dmul
/*     */     //   718: invokestatic floor : (D)D
/*     */     //   721: dload #18
/*     */     //   723: dcmpl
/*     */     //   724: ifeq -> 730
/*     */     //   727: goto -> 737
/*     */     //   730: dload #18
/*     */     //   732: dload #20
/*     */     //   734: dsub
/*     */     //   735: dstore #18
/*     */     //   737: dload #18
/*     */     //   739: dload #20
/*     */     //   741: dadd
/*     */     //   742: dstore #16
/*     */     //   744: aload_0
/*     */     //   745: invokeinterface getDouble : ()D
/*     */     //   750: dload #26
/*     */     //   752: dmul
/*     */     //   753: ldc2_w 0.5
/*     */     //   756: dadd
/*     */     //   757: invokestatic floor : (D)D
/*     */     //   760: dload #16
/*     */     //   762: dcmpl
/*     */     //   763: ifgt -> 769
/*     */     //   766: goto -> 780
/*     */     //   769: dload #16
/*     */     //   771: dstore #18
/*     */     //   773: dload #18
/*     */     //   775: dload #20
/*     */     //   777: dadd
/*     */     //   778: dstore #16
/*     */     //   780: dload #26
/*     */     //   782: invokestatic log10 : (D)D
/*     */     //   785: ldc2_w 0.5
/*     */     //   788: dadd
/*     */     //   789: invokestatic floor : (D)D
/*     */     //   792: d2i
/*     */     //   793: istore #77
/*     */     //   795: iconst_1
/*     */     //   796: iload #77
/*     */     //   798: isub
/*     */     //   799: istore #7
/*     */     //   801: new org/renjin/gcc/runtime/BytePtr
/*     */     //   804: dup
/*     */     //   805: ldc '  The decimal point is  '
/*     */     //   807: invokevirtual getBytes : ()[B
/*     */     //   810: iconst_0
/*     */     //   811: invokespecial <init> : ([BI)V
/*     */     //   814: iconst_0
/*     */     //   815: anewarray java/lang/Object
/*     */     //   818: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   821: iload #7
/*     */     //   823: ifeq -> 829
/*     */     //   826: goto -> 852
/*     */     //   829: new org/renjin/gcc/runtime/BytePtr
/*     */     //   832: dup
/*     */     //   833: ldc 'at the |\\n\\n '
/*     */     //   835: invokevirtual getBytes : ()[B
/*     */     //   838: iconst_0
/*     */     //   839: invokespecial <init> : ([BI)V
/*     */     //   842: iconst_0
/*     */     //   843: anewarray java/lang/Object
/*     */     //   846: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   849: goto -> 947
/*     */     //   852: iload #7
/*     */     //   854: ifgt -> 860
/*     */     //   857: goto -> 881
/*     */     //   860: new org/renjin/gcc/runtime/BytePtr
/*     */     //   863: dup
/*     */     //   864: ldc 'right '
/*     */     //   866: invokevirtual getBytes : ()[B
/*     */     //   869: iconst_0
/*     */     //   870: invokespecial <init> : ([BI)V
/*     */     //   873: astore #75
/*     */     //   875: iconst_0
/*     */     //   876: istore #76
/*     */     //   878: goto -> 899
/*     */     //   881: new org/renjin/gcc/runtime/BytePtr
/*     */     //   884: dup
/*     */     //   885: ldc 'left '
/*     */     //   887: invokevirtual getBytes : ()[B
/*     */     //   890: iconst_0
/*     */     //   891: invokespecial <init> : ([BI)V
/*     */     //   894: astore #75
/*     */     //   896: iconst_0
/*     */     //   897: istore #76
/*     */     //   899: iload #7
/*     */     //   901: invokestatic abs : (I)I
/*     */     //   904: istore #74
/*     */     //   906: new org/renjin/gcc/runtime/BytePtr
/*     */     //   909: dup
/*     */     //   910: ldc_w '%d digit(s) to the %s of the |\\n\\n '
/*     */     //   913: invokevirtual getBytes : ()[B
/*     */     //   916: iconst_0
/*     */     //   917: invokespecial <init> : ([BI)V
/*     */     //   920: iconst_2
/*     */     //   921: anewarray java/lang/Object
/*     */     //   924: dup
/*     */     //   925: iconst_0
/*     */     //   926: iload #74
/*     */     //   928: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   931: aastore
/*     */     //   932: dup
/*     */     //   933: iconst_1
/*     */     //   934: aload #75
/*     */     //   936: iload #76
/*     */     //   938: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   943: aastore
/*     */     //   944: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   947: iconst_0
/*     */     //   948: istore #13
/*     */     //   950: dload #18
/*     */     //   952: dconst_0
/*     */     //   953: dcmpg
/*     */     //   954: iflt -> 960
/*     */     //   957: goto -> 978
/*     */     //   960: dload #18
/*     */     //   962: d2i
/*     */     //   963: istore #73
/*     */     //   965: dload #16
/*     */     //   967: d2i
/*     */     //   968: iload #73
/*     */     //   970: iload #8
/*     */     //   972: invokestatic stem_print : (III)V
/*     */     //   975: goto -> 993
/*     */     //   978: dload #16
/*     */     //   980: d2i
/*     */     //   981: istore #71
/*     */     //   983: dload #18
/*     */     //   985: d2i
/*     */     //   986: iload #71
/*     */     //   988: iload #8
/*     */     //   990: invokestatic stem_print : (III)V
/*     */     //   993: iconst_0
/*     */     //   994: istore #12
/*     */     //   996: iload #13
/*     */     //   998: bipush #8
/*     */     //   1000: imul
/*     */     //   1001: istore #68
/*     */     //   1003: aload_0
/*     */     //   1004: astore #66
/*     */     //   1006: iload #68
/*     */     //   1008: istore #67
/*     */     //   1010: aload #66
/*     */     //   1012: iload #67
/*     */     //   1014: invokeinterface getDouble : (I)D
/*     */     //   1019: dconst_0
/*     */     //   1020: dcmpg
/*     */     //   1021: iflt -> 1027
/*     */     //   1024: goto -> 1063
/*     */     //   1027: iload #13
/*     */     //   1029: bipush #8
/*     */     //   1031: imul
/*     */     //   1032: istore #62
/*     */     //   1034: aload_0
/*     */     //   1035: astore #60
/*     */     //   1037: iload #62
/*     */     //   1039: istore #61
/*     */     //   1041: aload #60
/*     */     //   1043: iload #61
/*     */     //   1045: invokeinterface getDouble : (I)D
/*     */     //   1050: dload #26
/*     */     //   1052: dmul
/*     */     //   1053: ldc2_w 0.5
/*     */     //   1056: dsub
/*     */     //   1057: d2i
/*     */     //   1058: istore #11
/*     */     //   1060: goto -> 1096
/*     */     //   1063: iload #13
/*     */     //   1065: bipush #8
/*     */     //   1067: imul
/*     */     //   1068: istore #52
/*     */     //   1070: aload_0
/*     */     //   1071: astore #50
/*     */     //   1073: iload #52
/*     */     //   1075: istore #51
/*     */     //   1077: aload #50
/*     */     //   1079: iload #51
/*     */     //   1081: invokeinterface getDouble : (I)D
/*     */     //   1086: dload #26
/*     */     //   1088: dmul
/*     */     //   1089: ldc2_w 0.5
/*     */     //   1092: dadd
/*     */     //   1093: d2i
/*     */     //   1094: istore #11
/*     */     //   1096: dload #16
/*     */     //   1098: dconst_0
/*     */     //   1099: dcmpl
/*     */     //   1100: ifeq -> 1106
/*     */     //   1103: goto -> 1137
/*     */     //   1106: iload #13
/*     */     //   1108: bipush #8
/*     */     //   1110: imul
/*     */     //   1111: istore #42
/*     */     //   1113: aload_0
/*     */     //   1114: astore #40
/*     */     //   1116: iload #42
/*     */     //   1118: istore #41
/*     */     //   1120: aload #40
/*     */     //   1122: iload #41
/*     */     //   1124: invokeinterface getDouble : (I)D
/*     */     //   1129: dconst_0
/*     */     //   1130: dcmpl
/*     */     //   1131: ifge -> 1248
/*     */     //   1134: goto -> 1137
/*     */     //   1137: dload #18
/*     */     //   1139: dconst_0
/*     */     //   1140: dcmpg
/*     */     //   1141: iflt -> 1147
/*     */     //   1144: goto -> 1159
/*     */     //   1147: iload #11
/*     */     //   1149: i2d
/*     */     //   1150: dload #16
/*     */     //   1152: dcmpl
/*     */     //   1153: ifgt -> 1248
/*     */     //   1156: goto -> 1159
/*     */     //   1159: dload #18
/*     */     //   1161: dconst_0
/*     */     //   1162: dcmpl
/*     */     //   1163: ifge -> 1169
/*     */     //   1166: goto -> 1181
/*     */     //   1169: iload #11
/*     */     //   1171: i2d
/*     */     //   1172: dload #16
/*     */     //   1174: dcmpl
/*     */     //   1175: ifge -> 1248
/*     */     //   1178: goto -> 1181
/*     */     //   1181: iinc #12, 1
/*     */     //   1184: iload #4
/*     */     //   1186: bipush #-12
/*     */     //   1188: iadd
/*     */     //   1189: iload #12
/*     */     //   1191: if_icmpge -> 1197
/*     */     //   1194: goto -> 1236
/*     */     //   1197: iload #11
/*     */     //   1199: invokestatic abs : (I)I
/*     */     //   1202: bipush #10
/*     */     //   1204: irem
/*     */     //   1205: istore #31
/*     */     //   1207: new org/renjin/gcc/runtime/BytePtr
/*     */     //   1210: dup
/*     */     //   1211: ldc_w '%1d '
/*     */     //   1214: invokevirtual getBytes : ()[B
/*     */     //   1217: iconst_0
/*     */     //   1218: invokespecial <init> : ([BI)V
/*     */     //   1221: iconst_1
/*     */     //   1222: anewarray java/lang/Object
/*     */     //   1225: dup
/*     */     //   1226: iconst_0
/*     */     //   1227: iload #31
/*     */     //   1229: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   1232: aastore
/*     */     //   1233: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   1236: iinc #13, 1
/*     */     //   1239: iload #13
/*     */     //   1241: iload_1
/*     */     //   1242: if_icmplt -> 996
/*     */     //   1245: goto -> 1248
/*     */     //   1248: iload #12
/*     */     //   1250: iload #4
/*     */     //   1252: if_icmpgt -> 1258
/*     */     //   1255: goto -> 1294
/*     */     //   1258: iload #12
/*     */     //   1260: iload #4
/*     */     //   1262: isub
/*     */     //   1263: istore #30
/*     */     //   1265: new org/renjin/gcc/runtime/BytePtr
/*     */     //   1268: dup
/*     */     //   1269: ldc_w '+%d '
/*     */     //   1272: invokevirtual getBytes : ()[B
/*     */     //   1275: iconst_0
/*     */     //   1276: invokespecial <init> : ([BI)V
/*     */     //   1279: iconst_1
/*     */     //   1280: anewarray java/lang/Object
/*     */     //   1283: dup
/*     */     //   1284: iconst_0
/*     */     //   1285: iload #30
/*     */     //   1287: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   1290: aastore
/*     */     //   1291: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   1294: new org/renjin/gcc/runtime/BytePtr
/*     */     //   1297: dup
/*     */     //   1298: ldc '\\n '
/*     */     //   1300: invokevirtual getBytes : ()[B
/*     */     //   1303: iconst_0
/*     */     //   1304: invokespecial <init> : ([BI)V
/*     */     //   1307: iconst_0
/*     */     //   1308: anewarray java/lang/Object
/*     */     //   1311: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   1314: iload #13
/*     */     //   1316: iload_1
/*     */     //   1317: if_icmpge -> 1323
/*     */     //   1320: goto -> 1326
/*     */     //   1323: goto -> 1343
/*     */     //   1326: dload #16
/*     */     //   1328: dload #20
/*     */     //   1330: dadd
/*     */     //   1331: dstore #16
/*     */     //   1333: dload #18
/*     */     //   1335: dload #20
/*     */     //   1337: dadd
/*     */     //   1338: dstore #18
/*     */     //   1340: goto -> 950
/*     */     //   1343: new org/renjin/gcc/runtime/BytePtr
/*     */     //   1346: dup
/*     */     //   1347: ldc '\\n '
/*     */     //   1349: invokevirtual getBytes : ()[B
/*     */     //   1352: iconst_0
/*     */     //   1353: invokespecial <init> : ([BI)V
/*     */     //   1356: iconst_0
/*     */     //   1357: anewarray java/lang/Object
/*     */     //   1360: invokestatic Rprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*     */     //   1363: iconst_1
/*     */     //   1364: istore #218
/*     */     //   1366: iload #218
/*     */     //   1368: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #58	-> 24
/*     */     //   #60	-> 29
/*     */     //   #61	-> 37
/*     */     //   #63	-> 43
/*     */     //   #64	-> 63
/*     */     //   #65	-> 108
/*     */     //   #67	-> 154
/*     */     //   #68	-> 181
/*     */     //   #69	-> 207
/*     */     //   #70	-> 234
/*     */     //   #71	-> 272
/*     */     //   #73	-> 280
/*     */     //   #74	-> 320
/*     */     //   #74	-> 331
/*     */     //   #75	-> 338
/*     */     //   #75	-> 346
/*     */     //   #76	-> 361
/*     */     //   #76	-> 389
/*     */     //   #77	-> 394
/*     */     //   #77	-> 432
/*     */     //   #79	-> 440
/*     */     //   #80	-> 456
/*     */     //   #81	-> 483
/*     */     //   #84	-> 486
/*     */     //   #85	-> 491
/*     */     //   #85	-> 519
/*     */     //   #86	-> 524
/*     */     //   #86	-> 562
/*     */     //   #91	-> 567
/*     */     //   #92	-> 587
/*     */     //   #93	-> 625
/*     */     //   #93	-> 635
/*     */     //   #93	-> 652
/*     */     //   #93	-> 655
/*     */     //   #94	-> 659
/*     */     //   #94	-> 669
/*     */     //   #94	-> 683
/*     */     //   #94	-> 686
/*     */     //   #95	-> 690
/*     */     //   #99	-> 699
/*     */     //   #99	-> 709
/*     */     //   #99	-> 730
/*     */     //   #100	-> 737
/*     */     //   #101	-> 744
/*     */     //   #102	-> 769
/*     */     //   #103	-> 773
/*     */     //   #108	-> 780
/*     */     //   #110	-> 801
/*     */     //   #111	-> 821
/*     */     //   #112	-> 829
/*     */     //   #114	-> 852
/*     */     //   #114	-> 860
/*     */     //   #114	-> 881
/*     */     //   #114	-> 899
/*     */     //   #116	-> 947
/*     */     //   #118	-> 950
/*     */     //   #119	-> 960
/*     */     //   #121	-> 978
/*     */     //   #122	-> 993
/*     */     //   #124	-> 996
/*     */     //   #124	-> 1027
/*     */     //   #125	-> 1063
/*     */     //   #127	-> 1096
/*     */     //   #127	-> 1106
/*     */     //   #127	-> 1137
/*     */     //   #128	-> 1147
/*     */     //   #128	-> 1159
/*     */     //   #129	-> 1169
/*     */     //   #132	-> 1181
/*     */     //   #133	-> 1184
/*     */     //   #134	-> 1197
/*     */     //   #135	-> 1236
/*     */     //   #136	-> 1239
/*     */     //   #137	-> 1248
/*     */     //   #138	-> 1258
/*     */     //   #139	-> 1294
/*     */     //   #140	-> 1314
/*     */     //   #142	-> 1326
/*     */     //   #143	-> 1333
/*     */     //   #145	-> 1343
/*     */     //   #146	-> 1363
/*     */     //   #0	-> 1366
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	1369	0	x	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	1369	1	n	I
/*     */     //   0	1369	2	scale	D
/*     */     //   0	1369	4	width	I
/*     */     //   0	1369	5	atom	D
/*     */     //   0	1369	7	pdigits	I
/*     */     //   0	1369	8	ndigits	I
/*     */     //   0	1369	9	hdigits	I
/*     */     //   0	1369	10	ldigits	I
/*     */     //   0	1369	11	xi	I
/*     */     //   0	1369	12	j	I
/*     */     //   0	1369	13	i	I
/*     */     //   0	1369	14	k	I
/*     */     //   0	1369	15	mm	I
/*     */     //   0	1369	16	hi	D
/*     */     //   0	1369	18	lo	D
/*     */     //   0	1369	20	mu	D
/*     */     //   0	1369	22	x2	D
/*     */     //   0	1369	24	x1	D
/*     */     //   0	1369	26	c	D
/*     */     //   0	1369	28	r	D
/*     */     //   0	1369	43	i$28	I
/*     */     //   0	1369	53	i$27	I
/*     */     //   0	1369	63	i$26	I
/*     */     //   0	1369	69	i$25	I
/*     */     //   0	1369	75	iftmp$24	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	1369	76	iftmp$24$offset	I
/*     */     //   0	1369	102	iftmp$23	I
/*     */     //   0	1369	110	iftmp$22	I
/*     */     //   0	1369	123	n$21	I
/*     */     //   0	1369	171	n$20	I
/*     */     //   0	1369	208	n$19	I
/*     */     //   0	1369	217	n$18	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP C_StemLeaf(SEXP x, SEXP scale, SEXP swidth, SEXP atom) {
/* 152 */     if (Rinternals.TYPEOF(x) != 14 || Rinternals.TYPEOF(scale) != 14) Error.Rf_error(new BytePtr("invalid input\000".getBytes(), 0), new Object[0]);
/*     */     
/* 154 */     if (Rinternals.IS_LONG_VEC(x) != 0) {
/* 155 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("long vector '%s' is not supported\000".getBytes(), 0)), new Object[] { new BytePtr("x\000".getBytes(), 0) });
/*     */     }
/* 157 */     width = Rinternals.Rf_asInteger(swidth); n = Rinternals.LENGTH(x);
/* 158 */     R_NaInt$16 = Arith.R_NaInt; if (n == R_NaInt$16) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("x\000".getBytes(), 0) }); 
/* 159 */     R_NaInt$17 = Arith.R_NaInt; if (width == R_NaInt$17) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("width\000".getBytes(), 0) }); 
/* 160 */     sc = Rinternals.Rf_asReal(scale); sa = Rinternals.Rf_asReal(atom);
/* 161 */     if (Arith.R_finite(sc) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("scale\000".getBytes(), 0) }); 
/* 162 */     if (Arith.R_finite(sa) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("atom\000".getBytes(), 0) }); 
/* 163 */     stem_leaf(Rinternals2.REAL(x), n, sc, width, sa);
/* 164 */     return Rinternals.R_NilValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void C_bincount(Ptr x, int n, Ptr breaks, int nb, Ptr count, int right, int include_border) {
/* 174 */     nb1 = 0; hi = 0; lo = 0; i = 0; nb1 = nb + -1;
/*     */ 
/*     */     
/* 177 */     int j = nb1 * 4; count.memset(0, j);
/*     */     
/* 179 */     for (i = 0; i < n; i++) {
/* 180 */       int m = i * 8; Ptr ptr = x; int k = m; if (Arith.R_finite(ptr.getDouble(k)) != 0) {
/* 181 */         lo = 0;
/* 182 */         hi = nb1;
/* 183 */         int i4 = lo * 8; Ptr ptr2 = breaks; int i3 = i4; double d2 = ptr2.getDouble(i3); int i2 = i * 8; Ptr ptr1 = x; int i1 = i2; double d1 = ptr1.getDouble(i1); if (d2 <= d1) {
/* 184 */           int i8 = i * 8; Ptr ptr4 = x; int i7 = i8; double d4 = ptr4.getDouble(i7); int i6 = hi * 8; Ptr ptr3 = breaks; int i5 = i6; double d3 = ptr3.getDouble(i5);
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP C_BinCount(SEXP x, SEXP breaks, SEXP right, SEXP lowest) {
/* 204 */     x = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(x, 14));
/* 205 */     breaks = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(breaks, 14));
/* 206 */     n = Rinternals.XLENGTH(x); nB = Rinternals.XLENGTH(breaks);
/* 207 */     sr = Rinternals.Rf_asLogical(right); sl = Rinternals.Rf_asLogical(lowest);
/* 208 */     R_NaInt$0 = Arith.R_NaInt; if (sr == R_NaInt$0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("right\000".getBytes(), 0) }); 
/* 209 */     R_NaInt$1 = Arith.R_NaInt; if (sl == R_NaInt$1) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("include.lowest\000".getBytes(), 0) }); 
/* 210 */     int i = nB + -1; counts = Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, i));
/* 211 */     Ptr ptr2 = Rinternals2.INTEGER(counts), ptr1 = Rinternals2.REAL(breaks); C_bincount(Rinternals2.REAL(x), n, ptr1, nB, ptr2, sr, sl);
/*     */     
/* 213 */     return counts;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/stem__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */