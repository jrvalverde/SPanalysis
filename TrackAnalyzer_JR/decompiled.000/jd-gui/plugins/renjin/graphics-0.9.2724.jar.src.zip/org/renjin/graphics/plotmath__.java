/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.Mathlib;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.Stdlib2;
/*      */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.grDevices.baseEngine__;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class plotmath__
/*      */ {
/*      */   public static double $MuSpace$OneEighteenth = 0.05555555555555555D;
/*      */   public static double $ThickSpace$FiveEighteenths = 0.2777777777777778D;
/*      */   public static double $MediumSpace$TwoNinths = 0.2222222222222222D;
/*      */   public static double $ThinSpace$OneSixth = 0.16666666666666666D;
/*      */   
/*      */   public static double ConvertedX(Ptr mc, Ptr dd) {
/*  100 */     double d12 = mc.getDouble(12);
/*  101 */     double d11 = mc.getDouble(28), d10 = mc.getDouble(12), d9 = d11 - d10, d8 = mc.getDouble(52), d7 = d9 * d8; double d6 = d12 + d7;
/*  102 */     double d5 = mc.getDouble(36), d4 = mc.getDouble(20), d3 = d5 - d4, d2 = mc.getDouble(60), d1 = d3 * d2; rotatedX = d6 - d1;
/*  103 */     MetricUnit$90 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEtoDeviceX(rotatedX, MetricUnit$90, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double ConvertedY(Ptr mc, Ptr dd) {
/*  108 */     double d12 = mc.getDouble(20);
/*  109 */     double d11 = mc.getDouble(36), d10 = mc.getDouble(20), d9 = d11 - d10, d8 = mc.getDouble(52), d7 = d9 * d8; double d6 = d12 + d7;
/*  110 */     double d5 = mc.getDouble(28), d4 = mc.getDouble(12), d3 = d5 - d4, d2 = mc.getDouble(60), d1 = d3 * d2; rotatedY = d6 + d1;
/*  111 */     MetricUnit$89 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEtoDeviceY(rotatedY, MetricUnit$89, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void PMoveAcross(double xamount, Ptr mc) {
/*  116 */     double d = mc.getDouble(28) + xamount; mc.setDouble(28, d);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void PMoveUp(double yamount, Ptr mc) {
/*  121 */     double d = mc.getDouble(36) + yamount; mc.setDouble(36, d);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void PMoveTo(double x, double y, Ptr mc) {
/*  126 */     mc.setDouble(28, x);
/*  127 */     mc.setDouble(36, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xHeight(Ptr gc, Ptr dd) {
/*  135 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(120, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  136 */     MetricUnit$87 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(height[0], MetricUnit$87, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double XHeight(Ptr gc, Ptr dd) {
/*  142 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(88, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  143 */     MetricUnit$85 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(height[0], MetricUnit$85, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double AxisHeight(Ptr gc, Ptr dd) {
/*  149 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(43, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  150 */     MetricUnit$83 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(height[0] * 0.5D, MetricUnit$83, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Quad(Ptr gc, Ptr dd) {
/*  156 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  157 */     MetricUnit$81 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(width[0], MetricUnit$81, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double FigHeight(Ptr gc, Ptr dd) {
/*  164 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(48, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  165 */     MetricUnit$79 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(height[0], MetricUnit$79, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double DescDepth(Ptr gc, Ptr dd) {
/*  172 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(103, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  173 */     MetricUnit$77 = Context.get__plotmath$MetricUnit(); return baseEngine__.GEfromDeviceHeight(depth[0], MetricUnit$77, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double RuleThickness() {
/*  179 */     return 0.015D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ThinSpace(Ptr gc, Ptr dd) {
/*  186 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  187 */     MetricUnit$74 = Context.get__plotmath$MetricUnit(); OneSixth$75 = $ThinSpace$OneSixth; width$76 = width[0]; return baseEngine__.GEfromDeviceHeight(OneSixth$75 * width$76, MetricUnit$74, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double MediumSpace(Ptr gc, Ptr dd) {
/*  194 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  195 */     MetricUnit$71 = Context.get__plotmath$MetricUnit(); TwoNinths$72 = $MediumSpace$TwoNinths; width$73 = width[0]; return baseEngine__.GEfromDeviceHeight(TwoNinths$72 * width$73, MetricUnit$71, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ThickSpace(Ptr gc, Ptr dd) {
/*  202 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  203 */     MetricUnit$68 = Context.get__plotmath$MetricUnit(); FiveEighteenths$69 = $ThickSpace$FiveEighteenths; width$70 = width[0]; return baseEngine__.GEfromDeviceHeight(FiveEighteenths$69 * width$70, MetricUnit$68, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double MuSpace(Ptr gc, Ptr dd) {
/*  210 */     width = new double[1]; depth = new double[1]; height = new double[1]; width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  211 */     MetricUnit$65 = Context.get__plotmath$MetricUnit(); OneEighteenth$66 = $MuSpace$OneEighteenth; width$67 = width[0]; return baseEngine__.GEfromDeviceHeight(OneEighteenth$66 * width$67, MetricUnit$65, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double TeX(int which, Ptr gc, Ptr dd) {
/*      */     double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20, d21, d22, d23, d24, d25, d26;
/*  238 */     null = 0.0D; switch (which) {
/*      */       case 0:
/*      */       case 1:
/*  241 */         return xHeight(gc, dd);
/*      */       
/*      */       case 2:
/*  244 */         return Quad(gc, dd);
/*      */       
/*      */       case 3:
/*  247 */         d26 = AxisHeight(gc, dd);
/*  248 */         d25 = RuleThickness() * 3.51D; d24 = d26 + d25;
/*  249 */         d23 = XHeight(gc, dd) * 0.15D; d22 = d24 + d23;
/*  250 */         d21 = DescDepth(gc, dd) * 0.7D; return d22 + d21;
/*      */       case 4:
/*  252 */         d20 = AxisHeight(gc, dd);
/*  253 */         d19 = RuleThickness() * 1.51D; d18 = d20 + d19;
/*  254 */         d17 = XHeight(gc, dd) * 0.08333333D; return d18 + d17;
/*      */       case 5:
/*  256 */         d16 = AxisHeight(gc, dd);
/*  257 */         d15 = RuleThickness() * 1.51D; d14 = d16 + d15;
/*  258 */         d13 = XHeight(gc, dd) * 0.1333333D;
/*      */         return d14 + d13;
/*      */       case 6:
/*  261 */         d12 = RuleThickness() * 3.51D; d11 = AxisHeight(gc, dd); d10 = d12 - d11;
/*  262 */         d9 = FigHeight(gc, dd) * 0.7D; d8 = d10 + d9;
/*  263 */         d7 = XHeight(gc, dd) * 0.344444D;
/*      */         return d8 + d7;
/*      */       case 7:
/*  266 */         d6 = RuleThickness() * 1.51D; d5 = AxisHeight(gc, dd); d4 = d6 - d5;
/*  267 */         d3 = FigHeight(gc, dd) * 0.7D; d2 = d4 + d3;
/*  268 */         d1 = XHeight(gc, dd) * 0.08333333D;
/*      */         return d2 + d1;
/*      */       case 8:
/*  271 */         return xHeight(gc, dd) * 0.95D;
/*      */       case 9:
/*  273 */         return xHeight(gc, dd) * 0.825D;
/*      */       case 10:
/*  275 */         return xHeight(gc, dd) * 0.7D;
/*      */       
/*      */       case 11:
/*  278 */         return xHeight(gc, dd) * 0.35D;
/*      */       case 12:
/*  280 */         return XHeight(gc, dd) * 0.45D;
/*      */       
/*      */       case 13:
/*  283 */         return XHeight(gc, dd) * 0.3861111D;
/*      */       
/*      */       case 14:
/*  286 */         return XHeight(gc, dd) * 0.05D;
/*      */       
/*      */       case 15:
/*  289 */         return XHeight(gc, dd) * 2.39D;
/*      */       case 16:
/*  291 */         return XHeight(gc, dd) * 1.01D;
/*      */       
/*      */       case 17:
/*  294 */         return AxisHeight(gc, dd);
/*      */       
/*      */       case 18:
/*  297 */         return RuleThickness();
/*      */       
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*  304 */         return XHeight(gc, dd) * 0.15D;
/*      */     } 
/*  306 */     Error.Rf_error(new BytePtr("invalid `which' in C function TeX\000".getBytes(), 0), new Object[0]);
/*      */     return SYNTHETIC_LOCAL_VARIABLE_101;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int GetStyle(Ptr mc) {
/*  312 */     return mc.getAlignedInt(17);
/*      */   }
/*      */   
/*      */   public static void SetStyle(int newstyle, Ptr mc, Ptr gc) {
/*      */     double d1, d2, d3;
/*  317 */     switch (newstyle) {
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  322 */         d3 = mc.getDouble(4); gc.setDouble(44, d3);
/*      */         break;
/*      */       case 3:
/*      */       case 4:
/*  326 */         d2 = mc.getDouble(4) * 0.7D; gc.setDouble(44, d2);
/*      */         break;
/*      */       case 1:
/*      */       case 2:
/*  330 */         d1 = mc.getDouble(4) * 0.5D; gc.setDouble(44, d1);
/*      */         break;
/*      */       default:
/*  333 */         throw new UnsatisfiedLinkException("_");
/*      */     } 
/*  335 */     mc.setAlignedInt(17, newstyle);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SetPrimeStyle(int style, Ptr mc, Ptr gc) {
/*  340 */     switch (style) {
/*      */       case 7:
/*      */       case 8:
/*  343 */         SetStyle(7, mc, gc);
/*      */         break;
/*      */       case 5:
/*      */       case 6:
/*  347 */         SetStyle(5, mc, gc);
/*      */         break;
/*      */       case 3:
/*      */       case 4:
/*  351 */         SetStyle(3, mc, gc);
/*      */         break;
/*      */       case 1:
/*      */       case 2:
/*  355 */         SetStyle(1, mc, gc);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SetSupStyle(int style, Ptr mc, Ptr gc) {
/*  362 */     switch (style) {
/*      */       case 6:
/*      */       case 8:
/*  365 */         SetStyle(4, mc, gc);
/*      */         break;
/*      */       case 5:
/*      */       case 7:
/*  369 */         SetStyle(3, mc, gc);
/*      */         break;
/*      */       case 2:
/*      */       case 4:
/*  373 */         SetStyle(2, mc, gc);
/*      */         break;
/*      */       case 1:
/*      */       case 3:
/*  377 */         SetStyle(1, mc, gc);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SetSubStyle(int style, Ptr mc, Ptr gc) {
/*  384 */     switch (style) {
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  389 */         SetStyle(3, mc, gc);
/*      */         break;
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*  395 */         SetStyle(1, mc, gc);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void SetNumStyle(int style, Ptr mc, Ptr gc) {
/*  402 */     switch (style) {
/*      */       case 8:
/*  404 */         SetStyle(6, mc, gc);
/*      */         return;
/*      */       case 7:
/*  407 */         SetStyle(5, mc, gc);
/*      */         return;
/*      */     } 
/*  410 */     SetSupStyle(style, mc, gc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SetDenomStyle(int style, Ptr mc, Ptr gc) {
/*  416 */     if (style <= 6) {
/*      */ 
/*      */       
/*  419 */       SetSubStyle(style, mc, gc);
/*      */       return;
/*      */     } 
/*      */     SetStyle(5, mc, gc);
/*      */   } public static int IsCompactStyle(int style, Ptr mc, Ptr gc) {
/*  424 */     switch (style) {
/*      */       case 1:
/*      */       case 3:
/*      */       case 5:
/*      */       case 7:
/*  429 */         return 1;
/*      */     } 
/*  431 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double x, double y) {
/*  442 */     return (x <= y) ? 
/*  443 */       y : x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr MakeBBox(double height, double depth, double width) {
/*  470 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); mixedPtr1.setDouble(height);
/*  471 */     mixedPtr1.setAlignedDouble(1, depth);
/*  472 */     mixedPtr1.setAlignedDouble(2, width);
/*  473 */     mixedPtr1.setAlignedDouble(3, 0.0D);
/*  474 */     mixedPtr1.setAlignedInt(8, 0);
/*  475 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr NullBBox() {
/*  481 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); mixedPtr1.setDouble(0.0D);
/*  482 */     mixedPtr1.setAlignedDouble(1, 0.0D);
/*  483 */     mixedPtr1.setAlignedDouble(2, 0.0D);
/*  484 */     mixedPtr1.setAlignedDouble(3, 0.0D);
/*  485 */     mixedPtr1.setAlignedInt(8, 0);
/*  486 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr ShiftBBox(Ptr bbox1, double shiftV) {
/*  491 */     MixedPtr mixedPtr = MixedPtr.malloc(36); double d4 = bbox1.getDouble() + shiftV; bbox1.setDouble(d4);
/*  492 */     double d3 = bbox1.getAlignedDouble(1) - shiftV; bbox1.setAlignedDouble(1, d3);
/*  493 */     double d2 = bbox1.getAlignedDouble(2); bbox1.setAlignedDouble(2, d2);
/*  494 */     double d1 = bbox1.getAlignedDouble(3); bbox1.setAlignedDouble(3, d1);
/*  495 */     int i = bbox1.getAlignedInt(8); bbox1.setAlignedInt(8, i);
/*  496 */     mixedPtr.memcpy(bbox1, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr EnlargeBBox(Ptr bbox, double deltaHeight, double deltaDepth, double deltaWidth) {
/*  502 */     MixedPtr mixedPtr = MixedPtr.malloc(36); double d3 = bbox.getDouble() + deltaHeight; bbox.setDouble(d3);
/*  503 */     double d2 = bbox.getAlignedDouble(1) + deltaDepth; bbox.setAlignedDouble(1, d2);
/*  504 */     double d1 = bbox.getAlignedDouble(2) + deltaWidth; bbox.setAlignedDouble(2, d1);
/*  505 */     mixedPtr.memcpy(bbox, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr CombineBBoxes(Ptr bbox1, Ptr bbox2) {
/*  510 */     MixedPtr mixedPtr = MixedPtr.malloc(36); double d8 = bbox2.getDouble(), d7 = max(bbox1.getDouble(), d8); bbox1.setDouble(d7);
/*  511 */     double d6 = bbox2.getAlignedDouble(1), d5 = max(bbox1.getAlignedDouble(1), d6); bbox1.setAlignedDouble(1, d5);
/*  512 */     double d4 = bbox1.getAlignedDouble(2), d3 = bbox2.getAlignedDouble(2), d2 = d4 + d3; bbox1.setAlignedDouble(2, d2);
/*  513 */     double d1 = bbox2.getAlignedDouble(3); bbox1.setAlignedDouble(3, d1);
/*  514 */     int i = bbox2.getAlignedInt(8); bbox1.setAlignedInt(8, i);
/*  515 */     mixedPtr.memcpy(bbox1, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr CombineAlignedBBoxes(Ptr bbox1, Ptr bbox2) {
/*  520 */     MixedPtr mixedPtr = MixedPtr.malloc(36); double d6 = bbox2.getDouble(), d5 = max(bbox1.getDouble(), d6); bbox1.setDouble(d5);
/*  521 */     double d4 = bbox2.getAlignedDouble(1), d3 = max(bbox1.getAlignedDouble(1), d4); bbox1.setAlignedDouble(1, d3);
/*  522 */     double d2 = bbox2.getAlignedDouble(2), d1 = max(bbox1.getAlignedDouble(2), d2); bbox1.setAlignedDouble(2, d1);
/*  523 */     bbox1.setAlignedDouble(3, 0.0D);
/*  524 */     bbox1.setAlignedInt(8, 0);
/*  525 */     mixedPtr.memcpy(bbox1, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr CombineOffsetBBoxes(Ptr bbox1, int italic1, Ptr bbox2, int italic2, double xoffset, double yoffset) {
/*  533 */     MixedPtr mixedPtr = MixedPtr.malloc(36); double d8 = bbox1.getAlignedDouble(2); if (italic1 == 0) { iftmp$63 = 0.0D; } else { iftmp$63 = bbox1.getAlignedDouble(3); }  width1 = d8 + iftmp$63;
/*  534 */     double d7 = bbox2.getAlignedDouble(2); if (italic2 == 0) { iftmp$64 = 0.0D;
/*  535 */       double d14 = d7 + iftmp$64 + xoffset, d13 = max(width1, d14); bbox1.setAlignedDouble(2, d13);
/*  536 */       double d12 = bbox2.getDouble() + yoffset, d11 = max(bbox1.getDouble(), d12); bbox1.setDouble(d11);
/*  537 */       double d10 = bbox2.getAlignedDouble(1) - yoffset, d9 = max(bbox1.getAlignedDouble(1), d10); bbox1.setAlignedDouble(1, d9);
/*  538 */       bbox1.setAlignedDouble(3, 0.0D);
/*  539 */       bbox1.setAlignedInt(8, 0);
/*  540 */       mixedPtr.memcpy(bbox1, 36); return (Ptr)mixedPtr; }  iftmp$64 = bbox2.getAlignedDouble(3); double d6 = d7 + iftmp$64 + xoffset, d5 = max(width1, d6); bbox1.setAlignedDouble(2, d5); double d4 = bbox2.getDouble() + yoffset, d3 = max(bbox1.getDouble(), d4); bbox1.setDouble(d3); double d2 = bbox2.getAlignedDouble(1) - yoffset, d1 = max(bbox1.getAlignedDouble(1), d2); bbox1.setAlignedDouble(1, d1); bbox1.setAlignedDouble(3, 0.0D); bbox1.setAlignedInt(8, 0); mixedPtr.memcpy(bbox1, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double CenterShift(Ptr bbox) {
/*  545 */     double d2 = bbox.getDouble(), d1 = bbox.getAlignedDouble(1); return (d2 - d1) * 0.5D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int NameMatch(SEXP expr, Ptr aString) {
/*  558 */     return (Rinternals.TYPEOF(expr) == 1) ? (
/*  559 */       (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.PRINTNAME(expr)), aString) != 0) ? 0 : 1) : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int StringMatch(SEXP expr, Ptr aString) {
/*  564 */     return (Stdlib.strcmp((Ptr)Rinternals.Rf_translateChar(Rinternals.STRING_ELT(expr, 0)), aString) != 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int SymbolCode(SEXP expr) {
/*      */     int j;
/*  808 */     i = 0; while (true) { if (Context.get__plotmath$SymbolTable().getInt(i * 8 + 4) == 0) {
/*      */ 
/*      */         
/*  811 */         boolean bool = false; break;
/*      */       }  Ptr ptr = Context.get__plotmath$SymbolTable().getPointer(i * 8); if (NameMatch(expr, ptr) == 0) {
/*      */         i++; continue;
/*      */       }  j = Context.get__plotmath$SymbolTable().getInt(i * 8 + 4);
/*      */       break; }
/*      */     
/*  817 */     return j; } public static int TranslatedSymbol(SEXP expr) { code = SymbolCode(expr);
/*  818 */     if ((code <= 64 || code > 90) && (code <= 96 || 
/*  819 */       code > 122) && code != 192 && 
/*  820 */       code != 161 && 
/*  821 */       code != 162 && 
/*  822 */       code != 165 && 
/*  823 */       code != 176 && 
/*  824 */       code != 178 && 
/*  825 */       code != 182)
/*      */     {
/*  827 */       if (code != 209)
/*      */       {
/*      */ 
/*      */         
/*  831 */         return 0;
/*      */       }
/*      */     }
/*      */     return code; }
/*      */ 
/*      */   
/*      */   public static int FormulaExpression(SEXP expr) {
/*  838 */     return (Rinternals.TYPEOF(expr) != 6) ? 0 : 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int NameAtom(SEXP expr) {
/*  843 */     return (Rinternals.TYPEOF(expr) != 1) ? 0 : 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int NumberAtom(SEXP expr) {
/*  848 */     if (Rinternals.TYPEOF(expr) != 
/*  849 */       14 && Rinternals.TYPEOF(expr) != 13)
/*  850 */       if (Rinternals.TYPEOF(expr) != 15)
/*      */         return 0;  
/*      */     return 1;
/*      */   }
/*      */   public static int StringAtom(SEXP expr) {
/*  855 */     return (Rinternals.TYPEOF(expr) != 16) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int GetFont(Ptr gc) {
/*  863 */     return gc.getAlignedInt(17);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int SetFont(int font, Ptr gc) {
/*  868 */     prevfont = gc.getAlignedInt(17);
/*  869 */     font$61 = font; gc.setAlignedInt(17, font$61);
/*  870 */     return prevfont;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int UsingItalics(Ptr gc) {
/*  875 */     return (gc.getAlignedInt(17) != 3 && 
/*  876 */       gc.getAlignedInt(17) != 4) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr GlyphBBox(int chr, Ptr gc, Ptr dd) {
/*  883 */     width = new double[1]; depth = new double[1]; height = new double[1]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); width[0] = 0.0D; depth[0] = 0.0D; height[0] = 0.0D; chr1 = chr;
/*  884 */     if (dd.getPointer().getInt(300) != 0 && gc.getAlignedInt(17) == 5)
/*  885 */       chr1 = -Defn.Rf_AdobeSymbol2ucs2(chr); 
/*  886 */     baseEngine__.GEMetricInfo(chr1, gc, (Ptr)new DoublePtr(height, 0), (Ptr)new DoublePtr(depth, 0), (Ptr)new DoublePtr(width, 0), dd);
/*  887 */     MetricUnit$54 = Context.get__plotmath$MetricUnit(); double d3 = baseEngine__.GEfromDeviceHeight(height[0], MetricUnit$54, dd); mixedPtr1.setDouble(d3);
/*  888 */     MetricUnit$56 = Context.get__plotmath$MetricUnit(); double d2 = baseEngine__.GEfromDeviceHeight(depth[0], MetricUnit$56, dd); mixedPtr1.setAlignedDouble(1, d2);
/*  889 */     MetricUnit$58 = Context.get__plotmath$MetricUnit(); double d1 = baseEngine__.GEfromDeviceHeight(width[0], MetricUnit$58, dd); mixedPtr1.setAlignedDouble(2, d1);
/*  890 */     mixedPtr1.setAlignedDouble(3, 0.0D);
/*  891 */     mixedPtr1.setAlignedInt(8, 1);
/*  892 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderItalicCorr(Ptr bbox, int draw, Ptr mc, Ptr gc, Ptr dd) {
/*  907 */     MixedPtr mixedPtr = MixedPtr.malloc(36); if (bbox.getAlignedDouble(3) > 0.0D) {
/*  908 */       if (draw != 0)
/*  909 */         PMoveAcross(bbox.getAlignedDouble(3), mc); 
/*  910 */       double d3 = bbox.getAlignedDouble(2), d2 = bbox.getAlignedDouble(3), d1 = d3 + d2; bbox.setAlignedDouble(2, d1);
/*  911 */       bbox.setAlignedDouble(3, 0.0D);
/*      */     } 
/*  913 */     mixedPtr.memcpy(bbox, 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderGap(double gap, int draw, Ptr mc, Ptr gc, Ptr dd) {
/*  919 */     MixedPtr mixedPtr = MixedPtr.malloc(36); if (draw != 0)
/*  920 */       PMoveAcross(gap, mc); 
/*  921 */     mixedPtr.memcpy(MakeBBox(0.0D, 0.0D, gap), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSymbolChar(int ascii, int draw, Ptr mc, Ptr gc, Ptr dd) {
/*  934 */     asciiStr = new byte[2]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); if (ascii != 94 && ascii != 126)
/*      */     
/*      */     { 
/*  937 */       prev = SetFont(5, gc); } else { prev = SetFont(1, gc); }
/*  938 */      mixedPtr1.memcpy(GlyphBBox(ascii, gc, dd), 36);
/*  939 */     if (draw != 0) {
/*  940 */       byte b = (byte)ascii; asciiStr[0] = b;
/*  941 */       asciiStr[1] = (byte)0;
/*  942 */       double d2 = mc.getDouble(44), d1 = ConvertedY(mc, dd); baseEngine__.GEText(ConvertedX(mc, dd), d1, (Ptr)new BytePtr(asciiStr, 0), 5, 0.0D, 0.0D, d2, gc, dd);
/*      */ 
/*      */ 
/*      */       
/*  946 */       PMoveAcross(mixedPtr1.getAlignedDouble(2), mc);
/*      */     } 
/*  948 */     SetFont(prev, gc);
/*  949 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSymbolStr(Ptr str, int draw, Ptr mc, Ptr gc, Ptr dd) {
/*  959 */     MixedPtr mixedPtr1 = MixedPtr.malloc(8); wc = new int[1]; MixedPtr mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36); chr = new byte[7]; MixedPtr mixedPtr4 = MixedPtr.malloc(36); font = 0; prevfont = 0; System.arraycopy("\000".getBytes(), 0, chr, 0, 1);
/*  960 */     s = str; s$offset = 0;
/*      */     
/*  962 */     mixedPtr2.memcpy(NullBBox(), 36);
/*  963 */     lastItalicCorr = 0.0D;
/*  964 */     prevfont = GetFont(gc);
/*  965 */     font = prevfont;
/*      */     
/*  967 */     if (!str.isNull()) {
/*      */ 
/*      */ 
/*      */       
/*  971 */       if (Defn.mbcslocale == 0 || gc.getAlignedInt(17) == 5)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1012 */         while (s.getByte(s$offset) != (byte)0)
/* 1013 */         { Ptr ptr2 = Stdlib2.__ctype_b_loc().getPointer(); int k = s.getByte(s$offset) * 2; Ptr ptr1 = ptr2; int j = 0 + k; if ((ptr1.getChar(j) & 0x800) == 0 || font == 1)
/*      */           
/*      */           { 
/*      */             
/* 1017 */             if (font != prevfont)
/* 1018 */             { font = prevfont;
/* 1019 */               SetFont(prevfont, gc); }  }
/*      */           else { font = 1; SetFont(1, gc); }
/* 1021 */            int i = s.getByte(s$offset) & 0xFF; mixedPtr3.memcpy(GlyphBBox(i, gc, dd), 36);
/* 1022 */           if (UsingItalics(gc) == 0)
/*      */           
/*      */           { 
/*      */             
/* 1026 */             mixedPtr3.setAlignedDouble(3, 0.0D); } else { double d2 = mixedPtr3.getDouble(); ItalicFactor$53 = Context.get__plotmath$ItalicFactor(); double d1 = d2 * ItalicFactor$53; mixedPtr3.setAlignedDouble(3, d1); }
/* 1027 */            if (draw != 0) {
/* 1028 */             byte b = s.getByte(s$offset); chr[0] = b;
/* 1029 */             PMoveAcross(lastItalicCorr, mc);
/* 1030 */             double d2 = mc.getDouble(44), d1 = ConvertedY(mc, dd); baseEngine__.GEText(ConvertedX(mc, dd), d1, (Ptr)new BytePtr(chr, 0), 0, 0.0D, 0.0D, d2, gc, dd);
/*      */ 
/*      */             
/* 1033 */             PMoveAcross(mixedPtr3.getAlignedDouble(2), mc);
/*      */           } 
/* 1035 */           double d = mixedPtr2.getAlignedDouble(2) + lastItalicCorr; mixedPtr2.setAlignedDouble(2, d);
/* 1036 */           mixedPtr2.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 1037 */           lastItalicCorr = mixedPtr3.getAlignedDouble(3);
/* 1038 */           s = s; s$offset++; }  }
/*      */       else { mixedPtr1.memset(0, 8); if (s.getByte(s$offset) != (byte)0) { wc[0] = 0; throw new UnsatisfiedLinkException("mbrtowc"); }
/*      */          }
/* 1041 */        if (font != prevfont)
/* 1042 */         SetFont(prevfont, gc); 
/*      */     } 
/* 1044 */     mixedPtr2.setAlignedInt(8, 1);
/* 1045 */     mixedPtr4.memcpy((Ptr)mixedPtr2, 36); return (Ptr)mixedPtr4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderChar(int ascii, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1057 */     asciiStr = new byte[7]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); mixedPtr1.memcpy(GlyphBBox(ascii, gc, dd), 36);
/* 1058 */     if (draw != 0) {
/* 1059 */       BytePtr.memset(asciiStr, 0, 0, 7);
/* 1060 */       if (Defn.mbcslocale == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 1065 */         byte b = (byte)ascii; asciiStr[0] = b;
/* 1066 */         double d2 = mc.getDouble(44), d1 = ConvertedY(mc, dd); baseEngine__.GEText(ConvertedX(mc, dd), d1, (Ptr)new BytePtr(asciiStr, 0), 0, 0.0D, 0.0D, d2, gc, dd);
/*      */ 
/*      */         
/* 1069 */         PMoveAcross(mixedPtr1.getAlignedDouble(2), mc); } else { throw new UnsatisfiedLinkException("wcrtomb"); }
/*      */     
/* 1071 */     }  mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderStr(Ptr str, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1078 */     MixedPtr mixedPtr1 = MixedPtr.malloc(8); wc = new int[1]; MixedPtr mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); wc[0] = 0; enc = 0; mixedPtr3.memcpy(NullBBox(), 36);
/* 1079 */     mixedPtr2.memcpy(NullBBox(), 36);
/* 1080 */     nc = 0;
/* 1081 */     if (gc.getAlignedInt(17) != 5) { iftmp$41 = 0; } else { iftmp$41 = 5; }  enc = iftmp$41;
/*      */     
/* 1083 */     if (!str.isNull())
/*      */     {
/* 1085 */       if (Defn.mbcslocale == 0 || gc.getAlignedInt(17) == 5)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1098 */         s = str; s$offset = 0;
/* 1099 */         while (s.getByte(s$offset) != (byte)0) {
/*      */           
/* 1101 */           int i = s.getByte(s$offset) & 0xFF; mixedPtr3.memcpy(GlyphBBox(i, gc, dd), 36);
/* 1102 */           mixedPtr2.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 1103 */           s = s; s$offset++; nc++;
/*      */         } 
/*      */         
/* 1106 */         if (nc > 1) {
/*      */           
/* 1108 */           wd = baseEngine__.GEStrWidth(str, enc, gc, dd);
/* 1109 */           MetricUnit$44 = Context.get__plotmath$MetricUnit(); double d = baseEngine__.GEfromDeviceHeight(wd, MetricUnit$44, dd); mixedPtr2.setAlignedDouble(2, d);
/*      */         } 
/* 1111 */         if (draw != 0) {
/* 1112 */           double d2 = mc.getDouble(44), d1 = ConvertedY(mc, dd); baseEngine__.GEText(ConvertedX(mc, dd), d1, str, enc, 0.0D, 0.0D, d2, gc, dd);
/*      */           
/* 1114 */           PMoveAcross(mixedPtr2.getAlignedDouble(2), mc);
/*      */         } 
/* 1116 */         if (UsingItalics(gc) == 0)
/*      */         
/*      */         { 
/* 1119 */           mixedPtr2.setAlignedDouble(3, 0.0D); } else { double d2 = mixedPtr3.getDouble(); ItalicFactor$45 = Context.get__plotmath$ItalicFactor(); double d1 = d2 * ItalicFactor$45; mixedPtr2.setAlignedDouble(3, d1); }  }
/*      */       else { n = Stdlib.strlen(str); p = str; p$offset = 0; mixedPtr1.memset(0, 8); throw new UnsatisfiedLinkException("Rf_mbrtowc"); }
/* 1121 */        }  mixedPtr2.setAlignedInt(8, 1);
/* 1122 */     mixedPtr4.memcpy((Ptr)mixedPtr2, 36); return (Ptr)mixedPtr4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSymbol(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1132 */     MixedPtr mixedPtr = MixedPtr.malloc(36); code = TranslatedSymbol(expr); if (code == 0) {
/*      */ 
/*      */       
/* 1135 */       BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.PRINTNAME(expr)); mixedPtr.memcpy(RenderSymbolStr((Ptr)bytePtr, draw, mc, gc, dd), 36);
/*      */       return (Ptr)mixedPtr;
/*      */     } 
/*      */     mixedPtr.memcpy(RenderSymbolChar(code, draw, mc, gc, dd), 36);
/*      */     return (Ptr)mixedPtr;
/*      */   }
/*      */   public static Ptr RenderSymbolString(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1142 */     MixedPtr mixedPtr = MixedPtr.malloc(36); code = TranslatedSymbol(expr); if (code == 0) {
/*      */ 
/*      */       
/* 1145 */       BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.PRINTNAME(expr)); mixedPtr.memcpy(RenderStr((Ptr)bytePtr, draw, mc, gc, dd), 36);
/*      */       return (Ptr)mixedPtr;
/*      */     } 
/*      */     mixedPtr.memcpy(RenderSymbolChar(code, draw, mc, gc, dd), 36);
/*      */     return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderNumber(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1155 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(1, gc);
/* 1156 */     Defn.Rf_PrintDefaults();
/* 1157 */     BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.Rf_asChar(expr)); mixedPtr1.memcpy(RenderStr((Ptr)bytePtr, draw, mc, gc, dd), 36);
/* 1158 */     SetFont(prevfont, gc);
/* 1159 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderString(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1167 */     MixedPtr mixedPtr = MixedPtr.malloc(36); BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(expr, 0)); mixedPtr.memcpy(RenderStr((Ptr)bytePtr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int DotsAtom(SEXP expr) {
/* 1174 */     if (NameMatch(expr, (Ptr)new BytePtr("cdots\000".getBytes(), 0)) == 0)
/* 1175 */       if (NameMatch(expr, (Ptr)new BytePtr("...\000".getBytes(), 0)) == 0)
/* 1176 */         if (NameMatch(expr, (Ptr)new BytePtr("ldots\000".getBytes(), 0)) == 0)
/*      */         {
/* 1178 */           return 0;
/*      */         }  
/*      */     return 1;
/*      */   }
/*      */   
/*      */   public static Ptr RenderDots(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1184 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); mixedPtr1.memcpy(RenderSymbolChar(188, 0, mc, gc, dd), 36);
/* 1185 */     if (NameMatch(expr, (Ptr)new BytePtr("cdots\000".getBytes(), 0)) == 0 && NameMatch(expr, (Ptr)new BytePtr("...\000".getBytes(), 0)) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1195 */       if (draw != 0)
/* 1196 */         RenderSymbolChar(188, 1, mc, gc, dd); 
/* 1197 */       mixedPtr2.memcpy((Ptr)mixedPtr1, 36);
/*      */       return (Ptr)mixedPtr2;
/*      */     } 
/*      */     double d2 = AxisHeight(gc, dd), d1 = mixedPtr1.getDouble() * 0.5D;
/*      */     shift = d2 - d1;
/*      */     if (draw != 0) {
/*      */       PMoveUp(shift, mc);
/*      */       RenderSymbolChar(188, 1, mc, gc, dd);
/*      */       PMoveUp(-shift, mc);
/*      */     } 
/*      */     mixedPtr2.memcpy(ShiftBBox(mixedPtr1.copyOf(36), shift), 36);
/*      */     return (Ptr)mixedPtr2;
/*      */   }
/* 1210 */   public static Ptr RenderAtom(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr = MixedPtr.malloc(36); if (NameAtom(expr) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1216 */       if (NumberAtom(expr) == 0) {
/*      */         
/* 1218 */         if (StringAtom(expr) == 0) {
/*      */ 
/*      */           
/* 1221 */           mixedPtr.memcpy(NullBBox(), 36);
/*      */           return (Ptr)mixedPtr;
/*      */         } 
/*      */         mixedPtr.memcpy(RenderString(expr, draw, mc, gc, dd), 36);
/*      */         return (Ptr)mixedPtr;
/*      */       } 
/*      */       mixedPtr.memcpy(RenderNumber(expr, draw, mc, gc, dd), 36);
/*      */       return (Ptr)mixedPtr;
/*      */     } 
/*      */     if (DotsAtom(expr) == 0) {
/*      */       mixedPtr.memcpy(RenderSymbol(expr, draw, mc, gc, dd), 36);
/*      */       return (Ptr)mixedPtr;
/*      */     } 
/*      */     mixedPtr.memcpy(RenderDots(expr, draw, mc, gc, dd), 36);
/* 1235 */     return (Ptr)mixedPtr; } public static int SpaceAtom(SEXP expr) { return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("~\000".getBytes(), 0)) == 0) ? 0 : 1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSpace(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1244 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); nexpr = Rinternals.Rf_length(expr);
/*      */     
/* 1246 */     if (nexpr != 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1251 */       if (nexpr != 3)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1260 */         throw new UnsatisfiedLinkException("_");
/*      */       }
/*      */       SEXP sEXP2 = Rinternals.CADR(expr);
/*      */       mixedPtr2.memcpy(RenderElement(sEXP2, draw, mc, gc, dd), 36);
/*      */       mixedPtr3.memcpy(RenderSymbolChar(32, draw, mc, gc, dd), 36);
/*      */       SEXP sEXP1 = Rinternals.CADDR(expr);
/*      */       mixedPtr1.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36);
/*      */       mixedPtr3.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr3.copyOf(36)), 36);
/*      */       mixedPtr3.memcpy(CombineBBoxes(mixedPtr3.copyOf(36), mixedPtr1.copyOf(36)), 36);
/*      */       mixedPtr4.memcpy((Ptr)mixedPtr3, 36);
/*      */       return (Ptr)mixedPtr4;
/*      */     } 
/*      */     mixedPtr3.memcpy(RenderSymbolChar(32, draw, mc, gc, dd), 36);
/*      */     SEXP sEXP = Rinternals.CADR(expr);
/*      */     mixedPtr2.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/*      */     mixedPtr4.memcpy(CombineBBoxes(mixedPtr3.copyOf(36), mixedPtr2.copyOf(36)), 36);
/*      */     return (Ptr)mixedPtr4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int BinAtom(SEXP expr) {
/*      */     int j;
/* 1284 */     i = 0; while (true) { if (Context.get__plotmath$BinTable().getInt(i * 8 + 4) == 0) {
/*      */ 
/*      */         
/* 1287 */         boolean bool = false; break;
/*      */       }  Ptr ptr = Context.get__plotmath$BinTable().getPointer(i * 8); if (NameMatch(expr, ptr) == 0) {
/*      */         i++;
/*      */         continue;
/*      */       } 
/*      */       j = Context.get__plotmath$BinTable().getInt(i * 8 + 4);
/*      */       break; }
/*      */     
/* 1295 */     return j; } public static Ptr RenderSlash(int draw, Ptr mc, Ptr gc, Ptr dd) { y = new double[2]; x = new double[2]; MixedPtr mixedPtr = MixedPtr.malloc(36); depth = TeX(17, gc, dd) * 0.5D;
/* 1296 */     double d3 = XHeight(gc, dd), d2 = TeX(17, gc, dd) * 0.5D; height = d3 + d2;
/* 1297 */     width = xHeight(gc, dd) * 0.5D;
/* 1298 */     if (draw != 0) {
/* 1299 */       savedlty = gc.getAlignedInt(6);
/* 1300 */       savedlwd = gc.getAlignedDouble(2);
/* 1301 */       PMoveAcross(width * 0.5D, mc);
/* 1302 */       PMoveUp(-depth, mc);
/* 1303 */       double d7 = ConvertedX(mc, dd); x[0] = d7;
/* 1304 */       double d6 = ConvertedY(mc, dd); y[0] = d6;
/* 1305 */       PMoveAcross(width, mc);
/* 1306 */       PMoveUp(depth + height, mc);
/* 1307 */       double d5 = ConvertedX(mc, dd); x[1] = d5;
/* 1308 */       double d4 = ConvertedY(mc, dd); y[1] = d4;
/* 1309 */       PMoveUp(-height, mc);
/* 1310 */       gc.setAlignedInt(6, 0);
/* 1311 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 1312 */         gc.setAlignedDouble(2, 1.0D); 
/* 1313 */       baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1314 */       PMoveAcross(width * 0.5D, mc);
/* 1315 */       gc.setAlignedInt(6, savedlty);
/* 1316 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/* 1318 */     double d1 = width * 2.0D; mixedPtr.memcpy(MakeBBox(height, depth, d1), 36); return (Ptr)mixedPtr; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderBin(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1324 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36), mixedPtr7 = MixedPtr.malloc(36), mixedPtr8 = MixedPtr.malloc(36), mixedPtr9 = MixedPtr.malloc(36), mixedPtr10 = MixedPtr.malloc(36), mixedPtr11 = MixedPtr.malloc(36), mixedPtr12 = MixedPtr.malloc(36), mixedPtr13 = MixedPtr.malloc(36); op = BinAtom(Rinternals.CAR(expr));
/* 1325 */     nexpr = Rinternals.Rf_length(expr);
/*      */ 
/*      */ 
/*      */     
/* 1329 */     if (nexpr != 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1357 */       if (nexpr != 2)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1365 */         throw new UnsatisfiedLinkException("_"); }  if (mc.getAlignedInt(17) <= 4) {
/*      */         iftmp$39 = 0.0D;
/*      */       } else {
/*      */         iftmp$39 = ThinSpace(gc, dd);
/*      */       }  gap = iftmp$39; mixedPtr1.memcpy(RenderSymbolChar(op, draw, mc, gc, dd), 36); mixedPtr3.memcpy(RenderGap(gap, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36); SEXP sEXP = Rinternals.CADR(expr); mixedPtr2.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36); mixedPtr13.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36); return (Ptr)mixedPtr13;
/*      */     }  if (op != 42) {
/*      */       if (op != 47) {
/*      */         if (mc.getAlignedInt(17) <= 4) {
/*      */           iftmp$38 = 0.0D;
/*      */         } else {
/*      */           iftmp$38 = MediumSpace(gc, dd);
/*      */         }  gap = iftmp$38; SEXP sEXP6 = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP6, draw, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36); mixedPtr7.memcpy(RenderGap(gap, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr7.copyOf(36)), 36); mixedPtr6.memcpy(RenderSymbolChar(op, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr6.copyOf(36)), 36); mixedPtr5.memcpy(RenderGap(gap, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36); SEXP sEXP5 = Rinternals.CADDR(expr); mixedPtr4.memcpy(RenderElement(sEXP5, draw, mc, gc, dd), 36); mixedPtr13.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36); return (Ptr)mixedPtr13;
/*      */       }  gap = 0.0D; SEXP sEXP4 = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP4, draw, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36); mixedPtr11.memcpy(RenderGap(gap, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr11.copyOf(36)), 36); mixedPtr10.memcpy(RenderSlash(draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr10.copyOf(36)), 36); mixedPtr9.memcpy(RenderGap(gap, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr9.copyOf(36)), 36); SEXP sEXP3 = Rinternals.CADDR(expr); mixedPtr8.memcpy(RenderElement(sEXP3, draw, mc, gc, dd), 36); mixedPtr13.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr8.copyOf(36)), 36); return (Ptr)mixedPtr13;
/*      */     }  SEXP sEXP2 = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP2, draw, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/*      */     SEXP sEXP1 = Rinternals.CADDR(expr);
/*      */     mixedPtr12.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36);
/*      */     mixedPtr13.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr12.copyOf(36)), 36);
/* 1382 */     return (Ptr)mixedPtr13; } public static int SuperAtom(SEXP expr) { return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("^\000".getBytes(), 0)) == 0) ? 0 : 1; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int SubAtom(SEXP expr) {
/* 1387 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("[\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSub(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1397 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36); body = Rinternals.CADR(expr);
/* 1398 */     sub = Rinternals.CADDR(expr);
/* 1399 */     style = GetStyle(mc);
/* 1400 */     savedX = mc.getDouble(28);
/* 1401 */     savedY = mc.getDouble(36);
/*      */     
/* 1403 */     mixedPtr2.memcpy(RenderElement(body, draw, mc, gc, dd), 36);
/* 1404 */     mixedPtr2.memcpy(RenderItalicCorr(mixedPtr2.copyOf(36), draw, mc, gc, dd), 36);
/* 1405 */     if (mixedPtr2.getAlignedInt(8) != 0) { iftmp$35 = 0.0D; } else { double d4 = mixedPtr2.getAlignedDouble(1), d3 = TeX(14, gc, dd); iftmp$35 = d4 + d3; }  v = iftmp$35;
/* 1406 */     s16 = TeX(11, gc, dd);
/* 1407 */     SetSubStyle(style, mc, gc);
/* 1408 */     mixedPtr1.memcpy(RenderElement(sub, 0, mc, gc, dd), 36);
/* 1409 */     double d2 = mixedPtr1.getDouble() - 0.8D; v = max(max(v, s16), d2);
/* 1410 */     double d1 = -v; mixedPtr1.memcpy(RenderOffsetElement(sub, 0.0D, d1, draw, mc, gc, dd), 36);
/* 1411 */     mixedPtr2.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr1.copyOf(36)), 36);
/* 1412 */     SetStyle(style, mc, gc);
/* 1413 */     if (draw != 0)
/* 1414 */       PMoveTo(mixedPtr2.getAlignedDouble(2) + savedX, savedY, mc); 
/* 1415 */     mixedPtr3.memcpy((Ptr)mixedPtr2, 36); return (Ptr)mixedPtr3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSup(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1422 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); body = Rinternals.CADR(expr);
/* 1423 */     sup = Rinternals.CADDR(expr);
/* 1424 */     sub = Rinternals.R_NilValue;
/* 1425 */     style = GetStyle(mc);
/* 1426 */     savedX = mc.getDouble(28);
/* 1427 */     savedY = mc.getDouble(36);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1432 */     if (FormulaExpression(body) == 0 || SubAtom(Rinternals.CAR(body)) == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */       
/* 1437 */       haveSub = 0; } else { sub = Rinternals.CADDR(body); body = Rinternals.CADR(body); haveSub = 1; }
/* 1438 */      mixedPtr3.memcpy(RenderElement(body, draw, mc, gc, dd), 36);
/* 1439 */     delta = mixedPtr3.getAlignedDouble(3);
/* 1440 */     mixedPtr3.memcpy(RenderItalicCorr(mixedPtr3.copyOf(36), draw, mc, gc, dd), 36);
/* 1441 */     width = mixedPtr3.getAlignedDouble(2);
/* 1442 */     if (mixedPtr3.getAlignedInt(8) == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */       
/* 1447 */       double d7 = mixedPtr3.getDouble(), d6 = TeX(13, gc, dd); u = d7 - d6;
/* 1448 */       double d5 = mixedPtr3.getAlignedDouble(1), d4 = TeX(14, gc, dd); v = d5 + d4; }
/*      */     else { u = 0.0D; v = 0.0D; }
/* 1450 */      theta = TeX(18, gc, dd);
/* 1451 */     s5 = TeX(1, gc, dd);
/* 1452 */     s17 = TeX(12, gc, dd);
/* 1453 */     if (style != 8)
/*      */     
/* 1455 */     { if (IsCompactStyle(style, mc, gc) == 0)
/*      */       
/*      */       { 
/* 1458 */         p = TeX(9, gc, dd); } else { p = TeX(10, gc, dd); }  } else { p = TeX(8, gc, dd); }
/* 1459 */      SetSupStyle(style, mc, gc);
/* 1460 */     mixedPtr1.memcpy(RenderElement(sup, 0, mc, gc, dd), 36);
/* 1461 */     double d3 = mixedPtr1.getAlignedDouble(1), d2 = s5 * 0.25D, d1 = d3 + d2; u = max(max(u, p), d1);
/*      */     
/* 1463 */     if (haveSub == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1485 */       mixedPtr1.memcpy(RenderOffsetElement(sup, 0.0D, u, draw, mc, gc, dd), 36);
/* 1486 */       mixedPtr3.memcpy(CombineBBoxes(mixedPtr3.copyOf(36), mixedPtr1.copyOf(36)), 36); } else { SetSubStyle(style, mc, gc); mixedPtr2.memcpy(RenderElement(sub, 0, mc, gc, dd), 36); v = max(v, s17); double d10 = mixedPtr1.getAlignedDouble(1), d9 = u - d10, d8 = mixedPtr2.getDouble() - v, d7 = d9 - d8, d6 = theta * 4.0D; if (d7 < d6) { double d13 = s5 * 0.8D, d12 = mixedPtr1.getAlignedDouble(1), d11 = u - d12; psi = d13 - d11; if (psi > 0.0D) { u += psi; v -= psi; }  }  if (draw != 0)
/*      */         PMoveTo(savedX, savedY, mc);  double d5 = -v; mixedPtr2.memcpy(RenderOffsetElement(sub, width, d5, draw, mc, gc, dd), 36); if (draw != 0)
/* 1488 */         PMoveTo(savedX, savedY, mc);  SetSupStyle(style, mc, gc); double d4 = width + delta; mixedPtr1.memcpy(RenderOffsetElement(sup, d4, u, draw, mc, gc, dd), 36); mixedPtr3.memcpy(CombineAlignedBBoxes(mixedPtr3.copyOf(36), mixedPtr2.copyOf(36)), 36); mixedPtr3.memcpy(CombineAlignedBBoxes(mixedPtr3.copyOf(36), mixedPtr1.copyOf(36)), 36); }  if (draw != 0)
/* 1489 */       PMoveTo(mixedPtr3.getAlignedDouble(2) + savedX, savedY, mc); 
/* 1490 */     SetStyle(style, mc, gc);
/* 1491 */     mixedPtr4.memcpy((Ptr)mixedPtr3, 36); return (Ptr)mixedPtr4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int WideTildeAtom(SEXP expr) {
/* 1509 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("widetilde\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderWideTilde(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1515 */     y = new double[11]; x = new double[11]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); savedlwd = 0.0D; savedlty = 0; baseY = 0.0D; baseX = 0.0D; c = 0.0D; hatHeight = 0.0D; accentGap = 0.0D; start = 0.0D; delta = 0.0D; totalwidth = 0.0D; height = 0.0D; savedY = 0.0D; savedX = 0.0D; savedX = mc.getDouble(28);
/* 1516 */     savedY = mc.getDouble(36);
/* 1517 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 1518 */     height = mixedPtr1.getDouble();
/*      */     
/* 1520 */     double d4 = mixedPtr1.getAlignedDouble(2), d3 = mixedPtr1.getAlignedDouble(3); totalwidth = d4 + d3;
/* 1521 */     delta = totalwidth * 0.9D / 8.0D;
/* 1522 */     start = totalwidth * 0.05D;
/* 1523 */     accentGap = XHeight(gc, dd) * 0.2D;
/* 1524 */     hatHeight = XHeight(gc, dd) * 0.15D;
/* 1525 */     c = 0.7853981633974483D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1530 */     if (draw != 0) {
/* 1531 */       savedlty = gc.getAlignedInt(6);
/* 1532 */       savedlwd = gc.getAlignedDouble(2);
/* 1533 */       baseX = savedX;
/* 1534 */       baseY = savedY + height + accentGap;
/* 1535 */       PMoveTo(baseX, baseY, mc);
/* 1536 */       double d9 = ConvertedX(mc, dd); x[0] = d9;
/* 1537 */       double d8 = ConvertedY(mc, dd); y[0] = d8;
/* 1538 */       for (i = 0; i <= 8; i++) {
/* 1539 */         xval = i * delta + start;
/* 1540 */         double d14 = hatHeight * 0.5D, d13 = Mathlib.sin(i * c) + 1.0D; yval = d14 * d13;
/* 1541 */         double d12 = baseY + yval; PMoveTo(baseX + xval, d12, mc);
/* 1542 */         int k = i + 1; double d11 = ConvertedX(mc, dd); x[k] = d11;
/* 1543 */         int j = i + 1; double d10 = ConvertedY(mc, dd); y[j] = d10;
/*      */       } 
/* 1545 */       double d7 = baseY + hatHeight; PMoveTo(baseX + totalwidth, d7, mc);
/* 1546 */       double d6 = ConvertedX(mc, dd); x[10] = d6;
/* 1547 */       double d5 = ConvertedY(mc, dd); y[10] = d5;
/* 1548 */       gc.setAlignedInt(6, 0);
/* 1549 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 1550 */         gc.setAlignedDouble(2, 1.0D); 
/* 1551 */       baseEngine__.GEPolyline(11, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1552 */       PMoveTo(savedX + totalwidth, savedY, mc);
/* 1553 */       gc.setAlignedInt(6, savedlty);
/* 1554 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/* 1556 */     double d2 = mixedPtr1.getAlignedDouble(1), d1 = height + accentGap + hatHeight; mixedPtr2.memcpy(MakeBBox(d1, d2, totalwidth), 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int WideHatAtom(SEXP expr) {
/* 1562 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("widehat\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderWideHat(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1568 */     y = new double[3]; x = new double[3]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); savedX = mc.getDouble(28);
/* 1569 */     savedY = mc.getDouble(36);
/* 1570 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 1571 */     accentGap = XHeight(gc, dd) * 0.2D;
/* 1572 */     hatHeight = XHeight(gc, dd) * 0.3D;
/* 1573 */     double d3 = mixedPtr1.getAlignedDouble(2), d2 = mixedPtr1.getAlignedDouble(3); totalwidth = d3 + d2;
/* 1574 */     height = mixedPtr1.getDouble();
/* 1575 */     width = mixedPtr1.getAlignedDouble(2);
/*      */ 
/*      */     
/* 1578 */     if (draw != 0) {
/* 1579 */       savedlty = gc.getAlignedInt(6);
/* 1580 */       savedlwd = gc.getAlignedDouble(2);
/* 1581 */       double d10 = savedY + height + accentGap; PMoveTo(savedX, d10, mc);
/* 1582 */       double d9 = ConvertedX(mc, dd); x[0] = d9;
/* 1583 */       double d8 = ConvertedY(mc, dd); y[0] = d8;
/* 1584 */       PMoveAcross(totalwidth * 0.5D, mc);
/* 1585 */       PMoveUp(hatHeight, mc);
/* 1586 */       double d7 = ConvertedX(mc, dd); x[1] = d7;
/* 1587 */       double d6 = ConvertedY(mc, dd); y[1] = d6;
/* 1588 */       PMoveAcross(totalwidth * 0.5D, mc);
/* 1589 */       PMoveUp(-hatHeight, mc);
/* 1590 */       double d5 = ConvertedX(mc, dd); x[2] = d5;
/* 1591 */       double d4 = ConvertedY(mc, dd); y[2] = d4;
/* 1592 */       gc.setAlignedInt(6, 0);
/* 1593 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 1594 */         gc.setAlignedDouble(2, 1.0D); 
/* 1595 */       baseEngine__.GEPolyline(3, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1596 */       PMoveTo(savedX + width, savedY, mc);
/* 1597 */       gc.setAlignedInt(6, savedlty);
/* 1598 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/* 1600 */     double d1 = accentGap + hatHeight; mixedPtr2.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), d1, 0.0D, 0.0D), 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int BarAtom(SEXP expr) {
/* 1605 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("bar\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderBar(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1611 */     y = new double[2]; x = new double[2]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); savedX = mc.getDouble(28);
/* 1612 */     savedY = mc.getDouble(36);
/* 1613 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 1614 */     accentGap = XHeight(gc, dd) * 0.2D;
/*      */     
/* 1616 */     height = mixedPtr1.getDouble();
/* 1617 */     width = mixedPtr1.getAlignedDouble(2);
/* 1618 */     offset = mixedPtr1.getAlignedDouble(3);
/*      */ 
/*      */     
/* 1621 */     if (draw != 0) {
/* 1622 */       savedlty = gc.getAlignedInt(6);
/* 1623 */       savedlwd = gc.getAlignedDouble(2);
/* 1624 */       double d5 = savedY + height + accentGap; PMoveTo(savedX + offset, d5, mc);
/* 1625 */       double d4 = ConvertedX(mc, dd); x[0] = d4;
/* 1626 */       double d3 = ConvertedY(mc, dd); y[0] = d3;
/* 1627 */       PMoveAcross(width, mc);
/* 1628 */       double d2 = ConvertedX(mc, dd); x[1] = d2;
/* 1629 */       double d1 = ConvertedY(mc, dd); y[1] = d1;
/* 1630 */       gc.setAlignedInt(6, 0);
/* 1631 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 1632 */         gc.setAlignedDouble(2, 1.0D); 
/* 1633 */       baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1634 */       PMoveTo(savedX + width, savedY, mc);
/* 1635 */       gc.setAlignedInt(6, savedlty);
/* 1636 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/* 1638 */     mixedPtr2.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), accentGap, 0.0D, 0.0D), 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int AccentCode(SEXP expr) {
/*      */     int j;
/* 1656 */     i = 0; while (true) { if (Context.get__plotmath$AccentTable().getInt(i * 8 + 4) == 0) {
/*      */ 
/*      */         
/* 1659 */         boolean bool = false; break;
/*      */       }  Ptr ptr = Context.get__plotmath$AccentTable().getPointer(i * 8); if (NameMatch(expr, ptr) == 0) {
/*      */         i++; continue;
/*      */       }  j = Context.get__plotmath$AccentTable().getInt(i * 8 + 4); break; }
/*      */     
/* 1664 */     return j; } public static int AccentAtom(SEXP expr) { return (NameAtom(expr) == 0 || AccentCode(expr) == 0) ? 0 : 1; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void InvalidAccent(SEXP expr) {
/* 1669 */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderAccent(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1676 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36); savedX = mc.getDouble(28);
/* 1677 */     savedY = mc.getDouble(36);
/*      */ 
/*      */ 
/*      */     
/* 1681 */     if (Rinternals.Rf_length(expr) != 2)
/* 1682 */       InvalidAccent(expr); 
/* 1683 */     accent = Rinternals.CAR(expr);
/* 1684 */     body = Rinternals.CADR(expr);
/* 1685 */     code = AccentCode(accent);
/* 1686 */     if (code == 0)
/* 1687 */       InvalidAccent(expr); 
/* 1688 */     mixedPtr2.memcpy(RenderElement(body, 0, mc, gc, dd), 36);
/* 1689 */     italic = mixedPtr2.getAlignedDouble(3);
/* 1690 */     if (code != 176 && code != 215)
/*      */     
/*      */     { 
/*      */       
/* 1694 */       mixedPtr1.memcpy(RenderChar(code, 0, mc, gc, dd), 36); } else { mixedPtr1.memcpy(RenderSymbolChar(code, 0, mc, gc, dd), 36); }
/* 1695 */      double d11 = mixedPtr1.getAlignedDouble(2), d10 = mixedPtr2.getAlignedDouble(2), d9 = mixedPtr2.getAlignedDouble(3); width = max(d10 + d9, d11);
/*      */     
/* 1697 */     double d8 = mixedPtr2.getAlignedDouble(2); xoffset = (width - d8) * 0.5D;
/* 1698 */     mixedPtr2.memcpy(RenderGap(xoffset, draw, mc, gc, dd), 36);
/* 1699 */     mixedPtr4.memcpy(RenderElement(body, draw, mc, gc, dd), 36); mixedPtr2.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr4.copyOf(36)), 36);
/* 1700 */     mixedPtr3.memcpy(RenderGap(xoffset, draw, mc, gc, dd), 36); mixedPtr2.memcpy(CombineBBoxes(mixedPtr2.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 1701 */     PMoveTo(savedX, savedY, mc);
/* 1702 */     double d7 = mixedPtr1.getAlignedDouble(2), d6 = (width - d7) * 0.5D;
/* 1703 */     double d5 = italic * 0.9D; xoffset = d6 + d5;
/* 1704 */     double d4 = mixedPtr2.getDouble(), d3 = mixedPtr1.getAlignedDouble(1), d2 = d4 + d3;
/* 1705 */     double d1 = XHeight(gc, dd) * 0.1D; yoffset = d2 + d1;
/* 1706 */     if (draw != 0) {
/* 1707 */       double d = savedY + yoffset; PMoveTo(savedX + xoffset, d, mc);
/* 1708 */       if (code != 176 && code != 215)
/*      */       
/*      */       { 
/*      */         
/* 1712 */         RenderChar(code, draw, mc, gc, dd); } else { RenderSymbolChar(code, draw, mc, gc, dd); }
/*      */     
/* 1714 */     }  mixedPtr2.memcpy(CombineOffsetBBoxes(mixedPtr2.copyOf(36), 0, mixedPtr1.copyOf(36), 0, xoffset, yoffset), 36);
/*      */     
/* 1716 */     if (draw != 0)
/* 1717 */       PMoveTo(savedX + width, savedY, mc); 
/* 1718 */     mixedPtr5.memcpy((Ptr)mixedPtr2, 36); return (Ptr)mixedPtr5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void NumDenomVShift(Ptr numBBox, Ptr denomBBox, Ptr u, Ptr v, Ptr mc, Ptr gc, Ptr dd) {
/* 1735 */     a = TeX(17, gc, dd);
/* 1736 */     theta = TeX(18, gc, dd);
/* 1737 */     if (mc.getAlignedInt(17) <= 6)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/* 1743 */       double d10 = TeX(4, gc, dd); u.setDouble(d10);
/* 1744 */       double d9 = TeX(7, gc, dd); v.setDouble(d9);
/* 1745 */       phi = theta; }
/*      */     else { double d10 = TeX(3, gc, dd); u.setDouble(d10); double d9 = TeX(6, gc, dd); v.setDouble(d9); phi = theta * 3.0D; }
/* 1747 */      double d8 = u.getDouble(), d7 = numBBox.getAlignedDouble(1), d6 = d8 - d7, d5 = theta * 0.5D + a; delta = d6 - d5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1753 */     if (delta < phi) {
/* 1754 */       double d11 = u.getDouble(), d10 = phi - delta, d9 = d11 + d10; u.setDouble(d9);
/* 1755 */     }  double d4 = theta * 0.5D + a, d3 = denomBBox.getDouble(), d2 = v.getDouble(), d1 = d3 - d2; delta = d4 - d1;
/* 1756 */     if (delta < phi) {
/* 1757 */       double d11 = v.getDouble(), d10 = phi - delta, d9 = d11 + d10; v.setDouble(d9);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void NumDenomHShift(Ptr numBBox, Ptr denomBBox, Ptr numShift, Ptr denomShift) {
/* 1763 */     numWidth = numBBox.getAlignedDouble(2);
/* 1764 */     denomWidth = denomBBox.getAlignedDouble(2);
/* 1765 */     if (numWidth <= denomWidth) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1770 */       double d1 = (denomWidth - numWidth) / 2.0D; numShift.setDouble(d1);
/* 1771 */       denomShift.setDouble(0.0D);
/*      */       return;
/*      */     } 
/*      */     numShift.setDouble(0.0D);
/*      */     double d = (numWidth - denomWidth) / 2.0D;
/*      */     denomShift.setDouble(d);
/*      */   } public static Ptr RenderFraction(SEXP expr, int rule, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1778 */     y = new double[2]; x = new double[2]; dVShift = new double[1]; nVShift = new double[1]; dHShift = new double[1]; nHShift = new double[1]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36); dVShift[0] = 0.0D; nVShift[0] = 0.0D; dHShift[0] = 0.0D; nHShift[0] = 0.0D; numerator = Rinternals.CADR(expr);
/* 1779 */     denominator = Rinternals.CADDR(expr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1784 */     savedX = mc.getDouble(28);
/* 1785 */     savedY = mc.getDouble(36);
/*      */ 
/*      */     
/* 1788 */     style = GetStyle(mc);
/* 1789 */     SetNumStyle(style, mc, gc);
/* 1790 */     mixedPtr4.memcpy(RenderElement(numerator, 0, mc, gc, dd), 36); mixedPtr2.memcpy(RenderItalicCorr(mixedPtr4.copyOf(36), 0, mc, gc, dd), 36);
/*      */     
/* 1792 */     SetDenomStyle(style, mc, gc);
/* 1793 */     mixedPtr3.memcpy(RenderElement(denominator, 0, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr3.copyOf(36), 0, mc, gc, dd), 36);
/*      */     
/* 1795 */     SetStyle(style, mc, gc);
/*      */     
/* 1797 */     double d2 = mixedPtr1.getAlignedDouble(2); width = max(mixedPtr2.getAlignedDouble(2), d2);
/* 1798 */     NumDenomHShift(mixedPtr2.copyOf(36), mixedPtr1.copyOf(36), (Ptr)new DoublePtr(nHShift, 0), (Ptr)new DoublePtr(dHShift, 0));
/* 1799 */     NumDenomVShift(mixedPtr2.copyOf(36), mixedPtr1.copyOf(36), (Ptr)new DoublePtr(nVShift, 0), (Ptr)new DoublePtr(dVShift, 0), mc, gc, dd);
/*      */     
/* 1801 */     mc.setDouble(28, savedX);
/* 1802 */     mc.setDouble(36, savedY);
/* 1803 */     SetNumStyle(style, mc, gc);
/* 1804 */     nVShift$27 = nVShift[0]; nHShift$28 = nHShift[0]; mixedPtr2.memcpy(RenderOffsetElement(numerator, nHShift$28, nVShift$27, draw, mc, gc, dd), 36);
/*      */ 
/*      */     
/* 1807 */     mc.setDouble(28, savedX);
/* 1808 */     mc.setDouble(36, savedY);
/* 1809 */     SetDenomStyle(style, mc, gc);
/* 1810 */     double d1 = -dVShift[0]; dHShift$30 = dHShift[0]; mixedPtr1.memcpy(RenderOffsetElement(denominator, dHShift$30, d1, draw, mc, gc, dd), 36);
/*      */ 
/*      */     
/* 1813 */     SetStyle(style, mc, gc);
/*      */     
/* 1815 */     if (draw != 0) {
/* 1816 */       if (rule != 0) {
/* 1817 */         savedlty = gc.getAlignedInt(6);
/* 1818 */         savedlwd = gc.getAlignedDouble(2);
/* 1819 */         mc.setDouble(28, savedX);
/* 1820 */         mc.setDouble(36, savedY);
/* 1821 */         PMoveUp(AxisHeight(gc, dd), mc);
/* 1822 */         double d6 = ConvertedX(mc, dd); x[0] = d6;
/* 1823 */         double d5 = ConvertedY(mc, dd); y[0] = d5;
/* 1824 */         PMoveAcross(width, mc);
/* 1825 */         double d4 = ConvertedX(mc, dd); x[1] = d4;
/* 1826 */         double d3 = ConvertedY(mc, dd); y[1] = d3;
/* 1827 */         gc.setAlignedInt(6, 0);
/* 1828 */         if (gc.getAlignedDouble(2) > 1.0D)
/* 1829 */           gc.setAlignedDouble(2, 1.0D); 
/* 1830 */         baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1831 */         PMoveUp(-AxisHeight(gc, dd), mc);
/* 1832 */         gc.setAlignedInt(6, savedlty);
/* 1833 */         gc.setAlignedDouble(2, savedlwd);
/*      */       } 
/* 1835 */       PMoveTo(savedX + width, savedY, mc);
/*      */     } 
/* 1837 */     mixedPtr5.memcpy(CombineAlignedBBoxes(mixedPtr2.copyOf(36), mixedPtr1.copyOf(36)), 36); return (Ptr)mixedPtr5;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderUnderline(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1843 */     y = new double[2]; x = new double[2]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36); body = Rinternals.CADR(expr);
/*      */ 
/*      */     
/* 1846 */     savedX = mc.getDouble(28);
/* 1847 */     savedY = mc.getDouble(36);
/*      */     
/* 1849 */     mixedPtr2.memcpy(RenderElement(body, 0, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr2.copyOf(36), 0, mc, gc, dd), 36);
/* 1850 */     width = mixedPtr1.getAlignedDouble(2);
/*      */     
/* 1852 */     mc.setDouble(28, savedX);
/* 1853 */     mc.setDouble(36, savedY);
/* 1854 */     mixedPtr1.memcpy(RenderElement(body, draw, mc, gc, dd), 36);
/* 1855 */     adepth = XHeight(gc, dd) * 0.1D;
/* 1856 */     depth = mixedPtr1.getAlignedDouble(1) + adepth;
/*      */     
/* 1858 */     if (draw != 0) {
/* 1859 */       savedlty = gc.getAlignedInt(6);
/* 1860 */       savedlwd = gc.getAlignedDouble(2);
/* 1861 */       mc.setDouble(28, savedX);
/* 1862 */       mc.setDouble(36, savedY);
/* 1863 */       PMoveUp(-depth, mc);
/* 1864 */       double d4 = ConvertedX(mc, dd); x[0] = d4;
/* 1865 */       double d3 = ConvertedY(mc, dd); y[0] = d3;
/* 1866 */       PMoveAcross(width, mc);
/* 1867 */       double d2 = ConvertedX(mc, dd); x[1] = d2;
/* 1868 */       double d1 = ConvertedY(mc, dd); y[1] = d1;
/* 1869 */       gc.setAlignedInt(6, 0);
/* 1870 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 1871 */         gc.setAlignedDouble(2, 1.0D); 
/* 1872 */       baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 1873 */       PMoveUp(depth, mc);
/* 1874 */       gc.setAlignedInt(6, savedlty);
/* 1875 */       gc.setAlignedDouble(2, savedlwd);
/* 1876 */       PMoveTo(savedX + width, savedY, mc);
/*      */     } 
/* 1878 */     mixedPtr3.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), 0.0D, adepth, 0.0D), 36); return (Ptr)mixedPtr3;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int OverAtom(SEXP expr) {
/* 1884 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 1885 */       NameMatch(expr, (Ptr)new BytePtr("over\000".getBytes(), 0)) == 0 && NameMatch(expr, (Ptr)new BytePtr("frac\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderOver(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1891 */     MixedPtr mixedPtr = MixedPtr.malloc(36); mixedPtr.memcpy(RenderFraction(expr, 1, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int UnderlAtom(SEXP expr) {
/* 1896 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("underline\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderUnderl(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1902 */     MixedPtr mixedPtr = MixedPtr.malloc(36); mixedPtr.memcpy(RenderUnderline(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int AtopAtom(SEXP expr) {
/* 1908 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("atop\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderAtop(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1914 */     MixedPtr mixedPtr = MixedPtr.malloc(36); mixedPtr.memcpy(RenderFraction(expr, 0, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int DelimCode(SEXP expr, SEXP head) {
/* 1931 */     code = 0;
/* 1932 */     if (NameAtom(head) == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1942 */       if (StringAtom(head) != 0 && Rinternals.Rf_length(head) > 0)
/* 1943 */         if (StringMatch(head, (Ptr)new BytePtr("|\000".getBytes(), 0)) == 0)
/*      */         
/* 1945 */         { if (StringMatch(head, (Ptr)new BytePtr("||\000".getBytes(), 0)) == 0)
/*      */           
/* 1947 */           { if (StringMatch(head, (Ptr)new BytePtr("(\000".getBytes(), 0)) == 0)
/*      */             
/* 1949 */             { if (StringMatch(head, (Ptr)new BytePtr(")\000".getBytes(), 0)) == 0)
/*      */               
/* 1951 */               { if (StringMatch(head, (Ptr)new BytePtr("[\000".getBytes(), 0)) == 0)
/*      */                 
/* 1953 */                 { if (StringMatch(head, (Ptr)new BytePtr("]\000".getBytes(), 0)) == 0)
/*      */                   
/* 1955 */                   { if (StringMatch(head, (Ptr)new BytePtr("{\000".getBytes(), 0)) == 0)
/*      */                     
/* 1957 */                     { if (StringMatch(head, (Ptr)new BytePtr("}\000".getBytes(), 0)) == 0)
/*      */                       
/* 1959 */                       { if (StringMatch(head, (Ptr)new BytePtr("\000".getBytes(), 0)) != 0 || StringMatch(head, (Ptr)new BytePtr(".\000".getBytes(), 0)) != 0)
/* 1960 */                           code = 46;  } else { code = 125; }  } else { code = 123; }  } else { code = 93; }  } else { code = 91; }  } else { code = 41; }  } else { code = 40; }  } else { code = 124; }  } else { code = 124; }   } else { if (NameMatch(head, (Ptr)new BytePtr("lfloor\000".getBytes(), 0)) == 0) { if (NameMatch(head, (Ptr)new BytePtr("rfloor\000".getBytes(), 0)) != 0)
/*      */           code = 251;  } else { code = 235; }  if (NameMatch(head, (Ptr)new BytePtr("lceil\000".getBytes(), 0)) == 0) { if (NameMatch(head, (Ptr)new BytePtr("rceil\000".getBytes(), 0)) != 0)
/* 1962 */           code = 249;  } else { code = 233; }  }  if (code != 0)
/*      */     {
/* 1964 */       return code;
/*      */     }
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr RenderDelimiter(int delim, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1971 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); savecex = gc.getDouble(44);
/* 1972 */     double d = gc.getDouble(44) * 1.25D; gc.setDouble(44, d);
/* 1973 */     mixedPtr1.memcpy(RenderSymbolChar(delim, draw, mc, gc, dd), 36);
/* 1974 */     gc.setDouble(44, savecex);
/* 1975 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int GroupAtom(SEXP expr) {
/* 1980 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("group\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderGroup(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 1986 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); cexSaved = gc.getDouble(44);
/*      */ 
/*      */     
/* 1989 */     if (Rinternals.Rf_length(expr) == 4) {
/*      */       
/* 1991 */       mixedPtr1.memcpy(NullBBox(), 36);
/* 1992 */       SEXP sEXP3 = Rinternals.CADR(expr); code = DelimCode(expr, sEXP3);
/* 1993 */       double d2 = gc.getDouble(44) * 1.25D; gc.setDouble(44, d2);
/* 1994 */       if (code != 46)
/* 1995 */         mixedPtr1.memcpy(RenderSymbolChar(code, draw, mc, gc, dd), 36); 
/* 1996 */       gc.setDouble(44, cexSaved);
/* 1997 */       SEXP sEXP2 = Rinternals.CADDR(expr); mixedPtr3.memcpy(RenderElement(sEXP2, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 1998 */       mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 1999 */       SEXP sEXP1 = Rinternals.CADDDR(expr); code = DelimCode(expr, sEXP1);
/* 2000 */       double d1 = gc.getDouble(44) * 1.25D; gc.setDouble(44, d1);
/* 2001 */       if (code != 46) {
/* 2002 */         mixedPtr2.memcpy(RenderSymbolChar(code, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2003 */       }  gc.setDouble(44, cexSaved);
/* 2004 */       mixedPtr4.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr4;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */   public static int BGroupAtom(SEXP expr) {
/* 2009 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("bgroup\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderDelim(int which, double dist, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2015 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36); delta = 0.0D; ybot = 0.0D; extShift = 0.0D; n = 0; mid = 0; ext = 0; bot = 0; top = 0; prev = 0; savedY = 0.0D; savedX = 0.0D; savedX = mc.getDouble(28);
/* 2016 */     savedY = mc.getDouble(36);
/* 2017 */     prev = SetFont(5, gc);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2023 */     axisHeight = TeX(17, gc, dd);
/*      */     
/* 2025 */     switch (which) {
/*      */       case 46:
/* 2027 */         SetFont(prev, gc);
/* 2028 */         mixedPtr6.memcpy(NullBBox(), 36);
/*      */         return (Ptr)mixedPtr6;
/*      */       case 124:
/* 2031 */         top = 239; ext = 239; bot = 239; mid = 0;
/*      */         break;
/*      */       case 40:
/* 2034 */         top = 230; ext = 231; bot = 232; mid = 0;
/*      */         break;
/*      */       case 41:
/* 2037 */         top = 246; ext = 247; bot = 248; mid = 0;
/*      */         break;
/*      */       case 91:
/* 2040 */         top = 233; ext = 234; bot = 235; mid = 0;
/*      */         break;
/*      */       case 93:
/* 2043 */         top = 249; ext = 250; bot = 251; mid = 0;
/*      */         break;
/*      */       case 123:
/* 2046 */         top = 236; ext = 239; bot = 238; mid = 237;
/*      */         break;
/*      */       case 125:
/* 2049 */         top = 252; ext = 239; bot = 254; mid = 253;
/*      */         break;
/*      */       default:
/* 2052 */         throw new UnsatisfiedLinkException("_");
/*      */     } 
/*      */     
/* 2055 */     mixedPtr4.memcpy(GlyphBBox(top, gc, dd), 36);
/* 2056 */     mixedPtr2.memcpy(GlyphBBox(ext, gc, dd), 36);
/* 2057 */     mixedPtr3.memcpy(GlyphBBox(bot, gc, dd), 36);
/* 2058 */     if (which != 123 && which != 125)
/*      */     
/*      */     { 
/*      */ 
/*      */       
/* 2063 */       double d9 = mixedPtr4.getDouble(), d8 = mixedPtr4.getAlignedDouble(1); if ((d9 + d8) * 0.8D > dist)
/* 2064 */       { double d11 = mixedPtr4.getDouble(), d10 = mixedPtr4.getAlignedDouble(1); dist = (d11 + d10) * 0.8D; }  } else { double d9 = mixedPtr4.getDouble(), d8 = mixedPtr4.getAlignedDouble(1); if ((d9 + d8) * 1.2D > dist) { double d11 = mixedPtr4.getDouble(), d10 = mixedPtr3.getAlignedDouble(1); dist = (d11 + d10) * 1.2D; }
/*      */        }
/* 2066 */      double d7 = mixedPtr2.getDouble(), d6 = mixedPtr2.getAlignedDouble(1); extHeight = d7 + d6;
/* 2067 */     double d5 = mixedPtr4.getDouble(); topShift = dist - d5 + axisHeight;
/* 2068 */     double d4 = mixedPtr3.getAlignedDouble(1); botShift = dist - d4 - axisHeight;
/* 2069 */     double d3 = mixedPtr2.getDouble(), d2 = mixedPtr2.getAlignedDouble(1); extShift = (d3 - d2) * 0.5D;
/* 2070 */     mixedPtr4.memcpy(ShiftBBox(mixedPtr4.copyOf(36), topShift), 36);
/* 2071 */     double d1 = -botShift; mixedPtr3.memcpy(ShiftBBox(mixedPtr3.copyOf(36), d1), 36);
/* 2072 */     mixedPtr5.memcpy(CombineAlignedBBoxes(mixedPtr4.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2073 */     if (which != 123 && which != 125)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2090 */       if (draw != 0) {
/*      */         
/* 2092 */         double d19 = savedY + topShift; PMoveTo(savedX, d19, mc);
/* 2093 */         RenderSymbolChar(top, draw, mc, gc, dd);
/* 2094 */         double d18 = savedY - botShift; PMoveTo(savedX, d18, mc);
/* 2095 */         RenderSymbolChar(bot, draw, mc, gc, dd);
/*      */         
/* 2097 */         double d17 = axisHeight + dist;
/* 2098 */         double d16 = mixedPtr4.getDouble(), d15 = mixedPtr4.getAlignedDouble(1), d14 = d16 + d15; ytop = d17 - d14;
/* 2099 */         double d13 = axisHeight - dist;
/* 2100 */         double d12 = mixedPtr3.getDouble(), d11 = mixedPtr3.getAlignedDouble(1), d10 = d12 + d11; ybot = d13 + d10;
/* 2101 */         double d9 = ytop - ybot, d8 = extHeight * 0.99D; n = (int)Mathlib.ceil(d9 / d8);
/* 2102 */         if (n > 0) {
/* 2103 */           double d21 = ytop - ybot, d20 = n; delta = d21 / d20;
/* 2104 */           for (i = 0; i < n; i++) {
/* 2105 */             double d24 = savedY + ybot;
/* 2106 */             double d23 = (i + 0.5D) * delta; double d22 = d24 + d23 - extShift; PMoveTo(savedX, d22, mc);
/* 2107 */             RenderSymbolChar(ext, draw, mc, gc, dd);
/*      */           } 
/*      */         } 
/* 2110 */         PMoveTo(mixedPtr5.getAlignedDouble(2) + savedX, savedY, mc);
/*      */       }  }
/*      */     else { mixedPtr1.memcpy(GlyphBBox(mid, gc, dd), 36); double d10 = mixedPtr1.getDouble(), d9 = mixedPtr1.getAlignedDouble(1), d8 = (d10 - d9) * 0.5D; midShift = axisHeight - d8; mixedPtr1.memcpy(ShiftBBox(mixedPtr1.copyOf(36), midShift), 36); mixedPtr5.memcpy(CombineAlignedBBoxes(mixedPtr5.copyOf(36), mixedPtr1.copyOf(36)), 36); if (draw != 0) { double d13 = savedY + topShift; PMoveTo(savedX, d13, mc); RenderSymbolChar(top, draw, mc, gc, dd); double d12 = savedY + midShift; PMoveTo(savedX, d12, mc); RenderSymbolChar(mid, draw, mc, gc, dd); double d11 = savedY - botShift; PMoveTo(savedX, d11, mc); RenderSymbolChar(bot, draw, mc, gc, dd); PMoveTo(mixedPtr5.getAlignedDouble(2) + savedX, savedY, mc); }
/*      */        }
/* 2114 */      SetFont(prev, gc);
/* 2115 */     mixedPtr6.memcpy((Ptr)mixedPtr5, 36);
/*      */     return (Ptr)mixedPtr6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderBGroup(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2123 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); axisHeight = TeX(17, gc, dd);
/* 2124 */     extra = xHeight(gc, dd) * 0.2D;
/*      */     
/* 2126 */     if (Rinternals.Rf_length(expr) == 4) {
/*      */       
/* 2128 */       mixedPtr1.memcpy(NullBBox(), 36);
/* 2129 */       SEXP sEXP4 = Rinternals.CADR(expr); delim1 = DelimCode(expr, sEXP4);
/* 2130 */       SEXP sEXP3 = Rinternals.CADDDR(expr); delim2 = DelimCode(expr, sEXP3);
/* 2131 */       SEXP sEXP2 = Rinternals.CADDR(expr); mixedPtr1.memcpy(RenderElement(sEXP2, 0, mc, gc, dd), 36);
/* 2132 */       double d3 = mixedPtr1.getAlignedDouble(1) + axisHeight; dist = max(mixedPtr1.getDouble() - axisHeight, d3);
/* 2133 */       double d2 = dist + extra; mixedPtr1.memcpy(RenderDelim(delim1, d2, draw, mc, gc, dd), 36);
/* 2134 */       SEXP sEXP1 = Rinternals.CADDR(expr); mixedPtr3.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2135 */       mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 2136 */       double d1 = dist + extra; mixedPtr2.memcpy(RenderDelim(delim2, d1, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/*      */       
/* 2138 */       mixedPtr4.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr4;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ParenAtom(SEXP expr) {
/* 2149 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("(\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderParen(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2156 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36); mixedPtr1.memcpy(RenderDelimiter(40, draw, mc, gc, dd), 36);
/* 2157 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr3.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2158 */     mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 2159 */     mixedPtr2.memcpy(RenderDelimiter(41, draw, mc, gc, dd), 36); mixedPtr4.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36); return (Ptr)mixedPtr4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int IntAtom(SEXP expr) {
/* 2170 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("integral\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderIntSymbol(int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2177 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36); savedX = mc.getDouble(28);
/* 2178 */     savedY = mc.getDouble(36);
/* 2179 */     if (GetStyle(mc) <= 6) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2199 */       mixedPtr5.memcpy(RenderSymbolChar(242, draw, mc, gc, dd), 36); return (Ptr)mixedPtr5;
/*      */     }  mixedPtr2.memcpy(RenderSymbolChar(243, 0, mc, gc, dd), 36); mixedPtr1.memcpy(RenderSymbolChar(245, 0, mc, gc, dd), 36); double d4 = TeX(17, gc, dd), d3 = mixedPtr2.getAlignedDouble(1) * 0.99D; shift = d4 + d3; PMoveUp(shift, mc); mixedPtr4.memcpy(RenderSymbolChar(243, draw, mc, gc, dd), 36); mixedPtr2.memcpy(ShiftBBox(mixedPtr4.copyOf(36), shift), 36); mc.setDouble(28, savedX); mc.setDouble(36, savedY); double d2 = TeX(17, gc, dd), d1 = mixedPtr1.getDouble() * 0.99D; shift = d2 - d1; PMoveUp(shift, mc); mixedPtr3.memcpy(RenderSymbolChar(245, draw, mc, gc, dd), 36); mixedPtr1.memcpy(ShiftBBox(mixedPtr3.copyOf(36), shift), 36); if (draw == 0) {
/*      */       PMoveTo(savedX, savedY, mc);
/*      */     } else {
/*      */       double d = mixedPtr1.getAlignedDouble(2);
/*      */       PMoveTo(max(mixedPtr2.getAlignedDouble(2), d) + savedX, savedY, mc);
/*      */     } 
/*      */     mixedPtr5.memcpy(CombineAlignedBBoxes(mixedPtr2.copyOf(36), mixedPtr1.copyOf(36)), 36);
/* 2207 */     return (Ptr)mixedPtr5; } public static Ptr RenderInt(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36); nexpr = Rinternals.Rf_length(expr);
/* 2208 */     style = GetStyle(mc);
/* 2209 */     savedX = mc.getDouble(28);
/* 2210 */     savedY = mc.getDouble(36);
/*      */ 
/*      */     
/* 2213 */     mixedPtr4.memcpy(RenderIntSymbol(draw, mc, gc, dd), 36);
/* 2214 */     width = mixedPtr4.getAlignedDouble(2);
/* 2215 */     mc.setDouble(28, savedX);
/* 2216 */     mc.setDouble(36, savedY);
/* 2217 */     if (nexpr > 2) {
/* 2218 */       double d5 = width * 0.5D, d4 = ThinSpace(gc, dd); hshift = d5 + d4;
/* 2219 */       SetSubStyle(style, mc, gc);
/* 2220 */       SEXP sEXP2 = Rinternals.CADDR(expr); mixedPtr3.memcpy(RenderElement(sEXP2, 0, mc, gc, dd), 36);
/* 2221 */       double d3 = mixedPtr4.getAlignedDouble(1), d2 = CenterShift(mixedPtr3.copyOf(36)); vshift = d3 + d2;
/* 2222 */       double d1 = -vshift; SEXP sEXP1 = Rinternals.CADDR(expr); mixedPtr3.memcpy(RenderOffsetElement(sEXP1, hshift, d1, draw, mc, gc, dd), 36);
/*      */       
/* 2224 */       mixedPtr4.memcpy(CombineAlignedBBoxes(mixedPtr4.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2225 */       SetStyle(style, mc, gc);
/* 2226 */       mc.setDouble(28, savedX);
/* 2227 */       mc.setDouble(36, savedY);
/*      */     } 
/* 2229 */     if (nexpr > 3) {
/* 2230 */       hshift = ThinSpace(gc, dd) + width;
/* 2231 */       SetSupStyle(style, mc, gc);
/* 2232 */       SEXP sEXP2 = Rinternals.CADDDR(expr); mixedPtr2.memcpy(RenderElement(sEXP2, 0, mc, gc, dd), 36);
/* 2233 */       double d2 = mixedPtr4.getDouble(), d1 = CenterShift(mixedPtr2.copyOf(36)); vshift = d2 - d1;
/* 2234 */       SEXP sEXP1 = Rinternals.CADDDR(expr); mixedPtr2.memcpy(RenderOffsetElement(sEXP1, hshift, vshift, draw, mc, gc, dd), 36);
/*      */       
/* 2236 */       mixedPtr4.memcpy(CombineAlignedBBoxes(mixedPtr4.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2237 */       SetStyle(style, mc, gc);
/* 2238 */       mc.setDouble(28, savedX);
/* 2239 */       mc.setDouble(36, savedY);
/*      */     } 
/* 2241 */     PMoveAcross(mixedPtr4.getAlignedDouble(2), mc);
/* 2242 */     if (nexpr > 1) {
/* 2243 */       SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2244 */       mixedPtr4.memcpy(CombineBBoxes(mixedPtr4.copyOf(36), mixedPtr1.copyOf(36)), 36);
/*      */     } 
/* 2246 */     mixedPtr5.memcpy((Ptr)mixedPtr4, 36); return (Ptr)mixedPtr5; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int OpAtom(SEXP expr) {
/*      */     int j;
/* 2276 */     i = 0; while (true) { if (Context.get__plotmath$OpTable().getInt(i * 8 + 4) == 0) {
/*      */ 
/*      */         
/* 2279 */         boolean bool = false; break;
/*      */       }  Ptr ptr = Context.get__plotmath$OpTable().getPointer(i * 8); if (NameMatch(expr, ptr) == 0) {
/*      */         i++; continue;
/*      */       } 
/*      */       j = Context.get__plotmath$OpTable().getInt(i * 8 + 4);
/*      */       break; }
/*      */     
/* 2286 */     return j; } public static Ptr RenderOpSymbol(SEXP op, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); cexSaved = gc.getDouble(44);
/*      */ 
/*      */ 
/*      */     
/* 2290 */     display = (GetStyle(mc) <= 6) ? 0 : 1;
/* 2291 */     opId = OpAtom(op);
/*      */     
/* 2293 */     if (opId != 229 && opId != 213 && opId != 200 && 
/* 2294 */       opId != 199) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2311 */       prevfont = SetFont(1, gc);
/* 2312 */       BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.PRINTNAME(op)); mixedPtr1.memcpy(RenderStr((Ptr)bytePtr, draw, mc, gc, dd), 36);
/* 2313 */       SetFont(prevfont, gc);
/* 2314 */       mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */     }  if (display == 0) {
/*      */       mixedPtr2.memcpy(RenderSymbolChar(opId, draw, mc, gc, dd), 36); return (Ptr)mixedPtr2;
/*      */     }  double d6 = gc.getDouble(44) * 1.25D; gc.setDouble(44, d6); int i = OpAtom(op); mixedPtr1.memcpy(RenderSymbolChar(i, 0, mc, gc, dd), 36); double d5 = mixedPtr1.getDouble(), d4 = mixedPtr1.getAlignedDouble(1), d3 = (d5 - d4) * 0.5D; double d2 = TeX(17, gc, dd); shift = d3 - d2; if (draw != 0) {
/*      */       PMoveUp(-shift, mc); mixedPtr1.memcpy(RenderSymbolChar(opId, 1, mc, gc, dd), 36); PMoveUp(shift, mc);
/*      */     }  gc.setDouble(44, cexSaved); double d1 = -shift;
/*      */     mixedPtr2.memcpy(ShiftBBox(mixedPtr1.copyOf(36), d1), 36);
/* 2321 */     return (Ptr)mixedPtr2; } public static Ptr RenderOp(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36), mixedPtr7 = MixedPtr.malloc(36); mixedPtr4.memcpy(NullBBox(), 36); mixedPtr3.memcpy(NullBBox(), 36);
/* 2322 */     savedX = mc.getDouble(28);
/* 2323 */     savedY = mc.getDouble(36);
/* 2324 */     nexpr = Rinternals.Rf_length(expr);
/* 2325 */     style = GetStyle(mc);
/* 2326 */     SEXP sEXP3 = Rinternals.CAR(expr); mixedPtr1.memcpy(RenderOpSymbol(sEXP3, 0, mc, gc, dd), 36);
/* 2327 */     width = mixedPtr1.getAlignedDouble(2);
/*      */     
/* 2329 */     lvshift = uvshift = 0.0D;
/* 2330 */     if (nexpr > 2) {
/* 2331 */       SetSubStyle(style, mc, gc);
/* 2332 */       SEXP sEXP = Rinternals.CADDR(expr); mixedPtr4.memcpy(RenderElement(sEXP, 0, mc, gc, dd), 36);
/* 2333 */       SetStyle(style, mc, gc);
/* 2334 */       double d10 = mixedPtr4.getAlignedDouble(2); width = max(width, d10);
/* 2335 */       double d9 = TeX(22, gc, dd);
/* 2336 */       double d8 = mixedPtr4.getDouble(); double d7 = d9 - d8; lvshift = max(TeX(20, gc, dd), d7);
/* 2337 */       double d6 = mixedPtr1.getAlignedDouble(1), d5 = mixedPtr4.getDouble(); lvshift = d6 + d5 + lvshift;
/*      */     } 
/* 2339 */     if (nexpr > 3) {
/* 2340 */       SetSupStyle(style, mc, gc);
/* 2341 */       SEXP sEXP = Rinternals.CADDDR(expr); mixedPtr3.memcpy(RenderElement(sEXP, 0, mc, gc, dd), 36);
/* 2342 */       SetStyle(style, mc, gc);
/* 2343 */       double d10 = mixedPtr3.getAlignedDouble(2); width = max(width, d10);
/* 2344 */       double d9 = TeX(21, gc, dd);
/* 2345 */       double d8 = mixedPtr3.getAlignedDouble(1); double d7 = d9 - d8; uvshift = max(TeX(19, gc, dd), d7);
/* 2346 */       double d6 = mixedPtr1.getDouble(), d5 = mixedPtr3.getAlignedDouble(1); uvshift = d6 + d5 + uvshift;
/*      */     } 
/* 2348 */     double d4 = mixedPtr1.getAlignedDouble(2); hshift = (width - d4) * 0.5D;
/* 2349 */     mixedPtr1.memcpy(RenderGap(hshift, draw, mc, gc, dd), 36);
/* 2350 */     SEXP sEXP2 = Rinternals.CAR(expr); mixedPtr6.memcpy(RenderOpSymbol(sEXP2, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr6.copyOf(36)), 36);
/*      */     
/* 2352 */     mc.setDouble(28, savedX);
/* 2353 */     mc.setDouble(36, savedY);
/* 2354 */     if (nexpr > 2) {
/* 2355 */       SetSubStyle(style, mc, gc);
/* 2356 */       double d6 = mixedPtr4.getAlignedDouble(2); hshift = (width - d6) * 0.5D;
/* 2357 */       double d5 = -lvshift; SEXP sEXP = Rinternals.CADDR(expr); mixedPtr4.memcpy(RenderOffsetElement(sEXP, hshift, d5, draw, mc, gc, dd), 36);
/*      */       
/* 2359 */       SetStyle(style, mc, gc);
/* 2360 */       mixedPtr1.memcpy(CombineAlignedBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/* 2361 */       mc.setDouble(28, savedX);
/* 2362 */       mc.setDouble(36, savedY);
/*      */     } 
/* 2364 */     if (nexpr > 3) {
/* 2365 */       SetSupStyle(style, mc, gc);
/* 2366 */       double d = mixedPtr3.getAlignedDouble(2); hshift = (width - d) * 0.5D;
/* 2367 */       SEXP sEXP = Rinternals.CADDDR(expr); mixedPtr3.memcpy(RenderOffsetElement(sEXP, hshift, uvshift, draw, mc, gc, dd), 36);
/*      */       
/* 2369 */       SetStyle(style, mc, gc);
/* 2370 */       mixedPtr1.memcpy(CombineAlignedBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2371 */       mc.setDouble(28, savedX);
/* 2372 */       mc.setDouble(36, savedY);
/*      */     } 
/* 2374 */     double d3 = TeX(23, gc, dd), d2 = TeX(23, gc, dd); mixedPtr1.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), d2, d3, 0.0D), 36);
/* 2375 */     if (draw != 0)
/* 2376 */       PMoveAcross(width, mc); 
/* 2377 */     double d1 = ThinSpace(gc, dd); mixedPtr5.memcpy(RenderGap(d1, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36);
/*      */     
/* 2379 */     SEXP sEXP1 = Rinternals.CADR(expr); mixedPtr2.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36);
/* 2380 */     mixedPtr7.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36); return (Ptr)mixedPtr7; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int RadicalAtom(SEXP expr) {
/* 2400 */     if (NameAtom(expr) == 0) return 0; 
/* 2401 */     if (NameMatch(expr, (Ptr)new BytePtr("root\000".getBytes(), 0)) == 0)
/* 2402 */       if (NameMatch(expr, (Ptr)new BytePtr("sqrt\000".getBytes(), 0)) == 0) {
/*      */         return 0;
/*      */       } 
/*      */     return 1;
/*      */   }
/*      */   
/*      */   public static Ptr RenderScript(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2409 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); style = GetStyle(mc);
/* 2410 */     SetSupStyle(style, mc, gc);
/* 2411 */     mixedPtr1.memcpy(RenderElement(expr, draw, mc, gc, dd), 36);
/* 2412 */     SetStyle(style, mc, gc);
/* 2413 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderRadical(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2419 */     y = new double[5]; x = new double[5]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36); body = Rinternals.CADR(expr);
/* 2420 */     order = Rinternals.CADDR(expr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2426 */     style = GetStyle(mc);
/* 2427 */     savedX = mc.getDouble(28);
/* 2428 */     savedY = mc.getDouble(36);
/*      */ 
/*      */     
/* 2431 */     radGap = xHeight(gc, dd) * 0.4D;
/* 2432 */     radSpace = xHeight(gc, dd) * 0.2D;
/* 2433 */     radTrail = MuSpace(gc, dd);
/* 2434 */     SetPrimeStyle(style, mc, gc);
/* 2435 */     mixedPtr2.memcpy(RenderElement(body, 0, mc, gc, dd), 36);
/* 2436 */     mixedPtr2.memcpy(RenderItalicCorr(mixedPtr2.copyOf(36), 0, mc, gc, dd), 36);
/*      */     
/* 2438 */     radWidth = XHeight(gc, dd) * 0.6D;
/* 2439 */     radHeight = mixedPtr2.getDouble() + radGap;
/* 2440 */     twiddleHeight = CenterShift(mixedPtr2.copyOf(36));
/*      */     
/* 2442 */     leadWidth = radWidth;
/* 2443 */     leadHeight = radHeight;
/* 2444 */     R_NilValue$18 = Rinternals.R_NilValue; if (order != R_NilValue$18) {
/* 2445 */       SetSupStyle(style, mc, gc);
/* 2446 */       mixedPtr1.memcpy(RenderScript(order, 0, mc, gc, dd), 36);
/* 2447 */       double d12 = mixedPtr1.getAlignedDouble(2), d11 = radWidth * 0.4D, d10 = d12 + d11; leadWidth = max(leadWidth, d10);
/* 2448 */       double d9 = mixedPtr1.getAlignedDouble(2), d8 = leadWidth - d9, d7 = radWidth * 0.4D; hshift = d8 - d7;
/* 2449 */       double d6 = mixedPtr1.getDouble(); vshift = leadHeight - d6;
/* 2450 */       double d5 = mixedPtr1.getAlignedDouble(1), d4 = vshift - d5, d3 = twiddleHeight + radGap; if (d4 < d3)
/* 2451 */         vshift = mixedPtr1.getAlignedDouble(1) + twiddleHeight + radGap; 
/* 2452 */       if (draw != 0) {
/* 2453 */         double d = savedY + vshift; PMoveTo(savedX + hshift, d, mc);
/* 2454 */         mixedPtr1.memcpy(RenderScript(order, draw, mc, gc, dd), 36);
/*      */       } 
/* 2456 */       mixedPtr1.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), vshift, 0.0D, hshift), 36);
/*      */     } else {
/*      */       
/* 2459 */       mixedPtr1.memcpy(NullBBox(), 36);
/* 2460 */     }  if (draw != 0) {
/* 2461 */       savedlty = gc.getAlignedInt(6);
/* 2462 */       savedlwd = gc.getAlignedDouble(2);
/* 2463 */       PMoveTo(savedX + leadWidth - radWidth, savedY, mc);
/* 2464 */       PMoveUp(twiddleHeight * 0.8D, mc);
/* 2465 */       double d14 = ConvertedX(mc, dd); x[0] = d14;
/* 2466 */       double d13 = ConvertedY(mc, dd); y[0] = d13;
/* 2467 */       PMoveUp(twiddleHeight * 0.2D, mc);
/* 2468 */       PMoveAcross(radWidth * 0.3D, mc);
/* 2469 */       double d12 = ConvertedX(mc, dd); x[1] = d12;
/* 2470 */       double d11 = ConvertedY(mc, dd); y[1] = d11;
/* 2471 */       PMoveUp(-(mixedPtr2.getAlignedDouble(1) + twiddleHeight), mc);
/* 2472 */       PMoveAcross(radWidth * 0.3D, mc);
/* 2473 */       double d10 = ConvertedX(mc, dd); x[2] = d10;
/* 2474 */       double d9 = ConvertedY(mc, dd); y[2] = d9;
/* 2475 */       double d8 = mixedPtr2.getAlignedDouble(1), d7 = mixedPtr2.getDouble(); PMoveUp(d8 + d7 + radGap, mc);
/* 2476 */       PMoveAcross(radWidth * 0.4D, mc);
/* 2477 */       double d6 = ConvertedX(mc, dd); x[3] = d6;
/* 2478 */       double d5 = ConvertedY(mc, dd); y[3] = d5;
/* 2479 */       PMoveAcross(mixedPtr2.getAlignedDouble(2) + radSpace + radTrail, mc);
/* 2480 */       double d4 = ConvertedX(mc, dd); x[4] = d4;
/* 2481 */       double d3 = ConvertedY(mc, dd); y[4] = d3;
/* 2482 */       gc.setAlignedInt(6, 0);
/* 2483 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 2484 */         gc.setAlignedDouble(2, 1.0D); 
/* 2485 */       baseEngine__.GEPolyline(5, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 2486 */       PMoveTo(savedX, savedY, mc);
/* 2487 */       gc.setAlignedInt(6, savedlty);
/* 2488 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/*      */     
/* 2491 */     double d2 = leadWidth + radSpace; mixedPtr5.memcpy(RenderGap(d2, draw, mc, gc, dd), 36);
/*      */     mixedPtr1.memcpy(CombineAlignedBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36);
/* 2493 */     SetPrimeStyle(style, mc, gc);
/* 2494 */     mixedPtr4.memcpy(RenderElement(body, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/*      */     
/* 2496 */     double d1 = radTrail * 2.0D; mixedPtr3.memcpy(RenderGap(d1, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/*      */     
/* 2498 */     mixedPtr1.memcpy(EnlargeBBox(mixedPtr1.copyOf(36), radGap, 0.0D, 0.0D), 36);
/* 2499 */     SetStyle(style, mc, gc);
/* 2500 */     mixedPtr6.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int AbsAtom(SEXP expr) {
/* 2511 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("abs\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderAbs(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2517 */     y = new double[2]; x = new double[2]; MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36); SEXP sEXP2 = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP2, 0, mc, gc, dd), 36);
/* 2518 */     height = mixedPtr1.getDouble();
/* 2519 */     depth = mixedPtr1.getAlignedDouble(1);
/*      */ 
/*      */     
/* 2522 */     double d5 = MuSpace(gc, dd); mixedPtr1.memcpy(RenderGap(d5, draw, mc, gc, dd), 36);
/* 2523 */     if (draw != 0) {
/* 2524 */       i = gc.getAlignedInt(6);
/* 2525 */       d1 = gc.getAlignedDouble(2);
/* 2526 */       PMoveUp(-depth, mc);
/* 2527 */       double d9 = ConvertedX(mc, dd); x[0] = d9;
/* 2528 */       double d8 = ConvertedY(mc, dd); y[0] = d8;
/* 2529 */       PMoveUp(depth + height, mc);
/* 2530 */       double d7 = ConvertedX(mc, dd); x[1] = d7;
/* 2531 */       double d6 = ConvertedY(mc, dd); y[1] = d6;
/* 2532 */       gc.setAlignedInt(6, 0);
/* 2533 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 2534 */         gc.setAlignedDouble(2, 1.0D); 
/* 2535 */       baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 2536 */       PMoveUp(-height, mc);
/* 2537 */       gc.setAlignedInt(6, i);
/* 2538 */       gc.setAlignedDouble(2, d1);
/*      */     } 
/* 2540 */     double d4 = MuSpace(gc, dd); mixedPtr5.memcpy(RenderGap(d4, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36);
/* 2541 */     SEXP sEXP1 = Rinternals.CADR(expr); mixedPtr4.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/* 2542 */     mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 2543 */     double d3 = MuSpace(gc, dd); mixedPtr3.memcpy(RenderGap(d3, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2544 */     if (draw != 0) {
/* 2545 */       savedlty = gc.getAlignedInt(6);
/* 2546 */       savedlwd = gc.getAlignedDouble(2);
/* 2547 */       PMoveUp(-depth, mc);
/* 2548 */       double d9 = ConvertedX(mc, dd); x[0] = d9;
/* 2549 */       double d8 = ConvertedY(mc, dd); y[0] = d8;
/* 2550 */       PMoveUp(depth + height, mc);
/* 2551 */       double d7 = ConvertedX(mc, dd); x[1] = d7;
/* 2552 */       double d6 = ConvertedY(mc, dd); y[1] = d6;
/* 2553 */       gc.setAlignedInt(6, 0);
/* 2554 */       if (gc.getAlignedDouble(2) > 1.0D)
/* 2555 */         gc.setAlignedDouble(2, 1.0D); 
/* 2556 */       baseEngine__.GEPolyline(2, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), gc, dd);
/* 2557 */       PMoveUp(-height, mc);
/* 2558 */       gc.setAlignedInt(6, savedlty);
/* 2559 */       gc.setAlignedDouble(2, savedlwd);
/*      */     } 
/* 2561 */     double d2 = MuSpace(gc, dd); mixedPtr2.memcpy(RenderGap(d2, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2562 */     mixedPtr6.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int CurlyAtom(SEXP expr) {
/* 2573 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 2574 */       NameMatch(expr, (Ptr)new BytePtr("{\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderCurly(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2580 */     MixedPtr mixedPtr = MixedPtr.malloc(36); SEXP sEXP = Rinternals.CADR(expr); mixedPtr.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int RelAtom(SEXP expr) {
/*      */     int j;
/* 2630 */     i = 0; while (true) { if (Context.get__plotmath$RelTable().getInt(i * 8 + 4) == 0) {
/*      */ 
/*      */         
/* 2633 */         boolean bool = false; break;
/*      */       }  Ptr ptr = Context.get__plotmath$RelTable().getPointer(i * 8); if (NameMatch(expr, ptr) == 0) {
/*      */         i++; continue;
/*      */       }  j = Context.get__plotmath$RelTable().getInt(i * 8 + 4);
/*      */       break; }
/*      */     
/* 2639 */     return j; } public static Ptr RenderRel(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36); op = RelAtom(Rinternals.CAR(expr));
/* 2640 */     if (Rinternals.Rf_length(expr) != 
/*      */ 
/*      */ 
/*      */       
/* 2644 */       3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2654 */       throw new UnsatisfiedLinkException("_"); }  if (mc.getAlignedInt(17) <= 4) {
/*      */       iftmp$15 = 0.0D;
/*      */     } else {
/*      */       iftmp$15 = ThickSpace(gc, dd);
/*      */     }  gap = iftmp$15; SEXP sEXP2 = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP2, draw, mc, gc, dd), 36); mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/*      */     mixedPtr5.memcpy(RenderGap(gap, draw, mc, gc, dd), 36);
/*      */     mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36);
/*      */     mixedPtr4.memcpy(RenderSymbolChar(op, draw, mc, gc, dd), 36);
/*      */     mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/*      */     mixedPtr3.memcpy(RenderGap(gap, draw, mc, gc, dd), 36);
/*      */     mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/*      */     SEXP sEXP1 = Rinternals.CADDR(expr);
/*      */     mixedPtr2.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36);
/*      */     mixedPtr6.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2668 */     return (Ptr)mixedPtr6; } public static int BoldAtom(SEXP expr) { return (NameAtom(expr) == 0) ? 0 : ((
/* 2669 */       NameMatch(expr, (Ptr)new BytePtr("bold\000".getBytes(), 0)) == 0) ? 0 : 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderBold(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2676 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(2, gc);
/* 2677 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2678 */     SetFont(prevfont, gc);
/* 2679 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ItalicAtom(SEXP expr) {
/* 2690 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 2691 */       NameMatch(expr, (Ptr)new BytePtr("italic\000".getBytes(), 0)) == 0 && NameMatch(expr, (Ptr)new BytePtr("math\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderItalic(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2698 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(3, gc);
/* 2699 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2700 */     SetFont(prevfont, gc);
/* 2701 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int PlainAtom(SEXP expr) {
/* 2712 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 2713 */       NameMatch(expr, (Ptr)new BytePtr("plain\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderPlain(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2720 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(1, gc);
/* 2721 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2722 */     SetFont(prevfont, gc);
/* 2723 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int SymbolFaceAtom(SEXP expr) {
/* 2740 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 2741 */       NameMatch(expr, (Ptr)new BytePtr("symbol\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderSymbolFace(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2748 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(5, gc);
/* 2749 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2750 */     SetFont(prevfont, gc);
/* 2751 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int BoldItalicAtom(SEXP expr) {
/* 2762 */     return (NameAtom(expr) == 0) ? 0 : ((
/* 2763 */       NameMatch(expr, (Ptr)new BytePtr("bolditalic\000".getBytes(), 0)) == 0 && NameMatch(expr, (Ptr)new BytePtr("boldmath\000".getBytes(), 0)) == 0) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderBoldItalic(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2770 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevfont = SetFont(4, gc);
/* 2771 */     SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2772 */     SetFont(prevfont, gc);
/* 2773 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int StyleAtom(SEXP expr) {
/* 2784 */     if (NameAtom(expr) == 0) return 0; 
/* 2785 */     if (NameMatch(expr, (Ptr)new BytePtr("displaystyle\000".getBytes(), 0)) == 0)
/* 2786 */       if (NameMatch(expr, (Ptr)new BytePtr("textstyle\000".getBytes(), 0)) == 0)
/* 2787 */         if (NameMatch(expr, (Ptr)new BytePtr("scriptstyle\000".getBytes(), 0)) == 0)
/* 2788 */           if (NameMatch(expr, (Ptr)new BytePtr("scriptscriptstyle\000".getBytes(), 0)) == 0)
/*      */             return 0;    
/*      */     return 1;
/*      */   }
/*      */   
/*      */   public static Ptr RenderStyle(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2794 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); prevstyle = GetStyle(mc);
/*      */     
/* 2796 */     if (NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("displaystyle\000".getBytes(), 0)) == 0)
/*      */     
/* 2798 */     { if (NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("textstyle\000".getBytes(), 0)) == 0)
/*      */       
/* 2800 */       { if (NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("scriptstyle\000".getBytes(), 0)) == 0)
/*      */         
/* 2802 */         { if (NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("scriptscriptstyle\000".getBytes(), 0)) != 0)
/* 2803 */             SetStyle(2, mc, gc);  } else { SetStyle(4, mc, gc); }  } else { SetStyle(6, mc, gc); }  } else { SetStyle(8, mc, gc); }
/* 2804 */      SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36);
/* 2805 */     SetStyle(prevstyle, mc, gc);
/* 2806 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int PhantomAtom(SEXP expr) {
/* 2817 */     if (NameAtom(expr) == 0) return 0; 
/* 2818 */     if (NameMatch(expr, (Ptr)new BytePtr("phantom\000".getBytes(), 0)) == 0)
/* 2819 */       if (NameMatch(expr, (Ptr)new BytePtr("vphantom\000".getBytes(), 0)) == 0)
/*      */         return 0;  
/*      */     return 1;
/*      */   }
/*      */   
/*      */   public static Ptr RenderPhantom(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2825 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); SEXP sEXP = Rinternals.CADR(expr); mixedPtr1.memcpy(RenderElement(sEXP, 0, mc, gc, dd), 36);
/* 2826 */     if (NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("vphantom\000".getBytes(), 0)) == 0)
/*      */     
/*      */     { 
/*      */       
/* 2830 */       RenderGap(mixedPtr1.getAlignedDouble(2), draw, mc, gc, dd); } else { mixedPtr1.setAlignedDouble(2, 0.0D); mixedPtr1.setAlignedDouble(3, 0.0D); }
/* 2831 */      mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ConcatenateAtom(SEXP expr) {
/* 2842 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("paste\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderConcatenate(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2848 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36); n = 0; mixedPtr1.memcpy(NullBBox(), 36);
/*      */ 
/*      */     
/* 2851 */     expr = Rinternals.CDR(expr);
/* 2852 */     n = Rinternals.Rf_length(expr);
/*      */     
/* 2854 */     for (i = 0; i < n; i++) {
/* 2855 */       SEXP sEXP = Rinternals.CAR(expr); mixedPtr2.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2856 */       if (n + -1 != i)
/* 2857 */         mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36); 
/* 2858 */       expr = Rinternals.CDR(expr);
/*      */     } 
/* 2860 */     mixedPtr3.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderCommaList(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2872 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36), mixedPtr6 = MixedPtr.malloc(36), mixedPtr7 = MixedPtr.malloc(36), mixedPtr8 = MixedPtr.malloc(36), mixedPtr9 = MixedPtr.malloc(36); n = 0; small = 0.0D; mixedPtr1.memcpy(NullBBox(), 36);
/* 2873 */     small = ThinSpace(gc, dd) * 0.4D;
/*      */     
/* 2875 */     n = Rinternals.Rf_length(expr);
/* 2876 */     for (i = 0; i < n; i++) {
/* 2877 */       if (NameAtom(Rinternals.CAR(expr)) == 0 || NameMatch(Rinternals.CAR(expr), (Ptr)new BytePtr("...\000".getBytes(), 0)) == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2889 */         if (i > 0) {
/* 2890 */           mixedPtr4.memcpy(RenderSymbolChar(44, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/*      */           
/* 2892 */           mixedPtr3.memcpy(RenderSymbolChar(32, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/*      */         } 
/*      */         
/* 2895 */         SEXP sEXP = Rinternals.CAR(expr); mixedPtr2.memcpy(RenderElement(sEXP, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36); }
/*      */       else { if (i > 0) { mixedPtr8.memcpy(RenderSymbolChar(44, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr8.copyOf(36)), 36); mixedPtr7.memcpy(RenderSymbolChar(32, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr7.copyOf(36)), 36); }
/*      */          mixedPtr6.memcpy(RenderSymbolChar(188, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr6.copyOf(36)), 36); mixedPtr5.memcpy(RenderGap(small, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr5.copyOf(36)), 36); }
/* 2898 */        expr = Rinternals.CDR(expr);
/*      */     } 
/* 2900 */     mixedPtr9.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr9;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderExpression(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2913 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36), mixedPtr3 = MixedPtr.malloc(36), mixedPtr4 = MixedPtr.malloc(36), mixedPtr5 = MixedPtr.malloc(36); if (NameAtom(Rinternals.CAR(expr)) == 0)
/*      */     
/*      */     { 
/* 2916 */       SEXP sEXP1 = Rinternals.CAR(expr); mixedPtr1.memcpy(RenderElement(sEXP1, draw, mc, gc, dd), 36); } else { SEXP sEXP1 = Rinternals.CAR(expr); mixedPtr1.memcpy(RenderSymbolString(sEXP1, draw, mc, gc, dd), 36); }
/* 2917 */      mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 2918 */     mixedPtr4.memcpy(RenderDelimiter(40, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr4.copyOf(36)), 36);
/* 2919 */     SEXP sEXP = Rinternals.CDR(expr); mixedPtr3.memcpy(RenderCommaList(sEXP, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr3.copyOf(36)), 36);
/* 2920 */     mixedPtr1.memcpy(RenderItalicCorr(mixedPtr1.copyOf(36), draw, mc, gc, dd), 36);
/* 2921 */     mixedPtr2.memcpy(RenderDelimiter(41, draw, mc, gc, dd), 36); mixedPtr1.memcpy(CombineBBoxes(mixedPtr1.copyOf(36), mixedPtr2.copyOf(36)), 36);
/* 2922 */     mixedPtr5.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ListAtom(SEXP expr) {
/* 2933 */     return (NameAtom(expr) == 0 || NameMatch(expr, (Ptr)new BytePtr("list\000".getBytes(), 0)) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderList(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2939 */     MixedPtr mixedPtr = MixedPtr.malloc(36); SEXP sEXP = Rinternals.CDR(expr); mixedPtr.memcpy(RenderCommaList(sEXP, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RenderFormula(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 2948 */     MixedPtr mixedPtr = MixedPtr.malloc(36); head = Rinternals.CAR(expr);
/*      */     
/* 2950 */     if (SpaceAtom(head) == 0) {
/*      */       
/* 2952 */       if (BinAtom(head) == 0) {
/*      */         
/* 2954 */         if (SuperAtom(head) == 0) {
/*      */           
/* 2956 */           if (SubAtom(head) == 0) {
/*      */             
/* 2958 */             if (WideTildeAtom(head) == 0) {
/*      */               
/* 2960 */               if (WideHatAtom(head) == 0) {
/*      */                 
/* 2962 */                 if (BarAtom(head) == 0) {
/*      */                   
/* 2964 */                   if (AccentAtom(head) == 0) {
/*      */                     
/* 2966 */                     if (OverAtom(head) == 0) {
/*      */                       
/* 2968 */                       if (UnderlAtom(head) == 0) {
/*      */                         
/* 2970 */                         if (AtopAtom(head) == 0)
/*      */                         
/* 2972 */                         { if (ParenAtom(head) == 0)
/*      */                           
/* 2974 */                           { if (BGroupAtom(head) == 0)
/*      */                             
/* 2976 */                             { if (GroupAtom(head) == 0)
/*      */                               
/* 2978 */                               { if (IntAtom(head) == 0)
/*      */                                 
/* 2980 */                                 { if (OpAtom(head) == 0)
/*      */                                   
/* 2982 */                                   { if (RadicalAtom(head) == 0)
/*      */                                     
/* 2984 */                                     { if (AbsAtom(head) == 0)
/*      */                                       
/* 2986 */                                       { if (CurlyAtom(head) == 0)
/*      */                                         
/* 2988 */                                         { if (RelAtom(head) == 0)
/*      */                                           
/* 2990 */                                           { if (BoldAtom(head) == 0)
/*      */                                             
/* 2992 */                                             { if (ItalicAtom(head) == 0)
/*      */                                               
/* 2994 */                                               { if (PlainAtom(head) == 0)
/*      */                                                 
/* 2996 */                                                 { if (SymbolFaceAtom(head) == 0)
/*      */                                                   
/* 2998 */                                                   { if (BoldItalicAtom(head) == 0)
/*      */                                                     
/* 3000 */                                                     { if (StyleAtom(head) == 0)
/*      */                                                       
/* 3002 */                                                       { if (PhantomAtom(head) == 0)
/*      */                                                         
/* 3004 */                                                         { if (ConcatenateAtom(head) == 0)
/*      */                                                           
/* 3006 */                                                           { if (ListAtom(head) == 0)
/*      */                                                             
/*      */                                                             { 
/* 3009 */                                                               mixedPtr.memcpy(RenderExpression(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderList(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderConcatenate(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderPhantom(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderStyle(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderBoldItalic(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderSymbolFace(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderPlain(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderItalic(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderBold(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderRel(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderCurly(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderAbs(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderRadical(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderOp(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderInt(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderGroup(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderBGroup(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderParen(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; }  mixedPtr.memcpy(RenderAtop(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */                       }  mixedPtr.memcpy(RenderUnderl(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */                     }  mixedPtr.memcpy(RenderOver(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */                   }  mixedPtr.memcpy(RenderAccent(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */                 }  mixedPtr.memcpy(RenderBar(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */               }  mixedPtr.memcpy(RenderWideHat(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */             }  mixedPtr.memcpy(RenderWideTilde(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */           }  mixedPtr.memcpy(RenderSub(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */         }  mixedPtr.memcpy(RenderSup(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/*      */       }  mixedPtr.memcpy(RenderBin(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr;
/* 3019 */     }  mixedPtr.memcpy(RenderSpace(expr, draw, mc, gc, dd), 36); return (Ptr)mixedPtr; } public static Ptr RenderElement(SEXP expr, int draw, Ptr mc, Ptr gc, Ptr dd) { MixedPtr mixedPtr = MixedPtr.malloc(36); if (FormulaExpression(expr) == 0) {
/*      */ 
/*      */       
/* 3022 */       mixedPtr.memcpy(RenderAtom(expr, draw, mc, gc, dd), 36);
/*      */       return (Ptr)mixedPtr;
/*      */     } 
/*      */     mixedPtr.memcpy(RenderFormula(expr, draw, mc, gc, dd), 36);
/*      */     return (Ptr)mixedPtr; }
/*      */ 
/*      */   
/*      */   public static Ptr RenderOffsetElement(SEXP expr, double x, double y, int draw, Ptr mc, Ptr gc, Ptr dd) {
/* 3030 */     MixedPtr mixedPtr1 = MixedPtr.malloc(36), mixedPtr2 = MixedPtr.malloc(36); savedX = mc.getDouble(28);
/* 3031 */     savedY = mc.getDouble(36);
/* 3032 */     if (draw != 0) {
/* 3033 */       double d5 = mc.getDouble(28) + x; mc.setDouble(28, d5);
/* 3034 */       double d4 = mc.getDouble(36) + y; mc.setDouble(36, d4);
/*      */     } 
/* 3036 */     mixedPtr1.memcpy(RenderElement(expr, draw, mc, gc, dd), 36);
/* 3037 */     double d3 = mixedPtr1.getAlignedDouble(2) + x; mixedPtr1.setAlignedDouble(2, d3);
/* 3038 */     double d2 = mixedPtr1.getDouble() + y; mixedPtr1.setDouble(d2);
/* 3039 */     double d1 = mixedPtr1.getAlignedDouble(1) - y; mixedPtr1.setAlignedDouble(1, d1);
/* 3040 */     mc.setDouble(28, savedX);
/* 3041 */     mc.setDouble(36, savedY);
/* 3042 */     mixedPtr2.memcpy((Ptr)mixedPtr1, 36); return (Ptr)mixedPtr2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double GEExpressionWidth(SEXP expr, Ptr gc, Ptr dd) {
/* 3062 */     MixedPtr mixedPtr1 = MixedPtr.malloc(72), mixedPtr2 = MixedPtr.malloc(36); double d = gc.getDouble(44); mixedPtr1.setDouble(4, d);
/* 3063 */     mixedPtr1.setInt(-3424001);
/* 3064 */     mixedPtr1.setAlignedInt(17, 8);
/*      */ 
/*      */ 
/*      */     
/* 3068 */     mixedPtr1.setDouble(12, 0.0D);
/* 3069 */     mixedPtr1.setDouble(20, 0.0D);
/* 3070 */     mixedPtr1.setDouble(28, 0.0D);
/* 3071 */     mixedPtr1.setDouble(36, 0.0D);
/* 3072 */     mixedPtr1.setDouble(44, 0.0D);
/* 3073 */     mixedPtr1.setDouble(52, 0.0D);
/* 3074 */     mixedPtr1.setDouble(60, 0.0D);
/*      */     
/* 3076 */     SetFont(1, gc);
/* 3077 */     mixedPtr2.memcpy(RenderElement(expr, 0, (Ptr)mixedPtr1, gc, dd), 36);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3087 */     return Math.abs(baseEngine__.GEtoDeviceWidth(mixedPtr2.getAlignedDouble(2), 2, dd));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double GEExpressionHeight(SEXP expr, Ptr gc, Ptr dd) {
/* 3101 */     MixedPtr mixedPtr1 = MixedPtr.malloc(72), mixedPtr2 = MixedPtr.malloc(36); double d3 = gc.getDouble(44); mixedPtr1.setDouble(4, d3);
/* 3102 */     mixedPtr1.setInt(-3424001);
/* 3103 */     mixedPtr1.setAlignedInt(17, 8);
/*      */ 
/*      */ 
/*      */     
/* 3107 */     mixedPtr1.setDouble(12, 0.0D);
/* 3108 */     mixedPtr1.setDouble(20, 0.0D);
/* 3109 */     mixedPtr1.setDouble(28, 0.0D);
/* 3110 */     mixedPtr1.setDouble(36, 0.0D);
/* 3111 */     mixedPtr1.setDouble(44, 0.0D);
/* 3112 */     mixedPtr1.setDouble(52, 0.0D);
/* 3113 */     mixedPtr1.setDouble(60, 0.0D);
/*      */     
/* 3115 */     SetFont(1, gc);
/* 3116 */     mixedPtr2.memcpy(RenderElement(expr, 0, (Ptr)mixedPtr1, gc, dd), 36);
/* 3117 */     double d2 = mixedPtr2.getDouble(), d1 = mixedPtr2.getAlignedDouble(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3125 */     return Math.abs(baseEngine__.GEtoDeviceHeight(d2 + d1, 2, dd));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEExpressionMetric(SEXP expr, Ptr gc, Ptr ascent, Ptr descent, Ptr width, Ptr dd) {
/* 3139 */     MixedPtr mixedPtr1 = MixedPtr.malloc(72), mixedPtr2 = MixedPtr.malloc(36); double d4 = gc.getDouble(44); mixedPtr1.setDouble(4, d4);
/* 3140 */     mixedPtr1.setInt(-3424001);
/* 3141 */     mixedPtr1.setAlignedInt(17, 8);
/*      */ 
/*      */ 
/*      */     
/* 3145 */     mixedPtr1.setDouble(12, 0.0D);
/* 3146 */     mixedPtr1.setDouble(20, 0.0D);
/* 3147 */     mixedPtr1.setDouble(28, 0.0D);
/* 3148 */     mixedPtr1.setDouble(36, 0.0D);
/* 3149 */     mixedPtr1.setDouble(44, 0.0D);
/* 3150 */     mixedPtr1.setDouble(52, 0.0D);
/* 3151 */     mixedPtr1.setDouble(60, 0.0D);
/*      */     
/* 3153 */     SetFont(1, gc);
/* 3154 */     mixedPtr2.memcpy(RenderElement(expr, 0, (Ptr)mixedPtr1, gc, dd), 36);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3162 */     double d3 = Math.abs(baseEngine__.GEtoDeviceWidth(mixedPtr2.getAlignedDouble(2), 2, dd)); width.setDouble(d3);
/* 3163 */     double d2 = Math.abs(baseEngine__.GEtoDeviceHeight(mixedPtr2.getDouble(), 2, dd)); ascent.setDouble(d2);
/* 3164 */     double d1 = Math.abs(baseEngine__.GEtoDeviceHeight(mixedPtr2.getAlignedDouble(1), 2, dd)); descent.setDouble(d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEMathText(double x, double y, SEXP expr, double xc, double yc, double rot, Ptr gc, Ptr dd) {
/* 3178 */     width = new double[1]; descent = new double[1]; ascent = new double[1]; MixedPtr mixedPtr1 = MixedPtr.malloc(72), mixedPtr2 = MixedPtr.malloc(36); width[0] = 0.0D; descent[0] = 0.0D; ascent[0] = 0.0D; baseEngine__.GEMetricInfo(77, gc, (Ptr)new DoublePtr(ascent, 0), (Ptr)new DoublePtr(descent, 0), (Ptr)new DoublePtr(width, 0), dd);
/* 3179 */     if (ascent[0] != 0.0D || descent[0] != 0.0D || width[0] != 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3185 */       double d5 = gc.getDouble(44); mixedPtr1.setDouble(4, d5);
/* 3186 */       mixedPtr1.setInt(-3424001);
/* 3187 */       mixedPtr1.setAlignedInt(17, 8);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3192 */       mixedPtr1.setDouble(12, 0.0D);
/* 3193 */       mixedPtr1.setDouble(20, 0.0D);
/* 3194 */       mixedPtr1.setDouble(28, 0.0D);
/* 3195 */       mixedPtr1.setDouble(36, 0.0D);
/* 3196 */       mixedPtr1.setDouble(44, 0.0D);
/* 3197 */       mixedPtr1.setDouble(52, 0.0D);
/* 3198 */       mixedPtr1.setDouble(60, 0.0D);
/*      */       
/* 3200 */       SetFont(1, gc);
/* 3201 */       mixedPtr2.memcpy(RenderElement(expr, 0, (Ptr)mixedPtr1, gc, dd), 36);
/* 3202 */       double d4 = baseEngine__.GEfromDeviceX(x, 2, dd); mixedPtr1.setDouble(12, d4);
/* 3203 */       double d3 = baseEngine__.GEfromDeviceY(y, 2, dd); mixedPtr1.setDouble(20, d3);
/* 3204 */       if (Arith.R_finite(xc) == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3211 */         double d8 = mixedPtr1.getDouble(12), d7 = mixedPtr2.getAlignedDouble(2) * 0.5D, d6 = d8 - d7; mixedPtr1.setDouble(28, d6); } else { double d8 = mixedPtr1.getDouble(12), d7 = mixedPtr2.getAlignedDouble(2) * xc, d6 = d8 - d7; mixedPtr1.setDouble(28, d6); }
/* 3212 */        if (Arith.R_finite(yc) == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3220 */         double d12 = mixedPtr1.getDouble(20), d11 = mixedPtr2.getAlignedDouble(1), d10 = d12 + d11;
/* 3221 */         double d9 = mixedPtr2.getDouble(), d8 = mixedPtr2.getAlignedDouble(1), d7 = (d9 + d8) * 0.5D, d6 = d10 - d7; mixedPtr1.setDouble(36, d6); } else { double d12 = mixedPtr1.getDouble(20), d11 = mixedPtr2.getAlignedDouble(1), d10 = d12 + d11; double d9 = mixedPtr2.getDouble(), d8 = mixedPtr2.getAlignedDouble(1), d7 = (d9 + d8) * yc, d6 = d10 - d7; mixedPtr1.setDouble(36, d6); }
/* 3222 */        mixedPtr1.setDouble(44, rot);
/* 3223 */       rot *= 0.017453292519943295D;
/* 3224 */       double d2 = Mathlib.cos(rot); mixedPtr1.setDouble(52, d2);
/* 3225 */       double d1 = Mathlib.sin(rot); mixedPtr1.setDouble(60, d1);
/* 3226 */       RenderElement(expr, 1, (Ptr)mixedPtr1, gc, dd);
/*      */       return;
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("_");
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/plotmath__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */