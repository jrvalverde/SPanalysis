/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*      */ import org.renjin.gcc.runtime.RecordUnitPtrPtr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*      */ import org.renjin.gcc.runtime.VoidPtr;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.GetText;
/*      */ import org.renjin.gnur.api.Memory;
/*      */ import org.renjin.gnur.api.Print;
/*      */ import org.renjin.gnur.api.PrtUtil;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.grDevices.baseDevices__;
/*      */ import org.renjin.grDevices.baseEngine__;
/*      */ import org.renjin.grDevices.colors__;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class plot__
/*      */ {
/*      */   public static void TypeCheck(SEXP s, int type) {
/*   36 */     if (Rinternals.TYPEOF(s) != type) {
/*   37 */       Error.Rf_error(new BytePtr("invalid type passed to graphics function\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int isNAcol(SEXP col, int index, int ncol) {
/*   46 */     result = 1;
/*      */     
/*   48 */     if (Rinternals.TYPEOF(col) != 0)
/*      */     
/*      */     { 
/*   51 */       if (Rinternals.TYPEOF(col) != 10)
/*      */       
/*   53 */       { if (Rinternals.TYPEOF(col) != 16)
/*      */         
/*   55 */         { if (!Rinternals.Rf_isInteger(col))
/*      */           
/*   57 */           { if (Rinternals.TYPEOF(col) != 14)
/*      */             
/*      */             { 
/*   60 */               Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid color specification\000".getBytes(), 0)), new Object[0]);
/*      */               
/*   62 */               return result; }  Ptr ptr4 = Rinternals2.REAL(col); int i4 = index % ncol * 8; Ptr ptr3 = ptr4; int i3 = 0 + i4; result = (Arith.R_finite(ptr3.getDouble(i3)) != 0) ? 0 : 1; return result; }  Ptr ptr2 = Rinternals2.INTEGER(col); int i2 = index % ncol * 4; Ptr ptr1 = ptr2; int i1 = 0 + i2, n = ptr1.getInt(i1); R_NaInt$776 = Arith.R_NaInt; result = (n != R_NaInt$776) ? 0 : 1; return result; }  int m = index % ncol; result = (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(col, m)), (Ptr)new BytePtr("NA\000".getBytes(), 0)) != 0) ? 0 : 1; return result; }  IntPtr intPtr2 = Rinternals.LOGICAL(col); int k = index % ncol * 4; IntPtr intPtr1 = intPtr2; int j = 0 + k, i = intPtr1.getInt(j); R_NaInt$775 = Arith.R_NaInt; result = (i != R_NaInt$775) ? 0 : 1; return result; }  result = 1; return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP getInlinePar(SEXP s, Ptr name) {
/*   73 */     result = (SEXP)BytePtr.of(0).getArray(); result = Rinternals.R_NilValue;
/*   74 */     found = 0;
/*   75 */     if (Rinternals.Rf_isList(s) && found == 0)
/*   76 */       while (true) { R_NilValue$774 = Rinternals.R_NilValue; if (s != R_NilValue$774) {
/*   77 */           if (!Rinternals.Rf_isList(Rinternals.CAR(s)))
/*      */           
/*      */           { 
/*      */ 
/*      */             
/*   82 */             SEXP sEXP = Rinternals.TAG(s); R_NilValue$773 = Rinternals.R_NilValue; if (sEXP != R_NilValue$773 && 
/*   83 */               Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.PRINTNAME(Rinternals.TAG(s))), name) == 0)
/*   84 */             { result = Rinternals.CAR(s);
/*   85 */               found = 1; }  } else { result = getInlinePar(Rinternals.CAR(s), name); if (result != null)
/*      */               found = 1;  }
/*   87 */            s = Rinternals.CDR(s); continue;
/*      */         }  break; }
/*      */        
/*   90 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP FixupPch(SEXP pch, int dflt) {
/*   98 */     ans = (SEXP)BytePtr.of(0).getArray(); n = 0; i = 0; ans = Rinternals.R_NilValue;
/*      */     
/*  100 */     n = Rinternals.Rf_length(pch);
/*  101 */     if (n != 0) {
/*      */       
/*  103 */       ans = Rinternals.Rf_allocVector(13, n); Rinternals.Rf_protect(ans);
/*  104 */       if (!Rinternals.Rf_isList(pch))
/*      */       
/*      */       { 
/*      */         
/*  108 */         if (!Rinternals.Rf_isInteger(pch))
/*      */         
/*      */         { 
/*      */           
/*  112 */           if (Rinternals.TYPEOF(pch) != 14)
/*      */           
/*      */           { 
/*      */ 
/*      */             
/*  117 */             if (Rinternals.TYPEOF(pch) != 16)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/*  123 */               if (Rinternals.TYPEOF(pch) != 10)
/*      */               
/*      */               { 
/*      */ 
/*      */                 
/*  128 */                 Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid plotting symbol\000".getBytes(), 0)), new Object[0]); } else { for (i = 0; i < n; i++) { IntPtr intPtr2 = Rinternals.LOGICAL(pch); int i2 = i * 4; IntPtr intPtr1 = intPtr2; int i1 = 0 + i2, m = intPtr1.getInt(i1); R_NaInt$770 = Arith.R_NaInt; if (m != R_NaInt$770) { Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("only NA allowed in logical plotting symbol\000".getBytes(), 0)), new Object[0]); continue; }  Ptr ptr2 = Rinternals2.INTEGER(ans); int k = i * 4; Ptr ptr1 = ptr2; int j = 0 + k; R_NaInt$772 = Arith.R_NaInt; ptr1.setInt(j, R_NaInt$772); }  }  } else { for (i = 0; i < n; i++) { Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = baseEngine__.GEstring_to_pch(Rinternals.STRING_ELT(pch, i)); ptr1.setInt(k, j); }  }  } else { for (i = 0; i < n; i++) { Ptr ptr4 = Rinternals2.INTEGER(ans); int i1 = i * 4; Ptr ptr3 = ptr4; int m = 0 + i1; Ptr ptr2 = Rinternals2.REAL(pch); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; if (Arith.R_finite(ptr1.getDouble(j)) == 0) { iftmp$765 = Arith.R_NaInt; } else { Ptr ptr6 = Rinternals2.REAL(pch); int i3 = i * 8; Ptr ptr5 = ptr6; int i2 = 0 + i3; iftmp$765 = (int)ptr5.getDouble(i2); }  ptr3.setInt(m, iftmp$765); }  }  } else { for (i = 0; i < n; i++) { Ptr ptr4 = Rinternals2.INTEGER(ans); int i2 = i * 4; Ptr ptr3 = ptr4; int i1 = 0 + i2; Ptr ptr2 = Rinternals2.INTEGER(pch); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = ptr1.getInt(k); ptr3.setInt(i1, j); }  }  } else { i = 0; while (true) { R_NilValue$761 = Rinternals.R_NilValue; if (pch != R_NilValue$761) { Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = Rinternals.Rf_asInteger(Rinternals.CAR(pch)); ptr1.setInt(k, j); i++; pch = Rinternals.CDR(pch); continue; }  break; }
/*      */          }
/*  130 */        return ans;
/*      */     } 
/*      */     return ans = Rinternals.Rf_ScalarInteger(dflt);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP Rf_FixupLty(SEXP lty, int dflt) {
/*  137 */     ans = (SEXP)BytePtr.of(0).getArray(); n = 0; n = Rinternals.Rf_length(lty);
/*  138 */     if (n != 0)
/*      */     
/*      */     { 
/*      */       
/*  142 */       ans = Rinternals.Rf_allocVector(13, n);
/*  143 */       for (i = 0; i < n; i++) {
/*  144 */         Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = baseEngine__.GE_LTYpar(lty, i); ptr1.setInt(k, j);
/*      */       } 
/*  146 */       return ans; }  ans = Rinternals.Rf_ScalarInteger(dflt); return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_FixupLwd(SEXP lwd, double dflt) {
/*  153 */     ans = (SEXP)BytePtr.of(0).getArray(); n = 0; ans = (SEXP)BytePtr.of(0).getArray();
/*      */     
/*  155 */     n = Rinternals.Rf_length(lwd);
/*  156 */     if (n != 0)
/*      */     
/*      */     { 
/*  159 */       lwd = Rinternals.Rf_coerceVector(lwd, 14); Rinternals.Rf_protect(lwd);
/*  160 */       n = Rinternals.Rf_length(lwd);
/*  161 */       ans = Rinternals.Rf_allocVector(14, n);
/*  162 */       for (i = 0; i < n; i++) {
/*  163 */         Ptr ptr4 = Rinternals2.REAL(lwd); int i1 = i * 8; Ptr ptr3 = ptr4; int m = 0 + i1; w = ptr3.getDouble(m);
/*  164 */         if (w < 0.0D) w = Arith.R_NaReal; 
/*  165 */         Ptr ptr2 = Rinternals2.REAL(ans); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; ptr1.setDouble(j, w);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  170 */       return ans; }  ans = Rinternals.Rf_ScalarReal(dflt); return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP FixupFont(SEXP font, int dflt) {
/*  176 */     ans = (SEXP)BytePtr.of(0).getArray(); n = 0; ans = Rinternals.R_NilValue;
/*  177 */     n = Rinternals.Rf_length(font);
/*  178 */     if (n != 0)
/*      */     
/*      */     { 
/*  181 */       if (Rinternals.TYPEOF(font) != 10)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  193 */         if (!Rinternals.Rf_isInteger(font))
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  205 */           if (Rinternals.TYPEOF(font) != 14)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  217 */             Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid font specification\000".getBytes(), 0)), new Object[0]);
/*  218 */             return ans; }  ans = Rinternals.Rf_allocVector(13, n); for (i = 0; i < n; i++) { Ptr ptr4 = Rinternals2.REAL(font); int i2 = i * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; k = (int)ptr3.getDouble(i1); if (k <= 0 || k > 5) k = Arith.R_NaInt;  Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int j = 0 + m; ptr1.setInt(j, k); }  return ans; }  ans = Rinternals.Rf_allocVector(13, n); for (i = 0; i < n; i++) { Ptr ptr4 = Rinternals2.INTEGER(font); int i2 = i * 4; Ptr ptr3 = ptr4; int i1 = 0 + i2; k = ptr3.getInt(i1); if (k <= 0 || k > 5) k = Arith.R_NaInt;  Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int j = 0 + m; ptr1.setInt(j, k); }  return ans; }  ans = Rinternals.Rf_allocVector(13, n); for (i = 0; i < n; i++) { IntPtr intPtr2 = Rinternals.LOGICAL(font); int i2 = i * 4; IntPtr intPtr1 = intPtr2; int i1 = 0 + i2; k = intPtr1.getInt(i1); if (k <= 0 || k > 5) k = Arith.R_NaInt;  Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int j = 0 + m; ptr1.setInt(j, k); }  return ans; }  ans = Rinternals.Rf_ScalarInteger(dflt); return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_FixupCol(SEXP col, int dflt) {
/*  225 */     bg = 0; ans = (SEXP)BytePtr.of(0).getArray(); n = 0; bg = base__.Rf_dpptr(baseDevices__.GEcurrentDevice()).getInt(20);
/*      */     
/*  227 */     n = Rinternals.Rf_length(col);
/*  228 */     if (n != 0)
/*      */     
/*      */     { 
/*  231 */       ans = Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, n));
/*  232 */       if (!Rinternals.Rf_isList(col))
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */         
/*  238 */         for (i = 0; i < n; i++) {
/*  239 */           Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = colors__.Rf_RGBpar3(col, i, bg); ptr1.setInt(k, j);
/*      */         } 
/*      */         
/*  242 */         return ans; }  for (i = 0; i < n; i++) { Ptr ptr2 = Rinternals2.INTEGER(ans); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = colors__.Rf_RGBpar3(Rinternals.CAR(col), 0, bg); ptr1.setInt(k, j); col = Rinternals.CDR(col); }  return ans; }  ans = Rinternals.Rf_ScalarInteger(dflt); Rinternals.Rf_protect(ans); return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP FixupCex(SEXP cex, double dflt) {
/*  249 */     n = 0; ans = (SEXP)BytePtr.of(0).getArray(); n = Rinternals.Rf_length(cex);
/*  250 */     if (n != 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  259 */       ans = Rinternals.Rf_allocVector(14, n);
/*  260 */       if (Rinternals.TYPEOF(cex) != 14)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  268 */         if (!Rinternals.Rf_isInteger(cex) && Rinternals.TYPEOF(cex) != 10)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  276 */           Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("cex\000".getBytes(), 0) });
/*      */           
/*  278 */           return ans; }  for (i = 0; i < n; i++) { Ptr ptr4 = Rinternals2.INTEGER(cex); int i1 = i * 4; Ptr ptr3 = ptr4; int m = 0 + i1; c = ptr3.getInt(m); if (Arith.R_NaInt == c || c <= 0.0D) c = Arith.R_NaReal;  Ptr ptr2 = Rinternals2.REAL(ans); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; ptr1.setDouble(j, c); }  return ans; }  for (i = 0; i < n; i++) { Ptr ptr2 = Rinternals2.REAL(cex); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; c = ptr1.getDouble(j); if (Arith.R_finite(c) == 0 || c <= 0.0D) { Ptr ptr4 = Rinternals2.REAL(ans); int i1 = i * 8; Ptr ptr3 = ptr4; int m = 0 + i1; R_NaReal$744 = Arith.R_NaReal; ptr3.setDouble(m, R_NaReal$744); } else { Ptr ptr4 = Rinternals2.REAL(ans); int i1 = i * 8; Ptr ptr3 = ptr4; int m = 0 + i1; ptr3.setDouble(m, c); }  }  return ans; }  ans = Rinternals.Rf_allocVector(14, 1); if (Arith.R_finite(dflt) == 0 || dflt <= 0.0D) { Ptr ptr = Rinternals2.REAL(ans); R_NaReal$740 = Arith.R_NaReal; ptr.setDouble(0, R_NaReal$740); return ans; }  Rinternals2.REAL(ans).setDouble(0, dflt); return ans;
/*      */   }
/*      */   
/*      */   public static SEXP Rf_FixupVFont(SEXP vfont) {
/*  282 */     vf = (SEXP)BytePtr.of(0).getArray(); ans = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue;
/*  283 */     if (Rinternals.TYPEOF(vfont) != 0) {
/*      */ 
/*      */       
/*  286 */       maxindex = 0;
/*      */       
/*  288 */       vf = Rinternals.Rf_coerceVector(vfont, 13); Rinternals.Rf_protect(vf);
/*  289 */       if (Rinternals.Rf_length(vf) != 2)
/*  290 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("vfont\000".getBytes(), 0) }); 
/*  291 */       typeface = Rinternals2.INTEGER(vf).getInt();
/*  292 */       if (typeface <= 0 || typeface > 8) {
/*  293 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid 'vfont' value [typeface %d]\000".getBytes(), 0)), new Object[] { Integer.valueOf(typeface) });
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  300 */       switch (typeface) {
/*      */         case 1:
/*  302 */           maxindex = 7; break;
/*      */         case 2:
/*      */         case 7:
/*  305 */           maxindex = 4; break;
/*      */         case 3:
/*  307 */           maxindex = 3; break;
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*  311 */           maxindex = 1; break;
/*      */         case 8:
/*  313 */           maxindex = 2; break;
/*      */       } 
/*  315 */       fontindex = Rinternals2.INTEGER(vf).getInt(4);
/*  316 */       if (fontindex < 1 || fontindex > maxindex) {
/*  317 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid 'vfont' value [typeface = %d, fontindex = %d]\000".getBytes(), 0)), new Object[] { Integer.valueOf(typeface), Integer.valueOf(fontindex) });
/*      */       }
/*  319 */       ans = Rinternals.Rf_allocVector(13, 2);
/*  320 */       for (i = 0; i <= 1; ) { Ptr ptr4 = Rinternals2.INTEGER(ans); int i1 = i * 4; Ptr ptr3 = ptr4; int n = 0 + i1; Ptr ptr2 = Rinternals2.INTEGER(vf); int m = i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = ptr1.getInt(k); ptr3.setInt(n, j); i++; }
/*      */     
/*      */     } 
/*  323 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GetTextArg(SEXP spec, Ptr ptxt, Ptr pcol, Ptr pcex, Ptr pfont) {
/*  343 */     pi = new int[1]; pi[0] = 0; nms = (SEXP)BytePtr.of(0).getArray(); txt = (SEXP)BytePtr.of(0).getArray(); cex = 0.0D; col = 0; colspecd = 0; font = 0; n = 0; txt = Rinternals.R_NilValue;
/*  344 */     cex = Arith.R_NaReal;
/*  345 */     col = 16777215;
/*  346 */     colspecd = 0;
/*  347 */     font = Arith.R_NaInt;
/*      */ 
/*      */ 
/*      */     
/*  351 */     switch (Rinternals.TYPEOF(spec)) {
/*      */       case 1:
/*      */       case 6:
/*  354 */         pi$726 = pi[0]; txt = Rinternals.Rf_coerceVector(spec, 20);
/*      */         break;
/*      */       case 19:
/*  357 */         if (Rinternals.Rf_length(spec) != 0) {
/*      */ 
/*      */ 
/*      */           
/*  361 */           R_NamesSymbol$728 = Rinternals.R_NamesSymbol; nms = Rinternals.Rf_getAttrib(spec, R_NamesSymbol$728);
/*  362 */           R_NilValue$729 = Rinternals.R_NilValue; if (nms != R_NilValue$729) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  369 */             n = Rinternals.Rf_length(nms);
/*  370 */             for (i = 0; i < n; i++)
/*  371 */             { if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(nms, i)), (Ptr)new BytePtr("cex\000".getBytes(), 0)) != 0)
/*      */               
/*      */               { 
/*  374 */                 if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(nms, i)), (Ptr)new BytePtr("col\000".getBytes(), 0)) != 0)
/*      */                 
/*      */                 { 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  381 */                   if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(nms, i)), (Ptr)new BytePtr("font\000".getBytes(), 0)) != 0)
/*      */                   
/*      */                   { 
/*  384 */                     if ((Rinternals.R_CHAR(Rinternals.STRING_ELT(nms, i)).getByte() & 0xFF) != 0)
/*      */                     
/*      */                     { 
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/*  391 */                       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid graphics parameter\000".getBytes(), 0)), new Object[0]); } else { txt = Rinternals.VECTOR_ELT(spec, i); if (Rinternals.TYPEOF(txt) != 6 && Rinternals.TYPEOF(txt) != 1) { if (Rinternals.TYPEOF(txt) != 20) { pi$734 = pi[0]; txt = Rinternals.Rf_coerceVector(txt, 16); }  } else { pi$733 = pi[0]; txt = Rinternals.Rf_coerceVector(txt, 20); }  }  } else { R_NaInt$732 = Arith.R_NaInt; font = Rinternals.Rf_asInteger(FixupFont(Rinternals.VECTOR_ELT(spec, i), R_NaInt$732)); }  } else { colsxp = Rinternals.VECTOR_ELT(spec, i); int j = Rinternals.LENGTH(colsxp); if (isNAcol(colsxp, 0, j) == 0) { col = Rinternals.Rf_asInteger(Rf_FixupCol(colsxp, 16777215)); colspecd = 1; }  }  } else { cex = Rinternals.Rf_asReal(Rinternals.VECTOR_ELT(spec, i)); }  }  break;
/*      */           }  txt = Rinternals.VECTOR_ELT(spec, 0); if (Rinternals.TYPEOF(txt) != 6 && Rinternals.TYPEOF(txt) != 1) { if (Rinternals.TYPEOF(txt) == 20)
/*      */               break;  pi$731 = pi[0]; txt = Rinternals.Rf_coerceVector(txt, 16); break; }
/*      */            pi$730 = pi[0]; txt = Rinternals.Rf_coerceVector(txt, 20); break;
/*      */         }  R_NilValue$727 = Rinternals.R_NilValue; ptxt.setPointer((Ptr)new RecordUnitPtr(R_NilValue$727)); break;
/*      */       case 16:
/*      */       case 20:
/*  398 */         txt = spec;
/*      */         break;
/*      */       default:
/*  401 */         pi$735 = pi[0]; txt = Rinternals.Rf_coerceVector(spec, 16);
/*      */         break;
/*      */     } 
/*      */     
/*  405 */     R_NilValue$736 = Rinternals.R_NilValue; if (txt != R_NilValue$736) {
/*  406 */       ptxt.setPointer((Ptr)new RecordUnitPtr(txt));
/*  407 */       if (Arith.R_finite(cex) != 0) pcex.setDouble(cex); 
/*  408 */       if (colspecd != 0) pcol.setInt(col); 
/*  409 */       R_NaInt$737 = Arith.R_NaInt; if (font != R_NaInt$737) pfont.setInt(font);
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_plot_new(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*  422 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  428 */     dd = graphics__.Rf_GNewPlot(graphics__.GRecording(call, dd.pointerPlus(dd$offset))); dd$offset = 0;
/*      */     
/*  430 */     Ptr ptr4 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr3.setInt(440, 0); int j = ptr3.getInt(440); ptr4.setInt(440, j);
/*  431 */     Ptr ptr2 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr1.setInt(480, 0); int i = ptr1.getInt(480); ptr2.setInt(480, i);
/*      */     
/*  433 */     graphics__.Rf_GScale(0.0D, 1.0D, 1, dd.pointerPlus(dd$offset));
/*  434 */     graphics__.Rf_GScale(0.0D, 1.0D, 2, dd.pointerPlus(dd$offset));
/*  435 */     graphics__.Rf_GMapWin2Fig(dd.pointerPlus(dd$offset));
/*  436 */     graphics__.Rf_GSetState(1, dd.pointerPlus(dd$offset));
/*      */     
/*  438 */     if (graphics__.GRecording(call, dd.pointerPlus(dd$offset)) != 0)
/*  439 */       baseEngine__.GErecordGraphicOperation(op, args, dd.pointerPlus(dd$offset)); 
/*  440 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_plot_window(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4: astore #19
/*      */     //   6: iconst_0
/*      */     //   7: istore #20
/*      */     //   9: iconst_0
/*      */     //   10: istore #23
/*      */     //   12: iconst_0
/*      */     //   13: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   21: checkcast org/renjin/sexp/SEXP
/*      */     //   24: astore #35
/*      */     //   26: iconst_0
/*      */     //   27: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   30: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   35: checkcast org/renjin/sexp/SEXP
/*      */     //   38: astore #36
/*      */     //   40: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   43: astore #19
/*      */     //   45: iconst_0
/*      */     //   46: istore #20
/*      */     //   48: aload_0
/*      */     //   49: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   52: astore_0
/*      */     //   53: aload_0
/*      */     //   54: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   57: iconst_2
/*      */     //   58: if_icmple -> 64
/*      */     //   61: goto -> 104
/*      */     //   64: new org/renjin/gcc/runtime/BytePtr
/*      */     //   67: dup
/*      */     //   68: ldc 'graphics '
/*      */     //   70: invokevirtual getBytes : ()[B
/*      */     //   73: iconst_0
/*      */     //   74: invokespecial <init> : ([BI)V
/*      */     //   77: new org/renjin/gcc/runtime/BytePtr
/*      */     //   80: dup
/*      */     //   81: ldc_w 'at least 3 arguments required '
/*      */     //   84: invokevirtual getBytes : ()[B
/*      */     //   87: iconst_0
/*      */     //   88: invokespecial <init> : ([BI)V
/*      */     //   91: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   94: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   97: iconst_0
/*      */     //   98: anewarray java/lang/Object
/*      */     //   101: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   104: aload_0
/*      */     //   105: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   108: astore #36
/*      */     //   110: aload #36
/*      */     //   112: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   115: ifeq -> 133
/*      */     //   118: goto -> 121
/*      */     //   121: aload #36
/*      */     //   123: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   126: iconst_2
/*      */     //   127: if_icmpne -> 133
/*      */     //   130: goto -> 190
/*      */     //   133: new org/renjin/gcc/runtime/BytePtr
/*      */     //   136: dup
/*      */     //   137: ldc 'graphics '
/*      */     //   139: invokevirtual getBytes : ()[B
/*      */     //   142: iconst_0
/*      */     //   143: invokespecial <init> : ([BI)V
/*      */     //   146: new org/renjin/gcc/runtime/BytePtr
/*      */     //   149: dup
/*      */     //   150: ldc_w 'invalid '%s' value '
/*      */     //   153: invokevirtual getBytes : ()[B
/*      */     //   156: iconst_0
/*      */     //   157: invokespecial <init> : ([BI)V
/*      */     //   160: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   163: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   166: iconst_1
/*      */     //   167: anewarray java/lang/Object
/*      */     //   170: dup
/*      */     //   171: iconst_0
/*      */     //   172: new org/renjin/gcc/runtime/BytePtr
/*      */     //   175: dup
/*      */     //   176: ldc_w 'xlim '
/*      */     //   179: invokevirtual getBytes : ()[B
/*      */     //   182: iconst_0
/*      */     //   183: invokespecial <init> : ([BI)V
/*      */     //   186: aastore
/*      */     //   187: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   190: aload_0
/*      */     //   191: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   194: astore_0
/*      */     //   195: aload_0
/*      */     //   196: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   199: astore #35
/*      */     //   201: aload #35
/*      */     //   203: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   206: ifeq -> 224
/*      */     //   209: goto -> 212
/*      */     //   212: aload #35
/*      */     //   214: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   217: iconst_2
/*      */     //   218: if_icmpne -> 224
/*      */     //   221: goto -> 281
/*      */     //   224: new org/renjin/gcc/runtime/BytePtr
/*      */     //   227: dup
/*      */     //   228: ldc 'graphics '
/*      */     //   230: invokevirtual getBytes : ()[B
/*      */     //   233: iconst_0
/*      */     //   234: invokespecial <init> : ([BI)V
/*      */     //   237: new org/renjin/gcc/runtime/BytePtr
/*      */     //   240: dup
/*      */     //   241: ldc_w 'invalid '%s' value '
/*      */     //   244: invokevirtual getBytes : ()[B
/*      */     //   247: iconst_0
/*      */     //   248: invokespecial <init> : ([BI)V
/*      */     //   251: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   254: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   257: iconst_1
/*      */     //   258: anewarray java/lang/Object
/*      */     //   261: dup
/*      */     //   262: iconst_0
/*      */     //   263: new org/renjin/gcc/runtime/BytePtr
/*      */     //   266: dup
/*      */     //   267: ldc_w 'ylim '
/*      */     //   270: invokevirtual getBytes : ()[B
/*      */     //   273: iconst_0
/*      */     //   274: invokespecial <init> : ([BI)V
/*      */     //   277: aastore
/*      */     //   278: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   281: aload_0
/*      */     //   282: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   285: astore_0
/*      */     //   286: iconst_0
/*      */     //   287: istore #23
/*      */     //   289: aload_0
/*      */     //   290: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   293: astore #34
/*      */     //   295: aload #34
/*      */     //   297: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   300: bipush #16
/*      */     //   302: if_icmpne -> 308
/*      */     //   305: goto -> 348
/*      */     //   308: new org/renjin/gcc/runtime/BytePtr
/*      */     //   311: dup
/*      */     //   312: ldc 'graphics '
/*      */     //   314: invokevirtual getBytes : ()[B
/*      */     //   317: iconst_0
/*      */     //   318: invokespecial <init> : ([BI)V
/*      */     //   321: new org/renjin/gcc/runtime/BytePtr
/*      */     //   324: dup
/*      */     //   325: ldc_w '"log=" specification must be character '
/*      */     //   328: invokevirtual getBytes : ()[B
/*      */     //   331: iconst_0
/*      */     //   332: invokespecial <init> : ([BI)V
/*      */     //   335: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   338: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   341: iconst_0
/*      */     //   342: anewarray java/lang/Object
/*      */     //   345: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   348: aload #34
/*      */     //   350: iconst_0
/*      */     //   351: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   354: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   357: astore #21
/*      */     //   359: iconst_0
/*      */     //   360: istore #22
/*      */     //   362: goto -> 599
/*      */     //   365: aload #21
/*      */     //   367: iload #22
/*      */     //   369: invokeinterface getByte : (I)B
/*      */     //   374: lookupswitch default -> 540, 120 -> 400, 121 -> 470
/*      */     //   400: aload #19
/*      */     //   402: iload #20
/*      */     //   404: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   409: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   412: astore #167
/*      */     //   414: aload #19
/*      */     //   416: iload #20
/*      */     //   418: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   423: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   426: astore #165
/*      */     //   428: iconst_1
/*      */     //   429: istore #23
/*      */     //   431: aload #165
/*      */     //   433: sipush #440
/*      */     //   436: iload #23
/*      */     //   438: invokeinterface setInt : (II)V
/*      */     //   443: aload #165
/*      */     //   445: sipush #440
/*      */     //   448: invokeinterface getInt : (I)I
/*      */     //   453: istore #164
/*      */     //   455: aload #167
/*      */     //   457: sipush #440
/*      */     //   460: iload #164
/*      */     //   462: invokeinterface setInt : (II)V
/*      */     //   467: goto -> 592
/*      */     //   470: aload #19
/*      */     //   472: iload #20
/*      */     //   474: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   479: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   482: astore #162
/*      */     //   484: aload #19
/*      */     //   486: iload #20
/*      */     //   488: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   493: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   496: astore #160
/*      */     //   498: iconst_1
/*      */     //   499: istore #23
/*      */     //   501: aload #160
/*      */     //   503: sipush #480
/*      */     //   506: iload #23
/*      */     //   508: invokeinterface setInt : (II)V
/*      */     //   513: aload #160
/*      */     //   515: sipush #480
/*      */     //   518: invokeinterface getInt : (I)I
/*      */     //   523: istore #159
/*      */     //   525: aload #162
/*      */     //   527: sipush #480
/*      */     //   530: iload #159
/*      */     //   532: invokeinterface setInt : (II)V
/*      */     //   537: goto -> 592
/*      */     //   540: new org/renjin/gcc/runtime/BytePtr
/*      */     //   543: dup
/*      */     //   544: ldc 'graphics '
/*      */     //   546: invokevirtual getBytes : ()[B
/*      */     //   549: iconst_0
/*      */     //   550: invokespecial <init> : ([BI)V
/*      */     //   553: new org/renjin/gcc/runtime/BytePtr
/*      */     //   556: dup
/*      */     //   557: ldc_w 'invalid "log=%s" specification '
/*      */     //   560: invokevirtual getBytes : ()[B
/*      */     //   563: iconst_0
/*      */     //   564: invokespecial <init> : ([BI)V
/*      */     //   567: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   570: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   573: iconst_1
/*      */     //   574: anewarray java/lang/Object
/*      */     //   577: dup
/*      */     //   578: iconst_0
/*      */     //   579: aload #21
/*      */     //   581: iload #22
/*      */     //   583: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   588: aastore
/*      */     //   589: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   592: aload #21
/*      */     //   594: astore #21
/*      */     //   596: iinc #22, 1
/*      */     //   599: aload #21
/*      */     //   601: iload #22
/*      */     //   603: invokeinterface getByte : (I)B
/*      */     //   608: iconst_0
/*      */     //   609: i2b
/*      */     //   610: if_icmpne -> 365
/*      */     //   613: goto -> 616
/*      */     //   616: aload_0
/*      */     //   617: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   620: astore_0
/*      */     //   621: iload #23
/*      */     //   623: ifeq -> 629
/*      */     //   626: goto -> 641
/*      */     //   629: aload_0
/*      */     //   630: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   633: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   636: dstore #154
/*      */     //   638: goto -> 646
/*      */     //   641: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   644: dstore #154
/*      */     //   646: dload #154
/*      */     //   648: dstore #32
/*      */     //   650: aload_0
/*      */     //   651: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   654: astore_0
/*      */     //   655: aload #19
/*      */     //   657: iload #20
/*      */     //   659: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   664: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   667: aload_0
/*      */     //   668: aload #19
/*      */     //   670: iload #20
/*      */     //   672: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   677: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   680: aload #36
/*      */     //   682: invokestatic Rf_isInteger : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   685: ifne -> 691
/*      */     //   688: goto -> 816
/*      */     //   691: aload #36
/*      */     //   693: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   696: invokeinterface getInt : ()I
/*      */     //   701: istore #149
/*      */     //   703: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   706: istore #148
/*      */     //   708: iload #149
/*      */     //   710: iload #148
/*      */     //   712: if_icmpeq -> 746
/*      */     //   715: goto -> 718
/*      */     //   718: aload #36
/*      */     //   720: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   723: iconst_4
/*      */     //   724: invokeinterface getInt : (I)I
/*      */     //   729: istore #143
/*      */     //   731: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   734: istore #142
/*      */     //   736: iload #143
/*      */     //   738: iload #142
/*      */     //   740: if_icmpeq -> 746
/*      */     //   743: goto -> 786
/*      */     //   746: new org/renjin/gcc/runtime/BytePtr
/*      */     //   749: dup
/*      */     //   750: ldc 'graphics '
/*      */     //   752: invokevirtual getBytes : ()[B
/*      */     //   755: iconst_0
/*      */     //   756: invokespecial <init> : ([BI)V
/*      */     //   759: new org/renjin/gcc/runtime/BytePtr
/*      */     //   762: dup
/*      */     //   763: ldc_w 'NAs not allowed in 'xlim' '
/*      */     //   766: invokevirtual getBytes : ()[B
/*      */     //   769: iconst_0
/*      */     //   770: invokespecial <init> : ([BI)V
/*      */     //   773: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   776: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   779: iconst_0
/*      */     //   780: anewarray java/lang/Object
/*      */     //   783: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   786: aload #36
/*      */     //   788: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   791: invokeinterface getInt : ()I
/*      */     //   796: i2d
/*      */     //   797: dstore #30
/*      */     //   799: aload #36
/*      */     //   801: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   804: iconst_4
/*      */     //   805: invokeinterface getInt : (I)I
/*      */     //   810: i2d
/*      */     //   811: dstore #28
/*      */     //   813: goto -> 922
/*      */     //   816: aload #36
/*      */     //   818: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   821: invokeinterface getDouble : ()D
/*      */     //   826: invokestatic R_finite : (D)I
/*      */     //   829: ifeq -> 856
/*      */     //   832: goto -> 835
/*      */     //   835: aload #36
/*      */     //   837: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   840: bipush #8
/*      */     //   842: invokeinterface getDouble : (I)D
/*      */     //   847: invokestatic R_finite : (D)I
/*      */     //   850: ifeq -> 856
/*      */     //   853: goto -> 896
/*      */     //   856: new org/renjin/gcc/runtime/BytePtr
/*      */     //   859: dup
/*      */     //   860: ldc 'graphics '
/*      */     //   862: invokevirtual getBytes : ()[B
/*      */     //   865: iconst_0
/*      */     //   866: invokespecial <init> : ([BI)V
/*      */     //   869: new org/renjin/gcc/runtime/BytePtr
/*      */     //   872: dup
/*      */     //   873: ldc_w 'need finite 'xlim' values '
/*      */     //   876: invokevirtual getBytes : ()[B
/*      */     //   879: iconst_0
/*      */     //   880: invokespecial <init> : ([BI)V
/*      */     //   883: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   886: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   889: iconst_0
/*      */     //   890: anewarray java/lang/Object
/*      */     //   893: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   896: aload #36
/*      */     //   898: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   901: invokeinterface getDouble : ()D
/*      */     //   906: dstore #30
/*      */     //   908: aload #36
/*      */     //   910: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   913: bipush #8
/*      */     //   915: invokeinterface getDouble : (I)D
/*      */     //   920: dstore #28
/*      */     //   922: aload #35
/*      */     //   924: invokestatic Rf_isInteger : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   927: ifne -> 933
/*      */     //   930: goto -> 1058
/*      */     //   933: aload #35
/*      */     //   935: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   938: invokeinterface getInt : ()I
/*      */     //   943: istore #110
/*      */     //   945: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   948: istore #109
/*      */     //   950: iload #110
/*      */     //   952: iload #109
/*      */     //   954: if_icmpeq -> 988
/*      */     //   957: goto -> 960
/*      */     //   960: aload #35
/*      */     //   962: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   965: iconst_4
/*      */     //   966: invokeinterface getInt : (I)I
/*      */     //   971: istore #104
/*      */     //   973: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   976: istore #103
/*      */     //   978: iload #104
/*      */     //   980: iload #103
/*      */     //   982: if_icmpeq -> 988
/*      */     //   985: goto -> 1028
/*      */     //   988: new org/renjin/gcc/runtime/BytePtr
/*      */     //   991: dup
/*      */     //   992: ldc 'graphics '
/*      */     //   994: invokevirtual getBytes : ()[B
/*      */     //   997: iconst_0
/*      */     //   998: invokespecial <init> : ([BI)V
/*      */     //   1001: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1004: dup
/*      */     //   1005: ldc_w 'NAs not allowed in 'ylim' '
/*      */     //   1008: invokevirtual getBytes : ()[B
/*      */     //   1011: iconst_0
/*      */     //   1012: invokespecial <init> : ([BI)V
/*      */     //   1015: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1018: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1021: iconst_0
/*      */     //   1022: anewarray java/lang/Object
/*      */     //   1025: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1028: aload #35
/*      */     //   1030: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1033: invokeinterface getInt : ()I
/*      */     //   1038: i2d
/*      */     //   1039: dstore #26
/*      */     //   1041: aload #35
/*      */     //   1043: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1046: iconst_4
/*      */     //   1047: invokeinterface getInt : (I)I
/*      */     //   1052: i2d
/*      */     //   1053: dstore #24
/*      */     //   1055: goto -> 1164
/*      */     //   1058: aload #35
/*      */     //   1060: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1063: invokeinterface getDouble : ()D
/*      */     //   1068: invokestatic R_finite : (D)I
/*      */     //   1071: ifeq -> 1098
/*      */     //   1074: goto -> 1077
/*      */     //   1077: aload #35
/*      */     //   1079: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1082: bipush #8
/*      */     //   1084: invokeinterface getDouble : (I)D
/*      */     //   1089: invokestatic R_finite : (D)I
/*      */     //   1092: ifeq -> 1098
/*      */     //   1095: goto -> 1138
/*      */     //   1098: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1101: dup
/*      */     //   1102: ldc 'graphics '
/*      */     //   1104: invokevirtual getBytes : ()[B
/*      */     //   1107: iconst_0
/*      */     //   1108: invokespecial <init> : ([BI)V
/*      */     //   1111: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1114: dup
/*      */     //   1115: ldc_w 'need finite 'ylim' values '
/*      */     //   1118: invokevirtual getBytes : ()[B
/*      */     //   1121: iconst_0
/*      */     //   1122: invokespecial <init> : ([BI)V
/*      */     //   1125: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1128: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1131: iconst_0
/*      */     //   1132: anewarray java/lang/Object
/*      */     //   1135: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1138: aload #35
/*      */     //   1140: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1143: invokeinterface getDouble : ()D
/*      */     //   1148: dstore #26
/*      */     //   1150: aload #35
/*      */     //   1152: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1155: bipush #8
/*      */     //   1157: invokeinterface getDouble : (I)D
/*      */     //   1162: dstore #24
/*      */     //   1164: aload #19
/*      */     //   1166: iload #20
/*      */     //   1168: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1173: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1176: sipush #440
/*      */     //   1179: invokeinterface getInt : (I)I
/*      */     //   1184: ifne -> 1190
/*      */     //   1187: goto -> 1210
/*      */     //   1190: dload #30
/*      */     //   1192: dconst_0
/*      */     //   1193: dcmpg
/*      */     //   1194: iflt -> 1256
/*      */     //   1197: goto -> 1200
/*      */     //   1200: dload #28
/*      */     //   1202: dconst_0
/*      */     //   1203: dcmpg
/*      */     //   1204: iflt -> 1256
/*      */     //   1207: goto -> 1210
/*      */     //   1210: aload #19
/*      */     //   1212: iload #20
/*      */     //   1214: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1219: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1222: sipush #480
/*      */     //   1225: invokeinterface getInt : (I)I
/*      */     //   1230: ifne -> 1236
/*      */     //   1233: goto -> 1296
/*      */     //   1236: dload #26
/*      */     //   1238: dconst_0
/*      */     //   1239: dcmpg
/*      */     //   1240: iflt -> 1256
/*      */     //   1243: goto -> 1246
/*      */     //   1246: dload #24
/*      */     //   1248: dconst_0
/*      */     //   1249: dcmpg
/*      */     //   1250: iflt -> 1256
/*      */     //   1253: goto -> 1296
/*      */     //   1256: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1259: dup
/*      */     //   1260: ldc 'graphics '
/*      */     //   1262: invokevirtual getBytes : ()[B
/*      */     //   1265: iconst_0
/*      */     //   1266: invokespecial <init> : ([BI)V
/*      */     //   1269: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1272: dup
/*      */     //   1273: ldc_w 'Logarithmic axis must have positive limits '
/*      */     //   1276: invokevirtual getBytes : ()[B
/*      */     //   1279: iconst_0
/*      */     //   1280: invokespecial <init> : ([BI)V
/*      */     //   1283: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1286: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1289: iconst_0
/*      */     //   1290: anewarray java/lang/Object
/*      */     //   1293: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1296: dload #32
/*      */     //   1298: invokestatic R_finite : (D)I
/*      */     //   1301: ifne -> 1307
/*      */     //   1304: goto -> 1585
/*      */     //   1307: dload #32
/*      */     //   1309: dconst_0
/*      */     //   1310: dcmpl
/*      */     //   1311: ifgt -> 1317
/*      */     //   1314: goto -> 1585
/*      */     //   1317: dconst_1
/*      */     //   1318: bipush #16
/*      */     //   1320: bipush #13
/*      */     //   1322: aload #19
/*      */     //   1324: iload #20
/*      */     //   1326: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1331: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1334: dstore #17
/*      */     //   1336: dconst_1
/*      */     //   1337: bipush #16
/*      */     //   1339: bipush #13
/*      */     //   1341: aload #19
/*      */     //   1343: iload #20
/*      */     //   1345: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1350: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1353: dstore #15
/*      */     //   1355: dload #28
/*      */     //   1357: dload #30
/*      */     //   1359: dsub
/*      */     //   1360: invokestatic abs : (D)D
/*      */     //   1363: dload #32
/*      */     //   1365: ddiv
/*      */     //   1366: dstore #11
/*      */     //   1368: dload #24
/*      */     //   1370: dload #26
/*      */     //   1372: dsub
/*      */     //   1373: invokestatic abs : (D)D
/*      */     //   1376: dstore #9
/*      */     //   1378: dload #11
/*      */     //   1380: dconst_0
/*      */     //   1381: dcmpl
/*      */     //   1382: ifeq -> 1388
/*      */     //   1385: goto -> 1435
/*      */     //   1388: dload #9
/*      */     //   1390: dconst_0
/*      */     //   1391: dcmpl
/*      */     //   1392: ifeq -> 1398
/*      */     //   1395: goto -> 1435
/*      */     //   1398: dload #30
/*      */     //   1400: dconst_0
/*      */     //   1401: dcmpl
/*      */     //   1402: ifeq -> 1408
/*      */     //   1405: goto -> 1414
/*      */     //   1408: dconst_1
/*      */     //   1409: dstore #58
/*      */     //   1411: goto -> 1419
/*      */     //   1414: ldc2_w 0.4
/*      */     //   1417: dstore #58
/*      */     //   1419: dload #58
/*      */     //   1421: dload #32
/*      */     //   1423: dmul
/*      */     //   1424: dstore_1
/*      */     //   1425: dload_1
/*      */     //   1426: dstore_3
/*      */     //   1427: dload_3
/*      */     //   1428: dload #32
/*      */     //   1430: dmul
/*      */     //   1431: dstore_3
/*      */     //   1432: goto -> 1504
/*      */     //   1435: dload #17
/*      */     //   1437: dload #11
/*      */     //   1439: ddiv
/*      */     //   1440: dstore #7
/*      */     //   1442: dload #15
/*      */     //   1444: dload #9
/*      */     //   1446: ddiv
/*      */     //   1447: dstore #5
/*      */     //   1449: dload #7
/*      */     //   1451: dload #5
/*      */     //   1453: dcmpg
/*      */     //   1454: iflt -> 1460
/*      */     //   1457: goto -> 1467
/*      */     //   1460: dload #7
/*      */     //   1462: dstore #56
/*      */     //   1464: goto -> 1471
/*      */     //   1467: dload #5
/*      */     //   1469: dstore #56
/*      */     //   1471: dload #56
/*      */     //   1473: dstore #13
/*      */     //   1475: dload #17
/*      */     //   1477: dload #13
/*      */     //   1479: ddiv
/*      */     //   1480: dload #11
/*      */     //   1482: dsub
/*      */     //   1483: ldc2_w 0.5
/*      */     //   1486: dmul
/*      */     //   1487: dload #32
/*      */     //   1489: dmul
/*      */     //   1490: dstore_3
/*      */     //   1491: dload #15
/*      */     //   1493: dload #13
/*      */     //   1495: ddiv
/*      */     //   1496: dload #9
/*      */     //   1498: dsub
/*      */     //   1499: ldc2_w 0.5
/*      */     //   1502: dmul
/*      */     //   1503: dstore_1
/*      */     //   1504: dload #28
/*      */     //   1506: dload #30
/*      */     //   1508: dcmpg
/*      */     //   1509: iflt -> 1515
/*      */     //   1512: goto -> 1518
/*      */     //   1515: dload_3
/*      */     //   1516: dneg
/*      */     //   1517: dstore_3
/*      */     //   1518: dload #24
/*      */     //   1520: dload #26
/*      */     //   1522: dcmpg
/*      */     //   1523: iflt -> 1529
/*      */     //   1526: goto -> 1532
/*      */     //   1529: dload_1
/*      */     //   1530: dneg
/*      */     //   1531: dstore_1
/*      */     //   1532: dload #28
/*      */     //   1534: dload_3
/*      */     //   1535: dadd
/*      */     //   1536: dstore #44
/*      */     //   1538: dload #30
/*      */     //   1540: dload_3
/*      */     //   1541: dsub
/*      */     //   1542: dload #44
/*      */     //   1544: iconst_1
/*      */     //   1545: aload #19
/*      */     //   1547: iload #20
/*      */     //   1549: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1554: invokestatic Rf_GScale : (DDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1557: dload #24
/*      */     //   1559: dload_1
/*      */     //   1560: dadd
/*      */     //   1561: dstore #40
/*      */     //   1563: dload #26
/*      */     //   1565: dload_1
/*      */     //   1566: dsub
/*      */     //   1567: dload #40
/*      */     //   1569: iconst_2
/*      */     //   1570: aload #19
/*      */     //   1572: iload #20
/*      */     //   1574: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1579: invokestatic Rf_GScale : (DDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1582: goto -> 1619
/*      */     //   1585: dload #30
/*      */     //   1587: dload #28
/*      */     //   1589: iconst_1
/*      */     //   1590: aload #19
/*      */     //   1592: iload #20
/*      */     //   1594: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1599: invokestatic Rf_GScale : (DDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1602: dload #26
/*      */     //   1604: dload #24
/*      */     //   1606: iconst_2
/*      */     //   1607: aload #19
/*      */     //   1609: iload #20
/*      */     //   1611: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1616: invokestatic Rf_GScale : (DDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1619: aload #19
/*      */     //   1621: iload #20
/*      */     //   1623: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1628: invokestatic Rf_GMapWin2Fig : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1631: aload #19
/*      */     //   1633: iload #20
/*      */     //   1635: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1640: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1643: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   1646: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #473	-> 40
/*      */     //   #475	-> 48
/*      */     //   #476	-> 53
/*      */     //   #477	-> 64
/*      */     //   #479	-> 104
/*      */     //   #480	-> 110
/*      */     //   #480	-> 121
/*      */     //   #481	-> 133
/*      */     //   #482	-> 190
/*      */     //   #484	-> 195
/*      */     //   #485	-> 201
/*      */     //   #485	-> 212
/*      */     //   #486	-> 224
/*      */     //   #487	-> 281
/*      */     //   #489	-> 286
/*      */     //   #490	-> 289
/*      */     //   #491	-> 295
/*      */     //   #492	-> 308
/*      */     //   #493	-> 348
/*      */     //   #495	-> 365
/*      */     //   #497	-> 400
/*      */     //   #500	-> 470
/*      */     //   #503	-> 540
/*      */     //   #505	-> 592
/*      */     //   #494	-> 599
/*      */     //   #507	-> 616
/*      */     //   #509	-> 621
/*      */     //   #509	-> 629
/*      */     //   #509	-> 641
/*      */     //   #509	-> 646
/*      */     //   #510	-> 650
/*      */     //   #513	-> 655
/*      */     //   #514	-> 667
/*      */     //   #516	-> 680
/*      */     //   #517	-> 691
/*      */     //   #517	-> 718
/*      */     //   #518	-> 746
/*      */     //   #519	-> 786
/*      */     //   #520	-> 799
/*      */     //   #523	-> 816
/*      */     //   #523	-> 835
/*      */     //   #524	-> 856
/*      */     //   #525	-> 896
/*      */     //   #526	-> 908
/*      */     //   #528	-> 922
/*      */     //   #529	-> 933
/*      */     //   #529	-> 960
/*      */     //   #530	-> 988
/*      */     //   #531	-> 1028
/*      */     //   #532	-> 1041
/*      */     //   #535	-> 1058
/*      */     //   #535	-> 1077
/*      */     //   #536	-> 1098
/*      */     //   #537	-> 1138
/*      */     //   #538	-> 1150
/*      */     //   #540	-> 1164
/*      */     //   #540	-> 1190
/*      */     //   #540	-> 1200
/*      */     //   #541	-> 1210
/*      */     //   #540	-> 1230
/*      */     //   #541	-> 1236
/*      */     //   #541	-> 1246
/*      */     //   #542	-> 1256
/*      */     //   #544	-> 1296
/*      */     //   #544	-> 1307
/*      */     //   #546	-> 1317
/*      */     //   #547	-> 1336
/*      */     //   #548	-> 1355
/*      */     //   #549	-> 1368
/*      */     //   #550	-> 1378
/*      */     //   #550	-> 1388
/*      */     //   #553	-> 1398
/*      */     //   #553	-> 1408
/*      */     //   #553	-> 1414
/*      */     //   #553	-> 1419
/*      */     //   #554	-> 1427
/*      */     //   #556	-> 1435
/*      */     //   #557	-> 1442
/*      */     //   #558	-> 1449
/*      */     //   #558	-> 1460
/*      */     //   #558	-> 1467
/*      */     //   #558	-> 1471
/*      */     //   #559	-> 1475
/*      */     //   #560	-> 1491
/*      */     //   #562	-> 1504
/*      */     //   #562	-> 1515
/*      */     //   #563	-> 1518
/*      */     //   #563	-> 1529
/*      */     //   #564	-> 1532
/*      */     //   #565	-> 1557
/*      */     //   #568	-> 1585
/*      */     //   #569	-> 1602
/*      */     //   #572	-> 1619
/*      */     //   #573	-> 1631
/*      */     //   #575	-> 1643
/*      */     //   #575	-> 1646
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1647	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1647	1	yadd	D
/*      */     //   0	1647	3	xadd	D
/*      */     //   0	1647	5	yscale	D
/*      */     //   0	1647	7	xscale	D
/*      */     //   0	1647	9	ydelta	D
/*      */     //   0	1647	11	xdelta	D
/*      */     //   0	1647	13	scale	D
/*      */     //   0	1647	15	pin2	D
/*      */     //   0	1647	17	pin1	D
/*      */     //   0	1647	19	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1647	20	dd$offset	I
/*      */     //   0	1647	21	p	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1647	22	p$offset	I
/*      */     //   0	1647	23	logscale	I
/*      */     //   0	1647	24	ymax	D
/*      */     //   0	1647	26	ymin	D
/*      */     //   0	1647	28	xmax	D
/*      */     //   0	1647	30	xmin	D
/*      */     //   0	1647	32	asp	D
/*      */     //   0	1647	34	logarg	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1647	35	ylim	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1647	36	xlim	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1647	56	iftmp$725	D
/*      */     //   0	1647	58	iftmp$724	D
/*      */     //   0	1647	103	R_NaInt$723	I
/*      */     //   0	1647	109	R_NaInt$722	I
/*      */     //   0	1647	142	R_NaInt$721	I
/*      */     //   0	1647	148	R_NaInt$720	I
/*      */     //   0	1647	154	iftmp$719	D
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GetAxisLimits(double left, double right, int logflag, Ptr low, Ptr high) {
/*  586 */     if (logflag != 0) {
/*  587 */       left = Math.log(left);
/*  588 */       right = Math.log(right);
/*      */     } 
/*  590 */     if (left > right) {
/*  591 */       eps = left; left = right; right = eps;
/*      */     } 
/*  593 */     eps = right - left;
/*  594 */     if (eps != 0.0D)
/*      */     
/*      */     { 
/*  597 */       eps *= 1.1920928955078125E-7D; } else { eps = 5.9604644775390625E-8D; }
/*  598 */      double d2 = left - eps; low.setDouble(d2);
/*  599 */     double d1 = right + eps; high.setDouble(d1);
/*      */     
/*  601 */     if (logflag != 0) {
/*  602 */       double d4 = Math.exp(low.getDouble()); low.setDouble(d4);
/*  603 */       double d3 = Math.exp(high.getDouble()); high.setDouble(d3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP Rf_labelformat(SEXP labels) {
/*      */     DoublePtr doublePtr1;
/*      */     int j, k;
/*      */     DoublePtr doublePtr2;
/*  613 */     ei = new int[1]; di = new int[1]; wi = new int[1]; e = new int[1]; d = new int[1]; w = new int[1]; ei[0] = 0; di[0] = 0; wi[0] = 0; e[0] = 0; d[0] = 0; w[0] = 0; n = 0; ans = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue;
/*      */ 
/*      */     
/*  616 */     n = Rinternals.Rf_length(labels);
/*  617 */     Print.R_print.setAlignedInt(3, 7);
/*      */ 
/*      */     
/*  620 */     switch (Rinternals.TYPEOF(labels)) {
/*      */       case 10:
/*  622 */         ans = Rinternals.Rf_allocVector(16, n); Rinternals.Rf_protect(ans);
/*  623 */         for (i = 0; i < n; i++) {
/*  624 */           IntPtr intPtr2 = Rinternals.LOGICAL(labels); int i1 = i * 4; IntPtr intPtr1 = intPtr2; int m = 0 + i1; BytePtr bytePtr = PrtUtil.Rf_EncodeLogical(intPtr1.getInt(m), 0); strp$offset = 0;
/*  625 */           SEXP sEXP = Rinternals.Rf_mkChar(bytePtr.pointerPlus(strp$offset)); Rinternals.SET_STRING_ELT(ans, i, sEXP);
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 13:
/*  630 */         ans = Rinternals.Rf_allocVector(16, n); Rinternals.Rf_protect(ans);
/*  631 */         for (i = 0; i < n; i++) {
/*  632 */           Ptr ptr2 = Rinternals2.INTEGER(labels); int i1 = i * 4; Ptr ptr1 = ptr2; int m = 0 + i1; BytePtr bytePtr = PrtUtil.Rf_EncodeInteger(ptr1.getInt(m), 0); strp$offset = 0;
/*  633 */           SEXP sEXP = Rinternals.Rf_mkChar(bytePtr.pointerPlus(strp$offset)); Rinternals.SET_STRING_ELT(ans, i, sEXP);
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 14:
/*  638 */         format__.Rf_formatReal(Rinternals2.REAL(labels), n, (Ptr)new IntPtr(w, 0), (Ptr)new IntPtr(d, 0), (Ptr)new IntPtr(e, 0), 0);
/*  639 */         ans = Rinternals.Rf_allocVector(16, n); Rinternals.Rf_protect(ans);
/*  640 */         for (i = 0; i < n; i++) {
/*  641 */           OutDec$709 = Defn.OutDec; e$710 = e[0]; d$711 = d[0]; Ptr ptr2 = Rinternals2.REAL(labels); int i1 = i * 8; Ptr ptr1 = ptr2; int m = 0 + i1; BytePtr bytePtr = PrtUtil.Rf_EncodeReal0(ptr1.getDouble(m), 0, d$711, e$710, (BytePtr)OutDec$709); strp$offset = 0;
/*  642 */           SEXP sEXP = Rinternals.Rf_mkChar(bytePtr.pointerPlus(strp$offset)); Rinternals.SET_STRING_ELT(ans, i, sEXP);
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 15:
/*  647 */         format__.Rf_formatComplex((Ptr)Rinternals.COMPLEX(labels), n, (Ptr)new IntPtr(w, 0), (Ptr)new IntPtr(d, 0), (Ptr)new IntPtr(e, 0), (Ptr)new IntPtr(wi, 0), (Ptr)new IntPtr(di, 0), (Ptr)new IntPtr(ei, 0), 0);
/*  648 */         ans = Rinternals.Rf_allocVector(16, n); Rinternals.Rf_protect(ans);
/*  649 */         i = 0; if (i >= n)
/*  650 */           break;  OutDec$713 = Defn.OutDec; ei$714 = ei[0]; di$715 = di[0]; e$716 = e[0]; d$717 = d[0]; doublePtr2 = Rinternals.COMPLEX(labels); k = i * 16; doublePtr1 = doublePtr2; j = 0 + k; throw new UnsatisfiedLinkException("Rf_EncodeComplex");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 16:
/*  657 */         ans = Rinternals.Rf_allocVector(16, n); Rinternals.Rf_protect(ans);
/*  658 */         for (i = 0; i < n; i++) {
/*  659 */           SEXP sEXP = Rinternals.STRING_ELT(labels, i); Rinternals.SET_STRING_ELT(ans, i, sEXP);
/*      */         } 
/*      */         break;
/*      */       
/*      */       default:
/*  664 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid type for axis labels\000".getBytes(), 0)), new Object[0]); break;
/*      */     } 
/*  666 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ComputePAdjValue(double padj, int side, int las) {
/*  672 */     if (Arith.R_finite(padj) == 0)
/*  673 */       switch (las) {
/*      */         case 0:
/*  675 */           padj = 0.0D; break;
/*      */         case 1:
/*  677 */           switch (side) { case 1:
/*      */             case 3:
/*  679 */               padj = 0.0D; break;
/*      */             case 2: case 4:
/*  681 */               padj = 0.5D; break; }
/*      */           
/*      */           break;
/*      */         case 2:
/*  685 */           padj = 0.5D; break;
/*      */         case 3:
/*  687 */           switch (side) { case 1:
/*      */             case 3:
/*  689 */               padj = 0.5D; break;
/*      */             case 2: case 4:
/*  691 */               padj = 0.0D;
/*      */               break; }
/*      */           
/*      */           break;
/*      */       }  
/*  696 */     return padj; } public static void getxlimits(Ptr x, Ptr dd) { double d1;
/*      */     Ptr ptr1;
/*      */     double d2;
/*      */     double d3;
/*      */     Ptr ptr2;
/*      */     double d4;
/*      */     double d5;
/*      */     Ptr ptr3;
/*      */     double d6;
/*  705 */     switch (base__.Rf_gpptr(dd).getInt(444)) {
/*      */       case 0:
/*  707 */         d6 = base__.Rf_gpptr(dd).getDouble(0 + 35700); x.setDouble(d6);
/*  708 */         ptr3 = x; d5 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8); ptr3.setDouble(8, d5);
/*      */         break;
/*      */       case 1:
/*  711 */         d4 = graphics__.Rf_GConvertX(0.0D, 7, 12, dd); x.setDouble(d4);
/*  712 */         ptr2 = x; d3 = graphics__.Rf_GConvertX(1.0D, 7, 12, dd); ptr2.setDouble(8, d3);
/*      */         break;
/*      */       case 2:
/*  715 */         d2 = graphics__.Rf_GConvertX(0.0D, 1, 12, dd); x.setDouble(d2);
/*  716 */         ptr1 = x; d1 = graphics__.Rf_GConvertX(1.0D, 1, 12, dd); ptr1.setDouble(8, d1); break;
/*      */     }  } public static void getylimits(Ptr y, Ptr dd) { double d1; Ptr ptr1; double d2; double d3; Ptr ptr2;
/*      */     double d4;
/*      */     double d5;
/*      */     Ptr ptr3;
/*      */     double d6;
/*  722 */     switch (base__.Rf_gpptr(dd).getInt(444)) {
/*      */       case 0:
/*  724 */         d6 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16); y.setDouble(d6);
/*  725 */         ptr3 = y; d5 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24); ptr3.setDouble(8, d5);
/*      */         break;
/*      */       case 1:
/*  728 */         d4 = graphics__.Rf_GConvertY(0.0D, 7, 12, dd); y.setDouble(d4);
/*  729 */         ptr2 = y; d3 = graphics__.Rf_GConvertY(1.0D, 7, 12, dd); ptr2.setDouble(8, d3);
/*      */         break;
/*      */       case 2:
/*  732 */         d2 = graphics__.Rf_GConvertY(0.0D, 1, 12, dd); y.setDouble(d2);
/*  733 */         ptr1 = y; d1 = graphics__.Rf_GConvertY(1.0D, 1, 12, dd); ptr1.setDouble(8, d1);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_axis(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #55
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #56
/*      */     //   10: iconst_2
/*      */     //   11: newarray double
/*      */     //   13: astore #61
/*      */     //   15: iconst_2
/*      */     //   16: newarray double
/*      */     //   18: astore #62
/*      */     //   20: iconst_3
/*      */     //   21: newarray double
/*      */     //   23: astore #63
/*      */     //   25: iconst_0
/*      */     //   26: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   29: astore #33
/*      */     //   31: iconst_0
/*      */     //   32: istore #34
/*      */     //   34: dconst_0
/*      */     //   35: dstore #39
/*      */     //   37: dconst_0
/*      */     //   38: dstore #41
/*      */     //   40: dconst_0
/*      */     //   41: dstore #43
/*      */     //   43: dconst_0
/*      */     //   44: dstore #45
/*      */     //   46: dconst_0
/*      */     //   47: dstore #47
/*      */     //   49: dconst_0
/*      */     //   50: dstore #49
/*      */     //   52: dconst_0
/*      */     //   53: dstore #51
/*      */     //   55: dconst_0
/*      */     //   56: dstore #53
/*      */     //   58: aload #55
/*      */     //   60: iconst_0
/*      */     //   61: dconst_0
/*      */     //   62: dastore
/*      */     //   63: aload #56
/*      */     //   65: iconst_0
/*      */     //   66: dconst_0
/*      */     //   67: dastore
/*      */     //   68: dconst_0
/*      */     //   69: dstore #59
/*      */     //   71: dconst_0
/*      */     //   72: dstore #64
/*      */     //   74: iconst_0
/*      */     //   75: istore #75
/*      */     //   77: iconst_0
/*      */     //   78: istore #76
/*      */     //   80: iconst_0
/*      */     //   81: istore #77
/*      */     //   83: iconst_0
/*      */     //   84: istore #78
/*      */     //   86: iconst_0
/*      */     //   87: istore #79
/*      */     //   89: iconst_0
/*      */     //   90: istore #81
/*      */     //   92: iconst_0
/*      */     //   93: istore #82
/*      */     //   95: iconst_0
/*      */     //   96: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   99: astore #83
/*      */     //   101: iconst_0
/*      */     //   102: istore #84
/*      */     //   104: iconst_0
/*      */     //   105: istore #85
/*      */     //   107: iconst_0
/*      */     //   108: istore #86
/*      */     //   110: iconst_0
/*      */     //   111: istore #88
/*      */     //   113: iconst_0
/*      */     //   114: istore #90
/*      */     //   116: iconst_0
/*      */     //   117: istore #91
/*      */     //   119: iconst_0
/*      */     //   120: istore #92
/*      */     //   122: iconst_0
/*      */     //   123: istore #93
/*      */     //   125: iconst_0
/*      */     //   126: istore #94
/*      */     //   128: iconst_0
/*      */     //   129: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   132: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   137: checkcast org/renjin/sexp/SEXP
/*      */     //   140: astore #96
/*      */     //   142: iconst_0
/*      */     //   143: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   146: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   151: checkcast org/renjin/sexp/SEXP
/*      */     //   154: astore #97
/*      */     //   156: iconst_0
/*      */     //   157: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   160: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   165: checkcast org/renjin/sexp/SEXP
/*      */     //   168: astore #98
/*      */     //   170: iconst_0
/*      */     //   171: istore #87
/*      */     //   173: iconst_0
/*      */     //   174: istore #81
/*      */     //   176: iconst_0
/*      */     //   177: istore #75
/*      */     //   179: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   182: astore #33
/*      */     //   184: iconst_0
/*      */     //   185: istore #34
/*      */     //   187: aload_0
/*      */     //   188: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   191: astore_0
/*      */     //   192: aload_0
/*      */     //   193: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   196: bipush #14
/*      */     //   198: if_icmple -> 204
/*      */     //   201: goto -> 243
/*      */     //   204: new org/renjin/gcc/runtime/BytePtr
/*      */     //   207: dup
/*      */     //   208: ldc 'graphics '
/*      */     //   210: invokevirtual getBytes : ()[B
/*      */     //   213: iconst_0
/*      */     //   214: invokespecial <init> : ([BI)V
/*      */     //   217: new org/renjin/gcc/runtime/BytePtr
/*      */     //   220: dup
/*      */     //   221: ldc 'too few arguments '
/*      */     //   223: invokevirtual getBytes : ()[B
/*      */     //   226: iconst_0
/*      */     //   227: invokespecial <init> : ([BI)V
/*      */     //   230: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   233: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   236: iconst_0
/*      */     //   237: anewarray java/lang/Object
/*      */     //   240: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   243: aload #33
/*      */     //   245: iload #34
/*      */     //   247: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   252: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   255: invokestatic Rf_PrintDefaults : ()V
/*      */     //   258: aload_0
/*      */     //   259: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   262: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   265: istore #85
/*      */     //   267: iload #85
/*      */     //   269: ifle -> 284
/*      */     //   272: goto -> 275
/*      */     //   275: iload #85
/*      */     //   277: iconst_4
/*      */     //   278: if_icmpgt -> 284
/*      */     //   281: goto -> 332
/*      */     //   284: new org/renjin/gcc/runtime/BytePtr
/*      */     //   287: dup
/*      */     //   288: ldc 'graphics '
/*      */     //   290: invokevirtual getBytes : ()[B
/*      */     //   293: iconst_0
/*      */     //   294: invokespecial <init> : ([BI)V
/*      */     //   297: new org/renjin/gcc/runtime/BytePtr
/*      */     //   300: dup
/*      */     //   301: ldc_w 'invalid axis number %d '
/*      */     //   304: invokevirtual getBytes : ()[B
/*      */     //   307: iconst_0
/*      */     //   308: invokespecial <init> : ([BI)V
/*      */     //   311: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   314: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   317: iconst_1
/*      */     //   318: anewarray java/lang/Object
/*      */     //   321: dup
/*      */     //   322: iconst_0
/*      */     //   323: iload #85
/*      */     //   325: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   328: aastore
/*      */     //   329: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   332: aload_0
/*      */     //   333: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   336: astore_0
/*      */     //   337: aload_0
/*      */     //   338: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   341: astore #98
/*      */     //   343: aload_0
/*      */     //   344: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   347: astore_0
/*      */     //   348: iconst_1
/*      */     //   349: istore #77
/*      */     //   351: aload_0
/*      */     //   352: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   355: astore #97
/*      */     //   357: aload #97
/*      */     //   359: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   362: bipush #10
/*      */     //   364: if_icmpeq -> 370
/*      */     //   367: goto -> 432
/*      */     //   370: aload #97
/*      */     //   372: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   375: ifgt -> 381
/*      */     //   378: goto -> 432
/*      */     //   381: aload #97
/*      */     //   383: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   386: istore #89
/*      */     //   388: iload #89
/*      */     //   390: ifeq -> 415
/*      */     //   393: goto -> 396
/*      */     //   396: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   399: wide istore #764
/*      */     //   403: iload #89
/*      */     //   405: wide iload #764
/*      */     //   409: if_icmpeq -> 415
/*      */     //   412: goto -> 418
/*      */     //   415: iconst_0
/*      */     //   416: istore #77
/*      */     //   418: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   421: astore #97
/*      */     //   423: aload #97
/*      */     //   425: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   428: pop
/*      */     //   429: goto -> 512
/*      */     //   432: aload #97
/*      */     //   434: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   437: bipush #6
/*      */     //   439: if_icmpeq -> 457
/*      */     //   442: goto -> 445
/*      */     //   445: aload #97
/*      */     //   447: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   450: iconst_1
/*      */     //   451: if_icmpeq -> 457
/*      */     //   454: goto -> 475
/*      */     //   457: aload #97
/*      */     //   459: bipush #20
/*      */     //   461: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   464: astore #97
/*      */     //   466: aload #97
/*      */     //   468: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   471: pop
/*      */     //   472: goto -> 512
/*      */     //   475: aload #97
/*      */     //   477: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   480: bipush #20
/*      */     //   482: if_icmpeq -> 488
/*      */     //   485: goto -> 497
/*      */     //   488: aload #97
/*      */     //   490: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   493: pop
/*      */     //   494: goto -> 512
/*      */     //   497: aload #97
/*      */     //   499: bipush #16
/*      */     //   501: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   504: astore #97
/*      */     //   506: aload #97
/*      */     //   508: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   511: pop
/*      */     //   512: aload_0
/*      */     //   513: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   516: astore_0
/*      */     //   517: aload_0
/*      */     //   518: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   521: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   524: istore #76
/*      */     //   526: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   529: iload #76
/*      */     //   531: if_icmpne -> 537
/*      */     //   534: goto -> 546
/*      */     //   537: iload #76
/*      */     //   539: wide istore #758
/*      */     //   543: goto -> 551
/*      */     //   546: iconst_1
/*      */     //   547: wide istore #758
/*      */     //   551: wide iload #758
/*      */     //   555: istore #76
/*      */     //   557: aload_0
/*      */     //   558: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   561: astore_0
/*      */     //   562: aload_0
/*      */     //   563: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   566: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   569: dstore #53
/*      */     //   571: aload_0
/*      */     //   572: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   575: astore_0
/*      */     //   576: aload_0
/*      */     //   577: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   580: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   583: dstore #51
/*      */     //   585: aload_0
/*      */     //   586: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   589: astore_0
/*      */     //   590: aload_0
/*      */     //   591: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   594: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   597: istore #82
/*      */     //   599: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   602: wide istore #752
/*      */     //   606: iload #82
/*      */     //   608: wide iload #752
/*      */     //   612: if_icmpeq -> 626
/*      */     //   615: goto -> 618
/*      */     //   618: iload #82
/*      */     //   620: ifeq -> 626
/*      */     //   623: goto -> 633
/*      */     //   626: bipush #16
/*      */     //   628: istore #82
/*      */     //   630: goto -> 637
/*      */     //   633: bipush #6
/*      */     //   635: istore #82
/*      */     //   637: aload_0
/*      */     //   638: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   641: astore_0
/*      */     //   642: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   645: wide istore #751
/*      */     //   649: aload_0
/*      */     //   650: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   653: wide iload #751
/*      */     //   657: invokestatic FixupFont : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   660: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   663: istore #94
/*      */     //   665: aload_0
/*      */     //   666: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   669: astore_0
/*      */     //   670: aload_0
/*      */     //   671: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   674: iconst_0
/*      */     //   675: invokestatic Rf_FixupLty : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   678: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   681: istore #93
/*      */     //   683: aload_0
/*      */     //   684: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   687: astore_0
/*      */     //   688: aload_0
/*      */     //   689: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   692: dconst_1
/*      */     //   693: invokestatic Rf_FixupLwd : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   696: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   699: dstore #49
/*      */     //   701: aload_0
/*      */     //   702: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   705: astore_0
/*      */     //   706: aload_0
/*      */     //   707: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   710: dconst_1
/*      */     //   711: invokestatic Rf_FixupLwd : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   714: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   717: dstore #47
/*      */     //   719: aload_0
/*      */     //   720: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   723: astore_0
/*      */     //   724: aload #33
/*      */     //   726: iload #34
/*      */     //   728: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   733: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   736: bipush #76
/*      */     //   738: invokeinterface getInt : (I)I
/*      */     //   743: wide istore #740
/*      */     //   747: aload_0
/*      */     //   748: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   751: wide iload #740
/*      */     //   755: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   758: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   761: istore #91
/*      */     //   763: aload_0
/*      */     //   764: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   767: astore_0
/*      */     //   768: aload_0
/*      */     //   769: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   772: iload #91
/*      */     //   774: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   777: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   780: istore #90
/*      */     //   782: aload_0
/*      */     //   783: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   786: astore_0
/*      */     //   787: aload_0
/*      */     //   788: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   791: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   794: iconst_1
/*      */     //   795: if_icmpne -> 801
/*      */     //   798: goto -> 841
/*      */     //   801: new org/renjin/gcc/runtime/BytePtr
/*      */     //   804: dup
/*      */     //   805: ldc 'graphics '
/*      */     //   807: invokevirtual getBytes : ()[B
/*      */     //   810: iconst_0
/*      */     //   811: invokespecial <init> : ([BI)V
/*      */     //   814: new org/renjin/gcc/runtime/BytePtr
/*      */     //   817: dup
/*      */     //   818: ldc_w ''hadj' must be of length one '
/*      */     //   821: invokevirtual getBytes : ()[B
/*      */     //   824: iconst_0
/*      */     //   825: invokespecial <init> : ([BI)V
/*      */     //   828: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   831: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   834: iconst_0
/*      */     //   835: anewarray java/lang/Object
/*      */     //   838: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   841: aload_0
/*      */     //   842: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   845: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   848: dstore #45
/*      */     //   850: aload_0
/*      */     //   851: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   854: astore_0
/*      */     //   855: aload_0
/*      */     //   856: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   859: bipush #14
/*      */     //   861: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   864: astore #96
/*      */     //   866: aload #96
/*      */     //   868: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   871: pop
/*      */     //   872: aload #96
/*      */     //   874: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   877: istore #92
/*      */     //   879: iload #92
/*      */     //   881: ifle -> 887
/*      */     //   884: goto -> 944
/*      */     //   887: new org/renjin/gcc/runtime/BytePtr
/*      */     //   890: dup
/*      */     //   891: ldc 'graphics '
/*      */     //   893: invokevirtual getBytes : ()[B
/*      */     //   896: iconst_0
/*      */     //   897: invokespecial <init> : ([BI)V
/*      */     //   900: new org/renjin/gcc/runtime/BytePtr
/*      */     //   903: dup
/*      */     //   904: ldc_w 'zero-length '%s' specified '
/*      */     //   907: invokevirtual getBytes : ()[B
/*      */     //   910: iconst_0
/*      */     //   911: invokespecial <init> : ([BI)V
/*      */     //   914: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   917: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   920: iconst_1
/*      */     //   921: anewarray java/lang/Object
/*      */     //   924: dup
/*      */     //   925: iconst_0
/*      */     //   926: new org/renjin/gcc/runtime/BytePtr
/*      */     //   929: dup
/*      */     //   930: ldc_w 'padj '
/*      */     //   933: invokevirtual getBytes : ()[B
/*      */     //   936: iconst_0
/*      */     //   937: invokespecial <init> : ([BI)V
/*      */     //   940: aastore
/*      */     //   941: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   944: aload #33
/*      */     //   946: iload #34
/*      */     //   948: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   953: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   956: aload #33
/*      */     //   958: iload #34
/*      */     //   960: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   965: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   968: wide astore #724
/*      */     //   972: aload #33
/*      */     //   974: iload #34
/*      */     //   976: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   981: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   984: sipush #412
/*      */     //   987: invokeinterface getDouble : (I)D
/*      */     //   992: wide dstore #720
/*      */     //   996: wide aload #724
/*      */     //   1000: sipush #412
/*      */     //   1003: wide dload #720
/*      */     //   1007: invokeinterface setDouble : (ID)V
/*      */     //   1012: aload #33
/*      */     //   1014: iload #34
/*      */     //   1016: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1021: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1024: wide astore #718
/*      */     //   1028: aload #33
/*      */     //   1030: iload #34
/*      */     //   1032: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1037: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1040: sipush #420
/*      */     //   1043: invokeinterface getDouble : (I)D
/*      */     //   1048: wide dstore #714
/*      */     //   1052: wide aload #718
/*      */     //   1056: sipush #420
/*      */     //   1059: wide dload #714
/*      */     //   1063: invokeinterface setDouble : (ID)V
/*      */     //   1068: aload #33
/*      */     //   1070: iload #34
/*      */     //   1072: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1077: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1080: wide astore #712
/*      */     //   1084: aload #33
/*      */     //   1086: iload #34
/*      */     //   1088: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1093: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1096: sipush #428
/*      */     //   1099: invokeinterface getDouble : (I)D
/*      */     //   1104: wide dstore #708
/*      */     //   1108: wide aload #712
/*      */     //   1112: sipush #428
/*      */     //   1115: wide dload #708
/*      */     //   1119: invokeinterface setDouble : (ID)V
/*      */     //   1124: aload #33
/*      */     //   1126: iload #34
/*      */     //   1128: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1133: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1136: wide astore #706
/*      */     //   1140: aload #33
/*      */     //   1142: iload #34
/*      */     //   1144: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1149: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1152: sipush #452
/*      */     //   1155: invokeinterface getDouble : (I)D
/*      */     //   1160: wide dstore #702
/*      */     //   1164: wide aload #706
/*      */     //   1168: sipush #452
/*      */     //   1171: wide dload #702
/*      */     //   1175: invokeinterface setDouble : (ID)V
/*      */     //   1180: aload #33
/*      */     //   1182: iload #34
/*      */     //   1184: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1189: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1192: wide astore #700
/*      */     //   1196: aload #33
/*      */     //   1198: iload #34
/*      */     //   1200: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1205: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1208: sipush #460
/*      */     //   1211: invokeinterface getDouble : (I)D
/*      */     //   1216: wide dstore #696
/*      */     //   1220: wide aload #700
/*      */     //   1224: sipush #460
/*      */     //   1227: wide dload #696
/*      */     //   1231: invokeinterface setDouble : (ID)V
/*      */     //   1236: aload #33
/*      */     //   1238: iload #34
/*      */     //   1240: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1245: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1248: wide astore #694
/*      */     //   1252: aload #33
/*      */     //   1254: iload #34
/*      */     //   1256: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1261: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1264: sipush #468
/*      */     //   1267: invokeinterface getDouble : (I)D
/*      */     //   1272: wide dstore #690
/*      */     //   1276: wide aload #694
/*      */     //   1280: sipush #468
/*      */     //   1283: wide dload #690
/*      */     //   1287: invokeinterface setDouble : (ID)V
/*      */     //   1292: aload_0
/*      */     //   1293: aload #33
/*      */     //   1295: iload #34
/*      */     //   1297: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1302: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1305: iload #85
/*      */     //   1307: lookupswitch default -> 1776, 1 -> 1348, 2 -> 1562, 3 -> 1348, 4 -> 1562
/*      */     //   1348: aload #33
/*      */     //   1350: iload #34
/*      */     //   1352: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1357: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1360: sipush #412
/*      */     //   1363: invokeinterface getDouble : (I)D
/*      */     //   1368: wide dstore #686
/*      */     //   1372: aload #63
/*      */     //   1374: iconst_0
/*      */     //   1375: wide dload #686
/*      */     //   1379: dastore
/*      */     //   1380: aload #33
/*      */     //   1382: iload #34
/*      */     //   1384: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1389: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1392: sipush #420
/*      */     //   1395: invokeinterface getDouble : (I)D
/*      */     //   1400: wide dstore #682
/*      */     //   1404: aload #63
/*      */     //   1406: iconst_1
/*      */     //   1407: wide dload #682
/*      */     //   1411: dastore
/*      */     //   1412: aload #33
/*      */     //   1414: iload #34
/*      */     //   1416: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1421: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1424: sipush #428
/*      */     //   1427: invokeinterface getDouble : (I)D
/*      */     //   1432: wide dstore #678
/*      */     //   1436: aload #63
/*      */     //   1438: iconst_2
/*      */     //   1439: wide dload #678
/*      */     //   1443: dastore
/*      */     //   1444: aload #33
/*      */     //   1446: iload #34
/*      */     //   1448: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1453: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1456: iconst_0
/*      */     //   1457: ldc_w 35700
/*      */     //   1460: iadd
/*      */     //   1461: invokeinterface getDouble : (I)D
/*      */     //   1466: wide dstore #674
/*      */     //   1470: aload #62
/*      */     //   1472: iconst_0
/*      */     //   1473: wide dload #674
/*      */     //   1477: dastore
/*      */     //   1478: aload #33
/*      */     //   1480: iload #34
/*      */     //   1482: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1487: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1490: iconst_0
/*      */     //   1491: ldc_w 35700
/*      */     //   1494: iadd
/*      */     //   1495: bipush #8
/*      */     //   1497: iadd
/*      */     //   1498: invokeinterface getDouble : (I)D
/*      */     //   1503: wide dstore #670
/*      */     //   1507: aload #62
/*      */     //   1509: iconst_1
/*      */     //   1510: wide dload #670
/*      */     //   1514: dastore
/*      */     //   1515: aload #33
/*      */     //   1517: iload #34
/*      */     //   1519: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1524: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1527: sipush #440
/*      */     //   1530: invokeinterface getInt : (I)I
/*      */     //   1535: istore #75
/*      */     //   1537: aload #33
/*      */     //   1539: iload #34
/*      */     //   1541: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1546: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1549: sipush #296
/*      */     //   1552: invokeinterface getInt : (I)I
/*      */     //   1557: istore #87
/*      */     //   1559: goto -> 1776
/*      */     //   1562: aload #33
/*      */     //   1564: iload #34
/*      */     //   1566: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1571: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1574: sipush #452
/*      */     //   1577: invokeinterface getDouble : (I)D
/*      */     //   1582: wide dstore #662
/*      */     //   1586: aload #63
/*      */     //   1588: iconst_0
/*      */     //   1589: wide dload #662
/*      */     //   1593: dastore
/*      */     //   1594: aload #33
/*      */     //   1596: iload #34
/*      */     //   1598: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1603: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1606: sipush #460
/*      */     //   1609: invokeinterface getDouble : (I)D
/*      */     //   1614: wide dstore #658
/*      */     //   1618: aload #63
/*      */     //   1620: iconst_1
/*      */     //   1621: wide dload #658
/*      */     //   1625: dastore
/*      */     //   1626: aload #33
/*      */     //   1628: iload #34
/*      */     //   1630: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1635: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1638: sipush #468
/*      */     //   1641: invokeinterface getDouble : (I)D
/*      */     //   1646: wide dstore #654
/*      */     //   1650: aload #63
/*      */     //   1652: iconst_2
/*      */     //   1653: wide dload #654
/*      */     //   1657: dastore
/*      */     //   1658: aload #33
/*      */     //   1660: iload #34
/*      */     //   1662: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1667: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1670: iconst_0
/*      */     //   1671: ldc_w 35700
/*      */     //   1674: iadd
/*      */     //   1675: bipush #16
/*      */     //   1677: iadd
/*      */     //   1678: invokeinterface getDouble : (I)D
/*      */     //   1683: wide dstore #650
/*      */     //   1687: aload #62
/*      */     //   1689: iconst_0
/*      */     //   1690: wide dload #650
/*      */     //   1694: dastore
/*      */     //   1695: aload #33
/*      */     //   1697: iload #34
/*      */     //   1699: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1704: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1707: iconst_0
/*      */     //   1708: ldc_w 35700
/*      */     //   1711: iadd
/*      */     //   1712: bipush #24
/*      */     //   1714: iadd
/*      */     //   1715: invokeinterface getDouble : (I)D
/*      */     //   1720: wide dstore #646
/*      */     //   1724: aload #62
/*      */     //   1726: iconst_1
/*      */     //   1727: wide dload #646
/*      */     //   1731: dastore
/*      */     //   1732: aload #33
/*      */     //   1734: iload #34
/*      */     //   1736: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1741: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1744: sipush #480
/*      */     //   1747: invokeinterface getInt : (I)I
/*      */     //   1752: istore #75
/*      */     //   1754: aload #33
/*      */     //   1756: iload #34
/*      */     //   1758: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1763: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1766: sipush #300
/*      */     //   1769: invokeinterface getInt : (I)I
/*      */     //   1774: istore #87
/*      */     //   1776: dload #53
/*      */     //   1778: invokestatic R_finite : (D)I
/*      */     //   1781: ifeq -> 1787
/*      */     //   1784: goto -> 1814
/*      */     //   1787: aload #33
/*      */     //   1789: iload #34
/*      */     //   1791: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1796: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1799: sipush #356
/*      */     //   1802: invokeinterface getDouble : (I)D
/*      */     //   1807: dstore #53
/*      */     //   1809: dload #53
/*      */     //   1811: d2i
/*      */     //   1812: istore #81
/*      */     //   1814: dload #51
/*      */     //   1816: invokestatic R_finite : (D)I
/*      */     //   1819: ifeq -> 1825
/*      */     //   1822: goto -> 1833
/*      */     //   1825: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1828: dstore #51
/*      */     //   1830: goto -> 1836
/*      */     //   1833: iconst_0
/*      */     //   1834: istore #81
/*      */     //   1836: aload #98
/*      */     //   1838: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1841: ifeq -> 1851
/*      */     //   1844: goto -> 1847
/*      */     //   1847: iconst_0
/*      */     //   1848: goto -> 1852
/*      */     //   1851: iconst_1
/*      */     //   1852: istore #74
/*      */     //   1854: iload #74
/*      */     //   1856: ifne -> 1862
/*      */     //   1859: goto -> 1906
/*      */     //   1862: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1865: dup
/*      */     //   1866: aload #63
/*      */     //   1868: iconst_0
/*      */     //   1869: invokespecial <init> : ([DI)V
/*      */     //   1872: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1875: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1878: dup
/*      */     //   1879: aload #62
/*      */     //   1881: iconst_0
/*      */     //   1882: invokespecial <init> : ([DI)V
/*      */     //   1885: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1888: iload #87
/*      */     //   1890: iload #75
/*      */     //   1892: invokestatic Rf_CreateAtVector : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;II)Lorg/renjin/sexp/SEXP;
/*      */     //   1895: astore #98
/*      */     //   1897: aload #98
/*      */     //   1899: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1902: pop
/*      */     //   1903: goto -> 1950
/*      */     //   1906: aload #98
/*      */     //   1908: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1911: bipush #14
/*      */     //   1913: if_icmpeq -> 1919
/*      */     //   1916: goto -> 1935
/*      */     //   1919: aload #98
/*      */     //   1921: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1924: astore #98
/*      */     //   1926: aload #98
/*      */     //   1928: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1931: pop
/*      */     //   1932: goto -> 1950
/*      */     //   1935: aload #98
/*      */     //   1937: bipush #14
/*      */     //   1939: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   1942: astore #98
/*      */     //   1944: aload #98
/*      */     //   1946: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1949: pop
/*      */     //   1950: aload #98
/*      */     //   1952: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1955: istore #88
/*      */     //   1957: iload #77
/*      */     //   1959: ifne -> 1965
/*      */     //   1962: goto -> 2164
/*      */     //   1965: aload #97
/*      */     //   1967: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1970: ifeq -> 1976
/*      */     //   1973: goto -> 1986
/*      */     //   1976: aload #98
/*      */     //   1978: invokestatic Rf_labelformat : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1981: astore #97
/*      */     //   1983: goto -> 2054
/*      */     //   1986: iload #74
/*      */     //   1988: ifne -> 1994
/*      */     //   1991: goto -> 2034
/*      */     //   1994: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1997: dup
/*      */     //   1998: ldc 'graphics '
/*      */     //   2000: invokevirtual getBytes : ()[B
/*      */     //   2003: iconst_0
/*      */     //   2004: invokespecial <init> : ([BI)V
/*      */     //   2007: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2010: dup
/*      */     //   2011: ldc_w ''labels' is supplied and not 'at' '
/*      */     //   2014: invokevirtual getBytes : ()[B
/*      */     //   2017: iconst_0
/*      */     //   2018: invokespecial <init> : ([BI)V
/*      */     //   2021: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2024: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2027: iconst_0
/*      */     //   2028: anewarray java/lang/Object
/*      */     //   2031: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2034: aload #97
/*      */     //   2036: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2039: bipush #20
/*      */     //   2041: if_icmpne -> 2047
/*      */     //   2044: goto -> 2054
/*      */     //   2047: aload #97
/*      */     //   2049: invokestatic Rf_labelformat : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2052: astore #97
/*      */     //   2054: aload #98
/*      */     //   2056: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2059: wide istore #630
/*      */     //   2063: aload #97
/*      */     //   2065: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2068: wide istore #629
/*      */     //   2072: wide iload #630
/*      */     //   2076: wide iload #629
/*      */     //   2080: if_icmpne -> 2086
/*      */     //   2083: goto -> 2164
/*      */     //   2086: aload #97
/*      */     //   2088: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2091: wide istore #628
/*      */     //   2095: aload #98
/*      */     //   2097: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2100: wide istore #627
/*      */     //   2104: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2107: dup
/*      */     //   2108: ldc 'graphics '
/*      */     //   2110: invokevirtual getBytes : ()[B
/*      */     //   2113: iconst_0
/*      */     //   2114: invokespecial <init> : ([BI)V
/*      */     //   2117: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2120: dup
/*      */     //   2121: ldc_w ''at' and 'labels' lengths differ, %d != %d '
/*      */     //   2124: invokevirtual getBytes : ()[B
/*      */     //   2127: iconst_0
/*      */     //   2128: invokespecial <init> : ([BI)V
/*      */     //   2131: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2134: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2137: iconst_2
/*      */     //   2138: anewarray java/lang/Object
/*      */     //   2141: dup
/*      */     //   2142: iconst_0
/*      */     //   2143: wide iload #627
/*      */     //   2147: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   2150: aastore
/*      */     //   2151: dup
/*      */     //   2152: iconst_1
/*      */     //   2153: wide iload #628
/*      */     //   2157: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   2160: aastore
/*      */     //   2161: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2164: aload #97
/*      */     //   2166: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2169: pop
/*      */     //   2170: iload #88
/*      */     //   2172: iconst_4
/*      */     //   2173: imul
/*      */     //   2174: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   2177: astore #83
/*      */     //   2179: iconst_0
/*      */     //   2180: istore #84
/*      */     //   2182: iconst_0
/*      */     //   2183: istore #89
/*      */     //   2185: goto -> 2231
/*      */     //   2188: iload #89
/*      */     //   2190: iconst_4
/*      */     //   2191: imul
/*      */     //   2192: wide istore #621
/*      */     //   2196: aload #83
/*      */     //   2198: wide astore #619
/*      */     //   2202: iload #84
/*      */     //   2204: wide iload #621
/*      */     //   2208: iadd
/*      */     //   2209: wide istore #620
/*      */     //   2213: wide aload #619
/*      */     //   2217: wide iload #620
/*      */     //   2221: iload #89
/*      */     //   2223: invokeinterface setInt : (II)V
/*      */     //   2228: iinc #89, 1
/*      */     //   2231: iload #89
/*      */     //   2233: iload #88
/*      */     //   2235: if_icmplt -> 2188
/*      */     //   2238: goto -> 2241
/*      */     //   2241: aload #98
/*      */     //   2243: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2246: aload #83
/*      */     //   2248: iload #84
/*      */     //   2250: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2255: iload #88
/*      */     //   2257: invokestatic rsort_with_index : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)V
/*      */     //   2260: iconst_0
/*      */     //   2261: istore #86
/*      */     //   2263: iconst_0
/*      */     //   2264: istore #89
/*      */     //   2266: goto -> 2336
/*      */     //   2269: aload #98
/*      */     //   2271: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2274: wide astore #615
/*      */     //   2278: iload #89
/*      */     //   2280: bipush #8
/*      */     //   2282: imul
/*      */     //   2283: wide istore #613
/*      */     //   2287: wide aload #615
/*      */     //   2291: wide astore #611
/*      */     //   2295: iconst_0
/*      */     //   2296: wide iload #613
/*      */     //   2300: iadd
/*      */     //   2301: wide istore #612
/*      */     //   2305: wide aload #611
/*      */     //   2309: wide iload #612
/*      */     //   2313: invokeinterface getDouble : (I)D
/*      */     //   2318: invokestatic R_finite : (D)I
/*      */     //   2321: ifne -> 2327
/*      */     //   2324: goto -> 2333
/*      */     //   2327: iload #89
/*      */     //   2329: iconst_1
/*      */     //   2330: iadd
/*      */     //   2331: istore #86
/*      */     //   2333: iinc #89, 1
/*      */     //   2336: iload #89
/*      */     //   2338: iload #88
/*      */     //   2340: if_icmplt -> 2269
/*      */     //   2343: goto -> 2346
/*      */     //   2346: iload #88
/*      */     //   2348: ifgt -> 2354
/*      */     //   2351: goto -> 2402
/*      */     //   2354: iload #86
/*      */     //   2356: ifeq -> 2362
/*      */     //   2359: goto -> 2402
/*      */     //   2362: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2365: dup
/*      */     //   2366: ldc 'graphics '
/*      */     //   2368: invokevirtual getBytes : ()[B
/*      */     //   2371: iconst_0
/*      */     //   2372: invokespecial <init> : ([BI)V
/*      */     //   2375: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2378: dup
/*      */     //   2379: ldc_w 'no locations are finite '
/*      */     //   2382: invokevirtual getBytes : ()[B
/*      */     //   2385: iconst_0
/*      */     //   2386: invokespecial <init> : ([BI)V
/*      */     //   2389: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2392: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2395: iconst_0
/*      */     //   2396: anewarray java/lang/Object
/*      */     //   2399: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2402: iload #86
/*      */     //   2404: istore #88
/*      */     //   2406: iload #88
/*      */     //   2408: ifeq -> 2508
/*      */     //   2411: goto -> 2414
/*      */     //   2414: iload #85
/*      */     //   2416: iconst_1
/*      */     //   2417: if_icmpeq -> 2432
/*      */     //   2420: goto -> 2423
/*      */     //   2423: iload #85
/*      */     //   2425: iconst_3
/*      */     //   2426: if_icmpeq -> 2432
/*      */     //   2429: goto -> 2461
/*      */     //   2432: aload #33
/*      */     //   2434: iload #34
/*      */     //   2436: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2441: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2444: sipush #437
/*      */     //   2447: invokeinterface getByte : (I)B
/*      */     //   2452: bipush #110
/*      */     //   2454: i2b
/*      */     //   2455: if_icmpeq -> 2508
/*      */     //   2458: goto -> 2461
/*      */     //   2461: iload #85
/*      */     //   2463: iconst_2
/*      */     //   2464: if_icmpeq -> 2479
/*      */     //   2467: goto -> 2470
/*      */     //   2470: iload #85
/*      */     //   2472: iconst_4
/*      */     //   2473: if_icmpeq -> 2479
/*      */     //   2476: goto -> 2530
/*      */     //   2479: aload #33
/*      */     //   2481: iload #34
/*      */     //   2483: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2488: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2491: sipush #477
/*      */     //   2494: invokeinterface getByte : (I)B
/*      */     //   2499: bipush #110
/*      */     //   2501: i2b
/*      */     //   2502: if_icmpeq -> 2508
/*      */     //   2505: goto -> 2530
/*      */     //   2508: aload #33
/*      */     //   2510: iload #34
/*      */     //   2512: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2517: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2520: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   2523: wide astore #599
/*      */     //   2527: goto -> 7758
/*      */     //   2530: aload #33
/*      */     //   2532: iload #34
/*      */     //   2534: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2539: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2542: sipush #312
/*      */     //   2545: iload #93
/*      */     //   2547: invokeinterface setInt : (II)V
/*      */     //   2552: aload #33
/*      */     //   2554: iload #34
/*      */     //   2556: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2561: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2564: sipush #316
/*      */     //   2567: dload #49
/*      */     //   2569: invokeinterface setDouble : (ID)V
/*      */     //   2574: aload #33
/*      */     //   2576: iload #34
/*      */     //   2578: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2583: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2586: wide astore #593
/*      */     //   2590: dload #45
/*      */     //   2592: invokestatic R_finite : (D)I
/*      */     //   2595: ifne -> 2601
/*      */     //   2598: goto -> 2610
/*      */     //   2601: dload #45
/*      */     //   2603: wide dstore #591
/*      */     //   2607: goto -> 2617
/*      */     //   2610: ldc2_w 0.5
/*      */     //   2613: wide dstore #591
/*      */     //   2617: wide aload #593
/*      */     //   2621: bipush #8
/*      */     //   2623: wide dload #591
/*      */     //   2627: invokeinterface setDouble : (ID)V
/*      */     //   2632: aload #33
/*      */     //   2634: iload #34
/*      */     //   2636: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2641: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2644: wide astore #588
/*      */     //   2648: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   2651: wide istore #586
/*      */     //   2655: iload #94
/*      */     //   2657: wide iload #586
/*      */     //   2661: if_icmpeq -> 2667
/*      */     //   2664: goto -> 2694
/*      */     //   2667: aload #33
/*      */     //   2669: iload #34
/*      */     //   2671: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2676: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2679: sipush #536
/*      */     //   2682: invokeinterface getInt : (I)I
/*      */     //   2687: wide istore #587
/*      */     //   2691: goto -> 2700
/*      */     //   2694: iload #94
/*      */     //   2696: wide istore #587
/*      */     //   2700: wide aload #588
/*      */     //   2704: sipush #284
/*      */     //   2707: wide iload #587
/*      */     //   2711: invokeinterface setInt : (II)V
/*      */     //   2716: aload #33
/*      */     //   2718: iload #34
/*      */     //   2720: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2725: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2728: wide astore #582
/*      */     //   2732: aload #33
/*      */     //   2734: iload #34
/*      */     //   2736: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2741: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2744: sipush #484
/*      */     //   2747: invokeinterface getDouble : (I)D
/*      */     //   2752: wide dstore #578
/*      */     //   2756: aload #33
/*      */     //   2758: iload #34
/*      */     //   2760: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2765: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2768: sipush #516
/*      */     //   2771: invokeinterface getDouble : (I)D
/*      */     //   2776: wide dstore #574
/*      */     //   2780: wide dload #578
/*      */     //   2784: wide dload #574
/*      */     //   2788: dmul
/*      */     //   2789: wide dstore #572
/*      */     //   2793: wide aload #582
/*      */     //   2797: bipush #28
/*      */     //   2799: wide dload #572
/*      */     //   2803: invokeinterface setDouble : (ID)V
/*      */     //   2808: iconst_1
/*      */     //   2809: aload #33
/*      */     //   2811: iload #34
/*      */     //   2813: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2818: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2821: iload #85
/*      */     //   2823: lookupswitch default -> 7727, 1 -> 2864, 2 -> 5371, 3 -> 2864, 4 -> 5371
/*      */     //   2864: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2867: dup
/*      */     //   2868: aload #61
/*      */     //   2870: iconst_0
/*      */     //   2871: invokespecial <init> : ([DI)V
/*      */     //   2874: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2877: aload #33
/*      */     //   2879: iload #34
/*      */     //   2881: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2886: invokestatic getxlimits : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2889: aload #33
/*      */     //   2891: iload #34
/*      */     //   2893: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2898: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2901: sipush #444
/*      */     //   2904: iconst_2
/*      */     //   2905: invokeinterface setInt : (II)V
/*      */     //   2910: aload #61
/*      */     //   2912: iconst_1
/*      */     //   2913: daload
/*      */     //   2914: wide dstore #568
/*      */     //   2918: aload #61
/*      */     //   2920: iconst_0
/*      */     //   2921: daload
/*      */     //   2922: wide dload #568
/*      */     //   2926: iload #75
/*      */     //   2928: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2931: dup
/*      */     //   2932: aload #56
/*      */     //   2934: iconst_0
/*      */     //   2935: invokespecial <init> : ([DI)V
/*      */     //   2938: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2941: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2944: dup
/*      */     //   2945: aload #55
/*      */     //   2947: iconst_0
/*      */     //   2948: invokespecial <init> : ([DI)V
/*      */     //   2951: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2954: invokestatic GetAxisLimits : (DDILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2957: aload #98
/*      */     //   2959: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2962: invokeinterface getDouble : ()D
/*      */     //   2967: wide dstore #562
/*      */     //   2971: aload #56
/*      */     //   2973: iconst_0
/*      */     //   2974: daload
/*      */     //   2975: wide dload #562
/*      */     //   2979: invokestatic Rf_fmax2 : (DD)D
/*      */     //   2982: wide dstore #558
/*      */     //   2986: aload #55
/*      */     //   2988: iconst_0
/*      */     //   2989: daload
/*      */     //   2990: wide dload #558
/*      */     //   2994: invokestatic Rf_fmin2 : (DD)D
/*      */     //   2997: bipush #12
/*      */     //   2999: bipush #7
/*      */     //   3001: aload #33
/*      */     //   3003: iload #34
/*      */     //   3005: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3010: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3013: dstore #37
/*      */     //   3015: aload #98
/*      */     //   3017: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3020: wide astore #552
/*      */     //   3024: iload #88
/*      */     //   3026: iconst_m1
/*      */     //   3027: iadd
/*      */     //   3028: bipush #8
/*      */     //   3030: imul
/*      */     //   3031: wide istore #549
/*      */     //   3035: wide aload #552
/*      */     //   3039: wide astore #547
/*      */     //   3043: iconst_0
/*      */     //   3044: wide iload #549
/*      */     //   3048: iadd
/*      */     //   3049: wide istore #548
/*      */     //   3053: wide aload #547
/*      */     //   3057: wide iload #548
/*      */     //   3061: invokeinterface getDouble : (I)D
/*      */     //   3066: wide dstore #545
/*      */     //   3070: aload #56
/*      */     //   3072: iconst_0
/*      */     //   3073: daload
/*      */     //   3074: wide dload #545
/*      */     //   3078: invokestatic Rf_fmax2 : (DD)D
/*      */     //   3081: wide dstore #541
/*      */     //   3085: aload #55
/*      */     //   3087: iconst_0
/*      */     //   3088: daload
/*      */     //   3089: wide dload #541
/*      */     //   3093: invokestatic Rf_fmin2 : (DD)D
/*      */     //   3096: bipush #12
/*      */     //   3098: bipush #7
/*      */     //   3100: aload #33
/*      */     //   3102: iload #34
/*      */     //   3104: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3109: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3112: dstore #35
/*      */     //   3114: iload #85
/*      */     //   3116: iconst_1
/*      */     //   3117: if_icmpeq -> 3123
/*      */     //   3120: goto -> 3523
/*      */     //   3123: dload #51
/*      */     //   3125: invokestatic R_finite : (D)I
/*      */     //   3128: ifne -> 3134
/*      */     //   3131: goto -> 3157
/*      */     //   3134: dload #51
/*      */     //   3136: bipush #12
/*      */     //   3138: bipush #7
/*      */     //   3140: aload #33
/*      */     //   3142: iload #34
/*      */     //   3144: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3149: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3152: dstore #43
/*      */     //   3154: goto -> 3219
/*      */     //   3157: iload #82
/*      */     //   3159: wide istore #535
/*      */     //   3163: dconst_0
/*      */     //   3164: wide iload #535
/*      */     //   3168: bipush #7
/*      */     //   3170: aload #33
/*      */     //   3172: iload #34
/*      */     //   3174: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3179: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3182: wide dstore #533
/*      */     //   3186: dload #53
/*      */     //   3188: bipush #14
/*      */     //   3190: bipush #7
/*      */     //   3192: aload #33
/*      */     //   3194: iload #34
/*      */     //   3196: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3201: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3204: wide dstore #531
/*      */     //   3208: wide dload #533
/*      */     //   3212: wide dload #531
/*      */     //   3216: dsub
/*      */     //   3217: dstore #43
/*      */     //   3219: aload #33
/*      */     //   3221: iload #34
/*      */     //   3223: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3228: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3231: sipush #396
/*      */     //   3234: invokeinterface getDouble : (I)D
/*      */     //   3239: invokestatic R_finite : (D)I
/*      */     //   3242: ifne -> 3248
/*      */     //   3245: goto -> 3479
/*      */     //   3248: aload #33
/*      */     //   3250: iload #34
/*      */     //   3252: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3257: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3260: sipush #396
/*      */     //   3263: invokeinterface getDouble : (I)D
/*      */     //   3268: ldc2_w 0.5
/*      */     //   3271: dcmpl
/*      */     //   3272: ifgt -> 3278
/*      */     //   3275: goto -> 3319
/*      */     //   3278: aload #33
/*      */     //   3280: iload #34
/*      */     //   3282: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3287: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3290: sipush #396
/*      */     //   3293: invokeinterface getDouble : (I)D
/*      */     //   3298: bipush #16
/*      */     //   3300: bipush #7
/*      */     //   3302: aload #33
/*      */     //   3304: iload #34
/*      */     //   3306: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3311: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3314: dstore #31
/*      */     //   3316: goto -> 3469
/*      */     //   3319: aload #33
/*      */     //   3321: iload #34
/*      */     //   3323: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3328: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3331: sipush #396
/*      */     //   3334: invokeinterface getDouble : (I)D
/*      */     //   3339: bipush #16
/*      */     //   3341: bipush #13
/*      */     //   3343: aload #33
/*      */     //   3345: iload #34
/*      */     //   3347: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3352: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3355: dstore #29
/*      */     //   3357: aload #33
/*      */     //   3359: iload #34
/*      */     //   3361: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3366: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3369: sipush #396
/*      */     //   3372: invokeinterface getDouble : (I)D
/*      */     //   3377: bipush #16
/*      */     //   3379: bipush #13
/*      */     //   3381: aload #33
/*      */     //   3383: iload #34
/*      */     //   3385: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3390: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3393: dstore #27
/*      */     //   3395: dload #29
/*      */     //   3397: invokestatic abs : (D)D
/*      */     //   3400: wide dstore #506
/*      */     //   3404: dload #27
/*      */     //   3406: invokestatic abs : (D)D
/*      */     //   3409: wide dstore #504
/*      */     //   3413: wide dload #506
/*      */     //   3417: wide dload #504
/*      */     //   3421: dcmpg
/*      */     //   3422: iflt -> 3428
/*      */     //   3425: goto -> 3437
/*      */     //   3428: dload #29
/*      */     //   3430: wide dstore #508
/*      */     //   3434: goto -> 3443
/*      */     //   3437: dload #27
/*      */     //   3439: wide dstore #508
/*      */     //   3443: wide dload #508
/*      */     //   3447: dstore #29
/*      */     //   3449: dload #29
/*      */     //   3451: bipush #13
/*      */     //   3453: bipush #7
/*      */     //   3455: aload #33
/*      */     //   3457: iload #34
/*      */     //   3459: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3464: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3467: dstore #31
/*      */     //   3469: dload #43
/*      */     //   3471: dload #31
/*      */     //   3473: dadd
/*      */     //   3474: dstore #41
/*      */     //   3476: goto -> 3928
/*      */     //   3479: aload #33
/*      */     //   3481: iload #34
/*      */     //   3483: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3488: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3491: sipush #404
/*      */     //   3494: invokeinterface getDouble : (I)D
/*      */     //   3499: bipush #14
/*      */     //   3501: bipush #7
/*      */     //   3503: aload #33
/*      */     //   3505: iload #34
/*      */     //   3507: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3512: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3515: dload #43
/*      */     //   3517: dadd
/*      */     //   3518: dstore #41
/*      */     //   3520: goto -> 3928
/*      */     //   3523: dload #51
/*      */     //   3525: invokestatic R_finite : (D)I
/*      */     //   3528: ifne -> 3534
/*      */     //   3531: goto -> 3557
/*      */     //   3534: dload #51
/*      */     //   3536: bipush #12
/*      */     //   3538: bipush #7
/*      */     //   3540: aload #33
/*      */     //   3542: iload #34
/*      */     //   3544: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3549: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3552: dstore #43
/*      */     //   3554: goto -> 3619
/*      */     //   3557: iload #82
/*      */     //   3559: wide istore #496
/*      */     //   3563: dconst_1
/*      */     //   3564: wide iload #496
/*      */     //   3568: bipush #7
/*      */     //   3570: aload #33
/*      */     //   3572: iload #34
/*      */     //   3574: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3579: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3582: wide dstore #494
/*      */     //   3586: dload #53
/*      */     //   3588: bipush #14
/*      */     //   3590: bipush #7
/*      */     //   3592: aload #33
/*      */     //   3594: iload #34
/*      */     //   3596: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3601: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3604: wide dstore #492
/*      */     //   3608: wide dload #494
/*      */     //   3612: wide dload #492
/*      */     //   3616: dadd
/*      */     //   3617: dstore #43
/*      */     //   3619: aload #33
/*      */     //   3621: iload #34
/*      */     //   3623: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3628: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3631: sipush #396
/*      */     //   3634: invokeinterface getDouble : (I)D
/*      */     //   3639: invokestatic R_finite : (D)I
/*      */     //   3642: ifne -> 3648
/*      */     //   3645: goto -> 3879
/*      */     //   3648: aload #33
/*      */     //   3650: iload #34
/*      */     //   3652: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3657: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3660: sipush #396
/*      */     //   3663: invokeinterface getDouble : (I)D
/*      */     //   3668: ldc2_w 0.5
/*      */     //   3671: dcmpl
/*      */     //   3672: ifgt -> 3678
/*      */     //   3675: goto -> 3719
/*      */     //   3678: aload #33
/*      */     //   3680: iload #34
/*      */     //   3682: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3687: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3690: sipush #396
/*      */     //   3693: invokeinterface getDouble : (I)D
/*      */     //   3698: bipush #16
/*      */     //   3700: bipush #7
/*      */     //   3702: aload #33
/*      */     //   3704: iload #34
/*      */     //   3706: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3711: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3714: dstore #25
/*      */     //   3716: goto -> 3869
/*      */     //   3719: aload #33
/*      */     //   3721: iload #34
/*      */     //   3723: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3728: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3731: sipush #396
/*      */     //   3734: invokeinterface getDouble : (I)D
/*      */     //   3739: bipush #16
/*      */     //   3741: bipush #13
/*      */     //   3743: aload #33
/*      */     //   3745: iload #34
/*      */     //   3747: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3752: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3755: dstore #23
/*      */     //   3757: aload #33
/*      */     //   3759: iload #34
/*      */     //   3761: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3766: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3769: sipush #396
/*      */     //   3772: invokeinterface getDouble : (I)D
/*      */     //   3777: bipush #16
/*      */     //   3779: bipush #13
/*      */     //   3781: aload #33
/*      */     //   3783: iload #34
/*      */     //   3785: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3790: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3793: dstore #21
/*      */     //   3795: dload #23
/*      */     //   3797: invokestatic abs : (D)D
/*      */     //   3800: wide dstore #467
/*      */     //   3804: dload #21
/*      */     //   3806: invokestatic abs : (D)D
/*      */     //   3809: wide dstore #465
/*      */     //   3813: wide dload #467
/*      */     //   3817: wide dload #465
/*      */     //   3821: dcmpg
/*      */     //   3822: iflt -> 3828
/*      */     //   3825: goto -> 3837
/*      */     //   3828: dload #23
/*      */     //   3830: wide dstore #469
/*      */     //   3834: goto -> 3843
/*      */     //   3837: dload #21
/*      */     //   3839: wide dstore #469
/*      */     //   3843: wide dload #469
/*      */     //   3847: dstore #23
/*      */     //   3849: dload #23
/*      */     //   3851: bipush #13
/*      */     //   3853: bipush #7
/*      */     //   3855: aload #33
/*      */     //   3857: iload #34
/*      */     //   3859: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3864: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3867: dstore #25
/*      */     //   3869: dload #43
/*      */     //   3871: dload #25
/*      */     //   3873: dsub
/*      */     //   3874: dstore #41
/*      */     //   3876: goto -> 3928
/*      */     //   3879: aload #33
/*      */     //   3881: iload #34
/*      */     //   3883: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3888: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3891: sipush #404
/*      */     //   3894: invokeinterface getDouble : (I)D
/*      */     //   3899: bipush #14
/*      */     //   3901: bipush #7
/*      */     //   3903: aload #33
/*      */     //   3905: iload #34
/*      */     //   3907: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3912: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3915: wide dstore #459
/*      */     //   3919: dload #43
/*      */     //   3921: wide dload #459
/*      */     //   3925: dsub
/*      */     //   3926: dstore #41
/*      */     //   3928: iload #76
/*      */     //   3930: ifne -> 3936
/*      */     //   3933: goto -> 4188
/*      */     //   3936: aload #33
/*      */     //   3938: iload #34
/*      */     //   3940: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3945: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3948: bipush #44
/*      */     //   3950: iload #91
/*      */     //   3952: invokeinterface setInt : (II)V
/*      */     //   3957: dload #49
/*      */     //   3959: dconst_0
/*      */     //   3960: dcmpl
/*      */     //   3961: ifgt -> 3967
/*      */     //   3964: goto -> 3989
/*      */     //   3967: dload #37
/*      */     //   3969: dload #43
/*      */     //   3971: dload #35
/*      */     //   3973: dload #43
/*      */     //   3975: bipush #7
/*      */     //   3977: aload #33
/*      */     //   3979: iload #34
/*      */     //   3981: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3986: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3989: aload #33
/*      */     //   3991: iload #34
/*      */     //   3993: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3998: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4001: bipush #44
/*      */     //   4003: iload #90
/*      */     //   4005: invokeinterface setInt : (II)V
/*      */     //   4010: aload #33
/*      */     //   4012: iload #34
/*      */     //   4014: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4019: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4022: sipush #316
/*      */     //   4025: dload #47
/*      */     //   4027: invokeinterface setDouble : (ID)V
/*      */     //   4032: dload #47
/*      */     //   4034: dconst_0
/*      */     //   4035: dcmpl
/*      */     //   4036: ifgt -> 4042
/*      */     //   4039: goto -> 4188
/*      */     //   4042: iconst_0
/*      */     //   4043: istore #89
/*      */     //   4045: goto -> 4178
/*      */     //   4048: aload #98
/*      */     //   4050: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4053: wide astore #451
/*      */     //   4057: iload #89
/*      */     //   4059: bipush #8
/*      */     //   4061: imul
/*      */     //   4062: wide istore #449
/*      */     //   4066: wide aload #451
/*      */     //   4070: wide astore #447
/*      */     //   4074: iconst_0
/*      */     //   4075: wide iload #449
/*      */     //   4079: iadd
/*      */     //   4080: wide istore #448
/*      */     //   4084: wide aload #447
/*      */     //   4088: wide iload #448
/*      */     //   4092: invokeinterface getDouble : (I)D
/*      */     //   4097: dstore #72
/*      */     //   4099: aload #56
/*      */     //   4101: iconst_0
/*      */     //   4102: daload
/*      */     //   4103: dload #72
/*      */     //   4105: dcmpg
/*      */     //   4106: ifle -> 4112
/*      */     //   4109: goto -> 4175
/*      */     //   4112: aload #55
/*      */     //   4114: iconst_0
/*      */     //   4115: daload
/*      */     //   4116: wide dstore #443
/*      */     //   4120: dload #72
/*      */     //   4122: wide dload #443
/*      */     //   4126: dcmpg
/*      */     //   4127: ifle -> 4133
/*      */     //   4130: goto -> 4175
/*      */     //   4133: dload #72
/*      */     //   4135: bipush #12
/*      */     //   4137: bipush #7
/*      */     //   4139: aload #33
/*      */     //   4141: iload #34
/*      */     //   4143: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4148: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4151: dstore #72
/*      */     //   4153: dload #72
/*      */     //   4155: dload #43
/*      */     //   4157: dload #72
/*      */     //   4159: dload #41
/*      */     //   4161: bipush #7
/*      */     //   4163: aload #33
/*      */     //   4165: iload #34
/*      */     //   4167: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4172: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4175: iinc #89, 1
/*      */     //   4178: iload #89
/*      */     //   4180: iload #88
/*      */     //   4182: if_icmplt -> 4048
/*      */     //   4185: goto -> 4188
/*      */     //   4188: aload #33
/*      */     //   4190: iload #34
/*      */     //   4192: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4197: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4200: wide astore #441
/*      */     //   4204: aload #33
/*      */     //   4206: iload #34
/*      */     //   4208: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4213: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4216: sipush #552
/*      */     //   4219: invokeinterface getInt : (I)I
/*      */     //   4224: wide istore #438
/*      */     //   4228: wide aload #441
/*      */     //   4232: bipush #44
/*      */     //   4234: wide iload #438
/*      */     //   4238: invokeinterface setInt : (II)V
/*      */     //   4243: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4246: dup
/*      */     //   4247: ldc_w 'm '
/*      */     //   4250: invokevirtual getBytes : ()[B
/*      */     //   4253: iconst_0
/*      */     //   4254: invokespecial <init> : ([BI)V
/*      */     //   4257: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4260: iconst_m1
/*      */     //   4261: bipush #7
/*      */     //   4263: aload #33
/*      */     //   4265: iload #34
/*      */     //   4267: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4272: invokestatic Rf_GStrWidth : (Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4275: dstore #59
/*      */     //   4277: ldc2_w -1.0
/*      */     //   4280: dstore #64
/*      */     //   4282: dload #45
/*      */     //   4284: invokestatic R_finite : (D)I
/*      */     //   4287: ifeq -> 4293
/*      */     //   4290: goto -> 4425
/*      */     //   4293: aload #33
/*      */     //   4295: iload #34
/*      */     //   4297: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4302: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4305: sipush #308
/*      */     //   4308: invokeinterface getInt : (I)I
/*      */     //   4313: iconst_2
/*      */     //   4314: if_icmpeq -> 4347
/*      */     //   4317: goto -> 4320
/*      */     //   4320: aload #33
/*      */     //   4322: iload #34
/*      */     //   4324: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4329: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4332: sipush #308
/*      */     //   4335: invokeinterface getInt : (I)I
/*      */     //   4340: iconst_3
/*      */     //   4341: if_icmpeq -> 4347
/*      */     //   4344: goto -> 4403
/*      */     //   4347: aload #33
/*      */     //   4349: iload #34
/*      */     //   4351: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4356: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4359: wide astore #429
/*      */     //   4363: iload #85
/*      */     //   4365: iconst_1
/*      */     //   4366: if_icmpeq -> 4372
/*      */     //   4369: goto -> 4380
/*      */     //   4372: dconst_1
/*      */     //   4373: wide dstore #427
/*      */     //   4377: goto -> 4385
/*      */     //   4380: dconst_0
/*      */     //   4381: wide dstore #427
/*      */     //   4385: wide aload #429
/*      */     //   4389: bipush #8
/*      */     //   4391: wide dload #427
/*      */     //   4395: invokeinterface setDouble : (ID)V
/*      */     //   4400: goto -> 4425
/*      */     //   4403: aload #33
/*      */     //   4405: iload #34
/*      */     //   4407: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4412: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4415: bipush #8
/*      */     //   4417: ldc2_w 0.5
/*      */     //   4420: invokeinterface setDouble : (ID)V
/*      */     //   4425: iload #85
/*      */     //   4427: iconst_1
/*      */     //   4428: if_icmpeq -> 4434
/*      */     //   4431: goto -> 4532
/*      */     //   4434: aload #33
/*      */     //   4436: iload #34
/*      */     //   4438: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4443: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4446: sipush #348
/*      */     //   4449: invokeinterface getDouble : (I)D
/*      */     //   4454: wide dstore #421
/*      */     //   4458: iload #81
/*      */     //   4460: i2d
/*      */     //   4461: wide dstore #419
/*      */     //   4465: wide dload #421
/*      */     //   4469: wide dload #419
/*      */     //   4473: dsub
/*      */     //   4474: bipush #14
/*      */     //   4476: bipush #7
/*      */     //   4478: aload #33
/*      */     //   4480: iload #34
/*      */     //   4482: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4487: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4490: dload #43
/*      */     //   4492: dsub
/*      */     //   4493: wide dstore #413
/*      */     //   4497: dconst_0
/*      */     //   4498: bipush #16
/*      */     //   4500: bipush #7
/*      */     //   4502: aload #33
/*      */     //   4504: iload #34
/*      */     //   4506: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4511: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4514: wide dstore #411
/*      */     //   4518: wide dload #413
/*      */     //   4522: wide dload #411
/*      */     //   4526: dadd
/*      */     //   4527: dstore #39
/*      */     //   4529: goto -> 4627
/*      */     //   4532: aload #33
/*      */     //   4534: iload #34
/*      */     //   4536: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4541: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4544: sipush #348
/*      */     //   4547: invokeinterface getDouble : (I)D
/*      */     //   4552: wide dstore #407
/*      */     //   4556: iload #81
/*      */     //   4558: i2d
/*      */     //   4559: wide dstore #405
/*      */     //   4563: wide dload #407
/*      */     //   4567: wide dload #405
/*      */     //   4571: dsub
/*      */     //   4572: bipush #14
/*      */     //   4574: bipush #7
/*      */     //   4576: aload #33
/*      */     //   4578: iload #34
/*      */     //   4580: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4585: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4588: dload #43
/*      */     //   4590: dadd
/*      */     //   4591: wide dstore #399
/*      */     //   4595: dconst_1
/*      */     //   4596: bipush #16
/*      */     //   4598: bipush #7
/*      */     //   4600: aload #33
/*      */     //   4602: iload #34
/*      */     //   4604: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4609: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4612: wide dstore #397
/*      */     //   4616: wide dload #399
/*      */     //   4620: wide dload #397
/*      */     //   4624: dsub
/*      */     //   4625: dstore #39
/*      */     //   4627: dload #39
/*      */     //   4629: bipush #7
/*      */     //   4631: bipush #14
/*      */     //   4633: aload #33
/*      */     //   4635: iload #34
/*      */     //   4637: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4642: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4645: dstore #39
/*      */     //   4647: aload #33
/*      */     //   4649: iload #34
/*      */     //   4651: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4656: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4659: iconst_0
/*      */     //   4660: ldc_w 35700
/*      */     //   4663: iadd
/*      */     //   4664: invokeinterface getDouble : (I)D
/*      */     //   4669: wide dstore #393
/*      */     //   4673: aload #33
/*      */     //   4675: iload #34
/*      */     //   4677: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4682: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4685: iconst_0
/*      */     //   4686: ldc_w 35700
/*      */     //   4689: iadd
/*      */     //   4690: bipush #8
/*      */     //   4692: iadd
/*      */     //   4693: invokeinterface getDouble : (I)D
/*      */     //   4698: wide dstore #389
/*      */     //   4702: wide dload #393
/*      */     //   4706: wide dload #389
/*      */     //   4710: dcmpl
/*      */     //   4711: ifgt -> 4717
/*      */     //   4714: goto -> 4732
/*      */     //   4717: iload #88
/*      */     //   4719: iconst_m1
/*      */     //   4720: iadd
/*      */     //   4721: istore #80
/*      */     //   4723: iconst_m1
/*      */     //   4724: istore #79
/*      */     //   4726: iconst_m1
/*      */     //   4727: istore #78
/*      */     //   4729: goto -> 4742
/*      */     //   4732: iconst_0
/*      */     //   4733: istore #80
/*      */     //   4735: iload #88
/*      */     //   4737: istore #79
/*      */     //   4739: iconst_1
/*      */     //   4740: istore #78
/*      */     //   4742: iload #80
/*      */     //   4744: istore #89
/*      */     //   4746: goto -> 5358
/*      */     //   4749: aload #96
/*      */     //   4751: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4754: wide astore #387
/*      */     //   4758: iload #89
/*      */     //   4760: iload #92
/*      */     //   4762: irem
/*      */     //   4763: bipush #8
/*      */     //   4765: imul
/*      */     //   4766: wide istore #384
/*      */     //   4770: wide aload #387
/*      */     //   4774: wide astore #382
/*      */     //   4778: iconst_0
/*      */     //   4779: wide iload #384
/*      */     //   4783: iadd
/*      */     //   4784: wide istore #383
/*      */     //   4788: wide aload #382
/*      */     //   4792: wide iload #383
/*      */     //   4796: invokeinterface getDouble : (I)D
/*      */     //   4801: dstore #19
/*      */     //   4803: aload #33
/*      */     //   4805: iload #34
/*      */     //   4807: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4812: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4815: sipush #308
/*      */     //   4818: invokeinterface getInt : (I)I
/*      */     //   4823: wide istore #379
/*      */     //   4827: dload #19
/*      */     //   4829: iload #85
/*      */     //   4831: wide iload #379
/*      */     //   4835: invokestatic ComputePAdjValue : (DII)D
/*      */     //   4838: dstore #19
/*      */     //   4840: aload #98
/*      */     //   4842: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4845: wide astore #377
/*      */     //   4849: iload #89
/*      */     //   4851: bipush #8
/*      */     //   4853: imul
/*      */     //   4854: wide istore #375
/*      */     //   4858: wide aload #377
/*      */     //   4862: wide astore #373
/*      */     //   4866: iconst_0
/*      */     //   4867: wide iload #375
/*      */     //   4871: iadd
/*      */     //   4872: wide istore #374
/*      */     //   4876: wide aload #373
/*      */     //   4880: wide iload #374
/*      */     //   4884: invokeinterface getDouble : (I)D
/*      */     //   4889: dstore #72
/*      */     //   4891: dload #72
/*      */     //   4893: invokestatic R_finite : (D)I
/*      */     //   4896: ifeq -> 4902
/*      */     //   4899: goto -> 4905
/*      */     //   4902: goto -> 5351
/*      */     //   4905: dload #72
/*      */     //   4907: bipush #12
/*      */     //   4909: bipush #7
/*      */     //   4911: aload #33
/*      */     //   4913: iload #34
/*      */     //   4915: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4920: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4923: dstore #68
/*      */     //   4925: iload #77
/*      */     //   4927: ifne -> 4933
/*      */     //   4930: goto -> 5351
/*      */     //   4933: aload #56
/*      */     //   4935: iconst_0
/*      */     //   4936: daload
/*      */     //   4937: wide dstore #370
/*      */     //   4941: dload #72
/*      */     //   4943: wide dload #370
/*      */     //   4947: dcmpl
/*      */     //   4948: ifgt -> 4954
/*      */     //   4951: goto -> 5351
/*      */     //   4954: aload #55
/*      */     //   4956: iconst_0
/*      */     //   4957: daload
/*      */     //   4958: wide dstore #368
/*      */     //   4962: dload #72
/*      */     //   4964: wide dload #368
/*      */     //   4968: dcmpg
/*      */     //   4969: iflt -> 4975
/*      */     //   4972: goto -> 5351
/*      */     //   4975: aload #97
/*      */     //   4977: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   4980: bipush #20
/*      */     //   4982: if_icmpeq -> 4988
/*      */     //   4985: goto -> 5091
/*      */     //   4988: aload #33
/*      */     //   4990: iload #34
/*      */     //   4992: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4997: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5000: sipush #308
/*      */     //   5003: invokeinterface getInt : (I)I
/*      */     //   5008: wide istore #364
/*      */     //   5012: iload #89
/*      */     //   5014: iconst_4
/*      */     //   5015: imul
/*      */     //   5016: wide istore #362
/*      */     //   5020: aload #83
/*      */     //   5022: wide astore #360
/*      */     //   5026: iload #84
/*      */     //   5028: wide iload #362
/*      */     //   5032: iadd
/*      */     //   5033: wide istore #361
/*      */     //   5037: wide aload #360
/*      */     //   5041: wide iload #361
/*      */     //   5045: invokeinterface getInt : (I)I
/*      */     //   5050: wide istore #359
/*      */     //   5054: aload #97
/*      */     //   5056: wide iload #359
/*      */     //   5060: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   5063: iload #85
/*      */     //   5065: dload #39
/*      */     //   5067: iconst_0
/*      */     //   5068: dload #72
/*      */     //   5070: wide iload #364
/*      */     //   5074: dload #19
/*      */     //   5076: aload #33
/*      */     //   5078: iload #34
/*      */     //   5080: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5085: invokestatic Rf_GMMathText : (Lorg/renjin/sexp/SEXP;IDIDIDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5088: goto -> 5351
/*      */     //   5091: iload #89
/*      */     //   5093: iconst_4
/*      */     //   5094: imul
/*      */     //   5095: wide istore #356
/*      */     //   5099: aload #83
/*      */     //   5101: wide astore #354
/*      */     //   5105: iload #84
/*      */     //   5107: wide iload #356
/*      */     //   5111: iadd
/*      */     //   5112: wide istore #355
/*      */     //   5116: wide aload #354
/*      */     //   5120: wide iload #355
/*      */     //   5124: invokeinterface getInt : (I)I
/*      */     //   5129: wide istore #353
/*      */     //   5133: aload #97
/*      */     //   5135: wide iload #353
/*      */     //   5139: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   5142: astore #95
/*      */     //   5144: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   5147: wide astore #352
/*      */     //   5151: aload #95
/*      */     //   5153: wide aload #352
/*      */     //   5157: if_acmpeq -> 5351
/*      */     //   5160: goto -> 5163
/*      */     //   5163: aload #95
/*      */     //   5165: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   5168: astore #17
/*      */     //   5170: aload #17
/*      */     //   5172: iconst_0
/*      */     //   5173: bipush #7
/*      */     //   5175: aload #33
/*      */     //   5177: iload #34
/*      */     //   5179: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5184: invokestatic Rf_GStrWidth : (Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5187: dstore #57
/*      */     //   5189: dload #57
/*      */     //   5191: ldc2_w 0.5
/*      */     //   5194: dmul
/*      */     //   5195: wide dstore #350
/*      */     //   5199: dload #68
/*      */     //   5201: wide dload #350
/*      */     //   5205: dsub
/*      */     //   5206: dstore #66
/*      */     //   5208: aload #33
/*      */     //   5210: iload #34
/*      */     //   5212: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5217: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5220: sipush #308
/*      */     //   5223: invokeinterface getInt : (I)I
/*      */     //   5228: iconst_2
/*      */     //   5229: if_icmpeq -> 5276
/*      */     //   5232: goto -> 5235
/*      */     //   5235: aload #33
/*      */     //   5237: iload #34
/*      */     //   5239: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5244: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5247: sipush #308
/*      */     //   5250: invokeinterface getInt : (I)I
/*      */     //   5255: iconst_3
/*      */     //   5256: if_icmpeq -> 5276
/*      */     //   5259: goto -> 5262
/*      */     //   5262: dload #66
/*      */     //   5264: dload #64
/*      */     //   5266: dsub
/*      */     //   5267: dload #59
/*      */     //   5269: dcmpl
/*      */     //   5270: ifge -> 5276
/*      */     //   5273: goto -> 5351
/*      */     //   5276: aload #33
/*      */     //   5278: iload #34
/*      */     //   5280: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5285: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5288: sipush #308
/*      */     //   5291: invokeinterface getInt : (I)I
/*      */     //   5296: wide istore #339
/*      */     //   5300: aload #95
/*      */     //   5302: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   5305: wide istore #338
/*      */     //   5309: aload #17
/*      */     //   5311: wide iload #338
/*      */     //   5315: iload #85
/*      */     //   5317: dload #39
/*      */     //   5319: iconst_0
/*      */     //   5320: dload #72
/*      */     //   5322: wide iload #339
/*      */     //   5326: dload #19
/*      */     //   5328: aload #33
/*      */     //   5330: iload #34
/*      */     //   5332: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5337: invokestatic Rf_GMtext : (Lorg/renjin/gcc/runtime/Ptr;IIDIDIDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5340: dload #57
/*      */     //   5342: ldc2_w 0.5
/*      */     //   5345: dmul
/*      */     //   5346: dload #68
/*      */     //   5348: dadd
/*      */     //   5349: dstore #64
/*      */     //   5351: iload #89
/*      */     //   5353: iload #78
/*      */     //   5355: iadd
/*      */     //   5356: istore #89
/*      */     //   5358: iload #89
/*      */     //   5360: iload #79
/*      */     //   5362: if_icmpne -> 4749
/*      */     //   5365: goto -> 5368
/*      */     //   5368: goto -> 7727
/*      */     //   5371: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5374: dup
/*      */     //   5375: aload #61
/*      */     //   5377: iconst_0
/*      */     //   5378: invokespecial <init> : ([DI)V
/*      */     //   5381: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5384: aload #33
/*      */     //   5386: iload #34
/*      */     //   5388: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5393: invokestatic getylimits : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5396: aload #33
/*      */     //   5398: iload #34
/*      */     //   5400: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5405: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5408: sipush #444
/*      */     //   5411: iconst_2
/*      */     //   5412: invokeinterface setInt : (II)V
/*      */     //   5417: aload #61
/*      */     //   5419: iconst_1
/*      */     //   5420: daload
/*      */     //   5421: wide dstore #332
/*      */     //   5425: aload #61
/*      */     //   5427: iconst_0
/*      */     //   5428: daload
/*      */     //   5429: wide dload #332
/*      */     //   5433: iload #75
/*      */     //   5435: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5438: dup
/*      */     //   5439: aload #56
/*      */     //   5441: iconst_0
/*      */     //   5442: invokespecial <init> : ([DI)V
/*      */     //   5445: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5448: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5451: dup
/*      */     //   5452: aload #55
/*      */     //   5454: iconst_0
/*      */     //   5455: invokespecial <init> : ([DI)V
/*      */     //   5458: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5461: invokestatic GetAxisLimits : (DDILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5464: aload #98
/*      */     //   5466: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5469: invokeinterface getDouble : ()D
/*      */     //   5474: wide dstore #326
/*      */     //   5478: aload #56
/*      */     //   5480: iconst_0
/*      */     //   5481: daload
/*      */     //   5482: wide dload #326
/*      */     //   5486: invokestatic Rf_fmax2 : (DD)D
/*      */     //   5489: wide dstore #322
/*      */     //   5493: aload #55
/*      */     //   5495: iconst_0
/*      */     //   5496: daload
/*      */     //   5497: wide dload #322
/*      */     //   5501: invokestatic Rf_fmin2 : (DD)D
/*      */     //   5504: bipush #12
/*      */     //   5506: bipush #7
/*      */     //   5508: aload #33
/*      */     //   5510: iload #34
/*      */     //   5512: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5517: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5520: dstore #37
/*      */     //   5522: aload #98
/*      */     //   5524: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5527: wide astore #316
/*      */     //   5531: iload #88
/*      */     //   5533: iconst_m1
/*      */     //   5534: iadd
/*      */     //   5535: bipush #8
/*      */     //   5537: imul
/*      */     //   5538: wide istore #313
/*      */     //   5542: wide aload #316
/*      */     //   5546: wide astore #311
/*      */     //   5550: iconst_0
/*      */     //   5551: wide iload #313
/*      */     //   5555: iadd
/*      */     //   5556: wide istore #312
/*      */     //   5560: wide aload #311
/*      */     //   5564: wide iload #312
/*      */     //   5568: invokeinterface getDouble : (I)D
/*      */     //   5573: wide dstore #309
/*      */     //   5577: aload #56
/*      */     //   5579: iconst_0
/*      */     //   5580: daload
/*      */     //   5581: wide dload #309
/*      */     //   5585: invokestatic Rf_fmax2 : (DD)D
/*      */     //   5588: wide dstore #305
/*      */     //   5592: aload #55
/*      */     //   5594: iconst_0
/*      */     //   5595: daload
/*      */     //   5596: wide dload #305
/*      */     //   5600: invokestatic Rf_fmin2 : (DD)D
/*      */     //   5603: bipush #12
/*      */     //   5605: bipush #7
/*      */     //   5607: aload #33
/*      */     //   5609: iload #34
/*      */     //   5611: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5616: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5619: dstore #35
/*      */     //   5621: iload #85
/*      */     //   5623: iconst_2
/*      */     //   5624: if_icmpeq -> 5630
/*      */     //   5627: goto -> 6030
/*      */     //   5630: dload #51
/*      */     //   5632: invokestatic R_finite : (D)I
/*      */     //   5635: ifne -> 5641
/*      */     //   5638: goto -> 5664
/*      */     //   5641: dload #51
/*      */     //   5643: bipush #12
/*      */     //   5645: bipush #7
/*      */     //   5647: aload #33
/*      */     //   5649: iload #34
/*      */     //   5651: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5656: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5659: dstore #43
/*      */     //   5661: goto -> 5726
/*      */     //   5664: iload #82
/*      */     //   5666: wide istore #299
/*      */     //   5670: dconst_0
/*      */     //   5671: wide iload #299
/*      */     //   5675: bipush #7
/*      */     //   5677: aload #33
/*      */     //   5679: iload #34
/*      */     //   5681: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5686: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5689: wide dstore #297
/*      */     //   5693: dload #53
/*      */     //   5695: bipush #14
/*      */     //   5697: bipush #7
/*      */     //   5699: aload #33
/*      */     //   5701: iload #34
/*      */     //   5703: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5708: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5711: wide dstore #295
/*      */     //   5715: wide dload #297
/*      */     //   5719: wide dload #295
/*      */     //   5723: dsub
/*      */     //   5724: dstore #43
/*      */     //   5726: aload #33
/*      */     //   5728: iload #34
/*      */     //   5730: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5735: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5738: sipush #396
/*      */     //   5741: invokeinterface getDouble : (I)D
/*      */     //   5746: invokestatic R_finite : (D)I
/*      */     //   5749: ifne -> 5755
/*      */     //   5752: goto -> 5986
/*      */     //   5755: aload #33
/*      */     //   5757: iload #34
/*      */     //   5759: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5764: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5767: sipush #396
/*      */     //   5770: invokeinterface getDouble : (I)D
/*      */     //   5775: ldc2_w 0.5
/*      */     //   5778: dcmpl
/*      */     //   5779: ifgt -> 5785
/*      */     //   5782: goto -> 5826
/*      */     //   5785: aload #33
/*      */     //   5787: iload #34
/*      */     //   5789: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5794: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5797: sipush #396
/*      */     //   5800: invokeinterface getDouble : (I)D
/*      */     //   5805: bipush #16
/*      */     //   5807: bipush #7
/*      */     //   5809: aload #33
/*      */     //   5811: iload #34
/*      */     //   5813: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5818: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5821: dstore #15
/*      */     //   5823: goto -> 5976
/*      */     //   5826: aload #33
/*      */     //   5828: iload #34
/*      */     //   5830: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5835: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5838: sipush #396
/*      */     //   5841: invokeinterface getDouble : (I)D
/*      */     //   5846: bipush #16
/*      */     //   5848: bipush #13
/*      */     //   5850: aload #33
/*      */     //   5852: iload #34
/*      */     //   5854: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5859: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5862: dstore #13
/*      */     //   5864: aload #33
/*      */     //   5866: iload #34
/*      */     //   5868: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5873: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5876: sipush #396
/*      */     //   5879: invokeinterface getDouble : (I)D
/*      */     //   5884: bipush #16
/*      */     //   5886: bipush #13
/*      */     //   5888: aload #33
/*      */     //   5890: iload #34
/*      */     //   5892: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5897: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5900: dstore #11
/*      */     //   5902: dload #13
/*      */     //   5904: invokestatic abs : (D)D
/*      */     //   5907: wide dstore #270
/*      */     //   5911: dload #11
/*      */     //   5913: invokestatic abs : (D)D
/*      */     //   5916: wide dstore #268
/*      */     //   5920: wide dload #270
/*      */     //   5924: wide dload #268
/*      */     //   5928: dcmpg
/*      */     //   5929: iflt -> 5935
/*      */     //   5932: goto -> 5944
/*      */     //   5935: dload #13
/*      */     //   5937: wide dstore #272
/*      */     //   5941: goto -> 5950
/*      */     //   5944: dload #11
/*      */     //   5946: wide dstore #272
/*      */     //   5950: wide dload #272
/*      */     //   5954: dstore #13
/*      */     //   5956: dload #13
/*      */     //   5958: bipush #13
/*      */     //   5960: bipush #7
/*      */     //   5962: aload #33
/*      */     //   5964: iload #34
/*      */     //   5966: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5971: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5974: dstore #15
/*      */     //   5976: dload #43
/*      */     //   5978: dload #15
/*      */     //   5980: dadd
/*      */     //   5981: dstore #41
/*      */     //   5983: goto -> 6417
/*      */     //   5986: aload #33
/*      */     //   5988: iload #34
/*      */     //   5990: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5995: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5998: sipush #404
/*      */     //   6001: invokeinterface getDouble : (I)D
/*      */     //   6006: bipush #14
/*      */     //   6008: bipush #7
/*      */     //   6010: aload #33
/*      */     //   6012: iload #34
/*      */     //   6014: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6019: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6022: dload #43
/*      */     //   6024: dadd
/*      */     //   6025: dstore #41
/*      */     //   6027: goto -> 6417
/*      */     //   6030: dload #51
/*      */     //   6032: invokestatic R_finite : (D)I
/*      */     //   6035: ifne -> 6041
/*      */     //   6038: goto -> 6064
/*      */     //   6041: dload #51
/*      */     //   6043: bipush #12
/*      */     //   6045: bipush #7
/*      */     //   6047: aload #33
/*      */     //   6049: iload #34
/*      */     //   6051: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6056: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6059: dstore #43
/*      */     //   6061: goto -> 6126
/*      */     //   6064: iload #82
/*      */     //   6066: wide istore #260
/*      */     //   6070: dconst_1
/*      */     //   6071: wide iload #260
/*      */     //   6075: bipush #7
/*      */     //   6077: aload #33
/*      */     //   6079: iload #34
/*      */     //   6081: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6086: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6089: wide dstore #258
/*      */     //   6093: dload #53
/*      */     //   6095: bipush #14
/*      */     //   6097: bipush #7
/*      */     //   6099: aload #33
/*      */     //   6101: iload #34
/*      */     //   6103: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6108: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6111: wide dstore #256
/*      */     //   6115: wide dload #258
/*      */     //   6119: wide dload #256
/*      */     //   6123: dadd
/*      */     //   6124: dstore #43
/*      */     //   6126: aload #33
/*      */     //   6128: iload #34
/*      */     //   6130: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6135: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6138: sipush #396
/*      */     //   6141: invokeinterface getDouble : (I)D
/*      */     //   6146: invokestatic R_finite : (D)I
/*      */     //   6149: ifne -> 6155
/*      */     //   6152: goto -> 6372
/*      */     //   6155: aload #33
/*      */     //   6157: iload #34
/*      */     //   6159: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6164: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6167: sipush #396
/*      */     //   6170: invokeinterface getDouble : (I)D
/*      */     //   6175: ldc2_w 0.5
/*      */     //   6178: dcmpl
/*      */     //   6179: ifgt -> 6185
/*      */     //   6182: goto -> 6226
/*      */     //   6185: aload #33
/*      */     //   6187: iload #34
/*      */     //   6189: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6194: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6197: sipush #396
/*      */     //   6200: invokeinterface getDouble : (I)D
/*      */     //   6205: bipush #16
/*      */     //   6207: bipush #7
/*      */     //   6209: aload #33
/*      */     //   6211: iload #34
/*      */     //   6213: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6218: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6221: dstore #9
/*      */     //   6223: goto -> 6362
/*      */     //   6226: aload #33
/*      */     //   6228: iload #34
/*      */     //   6230: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6235: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6238: sipush #396
/*      */     //   6241: invokeinterface getDouble : (I)D
/*      */     //   6246: bipush #16
/*      */     //   6248: bipush #13
/*      */     //   6250: aload #33
/*      */     //   6252: iload #34
/*      */     //   6254: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6259: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6262: dstore #7
/*      */     //   6264: aload #33
/*      */     //   6266: iload #34
/*      */     //   6268: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6273: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6276: sipush #396
/*      */     //   6279: invokeinterface getDouble : (I)D
/*      */     //   6284: bipush #16
/*      */     //   6286: bipush #13
/*      */     //   6288: aload #33
/*      */     //   6290: iload #34
/*      */     //   6292: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6297: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6300: dstore #5
/*      */     //   6302: dload #7
/*      */     //   6304: invokestatic abs : (D)D
/*      */     //   6307: dstore #231
/*      */     //   6309: dload #5
/*      */     //   6311: invokestatic abs : (D)D
/*      */     //   6314: dstore #229
/*      */     //   6316: dload #231
/*      */     //   6318: dload #229
/*      */     //   6320: dcmpg
/*      */     //   6321: iflt -> 6327
/*      */     //   6324: goto -> 6334
/*      */     //   6327: dload #7
/*      */     //   6329: dstore #233
/*      */     //   6331: goto -> 6338
/*      */     //   6334: dload #5
/*      */     //   6336: dstore #233
/*      */     //   6338: dload #233
/*      */     //   6340: dstore #7
/*      */     //   6342: dload #7
/*      */     //   6344: bipush #13
/*      */     //   6346: bipush #7
/*      */     //   6348: aload #33
/*      */     //   6350: iload #34
/*      */     //   6352: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6357: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6360: dstore #9
/*      */     //   6362: dload #43
/*      */     //   6364: dload #9
/*      */     //   6366: dsub
/*      */     //   6367: dstore #41
/*      */     //   6369: goto -> 6417
/*      */     //   6372: aload #33
/*      */     //   6374: iload #34
/*      */     //   6376: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6381: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6384: sipush #404
/*      */     //   6387: invokeinterface getDouble : (I)D
/*      */     //   6392: bipush #14
/*      */     //   6394: bipush #7
/*      */     //   6396: aload #33
/*      */     //   6398: iload #34
/*      */     //   6400: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6405: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6408: dstore #223
/*      */     //   6410: dload #43
/*      */     //   6412: dload #223
/*      */     //   6414: dsub
/*      */     //   6415: dstore #41
/*      */     //   6417: iload #76
/*      */     //   6419: ifne -> 6425
/*      */     //   6422: goto -> 6657
/*      */     //   6425: aload #33
/*      */     //   6427: iload #34
/*      */     //   6429: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6434: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6437: bipush #44
/*      */     //   6439: iload #91
/*      */     //   6441: invokeinterface setInt : (II)V
/*      */     //   6446: dload #49
/*      */     //   6448: dconst_0
/*      */     //   6449: dcmpl
/*      */     //   6450: ifgt -> 6456
/*      */     //   6453: goto -> 6478
/*      */     //   6456: dload #43
/*      */     //   6458: dload #37
/*      */     //   6460: dload #43
/*      */     //   6462: dload #35
/*      */     //   6464: bipush #7
/*      */     //   6466: aload #33
/*      */     //   6468: iload #34
/*      */     //   6470: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6475: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6478: aload #33
/*      */     //   6480: iload #34
/*      */     //   6482: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6487: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6490: bipush #44
/*      */     //   6492: iload #90
/*      */     //   6494: invokeinterface setInt : (II)V
/*      */     //   6499: aload #33
/*      */     //   6501: iload #34
/*      */     //   6503: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6508: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6511: sipush #316
/*      */     //   6514: dload #47
/*      */     //   6516: invokeinterface setDouble : (ID)V
/*      */     //   6521: dload #47
/*      */     //   6523: dconst_0
/*      */     //   6524: dcmpl
/*      */     //   6525: ifgt -> 6531
/*      */     //   6528: goto -> 6657
/*      */     //   6531: iconst_0
/*      */     //   6532: istore #89
/*      */     //   6534: goto -> 6647
/*      */     //   6537: aload #98
/*      */     //   6539: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6542: astore #215
/*      */     //   6544: iload #89
/*      */     //   6546: bipush #8
/*      */     //   6548: imul
/*      */     //   6549: istore #213
/*      */     //   6551: aload #215
/*      */     //   6553: astore #211
/*      */     //   6555: iconst_0
/*      */     //   6556: iload #213
/*      */     //   6558: iadd
/*      */     //   6559: istore #212
/*      */     //   6561: aload #211
/*      */     //   6563: iload #212
/*      */     //   6565: invokeinterface getDouble : (I)D
/*      */     //   6570: dstore #70
/*      */     //   6572: aload #56
/*      */     //   6574: iconst_0
/*      */     //   6575: daload
/*      */     //   6576: dload #70
/*      */     //   6578: dcmpg
/*      */     //   6579: ifle -> 6585
/*      */     //   6582: goto -> 6644
/*      */     //   6585: aload #55
/*      */     //   6587: iconst_0
/*      */     //   6588: daload
/*      */     //   6589: dstore #207
/*      */     //   6591: dload #70
/*      */     //   6593: dload #207
/*      */     //   6595: dcmpg
/*      */     //   6596: ifle -> 6602
/*      */     //   6599: goto -> 6644
/*      */     //   6602: dload #70
/*      */     //   6604: bipush #12
/*      */     //   6606: bipush #7
/*      */     //   6608: aload #33
/*      */     //   6610: iload #34
/*      */     //   6612: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6617: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6620: dstore #70
/*      */     //   6622: dload #43
/*      */     //   6624: dload #70
/*      */     //   6626: dload #41
/*      */     //   6628: dload #70
/*      */     //   6630: bipush #7
/*      */     //   6632: aload #33
/*      */     //   6634: iload #34
/*      */     //   6636: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6641: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6644: iinc #89, 1
/*      */     //   6647: iload #89
/*      */     //   6649: iload #88
/*      */     //   6651: if_icmplt -> 6537
/*      */     //   6654: goto -> 6657
/*      */     //   6657: aload #33
/*      */     //   6659: iload #34
/*      */     //   6661: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6666: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6669: astore #205
/*      */     //   6671: aload #33
/*      */     //   6673: iload #34
/*      */     //   6675: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6680: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6683: sipush #552
/*      */     //   6686: invokeinterface getInt : (I)I
/*      */     //   6691: istore #202
/*      */     //   6693: aload #205
/*      */     //   6695: bipush #44
/*      */     //   6697: iload #202
/*      */     //   6699: invokeinterface setInt : (II)V
/*      */     //   6704: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6707: dup
/*      */     //   6708: ldc_w 'm '
/*      */     //   6711: invokevirtual getBytes : ()[B
/*      */     //   6714: iconst_0
/*      */     //   6715: invokespecial <init> : ([BI)V
/*      */     //   6718: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6721: bipush #99
/*      */     //   6723: bipush #13
/*      */     //   6725: aload #33
/*      */     //   6727: iload #34
/*      */     //   6729: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6734: invokestatic Rf_GStrWidth : (Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6737: dstore #59
/*      */     //   6739: dload #59
/*      */     //   6741: bipush #13
/*      */     //   6743: bipush #7
/*      */     //   6745: aload #33
/*      */     //   6747: iload #34
/*      */     //   6749: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6754: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6757: dstore #59
/*      */     //   6759: ldc2_w -1.0
/*      */     //   6762: dstore #64
/*      */     //   6764: dload #45
/*      */     //   6766: invokestatic R_finite : (D)I
/*      */     //   6769: ifeq -> 6775
/*      */     //   6772: goto -> 6897
/*      */     //   6775: aload #33
/*      */     //   6777: iload #34
/*      */     //   6779: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6784: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6787: sipush #308
/*      */     //   6790: invokeinterface getInt : (I)I
/*      */     //   6795: iconst_1
/*      */     //   6796: if_icmpeq -> 6829
/*      */     //   6799: goto -> 6802
/*      */     //   6802: aload #33
/*      */     //   6804: iload #34
/*      */     //   6806: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6811: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6814: sipush #308
/*      */     //   6817: invokeinterface getInt : (I)I
/*      */     //   6822: iconst_2
/*      */     //   6823: if_icmpeq -> 6829
/*      */     //   6826: goto -> 6875
/*      */     //   6829: aload #33
/*      */     //   6831: iload #34
/*      */     //   6833: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6838: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6841: astore #193
/*      */     //   6843: iload #85
/*      */     //   6845: iconst_2
/*      */     //   6846: if_icmpeq -> 6852
/*      */     //   6849: goto -> 6858
/*      */     //   6852: dconst_1
/*      */     //   6853: dstore #191
/*      */     //   6855: goto -> 6861
/*      */     //   6858: dconst_0
/*      */     //   6859: dstore #191
/*      */     //   6861: aload #193
/*      */     //   6863: bipush #8
/*      */     //   6865: dload #191
/*      */     //   6867: invokeinterface setDouble : (ID)V
/*      */     //   6872: goto -> 6897
/*      */     //   6875: aload #33
/*      */     //   6877: iload #34
/*      */     //   6879: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6884: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6887: bipush #8
/*      */     //   6889: ldc2_w 0.5
/*      */     //   6892: invokeinterface setDouble : (ID)V
/*      */     //   6897: iload #85
/*      */     //   6899: iconst_2
/*      */     //   6900: if_icmpeq -> 6906
/*      */     //   6903: goto -> 6988
/*      */     //   6906: aload #33
/*      */     //   6908: iload #34
/*      */     //   6910: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6915: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6918: sipush #348
/*      */     //   6921: invokeinterface getDouble : (I)D
/*      */     //   6926: dstore #185
/*      */     //   6928: iload #81
/*      */     //   6930: i2d
/*      */     //   6931: dstore #183
/*      */     //   6933: dload #185
/*      */     //   6935: dload #183
/*      */     //   6937: dsub
/*      */     //   6938: bipush #14
/*      */     //   6940: bipush #7
/*      */     //   6942: aload #33
/*      */     //   6944: iload #34
/*      */     //   6946: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6951: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6954: dload #43
/*      */     //   6956: dsub
/*      */     //   6957: dstore #177
/*      */     //   6959: dconst_0
/*      */     //   6960: bipush #16
/*      */     //   6962: bipush #7
/*      */     //   6964: aload #33
/*      */     //   6966: iload #34
/*      */     //   6968: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6973: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   6976: dstore #175
/*      */     //   6978: dload #177
/*      */     //   6980: dload #175
/*      */     //   6982: dadd
/*      */     //   6983: dstore #39
/*      */     //   6985: goto -> 7067
/*      */     //   6988: aload #33
/*      */     //   6990: iload #34
/*      */     //   6992: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6997: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7000: sipush #348
/*      */     //   7003: invokeinterface getDouble : (I)D
/*      */     //   7008: dstore #171
/*      */     //   7010: iload #81
/*      */     //   7012: i2d
/*      */     //   7013: dstore #169
/*      */     //   7015: dload #171
/*      */     //   7017: dload #169
/*      */     //   7019: dsub
/*      */     //   7020: bipush #14
/*      */     //   7022: bipush #7
/*      */     //   7024: aload #33
/*      */     //   7026: iload #34
/*      */     //   7028: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7033: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7036: dload #43
/*      */     //   7038: dadd
/*      */     //   7039: dstore #163
/*      */     //   7041: dconst_1
/*      */     //   7042: bipush #16
/*      */     //   7044: bipush #7
/*      */     //   7046: aload #33
/*      */     //   7048: iload #34
/*      */     //   7050: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7055: invokestatic Rf_GConvertX : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7058: dstore #161
/*      */     //   7060: dload #163
/*      */     //   7062: dload #161
/*      */     //   7064: dsub
/*      */     //   7065: dstore #39
/*      */     //   7067: dload #39
/*      */     //   7069: bipush #7
/*      */     //   7071: bipush #14
/*      */     //   7073: aload #33
/*      */     //   7075: iload #34
/*      */     //   7077: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7082: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7085: dstore #39
/*      */     //   7087: aload #33
/*      */     //   7089: iload #34
/*      */     //   7091: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7096: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7099: iconst_0
/*      */     //   7100: ldc_w 35700
/*      */     //   7103: iadd
/*      */     //   7104: bipush #16
/*      */     //   7106: iadd
/*      */     //   7107: invokeinterface getDouble : (I)D
/*      */     //   7112: dstore #157
/*      */     //   7114: aload #33
/*      */     //   7116: iload #34
/*      */     //   7118: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7123: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7126: iconst_0
/*      */     //   7127: ldc_w 35700
/*      */     //   7130: iadd
/*      */     //   7131: bipush #24
/*      */     //   7133: iadd
/*      */     //   7134: invokeinterface getDouble : (I)D
/*      */     //   7139: dstore #153
/*      */     //   7141: dload #157
/*      */     //   7143: dload #153
/*      */     //   7145: dcmpl
/*      */     //   7146: ifgt -> 7152
/*      */     //   7149: goto -> 7167
/*      */     //   7152: iload #88
/*      */     //   7154: iconst_m1
/*      */     //   7155: iadd
/*      */     //   7156: istore #80
/*      */     //   7158: iconst_m1
/*      */     //   7159: istore #79
/*      */     //   7161: iconst_m1
/*      */     //   7162: istore #78
/*      */     //   7164: goto -> 7177
/*      */     //   7167: iconst_0
/*      */     //   7168: istore #80
/*      */     //   7170: iload #88
/*      */     //   7172: istore #79
/*      */     //   7174: iconst_1
/*      */     //   7175: istore #78
/*      */     //   7177: iload #80
/*      */     //   7179: istore #89
/*      */     //   7181: goto -> 7717
/*      */     //   7184: aload #96
/*      */     //   7186: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7189: astore #151
/*      */     //   7191: iload #89
/*      */     //   7193: iload #92
/*      */     //   7195: irem
/*      */     //   7196: bipush #8
/*      */     //   7198: imul
/*      */     //   7199: istore #148
/*      */     //   7201: aload #151
/*      */     //   7203: astore #146
/*      */     //   7205: iconst_0
/*      */     //   7206: iload #148
/*      */     //   7208: iadd
/*      */     //   7209: istore #147
/*      */     //   7211: aload #146
/*      */     //   7213: iload #147
/*      */     //   7215: invokeinterface getDouble : (I)D
/*      */     //   7220: dstore_3
/*      */     //   7221: aload #33
/*      */     //   7223: iload #34
/*      */     //   7225: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7230: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7233: sipush #308
/*      */     //   7236: invokeinterface getInt : (I)I
/*      */     //   7241: istore #143
/*      */     //   7243: dload_3
/*      */     //   7244: iload #85
/*      */     //   7246: iload #143
/*      */     //   7248: invokestatic ComputePAdjValue : (DII)D
/*      */     //   7251: dstore_3
/*      */     //   7252: aload #98
/*      */     //   7254: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7257: astore #141
/*      */     //   7259: iload #89
/*      */     //   7261: bipush #8
/*      */     //   7263: imul
/*      */     //   7264: istore #139
/*      */     //   7266: aload #141
/*      */     //   7268: astore #137
/*      */     //   7270: iconst_0
/*      */     //   7271: iload #139
/*      */     //   7273: iadd
/*      */     //   7274: istore #138
/*      */     //   7276: aload #137
/*      */     //   7278: iload #138
/*      */     //   7280: invokeinterface getDouble : (I)D
/*      */     //   7285: dstore #70
/*      */     //   7287: dload #70
/*      */     //   7289: invokestatic R_finite : (D)I
/*      */     //   7292: ifeq -> 7298
/*      */     //   7295: goto -> 7301
/*      */     //   7298: goto -> 7710
/*      */     //   7301: dload #70
/*      */     //   7303: bipush #12
/*      */     //   7305: bipush #7
/*      */     //   7307: aload #33
/*      */     //   7309: iload #34
/*      */     //   7311: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7316: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7319: dstore #68
/*      */     //   7321: iload #77
/*      */     //   7323: ifne -> 7329
/*      */     //   7326: goto -> 7710
/*      */     //   7329: aload #56
/*      */     //   7331: iconst_0
/*      */     //   7332: daload
/*      */     //   7333: dstore #134
/*      */     //   7335: dload #70
/*      */     //   7337: dload #134
/*      */     //   7339: dcmpl
/*      */     //   7340: ifgt -> 7346
/*      */     //   7343: goto -> 7710
/*      */     //   7346: aload #55
/*      */     //   7348: iconst_0
/*      */     //   7349: daload
/*      */     //   7350: dstore #132
/*      */     //   7352: dload #70
/*      */     //   7354: dload #132
/*      */     //   7356: dcmpg
/*      */     //   7357: iflt -> 7363
/*      */     //   7360: goto -> 7710
/*      */     //   7363: aload #97
/*      */     //   7365: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7368: bipush #20
/*      */     //   7370: if_icmpeq -> 7376
/*      */     //   7373: goto -> 7458
/*      */     //   7376: aload #33
/*      */     //   7378: iload #34
/*      */     //   7380: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7385: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7388: sipush #308
/*      */     //   7391: invokeinterface getInt : (I)I
/*      */     //   7396: istore #128
/*      */     //   7398: iload #89
/*      */     //   7400: iconst_4
/*      */     //   7401: imul
/*      */     //   7402: istore #126
/*      */     //   7404: aload #83
/*      */     //   7406: astore #124
/*      */     //   7408: iload #84
/*      */     //   7410: iload #126
/*      */     //   7412: iadd
/*      */     //   7413: istore #125
/*      */     //   7415: aload #124
/*      */     //   7417: iload #125
/*      */     //   7419: invokeinterface getInt : (I)I
/*      */     //   7424: istore #123
/*      */     //   7426: aload #97
/*      */     //   7428: iload #123
/*      */     //   7430: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   7433: iload #85
/*      */     //   7435: dload #39
/*      */     //   7437: iconst_0
/*      */     //   7438: dload #70
/*      */     //   7440: iload #128
/*      */     //   7442: dload_3
/*      */     //   7443: aload #33
/*      */     //   7445: iload #34
/*      */     //   7447: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7452: invokestatic Rf_GMMathText : (Lorg/renjin/sexp/SEXP;IDIDIDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7455: goto -> 7710
/*      */     //   7458: iload #89
/*      */     //   7460: iconst_4
/*      */     //   7461: imul
/*      */     //   7462: istore #120
/*      */     //   7464: aload #83
/*      */     //   7466: astore #118
/*      */     //   7468: iload #84
/*      */     //   7470: iload #120
/*      */     //   7472: iadd
/*      */     //   7473: istore #119
/*      */     //   7475: aload #118
/*      */     //   7477: iload #119
/*      */     //   7479: invokeinterface getInt : (I)I
/*      */     //   7484: istore #117
/*      */     //   7486: aload #97
/*      */     //   7488: iload #117
/*      */     //   7490: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   7493: astore #95
/*      */     //   7495: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   7498: astore #116
/*      */     //   7500: aload #95
/*      */     //   7502: aload #116
/*      */     //   7504: if_acmpeq -> 7710
/*      */     //   7507: goto -> 7510
/*      */     //   7510: aload #95
/*      */     //   7512: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   7515: astore_1
/*      */     //   7516: aload #95
/*      */     //   7518: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7521: istore #115
/*      */     //   7523: aload_1
/*      */     //   7524: iload #115
/*      */     //   7526: bipush #13
/*      */     //   7528: aload #33
/*      */     //   7530: iload #34
/*      */     //   7532: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7537: invokestatic Rf_GStrWidth : (Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7540: dstore #57
/*      */     //   7542: dload #57
/*      */     //   7544: bipush #13
/*      */     //   7546: bipush #7
/*      */     //   7548: aload #33
/*      */     //   7550: iload #34
/*      */     //   7552: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7557: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7560: dstore #57
/*      */     //   7562: dload #57
/*      */     //   7564: ldc2_w 0.5
/*      */     //   7567: dmul
/*      */     //   7568: dstore #113
/*      */     //   7570: dload #68
/*      */     //   7572: dload #113
/*      */     //   7574: dsub
/*      */     //   7575: dstore #66
/*      */     //   7577: aload #33
/*      */     //   7579: iload #34
/*      */     //   7581: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7586: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7589: sipush #308
/*      */     //   7592: invokeinterface getInt : (I)I
/*      */     //   7597: iconst_1
/*      */     //   7598: if_icmpeq -> 7645
/*      */     //   7601: goto -> 7604
/*      */     //   7604: aload #33
/*      */     //   7606: iload #34
/*      */     //   7608: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7613: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7616: sipush #308
/*      */     //   7619: invokeinterface getInt : (I)I
/*      */     //   7624: iconst_2
/*      */     //   7625: if_icmpeq -> 7645
/*      */     //   7628: goto -> 7631
/*      */     //   7631: dload #66
/*      */     //   7633: dload #64
/*      */     //   7635: dsub
/*      */     //   7636: dload #59
/*      */     //   7638: dcmpl
/*      */     //   7639: ifge -> 7645
/*      */     //   7642: goto -> 7710
/*      */     //   7645: aload #33
/*      */     //   7647: iload #34
/*      */     //   7649: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7654: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7657: sipush #308
/*      */     //   7660: invokeinterface getInt : (I)I
/*      */     //   7665: istore #102
/*      */     //   7667: aload #95
/*      */     //   7669: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7672: istore #101
/*      */     //   7674: aload_1
/*      */     //   7675: iload #101
/*      */     //   7677: iload #85
/*      */     //   7679: dload #39
/*      */     //   7681: iconst_0
/*      */     //   7682: dload #70
/*      */     //   7684: iload #102
/*      */     //   7686: dload_3
/*      */     //   7687: aload #33
/*      */     //   7689: iload #34
/*      */     //   7691: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7696: invokestatic Rf_GMtext : (Lorg/renjin/gcc/runtime/Ptr;IIDIDIDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7699: dload #57
/*      */     //   7701: ldc2_w 0.5
/*      */     //   7704: dmul
/*      */     //   7705: dload #68
/*      */     //   7707: dadd
/*      */     //   7708: dstore #64
/*      */     //   7710: iload #89
/*      */     //   7712: iload #78
/*      */     //   7714: iadd
/*      */     //   7715: istore #89
/*      */     //   7717: iload #89
/*      */     //   7719: iload #79
/*      */     //   7721: if_icmpne -> 7184
/*      */     //   7724: goto -> 7727
/*      */     //   7727: iconst_0
/*      */     //   7728: aload #33
/*      */     //   7730: iload #34
/*      */     //   7732: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7737: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7740: aload #33
/*      */     //   7742: iload #34
/*      */     //   7744: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7749: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7752: aload #98
/*      */     //   7754: wide astore #599
/*      */     //   7758: wide aload #599
/*      */     //   7762: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #748	-> 170
/*      */     //   #750	-> 176
/*      */     //   #757	-> 179
/*      */     //   #763	-> 187
/*      */     //   #764	-> 192
/*      */     //   #765	-> 204
/*      */     //   #766	-> 243
/*      */     //   #768	-> 255
/*      */     //   #774	-> 258
/*      */     //   #775	-> 267
/*      */     //   #775	-> 275
/*      */     //   #776	-> 284
/*      */     //   #777	-> 332
/*      */     //   #783	-> 337
/*      */     //   #791	-> 348
/*      */     //   #792	-> 351
/*      */     //   #793	-> 357
/*      */     //   #793	-> 370
/*      */     //   #794	-> 381
/*      */     //   #795	-> 388
/*      */     //   #795	-> 396
/*      */     //   #796	-> 415
/*      */     //   #797	-> 418
/*      */     //   #798	-> 432
/*      */     //   #798	-> 445
/*      */     //   #799	-> 457
/*      */     //   #800	-> 475
/*      */     //   #801	-> 488
/*      */     //   #803	-> 497
/*      */     //   #805	-> 512
/*      */     //   #811	-> 517
/*      */     //   #812	-> 526
/*      */     //   #812	-> 537
/*      */     //   #812	-> 546
/*      */     //   #812	-> 551
/*      */     //   #813	-> 557
/*      */     //   #820	-> 562
/*      */     //   #822	-> 571
/*      */     //   #829	-> 576
/*      */     //   #831	-> 585
/*      */     //   #837	-> 590
/*      */     //   #838	-> 599
/*      */     //   #838	-> 618
/*      */     //   #839	-> 626
/*      */     //   #841	-> 633
/*      */     //   #842	-> 637
/*      */     //   #845	-> 642
/*      */     //   #846	-> 665
/*      */     //   #849	-> 670
/*      */     //   #850	-> 683
/*      */     //   #853	-> 688
/*      */     //   #854	-> 701
/*      */     //   #855	-> 706
/*      */     //   #856	-> 719
/*      */     //   #859	-> 724
/*      */     //   #860	-> 763
/*      */     //   #861	-> 768
/*      */     //   #862	-> 782
/*      */     //   #865	-> 787
/*      */     //   #866	-> 801
/*      */     //   #867	-> 841
/*      */     //   #868	-> 850
/*      */     //   #871	-> 855
/*      */     //   #872	-> 872
/*      */     //   #873	-> 879
/*      */     //   #873	-> 887
/*      */     //   #879	-> 944
/*      */     //   #880	-> 956
/*      */     //   #881	-> 1012
/*      */     //   #882	-> 1068
/*      */     //   #883	-> 1124
/*      */     //   #884	-> 1180
/*      */     //   #885	-> 1236
/*      */     //   #886	-> 1292
/*      */     //   #890	-> 1305
/*      */     //   #893	-> 1348
/*      */     //   #894	-> 1380
/*      */     //   #895	-> 1412
/*      */     //   #896	-> 1444
/*      */     //   #897	-> 1478
/*      */     //   #898	-> 1515
/*      */     //   #899	-> 1537
/*      */     //   #903	-> 1562
/*      */     //   #904	-> 1594
/*      */     //   #905	-> 1626
/*      */     //   #906	-> 1658
/*      */     //   #907	-> 1695
/*      */     //   #908	-> 1732
/*      */     //   #909	-> 1754
/*      */     //   #914	-> 1776
/*      */     //   #916	-> 1787
/*      */     //   #917	-> 1809
/*      */     //   #919	-> 1814
/*      */     //   #919	-> 1825
/*      */     //   #919	-> 1833
/*      */     //   #924	-> 1836
/*      */     //   #925	-> 1854
/*      */     //   #926	-> 1862
/*      */     //   #929	-> 1906
/*      */     //   #929	-> 1919
/*      */     //   #930	-> 1935
/*      */     //   #932	-> 1950
/*      */     //   #937	-> 1957
/*      */     //   #938	-> 1965
/*      */     //   #939	-> 1976
/*      */     //   #941	-> 1986
/*      */     //   #942	-> 1994
/*      */     //   #943	-> 2034
/*      */     //   #943	-> 2047
/*      */     //   #945	-> 2054
/*      */     //   #946	-> 2086
/*      */     //   #949	-> 2164
/*      */     //   #955	-> 2170
/*      */     //   #956	-> 2182
/*      */     //   #956	-> 2188
/*      */     //   #956	-> 2231
/*      */     //   #957	-> 2241
/*      */     //   #958	-> 2260
/*      */     //   #959	-> 2263
/*      */     //   #960	-> 2269
/*      */     //   #960	-> 2327
/*      */     //   #959	-> 2333
/*      */     //   #959	-> 2336
/*      */     //   #962	-> 2346
/*      */     //   #962	-> 2354
/*      */     //   #963	-> 2362
/*      */     //   #964	-> 2402
/*      */     //   #972	-> 2406
/*      */     //   #972	-> 2414
/*      */     //   #973	-> 2423
/*      */     //   #973	-> 2432
/*      */     //   #973	-> 2461
/*      */     //   #974	-> 2470
/*      */     //   #974	-> 2479
/*      */     //   #975	-> 2508
/*      */     //   #976	-> 2520
/*      */     //   #977	-> 2520
/*      */     //   #981	-> 2530
/*      */     //   #982	-> 2552
/*      */     //   #983	-> 2574
/*      */     //   #983	-> 2601
/*      */     //   #983	-> 2610
/*      */     //   #983	-> 2617
/*      */     //   #984	-> 2632
/*      */     //   #984	-> 2667
/*      */     //   #984	-> 2694
/*      */     //   #984	-> 2700
/*      */     //   #985	-> 2716
/*      */     //   #988	-> 2808
/*      */     //   #989	-> 2821
/*      */     //   #993	-> 2864
/*      */     //   #995	-> 2889
/*      */     //   #996	-> 2910
/*      */     //   #997	-> 2957
/*      */     //   #998	-> 3015
/*      */     //   #999	-> 3114
/*      */     //   #1000	-> 3123
/*      */     //   #1001	-> 3134
/*      */     //   #1003	-> 3157
/*      */     //   #1004	-> 3186
/*      */     //   #1003	-> 3208
/*      */     //   #1005	-> 3219
/*      */     //   #1007	-> 3248
/*      */     //   #1008	-> 3278
/*      */     //   #1010	-> 3319
/*      */     //   #1011	-> 3357
/*      */     //   #1012	-> 3395
/*      */     //   #1012	-> 3428
/*      */     //   #1012	-> 3437
/*      */     //   #1012	-> 3443
/*      */     //   #1013	-> 3449
/*      */     //   #1015	-> 3469
/*      */     //   #1019	-> 3479
/*      */     //   #1018	-> 3515
/*      */     //   #1022	-> 3523
/*      */     //   #1023	-> 3534
/*      */     //   #1025	-> 3557
/*      */     //   #1026	-> 3586
/*      */     //   #1025	-> 3608
/*      */     //   #1027	-> 3619
/*      */     //   #1029	-> 3648
/*      */     //   #1030	-> 3678
/*      */     //   #1032	-> 3719
/*      */     //   #1033	-> 3757
/*      */     //   #1034	-> 3795
/*      */     //   #1034	-> 3828
/*      */     //   #1034	-> 3837
/*      */     //   #1034	-> 3843
/*      */     //   #1035	-> 3849
/*      */     //   #1037	-> 3869
/*      */     //   #1040	-> 3879
/*      */     //   #1039	-> 3919
/*      */     //   #1042	-> 3928
/*      */     //   #1043	-> 3936
/*      */     //   #1044	-> 3957
/*      */     //   #1045	-> 3967
/*      */     //   #1046	-> 3989
/*      */     //   #1047	-> 4010
/*      */     //   #1048	-> 4032
/*      */     //   #1049	-> 4042
/*      */     //   #1050	-> 4048
/*      */     //   #1051	-> 4099
/*      */     //   #1051	-> 4112
/*      */     //   #1052	-> 4133
/*      */     //   #1053	-> 4153
/*      */     //   #1049	-> 4175
/*      */     //   #1049	-> 4178
/*      */     //   #1059	-> 4188
/*      */     //   #1060	-> 4243
/*      */     //   #1061	-> 4277
/*      */     //   #1062	-> 4282
/*      */     //   #1063	-> 4293
/*      */     //   #1063	-> 4320
/*      */     //   #1064	-> 4347
/*      */     //   #1064	-> 4372
/*      */     //   #1064	-> 4380
/*      */     //   #1064	-> 4385
/*      */     //   #1066	-> 4403
/*      */     //   #1068	-> 4425
/*      */     //   #1070	-> 4434
/*      */     //   #1071	-> 4497
/*      */     //   #1069	-> 4518
/*      */     //   #1075	-> 4532
/*      */     //   #1076	-> 4595
/*      */     //   #1074	-> 4616
/*      */     //   #1078	-> 4627
/*      */     //   #1085	-> 4647
/*      */     //   #1086	-> 4717
/*      */     //   #1087	-> 4723
/*      */     //   #1088	-> 4726
/*      */     //   #1091	-> 4732
/*      */     //   #1092	-> 4735
/*      */     //   #1093	-> 4739
/*      */     //   #1095	-> 4742
/*      */     //   #1096	-> 4749
/*      */     //   #1097	-> 4803
/*      */     //   #1098	-> 4840
/*      */     //   #1099	-> 4891
/*      */     //   #1100	-> 4905
/*      */     //   #1101	-> 4925
/*      */     //   #1103	-> 4933
/*      */     //   #1103	-> 4954
/*      */     //   #1104	-> 4975
/*      */     //   #1106	-> 4988
/*      */     //   #1105	-> 5000
/*      */     //   #1110	-> 5091
/*      */     //   #1111	-> 5144
/*      */     //   #1112	-> 5163
/*      */     //   #1113	-> 5170
/*      */     //   #1114	-> 5189
/*      */     //   #1116	-> 5208
/*      */     //   #1117	-> 5235
/*      */     //   #1116	-> 5255
/*      */     //   #1118	-> 5262
/*      */     //   #1117	-> 5267
/*      */     //   #1121	-> 5276
/*      */     //   #1119	-> 5288
/*      */     //   #1122	-> 5340
/*      */     //   #1095	-> 5351
/*      */     //   #1095	-> 5358
/*      */     //   #1134	-> 5371
/*      */     //   #1136	-> 5396
/*      */     //   #1137	-> 5417
/*      */     //   #1138	-> 5464
/*      */     //   #1139	-> 5522
/*      */     //   #1140	-> 5621
/*      */     //   #1141	-> 5630
/*      */     //   #1142	-> 5641
/*      */     //   #1144	-> 5664
/*      */     //   #1145	-> 5693
/*      */     //   #1144	-> 5715
/*      */     //   #1146	-> 5726
/*      */     //   #1148	-> 5755
/*      */     //   #1149	-> 5785
/*      */     //   #1151	-> 5826
/*      */     //   #1152	-> 5864
/*      */     //   #1153	-> 5902
/*      */     //   #1153	-> 5935
/*      */     //   #1153	-> 5944
/*      */     //   #1153	-> 5950
/*      */     //   #1154	-> 5956
/*      */     //   #1156	-> 5976
/*      */     //   #1159	-> 5986
/*      */     //   #1158	-> 6022
/*      */     //   #1162	-> 6030
/*      */     //   #1163	-> 6041
/*      */     //   #1165	-> 6064
/*      */     //   #1166	-> 6093
/*      */     //   #1165	-> 6115
/*      */     //   #1167	-> 6126
/*      */     //   #1169	-> 6155
/*      */     //   #1170	-> 6185
/*      */     //   #1172	-> 6226
/*      */     //   #1173	-> 6264
/*      */     //   #1174	-> 6302
/*      */     //   #1174	-> 6327
/*      */     //   #1174	-> 6334
/*      */     //   #1174	-> 6338
/*      */     //   #1175	-> 6342
/*      */     //   #1177	-> 6362
/*      */     //   #1180	-> 6372
/*      */     //   #1179	-> 6410
/*      */     //   #1182	-> 6417
/*      */     //   #1183	-> 6425
/*      */     //   #1184	-> 6446
/*      */     //   #1185	-> 6456
/*      */     //   #1186	-> 6478
/*      */     //   #1187	-> 6499
/*      */     //   #1188	-> 6521
/*      */     //   #1189	-> 6531
/*      */     //   #1190	-> 6537
/*      */     //   #1191	-> 6572
/*      */     //   #1191	-> 6585
/*      */     //   #1192	-> 6602
/*      */     //   #1193	-> 6622
/*      */     //   #1189	-> 6644
/*      */     //   #1189	-> 6647
/*      */     //   #1199	-> 6657
/*      */     //   #1200	-> 6704
/*      */     //   #1201	-> 6739
/*      */     //   #1202	-> 6759
/*      */     //   #1203	-> 6764
/*      */     //   #1204	-> 6775
/*      */     //   #1204	-> 6802
/*      */     //   #1205	-> 6829
/*      */     //   #1205	-> 6852
/*      */     //   #1205	-> 6858
/*      */     //   #1205	-> 6861
/*      */     //   #1207	-> 6875
/*      */     //   #1209	-> 6897
/*      */     //   #1211	-> 6906
/*      */     //   #1212	-> 6959
/*      */     //   #1210	-> 6978
/*      */     //   #1216	-> 6988
/*      */     //   #1217	-> 7041
/*      */     //   #1215	-> 7060
/*      */     //   #1219	-> 7067
/*      */     //   #1226	-> 7087
/*      */     //   #1227	-> 7152
/*      */     //   #1228	-> 7158
/*      */     //   #1229	-> 7161
/*      */     //   #1232	-> 7167
/*      */     //   #1233	-> 7170
/*      */     //   #1234	-> 7174
/*      */     //   #1236	-> 7177
/*      */     //   #1237	-> 7184
/*      */     //   #1238	-> 7221
/*      */     //   #1239	-> 7252
/*      */     //   #1240	-> 7287
/*      */     //   #1241	-> 7301
/*      */     //   #1242	-> 7321
/*      */     //   #1244	-> 7329
/*      */     //   #1244	-> 7346
/*      */     //   #1245	-> 7363
/*      */     //   #1247	-> 7376
/*      */     //   #1246	-> 7388
/*      */     //   #1251	-> 7458
/*      */     //   #1252	-> 7495
/*      */     //   #1253	-> 7510
/*      */     //   #1254	-> 7516
/*      */     //   #1255	-> 7542
/*      */     //   #1256	-> 7562
/*      */     //   #1258	-> 7577
/*      */     //   #1259	-> 7604
/*      */     //   #1258	-> 7624
/*      */     //   #1260	-> 7631
/*      */     //   #1259	-> 7636
/*      */     //   #1263	-> 7645
/*      */     //   #1261	-> 7657
/*      */     //   #1264	-> 7699
/*      */     //   #1236	-> 7710
/*      */     //   #1236	-> 7717
/*      */     //   #1273	-> 7727
/*      */     //   #1274	-> 7740
/*      */     //   #1275	-> 7752
/*      */     //   #1276	-> 7752
/*      */     //   #0	-> 7758
/*      */     //   #0	-> 7758
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	7763	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	1	ss	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7763	2	ss$offset	I
/*      */     //   0	7763	3	padjval	D
/*      */     //   0	7763	5	yu	D
/*      */     //   0	7763	7	xu	D
/*      */     //   0	7763	9	len	D
/*      */     //   0	7763	11	yu	D
/*      */     //   0	7763	13	xu	D
/*      */     //   0	7763	15	len	D
/*      */     //   0	7763	17	ss	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7763	18	ss$offset	I
/*      */     //   0	7763	19	padjval	D
/*      */     //   0	7763	21	yu	D
/*      */     //   0	7763	23	xu	D
/*      */     //   0	7763	25	len	D
/*      */     //   0	7763	27	yu	D
/*      */     //   0	7763	29	xu	D
/*      */     //   0	7763	31	len	D
/*      */     //   0	7763	33	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7763	34	dd$offset	I
/*      */     //   0	7763	35	axis_high	D
/*      */     //   0	7763	37	axis_low	D
/*      */     //   0	7763	39	axis_lab	D
/*      */     //   0	7763	41	axis_tick	D
/*      */     //   0	7763	43	axis_base	D
/*      */     //   0	7763	45	hadj	D
/*      */     //   0	7763	47	lwdticks	D
/*      */     //   0	7763	49	lwd	D
/*      */     //   0	7763	51	pos	D
/*      */     //   0	7763	53	line	D
/*      */     //   0	7763	55	high	[D
/*      */     //   0	7763	56	low	[D
/*      */     //   0	7763	57	labw	D
/*      */     //   0	7763	59	gap	D
/*      */     //   0	7763	61	limits	[D
/*      */     //   0	7763	62	usr	[D
/*      */     //   0	7763	63	axp	[D
/*      */     //   0	7763	64	tlast	D
/*      */     //   0	7763	66	tnew	D
/*      */     //   0	7763	68	temp	D
/*      */     //   0	7763	70	y	D
/*      */     //   0	7763	72	x	D
/*      */     //   0	7763	74	create_at	I
/*      */     //   0	7763	75	logflag	I
/*      */     //   0	7763	76	doticks	I
/*      */     //   0	7763	77	dolabels	I
/*      */     //   0	7763	78	incr	I
/*      */     //   0	7763	79	iend	I
/*      */     //   0	7763	80	istart	I
/*      */     //   0	7763	81	lineoff	I
/*      */     //   0	7763	82	outer	I
/*      */     //   0	7763	83	ind	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7763	84	ind$offset	I
/*      */     //   0	7763	85	side	I
/*      */     //   0	7763	86	ntmp	I
/*      */     //   0	7763	87	nint	I
/*      */     //   0	7763	88	n	I
/*      */     //   0	7763	89	i	I
/*      */     //   0	7763	90	colticks	I
/*      */     //   0	7763	91	col	I
/*      */     //   0	7763	92	npadj	I
/*      */     //   0	7763	93	lty	I
/*      */     //   0	7763	94	font	I
/*      */     //   0	7763	95	label	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	96	padj	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	97	lab	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	98	at	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	116	R_NaString$706	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	121	i$705	I
/*      */     //   0	7763	127	i$704	I
/*      */     //   0	7763	132	high$703	D
/*      */     //   0	7763	134	low$702	D
/*      */     //   0	7763	140	i$701	I
/*      */     //   0	7763	191	iftmp$700	D
/*      */     //   0	7763	207	high$699	D
/*      */     //   0	7763	209	low$698	D
/*      */     //   0	7763	214	i$697	I
/*      */     //   0	7763	233	iftmp$696	D
/*      */     //   0	7763	260	outer$695	I
/*      */     //   0	7763	272	iftmp$694	D
/*      */     //   0	7763	299	outer$693	I
/*      */     //   0	7763	303	high$692	D
/*      */     //   0	7763	307	low$691	D
/*      */     //   0	7763	315	n$690	I
/*      */     //   0	7763	320	high$689	D
/*      */     //   0	7763	324	low$688	D
/*      */     //   0	7763	352	R_NaString$687	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7763	357	i$686	I
/*      */     //   0	7763	363	i$685	I
/*      */     //   0	7763	368	high$684	D
/*      */     //   0	7763	370	low$683	D
/*      */     //   0	7763	376	i$682	I
/*      */     //   0	7763	427	iftmp$681	D
/*      */     //   0	7763	443	high$680	D
/*      */     //   0	7763	445	low$679	D
/*      */     //   0	7763	450	i$678	I
/*      */     //   0	7763	469	iftmp$677	D
/*      */     //   0	7763	496	outer$676	I
/*      */     //   0	7763	508	iftmp$675	D
/*      */     //   0	7763	535	outer$674	I
/*      */     //   0	7763	539	high$673	D
/*      */     //   0	7763	543	low$672	D
/*      */     //   0	7763	551	n$671	I
/*      */     //   0	7763	556	high$670	D
/*      */     //   0	7763	560	low$669	D
/*      */     //   0	7763	586	R_NaInt$668	I
/*      */     //   0	7763	587	iftmp$667	I
/*      */     //   0	7763	591	iftmp$666	D
/*      */     //   0	7763	614	i$665	I
/*      */     //   0	7763	622	i$664	I
/*      */     //   0	7763	624	n$663	I
/*      */     //   0	7763	751	R_NaInt$662	I
/*      */     //   0	7763	752	R_NaInt$661	I
/*      */     //   0	7763	756	R_NaInt$660	I
/*      */     //   0	7763	757	R_NaInt$659	I
/*      */     //   0	7763	758	iftmp$658	I
/*      */     //   0	7763	764	R_NaInt$657	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_plotXY(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #35
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #36
/*      */     //   10: iconst_0
/*      */     //   11: istore_1
/*      */     //   12: iconst_0
/*      */     //   13: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16: astore_2
/*      */     //   17: iconst_0
/*      */     //   18: istore_3
/*      */     //   19: iconst_0
/*      */     //   20: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   23: astore #4
/*      */     //   25: iconst_0
/*      */     //   26: istore #5
/*      */     //   28: iconst_0
/*      */     //   29: istore #6
/*      */     //   31: iconst_0
/*      */     //   32: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   35: astore #7
/*      */     //   37: iconst_0
/*      */     //   38: istore #8
/*      */     //   40: iconst_0
/*      */     //   41: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   44: astore #9
/*      */     //   46: iconst_0
/*      */     //   47: istore #10
/*      */     //   49: dconst_0
/*      */     //   50: dstore #13
/*      */     //   52: iconst_0
/*      */     //   53: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   56: astore #15
/*      */     //   58: iconst_0
/*      */     //   59: istore #16
/*      */     //   61: iconst_0
/*      */     //   62: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   65: astore #17
/*      */     //   67: iconst_0
/*      */     //   68: istore #18
/*      */     //   70: iconst_0
/*      */     //   71: istore #22
/*      */     //   73: iconst_0
/*      */     //   74: istore #23
/*      */     //   76: iconst_0
/*      */     //   77: istore #24
/*      */     //   79: iconst_0
/*      */     //   80: istore #25
/*      */     //   82: iconst_0
/*      */     //   83: istore #26
/*      */     //   85: iconst_0
/*      */     //   86: istore #27
/*      */     //   88: iconst_0
/*      */     //   89: istore #28
/*      */     //   91: iconst_0
/*      */     //   92: istore #29
/*      */     //   94: dconst_0
/*      */     //   95: dstore #37
/*      */     //   97: iconst_0
/*      */     //   98: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   101: astore #41
/*      */     //   103: iconst_0
/*      */     //   104: istore #42
/*      */     //   106: iconst_0
/*      */     //   107: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   110: astore #43
/*      */     //   112: iconst_0
/*      */     //   113: istore #44
/*      */     //   115: iconst_0
/*      */     //   116: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   119: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   124: checkcast org/renjin/sexp/SEXP
/*      */     //   127: astore #45
/*      */     //   129: iconst_0
/*      */     //   130: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   133: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   138: checkcast org/renjin/sexp/SEXP
/*      */     //   141: astore #47
/*      */     //   143: iconst_0
/*      */     //   144: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   147: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   152: checkcast org/renjin/sexp/SEXP
/*      */     //   155: astore #48
/*      */     //   157: iconst_0
/*      */     //   158: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   161: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   166: checkcast org/renjin/sexp/SEXP
/*      */     //   169: astore #49
/*      */     //   171: iconst_0
/*      */     //   172: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   175: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   180: checkcast org/renjin/sexp/SEXP
/*      */     //   183: astore #50
/*      */     //   185: iconst_0
/*      */     //   186: istore #23
/*      */     //   188: iconst_0
/*      */     //   189: istore #22
/*      */     //   191: iconst_0
/*      */     //   192: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   195: astore #17
/*      */     //   197: iconst_0
/*      */     //   198: istore #18
/*      */     //   200: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   203: astore #15
/*      */     //   205: iconst_0
/*      */     //   206: istore #16
/*      */     //   208: aload #15
/*      */     //   210: iload #16
/*      */     //   212: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   217: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   220: aload_0
/*      */     //   221: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   224: astore_0
/*      */     //   225: aload_0
/*      */     //   226: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   229: bipush #6
/*      */     //   231: if_icmple -> 237
/*      */     //   234: goto -> 276
/*      */     //   237: new org/renjin/gcc/runtime/BytePtr
/*      */     //   240: dup
/*      */     //   241: ldc 'graphics '
/*      */     //   243: invokevirtual getBytes : ()[B
/*      */     //   246: iconst_0
/*      */     //   247: invokespecial <init> : ([BI)V
/*      */     //   250: new org/renjin/gcc/runtime/BytePtr
/*      */     //   253: dup
/*      */     //   254: ldc 'too few arguments '
/*      */     //   256: invokevirtual getBytes : ()[B
/*      */     //   259: iconst_0
/*      */     //   260: invokespecial <init> : ([BI)V
/*      */     //   263: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   266: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   269: iconst_0
/*      */     //   270: anewarray java/lang/Object
/*      */     //   273: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   276: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   279: astore #52
/*      */     //   281: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   284: astore #51
/*      */     //   286: aload_0
/*      */     //   287: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   290: astore #53
/*      */     //   292: aload #53
/*      */     //   294: invokestatic Rf_isNewList : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   297: ifne -> 303
/*      */     //   300: goto -> 348
/*      */     //   303: aload #53
/*      */     //   305: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   308: iconst_1
/*      */     //   309: if_icmpgt -> 315
/*      */     //   312: goto -> 348
/*      */     //   315: aload #53
/*      */     //   317: iconst_0
/*      */     //   318: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   321: astore #52
/*      */     //   323: aload #52
/*      */     //   325: bipush #14
/*      */     //   327: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   330: aload #53
/*      */     //   332: iconst_1
/*      */     //   333: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   336: astore #51
/*      */     //   338: aload #51
/*      */     //   340: bipush #14
/*      */     //   342: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   345: goto -> 442
/*      */     //   348: aload #53
/*      */     //   350: invokestatic Rf_isList : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   353: ifne -> 359
/*      */     //   356: goto -> 402
/*      */     //   359: aload #53
/*      */     //   361: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   364: iconst_1
/*      */     //   365: if_icmpgt -> 371
/*      */     //   368: goto -> 402
/*      */     //   371: aload #53
/*      */     //   373: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   376: astore #52
/*      */     //   378: aload #52
/*      */     //   380: bipush #14
/*      */     //   382: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   385: aload #53
/*      */     //   387: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   390: astore #51
/*      */     //   392: aload #51
/*      */     //   394: bipush #14
/*      */     //   396: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   399: goto -> 442
/*      */     //   402: new org/renjin/gcc/runtime/BytePtr
/*      */     //   405: dup
/*      */     //   406: ldc 'graphics '
/*      */     //   408: invokevirtual getBytes : ()[B
/*      */     //   411: iconst_0
/*      */     //   412: invokespecial <init> : ([BI)V
/*      */     //   415: new org/renjin/gcc/runtime/BytePtr
/*      */     //   418: dup
/*      */     //   419: ldc_w 'invalid plotting structure '
/*      */     //   422: invokevirtual getBytes : ()[B
/*      */     //   425: iconst_0
/*      */     //   426: invokespecial <init> : ([BI)V
/*      */     //   429: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   432: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   435: iconst_0
/*      */     //   436: anewarray java/lang/Object
/*      */     //   439: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   442: aload #52
/*      */     //   444: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   447: wide istore #514
/*      */     //   451: aload #51
/*      */     //   453: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   456: wide istore #513
/*      */     //   460: wide iload #514
/*      */     //   464: wide iload #513
/*      */     //   468: if_icmpne -> 474
/*      */     //   471: goto -> 531
/*      */     //   474: new org/renjin/gcc/runtime/BytePtr
/*      */     //   477: dup
/*      */     //   478: ldc 'graphics '
/*      */     //   480: invokevirtual getBytes : ()[B
/*      */     //   483: iconst_0
/*      */     //   484: invokespecial <init> : ([BI)V
/*      */     //   487: new org/renjin/gcc/runtime/BytePtr
/*      */     //   490: dup
/*      */     //   491: ldc_w ''x' and 'y' lengths differ in %s() '
/*      */     //   494: invokevirtual getBytes : ()[B
/*      */     //   497: iconst_0
/*      */     //   498: invokespecial <init> : ([BI)V
/*      */     //   501: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   504: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   507: iconst_1
/*      */     //   508: anewarray java/lang/Object
/*      */     //   511: dup
/*      */     //   512: iconst_0
/*      */     //   513: new org/renjin/gcc/runtime/BytePtr
/*      */     //   516: dup
/*      */     //   517: ldc_w 'plot.xy '
/*      */     //   520: invokevirtual getBytes : ()[B
/*      */     //   523: iconst_0
/*      */     //   524: invokespecial <init> : ([BI)V
/*      */     //   527: aastore
/*      */     //   528: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   531: aload #52
/*      */     //   533: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   536: istore #29
/*      */     //   538: aload_0
/*      */     //   539: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   542: astore_0
/*      */     //   543: aload_0
/*      */     //   544: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   547: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   550: ifeq -> 556
/*      */     //   553: goto -> 563
/*      */     //   556: bipush #112
/*      */     //   558: istore #23
/*      */     //   560: goto -> 736
/*      */     //   563: aload_0
/*      */     //   564: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   567: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   570: bipush #16
/*      */     //   572: if_icmpeq -> 578
/*      */     //   575: goto -> 696
/*      */     //   578: aload_0
/*      */     //   579: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   582: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   585: iconst_1
/*      */     //   586: if_icmpeq -> 592
/*      */     //   589: goto -> 696
/*      */     //   592: aload_0
/*      */     //   593: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   596: iconst_0
/*      */     //   597: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   600: astore #50
/*      */     //   602: aload #50
/*      */     //   604: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   607: ifgt -> 613
/*      */     //   610: goto -> 696
/*      */     //   613: aload #50
/*      */     //   615: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   618: iconst_1
/*      */     //   619: if_icmpgt -> 625
/*      */     //   622: goto -> 681
/*      */     //   625: aload #50
/*      */     //   627: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   630: wide astore #500
/*      */     //   634: new org/renjin/gcc/runtime/BytePtr
/*      */     //   637: dup
/*      */     //   638: ldc 'graphics '
/*      */     //   640: invokevirtual getBytes : ()[B
/*      */     //   643: iconst_0
/*      */     //   644: invokespecial <init> : ([BI)V
/*      */     //   647: new org/renjin/gcc/runtime/BytePtr
/*      */     //   650: dup
/*      */     //   651: ldc_w 'plot type '%s' will be truncated to first character '
/*      */     //   654: invokevirtual getBytes : ()[B
/*      */     //   657: iconst_0
/*      */     //   658: invokespecial <init> : ([BI)V
/*      */     //   661: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   664: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   667: iconst_1
/*      */     //   668: anewarray java/lang/Object
/*      */     //   671: dup
/*      */     //   672: iconst_0
/*      */     //   673: wide aload #500
/*      */     //   677: aastore
/*      */     //   678: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   681: aload #50
/*      */     //   683: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   686: invokeinterface getByte : ()B
/*      */     //   691: istore #23
/*      */     //   693: goto -> 736
/*      */     //   696: new org/renjin/gcc/runtime/BytePtr
/*      */     //   699: dup
/*      */     //   700: ldc 'graphics '
/*      */     //   702: invokevirtual getBytes : ()[B
/*      */     //   705: iconst_0
/*      */     //   706: invokespecial <init> : ([BI)V
/*      */     //   709: new org/renjin/gcc/runtime/BytePtr
/*      */     //   712: dup
/*      */     //   713: ldc_w 'invalid plot type '
/*      */     //   716: invokevirtual getBytes : ()[B
/*      */     //   719: iconst_0
/*      */     //   720: invokespecial <init> : ([BI)V
/*      */     //   723: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   726: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   729: iconst_0
/*      */     //   730: anewarray java/lang/Object
/*      */     //   733: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   736: aload_0
/*      */     //   737: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   740: astore_0
/*      */     //   741: aload #15
/*      */     //   743: iload #16
/*      */     //   745: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   750: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   753: sipush #372
/*      */     //   756: invokeinterface getInt : (I)I
/*      */     //   761: wide istore #490
/*      */     //   765: aload_0
/*      */     //   766: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   769: wide iload #490
/*      */     //   773: invokestatic FixupPch : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   776: astore #50
/*      */     //   778: aload #50
/*      */     //   780: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   783: pop
/*      */     //   784: aload #50
/*      */     //   786: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   789: istore #28
/*      */     //   791: aload_0
/*      */     //   792: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   795: astore_0
/*      */     //   796: aload #15
/*      */     //   798: iload #16
/*      */     //   800: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   805: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   808: sipush #312
/*      */     //   811: invokeinterface getInt : (I)I
/*      */     //   816: wide istore #486
/*      */     //   820: aload_0
/*      */     //   821: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   824: wide iload #486
/*      */     //   828: invokestatic Rf_FixupLty : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   831: astore #46
/*      */     //   833: aload #46
/*      */     //   835: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   838: pop
/*      */     //   839: aload_0
/*      */     //   840: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   843: astore_0
/*      */     //   844: aload_0
/*      */     //   845: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   848: iconst_0
/*      */     //   849: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   852: astore #48
/*      */     //   854: aload #48
/*      */     //   856: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   859: pop
/*      */     //   860: aload_0
/*      */     //   861: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   864: astore_0
/*      */     //   865: aload #48
/*      */     //   867: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   870: istore #26
/*      */     //   872: aload_0
/*      */     //   873: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   876: ldc 16777215
/*      */     //   878: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   881: astore #47
/*      */     //   883: aload #47
/*      */     //   885: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   888: pop
/*      */     //   889: aload_0
/*      */     //   890: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   893: astore_0
/*      */     //   894: aload #47
/*      */     //   896: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   899: istore #25
/*      */     //   901: aload_0
/*      */     //   902: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   905: dconst_1
/*      */     //   906: invokestatic FixupCex : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   909: astore #49
/*      */     //   911: aload #49
/*      */     //   913: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   916: pop
/*      */     //   917: aload_0
/*      */     //   918: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   921: astore_0
/*      */     //   922: aload #49
/*      */     //   924: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   927: istore #27
/*      */     //   929: aload #15
/*      */     //   931: iload #16
/*      */     //   933: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   938: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   941: sipush #316
/*      */     //   944: invokeinterface getDouble : (I)D
/*      */     //   949: wide dstore #478
/*      */     //   953: aload_0
/*      */     //   954: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   957: wide dload #478
/*      */     //   961: invokestatic Rf_FixupLwd : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   964: astore #45
/*      */     //   966: aload #45
/*      */     //   968: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   971: pop
/*      */     //   972: aload_0
/*      */     //   973: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   976: astore_0
/*      */     //   977: aload #45
/*      */     //   979: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   982: istore #24
/*      */     //   984: aload #15
/*      */     //   986: iload #16
/*      */     //   988: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   993: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   996: aload_0
/*      */     //   997: aload #15
/*      */     //   999: iload #16
/*      */     //   1001: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1006: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1009: aload #52
/*      */     //   1011: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1014: astore #43
/*      */     //   1016: iconst_0
/*      */     //   1017: istore #44
/*      */     //   1019: aload #51
/*      */     //   1021: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1024: astore #41
/*      */     //   1026: iconst_0
/*      */     //   1027: istore #42
/*      */     //   1029: aload #46
/*      */     //   1031: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1034: invokeinterface getInt : ()I
/*      */     //   1039: wide istore #474
/*      */     //   1043: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1046: wide istore #473
/*      */     //   1050: wide iload #474
/*      */     //   1054: wide iload #473
/*      */     //   1058: if_icmpne -> 1064
/*      */     //   1061: goto -> 1110
/*      */     //   1064: aload #15
/*      */     //   1066: iload #16
/*      */     //   1068: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1073: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1076: wide astore #471
/*      */     //   1080: aload #46
/*      */     //   1082: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1085: invokeinterface getInt : ()I
/*      */     //   1090: wide istore #468
/*      */     //   1094: wide aload #471
/*      */     //   1098: sipush #312
/*      */     //   1101: wide iload #468
/*      */     //   1105: invokeinterface setInt : (II)V
/*      */     //   1110: aload #45
/*      */     //   1112: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1115: invokeinterface getDouble : ()D
/*      */     //   1120: dstore #31
/*      */     //   1122: dload #31
/*      */     //   1124: invokestatic R_finite : (D)I
/*      */     //   1127: ifne -> 1133
/*      */     //   1130: goto -> 1155
/*      */     //   1133: aload #15
/*      */     //   1135: iload #16
/*      */     //   1137: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1142: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1145: sipush #316
/*      */     //   1148: dload #31
/*      */     //   1150: invokeinterface setDouble : (ID)V
/*      */     //   1155: iconst_1
/*      */     //   1156: aload #15
/*      */     //   1158: iload #16
/*      */     //   1160: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1165: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1168: iload #23
/*      */     //   1170: lookupswitch default -> 4159, 83 -> 3159, 98 -> 1830, 99 -> 1830, 104 -> 3815, 108 -> 1252, 110 -> 4156, 111 -> 1252, 112 -> 4156, 115 -> 2350
/*      */     //   1252: aload #15
/*      */     //   1254: iload #16
/*      */     //   1256: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1261: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1264: wide astore #461
/*      */     //   1268: aload #48
/*      */     //   1270: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1273: invokeinterface getInt : ()I
/*      */     //   1278: wide istore #457
/*      */     //   1282: wide aload #461
/*      */     //   1286: bipush #44
/*      */     //   1288: wide iload #457
/*      */     //   1292: invokeinterface setInt : (II)V
/*      */     //   1297: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1300: dstore #39
/*      */     //   1302: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1305: dstore #37
/*      */     //   1307: iconst_0
/*      */     //   1308: istore #30
/*      */     //   1310: goto -> 1817
/*      */     //   1313: iload #30
/*      */     //   1315: bipush #8
/*      */     //   1317: imul
/*      */     //   1318: wide istore #455
/*      */     //   1322: aload #43
/*      */     //   1324: wide astore #453
/*      */     //   1328: iload #44
/*      */     //   1330: wide iload #455
/*      */     //   1334: iadd
/*      */     //   1335: wide istore #454
/*      */     //   1339: wide aload #453
/*      */     //   1343: wide iload #454
/*      */     //   1347: invokeinterface getDouble : (I)D
/*      */     //   1352: wide dstore #451
/*      */     //   1356: aload #36
/*      */     //   1358: iconst_0
/*      */     //   1359: wide dload #451
/*      */     //   1363: dastore
/*      */     //   1364: iload #30
/*      */     //   1366: bipush #8
/*      */     //   1368: imul
/*      */     //   1369: wide istore #449
/*      */     //   1373: aload #41
/*      */     //   1375: wide astore #447
/*      */     //   1379: iload #42
/*      */     //   1381: wide iload #449
/*      */     //   1385: iadd
/*      */     //   1386: wide istore #448
/*      */     //   1390: wide aload #447
/*      */     //   1394: wide iload #448
/*      */     //   1398: invokeinterface getDouble : (I)D
/*      */     //   1403: wide dstore #445
/*      */     //   1407: aload #35
/*      */     //   1409: iconst_0
/*      */     //   1410: wide dload #445
/*      */     //   1414: dastore
/*      */     //   1415: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1418: dup
/*      */     //   1419: aload #36
/*      */     //   1421: iconst_0
/*      */     //   1422: invokespecial <init> : ([DI)V
/*      */     //   1425: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1428: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1431: dup
/*      */     //   1432: aload #35
/*      */     //   1434: iconst_0
/*      */     //   1435: invokespecial <init> : ([DI)V
/*      */     //   1438: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1441: bipush #12
/*      */     //   1443: iconst_0
/*      */     //   1444: aload #15
/*      */     //   1446: iload #16
/*      */     //   1448: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1453: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1456: aload #36
/*      */     //   1458: iconst_0
/*      */     //   1459: daload
/*      */     //   1460: invokestatic R_finite : (D)I
/*      */     //   1463: ifne -> 1469
/*      */     //   1466: goto -> 1511
/*      */     //   1469: aload #35
/*      */     //   1471: iconst_0
/*      */     //   1472: daload
/*      */     //   1473: invokestatic R_finite : (D)I
/*      */     //   1476: ifne -> 1482
/*      */     //   1479: goto -> 1511
/*      */     //   1482: dload #39
/*      */     //   1484: invokestatic R_finite : (D)I
/*      */     //   1487: ifeq -> 1504
/*      */     //   1490: goto -> 1493
/*      */     //   1493: dload #37
/*      */     //   1495: invokestatic R_finite : (D)I
/*      */     //   1498: ifeq -> 1504
/*      */     //   1501: goto -> 1511
/*      */     //   1504: iload #30
/*      */     //   1506: istore #22
/*      */     //   1508: goto -> 1802
/*      */     //   1511: dload #39
/*      */     //   1513: invokestatic R_finite : (D)I
/*      */     //   1516: ifne -> 1522
/*      */     //   1519: goto -> 1671
/*      */     //   1522: dload #37
/*      */     //   1524: invokestatic R_finite : (D)I
/*      */     //   1527: ifne -> 1533
/*      */     //   1530: goto -> 1671
/*      */     //   1533: aload #36
/*      */     //   1535: iconst_0
/*      */     //   1536: daload
/*      */     //   1537: invokestatic R_finite : (D)I
/*      */     //   1540: ifeq -> 1559
/*      */     //   1543: goto -> 1546
/*      */     //   1546: aload #35
/*      */     //   1548: iconst_0
/*      */     //   1549: daload
/*      */     //   1550: invokestatic R_finite : (D)I
/*      */     //   1553: ifeq -> 1559
/*      */     //   1556: goto -> 1671
/*      */     //   1559: iload #30
/*      */     //   1561: iload #22
/*      */     //   1563: isub
/*      */     //   1564: iconst_1
/*      */     //   1565: if_icmpgt -> 1571
/*      */     //   1568: goto -> 1668
/*      */     //   1571: iload #22
/*      */     //   1573: bipush #8
/*      */     //   1575: imul
/*      */     //   1576: wide istore #426
/*      */     //   1580: aload #41
/*      */     //   1582: wide astore #424
/*      */     //   1586: iload #42
/*      */     //   1588: wide iload #426
/*      */     //   1592: iadd
/*      */     //   1593: wide istore #425
/*      */     //   1597: iload #22
/*      */     //   1599: bipush #8
/*      */     //   1601: imul
/*      */     //   1602: wide istore #422
/*      */     //   1606: aload #43
/*      */     //   1608: wide astore #420
/*      */     //   1612: iload #44
/*      */     //   1614: wide iload #422
/*      */     //   1618: iadd
/*      */     //   1619: wide istore #421
/*      */     //   1623: iload #30
/*      */     //   1625: iload #22
/*      */     //   1627: isub
/*      */     //   1628: wide aload #420
/*      */     //   1632: wide iload #421
/*      */     //   1636: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1641: wide aload #424
/*      */     //   1645: wide iload #425
/*      */     //   1649: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1654: bipush #12
/*      */     //   1656: aload #15
/*      */     //   1658: iload #16
/*      */     //   1660: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1665: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1668: goto -> 1802
/*      */     //   1671: dload #39
/*      */     //   1673: invokestatic R_finite : (D)I
/*      */     //   1676: ifne -> 1682
/*      */     //   1679: goto -> 1802
/*      */     //   1682: dload #37
/*      */     //   1684: invokestatic R_finite : (D)I
/*      */     //   1687: ifne -> 1693
/*      */     //   1690: goto -> 1802
/*      */     //   1693: iload #29
/*      */     //   1695: iconst_m1
/*      */     //   1696: iadd
/*      */     //   1697: iload #30
/*      */     //   1699: if_icmpeq -> 1705
/*      */     //   1702: goto -> 1802
/*      */     //   1705: iload #22
/*      */     //   1707: bipush #8
/*      */     //   1709: imul
/*      */     //   1710: wide istore #414
/*      */     //   1714: aload #41
/*      */     //   1716: wide astore #412
/*      */     //   1720: iload #42
/*      */     //   1722: wide iload #414
/*      */     //   1726: iadd
/*      */     //   1727: wide istore #413
/*      */     //   1731: iload #22
/*      */     //   1733: bipush #8
/*      */     //   1735: imul
/*      */     //   1736: wide istore #410
/*      */     //   1740: aload #43
/*      */     //   1742: wide astore #408
/*      */     //   1746: iload #44
/*      */     //   1748: wide iload #410
/*      */     //   1752: iadd
/*      */     //   1753: wide istore #409
/*      */     //   1757: iload #29
/*      */     //   1759: iload #22
/*      */     //   1761: isub
/*      */     //   1762: wide aload #408
/*      */     //   1766: wide iload #409
/*      */     //   1770: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1775: wide aload #412
/*      */     //   1779: wide iload #413
/*      */     //   1783: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1788: bipush #12
/*      */     //   1790: aload #15
/*      */     //   1792: iload #16
/*      */     //   1794: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1799: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1802: aload #36
/*      */     //   1804: iconst_0
/*      */     //   1805: daload
/*      */     //   1806: dstore #39
/*      */     //   1808: aload #35
/*      */     //   1810: iconst_0
/*      */     //   1811: daload
/*      */     //   1812: dstore #37
/*      */     //   1814: iinc #30, 1
/*      */     //   1817: iload #30
/*      */     //   1819: iload #29
/*      */     //   1821: if_icmplt -> 1313
/*      */     //   1824: goto -> 1827
/*      */     //   1827: goto -> 4207
/*      */     //   1830: ldc2_w 0.5
/*      */     //   1833: bipush #15
/*      */     //   1835: bipush #13
/*      */     //   1837: aload #15
/*      */     //   1839: iload #16
/*      */     //   1841: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1846: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1849: dstore #13
/*      */     //   1851: aload #15
/*      */     //   1853: iload #16
/*      */     //   1855: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1860: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1863: wide astore #405
/*      */     //   1867: aload #48
/*      */     //   1869: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1872: invokeinterface getInt : ()I
/*      */     //   1877: wide istore #401
/*      */     //   1881: wide aload #405
/*      */     //   1885: bipush #44
/*      */     //   1887: wide iload #401
/*      */     //   1891: invokeinterface setInt : (II)V
/*      */     //   1896: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1899: dstore #39
/*      */     //   1901: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1904: dstore #37
/*      */     //   1906: iconst_0
/*      */     //   1907: istore #30
/*      */     //   1909: goto -> 2337
/*      */     //   1912: iload #30
/*      */     //   1914: bipush #8
/*      */     //   1916: imul
/*      */     //   1917: wide istore #399
/*      */     //   1921: aload #43
/*      */     //   1923: wide astore #397
/*      */     //   1927: iload #44
/*      */     //   1929: wide iload #399
/*      */     //   1933: iadd
/*      */     //   1934: wide istore #398
/*      */     //   1938: wide aload #397
/*      */     //   1942: wide iload #398
/*      */     //   1946: invokeinterface getDouble : (I)D
/*      */     //   1951: wide dstore #395
/*      */     //   1955: aload #36
/*      */     //   1957: iconst_0
/*      */     //   1958: wide dload #395
/*      */     //   1962: dastore
/*      */     //   1963: iload #30
/*      */     //   1965: bipush #8
/*      */     //   1967: imul
/*      */     //   1968: wide istore #393
/*      */     //   1972: aload #41
/*      */     //   1974: wide astore #391
/*      */     //   1978: iload #42
/*      */     //   1980: wide iload #393
/*      */     //   1984: iadd
/*      */     //   1985: wide istore #392
/*      */     //   1989: wide aload #391
/*      */     //   1993: wide iload #392
/*      */     //   1997: invokeinterface getDouble : (I)D
/*      */     //   2002: wide dstore #389
/*      */     //   2006: aload #35
/*      */     //   2008: iconst_0
/*      */     //   2009: wide dload #389
/*      */     //   2013: dastore
/*      */     //   2014: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2017: dup
/*      */     //   2018: aload #36
/*      */     //   2020: iconst_0
/*      */     //   2021: invokespecial <init> : ([DI)V
/*      */     //   2024: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2027: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2030: dup
/*      */     //   2031: aload #35
/*      */     //   2033: iconst_0
/*      */     //   2034: invokespecial <init> : ([DI)V
/*      */     //   2037: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2040: bipush #12
/*      */     //   2042: bipush #13
/*      */     //   2044: aload #15
/*      */     //   2046: iload #16
/*      */     //   2048: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2053: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2056: dload #39
/*      */     //   2058: invokestatic R_finite : (D)I
/*      */     //   2061: ifne -> 2067
/*      */     //   2064: goto -> 2322
/*      */     //   2067: dload #37
/*      */     //   2069: invokestatic R_finite : (D)I
/*      */     //   2072: ifne -> 2078
/*      */     //   2075: goto -> 2322
/*      */     //   2078: aload #36
/*      */     //   2080: iconst_0
/*      */     //   2081: daload
/*      */     //   2082: invokestatic R_finite : (D)I
/*      */     //   2085: ifne -> 2091
/*      */     //   2088: goto -> 2322
/*      */     //   2091: aload #35
/*      */     //   2093: iconst_0
/*      */     //   2094: daload
/*      */     //   2095: invokestatic R_finite : (D)I
/*      */     //   2098: ifne -> 2104
/*      */     //   2101: goto -> 2322
/*      */     //   2104: aload #35
/*      */     //   2106: iconst_0
/*      */     //   2107: daload
/*      */     //   2108: dload #37
/*      */     //   2110: dsub
/*      */     //   2111: wide dstore #377
/*      */     //   2115: aload #36
/*      */     //   2117: iconst_0
/*      */     //   2118: daload
/*      */     //   2119: dload #39
/*      */     //   2121: dsub
/*      */     //   2122: wide dload #377
/*      */     //   2126: invokestatic hypot : (DD)D
/*      */     //   2129: ldc2_w 0.5
/*      */     //   2132: dmul
/*      */     //   2133: dload #13
/*      */     //   2135: dcmpl
/*      */     //   2136: ifgt -> 2142
/*      */     //   2139: goto -> 2322
/*      */     //   2142: aload #35
/*      */     //   2144: iconst_0
/*      */     //   2145: daload
/*      */     //   2146: dload #37
/*      */     //   2148: dsub
/*      */     //   2149: wide dstore #365
/*      */     //   2153: aload #36
/*      */     //   2155: iconst_0
/*      */     //   2156: daload
/*      */     //   2157: dload #39
/*      */     //   2159: dsub
/*      */     //   2160: wide dload #365
/*      */     //   2164: invokestatic hypot : (DD)D
/*      */     //   2167: wide dstore #359
/*      */     //   2171: dload #13
/*      */     //   2173: wide dload #359
/*      */     //   2177: ddiv
/*      */     //   2178: dstore #11
/*      */     //   2180: aload #35
/*      */     //   2182: iconst_0
/*      */     //   2183: daload
/*      */     //   2184: wide dstore #357
/*      */     //   2188: dload #37
/*      */     //   2190: wide dload #357
/*      */     //   2194: dsub
/*      */     //   2195: dload #11
/*      */     //   2197: dmul
/*      */     //   2198: wide dstore #353
/*      */     //   2202: aload #35
/*      */     //   2204: iconst_0
/*      */     //   2205: daload
/*      */     //   2206: wide dstore #351
/*      */     //   2210: wide dload #353
/*      */     //   2214: wide dload #351
/*      */     //   2218: dadd
/*      */     //   2219: wide dstore #349
/*      */     //   2223: aload #36
/*      */     //   2225: iconst_0
/*      */     //   2226: daload
/*      */     //   2227: wide dstore #347
/*      */     //   2231: dload #39
/*      */     //   2233: wide dload #347
/*      */     //   2237: dsub
/*      */     //   2238: dload #11
/*      */     //   2240: dmul
/*      */     //   2241: wide dstore #343
/*      */     //   2245: aload #36
/*      */     //   2247: iconst_0
/*      */     //   2248: daload
/*      */     //   2249: wide dstore #341
/*      */     //   2253: wide dload #343
/*      */     //   2257: wide dload #341
/*      */     //   2261: dadd
/*      */     //   2262: wide dstore #339
/*      */     //   2266: aload #35
/*      */     //   2268: iconst_0
/*      */     //   2269: daload
/*      */     //   2270: dload #37
/*      */     //   2272: dsub
/*      */     //   2273: dload #11
/*      */     //   2275: dmul
/*      */     //   2276: dload #37
/*      */     //   2278: dadd
/*      */     //   2279: wide dstore #331
/*      */     //   2283: aload #36
/*      */     //   2285: iconst_0
/*      */     //   2286: daload
/*      */     //   2287: dload #39
/*      */     //   2289: dsub
/*      */     //   2290: dload #11
/*      */     //   2292: dmul
/*      */     //   2293: dload #39
/*      */     //   2295: dadd
/*      */     //   2296: wide dload #331
/*      */     //   2300: wide dload #339
/*      */     //   2304: wide dload #349
/*      */     //   2308: bipush #13
/*      */     //   2310: aload #15
/*      */     //   2312: iload #16
/*      */     //   2314: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2319: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2322: aload #36
/*      */     //   2324: iconst_0
/*      */     //   2325: daload
/*      */     //   2326: dstore #39
/*      */     //   2328: aload #35
/*      */     //   2330: iconst_0
/*      */     //   2331: daload
/*      */     //   2332: dstore #37
/*      */     //   2334: iinc #30, 1
/*      */     //   2337: iload #30
/*      */     //   2339: iload #29
/*      */     //   2341: if_icmplt -> 1912
/*      */     //   2344: goto -> 2347
/*      */     //   2347: goto -> 4207
/*      */     //   2350: iconst_0
/*      */     //   2351: istore #6
/*      */     //   2353: iload #29
/*      */     //   2355: sipush #1000
/*      */     //   2358: if_icmple -> 2364
/*      */     //   2361: goto -> 2402
/*      */     //   2364: iload #29
/*      */     //   2366: bipush #32
/*      */     //   2368: imul
/*      */     //   2369: wide istore #321
/*      */     //   2373: iload #29
/*      */     //   2375: bipush #16
/*      */     //   2377: imul
/*      */     //   2378: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   2381: astore #9
/*      */     //   2383: iconst_0
/*      */     //   2384: istore #10
/*      */     //   2386: iload #29
/*      */     //   2388: bipush #16
/*      */     //   2390: imul
/*      */     //   2391: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   2394: astore #7
/*      */     //   2396: iconst_0
/*      */     //   2397: istore #8
/*      */     //   2399: goto -> 2439
/*      */     //   2402: invokestatic vmaxget : ()Ljava/lang/Object;
/*      */     //   2405: invokestatic toPtr : (Ljava/lang/Object;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2408: astore #17
/*      */     //   2410: iconst_0
/*      */     //   2411: istore #18
/*      */     //   2413: iload #29
/*      */     //   2415: bipush #16
/*      */     //   2417: imul
/*      */     //   2418: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   2421: astore #9
/*      */     //   2423: iconst_0
/*      */     //   2424: istore #10
/*      */     //   2426: iload #29
/*      */     //   2428: bipush #16
/*      */     //   2430: imul
/*      */     //   2431: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   2434: astore #7
/*      */     //   2436: iconst_0
/*      */     //   2437: istore #8
/*      */     //   2439: aload #15
/*      */     //   2441: iload #16
/*      */     //   2443: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2448: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2451: wide astore #311
/*      */     //   2455: aload #48
/*      */     //   2457: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2460: invokeinterface getInt : ()I
/*      */     //   2465: wide istore #307
/*      */     //   2469: wide aload #311
/*      */     //   2473: bipush #44
/*      */     //   2475: wide iload #307
/*      */     //   2479: invokeinterface setInt : (II)V
/*      */     //   2484: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   2487: dstore #39
/*      */     //   2489: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   2492: dstore #37
/*      */     //   2494: iconst_0
/*      */     //   2495: istore #30
/*      */     //   2497: goto -> 3094
/*      */     //   2500: iload #30
/*      */     //   2502: bipush #8
/*      */     //   2504: imul
/*      */     //   2505: wide istore #305
/*      */     //   2509: aload #43
/*      */     //   2511: wide astore #303
/*      */     //   2515: iload #44
/*      */     //   2517: wide iload #305
/*      */     //   2521: iadd
/*      */     //   2522: wide istore #304
/*      */     //   2526: wide aload #303
/*      */     //   2530: wide iload #304
/*      */     //   2534: invokeinterface getDouble : (I)D
/*      */     //   2539: wide dstore #301
/*      */     //   2543: aload #36
/*      */     //   2545: iconst_0
/*      */     //   2546: wide dload #301
/*      */     //   2550: dastore
/*      */     //   2551: iload #30
/*      */     //   2553: bipush #8
/*      */     //   2555: imul
/*      */     //   2556: wide istore #299
/*      */     //   2560: aload #41
/*      */     //   2562: wide astore #297
/*      */     //   2566: iload #42
/*      */     //   2568: wide iload #299
/*      */     //   2572: iadd
/*      */     //   2573: wide istore #298
/*      */     //   2577: wide aload #297
/*      */     //   2581: wide iload #298
/*      */     //   2585: invokeinterface getDouble : (I)D
/*      */     //   2590: wide dstore #295
/*      */     //   2594: aload #35
/*      */     //   2596: iconst_0
/*      */     //   2597: wide dload #295
/*      */     //   2601: dastore
/*      */     //   2602: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2605: dup
/*      */     //   2606: aload #36
/*      */     //   2608: iconst_0
/*      */     //   2609: invokespecial <init> : ([DI)V
/*      */     //   2612: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2615: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2618: dup
/*      */     //   2619: aload #35
/*      */     //   2621: iconst_0
/*      */     //   2622: invokespecial <init> : ([DI)V
/*      */     //   2625: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2628: bipush #12
/*      */     //   2630: iconst_0
/*      */     //   2631: aload #15
/*      */     //   2633: iload #16
/*      */     //   2635: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2640: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2643: aload #36
/*      */     //   2645: iconst_0
/*      */     //   2646: daload
/*      */     //   2647: invokestatic R_finite : (D)I
/*      */     //   2650: ifne -> 2656
/*      */     //   2653: goto -> 2987
/*      */     //   2656: aload #35
/*      */     //   2658: iconst_0
/*      */     //   2659: daload
/*      */     //   2660: invokestatic R_finite : (D)I
/*      */     //   2663: ifne -> 2669
/*      */     //   2666: goto -> 2987
/*      */     //   2669: dload #39
/*      */     //   2671: invokestatic R_finite : (D)I
/*      */     //   2674: ifne -> 2680
/*      */     //   2677: goto -> 2987
/*      */     //   2680: dload #37
/*      */     //   2682: invokestatic R_finite : (D)I
/*      */     //   2685: ifne -> 2691
/*      */     //   2688: goto -> 2987
/*      */     //   2691: iload #6
/*      */     //   2693: ifeq -> 2699
/*      */     //   2696: goto -> 2784
/*      */     //   2699: iload #6
/*      */     //   2701: bipush #8
/*      */     //   2703: imul
/*      */     //   2704: wide istore #285
/*      */     //   2708: aload #9
/*      */     //   2710: wide astore #283
/*      */     //   2714: iload #10
/*      */     //   2716: wide iload #285
/*      */     //   2720: iadd
/*      */     //   2721: wide istore #284
/*      */     //   2725: wide aload #283
/*      */     //   2729: wide iload #284
/*      */     //   2733: dload #39
/*      */     //   2735: invokeinterface setDouble : (ID)V
/*      */     //   2740: iload #6
/*      */     //   2742: bipush #8
/*      */     //   2744: imul
/*      */     //   2745: wide istore #281
/*      */     //   2749: aload #7
/*      */     //   2751: wide astore #279
/*      */     //   2755: iload #8
/*      */     //   2757: wide iload #281
/*      */     //   2761: iadd
/*      */     //   2762: wide istore #280
/*      */     //   2766: wide aload #279
/*      */     //   2770: wide iload #280
/*      */     //   2774: dload #37
/*      */     //   2776: invokeinterface setDouble : (ID)V
/*      */     //   2781: iinc #6, 1
/*      */     //   2784: iload #6
/*      */     //   2786: bipush #8
/*      */     //   2788: imul
/*      */     //   2789: wide istore #277
/*      */     //   2793: aload #9
/*      */     //   2795: wide astore #275
/*      */     //   2799: iload #10
/*      */     //   2801: wide iload #277
/*      */     //   2805: iadd
/*      */     //   2806: wide istore #276
/*      */     //   2810: aload #36
/*      */     //   2812: iconst_0
/*      */     //   2813: daload
/*      */     //   2814: wide dstore #273
/*      */     //   2818: wide aload #275
/*      */     //   2822: wide iload #276
/*      */     //   2826: wide dload #273
/*      */     //   2830: invokeinterface setDouble : (ID)V
/*      */     //   2835: iload #6
/*      */     //   2837: bipush #8
/*      */     //   2839: imul
/*      */     //   2840: wide istore #271
/*      */     //   2844: aload #7
/*      */     //   2846: wide astore #269
/*      */     //   2850: iload #8
/*      */     //   2852: wide iload #271
/*      */     //   2856: iadd
/*      */     //   2857: wide istore #270
/*      */     //   2861: wide aload #269
/*      */     //   2865: wide iload #270
/*      */     //   2869: dload #37
/*      */     //   2871: invokeinterface setDouble : (ID)V
/*      */     //   2876: iinc #6, 1
/*      */     //   2879: iload #6
/*      */     //   2881: bipush #8
/*      */     //   2883: imul
/*      */     //   2884: wide istore #267
/*      */     //   2888: aload #9
/*      */     //   2890: wide astore #265
/*      */     //   2894: iload #10
/*      */     //   2896: wide iload #267
/*      */     //   2900: iadd
/*      */     //   2901: wide istore #266
/*      */     //   2905: aload #36
/*      */     //   2907: iconst_0
/*      */     //   2908: daload
/*      */     //   2909: wide dstore #263
/*      */     //   2913: wide aload #265
/*      */     //   2917: wide iload #266
/*      */     //   2921: wide dload #263
/*      */     //   2925: invokeinterface setDouble : (ID)V
/*      */     //   2930: iload #6
/*      */     //   2932: bipush #8
/*      */     //   2934: imul
/*      */     //   2935: wide istore #261
/*      */     //   2939: aload #7
/*      */     //   2941: wide astore #259
/*      */     //   2945: iload #8
/*      */     //   2947: wide iload #261
/*      */     //   2951: iadd
/*      */     //   2952: wide istore #260
/*      */     //   2956: aload #35
/*      */     //   2958: iconst_0
/*      */     //   2959: daload
/*      */     //   2960: wide dstore #257
/*      */     //   2964: wide aload #259
/*      */     //   2968: wide iload #260
/*      */     //   2972: wide dload #257
/*      */     //   2976: invokeinterface setDouble : (ID)V
/*      */     //   2981: iinc #6, 1
/*      */     //   2984: goto -> 3079
/*      */     //   2987: dload #39
/*      */     //   2989: invokestatic R_finite : (D)I
/*      */     //   2992: ifne -> 2998
/*      */     //   2995: goto -> 3079
/*      */     //   2998: dload #37
/*      */     //   3000: invokestatic R_finite : (D)I
/*      */     //   3003: ifne -> 3009
/*      */     //   3006: goto -> 3079
/*      */     //   3009: aload #36
/*      */     //   3011: iconst_0
/*      */     //   3012: daload
/*      */     //   3013: invokestatic R_finite : (D)I
/*      */     //   3016: ifeq -> 3035
/*      */     //   3019: goto -> 3022
/*      */     //   3022: aload #35
/*      */     //   3024: iconst_0
/*      */     //   3025: daload
/*      */     //   3026: invokestatic R_finite : (D)I
/*      */     //   3029: ifeq -> 3035
/*      */     //   3032: goto -> 3079
/*      */     //   3035: iload #6
/*      */     //   3037: ifgt -> 3043
/*      */     //   3040: goto -> 3079
/*      */     //   3043: iload #6
/*      */     //   3045: aload #9
/*      */     //   3047: iload #10
/*      */     //   3049: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3054: aload #7
/*      */     //   3056: iload #8
/*      */     //   3058: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3063: iconst_0
/*      */     //   3064: aload #15
/*      */     //   3066: iload #16
/*      */     //   3068: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3073: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3076: iconst_0
/*      */     //   3077: istore #6
/*      */     //   3079: aload #36
/*      */     //   3081: iconst_0
/*      */     //   3082: daload
/*      */     //   3083: dstore #39
/*      */     //   3085: aload #35
/*      */     //   3087: iconst_0
/*      */     //   3088: daload
/*      */     //   3089: dstore #37
/*      */     //   3091: iinc #30, 1
/*      */     //   3094: iload #30
/*      */     //   3096: iload #29
/*      */     //   3098: if_icmplt -> 2500
/*      */     //   3101: goto -> 3104
/*      */     //   3104: iload #6
/*      */     //   3106: ifgt -> 3112
/*      */     //   3109: goto -> 3145
/*      */     //   3112: iload #6
/*      */     //   3114: aload #9
/*      */     //   3116: iload #10
/*      */     //   3118: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3123: aload #7
/*      */     //   3125: iload #8
/*      */     //   3127: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3132: iconst_0
/*      */     //   3133: aload #15
/*      */     //   3135: iload #16
/*      */     //   3137: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3142: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3145: iload #29
/*      */     //   3147: sipush #1000
/*      */     //   3150: if_icmpgt -> 3156
/*      */     //   3153: goto -> 3156
/*      */     //   3156: goto -> 4207
/*      */     //   3159: iconst_0
/*      */     //   3160: istore_1
/*      */     //   3161: iload #29
/*      */     //   3163: sipush #999
/*      */     //   3166: if_icmple -> 3172
/*      */     //   3169: goto -> 3206
/*      */     //   3172: iload #29
/*      */     //   3174: bipush #32
/*      */     //   3176: imul
/*      */     //   3177: istore #247
/*      */     //   3179: iload #29
/*      */     //   3181: bipush #16
/*      */     //   3183: imul
/*      */     //   3184: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3187: astore #4
/*      */     //   3189: iconst_0
/*      */     //   3190: istore #5
/*      */     //   3192: iload #29
/*      */     //   3194: bipush #16
/*      */     //   3196: imul
/*      */     //   3197: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3200: astore_2
/*      */     //   3201: iconst_0
/*      */     //   3202: istore_3
/*      */     //   3203: goto -> 3241
/*      */     //   3206: invokestatic vmaxget : ()Ljava/lang/Object;
/*      */     //   3209: invokestatic toPtr : (Ljava/lang/Object;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3212: astore #17
/*      */     //   3214: iconst_0
/*      */     //   3215: istore #18
/*      */     //   3217: iload #29
/*      */     //   3219: bipush #16
/*      */     //   3221: imul
/*      */     //   3222: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3225: astore #4
/*      */     //   3227: iconst_0
/*      */     //   3228: istore #5
/*      */     //   3230: iload #29
/*      */     //   3232: bipush #16
/*      */     //   3234: imul
/*      */     //   3235: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3238: astore_2
/*      */     //   3239: iconst_0
/*      */     //   3240: istore_3
/*      */     //   3241: aload #15
/*      */     //   3243: iload #16
/*      */     //   3245: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3250: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3253: astore #237
/*      */     //   3255: aload #48
/*      */     //   3257: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3260: invokeinterface getInt : ()I
/*      */     //   3265: istore #233
/*      */     //   3267: aload #237
/*      */     //   3269: bipush #44
/*      */     //   3271: iload #233
/*      */     //   3273: invokeinterface setInt : (II)V
/*      */     //   3278: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   3281: dstore #39
/*      */     //   3283: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   3286: dstore #37
/*      */     //   3288: iconst_0
/*      */     //   3289: istore #30
/*      */     //   3291: goto -> 3754
/*      */     //   3294: iload #30
/*      */     //   3296: bipush #8
/*      */     //   3298: imul
/*      */     //   3299: istore #231
/*      */     //   3301: aload #43
/*      */     //   3303: astore #229
/*      */     //   3305: iload #44
/*      */     //   3307: iload #231
/*      */     //   3309: iadd
/*      */     //   3310: istore #230
/*      */     //   3312: aload #229
/*      */     //   3314: iload #230
/*      */     //   3316: invokeinterface getDouble : (I)D
/*      */     //   3321: dstore #227
/*      */     //   3323: aload #36
/*      */     //   3325: iconst_0
/*      */     //   3326: dload #227
/*      */     //   3328: dastore
/*      */     //   3329: iload #30
/*      */     //   3331: bipush #8
/*      */     //   3333: imul
/*      */     //   3334: istore #225
/*      */     //   3336: aload #41
/*      */     //   3338: astore #223
/*      */     //   3340: iload #42
/*      */     //   3342: iload #225
/*      */     //   3344: iadd
/*      */     //   3345: istore #224
/*      */     //   3347: aload #223
/*      */     //   3349: iload #224
/*      */     //   3351: invokeinterface getDouble : (I)D
/*      */     //   3356: dstore #221
/*      */     //   3358: aload #35
/*      */     //   3360: iconst_0
/*      */     //   3361: dload #221
/*      */     //   3363: dastore
/*      */     //   3364: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3367: dup
/*      */     //   3368: aload #36
/*      */     //   3370: iconst_0
/*      */     //   3371: invokespecial <init> : ([DI)V
/*      */     //   3374: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3377: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3380: dup
/*      */     //   3381: aload #35
/*      */     //   3383: iconst_0
/*      */     //   3384: invokespecial <init> : ([DI)V
/*      */     //   3387: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3390: bipush #12
/*      */     //   3392: iconst_0
/*      */     //   3393: aload #15
/*      */     //   3395: iload #16
/*      */     //   3397: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3402: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3405: aload #36
/*      */     //   3407: iconst_0
/*      */     //   3408: daload
/*      */     //   3409: invokestatic R_finite : (D)I
/*      */     //   3412: ifne -> 3418
/*      */     //   3415: goto -> 3652
/*      */     //   3418: aload #35
/*      */     //   3420: iconst_0
/*      */     //   3421: daload
/*      */     //   3422: invokestatic R_finite : (D)I
/*      */     //   3425: ifne -> 3431
/*      */     //   3428: goto -> 3652
/*      */     //   3431: dload #39
/*      */     //   3433: invokestatic R_finite : (D)I
/*      */     //   3436: ifne -> 3442
/*      */     //   3439: goto -> 3652
/*      */     //   3442: dload #37
/*      */     //   3444: invokestatic R_finite : (D)I
/*      */     //   3447: ifne -> 3453
/*      */     //   3450: goto -> 3652
/*      */     //   3453: iload_1
/*      */     //   3454: ifeq -> 3460
/*      */     //   3457: goto -> 3517
/*      */     //   3460: iload_1
/*      */     //   3461: bipush #8
/*      */     //   3463: imul
/*      */     //   3464: istore #211
/*      */     //   3466: aload #4
/*      */     //   3468: astore #209
/*      */     //   3470: iload #5
/*      */     //   3472: iload #211
/*      */     //   3474: iadd
/*      */     //   3475: istore #210
/*      */     //   3477: aload #209
/*      */     //   3479: iload #210
/*      */     //   3481: dload #39
/*      */     //   3483: invokeinterface setDouble : (ID)V
/*      */     //   3488: iload_1
/*      */     //   3489: bipush #8
/*      */     //   3491: imul
/*      */     //   3492: istore #207
/*      */     //   3494: aload_2
/*      */     //   3495: astore #205
/*      */     //   3497: iload_3
/*      */     //   3498: iload #207
/*      */     //   3500: iadd
/*      */     //   3501: istore #206
/*      */     //   3503: aload #205
/*      */     //   3505: iload #206
/*      */     //   3507: dload #37
/*      */     //   3509: invokeinterface setDouble : (ID)V
/*      */     //   3514: iinc #1, 1
/*      */     //   3517: iload_1
/*      */     //   3518: bipush #8
/*      */     //   3520: imul
/*      */     //   3521: istore #203
/*      */     //   3523: aload #4
/*      */     //   3525: astore #201
/*      */     //   3527: iload #5
/*      */     //   3529: iload #203
/*      */     //   3531: iadd
/*      */     //   3532: istore #202
/*      */     //   3534: aload #201
/*      */     //   3536: iload #202
/*      */     //   3538: dload #39
/*      */     //   3540: invokeinterface setDouble : (ID)V
/*      */     //   3545: iload_1
/*      */     //   3546: bipush #8
/*      */     //   3548: imul
/*      */     //   3549: istore #199
/*      */     //   3551: aload_2
/*      */     //   3552: astore #197
/*      */     //   3554: iload_3
/*      */     //   3555: iload #199
/*      */     //   3557: iadd
/*      */     //   3558: istore #198
/*      */     //   3560: aload #35
/*      */     //   3562: iconst_0
/*      */     //   3563: daload
/*      */     //   3564: dstore #195
/*      */     //   3566: aload #197
/*      */     //   3568: iload #198
/*      */     //   3570: dload #195
/*      */     //   3572: invokeinterface setDouble : (ID)V
/*      */     //   3577: iinc #1, 1
/*      */     //   3580: iload_1
/*      */     //   3581: bipush #8
/*      */     //   3583: imul
/*      */     //   3584: istore #193
/*      */     //   3586: aload #4
/*      */     //   3588: astore #191
/*      */     //   3590: iload #5
/*      */     //   3592: iload #193
/*      */     //   3594: iadd
/*      */     //   3595: istore #192
/*      */     //   3597: aload #36
/*      */     //   3599: iconst_0
/*      */     //   3600: daload
/*      */     //   3601: dstore #189
/*      */     //   3603: aload #191
/*      */     //   3605: iload #192
/*      */     //   3607: dload #189
/*      */     //   3609: invokeinterface setDouble : (ID)V
/*      */     //   3614: iload_1
/*      */     //   3615: bipush #8
/*      */     //   3617: imul
/*      */     //   3618: istore #187
/*      */     //   3620: aload_2
/*      */     //   3621: astore #185
/*      */     //   3623: iload_3
/*      */     //   3624: iload #187
/*      */     //   3626: iadd
/*      */     //   3627: istore #186
/*      */     //   3629: aload #35
/*      */     //   3631: iconst_0
/*      */     //   3632: daload
/*      */     //   3633: dstore #183
/*      */     //   3635: aload #185
/*      */     //   3637: iload #186
/*      */     //   3639: dload #183
/*      */     //   3641: invokeinterface setDouble : (ID)V
/*      */     //   3646: iinc #1, 1
/*      */     //   3649: goto -> 3739
/*      */     //   3652: dload #39
/*      */     //   3654: invokestatic R_finite : (D)I
/*      */     //   3657: ifne -> 3663
/*      */     //   3660: goto -> 3739
/*      */     //   3663: dload #37
/*      */     //   3665: invokestatic R_finite : (D)I
/*      */     //   3668: ifne -> 3674
/*      */     //   3671: goto -> 3739
/*      */     //   3674: aload #36
/*      */     //   3676: iconst_0
/*      */     //   3677: daload
/*      */     //   3678: invokestatic R_finite : (D)I
/*      */     //   3681: ifeq -> 3700
/*      */     //   3684: goto -> 3687
/*      */     //   3687: aload #35
/*      */     //   3689: iconst_0
/*      */     //   3690: daload
/*      */     //   3691: invokestatic R_finite : (D)I
/*      */     //   3694: ifeq -> 3700
/*      */     //   3697: goto -> 3739
/*      */     //   3700: iload_1
/*      */     //   3701: ifgt -> 3707
/*      */     //   3704: goto -> 3739
/*      */     //   3707: iload_1
/*      */     //   3708: aload #4
/*      */     //   3710: iload #5
/*      */     //   3712: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3717: aload_2
/*      */     //   3718: iload_3
/*      */     //   3719: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3724: iconst_0
/*      */     //   3725: aload #15
/*      */     //   3727: iload #16
/*      */     //   3729: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3734: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3737: iconst_0
/*      */     //   3738: istore_1
/*      */     //   3739: aload #36
/*      */     //   3741: iconst_0
/*      */     //   3742: daload
/*      */     //   3743: dstore #39
/*      */     //   3745: aload #35
/*      */     //   3747: iconst_0
/*      */     //   3748: daload
/*      */     //   3749: dstore #37
/*      */     //   3751: iinc #30, 1
/*      */     //   3754: iload #30
/*      */     //   3756: iload #29
/*      */     //   3758: if_icmplt -> 3294
/*      */     //   3761: goto -> 3764
/*      */     //   3764: iload_1
/*      */     //   3765: ifgt -> 3771
/*      */     //   3768: goto -> 3801
/*      */     //   3771: iload_1
/*      */     //   3772: aload #4
/*      */     //   3774: iload #5
/*      */     //   3776: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3781: aload_2
/*      */     //   3782: iload_3
/*      */     //   3783: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3788: iconst_0
/*      */     //   3789: aload #15
/*      */     //   3791: iload #16
/*      */     //   3793: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3798: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3801: iload #29
/*      */     //   3803: sipush #1000
/*      */     //   3806: if_icmpgt -> 3812
/*      */     //   3809: goto -> 3812
/*      */     //   3812: goto -> 4207
/*      */     //   3815: aload #15
/*      */     //   3817: iload #16
/*      */     //   3819: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3824: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3827: sipush #480
/*      */     //   3830: invokeinterface getInt : (I)I
/*      */     //   3835: ifne -> 3841
/*      */     //   3838: goto -> 3871
/*      */     //   3841: aload #15
/*      */     //   3843: iload #16
/*      */     //   3845: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3850: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3853: iconst_0
/*      */     //   3854: ldc_w 35700
/*      */     //   3857: iadd
/*      */     //   3858: bipush #16
/*      */     //   3860: iadd
/*      */     //   3861: invokeinterface getDouble : (I)D
/*      */     //   3866: dstore #37
/*      */     //   3868: goto -> 3874
/*      */     //   3871: dconst_0
/*      */     //   3872: dstore #37
/*      */     //   3874: dload #37
/*      */     //   3876: bipush #12
/*      */     //   3878: iconst_0
/*      */     //   3879: aload #15
/*      */     //   3881: iload #16
/*      */     //   3883: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3888: invokestatic Rf_GConvertY : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3891: dstore #37
/*      */     //   3893: iconst_0
/*      */     //   3894: istore #30
/*      */     //   3896: goto -> 4143
/*      */     //   3899: iload #30
/*      */     //   3901: bipush #8
/*      */     //   3903: imul
/*      */     //   3904: istore #168
/*      */     //   3906: aload #43
/*      */     //   3908: astore #166
/*      */     //   3910: iload #44
/*      */     //   3912: iload #168
/*      */     //   3914: iadd
/*      */     //   3915: istore #167
/*      */     //   3917: aload #166
/*      */     //   3919: iload #167
/*      */     //   3921: invokeinterface getDouble : (I)D
/*      */     //   3926: dstore #164
/*      */     //   3928: aload #36
/*      */     //   3930: iconst_0
/*      */     //   3931: dload #164
/*      */     //   3933: dastore
/*      */     //   3934: iload #30
/*      */     //   3936: bipush #8
/*      */     //   3938: imul
/*      */     //   3939: istore #162
/*      */     //   3941: aload #41
/*      */     //   3943: astore #160
/*      */     //   3945: iload #42
/*      */     //   3947: iload #162
/*      */     //   3949: iadd
/*      */     //   3950: istore #161
/*      */     //   3952: aload #160
/*      */     //   3954: iload #161
/*      */     //   3956: invokeinterface getDouble : (I)D
/*      */     //   3961: dstore #158
/*      */     //   3963: aload #35
/*      */     //   3965: iconst_0
/*      */     //   3966: dload #158
/*      */     //   3968: dastore
/*      */     //   3969: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3972: dup
/*      */     //   3973: aload #36
/*      */     //   3975: iconst_0
/*      */     //   3976: invokespecial <init> : ([DI)V
/*      */     //   3979: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3982: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3985: dup
/*      */     //   3986: aload #35
/*      */     //   3988: iconst_0
/*      */     //   3989: invokespecial <init> : ([DI)V
/*      */     //   3992: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3995: bipush #12
/*      */     //   3997: iconst_0
/*      */     //   3998: aload #15
/*      */     //   4000: iload #16
/*      */     //   4002: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4007: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4010: aload #36
/*      */     //   4012: iconst_0
/*      */     //   4013: daload
/*      */     //   4014: invokestatic R_finite : (D)I
/*      */     //   4017: ifne -> 4023
/*      */     //   4020: goto -> 4140
/*      */     //   4023: aload #35
/*      */     //   4025: iconst_0
/*      */     //   4026: daload
/*      */     //   4027: invokestatic R_finite : (D)I
/*      */     //   4030: ifne -> 4036
/*      */     //   4033: goto -> 4140
/*      */     //   4036: aload #48
/*      */     //   4038: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4041: astore #150
/*      */     //   4043: iload #30
/*      */     //   4045: iload #26
/*      */     //   4047: irem
/*      */     //   4048: iconst_4
/*      */     //   4049: imul
/*      */     //   4050: istore #147
/*      */     //   4052: aload #150
/*      */     //   4054: astore #145
/*      */     //   4056: iconst_0
/*      */     //   4057: iload #147
/*      */     //   4059: iadd
/*      */     //   4060: istore #146
/*      */     //   4062: aload #145
/*      */     //   4064: iload #146
/*      */     //   4066: invokeinterface getInt : (I)I
/*      */     //   4071: istore #20
/*      */     //   4073: iload #20
/*      */     //   4075: bipush #24
/*      */     //   4077: iushr
/*      */     //   4078: ifne -> 4084
/*      */     //   4081: goto -> 4140
/*      */     //   4084: aload #15
/*      */     //   4086: iload #16
/*      */     //   4088: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4093: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4096: bipush #44
/*      */     //   4098: iload #20
/*      */     //   4100: invokeinterface setInt : (II)V
/*      */     //   4105: aload #35
/*      */     //   4107: iconst_0
/*      */     //   4108: daload
/*      */     //   4109: dstore #139
/*      */     //   4111: aload #36
/*      */     //   4113: iconst_0
/*      */     //   4114: daload
/*      */     //   4115: dstore #137
/*      */     //   4117: aload #36
/*      */     //   4119: iconst_0
/*      */     //   4120: daload
/*      */     //   4121: dload #37
/*      */     //   4123: dload #137
/*      */     //   4125: dload #139
/*      */     //   4127: iconst_0
/*      */     //   4128: aload #15
/*      */     //   4130: iload #16
/*      */     //   4132: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4137: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4140: iinc #30, 1
/*      */     //   4143: iload #30
/*      */     //   4145: iload #29
/*      */     //   4147: if_icmplt -> 3899
/*      */     //   4150: goto -> 4153
/*      */     //   4153: goto -> 4207
/*      */     //   4156: goto -> 4207
/*      */     //   4159: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4162: dup
/*      */     //   4163: ldc 'graphics '
/*      */     //   4165: invokevirtual getBytes : ()[B
/*      */     //   4168: iconst_0
/*      */     //   4169: invokespecial <init> : ([BI)V
/*      */     //   4172: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4175: dup
/*      */     //   4176: ldc_w 'invalid plot type '%c' '
/*      */     //   4179: invokevirtual getBytes : ()[B
/*      */     //   4182: iconst_0
/*      */     //   4183: invokespecial <init> : ([BI)V
/*      */     //   4186: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   4189: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   4192: iconst_1
/*      */     //   4193: anewarray java/lang/Object
/*      */     //   4196: dup
/*      */     //   4197: iconst_0
/*      */     //   4198: iload #23
/*      */     //   4200: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   4203: aastore
/*      */     //   4204: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   4207: iload #23
/*      */     //   4209: bipush #112
/*      */     //   4211: if_icmpeq -> 4237
/*      */     //   4214: goto -> 4217
/*      */     //   4217: iload #23
/*      */     //   4219: bipush #98
/*      */     //   4221: if_icmpeq -> 4237
/*      */     //   4224: goto -> 4227
/*      */     //   4227: iload #23
/*      */     //   4229: bipush #111
/*      */     //   4231: if_icmpeq -> 4237
/*      */     //   4234: goto -> 4789
/*      */     //   4237: iconst_0
/*      */     //   4238: istore #30
/*      */     //   4240: goto -> 4779
/*      */     //   4243: iload #30
/*      */     //   4245: bipush #8
/*      */     //   4247: imul
/*      */     //   4248: istore #131
/*      */     //   4250: aload #43
/*      */     //   4252: astore #129
/*      */     //   4254: iload #44
/*      */     //   4256: iload #131
/*      */     //   4258: iadd
/*      */     //   4259: istore #130
/*      */     //   4261: aload #129
/*      */     //   4263: iload #130
/*      */     //   4265: invokeinterface getDouble : (I)D
/*      */     //   4270: dstore #127
/*      */     //   4272: aload #36
/*      */     //   4274: iconst_0
/*      */     //   4275: dload #127
/*      */     //   4277: dastore
/*      */     //   4278: iload #30
/*      */     //   4280: bipush #8
/*      */     //   4282: imul
/*      */     //   4283: istore #125
/*      */     //   4285: aload #41
/*      */     //   4287: astore #123
/*      */     //   4289: iload #42
/*      */     //   4291: iload #125
/*      */     //   4293: iadd
/*      */     //   4294: istore #124
/*      */     //   4296: aload #123
/*      */     //   4298: iload #124
/*      */     //   4300: invokeinterface getDouble : (I)D
/*      */     //   4305: dstore #121
/*      */     //   4307: aload #35
/*      */     //   4309: iconst_0
/*      */     //   4310: dload #121
/*      */     //   4312: dastore
/*      */     //   4313: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   4316: dup
/*      */     //   4317: aload #36
/*      */     //   4319: iconst_0
/*      */     //   4320: invokespecial <init> : ([DI)V
/*      */     //   4323: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4326: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   4329: dup
/*      */     //   4330: aload #35
/*      */     //   4332: iconst_0
/*      */     //   4333: invokespecial <init> : ([DI)V
/*      */     //   4336: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4339: bipush #12
/*      */     //   4341: iconst_0
/*      */     //   4342: aload #15
/*      */     //   4344: iload #16
/*      */     //   4346: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4351: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4354: aload #36
/*      */     //   4356: iconst_0
/*      */     //   4357: daload
/*      */     //   4358: invokestatic R_finite : (D)I
/*      */     //   4361: ifne -> 4367
/*      */     //   4364: goto -> 4776
/*      */     //   4367: aload #35
/*      */     //   4369: iconst_0
/*      */     //   4370: daload
/*      */     //   4371: invokestatic R_finite : (D)I
/*      */     //   4374: ifne -> 4380
/*      */     //   4377: goto -> 4776
/*      */     //   4380: aload #49
/*      */     //   4382: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4385: astore #113
/*      */     //   4387: iload #30
/*      */     //   4389: iload #27
/*      */     //   4391: irem
/*      */     //   4392: bipush #8
/*      */     //   4394: imul
/*      */     //   4395: istore #110
/*      */     //   4397: aload #113
/*      */     //   4399: astore #108
/*      */     //   4401: iconst_0
/*      */     //   4402: iload #110
/*      */     //   4404: iadd
/*      */     //   4405: istore #109
/*      */     //   4407: aload #108
/*      */     //   4409: iload #109
/*      */     //   4411: invokeinterface getDouble : (I)D
/*      */     //   4416: dstore #33
/*      */     //   4418: dload #33
/*      */     //   4420: invokestatic R_finite : (D)I
/*      */     //   4423: ifne -> 4429
/*      */     //   4426: goto -> 4776
/*      */     //   4429: aload #50
/*      */     //   4431: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4434: astore #105
/*      */     //   4436: iload #30
/*      */     //   4438: iload #28
/*      */     //   4440: irem
/*      */     //   4441: iconst_4
/*      */     //   4442: imul
/*      */     //   4443: istore #102
/*      */     //   4445: aload #105
/*      */     //   4447: astore #100
/*      */     //   4449: iconst_0
/*      */     //   4450: iload #102
/*      */     //   4452: iadd
/*      */     //   4453: istore #101
/*      */     //   4455: aload #100
/*      */     //   4457: iload #101
/*      */     //   4459: invokeinterface getInt : (I)I
/*      */     //   4464: istore #21
/*      */     //   4466: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   4469: istore #99
/*      */     //   4471: iload #21
/*      */     //   4473: iload #99
/*      */     //   4475: if_icmpne -> 4481
/*      */     //   4478: goto -> 4776
/*      */     //   4481: aload #48
/*      */     //   4483: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4486: astore #97
/*      */     //   4488: iload #30
/*      */     //   4490: iload #26
/*      */     //   4492: irem
/*      */     //   4493: iconst_4
/*      */     //   4494: imul
/*      */     //   4495: istore #94
/*      */     //   4497: aload #97
/*      */     //   4499: astore #92
/*      */     //   4501: iconst_0
/*      */     //   4502: iload #94
/*      */     //   4504: iadd
/*      */     //   4505: istore #93
/*      */     //   4507: aload #92
/*      */     //   4509: iload #93
/*      */     //   4511: invokeinterface getInt : (I)I
/*      */     //   4516: istore #20
/*      */     //   4518: aload #47
/*      */     //   4520: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4523: astore #89
/*      */     //   4525: iload #30
/*      */     //   4527: iload #25
/*      */     //   4529: irem
/*      */     //   4530: iconst_4
/*      */     //   4531: imul
/*      */     //   4532: istore #86
/*      */     //   4534: aload #89
/*      */     //   4536: astore #84
/*      */     //   4538: iconst_0
/*      */     //   4539: iload #86
/*      */     //   4541: iadd
/*      */     //   4542: istore #85
/*      */     //   4544: aload #84
/*      */     //   4546: iload #85
/*      */     //   4548: invokeinterface getInt : (I)I
/*      */     //   4553: istore #19
/*      */     //   4555: iload #20
/*      */     //   4557: bipush #24
/*      */     //   4559: iushr
/*      */     //   4560: ifne -> 4577
/*      */     //   4563: goto -> 4566
/*      */     //   4566: iload #19
/*      */     //   4568: bipush #24
/*      */     //   4570: iushr
/*      */     //   4571: ifne -> 4577
/*      */     //   4574: goto -> 4776
/*      */     //   4577: aload #15
/*      */     //   4579: iload #16
/*      */     //   4581: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4586: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4589: astore #79
/*      */     //   4591: aload #15
/*      */     //   4593: iload #16
/*      */     //   4595: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4600: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4603: sipush #484
/*      */     //   4606: invokeinterface getDouble : (I)D
/*      */     //   4611: dload #33
/*      */     //   4613: dmul
/*      */     //   4614: dstore #73
/*      */     //   4616: aload #79
/*      */     //   4618: bipush #28
/*      */     //   4620: dload #73
/*      */     //   4622: invokeinterface setDouble : (ID)V
/*      */     //   4627: aload #15
/*      */     //   4629: iload #16
/*      */     //   4631: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4636: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4639: bipush #44
/*      */     //   4641: iload #20
/*      */     //   4643: invokeinterface setInt : (II)V
/*      */     //   4648: iload #24
/*      */     //   4650: iconst_1
/*      */     //   4651: if_icmpgt -> 4657
/*      */     //   4654: goto -> 4728
/*      */     //   4657: aload #45
/*      */     //   4659: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4662: astore #69
/*      */     //   4664: iload #30
/*      */     //   4666: iload #24
/*      */     //   4668: irem
/*      */     //   4669: bipush #8
/*      */     //   4671: imul
/*      */     //   4672: istore #66
/*      */     //   4674: aload #69
/*      */     //   4676: astore #64
/*      */     //   4678: iconst_0
/*      */     //   4679: iload #66
/*      */     //   4681: iadd
/*      */     //   4682: istore #65
/*      */     //   4684: aload #64
/*      */     //   4686: iload #65
/*      */     //   4688: invokeinterface getDouble : (I)D
/*      */     //   4693: dstore #31
/*      */     //   4695: dload #31
/*      */     //   4697: invokestatic R_finite : (D)I
/*      */     //   4700: ifne -> 4706
/*      */     //   4703: goto -> 4728
/*      */     //   4706: aload #15
/*      */     //   4708: iload #16
/*      */     //   4710: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4715: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4718: sipush #316
/*      */     //   4721: dload #31
/*      */     //   4723: invokeinterface setDouble : (ID)V
/*      */     //   4728: aload #15
/*      */     //   4730: iload #16
/*      */     //   4732: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4737: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4740: bipush #20
/*      */     //   4742: iload #19
/*      */     //   4744: invokeinterface setInt : (II)V
/*      */     //   4749: aload #35
/*      */     //   4751: iconst_0
/*      */     //   4752: daload
/*      */     //   4753: dstore #57
/*      */     //   4755: aload #36
/*      */     //   4757: iconst_0
/*      */     //   4758: daload
/*      */     //   4759: dload #57
/*      */     //   4761: iconst_0
/*      */     //   4762: iload #21
/*      */     //   4764: aload #15
/*      */     //   4766: iload #16
/*      */     //   4768: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4773: invokestatic Rf_GSymbol : (DDIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4776: iinc #30, 1
/*      */     //   4779: iload #30
/*      */     //   4781: iload #29
/*      */     //   4783: if_icmplt -> 4243
/*      */     //   4786: goto -> 4789
/*      */     //   4789: iconst_0
/*      */     //   4790: aload #15
/*      */     //   4792: iload #16
/*      */     //   4794: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4799: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4802: aload #15
/*      */     //   4804: iload #16
/*      */     //   4806: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4811: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4814: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   4817: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1288	-> 185
/*      */     //   #1290	-> 191
/*      */     //   #1292	-> 200
/*      */     //   #1295	-> 208
/*      */     //   #1296	-> 220
/*      */     //   #1297	-> 225
/*      */     //   #1298	-> 237
/*      */     //   #1320	-> 276
/*      */     //   #1320	-> 303
/*      */     //   #1320	-> 315
/*      */     //   #1320	-> 348
/*      */     //   #1320	-> 359
/*      */     //   #1320	-> 371
/*      */     //   #1320	-> 402
/*      */     //   #1320	-> 442
/*      */     //   #1320	-> 474
/*      */     //   #1320	-> 531
/*      */     //   #1322	-> 543
/*      */     //   #1322	-> 556
/*      */     //   #1324	-> 563
/*      */     //   #1324	-> 578
/*      */     //   #1325	-> 592
/*      */     //   #1324	-> 596
/*      */     //   #1325	-> 602
/*      */     //   #1324	-> 607
/*      */     //   #1326	-> 613
/*      */     //   #1327	-> 625
/*      */     //   #1329	-> 681
/*      */     //   #1331	-> 696
/*      */     //   #1333	-> 736
/*      */     //   #1335	-> 741
/*      */     //   #1336	-> 784
/*      */     //   #1337	-> 791
/*      */     //   #1339	-> 796
/*      */     //   #1340	-> 839
/*      */     //   #1350	-> 844
/*      */     //   #1351	-> 865
/*      */     //   #1353	-> 872
/*      */     //   #1354	-> 894
/*      */     //   #1356	-> 901
/*      */     //   #1357	-> 922
/*      */     //   #1359	-> 929
/*      */     //   #1360	-> 977
/*      */     //   #1363	-> 984
/*      */     //   #1364	-> 996
/*      */     //   #1366	-> 1009
/*      */     //   #1367	-> 1019
/*      */     //   #1369	-> 1029
/*      */     //   #1370	-> 1064
/*      */     //   #1371	-> 1110
/*      */     //   #1372	-> 1133
/*      */     //   #1374	-> 1155
/*      */     //   #1377	-> 1168
/*      */     //   #1381	-> 1252
/*      */     //   #1382	-> 1297
/*      */     //   #1383	-> 1302
/*      */     //   #1384	-> 1307
/*      */     //   #1385	-> 1313
/*      */     //   #1386	-> 1364
/*      */     //   #1388	-> 1415
/*      */     //   #1389	-> 1456
/*      */     //   #1389	-> 1469
/*      */     //   #1390	-> 1482
/*      */     //   #1389	-> 1487
/*      */     //   #1390	-> 1493
/*      */     //   #1391	-> 1504
/*      */     //   #1392	-> 1511
/*      */     //   #1392	-> 1522
/*      */     //   #1393	-> 1533
/*      */     //   #1392	-> 1540
/*      */     //   #1393	-> 1546
/*      */     //   #1394	-> 1559
/*      */     //   #1395	-> 1571
/*      */     //   #1397	-> 1671
/*      */     //   #1397	-> 1682
/*      */     //   #1397	-> 1693
/*      */     //   #1398	-> 1705
/*      */     //   #1399	-> 1802
/*      */     //   #1400	-> 1808
/*      */     //   #1384	-> 1814
/*      */     //   #1384	-> 1817
/*      */     //   #1408	-> 1830
/*      */     //   #1409	-> 1851
/*      */     //   #1410	-> 1896
/*      */     //   #1411	-> 1901
/*      */     //   #1412	-> 1906
/*      */     //   #1413	-> 1912
/*      */     //   #1414	-> 1963
/*      */     //   #1415	-> 2014
/*      */     //   #1416	-> 2056
/*      */     //   #1416	-> 2067
/*      */     //   #1417	-> 2078
/*      */     //   #1416	-> 2085
/*      */     //   #1417	-> 2091
/*      */     //   #1419	-> 2104
/*      */     //   #1420	-> 2142
/*      */     //   #1424	-> 2180
/*      */     //   #1421	-> 2202
/*      */     //   #1423	-> 2223
/*      */     //   #1421	-> 2245
/*      */     //   #1422	-> 2266
/*      */     //   #1421	-> 2276
/*      */     //   #1428	-> 2322
/*      */     //   #1429	-> 2328
/*      */     //   #1412	-> 2334
/*      */     //   #1412	-> 2337
/*      */     //   #1437	-> 2350
/*      */     //   #1438	-> 2353
/*      */     //   #1439	-> 2364
/*      */     //   #1440	-> 2373
/*      */     //   #1441	-> 2386
/*      */     //   #1443	-> 2402
/*      */     //   #1444	-> 2413
/*      */     //   #1445	-> 2426
/*      */     //   #1447	-> 2439
/*      */     //   #1448	-> 2484
/*      */     //   #1449	-> 2489
/*      */     //   #1450	-> 2494
/*      */     //   #1451	-> 2500
/*      */     //   #1452	-> 2551
/*      */     //   #1453	-> 2602
/*      */     //   #1454	-> 2643
/*      */     //   #1454	-> 2656
/*      */     //   #1455	-> 2669
/*      */     //   #1454	-> 2674
/*      */     //   #1455	-> 2680
/*      */     //   #1456	-> 2691
/*      */     //   #1456	-> 2699
/*      */     //   #1457	-> 2784
/*      */     //   #1458	-> 2879
/*      */     //   #1459	-> 2987
/*      */     //   #1459	-> 2998
/*      */     //   #1460	-> 3009
/*      */     //   #1459	-> 3016
/*      */     //   #1460	-> 3022
/*      */     //   #1460	-> 3035
/*      */     //   #1461	-> 3043
/*      */     //   #1462	-> 3076
/*      */     //   #1464	-> 3079
/*      */     //   #1465	-> 3085
/*      */     //   #1450	-> 3091
/*      */     //   #1450	-> 3094
/*      */     //   #1467	-> 3104
/*      */     //   #1467	-> 3112
/*      */     //   #1468	-> 3145
/*      */     //   #1468	-> 3156
/*      */     //   #1475	-> 3159
/*      */     //   #1476	-> 3161
/*      */     //   #1477	-> 3172
/*      */     //   #1478	-> 3179
/*      */     //   #1479	-> 3192
/*      */     //   #1481	-> 3206
/*      */     //   #1482	-> 3217
/*      */     //   #1483	-> 3230
/*      */     //   #1485	-> 3241
/*      */     //   #1486	-> 3278
/*      */     //   #1487	-> 3283
/*      */     //   #1488	-> 3288
/*      */     //   #1489	-> 3294
/*      */     //   #1490	-> 3329
/*      */     //   #1491	-> 3364
/*      */     //   #1492	-> 3405
/*      */     //   #1492	-> 3418
/*      */     //   #1493	-> 3431
/*      */     //   #1492	-> 3436
/*      */     //   #1493	-> 3442
/*      */     //   #1494	-> 3453
/*      */     //   #1494	-> 3460
/*      */     //   #1495	-> 3517
/*      */     //   #1496	-> 3580
/*      */     //   #1497	-> 3652
/*      */     //   #1497	-> 3663
/*      */     //   #1498	-> 3674
/*      */     //   #1497	-> 3681
/*      */     //   #1498	-> 3687
/*      */     //   #1498	-> 3700
/*      */     //   #1499	-> 3707
/*      */     //   #1500	-> 3737
/*      */     //   #1502	-> 3739
/*      */     //   #1503	-> 3745
/*      */     //   #1488	-> 3751
/*      */     //   #1488	-> 3754
/*      */     //   #1505	-> 3764
/*      */     //   #1505	-> 3771
/*      */     //   #1506	-> 3801
/*      */     //   #1506	-> 3812
/*      */     //   #1511	-> 3815
/*      */     //   #1512	-> 3841
/*      */     //   #1514	-> 3871
/*      */     //   #1515	-> 3874
/*      */     //   #1516	-> 3893
/*      */     //   #1517	-> 3899
/*      */     //   #1518	-> 3934
/*      */     //   #1519	-> 3969
/*      */     //   #1520	-> 4010
/*      */     //   #1520	-> 4023
/*      */     //   #1521	-> 4036
/*      */     //   #1522	-> 4084
/*      */     //   #1523	-> 4105
/*      */     //   #1516	-> 4140
/*      */     //   #1516	-> 4143
/*      */     //   #1533	-> 4159
/*      */     //   #1538	-> 4207
/*      */     //   #1538	-> 4217
/*      */     //   #1538	-> 4227
/*      */     //   #1539	-> 4237
/*      */     //   #1540	-> 4243
/*      */     //   #1541	-> 4278
/*      */     //   #1542	-> 4313
/*      */     //   #1543	-> 4354
/*      */     //   #1543	-> 4367
/*      */     //   #1544	-> 4380
/*      */     //   #1545	-> 4429
/*      */     //   #1544	-> 4471
/*      */     //   #1547	-> 4481
/*      */     //   #1548	-> 4518
/*      */     //   #1549	-> 4555
/*      */     //   #1550	-> 4566
/*      */     //   #1549	-> 4571
/*      */     //   #1551	-> 4577
/*      */     //   #1552	-> 4627
/*      */     //   #1553	-> 4648
/*      */     //   #1554	-> 4657
/*      */     //   #1553	-> 4700
/*      */     //   #1555	-> 4706
/*      */     //   #1556	-> 4728
/*      */     //   #1557	-> 4749
/*      */     //   #1539	-> 4776
/*      */     //   #1539	-> 4779
/*      */     //   #1563	-> 4789
/*      */     //   #1564	-> 4802
/*      */     //   #1565	-> 4814
/*      */     //   #1566	-> 4814
/*      */     //   #0	-> 4817
/*      */     //   #1566	-> 4817
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	4818	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	1	n0	I
/*      */     //   0	4818	2	ytemp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	3	ytemp$offset	I
/*      */     //   0	4818	4	xtemp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	5	xtemp$offset	I
/*      */     //   0	4818	6	n0	I
/*      */     //   0	4818	7	ytemp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	8	ytemp$offset	I
/*      */     //   0	4818	9	xtemp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	10	xtemp$offset	I
/*      */     //   0	4818	11	f	D
/*      */     //   0	4818	13	d	D
/*      */     //   0	4818	15	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	16	dd$offset	I
/*      */     //   0	4818	17	vmax	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	18	vmax$offset	I
/*      */     //   0	4818	19	thisbg	I
/*      */     //   0	4818	20	thiscol	I
/*      */     //   0	4818	21	thispch	I
/*      */     //   0	4818	22	start	I
/*      */     //   0	4818	23	type	I
/*      */     //   0	4818	24	nlwd	I
/*      */     //   0	4818	25	nbg	I
/*      */     //   0	4818	26	ncol	I
/*      */     //   0	4818	27	ncex	I
/*      */     //   0	4818	28	npch	I
/*      */     //   0	4818	29	n	I
/*      */     //   0	4818	30	i	I
/*      */     //   0	4818	31	thislwd	D
/*      */     //   0	4818	33	thiscex	D
/*      */     //   0	4818	35	yy	[D
/*      */     //   0	4818	36	xx	[D
/*      */     //   0	4818	37	yold	D
/*      */     //   0	4818	39	xold	D
/*      */     //   0	4818	41	y	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	42	y$offset	I
/*      */     //   0	4818	43	x	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	4818	44	x$offset	I
/*      */     //   0	4818	45	lwd	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	46	lty	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	47	bg	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	48	col	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	49	cex	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	50	pch	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	51	sy	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	52	sx	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	53	sxy	Lorg/renjin/sexp/SEXP;
/*      */     //   0	4818	55	xx$656	D
/*      */     //   0	4818	57	yy$655	D
/*      */     //   0	4818	99	R_NaInt$654	I
/*      */     //   0	4818	116	yy$653	D
/*      */     //   0	4818	119	xx$652	D
/*      */     //   0	4818	121	yy$651	D
/*      */     //   0	4818	126	i$650	I
/*      */     //   0	4818	127	xx$649	D
/*      */     //   0	4818	132	i$648	I
/*      */     //   0	4818	135	xx$647	D
/*      */     //   0	4818	137	xx$646	D
/*      */     //   0	4818	139	yy$645	D
/*      */     //   0	4818	153	yy$644	D
/*      */     //   0	4818	156	xx$643	D
/*      */     //   0	4818	158	yy$642	D
/*      */     //   0	4818	163	i$641	I
/*      */     //   0	4818	164	xx$640	D
/*      */     //   0	4818	169	i$639	I
/*      */     //   0	4818	176	yy$638	D
/*      */     //   0	4818	179	xx$637	D
/*      */     //   0	4818	183	yy$636	D
/*      */     //   0	4818	188	n0$635	I
/*      */     //   0	4818	189	xx$634	D
/*      */     //   0	4818	194	n0$633	I
/*      */     //   0	4818	195	yy$632	D
/*      */     //   0	4818	200	n0$631	I
/*      */     //   0	4818	204	n0$630	I
/*      */     //   0	4818	208	n0$629	I
/*      */     //   0	4818	212	n0$628	I
/*      */     //   0	4818	216	yy$627	D
/*      */     //   0	4818	219	xx$626	D
/*      */     //   0	4818	221	yy$625	D
/*      */     //   0	4818	226	i$624	I
/*      */     //   0	4818	227	xx$623	D
/*      */     //   0	4818	232	i$622	I
/*      */     //   0	4818	250	yy$621	D
/*      */     //   0	4818	253	xx$620	D
/*      */     //   0	4818	257	yy$619	D
/*      */     //   0	4818	262	n0$618	I
/*      */     //   0	4818	263	xx$617	D
/*      */     //   0	4818	268	n0$616	I
/*      */     //   0	4818	272	n0$615	I
/*      */     //   0	4818	273	xx$614	D
/*      */     //   0	4818	278	n0$613	I
/*      */     //   0	4818	282	n0$612	I
/*      */     //   0	4818	286	n0$611	I
/*      */     //   0	4818	290	yy$610	D
/*      */     //   0	4818	293	xx$609	D
/*      */     //   0	4818	295	yy$608	D
/*      */     //   0	4818	300	i$607	I
/*      */     //   0	4818	301	xx$606	D
/*      */     //   0	4818	306	i$605	I
/*      */     //   0	4818	329	xx$604	D
/*      */     //   0	4818	337	yy$603	D
/*      */     //   0	4818	341	xx$602	D
/*      */     //   0	4818	347	xx$601	D
/*      */     //   0	4818	351	yy$600	D
/*      */     //   0	4818	357	yy$599	D
/*      */     //   0	4818	363	xx$598	D
/*      */     //   0	4818	367	yy$597	D
/*      */     //   0	4818	375	xx$596	D
/*      */     //   0	4818	379	yy$595	D
/*      */     //   0	4818	382	yy$594	D
/*      */     //   0	4818	385	xx$593	D
/*      */     //   0	4818	389	yy$592	D
/*      */     //   0	4818	394	i$591	I
/*      */     //   0	4818	395	xx$590	D
/*      */     //   0	4818	400	i$589	I
/*      */     //   0	4818	411	start$588	I
/*      */     //   0	4818	415	start$587	I
/*      */     //   0	4818	423	start$586	I
/*      */     //   0	4818	427	start$585	I
/*      */     //   0	4818	430	yy$584	D
/*      */     //   0	4818	433	xx$583	D
/*      */     //   0	4818	440	yy$582	D
/*      */     //   0	4818	443	xx$581	D
/*      */     //   0	4818	445	yy$580	D
/*      */     //   0	4818	450	i$579	I
/*      */     //   0	4818	451	xx$578	D
/*      */     //   0	4818	456	i$577	I
/*      */     //   0	4818	473	R_NaInt$576	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void xypoints(SEXP args, Ptr n) {
/* 1573 */     k = 0;
/*      */     
/* 1575 */     if (!Rinternals.Rf_isNumeric(Rinternals.CAR(args)))
/* 1576 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid first argument\000".getBytes(), 0)), new Object[0]); 
/* 1577 */     SEXP sEXP4 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.SETCAR(args, sEXP4);
/* 1578 */     k = Rinternals.LENGTH(Rinternals.CAR(args));
/* 1579 */     n.setInt(k); kmin = k;
/* 1580 */     args = Rinternals.CDR(args);
/*      */     
/* 1582 */     if (!Rinternals.Rf_isNumeric(Rinternals.CAR(args)))
/* 1583 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid second argument\000".getBytes(), 0)), new Object[0]); 
/* 1584 */     k = Rinternals.LENGTH(Rinternals.CAR(args));
/* 1585 */     SEXP sEXP3 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.SETCAR(args, sEXP3);
/* 1586 */     if (n.getInt() < k) n.setInt(k); 
/* 1587 */     if (k < kmin) kmin = k; 
/* 1588 */     args = Rinternals.CDR(args);
/*      */     
/* 1590 */     if (!Rinternals.Rf_isNumeric(Rinternals.CAR(args)))
/* 1591 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid third argument\000".getBytes(), 0)), new Object[0]); 
/* 1592 */     SEXP sEXP2 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.SETCAR(args, sEXP2);
/* 1593 */     k = Rinternals.LENGTH(Rinternals.CAR(args));
/* 1594 */     if (n.getInt() < k) n.setInt(k); 
/* 1595 */     if (k < kmin) kmin = k; 
/* 1596 */     args = Rinternals.CDR(args);
/*      */     
/* 1598 */     if (!Rinternals.Rf_isNumeric(Rinternals.CAR(args)))
/* 1599 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid fourth argument\000".getBytes(), 0)), new Object[0]); 
/* 1600 */     SEXP sEXP1 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.SETCAR(args, sEXP1);
/* 1601 */     k = Rinternals.LENGTH(Rinternals.CAR(args));
/* 1602 */     if (n.getInt() < k) n.setInt(k); 
/* 1603 */     if (k < kmin) kmin = k; 
/* 1604 */     args = Rinternals.CDR(args);
/*      */     
/* 1606 */     if (n.getInt() > 0 && kmin == 0) {
/* 1607 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("cannot mix zero-length and non-zero-length coordinates\000".getBytes(), 0)), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_segments(SEXP args) {
/* 1618 */     n = new int[1]; yy = new double[2]; xx = new double[2]; dd = BytePtr.of(0); dd$offset = 0; nlwd = 0; nlty = 0; ncol = 0; n[0] = 0; ny1 = 0; ny0 = 0; nx1 = 0; nx0 = 0; y1 = BytePtr.of(0); y1$offset = 0; y0 = BytePtr.of(0); y0$offset = 0; x1 = BytePtr.of(0); x1$offset = 0; x0 = BytePtr.of(0); x0$offset = 0; lwd = (SEXP)BytePtr.of(0).getArray(); lty = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 1620 */     args = Rinternals.CDR(args);
/* 1621 */     if (Rinternals.Rf_length(args) <= 3) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]); 
/* 1622 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1624 */     xypoints(args, (Ptr)new IntPtr(n, 0));
/* 1625 */     if (n[0] != 0) {
/*      */       
/* 1627 */       sx0 = Rinternals.CAR(args); nx0 = Rinternals.Rf_length(sx0); args = Rinternals.CDR(args);
/* 1628 */       sy0 = Rinternals.CAR(args); ny0 = Rinternals.Rf_length(sy0); args = Rinternals.CDR(args);
/* 1629 */       sx1 = Rinternals.CAR(args); nx1 = Rinternals.Rf_length(sx1); args = Rinternals.CDR(args);
/* 1630 */       sy1 = Rinternals.CAR(args); ny1 = Rinternals.Rf_length(sy1); args = Rinternals.CDR(args);
/*      */       
/* 1632 */       col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col);
/* 1633 */       ncol = Rinternals.LENGTH(col); args = Rinternals.CDR(args);
/*      */       
/* 1635 */       int j = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); lty = Rf_FixupLty(Rinternals.CAR(args), j); Rinternals.Rf_protect(lty);
/* 1636 */       nlty = Rinternals.Rf_length(lty); args = Rinternals.CDR(args);
/*      */       
/* 1638 */       double d = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(316); lwd = Rf_FixupLwd(Rinternals.CAR(args), d); Rinternals.Rf_protect(lwd);
/* 1639 */       nlwd = Rinternals.Rf_length(lwd); args = Rinternals.CDR(args);
/*      */       
/* 1641 */       graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 1642 */       par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */       
/* 1644 */       x0 = Rinternals2.REAL(sx0); x0$offset = 0;
/* 1645 */       y0 = Rinternals2.REAL(sy0); y0$offset = 0;
/* 1646 */       x1 = Rinternals2.REAL(sx1); x1$offset = 0;
/* 1647 */       y1 = Rinternals2.REAL(sy1); y1$offset = 0;
/*      */       
/* 1649 */       graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/* 1650 */       i = 0; while (true) { n$575 = n[0]; if (i >= n$575)
/* 1651 */           break;  int i6 = i % nx0 * 8; Ptr ptr4 = x0; int i5 = x0$offset + i6; double d4 = ptr4.getDouble(i5); xx[0] = d4;
/* 1652 */         int i4 = i % ny0 * 8; Ptr ptr3 = y0; int i3 = y0$offset + i4; double d3 = ptr3.getDouble(i3); yy[0] = d3;
/* 1653 */         int i2 = i % nx1 * 8; Ptr ptr2 = x1; int i1 = x1$offset + i2; double d2 = ptr2.getDouble(i1); xx[1] = d2;
/* 1654 */         int m = i % ny1 * 8; Ptr ptr1 = y1; int k = y1$offset + m; double d1 = ptr1.getDouble(k); yy[1] = d1;
/* 1655 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 1656 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(xx, 1), (Ptr)new DoublePtr(yy, 1), 12, 0, dd.pointerPlus(dd$offset));
/* 1657 */         if (Arith.R_finite(xx[0]) != 0 && Arith.R_finite(yy[0]) != 0 && 
/* 1658 */           Arith.R_finite(xx[1]) != 0 && Arith.R_finite(yy[1]) != 0) {
/*      */           
/* 1660 */           Ptr ptr6 = Rinternals2.INTEGER(col); int i8 = i % ncol * 4; Ptr ptr5 = ptr6; int i7 = 0 + i8; thiscol = ptr5.getInt(i7);
/* 1661 */           if (thiscol >>> 24 != 0) {
/* 1662 */             Ptr ptr13 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); thiscol$574 = thiscol; ptr13.setInt(44, thiscol$574);
/* 1663 */             Ptr ptr12 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr11 = Rinternals2.INTEGER(lty); int i13 = i % nlty * 4; Ptr ptr10 = ptr11; int i12 = 0 + i13, i11 = ptr10.getInt(i12); ptr12.setInt(312, i11);
/* 1664 */             Ptr ptr9 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr8 = Rinternals2.REAL(lwd); int i10 = i % nlwd * 8; Ptr ptr7 = ptr8; int i9 = 0 + i10; double d8 = ptr7.getDouble(i9); ptr9.setDouble(316, d8);
/* 1665 */             double d7 = yy[1], d6 = xx[1], d5 = yy[0]; graphics__.Rf_GLine(xx[0], d5, d6, d7, 0, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         }  i++; }
/*      */       
/* 1669 */       graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/* 1670 */       graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */ 
/*      */       
/* 1673 */       return Rinternals.R_NilValue;
/*      */     } 
/*      */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_rect(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray int
/*      */     //   3: astore #11
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #13
/*      */     //   10: iconst_1
/*      */     //   11: newarray double
/*      */     //   13: astore #14
/*      */     //   15: iconst_1
/*      */     //   16: newarray double
/*      */     //   18: astore #15
/*      */     //   20: iconst_1
/*      */     //   21: newarray double
/*      */     //   23: astore #16
/*      */     //   25: iconst_0
/*      */     //   26: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   29: astore_1
/*      */     //   30: iconst_0
/*      */     //   31: istore_2
/*      */     //   32: iconst_0
/*      */     //   33: istore_3
/*      */     //   34: iconst_0
/*      */     //   35: istore #4
/*      */     //   37: iconst_0
/*      */     //   38: istore #5
/*      */     //   40: iconst_0
/*      */     //   41: istore #6
/*      */     //   43: iconst_0
/*      */     //   44: istore #7
/*      */     //   46: iconst_0
/*      */     //   47: istore #8
/*      */     //   49: iconst_0
/*      */     //   50: istore #9
/*      */     //   52: iconst_0
/*      */     //   53: istore #10
/*      */     //   55: aload #11
/*      */     //   57: iconst_0
/*      */     //   58: iconst_0
/*      */     //   59: iastore
/*      */     //   60: iconst_0
/*      */     //   61: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   64: astore #17
/*      */     //   66: iconst_0
/*      */     //   67: istore #18
/*      */     //   69: iconst_0
/*      */     //   70: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   73: astore #19
/*      */     //   75: iconst_0
/*      */     //   76: istore #20
/*      */     //   78: iconst_0
/*      */     //   79: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   82: astore #21
/*      */     //   84: iconst_0
/*      */     //   85: istore #22
/*      */     //   87: iconst_0
/*      */     //   88: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   91: astore #23
/*      */     //   93: iconst_0
/*      */     //   94: istore #24
/*      */     //   96: iconst_0
/*      */     //   97: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   100: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   105: checkcast org/renjin/sexp/SEXP
/*      */     //   108: astore #25
/*      */     //   110: iconst_0
/*      */     //   111: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   114: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   119: checkcast org/renjin/sexp/SEXP
/*      */     //   122: astore #26
/*      */     //   124: iconst_0
/*      */     //   125: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   128: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   133: checkcast org/renjin/sexp/SEXP
/*      */     //   136: astore #27
/*      */     //   138: iconst_0
/*      */     //   139: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   142: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   147: checkcast org/renjin/sexp/SEXP
/*      */     //   150: astore #28
/*      */     //   152: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   155: astore_1
/*      */     //   156: iconst_0
/*      */     //   157: istore_2
/*      */     //   158: aload_0
/*      */     //   159: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   162: astore_0
/*      */     //   163: aload_0
/*      */     //   164: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   167: iconst_3
/*      */     //   168: if_icmple -> 174
/*      */     //   171: goto -> 213
/*      */     //   174: new org/renjin/gcc/runtime/BytePtr
/*      */     //   177: dup
/*      */     //   178: ldc 'graphics '
/*      */     //   180: invokevirtual getBytes : ()[B
/*      */     //   183: iconst_0
/*      */     //   184: invokespecial <init> : ([BI)V
/*      */     //   187: new org/renjin/gcc/runtime/BytePtr
/*      */     //   190: dup
/*      */     //   191: ldc 'too few arguments '
/*      */     //   193: invokevirtual getBytes : ()[B
/*      */     //   196: iconst_0
/*      */     //   197: invokespecial <init> : ([BI)V
/*      */     //   200: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   203: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   206: iconst_0
/*      */     //   207: anewarray java/lang/Object
/*      */     //   210: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   213: aload_1
/*      */     //   214: iload_2
/*      */     //   215: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   220: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   223: aload_0
/*      */     //   224: new org/renjin/gcc/runtime/IntPtr
/*      */     //   227: dup
/*      */     //   228: aload #11
/*      */     //   230: iconst_0
/*      */     //   231: invokespecial <init> : ([II)V
/*      */     //   234: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   237: invokestatic xypoints : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   240: aload #11
/*      */     //   242: iconst_0
/*      */     //   243: iaload
/*      */     //   244: ifeq -> 250
/*      */     //   247: goto -> 258
/*      */     //   250: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   253: astore #164
/*      */     //   255: goto -> 1364
/*      */     //   258: aload_0
/*      */     //   259: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   262: astore #32
/*      */     //   264: aload #32
/*      */     //   266: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   269: istore #10
/*      */     //   271: aload_0
/*      */     //   272: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   275: astore_0
/*      */     //   276: aload_0
/*      */     //   277: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   280: astore #30
/*      */     //   282: aload #30
/*      */     //   284: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   287: istore #8
/*      */     //   289: aload_0
/*      */     //   290: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   293: astore_0
/*      */     //   294: aload_0
/*      */     //   295: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   298: astore #31
/*      */     //   300: aload #31
/*      */     //   302: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   305: istore #9
/*      */     //   307: aload_0
/*      */     //   308: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   311: astore_0
/*      */     //   312: aload_0
/*      */     //   313: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   316: astore #29
/*      */     //   318: aload #29
/*      */     //   320: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   323: istore #7
/*      */     //   325: aload_0
/*      */     //   326: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   329: astore_0
/*      */     //   330: aload_0
/*      */     //   331: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   334: ldc 16777215
/*      */     //   336: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   339: astore #28
/*      */     //   341: aload #28
/*      */     //   343: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   346: pop
/*      */     //   347: aload #28
/*      */     //   349: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   352: istore #6
/*      */     //   354: aload_0
/*      */     //   355: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   358: astore_0
/*      */     //   359: aload_1
/*      */     //   360: iload_2
/*      */     //   361: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   366: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   369: bipush #76
/*      */     //   371: invokeinterface getInt : (I)I
/*      */     //   376: istore #160
/*      */     //   378: aload_0
/*      */     //   379: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   382: iload #160
/*      */     //   384: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   387: astore #25
/*      */     //   389: aload #25
/*      */     //   391: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   394: pop
/*      */     //   395: aload #25
/*      */     //   397: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   400: istore_3
/*      */     //   401: aload_0
/*      */     //   402: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   405: astore_0
/*      */     //   406: aload_1
/*      */     //   407: iload_2
/*      */     //   408: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   413: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   416: sipush #312
/*      */     //   419: invokeinterface getInt : (I)I
/*      */     //   424: istore #156
/*      */     //   426: aload_0
/*      */     //   427: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   430: iload #156
/*      */     //   432: invokestatic Rf_FixupLty : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   435: astore #27
/*      */     //   437: aload #27
/*      */     //   439: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   442: pop
/*      */     //   443: aload #27
/*      */     //   445: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   448: istore #5
/*      */     //   450: aload_0
/*      */     //   451: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   454: astore_0
/*      */     //   455: aload_1
/*      */     //   456: iload_2
/*      */     //   457: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   462: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   465: sipush #316
/*      */     //   468: invokeinterface getDouble : (I)D
/*      */     //   473: dstore #151
/*      */     //   475: aload_0
/*      */     //   476: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   479: dload #151
/*      */     //   481: invokestatic Rf_FixupLwd : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   484: astore #26
/*      */     //   486: aload #26
/*      */     //   488: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   491: pop
/*      */     //   492: aload #26
/*      */     //   494: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   497: istore #4
/*      */     //   499: aload_0
/*      */     //   500: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   503: astore_0
/*      */     //   504: aload_1
/*      */     //   505: iload_2
/*      */     //   506: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   511: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   514: aload_0
/*      */     //   515: aload_1
/*      */     //   516: iload_2
/*      */     //   517: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   522: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   525: aload #32
/*      */     //   527: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   530: astore #23
/*      */     //   532: iconst_0
/*      */     //   533: istore #24
/*      */     //   535: aload #31
/*      */     //   537: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   540: astore #21
/*      */     //   542: iconst_0
/*      */     //   543: istore #22
/*      */     //   545: aload #30
/*      */     //   547: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   550: astore #19
/*      */     //   552: iconst_0
/*      */     //   553: istore #20
/*      */     //   555: aload #29
/*      */     //   557: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   560: astore #17
/*      */     //   562: iconst_0
/*      */     //   563: istore #18
/*      */     //   565: iconst_1
/*      */     //   566: aload_1
/*      */     //   567: iload_2
/*      */     //   568: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   573: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   576: iconst_0
/*      */     //   577: istore #12
/*      */     //   579: goto -> 1322
/*      */     //   582: iload #5
/*      */     //   584: ifne -> 590
/*      */     //   587: goto -> 706
/*      */     //   590: aload #27
/*      */     //   592: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   595: astore #148
/*      */     //   597: iload #12
/*      */     //   599: iload #5
/*      */     //   601: irem
/*      */     //   602: iconst_4
/*      */     //   603: imul
/*      */     //   604: istore #145
/*      */     //   606: aload #148
/*      */     //   608: astore #143
/*      */     //   610: iconst_0
/*      */     //   611: iload #145
/*      */     //   613: iadd
/*      */     //   614: istore #144
/*      */     //   616: aload #143
/*      */     //   618: iload #144
/*      */     //   620: invokeinterface getInt : (I)I
/*      */     //   625: istore #142
/*      */     //   627: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   630: istore #141
/*      */     //   632: iload #142
/*      */     //   634: iload #141
/*      */     //   636: if_icmpne -> 642
/*      */     //   639: goto -> 706
/*      */     //   642: aload_1
/*      */     //   643: iload_2
/*      */     //   644: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   649: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   652: astore #139
/*      */     //   654: aload #27
/*      */     //   656: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   659: astore #137
/*      */     //   661: iload #12
/*      */     //   663: iload #5
/*      */     //   665: irem
/*      */     //   666: iconst_4
/*      */     //   667: imul
/*      */     //   668: istore #134
/*      */     //   670: aload #137
/*      */     //   672: astore #132
/*      */     //   674: iconst_0
/*      */     //   675: iload #134
/*      */     //   677: iadd
/*      */     //   678: istore #133
/*      */     //   680: aload #132
/*      */     //   682: iload #133
/*      */     //   684: invokeinterface getInt : (I)I
/*      */     //   689: istore #131
/*      */     //   691: aload #139
/*      */     //   693: sipush #312
/*      */     //   696: iload #131
/*      */     //   698: invokeinterface setInt : (II)V
/*      */     //   703: goto -> 750
/*      */     //   706: aload_1
/*      */     //   707: iload_2
/*      */     //   708: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   713: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   716: astore #129
/*      */     //   718: aload_1
/*      */     //   719: iload_2
/*      */     //   720: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   725: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   728: sipush #312
/*      */     //   731: invokeinterface getInt : (I)I
/*      */     //   736: istore #126
/*      */     //   738: aload #129
/*      */     //   740: sipush #312
/*      */     //   743: iload #126
/*      */     //   745: invokeinterface setInt : (II)V
/*      */     //   750: iload #4
/*      */     //   752: ifne -> 758
/*      */     //   755: goto -> 877
/*      */     //   758: aload #26
/*      */     //   760: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   763: astore #124
/*      */     //   765: iload #12
/*      */     //   767: iload #4
/*      */     //   769: irem
/*      */     //   770: bipush #8
/*      */     //   772: imul
/*      */     //   773: istore #121
/*      */     //   775: aload #124
/*      */     //   777: astore #119
/*      */     //   779: iconst_0
/*      */     //   780: iload #121
/*      */     //   782: iadd
/*      */     //   783: istore #120
/*      */     //   785: aload #119
/*      */     //   787: iload #120
/*      */     //   789: invokeinterface getDouble : (I)D
/*      */     //   794: dstore #117
/*      */     //   796: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   799: dstore #115
/*      */     //   801: dload #117
/*      */     //   803: dload #115
/*      */     //   805: dcmpl
/*      */     //   806: ifne -> 812
/*      */     //   809: goto -> 877
/*      */     //   812: aload_1
/*      */     //   813: iload_2
/*      */     //   814: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   819: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   822: astore #113
/*      */     //   824: aload #26
/*      */     //   826: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   829: astore #111
/*      */     //   831: iload #12
/*      */     //   833: iload #4
/*      */     //   835: irem
/*      */     //   836: bipush #8
/*      */     //   838: imul
/*      */     //   839: istore #108
/*      */     //   841: aload #111
/*      */     //   843: astore #106
/*      */     //   845: iconst_0
/*      */     //   846: iload #108
/*      */     //   848: iadd
/*      */     //   849: istore #107
/*      */     //   851: aload #106
/*      */     //   853: iload #107
/*      */     //   855: invokeinterface getDouble : (I)D
/*      */     //   860: dstore #104
/*      */     //   862: aload #113
/*      */     //   864: sipush #316
/*      */     //   867: dload #104
/*      */     //   869: invokeinterface setDouble : (ID)V
/*      */     //   874: goto -> 921
/*      */     //   877: aload_1
/*      */     //   878: iload_2
/*      */     //   879: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   884: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   887: astore #102
/*      */     //   889: aload_1
/*      */     //   890: iload_2
/*      */     //   891: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   896: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   899: sipush #316
/*      */     //   902: invokeinterface getDouble : (I)D
/*      */     //   907: dstore #98
/*      */     //   909: aload #102
/*      */     //   911: sipush #316
/*      */     //   914: dload #98
/*      */     //   916: invokeinterface setDouble : (ID)V
/*      */     //   921: iload #12
/*      */     //   923: iload #10
/*      */     //   925: irem
/*      */     //   926: bipush #8
/*      */     //   928: imul
/*      */     //   929: istore #95
/*      */     //   931: aload #23
/*      */     //   933: astore #93
/*      */     //   935: iload #24
/*      */     //   937: iload #95
/*      */     //   939: iadd
/*      */     //   940: istore #94
/*      */     //   942: aload #93
/*      */     //   944: iload #94
/*      */     //   946: invokeinterface getDouble : (I)D
/*      */     //   951: dstore #91
/*      */     //   953: aload #16
/*      */     //   955: iconst_0
/*      */     //   956: dload #91
/*      */     //   958: dastore
/*      */     //   959: iload #12
/*      */     //   961: iload #8
/*      */     //   963: irem
/*      */     //   964: bipush #8
/*      */     //   966: imul
/*      */     //   967: istore #88
/*      */     //   969: aload #19
/*      */     //   971: astore #86
/*      */     //   973: iload #20
/*      */     //   975: iload #88
/*      */     //   977: iadd
/*      */     //   978: istore #87
/*      */     //   980: aload #86
/*      */     //   982: iload #87
/*      */     //   984: invokeinterface getDouble : (I)D
/*      */     //   989: dstore #84
/*      */     //   991: aload #15
/*      */     //   993: iconst_0
/*      */     //   994: dload #84
/*      */     //   996: dastore
/*      */     //   997: iload #12
/*      */     //   999: iload #9
/*      */     //   1001: irem
/*      */     //   1002: bipush #8
/*      */     //   1004: imul
/*      */     //   1005: istore #81
/*      */     //   1007: aload #21
/*      */     //   1009: astore #79
/*      */     //   1011: iload #22
/*      */     //   1013: iload #81
/*      */     //   1015: iadd
/*      */     //   1016: istore #80
/*      */     //   1018: aload #79
/*      */     //   1020: iload #80
/*      */     //   1022: invokeinterface getDouble : (I)D
/*      */     //   1027: dstore #77
/*      */     //   1029: aload #14
/*      */     //   1031: iconst_0
/*      */     //   1032: dload #77
/*      */     //   1034: dastore
/*      */     //   1035: iload #12
/*      */     //   1037: iload #7
/*      */     //   1039: irem
/*      */     //   1040: bipush #8
/*      */     //   1042: imul
/*      */     //   1043: istore #74
/*      */     //   1045: aload #17
/*      */     //   1047: astore #72
/*      */     //   1049: iload #18
/*      */     //   1051: iload #74
/*      */     //   1053: iadd
/*      */     //   1054: istore #73
/*      */     //   1056: aload #72
/*      */     //   1058: iload #73
/*      */     //   1060: invokeinterface getDouble : (I)D
/*      */     //   1065: dstore #70
/*      */     //   1067: aload #13
/*      */     //   1069: iconst_0
/*      */     //   1070: dload #70
/*      */     //   1072: dastore
/*      */     //   1073: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1076: dup
/*      */     //   1077: aload #16
/*      */     //   1079: iconst_0
/*      */     //   1080: invokespecial <init> : ([DI)V
/*      */     //   1083: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1086: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1089: dup
/*      */     //   1090: aload #15
/*      */     //   1092: iconst_0
/*      */     //   1093: invokespecial <init> : ([DI)V
/*      */     //   1096: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1099: bipush #12
/*      */     //   1101: iconst_0
/*      */     //   1102: aload_1
/*      */     //   1103: iload_2
/*      */     //   1104: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1109: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1112: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1115: dup
/*      */     //   1116: aload #14
/*      */     //   1118: iconst_0
/*      */     //   1119: invokespecial <init> : ([DI)V
/*      */     //   1122: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1125: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1128: dup
/*      */     //   1129: aload #13
/*      */     //   1131: iconst_0
/*      */     //   1132: invokespecial <init> : ([DI)V
/*      */     //   1135: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1138: bipush #12
/*      */     //   1140: iconst_0
/*      */     //   1141: aload_1
/*      */     //   1142: iload_2
/*      */     //   1143: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1148: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1151: aload #16
/*      */     //   1153: iconst_0
/*      */     //   1154: daload
/*      */     //   1155: invokestatic R_finite : (D)I
/*      */     //   1158: ifne -> 1164
/*      */     //   1161: goto -> 1319
/*      */     //   1164: aload #15
/*      */     //   1166: iconst_0
/*      */     //   1167: daload
/*      */     //   1168: invokestatic R_finite : (D)I
/*      */     //   1171: ifne -> 1177
/*      */     //   1174: goto -> 1319
/*      */     //   1177: aload #14
/*      */     //   1179: iconst_0
/*      */     //   1180: daload
/*      */     //   1181: invokestatic R_finite : (D)I
/*      */     //   1184: ifne -> 1190
/*      */     //   1187: goto -> 1319
/*      */     //   1190: aload #13
/*      */     //   1192: iconst_0
/*      */     //   1193: daload
/*      */     //   1194: invokestatic R_finite : (D)I
/*      */     //   1197: ifne -> 1203
/*      */     //   1200: goto -> 1319
/*      */     //   1203: aload #25
/*      */     //   1205: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1208: astore #56
/*      */     //   1210: iload #12
/*      */     //   1212: iload_3
/*      */     //   1213: irem
/*      */     //   1214: iconst_4
/*      */     //   1215: imul
/*      */     //   1216: istore #53
/*      */     //   1218: aload #56
/*      */     //   1220: astore #51
/*      */     //   1222: iconst_0
/*      */     //   1223: iload #53
/*      */     //   1225: iadd
/*      */     //   1226: istore #52
/*      */     //   1228: aload #51
/*      */     //   1230: iload #52
/*      */     //   1232: invokeinterface getInt : (I)I
/*      */     //   1237: istore #50
/*      */     //   1239: aload #28
/*      */     //   1241: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1244: astore #48
/*      */     //   1246: iload #12
/*      */     //   1248: iload #6
/*      */     //   1250: irem
/*      */     //   1251: iconst_4
/*      */     //   1252: imul
/*      */     //   1253: istore #45
/*      */     //   1255: aload #48
/*      */     //   1257: astore #43
/*      */     //   1259: iconst_0
/*      */     //   1260: iload #45
/*      */     //   1262: iadd
/*      */     //   1263: istore #44
/*      */     //   1265: aload #43
/*      */     //   1267: iload #44
/*      */     //   1269: invokeinterface getInt : (I)I
/*      */     //   1274: istore #42
/*      */     //   1276: aload #13
/*      */     //   1278: iconst_0
/*      */     //   1279: daload
/*      */     //   1280: dstore #40
/*      */     //   1282: aload #14
/*      */     //   1284: iconst_0
/*      */     //   1285: daload
/*      */     //   1286: dstore #38
/*      */     //   1288: aload #15
/*      */     //   1290: iconst_0
/*      */     //   1291: daload
/*      */     //   1292: dstore #36
/*      */     //   1294: aload #16
/*      */     //   1296: iconst_0
/*      */     //   1297: daload
/*      */     //   1298: dload #36
/*      */     //   1300: dload #38
/*      */     //   1302: dload #40
/*      */     //   1304: iconst_0
/*      */     //   1305: iload #42
/*      */     //   1307: iload #50
/*      */     //   1309: aload_1
/*      */     //   1310: iload_2
/*      */     //   1311: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1316: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1319: iinc #12, 1
/*      */     //   1322: aload #11
/*      */     //   1324: iconst_0
/*      */     //   1325: iaload
/*      */     //   1326: istore #33
/*      */     //   1328: iload #12
/*      */     //   1330: iload #33
/*      */     //   1332: if_icmplt -> 582
/*      */     //   1335: goto -> 1338
/*      */     //   1338: iconst_0
/*      */     //   1339: aload_1
/*      */     //   1340: iload_2
/*      */     //   1341: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1346: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1349: aload_1
/*      */     //   1350: iload_2
/*      */     //   1351: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1356: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1359: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   1362: astore #164
/*      */     //   1364: aload #164
/*      */     //   1366: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1683	-> 152
/*      */     //   #1685	-> 158
/*      */     //   #1686	-> 163
/*      */     //   #1686	-> 174
/*      */     //   #1687	-> 213
/*      */     //   #1689	-> 223
/*      */     //   #1690	-> 240
/*      */     //   #1690	-> 250
/*      */     //   #1692	-> 258
/*      */     //   #1693	-> 276
/*      */     //   #1694	-> 294
/*      */     //   #1695	-> 312
/*      */     //   #1697	-> 330
/*      */     //   #1698	-> 347
/*      */     //   #1699	-> 354
/*      */     //   #1701	-> 359
/*      */     //   #1702	-> 395
/*      */     //   #1703	-> 401
/*      */     //   #1705	-> 406
/*      */     //   #1706	-> 443
/*      */     //   #1707	-> 450
/*      */     //   #1709	-> 455
/*      */     //   #1710	-> 492
/*      */     //   #1711	-> 499
/*      */     //   #1713	-> 504
/*      */     //   #1714	-> 514
/*      */     //   #1716	-> 525
/*      */     //   #1717	-> 535
/*      */     //   #1718	-> 545
/*      */     //   #1719	-> 555
/*      */     //   #1721	-> 565
/*      */     //   #1722	-> 576
/*      */     //   #1723	-> 582
/*      */     //   #1723	-> 590
/*      */     //   #1724	-> 642
/*      */     //   #1726	-> 706
/*      */     //   #1727	-> 750
/*      */     //   #1727	-> 758
/*      */     //   #1728	-> 812
/*      */     //   #1730	-> 877
/*      */     //   #1731	-> 921
/*      */     //   #1732	-> 959
/*      */     //   #1733	-> 997
/*      */     //   #1734	-> 1035
/*      */     //   #1735	-> 1073
/*      */     //   #1736	-> 1112
/*      */     //   #1737	-> 1151
/*      */     //   #1737	-> 1164
/*      */     //   #1737	-> 1177
/*      */     //   #1737	-> 1190
/*      */     //   #1739	-> 1203
/*      */     //   #1738	-> 1228
/*      */     //   #1722	-> 1319
/*      */     //   #1722	-> 1322
/*      */     //   #1741	-> 1338
/*      */     //   #1743	-> 1349
/*      */     //   #1744	-> 1359
/*      */     //   #1745	-> 1359
/*      */     //   #0	-> 1364
/*      */     //   #0	-> 1364
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1367	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	1	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1367	2	dd$offset	I
/*      */     //   0	1367	3	nborder	I
/*      */     //   0	1367	4	nlwd	I
/*      */     //   0	1367	5	nlty	I
/*      */     //   0	1367	6	ncol	I
/*      */     //   0	1367	7	nyt	I
/*      */     //   0	1367	8	nyb	I
/*      */     //   0	1367	9	nxr	I
/*      */     //   0	1367	10	nxl	I
/*      */     //   0	1367	11	n	[I
/*      */     //   0	1367	12	i	I
/*      */     //   0	1367	13	y1	[D
/*      */     //   0	1367	14	x1	[D
/*      */     //   0	1367	15	y0	[D
/*      */     //   0	1367	16	x0	[D
/*      */     //   0	1367	17	yt	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1367	18	yt$offset	I
/*      */     //   0	1367	19	yb	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1367	20	yb$offset	I
/*      */     //   0	1367	21	xr	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1367	22	xr$offset	I
/*      */     //   0	1367	23	xl	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1367	24	xl$offset	I
/*      */     //   0	1367	25	border	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	26	lwd	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	27	lty	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	28	col	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	29	syt	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	30	syb	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	31	sxr	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	32	sxl	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1367	33	n$571	I
/*      */     //   0	1367	34	x0$570	D
/*      */     //   0	1367	36	y0$569	D
/*      */     //   0	1367	38	x1$568	D
/*      */     //   0	1367	40	y1$567	D
/*      */     //   0	1367	59	y1$566	D
/*      */     //   0	1367	62	x1$565	D
/*      */     //   0	1367	65	y0$564	D
/*      */     //   0	1367	68	x0$563	D
/*      */     //   0	1367	70	y1$562	D
/*      */     //   0	1367	77	x1$561	D
/*      */     //   0	1367	84	y0$560	D
/*      */     //   0	1367	91	x0$559	D
/*      */     //   0	1367	115	R_NaReal$558	D
/*      */     //   0	1367	141	R_NaInt$557	I
/*      */     //   0	1367	165	n$556	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_path(SEXP args) {
/* 1754 */     dd = BytePtr.of(0); dd$offset = 0; vmax = BytePtr.of(0); vmax$offset = 0; yy = BytePtr.of(0); yy$offset = 0; xx = BytePtr.of(0); xx$offset = 0; npoly = 0; nx = 0; lty = (SEXP)BytePtr.of(0).getArray(); border = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); rule = (SEXP)BytePtr.of(0).getArray(); nper = (SEXP)BytePtr.of(0).getArray(); sy = (SEXP)BytePtr.of(0).getArray(); sx = (SEXP)BytePtr.of(0).getArray(); vmax = BytePtr.of(0); vmax$offset = 0;
/*      */     
/* 1756 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 1758 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1760 */     args = Rinternals.CDR(args);
/* 1761 */     if (Rinternals.Rf_length(args) <= 1) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     
/* 1763 */     SEXP sEXP2 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sx = Rinternals.SETCAR(args, sEXP2); args = Rinternals.CDR(args);
/* 1764 */     SEXP sEXP1 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sy = Rinternals.SETCAR(args, sEXP1); args = Rinternals.CDR(args);
/* 1765 */     nx = Rinternals.LENGTH(sx);
/*      */     
/* 1767 */     nper = Rinternals.CAR(args); Rinternals.Rf_protect(nper); args = Rinternals.CDR(args);
/* 1768 */     npoly = Rinternals.LENGTH(nper);
/*      */     
/* 1770 */     rule = Rinternals.CAR(args); Rinternals.Rf_protect(rule); args = Rinternals.CDR(args);
/*      */     
/* 1772 */     col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col); args = Rinternals.CDR(args);
/* 1773 */     int i1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(76); border = Rf_FixupCol(Rinternals.CAR(args), i1); Rinternals.Rf_protect(border); args = Rinternals.CDR(args);
/* 1774 */     int n = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); lty = Rf_FixupLty(Rinternals.CAR(args), n); Rinternals.Rf_protect(lty); args = Rinternals.CDR(args);
/*      */     
/* 1776 */     graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 1777 */     par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */     
/* 1779 */     graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/*      */     
/* 1781 */     vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1787 */     DoublePtr doublePtr2 = DoublePtr.malloc(nx * 8); xx$offset = 0;
/* 1788 */     DoublePtr doublePtr1 = DoublePtr.malloc(nx * 8); yy$offset = 0;
/* 1789 */     if (doublePtr2.pointerPlus(xx$offset).isNull() || doublePtr1.pointerPlus(yy$offset).isNull())
/* 1790 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GPath)\000".getBytes(), 0), new Object[0]); 
/* 1791 */     for (i = 0; i < nx; i++) {
/* 1792 */       int i15 = i * 8; DoublePtr doublePtr7 = doublePtr2; int i14 = xx$offset + i15; Ptr ptr4 = Rinternals2.REAL(sx); int i13 = i * 8; Ptr ptr3 = ptr4; int i12 = 0 + i13; double d2 = ptr3.getDouble(i12); doublePtr7.setDouble(i14, d2);
/* 1793 */       int i11 = i * 8; DoublePtr doublePtr6 = doublePtr1; int i10 = yy$offset + i11; Ptr ptr2 = Rinternals2.REAL(sy); int i9 = i * 8; Ptr ptr1 = ptr2; int i8 = 0 + i9; double d1 = ptr1.getDouble(i8); doublePtr6.setDouble(i10, d1);
/* 1794 */       int i7 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i6 = yy$offset + i7, i5 = i * 8; DoublePtr doublePtr4 = doublePtr2; int i4 = xx$offset + i5; graphics__.Rf_GConvert(doublePtr4.pointerPlus(i4), doublePtr5.pointerPlus(i6), 12, 0, dd.pointerPlus(dd$offset));
/* 1795 */       int i3 = i * 8; DoublePtr doublePtr3 = doublePtr2; int i2 = xx$offset + i3; if (Arith.R_finite(doublePtr3.getDouble(i2)) != 0) { int i17 = i * 8; DoublePtr doublePtr = doublePtr1; int i16 = yy$offset + i17; if (Arith.R_finite(doublePtr.getDouble(i16)) != 0)
/* 1796 */           continue;  }  Error.Rf_error(new BytePtr("invalid 'x' or 'y' (in 'GPath')\000".getBytes(), 0), new Object[0]);
/*      */       continue;
/*      */     } 
/* 1799 */     int m = Rinternals2.INTEGER(lty).getInt(); R_NaInt$555 = Arith.R_NaInt; if (m != R_NaInt$555)
/*      */     
/*      */     { 
/* 1802 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int i2 = Rinternals2.INTEGER(lty).getInt(); ptr1.setInt(312, i2); }
/*      */     else { Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int i2 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)).getInt(312); ptr1.setInt(312, i2); }
/* 1804 */      int k = 
/* 1805 */       Rinternals2.INTEGER(border).getInt(), j = Rinternals2.INTEGER(col).getInt(); boolean bool = (Rinternals2.INTEGER(rule).getInt() != 1) ? false : true; Ptr ptr = Rinternals2.INTEGER(nper);
/*      */     graphics__.Rf_GPath(doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), npoly, ptr, bool, j, k, dd.pointerPlus(dd$offset));
/* 1807 */     graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */     
/* 1809 */     graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */     
/* 1813 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_raster(SEXP args) {
/* 1824 */     n = new int[1]; y1 = new double[1]; x1 = new double[1]; y0 = new double[1]; x0 = new double[1]; dd = BytePtr.of(0); dd$offset = 0; nyt = 0; nyb = 0; nxr = 0; nxl = 0; n[0] = 0; yt = BytePtr.of(0); yt$offset = 0; yb = BytePtr.of(0); yb$offset = 0; xr = BytePtr.of(0); xr$offset = 0; xl = BytePtr.of(0); xl$offset = 0; interpolate = (SEXP)BytePtr.of(0).getArray(); angle = (SEXP)BytePtr.of(0).getArray(); dim = (SEXP)BytePtr.of(0).getArray(); raster = (SEXP)BytePtr.of(0).getArray(); image = BytePtr.of(0); image$offset = 0; vmax = BytePtr.of(0); vmax$offset = 0; dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 1826 */     args = Rinternals.CDR(args);
/* 1827 */     if (Rinternals.Rf_length(args) <= 6) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]); 
/* 1828 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1830 */     raster = Rinternals.CAR(args); args = Rinternals.CDR(args);
/* 1831 */     n$522 = Rinternals.LENGTH(raster); n[0] = n$522;
/* 1832 */     if (n[0] <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("Empty raster\000".getBytes(), 0)), new Object[0]); 
/* 1833 */     R_DimSymbol$524 = Rinternals.R_DimSymbol; dim = Rinternals.Rf_getAttrib(raster, R_DimSymbol$524);
/*      */     
/* 1835 */     vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */ 
/*      */     
/* 1838 */     if (!Rinternals.Rf_inherits(raster, new BytePtr("nativeRaster\000".getBytes(), 0)) || !Rinternals.Rf_isInteger(raster))
/*      */     
/*      */     { 
/* 1841 */       IntPtr intPtr = IntPtr.malloc(n[0] * 4); image$offset = 0;
/* 1842 */       i = 0; while (true) { n$528 = n[0]; if (i >= n$528)
/* 1843 */           break;  int m = i * 4; IntPtr intPtr1 = intPtr; int k = image$offset + m, j = colors__.Rf_RGBpar3(raster, i, 16777215); intPtr1.setInt(k, j); i++; }
/*      */        }
/*      */     else { image = Rinternals2.INTEGER(raster); image$offset = 0; }
/* 1846 */      xypoints(args, (Ptr)new IntPtr(n, 0));
/* 1847 */     if (n[0] != 0) {
/*      */       
/* 1849 */       sxl = Rinternals.CAR(args); nxl = Rinternals.Rf_length(sxl); args = Rinternals.CDR(args);
/* 1850 */       syb = Rinternals.CAR(args); nyb = Rinternals.Rf_length(syb); args = Rinternals.CDR(args);
/* 1851 */       sxr = Rinternals.CAR(args); nxr = Rinternals.Rf_length(sxr); args = Rinternals.CDR(args);
/* 1852 */       syt = Rinternals.CAR(args); nyt = Rinternals.Rf_length(syt); args = Rinternals.CDR(args);
/*      */       
/* 1854 */       angle = Rinternals.CAR(args); args = Rinternals.CDR(args);
/* 1855 */       interpolate = Rinternals.CAR(args); args = Rinternals.CDR(args);
/*      */       
/* 1857 */       graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 1858 */       par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */       
/* 1860 */       xl = Rinternals2.REAL(sxl); xl$offset = 0;
/* 1861 */       xr = Rinternals2.REAL(sxr); xr$offset = 0;
/* 1862 */       yb = Rinternals2.REAL(syb); yb$offset = 0;
/* 1863 */       yt = Rinternals2.REAL(syt); yt$offset = 0;
/*      */       
/* 1865 */       graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/* 1866 */       i = 0; while (true) { n$544 = n[0]; if (i >= n$544)
/* 1867 */           break;  int i5 = i % nxl * 8; Ptr ptr4 = xl; int i4 = xl$offset + i5; x0$530 = ptr4.getDouble(i4); x0[0] = x0$530;
/* 1868 */         int i3 = i % nyb * 8; Ptr ptr3 = yb; int i2 = yb$offset + i3; y0$531 = ptr3.getDouble(i2); y0[0] = y0$531;
/* 1869 */         int i1 = i % nxr * 8; Ptr ptr2 = xr; int m = xr$offset + i1; x1$532 = ptr2.getDouble(m); x1[0] = x1$532;
/* 1870 */         int k = i % nyt * 8; Ptr ptr1 = yt; int j = yt$offset + k; y1$533 = ptr1.getDouble(j); y1[0] = y1$533;
/* 1871 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(x0, 0), (Ptr)new DoublePtr(y0, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 1872 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y1, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 1873 */         if (Arith.R_finite(x0[0]) != 0 && Arith.R_finite(y0[0]) != 0 && Arith.R_finite(x1[0]) != 0 && Arith.R_finite(y1[0]) != 0) {
/*      */ 
/*      */ 
/*      */           
/* 1877 */           IntPtr intPtr2 = Rinternals.LOGICAL(interpolate); int i14 = Rinternals.LENGTH(interpolate), i13 = i % i14 * 4; IntPtr intPtr1 = intPtr2; int i12 = 0 + i13; int i11 = intPtr1.getInt(i12); Ptr ptr6 = Rinternals2.REAL(angle); int i10 = Rinternals.LENGTH(angle), i9 = i % i10 * 8; Ptr ptr5 = ptr6; int i8 = 0 + i9; double d3 = ptr5.getDouble(i8); y1$538 = y1[0]; y0$539 = y0[0]; double d2 = y1$538 - y0$539; x1$540 = x1[0]; x0$541 = x0[0]; double d1 = x1$540 - x0$541; y0$542 = y0[0]; x0$543 = x0[0]; int i7 = Rinternals2.INTEGER(dim).getInt(), i6 = Rinternals2.INTEGER(dim).getInt(4); graphics__.Rf_GRaster(image.pointerPlus(image$offset), i6, i7, x0$543, y0$542, d1, d2, d3, i11, dd.pointerPlus(dd$offset));
/*      */         }  i++; }
/* 1879 */        graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */       
/* 1881 */       graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */ 
/*      */       
/* 1884 */       return Rinternals.R_NilValue;
/*      */     } 
/*      */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_arrows(SEXP args) {
/* 1898 */     n = new int[1]; yy1 = new double[1]; xx1 = new double[1]; yy0 = new double[1]; xx0 = new double[1]; dd = BytePtr.of(0); dd$offset = 0; nlwd = 0; nlty = 0; ncol = 0; n[0] = 0; ny1 = 0; ny0 = 0; nx1 = 0; nx0 = 0; code = 0; angle = 0.0D; hlength = 0.0D; y1 = BytePtr.of(0); y1$offset = 0; y0 = BytePtr.of(0); y0$offset = 0; x1 = BytePtr.of(0); x1$offset = 0; x0 = BytePtr.of(0); x0$offset = 0; lwd = (SEXP)BytePtr.of(0).getArray(); lty = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 1900 */     args = Rinternals.CDR(args);
/* 1901 */     if (Rinternals.Rf_length(args) <= 3) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]); 
/* 1902 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1904 */     xypoints(args, (Ptr)new IntPtr(n, 0));
/* 1905 */     if (n[0] != 0) {
/*      */       
/* 1907 */       sx0 = Rinternals.CAR(args); nx0 = Rinternals.Rf_length(sx0); args = Rinternals.CDR(args);
/* 1908 */       sy0 = Rinternals.CAR(args); ny0 = Rinternals.Rf_length(sy0); args = Rinternals.CDR(args);
/* 1909 */       sx1 = Rinternals.CAR(args); nx1 = Rinternals.Rf_length(sx1); args = Rinternals.CDR(args);
/* 1910 */       sy1 = Rinternals.CAR(args); ny1 = Rinternals.Rf_length(sy1); args = Rinternals.CDR(args);
/*      */       
/* 1912 */       hlength = Rinternals.Rf_asReal(Rinternals.CAR(args));
/* 1913 */       if (Arith.R_finite(hlength) == 0 || hlength < 0.0D)
/* 1914 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid arrow head length\000".getBytes(), 0)), new Object[0]); 
/* 1915 */       args = Rinternals.CDR(args);
/*      */       
/* 1917 */       angle = Rinternals.Rf_asReal(Rinternals.CAR(args));
/* 1918 */       if (Arith.R_finite(angle) == 0)
/* 1919 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid arrow head angle\000".getBytes(), 0)), new Object[0]); 
/* 1920 */       args = Rinternals.CDR(args);
/*      */       
/* 1922 */       code = Rinternals.Rf_asInteger(Rinternals.CAR(args));
/* 1923 */       R_NaInt$508 = Arith.R_NaInt; if (code == R_NaInt$508 || code < 0 || code > 3)
/* 1924 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid arrow head specification\000".getBytes(), 0)), new Object[0]); 
/* 1925 */       args = Rinternals.CDR(args);
/*      */       
/* 1927 */       col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col);
/* 1928 */       ncol = Rinternals.LENGTH(col);
/* 1929 */       args = Rinternals.CDR(args);
/*      */       
/* 1931 */       int j = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); lty = Rf_FixupLty(Rinternals.CAR(args), j); Rinternals.Rf_protect(lty);
/* 1932 */       nlty = Rinternals.Rf_length(lty);
/* 1933 */       args = Rinternals.CDR(args);
/*      */       
/* 1935 */       double d = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(316); lwd = Rf_FixupLwd(Rinternals.CAR(args), d); Rinternals.Rf_protect(lwd);
/* 1936 */       nlwd = Rinternals.Rf_length(lwd);
/* 1937 */       args = Rinternals.CDR(args);
/*      */       
/* 1939 */       graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 1940 */       par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */       
/* 1942 */       x0 = Rinternals2.REAL(sx0); x0$offset = 0;
/* 1943 */       y0 = Rinternals2.REAL(sy0); y0$offset = 0;
/* 1944 */       x1 = Rinternals2.REAL(sx1); x1$offset = 0;
/* 1945 */       y1 = Rinternals2.REAL(sy1); y1$offset = 0;
/*      */       
/* 1947 */       graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/* 1948 */       i = 0; while (true) { n$521 = n[0]; if (i >= n$521)
/* 1949 */           break;  int i6 = i % nx0 * 8; Ptr ptr4 = x0; int i5 = x0$offset + i6; xx0$509 = ptr4.getDouble(i5); xx0[0] = xx0$509;
/* 1950 */         int i4 = i % ny0 * 8; Ptr ptr3 = y0; int i3 = y0$offset + i4; yy0$510 = ptr3.getDouble(i3); yy0[0] = yy0$510;
/* 1951 */         int i2 = i % nx1 * 8; Ptr ptr2 = x1; int i1 = x1$offset + i2; xx1$511 = ptr2.getDouble(i1); xx1[0] = xx1$511;
/* 1952 */         int m = i % ny1 * 8; Ptr ptr1 = y1; int k = y1$offset + m; yy1$512 = ptr1.getDouble(k); yy1[0] = yy1$512;
/* 1953 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(xx0, 0), (Ptr)new DoublePtr(yy0, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 1954 */         graphics__.Rf_GConvert((Ptr)new DoublePtr(xx1, 0), (Ptr)new DoublePtr(yy1, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 1955 */         if (Arith.R_finite(xx0[0]) != 0 && Arith.R_finite(yy0[0]) != 0 && Arith.R_finite(xx1[0]) != 0 && Arith.R_finite(yy1[0]) != 0) {
/* 1956 */           Ptr ptr6 = Rinternals2.INTEGER(col); int i8 = i % ncol * 4; Ptr ptr5 = ptr6; int i7 = 0 + i8; thiscol = ptr5.getInt(i7); if (thiscol >>> 24 != 0) {
/* 1957 */             base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(44, thiscol);
/* 1958 */             Ptr ptr12 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr11 = Rinternals2.INTEGER(lty); int i13 = i % nlty * 4; Ptr ptr10 = ptr11; int i12 = 0 + i13, i11 = ptr10.getInt(i12); ptr12.setInt(312, i11);
/* 1959 */             Ptr ptr9 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr8 = Rinternals2.REAL(lwd); int i10 = i % nlwd * 8; Ptr ptr7 = ptr8; int i9 = 0 + i10; double d1 = ptr7.getDouble(i9); ptr9.setDouble(316, d1);
/* 1960 */             yy1$517 = yy1[0]; xx1$518 = xx1[0]; yy0$519 = yy0[0]; graphics__.Rf_GArrow(xx0[0], yy0$519, xx1$518, yy1$517, 0, hlength, angle, code, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         }  i++; }
/*      */       
/* 1964 */       graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/* 1965 */       graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */ 
/*      */       
/* 1968 */       return Rinternals.R_NilValue;
/*      */     } 
/*      */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void drawPolygon(int n, Ptr x, Ptr y, int lty, int fill, int border, Ptr dd) {
/* 1975 */     R_NaInt$506 = Arith.R_NaInt; if (lty != R_NaInt$506)
/*      */     
/*      */     { 
/* 1978 */       base__.Rf_gpptr(dd).setInt(312, lty); } else { Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_dpptr(dd).getInt(312); ptr.setInt(312, i); }
/* 1979 */      graphics__.Rf_GPolygon(n, x, y, 12, fill, border, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_polygon(SEXP args) {
/* 1987 */     yy = new double[1]; xx = new double[1]; dd = BytePtr.of(0); dd$offset = 0; y = BytePtr.of(0); y$offset = 0; x = BytePtr.of(0); x$offset = 0; num = 0; start = 0; nlty = 0; nborder = 0; ncol = 0; nx = 0; lty = (SEXP)BytePtr.of(0).getArray(); border = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); start = 0;
/* 1988 */     num = 0;
/*      */ 
/*      */     
/* 1991 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 1993 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1995 */     args = Rinternals.CDR(args);
/* 1996 */     if (Rinternals.Rf_length(args) <= 1) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     
/* 1998 */     SEXP sEXP2 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sx = Rinternals.SETCAR(args, sEXP2); args = Rinternals.CDR(args);
/* 1999 */     SEXP sEXP1 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sy = Rinternals.SETCAR(args, sEXP1); args = Rinternals.CDR(args);
/* 2000 */     nx = Rinternals.LENGTH(sx);
/*      */     
/* 2002 */     col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col); args = Rinternals.CDR(args);
/* 2003 */     ncol = Rinternals.LENGTH(col);
/*      */     
/* 2005 */     int k = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(76); border = Rf_FixupCol(Rinternals.CAR(args), k); Rinternals.Rf_protect(border); args = Rinternals.CDR(args);
/* 2006 */     nborder = Rinternals.LENGTH(border);
/*      */     
/* 2008 */     int j = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); lty = Rf_FixupLty(Rinternals.CAR(args), j); Rinternals.Rf_protect(lty); args = Rinternals.CDR(args);
/* 2009 */     nlty = Rinternals.Rf_length(lty);
/*      */     
/* 2011 */     graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 2012 */     par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */     
/* 2014 */     graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/*      */     
/* 2016 */     x = Rinternals2.REAL(sx); x$offset = 0;
/* 2017 */     y = Rinternals2.REAL(sy); y$offset = 0;
/* 2018 */     xold = Arith.R_NaReal;
/* 2019 */     yold = Arith.R_NaReal;
/* 2020 */     for (i = 0; i < nx; i++) {
/* 2021 */       int i2 = i * 8; Ptr ptr2 = x; int i1 = x$offset + i2; xx$495 = ptr2.getDouble(i1); xx[0] = xx$495;
/* 2022 */       int n = i * 8; Ptr ptr1 = y; int m = y$offset + n; yy$497 = ptr1.getDouble(m); yy[0] = yy$497;
/* 2023 */       graphics__.Rf_GConvert((Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), 12, 0, dd.pointerPlus(dd$offset));
/* 2024 */       if (Arith.R_finite(xx[0]) == 0 || Arith.R_finite(yy[0]) == 0 || (
/* 2025 */         Arith.R_finite(xold) != 0 && Arith.R_finite(yold) != 0))
/*      */       
/* 2027 */       { if (Arith.R_finite(xold) == 0 || Arith.R_finite(yold) == 0 || (
/* 2028 */           Arith.R_finite(xx[0]) != 0 && Arith.R_finite(yy[0]) != 0))
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2037 */           if (Arith.R_finite(xold) != 0 && Arith.R_finite(yold) != 0 && nx + -1 == i)
/*      */           
/*      */           { 
/*      */             
/* 2041 */             Ptr ptr10 = Rinternals2.INTEGER(border); int i15 = num % nborder * 4; Ptr ptr9 = ptr10; int i14 = 0 + i15; int i13 = ptr9.getInt(i14); Ptr ptr8 = Rinternals2.INTEGER(col); int i12 = num % ncol * 4; Ptr ptr7 = ptr8; int i11 = 0 + i12; int i10 = ptr7.getInt(i11); Ptr ptr6 = Rinternals2.INTEGER(lty); int i9 = num % nlty * 4; Ptr ptr5 = ptr6; int i8 = 0 + i9; int i7 = ptr5.getInt(i8), i6 = start * 8; Ptr ptr4 = y; int i5 = y$offset + i6, i4 = start * 8; Ptr ptr3 = x; int i3 = x$offset + i4; drawPolygon(nx - start, ptr3.pointerPlus(i3), ptr4.pointerPlus(i5), i7, i10, i13, dd.pointerPlus(dd$offset));
/* 2042 */             num++; }  } else if (i - start > 1) { Ptr ptr10 = Rinternals2.INTEGER(border); int i15 = num % nborder * 4; Ptr ptr9 = ptr10; int i14 = 0 + i15; int i13 = ptr9.getInt(i14); Ptr ptr8 = Rinternals2.INTEGER(col); int i12 = num % ncol * 4; Ptr ptr7 = ptr8; int i11 = 0 + i12; int i10 = ptr7.getInt(i11); Ptr ptr6 = Rinternals2.INTEGER(lty); int i9 = num % nlty * 4; Ptr ptr5 = ptr6; int i8 = 0 + i9; int i7 = ptr5.getInt(i8), i6 = start * 8; Ptr ptr4 = y; int i5 = y$offset + i6, i4 = start * 8; Ptr ptr3 = x; int i3 = x$offset + i4; drawPolygon(i - start, ptr3.pointerPlus(i3), ptr4.pointerPlus(i5), i7, i10, i13, dd.pointerPlus(dd$offset)); num++; }  }
/*      */       else { start = i; }
/* 2044 */        xold = xx[0];
/* 2045 */       yold = yy[0];
/*      */     } 
/*      */     
/* 2048 */     graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */     
/* 2050 */     graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */     
/* 2052 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_text(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #5
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #6
/*      */     //   10: iconst_0
/*      */     //   11: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14: astore_1
/*      */     //   15: iconst_0
/*      */     //   16: istore_2
/*      */     //   17: iconst_0
/*      */     //   18: istore #4
/*      */     //   20: iconst_0
/*      */     //   21: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   24: astore #7
/*      */     //   26: iconst_0
/*      */     //   27: istore #8
/*      */     //   29: iconst_0
/*      */     //   30: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   33: astore #9
/*      */     //   35: iconst_0
/*      */     //   36: istore #10
/*      */     //   38: dconst_0
/*      */     //   39: dstore #11
/*      */     //   41: dconst_0
/*      */     //   42: dstore #13
/*      */     //   44: dconst_0
/*      */     //   45: dstore #15
/*      */     //   47: iconst_0
/*      */     //   48: istore #17
/*      */     //   50: iconst_0
/*      */     //   51: istore #18
/*      */     //   53: iconst_0
/*      */     //   54: istore #19
/*      */     //   56: iconst_0
/*      */     //   57: istore #20
/*      */     //   59: iconst_0
/*      */     //   60: istore #21
/*      */     //   62: iconst_0
/*      */     //   63: istore #22
/*      */     //   65: iconst_0
/*      */     //   66: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   69: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   74: checkcast org/renjin/sexp/SEXP
/*      */     //   77: astore #24
/*      */     //   79: iconst_0
/*      */     //   80: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   83: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   88: checkcast org/renjin/sexp/SEXP
/*      */     //   91: astore #25
/*      */     //   93: iconst_0
/*      */     //   94: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   97: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   102: checkcast org/renjin/sexp/SEXP
/*      */     //   105: astore #26
/*      */     //   107: iconst_0
/*      */     //   108: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   111: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   116: checkcast org/renjin/sexp/SEXP
/*      */     //   119: astore #27
/*      */     //   121: iconst_0
/*      */     //   122: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   125: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   130: checkcast org/renjin/sexp/SEXP
/*      */     //   133: astore #28
/*      */     //   135: iconst_0
/*      */     //   136: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   139: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   144: checkcast org/renjin/sexp/SEXP
/*      */     //   147: astore #29
/*      */     //   149: iconst_0
/*      */     //   150: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   153: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   158: checkcast org/renjin/sexp/SEXP
/*      */     //   161: astore #31
/*      */     //   163: iconst_0
/*      */     //   164: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   167: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   172: checkcast org/renjin/sexp/SEXP
/*      */     //   175: astore #33
/*      */     //   177: iconst_0
/*      */     //   178: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   181: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   186: checkcast org/renjin/sexp/SEXP
/*      */     //   189: astore #34
/*      */     //   191: dconst_0
/*      */     //   192: dstore #15
/*      */     //   194: dconst_0
/*      */     //   195: dstore #13
/*      */     //   197: ldc2_w 0.5
/*      */     //   200: dstore #11
/*      */     //   202: iconst_0
/*      */     //   203: istore #4
/*      */     //   205: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   208: astore_1
/*      */     //   209: iconst_0
/*      */     //   210: istore_2
/*      */     //   211: aload_1
/*      */     //   212: iload_2
/*      */     //   213: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   218: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   221: aload_0
/*      */     //   222: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   225: astore_0
/*      */     //   226: aload_0
/*      */     //   227: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   230: iconst_2
/*      */     //   231: if_icmple -> 237
/*      */     //   234: goto -> 276
/*      */     //   237: new org/renjin/gcc/runtime/BytePtr
/*      */     //   240: dup
/*      */     //   241: ldc 'graphics '
/*      */     //   243: invokevirtual getBytes : ()[B
/*      */     //   246: iconst_0
/*      */     //   247: invokespecial <init> : ([BI)V
/*      */     //   250: new org/renjin/gcc/runtime/BytePtr
/*      */     //   253: dup
/*      */     //   254: ldc 'too few arguments '
/*      */     //   256: invokevirtual getBytes : ()[B
/*      */     //   259: iconst_0
/*      */     //   260: invokespecial <init> : ([BI)V
/*      */     //   263: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   266: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   269: iconst_0
/*      */     //   270: anewarray java/lang/Object
/*      */     //   273: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   276: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   279: astore #34
/*      */     //   281: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   284: astore #33
/*      */     //   286: aload_0
/*      */     //   287: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   290: astore #32
/*      */     //   292: aload #32
/*      */     //   294: invokestatic Rf_isNewList : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   297: ifne -> 303
/*      */     //   300: goto -> 348
/*      */     //   303: aload #32
/*      */     //   305: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   308: iconst_1
/*      */     //   309: if_icmpgt -> 315
/*      */     //   312: goto -> 348
/*      */     //   315: aload #32
/*      */     //   317: iconst_0
/*      */     //   318: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   321: astore #34
/*      */     //   323: aload #34
/*      */     //   325: bipush #14
/*      */     //   327: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   330: aload #32
/*      */     //   332: iconst_1
/*      */     //   333: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   336: astore #33
/*      */     //   338: aload #33
/*      */     //   340: bipush #14
/*      */     //   342: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   345: goto -> 442
/*      */     //   348: aload #32
/*      */     //   350: invokestatic Rf_isList : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   353: ifne -> 359
/*      */     //   356: goto -> 402
/*      */     //   359: aload #32
/*      */     //   361: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   364: iconst_1
/*      */     //   365: if_icmpgt -> 371
/*      */     //   368: goto -> 402
/*      */     //   371: aload #32
/*      */     //   373: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   376: astore #34
/*      */     //   378: aload #34
/*      */     //   380: bipush #14
/*      */     //   382: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   385: aload #32
/*      */     //   387: invokestatic CADR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   390: astore #33
/*      */     //   392: aload #33
/*      */     //   394: bipush #14
/*      */     //   396: invokestatic TypeCheck : (Lorg/renjin/sexp/SEXP;I)V
/*      */     //   399: goto -> 442
/*      */     //   402: new org/renjin/gcc/runtime/BytePtr
/*      */     //   405: dup
/*      */     //   406: ldc 'graphics '
/*      */     //   408: invokevirtual getBytes : ()[B
/*      */     //   411: iconst_0
/*      */     //   412: invokespecial <init> : ([BI)V
/*      */     //   415: new org/renjin/gcc/runtime/BytePtr
/*      */     //   418: dup
/*      */     //   419: ldc_w 'invalid plotting structure '
/*      */     //   422: invokevirtual getBytes : ()[B
/*      */     //   425: iconst_0
/*      */     //   426: invokespecial <init> : ([BI)V
/*      */     //   429: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   432: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   435: iconst_0
/*      */     //   436: anewarray java/lang/Object
/*      */     //   439: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   442: aload #34
/*      */     //   444: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   447: wide istore #269
/*      */     //   451: aload #33
/*      */     //   453: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   456: wide istore #268
/*      */     //   460: wide iload #269
/*      */     //   464: wide iload #268
/*      */     //   468: if_icmpne -> 474
/*      */     //   471: goto -> 531
/*      */     //   474: new org/renjin/gcc/runtime/BytePtr
/*      */     //   477: dup
/*      */     //   478: ldc 'graphics '
/*      */     //   480: invokevirtual getBytes : ()[B
/*      */     //   483: iconst_0
/*      */     //   484: invokespecial <init> : ([BI)V
/*      */     //   487: new org/renjin/gcc/runtime/BytePtr
/*      */     //   490: dup
/*      */     //   491: ldc_w ''x' and 'y' lengths differ in %s() '
/*      */     //   494: invokevirtual getBytes : ()[B
/*      */     //   497: iconst_0
/*      */     //   498: invokespecial <init> : ([BI)V
/*      */     //   501: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   504: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   507: iconst_1
/*      */     //   508: anewarray java/lang/Object
/*      */     //   511: dup
/*      */     //   512: iconst_0
/*      */     //   513: new org/renjin/gcc/runtime/BytePtr
/*      */     //   516: dup
/*      */     //   517: ldc_w 'text '
/*      */     //   520: invokevirtual getBytes : ()[B
/*      */     //   523: iconst_0
/*      */     //   524: invokespecial <init> : ([BI)V
/*      */     //   527: aastore
/*      */     //   528: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   531: aload #34
/*      */     //   533: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   536: istore #22
/*      */     //   538: aload_0
/*      */     //   539: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   542: astore_0
/*      */     //   543: aload_0
/*      */     //   544: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   547: astore #31
/*      */     //   549: aload #31
/*      */     //   551: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   554: iconst_1
/*      */     //   555: if_icmpeq -> 572
/*      */     //   558: goto -> 561
/*      */     //   561: aload #31
/*      */     //   563: invokestatic Rf_isLanguage : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   566: ifne -> 572
/*      */     //   569: goto -> 584
/*      */     //   572: aload #31
/*      */     //   574: bipush #20
/*      */     //   576: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   579: astore #31
/*      */     //   581: goto -> 606
/*      */     //   584: aload #31
/*      */     //   586: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   589: bipush #20
/*      */     //   591: if_icmpne -> 597
/*      */     //   594: goto -> 606
/*      */     //   597: aload #31
/*      */     //   599: bipush #16
/*      */     //   601: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   604: astore #31
/*      */     //   606: aload #31
/*      */     //   608: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   611: pop
/*      */     //   612: aload #31
/*      */     //   614: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   617: ifle -> 623
/*      */     //   620: goto -> 680
/*      */     //   623: new org/renjin/gcc/runtime/BytePtr
/*      */     //   626: dup
/*      */     //   627: ldc 'graphics '
/*      */     //   629: invokevirtual getBytes : ()[B
/*      */     //   632: iconst_0
/*      */     //   633: invokespecial <init> : ([BI)V
/*      */     //   636: new org/renjin/gcc/runtime/BytePtr
/*      */     //   639: dup
/*      */     //   640: ldc_w 'zero-length '%s' specified '
/*      */     //   643: invokevirtual getBytes : ()[B
/*      */     //   646: iconst_0
/*      */     //   647: invokespecial <init> : ([BI)V
/*      */     //   650: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   653: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   656: iconst_1
/*      */     //   657: anewarray java/lang/Object
/*      */     //   660: dup
/*      */     //   661: iconst_0
/*      */     //   662: new org/renjin/gcc/runtime/BytePtr
/*      */     //   665: dup
/*      */     //   666: ldc_w 'labels '
/*      */     //   669: invokevirtual getBytes : ()[B
/*      */     //   672: iconst_0
/*      */     //   673: invokespecial <init> : ([BI)V
/*      */     //   676: aastore
/*      */     //   677: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   680: aload_0
/*      */     //   681: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   684: astore_0
/*      */     //   685: aload_0
/*      */     //   686: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   689: astore #30
/*      */     //   691: aload #30
/*      */     //   693: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   696: pop
/*      */     //   697: aload #30
/*      */     //   699: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   702: ifeq -> 730
/*      */     //   705: goto -> 708
/*      */     //   708: aload #30
/*      */     //   710: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   713: ifne -> 719
/*      */     //   716: goto -> 757
/*      */     //   719: aload #30
/*      */     //   721: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   724: ifeq -> 730
/*      */     //   727: goto -> 757
/*      */     //   730: aload_1
/*      */     //   731: iload_2
/*      */     //   732: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   737: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   740: bipush #8
/*      */     //   742: invokeinterface getDouble : (I)D
/*      */     //   747: dstore #15
/*      */     //   749: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   752: dstore #13
/*      */     //   754: goto -> 962
/*      */     //   757: aload #30
/*      */     //   759: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   762: bipush #14
/*      */     //   764: if_icmpeq -> 770
/*      */     //   767: goto -> 831
/*      */     //   770: aload #30
/*      */     //   772: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   775: iconst_1
/*      */     //   776: if_icmpeq -> 782
/*      */     //   779: goto -> 802
/*      */     //   782: aload #30
/*      */     //   784: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   787: invokeinterface getDouble : ()D
/*      */     //   792: dstore #15
/*      */     //   794: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   797: dstore #13
/*      */     //   799: goto -> 962
/*      */     //   802: aload #30
/*      */     //   804: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   807: invokeinterface getDouble : ()D
/*      */     //   812: dstore #15
/*      */     //   814: aload #30
/*      */     //   816: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   819: bipush #8
/*      */     //   821: invokeinterface getDouble : (I)D
/*      */     //   826: dstore #13
/*      */     //   828: goto -> 962
/*      */     //   831: aload #30
/*      */     //   833: invokestatic Rf_isInteger : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   836: ifne -> 842
/*      */     //   839: goto -> 905
/*      */     //   842: aload #30
/*      */     //   844: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   847: iconst_1
/*      */     //   848: if_icmpeq -> 854
/*      */     //   851: goto -> 875
/*      */     //   854: aload #30
/*      */     //   856: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   859: invokeinterface getInt : ()I
/*      */     //   864: i2d
/*      */     //   865: dstore #15
/*      */     //   867: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   870: dstore #13
/*      */     //   872: goto -> 962
/*      */     //   875: aload #30
/*      */     //   877: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   880: invokeinterface getInt : ()I
/*      */     //   885: i2d
/*      */     //   886: dstore #15
/*      */     //   888: aload #30
/*      */     //   890: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   893: iconst_4
/*      */     //   894: invokeinterface getInt : (I)I
/*      */     //   899: i2d
/*      */     //   900: dstore #13
/*      */     //   902: goto -> 962
/*      */     //   905: new org/renjin/gcc/runtime/BytePtr
/*      */     //   908: dup
/*      */     //   909: ldc 'graphics '
/*      */     //   911: invokevirtual getBytes : ()[B
/*      */     //   914: iconst_0
/*      */     //   915: invokespecial <init> : ([BI)V
/*      */     //   918: new org/renjin/gcc/runtime/BytePtr
/*      */     //   921: dup
/*      */     //   922: ldc_w 'invalid '%s' value '
/*      */     //   925: invokevirtual getBytes : ()[B
/*      */     //   928: iconst_0
/*      */     //   929: invokespecial <init> : ([BI)V
/*      */     //   932: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   935: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   938: iconst_1
/*      */     //   939: anewarray java/lang/Object
/*      */     //   942: dup
/*      */     //   943: iconst_0
/*      */     //   944: new org/renjin/gcc/runtime/BytePtr
/*      */     //   947: dup
/*      */     //   948: ldc_w 'adj '
/*      */     //   951: invokevirtual getBytes : ()[B
/*      */     //   954: iconst_0
/*      */     //   955: invokespecial <init> : ([BI)V
/*      */     //   958: aastore
/*      */     //   959: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   962: aload_0
/*      */     //   963: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   966: astore_0
/*      */     //   967: aload_0
/*      */     //   968: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   971: bipush #13
/*      */     //   973: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   976: astore #29
/*      */     //   978: aload #29
/*      */     //   980: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   983: pop
/*      */     //   984: aload #29
/*      */     //   986: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   989: istore #21
/*      */     //   991: iconst_0
/*      */     //   992: istore #23
/*      */     //   994: goto -> 1134
/*      */     //   997: aload #29
/*      */     //   999: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1002: astore #229
/*      */     //   1004: iload #23
/*      */     //   1006: iconst_4
/*      */     //   1007: imul
/*      */     //   1008: istore #227
/*      */     //   1010: aload #229
/*      */     //   1012: astore #225
/*      */     //   1014: iconst_0
/*      */     //   1015: iload #227
/*      */     //   1017: iadd
/*      */     //   1018: istore #226
/*      */     //   1020: aload #225
/*      */     //   1022: iload #226
/*      */     //   1024: invokeinterface getInt : (I)I
/*      */     //   1029: ifle -> 1074
/*      */     //   1032: goto -> 1035
/*      */     //   1035: aload #29
/*      */     //   1037: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1040: astore #222
/*      */     //   1042: iload #23
/*      */     //   1044: iconst_4
/*      */     //   1045: imul
/*      */     //   1046: istore #220
/*      */     //   1048: aload #222
/*      */     //   1050: astore #218
/*      */     //   1052: iconst_0
/*      */     //   1053: iload #220
/*      */     //   1055: iadd
/*      */     //   1056: istore #219
/*      */     //   1058: aload #218
/*      */     //   1060: iload #219
/*      */     //   1062: invokeinterface getInt : (I)I
/*      */     //   1067: iconst_4
/*      */     //   1068: if_icmpgt -> 1074
/*      */     //   1071: goto -> 1131
/*      */     //   1074: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1077: dup
/*      */     //   1078: ldc 'graphics '
/*      */     //   1080: invokevirtual getBytes : ()[B
/*      */     //   1083: iconst_0
/*      */     //   1084: invokespecial <init> : ([BI)V
/*      */     //   1087: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1090: dup
/*      */     //   1091: ldc_w 'invalid '%s' value '
/*      */     //   1094: invokevirtual getBytes : ()[B
/*      */     //   1097: iconst_0
/*      */     //   1098: invokespecial <init> : ([BI)V
/*      */     //   1101: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1104: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1107: iconst_1
/*      */     //   1108: anewarray java/lang/Object
/*      */     //   1111: dup
/*      */     //   1112: iconst_0
/*      */     //   1113: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1116: dup
/*      */     //   1117: ldc_w 'pos '
/*      */     //   1120: invokevirtual getBytes : ()[B
/*      */     //   1123: iconst_0
/*      */     //   1124: invokespecial <init> : ([BI)V
/*      */     //   1127: aastore
/*      */     //   1128: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1131: iinc #23, 1
/*      */     //   1134: iload #23
/*      */     //   1136: iload #21
/*      */     //   1138: if_icmplt -> 997
/*      */     //   1141: goto -> 1144
/*      */     //   1144: aload_0
/*      */     //   1145: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1148: astore_0
/*      */     //   1149: aload_0
/*      */     //   1150: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1153: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1156: bipush #15
/*      */     //   1158: bipush #13
/*      */     //   1160: aload_1
/*      */     //   1161: iload_2
/*      */     //   1162: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1167: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1170: dstore #11
/*      */     //   1172: aload_0
/*      */     //   1173: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1176: astore_0
/*      */     //   1177: aload_0
/*      */     //   1178: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1181: invokestatic Rf_FixupVFont : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1184: astore #24
/*      */     //   1186: aload #24
/*      */     //   1188: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1191: pop
/*      */     //   1192: aload_0
/*      */     //   1193: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1196: astore_0
/*      */     //   1197: aload_0
/*      */     //   1198: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1201: dconst_1
/*      */     //   1202: invokestatic FixupCex : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   1205: astore #28
/*      */     //   1207: aload #28
/*      */     //   1209: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1212: pop
/*      */     //   1213: aload #28
/*      */     //   1215: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1218: istore #20
/*      */     //   1220: aload_0
/*      */     //   1221: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1224: astore_0
/*      */     //   1225: aload_0
/*      */     //   1226: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1229: astore #26
/*      */     //   1231: aload #26
/*      */     //   1233: ldc 16777215
/*      */     //   1235: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   1238: astore #27
/*      */     //   1240: aload #27
/*      */     //   1242: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1245: pop
/*      */     //   1246: aload #27
/*      */     //   1248: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1251: istore #19
/*      */     //   1253: aload_0
/*      */     //   1254: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1257: astore_0
/*      */     //   1258: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1261: istore #209
/*      */     //   1263: aload_0
/*      */     //   1264: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1267: iload #209
/*      */     //   1269: invokestatic FixupFont : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   1272: astore #25
/*      */     //   1274: aload #25
/*      */     //   1276: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1279: pop
/*      */     //   1280: aload #25
/*      */     //   1282: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1285: istore #18
/*      */     //   1287: aload_0
/*      */     //   1288: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1291: astore_0
/*      */     //   1292: aload #34
/*      */     //   1294: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1297: astore #9
/*      */     //   1299: iconst_0
/*      */     //   1300: istore #10
/*      */     //   1302: aload #33
/*      */     //   1304: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1307: astore #7
/*      */     //   1309: iconst_0
/*      */     //   1310: istore #8
/*      */     //   1312: aload #31
/*      */     //   1314: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1317: istore #17
/*      */     //   1319: aload_1
/*      */     //   1320: iload_2
/*      */     //   1321: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1326: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1329: aload_0
/*      */     //   1330: aload_1
/*      */     //   1331: iload_2
/*      */     //   1332: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1337: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1340: aload #24
/*      */     //   1342: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1345: ifne -> 1351
/*      */     //   1348: goto -> 1444
/*      */     //   1351: aload #31
/*      */     //   1353: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1356: bipush #20
/*      */     //   1358: if_icmpne -> 1364
/*      */     //   1361: goto -> 1444
/*      */     //   1364: aload_1
/*      */     //   1365: iload_2
/*      */     //   1366: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1371: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1374: bipush #80
/*      */     //   1376: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1381: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1384: dup
/*      */     //   1385: ldc_w 'Hershey  '
/*      */     //   1388: invokevirtual getBytes : ()[B
/*      */     //   1391: iconst_0
/*      */     //   1392: invokespecial <init> : ([BI)V
/*      */     //   1395: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1398: sipush #201
/*      */     //   1401: invokestatic strncpy : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1404: pop
/*      */     //   1405: aload_1
/*      */     //   1406: iload_2
/*      */     //   1407: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1412: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1415: astore #200
/*      */     //   1417: aload #24
/*      */     //   1419: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1422: invokeinterface getInt : ()I
/*      */     //   1427: i2b
/*      */     //   1428: istore #196
/*      */     //   1430: aload #200
/*      */     //   1432: bipush #87
/*      */     //   1434: iload #196
/*      */     //   1436: invokeinterface setByte : (IB)V
/*      */     //   1441: iconst_1
/*      */     //   1442: istore #4
/*      */     //   1444: iconst_1
/*      */     //   1445: aload_1
/*      */     //   1446: iload_2
/*      */     //   1447: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1452: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1455: iload #22
/*      */     //   1457: ifeq -> 1463
/*      */     //   1460: goto -> 1511
/*      */     //   1463: iload #17
/*      */     //   1465: ifgt -> 1471
/*      */     //   1468: goto -> 1511
/*      */     //   1471: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1474: dup
/*      */     //   1475: ldc 'graphics '
/*      */     //   1477: invokevirtual getBytes : ()[B
/*      */     //   1480: iconst_0
/*      */     //   1481: invokespecial <init> : ([BI)V
/*      */     //   1484: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1487: dup
/*      */     //   1488: ldc_w 'no coordinates were supplied '
/*      */     //   1491: invokevirtual getBytes : ()[B
/*      */     //   1494: iconst_0
/*      */     //   1495: invokespecial <init> : ([BI)V
/*      */     //   1498: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1501: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1504: iconst_0
/*      */     //   1505: anewarray java/lang/Object
/*      */     //   1508: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1511: iconst_0
/*      */     //   1512: istore #23
/*      */     //   1514: goto -> 2608
/*      */     //   1517: iload #23
/*      */     //   1519: iload #22
/*      */     //   1521: irem
/*      */     //   1522: bipush #8
/*      */     //   1524: imul
/*      */     //   1525: istore #191
/*      */     //   1527: aload #9
/*      */     //   1529: astore #189
/*      */     //   1531: iload #10
/*      */     //   1533: iload #191
/*      */     //   1535: iadd
/*      */     //   1536: istore #190
/*      */     //   1538: aload #189
/*      */     //   1540: iload #190
/*      */     //   1542: invokeinterface getDouble : (I)D
/*      */     //   1547: dstore #187
/*      */     //   1549: aload #6
/*      */     //   1551: iconst_0
/*      */     //   1552: dload #187
/*      */     //   1554: dastore
/*      */     //   1555: iload #23
/*      */     //   1557: iload #22
/*      */     //   1559: irem
/*      */     //   1560: bipush #8
/*      */     //   1562: imul
/*      */     //   1563: istore #184
/*      */     //   1565: aload #7
/*      */     //   1567: astore #182
/*      */     //   1569: iload #8
/*      */     //   1571: iload #184
/*      */     //   1573: iadd
/*      */     //   1574: istore #183
/*      */     //   1576: aload #182
/*      */     //   1578: iload #183
/*      */     //   1580: invokeinterface getDouble : (I)D
/*      */     //   1585: dstore #180
/*      */     //   1587: aload #5
/*      */     //   1589: iconst_0
/*      */     //   1590: dload #180
/*      */     //   1592: dastore
/*      */     //   1593: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1596: dup
/*      */     //   1597: aload #6
/*      */     //   1599: iconst_0
/*      */     //   1600: invokespecial <init> : ([DI)V
/*      */     //   1603: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1606: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1609: dup
/*      */     //   1610: aload #5
/*      */     //   1612: iconst_0
/*      */     //   1613: invokespecial <init> : ([DI)V
/*      */     //   1616: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1619: bipush #12
/*      */     //   1621: bipush #13
/*      */     //   1623: aload_1
/*      */     //   1624: iload_2
/*      */     //   1625: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1630: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1633: aload #6
/*      */     //   1635: iconst_0
/*      */     //   1636: daload
/*      */     //   1637: invokestatic R_finite : (D)I
/*      */     //   1640: ifne -> 1646
/*      */     //   1643: goto -> 2605
/*      */     //   1646: aload #5
/*      */     //   1648: iconst_0
/*      */     //   1649: daload
/*      */     //   1650: invokestatic R_finite : (D)I
/*      */     //   1653: ifne -> 1659
/*      */     //   1656: goto -> 2605
/*      */     //   1659: iload #19
/*      */     //   1661: ifne -> 1667
/*      */     //   1664: goto -> 1745
/*      */     //   1667: aload #26
/*      */     //   1669: iload #23
/*      */     //   1671: iload #19
/*      */     //   1673: invokestatic isNAcol : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1676: ifeq -> 1682
/*      */     //   1679: goto -> 1745
/*      */     //   1682: aload_1
/*      */     //   1683: iload_2
/*      */     //   1684: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1689: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1692: astore #171
/*      */     //   1694: aload #27
/*      */     //   1696: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1699: astore #169
/*      */     //   1701: iload #23
/*      */     //   1703: iload #19
/*      */     //   1705: irem
/*      */     //   1706: iconst_4
/*      */     //   1707: imul
/*      */     //   1708: istore #166
/*      */     //   1710: aload #169
/*      */     //   1712: astore #164
/*      */     //   1714: iconst_0
/*      */     //   1715: iload #166
/*      */     //   1717: iadd
/*      */     //   1718: istore #165
/*      */     //   1720: aload #164
/*      */     //   1722: iload #165
/*      */     //   1724: invokeinterface getInt : (I)I
/*      */     //   1729: istore #162
/*      */     //   1731: aload #171
/*      */     //   1733: bipush #44
/*      */     //   1735: iload #162
/*      */     //   1737: invokeinterface setInt : (II)V
/*      */     //   1742: goto -> 1787
/*      */     //   1745: aload_1
/*      */     //   1746: iload_2
/*      */     //   1747: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1752: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1755: astore #160
/*      */     //   1757: aload_1
/*      */     //   1758: iload_2
/*      */     //   1759: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1764: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1767: bipush #44
/*      */     //   1769: invokeinterface getInt : (I)I
/*      */     //   1774: istore #157
/*      */     //   1776: aload #160
/*      */     //   1778: bipush #44
/*      */     //   1780: iload #157
/*      */     //   1782: invokeinterface setInt : (II)V
/*      */     //   1787: iload #20
/*      */     //   1789: ifne -> 1795
/*      */     //   1792: goto -> 1931
/*      */     //   1795: aload #28
/*      */     //   1797: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1800: astore #155
/*      */     //   1802: iload #23
/*      */     //   1804: iload #20
/*      */     //   1806: irem
/*      */     //   1807: bipush #8
/*      */     //   1809: imul
/*      */     //   1810: istore #152
/*      */     //   1812: aload #155
/*      */     //   1814: astore #150
/*      */     //   1816: iconst_0
/*      */     //   1817: iload #152
/*      */     //   1819: iadd
/*      */     //   1820: istore #151
/*      */     //   1822: aload #150
/*      */     //   1824: iload #151
/*      */     //   1826: invokeinterface getDouble : (I)D
/*      */     //   1831: invokestatic R_finite : (D)I
/*      */     //   1834: ifne -> 1840
/*      */     //   1837: goto -> 1931
/*      */     //   1840: aload_1
/*      */     //   1841: iload_2
/*      */     //   1842: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1847: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1850: astore #145
/*      */     //   1852: aload_1
/*      */     //   1853: iload_2
/*      */     //   1854: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1859: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1862: sipush #484
/*      */     //   1865: invokeinterface getDouble : (I)D
/*      */     //   1870: dstore #141
/*      */     //   1872: aload #28
/*      */     //   1874: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1877: astore #139
/*      */     //   1879: iload #23
/*      */     //   1881: iload #20
/*      */     //   1883: irem
/*      */     //   1884: bipush #8
/*      */     //   1886: imul
/*      */     //   1887: istore #136
/*      */     //   1889: aload #139
/*      */     //   1891: astore #134
/*      */     //   1893: iconst_0
/*      */     //   1894: iload #136
/*      */     //   1896: iadd
/*      */     //   1897: istore #135
/*      */     //   1899: aload #134
/*      */     //   1901: iload #135
/*      */     //   1903: invokeinterface getDouble : (I)D
/*      */     //   1908: dstore #132
/*      */     //   1910: dload #141
/*      */     //   1912: dload #132
/*      */     //   1914: dmul
/*      */     //   1915: dstore #130
/*      */     //   1917: aload #145
/*      */     //   1919: bipush #28
/*      */     //   1921: dload #130
/*      */     //   1923: invokeinterface setDouble : (ID)V
/*      */     //   1928: goto -> 1974
/*      */     //   1931: aload_1
/*      */     //   1932: iload_2
/*      */     //   1933: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1938: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1941: astore #128
/*      */     //   1943: aload_1
/*      */     //   1944: iload_2
/*      */     //   1945: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1950: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1953: sipush #484
/*      */     //   1956: invokeinterface getDouble : (I)D
/*      */     //   1961: dstore #124
/*      */     //   1963: aload #128
/*      */     //   1965: bipush #28
/*      */     //   1967: dload #124
/*      */     //   1969: invokeinterface setDouble : (ID)V
/*      */     //   1974: iload #4
/*      */     //   1976: ifne -> 1982
/*      */     //   1979: goto -> 2022
/*      */     //   1982: aload_1
/*      */     //   1983: iload_2
/*      */     //   1984: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1989: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1992: astore #122
/*      */     //   1994: aload #24
/*      */     //   1996: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1999: iconst_4
/*      */     //   2000: invokeinterface getInt : (I)I
/*      */     //   2005: istore #119
/*      */     //   2007: aload #122
/*      */     //   2009: sipush #284
/*      */     //   2012: iload #119
/*      */     //   2014: invokeinterface setInt : (II)V
/*      */     //   2019: goto -> 2190
/*      */     //   2022: iload #18
/*      */     //   2024: ifne -> 2030
/*      */     //   2027: goto -> 2146
/*      */     //   2030: aload #25
/*      */     //   2032: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2035: astore #117
/*      */     //   2037: iload #23
/*      */     //   2039: iload #18
/*      */     //   2041: irem
/*      */     //   2042: iconst_4
/*      */     //   2043: imul
/*      */     //   2044: istore #114
/*      */     //   2046: aload #117
/*      */     //   2048: astore #112
/*      */     //   2050: iconst_0
/*      */     //   2051: iload #114
/*      */     //   2053: iadd
/*      */     //   2054: istore #113
/*      */     //   2056: aload #112
/*      */     //   2058: iload #113
/*      */     //   2060: invokeinterface getInt : (I)I
/*      */     //   2065: istore #111
/*      */     //   2067: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   2070: istore #110
/*      */     //   2072: iload #111
/*      */     //   2074: iload #110
/*      */     //   2076: if_icmpne -> 2082
/*      */     //   2079: goto -> 2146
/*      */     //   2082: aload_1
/*      */     //   2083: iload_2
/*      */     //   2084: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2089: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2092: astore #108
/*      */     //   2094: aload #25
/*      */     //   2096: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2099: astore #106
/*      */     //   2101: iload #23
/*      */     //   2103: iload #18
/*      */     //   2105: irem
/*      */     //   2106: iconst_4
/*      */     //   2107: imul
/*      */     //   2108: istore #103
/*      */     //   2110: aload #106
/*      */     //   2112: astore #101
/*      */     //   2114: iconst_0
/*      */     //   2115: iload #103
/*      */     //   2117: iadd
/*      */     //   2118: istore #102
/*      */     //   2120: aload #101
/*      */     //   2122: iload #102
/*      */     //   2124: invokeinterface getInt : (I)I
/*      */     //   2129: istore #100
/*      */     //   2131: aload #108
/*      */     //   2133: sipush #284
/*      */     //   2136: iload #100
/*      */     //   2138: invokeinterface setInt : (II)V
/*      */     //   2143: goto -> 2190
/*      */     //   2146: aload_1
/*      */     //   2147: iload_2
/*      */     //   2148: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2153: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2156: astore #98
/*      */     //   2158: aload_1
/*      */     //   2159: iload_2
/*      */     //   2160: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2165: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2168: sipush #284
/*      */     //   2171: invokeinterface getInt : (I)I
/*      */     //   2176: istore #95
/*      */     //   2178: aload #98
/*      */     //   2180: sipush #284
/*      */     //   2183: iload #95
/*      */     //   2185: invokeinterface setInt : (II)V
/*      */     //   2190: iload #21
/*      */     //   2192: ifgt -> 2198
/*      */     //   2195: goto -> 2426
/*      */     //   2198: aload #29
/*      */     //   2200: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2203: astore #93
/*      */     //   2205: iload #23
/*      */     //   2207: iload #21
/*      */     //   2209: irem
/*      */     //   2210: iconst_4
/*      */     //   2211: imul
/*      */     //   2212: istore #90
/*      */     //   2214: aload #93
/*      */     //   2216: astore #88
/*      */     //   2218: iconst_0
/*      */     //   2219: iload #90
/*      */     //   2221: iadd
/*      */     //   2222: istore #89
/*      */     //   2224: aload #88
/*      */     //   2226: iload #89
/*      */     //   2228: invokeinterface getInt : (I)I
/*      */     //   2233: lookupswitch default -> 2426, 1 -> 2276, 2 -> 2329, 3 -> 2366, 4 -> 2392
/*      */     //   2276: aload #5
/*      */     //   2278: iconst_0
/*      */     //   2279: daload
/*      */     //   2280: dload #11
/*      */     //   2282: dsub
/*      */     //   2283: dstore #83
/*      */     //   2285: aload #5
/*      */     //   2287: iconst_0
/*      */     //   2288: dload #83
/*      */     //   2290: dastore
/*      */     //   2291: ldc2_w 0.5
/*      */     //   2294: dstore #15
/*      */     //   2296: aload_1
/*      */     //   2297: iload_2
/*      */     //   2298: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2303: bipush #72
/*      */     //   2305: invokeinterface getDouble : (I)D
/*      */     //   2310: dstore #79
/*      */     //   2312: ldc2_w 0.5
/*      */     //   2315: dload #79
/*      */     //   2317: dsub
/*      */     //   2318: dstore #77
/*      */     //   2320: dconst_1
/*      */     //   2321: dload #77
/*      */     //   2323: dsub
/*      */     //   2324: dstore #13
/*      */     //   2326: goto -> 2426
/*      */     //   2329: aload #6
/*      */     //   2331: iconst_0
/*      */     //   2332: daload
/*      */     //   2333: dload #11
/*      */     //   2335: dsub
/*      */     //   2336: dstore #73
/*      */     //   2338: aload #6
/*      */     //   2340: iconst_0
/*      */     //   2341: dload #73
/*      */     //   2343: dastore
/*      */     //   2344: dconst_1
/*      */     //   2345: dstore #15
/*      */     //   2347: aload_1
/*      */     //   2348: iload_2
/*      */     //   2349: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2354: bipush #72
/*      */     //   2356: invokeinterface getDouble : (I)D
/*      */     //   2361: dstore #13
/*      */     //   2363: goto -> 2426
/*      */     //   2366: aload #5
/*      */     //   2368: iconst_0
/*      */     //   2369: daload
/*      */     //   2370: dload #11
/*      */     //   2372: dadd
/*      */     //   2373: dstore #67
/*      */     //   2375: aload #5
/*      */     //   2377: iconst_0
/*      */     //   2378: dload #67
/*      */     //   2380: dastore
/*      */     //   2381: ldc2_w 0.5
/*      */     //   2384: dstore #15
/*      */     //   2386: dconst_0
/*      */     //   2387: dstore #13
/*      */     //   2389: goto -> 2426
/*      */     //   2392: aload #6
/*      */     //   2394: iconst_0
/*      */     //   2395: daload
/*      */     //   2396: dload #11
/*      */     //   2398: dadd
/*      */     //   2399: dstore #63
/*      */     //   2401: aload #6
/*      */     //   2403: iconst_0
/*      */     //   2404: dload #63
/*      */     //   2406: dastore
/*      */     //   2407: dconst_0
/*      */     //   2408: dstore #15
/*      */     //   2410: aload_1
/*      */     //   2411: iload_2
/*      */     //   2412: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2417: bipush #72
/*      */     //   2419: invokeinterface getDouble : (I)D
/*      */     //   2424: dstore #13
/*      */     //   2426: aload #31
/*      */     //   2428: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2431: bipush #20
/*      */     //   2433: if_icmpeq -> 2439
/*      */     //   2436: goto -> 2510
/*      */     //   2439: aload_1
/*      */     //   2440: iload_2
/*      */     //   2441: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2446: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2449: sipush #388
/*      */     //   2452: invokeinterface getDouble : (I)D
/*      */     //   2457: dstore #56
/*      */     //   2459: iload #23
/*      */     //   2461: iload #17
/*      */     //   2463: irem
/*      */     //   2464: istore #55
/*      */     //   2466: aload #31
/*      */     //   2468: iload #55
/*      */     //   2470: invokestatic VECTOR_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2473: astore #54
/*      */     //   2475: aload #5
/*      */     //   2477: iconst_0
/*      */     //   2478: daload
/*      */     //   2479: dstore #52
/*      */     //   2481: aload #6
/*      */     //   2483: iconst_0
/*      */     //   2484: daload
/*      */     //   2485: dload #52
/*      */     //   2487: bipush #13
/*      */     //   2489: aload #54
/*      */     //   2491: dload #15
/*      */     //   2493: dload #13
/*      */     //   2495: dload #56
/*      */     //   2497: aload_1
/*      */     //   2498: iload_2
/*      */     //   2499: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2504: invokestatic Rf_GMathText : (DDILorg/renjin/sexp/SEXP;DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2507: goto -> 2605
/*      */     //   2510: iload #23
/*      */     //   2512: iload #17
/*      */     //   2514: irem
/*      */     //   2515: istore #49
/*      */     //   2517: aload #31
/*      */     //   2519: iload #49
/*      */     //   2521: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2524: astore_3
/*      */     //   2525: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   2528: astore #48
/*      */     //   2530: aload_3
/*      */     //   2531: aload #48
/*      */     //   2533: if_acmpeq -> 2605
/*      */     //   2536: goto -> 2539
/*      */     //   2539: aload_1
/*      */     //   2540: iload_2
/*      */     //   2541: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2546: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2549: sipush #388
/*      */     //   2552: invokeinterface getDouble : (I)D
/*      */     //   2557: dstore #44
/*      */     //   2559: aload_3
/*      */     //   2560: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2563: istore #43
/*      */     //   2565: aload_3
/*      */     //   2566: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2569: astore #41
/*      */     //   2571: aload #5
/*      */     //   2573: iconst_0
/*      */     //   2574: daload
/*      */     //   2575: dstore #39
/*      */     //   2577: aload #6
/*      */     //   2579: iconst_0
/*      */     //   2580: daload
/*      */     //   2581: dload #39
/*      */     //   2583: bipush #13
/*      */     //   2585: aload #41
/*      */     //   2587: iload #43
/*      */     //   2589: dload #15
/*      */     //   2591: dload #13
/*      */     //   2593: dload #44
/*      */     //   2595: aload_1
/*      */     //   2596: iload_2
/*      */     //   2597: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2602: invokestatic Rf_GText : (DDILorg/renjin/gcc/runtime/Ptr;IDDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2605: iinc #23, 1
/*      */     //   2608: iload #22
/*      */     //   2610: iload #17
/*      */     //   2612: invokestatic Rf_imax2 : (II)I
/*      */     //   2615: iload #23
/*      */     //   2617: if_icmpgt -> 1517
/*      */     //   2620: goto -> 2623
/*      */     //   2623: iconst_0
/*      */     //   2624: aload_1
/*      */     //   2625: iload_2
/*      */     //   2626: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2631: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2634: aload_1
/*      */     //   2635: iload_2
/*      */     //   2636: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2641: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2644: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   2647: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2062	-> 191
/*      */     //   #2065	-> 202
/*      */     //   #2067	-> 205
/*      */     //   #2069	-> 211
/*      */     //   #2071	-> 221
/*      */     //   #2072	-> 226
/*      */     //   #2072	-> 237
/*      */     //   #2074	-> 276
/*      */     //   #2074	-> 303
/*      */     //   #2074	-> 315
/*      */     //   #2074	-> 348
/*      */     //   #2074	-> 359
/*      */     //   #2074	-> 371
/*      */     //   #2074	-> 402
/*      */     //   #2074	-> 442
/*      */     //   #2074	-> 474
/*      */     //   #2074	-> 531
/*      */     //   #2077	-> 543
/*      */     //   #2078	-> 549
/*      */     //   #2078	-> 561
/*      */     //   #2079	-> 572
/*      */     //   #2080	-> 584
/*      */     //   #2081	-> 597
/*      */     //   #2082	-> 606
/*      */     //   #2083	-> 612
/*      */     //   #2084	-> 623
/*      */     //   #2085	-> 680
/*      */     //   #2087	-> 685
/*      */     //   #2088	-> 697
/*      */     //   #2088	-> 708
/*      */     //   #2088	-> 719
/*      */     //   #2089	-> 730
/*      */     //   #2090	-> 749
/*      */     //   #2092	-> 757
/*      */     //   #2093	-> 770
/*      */     //   #2094	-> 782
/*      */     //   #2095	-> 794
/*      */     //   #2098	-> 802
/*      */     //   #2099	-> 814
/*      */     //   #2102	-> 831
/*      */     //   #2103	-> 842
/*      */     //   #2104	-> 854
/*      */     //   #2105	-> 867
/*      */     //   #2108	-> 875
/*      */     //   #2109	-> 888
/*      */     //   #2112	-> 905
/*      */     //   #2113	-> 962
/*      */     //   #2115	-> 967
/*      */     //   #2116	-> 984
/*      */     //   #2117	-> 991
/*      */     //   #2118	-> 997
/*      */     //   #2118	-> 1035
/*      */     //   #2119	-> 1074
/*      */     //   #2117	-> 1131
/*      */     //   #2117	-> 1134
/*      */     //   #2120	-> 1144
/*      */     //   #2122	-> 1149
/*      */     //   #2123	-> 1172
/*      */     //   #2125	-> 1177
/*      */     //   #2126	-> 1192
/*      */     //   #2128	-> 1197
/*      */     //   #2129	-> 1213
/*      */     //   #2130	-> 1220
/*      */     //   #2132	-> 1225
/*      */     //   #2133	-> 1231
/*      */     //   #2134	-> 1246
/*      */     //   #2135	-> 1253
/*      */     //   #2137	-> 1258
/*      */     //   #2138	-> 1280
/*      */     //   #2139	-> 1287
/*      */     //   #2141	-> 1292
/*      */     //   #2142	-> 1302
/*      */     //   #2144	-> 1312
/*      */     //   #2146	-> 1319
/*      */     //   #2147	-> 1329
/*      */     //   #2150	-> 1340
/*      */     //   #2150	-> 1351
/*      */     //   #2151	-> 1364
/*      */     //   #2152	-> 1405
/*      */     //   #2153	-> 1441
/*      */     //   #2156	-> 1444
/*      */     //   #2157	-> 1455
/*      */     //   #2157	-> 1463
/*      */     //   #2158	-> 1471
/*      */     //   #2159	-> 1511
/*      */     //   #2160	-> 1517
/*      */     //   #2161	-> 1555
/*      */     //   #2162	-> 1593
/*      */     //   #2163	-> 1633
/*      */     //   #2163	-> 1646
/*      */     //   #2164	-> 1659
/*      */     //   #2164	-> 1667
/*      */     //   #2165	-> 1682
/*      */     //   #2167	-> 1745
/*      */     //   #2168	-> 1787
/*      */     //   #2168	-> 1795
/*      */     //   #2169	-> 1840
/*      */     //   #2171	-> 1931
/*      */     //   #2173	-> 1974
/*      */     //   #2173	-> 1982
/*      */     //   #2174	-> 2022
/*      */     //   #2174	-> 2030
/*      */     //   #2175	-> 2082
/*      */     //   #2177	-> 2146
/*      */     //   #2179	-> 2190
/*      */     //   #2180	-> 2198
/*      */     //   #2182	-> 2276
/*      */     //   #2183	-> 2291
/*      */     //   #2184	-> 2296
/*      */     //   #2187	-> 2329
/*      */     //   #2188	-> 2344
/*      */     //   #2189	-> 2347
/*      */     //   #2192	-> 2366
/*      */     //   #2193	-> 2381
/*      */     //   #2194	-> 2386
/*      */     //   #2197	-> 2392
/*      */     //   #2198	-> 2407
/*      */     //   #2199	-> 2410
/*      */     //   #2203	-> 2426
/*      */     //   #2205	-> 2439
/*      */     //   #2204	-> 2449
/*      */     //   #2207	-> 2510
/*      */     //   #2208	-> 2525
/*      */     //   #2210	-> 2539
/*      */     //   #2209	-> 2549
/*      */     //   #2159	-> 2605
/*      */     //   #2159	-> 2608
/*      */     //   #2214	-> 2623
/*      */     //   #2216	-> 2634
/*      */     //   #2217	-> 2644
/*      */     //   #2218	-> 2644
/*      */     //   #0	-> 2647
/*      */     //   #2218	-> 2647
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	2648	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	1	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	2648	2	dd$offset	I
/*      */     //   0	2648	3	string	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	4	vectorFonts	I
/*      */     //   0	2648	5	yy	[D
/*      */     //   0	2648	6	xx	[D
/*      */     //   0	2648	7	y	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	2648	8	y$offset	I
/*      */     //   0	2648	9	x	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	2648	10	x$offset	I
/*      */     //   0	2648	11	offset	D
/*      */     //   0	2648	13	adjy	D
/*      */     //   0	2648	15	adjx	D
/*      */     //   0	2648	17	ntxt	I
/*      */     //   0	2648	18	nfont	I
/*      */     //   0	2648	19	ncol	I
/*      */     //   0	2648	20	ncex	I
/*      */     //   0	2648	21	npos	I
/*      */     //   0	2648	22	n	I
/*      */     //   0	2648	23	i	I
/*      */     //   0	2648	24	vfont	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	25	font	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	26	rawcol	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	27	col	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	28	cex	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	29	pos	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	30	adj	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	31	txt	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	32	sxy	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	33	sy	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	34	sx	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	37	xx$493	D
/*      */     //   0	2648	39	yy$492	D
/*      */     //   0	2648	48	R_NaString$491	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2648	50	xx$490	D
/*      */     //   0	2648	52	yy$489	D
/*      */     //   0	2648	63	xx$488	D
/*      */     //   0	2648	65	xx$487	D
/*      */     //   0	2648	67	yy$486	D
/*      */     //   0	2648	69	yy$485	D
/*      */     //   0	2648	73	xx$484	D
/*      */     //   0	2648	75	xx$483	D
/*      */     //   0	2648	83	yy$482	D
/*      */     //   0	2648	85	yy$481	D
/*      */     //   0	2648	110	R_NaInt$480	I
/*      */     //   0	2648	175	yy$479	D
/*      */     //   0	2648	178	xx$478	D
/*      */     //   0	2648	180	yy$477	D
/*      */     //   0	2648	187	xx$476	D
/*      */     //   0	2648	209	R_NaInt$475	I
/*      */     //   0	2648	221	i$474	I
/*      */     //   0	2648	228	i$473	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ComputeAdjValue(double adj, int side, int las) {
/* 2223 */     if (Arith.R_finite(adj) == 0)
/* 2224 */       switch (las) {
/*      */         case 0:
/* 2226 */           adj = 0.5D; break;
/*      */         case 1:
/* 2228 */           switch (side) { case 1:
/*      */             case 3:
/* 2230 */               adj = 0.5D; break;
/* 2231 */             case 2: adj = 1.0D; break;
/* 2232 */             case 4: adj = 0.0D; break; }
/*      */           
/*      */           break;
/*      */         case 2:
/* 2236 */           switch (side) { case 1:
/*      */             case 2:
/* 2238 */               adj = 1.0D; break;
/*      */             case 3: case 4:
/* 2240 */               adj = 0.0D; break; }
/*      */           
/*      */           break;
/*      */         case 3:
/* 2244 */           switch (side) { case 1:
/* 2245 */               adj = 1.0D; break;
/* 2246 */             case 3: adj = 0.0D; break;
/*      */             case 2: case 4:
/* 2248 */               adj = 0.5D;
/*      */               break; }
/*      */           
/*      */           break;
/*      */       }  
/* 2253 */     return adj;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ComputeAtValueFromAdj(double adj, int side, int outer, Ptr dd) {
/* 2259 */     at = 0.0D;
/* 2260 */     switch (side % 2) {
/*      */       case 0:
/* 2262 */         if (outer != 0) { iftmp$471 = adj; } else { iftmp$471 = graphics__.Rf_yNPCtoUsr(adj, dd); }  at = iftmp$471;
/*      */         break;
/*      */       case 1:
/* 2265 */         if (outer != 0) { iftmp$472 = adj; } else { iftmp$472 = graphics__.Rf_xNPCtoUsr(adj, dd); }  at = iftmp$472;
/*      */         break;
/*      */     } 
/* 2268 */     return at;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double ComputeAtValue(double at, double adj, int side, int las, int outer, Ptr dd) {
/* 2275 */     if (Arith.R_finite(at) == 0)
/*      */     {
/*      */ 
/*      */       
/* 2279 */       switch (las) {
/*      */         case 0:
/* 2281 */           at = ComputeAtValueFromAdj(adj, side, outer, dd);
/*      */           break;
/*      */         case 1:
/* 2284 */           switch (side) {
/*      */             case 1:
/*      */             case 3:
/* 2287 */               at = ComputeAtValueFromAdj(adj, side, outer, dd);
/*      */               break;
/*      */             case 2:
/*      */             case 4:
/* 2291 */               if (outer != 0) { iftmp$467 = 0.5D; } else { iftmp$467 = graphics__.Rf_yNPCtoUsr(0.5D, dd); }  at = iftmp$467;
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 2:
/* 2296 */           switch (side) {
/*      */             case 1:
/*      */             case 3:
/* 2299 */               if (outer != 0) { iftmp$468 = 0.5D; } else { iftmp$468 = graphics__.Rf_xNPCtoUsr(0.5D, dd); }  at = iftmp$468;
/*      */               break;
/*      */             case 2:
/*      */             case 4:
/* 2303 */               if (outer != 0) { iftmp$469 = 0.5D; } else { iftmp$469 = graphics__.Rf_yNPCtoUsr(0.5D, dd); }  at = iftmp$469;
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 3:
/* 2308 */           switch (side) {
/*      */             case 1:
/*      */             case 3:
/* 2311 */               if (outer != 0) { iftmp$470 = 0.5D; } else { iftmp$470 = graphics__.Rf_xNPCtoUsr(0.5D, dd); }  at = iftmp$470;
/*      */               break;
/*      */             case 2:
/*      */             case 4:
/* 2315 */               at = ComputeAtValueFromAdj(adj, side, outer, dd);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     }
/* 2321 */     return at;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_mtext(SEXP args) {
/* 2341 */     dd = BytePtr.of(0); dd$offset = 0; cexsave = 0.0D; colsave = 0; fontsave = 0; n = 0; dpnewsave = 0; gpnewsave = 0; dirtyplot = 0; nfont = 0; ncol = 0; ncex = 0; npadj = 0; nadj = 0; nat = 0; nouter = 0; nline = 0; nside = 0; ntext = 0; rawcol = (SEXP)BytePtr.of(0).getArray(); font = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); cex = (SEXP)BytePtr.of(0).getArray(); padj = (SEXP)BytePtr.of(0).getArray(); adj = (SEXP)BytePtr.of(0).getArray(); at = (SEXP)BytePtr.of(0).getArray(); outer = (SEXP)BytePtr.of(0).getArray(); line = (SEXP)BytePtr.of(0).getArray(); side = (SEXP)BytePtr.of(0).getArray(); text = (SEXP)BytePtr.of(0).getArray(); dirtyplot = 0; gpnewsave = 0; dpnewsave = 0;
/*      */ 
/*      */     
/* 2344 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 2346 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 2348 */     args = Rinternals.CDR(args);
/* 2349 */     if (Rinternals.Rf_length(args) <= 8) {
/* 2350 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     }
/*      */     
/* 2353 */     text = Rinternals.CAR(args);
/* 2354 */     if (Rinternals.TYPEOF(text) != 1 && !Rinternals.Rf_isLanguage(text))
/*      */     
/* 2356 */     { if (Rinternals.TYPEOF(text) != 20)
/* 2357 */         text = Rinternals.Rf_coerceVector(text, 16);  } else { text = Rinternals.Rf_coerceVector(text, 20); }
/* 2358 */      Rinternals.Rf_protect(text);
/* 2359 */     n = ntext = Rinternals.Rf_length(text);
/* 2360 */     if (ntext <= 0)
/* 2361 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("text\000".getBytes(), 0) }); 
/* 2362 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2365 */     side = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 13); Rinternals.Rf_protect(side);
/* 2366 */     nside = Rinternals.Rf_length(side);
/* 2367 */     if (nside <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("side\000".getBytes(), 0) }); 
/* 2368 */     if (n < nside) n = nside; 
/* 2369 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2372 */     line = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.Rf_protect(line);
/* 2373 */     nline = Rinternals.Rf_length(line);
/* 2374 */     if (nline <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("line\000".getBytes(), 0) }); 
/* 2375 */     if (n < nline) n = nline; 
/* 2376 */     args = Rinternals.CDR(args);
/*      */ 
/*      */ 
/*      */     
/* 2380 */     outer = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 13); Rinternals.Rf_protect(outer);
/* 2381 */     nouter = Rinternals.Rf_length(outer);
/* 2382 */     if (nouter <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("outer\000".getBytes(), 0) }); 
/* 2383 */     if (n < nouter) n = nouter; 
/* 2384 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2387 */     at = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.Rf_protect(at);
/* 2388 */     nat = Rinternals.Rf_length(at);
/* 2389 */     if (nat <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("at\000".getBytes(), 0) }); 
/* 2390 */     if (n < nat) n = nat; 
/* 2391 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2394 */     adj = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.Rf_protect(adj);
/* 2395 */     nadj = Rinternals.Rf_length(adj);
/* 2396 */     if (nadj <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("adj\000".getBytes(), 0) }); 
/* 2397 */     if (n < nadj) n = nadj; 
/* 2398 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2401 */     padj = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.Rf_protect(padj);
/* 2402 */     npadj = Rinternals.Rf_length(padj);
/* 2403 */     if (npadj <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("padj\000".getBytes(), 0) }); 
/* 2404 */     if (n < npadj) n = npadj; 
/* 2405 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2408 */     cex = FixupCex(Rinternals.CAR(args), 1.0D); Rinternals.Rf_protect(cex);
/* 2409 */     ncex = Rinternals.Rf_length(cex);
/* 2410 */     if (ncex <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("cex\000".getBytes(), 0) }); 
/* 2411 */     if (n < ncex) n = ncex; 
/* 2412 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2415 */     rawcol = Rinternals.CAR(args);
/* 2416 */     col = Rf_FixupCol(rawcol, 16777215); Rinternals.Rf_protect(col);
/* 2417 */     ncol = Rinternals.Rf_length(col);
/* 2418 */     if (ncol <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("col\000".getBytes(), 0) }); 
/* 2419 */     if (n < ncol) n = ncol; 
/* 2420 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 2423 */     R_NaInt$460 = Arith.R_NaInt; font = FixupFont(Rinternals.CAR(args), R_NaInt$460); Rinternals.Rf_protect(font);
/* 2424 */     nfont = Rinternals.Rf_length(font);
/* 2425 */     if (nfont <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("zero-length '%s' specified\000".getBytes(), 0)), new Object[] { new BytePtr("font\000".getBytes(), 0) }); 
/* 2426 */     if (n < nfont) n = nfont; 
/* 2427 */     args = Rinternals.CDR(args);
/*      */     
/* 2429 */     graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 2430 */     par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2435 */     dirtyplot = 0;
/* 2436 */     gpnewsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(0 + 35764);
/* 2437 */     dpnewsave = base__.Rf_dpptr(dd.pointerPlus(dd$offset)).getInt(0 + 35764);
/* 2438 */     cexsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28);
/* 2439 */     fontsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(284);
/* 2440 */     colsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(44);
/*      */ 
/*      */ 
/*      */     
/* 2444 */     if (base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444) <= 0) {
/* 2445 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 1);
/*      */     }
/* 2447 */     if (outer != null) {
/* 2448 */       gpnewsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(0 + 35764);
/* 2449 */       dpnewsave = base__.Rf_dpptr(dd.pointerPlus(dd$offset)).getInt(0 + 35764);
/*      */       
/* 2451 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2);
/*      */     } 
/* 2453 */     graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/*      */     
/* 2455 */     for (i = 0; i < n; i++) {
/* 2456 */       Ptr ptr20 = Rinternals2.REAL(at); int i18 = i % nat * 8; Ptr ptr19 = ptr20; int i17 = 0 + i18; atval = ptr19.getDouble(i17);
/* 2457 */       Ptr ptr18 = Rinternals2.REAL(adj); int i16 = i % nadj * 8; Ptr ptr17 = ptr18; int i15 = 0 + i16; adjval = ptr17.getDouble(i15);
/* 2458 */       Ptr ptr16 = Rinternals2.REAL(padj); int i14 = i % npadj * 8; Ptr ptr15 = ptr16; int i13 = 0 + i14; padjval = ptr15.getDouble(i13);
/* 2459 */       Ptr ptr14 = Rinternals2.REAL(cex); int i12 = i % ncex * 8; Ptr ptr13 = ptr14; int i11 = 0 + i12; cexval = ptr13.getDouble(i11);
/* 2460 */       Ptr ptr12 = Rinternals2.REAL(line); int i10 = i % nline * 8; Ptr ptr11 = ptr12; int i9 = 0 + i10; lineval = ptr11.getDouble(i9);
/* 2461 */       Ptr ptr10 = Rinternals2.INTEGER(outer); int i8 = i % nouter * 4; Ptr ptr9 = ptr10; int i7 = 0 + i8; outerval = ptr9.getInt(i7);
/* 2462 */       Ptr ptr8 = Rinternals2.INTEGER(side); int i6 = i % nside * 4; Ptr ptr7 = ptr8; int i5 = 0 + i6; sideval = ptr7.getInt(i5);
/* 2463 */       Ptr ptr6 = Rinternals2.INTEGER(font); int i4 = i % nfont * 4; Ptr ptr5 = ptr6; int i3 = 0 + i4; fontval = ptr5.getInt(i3);
/* 2464 */       Ptr ptr4 = Rinternals2.INTEGER(col); int i2 = i % ncol * 4; Ptr ptr3 = ptr4; int i1 = 0 + i2; colval = ptr3.getInt(i1);
/*      */       
/* 2466 */       R_NaInt$461 = Arith.R_NaInt; if (outerval == R_NaInt$461) outerval = 0;
/*      */ 
/*      */ 
/*      */       
/* 2470 */       if (Arith.R_finite(cexval) == 0)
/* 2471 */       { cexval = cexsave; } else { base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(28, cexval); }
/* 2472 */        Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); R_NaInt$463 = Arith.R_NaInt; if (fontval != R_NaInt$463) { iftmp$462 = fontval; } else { iftmp$462 = fontsave; }  ptr2.setInt(284, iftmp$462);
/* 2473 */       if (isNAcol(rawcol, i, ncol) == 0)
/*      */       
/*      */       { 
/* 2476 */         Ptr ptr = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); colval$465 = colval; ptr.setInt(44, colval$465); } else { Ptr ptr = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); colsave$464 = colsave; ptr.setInt(44, colsave$464); }
/* 2477 */        Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int m = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(308); double d2 = ComputeAdjValue(adjval, sideval, m); ptr1.setDouble(8, d2);
/* 2478 */       int k = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(308); padjval = ComputePAdjValue(padjval, sideval, k);
/* 2479 */       int j = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(308); double d1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(8); atval = ComputeAtValue(atval, d1, sideval, j, outerval, dd.pointerPlus(dd$offset));
/*      */ 
/*      */       
/* 2482 */       if (Rinternals.TYPEOF(text) != 20)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 2487 */         int i19 = i % ntext; string = Rinternals.STRING_ELT(text, i19);
/* 2488 */         R_NaString$466 = Rinternals.R_NaString; if (string != R_NaString$466) {
/* 2489 */           int i21 = 
/* 2490 */             base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(308), i20 = Rinternals.Rf_getCharCE(string); graphics__.Rf_GMtext((Ptr)Rinternals.R_CHAR(string), i20, sideval, lineval, outerval, atval, i21, padjval, dd.pointerPlus(dd$offset));
/*      */         }  }
/*      */       else { int i20 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(308), i19 = i % ntext; graphics__.Rf_GMMathText(Rinternals.VECTOR_ELT(text, i19), sideval, lineval, outerval, atval, i20, padjval, dd.pointerPlus(dd$offset)); }
/* 2493 */        if (outerval == 0) dirtyplot = 1; 
/*      */     } 
/* 2495 */     graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */     
/* 2497 */     graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/* 2498 */     if (dirtyplot == 0) {
/* 2499 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(0 + 35764, gpnewsave);
/* 2500 */       base__.Rf_dpptr(dd.pointerPlus(dd$offset)).setInt(0 + 35764, dpnewsave);
/*      */     } 
/*      */     
/* 2503 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_title(SEXP args) {
/* 2519 */     col = new int[1]; font = new int[1]; cex = new double[1]; sub = new SEXP[1]; ylab = new SEXP[1]; xlab = new SEXP[1]; Main = new SEXP[1]; dd = BytePtr.of(0); dd$offset = 0; where = 0; outer = 0; n = 0; vpos = 0.0D; hpos = 0.0D; line = 0.0D; offset = 0.0D; adjy = 0.0D; adj = 0.0D; sub[0] = (SEXP)BytePtr.of(0).getArray(); ylab[0] = (SEXP)BytePtr.of(0).getArray(); xlab[0] = (SEXP)BytePtr.of(0).getArray(); Main[0] = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 2521 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 2523 */     args = Rinternals.CDR(args);
/* 2524 */     if (Rinternals.Rf_length(args) <= 5) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     
/* 2526 */     R_NilValue$387 = Rinternals.R_NilValue; ylab[0] = R_NilValue$387; ylab$388 = ylab[0]; xlab[0] = ylab$388; xlab$389 = xlab[0]; sub[0] = xlab$389; sub$390 = sub[0]; Main[0] = sub$390;
/*      */     
/* 2528 */     SEXP sEXP4 = Rinternals.CAR(args); R_NilValue$391 = Rinternals.R_NilValue; if (sEXP4 != R_NilValue$391 && Rinternals.Rf_length(Rinternals.CAR(args)) > 0) {
/* 2529 */       Main$392 = Rinternals.CAR(args); Main[0] = Main$392;
/* 2530 */     }  args = Rinternals.CDR(args);
/*      */     
/* 2532 */     SEXP sEXP3 = Rinternals.CAR(args); R_NilValue$393 = Rinternals.R_NilValue; if (sEXP3 != R_NilValue$393 && Rinternals.Rf_length(Rinternals.CAR(args)) > 0) {
/* 2533 */       sub$394 = Rinternals.CAR(args); sub[0] = sub$394;
/* 2534 */     }  args = Rinternals.CDR(args);
/*      */     
/* 2536 */     SEXP sEXP2 = Rinternals.CAR(args); R_NilValue$395 = Rinternals.R_NilValue; if (sEXP2 != R_NilValue$395 && Rinternals.Rf_length(Rinternals.CAR(args)) > 0) {
/* 2537 */       xlab$396 = Rinternals.CAR(args); xlab[0] = xlab$396;
/* 2538 */     }  args = Rinternals.CDR(args);
/*      */     
/* 2540 */     SEXP sEXP1 = Rinternals.CAR(args); R_NilValue$397 = Rinternals.R_NilValue; if (sEXP1 != R_NilValue$397 && Rinternals.Rf_length(Rinternals.CAR(args)) > 0) {
/* 2541 */       ylab$398 = Rinternals.CAR(args); ylab[0] = ylab$398;
/* 2542 */     }  args = Rinternals.CDR(args);
/*      */     
/* 2544 */     line = Rinternals.Rf_asReal(Rinternals.CAR(args));
/* 2545 */     args = Rinternals.CDR(args);
/*      */     
/* 2547 */     outer = Rinternals.Rf_asLogical(Rinternals.CAR(args));
/* 2548 */     R_NaInt$399 = Arith.R_NaInt; if (outer == R_NaInt$399) outer = 0; 
/* 2549 */     args = Rinternals.CDR(args);
/*      */     
/* 2551 */     graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 2552 */     par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */     
/* 2556 */     if (base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444) <= 0)
/* 2557 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 1); 
/* 2558 */     if (outer != 0)
/* 2559 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2); 
/* 2560 */     adj = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(8);
/*      */     
/* 2562 */     graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/* 2563 */     Main$400 = Main[0]; R_NilValue$401 = Rinternals.R_NilValue; if (Main$400 != R_NilValue$401) {
/* 2564 */       cex$402 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(492); cex[0] = cex$402;
/* 2565 */       col$403 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(540); col[0] = col$403;
/* 2566 */       font$404 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(524); font[0] = font$404;
/*      */       
/* 2568 */       GetTextArg(Main[0], (Ptr)new RecordUnitPtrPtr((Object[])Main, 0), (Ptr)new IntPtr(col, 0), (Ptr)new DoublePtr(cex, 0), (Ptr)new IntPtr(font, 0));
/* 2569 */       Rinternals.Rf_protect(Main[0]);
/* 2570 */       Ptr ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); col$407 = col[0]; ptr3.setInt(44, col$407);
/* 2571 */       Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484); cex$408 = cex[0]; double d1 = d2 * cex$408; ptr2.setDouble(28, d1);
/* 2572 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); font$409 = font[0]; ptr1.setInt(284, font$409);
/* 2573 */       if (outer == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2586 */         if (Arith.R_finite(line) == 0)
/*      */         
/*      */         { 
/*      */ 
/*      */           
/* 2591 */           vpos = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(0 + 35520 + 16) * 0.5D;
/* 2592 */           adjy = 0.5D; }
/*      */         else { vpos = line; adjy = 0.0D; }
/* 2594 */          hpos = graphics__.Rf_GConvertX(adj, 16, 12, dd.pointerPlus(dd$offset));
/* 2595 */         where = 10; } else { if (Arith.R_finite(line) == 0) { vpos = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(0 + 35596 + 16) * 0.5D; adjy = 0.5D; } else { vpos = line; adjy = 0.0D; }
/*      */          hpos = adj; where = 4; }
/* 2597 */        if (Rinternals.TYPEOF(Main[0]) != 20) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2602 */         n = Rinternals.Rf_length(Main[0]);
/* 2603 */         offset = (n + -1) * 0.5D + vpos;
/* 2604 */         for (i = 0; i < n; i++) {
/* 2605 */           string = Rinternals.STRING_ELT(Main[0], i);
/* 2606 */           R_NaString$414 = Rinternals.R_NaString; if (string != R_NaString$414) {
/* 2607 */             int j = Rinternals.Rf_getCharCE(string); BytePtr bytePtr = Rinternals.R_CHAR(string); double d4 = i, d3 = offset - d4; graphics__.Rf_GText(hpos, d3, where, (Ptr)bytePtr, j, adj, adjy, 0.0D, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         SEXP sEXP = Rinternals.VECTOR_ELT(Main[0], 0); graphics__.Rf_GMathText(hpos, vpos, where, sEXP, adj, 0.5D, 0.0D, dd.pointerPlus(dd$offset));
/*      */       } 
/* 2613 */     }  sub$415 = sub[0]; R_NilValue$416 = Rinternals.R_NilValue; if (sub$415 != R_NilValue$416) {
/* 2614 */       cex$417 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(508); cex[0] = cex$417;
/* 2615 */       col$418 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(548); col[0] = col$418;
/* 2616 */       font$419 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(532); font[0] = font$419;
/*      */       
/* 2618 */       GetTextArg(sub[0], (Ptr)new RecordUnitPtrPtr((Object[])sub, 0), (Ptr)new IntPtr(col, 0), (Ptr)new DoublePtr(cex, 0), (Ptr)new IntPtr(font, 0));
/* 2619 */       Rinternals.Rf_protect(sub[0]);
/* 2620 */       Ptr ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); col$422 = col[0]; ptr3.setInt(44, col$422);
/* 2621 */       Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484); cex$423 = cex[0]; double d1 = d2 * cex$423; ptr2.setDouble(28, d1);
/* 2622 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); font$424 = font[0]; ptr1.setInt(284, font$424);
/* 2623 */       if (Arith.R_finite(line) == 0)
/*      */       
/*      */       { 
/* 2626 */         vpos = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(340) + 1.0D; } else { vpos = line; }
/* 2627 */        if (outer == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 2632 */         hpos = graphics__.Rf_GConvertX(adj, 16, 12, dd.pointerPlus(dd$offset));
/* 2633 */         where = 0; }
/*      */       else { hpos = adj; where = 1; }
/* 2635 */        if (Rinternals.TYPEOF(sub[0]) != 20) {
/*      */ 
/*      */ 
/*      */         
/* 2639 */         n = Rinternals.Rf_length(sub[0]);
/* 2640 */         for (i = 0; i < n; i++) {
/* 2641 */           string = Rinternals.STRING_ELT(sub[0], i);
/* 2642 */           R_NaString$429 = Rinternals.R_NaString; if (string != R_NaString$429) {
/* 2643 */             int j = Rinternals.Rf_getCharCE(string); graphics__.Rf_GMtext((Ptr)Rinternals.R_CHAR(string), j, 1, vpos, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         graphics__.Rf_GMMathText(Rinternals.VECTOR_ELT(sub[0], 0), 1, vpos, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */       } 
/* 2649 */     }  xlab$430 = xlab[0]; R_NilValue$431 = Rinternals.R_NilValue; if (xlab$430 != R_NilValue$431) {
/* 2650 */       cex$432 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(500); cex[0] = cex$432;
/* 2651 */       col$433 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(544); col[0] = col$433;
/* 2652 */       font$434 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(528); font[0] = font$434;
/*      */       
/* 2654 */       GetTextArg(xlab[0], (Ptr)new RecordUnitPtrPtr((Object[])xlab, 0), (Ptr)new IntPtr(col, 0), (Ptr)new DoublePtr(cex, 0), (Ptr)new IntPtr(font, 0));
/* 2655 */       Rinternals.Rf_protect(xlab[0]);
/* 2656 */       Ptr ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484); cex$437 = cex[0]; double d1 = d2 * cex$437; ptr3.setDouble(28, d1);
/* 2657 */       Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); col$438 = col[0]; ptr2.setInt(44, col$438);
/* 2658 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); font$439 = font[0]; ptr1.setInt(284, font$439);
/* 2659 */       if (Arith.R_finite(line) == 0)
/*      */       
/*      */       { 
/* 2662 */         vpos = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(340); } else { vpos = line; }
/* 2663 */        if (outer == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 2668 */         hpos = graphics__.Rf_GConvertX(adj, 16, 12, dd.pointerPlus(dd$offset));
/* 2669 */         where = 0; }
/*      */       else { hpos = adj; where = 1; }
/* 2671 */        if (Rinternals.TYPEOF(xlab[0]) != 20) {
/*      */ 
/*      */ 
/*      */         
/* 2675 */         n = Rinternals.Rf_length(xlab[0]);
/* 2676 */         for (i = 0; i < n; i++) {
/* 2677 */           string = Rinternals.STRING_ELT(xlab[0], i);
/* 2678 */           R_NaString$444 = Rinternals.R_NaString; if (string != R_NaString$444) {
/* 2679 */             double d = i + vpos; int j = Rinternals.Rf_getCharCE(string); graphics__.Rf_GMtext((Ptr)Rinternals.R_CHAR(string), j, 1, d, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         graphics__.Rf_GMMathText(Rinternals.VECTOR_ELT(xlab[0], 0), 1, vpos, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */       } 
/* 2685 */     }  ylab$445 = ylab[0]; R_NilValue$446 = Rinternals.R_NilValue; if (ylab$445 != R_NilValue$446) {
/* 2686 */       cex$447 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(500); cex[0] = cex$447;
/* 2687 */       col$448 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(544); col[0] = col$448;
/* 2688 */       font$449 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(528); font[0] = font$449;
/*      */       
/* 2690 */       GetTextArg(ylab[0], (Ptr)new RecordUnitPtrPtr((Object[])ylab, 0), (Ptr)new IntPtr(col, 0), (Ptr)new DoublePtr(cex, 0), (Ptr)new IntPtr(font, 0));
/* 2691 */       Rinternals.Rf_protect(ylab[0]);
/* 2692 */       Ptr ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484); cex$452 = cex[0]; double d1 = d2 * cex$452; ptr3.setDouble(28, d1);
/* 2693 */       Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); col$453 = col[0]; ptr2.setInt(44, col$453);
/* 2694 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); font$454 = font[0]; ptr1.setInt(284, font$454);
/* 2695 */       if (Arith.R_finite(line) == 0)
/*      */       
/*      */       { 
/* 2698 */         vpos = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(340); } else { vpos = line; }
/* 2699 */        if (outer == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 2704 */         hpos = graphics__.Rf_GConvertY(adj, 16, 12, dd.pointerPlus(dd$offset));
/* 2705 */         where = 0; }
/*      */       else { hpos = adj; where = 1; }
/* 2707 */        if (Rinternals.TYPEOF(ylab[0]) != 20) {
/*      */ 
/*      */ 
/*      */         
/* 2711 */         n = Rinternals.Rf_length(ylab[0]);
/* 2712 */         for (i = 0; i < n; i++) {
/* 2713 */           string = Rinternals.STRING_ELT(ylab[0], i);
/* 2714 */           R_NaString$459 = Rinternals.R_NaString; if (string != R_NaString$459) {
/* 2715 */             double d4 = i, d3 = vpos - d4; int j = Rinternals.Rf_getCharCE(string); graphics__.Rf_GMtext((Ptr)Rinternals.R_CHAR(string), j, 2, d3, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         graphics__.Rf_GMMathText(Rinternals.VECTOR_ELT(ylab[0], 0), 2, vpos, where, hpos, 0, 0.0D, dd.pointerPlus(dd$offset));
/*      */       } 
/* 2721 */     }  graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/* 2722 */     graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/* 2723 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_abline(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: bipush #101
/*      */     //   2: newarray double
/*      */     //   4: astore #5
/*      */     //   6: bipush #101
/*      */     //   8: newarray double
/*      */     //   10: astore #6
/*      */     //   12: iconst_2
/*      */     //   13: newarray double
/*      */     //   15: astore #11
/*      */     //   17: iconst_2
/*      */     //   18: newarray double
/*      */     //   20: astore #12
/*      */     //   22: dconst_0
/*      */     //   23: dstore_1
/*      */     //   24: dconst_0
/*      */     //   25: dstore_3
/*      */     //   26: iconst_0
/*      */     //   27: istore #7
/*      */     //   29: iconst_0
/*      */     //   30: istore #8
/*      */     //   32: iconst_0
/*      */     //   33: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   36: astore #9
/*      */     //   38: iconst_0
/*      */     //   39: istore #10
/*      */     //   41: dconst_0
/*      */     //   42: dstore #13
/*      */     //   44: dconst_0
/*      */     //   45: dstore #15
/*      */     //   47: iconst_0
/*      */     //   48: istore #17
/*      */     //   50: iconst_0
/*      */     //   51: istore #18
/*      */     //   53: iconst_0
/*      */     //   54: istore #19
/*      */     //   56: iconst_0
/*      */     //   57: istore #20
/*      */     //   59: iconst_0
/*      */     //   60: istore #21
/*      */     //   62: iconst_0
/*      */     //   63: istore #22
/*      */     //   65: iconst_0
/*      */     //   66: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   69: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   74: checkcast org/renjin/sexp/SEXP
/*      */     //   77: astore #24
/*      */     //   79: iconst_0
/*      */     //   80: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   83: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   88: checkcast org/renjin/sexp/SEXP
/*      */     //   91: astore #25
/*      */     //   93: iconst_0
/*      */     //   94: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   97: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   102: checkcast org/renjin/sexp/SEXP
/*      */     //   105: astore #26
/*      */     //   107: iconst_0
/*      */     //   108: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   111: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   116: checkcast org/renjin/sexp/SEXP
/*      */     //   119: astore #28
/*      */     //   121: iconst_0
/*      */     //   122: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   125: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   130: checkcast org/renjin/sexp/SEXP
/*      */     //   133: astore #29
/*      */     //   135: aload #11
/*      */     //   137: iconst_0
/*      */     //   138: dconst_0
/*      */     //   139: dastore
/*      */     //   140: aload #11
/*      */     //   142: iconst_1
/*      */     //   143: dconst_0
/*      */     //   144: dastore
/*      */     //   145: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   148: astore #9
/*      */     //   150: iconst_0
/*      */     //   151: istore #10
/*      */     //   153: aload #9
/*      */     //   155: iload #10
/*      */     //   157: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   162: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   165: aload_0
/*      */     //   166: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   169: astore_0
/*      */     //   170: aload_0
/*      */     //   171: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   174: iconst_4
/*      */     //   175: if_icmple -> 181
/*      */     //   178: goto -> 220
/*      */     //   181: new org/renjin/gcc/runtime/BytePtr
/*      */     //   184: dup
/*      */     //   185: ldc 'graphics '
/*      */     //   187: invokevirtual getBytes : ()[B
/*      */     //   190: iconst_0
/*      */     //   191: invokespecial <init> : ([BI)V
/*      */     //   194: new org/renjin/gcc/runtime/BytePtr
/*      */     //   197: dup
/*      */     //   198: ldc 'too few arguments '
/*      */     //   200: invokevirtual getBytes : ()[B
/*      */     //   203: iconst_0
/*      */     //   204: invokespecial <init> : ([BI)V
/*      */     //   207: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   210: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   213: iconst_0
/*      */     //   214: anewarray java/lang/Object
/*      */     //   217: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   220: aload_0
/*      */     //   221: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   224: astore #31
/*      */     //   226: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   229: wide astore #327
/*      */     //   233: aload #31
/*      */     //   235: wide aload #327
/*      */     //   239: if_acmpeq -> 261
/*      */     //   242: goto -> 245
/*      */     //   245: aload #31
/*      */     //   247: bipush #14
/*      */     //   249: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   252: astore #31
/*      */     //   254: aload_0
/*      */     //   255: aload #31
/*      */     //   257: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   260: pop
/*      */     //   261: aload_0
/*      */     //   262: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   265: astore_0
/*      */     //   266: aload_0
/*      */     //   267: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   270: astore #30
/*      */     //   272: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   275: wide astore #326
/*      */     //   279: aload #30
/*      */     //   281: wide aload #326
/*      */     //   285: if_acmpeq -> 307
/*      */     //   288: goto -> 291
/*      */     //   291: aload #30
/*      */     //   293: bipush #14
/*      */     //   295: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   298: astore #30
/*      */     //   300: aload_0
/*      */     //   301: aload #30
/*      */     //   303: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   306: pop
/*      */     //   307: aload_0
/*      */     //   308: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   311: astore_0
/*      */     //   312: aload_0
/*      */     //   313: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   316: astore #29
/*      */     //   318: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   321: wide astore #325
/*      */     //   325: aload #29
/*      */     //   327: wide aload #325
/*      */     //   331: if_acmpeq -> 353
/*      */     //   334: goto -> 337
/*      */     //   337: aload #29
/*      */     //   339: bipush #14
/*      */     //   341: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   344: astore #29
/*      */     //   346: aload_0
/*      */     //   347: aload #29
/*      */     //   349: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   352: pop
/*      */     //   353: aload_0
/*      */     //   354: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   357: astore_0
/*      */     //   358: aload_0
/*      */     //   359: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   362: astore #28
/*      */     //   364: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   367: wide astore #324
/*      */     //   371: aload #28
/*      */     //   373: wide aload #324
/*      */     //   377: if_acmpeq -> 399
/*      */     //   380: goto -> 383
/*      */     //   383: aload #28
/*      */     //   385: bipush #14
/*      */     //   387: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   390: astore #28
/*      */     //   392: aload_0
/*      */     //   393: aload #28
/*      */     //   395: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   398: pop
/*      */     //   399: aload_0
/*      */     //   400: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   403: astore_0
/*      */     //   404: aload_0
/*      */     //   405: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   408: astore #27
/*      */     //   410: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   413: wide astore #323
/*      */     //   417: aload #27
/*      */     //   419: wide aload #323
/*      */     //   423: if_acmpeq -> 445
/*      */     //   426: goto -> 429
/*      */     //   429: aload #27
/*      */     //   431: bipush #10
/*      */     //   433: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   436: astore #27
/*      */     //   438: aload_0
/*      */     //   439: aload #27
/*      */     //   441: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   444: pop
/*      */     //   445: aload_0
/*      */     //   446: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   449: astore_0
/*      */     //   450: aload_0
/*      */     //   451: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   454: ldc 16777215
/*      */     //   456: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   459: astore #26
/*      */     //   461: aload #26
/*      */     //   463: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   466: pop
/*      */     //   467: aload_0
/*      */     //   468: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   471: astore_0
/*      */     //   472: aload #26
/*      */     //   474: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   477: istore #22
/*      */     //   479: aload #9
/*      */     //   481: iload #10
/*      */     //   483: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   488: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   491: sipush #312
/*      */     //   494: invokeinterface getInt : (I)I
/*      */     //   499: wide istore #319
/*      */     //   503: aload_0
/*      */     //   504: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   507: wide iload #319
/*      */     //   511: invokestatic Rf_FixupLty : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   514: astore #25
/*      */     //   516: aload #25
/*      */     //   518: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   521: pop
/*      */     //   522: aload_0
/*      */     //   523: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   526: astore_0
/*      */     //   527: aload #25
/*      */     //   529: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   532: istore #20
/*      */     //   534: aload #9
/*      */     //   536: iload #10
/*      */     //   538: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   543: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   546: sipush #316
/*      */     //   549: invokeinterface getDouble : (I)D
/*      */     //   554: wide dstore #314
/*      */     //   558: aload_0
/*      */     //   559: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   562: wide dload #314
/*      */     //   566: invokestatic Rf_FixupLwd : (Lorg/renjin/sexp/SEXP;D)Lorg/renjin/sexp/SEXP;
/*      */     //   569: astore #24
/*      */     //   571: aload #24
/*      */     //   573: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   576: pop
/*      */     //   577: aload_0
/*      */     //   578: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   581: astore_0
/*      */     //   582: aload #24
/*      */     //   584: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   587: istore #19
/*      */     //   589: aload #9
/*      */     //   591: iload #10
/*      */     //   593: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   598: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   601: aload_0
/*      */     //   602: aload #9
/*      */     //   604: iload #10
/*      */     //   606: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   611: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   614: iconst_0
/*      */     //   615: istore #21
/*      */     //   617: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   620: wide astore #312
/*      */     //   624: aload #31
/*      */     //   626: wide aload #312
/*      */     //   630: if_acmpeq -> 1845
/*      */     //   633: goto -> 636
/*      */     //   636: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   639: wide astore #311
/*      */     //   643: aload #30
/*      */     //   645: wide aload #311
/*      */     //   649: if_acmpeq -> 655
/*      */     //   652: goto -> 736
/*      */     //   655: aload #31
/*      */     //   657: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   660: iconst_2
/*      */     //   661: if_icmpne -> 667
/*      */     //   664: goto -> 707
/*      */     //   667: new org/renjin/gcc/runtime/BytePtr
/*      */     //   670: dup
/*      */     //   671: ldc 'graphics '
/*      */     //   673: invokevirtual getBytes : ()[B
/*      */     //   676: iconst_0
/*      */     //   677: invokespecial <init> : ([BI)V
/*      */     //   680: new org/renjin/gcc/runtime/BytePtr
/*      */     //   683: dup
/*      */     //   684: ldc_w 'invalid a=, b= specification '
/*      */     //   687: invokevirtual getBytes : ()[B
/*      */     //   690: iconst_0
/*      */     //   691: invokespecial <init> : ([BI)V
/*      */     //   694: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   697: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   700: iconst_0
/*      */     //   701: anewarray java/lang/Object
/*      */     //   704: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   707: aload #31
/*      */     //   709: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   712: invokeinterface getDouble : ()D
/*      */     //   717: dstore #15
/*      */     //   719: aload #31
/*      */     //   721: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   724: bipush #8
/*      */     //   726: invokeinterface getDouble : (I)D
/*      */     //   731: dstore #13
/*      */     //   733: goto -> 750
/*      */     //   736: aload #31
/*      */     //   738: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   741: dstore #15
/*      */     //   743: aload #30
/*      */     //   745: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   748: dstore #13
/*      */     //   750: dload #15
/*      */     //   752: invokestatic R_finite : (D)I
/*      */     //   755: ifeq -> 772
/*      */     //   758: goto -> 761
/*      */     //   761: dload #13
/*      */     //   763: invokestatic R_finite : (D)I
/*      */     //   766: ifeq -> 772
/*      */     //   769: goto -> 812
/*      */     //   772: new org/renjin/gcc/runtime/BytePtr
/*      */     //   775: dup
/*      */     //   776: ldc 'graphics '
/*      */     //   778: invokevirtual getBytes : ()[B
/*      */     //   781: iconst_0
/*      */     //   782: invokespecial <init> : ([BI)V
/*      */     //   785: new org/renjin/gcc/runtime/BytePtr
/*      */     //   788: dup
/*      */     //   789: ldc_w ''a' and 'b' must be finite '
/*      */     //   792: invokevirtual getBytes : ()[B
/*      */     //   795: iconst_0
/*      */     //   796: invokespecial <init> : ([BI)V
/*      */     //   799: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   802: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   805: iconst_0
/*      */     //   806: anewarray java/lang/Object
/*      */     //   809: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   812: aload #9
/*      */     //   814: iload #10
/*      */     //   816: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   821: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   824: wide astore #298
/*      */     //   828: aload #26
/*      */     //   830: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   833: invokeinterface getInt : ()I
/*      */     //   838: wide istore #294
/*      */     //   842: wide aload #298
/*      */     //   846: bipush #44
/*      */     //   848: wide iload #294
/*      */     //   852: invokeinterface setInt : (II)V
/*      */     //   857: aload #9
/*      */     //   859: iload #10
/*      */     //   861: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   866: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   869: wide astore #292
/*      */     //   873: aload #24
/*      */     //   875: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   878: invokeinterface getDouble : ()D
/*      */     //   883: wide dstore #288
/*      */     //   887: wide aload #292
/*      */     //   891: sipush #316
/*      */     //   894: wide dload #288
/*      */     //   898: invokeinterface setDouble : (ID)V
/*      */     //   903: iload #20
/*      */     //   905: ifne -> 911
/*      */     //   908: goto -> 995
/*      */     //   911: aload #25
/*      */     //   913: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   916: invokeinterface getInt : ()I
/*      */     //   921: wide istore #285
/*      */     //   925: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   928: wide istore #284
/*      */     //   932: wide iload #285
/*      */     //   936: wide iload #284
/*      */     //   940: if_icmpne -> 946
/*      */     //   943: goto -> 995
/*      */     //   946: aload #9
/*      */     //   948: iload #10
/*      */     //   950: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   955: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   958: wide astore #282
/*      */     //   962: aload #25
/*      */     //   964: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   967: invokeinterface getInt : ()I
/*      */     //   972: wide istore #279
/*      */     //   976: wide aload #282
/*      */     //   980: sipush #312
/*      */     //   983: wide iload #279
/*      */     //   987: invokeinterface setInt : (II)V
/*      */     //   992: goto -> 1051
/*      */     //   995: aload #9
/*      */     //   997: iload #10
/*      */     //   999: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1004: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1007: wide astore #277
/*      */     //   1011: aload #9
/*      */     //   1013: iload #10
/*      */     //   1015: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1020: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1023: sipush #312
/*      */     //   1026: invokeinterface getInt : (I)I
/*      */     //   1031: wide istore #274
/*      */     //   1035: wide aload #277
/*      */     //   1039: sipush #312
/*      */     //   1042: wide iload #274
/*      */     //   1046: invokeinterface setInt : (II)V
/*      */     //   1051: iconst_1
/*      */     //   1052: aload #9
/*      */     //   1054: iload #10
/*      */     //   1056: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1061: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1064: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1067: dup
/*      */     //   1068: aload #12
/*      */     //   1070: iconst_0
/*      */     //   1071: invokespecial <init> : ([DI)V
/*      */     //   1074: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1077: aload #9
/*      */     //   1079: iload #10
/*      */     //   1081: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1086: invokestatic getxlimits : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1089: aload #9
/*      */     //   1091: iload #10
/*      */     //   1093: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1098: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1101: sipush #316
/*      */     //   1104: invokeinterface getDouble : (I)D
/*      */     //   1109: invokestatic R_finite : (D)I
/*      */     //   1112: ifne -> 1118
/*      */     //   1115: goto -> 1829
/*      */     //   1118: aload #9
/*      */     //   1120: iload #10
/*      */     //   1122: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1127: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1130: sipush #440
/*      */     //   1133: invokeinterface getInt : (I)I
/*      */     //   1138: istore #8
/*      */     //   1140: aload #9
/*      */     //   1142: iload #10
/*      */     //   1144: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1149: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1152: sipush #480
/*      */     //   1155: invokeinterface getInt : (I)I
/*      */     //   1160: istore #7
/*      */     //   1162: aload #27
/*      */     //   1164: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   1167: invokeinterface getInt : ()I
/*      */     //   1172: ifne -> 1178
/*      */     //   1175: goto -> 1651
/*      */     //   1178: iload #8
/*      */     //   1180: ifne -> 1194
/*      */     //   1183: goto -> 1186
/*      */     //   1186: iload #7
/*      */     //   1188: ifne -> 1194
/*      */     //   1191: goto -> 1651
/*      */     //   1194: iload #8
/*      */     //   1196: ifne -> 1202
/*      */     //   1199: goto -> 1316
/*      */     //   1202: aload #12
/*      */     //   1204: iconst_1
/*      */     //   1205: daload
/*      */     //   1206: ldc2_w 1.7976931348623157E308
/*      */     //   1209: ddiv
/*      */     //   1210: dstore_3
/*      */     //   1211: dload_3
/*      */     //   1212: ldc2_w 1.01
/*      */     //   1215: dmul
/*      */     //   1216: wide dstore #258
/*      */     //   1220: aload #12
/*      */     //   1222: iconst_0
/*      */     //   1223: daload
/*      */     //   1224: wide dload #258
/*      */     //   1228: invokestatic Rf_fmax2 : (DD)D
/*      */     //   1231: dstore #254
/*      */     //   1233: aload #12
/*      */     //   1235: iconst_0
/*      */     //   1236: dload #254
/*      */     //   1238: dastore
/*      */     //   1239: aload #12
/*      */     //   1241: iconst_0
/*      */     //   1242: daload
/*      */     //   1243: dstore #252
/*      */     //   1245: aload #6
/*      */     //   1247: iconst_0
/*      */     //   1248: dload #252
/*      */     //   1250: dastore
/*      */     //   1251: aload #12
/*      */     //   1253: iconst_1
/*      */     //   1254: daload
/*      */     //   1255: dstore #250
/*      */     //   1257: aload #12
/*      */     //   1259: iconst_0
/*      */     //   1260: daload
/*      */     //   1261: dstore #248
/*      */     //   1263: dload #250
/*      */     //   1265: dload #248
/*      */     //   1267: ddiv
/*      */     //   1268: ldc2_w 0.01
/*      */     //   1271: invokestatic pow : (DD)D
/*      */     //   1274: dstore_3
/*      */     //   1275: iconst_1
/*      */     //   1276: istore #23
/*      */     //   1278: goto -> 1306
/*      */     //   1281: iload #23
/*      */     //   1283: iconst_m1
/*      */     //   1284: iadd
/*      */     //   1285: istore #245
/*      */     //   1287: aload #6
/*      */     //   1289: iload #245
/*      */     //   1291: daload
/*      */     //   1292: dload_3
/*      */     //   1293: dmul
/*      */     //   1294: dstore #241
/*      */     //   1296: aload #6
/*      */     //   1298: iload #23
/*      */     //   1300: dload #241
/*      */     //   1302: dastore
/*      */     //   1303: iinc #23, 1
/*      */     //   1306: iload #23
/*      */     //   1308: bipush #99
/*      */     //   1310: if_icmple -> 1281
/*      */     //   1313: goto -> 1384
/*      */     //   1316: aload #12
/*      */     //   1318: iconst_1
/*      */     //   1319: daload
/*      */     //   1320: dstore #239
/*      */     //   1322: aload #12
/*      */     //   1324: iconst_0
/*      */     //   1325: daload
/*      */     //   1326: dstore #237
/*      */     //   1328: dload #239
/*      */     //   1330: dload #237
/*      */     //   1332: dsub
/*      */     //   1333: ldc2_w 100.0
/*      */     //   1336: ddiv
/*      */     //   1337: dstore_1
/*      */     //   1338: iconst_0
/*      */     //   1339: istore #23
/*      */     //   1341: goto -> 1374
/*      */     //   1344: aload #12
/*      */     //   1346: iconst_0
/*      */     //   1347: daload
/*      */     //   1348: dstore #233
/*      */     //   1350: iload #23
/*      */     //   1352: i2d
/*      */     //   1353: dload_1
/*      */     //   1354: dmul
/*      */     //   1355: dstore #229
/*      */     //   1357: dload #233
/*      */     //   1359: dload #229
/*      */     //   1361: dadd
/*      */     //   1362: dstore #227
/*      */     //   1364: aload #6
/*      */     //   1366: iload #23
/*      */     //   1368: dload #227
/*      */     //   1370: dastore
/*      */     //   1371: iinc #23, 1
/*      */     //   1374: iload #23
/*      */     //   1376: bipush #99
/*      */     //   1378: if_icmple -> 1344
/*      */     //   1381: goto -> 1384
/*      */     //   1384: aload #12
/*      */     //   1386: iconst_1
/*      */     //   1387: daload
/*      */     //   1388: dstore #225
/*      */     //   1390: aload #6
/*      */     //   1392: bipush #100
/*      */     //   1394: dload #225
/*      */     //   1396: dastore
/*      */     //   1397: iconst_0
/*      */     //   1398: istore #23
/*      */     //   1400: goto -> 1426
/*      */     //   1403: aload #6
/*      */     //   1405: iload #23
/*      */     //   1407: daload
/*      */     //   1408: dload #13
/*      */     //   1410: dmul
/*      */     //   1411: dload #15
/*      */     //   1413: dadd
/*      */     //   1414: dstore #219
/*      */     //   1416: aload #5
/*      */     //   1418: iload #23
/*      */     //   1420: dload #219
/*      */     //   1422: dastore
/*      */     //   1423: iinc #23, 1
/*      */     //   1426: iload #23
/*      */     //   1428: bipush #100
/*      */     //   1430: if_icmple -> 1403
/*      */     //   1433: goto -> 1436
/*      */     //   1436: iconst_0
/*      */     //   1437: istore #18
/*      */     //   1439: bipush #100
/*      */     //   1441: istore #17
/*      */     //   1443: iload #8
/*      */     //   1445: ifne -> 1451
/*      */     //   1448: goto -> 1510
/*      */     //   1451: goto -> 1457
/*      */     //   1454: iinc #18, 1
/*      */     //   1457: iload #18
/*      */     //   1459: bipush #100
/*      */     //   1461: if_icmple -> 1467
/*      */     //   1464: goto -> 1480
/*      */     //   1467: aload #6
/*      */     //   1469: iload #18
/*      */     //   1471: daload
/*      */     //   1472: dconst_0
/*      */     //   1473: dcmpg
/*      */     //   1474: ifle -> 1454
/*      */     //   1477: goto -> 1480
/*      */     //   1480: goto -> 1489
/*      */     //   1483: iload #17
/*      */     //   1485: iconst_1
/*      */     //   1486: isub
/*      */     //   1487: istore #17
/*      */     //   1489: iload #17
/*      */     //   1491: ifgt -> 1497
/*      */     //   1494: goto -> 1510
/*      */     //   1497: aload #6
/*      */     //   1499: iload #17
/*      */     //   1501: daload
/*      */     //   1502: dconst_0
/*      */     //   1503: dcmpg
/*      */     //   1504: ifle -> 1483
/*      */     //   1507: goto -> 1510
/*      */     //   1510: iload #7
/*      */     //   1512: ifne -> 1518
/*      */     //   1515: goto -> 1577
/*      */     //   1518: goto -> 1524
/*      */     //   1521: iinc #18, 1
/*      */     //   1524: iload #18
/*      */     //   1526: bipush #100
/*      */     //   1528: if_icmple -> 1534
/*      */     //   1531: goto -> 1547
/*      */     //   1534: aload #5
/*      */     //   1536: iload #18
/*      */     //   1538: daload
/*      */     //   1539: dconst_0
/*      */     //   1540: dcmpg
/*      */     //   1541: ifle -> 1521
/*      */     //   1544: goto -> 1547
/*      */     //   1547: goto -> 1556
/*      */     //   1550: iload #17
/*      */     //   1552: iconst_1
/*      */     //   1553: isub
/*      */     //   1554: istore #17
/*      */     //   1556: iload #17
/*      */     //   1558: ifgt -> 1564
/*      */     //   1561: goto -> 1577
/*      */     //   1564: aload #5
/*      */     //   1566: iload #17
/*      */     //   1568: daload
/*      */     //   1569: dconst_0
/*      */     //   1570: dcmpg
/*      */     //   1571: ifle -> 1550
/*      */     //   1574: goto -> 1577
/*      */     //   1577: iload #18
/*      */     //   1579: bipush #8
/*      */     //   1581: imul
/*      */     //   1582: istore #209
/*      */     //   1584: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1587: dup
/*      */     //   1588: aload #5
/*      */     //   1590: iload #209
/*      */     //   1592: bipush #8
/*      */     //   1594: idiv
/*      */     //   1595: invokespecial <init> : ([DI)V
/*      */     //   1598: astore #207
/*      */     //   1600: iload #18
/*      */     //   1602: bipush #8
/*      */     //   1604: imul
/*      */     //   1605: istore #205
/*      */     //   1607: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1610: dup
/*      */     //   1611: aload #6
/*      */     //   1613: iload #205
/*      */     //   1615: bipush #8
/*      */     //   1617: idiv
/*      */     //   1618: invokespecial <init> : ([DI)V
/*      */     //   1621: astore #203
/*      */     //   1623: iload #17
/*      */     //   1625: iload #18
/*      */     //   1627: isub
/*      */     //   1628: iconst_1
/*      */     //   1629: iadd
/*      */     //   1630: aload #203
/*      */     //   1632: aload #207
/*      */     //   1634: bipush #12
/*      */     //   1636: aload #9
/*      */     //   1638: iload #10
/*      */     //   1640: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1645: invokestatic Rf_GPolyline : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1648: goto -> 1829
/*      */     //   1651: iload #8
/*      */     //   1653: ifne -> 1659
/*      */     //   1656: goto -> 1671
/*      */     //   1659: aload #12
/*      */     //   1661: iconst_0
/*      */     //   1662: daload
/*      */     //   1663: invokestatic log10 : (D)D
/*      */     //   1666: dstore #199
/*      */     //   1668: goto -> 1677
/*      */     //   1671: aload #12
/*      */     //   1673: iconst_0
/*      */     //   1674: daload
/*      */     //   1675: dstore #199
/*      */     //   1677: dload #199
/*      */     //   1679: dload #13
/*      */     //   1681: dmul
/*      */     //   1682: dload #15
/*      */     //   1684: dadd
/*      */     //   1685: dstore #193
/*      */     //   1687: aload #11
/*      */     //   1689: iconst_0
/*      */     //   1690: dload #193
/*      */     //   1692: dastore
/*      */     //   1693: iload #8
/*      */     //   1695: ifne -> 1701
/*      */     //   1698: goto -> 1713
/*      */     //   1701: aload #12
/*      */     //   1703: iconst_1
/*      */     //   1704: daload
/*      */     //   1705: invokestatic log10 : (D)D
/*      */     //   1708: dstore #191
/*      */     //   1710: goto -> 1719
/*      */     //   1713: aload #12
/*      */     //   1715: iconst_1
/*      */     //   1716: daload
/*      */     //   1717: dstore #191
/*      */     //   1719: dload #191
/*      */     //   1721: dload #13
/*      */     //   1723: dmul
/*      */     //   1724: dload #15
/*      */     //   1726: dadd
/*      */     //   1727: dstore #185
/*      */     //   1729: aload #11
/*      */     //   1731: iconst_1
/*      */     //   1732: dload #185
/*      */     //   1734: dastore
/*      */     //   1735: iload #7
/*      */     //   1737: ifne -> 1743
/*      */     //   1740: goto -> 1787
/*      */     //   1743: aload #11
/*      */     //   1745: iconst_0
/*      */     //   1746: daload
/*      */     //   1747: dstore #183
/*      */     //   1749: ldc2_w 10.0
/*      */     //   1752: dload #183
/*      */     //   1754: invokestatic pow : (DD)D
/*      */     //   1757: dstore #181
/*      */     //   1759: aload #11
/*      */     //   1761: iconst_0
/*      */     //   1762: dload #181
/*      */     //   1764: dastore
/*      */     //   1765: aload #11
/*      */     //   1767: iconst_1
/*      */     //   1768: daload
/*      */     //   1769: dstore #179
/*      */     //   1771: ldc2_w 10.0
/*      */     //   1774: dload #179
/*      */     //   1776: invokestatic pow : (DD)D
/*      */     //   1779: dstore #177
/*      */     //   1781: aload #11
/*      */     //   1783: iconst_1
/*      */     //   1784: dload #177
/*      */     //   1786: dastore
/*      */     //   1787: aload #11
/*      */     //   1789: iconst_1
/*      */     //   1790: daload
/*      */     //   1791: dstore #175
/*      */     //   1793: aload #12
/*      */     //   1795: iconst_1
/*      */     //   1796: daload
/*      */     //   1797: dstore #173
/*      */     //   1799: aload #11
/*      */     //   1801: iconst_0
/*      */     //   1802: daload
/*      */     //   1803: dstore #171
/*      */     //   1805: aload #12
/*      */     //   1807: iconst_0
/*      */     //   1808: daload
/*      */     //   1809: dload #171
/*      */     //   1811: dload #173
/*      */     //   1813: dload #175
/*      */     //   1815: bipush #12
/*      */     //   1817: aload #9
/*      */     //   1819: iload #10
/*      */     //   1821: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1826: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1829: iconst_0
/*      */     //   1830: aload #9
/*      */     //   1832: iload #10
/*      */     //   1834: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1839: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1842: iinc #21, 1
/*      */     //   1845: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   1848: astore #168
/*      */     //   1850: aload #29
/*      */     //   1852: aload #168
/*      */     //   1854: if_acmpeq -> 2365
/*      */     //   1857: goto -> 1860
/*      */     //   1860: iconst_1
/*      */     //   1861: aload #9
/*      */     //   1863: iload #10
/*      */     //   1865: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1870: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1873: iconst_0
/*      */     //   1874: istore #23
/*      */     //   1876: goto -> 2339
/*      */     //   1879: aload #9
/*      */     //   1881: iload #10
/*      */     //   1883: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1888: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1891: astore #166
/*      */     //   1893: aload #26
/*      */     //   1895: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1898: astore #164
/*      */     //   1900: iload #21
/*      */     //   1902: iload #22
/*      */     //   1904: irem
/*      */     //   1905: iconst_4
/*      */     //   1906: imul
/*      */     //   1907: istore #161
/*      */     //   1909: aload #164
/*      */     //   1911: astore #159
/*      */     //   1913: iconst_0
/*      */     //   1914: iload #161
/*      */     //   1916: iadd
/*      */     //   1917: istore #160
/*      */     //   1919: aload #159
/*      */     //   1921: iload #160
/*      */     //   1923: invokeinterface getInt : (I)I
/*      */     //   1928: istore #157
/*      */     //   1930: aload #166
/*      */     //   1932: bipush #44
/*      */     //   1934: iload #157
/*      */     //   1936: invokeinterface setInt : (II)V
/*      */     //   1941: iload #20
/*      */     //   1943: ifne -> 1949
/*      */     //   1946: goto -> 2067
/*      */     //   1949: aload #25
/*      */     //   1951: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1954: astore #155
/*      */     //   1956: iload #21
/*      */     //   1958: iload #20
/*      */     //   1960: irem
/*      */     //   1961: iconst_4
/*      */     //   1962: imul
/*      */     //   1963: istore #152
/*      */     //   1965: aload #155
/*      */     //   1967: astore #150
/*      */     //   1969: iconst_0
/*      */     //   1970: iload #152
/*      */     //   1972: iadd
/*      */     //   1973: istore #151
/*      */     //   1975: aload #150
/*      */     //   1977: iload #151
/*      */     //   1979: invokeinterface getInt : (I)I
/*      */     //   1984: istore #149
/*      */     //   1986: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1989: istore #148
/*      */     //   1991: iload #149
/*      */     //   1993: iload #148
/*      */     //   1995: if_icmpne -> 2001
/*      */     //   1998: goto -> 2067
/*      */     //   2001: aload #9
/*      */     //   2003: iload #10
/*      */     //   2005: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2010: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2013: astore #146
/*      */     //   2015: aload #25
/*      */     //   2017: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2020: astore #144
/*      */     //   2022: iload #21
/*      */     //   2024: iload #20
/*      */     //   2026: irem
/*      */     //   2027: iconst_4
/*      */     //   2028: imul
/*      */     //   2029: istore #141
/*      */     //   2031: aload #144
/*      */     //   2033: astore #139
/*      */     //   2035: iconst_0
/*      */     //   2036: iload #141
/*      */     //   2038: iadd
/*      */     //   2039: istore #140
/*      */     //   2041: aload #139
/*      */     //   2043: iload #140
/*      */     //   2045: invokeinterface getInt : (I)I
/*      */     //   2050: istore #138
/*      */     //   2052: aload #146
/*      */     //   2054: sipush #312
/*      */     //   2057: iload #138
/*      */     //   2059: invokeinterface setInt : (II)V
/*      */     //   2064: goto -> 2115
/*      */     //   2067: aload #9
/*      */     //   2069: iload #10
/*      */     //   2071: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2076: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2079: astore #136
/*      */     //   2081: aload #9
/*      */     //   2083: iload #10
/*      */     //   2085: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2090: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2093: sipush #312
/*      */     //   2096: invokeinterface getInt : (I)I
/*      */     //   2101: istore #133
/*      */     //   2103: aload #136
/*      */     //   2105: sipush #312
/*      */     //   2108: iload #133
/*      */     //   2110: invokeinterface setInt : (II)V
/*      */     //   2115: aload #9
/*      */     //   2117: iload #10
/*      */     //   2119: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2124: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2127: astore #131
/*      */     //   2129: aload #24
/*      */     //   2131: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2134: astore #129
/*      */     //   2136: iload #21
/*      */     //   2138: iload #19
/*      */     //   2140: irem
/*      */     //   2141: bipush #8
/*      */     //   2143: imul
/*      */     //   2144: istore #126
/*      */     //   2146: aload #129
/*      */     //   2148: astore #124
/*      */     //   2150: iconst_0
/*      */     //   2151: iload #126
/*      */     //   2153: iadd
/*      */     //   2154: istore #125
/*      */     //   2156: aload #124
/*      */     //   2158: iload #125
/*      */     //   2160: invokeinterface getDouble : (I)D
/*      */     //   2165: dstore #122
/*      */     //   2167: aload #131
/*      */     //   2169: sipush #316
/*      */     //   2172: dload #122
/*      */     //   2174: invokeinterface setDouble : (ID)V
/*      */     //   2179: aload #29
/*      */     //   2181: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2184: astore #120
/*      */     //   2186: iload #23
/*      */     //   2188: bipush #8
/*      */     //   2190: imul
/*      */     //   2191: istore #118
/*      */     //   2193: aload #120
/*      */     //   2195: astore #116
/*      */     //   2197: iconst_0
/*      */     //   2198: iload #118
/*      */     //   2200: iadd
/*      */     //   2201: istore #117
/*      */     //   2203: aload #116
/*      */     //   2205: iload #117
/*      */     //   2207: invokeinterface getDouble : (I)D
/*      */     //   2212: dstore #15
/*      */     //   2214: dload #15
/*      */     //   2216: invokestatic R_finite : (D)I
/*      */     //   2219: ifne -> 2225
/*      */     //   2222: goto -> 2333
/*      */     //   2225: aload #9
/*      */     //   2227: iload #10
/*      */     //   2229: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2234: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2237: sipush #316
/*      */     //   2240: invokeinterface getDouble : (I)D
/*      */     //   2245: invokestatic R_finite : (D)I
/*      */     //   2248: ifne -> 2254
/*      */     //   2251: goto -> 2333
/*      */     //   2254: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2257: dup
/*      */     //   2258: aload #12
/*      */     //   2260: iconst_0
/*      */     //   2261: invokespecial <init> : ([DI)V
/*      */     //   2264: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2267: aload #9
/*      */     //   2269: iload #10
/*      */     //   2271: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2276: invokestatic getxlimits : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2279: aload #11
/*      */     //   2281: iconst_0
/*      */     //   2282: dload #15
/*      */     //   2284: dastore
/*      */     //   2285: aload #11
/*      */     //   2287: iconst_1
/*      */     //   2288: dload #15
/*      */     //   2290: dastore
/*      */     //   2291: aload #11
/*      */     //   2293: iconst_1
/*      */     //   2294: daload
/*      */     //   2295: dstore #108
/*      */     //   2297: aload #12
/*      */     //   2299: iconst_1
/*      */     //   2300: daload
/*      */     //   2301: dstore #106
/*      */     //   2303: aload #11
/*      */     //   2305: iconst_0
/*      */     //   2306: daload
/*      */     //   2307: dstore #104
/*      */     //   2309: aload #12
/*      */     //   2311: iconst_0
/*      */     //   2312: daload
/*      */     //   2313: dload #104
/*      */     //   2315: dload #106
/*      */     //   2317: dload #108
/*      */     //   2319: bipush #12
/*      */     //   2321: aload #9
/*      */     //   2323: iload #10
/*      */     //   2325: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2330: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2333: iinc #21, 1
/*      */     //   2336: iinc #23, 1
/*      */     //   2339: aload #29
/*      */     //   2341: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2344: iload #23
/*      */     //   2346: if_icmpgt -> 1879
/*      */     //   2349: goto -> 2352
/*      */     //   2352: iconst_0
/*      */     //   2353: aload #9
/*      */     //   2355: iload #10
/*      */     //   2357: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2362: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2365: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   2368: astore #100
/*      */     //   2370: aload #28
/*      */     //   2372: aload #100
/*      */     //   2374: if_acmpeq -> 2885
/*      */     //   2377: goto -> 2380
/*      */     //   2380: iconst_1
/*      */     //   2381: aload #9
/*      */     //   2383: iload #10
/*      */     //   2385: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2390: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2393: iconst_0
/*      */     //   2394: istore #23
/*      */     //   2396: goto -> 2859
/*      */     //   2399: aload #9
/*      */     //   2401: iload #10
/*      */     //   2403: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2408: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2411: astore #98
/*      */     //   2413: aload #26
/*      */     //   2415: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2418: astore #96
/*      */     //   2420: iload #21
/*      */     //   2422: iload #22
/*      */     //   2424: irem
/*      */     //   2425: iconst_4
/*      */     //   2426: imul
/*      */     //   2427: istore #93
/*      */     //   2429: aload #96
/*      */     //   2431: astore #91
/*      */     //   2433: iconst_0
/*      */     //   2434: iload #93
/*      */     //   2436: iadd
/*      */     //   2437: istore #92
/*      */     //   2439: aload #91
/*      */     //   2441: iload #92
/*      */     //   2443: invokeinterface getInt : (I)I
/*      */     //   2448: istore #89
/*      */     //   2450: aload #98
/*      */     //   2452: bipush #44
/*      */     //   2454: iload #89
/*      */     //   2456: invokeinterface setInt : (II)V
/*      */     //   2461: iload #20
/*      */     //   2463: ifne -> 2469
/*      */     //   2466: goto -> 2587
/*      */     //   2469: aload #25
/*      */     //   2471: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2474: astore #87
/*      */     //   2476: iload #21
/*      */     //   2478: iload #20
/*      */     //   2480: irem
/*      */     //   2481: iconst_4
/*      */     //   2482: imul
/*      */     //   2483: istore #84
/*      */     //   2485: aload #87
/*      */     //   2487: astore #82
/*      */     //   2489: iconst_0
/*      */     //   2490: iload #84
/*      */     //   2492: iadd
/*      */     //   2493: istore #83
/*      */     //   2495: aload #82
/*      */     //   2497: iload #83
/*      */     //   2499: invokeinterface getInt : (I)I
/*      */     //   2504: istore #81
/*      */     //   2506: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   2509: istore #80
/*      */     //   2511: iload #81
/*      */     //   2513: iload #80
/*      */     //   2515: if_icmpne -> 2521
/*      */     //   2518: goto -> 2587
/*      */     //   2521: aload #9
/*      */     //   2523: iload #10
/*      */     //   2525: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2530: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2533: astore #78
/*      */     //   2535: aload #25
/*      */     //   2537: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2540: astore #76
/*      */     //   2542: iload #21
/*      */     //   2544: iload #20
/*      */     //   2546: irem
/*      */     //   2547: iconst_4
/*      */     //   2548: imul
/*      */     //   2549: istore #73
/*      */     //   2551: aload #76
/*      */     //   2553: astore #71
/*      */     //   2555: iconst_0
/*      */     //   2556: iload #73
/*      */     //   2558: iadd
/*      */     //   2559: istore #72
/*      */     //   2561: aload #71
/*      */     //   2563: iload #72
/*      */     //   2565: invokeinterface getInt : (I)I
/*      */     //   2570: istore #70
/*      */     //   2572: aload #78
/*      */     //   2574: sipush #312
/*      */     //   2577: iload #70
/*      */     //   2579: invokeinterface setInt : (II)V
/*      */     //   2584: goto -> 2635
/*      */     //   2587: aload #9
/*      */     //   2589: iload #10
/*      */     //   2591: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2596: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2599: astore #68
/*      */     //   2601: aload #9
/*      */     //   2603: iload #10
/*      */     //   2605: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2610: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2613: sipush #312
/*      */     //   2616: invokeinterface getInt : (I)I
/*      */     //   2621: istore #65
/*      */     //   2623: aload #68
/*      */     //   2625: sipush #312
/*      */     //   2628: iload #65
/*      */     //   2630: invokeinterface setInt : (II)V
/*      */     //   2635: aload #9
/*      */     //   2637: iload #10
/*      */     //   2639: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2644: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2647: astore #63
/*      */     //   2649: aload #24
/*      */     //   2651: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2654: astore #61
/*      */     //   2656: iload #21
/*      */     //   2658: iload #19
/*      */     //   2660: irem
/*      */     //   2661: bipush #8
/*      */     //   2663: imul
/*      */     //   2664: istore #58
/*      */     //   2666: aload #61
/*      */     //   2668: astore #56
/*      */     //   2670: iconst_0
/*      */     //   2671: iload #58
/*      */     //   2673: iadd
/*      */     //   2674: istore #57
/*      */     //   2676: aload #56
/*      */     //   2678: iload #57
/*      */     //   2680: invokeinterface getDouble : (I)D
/*      */     //   2685: dstore #54
/*      */     //   2687: aload #63
/*      */     //   2689: sipush #316
/*      */     //   2692: dload #54
/*      */     //   2694: invokeinterface setDouble : (ID)V
/*      */     //   2699: aload #28
/*      */     //   2701: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2704: astore #52
/*      */     //   2706: iload #23
/*      */     //   2708: bipush #8
/*      */     //   2710: imul
/*      */     //   2711: istore #50
/*      */     //   2713: aload #52
/*      */     //   2715: astore #48
/*      */     //   2717: iconst_0
/*      */     //   2718: iload #50
/*      */     //   2720: iadd
/*      */     //   2721: istore #49
/*      */     //   2723: aload #48
/*      */     //   2725: iload #49
/*      */     //   2727: invokeinterface getDouble : (I)D
/*      */     //   2732: dstore #15
/*      */     //   2734: dload #15
/*      */     //   2736: invokestatic R_finite : (D)I
/*      */     //   2739: ifne -> 2745
/*      */     //   2742: goto -> 2853
/*      */     //   2745: aload #9
/*      */     //   2747: iload #10
/*      */     //   2749: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2754: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2757: sipush #316
/*      */     //   2760: invokeinterface getDouble : (I)D
/*      */     //   2765: invokestatic R_finite : (D)I
/*      */     //   2768: ifne -> 2774
/*      */     //   2771: goto -> 2853
/*      */     //   2774: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2777: dup
/*      */     //   2778: aload #11
/*      */     //   2780: iconst_0
/*      */     //   2781: invokespecial <init> : ([DI)V
/*      */     //   2784: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2787: aload #9
/*      */     //   2789: iload #10
/*      */     //   2791: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2796: invokestatic getylimits : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2799: aload #12
/*      */     //   2801: iconst_0
/*      */     //   2802: dload #15
/*      */     //   2804: dastore
/*      */     //   2805: aload #12
/*      */     //   2807: iconst_1
/*      */     //   2808: dload #15
/*      */     //   2810: dastore
/*      */     //   2811: aload #11
/*      */     //   2813: iconst_1
/*      */     //   2814: daload
/*      */     //   2815: dstore #40
/*      */     //   2817: aload #12
/*      */     //   2819: iconst_1
/*      */     //   2820: daload
/*      */     //   2821: dstore #38
/*      */     //   2823: aload #11
/*      */     //   2825: iconst_0
/*      */     //   2826: daload
/*      */     //   2827: dstore #36
/*      */     //   2829: aload #12
/*      */     //   2831: iconst_0
/*      */     //   2832: daload
/*      */     //   2833: dload #36
/*      */     //   2835: dload #38
/*      */     //   2837: dload #40
/*      */     //   2839: bipush #12
/*      */     //   2841: aload #9
/*      */     //   2843: iload #10
/*      */     //   2845: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2850: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2853: iinc #21, 1
/*      */     //   2856: iinc #23, 1
/*      */     //   2859: aload #28
/*      */     //   2861: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2864: iload #23
/*      */     //   2866: if_icmpgt -> 2399
/*      */     //   2869: goto -> 2872
/*      */     //   2872: iconst_0
/*      */     //   2873: aload #9
/*      */     //   2875: iload #10
/*      */     //   2877: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2882: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2885: aload #9
/*      */     //   2887: iload #10
/*      */     //   2889: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2894: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2897: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   2900: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2734	-> 135
/*      */     //   #2735	-> 145
/*      */     //   #2737	-> 153
/*      */     //   #2739	-> 165
/*      */     //   #2740	-> 170
/*      */     //   #2740	-> 181
/*      */     //   #2742	-> 220
/*      */     //   #2743	-> 245
/*      */     //   #2744	-> 261
/*      */     //   #2746	-> 266
/*      */     //   #2747	-> 291
/*      */     //   #2748	-> 307
/*      */     //   #2750	-> 312
/*      */     //   #2751	-> 337
/*      */     //   #2752	-> 353
/*      */     //   #2754	-> 358
/*      */     //   #2755	-> 383
/*      */     //   #2756	-> 399
/*      */     //   #2758	-> 404
/*      */     //   #2759	-> 429
/*      */     //   #2760	-> 445
/*      */     //   #2763	-> 450
/*      */     //   #2764	-> 472
/*      */     //   #2766	-> 479
/*      */     //   #2767	-> 527
/*      */     //   #2769	-> 534
/*      */     //   #2770	-> 582
/*      */     //   #2772	-> 589
/*      */     //   #2774	-> 601
/*      */     //   #2776	-> 614
/*      */     //   #2778	-> 617
/*      */     //   #2779	-> 636
/*      */     //   #2780	-> 655
/*      */     //   #2781	-> 667
/*      */     //   #2782	-> 707
/*      */     //   #2783	-> 719
/*      */     //   #2786	-> 736
/*      */     //   #2787	-> 743
/*      */     //   #2789	-> 750
/*      */     //   #2789	-> 761
/*      */     //   #2790	-> 772
/*      */     //   #2791	-> 812
/*      */     //   #2792	-> 857
/*      */     //   #2793	-> 903
/*      */     //   #2793	-> 911
/*      */     //   #2794	-> 946
/*      */     //   #2796	-> 995
/*      */     //   #2797	-> 1051
/*      */     //   #2814	-> 1064
/*      */     //   #2815	-> 1089
/*      */     //   #2816	-> 1118
/*      */     //   #2817	-> 1162
/*      */     //   #2817	-> 1178
/*      */     //   #2817	-> 1186
/*      */     //   #2821	-> 1194
/*      */     //   #2823	-> 1202
/*      */     //   #2824	-> 1211
/*      */     //   #2825	-> 1251
/*      */     //   #2826	-> 1275
/*      */     //   #2827	-> 1281
/*      */     //   #2826	-> 1303
/*      */     //   #2826	-> 1306
/*      */     //   #2829	-> 1316
/*      */     //   #2830	-> 1338
/*      */     //   #2831	-> 1344
/*      */     //   #2830	-> 1371
/*      */     //   #2830	-> 1374
/*      */     //   #2833	-> 1384
/*      */     //   #2834	-> 1397
/*      */     //   #2835	-> 1403
/*      */     //   #2834	-> 1423
/*      */     //   #2834	-> 1426
/*      */     //   #2838	-> 1436
/*      */     //   #2839	-> 1443
/*      */     //   #2840	-> 1454
/*      */     //   #2840	-> 1457
/*      */     //   #2840	-> 1467
/*      */     //   #2841	-> 1483
/*      */     //   #2841	-> 1489
/*      */     //   #2841	-> 1497
/*      */     //   #2843	-> 1510
/*      */     //   #2844	-> 1521
/*      */     //   #2844	-> 1524
/*      */     //   #2844	-> 1534
/*      */     //   #2845	-> 1550
/*      */     //   #2845	-> 1556
/*      */     //   #2845	-> 1564
/*      */     //   #2848	-> 1577
/*      */     //   #0	-> 1648
/*      */     //   #2852	-> 1651
/*      */     //   #2852	-> 1659
/*      */     //   #2852	-> 1671
/*      */     //   #2852	-> 1677
/*      */     //   #2853	-> 1693
/*      */     //   #2853	-> 1701
/*      */     //   #2853	-> 1713
/*      */     //   #2853	-> 1719
/*      */     //   #2854	-> 1735
/*      */     //   #2855	-> 1743
/*      */     //   #2856	-> 1765
/*      */     //   #2859	-> 1787
/*      */     //   #2862	-> 1829
/*      */     //   #2863	-> 1842
/*      */     //   #2865	-> 1845
/*      */     //   #2866	-> 1860
/*      */     //   #2867	-> 1873
/*      */     //   #2868	-> 1879
/*      */     //   #2869	-> 1941
/*      */     //   #2869	-> 1949
/*      */     //   #2870	-> 2001
/*      */     //   #2872	-> 2067
/*      */     //   #2873	-> 2115
/*      */     //   #2874	-> 2179
/*      */     //   #2875	-> 2214
/*      */     //   #2875	-> 2225
/*      */     //   #2876	-> 2254
/*      */     //   #2877	-> 2279
/*      */     //   #2878	-> 2285
/*      */     //   #2879	-> 2291
/*      */     //   #2881	-> 2333
/*      */     //   #2867	-> 2336
/*      */     //   #2867	-> 2339
/*      */     //   #2883	-> 2352
/*      */     //   #2885	-> 2365
/*      */     //   #2886	-> 2380
/*      */     //   #2887	-> 2393
/*      */     //   #2888	-> 2399
/*      */     //   #2889	-> 2461
/*      */     //   #2889	-> 2469
/*      */     //   #2890	-> 2521
/*      */     //   #2892	-> 2587
/*      */     //   #2893	-> 2635
/*      */     //   #2894	-> 2699
/*      */     //   #2895	-> 2734
/*      */     //   #2895	-> 2745
/*      */     //   #2896	-> 2774
/*      */     //   #2897	-> 2799
/*      */     //   #2898	-> 2805
/*      */     //   #2899	-> 2811
/*      */     //   #2901	-> 2853
/*      */     //   #2887	-> 2856
/*      */     //   #2887	-> 2859
/*      */     //   #2903	-> 2872
/*      */     //   #2905	-> 2885
/*      */     //   #2906	-> 2885
/*      */     //   #2907	-> 2897
/*      */     //   #0	-> 2900
/*      */     //   #2907	-> 2900
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	2901	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	1	xstep	D
/*      */     //   0	2901	3	x_f	D
/*      */     //   0	2901	5	yy	[D
/*      */     //   0	2901	6	xx	[D
/*      */     //   0	2901	7	ylog	I
/*      */     //   0	2901	8	xlog	I
/*      */     //   0	2901	9	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	2901	10	dd$offset	I
/*      */     //   0	2901	11	y	[D
/*      */     //   0	2901	12	x	[D
/*      */     //   0	2901	13	bb	D
/*      */     //   0	2901	15	aa	D
/*      */     //   0	2901	17	lstop	I
/*      */     //   0	2901	18	lstart	I
/*      */     //   0	2901	19	nlwd	I
/*      */     //   0	2901	20	nlty	I
/*      */     //   0	2901	21	nlines	I
/*      */     //   0	2901	22	ncol	I
/*      */     //   0	2901	23	i	I
/*      */     //   0	2901	24	lwd	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	25	lty	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	26	col	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	27	untf	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	28	v	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	29	h	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	30	b	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	31	a	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	51	i$386	I
/*      */     //   0	2901	80	R_NaInt$385	I
/*      */     //   0	2901	100	R_NilValue$384	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	119	i$383	I
/*      */     //   0	2901	148	R_NaInt$382	I
/*      */     //   0	2901	168	R_NilValue$381	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	191	iftmp$380	D
/*      */     //   0	2901	199	iftmp$379	D
/*      */     //   0	2901	206	lstart$378	I
/*      */     //   0	2901	210	lstart$377	I
/*      */     //   0	2901	284	R_NaInt$376	I
/*      */     //   0	2901	311	R_NilValue$375	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	312	R_NilValue$374	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	323	R_NilValue$373	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	324	R_NilValue$372	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	325	R_NilValue$371	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	326	R_NilValue$370	Lorg/renjin/sexp/SEXP;
/*      */     //   0	2901	327	R_NilValue$369	Lorg/renjin/sexp/SEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_box(SEXP args) {
/* 2918 */     dd = baseDevices__.GEcurrentDevice();
/*      */     
/* 2920 */     graphics__.Rf_GCheckState(dd);
/* 2921 */     graphics__.Rf_GSavePars(dd);
/* 2922 */     args = Rinternals.CDR(args);
/* 2923 */     which = Rinternals.Rf_asInteger(Rinternals.CAR(args)); args = Rinternals.CDR(args);
/* 2924 */     if (which <= 0 || which > 4) {
/* 2925 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("which\000".getBytes(), 0) });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2933 */     col = base__.Rf_gpptr(dd).getInt(44);
/* 2934 */     par__.Rf_ProcessInlinePars(args, dd);
/*      */     
/* 2936 */     if (isNAcol(getInlinePar(args, (Ptr)new BytePtr("col\000".getBytes(), 0)), 0, 1) != 0)
/*      */     
/* 2938 */     { if (isNAcol(getInlinePar(args, (Ptr)new BytePtr("fg\000".getBytes(), 0)), 0, 1) == 0)
/*      */       
/*      */       { 
/* 2941 */         Ptr ptr1 = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(76); ptr1.setInt(44, i);
/*      */ 
/*      */         
/* 2944 */         base__.Rf_gpptr(dd).setInt(444, 2);
/* 2945 */         graphics__.Rf_GMode(1, dd);
/* 2946 */         graphics__.Rf_GBox(which, dd);
/* 2947 */         graphics__.Rf_GMode(0, dd);
/* 2948 */         graphics__.Rf_GRestorePars(dd);
/* 2949 */         return Rinternals.R_NilValue; }  Ptr ptr = base__.Rf_gpptr(dd); col$368 = col; ptr.setInt(44, col$368); }  base__.Rf_gpptr(dd).setInt(444, 2); graphics__.Rf_GMode(1, dd); graphics__.Rf_GBox(which, dd); graphics__.Rf_GMode(0, dd); graphics__.Rf_GRestorePars(dd); return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawPointsLines(double xp, double yp, double xold, double yold, byte type, int first, Ptr dd) {
/* 2955 */     if (type == (byte)112 || type == (byte)111) {
/* 2956 */       int i = base__.Rf_gpptr(dd).getInt(372); graphics__.Rf_GSymbol(xp, yp, 0, i, dd);
/* 2957 */     }  if ((type == (byte)108 || type == (byte)111) && first == 0) {
/* 2958 */       graphics__.Rf_GLine(xold, yold, xp, yp, 0, dd);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_locator(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #11
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #12
/*      */     //   10: iconst_0
/*      */     //   11: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   19: checkcast org/renjin/sexp/SEXP
/*      */     //   22: astore #4
/*      */     //   24: iconst_0
/*      */     //   25: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   28: astore #5
/*      */     //   30: iconst_0
/*      */     //   31: istore #6
/*      */     //   33: dconst_0
/*      */     //   34: dstore #7
/*      */     //   36: dconst_0
/*      */     //   37: dstore #9
/*      */     //   39: iconst_0
/*      */     //   40: i2b
/*      */     //   41: istore #13
/*      */     //   43: iconst_0
/*      */     //   44: istore #14
/*      */     //   46: iconst_0
/*      */     //   47: istore #15
/*      */     //   49: iconst_0
/*      */     //   50: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   53: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   58: checkcast org/renjin/sexp/SEXP
/*      */     //   61: astore #19
/*      */     //   63: iconst_0
/*      */     //   64: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   67: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   72: checkcast org/renjin/sexp/SEXP
/*      */     //   75: astore #20
/*      */     //   77: iconst_0
/*      */     //   78: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   81: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   86: checkcast org/renjin/sexp/SEXP
/*      */     //   89: astore #21
/*      */     //   91: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   94: astore #16
/*      */     //   96: bipush #112
/*      */     //   98: i2b
/*      */     //   99: istore #13
/*      */     //   101: dconst_0
/*      */     //   102: dstore #9
/*      */     //   104: dconst_0
/*      */     //   105: dstore #7
/*      */     //   107: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   110: astore #5
/*      */     //   112: iconst_0
/*      */     //   113: istore #6
/*      */     //   115: aload_2
/*      */     //   116: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   119: astore #4
/*      */     //   121: aload_2
/*      */     //   122: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   125: astore_2
/*      */     //   126: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   129: astore #120
/*      */     //   131: aload_0
/*      */     //   132: aload #120
/*      */     //   134: if_acmpeq -> 140
/*      */     //   137: goto -> 463
/*      */     //   140: aload_2
/*      */     //   141: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   144: astore #21
/*      */     //   146: aload_2
/*      */     //   147: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   150: astore_2
/*      */     //   151: aload_2
/*      */     //   152: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   155: astore #20
/*      */     //   157: aload_2
/*      */     //   158: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   161: astore_2
/*      */     //   162: aload_2
/*      */     //   163: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   166: astore #19
/*      */     //   168: aload_2
/*      */     //   169: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   172: astore_2
/*      */     //   173: aload #19
/*      */     //   175: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   178: invokeinterface getInt : ()I
/*      */     //   183: istore #14
/*      */     //   185: aload_2
/*      */     //   186: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   189: astore #16
/*      */     //   191: aload_2
/*      */     //   192: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   195: astore_2
/*      */     //   196: aload #16
/*      */     //   198: iconst_0
/*      */     //   199: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   202: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   205: invokeinterface getByte : ()B
/*      */     //   210: istore #13
/*      */     //   212: iload #13
/*      */     //   214: bipush #110
/*      */     //   216: i2b
/*      */     //   217: if_icmpne -> 223
/*      */     //   220: goto -> 455
/*      */     //   223: iconst_1
/*      */     //   224: aload #5
/*      */     //   226: iload #6
/*      */     //   228: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   233: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   236: iconst_0
/*      */     //   237: istore #15
/*      */     //   239: goto -> 432
/*      */     //   242: aload #21
/*      */     //   244: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   247: astore #113
/*      */     //   249: iload #15
/*      */     //   251: bipush #8
/*      */     //   253: imul
/*      */     //   254: istore #111
/*      */     //   256: aload #113
/*      */     //   258: astore #109
/*      */     //   260: iconst_0
/*      */     //   261: iload #111
/*      */     //   263: iadd
/*      */     //   264: istore #110
/*      */     //   266: aload #109
/*      */     //   268: iload #110
/*      */     //   270: invokeinterface getDouble : (I)D
/*      */     //   275: dstore #107
/*      */     //   277: aload #12
/*      */     //   279: iconst_0
/*      */     //   280: dload #107
/*      */     //   282: dastore
/*      */     //   283: aload #20
/*      */     //   285: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   288: astore #105
/*      */     //   290: iload #15
/*      */     //   292: bipush #8
/*      */     //   294: imul
/*      */     //   295: istore #103
/*      */     //   297: aload #105
/*      */     //   299: astore #101
/*      */     //   301: iconst_0
/*      */     //   302: iload #103
/*      */     //   304: iadd
/*      */     //   305: istore #102
/*      */     //   307: aload #101
/*      */     //   309: iload #102
/*      */     //   311: invokeinterface getDouble : (I)D
/*      */     //   316: dstore #99
/*      */     //   318: aload #11
/*      */     //   320: iconst_0
/*      */     //   321: dload #99
/*      */     //   323: dastore
/*      */     //   324: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   327: dup
/*      */     //   328: aload #12
/*      */     //   330: iconst_0
/*      */     //   331: invokespecial <init> : ([DI)V
/*      */     //   334: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   337: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   340: dup
/*      */     //   341: aload #11
/*      */     //   343: iconst_0
/*      */     //   344: invokespecial <init> : ([DI)V
/*      */     //   347: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   350: bipush #12
/*      */     //   352: iconst_0
/*      */     //   353: aload #5
/*      */     //   355: iload #6
/*      */     //   357: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   362: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   365: iload #15
/*      */     //   367: ifeq -> 377
/*      */     //   370: goto -> 373
/*      */     //   373: iconst_0
/*      */     //   374: goto -> 378
/*      */     //   377: iconst_1
/*      */     //   378: istore #97
/*      */     //   380: iload #13
/*      */     //   382: istore #96
/*      */     //   384: aload #11
/*      */     //   386: iconst_0
/*      */     //   387: daload
/*      */     //   388: dstore #94
/*      */     //   390: aload #12
/*      */     //   392: iconst_0
/*      */     //   393: daload
/*      */     //   394: dload #94
/*      */     //   396: dload #9
/*      */     //   398: dload #7
/*      */     //   400: iload #96
/*      */     //   402: i2b
/*      */     //   403: iload #97
/*      */     //   405: aload #5
/*      */     //   407: iload #6
/*      */     //   409: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   414: invokestatic drawPointsLines : (DDDDBILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   417: aload #12
/*      */     //   419: iconst_0
/*      */     //   420: daload
/*      */     //   421: dstore #9
/*      */     //   423: aload #11
/*      */     //   425: iconst_0
/*      */     //   426: daload
/*      */     //   427: dstore #7
/*      */     //   429: iinc #15, 1
/*      */     //   432: iload #15
/*      */     //   434: iload #14
/*      */     //   436: if_icmplt -> 242
/*      */     //   439: goto -> 442
/*      */     //   442: iconst_0
/*      */     //   443: aload #5
/*      */     //   445: iload #6
/*      */     //   447: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   452: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   455: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   458: astore #91
/*      */     //   460: goto -> 1316
/*      */     //   463: aload #5
/*      */     //   465: iload #6
/*      */     //   467: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   472: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   475: aload_2
/*      */     //   476: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   479: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   482: istore #14
/*      */     //   484: iload #14
/*      */     //   486: ifle -> 507
/*      */     //   489: goto -> 492
/*      */     //   492: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   495: istore #89
/*      */     //   497: iload #14
/*      */     //   499: iload #89
/*      */     //   501: if_icmpeq -> 507
/*      */     //   504: goto -> 564
/*      */     //   507: new org/renjin/gcc/runtime/BytePtr
/*      */     //   510: dup
/*      */     //   511: ldc 'graphics '
/*      */     //   513: invokevirtual getBytes : ()[B
/*      */     //   516: iconst_0
/*      */     //   517: invokespecial <init> : ([BI)V
/*      */     //   520: new org/renjin/gcc/runtime/BytePtr
/*      */     //   523: dup
/*      */     //   524: ldc_w 'invalid number of points in %s '
/*      */     //   527: invokevirtual getBytes : ()[B
/*      */     //   530: iconst_0
/*      */     //   531: invokespecial <init> : ([BI)V
/*      */     //   534: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   537: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   540: iconst_1
/*      */     //   541: anewarray java/lang/Object
/*      */     //   544: dup
/*      */     //   545: iconst_0
/*      */     //   546: new org/renjin/gcc/runtime/BytePtr
/*      */     //   549: dup
/*      */     //   550: ldc_w 'locator() '
/*      */     //   553: invokevirtual getBytes : ()[B
/*      */     //   556: iconst_0
/*      */     //   557: invokespecial <init> : ([BI)V
/*      */     //   560: aastore
/*      */     //   561: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   564: aload_2
/*      */     //   565: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   568: astore_2
/*      */     //   569: aload_2
/*      */     //   570: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   573: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   576: bipush #16
/*      */     //   578: if_icmpeq -> 584
/*      */     //   581: goto -> 683
/*      */     //   584: aload_2
/*      */     //   585: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   588: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   591: iconst_1
/*      */     //   592: if_icmpeq -> 598
/*      */     //   595: goto -> 683
/*      */     //   598: aload_2
/*      */     //   599: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   602: astore #16
/*      */     //   604: aload #16
/*      */     //   606: iconst_0
/*      */     //   607: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   610: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   613: invokeinterface getByte : ()B
/*      */     //   618: istore #13
/*      */     //   620: bipush #14
/*      */     //   622: iload #14
/*      */     //   624: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   627: astore #21
/*      */     //   629: aload #21
/*      */     //   631: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   634: pop
/*      */     //   635: bipush #14
/*      */     //   637: iload #14
/*      */     //   639: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   642: astore #20
/*      */     //   644: aload #20
/*      */     //   646: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   649: pop
/*      */     //   650: bipush #13
/*      */     //   652: iconst_1
/*      */     //   653: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   656: astore #19
/*      */     //   658: aload #19
/*      */     //   660: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   663: pop
/*      */     //   664: iconst_2
/*      */     //   665: aload #5
/*      */     //   667: iload #6
/*      */     //   669: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   674: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   677: iconst_0
/*      */     //   678: istore #15
/*      */     //   680: goto -> 1052
/*      */     //   683: new org/renjin/gcc/runtime/BytePtr
/*      */     //   686: dup
/*      */     //   687: ldc 'graphics '
/*      */     //   689: invokevirtual getBytes : ()[B
/*      */     //   692: iconst_0
/*      */     //   693: invokespecial <init> : ([BI)V
/*      */     //   696: new org/renjin/gcc/runtime/BytePtr
/*      */     //   699: dup
/*      */     //   700: ldc_w 'invalid plot type '
/*      */     //   703: invokevirtual getBytes : ()[B
/*      */     //   706: iconst_0
/*      */     //   707: invokespecial <init> : ([BI)V
/*      */     //   710: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   713: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   716: iconst_0
/*      */     //   717: anewarray java/lang/Object
/*      */     //   720: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   723: aload #20
/*      */     //   725: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   728: astore #76
/*      */     //   730: iload #15
/*      */     //   732: bipush #8
/*      */     //   734: imul
/*      */     //   735: istore #74
/*      */     //   737: aload #76
/*      */     //   739: astore #72
/*      */     //   741: iconst_0
/*      */     //   742: iload #74
/*      */     //   744: iadd
/*      */     //   745: istore #73
/*      */     //   747: aload #21
/*      */     //   749: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   752: astore #70
/*      */     //   754: iload #15
/*      */     //   756: bipush #8
/*      */     //   758: imul
/*      */     //   759: istore #68
/*      */     //   761: aload #70
/*      */     //   763: astore #66
/*      */     //   765: iconst_0
/*      */     //   766: iload #68
/*      */     //   768: iadd
/*      */     //   769: istore #67
/*      */     //   771: aload #66
/*      */     //   773: iload #67
/*      */     //   775: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   780: aload #72
/*      */     //   782: iload #73
/*      */     //   784: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   789: bipush #12
/*      */     //   791: aload #5
/*      */     //   793: iload #6
/*      */     //   795: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   800: invokestatic Rf_GLocator : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   803: ifeq -> 809
/*      */     //   806: goto -> 812
/*      */     //   809: goto -> 1062
/*      */     //   812: iload #13
/*      */     //   814: bipush #110
/*      */     //   816: i2b
/*      */     //   817: if_icmpne -> 823
/*      */     //   820: goto -> 1049
/*      */     //   823: iconst_1
/*      */     //   824: aload #5
/*      */     //   826: iload #6
/*      */     //   828: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   833: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   836: aload #21
/*      */     //   838: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   841: astore #63
/*      */     //   843: iload #15
/*      */     //   845: bipush #8
/*      */     //   847: imul
/*      */     //   848: istore #61
/*      */     //   850: aload #63
/*      */     //   852: astore #59
/*      */     //   854: iconst_0
/*      */     //   855: iload #61
/*      */     //   857: iadd
/*      */     //   858: istore #60
/*      */     //   860: aload #59
/*      */     //   862: iload #60
/*      */     //   864: invokeinterface getDouble : (I)D
/*      */     //   869: dstore #57
/*      */     //   871: aload #12
/*      */     //   873: iconst_0
/*      */     //   874: dload #57
/*      */     //   876: dastore
/*      */     //   877: aload #20
/*      */     //   879: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   882: astore #55
/*      */     //   884: iload #15
/*      */     //   886: bipush #8
/*      */     //   888: imul
/*      */     //   889: istore #53
/*      */     //   891: aload #55
/*      */     //   893: astore #51
/*      */     //   895: iconst_0
/*      */     //   896: iload #53
/*      */     //   898: iadd
/*      */     //   899: istore #52
/*      */     //   901: aload #51
/*      */     //   903: iload #52
/*      */     //   905: invokeinterface getDouble : (I)D
/*      */     //   910: dstore #49
/*      */     //   912: aload #11
/*      */     //   914: iconst_0
/*      */     //   915: dload #49
/*      */     //   917: dastore
/*      */     //   918: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   921: dup
/*      */     //   922: aload #12
/*      */     //   924: iconst_0
/*      */     //   925: invokespecial <init> : ([DI)V
/*      */     //   928: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   931: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   934: dup
/*      */     //   935: aload #11
/*      */     //   937: iconst_0
/*      */     //   938: invokespecial <init> : ([DI)V
/*      */     //   941: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   944: bipush #12
/*      */     //   946: iconst_0
/*      */     //   947: aload #5
/*      */     //   949: iload #6
/*      */     //   951: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   956: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   959: iload #15
/*      */     //   961: ifeq -> 971
/*      */     //   964: goto -> 967
/*      */     //   967: iconst_0
/*      */     //   968: goto -> 972
/*      */     //   971: iconst_1
/*      */     //   972: istore #47
/*      */     //   974: iload #13
/*      */     //   976: istore #46
/*      */     //   978: aload #11
/*      */     //   980: iconst_0
/*      */     //   981: daload
/*      */     //   982: dstore #44
/*      */     //   984: aload #12
/*      */     //   986: iconst_0
/*      */     //   987: daload
/*      */     //   988: dload #44
/*      */     //   990: dload #9
/*      */     //   992: dload #7
/*      */     //   994: iload #46
/*      */     //   996: i2b
/*      */     //   997: iload #47
/*      */     //   999: aload #5
/*      */     //   1001: iload #6
/*      */     //   1003: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1008: invokestatic drawPointsLines : (DDDDBILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1011: iconst_0
/*      */     //   1012: aload #5
/*      */     //   1014: iload #6
/*      */     //   1016: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1021: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1024: iconst_2
/*      */     //   1025: aload #5
/*      */     //   1027: iload #6
/*      */     //   1029: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1034: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1037: aload #12
/*      */     //   1039: iconst_0
/*      */     //   1040: daload
/*      */     //   1041: dstore #9
/*      */     //   1043: aload #11
/*      */     //   1045: iconst_0
/*      */     //   1046: daload
/*      */     //   1047: dstore #7
/*      */     //   1049: iinc #15, 1
/*      */     //   1052: iload #15
/*      */     //   1054: iload #14
/*      */     //   1056: if_icmplt -> 723
/*      */     //   1059: goto -> 1062
/*      */     //   1062: iconst_0
/*      */     //   1063: aload #5
/*      */     //   1065: iload #6
/*      */     //   1067: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1072: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1075: aload #19
/*      */     //   1077: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1080: iconst_0
/*      */     //   1081: iload #15
/*      */     //   1083: invokeinterface setInt : (II)V
/*      */     //   1088: goto -> 1174
/*      */     //   1091: aload #21
/*      */     //   1093: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1096: astore #38
/*      */     //   1098: iload #15
/*      */     //   1100: bipush #8
/*      */     //   1102: imul
/*      */     //   1103: istore #36
/*      */     //   1105: aload #38
/*      */     //   1107: astore #34
/*      */     //   1109: iconst_0
/*      */     //   1110: iload #36
/*      */     //   1112: iadd
/*      */     //   1113: istore #35
/*      */     //   1115: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1118: dstore #32
/*      */     //   1120: aload #34
/*      */     //   1122: iload #35
/*      */     //   1124: dload #32
/*      */     //   1126: invokeinterface setDouble : (ID)V
/*      */     //   1131: aload #20
/*      */     //   1133: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1136: astore #30
/*      */     //   1138: iload #15
/*      */     //   1140: bipush #8
/*      */     //   1142: imul
/*      */     //   1143: istore #28
/*      */     //   1145: aload #30
/*      */     //   1147: astore #26
/*      */     //   1149: iconst_0
/*      */     //   1150: iload #28
/*      */     //   1152: iadd
/*      */     //   1153: istore #27
/*      */     //   1155: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   1158: dstore #24
/*      */     //   1160: aload #26
/*      */     //   1162: iload #27
/*      */     //   1164: dload #24
/*      */     //   1166: invokeinterface setDouble : (ID)V
/*      */     //   1171: iinc #15, 1
/*      */     //   1174: iload #15
/*      */     //   1176: iload #14
/*      */     //   1178: if_icmplt -> 1091
/*      */     //   1181: goto -> 1184
/*      */     //   1184: iconst_3
/*      */     //   1185: invokestatic Rf_allocList : (I)Lorg/renjin/sexp/SEXP;
/*      */     //   1188: astore #18
/*      */     //   1190: aload #18
/*      */     //   1192: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1195: pop
/*      */     //   1196: aload #18
/*      */     //   1198: aload #21
/*      */     //   1200: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1203: pop
/*      */     //   1204: aload #18
/*      */     //   1206: aload #20
/*      */     //   1208: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1211: pop
/*      */     //   1212: aload #18
/*      */     //   1214: aload #19
/*      */     //   1216: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1219: pop
/*      */     //   1220: aload_0
/*      */     //   1221: aload #5
/*      */     //   1223: iload #6
/*      */     //   1225: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1230: invokestatic GRecording : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1233: ifne -> 1239
/*      */     //   1236: goto -> 1312
/*      */     //   1239: iconst_5
/*      */     //   1240: invokestatic Rf_allocList : (I)Lorg/renjin/sexp/SEXP;
/*      */     //   1243: astore #17
/*      */     //   1245: aload #17
/*      */     //   1247: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1250: pop
/*      */     //   1251: aload #17
/*      */     //   1253: aload #4
/*      */     //   1255: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1258: pop
/*      */     //   1259: aload #17
/*      */     //   1261: aload #21
/*      */     //   1263: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1266: pop
/*      */     //   1267: aload #17
/*      */     //   1269: aload #20
/*      */     //   1271: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1274: pop
/*      */     //   1275: aload #17
/*      */     //   1277: aload #19
/*      */     //   1279: invokestatic SETCADDDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1282: pop
/*      */     //   1283: aload_2
/*      */     //   1284: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1287: astore #22
/*      */     //   1289: aload #17
/*      */     //   1291: aload #22
/*      */     //   1293: invokestatic SETCAD4R : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1296: pop
/*      */     //   1297: aload_1
/*      */     //   1298: aload #17
/*      */     //   1300: aload #5
/*      */     //   1302: iload #6
/*      */     //   1304: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1309: invokestatic GErecordGraphicOperation : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1312: aload #18
/*      */     //   1314: astore #91
/*      */     //   1316: aload #91
/*      */     //   1318: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2963	-> 91
/*      */     //   #2965	-> 96
/*      */     //   #2966	-> 101
/*      */     //   #2967	-> 107
/*      */     //   #2968	-> 115
/*      */     //   #2970	-> 121
/*      */     //   #2972	-> 126
/*      */     //   #2973	-> 140
/*      */     //   #2974	-> 151
/*      */     //   #2975	-> 162
/*      */     //   #2976	-> 173
/*      */     //   #2977	-> 185
/*      */     //   #2978	-> 196
/*      */     //   #2979	-> 212
/*      */     //   #2980	-> 223
/*      */     //   #2981	-> 236
/*      */     //   #2982	-> 242
/*      */     //   #2983	-> 283
/*      */     //   #2984	-> 324
/*      */     //   #2985	-> 365
/*      */     //   #2986	-> 417
/*      */     //   #2987	-> 423
/*      */     //   #2981	-> 429
/*      */     //   #2981	-> 432
/*      */     //   #2989	-> 442
/*      */     //   #2991	-> 455
/*      */     //   #2993	-> 463
/*      */     //   #2995	-> 475
/*      */     //   #2996	-> 484
/*      */     //   #2996	-> 492
/*      */     //   #2997	-> 507
/*      */     //   #2998	-> 564
/*      */     //   #2999	-> 569
/*      */     //   #2999	-> 584
/*      */     //   #3000	-> 598
/*      */     //   #3003	-> 604
/*      */     //   #3004	-> 620
/*      */     //   #3005	-> 635
/*      */     //   #3006	-> 650
/*      */     //   #3008	-> 664
/*      */     //   #3009	-> 677
/*      */     //   #3002	-> 683
/*      */     //   #3010	-> 723
/*      */     //   #3011	-> 812
/*      */     //   #3012	-> 823
/*      */     //   #3013	-> 836
/*      */     //   #3014	-> 877
/*      */     //   #3015	-> 918
/*      */     //   #3016	-> 959
/*      */     //   #3017	-> 1011
/*      */     //   #3018	-> 1024
/*      */     //   #3019	-> 1037
/*      */     //   #3009	-> 1049
/*      */     //   #3009	-> 1052
/*      */     //   #3022	-> 1062
/*      */     //   #3023	-> 1075
/*      */     //   #3025	-> 1091
/*      */     //   #3026	-> 1131
/*      */     //   #3024	-> 1171
/*      */     //   #3024	-> 1174
/*      */     //   #3028	-> 1184
/*      */     //   #3029	-> 1196
/*      */     //   #3030	-> 1204
/*      */     //   #3031	-> 1212
/*      */     //   #3032	-> 1220
/*      */     //   #3033	-> 1239
/*      */     //   #3034	-> 1251
/*      */     //   #3035	-> 1259
/*      */     //   #3036	-> 1267
/*      */     //   #3037	-> 1275
/*      */     //   #3038	-> 1283
/*      */     //   #3040	-> 1297
/*      */     //   #3041	-> 1312
/*      */     //   #3043	-> 1312
/*      */     //   #3044	-> 1312
/*      */     //   #0	-> 1316
/*      */     //   #0	-> 1316
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1319	0	call	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	1	op	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	2	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	3	rho	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	4	name	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	5	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	1319	6	dd$offset	I
/*      */     //   0	1319	7	yold	D
/*      */     //   0	1319	9	xold	D
/*      */     //   0	1319	11	yp	[D
/*      */     //   0	1319	12	xp	[D
/*      */     //   0	1319	13	type	B
/*      */     //   0	1319	14	n	I
/*      */     //   0	1319	15	i	I
/*      */     //   0	1319	16	stype	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	17	saveans	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	18	ans	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	19	nobs	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	20	y	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	21	x	Lorg/renjin/sexp/SEXP;
/*      */     //   0	1319	24	R_NaReal$367	D
/*      */     //   0	1319	29	i$366	I
/*      */     //   0	1319	32	R_NaReal$365	D
/*      */     //   0	1319	37	i$364	I
/*      */     //   0	1319	42	xp$363	D
/*      */     //   0	1319	44	yp$362	D
/*      */     //   0	1319	49	yp$361	D
/*      */     //   0	1319	54	i$360	I
/*      */     //   0	1319	57	xp$359	D
/*      */     //   0	1319	62	i$358	I
/*      */     //   0	1319	69	i$357	I
/*      */     //   0	1319	75	i$356	I
/*      */     //   0	1319	89	R_NaInt$355	I
/*      */     //   0	1319	92	xp$354	D
/*      */     //   0	1319	94	yp$353	D
/*      */     //   0	1319	99	yp$352	D
/*      */     //   0	1319	104	i$351	I
/*      */     //   0	1319	107	xp$350	D
/*      */     //   0	1319	112	i$349	I
/*      */     //   0	1319	120	R_NilValue$348	Lorg/renjin/sexp/SEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawLabel(double xi, double yi, int pos, double offset, Ptr l, int enc, Ptr dd) {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/* 3051 */     switch (pos) {
/*      */       case 4:
/* 3053 */         xi += offset;
/* 3054 */         d5 = 
/* 3055 */           dd.getPointer().getDouble(72); graphics__.Rf_GText(xi, yi, 13, l, enc, 0.0D, d5, 0.0D, dd);
/*      */         break;
/*      */       case 2:
/* 3058 */         xi -= offset;
/* 3059 */         d4 = 
/* 3060 */           dd.getPointer().getDouble(72); graphics__.Rf_GText(xi, yi, 13, l, enc, 1.0D, d4, 0.0D, dd);
/*      */         break;
/*      */       case 3:
/* 3063 */         yi += offset;
/* 3064 */         graphics__.Rf_GText(xi, yi, 13, l, enc, 0.5D, 0.0D, 0.0D, dd);
/*      */         break;
/*      */       
/*      */       case 1:
/* 3068 */         yi -= offset;
/*      */         
/* 3070 */         d3 = dd.getPointer().getDouble(72); d2 = 0.5D - d3; d1 = 1.0D - d2;
/*      */         graphics__.Rf_GText(xi, yi, 13, l, enc, 0.5D, d1, 0.0D, dd);
/*      */         break;
/*      */       case 0:
/* 3074 */         graphics__.Rf_GText(xi, yi, 13, l, enc, 0.0D, 0.0D, 0.0D, dd);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_identify(SEXP call, SEXP op, SEXP args, SEXP rho) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #25
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #26
/*      */     //   10: iconst_1
/*      */     //   11: newarray double
/*      */     //   13: astore #27
/*      */     //   15: iconst_1
/*      */     //   16: newarray double
/*      */     //   18: astore #28
/*      */     //   20: iconst_0
/*      */     //   21: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   24: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   29: checkcast org/renjin/sexp/SEXP
/*      */     //   32: astore #4
/*      */     //   34: iconst_0
/*      */     //   35: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   38: astore #5
/*      */     //   40: iconst_0
/*      */     //   41: istore #6
/*      */     //   43: iconst_0
/*      */     //   44: istore #9
/*      */     //   46: iconst_0
/*      */     //   47: istore #10
/*      */     //   49: iconst_0
/*      */     //   50: istore #11
/*      */     //   52: iconst_0
/*      */     //   53: istore #12
/*      */     //   55: iconst_0
/*      */     //   56: istore #13
/*      */     //   58: iconst_0
/*      */     //   59: istore #14
/*      */     //   61: iconst_0
/*      */     //   62: istore #16
/*      */     //   64: dconst_0
/*      */     //   65: dstore #17
/*      */     //   67: dconst_0
/*      */     //   68: dstore #19
/*      */     //   70: dconst_0
/*      */     //   71: dstore #21
/*      */     //   73: aload #25
/*      */     //   75: iconst_0
/*      */     //   76: dconst_0
/*      */     //   77: dastore
/*      */     //   78: aload #26
/*      */     //   80: iconst_0
/*      */     //   81: dconst_0
/*      */     //   82: dastore
/*      */     //   83: iconst_0
/*      */     //   84: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   87: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   92: checkcast org/renjin/sexp/SEXP
/*      */     //   95: astore #30
/*      */     //   97: iconst_0
/*      */     //   98: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   101: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   106: checkcast org/renjin/sexp/SEXP
/*      */     //   109: astore #31
/*      */     //   111: iconst_0
/*      */     //   112: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   115: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   120: checkcast org/renjin/sexp/SEXP
/*      */     //   123: astore #32
/*      */     //   125: iconst_0
/*      */     //   126: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   129: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   134: checkcast org/renjin/sexp/SEXP
/*      */     //   137: astore #33
/*      */     //   139: iconst_0
/*      */     //   140: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   143: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   148: checkcast org/renjin/sexp/SEXP
/*      */     //   151: astore #34
/*      */     //   153: iconst_0
/*      */     //   154: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   157: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   162: checkcast org/renjin/sexp/SEXP
/*      */     //   165: astore #35
/*      */     //   167: iconst_0
/*      */     //   168: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   171: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   176: checkcast org/renjin/sexp/SEXP
/*      */     //   179: astore #36
/*      */     //   181: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   184: astore #5
/*      */     //   186: iconst_0
/*      */     //   187: istore #6
/*      */     //   189: aload_2
/*      */     //   190: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   193: astore #4
/*      */     //   195: aload_2
/*      */     //   196: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   199: astore_2
/*      */     //   200: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   203: wide astore #305
/*      */     //   207: aload_0
/*      */     //   208: wide aload #305
/*      */     //   212: if_acmpeq -> 218
/*      */     //   215: goto -> 787
/*      */     //   218: aload_2
/*      */     //   219: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   222: astore #33
/*      */     //   224: aload_2
/*      */     //   225: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   228: astore_2
/*      */     //   229: aload_2
/*      */     //   230: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   233: astore #32
/*      */     //   235: aload_2
/*      */     //   236: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   239: astore_2
/*      */     //   240: aload_2
/*      */     //   241: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   244: astore #36
/*      */     //   246: aload_2
/*      */     //   247: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   250: astore_2
/*      */     //   251: aload_2
/*      */     //   252: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   255: astore #35
/*      */     //   257: aload_2
/*      */     //   258: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   261: astore_2
/*      */     //   262: aload_2
/*      */     //   263: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   266: astore #31
/*      */     //   268: aload_2
/*      */     //   269: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   272: astore_2
/*      */     //   273: aload_2
/*      */     //   274: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   277: astore #34
/*      */     //   279: aload_2
/*      */     //   280: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   283: astore_2
/*      */     //   284: aload_2
/*      */     //   285: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   288: astore #30
/*      */     //   290: aload #36
/*      */     //   292: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   295: istore #12
/*      */     //   297: aload #34
/*      */     //   299: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   302: istore #11
/*      */     //   304: aload #5
/*      */     //   306: iload #6
/*      */     //   308: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   313: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   316: wide astore #303
/*      */     //   320: aload #5
/*      */     //   322: iload #6
/*      */     //   324: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   329: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   332: sipush #484
/*      */     //   335: invokeinterface getDouble : (I)D
/*      */     //   340: wide dstore #299
/*      */     //   344: wide aload #303
/*      */     //   348: bipush #28
/*      */     //   350: wide dload #299
/*      */     //   354: invokeinterface setDouble : (ID)V
/*      */     //   359: aload #31
/*      */     //   361: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   364: bipush #15
/*      */     //   366: bipush #13
/*      */     //   368: aload #5
/*      */     //   370: iload #6
/*      */     //   372: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   377: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   380: dstore #19
/*      */     //   382: iconst_0
/*      */     //   383: istore #15
/*      */     //   385: goto -> 769
/*      */     //   388: aload #33
/*      */     //   390: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   393: wide astore #295
/*      */     //   397: iload #15
/*      */     //   399: iconst_4
/*      */     //   400: imul
/*      */     //   401: wide istore #293
/*      */     //   405: wide aload #295
/*      */     //   409: wide astore #291
/*      */     //   413: iconst_0
/*      */     //   414: wide iload #293
/*      */     //   418: iadd
/*      */     //   419: wide istore #292
/*      */     //   423: wide aload #291
/*      */     //   427: wide iload #292
/*      */     //   431: invokeinterface getInt : (I)I
/*      */     //   436: istore #9
/*      */     //   438: aload #30
/*      */     //   440: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   443: invokeinterface getInt : ()I
/*      */     //   448: ifne -> 454
/*      */     //   451: goto -> 766
/*      */     //   454: iload #9
/*      */     //   456: ifne -> 462
/*      */     //   459: goto -> 766
/*      */     //   462: aload #36
/*      */     //   464: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   467: wide astore #286
/*      */     //   471: iload #15
/*      */     //   473: bipush #8
/*      */     //   475: imul
/*      */     //   476: wide istore #284
/*      */     //   480: wide aload #286
/*      */     //   484: wide astore #282
/*      */     //   488: iconst_0
/*      */     //   489: wide iload #284
/*      */     //   493: iadd
/*      */     //   494: wide istore #283
/*      */     //   498: wide aload #282
/*      */     //   502: wide iload #283
/*      */     //   506: invokeinterface getDouble : (I)D
/*      */     //   511: wide dstore #280
/*      */     //   515: aload #28
/*      */     //   517: iconst_0
/*      */     //   518: wide dload #280
/*      */     //   522: dastore
/*      */     //   523: aload #35
/*      */     //   525: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   528: wide astore #278
/*      */     //   532: iload #15
/*      */     //   534: bipush #8
/*      */     //   536: imul
/*      */     //   537: wide istore #276
/*      */     //   541: wide aload #278
/*      */     //   545: wide astore #274
/*      */     //   549: iconst_0
/*      */     //   550: wide iload #276
/*      */     //   554: iadd
/*      */     //   555: wide istore #275
/*      */     //   559: wide aload #274
/*      */     //   563: wide iload #275
/*      */     //   567: invokeinterface getDouble : (I)D
/*      */     //   572: wide dstore #272
/*      */     //   576: aload #27
/*      */     //   578: iconst_0
/*      */     //   579: wide dload #272
/*      */     //   583: dastore
/*      */     //   584: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   587: dup
/*      */     //   588: aload #28
/*      */     //   590: iconst_0
/*      */     //   591: invokespecial <init> : ([DI)V
/*      */     //   594: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   597: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   600: dup
/*      */     //   601: aload #27
/*      */     //   603: iconst_0
/*      */     //   604: invokespecial <init> : ([DI)V
/*      */     //   607: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   610: bipush #12
/*      */     //   612: bipush #13
/*      */     //   614: aload #5
/*      */     //   616: iload #6
/*      */     //   618: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   623: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   626: aload #32
/*      */     //   628: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   631: wide astore #270
/*      */     //   635: iload #15
/*      */     //   637: iconst_4
/*      */     //   638: imul
/*      */     //   639: wide istore #268
/*      */     //   643: wide aload #270
/*      */     //   647: wide astore #266
/*      */     //   651: iconst_0
/*      */     //   652: wide iload #268
/*      */     //   656: iadd
/*      */     //   657: wide istore #267
/*      */     //   661: wide aload #266
/*      */     //   665: wide iload #267
/*      */     //   669: invokeinterface getInt : (I)I
/*      */     //   674: istore #8
/*      */     //   676: iload #15
/*      */     //   678: iload #11
/*      */     //   680: irem
/*      */     //   681: wide istore #265
/*      */     //   685: aload #34
/*      */     //   687: wide iload #265
/*      */     //   691: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   694: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   697: wide istore #263
/*      */     //   701: iload #15
/*      */     //   703: iload #11
/*      */     //   705: irem
/*      */     //   706: wide istore #262
/*      */     //   710: aload #34
/*      */     //   712: wide iload #262
/*      */     //   716: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   719: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   722: wide astore #259
/*      */     //   726: aload #27
/*      */     //   728: iconst_0
/*      */     //   729: daload
/*      */     //   730: wide dstore #257
/*      */     //   734: aload #28
/*      */     //   736: iconst_0
/*      */     //   737: daload
/*      */     //   738: wide dload #257
/*      */     //   742: iload #8
/*      */     //   744: dload #19
/*      */     //   746: wide aload #259
/*      */     //   750: wide iload #263
/*      */     //   754: aload #5
/*      */     //   756: iload #6
/*      */     //   758: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   763: invokestatic drawLabel : (DDIDLorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   766: iinc #15, 1
/*      */     //   769: iload #15
/*      */     //   771: iload #12
/*      */     //   773: if_icmplt -> 388
/*      */     //   776: goto -> 779
/*      */     //   779: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   782: astore #254
/*      */     //   784: goto -> 3114
/*      */     //   787: aload #5
/*      */     //   789: iload #6
/*      */     //   791: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   796: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   799: aload_2
/*      */     //   800: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   803: astore #36
/*      */     //   805: aload_2
/*      */     //   806: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   809: astore_2
/*      */     //   810: aload_2
/*      */     //   811: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   814: astore #35
/*      */     //   816: aload_2
/*      */     //   817: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   820: astore_2
/*      */     //   821: aload_2
/*      */     //   822: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   825: astore #34
/*      */     //   827: aload_2
/*      */     //   828: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   831: astore_2
/*      */     //   832: aload_2
/*      */     //   833: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   836: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   839: istore #10
/*      */     //   841: aload_2
/*      */     //   842: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   845: astore_2
/*      */     //   846: aload_2
/*      */     //   847: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   850: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   853: istore #9
/*      */     //   855: aload_2
/*      */     //   856: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   859: astore_2
/*      */     //   860: aload_2
/*      */     //   861: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   864: astore #31
/*      */     //   866: aload_2
/*      */     //   867: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   870: astore_2
/*      */     //   871: aload_2
/*      */     //   872: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   875: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   878: dstore #17
/*      */     //   880: aload_2
/*      */     //   881: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   884: astore_2
/*      */     //   885: aload_2
/*      */     //   886: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   889: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   892: istore #16
/*      */     //   894: iload #10
/*      */     //   896: ifle -> 917
/*      */     //   899: goto -> 902
/*      */     //   902: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   905: istore #249
/*      */     //   907: iload #10
/*      */     //   909: iload #249
/*      */     //   911: if_icmpeq -> 917
/*      */     //   914: goto -> 974
/*      */     //   917: new org/renjin/gcc/runtime/BytePtr
/*      */     //   920: dup
/*      */     //   921: ldc 'graphics '
/*      */     //   923: invokevirtual getBytes : ()[B
/*      */     //   926: iconst_0
/*      */     //   927: invokespecial <init> : ([BI)V
/*      */     //   930: new org/renjin/gcc/runtime/BytePtr
/*      */     //   933: dup
/*      */     //   934: ldc_w 'invalid number of points in %s '
/*      */     //   937: invokevirtual getBytes : ()[B
/*      */     //   940: iconst_0
/*      */     //   941: invokespecial <init> : ([BI)V
/*      */     //   944: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   947: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   950: iconst_1
/*      */     //   951: anewarray java/lang/Object
/*      */     //   954: dup
/*      */     //   955: iconst_0
/*      */     //   956: new org/renjin/gcc/runtime/BytePtr
/*      */     //   959: dup
/*      */     //   960: ldc_w 'identify() '
/*      */     //   963: invokevirtual getBytes : ()[B
/*      */     //   966: iconst_0
/*      */     //   967: invokespecial <init> : ([BI)V
/*      */     //   970: aastore
/*      */     //   971: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   974: aload #36
/*      */     //   976: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   979: bipush #14
/*      */     //   981: if_icmpne -> 1026
/*      */     //   984: goto -> 987
/*      */     //   987: aload #35
/*      */     //   989: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   992: bipush #14
/*      */     //   994: if_icmpne -> 1026
/*      */     //   997: goto -> 1000
/*      */     //   1000: aload #34
/*      */     //   1002: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1005: bipush #16
/*      */     //   1007: if_icmpne -> 1026
/*      */     //   1010: goto -> 1013
/*      */     //   1013: aload #31
/*      */     //   1015: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1018: bipush #14
/*      */     //   1020: if_icmpne -> 1026
/*      */     //   1023: goto -> 1066
/*      */     //   1026: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1029: dup
/*      */     //   1030: ldc 'graphics '
/*      */     //   1032: invokevirtual getBytes : ()[B
/*      */     //   1035: iconst_0
/*      */     //   1036: invokespecial <init> : ([BI)V
/*      */     //   1039: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1042: dup
/*      */     //   1043: ldc_w 'incorrect argument type '
/*      */     //   1046: invokevirtual getBytes : ()[B
/*      */     //   1049: iconst_0
/*      */     //   1050: invokespecial <init> : ([BI)V
/*      */     //   1053: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1056: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1059: iconst_0
/*      */     //   1060: anewarray java/lang/Object
/*      */     //   1063: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1066: dload #17
/*      */     //   1068: dconst_0
/*      */     //   1069: dcmpg
/*      */     //   1070: ifle -> 1087
/*      */     //   1073: goto -> 1076
/*      */     //   1076: dload #17
/*      */     //   1078: invokestatic __isnan : (D)I
/*      */     //   1081: ifne -> 1087
/*      */     //   1084: goto -> 1144
/*      */     //   1087: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1090: dup
/*      */     //   1091: ldc 'graphics '
/*      */     //   1093: invokevirtual getBytes : ()[B
/*      */     //   1096: iconst_0
/*      */     //   1097: invokespecial <init> : ([BI)V
/*      */     //   1100: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1103: dup
/*      */     //   1104: ldc_w 'invalid '%s' value '
/*      */     //   1107: invokevirtual getBytes : ()[B
/*      */     //   1110: iconst_0
/*      */     //   1111: invokespecial <init> : ([BI)V
/*      */     //   1114: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1117: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1120: iconst_1
/*      */     //   1121: anewarray java/lang/Object
/*      */     //   1124: dup
/*      */     //   1125: iconst_0
/*      */     //   1126: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1129: dup
/*      */     //   1130: ldc_w 'tolerance '
/*      */     //   1133: invokevirtual getBytes : ()[B
/*      */     //   1136: iconst_0
/*      */     //   1137: invokespecial <init> : ([BI)V
/*      */     //   1140: aastore
/*      */     //   1141: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1144: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1147: istore #237
/*      */     //   1149: iload #9
/*      */     //   1151: iload #237
/*      */     //   1153: if_icmpeq -> 1159
/*      */     //   1156: goto -> 1216
/*      */     //   1159: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1162: dup
/*      */     //   1163: ldc 'graphics '
/*      */     //   1165: invokevirtual getBytes : ()[B
/*      */     //   1168: iconst_0
/*      */     //   1169: invokespecial <init> : ([BI)V
/*      */     //   1172: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1175: dup
/*      */     //   1176: ldc_w 'invalid '%s' value '
/*      */     //   1179: invokevirtual getBytes : ()[B
/*      */     //   1182: iconst_0
/*      */     //   1183: invokespecial <init> : ([BI)V
/*      */     //   1186: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1189: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1192: iconst_1
/*      */     //   1193: anewarray java/lang/Object
/*      */     //   1196: dup
/*      */     //   1197: iconst_0
/*      */     //   1198: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1201: dup
/*      */     //   1202: ldc_w 'plot '
/*      */     //   1205: invokevirtual getBytes : ()[B
/*      */     //   1208: iconst_0
/*      */     //   1209: invokespecial <init> : ([BI)V
/*      */     //   1212: aastore
/*      */     //   1213: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1216: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1219: istore #234
/*      */     //   1221: iload #16
/*      */     //   1223: iload #234
/*      */     //   1225: if_icmpeq -> 1231
/*      */     //   1228: goto -> 1288
/*      */     //   1231: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1234: dup
/*      */     //   1235: ldc 'graphics '
/*      */     //   1237: invokevirtual getBytes : ()[B
/*      */     //   1240: iconst_0
/*      */     //   1241: invokespecial <init> : ([BI)V
/*      */     //   1244: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1247: dup
/*      */     //   1248: ldc_w 'invalid '%s' value '
/*      */     //   1251: invokevirtual getBytes : ()[B
/*      */     //   1254: iconst_0
/*      */     //   1255: invokespecial <init> : ([BI)V
/*      */     //   1258: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1261: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1264: iconst_1
/*      */     //   1265: anewarray java/lang/Object
/*      */     //   1268: dup
/*      */     //   1269: iconst_0
/*      */     //   1270: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1273: dup
/*      */     //   1274: ldc_w 'atpen '
/*      */     //   1277: invokevirtual getBytes : ()[B
/*      */     //   1280: iconst_0
/*      */     //   1281: invokespecial <init> : ([BI)V
/*      */     //   1284: aastore
/*      */     //   1285: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1288: aload #34
/*      */     //   1290: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1293: istore #11
/*      */     //   1295: iload #11
/*      */     //   1297: ifle -> 1303
/*      */     //   1300: goto -> 1360
/*      */     //   1303: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1306: dup
/*      */     //   1307: ldc 'graphics '
/*      */     //   1309: invokevirtual getBytes : ()[B
/*      */     //   1312: iconst_0
/*      */     //   1313: invokespecial <init> : ([BI)V
/*      */     //   1316: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1319: dup
/*      */     //   1320: ldc_w 'zero-length '%s' specified '
/*      */     //   1323: invokevirtual getBytes : ()[B
/*      */     //   1326: iconst_0
/*      */     //   1327: invokespecial <init> : ([BI)V
/*      */     //   1330: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1333: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1336: iconst_1
/*      */     //   1337: anewarray java/lang/Object
/*      */     //   1340: dup
/*      */     //   1341: iconst_0
/*      */     //   1342: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1345: dup
/*      */     //   1346: ldc_w 'labels '
/*      */     //   1349: invokevirtual getBytes : ()[B
/*      */     //   1352: iconst_0
/*      */     //   1353: invokespecial <init> : ([BI)V
/*      */     //   1356: aastore
/*      */     //   1357: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1360: aload #36
/*      */     //   1362: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1365: istore #12
/*      */     //   1367: aload #35
/*      */     //   1369: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1372: iload #12
/*      */     //   1374: if_icmpne -> 1380
/*      */     //   1377: goto -> 1420
/*      */     //   1380: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1383: dup
/*      */     //   1384: ldc 'graphics '
/*      */     //   1386: invokevirtual getBytes : ()[B
/*      */     //   1389: iconst_0
/*      */     //   1390: invokespecial <init> : ([BI)V
/*      */     //   1393: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1396: dup
/*      */     //   1397: ldc_w 'different argument lengths '
/*      */     //   1400: invokevirtual getBytes : ()[B
/*      */     //   1403: iconst_0
/*      */     //   1404: invokespecial <init> : ([BI)V
/*      */     //   1407: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1410: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1413: iconst_0
/*      */     //   1414: anewarray java/lang/Object
/*      */     //   1417: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1420: iload #11
/*      */     //   1422: iload #12
/*      */     //   1424: if_icmpgt -> 1430
/*      */     //   1427: goto -> 1470
/*      */     //   1430: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1433: dup
/*      */     //   1434: ldc 'graphics '
/*      */     //   1436: invokevirtual getBytes : ()[B
/*      */     //   1439: iconst_0
/*      */     //   1440: invokespecial <init> : ([BI)V
/*      */     //   1443: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1446: dup
/*      */     //   1447: ldc_w 'more 'labels' than points '
/*      */     //   1450: invokevirtual getBytes : ()[B
/*      */     //   1453: iconst_0
/*      */     //   1454: invokespecial <init> : ([BI)V
/*      */     //   1457: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1460: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1463: iconst_0
/*      */     //   1464: anewarray java/lang/Object
/*      */     //   1467: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1470: aload #5
/*      */     //   1472: iload #6
/*      */     //   1474: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1479: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1482: astore #223
/*      */     //   1484: aload #5
/*      */     //   1486: iload #6
/*      */     //   1488: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1493: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1496: sipush #484
/*      */     //   1499: invokeinterface getDouble : (I)D
/*      */     //   1504: dstore #219
/*      */     //   1506: aload #223
/*      */     //   1508: bipush #28
/*      */     //   1510: dload #219
/*      */     //   1512: invokeinterface setDouble : (ID)V
/*      */     //   1517: aload #31
/*      */     //   1519: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1522: bipush #15
/*      */     //   1524: bipush #13
/*      */     //   1526: aload #5
/*      */     //   1528: iload #6
/*      */     //   1530: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1535: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1538: dstore #19
/*      */     //   1540: bipush #10
/*      */     //   1542: iload #12
/*      */     //   1544: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   1547: astore #33
/*      */     //   1549: aload #33
/*      */     //   1551: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1554: pop
/*      */     //   1555: bipush #13
/*      */     //   1557: iload #12
/*      */     //   1559: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   1562: astore #32
/*      */     //   1564: aload #32
/*      */     //   1566: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1569: pop
/*      */     //   1570: iconst_0
/*      */     //   1571: istore #15
/*      */     //   1573: goto -> 1612
/*      */     //   1576: aload #33
/*      */     //   1578: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   1581: astore #215
/*      */     //   1583: iload #15
/*      */     //   1585: iconst_4
/*      */     //   1586: imul
/*      */     //   1587: istore #213
/*      */     //   1589: aload #215
/*      */     //   1591: astore #211
/*      */     //   1593: iconst_0
/*      */     //   1594: iload #213
/*      */     //   1596: iadd
/*      */     //   1597: istore #212
/*      */     //   1599: aload #211
/*      */     //   1601: iload #212
/*      */     //   1603: iconst_0
/*      */     //   1604: invokeinterface setInt : (II)V
/*      */     //   1609: iinc #15, 1
/*      */     //   1612: iload #15
/*      */     //   1614: iload #12
/*      */     //   1616: if_icmplt -> 1576
/*      */     //   1619: goto -> 1622
/*      */     //   1622: iconst_0
/*      */     //   1623: istore #13
/*      */     //   1625: iconst_2
/*      */     //   1626: aload #5
/*      */     //   1628: iload #6
/*      */     //   1630: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1635: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1638: aload #36
/*      */     //   1640: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1643: astore #36
/*      */     //   1645: aload #36
/*      */     //   1647: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1650: pop
/*      */     //   1651: aload #35
/*      */     //   1653: invokestatic Rf_duplicate : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1656: astore #35
/*      */     //   1658: aload #35
/*      */     //   1660: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1663: pop
/*      */     //   1664: goto -> 2927
/*      */     //   1667: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1670: dup
/*      */     //   1671: aload #26
/*      */     //   1673: iconst_0
/*      */     //   1674: invokespecial <init> : ([DI)V
/*      */     //   1677: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1680: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1683: dup
/*      */     //   1684: aload #25
/*      */     //   1686: iconst_0
/*      */     //   1687: invokespecial <init> : ([DI)V
/*      */     //   1690: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1693: bipush #13
/*      */     //   1695: aload #5
/*      */     //   1697: iload #6
/*      */     //   1699: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1704: invokestatic Rf_GLocator : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1707: ifeq -> 1713
/*      */     //   1710: goto -> 1716
/*      */     //   1713: goto -> 2937
/*      */     //   1716: aload #5
/*      */     //   1718: iload #6
/*      */     //   1720: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1725: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1728: astore #208
/*      */     //   1730: aload #5
/*      */     //   1732: iload #6
/*      */     //   1734: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1739: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1742: sipush #484
/*      */     //   1745: invokeinterface getDouble : (I)D
/*      */     //   1750: dstore #204
/*      */     //   1752: aload #208
/*      */     //   1754: bipush #28
/*      */     //   1756: dload #204
/*      */     //   1758: invokeinterface setDouble : (ID)V
/*      */     //   1763: ldc2_w 1.7976931348623157E308
/*      */     //   1766: dstore #21
/*      */     //   1768: iconst_m1
/*      */     //   1769: istore #14
/*      */     //   1771: iconst_0
/*      */     //   1772: istore #15
/*      */     //   1774: goto -> 1995
/*      */     //   1777: aload #36
/*      */     //   1779: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1782: astore #202
/*      */     //   1784: iload #15
/*      */     //   1786: bipush #8
/*      */     //   1788: imul
/*      */     //   1789: istore #200
/*      */     //   1791: aload #202
/*      */     //   1793: astore #198
/*      */     //   1795: iconst_0
/*      */     //   1796: iload #200
/*      */     //   1798: iadd
/*      */     //   1799: istore #199
/*      */     //   1801: aload #198
/*      */     //   1803: iload #199
/*      */     //   1805: invokeinterface getDouble : (I)D
/*      */     //   1810: dstore #196
/*      */     //   1812: aload #28
/*      */     //   1814: iconst_0
/*      */     //   1815: dload #196
/*      */     //   1817: dastore
/*      */     //   1818: aload #35
/*      */     //   1820: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1823: astore #194
/*      */     //   1825: iload #15
/*      */     //   1827: bipush #8
/*      */     //   1829: imul
/*      */     //   1830: istore #192
/*      */     //   1832: aload #194
/*      */     //   1834: astore #190
/*      */     //   1836: iconst_0
/*      */     //   1837: iload #192
/*      */     //   1839: iadd
/*      */     //   1840: istore #191
/*      */     //   1842: aload #190
/*      */     //   1844: iload #191
/*      */     //   1846: invokeinterface getDouble : (I)D
/*      */     //   1851: dstore #188
/*      */     //   1853: aload #27
/*      */     //   1855: iconst_0
/*      */     //   1856: dload #188
/*      */     //   1858: dastore
/*      */     //   1859: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1862: dup
/*      */     //   1863: aload #28
/*      */     //   1865: iconst_0
/*      */     //   1866: invokespecial <init> : ([DI)V
/*      */     //   1869: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1872: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1875: dup
/*      */     //   1876: aload #27
/*      */     //   1878: iconst_0
/*      */     //   1879: invokespecial <init> : ([DI)V
/*      */     //   1882: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1885: bipush #12
/*      */     //   1887: bipush #13
/*      */     //   1889: aload #5
/*      */     //   1891: iload #6
/*      */     //   1893: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1898: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1901: aload #28
/*      */     //   1903: iconst_0
/*      */     //   1904: daload
/*      */     //   1905: invokestatic R_finite : (D)I
/*      */     //   1908: ifeq -> 1927
/*      */     //   1911: goto -> 1914
/*      */     //   1914: aload #27
/*      */     //   1916: iconst_0
/*      */     //   1917: daload
/*      */     //   1918: invokestatic R_finite : (D)I
/*      */     //   1921: ifeq -> 1927
/*      */     //   1924: goto -> 1930
/*      */     //   1927: goto -> 1992
/*      */     //   1930: aload #25
/*      */     //   1932: iconst_0
/*      */     //   1933: daload
/*      */     //   1934: dstore #180
/*      */     //   1936: aload #27
/*      */     //   1938: iconst_0
/*      */     //   1939: daload
/*      */     //   1940: dstore #178
/*      */     //   1942: dload #180
/*      */     //   1944: dload #178
/*      */     //   1946: dsub
/*      */     //   1947: dstore #176
/*      */     //   1949: aload #26
/*      */     //   1951: iconst_0
/*      */     //   1952: daload
/*      */     //   1953: dstore #174
/*      */     //   1955: aload #28
/*      */     //   1957: iconst_0
/*      */     //   1958: daload
/*      */     //   1959: dstore #172
/*      */     //   1961: dload #174
/*      */     //   1963: dload #172
/*      */     //   1965: dsub
/*      */     //   1966: dload #176
/*      */     //   1968: invokestatic hypot : (DD)D
/*      */     //   1971: dstore #23
/*      */     //   1973: dload #23
/*      */     //   1975: dload #21
/*      */     //   1977: dcmpg
/*      */     //   1978: iflt -> 1984
/*      */     //   1981: goto -> 1992
/*      */     //   1984: iload #15
/*      */     //   1986: istore #14
/*      */     //   1988: dload #23
/*      */     //   1990: dstore #21
/*      */     //   1992: iinc #15, 1
/*      */     //   1995: iload #15
/*      */     //   1997: iload #12
/*      */     //   1999: if_icmplt -> 1777
/*      */     //   2002: goto -> 2005
/*      */     //   2005: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2008: dup
/*      */     //   2009: ldc_w 'warn '
/*      */     //   2012: invokevirtual getBytes : ()[B
/*      */     //   2015: iconst_0
/*      */     //   2016: invokespecial <init> : ([BI)V
/*      */     //   2019: invokestatic Rf_install : (Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/sexp/SEXP;
/*      */     //   2022: invokestatic Rf_GetOption1 : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2025: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2028: istore #7
/*      */     //   2030: dload #21
/*      */     //   2032: dload #17
/*      */     //   2034: dcmpl
/*      */     //   2035: ifgt -> 2041
/*      */     //   2038: goto -> 2103
/*      */     //   2041: iload #7
/*      */     //   2043: ifge -> 2049
/*      */     //   2046: goto -> 2927
/*      */     //   2049: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2052: dup
/*      */     //   2053: ldc 'graphics '
/*      */     //   2055: invokevirtual getBytes : ()[B
/*      */     //   2058: iconst_0
/*      */     //   2059: invokespecial <init> : ([BI)V
/*      */     //   2062: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2065: dup
/*      */     //   2066: ldc_w 'warning: no point within %.2f inches\\n '
/*      */     //   2069: invokevirtual getBytes : ()[B
/*      */     //   2072: iconst_0
/*      */     //   2073: invokespecial <init> : ([BI)V
/*      */     //   2076: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2079: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2082: iconst_1
/*      */     //   2083: anewarray java/lang/Object
/*      */     //   2086: dup
/*      */     //   2087: iconst_0
/*      */     //   2088: dload #17
/*      */     //   2090: invokestatic valueOf : (D)Ljava/lang/Double;
/*      */     //   2093: aastore
/*      */     //   2094: invokestatic REprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2097: invokestatic R_FlushConsole : ()V
/*      */     //   2100: goto -> 2927
/*      */     //   2103: aload #33
/*      */     //   2105: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   2108: astore #164
/*      */     //   2110: iload #14
/*      */     //   2112: iconst_4
/*      */     //   2113: imul
/*      */     //   2114: istore #162
/*      */     //   2116: aload #164
/*      */     //   2118: astore #160
/*      */     //   2120: iconst_0
/*      */     //   2121: iload #162
/*      */     //   2123: iadd
/*      */     //   2124: istore #161
/*      */     //   2126: aload #160
/*      */     //   2128: iload #161
/*      */     //   2130: invokeinterface getInt : (I)I
/*      */     //   2135: ifne -> 2141
/*      */     //   2138: goto -> 2195
/*      */     //   2141: iload #7
/*      */     //   2143: ifge -> 2149
/*      */     //   2146: goto -> 2927
/*      */     //   2149: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2152: dup
/*      */     //   2153: ldc 'graphics '
/*      */     //   2155: invokevirtual getBytes : ()[B
/*      */     //   2158: iconst_0
/*      */     //   2159: invokespecial <init> : ([BI)V
/*      */     //   2162: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2165: dup
/*      */     //   2166: ldc_w 'warning: nearest point already identified\\n '
/*      */     //   2169: invokevirtual getBytes : ()[B
/*      */     //   2172: iconst_0
/*      */     //   2173: invokespecial <init> : ([BI)V
/*      */     //   2176: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2179: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2182: iconst_0
/*      */     //   2183: anewarray java/lang/Object
/*      */     //   2186: invokestatic REprintf : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2189: invokestatic R_FlushConsole : ()V
/*      */     //   2192: goto -> 2927
/*      */     //   2195: iinc #13, 1
/*      */     //   2198: aload #33
/*      */     //   2200: invokestatic LOGICAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/IntPtr;
/*      */     //   2203: astore #155
/*      */     //   2205: iload #14
/*      */     //   2207: iconst_4
/*      */     //   2208: imul
/*      */     //   2209: istore #153
/*      */     //   2211: aload #155
/*      */     //   2213: astore #151
/*      */     //   2215: iconst_0
/*      */     //   2216: iload #153
/*      */     //   2218: iadd
/*      */     //   2219: istore #152
/*      */     //   2221: aload #151
/*      */     //   2223: iload #152
/*      */     //   2225: iconst_1
/*      */     //   2226: invokeinterface setInt : (II)V
/*      */     //   2231: iload #16
/*      */     //   2233: ifne -> 2239
/*      */     //   2236: goto -> 2423
/*      */     //   2239: aload #26
/*      */     //   2241: iconst_0
/*      */     //   2242: daload
/*      */     //   2243: dstore #149
/*      */     //   2245: aload #28
/*      */     //   2247: iconst_0
/*      */     //   2248: dload #149
/*      */     //   2250: dastore
/*      */     //   2251: aload #25
/*      */     //   2253: iconst_0
/*      */     //   2254: daload
/*      */     //   2255: dstore #147
/*      */     //   2257: aload #27
/*      */     //   2259: iconst_0
/*      */     //   2260: dload #147
/*      */     //   2262: dastore
/*      */     //   2263: aload #32
/*      */     //   2265: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2268: astore #145
/*      */     //   2270: iload #14
/*      */     //   2272: iconst_4
/*      */     //   2273: imul
/*      */     //   2274: istore #143
/*      */     //   2276: aload #145
/*      */     //   2278: astore #141
/*      */     //   2280: iconst_0
/*      */     //   2281: iload #143
/*      */     //   2283: iadd
/*      */     //   2284: istore #142
/*      */     //   2286: aload #141
/*      */     //   2288: iload #142
/*      */     //   2290: iconst_0
/*      */     //   2291: invokeinterface setInt : (II)V
/*      */     //   2296: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2299: dup
/*      */     //   2300: aload #26
/*      */     //   2302: iconst_0
/*      */     //   2303: invokespecial <init> : ([DI)V
/*      */     //   2306: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2309: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2312: dup
/*      */     //   2313: aload #25
/*      */     //   2315: iconst_0
/*      */     //   2316: invokespecial <init> : ([DI)V
/*      */     //   2319: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2322: bipush #13
/*      */     //   2324: bipush #12
/*      */     //   2326: aload #5
/*      */     //   2328: iload #6
/*      */     //   2330: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2335: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2338: aload #36
/*      */     //   2340: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2343: astore #139
/*      */     //   2345: iload #14
/*      */     //   2347: bipush #8
/*      */     //   2349: imul
/*      */     //   2350: istore #137
/*      */     //   2352: aload #139
/*      */     //   2354: astore #135
/*      */     //   2356: iconst_0
/*      */     //   2357: iload #137
/*      */     //   2359: iadd
/*      */     //   2360: istore #136
/*      */     //   2362: aload #26
/*      */     //   2364: iconst_0
/*      */     //   2365: daload
/*      */     //   2366: dstore #133
/*      */     //   2368: aload #135
/*      */     //   2370: iload #136
/*      */     //   2372: dload #133
/*      */     //   2374: invokeinterface setDouble : (ID)V
/*      */     //   2379: aload #35
/*      */     //   2381: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2384: astore #131
/*      */     //   2386: iload #14
/*      */     //   2388: bipush #8
/*      */     //   2390: imul
/*      */     //   2391: istore #129
/*      */     //   2393: aload #131
/*      */     //   2395: astore #127
/*      */     //   2397: iconst_0
/*      */     //   2398: iload #129
/*      */     //   2400: iadd
/*      */     //   2401: istore #128
/*      */     //   2403: aload #25
/*      */     //   2405: iconst_0
/*      */     //   2406: daload
/*      */     //   2407: dstore #125
/*      */     //   2409: aload #127
/*      */     //   2411: iload #128
/*      */     //   2413: dload #125
/*      */     //   2415: invokeinterface setDouble : (ID)V
/*      */     //   2420: goto -> 2789
/*      */     //   2423: aload #36
/*      */     //   2425: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2428: astore #123
/*      */     //   2430: iload #14
/*      */     //   2432: bipush #8
/*      */     //   2434: imul
/*      */     //   2435: istore #121
/*      */     //   2437: aload #123
/*      */     //   2439: astore #119
/*      */     //   2441: iconst_0
/*      */     //   2442: iload #121
/*      */     //   2444: iadd
/*      */     //   2445: istore #120
/*      */     //   2447: aload #119
/*      */     //   2449: iload #120
/*      */     //   2451: invokeinterface getDouble : (I)D
/*      */     //   2456: dstore #117
/*      */     //   2458: aload #28
/*      */     //   2460: iconst_0
/*      */     //   2461: dload #117
/*      */     //   2463: dastore
/*      */     //   2464: aload #35
/*      */     //   2466: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2469: astore #115
/*      */     //   2471: iload #14
/*      */     //   2473: bipush #8
/*      */     //   2475: imul
/*      */     //   2476: istore #113
/*      */     //   2478: aload #115
/*      */     //   2480: astore #111
/*      */     //   2482: iconst_0
/*      */     //   2483: iload #113
/*      */     //   2485: iadd
/*      */     //   2486: istore #112
/*      */     //   2488: aload #111
/*      */     //   2490: iload #112
/*      */     //   2492: invokeinterface getDouble : (I)D
/*      */     //   2497: dstore #109
/*      */     //   2499: aload #27
/*      */     //   2501: iconst_0
/*      */     //   2502: dload #109
/*      */     //   2504: dastore
/*      */     //   2505: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2508: dup
/*      */     //   2509: aload #28
/*      */     //   2511: iconst_0
/*      */     //   2512: invokespecial <init> : ([DI)V
/*      */     //   2515: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2518: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2521: dup
/*      */     //   2522: aload #27
/*      */     //   2524: iconst_0
/*      */     //   2525: invokespecial <init> : ([DI)V
/*      */     //   2528: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2531: bipush #12
/*      */     //   2533: bipush #13
/*      */     //   2535: aload #5
/*      */     //   2537: iload #6
/*      */     //   2539: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2544: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2547: aload #26
/*      */     //   2549: iconst_0
/*      */     //   2550: daload
/*      */     //   2551: dstore #107
/*      */     //   2553: aload #28
/*      */     //   2555: iconst_0
/*      */     //   2556: daload
/*      */     //   2557: dstore #105
/*      */     //   2559: dload #107
/*      */     //   2561: dload #105
/*      */     //   2563: dsub
/*      */     //   2564: invokestatic abs : (D)D
/*      */     //   2567: dstore #101
/*      */     //   2569: aload #25
/*      */     //   2571: iconst_0
/*      */     //   2572: daload
/*      */     //   2573: dstore #99
/*      */     //   2575: aload #27
/*      */     //   2577: iconst_0
/*      */     //   2578: daload
/*      */     //   2579: dstore #97
/*      */     //   2581: dload #99
/*      */     //   2583: dload #97
/*      */     //   2585: dsub
/*      */     //   2586: invokestatic abs : (D)D
/*      */     //   2589: dstore #93
/*      */     //   2591: dload #101
/*      */     //   2593: dload #93
/*      */     //   2595: dcmpl
/*      */     //   2596: ifge -> 2602
/*      */     //   2599: goto -> 2697
/*      */     //   2602: aload #26
/*      */     //   2604: iconst_0
/*      */     //   2605: daload
/*      */     //   2606: dstore #91
/*      */     //   2608: aload #28
/*      */     //   2610: iconst_0
/*      */     //   2611: daload
/*      */     //   2612: dstore #89
/*      */     //   2614: dload #91
/*      */     //   2616: dload #89
/*      */     //   2618: dcmpl
/*      */     //   2619: ifge -> 2625
/*      */     //   2622: goto -> 2661
/*      */     //   2625: aload #32
/*      */     //   2627: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2630: astore #87
/*      */     //   2632: iload #14
/*      */     //   2634: iconst_4
/*      */     //   2635: imul
/*      */     //   2636: istore #85
/*      */     //   2638: aload #87
/*      */     //   2640: astore #83
/*      */     //   2642: iconst_0
/*      */     //   2643: iload #85
/*      */     //   2645: iadd
/*      */     //   2646: istore #84
/*      */     //   2648: aload #83
/*      */     //   2650: iload #84
/*      */     //   2652: iconst_4
/*      */     //   2653: invokeinterface setInt : (II)V
/*      */     //   2658: goto -> 2789
/*      */     //   2661: aload #32
/*      */     //   2663: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2666: astore #81
/*      */     //   2668: iload #14
/*      */     //   2670: iconst_4
/*      */     //   2671: imul
/*      */     //   2672: istore #79
/*      */     //   2674: aload #81
/*      */     //   2676: astore #77
/*      */     //   2678: iconst_0
/*      */     //   2679: iload #79
/*      */     //   2681: iadd
/*      */     //   2682: istore #78
/*      */     //   2684: aload #77
/*      */     //   2686: iload #78
/*      */     //   2688: iconst_2
/*      */     //   2689: invokeinterface setInt : (II)V
/*      */     //   2694: goto -> 2789
/*      */     //   2697: aload #25
/*      */     //   2699: iconst_0
/*      */     //   2700: daload
/*      */     //   2701: dstore #75
/*      */     //   2703: aload #27
/*      */     //   2705: iconst_0
/*      */     //   2706: daload
/*      */     //   2707: dstore #73
/*      */     //   2709: dload #75
/*      */     //   2711: dload #73
/*      */     //   2713: dcmpl
/*      */     //   2714: ifge -> 2720
/*      */     //   2717: goto -> 2756
/*      */     //   2720: aload #32
/*      */     //   2722: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2725: astore #71
/*      */     //   2727: iload #14
/*      */     //   2729: iconst_4
/*      */     //   2730: imul
/*      */     //   2731: istore #69
/*      */     //   2733: aload #71
/*      */     //   2735: astore #67
/*      */     //   2737: iconst_0
/*      */     //   2738: iload #69
/*      */     //   2740: iadd
/*      */     //   2741: istore #68
/*      */     //   2743: aload #67
/*      */     //   2745: iload #68
/*      */     //   2747: iconst_3
/*      */     //   2748: invokeinterface setInt : (II)V
/*      */     //   2753: goto -> 2789
/*      */     //   2756: aload #32
/*      */     //   2758: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2761: astore #65
/*      */     //   2763: iload #14
/*      */     //   2765: iconst_4
/*      */     //   2766: imul
/*      */     //   2767: istore #63
/*      */     //   2769: aload #65
/*      */     //   2771: astore #61
/*      */     //   2773: iconst_0
/*      */     //   2774: iload #63
/*      */     //   2776: iadd
/*      */     //   2777: istore #62
/*      */     //   2779: aload #61
/*      */     //   2781: iload #62
/*      */     //   2783: iconst_1
/*      */     //   2784: invokeinterface setInt : (II)V
/*      */     //   2789: iload #9
/*      */     //   2791: ifne -> 2797
/*      */     //   2794: goto -> 2927
/*      */     //   2797: iload #14
/*      */     //   2799: iload #11
/*      */     //   2801: irem
/*      */     //   2802: istore #60
/*      */     //   2804: aload #34
/*      */     //   2806: iload #60
/*      */     //   2808: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2811: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2814: istore #58
/*      */     //   2816: iload #14
/*      */     //   2818: iload #11
/*      */     //   2820: irem
/*      */     //   2821: istore #57
/*      */     //   2823: aload #34
/*      */     //   2825: iload #57
/*      */     //   2827: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2830: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2833: astore #54
/*      */     //   2835: aload #32
/*      */     //   2837: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2840: astore #52
/*      */     //   2842: iload #14
/*      */     //   2844: iconst_4
/*      */     //   2845: imul
/*      */     //   2846: istore #50
/*      */     //   2848: aload #52
/*      */     //   2850: astore #48
/*      */     //   2852: iconst_0
/*      */     //   2853: iload #50
/*      */     //   2855: iadd
/*      */     //   2856: istore #49
/*      */     //   2858: aload #48
/*      */     //   2860: iload #49
/*      */     //   2862: invokeinterface getInt : (I)I
/*      */     //   2867: istore #47
/*      */     //   2869: aload #27
/*      */     //   2871: iconst_0
/*      */     //   2872: daload
/*      */     //   2873: dstore #45
/*      */     //   2875: aload #28
/*      */     //   2877: iconst_0
/*      */     //   2878: daload
/*      */     //   2879: dload #45
/*      */     //   2881: iload #47
/*      */     //   2883: dload #19
/*      */     //   2885: aload #54
/*      */     //   2887: iload #58
/*      */     //   2889: aload #5
/*      */     //   2891: iload #6
/*      */     //   2893: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2898: invokestatic drawLabel : (DDIDLorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2901: iconst_0
/*      */     //   2902: aload #5
/*      */     //   2904: iload #6
/*      */     //   2906: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2911: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2914: iconst_2
/*      */     //   2915: aload #5
/*      */     //   2917: iload #6
/*      */     //   2919: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2924: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2927: iload #13
/*      */     //   2929: iload #10
/*      */     //   2931: if_icmplt -> 1667
/*      */     //   2934: goto -> 2937
/*      */     //   2937: iconst_0
/*      */     //   2938: aload #5
/*      */     //   2940: iload #6
/*      */     //   2942: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2947: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2950: iconst_2
/*      */     //   2951: invokestatic Rf_allocList : (I)Lorg/renjin/sexp/SEXP;
/*      */     //   2954: astore #37
/*      */     //   2956: aload #37
/*      */     //   2958: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2961: pop
/*      */     //   2962: aload #37
/*      */     //   2964: aload #33
/*      */     //   2966: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2969: pop
/*      */     //   2970: aload #37
/*      */     //   2972: aload #32
/*      */     //   2974: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2977: pop
/*      */     //   2978: aload_0
/*      */     //   2979: aload #5
/*      */     //   2981: iload #6
/*      */     //   2983: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2988: invokestatic GRecording : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2991: ifne -> 2997
/*      */     //   2994: goto -> 3110
/*      */     //   2997: bipush #8
/*      */     //   2999: invokestatic Rf_allocList : (I)Lorg/renjin/sexp/SEXP;
/*      */     //   3002: astore #29
/*      */     //   3004: aload #29
/*      */     //   3006: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3009: pop
/*      */     //   3010: aload #29
/*      */     //   3012: aload #4
/*      */     //   3014: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3017: pop
/*      */     //   3018: aload #29
/*      */     //   3020: aload #33
/*      */     //   3022: invokestatic SETCADR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3025: pop
/*      */     //   3026: aload #29
/*      */     //   3028: aload #32
/*      */     //   3030: invokestatic SETCADDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3033: pop
/*      */     //   3034: aload #29
/*      */     //   3036: aload #36
/*      */     //   3038: invokestatic SETCADDDR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3041: pop
/*      */     //   3042: aload #29
/*      */     //   3044: aload #35
/*      */     //   3046: invokestatic SETCAD4R : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3049: pop
/*      */     //   3050: aload #29
/*      */     //   3052: iconst_5
/*      */     //   3053: invokestatic Rf_nthcdr : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   3056: aload #31
/*      */     //   3058: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3061: pop
/*      */     //   3062: aload #29
/*      */     //   3064: bipush #6
/*      */     //   3066: invokestatic Rf_nthcdr : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   3069: aload #34
/*      */     //   3071: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3074: pop
/*      */     //   3075: iload #9
/*      */     //   3077: invokestatic Rf_ScalarLogical : (I)Lorg/renjin/sexp/SEXP;
/*      */     //   3080: astore #39
/*      */     //   3082: aload #29
/*      */     //   3084: bipush #7
/*      */     //   3086: invokestatic Rf_nthcdr : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   3089: aload #39
/*      */     //   3091: invokestatic SETCAR : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3094: pop
/*      */     //   3095: aload_1
/*      */     //   3096: aload #29
/*      */     //   3098: aload #5
/*      */     //   3100: iload #6
/*      */     //   3102: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3107: invokestatic GErecordGraphicOperation : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3110: aload #37
/*      */     //   3112: astore #254
/*      */     //   3114: aload #254
/*      */     //   3116: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #3084	-> 181
/*      */     //   #3085	-> 189
/*      */     //   #3087	-> 195
/*      */     //   #3090	-> 200
/*      */     //   #3091	-> 218
/*      */     //   #3092	-> 229
/*      */     //   #3093	-> 240
/*      */     //   #3094	-> 251
/*      */     //   #3095	-> 262
/*      */     //   #3096	-> 273
/*      */     //   #3097	-> 284
/*      */     //   #3098	-> 290
/*      */     //   #3099	-> 297
/*      */     //   #3109	-> 304
/*      */     //   #3110	-> 359
/*      */     //   #3111	-> 382
/*      */     //   #3112	-> 388
/*      */     //   #3113	-> 438
/*      */     //   #3113	-> 454
/*      */     //   #3114	-> 462
/*      */     //   #3115	-> 523
/*      */     //   #3116	-> 584
/*      */     //   #3117	-> 626
/*      */     //   #3118	-> 676
/*      */     //   #3111	-> 766
/*      */     //   #3111	-> 769
/*      */     //   #3123	-> 779
/*      */     //   #3126	-> 787
/*      */     //   #3128	-> 799
/*      */     //   #3129	-> 810
/*      */     //   #3130	-> 821
/*      */     //   #3131	-> 832
/*      */     //   #3132	-> 846
/*      */     //   #3133	-> 860
/*      */     //   #3134	-> 871
/*      */     //   #3135	-> 885
/*      */     //   #3136	-> 894
/*      */     //   #3136	-> 902
/*      */     //   #3137	-> 917
/*      */     //   #3138	-> 974
/*      */     //   #3138	-> 987
/*      */     //   #3138	-> 1000
/*      */     //   #3138	-> 1013
/*      */     //   #3139	-> 1026
/*      */     //   #3140	-> 1066
/*      */     //   #3140	-> 1076
/*      */     //   #3141	-> 1087
/*      */     //   #3142	-> 1144
/*      */     //   #3143	-> 1159
/*      */     //   #3144	-> 1216
/*      */     //   #3145	-> 1231
/*      */     //   #3146	-> 1288
/*      */     //   #3147	-> 1295
/*      */     //   #3148	-> 1303
/*      */     //   #3149	-> 1360
/*      */     //   #3150	-> 1367
/*      */     //   #3151	-> 1380
/*      */     //   #3152	-> 1420
/*      */     //   #3153	-> 1430
/*      */     //   #3164	-> 1470
/*      */     //   #3165	-> 1517
/*      */     //   #3166	-> 1540
/*      */     //   #3167	-> 1555
/*      */     //   #3168	-> 1570
/*      */     //   #3168	-> 1576
/*      */     //   #3168	-> 1612
/*      */     //   #3170	-> 1622
/*      */     //   #3171	-> 1625
/*      */     //   #3172	-> 1638
/*      */     //   #3173	-> 1651
/*      */     //   #3175	-> 1667
/*      */     //   #3183	-> 1716
/*      */     //   #3184	-> 1763
/*      */     //   #3185	-> 1768
/*      */     //   #3186	-> 1771
/*      */     //   #3187	-> 1777
/*      */     //   #3188	-> 1818
/*      */     //   #3189	-> 1859
/*      */     //   #3190	-> 1901
/*      */     //   #3190	-> 1914
/*      */     //   #3191	-> 1930
/*      */     //   #3192	-> 1973
/*      */     //   #3193	-> 1984
/*      */     //   #3194	-> 1988
/*      */     //   #3186	-> 1992
/*      */     //   #3186	-> 1995
/*      */     //   #3199	-> 2005
/*      */     //   #3200	-> 2030
/*      */     //   #3201	-> 2041
/*      */     //   #3202	-> 2049
/*      */     //   #3203	-> 2097
/*      */     //   #3206	-> 2103
/*      */     //   #3207	-> 2141
/*      */     //   #3208	-> 2149
/*      */     //   #3209	-> 2189
/*      */     //   #3213	-> 2195
/*      */     //   #3214	-> 2198
/*      */     //   #3216	-> 2231
/*      */     //   #3217	-> 2239
/*      */     //   #3218	-> 2251
/*      */     //   #3219	-> 2263
/*      */     //   #3221	-> 2296
/*      */     //   #3222	-> 2338
/*      */     //   #3224	-> 2423
/*      */     //   #3225	-> 2464
/*      */     //   #3226	-> 2505
/*      */     //   #3227	-> 2547
/*      */     //   #3228	-> 2602
/*      */     //   #3229	-> 2625
/*      */     //   #3231	-> 2661
/*      */     //   #3233	-> 2697
/*      */     //   #3234	-> 2720
/*      */     //   #3236	-> 2756
/*      */     //   #3239	-> 2789
/*      */     //   #3240	-> 2797
/*      */     //   #3243	-> 2901
/*      */     //   #3244	-> 2914
/*      */     //   #3174	-> 2927
/*      */     //   #3248	-> 2937
/*      */     //   #3249	-> 2950
/*      */     //   #3250	-> 2962
/*      */     //   #3251	-> 2970
/*      */     //   #3252	-> 2978
/*      */     //   #3255	-> 2997
/*      */     //   #3256	-> 3010
/*      */     //   #3257	-> 3018
/*      */     //   #3258	-> 3026
/*      */     //   #3259	-> 3034
/*      */     //   #3260	-> 3042
/*      */     //   #3261	-> 3050
/*      */     //   #3262	-> 3062
/*      */     //   #3263	-> 3075
/*      */     //   #3265	-> 3095
/*      */     //   #3266	-> 3110
/*      */     //   #3268	-> 3110
/*      */     //   #3270	-> 3110
/*      */     //   #0	-> 3114
/*      */     //   #0	-> 3114
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	3117	0	call	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	1	op	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	2	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	3	rho	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	4	name	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	5	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	3117	6	dd$offset	I
/*      */     //   0	3117	7	warn	I
/*      */     //   0	3117	8	posi	I
/*      */     //   0	3117	9	plot	I
/*      */     //   0	3117	10	npts	I
/*      */     //   0	3117	11	nl	I
/*      */     //   0	3117	12	n	I
/*      */     //   0	3117	13	k	I
/*      */     //   0	3117	14	imin	I
/*      */     //   0	3117	15	i	I
/*      */     //   0	3117	16	atpen	I
/*      */     //   0	3117	17	tol	D
/*      */     //   0	3117	19	offset	D
/*      */     //   0	3117	21	dmin	D
/*      */     //   0	3117	23	d	D
/*      */     //   0	3117	25	yp	[D
/*      */     //   0	3117	26	xp	[D
/*      */     //   0	3117	27	yi	[D
/*      */     //   0	3117	28	xi	[D
/*      */     //   0	3117	29	saveans	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	30	draw	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	31	Offset	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	32	pos	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	33	ind	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	34	l	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	35	y	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	36	x	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	37	ans	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3117	43	xi$347	D
/*      */     //   0	3117	45	yi$346	D
/*      */     //   0	3117	51	imin$345	I
/*      */     //   0	3117	64	imin$344	I
/*      */     //   0	3117	70	imin$343	I
/*      */     //   0	3117	73	yi$342	D
/*      */     //   0	3117	75	yp$341	D
/*      */     //   0	3117	80	imin$340	I
/*      */     //   0	3117	86	imin$339	I
/*      */     //   0	3117	89	xi$338	D
/*      */     //   0	3117	91	xp$337	D
/*      */     //   0	3117	97	yi$336	D
/*      */     //   0	3117	99	yp$335	D
/*      */     //   0	3117	105	xi$334	D
/*      */     //   0	3117	107	xp$333	D
/*      */     //   0	3117	109	yi$332	D
/*      */     //   0	3117	114	imin$331	I
/*      */     //   0	3117	117	xi$330	D
/*      */     //   0	3117	122	imin$329	I
/*      */     //   0	3117	125	yp$328	D
/*      */     //   0	3117	130	imin$327	I
/*      */     //   0	3117	133	xp$326	D
/*      */     //   0	3117	138	imin$325	I
/*      */     //   0	3117	144	imin$324	I
/*      */     //   0	3117	147	yp$323	D
/*      */     //   0	3117	149	xp$322	D
/*      */     //   0	3117	154	imin$321	I
/*      */     //   0	3117	163	imin$320	I
/*      */     //   0	3117	172	xi$319	D
/*      */     //   0	3117	174	xp$318	D
/*      */     //   0	3117	178	yi$317	D
/*      */     //   0	3117	180	yp$316	D
/*      */     //   0	3117	183	yi$315	D
/*      */     //   0	3117	186	xi$314	D
/*      */     //   0	3117	188	yi$313	D
/*      */     //   0	3117	193	i$312	I
/*      */     //   0	3117	196	xi$311	D
/*      */     //   0	3117	201	i$310	I
/*      */     //   0	3117	214	i$309	I
/*      */     //   0	3117	234	R_NaInt$308	I
/*      */     //   0	3117	237	R_NaInt$307	I
/*      */     //   0	3117	249	R_NaInt$306	I
/*      */     //   0	3117	255	xi$305	D
/*      */     //   0	3117	257	yi$304	D
/*      */     //   0	3117	269	i$303	I
/*      */     //   0	3117	272	yi$302	D
/*      */     //   0	3117	277	i$301	I
/*      */     //   0	3117	280	xi$300	D
/*      */     //   0	3117	285	i$299	I
/*      */     //   0	3117	294	i$298	I
/*      */     //   0	3117	305	R_NilValue$297	Lorg/renjin/sexp/SEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_strHeight(SEXP args) {
/* 3334 */     dd = BytePtr.of(0); dd$offset = 0; cexsave = 0.0D; units = 0; n = 0; str = (SEXP)BytePtr.of(0).getArray(); ans = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0; args = Rinternals.CDR(args); if (Rinternals.Rf_length(args) <= 4) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);  str = Rinternals.CAR(args); if (Rinternals.TYPEOF(str) != 1 && !Rinternals.Rf_isLanguage(str)) { if (Rinternals.TYPEOF(str) != 20) str = Rinternals.Rf_coerceVector(str, 16);  } else { str = Rinternals.Rf_coerceVector(str, 20); }  Rinternals.Rf_protect(str); args = Rinternals.CDR(args); units = Rinternals.Rf_asInteger(Rinternals.CAR(args)); R_NaInt$291 = Arith.R_NaInt; if (units == R_NaInt$291 || units < 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid units\000".getBytes(), 0)), new Object[0]);  if (units == 1) graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));  args = Rinternals.CDR(args); if (Rinternals.TYPEOF(Rinternals.CAR(args)) != 0) { cex = Rinternals.Rf_asReal(Rinternals.CAR(args)); if (Arith.R_finite(cex) == 0 || cex <= 0.0D) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("cex\000".getBytes(), 0) });  } else { cex = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28); }  args = Rinternals.CDR(args); R_NaInt$292 = Arith.R_NaInt; font = FixupFont(Rinternals.CAR(args), R_NaInt$292); Rinternals.Rf_protect(font); args = Rinternals.CDR(args); vfont = Rf_FixupVFont(Rinternals.CAR(args)); Rinternals.Rf_protect(vfont); args = Rinternals.CDR(args); graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset)); par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset)); if (Rinternals.TYPEOF(vfont) == 0 || Rinternals.TYPEOF(str) == 20) { Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int j = Rinternals2.INTEGER(font).getInt(); ptr1.setInt(284, j); } else { Stdlib.strncpy(base__.Rf_gpptr(dd.pointerPlus(dd$offset)).pointerPlus(80), (Ptr)new BytePtr("Hershey \000".getBytes(), 0), 201); Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); byte b = (byte)Rinternals2.INTEGER(vfont).getInt(); ptr2.setByte(87, b); Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int j = Rinternals2.INTEGER(vfont).getInt(4); ptr1.setInt(284, j); }  n = Rinternals.LENGTH(str); ans = Rinternals.Rf_allocVector(14, n); Rinternals.Rf_protect(ans); cexsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28); Ptr ptr = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484) * cex; ptr.setDouble(28, d); for (i = 0; i < n; ) { if (Rinternals.TYPEOF(str) != 20) { ch = Rinternals.STRING_ELT(str, i); Ptr ptr2 = Rinternals2.REAL(ans); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; R_NaString$296 = Rinternals.R_NaString; if (ch != R_NaString$296) { int i1 = graphics__.Rf_GMapUnits(units), m = Rinternals.Rf_getCharCE(ch); iftmp$295 = graphics__.Rf_GStrHeight((Ptr)Rinternals.R_CHAR(ch), m, i1, dd.pointerPlus(dd$offset)); } else { iftmp$295 = 0.0D; }  ptr1.setDouble(j, iftmp$295); } else { Ptr ptr2 = Rinternals2.REAL(ans); int m = i * 8; Ptr ptr1 = ptr2; int k = 0 + m, j = graphics__.Rf_GMapUnits(units); double d1 = graphics__.Rf_GExpressionHeight(Rinternals.VECTOR_ELT(str, i), j, dd.pointerPlus(dd$offset)); ptr1.setDouble(k, d1); }  i++; }  base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(28, cexsave); graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset)); return ans;
/*      */   }
/*      */   public static SEXP C_strWidth(SEXP args) {
/* 3337 */     dd = BytePtr.of(0); dd$offset = 0; cexsave = 0.0D; units = 0; n = 0; str = (SEXP)BytePtr.of(0).getArray(); ans = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0; args = Rinternals.CDR(args); if (Rinternals.Rf_length(args) <= 4) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);  str = Rinternals.CAR(args); if (Rinternals.TYPEOF(str) != 1 && !Rinternals.Rf_isLanguage(str)) { if (Rinternals.TYPEOF(str) != 20) str = Rinternals.Rf_coerceVector(str, 16);  } else { str = Rinternals.Rf_coerceVector(str, 20); }  Rinternals.Rf_protect(str); args = Rinternals.CDR(args); units = Rinternals.Rf_asInteger(Rinternals.CAR(args)); R_NaInt$285 = Arith.R_NaInt; if (units == R_NaInt$285 || units < 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid units\000".getBytes(), 0)), new Object[0]);  if (units == 1) graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));  args = Rinternals.CDR(args); if (Rinternals.TYPEOF(Rinternals.CAR(args)) != 0) { cex = Rinternals.Rf_asReal(Rinternals.CAR(args)); if (Arith.R_finite(cex) == 0 || cex <= 0.0D) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("cex\000".getBytes(), 0) });  } else { cex = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28); }  args = Rinternals.CDR(args); R_NaInt$286 = Arith.R_NaInt; font = FixupFont(Rinternals.CAR(args), R_NaInt$286); Rinternals.Rf_protect(font); args = Rinternals.CDR(args); vfont = Rf_FixupVFont(Rinternals.CAR(args)); Rinternals.Rf_protect(vfont); args = Rinternals.CDR(args); graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset)); par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset)); if (Rinternals.TYPEOF(vfont) == 0 || Rinternals.TYPEOF(str) == 20) { Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int j = Rinternals2.INTEGER(font).getInt(); ptr1.setInt(284, j); } else { Stdlib.strncpy(base__.Rf_gpptr(dd.pointerPlus(dd$offset)).pointerPlus(80), (Ptr)new BytePtr("Hershey \000".getBytes(), 0), 201); Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); byte b = (byte)Rinternals2.INTEGER(vfont).getInt(); ptr2.setByte(87, b); Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int j = Rinternals2.INTEGER(vfont).getInt(4); ptr1.setInt(284, j); }  n = Rinternals.LENGTH(str); ans = Rinternals.Rf_allocVector(14, n); Rinternals.Rf_protect(ans); cexsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28); Ptr ptr = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484) * cex; ptr.setDouble(28, d); for (i = 0; i < n; ) { if (Rinternals.TYPEOF(str) != 20) { ch = Rinternals.STRING_ELT(str, i); Ptr ptr2 = Rinternals2.REAL(ans); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; R_NaString$290 = Rinternals.R_NaString; if (ch != R_NaString$290) { int i1 = graphics__.Rf_GMapUnits(units), m = Rinternals.Rf_getCharCE(ch); iftmp$289 = graphics__.Rf_GStrWidth((Ptr)Rinternals.R_CHAR(ch), m, i1, dd.pointerPlus(dd$offset)); } else { iftmp$289 = 0.0D; }  ptr1.setDouble(j, iftmp$289); } else { Ptr ptr2 = Rinternals2.REAL(ans); int m = i * 8; Ptr ptr1 = ptr2; int k = 0 + m, j = graphics__.Rf_GMapUnits(units); double d1 = graphics__.Rf_GExpressionWidth(Rinternals.VECTOR_ELT(str, i), j, dd.pointerPlus(dd$offset)); ptr1.setDouble(k, d1); }  i++; }  base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(28, cexsave); graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset)); return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void drawdend(int node, Ptr x, Ptr y, SEXP dnd_llabels, Ptr dd) {
/* 3362 */     yy = new double[4]; xx = new double[4]; yr = new double[1]; yl = new double[1]; xr = new double[1]; xl = new double[1]; yr[0] = 0.0D; yl[0] = 0.0D; xr[0] = 0.0D; xl[0] = 0.0D; dnd_hght$251 = Context.get__plot$dnd_hght(); dnd_hght$251$offset = Context.get__plot$dnd_hght$offset(); int i2 = (node + -1) * 8; Ptr ptr3 = dnd_hght$251; int i1 = dnd_hght$251$offset + i2; double d4 = ptr3.getDouble(i1); y.setDouble(d4);
/*      */     
/* 3364 */     dnd_lptr$253 = Context.get__plot$dnd_lptr(); dnd_lptr$253$offset = Context.get__plot$dnd_lptr$offset(); int n = (node + -1) * 4; Ptr ptr2 = dnd_lptr$253; int m = dnd_lptr$253$offset + n; k = ptr2.getInt(m);
/* 3365 */     if (k <= 0) {
/*      */       
/* 3367 */       dnd_xpos$255 = Context.get__plot$dnd_xpos(); dnd_xpos$255$offset = Context.get__plot$dnd_xpos$offset(); int i5 = (k ^ 0xFFFFFFFF) * 8; Ptr ptr = dnd_xpos$255; int i4 = dnd_xpos$255$offset + i5; xl$257 = ptr.getDouble(i4); xl[0] = xl$257;
/* 3368 */       if (Context.get__plot$dnd_hang() < 0.0D) { iftmp$258 = 0.0D; } else { double d = y.getDouble(); dnd_hang$260 = Context.get__plot$dnd_hang(); iftmp$258 = d - dnd_hang$260; }  yl[0] = iftmp$258;
/* 3369 */       int i3 = k ^ 0xFFFFFFFF; SEXP sEXP = Rinternals.STRING_ELT(dnd_llabels, i3); R_NaString$261 = Rinternals.R_NaString; if (sEXP != R_NaString$261) {
/* 3370 */         int i8 = k ^ 0xFFFFFFFF, i7 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(dnd_llabels, i8)), i6 = k ^ 0xFFFFFFFF; BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(dnd_llabels, i6)); yl$262 = yl[0]; dnd_offset$263 = Context.get__plot$dnd_offset(); double d = yl$262 - dnd_offset$263; graphics__.Rf_GText(xl[0], d, 12, (Ptr)bytePtr, i7, 1.0D, 0.3D, 90.0D, dd);
/*      */       } 
/*      */     } else {
/*      */       drawdend(k, (Ptr)new DoublePtr(xl, 0), (Ptr)new DoublePtr(yl, 0), dnd_llabels, dd);
/*      */     } 
/*      */     
/* 3376 */     dnd_rptr$265 = Context.get__plot$dnd_rptr(); dnd_rptr$265$offset = Context.get__plot$dnd_rptr$offset(); int j = (node + -1) * 4; Ptr ptr1 = dnd_rptr$265; int i = dnd_rptr$265$offset + j; k = ptr1.getInt(i);
/* 3377 */     if (k <= 0) {
/*      */       
/* 3379 */       dnd_xpos$267 = Context.get__plot$dnd_xpos(); dnd_xpos$267$offset = Context.get__plot$dnd_xpos$offset(); int i5 = (k ^ 0xFFFFFFFF) * 8; Ptr ptr = dnd_xpos$267; int i4 = dnd_xpos$267$offset + i5; xr$269 = ptr.getDouble(i4); xr[0] = xr$269;
/* 3380 */       if (Context.get__plot$dnd_hang() < 0.0D) { iftmp$270 = 0.0D; } else { double d = y.getDouble(); dnd_hang$272 = Context.get__plot$dnd_hang(); iftmp$270 = d - dnd_hang$272; }  yr[0] = iftmp$270;
/* 3381 */       int i3 = k ^ 0xFFFFFFFF; SEXP sEXP = Rinternals.STRING_ELT(dnd_llabels, i3); R_NaString$273 = Rinternals.R_NaString; if (sEXP != R_NaString$273) {
/* 3382 */         int i8 = k ^ 0xFFFFFFFF, i7 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(dnd_llabels, i8)), i6 = k ^ 0xFFFFFFFF; BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(dnd_llabels, i6)); yr$274 = yr[0]; dnd_offset$275 = Context.get__plot$dnd_offset(); double d = yr$274 - dnd_offset$275; graphics__.Rf_GText(xr[0], d, 12, (Ptr)bytePtr, i7, 1.0D, 0.3D, 90.0D, dd);
/*      */       } 
/*      */     } else {
/*      */       drawdend(k, (Ptr)new DoublePtr(xr, 0), (Ptr)new DoublePtr(yr, 0), dnd_llabels, dd);
/*      */     } 
/* 3387 */     xl$277 = xl[0]; xx[0] = xl$277; yl$278 = yl[0]; yy[0] = yl$278;
/* 3388 */     xl$279 = xl[0]; xx[1] = xl$279; double d3 = y.getDouble(); yy[1] = d3;
/* 3389 */     xr$280 = xr[0]; xx[2] = xr$280; double d2 = y.getDouble(); yy[2] = d2;
/* 3390 */     xr$281 = xr[0]; xx[3] = xr$281; yr$282 = yr[0]; yy[3] = yr$282;
/* 3391 */     graphics__.Rf_GPolyline(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), 12, dd);
/* 3392 */     xl$283 = xl[0]; xr$284 = xr[0]; double d1 = (xl$283 + xr$284) * 0.5D; x.setDouble(d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_dend(SEXP args) {
/* 3404 */     y = new double[1]; x = new double[1]; y[0] = 0.0D; x[0] = 0.0D; SEXP sEXP = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice();
/* 3405 */     graphics__.Rf_GCheckState(dd);
/*      */     
/* 3407 */     args = Rinternals.CDR(args);
/* 3408 */     if (Rinternals.Rf_length(args) <= 5) {
/* 3409 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     }
/*      */     
/* 3412 */     n = Rinternals.Rf_asInteger(Rinternals.CAR(args));
/* 3413 */     R_NaInt$237 = Arith.R_NaInt; if (n != R_NaInt$237 && n > 1) {
/*      */       
/* 3415 */       args = Rinternals.CDR(args);
/*      */ 
/*      */       
/* 3418 */       if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 13) { int j = Rinternals.Rf_length(Rinternals.CAR(args)), i = n * 2; if (j == i) {
/*      */           
/* 3420 */           Context.set__plot$dnd_lptr(Rinternals2.INTEGER(Rinternals.CAR(args))); Context.set__plot$dnd_lptr$offset(0);
/* 3421 */           Ptr ptr = Rinternals2.INTEGER(Rinternals.CAR(args)); int k = n * 4; dnd_rptr$240 = ptr; dnd_rptr$240$offset = 0 + k; Context.set__plot$dnd_rptr(dnd_rptr$240); Context.set__plot$dnd_rptr$offset(dnd_rptr$240$offset);
/* 3422 */           args = Rinternals.CDR(args);
/*      */ 
/*      */           
/* 3425 */           if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 14 && Rinternals.Rf_length(Rinternals.CAR(args)) == n)
/*      */           
/* 3427 */           { Context.set__plot$dnd_hght(Rinternals2.REAL(Rinternals.CAR(args))); Context.set__plot$dnd_hght$offset(0);
/* 3428 */             args = Rinternals.CDR(args);
/*      */ 
/*      */             
/* 3431 */             int i1 = Rinternals.Rf_length(Rinternals.CAR(args)), m = n + 1; if (i1 == m)
/*      */             
/* 3433 */             { xpos = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); Rinternals.Rf_protect(xpos);
/* 3434 */               Context.set__plot$dnd_xpos(Rinternals2.REAL(xpos)); Context.set__plot$dnd_xpos$offset(0);
/* 3435 */               args = Rinternals.CDR(args);
/*      */ 
/*      */               
/* 3438 */               Context.set__plot$dnd_hang(Rinternals.Rf_asReal(Rinternals.CAR(args)));
/* 3439 */               if (Arith.R_finite(Context.get__plot$dnd_hang()) != 0)
/*      */               
/* 3441 */               { dnd_hght$245 = Context.get__plot$dnd_hght(); dnd_hght$245$offset = Context.get__plot$dnd_hght$offset(); int i3 = (n + -1) * 8; Ptr ptr1 = dnd_hght$245; int i2 = dnd_hght$245$offset + i3; double d3 = ptr1.getDouble(i2); dnd_hght$247 = Context.get__plot$dnd_hght(); dnd_hght$247$offset = Context.get__plot$dnd_hght$offset(); double d2 = dnd_hght$247.getDouble(dnd_hght$247$offset), d1 = d3 - d2; dnd_hang$248 = Context.get__plot$dnd_hang(); Context.set__plot$dnd_hang(d1 * dnd_hang$248);
/* 3442 */                 args = Rinternals.CDR(args);
/*      */ 
/*      */                 
/* 3445 */                 if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 16) { int i5 = Rinternals.Rf_length(Rinternals.CAR(args)), i4 = n + 1; if (i5 == i4)
/*      */                   
/* 3447 */                   { dnd_llabels = Rinternals.CAR(args);
/* 3448 */                     args = Rinternals.CDR(args);
/*      */                     
/* 3450 */                     graphics__.Rf_GSavePars(dd);
/* 3451 */                     par__.Rf_ProcessInlinePars(args, dd);
/* 3452 */                     Ptr ptr2 = base__.Rf_gpptr(dd); double d6 = base__.Rf_gpptr(dd).getDouble(484), d5 = base__.Rf_gpptr(dd).getDouble(28), d4 = d6 * d5; ptr2.setDouble(28, d4);
/* 3453 */                     Context.set__plot$dnd_offset(graphics__.Rf_GConvertYUnits(graphics__.Rf_GStrWidth((Ptr)new BytePtr("m\000".getBytes(), 0), 99, 13, dd), 13, 12, dd));
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 3458 */                     if (base__.Rf_gpptr(dd).getInt(444) <= 0) {
/* 3459 */                       base__.Rf_gpptr(dd).setInt(444, 1);
/*      */                     }
/* 3461 */                     graphics__.Rf_GMode(1, dd);
/* 3462 */                     drawdend(n, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), dnd_llabels, dd);
/* 3463 */                     graphics__.Rf_GMode(0, dd);
/* 3464 */                     graphics__.Rf_GRestorePars(dd);
/*      */                     
/* 3466 */                     return Rinternals.R_NilValue; }  }  }  }  } 
/*      */         }  }
/*      */     
/* 3469 */     }  Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid dendrogram input\000".getBytes(), 0)), new Object[0]);
/*      */     return sEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_dendwindow(SEXP args) {
/* 3481 */     dd = BytePtr.of(0); dd$offset = 0; vmax = BytePtr.of(0); vmax$offset = 0; llabels = (SEXP)BytePtr.of(0).getArray(); height = (SEXP)BytePtr.of(0).getArray(); yrange = 0.0D; ymax = 0.0D; ymin = 0.0D; y = BytePtr.of(0); y$offset = 0; yval = 0.0D; ll = BytePtr.of(0); ll$offset = 0; pin = 0.0D; n = 0; imax = 0; SEXP sEXP = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/* 3482 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/* 3483 */     args = Rinternals.CDR(args);
/* 3484 */     if (Rinternals.Rf_length(args) <= 4)
/* 3485 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]); 
/* 3486 */     n = Rinternals.Rf_asInteger(Rinternals.CAR(args));
/* 3487 */     R_NaInt$209 = Arith.R_NaInt; if (n != R_NaInt$209 && n > 1) {
/*      */       
/* 3489 */       args = Rinternals.CDR(args);
/* 3490 */       if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 13) { int k = Rinternals.Rf_length(Rinternals.CAR(args)), j = n * 2; if (k == j)
/*      */         
/* 3492 */         { merge = Rinternals.CAR(args);
/*      */           
/* 3494 */           args = Rinternals.CDR(args);
/* 3495 */           if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 14 && Rinternals.Rf_length(Rinternals.CAR(args)) == n)
/*      */           
/* 3497 */           { height = Rinternals.CAR(args);
/*      */             
/* 3499 */             args = Rinternals.CDR(args);
/* 3500 */             Context.set__plot$dnd_hang(Rinternals.Rf_asReal(Rinternals.CAR(args)));
/* 3501 */             if (Arith.R_finite(Context.get__plot$dnd_hang()) != 0)
/*      */             
/*      */             { 
/* 3504 */               args = Rinternals.CDR(args);
/* 3505 */               if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 16) { int i2 = Rinternals.Rf_length(Rinternals.CAR(args)), i1 = n + 1; if (i2 == i1)
/*      */                 
/* 3507 */                 { llabels = Rinternals.CAR(args);
/*      */                   
/* 3509 */                   args = Rinternals.CDR(args);
/* 3510 */                   graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 3511 */                   par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/* 3512 */                   Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); double d7 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(484), d6 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28), d5 = d7 * d6; ptr2.setDouble(28, d5);
/* 3513 */                   Context.set__plot$dnd_offset(graphics__.Rf_GStrWidth((Ptr)new BytePtr("m\000".getBytes(), 0), 99, 13, dd.pointerPlus(dd$offset)));
/* 3514 */                   vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */                   
/* 3516 */                   DoublePtr doublePtr1 = DoublePtr.malloc((n + 1) * 8); y$offset = 0;
/* 3517 */                   DoublePtr doublePtr2 = DoublePtr.malloc((n + 1) * 8); ll$offset = 0;
/* 3518 */                   Context.set__plot$dnd_lptr(Rinternals2.INTEGER(merge)); Context.set__plot$dnd_lptr$offset(0);
/* 3519 */                   Ptr ptr1 = Rinternals2.INTEGER(merge); int i5 = n * 4; dnd_rptr$215 = ptr1; dnd_rptr$215$offset = 0 + i5; Context.set__plot$dnd_rptr(dnd_rptr$215); Context.set__plot$dnd_rptr$offset(dnd_rptr$215$offset);
/* 3520 */                   ymax = ymin = Rinternals2.REAL(height).getDouble();
/* 3521 */                   for (i = 1; i < n; i++) {
/* 3522 */                     Ptr ptr4 = Rinternals2.REAL(height); int i7 = i * 8; Ptr ptr3 = ptr4; int i6 = 0 + i7; m = ptr3.getDouble(i6);
/* 3523 */                     if (m <= ymax)
/*      */                     
/* 3525 */                     { if (m < ymin)
/* 3526 */                         ymin = m;  } else { ymax = m; }
/*      */                   
/* 3528 */                   }  pin = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(0 + 35492 + 8);
/* 3529 */                   for (i = 0; i <= n; i++) {
/* 3530 */                     str = Rinternals.STRING_ELT(llabels, i);
/* 3531 */                     int i7 = i * 8; DoublePtr doublePtr = doublePtr2; int i6 = ll$offset + i7; R_NaString$219 = Rinternals.R_NaString; if (str != R_NaString$219)
/* 3532 */                     { int i8 = Rinternals.Rf_getCharCE(str); double d = graphics__.Rf_GStrWidth((Ptr)Rinternals.R_CHAR(str), i8, 13, dd.pointerPlus(dd$offset)); dnd_offset$220 = Context.get__plot$dnd_offset(); iftmp$218 = d + dnd_offset$220; }
/*      */                     else { iftmp$218 = 0.0D; }
/*      */                      doublePtr.setDouble(i6, iftmp$218);
/* 3535 */                   }  imax = -1; yval = -1.7976931348623157E308D;
/* 3536 */                   if (Context.get__plot$dnd_hang() < 0.0D)
/*      */                   
/*      */                   { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 3558 */                     yrange = ymax;
/* 3559 */                     for (i = 0; i <= n; i++)
/* 3560 */                     { int i7 = i * 8; DoublePtr doublePtr = doublePtr2; int i6 = ll$offset + i7; tmp = doublePtr.getDouble(i6) + pin;
/* 3561 */                       if (tmp > yval)
/* 3562 */                       { yval = tmp;
/* 3563 */                         imax = i; }  }  } else { double d10 = Context.get__plot$dnd_hang() + 1.0D, d9 = ymax - ymin, d8 = d10 * d9; ymin = ymax - d8; yrange = ymax - ymin; for (i = 0; i < n; i++) { dnd_lptr$223 = Context.get__plot$dnd_lptr(); dnd_lptr$223$offset = Context.get__plot$dnd_lptr$offset(); int i9 = i * 4; Ptr ptr4 = dnd_lptr$223; int i8 = dnd_lptr$223$offset + i9; if (ptr4.getInt(i8) < 0) { dnd_lptr$225 = Context.get__plot$dnd_lptr(); dnd_lptr$225$offset = Context.get__plot$dnd_lptr$offset(); int i15 = i * 4; Ptr ptr7 = dnd_lptr$225; int i14 = dnd_lptr$225$offset + i15, i13 = (ptr7.getInt(i14) ^ 0xFFFFFFFF) * 8; DoublePtr doublePtr = doublePtr1; int i12 = y$offset + i13; Ptr ptr6 = Rinternals2.REAL(height); int i11 = i * 8; Ptr ptr5 = ptr6; int i10 = 0 + i11; double d = ptr5.getDouble(i10); doublePtr.setDouble(i12, d); }  dnd_rptr$228 = Context.get__plot$dnd_rptr(); dnd_rptr$228$offset = Context.get__plot$dnd_rptr$offset(); int i7 = i * 4; Ptr ptr3 = dnd_rptr$228; int i6 = dnd_rptr$228$offset + i7; if (ptr3.getInt(i6) < 0) { dnd_rptr$230 = Context.get__plot$dnd_rptr(); dnd_rptr$230$offset = Context.get__plot$dnd_rptr$offset(); int i15 = i * 4; Ptr ptr7 = dnd_rptr$230; int i14 = dnd_rptr$230$offset + i15, i13 = (ptr7.getInt(i14) ^ 0xFFFFFFFF) * 8; DoublePtr doublePtr = doublePtr1; int i12 = y$offset + i13; Ptr ptr6 = Rinternals2.REAL(height); int i11 = i * 8; Ptr ptr5 = ptr6; int i10 = 0 + i11; double d = ptr5.getDouble(i10); doublePtr.setDouble(i12, d); }
/*      */                        }
/*      */                      for (i = 0; i <= n; i++) { int i9 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i8 = y$offset + i9; double d13 = doublePtr5.getDouble(i8), d12 = (ymax - d13) / yrange * pin; int i7 = i * 8; DoublePtr doublePtr4 = doublePtr2; int i6 = ll$offset + i7; double d11 = doublePtr4.getDouble(i6); tmp = d12 + d11; if (tmp > yval) { yval = tmp; imax = i; }
/*      */                        }
/*      */                      }
/* 3568 */                    int i4 = imax * 8; DoublePtr doublePtr3 = doublePtr2; int i3 = ll$offset + i4; double d4 = doublePtr3.getDouble(i3), d3 = pin - d4, d2 = pin / d3 * yrange; ymin = ymax - d2;
/* 3569 */                   double d1 = n + 1.0D; graphics__.Rf_GScale(1.0D, d1, 1, dd.pointerPlus(dd$offset));
/* 3570 */                   graphics__.Rf_GScale(ymin, ymax, 2, dd.pointerPlus(dd$offset));
/* 3571 */                   graphics__.Rf_GMapWin2Fig(dd.pointerPlus(dd$offset));
/* 3572 */                   graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/*      */                   
/* 3574 */                   return Rinternals.R_NilValue; }  }  }  }  }  }
/*      */     
/* 3576 */     }  Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid dendrogram input\000".getBytes(), 0)), new Object[0]);
/*      */     return sEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_erase(SEXP args) {
/* 3584 */     dd = baseDevices__.GEcurrentDevice();
/* 3585 */     args = Rinternals.CDR(args);
/* 3586 */     col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col);
/* 3587 */     graphics__.Rf_GSavePars(dd);
/* 3588 */     graphics__.Rf_GMode(1, dd);
/* 3589 */     int i = Rinternals2.INTEGER(col).getInt(); graphics__.Rf_GRect(0.0D, 0.0D, 1.0D, 1.0D, 1, i, 16777215, dd);
/* 3590 */     graphics__.Rf_GMode(0, dd);
/* 3591 */     graphics__.Rf_GRestorePars(dd);
/*      */     
/* 3593 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int SymbolRange(Ptr x, int n, Ptr xmax, Ptr xmin) {
/* 3602 */     xmax.setDouble(-1.7976931348623157E308D);
/* 3603 */     xmin.setDouble(Double.MAX_VALUE);
/* 3604 */     for (i = 0; i < n; i++) {
/* 3605 */       int k = i * 8; Ptr ptr = x; int j = k; if (Arith.R_finite(ptr.getDouble(j)) != 0) {
/* 3606 */         double d6 = xmax.getDouble(); int i3 = i * 8; Ptr ptr2 = x; int i2 = i3; double d5 = ptr2.getDouble(i2); if (d6 < d5) { int i5 = i * 8; Ptr ptr3 = x; int i4 = i5; double d = ptr3.getDouble(i4); xmax.setDouble(d); }
/* 3607 */          double d4 = xmin.getDouble(); int i1 = i * 8; Ptr ptr1 = x; int m = i1; double d3 = ptr1.getDouble(m); if (d4 > d3) { int i5 = i * 8; Ptr ptr3 = x; int i4 = i5; double d = ptr3.getDouble(i4); xmin.setDouble(d); } 
/*      */       } 
/* 3609 */     }  double d2 = xmax.getDouble(), d1 = xmin.getDouble(); return (d2 < d1 || xmin.getDouble() < 0.0D) ? 0 : 1;
/*      */   }
/*      */   
/*      */   public static void CheckSymbolPar(SEXP p, Ptr nr, Ptr nc) {
/*      */     int i, j, k, m;
/* 3614 */     R_DimSymbol$202 = Rinternals.R_DimSymbol; dim = Rinternals.Rf_getAttrib(p, R_DimSymbol$202);
/* 3615 */     switch (Rinternals.Rf_length(dim)) {
/*      */       case 0:
/* 3617 */         m = Rinternals.LENGTH(p); nr.setInt(m);
/* 3618 */         nc.setInt(1);
/*      */         break;
/*      */       case 1:
/* 3621 */         k = Rinternals2.INTEGER(dim).getInt(); nr.setInt(k);
/* 3622 */         nc.setInt(1);
/*      */         break;
/*      */       case 2:
/* 3625 */         j = Rinternals2.INTEGER(dim).getInt(); nr.setInt(j);
/* 3626 */         i = Rinternals2.INTEGER(dim).getInt(4); nc.setInt(i);
/*      */         break;
/*      */       default:
/* 3629 */         nr.setInt(0);
/* 3630 */         nc.setInt(0); break;
/*      */     } 
/* 3632 */     if (nr.getInt() == 0 || nc.getInt() == 0) {
/* 3633 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid symbol parameter vector\000".getBytes(), 0)), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_symbols(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #21
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #22
/*      */     //   10: iconst_1
/*      */     //   11: newarray double
/*      */     //   13: astore #29
/*      */     //   15: iconst_1
/*      */     //   16: newarray double
/*      */     //   18: astore #30
/*      */     //   20: iconst_1
/*      */     //   21: newarray int
/*      */     //   23: astore #34
/*      */     //   25: iconst_1
/*      */     //   26: newarray int
/*      */     //   28: astore #35
/*      */     //   30: iconst_0
/*      */     //   31: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   34: astore_1
/*      */     //   35: iconst_0
/*      */     //   36: istore_2
/*      */     //   37: iconst_0
/*      */     //   38: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   41: astore_3
/*      */     //   42: iconst_0
/*      */     //   43: istore #4
/*      */     //   45: iconst_0
/*      */     //   46: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   49: astore #5
/*      */     //   51: iconst_0
/*      */     //   52: istore #6
/*      */     //   54: iconst_0
/*      */     //   55: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   58: astore #7
/*      */     //   60: iconst_0
/*      */     //   61: istore #8
/*      */     //   63: iconst_0
/*      */     //   64: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   67: astore #9
/*      */     //   69: iconst_0
/*      */     //   70: istore #10
/*      */     //   72: dconst_0
/*      */     //   73: dstore #17
/*      */     //   75: aload #21
/*      */     //   77: iconst_0
/*      */     //   78: dconst_0
/*      */     //   79: dastore
/*      */     //   80: aload #22
/*      */     //   82: iconst_0
/*      */     //   83: dconst_0
/*      */     //   84: dastore
/*      */     //   85: dconst_0
/*      */     //   86: dstore #27
/*      */     //   88: aload #29
/*      */     //   90: iconst_0
/*      */     //   91: dconst_0
/*      */     //   92: dastore
/*      */     //   93: aload #30
/*      */     //   95: iconst_0
/*      */     //   96: dconst_0
/*      */     //   97: dastore
/*      */     //   98: iconst_0
/*      */     //   99: istore #32
/*      */     //   101: iconst_0
/*      */     //   102: istore #33
/*      */     //   104: aload #34
/*      */     //   106: iconst_0
/*      */     //   107: iconst_0
/*      */     //   108: iastore
/*      */     //   109: aload #35
/*      */     //   111: iconst_0
/*      */     //   112: iconst_0
/*      */     //   113: iastore
/*      */     //   114: iconst_0
/*      */     //   115: istore #37
/*      */     //   117: iconst_0
/*      */     //   118: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   121: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   126: checkcast org/renjin/sexp/SEXP
/*      */     //   129: astore #38
/*      */     //   131: iconst_0
/*      */     //   132: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   135: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   140: checkcast org/renjin/sexp/SEXP
/*      */     //   143: astore #39
/*      */     //   145: iconst_0
/*      */     //   146: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   149: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   154: checkcast org/renjin/sexp/SEXP
/*      */     //   157: astore #40
/*      */     //   159: iconst_0
/*      */     //   160: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   163: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   168: checkcast org/renjin/sexp/SEXP
/*      */     //   171: astore #41
/*      */     //   173: iconst_0
/*      */     //   174: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   177: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   182: checkcast org/renjin/sexp/SEXP
/*      */     //   185: astore #42
/*      */     //   187: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   190: astore_1
/*      */     //   191: iconst_0
/*      */     //   192: istore_2
/*      */     //   193: aload_1
/*      */     //   194: iload_2
/*      */     //   195: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   200: invokestatic Rf_GCheckState : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   203: aload_0
/*      */     //   204: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   207: astore_0
/*      */     //   208: aload_0
/*      */     //   209: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   212: bipush #6
/*      */     //   214: if_icmple -> 220
/*      */     //   217: goto -> 259
/*      */     //   220: new org/renjin/gcc/runtime/BytePtr
/*      */     //   223: dup
/*      */     //   224: ldc 'graphics '
/*      */     //   226: invokevirtual getBytes : ()[B
/*      */     //   229: iconst_0
/*      */     //   230: invokespecial <init> : ([BI)V
/*      */     //   233: new org/renjin/gcc/runtime/BytePtr
/*      */     //   236: dup
/*      */     //   237: ldc 'too few arguments '
/*      */     //   239: invokevirtual getBytes : ()[B
/*      */     //   242: iconst_0
/*      */     //   243: invokespecial <init> : ([BI)V
/*      */     //   246: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   249: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   252: iconst_0
/*      */     //   253: anewarray java/lang/Object
/*      */     //   256: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   259: aload_0
/*      */     //   260: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   263: bipush #14
/*      */     //   265: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   268: astore #42
/*      */     //   270: aload #42
/*      */     //   272: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   275: pop
/*      */     //   276: aload_0
/*      */     //   277: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   280: astore_0
/*      */     //   281: aload_0
/*      */     //   282: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   285: bipush #14
/*      */     //   287: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   290: astore #41
/*      */     //   292: aload #41
/*      */     //   294: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   297: pop
/*      */     //   298: aload_0
/*      */     //   299: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   302: astore_0
/*      */     //   303: aload #42
/*      */     //   305: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   308: ifeq -> 347
/*      */     //   311: goto -> 314
/*      */     //   314: aload #41
/*      */     //   316: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   319: ifeq -> 347
/*      */     //   322: goto -> 325
/*      */     //   325: aload #42
/*      */     //   327: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   330: ifle -> 347
/*      */     //   333: goto -> 336
/*      */     //   336: aload #42
/*      */     //   338: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   341: ifle -> 347
/*      */     //   344: goto -> 387
/*      */     //   347: new org/renjin/gcc/runtime/BytePtr
/*      */     //   350: dup
/*      */     //   351: ldc 'graphics '
/*      */     //   353: invokevirtual getBytes : ()[B
/*      */     //   356: iconst_0
/*      */     //   357: invokespecial <init> : ([BI)V
/*      */     //   360: new org/renjin/gcc/runtime/BytePtr
/*      */     //   363: dup
/*      */     //   364: ldc_w 'invalid symbol coordinates '
/*      */     //   367: invokevirtual getBytes : ()[B
/*      */     //   370: iconst_0
/*      */     //   371: invokespecial <init> : ([BI)V
/*      */     //   374: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   377: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   380: iconst_0
/*      */     //   381: anewarray java/lang/Object
/*      */     //   384: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   387: aload_0
/*      */     //   388: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   391: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   394: istore #31
/*      */     //   396: aload_0
/*      */     //   397: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   400: astore_0
/*      */     //   401: aload_0
/*      */     //   402: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   405: bipush #14
/*      */     //   407: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   410: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   413: astore #40
/*      */     //   415: aload_0
/*      */     //   416: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   419: astore_0
/*      */     //   420: aload #40
/*      */     //   422: new org/renjin/gcc/runtime/IntPtr
/*      */     //   425: dup
/*      */     //   426: aload #35
/*      */     //   428: iconst_0
/*      */     //   429: invokespecial <init> : ([II)V
/*      */     //   432: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   435: new org/renjin/gcc/runtime/IntPtr
/*      */     //   438: dup
/*      */     //   439: aload #34
/*      */     //   441: iconst_0
/*      */     //   442: invokespecial <init> : ([II)V
/*      */     //   445: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   448: invokestatic CheckSymbolPar : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   451: aload #42
/*      */     //   453: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   456: wide istore #926
/*      */     //   460: aload #35
/*      */     //   462: iconst_0
/*      */     //   463: iaload
/*      */     //   464: wide istore #925
/*      */     //   468: wide iload #926
/*      */     //   472: wide iload #925
/*      */     //   476: if_icmpne -> 513
/*      */     //   479: goto -> 482
/*      */     //   482: aload #41
/*      */     //   484: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   487: wide istore #924
/*      */     //   491: aload #35
/*      */     //   493: iconst_0
/*      */     //   494: iaload
/*      */     //   495: wide istore #923
/*      */     //   499: wide iload #924
/*      */     //   503: wide iload #923
/*      */     //   507: if_icmpne -> 513
/*      */     //   510: goto -> 553
/*      */     //   513: new org/renjin/gcc/runtime/BytePtr
/*      */     //   516: dup
/*      */     //   517: ldc 'graphics '
/*      */     //   519: invokevirtual getBytes : ()[B
/*      */     //   522: iconst_0
/*      */     //   523: invokespecial <init> : ([BI)V
/*      */     //   526: new org/renjin/gcc/runtime/BytePtr
/*      */     //   529: dup
/*      */     //   530: ldc_w 'x/y/parameter length mismatch '
/*      */     //   533: invokevirtual getBytes : ()[B
/*      */     //   536: iconst_0
/*      */     //   537: invokespecial <init> : ([BI)V
/*      */     //   540: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   543: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   546: iconst_0
/*      */     //   547: anewarray java/lang/Object
/*      */     //   550: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   553: aload_0
/*      */     //   554: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   557: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   560: dstore #27
/*      */     //   562: aload_0
/*      */     //   563: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   566: astore_0
/*      */     //   567: dload #27
/*      */     //   569: invokestatic R_finite : (D)I
/*      */     //   572: ifeq -> 588
/*      */     //   575: goto -> 578
/*      */     //   578: dload #27
/*      */     //   580: dconst_0
/*      */     //   581: dcmpg
/*      */     //   582: iflt -> 588
/*      */     //   585: goto -> 591
/*      */     //   588: dconst_0
/*      */     //   589: dstore #27
/*      */     //   591: aload_0
/*      */     //   592: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   595: ldc 16777215
/*      */     //   597: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   600: astore #38
/*      */     //   602: aload #38
/*      */     //   604: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   607: pop
/*      */     //   608: aload_0
/*      */     //   609: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   612: astore_0
/*      */     //   613: aload #38
/*      */     //   615: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   618: istore #33
/*      */     //   620: aload_0
/*      */     //   621: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   624: ldc 16777215
/*      */     //   626: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   629: astore #39
/*      */     //   631: aload #39
/*      */     //   633: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   636: pop
/*      */     //   637: aload_0
/*      */     //   638: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   641: astore_0
/*      */     //   642: aload #39
/*      */     //   644: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   647: istore #32
/*      */     //   649: aload_1
/*      */     //   650: iload_2
/*      */     //   651: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   656: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   659: aload_0
/*      */     //   660: aload_1
/*      */     //   661: iload_2
/*      */     //   662: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   667: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   670: iconst_1
/*      */     //   671: aload_1
/*      */     //   672: iload_2
/*      */     //   673: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   678: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   681: iload #31
/*      */     //   683: lookupswitch default -> 7650, 1 -> 740, 2 -> 1429, 3 -> 2246, 4 -> 3262, 5 -> 4549, 6 -> 6363
/*      */     //   740: aload #34
/*      */     //   742: iconst_0
/*      */     //   743: iaload
/*      */     //   744: iconst_1
/*      */     //   745: if_icmpne -> 751
/*      */     //   748: goto -> 791
/*      */     //   751: new org/renjin/gcc/runtime/BytePtr
/*      */     //   754: dup
/*      */     //   755: ldc 'graphics '
/*      */     //   757: invokevirtual getBytes : ()[B
/*      */     //   760: iconst_0
/*      */     //   761: invokespecial <init> : ([BI)V
/*      */     //   764: new org/renjin/gcc/runtime/BytePtr
/*      */     //   767: dup
/*      */     //   768: ldc_w 'invalid circles data '
/*      */     //   771: invokevirtual getBytes : ()[B
/*      */     //   774: iconst_0
/*      */     //   775: invokespecial <init> : ([BI)V
/*      */     //   778: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   781: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   784: iconst_0
/*      */     //   785: anewarray java/lang/Object
/*      */     //   788: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   791: aload #35
/*      */     //   793: iconst_0
/*      */     //   794: iaload
/*      */     //   795: wide istore #913
/*      */     //   799: aload #40
/*      */     //   801: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   804: wide iload #913
/*      */     //   808: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   811: dup
/*      */     //   812: aload #30
/*      */     //   814: iconst_0
/*      */     //   815: invokespecial <init> : ([DI)V
/*      */     //   818: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   821: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   824: dup
/*      */     //   825: aload #29
/*      */     //   827: iconst_0
/*      */     //   828: invokespecial <init> : ([DI)V
/*      */     //   831: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   834: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   837: ifeq -> 843
/*      */     //   840: goto -> 883
/*      */     //   843: new org/renjin/gcc/runtime/BytePtr
/*      */     //   846: dup
/*      */     //   847: ldc 'graphics '
/*      */     //   849: invokevirtual getBytes : ()[B
/*      */     //   852: iconst_0
/*      */     //   853: invokespecial <init> : ([BI)V
/*      */     //   856: new org/renjin/gcc/runtime/BytePtr
/*      */     //   859: dup
/*      */     //   860: ldc_w 'invalid symbol parameter '
/*      */     //   863: invokevirtual getBytes : ()[B
/*      */     //   866: iconst_0
/*      */     //   867: invokespecial <init> : ([BI)V
/*      */     //   870: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   873: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   876: iconst_0
/*      */     //   877: anewarray java/lang/Object
/*      */     //   880: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   883: iconst_0
/*      */     //   884: istore #37
/*      */     //   886: goto -> 1406
/*      */     //   889: aload #42
/*      */     //   891: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   894: wide astore #906
/*      */     //   898: iload #37
/*      */     //   900: bipush #8
/*      */     //   902: imul
/*      */     //   903: wide istore #904
/*      */     //   907: wide aload #906
/*      */     //   911: wide astore #902
/*      */     //   915: iconst_0
/*      */     //   916: wide iload #904
/*      */     //   920: iadd
/*      */     //   921: wide istore #903
/*      */     //   925: wide aload #902
/*      */     //   929: wide iload #903
/*      */     //   933: invokeinterface getDouble : (I)D
/*      */     //   938: invokestatic R_finite : (D)I
/*      */     //   941: ifne -> 947
/*      */     //   944: goto -> 1403
/*      */     //   947: aload #41
/*      */     //   949: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   952: wide astore #897
/*      */     //   956: iload #37
/*      */     //   958: bipush #8
/*      */     //   960: imul
/*      */     //   961: wide istore #895
/*      */     //   965: wide aload #897
/*      */     //   969: wide astore #893
/*      */     //   973: iconst_0
/*      */     //   974: wide iload #895
/*      */     //   978: iadd
/*      */     //   979: wide istore #894
/*      */     //   983: wide aload #893
/*      */     //   987: wide iload #894
/*      */     //   991: invokeinterface getDouble : (I)D
/*      */     //   996: invokestatic R_finite : (D)I
/*      */     //   999: ifne -> 1005
/*      */     //   1002: goto -> 1403
/*      */     //   1005: aload #40
/*      */     //   1007: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1010: wide astore #888
/*      */     //   1014: iload #37
/*      */     //   1016: bipush #8
/*      */     //   1018: imul
/*      */     //   1019: wide istore #886
/*      */     //   1023: wide aload #888
/*      */     //   1027: wide astore #884
/*      */     //   1031: iconst_0
/*      */     //   1032: wide iload #886
/*      */     //   1036: iadd
/*      */     //   1037: wide istore #885
/*      */     //   1041: wide aload #884
/*      */     //   1045: wide iload #885
/*      */     //   1049: invokeinterface getDouble : (I)D
/*      */     //   1054: invokestatic R_finite : (D)I
/*      */     //   1057: ifne -> 1063
/*      */     //   1060: goto -> 1403
/*      */     //   1063: aload #40
/*      */     //   1065: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1068: wide astore #879
/*      */     //   1072: iload #37
/*      */     //   1074: bipush #8
/*      */     //   1076: imul
/*      */     //   1077: wide istore #877
/*      */     //   1081: wide aload #879
/*      */     //   1085: wide astore #875
/*      */     //   1089: iconst_0
/*      */     //   1090: wide iload #877
/*      */     //   1094: iadd
/*      */     //   1095: wide istore #876
/*      */     //   1099: wide aload #875
/*      */     //   1103: wide iload #876
/*      */     //   1107: invokeinterface getDouble : (I)D
/*      */     //   1112: dstore #25
/*      */     //   1114: dload #27
/*      */     //   1116: dconst_0
/*      */     //   1117: dcmpl
/*      */     //   1118: ifgt -> 1124
/*      */     //   1121: goto -> 1147
/*      */     //   1124: aload #30
/*      */     //   1126: iconst_0
/*      */     //   1127: daload
/*      */     //   1128: wide dstore #873
/*      */     //   1132: dload #27
/*      */     //   1134: wide dload #873
/*      */     //   1138: ddiv
/*      */     //   1139: dload #25
/*      */     //   1141: dmul
/*      */     //   1142: dstore #25
/*      */     //   1144: goto -> 1165
/*      */     //   1147: dload #25
/*      */     //   1149: bipush #12
/*      */     //   1151: bipush #13
/*      */     //   1153: aload_1
/*      */     //   1154: iload_2
/*      */     //   1155: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1160: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   1163: dstore #25
/*      */     //   1165: aload #39
/*      */     //   1167: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1170: wide astore #869
/*      */     //   1174: iload #37
/*      */     //   1176: iload #32
/*      */     //   1178: irem
/*      */     //   1179: iconst_4
/*      */     //   1180: imul
/*      */     //   1181: wide istore #866
/*      */     //   1185: wide aload #869
/*      */     //   1189: wide astore #864
/*      */     //   1193: iconst_0
/*      */     //   1194: wide iload #866
/*      */     //   1198: iadd
/*      */     //   1199: wide istore #865
/*      */     //   1203: wide aload #864
/*      */     //   1207: wide iload #865
/*      */     //   1211: invokeinterface getInt : (I)I
/*      */     //   1216: wide istore #863
/*      */     //   1220: aload #38
/*      */     //   1222: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1225: wide astore #861
/*      */     //   1229: iload #37
/*      */     //   1231: iload #33
/*      */     //   1233: irem
/*      */     //   1234: iconst_4
/*      */     //   1235: imul
/*      */     //   1236: wide istore #858
/*      */     //   1240: wide aload #861
/*      */     //   1244: wide astore #856
/*      */     //   1248: iconst_0
/*      */     //   1249: wide iload #858
/*      */     //   1253: iadd
/*      */     //   1254: wide istore #857
/*      */     //   1258: wide aload #856
/*      */     //   1262: wide iload #857
/*      */     //   1266: invokeinterface getInt : (I)I
/*      */     //   1271: wide istore #855
/*      */     //   1275: aload #41
/*      */     //   1277: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1280: wide astore #853
/*      */     //   1284: iload #37
/*      */     //   1286: bipush #8
/*      */     //   1288: imul
/*      */     //   1289: wide istore #851
/*      */     //   1293: wide aload #853
/*      */     //   1297: wide astore #849
/*      */     //   1301: iconst_0
/*      */     //   1302: wide iload #851
/*      */     //   1306: iadd
/*      */     //   1307: wide istore #850
/*      */     //   1311: wide aload #849
/*      */     //   1315: wide iload #850
/*      */     //   1319: invokeinterface getDouble : (I)D
/*      */     //   1324: wide dstore #847
/*      */     //   1328: aload #42
/*      */     //   1330: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1333: wide astore #845
/*      */     //   1337: iload #37
/*      */     //   1339: bipush #8
/*      */     //   1341: imul
/*      */     //   1342: wide istore #843
/*      */     //   1346: wide aload #845
/*      */     //   1350: wide astore #841
/*      */     //   1354: iconst_0
/*      */     //   1355: wide iload #843
/*      */     //   1359: iadd
/*      */     //   1360: wide istore #842
/*      */     //   1364: wide aload #841
/*      */     //   1368: wide iload #842
/*      */     //   1372: invokeinterface getDouble : (I)D
/*      */     //   1377: wide dload #847
/*      */     //   1381: bipush #12
/*      */     //   1383: dload #25
/*      */     //   1385: wide iload #855
/*      */     //   1389: wide iload #863
/*      */     //   1393: aload_1
/*      */     //   1394: iload_2
/*      */     //   1395: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1400: invokestatic Rf_GCircle : (DDIDIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1403: iinc #37, 1
/*      */     //   1406: aload #35
/*      */     //   1408: iconst_0
/*      */     //   1409: iaload
/*      */     //   1410: wide istore #838
/*      */     //   1414: iload #37
/*      */     //   1416: wide iload #838
/*      */     //   1420: if_icmplt -> 889
/*      */     //   1423: goto -> 1426
/*      */     //   1426: goto -> 7690
/*      */     //   1429: aload #34
/*      */     //   1431: iconst_0
/*      */     //   1432: iaload
/*      */     //   1433: iconst_1
/*      */     //   1434: if_icmpne -> 1440
/*      */     //   1437: goto -> 1480
/*      */     //   1440: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1443: dup
/*      */     //   1444: ldc 'graphics '
/*      */     //   1446: invokevirtual getBytes : ()[B
/*      */     //   1449: iconst_0
/*      */     //   1450: invokespecial <init> : ([BI)V
/*      */     //   1453: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1456: dup
/*      */     //   1457: ldc_w 'invalid squares data '
/*      */     //   1460: invokevirtual getBytes : ()[B
/*      */     //   1463: iconst_0
/*      */     //   1464: invokespecial <init> : ([BI)V
/*      */     //   1467: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1470: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1473: iconst_0
/*      */     //   1474: anewarray java/lang/Object
/*      */     //   1477: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1480: aload #35
/*      */     //   1482: iconst_0
/*      */     //   1483: iaload
/*      */     //   1484: wide istore #834
/*      */     //   1488: aload #40
/*      */     //   1490: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1493: wide iload #834
/*      */     //   1497: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1500: dup
/*      */     //   1501: aload #30
/*      */     //   1503: iconst_0
/*      */     //   1504: invokespecial <init> : ([DI)V
/*      */     //   1507: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1510: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1513: dup
/*      */     //   1514: aload #29
/*      */     //   1516: iconst_0
/*      */     //   1517: invokespecial <init> : ([DI)V
/*      */     //   1520: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1523: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1526: ifeq -> 1532
/*      */     //   1529: goto -> 1572
/*      */     //   1532: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1535: dup
/*      */     //   1536: ldc 'graphics '
/*      */     //   1538: invokevirtual getBytes : ()[B
/*      */     //   1541: iconst_0
/*      */     //   1542: invokespecial <init> : ([BI)V
/*      */     //   1545: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1548: dup
/*      */     //   1549: ldc_w 'invalid symbol parameter '
/*      */     //   1552: invokevirtual getBytes : ()[B
/*      */     //   1555: iconst_0
/*      */     //   1556: invokespecial <init> : ([BI)V
/*      */     //   1559: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1562: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1565: iconst_0
/*      */     //   1566: anewarray java/lang/Object
/*      */     //   1569: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1572: iconst_0
/*      */     //   1573: istore #37
/*      */     //   1575: goto -> 2223
/*      */     //   1578: aload #42
/*      */     //   1580: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1583: wide astore #827
/*      */     //   1587: iload #37
/*      */     //   1589: bipush #8
/*      */     //   1591: imul
/*      */     //   1592: wide istore #825
/*      */     //   1596: wide aload #827
/*      */     //   1600: wide astore #823
/*      */     //   1604: iconst_0
/*      */     //   1605: wide iload #825
/*      */     //   1609: iadd
/*      */     //   1610: wide istore #824
/*      */     //   1614: wide aload #823
/*      */     //   1618: wide iload #824
/*      */     //   1622: invokeinterface getDouble : (I)D
/*      */     //   1627: invokestatic R_finite : (D)I
/*      */     //   1630: ifne -> 1636
/*      */     //   1633: goto -> 2220
/*      */     //   1636: aload #41
/*      */     //   1638: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1641: wide astore #818
/*      */     //   1645: iload #37
/*      */     //   1647: bipush #8
/*      */     //   1649: imul
/*      */     //   1650: wide istore #816
/*      */     //   1654: wide aload #818
/*      */     //   1658: wide astore #814
/*      */     //   1662: iconst_0
/*      */     //   1663: wide iload #816
/*      */     //   1667: iadd
/*      */     //   1668: wide istore #815
/*      */     //   1672: wide aload #814
/*      */     //   1676: wide iload #815
/*      */     //   1680: invokeinterface getDouble : (I)D
/*      */     //   1685: invokestatic R_finite : (D)I
/*      */     //   1688: ifne -> 1694
/*      */     //   1691: goto -> 2220
/*      */     //   1694: aload #40
/*      */     //   1696: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1699: wide astore #809
/*      */     //   1703: iload #37
/*      */     //   1705: bipush #8
/*      */     //   1707: imul
/*      */     //   1708: wide istore #807
/*      */     //   1712: wide aload #809
/*      */     //   1716: wide astore #805
/*      */     //   1720: iconst_0
/*      */     //   1721: wide iload #807
/*      */     //   1725: iadd
/*      */     //   1726: wide istore #806
/*      */     //   1730: wide aload #805
/*      */     //   1734: wide iload #806
/*      */     //   1738: invokeinterface getDouble : (I)D
/*      */     //   1743: invokestatic R_finite : (D)I
/*      */     //   1746: ifne -> 1752
/*      */     //   1749: goto -> 2220
/*      */     //   1752: aload #40
/*      */     //   1754: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1757: wide astore #800
/*      */     //   1761: iload #37
/*      */     //   1763: bipush #8
/*      */     //   1765: imul
/*      */     //   1766: wide istore #798
/*      */     //   1770: wide aload #800
/*      */     //   1774: wide astore #796
/*      */     //   1778: iconst_0
/*      */     //   1779: wide iload #798
/*      */     //   1783: iadd
/*      */     //   1784: wide istore #797
/*      */     //   1788: wide aload #796
/*      */     //   1792: wide iload #797
/*      */     //   1796: invokeinterface getDouble : (I)D
/*      */     //   1801: dstore #19
/*      */     //   1803: aload #42
/*      */     //   1805: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1808: wide astore #794
/*      */     //   1812: iload #37
/*      */     //   1814: bipush #8
/*      */     //   1816: imul
/*      */     //   1817: wide istore #792
/*      */     //   1821: wide aload #794
/*      */     //   1825: wide astore #790
/*      */     //   1829: iconst_0
/*      */     //   1830: wide iload #792
/*      */     //   1834: iadd
/*      */     //   1835: wide istore #791
/*      */     //   1839: wide aload #790
/*      */     //   1843: wide iload #791
/*      */     //   1847: invokeinterface getDouble : (I)D
/*      */     //   1852: wide dstore #788
/*      */     //   1856: aload #22
/*      */     //   1858: iconst_0
/*      */     //   1859: wide dload #788
/*      */     //   1863: dastore
/*      */     //   1864: aload #41
/*      */     //   1866: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1869: wide astore #786
/*      */     //   1873: iload #37
/*      */     //   1875: bipush #8
/*      */     //   1877: imul
/*      */     //   1878: wide istore #784
/*      */     //   1882: wide aload #786
/*      */     //   1886: wide astore #782
/*      */     //   1890: iconst_0
/*      */     //   1891: wide iload #784
/*      */     //   1895: iadd
/*      */     //   1896: wide istore #783
/*      */     //   1900: wide aload #782
/*      */     //   1904: wide iload #783
/*      */     //   1908: invokeinterface getDouble : (I)D
/*      */     //   1913: wide dstore #780
/*      */     //   1917: aload #21
/*      */     //   1919: iconst_0
/*      */     //   1920: wide dload #780
/*      */     //   1924: dastore
/*      */     //   1925: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1928: dup
/*      */     //   1929: aload #22
/*      */     //   1931: iconst_0
/*      */     //   1932: invokespecial <init> : ([DI)V
/*      */     //   1935: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1938: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1941: dup
/*      */     //   1942: aload #21
/*      */     //   1944: iconst_0
/*      */     //   1945: invokespecial <init> : ([DI)V
/*      */     //   1948: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1951: bipush #12
/*      */     //   1953: iconst_0
/*      */     //   1954: aload_1
/*      */     //   1955: iload_2
/*      */     //   1956: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1961: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1964: dload #27
/*      */     //   1966: dconst_0
/*      */     //   1967: dcmpl
/*      */     //   1968: ifgt -> 1974
/*      */     //   1971: goto -> 2018
/*      */     //   1974: aload #30
/*      */     //   1976: iconst_0
/*      */     //   1977: daload
/*      */     //   1978: wide dstore #778
/*      */     //   1982: dload #27
/*      */     //   1984: wide dload #778
/*      */     //   1988: ddiv
/*      */     //   1989: dload #19
/*      */     //   1991: dmul
/*      */     //   1992: dstore #19
/*      */     //   1994: dload #19
/*      */     //   1996: ldc2_w 0.5
/*      */     //   1999: dmul
/*      */     //   2000: bipush #13
/*      */     //   2002: iconst_0
/*      */     //   2003: aload_1
/*      */     //   2004: iload_2
/*      */     //   2005: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2010: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   2013: dstore #25
/*      */     //   2015: goto -> 2039
/*      */     //   2018: dload #19
/*      */     //   2020: ldc2_w 0.5
/*      */     //   2023: dmul
/*      */     //   2024: bipush #12
/*      */     //   2026: iconst_0
/*      */     //   2027: aload_1
/*      */     //   2028: iload_2
/*      */     //   2029: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2034: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   2037: dstore #25
/*      */     //   2039: aload #39
/*      */     //   2041: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2044: wide astore #770
/*      */     //   2048: iload #37
/*      */     //   2050: iload #32
/*      */     //   2052: irem
/*      */     //   2053: iconst_4
/*      */     //   2054: imul
/*      */     //   2055: wide istore #767
/*      */     //   2059: wide aload #770
/*      */     //   2063: wide astore #765
/*      */     //   2067: iconst_0
/*      */     //   2068: wide iload #767
/*      */     //   2072: iadd
/*      */     //   2073: wide istore #766
/*      */     //   2077: wide aload #765
/*      */     //   2081: wide iload #766
/*      */     //   2085: invokeinterface getInt : (I)I
/*      */     //   2090: wide istore #764
/*      */     //   2094: aload #38
/*      */     //   2096: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2099: wide astore #762
/*      */     //   2103: iload #37
/*      */     //   2105: iload #33
/*      */     //   2107: irem
/*      */     //   2108: iconst_4
/*      */     //   2109: imul
/*      */     //   2110: wide istore #759
/*      */     //   2114: wide aload #762
/*      */     //   2118: wide astore #757
/*      */     //   2122: iconst_0
/*      */     //   2123: wide iload #759
/*      */     //   2127: iadd
/*      */     //   2128: wide istore #758
/*      */     //   2132: wide aload #757
/*      */     //   2136: wide iload #758
/*      */     //   2140: invokeinterface getInt : (I)I
/*      */     //   2145: wide istore #756
/*      */     //   2149: aload #21
/*      */     //   2151: iconst_0
/*      */     //   2152: daload
/*      */     //   2153: dload #25
/*      */     //   2155: dadd
/*      */     //   2156: wide dstore #752
/*      */     //   2160: aload #22
/*      */     //   2162: iconst_0
/*      */     //   2163: daload
/*      */     //   2164: dload #25
/*      */     //   2166: dadd
/*      */     //   2167: wide dstore #748
/*      */     //   2171: aload #21
/*      */     //   2173: iconst_0
/*      */     //   2174: daload
/*      */     //   2175: dload #25
/*      */     //   2177: dsub
/*      */     //   2178: wide dstore #744
/*      */     //   2182: aload #22
/*      */     //   2184: iconst_0
/*      */     //   2185: daload
/*      */     //   2186: dload #25
/*      */     //   2188: dsub
/*      */     //   2189: wide dload #744
/*      */     //   2193: wide dload #748
/*      */     //   2197: wide dload #752
/*      */     //   2201: iconst_0
/*      */     //   2202: wide iload #756
/*      */     //   2206: wide iload #764
/*      */     //   2210: aload_1
/*      */     //   2211: iload_2
/*      */     //   2212: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2217: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2220: iinc #37, 1
/*      */     //   2223: aload #35
/*      */     //   2225: iconst_0
/*      */     //   2226: iaload
/*      */     //   2227: wide istore #739
/*      */     //   2231: iload #37
/*      */     //   2233: wide iload #739
/*      */     //   2237: if_icmplt -> 1578
/*      */     //   2240: goto -> 2243
/*      */     //   2243: goto -> 7690
/*      */     //   2246: aload #34
/*      */     //   2248: iconst_0
/*      */     //   2249: iaload
/*      */     //   2250: iconst_2
/*      */     //   2251: if_icmpne -> 2257
/*      */     //   2254: goto -> 2297
/*      */     //   2257: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2260: dup
/*      */     //   2261: ldc 'graphics '
/*      */     //   2263: invokevirtual getBytes : ()[B
/*      */     //   2266: iconst_0
/*      */     //   2267: invokespecial <init> : ([BI)V
/*      */     //   2270: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2273: dup
/*      */     //   2274: ldc_w 'invalid rectangles data (need 2 columns) '
/*      */     //   2277: invokevirtual getBytes : ()[B
/*      */     //   2280: iconst_0
/*      */     //   2281: invokespecial <init> : ([BI)V
/*      */     //   2284: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2287: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2290: iconst_0
/*      */     //   2291: anewarray java/lang/Object
/*      */     //   2294: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2297: aload #35
/*      */     //   2299: iconst_0
/*      */     //   2300: iaload
/*      */     //   2301: iconst_2
/*      */     //   2302: imul
/*      */     //   2303: wide istore #734
/*      */     //   2307: aload #40
/*      */     //   2309: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2312: wide iload #734
/*      */     //   2316: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2319: dup
/*      */     //   2320: aload #30
/*      */     //   2322: iconst_0
/*      */     //   2323: invokespecial <init> : ([DI)V
/*      */     //   2326: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2329: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2332: dup
/*      */     //   2333: aload #29
/*      */     //   2335: iconst_0
/*      */     //   2336: invokespecial <init> : ([DI)V
/*      */     //   2339: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2342: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2345: ifeq -> 2351
/*      */     //   2348: goto -> 2391
/*      */     //   2351: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2354: dup
/*      */     //   2355: ldc 'graphics '
/*      */     //   2357: invokevirtual getBytes : ()[B
/*      */     //   2360: iconst_0
/*      */     //   2361: invokespecial <init> : ([BI)V
/*      */     //   2364: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2367: dup
/*      */     //   2368: ldc_w 'invalid symbol parameter '
/*      */     //   2371: invokevirtual getBytes : ()[B
/*      */     //   2374: iconst_0
/*      */     //   2375: invokespecial <init> : ([BI)V
/*      */     //   2378: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2381: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2384: iconst_0
/*      */     //   2385: anewarray java/lang/Object
/*      */     //   2388: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2391: iconst_0
/*      */     //   2392: istore #37
/*      */     //   2394: goto -> 3239
/*      */     //   2397: aload #42
/*      */     //   2399: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2402: wide astore #727
/*      */     //   2406: iload #37
/*      */     //   2408: bipush #8
/*      */     //   2410: imul
/*      */     //   2411: wide istore #725
/*      */     //   2415: wide aload #727
/*      */     //   2419: wide astore #723
/*      */     //   2423: iconst_0
/*      */     //   2424: wide iload #725
/*      */     //   2428: iadd
/*      */     //   2429: wide istore #724
/*      */     //   2433: wide aload #723
/*      */     //   2437: wide iload #724
/*      */     //   2441: invokeinterface getDouble : (I)D
/*      */     //   2446: invokestatic R_finite : (D)I
/*      */     //   2449: ifne -> 2455
/*      */     //   2452: goto -> 3236
/*      */     //   2455: aload #41
/*      */     //   2457: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2460: wide astore #718
/*      */     //   2464: iload #37
/*      */     //   2466: bipush #8
/*      */     //   2468: imul
/*      */     //   2469: wide istore #716
/*      */     //   2473: wide aload #718
/*      */     //   2477: wide astore #714
/*      */     //   2481: iconst_0
/*      */     //   2482: wide iload #716
/*      */     //   2486: iadd
/*      */     //   2487: wide istore #715
/*      */     //   2491: wide aload #714
/*      */     //   2495: wide iload #715
/*      */     //   2499: invokeinterface getDouble : (I)D
/*      */     //   2504: invokestatic R_finite : (D)I
/*      */     //   2507: ifne -> 2513
/*      */     //   2510: goto -> 3236
/*      */     //   2513: aload #40
/*      */     //   2515: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2518: wide astore #709
/*      */     //   2522: iload #37
/*      */     //   2524: bipush #8
/*      */     //   2526: imul
/*      */     //   2527: wide istore #707
/*      */     //   2531: wide aload #709
/*      */     //   2535: wide astore #705
/*      */     //   2539: iconst_0
/*      */     //   2540: wide iload #707
/*      */     //   2544: iadd
/*      */     //   2545: wide istore #706
/*      */     //   2549: wide aload #705
/*      */     //   2553: wide iload #706
/*      */     //   2557: invokeinterface getDouble : (I)D
/*      */     //   2562: invokestatic R_finite : (D)I
/*      */     //   2565: ifne -> 2571
/*      */     //   2568: goto -> 3236
/*      */     //   2571: aload #40
/*      */     //   2573: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2576: wide astore #700
/*      */     //   2580: aload #35
/*      */     //   2582: iconst_0
/*      */     //   2583: iaload
/*      */     //   2584: wide istore #699
/*      */     //   2588: iload #37
/*      */     //   2590: wide iload #699
/*      */     //   2594: iadd
/*      */     //   2595: bipush #8
/*      */     //   2597: imul
/*      */     //   2598: wide istore #696
/*      */     //   2602: wide aload #700
/*      */     //   2606: wide astore #694
/*      */     //   2610: iconst_0
/*      */     //   2611: wide iload #696
/*      */     //   2615: iadd
/*      */     //   2616: wide istore #695
/*      */     //   2620: wide aload #694
/*      */     //   2624: wide iload #695
/*      */     //   2628: invokeinterface getDouble : (I)D
/*      */     //   2633: invokestatic R_finite : (D)I
/*      */     //   2636: ifne -> 2642
/*      */     //   2639: goto -> 3236
/*      */     //   2642: aload #42
/*      */     //   2644: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2647: wide astore #689
/*      */     //   2651: iload #37
/*      */     //   2653: bipush #8
/*      */     //   2655: imul
/*      */     //   2656: wide istore #687
/*      */     //   2660: wide aload #689
/*      */     //   2664: wide astore #685
/*      */     //   2668: iconst_0
/*      */     //   2669: wide iload #687
/*      */     //   2673: iadd
/*      */     //   2674: wide istore #686
/*      */     //   2678: wide aload #685
/*      */     //   2682: wide iload #686
/*      */     //   2686: invokeinterface getDouble : (I)D
/*      */     //   2691: wide dstore #683
/*      */     //   2695: aload #22
/*      */     //   2697: iconst_0
/*      */     //   2698: wide dload #683
/*      */     //   2702: dastore
/*      */     //   2703: aload #41
/*      */     //   2705: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2708: wide astore #681
/*      */     //   2712: iload #37
/*      */     //   2714: bipush #8
/*      */     //   2716: imul
/*      */     //   2717: wide istore #679
/*      */     //   2721: wide aload #681
/*      */     //   2725: wide astore #677
/*      */     //   2729: iconst_0
/*      */     //   2730: wide iload #679
/*      */     //   2734: iadd
/*      */     //   2735: wide istore #678
/*      */     //   2739: wide aload #677
/*      */     //   2743: wide iload #678
/*      */     //   2747: invokeinterface getDouble : (I)D
/*      */     //   2752: wide dstore #675
/*      */     //   2756: aload #21
/*      */     //   2758: iconst_0
/*      */     //   2759: wide dload #675
/*      */     //   2763: dastore
/*      */     //   2764: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2767: dup
/*      */     //   2768: aload #22
/*      */     //   2770: iconst_0
/*      */     //   2771: invokespecial <init> : ([DI)V
/*      */     //   2774: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2777: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2780: dup
/*      */     //   2781: aload #21
/*      */     //   2783: iconst_0
/*      */     //   2784: invokespecial <init> : ([DI)V
/*      */     //   2787: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2790: bipush #12
/*      */     //   2792: iconst_0
/*      */     //   2793: aload_1
/*      */     //   2794: iload_2
/*      */     //   2795: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2800: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2803: aload #40
/*      */     //   2805: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2808: wide astore #673
/*      */     //   2812: iload #37
/*      */     //   2814: bipush #8
/*      */     //   2816: imul
/*      */     //   2817: wide istore #671
/*      */     //   2821: wide aload #673
/*      */     //   2825: wide astore #669
/*      */     //   2829: iconst_0
/*      */     //   2830: wide iload #671
/*      */     //   2834: iadd
/*      */     //   2835: wide istore #670
/*      */     //   2839: wide aload #669
/*      */     //   2843: wide iload #670
/*      */     //   2847: invokeinterface getDouble : (I)D
/*      */     //   2852: dstore #19
/*      */     //   2854: aload #40
/*      */     //   2856: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2859: wide astore #667
/*      */     //   2863: aload #35
/*      */     //   2865: iconst_0
/*      */     //   2866: iaload
/*      */     //   2867: wide istore #666
/*      */     //   2871: iload #37
/*      */     //   2873: wide iload #666
/*      */     //   2877: iadd
/*      */     //   2878: bipush #8
/*      */     //   2880: imul
/*      */     //   2881: wide istore #663
/*      */     //   2885: wide aload #667
/*      */     //   2889: wide astore #661
/*      */     //   2893: iconst_0
/*      */     //   2894: wide iload #663
/*      */     //   2898: iadd
/*      */     //   2899: wide istore #662
/*      */     //   2903: wide aload #661
/*      */     //   2907: wide iload #662
/*      */     //   2911: invokeinterface getDouble : (I)D
/*      */     //   2916: dstore #17
/*      */     //   2918: dload #27
/*      */     //   2920: dconst_0
/*      */     //   2921: dcmpl
/*      */     //   2922: ifgt -> 2928
/*      */     //   2925: goto -> 3013
/*      */     //   2928: aload #30
/*      */     //   2930: iconst_0
/*      */     //   2931: daload
/*      */     //   2932: wide dstore #659
/*      */     //   2936: dload #27
/*      */     //   2938: wide dload #659
/*      */     //   2942: ddiv
/*      */     //   2943: dload #19
/*      */     //   2945: dmul
/*      */     //   2946: dstore #19
/*      */     //   2948: aload #30
/*      */     //   2950: iconst_0
/*      */     //   2951: daload
/*      */     //   2952: wide dstore #655
/*      */     //   2956: dload #27
/*      */     //   2958: wide dload #655
/*      */     //   2962: ddiv
/*      */     //   2963: dload #17
/*      */     //   2965: dmul
/*      */     //   2966: dstore #17
/*      */     //   2968: dload #19
/*      */     //   2970: ldc2_w 0.5
/*      */     //   2973: dmul
/*      */     //   2974: bipush #13
/*      */     //   2976: iconst_0
/*      */     //   2977: aload_1
/*      */     //   2978: iload_2
/*      */     //   2979: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2984: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   2987: dstore #25
/*      */     //   2989: dload #17
/*      */     //   2991: ldc2_w 0.5
/*      */     //   2994: dmul
/*      */     //   2995: bipush #13
/*      */     //   2997: iconst_0
/*      */     //   2998: aload_1
/*      */     //   2999: iload_2
/*      */     //   3000: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3005: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3008: dstore #23
/*      */     //   3010: goto -> 3055
/*      */     //   3013: dload #19
/*      */     //   3015: ldc2_w 0.5
/*      */     //   3018: dmul
/*      */     //   3019: bipush #12
/*      */     //   3021: iconst_0
/*      */     //   3022: aload_1
/*      */     //   3023: iload_2
/*      */     //   3024: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3029: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3032: dstore #25
/*      */     //   3034: dload #17
/*      */     //   3036: ldc2_w 0.5
/*      */     //   3039: dmul
/*      */     //   3040: bipush #12
/*      */     //   3042: iconst_0
/*      */     //   3043: aload_1
/*      */     //   3044: iload_2
/*      */     //   3045: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3050: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   3053: dstore #23
/*      */     //   3055: aload #39
/*      */     //   3057: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3060: wide astore #643
/*      */     //   3064: iload #37
/*      */     //   3066: iload #32
/*      */     //   3068: irem
/*      */     //   3069: iconst_4
/*      */     //   3070: imul
/*      */     //   3071: wide istore #640
/*      */     //   3075: wide aload #643
/*      */     //   3079: wide astore #638
/*      */     //   3083: iconst_0
/*      */     //   3084: wide iload #640
/*      */     //   3088: iadd
/*      */     //   3089: wide istore #639
/*      */     //   3093: wide aload #638
/*      */     //   3097: wide iload #639
/*      */     //   3101: invokeinterface getInt : (I)I
/*      */     //   3106: wide istore #637
/*      */     //   3110: aload #38
/*      */     //   3112: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3115: wide astore #635
/*      */     //   3119: iload #37
/*      */     //   3121: iload #33
/*      */     //   3123: irem
/*      */     //   3124: iconst_4
/*      */     //   3125: imul
/*      */     //   3126: wide istore #632
/*      */     //   3130: wide aload #635
/*      */     //   3134: wide astore #630
/*      */     //   3138: iconst_0
/*      */     //   3139: wide iload #632
/*      */     //   3143: iadd
/*      */     //   3144: wide istore #631
/*      */     //   3148: wide aload #630
/*      */     //   3152: wide iload #631
/*      */     //   3156: invokeinterface getInt : (I)I
/*      */     //   3161: wide istore #629
/*      */     //   3165: aload #21
/*      */     //   3167: iconst_0
/*      */     //   3168: daload
/*      */     //   3169: dload #23
/*      */     //   3171: dadd
/*      */     //   3172: wide dstore #625
/*      */     //   3176: aload #22
/*      */     //   3178: iconst_0
/*      */     //   3179: daload
/*      */     //   3180: dload #25
/*      */     //   3182: dadd
/*      */     //   3183: wide dstore #621
/*      */     //   3187: aload #21
/*      */     //   3189: iconst_0
/*      */     //   3190: daload
/*      */     //   3191: dload #23
/*      */     //   3193: dsub
/*      */     //   3194: wide dstore #617
/*      */     //   3198: aload #22
/*      */     //   3200: iconst_0
/*      */     //   3201: daload
/*      */     //   3202: dload #25
/*      */     //   3204: dsub
/*      */     //   3205: wide dload #617
/*      */     //   3209: wide dload #621
/*      */     //   3213: wide dload #625
/*      */     //   3217: iconst_0
/*      */     //   3218: wide iload #629
/*      */     //   3222: wide iload #637
/*      */     //   3226: aload_1
/*      */     //   3227: iload_2
/*      */     //   3228: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3233: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3236: iinc #37, 1
/*      */     //   3239: aload #35
/*      */     //   3241: iconst_0
/*      */     //   3242: iaload
/*      */     //   3243: wide istore #612
/*      */     //   3247: iload #37
/*      */     //   3249: wide iload #612
/*      */     //   3253: if_icmplt -> 2397
/*      */     //   3256: goto -> 3259
/*      */     //   3259: goto -> 7690
/*      */     //   3262: aload #34
/*      */     //   3264: iconst_0
/*      */     //   3265: iaload
/*      */     //   3266: iconst_2
/*      */     //   3267: if_icmple -> 3273
/*      */     //   3270: goto -> 3313
/*      */     //   3273: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3276: dup
/*      */     //   3277: ldc 'graphics '
/*      */     //   3279: invokevirtual getBytes : ()[B
/*      */     //   3282: iconst_0
/*      */     //   3283: invokespecial <init> : ([BI)V
/*      */     //   3286: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3289: dup
/*      */     //   3290: ldc_w 'invalid stars data '
/*      */     //   3293: invokevirtual getBytes : ()[B
/*      */     //   3296: iconst_0
/*      */     //   3297: invokespecial <init> : ([BI)V
/*      */     //   3300: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   3303: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   3306: iconst_0
/*      */     //   3307: anewarray java/lang/Object
/*      */     //   3310: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   3313: aload #34
/*      */     //   3315: iconst_0
/*      */     //   3316: iaload
/*      */     //   3317: wide istore #608
/*      */     //   3321: aload #35
/*      */     //   3323: iconst_0
/*      */     //   3324: iaload
/*      */     //   3325: wide istore #607
/*      */     //   3329: wide iload #608
/*      */     //   3333: wide iload #607
/*      */     //   3337: imul
/*      */     //   3338: wide istore #606
/*      */     //   3342: aload #40
/*      */     //   3344: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3347: wide iload #606
/*      */     //   3351: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3354: dup
/*      */     //   3355: aload #30
/*      */     //   3357: iconst_0
/*      */     //   3358: invokespecial <init> : ([DI)V
/*      */     //   3361: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3364: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3367: dup
/*      */     //   3368: aload #29
/*      */     //   3370: iconst_0
/*      */     //   3371: invokespecial <init> : ([DI)V
/*      */     //   3374: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3377: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3380: ifeq -> 3386
/*      */     //   3383: goto -> 3426
/*      */     //   3386: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3389: dup
/*      */     //   3390: ldc 'graphics '
/*      */     //   3392: invokevirtual getBytes : ()[B
/*      */     //   3395: iconst_0
/*      */     //   3396: invokespecial <init> : ([BI)V
/*      */     //   3399: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3402: dup
/*      */     //   3403: ldc_w 'invalid symbol parameter '
/*      */     //   3406: invokevirtual getBytes : ()[B
/*      */     //   3409: iconst_0
/*      */     //   3410: invokespecial <init> : ([BI)V
/*      */     //   3413: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   3416: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   3419: iconst_0
/*      */     //   3420: anewarray java/lang/Object
/*      */     //   3423: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   3426: invokestatic vmaxget : ()Ljava/lang/Object;
/*      */     //   3429: invokestatic toPtr : (Ljava/lang/Object;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3432: astore_3
/*      */     //   3433: iconst_0
/*      */     //   3434: istore #4
/*      */     //   3436: aload #34
/*      */     //   3438: iconst_0
/*      */     //   3439: iaload
/*      */     //   3440: bipush #8
/*      */     //   3442: imul
/*      */     //   3443: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3446: astore #9
/*      */     //   3448: iconst_0
/*      */     //   3449: istore #10
/*      */     //   3451: aload #34
/*      */     //   3453: iconst_0
/*      */     //   3454: iaload
/*      */     //   3455: bipush #8
/*      */     //   3457: imul
/*      */     //   3458: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3461: astore #7
/*      */     //   3463: iconst_0
/*      */     //   3464: istore #8
/*      */     //   3466: aload #34
/*      */     //   3468: iconst_0
/*      */     //   3469: iaload
/*      */     //   3470: bipush #8
/*      */     //   3472: imul
/*      */     //   3473: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/DoublePtr;
/*      */     //   3476: astore #5
/*      */     //   3478: iconst_0
/*      */     //   3479: istore #6
/*      */     //   3481: aload #34
/*      */     //   3483: iconst_0
/*      */     //   3484: iaload
/*      */     //   3485: i2d
/*      */     //   3486: wide dstore #589
/*      */     //   3490: ldc2_w 6.283185307179586
/*      */     //   3493: wide dload #589
/*      */     //   3497: ddiv
/*      */     //   3498: dstore #17
/*      */     //   3500: iconst_0
/*      */     //   3501: istore #37
/*      */     //   3503: goto -> 4526
/*      */     //   3506: aload #42
/*      */     //   3508: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3511: wide astore #587
/*      */     //   3515: iload #37
/*      */     //   3517: bipush #8
/*      */     //   3519: imul
/*      */     //   3520: wide istore #585
/*      */     //   3524: wide aload #587
/*      */     //   3528: wide astore #583
/*      */     //   3532: iconst_0
/*      */     //   3533: wide iload #585
/*      */     //   3537: iadd
/*      */     //   3538: wide istore #584
/*      */     //   3542: wide aload #583
/*      */     //   3546: wide iload #584
/*      */     //   3550: invokeinterface getDouble : (I)D
/*      */     //   3555: wide dstore #581
/*      */     //   3559: aload #22
/*      */     //   3561: iconst_0
/*      */     //   3562: wide dload #581
/*      */     //   3566: dastore
/*      */     //   3567: aload #41
/*      */     //   3569: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3572: wide astore #579
/*      */     //   3576: iload #37
/*      */     //   3578: bipush #8
/*      */     //   3580: imul
/*      */     //   3581: wide istore #577
/*      */     //   3585: wide aload #579
/*      */     //   3589: wide astore #575
/*      */     //   3593: iconst_0
/*      */     //   3594: wide iload #577
/*      */     //   3598: iadd
/*      */     //   3599: wide istore #576
/*      */     //   3603: wide aload #575
/*      */     //   3607: wide iload #576
/*      */     //   3611: invokeinterface getDouble : (I)D
/*      */     //   3616: wide dstore #573
/*      */     //   3620: aload #21
/*      */     //   3622: iconst_0
/*      */     //   3623: wide dload #573
/*      */     //   3627: dastore
/*      */     //   3628: aload #22
/*      */     //   3630: iconst_0
/*      */     //   3631: daload
/*      */     //   3632: invokestatic R_finite : (D)I
/*      */     //   3635: ifne -> 3641
/*      */     //   3638: goto -> 4523
/*      */     //   3641: aload #21
/*      */     //   3643: iconst_0
/*      */     //   3644: daload
/*      */     //   3645: invokestatic R_finite : (D)I
/*      */     //   3648: ifne -> 3654
/*      */     //   3651: goto -> 4523
/*      */     //   3654: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3657: dup
/*      */     //   3658: aload #22
/*      */     //   3660: iconst_0
/*      */     //   3661: invokespecial <init> : ([DI)V
/*      */     //   3664: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3667: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   3670: dup
/*      */     //   3671: aload #21
/*      */     //   3673: iconst_0
/*      */     //   3674: invokespecial <init> : ([DI)V
/*      */     //   3677: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3680: bipush #12
/*      */     //   3682: iconst_1
/*      */     //   3683: aload_1
/*      */     //   3684: iload_2
/*      */     //   3685: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3690: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3693: dload #27
/*      */     //   3695: dconst_0
/*      */     //   3696: dcmpl
/*      */     //   3697: ifgt -> 3703
/*      */     //   3700: goto -> 3878
/*      */     //   3703: iconst_0
/*      */     //   3704: istore #36
/*      */     //   3706: goto -> 3858
/*      */     //   3709: aload #40
/*      */     //   3711: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3714: wide astore #565
/*      */     //   3718: aload #35
/*      */     //   3720: iconst_0
/*      */     //   3721: iaload
/*      */     //   3722: wide istore #564
/*      */     //   3726: iload #36
/*      */     //   3728: wide iload #564
/*      */     //   3732: imul
/*      */     //   3733: iload #37
/*      */     //   3735: iadd
/*      */     //   3736: bipush #8
/*      */     //   3738: imul
/*      */     //   3739: wide istore #560
/*      */     //   3743: wide aload #565
/*      */     //   3747: wide astore #558
/*      */     //   3751: iconst_0
/*      */     //   3752: wide iload #560
/*      */     //   3756: iadd
/*      */     //   3757: wide istore #559
/*      */     //   3761: wide aload #558
/*      */     //   3765: wide iload #559
/*      */     //   3769: invokeinterface getDouble : (I)D
/*      */     //   3774: dstore #19
/*      */     //   3776: dload #19
/*      */     //   3778: invokestatic R_finite : (D)I
/*      */     //   3781: ifeq -> 3787
/*      */     //   3784: goto -> 3790
/*      */     //   3787: dconst_0
/*      */     //   3788: dstore #19
/*      */     //   3790: iload #36
/*      */     //   3792: bipush #8
/*      */     //   3794: imul
/*      */     //   3795: wide istore #555
/*      */     //   3799: aload #9
/*      */     //   3801: wide astore #553
/*      */     //   3805: iload #10
/*      */     //   3807: wide iload #555
/*      */     //   3811: iadd
/*      */     //   3812: wide istore #554
/*      */     //   3816: aload #30
/*      */     //   3818: iconst_0
/*      */     //   3819: daload
/*      */     //   3820: wide dstore #551
/*      */     //   3824: dload #19
/*      */     //   3826: wide dload #551
/*      */     //   3830: ddiv
/*      */     //   3831: dload #27
/*      */     //   3833: dmul
/*      */     //   3834: wide dstore #547
/*      */     //   3838: wide aload #553
/*      */     //   3842: wide iload #554
/*      */     //   3846: wide dload #547
/*      */     //   3850: invokeinterface setDouble : (ID)V
/*      */     //   3855: iinc #36, 1
/*      */     //   3858: aload #34
/*      */     //   3860: iconst_0
/*      */     //   3861: iaload
/*      */     //   3862: wide istore #546
/*      */     //   3866: iload #36
/*      */     //   3868: wide iload #546
/*      */     //   3872: if_icmplt -> 3709
/*      */     //   3875: goto -> 4051
/*      */     //   3878: iconst_0
/*      */     //   3879: istore #36
/*      */     //   3881: goto -> 4031
/*      */     //   3884: aload #40
/*      */     //   3886: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3889: wide astore #544
/*      */     //   3893: aload #35
/*      */     //   3895: iconst_0
/*      */     //   3896: iaload
/*      */     //   3897: wide istore #543
/*      */     //   3901: iload #36
/*      */     //   3903: wide iload #543
/*      */     //   3907: imul
/*      */     //   3908: iload #37
/*      */     //   3910: iadd
/*      */     //   3911: bipush #8
/*      */     //   3913: imul
/*      */     //   3914: wide istore #539
/*      */     //   3918: wide aload #544
/*      */     //   3922: wide astore #537
/*      */     //   3926: iconst_0
/*      */     //   3927: wide iload #539
/*      */     //   3931: iadd
/*      */     //   3932: wide istore #538
/*      */     //   3936: wide aload #537
/*      */     //   3940: wide iload #538
/*      */     //   3944: invokeinterface getDouble : (I)D
/*      */     //   3949: dstore #19
/*      */     //   3951: dload #19
/*      */     //   3953: invokestatic R_finite : (D)I
/*      */     //   3956: ifeq -> 3962
/*      */     //   3959: goto -> 3965
/*      */     //   3962: dconst_0
/*      */     //   3963: dstore #19
/*      */     //   3965: iload #36
/*      */     //   3967: bipush #8
/*      */     //   3969: imul
/*      */     //   3970: wide istore #534
/*      */     //   3974: aload #9
/*      */     //   3976: wide astore #532
/*      */     //   3980: iload #10
/*      */     //   3982: wide iload #534
/*      */     //   3986: iadd
/*      */     //   3987: wide istore #533
/*      */     //   3991: dload #19
/*      */     //   3993: bipush #12
/*      */     //   3995: bipush #13
/*      */     //   3997: aload_1
/*      */     //   3998: iload_2
/*      */     //   3999: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4004: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4007: wide dstore #530
/*      */     //   4011: wide aload #532
/*      */     //   4015: wide iload #533
/*      */     //   4019: wide dload #530
/*      */     //   4023: invokeinterface setDouble : (ID)V
/*      */     //   4028: iinc #36, 1
/*      */     //   4031: aload #34
/*      */     //   4033: iconst_0
/*      */     //   4034: iaload
/*      */     //   4035: wide istore #529
/*      */     //   4039: iload #36
/*      */     //   4041: wide iload #529
/*      */     //   4045: if_icmplt -> 3884
/*      */     //   4048: goto -> 4051
/*      */     //   4051: iconst_0
/*      */     //   4052: istore #36
/*      */     //   4054: goto -> 4352
/*      */     //   4057: iload #36
/*      */     //   4059: bipush #8
/*      */     //   4061: imul
/*      */     //   4062: wide istore #527
/*      */     //   4066: aload #7
/*      */     //   4068: wide astore #525
/*      */     //   4072: iload #8
/*      */     //   4074: wide iload #527
/*      */     //   4078: iadd
/*      */     //   4079: wide istore #526
/*      */     //   4083: iload #36
/*      */     //   4085: bipush #8
/*      */     //   4087: imul
/*      */     //   4088: wide istore #523
/*      */     //   4092: aload #9
/*      */     //   4094: wide astore #521
/*      */     //   4098: iload #10
/*      */     //   4100: wide iload #523
/*      */     //   4104: iadd
/*      */     //   4105: wide istore #522
/*      */     //   4109: wide aload #521
/*      */     //   4113: wide iload #522
/*      */     //   4117: invokeinterface getDouble : (I)D
/*      */     //   4122: wide dstore #519
/*      */     //   4126: iload #36
/*      */     //   4128: i2d
/*      */     //   4129: dload #17
/*      */     //   4131: dmul
/*      */     //   4132: invokestatic cos : (D)D
/*      */     //   4135: wide dstore #513
/*      */     //   4139: wide dload #519
/*      */     //   4143: wide dload #513
/*      */     //   4147: dmul
/*      */     //   4148: bipush #13
/*      */     //   4150: iconst_1
/*      */     //   4151: aload_1
/*      */     //   4152: iload_2
/*      */     //   4153: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4158: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4161: wide dstore #509
/*      */     //   4165: aload #22
/*      */     //   4167: iconst_0
/*      */     //   4168: daload
/*      */     //   4169: wide dstore #507
/*      */     //   4173: wide dload #509
/*      */     //   4177: wide dload #507
/*      */     //   4181: dadd
/*      */     //   4182: wide dstore #505
/*      */     //   4186: wide aload #525
/*      */     //   4190: wide iload #526
/*      */     //   4194: wide dload #505
/*      */     //   4198: invokeinterface setDouble : (ID)V
/*      */     //   4203: iload #36
/*      */     //   4205: bipush #8
/*      */     //   4207: imul
/*      */     //   4208: wide istore #503
/*      */     //   4212: aload #5
/*      */     //   4214: wide astore #501
/*      */     //   4218: iload #6
/*      */     //   4220: wide iload #503
/*      */     //   4224: iadd
/*      */     //   4225: wide istore #502
/*      */     //   4229: iload #36
/*      */     //   4231: bipush #8
/*      */     //   4233: imul
/*      */     //   4234: wide istore #499
/*      */     //   4238: aload #9
/*      */     //   4240: wide astore #497
/*      */     //   4244: iload #10
/*      */     //   4246: wide iload #499
/*      */     //   4250: iadd
/*      */     //   4251: wide istore #498
/*      */     //   4255: wide aload #497
/*      */     //   4259: wide iload #498
/*      */     //   4263: invokeinterface getDouble : (I)D
/*      */     //   4268: wide dstore #495
/*      */     //   4272: iload #36
/*      */     //   4274: i2d
/*      */     //   4275: dload #17
/*      */     //   4277: dmul
/*      */     //   4278: invokestatic sin : (D)D
/*      */     //   4281: wide dstore #489
/*      */     //   4285: wide dload #495
/*      */     //   4289: wide dload #489
/*      */     //   4293: dmul
/*      */     //   4294: bipush #13
/*      */     //   4296: iconst_1
/*      */     //   4297: aload_1
/*      */     //   4298: iload_2
/*      */     //   4299: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4304: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   4307: wide dstore #485
/*      */     //   4311: aload #21
/*      */     //   4313: iconst_0
/*      */     //   4314: daload
/*      */     //   4315: wide dstore #483
/*      */     //   4319: wide dload #485
/*      */     //   4323: wide dload #483
/*      */     //   4327: dadd
/*      */     //   4328: wide dstore #481
/*      */     //   4332: wide aload #501
/*      */     //   4336: wide iload #502
/*      */     //   4340: wide dload #481
/*      */     //   4344: invokeinterface setDouble : (ID)V
/*      */     //   4349: iinc #36, 1
/*      */     //   4352: aload #34
/*      */     //   4354: iconst_0
/*      */     //   4355: iaload
/*      */     //   4356: wide istore #480
/*      */     //   4360: iload #36
/*      */     //   4362: wide iload #480
/*      */     //   4366: if_icmplt -> 4057
/*      */     //   4369: goto -> 4372
/*      */     //   4372: aload #39
/*      */     //   4374: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4377: wide astore #478
/*      */     //   4381: iload #37
/*      */     //   4383: iload #32
/*      */     //   4385: irem
/*      */     //   4386: iconst_4
/*      */     //   4387: imul
/*      */     //   4388: wide istore #475
/*      */     //   4392: wide aload #478
/*      */     //   4396: wide astore #473
/*      */     //   4400: iconst_0
/*      */     //   4401: wide iload #475
/*      */     //   4405: iadd
/*      */     //   4406: wide istore #474
/*      */     //   4410: wide aload #473
/*      */     //   4414: wide iload #474
/*      */     //   4418: invokeinterface getInt : (I)I
/*      */     //   4423: wide istore #472
/*      */     //   4427: aload #38
/*      */     //   4429: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4432: wide astore #470
/*      */     //   4436: iload #37
/*      */     //   4438: iload #33
/*      */     //   4440: irem
/*      */     //   4441: iconst_4
/*      */     //   4442: imul
/*      */     //   4443: wide istore #467
/*      */     //   4447: wide aload #470
/*      */     //   4451: wide astore #465
/*      */     //   4455: iconst_0
/*      */     //   4456: wide iload #467
/*      */     //   4460: iadd
/*      */     //   4461: wide istore #466
/*      */     //   4465: wide aload #465
/*      */     //   4469: wide iload #466
/*      */     //   4473: invokeinterface getInt : (I)I
/*      */     //   4478: wide istore #464
/*      */     //   4482: aload #34
/*      */     //   4484: iconst_0
/*      */     //   4485: iaload
/*      */     //   4486: aload #7
/*      */     //   4488: iload #8
/*      */     //   4490: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4495: aload #5
/*      */     //   4497: iload #6
/*      */     //   4499: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4504: iconst_1
/*      */     //   4505: wide iload #464
/*      */     //   4509: wide iload #472
/*      */     //   4513: aload_1
/*      */     //   4514: iload_2
/*      */     //   4515: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4520: invokestatic Rf_GPolygon : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4523: iinc #37, 1
/*      */     //   4526: aload #35
/*      */     //   4528: iconst_0
/*      */     //   4529: iaload
/*      */     //   4530: wide istore #462
/*      */     //   4534: iload #37
/*      */     //   4536: wide iload #462
/*      */     //   4540: if_icmplt -> 3506
/*      */     //   4543: goto -> 4546
/*      */     //   4546: goto -> 7690
/*      */     //   4549: aload #34
/*      */     //   4551: iconst_0
/*      */     //   4552: iaload
/*      */     //   4553: iconst_3
/*      */     //   4554: if_icmpne -> 4560
/*      */     //   4557: goto -> 4611
/*      */     //   4560: aload #34
/*      */     //   4562: iconst_0
/*      */     //   4563: iaload
/*      */     //   4564: iconst_4
/*      */     //   4565: if_icmpne -> 4571
/*      */     //   4568: goto -> 4611
/*      */     //   4571: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4574: dup
/*      */     //   4575: ldc 'graphics '
/*      */     //   4577: invokevirtual getBytes : ()[B
/*      */     //   4580: iconst_0
/*      */     //   4581: invokespecial <init> : ([BI)V
/*      */     //   4584: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4587: dup
/*      */     //   4588: ldc_w 'invalid thermometers data (need 3 or 4 columns) '
/*      */     //   4591: invokevirtual getBytes : ()[B
/*      */     //   4594: iconst_0
/*      */     //   4595: invokespecial <init> : ([BI)V
/*      */     //   4598: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   4601: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   4604: iconst_0
/*      */     //   4605: anewarray java/lang/Object
/*      */     //   4608: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   4611: aload #35
/*      */     //   4613: iconst_0
/*      */     //   4614: iaload
/*      */     //   4615: wide istore #457
/*      */     //   4619: aload #40
/*      */     //   4621: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4624: wide astore #455
/*      */     //   4628: aload #35
/*      */     //   4630: iconst_0
/*      */     //   4631: iaload
/*      */     //   4632: bipush #16
/*      */     //   4634: imul
/*      */     //   4635: wide istore #452
/*      */     //   4639: wide aload #455
/*      */     //   4643: wide astore #450
/*      */     //   4647: iconst_0
/*      */     //   4648: wide iload #452
/*      */     //   4652: iadd
/*      */     //   4653: wide istore #451
/*      */     //   4657: wide aload #450
/*      */     //   4661: wide iload #451
/*      */     //   4665: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4670: wide iload #457
/*      */     //   4674: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   4677: dup
/*      */     //   4678: aload #30
/*      */     //   4680: iconst_0
/*      */     //   4681: invokespecial <init> : ([DI)V
/*      */     //   4684: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4687: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   4690: dup
/*      */     //   4691: aload #29
/*      */     //   4693: iconst_0
/*      */     //   4694: invokespecial <init> : ([DI)V
/*      */     //   4697: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4700: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4703: pop
/*      */     //   4704: aload #30
/*      */     //   4706: iconst_0
/*      */     //   4707: daload
/*      */     //   4708: wide dstore #448
/*      */     //   4712: aload #29
/*      */     //   4714: iconst_0
/*      */     //   4715: daload
/*      */     //   4716: wide dstore #446
/*      */     //   4720: wide dload #448
/*      */     //   4724: wide dload #446
/*      */     //   4728: dcmpg
/*      */     //   4729: iflt -> 4735
/*      */     //   4732: goto -> 4851
/*      */     //   4735: aload #34
/*      */     //   4737: iconst_0
/*      */     //   4738: iaload
/*      */     //   4739: iconst_4
/*      */     //   4740: if_icmpeq -> 4746
/*      */     //   4743: goto -> 4772
/*      */     //   4746: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4749: dup
/*      */     //   4750: ldc_w '3:4 '
/*      */     //   4753: invokevirtual getBytes : ()[B
/*      */     //   4756: iconst_0
/*      */     //   4757: invokespecial <init> : ([BI)V
/*      */     //   4760: wide astore #444
/*      */     //   4764: iconst_0
/*      */     //   4765: wide istore #445
/*      */     //   4769: goto -> 4795
/*      */     //   4772: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4775: dup
/*      */     //   4776: ldc_w '3 '
/*      */     //   4779: invokevirtual getBytes : ()[B
/*      */     //   4782: iconst_0
/*      */     //   4783: invokespecial <init> : ([BI)V
/*      */     //   4786: wide astore #444
/*      */     //   4790: iconst_0
/*      */     //   4791: wide istore #445
/*      */     //   4795: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4798: dup
/*      */     //   4799: ldc 'graphics '
/*      */     //   4801: invokevirtual getBytes : ()[B
/*      */     //   4804: iconst_0
/*      */     //   4805: invokespecial <init> : ([BI)V
/*      */     //   4808: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4811: dup
/*      */     //   4812: ldc_w 'invalid 'thermometers[, %s]' '
/*      */     //   4815: invokevirtual getBytes : ()[B
/*      */     //   4818: iconst_0
/*      */     //   4819: invokespecial <init> : ([BI)V
/*      */     //   4822: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   4825: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   4828: iconst_1
/*      */     //   4829: anewarray java/lang/Object
/*      */     //   4832: dup
/*      */     //   4833: iconst_0
/*      */     //   4834: wide aload #444
/*      */     //   4838: wide iload #445
/*      */     //   4842: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4847: aastore
/*      */     //   4848: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   4851: aload #29
/*      */     //   4853: iconst_0
/*      */     //   4854: daload
/*      */     //   4855: dconst_0
/*      */     //   4856: dcmpg
/*      */     //   4857: iflt -> 4875
/*      */     //   4860: goto -> 4863
/*      */     //   4863: aload #30
/*      */     //   4865: iconst_0
/*      */     //   4866: daload
/*      */     //   4867: dconst_1
/*      */     //   4868: dcmpl
/*      */     //   4869: ifgt -> 4875
/*      */     //   4872: goto -> 4991
/*      */     //   4875: aload #34
/*      */     //   4877: iconst_0
/*      */     //   4878: iaload
/*      */     //   4879: iconst_4
/*      */     //   4880: if_icmpeq -> 4886
/*      */     //   4883: goto -> 4912
/*      */     //   4886: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4889: dup
/*      */     //   4890: ldc_w '3:4 '
/*      */     //   4893: invokevirtual getBytes : ()[B
/*      */     //   4896: iconst_0
/*      */     //   4897: invokespecial <init> : ([BI)V
/*      */     //   4900: wide astore #435
/*      */     //   4904: iconst_0
/*      */     //   4905: wide istore #436
/*      */     //   4909: goto -> 4935
/*      */     //   4912: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4915: dup
/*      */     //   4916: ldc_w '3 '
/*      */     //   4919: invokevirtual getBytes : ()[B
/*      */     //   4922: iconst_0
/*      */     //   4923: invokespecial <init> : ([BI)V
/*      */     //   4926: wide astore #435
/*      */     //   4930: iconst_0
/*      */     //   4931: wide istore #436
/*      */     //   4935: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4938: dup
/*      */     //   4939: ldc 'graphics '
/*      */     //   4941: invokevirtual getBytes : ()[B
/*      */     //   4944: iconst_0
/*      */     //   4945: invokespecial <init> : ([BI)V
/*      */     //   4948: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4951: dup
/*      */     //   4952: ldc_w ''thermometers[, %s]' not in [0,1] -- may look funny '
/*      */     //   4955: invokevirtual getBytes : ()[B
/*      */     //   4958: iconst_0
/*      */     //   4959: invokespecial <init> : ([BI)V
/*      */     //   4962: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   4965: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   4968: iconst_1
/*      */     //   4969: anewarray java/lang/Object
/*      */     //   4972: dup
/*      */     //   4973: iconst_0
/*      */     //   4974: wide aload #435
/*      */     //   4978: wide iload #436
/*      */     //   4982: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4987: aastore
/*      */     //   4988: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   4991: aload #35
/*      */     //   4993: iconst_0
/*      */     //   4994: iaload
/*      */     //   4995: iconst_2
/*      */     //   4996: imul
/*      */     //   4997: wide istore #430
/*      */     //   5001: aload #40
/*      */     //   5003: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5006: wide iload #430
/*      */     //   5010: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5013: dup
/*      */     //   5014: aload #30
/*      */     //   5016: iconst_0
/*      */     //   5017: invokespecial <init> : ([DI)V
/*      */     //   5020: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5023: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5026: dup
/*      */     //   5027: aload #29
/*      */     //   5029: iconst_0
/*      */     //   5030: invokespecial <init> : ([DI)V
/*      */     //   5033: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5036: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   5039: ifeq -> 5045
/*      */     //   5042: goto -> 5085
/*      */     //   5045: new org/renjin/gcc/runtime/BytePtr
/*      */     //   5048: dup
/*      */     //   5049: ldc 'graphics '
/*      */     //   5051: invokevirtual getBytes : ()[B
/*      */     //   5054: iconst_0
/*      */     //   5055: invokespecial <init> : ([BI)V
/*      */     //   5058: new org/renjin/gcc/runtime/BytePtr
/*      */     //   5061: dup
/*      */     //   5062: ldc_w 'invalid 'thermometers[, 1:2]' '
/*      */     //   5065: invokevirtual getBytes : ()[B
/*      */     //   5068: iconst_0
/*      */     //   5069: invokespecial <init> : ([BI)V
/*      */     //   5072: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   5075: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   5078: iconst_0
/*      */     //   5079: anewarray java/lang/Object
/*      */     //   5082: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   5085: iconst_0
/*      */     //   5086: istore #37
/*      */     //   5088: goto -> 6344
/*      */     //   5091: aload #42
/*      */     //   5093: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5096: wide astore #423
/*      */     //   5100: iload #37
/*      */     //   5102: bipush #8
/*      */     //   5104: imul
/*      */     //   5105: wide istore #421
/*      */     //   5109: wide aload #423
/*      */     //   5113: wide astore #419
/*      */     //   5117: iconst_0
/*      */     //   5118: wide iload #421
/*      */     //   5122: iadd
/*      */     //   5123: wide istore #420
/*      */     //   5127: wide aload #419
/*      */     //   5131: wide iload #420
/*      */     //   5135: invokeinterface getDouble : (I)D
/*      */     //   5140: wide dstore #417
/*      */     //   5144: aload #22
/*      */     //   5146: iconst_0
/*      */     //   5147: wide dload #417
/*      */     //   5151: dastore
/*      */     //   5152: aload #41
/*      */     //   5154: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5157: wide astore #415
/*      */     //   5161: iload #37
/*      */     //   5163: bipush #8
/*      */     //   5165: imul
/*      */     //   5166: wide istore #413
/*      */     //   5170: wide aload #415
/*      */     //   5174: wide astore #411
/*      */     //   5178: iconst_0
/*      */     //   5179: wide iload #413
/*      */     //   5183: iadd
/*      */     //   5184: wide istore #412
/*      */     //   5188: wide aload #411
/*      */     //   5192: wide iload #412
/*      */     //   5196: invokeinterface getDouble : (I)D
/*      */     //   5201: wide dstore #409
/*      */     //   5205: aload #21
/*      */     //   5207: iconst_0
/*      */     //   5208: wide dload #409
/*      */     //   5212: dastore
/*      */     //   5213: aload #22
/*      */     //   5215: iconst_0
/*      */     //   5216: daload
/*      */     //   5217: invokestatic R_finite : (D)I
/*      */     //   5220: ifne -> 5226
/*      */     //   5223: goto -> 6341
/*      */     //   5226: aload #21
/*      */     //   5228: iconst_0
/*      */     //   5229: daload
/*      */     //   5230: invokestatic R_finite : (D)I
/*      */     //   5233: ifne -> 5239
/*      */     //   5236: goto -> 6341
/*      */     //   5239: aload #40
/*      */     //   5241: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5244: wide astore #401
/*      */     //   5248: iload #37
/*      */     //   5250: bipush #8
/*      */     //   5252: imul
/*      */     //   5253: wide istore #399
/*      */     //   5257: wide aload #401
/*      */     //   5261: wide astore #397
/*      */     //   5265: iconst_0
/*      */     //   5266: wide iload #399
/*      */     //   5270: iadd
/*      */     //   5271: wide istore #398
/*      */     //   5275: wide aload #397
/*      */     //   5279: wide iload #398
/*      */     //   5283: invokeinterface getDouble : (I)D
/*      */     //   5288: dstore #19
/*      */     //   5290: aload #40
/*      */     //   5292: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5295: wide astore #395
/*      */     //   5299: aload #35
/*      */     //   5301: iconst_0
/*      */     //   5302: iaload
/*      */     //   5303: wide istore #394
/*      */     //   5307: iload #37
/*      */     //   5309: wide iload #394
/*      */     //   5313: iadd
/*      */     //   5314: bipush #8
/*      */     //   5316: imul
/*      */     //   5317: wide istore #391
/*      */     //   5321: wide aload #395
/*      */     //   5325: wide astore #389
/*      */     //   5329: iconst_0
/*      */     //   5330: wide iload #391
/*      */     //   5334: iadd
/*      */     //   5335: wide istore #390
/*      */     //   5339: wide aload #389
/*      */     //   5343: wide iload #390
/*      */     //   5347: invokeinterface getDouble : (I)D
/*      */     //   5352: dstore #17
/*      */     //   5354: aload #40
/*      */     //   5356: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5359: wide astore #387
/*      */     //   5363: aload #35
/*      */     //   5365: iconst_0
/*      */     //   5366: iaload
/*      */     //   5367: iconst_2
/*      */     //   5368: imul
/*      */     //   5369: iload #37
/*      */     //   5371: iadd
/*      */     //   5372: bipush #8
/*      */     //   5374: imul
/*      */     //   5375: wide istore #382
/*      */     //   5379: wide aload #387
/*      */     //   5383: wide astore #380
/*      */     //   5387: iconst_0
/*      */     //   5388: wide iload #382
/*      */     //   5392: iadd
/*      */     //   5393: wide istore #381
/*      */     //   5397: wide aload #380
/*      */     //   5401: wide iload #381
/*      */     //   5405: invokeinterface getDouble : (I)D
/*      */     //   5410: dstore #15
/*      */     //   5412: aload #34
/*      */     //   5414: iconst_0
/*      */     //   5415: iaload
/*      */     //   5416: iconst_4
/*      */     //   5417: if_icmpeq -> 5423
/*      */     //   5420: goto -> 5486
/*      */     //   5423: aload #40
/*      */     //   5425: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5428: wide astore #375
/*      */     //   5432: aload #35
/*      */     //   5434: iconst_0
/*      */     //   5435: iaload
/*      */     //   5436: iconst_3
/*      */     //   5437: imul
/*      */     //   5438: iload #37
/*      */     //   5440: iadd
/*      */     //   5441: bipush #8
/*      */     //   5443: imul
/*      */     //   5444: wide istore #370
/*      */     //   5448: wide aload #375
/*      */     //   5452: wide astore #368
/*      */     //   5456: iconst_0
/*      */     //   5457: wide iload #370
/*      */     //   5461: iadd
/*      */     //   5462: wide istore #369
/*      */     //   5466: wide aload #368
/*      */     //   5470: wide iload #369
/*      */     //   5474: invokeinterface getDouble : (I)D
/*      */     //   5479: wide dstore #378
/*      */     //   5483: goto -> 5491
/*      */     //   5486: dconst_0
/*      */     //   5487: wide dstore #378
/*      */     //   5491: wide dload #378
/*      */     //   5495: dstore #13
/*      */     //   5497: dload #19
/*      */     //   5499: invokestatic R_finite : (D)I
/*      */     //   5502: ifne -> 5508
/*      */     //   5505: goto -> 6341
/*      */     //   5508: dload #17
/*      */     //   5510: invokestatic R_finite : (D)I
/*      */     //   5513: ifne -> 5519
/*      */     //   5516: goto -> 6341
/*      */     //   5519: dload #15
/*      */     //   5521: invokestatic R_finite : (D)I
/*      */     //   5524: ifne -> 5530
/*      */     //   5527: goto -> 6341
/*      */     //   5530: dload #13
/*      */     //   5532: invokestatic R_finite : (D)I
/*      */     //   5535: ifne -> 5541
/*      */     //   5538: goto -> 6341
/*      */     //   5541: dload #15
/*      */     //   5543: dconst_0
/*      */     //   5544: dcmpg
/*      */     //   5545: iflt -> 5551
/*      */     //   5548: goto -> 5557
/*      */     //   5551: dconst_0
/*      */     //   5552: dstore #15
/*      */     //   5554: goto -> 5570
/*      */     //   5557: dload #15
/*      */     //   5559: dconst_1
/*      */     //   5560: dcmpl
/*      */     //   5561: ifgt -> 5567
/*      */     //   5564: goto -> 5570
/*      */     //   5567: dconst_1
/*      */     //   5568: dstore #15
/*      */     //   5570: dload #13
/*      */     //   5572: dconst_0
/*      */     //   5573: dcmpg
/*      */     //   5574: iflt -> 5580
/*      */     //   5577: goto -> 5586
/*      */     //   5580: dconst_0
/*      */     //   5581: dstore #13
/*      */     //   5583: goto -> 5599
/*      */     //   5586: dload #13
/*      */     //   5588: dconst_1
/*      */     //   5589: dcmpl
/*      */     //   5590: ifgt -> 5596
/*      */     //   5593: goto -> 5599
/*      */     //   5596: dconst_1
/*      */     //   5597: dstore #13
/*      */     //   5599: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5602: dup
/*      */     //   5603: aload #22
/*      */     //   5605: iconst_0
/*      */     //   5606: invokespecial <init> : ([DI)V
/*      */     //   5609: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5612: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   5615: dup
/*      */     //   5616: aload #21
/*      */     //   5618: iconst_0
/*      */     //   5619: invokespecial <init> : ([DI)V
/*      */     //   5622: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5625: bipush #12
/*      */     //   5627: iconst_1
/*      */     //   5628: aload_1
/*      */     //   5629: iload_2
/*      */     //   5630: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5635: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5638: dload #27
/*      */     //   5640: dconst_0
/*      */     //   5641: dcmpl
/*      */     //   5642: ifgt -> 5648
/*      */     //   5645: goto -> 5733
/*      */     //   5648: aload #30
/*      */     //   5650: iconst_0
/*      */     //   5651: daload
/*      */     //   5652: wide dstore #362
/*      */     //   5656: dload #27
/*      */     //   5658: wide dload #362
/*      */     //   5662: ddiv
/*      */     //   5663: dload #19
/*      */     //   5665: dmul
/*      */     //   5666: dstore #19
/*      */     //   5668: aload #30
/*      */     //   5670: iconst_0
/*      */     //   5671: daload
/*      */     //   5672: wide dstore #358
/*      */     //   5676: dload #27
/*      */     //   5678: wide dload #358
/*      */     //   5682: ddiv
/*      */     //   5683: dload #17
/*      */     //   5685: dmul
/*      */     //   5686: dstore #17
/*      */     //   5688: dload #19
/*      */     //   5690: ldc2_w 0.5
/*      */     //   5693: dmul
/*      */     //   5694: bipush #13
/*      */     //   5696: iconst_1
/*      */     //   5697: aload_1
/*      */     //   5698: iload_2
/*      */     //   5699: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5704: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5707: dstore #25
/*      */     //   5709: dload #17
/*      */     //   5711: ldc2_w 0.5
/*      */     //   5714: dmul
/*      */     //   5715: bipush #13
/*      */     //   5717: iconst_1
/*      */     //   5718: aload_1
/*      */     //   5719: iload_2
/*      */     //   5720: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5725: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5728: dstore #23
/*      */     //   5730: goto -> 5775
/*      */     //   5733: dload #19
/*      */     //   5735: ldc2_w 0.5
/*      */     //   5738: dmul
/*      */     //   5739: bipush #12
/*      */     //   5741: iconst_1
/*      */     //   5742: aload_1
/*      */     //   5743: iload_2
/*      */     //   5744: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5749: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5752: dstore #25
/*      */     //   5754: dload #17
/*      */     //   5756: ldc2_w 0.5
/*      */     //   5759: dmul
/*      */     //   5760: bipush #12
/*      */     //   5762: iconst_1
/*      */     //   5763: aload_1
/*      */     //   5764: iload_2
/*      */     //   5765: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5770: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   5773: dstore #23
/*      */     //   5775: aload #39
/*      */     //   5777: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5780: wide astore #346
/*      */     //   5784: iload #37
/*      */     //   5786: iload #32
/*      */     //   5788: irem
/*      */     //   5789: iconst_4
/*      */     //   5790: imul
/*      */     //   5791: wide istore #343
/*      */     //   5795: wide aload #346
/*      */     //   5799: wide astore #341
/*      */     //   5803: iconst_0
/*      */     //   5804: wide iload #343
/*      */     //   5808: iadd
/*      */     //   5809: wide istore #342
/*      */     //   5813: wide aload #341
/*      */     //   5817: wide iload #342
/*      */     //   5821: invokeinterface getInt : (I)I
/*      */     //   5826: wide istore #340
/*      */     //   5830: aload #38
/*      */     //   5832: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5835: wide astore #338
/*      */     //   5839: iload #37
/*      */     //   5841: iload #33
/*      */     //   5843: irem
/*      */     //   5844: iconst_4
/*      */     //   5845: imul
/*      */     //   5846: wide istore #335
/*      */     //   5850: wide aload #338
/*      */     //   5854: wide astore #333
/*      */     //   5858: iconst_0
/*      */     //   5859: wide iload #335
/*      */     //   5863: iadd
/*      */     //   5864: wide istore #334
/*      */     //   5868: wide aload #333
/*      */     //   5872: wide iload #334
/*      */     //   5876: invokeinterface getInt : (I)I
/*      */     //   5881: wide istore #332
/*      */     //   5885: aload #21
/*      */     //   5887: iconst_0
/*      */     //   5888: daload
/*      */     //   5889: dload #23
/*      */     //   5891: dadd
/*      */     //   5892: wide dstore #328
/*      */     //   5896: aload #22
/*      */     //   5898: iconst_0
/*      */     //   5899: daload
/*      */     //   5900: dload #25
/*      */     //   5902: dadd
/*      */     //   5903: wide dstore #324
/*      */     //   5907: aload #21
/*      */     //   5909: iconst_0
/*      */     //   5910: daload
/*      */     //   5911: dload #23
/*      */     //   5913: dsub
/*      */     //   5914: wide dstore #320
/*      */     //   5918: aload #22
/*      */     //   5920: iconst_0
/*      */     //   5921: daload
/*      */     //   5922: dload #25
/*      */     //   5924: dsub
/*      */     //   5925: wide dload #320
/*      */     //   5929: wide dload #324
/*      */     //   5933: wide dload #328
/*      */     //   5937: iconst_1
/*      */     //   5938: wide iload #332
/*      */     //   5942: wide iload #340
/*      */     //   5946: aload_1
/*      */     //   5947: iload_2
/*      */     //   5948: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5953: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5956: aload #39
/*      */     //   5958: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5961: wide astore #314
/*      */     //   5965: iload #37
/*      */     //   5967: iload #32
/*      */     //   5969: irem
/*      */     //   5970: iconst_4
/*      */     //   5971: imul
/*      */     //   5972: wide istore #311
/*      */     //   5976: wide aload #314
/*      */     //   5980: wide astore #309
/*      */     //   5984: iconst_0
/*      */     //   5985: wide iload #311
/*      */     //   5989: iadd
/*      */     //   5990: wide istore #310
/*      */     //   5994: wide aload #309
/*      */     //   5998: wide iload #310
/*      */     //   6002: invokeinterface getInt : (I)I
/*      */     //   6007: wide istore #308
/*      */     //   6011: aload #39
/*      */     //   6013: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6016: wide astore #306
/*      */     //   6020: iload #37
/*      */     //   6022: iload #32
/*      */     //   6024: irem
/*      */     //   6025: iconst_4
/*      */     //   6026: imul
/*      */     //   6027: wide istore #303
/*      */     //   6031: wide aload #306
/*      */     //   6035: wide astore #301
/*      */     //   6039: iconst_0
/*      */     //   6040: wide iload #303
/*      */     //   6044: iadd
/*      */     //   6045: wide istore #302
/*      */     //   6049: wide aload #301
/*      */     //   6053: wide iload #302
/*      */     //   6057: invokeinterface getInt : (I)I
/*      */     //   6062: wide istore #300
/*      */     //   6066: aload #21
/*      */     //   6068: iconst_0
/*      */     //   6069: daload
/*      */     //   6070: wide dstore #298
/*      */     //   6074: dload #13
/*      */     //   6076: ldc2_w 2.0
/*      */     //   6079: dmul
/*      */     //   6080: wide dstore #296
/*      */     //   6084: dconst_1
/*      */     //   6085: wide dload #296
/*      */     //   6089: dsub
/*      */     //   6090: dload #23
/*      */     //   6092: dmul
/*      */     //   6093: wide dstore #292
/*      */     //   6097: wide dload #298
/*      */     //   6101: wide dload #292
/*      */     //   6105: dsub
/*      */     //   6106: wide dstore #290
/*      */     //   6110: aload #22
/*      */     //   6112: iconst_0
/*      */     //   6113: daload
/*      */     //   6114: dload #25
/*      */     //   6116: dadd
/*      */     //   6117: wide dstore #286
/*      */     //   6121: aload #21
/*      */     //   6123: iconst_0
/*      */     //   6124: daload
/*      */     //   6125: wide dstore #284
/*      */     //   6129: dload #15
/*      */     //   6131: ldc2_w 2.0
/*      */     //   6134: dmul
/*      */     //   6135: wide dstore #282
/*      */     //   6139: dconst_1
/*      */     //   6140: wide dload #282
/*      */     //   6144: dsub
/*      */     //   6145: dload #23
/*      */     //   6147: dmul
/*      */     //   6148: wide dstore #278
/*      */     //   6152: wide dload #284
/*      */     //   6156: wide dload #278
/*      */     //   6160: dsub
/*      */     //   6161: wide dstore #276
/*      */     //   6165: aload #22
/*      */     //   6167: iconst_0
/*      */     //   6168: daload
/*      */     //   6169: dload #25
/*      */     //   6171: dsub
/*      */     //   6172: wide dload #276
/*      */     //   6176: wide dload #286
/*      */     //   6180: wide dload #290
/*      */     //   6184: iconst_1
/*      */     //   6185: wide iload #300
/*      */     //   6189: wide iload #308
/*      */     //   6193: aload_1
/*      */     //   6194: iload_2
/*      */     //   6195: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6200: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6203: aload #21
/*      */     //   6205: iconst_0
/*      */     //   6206: daload
/*      */     //   6207: wide dstore #270
/*      */     //   6211: aload #22
/*      */     //   6213: iconst_0
/*      */     //   6214: daload
/*      */     //   6215: wide dstore #268
/*      */     //   6219: dload #25
/*      */     //   6221: ldc2_w 1.5
/*      */     //   6224: dmul
/*      */     //   6225: wide dstore #266
/*      */     //   6229: wide dload #268
/*      */     //   6233: wide dload #266
/*      */     //   6237: dsub
/*      */     //   6238: wide dstore #264
/*      */     //   6242: aload #21
/*      */     //   6244: iconst_0
/*      */     //   6245: daload
/*      */     //   6246: wide dstore #262
/*      */     //   6250: aload #22
/*      */     //   6252: iconst_0
/*      */     //   6253: daload
/*      */     //   6254: dload #25
/*      */     //   6256: dsub
/*      */     //   6257: wide dload #262
/*      */     //   6261: wide dload #264
/*      */     //   6265: wide dload #270
/*      */     //   6269: iconst_1
/*      */     //   6270: aload_1
/*      */     //   6271: iload_2
/*      */     //   6272: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6277: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6280: aload #21
/*      */     //   6282: iconst_0
/*      */     //   6283: daload
/*      */     //   6284: wide dstore #256
/*      */     //   6288: dload #25
/*      */     //   6290: ldc2_w 1.5
/*      */     //   6293: dmul
/*      */     //   6294: dstore #254
/*      */     //   6296: aload #22
/*      */     //   6298: iconst_0
/*      */     //   6299: daload
/*      */     //   6300: dstore #252
/*      */     //   6302: dload #254
/*      */     //   6304: dload #252
/*      */     //   6306: dadd
/*      */     //   6307: dstore #250
/*      */     //   6309: aload #21
/*      */     //   6311: iconst_0
/*      */     //   6312: daload
/*      */     //   6313: dstore #248
/*      */     //   6315: aload #22
/*      */     //   6317: iconst_0
/*      */     //   6318: daload
/*      */     //   6319: dload #25
/*      */     //   6321: dadd
/*      */     //   6322: dload #248
/*      */     //   6324: dload #250
/*      */     //   6326: wide dload #256
/*      */     //   6330: iconst_1
/*      */     //   6331: aload_1
/*      */     //   6332: iload_2
/*      */     //   6333: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6338: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6341: iinc #37, 1
/*      */     //   6344: aload #35
/*      */     //   6346: iconst_0
/*      */     //   6347: iaload
/*      */     //   6348: istore #243
/*      */     //   6350: iload #37
/*      */     //   6352: iload #243
/*      */     //   6354: if_icmplt -> 5091
/*      */     //   6357: goto -> 6360
/*      */     //   6360: goto -> 7690
/*      */     //   6363: aload #34
/*      */     //   6365: iconst_0
/*      */     //   6366: iaload
/*      */     //   6367: iconst_5
/*      */     //   6368: if_icmpne -> 6374
/*      */     //   6371: goto -> 6414
/*      */     //   6374: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6377: dup
/*      */     //   6378: ldc 'graphics '
/*      */     //   6380: invokevirtual getBytes : ()[B
/*      */     //   6383: iconst_0
/*      */     //   6384: invokespecial <init> : ([BI)V
/*      */     //   6387: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6390: dup
/*      */     //   6391: ldc_w 'invalid 'boxplots' data (need 5 columns) '
/*      */     //   6394: invokevirtual getBytes : ()[B
/*      */     //   6397: iconst_0
/*      */     //   6398: invokespecial <init> : ([BI)V
/*      */     //   6401: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   6404: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   6407: iconst_0
/*      */     //   6408: anewarray java/lang/Object
/*      */     //   6411: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   6414: aload #30
/*      */     //   6416: iconst_0
/*      */     //   6417: ldc2_w -1.7976931348623157E308
/*      */     //   6420: dastore
/*      */     //   6421: aload #29
/*      */     //   6423: iconst_0
/*      */     //   6424: ldc2_w 1.7976931348623157E308
/*      */     //   6427: dastore
/*      */     //   6428: iconst_0
/*      */     //   6429: istore #37
/*      */     //   6431: goto -> 6517
/*      */     //   6434: aload #40
/*      */     //   6436: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6439: astore #238
/*      */     //   6441: aload #35
/*      */     //   6443: iconst_0
/*      */     //   6444: iaload
/*      */     //   6445: iconst_4
/*      */     //   6446: imul
/*      */     //   6447: iload #37
/*      */     //   6449: iadd
/*      */     //   6450: bipush #8
/*      */     //   6452: imul
/*      */     //   6453: istore #233
/*      */     //   6455: aload #238
/*      */     //   6457: astore #231
/*      */     //   6459: iconst_0
/*      */     //   6460: iload #233
/*      */     //   6462: iadd
/*      */     //   6463: istore #232
/*      */     //   6465: aload #231
/*      */     //   6467: iload #232
/*      */     //   6469: invokeinterface getDouble : (I)D
/*      */     //   6474: dstore #11
/*      */     //   6476: aload #30
/*      */     //   6478: iconst_0
/*      */     //   6479: daload
/*      */     //   6480: dload #11
/*      */     //   6482: dcmpg
/*      */     //   6483: iflt -> 6489
/*      */     //   6486: goto -> 6495
/*      */     //   6489: aload #30
/*      */     //   6491: iconst_0
/*      */     //   6492: dload #11
/*      */     //   6494: dastore
/*      */     //   6495: aload #29
/*      */     //   6497: iconst_0
/*      */     //   6498: daload
/*      */     //   6499: dload #11
/*      */     //   6501: dcmpl
/*      */     //   6502: ifgt -> 6508
/*      */     //   6505: goto -> 6514
/*      */     //   6508: aload #29
/*      */     //   6510: iconst_0
/*      */     //   6511: dload #11
/*      */     //   6513: dastore
/*      */     //   6514: iinc #37, 1
/*      */     //   6517: aload #35
/*      */     //   6519: iconst_0
/*      */     //   6520: iaload
/*      */     //   6521: istore #226
/*      */     //   6523: iload #37
/*      */     //   6525: iload #226
/*      */     //   6527: if_icmplt -> 6434
/*      */     //   6530: goto -> 6533
/*      */     //   6533: aload #29
/*      */     //   6535: iconst_0
/*      */     //   6536: daload
/*      */     //   6537: dconst_0
/*      */     //   6538: dcmpg
/*      */     //   6539: iflt -> 6557
/*      */     //   6542: goto -> 6545
/*      */     //   6545: aload #30
/*      */     //   6547: iconst_0
/*      */     //   6548: daload
/*      */     //   6549: dconst_1
/*      */     //   6550: dcmpl
/*      */     //   6551: ifgt -> 6557
/*      */     //   6554: goto -> 6597
/*      */     //   6557: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6560: dup
/*      */     //   6561: ldc 'graphics '
/*      */     //   6563: invokevirtual getBytes : ()[B
/*      */     //   6566: iconst_0
/*      */     //   6567: invokespecial <init> : ([BI)V
/*      */     //   6570: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6573: dup
/*      */     //   6574: ldc_w ''boxplots[, 5]' outside [0,1] -- may look funny '
/*      */     //   6577: invokevirtual getBytes : ()[B
/*      */     //   6580: iconst_0
/*      */     //   6581: invokespecial <init> : ([BI)V
/*      */     //   6584: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   6587: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   6590: iconst_0
/*      */     //   6591: anewarray java/lang/Object
/*      */     //   6594: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   6597: aload #35
/*      */     //   6599: iconst_0
/*      */     //   6600: iaload
/*      */     //   6601: iconst_4
/*      */     //   6602: imul
/*      */     //   6603: istore #218
/*      */     //   6605: aload #40
/*      */     //   6607: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6610: iload #218
/*      */     //   6612: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   6615: dup
/*      */     //   6616: aload #30
/*      */     //   6618: iconst_0
/*      */     //   6619: invokespecial <init> : ([DI)V
/*      */     //   6622: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6625: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   6628: dup
/*      */     //   6629: aload #29
/*      */     //   6631: iconst_0
/*      */     //   6632: invokespecial <init> : ([DI)V
/*      */     //   6635: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6638: invokestatic SymbolRange : (Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   6641: ifeq -> 6647
/*      */     //   6644: goto -> 6687
/*      */     //   6647: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6650: dup
/*      */     //   6651: ldc 'graphics '
/*      */     //   6653: invokevirtual getBytes : ()[B
/*      */     //   6656: iconst_0
/*      */     //   6657: invokespecial <init> : ([BI)V
/*      */     //   6660: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6663: dup
/*      */     //   6664: ldc_w 'invalid 'boxplots[, 1:4]' '
/*      */     //   6667: invokevirtual getBytes : ()[B
/*      */     //   6670: iconst_0
/*      */     //   6671: invokespecial <init> : ([BI)V
/*      */     //   6674: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   6677: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   6680: iconst_0
/*      */     //   6681: anewarray java/lang/Object
/*      */     //   6684: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   6687: iconst_0
/*      */     //   6688: istore #37
/*      */     //   6690: goto -> 7631
/*      */     //   6693: aload #42
/*      */     //   6695: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6698: astore #211
/*      */     //   6700: iload #37
/*      */     //   6702: bipush #8
/*      */     //   6704: imul
/*      */     //   6705: istore #209
/*      */     //   6707: aload #211
/*      */     //   6709: astore #207
/*      */     //   6711: iconst_0
/*      */     //   6712: iload #209
/*      */     //   6714: iadd
/*      */     //   6715: istore #208
/*      */     //   6717: aload #207
/*      */     //   6719: iload #208
/*      */     //   6721: invokeinterface getDouble : (I)D
/*      */     //   6726: dstore #205
/*      */     //   6728: aload #22
/*      */     //   6730: iconst_0
/*      */     //   6731: dload #205
/*      */     //   6733: dastore
/*      */     //   6734: aload #41
/*      */     //   6736: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6739: astore #203
/*      */     //   6741: iload #37
/*      */     //   6743: bipush #8
/*      */     //   6745: imul
/*      */     //   6746: istore #201
/*      */     //   6748: aload #203
/*      */     //   6750: astore #199
/*      */     //   6752: iconst_0
/*      */     //   6753: iload #201
/*      */     //   6755: iadd
/*      */     //   6756: istore #200
/*      */     //   6758: aload #199
/*      */     //   6760: iload #200
/*      */     //   6762: invokeinterface getDouble : (I)D
/*      */     //   6767: dstore #197
/*      */     //   6769: aload #21
/*      */     //   6771: iconst_0
/*      */     //   6772: dload #197
/*      */     //   6774: dastore
/*      */     //   6775: aload #22
/*      */     //   6777: iconst_0
/*      */     //   6778: daload
/*      */     //   6779: invokestatic R_finite : (D)I
/*      */     //   6782: ifne -> 6788
/*      */     //   6785: goto -> 7628
/*      */     //   6788: aload #21
/*      */     //   6790: iconst_0
/*      */     //   6791: daload
/*      */     //   6792: invokestatic R_finite : (D)I
/*      */     //   6795: ifne -> 6801
/*      */     //   6798: goto -> 7628
/*      */     //   6801: aload #40
/*      */     //   6803: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6806: astore #189
/*      */     //   6808: iload #37
/*      */     //   6810: bipush #8
/*      */     //   6812: imul
/*      */     //   6813: istore #187
/*      */     //   6815: aload #189
/*      */     //   6817: astore #185
/*      */     //   6819: iconst_0
/*      */     //   6820: iload #187
/*      */     //   6822: iadd
/*      */     //   6823: istore #186
/*      */     //   6825: aload #185
/*      */     //   6827: iload #186
/*      */     //   6829: invokeinterface getDouble : (I)D
/*      */     //   6834: dstore #19
/*      */     //   6836: aload #40
/*      */     //   6838: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6841: astore #183
/*      */     //   6843: aload #35
/*      */     //   6845: iconst_0
/*      */     //   6846: iaload
/*      */     //   6847: istore #182
/*      */     //   6849: iload #37
/*      */     //   6851: iload #182
/*      */     //   6853: iadd
/*      */     //   6854: bipush #8
/*      */     //   6856: imul
/*      */     //   6857: istore #179
/*      */     //   6859: aload #183
/*      */     //   6861: astore #177
/*      */     //   6863: iconst_0
/*      */     //   6864: iload #179
/*      */     //   6866: iadd
/*      */     //   6867: istore #178
/*      */     //   6869: aload #177
/*      */     //   6871: iload #178
/*      */     //   6873: invokeinterface getDouble : (I)D
/*      */     //   6878: dstore #17
/*      */     //   6880: aload #40
/*      */     //   6882: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6885: astore #175
/*      */     //   6887: aload #35
/*      */     //   6889: iconst_0
/*      */     //   6890: iaload
/*      */     //   6891: iconst_2
/*      */     //   6892: imul
/*      */     //   6893: iload #37
/*      */     //   6895: iadd
/*      */     //   6896: bipush #8
/*      */     //   6898: imul
/*      */     //   6899: istore #170
/*      */     //   6901: aload #175
/*      */     //   6903: astore #168
/*      */     //   6905: iconst_0
/*      */     //   6906: iload #170
/*      */     //   6908: iadd
/*      */     //   6909: istore #169
/*      */     //   6911: aload #168
/*      */     //   6913: iload #169
/*      */     //   6915: invokeinterface getDouble : (I)D
/*      */     //   6920: dstore #15
/*      */     //   6922: aload #40
/*      */     //   6924: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6927: astore #166
/*      */     //   6929: aload #35
/*      */     //   6931: iconst_0
/*      */     //   6932: iaload
/*      */     //   6933: iconst_3
/*      */     //   6934: imul
/*      */     //   6935: iload #37
/*      */     //   6937: iadd
/*      */     //   6938: bipush #8
/*      */     //   6940: imul
/*      */     //   6941: istore #161
/*      */     //   6943: aload #166
/*      */     //   6945: astore #159
/*      */     //   6947: iconst_0
/*      */     //   6948: iload #161
/*      */     //   6950: iadd
/*      */     //   6951: istore #160
/*      */     //   6953: aload #159
/*      */     //   6955: iload #160
/*      */     //   6957: invokeinterface getDouble : (I)D
/*      */     //   6962: dstore #13
/*      */     //   6964: aload #40
/*      */     //   6966: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6969: astore #157
/*      */     //   6971: aload #35
/*      */     //   6973: iconst_0
/*      */     //   6974: iaload
/*      */     //   6975: iconst_4
/*      */     //   6976: imul
/*      */     //   6977: iload #37
/*      */     //   6979: iadd
/*      */     //   6980: bipush #8
/*      */     //   6982: imul
/*      */     //   6983: istore #152
/*      */     //   6985: aload #157
/*      */     //   6987: astore #150
/*      */     //   6989: iconst_0
/*      */     //   6990: iload #152
/*      */     //   6992: iadd
/*      */     //   6993: istore #151
/*      */     //   6995: aload #150
/*      */     //   6997: iload #151
/*      */     //   6999: invokeinterface getDouble : (I)D
/*      */     //   7004: dstore #11
/*      */     //   7006: dload #19
/*      */     //   7008: invokestatic R_finite : (D)I
/*      */     //   7011: ifne -> 7017
/*      */     //   7014: goto -> 7628
/*      */     //   7017: dload #17
/*      */     //   7019: invokestatic R_finite : (D)I
/*      */     //   7022: ifne -> 7028
/*      */     //   7025: goto -> 7628
/*      */     //   7028: dload #15
/*      */     //   7030: invokestatic R_finite : (D)I
/*      */     //   7033: ifne -> 7039
/*      */     //   7036: goto -> 7628
/*      */     //   7039: dload #13
/*      */     //   7041: invokestatic R_finite : (D)I
/*      */     //   7044: ifne -> 7050
/*      */     //   7047: goto -> 7628
/*      */     //   7050: dload #11
/*      */     //   7052: invokestatic R_finite : (D)I
/*      */     //   7055: ifne -> 7061
/*      */     //   7058: goto -> 7628
/*      */     //   7061: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   7064: dup
/*      */     //   7065: aload #22
/*      */     //   7067: iconst_0
/*      */     //   7068: invokespecial <init> : ([DI)V
/*      */     //   7071: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7074: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   7077: dup
/*      */     //   7078: aload #21
/*      */     //   7080: iconst_0
/*      */     //   7081: invokespecial <init> : ([DI)V
/*      */     //   7084: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7087: bipush #12
/*      */     //   7089: iconst_1
/*      */     //   7090: aload_1
/*      */     //   7091: iload_2
/*      */     //   7092: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7097: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7100: dload #27
/*      */     //   7102: dconst_0
/*      */     //   7103: dcmpl
/*      */     //   7104: ifgt -> 7110
/*      */     //   7107: goto -> 7245
/*      */     //   7110: aload #30
/*      */     //   7112: iconst_0
/*      */     //   7113: daload
/*      */     //   7114: dstore #143
/*      */     //   7116: dload #27
/*      */     //   7118: dload #143
/*      */     //   7120: ddiv
/*      */     //   7121: dload #19
/*      */     //   7123: dmul
/*      */     //   7124: dstore #19
/*      */     //   7126: aload #30
/*      */     //   7128: iconst_0
/*      */     //   7129: daload
/*      */     //   7130: dstore #139
/*      */     //   7132: dload #27
/*      */     //   7134: dload #139
/*      */     //   7136: ddiv
/*      */     //   7137: dload #17
/*      */     //   7139: dmul
/*      */     //   7140: dstore #17
/*      */     //   7142: aload #30
/*      */     //   7144: iconst_0
/*      */     //   7145: daload
/*      */     //   7146: dstore #135
/*      */     //   7148: dload #27
/*      */     //   7150: dload #135
/*      */     //   7152: ddiv
/*      */     //   7153: dload #15
/*      */     //   7155: dmul
/*      */     //   7156: dstore #15
/*      */     //   7158: aload #30
/*      */     //   7160: iconst_0
/*      */     //   7161: daload
/*      */     //   7162: dstore #131
/*      */     //   7164: dload #27
/*      */     //   7166: dload #131
/*      */     //   7168: ddiv
/*      */     //   7169: dload #13
/*      */     //   7171: dmul
/*      */     //   7172: dstore #13
/*      */     //   7174: dload #19
/*      */     //   7176: bipush #13
/*      */     //   7178: iconst_1
/*      */     //   7179: aload_1
/*      */     //   7180: iload_2
/*      */     //   7181: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7186: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7189: dstore #19
/*      */     //   7191: dload #17
/*      */     //   7193: bipush #13
/*      */     //   7195: iconst_1
/*      */     //   7196: aload_1
/*      */     //   7197: iload_2
/*      */     //   7198: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7203: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7206: dstore #17
/*      */     //   7208: dload #15
/*      */     //   7210: bipush #13
/*      */     //   7212: iconst_1
/*      */     //   7213: aload_1
/*      */     //   7214: iload_2
/*      */     //   7215: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7220: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7223: dstore #15
/*      */     //   7225: dload #13
/*      */     //   7227: bipush #13
/*      */     //   7229: iconst_1
/*      */     //   7230: aload_1
/*      */     //   7231: iload_2
/*      */     //   7232: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7237: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7240: dstore #13
/*      */     //   7242: goto -> 7313
/*      */     //   7245: dload #19
/*      */     //   7247: bipush #12
/*      */     //   7249: iconst_1
/*      */     //   7250: aload_1
/*      */     //   7251: iload_2
/*      */     //   7252: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7257: invokestatic Rf_GConvertXUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7260: dstore #19
/*      */     //   7262: dload #17
/*      */     //   7264: bipush #12
/*      */     //   7266: iconst_1
/*      */     //   7267: aload_1
/*      */     //   7268: iload_2
/*      */     //   7269: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7274: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7277: dstore #17
/*      */     //   7279: dload #15
/*      */     //   7281: bipush #12
/*      */     //   7283: iconst_1
/*      */     //   7284: aload_1
/*      */     //   7285: iload_2
/*      */     //   7286: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7291: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7294: dstore #15
/*      */     //   7296: dload #13
/*      */     //   7298: bipush #12
/*      */     //   7300: iconst_1
/*      */     //   7301: aload_1
/*      */     //   7302: iload_2
/*      */     //   7303: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7308: invokestatic Rf_GConvertYUnits : (DIILorg/renjin/gcc/runtime/Ptr;)D
/*      */     //   7311: dstore #13
/*      */     //   7313: dload #19
/*      */     //   7315: ldc2_w 0.5
/*      */     //   7318: dmul
/*      */     //   7319: dstore #25
/*      */     //   7321: dload #17
/*      */     //   7323: ldc2_w 0.5
/*      */     //   7326: dmul
/*      */     //   7327: dstore #23
/*      */     //   7329: dconst_1
/*      */     //   7330: dload #11
/*      */     //   7332: dsub
/*      */     //   7333: dstore #127
/*      */     //   7335: aload #21
/*      */     //   7337: iconst_0
/*      */     //   7338: daload
/*      */     //   7339: dload #23
/*      */     //   7341: dsub
/*      */     //   7342: dstore #123
/*      */     //   7344: dload #127
/*      */     //   7346: dload #123
/*      */     //   7348: dmul
/*      */     //   7349: dstore #121
/*      */     //   7351: aload #21
/*      */     //   7353: iconst_0
/*      */     //   7354: daload
/*      */     //   7355: dload #23
/*      */     //   7357: dadd
/*      */     //   7358: dload #11
/*      */     //   7360: dmul
/*      */     //   7361: dstore #115
/*      */     //   7363: dload #121
/*      */     //   7365: dload #115
/*      */     //   7367: dadd
/*      */     //   7368: dstore #11
/*      */     //   7370: aload #39
/*      */     //   7372: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7375: astore #113
/*      */     //   7377: iload #37
/*      */     //   7379: iload #32
/*      */     //   7381: irem
/*      */     //   7382: iconst_4
/*      */     //   7383: imul
/*      */     //   7384: istore #110
/*      */     //   7386: aload #113
/*      */     //   7388: astore #108
/*      */     //   7390: iconst_0
/*      */     //   7391: iload #110
/*      */     //   7393: iadd
/*      */     //   7394: istore #109
/*      */     //   7396: aload #108
/*      */     //   7398: iload #109
/*      */     //   7400: invokeinterface getInt : (I)I
/*      */     //   7405: istore #107
/*      */     //   7407: aload #38
/*      */     //   7409: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7412: astore #105
/*      */     //   7414: iload #37
/*      */     //   7416: iload #33
/*      */     //   7418: irem
/*      */     //   7419: iconst_4
/*      */     //   7420: imul
/*      */     //   7421: istore #102
/*      */     //   7423: aload #105
/*      */     //   7425: astore #100
/*      */     //   7427: iconst_0
/*      */     //   7428: iload #102
/*      */     //   7430: iadd
/*      */     //   7431: istore #101
/*      */     //   7433: aload #100
/*      */     //   7435: iload #101
/*      */     //   7437: invokeinterface getInt : (I)I
/*      */     //   7442: istore #99
/*      */     //   7444: aload #21
/*      */     //   7446: iconst_0
/*      */     //   7447: daload
/*      */     //   7448: dload #23
/*      */     //   7450: dadd
/*      */     //   7451: dstore #95
/*      */     //   7453: aload #22
/*      */     //   7455: iconst_0
/*      */     //   7456: daload
/*      */     //   7457: dload #25
/*      */     //   7459: dadd
/*      */     //   7460: dstore #91
/*      */     //   7462: aload #21
/*      */     //   7464: iconst_0
/*      */     //   7465: daload
/*      */     //   7466: dload #23
/*      */     //   7468: dsub
/*      */     //   7469: dstore #87
/*      */     //   7471: aload #22
/*      */     //   7473: iconst_0
/*      */     //   7474: daload
/*      */     //   7475: dload #25
/*      */     //   7477: dsub
/*      */     //   7478: dload #87
/*      */     //   7480: dload #91
/*      */     //   7482: dload #95
/*      */     //   7484: iconst_1
/*      */     //   7485: iload #99
/*      */     //   7487: iload #107
/*      */     //   7489: aload_1
/*      */     //   7490: iload_2
/*      */     //   7491: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7496: invokestatic Rf_GRect : (DDDDIIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7499: aload #22
/*      */     //   7501: iconst_0
/*      */     //   7502: daload
/*      */     //   7503: dload #25
/*      */     //   7505: dadd
/*      */     //   7506: dstore #79
/*      */     //   7508: aload #22
/*      */     //   7510: iconst_0
/*      */     //   7511: daload
/*      */     //   7512: dload #25
/*      */     //   7514: dsub
/*      */     //   7515: dload #11
/*      */     //   7517: dload #79
/*      */     //   7519: dload #11
/*      */     //   7521: iconst_1
/*      */     //   7522: aload_1
/*      */     //   7523: iload_2
/*      */     //   7524: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7529: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7532: aload #21
/*      */     //   7534: iconst_0
/*      */     //   7535: daload
/*      */     //   7536: dload #23
/*      */     //   7538: dsub
/*      */     //   7539: dload #15
/*      */     //   7541: dsub
/*      */     //   7542: dstore #69
/*      */     //   7544: aload #22
/*      */     //   7546: iconst_0
/*      */     //   7547: daload
/*      */     //   7548: dstore #67
/*      */     //   7550: aload #21
/*      */     //   7552: iconst_0
/*      */     //   7553: daload
/*      */     //   7554: dload #23
/*      */     //   7556: dsub
/*      */     //   7557: dstore #63
/*      */     //   7559: aload #22
/*      */     //   7561: iconst_0
/*      */     //   7562: daload
/*      */     //   7563: dload #63
/*      */     //   7565: dload #67
/*      */     //   7567: dload #69
/*      */     //   7569: iconst_1
/*      */     //   7570: aload_1
/*      */     //   7571: iload_2
/*      */     //   7572: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7577: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7580: aload #21
/*      */     //   7582: iconst_0
/*      */     //   7583: daload
/*      */     //   7584: dload #23
/*      */     //   7586: dadd
/*      */     //   7587: dload #13
/*      */     //   7589: dadd
/*      */     //   7590: dstore #55
/*      */     //   7592: aload #22
/*      */     //   7594: iconst_0
/*      */     //   7595: daload
/*      */     //   7596: dstore #53
/*      */     //   7598: aload #21
/*      */     //   7600: iconst_0
/*      */     //   7601: daload
/*      */     //   7602: dload #23
/*      */     //   7604: dadd
/*      */     //   7605: dstore #49
/*      */     //   7607: aload #22
/*      */     //   7609: iconst_0
/*      */     //   7610: daload
/*      */     //   7611: dload #49
/*      */     //   7613: dload #53
/*      */     //   7615: dload #55
/*      */     //   7617: iconst_1
/*      */     //   7618: aload_1
/*      */     //   7619: iload_2
/*      */     //   7620: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7625: invokestatic Rf_GLine : (DDDDILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7628: iinc #37, 1
/*      */     //   7631: aload #35
/*      */     //   7633: iconst_0
/*      */     //   7634: iaload
/*      */     //   7635: istore #46
/*      */     //   7637: iload #37
/*      */     //   7639: iload #46
/*      */     //   7641: if_icmplt -> 6693
/*      */     //   7644: goto -> 7647
/*      */     //   7647: goto -> 7690
/*      */     //   7650: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7653: dup
/*      */     //   7654: ldc 'graphics '
/*      */     //   7656: invokevirtual getBytes : ()[B
/*      */     //   7659: iconst_0
/*      */     //   7660: invokespecial <init> : ([BI)V
/*      */     //   7663: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7666: dup
/*      */     //   7667: ldc_w 'invalid symbol type '
/*      */     //   7670: invokevirtual getBytes : ()[B
/*      */     //   7673: iconst_0
/*      */     //   7674: invokespecial <init> : ([BI)V
/*      */     //   7677: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   7680: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   7683: iconst_0
/*      */     //   7684: anewarray java/lang/Object
/*      */     //   7687: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   7690: iconst_0
/*      */     //   7691: aload_1
/*      */     //   7692: iload_2
/*      */     //   7693: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7698: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7701: aload_1
/*      */     //   7702: iload_2
/*      */     //   7703: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7708: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7711: getstatic org/renjin/gnur/api/Rinternals.R_NilValue : Lorg/renjin/sexp/SEXP;
/*      */     //   7714: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #3646	-> 187
/*      */     //   #3647	-> 193
/*      */     //   #3648	-> 203
/*      */     //   #3650	-> 208
/*      */     //   #3651	-> 220
/*      */     //   #3653	-> 259
/*      */     //   #3654	-> 281
/*      */     //   #3655	-> 303
/*      */     //   #3655	-> 314
/*      */     //   #3655	-> 325
/*      */     //   #3655	-> 336
/*      */     //   #3656	-> 347
/*      */     //   #3658	-> 387
/*      */     //   #3661	-> 401
/*      */     //   #3662	-> 420
/*      */     //   #3663	-> 451
/*      */     //   #3663	-> 482
/*      */     //   #3664	-> 513
/*      */     //   #3666	-> 553
/*      */     //   #3667	-> 567
/*      */     //   #3667	-> 578
/*      */     //   #3668	-> 588
/*      */     //   #3670	-> 591
/*      */     //   #3671	-> 613
/*      */     //   #3673	-> 620
/*      */     //   #3674	-> 642
/*      */     //   #3676	-> 649
/*      */     //   #3677	-> 659
/*      */     //   #3679	-> 670
/*      */     //   #3680	-> 681
/*      */     //   #3682	-> 740
/*      */     //   #3683	-> 751
/*      */     //   #3684	-> 791
/*      */     //   #3685	-> 843
/*      */     //   #3686	-> 883
/*      */     //   #3687	-> 889
/*      */     //   #3687	-> 947
/*      */     //   #3688	-> 1005
/*      */     //   #3687	-> 1057
/*      */     //   #3689	-> 1063
/*      */     //   #3691	-> 1114
/*      */     //   #3692	-> 1124
/*      */     //   #3694	-> 1147
/*      */     //   #3698	-> 1165
/*      */     //   #3697	-> 1203
/*      */     //   #3698	-> 1220
/*      */     //   #3697	-> 1258
/*      */     //   #3686	-> 1403
/*      */     //   #3686	-> 1406
/*      */     //   #3703	-> 1429
/*      */     //   #3704	-> 1440
/*      */     //   #3705	-> 1480
/*      */     //   #3706	-> 1532
/*      */     //   #3707	-> 1572
/*      */     //   #3708	-> 1578
/*      */     //   #3708	-> 1636
/*      */     //   #3709	-> 1694
/*      */     //   #3708	-> 1746
/*      */     //   #3710	-> 1752
/*      */     //   #3711	-> 1803
/*      */     //   #3712	-> 1864
/*      */     //   #3713	-> 1925
/*      */     //   #3714	-> 1964
/*      */     //   #3715	-> 1974
/*      */     //   #3716	-> 1994
/*      */     //   #3719	-> 2018
/*      */     //   #3723	-> 2039
/*      */     //   #3722	-> 2077
/*      */     //   #3723	-> 2094
/*      */     //   #3722	-> 2132
/*      */     //   #3707	-> 2220
/*      */     //   #3707	-> 2223
/*      */     //   #3728	-> 2246
/*      */     //   #3729	-> 2257
/*      */     //   #3730	-> 2297
/*      */     //   #3731	-> 2351
/*      */     //   #3732	-> 2391
/*      */     //   #3733	-> 2397
/*      */     //   #3733	-> 2455
/*      */     //   #3734	-> 2513
/*      */     //   #3733	-> 2565
/*      */     //   #3734	-> 2571
/*      */     //   #3735	-> 2642
/*      */     //   #3736	-> 2703
/*      */     //   #3737	-> 2764
/*      */     //   #3738	-> 2803
/*      */     //   #3739	-> 2854
/*      */     //   #3740	-> 2918
/*      */     //   #3741	-> 2928
/*      */     //   #3742	-> 2948
/*      */     //   #3743	-> 2968
/*      */     //   #3744	-> 2989
/*      */     //   #3747	-> 3013
/*      */     //   #3748	-> 3034
/*      */     //   #3752	-> 3055
/*      */     //   #3751	-> 3093
/*      */     //   #3752	-> 3110
/*      */     //   #3751	-> 3148
/*      */     //   #3732	-> 3236
/*      */     //   #3732	-> 3239
/*      */     //   #3758	-> 3262
/*      */     //   #3759	-> 3273
/*      */     //   #3760	-> 3313
/*      */     //   #3761	-> 3386
/*      */     //   #3762	-> 3426
/*      */     //   #3763	-> 3436
/*      */     //   #3764	-> 3451
/*      */     //   #3765	-> 3466
/*      */     //   #3766	-> 3481
/*      */     //   #3767	-> 3500
/*      */     //   #3768	-> 3506
/*      */     //   #3769	-> 3567
/*      */     //   #3770	-> 3628
/*      */     //   #3770	-> 3641
/*      */     //   #3771	-> 3654
/*      */     //   #3772	-> 3693
/*      */     //   #3773	-> 3703
/*      */     //   #3774	-> 3709
/*      */     //   #3775	-> 3776
/*      */     //   #3775	-> 3787
/*      */     //   #3776	-> 3790
/*      */     //   #3773	-> 3855
/*      */     //   #3773	-> 3858
/*      */     //   #3780	-> 3878
/*      */     //   #3781	-> 3884
/*      */     //   #3782	-> 3951
/*      */     //   #3782	-> 3962
/*      */     //   #3783	-> 3965
/*      */     //   #3780	-> 4028
/*      */     //   #3780	-> 4031
/*      */     //   #3787	-> 4051
/*      */     //   #3788	-> 4057
/*      */     //   #3789	-> 4165
/*      */     //   #3788	-> 4186
/*      */     //   #3790	-> 4203
/*      */     //   #3791	-> 4311
/*      */     //   #3790	-> 4332
/*      */     //   #3787	-> 4349
/*      */     //   #3787	-> 4352
/*      */     //   #3794	-> 4372
/*      */     //   #3793	-> 4410
/*      */     //   #3794	-> 4427
/*      */     //   #3793	-> 4465
/*      */     //   #3767	-> 4523
/*      */     //   #3767	-> 4526
/*      */     //   #3797	-> 4546
/*      */     //   #3800	-> 4549
/*      */     //   #3800	-> 4560
/*      */     //   #3801	-> 4571
/*      */     //   #3802	-> 4611
/*      */     //   #3803	-> 4704
/*      */     //   #3805	-> 4735
/*      */     //   #3804	-> 4739
/*      */     //   #3804	-> 4746
/*      */     //   #3804	-> 4772
/*      */     //   #3804	-> 4795
/*      */     //   #3806	-> 4851
/*      */     //   #3806	-> 4863
/*      */     //   #3808	-> 4875
/*      */     //   #3807	-> 4879
/*      */     //   #3807	-> 4886
/*      */     //   #3807	-> 4912
/*      */     //   #3807	-> 4935
/*      */     //   #3809	-> 4991
/*      */     //   #3810	-> 5045
/*      */     //   #3811	-> 5085
/*      */     //   #3812	-> 5091
/*      */     //   #3813	-> 5152
/*      */     //   #3814	-> 5213
/*      */     //   #3814	-> 5226
/*      */     //   #3815	-> 5239
/*      */     //   #3816	-> 5290
/*      */     //   #3817	-> 5354
/*      */     //   #3818	-> 5412
/*      */     //   #3818	-> 5423
/*      */     //   #3818	-> 5486
/*      */     //   #3818	-> 5491
/*      */     //   #3819	-> 5497
/*      */     //   #3819	-> 5508
/*      */     //   #3820	-> 5519
/*      */     //   #3819	-> 5524
/*      */     //   #3820	-> 5530
/*      */     //   #3821	-> 5541
/*      */     //   #3821	-> 5551
/*      */     //   #3821	-> 5557
/*      */     //   #3821	-> 5567
/*      */     //   #3822	-> 5570
/*      */     //   #3822	-> 5580
/*      */     //   #3822	-> 5586
/*      */     //   #3822	-> 5596
/*      */     //   #3823	-> 5599
/*      */     //   #3824	-> 5638
/*      */     //   #3825	-> 5648
/*      */     //   #3826	-> 5668
/*      */     //   #3827	-> 5688
/*      */     //   #3828	-> 5709
/*      */     //   #3831	-> 5733
/*      */     //   #3832	-> 5754
/*      */     //   #3835	-> 5775
/*      */     //   #3834	-> 5813
/*      */     //   #3835	-> 5830
/*      */     //   #3834	-> 5868
/*      */     //   #3839	-> 5956
/*      */     //   #3836	-> 5994
/*      */     //   #3839	-> 6011
/*      */     //   #3836	-> 6049
/*      */     //   #3837	-> 6074
/*      */     //   #3836	-> 6097
/*      */     //   #3840	-> 6203
/*      */     //   #3841	-> 6280
/*      */     //   #3811	-> 6341
/*      */     //   #3811	-> 6344
/*      */     //   #3848	-> 6363
/*      */     //   #3849	-> 6374
/*      */     //   #3850	-> 6414
/*      */     //   #3851	-> 6421
/*      */     //   #3852	-> 6428
/*      */     //   #3853	-> 6434
/*      */     //   #3854	-> 6476
/*      */     //   #3854	-> 6489
/*      */     //   #3855	-> 6495
/*      */     //   #3855	-> 6508
/*      */     //   #3852	-> 6514
/*      */     //   #3852	-> 6517
/*      */     //   #3857	-> 6533
/*      */     //   #3857	-> 6545
/*      */     //   #3858	-> 6557
/*      */     //   #3859	-> 6597
/*      */     //   #3860	-> 6647
/*      */     //   #3861	-> 6687
/*      */     //   #3862	-> 6693
/*      */     //   #3863	-> 6734
/*      */     //   #3864	-> 6775
/*      */     //   #3864	-> 6788
/*      */     //   #3865	-> 6801
/*      */     //   #3866	-> 6836
/*      */     //   #3867	-> 6880
/*      */     //   #3868	-> 6922
/*      */     //   #3869	-> 6964
/*      */     //   #3870	-> 7006
/*      */     //   #3870	-> 7017
/*      */     //   #3871	-> 7028
/*      */     //   #3870	-> 7033
/*      */     //   #3871	-> 7039
/*      */     //   #3871	-> 7050
/*      */     //   #3872	-> 7061
/*      */     //   #3873	-> 7100
/*      */     //   #3874	-> 7110
/*      */     //   #3875	-> 7126
/*      */     //   #3876	-> 7142
/*      */     //   #3877	-> 7158
/*      */     //   #3878	-> 7174
/*      */     //   #3879	-> 7191
/*      */     //   #3880	-> 7208
/*      */     //   #3881	-> 7225
/*      */     //   #3884	-> 7245
/*      */     //   #3885	-> 7262
/*      */     //   #3886	-> 7279
/*      */     //   #3887	-> 7296
/*      */     //   #3889	-> 7313
/*      */     //   #3890	-> 7321
/*      */     //   #3891	-> 7329
/*      */     //   #3894	-> 7370
/*      */     //   #3893	-> 7396
/*      */     //   #3894	-> 7407
/*      */     //   #3893	-> 7433
/*      */     //   #3896	-> 7499
/*      */     //   #3898	-> 7532
/*      */     //   #3900	-> 7580
/*      */     //   #3861	-> 7628
/*      */     //   #3861	-> 7631
/*      */     //   #3906	-> 7650
/*      */     //   #3908	-> 7690
/*      */     //   #3909	-> 7701
/*      */     //   #3910	-> 7711
/*      */     //   #3911	-> 7711
/*      */     //   #0	-> 7714
/*      */     //   #3911	-> 7714
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	7715	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	1	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	2	dd$offset	I
/*      */     //   0	7715	3	vmax	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	4	vmax$offset	I
/*      */     //   0	7715	5	yp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	6	yp$offset	I
/*      */     //   0	7715	7	xp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	8	xp$offset	I
/*      */     //   0	7715	9	pp	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	10	pp$offset	I
/*      */     //   0	7715	11	p4	D
/*      */     //   0	7715	13	p3	D
/*      */     //   0	7715	15	p2	D
/*      */     //   0	7715	17	p1	D
/*      */     //   0	7715	19	p0	D
/*      */     //   0	7715	21	yy	[D
/*      */     //   0	7715	22	xx	[D
/*      */     //   0	7715	23	ry	D
/*      */     //   0	7715	25	rx	D
/*      */     //   0	7715	27	inches	D
/*      */     //   0	7715	29	pmin	[D
/*      */     //   0	7715	30	pmax	[D
/*      */     //   0	7715	31	type	I
/*      */     //   0	7715	32	nfg	I
/*      */     //   0	7715	33	nbg	I
/*      */     //   0	7715	34	nc	[I
/*      */     //   0	7715	35	nr	[I
/*      */     //   0	7715	36	j	I
/*      */     //   0	7715	37	i	I
/*      */     //   0	7715	38	bg	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	39	fg	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	40	p	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	41	y	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	42	x	Lorg/renjin/sexp/SEXP;
/*      */     //   0	7715	46	nr$201	I
/*      */     //   0	7715	47	xx$200	D
/*      */     //   0	7715	51	yy$199	D
/*      */     //   0	7715	53	xx$198	D
/*      */     //   0	7715	59	yy$197	D
/*      */     //   0	7715	61	xx$196	D
/*      */     //   0	7715	65	yy$195	D
/*      */     //   0	7715	67	xx$194	D
/*      */     //   0	7715	73	yy$193	D
/*      */     //   0	7715	77	xx$192	D
/*      */     //   0	7715	81	xx$191	D
/*      */     //   0	7715	85	xx$190	D
/*      */     //   0	7715	89	yy$189	D
/*      */     //   0	7715	93	xx$188	D
/*      */     //   0	7715	97	yy$187	D
/*      */     //   0	7715	119	yy$186	D
/*      */     //   0	7715	125	yy$185	D
/*      */     //   0	7715	131	pmax$184	D
/*      */     //   0	7715	135	pmax$183	D
/*      */     //   0	7715	139	pmax$182	D
/*      */     //   0	7715	143	pmax$181	D
/*      */     //   0	7715	156	nr$180	I
/*      */     //   0	7715	165	nr$179	I
/*      */     //   0	7715	174	nr$178	I
/*      */     //   0	7715	182	nr$177	I
/*      */     //   0	7715	188	i$176	I
/*      */     //   0	7715	192	yy$175	D
/*      */     //   0	7715	195	xx$174	D
/*      */     //   0	7715	197	yy$173	D
/*      */     //   0	7715	202	i$172	I
/*      */     //   0	7715	205	xx$171	D
/*      */     //   0	7715	210	i$170	I
/*      */     //   0	7715	219	nr$169	I
/*      */     //   0	7715	222	pmax$168	D
/*      */     //   0	7715	224	pmin$167	D
/*      */     //   0	7715	226	nr$166	I
/*      */     //   0	7715	227	pmin$165	D
/*      */     //   0	7715	229	pmax$164	D
/*      */     //   0	7715	237	nr$163	I
/*      */     //   0	7715	242	nc$162	I
/*      */     //   0	7715	243	nr$161	I
/*      */     //   0	7715	246	xx$160	D
/*      */     //   0	7715	248	yy$159	D
/*      */     //   0	7715	252	xx$158	D
/*      */     //   0	7715	256	yy$157	D
/*      */     //   0	7715	260	xx$156	D
/*      */     //   0	7715	262	yy$155	D
/*      */     //   0	7715	268	xx$154	D
/*      */     //   0	7715	270	yy$153	D
/*      */     //   0	7715	274	xx$152	D
/*      */     //   0	7715	284	yy$151	D
/*      */     //   0	7715	288	xx$150	D
/*      */     //   0	7715	298	yy$149	D
/*      */     //   0	7715	318	xx$148	D
/*      */     //   0	7715	322	yy$147	D
/*      */     //   0	7715	326	xx$146	D
/*      */     //   0	7715	330	yy$145	D
/*      */     //   0	7715	358	pmax$144	D
/*      */     //   0	7715	362	pmax$143	D
/*      */     //   0	7715	374	nr$142	I
/*      */     //   0	7715	377	nc$141	I
/*      */     //   0	7715	378	iftmp$140	D
/*      */     //   0	7715	386	nr$139	I
/*      */     //   0	7715	394	nr$138	I
/*      */     //   0	7715	400	i$137	I
/*      */     //   0	7715	404	yy$136	D
/*      */     //   0	7715	407	xx$135	D
/*      */     //   0	7715	409	yy$134	D
/*      */     //   0	7715	414	i$133	I
/*      */     //   0	7715	417	xx$132	D
/*      */     //   0	7715	422	i$131	I
/*      */     //   0	7715	431	nr$130	I
/*      */     //   0	7715	434	nc$129	I
/*      */     //   0	7715	435	iftmp$128	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	436	iftmp$128$offset	I
/*      */     //   0	7715	437	pmax$127	D
/*      */     //   0	7715	439	pmin$126	D
/*      */     //   0	7715	443	nc$125	I
/*      */     //   0	7715	444	iftmp$124	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	7715	445	iftmp$124$offset	I
/*      */     //   0	7715	446	pmin$123	D
/*      */     //   0	7715	448	pmax$122	D
/*      */     //   0	7715	454	nr$121	I
/*      */     //   0	7715	457	nr$120	I
/*      */     //   0	7715	460	nc$119	I
/*      */     //   0	7715	461	nc$118	I
/*      */     //   0	7715	462	nr$117	I
/*      */     //   0	7715	463	nc$116	I
/*      */     //   0	7715	480	nc$115	I
/*      */     //   0	7715	483	yy$114	D
/*      */     //   0	7715	500	j$113	I
/*      */     //   0	7715	504	j$112	I
/*      */     //   0	7715	507	xx$111	D
/*      */     //   0	7715	524	j$110	I
/*      */     //   0	7715	528	j$109	I
/*      */     //   0	7715	529	nc$108	I
/*      */     //   0	7715	535	j$107	I
/*      */     //   0	7715	543	nr$106	I
/*      */     //   0	7715	546	nc$105	I
/*      */     //   0	7715	551	pmax$104	D
/*      */     //   0	7715	556	j$103	I
/*      */     //   0	7715	564	nr$102	I
/*      */     //   0	7715	568	yy$101	D
/*      */     //   0	7715	571	xx$100	D
/*      */     //   0	7715	573	yy$99	D
/*      */     //   0	7715	578	i$98	I
/*      */     //   0	7715	581	xx$97	D
/*      */     //   0	7715	586	i$96	I
/*      */     //   0	7715	591	nc$95	I
/*      */     //   0	7715	593	nc$94	I
/*      */     //   0	7715	594	nc$93	I
/*      */     //   0	7715	596	nc$92	I
/*      */     //   0	7715	597	nc$91	I
/*      */     //   0	7715	599	nc$90	I
/*      */     //   0	7715	600	nc$89	I
/*      */     //   0	7715	607	nr$88	I
/*      */     //   0	7715	608	nc$87	I
/*      */     //   0	7715	611	nc$86	I
/*      */     //   0	7715	612	nr$85	I
/*      */     //   0	7715	615	xx$84	D
/*      */     //   0	7715	619	yy$83	D
/*      */     //   0	7715	623	xx$82	D
/*      */     //   0	7715	627	yy$81	D
/*      */     //   0	7715	655	pmax$80	D
/*      */     //   0	7715	659	pmax$79	D
/*      */     //   0	7715	666	nr$78	I
/*      */     //   0	7715	672	i$77	I
/*      */     //   0	7715	675	yy$76	D
/*      */     //   0	7715	680	i$75	I
/*      */     //   0	7715	683	xx$74	D
/*      */     //   0	7715	688	i$73	I
/*      */     //   0	7715	699	nr$72	I
/*      */     //   0	7715	708	i$71	I
/*      */     //   0	7715	717	i$70	I
/*      */     //   0	7715	726	i$69	I
/*      */     //   0	7715	735	nr$68	I
/*      */     //   0	7715	738	nc$67	I
/*      */     //   0	7715	739	nr$66	I
/*      */     //   0	7715	742	xx$65	D
/*      */     //   0	7715	746	yy$64	D
/*      */     //   0	7715	750	xx$63	D
/*      */     //   0	7715	754	yy$62	D
/*      */     //   0	7715	778	pmax$61	D
/*      */     //   0	7715	780	yy$60	D
/*      */     //   0	7715	785	i$59	I
/*      */     //   0	7715	788	xx$58	D
/*      */     //   0	7715	793	i$57	I
/*      */     //   0	7715	799	i$56	I
/*      */     //   0	7715	808	i$55	I
/*      */     //   0	7715	817	i$54	I
/*      */     //   0	7715	826	i$53	I
/*      */     //   0	7715	834	nr$52	I
/*      */     //   0	7715	837	nc$51	I
/*      */     //   0	7715	838	nr$50	I
/*      */     //   0	7715	844	i$49	I
/*      */     //   0	7715	852	i$48	I
/*      */     //   0	7715	873	pmax$47	D
/*      */     //   0	7715	878	i$46	I
/*      */     //   0	7715	887	i$45	I
/*      */     //   0	7715	896	i$44	I
/*      */     //   0	7715	905	i$43	I
/*      */     //   0	7715	913	nr$42	I
/*      */     //   0	7715	916	nc$41	I
/*      */     //   0	7715	923	nr$40	I
/*      */     //   0	7715	925	nr$39	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_xspline(SEXP args) {
/* 3916 */     MixedPtr mixedPtr = MixedPtr.malloc(276); y0 = BytePtr.of(0); y0$offset = 0; x0 = BytePtr.of(0); x0$offset = 0; yy = BytePtr.of(0); yy$offset = 0; xx = BytePtr.of(0); xx$offset = 0; tmpy = (SEXP)BytePtr.of(0).getArray(); tmpx = (SEXP)BytePtr.of(0).getArray(); dd = BytePtr.of(0); dd$offset = 0; vmaxsave = BytePtr.of(0); vmaxsave$offset = 0; ptr1 = BytePtr.of(0); j = 0; ptr2 = BytePtr.of(0); k = 0; draw = 0; repEnds = 0; open = 0; y = BytePtr.of(0); y$offset = 0; x = BytePtr.of(0); x$offset = 0; nx = 0; ans = (SEXP)BytePtr.of(0).getArray(); border = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); ss = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3926 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/* 3928 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/* 3929 */     args = Rinternals.CDR(args);
/*      */     
/* 3931 */     if (Rinternals.Rf_length(args) <= 5) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]);
/*      */     
/* 3933 */     SEXP sEXP3 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sx = Rinternals.SETCAR(args, sEXP3); args = Rinternals.CDR(args);
/* 3934 */     SEXP sEXP2 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); sy = Rinternals.SETCAR(args, sEXP2); args = Rinternals.CDR(args);
/* 3935 */     nx = Rinternals.LENGTH(sx);
/* 3936 */     SEXP sEXP1 = Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14); ss = Rinternals.SETCAR(args, sEXP1); args = Rinternals.CDR(args);
/* 3937 */     open = Rinternals.Rf_asLogical(Rinternals.CAR(args)); args = Rinternals.CDR(args);
/* 3938 */     repEnds = Rinternals.Rf_asLogical(Rinternals.CAR(args)); args = Rinternals.CDR(args);
/* 3939 */     draw = Rinternals.Rf_asLogical(Rinternals.CAR(args)); args = Rinternals.CDR(args);
/*      */     
/* 3941 */     col = Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(col); args = Rinternals.CDR(args);
/* 3942 */     ncol = Rinternals.LENGTH(col);
/* 3943 */     if (ncol <= 0)
/* 3944 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("incorrect length for '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("col\000".getBytes(), 0) }); 
/* 3945 */     if (ncol > 1) {
/* 3946 */       Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("incorrect length for '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("col\000".getBytes(), 0) });
/*      */     }
/* 3948 */     int i1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(76); border = Rf_FixupCol(Rinternals.CAR(args), i1); Rinternals.Rf_protect(border); args = Rinternals.CDR(args);
/* 3949 */     nborder = Rinternals.LENGTH(border);
/* 3950 */     if (nborder <= 0)
/* 3951 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("incorrect length for '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("border\000".getBytes(), 0) }); 
/* 3952 */     if (nborder > 1) {
/* 3953 */       Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("incorrect length for '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("border\000".getBytes(), 0) });
/*      */     }
/* 3955 */     graphics__.Rf_GSavePars(dd.pointerPlus(dd$offset));
/* 3956 */     par__.Rf_ProcessInlinePars(args, dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */     
/* 3960 */     graphics__.gcontextFromGP((Ptr)mixedPtr, dd.pointerPlus(dd$offset));
/*      */     
/* 3962 */     graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/*      */     
/* 3964 */     x = Rinternals2.REAL(sx); x$offset = 0;
/* 3965 */     y = Rinternals2.REAL(sy); y$offset = 0;
/* 3966 */     vmaxsave = VoidPtr.toPtr(Memory.vmaxget()); vmaxsave$offset = 0;
/* 3967 */     DoublePtr doublePtr2 = DoublePtr.malloc(nx * 8); k = 0;
/* 3968 */     DoublePtr doublePtr1 = DoublePtr.malloc(nx * 8); j = 0;
/* 3969 */     if (doublePtr2.pointerPlus(k).isNull() || doublePtr1.pointerPlus(j).isNull())
/* 3970 */       Error.Rf_error(new BytePtr("unable to allocate memory (in xspline)\000".getBytes(), 0), new Object[0]); 
/* 3971 */     for (i = 0; i < nx; i++) {
/* 3972 */       int i13 = i * 8; DoublePtr doublePtr6 = doublePtr2; int i12 = k + i13, i11 = i * 8; Ptr ptr4 = x; int i10 = x$offset + i11; double d2 = ptr4.getDouble(i10); doublePtr6.setDouble(i12, d2);
/* 3973 */       int i9 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i8 = j + i9, i7 = i * 8; Ptr ptr3 = y; int i6 = y$offset + i7; double d1 = ptr3.getDouble(i6); doublePtr5.setDouble(i8, d1);
/* 3974 */       int i5 = i * 8; DoublePtr doublePtr4 = doublePtr1; int i4 = j + i5, i3 = i * 8; DoublePtr doublePtr3 = doublePtr2; int i2 = k + i3; graphics__.Rf_GConvert(doublePtr3.pointerPlus(i2), doublePtr4.pointerPlus(i4), 12, 0, dd.pointerPlus(dd$offset));
/*      */     } 
/* 3976 */     graphics__.Rf_GClip(dd.pointerPlus(dd$offset));
/* 3977 */     int n = Rinternals2.INTEGER(border).getInt(); mixedPtr.setInt(n);
/* 3978 */     int m = Rinternals2.INTEGER(col).getInt(); mixedPtr.setAlignedInt(1, m);
/* 3979 */     Ptr ptr = Rinternals2.REAL(ss); res = baseEngine__.GEXspline(nx, doublePtr2.pointerPlus(k), doublePtr1.pointerPlus(j), ptr, open, repEnds, draw, (Ptr)mixedPtr, dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */     
/* 3983 */     if (draw == 0) {
/*      */ 
/*      */       
/* 3986 */       ans = res; Rinternals.Rf_protect(ans);
/* 3987 */       nm = Rinternals.Rf_allocVector(16, 2); Rinternals.Rf_protect(nm);
/* 3988 */       SEXP sEXP5 = Rinternals.Rf_mkChar((Ptr)new BytePtr("x\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(nm, 0, sEXP5);
/* 3989 */       SEXP sEXP4 = Rinternals.Rf_mkChar((Ptr)new BytePtr("y\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(nm, 1, sEXP4);
/* 3990 */       R_NamesSymbol$32 = Rinternals.R_NamesSymbol; Rinternals.Rf_setAttrib(ans, R_NamesSymbol$32, nm);
/* 3991 */       nx = Rinternals.LENGTH(Rinternals.VECTOR_ELT(ans, 0));
/* 3992 */       x0 = Rinternals2.REAL(Rinternals.VECTOR_ELT(ans, 0)); x0$offset = 0;
/* 3993 */       y0 = Rinternals2.REAL(Rinternals.VECTOR_ELT(ans, 1)); y0$offset = 0;
/* 3994 */       tmpx = Rinternals.Rf_allocVector(14, nx); Rinternals.Rf_protect(tmpx);
/* 3995 */       tmpy = Rinternals.Rf_allocVector(14, nx); Rinternals.Rf_protect(tmpy);
/* 3996 */       xx = Rinternals2.REAL(tmpx); xx$offset = 0;
/* 3997 */       yy = Rinternals2.REAL(tmpy); yy$offset = 0;
/* 3998 */       for (i = 0; i < nx; i++) {
/* 3999 */         int i13 = i * 8; Ptr ptr8 = xx; int i12 = xx$offset + i13, i11 = i * 8; Ptr ptr7 = x0; int i10 = x0$offset + i11; double d2 = ptr7.getDouble(i10); ptr8.setDouble(i12, d2);
/* 4000 */         int i9 = i * 8; Ptr ptr6 = yy; int i8 = yy$offset + i9, i7 = i * 8; Ptr ptr5 = y0; int i6 = y0$offset + i7; double d1 = ptr5.getDouble(i6); ptr6.setDouble(i8, d1);
/* 4001 */         int i5 = i * 8; Ptr ptr4 = yy; int i4 = yy$offset + i5, i3 = i * 8; Ptr ptr3 = xx; int i2 = xx$offset + i3; graphics__.Rf_GConvert(ptr3.pointerPlus(i2), ptr4.pointerPlus(i4), 0, 12, dd.pointerPlus(dd$offset));
/*      */       } 
/* 4003 */       Rinternals.SET_VECTOR_ELT(ans, 0, tmpx);
/* 4004 */       Rinternals.SET_VECTOR_ELT(ans, 1, tmpy);
/*      */     } 
/*      */ 
/*      */     
/* 4008 */     graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/* 4009 */     graphics__.Rf_GRestorePars(dd.pointerPlus(dd$offset));
/* 4010 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_clip(SEXP args) {
/* 4016 */     y2 = new double[1]; y1 = new double[1]; x2 = new double[1]; x1 = new double[1]; ans = Rinternals.R_NilValue;
/*      */     
/* 4018 */     dd = baseDevices__.GEcurrentDevice();
/*      */     
/* 4020 */     args = Rinternals.CDR(args);
/* 4021 */     x1$12 = Rinternals.Rf_asReal(Rinternals.CAR(args)); x1[0] = x1$12;
/* 4022 */     if (Arith.R_finite(x1[0]) == 0) Error.Rf_error(new BytePtr("invalid '%s' argument\000".getBytes(), 0), new Object[] { new BytePtr("x1\000".getBytes(), 0) }); 
/* 4023 */     args = Rinternals.CDR(args);
/* 4024 */     x2$14 = Rinternals.Rf_asReal(Rinternals.CAR(args)); x2[0] = x2$14;
/* 4025 */     if (Arith.R_finite(x2[0]) == 0) Error.Rf_error(new BytePtr("invalid '%s' argument\000".getBytes(), 0), new Object[] { new BytePtr("x2\000".getBytes(), 0) }); 
/* 4026 */     args = Rinternals.CDR(args);
/* 4027 */     y1$16 = Rinternals.Rf_asReal(Rinternals.CAR(args)); y1[0] = y1$16;
/* 4028 */     if (Arith.R_finite(y1[0]) == 0) Error.Rf_error(new BytePtr("invalid '%s' argument\000".getBytes(), 0), new Object[] { new BytePtr("y1\000".getBytes(), 0) }); 
/* 4029 */     args = Rinternals.CDR(args);
/* 4030 */     y2$18 = Rinternals.Rf_asReal(Rinternals.CAR(args)); y2[0] = y2$18;
/* 4031 */     if (Arith.R_finite(y2[0]) == 0) Error.Rf_error(new BytePtr("invalid '%s' argument\000".getBytes(), 0), new Object[] { new BytePtr("y2\000".getBytes(), 0) });
/*      */     
/* 4033 */     graphics__.Rf_GConvert((Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y1, 0), 12, 0, dd);
/* 4034 */     graphics__.Rf_GConvert((Ptr)new DoublePtr(x2, 0), (Ptr)new DoublePtr(y2, 0), 12, 0, dd);
/* 4035 */     y2$20 = y2[0]; x2$21 = x2[0]; y1$22 = y1[0]; baseEngine__.GESetClip(x1[0], y1$22, x2$21, y2$20, dd);
/*      */     
/* 4037 */     Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(444); ptr.setInt(448, i);
/* 4038 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_convertX(SEXP args) {
/* 4044 */     gdd = BytePtr.of(0); gdd$offset = 0; rx = BytePtr.of(0); rx$offset = 0; n = 0; to = 0; from = 0; ans = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue;
/*      */ 
/*      */     
/* 4047 */     gdd = baseDevices__.GEcurrentDevice(); gdd$offset = 0;
/*      */     
/* 4049 */     args = Rinternals.CDR(args);
/* 4050 */     x = Rinternals.CAR(args);
/* 4051 */     if (Rinternals.TYPEOF(x) != 14) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("x\000".getBytes(), 0) }); 
/* 4052 */     n = Rinternals.LENGTH(x);
/* 4053 */     from = Rinternals.Rf_asInteger(Rinternals.CADR(args));
/* 4054 */     R_NaInt$6 = Arith.R_NaInt; if (from == R_NaInt$6 || from <= 0 || from > 17)
/* 4055 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("from\000".getBytes(), 0) }); 
/* 4056 */     to = Rinternals.Rf_asInteger(Rinternals.CADDR(args));
/* 4057 */     R_NaInt$7 = Arith.R_NaInt; if (to == R_NaInt$7 || to <= 0 || to > 17)
/* 4058 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("to\000".getBytes(), 0) }); 
/* 4059 */     from--; to--;
/*      */     
/* 4061 */     ans = Rinternals.Rf_duplicate(x); Rinternals.Rf_protect(ans);
/* 4062 */     rx = Rinternals2.REAL(ans); rx$offset = 0;
/* 4063 */     for (i = 0; i < n; ) { int i1 = i * 8; Ptr ptr2 = rx; int m = rx$offset + i1; to$9 = to; from$10 = from; int k = i * 8; Ptr ptr1 = rx; int j = rx$offset + k; double d = graphics__.Rf_GConvertX(ptr1.getDouble(j), from$10, to$9, gdd.pointerPlus(gdd$offset)); ptr2.setDouble(m, d); i++; }
/*      */ 
/*      */     
/* 4066 */     return ans;
/*      */   }
/*      */ 
/*      */   
/*      */   public static SEXP C_convertY(SEXP args) {
/* 4071 */     gdd = BytePtr.of(0); gdd$offset = 0; rx = BytePtr.of(0); rx$offset = 0; n = 0; to = 0; from = 0; ans = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue;
/*      */ 
/*      */     
/* 4074 */     gdd = baseDevices__.GEcurrentDevice(); gdd$offset = 0;
/*      */     
/* 4076 */     args = Rinternals.CDR(args);
/* 4077 */     x = Rinternals.CAR(args);
/* 4078 */     if (Rinternals.TYPEOF(x) != 14) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("x\000".getBytes(), 0) }); 
/* 4079 */     n = Rinternals.LENGTH(x);
/* 4080 */     from = Rinternals.Rf_asInteger(Rinternals.CADR(args));
/* 4081 */     R_NaInt$0 = Arith.R_NaInt; if (from == R_NaInt$0 || from <= 0 || from > 17)
/* 4082 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("from\000".getBytes(), 0) }); 
/* 4083 */     to = Rinternals.Rf_asInteger(Rinternals.CADDR(args));
/* 4084 */     R_NaInt$1 = Arith.R_NaInt; if (to == R_NaInt$1 || to <= 0 || to > 17)
/* 4085 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("to\000".getBytes(), 0) }); 
/* 4086 */     from--; to--;
/*      */     
/* 4088 */     ans = Rinternals.Rf_duplicate(x); Rinternals.Rf_protect(ans);
/* 4089 */     rx = Rinternals2.REAL(ans); rx$offset = 0;
/* 4090 */     for (i = 0; i < n; ) { int i1 = i * 8; Ptr ptr2 = rx; int m = rx$offset + i1; to$3 = to; from$4 = from; int k = i * 8; Ptr ptr1 = rx; int j = rx$offset + k; double d = graphics__.Rf_GConvertY(ptr1.getDouble(j), from$4, to$3, gdd.pointerPlus(gdd$offset)); ptr2.setDouble(m, d); i++; }
/*      */ 
/*      */     
/* 4093 */     return ans;
/*      */   }
/*      */   
/*      */   static {
/*      */   
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/plot__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */