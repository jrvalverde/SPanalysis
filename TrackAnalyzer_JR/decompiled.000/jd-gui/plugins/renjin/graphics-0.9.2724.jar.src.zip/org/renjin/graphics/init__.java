/*    */ package org.renjin.graphics;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gnur.api.Rdynload;
/*    */ import org.renjin.primitives.packaging.DllInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class init__
/*    */ {
/*    */   public static void R_init_graphics(DllInfo dll) {
/* 87 */     Rdynload.R_registerRoutines(dll, BytePtr.of(0), Context.get__init$CallEntries(), BytePtr.of(0), Context.get__init$ExtEntries());
/* 88 */     Rdynload.R_useDynamicSymbols(dll, false);
/* 89 */     Rdynload.R_forceSymbols(dll, true);
/* 90 */     base__.registerBase();
/*    */   }
/*    */   
/*    */   static {
/*    */   
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/init__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */