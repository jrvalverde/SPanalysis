/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.VoidPtr;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.GetText;
/*      */ import org.renjin.gnur.api.Memory;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.grDevices.baseDevices__;
/*      */ import org.renjin.grDevices.baseEngine__;
/*      */ import org.renjin.grDevices.colors__;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class par__
/*      */ {
/*      */   static {
/*      */   
/*      */   }
/*      */   
/*      */   public static int ParCode(Ptr what) {
/*      */     byte b;
/*  152 */     i = 0; while (true) { if (!Context.get__par$ParTable().getPointer(i * 8).isNull()) {
/*  153 */         Ptr ptr = Context.get__par$ParTable().getPointer(i * 8); if (Stdlib.strcmp(what, ptr) != 0) { i++; continue; }  int j = Context.get__par$ParTable().getInt(i * 8 + 4); break;
/*  154 */       }  b = -1;
/*      */       break; }
/*      */     
/*      */     return b;
/*      */   }
/*      */   public static void par_error(Ptr what) {
/*  160 */     Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid value specified for graphical parameter \"%s\"\000".getBytes(), 0)), new Object[] { what });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void lengthCheck(Ptr what, SEXP v, int n) {
/*  166 */     if (Rinternals.Rf_length(v) != n) {
/*  167 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("graphical parameter \"%s\" has the wrong length\000".getBytes(), 0)), new Object[] { what });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static void nonnegIntCheck(int x, Ptr s) {
/*  173 */     R_NaInt$43 = Arith.R_NaInt; if (x == R_NaInt$43 || x < 0) {
/*  174 */       par_error(s);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void posIntCheck(int x, Ptr s) {
/*  179 */     R_NaInt$42 = Arith.R_NaInt; if (x == R_NaInt$42 || x <= 0) {
/*  180 */       par_error(s);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void posRealCheck(double x, Ptr s) {
/*  185 */     if (Arith.R_finite(x) == 0 || x <= 0.0D) {
/*  186 */       par_error(s);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void nonnegRealCheck(double x, Ptr s) {
/*  191 */     if (Arith.R_finite(x) == 0 || x < 0.0D) {
/*  192 */       par_error(s);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void naRealCheck(double x, Ptr s) {
/*  197 */     if (Arith.R_finite(x) == 0) {
/*  198 */       par_error(s);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void logAxpCheck(int x, Ptr s) {
/*  203 */     R_NaInt$41 = Arith.R_NaInt; if (x == R_NaInt$41 || x == 0 || x > 4) {
/*  204 */       par_error(s);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void BoundsCheck(double x, double a, double b, Ptr s) {
/*  211 */     if (Arith.R_finite(x) == 0 || (Arith.R_finite(a) != 0 && x < a) || (Arith.R_finite(b) != 0 && x > b)) {
/*  212 */       par_error(s);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Specify(Ptr what, SEXP value, Ptr dd) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #17
/*      */     //   3: iconst_0
/*      */     //   4: i2b
/*      */     //   5: istore #16
/*      */     //   7: aload_0
/*      */     //   8: invokestatic ParCode : (Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   11: iconst_2
/*      */     //   12: if_icmpeq -> 18
/*      */     //   15: goto -> 65
/*      */     //   18: new org/renjin/gcc/runtime/BytePtr
/*      */     //   21: dup
/*      */     //   22: ldc 'graphics '
/*      */     //   24: invokevirtual getBytes : ()[B
/*      */     //   27: iconst_0
/*      */     //   28: invokespecial <init> : ([BI)V
/*      */     //   31: new org/renjin/gcc/runtime/BytePtr
/*      */     //   34: dup
/*      */     //   35: ldc_w 'graphical parameter "%s" cannot be set '
/*      */     //   38: invokevirtual getBytes : ()[B
/*      */     //   41: iconst_0
/*      */     //   42: invokespecial <init> : ([BI)V
/*      */     //   45: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   48: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   51: iconst_1
/*      */     //   52: anewarray java/lang/Object
/*      */     //   55: dup
/*      */     //   56: iconst_0
/*      */     //   57: aload_0
/*      */     //   58: aastore
/*      */     //   59: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   62: goto -> 19275
/*      */     //   65: aload_0
/*      */     //   66: new org/renjin/gcc/runtime/BytePtr
/*      */     //   69: dup
/*      */     //   70: ldc_w 'adj '
/*      */     //   73: invokevirtual getBytes : ()[B
/*      */     //   76: iconst_0
/*      */     //   77: invokespecial <init> : ([BI)V
/*      */     //   80: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   83: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   86: ifeq -> 92
/*      */     //   89: goto -> 174
/*      */     //   92: aload_0
/*      */     //   93: aload_1
/*      */     //   94: iconst_1
/*      */     //   95: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   98: aload_1
/*      */     //   99: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   102: dstore #18
/*      */     //   104: dload #18
/*      */     //   106: dconst_0
/*      */     //   107: dconst_1
/*      */     //   108: aload_0
/*      */     //   109: invokestatic BoundsCheck : (DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   112: aload_2
/*      */     //   113: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   116: wide astore #1953
/*      */     //   120: aload_2
/*      */     //   121: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   124: wide astore #1951
/*      */     //   128: wide aload #1951
/*      */     //   132: bipush #8
/*      */     //   134: dload #18
/*      */     //   136: invokeinterface setDouble : (ID)V
/*      */     //   141: wide aload #1951
/*      */     //   145: bipush #8
/*      */     //   147: invokeinterface getDouble : (I)D
/*      */     //   152: wide dstore #1949
/*      */     //   156: wide aload #1953
/*      */     //   160: bipush #8
/*      */     //   162: wide dload #1949
/*      */     //   166: invokeinterface setDouble : (ID)V
/*      */     //   171: goto -> 19275
/*      */     //   174: aload_0
/*      */     //   175: new org/renjin/gcc/runtime/BytePtr
/*      */     //   178: dup
/*      */     //   179: ldc_w 'ann '
/*      */     //   182: invokevirtual getBytes : ()[B
/*      */     //   185: iconst_0
/*      */     //   186: invokespecial <init> : ([BI)V
/*      */     //   189: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   192: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   195: ifeq -> 201
/*      */     //   198: goto -> 294
/*      */     //   201: aload_0
/*      */     //   202: aload_1
/*      */     //   203: iconst_1
/*      */     //   204: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   207: aload_1
/*      */     //   208: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   211: istore #17
/*      */     //   213: aload_2
/*      */     //   214: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   217: wide astore #1946
/*      */     //   221: aload_2
/*      */     //   222: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   225: wide astore #1944
/*      */     //   229: iload #17
/*      */     //   231: ifne -> 241
/*      */     //   234: goto -> 237
/*      */     //   237: iconst_0
/*      */     //   238: goto -> 242
/*      */     //   241: iconst_1
/*      */     //   242: wide istore #1942
/*      */     //   246: wide aload #1944
/*      */     //   250: bipush #16
/*      */     //   252: wide iload #1942
/*      */     //   256: invokeinterface setInt : (II)V
/*      */     //   261: wide aload #1944
/*      */     //   265: bipush #16
/*      */     //   267: invokeinterface getInt : (I)I
/*      */     //   272: wide istore #1941
/*      */     //   276: wide aload #1946
/*      */     //   280: bipush #16
/*      */     //   282: wide iload #1941
/*      */     //   286: invokeinterface setInt : (II)V
/*      */     //   291: goto -> 19275
/*      */     //   294: aload_0
/*      */     //   295: new org/renjin/gcc/runtime/BytePtr
/*      */     //   298: dup
/*      */     //   299: ldc_w 'bg '
/*      */     //   302: invokevirtual getBytes : ()[B
/*      */     //   305: iconst_0
/*      */     //   306: invokespecial <init> : ([BI)V
/*      */     //   309: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   312: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   315: ifeq -> 321
/*      */     //   318: goto -> 486
/*      */     //   321: aload_0
/*      */     //   322: aload_1
/*      */     //   323: iconst_1
/*      */     //   324: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   327: aload_2
/*      */     //   328: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   331: wide astore #1938
/*      */     //   335: aload_2
/*      */     //   336: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   339: wide astore #1936
/*      */     //   343: aload_2
/*      */     //   344: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   347: bipush #20
/*      */     //   349: invokeinterface getInt : (I)I
/*      */     //   354: wide istore #1933
/*      */     //   358: aload_1
/*      */     //   359: iconst_0
/*      */     //   360: wide iload #1933
/*      */     //   364: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   367: wide istore #1932
/*      */     //   371: wide aload #1936
/*      */     //   375: bipush #20
/*      */     //   377: wide iload #1932
/*      */     //   381: invokeinterface setInt : (II)V
/*      */     //   386: wide aload #1936
/*      */     //   390: bipush #20
/*      */     //   392: invokeinterface getInt : (I)I
/*      */     //   397: wide istore #1931
/*      */     //   401: wide aload #1938
/*      */     //   405: bipush #20
/*      */     //   407: wide iload #1931
/*      */     //   411: invokeinterface setInt : (II)V
/*      */     //   416: aload_2
/*      */     //   417: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   420: wide astore #1929
/*      */     //   424: aload_2
/*      */     //   425: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   428: wide astore #1927
/*      */     //   432: wide aload #1927
/*      */     //   436: iconst_0
/*      */     //   437: ldc_w 35764
/*      */     //   440: iadd
/*      */     //   441: iconst_0
/*      */     //   442: invokeinterface setInt : (II)V
/*      */     //   447: wide aload #1927
/*      */     //   451: iconst_0
/*      */     //   452: ldc_w 35764
/*      */     //   455: iadd
/*      */     //   456: invokeinterface getInt : (I)I
/*      */     //   461: wide istore #1926
/*      */     //   465: wide aload #1929
/*      */     //   469: iconst_0
/*      */     //   470: ldc_w 35764
/*      */     //   473: iadd
/*      */     //   474: wide iload #1926
/*      */     //   478: invokeinterface setInt : (II)V
/*      */     //   483: goto -> 19275
/*      */     //   486: aload_0
/*      */     //   487: new org/renjin/gcc/runtime/BytePtr
/*      */     //   490: dup
/*      */     //   491: ldc_w 'bty '
/*      */     //   494: invokevirtual getBytes : ()[B
/*      */     //   497: iconst_0
/*      */     //   498: invokespecial <init> : ([BI)V
/*      */     //   501: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   504: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   507: ifeq -> 513
/*      */     //   510: goto -> 729
/*      */     //   513: aload_0
/*      */     //   514: aload_1
/*      */     //   515: iconst_1
/*      */     //   516: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   519: aload_1
/*      */     //   520: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   523: bipush #16
/*      */     //   525: if_icmpne -> 531
/*      */     //   528: goto -> 535
/*      */     //   531: aload_0
/*      */     //   532: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   535: aload_1
/*      */     //   536: iconst_0
/*      */     //   537: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   540: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   543: invokeinterface getByte : ()B
/*      */     //   548: istore #16
/*      */     //   550: iload #16
/*      */     //   552: lookupswitch default -> 722, 55 -> 660, 67 -> 660, 76 -> 660, 79 -> 660, 85 -> 660, 91 -> 660, 93 -> 660, 99 -> 660, 108 -> 660, 110 -> 660, 111 -> 660, 117 -> 660
/*      */     //   660: aload_2
/*      */     //   661: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   664: wide astore #1918
/*      */     //   668: aload_2
/*      */     //   669: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   672: wide astore #1916
/*      */     //   676: wide aload #1916
/*      */     //   680: bipush #24
/*      */     //   682: iload #16
/*      */     //   684: invokeinterface setByte : (IB)V
/*      */     //   689: wide aload #1916
/*      */     //   693: bipush #24
/*      */     //   695: invokeinterface getByte : (I)B
/*      */     //   700: wide istore #1915
/*      */     //   704: wide aload #1918
/*      */     //   708: bipush #24
/*      */     //   710: wide iload #1915
/*      */     //   714: invokeinterface setByte : (IB)V
/*      */     //   719: goto -> 726
/*      */     //   722: aload_0
/*      */     //   723: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   726: goto -> 19275
/*      */     //   729: aload_0
/*      */     //   730: new org/renjin/gcc/runtime/BytePtr
/*      */     //   733: dup
/*      */     //   734: ldc_w 'cex '
/*      */     //   737: invokevirtual getBytes : ()[B
/*      */     //   740: iconst_0
/*      */     //   741: invokespecial <init> : ([BI)V
/*      */     //   744: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   747: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   750: ifeq -> 756
/*      */     //   753: goto -> 897
/*      */     //   756: aload_0
/*      */     //   757: aload_1
/*      */     //   758: iconst_1
/*      */     //   759: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   762: aload_1
/*      */     //   763: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   766: dstore #18
/*      */     //   768: dload #18
/*      */     //   770: aload_0
/*      */     //   771: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   774: aload_2
/*      */     //   775: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   778: wide astore #1912
/*      */     //   782: aload_2
/*      */     //   783: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   786: wide astore #1910
/*      */     //   790: wide aload #1910
/*      */     //   794: bipush #28
/*      */     //   796: dconst_1
/*      */     //   797: invokeinterface setDouble : (ID)V
/*      */     //   802: wide aload #1910
/*      */     //   806: bipush #28
/*      */     //   808: invokeinterface getDouble : (I)D
/*      */     //   813: wide dstore #1908
/*      */     //   817: wide aload #1912
/*      */     //   821: bipush #28
/*      */     //   823: wide dload #1908
/*      */     //   827: invokeinterface setDouble : (ID)V
/*      */     //   832: aload_2
/*      */     //   833: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   836: wide astore #1906
/*      */     //   840: aload_2
/*      */     //   841: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   844: wide astore #1904
/*      */     //   848: wide aload #1904
/*      */     //   852: sipush #484
/*      */     //   855: dload #18
/*      */     //   857: invokeinterface setDouble : (ID)V
/*      */     //   862: wide aload #1904
/*      */     //   866: sipush #484
/*      */     //   869: invokeinterface getDouble : (I)D
/*      */     //   874: wide dstore #1902
/*      */     //   878: wide aload #1906
/*      */     //   882: sipush #484
/*      */     //   885: wide dload #1902
/*      */     //   889: invokeinterface setDouble : (ID)V
/*      */     //   894: goto -> 19275
/*      */     //   897: aload_0
/*      */     //   898: new org/renjin/gcc/runtime/BytePtr
/*      */     //   901: dup
/*      */     //   902: ldc_w 'cex.main '
/*      */     //   905: invokevirtual getBytes : ()[B
/*      */     //   908: iconst_0
/*      */     //   909: invokespecial <init> : ([BI)V
/*      */     //   912: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   915: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   918: ifeq -> 924
/*      */     //   921: goto -> 1007
/*      */     //   924: aload_0
/*      */     //   925: aload_1
/*      */     //   926: iconst_1
/*      */     //   927: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   930: aload_1
/*      */     //   931: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   934: dstore #18
/*      */     //   936: dload #18
/*      */     //   938: aload_0
/*      */     //   939: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   942: aload_2
/*      */     //   943: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   946: wide astore #1899
/*      */     //   950: aload_2
/*      */     //   951: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   954: wide astore #1897
/*      */     //   958: wide aload #1897
/*      */     //   962: sipush #492
/*      */     //   965: dload #18
/*      */     //   967: invokeinterface setDouble : (ID)V
/*      */     //   972: wide aload #1897
/*      */     //   976: sipush #492
/*      */     //   979: invokeinterface getDouble : (I)D
/*      */     //   984: wide dstore #1895
/*      */     //   988: wide aload #1899
/*      */     //   992: sipush #492
/*      */     //   995: wide dload #1895
/*      */     //   999: invokeinterface setDouble : (ID)V
/*      */     //   1004: goto -> 19275
/*      */     //   1007: aload_0
/*      */     //   1008: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1011: dup
/*      */     //   1012: ldc_w 'cex.lab '
/*      */     //   1015: invokevirtual getBytes : ()[B
/*      */     //   1018: iconst_0
/*      */     //   1019: invokespecial <init> : ([BI)V
/*      */     //   1022: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1025: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1028: ifeq -> 1034
/*      */     //   1031: goto -> 1117
/*      */     //   1034: aload_0
/*      */     //   1035: aload_1
/*      */     //   1036: iconst_1
/*      */     //   1037: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1040: aload_1
/*      */     //   1041: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1044: dstore #18
/*      */     //   1046: dload #18
/*      */     //   1048: aload_0
/*      */     //   1049: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1052: aload_2
/*      */     //   1053: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1056: wide astore #1892
/*      */     //   1060: aload_2
/*      */     //   1061: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1064: wide astore #1890
/*      */     //   1068: wide aload #1890
/*      */     //   1072: sipush #500
/*      */     //   1075: dload #18
/*      */     //   1077: invokeinterface setDouble : (ID)V
/*      */     //   1082: wide aload #1890
/*      */     //   1086: sipush #500
/*      */     //   1089: invokeinterface getDouble : (I)D
/*      */     //   1094: wide dstore #1888
/*      */     //   1098: wide aload #1892
/*      */     //   1102: sipush #500
/*      */     //   1105: wide dload #1888
/*      */     //   1109: invokeinterface setDouble : (ID)V
/*      */     //   1114: goto -> 19275
/*      */     //   1117: aload_0
/*      */     //   1118: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1121: dup
/*      */     //   1122: ldc_w 'cex.sub '
/*      */     //   1125: invokevirtual getBytes : ()[B
/*      */     //   1128: iconst_0
/*      */     //   1129: invokespecial <init> : ([BI)V
/*      */     //   1132: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1135: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1138: ifeq -> 1144
/*      */     //   1141: goto -> 1227
/*      */     //   1144: aload_0
/*      */     //   1145: aload_1
/*      */     //   1146: iconst_1
/*      */     //   1147: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1150: aload_1
/*      */     //   1151: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1154: dstore #18
/*      */     //   1156: dload #18
/*      */     //   1158: aload_0
/*      */     //   1159: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1162: aload_2
/*      */     //   1163: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1166: wide astore #1885
/*      */     //   1170: aload_2
/*      */     //   1171: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1174: wide astore #1883
/*      */     //   1178: wide aload #1883
/*      */     //   1182: sipush #508
/*      */     //   1185: dload #18
/*      */     //   1187: invokeinterface setDouble : (ID)V
/*      */     //   1192: wide aload #1883
/*      */     //   1196: sipush #508
/*      */     //   1199: invokeinterface getDouble : (I)D
/*      */     //   1204: wide dstore #1881
/*      */     //   1208: wide aload #1885
/*      */     //   1212: sipush #508
/*      */     //   1215: wide dload #1881
/*      */     //   1219: invokeinterface setDouble : (ID)V
/*      */     //   1224: goto -> 19275
/*      */     //   1227: aload_0
/*      */     //   1228: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1231: dup
/*      */     //   1232: ldc_w 'cex.axis '
/*      */     //   1235: invokevirtual getBytes : ()[B
/*      */     //   1238: iconst_0
/*      */     //   1239: invokespecial <init> : ([BI)V
/*      */     //   1242: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1245: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1248: ifeq -> 1254
/*      */     //   1251: goto -> 1337
/*      */     //   1254: aload_0
/*      */     //   1255: aload_1
/*      */     //   1256: iconst_1
/*      */     //   1257: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1260: aload_1
/*      */     //   1261: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1264: dstore #18
/*      */     //   1266: dload #18
/*      */     //   1268: aload_0
/*      */     //   1269: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   1272: aload_2
/*      */     //   1273: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1276: wide astore #1878
/*      */     //   1280: aload_2
/*      */     //   1281: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1284: wide astore #1876
/*      */     //   1288: wide aload #1876
/*      */     //   1292: sipush #516
/*      */     //   1295: dload #18
/*      */     //   1297: invokeinterface setDouble : (ID)V
/*      */     //   1302: wide aload #1876
/*      */     //   1306: sipush #516
/*      */     //   1309: invokeinterface getDouble : (I)D
/*      */     //   1314: wide dstore #1874
/*      */     //   1318: wide aload #1878
/*      */     //   1322: sipush #516
/*      */     //   1325: wide dload #1874
/*      */     //   1329: invokeinterface setDouble : (ID)V
/*      */     //   1334: goto -> 19275
/*      */     //   1337: aload_0
/*      */     //   1338: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1341: dup
/*      */     //   1342: ldc_w 'col '
/*      */     //   1345: invokevirtual getBytes : ()[B
/*      */     //   1348: iconst_0
/*      */     //   1349: invokespecial <init> : ([BI)V
/*      */     //   1352: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1355: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1358: ifeq -> 1364
/*      */     //   1361: goto -> 1462
/*      */     //   1364: aload_0
/*      */     //   1365: aload_1
/*      */     //   1366: iconst_1
/*      */     //   1367: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1370: aload_2
/*      */     //   1371: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1374: wide astore #1871
/*      */     //   1378: aload_2
/*      */     //   1379: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1382: wide astore #1869
/*      */     //   1386: aload_2
/*      */     //   1387: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1390: bipush #20
/*      */     //   1392: invokeinterface getInt : (I)I
/*      */     //   1397: wide istore #1866
/*      */     //   1401: aload_1
/*      */     //   1402: iconst_0
/*      */     //   1403: wide iload #1866
/*      */     //   1407: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1410: wide istore #1865
/*      */     //   1414: wide aload #1869
/*      */     //   1418: bipush #44
/*      */     //   1420: wide iload #1865
/*      */     //   1424: invokeinterface setInt : (II)V
/*      */     //   1429: wide aload #1869
/*      */     //   1433: bipush #44
/*      */     //   1435: invokeinterface getInt : (I)I
/*      */     //   1440: wide istore #1864
/*      */     //   1444: wide aload #1871
/*      */     //   1448: bipush #44
/*      */     //   1450: wide iload #1864
/*      */     //   1454: invokeinterface setInt : (II)V
/*      */     //   1459: goto -> 19275
/*      */     //   1462: aload_0
/*      */     //   1463: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1466: dup
/*      */     //   1467: ldc_w 'col.main '
/*      */     //   1470: invokevirtual getBytes : ()[B
/*      */     //   1473: iconst_0
/*      */     //   1474: invokespecial <init> : ([BI)V
/*      */     //   1477: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1480: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1483: ifeq -> 1489
/*      */     //   1486: goto -> 1590
/*      */     //   1489: aload_0
/*      */     //   1490: aload_1
/*      */     //   1491: iconst_1
/*      */     //   1492: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1495: aload_2
/*      */     //   1496: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1499: wide astore #1861
/*      */     //   1503: aload_2
/*      */     //   1504: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1507: wide astore #1859
/*      */     //   1511: aload_2
/*      */     //   1512: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1515: bipush #20
/*      */     //   1517: invokeinterface getInt : (I)I
/*      */     //   1522: wide istore #1856
/*      */     //   1526: aload_1
/*      */     //   1527: iconst_0
/*      */     //   1528: wide iload #1856
/*      */     //   1532: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1535: wide istore #1855
/*      */     //   1539: wide aload #1859
/*      */     //   1543: sipush #540
/*      */     //   1546: wide iload #1855
/*      */     //   1550: invokeinterface setInt : (II)V
/*      */     //   1555: wide aload #1859
/*      */     //   1559: sipush #540
/*      */     //   1562: invokeinterface getInt : (I)I
/*      */     //   1567: wide istore #1854
/*      */     //   1571: wide aload #1861
/*      */     //   1575: sipush #540
/*      */     //   1578: wide iload #1854
/*      */     //   1582: invokeinterface setInt : (II)V
/*      */     //   1587: goto -> 19275
/*      */     //   1590: aload_0
/*      */     //   1591: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1594: dup
/*      */     //   1595: ldc_w 'col.lab '
/*      */     //   1598: invokevirtual getBytes : ()[B
/*      */     //   1601: iconst_0
/*      */     //   1602: invokespecial <init> : ([BI)V
/*      */     //   1605: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1608: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1611: ifeq -> 1617
/*      */     //   1614: goto -> 1718
/*      */     //   1617: aload_0
/*      */     //   1618: aload_1
/*      */     //   1619: iconst_1
/*      */     //   1620: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1623: aload_2
/*      */     //   1624: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1627: wide astore #1851
/*      */     //   1631: aload_2
/*      */     //   1632: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1635: wide astore #1849
/*      */     //   1639: aload_2
/*      */     //   1640: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1643: bipush #20
/*      */     //   1645: invokeinterface getInt : (I)I
/*      */     //   1650: wide istore #1846
/*      */     //   1654: aload_1
/*      */     //   1655: iconst_0
/*      */     //   1656: wide iload #1846
/*      */     //   1660: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1663: wide istore #1845
/*      */     //   1667: wide aload #1849
/*      */     //   1671: sipush #544
/*      */     //   1674: wide iload #1845
/*      */     //   1678: invokeinterface setInt : (II)V
/*      */     //   1683: wide aload #1849
/*      */     //   1687: sipush #544
/*      */     //   1690: invokeinterface getInt : (I)I
/*      */     //   1695: wide istore #1844
/*      */     //   1699: wide aload #1851
/*      */     //   1703: sipush #544
/*      */     //   1706: wide iload #1844
/*      */     //   1710: invokeinterface setInt : (II)V
/*      */     //   1715: goto -> 19275
/*      */     //   1718: aload_0
/*      */     //   1719: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1722: dup
/*      */     //   1723: ldc_w 'col.sub '
/*      */     //   1726: invokevirtual getBytes : ()[B
/*      */     //   1729: iconst_0
/*      */     //   1730: invokespecial <init> : ([BI)V
/*      */     //   1733: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1736: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1739: ifeq -> 1745
/*      */     //   1742: goto -> 1846
/*      */     //   1745: aload_0
/*      */     //   1746: aload_1
/*      */     //   1747: iconst_1
/*      */     //   1748: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1751: aload_2
/*      */     //   1752: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1755: wide astore #1841
/*      */     //   1759: aload_2
/*      */     //   1760: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1763: wide astore #1839
/*      */     //   1767: aload_2
/*      */     //   1768: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1771: bipush #20
/*      */     //   1773: invokeinterface getInt : (I)I
/*      */     //   1778: wide istore #1836
/*      */     //   1782: aload_1
/*      */     //   1783: iconst_0
/*      */     //   1784: wide iload #1836
/*      */     //   1788: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1791: wide istore #1835
/*      */     //   1795: wide aload #1839
/*      */     //   1799: sipush #548
/*      */     //   1802: wide iload #1835
/*      */     //   1806: invokeinterface setInt : (II)V
/*      */     //   1811: wide aload #1839
/*      */     //   1815: sipush #548
/*      */     //   1818: invokeinterface getInt : (I)I
/*      */     //   1823: wide istore #1834
/*      */     //   1827: wide aload #1841
/*      */     //   1831: sipush #548
/*      */     //   1834: wide iload #1834
/*      */     //   1838: invokeinterface setInt : (II)V
/*      */     //   1843: goto -> 19275
/*      */     //   1846: aload_0
/*      */     //   1847: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1850: dup
/*      */     //   1851: ldc_w 'col.axis '
/*      */     //   1854: invokevirtual getBytes : ()[B
/*      */     //   1857: iconst_0
/*      */     //   1858: invokespecial <init> : ([BI)V
/*      */     //   1861: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1864: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1867: ifeq -> 1873
/*      */     //   1870: goto -> 1974
/*      */     //   1873: aload_0
/*      */     //   1874: aload_1
/*      */     //   1875: iconst_1
/*      */     //   1876: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   1879: aload_2
/*      */     //   1880: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1883: wide astore #1831
/*      */     //   1887: aload_2
/*      */     //   1888: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1891: wide astore #1829
/*      */     //   1895: aload_2
/*      */     //   1896: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1899: bipush #20
/*      */     //   1901: invokeinterface getInt : (I)I
/*      */     //   1906: wide istore #1826
/*      */     //   1910: aload_1
/*      */     //   1911: iconst_0
/*      */     //   1912: wide iload #1826
/*      */     //   1916: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   1919: wide istore #1825
/*      */     //   1923: wide aload #1829
/*      */     //   1927: sipush #552
/*      */     //   1930: wide iload #1825
/*      */     //   1934: invokeinterface setInt : (II)V
/*      */     //   1939: wide aload #1829
/*      */     //   1943: sipush #552
/*      */     //   1946: invokeinterface getInt : (I)I
/*      */     //   1951: wide istore #1824
/*      */     //   1955: wide aload #1831
/*      */     //   1959: sipush #552
/*      */     //   1962: wide iload #1824
/*      */     //   1966: invokeinterface setInt : (II)V
/*      */     //   1971: goto -> 19275
/*      */     //   1974: aload_0
/*      */     //   1975: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1978: dup
/*      */     //   1979: ldc_w 'crt '
/*      */     //   1982: invokevirtual getBytes : ()[B
/*      */     //   1985: iconst_0
/*      */     //   1986: invokespecial <init> : ([BI)V
/*      */     //   1989: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1992: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1995: ifeq -> 2001
/*      */     //   1998: goto -> 2081
/*      */     //   2001: aload_0
/*      */     //   2002: aload_1
/*      */     //   2003: iconst_1
/*      */     //   2004: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2007: aload_1
/*      */     //   2008: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   2011: dstore #18
/*      */     //   2013: dload #18
/*      */     //   2015: aload_0
/*      */     //   2016: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2019: aload_2
/*      */     //   2020: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2023: wide astore #1821
/*      */     //   2027: aload_2
/*      */     //   2028: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2031: wide astore #1819
/*      */     //   2035: wide aload #1819
/*      */     //   2039: bipush #48
/*      */     //   2041: dload #18
/*      */     //   2043: invokeinterface setDouble : (ID)V
/*      */     //   2048: wide aload #1819
/*      */     //   2052: bipush #48
/*      */     //   2054: invokeinterface getDouble : (I)D
/*      */     //   2059: wide dstore #1817
/*      */     //   2063: wide aload #1821
/*      */     //   2067: bipush #48
/*      */     //   2069: wide dload #1817
/*      */     //   2073: invokeinterface setDouble : (ID)V
/*      */     //   2078: goto -> 19275
/*      */     //   2081: aload_0
/*      */     //   2082: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2085: dup
/*      */     //   2086: ldc_w 'err '
/*      */     //   2089: invokevirtual getBytes : ()[B
/*      */     //   2092: iconst_0
/*      */     //   2093: invokespecial <init> : ([BI)V
/*      */     //   2096: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2099: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2102: ifeq -> 2108
/*      */     //   2105: goto -> 2203
/*      */     //   2108: aload_0
/*      */     //   2109: aload_1
/*      */     //   2110: iconst_1
/*      */     //   2111: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2114: aload_1
/*      */     //   2115: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2118: istore #17
/*      */     //   2120: iload #17
/*      */     //   2122: ifeq -> 2137
/*      */     //   2125: goto -> 2128
/*      */     //   2128: iload #17
/*      */     //   2130: iconst_m1
/*      */     //   2131: if_icmpeq -> 2137
/*      */     //   2134: goto -> 2199
/*      */     //   2137: aload_2
/*      */     //   2138: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2141: wide astore #1814
/*      */     //   2145: aload_2
/*      */     //   2146: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2149: wide astore #1812
/*      */     //   2153: wide aload #1812
/*      */     //   2157: bipush #72
/*      */     //   2159: iload #17
/*      */     //   2161: invokeinterface setInt : (II)V
/*      */     //   2166: wide aload #1812
/*      */     //   2170: bipush #72
/*      */     //   2172: invokeinterface getInt : (I)I
/*      */     //   2177: wide istore #1811
/*      */     //   2181: wide aload #1814
/*      */     //   2185: bipush #72
/*      */     //   2187: wide iload #1811
/*      */     //   2191: invokeinterface setInt : (II)V
/*      */     //   2196: goto -> 19275
/*      */     //   2199: aload_0
/*      */     //   2200: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2203: aload_0
/*      */     //   2204: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2207: dup
/*      */     //   2208: ldc_w 'family '
/*      */     //   2211: invokevirtual getBytes : ()[B
/*      */     //   2214: iconst_0
/*      */     //   2215: invokespecial <init> : ([BI)V
/*      */     //   2218: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2221: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2224: ifeq -> 2230
/*      */     //   2227: goto -> 2407
/*      */     //   2230: aload_1
/*      */     //   2231: bipush #16
/*      */     //   2233: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2236: astore_1
/*      */     //   2237: aload_1
/*      */     //   2238: iconst_0
/*      */     //   2239: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2242: wide astore #1809
/*      */     //   2246: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   2249: wide astore #1808
/*      */     //   2253: wide aload #1809
/*      */     //   2257: wide aload #1808
/*      */     //   2261: if_acmpeq -> 2267
/*      */     //   2264: goto -> 2283
/*      */     //   2267: getstatic org/renjin/gnur/api/Rinternals.R_BlankString : Lorg/renjin/sexp/SEXP;
/*      */     //   2270: wide astore #1807
/*      */     //   2274: aload_1
/*      */     //   2275: iconst_0
/*      */     //   2276: wide aload #1807
/*      */     //   2280: invokestatic SET_STRING_ELT : (Lorg/renjin/sexp/SEXP;ILorg/renjin/sexp/SEXP;)V
/*      */     //   2283: aload_0
/*      */     //   2284: aload_1
/*      */     //   2285: iconst_1
/*      */     //   2286: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2289: invokestatic vmaxget : ()Ljava/lang/Object;
/*      */     //   2292: invokestatic toPtr : (Ljava/lang/Object;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2295: astore #12
/*      */     //   2297: aload_1
/*      */     //   2298: iconst_0
/*      */     //   2299: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2302: invokestatic Rf_translateChar : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2305: astore #14
/*      */     //   2307: aload #14
/*      */     //   2309: invokestatic strlen : (Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2312: sipush #200
/*      */     //   2315: invokestatic compareUnsigned : (II)I
/*      */     //   2318: ifgt -> 2324
/*      */     //   2321: goto -> 2364
/*      */     //   2324: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2327: dup
/*      */     //   2328: ldc 'graphics '
/*      */     //   2330: invokevirtual getBytes : ()[B
/*      */     //   2333: iconst_0
/*      */     //   2334: invokespecial <init> : ([BI)V
/*      */     //   2337: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2340: dup
/*      */     //   2341: ldc_w 'graphical parameter 'family' has a maximum length of 200 bytes '
/*      */     //   2344: invokevirtual getBytes : ()[B
/*      */     //   2347: iconst_0
/*      */     //   2348: invokespecial <init> : ([BI)V
/*      */     //   2351: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2354: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2357: iconst_0
/*      */     //   2358: anewarray java/lang/Object
/*      */     //   2361: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2364: aload_2
/*      */     //   2365: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2368: bipush #80
/*      */     //   2370: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2375: aload #14
/*      */     //   2377: sipush #201
/*      */     //   2380: invokestatic strncpy : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2383: pop
/*      */     //   2384: aload_2
/*      */     //   2385: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2388: bipush #80
/*      */     //   2390: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2395: aload #14
/*      */     //   2397: sipush #201
/*      */     //   2400: invokestatic strncpy : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2403: pop
/*      */     //   2404: goto -> 19275
/*      */     //   2407: aload_0
/*      */     //   2408: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2411: dup
/*      */     //   2412: ldc_w 'fg '
/*      */     //   2415: invokevirtual getBytes : ()[B
/*      */     //   2418: iconst_0
/*      */     //   2419: invokespecial <init> : ([BI)V
/*      */     //   2422: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2425: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2428: ifeq -> 2434
/*      */     //   2431: goto -> 2603
/*      */     //   2434: aload_0
/*      */     //   2435: aload_1
/*      */     //   2436: iconst_1
/*      */     //   2437: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2440: aload_2
/*      */     //   2441: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2444: bipush #20
/*      */     //   2446: invokeinterface getInt : (I)I
/*      */     //   2451: wide istore #1791
/*      */     //   2455: aload_1
/*      */     //   2456: iconst_0
/*      */     //   2457: wide iload #1791
/*      */     //   2461: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   2464: istore #17
/*      */     //   2466: aload_2
/*      */     //   2467: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2470: wide astore #1788
/*      */     //   2474: aload_2
/*      */     //   2475: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2478: wide astore #1786
/*      */     //   2482: iload #17
/*      */     //   2484: wide istore #1785
/*      */     //   2488: wide aload #1786
/*      */     //   2492: bipush #44
/*      */     //   2494: wide iload #1785
/*      */     //   2498: invokeinterface setInt : (II)V
/*      */     //   2503: wide aload #1786
/*      */     //   2507: bipush #44
/*      */     //   2509: invokeinterface getInt : (I)I
/*      */     //   2514: wide istore #1784
/*      */     //   2518: wide aload #1788
/*      */     //   2522: bipush #44
/*      */     //   2524: wide iload #1784
/*      */     //   2528: invokeinterface setInt : (II)V
/*      */     //   2533: aload_2
/*      */     //   2534: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2537: wide astore #1782
/*      */     //   2541: aload_2
/*      */     //   2542: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2545: wide astore #1780
/*      */     //   2549: iload #17
/*      */     //   2551: wide istore #1779
/*      */     //   2555: wide aload #1780
/*      */     //   2559: bipush #76
/*      */     //   2561: wide iload #1779
/*      */     //   2565: invokeinterface setInt : (II)V
/*      */     //   2570: wide aload #1780
/*      */     //   2574: bipush #76
/*      */     //   2576: invokeinterface getInt : (I)I
/*      */     //   2581: wide istore #1778
/*      */     //   2585: wide aload #1782
/*      */     //   2589: bipush #76
/*      */     //   2591: wide iload #1778
/*      */     //   2595: invokeinterface setInt : (II)V
/*      */     //   2600: goto -> 19275
/*      */     //   2603: aload_0
/*      */     //   2604: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2607: dup
/*      */     //   2608: ldc_w 'font '
/*      */     //   2611: invokevirtual getBytes : ()[B
/*      */     //   2614: iconst_0
/*      */     //   2615: invokespecial <init> : ([BI)V
/*      */     //   2618: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2621: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2624: ifeq -> 2630
/*      */     //   2627: goto -> 2713
/*      */     //   2630: aload_0
/*      */     //   2631: aload_1
/*      */     //   2632: iconst_1
/*      */     //   2633: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2636: aload_1
/*      */     //   2637: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2640: istore #17
/*      */     //   2642: iload #17
/*      */     //   2644: aload_0
/*      */     //   2645: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2648: aload_2
/*      */     //   2649: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2652: wide astore #1775
/*      */     //   2656: aload_2
/*      */     //   2657: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2660: wide astore #1773
/*      */     //   2664: wide aload #1773
/*      */     //   2668: sipush #284
/*      */     //   2671: iload #17
/*      */     //   2673: invokeinterface setInt : (II)V
/*      */     //   2678: wide aload #1773
/*      */     //   2682: sipush #284
/*      */     //   2685: invokeinterface getInt : (I)I
/*      */     //   2690: wide istore #1772
/*      */     //   2694: wide aload #1775
/*      */     //   2698: sipush #284
/*      */     //   2701: wide iload #1772
/*      */     //   2705: invokeinterface setInt : (II)V
/*      */     //   2710: goto -> 19275
/*      */     //   2713: aload_0
/*      */     //   2714: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2717: dup
/*      */     //   2718: ldc_w 'font.main '
/*      */     //   2721: invokevirtual getBytes : ()[B
/*      */     //   2724: iconst_0
/*      */     //   2725: invokespecial <init> : ([BI)V
/*      */     //   2728: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2731: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2734: ifeq -> 2740
/*      */     //   2737: goto -> 2823
/*      */     //   2740: aload_0
/*      */     //   2741: aload_1
/*      */     //   2742: iconst_1
/*      */     //   2743: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2746: aload_1
/*      */     //   2747: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2750: istore #17
/*      */     //   2752: iload #17
/*      */     //   2754: aload_0
/*      */     //   2755: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2758: aload_2
/*      */     //   2759: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2762: wide astore #1769
/*      */     //   2766: aload_2
/*      */     //   2767: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2770: wide astore #1767
/*      */     //   2774: wide aload #1767
/*      */     //   2778: sipush #524
/*      */     //   2781: iload #17
/*      */     //   2783: invokeinterface setInt : (II)V
/*      */     //   2788: wide aload #1767
/*      */     //   2792: sipush #524
/*      */     //   2795: invokeinterface getInt : (I)I
/*      */     //   2800: wide istore #1766
/*      */     //   2804: wide aload #1769
/*      */     //   2808: sipush #524
/*      */     //   2811: wide iload #1766
/*      */     //   2815: invokeinterface setInt : (II)V
/*      */     //   2820: goto -> 19275
/*      */     //   2823: aload_0
/*      */     //   2824: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2827: dup
/*      */     //   2828: ldc_w 'font.lab '
/*      */     //   2831: invokevirtual getBytes : ()[B
/*      */     //   2834: iconst_0
/*      */     //   2835: invokespecial <init> : ([BI)V
/*      */     //   2838: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2841: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2844: ifeq -> 2850
/*      */     //   2847: goto -> 2933
/*      */     //   2850: aload_0
/*      */     //   2851: aload_1
/*      */     //   2852: iconst_1
/*      */     //   2853: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2856: aload_1
/*      */     //   2857: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2860: istore #17
/*      */     //   2862: iload #17
/*      */     //   2864: aload_0
/*      */     //   2865: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2868: aload_2
/*      */     //   2869: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2872: wide astore #1763
/*      */     //   2876: aload_2
/*      */     //   2877: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2880: wide astore #1761
/*      */     //   2884: wide aload #1761
/*      */     //   2888: sipush #528
/*      */     //   2891: iload #17
/*      */     //   2893: invokeinterface setInt : (II)V
/*      */     //   2898: wide aload #1761
/*      */     //   2902: sipush #528
/*      */     //   2905: invokeinterface getInt : (I)I
/*      */     //   2910: wide istore #1760
/*      */     //   2914: wide aload #1763
/*      */     //   2918: sipush #528
/*      */     //   2921: wide iload #1760
/*      */     //   2925: invokeinterface setInt : (II)V
/*      */     //   2930: goto -> 19275
/*      */     //   2933: aload_0
/*      */     //   2934: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2937: dup
/*      */     //   2938: ldc_w 'font.sub '
/*      */     //   2941: invokevirtual getBytes : ()[B
/*      */     //   2944: iconst_0
/*      */     //   2945: invokespecial <init> : ([BI)V
/*      */     //   2948: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2951: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   2954: ifeq -> 2960
/*      */     //   2957: goto -> 3043
/*      */     //   2960: aload_0
/*      */     //   2961: aload_1
/*      */     //   2962: iconst_1
/*      */     //   2963: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   2966: aload_1
/*      */     //   2967: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2970: istore #17
/*      */     //   2972: iload #17
/*      */     //   2974: aload_0
/*      */     //   2975: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2978: aload_2
/*      */     //   2979: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2982: wide astore #1757
/*      */     //   2986: aload_2
/*      */     //   2987: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2990: wide astore #1755
/*      */     //   2994: wide aload #1755
/*      */     //   2998: sipush #532
/*      */     //   3001: iload #17
/*      */     //   3003: invokeinterface setInt : (II)V
/*      */     //   3008: wide aload #1755
/*      */     //   3012: sipush #532
/*      */     //   3015: invokeinterface getInt : (I)I
/*      */     //   3020: wide istore #1754
/*      */     //   3024: wide aload #1757
/*      */     //   3028: sipush #532
/*      */     //   3031: wide iload #1754
/*      */     //   3035: invokeinterface setInt : (II)V
/*      */     //   3040: goto -> 19275
/*      */     //   3043: aload_0
/*      */     //   3044: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3047: dup
/*      */     //   3048: ldc_w 'font.axis '
/*      */     //   3051: invokevirtual getBytes : ()[B
/*      */     //   3054: iconst_0
/*      */     //   3055: invokespecial <init> : ([BI)V
/*      */     //   3058: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3061: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3064: ifeq -> 3070
/*      */     //   3067: goto -> 3153
/*      */     //   3070: aload_0
/*      */     //   3071: aload_1
/*      */     //   3072: iconst_1
/*      */     //   3073: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3076: aload_1
/*      */     //   3077: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3080: istore #17
/*      */     //   3082: iload #17
/*      */     //   3084: aload_0
/*      */     //   3085: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3088: aload_2
/*      */     //   3089: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3092: wide astore #1751
/*      */     //   3096: aload_2
/*      */     //   3097: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3100: wide astore #1749
/*      */     //   3104: wide aload #1749
/*      */     //   3108: sipush #536
/*      */     //   3111: iload #17
/*      */     //   3113: invokeinterface setInt : (II)V
/*      */     //   3118: wide aload #1749
/*      */     //   3122: sipush #536
/*      */     //   3125: invokeinterface getInt : (I)I
/*      */     //   3130: wide istore #1748
/*      */     //   3134: wide aload #1751
/*      */     //   3138: sipush #536
/*      */     //   3141: wide iload #1748
/*      */     //   3145: invokeinterface setInt : (II)V
/*      */     //   3150: goto -> 19275
/*      */     //   3153: aload_0
/*      */     //   3154: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3157: dup
/*      */     //   3158: ldc_w 'lab '
/*      */     //   3161: invokevirtual getBytes : ()[B
/*      */     //   3164: iconst_0
/*      */     //   3165: invokespecial <init> : ([BI)V
/*      */     //   3168: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3171: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3174: ifeq -> 3180
/*      */     //   3177: goto -> 3472
/*      */     //   3180: aload_1
/*      */     //   3181: bipush #13
/*      */     //   3183: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   3186: astore_1
/*      */     //   3187: aload_0
/*      */     //   3188: aload_1
/*      */     //   3189: iconst_3
/*      */     //   3190: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3193: aload_1
/*      */     //   3194: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3197: invokeinterface getInt : ()I
/*      */     //   3202: aload_0
/*      */     //   3203: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3206: aload_1
/*      */     //   3207: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3210: iconst_4
/*      */     //   3211: invokeinterface getInt : (I)I
/*      */     //   3216: aload_0
/*      */     //   3217: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3220: aload_1
/*      */     //   3221: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3224: bipush #8
/*      */     //   3226: invokeinterface getInt : (I)I
/*      */     //   3231: aload_0
/*      */     //   3232: invokestatic nonnegIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3235: aload_2
/*      */     //   3236: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3239: wide astore #1732
/*      */     //   3243: aload_2
/*      */     //   3244: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3247: wide astore #1730
/*      */     //   3251: aload_1
/*      */     //   3252: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3255: invokeinterface getInt : ()I
/*      */     //   3260: wide istore #1727
/*      */     //   3264: wide aload #1730
/*      */     //   3268: sipush #296
/*      */     //   3271: wide iload #1727
/*      */     //   3275: invokeinterface setInt : (II)V
/*      */     //   3280: wide aload #1730
/*      */     //   3284: sipush #296
/*      */     //   3287: invokeinterface getInt : (I)I
/*      */     //   3292: wide istore #1726
/*      */     //   3296: wide aload #1732
/*      */     //   3300: sipush #296
/*      */     //   3303: wide iload #1726
/*      */     //   3307: invokeinterface setInt : (II)V
/*      */     //   3312: aload_2
/*      */     //   3313: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3316: wide astore #1724
/*      */     //   3320: aload_2
/*      */     //   3321: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3324: wide astore #1722
/*      */     //   3328: aload_1
/*      */     //   3329: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3332: iconst_4
/*      */     //   3333: invokeinterface getInt : (I)I
/*      */     //   3338: wide istore #1719
/*      */     //   3342: wide aload #1722
/*      */     //   3346: sipush #300
/*      */     //   3349: wide iload #1719
/*      */     //   3353: invokeinterface setInt : (II)V
/*      */     //   3358: wide aload #1722
/*      */     //   3362: sipush #300
/*      */     //   3365: invokeinterface getInt : (I)I
/*      */     //   3370: wide istore #1718
/*      */     //   3374: wide aload #1724
/*      */     //   3378: sipush #300
/*      */     //   3381: wide iload #1718
/*      */     //   3385: invokeinterface setInt : (II)V
/*      */     //   3390: aload_2
/*      */     //   3391: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3394: wide astore #1716
/*      */     //   3398: aload_2
/*      */     //   3399: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3402: wide astore #1714
/*      */     //   3406: aload_1
/*      */     //   3407: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3410: bipush #8
/*      */     //   3412: invokeinterface getInt : (I)I
/*      */     //   3417: wide istore #1711
/*      */     //   3421: wide aload #1714
/*      */     //   3425: sipush #304
/*      */     //   3428: wide iload #1711
/*      */     //   3432: invokeinterface setInt : (II)V
/*      */     //   3437: wide aload #1714
/*      */     //   3441: sipush #304
/*      */     //   3444: invokeinterface getInt : (I)I
/*      */     //   3449: wide istore #1710
/*      */     //   3453: wide aload #1716
/*      */     //   3457: sipush #304
/*      */     //   3460: wide iload #1710
/*      */     //   3464: invokeinterface setInt : (II)V
/*      */     //   3469: goto -> 19275
/*      */     //   3472: aload_0
/*      */     //   3473: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3476: dup
/*      */     //   3477: ldc_w 'las '
/*      */     //   3480: invokevirtual getBytes : ()[B
/*      */     //   3483: iconst_0
/*      */     //   3484: invokespecial <init> : ([BI)V
/*      */     //   3487: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3490: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3493: ifeq -> 3499
/*      */     //   3496: goto -> 3597
/*      */     //   3499: aload_0
/*      */     //   3500: aload_1
/*      */     //   3501: iconst_1
/*      */     //   3502: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3505: aload_1
/*      */     //   3506: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3509: istore #17
/*      */     //   3511: iload #17
/*      */     //   3513: ifge -> 3519
/*      */     //   3516: goto -> 3593
/*      */     //   3519: iload #17
/*      */     //   3521: iconst_3
/*      */     //   3522: if_icmple -> 3528
/*      */     //   3525: goto -> 3593
/*      */     //   3528: aload_2
/*      */     //   3529: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3532: wide astore #1707
/*      */     //   3536: aload_2
/*      */     //   3537: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3540: wide astore #1705
/*      */     //   3544: wide aload #1705
/*      */     //   3548: sipush #308
/*      */     //   3551: iload #17
/*      */     //   3553: invokeinterface setInt : (II)V
/*      */     //   3558: wide aload #1705
/*      */     //   3562: sipush #308
/*      */     //   3565: invokeinterface getInt : (I)I
/*      */     //   3570: wide istore #1704
/*      */     //   3574: wide aload #1707
/*      */     //   3578: sipush #308
/*      */     //   3581: wide iload #1704
/*      */     //   3585: invokeinterface setInt : (II)V
/*      */     //   3590: goto -> 19275
/*      */     //   3593: aload_0
/*      */     //   3594: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3597: aload_0
/*      */     //   3598: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3601: dup
/*      */     //   3602: ldc_w 'lend '
/*      */     //   3605: invokevirtual getBytes : ()[B
/*      */     //   3608: iconst_0
/*      */     //   3609: invokespecial <init> : ([BI)V
/*      */     //   3612: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3615: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3618: ifeq -> 3624
/*      */     //   3621: goto -> 3706
/*      */     //   3624: aload_0
/*      */     //   3625: aload_1
/*      */     //   3626: iconst_1
/*      */     //   3627: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3630: aload_2
/*      */     //   3631: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3634: wide astore #1701
/*      */     //   3638: aload_2
/*      */     //   3639: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3642: wide astore #1699
/*      */     //   3646: aload_1
/*      */     //   3647: iconst_0
/*      */     //   3648: invokestatic GE_LENDpar : (Lorg/renjin/sexp/SEXP;I)I
/*      */     //   3651: wide istore #1698
/*      */     //   3655: wide aload #1699
/*      */     //   3659: sipush #324
/*      */     //   3662: wide iload #1698
/*      */     //   3666: invokeinterface setInt : (II)V
/*      */     //   3671: wide aload #1699
/*      */     //   3675: sipush #324
/*      */     //   3678: invokeinterface getInt : (I)I
/*      */     //   3683: wide istore #1697
/*      */     //   3687: wide aload #1701
/*      */     //   3691: sipush #324
/*      */     //   3694: wide iload #1697
/*      */     //   3698: invokeinterface setInt : (II)V
/*      */     //   3703: goto -> 19275
/*      */     //   3706: aload_0
/*      */     //   3707: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3710: dup
/*      */     //   3711: ldc_w 'ljoin '
/*      */     //   3714: invokevirtual getBytes : ()[B
/*      */     //   3717: iconst_0
/*      */     //   3718: invokespecial <init> : ([BI)V
/*      */     //   3721: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3724: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3727: ifeq -> 3733
/*      */     //   3730: goto -> 3815
/*      */     //   3733: aload_0
/*      */     //   3734: aload_1
/*      */     //   3735: iconst_1
/*      */     //   3736: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3739: aload_2
/*      */     //   3740: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3743: wide astore #1694
/*      */     //   3747: aload_2
/*      */     //   3748: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3751: wide astore #1692
/*      */     //   3755: aload_1
/*      */     //   3756: iconst_0
/*      */     //   3757: invokestatic GE_LJOINpar : (Lorg/renjin/sexp/SEXP;I)I
/*      */     //   3760: wide istore #1691
/*      */     //   3764: wide aload #1692
/*      */     //   3768: sipush #328
/*      */     //   3771: wide iload #1691
/*      */     //   3775: invokeinterface setInt : (II)V
/*      */     //   3780: wide aload #1692
/*      */     //   3784: sipush #328
/*      */     //   3787: invokeinterface getInt : (I)I
/*      */     //   3792: wide istore #1690
/*      */     //   3796: wide aload #1694
/*      */     //   3800: sipush #328
/*      */     //   3803: wide iload #1690
/*      */     //   3807: invokeinterface setInt : (II)V
/*      */     //   3812: goto -> 19275
/*      */     //   3815: aload_0
/*      */     //   3816: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3819: dup
/*      */     //   3820: ldc_w 'lmitre '
/*      */     //   3823: invokevirtual getBytes : ()[B
/*      */     //   3826: iconst_0
/*      */     //   3827: invokespecial <init> : ([BI)V
/*      */     //   3830: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3833: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3836: ifeq -> 3842
/*      */     //   3839: goto -> 3939
/*      */     //   3842: aload_0
/*      */     //   3843: aload_1
/*      */     //   3844: iconst_1
/*      */     //   3845: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3848: aload_1
/*      */     //   3849: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   3852: dstore #18
/*      */     //   3854: dload #18
/*      */     //   3856: aload_0
/*      */     //   3857: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3860: dload #18
/*      */     //   3862: dconst_1
/*      */     //   3863: dcmpg
/*      */     //   3864: iflt -> 3870
/*      */     //   3867: goto -> 3874
/*      */     //   3870: aload_0
/*      */     //   3871: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3874: aload_2
/*      */     //   3875: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3878: wide astore #1687
/*      */     //   3882: aload_2
/*      */     //   3883: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3886: wide astore #1685
/*      */     //   3890: wide aload #1685
/*      */     //   3894: sipush #332
/*      */     //   3897: dload #18
/*      */     //   3899: invokeinterface setDouble : (ID)V
/*      */     //   3904: wide aload #1685
/*      */     //   3908: sipush #332
/*      */     //   3911: invokeinterface getDouble : (I)D
/*      */     //   3916: wide dstore #1683
/*      */     //   3920: wide aload #1687
/*      */     //   3924: sipush #332
/*      */     //   3927: wide dload #1683
/*      */     //   3931: invokeinterface setDouble : (ID)V
/*      */     //   3936: goto -> 19275
/*      */     //   3939: aload_0
/*      */     //   3940: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3943: dup
/*      */     //   3944: ldc_w 'lty '
/*      */     //   3947: invokevirtual getBytes : ()[B
/*      */     //   3950: iconst_0
/*      */     //   3951: invokespecial <init> : ([BI)V
/*      */     //   3954: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3957: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   3960: ifeq -> 3966
/*      */     //   3963: goto -> 4048
/*      */     //   3966: aload_0
/*      */     //   3967: aload_1
/*      */     //   3968: iconst_1
/*      */     //   3969: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   3972: aload_2
/*      */     //   3973: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3976: wide astore #1680
/*      */     //   3980: aload_2
/*      */     //   3981: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3984: wide astore #1678
/*      */     //   3988: aload_1
/*      */     //   3989: iconst_0
/*      */     //   3990: invokestatic GE_LTYpar : (Lorg/renjin/sexp/SEXP;I)I
/*      */     //   3993: wide istore #1676
/*      */     //   3997: wide aload #1678
/*      */     //   4001: sipush #312
/*      */     //   4004: wide iload #1676
/*      */     //   4008: invokeinterface setInt : (II)V
/*      */     //   4013: wide aload #1678
/*      */     //   4017: sipush #312
/*      */     //   4020: invokeinterface getInt : (I)I
/*      */     //   4025: wide istore #1675
/*      */     //   4029: wide aload #1680
/*      */     //   4033: sipush #312
/*      */     //   4036: wide iload #1675
/*      */     //   4040: invokeinterface setInt : (II)V
/*      */     //   4045: goto -> 19275
/*      */     //   4048: aload_0
/*      */     //   4049: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4052: dup
/*      */     //   4053: ldc_w 'lwd '
/*      */     //   4056: invokevirtual getBytes : ()[B
/*      */     //   4059: iconst_0
/*      */     //   4060: invokespecial <init> : ([BI)V
/*      */     //   4063: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4066: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4069: ifeq -> 4075
/*      */     //   4072: goto -> 4158
/*      */     //   4075: aload_0
/*      */     //   4076: aload_1
/*      */     //   4077: iconst_1
/*      */     //   4078: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   4081: aload_1
/*      */     //   4082: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   4085: dstore #18
/*      */     //   4087: dload #18
/*      */     //   4089: aload_0
/*      */     //   4090: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4093: aload_2
/*      */     //   4094: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4097: wide astore #1672
/*      */     //   4101: aload_2
/*      */     //   4102: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4105: wide astore #1670
/*      */     //   4109: wide aload #1670
/*      */     //   4113: sipush #316
/*      */     //   4116: dload #18
/*      */     //   4118: invokeinterface setDouble : (ID)V
/*      */     //   4123: wide aload #1670
/*      */     //   4127: sipush #316
/*      */     //   4130: invokeinterface getDouble : (I)D
/*      */     //   4135: wide dstore #1668
/*      */     //   4139: wide aload #1672
/*      */     //   4143: sipush #316
/*      */     //   4146: wide dload #1668
/*      */     //   4150: invokeinterface setDouble : (ID)V
/*      */     //   4155: goto -> 19275
/*      */     //   4158: aload_0
/*      */     //   4159: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4162: dup
/*      */     //   4163: ldc_w 'mgp '
/*      */     //   4166: invokevirtual getBytes : ()[B
/*      */     //   4169: iconst_0
/*      */     //   4170: invokespecial <init> : ([BI)V
/*      */     //   4173: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4176: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4179: ifeq -> 4185
/*      */     //   4182: goto -> 4595
/*      */     //   4185: aload_1
/*      */     //   4186: bipush #14
/*      */     //   4188: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   4191: astore_1
/*      */     //   4192: aload_1
/*      */     //   4193: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   4196: pop
/*      */     //   4197: aload_0
/*      */     //   4198: aload_1
/*      */     //   4199: iconst_3
/*      */     //   4200: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   4203: aload_1
/*      */     //   4204: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4207: invokeinterface getDouble : ()D
/*      */     //   4212: aload_0
/*      */     //   4213: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4216: aload_1
/*      */     //   4217: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4220: bipush #8
/*      */     //   4222: invokeinterface getDouble : (I)D
/*      */     //   4227: aload_0
/*      */     //   4228: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4231: aload_1
/*      */     //   4232: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4235: bipush #16
/*      */     //   4237: invokeinterface getDouble : (I)D
/*      */     //   4242: aload_0
/*      */     //   4243: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4246: aload_1
/*      */     //   4247: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4250: invokeinterface getDouble : ()D
/*      */     //   4255: wide dstore #1647
/*      */     //   4259: aload_1
/*      */     //   4260: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4263: bipush #8
/*      */     //   4265: invokeinterface getDouble : (I)D
/*      */     //   4270: wide dstore #1641
/*      */     //   4274: wide dload #1647
/*      */     //   4278: wide dload #1641
/*      */     //   4282: dmul
/*      */     //   4283: dconst_0
/*      */     //   4284: dcmpg
/*      */     //   4285: iflt -> 4336
/*      */     //   4288: goto -> 4291
/*      */     //   4291: aload_1
/*      */     //   4292: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4295: invokeinterface getDouble : ()D
/*      */     //   4300: wide dstore #1635
/*      */     //   4304: aload_1
/*      */     //   4305: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4308: bipush #16
/*      */     //   4310: invokeinterface getDouble : (I)D
/*      */     //   4315: wide dstore #1629
/*      */     //   4319: wide dload #1635
/*      */     //   4323: wide dload #1629
/*      */     //   4327: dmul
/*      */     //   4328: dconst_0
/*      */     //   4329: dcmpg
/*      */     //   4330: iflt -> 4336
/*      */     //   4333: goto -> 4357
/*      */     //   4336: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4339: dup
/*      */     //   4340: ldc_w '`mgp[1:3]' are of differing sign '
/*      */     //   4343: invokevirtual getBytes : ()[B
/*      */     //   4346: iconst_0
/*      */     //   4347: invokespecial <init> : ([BI)V
/*      */     //   4350: iconst_0
/*      */     //   4351: anewarray java/lang/Object
/*      */     //   4354: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   4357: aload_2
/*      */     //   4358: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4361: wide astore #1625
/*      */     //   4365: aload_2
/*      */     //   4366: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4369: wide astore #1623
/*      */     //   4373: aload_1
/*      */     //   4374: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4377: invokeinterface getDouble : ()D
/*      */     //   4382: wide dstore #1619
/*      */     //   4386: wide aload #1623
/*      */     //   4390: sipush #340
/*      */     //   4393: wide dload #1619
/*      */     //   4397: invokeinterface setDouble : (ID)V
/*      */     //   4402: wide aload #1623
/*      */     //   4406: sipush #340
/*      */     //   4409: invokeinterface getDouble : (I)D
/*      */     //   4414: wide dstore #1617
/*      */     //   4418: wide aload #1625
/*      */     //   4422: sipush #340
/*      */     //   4425: wide dload #1617
/*      */     //   4429: invokeinterface setDouble : (ID)V
/*      */     //   4434: aload_2
/*      */     //   4435: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4438: wide astore #1615
/*      */     //   4442: aload_2
/*      */     //   4443: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4446: wide astore #1613
/*      */     //   4450: aload_1
/*      */     //   4451: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4454: bipush #8
/*      */     //   4456: invokeinterface getDouble : (I)D
/*      */     //   4461: wide dstore #1609
/*      */     //   4465: wide aload #1613
/*      */     //   4469: sipush #348
/*      */     //   4472: wide dload #1609
/*      */     //   4476: invokeinterface setDouble : (ID)V
/*      */     //   4481: wide aload #1613
/*      */     //   4485: sipush #348
/*      */     //   4488: invokeinterface getDouble : (I)D
/*      */     //   4493: wide dstore #1607
/*      */     //   4497: wide aload #1615
/*      */     //   4501: sipush #348
/*      */     //   4504: wide dload #1607
/*      */     //   4508: invokeinterface setDouble : (ID)V
/*      */     //   4513: aload_2
/*      */     //   4514: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4517: wide astore #1605
/*      */     //   4521: aload_2
/*      */     //   4522: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4525: wide astore #1603
/*      */     //   4529: aload_1
/*      */     //   4530: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4533: bipush #16
/*      */     //   4535: invokeinterface getDouble : (I)D
/*      */     //   4540: wide dstore #1599
/*      */     //   4544: wide aload #1603
/*      */     //   4548: sipush #356
/*      */     //   4551: wide dload #1599
/*      */     //   4555: invokeinterface setDouble : (ID)V
/*      */     //   4560: wide aload #1603
/*      */     //   4564: sipush #356
/*      */     //   4567: invokeinterface getDouble : (I)D
/*      */     //   4572: wide dstore #1597
/*      */     //   4576: wide aload #1605
/*      */     //   4580: sipush #356
/*      */     //   4583: wide dload #1597
/*      */     //   4587: invokeinterface setDouble : (ID)V
/*      */     //   4592: goto -> 19275
/*      */     //   4595: aload_0
/*      */     //   4596: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4599: dup
/*      */     //   4600: ldc_w 'mkh '
/*      */     //   4603: invokevirtual getBytes : ()[B
/*      */     //   4606: iconst_0
/*      */     //   4607: invokespecial <init> : ([BI)V
/*      */     //   4610: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4613: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4616: ifeq -> 4622
/*      */     //   4619: goto -> 4705
/*      */     //   4622: aload_0
/*      */     //   4623: aload_1
/*      */     //   4624: iconst_1
/*      */     //   4625: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   4628: aload_1
/*      */     //   4629: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   4632: dstore #18
/*      */     //   4634: dload #18
/*      */     //   4636: aload_0
/*      */     //   4637: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4640: aload_2
/*      */     //   4641: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4644: wide astore #1594
/*      */     //   4648: aload_2
/*      */     //   4649: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4652: wide astore #1592
/*      */     //   4656: wide aload #1592
/*      */     //   4660: sipush #364
/*      */     //   4663: dload #18
/*      */     //   4665: invokeinterface setDouble : (ID)V
/*      */     //   4670: wide aload #1592
/*      */     //   4674: sipush #364
/*      */     //   4677: invokeinterface getDouble : (I)D
/*      */     //   4682: wide dstore #1590
/*      */     //   4686: wide aload #1594
/*      */     //   4690: sipush #364
/*      */     //   4693: wide dload #1590
/*      */     //   4697: invokeinterface setDouble : (ID)V
/*      */     //   4702: goto -> 19275
/*      */     //   4705: aload_0
/*      */     //   4706: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4709: dup
/*      */     //   4710: ldc_w 'pch '
/*      */     //   4713: invokevirtual getBytes : ()[B
/*      */     //   4716: iconst_0
/*      */     //   4717: invokespecial <init> : ([BI)V
/*      */     //   4720: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4723: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4726: ifeq -> 4732
/*      */     //   4729: goto -> 4874
/*      */     //   4732: aload_0
/*      */     //   4733: aload_1
/*      */     //   4734: iconst_1
/*      */     //   4735: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   4738: aload_1
/*      */     //   4739: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   4742: bipush #16
/*      */     //   4744: if_icmpeq -> 4750
/*      */     //   4747: goto -> 4763
/*      */     //   4750: aload_1
/*      */     //   4751: iconst_0
/*      */     //   4752: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   4755: invokestatic GEstring_to_pch : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   4758: istore #17
/*      */     //   4760: goto -> 4786
/*      */     //   4763: aload_1
/*      */     //   4764: invokestatic Rf_isNumeric : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   4767: ifne -> 4773
/*      */     //   4770: goto -> 4782
/*      */     //   4773: aload_1
/*      */     //   4774: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   4777: istore #17
/*      */     //   4779: goto -> 4786
/*      */     //   4782: aload_0
/*      */     //   4783: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4786: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   4789: wide istore #1585
/*      */     //   4793: iload #17
/*      */     //   4795: wide iload #1585
/*      */     //   4799: if_icmpeq -> 4805
/*      */     //   4802: goto -> 4809
/*      */     //   4805: aload_0
/*      */     //   4806: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4809: aload_2
/*      */     //   4810: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4813: wide astore #1583
/*      */     //   4817: aload_2
/*      */     //   4818: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4821: wide astore #1581
/*      */     //   4825: wide aload #1581
/*      */     //   4829: sipush #372
/*      */     //   4832: iload #17
/*      */     //   4834: invokeinterface setInt : (II)V
/*      */     //   4839: wide aload #1581
/*      */     //   4843: sipush #372
/*      */     //   4846: invokeinterface getInt : (I)I
/*      */     //   4851: wide istore #1580
/*      */     //   4855: wide aload #1583
/*      */     //   4859: sipush #372
/*      */     //   4862: wide iload #1580
/*      */     //   4866: invokeinterface setInt : (II)V
/*      */     //   4871: goto -> 19275
/*      */     //   4874: aload_0
/*      */     //   4875: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4878: dup
/*      */     //   4879: ldc_w 'smo '
/*      */     //   4882: invokevirtual getBytes : ()[B
/*      */     //   4885: iconst_0
/*      */     //   4886: invokespecial <init> : ([BI)V
/*      */     //   4889: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   4892: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   4895: ifeq -> 4901
/*      */     //   4898: goto -> 4993
/*      */     //   4901: aload_0
/*      */     //   4902: aload_1
/*      */     //   4903: iconst_1
/*      */     //   4904: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   4907: aload_1
/*      */     //   4908: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   4911: dstore #18
/*      */     //   4913: dload #18
/*      */     //   4915: aload_0
/*      */     //   4916: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   4919: aload_2
/*      */     //   4920: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4923: wide astore #1577
/*      */     //   4927: aload_2
/*      */     //   4928: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   4931: wide astore #1575
/*      */     //   4935: dload #18
/*      */     //   4937: d2i
/*      */     //   4938: wide istore #1574
/*      */     //   4942: wide aload #1575
/*      */     //   4946: sipush #384
/*      */     //   4949: wide iload #1574
/*      */     //   4953: invokeinterface setInt : (II)V
/*      */     //   4958: wide aload #1575
/*      */     //   4962: sipush #384
/*      */     //   4965: invokeinterface getInt : (I)I
/*      */     //   4970: wide istore #1573
/*      */     //   4974: wide aload #1577
/*      */     //   4978: sipush #384
/*      */     //   4981: wide iload #1573
/*      */     //   4985: invokeinterface setInt : (II)V
/*      */     //   4990: goto -> 19275
/*      */     //   4993: aload_0
/*      */     //   4994: new org/renjin/gcc/runtime/BytePtr
/*      */     //   4997: dup
/*      */     //   4998: ldc_w 'srt '
/*      */     //   5001: invokevirtual getBytes : ()[B
/*      */     //   5004: iconst_0
/*      */     //   5005: invokespecial <init> : ([BI)V
/*      */     //   5008: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5011: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   5014: ifeq -> 5020
/*      */     //   5017: goto -> 5103
/*      */     //   5020: aload_0
/*      */     //   5021: aload_1
/*      */     //   5022: iconst_1
/*      */     //   5023: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   5026: aload_1
/*      */     //   5027: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   5030: dstore #18
/*      */     //   5032: dload #18
/*      */     //   5034: aload_0
/*      */     //   5035: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5038: aload_2
/*      */     //   5039: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5042: wide astore #1570
/*      */     //   5046: aload_2
/*      */     //   5047: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5050: wide astore #1568
/*      */     //   5054: wide aload #1568
/*      */     //   5058: sipush #388
/*      */     //   5061: dload #18
/*      */     //   5063: invokeinterface setDouble : (ID)V
/*      */     //   5068: wide aload #1568
/*      */     //   5072: sipush #388
/*      */     //   5075: invokeinterface getDouble : (I)D
/*      */     //   5080: wide dstore #1566
/*      */     //   5084: wide aload #1570
/*      */     //   5088: sipush #388
/*      */     //   5091: wide dload #1566
/*      */     //   5095: invokeinterface setDouble : (ID)V
/*      */     //   5100: goto -> 19275
/*      */     //   5103: aload_0
/*      */     //   5104: new org/renjin/gcc/runtime/BytePtr
/*      */     //   5107: dup
/*      */     //   5108: ldc_w 'tck '
/*      */     //   5111: invokevirtual getBytes : ()[B
/*      */     //   5114: iconst_0
/*      */     //   5115: invokespecial <init> : ([BI)V
/*      */     //   5118: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5121: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   5124: ifeq -> 5130
/*      */     //   5127: goto -> 5376
/*      */     //   5130: aload_0
/*      */     //   5131: aload_1
/*      */     //   5132: iconst_1
/*      */     //   5133: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   5136: aload_1
/*      */     //   5137: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   5140: dstore #18
/*      */     //   5142: aload_2
/*      */     //   5143: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5146: wide astore #1563
/*      */     //   5150: aload_2
/*      */     //   5151: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5154: wide astore #1561
/*      */     //   5158: wide aload #1561
/*      */     //   5162: sipush #396
/*      */     //   5165: dload #18
/*      */     //   5167: invokeinterface setDouble : (ID)V
/*      */     //   5172: wide aload #1561
/*      */     //   5176: sipush #396
/*      */     //   5179: invokeinterface getDouble : (I)D
/*      */     //   5184: wide dstore #1559
/*      */     //   5188: wide aload #1563
/*      */     //   5192: sipush #396
/*      */     //   5195: wide dload #1559
/*      */     //   5199: invokeinterface setDouble : (ID)V
/*      */     //   5204: dload #18
/*      */     //   5206: invokestatic R_finite : (D)I
/*      */     //   5209: ifne -> 5215
/*      */     //   5212: goto -> 5289
/*      */     //   5215: aload_2
/*      */     //   5216: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5219: wide astore #1556
/*      */     //   5223: aload_2
/*      */     //   5224: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5227: wide astore #1554
/*      */     //   5231: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   5234: wide dstore #1552
/*      */     //   5238: wide aload #1554
/*      */     //   5242: sipush #404
/*      */     //   5245: wide dload #1552
/*      */     //   5249: invokeinterface setDouble : (ID)V
/*      */     //   5254: wide aload #1554
/*      */     //   5258: sipush #404
/*      */     //   5261: invokeinterface getDouble : (I)D
/*      */     //   5266: wide dstore #1550
/*      */     //   5270: wide aload #1556
/*      */     //   5274: sipush #404
/*      */     //   5277: wide dload #1550
/*      */     //   5281: invokeinterface setDouble : (ID)V
/*      */     //   5286: goto -> 19275
/*      */     //   5289: aload_2
/*      */     //   5290: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5293: sipush #404
/*      */     //   5296: invokeinterface getDouble : (I)D
/*      */     //   5301: invokestatic R_finite : (D)I
/*      */     //   5304: ifeq -> 5310
/*      */     //   5307: goto -> 19275
/*      */     //   5310: aload_2
/*      */     //   5311: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5314: wide astore #1543
/*      */     //   5318: aload_2
/*      */     //   5319: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5322: wide astore #1541
/*      */     //   5326: wide aload #1541
/*      */     //   5330: sipush #404
/*      */     //   5333: ldc2_w -0.5
/*      */     //   5336: invokeinterface setDouble : (ID)V
/*      */     //   5341: wide aload #1541
/*      */     //   5345: sipush #404
/*      */     //   5348: invokeinterface getDouble : (I)D
/*      */     //   5353: wide dstore #1539
/*      */     //   5357: wide aload #1543
/*      */     //   5361: sipush #404
/*      */     //   5364: wide dload #1539
/*      */     //   5368: invokeinterface setDouble : (ID)V
/*      */     //   5373: goto -> 19275
/*      */     //   5376: aload_0
/*      */     //   5377: new org/renjin/gcc/runtime/BytePtr
/*      */     //   5380: dup
/*      */     //   5381: ldc_w 'tcl '
/*      */     //   5384: invokevirtual getBytes : ()[B
/*      */     //   5387: iconst_0
/*      */     //   5388: invokespecial <init> : ([BI)V
/*      */     //   5391: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5394: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   5397: ifeq -> 5403
/*      */     //   5400: goto -> 5649
/*      */     //   5403: aload_0
/*      */     //   5404: aload_1
/*      */     //   5405: iconst_1
/*      */     //   5406: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   5409: aload_1
/*      */     //   5410: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   5413: dstore #18
/*      */     //   5415: aload_2
/*      */     //   5416: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5419: wide astore #1536
/*      */     //   5423: aload_2
/*      */     //   5424: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5427: wide astore #1534
/*      */     //   5431: wide aload #1534
/*      */     //   5435: sipush #404
/*      */     //   5438: dload #18
/*      */     //   5440: invokeinterface setDouble : (ID)V
/*      */     //   5445: wide aload #1534
/*      */     //   5449: sipush #404
/*      */     //   5452: invokeinterface getDouble : (I)D
/*      */     //   5457: wide dstore #1532
/*      */     //   5461: wide aload #1536
/*      */     //   5465: sipush #404
/*      */     //   5468: wide dload #1532
/*      */     //   5472: invokeinterface setDouble : (ID)V
/*      */     //   5477: dload #18
/*      */     //   5479: invokestatic R_finite : (D)I
/*      */     //   5482: ifne -> 5488
/*      */     //   5485: goto -> 5562
/*      */     //   5488: aload_2
/*      */     //   5489: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5492: wide astore #1529
/*      */     //   5496: aload_2
/*      */     //   5497: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5500: wide astore #1527
/*      */     //   5504: getstatic org/renjin/gnur/api/Arith.R_NaReal : D
/*      */     //   5507: wide dstore #1525
/*      */     //   5511: wide aload #1527
/*      */     //   5515: sipush #396
/*      */     //   5518: wide dload #1525
/*      */     //   5522: invokeinterface setDouble : (ID)V
/*      */     //   5527: wide aload #1527
/*      */     //   5531: sipush #396
/*      */     //   5534: invokeinterface getDouble : (I)D
/*      */     //   5539: wide dstore #1523
/*      */     //   5543: wide aload #1529
/*      */     //   5547: sipush #396
/*      */     //   5550: wide dload #1523
/*      */     //   5554: invokeinterface setDouble : (ID)V
/*      */     //   5559: goto -> 19275
/*      */     //   5562: aload_2
/*      */     //   5563: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5566: sipush #396
/*      */     //   5569: invokeinterface getDouble : (I)D
/*      */     //   5574: invokestatic R_finite : (D)I
/*      */     //   5577: ifeq -> 5583
/*      */     //   5580: goto -> 19275
/*      */     //   5583: aload_2
/*      */     //   5584: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5587: wide astore #1516
/*      */     //   5591: aload_2
/*      */     //   5592: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5595: wide astore #1514
/*      */     //   5599: wide aload #1514
/*      */     //   5603: sipush #396
/*      */     //   5606: ldc2_w -0.01
/*      */     //   5609: invokeinterface setDouble : (ID)V
/*      */     //   5614: wide aload #1514
/*      */     //   5618: sipush #396
/*      */     //   5621: invokeinterface getDouble : (I)D
/*      */     //   5626: wide dstore #1512
/*      */     //   5630: wide aload #1516
/*      */     //   5634: sipush #396
/*      */     //   5637: wide dload #1512
/*      */     //   5641: invokeinterface setDouble : (ID)V
/*      */     //   5646: goto -> 19275
/*      */     //   5649: aload_0
/*      */     //   5650: new org/renjin/gcc/runtime/BytePtr
/*      */     //   5653: dup
/*      */     //   5654: ldc_w 'xaxp '
/*      */     //   5657: invokevirtual getBytes : ()[B
/*      */     //   5660: iconst_0
/*      */     //   5661: invokespecial <init> : ([BI)V
/*      */     //   5664: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   5667: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   5670: ifeq -> 5676
/*      */     //   5673: goto -> 6050
/*      */     //   5676: aload_1
/*      */     //   5677: bipush #14
/*      */     //   5679: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   5682: astore_1
/*      */     //   5683: aload_0
/*      */     //   5684: aload_1
/*      */     //   5685: iconst_3
/*      */     //   5686: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   5689: aload_1
/*      */     //   5690: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5693: invokeinterface getDouble : ()D
/*      */     //   5698: aload_0
/*      */     //   5699: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5702: aload_1
/*      */     //   5703: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5706: bipush #8
/*      */     //   5708: invokeinterface getDouble : (I)D
/*      */     //   5713: aload_0
/*      */     //   5714: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5717: aload_2
/*      */     //   5718: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5721: wide astore #1499
/*      */     //   5725: aload_2
/*      */     //   5726: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5729: sipush #440
/*      */     //   5732: invokeinterface getInt : (I)I
/*      */     //   5737: wide istore #1496
/*      */     //   5741: wide aload #1499
/*      */     //   5745: sipush #440
/*      */     //   5748: wide iload #1496
/*      */     //   5752: invokeinterface setInt : (II)V
/*      */     //   5757: wide aload #1499
/*      */     //   5761: sipush #440
/*      */     //   5764: invokeinterface getInt : (I)I
/*      */     //   5769: ifne -> 5775
/*      */     //   5772: goto -> 5794
/*      */     //   5775: aload_1
/*      */     //   5776: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5779: bipush #16
/*      */     //   5781: invokeinterface getDouble : (I)D
/*      */     //   5786: d2i
/*      */     //   5787: aload_0
/*      */     //   5788: invokestatic logAxpCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5791: goto -> 5810
/*      */     //   5794: aload_1
/*      */     //   5795: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5798: bipush #16
/*      */     //   5800: invokeinterface getDouble : (I)D
/*      */     //   5805: d2i
/*      */     //   5806: aload_0
/*      */     //   5807: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   5810: aload_2
/*      */     //   5811: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5814: wide astore #1479
/*      */     //   5818: aload_2
/*      */     //   5819: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5822: wide astore #1477
/*      */     //   5826: aload_1
/*      */     //   5827: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5830: invokeinterface getDouble : ()D
/*      */     //   5835: wide dstore #1473
/*      */     //   5839: wide aload #1477
/*      */     //   5843: sipush #412
/*      */     //   5846: wide dload #1473
/*      */     //   5850: invokeinterface setDouble : (ID)V
/*      */     //   5855: wide aload #1477
/*      */     //   5859: sipush #412
/*      */     //   5862: invokeinterface getDouble : (I)D
/*      */     //   5867: wide dstore #1471
/*      */     //   5871: wide aload #1479
/*      */     //   5875: sipush #412
/*      */     //   5878: wide dload #1471
/*      */     //   5882: invokeinterface setDouble : (ID)V
/*      */     //   5887: aload_2
/*      */     //   5888: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5891: wide astore #1469
/*      */     //   5895: aload_2
/*      */     //   5896: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5899: wide astore #1467
/*      */     //   5903: aload_1
/*      */     //   5904: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5907: bipush #8
/*      */     //   5909: invokeinterface getDouble : (I)D
/*      */     //   5914: wide dstore #1463
/*      */     //   5918: wide aload #1467
/*      */     //   5922: sipush #420
/*      */     //   5925: wide dload #1463
/*      */     //   5929: invokeinterface setDouble : (ID)V
/*      */     //   5934: wide aload #1467
/*      */     //   5938: sipush #420
/*      */     //   5941: invokeinterface getDouble : (I)D
/*      */     //   5946: wide dstore #1461
/*      */     //   5950: wide aload #1469
/*      */     //   5954: sipush #420
/*      */     //   5957: wide dload #1461
/*      */     //   5961: invokeinterface setDouble : (ID)V
/*      */     //   5966: aload_2
/*      */     //   5967: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5970: wide astore #1459
/*      */     //   5974: aload_2
/*      */     //   5975: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5978: wide astore #1457
/*      */     //   5982: aload_1
/*      */     //   5983: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   5986: bipush #16
/*      */     //   5988: invokeinterface getDouble : (I)D
/*      */     //   5993: d2i
/*      */     //   5994: i2d
/*      */     //   5995: wide dstore #1448
/*      */     //   5999: wide aload #1457
/*      */     //   6003: sipush #428
/*      */     //   6006: wide dload #1448
/*      */     //   6010: invokeinterface setDouble : (ID)V
/*      */     //   6015: wide aload #1457
/*      */     //   6019: sipush #428
/*      */     //   6022: invokeinterface getDouble : (I)D
/*      */     //   6027: wide dstore #1446
/*      */     //   6031: wide aload #1459
/*      */     //   6035: sipush #428
/*      */     //   6038: wide dload #1446
/*      */     //   6042: invokeinterface setDouble : (ID)V
/*      */     //   6047: goto -> 19275
/*      */     //   6050: aload_0
/*      */     //   6051: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6054: dup
/*      */     //   6055: ldc_w 'xaxs '
/*      */     //   6058: invokevirtual getBytes : ()[B
/*      */     //   6061: iconst_0
/*      */     //   6062: invokespecial <init> : ([BI)V
/*      */     //   6065: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6068: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   6071: ifeq -> 6077
/*      */     //   6074: goto -> 6242
/*      */     //   6077: aload_1
/*      */     //   6078: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   6081: bipush #16
/*      */     //   6083: if_icmpne -> 6099
/*      */     //   6086: goto -> 6089
/*      */     //   6089: aload_1
/*      */     //   6090: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   6093: ifle -> 6099
/*      */     //   6096: goto -> 6103
/*      */     //   6099: aload_0
/*      */     //   6100: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6103: aload_1
/*      */     //   6104: iconst_0
/*      */     //   6105: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   6108: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   6111: invokeinterface getByte : ()B
/*      */     //   6116: istore #16
/*      */     //   6118: iload #16
/*      */     //   6120: bipush #115
/*      */     //   6122: i2b
/*      */     //   6123: if_icmpeq -> 6173
/*      */     //   6126: goto -> 6129
/*      */     //   6129: iload #16
/*      */     //   6131: bipush #101
/*      */     //   6133: i2b
/*      */     //   6134: if_icmpeq -> 6173
/*      */     //   6137: goto -> 6140
/*      */     //   6140: iload #16
/*      */     //   6142: bipush #105
/*      */     //   6144: i2b
/*      */     //   6145: if_icmpeq -> 6173
/*      */     //   6148: goto -> 6151
/*      */     //   6151: iload #16
/*      */     //   6153: bipush #114
/*      */     //   6155: i2b
/*      */     //   6156: if_icmpeq -> 6173
/*      */     //   6159: goto -> 6162
/*      */     //   6162: iload #16
/*      */     //   6164: bipush #100
/*      */     //   6166: i2b
/*      */     //   6167: if_icmpeq -> 6173
/*      */     //   6170: goto -> 6238
/*      */     //   6173: aload_2
/*      */     //   6174: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6177: wide astore #1438
/*      */     //   6181: aload_2
/*      */     //   6182: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6185: wide astore #1436
/*      */     //   6189: wide aload #1436
/*      */     //   6193: sipush #436
/*      */     //   6196: iload #16
/*      */     //   6198: invokeinterface setByte : (IB)V
/*      */     //   6203: wide aload #1436
/*      */     //   6207: sipush #436
/*      */     //   6210: invokeinterface getByte : (I)B
/*      */     //   6215: wide istore #1435
/*      */     //   6219: wide aload #1438
/*      */     //   6223: sipush #436
/*      */     //   6226: wide iload #1435
/*      */     //   6230: invokeinterface setByte : (IB)V
/*      */     //   6235: goto -> 19275
/*      */     //   6238: aload_0
/*      */     //   6239: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6242: aload_0
/*      */     //   6243: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6246: dup
/*      */     //   6247: ldc_w 'xaxt '
/*      */     //   6250: invokevirtual getBytes : ()[B
/*      */     //   6253: iconst_0
/*      */     //   6254: invokespecial <init> : ([BI)V
/*      */     //   6257: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6260: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   6263: ifeq -> 6269
/*      */     //   6266: goto -> 6423
/*      */     //   6269: aload_1
/*      */     //   6270: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   6273: bipush #16
/*      */     //   6275: if_icmpne -> 6291
/*      */     //   6278: goto -> 6281
/*      */     //   6281: aload_1
/*      */     //   6282: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   6285: ifle -> 6291
/*      */     //   6288: goto -> 6295
/*      */     //   6291: aload_0
/*      */     //   6292: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6295: aload_1
/*      */     //   6296: iconst_0
/*      */     //   6297: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   6300: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   6303: invokeinterface getByte : ()B
/*      */     //   6308: istore #16
/*      */     //   6310: iload #16
/*      */     //   6312: bipush #115
/*      */     //   6314: i2b
/*      */     //   6315: if_icmpeq -> 6354
/*      */     //   6318: goto -> 6321
/*      */     //   6321: iload #16
/*      */     //   6323: bipush #108
/*      */     //   6325: i2b
/*      */     //   6326: if_icmpeq -> 6354
/*      */     //   6329: goto -> 6332
/*      */     //   6332: iload #16
/*      */     //   6334: bipush #116
/*      */     //   6336: i2b
/*      */     //   6337: if_icmpeq -> 6354
/*      */     //   6340: goto -> 6343
/*      */     //   6343: iload #16
/*      */     //   6345: bipush #110
/*      */     //   6347: i2b
/*      */     //   6348: if_icmpeq -> 6354
/*      */     //   6351: goto -> 6419
/*      */     //   6354: aload_2
/*      */     //   6355: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6358: wide astore #1427
/*      */     //   6362: aload_2
/*      */     //   6363: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6366: wide astore #1425
/*      */     //   6370: wide aload #1425
/*      */     //   6374: sipush #437
/*      */     //   6377: iload #16
/*      */     //   6379: invokeinterface setByte : (IB)V
/*      */     //   6384: wide aload #1425
/*      */     //   6388: sipush #437
/*      */     //   6391: invokeinterface getByte : (I)B
/*      */     //   6396: wide istore #1424
/*      */     //   6400: wide aload #1427
/*      */     //   6404: sipush #437
/*      */     //   6407: wide iload #1424
/*      */     //   6411: invokeinterface setByte : (IB)V
/*      */     //   6416: goto -> 19275
/*      */     //   6419: aload_0
/*      */     //   6420: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6423: aload_0
/*      */     //   6424: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6427: dup
/*      */     //   6428: ldc_w 'xpd '
/*      */     //   6431: invokevirtual getBytes : ()[B
/*      */     //   6434: iconst_0
/*      */     //   6435: invokespecial <init> : ([BI)V
/*      */     //   6438: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6441: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   6444: ifeq -> 6450
/*      */     //   6447: goto -> 6629
/*      */     //   6450: aload_0
/*      */     //   6451: aload_1
/*      */     //   6452: iconst_1
/*      */     //   6453: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   6456: aload_1
/*      */     //   6457: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   6460: istore #17
/*      */     //   6462: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   6465: wide istore #1422
/*      */     //   6469: iload #17
/*      */     //   6471: wide iload #1422
/*      */     //   6475: if_icmpeq -> 6481
/*      */     //   6478: goto -> 6545
/*      */     //   6481: aload_2
/*      */     //   6482: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6485: wide astore #1420
/*      */     //   6489: aload_2
/*      */     //   6490: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6493: wide astore #1418
/*      */     //   6497: wide aload #1418
/*      */     //   6501: sipush #444
/*      */     //   6504: iconst_2
/*      */     //   6505: invokeinterface setInt : (II)V
/*      */     //   6510: wide aload #1418
/*      */     //   6514: sipush #444
/*      */     //   6517: invokeinterface getInt : (I)I
/*      */     //   6522: wide istore #1417
/*      */     //   6526: wide aload #1420
/*      */     //   6530: sipush #444
/*      */     //   6533: wide iload #1417
/*      */     //   6537: invokeinterface setInt : (II)V
/*      */     //   6542: goto -> 19275
/*      */     //   6545: aload_2
/*      */     //   6546: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6549: wide astore #1415
/*      */     //   6553: aload_2
/*      */     //   6554: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6557: wide astore #1413
/*      */     //   6561: iload #17
/*      */     //   6563: ifne -> 6573
/*      */     //   6566: goto -> 6569
/*      */     //   6569: iconst_0
/*      */     //   6570: goto -> 6574
/*      */     //   6573: iconst_1
/*      */     //   6574: wide istore #1411
/*      */     //   6578: wide aload #1413
/*      */     //   6582: sipush #444
/*      */     //   6585: wide iload #1411
/*      */     //   6589: invokeinterface setInt : (II)V
/*      */     //   6594: wide aload #1413
/*      */     //   6598: sipush #444
/*      */     //   6601: invokeinterface getInt : (I)I
/*      */     //   6606: wide istore #1410
/*      */     //   6610: wide aload #1415
/*      */     //   6614: sipush #444
/*      */     //   6617: wide iload #1410
/*      */     //   6621: invokeinterface setInt : (II)V
/*      */     //   6626: goto -> 19275
/*      */     //   6629: aload_0
/*      */     //   6630: new org/renjin/gcc/runtime/BytePtr
/*      */     //   6633: dup
/*      */     //   6634: ldc_w 'yaxp '
/*      */     //   6637: invokevirtual getBytes : ()[B
/*      */     //   6640: iconst_0
/*      */     //   6641: invokespecial <init> : ([BI)V
/*      */     //   6644: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   6647: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   6650: ifeq -> 6656
/*      */     //   6653: goto -> 7030
/*      */     //   6656: aload_1
/*      */     //   6657: bipush #14
/*      */     //   6659: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   6662: astore_1
/*      */     //   6663: aload_0
/*      */     //   6664: aload_1
/*      */     //   6665: iconst_3
/*      */     //   6666: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   6669: aload_1
/*      */     //   6670: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6673: invokeinterface getDouble : ()D
/*      */     //   6678: aload_0
/*      */     //   6679: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6682: aload_1
/*      */     //   6683: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6686: bipush #8
/*      */     //   6688: invokeinterface getDouble : (I)D
/*      */     //   6693: aload_0
/*      */     //   6694: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6697: aload_2
/*      */     //   6698: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6701: wide astore #1397
/*      */     //   6705: aload_2
/*      */     //   6706: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6709: sipush #480
/*      */     //   6712: invokeinterface getInt : (I)I
/*      */     //   6717: wide istore #1394
/*      */     //   6721: wide aload #1397
/*      */     //   6725: sipush #480
/*      */     //   6728: wide iload #1394
/*      */     //   6732: invokeinterface setInt : (II)V
/*      */     //   6737: wide aload #1397
/*      */     //   6741: sipush #480
/*      */     //   6744: invokeinterface getInt : (I)I
/*      */     //   6749: ifne -> 6755
/*      */     //   6752: goto -> 6774
/*      */     //   6755: aload_1
/*      */     //   6756: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6759: bipush #16
/*      */     //   6761: invokeinterface getDouble : (I)D
/*      */     //   6766: d2i
/*      */     //   6767: aload_0
/*      */     //   6768: invokestatic logAxpCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6771: goto -> 6790
/*      */     //   6774: aload_1
/*      */     //   6775: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6778: bipush #16
/*      */     //   6780: invokeinterface getDouble : (I)D
/*      */     //   6785: d2i
/*      */     //   6786: aload_0
/*      */     //   6787: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   6790: aload_2
/*      */     //   6791: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6794: wide astore #1377
/*      */     //   6798: aload_2
/*      */     //   6799: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6802: wide astore #1375
/*      */     //   6806: aload_1
/*      */     //   6807: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6810: invokeinterface getDouble : ()D
/*      */     //   6815: wide dstore #1371
/*      */     //   6819: wide aload #1375
/*      */     //   6823: sipush #452
/*      */     //   6826: wide dload #1371
/*      */     //   6830: invokeinterface setDouble : (ID)V
/*      */     //   6835: wide aload #1375
/*      */     //   6839: sipush #452
/*      */     //   6842: invokeinterface getDouble : (I)D
/*      */     //   6847: wide dstore #1369
/*      */     //   6851: wide aload #1377
/*      */     //   6855: sipush #452
/*      */     //   6858: wide dload #1369
/*      */     //   6862: invokeinterface setDouble : (ID)V
/*      */     //   6867: aload_2
/*      */     //   6868: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6871: wide astore #1367
/*      */     //   6875: aload_2
/*      */     //   6876: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6879: wide astore #1365
/*      */     //   6883: aload_1
/*      */     //   6884: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6887: bipush #8
/*      */     //   6889: invokeinterface getDouble : (I)D
/*      */     //   6894: wide dstore #1361
/*      */     //   6898: wide aload #1365
/*      */     //   6902: sipush #460
/*      */     //   6905: wide dload #1361
/*      */     //   6909: invokeinterface setDouble : (ID)V
/*      */     //   6914: wide aload #1365
/*      */     //   6918: sipush #460
/*      */     //   6921: invokeinterface getDouble : (I)D
/*      */     //   6926: wide dstore #1359
/*      */     //   6930: wide aload #1367
/*      */     //   6934: sipush #460
/*      */     //   6937: wide dload #1359
/*      */     //   6941: invokeinterface setDouble : (ID)V
/*      */     //   6946: aload_2
/*      */     //   6947: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6950: wide astore #1357
/*      */     //   6954: aload_2
/*      */     //   6955: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6958: wide astore #1355
/*      */     //   6962: aload_1
/*      */     //   6963: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6966: bipush #16
/*      */     //   6968: invokeinterface getDouble : (I)D
/*      */     //   6973: d2i
/*      */     //   6974: i2d
/*      */     //   6975: wide dstore #1346
/*      */     //   6979: wide aload #1355
/*      */     //   6983: sipush #468
/*      */     //   6986: wide dload #1346
/*      */     //   6990: invokeinterface setDouble : (ID)V
/*      */     //   6995: wide aload #1355
/*      */     //   6999: sipush #468
/*      */     //   7002: invokeinterface getDouble : (I)D
/*      */     //   7007: wide dstore #1344
/*      */     //   7011: wide aload #1357
/*      */     //   7015: sipush #468
/*      */     //   7018: wide dload #1344
/*      */     //   7022: invokeinterface setDouble : (ID)V
/*      */     //   7027: goto -> 19275
/*      */     //   7030: aload_0
/*      */     //   7031: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7034: dup
/*      */     //   7035: ldc_w 'yaxs '
/*      */     //   7038: invokevirtual getBytes : ()[B
/*      */     //   7041: iconst_0
/*      */     //   7042: invokespecial <init> : ([BI)V
/*      */     //   7045: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7048: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   7051: ifeq -> 7057
/*      */     //   7054: goto -> 7222
/*      */     //   7057: aload_1
/*      */     //   7058: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7061: bipush #16
/*      */     //   7063: if_icmpne -> 7079
/*      */     //   7066: goto -> 7069
/*      */     //   7069: aload_1
/*      */     //   7070: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7073: ifle -> 7079
/*      */     //   7076: goto -> 7083
/*      */     //   7079: aload_0
/*      */     //   7080: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7083: aload_1
/*      */     //   7084: iconst_0
/*      */     //   7085: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   7088: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   7091: invokeinterface getByte : ()B
/*      */     //   7096: istore #16
/*      */     //   7098: iload #16
/*      */     //   7100: bipush #115
/*      */     //   7102: i2b
/*      */     //   7103: if_icmpeq -> 7153
/*      */     //   7106: goto -> 7109
/*      */     //   7109: iload #16
/*      */     //   7111: bipush #101
/*      */     //   7113: i2b
/*      */     //   7114: if_icmpeq -> 7153
/*      */     //   7117: goto -> 7120
/*      */     //   7120: iload #16
/*      */     //   7122: bipush #105
/*      */     //   7124: i2b
/*      */     //   7125: if_icmpeq -> 7153
/*      */     //   7128: goto -> 7131
/*      */     //   7131: iload #16
/*      */     //   7133: bipush #114
/*      */     //   7135: i2b
/*      */     //   7136: if_icmpeq -> 7153
/*      */     //   7139: goto -> 7142
/*      */     //   7142: iload #16
/*      */     //   7144: bipush #100
/*      */     //   7146: i2b
/*      */     //   7147: if_icmpeq -> 7153
/*      */     //   7150: goto -> 7218
/*      */     //   7153: aload_2
/*      */     //   7154: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7157: wide astore #1336
/*      */     //   7161: aload_2
/*      */     //   7162: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7165: wide astore #1334
/*      */     //   7169: wide aload #1334
/*      */     //   7173: sipush #476
/*      */     //   7176: iload #16
/*      */     //   7178: invokeinterface setByte : (IB)V
/*      */     //   7183: wide aload #1334
/*      */     //   7187: sipush #476
/*      */     //   7190: invokeinterface getByte : (I)B
/*      */     //   7195: wide istore #1333
/*      */     //   7199: wide aload #1336
/*      */     //   7203: sipush #476
/*      */     //   7206: wide iload #1333
/*      */     //   7210: invokeinterface setByte : (IB)V
/*      */     //   7215: goto -> 19275
/*      */     //   7218: aload_0
/*      */     //   7219: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7222: aload_0
/*      */     //   7223: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7226: dup
/*      */     //   7227: ldc_w 'yaxt '
/*      */     //   7230: invokevirtual getBytes : ()[B
/*      */     //   7233: iconst_0
/*      */     //   7234: invokespecial <init> : ([BI)V
/*      */     //   7237: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7240: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   7243: ifeq -> 7249
/*      */     //   7246: goto -> 7403
/*      */     //   7249: aload_1
/*      */     //   7250: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7253: bipush #16
/*      */     //   7255: if_icmpne -> 7271
/*      */     //   7258: goto -> 7261
/*      */     //   7261: aload_1
/*      */     //   7262: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7265: ifle -> 7271
/*      */     //   7268: goto -> 7275
/*      */     //   7271: aload_0
/*      */     //   7272: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7275: aload_1
/*      */     //   7276: iconst_0
/*      */     //   7277: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   7280: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   7283: invokeinterface getByte : ()B
/*      */     //   7288: istore #16
/*      */     //   7290: iload #16
/*      */     //   7292: bipush #115
/*      */     //   7294: i2b
/*      */     //   7295: if_icmpeq -> 7334
/*      */     //   7298: goto -> 7301
/*      */     //   7301: iload #16
/*      */     //   7303: bipush #108
/*      */     //   7305: i2b
/*      */     //   7306: if_icmpeq -> 7334
/*      */     //   7309: goto -> 7312
/*      */     //   7312: iload #16
/*      */     //   7314: bipush #116
/*      */     //   7316: i2b
/*      */     //   7317: if_icmpeq -> 7334
/*      */     //   7320: goto -> 7323
/*      */     //   7323: iload #16
/*      */     //   7325: bipush #110
/*      */     //   7327: i2b
/*      */     //   7328: if_icmpeq -> 7334
/*      */     //   7331: goto -> 7399
/*      */     //   7334: aload_2
/*      */     //   7335: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7338: wide astore #1325
/*      */     //   7342: aload_2
/*      */     //   7343: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7346: wide astore #1323
/*      */     //   7350: wide aload #1323
/*      */     //   7354: sipush #477
/*      */     //   7357: iload #16
/*      */     //   7359: invokeinterface setByte : (IB)V
/*      */     //   7364: wide aload #1323
/*      */     //   7368: sipush #477
/*      */     //   7371: invokeinterface getByte : (I)B
/*      */     //   7376: wide istore #1322
/*      */     //   7380: wide aload #1325
/*      */     //   7384: sipush #477
/*      */     //   7387: wide iload #1322
/*      */     //   7391: invokeinterface setByte : (IB)V
/*      */     //   7396: goto -> 19275
/*      */     //   7399: aload_0
/*      */     //   7400: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   7403: aload_0
/*      */     //   7404: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7407: dup
/*      */     //   7408: ldc_w 'bg '
/*      */     //   7411: invokevirtual getBytes : ()[B
/*      */     //   7414: iconst_0
/*      */     //   7415: invokespecial <init> : ([BI)V
/*      */     //   7418: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7421: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   7424: ifeq -> 7430
/*      */     //   7427: goto -> 7599
/*      */     //   7430: aload_0
/*      */     //   7431: aload_1
/*      */     //   7432: iconst_1
/*      */     //   7433: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   7436: aload_2
/*      */     //   7437: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7440: bipush #20
/*      */     //   7442: invokeinterface getInt : (I)I
/*      */     //   7447: wide istore #1318
/*      */     //   7451: aload_1
/*      */     //   7452: iconst_0
/*      */     //   7453: wide iload #1318
/*      */     //   7457: invokestatic Rf_RGBpar3 : (Lorg/renjin/sexp/SEXP;II)I
/*      */     //   7460: istore #17
/*      */     //   7462: aload_2
/*      */     //   7463: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7466: wide astore #1315
/*      */     //   7470: aload_2
/*      */     //   7471: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7474: wide astore #1313
/*      */     //   7478: iload #17
/*      */     //   7480: wide istore #1312
/*      */     //   7484: wide aload #1313
/*      */     //   7488: bipush #20
/*      */     //   7490: wide iload #1312
/*      */     //   7494: invokeinterface setInt : (II)V
/*      */     //   7499: wide aload #1313
/*      */     //   7503: bipush #20
/*      */     //   7505: invokeinterface getInt : (I)I
/*      */     //   7510: wide istore #1311
/*      */     //   7514: wide aload #1315
/*      */     //   7518: bipush #20
/*      */     //   7520: wide iload #1311
/*      */     //   7524: invokeinterface setInt : (II)V
/*      */     //   7529: aload_2
/*      */     //   7530: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7533: wide astore #1309
/*      */     //   7537: aload_2
/*      */     //   7538: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7541: wide astore #1307
/*      */     //   7545: wide aload #1307
/*      */     //   7549: iconst_0
/*      */     //   7550: ldc_w 35764
/*      */     //   7553: iadd
/*      */     //   7554: iconst_0
/*      */     //   7555: invokeinterface setInt : (II)V
/*      */     //   7560: wide aload #1307
/*      */     //   7564: iconst_0
/*      */     //   7565: ldc_w 35764
/*      */     //   7568: iadd
/*      */     //   7569: invokeinterface getInt : (I)I
/*      */     //   7574: wide istore #1306
/*      */     //   7578: wide aload #1309
/*      */     //   7582: iconst_0
/*      */     //   7583: ldc_w 35764
/*      */     //   7586: iadd
/*      */     //   7587: wide iload #1306
/*      */     //   7591: invokeinterface setInt : (II)V
/*      */     //   7596: goto -> 19275
/*      */     //   7599: aload_0
/*      */     //   7600: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7603: dup
/*      */     //   7604: ldc_w 'ask '
/*      */     //   7607: invokevirtual getBytes : ()[B
/*      */     //   7610: iconst_0
/*      */     //   7611: invokespecial <init> : ([BI)V
/*      */     //   7614: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7617: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   7620: ifeq -> 7626
/*      */     //   7623: goto -> 7671
/*      */     //   7626: aload_0
/*      */     //   7627: aload_1
/*      */     //   7628: iconst_1
/*      */     //   7629: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   7632: aload_1
/*      */     //   7633: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   7636: istore #17
/*      */     //   7638: iload #17
/*      */     //   7640: iconst_1
/*      */     //   7641: if_icmpeq -> 7651
/*      */     //   7644: goto -> 7647
/*      */     //   7647: iconst_0
/*      */     //   7648: goto -> 7652
/*      */     //   7651: iconst_1
/*      */     //   7652: wide istore #1303
/*      */     //   7656: aload_2
/*      */     //   7657: bipush #31
/*      */     //   7659: wide iload #1303
/*      */     //   7663: invokeinterface setAlignedInt : (II)V
/*      */     //   7668: goto -> 19275
/*      */     //   7671: aload_0
/*      */     //   7672: new org/renjin/gcc/runtime/BytePtr
/*      */     //   7675: dup
/*      */     //   7676: ldc_w 'fig '
/*      */     //   7679: invokevirtual getBytes : ()[B
/*      */     //   7682: iconst_0
/*      */     //   7683: invokespecial <init> : ([BI)V
/*      */     //   7686: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   7689: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   7692: ifeq -> 7698
/*      */     //   7695: goto -> 8992
/*      */     //   7698: aload_1
/*      */     //   7699: bipush #14
/*      */     //   7701: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   7704: astore_1
/*      */     //   7705: aload_0
/*      */     //   7706: aload_1
/*      */     //   7707: iconst_4
/*      */     //   7708: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   7711: aload_1
/*      */     //   7712: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7715: invokeinterface getDouble : ()D
/*      */     //   7720: dconst_0
/*      */     //   7721: dcmpl
/*      */     //   7722: ifge -> 7728
/*      */     //   7725: goto -> 8988
/*      */     //   7728: aload_1
/*      */     //   7729: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7732: invokeinterface getDouble : ()D
/*      */     //   7737: wide dstore #1294
/*      */     //   7741: aload_1
/*      */     //   7742: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7745: bipush #8
/*      */     //   7747: invokeinterface getDouble : (I)D
/*      */     //   7752: wide dstore #1288
/*      */     //   7756: wide dload #1294
/*      */     //   7760: wide dload #1288
/*      */     //   7764: dcmpg
/*      */     //   7765: iflt -> 7771
/*      */     //   7768: goto -> 8988
/*      */     //   7771: aload_1
/*      */     //   7772: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7775: bipush #8
/*      */     //   7777: invokeinterface getDouble : (I)D
/*      */     //   7782: dconst_1
/*      */     //   7783: dcmpg
/*      */     //   7784: ifle -> 7790
/*      */     //   7787: goto -> 8988
/*      */     //   7790: aload_1
/*      */     //   7791: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7794: bipush #16
/*      */     //   7796: invokeinterface getDouble : (I)D
/*      */     //   7801: dconst_0
/*      */     //   7802: dcmpl
/*      */     //   7803: ifge -> 7809
/*      */     //   7806: goto -> 8988
/*      */     //   7809: aload_1
/*      */     //   7810: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7813: bipush #16
/*      */     //   7815: invokeinterface getDouble : (I)D
/*      */     //   7820: wide dstore #1270
/*      */     //   7824: aload_1
/*      */     //   7825: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7828: bipush #24
/*      */     //   7830: invokeinterface getDouble : (I)D
/*      */     //   7835: wide dstore #1264
/*      */     //   7839: wide dload #1270
/*      */     //   7843: wide dload #1264
/*      */     //   7847: dcmpg
/*      */     //   7848: iflt -> 7854
/*      */     //   7851: goto -> 8988
/*      */     //   7854: aload_1
/*      */     //   7855: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7858: bipush #24
/*      */     //   7860: invokeinterface getDouble : (I)D
/*      */     //   7865: dconst_1
/*      */     //   7866: dcmpg
/*      */     //   7867: ifle -> 7873
/*      */     //   7870: goto -> 8988
/*      */     //   7873: aload_2
/*      */     //   7874: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7877: wide astore #1256
/*      */     //   7881: aload_2
/*      */     //   7882: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7885: wide astore #1254
/*      */     //   7889: wide aload #1254
/*      */     //   7893: iconst_0
/*      */     //   7894: ldc 35512
/*      */     //   7896: iadd
/*      */     //   7897: iconst_0
/*      */     //   7898: invokeinterface setInt : (II)V
/*      */     //   7903: wide aload #1254
/*      */     //   7907: iconst_0
/*      */     //   7908: ldc 35512
/*      */     //   7910: iadd
/*      */     //   7911: invokeinterface getInt : (I)I
/*      */     //   7916: wide istore #1253
/*      */     //   7920: wide aload #1256
/*      */     //   7924: iconst_0
/*      */     //   7925: ldc 35512
/*      */     //   7927: iadd
/*      */     //   7928: wide iload #1253
/*      */     //   7932: invokeinterface setInt : (II)V
/*      */     //   7937: aload_2
/*      */     //   7938: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7941: wide astore #1251
/*      */     //   7945: aload_2
/*      */     //   7946: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   7949: wide astore #1249
/*      */     //   7953: wide aload #1249
/*      */     //   7957: iconst_0
/*      */     //   7958: ldc_w 35456
/*      */     //   7961: iadd
/*      */     //   7962: bipush #6
/*      */     //   7964: invokeinterface setInt : (II)V
/*      */     //   7969: wide aload #1249
/*      */     //   7973: iconst_0
/*      */     //   7974: ldc_w 35456
/*      */     //   7977: iadd
/*      */     //   7978: invokeinterface getInt : (I)I
/*      */     //   7983: wide istore #1248
/*      */     //   7987: wide aload #1251
/*      */     //   7991: iconst_0
/*      */     //   7992: ldc_w 35456
/*      */     //   7995: iadd
/*      */     //   7996: wide iload #1248
/*      */     //   8000: invokeinterface setInt : (II)V
/*      */     //   8005: aload_2
/*      */     //   8006: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8009: wide astore #1246
/*      */     //   8013: aload_2
/*      */     //   8014: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8017: wide astore #1244
/*      */     //   8021: wide aload #1244
/*      */     //   8025: sipush #560
/*      */     //   8028: iconst_1
/*      */     //   8029: invokeinterface setInt : (II)V
/*      */     //   8034: wide aload #1244
/*      */     //   8038: sipush #560
/*      */     //   8041: invokeinterface getInt : (I)I
/*      */     //   8046: wide istore #1243
/*      */     //   8050: wide aload #1246
/*      */     //   8054: sipush #560
/*      */     //   8057: wide iload #1243
/*      */     //   8061: invokeinterface setInt : (II)V
/*      */     //   8066: aload_2
/*      */     //   8067: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8070: wide astore #1241
/*      */     //   8074: aload_2
/*      */     //   8075: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8078: wide astore #1239
/*      */     //   8082: wide aload #1239
/*      */     //   8086: sipush #564
/*      */     //   8089: iconst_1
/*      */     //   8090: invokeinterface setInt : (II)V
/*      */     //   8095: wide aload #1239
/*      */     //   8099: sipush #564
/*      */     //   8102: invokeinterface getInt : (I)I
/*      */     //   8107: wide istore #1238
/*      */     //   8111: wide aload #1241
/*      */     //   8115: sipush #564
/*      */     //   8118: wide iload #1238
/*      */     //   8122: invokeinterface setInt : (II)V
/*      */     //   8127: aload_2
/*      */     //   8128: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8131: wide astore #1236
/*      */     //   8135: aload_2
/*      */     //   8136: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8139: wide astore #1234
/*      */     //   8143: wide aload #1234
/*      */     //   8147: sipush #576
/*      */     //   8150: dconst_1
/*      */     //   8151: invokeinterface setDouble : (ID)V
/*      */     //   8156: wide aload #1234
/*      */     //   8160: sipush #576
/*      */     //   8163: invokeinterface getDouble : (I)D
/*      */     //   8168: wide dstore #1232
/*      */     //   8172: wide aload #1236
/*      */     //   8176: sipush #576
/*      */     //   8179: wide dload #1232
/*      */     //   8183: invokeinterface setDouble : (ID)V
/*      */     //   8188: aload_2
/*      */     //   8189: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8192: wide astore #1230
/*      */     //   8196: aload_2
/*      */     //   8197: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8200: wide astore #1228
/*      */     //   8204: wide aload #1228
/*      */     //   8208: sipush #2176
/*      */     //   8211: dconst_1
/*      */     //   8212: invokeinterface setDouble : (ID)V
/*      */     //   8217: wide aload #1228
/*      */     //   8221: sipush #2176
/*      */     //   8224: invokeinterface getDouble : (I)D
/*      */     //   8229: wide dstore #1226
/*      */     //   8233: wide aload #1230
/*      */     //   8237: sipush #2176
/*      */     //   8240: wide dload #1226
/*      */     //   8244: invokeinterface setDouble : (ID)V
/*      */     //   8249: aload_2
/*      */     //   8250: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8253: wide astore #1224
/*      */     //   8257: aload_2
/*      */     //   8258: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8261: wide astore #1222
/*      */     //   8265: wide aload #1222
/*      */     //   8269: sipush #3776
/*      */     //   8272: iconst_0
/*      */     //   8273: invokeinterface setInt : (II)V
/*      */     //   8278: wide aload #1222
/*      */     //   8282: sipush #3776
/*      */     //   8285: invokeinterface getInt : (I)I
/*      */     //   8290: wide istore #1221
/*      */     //   8294: wide aload #1224
/*      */     //   8298: sipush #3776
/*      */     //   8301: wide iload #1221
/*      */     //   8305: invokeinterface setInt : (II)V
/*      */     //   8310: aload_2
/*      */     //   8311: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8314: wide astore #1219
/*      */     //   8318: aload_2
/*      */     //   8319: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8322: wide astore #1217
/*      */     //   8326: wide aload #1217
/*      */     //   8330: sipush #4576
/*      */     //   8333: iconst_0
/*      */     //   8334: invokeinterface setInt : (II)V
/*      */     //   8339: wide aload #1217
/*      */     //   8343: sipush #4576
/*      */     //   8346: invokeinterface getInt : (I)I
/*      */     //   8351: wide istore #1216
/*      */     //   8355: wide aload #1219
/*      */     //   8359: sipush #4576
/*      */     //   8362: wide iload #1216
/*      */     //   8366: invokeinterface setInt : (II)V
/*      */     //   8371: aload_2
/*      */     //   8372: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8375: wide astore #1214
/*      */     //   8379: aload_2
/*      */     //   8380: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8383: wide astore #1212
/*      */     //   8387: wide aload #1212
/*      */     //   8391: sipush #5376
/*      */     //   8394: iconst_1
/*      */     //   8395: i2c
/*      */     //   8396: invokeinterface setChar : (IC)V
/*      */     //   8401: wide aload #1212
/*      */     //   8405: sipush #5376
/*      */     //   8408: invokeinterface getChar : (I)C
/*      */     //   8413: wide istore #1211
/*      */     //   8417: wide aload #1214
/*      */     //   8421: sipush #5376
/*      */     //   8424: wide iload #1211
/*      */     //   8428: invokeinterface setChar : (IC)V
/*      */     //   8433: aload_2
/*      */     //   8434: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8437: wide astore #1209
/*      */     //   8441: aload_2
/*      */     //   8442: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8445: wide astore #1207
/*      */     //   8449: wide aload #1207
/*      */     //   8453: sipush #568
/*      */     //   8456: iconst_1
/*      */     //   8457: invokeinterface setInt : (II)V
/*      */     //   8462: wide aload #1207
/*      */     //   8466: sipush #568
/*      */     //   8469: invokeinterface getInt : (I)I
/*      */     //   8474: wide istore #1206
/*      */     //   8478: wide aload #1209
/*      */     //   8482: sipush #568
/*      */     //   8485: wide iload #1206
/*      */     //   8489: invokeinterface setInt : (II)V
/*      */     //   8494: aload_2
/*      */     //   8495: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8498: wide astore #1204
/*      */     //   8502: aload_2
/*      */     //   8503: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8506: wide astore #1202
/*      */     //   8510: wide aload #1202
/*      */     //   8514: sipush #572
/*      */     //   8517: iconst_1
/*      */     //   8518: invokeinterface setInt : (II)V
/*      */     //   8523: wide aload #1202
/*      */     //   8527: sipush #572
/*      */     //   8530: invokeinterface getInt : (I)I
/*      */     //   8535: wide istore #1201
/*      */     //   8539: wide aload #1204
/*      */     //   8543: sipush #572
/*      */     //   8546: wide iload #1201
/*      */     //   8550: invokeinterface setInt : (II)V
/*      */     //   8555: aload_2
/*      */     //   8556: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8559: wide astore #1199
/*      */     //   8563: aload_2
/*      */     //   8564: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8567: wide astore #1197
/*      */     //   8571: wide aload #1197
/*      */     //   8575: sipush #25392
/*      */     //   8578: iconst_0
/*      */     //   8579: invokeinterface setInt : (II)V
/*      */     //   8584: wide aload #1197
/*      */     //   8588: sipush #25392
/*      */     //   8591: invokeinterface getInt : (I)I
/*      */     //   8596: wide istore #1196
/*      */     //   8600: wide aload #1199
/*      */     //   8604: sipush #25392
/*      */     //   8607: wide iload #1196
/*      */     //   8611: invokeinterface setInt : (II)V
/*      */     //   8616: aload_2
/*      */     //   8617: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8620: wide astore #1194
/*      */     //   8624: aload_2
/*      */     //   8625: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8628: wide astore #1192
/*      */     //   8632: aload_1
/*      */     //   8633: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8636: invokeinterface getDouble : ()D
/*      */     //   8641: wide dstore #1188
/*      */     //   8645: wide aload #1192
/*      */     //   8649: iconst_0
/*      */     //   8650: ldc_w 35408
/*      */     //   8653: iadd
/*      */     //   8654: wide dload #1188
/*      */     //   8658: invokeinterface setDouble : (ID)V
/*      */     //   8663: wide aload #1192
/*      */     //   8667: iconst_0
/*      */     //   8668: ldc_w 35408
/*      */     //   8671: iadd
/*      */     //   8672: invokeinterface getDouble : (I)D
/*      */     //   8677: wide dstore #1186
/*      */     //   8681: wide aload #1194
/*      */     //   8685: iconst_0
/*      */     //   8686: ldc_w 35408
/*      */     //   8689: iadd
/*      */     //   8690: wide dload #1186
/*      */     //   8694: invokeinterface setDouble : (ID)V
/*      */     //   8699: aload_2
/*      */     //   8700: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8703: wide astore #1184
/*      */     //   8707: aload_2
/*      */     //   8708: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8711: wide astore #1182
/*      */     //   8715: aload_1
/*      */     //   8716: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8719: bipush #8
/*      */     //   8721: invokeinterface getDouble : (I)D
/*      */     //   8726: wide dstore #1178
/*      */     //   8730: wide aload #1182
/*      */     //   8734: iconst_0
/*      */     //   8735: ldc_w 35408
/*      */     //   8738: iadd
/*      */     //   8739: bipush #8
/*      */     //   8741: iadd
/*      */     //   8742: wide dload #1178
/*      */     //   8746: invokeinterface setDouble : (ID)V
/*      */     //   8751: wide aload #1182
/*      */     //   8755: iconst_0
/*      */     //   8756: ldc_w 35408
/*      */     //   8759: iadd
/*      */     //   8760: bipush #8
/*      */     //   8762: iadd
/*      */     //   8763: invokeinterface getDouble : (I)D
/*      */     //   8768: wide dstore #1176
/*      */     //   8772: wide aload #1184
/*      */     //   8776: iconst_0
/*      */     //   8777: ldc_w 35408
/*      */     //   8780: iadd
/*      */     //   8781: bipush #8
/*      */     //   8783: iadd
/*      */     //   8784: wide dload #1176
/*      */     //   8788: invokeinterface setDouble : (ID)V
/*      */     //   8793: aload_2
/*      */     //   8794: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8797: wide astore #1174
/*      */     //   8801: aload_2
/*      */     //   8802: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8805: wide astore #1172
/*      */     //   8809: aload_1
/*      */     //   8810: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8813: bipush #16
/*      */     //   8815: invokeinterface getDouble : (I)D
/*      */     //   8820: wide dstore #1168
/*      */     //   8824: wide aload #1172
/*      */     //   8828: iconst_0
/*      */     //   8829: ldc_w 35408
/*      */     //   8832: iadd
/*      */     //   8833: bipush #16
/*      */     //   8835: iadd
/*      */     //   8836: wide dload #1168
/*      */     //   8840: invokeinterface setDouble : (ID)V
/*      */     //   8845: wide aload #1172
/*      */     //   8849: iconst_0
/*      */     //   8850: ldc_w 35408
/*      */     //   8853: iadd
/*      */     //   8854: bipush #16
/*      */     //   8856: iadd
/*      */     //   8857: invokeinterface getDouble : (I)D
/*      */     //   8862: wide dstore #1166
/*      */     //   8866: wide aload #1174
/*      */     //   8870: iconst_0
/*      */     //   8871: ldc_w 35408
/*      */     //   8874: iadd
/*      */     //   8875: bipush #16
/*      */     //   8877: iadd
/*      */     //   8878: wide dload #1166
/*      */     //   8882: invokeinterface setDouble : (ID)V
/*      */     //   8887: aload_2
/*      */     //   8888: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8891: wide astore #1164
/*      */     //   8895: aload_2
/*      */     //   8896: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8899: wide astore #1162
/*      */     //   8903: aload_1
/*      */     //   8904: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8907: bipush #24
/*      */     //   8909: invokeinterface getDouble : (I)D
/*      */     //   8914: wide dstore #1158
/*      */     //   8918: wide aload #1162
/*      */     //   8922: iconst_0
/*      */     //   8923: ldc_w 35408
/*      */     //   8926: iadd
/*      */     //   8927: bipush #24
/*      */     //   8929: iadd
/*      */     //   8930: wide dload #1158
/*      */     //   8934: invokeinterface setDouble : (ID)V
/*      */     //   8939: wide aload #1162
/*      */     //   8943: iconst_0
/*      */     //   8944: ldc_w 35408
/*      */     //   8947: iadd
/*      */     //   8948: bipush #24
/*      */     //   8950: iadd
/*      */     //   8951: invokeinterface getDouble : (I)D
/*      */     //   8956: wide dstore #1156
/*      */     //   8960: wide aload #1164
/*      */     //   8964: iconst_0
/*      */     //   8965: ldc_w 35408
/*      */     //   8968: iadd
/*      */     //   8969: bipush #24
/*      */     //   8971: iadd
/*      */     //   8972: wide dload #1156
/*      */     //   8976: invokeinterface setDouble : (ID)V
/*      */     //   8981: aload_2
/*      */     //   8982: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   8985: goto -> 19275
/*      */     //   8988: aload_0
/*      */     //   8989: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   8992: aload_0
/*      */     //   8993: new org/renjin/gcc/runtime/BytePtr
/*      */     //   8996: dup
/*      */     //   8997: ldc_w 'fin '
/*      */     //   9000: invokevirtual getBytes : ()[B
/*      */     //   9003: iconst_0
/*      */     //   9004: invokespecial <init> : ([BI)V
/*      */     //   9007: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   9010: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   9013: ifeq -> 9019
/*      */     //   9016: goto -> 9959
/*      */     //   9019: aload_1
/*      */     //   9020: bipush #14
/*      */     //   9022: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   9025: astore_1
/*      */     //   9026: aload_0
/*      */     //   9027: aload_1
/*      */     //   9028: iconst_2
/*      */     //   9029: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   9032: aload_2
/*      */     //   9033: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9036: wide astore #1153
/*      */     //   9040: aload_2
/*      */     //   9041: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9044: wide astore #1151
/*      */     //   9048: wide aload #1151
/*      */     //   9052: iconst_0
/*      */     //   9053: ldc 35512
/*      */     //   9055: iadd
/*      */     //   9056: iconst_0
/*      */     //   9057: invokeinterface setInt : (II)V
/*      */     //   9062: wide aload #1151
/*      */     //   9066: iconst_0
/*      */     //   9067: ldc 35512
/*      */     //   9069: iadd
/*      */     //   9070: invokeinterface getInt : (I)I
/*      */     //   9075: wide istore #1150
/*      */     //   9079: wide aload #1153
/*      */     //   9083: iconst_0
/*      */     //   9084: ldc 35512
/*      */     //   9086: iadd
/*      */     //   9087: wide iload #1150
/*      */     //   9091: invokeinterface setInt : (II)V
/*      */     //   9096: aload_2
/*      */     //   9097: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9100: wide astore #1148
/*      */     //   9104: aload_2
/*      */     //   9105: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9108: wide astore #1146
/*      */     //   9112: wide aload #1146
/*      */     //   9116: iconst_0
/*      */     //   9117: ldc_w 35456
/*      */     //   9120: iadd
/*      */     //   9121: bipush #13
/*      */     //   9123: invokeinterface setInt : (II)V
/*      */     //   9128: wide aload #1146
/*      */     //   9132: iconst_0
/*      */     //   9133: ldc_w 35456
/*      */     //   9136: iadd
/*      */     //   9137: invokeinterface getInt : (I)I
/*      */     //   9142: wide istore #1145
/*      */     //   9146: wide aload #1148
/*      */     //   9150: iconst_0
/*      */     //   9151: ldc_w 35456
/*      */     //   9154: iadd
/*      */     //   9155: wide iload #1145
/*      */     //   9159: invokeinterface setInt : (II)V
/*      */     //   9164: aload_2
/*      */     //   9165: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9168: wide astore #1143
/*      */     //   9172: aload_2
/*      */     //   9173: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9176: wide astore #1141
/*      */     //   9180: wide aload #1141
/*      */     //   9184: sipush #560
/*      */     //   9187: iconst_1
/*      */     //   9188: invokeinterface setInt : (II)V
/*      */     //   9193: wide aload #1141
/*      */     //   9197: sipush #560
/*      */     //   9200: invokeinterface getInt : (I)I
/*      */     //   9205: wide istore #1140
/*      */     //   9209: wide aload #1143
/*      */     //   9213: sipush #560
/*      */     //   9216: wide iload #1140
/*      */     //   9220: invokeinterface setInt : (II)V
/*      */     //   9225: aload_2
/*      */     //   9226: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9229: wide astore #1138
/*      */     //   9233: aload_2
/*      */     //   9234: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9237: wide astore #1136
/*      */     //   9241: wide aload #1136
/*      */     //   9245: sipush #564
/*      */     //   9248: iconst_1
/*      */     //   9249: invokeinterface setInt : (II)V
/*      */     //   9254: wide aload #1136
/*      */     //   9258: sipush #564
/*      */     //   9261: invokeinterface getInt : (I)I
/*      */     //   9266: wide istore #1135
/*      */     //   9270: wide aload #1138
/*      */     //   9274: sipush #564
/*      */     //   9277: wide iload #1135
/*      */     //   9281: invokeinterface setInt : (II)V
/*      */     //   9286: aload_2
/*      */     //   9287: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9290: wide astore #1133
/*      */     //   9294: aload_2
/*      */     //   9295: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9298: wide astore #1131
/*      */     //   9302: wide aload #1131
/*      */     //   9306: sipush #576
/*      */     //   9309: dconst_1
/*      */     //   9310: invokeinterface setDouble : (ID)V
/*      */     //   9315: wide aload #1131
/*      */     //   9319: sipush #576
/*      */     //   9322: invokeinterface getDouble : (I)D
/*      */     //   9327: wide dstore #1129
/*      */     //   9331: wide aload #1133
/*      */     //   9335: sipush #576
/*      */     //   9338: wide dload #1129
/*      */     //   9342: invokeinterface setDouble : (ID)V
/*      */     //   9347: aload_2
/*      */     //   9348: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9351: wide astore #1127
/*      */     //   9355: aload_2
/*      */     //   9356: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9359: wide astore #1125
/*      */     //   9363: wide aload #1125
/*      */     //   9367: sipush #2176
/*      */     //   9370: dconst_1
/*      */     //   9371: invokeinterface setDouble : (ID)V
/*      */     //   9376: wide aload #1125
/*      */     //   9380: sipush #2176
/*      */     //   9383: invokeinterface getDouble : (I)D
/*      */     //   9388: wide dstore #1123
/*      */     //   9392: wide aload #1127
/*      */     //   9396: sipush #2176
/*      */     //   9399: wide dload #1123
/*      */     //   9403: invokeinterface setDouble : (ID)V
/*      */     //   9408: aload_2
/*      */     //   9409: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9412: wide astore #1121
/*      */     //   9416: aload_2
/*      */     //   9417: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9420: wide astore #1119
/*      */     //   9424: wide aload #1119
/*      */     //   9428: sipush #3776
/*      */     //   9431: iconst_0
/*      */     //   9432: invokeinterface setInt : (II)V
/*      */     //   9437: wide aload #1119
/*      */     //   9441: sipush #3776
/*      */     //   9444: invokeinterface getInt : (I)I
/*      */     //   9449: wide istore #1118
/*      */     //   9453: wide aload #1121
/*      */     //   9457: sipush #3776
/*      */     //   9460: wide iload #1118
/*      */     //   9464: invokeinterface setInt : (II)V
/*      */     //   9469: aload_2
/*      */     //   9470: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9473: wide astore #1116
/*      */     //   9477: aload_2
/*      */     //   9478: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9481: wide astore #1114
/*      */     //   9485: wide aload #1114
/*      */     //   9489: sipush #4576
/*      */     //   9492: iconst_0
/*      */     //   9493: invokeinterface setInt : (II)V
/*      */     //   9498: wide aload #1114
/*      */     //   9502: sipush #4576
/*      */     //   9505: invokeinterface getInt : (I)I
/*      */     //   9510: wide istore #1113
/*      */     //   9514: wide aload #1116
/*      */     //   9518: sipush #4576
/*      */     //   9521: wide iload #1113
/*      */     //   9525: invokeinterface setInt : (II)V
/*      */     //   9530: aload_2
/*      */     //   9531: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9534: wide astore #1111
/*      */     //   9538: aload_2
/*      */     //   9539: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9542: wide astore #1109
/*      */     //   9546: wide aload #1109
/*      */     //   9550: sipush #5376
/*      */     //   9553: iconst_1
/*      */     //   9554: i2c
/*      */     //   9555: invokeinterface setChar : (IC)V
/*      */     //   9560: wide aload #1109
/*      */     //   9564: sipush #5376
/*      */     //   9567: invokeinterface getChar : (I)C
/*      */     //   9572: wide istore #1108
/*      */     //   9576: wide aload #1111
/*      */     //   9580: sipush #5376
/*      */     //   9583: wide iload #1108
/*      */     //   9587: invokeinterface setChar : (IC)V
/*      */     //   9592: aload_2
/*      */     //   9593: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9596: wide astore #1106
/*      */     //   9600: aload_2
/*      */     //   9601: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9604: wide astore #1104
/*      */     //   9608: wide aload #1104
/*      */     //   9612: sipush #568
/*      */     //   9615: iconst_1
/*      */     //   9616: invokeinterface setInt : (II)V
/*      */     //   9621: wide aload #1104
/*      */     //   9625: sipush #568
/*      */     //   9628: invokeinterface getInt : (I)I
/*      */     //   9633: wide istore #1103
/*      */     //   9637: wide aload #1106
/*      */     //   9641: sipush #568
/*      */     //   9644: wide iload #1103
/*      */     //   9648: invokeinterface setInt : (II)V
/*      */     //   9653: aload_2
/*      */     //   9654: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9657: wide astore #1101
/*      */     //   9661: aload_2
/*      */     //   9662: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9665: wide astore #1099
/*      */     //   9669: wide aload #1099
/*      */     //   9673: sipush #572
/*      */     //   9676: iconst_1
/*      */     //   9677: invokeinterface setInt : (II)V
/*      */     //   9682: wide aload #1099
/*      */     //   9686: sipush #572
/*      */     //   9689: invokeinterface getInt : (I)I
/*      */     //   9694: wide istore #1098
/*      */     //   9698: wide aload #1101
/*      */     //   9702: sipush #572
/*      */     //   9705: wide iload #1098
/*      */     //   9709: invokeinterface setInt : (II)V
/*      */     //   9714: aload_2
/*      */     //   9715: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9718: wide astore #1096
/*      */     //   9722: aload_2
/*      */     //   9723: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9726: wide astore #1094
/*      */     //   9730: wide aload #1094
/*      */     //   9734: sipush #25392
/*      */     //   9737: iconst_0
/*      */     //   9738: invokeinterface setInt : (II)V
/*      */     //   9743: wide aload #1094
/*      */     //   9747: sipush #25392
/*      */     //   9750: invokeinterface getInt : (I)I
/*      */     //   9755: wide istore #1093
/*      */     //   9759: wide aload #1096
/*      */     //   9763: sipush #25392
/*      */     //   9766: wide iload #1093
/*      */     //   9770: invokeinterface setInt : (II)V
/*      */     //   9775: aload_2
/*      */     //   9776: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9779: wide astore #1091
/*      */     //   9783: aload_2
/*      */     //   9784: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9787: wide astore #1089
/*      */     //   9791: aload_1
/*      */     //   9792: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9795: invokeinterface getDouble : ()D
/*      */     //   9800: wide dstore #1085
/*      */     //   9804: wide aload #1089
/*      */     //   9808: iconst_0
/*      */     //   9809: ldc_w 35440
/*      */     //   9812: iadd
/*      */     //   9813: wide dload #1085
/*      */     //   9817: invokeinterface setDouble : (ID)V
/*      */     //   9822: wide aload #1089
/*      */     //   9826: iconst_0
/*      */     //   9827: ldc_w 35440
/*      */     //   9830: iadd
/*      */     //   9831: invokeinterface getDouble : (I)D
/*      */     //   9836: wide dstore #1083
/*      */     //   9840: wide aload #1091
/*      */     //   9844: iconst_0
/*      */     //   9845: ldc_w 35440
/*      */     //   9848: iadd
/*      */     //   9849: wide dload #1083
/*      */     //   9853: invokeinterface setDouble : (ID)V
/*      */     //   9858: aload_2
/*      */     //   9859: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9862: wide astore #1081
/*      */     //   9866: aload_2
/*      */     //   9867: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9870: wide astore #1079
/*      */     //   9874: aload_1
/*      */     //   9875: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   9878: bipush #8
/*      */     //   9880: invokeinterface getDouble : (I)D
/*      */     //   9885: wide dstore #1075
/*      */     //   9889: wide aload #1079
/*      */     //   9893: iconst_0
/*      */     //   9894: ldc_w 35440
/*      */     //   9897: iadd
/*      */     //   9898: bipush #8
/*      */     //   9900: iadd
/*      */     //   9901: wide dload #1075
/*      */     //   9905: invokeinterface setDouble : (ID)V
/*      */     //   9910: wide aload #1079
/*      */     //   9914: iconst_0
/*      */     //   9915: ldc_w 35440
/*      */     //   9918: iadd
/*      */     //   9919: bipush #8
/*      */     //   9921: iadd
/*      */     //   9922: invokeinterface getDouble : (I)D
/*      */     //   9927: wide dstore #1073
/*      */     //   9931: wide aload #1081
/*      */     //   9935: iconst_0
/*      */     //   9936: ldc_w 35440
/*      */     //   9939: iadd
/*      */     //   9940: bipush #8
/*      */     //   9942: iadd
/*      */     //   9943: wide dload #1073
/*      */     //   9947: invokeinterface setDouble : (ID)V
/*      */     //   9952: aload_2
/*      */     //   9953: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   9956: goto -> 19275
/*      */     //   9959: aload_0
/*      */     //   9960: new org/renjin/gcc/runtime/BytePtr
/*      */     //   9963: dup
/*      */     //   9964: ldc_w 'lheight '
/*      */     //   9967: invokevirtual getBytes : ()[B
/*      */     //   9970: iconst_0
/*      */     //   9971: invokespecial <init> : ([BI)V
/*      */     //   9974: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   9977: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   9980: ifeq -> 9986
/*      */     //   9983: goto -> 10066
/*      */     //   9986: aload_0
/*      */     //   9987: aload_1
/*      */     //   9988: iconst_1
/*      */     //   9989: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   9992: aload_1
/*      */     //   9993: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   9996: dstore #18
/*      */     //   9998: dload #18
/*      */     //   10000: aload_0
/*      */     //   10001: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10004: aload_2
/*      */     //   10005: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10008: wide astore #1070
/*      */     //   10012: aload_2
/*      */     //   10013: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10016: wide astore #1068
/*      */     //   10020: wide aload #1068
/*      */     //   10024: bipush #36
/*      */     //   10026: dload #18
/*      */     //   10028: invokeinterface setDouble : (ID)V
/*      */     //   10033: wide aload #1068
/*      */     //   10037: bipush #36
/*      */     //   10039: invokeinterface getDouble : (I)D
/*      */     //   10044: wide dstore #1066
/*      */     //   10048: wide aload #1070
/*      */     //   10052: bipush #36
/*      */     //   10054: wide dload #1066
/*      */     //   10058: invokeinterface setDouble : (ID)V
/*      */     //   10063: goto -> 19275
/*      */     //   10066: aload_0
/*      */     //   10067: new org/renjin/gcc/runtime/BytePtr
/*      */     //   10070: dup
/*      */     //   10071: ldc_w 'mai '
/*      */     //   10074: invokevirtual getBytes : ()[B
/*      */     //   10077: iconst_0
/*      */     //   10078: invokespecial <init> : ([BI)V
/*      */     //   10081: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   10084: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   10087: ifeq -> 10093
/*      */     //   10090: goto -> 10671
/*      */     //   10093: aload_1
/*      */     //   10094: bipush #14
/*      */     //   10096: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   10099: astore_1
/*      */     //   10100: aload_0
/*      */     //   10101: aload_1
/*      */     //   10102: iconst_4
/*      */     //   10103: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   10106: aload_1
/*      */     //   10107: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10110: invokeinterface getDouble : ()D
/*      */     //   10115: aload_0
/*      */     //   10116: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10119: aload_1
/*      */     //   10120: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10123: bipush #8
/*      */     //   10125: invokeinterface getDouble : (I)D
/*      */     //   10130: aload_0
/*      */     //   10131: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10134: aload_1
/*      */     //   10135: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10138: bipush #16
/*      */     //   10140: invokeinterface getDouble : (I)D
/*      */     //   10145: aload_0
/*      */     //   10146: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10149: aload_1
/*      */     //   10150: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10153: bipush #24
/*      */     //   10155: invokeinterface getDouble : (I)D
/*      */     //   10160: aload_0
/*      */     //   10161: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10164: aload_2
/*      */     //   10165: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10168: wide astore #1041
/*      */     //   10172: aload_2
/*      */     //   10173: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10176: wide astore #1039
/*      */     //   10180: aload_1
/*      */     //   10181: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10184: invokeinterface getDouble : ()D
/*      */     //   10189: wide dstore #1035
/*      */     //   10193: wide aload #1039
/*      */     //   10197: iconst_0
/*      */     //   10198: ldc_w 35552
/*      */     //   10201: iadd
/*      */     //   10202: wide dload #1035
/*      */     //   10206: invokeinterface setDouble : (ID)V
/*      */     //   10211: wide aload #1039
/*      */     //   10215: iconst_0
/*      */     //   10216: ldc_w 35552
/*      */     //   10219: iadd
/*      */     //   10220: invokeinterface getDouble : (I)D
/*      */     //   10225: wide dstore #1033
/*      */     //   10229: wide aload #1041
/*      */     //   10233: iconst_0
/*      */     //   10234: ldc_w 35552
/*      */     //   10237: iadd
/*      */     //   10238: wide dload #1033
/*      */     //   10242: invokeinterface setDouble : (ID)V
/*      */     //   10247: aload_2
/*      */     //   10248: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10251: wide astore #1031
/*      */     //   10255: aload_2
/*      */     //   10256: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10259: wide astore #1029
/*      */     //   10263: aload_1
/*      */     //   10264: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10267: bipush #8
/*      */     //   10269: invokeinterface getDouble : (I)D
/*      */     //   10274: wide dstore #1025
/*      */     //   10278: wide aload #1029
/*      */     //   10282: iconst_0
/*      */     //   10283: ldc_w 35552
/*      */     //   10286: iadd
/*      */     //   10287: bipush #8
/*      */     //   10289: iadd
/*      */     //   10290: wide dload #1025
/*      */     //   10294: invokeinterface setDouble : (ID)V
/*      */     //   10299: wide aload #1029
/*      */     //   10303: iconst_0
/*      */     //   10304: ldc_w 35552
/*      */     //   10307: iadd
/*      */     //   10308: bipush #8
/*      */     //   10310: iadd
/*      */     //   10311: invokeinterface getDouble : (I)D
/*      */     //   10316: wide dstore #1023
/*      */     //   10320: wide aload #1031
/*      */     //   10324: iconst_0
/*      */     //   10325: ldc_w 35552
/*      */     //   10328: iadd
/*      */     //   10329: bipush #8
/*      */     //   10331: iadd
/*      */     //   10332: wide dload #1023
/*      */     //   10336: invokeinterface setDouble : (ID)V
/*      */     //   10341: aload_2
/*      */     //   10342: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10345: wide astore #1021
/*      */     //   10349: aload_2
/*      */     //   10350: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10353: wide astore #1019
/*      */     //   10357: aload_1
/*      */     //   10358: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10361: bipush #16
/*      */     //   10363: invokeinterface getDouble : (I)D
/*      */     //   10368: wide dstore #1015
/*      */     //   10372: wide aload #1019
/*      */     //   10376: iconst_0
/*      */     //   10377: ldc_w 35552
/*      */     //   10380: iadd
/*      */     //   10381: bipush #16
/*      */     //   10383: iadd
/*      */     //   10384: wide dload #1015
/*      */     //   10388: invokeinterface setDouble : (ID)V
/*      */     //   10393: wide aload #1019
/*      */     //   10397: iconst_0
/*      */     //   10398: ldc_w 35552
/*      */     //   10401: iadd
/*      */     //   10402: bipush #16
/*      */     //   10404: iadd
/*      */     //   10405: invokeinterface getDouble : (I)D
/*      */     //   10410: wide dstore #1013
/*      */     //   10414: wide aload #1021
/*      */     //   10418: iconst_0
/*      */     //   10419: ldc_w 35552
/*      */     //   10422: iadd
/*      */     //   10423: bipush #16
/*      */     //   10425: iadd
/*      */     //   10426: wide dload #1013
/*      */     //   10430: invokeinterface setDouble : (ID)V
/*      */     //   10435: aload_2
/*      */     //   10436: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10439: wide astore #1011
/*      */     //   10443: aload_2
/*      */     //   10444: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10447: wide astore #1009
/*      */     //   10451: aload_1
/*      */     //   10452: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10455: bipush #24
/*      */     //   10457: invokeinterface getDouble : (I)D
/*      */     //   10462: wide dstore #1005
/*      */     //   10466: wide aload #1009
/*      */     //   10470: iconst_0
/*      */     //   10471: ldc_w 35552
/*      */     //   10474: iadd
/*      */     //   10475: bipush #24
/*      */     //   10477: iadd
/*      */     //   10478: wide dload #1005
/*      */     //   10482: invokeinterface setDouble : (ID)V
/*      */     //   10487: wide aload #1009
/*      */     //   10491: iconst_0
/*      */     //   10492: ldc_w 35552
/*      */     //   10495: iadd
/*      */     //   10496: bipush #24
/*      */     //   10498: iadd
/*      */     //   10499: invokeinterface getDouble : (I)D
/*      */     //   10504: wide dstore #1003
/*      */     //   10508: wide aload #1011
/*      */     //   10512: iconst_0
/*      */     //   10513: ldc_w 35552
/*      */     //   10516: iadd
/*      */     //   10517: bipush #24
/*      */     //   10519: iadd
/*      */     //   10520: wide dload #1003
/*      */     //   10524: invokeinterface setDouble : (ID)V
/*      */     //   10529: aload_2
/*      */     //   10530: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10533: wide astore #1001
/*      */     //   10537: aload_2
/*      */     //   10538: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10541: wide astore #999
/*      */     //   10545: wide aload #999
/*      */     //   10549: iconst_0
/*      */     //   10550: ldc_w 35584
/*      */     //   10553: iadd
/*      */     //   10554: bipush #13
/*      */     //   10556: invokeinterface setInt : (II)V
/*      */     //   10561: wide aload #999
/*      */     //   10565: iconst_0
/*      */     //   10566: ldc_w 35584
/*      */     //   10569: iadd
/*      */     //   10570: invokeinterface getInt : (I)I
/*      */     //   10575: wide istore #998
/*      */     //   10579: wide aload #1001
/*      */     //   10583: iconst_0
/*      */     //   10584: ldc_w 35584
/*      */     //   10587: iadd
/*      */     //   10588: wide iload #998
/*      */     //   10592: invokeinterface setInt : (II)V
/*      */     //   10597: aload_2
/*      */     //   10598: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10601: wide astore #996
/*      */     //   10605: aload_2
/*      */     //   10606: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10609: wide astore #994
/*      */     //   10613: wide aload #994
/*      */     //   10617: iconst_0
/*      */     //   10618: ldc_w 35516
/*      */     //   10621: iadd
/*      */     //   10622: iconst_1
/*      */     //   10623: invokeinterface setInt : (II)V
/*      */     //   10628: wide aload #994
/*      */     //   10632: iconst_0
/*      */     //   10633: ldc_w 35516
/*      */     //   10636: iadd
/*      */     //   10637: invokeinterface getInt : (I)I
/*      */     //   10642: wide istore #993
/*      */     //   10646: wide aload #996
/*      */     //   10650: iconst_0
/*      */     //   10651: ldc_w 35516
/*      */     //   10654: iadd
/*      */     //   10655: wide iload #993
/*      */     //   10659: invokeinterface setInt : (II)V
/*      */     //   10664: aload_2
/*      */     //   10665: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10668: goto -> 19275
/*      */     //   10671: aload_0
/*      */     //   10672: new org/renjin/gcc/runtime/BytePtr
/*      */     //   10675: dup
/*      */     //   10676: ldc_w 'mar '
/*      */     //   10679: invokevirtual getBytes : ()[B
/*      */     //   10682: iconst_0
/*      */     //   10683: invokespecial <init> : ([BI)V
/*      */     //   10686: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   10689: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   10692: ifeq -> 10698
/*      */     //   10695: goto -> 11276
/*      */     //   10698: aload_1
/*      */     //   10699: bipush #14
/*      */     //   10701: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   10704: astore_1
/*      */     //   10705: aload_0
/*      */     //   10706: aload_1
/*      */     //   10707: iconst_4
/*      */     //   10708: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   10711: aload_1
/*      */     //   10712: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10715: invokeinterface getDouble : ()D
/*      */     //   10720: aload_0
/*      */     //   10721: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10724: aload_1
/*      */     //   10725: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10728: bipush #8
/*      */     //   10730: invokeinterface getDouble : (I)D
/*      */     //   10735: aload_0
/*      */     //   10736: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10739: aload_1
/*      */     //   10740: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10743: bipush #16
/*      */     //   10745: invokeinterface getDouble : (I)D
/*      */     //   10750: aload_0
/*      */     //   10751: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10754: aload_1
/*      */     //   10755: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10758: bipush #24
/*      */     //   10760: invokeinterface getDouble : (I)D
/*      */     //   10765: aload_0
/*      */     //   10766: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   10769: aload_2
/*      */     //   10770: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10773: wide astore #968
/*      */     //   10777: aload_2
/*      */     //   10778: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10781: wide astore #966
/*      */     //   10785: aload_1
/*      */     //   10786: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10789: invokeinterface getDouble : ()D
/*      */     //   10794: wide dstore #962
/*      */     //   10798: wide aload #966
/*      */     //   10802: iconst_0
/*      */     //   10803: ldc_w 35520
/*      */     //   10806: iadd
/*      */     //   10807: wide dload #962
/*      */     //   10811: invokeinterface setDouble : (ID)V
/*      */     //   10816: wide aload #966
/*      */     //   10820: iconst_0
/*      */     //   10821: ldc_w 35520
/*      */     //   10824: iadd
/*      */     //   10825: invokeinterface getDouble : (I)D
/*      */     //   10830: wide dstore #960
/*      */     //   10834: wide aload #968
/*      */     //   10838: iconst_0
/*      */     //   10839: ldc_w 35520
/*      */     //   10842: iadd
/*      */     //   10843: wide dload #960
/*      */     //   10847: invokeinterface setDouble : (ID)V
/*      */     //   10852: aload_2
/*      */     //   10853: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10856: wide astore #958
/*      */     //   10860: aload_2
/*      */     //   10861: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10864: wide astore #956
/*      */     //   10868: aload_1
/*      */     //   10869: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10872: bipush #8
/*      */     //   10874: invokeinterface getDouble : (I)D
/*      */     //   10879: wide dstore #952
/*      */     //   10883: wide aload #956
/*      */     //   10887: iconst_0
/*      */     //   10888: ldc_w 35520
/*      */     //   10891: iadd
/*      */     //   10892: bipush #8
/*      */     //   10894: iadd
/*      */     //   10895: wide dload #952
/*      */     //   10899: invokeinterface setDouble : (ID)V
/*      */     //   10904: wide aload #956
/*      */     //   10908: iconst_0
/*      */     //   10909: ldc_w 35520
/*      */     //   10912: iadd
/*      */     //   10913: bipush #8
/*      */     //   10915: iadd
/*      */     //   10916: invokeinterface getDouble : (I)D
/*      */     //   10921: wide dstore #950
/*      */     //   10925: wide aload #958
/*      */     //   10929: iconst_0
/*      */     //   10930: ldc_w 35520
/*      */     //   10933: iadd
/*      */     //   10934: bipush #8
/*      */     //   10936: iadd
/*      */     //   10937: wide dload #950
/*      */     //   10941: invokeinterface setDouble : (ID)V
/*      */     //   10946: aload_2
/*      */     //   10947: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10950: wide astore #948
/*      */     //   10954: aload_2
/*      */     //   10955: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10958: wide astore #946
/*      */     //   10962: aload_1
/*      */     //   10963: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   10966: bipush #16
/*      */     //   10968: invokeinterface getDouble : (I)D
/*      */     //   10973: wide dstore #942
/*      */     //   10977: wide aload #946
/*      */     //   10981: iconst_0
/*      */     //   10982: ldc_w 35520
/*      */     //   10985: iadd
/*      */     //   10986: bipush #16
/*      */     //   10988: iadd
/*      */     //   10989: wide dload #942
/*      */     //   10993: invokeinterface setDouble : (ID)V
/*      */     //   10998: wide aload #946
/*      */     //   11002: iconst_0
/*      */     //   11003: ldc_w 35520
/*      */     //   11006: iadd
/*      */     //   11007: bipush #16
/*      */     //   11009: iadd
/*      */     //   11010: invokeinterface getDouble : (I)D
/*      */     //   11015: wide dstore #940
/*      */     //   11019: wide aload #948
/*      */     //   11023: iconst_0
/*      */     //   11024: ldc_w 35520
/*      */     //   11027: iadd
/*      */     //   11028: bipush #16
/*      */     //   11030: iadd
/*      */     //   11031: wide dload #940
/*      */     //   11035: invokeinterface setDouble : (ID)V
/*      */     //   11040: aload_2
/*      */     //   11041: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11044: wide astore #938
/*      */     //   11048: aload_2
/*      */     //   11049: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11052: wide astore #936
/*      */     //   11056: aload_1
/*      */     //   11057: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11060: bipush #24
/*      */     //   11062: invokeinterface getDouble : (I)D
/*      */     //   11067: wide dstore #932
/*      */     //   11071: wide aload #936
/*      */     //   11075: iconst_0
/*      */     //   11076: ldc_w 35520
/*      */     //   11079: iadd
/*      */     //   11080: bipush #24
/*      */     //   11082: iadd
/*      */     //   11083: wide dload #932
/*      */     //   11087: invokeinterface setDouble : (ID)V
/*      */     //   11092: wide aload #936
/*      */     //   11096: iconst_0
/*      */     //   11097: ldc_w 35520
/*      */     //   11100: iadd
/*      */     //   11101: bipush #24
/*      */     //   11103: iadd
/*      */     //   11104: invokeinterface getDouble : (I)D
/*      */     //   11109: wide dstore #930
/*      */     //   11113: wide aload #938
/*      */     //   11117: iconst_0
/*      */     //   11118: ldc_w 35520
/*      */     //   11121: iadd
/*      */     //   11122: bipush #24
/*      */     //   11124: iadd
/*      */     //   11125: wide dload #930
/*      */     //   11129: invokeinterface setDouble : (ID)V
/*      */     //   11134: aload_2
/*      */     //   11135: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11138: wide astore #928
/*      */     //   11142: aload_2
/*      */     //   11143: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11146: wide astore #926
/*      */     //   11150: wide aload #926
/*      */     //   11154: iconst_0
/*      */     //   11155: ldc_w 35584
/*      */     //   11158: iadd
/*      */     //   11159: bipush #14
/*      */     //   11161: invokeinterface setInt : (II)V
/*      */     //   11166: wide aload #926
/*      */     //   11170: iconst_0
/*      */     //   11171: ldc_w 35584
/*      */     //   11174: iadd
/*      */     //   11175: invokeinterface getInt : (I)I
/*      */     //   11180: wide istore #925
/*      */     //   11184: wide aload #928
/*      */     //   11188: iconst_0
/*      */     //   11189: ldc_w 35584
/*      */     //   11192: iadd
/*      */     //   11193: wide iload #925
/*      */     //   11197: invokeinterface setInt : (II)V
/*      */     //   11202: aload_2
/*      */     //   11203: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11206: wide astore #923
/*      */     //   11210: aload_2
/*      */     //   11211: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11214: wide astore #921
/*      */     //   11218: wide aload #921
/*      */     //   11222: iconst_0
/*      */     //   11223: ldc_w 35516
/*      */     //   11226: iadd
/*      */     //   11227: iconst_1
/*      */     //   11228: invokeinterface setInt : (II)V
/*      */     //   11233: wide aload #921
/*      */     //   11237: iconst_0
/*      */     //   11238: ldc_w 35516
/*      */     //   11241: iadd
/*      */     //   11242: invokeinterface getInt : (I)I
/*      */     //   11247: wide istore #920
/*      */     //   11251: wide aload #923
/*      */     //   11255: iconst_0
/*      */     //   11256: ldc_w 35516
/*      */     //   11259: iadd
/*      */     //   11260: wide iload #920
/*      */     //   11264: invokeinterface setInt : (II)V
/*      */     //   11269: aload_2
/*      */     //   11270: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   11273: goto -> 19275
/*      */     //   11276: aload_0
/*      */     //   11277: new org/renjin/gcc/runtime/BytePtr
/*      */     //   11280: dup
/*      */     //   11281: ldc_w 'mex '
/*      */     //   11284: invokevirtual getBytes : ()[B
/*      */     //   11287: iconst_0
/*      */     //   11288: invokespecial <init> : ([BI)V
/*      */     //   11291: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   11294: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   11297: ifeq -> 11303
/*      */     //   11300: goto -> 11393
/*      */     //   11303: aload_0
/*      */     //   11304: aload_1
/*      */     //   11305: iconst_1
/*      */     //   11306: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   11309: aload_1
/*      */     //   11310: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   11313: dstore #18
/*      */     //   11315: dload #18
/*      */     //   11317: aload_0
/*      */     //   11318: invokestatic posRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   11321: aload_2
/*      */     //   11322: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11325: wide astore #917
/*      */     //   11329: aload_2
/*      */     //   11330: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11333: wide astore #915
/*      */     //   11337: wide aload #915
/*      */     //   11341: iconst_0
/*      */     //   11342: ldc 35588
/*      */     //   11344: iadd
/*      */     //   11345: dload #18
/*      */     //   11347: invokeinterface setDouble : (ID)V
/*      */     //   11352: wide aload #915
/*      */     //   11356: iconst_0
/*      */     //   11357: ldc 35588
/*      */     //   11359: iadd
/*      */     //   11360: invokeinterface getDouble : (I)D
/*      */     //   11365: wide dstore #913
/*      */     //   11369: wide aload #917
/*      */     //   11373: iconst_0
/*      */     //   11374: ldc 35588
/*      */     //   11376: iadd
/*      */     //   11377: wide dload #913
/*      */     //   11381: invokeinterface setDouble : (ID)V
/*      */     //   11386: aload_2
/*      */     //   11387: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   11390: goto -> 19275
/*      */     //   11393: aload_0
/*      */     //   11394: new org/renjin/gcc/runtime/BytePtr
/*      */     //   11397: dup
/*      */     //   11398: ldc_w 'mfrow '
/*      */     //   11401: invokevirtual getBytes : ()[B
/*      */     //   11404: iconst_0
/*      */     //   11405: invokespecial <init> : ([BI)V
/*      */     //   11408: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   11411: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   11414: ifeq -> 11420
/*      */     //   11417: goto -> 12373
/*      */     //   11420: aload_1
/*      */     //   11421: bipush #13
/*      */     //   11423: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   11426: astore_1
/*      */     //   11427: aload_0
/*      */     //   11428: aload_1
/*      */     //   11429: iconst_2
/*      */     //   11430: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   11433: aload_1
/*      */     //   11434: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11437: invokeinterface getInt : ()I
/*      */     //   11442: aload_0
/*      */     //   11443: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   11446: aload_1
/*      */     //   11447: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11450: iconst_4
/*      */     //   11451: invokeinterface getInt : (I)I
/*      */     //   11456: aload_0
/*      */     //   11457: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   11460: aload_1
/*      */     //   11461: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11464: invokeinterface getInt : ()I
/*      */     //   11469: istore #11
/*      */     //   11471: aload_1
/*      */     //   11472: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11475: iconst_4
/*      */     //   11476: invokeinterface getInt : (I)I
/*      */     //   11481: istore #10
/*      */     //   11483: aload_2
/*      */     //   11484: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11487: wide astore #898
/*      */     //   11491: aload_2
/*      */     //   11492: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11495: wide astore #896
/*      */     //   11499: wide aload #896
/*      */     //   11503: sipush #560
/*      */     //   11506: iload #11
/*      */     //   11508: invokeinterface setInt : (II)V
/*      */     //   11513: wide aload #896
/*      */     //   11517: sipush #560
/*      */     //   11520: invokeinterface getInt : (I)I
/*      */     //   11525: wide istore #895
/*      */     //   11529: wide aload #898
/*      */     //   11533: sipush #560
/*      */     //   11536: wide iload #895
/*      */     //   11540: invokeinterface setInt : (II)V
/*      */     //   11545: aload_2
/*      */     //   11546: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11549: wide astore #893
/*      */     //   11553: aload_2
/*      */     //   11554: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11557: wide astore #891
/*      */     //   11561: wide aload #891
/*      */     //   11565: sipush #564
/*      */     //   11568: iload #10
/*      */     //   11570: invokeinterface setInt : (II)V
/*      */     //   11575: wide aload #891
/*      */     //   11579: sipush #564
/*      */     //   11582: invokeinterface getInt : (I)I
/*      */     //   11587: wide istore #890
/*      */     //   11591: wide aload #893
/*      */     //   11595: sipush #564
/*      */     //   11598: wide iload #890
/*      */     //   11602: invokeinterface setInt : (II)V
/*      */     //   11607: aload_2
/*      */     //   11608: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11611: wide astore #888
/*      */     //   11615: aload_2
/*      */     //   11616: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11619: wide astore #886
/*      */     //   11623: iload #11
/*      */     //   11625: iload #10
/*      */     //   11627: imul
/*      */     //   11628: wide istore #885
/*      */     //   11632: wide aload #886
/*      */     //   11636: sipush #568
/*      */     //   11639: wide iload #885
/*      */     //   11643: invokeinterface setInt : (II)V
/*      */     //   11648: wide aload #886
/*      */     //   11652: sipush #568
/*      */     //   11655: invokeinterface getInt : (I)I
/*      */     //   11660: wide istore #884
/*      */     //   11664: wide aload #888
/*      */     //   11668: sipush #568
/*      */     //   11671: wide iload #884
/*      */     //   11675: invokeinterface setInt : (II)V
/*      */     //   11680: aload_2
/*      */     //   11681: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11684: wide astore #882
/*      */     //   11688: aload_2
/*      */     //   11689: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11692: wide astore #880
/*      */     //   11696: iload #11
/*      */     //   11698: iload #10
/*      */     //   11700: imul
/*      */     //   11701: wide istore #879
/*      */     //   11705: wide aload #880
/*      */     //   11709: sipush #572
/*      */     //   11712: wide iload #879
/*      */     //   11716: invokeinterface setInt : (II)V
/*      */     //   11721: wide aload #880
/*      */     //   11725: sipush #572
/*      */     //   11728: invokeinterface getInt : (I)I
/*      */     //   11733: wide istore #878
/*      */     //   11737: wide aload #882
/*      */     //   11741: sipush #572
/*      */     //   11744: wide iload #878
/*      */     //   11748: invokeinterface setInt : (II)V
/*      */     //   11753: aload_2
/*      */     //   11754: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11757: wide astore #876
/*      */     //   11761: aload_2
/*      */     //   11762: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11765: wide astore #874
/*      */     //   11769: wide aload #874
/*      */     //   11773: iconst_0
/*      */     //   11774: ldc 35512
/*      */     //   11776: iadd
/*      */     //   11777: iconst_1
/*      */     //   11778: invokeinterface setInt : (II)V
/*      */     //   11783: wide aload #874
/*      */     //   11787: iconst_0
/*      */     //   11788: ldc 35512
/*      */     //   11790: iadd
/*      */     //   11791: invokeinterface getInt : (I)I
/*      */     //   11796: wide istore #873
/*      */     //   11800: wide aload #876
/*      */     //   11804: iconst_0
/*      */     //   11805: ldc 35512
/*      */     //   11807: iadd
/*      */     //   11808: wide iload #873
/*      */     //   11812: invokeinterface setInt : (II)V
/*      */     //   11817: aload_2
/*      */     //   11818: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11821: wide astore #871
/*      */     //   11825: aload_2
/*      */     //   11826: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11829: wide astore #869
/*      */     //   11833: wide aload #869
/*      */     //   11837: sipush #556
/*      */     //   11840: iconst_0
/*      */     //   11841: invokeinterface setInt : (II)V
/*      */     //   11846: wide aload #869
/*      */     //   11850: sipush #556
/*      */     //   11853: invokeinterface getInt : (I)I
/*      */     //   11858: wide istore #868
/*      */     //   11862: wide aload #871
/*      */     //   11866: sipush #556
/*      */     //   11869: wide iload #868
/*      */     //   11873: invokeinterface setInt : (II)V
/*      */     //   11878: iload #11
/*      */     //   11880: iconst_2
/*      */     //   11881: if_icmpgt -> 11896
/*      */     //   11884: goto -> 11887
/*      */     //   11887: iload #10
/*      */     //   11889: iconst_2
/*      */     //   11890: if_icmpgt -> 11896
/*      */     //   11893: goto -> 12026
/*      */     //   11896: aload_2
/*      */     //   11897: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11900: wide astore #866
/*      */     //   11904: aload_2
/*      */     //   11905: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11908: wide astore #864
/*      */     //   11912: wide aload #864
/*      */     //   11916: sipush #484
/*      */     //   11919: ldc2_w 0.66
/*      */     //   11922: invokeinterface setDouble : (ID)V
/*      */     //   11927: wide aload #864
/*      */     //   11931: sipush #484
/*      */     //   11934: invokeinterface getDouble : (I)D
/*      */     //   11939: wide dstore #862
/*      */     //   11943: wide aload #866
/*      */     //   11947: sipush #484
/*      */     //   11950: wide dload #862
/*      */     //   11954: invokeinterface setDouble : (ID)V
/*      */     //   11959: aload_2
/*      */     //   11960: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11963: wide astore #860
/*      */     //   11967: aload_2
/*      */     //   11968: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   11971: wide astore #858
/*      */     //   11975: wide aload #858
/*      */     //   11979: iconst_0
/*      */     //   11980: ldc 35588
/*      */     //   11982: iadd
/*      */     //   11983: dconst_1
/*      */     //   11984: invokeinterface setDouble : (ID)V
/*      */     //   11989: wide aload #858
/*      */     //   11993: iconst_0
/*      */     //   11994: ldc 35588
/*      */     //   11996: iadd
/*      */     //   11997: invokeinterface getDouble : (I)D
/*      */     //   12002: wide dstore #856
/*      */     //   12006: wide aload #860
/*      */     //   12010: iconst_0
/*      */     //   12011: ldc 35588
/*      */     //   12013: iadd
/*      */     //   12014: wide dload #856
/*      */     //   12018: invokeinterface setDouble : (ID)V
/*      */     //   12023: goto -> 12299
/*      */     //   12026: iload #11
/*      */     //   12028: iconst_2
/*      */     //   12029: if_icmpeq -> 12035
/*      */     //   12032: goto -> 12174
/*      */     //   12035: iload #10
/*      */     //   12037: iconst_2
/*      */     //   12038: if_icmpeq -> 12044
/*      */     //   12041: goto -> 12174
/*      */     //   12044: aload_2
/*      */     //   12045: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12048: wide astore #854
/*      */     //   12052: aload_2
/*      */     //   12053: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12056: wide astore #852
/*      */     //   12060: wide aload #852
/*      */     //   12064: sipush #484
/*      */     //   12067: ldc2_w 0.83
/*      */     //   12070: invokeinterface setDouble : (ID)V
/*      */     //   12075: wide aload #852
/*      */     //   12079: sipush #484
/*      */     //   12082: invokeinterface getDouble : (I)D
/*      */     //   12087: wide dstore #850
/*      */     //   12091: wide aload #854
/*      */     //   12095: sipush #484
/*      */     //   12098: wide dload #850
/*      */     //   12102: invokeinterface setDouble : (ID)V
/*      */     //   12107: aload_2
/*      */     //   12108: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12111: wide astore #848
/*      */     //   12115: aload_2
/*      */     //   12116: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12119: wide astore #846
/*      */     //   12123: wide aload #846
/*      */     //   12127: iconst_0
/*      */     //   12128: ldc 35588
/*      */     //   12130: iadd
/*      */     //   12131: dconst_1
/*      */     //   12132: invokeinterface setDouble : (ID)V
/*      */     //   12137: wide aload #846
/*      */     //   12141: iconst_0
/*      */     //   12142: ldc 35588
/*      */     //   12144: iadd
/*      */     //   12145: invokeinterface getDouble : (I)D
/*      */     //   12150: wide dstore #844
/*      */     //   12154: wide aload #848
/*      */     //   12158: iconst_0
/*      */     //   12159: ldc 35588
/*      */     //   12161: iadd
/*      */     //   12162: wide dload #844
/*      */     //   12166: invokeinterface setDouble : (ID)V
/*      */     //   12171: goto -> 12299
/*      */     //   12174: aload_2
/*      */     //   12175: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12178: wide astore #842
/*      */     //   12182: aload_2
/*      */     //   12183: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12186: wide astore #840
/*      */     //   12190: wide aload #840
/*      */     //   12194: sipush #484
/*      */     //   12197: dconst_1
/*      */     //   12198: invokeinterface setDouble : (ID)V
/*      */     //   12203: wide aload #840
/*      */     //   12207: sipush #484
/*      */     //   12210: invokeinterface getDouble : (I)D
/*      */     //   12215: wide dstore #838
/*      */     //   12219: wide aload #842
/*      */     //   12223: sipush #484
/*      */     //   12226: wide dload #838
/*      */     //   12230: invokeinterface setDouble : (ID)V
/*      */     //   12235: aload_2
/*      */     //   12236: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12239: wide astore #836
/*      */     //   12243: aload_2
/*      */     //   12244: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12247: wide astore #834
/*      */     //   12251: wide aload #834
/*      */     //   12255: iconst_0
/*      */     //   12256: ldc 35588
/*      */     //   12258: iadd
/*      */     //   12259: dconst_1
/*      */     //   12260: invokeinterface setDouble : (ID)V
/*      */     //   12265: wide aload #834
/*      */     //   12269: iconst_0
/*      */     //   12270: ldc 35588
/*      */     //   12272: iadd
/*      */     //   12273: invokeinterface getDouble : (I)D
/*      */     //   12278: wide dstore #832
/*      */     //   12282: wide aload #836
/*      */     //   12286: iconst_0
/*      */     //   12287: ldc 35588
/*      */     //   12289: iadd
/*      */     //   12290: wide dload #832
/*      */     //   12294: invokeinterface setDouble : (ID)V
/*      */     //   12299: aload_2
/*      */     //   12300: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12303: wide astore #830
/*      */     //   12307: aload_2
/*      */     //   12308: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12311: wide astore #828
/*      */     //   12315: wide aload #828
/*      */     //   12319: iconst_0
/*      */     //   12320: ldc_w 35404
/*      */     //   12323: iadd
/*      */     //   12324: iconst_0
/*      */     //   12325: invokeinterface setInt : (II)V
/*      */     //   12330: wide aload #828
/*      */     //   12334: iconst_0
/*      */     //   12335: ldc_w 35404
/*      */     //   12338: iadd
/*      */     //   12339: invokeinterface getInt : (I)I
/*      */     //   12344: wide istore #827
/*      */     //   12348: wide aload #830
/*      */     //   12352: iconst_0
/*      */     //   12353: ldc_w 35404
/*      */     //   12356: iadd
/*      */     //   12357: wide iload #827
/*      */     //   12361: invokeinterface setInt : (II)V
/*      */     //   12366: aload_2
/*      */     //   12367: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   12370: goto -> 19275
/*      */     //   12373: aload_0
/*      */     //   12374: new org/renjin/gcc/runtime/BytePtr
/*      */     //   12377: dup
/*      */     //   12378: ldc_w 'mfcol '
/*      */     //   12381: invokevirtual getBytes : ()[B
/*      */     //   12384: iconst_0
/*      */     //   12385: invokespecial <init> : ([BI)V
/*      */     //   12388: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   12391: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   12394: ifeq -> 12400
/*      */     //   12397: goto -> 13353
/*      */     //   12400: aload_1
/*      */     //   12401: bipush #13
/*      */     //   12403: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   12406: astore_1
/*      */     //   12407: aload_0
/*      */     //   12408: aload_1
/*      */     //   12409: iconst_2
/*      */     //   12410: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   12413: aload_1
/*      */     //   12414: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12417: invokeinterface getInt : ()I
/*      */     //   12422: aload_0
/*      */     //   12423: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   12426: aload_1
/*      */     //   12427: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12430: iconst_4
/*      */     //   12431: invokeinterface getInt : (I)I
/*      */     //   12436: aload_0
/*      */     //   12437: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   12440: aload_1
/*      */     //   12441: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12444: invokeinterface getInt : ()I
/*      */     //   12449: istore #9
/*      */     //   12451: aload_1
/*      */     //   12452: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12455: iconst_4
/*      */     //   12456: invokeinterface getInt : (I)I
/*      */     //   12461: istore #8
/*      */     //   12463: aload_2
/*      */     //   12464: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12467: wide astore #812
/*      */     //   12471: aload_2
/*      */     //   12472: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12475: wide astore #810
/*      */     //   12479: wide aload #810
/*      */     //   12483: sipush #560
/*      */     //   12486: iload #9
/*      */     //   12488: invokeinterface setInt : (II)V
/*      */     //   12493: wide aload #810
/*      */     //   12497: sipush #560
/*      */     //   12500: invokeinterface getInt : (I)I
/*      */     //   12505: wide istore #809
/*      */     //   12509: wide aload #812
/*      */     //   12513: sipush #560
/*      */     //   12516: wide iload #809
/*      */     //   12520: invokeinterface setInt : (II)V
/*      */     //   12525: aload_2
/*      */     //   12526: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12529: wide astore #807
/*      */     //   12533: aload_2
/*      */     //   12534: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12537: wide astore #805
/*      */     //   12541: wide aload #805
/*      */     //   12545: sipush #564
/*      */     //   12548: iload #8
/*      */     //   12550: invokeinterface setInt : (II)V
/*      */     //   12555: wide aload #805
/*      */     //   12559: sipush #564
/*      */     //   12562: invokeinterface getInt : (I)I
/*      */     //   12567: wide istore #804
/*      */     //   12571: wide aload #807
/*      */     //   12575: sipush #564
/*      */     //   12578: wide iload #804
/*      */     //   12582: invokeinterface setInt : (II)V
/*      */     //   12587: aload_2
/*      */     //   12588: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12591: wide astore #802
/*      */     //   12595: aload_2
/*      */     //   12596: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12599: wide astore #800
/*      */     //   12603: iload #9
/*      */     //   12605: iload #8
/*      */     //   12607: imul
/*      */     //   12608: wide istore #799
/*      */     //   12612: wide aload #800
/*      */     //   12616: sipush #568
/*      */     //   12619: wide iload #799
/*      */     //   12623: invokeinterface setInt : (II)V
/*      */     //   12628: wide aload #800
/*      */     //   12632: sipush #568
/*      */     //   12635: invokeinterface getInt : (I)I
/*      */     //   12640: wide istore #798
/*      */     //   12644: wide aload #802
/*      */     //   12648: sipush #568
/*      */     //   12651: wide iload #798
/*      */     //   12655: invokeinterface setInt : (II)V
/*      */     //   12660: aload_2
/*      */     //   12661: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12664: wide astore #796
/*      */     //   12668: aload_2
/*      */     //   12669: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12672: wide astore #794
/*      */     //   12676: iload #9
/*      */     //   12678: iload #8
/*      */     //   12680: imul
/*      */     //   12681: wide istore #793
/*      */     //   12685: wide aload #794
/*      */     //   12689: sipush #572
/*      */     //   12692: wide iload #793
/*      */     //   12696: invokeinterface setInt : (II)V
/*      */     //   12701: wide aload #794
/*      */     //   12705: sipush #572
/*      */     //   12708: invokeinterface getInt : (I)I
/*      */     //   12713: wide istore #792
/*      */     //   12717: wide aload #796
/*      */     //   12721: sipush #572
/*      */     //   12724: wide iload #792
/*      */     //   12728: invokeinterface setInt : (II)V
/*      */     //   12733: aload_2
/*      */     //   12734: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12737: wide astore #790
/*      */     //   12741: aload_2
/*      */     //   12742: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12745: wide astore #788
/*      */     //   12749: wide aload #788
/*      */     //   12753: iconst_0
/*      */     //   12754: ldc 35512
/*      */     //   12756: iadd
/*      */     //   12757: iconst_1
/*      */     //   12758: invokeinterface setInt : (II)V
/*      */     //   12763: wide aload #788
/*      */     //   12767: iconst_0
/*      */     //   12768: ldc 35512
/*      */     //   12770: iadd
/*      */     //   12771: invokeinterface getInt : (I)I
/*      */     //   12776: wide istore #787
/*      */     //   12780: wide aload #790
/*      */     //   12784: iconst_0
/*      */     //   12785: ldc 35512
/*      */     //   12787: iadd
/*      */     //   12788: wide iload #787
/*      */     //   12792: invokeinterface setInt : (II)V
/*      */     //   12797: aload_2
/*      */     //   12798: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12801: wide astore #785
/*      */     //   12805: aload_2
/*      */     //   12806: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12809: wide astore #783
/*      */     //   12813: wide aload #783
/*      */     //   12817: sipush #556
/*      */     //   12820: iconst_0
/*      */     //   12821: invokeinterface setInt : (II)V
/*      */     //   12826: wide aload #783
/*      */     //   12830: sipush #556
/*      */     //   12833: invokeinterface getInt : (I)I
/*      */     //   12838: wide istore #782
/*      */     //   12842: wide aload #785
/*      */     //   12846: sipush #556
/*      */     //   12849: wide iload #782
/*      */     //   12853: invokeinterface setInt : (II)V
/*      */     //   12858: iload #9
/*      */     //   12860: iconst_2
/*      */     //   12861: if_icmpgt -> 12876
/*      */     //   12864: goto -> 12867
/*      */     //   12867: iload #8
/*      */     //   12869: iconst_2
/*      */     //   12870: if_icmpgt -> 12876
/*      */     //   12873: goto -> 13006
/*      */     //   12876: aload_2
/*      */     //   12877: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12880: wide astore #780
/*      */     //   12884: aload_2
/*      */     //   12885: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12888: wide astore #778
/*      */     //   12892: wide aload #778
/*      */     //   12896: sipush #484
/*      */     //   12899: ldc2_w 0.66
/*      */     //   12902: invokeinterface setDouble : (ID)V
/*      */     //   12907: wide aload #778
/*      */     //   12911: sipush #484
/*      */     //   12914: invokeinterface getDouble : (I)D
/*      */     //   12919: wide dstore #776
/*      */     //   12923: wide aload #780
/*      */     //   12927: sipush #484
/*      */     //   12930: wide dload #776
/*      */     //   12934: invokeinterface setDouble : (ID)V
/*      */     //   12939: aload_2
/*      */     //   12940: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12943: wide astore #774
/*      */     //   12947: aload_2
/*      */     //   12948: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   12951: wide astore #772
/*      */     //   12955: wide aload #772
/*      */     //   12959: iconst_0
/*      */     //   12960: ldc 35588
/*      */     //   12962: iadd
/*      */     //   12963: dconst_1
/*      */     //   12964: invokeinterface setDouble : (ID)V
/*      */     //   12969: wide aload #772
/*      */     //   12973: iconst_0
/*      */     //   12974: ldc 35588
/*      */     //   12976: iadd
/*      */     //   12977: invokeinterface getDouble : (I)D
/*      */     //   12982: wide dstore #770
/*      */     //   12986: wide aload #774
/*      */     //   12990: iconst_0
/*      */     //   12991: ldc 35588
/*      */     //   12993: iadd
/*      */     //   12994: wide dload #770
/*      */     //   12998: invokeinterface setDouble : (ID)V
/*      */     //   13003: goto -> 13279
/*      */     //   13006: iload #9
/*      */     //   13008: iconst_2
/*      */     //   13009: if_icmpeq -> 13015
/*      */     //   13012: goto -> 13154
/*      */     //   13015: iload #8
/*      */     //   13017: iconst_2
/*      */     //   13018: if_icmpeq -> 13024
/*      */     //   13021: goto -> 13154
/*      */     //   13024: aload_2
/*      */     //   13025: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13028: wide astore #768
/*      */     //   13032: aload_2
/*      */     //   13033: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13036: wide astore #766
/*      */     //   13040: wide aload #766
/*      */     //   13044: sipush #484
/*      */     //   13047: ldc2_w 0.83
/*      */     //   13050: invokeinterface setDouble : (ID)V
/*      */     //   13055: wide aload #766
/*      */     //   13059: sipush #484
/*      */     //   13062: invokeinterface getDouble : (I)D
/*      */     //   13067: wide dstore #764
/*      */     //   13071: wide aload #768
/*      */     //   13075: sipush #484
/*      */     //   13078: wide dload #764
/*      */     //   13082: invokeinterface setDouble : (ID)V
/*      */     //   13087: aload_2
/*      */     //   13088: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13091: wide astore #762
/*      */     //   13095: aload_2
/*      */     //   13096: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13099: wide astore #760
/*      */     //   13103: wide aload #760
/*      */     //   13107: iconst_0
/*      */     //   13108: ldc 35588
/*      */     //   13110: iadd
/*      */     //   13111: dconst_1
/*      */     //   13112: invokeinterface setDouble : (ID)V
/*      */     //   13117: wide aload #760
/*      */     //   13121: iconst_0
/*      */     //   13122: ldc 35588
/*      */     //   13124: iadd
/*      */     //   13125: invokeinterface getDouble : (I)D
/*      */     //   13130: wide dstore #758
/*      */     //   13134: wide aload #762
/*      */     //   13138: iconst_0
/*      */     //   13139: ldc 35588
/*      */     //   13141: iadd
/*      */     //   13142: wide dload #758
/*      */     //   13146: invokeinterface setDouble : (ID)V
/*      */     //   13151: goto -> 13279
/*      */     //   13154: aload_2
/*      */     //   13155: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13158: wide astore #756
/*      */     //   13162: aload_2
/*      */     //   13163: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13166: wide astore #754
/*      */     //   13170: wide aload #754
/*      */     //   13174: sipush #484
/*      */     //   13177: dconst_1
/*      */     //   13178: invokeinterface setDouble : (ID)V
/*      */     //   13183: wide aload #754
/*      */     //   13187: sipush #484
/*      */     //   13190: invokeinterface getDouble : (I)D
/*      */     //   13195: wide dstore #752
/*      */     //   13199: wide aload #756
/*      */     //   13203: sipush #484
/*      */     //   13206: wide dload #752
/*      */     //   13210: invokeinterface setDouble : (ID)V
/*      */     //   13215: aload_2
/*      */     //   13216: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13219: wide astore #750
/*      */     //   13223: aload_2
/*      */     //   13224: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13227: wide astore #748
/*      */     //   13231: wide aload #748
/*      */     //   13235: iconst_0
/*      */     //   13236: ldc 35588
/*      */     //   13238: iadd
/*      */     //   13239: dconst_1
/*      */     //   13240: invokeinterface setDouble : (ID)V
/*      */     //   13245: wide aload #748
/*      */     //   13249: iconst_0
/*      */     //   13250: ldc 35588
/*      */     //   13252: iadd
/*      */     //   13253: invokeinterface getDouble : (I)D
/*      */     //   13258: wide dstore #746
/*      */     //   13262: wide aload #750
/*      */     //   13266: iconst_0
/*      */     //   13267: ldc 35588
/*      */     //   13269: iadd
/*      */     //   13270: wide dload #746
/*      */     //   13274: invokeinterface setDouble : (ID)V
/*      */     //   13279: aload_2
/*      */     //   13280: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13283: wide astore #744
/*      */     //   13287: aload_2
/*      */     //   13288: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13291: wide astore #742
/*      */     //   13295: wide aload #742
/*      */     //   13299: iconst_0
/*      */     //   13300: ldc_w 35404
/*      */     //   13303: iadd
/*      */     //   13304: iconst_1
/*      */     //   13305: invokeinterface setInt : (II)V
/*      */     //   13310: wide aload #742
/*      */     //   13314: iconst_0
/*      */     //   13315: ldc_w 35404
/*      */     //   13318: iadd
/*      */     //   13319: invokeinterface getInt : (I)I
/*      */     //   13324: wide istore #741
/*      */     //   13328: wide aload #744
/*      */     //   13332: iconst_0
/*      */     //   13333: ldc_w 35404
/*      */     //   13336: iadd
/*      */     //   13337: wide iload #741
/*      */     //   13341: invokeinterface setInt : (II)V
/*      */     //   13346: aload_2
/*      */     //   13347: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   13350: goto -> 19275
/*      */     //   13353: aload_0
/*      */     //   13354: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13357: dup
/*      */     //   13358: ldc_w 'mfg '
/*      */     //   13361: invokevirtual getBytes : ()[B
/*      */     //   13364: iconst_0
/*      */     //   13365: invokespecial <init> : ([BI)V
/*      */     //   13368: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   13371: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   13374: ifeq -> 13380
/*      */     //   13377: goto -> 14113
/*      */     //   13380: aload_1
/*      */     //   13381: bipush #13
/*      */     //   13383: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   13386: astore_1
/*      */     //   13387: aload_1
/*      */     //   13388: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   13391: pop
/*      */     //   13392: aload_1
/*      */     //   13393: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   13396: istore_3
/*      */     //   13397: iload_3
/*      */     //   13398: iconst_2
/*      */     //   13399: if_icmpne -> 13405
/*      */     //   13402: goto -> 13453
/*      */     //   13405: iload_3
/*      */     //   13406: iconst_4
/*      */     //   13407: if_icmpne -> 13413
/*      */     //   13410: goto -> 13453
/*      */     //   13413: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13416: dup
/*      */     //   13417: ldc 'graphics '
/*      */     //   13419: invokevirtual getBytes : ()[B
/*      */     //   13422: iconst_0
/*      */     //   13423: invokespecial <init> : ([BI)V
/*      */     //   13426: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13429: dup
/*      */     //   13430: ldc_w 'parameter "mfg" has the wrong length '
/*      */     //   13433: invokevirtual getBytes : ()[B
/*      */     //   13436: iconst_0
/*      */     //   13437: invokespecial <init> : ([BI)V
/*      */     //   13440: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   13443: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   13446: iconst_0
/*      */     //   13447: anewarray java/lang/Object
/*      */     //   13450: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   13453: aload_1
/*      */     //   13454: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13457: invokeinterface getInt : ()I
/*      */     //   13462: aload_0
/*      */     //   13463: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   13466: aload_1
/*      */     //   13467: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13470: iconst_4
/*      */     //   13471: invokeinterface getInt : (I)I
/*      */     //   13476: aload_0
/*      */     //   13477: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   13480: aload_1
/*      */     //   13481: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13484: invokeinterface getInt : ()I
/*      */     //   13489: istore #7
/*      */     //   13491: aload_1
/*      */     //   13492: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13495: iconst_4
/*      */     //   13496: invokeinterface getInt : (I)I
/*      */     //   13501: istore #6
/*      */     //   13503: aload_2
/*      */     //   13504: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13507: sipush #560
/*      */     //   13510: invokeinterface getInt : (I)I
/*      */     //   13515: istore #5
/*      */     //   13517: aload_2
/*      */     //   13518: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13521: sipush #564
/*      */     //   13524: invokeinterface getInt : (I)I
/*      */     //   13529: istore #4
/*      */     //   13531: iload #7
/*      */     //   13533: ifle -> 13549
/*      */     //   13536: goto -> 13539
/*      */     //   13539: iload #7
/*      */     //   13541: iload #5
/*      */     //   13543: if_icmpgt -> 13549
/*      */     //   13546: goto -> 13589
/*      */     //   13549: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13552: dup
/*      */     //   13553: ldc 'graphics '
/*      */     //   13555: invokevirtual getBytes : ()[B
/*      */     //   13558: iconst_0
/*      */     //   13559: invokespecial <init> : ([BI)V
/*      */     //   13562: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13565: dup
/*      */     //   13566: ldc_w 'parameter "i" in "mfg" is out of range '
/*      */     //   13569: invokevirtual getBytes : ()[B
/*      */     //   13572: iconst_0
/*      */     //   13573: invokespecial <init> : ([BI)V
/*      */     //   13576: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   13579: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   13582: iconst_0
/*      */     //   13583: anewarray java/lang/Object
/*      */     //   13586: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   13589: iload #6
/*      */     //   13591: ifle -> 13607
/*      */     //   13594: goto -> 13597
/*      */     //   13597: iload #6
/*      */     //   13599: iload #4
/*      */     //   13601: if_icmpgt -> 13607
/*      */     //   13604: goto -> 13647
/*      */     //   13607: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13610: dup
/*      */     //   13611: ldc 'graphics '
/*      */     //   13613: invokevirtual getBytes : ()[B
/*      */     //   13616: iconst_0
/*      */     //   13617: invokespecial <init> : ([BI)V
/*      */     //   13620: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13623: dup
/*      */     //   13624: ldc_w 'parameter "j" in "mfg" is out of range '
/*      */     //   13627: invokevirtual getBytes : ()[B
/*      */     //   13630: iconst_0
/*      */     //   13631: invokespecial <init> : ([BI)V
/*      */     //   13634: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   13637: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   13640: iconst_0
/*      */     //   13641: anewarray java/lang/Object
/*      */     //   13644: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   13647: iload_3
/*      */     //   13648: iconst_4
/*      */     //   13649: if_icmpeq -> 13655
/*      */     //   13652: goto -> 13803
/*      */     //   13655: aload_1
/*      */     //   13656: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13659: bipush #8
/*      */     //   13661: invokeinterface getInt : (I)I
/*      */     //   13666: aload_0
/*      */     //   13667: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   13670: aload_1
/*      */     //   13671: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13674: bipush #12
/*      */     //   13676: invokeinterface getInt : (I)I
/*      */     //   13681: aload_0
/*      */     //   13682: invokestatic posIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   13685: aload_1
/*      */     //   13686: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13689: bipush #8
/*      */     //   13691: invokeinterface getInt : (I)I
/*      */     //   13696: iload #5
/*      */     //   13698: if_icmpne -> 13704
/*      */     //   13701: goto -> 13744
/*      */     //   13704: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13707: dup
/*      */     //   13708: ldc 'graphics '
/*      */     //   13710: invokevirtual getBytes : ()[B
/*      */     //   13713: iconst_0
/*      */     //   13714: invokespecial <init> : ([BI)V
/*      */     //   13717: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13720: dup
/*      */     //   13721: ldc_w 'value of 'nr' in "mfg" is wrong and will be ignored '
/*      */     //   13724: invokevirtual getBytes : ()[B
/*      */     //   13727: iconst_0
/*      */     //   13728: invokespecial <init> : ([BI)V
/*      */     //   13731: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   13734: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   13737: iconst_0
/*      */     //   13738: anewarray java/lang/Object
/*      */     //   13741: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   13744: aload_1
/*      */     //   13745: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13748: bipush #12
/*      */     //   13750: invokeinterface getInt : (I)I
/*      */     //   13755: iload #4
/*      */     //   13757: if_icmpne -> 13763
/*      */     //   13760: goto -> 13803
/*      */     //   13763: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13766: dup
/*      */     //   13767: ldc 'graphics '
/*      */     //   13769: invokevirtual getBytes : ()[B
/*      */     //   13772: iconst_0
/*      */     //   13773: invokespecial <init> : ([BI)V
/*      */     //   13776: new org/renjin/gcc/runtime/BytePtr
/*      */     //   13779: dup
/*      */     //   13780: ldc_w 'value of 'nc' in "mfg" is wrong and will be ignored '
/*      */     //   13783: invokevirtual getBytes : ()[B
/*      */     //   13786: iconst_0
/*      */     //   13787: invokespecial <init> : ([BI)V
/*      */     //   13790: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   13793: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   13796: iconst_0
/*      */     //   13797: anewarray java/lang/Object
/*      */     //   13800: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   13803: aload_2
/*      */     //   13804: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13807: wide astore #692
/*      */     //   13811: aload_2
/*      */     //   13812: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13815: wide astore #690
/*      */     //   13819: iload #5
/*      */     //   13821: iload #4
/*      */     //   13823: imul
/*      */     //   13824: wide istore #689
/*      */     //   13828: wide aload #690
/*      */     //   13832: sipush #572
/*      */     //   13835: wide iload #689
/*      */     //   13839: invokeinterface setInt : (II)V
/*      */     //   13844: wide aload #690
/*      */     //   13848: sipush #572
/*      */     //   13851: invokeinterface getInt : (I)I
/*      */     //   13856: wide istore #688
/*      */     //   13860: wide aload #692
/*      */     //   13864: sipush #572
/*      */     //   13867: wide iload #688
/*      */     //   13871: invokeinterface setInt : (II)V
/*      */     //   13876: aload_2
/*      */     //   13877: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13880: iconst_0
/*      */     //   13881: ldc_w 35404
/*      */     //   13884: iadd
/*      */     //   13885: invokeinterface getInt : (I)I
/*      */     //   13890: ifne -> 13896
/*      */     //   13893: goto -> 13937
/*      */     //   13896: aload_2
/*      */     //   13897: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13900: wide astore #683
/*      */     //   13904: iload #6
/*      */     //   13906: iconst_m1
/*      */     //   13907: iadd
/*      */     //   13908: iload #5
/*      */     //   13910: imul
/*      */     //   13911: iload #7
/*      */     //   13913: iadd
/*      */     //   13914: wide istore #680
/*      */     //   13918: wide aload #683
/*      */     //   13922: sipush #568
/*      */     //   13925: wide iload #680
/*      */     //   13929: invokeinterface setInt : (II)V
/*      */     //   13934: goto -> 13975
/*      */     //   13937: aload_2
/*      */     //   13938: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13941: wide astore #678
/*      */     //   13945: iload #7
/*      */     //   13947: iconst_m1
/*      */     //   13948: iadd
/*      */     //   13949: iload #4
/*      */     //   13951: imul
/*      */     //   13952: iload #6
/*      */     //   13954: iadd
/*      */     //   13955: wide istore #675
/*      */     //   13959: wide aload #678
/*      */     //   13963: sipush #568
/*      */     //   13966: wide iload #675
/*      */     //   13970: invokeinterface setInt : (II)V
/*      */     //   13975: aload_2
/*      */     //   13976: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13979: wide astore #673
/*      */     //   13983: aload_2
/*      */     //   13984: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   13987: sipush #568
/*      */     //   13990: invokeinterface getInt : (I)I
/*      */     //   13995: wide istore #670
/*      */     //   13999: wide aload #673
/*      */     //   14003: sipush #568
/*      */     //   14006: wide iload #670
/*      */     //   14010: invokeinterface setInt : (II)V
/*      */     //   14015: aload_2
/*      */     //   14016: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14019: wide astore #668
/*      */     //   14023: aload_2
/*      */     //   14024: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14027: wide astore #666
/*      */     //   14031: wide aload #666
/*      */     //   14035: iconst_0
/*      */     //   14036: ldc_w 35764
/*      */     //   14039: iadd
/*      */     //   14040: iconst_1
/*      */     //   14041: invokeinterface setInt : (II)V
/*      */     //   14046: wide aload #666
/*      */     //   14050: iconst_0
/*      */     //   14051: ldc_w 35764
/*      */     //   14054: iadd
/*      */     //   14055: invokeinterface getInt : (I)I
/*      */     //   14060: wide istore #665
/*      */     //   14064: wide aload #668
/*      */     //   14068: iconst_0
/*      */     //   14069: ldc_w 35764
/*      */     //   14072: iadd
/*      */     //   14073: wide iload #665
/*      */     //   14077: invokeinterface setInt : (II)V
/*      */     //   14082: aload_2
/*      */     //   14083: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14086: aload_2
/*      */     //   14087: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14092: sipush #128
/*      */     //   14095: invokeinterface getInt : (I)I
/*      */     //   14100: ifne -> 14106
/*      */     //   14103: goto -> 19275
/*      */     //   14106: aload_2
/*      */     //   14107: invokestatic Rf_GForceClip : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14110: goto -> 19275
/*      */     //   14113: aload_0
/*      */     //   14114: new org/renjin/gcc/runtime/BytePtr
/*      */     //   14117: dup
/*      */     //   14118: ldc_w 'new '
/*      */     //   14121: invokevirtual getBytes : ()[B
/*      */     //   14124: iconst_0
/*      */     //   14125: invokespecial <init> : ([BI)V
/*      */     //   14128: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   14131: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   14134: ifeq -> 14140
/*      */     //   14137: goto -> 14308
/*      */     //   14140: aload_0
/*      */     //   14141: aload_1
/*      */     //   14142: iconst_1
/*      */     //   14143: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   14146: aload_1
/*      */     //   14147: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   14150: istore #17
/*      */     //   14152: aload_2
/*      */     //   14153: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14156: invokeinterface getInt : ()I
/*      */     //   14161: ifeq -> 14167
/*      */     //   14164: goto -> 14218
/*      */     //   14167: iload #17
/*      */     //   14169: ifne -> 14175
/*      */     //   14172: goto -> 19275
/*      */     //   14175: new org/renjin/gcc/runtime/BytePtr
/*      */     //   14178: dup
/*      */     //   14179: ldc 'graphics '
/*      */     //   14181: invokevirtual getBytes : ()[B
/*      */     //   14184: iconst_0
/*      */     //   14185: invokespecial <init> : ([BI)V
/*      */     //   14188: new org/renjin/gcc/runtime/BytePtr
/*      */     //   14191: dup
/*      */     //   14192: ldc_w 'calling par(new=TRUE) with no plot '
/*      */     //   14195: invokevirtual getBytes : ()[B
/*      */     //   14198: iconst_0
/*      */     //   14199: invokespecial <init> : ([BI)V
/*      */     //   14202: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   14205: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   14208: iconst_0
/*      */     //   14209: anewarray java/lang/Object
/*      */     //   14212: invokestatic Rf_warning : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   14215: goto -> 19275
/*      */     //   14218: aload_2
/*      */     //   14219: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14222: wide astore #654
/*      */     //   14226: aload_2
/*      */     //   14227: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14230: wide astore #652
/*      */     //   14234: iload #17
/*      */     //   14236: ifne -> 14246
/*      */     //   14239: goto -> 14242
/*      */     //   14242: iconst_0
/*      */     //   14243: goto -> 14247
/*      */     //   14246: iconst_1
/*      */     //   14247: wide istore #650
/*      */     //   14251: wide aload #652
/*      */     //   14255: iconst_0
/*      */     //   14256: ldc_w 35764
/*      */     //   14259: iadd
/*      */     //   14260: wide iload #650
/*      */     //   14264: invokeinterface setInt : (II)V
/*      */     //   14269: wide aload #652
/*      */     //   14273: iconst_0
/*      */     //   14274: ldc_w 35764
/*      */     //   14277: iadd
/*      */     //   14278: invokeinterface getInt : (I)I
/*      */     //   14283: wide istore #649
/*      */     //   14287: wide aload #654
/*      */     //   14291: iconst_0
/*      */     //   14292: ldc_w 35764
/*      */     //   14295: iadd
/*      */     //   14296: wide iload #649
/*      */     //   14300: invokeinterface setInt : (II)V
/*      */     //   14305: goto -> 19275
/*      */     //   14308: aload_0
/*      */     //   14309: new org/renjin/gcc/runtime/BytePtr
/*      */     //   14312: dup
/*      */     //   14313: ldc_w 'oma '
/*      */     //   14316: invokevirtual getBytes : ()[B
/*      */     //   14319: iconst_0
/*      */     //   14320: invokespecial <init> : ([BI)V
/*      */     //   14323: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   14326: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   14329: ifeq -> 14335
/*      */     //   14332: goto -> 14926
/*      */     //   14335: aload_1
/*      */     //   14336: bipush #14
/*      */     //   14338: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   14341: astore_1
/*      */     //   14342: aload_0
/*      */     //   14343: aload_1
/*      */     //   14344: iconst_4
/*      */     //   14345: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   14348: aload_1
/*      */     //   14349: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14352: invokeinterface getDouble : ()D
/*      */     //   14357: aload_0
/*      */     //   14358: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14361: aload_1
/*      */     //   14362: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14365: bipush #8
/*      */     //   14367: invokeinterface getDouble : (I)D
/*      */     //   14372: aload_0
/*      */     //   14373: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14376: aload_1
/*      */     //   14377: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14380: bipush #16
/*      */     //   14382: invokeinterface getDouble : (I)D
/*      */     //   14387: aload_0
/*      */     //   14388: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14391: aload_1
/*      */     //   14392: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14395: bipush #24
/*      */     //   14397: invokeinterface getDouble : (I)D
/*      */     //   14402: aload_0
/*      */     //   14403: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14406: aload_2
/*      */     //   14407: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14410: wide astore #624
/*      */     //   14414: aload_2
/*      */     //   14415: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14418: wide astore #622
/*      */     //   14422: aload_1
/*      */     //   14423: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14426: invokeinterface getDouble : ()D
/*      */     //   14431: wide dstore #618
/*      */     //   14435: wide aload #622
/*      */     //   14439: iconst_0
/*      */     //   14440: ldc_w 35596
/*      */     //   14443: iadd
/*      */     //   14444: wide dload #618
/*      */     //   14448: invokeinterface setDouble : (ID)V
/*      */     //   14453: wide aload #622
/*      */     //   14457: iconst_0
/*      */     //   14458: ldc_w 35596
/*      */     //   14461: iadd
/*      */     //   14462: invokeinterface getDouble : (I)D
/*      */     //   14467: wide dstore #616
/*      */     //   14471: wide aload #624
/*      */     //   14475: iconst_0
/*      */     //   14476: ldc_w 35596
/*      */     //   14479: iadd
/*      */     //   14480: wide dload #616
/*      */     //   14484: invokeinterface setDouble : (ID)V
/*      */     //   14489: aload_2
/*      */     //   14490: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14493: wide astore #614
/*      */     //   14497: aload_2
/*      */     //   14498: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14501: wide astore #612
/*      */     //   14505: aload_1
/*      */     //   14506: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14509: bipush #8
/*      */     //   14511: invokeinterface getDouble : (I)D
/*      */     //   14516: wide dstore #608
/*      */     //   14520: wide aload #612
/*      */     //   14524: iconst_0
/*      */     //   14525: ldc_w 35596
/*      */     //   14528: iadd
/*      */     //   14529: bipush #8
/*      */     //   14531: iadd
/*      */     //   14532: wide dload #608
/*      */     //   14536: invokeinterface setDouble : (ID)V
/*      */     //   14541: wide aload #612
/*      */     //   14545: iconst_0
/*      */     //   14546: ldc_w 35596
/*      */     //   14549: iadd
/*      */     //   14550: bipush #8
/*      */     //   14552: iadd
/*      */     //   14553: invokeinterface getDouble : (I)D
/*      */     //   14558: wide dstore #606
/*      */     //   14562: wide aload #614
/*      */     //   14566: iconst_0
/*      */     //   14567: ldc_w 35596
/*      */     //   14570: iadd
/*      */     //   14571: bipush #8
/*      */     //   14573: iadd
/*      */     //   14574: wide dload #606
/*      */     //   14578: invokeinterface setDouble : (ID)V
/*      */     //   14583: aload_2
/*      */     //   14584: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14587: wide astore #604
/*      */     //   14591: aload_2
/*      */     //   14592: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14595: wide astore #602
/*      */     //   14599: aload_1
/*      */     //   14600: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14603: bipush #16
/*      */     //   14605: invokeinterface getDouble : (I)D
/*      */     //   14610: wide dstore #598
/*      */     //   14614: wide aload #602
/*      */     //   14618: iconst_0
/*      */     //   14619: ldc_w 35596
/*      */     //   14622: iadd
/*      */     //   14623: bipush #16
/*      */     //   14625: iadd
/*      */     //   14626: wide dload #598
/*      */     //   14630: invokeinterface setDouble : (ID)V
/*      */     //   14635: wide aload #602
/*      */     //   14639: iconst_0
/*      */     //   14640: ldc_w 35596
/*      */     //   14643: iadd
/*      */     //   14644: bipush #16
/*      */     //   14646: iadd
/*      */     //   14647: invokeinterface getDouble : (I)D
/*      */     //   14652: wide dstore #596
/*      */     //   14656: wide aload #604
/*      */     //   14660: iconst_0
/*      */     //   14661: ldc_w 35596
/*      */     //   14664: iadd
/*      */     //   14665: bipush #16
/*      */     //   14667: iadd
/*      */     //   14668: wide dload #596
/*      */     //   14672: invokeinterface setDouble : (ID)V
/*      */     //   14677: aload_2
/*      */     //   14678: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14681: wide astore #594
/*      */     //   14685: aload_2
/*      */     //   14686: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14689: wide astore #592
/*      */     //   14693: aload_1
/*      */     //   14694: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14697: bipush #24
/*      */     //   14699: invokeinterface getDouble : (I)D
/*      */     //   14704: wide dstore #588
/*      */     //   14708: wide aload #592
/*      */     //   14712: iconst_0
/*      */     //   14713: ldc_w 35596
/*      */     //   14716: iadd
/*      */     //   14717: bipush #24
/*      */     //   14719: iadd
/*      */     //   14720: wide dload #588
/*      */     //   14724: invokeinterface setDouble : (ID)V
/*      */     //   14729: wide aload #592
/*      */     //   14733: iconst_0
/*      */     //   14734: ldc_w 35596
/*      */     //   14737: iadd
/*      */     //   14738: bipush #24
/*      */     //   14740: iadd
/*      */     //   14741: invokeinterface getDouble : (I)D
/*      */     //   14746: wide dstore #586
/*      */     //   14750: wide aload #594
/*      */     //   14754: iconst_0
/*      */     //   14755: ldc_w 35596
/*      */     //   14758: iadd
/*      */     //   14759: bipush #24
/*      */     //   14761: iadd
/*      */     //   14762: wide dload #586
/*      */     //   14766: invokeinterface setDouble : (ID)V
/*      */     //   14771: aload_2
/*      */     //   14772: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14775: wide astore #584
/*      */     //   14779: aload_2
/*      */     //   14780: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14783: wide astore #582
/*      */     //   14787: wide aload #582
/*      */     //   14791: iconst_0
/*      */     //   14792: ldc_w 35692
/*      */     //   14795: iadd
/*      */     //   14796: bipush #14
/*      */     //   14798: invokeinterface setInt : (II)V
/*      */     //   14803: wide aload #582
/*      */     //   14807: iconst_0
/*      */     //   14808: ldc_w 35692
/*      */     //   14811: iadd
/*      */     //   14812: invokeinterface getInt : (I)I
/*      */     //   14817: wide istore #581
/*      */     //   14821: wide aload #584
/*      */     //   14825: iconst_0
/*      */     //   14826: ldc_w 35692
/*      */     //   14829: iadd
/*      */     //   14830: wide iload #581
/*      */     //   14834: invokeinterface setInt : (II)V
/*      */     //   14839: aload_2
/*      */     //   14840: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14843: wide astore #579
/*      */     //   14847: aload_2
/*      */     //   14848: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14851: wide astore #577
/*      */     //   14855: aload_2
/*      */     //   14856: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14859: sipush #572
/*      */     //   14862: invokeinterface getInt : (I)I
/*      */     //   14867: wide istore #574
/*      */     //   14871: wide aload #577
/*      */     //   14875: sipush #568
/*      */     //   14878: wide iload #574
/*      */     //   14882: invokeinterface setInt : (II)V
/*      */     //   14887: wide aload #577
/*      */     //   14891: sipush #568
/*      */     //   14894: invokeinterface getInt : (I)I
/*      */     //   14899: wide istore #573
/*      */     //   14903: wide aload #579
/*      */     //   14907: sipush #568
/*      */     //   14910: wide iload #573
/*      */     //   14914: invokeinterface setInt : (II)V
/*      */     //   14919: aload_2
/*      */     //   14920: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14923: goto -> 19275
/*      */     //   14926: aload_0
/*      */     //   14927: new org/renjin/gcc/runtime/BytePtr
/*      */     //   14930: dup
/*      */     //   14931: ldc_w 'omd '
/*      */     //   14934: invokevirtual getBytes : ()[B
/*      */     //   14937: iconst_0
/*      */     //   14938: invokespecial <init> : ([BI)V
/*      */     //   14941: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   14944: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   14947: ifeq -> 14953
/*      */     //   14950: goto -> 15551
/*      */     //   14953: aload_1
/*      */     //   14954: bipush #14
/*      */     //   14956: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   14959: astore_1
/*      */     //   14960: aload_0
/*      */     //   14961: aload_1
/*      */     //   14962: iconst_4
/*      */     //   14963: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   14966: aload_1
/*      */     //   14967: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14970: invokeinterface getDouble : ()D
/*      */     //   14975: dconst_0
/*      */     //   14976: dconst_1
/*      */     //   14977: aload_0
/*      */     //   14978: invokestatic BoundsCheck : (DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14981: aload_1
/*      */     //   14982: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14985: bipush #8
/*      */     //   14987: invokeinterface getDouble : (I)D
/*      */     //   14992: dconst_0
/*      */     //   14993: dconst_1
/*      */     //   14994: aload_0
/*      */     //   14995: invokestatic BoundsCheck : (DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   14998: aload_1
/*      */     //   14999: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15002: bipush #16
/*      */     //   15004: invokeinterface getDouble : (I)D
/*      */     //   15009: dconst_0
/*      */     //   15010: dconst_1
/*      */     //   15011: aload_0
/*      */     //   15012: invokestatic BoundsCheck : (DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15015: aload_1
/*      */     //   15016: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15019: bipush #24
/*      */     //   15021: invokeinterface getDouble : (I)D
/*      */     //   15026: dconst_0
/*      */     //   15027: dconst_1
/*      */     //   15028: aload_0
/*      */     //   15029: invokestatic BoundsCheck : (DDDLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15032: aload_2
/*      */     //   15033: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15036: wide astore #548
/*      */     //   15040: aload_2
/*      */     //   15041: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15044: wide astore #546
/*      */     //   15048: aload_1
/*      */     //   15049: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15052: invokeinterface getDouble : ()D
/*      */     //   15057: wide dstore #542
/*      */     //   15061: wide aload #546
/*      */     //   15065: iconst_0
/*      */     //   15066: ldc_w 35660
/*      */     //   15069: iadd
/*      */     //   15070: wide dload #542
/*      */     //   15074: invokeinterface setDouble : (ID)V
/*      */     //   15079: wide aload #546
/*      */     //   15083: iconst_0
/*      */     //   15084: ldc_w 35660
/*      */     //   15087: iadd
/*      */     //   15088: invokeinterface getDouble : (I)D
/*      */     //   15093: wide dstore #540
/*      */     //   15097: wide aload #548
/*      */     //   15101: iconst_0
/*      */     //   15102: ldc_w 35660
/*      */     //   15105: iadd
/*      */     //   15106: wide dload #540
/*      */     //   15110: invokeinterface setDouble : (ID)V
/*      */     //   15115: aload_2
/*      */     //   15116: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15119: wide astore #538
/*      */     //   15123: aload_2
/*      */     //   15124: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15127: wide astore #536
/*      */     //   15131: aload_1
/*      */     //   15132: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15135: bipush #8
/*      */     //   15137: invokeinterface getDouble : (I)D
/*      */     //   15142: wide dstore #532
/*      */     //   15146: wide aload #536
/*      */     //   15150: iconst_0
/*      */     //   15151: ldc_w 35660
/*      */     //   15154: iadd
/*      */     //   15155: bipush #8
/*      */     //   15157: iadd
/*      */     //   15158: wide dload #532
/*      */     //   15162: invokeinterface setDouble : (ID)V
/*      */     //   15167: wide aload #536
/*      */     //   15171: iconst_0
/*      */     //   15172: ldc_w 35660
/*      */     //   15175: iadd
/*      */     //   15176: bipush #8
/*      */     //   15178: iadd
/*      */     //   15179: invokeinterface getDouble : (I)D
/*      */     //   15184: wide dstore #530
/*      */     //   15188: wide aload #538
/*      */     //   15192: iconst_0
/*      */     //   15193: ldc_w 35660
/*      */     //   15196: iadd
/*      */     //   15197: bipush #8
/*      */     //   15199: iadd
/*      */     //   15200: wide dload #530
/*      */     //   15204: invokeinterface setDouble : (ID)V
/*      */     //   15209: aload_2
/*      */     //   15210: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15213: wide astore #528
/*      */     //   15217: aload_2
/*      */     //   15218: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15221: wide astore #526
/*      */     //   15225: aload_1
/*      */     //   15226: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15229: bipush #16
/*      */     //   15231: invokeinterface getDouble : (I)D
/*      */     //   15236: wide dstore #522
/*      */     //   15240: wide aload #526
/*      */     //   15244: iconst_0
/*      */     //   15245: ldc_w 35660
/*      */     //   15248: iadd
/*      */     //   15249: bipush #16
/*      */     //   15251: iadd
/*      */     //   15252: wide dload #522
/*      */     //   15256: invokeinterface setDouble : (ID)V
/*      */     //   15261: wide aload #526
/*      */     //   15265: iconst_0
/*      */     //   15266: ldc_w 35660
/*      */     //   15269: iadd
/*      */     //   15270: bipush #16
/*      */     //   15272: iadd
/*      */     //   15273: invokeinterface getDouble : (I)D
/*      */     //   15278: wide dstore #520
/*      */     //   15282: wide aload #528
/*      */     //   15286: iconst_0
/*      */     //   15287: ldc_w 35660
/*      */     //   15290: iadd
/*      */     //   15291: bipush #16
/*      */     //   15293: iadd
/*      */     //   15294: wide dload #520
/*      */     //   15298: invokeinterface setDouble : (ID)V
/*      */     //   15303: aload_2
/*      */     //   15304: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15307: wide astore #518
/*      */     //   15311: aload_2
/*      */     //   15312: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15315: wide astore #516
/*      */     //   15319: aload_1
/*      */     //   15320: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15323: bipush #24
/*      */     //   15325: invokeinterface getDouble : (I)D
/*      */     //   15330: wide dstore #512
/*      */     //   15334: wide aload #516
/*      */     //   15338: iconst_0
/*      */     //   15339: ldc_w 35660
/*      */     //   15342: iadd
/*      */     //   15343: bipush #24
/*      */     //   15345: iadd
/*      */     //   15346: wide dload #512
/*      */     //   15350: invokeinterface setDouble : (ID)V
/*      */     //   15355: wide aload #516
/*      */     //   15359: iconst_0
/*      */     //   15360: ldc_w 35660
/*      */     //   15363: iadd
/*      */     //   15364: bipush #24
/*      */     //   15366: iadd
/*      */     //   15367: invokeinterface getDouble : (I)D
/*      */     //   15372: wide dstore #510
/*      */     //   15376: wide aload #518
/*      */     //   15380: iconst_0
/*      */     //   15381: ldc_w 35660
/*      */     //   15384: iadd
/*      */     //   15385: bipush #24
/*      */     //   15387: iadd
/*      */     //   15388: wide dload #510
/*      */     //   15392: invokeinterface setDouble : (ID)V
/*      */     //   15397: aload_2
/*      */     //   15398: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15401: wide astore #508
/*      */     //   15405: aload_2
/*      */     //   15406: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15409: wide astore #506
/*      */     //   15413: wide aload #506
/*      */     //   15417: iconst_0
/*      */     //   15418: ldc_w 35692
/*      */     //   15421: iadd
/*      */     //   15422: iconst_1
/*      */     //   15423: invokeinterface setInt : (II)V
/*      */     //   15428: wide aload #506
/*      */     //   15432: iconst_0
/*      */     //   15433: ldc_w 35692
/*      */     //   15436: iadd
/*      */     //   15437: invokeinterface getInt : (I)I
/*      */     //   15442: wide istore #505
/*      */     //   15446: wide aload #508
/*      */     //   15450: iconst_0
/*      */     //   15451: ldc_w 35692
/*      */     //   15454: iadd
/*      */     //   15455: wide iload #505
/*      */     //   15459: invokeinterface setInt : (II)V
/*      */     //   15464: aload_2
/*      */     //   15465: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15468: wide astore #503
/*      */     //   15472: aload_2
/*      */     //   15473: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15476: wide astore #501
/*      */     //   15480: aload_2
/*      */     //   15481: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15484: sipush #572
/*      */     //   15487: invokeinterface getInt : (I)I
/*      */     //   15492: wide istore #498
/*      */     //   15496: wide aload #501
/*      */     //   15500: sipush #568
/*      */     //   15503: wide iload #498
/*      */     //   15507: invokeinterface setInt : (II)V
/*      */     //   15512: wide aload #501
/*      */     //   15516: sipush #568
/*      */     //   15519: invokeinterface getInt : (I)I
/*      */     //   15524: wide istore #497
/*      */     //   15528: wide aload #503
/*      */     //   15532: sipush #568
/*      */     //   15535: wide iload #497
/*      */     //   15539: invokeinterface setInt : (II)V
/*      */     //   15544: aload_2
/*      */     //   15545: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15548: goto -> 19275
/*      */     //   15551: aload_0
/*      */     //   15552: new org/renjin/gcc/runtime/BytePtr
/*      */     //   15555: dup
/*      */     //   15556: ldc_w 'omi '
/*      */     //   15559: invokevirtual getBytes : ()[B
/*      */     //   15562: iconst_0
/*      */     //   15563: invokespecial <init> : ([BI)V
/*      */     //   15566: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   15569: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   15572: ifeq -> 15578
/*      */     //   15575: goto -> 16169
/*      */     //   15578: aload_1
/*      */     //   15579: bipush #14
/*      */     //   15581: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   15584: astore_1
/*      */     //   15585: aload_0
/*      */     //   15586: aload_1
/*      */     //   15587: iconst_4
/*      */     //   15588: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   15591: aload_1
/*      */     //   15592: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15595: invokeinterface getDouble : ()D
/*      */     //   15600: aload_0
/*      */     //   15601: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15604: aload_1
/*      */     //   15605: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15608: bipush #8
/*      */     //   15610: invokeinterface getDouble : (I)D
/*      */     //   15615: aload_0
/*      */     //   15616: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15619: aload_1
/*      */     //   15620: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15623: bipush #16
/*      */     //   15625: invokeinterface getDouble : (I)D
/*      */     //   15630: aload_0
/*      */     //   15631: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15634: aload_1
/*      */     //   15635: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15638: bipush #24
/*      */     //   15640: invokeinterface getDouble : (I)D
/*      */     //   15645: aload_0
/*      */     //   15646: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   15649: aload_2
/*      */     //   15650: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15653: wide astore #472
/*      */     //   15657: aload_2
/*      */     //   15658: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15661: wide astore #470
/*      */     //   15665: aload_1
/*      */     //   15666: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15669: invokeinterface getDouble : ()D
/*      */     //   15674: wide dstore #466
/*      */     //   15678: wide aload #470
/*      */     //   15682: iconst_0
/*      */     //   15683: ldc_w 35628
/*      */     //   15686: iadd
/*      */     //   15687: wide dload #466
/*      */     //   15691: invokeinterface setDouble : (ID)V
/*      */     //   15696: wide aload #470
/*      */     //   15700: iconst_0
/*      */     //   15701: ldc_w 35628
/*      */     //   15704: iadd
/*      */     //   15705: invokeinterface getDouble : (I)D
/*      */     //   15710: wide dstore #464
/*      */     //   15714: wide aload #472
/*      */     //   15718: iconst_0
/*      */     //   15719: ldc_w 35628
/*      */     //   15722: iadd
/*      */     //   15723: wide dload #464
/*      */     //   15727: invokeinterface setDouble : (ID)V
/*      */     //   15732: aload_2
/*      */     //   15733: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15736: wide astore #462
/*      */     //   15740: aload_2
/*      */     //   15741: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15744: wide astore #460
/*      */     //   15748: aload_1
/*      */     //   15749: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15752: bipush #8
/*      */     //   15754: invokeinterface getDouble : (I)D
/*      */     //   15759: wide dstore #456
/*      */     //   15763: wide aload #460
/*      */     //   15767: iconst_0
/*      */     //   15768: ldc_w 35628
/*      */     //   15771: iadd
/*      */     //   15772: bipush #8
/*      */     //   15774: iadd
/*      */     //   15775: wide dload #456
/*      */     //   15779: invokeinterface setDouble : (ID)V
/*      */     //   15784: wide aload #460
/*      */     //   15788: iconst_0
/*      */     //   15789: ldc_w 35628
/*      */     //   15792: iadd
/*      */     //   15793: bipush #8
/*      */     //   15795: iadd
/*      */     //   15796: invokeinterface getDouble : (I)D
/*      */     //   15801: wide dstore #454
/*      */     //   15805: wide aload #462
/*      */     //   15809: iconst_0
/*      */     //   15810: ldc_w 35628
/*      */     //   15813: iadd
/*      */     //   15814: bipush #8
/*      */     //   15816: iadd
/*      */     //   15817: wide dload #454
/*      */     //   15821: invokeinterface setDouble : (ID)V
/*      */     //   15826: aload_2
/*      */     //   15827: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15830: wide astore #452
/*      */     //   15834: aload_2
/*      */     //   15835: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15838: wide astore #450
/*      */     //   15842: aload_1
/*      */     //   15843: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15846: bipush #16
/*      */     //   15848: invokeinterface getDouble : (I)D
/*      */     //   15853: wide dstore #446
/*      */     //   15857: wide aload #450
/*      */     //   15861: iconst_0
/*      */     //   15862: ldc_w 35628
/*      */     //   15865: iadd
/*      */     //   15866: bipush #16
/*      */     //   15868: iadd
/*      */     //   15869: wide dload #446
/*      */     //   15873: invokeinterface setDouble : (ID)V
/*      */     //   15878: wide aload #450
/*      */     //   15882: iconst_0
/*      */     //   15883: ldc_w 35628
/*      */     //   15886: iadd
/*      */     //   15887: bipush #16
/*      */     //   15889: iadd
/*      */     //   15890: invokeinterface getDouble : (I)D
/*      */     //   15895: wide dstore #444
/*      */     //   15899: wide aload #452
/*      */     //   15903: iconst_0
/*      */     //   15904: ldc_w 35628
/*      */     //   15907: iadd
/*      */     //   15908: bipush #16
/*      */     //   15910: iadd
/*      */     //   15911: wide dload #444
/*      */     //   15915: invokeinterface setDouble : (ID)V
/*      */     //   15920: aload_2
/*      */     //   15921: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15924: wide astore #442
/*      */     //   15928: aload_2
/*      */     //   15929: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15932: wide astore #440
/*      */     //   15936: aload_1
/*      */     //   15937: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   15940: bipush #24
/*      */     //   15942: invokeinterface getDouble : (I)D
/*      */     //   15947: wide dstore #436
/*      */     //   15951: wide aload #440
/*      */     //   15955: iconst_0
/*      */     //   15956: ldc_w 35628
/*      */     //   15959: iadd
/*      */     //   15960: bipush #24
/*      */     //   15962: iadd
/*      */     //   15963: wide dload #436
/*      */     //   15967: invokeinterface setDouble : (ID)V
/*      */     //   15972: wide aload #440
/*      */     //   15976: iconst_0
/*      */     //   15977: ldc_w 35628
/*      */     //   15980: iadd
/*      */     //   15981: bipush #24
/*      */     //   15983: iadd
/*      */     //   15984: invokeinterface getDouble : (I)D
/*      */     //   15989: wide dstore #434
/*      */     //   15993: wide aload #442
/*      */     //   15997: iconst_0
/*      */     //   15998: ldc_w 35628
/*      */     //   16001: iadd
/*      */     //   16002: bipush #24
/*      */     //   16004: iadd
/*      */     //   16005: wide dload #434
/*      */     //   16009: invokeinterface setDouble : (ID)V
/*      */     //   16014: aload_2
/*      */     //   16015: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16018: wide astore #432
/*      */     //   16022: aload_2
/*      */     //   16023: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16026: wide astore #430
/*      */     //   16030: wide aload #430
/*      */     //   16034: iconst_0
/*      */     //   16035: ldc_w 35692
/*      */     //   16038: iadd
/*      */     //   16039: bipush #13
/*      */     //   16041: invokeinterface setInt : (II)V
/*      */     //   16046: wide aload #430
/*      */     //   16050: iconst_0
/*      */     //   16051: ldc_w 35692
/*      */     //   16054: iadd
/*      */     //   16055: invokeinterface getInt : (I)I
/*      */     //   16060: wide istore #429
/*      */     //   16064: wide aload #432
/*      */     //   16068: iconst_0
/*      */     //   16069: ldc_w 35692
/*      */     //   16072: iadd
/*      */     //   16073: wide iload #429
/*      */     //   16077: invokeinterface setInt : (II)V
/*      */     //   16082: aload_2
/*      */     //   16083: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16086: wide astore #427
/*      */     //   16090: aload_2
/*      */     //   16091: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16094: wide astore #425
/*      */     //   16098: aload_2
/*      */     //   16099: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16102: sipush #572
/*      */     //   16105: invokeinterface getInt : (I)I
/*      */     //   16110: wide istore #422
/*      */     //   16114: wide aload #425
/*      */     //   16118: sipush #568
/*      */     //   16121: wide iload #422
/*      */     //   16125: invokeinterface setInt : (II)V
/*      */     //   16130: wide aload #425
/*      */     //   16134: sipush #568
/*      */     //   16137: invokeinterface getInt : (I)I
/*      */     //   16142: wide istore #421
/*      */     //   16146: wide aload #427
/*      */     //   16150: sipush #568
/*      */     //   16153: wide iload #421
/*      */     //   16157: invokeinterface setInt : (II)V
/*      */     //   16162: aload_2
/*      */     //   16163: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16166: goto -> 19275
/*      */     //   16169: aload_0
/*      */     //   16170: new org/renjin/gcc/runtime/BytePtr
/*      */     //   16173: dup
/*      */     //   16174: ldc_w 'pin '
/*      */     //   16177: invokevirtual getBytes : ()[B
/*      */     //   16180: iconst_0
/*      */     //   16181: invokespecial <init> : ([BI)V
/*      */     //   16184: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   16187: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   16190: ifeq -> 16196
/*      */     //   16193: goto -> 16556
/*      */     //   16196: aload_1
/*      */     //   16197: bipush #14
/*      */     //   16199: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   16202: astore_1
/*      */     //   16203: aload_0
/*      */     //   16204: aload_1
/*      */     //   16205: iconst_2
/*      */     //   16206: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   16209: aload_1
/*      */     //   16210: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16213: invokeinterface getDouble : ()D
/*      */     //   16218: aload_0
/*      */     //   16219: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16222: aload_1
/*      */     //   16223: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16226: bipush #8
/*      */     //   16228: invokeinterface getDouble : (I)D
/*      */     //   16233: aload_0
/*      */     //   16234: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16237: aload_2
/*      */     //   16238: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16241: wide astore #408
/*      */     //   16245: aload_2
/*      */     //   16246: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16249: wide astore #406
/*      */     //   16253: aload_1
/*      */     //   16254: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16257: invokeinterface getDouble : ()D
/*      */     //   16262: wide dstore #402
/*      */     //   16266: wide aload #406
/*      */     //   16270: iconst_0
/*      */     //   16271: ldc_w 35492
/*      */     //   16274: iadd
/*      */     //   16275: wide dload #402
/*      */     //   16279: invokeinterface setDouble : (ID)V
/*      */     //   16284: wide aload #406
/*      */     //   16288: iconst_0
/*      */     //   16289: ldc_w 35492
/*      */     //   16292: iadd
/*      */     //   16293: invokeinterface getDouble : (I)D
/*      */     //   16298: wide dstore #400
/*      */     //   16302: wide aload #408
/*      */     //   16306: iconst_0
/*      */     //   16307: ldc_w 35492
/*      */     //   16310: iadd
/*      */     //   16311: wide dload #400
/*      */     //   16315: invokeinterface setDouble : (ID)V
/*      */     //   16320: aload_2
/*      */     //   16321: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16324: wide astore #398
/*      */     //   16328: aload_2
/*      */     //   16329: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16332: wide astore #396
/*      */     //   16336: aload_1
/*      */     //   16337: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16340: bipush #8
/*      */     //   16342: invokeinterface getDouble : (I)D
/*      */     //   16347: wide dstore #392
/*      */     //   16351: wide aload #396
/*      */     //   16355: iconst_0
/*      */     //   16356: ldc_w 35492
/*      */     //   16359: iadd
/*      */     //   16360: bipush #8
/*      */     //   16362: iadd
/*      */     //   16363: wide dload #392
/*      */     //   16367: invokeinterface setDouble : (ID)V
/*      */     //   16372: wide aload #396
/*      */     //   16376: iconst_0
/*      */     //   16377: ldc_w 35492
/*      */     //   16380: iadd
/*      */     //   16381: bipush #8
/*      */     //   16383: iadd
/*      */     //   16384: invokeinterface getDouble : (I)D
/*      */     //   16389: wide dstore #390
/*      */     //   16393: wide aload #398
/*      */     //   16397: iconst_0
/*      */     //   16398: ldc_w 35492
/*      */     //   16401: iadd
/*      */     //   16402: bipush #8
/*      */     //   16404: iadd
/*      */     //   16405: wide dload #390
/*      */     //   16409: invokeinterface setDouble : (ID)V
/*      */     //   16414: aload_2
/*      */     //   16415: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16418: wide astore #388
/*      */     //   16422: aload_2
/*      */     //   16423: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16426: wide astore #386
/*      */     //   16430: wide aload #386
/*      */     //   16434: iconst_0
/*      */     //   16435: ldc_w 35508
/*      */     //   16438: iadd
/*      */     //   16439: bipush #13
/*      */     //   16441: invokeinterface setInt : (II)V
/*      */     //   16446: wide aload #386
/*      */     //   16450: iconst_0
/*      */     //   16451: ldc_w 35508
/*      */     //   16454: iadd
/*      */     //   16455: invokeinterface getInt : (I)I
/*      */     //   16460: wide istore #385
/*      */     //   16464: wide aload #388
/*      */     //   16468: iconst_0
/*      */     //   16469: ldc_w 35508
/*      */     //   16472: iadd
/*      */     //   16473: wide iload #385
/*      */     //   16477: invokeinterface setInt : (II)V
/*      */     //   16482: aload_2
/*      */     //   16483: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16486: wide astore #383
/*      */     //   16490: aload_2
/*      */     //   16491: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16494: wide astore #381
/*      */     //   16498: wide aload #381
/*      */     //   16502: iconst_0
/*      */     //   16503: ldc_w 35516
/*      */     //   16506: iadd
/*      */     //   16507: iconst_0
/*      */     //   16508: invokeinterface setInt : (II)V
/*      */     //   16513: wide aload #381
/*      */     //   16517: iconst_0
/*      */     //   16518: ldc_w 35516
/*      */     //   16521: iadd
/*      */     //   16522: invokeinterface getInt : (I)I
/*      */     //   16527: wide istore #380
/*      */     //   16531: wide aload #383
/*      */     //   16535: iconst_0
/*      */     //   16536: ldc_w 35516
/*      */     //   16539: iadd
/*      */     //   16540: wide iload #380
/*      */     //   16544: invokeinterface setInt : (II)V
/*      */     //   16549: aload_2
/*      */     //   16550: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16553: goto -> 19275
/*      */     //   16556: aload_0
/*      */     //   16557: new org/renjin/gcc/runtime/BytePtr
/*      */     //   16560: dup
/*      */     //   16561: ldc_w 'plt '
/*      */     //   16564: invokevirtual getBytes : ()[B
/*      */     //   16567: iconst_0
/*      */     //   16568: invokespecial <init> : ([BI)V
/*      */     //   16571: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   16574: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   16577: ifeq -> 16583
/*      */     //   16580: goto -> 17161
/*      */     //   16583: aload_1
/*      */     //   16584: bipush #14
/*      */     //   16586: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   16589: astore_1
/*      */     //   16590: aload_0
/*      */     //   16591: aload_1
/*      */     //   16592: iconst_4
/*      */     //   16593: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   16596: aload_1
/*      */     //   16597: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16600: invokeinterface getDouble : ()D
/*      */     //   16605: aload_0
/*      */     //   16606: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16609: aload_1
/*      */     //   16610: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16613: bipush #8
/*      */     //   16615: invokeinterface getDouble : (I)D
/*      */     //   16620: aload_0
/*      */     //   16621: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16624: aload_1
/*      */     //   16625: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16628: bipush #16
/*      */     //   16630: invokeinterface getDouble : (I)D
/*      */     //   16635: aload_0
/*      */     //   16636: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16639: aload_1
/*      */     //   16640: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16643: bipush #24
/*      */     //   16645: invokeinterface getDouble : (I)D
/*      */     //   16650: aload_0
/*      */     //   16651: invokestatic nonnegRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   16654: aload_2
/*      */     //   16655: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16658: wide astore #355
/*      */     //   16662: aload_2
/*      */     //   16663: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16666: wide astore #353
/*      */     //   16670: aload_1
/*      */     //   16671: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16674: invokeinterface getDouble : ()D
/*      */     //   16679: wide dstore #349
/*      */     //   16683: wide aload #353
/*      */     //   16687: iconst_0
/*      */     //   16688: ldc_w 35460
/*      */     //   16691: iadd
/*      */     //   16692: wide dload #349
/*      */     //   16696: invokeinterface setDouble : (ID)V
/*      */     //   16701: wide aload #353
/*      */     //   16705: iconst_0
/*      */     //   16706: ldc_w 35460
/*      */     //   16709: iadd
/*      */     //   16710: invokeinterface getDouble : (I)D
/*      */     //   16715: wide dstore #347
/*      */     //   16719: wide aload #355
/*      */     //   16723: iconst_0
/*      */     //   16724: ldc_w 35460
/*      */     //   16727: iadd
/*      */     //   16728: wide dload #347
/*      */     //   16732: invokeinterface setDouble : (ID)V
/*      */     //   16737: aload_2
/*      */     //   16738: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16741: wide astore #345
/*      */     //   16745: aload_2
/*      */     //   16746: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16749: wide astore #343
/*      */     //   16753: aload_1
/*      */     //   16754: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16757: bipush #8
/*      */     //   16759: invokeinterface getDouble : (I)D
/*      */     //   16764: wide dstore #339
/*      */     //   16768: wide aload #343
/*      */     //   16772: iconst_0
/*      */     //   16773: ldc_w 35460
/*      */     //   16776: iadd
/*      */     //   16777: bipush #8
/*      */     //   16779: iadd
/*      */     //   16780: wide dload #339
/*      */     //   16784: invokeinterface setDouble : (ID)V
/*      */     //   16789: wide aload #343
/*      */     //   16793: iconst_0
/*      */     //   16794: ldc_w 35460
/*      */     //   16797: iadd
/*      */     //   16798: bipush #8
/*      */     //   16800: iadd
/*      */     //   16801: invokeinterface getDouble : (I)D
/*      */     //   16806: wide dstore #337
/*      */     //   16810: wide aload #345
/*      */     //   16814: iconst_0
/*      */     //   16815: ldc_w 35460
/*      */     //   16818: iadd
/*      */     //   16819: bipush #8
/*      */     //   16821: iadd
/*      */     //   16822: wide dload #337
/*      */     //   16826: invokeinterface setDouble : (ID)V
/*      */     //   16831: aload_2
/*      */     //   16832: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16835: wide astore #335
/*      */     //   16839: aload_2
/*      */     //   16840: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16843: wide astore #333
/*      */     //   16847: aload_1
/*      */     //   16848: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16851: bipush #16
/*      */     //   16853: invokeinterface getDouble : (I)D
/*      */     //   16858: wide dstore #329
/*      */     //   16862: wide aload #333
/*      */     //   16866: iconst_0
/*      */     //   16867: ldc_w 35460
/*      */     //   16870: iadd
/*      */     //   16871: bipush #16
/*      */     //   16873: iadd
/*      */     //   16874: wide dload #329
/*      */     //   16878: invokeinterface setDouble : (ID)V
/*      */     //   16883: wide aload #333
/*      */     //   16887: iconst_0
/*      */     //   16888: ldc_w 35460
/*      */     //   16891: iadd
/*      */     //   16892: bipush #16
/*      */     //   16894: iadd
/*      */     //   16895: invokeinterface getDouble : (I)D
/*      */     //   16900: wide dstore #327
/*      */     //   16904: wide aload #335
/*      */     //   16908: iconst_0
/*      */     //   16909: ldc_w 35460
/*      */     //   16912: iadd
/*      */     //   16913: bipush #16
/*      */     //   16915: iadd
/*      */     //   16916: wide dload #327
/*      */     //   16920: invokeinterface setDouble : (ID)V
/*      */     //   16925: aload_2
/*      */     //   16926: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16929: wide astore #325
/*      */     //   16933: aload_2
/*      */     //   16934: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16937: wide astore #323
/*      */     //   16941: aload_1
/*      */     //   16942: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   16945: bipush #24
/*      */     //   16947: invokeinterface getDouble : (I)D
/*      */     //   16952: wide dstore #319
/*      */     //   16956: wide aload #323
/*      */     //   16960: iconst_0
/*      */     //   16961: ldc_w 35460
/*      */     //   16964: iadd
/*      */     //   16965: bipush #24
/*      */     //   16967: iadd
/*      */     //   16968: wide dload #319
/*      */     //   16972: invokeinterface setDouble : (ID)V
/*      */     //   16977: wide aload #323
/*      */     //   16981: iconst_0
/*      */     //   16982: ldc_w 35460
/*      */     //   16985: iadd
/*      */     //   16986: bipush #24
/*      */     //   16988: iadd
/*      */     //   16989: invokeinterface getDouble : (I)D
/*      */     //   16994: wide dstore #317
/*      */     //   16998: wide aload #325
/*      */     //   17002: iconst_0
/*      */     //   17003: ldc_w 35460
/*      */     //   17006: iadd
/*      */     //   17007: bipush #24
/*      */     //   17009: iadd
/*      */     //   17010: wide dload #317
/*      */     //   17014: invokeinterface setDouble : (ID)V
/*      */     //   17019: aload_2
/*      */     //   17020: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17023: wide astore #315
/*      */     //   17027: aload_2
/*      */     //   17028: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17031: wide astore #313
/*      */     //   17035: wide aload #313
/*      */     //   17039: iconst_0
/*      */     //   17040: ldc_w 35508
/*      */     //   17043: iadd
/*      */     //   17044: bipush #7
/*      */     //   17046: invokeinterface setInt : (II)V
/*      */     //   17051: wide aload #313
/*      */     //   17055: iconst_0
/*      */     //   17056: ldc_w 35508
/*      */     //   17059: iadd
/*      */     //   17060: invokeinterface getInt : (I)I
/*      */     //   17065: wide istore #312
/*      */     //   17069: wide aload #315
/*      */     //   17073: iconst_0
/*      */     //   17074: ldc_w 35508
/*      */     //   17077: iadd
/*      */     //   17078: wide iload #312
/*      */     //   17082: invokeinterface setInt : (II)V
/*      */     //   17087: aload_2
/*      */     //   17088: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17091: wide astore #310
/*      */     //   17095: aload_2
/*      */     //   17096: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17099: wide astore #308
/*      */     //   17103: wide aload #308
/*      */     //   17107: iconst_0
/*      */     //   17108: ldc_w 35516
/*      */     //   17111: iadd
/*      */     //   17112: iconst_0
/*      */     //   17113: invokeinterface setInt : (II)V
/*      */     //   17118: wide aload #308
/*      */     //   17122: iconst_0
/*      */     //   17123: ldc_w 35516
/*      */     //   17126: iadd
/*      */     //   17127: invokeinterface getInt : (I)I
/*      */     //   17132: wide istore #307
/*      */     //   17136: wide aload #310
/*      */     //   17140: iconst_0
/*      */     //   17141: ldc_w 35516
/*      */     //   17144: iadd
/*      */     //   17145: wide iload #307
/*      */     //   17149: invokeinterface setInt : (II)V
/*      */     //   17154: aload_2
/*      */     //   17155: invokestatic Rf_GReset : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17158: goto -> 19275
/*      */     //   17161: aload_0
/*      */     //   17162: new org/renjin/gcc/runtime/BytePtr
/*      */     //   17165: dup
/*      */     //   17166: ldc_w 'ps '
/*      */     //   17169: invokevirtual getBytes : ()[B
/*      */     //   17172: iconst_0
/*      */     //   17173: invokespecial <init> : ([BI)V
/*      */     //   17176: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   17179: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   17182: ifeq -> 17188
/*      */     //   17185: goto -> 17280
/*      */     //   17188: aload_0
/*      */     //   17189: aload_1
/*      */     //   17190: iconst_1
/*      */     //   17191: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   17194: aload_1
/*      */     //   17195: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   17198: istore #17
/*      */     //   17200: iload #17
/*      */     //   17202: aload_0
/*      */     //   17203: invokestatic nonnegIntCheck : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17206: aload_2
/*      */     //   17207: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17210: wide astore #304
/*      */     //   17214: aload_2
/*      */     //   17215: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17218: wide astore #302
/*      */     //   17222: iload #17
/*      */     //   17224: i2d
/*      */     //   17225: wide dstore #300
/*      */     //   17229: wide aload #302
/*      */     //   17233: sipush #376
/*      */     //   17236: wide dload #300
/*      */     //   17240: invokeinterface setDouble : (ID)V
/*      */     //   17245: wide aload #302
/*      */     //   17249: sipush #376
/*      */     //   17252: invokeinterface getDouble : (I)D
/*      */     //   17257: wide dstore #298
/*      */     //   17261: wide aload #304
/*      */     //   17265: sipush #376
/*      */     //   17268: wide dload #298
/*      */     //   17272: invokeinterface setDouble : (ID)V
/*      */     //   17277: goto -> 19275
/*      */     //   17280: aload_0
/*      */     //   17281: new org/renjin/gcc/runtime/BytePtr
/*      */     //   17284: dup
/*      */     //   17285: ldc_w 'pty '
/*      */     //   17288: invokevirtual getBytes : ()[B
/*      */     //   17291: iconst_0
/*      */     //   17292: invokespecial <init> : ([BI)V
/*      */     //   17295: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   17298: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   17301: ifeq -> 17307
/*      */     //   17304: goto -> 17512
/*      */     //   17307: aload_1
/*      */     //   17308: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   17311: bipush #16
/*      */     //   17313: if_icmpne -> 17329
/*      */     //   17316: goto -> 17319
/*      */     //   17319: aload_1
/*      */     //   17320: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   17323: ifle -> 17329
/*      */     //   17326: goto -> 17333
/*      */     //   17329: aload_0
/*      */     //   17330: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17333: aload_1
/*      */     //   17334: iconst_0
/*      */     //   17335: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   17338: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   17341: invokeinterface getByte : ()B
/*      */     //   17346: istore #16
/*      */     //   17348: iload #16
/*      */     //   17350: bipush #109
/*      */     //   17352: i2b
/*      */     //   17353: if_icmpeq -> 17370
/*      */     //   17356: goto -> 17359
/*      */     //   17359: iload #16
/*      */     //   17361: bipush #115
/*      */     //   17363: i2b
/*      */     //   17364: if_icmpeq -> 17370
/*      */     //   17367: goto -> 17508
/*      */     //   17370: aload_2
/*      */     //   17371: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17374: wide astore #290
/*      */     //   17378: aload_2
/*      */     //   17379: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17382: wide astore #288
/*      */     //   17386: wide aload #288
/*      */     //   17390: iconst_0
/*      */     //   17391: ldc_w 35696
/*      */     //   17394: iadd
/*      */     //   17395: iload #16
/*      */     //   17397: invokeinterface setByte : (IB)V
/*      */     //   17402: wide aload #288
/*      */     //   17406: iconst_0
/*      */     //   17407: ldc_w 35696
/*      */     //   17410: iadd
/*      */     //   17411: invokeinterface getByte : (I)B
/*      */     //   17416: wide istore #287
/*      */     //   17420: wide aload #290
/*      */     //   17424: iconst_0
/*      */     //   17425: ldc_w 35696
/*      */     //   17428: iadd
/*      */     //   17429: wide iload #287
/*      */     //   17433: invokeinterface setByte : (IB)V
/*      */     //   17438: aload_2
/*      */     //   17439: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17442: wide astore #285
/*      */     //   17446: aload_2
/*      */     //   17447: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17450: wide astore #283
/*      */     //   17454: wide aload #283
/*      */     //   17458: iconst_0
/*      */     //   17459: ldc_w 35516
/*      */     //   17462: iadd
/*      */     //   17463: iconst_1
/*      */     //   17464: invokeinterface setInt : (II)V
/*      */     //   17469: wide aload #283
/*      */     //   17473: iconst_0
/*      */     //   17474: ldc_w 35516
/*      */     //   17477: iadd
/*      */     //   17478: invokeinterface getInt : (I)I
/*      */     //   17483: wide istore #282
/*      */     //   17487: wide aload #285
/*      */     //   17491: iconst_0
/*      */     //   17492: ldc_w 35516
/*      */     //   17495: iadd
/*      */     //   17496: wide iload #282
/*      */     //   17500: invokeinterface setInt : (II)V
/*      */     //   17505: goto -> 19275
/*      */     //   17508: aload_0
/*      */     //   17509: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17512: aload_0
/*      */     //   17513: new org/renjin/gcc/runtime/BytePtr
/*      */     //   17516: dup
/*      */     //   17517: ldc_w 'usr '
/*      */     //   17520: invokevirtual getBytes : ()[B
/*      */     //   17523: iconst_0
/*      */     //   17524: invokespecial <init> : ([BI)V
/*      */     //   17527: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   17530: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   17533: ifeq -> 17539
/*      */     //   17536: goto -> 18969
/*      */     //   17539: aload_1
/*      */     //   17540: bipush #14
/*      */     //   17542: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   17545: astore_1
/*      */     //   17546: aload_0
/*      */     //   17547: aload_1
/*      */     //   17548: iconst_4
/*      */     //   17549: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   17552: aload_1
/*      */     //   17553: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17556: invokeinterface getDouble : ()D
/*      */     //   17561: aload_0
/*      */     //   17562: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17565: aload_1
/*      */     //   17566: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17569: bipush #8
/*      */     //   17571: invokeinterface getDouble : (I)D
/*      */     //   17576: aload_0
/*      */     //   17577: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17580: aload_1
/*      */     //   17581: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17584: bipush #16
/*      */     //   17586: invokeinterface getDouble : (I)D
/*      */     //   17591: aload_0
/*      */     //   17592: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17595: aload_1
/*      */     //   17596: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17599: bipush #24
/*      */     //   17601: invokeinterface getDouble : (I)D
/*      */     //   17606: aload_0
/*      */     //   17607: invokestatic naRealCheck : (DLorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17610: aload_1
/*      */     //   17611: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17614: invokeinterface getDouble : ()D
/*      */     //   17619: dstore #255
/*      */     //   17621: aload_1
/*      */     //   17622: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17625: bipush #8
/*      */     //   17627: invokeinterface getDouble : (I)D
/*      */     //   17632: dstore #249
/*      */     //   17634: dload #255
/*      */     //   17636: dload #249
/*      */     //   17638: dcmpl
/*      */     //   17639: ifeq -> 17682
/*      */     //   17642: goto -> 17645
/*      */     //   17645: aload_1
/*      */     //   17646: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17649: bipush #16
/*      */     //   17651: invokeinterface getDouble : (I)D
/*      */     //   17656: dstore #243
/*      */     //   17658: aload_1
/*      */     //   17659: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17662: bipush #24
/*      */     //   17664: invokeinterface getDouble : (I)D
/*      */     //   17669: dstore #237
/*      */     //   17671: dload #243
/*      */     //   17673: dload #237
/*      */     //   17675: dcmpl
/*      */     //   17676: ifeq -> 17682
/*      */     //   17679: goto -> 17686
/*      */     //   17682: aload_0
/*      */     //   17683: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   17686: aload_2
/*      */     //   17687: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17690: sipush #440
/*      */     //   17693: invokeinterface getInt : (I)I
/*      */     //   17698: ifne -> 17704
/*      */     //   17701: goto -> 18009
/*      */     //   17704: aload_2
/*      */     //   17705: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17708: astore #232
/*      */     //   17710: aload_2
/*      */     //   17711: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17714: astore #230
/*      */     //   17716: aload_1
/*      */     //   17717: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17720: invokeinterface getDouble : ()D
/*      */     //   17725: dstore #226
/*      */     //   17727: aload #230
/*      */     //   17729: iconst_0
/*      */     //   17730: ldc_w 35732
/*      */     //   17733: iadd
/*      */     //   17734: dload #226
/*      */     //   17736: invokeinterface setDouble : (ID)V
/*      */     //   17741: aload #230
/*      */     //   17743: iconst_0
/*      */     //   17744: ldc_w 35732
/*      */     //   17747: iadd
/*      */     //   17748: invokeinterface getDouble : (I)D
/*      */     //   17753: dstore #224
/*      */     //   17755: aload #232
/*      */     //   17757: iconst_0
/*      */     //   17758: ldc_w 35732
/*      */     //   17761: iadd
/*      */     //   17762: dload #224
/*      */     //   17764: invokeinterface setDouble : (ID)V
/*      */     //   17769: aload_2
/*      */     //   17770: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17773: astore #222
/*      */     //   17775: aload_2
/*      */     //   17776: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17779: astore #220
/*      */     //   17781: aload_1
/*      */     //   17782: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17785: bipush #8
/*      */     //   17787: invokeinterface getDouble : (I)D
/*      */     //   17792: dstore #216
/*      */     //   17794: aload #220
/*      */     //   17796: iconst_0
/*      */     //   17797: ldc_w 35732
/*      */     //   17800: iadd
/*      */     //   17801: bipush #8
/*      */     //   17803: iadd
/*      */     //   17804: dload #216
/*      */     //   17806: invokeinterface setDouble : (ID)V
/*      */     //   17811: aload #220
/*      */     //   17813: iconst_0
/*      */     //   17814: ldc_w 35732
/*      */     //   17817: iadd
/*      */     //   17818: bipush #8
/*      */     //   17820: iadd
/*      */     //   17821: invokeinterface getDouble : (I)D
/*      */     //   17826: dstore #214
/*      */     //   17828: aload #222
/*      */     //   17830: iconst_0
/*      */     //   17831: ldc_w 35732
/*      */     //   17834: iadd
/*      */     //   17835: bipush #8
/*      */     //   17837: iadd
/*      */     //   17838: dload #214
/*      */     //   17840: invokeinterface setDouble : (ID)V
/*      */     //   17845: aload_2
/*      */     //   17846: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17849: astore #212
/*      */     //   17851: aload_2
/*      */     //   17852: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17855: astore #210
/*      */     //   17857: aload_1
/*      */     //   17858: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17861: invokeinterface getDouble : ()D
/*      */     //   17866: dstore #206
/*      */     //   17868: ldc2_w 10.0
/*      */     //   17871: dload #206
/*      */     //   17873: invokestatic pow : (DD)D
/*      */     //   17876: dstore #204
/*      */     //   17878: aload #210
/*      */     //   17880: iconst_0
/*      */     //   17881: ldc_w 35700
/*      */     //   17884: iadd
/*      */     //   17885: dload #204
/*      */     //   17887: invokeinterface setDouble : (ID)V
/*      */     //   17892: aload #210
/*      */     //   17894: iconst_0
/*      */     //   17895: ldc_w 35700
/*      */     //   17898: iadd
/*      */     //   17899: invokeinterface getDouble : (I)D
/*      */     //   17904: dstore #202
/*      */     //   17906: aload #212
/*      */     //   17908: iconst_0
/*      */     //   17909: ldc_w 35700
/*      */     //   17912: iadd
/*      */     //   17913: dload #202
/*      */     //   17915: invokeinterface setDouble : (ID)V
/*      */     //   17920: aload_2
/*      */     //   17921: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17924: astore #200
/*      */     //   17926: aload_2
/*      */     //   17927: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17930: astore #198
/*      */     //   17932: aload_1
/*      */     //   17933: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   17936: bipush #8
/*      */     //   17938: invokeinterface getDouble : (I)D
/*      */     //   17943: dstore #192
/*      */     //   17945: ldc2_w 10.0
/*      */     //   17948: dload #192
/*      */     //   17950: invokestatic pow : (DD)D
/*      */     //   17953: dstore #190
/*      */     //   17955: aload #198
/*      */     //   17957: iconst_0
/*      */     //   17958: ldc_w 35700
/*      */     //   17961: iadd
/*      */     //   17962: bipush #8
/*      */     //   17964: iadd
/*      */     //   17965: dload #190
/*      */     //   17967: invokeinterface setDouble : (ID)V
/*      */     //   17972: aload #198
/*      */     //   17974: iconst_0
/*      */     //   17975: ldc_w 35700
/*      */     //   17978: iadd
/*      */     //   17979: bipush #8
/*      */     //   17981: iadd
/*      */     //   17982: invokeinterface getDouble : (I)D
/*      */     //   17987: dstore #188
/*      */     //   17989: aload #200
/*      */     //   17991: iconst_0
/*      */     //   17992: ldc_w 35700
/*      */     //   17995: iadd
/*      */     //   17996: bipush #8
/*      */     //   17998: iadd
/*      */     //   17999: dload #188
/*      */     //   18001: invokeinterface setDouble : (ID)V
/*      */     //   18006: goto -> 18297
/*      */     //   18009: aload_2
/*      */     //   18010: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18013: astore #186
/*      */     //   18015: aload_2
/*      */     //   18016: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18019: astore #184
/*      */     //   18021: aload_1
/*      */     //   18022: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18025: invokeinterface getDouble : ()D
/*      */     //   18030: dstore #180
/*      */     //   18032: aload #184
/*      */     //   18034: iconst_0
/*      */     //   18035: ldc_w 35700
/*      */     //   18038: iadd
/*      */     //   18039: dload #180
/*      */     //   18041: invokeinterface setDouble : (ID)V
/*      */     //   18046: aload #184
/*      */     //   18048: iconst_0
/*      */     //   18049: ldc_w 35700
/*      */     //   18052: iadd
/*      */     //   18053: invokeinterface getDouble : (I)D
/*      */     //   18058: dstore #178
/*      */     //   18060: aload #186
/*      */     //   18062: iconst_0
/*      */     //   18063: ldc_w 35700
/*      */     //   18066: iadd
/*      */     //   18067: dload #178
/*      */     //   18069: invokeinterface setDouble : (ID)V
/*      */     //   18074: aload_2
/*      */     //   18075: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18078: astore #176
/*      */     //   18080: aload_2
/*      */     //   18081: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18084: astore #174
/*      */     //   18086: aload_1
/*      */     //   18087: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18090: bipush #8
/*      */     //   18092: invokeinterface getDouble : (I)D
/*      */     //   18097: dstore #170
/*      */     //   18099: aload #174
/*      */     //   18101: iconst_0
/*      */     //   18102: ldc_w 35700
/*      */     //   18105: iadd
/*      */     //   18106: bipush #8
/*      */     //   18108: iadd
/*      */     //   18109: dload #170
/*      */     //   18111: invokeinterface setDouble : (ID)V
/*      */     //   18116: aload #174
/*      */     //   18118: iconst_0
/*      */     //   18119: ldc_w 35700
/*      */     //   18122: iadd
/*      */     //   18123: bipush #8
/*      */     //   18125: iadd
/*      */     //   18126: invokeinterface getDouble : (I)D
/*      */     //   18131: dstore #168
/*      */     //   18133: aload #176
/*      */     //   18135: iconst_0
/*      */     //   18136: ldc_w 35700
/*      */     //   18139: iadd
/*      */     //   18140: bipush #8
/*      */     //   18142: iadd
/*      */     //   18143: dload #168
/*      */     //   18145: invokeinterface setDouble : (ID)V
/*      */     //   18150: aload_2
/*      */     //   18151: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18154: astore #166
/*      */     //   18156: aload_2
/*      */     //   18157: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18160: astore #164
/*      */     //   18162: aload_1
/*      */     //   18163: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18166: invokeinterface getDouble : ()D
/*      */     //   18171: invokestatic R_Log10 : (D)D
/*      */     //   18174: dstore #158
/*      */     //   18176: aload #164
/*      */     //   18178: iconst_0
/*      */     //   18179: ldc_w 35732
/*      */     //   18182: iadd
/*      */     //   18183: dload #158
/*      */     //   18185: invokeinterface setDouble : (ID)V
/*      */     //   18190: aload #164
/*      */     //   18192: iconst_0
/*      */     //   18193: ldc_w 35732
/*      */     //   18196: iadd
/*      */     //   18197: invokeinterface getDouble : (I)D
/*      */     //   18202: dstore #156
/*      */     //   18204: aload #166
/*      */     //   18206: iconst_0
/*      */     //   18207: ldc_w 35732
/*      */     //   18210: iadd
/*      */     //   18211: dload #156
/*      */     //   18213: invokeinterface setDouble : (ID)V
/*      */     //   18218: aload_2
/*      */     //   18219: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18222: astore #154
/*      */     //   18224: aload_2
/*      */     //   18225: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18228: astore #152
/*      */     //   18230: aload_1
/*      */     //   18231: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18234: bipush #8
/*      */     //   18236: invokeinterface getDouble : (I)D
/*      */     //   18241: invokestatic R_Log10 : (D)D
/*      */     //   18244: dstore #144
/*      */     //   18246: aload #152
/*      */     //   18248: iconst_0
/*      */     //   18249: ldc_w 35732
/*      */     //   18252: iadd
/*      */     //   18253: bipush #8
/*      */     //   18255: iadd
/*      */     //   18256: dload #144
/*      */     //   18258: invokeinterface setDouble : (ID)V
/*      */     //   18263: aload #152
/*      */     //   18265: iconst_0
/*      */     //   18266: ldc_w 35732
/*      */     //   18269: iadd
/*      */     //   18270: bipush #8
/*      */     //   18272: iadd
/*      */     //   18273: invokeinterface getDouble : (I)D
/*      */     //   18278: dstore #142
/*      */     //   18280: aload #154
/*      */     //   18282: iconst_0
/*      */     //   18283: ldc_w 35732
/*      */     //   18286: iadd
/*      */     //   18287: bipush #8
/*      */     //   18289: iadd
/*      */     //   18290: dload #142
/*      */     //   18292: invokeinterface setDouble : (ID)V
/*      */     //   18297: aload_2
/*      */     //   18298: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18301: sipush #480
/*      */     //   18304: invokeinterface getInt : (I)I
/*      */     //   18309: ifne -> 18315
/*      */     //   18312: goto -> 18642
/*      */     //   18315: aload_2
/*      */     //   18316: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18319: astore #137
/*      */     //   18321: aload_2
/*      */     //   18322: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18325: astore #135
/*      */     //   18327: aload_1
/*      */     //   18328: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18331: bipush #16
/*      */     //   18333: invokeinterface getDouble : (I)D
/*      */     //   18338: dstore #131
/*      */     //   18340: aload #135
/*      */     //   18342: iconst_0
/*      */     //   18343: ldc_w 35732
/*      */     //   18346: iadd
/*      */     //   18347: bipush #16
/*      */     //   18349: iadd
/*      */     //   18350: dload #131
/*      */     //   18352: invokeinterface setDouble : (ID)V
/*      */     //   18357: aload #135
/*      */     //   18359: iconst_0
/*      */     //   18360: ldc_w 35732
/*      */     //   18363: iadd
/*      */     //   18364: bipush #16
/*      */     //   18366: iadd
/*      */     //   18367: invokeinterface getDouble : (I)D
/*      */     //   18372: dstore #129
/*      */     //   18374: aload #137
/*      */     //   18376: iconst_0
/*      */     //   18377: ldc_w 35732
/*      */     //   18380: iadd
/*      */     //   18381: bipush #16
/*      */     //   18383: iadd
/*      */     //   18384: dload #129
/*      */     //   18386: invokeinterface setDouble : (ID)V
/*      */     //   18391: aload_2
/*      */     //   18392: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18395: astore #127
/*      */     //   18397: aload_2
/*      */     //   18398: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18401: astore #125
/*      */     //   18403: aload_1
/*      */     //   18404: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18407: bipush #24
/*      */     //   18409: invokeinterface getDouble : (I)D
/*      */     //   18414: dstore #121
/*      */     //   18416: aload #125
/*      */     //   18418: iconst_0
/*      */     //   18419: ldc_w 35732
/*      */     //   18422: iadd
/*      */     //   18423: bipush #24
/*      */     //   18425: iadd
/*      */     //   18426: dload #121
/*      */     //   18428: invokeinterface setDouble : (ID)V
/*      */     //   18433: aload #125
/*      */     //   18435: iconst_0
/*      */     //   18436: ldc_w 35732
/*      */     //   18439: iadd
/*      */     //   18440: bipush #24
/*      */     //   18442: iadd
/*      */     //   18443: invokeinterface getDouble : (I)D
/*      */     //   18448: dstore #119
/*      */     //   18450: aload #127
/*      */     //   18452: iconst_0
/*      */     //   18453: ldc_w 35732
/*      */     //   18456: iadd
/*      */     //   18457: bipush #24
/*      */     //   18459: iadd
/*      */     //   18460: dload #119
/*      */     //   18462: invokeinterface setDouble : (ID)V
/*      */     //   18467: aload_2
/*      */     //   18468: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18471: astore #117
/*      */     //   18473: aload_2
/*      */     //   18474: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18477: astore #115
/*      */     //   18479: aload_1
/*      */     //   18480: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18483: bipush #16
/*      */     //   18485: invokeinterface getDouble : (I)D
/*      */     //   18490: dstore #109
/*      */     //   18492: ldc2_w 10.0
/*      */     //   18495: dload #109
/*      */     //   18497: invokestatic pow : (DD)D
/*      */     //   18500: dstore #107
/*      */     //   18502: aload #115
/*      */     //   18504: iconst_0
/*      */     //   18505: ldc_w 35700
/*      */     //   18508: iadd
/*      */     //   18509: bipush #16
/*      */     //   18511: iadd
/*      */     //   18512: dload #107
/*      */     //   18514: invokeinterface setDouble : (ID)V
/*      */     //   18519: aload #115
/*      */     //   18521: iconst_0
/*      */     //   18522: ldc_w 35700
/*      */     //   18525: iadd
/*      */     //   18526: bipush #16
/*      */     //   18528: iadd
/*      */     //   18529: invokeinterface getDouble : (I)D
/*      */     //   18534: dstore #105
/*      */     //   18536: aload #117
/*      */     //   18538: iconst_0
/*      */     //   18539: ldc_w 35700
/*      */     //   18542: iadd
/*      */     //   18543: bipush #16
/*      */     //   18545: iadd
/*      */     //   18546: dload #105
/*      */     //   18548: invokeinterface setDouble : (ID)V
/*      */     //   18553: aload_2
/*      */     //   18554: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18557: astore #103
/*      */     //   18559: aload_2
/*      */     //   18560: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18563: astore #101
/*      */     //   18565: aload_1
/*      */     //   18566: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18569: bipush #24
/*      */     //   18571: invokeinterface getDouble : (I)D
/*      */     //   18576: dstore #95
/*      */     //   18578: ldc2_w 10.0
/*      */     //   18581: dload #95
/*      */     //   18583: invokestatic pow : (DD)D
/*      */     //   18586: dstore #93
/*      */     //   18588: aload #101
/*      */     //   18590: iconst_0
/*      */     //   18591: ldc_w 35700
/*      */     //   18594: iadd
/*      */     //   18595: bipush #24
/*      */     //   18597: iadd
/*      */     //   18598: dload #93
/*      */     //   18600: invokeinterface setDouble : (ID)V
/*      */     //   18605: aload #101
/*      */     //   18607: iconst_0
/*      */     //   18608: ldc_w 35700
/*      */     //   18611: iadd
/*      */     //   18612: bipush #24
/*      */     //   18614: iadd
/*      */     //   18615: invokeinterface getDouble : (I)D
/*      */     //   18620: dstore #91
/*      */     //   18622: aload #103
/*      */     //   18624: iconst_0
/*      */     //   18625: ldc_w 35700
/*      */     //   18628: iadd
/*      */     //   18629: bipush #24
/*      */     //   18631: iadd
/*      */     //   18632: dload #91
/*      */     //   18634: invokeinterface setDouble : (ID)V
/*      */     //   18639: goto -> 18952
/*      */     //   18642: aload_2
/*      */     //   18643: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18646: astore #89
/*      */     //   18648: aload_2
/*      */     //   18649: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18652: astore #87
/*      */     //   18654: aload_1
/*      */     //   18655: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18658: bipush #16
/*      */     //   18660: invokeinterface getDouble : (I)D
/*      */     //   18665: dstore #83
/*      */     //   18667: aload #87
/*      */     //   18669: iconst_0
/*      */     //   18670: ldc_w 35700
/*      */     //   18673: iadd
/*      */     //   18674: bipush #16
/*      */     //   18676: iadd
/*      */     //   18677: dload #83
/*      */     //   18679: invokeinterface setDouble : (ID)V
/*      */     //   18684: aload #87
/*      */     //   18686: iconst_0
/*      */     //   18687: ldc_w 35700
/*      */     //   18690: iadd
/*      */     //   18691: bipush #16
/*      */     //   18693: iadd
/*      */     //   18694: invokeinterface getDouble : (I)D
/*      */     //   18699: dstore #81
/*      */     //   18701: aload #89
/*      */     //   18703: iconst_0
/*      */     //   18704: ldc_w 35700
/*      */     //   18707: iadd
/*      */     //   18708: bipush #16
/*      */     //   18710: iadd
/*      */     //   18711: dload #81
/*      */     //   18713: invokeinterface setDouble : (ID)V
/*      */     //   18718: aload_2
/*      */     //   18719: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18722: astore #79
/*      */     //   18724: aload_2
/*      */     //   18725: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18728: astore #77
/*      */     //   18730: aload_1
/*      */     //   18731: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18734: bipush #24
/*      */     //   18736: invokeinterface getDouble : (I)D
/*      */     //   18741: dstore #73
/*      */     //   18743: aload #77
/*      */     //   18745: iconst_0
/*      */     //   18746: ldc_w 35700
/*      */     //   18749: iadd
/*      */     //   18750: bipush #24
/*      */     //   18752: iadd
/*      */     //   18753: dload #73
/*      */     //   18755: invokeinterface setDouble : (ID)V
/*      */     //   18760: aload #77
/*      */     //   18762: iconst_0
/*      */     //   18763: ldc_w 35700
/*      */     //   18766: iadd
/*      */     //   18767: bipush #24
/*      */     //   18769: iadd
/*      */     //   18770: invokeinterface getDouble : (I)D
/*      */     //   18775: dstore #71
/*      */     //   18777: aload #79
/*      */     //   18779: iconst_0
/*      */     //   18780: ldc_w 35700
/*      */     //   18783: iadd
/*      */     //   18784: bipush #24
/*      */     //   18786: iadd
/*      */     //   18787: dload #71
/*      */     //   18789: invokeinterface setDouble : (ID)V
/*      */     //   18794: aload_2
/*      */     //   18795: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18798: astore #69
/*      */     //   18800: aload_2
/*      */     //   18801: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18804: astore #67
/*      */     //   18806: aload_1
/*      */     //   18807: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18810: bipush #16
/*      */     //   18812: invokeinterface getDouble : (I)D
/*      */     //   18817: invokestatic R_Log10 : (D)D
/*      */     //   18820: dstore #59
/*      */     //   18822: aload #67
/*      */     //   18824: iconst_0
/*      */     //   18825: ldc_w 35732
/*      */     //   18828: iadd
/*      */     //   18829: bipush #16
/*      */     //   18831: iadd
/*      */     //   18832: dload #59
/*      */     //   18834: invokeinterface setDouble : (ID)V
/*      */     //   18839: aload #67
/*      */     //   18841: iconst_0
/*      */     //   18842: ldc_w 35732
/*      */     //   18845: iadd
/*      */     //   18846: bipush #16
/*      */     //   18848: iadd
/*      */     //   18849: invokeinterface getDouble : (I)D
/*      */     //   18854: dstore #57
/*      */     //   18856: aload #69
/*      */     //   18858: iconst_0
/*      */     //   18859: ldc_w 35732
/*      */     //   18862: iadd
/*      */     //   18863: bipush #16
/*      */     //   18865: iadd
/*      */     //   18866: dload #57
/*      */     //   18868: invokeinterface setDouble : (ID)V
/*      */     //   18873: aload_2
/*      */     //   18874: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18877: astore #55
/*      */     //   18879: aload_2
/*      */     //   18880: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18883: astore #53
/*      */     //   18885: aload_1
/*      */     //   18886: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   18889: bipush #24
/*      */     //   18891: invokeinterface getDouble : (I)D
/*      */     //   18896: invokestatic R_Log10 : (D)D
/*      */     //   18899: dstore #45
/*      */     //   18901: aload #53
/*      */     //   18903: iconst_0
/*      */     //   18904: ldc_w 35732
/*      */     //   18907: iadd
/*      */     //   18908: bipush #24
/*      */     //   18910: iadd
/*      */     //   18911: dload #45
/*      */     //   18913: invokeinterface setDouble : (ID)V
/*      */     //   18918: aload #53
/*      */     //   18920: iconst_0
/*      */     //   18921: ldc_w 35732
/*      */     //   18924: iadd
/*      */     //   18925: bipush #24
/*      */     //   18927: iadd
/*      */     //   18928: invokeinterface getDouble : (I)D
/*      */     //   18933: dstore #43
/*      */     //   18935: aload #55
/*      */     //   18937: iconst_0
/*      */     //   18938: ldc_w 35732
/*      */     //   18941: iadd
/*      */     //   18942: bipush #24
/*      */     //   18944: iadd
/*      */     //   18945: dload #43
/*      */     //   18947: invokeinterface setDouble : (ID)V
/*      */     //   18952: aload_2
/*      */     //   18953: invokestatic Rf_GMapWin2Fig : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   18956: iconst_1
/*      */     //   18957: aload_2
/*      */     //   18958: invokestatic Rf_GSetupAxis : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   18961: iconst_2
/*      */     //   18962: aload_2
/*      */     //   18963: invokestatic Rf_GSetupAxis : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   18966: goto -> 19275
/*      */     //   18969: aload_0
/*      */     //   18970: new org/renjin/gcc/runtime/BytePtr
/*      */     //   18973: dup
/*      */     //   18974: ldc_w 'xlog '
/*      */     //   18977: invokevirtual getBytes : ()[B
/*      */     //   18980: iconst_0
/*      */     //   18981: invokespecial <init> : ([BI)V
/*      */     //   18984: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   18987: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   18990: ifeq -> 18996
/*      */     //   18993: goto -> 19093
/*      */     //   18996: aload_0
/*      */     //   18997: aload_1
/*      */     //   18998: iconst_1
/*      */     //   18999: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   19002: aload_1
/*      */     //   19003: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   19006: istore #17
/*      */     //   19008: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   19011: istore #41
/*      */     //   19013: iload #17
/*      */     //   19015: iload #41
/*      */     //   19017: if_icmpeq -> 19023
/*      */     //   19020: goto -> 19027
/*      */     //   19023: aload_0
/*      */     //   19024: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   19027: aload_2
/*      */     //   19028: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   19031: astore #39
/*      */     //   19033: aload_2
/*      */     //   19034: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   19037: astore #37
/*      */     //   19039: iload #17
/*      */     //   19041: ifne -> 19051
/*      */     //   19044: goto -> 19047
/*      */     //   19047: iconst_0
/*      */     //   19048: goto -> 19052
/*      */     //   19051: iconst_1
/*      */     //   19052: istore #35
/*      */     //   19054: aload #37
/*      */     //   19056: sipush #440
/*      */     //   19059: iload #35
/*      */     //   19061: invokeinterface setInt : (II)V
/*      */     //   19066: aload #37
/*      */     //   19068: sipush #440
/*      */     //   19071: invokeinterface getInt : (I)I
/*      */     //   19076: istore #34
/*      */     //   19078: aload #39
/*      */     //   19080: sipush #440
/*      */     //   19083: iload #34
/*      */     //   19085: invokeinterface setInt : (II)V
/*      */     //   19090: goto -> 19275
/*      */     //   19093: aload_0
/*      */     //   19094: new org/renjin/gcc/runtime/BytePtr
/*      */     //   19097: dup
/*      */     //   19098: ldc_w 'ylog '
/*      */     //   19101: invokevirtual getBytes : ()[B
/*      */     //   19104: iconst_0
/*      */     //   19105: invokespecial <init> : ([BI)V
/*      */     //   19108: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   19111: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   19114: ifeq -> 19120
/*      */     //   19117: goto -> 19217
/*      */     //   19120: aload_0
/*      */     //   19121: aload_1
/*      */     //   19122: iconst_1
/*      */     //   19123: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   19126: aload_1
/*      */     //   19127: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   19130: istore #17
/*      */     //   19132: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   19135: istore #32
/*      */     //   19137: iload #17
/*      */     //   19139: iload #32
/*      */     //   19141: if_icmpeq -> 19147
/*      */     //   19144: goto -> 19151
/*      */     //   19147: aload_0
/*      */     //   19148: invokestatic par_error : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   19151: aload_2
/*      */     //   19152: invokestatic Rf_dpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   19155: astore #30
/*      */     //   19157: aload_2
/*      */     //   19158: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   19161: astore #28
/*      */     //   19163: iload #17
/*      */     //   19165: ifne -> 19175
/*      */     //   19168: goto -> 19171
/*      */     //   19171: iconst_0
/*      */     //   19172: goto -> 19176
/*      */     //   19175: iconst_1
/*      */     //   19176: istore #26
/*      */     //   19178: aload #28
/*      */     //   19180: sipush #480
/*      */     //   19183: iload #26
/*      */     //   19185: invokeinterface setInt : (II)V
/*      */     //   19190: aload #28
/*      */     //   19192: sipush #480
/*      */     //   19195: invokeinterface getInt : (I)I
/*      */     //   19200: istore #25
/*      */     //   19202: aload #30
/*      */     //   19204: sipush #480
/*      */     //   19207: iload #25
/*      */     //   19209: invokeinterface setInt : (II)V
/*      */     //   19214: goto -> 19275
/*      */     //   19217: aload_0
/*      */     //   19218: new org/renjin/gcc/runtime/BytePtr
/*      */     //   19221: dup
/*      */     //   19222: ldc_w 'ylbias '
/*      */     //   19225: invokevirtual getBytes : ()[B
/*      */     //   19228: iconst_0
/*      */     //   19229: invokespecial <init> : ([BI)V
/*      */     //   19232: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   19235: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   19238: ifeq -> 19244
/*      */     //   19241: goto -> 19275
/*      */     //   19244: aload_0
/*      */     //   19245: aload_1
/*      */     //   19246: iconst_1
/*      */     //   19247: invokestatic lengthCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/sexp/SEXP;I)V
/*      */     //   19250: aload_2
/*      */     //   19251: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   19256: astore #22
/*      */     //   19258: aload_1
/*      */     //   19259: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   19262: dstore #20
/*      */     //   19264: aload #22
/*      */     //   19266: bipush #80
/*      */     //   19268: dload #20
/*      */     //   19270: invokeinterface setDouble : (ID)V
/*      */     //   19275: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #256	-> 0
/*      */     //   #257	-> 3
/*      */     //   #261	-> 7
/*      */     //   #262	-> 18
/*      */     //   #25	-> 65
/*      */     //   #26	-> 92
/*      */     //   #27	-> 104
/*      */     //   #28	-> 112
/*      */     //   #30	-> 174
/*      */     //   #31	-> 201
/*      */     //   #32	-> 213
/*      */     //   #34	-> 294
/*      */     //   #37	-> 321
/*      */     //   #41	-> 327
/*      */     //   #43	-> 416
/*      */     //   #46	-> 486
/*      */     //   #47	-> 513
/*      */     //   #48	-> 519
/*      */     //   #49	-> 531
/*      */     //   #50	-> 535
/*      */     //   #51	-> 550
/*      */     //   #59	-> 660
/*      */     //   #62	-> 722
/*      */     //   #66	-> 729
/*      */     //   #68	-> 756
/*      */     //   #72	-> 762
/*      */     //   #73	-> 768
/*      */     //   #75	-> 774
/*      */     //   #76	-> 832
/*      */     //   #81	-> 897
/*      */     //   #82	-> 924
/*      */     //   #83	-> 936
/*      */     //   #84	-> 942
/*      */     //   #86	-> 1007
/*      */     //   #87	-> 1034
/*      */     //   #88	-> 1046
/*      */     //   #89	-> 1052
/*      */     //   #91	-> 1117
/*      */     //   #92	-> 1144
/*      */     //   #93	-> 1156
/*      */     //   #94	-> 1162
/*      */     //   #96	-> 1227
/*      */     //   #97	-> 1254
/*      */     //   #98	-> 1266
/*      */     //   #99	-> 1272
/*      */     //   #101	-> 1337
/*      */     //   #103	-> 1364
/*      */     //   #107	-> 1370
/*      */     //   #109	-> 1462
/*      */     //   #110	-> 1489
/*      */     //   #111	-> 1495
/*      */     //   #113	-> 1590
/*      */     //   #114	-> 1617
/*      */     //   #115	-> 1623
/*      */     //   #117	-> 1718
/*      */     //   #118	-> 1745
/*      */     //   #119	-> 1751
/*      */     //   #121	-> 1846
/*      */     //   #122	-> 1873
/*      */     //   #123	-> 1879
/*      */     //   #125	-> 1974
/*      */     //   #126	-> 2001
/*      */     //   #127	-> 2013
/*      */     //   #128	-> 2019
/*      */     //   #130	-> 2081
/*      */     //   #131	-> 2108
/*      */     //   #132	-> 2120
/*      */     //   #132	-> 2128
/*      */     //   #133	-> 2137
/*      */     //   #134	-> 2199
/*      */     //   #136	-> 2203
/*      */     //   #138	-> 2230
/*      */     //   #139	-> 2237
/*      */     //   #140	-> 2267
/*      */     //   #142	-> 2283
/*      */     //   #143	-> 2289
/*      */     //   #144	-> 2297
/*      */     //   #145	-> 2307
/*      */     //   #146	-> 2324
/*      */     //   #148	-> 2364
/*      */     //   #150	-> 2384
/*      */     //   #151	-> 2404
/*      */     //   #153	-> 2407
/*      */     //   #154	-> 2434
/*      */     //   #155	-> 2440
/*      */     //   #158	-> 2466
/*      */     //   #160	-> 2533
/*      */     //   #162	-> 2603
/*      */     //   #163	-> 2630
/*      */     //   #164	-> 2642
/*      */     //   #165	-> 2648
/*      */     //   #167	-> 2713
/*      */     //   #168	-> 2740
/*      */     //   #169	-> 2752
/*      */     //   #170	-> 2758
/*      */     //   #172	-> 2823
/*      */     //   #173	-> 2850
/*      */     //   #174	-> 2862
/*      */     //   #175	-> 2868
/*      */     //   #177	-> 2933
/*      */     //   #178	-> 2960
/*      */     //   #179	-> 2972
/*      */     //   #180	-> 2978
/*      */     //   #182	-> 3043
/*      */     //   #183	-> 3070
/*      */     //   #184	-> 3082
/*      */     //   #185	-> 3088
/*      */     //   #187	-> 3153
/*      */     //   #188	-> 3180
/*      */     //   #189	-> 3187
/*      */     //   #190	-> 3193
/*      */     //   #191	-> 3206
/*      */     //   #192	-> 3220
/*      */     //   #193	-> 3235
/*      */     //   #194	-> 3312
/*      */     //   #195	-> 3390
/*      */     //   #197	-> 3472
/*      */     //   #198	-> 3499
/*      */     //   #199	-> 3511
/*      */     //   #199	-> 3519
/*      */     //   #200	-> 3528
/*      */     //   #201	-> 3593
/*      */     //   #203	-> 3597
/*      */     //   #204	-> 3624
/*      */     //   #205	-> 3630
/*      */     //   #207	-> 3706
/*      */     //   #208	-> 3733
/*      */     //   #209	-> 3739
/*      */     //   #211	-> 3815
/*      */     //   #212	-> 3842
/*      */     //   #213	-> 3848
/*      */     //   #214	-> 3854
/*      */     //   #215	-> 3860
/*      */     //   #216	-> 3870
/*      */     //   #217	-> 3874
/*      */     //   #219	-> 3939
/*      */     //   #221	-> 3966
/*      */     //   #225	-> 3972
/*      */     //   #227	-> 4048
/*      */     //   #229	-> 4075
/*      */     //   #233	-> 4081
/*      */     //   #234	-> 4087
/*      */     //   #235	-> 4093
/*      */     //   #237	-> 4158
/*      */     //   #238	-> 4185
/*      */     //   #239	-> 4197
/*      */     //   #241	-> 4203
/*      */     //   #242	-> 4216
/*      */     //   #243	-> 4231
/*      */     //   #244	-> 4246
/*      */     //   #245	-> 4291
/*      */     //   #244	-> 4328
/*      */     //   #246	-> 4336
/*      */     //   #247	-> 4357
/*      */     //   #248	-> 4434
/*      */     //   #249	-> 4513
/*      */     //   #250	-> 4592
/*      */     //   #252	-> 4595
/*      */     //   #253	-> 4622
/*      */     //   #254	-> 4634
/*      */     //   #255	-> 4640
/*      */     //   #257	-> 4705
/*      */     //   #259	-> 4732
/*      */     //   #263	-> 4738
/*      */     //   #264	-> 4750
/*      */     //   #265	-> 4763
/*      */     //   #266	-> 4773
/*      */     //   #267	-> 4782
/*      */     //   #268	-> 4786
/*      */     //   #268	-> 4805
/*      */     //   #269	-> 4809
/*      */     //   #271	-> 4874
/*      */     //   #273	-> 4901
/*      */     //   #274	-> 4913
/*      */     //   #275	-> 4919
/*      */     //   #277	-> 4993
/*      */     //   #278	-> 5020
/*      */     //   #279	-> 5032
/*      */     //   #280	-> 5038
/*      */     //   #286	-> 5103
/*      */     //   #287	-> 5130
/*      */     //   #288	-> 5142
/*      */     //   #289	-> 5204
/*      */     //   #290	-> 5215
/*      */     //   #291	-> 5289
/*      */     //   #292	-> 5310
/*      */     //   #294	-> 5376
/*      */     //   #295	-> 5403
/*      */     //   #296	-> 5415
/*      */     //   #297	-> 5477
/*      */     //   #298	-> 5488
/*      */     //   #299	-> 5562
/*      */     //   #300	-> 5583
/*      */     //   #302	-> 5649
/*      */     //   #303	-> 5676
/*      */     //   #304	-> 5683
/*      */     //   #305	-> 5689
/*      */     //   #306	-> 5702
/*      */     //   #307	-> 5717
/*      */     //   #308	-> 5775
/*      */     //   #310	-> 5794
/*      */     //   #311	-> 5810
/*      */     //   #312	-> 5887
/*      */     //   #313	-> 5966
/*      */     //   #315	-> 6050
/*      */     //   #316	-> 6077
/*      */     //   #316	-> 6089
/*      */     //   #317	-> 6099
/*      */     //   #318	-> 6103
/*      */     //   #319	-> 6118
/*      */     //   #319	-> 6129
/*      */     //   #319	-> 6140
/*      */     //   #319	-> 6151
/*      */     //   #319	-> 6162
/*      */     //   #320	-> 6173
/*      */     //   #321	-> 6238
/*      */     //   #323	-> 6242
/*      */     //   #324	-> 6269
/*      */     //   #324	-> 6281
/*      */     //   #325	-> 6291
/*      */     //   #326	-> 6295
/*      */     //   #327	-> 6310
/*      */     //   #327	-> 6321
/*      */     //   #327	-> 6332
/*      */     //   #327	-> 6343
/*      */     //   #328	-> 6354
/*      */     //   #329	-> 6419
/*      */     //   #331	-> 6423
/*      */     //   #332	-> 6450
/*      */     //   #333	-> 6456
/*      */     //   #334	-> 6462
/*      */     //   #335	-> 6481
/*      */     //   #337	-> 6545
/*      */     //   #339	-> 6629
/*      */     //   #340	-> 6656
/*      */     //   #341	-> 6663
/*      */     //   #342	-> 6669
/*      */     //   #343	-> 6682
/*      */     //   #344	-> 6697
/*      */     //   #345	-> 6755
/*      */     //   #347	-> 6774
/*      */     //   #348	-> 6790
/*      */     //   #349	-> 6867
/*      */     //   #350	-> 6946
/*      */     //   #352	-> 7030
/*      */     //   #353	-> 7057
/*      */     //   #353	-> 7069
/*      */     //   #354	-> 7079
/*      */     //   #355	-> 7083
/*      */     //   #356	-> 7098
/*      */     //   #356	-> 7109
/*      */     //   #356	-> 7120
/*      */     //   #356	-> 7131
/*      */     //   #356	-> 7142
/*      */     //   #357	-> 7153
/*      */     //   #358	-> 7218
/*      */     //   #360	-> 7222
/*      */     //   #361	-> 7249
/*      */     //   #361	-> 7261
/*      */     //   #362	-> 7271
/*      */     //   #363	-> 7275
/*      */     //   #364	-> 7290
/*      */     //   #364	-> 7301
/*      */     //   #364	-> 7312
/*      */     //   #364	-> 7323
/*      */     //   #365	-> 7334
/*      */     //   #366	-> 7399
/*      */     //   #269	-> 7403
/*      */     //   #270	-> 7430
/*      */     //   #271	-> 7436
/*      */     //   #273	-> 7462
/*      */     //   #274	-> 7529
/*      */     //   #277	-> 7599
/*      */     //   #278	-> 7626
/*      */     //   #279	-> 7638
/*      */     //   #281	-> 7671
/*      */     //   #282	-> 7698
/*      */     //   #283	-> 7705
/*      */     //   #284	-> 7711
/*      */     //   #284	-> 7728
/*      */     //   #285	-> 7771
/*      */     //   #284	-> 7782
/*      */     //   #286	-> 7790
/*      */     //   #285	-> 7801
/*      */     //   #286	-> 7809
/*      */     //   #287	-> 7854
/*      */     //   #286	-> 7865
/*      */     //   #288	-> 7873
/*      */     //   #289	-> 7937
/*      */     //   #290	-> 8005
/*      */     //   #291	-> 8066
/*      */     //   #292	-> 8127
/*      */     //   #293	-> 8188
/*      */     //   #294	-> 8249
/*      */     //   #295	-> 8310
/*      */     //   #296	-> 8371
/*      */     //   #297	-> 8433
/*      */     //   #298	-> 8494
/*      */     //   #299	-> 8555
/*      */     //   #301	-> 8616
/*      */     //   #302	-> 8699
/*      */     //   #303	-> 8793
/*      */     //   #304	-> 8887
/*      */     //   #305	-> 8981
/*      */     //   #307	-> 8988
/*      */     //   #309	-> 8992
/*      */     //   #310	-> 9019
/*      */     //   #311	-> 9026
/*      */     //   #312	-> 9032
/*      */     //   #313	-> 9096
/*      */     //   #314	-> 9164
/*      */     //   #315	-> 9225
/*      */     //   #316	-> 9286
/*      */     //   #317	-> 9347
/*      */     //   #318	-> 9408
/*      */     //   #319	-> 9469
/*      */     //   #320	-> 9530
/*      */     //   #321	-> 9592
/*      */     //   #322	-> 9653
/*      */     //   #323	-> 9714
/*      */     //   #324	-> 9775
/*      */     //   #325	-> 9858
/*      */     //   #326	-> 9952
/*      */     //   #329	-> 9959
/*      */     //   #330	-> 9986
/*      */     //   #331	-> 9992
/*      */     //   #332	-> 9998
/*      */     //   #333	-> 10004
/*      */     //   #335	-> 10066
/*      */     //   #336	-> 10093
/*      */     //   #337	-> 10100
/*      */     //   #338	-> 10106
/*      */     //   #339	-> 10119
/*      */     //   #340	-> 10134
/*      */     //   #341	-> 10149
/*      */     //   #342	-> 10164
/*      */     //   #343	-> 10247
/*      */     //   #344	-> 10341
/*      */     //   #345	-> 10435
/*      */     //   #346	-> 10529
/*      */     //   #347	-> 10597
/*      */     //   #348	-> 10664
/*      */     //   #350	-> 10671
/*      */     //   #351	-> 10698
/*      */     //   #352	-> 10705
/*      */     //   #353	-> 10711
/*      */     //   #354	-> 10724
/*      */     //   #355	-> 10739
/*      */     //   #356	-> 10754
/*      */     //   #357	-> 10769
/*      */     //   #358	-> 10852
/*      */     //   #359	-> 10946
/*      */     //   #360	-> 11040
/*      */     //   #361	-> 11134
/*      */     //   #362	-> 11202
/*      */     //   #363	-> 11269
/*      */     //   #365	-> 11276
/*      */     //   #366	-> 11303
/*      */     //   #367	-> 11315
/*      */     //   #368	-> 11321
/*      */     //   #369	-> 11386
/*      */     //   #371	-> 11393
/*      */     //   #373	-> 11420
/*      */     //   #374	-> 11427
/*      */     //   #375	-> 11433
/*      */     //   #376	-> 11446
/*      */     //   #377	-> 11460
/*      */     //   #378	-> 11471
/*      */     //   #379	-> 11483
/*      */     //   #380	-> 11545
/*      */     //   #381	-> 11607
/*      */     //   #382	-> 11680
/*      */     //   #383	-> 11753
/*      */     //   #384	-> 11817
/*      */     //   #385	-> 11878
/*      */     //   #385	-> 11887
/*      */     //   #386	-> 11896
/*      */     //   #387	-> 11959
/*      */     //   #389	-> 12026
/*      */     //   #389	-> 12035
/*      */     //   #390	-> 12044
/*      */     //   #391	-> 12107
/*      */     //   #394	-> 12174
/*      */     //   #395	-> 12235
/*      */     //   #397	-> 12299
/*      */     //   #398	-> 12366
/*      */     //   #400	-> 12373
/*      */     //   #402	-> 12400
/*      */     //   #403	-> 12407
/*      */     //   #404	-> 12413
/*      */     //   #405	-> 12426
/*      */     //   #406	-> 12440
/*      */     //   #407	-> 12451
/*      */     //   #408	-> 12463
/*      */     //   #409	-> 12525
/*      */     //   #410	-> 12587
/*      */     //   #411	-> 12660
/*      */     //   #412	-> 12733
/*      */     //   #413	-> 12797
/*      */     //   #414	-> 12858
/*      */     //   #414	-> 12867
/*      */     //   #415	-> 12876
/*      */     //   #416	-> 12939
/*      */     //   #418	-> 13006
/*      */     //   #418	-> 13015
/*      */     //   #419	-> 13024
/*      */     //   #420	-> 13087
/*      */     //   #423	-> 13154
/*      */     //   #424	-> 13215
/*      */     //   #426	-> 13279
/*      */     //   #427	-> 13346
/*      */     //   #429	-> 13353
/*      */     //   #431	-> 13380
/*      */     //   #432	-> 13392
/*      */     //   #433	-> 13397
/*      */     //   #433	-> 13405
/*      */     //   #434	-> 13413
/*      */     //   #435	-> 13453
/*      */     //   #436	-> 13466
/*      */     //   #437	-> 13480
/*      */     //   #438	-> 13491
/*      */     //   #439	-> 13503
/*      */     //   #440	-> 13517
/*      */     //   #441	-> 13531
/*      */     //   #441	-> 13539
/*      */     //   #442	-> 13549
/*      */     //   #443	-> 13589
/*      */     //   #443	-> 13597
/*      */     //   #444	-> 13607
/*      */     //   #445	-> 13647
/*      */     //   #446	-> 13655
/*      */     //   #447	-> 13670
/*      */     //   #448	-> 13685
/*      */     //   #449	-> 13704
/*      */     //   #450	-> 13744
/*      */     //   #451	-> 13763
/*      */     //   #453	-> 13803
/*      */     //   #454	-> 13803
/*      */     //   #457	-> 13876
/*      */     //   #458	-> 13896
/*      */     //   #459	-> 13937
/*      */     //   #464	-> 13975
/*      */     //   #467	-> 14015
/*      */     //   #468	-> 14082
/*      */     //   #470	-> 14086
/*      */     //   #470	-> 14106
/*      */     //   #473	-> 14113
/*      */     //   #474	-> 14140
/*      */     //   #475	-> 14146
/*      */     //   #476	-> 14152
/*      */     //   #478	-> 14167
/*      */     //   #478	-> 14175
/*      */     //   #479	-> 14218
/*      */     //   #483	-> 14308
/*      */     //   #484	-> 14335
/*      */     //   #485	-> 14342
/*      */     //   #486	-> 14348
/*      */     //   #487	-> 14361
/*      */     //   #488	-> 14376
/*      */     //   #489	-> 14391
/*      */     //   #490	-> 14406
/*      */     //   #491	-> 14489
/*      */     //   #492	-> 14583
/*      */     //   #493	-> 14677
/*      */     //   #494	-> 14771
/*      */     //   #496	-> 14839
/*      */     //   #497	-> 14919
/*      */     //   #499	-> 14926
/*      */     //   #500	-> 14953
/*      */     //   #501	-> 14960
/*      */     //   #502	-> 14966
/*      */     //   #503	-> 14981
/*      */     //   #504	-> 14998
/*      */     //   #505	-> 15015
/*      */     //   #506	-> 15032
/*      */     //   #507	-> 15115
/*      */     //   #508	-> 15209
/*      */     //   #509	-> 15303
/*      */     //   #510	-> 15397
/*      */     //   #512	-> 15464
/*      */     //   #513	-> 15544
/*      */     //   #515	-> 15551
/*      */     //   #516	-> 15578
/*      */     //   #517	-> 15585
/*      */     //   #518	-> 15591
/*      */     //   #519	-> 15604
/*      */     //   #520	-> 15619
/*      */     //   #521	-> 15634
/*      */     //   #522	-> 15649
/*      */     //   #523	-> 15732
/*      */     //   #524	-> 15826
/*      */     //   #525	-> 15920
/*      */     //   #526	-> 16014
/*      */     //   #528	-> 16082
/*      */     //   #529	-> 16162
/*      */     //   #533	-> 16169
/*      */     //   #534	-> 16196
/*      */     //   #535	-> 16203
/*      */     //   #536	-> 16209
/*      */     //   #537	-> 16222
/*      */     //   #538	-> 16237
/*      */     //   #539	-> 16320
/*      */     //   #540	-> 16414
/*      */     //   #541	-> 16482
/*      */     //   #542	-> 16549
/*      */     //   #544	-> 16556
/*      */     //   #545	-> 16583
/*      */     //   #546	-> 16590
/*      */     //   #547	-> 16596
/*      */     //   #548	-> 16609
/*      */     //   #549	-> 16624
/*      */     //   #550	-> 16639
/*      */     //   #551	-> 16654
/*      */     //   #552	-> 16737
/*      */     //   #553	-> 16831
/*      */     //   #554	-> 16925
/*      */     //   #555	-> 17019
/*      */     //   #556	-> 17087
/*      */     //   #557	-> 17154
/*      */     //   #559	-> 17161
/*      */     //   #560	-> 17188
/*      */     //   #561	-> 17200
/*      */     //   #562	-> 17206
/*      */     //   #564	-> 17280
/*      */     //   #565	-> 17307
/*      */     //   #565	-> 17319
/*      */     //   #566	-> 17329
/*      */     //   #567	-> 17333
/*      */     //   #568	-> 17348
/*      */     //   #568	-> 17359
/*      */     //   #569	-> 17370
/*      */     //   #570	-> 17438
/*      */     //   #572	-> 17508
/*      */     //   #575	-> 17512
/*      */     //   #576	-> 17539
/*      */     //   #577	-> 17546
/*      */     //   #578	-> 17552
/*      */     //   #579	-> 17565
/*      */     //   #580	-> 17580
/*      */     //   #581	-> 17595
/*      */     //   #582	-> 17610
/*      */     //   #583	-> 17645
/*      */     //   #582	-> 17671
/*      */     //   #584	-> 17682
/*      */     //   #585	-> 17686
/*      */     //   #586	-> 17704
/*      */     //   #587	-> 17769
/*      */     //   #588	-> 17845
/*      */     //   #589	-> 17920
/*      */     //   #592	-> 18009
/*      */     //   #593	-> 18074
/*      */     //   #594	-> 18150
/*      */     //   #595	-> 18218
/*      */     //   #597	-> 18297
/*      */     //   #598	-> 18315
/*      */     //   #599	-> 18391
/*      */     //   #600	-> 18467
/*      */     //   #601	-> 18553
/*      */     //   #604	-> 18642
/*      */     //   #605	-> 18718
/*      */     //   #606	-> 18794
/*      */     //   #607	-> 18873
/*      */     //   #610	-> 18952
/*      */     //   #611	-> 18956
/*      */     //   #612	-> 18961
/*      */     //   #615	-> 18969
/*      */     //   #616	-> 18996
/*      */     //   #617	-> 19008
/*      */     //   #618	-> 19023
/*      */     //   #619	-> 19027
/*      */     //   #621	-> 19093
/*      */     //   #622	-> 19120
/*      */     //   #623	-> 19132
/*      */     //   #624	-> 19147
/*      */     //   #625	-> 19151
/*      */     //   #627	-> 19217
/*      */     //   #628	-> 19244
/*      */     //   #629	-> 19250
/*      */     //   #0	-> 19275
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	19276	0	what	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	19276	1	value	Lorg/renjin/sexp/SEXP;
/*      */     //   0	19276	2	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	19276	3	np	I
/*      */     //   0	19276	4	ncol	I
/*      */     //   0	19276	5	nrow	I
/*      */     //   0	19276	6	col	I
/*      */     //   0	19276	7	row	I
/*      */     //   0	19276	8	ncol	I
/*      */     //   0	19276	9	nrow	I
/*      */     //   0	19276	10	ncol	I
/*      */     //   0	19276	11	nrow	I
/*      */     //   0	19276	12	vmax	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	19276	13	vmax$offset	I
/*      */     //   0	19276	14	ss	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	19276	15	ss$offset	I
/*      */     //   0	19276	16	cx	B
/*      */     //   0	19276	17	ix	I
/*      */     //   0	19276	18	x	D
/*      */     //   0	19276	32	R_NaInt$40	I
/*      */     //   0	19276	41	R_NaInt$39	I
/*      */     //   0	19276	1312	ix$38	I
/*      */     //   0	19276	1422	R_NaInt$37	I
/*      */     //   0	19276	1525	R_NaReal$36	D
/*      */     //   0	19276	1552	R_NaReal$35	D
/*      */     //   0	19276	1585	R_NaInt$34	I
/*      */     //   0	19276	1779	ix$33	I
/*      */     //   0	19276	1785	ix$32	I
/*      */     //   0	19276	1807	R_BlankString$31	Lorg/renjin/sexp/SEXP;
/*      */     //   0	19276	1808	R_NaString$30	Lorg/renjin/sexp/SEXP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Specify2(Ptr what, SEXP value, Ptr dd) {
/*  655 */     ix = 0; ptype = ParCode(what);
/*  656 */     cx = (byte)0;
/*      */     
/*  658 */     if (ptype != 1 && ptype != -3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  664 */       if (ptype != -2) {
/*      */ 
/*      */ 
/*      */         
/*  668 */         if (ptype >= 0) {
/*      */ 
/*      */ 
/*      */           
/*  672 */           if (ptype != 2) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("adj\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("ann\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("bg\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("bty\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.main\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.lab\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.sub\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.axis\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("col\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.main\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.lab\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.sub\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.axis\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("crt\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("err\000".getBytes(), 0)) == 0) { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); if (ix != 0 && ix != -1) { par_error(what); } else { base__.Rf_gpptr(dd).setInt(72, ix); return; }  }  if (Stdlib.strcmp(what, (Ptr)new BytePtr("family\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("fg\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("font\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.main\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.lab\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.sub\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.axis\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("lab\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("las\000".getBytes(), 0)) == 0) { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); if (ix < 0 || ix > 3) { par_error(what); } else { base__.Rf_gpptr(dd).setInt(308, ix); return; }  }  if (Stdlib.strcmp(what, (Ptr)new BytePtr("lend\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("ljoin\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("lmitre\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("lty\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("lwd\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("mgp\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("mkh\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("pch\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("smo\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("srt\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("tck\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("tcl\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxp\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxs\000".getBytes(), 0)) == 0) { if (Rinternals.TYPEOF(value) != 16 || Rinternals.LENGTH(value) <= 0) par_error(what);  cx = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, 0)).getByte(); if (cx != (byte)115 && cx != (byte)101 && cx != (byte)105 && cx != (byte)114 && cx != (byte)100) { par_error(what); } else { base__.Rf_gpptr(dd).setByte(436, cx); return; }  }  if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxt\000".getBytes(), 0)) == 0) { if (Rinternals.TYPEOF(value) != 16 || Rinternals.LENGTH(value) <= 0) par_error(what);  cx = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, 0)).getByte(); if (cx != (byte)115 && cx != (byte)108 && cx != (byte)116 && cx != (byte)110) { par_error(what); } else { base__.Rf_gpptr(dd).setByte(437, cx); return; }  }  if (Stdlib.strcmp(what, (Ptr)new BytePtr("xpd\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxp\000".getBytes(), 0)) != 0) { if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxs\000".getBytes(), 0)) == 0) { if (Rinternals.TYPEOF(value) != 16 || Rinternals.LENGTH(value) <= 0) par_error(what);  cx = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, 0)).getByte(); if (cx != (byte)115 && cx != (byte)101 && cx != (byte)105 && cx != (byte)114 && cx != (byte)100) { par_error(what); } else { base__.Rf_gpptr(dd).setByte(476, cx); return; }  }  if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxt\000".getBytes(), 0)) == 0) { if (Rinternals.TYPEOF(value) != 16 || Rinternals.LENGTH(value) <= 0) par_error(what);  cx = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, 0)).getByte(); if (cx != (byte)115 && cx != (byte)108 && cx != (byte)116 && cx != (byte)110) { par_error(what); return; }  base__.Rf_gpptr(dd).setByte(477, cx); }  return; }  value = Rinternals.Rf_coerceVector(value, 14); lengthCheck(what, value, 3); naRealCheck(Rinternals2.REAL(value).getDouble(), what); naRealCheck(Rinternals2.REAL(value).getDouble(8), what); if (base__.Rf_gpptr(dd).getInt(480) == 0) { posIntCheck((int)Rinternals2.REAL(value).getDouble(16), what); } else { logAxpCheck((int)Rinternals2.REAL(value).getDouble(16), what); }  Ptr ptr11 = base__.Rf_gpptr(dd); double d11 = Rinternals2.REAL(value).getDouble(); ptr11.setDouble(452, d11); Ptr ptr10 = base__.Rf_gpptr(dd); double d10 = Rinternals2.REAL(value).getDouble(8); ptr10.setDouble(460, d10); Ptr ptr9 = base__.Rf_gpptr(dd); double d9 = (int)Rinternals2.REAL(value).getDouble(16); ptr9.setDouble(468, d9); return; }  lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); R_NaInt$29 = Arith.R_NaInt; if (ix != R_NaInt$29) { Ptr ptr9 = base__.Rf_gpptr(dd); boolean bool = (ix == 0) ? false : true; ptr9.setInt(444, bool); return; }  base__.Rf_gpptr(dd).setInt(444, 2); return; }  value = Rinternals.Rf_coerceVector(value, 14); lengthCheck(what, value, 3); naRealCheck(Rinternals2.REAL(value).getDouble(), what); naRealCheck(Rinternals2.REAL(value).getDouble(8), what); if (base__.Rf_gpptr(dd).getInt(440) == 0) { posIntCheck((int)Rinternals2.REAL(value).getDouble(16), what); } else { logAxpCheck((int)Rinternals2.REAL(value).getDouble(16), what); }  Ptr ptr8 = base__.Rf_gpptr(dd); double d8 = Rinternals2.REAL(value).getDouble(); ptr8.setDouble(412, d8); Ptr ptr7 = base__.Rf_gpptr(dd); double d7 = Rinternals2.REAL(value).getDouble(8); ptr7.setDouble(420, d7); Ptr ptr6 = base__.Rf_gpptr(dd); double d6 = (int)Rinternals2.REAL(value).getDouble(16); ptr6.setDouble(428, d6); return; }  lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); base__.Rf_gpptr(dd).setDouble(404, x); if (Arith.R_finite(x) == 0) { if (Arith.R_finite(base__.Rf_dpptr(dd).getDouble(396)) == 0) base__.Rf_gpptr(dd).setDouble(396, -0.01D);  return; }  Ptr ptr5 = base__.Rf_gpptr(dd); R_NaReal$28 = Arith.R_NaReal; ptr5.setDouble(396, R_NaReal$28); return; }  lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); base__.Rf_gpptr(dd).setDouble(396, x); if (Arith.R_finite(x) == 0) { if (Arith.R_finite(base__.Rf_dpptr(dd).getDouble(404)) == 0) base__.Rf_gpptr(dd).setDouble(404, -0.5D);  return; }  Ptr ptr4 = base__.Rf_gpptr(dd); R_NaReal$27 = Arith.R_NaReal; ptr4.setDouble(404, R_NaReal$27); return; }  lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); naRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(388, x); return; }  lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); nonnegRealCheck(x, what); Ptr ptr = base__.Rf_gpptr(dd); int i = (int)x; ptr.setInt(384, i); return; }  if (!Rinternals.Rf_isVector(value) || Rinternals.LENGTH(value) <= 0) par_error(what);  if (Rinternals.TYPEOF(value) != 16) { if (!Rinternals.Rf_isNumeric(value)) { par_error(what); } else { ix = Rinternals.Rf_asInteger(value); }  } else { ix = baseEngine__.GEstring_to_pch(Rinternals.STRING_ELT(value, 0)); }  R_NaInt$26 = Arith.R_NaInt; if (ix == R_NaInt$26) par_error(what);  base__.Rf_gpptr(dd).setInt(372, ix); return; }  lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(364, x); return; }  value = Rinternals.Rf_coerceVector(value, 14); Rinternals.Rf_protect(value); lengthCheck(what, value, 3); naRealCheck(Rinternals2.REAL(value).getDouble(), what); naRealCheck(Rinternals2.REAL(value).getDouble(8), what); naRealCheck(Rinternals2.REAL(value).getDouble(16), what); double d5 = Rinternals2.REAL(value).getDouble(), d4 = Rinternals2.REAL(value).getDouble(8); if (d5 * d4 >= 0.0D) { double d7 = Rinternals2.REAL(value).getDouble(), d6 = Rinternals2.REAL(value).getDouble(16); if (d7 * d6 >= 0.0D) { Ptr ptr6 = base__.Rf_gpptr(dd); double d10 = Rinternals2.REAL(value).getDouble(); ptr6.setDouble(340, d10); Ptr ptr5 = base__.Rf_gpptr(dd); double d9 = Rinternals2.REAL(value).getDouble(8); ptr5.setDouble(348, d9); Ptr ptr4 = base__.Rf_gpptr(dd); double d8 = Rinternals2.REAL(value).getDouble(16); ptr4.setDouble(356, d8); return; }  }  Error.Rf_warning(new BytePtr("`mgp[1:3]' are of differing sign\000".getBytes(), 0), new Object[0]); } else { if (!Rinternals.Rf_isVector(value) || Rinternals.LENGTH(value) <= 0) par_error(what);  x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(316, x); return; }  } else { if (!Rinternals.Rf_isVector(value) || Rinternals.LENGTH(value) <= 0) par_error(what);  Ptr ptr = base__.Rf_gpptr(dd); int i = baseEngine__.GE_LTYpar(value, 0); ptr.setInt(312, i); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); if (x < 1.0D) par_error(what);  base__.Rf_gpptr(dd).setDouble(332, x); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int i = baseEngine__.GE_LJOINpar(value, 0); ptr.setInt(328, i); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int i = baseEngine__.GE_LENDpar(value, 0); ptr.setInt(324, i); return; }  } else { value = Rinternals.Rf_coerceVector(value, 13); lengthCheck(what, value, 3); posIntCheck(Rinternals2.INTEGER(value).getInt(), what); posIntCheck(Rinternals2.INTEGER(value).getInt(4), what); nonnegIntCheck(Rinternals2.INTEGER(value).getInt(8), what); Ptr ptr6 = base__.Rf_gpptr(dd); int k = Rinternals2.INTEGER(value).getInt(); ptr6.setInt(296, k); Ptr ptr5 = base__.Rf_gpptr(dd); int j = Rinternals2.INTEGER(value).getInt(4); ptr5.setInt(300, j); Ptr ptr4 = base__.Rf_gpptr(dd); int i = Rinternals2.INTEGER(value).getInt(8); ptr4.setInt(304, i); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); posIntCheck(ix, what); base__.Rf_gpptr(dd).setInt(536, ix); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); posIntCheck(ix, what); base__.Rf_gpptr(dd).setInt(532, ix); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); posIntCheck(ix, what); base__.Rf_gpptr(dd).setInt(528, ix); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); posIntCheck(ix, what); base__.Rf_gpptr(dd).setInt(524, ix); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asInteger(value); posIntCheck(ix, what); base__.Rf_gpptr(dd).setInt(284, ix); return; }  } else { lengthCheck(what, value, 1); int i = base__.Rf_dpptr(dd).getInt(20); ix = colors__.Rf_RGBpar3(value, 0, i); Ptr ptr = base__.Rf_gpptr(dd); ix$25 = ix; ptr.setInt(76, ix$25); return; }  } else { value = Rinternals.Rf_coerceVector(value, 16); SEXP sEXP = Rinternals.STRING_ELT(value, 0); R_NaString$23 = Rinternals.R_NaString; if (sEXP == R_NaString$23) { R_BlankString$24 = Rinternals.R_BlankString; Rinternals.SET_STRING_ELT(value, 0, R_BlankString$24); }  lengthCheck(what, value, 1); vmax = VoidPtr.toPtr(Memory.vmaxget()); BytePtr bytePtr = Rinternals.Rf_translateChar(Rinternals.STRING_ELT(value, 0)); if (Integer.compareUnsigned(Stdlib.strlen((Ptr)bytePtr), 200) > 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("graphical parameter 'family' has a maximum length of 200 bytes\000".getBytes(), 0)), new Object[0]);  Stdlib.strncpy(base__.Rf_gpptr(dd).pointerPlus(80), (Ptr)bytePtr, 201); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); naRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(48, x); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(552, i); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(548, i); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(544, i); return; }  } else { lengthCheck(what, value, 1); Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(540, i); return; }  } else { if (!Rinternals.Rf_isVector(value) || Rinternals.LENGTH(value) <= 0) par_error(what);  Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(44, i); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(516, x); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(508, x); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(500, x); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(492, x); return; }  } else { x = Rinternals.Rf_asReal(value); posRealCheck(x, what); base__.Rf_gpptr(dd).setDouble(28, x); return; }  } else { lengthCheck(what, value, 1); if (Rinternals.TYPEOF(value) != 16) par_error(what);  cx = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, 0)).getByte(); switch (cx) { case 55: case 67: case 76: case 79: case 85: case 91: case 93: case 99: case 108: case 110: case 111: case 117: base__.Rf_gpptr(dd).setByte(24, cx); return; }  par_error(what); return; }  } else { if (!Rinternals.Rf_isVector(value) || Rinternals.LENGTH(value) <= 0)
/*  673 */                     par_error(what);  Ptr ptr = base__.Rf_gpptr(dd); int j = base__.Rf_dpptr(dd).getInt(20), i = colors__.Rf_RGBpar3(value, 0, j); ptr.setInt(20, i); return; }  } else { lengthCheck(what, value, 1); ix = Rinternals.Rf_asLogical(value); Ptr ptr = base__.Rf_gpptr(dd); boolean bool = (ix == 0) ? false : true; ptr.setInt(16, bool); return; }  } else { lengthCheck(what, value, 1); x = Rinternals.Rf_asReal(value); BoundsCheck(x, 0.0D, 1.0D, what); base__.Rf_gpptr(dd).setDouble(8, x); return; }  } else { Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("graphical parameter \"%s\" cannot be set\000".getBytes(), 0)), new Object[] { what }); return; }
/*      */         
/*      */         } else {
/*      */           Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("\"%s\" is not a graphical parameter\000".getBytes(), 0)), new Object[] { what }); return;
/*      */         } 
/*      */       } else {
/*      */         Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("graphical parameter \"%s\" is obsolete\000".getBytes(), 0)), new Object[] { what }); return;
/*      */       } 
/*      */     } else {
/*      */       return;
/*      */     }  Ptr ptr3 = base__.Rf_gpptr(dd); double d3 = Rinternals2.REAL(value).getDouble(); ptr3.setDouble(340, d3); Ptr ptr2 = base__.Rf_gpptr(dd);
/*      */     double d2 = Rinternals2.REAL(value).getDouble(8);
/*      */     ptr2.setDouble(348, d2);
/*      */     Ptr ptr1 = base__.Rf_gpptr(dd);
/*      */     double d1 = Rinternals2.REAL(value).getDouble(16);
/*  688 */     ptr1.setDouble(356, d1); } public static SEXP Query(Ptr what, Ptr dd) { buf = new byte[2]; arrayOfByte1 = new byte[2]; arrayOfByte2 = new byte[2]; arrayOfByte3 = new byte[2]; arrayOfByte4 = new byte[2]; arrayOfByte5 = new byte[2]; col = new int[1]; row = new int[1]; arrayOfByte6 = new byte[2]; col[0] = 0; row[0] = 0; if (Stdlib.strcmp(what, (Ptr)new BytePtr("adj\000".getBytes(), 0)) != 0)
/*      */     
/*      */     { 
/*      */       
/*  692 */       if (Stdlib.strcmp(what, (Ptr)new BytePtr("ann\000".getBytes(), 0)) != 0)
/*      */       
/*      */       { 
/*      */         
/*  696 */         if (Stdlib.strcmp(what, (Ptr)new BytePtr("ask\000".getBytes(), 0)) != 0)
/*      */         
/*      */         { 
/*      */           
/*  700 */           if (Stdlib.strcmp(what, (Ptr)new BytePtr("bg\000".getBytes(), 0)) != 0)
/*      */           
/*      */           { 
/*  703 */             if (Stdlib.strcmp(what, (Ptr)new BytePtr("bty\000".getBytes(), 0)) != 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/*  709 */               if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex\000".getBytes(), 0)) != 0)
/*      */               
/*      */               { 
/*      */                 
/*  713 */                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.main\000".getBytes(), 0)) != 0)
/*      */                 
/*      */                 { 
/*      */                   
/*  717 */                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.lab\000".getBytes(), 0)) != 0)
/*      */                   
/*      */                   { 
/*      */                     
/*  721 */                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.sub\000".getBytes(), 0)) != 0)
/*      */                     
/*      */                     { 
/*      */                       
/*  725 */                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("cex.axis\000".getBytes(), 0)) != 0)
/*      */                       
/*      */                       { 
/*      */                         
/*  729 */                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("cin\000".getBytes(), 0)) != 0)
/*      */                         
/*      */                         { 
/*      */ 
/*      */                           
/*  734 */                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("col\000".getBytes(), 0)) != 0)
/*      */                           
/*      */                           { 
/*  737 */                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.main\000".getBytes(), 0)) != 0)
/*      */                             
/*      */                             { 
/*  740 */                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.lab\000".getBytes(), 0)) != 0)
/*      */                               
/*      */                               { 
/*  743 */                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.sub\000".getBytes(), 0)) != 0)
/*      */                                 
/*      */                                 { 
/*  746 */                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("col.axis\000".getBytes(), 0)) != 0)
/*      */                                   
/*      */                                   { 
/*  749 */                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("cra\000".getBytes(), 0)) != 0)
/*      */                                     
/*      */                                     { 
/*      */ 
/*      */                                       
/*  754 */                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("crt\000".getBytes(), 0)) != 0)
/*      */                                       
/*      */                                       { 
/*      */                                         
/*  758 */                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("csi\000".getBytes(), 0)) != 0)
/*      */                                         
/*      */                                         { 
/*      */                                           
/*  762 */                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("cxy\000".getBytes(), 0)) != 0)
/*      */                                           
/*      */                                           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                                             
/*  772 */                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("din\000".getBytes(), 0)) != 0)
/*      */                                             
/*      */                                             { 
/*      */ 
/*      */                                               
/*  777 */                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("err\000".getBytes(), 0)) != 0)
/*      */                                               
/*      */                                               { 
/*      */                                                 
/*  781 */                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("family\000".getBytes(), 0)) != 0)
/*      */                                                 
/*      */                                                 { 
/*  784 */                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("fg\000".getBytes(), 0)) != 0)
/*      */                                                   
/*      */                                                   { 
/*  787 */                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("fig\000".getBytes(), 0)) != 0)
/*      */                                                     
/*      */                                                     { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                       
/*  794 */                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("fin\000".getBytes(), 0)) != 0)
/*      */                                                       
/*      */                                                       { 
/*      */ 
/*      */                                                         
/*  799 */                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("font\000".getBytes(), 0)) != 0)
/*      */                                                         
/*      */                                                         { 
/*      */                                                           
/*  803 */                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.main\000".getBytes(), 0)) != 0)
/*      */                                                           
/*      */                                                           { 
/*      */                                                             
/*  807 */                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.lab\000".getBytes(), 0)) != 0)
/*      */                                                             
/*      */                                                             { 
/*      */                                                               
/*  811 */                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.sub\000".getBytes(), 0)) != 0)
/*      */                                                               
/*      */                                                               { 
/*      */                                                                 
/*  815 */                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("font.axis\000".getBytes(), 0)) != 0)
/*      */                                                                 
/*      */                                                                 { 
/*      */                                                                   
/*  819 */                                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("lab\000".getBytes(), 0)) != 0)
/*      */                                                                   
/*      */                                                                   { 
/*      */ 
/*      */ 
/*      */                                                                     
/*  825 */                                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("las\000".getBytes(), 0)) != 0)
/*      */                                                                     
/*      */                                                                     { 
/*      */                                                                       
/*  829 */                                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("lend\000".getBytes(), 0)) != 0)
/*      */                                                                       
/*      */                                                                       { 
/*  832 */                                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("lheight\000".getBytes(), 0)) != 0)
/*      */                                                                         
/*      */                                                                         { 
/*      */                                                                           
/*  836 */                                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("ljoin\000".getBytes(), 0)) != 0)
/*      */                                                                           
/*      */                                                                           { 
/*  839 */                                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("lmitre\000".getBytes(), 0)) != 0)
/*      */                                                                             
/*      */                                                                             { 
/*      */                                                                               
/*  843 */                                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("lty\000".getBytes(), 0)) != 0)
/*      */                                                                               
/*      */                                                                               { 
/*  846 */                                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("lwd\000".getBytes(), 0)) != 0)
/*      */                                                                                 
/*      */                                                                                 { 
/*      */                                                                                   
/*  850 */                                                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("mai\000".getBytes(), 0)) != 0)
/*      */                                                                                   
/*      */                                                                                   { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                     
/*  857 */                                                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("mar\000".getBytes(), 0)) != 0)
/*      */                                                                                     
/*      */                                                                                     { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                       
/*  864 */                                                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("mex\000".getBytes(), 0)) != 0)
/*      */                                                                                       
/*      */                                                                                       { 
/*      */ 
/*      */ 
/*      */                                                                                         
/*  870 */                                                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("mfrow\000".getBytes(), 0)) != 0 && Stdlib.strcmp(what, (Ptr)new BytePtr("mfcol\000".getBytes(), 0)) != 0)
/*      */                                                                                         
/*      */                                                                                         { 
/*      */ 
/*      */                                                                                           
/*  875 */                                                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("mfg\000".getBytes(), 0)) != 0)
/*      */                                                                                           
/*      */                                                                                           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                             
/*  884 */                                                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("mgp\000".getBytes(), 0)) != 0)
/*      */                                                                                             
/*      */                                                                                             { 
/*      */ 
/*      */ 
/*      */                                                                                               
/*  890 */                                                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("mkh\000".getBytes(), 0)) != 0)
/*      */                                                                                               
/*      */                                                                                               { 
/*      */ 
/*      */                                                                                                 
/*  895 */                                                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("new\000".getBytes(), 0)) != 0)
/*      */                                                                                                 
/*      */                                                                                                 { 
/*      */                                                                                                   
/*  899 */                                                                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("oma\000".getBytes(), 0)) != 0)
/*      */                                                                                                   
/*      */                                                                                                   { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                     
/*  906 */                                                                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("omd\000".getBytes(), 0)) != 0)
/*      */                                                                                                     
/*      */                                                                                                     { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                       
/*  913 */                                                                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("omi\000".getBytes(), 0)) != 0)
/*      */                                                                                                       
/*      */                                                                                                       { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                         
/*  920 */                                                                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("page\000".getBytes(), 0)) != 0)
/*      */                                                                                                         
/*      */                                                                                                         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                           
/*  934 */                                                                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("pch\000".getBytes(), 0)) != 0)
/*      */                                                                                                           
/*      */                                                                                                           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                             
/*  949 */                                                                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("pin\000".getBytes(), 0)) != 0)
/*      */                                                                                                             
/*      */                                                                                                             { 
/*      */ 
/*      */                                                                                                               
/*  954 */                                                                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("plt\000".getBytes(), 0)) != 0)
/*      */                                                                                                               
/*      */                                                                                                               { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                                 
/*  961 */                                                                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("ps\000".getBytes(), 0)) != 0)
/*      */                                                                                                                 
/*      */                                                                                                                 { 
/*      */ 
/*      */                                                                                                                   
/*  966 */                                                                                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("pty\000".getBytes(), 0)) != 0)
/*      */                                                                                                                   
/*      */                                                                                                                   { 
/*      */ 
/*      */ 
/*      */                                                                                                                     
/*  972 */                                                                                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("smo\000".getBytes(), 0)) != 0)
/*      */                                                                                                                     
/*      */                                                                                                                     { 
/*      */                                                                                                                       
/*  976 */                                                                                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("srt\000".getBytes(), 0)) != 0)
/*      */                                                                                                                       
/*      */                                                                                                                       { 
/*      */                                                                                                                         
/*  980 */                                                                                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("tck\000".getBytes(), 0)) != 0)
/*      */                                                                                                                         
/*      */                                                                                                                         { 
/*      */                                                                                                                           
/*  984 */                                                                                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("tcl\000".getBytes(), 0)) != 0)
/*      */                                                                                                                           
/*      */                                                                                                                           { 
/*      */                                                                                                                             
/*  988 */                                                                                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("usr\000".getBytes(), 0)) != 0)
/*      */                                                                                                                             
/*      */                                                                                                                             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                                               
/* 1007 */                                                                                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxp\000".getBytes(), 0)) != 0)
/*      */                                                                                                                               
/*      */                                                                                                                               { 
/*      */ 
/*      */ 
/*      */                                                                                                                                 
/* 1013 */                                                                                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxs\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                 
/*      */                                                                                                                                 { 
/*      */ 
/*      */ 
/*      */                                                                                                                                   
/* 1019 */                                                                                                                                   if (Stdlib.strcmp(what, (Ptr)new BytePtr("xaxt\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                   
/*      */                                                                                                                                   { 
/*      */ 
/*      */ 
/*      */                                                                                                                                     
/* 1025 */                                                                                                                                     if (Stdlib.strcmp(what, (Ptr)new BytePtr("xlog\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                     
/*      */                                                                                                                                     { 
/*      */                                                                                                                                       
/* 1029 */                                                                                                                                       if (Stdlib.strcmp(what, (Ptr)new BytePtr("xpd\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                       
/*      */                                                                                                                                       { 
/*      */ 
/*      */ 
/*      */ 
/*      */                                                                                                                                         
/* 1036 */                                                                                                                                         if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxp\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                         
/*      */                                                                                                                                         { 
/*      */ 
/*      */ 
/*      */                                                                                                                                           
/* 1042 */                                                                                                                                           if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxs\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                           
/*      */                                                                                                                                           { 
/*      */ 
/*      */ 
/*      */                                                                                                                                             
/* 1048 */                                                                                                                                             if (Stdlib.strcmp(what, (Ptr)new BytePtr("yaxt\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                             
/*      */                                                                                                                                             { 
/*      */ 
/*      */ 
/*      */                                                                                                                                               
/* 1054 */                                                                                                                                               if (Stdlib.strcmp(what, (Ptr)new BytePtr("ylbias\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                               
/*      */                                                                                                                                               { 
/*      */                                                                                                                                                 
/* 1058 */                                                                                                                                                 if (Stdlib.strcmp(what, (Ptr)new BytePtr("ylog\000".getBytes(), 0)) != 0)
/*      */                                                                                                                                                 
/*      */                                                                                                                                                 { 
/*      */                                                                                                                                                   
/* 1062 */                                                                                                                                                   if (ParCode(what) != -2)
/*      */                                                                                                                                                   
/*      */                                                                                                                                                   { 
/*      */ 
/*      */                                                                                                                                                     
/* 1067 */                                                                                                                                                     Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("\"%s\" is not a graphical parameter\000".getBytes(), 0)), new Object[] { what });
/* 1068 */                                                                                                                                                     value = Rinternals.R_NilValue;
/*      */                                                                                                                                                     
/* 1070 */                                                                                                                                                     return value; }  Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("graphical parameter \"%s\" is obsolete\000".getBytes(), 0)), new Object[] { what }); value = Rinternals.R_NilValue; return value; }  value = Rinternals.Rf_allocVector(10, 1); IntPtr intPtr5 = Rinternals.LOGICAL(value); int i16 = base__.Rf_dpptr(dd).getInt(480); intPtr5.setInt(0, i16); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr85 = Rinternals2.REAL(value); double d102 = dd.getPointer().getDouble(80); ptr85.setDouble(0, d102); return value; }  byte b6 = base__.Rf_dpptr(dd).getByte(477); buf[0] = b6; buf[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(buf, 0)); return value; }  byte b5 = base__.Rf_dpptr(dd).getByte(476); arrayOfByte1[0] = b5; arrayOfByte1[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte1, 0)); return value; }  value = Rinternals.Rf_allocVector(14, 3); Ptr ptr84 = Rinternals2.REAL(value); double d101 = base__.Rf_dpptr(dd).getDouble(452); ptr84.setDouble(0, d101); Ptr ptr83 = Rinternals2.REAL(value); double d100 = base__.Rf_dpptr(dd).getDouble(460); ptr83.setDouble(8, d100); Ptr ptr82 = Rinternals2.REAL(value); double d99 = base__.Rf_dpptr(dd).getDouble(468); ptr82.setDouble(16, d99); return value; }  value = Rinternals.Rf_allocVector(10, 1); if (base__.Rf_dpptr(dd).getInt(444) != 2) { IntPtr intPtr5 = Rinternals.LOGICAL(value); int i16 = base__.Rf_dpptr(dd).getInt(444); intPtr5.setInt(0, i16); return value; }  IntPtr intPtr4 = Rinternals.LOGICAL(value); R_NaInt$22 = Arith.R_NaInt; intPtr4.setInt(0, R_NaInt$22); return value; }  value = Rinternals.Rf_allocVector(10, 1); IntPtr intPtr3 = Rinternals.LOGICAL(value); int i15 = base__.Rf_dpptr(dd).getInt(440); intPtr3.setInt(0, i15); return value; }  byte b4 = base__.Rf_dpptr(dd).getByte(437); arrayOfByte2[0] = b4; arrayOfByte2[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte2, 0)); return value; }  byte b3 = base__.Rf_dpptr(dd).getByte(436); arrayOfByte3[0] = b3; arrayOfByte3[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte3, 0)); return value; }  value = Rinternals.Rf_allocVector(14, 3); Ptr ptr81 = Rinternals2.REAL(value); double d98 = base__.Rf_dpptr(dd).getDouble(412); ptr81.setDouble(0, d98); Ptr ptr80 = Rinternals2.REAL(value); double d97 = base__.Rf_dpptr(dd).getDouble(420); ptr80.setDouble(8, d97); Ptr ptr79 = Rinternals2.REAL(value); double d96 = base__.Rf_dpptr(dd).getDouble(428); ptr79.setDouble(16, d96); return value; }  value = Rinternals.Rf_allocVector(14, 4); if (base__.Rf_gpptr(dd).getInt(440) == 0) { Ptr ptr80 = Rinternals2.REAL(value); double d97 = base__.Rf_dpptr(dd).getDouble(0 + 35700); ptr80.setDouble(0, d97); Ptr ptr79 = Rinternals2.REAL(value); double d96 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 8); ptr79.setDouble(8, d96); } else { Ptr ptr80 = Rinternals2.REAL(value); double d97 = base__.Rf_gpptr(dd).getDouble(0 + 35732); ptr80.setDouble(0, d97); Ptr ptr79 = Rinternals2.REAL(value); double d96 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 8); ptr79.setDouble(8, d96); }  if (base__.Rf_gpptr(dd).getInt(480) == 0) { Ptr ptr80 = Rinternals2.REAL(value); double d97 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 16); ptr80.setDouble(16, d97); Ptr ptr79 = Rinternals2.REAL(value); double d96 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 24); ptr79.setDouble(24, d96); return value; }  Ptr ptr78 = Rinternals2.REAL(value); double d95 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 16); ptr78.setDouble(16, d95); Ptr ptr77 = Rinternals2.REAL(value); double d94 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 24); ptr77.setDouble(24, d94); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr76 = Rinternals2.REAL(value); double d93 = base__.Rf_dpptr(dd).getDouble(404); ptr76.setDouble(0, d93); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr75 = Rinternals2.REAL(value); double d92 = base__.Rf_dpptr(dd).getDouble(396); ptr75.setDouble(0, d92); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr74 = Rinternals2.REAL(value); double d91 = base__.Rf_dpptr(dd).getDouble(388); ptr74.setDouble(0, d91); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr73 = Rinternals2.REAL(value); double d90 = base__.Rf_dpptr(dd).getInt(384); ptr73.setDouble(0, d90); return value; }  byte b2 = base__.Rf_dpptr(dd).getByte(0 + 35696); arrayOfByte4[0] = b2; arrayOfByte4[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte4, 0)); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr72 = Rinternals2.INTEGER(value); double d89 = base__.Rf_dpptr(dd).getDouble(376), d88 = base__.Rf_dpptr(dd).getDouble(0 + 35948); int i14 = (int)(d89 * d88); ptr72.setInt(0, i14); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr71 = Rinternals2.REAL(value); double d87 = base__.Rf_dpptr(dd).getDouble(0 + 35460); ptr71.setDouble(0, d87); Ptr ptr70 = Rinternals2.REAL(value); double d86 = base__.Rf_dpptr(dd).getDouble(0 + 35460 + 8); ptr70.setDouble(8, d86); Ptr ptr69 = Rinternals2.REAL(value); double d85 = base__.Rf_dpptr(dd).getDouble(0 + 35460 + 16); ptr69.setDouble(16, d85); Ptr ptr68 = Rinternals2.REAL(value); double d84 = base__.Rf_dpptr(dd).getDouble(0 + 35460 + 24); ptr68.setDouble(24, d84); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr67 = Rinternals2.REAL(value); double d83 = base__.Rf_dpptr(dd).getDouble(0 + 35492); ptr67.setDouble(0, d83); Ptr ptr66 = Rinternals2.REAL(value); double d82 = base__.Rf_dpptr(dd).getDouble(0 + 35492 + 8); ptr66.setDouble(8, d82); return value; }  val = base__.Rf_dpptr(dd).getInt(372); if (Defn.known_to_be_latin1 != 0 && val < -31 && val >= -255) val = -val;  if (val <= 31) { value = Rinternals.Rf_ScalarInteger(val); return value; }  if (Defn.mbcslocale == 0) { iftmp$20 = 255; } else { iftmp$20 = 127; }  if (iftmp$20 < val) { value = Rinternals.Rf_ScalarInteger(val); return value; }  byte b1 = (byte)val; arrayOfByte5[0] = b1; arrayOfByte5[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte5, 0)); return value; }  value = Rinternals.Rf_allocVector(10, 1); Rinternals.LOGICAL(value).setInt(0, 0); if (base__.Rf_dpptr(dd).getInt(0 + 35764) == 0) { int i15 = base__.Rf_dpptr(dd).getInt(568) + 1, i14 = base__.Rf_dpptr(dd).getInt(572); if (i15 > i14) Rinternals.LOGICAL(value).setInt(0, 1);  return value; }  if (base__.Rf_dpptr(dd).getInt() == 0) Rinternals.LOGICAL(value).setInt(0, 1);  return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr65 = Rinternals2.REAL(value); double d81 = base__.Rf_dpptr(dd).getDouble(0 + 35628); ptr65.setDouble(0, d81); Ptr ptr64 = Rinternals2.REAL(value); double d80 = base__.Rf_dpptr(dd).getDouble(0 + 35628 + 8); ptr64.setDouble(8, d80); Ptr ptr63 = Rinternals2.REAL(value); double d79 = base__.Rf_dpptr(dd).getDouble(0 + 35628 + 16); ptr63.setDouble(16, d79); Ptr ptr62 = Rinternals2.REAL(value); double d78 = base__.Rf_dpptr(dd).getDouble(0 + 35628 + 24); ptr62.setDouble(24, d78); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr61 = Rinternals2.REAL(value); double d77 = base__.Rf_dpptr(dd).getDouble(0 + 35660); ptr61.setDouble(0, d77); Ptr ptr60 = Rinternals2.REAL(value); double d76 = base__.Rf_dpptr(dd).getDouble(0 + 35660 + 8); ptr60.setDouble(8, d76); Ptr ptr59 = Rinternals2.REAL(value); double d75 = base__.Rf_dpptr(dd).getDouble(0 + 35660 + 16); ptr59.setDouble(16, d75); Ptr ptr58 = Rinternals2.REAL(value); double d74 = base__.Rf_dpptr(dd).getDouble(0 + 35660 + 24); ptr58.setDouble(24, d74); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr57 = Rinternals2.REAL(value); double d73 = base__.Rf_dpptr(dd).getDouble(0 + 35596); ptr57.setDouble(0, d73); Ptr ptr56 = Rinternals2.REAL(value); double d72 = base__.Rf_dpptr(dd).getDouble(0 + 35596 + 8); ptr56.setDouble(8, d72); Ptr ptr55 = Rinternals2.REAL(value); double d71 = base__.Rf_dpptr(dd).getDouble(0 + 35596 + 16); ptr55.setDouble(16, d71); Ptr ptr54 = Rinternals2.REAL(value); double d70 = base__.Rf_dpptr(dd).getDouble(0 + 35596 + 24); ptr54.setDouble(24, d70); return value; }  value = Rinternals.Rf_allocVector(10, 1); IntPtr intPtr2 = Rinternals.LOGICAL(value); int i13 = base__.Rf_dpptr(dd).getInt(0 + 35764); intPtr2.setInt(0, i13); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr53 = Rinternals2.REAL(value); double d69 = base__.Rf_dpptr(dd).getDouble(364); ptr53.setDouble(0, d69); return value; }  value = Rinternals.Rf_allocVector(14, 3); Ptr ptr52 = Rinternals2.REAL(value); double d68 = base__.Rf_dpptr(dd).getDouble(340); ptr52.setDouble(0, d68); Ptr ptr51 = Rinternals2.REAL(value); double d67 = base__.Rf_dpptr(dd).getDouble(348); ptr51.setDouble(8, d67); Ptr ptr50 = Rinternals2.REAL(value); double d66 = base__.Rf_dpptr(dd).getDouble(356); ptr50.setDouble(16, d66); return value; }  value = Rinternals.Rf_allocVector(13, 4); graphics__.Rf_currentFigureLocation((Ptr)new IntPtr(row, 0), (Ptr)new IntPtr(col, 0), dd); Ptr ptr49 = Rinternals2.INTEGER(value); int i12 = row[0] + 1; ptr49.setInt(0, i12); Ptr ptr48 = Rinternals2.INTEGER(value); int i11 = col[0] + 1; ptr48.setInt(4, i11); Ptr ptr47 = Rinternals2.INTEGER(value); int i10 = base__.Rf_dpptr(dd).getInt(560); ptr47.setInt(8, i10); Ptr ptr46 = Rinternals2.INTEGER(value); int i9 = base__.Rf_dpptr(dd).getInt(564); ptr46.setInt(12, i9); return value; }  value = Rinternals.Rf_allocVector(13, 2); Ptr ptr45 = Rinternals2.INTEGER(value); int i8 = base__.Rf_dpptr(dd).getInt(560); ptr45.setInt(0, i8); Ptr ptr44 = Rinternals2.INTEGER(value); int i7 = base__.Rf_dpptr(dd).getInt(564); ptr44.setInt(4, i7); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr43 = Rinternals2.REAL(value); double d65 = base__.Rf_dpptr(dd).getDouble(0 + 35588); ptr43.setDouble(0, d65); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr42 = Rinternals2.REAL(value); double d64 = base__.Rf_dpptr(dd).getDouble(0 + 35520); ptr42.setDouble(0, d64); Ptr ptr41 = Rinternals2.REAL(value); double d63 = base__.Rf_dpptr(dd).getDouble(0 + 35520 + 8); ptr41.setDouble(8, d63); Ptr ptr40 = Rinternals2.REAL(value); double d62 = base__.Rf_dpptr(dd).getDouble(0 + 35520 + 16); ptr40.setDouble(16, d62); Ptr ptr39 = Rinternals2.REAL(value); double d61 = base__.Rf_dpptr(dd).getDouble(0 + 35520 + 24); ptr39.setDouble(24, d61); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr38 = Rinternals2.REAL(value); double d60 = base__.Rf_dpptr(dd).getDouble(0 + 35552); ptr38.setDouble(0, d60); Ptr ptr37 = Rinternals2.REAL(value); double d59 = base__.Rf_dpptr(dd).getDouble(0 + 35552 + 8); ptr37.setDouble(8, d59); Ptr ptr36 = Rinternals2.REAL(value); double d58 = base__.Rf_dpptr(dd).getDouble(0 + 35552 + 16); ptr36.setDouble(16, d58); Ptr ptr35 = Rinternals2.REAL(value); double d57 = base__.Rf_dpptr(dd).getDouble(0 + 35552 + 24); ptr35.setDouble(24, d57); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr34 = Rinternals2.REAL(value); double d56 = base__.Rf_dpptr(dd).getDouble(316); ptr34.setDouble(0, d56); return value; }  value = baseEngine__.GE_LTYget(base__.Rf_dpptr(dd).getInt(312)); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr33 = Rinternals2.REAL(value); double d55 = base__.Rf_dpptr(dd).getDouble(332); ptr33.setDouble(0, d55); return value; }  value = baseEngine__.GE_LJOINget(base__.Rf_dpptr(dd).getInt(328)); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr32 = Rinternals2.REAL(value); double d54 = base__.Rf_dpptr(dd).getDouble(36); ptr32.setDouble(0, d54); return value; }  value = baseEngine__.GE_LENDget(base__.Rf_dpptr(dd).getInt(324)); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr31 = Rinternals2.INTEGER(value); int i6 = base__.Rf_dpptr(dd).getInt(308); ptr31.setInt(0, i6); return value; }  value = Rinternals.Rf_allocVector(13, 3); Ptr ptr30 = Rinternals2.INTEGER(value); int i5 = base__.Rf_dpptr(dd).getInt(296); ptr30.setInt(0, i5); Ptr ptr29 = Rinternals2.INTEGER(value); int i4 = base__.Rf_dpptr(dd).getInt(300); ptr29.setInt(4, i4); Ptr ptr28 = Rinternals2.INTEGER(value); int i3 = base__.Rf_dpptr(dd).getInt(304); ptr28.setInt(8, i3); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr27 = Rinternals2.INTEGER(value); int i2 = base__.Rf_dpptr(dd).getInt(536); ptr27.setInt(0, i2); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr26 = Rinternals2.INTEGER(value); int i1 = base__.Rf_dpptr(dd).getInt(532); ptr26.setInt(0, i1); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr25 = Rinternals2.INTEGER(value); int n = base__.Rf_dpptr(dd).getInt(528); ptr25.setInt(0, n); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr24 = Rinternals2.INTEGER(value); int m = base__.Rf_dpptr(dd).getInt(524); ptr24.setInt(0, m); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr23 = Rinternals2.INTEGER(value); int k = base__.Rf_dpptr(dd).getInt(284); ptr23.setInt(0, k); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr22 = Rinternals2.REAL(value); double d53 = base__.Rf_dpptr(dd).getDouble(0 + 35440); ptr22.setDouble(0, d53); Ptr ptr21 = Rinternals2.REAL(value); double d52 = base__.Rf_dpptr(dd).getDouble(0 + 35440 + 8); ptr21.setDouble(8, d52); return value; }  value = Rinternals.Rf_allocVector(14, 4); Ptr ptr20 = Rinternals2.REAL(value); double d51 = base__.Rf_dpptr(dd).getDouble(0 + 35408); ptr20.setDouble(0, d51); Ptr ptr19 = Rinternals2.REAL(value); double d50 = base__.Rf_dpptr(dd).getDouble(0 + 35408 + 8); ptr19.setDouble(8, d50); Ptr ptr18 = Rinternals2.REAL(value); double d49 = base__.Rf_dpptr(dd).getDouble(0 + 35408 + 16); ptr18.setDouble(16, d49); Ptr ptr17 = Rinternals2.REAL(value); double d48 = base__.Rf_dpptr(dd).getDouble(0 + 35408 + 24); ptr17.setDouble(24, d48); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(76))); return value; }  value = Rinternals.Rf_mkString(base__.Rf_dpptr(dd).pointerPlus(80)); return value; }  value = Rinternals.Rf_allocVector(13, 1); Ptr ptr16 = Rinternals2.INTEGER(value); int j = base__.Rf_dpptr(dd).getInt(72); ptr16.setInt(0, j); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr15 = Rinternals2.REAL(value); double d47 = graphics__.Rf_GConvertXUnits(1.0D, 1, 13, dd); ptr15.setDouble(0, d47); Ptr ptr14 = Rinternals2.REAL(value); double d46 = graphics__.Rf_GConvertYUnits(1.0D, 1, 13, dd); ptr14.setDouble(8, d46); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr13 = Rinternals2.REAL(value); double d45 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d44 = dd.getPointer().getDouble(104), d43 = d45 * d44; double d42 = dd.getPointer().getDouble(88), d41 = d43 * d42, d40 = base__.Rf_dpptr(dd).getDouble(0 + 35492), d39 = d41 / d40; double d38 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 8), d37 = base__.Rf_dpptr(dd).getDouble(0 + 35700), d36 = d38 - d37, d35 = d39 * d36; ptr13.setDouble(0, d35); Ptr ptr12 = Rinternals2.REAL(value); double d34 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d33 = dd.getPointer().getDouble(112), d32 = d34 * d33; double d31 = dd.getPointer().getDouble(96), d30 = d32 * d31, d29 = base__.Rf_dpptr(dd).getDouble(0 + 35492 + 8), d28 = d30 / d29; double d27 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 24), d26 = base__.Rf_dpptr(dd).getDouble(0 + 35700 + 16), d25 = d27 - d26, d24 = d28 * d25; ptr12.setDouble(8, d24); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr11 = Rinternals2.REAL(value); double d23 = graphics__.Rf_GConvertYUnits(1.0D, 15, 13, dd); ptr11.setDouble(0, d23); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr10 = Rinternals2.REAL(value); double d22 = base__.Rf_dpptr(dd).getDouble(48); ptr10.setDouble(0, d22); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr9 = Rinternals2.REAL(value); double d21 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d20 = dd.getPointer().getDouble(104), d19 = d21 * d20; ptr9.setDouble(0, d19); Ptr ptr8 = Rinternals2.REAL(value); double d18 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d17 = dd.getPointer().getDouble(112), d16 = d18 * d17; ptr8.setDouble(8, d16); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(552))); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(548))); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(544))); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(540))); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(44))); return value; }  value = Rinternals.Rf_allocVector(14, 2); Ptr ptr7 = Rinternals2.REAL(value); double d15 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d14 = dd.getPointer().getDouble(104), d13 = d15 * d14, d12 = dd.getPointer().getDouble(88), d11 = d13 * d12; ptr7.setDouble(0, d11); Ptr ptr6 = Rinternals2.REAL(value); double d10 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d9 = dd.getPointer().getDouble(112), d8 = d10 * d9, d7 = dd.getPointer().getDouble(96), d6 = d8 * d7; ptr6.setDouble(8, d6); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr5 = Rinternals2.REAL(value); double d5 = base__.Rf_dpptr(dd).getDouble(516); ptr5.setDouble(0, d5); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr4 = Rinternals2.REAL(value); double d4 = base__.Rf_dpptr(dd).getDouble(508); ptr4.setDouble(0, d4); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr3 = Rinternals2.REAL(value); double d3 = base__.Rf_dpptr(dd).getDouble(500); ptr3.setDouble(0, d3); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr2 = Rinternals2.REAL(value); double d2 = base__.Rf_dpptr(dd).getDouble(492); ptr2.setDouble(0, d2); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr1 = Rinternals2.REAL(value); double d1 = base__.Rf_dpptr(dd).getDouble(484); ptr1.setDouble(0, d1); return value; }  byte b = base__.Rf_dpptr(dd).getByte(24); arrayOfByte6[0] = b; arrayOfByte6[1] = (byte)0; value = Rinternals.Rf_mkString((Ptr)new BytePtr(arrayOfByte6, 0)); return value; }  value = Rinternals.Rf_mkString(colors__.Rf_col2name(base__.Rf_dpptr(dd).getInt(20))); return value; }  value = Rinternals.Rf_allocVector(10, 1); IntPtr intPtr1 = Rinternals.LOGICAL(value); int i = dd.getAlignedInt(31); intPtr1.setInt(0, i); return value; }  value = Rinternals.Rf_allocVector(10, 1); IntPtr intPtr = Rinternals.LOGICAL(value); boolean bool = (base__.Rf_dpptr(dd).getInt(16) == 0) ? false : true; intPtr.setInt(0, bool); return value; }  value = Rinternals.Rf_allocVector(14, 1); Ptr ptr = Rinternals2.REAL(value); double d = base__.Rf_dpptr(dd).getDouble(8); ptr.setDouble(0, d); return value; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_par(SEXP call, SEXP op, SEXP args, SEXP rho) {
/* 1076 */     newnames = (SEXP)BytePtr.of(0).getArray(); oldnames = (SEXP)BytePtr.of(0).getArray(); nargs = 0; new_spec = 0; dd = BytePtr.of(0); dd$offset = 0; originalArgs = (SEXP)BytePtr.of(0).getArray(); value = (SEXP)BytePtr.of(0).getArray(); originalArgs = args;
/*      */ 
/*      */ 
/*      */     
/* 1080 */     args = Rinternals.CDR(args);
/*      */     
/* 1082 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/* 1083 */     new_spec = 0;
/* 1084 */     args = Rinternals.CAR(args);
/* 1085 */     nargs = Rinternals.Rf_length(args);
/* 1086 */     if (!Rinternals.Rf_isNewList(args))
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1120 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid argument passed to par()\000".getBytes(), 0)), new Object[0]); } else { newnames = Rinternals.Rf_allocVector(16, nargs); Rinternals.Rf_protect(newnames); value = Rinternals.Rf_allocVector(19, nargs); Rinternals.Rf_protect(value); R_NamesSymbol$10 = Rinternals.R_NamesSymbol; oldnames = Rinternals.Rf_getAttrib(args, R_NamesSymbol$10); for (i = 0; i < nargs; i++) { R_NilValue$11 = Rinternals.R_NilValue; if (oldnames != R_NilValue$11) { tag = Rinternals.STRING_ELT(oldnames, i); } else { tag = Rinternals.R_NilValue; }  val = Rinternals.VECTOR_ELT(args, i); R_NilValue$12 = Rinternals.R_NilValue; if (tag == R_NilValue$12 || Rinternals.R_CHAR(tag).getByte() == (byte)0) { if (Rinternals.TYPEOF(val) != 16 || Rinternals.Rf_length(val) <= 0) { R_NilValue$14 = Rinternals.R_NilValue; Rinternals.SET_VECTOR_ELT(value, i, R_NilValue$14); R_BlankString$15 = Rinternals.R_BlankString; Rinternals.SET_STRING_ELT(newnames, i, R_BlankString$15); } else { tag = Rinternals.STRING_ELT(val, 0); R_NilValue$13 = Rinternals.R_NilValue; if (tag != R_NilValue$13 && Rinternals.R_CHAR(tag).getByte() != (byte)0) { SEXP sEXP = Query((Ptr)Rinternals.R_CHAR(tag), dd.pointerPlus(dd$offset)); Rinternals.SET_VECTOR_ELT(value, i, sEXP); Rinternals.SET_STRING_ELT(newnames, i, tag); }
/*      */              }
/*      */            }
/*      */         else { new_spec = 1; SEXP sEXP = Query((Ptr)Rinternals.R_CHAR(tag), dd.pointerPlus(dd$offset)); Rinternals.SET_VECTOR_ELT(value, i, sEXP); Rinternals.SET_STRING_ELT(newnames, i, tag); Specify((Ptr)Rinternals.R_CHAR(tag), val, dd.pointerPlus(dd$offset)); }
/*      */          }
/* 1125 */        R_NamesSymbol$16 = Rinternals.R_NamesSymbol; Rinternals.Rf_setAttrib(value, R_NamesSymbol$16, newnames); if (new_spec == 0)
/*      */       {
/*      */ 
/*      */         
/* 1129 */         return value; }  }  if (graphics__.GRecording(call, dd.pointerPlus(dd$offset)) != 0) baseEngine__.GErecordGraphicOperation(op, originalArgs, dd.pointerPlus(dd$offset));  return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_layout(SEXP args) {
/* 1156 */     dd = BytePtr.of(0); dd$offset = 0; ncmcol = 0; ncmrow = 0; ncol = 0; nrow = 0; args = Rinternals.CDR(args);
/*      */     
/* 1158 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */ 
/*      */     
/* 1161 */     Ptr ptr18 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr17 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1162 */     int i9 = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt(); ptr17.setInt(560, i9); int i8 = ptr17.getInt(560); ptr18.setInt(560, i8); nrow = ptr18.getInt(560);
/* 1163 */     if (nrow > 200)
/* 1164 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too many rows in layout, limit %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(200) }); 
/* 1165 */     args = Rinternals.CDR(args);
/*      */     
/* 1167 */     Ptr ptr16 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr15 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1168 */     int i7 = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt(); ptr15.setInt(564, i7); int i6 = ptr15.getInt(564); ptr16.setInt(564, i6); ncol = ptr16.getInt(564);
/* 1169 */     if (ncol > 200)
/* 1170 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too many columns in layout, limit %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(200) }); 
/* 1171 */     if (nrow * ncol > 10007)
/* 1172 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too many cells in layout, limit %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(10007) }); 
/* 1173 */     args = Rinternals.CDR(args);
/*      */     
/* 1175 */     for (i = 0; nrow * ncol > i; i++) {
/* 1176 */       Ptr ptr22 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1177 */       Ptr ptr20 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i11 = i * 4; Ptr ptr19 = ptr20; int i10 = 0 + i11; char c2 = (char)ptr19.getInt(i10); ptr21.setChar(5376 + i * 2, c2); char c1 = ptr21.getChar(5376 + i * 2); ptr22.setChar(5376 + i * 2, c1);
/* 1178 */     }  args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 1181 */     Ptr ptr14 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr13 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1182 */     Ptr ptr12 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr11 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1183 */     int i5 = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt(); ptr11.setInt(572, i5); int i4 = ptr11.getInt(572); ptr12.setInt(572, i4); int i3 = ptr12.getInt(572); ptr13.setInt(568, i3); int i2 = ptr13.getInt(568); ptr14.setInt(568, i2);
/* 1184 */     args = Rinternals.CDR(args);
/*      */     
/* 1186 */     for (j = 0; j < ncol; j++) {
/* 1187 */       Ptr ptr22 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1188 */       Ptr ptr20 = Rinternals2.REAL(Rinternals.CAR(args)); int i11 = j * 8; Ptr ptr19 = ptr20; int i10 = 0 + i11; double d4 = ptr19.getDouble(i10); ptr21.setDouble(2176 + j * 8, d4); double d3 = ptr21.getDouble(2176 + j * 8); ptr22.setDouble(2176 + j * 8, d3);
/* 1189 */     }  args = Rinternals.CDR(args);
/*      */     
/* 1191 */     for (i = 0; i < nrow; i++) {
/* 1192 */       Ptr ptr22 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1193 */       Ptr ptr20 = Rinternals2.REAL(Rinternals.CAR(args)); int i11 = i * 8; Ptr ptr19 = ptr20; int i10 = 0 + i11; double d4 = ptr19.getDouble(i10); ptr21.setDouble(576 + i * 8, d4); double d3 = ptr21.getDouble(576 + i * 8); ptr22.setDouble(576 + i * 8, d3);
/* 1194 */     }  args = Rinternals.CDR(args);
/*      */     
/* 1196 */     ncmcol = Rinternals.Rf_length(Rinternals.CAR(args));
/* 1197 */     for (j = 0; j < ncol; j++) {
/* 1198 */       Ptr ptr20 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr19 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr19.setInt(4576 + j * 4, 0); int i10 = ptr19.getInt(4576 + j * 4); ptr20.setInt(4576 + j * 4, i10);
/* 1199 */     }  for (j = 0; j < ncmcol; j++) {
/* 1200 */       Ptr ptr24 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr23 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i16 = j * 4; Ptr ptr22 = ptr23; int i15 = 0 + i16, i14 = ptr22.getInt(i15) + -1;
/* 1201 */       Ptr ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr20 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i13 = j * 4; Ptr ptr19 = ptr20; int i12 = 0 + i13, i11 = ptr19.getInt(i12) + -1;
/* 1202 */       ptr21.setInt(4576 + i11 * 4, 1); int i10 = ptr21.getInt(4576 + i11 * 4); ptr24.setInt(4576 + i14 * 4, i10);
/*      */     } 
/* 1204 */     args = Rinternals.CDR(args);
/*      */     
/* 1206 */     ncmrow = Rinternals.Rf_length(Rinternals.CAR(args));
/* 1207 */     for (i = 0; i < nrow; i++) {
/* 1208 */       Ptr ptr20 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr19 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr19.setInt(3776 + i * 4, 0); int i10 = ptr19.getInt(3776 + i * 4); ptr20.setInt(3776 + i * 4, i10);
/* 1209 */     }  for (i = 0; i < ncmrow; i++) {
/* 1210 */       Ptr ptr24 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr23 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i16 = i * 4; Ptr ptr22 = ptr23; int i15 = 0 + i16, i14 = ptr22.getInt(i15) + -1;
/* 1211 */       Ptr ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr20 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i13 = i * 4; Ptr ptr19 = ptr20; int i12 = 0 + i13, i11 = ptr19.getInt(i12) + -1;
/* 1212 */       ptr21.setInt(3776 + i11 * 4, 1); int i10 = ptr21.getInt(3776 + i11 * 4); ptr24.setInt(3776 + i14 * 4, i10);
/*      */     } 
/* 1214 */     args = Rinternals.CDR(args);
/*      */     
/* 1216 */     Ptr ptr10 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr9 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int i1 = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt(); ptr9.setInt(25392, i1); int n = ptr9.getInt(25392); ptr10.setInt(25392, n);
/* 1217 */     args = Rinternals.CDR(args);
/*      */     
/* 1219 */     for (i = 0; nrow * ncol > i; i++) {
/* 1220 */       Ptr ptr22 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/* 1221 */       Ptr ptr20 = Rinternals2.INTEGER(Rinternals.CAR(args)); int i13 = i * 4; Ptr ptr19 = ptr20; int i12 = 0 + i13, i11 = ptr19.getInt(i12) & 0xFF; ptr21.setByte(25396 + i, i11);
/*      */       int i10 = ptr21.getByte(25396 + i) & 0xFF;
/*      */       ptr22.setByte(25396 + i, i10);
/*      */     } 
/* 1225 */     if (nrow <= 2 && ncol <= 2)
/*      */     
/*      */     { 
/*      */       
/* 1229 */       if (nrow != 2 || ncol != 2)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 1234 */         Ptr ptr34 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr33 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr33.setDouble(484, 1.0D); double d6 = ptr33.getDouble(484); ptr34.setDouble(484, d6);
/* 1235 */         Ptr ptr32 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr31 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr31.setDouble(0 + 35588, 1.0D); double d5 = ptr31.getDouble(0 + 35588); ptr32.setDouble(0 + 35588, d5);
/*      */ 
/*      */         
/* 1238 */         Ptr ptr30 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr29 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr29.setInt(0 + 35512, 1); int i13 = ptr29.getInt(0 + 35512); ptr30.setInt(0 + 35512, i13);
/* 1239 */         Ptr ptr28 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr27 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr27.setInt(556, 1); int i12 = ptr27.getInt(556); ptr28.setInt(556, i12);
/*      */         
/* 1241 */         graphics__.Rf_GReset(dd.pointerPlus(dd$offset));
/*      */         
/* 1243 */         return Rinternals.R_NilValue; }  Ptr ptr26 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr25 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr25.setDouble(484, 0.83D); double d4 = ptr25.getDouble(484); ptr26.setDouble(484, d4); Ptr ptr24 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr23 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr23.setDouble(0 + 35588, 1.0D); double d3 = ptr23.getDouble(0 + 35588); ptr24.setDouble(0 + 35588, d3); Ptr ptr22 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr21 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr21.setInt(0 + 35512, 1); int i11 = ptr21.getInt(0 + 35512); ptr22.setInt(0 + 35512, i11); Ptr ptr20 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr19 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr19.setInt(556, 1); int i10 = ptr19.getInt(556); ptr20.setInt(556, i10); graphics__.Rf_GReset(dd.pointerPlus(dd$offset)); return Rinternals.R_NilValue; }  Ptr ptr8 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr7 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr7.setDouble(484, 0.66D); double d2 = ptr7.getDouble(484); ptr8.setDouble(484, d2); Ptr ptr6 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr5 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); ptr5.setDouble(0 + 35588, 1.0D); double d1 = ptr5.getDouble(0 + 35588); ptr6.setDouble(0 + 35588, d1); Ptr ptr4 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr3.setInt(0 + 35512, 1); int m = ptr3.getInt(0 + 35512); ptr4.setInt(0 + 35512, m); Ptr ptr2 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr1.setInt(556, 1); int k = ptr1.getInt(556); ptr2.setInt(556, k); graphics__.Rf_GReset(dd.pointerPlus(dd$offset)); return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_ProcessInlinePars(SEXP s, Ptr dd) {
/* 1252 */     if (Rinternals.Rf_isList(s))
/* 1253 */       while (true) { R_NilValue$1 = Rinternals.R_NilValue; if (s != R_NilValue$1) {
/* 1254 */           if (!Rinternals.Rf_isList(Rinternals.CAR(s)))
/*      */           
/* 1256 */           { SEXP sEXP = Rinternals.TAG(s); R_NilValue$0 = Rinternals.R_NilValue; if (sEXP != R_NilValue$0)
/* 1257 */             { SEXP sEXP1 = Rinternals.CAR(s); Specify2((Ptr)Rinternals.R_CHAR(Rinternals.PRINTNAME(Rinternals.TAG(s))), sEXP1, dd); }  } else { Rf_ProcessInlinePars(Rinternals.CAR(s), dd); }
/* 1258 */            s = Rinternals.CDR(s);
/*      */           continue;
/*      */         } 
/*      */         break; }
/*      */        
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/par__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */