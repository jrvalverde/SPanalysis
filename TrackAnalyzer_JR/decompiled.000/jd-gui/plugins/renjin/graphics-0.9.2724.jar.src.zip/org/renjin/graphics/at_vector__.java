/*     */ package org.renjin.graphics;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Mathlib;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.gnur.api.Rmath;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class at_vector__
/*     */ {
/*     */   public static SEXP Rf_CreateAtVector(Ptr axp, Ptr usr, int nint, int logflag) {
/*  45 */     reversed = 0; ne = 0; n = 0; i = 0; small = 0.0D; rng = 0.0D; dn = 0.0D; umax = 0.0D; umin = 0.0D; at = (SEXP)BytePtr.of(0).getArray(); at = Rinternals.R_NilValue;
/*     */ 
/*     */     
/*  48 */     if (logflag != 0 && axp.getDouble(16) >= 0.0D)
/*     */     { double d5, d6, d7, d8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  61 */       reversed = 0;
/*     */       
/*  63 */       n = (int)(axp.getDouble(16) + 0.5D);
/*     */ 
/*     */ 
/*     */       
/*  67 */       umin = usr.getDouble();
/*  68 */       umax = usr.getAlignedDouble(1);
/*  69 */       if (umin > umax) {
/*  70 */         double d10 = axp.getDouble(), d9 = axp.getDouble(8); reversed = (d10 <= d9) ? 0 : 1;
/*  71 */         if (reversed == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  81 */           Error.Rf_warning(new BytePtr("CreateAtVector \"log\"(from axis()): usr[0] = %g > %g = usr[1] !\000".getBytes(), 0), new Object[] { Double.valueOf(umin), Double.valueOf(umax) });
/*     */         } else {
/*     */           umin = usr.getAlignedDouble(1); umax = usr.getDouble(); dn = axp.getDouble(); double d = axp.getAlignedDouble(1); axp.setDouble(d); axp.setDouble(8, dn);
/*     */         } 
/*     */       } 
/*  86 */       umin *= 0.999999999999D;
/*  87 */       umax *= 1.000000000001D;
/*     */       
/*  89 */       dn = axp.getDouble();
/*  90 */       if (dn < 2.2250738585072014E-308D) {
/*  91 */         Error.Rf_warning(new BytePtr("CreateAtVector \"log\"(from axis()): axp[0] = %g !\000".getBytes(), 0), new Object[] { Double.valueOf(dn) });
/*  92 */         if (dn <= 0.0D) {
/*  93 */           Error.Rf_error(new BytePtr("CreateAtVector [log-axis()]: axp[0] = %g < 0!\000".getBytes(), 0), new Object[] { Double.valueOf(dn) });
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  99 */       switch (n) {
/*     */         case 1:
/* 101 */           d8 = Mathlib.floor(Mathlib.log10(axp.getDouble(8))); d7 = Mathlib.ceil(Mathlib.log10(axp.getDouble())); i = (int)(d8 - d7 + 0.25D);
/* 102 */           ne = i / nint + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 107 */           if (ne <= 0) {
/* 108 */             double d10 = 
/*     */ 
/*     */               
/* 111 */               axp.getDouble(8), d9 = axp.getDouble(); Error.Rf_error(new BytePtr("log - axis(), 'at' creation, _LARGE_ range: ne = %d <= 0 !!\n\t axp[0:1]=(%g,%g) ==> i = %d;\tnint = %d\000".getBytes(), 0), new Object[] { Integer.valueOf(ne), Double.valueOf(d9), Double.valueOf(d10), Integer.valueOf(i), Integer.valueOf(nint) });
/* 112 */           }  d6 = ne; rng = Mathlib.pow(10.0D, d6);
/* 113 */           n = 0;
/* 114 */           while (dn < umax) {
/* 115 */             n++;
/* 116 */             dn *= rng;
/*     */           } 
/* 118 */           if (n == 0) {
/* 119 */             double d10 = 
/*     */ 
/*     */               
/* 122 */               axp.getDouble(8), d9 = axp.getDouble(); Error.Rf_error(new BytePtr("log - axis(), 'at' creation, _LARGE_ range: invalid {xy}axp or par; nint=%d\n\t axp[0:1]=(%g,%g), usr[0:1]=(%g,%g); i=%d, ni=%d\000".getBytes(), 0), new Object[] { Integer.valueOf(nint), Double.valueOf(d9), Double.valueOf(d10), Double.valueOf(umin), Double.valueOf(umax), Integer.valueOf(i), Integer.valueOf(ne) });
/* 123 */           }  at = Rinternals.Rf_allocVector(14, n);
/* 124 */           dn = axp.getDouble();
/* 125 */           n = 0;
/* 126 */           while (dn < umax) {
/* 127 */             Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; ptr1.setDouble(k, dn); n++;
/* 128 */             dn *= rng;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 2:
/* 133 */           n = 0;
/* 134 */           if (dn * 0.5D >= umin) n++;
/*     */           
/* 136 */           while (dn <= umax) {
/* 137 */             n++;
/* 138 */             if (dn * 5.0D <= umax) {
/* 139 */               n++;
/* 140 */               dn *= 10.0D;
/*     */             } 
/* 142 */           }  if (n == 0) {
/* 143 */             double d = axp.getDouble(); Error.Rf_error(new BytePtr("log - axis(), 'at' creation, _MEDIUM_ range: invalid {xy}axp or par;\n\t axp[0]= %g, usr[0:1]=(%g,%g)\000".getBytes(), 0), new Object[] { Double.valueOf(d), Double.valueOf(umin), Double.valueOf(umax) });
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 148 */           at = Rinternals.Rf_allocVector(14, n);
/* 149 */           dn = axp.getDouble();
/* 150 */           n = 0;
/* 151 */           if (dn * 0.5D >= umin) { Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; double d = dn * 0.5D; ptr1.setDouble(k, d); n++; }
/*     */           
/* 153 */           while (dn <= umax) { Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; ptr1.setDouble(k, dn); n++;
/* 154 */             if (dn * 5.0D <= umax) { Ptr ptr4 = Rinternals2.REAL(at); int i2 = n * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d = dn * 5.0D; ptr3.setDouble(i1, d); n++;
/* 155 */               dn *= 10.0D; }
/*     */              }
/*     */           
/*     */           break;
/*     */         case 3:
/* 160 */           n = 0;
/* 161 */           if (dn * 0.2D >= umin) n++; 
/* 162 */           if (dn * 0.5D >= umin) n++;
/*     */           
/* 164 */           while (dn <= umax) {
/* 165 */             n++;
/* 166 */             if (dn * 2.0D <= umax) {
/* 167 */               n++;
/* 168 */               if (dn * 5.0D <= umax)
/* 169 */               { n++;
/* 170 */                 dn *= 10.0D; } 
/*     */             } 
/* 172 */           }  if (n == 0) {
/* 173 */             double d = axp.getDouble(); Error.Rf_error(new BytePtr("log - axis(), 'at' creation, _SMALL_ range: invalid {xy}axp or par;\n\t axp[0]= %g, usr[0:1]=(%g,%g)\000".getBytes(), 0), new Object[] { Double.valueOf(d), Double.valueOf(umin), Double.valueOf(umax) });
/*     */           } 
/*     */ 
/*     */           
/* 177 */           at = Rinternals.Rf_allocVector(14, n);
/* 178 */           dn = axp.getDouble();
/* 179 */           n = 0;
/* 180 */           if (dn * 0.2D >= umin) { Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; double d = dn * 0.2D; ptr1.setDouble(k, d); n++; }
/* 181 */            if (dn * 0.5D >= umin) { Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; double d = dn * 0.5D; ptr1.setDouble(k, d); n++; }
/*     */           
/* 183 */           while (dn <= umax) { Ptr ptr2 = Rinternals2.REAL(at); int m = n * 8; Ptr ptr1 = ptr2; int k = 0 + m; ptr1.setDouble(k, dn); n++;
/* 184 */             if (dn * 2.0D <= umax) { Ptr ptr4 = Rinternals2.REAL(at); int i2 = n * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d = dn * 2.0D; ptr3.setDouble(i1, d); n++;
/* 185 */               if (dn * 5.0D <= umax) { Ptr ptr6 = Rinternals2.REAL(at); int i4 = n * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; double d9 = dn * 5.0D; ptr5.setDouble(i3, d9); n++;
/* 186 */                 dn *= 10.0D; }  }
/*     */              }
/*     */            break;
/*     */         default:
/* 190 */           d5 = 
/* 191 */             axp.getDouble(16); Error.Rf_error(new BytePtr("log - axis(), 'at' creation: INVALID {xy}axp[3] = %g\000".getBytes(), 0), new Object[] { Double.valueOf(d5) });
/*     */           break;
/*     */       } 
/* 194 */       if (reversed != 0) {
/* 195 */         for (i = 0; n / 2 > i; i++) {
/* 196 */           Ptr ptr8 = Rinternals2.REAL(at); int i6 = i * 8; Ptr ptr7 = ptr8; int i5 = 0 + i6; dn = ptr7.getDouble(i5);
/* 197 */           Ptr ptr6 = Rinternals2.REAL(at); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; Ptr ptr4 = Rinternals2.REAL(at); int i2 = (n - i + -1) * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d = ptr3.getDouble(i1); ptr5.setDouble(i3, d);
/* 198 */           Ptr ptr2 = Rinternals2.REAL(at); int m = (n - i + -1) * 8; Ptr ptr1 = ptr2; int k = 0 + m; ptr1.setDouble(k, dn);
/*     */         } 
/*     */       }
/*     */       
/* 202 */       return at; }  n = (int)(Math.abs(axp.getDouble(16)) + 0.25D); dn = Rmath.Rf_imax2(1, n); double d4 = axp.getDouble(8), d3 = axp.getDouble(); rng = d4 - d3; double d2 = Math.abs(rng), d1 = dn * 100.0D; small = d2 / d1; int j = n + 1; at = Rinternals.Rf_allocVector(14, j); for (i = 0; i <= n; i++) { Ptr ptr4 = Rinternals2.REAL(at); int i2 = i * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d7 = axp.getDouble(), d6 = i / dn * rng, d5 = d7 + d6; ptr3.setDouble(i1, d5); Ptr ptr2 = Rinternals2.REAL(at); int m = i * 8; Ptr ptr1 = ptr2; int k = 0 + m; if (Math.abs(ptr1.getDouble(k)) < small) { Ptr ptr6 = Rinternals2.REAL(at); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; ptr5.setDouble(i3, 0.0D); }  }  return at;
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/at_vector__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */