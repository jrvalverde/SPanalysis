/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.Mathlib;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.PointerPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.VoidPtr;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.GetText;
/*      */ import org.renjin.gnur.api.Memory;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.gnur.api.Rmath;
/*      */ import org.renjin.grDevices.baseDevices__;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class plot3d__
/*      */ {
/*      */   public static void TypeCheck(SEXP s, int type) {
/*   36 */     if (Rinternals.TYPEOF(s) != type) {
/*   37 */       Error.Rf_error(new BytePtr("invalid type passed to graphics function\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ctr_intersect(double z0, double z1, double zc, Ptr f) {
/*   44 */     boolean bool2 = (z0 >= zc) ? false : true, bool1 = (z1 >= zc) ? false : true; if ((bool2 ^ bool1) == 0 || z0 == zc || z1 == zc)
/*      */     {
/*      */ 
/*      */       
/*   48 */       return 0; } 
/*      */     double d3 = zc - z0, d2 = z1 - z0, d1 = d3 / d2;
/*      */     f.setDouble(d1);
/*      */     return 1;
/*      */   } public static Ptr ctr_newseg(double x0, double y0, double x1, double y1, Ptr prev) {
/*   53 */     MixedPtr mixedPtr = MixedPtr.malloc(36);
/*   54 */     mixedPtr.setDouble(4, x0);
/*   55 */     mixedPtr.setDouble(12, y0);
/*   56 */     mixedPtr.setDouble(20, x1);
/*   57 */     mixedPtr.setDouble(28, y1);
/*   58 */     mixedPtr.setPointer(0, prev);
/*   59 */     return (Ptr)mixedPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void FindCutPoints(double low, double high, double x1, double y1, double z1, double x2, double y2, double z2, Ptr x, Ptr y, Ptr z, Ptr npt) {
/*      */     if (z1 <= z2)
/*   85 */     { if (z1 >= z2)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  125 */         if (low <= z1 && z1 <= high)
/*  126 */         { int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; ptr3.setDouble(i1, x1);
/*  127 */           int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1);
/*  128 */           int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; ptr1.setDouble(j, z1);
/*  129 */           int i = npt.getInt() + 1; npt.setInt(i); }  return; }  if (z2 >= low && z1 <= high) { if (z1 <= low) { R_NegInf$277 = Arith.R_NegInf; if (z1 != R_NegInf$277) { double d4 = z1 - low, d3 = z1 - z2; c = d4 / d3; int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; double d2 = (x2 - x1) * c + x1; ptr3.setDouble(i1, d2); int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1); int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; double d1 = (z2 - z1) * c + z1; ptr1.setDouble(j, d1); int i = npt.getInt() + 1; npt.setInt(i); } else { int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; ptr3.setDouble(i1, x2); int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1); int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; ptr1.setDouble(j, z2); int i = npt.getInt() + 1; npt.setInt(i); }  } else { int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; ptr3.setDouble(i1, x1); int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1); int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; ptr1.setDouble(j, z1); int i = npt.getInt() + 1; npt.setInt(i); }  if (z2 >= high) { R_PosInf$278 = Arith.R_PosInf; if (z2 != R_PosInf$278) { double d6 = z2 - high, d5 = z2 - z1; c = d6 / d5; int i9 = npt.getInt() * 8; Ptr ptr6 = x; int i8 = i9; double d4 = (x2 - x1) * c, d3 = x2 - d4; ptr6.setDouble(i8, d3); int i7 = npt.getInt() * 8; Ptr ptr5 = y; int i6 = i7; ptr5.setDouble(i6, y1); int i5 = npt.getInt() * 8; Ptr ptr4 = z; int i4 = i5; double d2 = (z2 - z1) * c, d1 = z2 - d2; ptr4.setDouble(i4, d1); int i3 = npt.getInt() + 1; npt.setInt(i3); return; }  int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; ptr3.setDouble(i1, x1); int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1); int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; ptr1.setDouble(j, z1); int i = npt.getInt() + 1; npt.setInt(i); }  }  return; }  if (z2 <= high && z1 >= low) { if (z1 >= high) { R_PosInf$275 = Arith.R_PosInf; if (z1 != R_PosInf$275) { double d4 = z1 - high, d3 = z1 - z2; c = d4 / d3; int i9 = npt.getInt() * 8; Ptr ptr6 = x; int i8 = i9; double d2 = (x2 - x1) * c + x1; ptr6.setDouble(i8, d2); int i7 = npt.getInt() * 8; Ptr ptr5 = y; int i6 = i7; ptr5.setDouble(i6, y1); int i5 = npt.getInt() * 8; Ptr ptr4 = z; int i4 = i5; double d1 = (z2 - z1) * c + z1; ptr4.setDouble(i4, d1); int i3 = npt.getInt() + 1; npt.setInt(i3); } else { int i9 = npt.getInt() * 8; Ptr ptr6 = x; int i8 = i9; ptr6.setDouble(i8, x2); int i7 = npt.getInt() * 8; Ptr ptr5 = y; int i6 = i7; ptr5.setDouble(i6, y1); int i5 = npt.getInt() * 8; Ptr ptr4 = z; int i4 = i5; ptr4.setDouble(i4, z2); int i3 = npt.getInt() + 1; npt.setInt(i3); }  } else { int i9 = npt.getInt() * 8; Ptr ptr6 = x; int i8 = i9; ptr6.setDouble(i8, x1); int i7 = npt.getInt() * 8; Ptr ptr5 = y; int i6 = i7; ptr5.setDouble(i6, y1); int i5 = npt.getInt() * 8; Ptr ptr4 = z; int i4 = i5; ptr4.setDouble(i4, z1); int i3 = npt.getInt() + 1; npt.setInt(i3); }  R_NegInf$276 = Arith.R_NegInf; if (z2 != R_NegInf$276) { if (z2 <= low) { double d6 = z2 - low, d5 = z2 - z1; c = d6 / d5; int i9 = npt.getInt() * 8; Ptr ptr6 = x; int i8 = i9; double d4 = (x2 - x1) * c, d3 = x2 - d4; ptr6.setDouble(i8, d3); int i7 = npt.getInt() * 8; Ptr ptr5 = y; int i6 = i7; ptr5.setDouble(i6, y1); int i5 = npt.getInt() * 8; Ptr ptr4 = z; int i4 = i5; double d2 = (z2 - z1) * c, d1 = z2 - d2; ptr4.setDouble(i4, d1); int i3 = npt.getInt() + 1; npt.setInt(i3); }  return; }  int i2 = npt.getInt() * 8; Ptr ptr3 = x; int i1 = i2; ptr3.setDouble(i1, x1); int n = npt.getInt() * 8; Ptr ptr2 = y; int m = n; ptr2.setDouble(m, y1); int k = npt.getInt() * 8; Ptr ptr1 = z; int j = k; ptr1.setDouble(j, z1); int i = npt.getInt() + 1; npt.setInt(i); } 
/*      */   }
/*  131 */   public static void ctr_swapseg(Ptr seg) { x = seg.getDouble(4); y = seg.getDouble(12); double d2 = seg.getDouble(20); seg.setDouble(4, d2); double d1 = seg.getDouble(28); seg.setDouble(12, d1); seg.setDouble(20, x); seg.setDouble(28, y); } public static int ctr_segdir(double xend, double yend, Ptr x, Ptr y, Ptr i, Ptr j, int nx, int ny) { int m = j.getInt() * 8; Ptr ptr = y; int k = m; double d = ptr.getDouble(k); if (yend - d != 0.0D) { int i1 = i.getInt() * 8; Ptr ptr1 = x; int n = i1; double d1 = ptr1.getDouble(n); if (xend - d1 != 0.0D) { int i5 = (j.getInt() + 1) * 8; Ptr ptr2 = y; int i4 = i5; double d2 = ptr2.getDouble(i4); if (yend - d2 != 0.0D) { int i9 = (i.getInt() + 1) * 8; Ptr ptr3 = x; int i8 = i9; double d3 = ptr3.getDouble(i8); if (xend - d3 != 0.0D) return 0;  int i7 = i.getInt(), i6 = nx + -1; if (i7 < i6) { int i10 = i.getInt() + 1; i.setInt(i10); return 2; }  return 0; }  int i3 = j.getInt(), i2 = ny + -1; if (i3 < i2) { int i6 = j.getInt() + 1; j.setInt(i6); return 1; }  return 0; }  if (i.getInt() != 0) { int i2 = i.getInt() + -1; i.setInt(i2); return 4; }  return 0; }  if (j.getInt() != 0) { int n = j.getInt() + -1; j.setInt(n); return 3; }  return 0; } public static Ptr ctr_segupdate(double xend, double yend, int dir, int tail, Ptr seglist, Ptr seg) { if (!seglist.isNull()) { double d1, d2; switch (dir) { case 1: case 3: d2 = seglist.getDouble(12); if (yend - d2 != 0.0D) { double d = seglist.getDouble(28); if (yend - d != 0.0D)
/*  132 */               break;  if (tail != 0)
/*  133 */               ctr_swapseg(seglist); 
/*  134 */             seg.setPointer(seglist);
/*  135 */             Ptr ptr4 = seglist.getPointer(); boolean bool2 = false; return ptr4.pointerPlus(bool2); }
/*      */            if (tail == 0)
/*      */             ctr_swapseg(seglist);  seg.setPointer(seglist); ptr3 = seglist.getPointer(); bool1 = false; return ptr3.pointerPlus(bool1);
/*      */         case 2:
/*      */         case 4:
/*  140 */           d1 = seglist.getDouble(4); if (xend - d1 != 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  146 */             double d = seglist.getDouble(20); if (xend - d != 0.0D)
/*  147 */               break;  if (tail != 0)
/*  148 */               ctr_swapseg(seglist); 
/*  149 */             seg.setPointer(seglist);
/*  150 */             ptr3 = seglist.getPointer(); bool1 = false; return ptr3.pointerPlus(bool1);
/*      */           }  if (tail == 0)
/*      */             ctr_swapseg(seglist);  seg.setPointer(seglist); ptr3 = seglist.getPointer(); bool1 = false; return ptr3.pointerPlus(bool1); }
/*      */       
/*  154 */       Ptr ptr2 = seglist.getPointer(), ptr1 = ctr_segupdate(xend, yend, dir, tail, ptr2, seg); seglist.setPointer(ptr1);
/*  155 */       Ptr ptr3 = seglist; boolean bool1 = false; return ptr3.pointerPlus(bool1); }  seg.setPointer(BytePtr.of(0)); Ptr ptr = BytePtr.of(0); boolean bool = false; return ptr.pointerPlus(bool); } public static void FindPolygonVertices(double low, double high, double x1, double x2, double y1, double y2, double z11, double z21, double z12, double z22, Ptr x, Ptr y, Ptr z, Ptr npt) { npt.setInt(0); FindCutPoints(low, high, x1, y1, z11, x2, y1, z21, x, y, z, npt); FindCutPoints(low, high, y1, x2, z21, y2, x2, z22, y, x, z, npt); FindCutPoints(low, high, x2, y2, z22, x1, y2, z12, x, y, z, npt);
/*  156 */     FindCutPoints(low, high, y2, x1, z12, y1, x1, z11, y, x, z, npt); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_filledcontour(SEXP args) {
/*  167 */     pz = new double[8]; py = new double[8]; px = new double[8]; npt = new int[1]; dd = BytePtr.of(0); dd$offset = 0; xpdsave = 0; colsave = 0; ncol = 0; nc = 0; ny = 0; nx = 0; npt[0] = 0; j = 0; i = 0; col = BytePtr.of(0); col$offset = 0; c = BytePtr.of(0); c$offset = 0; z = BytePtr.of(0); z$offset = 0; y = BytePtr.of(0); y$offset = 0; x = BytePtr.of(0); x$offset = 0; SEXP sEXP = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */     
/*  169 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/*  171 */     Defn.Rf_PrintDefaults();
/*      */     
/*  173 */     args = Rinternals.CDR(args);
/*  174 */     sx = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/*  175 */     nx = Rinternals.LENGTH(sx);
/*  176 */     args = Rinternals.CDR(args);
/*      */     
/*  178 */     sy = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/*  179 */     ny = Rinternals.LENGTH(sy);
/*  180 */     args = Rinternals.CDR(args);
/*  181 */     if (nx <= 1 || ny <= 1) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("insufficient 'x' or 'y' values\000".getBytes(), 0)), new Object[0]);
/*      */ 
/*      */     
/*  184 */     sz = Rinternals.CAR(args);
/*  185 */     if (Rinternals.Rf_nrows(sz) != nx || Rinternals.Rf_ncols(sz) != ny) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("dimension mismatch\000".getBytes(), 0)), new Object[0]); 
/*  186 */     sz = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(sz, 14));
/*  187 */     args = Rinternals.CDR(args);
/*      */     
/*  189 */     sc = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/*  190 */     nc = Rinternals.Rf_length(sc);
/*  191 */     args = Rinternals.CDR(args);
/*      */     
/*  193 */     if (nc <= 0) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("no contour values\000".getBytes(), 0)), new Object[0]);
/*      */     
/*  195 */     scol = plot__.Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(scol);
/*  196 */     ncol = Rinternals.Rf_length(scol);
/*      */ 
/*      */ 
/*      */     
/*  200 */     x = Rinternals2.REAL(sx); x$offset = 0;
/*  201 */     y = Rinternals2.REAL(sy); y$offset = 0;
/*  202 */     z = Rinternals2.REAL(sz); z$offset = 0;
/*  203 */     c = Rinternals2.REAL(sc); c$offset = 0;
/*  204 */     col = Rinternals2.INTEGER(scol); col$offset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  210 */     if (nx > 0 && ny > 0 && 
/*  211 */       Arith.R_finite(x.getDouble(x$offset)) != 0 && 
/*  212 */       Arith.R_finite(y.getDouble(y$offset)) != 0) {
/*  213 */       for (i = 1; i < nx; ) {
/*  214 */         int n = i * 8; Ptr ptr = x; int m = x$offset + n; if (Arith.R_finite(ptr.getDouble(m)) != 0) { int i4 = i * 8; Ptr ptr2 = x; int i3 = x$offset + i4; double d2 = ptr2.getDouble(i3); int i2 = (i + -1) * 8; Ptr ptr1 = x; int i1 = x$offset + i2; double d1 = ptr1.getDouble(i1); if (d2 > d1) { i++; continue; }  // Byte code: goto -> 1641 }  // Byte code: goto -> 1641
/*  215 */       }  for (j = 1; j < ny; ) {
/*  216 */         int n = j * 8; Ptr ptr = y; int m = y$offset + n; if (Arith.R_finite(ptr.getDouble(m)) != 0) { int i4 = j * 8; Ptr ptr2 = y; int i3 = y$offset + i4; double d2 = ptr2.getDouble(i3); int i2 = (j + -1) * 8; Ptr ptr1 = y; int i1 = y$offset + i2; double d1 = ptr1.getDouble(i1); if (d2 > d1) {
/*      */             j++; continue;
/*      */           }  // Byte code: goto -> 1641 }
/*      */          // Byte code: goto -> 1641
/*  220 */       }  if (Arith.R_finite(c.getDouble(c$offset)) != 0) {
/*  221 */         for (k = 1; k < nc; ) {
/*  222 */           int n = k * 8; Ptr ptr1 = c; int m = c$offset + n; if (Arith.R_finite(ptr1.getDouble(m)) != 0) { int i4 = k * 8; Ptr ptr3 = c; int i3 = c$offset + i4; double d2 = ptr3.getDouble(i3); int i2 = (k + -1) * 8; Ptr ptr2 = c; int i1 = c$offset + i2; double d1 = ptr2.getDouble(i1); if (d2 > d1) { k++; continue; }  // Byte code: goto -> 1681 }
/*      */            // Byte code: goto -> 1681
/*  224 */         }  colsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(44);
/*  225 */         xpdsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444);
/*      */         
/*  227 */         base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 0);
/*      */         
/*  229 */         graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/*      */         
/*  231 */         for (i = 1; i < nx; i++) {
/*  232 */           for (j = 1; j < ny; j++) {
/*  233 */             for (k = 1; k < nc; k++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  240 */               int i22 = (j * nx + i) * 8; Ptr ptr10 = z; int i21 = z$offset + i22; double d9 = ptr10.getDouble(i21); int i20 = i + -1, i19 = j * nx, i18 = (i20 + i19) * 8; Ptr ptr9 = z; int i17 = z$offset + i18; double d8 = ptr9.getDouble(i17); int i16 = ((j + -1) * nx + i) * 8; Ptr ptr8 = z; int i15 = z$offset + i16; double d7 = ptr8.getDouble(i15); int i14 = (i + -1) * 8, i13 = (j + -1) * 8 * nx, i12 = i14 + i13; Ptr ptr7 = z; int i11 = z$offset + i12; double d6 = ptr7.getDouble(i11); int i10 = j * 8; Ptr ptr6 = y; int i9 = y$offset + i10; double d5 = ptr6.getDouble(i9); int i8 = (j + -1) * 8; Ptr ptr5 = y; int i7 = y$offset + i8; double d4 = ptr5.getDouble(i7); int i6 = i * 8; Ptr ptr4 = x; int i5 = x$offset + i6; double d3 = ptr4.getDouble(i5); int i4 = (i + -1) * 8; Ptr ptr3 = x; int i3 = x$offset + i4; double d2 = ptr3.getDouble(i3); int i2 = k * 8; Ptr ptr2 = c; int i1 = c$offset + i2; double d1 = ptr2.getDouble(i1); int n = (k + -1) * 8; Ptr ptr1 = c; int m = c$offset + n;
/*      */               FindPolygonVertices(ptr1.getDouble(m), d1, d2, d3, d4, d5, d6, d7, d8, d9, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), (Ptr)new DoublePtr(pz, 0), (Ptr)new IntPtr(npt, 0));
/*  242 */               if (npt[0] > 2) {
/*  243 */                 int i25 = (k + -1) % ncol * 4; Ptr ptr11 = col; int i24 = col$offset + i25, i23 = ptr11.getInt(i24); graphics__.Rf_GPolygon(npt[0], (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), 12, i23, 16777215, dd.pointerPlus(dd$offset));
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  248 */         graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*  249 */         Ptr ptr = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); colsave$274 = colsave; ptr.setInt(44, colsave$274);
/*  250 */         base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, xpdsave);
/*      */         
/*  252 */         return Rinternals.R_NilValue;
/*      */       } 
/*      */     } else {
/*  255 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid x / y values or limits\000".getBytes(), 0)), new Object[0]);
/*      */     } 
/*  257 */     Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid contour levels: must be strictly increasing\000".getBytes(), 0)), new Object[0]); return sEXP; } public static Ptr contourLines(Ptr x, int nx, Ptr y, int ny, Ptr z, double zc, double atom) { yy = new double[4]; xx = new double[4]; f = new double[1]; segmentDB = BytePtr.of(0); segmentDB$offset = 0; seglist = BytePtr.of(0); seglist$offset = 0; m = 0; k = 0; j = 0; i = 0; xh = 0.0D; xl = 0.0D; f[0] = 0.0D; PointerPtr pointerPtr1 = PointerPtr.malloc(nx * ny * 4); segmentDB$offset = 0; for (i = 0; i < nx; i++) { for (j = 0; j < ny; j++) { int i2 = (j * nx + i) * 4; PointerPtr pointerPtr = pointerPtr1; int i1 = segmentDB$offset + i2; pointerPtr.setPointer(i1, BytePtr.of(0)); }  }  for (i = 0; nx + -1 > i; i++) { int i4 = i * 8; Ptr ptr2 = x; int i3 = i4; xl = ptr2.getDouble(i3); int i2 = (i + 1) * 8; Ptr ptr1 = x; int i1 = i2; xh = ptr1.getDouble(i1); for (j = 0; ny + -1 > j; j++) { double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18; int i18 = j * 8; Ptr ptr8 = y; int i17 = i18; yl = ptr8.getDouble(i17); int i16 = (j + 1) * 8; Ptr ptr7 = y; int i15 = i16; yh = ptr7.getDouble(i15); k = j * nx + i; int i14 = k * 8; Ptr ptr6 = z; int i13 = i14; zll = ptr6.getDouble(i13); int i12 = (k + 1) * 8; Ptr ptr5 = z; int i11 = i12; zhl = ptr5.getDouble(i11); int i10 = (k + nx) * 8; Ptr ptr4 = z; int i9 = i10; zlh = ptr4.getDouble(i9); int i8 = (k + nx + 1) * 8; Ptr ptr3 = z; int i7 = i8; zhh = ptr3.getDouble(i7); if (zll == zc) zll += atom;  if (zhl == zc) zhl += atom;  if (zlh == zc) zlh += atom;  if (zhh == zc) zhh += atom;  nacode = 0; if (Arith.R_finite(zll) != 0) nacode++;  if (Arith.R_finite(zhl) != 0) nacode += 2;  if (Arith.R_finite(zlh) != 0) nacode += 4;  if (Arith.R_finite(zhh) != 0) nacode += 8;  k = 0; switch (nacode) { case 15: if (ctr_intersect(zll, zhl, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = xh - xl; f$134 = f[0]; double d19 = d20 * f$134 + xl; xx[k] = d19; yy[k] = yl; k++; }  if (ctr_intersect(zll, zlh, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = yh - yl; f$135 = f[0]; double d19 = d20 * f$135 + yl; yy[k] = d19; xx[k] = xl; k++; }  if (ctr_intersect(zhl, zhh, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = yh - yl; f$136 = f[0]; double d19 = d20 * f$136 + yl; yy[k] = d19; xx[k] = xh; k++; }  if (ctr_intersect(zlh, zhh, zc, (Ptr)new DoublePtr(f, 0)) == 0) break;  d18 = xh - xl; f$137 = f[0]; d17 = d18 * f$137 + xl; xx[k] = d17; yy[k] = yh; k++; break;case 14: if (ctr_intersect(zhl, zhh, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = yh - yl; f$138 = f[0]; double d19 = d20 * f$138 + yl; yy[k] = d19; xx[k] = xh; k++; }  if (ctr_intersect(zlh, zhh, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = xh - xl; f$139 = f[0]; double d19 = d20 * f$139 + xl; xx[k] = d19; yy[k] = yh; k++; }  if (ctr_intersect(zlh, zhl, zc, (Ptr)new DoublePtr(f, 0)) == 0) break;  d16 = xh - xl; f$140 = f[0]; d15 = d16 * f$140 + xl; xx[k] = d15; d14 = yl - yh; f$141 = f[0]; d13 = d14 * f$141 + yh; yy[k] = d13; k++; break;case 13: if (ctr_intersect(zll, zlh, zc, (Ptr)new DoublePtr(f, 0)) != 0) { double d20 = yh - yl; f$142 = f[0]; double d19 = d20 * f$142 + yl; yy[k] = d19; xx[k] = xl; k++; }  if (ctr_intersect(zlh, zhh, zc, (Ptr)new DoublePtr(f, 0)) != 0) {
/*  258 */               double d20 = xh - xl; f$143 = f[0]; double d19 = d20 * f$143 + xl; xx[k] = d19;
/*  259 */               yy[k] = yh; k++;
/*      */             } 
/*  261 */             if (ctr_intersect(zll, zhh, zc, (Ptr)new DoublePtr(f, 0)) == 0)
/*  262 */               break;  d12 = xh - xl; f$144 = f[0]; d11 = d12 * f$144 + xl; xx[k] = d11;
/*  263 */             d10 = yh - yl; f$145 = f[0]; d9 = d10 * f$145 + yl; yy[k] = d9;
/*  264 */             k++;
/*      */             break;
/*      */           
/*      */           case 11:
/*  268 */             if (ctr_intersect(zhl, zhh, zc, (Ptr)new DoublePtr(f, 0)) != 0) {
/*  269 */               double d20 = yh - yl; f$146 = f[0]; double d19 = d20 * f$146 + yl; yy[k] = d19;
/*  270 */               xx[k] = xh; k++;
/*      */             } 
/*  272 */             if (ctr_intersect(zll, zhl, zc, (Ptr)new DoublePtr(f, 0)) != 0) {
/*  273 */               double d20 = xh - xl; f$147 = f[0]; double d19 = d20 * f$147 + xl; xx[k] = d19;
/*  274 */               yy[k] = yl; k++;
/*      */             } 
/*  276 */             if (ctr_intersect(zll, zhh, zc, (Ptr)new DoublePtr(f, 0)) == 0)
/*  277 */               break;  d8 = xh - xl; f$148 = f[0]; d7 = d8 * f$148 + xl; xx[k] = d7;
/*  278 */             d6 = yh - yl; f$149 = f[0]; d5 = d6 * f$149 + yl; yy[k] = d5;
/*  279 */             k++;
/*      */             break;
/*      */           
/*      */           case 7:
/*  283 */             if (ctr_intersect(zll, zlh, zc, (Ptr)new DoublePtr(f, 0)) != 0) {
/*  284 */               double d20 = yh - yl; f$150 = f[0]; double d19 = d20 * f$150 + yl; yy[k] = d19;
/*  285 */               xx[k] = xl; k++;
/*      */             } 
/*  287 */             if (ctr_intersect(zll, zhl, zc, (Ptr)new DoublePtr(f, 0)) != 0) {
/*  288 */               double d20 = xh - xl; f$151 = f[0]; double d19 = d20 * f$151 + xl; xx[k] = d19;
/*  289 */               yy[k] = yl; k++;
/*      */             } 
/*  291 */             if (ctr_intersect(zlh, zhl, zc, (Ptr)new DoublePtr(f, 0)) == 0)
/*  292 */               break;  d4 = xh - xl; f$152 = f[0]; d3 = d4 * f$152 + xl; xx[k] = d3;
/*  293 */             d2 = yl - yh; f$153 = f[0]; d1 = d2 * f$153 + yh; yy[k] = d1;
/*  294 */             k++;
/*      */             break; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  302 */         seglist = BytePtr.of(0); seglist$offset = 0;
/*      */         
/*  304 */         if (k > 0)
/*  305 */           if (k != 2)
/*      */           
/*      */           { 
/*  308 */             if (k != 4)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  330 */               Error.Rf_error(new BytePtr("k = %d, should be 2 or 4\000".getBytes(), 0), new Object[] { Integer.valueOf(k) }); } else { for (k = 3; k > 0; k--) { m = k; xl = xx[k]; for (l = 0; l < k; l++) { if (xx[l] > xl) { xl = xx[l]; m = l; }  }  if (m != k) { xl = xx[k]; yl = yy[k]; double d26 = xx[m]; xx[k] = d26; double d25 = yy[m]; yy[k] = d25; xx[m] = xl; yy[m] = yl; }  }  double d24 = yy[1], d23 = xx[1], d22 = yy[0]; seglist = ctr_newseg(xx[0], d22, d23, d24, seglist.pointerPlus(seglist$offset)); seglist$offset = 0; double d21 = yy[3], d20 = xx[3], d19 = yy[2]; seglist = ctr_newseg(xx[2], d19, d20, d21, seglist.pointerPlus(seglist$offset)); seglist$offset = 0; }  }
/*      */           else { double d21 = yy[1], d20 = xx[1], d19 = yy[0]; seglist = ctr_newseg(xx[0], d19, d20, d21, seglist.pointerPlus(seglist$offset)); seglist$offset = 0; }
/*  332 */             int i6 = (j * nx + i) * 4; PointerPtr pointerPtr = pointerPtr1; int i5 = segmentDB$offset + i6; pointerPtr.setPointer(i5, seglist.pointerPlus(seglist$offset)); }
/*      */        }
/*      */     
/*  335 */     PointerPtr pointerPtr2 = pointerPtr1; int n = segmentDB$offset; return pointerPtr2.pointerPlus(n); }
/*      */   public static SEXP C_image(SEXP args) { dd = BytePtr.of(0); dd$offset = 0; colsave = 0; xpdsave = 0; nc = 0; ny = 0; nx = 0; i = 0; c = BytePtr.of(0); c$offset = 0; z = BytePtr.of(0); z$offset = 0; y = BytePtr.of(0); y$offset = 0; x = BytePtr.of(0); x$offset = 0; dd = baseDevices__.GEcurrentDevice(); dd$offset = 0; graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset)); args = Rinternals.CDR(args); sx = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14)); nx = Rinternals.LENGTH(sx); args = Rinternals.CDR(args); sy = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14)); ny = Rinternals.LENGTH(sy); args = Rinternals.CDR(args); sz = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 13)); args = Rinternals.CDR(args); sc = plot__.Rf_FixupCol(Rinternals.CAR(args), 16777215); Rinternals.Rf_protect(sc); nc = Rinternals.LENGTH(sc); x = Rinternals2.REAL(sx); x$offset = 0; y = Rinternals2.REAL(sy); y$offset = 0; z = Rinternals2.INTEGER(sz); z$offset = 0; c = Rinternals2.INTEGER(sc); c$offset = 0; colsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(44); xpdsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 0); graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset)); for (i = 0; nx + -1 > i; i++) {
/*      */       for (j = 0; ny + -1 > j; j++) {
/*      */         int m = ((nx + -1) * j + i) * 4; Ptr ptr = z; int k = z$offset + m; tmp = ptr.getInt(k); if (tmp >= 0 && tmp < nc) {
/*      */           R_NaInt$251 = Arith.R_NaInt; if (tmp != R_NaInt$251) {
/*      */             int i10 = tmp * 4; Ptr ptr5 = c; int i9 = c$offset + i10, i8 = ptr5.getInt(i9), i7 = (j + 1) * 8; Ptr ptr4 = y; int i6 = y$offset + i7; double d3 = ptr4.getDouble(i6); int i5 = (i + 1) * 8; Ptr ptr3 = x; int i4 = x$offset + i5; double d2 = ptr3.getDouble(i4); int i3 = j * 8; Ptr ptr2 = y; int i2 = y$offset + i3; double d1 = ptr2.getDouble(i2); int i1 = i * 8; Ptr ptr1 = x; int n = x$offset + i1; graphics__.Rf_GRect(ptr1.getDouble(n), d1, d2, d3, 12, i8, 16777215, dd.pointerPlus(dd$offset));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }  graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */     base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(44, colsave);
/*      */     base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, xpdsave);
/*  347 */     return Rinternals.R_NilValue; } public static void TransVector(Ptr u, Ptr T, Ptr v) { for (i = 0, i = 0; i <= 3; i++) {
/*  348 */       sum = 0.0D;
/*  349 */       for (j = 0; j <= 3; j++) {
/*  350 */         int i3 = j * 8; Ptr ptr2 = u; int i2 = i3; double d2 = ptr2.getDouble(i2); int i1 = j * 32; Ptr ptr1 = T; int n = i1; double d1 = ptr1.getDouble(n + i * 8); sum = d2 * d1 + sum;
/*  351 */       }  int m = i * 8; Ptr ptr = v; int k = m; ptr.setDouble(k, sum);
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Accumulate(Ptr T) {
/*  361 */     for (U = new double[16], j = 0, i = 0, i = 0; i <= 3; i++) {
/*  362 */       for (j = 0; j <= 3; j++) {
/*  363 */         sum = 0.0D;
/*  364 */         for (k = 0; k <= 3; k++) {
/*  365 */           double d2 = Context.get__plot3d$VT()[i * 4 + k]; int n = k * 32; Ptr ptr = T; int m = n; double d1 = ptr.getDouble(m + j * 8); sum = d2 * d1 + sum;
/*  366 */         }  U[i * 4 + j] = sum;
/*      */       } 
/*      */     } 
/*  369 */     for (i = 0; i <= 3; i++) {
/*  370 */       for (j = 0; j <= 3; j++) {
/*  371 */         double d = U[i * 4 + j]; Context.get__plot3d$VT()[i * 4 + j] = d;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void SetToIdentity(Ptr T) {
/*  377 */     for (i = 0, i = 0; i <= 3; i++) {
/*  378 */       for (j = 0; j <= 3; j++) {
/*  379 */         int i1 = i * 32; Ptr ptr1 = T; int n = i1; ptr1.setDouble(n + j * 8, 0.0D);
/*  380 */       }  int m = i * 32; Ptr ptr = T; int k = m; ptr.setDouble(k + i * 8, 1.0D);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Translate(double x, double y, double z) {
/*  387 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  388 */     T[12] = x;
/*  389 */     T[13] = y;
/*  390 */     T[14] = z;
/*  391 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Scale(double x, double y, double z) {
/*  397 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  398 */     T[0] = x;
/*  399 */     T[5] = y;
/*  400 */     T[10] = z;
/*  401 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void XRotate(double angle) {
/*  408 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  409 */     c = Mathlib.cos(angle * 0.017453292519943295D);
/*  410 */     s = Mathlib.sin(angle * 0.017453292519943295D);
/*  411 */     T[5] = c;
/*  412 */     double d = -s; T[9] = d;
/*  413 */     T[10] = c;
/*  414 */     T[6] = s;
/*  415 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void YRotate(double angle) {
/*  422 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  423 */     c = Mathlib.cos(angle * 0.017453292519943295D);
/*  424 */     s = Mathlib.sin(angle * 0.017453292519943295D);
/*  425 */     T[0] = c;
/*  426 */     T[8] = s;
/*  427 */     T[10] = c;
/*  428 */     double d = -s; T[2] = d;
/*  429 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void ZRotate(double angle) {
/*  436 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  437 */     c = Mathlib.cos(angle * 0.017453292519943295D);
/*  438 */     s = Mathlib.sin(angle * 0.017453292519943295D);
/*  439 */     T[0] = c;
/*  440 */     double d = -s; T[4] = d;
/*  441 */     T[5] = c;
/*  442 */     T[1] = s;
/*  443 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Perspective(double d) {
/*  450 */     T = new double[16]; SetToIdentity((Ptr)new DoublePtr(T, 0));
/*  451 */     double d1 = -1.0D / d; T[11] = d1;
/*  452 */     Accumulate((Ptr)new DoublePtr(T, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void SetUpLight(double theta, double phi) {
/*  464 */     u = new double[4]; u[0] = 0.0D; u[1] = -1.0D; u[2] = 0.0D; u[3] = 1.0D;
/*  465 */     SetToIdentity((Ptr)new DoublePtr(Context.get__plot3d$VT(), 0));
/*  466 */     XRotate(-phi);
/*  467 */     ZRotate(theta);
/*  468 */     TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(Context.get__plot3d$Light(), 0));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double FacetShade(Ptr u, Ptr v) {
/*  474 */     double d26 = u.getDouble(8), d25 = v.getDouble(16), d24 = d26 * d25, d23 = u.getDouble(16), d22 = v.getDouble(8), d21 = d23 * d22; nx = d24 - d21;
/*  475 */     double d20 = u.getDouble(16), d19 = v.getDouble(), d18 = d20 * d19, d17 = u.getDouble(), d16 = v.getDouble(16), d15 = d17 * d16; ny = d18 - d15;
/*  476 */     double d14 = u.getDouble(), d13 = v.getDouble(8), d12 = d14 * d13, d11 = u.getDouble(8), d10 = v.getDouble(), d9 = d11 * d10; nz = d12 - d9;
/*  477 */     double d8 = nx * nx, d7 = ny * ny, d6 = d8 + d7, d5 = nz * nz; sum = Mathlib.sqrt(d6 + d5);
/*  478 */     if (sum == 0.0D) sum = 1.0D; 
/*  479 */     nx /= sum;
/*  480 */     ny /= sum;
/*  481 */     nz /= sum;
/*  482 */     double d4 = Context.get__plot3d$Light()[0] * nx, d3 = Context.get__plot3d$Light()[1] * ny, d2 = d4 + d3, d1 = Context.get__plot3d$Light()[2] * nz; sum = (d2 + d1 + 1.0D) * 0.5D;
/*  483 */     Shade$244 = Context.get__plot3d$Shade(); return Mathlib.pow(sum, Shade$244);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void DepthOrder(Ptr z, Ptr x, Ptr y, int nx, int ny, Ptr depth, Ptr indx) {
/*  498 */     v = new double[4]; u = new double[4]; d = 0.0D; ny1 = 0; nx1 = 0; j = 0; ii = 0; i = 0; nx1 = nx + -1;
/*  499 */     ny1 = ny + -1;
/*  500 */     for (i = 0; nx1 * ny1 > i; i++) {
/*  501 */       int n = i * 4; Ptr ptr = indx; int m = n; ptr.setInt(m, i);
/*  502 */     }  for (i = 0; i < nx1; i++) {
/*  503 */       for (j = 0; j < ny1; j++) {
/*  504 */         d = -1.7976931348623157E308D;
/*  505 */         for (ii = 0; ii <= 1; ii++) {
/*  506 */           for (jj = 0; jj <= 1; jj++) {
/*  507 */             int i4 = (i + ii) * 8; Ptr ptr2 = x; int i3 = i4; double d3 = ptr2.getDouble(i3); u[0] = d3;
/*  508 */             int i2 = (j + jj) * 8; Ptr ptr1 = y; int i1 = i2; double d2 = ptr1.getDouble(i1); u[1] = d2;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  513 */             u[2] = 0.0D;
/*  514 */             u[3] = 1.0D;
/*  515 */             if (Arith.R_finite(u[0]) != 0 && Arith.R_finite(u[1]) != 0 && Arith.R_finite(u[2]) != 0) {
/*  516 */               TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  517 */               if (v[3] > d) d = v[3]; 
/*      */             } 
/*      */           } 
/*  520 */         }  int n = (j * nx1 + i) * 8; Ptr ptr = depth; int m = n; double d1 = -d; ptr.setDouble(m, d1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  525 */     int k = nx1 * ny1; sort__.rsort_with_index(depth, indx, k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void DrawFacets(Ptr z, Ptr x, Ptr y, int nx, int ny, Ptr indx, double xs, double ys, double zs, Ptr col, int ncol, int border) {
/*  533 */     v = new double[4]; u = new double[4]; yy = new double[4]; xx = new double[4]; dd = BytePtr.of(0); dd$offset = 0; nx1 = 0; n = 0; shade = 0.0D; shade = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  538 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*  539 */     nx1 = nx + -1;
/*  540 */     ny1 = ny + -1;
/*  541 */     n = nx1 * ny1;
/*  542 */     for (k = 0; k < n; k++) {
/*  543 */       nv = 0;
/*  544 */       int i31 = k * 4; Ptr ptr14 = indx; int i30 = i31; i = ptr14.getInt(i30) % nx1;
/*  545 */       int i29 = k * 4; Ptr ptr13 = indx; int i28 = i29; j = ptr13.getInt(i28) / nx1;
/*  546 */       icol = (j * nx1 + i) % ncol;
/*  547 */       if (Context.get__plot3d$DoLighting() != 0) {
/*      */         
/*  549 */         int i59 = (i + 1) * 8; Ptr ptr26 = x; int i58 = i59; double d30 = ptr26.getDouble(i58); int i57 = i * 8; Ptr ptr25 = x; int i56 = i57; double d29 = ptr25.getDouble(i56), d28 = (d30 - d29) * xs; u[0] = d28;
/*  550 */         int i55 = j * 8; Ptr ptr24 = y; int i54 = i55; double d27 = ptr24.getDouble(i54); int i53 = (j + 1) * 8; Ptr ptr23 = y; int i52 = i53; double d26 = ptr23.getDouble(i52), d25 = (d27 - d26) * ys; u[1] = d25;
/*  551 */         int i51 = i + 1, i50 = j * nx, i49 = (i51 + i50) * 8; Ptr ptr22 = z; int i48 = i49; double d24 = ptr22.getDouble(i48); int i47 = ((j + 1) * nx + i) * 8; Ptr ptr21 = z; int i46 = i47; double d23 = ptr21.getDouble(i46), d22 = (d24 - d23) * zs; u[2] = d22;
/*  552 */         int i45 = (i + 1) * 8; Ptr ptr20 = x; int i44 = i45; double d21 = ptr20.getDouble(i44); int i43 = i * 8; Ptr ptr19 = x; int i42 = i43; double d20 = ptr19.getDouble(i42), d19 = (d21 - d20) * xs; v[0] = d19;
/*  553 */         int i41 = (j + 1) * 8; Ptr ptr18 = y; int i40 = i41; double d18 = ptr18.getDouble(i40); int i39 = j * 8; Ptr ptr17 = y; int i38 = i39; double d17 = ptr17.getDouble(i38), d16 = (d18 - d17) * ys; v[1] = d16;
/*  554 */         int i37 = (i + 1) * 8, i36 = (j + 1) * 8 * nx, i35 = i37 + i36; Ptr ptr16 = z; int i34 = i35; double d15 = ptr16.getDouble(i34); int i33 = (j * nx + i) * 8; Ptr ptr15 = z; int i32 = i33; double d14 = ptr15.getDouble(i32), d13 = (d15 - d14) * zs; v[2] = d13;
/*  555 */         shade = FacetShade((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(v, 0));
/*      */       } 
/*  557 */       int i27 = i * 8; Ptr ptr12 = x; int i26 = i27; double d12 = ptr12.getDouble(i26); u[0] = d12; int i25 = j * 8; Ptr ptr11 = y; int i24 = i25; double d11 = ptr11.getDouble(i24); u[1] = d11;
/*  558 */       int i23 = (j * nx + i) * 8; Ptr ptr10 = z; int i22 = i23; double d10 = ptr10.getDouble(i22); u[2] = d10; u[3] = 1.0D;
/*  559 */       if (Arith.R_finite(u[0]) != 0 && Arith.R_finite(u[1]) != 0 && Arith.R_finite(u[2]) != 0) {
/*  560 */         TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  561 */         double d18 = v[0], d17 = v[3], d16 = d18 / d17; xx[nv] = d16;
/*  562 */         double d15 = v[1], d14 = v[3], d13 = d15 / d14; yy[nv] = d13;
/*  563 */         nv++;
/*      */       } 
/*      */       
/*  566 */       int i21 = (i + 1) * 8; Ptr ptr9 = x; int i20 = i21; double d9 = ptr9.getDouble(i20); u[0] = d9; int i19 = j * 8; Ptr ptr8 = y; int i18 = i19; double d8 = ptr8.getDouble(i18); u[1] = d8;
/*  567 */       int i17 = i + 1, i16 = j * nx, i15 = (i17 + i16) * 8; Ptr ptr7 = z; int i14 = i15; double d7 = ptr7.getDouble(i14); u[2] = d7; u[3] = 1.0D;
/*  568 */       if (Arith.R_finite(u[0]) != 0 && Arith.R_finite(u[1]) != 0 && Arith.R_finite(u[2]) != 0) {
/*  569 */         TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  570 */         double d18 = v[0], d17 = v[3], d16 = d18 / d17; xx[nv] = d16;
/*  571 */         double d15 = v[1], d14 = v[3], d13 = d15 / d14; yy[nv] = d13;
/*  572 */         nv++;
/*      */       } 
/*      */       
/*  575 */       int i13 = (i + 1) * 8; Ptr ptr6 = x; int i12 = i13; double d6 = ptr6.getDouble(i12); u[0] = d6; int i11 = (j + 1) * 8; Ptr ptr5 = y; int i10 = i11; double d5 = ptr5.getDouble(i10); u[1] = d5;
/*  576 */       int i9 = (i + 1) * 8, i8 = (j + 1) * 8 * nx, i7 = i9 + i8; Ptr ptr4 = z; int i6 = i7; double d4 = ptr4.getDouble(i6); u[2] = d4; u[3] = 1.0D;
/*  577 */       if (Arith.R_finite(u[0]) != 0 && Arith.R_finite(u[1]) != 0 && Arith.R_finite(u[2]) != 0) {
/*  578 */         TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  579 */         double d18 = v[0], d17 = v[3], d16 = d18 / d17; xx[nv] = d16;
/*  580 */         double d15 = v[1], d14 = v[3], d13 = d15 / d14; yy[nv] = d13;
/*  581 */         nv++;
/*      */       } 
/*      */       
/*  584 */       int i5 = i * 8; Ptr ptr3 = x; int i4 = i5; double d3 = ptr3.getDouble(i4); u[0] = d3; int i3 = (j + 1) * 8; Ptr ptr2 = y; int i2 = i3; double d2 = ptr2.getDouble(i2); u[1] = d2;
/*  585 */       int i1 = ((j + 1) * nx + i) * 8; Ptr ptr1 = z; int m = i1; double d1 = ptr1.getDouble(m); u[2] = d1; u[3] = 1.0D;
/*  586 */       if (Arith.R_finite(u[0]) != 0 && Arith.R_finite(u[1]) != 0 && Arith.R_finite(u[2]) != 0) {
/*  587 */         TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  588 */         double d18 = v[0], d17 = v[3], d16 = d18 / d17; xx[nv] = d16;
/*  589 */         double d15 = v[1], d14 = v[3], d13 = d15 / d14; yy[nv] = d13;
/*  590 */         nv++;
/*      */       } 
/*      */       
/*  593 */       if (nv > 2) {
/*  594 */         int i33 = icol * 4; Ptr ptr = col; int i32 = i33; newcol = ptr.getInt(i32);
/*  595 */         if (Context.get__plot3d$DoLighting() == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  605 */           newcol$242 = newcol; graphics__.Rf_GPolygon(nv, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), 12, newcol$242, border, dd.pointerPlus(dd$offset));
/*      */         } else if (Arith.R_finite(shade) != 0) {
/*      */           r = (int)(Integer.toUnsignedLong(newcol & 0xFF) * shade);
/*      */           g = (int)(Integer.toUnsignedLong(newcol >>> 8 & 0xFF) * shade);
/*      */           b = (int)(Integer.toUnsignedLong(newcol >>> 16 & 0xFF) * shade);
/*      */           int i35 = g << 8 | r, i34 = b << 16;
/*      */           newcol = i35 | i34 | 0xFF000000;
/*      */           newcol$241 = newcol;
/*      */           graphics__.Rf_GPolygon(nv, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), 12, newcol$241, border, dd.pointerPlus(dd$offset));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } public static void PerspWindow(Ptr xlim, Ptr ylim, Ptr zlim, Ptr dd) {
/*  618 */     v = new double[4]; u = new double[4]; j = 0; i = 0; ymin = 0.0D; ymax = 0.0D; xmin = 0.0D; xmax = 0.0D; xmax = xmin = ymax = ymin = 0.0D;
/*  619 */     u[3] = 1.0D;
/*  620 */     for (i = 0; i <= 1; i++) {
/*  621 */       int n = i * 8; Ptr ptr = xlim; int m = n; double d = ptr.getDouble(m); u[0] = d;
/*  622 */       for (j = 0; j <= 1; j++) {
/*  623 */         int i2 = j * 8; Ptr ptr1 = ylim; int i1 = i2; double d3 = ptr1.getDouble(i1); u[1] = d3;
/*  624 */         for (k = 0; k <= 1; k++) {
/*  625 */           int i4 = k * 8; Ptr ptr2 = zlim; int i3 = i4; double d8 = ptr2.getDouble(i3); u[2] = d8;
/*  626 */           TransVector((Ptr)new DoublePtr(u, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v, 0));
/*  627 */           double d7 = v[0], d6 = v[3]; xx = d7 / d6;
/*  628 */           double d5 = v[1], d4 = v[3]; yy = d5 / d4;
/*  629 */           if (xx > xmax) xmax = xx; 
/*  630 */           if (xx < xmin) xmin = xx; 
/*  631 */           if (yy > ymax) ymax = yy; 
/*  632 */           if (yy < ymin) ymin = yy; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  636 */     pin1 = graphics__.Rf_GConvertXUnits(1.0D, 16, 13, dd);
/*  637 */     pin2 = graphics__.Rf_GConvertYUnits(1.0D, 16, 13, dd);
/*  638 */     xdelta = Math.abs(xmax - xmin);
/*  639 */     ydelta = Math.abs(ymax - ymin);
/*  640 */     xscale = pin1 / xdelta;
/*  641 */     yscale = pin2 / ydelta;
/*  642 */     if (xscale >= yscale) { iftmp$219 = yscale; } else { iftmp$219 = xscale; }  scale = iftmp$219;
/*  643 */     xadd = (pin1 / scale - xdelta) * 0.5D;
/*  644 */     yadd = (pin2 / scale - ydelta) * 0.5D;
/*  645 */     double d2 = xmax + xadd; graphics__.Rf_GScale(xmin - xadd, d2, 1, dd);
/*  646 */     double d1 = ymax + yadd; graphics__.Rf_GScale(ymin - yadd, d1, 2, dd);
/*  647 */     graphics__.Rf_GMapWin2Fig(dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int LimitCheck(Ptr lim, Ptr c, Ptr s) {
/*  652 */     if (Arith.R_finite(lim.getDouble()) != 0 && Arith.R_finite(lim.getDouble(8)) != 0) { double d2 = lim.getDouble(), d1 = lim.getDouble(8); if (d2 < d1) {
/*      */         
/*  654 */         double d8 = lim.getDouble(8), d7 = lim.getDouble(), d6 = Math.abs(d8 - d7) * 0.5D; s.setDouble(d6);
/*  655 */         double d5 = lim.getDouble(8), d4 = lim.getDouble(), d3 = (d5 + d4) * 0.5D; c.setDouble(d3);
/*  656 */         return 1;
/*      */       }  }
/*      */     
/*      */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void PerspBox(int front, Ptr x, Ptr y, Ptr z, Ptr EdgeDone, Ptr dd) {
/*  711 */     e = new double[3]; d = new double[3]; v3 = new double[4]; u3 = new double[4]; v2 = new double[4]; u2 = new double[4]; v1 = new double[4]; u1 = new double[4]; v0 = new double[4]; u0 = new double[4]; ltysave = 0; f = 0; ltysave = base__.Rf_gpptr(dd).getInt(312);
/*      */     
/*  713 */     Ptr ptr = base__.Rf_gpptr(dd); if (front == 0) { iftmp$215 = 0; } else { iftmp$215 = 49; }  ptr.setInt(312, iftmp$215);
/*      */     
/*  715 */     for (f = 0; f <= 5; f++) {
/*  716 */       p0 = Context.get__plot3d$Face()[f * 4];
/*  717 */       p1 = Context.get__plot3d$Face()[f * 4 + 1];
/*  718 */       p2 = Context.get__plot3d$Face()[f * 4 + 2];
/*  719 */       p3 = Context.get__plot3d$Face()[f * 4 + 3];
/*      */       
/*  721 */       int i20 = Context.get__plot3d$Vertex()[p0 * 3] * 8; Ptr ptr12 = x; int i19 = i20; double d18 = ptr12.getDouble(i19); u0[0] = d18;
/*  722 */       int i18 = Context.get__plot3d$Vertex()[p0 * 3 + 1] * 8; Ptr ptr11 = y; int i17 = i18; double d17 = ptr11.getDouble(i17); u0[1] = d17;
/*  723 */       int i16 = Context.get__plot3d$Vertex()[p0 * 3 + 2] * 8; Ptr ptr10 = z; int i15 = i16; double d16 = ptr10.getDouble(i15); u0[2] = d16;
/*  724 */       u0[3] = 1.0D;
/*  725 */       int i14 = Context.get__plot3d$Vertex()[p1 * 3] * 8; Ptr ptr9 = x; int i13 = i14; double d15 = ptr9.getDouble(i13); u1[0] = d15;
/*  726 */       int i12 = Context.get__plot3d$Vertex()[p1 * 3 + 1] * 8; Ptr ptr8 = y; int i11 = i12; double d14 = ptr8.getDouble(i11); u1[1] = d14;
/*  727 */       int i10 = Context.get__plot3d$Vertex()[p1 * 3 + 2] * 8; Ptr ptr7 = z; int i9 = i10; double d13 = ptr7.getDouble(i9); u1[2] = d13;
/*  728 */       u1[3] = 1.0D;
/*  729 */       int i8 = Context.get__plot3d$Vertex()[p2 * 3] * 8; Ptr ptr6 = x; int i7 = i8; double d12 = ptr6.getDouble(i7); u2[0] = d12;
/*  730 */       int i6 = Context.get__plot3d$Vertex()[p2 * 3 + 1] * 8; Ptr ptr5 = y; int i5 = i6; double d11 = ptr5.getDouble(i5); u2[1] = d11;
/*  731 */       int i4 = Context.get__plot3d$Vertex()[p2 * 3 + 2] * 8; Ptr ptr4 = z; int i3 = i4; double d10 = ptr4.getDouble(i3); u2[2] = d10;
/*  732 */       u2[3] = 1.0D;
/*  733 */       int i2 = Context.get__plot3d$Vertex()[p3 * 3] * 8; Ptr ptr3 = x; int i1 = i2; double d9 = ptr3.getDouble(i1); u3[0] = d9;
/*  734 */       int n = Context.get__plot3d$Vertex()[p3 * 3 + 1] * 8; Ptr ptr2 = y; int m = n; double d8 = ptr2.getDouble(m); u3[1] = d8;
/*  735 */       int k = Context.get__plot3d$Vertex()[p3 * 3 + 2] * 8; Ptr ptr1 = z; int j = k; double d7 = ptr1.getDouble(j); u3[2] = d7;
/*  736 */       u3[3] = 1.0D;
/*      */       
/*  738 */       TransVector((Ptr)new DoublePtr(u0, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v0, 0));
/*  739 */       TransVector((Ptr)new DoublePtr(u1, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v1, 0));
/*  740 */       TransVector((Ptr)new DoublePtr(u2, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v2, 0));
/*  741 */       TransVector((Ptr)new DoublePtr(u3, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v3, 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  747 */       for (i = 0; i <= 2; i++) {
/*  748 */         double d32 = v1[i], d31 = v1[3], d30 = d32 / d31, d29 = v0[i], d28 = v0[3], d27 = d29 / d28, d26 = d30 - d27; d[i] = d26;
/*  749 */         double d25 = v2[i], d24 = v2[3], d23 = d25 / d24, d22 = v1[i], d21 = v1[3], d20 = d22 / d21, d19 = d23 - d20; e[i] = d19;
/*      */       } 
/*  751 */       double d6 = d[0], d5 = e[1], d4 = d6 * d5, d3 = d[1], d2 = e[0], d1 = d3 * d2; nearby = (d4 - d1 >= 0.0D) ? 0 : 1;
/*      */       
/*  753 */       if ((front != 0 && nearby != 0) || (front == 0 && nearby == 0)) {
/*  754 */         short s8 = Context.get__plot3d$Edge()[f * 4]; Ptr ptr16 = EdgeDone; short s7 = s8; byte b8 = ptr16.getByte(s7); boolean bool4 = (b8 != (byte)0) ? false : true; byte b7 = (byte)(b8 + (byte)1); ptr16.setByte(s7, b7); if (bool4) {
/*      */           
/*  756 */           double d29 = v1[1], d28 = v1[3]; double d27 = d29 / d28; double d26 = v1[0], d25 = v1[3]; double d24 = d26 / d25, d23 = v0[1], d22 = v0[3], d21 = d23 / d22, d20 = v0[0], d19 = v0[3]; graphics__.Rf_GLine(d20 / d19, d21, d24, d27, 12, dd);
/*  757 */         }  short s6 = Context.get__plot3d$Edge()[f * 4 + 1]; Ptr ptr15 = EdgeDone; short s5 = s6; byte b6 = ptr15.getByte(s5); boolean bool3 = (b6 != (byte)0) ? false : true; byte b5 = (byte)(b6 + (byte)1); ptr15.setByte(s5, b5); if (bool3) {
/*      */           
/*  759 */           double d29 = v2[1], d28 = v2[3]; double d27 = d29 / d28; double d26 = v2[0], d25 = v2[3]; double d24 = d26 / d25, d23 = v1[1], d22 = v1[3], d21 = d23 / d22, d20 = v1[0], d19 = v1[3]; graphics__.Rf_GLine(d20 / d19, d21, d24, d27, 12, dd);
/*  760 */         }  short s4 = Context.get__plot3d$Edge()[f * 4 + 2]; Ptr ptr14 = EdgeDone; short s3 = s4; byte b4 = ptr14.getByte(s3); boolean bool2 = (b4 != (byte)0) ? false : true; byte b3 = (byte)(b4 + (byte)1); ptr14.setByte(s3, b3); if (bool2) {
/*      */           
/*  762 */           double d29 = v3[1], d28 = v3[3]; double d27 = d29 / d28; double d26 = v3[0], d25 = v3[3]; double d24 = d26 / d25, d23 = v2[1], d22 = v2[3], d21 = d23 / d22, d20 = v2[0], d19 = v2[3]; graphics__.Rf_GLine(d20 / d19, d21, d24, d27, 12, dd);
/*  763 */         }  short s2 = Context.get__plot3d$Edge()[f * 4 + 3]; Ptr ptr13 = EdgeDone; short s1 = s2; byte b2 = ptr13.getByte(s1); boolean bool1 = (b2 != (byte)0) ? false : true; byte b1 = (byte)(b2 + (byte)1); ptr13.setByte(s1, b1); if (bool1) {
/*      */           
/*  765 */           double d29 = v0[1], d28 = v0[3]; double d27 = d29 / d28; double d26 = v0[0], d25 = v0[3]; double d24 = d26 / d25, d23 = v3[1], d22 = v3[3], d21 = d23 / d22, d20 = v3[0], d19 = v3[3]; graphics__.Rf_GLine(d20 / d19, d21, d24, d27, 12, dd);
/*      */         } 
/*      */       } 
/*  768 */     }  base__.Rf_gpptr(dd).setInt(312, ltysave);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lowest(double y1, double y2, double y3, double y4) {
/*  789 */     return (y1 > y2 || y1 > y3 || y1 > y4) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double labelAngle(double x1, double y1, double x2, double y2) {
/*  795 */     dx = Math.abs(x2 - x1);
/*  796 */     if (x2 <= x1)
/*      */     
/*      */     { 
/*  799 */       dy = y1 - y2; } else { dy = y2 - y1; }
/*  800 */      if (dx != 0.0D)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  809 */       angle = Mathlib.atan2(dy, dx) * 57.29577951308232D;
/*      */ 
/*      */       
/*  812 */       return angle; }  if (dy <= 0.0D) { angle = 270.0D; return angle; }  angle = 90.0D; return angle; } public static void PerspAxis(Ptr x, Ptr y, Ptr z, int axis, int axisType, int nTicks, int tickType, Ptr label, int enc, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d35, d36, d37, d38, d39, d40, d41, d42, d43, d44, d45, d46, d47, d48, d49, d50, d51, d52, d53, d54, d55, d56, d57, d58, d59, d60, d61, d62, d63, d64, d65, d66, d67, d68, d69, d70, d71, d72, d73, d74, d75, d76, d77, d78, d79, d80, d81, d82, d83, d84, d85, d86, d87, d88, d89, d90, d91, d113; Ptr ptr5; int m, n; short s1; double d114; Ptr ptr6; int i1, i2; short s2; double d115; Ptr ptr7; int i3, i4; short s3; double d116; Ptr ptr8; int i5, i6; short s4; double d117; Ptr ptr9;
/*      */     int i7, i8;
/*      */     short s5;
/*      */     double d118;
/*      */     Ptr ptr10;
/*      */     int i9, i10;
/*      */     short s6;
/*  819 */     nint = new int[1]; axp = new double[3]; max = new double[1]; min = new double[1]; v3 = new double[4]; v2 = new double[4]; v1 = new double[4]; u3 = new double[4]; u2 = new double[4]; u1 = new double[4]; fontsave = 0; cexsave = 0.0D; lab = (SEXP)BytePtr.of(0).getArray(); at = (SEXP)BytePtr.of(0).getArray(); range = BytePtr.of(0); range$offset = 0; d_frac = 0.0D; max[0] = 0.0D; min[0] = 0.0D; tickLength = 0.0D; u1[0] = 0.0D; u1[1] = 0.0D; u1[2] = 0.0D; u1[3] = 0.0D; u2[0] = 0.0D; u2[1] = 0.0D; u2[2] = 0.0D; u2[3] = 0.0D; u3[0] = 0.0D; u3[1] = 0.0D; u3[2] = 0.0D; u3[3] = 0.0D;
/*  820 */     tickLength = 0.03D;
/*      */     
/*  822 */     range = BytePtr.of(0); range$offset = 0;
/*      */ 
/*      */ 
/*      */     
/*  826 */     cexsave = base__.Rf_gpptr(dd).getDouble(28);
/*  827 */     fontsave = base__.Rf_gpptr(dd).getInt(284);
/*      */ 
/*      */     
/*  830 */     switch (axisType) {
/*      */       case 0:
/*  832 */         min$180 = x.getDouble(); min[0] = min$180; max$181 = x.getAlignedDouble(1); max[0] = max$181; range = x; range$offset = 0; break;
/*      */       case 1:
/*  834 */         min$182 = y.getDouble(); min[0] = min$182; max$183 = y.getAlignedDouble(1); max[0] = max$183; range = y; range$offset = 0; break;
/*      */       case 2:
/*  836 */         min$184 = z.getDouble(); min[0] = min$184; max$185 = z.getAlignedDouble(1); max[0] = max$185; range = z; range$offset = 0; break;
/*      */     } 
/*  838 */     max$186 = max[0]; min$187 = min[0]; d_frac = (max$186 - min$187) * 0.1D;
/*  839 */     nint$188 = nTicks + -1; nint[0] = nint$188; if (nint[0] == 0) { nint$191 = nint[0] + 1; nint[0] = nint$191; }
/*  840 */      i = nint[0];
/*  841 */     graphics__.Rf_GPretty((Ptr)new DoublePtr(min, 0), (Ptr)new DoublePtr(max, 0), (Ptr)new IntPtr(nint, 0));
/*      */     
/*      */     while (true) {
/*  844 */       double d = range.getDouble(range$offset) - d_frac; min$194 = min[0]; if (d <= min$194) { Ptr ptr = range; int i11 = range$offset + 8; double d120 = ptr.getDouble(i11) + d_frac; max$195 = max[0]; if (d120 >= max$195) break;  }  if (i > 19)
/*  845 */         break;  nint[0] = ++i;
/*  846 */       min$192 = range.getDouble(range$offset); min[0] = min$192;
/*  847 */       max$193 = range.getDouble(range$offset + 8); max[0] = max$193;
/*  848 */       graphics__.Rf_GPretty((Ptr)new DoublePtr(min, 0), (Ptr)new DoublePtr(max, 0), (Ptr)new IntPtr(nint, 0));
/*      */     } 
/*  850 */     min$196 = min[0]; axp[0] = min$196;
/*  851 */     max$197 = max[0]; axp[1] = max$197;
/*  852 */     double d119 = nint[0]; axp[2] = d119;
/*      */     
/*  854 */     switch (axisType) {
/*      */       case 0:
/*  856 */         min$199 = min[0]; u1[0] = min$199;
/*  857 */         s6 = Context.get__plot3d$AxisStart()[axis]; i10 = Context.get__plot3d$Vertex()[s6 * 3 + 1] * 8; ptr10 = y; i9 = i10; d118 = ptr10.getDouble(i9); u1[1] = d118;
/*  858 */         s5 = Context.get__plot3d$AxisStart()[axis]; i8 = Context.get__plot3d$Vertex()[s5 * 3 + 2] * 8; ptr9 = z; i7 = i8; d117 = ptr9.getDouble(i7); u1[2] = d117;
/*      */         break;
/*      */       case 1:
/*  861 */         s4 = Context.get__plot3d$AxisStart()[axis]; i6 = Context.get__plot3d$Vertex()[s4 * 3] * 8; ptr8 = x; i5 = i6; d116 = ptr8.getDouble(i5); u1[0] = d116;
/*  862 */         min$200 = min[0]; u1[1] = min$200;
/*  863 */         s3 = Context.get__plot3d$AxisStart()[axis]; i4 = Context.get__plot3d$Vertex()[s3 * 3 + 2] * 8; ptr7 = z; i3 = i4; d115 = ptr7.getDouble(i3); u1[2] = d115;
/*      */         break;
/*      */       case 2:
/*  866 */         s2 = Context.get__plot3d$AxisStart()[axis]; i2 = Context.get__plot3d$Vertex()[s2 * 3] * 8; ptr6 = x; i1 = i2; d114 = ptr6.getDouble(i1); u1[0] = d114;
/*  867 */         s1 = Context.get__plot3d$AxisStart()[axis]; n = Context.get__plot3d$Vertex()[s1 * 3 + 1] * 8; ptr5 = y; m = n; d113 = ptr5.getDouble(m); u1[1] = d113;
/*  868 */         min$201 = min[0]; u1[2] = min$201;
/*      */         break;
/*      */     } 
/*  871 */     double d112 = u1[0], d111 = x.getDouble(8), d110 = x.getDouble(), d109 = (d111 - d110) * tickLength, d108 = Context.get__plot3d$TickVector()[axis * 3], d107 = d109 * d108, d106 = d112 + d107; u1[0] = d106;
/*  872 */     double d105 = u1[1], d104 = y.getDouble(8), d103 = y.getDouble(), d102 = (d104 - d103) * tickLength, d101 = Context.get__plot3d$TickVector()[axis * 3 + 1], d100 = d102 * d101, d99 = d105 + d100; u1[1] = d99;
/*  873 */     double d98 = u1[2], d97 = z.getDouble(8), d96 = z.getDouble(), d95 = (d97 - d96) * tickLength, d94 = Context.get__plot3d$TickVector()[axis * 3 + 2], d93 = d95 * d94, d92 = d98 + d93; u1[2] = d92;
/*  874 */     u1[3] = 1.0D;
/*  875 */     switch (axisType) {
/*      */       case 0:
/*  877 */         max$202 = max[0]; u2[0] = max$202;
/*  878 */         d91 = u1[1]; u2[1] = d91;
/*  879 */         d90 = u1[2]; u2[2] = d90;
/*      */         break;
/*      */       case 1:
/*  882 */         d89 = u1[0]; u2[0] = d89;
/*  883 */         max$203 = max[0]; u2[1] = max$203;
/*  884 */         d88 = u1[2]; u2[2] = d88;
/*      */         break;
/*      */       case 2:
/*  887 */         d87 = u1[0]; u2[0] = d87;
/*  888 */         d86 = u1[1]; u2[1] = d86;
/*  889 */         max$204 = max[0]; u2[2] = max$204;
/*      */         break;
/*      */     } 
/*  892 */     u2[3] = 1.0D;
/*      */ 
/*      */     
/*  895 */     switch (tickType) {
/*      */       
/*      */       case 1:
/*  898 */         d85 = u1[0]; d84 = x.getDouble(8); d83 = x.getDouble(); d82 = (d84 - d83) * tickLength; d81 = Context.get__plot3d$TickVector()[axis * 3]; d80 = d82 * d81; d79 = d85 + d80; u3[0] = d79;
/*  899 */         d78 = u1[1]; d77 = y.getDouble(8); d76 = y.getDouble(); d75 = (d77 - d76) * tickLength; d74 = Context.get__plot3d$TickVector()[axis * 3 + 1]; d73 = d75 * d74; d72 = d78 + d73; u3[1] = d72;
/*  900 */         d71 = u1[2]; d70 = z.getDouble(8); d69 = z.getDouble(); d68 = (d70 - d69) * tickLength; d67 = Context.get__plot3d$TickVector()[axis * 3 + 2]; d66 = d68 * d67; d65 = d71 + d66; u3[2] = d65;
/*      */         break;
/*      */       case 2:
/*  903 */         d64 = u1[0]; d63 = tickLength * 2.5D; d62 = x.getDouble(8); d61 = x.getDouble(); d60 = d62 - d61; d59 = d63 * d60; d58 = Context.get__plot3d$TickVector()[axis * 3]; d57 = d59 * d58; d56 = d64 + d57; u3[0] = d56;
/*  904 */         d55 = u1[1]; d54 = tickLength * 2.5D; d53 = y.getDouble(8); d52 = y.getDouble(); d51 = d53 - d52; d50 = d54 * d51; d49 = Context.get__plot3d$TickVector()[axis * 3 + 1]; d48 = d50 * d49; d47 = d55 + d48; u3[1] = d47;
/*  905 */         d46 = u1[2]; d45 = tickLength * 2.5D; d44 = z.getDouble(8); d43 = z.getDouble(); d42 = d44 - d43; d41 = d45 * d42; d40 = Context.get__plot3d$TickVector()[axis * 3 + 2]; d39 = d41 * d40; d38 = d46 + d39; u3[2] = d38;
/*      */         break;
/*      */     } 
/*  908 */     switch (axisType) {
/*      */       case 0:
/*  910 */         min$205 = min[0]; max$206 = max[0]; d37 = (min$205 + max$206) / 2.0D; u3[0] = d37;
/*      */         break;
/*      */       case 1:
/*  913 */         min$207 = min[0]; max$208 = max[0]; d36 = (min$207 + max$208) / 2.0D; u3[1] = d36;
/*      */         break;
/*      */       case 2:
/*  916 */         min$209 = min[0]; max$210 = max[0]; d35 = (min$209 + max$210) / 2.0D; u3[2] = d35;
/*      */         break;
/*      */     } 
/*  919 */     u3[3] = 1.0D;
/*  920 */     TransVector((Ptr)new DoublePtr(u1, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v1, 0));
/*  921 */     TransVector((Ptr)new DoublePtr(u2, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v2, 0));
/*  922 */     TransVector((Ptr)new DoublePtr(u3, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v3, 0));
/*      */ 
/*      */     
/*  925 */     Ptr ptr4 = base__.Rf_gpptr(dd); double d34 = base__.Rf_gpptr(dd).getDouble(484), d33 = base__.Rf_gpptr(dd).getDouble(500), d32 = d34 * d33; ptr4.setDouble(28, d32);
/*  926 */     Ptr ptr3 = base__.Rf_gpptr(dd); int k = base__.Rf_gpptr(dd).getInt(528); ptr3.setInt(284, k);
/*      */     
/*  928 */     double d31 = v2[1], d30 = v2[3]; double d29 = d31 / d30; double d28 = v2[0], d27 = v2[3]; double d26 = d28 / d27; double d25 = v1[1], d24 = v1[3]; double d23 = d25 / d24; double d22 = v1[0], d21 = v1[3];
/*      */     
/*      */     double d20 = labelAngle(d22 / d21, d23, d26, d29), d19 = v3[1], d18 = v3[3], d17 = d19 / d18, d16 = v3[0], d15 = v3[3];
/*      */     graphics__.Rf_GText(d16 / d15, d17, 12, label, enc, 0.5D, 0.5D, d20, dd);
/*  932 */     Ptr ptr2 = base__.Rf_gpptr(dd); double d14 = base__.Rf_gpptr(dd).getDouble(484), d13 = base__.Rf_gpptr(dd).getDouble(516), d12 = d14 * d13; ptr2.setDouble(28, d12);
/*  933 */     Ptr ptr1 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(536); ptr1.setInt(284, j);
/*  934 */     switch (tickType) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  940 */         d11 = v2[1]; d10 = v2[3]; d9 = d11 / d10; d8 = v2[0]; d7 = v2[3]; d6 = d8 / d7; d5 = v1[1]; d4 = v1[3]; d3 = d5 / d4; d2 = v1[0]; d1 = v1[3];
/*      */         graphics__.Rf_GArrow(d2 / d1, d3, d6, d9, 12, 0.1D, 10.0D, 2, dd);
/*      */         break;
/*      */       case 2:
/*  944 */         at = at_vector__.Rf_CreateAtVector((Ptr)new DoublePtr(axp, 0), range.pointerPlus(range$offset), 7, 0); Rinternals.Rf_protect(at);
/*  945 */         lab = plot__.Rf_labelformat(at); Rinternals.Rf_protect(lab);
/*  946 */         for (i = 0; Rinternals.Rf_length(at) > i; i++) {
/*  947 */           double d178; Ptr ptr11; int i12, i13; Ptr ptr12; double d179; Ptr ptr13; int i14, i15; short s7; double d180; Ptr ptr14; int i16, i17; short s8; double d181; Ptr ptr15; int i18, i19; short s9; double d182; Ptr ptr16; int i20, i21; Ptr ptr17; double d183; Ptr ptr18; int i22, i23; short s10; double d184; Ptr ptr19; int i24, i25; short s11; double d185; Ptr ptr20; int i26, i27; short s12; double d186; Ptr ptr21; int i28, i29; Ptr ptr22; switch (axisType) {
/*      */             case 0:
/*  949 */               ptr22 = Rinternals2.REAL(at); i29 = i * 8; ptr21 = ptr22; i28 = 0 + i29; d186 = ptr21.getDouble(i28); u1[0] = d186;
/*  950 */               s12 = Context.get__plot3d$AxisStart()[axis]; i27 = Context.get__plot3d$Vertex()[s12 * 3 + 1] * 8; ptr20 = y; i26 = i27; d185 = ptr20.getDouble(i26); u1[1] = d185;
/*  951 */               s11 = Context.get__plot3d$AxisStart()[axis]; i25 = Context.get__plot3d$Vertex()[s11 * 3 + 2] * 8; ptr19 = z; i24 = i25; d184 = ptr19.getDouble(i24); u1[2] = d184;
/*      */               break;
/*      */             case 1:
/*  954 */               s10 = Context.get__plot3d$AxisStart()[axis]; i23 = Context.get__plot3d$Vertex()[s10 * 3] * 8; ptr18 = x; i22 = i23; d183 = ptr18.getDouble(i22); u1[0] = d183;
/*  955 */               ptr17 = Rinternals2.REAL(at); i21 = i * 8; ptr16 = ptr17; i20 = 0 + i21; d182 = ptr16.getDouble(i20); u1[1] = d182;
/*  956 */               s9 = Context.get__plot3d$AxisStart()[axis]; i19 = Context.get__plot3d$Vertex()[s9 * 3 + 2] * 8; ptr15 = z; i18 = i19; d181 = ptr15.getDouble(i18); u1[2] = d181;
/*      */               break;
/*      */             case 2:
/*  959 */               s8 = Context.get__plot3d$AxisStart()[axis]; i17 = Context.get__plot3d$Vertex()[s8 * 3] * 8; ptr14 = x; i16 = i17; d180 = ptr14.getDouble(i16); u1[0] = d180;
/*  960 */               s7 = Context.get__plot3d$AxisStart()[axis]; i15 = Context.get__plot3d$Vertex()[s7 * 3 + 1] * 8; ptr13 = y; i14 = i15; d179 = ptr13.getDouble(i14); u1[1] = d179;
/*  961 */               ptr12 = Rinternals2.REAL(at); i13 = i * 8; ptr11 = ptr12; i12 = 0 + i13; d178 = ptr11.getDouble(i12); u1[2] = d178;
/*      */               break;
/*      */           } 
/*  964 */           u1[3] = 1.0D;
/*  965 */           double d177 = u1[0], d176 = x.getDouble(8), d175 = x.getDouble(), d174 = (d176 - d175) * tickLength, d173 = Context.get__plot3d$TickVector()[axis * 3], d172 = d174 * d173, d171 = d177 + d172; u2[0] = d171;
/*  966 */           double d170 = u1[1], d169 = y.getDouble(8), d168 = y.getDouble(), d167 = (d169 - d168) * tickLength, d166 = Context.get__plot3d$TickVector()[axis * 3 + 1], d165 = d167 * d166, d164 = d170 + d165; u2[1] = d164;
/*  967 */           double d163 = u1[2], d162 = z.getDouble(8), d161 = z.getDouble(), d160 = (d162 - d161) * tickLength, d159 = Context.get__plot3d$TickVector()[axis * 3 + 2], d158 = d160 * d159, d157 = d163 + d158; u2[2] = d157;
/*  968 */           u2[3] = 1.0D;
/*  969 */           double d156 = u2[0], d155 = x.getDouble(8), d154 = x.getDouble(), d153 = (d155 - d154) * tickLength, d152 = Context.get__plot3d$TickVector()[axis * 3], d151 = d153 * d152, d150 = d156 + d151; u3[0] = d150;
/*  970 */           double d149 = u2[1], d148 = y.getDouble(8), d147 = y.getDouble(), d146 = (d148 - d147) * tickLength, d145 = Context.get__plot3d$TickVector()[axis * 3 + 1], d144 = d146 * d145, d143 = d149 + d144; u3[1] = d143;
/*  971 */           double d142 = u2[2], d141 = z.getDouble(8), d140 = z.getDouble(), d139 = (d141 - d140) * tickLength, d138 = Context.get__plot3d$TickVector()[axis * 3 + 2], d137 = d139 * d138, d136 = d142 + d137; u3[2] = d136;
/*  972 */           u3[3] = 1.0D;
/*  973 */           TransVector((Ptr)new DoublePtr(u1, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v1, 0));
/*  974 */           TransVector((Ptr)new DoublePtr(u2, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v2, 0));
/*  975 */           TransVector((Ptr)new DoublePtr(u3, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v3, 0));
/*      */ 
/*      */           
/*  978 */           double d135 = v2[1], d134 = v2[3]; double d133 = d135 / d134; double d132 = v2[0], d131 = v2[3]; double d130 = d132 / d131, d129 = v1[1], d128 = v1[3], d127 = d129 / d128, d126 = v1[0], d125 = v1[3];
/*      */           graphics__.Rf_GLine(d126 / d125, d127, d130, d133, 12, dd);
/*  980 */           int i11 = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(lab, i)); BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(lab, i)); double d124 = v3[1], d123 = v3[3], d122 = d124 / d123, d121 = v3[0], d120 = v3[3]; graphics__.Rf_GText(d121 / d120, d122, 12, (Ptr)bytePtr, i11, 0.5D, 0.5D, 0.0D, dd);
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  988 */     base__.Rf_gpptr(dd).setDouble(28, cexsave);
/*  989 */     base__.Rf_gpptr(dd).setInt(284, fontsave); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void PerspAxes(Ptr x, Ptr y, Ptr z, Ptr xlab, int xenc, Ptr ylab, int yenc, Ptr zlab, int zenc, int nTicks, int tickType, Ptr dd) {
/* 1006 */     v3 = new double[4]; v2 = new double[4]; v1 = new double[4]; v0 = new double[4]; u3 = new double[4]; u2 = new double[4]; u1 = new double[4]; u0 = new double[4]; xAxis = 0; yAxis = 0; zAxis = 0;
/*      */ 
/*      */ 
/*      */     
/* 1010 */     double d34 = x.getDouble(); u0[0] = d34;
/* 1011 */     double d33 = y.getDouble(); u0[1] = d33;
/* 1012 */     double d32 = z.getDouble(); u0[2] = d32;
/* 1013 */     u0[3] = 1.0D;
/* 1014 */     double d31 = x.getAlignedDouble(1); u1[0] = d31;
/* 1015 */     double d30 = y.getDouble(); u1[1] = d30;
/* 1016 */     double d29 = z.getDouble(); u1[2] = d29;
/* 1017 */     u1[3] = 1.0D;
/* 1018 */     double d28 = x.getDouble(); u2[0] = d28;
/* 1019 */     double d27 = y.getAlignedDouble(1); u2[1] = d27;
/* 1020 */     double d26 = z.getDouble(); u2[2] = d26;
/* 1021 */     u2[3] = 1.0D;
/* 1022 */     double d25 = x.getAlignedDouble(1); u3[0] = d25;
/* 1023 */     double d24 = y.getAlignedDouble(1); u3[1] = d24;
/* 1024 */     double d23 = z.getDouble(); u3[2] = d23;
/* 1025 */     u3[3] = 1.0D;
/* 1026 */     TransVector((Ptr)new DoublePtr(u0, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v0, 0));
/* 1027 */     TransVector((Ptr)new DoublePtr(u1, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v1, 0));
/* 1028 */     TransVector((Ptr)new DoublePtr(u2, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v2, 0));
/* 1029 */     TransVector((Ptr)new DoublePtr(u3, 0), (Ptr)new DoublePtr(Context.get__plot3d$VT(), 0), (Ptr)new DoublePtr(v3, 0));
/*      */ 
/*      */     
/* 1032 */     xpdsave = base__.Rf_gpptr(dd).getInt(444);
/* 1033 */     base__.Rf_gpptr(dd).setInt(444, 1);
/*      */ 
/*      */     
/* 1036 */     double d22 = v3[1], d21 = v3[3], d20 = d22 / d21, d19 = v2[1], d18 = v2[3], d17 = d19 / d18, d16 = v1[1], d15 = v1[3], d14 = d16 / d15, d13 = v0[1], d12 = v0[3]; if (lowest(d13 / d12, d14, d17, d20) == 0)
/*      */     
/*      */     { 
/* 1039 */       double d45 = v3[1], d44 = v3[3], d43 = d45 / d44, d42 = v2[1], d41 = v2[3], d40 = d42 / d41, d39 = v0[1], d38 = v0[3], d37 = d39 / d38, d36 = v1[1], d35 = v1[3]; if (lowest(d36 / d35, d37, d40, d43) == 0)
/*      */       
/*      */       { 
/* 1042 */         double d56 = v3[1], d55 = v3[3], d54 = d56 / d55, d53 = v0[1], d52 = v0[3], d51 = d53 / d52, d50 = v1[1], d49 = v1[3], d48 = d50 / d49, d47 = v2[1], d46 = v2[3]; if (lowest(d47 / d46, d48, d51, d54) == 0)
/*      */         
/*      */         { 
/* 1045 */           double d67 = v0[1], d66 = v0[3], d65 = d67 / d66, d64 = v2[1], d63 = v2[3], d62 = d64 / d63, d61 = v1[1], d60 = v1[3], d59 = d61 / d60, d58 = v3[1], d57 = v3[3]; if (lowest(d58 / d57, d59, d62, d65) == 0)
/*      */           
/*      */           { 
/*      */             
/* 1049 */             Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("Axis orientation not calculated\000".getBytes(), 0)), new Object[0]); } else { xAxis = 2; yAxis = 3; }  } else { xAxis = 2; yAxis = 1; }  } else { xAxis = 0; yAxis = 3; }  } else { xAxis = 0; yAxis = 1; }
/* 1050 */      PerspAxis(x, y, z, xAxis, 0, nTicks, tickType, xlab, xenc, dd);
/* 1051 */     PerspAxis(x, y, z, yAxis, 1, nTicks, tickType, ylab, yenc, dd);
/*      */     
/* 1053 */     double d11 = v3[0], d10 = v3[3], d9 = d11 / d10, d8 = v2[0], d7 = v2[3], d6 = d8 / d7, d5 = v1[0], d4 = v1[3], d3 = d5 / d4, d2 = v0[0], d1 = v0[3]; if (lowest(d2 / d1, d3, d6, d9) == 0)
/*      */     
/* 1055 */     { double d45 = v3[0], d44 = v3[3], d43 = d45 / d44, d42 = v2[0], d41 = v2[3], d40 = d42 / d41, d39 = v0[0], d38 = v0[3], d37 = d39 / d38, d36 = v1[0], d35 = v1[3]; if (lowest(d36 / d35, d37, d40, d43) == 0)
/*      */       
/* 1057 */       { double d56 = v3[0], d55 = v3[3], d54 = d56 / d55, d53 = v0[0], d52 = v0[3], d51 = d53 / d52, d50 = v1[0], d49 = v1[3], d48 = d50 / d49, d47 = v2[0], d46 = v2[3]; if (lowest(d47 / d46, d48, d51, d54) == 0)
/*      */         
/* 1059 */         { double d67 = v0[0], d66 = v0[3], d65 = d67 / d66, d64 = v2[0], d63 = v2[3], d62 = d64 / d63, d61 = v1[0], d60 = v1[3], d59 = d61 / d60, d58 = v3[0], d57 = v3[3]; if (lowest(d58 / d57, d59, d62, d65) == 0)
/*      */           
/*      */           { 
/* 1062 */             Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("Axis orientation not calculated\000".getBytes(), 0)), new Object[0]); } else { zAxis = 7; }  } else { zAxis = 6; }  } else { zAxis = 5; }  } else { zAxis = 4; }
/* 1063 */      PerspAxis(x, y, z, zAxis, 2, nTicks, tickType, zlab, zenc, dd);
/*      */     
/* 1065 */     base__.Rf_gpptr(dd).setInt(444, xpdsave);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_persp(SEXP args) {
/*      */     // Byte code:
/*      */     //   0: bipush #12
/*      */     //   2: newarray byte
/*      */     //   4: astore #8
/*      */     //   6: iconst_1
/*      */     //   7: newarray double
/*      */     //   9: astore #17
/*      */     //   11: iconst_1
/*      */     //   12: newarray double
/*      */     //   14: astore #18
/*      */     //   16: iconst_1
/*      */     //   17: newarray double
/*      */     //   19: astore #19
/*      */     //   21: iconst_1
/*      */     //   22: newarray double
/*      */     //   24: astore #20
/*      */     //   26: iconst_1
/*      */     //   27: newarray double
/*      */     //   29: astore #21
/*      */     //   31: iconst_1
/*      */     //   32: newarray double
/*      */     //   34: astore #22
/*      */     //   36: iconst_0
/*      */     //   37: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   40: astore #6
/*      */     //   42: iconst_0
/*      */     //   43: istore #7
/*      */     //   45: iconst_0
/*      */     //   46: istore #9
/*      */     //   48: iconst_0
/*      */     //   49: istore #10
/*      */     //   51: iconst_0
/*      */     //   52: istore #11
/*      */     //   54: iconst_0
/*      */     //   55: istore #12
/*      */     //   57: iconst_0
/*      */     //   58: istore #13
/*      */     //   60: iconst_0
/*      */     //   61: istore #16
/*      */     //   63: aload #17
/*      */     //   65: iconst_0
/*      */     //   66: dconst_0
/*      */     //   67: dastore
/*      */     //   68: aload #18
/*      */     //   70: iconst_0
/*      */     //   71: dconst_0
/*      */     //   72: dastore
/*      */     //   73: aload #19
/*      */     //   75: iconst_0
/*      */     //   76: dconst_0
/*      */     //   77: dastore
/*      */     //   78: aload #20
/*      */     //   80: iconst_0
/*      */     //   81: dconst_0
/*      */     //   82: dastore
/*      */     //   83: aload #21
/*      */     //   85: iconst_0
/*      */     //   86: dconst_0
/*      */     //   87: dastore
/*      */     //   88: aload #22
/*      */     //   90: iconst_0
/*      */     //   91: dconst_0
/*      */     //   92: dastore
/*      */     //   93: dconst_0
/*      */     //   94: dstore #23
/*      */     //   96: dconst_0
/*      */     //   97: dstore #29
/*      */     //   99: dconst_0
/*      */     //   100: dstore #31
/*      */     //   102: dconst_0
/*      */     //   103: dstore #33
/*      */     //   105: dconst_0
/*      */     //   106: dstore #35
/*      */     //   108: iconst_0
/*      */     //   109: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   112: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   117: checkcast org/renjin/sexp/SEXP
/*      */     //   120: astore #37
/*      */     //   122: iconst_0
/*      */     //   123: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   126: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   131: checkcast org/renjin/sexp/SEXP
/*      */     //   134: astore #38
/*      */     //   136: iconst_0
/*      */     //   137: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   140: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   145: checkcast org/renjin/sexp/SEXP
/*      */     //   148: astore #39
/*      */     //   150: iconst_0
/*      */     //   151: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   154: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   159: checkcast org/renjin/sexp/SEXP
/*      */     //   162: astore #40
/*      */     //   164: iconst_0
/*      */     //   165: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   168: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   173: checkcast org/renjin/sexp/SEXP
/*      */     //   176: astore #41
/*      */     //   178: iconst_0
/*      */     //   179: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   182: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   187: checkcast org/renjin/sexp/SEXP
/*      */     //   190: astore #44
/*      */     //   192: iconst_0
/*      */     //   193: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   196: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   201: checkcast org/renjin/sexp/SEXP
/*      */     //   204: astore #45
/*      */     //   206: iconst_0
/*      */     //   207: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   210: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   215: checkcast org/renjin/sexp/SEXP
/*      */     //   218: astore #46
/*      */     //   220: iconst_0
/*      */     //   221: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   224: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   229: checkcast org/renjin/sexp/SEXP
/*      */     //   232: astore #47
/*      */     //   234: iconst_0
/*      */     //   235: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   238: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   243: checkcast org/renjin/sexp/SEXP
/*      */     //   246: astore #48
/*      */     //   248: iconst_0
/*      */     //   249: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   252: invokeinterface getArray : ()Ljava/lang/Object;
/*      */     //   257: checkcast org/renjin/sexp/SEXP
/*      */     //   260: astore #49
/*      */     //   262: aload #22
/*      */     //   264: iconst_0
/*      */     //   265: dconst_0
/*      */     //   266: dastore
/*      */     //   267: aload #21
/*      */     //   269: iconst_0
/*      */     //   270: dconst_0
/*      */     //   271: dastore
/*      */     //   272: aload #20
/*      */     //   274: iconst_0
/*      */     //   275: dconst_0
/*      */     //   276: dastore
/*      */     //   277: aload #19
/*      */     //   279: iconst_0
/*      */     //   280: dconst_0
/*      */     //   281: dastore
/*      */     //   282: aload #18
/*      */     //   284: iconst_0
/*      */     //   285: dconst_0
/*      */     //   286: dastore
/*      */     //   287: aload #17
/*      */     //   289: iconst_0
/*      */     //   290: dconst_0
/*      */     //   291: dastore
/*      */     //   292: aload_0
/*      */     //   293: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   296: astore_0
/*      */     //   297: aload_0
/*      */     //   298: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   301: bipush #23
/*      */     //   303: if_icmple -> 309
/*      */     //   306: goto -> 349
/*      */     //   309: new org/renjin/gcc/runtime/BytePtr
/*      */     //   312: dup
/*      */     //   313: ldc 'graphics '
/*      */     //   315: invokevirtual getBytes : ()[B
/*      */     //   318: iconst_0
/*      */     //   319: invokespecial <init> : ([BI)V
/*      */     //   322: new org/renjin/gcc/runtime/BytePtr
/*      */     //   325: dup
/*      */     //   326: ldc_w 'too few parameters '
/*      */     //   329: invokevirtual getBytes : ()[B
/*      */     //   332: iconst_0
/*      */     //   333: invokespecial <init> : ([BI)V
/*      */     //   336: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   339: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   342: iconst_0
/*      */     //   343: anewarray java/lang/Object
/*      */     //   346: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   349: aload_0
/*      */     //   350: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   353: bipush #14
/*      */     //   355: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   358: astore #49
/*      */     //   360: aload #49
/*      */     //   362: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   365: pop
/*      */     //   366: aload #49
/*      */     //   368: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   371: iconst_1
/*      */     //   372: if_icmple -> 378
/*      */     //   375: goto -> 435
/*      */     //   378: new org/renjin/gcc/runtime/BytePtr
/*      */     //   381: dup
/*      */     //   382: ldc 'graphics '
/*      */     //   384: invokevirtual getBytes : ()[B
/*      */     //   387: iconst_0
/*      */     //   388: invokespecial <init> : ([BI)V
/*      */     //   391: new org/renjin/gcc/runtime/BytePtr
/*      */     //   394: dup
/*      */     //   395: ldc_w 'invalid '%s' argument '
/*      */     //   398: invokevirtual getBytes : ()[B
/*      */     //   401: iconst_0
/*      */     //   402: invokespecial <init> : ([BI)V
/*      */     //   405: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   408: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   411: iconst_1
/*      */     //   412: anewarray java/lang/Object
/*      */     //   415: dup
/*      */     //   416: iconst_0
/*      */     //   417: new org/renjin/gcc/runtime/BytePtr
/*      */     //   420: dup
/*      */     //   421: ldc_w 'x '
/*      */     //   424: invokevirtual getBytes : ()[B
/*      */     //   427: iconst_0
/*      */     //   428: invokespecial <init> : ([BI)V
/*      */     //   431: aastore
/*      */     //   432: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   435: aload_0
/*      */     //   436: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   439: astore_0
/*      */     //   440: aload_0
/*      */     //   441: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   444: bipush #14
/*      */     //   446: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   449: astore #48
/*      */     //   451: aload #48
/*      */     //   453: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   456: pop
/*      */     //   457: aload #48
/*      */     //   459: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   462: iconst_1
/*      */     //   463: if_icmple -> 469
/*      */     //   466: goto -> 526
/*      */     //   469: new org/renjin/gcc/runtime/BytePtr
/*      */     //   472: dup
/*      */     //   473: ldc 'graphics '
/*      */     //   475: invokevirtual getBytes : ()[B
/*      */     //   478: iconst_0
/*      */     //   479: invokespecial <init> : ([BI)V
/*      */     //   482: new org/renjin/gcc/runtime/BytePtr
/*      */     //   485: dup
/*      */     //   486: ldc_w 'invalid '%s' argument '
/*      */     //   489: invokevirtual getBytes : ()[B
/*      */     //   492: iconst_0
/*      */     //   493: invokespecial <init> : ([BI)V
/*      */     //   496: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   499: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   502: iconst_1
/*      */     //   503: anewarray java/lang/Object
/*      */     //   506: dup
/*      */     //   507: iconst_0
/*      */     //   508: new org/renjin/gcc/runtime/BytePtr
/*      */     //   511: dup
/*      */     //   512: ldc_w 'y '
/*      */     //   515: invokevirtual getBytes : ()[B
/*      */     //   518: iconst_0
/*      */     //   519: invokespecial <init> : ([BI)V
/*      */     //   522: aastore
/*      */     //   523: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   526: aload_0
/*      */     //   527: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   530: astore_0
/*      */     //   531: aload_0
/*      */     //   532: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   535: bipush #14
/*      */     //   537: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   540: astore #47
/*      */     //   542: aload #47
/*      */     //   544: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   547: pop
/*      */     //   548: aload #47
/*      */     //   550: invokestatic Rf_isMatrix : (Lorg/renjin/sexp/SEXP;)Z
/*      */     //   553: ifeq -> 623
/*      */     //   556: goto -> 559
/*      */     //   559: aload #47
/*      */     //   561: invokestatic Rf_nrows : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   564: wide istore #301
/*      */     //   568: aload #49
/*      */     //   570: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   573: wide istore #300
/*      */     //   577: wide iload #301
/*      */     //   581: wide iload #300
/*      */     //   585: if_icmpne -> 623
/*      */     //   588: goto -> 591
/*      */     //   591: aload #47
/*      */     //   593: invokestatic Rf_ncols : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   596: wide istore #299
/*      */     //   600: aload #48
/*      */     //   602: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   605: wide istore #298
/*      */     //   609: wide iload #299
/*      */     //   613: wide iload #298
/*      */     //   617: if_icmpne -> 623
/*      */     //   620: goto -> 680
/*      */     //   623: new org/renjin/gcc/runtime/BytePtr
/*      */     //   626: dup
/*      */     //   627: ldc 'graphics '
/*      */     //   629: invokevirtual getBytes : ()[B
/*      */     //   632: iconst_0
/*      */     //   633: invokespecial <init> : ([BI)V
/*      */     //   636: new org/renjin/gcc/runtime/BytePtr
/*      */     //   639: dup
/*      */     //   640: ldc_w 'invalid '%s' argument '
/*      */     //   643: invokevirtual getBytes : ()[B
/*      */     //   646: iconst_0
/*      */     //   647: invokespecial <init> : ([BI)V
/*      */     //   650: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   653: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   656: iconst_1
/*      */     //   657: anewarray java/lang/Object
/*      */     //   660: dup
/*      */     //   661: iconst_0
/*      */     //   662: new org/renjin/gcc/runtime/BytePtr
/*      */     //   665: dup
/*      */     //   666: ldc_w 'z '
/*      */     //   669: invokevirtual getBytes : ()[B
/*      */     //   672: iconst_0
/*      */     //   673: invokespecial <init> : ([BI)V
/*      */     //   676: aastore
/*      */     //   677: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   680: aload_0
/*      */     //   681: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   684: astore_0
/*      */     //   685: aload_0
/*      */     //   686: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   689: bipush #14
/*      */     //   691: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   694: astore #46
/*      */     //   696: aload #46
/*      */     //   698: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   701: pop
/*      */     //   702: aload #46
/*      */     //   704: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   707: iconst_2
/*      */     //   708: if_icmpne -> 714
/*      */     //   711: goto -> 771
/*      */     //   714: new org/renjin/gcc/runtime/BytePtr
/*      */     //   717: dup
/*      */     //   718: ldc 'graphics '
/*      */     //   720: invokevirtual getBytes : ()[B
/*      */     //   723: iconst_0
/*      */     //   724: invokespecial <init> : ([BI)V
/*      */     //   727: new org/renjin/gcc/runtime/BytePtr
/*      */     //   730: dup
/*      */     //   731: ldc_w 'invalid '%s' argument '
/*      */     //   734: invokevirtual getBytes : ()[B
/*      */     //   737: iconst_0
/*      */     //   738: invokespecial <init> : ([BI)V
/*      */     //   741: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   744: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   747: iconst_1
/*      */     //   748: anewarray java/lang/Object
/*      */     //   751: dup
/*      */     //   752: iconst_0
/*      */     //   753: new org/renjin/gcc/runtime/BytePtr
/*      */     //   756: dup
/*      */     //   757: ldc_w 'xlim '
/*      */     //   760: invokevirtual getBytes : ()[B
/*      */     //   763: iconst_0
/*      */     //   764: invokespecial <init> : ([BI)V
/*      */     //   767: aastore
/*      */     //   768: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   771: aload_0
/*      */     //   772: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   775: astore_0
/*      */     //   776: aload_0
/*      */     //   777: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   780: bipush #14
/*      */     //   782: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   785: astore #45
/*      */     //   787: aload #45
/*      */     //   789: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   792: pop
/*      */     //   793: aload #45
/*      */     //   795: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   798: iconst_2
/*      */     //   799: if_icmpne -> 805
/*      */     //   802: goto -> 862
/*      */     //   805: new org/renjin/gcc/runtime/BytePtr
/*      */     //   808: dup
/*      */     //   809: ldc 'graphics '
/*      */     //   811: invokevirtual getBytes : ()[B
/*      */     //   814: iconst_0
/*      */     //   815: invokespecial <init> : ([BI)V
/*      */     //   818: new org/renjin/gcc/runtime/BytePtr
/*      */     //   821: dup
/*      */     //   822: ldc_w 'invalid '%s' argument '
/*      */     //   825: invokevirtual getBytes : ()[B
/*      */     //   828: iconst_0
/*      */     //   829: invokespecial <init> : ([BI)V
/*      */     //   832: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   835: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   838: iconst_1
/*      */     //   839: anewarray java/lang/Object
/*      */     //   842: dup
/*      */     //   843: iconst_0
/*      */     //   844: new org/renjin/gcc/runtime/BytePtr
/*      */     //   847: dup
/*      */     //   848: ldc_w 'ylim '
/*      */     //   851: invokevirtual getBytes : ()[B
/*      */     //   854: iconst_0
/*      */     //   855: invokespecial <init> : ([BI)V
/*      */     //   858: aastore
/*      */     //   859: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   862: aload_0
/*      */     //   863: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   866: astore_0
/*      */     //   867: aload_0
/*      */     //   868: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   871: bipush #14
/*      */     //   873: invokestatic Rf_coerceVector : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   876: astore #44
/*      */     //   878: aload #44
/*      */     //   880: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   883: pop
/*      */     //   884: aload #44
/*      */     //   886: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   889: iconst_2
/*      */     //   890: if_icmpne -> 896
/*      */     //   893: goto -> 953
/*      */     //   896: new org/renjin/gcc/runtime/BytePtr
/*      */     //   899: dup
/*      */     //   900: ldc 'graphics '
/*      */     //   902: invokevirtual getBytes : ()[B
/*      */     //   905: iconst_0
/*      */     //   906: invokespecial <init> : ([BI)V
/*      */     //   909: new org/renjin/gcc/runtime/BytePtr
/*      */     //   912: dup
/*      */     //   913: ldc_w 'invalid '%s' argument '
/*      */     //   916: invokevirtual getBytes : ()[B
/*      */     //   919: iconst_0
/*      */     //   920: invokespecial <init> : ([BI)V
/*      */     //   923: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   926: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   929: iconst_1
/*      */     //   930: anewarray java/lang/Object
/*      */     //   933: dup
/*      */     //   934: iconst_0
/*      */     //   935: new org/renjin/gcc/runtime/BytePtr
/*      */     //   938: dup
/*      */     //   939: ldc_w 'zlim '
/*      */     //   942: invokevirtual getBytes : ()[B
/*      */     //   945: iconst_0
/*      */     //   946: invokespecial <init> : ([BI)V
/*      */     //   949: aastore
/*      */     //   950: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   953: aload_0
/*      */     //   954: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   957: astore_0
/*      */     //   958: aload #46
/*      */     //   960: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   963: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   966: dup
/*      */     //   967: aload #22
/*      */     //   969: iconst_0
/*      */     //   970: invokespecial <init> : ([DI)V
/*      */     //   973: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   976: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   979: dup
/*      */     //   980: aload #19
/*      */     //   982: iconst_0
/*      */     //   983: invokespecial <init> : ([DI)V
/*      */     //   986: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   989: invokestatic LimitCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   992: ifeq -> 998
/*      */     //   995: goto -> 1038
/*      */     //   998: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1001: dup
/*      */     //   1002: ldc 'graphics '
/*      */     //   1004: invokevirtual getBytes : ()[B
/*      */     //   1007: iconst_0
/*      */     //   1008: invokespecial <init> : ([BI)V
/*      */     //   1011: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1014: dup
/*      */     //   1015: ldc_w 'invalid 'x' limits '
/*      */     //   1018: invokevirtual getBytes : ()[B
/*      */     //   1021: iconst_0
/*      */     //   1022: invokespecial <init> : ([BI)V
/*      */     //   1025: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1028: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1031: iconst_0
/*      */     //   1032: anewarray java/lang/Object
/*      */     //   1035: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1038: aload #45
/*      */     //   1040: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1043: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1046: dup
/*      */     //   1047: aload #21
/*      */     //   1049: iconst_0
/*      */     //   1050: invokespecial <init> : ([DI)V
/*      */     //   1053: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1056: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1059: dup
/*      */     //   1060: aload #18
/*      */     //   1062: iconst_0
/*      */     //   1063: invokespecial <init> : ([DI)V
/*      */     //   1066: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1069: invokestatic LimitCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1072: ifeq -> 1078
/*      */     //   1075: goto -> 1118
/*      */     //   1078: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1081: dup
/*      */     //   1082: ldc 'graphics '
/*      */     //   1084: invokevirtual getBytes : ()[B
/*      */     //   1087: iconst_0
/*      */     //   1088: invokespecial <init> : ([BI)V
/*      */     //   1091: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1094: dup
/*      */     //   1095: ldc_w 'invalid 'y' limits '
/*      */     //   1098: invokevirtual getBytes : ()[B
/*      */     //   1101: iconst_0
/*      */     //   1102: invokespecial <init> : ([BI)V
/*      */     //   1105: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1108: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1111: iconst_0
/*      */     //   1112: anewarray java/lang/Object
/*      */     //   1115: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1118: aload #44
/*      */     //   1120: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   1123: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1126: dup
/*      */     //   1127: aload #20
/*      */     //   1129: iconst_0
/*      */     //   1130: invokespecial <init> : ([DI)V
/*      */     //   1133: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1136: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   1139: dup
/*      */     //   1140: aload #17
/*      */     //   1142: iconst_0
/*      */     //   1143: invokespecial <init> : ([DI)V
/*      */     //   1146: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   1149: invokestatic LimitCheck : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   1152: ifeq -> 1158
/*      */     //   1155: goto -> 1198
/*      */     //   1158: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1161: dup
/*      */     //   1162: ldc 'graphics '
/*      */     //   1164: invokevirtual getBytes : ()[B
/*      */     //   1167: iconst_0
/*      */     //   1168: invokespecial <init> : ([BI)V
/*      */     //   1171: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1174: dup
/*      */     //   1175: ldc_w 'invalid 'z' limits '
/*      */     //   1178: invokevirtual getBytes : ()[B
/*      */     //   1181: iconst_0
/*      */     //   1182: invokespecial <init> : ([BI)V
/*      */     //   1185: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1188: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1191: iconst_0
/*      */     //   1192: anewarray java/lang/Object
/*      */     //   1195: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1198: aload_0
/*      */     //   1199: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1202: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1205: dstore #35
/*      */     //   1207: aload_0
/*      */     //   1208: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1211: astore_0
/*      */     //   1212: aload_0
/*      */     //   1213: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1216: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1219: dstore #33
/*      */     //   1221: aload_0
/*      */     //   1222: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1225: astore_0
/*      */     //   1226: aload_0
/*      */     //   1227: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1230: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1233: dstore #31
/*      */     //   1235: aload_0
/*      */     //   1236: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1239: astore_0
/*      */     //   1240: aload_0
/*      */     //   1241: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1244: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1247: dstore #29
/*      */     //   1249: aload_0
/*      */     //   1250: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1253: astore_0
/*      */     //   1254: aload_0
/*      */     //   1255: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1258: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1261: istore #14
/*      */     //   1263: aload_0
/*      */     //   1264: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1267: astore_0
/*      */     //   1268: aload_0
/*      */     //   1269: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1272: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1275: dstore #23
/*      */     //   1277: aload_0
/*      */     //   1278: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1281: astore_0
/*      */     //   1282: aload_0
/*      */     //   1283: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1286: astore #41
/*      */     //   1288: aload_0
/*      */     //   1289: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1292: astore_0
/*      */     //   1293: aload_0
/*      */     //   1294: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1297: astore #40
/*      */     //   1299: aload_0
/*      */     //   1300: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1303: astore_0
/*      */     //   1304: aload_0
/*      */     //   1305: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1308: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1311: dstore #27
/*      */     //   1313: aload_0
/*      */     //   1314: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1317: astore_0
/*      */     //   1318: aload_0
/*      */     //   1319: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1322: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1325: dstore #25
/*      */     //   1327: aload_0
/*      */     //   1328: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1331: astore_0
/*      */     //   1332: aload_0
/*      */     //   1333: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1336: invokestatic Rf_asReal : (Lorg/renjin/sexp/SEXP;)D
/*      */     //   1339: invokestatic set__plot3d$Shade : (D)V
/*      */     //   1342: aload_0
/*      */     //   1343: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1346: astore_0
/*      */     //   1347: aload_0
/*      */     //   1348: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1351: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1354: istore #12
/*      */     //   1356: aload_0
/*      */     //   1357: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1360: astore_0
/*      */     //   1361: aload_0
/*      */     //   1362: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1365: invokestatic Rf_asLogical : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1368: istore #11
/*      */     //   1370: aload_0
/*      */     //   1371: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1374: astore_0
/*      */     //   1375: aload_0
/*      */     //   1376: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1379: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1382: istore #10
/*      */     //   1384: aload_0
/*      */     //   1385: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1388: astore_0
/*      */     //   1389: aload_0
/*      */     //   1390: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1393: invokestatic Rf_asInteger : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1396: istore #9
/*      */     //   1398: aload_0
/*      */     //   1399: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1402: astore_0
/*      */     //   1403: aload_0
/*      */     //   1404: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1407: astore #39
/*      */     //   1409: aload_0
/*      */     //   1410: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1413: astore_0
/*      */     //   1414: aload_0
/*      */     //   1415: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1418: astore #38
/*      */     //   1420: aload_0
/*      */     //   1421: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1424: astore_0
/*      */     //   1425: aload_0
/*      */     //   1426: invokestatic CAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1429: astore #37
/*      */     //   1431: aload_0
/*      */     //   1432: invokestatic CDR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   1435: astore_0
/*      */     //   1436: aload #39
/*      */     //   1438: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1441: bipush #16
/*      */     //   1443: if_icmpne -> 1460
/*      */     //   1446: goto -> 1449
/*      */     //   1449: aload #39
/*      */     //   1451: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1454: ifle -> 1460
/*      */     //   1457: goto -> 1500
/*      */     //   1460: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1463: dup
/*      */     //   1464: ldc 'graphics '
/*      */     //   1466: invokevirtual getBytes : ()[B
/*      */     //   1469: iconst_0
/*      */     //   1470: invokespecial <init> : ([BI)V
/*      */     //   1473: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1476: dup
/*      */     //   1477: ldc_w ''xlab' must be a character vector of length 1 '
/*      */     //   1480: invokevirtual getBytes : ()[B
/*      */     //   1483: iconst_0
/*      */     //   1484: invokespecial <init> : ([BI)V
/*      */     //   1487: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1490: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1493: iconst_0
/*      */     //   1494: anewarray java/lang/Object
/*      */     //   1497: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1500: aload #38
/*      */     //   1502: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1505: bipush #16
/*      */     //   1507: if_icmpne -> 1524
/*      */     //   1510: goto -> 1513
/*      */     //   1513: aload #38
/*      */     //   1515: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1518: ifle -> 1524
/*      */     //   1521: goto -> 1564
/*      */     //   1524: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1527: dup
/*      */     //   1528: ldc 'graphics '
/*      */     //   1530: invokevirtual getBytes : ()[B
/*      */     //   1533: iconst_0
/*      */     //   1534: invokespecial <init> : ([BI)V
/*      */     //   1537: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1540: dup
/*      */     //   1541: ldc_w ''ylab' must be a character vector of length 1 '
/*      */     //   1544: invokevirtual getBytes : ()[B
/*      */     //   1547: iconst_0
/*      */     //   1548: invokespecial <init> : ([BI)V
/*      */     //   1551: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1554: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1557: iconst_0
/*      */     //   1558: anewarray java/lang/Object
/*      */     //   1561: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1564: aload #37
/*      */     //   1566: invokestatic TYPEOF : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1569: bipush #16
/*      */     //   1571: if_icmpne -> 1588
/*      */     //   1574: goto -> 1577
/*      */     //   1577: aload #37
/*      */     //   1579: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   1582: ifle -> 1588
/*      */     //   1585: goto -> 1628
/*      */     //   1588: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1591: dup
/*      */     //   1592: ldc 'graphics '
/*      */     //   1594: invokevirtual getBytes : ()[B
/*      */     //   1597: iconst_0
/*      */     //   1598: invokespecial <init> : ([BI)V
/*      */     //   1601: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1604: dup
/*      */     //   1605: ldc_w ''zlab' must be a character vector of length 1 '
/*      */     //   1608: invokevirtual getBytes : ()[B
/*      */     //   1611: iconst_0
/*      */     //   1612: invokespecial <init> : ([BI)V
/*      */     //   1615: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1618: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1621: iconst_0
/*      */     //   1622: anewarray java/lang/Object
/*      */     //   1625: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1628: invokestatic get__plot3d$Shade : ()D
/*      */     //   1631: invokestatic R_finite : (D)I
/*      */     //   1634: ifne -> 1640
/*      */     //   1637: goto -> 1655
/*      */     //   1640: invokestatic get__plot3d$Shade : ()D
/*      */     //   1643: dconst_0
/*      */     //   1644: dcmpg
/*      */     //   1645: ifle -> 1651
/*      */     //   1648: goto -> 1655
/*      */     //   1651: dconst_1
/*      */     //   1652: invokestatic set__plot3d$Shade : (D)V
/*      */     //   1655: dload #27
/*      */     //   1657: invokestatic R_finite : (D)I
/*      */     //   1660: ifne -> 1666
/*      */     //   1663: goto -> 1696
/*      */     //   1666: dload #25
/*      */     //   1668: invokestatic R_finite : (D)I
/*      */     //   1671: ifne -> 1677
/*      */     //   1674: goto -> 1696
/*      */     //   1677: invokestatic get__plot3d$Shade : ()D
/*      */     //   1680: invokestatic R_finite : (D)I
/*      */     //   1683: ifne -> 1689
/*      */     //   1686: goto -> 1696
/*      */     //   1689: iconst_1
/*      */     //   1690: invokestatic set__plot3d$DoLighting : (I)V
/*      */     //   1693: goto -> 1700
/*      */     //   1696: iconst_0
/*      */     //   1697: invokestatic set__plot3d$DoLighting : (I)V
/*      */     //   1700: iload #14
/*      */     //   1702: ifeq -> 1708
/*      */     //   1705: goto -> 1778
/*      */     //   1708: aload #19
/*      */     //   1710: iconst_0
/*      */     //   1711: daload
/*      */     //   1712: dstore #4
/*      */     //   1714: aload #18
/*      */     //   1716: iconst_0
/*      */     //   1717: daload
/*      */     //   1718: dstore #230
/*      */     //   1720: dload #4
/*      */     //   1722: dload #230
/*      */     //   1724: dcmpg
/*      */     //   1725: iflt -> 1731
/*      */     //   1728: goto -> 1737
/*      */     //   1731: aload #18
/*      */     //   1733: iconst_0
/*      */     //   1734: daload
/*      */     //   1735: dstore #4
/*      */     //   1737: aload #17
/*      */     //   1739: iconst_0
/*      */     //   1740: daload
/*      */     //   1741: dstore #228
/*      */     //   1743: dload #4
/*      */     //   1745: dload #228
/*      */     //   1747: dcmpg
/*      */     //   1748: iflt -> 1754
/*      */     //   1751: goto -> 1760
/*      */     //   1754: aload #17
/*      */     //   1756: iconst_0
/*      */     //   1757: daload
/*      */     //   1758: dstore #4
/*      */     //   1760: aload #19
/*      */     //   1762: iconst_0
/*      */     //   1763: dload #4
/*      */     //   1765: dastore
/*      */     //   1766: aload #18
/*      */     //   1768: iconst_0
/*      */     //   1769: dload #4
/*      */     //   1771: dastore
/*      */     //   1772: aload #17
/*      */     //   1774: iconst_0
/*      */     //   1775: dload #4
/*      */     //   1777: dastore
/*      */     //   1778: dload #35
/*      */     //   1780: invokestatic R_finite : (D)I
/*      */     //   1783: ifeq -> 1842
/*      */     //   1786: goto -> 1789
/*      */     //   1789: dload #33
/*      */     //   1791: invokestatic R_finite : (D)I
/*      */     //   1794: ifeq -> 1842
/*      */     //   1797: goto -> 1800
/*      */     //   1800: dload #31
/*      */     //   1802: invokestatic R_finite : (D)I
/*      */     //   1805: ifeq -> 1842
/*      */     //   1808: goto -> 1811
/*      */     //   1811: dload #29
/*      */     //   1813: invokestatic R_finite : (D)I
/*      */     //   1816: ifeq -> 1842
/*      */     //   1819: goto -> 1822
/*      */     //   1822: dload #29
/*      */     //   1824: dconst_0
/*      */     //   1825: dcmpg
/*      */     //   1826: iflt -> 1842
/*      */     //   1829: goto -> 1832
/*      */     //   1832: dload #31
/*      */     //   1834: dconst_0
/*      */     //   1835: dcmpg
/*      */     //   1836: iflt -> 1842
/*      */     //   1839: goto -> 1882
/*      */     //   1842: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1845: dup
/*      */     //   1846: ldc 'graphics '
/*      */     //   1848: invokevirtual getBytes : ()[B
/*      */     //   1851: iconst_0
/*      */     //   1852: invokespecial <init> : ([BI)V
/*      */     //   1855: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1858: dup
/*      */     //   1859: ldc_w 'invalid viewing parameters '
/*      */     //   1862: invokevirtual getBytes : ()[B
/*      */     //   1865: iconst_0
/*      */     //   1866: invokespecial <init> : ([BI)V
/*      */     //   1869: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1872: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1875: iconst_0
/*      */     //   1876: anewarray java/lang/Object
/*      */     //   1879: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1882: dload #23
/*      */     //   1884: invokestatic R_finite : (D)I
/*      */     //   1887: ifeq -> 1903
/*      */     //   1890: goto -> 1893
/*      */     //   1893: dload #23
/*      */     //   1895: dconst_0
/*      */     //   1896: dcmpg
/*      */     //   1897: iflt -> 1903
/*      */     //   1900: goto -> 1959
/*      */     //   1903: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1906: dup
/*      */     //   1907: ldc 'graphics '
/*      */     //   1909: invokevirtual getBytes : ()[B
/*      */     //   1912: iconst_0
/*      */     //   1913: invokespecial <init> : ([BI)V
/*      */     //   1916: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1919: dup
/*      */     //   1920: ldc 'invalid '%s' value '
/*      */     //   1922: invokevirtual getBytes : ()[B
/*      */     //   1925: iconst_0
/*      */     //   1926: invokespecial <init> : ([BI)V
/*      */     //   1929: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   1932: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   1935: iconst_1
/*      */     //   1936: anewarray java/lang/Object
/*      */     //   1939: dup
/*      */     //   1940: iconst_0
/*      */     //   1941: new org/renjin/gcc/runtime/BytePtr
/*      */     //   1944: dup
/*      */     //   1945: ldc_w 'expand '
/*      */     //   1948: invokevirtual getBytes : ()[B
/*      */     //   1951: iconst_0
/*      */     //   1952: invokespecial <init> : ([BI)V
/*      */     //   1955: aastore
/*      */     //   1956: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   1959: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1962: istore #218
/*      */     //   1964: iload #14
/*      */     //   1966: iload #218
/*      */     //   1968: if_icmpeq -> 1974
/*      */     //   1971: goto -> 1977
/*      */     //   1974: iconst_0
/*      */     //   1975: istore #14
/*      */     //   1977: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   1980: istore #217
/*      */     //   1982: iload #10
/*      */     //   1984: iload #217
/*      */     //   1986: if_icmpeq -> 2000
/*      */     //   1989: goto -> 1992
/*      */     //   1992: iload #10
/*      */     //   1994: iflt -> 2000
/*      */     //   1997: goto -> 2056
/*      */     //   2000: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2003: dup
/*      */     //   2004: ldc 'graphics '
/*      */     //   2006: invokevirtual getBytes : ()[B
/*      */     //   2009: iconst_0
/*      */     //   2010: invokespecial <init> : ([BI)V
/*      */     //   2013: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2016: dup
/*      */     //   2017: ldc 'invalid '%s' value '
/*      */     //   2019: invokevirtual getBytes : ()[B
/*      */     //   2022: iconst_0
/*      */     //   2023: invokespecial <init> : ([BI)V
/*      */     //   2026: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2029: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2032: iconst_1
/*      */     //   2033: anewarray java/lang/Object
/*      */     //   2036: dup
/*      */     //   2037: iconst_0
/*      */     //   2038: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2041: dup
/*      */     //   2042: ldc_w 'nticks '
/*      */     //   2045: invokevirtual getBytes : ()[B
/*      */     //   2048: iconst_0
/*      */     //   2049: invokespecial <init> : ([BI)V
/*      */     //   2052: aastore
/*      */     //   2053: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2056: getstatic org/renjin/gnur/api/Arith.R_NaInt : I
/*      */     //   2059: istore #214
/*      */     //   2061: iload #9
/*      */     //   2063: iload #214
/*      */     //   2065: if_icmpeq -> 2088
/*      */     //   2068: goto -> 2071
/*      */     //   2071: iload #9
/*      */     //   2073: ifle -> 2088
/*      */     //   2076: goto -> 2079
/*      */     //   2079: iload #9
/*      */     //   2081: iconst_2
/*      */     //   2082: if_icmpgt -> 2088
/*      */     //   2085: goto -> 2144
/*      */     //   2088: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2091: dup
/*      */     //   2092: ldc 'graphics '
/*      */     //   2094: invokevirtual getBytes : ()[B
/*      */     //   2097: iconst_0
/*      */     //   2098: invokespecial <init> : ([BI)V
/*      */     //   2101: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2104: dup
/*      */     //   2105: ldc 'invalid '%s' value '
/*      */     //   2107: invokevirtual getBytes : ()[B
/*      */     //   2110: iconst_0
/*      */     //   2111: invokespecial <init> : ([BI)V
/*      */     //   2114: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2117: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2120: iconst_1
/*      */     //   2121: anewarray java/lang/Object
/*      */     //   2124: dup
/*      */     //   2125: iconst_0
/*      */     //   2126: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2129: dup
/*      */     //   2130: ldc_w 'ticktype '
/*      */     //   2133: invokevirtual getBytes : ()[B
/*      */     //   2136: iconst_0
/*      */     //   2137: invokespecial <init> : ([BI)V
/*      */     //   2140: aastore
/*      */     //   2141: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2144: invokestatic GEcurrentDevice : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2147: astore #6
/*      */     //   2149: iconst_0
/*      */     //   2150: istore #7
/*      */     //   2152: aload #6
/*      */     //   2154: iload #7
/*      */     //   2156: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2161: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2164: bipush #20
/*      */     //   2166: invokeinterface getInt : (I)I
/*      */     //   2171: istore #209
/*      */     //   2173: aload #41
/*      */     //   2175: iload #209
/*      */     //   2177: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2180: astore #41
/*      */     //   2182: aload #41
/*      */     //   2184: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2187: pop
/*      */     //   2188: aload #41
/*      */     //   2190: invokestatic LENGTH : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2193: istore #13
/*      */     //   2195: iload #13
/*      */     //   2197: ifle -> 2203
/*      */     //   2200: goto -> 2260
/*      */     //   2203: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2206: dup
/*      */     //   2207: ldc 'graphics '
/*      */     //   2209: invokevirtual getBytes : ()[B
/*      */     //   2212: iconst_0
/*      */     //   2213: invokespecial <init> : ([BI)V
/*      */     //   2216: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2219: dup
/*      */     //   2220: ldc_w 'invalid '%s' specification '
/*      */     //   2223: invokevirtual getBytes : ()[B
/*      */     //   2226: iconst_0
/*      */     //   2227: invokespecial <init> : ([BI)V
/*      */     //   2230: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2233: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2236: iconst_1
/*      */     //   2237: anewarray java/lang/Object
/*      */     //   2240: dup
/*      */     //   2241: iconst_0
/*      */     //   2242: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2245: dup
/*      */     //   2246: ldc_w 'col '
/*      */     //   2249: invokevirtual getBytes : ()[B
/*      */     //   2252: iconst_0
/*      */     //   2253: invokespecial <init> : ([BI)V
/*      */     //   2256: aastore
/*      */     //   2257: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2260: aload #41
/*      */     //   2262: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2265: invokeinterface getInt : ()I
/*      */     //   2270: bipush #24
/*      */     //   2272: iushr
/*      */     //   2273: sipush #255
/*      */     //   2276: if_icmpne -> 2282
/*      */     //   2279: goto -> 2286
/*      */     //   2282: iconst_0
/*      */     //   2283: invokestatic set__plot3d$DoLighting : (I)V
/*      */     //   2286: aload #6
/*      */     //   2288: iload #7
/*      */     //   2290: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2295: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2298: bipush #76
/*      */     //   2300: invokeinterface getInt : (I)I
/*      */     //   2305: istore #199
/*      */     //   2307: aload #40
/*      */     //   2309: iload #199
/*      */     //   2311: invokestatic Rf_FixupCol : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2314: astore #40
/*      */     //   2316: aload #40
/*      */     //   2318: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2321: pop
/*      */     //   2322: aload #40
/*      */     //   2324: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2327: ifle -> 2333
/*      */     //   2330: goto -> 2390
/*      */     //   2333: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2336: dup
/*      */     //   2337: ldc 'graphics '
/*      */     //   2339: invokevirtual getBytes : ()[B
/*      */     //   2342: iconst_0
/*      */     //   2343: invokespecial <init> : ([BI)V
/*      */     //   2346: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2349: dup
/*      */     //   2350: ldc_w 'invalid '%s' specification '
/*      */     //   2353: invokevirtual getBytes : ()[B
/*      */     //   2356: iconst_0
/*      */     //   2357: invokespecial <init> : ([BI)V
/*      */     //   2360: invokestatic dgettext : (Lorg/renjin/gcc/runtime/BytePtr;Lorg/renjin/gcc/runtime/BytePtr;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   2363: checkcast org/renjin/gcc/runtime/BytePtr
/*      */     //   2366: iconst_1
/*      */     //   2367: anewarray java/lang/Object
/*      */     //   2370: dup
/*      */     //   2371: iconst_0
/*      */     //   2372: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2375: dup
/*      */     //   2376: ldc_w 'border '
/*      */     //   2379: invokevirtual getBytes : ()[B
/*      */     //   2382: iconst_0
/*      */     //   2383: invokespecial <init> : ([BI)V
/*      */     //   2386: aastore
/*      */     //   2387: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   2390: iconst_1
/*      */     //   2391: aload #6
/*      */     //   2393: iload #7
/*      */     //   2395: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2400: invokestatic Rf_GSetState : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2403: aload #6
/*      */     //   2405: iload #7
/*      */     //   2407: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2412: invokestatic Rf_GSavePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2415: aload_0
/*      */     //   2416: aload #6
/*      */     //   2418: iload #7
/*      */     //   2420: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2425: invokestatic Rf_ProcessInlinePars : (Lorg/renjin/sexp/SEXP;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2428: aload #40
/*      */     //   2430: invokestatic Rf_length : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2433: iconst_1
/*      */     //   2434: if_icmpgt -> 2440
/*      */     //   2437: goto -> 2477
/*      */     //   2440: aload #6
/*      */     //   2442: iload #7
/*      */     //   2444: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2449: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2452: astore #193
/*      */     //   2454: aload #40
/*      */     //   2456: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2459: invokeinterface getInt : ()I
/*      */     //   2464: istore #189
/*      */     //   2466: aload #193
/*      */     //   2468: bipush #76
/*      */     //   2470: iload #189
/*      */     //   2472: invokeinterface setInt : (II)V
/*      */     //   2477: aload #6
/*      */     //   2479: iload #7
/*      */     //   2481: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2486: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2489: astore #187
/*      */     //   2491: aload #6
/*      */     //   2493: iload #7
/*      */     //   2495: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2500: invokestatic Rf_gpptr : (Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2503: astore #185
/*      */     //   2505: aload #185
/*      */     //   2507: sipush #480
/*      */     //   2510: iconst_0
/*      */     //   2511: invokeinterface setInt : (II)V
/*      */     //   2516: aload #185
/*      */     //   2518: sipush #480
/*      */     //   2521: invokeinterface getInt : (I)I
/*      */     //   2526: istore #184
/*      */     //   2528: aload #187
/*      */     //   2530: sipush #440
/*      */     //   2533: iload #184
/*      */     //   2535: invokeinterface setInt : (II)V
/*      */     //   2540: invokestatic get__plot3d$DoLighting : ()I
/*      */     //   2543: ifne -> 2549
/*      */     //   2546: goto -> 2556
/*      */     //   2549: dload #27
/*      */     //   2551: dload #25
/*      */     //   2553: invokestatic SetUpLight : (DD)V
/*      */     //   2556: iconst_0
/*      */     //   2557: istore #16
/*      */     //   2559: goto -> 2572
/*      */     //   2562: aload #8
/*      */     //   2564: iload #16
/*      */     //   2566: iconst_0
/*      */     //   2567: i2b
/*      */     //   2568: bastore
/*      */     //   2569: iinc #16, 1
/*      */     //   2572: iload #16
/*      */     //   2574: bipush #11
/*      */     //   2576: if_icmple -> 2562
/*      */     //   2579: goto -> 2582
/*      */     //   2582: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   2585: dup
/*      */     //   2586: invokestatic get__plot3d$VT : ()[D
/*      */     //   2589: iconst_0
/*      */     //   2590: invokespecial <init> : ([DI)V
/*      */     //   2593: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2596: invokestatic SetToIdentity : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2599: aload #20
/*      */     //   2601: iconst_0
/*      */     //   2602: daload
/*      */     //   2603: dneg
/*      */     //   2604: dstore #179
/*      */     //   2606: aload #21
/*      */     //   2608: iconst_0
/*      */     //   2609: daload
/*      */     //   2610: dneg
/*      */     //   2611: dstore #175
/*      */     //   2613: aload #22
/*      */     //   2615: iconst_0
/*      */     //   2616: daload
/*      */     //   2617: dneg
/*      */     //   2618: dload #175
/*      */     //   2620: dload #179
/*      */     //   2622: invokestatic Translate : (DDD)V
/*      */     //   2625: aload #17
/*      */     //   2627: iconst_0
/*      */     //   2628: daload
/*      */     //   2629: dstore #169
/*      */     //   2631: dload #23
/*      */     //   2633: dload #169
/*      */     //   2635: ddiv
/*      */     //   2636: dstore #167
/*      */     //   2638: aload #18
/*      */     //   2640: iconst_0
/*      */     //   2641: daload
/*      */     //   2642: dstore #165
/*      */     //   2644: dconst_1
/*      */     //   2645: dload #165
/*      */     //   2647: ddiv
/*      */     //   2648: dstore #163
/*      */     //   2650: aload #19
/*      */     //   2652: iconst_0
/*      */     //   2653: daload
/*      */     //   2654: dstore #161
/*      */     //   2656: dconst_1
/*      */     //   2657: dload #161
/*      */     //   2659: ddiv
/*      */     //   2660: dload #163
/*      */     //   2662: dload #167
/*      */     //   2664: invokestatic Scale : (DDD)V
/*      */     //   2667: ldc2_w -90.0
/*      */     //   2670: invokestatic XRotate : (D)V
/*      */     //   2673: dload #35
/*      */     //   2675: dneg
/*      */     //   2676: invokestatic YRotate : (D)V
/*      */     //   2679: dload #33
/*      */     //   2681: invokestatic XRotate : (D)V
/*      */     //   2684: dload #31
/*      */     //   2686: dneg
/*      */     //   2687: dload #29
/*      */     //   2689: dsub
/*      */     //   2690: dstore #153
/*      */     //   2692: dconst_0
/*      */     //   2693: dconst_0
/*      */     //   2694: dload #153
/*      */     //   2696: invokestatic Translate : (DDD)V
/*      */     //   2699: dload #29
/*      */     //   2701: invokestatic Perspective : (D)V
/*      */     //   2704: aload #44
/*      */     //   2706: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2709: astore #151
/*      */     //   2711: aload #45
/*      */     //   2713: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2716: astore #149
/*      */     //   2718: aload #46
/*      */     //   2720: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2723: aload #149
/*      */     //   2725: aload #151
/*      */     //   2727: aload #6
/*      */     //   2729: iload #7
/*      */     //   2731: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2736: invokestatic PerspWindow : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2739: aload #47
/*      */     //   2741: invokestatic Rf_nrows : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2744: iconst_m1
/*      */     //   2745: iadd
/*      */     //   2746: istore #145
/*      */     //   2748: aload #47
/*      */     //   2750: invokestatic Rf_ncols : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2753: iconst_m1
/*      */     //   2754: iadd
/*      */     //   2755: istore #143
/*      */     //   2757: iload #145
/*      */     //   2759: iload #143
/*      */     //   2761: imul
/*      */     //   2762: istore #142
/*      */     //   2764: bipush #14
/*      */     //   2766: iload #142
/*      */     //   2768: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   2771: astore #43
/*      */     //   2773: aload #43
/*      */     //   2775: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2778: pop
/*      */     //   2779: aload #47
/*      */     //   2781: invokestatic Rf_nrows : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2784: iconst_m1
/*      */     //   2785: iadd
/*      */     //   2786: istore #140
/*      */     //   2788: aload #47
/*      */     //   2790: invokestatic Rf_ncols : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2793: iconst_m1
/*      */     //   2794: iadd
/*      */     //   2795: istore #138
/*      */     //   2797: iload #140
/*      */     //   2799: iload #138
/*      */     //   2801: imul
/*      */     //   2802: istore #137
/*      */     //   2804: bipush #13
/*      */     //   2806: iload #137
/*      */     //   2808: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   2811: astore #42
/*      */     //   2813: aload #42
/*      */     //   2815: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   2818: pop
/*      */     //   2819: aload #42
/*      */     //   2821: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2824: astore #135
/*      */     //   2826: aload #43
/*      */     //   2828: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2831: astore #133
/*      */     //   2833: aload #47
/*      */     //   2835: invokestatic Rf_ncols : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2838: istore #132
/*      */     //   2840: aload #47
/*      */     //   2842: invokestatic Rf_nrows : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2845: istore #131
/*      */     //   2847: aload #48
/*      */     //   2849: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2852: astore #129
/*      */     //   2854: aload #49
/*      */     //   2856: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2859: astore #127
/*      */     //   2861: aload #47
/*      */     //   2863: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2866: aload #127
/*      */     //   2868: aload #129
/*      */     //   2870: iload #131
/*      */     //   2872: iload #132
/*      */     //   2874: aload #133
/*      */     //   2876: aload #135
/*      */     //   2878: invokestatic DepthOrder : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2881: iconst_1
/*      */     //   2882: aload #6
/*      */     //   2884: iload #7
/*      */     //   2886: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2891: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2894: iload #12
/*      */     //   2896: ifne -> 2902
/*      */     //   2899: goto -> 3209
/*      */     //   2902: aload #44
/*      */     //   2904: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2907: astore #123
/*      */     //   2909: aload #45
/*      */     //   2911: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2914: astore #121
/*      */     //   2916: aload #46
/*      */     //   2918: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2921: astore #119
/*      */     //   2923: iconst_0
/*      */     //   2924: aload #119
/*      */     //   2926: aload #121
/*      */     //   2928: aload #123
/*      */     //   2930: new org/renjin/gcc/runtime/BytePtr
/*      */     //   2933: dup
/*      */     //   2934: aload #8
/*      */     //   2936: iconst_0
/*      */     //   2937: invokespecial <init> : ([BI)V
/*      */     //   2940: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   2943: aload #6
/*      */     //   2945: iload #7
/*      */     //   2947: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   2952: invokestatic PerspBox : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   2955: iload #11
/*      */     //   2957: ifne -> 2963
/*      */     //   2960: goto -> 3209
/*      */     //   2963: aload #39
/*      */     //   2965: iconst_0
/*      */     //   2966: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2969: astore_3
/*      */     //   2970: aload #38
/*      */     //   2972: iconst_0
/*      */     //   2973: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2976: astore_2
/*      */     //   2977: aload #37
/*      */     //   2979: iconst_0
/*      */     //   2980: invokestatic STRING_ELT : (Lorg/renjin/sexp/SEXP;I)Lorg/renjin/sexp/SEXP;
/*      */     //   2983: astore_1
/*      */     //   2984: aload_1
/*      */     //   2985: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   2988: istore #118
/*      */     //   2990: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   2993: astore #115
/*      */     //   2995: aload_1
/*      */     //   2996: aload #115
/*      */     //   2998: if_acmpeq -> 3016
/*      */     //   3001: goto -> 3004
/*      */     //   3004: aload_1
/*      */     //   3005: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   3008: astore #116
/*      */     //   3010: iconst_0
/*      */     //   3011: istore #117
/*      */     //   3013: goto -> 3035
/*      */     //   3016: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3019: dup
/*      */     //   3020: ldc_w ' '
/*      */     //   3023: invokevirtual getBytes : ()[B
/*      */     //   3026: iconst_0
/*      */     //   3027: invokespecial <init> : ([BI)V
/*      */     //   3030: astore #116
/*      */     //   3032: iconst_0
/*      */     //   3033: istore #117
/*      */     //   3035: aload_2
/*      */     //   3036: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3039: istore #114
/*      */     //   3041: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   3044: astore #111
/*      */     //   3046: aload_2
/*      */     //   3047: aload #111
/*      */     //   3049: if_acmpeq -> 3067
/*      */     //   3052: goto -> 3055
/*      */     //   3055: aload_2
/*      */     //   3056: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   3059: astore #112
/*      */     //   3061: iconst_0
/*      */     //   3062: istore #113
/*      */     //   3064: goto -> 3086
/*      */     //   3067: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3070: dup
/*      */     //   3071: ldc_w ' '
/*      */     //   3074: invokevirtual getBytes : ()[B
/*      */     //   3077: iconst_0
/*      */     //   3078: invokespecial <init> : ([BI)V
/*      */     //   3081: astore #112
/*      */     //   3083: iconst_0
/*      */     //   3084: istore #113
/*      */     //   3086: aload_3
/*      */     //   3087: invokestatic Rf_getCharCE : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3090: istore #110
/*      */     //   3092: getstatic org/renjin/gnur/api/Rinternals.R_NaString : Lorg/renjin/sexp/SEXP;
/*      */     //   3095: astore #107
/*      */     //   3097: aload_3
/*      */     //   3098: aload #107
/*      */     //   3100: if_acmpeq -> 3118
/*      */     //   3103: goto -> 3106
/*      */     //   3106: aload_3
/*      */     //   3107: invokestatic R_CHAR : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/BytePtr;
/*      */     //   3110: astore #108
/*      */     //   3112: iconst_0
/*      */     //   3113: istore #109
/*      */     //   3115: goto -> 3137
/*      */     //   3118: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3121: dup
/*      */     //   3122: ldc_w ' '
/*      */     //   3125: invokevirtual getBytes : ()[B
/*      */     //   3128: iconst_0
/*      */     //   3129: invokespecial <init> : ([BI)V
/*      */     //   3132: astore #108
/*      */     //   3134: iconst_0
/*      */     //   3135: istore #109
/*      */     //   3137: aload #44
/*      */     //   3139: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3142: astore #105
/*      */     //   3144: aload #45
/*      */     //   3146: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3149: astore #103
/*      */     //   3151: aload #46
/*      */     //   3153: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3156: aload #103
/*      */     //   3158: aload #105
/*      */     //   3160: aload #108
/*      */     //   3162: iload #109
/*      */     //   3164: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3169: iload #110
/*      */     //   3171: aload #112
/*      */     //   3173: iload #113
/*      */     //   3175: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3180: iload #114
/*      */     //   3182: aload #116
/*      */     //   3184: iload #117
/*      */     //   3186: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3191: iload #118
/*      */     //   3193: iload #10
/*      */     //   3195: iload #9
/*      */     //   3197: aload #6
/*      */     //   3199: iload #7
/*      */     //   3201: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3206: invokestatic PerspAxes : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3209: aload #40
/*      */     //   3211: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3214: invokeinterface getInt : ()I
/*      */     //   3219: istore #98
/*      */     //   3221: aload #41
/*      */     //   3223: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3226: astore #96
/*      */     //   3228: aload #17
/*      */     //   3230: iconst_0
/*      */     //   3231: daload
/*      */     //   3232: dstore #94
/*      */     //   3234: dload #23
/*      */     //   3236: dload #94
/*      */     //   3238: ddiv
/*      */     //   3239: dstore #92
/*      */     //   3241: aload #18
/*      */     //   3243: iconst_0
/*      */     //   3244: daload
/*      */     //   3245: dstore #90
/*      */     //   3247: dconst_1
/*      */     //   3248: dload #90
/*      */     //   3250: ddiv
/*      */     //   3251: dstore #88
/*      */     //   3253: aload #19
/*      */     //   3255: iconst_0
/*      */     //   3256: daload
/*      */     //   3257: dstore #86
/*      */     //   3259: dconst_1
/*      */     //   3260: dload #86
/*      */     //   3262: ddiv
/*      */     //   3263: dstore #84
/*      */     //   3265: aload #42
/*      */     //   3267: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3270: astore #82
/*      */     //   3272: aload #47
/*      */     //   3274: invokestatic Rf_ncols : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3277: istore #81
/*      */     //   3279: aload #47
/*      */     //   3281: invokestatic Rf_nrows : (Lorg/renjin/sexp/SEXP;)I
/*      */     //   3284: istore #80
/*      */     //   3286: aload #48
/*      */     //   3288: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3291: astore #78
/*      */     //   3293: aload #49
/*      */     //   3295: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3298: astore #76
/*      */     //   3300: aload #47
/*      */     //   3302: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3305: aload #76
/*      */     //   3307: aload #78
/*      */     //   3309: iload #80
/*      */     //   3311: iload #81
/*      */     //   3313: aload #82
/*      */     //   3315: dload #84
/*      */     //   3317: dload #88
/*      */     //   3319: dload #92
/*      */     //   3321: aload #96
/*      */     //   3323: iload #13
/*      */     //   3325: iload #98
/*      */     //   3327: invokestatic DrawFacets : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;DDDLorg/renjin/gcc/runtime/Ptr;II)V
/*      */     //   3330: iload #12
/*      */     //   3332: ifne -> 3338
/*      */     //   3335: goto -> 3391
/*      */     //   3338: aload #44
/*      */     //   3340: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3343: astore #72
/*      */     //   3345: aload #45
/*      */     //   3347: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3350: astore #70
/*      */     //   3352: aload #46
/*      */     //   3354: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3357: astore #68
/*      */     //   3359: iconst_1
/*      */     //   3360: aload #68
/*      */     //   3362: aload #70
/*      */     //   3364: aload #72
/*      */     //   3366: new org/renjin/gcc/runtime/BytePtr
/*      */     //   3369: dup
/*      */     //   3370: aload #8
/*      */     //   3372: iconst_0
/*      */     //   3373: invokespecial <init> : ([BI)V
/*      */     //   3376: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   3379: aload #6
/*      */     //   3381: iload #7
/*      */     //   3383: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3388: invokestatic PerspBox : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3391: iconst_0
/*      */     //   3392: aload #6
/*      */     //   3394: iload #7
/*      */     //   3396: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3401: invokestatic Rf_GMode : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3404: aload #6
/*      */     //   3406: iload #7
/*      */     //   3408: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3413: invokestatic Rf_GRestorePars : (Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   3416: bipush #14
/*      */     //   3418: bipush #16
/*      */     //   3420: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   3423: astore #49
/*      */     //   3425: aload #49
/*      */     //   3427: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3430: pop
/*      */     //   3431: bipush #13
/*      */     //   3433: iconst_2
/*      */     //   3434: invokestatic Rf_allocVector : (II)Lorg/renjin/sexp/SEXP;
/*      */     //   3437: astore #48
/*      */     //   3439: aload #48
/*      */     //   3441: invokestatic Rf_protect : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3444: pop
/*      */     //   3445: iconst_0
/*      */     //   3446: istore #16
/*      */     //   3448: goto -> 3525
/*      */     //   3451: iconst_0
/*      */     //   3452: istore #15
/*      */     //   3454: goto -> 3513
/*      */     //   3457: aload #49
/*      */     //   3459: invokestatic REAL : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3462: astore #66
/*      */     //   3464: iload #15
/*      */     //   3466: iconst_4
/*      */     //   3467: imul
/*      */     //   3468: iload #16
/*      */     //   3470: iadd
/*      */     //   3471: bipush #8
/*      */     //   3473: imul
/*      */     //   3474: istore #62
/*      */     //   3476: aload #66
/*      */     //   3478: astore #60
/*      */     //   3480: iconst_0
/*      */     //   3481: iload #62
/*      */     //   3483: iadd
/*      */     //   3484: istore #61
/*      */     //   3486: invokestatic get__plot3d$VT : ()[D
/*      */     //   3489: iload #16
/*      */     //   3491: iconst_4
/*      */     //   3492: imul
/*      */     //   3493: iload #15
/*      */     //   3495: iadd
/*      */     //   3496: daload
/*      */     //   3497: dstore #58
/*      */     //   3499: aload #60
/*      */     //   3501: iload #61
/*      */     //   3503: dload #58
/*      */     //   3505: invokeinterface setDouble : (ID)V
/*      */     //   3510: iinc #15, 1
/*      */     //   3513: iload #15
/*      */     //   3515: iconst_3
/*      */     //   3516: if_icmple -> 3457
/*      */     //   3519: goto -> 3522
/*      */     //   3522: iinc #16, 1
/*      */     //   3525: iload #16
/*      */     //   3527: iconst_3
/*      */     //   3528: if_icmple -> 3451
/*      */     //   3531: goto -> 3534
/*      */     //   3534: aload #48
/*      */     //   3536: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3539: iconst_0
/*      */     //   3540: iconst_4
/*      */     //   3541: invokeinterface setInt : (II)V
/*      */     //   3546: aload #48
/*      */     //   3548: invokestatic INTEGER : (Lorg/renjin/sexp/SEXP;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   3551: iconst_4
/*      */     //   3552: iconst_4
/*      */     //   3553: invokeinterface setInt : (II)V
/*      */     //   3558: getstatic org/renjin/gnur/api/Rinternals.R_DimSymbol : Lorg/renjin/sexp/SEXP;
/*      */     //   3561: astore #51
/*      */     //   3563: aload #49
/*      */     //   3565: aload #51
/*      */     //   3567: aload #48
/*      */     //   3569: invokestatic Rf_setAttrib : (Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;Lorg/renjin/sexp/SEXP;)Lorg/renjin/sexp/SEXP;
/*      */     //   3572: pop
/*      */     //   3573: aload #49
/*      */     //   3575: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1075	-> 262
/*      */     //   #1080	-> 292
/*      */     //   #1081	-> 297
/*      */     //   #1082	-> 309
/*      */     //   #1084	-> 349
/*      */     //   #1085	-> 366
/*      */     //   #1085	-> 378
/*      */     //   #1086	-> 435
/*      */     //   #1088	-> 440
/*      */     //   #1089	-> 457
/*      */     //   #1089	-> 469
/*      */     //   #1090	-> 526
/*      */     //   #1092	-> 531
/*      */     //   #1093	-> 548
/*      */     //   #1093	-> 559
/*      */     //   #1093	-> 591
/*      */     //   #1094	-> 623
/*      */     //   #1095	-> 680
/*      */     //   #1097	-> 685
/*      */     //   #1098	-> 702
/*      */     //   #1098	-> 714
/*      */     //   #1099	-> 771
/*      */     //   #1101	-> 776
/*      */     //   #1102	-> 793
/*      */     //   #1102	-> 805
/*      */     //   #1103	-> 862
/*      */     //   #1105	-> 867
/*      */     //   #1106	-> 884
/*      */     //   #1106	-> 896
/*      */     //   #1107	-> 953
/*      */     //   #1111	-> 958
/*      */     //   #1112	-> 998
/*      */     //   #1113	-> 1038
/*      */     //   #1114	-> 1078
/*      */     //   #1115	-> 1118
/*      */     //   #1116	-> 1158
/*      */     //   #1118	-> 1198
/*      */     //   #1119	-> 1212
/*      */     //   #1120	-> 1226
/*      */     //   #1121	-> 1240
/*      */     //   #1122	-> 1254
/*      */     //   #1123	-> 1268
/*      */     //   #1124	-> 1282
/*      */     //   #1125	-> 1293
/*      */     //   #1126	-> 1304
/*      */     //   #1127	-> 1318
/*      */     //   #1128	-> 1332
/*      */     //   #1129	-> 1347
/*      */     //   #1130	-> 1361
/*      */     //   #1131	-> 1375
/*      */     //   #1132	-> 1389
/*      */     //   #1133	-> 1403
/*      */     //   #1134	-> 1414
/*      */     //   #1135	-> 1425
/*      */     //   #1136	-> 1436
/*      */     //   #1136	-> 1449
/*      */     //   #1137	-> 1460
/*      */     //   #1138	-> 1500
/*      */     //   #1138	-> 1513
/*      */     //   #1139	-> 1524
/*      */     //   #1140	-> 1564
/*      */     //   #1140	-> 1577
/*      */     //   #1141	-> 1588
/*      */     //   #1143	-> 1628
/*      */     //   #1143	-> 1640
/*      */     //   #1143	-> 1651
/*      */     //   #1144	-> 1655
/*      */     //   #1144	-> 1666
/*      */     //   #1144	-> 1677
/*      */     //   #1145	-> 1689
/*      */     //   #1147	-> 1696
/*      */     //   #1149	-> 1700
/*      */     //   #1151	-> 1708
/*      */     //   #1152	-> 1714
/*      */     //   #1152	-> 1731
/*      */     //   #1153	-> 1737
/*      */     //   #1153	-> 1754
/*      */     //   #1154	-> 1760
/*      */     //   #1159	-> 1778
/*      */     //   #1159	-> 1789
/*      */     //   #1159	-> 1800
/*      */     //   #1159	-> 1811
/*      */     //   #1159	-> 1822
/*      */     //   #1160	-> 1832
/*      */     //   #1161	-> 1842
/*      */     //   #1162	-> 1882
/*      */     //   #1162	-> 1893
/*      */     //   #1163	-> 1903
/*      */     //   #1164	-> 1959
/*      */     //   #1165	-> 1974
/*      */     //   #1166	-> 1977
/*      */     //   #1166	-> 1992
/*      */     //   #1167	-> 2000
/*      */     //   #1168	-> 2056
/*      */     //   #1168	-> 2071
/*      */     //   #1168	-> 2079
/*      */     //   #1169	-> 2088
/*      */     //   #1171	-> 2144
/*      */     //   #1177	-> 2152
/*      */     //   #1178	-> 2188
/*      */     //   #1179	-> 2195
/*      */     //   #1179	-> 2203
/*      */     //   #1180	-> 2260
/*      */     //   #1180	-> 2282
/*      */     //   #1181	-> 2286
/*      */     //   #1182	-> 2322
/*      */     //   #1183	-> 2333
/*      */     //   #1185	-> 2390
/*      */     //   #1186	-> 2403
/*      */     //   #1187	-> 2415
/*      */     //   #1188	-> 2428
/*      */     //   #1189	-> 2440
/*      */     //   #1190	-> 2477
/*      */     //   #1193	-> 2540
/*      */     //   #1194	-> 2549
/*      */     //   #1197	-> 2556
/*      */     //   #1198	-> 2562
/*      */     //   #1197	-> 2569
/*      */     //   #1197	-> 2572
/*      */     //   #1202	-> 2582
/*      */     //   #1203	-> 2599
/*      */     //   #1204	-> 2625
/*      */     //   #1205	-> 2667
/*      */     //   #1206	-> 2673
/*      */     //   #1207	-> 2679
/*      */     //   #1208	-> 2684
/*      */     //   #1209	-> 2699
/*      */     //   #1217	-> 2704
/*      */     //   #1223	-> 2739
/*      */     //   #1224	-> 2779
/*      */     //   #1225	-> 2819
/*      */     //   #1228	-> 2881
/*      */     //   #1230	-> 2894
/*      */     //   #1232	-> 2902
/*      */     //   #1233	-> 2955
/*      */     //   #1234	-> 2963
/*      */     //   #1235	-> 2977
/*      */     //   #1236	-> 2984
/*      */     //   #1239	-> 2990
/*      */     //   #1236	-> 2995
/*      */     //   #1236	-> 3004
/*      */     //   #1236	-> 3016
/*      */     //   #1236	-> 3035
/*      */     //   #1238	-> 3041
/*      */     //   #1236	-> 3046
/*      */     //   #1236	-> 3055
/*      */     //   #1236	-> 3067
/*      */     //   #1236	-> 3086
/*      */     //   #1237	-> 3092
/*      */     //   #1236	-> 3097
/*      */     //   #1236	-> 3106
/*      */     //   #1236	-> 3118
/*      */     //   #1236	-> 3137
/*      */     //   #1246	-> 3209
/*      */     //   #1244	-> 3214
/*      */     //   #1250	-> 3330
/*      */     //   #1251	-> 3338
/*      */     //   #1252	-> 3391
/*      */     //   #1254	-> 3404
/*      */     //   #1255	-> 3416
/*      */     //   #1257	-> 3416
/*      */     //   #1258	-> 3431
/*      */     //   #1259	-> 3445
/*      */     //   #1260	-> 3451
/*      */     //   #1261	-> 3457
/*      */     //   #1260	-> 3510
/*      */     //   #1260	-> 3513
/*      */     //   #1259	-> 3522
/*      */     //   #1259	-> 3525
/*      */     //   #1262	-> 3534
/*      */     //   #1263	-> 3546
/*      */     //   #1264	-> 3558
/*      */     //   #1265	-> 3573
/*      */     //   #1266	-> 3573
/*      */     //   #0	-> 3575
/*      */     //   #1266	-> 3575
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	3576	0	args	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	1	zl	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	2	yl	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	3	xl	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	4	s	D
/*      */     //   0	3576	6	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	3576	7	dd$offset	I
/*      */     //   0	3576	8	EdgeDone	[B
/*      */     //   0	3576	9	tickType	I
/*      */     //   0	3576	10	nTicks	I
/*      */     //   0	3576	11	doaxes	I
/*      */     //   0	3576	12	dobox	I
/*      */     //   0	3576	13	ncol	I
/*      */     //   0	3576	14	scale	I
/*      */     //   0	3576	15	j	I
/*      */     //   0	3576	16	i	I
/*      */     //   0	3576	17	zs	[D
/*      */     //   0	3576	18	ys	[D
/*      */     //   0	3576	19	xs	[D
/*      */     //   0	3576	20	zc	[D
/*      */     //   0	3576	21	yc	[D
/*      */     //   0	3576	22	xc	[D
/*      */     //   0	3576	23	expand	D
/*      */     //   0	3576	25	lphi	D
/*      */     //   0	3576	27	ltheta	D
/*      */     //   0	3576	29	d	D
/*      */     //   0	3576	31	r	D
/*      */     //   0	3576	33	phi	D
/*      */     //   0	3576	35	theta	D
/*      */     //   0	3576	37	zlab	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	38	ylab	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	39	xlab	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	40	border	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	41	col	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	42	indx	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	43	depth	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	44	zlim	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	45	ylim	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	46	xlim	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	47	z	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	48	y	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	49	x	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	51	R_DimSymbol$179	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	86	xs$178	D
/*      */     //   0	3576	90	ys$177	D
/*      */     //   0	3576	94	zs$176	D
/*      */     //   0	3576	107	R_NaString$175	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	108	iftmp$174	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	3576	109	iftmp$174$offset	I
/*      */     //   0	3576	111	R_NaString$173	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	112	iftmp$172	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	3576	113	iftmp$172$offset	I
/*      */     //   0	3576	115	R_NaString$171	Lorg/renjin/sexp/SEXP;
/*      */     //   0	3576	116	iftmp$170	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	3576	117	iftmp$170$offset	I
/*      */     //   0	3576	161	xs$169	D
/*      */     //   0	3576	165	ys$168	D
/*      */     //   0	3576	169	zs$167	D
/*      */     //   0	3576	173	xc$166	D
/*      */     //   0	3576	177	yc$165	D
/*      */     //   0	3576	181	zc$164	D
/*      */     //   0	3576	183	DoLighting$163	I
/*      */     //   0	3576	214	R_NaInt$162	I
/*      */     //   0	3576	217	R_NaInt$161	I
/*      */     //   0	3576	218	R_NaInt$160	I
/*      */     //   0	3576	228	zs$159	D
/*      */     //   0	3576	230	ys$158	D
/*      */     //   0	3576	233	Shade$157	D
/*      */     //   0	3576	237	Shade$156	D
/*      */     //   0	3576	240	Shade$155	D
/*      */     //   0	3576	258	Shade$154	D
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void FindCorners(double width, double height, SEXP label, double x0, double y0, double x1, double y1, Ptr dd) {
/* 1276 */     delta = height / width;
/* 1277 */     dx = graphics__.Rf_GConvertXUnits(x1 - x0, 12, 13, dd) * delta;
/* 1278 */     dy = graphics__.Rf_GConvertYUnits(y1 - y0, 12, 13, dd) * delta;
/* 1279 */     dx = graphics__.Rf_GConvertYUnits(dx, 13, 12, dd);
/* 1280 */     dy = graphics__.Rf_GConvertXUnits(dy, 13, 12, dd);
/*      */     
/* 1282 */     Ptr ptr8 = Rinternals2.REAL(label); double d8 = x0 + dy; ptr8.setDouble(0, d8);
/* 1283 */     Ptr ptr7 = Rinternals2.REAL(label); double d7 = y0 - dx; ptr7.setDouble(32, d7);
/* 1284 */     Ptr ptr6 = Rinternals2.REAL(label); double d6 = x0 - dy; ptr6.setDouble(8, d6);
/* 1285 */     Ptr ptr5 = Rinternals2.REAL(label); double d5 = y0 + dx; ptr5.setDouble(40, d5);
/* 1286 */     Ptr ptr4 = Rinternals2.REAL(label); double d4 = x1 + dy; ptr4.setDouble(24, d4);
/* 1287 */     Ptr ptr3 = Rinternals2.REAL(label); double d3 = y1 - dx; ptr3.setDouble(56, d3);
/* 1288 */     Ptr ptr2 = Rinternals2.REAL(label); double d2 = x1 - dy; ptr2.setDouble(16, d2);
/* 1289 */     Ptr ptr1 = Rinternals2.REAL(label); double d1 = y1 + dx; ptr1.setDouble(48, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int TestLabelIntersection(SEXP label1, SEXP label2) {
/* 1299 */     for (By = 0.0D, Ay = 0.0D, Bx = 0.0D, Ax = 0.0D, i = 0, i = 0; i <= 3; i++) {
/* 1300 */       Ptr ptr8 = Rinternals2.REAL(label1); int i5 = i * 8; Ptr ptr7 = ptr8; int i4 = 0 + i5; Ax = ptr7.getDouble(i4);
/* 1301 */       Ptr ptr6 = Rinternals2.REAL(label1); int i3 = (i + 4) * 8; Ptr ptr5 = ptr6; int i2 = 0 + i3; Ay = ptr5.getDouble(i2);
/* 1302 */       Ptr ptr4 = Rinternals2.REAL(label1); int i1 = (i + 1) % 4 * 8; Ptr ptr3 = ptr4; int n = 0 + i1; Bx = ptr3.getDouble(n);
/* 1303 */       Ptr ptr2 = Rinternals2.REAL(label1); int m = ((i + 1) % 4 + 4) * 8; Ptr ptr1 = ptr2; int k = 0 + m; By = ptr1.getDouble(k);
/* 1304 */       for (j = 0; j <= 3; ) {
/* 1305 */         Ptr ptr16 = Rinternals2.REAL(label2); int i13 = j * 8; Ptr ptr15 = ptr16; int i12 = 0 + i13; ax = ptr15.getDouble(i12);
/* 1306 */         Ptr ptr14 = Rinternals2.REAL(label2); int i11 = (j + 4) * 8; Ptr ptr13 = ptr14; int i10 = 0 + i11; ay = ptr13.getDouble(i10);
/* 1307 */         Ptr ptr12 = Rinternals2.REAL(label2); int i9 = (j + 1) % 4 * 8; Ptr ptr11 = ptr12; int i8 = 0 + i9; bx = ptr11.getDouble(i8);
/* 1308 */         Ptr ptr10 = Rinternals2.REAL(label2); int i7 = ((j + 1) % 4 + 4) * 8; Ptr ptr9 = ptr10; int i6 = 0 + i7; by = ptr9.getDouble(i6);
/*      */         
/* 1310 */         double d14 = Bx * by, d13 = Bx * ay, d12 = d14 - d13, d11 = Ax * by, d10 = d12 - d11, d9 = Ax * ay, d8 = d10 + d9, d7 = bx * By, d6 = d8 - d7, d5 = bx * Ay, d4 = d6 + d5, d3 = ax * By, d2 = d4 + d3, d1 = ax * Ay; dom = d2 - d1;
/* 1311 */         if (dom != 0.0D)
/*      */         
/*      */         { 
/*      */ 
/*      */           
/* 1316 */           double d24 = bx * Ay, d23 = ax * Ay, d22 = d24 - d23, d21 = ay * bx, d20 = d22 - d21, d19 = Ax * by, d18 = d20 - d19, d17 = Ax * ay, d16 = d18 + d17, d15 = by * ax; result1 = (d16 + d15) / dom;
/*      */           
/* 1318 */           if (bx - ax != 0.0D)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1325 */             double d26 = (Bx - Ax) * result1 + Ax - ax, d25 = bx - ax; result2 = d26 / d25; } else if (by - ay != 0.0D) { double d26 = (By - Ay) * result1 + Ay - ay, d25 = by - ay; result2 = d26 / d25; } else { result2 = -1.0D; }
/*      */            }
/*      */         else { result1 = -1.0D; result2 = -1.0D; }
/* 1328 */          if (result1 < 0.0D || result1 > 1.0D) { iftmp$126 = 0; } else { iftmp$126 = 1; }  l1 = iftmp$126;
/* 1329 */         if (result2 < 0.0D || result2 > 1.0D) { iftmp$127 = 0; } else { iftmp$127 = 1; }  l2 = iftmp$127;
/* 1330 */         if (l1 == 0 || l2 == 0) { j++; continue; }  boolean bool = true;
/*      */         // Byte code: goto -> 737
/*      */       } 
/*      */     } 
/* 1334 */     return 0;
/*      */   }
/*      */   
/*      */   public static int LabelInsideWindow(SEXP label, Ptr dd) {
/*      */     boolean bool;
/* 1339 */     y = new double[1]; x = new double[1]; i = 0;
/*      */     
/*      */     while (true) {
/* 1342 */       if (i > 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1354 */         boolean bool1 = false; break;
/*      */       }  Ptr ptr4 = Rinternals2.REAL(label); int n = i * 8; Ptr ptr3 = ptr4; int m = 0 + n; x$115 = ptr3.getDouble(m); x[0] = x$115; Ptr ptr2 = Rinternals2.REAL(label); int k = (i + 4) * 8; Ptr ptr1 = ptr2; int j = 0 + k; y$117 = ptr1.getDouble(j); y[0] = y$117; graphics__.Rf_GConvert((Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 12, 1, dd); if (x[0] >= 0.0D && x[0] <= 1.0D && y[0] >= 0.0D && y[0] <= 1.0D) {
/*      */         i++;
/*      */         continue;
/*      */       } 
/*      */       bool = true;
/*      */       break;
/*      */     } 
/* 1362 */     return bool; } public static int findGapUp(Ptr xxx, Ptr yyy, int ns, double labelDistance, Ptr dd) { distanceSum = 0.0D;
/* 1363 */     n = 0;
/* 1364 */     jjj = 1;
/* 1365 */     while (jjj < ns && distanceSum < labelDistance) {
/*      */ 
/*      */ 
/*      */       
/* 1369 */       int i4 = jjj * 8; Ptr ptr4 = xxx; int i3 = i4; double d4 = ptr4.getDouble(i3); int i2 = (jjj - n + -1) * 8; Ptr ptr3 = xxx; int i1 = i2; double d3 = ptr3.getDouble(i1); dX = d4 - d3;
/* 1370 */       int m = jjj * 8; Ptr ptr2 = yyy; int k = m; double d2 = ptr2.getDouble(k); int j = (jjj - n + -1) * 8; Ptr ptr1 = yyy; int i = j; double d1 = ptr1.getDouble(i); dY = d2 - d1;
/* 1371 */       dXC = graphics__.Rf_GConvertXUnits(dX, 12, 13, dd);
/* 1372 */       dYC = graphics__.Rf_GConvertYUnits(dY, 12, 13, dd);
/* 1373 */       distanceSum = Mathlib.hypot(dXC, dYC);
/* 1374 */       jjj++;
/* 1375 */       n++;
/*      */     } 
/* 1377 */     return (distanceSum >= labelDistance) ? 
/*      */ 
/*      */       
/* 1380 */       n : 0; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int findGapDown(Ptr xxx, Ptr yyy, int ns, double labelDistance, Ptr dd) {
/* 1388 */     distanceSum = 0.0D;
/* 1389 */     n = 0;
/* 1390 */     jjj = ns + -2;
/* 1391 */     while (jjj >= 0 && distanceSum < labelDistance) {
/*      */ 
/*      */ 
/*      */       
/* 1395 */       int i4 = jjj * 8; Ptr ptr4 = xxx; int i3 = i4; double d4 = ptr4.getDouble(i3); int i2 = (jjj + n + 1) * 8; Ptr ptr3 = xxx; int i1 = i2; double d3 = ptr3.getDouble(i1); dX = d4 - d3;
/* 1396 */       int m = jjj * 8; Ptr ptr2 = yyy; int k = m; double d2 = ptr2.getDouble(k); int j = (jjj + n + 1) * 8; Ptr ptr1 = yyy; int i = j; double d1 = ptr1.getDouble(i); dY = d2 - d1;
/* 1397 */       dXC = graphics__.Rf_GConvertXUnits(dX, 12, 13, dd);
/* 1398 */       dYC = graphics__.Rf_GConvertYUnits(dY, 12, 13, dd);
/* 1399 */       distanceSum = Mathlib.hypot(dXC, dYC);
/* 1400 */       jjj--;
/* 1401 */       n++;
/*      */     } 
/* 1403 */     return (distanceSum >= labelDistance) ? 
/*      */ 
/*      */       
/* 1406 */       n : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double distFromEdge(Ptr xxx, Ptr yyy, int iii, Ptr dd) {
/* 1421 */     double d11 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24); int i3 = iii * 8; Ptr ptr4 = yyy; int i2 = i3; double d10 = ptr4.getDouble(i2); double d9 = d11 - d10; int i1 = iii * 8; Ptr ptr3 = yyy; int n = i1; double d8 = ptr3.getDouble(n), d7 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16); double d6 = Rmath.Rf_fmin2(d8 - d7, d9), d5 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8); int m = iii * 8;
/*      */     Ptr ptr2 = xxx;
/*      */     int k = m;
/*      */     double d4 = ptr2.getDouble(k), d3 = d5 - d4;
/*      */     int j = iii * 8;
/*      */     Ptr ptr1 = xxx;
/*      */     int i = j;
/*      */     double d2 = ptr1.getDouble(i), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35700);
/* 1429 */     return Rmath.Rf_fmin2(Rmath.Rf_fmin2(d2 - d1, d3), d6); } public static int useStart(Ptr xxx, Ptr yyy, int ns, Ptr dd) { double d2 = distFromEdge(xxx, yyy, 0, dd); int i = ns + -1; double d1 = distFromEdge(xxx, yyy, i, dd); return (d2 >= d1) ? 
/*      */ 
/*      */       
/* 1432 */       0 : 1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void contour(SEXP x, int nx, SEXP y, int ny, SEXP z, double zc, SEXP labels, int cnum, int drawLabels, int method, double atom, Ptr dd) {
/* 1453 */     vy = new double[1]; vx = new double[1]; uy = new double[1]; ux = new double[1]; buffer = new byte[255]; seg = new Ptr[1]; jj = new int[1]; ii = new int[1]; gotLabel = 0; label1 = (SEXP)BytePtr.of(0).getArray(); labelHeight = 0.0D; avgGradient = 0.0D; labelDistance = 0.0D; iii = 0; squareSum = 0.0D; lowestVariance = 0.0D; n = 0; indx = 0; range = 0; yyy = BytePtr.of(0); yyy$offset = 0; xxx = BytePtr.of(0); xxx$offset = 0; start = BytePtr.of(0); start$offset = 0; seg[0] = BytePtr.of(0); seglist = BytePtr.of(0); seglist$offset = 0; ns = 0; jj[0] = 0; j = 0; ii[0] = 0; i = 0; vmax = BytePtr.of(0); vmax$offset = 0; range = 0; indx = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1464 */     label1 = Rinternals.Rf_protect(Rinternals.Rf_allocVector(14, 8));
/*      */ 
/*      */     
/* 1467 */     gotLabel = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1474 */     vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */     
/* 1476 */     Ptr ptr2 = Rinternals2.REAL(z), ptr1 = Rinternals2.REAL(y); Context.set__plot3d$ctr_SegDB(contourLines(Rinternals2.REAL(x), nx, ptr1, ny, ptr2, zc, atom)); Context.set__plot3d$ctr_SegDB$offset(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1485 */     for (i = 0; nx + -1 > i; i++)
/* 1486 */     { for (j = 0; ny + -1 > j;) { for (;; j++)
/* 1487 */         { ctr_SegDB$105 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$105$offset = Context.get__plot3d$ctr_SegDB$offset(); int m = (j * nx + i) * 4; Ptr ptr = ctr_SegDB$105; int k = ctr_SegDB$105$offset + m; seglist = ptr.getPointer(k); seglist$offset = 0; if (!seglist.pointerPlus(seglist$offset).isNull())
/* 1488 */           { double d2; DoublePtr doublePtr5; int i5, i6; double d3; DoublePtr doublePtr6; int i7, i8; double d4; DoublePtr doublePtr7; int i9, i10; double d5; DoublePtr doublePtr8; int i11, i12; ii[0] = i; jj[0] = j;
/* 1489 */             end = seglist; end$offset = seglist$offset; start = end; start$offset = end$offset;
/* 1490 */             ctr_SegDB$19 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$19$offset = Context.get__plot3d$ctr_SegDB$offset(); int i24 = (j * nx + i) * 4; Ptr ptr4 = ctr_SegDB$19; int i23 = ctr_SegDB$19$offset + i24; Ptr ptr3 = seglist.getPointer(seglist$offset); ptr4.setPointer(i23, ptr3);
/* 1491 */             xend = seglist.getDouble(seglist$offset + 20);
/* 1492 */             yend = seglist.getDouble(seglist$offset + 28); while (true) {
/* 1493 */               Ptr ptr6 = Rinternals2.REAL(y), ptr5 = Rinternals2.REAL(x); dir = ctr_segdir(xend, yend, ptr5, ptr6, (Ptr)new IntPtr(ii, 0), (Ptr)new IntPtr(jj, 0), nx, ny); if (dir == 0)
/*      */                 break; 
/* 1495 */               ctr_SegDB$20 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$20$offset = Context.get__plot3d$ctr_SegDB$offset(); int i30 = jj[0] * nx; ii$22 = ii[0]; int i29 = (i30 + ii$22) * 4; Ptr ptr10 = ctr_SegDB$20; int i28 = ctr_SegDB$20$offset + i29;
/*      */               
/* 1497 */               ctr_SegDB$23 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$23$offset = Context.get__plot3d$ctr_SegDB$offset(); int i27 = jj[0] * nx; ii$25 = ii[0]; int i26 = (i27 + ii$25) * 4; Ptr ptr9 = ctr_SegDB$23; int i25 = ctr_SegDB$23$offset + i26; Ptr ptr8 = ptr9.getPointer(i25), ptr7 = ctr_segupdate(xend, yend, dir, 1, ptr8, (Ptr)new PointerPtr(seg, 0)); ptr10.setPointer(i28, ptr7);
/* 1498 */               if (!seg[0].isNull()) {
/* 1499 */                 seg$27 = seg[0]; end.setPointer(end$offset, seg$27);
/* 1500 */                 end = seg[0]; end$offset = 0;
/* 1501 */                 xend = end.getDouble(end$offset + 20);
/* 1502 */                 yend = end.getDouble(end$offset + 28); continue;
/*      */               }  break;
/* 1504 */             }  end.setPointer(end$offset, BytePtr.of(0));
/* 1505 */             ii[0] = i; jj[0] = j;
/* 1506 */             xend = seglist.getDouble(seglist$offset + 4);
/* 1507 */             yend = seglist.getDouble(seglist$offset + 12); while (true) {
/* 1508 */               Ptr ptr6 = Rinternals2.REAL(y), ptr5 = Rinternals2.REAL(x); dir = ctr_segdir(xend, yend, ptr5, ptr6, (Ptr)new IntPtr(ii, 0), (Ptr)new IntPtr(jj, 0), nx, ny); if (dir == 0)
/*      */                 break; 
/* 1510 */               ctr_SegDB$28 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$28$offset = Context.get__plot3d$ctr_SegDB$offset(); int i30 = jj[0] * nx; ii$30 = ii[0]; int i29 = (i30 + ii$30) * 4; Ptr ptr10 = ctr_SegDB$28; int i28 = ctr_SegDB$28$offset + i29;
/*      */               
/* 1512 */               ctr_SegDB$31 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$31$offset = Context.get__plot3d$ctr_SegDB$offset(); int i27 = jj[0] * nx; ii$33 = ii[0]; int i26 = (i27 + ii$33) * 4; Ptr ptr9 = ctr_SegDB$31; int i25 = ctr_SegDB$31$offset + i26; Ptr ptr8 = ptr9.getPointer(i25), ptr7 = ctr_segupdate(xend, yend, dir, 0, ptr8, (Ptr)new PointerPtr(seg, 0)); ptr10.setPointer(i28, ptr7);
/* 1513 */               if (!seg[0].isNull()) {
/* 1514 */                 seg[0].setPointer(0, start.pointerPlus(start$offset));
/* 1515 */                 start = seg[0]; start$offset = 0;
/* 1516 */                 xend = start.getDouble(start$offset + 4);
/* 1517 */                 yend = start.getDouble(start$offset + 12); continue;
/*      */               } 
/*      */               break;
/*      */             } 
/* 1521 */             s = start; s$offset = start$offset;
/* 1522 */             ns = 0;
/*      */             
/* 1524 */             while (!s.pointerPlus(s$offset).isNull()) { ns$36 = ns; max_contour_segments$37 = Defn.max_contour_segments; if (Integer.compareUnsigned(ns$36, max_contour_segments$37) >= 0)
/* 1525 */                 break;  ns++;
/* 1526 */               s = s.getPointer(s$offset); s$offset = 0; }
/*      */             
/* 1528 */             ns$38 = ns; max_contour_segments$39 = Defn.max_contour_segments; if (ns$38 == max_contour_segments$39) {
/* 1529 */               max_contour_segments$40 = Defn.max_contour_segments; Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("contour(): circular/long seglist -- set %s > %d?\000".getBytes(), 0)), new Object[] { new BytePtr("options(\"max.contour.segments\")\000".getBytes(), 0), Integer.valueOf(max_contour_segments$40) });
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1537 */             vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/* 1538 */             DoublePtr doublePtr2 = DoublePtr.malloc((ns + 1) * 8); xxx$offset = 0;
/* 1539 */             DoublePtr doublePtr1 = DoublePtr.malloc((ns + 1) * 8); yyy$offset = 0;
/*      */             
/* 1541 */             s = start; s$offset = start$offset;
/* 1542 */             ns = 0;
/* 1543 */             int i22 = ns * 8; DoublePtr doublePtr12 = doublePtr2; int i21 = xxx$offset + i22; double d9 = s.getDouble(s$offset + 4); doublePtr12.setDouble(i21, d9);
/* 1544 */             int i20 = ns * 8; DoublePtr doublePtr11 = doublePtr1; int i19 = yyy$offset + i20; double d8 = s.getDouble(s$offset + 12); doublePtr11.setDouble(i19, d8); ns++;
/* 1545 */             while (!s.getPointer(s$offset).isNull()) { ns$45 = ns; max_contour_segments$46 = Defn.max_contour_segments; if (Integer.compareUnsigned(ns$45, max_contour_segments$46) >= 0)
/* 1546 */                 break;  s = s.getPointer(s$offset); s$offset = 0;
/* 1547 */               int i28 = ns * 8; DoublePtr doublePtr14 = doublePtr2; int i27 = xxx$offset + i28; double d11 = s.getDouble(s$offset + 4); doublePtr14.setDouble(i27, d11);
/* 1548 */               int i26 = ns * 8; DoublePtr doublePtr13 = doublePtr1; int i25 = yyy$offset + i26; double d10 = s.getDouble(s$offset + 12); doublePtr13.setDouble(i25, d10); ns++; }
/*      */             
/* 1550 */             int i18 = ns * 8; DoublePtr doublePtr10 = doublePtr2; int i17 = xxx$offset + i18; double d7 = s.getDouble(s$offset + 20); doublePtr10.setDouble(i17, d7);
/* 1551 */             int i16 = ns * 8; DoublePtr doublePtr9 = doublePtr1; int i15 = yyy$offset + i16; double d6 = s.getDouble(s$offset + 28); doublePtr9.setDouble(i15, d6); ns++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1563 */             if (drawLabels == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1832 */               graphics__.Rf_GPolyline(ns, doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), 12, dd); continue; }  enc = 0; buffer[0] = (byte)32; if (Rinternals.TYPEOF(labels) == 0) { lab = Rinternals.Rf_allocVector(14, 1); Rinternals.Rf_protect(lab); Rinternals2.REAL(lab).setDouble(0, zc); lab = plot__.Rf_labelformat(lab); BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(lab, 0)); Stdlib.strcpy((Ptr)new BytePtr(buffer, 1), (Ptr)bytePtr); } else { numl = Rinternals.Rf_length(labels); int i26 = cnum % numl; BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(labels, i26)); Stdlib.strcpy((Ptr)new BytePtr(buffer, 1), (Ptr)bytePtr); int i25 = cnum % numl; enc = Rinternals.Rf_getCharCE(Rinternals.STRING_ELT(labels, i25)); }  int i14 = Stdlib.strlen((Ptr)new BytePtr(buffer, 0)) + 1; buffer[i14] = (byte)0; int i13 = Stdlib.strlen((Ptr)new BytePtr(buffer, 0)); buffer[i13] = (byte)32; labelDistance = graphics__.Rf_GStrWidth((Ptr)new BytePtr(buffer, 0), enc, 13, dd); labelHeight = graphics__.Rf_GStrHeight((Ptr)new BytePtr(buffer, 0), enc, 13, dd); if (labelDistance <= 0.0D)
/*      */               continue;  switch (method) { case 0: if (useStart(doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), ns, dd) == 0) { indx = ns + -1; break; }  indx = 0; break;
/*      */               case 1: indx = 0; range = 0; gotLabel = 0; if (useStart(doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), ns, dd) == 0) { n = findGapDown(doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), ns, labelDistance, dd); iii = ns - n + -1; } else { iii = 0; n = findGapUp(doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), ns, labelDistance, dd); }  if (n <= 0)
/*      */                   break;  i12 = (iii + n) * 8; doublePtr8 = doublePtr1; i11 = yyy$offset + i12; d5 = doublePtr8.getDouble(i11); i10 = (iii + n) * 8; doublePtr7 = doublePtr2; i9 = xxx$offset + i10; d4 = doublePtr7.getDouble(i9); i8 = iii * 8; doublePtr6 = doublePtr1; i7 = yyy$offset + i8; d3 = doublePtr6.getDouble(i7); i6 = iii * 8; doublePtr5 = doublePtr2; i5 = xxx$offset + i6; d2 = doublePtr5.getDouble(i5); FindCorners(labelDistance, labelHeight, label1, d2, d3, d4, d5, dd); label2 = Context.get__plot3d$labelList(); result = 0; while (result == 0) { R_NilValue$51 = Rinternals.R_NilValue; if (label2 != R_NilValue$51) { SEXP sEXP = Rinternals.CAR(label2); result = TestLabelIntersection(label1, sEXP); label2 = Rinternals.CDR(label2); continue; }  break; }  if (result != 0)
/*      */                   break;  result = LabelInsideWindow(label1, dd); if (result != 0)
/*      */                   break;  indx = iii; range = n; gotLabel = 1; break;
/*      */               case 2:
/*      */                 lowestVariance = 9999999.0D; indx = 0; range = 0; gotLabel = 0; for (iii = 0; iii < ns; ) { distanceSum = 0.0D; avgGradient = 0.0D; squareSum = 0.0D; n = 0; jjj = iii + 1; while (ns + -1 > jjj && distanceSum < labelDistance) { int i40 = jjj * 8; DoublePtr doublePtr20 = doublePtr2; int i39 = xxx$offset + i40; double d17 = doublePtr20.getDouble(i39); int i38 = (jjj - n + -1) * 8; DoublePtr doublePtr19 = doublePtr2; int i37 = xxx$offset + i38; double d16 = doublePtr19.getDouble(i37); dX = d17 - d16; int i36 = jjj * 8; DoublePtr doublePtr18 = doublePtr1; int i35 = yyy$offset + i36; double d15 = doublePtr18.getDouble(i35); int i34 = (jjj - n + -1) * 8; DoublePtr doublePtr17 = doublePtr1; int i33 = yyy$offset + i34; double d14 = doublePtr17.getDouble(i33); dY = d15 - d14; dXC = graphics__.Rf_GConvertXUnits(dX, 12, 13, dd); dYC = graphics__.Rf_GConvertYUnits(dY, 12, 13, dd); distanceSum = Mathlib.hypot(dXC, dYC); int i32 = jjj * 8; DoublePtr doublePtr16 = doublePtr2; int i31 = xxx$offset + i32; double d13 = doublePtr16.getDouble(i31); int i30 = (jjj + -1) * 8; DoublePtr doublePtr15 = doublePtr2; int i29 = xxx$offset + i30; double d12 = doublePtr15.getDouble(i29); deltaX = d13 - d12; int i28 = jjj * 8; DoublePtr doublePtr14 = doublePtr1; int i27 = yyy$offset + i28; double d11 = doublePtr14.getDouble(i27); int i26 = (jjj + -1) * 8; DoublePtr doublePtr13 = doublePtr1; int i25 = yyy$offset + i26; double d10 = doublePtr13.getDouble(i25); deltaY = d11 - d10; if (deltaX == 0.0D)
/*      */                       deltaX = 1.0D;  avgGradient = deltaY / deltaX + avgGradient; squareSum = avgGradient * avgGradient + squareSum; jjj++; n++; }  if (distanceSum >= labelDistance) { int i32 = (iii + n) * 8; DoublePtr doublePtr16 = doublePtr1; int i31 = yyy$offset + i32; double d19 = doublePtr16.getDouble(i31); int i30 = (iii + n) * 8; DoublePtr doublePtr15 = doublePtr2; int i29 = xxx$offset + i30; double d18 = doublePtr15.getDouble(i29); int i28 = iii * 8; DoublePtr doublePtr14 = doublePtr1; int i27 = yyy$offset + i28; double d17 = doublePtr14.getDouble(i27); int i26 = iii * 8; DoublePtr doublePtr13 = doublePtr2; int i25 = xxx$offset + i26; double d16 = doublePtr13.getDouble(i25); FindCorners(labelDistance, labelHeight, label1, d16, d17, d18, d19, dd); label2 = Context.get__plot3d$labelList(); result = 0; while (result == 0) { R_NilValue$60 = Rinternals.R_NilValue; if (label2 != R_NilValue$60) { SEXP sEXP = Rinternals.CAR(label2); result = TestLabelIntersection(label1, sEXP); label2 = Rinternals.CDR(label2); continue; }  break; }  if (result == 0)
/*      */                       result = LabelInsideWindow(label1, dd);  double d15 = avgGradient * avgGradient, d14 = n, d13 = d15 / d14, d12 = squareSum - d13, d11 = n; variance = d12 / d11; double d10 = n; avgGradient /= d10; if (result == 0 && variance < lowestVariance) { lowestVariance = variance; indx = iii; range = n; }  if (lowestVariance < 9999999.0D)
/*      */                       gotLabel = 1;  iii++; }  break; }  break; }  if (method != 0) { if (indx > 0)
/*      */                 graphics__.Rf_GPolyline(indx + 1, doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), 12, dd);  if (ns + -1 - indx - range > 0) { indx$63 = indx; range$64 = range; int i64 = (indx$63 + range$64) * 8; DoublePtr doublePtr32 = doublePtr1; int i63 = yyy$offset + i64; indx$65 = indx; range$66 = range; int i62 = (indx$65 + range$66) * 8; DoublePtr doublePtr31 = doublePtr2; int i61 = xxx$offset + i62; graphics__.Rf_GPolyline(ns - indx - range, doublePtr31.pointerPlus(i61), doublePtr32.pointerPlus(i63), 12, dd); }  if (gotLabel == 0)
/*      */                 continue;  double d41 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8); int i60 = indx * 8; DoublePtr doublePtr30 = doublePtr2; int i59 = xxx$offset + i60; double d40 = doublePtr30.getDouble(i59); double d39 = d41 - d40; int i58 = indx * 8; DoublePtr doublePtr29 = doublePtr2; int i57 = xxx$offset + i58; double d38 = doublePtr29.getDouble(i57), d37 = base__.Rf_gpptr(dd).getDouble(0 + 35700); dx1 = Rmath.Rf_fmin2(d38 - d37, d39); int i56 = (indx + range) * 8; DoublePtr doublePtr28 = doublePtr2; int i55 = xxx$offset + i56; double d36 = doublePtr28.getDouble(i55), d35 = base__.Rf_gpptr(dd).getDouble(0 + 35700); double d34 = d36 - d35, d33 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8); int i54 = (indx + range) * 8; DoublePtr doublePtr27 = doublePtr2; int i53 = xxx$offset + i54; double d32 = doublePtr27.getDouble(i53); dx2 = Rmath.Rf_fmin2(d33 - d32, d34); if (dx1 >= dx2) { closest = 1; dmin = dx2; } else { closest = 0; dmin = dx1; }  double d31 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24); int i52 = indx * 8; DoublePtr doublePtr26 = doublePtr1; int i51 = yyy$offset + i52; double d30 = doublePtr26.getDouble(i51); double d29 = d31 - d30; int i50 = indx * 8; DoublePtr doublePtr25 = doublePtr1; int i49 = yyy$offset + i50; double d28 = doublePtr25.getDouble(i49), d27 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16); dy1 = Rmath.Rf_fmin2(d28 - d27, d29); if (closest == 0 || dy1 >= dmin) { if (dy1 < dmin)
/*      */                   dmin = dy1;  } else { closest = 0; dmin = dy1; }  int i48 = (indx + range) * 8; DoublePtr doublePtr24 = doublePtr1; int i47 = yyy$offset + i48; double d26 = doublePtr24.getDouble(i47), d25 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16); double d24 = d26 - d25, d23 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24); int i46 = (indx + range) * 8; DoublePtr doublePtr23 = doublePtr1; int i45 = yyy$offset + i46; double d22 = doublePtr23.getDouble(i45); dy2 = Rmath.Rf_fmin2(d23 - d22, d24); if (closest == 0 && dy2 < dmin)
/*      */                 closest = 1;  int i44 = (indx + range) * 8; DoublePtr doublePtr22 = doublePtr2; int i43 = xxx$offset + i44; double d21 = doublePtr22.getDouble(i43); int i42 = indx * 8; DoublePtr doublePtr21 = doublePtr2; int i41 = xxx$offset + i42; double d20 = doublePtr21.getDouble(i41); dx = graphics__.Rf_GConvertXUnits(d21 - d20, 12, 13, dd); int i40 = (indx + range) * 8; DoublePtr doublePtr20 = doublePtr1; int i39 = yyy$offset + i40; double d19 = doublePtr20.getDouble(i39); int i38 = indx * 8; DoublePtr doublePtr19 = doublePtr1; int i37 = yyy$offset + i38; double d18 = doublePtr19.getDouble(i37); dy = graphics__.Rf_GConvertYUnits(d19 - d18, 12, 13, dd); dxy = Mathlib.hypot(dx, dy); label2 = Rinternals.Rf_allocVector(14, 8); int i36 = (indx + range) * 8; DoublePtr doublePtr18 = doublePtr1; int i35 = yyy$offset + i36; double d17 = doublePtr18.getDouble(i35); int i34 = (indx + range) * 8; DoublePtr doublePtr17 = doublePtr2; int i33 = xxx$offset + i34; double d16 = doublePtr17.getDouble(i33); int i32 = indx * 8; DoublePtr doublePtr16 = doublePtr1; int i31 = yyy$offset + i32; double d15 = doublePtr16.getDouble(i31); int i30 = indx * 8; DoublePtr doublePtr15 = doublePtr2; int i29 = xxx$offset + i30; double d14 = doublePtr15.getDouble(i29); FindCorners(labelDistance, labelHeight, label2, d14, d15, d16, d17, dd); labelList$75 = Context.get__plot3d$labelList(); labelList$76 = Context.get__plot3d$labelList(); Context.set__plot3d$labelList(Rinternals.Rf_protect(Rinternals.Rf_cons(label2, labelList$76))); if (closest == 0) { int i72 = indx * 8; DoublePtr doublePtr36 = doublePtr2; int i71 = xxx$offset + i72; double d49 = doublePtr36.getDouble(i71); int i70 = (indx + range) * 8; DoublePtr doublePtr35 = doublePtr2; int i69 = xxx$offset + i70; double d48 = doublePtr35.getDouble(i69); int i68 = indx * 8; DoublePtr doublePtr34 = doublePtr2; int i67 = xxx$offset + i68; double d47 = doublePtr34.getDouble(i67); double d46 = (d48 - d47) * labelDistance / dxy; xStart = d49 + d46; int i66 = indx * 8; DoublePtr doublePtr33 = doublePtr1; int i65 = yyy$offset + i66; double d45 = doublePtr33.getDouble(i65); int i64 = (indx + range) * 8; DoublePtr doublePtr32 = doublePtr1; int i63 = yyy$offset + i64; double d44 = doublePtr32.getDouble(i63); int i62 = indx * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; double d43 = doublePtr31.getDouble(i61); double d42 = (d44 - d43) * labelDistance / dxy; yStart = d45 + d42; if (labelDistance / dxy < 1.0D) { int i76 = (indx + range) * 8; DoublePtr doublePtr38 = doublePtr1; int i75 = yyy$offset + i76; double d51 = doublePtr38.getDouble(i75); int i74 = (indx + range) * 8; DoublePtr doublePtr37 = doublePtr2; int i73 = xxx$offset + i74; double d50 = doublePtr37.getDouble(i73); graphics__.Rf_GLine(xStart, yStart, d50, d51, 12, dd); }  } else { int i72 = (indx + range) * 8; DoublePtr doublePtr36 = doublePtr2; int i71 = xxx$offset + i72; double d49 = doublePtr36.getDouble(i71); int i70 = (indx + range) * 8; DoublePtr doublePtr35 = doublePtr2; int i69 = xxx$offset + i70; double d48 = doublePtr35.getDouble(i69); int i68 = indx * 8; DoublePtr doublePtr34 = doublePtr2; int i67 = xxx$offset + i68; double d47 = doublePtr34.getDouble(i67); double d46 = (d48 - d47) * labelDistance / dxy; xStart = d49 - d46; int i66 = (indx + range) * 8; DoublePtr doublePtr33 = doublePtr1; int i65 = yyy$offset + i66; double d45 = doublePtr33.getDouble(i65); int i64 = (indx + range) * 8; DoublePtr doublePtr32 = doublePtr1; int i63 = yyy$offset + i64; double d44 = doublePtr32.getDouble(i63); int i62 = indx * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; double d43 = doublePtr31.getDouble(i61); double d42 = (d44 - d43) * labelDistance / dxy; yStart = d45 - d42; if (labelDistance / dxy < 1.0D) { int i76 = indx * 8; DoublePtr doublePtr38 = doublePtr1; int i75 = yyy$offset + i76; double d = doublePtr38.getDouble(i75); int i74 = indx * 8; DoublePtr doublePtr37 = doublePtr2; int i73 = xxx$offset + i74; graphics__.Rf_GLine(doublePtr37.getDouble(i73), d, xStart, yStart, 12, dd); }  }  int i28 = indx * 8; DoublePtr doublePtr14 = doublePtr2; int i27 = xxx$offset + i28; double d13 = doublePtr14.getDouble(i27); int i26 = (indx + range) * 8; DoublePtr doublePtr13 = doublePtr2; int i25 = xxx$offset + i26; double d12 = doublePtr13.getDouble(i25); if (d13 >= d12) { if (closest == 0) { ux[0] = xStart; uy[0] = yStart; int i64 = indx * 8; DoublePtr doublePtr32 = doublePtr2; int i63 = xxx$offset + i64; vx$96 = doublePtr32.getDouble(i63); vx[0] = vx$96; int i62 = indx * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; vy$98 = doublePtr31.getDouble(i61); vy[0] = vy$98; } else { int i64 = (indx + range) * 8; DoublePtr doublePtr32 = doublePtr2; int i63 = xxx$offset + i64; ux$93 = doublePtr32.getDouble(i63); ux[0] = ux$93; int i62 = (indx + range) * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; uy$94 = doublePtr31.getDouble(i61); uy[0] = uy$94; vx[0] = xStart; vy[0] = yStart; }  } else if (closest == 0) { int i64 = indx * 8; DoublePtr doublePtr32 = doublePtr2; int i63 = xxx$offset + i64; ux$90 = doublePtr32.getDouble(i63); ux[0] = ux$90; int i62 = indx * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; uy$92 = doublePtr31.getDouble(i61); uy[0] = uy$92; vx[0] = xStart; vy[0] = yStart; } else { ux[0] = xStart; uy[0] = yStart; int i64 = (indx + range) * 8; DoublePtr doublePtr32 = doublePtr2; int i63 = xxx$offset + i64; vx$87 = doublePtr32.getDouble(i63); vx[0] = vx$87; int i62 = (indx + range) * 8; DoublePtr doublePtr31 = doublePtr1; int i61 = yyy$offset + i62; vy$88 = doublePtr31.getDouble(i61); vy[0] = vy$88; }  if (false)
/* 1847 */                 continue;  graphics__.Rf_GConvert((Ptr)new DoublePtr(ux, 0), (Ptr)new DoublePtr(uy, 0), 12, 13, dd); graphics__.Rf_GConvert((Ptr)new DoublePtr(vx, 0), (Ptr)new DoublePtr(vy, 0), 12, 13, dd); vx$99 = vx[0]; ux$100 = ux[0]; double d11 = vx$99 - ux$100; vy$101 = vy[0]; uy$102 = uy[0]; double d10 = Mathlib.atan2(vy$101 - uy$102, d11) * 57.324840764331206D; uy$103 = uy[0]; graphics__.Rf_GText(ux[0], uy$103, 13, (Ptr)new BytePtr(buffer, 0), 0, 0.0D, 0.5D, d10, dd); continue; }  graphics__.Rf_GPolyline(ns, doublePtr2.pointerPlus(xxx$offset), doublePtr1.pointerPlus(yyy$offset), 12, dd); int i4 = indx * 8; DoublePtr doublePtr4 = doublePtr1; int i3 = yyy$offset + i4; double d1 = doublePtr4.getDouble(i3); int i2 = indx * 8; DoublePtr doublePtr3 = doublePtr2; int i1 = xxx$offset + i2; graphics__.Rf_GText(doublePtr3.getDouble(i1), d1, 12, (Ptr)new BytePtr(buffer, 0), 0, 0.5D, 0.5D, 0.0D, dd); continue; }  }  }  }  } public static SEXP C_contourDef() { return Rinternals.Rf_ScalarLogical(baseDevices__.GEcurrentDevice().getPointer().getInt(304)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP C_contour(SEXP args) {
/* 1857 */     familysave = new byte[201]; result = (SEXP)BytePtr.of(0).getArray(); dd = BytePtr.of(0); dd$offset = 0; labcex = 0.0D; drawLabels = 0; method = 0; vmax0 = BytePtr.of(0); vmax0$offset = 0; zmax = 0.0D; zmin = 0.0D; atom = 0.0D; lwdsave = 0.0D; cexsave = 0.0D; colsave = 0; fontsave = 0; ltysave = 0; nlwd = 0; nlty = 0; ncol = 0; nc = 0; ny = 0; nx = 0; i = 0; labels = (SEXP)BytePtr.of(0).getArray(); lwd = (SEXP)BytePtr.of(0).getArray(); lty = (SEXP)BytePtr.of(0).getArray(); rawcol = (SEXP)BytePtr.of(0).getArray(); col = (SEXP)BytePtr.of(0).getArray(); vfont = (SEXP)BytePtr.of(0).getArray(); z = (SEXP)BytePtr.of(0).getArray(); y = (SEXP)BytePtr.of(0).getArray(); x = (SEXP)BytePtr.of(0).getArray(); c = (SEXP)BytePtr.of(0).getArray(); fontsave = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1866 */     dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/* 1867 */     result = Rinternals.R_NilValue;
/*      */     
/* 1869 */     graphics__.Rf_GCheckState(dd.pointerPlus(dd$offset));
/*      */     
/* 1871 */     args = Rinternals.CDR(args);
/* 1872 */     if (Rinternals.Rf_length(args) <= 11) Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("too few arguments\000".getBytes(), 0)), new Object[0]); 
/* 1873 */     Defn.Rf_PrintDefaults();
/*      */     
/* 1875 */     x = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/* 1876 */     nx = Rinternals.LENGTH(x);
/* 1877 */     args = Rinternals.CDR(args);
/*      */     
/* 1879 */     y = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/* 1880 */     ny = Rinternals.LENGTH(y);
/* 1881 */     args = Rinternals.CDR(args);
/*      */     
/* 1883 */     z = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/* 1884 */     args = Rinternals.CDR(args);
/*      */ 
/*      */     
/* 1887 */     c = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(Rinternals.CAR(args), 14));
/* 1888 */     nc = Rinternals.LENGTH(c);
/* 1889 */     args = Rinternals.CDR(args);
/*      */     
/* 1891 */     labels = Rinternals.CAR(args);
/* 1892 */     if (Rinternals.TYPEOF(labels) != 0) TypeCheck(labels, 16); 
/* 1893 */     args = Rinternals.CDR(args);
/*      */     
/* 1895 */     labcex = Rinternals.Rf_asReal(Rinternals.CAR(args));
/* 1896 */     args = Rinternals.CDR(args);
/*      */     
/* 1898 */     drawLabels = Rinternals.Rf_asLogical(Rinternals.CAR(args));
/* 1899 */     args = Rinternals.CDR(args);
/*      */     
/* 1901 */     method = Rinternals.Rf_asInteger(Rinternals.CAR(args)); args = Rinternals.CDR(args);
/* 1902 */     if (method <= 0 || method > 3) {
/* 1903 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("method\000".getBytes(), 0) });
/*      */     }
/* 1905 */     vfont = plot__.Rf_FixupVFont(Rinternals.CAR(args)); Rinternals.Rf_protect(vfont);
/* 1906 */     if (Rinternals.TYPEOF(vfont) != 0) {
/* 1907 */       Ptr ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); Stdlib.strncpy((Ptr)new BytePtr(familysave, 0), ptr3.pointerPlus(80), 201);
/* 1908 */       Stdlib.strncpy(base__.Rf_gpptr(dd.pointerPlus(dd$offset)).pointerPlus(80), (Ptr)new BytePtr("Hershey \000".getBytes(), 0), 201);
/* 1909 */       Ptr ptr2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); byte b = (byte)Rinternals2.INTEGER(vfont).getInt(); ptr2.setByte(87, b);
/* 1910 */       fontsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(284);
/* 1911 */       Ptr ptr1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int m = Rinternals2.INTEGER(vfont).getInt(4); ptr1.setInt(284, m);
/*      */     } 
/* 1913 */     args = Rinternals.CDR(args);
/*      */     
/* 1915 */     rawcol = Rinternals.CAR(args);
/* 1916 */     col = plot__.Rf_FixupCol(rawcol, 16777215); Rinternals.Rf_protect(col);
/* 1917 */     ncol = Rinternals.Rf_length(col);
/* 1918 */     args = Rinternals.CDR(args);
/*      */     
/* 1920 */     int k = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); lty = plot__.Rf_FixupLty(Rinternals.CAR(args), k); Rinternals.Rf_protect(lty);
/* 1921 */     nlty = Rinternals.Rf_length(lty);
/* 1922 */     args = Rinternals.CDR(args);
/*      */     
/* 1924 */     double d = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(316); lwd = plot__.Rf_FixupLwd(Rinternals.CAR(args), d); Rinternals.Rf_protect(lwd);
/* 1925 */     nlwd = Rinternals.Rf_length(lwd);
/* 1926 */     args = Rinternals.CDR(args);
/*      */     
/* 1928 */     if (nx <= 1 || ny <= 1) {
/* 1929 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("insufficient 'x' or 'y' values\000".getBytes(), 0)), new Object[0]);
/*      */     }
/* 1931 */     if (Rinternals.Rf_nrows(z) != nx || Rinternals.Rf_ncols(z) != ny) {
/* 1932 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("dimension mismatch\000".getBytes(), 0)), new Object[0]);
/*      */     }
/* 1934 */     if (nc <= 0) {
/* 1935 */       Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("no contour values\000".getBytes(), 0)), new Object[0]);
/*      */     }
/* 1937 */     for (i = 0; i < nx; i++) {
/* 1938 */       Ptr ptr2 = Rinternals2.REAL(x); int n = i * 8; Ptr ptr1 = ptr2; int m = 0 + n; if (Arith.R_finite(ptr1.getDouble(m)) == 0)
/* 1939 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("missing 'x' values\000".getBytes(), 0)), new Object[0]); 
/* 1940 */       if (i > 0) { Ptr ptr6 = Rinternals2.REAL(x); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; double d2 = ptr5.getDouble(i3); Ptr ptr4 = Rinternals2.REAL(x); int i2 = (i + -1) * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d1 = ptr3.getDouble(i1); if (d2 < d1)
/* 1941 */           Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("increasing 'x' values expected\000".getBytes(), 0)), new Object[0]);  }
/*      */     
/*      */     } 
/* 1944 */     for (i = 0; i < ny; i++) {
/* 1945 */       Ptr ptr2 = Rinternals2.REAL(y); int n = i * 8; Ptr ptr1 = ptr2; int m = 0 + n; if (Arith.R_finite(ptr1.getDouble(m)) == 0)
/* 1946 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("missing 'y' values\000".getBytes(), 0)), new Object[0]); 
/* 1947 */       if (i > 0) { Ptr ptr6 = Rinternals2.REAL(y); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; double d2 = ptr5.getDouble(i3); Ptr ptr4 = Rinternals2.REAL(y); int i2 = (i + -1) * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; double d1 = ptr3.getDouble(i1); if (d2 < d1)
/* 1948 */           Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("increasing 'y' values expected\000".getBytes(), 0)), new Object[0]);  }
/*      */     
/*      */     } 
/* 1951 */     for (i = 0; i < nc; i++) {
/* 1952 */       Ptr ptr2 = Rinternals2.REAL(c); int n = i * 8; Ptr ptr1 = ptr2; int m = 0 + n; if (Arith.R_finite(ptr1.getDouble(m)) == 0)
/* 1953 */         Error.Rf_error(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("invalid NA contour values\000".getBytes(), 0)), new Object[0]); 
/*      */     } 
/* 1955 */     zmin = Double.MAX_VALUE;
/* 1956 */     zmax = 2.2250738585072014E-308D;
/* 1957 */     for (i = 0; nx * ny > i; i++) {
/* 1958 */       Ptr ptr2 = Rinternals2.REAL(z); int n = i * 8; Ptr ptr1 = ptr2; int m = 0 + n; if (Arith.R_finite(ptr1.getDouble(m)) != 0) {
/* 1959 */         Ptr ptr6 = Rinternals2.REAL(z); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; if (ptr5.getDouble(i3) > zmax) { Ptr ptr8 = Rinternals2.REAL(z); int i6 = i * 8; Ptr ptr7 = ptr8; int i5 = 0 + i6; zmax = ptr7.getDouble(i5); }
/* 1960 */          Ptr ptr4 = Rinternals2.REAL(z); int i2 = i * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; if (ptr3.getDouble(i1) < zmin) { Ptr ptr8 = Rinternals2.REAL(z); int i6 = i * 8; Ptr ptr7 = ptr8; int i5 = 0 + i6; zmin = ptr7.getDouble(i5); }
/*      */       
/*      */       } 
/* 1963 */     }  if (zmin < zmax) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1976 */       atom = (zmax - zmin) * 0.001D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1984 */       vmax0 = VoidPtr.toPtr(Memory.vmaxget()); vmax0$offset = 0;
/* 1985 */       Context.set__plot3d$ctr_SegDB((Ptr)PointerPtr.malloc(nx * ny * 4)); Context.set__plot3d$ctr_SegDB$offset(0);
/*      */       
/* 1987 */       for (i = 0; i < nx; i++) {
/* 1988 */         for (j = 0; j < ny; j++) {
/* 1989 */           ctr_SegDB$13 = Context.get__plot3d$ctr_SegDB(); ctr_SegDB$13$offset = Context.get__plot3d$ctr_SegDB$offset(); int n = (j * nx + i) * 4; Ptr ptr = ctr_SegDB$13; int m = ctr_SegDB$13$offset + n; ptr.setPointer(m, BytePtr.of(0));
/*      */         } 
/*      */       } 
/*      */       
/* 1993 */       ltysave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312);
/* 1994 */       colsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(44);
/* 1995 */       lwdsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(316);
/* 1996 */       cexsave = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(28);
/* 1997 */       Context.set__plot3d$labelList(Rinternals.Rf_protect(Rinternals.R_NilValue));
/*      */ 
/*      */ 
/*      */       
/* 2001 */       graphics__.Rf_GMode(1, dd.pointerPlus(dd$offset));
/* 2002 */       for (i = 0; i < nc; i++) {
/* 2003 */         vmax = VoidPtr.toPtr(Memory.vmaxget());
/* 2004 */         Ptr ptr8 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr7 = Rinternals2.INTEGER(lty); int i7 = i % nlty * 4; Ptr ptr6 = ptr7; int i6 = 0 + i7, i5 = ptr6.getInt(i6); ptr8.setInt(312, i5);
/* 2005 */         int i4 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(312); R_NaInt$16 = Arith.R_NaInt; if (i4 == R_NaInt$16)
/* 2006 */           base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(312, ltysave); 
/* 2007 */         if (plot__.isNAcol(rawcol, i, ncol) == 0)
/*      */         
/*      */         { 
/* 2010 */           Ptr ptr11 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr10 = Rinternals2.INTEGER(col); int i10 = i % ncol * 4; Ptr ptr9 = ptr10; int i9 = 0 + i10, i8 = ptr9.getInt(i9); ptr11.setInt(44, i8); } else { base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(44, colsave); }
/* 2011 */          Ptr ptr5 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)), ptr4 = Rinternals2.REAL(lwd); int i3 = i % nlwd * 8; Ptr ptr3 = ptr4; int i2 = 0 + i3; double d2 = ptr3.getDouble(i2); ptr5.setDouble(316, d2);
/* 2012 */         if (Arith.R_finite(base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getDouble(316)) == 0)
/* 2013 */           base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(316, lwdsave); 
/* 2014 */         base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(28, labcex);
/* 2015 */         int i1 = method + -1; Ptr ptr2 = Rinternals2.REAL(c); int n = i * 8; Ptr ptr1 = ptr2; int m = 0 + n; double d1 = ptr1.getDouble(m); contour(x, nx, y, ny, z, d1, labels, i, drawLabels, i1, atom, dd.pointerPlus(dd$offset));
/*      */       } 
/*      */ 
/*      */       
/* 2019 */       graphics__.Rf_GMode(0, dd.pointerPlus(dd$offset));
/*      */       
/* 2021 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(312, ltysave);
/* 2022 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(44, colsave);
/* 2023 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(316, lwdsave);
/* 2024 */       base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setDouble(28, cexsave);
/* 2025 */       if (Rinternals.TYPEOF(vfont) != 0) {
/* 2026 */         Stdlib.strncpy(base__.Rf_gpptr(dd.pointerPlus(dd$offset)).pointerPlus(80), (Ptr)new BytePtr(familysave, 0), 201);
/* 2027 */         base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(284, fontsave);
/*      */       } 
/*      */       
/* 2030 */       return result;
/*      */     } 
/*      */     if (zmin != zmax) {
/*      */       Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("all z values are NA\000".getBytes(), 0)), new Object[0]);
/*      */     } else {
/*      */       Error.Rf_warning(GetText.dgettext(new BytePtr("graphics\000".getBytes(), 0), new BytePtr("all z values are equal\000".getBytes(), 0)), new Object[0]);
/*      */     } 
/*      */     return Rinternals.R_NilValue;
/*      */   }
/*      */   
/*      */   static {
/*      */   
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/plot3d__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */