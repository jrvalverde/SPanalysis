/*      */ package org.renjin.graphics;
/*      */ 
/*      */ import java.lang.invoke.MethodHandle;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.FunctionPtr1;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.Mathlib;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.VoidPtr;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.GetText;
/*      */ import org.renjin.gnur.api.Memory;
/*      */ import org.renjin.gnur.api.Rmath;
/*      */ import org.renjin.grDevices.baseDevices__;
/*      */ import org.renjin.grDevices.baseEngine__;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class graphics__
/*      */ {
/*      */   static {
/*      */   
/*      */   }
/*      */   
/*      */   public static double R_Log10(double x) {
/*   50 */     return (Arith.R_finite(x) == 0 || x <= 0.0D) ? Arith.R_NaReal : Mathlib.log10(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_GMapUnits(int Runits) {
/*  118 */     switch (Runits) { case 1:
/*  119 */         return 12;
/*  120 */       case 2: return 7;
/*  121 */       case 3: return 13; }
/*  122 */      return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xNDCtoDevUnits(double x, Ptr dd) {
/*  133 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8)) * x;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNDCtoDevUnits(double y, Ptr dd) {
/*  138 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24)) * y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNICtoDevUnits(double x, Ptr dd) {
/*  143 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35852 + 8)) * x;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNICtoDevUnits(double y, Ptr dd) {
/*  148 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35852 + 24)) * y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNFCtoDevUnits(double x, Ptr dd) {
/*  153 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35820 + 8)) * x;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNFCtoDevUnits(double y, Ptr dd) {
/*  158 */     return Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35820 + 24)) * y;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNPCtoDevUnits(double x, Ptr dd) {
/*  163 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35460); return xNFCtoDevUnits((d2 - d1) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNPCtoDevUnits(double y, Ptr dd) {
/*  168 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16); return yNFCtoDevUnits((d2 - d1) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xUsrtoDevUnits(double x, Ptr dd) {
/*  173 */     return xNFCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yUsrtoDevUnits(double y, Ptr dd) {
/*  178 */     return yNFCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xInchtoDevUnits(double x, Ptr dd) {
/*  183 */     return xNDCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35804) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yInchtoDevUnits(double y, Ptr dd) {
/*  188 */     return yNDCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35812) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xLinetoDevUnits(double x, Ptr dd) {
/*  193 */     return xNDCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35788) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yLinetoDevUnits(double y, Ptr dd) {
/*  198 */     return yNDCtoDevUnits(base__.Rf_gpptr(dd).getDouble(0 + 35796) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xChartoDevUnits(double x, Ptr dd) {
/*  203 */     double d2 = base__.Rf_gpptr(dd).getDouble(28) * x, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35772); return xNDCtoDevUnits(d2 * d1, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yChartoDevUnits(double y, Ptr dd) {
/*  208 */     double d2 = base__.Rf_gpptr(dd).getDouble(28) * y, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35780); return yNDCtoDevUnits(d2 * d1, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoNDCUnits(double x, Ptr dd) {
/*  213 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8)); return x / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoNDCUnits(double y, Ptr dd) {
/*  218 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24)); return y / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoNICUnits(double x, Ptr dd) {
/*  223 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35852 + 8)); return x / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoNICUnits(double y, Ptr dd) {
/*  228 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35852 + 24)); return y / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoNFCUnits(double x, Ptr dd) {
/*  233 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35820 + 8)); return x / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoNFCUnits(double y, Ptr dd) {
/*  238 */     double d = Math.abs(base__.Rf_gpptr(dd).getDouble(0 + 35820 + 24)); return y / d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoNPCUnits(double x, Ptr dd) {
/*  243 */     double d4 = xDevtoNFCUnits(x, dd), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d1 = d3 - d2; return d4 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoNPCUnits(double y, Ptr dd) {
/*  248 */     double d4 = yDevtoNFCUnits(y, dd), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d1 = d3 - d2; return d4 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoUsrUnits(double x, Ptr dd) {
/*  253 */     double d2 = xDevtoNFCUnits(x, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoUsrUnits(double y, Ptr dd) {
/*  258 */     double d2 = yDevtoNFCUnits(y, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoInchUnits(double x, Ptr dd) {
/*  263 */     double d2 = xDevtoNDCUnits(x, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35804); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoInchUnits(double y, Ptr dd) {
/*  268 */     double d2 = yDevtoNDCUnits(y, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35812); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoLineUnits(double x, Ptr dd) {
/*  273 */     double d2 = xDevtoNDCUnits(x, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35788); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoLineUnits(double y, Ptr dd) {
/*  278 */     double d2 = yDevtoNDCUnits(y, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35796); return d2 / d1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xDevtoCharUnits(double x, Ptr dd) {
/*  287 */     double d4 = xDevtoNDCUnits(x, dd), d3 = base__.Rf_gpptr(dd).getDouble(28), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35772), d1 = d3 * d2; return d4 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoCharUnits(double y, Ptr dd) {
/*  292 */     double d4 = yDevtoNDCUnits(y, dd), d3 = base__.Rf_gpptr(dd).getDouble(28), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35780), d1 = d3 * d2; return d4 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void BadUnitsError(Ptr where) {
/*  297 */     Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("bad units specified in '%s'\000".getBytes(), 0)), new Object[] { where });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GConvertXUnits(double x, int fromUnits, int toUnits, Ptr dd) {
/*  306 */     switch (fromUnits) { case 0:
/*  307 */         dev = x; break;
/*  308 */       case 1: dev = xNDCtoDevUnits(x, dd); break;
/*  309 */       case 6: dev = xNICtoDevUnits(x, dd); break;
/*  310 */       case 7: dev = xNFCtoDevUnits(x, dd); break;
/*  311 */       case 16: dev = xNPCtoDevUnits(x, dd); break;
/*  312 */       case 12: dev = xUsrtoDevUnits(x, dd); break;
/*  313 */       case 13: dev = xInchtoDevUnits(x, dd); break;
/*  314 */       case 14: dev = xLinetoDevUnits(x, dd); break;
/*  315 */       case 15: dev = xChartoDevUnits(x, dd); break;
/*  316 */       default: dev = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertXUnits\000".getBytes(), 0));
/*      */         break; }
/*      */     
/*  319 */     switch (toUnits) { case 0:
/*  320 */         final = dev;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  331 */         return final;case 1: final = xDevtoNDCUnits(dev, dd); return final;case 6: final = xDevtoNICUnits(dev, dd); return final;case 7: final = xDevtoNFCUnits(dev, dd); return final;case 16: final = xDevtoNPCUnits(dev, dd); return final;case 12: final = xDevtoUsrUnits(dev, dd); return final;case 13: final = xDevtoInchUnits(dev, dd); return final;case 14: final = xDevtoLineUnits(dev, dd); return final;case 15: final = xDevtoCharUnits(dev, dd); return final; }  final = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertXUnits\000".getBytes(), 0)); return final;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GConvertYUnits(double y, int fromUnits, int toUnits, Ptr dd) {
/*  337 */     switch (fromUnits) { case 0:
/*  338 */         dev = y; break;
/*  339 */       case 1: dev = yNDCtoDevUnits(y, dd); break;
/*  340 */       case 6: dev = yNICtoDevUnits(y, dd); break;
/*  341 */       case 7: dev = yNFCtoDevUnits(y, dd); break;
/*  342 */       case 16: dev = yNPCtoDevUnits(y, dd); break;
/*  343 */       case 12: dev = yUsrtoDevUnits(y, dd); break;
/*  344 */       case 13: dev = yInchtoDevUnits(y, dd); break;
/*  345 */       case 14: dev = yLinetoDevUnits(y, dd); break;
/*  346 */       case 15: dev = yChartoDevUnits(y, dd); break;
/*  347 */       default: dev = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertYUnits\000".getBytes(), 0)); break; }
/*      */     
/*  349 */     switch (toUnits) { case 0:
/*  350 */         final = dev;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  361 */         return final;case 1: final = yDevtoNDCUnits(dev, dd); return final;case 6: final = yDevtoNICUnits(dev, dd); return final;case 7: final = yDevtoNFCUnits(dev, dd); return final;case 16: final = yDevtoNPCUnits(dev, dd); return final;case 12: final = yDevtoUsrUnits(dev, dd); return final;case 13: final = yDevtoInchUnits(dev, dd); return final;case 14: final = yDevtoLineUnits(dev, dd); return final;case 15: final = yDevtoCharUnits(dev, dd); return final; }  final = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertYUnits\000".getBytes(), 0)); return final;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xNDCtoDev(double x, Ptr dd) {
/*  372 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35884), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8) * x; return d2 + d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNDCtoDev(double y, Ptr dd) {
/*  377 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24) * y; return d2 + d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xInchtoDev(double x, Ptr dd) {
/*  382 */     return xNDCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35804) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yInchtoDev(double y, Ptr dd) {
/*  387 */     return yNDCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35812) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xLinetoDev(double x, Ptr dd) {
/*  392 */     return xNDCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35788) * x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yLinetoDev(double y, Ptr dd) {
/*  397 */     return yNDCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35796) * y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNICtoDev(double x, Ptr dd) {
/*  402 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35852), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 8) * x; return d2 + d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNICtoDev(double y, Ptr dd) {
/*  407 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 24) * y; return d2 + d1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xOMA1toDev(double x, Ptr dd) {
/*  415 */     return xNICtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yOMA1toDev(double y, Ptr dd) {
/*  420 */     return yLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596) - y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xOMA2toyDev(double x, Ptr dd) {
/*  425 */     return yNICtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yOMA2toxDev(double y, Ptr dd) {
/*  430 */     return xLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8) - y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xOMA3toDev(double x, Ptr dd) {
/*  435 */     return xNICtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yOMA3toDev(double y, Ptr dd) {
/*  440 */     double d = Rf_yDevtoNDC(yLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 16) - y, dd), dd);
/*  441 */     return yNDCtoDev(1.0D - d, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xOMA4toyDev(double x, Ptr dd) {
/*  446 */     return yNICtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yOMA4toxDev(double y, Ptr dd) {
/*  451 */     double d = Rf_xDevtoNDC(xLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 24) - y, dd), dd);
/*  452 */     return xNDCtoDev(1.0D - d, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNFCtoDev(double x, Ptr dd) {
/*  457 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35820), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 8) * x; return d2 + d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yNFCtoDev(double y, Ptr dd) {
/*  462 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 24) * y; return d2 + d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xNPCtoDev(double x, Ptr dd) {
/*  467 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35460);
/*  468 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d1 = (d3 - d2) * x;
/*      */     return xNFCtoDev(d4 + d1, dd);
/*      */   }
/*      */   
/*      */   public static double yNPCtoDev(double y, Ptr dd) {
/*  473 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16);
/*  474 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d1 = (d3 - d2) * y;
/*      */     return yNFCtoDev(d4 + d1, dd);
/*      */   }
/*      */   
/*      */   public static double xUsrtoDev(double x, Ptr dd) {
/*  479 */     if (base__.Rf_gpptr(dd).getInt(440) != 0)
/*  480 */       x = R_Log10(x); 
/*  481 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35916), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8) * x; return xNFCtoDev(d2 + d1, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yUsrtoDev(double y, Ptr dd) {
/*  486 */     if (base__.Rf_gpptr(dd).getInt(480) != 0)
/*  487 */       y = R_Log10(y); 
/*  488 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24) * y; return yNFCtoDev(d2 + d1, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double xMAR1toDev(double x, Ptr dd) {
/*  497 */     return xUsrtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yMAR1toDev(double y, Ptr dd) {
/*  502 */     nfc = Rf_GConvertYUnits(y, 14, 7, dd);
/*  503 */     return yNFCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16) - nfc, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xMAR2toyDev(double x, Ptr dd) {
/*  508 */     return yUsrtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yMAR2toxDev(double y, Ptr dd) {
/*  513 */     nfc = Rf_GConvertXUnits(y, 14, 7, dd);
/*  514 */     return xNFCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35460) - nfc, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xMAR3toDev(double x, Ptr dd) {
/*  519 */     return xUsrtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yMAR3toDev(double y, Ptr dd) {
/*  524 */     nfc = Rf_GConvertYUnits(y, 14, 7, dd);
/*  525 */     return yNFCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24) + nfc, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xMAR4toyDev(double x, Ptr dd) {
/*  530 */     return yUsrtoDev(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yMAR4toxDev(double y, Ptr dd) {
/*  535 */     nfc = Rf_GConvertXUnits(y, 14, 7, dd);
/*  536 */     return xNFCtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8) + nfc, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_xDevtoNDC(double x, Ptr dd) {
/*  543 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35884), d2 = x - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double Rf_yDevtoNDC(double y, Ptr dd) {
/*  548 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 16), d2 = y - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoInch(double x, Ptr dd) {
/*  553 */     double d2 = Rf_xDevtoNDC(x, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35804); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoInch(double y, Ptr dd) {
/*  558 */     double d2 = Rf_yDevtoNDC(y, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35812); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoLine(double x, Ptr dd) {
/*  563 */     double d2 = Rf_xDevtoNDC(x, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35788); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoLine(double y, Ptr dd) {
/*  568 */     double d2 = Rf_yDevtoNDC(y, dd), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35796); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoNIC(double x, Ptr dd) {
/*  573 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35852), d2 = x - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 8); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoNIC(double y, Ptr dd) {
/*  578 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 16), d2 = y - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35852 + 24); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoOMA1(double x, Ptr dd) {
/*  583 */     return xDevtoNIC(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoOMA1(double y, Ptr dd) {
/*  588 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35596), d1 = yDevtoLine(y, dd); return d2 - d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoyOMA2(double x, Ptr dd) {
/*  593 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8), d1 = xDevtoLine(x, dd); return d2 - d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoxOMA2(double y, Ptr dd) {
/*  598 */     return yDevtoNIC(y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoOMA3(double x, Ptr dd) {
/*  603 */     return xDevtoNIC(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoOMA3(double y, Ptr dd) {
/*  608 */     double d3 = Rf_yDevtoNDC(y, dd), d2 = 1.0D - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35796); line = d2 / d1;
/*  609 */     return base__.Rf_gpptr(dd).getDouble(0 + 35596 + 16) - line;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoyOMA4(double x, Ptr dd) {
/*  614 */     double d3 = Rf_xDevtoNDC(x, dd), d2 = 1.0D - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35788); line = d2 / d1;
/*  615 */     return base__.Rf_gpptr(dd).getDouble(0 + 35596 + 24) - line;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoxOMA4(double y, Ptr dd) {
/*  620 */     return yDevtoNIC(y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double Rf_xDevtoNFC(double x, Ptr dd) {
/*  625 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35820), d2 = x - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 8); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double Rf_yDevtoNFC(double y, Ptr dd) {
/*  630 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 16), d2 = y - d3, d1 = base__.Rf_gpptr(dd).getDouble(0 + 35820 + 24); return d2 / d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double Rf_xDevtoNPC(double x, Ptr dd) {
/*  635 */     double d6 = Rf_xDevtoNFC(x, dd), d5 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d4 = d6 - d5;
/*  636 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d1 = d3 - d2;
/*      */     return d4 / d1;
/*      */   }
/*      */   
/*      */   public static double Rf_yDevtoNPC(double y, Ptr dd) {
/*  641 */     double d6 = Rf_yDevtoNFC(y, dd), d5 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d4 = d6 - d5;
/*  642 */     double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d1 = d3 - d2;
/*      */     return d4 / d1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_xNPCtoUsr(double x, Ptr dd) {
/*  649 */     if (base__.Rf_gpptr(dd).getInt(440) == 0) {
/*      */ 
/*      */ 
/*      */       
/*  653 */       double d9 = base__.Rf_gpptr(dd).getDouble(0 + 35700), d8 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8), d7 = base__.Rf_gpptr(dd).getDouble(0 + 35700), d6 = (d8 - d7) * x; return d9 + d6;
/*      */     } 
/*      */     double d5 = base__.Rf_gpptr(dd).getDouble(0 + 35732), d4 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 8), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35732), d2 = (d4 - d3) * x, d1 = d5 + d2;
/*      */     return Mathlib.pow(10.0D, d1);
/*      */   } public static double Rf_yNPCtoUsr(double y, Ptr dd) {
/*  658 */     if (base__.Rf_gpptr(dd).getInt(480) == 0) {
/*      */ 
/*      */ 
/*      */       
/*  662 */       double d9 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16), d8 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24), d7 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16), d6 = (d8 - d7) * y; return d9 + d6;
/*      */     } 
/*      */     double d5 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 16), d4 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 24), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 16), d2 = (d4 - d3) * y, d1 = d5 + d2;
/*      */     return Mathlib.pow(10.0D, d1);
/*      */   } public static double Rf_xDevtoUsr(double x, Ptr dd) {
/*  667 */     nfc = Rf_xDevtoNFC(x, dd);
/*  668 */     if (base__.Rf_gpptr(dd).getInt(440) == 0) {
/*      */ 
/*      */       
/*  671 */       double d7 = base__.Rf_gpptr(dd).getDouble(0 + 35916), d6 = nfc - d7, d5 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8); return d6 / d5;
/*      */     } 
/*      */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35916), d3 = nfc - d4, d2 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8), d1 = d3 / d2;
/*      */     return Mathlib.pow(10.0D, d1);
/*      */   } public static double Rf_yDevtoUsr(double y, Ptr dd) {
/*  676 */     nfc = Rf_yDevtoNFC(y, dd);
/*  677 */     if (base__.Rf_gpptr(dd).getInt(480) == 0) {
/*      */ 
/*      */       
/*  680 */       double d7 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 16), d6 = nfc - d7, d5 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24); return d6 / d5;
/*      */     } 
/*      */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 16), d3 = nfc - d4, d2 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24), d1 = d3 / d2;
/*      */     return Mathlib.pow(10.0D, d1);
/*      */   } public static double xDevtoMAR1(double x, Ptr dd) {
/*  685 */     return Rf_xDevtoUsr(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoMAR1(double y, Ptr dd) {
/*  690 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35596), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35520), d2 = d4 + d3, d1 = yDevtoLine(y, dd); return d2 - d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoyMAR2(double x, Ptr dd) {
/*  695 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35520 + 8), d2 = d4 + d3, d1 = xDevtoLine(x, dd); return d2 - d1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoxMAR2(double y, Ptr dd) {
/*  700 */     return Rf_yDevtoUsr(y, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoMAR3(double x, Ptr dd) {
/*  705 */     return Rf_xDevtoUsr(x, dd);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoMAR3(double y, Ptr dd) {
/*  710 */     double d = Rf_yDevtoNFC(y, dd); line = Rf_GConvertYUnits(1.0D - d, 7, 14, dd);
/*  711 */     return base__.Rf_gpptr(dd).getDouble(0 + 35520 + 16) - line;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double xDevtoyMAR4(double x, Ptr dd) {
/*  716 */     double d = Rf_xDevtoNFC(x, dd); line = Rf_GConvertXUnits(1.0D - d, 7, 14, dd);
/*  717 */     return base__.Rf_gpptr(dd).getDouble(0 + 35520 + 24) - line;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double yDevtoxMAR4(double y, Ptr dd) {
/*  722 */     return Rf_yDevtoUsr(y, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GConvert(Ptr x, Ptr y, int from, int to, Ptr dd) {
/*      */     double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20, d21, d22, d23, d24, d25, d26, d27, d28, d29, d30;
/*  732 */     switch (from) {
/*      */       case 0:
/*  734 */         devx = x.getDouble();
/*  735 */         devy = y.getDouble();
/*      */         break;
/*      */       case 1:
/*  738 */         devx = xNDCtoDev(x.getDouble(), dd);
/*  739 */         devy = yNDCtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 13:
/*  742 */         devx = xInchtoDev(x.getDouble(), dd);
/*  743 */         devy = yInchtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 2:
/*  746 */         devx = xOMA1toDev(x.getDouble(), dd);
/*  747 */         devy = yOMA1toDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 3:
/*  750 */         devx = yOMA2toxDev(y.getDouble(), dd);
/*  751 */         devy = xOMA2toyDev(x.getDouble(), dd);
/*      */         break;
/*      */       case 4:
/*  754 */         devx = xOMA3toDev(x.getDouble(), dd);
/*  755 */         devy = yOMA3toDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 5:
/*  758 */         devx = yOMA4toxDev(y.getDouble(), dd);
/*  759 */         devy = xOMA4toyDev(x.getDouble(), dd);
/*      */         break;
/*      */       case 6:
/*  762 */         devx = xNICtoDev(x.getDouble(), dd);
/*  763 */         devy = yNICtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 7:
/*  766 */         devx = xNFCtoDev(x.getDouble(), dd);
/*  767 */         devy = yNFCtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 8:
/*  770 */         devx = xMAR1toDev(x.getDouble(), dd);
/*  771 */         devy = yMAR1toDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 9:
/*  774 */         devx = yMAR2toxDev(y.getDouble(), dd);
/*  775 */         devy = xMAR2toyDev(x.getDouble(), dd);
/*      */         break;
/*      */       case 10:
/*  778 */         devx = xMAR3toDev(x.getDouble(), dd);
/*  779 */         devy = yMAR3toDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 11:
/*  782 */         devx = yMAR4toxDev(y.getDouble(), dd);
/*  783 */         devy = xMAR4toyDev(x.getDouble(), dd);
/*      */         break;
/*      */       case 16:
/*  786 */         devx = xNPCtoDev(x.getDouble(), dd);
/*  787 */         devy = yNPCtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       case 12:
/*  790 */         devx = xUsrtoDev(x.getDouble(), dd);
/*  791 */         devy = yUsrtoDev(y.getDouble(), dd);
/*      */         break;
/*      */       default:
/*  794 */         devx = 0.0D;
/*  795 */         devy = 0.0D;
/*  796 */         BadUnitsError((Ptr)new BytePtr("GConvert\000".getBytes(), 0));
/*      */         break;
/*      */     } 
/*  799 */     switch (to) {
/*      */       case 0:
/*  801 */         x.setDouble(devx);
/*  802 */         y.setDouble(devy);
/*      */         return;
/*      */       case 1:
/*  805 */         d30 = Rf_xDevtoNDC(devx, dd); x.setDouble(d30);
/*  806 */         d29 = Rf_yDevtoNDC(devy, dd); y.setDouble(d29);
/*      */         return;
/*      */       case 13:
/*  809 */         d28 = xDevtoInch(devx, dd); x.setDouble(d28);
/*  810 */         d27 = yDevtoInch(devy, dd); y.setDouble(d27);
/*      */         return;
/*      */       case 14:
/*  813 */         d26 = xDevtoLine(devx, dd); x.setDouble(d26);
/*  814 */         d25 = yDevtoLine(devy, dd); y.setDouble(d25);
/*      */         return;
/*      */       case 6:
/*  817 */         d24 = xDevtoNIC(devx, dd); x.setDouble(d24);
/*  818 */         d23 = yDevtoNIC(devy, dd); y.setDouble(d23);
/*      */         return;
/*      */       case 2:
/*  821 */         d22 = xDevtoOMA1(devx, dd); x.setDouble(d22);
/*  822 */         d21 = yDevtoOMA1(devy, dd); y.setDouble(d21);
/*      */         return;
/*      */       case 3:
/*  825 */         d20 = yDevtoxOMA2(devy, dd); x.setDouble(d20);
/*  826 */         d19 = xDevtoyOMA2(devx, dd); y.setDouble(d19);
/*      */         return;
/*      */       case 4:
/*  829 */         d18 = xDevtoOMA3(devx, dd); x.setDouble(d18);
/*  830 */         d17 = yDevtoOMA3(devy, dd); y.setDouble(d17);
/*      */         return;
/*      */       case 5:
/*  833 */         d16 = yDevtoxOMA4(devy, dd); x.setDouble(d16);
/*  834 */         d15 = xDevtoyOMA4(devx, dd); y.setDouble(d15);
/*      */         return;
/*      */       case 7:
/*  837 */         d14 = Rf_xDevtoNFC(devx, dd); x.setDouble(d14);
/*  838 */         d13 = Rf_yDevtoNFC(devy, dd); y.setDouble(d13);
/*      */         return;
/*      */       case 16:
/*  841 */         d12 = Rf_xDevtoNPC(devx, dd); x.setDouble(d12);
/*  842 */         d11 = Rf_yDevtoNPC(devy, dd); y.setDouble(d11);
/*      */         return;
/*      */       case 12:
/*  845 */         d10 = Rf_xDevtoUsr(devx, dd); x.setDouble(d10);
/*  846 */         d9 = Rf_yDevtoUsr(devy, dd); y.setDouble(d9);
/*      */         return;
/*      */       case 8:
/*  849 */         d8 = xDevtoMAR1(devx, dd); x.setDouble(d8);
/*  850 */         d7 = yDevtoMAR1(devy, dd); y.setDouble(d7);
/*      */         return;
/*      */       case 9:
/*  853 */         d6 = yDevtoxMAR2(devy, dd); x.setDouble(d6);
/*  854 */         d5 = xDevtoyMAR2(devx, dd); y.setDouble(d5);
/*      */         return;
/*      */       case 10:
/*  857 */         d4 = xDevtoMAR3(devx, dd); x.setDouble(d4);
/*  858 */         d3 = yDevtoMAR3(devy, dd); y.setDouble(d3);
/*      */         return;
/*      */       case 11:
/*  861 */         d2 = yDevtoxMAR4(devy, dd); x.setDouble(d2);
/*  862 */         d1 = xDevtoyMAR4(devx, dd); y.setDouble(d1);
/*      */         return;
/*      */     } 
/*  865 */     BadUnitsError((Ptr)new BytePtr("GConvert\000".getBytes(), 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GConvertX(double x, int from, int to, Ptr dd) {
/*  872 */     switch (from) { case 0:
/*  873 */         devx = x; break;
/*  874 */       case 1: devx = xNDCtoDev(x, dd); break;
/*  875 */       case 13: devx = xInchtoDev(x, dd); break;
/*  876 */       case 14: devx = xLinetoDev(x, dd); break;
/*  877 */       case 2: devx = xOMA1toDev(x, dd); break;
/*      */       case 4:
/*  879 */         devx = xOMA3toDev(x, dd); break;
/*      */       case 6:
/*  881 */         devx = xNICtoDev(x, dd); break;
/*  882 */       case 7: devx = xNFCtoDev(x, dd); break;
/*  883 */       case 8: devx = xMAR1toDev(x, dd); break;
/*      */       case 10:
/*  885 */         devx = xMAR3toDev(x, dd); break;
/*      */       case 16:
/*  887 */         devx = xNPCtoDev(x, dd); break;
/*  888 */       case 12: devx = xUsrtoDev(x, dd); break;
/*  889 */       default: devx = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertX\000".getBytes(), 0));
/*      */         break; }
/*      */     
/*  892 */     switch (to) { case 0:
/*  893 */         x = devx;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  911 */         return x;case 1: x = Rf_xDevtoNDC(devx, dd); return x;case 13: x = xDevtoInch(devx, dd); return x;case 14: x = xDevtoLine(devx, dd); return x;case 6: x = xDevtoNIC(devx, dd); return x;case 2: x = xDevtoOMA1(devx, dd); return x;case 4: x = xDevtoOMA3(devx, dd); return x;case 7: x = Rf_xDevtoNFC(devx, dd); return x;case 12: x = Rf_xDevtoUsr(devx, dd); return x;case 8: x = xDevtoMAR1(devx, dd); return x;case 10: x = xDevtoMAR3(devx, dd); return x;case 16: x = Rf_xDevtoNPC(devx, dd); return x; }  BadUnitsError((Ptr)new BytePtr("GConvertX\000".getBytes(), 0)); return x;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GConvertY(double y, int from, int to, Ptr dd) {
/*  917 */     switch (from) { case 0:
/*  918 */         devy = y; break;
/*  919 */       case 1: devy = yNDCtoDev(y, dd); break;
/*  920 */       case 13: devy = yInchtoDev(y, dd); break;
/*  921 */       case 14: devy = yLinetoDev(y, dd); break;
/*  922 */       case 2: devy = yOMA1toDev(y, dd); break;
/*      */       case 4:
/*  924 */         devy = yOMA3toDev(y, dd); break;
/*      */       case 6:
/*  926 */         devy = yNICtoDev(y, dd); break;
/*  927 */       case 7: devy = yNFCtoDev(y, dd); break;
/*  928 */       case 8: devy = yMAR1toDev(y, dd); break;
/*      */       case 10:
/*  930 */         devy = yMAR3toDev(y, dd); break;
/*      */       case 16:
/*  932 */         devy = yNPCtoDev(y, dd); break;
/*  933 */       case 12: devy = yUsrtoDev(y, dd); break;
/*  934 */       default: devy = 0.0D; BadUnitsError((Ptr)new BytePtr("GConvertY\000".getBytes(), 0));
/*      */         break; }
/*      */     
/*  937 */     switch (to) { case 0:
/*  938 */         y = devy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  956 */         return y;case 1: y = Rf_yDevtoNDC(devy, dd); return y;case 13: y = yDevtoInch(devy, dd); return y;case 14: y = yDevtoLine(devy, dd); return y;case 6: y = yDevtoNIC(devy, dd); return y;case 2: y = yDevtoOMA1(devy, dd); return y;case 4: y = yDevtoOMA3(devy, dd); return y;case 7: y = Rf_yDevtoNFC(devy, dd); return y;case 12: y = Rf_yDevtoUsr(devy, dd); return y;case 8: y = yDevtoMAR1(devy, dd); return y;case 10: y = yDevtoMAR3(devy, dd); return y;case 16: y = Rf_yDevtoNPC(devy, dd); return y; }  BadUnitsError((Ptr)new BytePtr("GConvertY\000".getBytes(), 0)); return y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sum(Ptr values, int n, Ptr cmValues, int cmSum) {
/*      */     // Byte code:
/*      */     //   0: dconst_0
/*      */     //   1: dstore #4
/*      */     //   3: dconst_0
/*      */     //   4: dstore #4
/*      */     //   6: iconst_0
/*      */     //   7: istore #6
/*      */     //   9: goto -> 113
/*      */     //   12: iload_3
/*      */     //   13: ifne -> 19
/*      */     //   16: goto -> 47
/*      */     //   19: iload #6
/*      */     //   21: iconst_4
/*      */     //   22: imul
/*      */     //   23: istore #23
/*      */     //   25: aload_2
/*      */     //   26: astore #21
/*      */     //   28: iload #23
/*      */     //   30: istore #22
/*      */     //   32: aload #21
/*      */     //   34: iload #22
/*      */     //   36: invokeinterface getInt : (I)I
/*      */     //   41: ifne -> 82
/*      */     //   44: goto -> 47
/*      */     //   47: iload_3
/*      */     //   48: ifeq -> 54
/*      */     //   51: goto -> 110
/*      */     //   54: iload #6
/*      */     //   56: iconst_4
/*      */     //   57: imul
/*      */     //   58: istore #18
/*      */     //   60: aload_2
/*      */     //   61: astore #16
/*      */     //   63: iload #18
/*      */     //   65: istore #17
/*      */     //   67: aload #16
/*      */     //   69: iload #17
/*      */     //   71: invokeinterface getInt : (I)I
/*      */     //   76: ifeq -> 82
/*      */     //   79: goto -> 110
/*      */     //   82: iload #6
/*      */     //   84: bipush #8
/*      */     //   86: imul
/*      */     //   87: istore #13
/*      */     //   89: aload_0
/*      */     //   90: astore #11
/*      */     //   92: iload #13
/*      */     //   94: istore #12
/*      */     //   96: aload #11
/*      */     //   98: iload #12
/*      */     //   100: invokeinterface getDouble : (I)D
/*      */     //   105: dload #4
/*      */     //   107: dadd
/*      */     //   108: dstore #4
/*      */     //   110: iinc #6, 1
/*      */     //   113: iload #6
/*      */     //   115: iload_1
/*      */     //   116: if_icmplt -> 12
/*      */     //   119: goto -> 122
/*      */     //   122: dload #4
/*      */     //   124: dreturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #964	-> 3
/*      */     //   #965	-> 6
/*      */     //   #966	-> 12
/*      */     //   #966	-> 19
/*      */     //   #966	-> 47
/*      */     //   #966	-> 54
/*      */     //   #967	-> 82
/*      */     //   #965	-> 110
/*      */     //   #965	-> 113
/*      */     //   #968	-> 122
/*      */     //   #968	-> 124
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	125	0	values	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	125	1	n	I
/*      */     //   0	125	2	cmValues	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	125	3	cmSum	I
/*      */     //   0	125	4	s	D
/*      */     //   0	125	6	i	I
/*      */     //   0	125	14	i$299	I
/*      */     //   0	125	19	i$298	I
/*      */     //   0	125	24	i$297	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sumWidths(Ptr dd) {
/*  973 */     Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(564); return sum(base__.Rf_gpptr(dd).pointerPlus(2176), i, ptr.pointerPlus(4576), 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double sumCmWidths(Ptr dd) {
/*  978 */     Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(564); return sum(base__.Rf_gpptr(dd).pointerPlus(2176), i, ptr.pointerPlus(4576), 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double sumHeights(Ptr dd) {
/*  983 */     Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(560); return sum(base__.Rf_gpptr(dd).pointerPlus(576), i, ptr.pointerPlus(3776), 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static double sumCmHeights(Ptr dd) {
/*  988 */     Ptr ptr = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(560); return sum(base__.Rf_gpptr(dd).pointerPlus(576), i, ptr.pointerPlus(3776), 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int tallLayout(double cmWidth, double cmHeight, Ptr dd) {
/*  993 */     double d4 = sumHeights(dd), d3 = cmHeight / d4, d2 = sumWidths(dd), d1 = cmWidth / d2; return (d3 <= d1) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void figureExtent(Ptr minCol, Ptr maxCol, Ptr minRow, Ptr maxRow, int figureNum, Ptr dd) {
/*  999 */     nr = 0; i = 0; maxr = 0; minr = 0; maxc = 0; minc = 0; minc = -1;
/* 1000 */     maxc = -1;
/* 1001 */     minr = -1;
/* 1002 */     maxr = -1;
/*      */     
/* 1004 */     nr = base__.Rf_gpptr(dd).getInt(560);
/* 1005 */     for (i = 0; i < nr; i++) {
/* 1006 */       for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++) {
/* 1007 */         Ptr ptr = base__.Rf_gpptr(dd); int k = j * nr + i; if (ptr.getChar(5376 + k * 2) == figureNum)
/* 1008 */         { if (minc == -1 || j < minc)
/* 1009 */             minc = j; 
/* 1010 */           if (maxc == -1 || j > maxc)
/* 1011 */             maxc = j; 
/* 1012 */           if (minr == -1 || i < minr)
/* 1013 */             minr = i; 
/* 1014 */           if (maxr == -1 || i > maxr)
/* 1015 */             maxr = i;  } 
/*      */       } 
/* 1017 */     }  minCol.setInt(minc);
/* 1018 */     maxCol.setInt(maxc);
/* 1019 */     minRow.setInt(minr);
/* 1020 */     maxRow.setInt(maxr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double sumRegions(Ptr regions, int from, int to) {
/* 1026 */     s = 0.0D;
/* 1027 */     for (i = from; to + 1 > i; i++) {
/* 1028 */       int k = i * 8; Ptr ptr = regions; int j = k; s = ptr.getDouble(j) + s;
/* 1029 */     }  return s;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void largestRegion(Ptr width, Ptr height, double layoutAspectRatio, double innerAspectRatio) {
/* 1035 */     if (layoutAspectRatio >= innerAspectRatio) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1040 */       double d1 = innerAspectRatio / layoutAspectRatio; width.setDouble(d1);
/* 1041 */       height.setDouble(1.0D);
/*      */       return;
/*      */     } 
/*      */     width.setDouble(1.0D);
/*      */     double d = layoutAspectRatio / innerAspectRatio;
/*      */     height.setDouble(d);
/*      */   }
/*      */   public static void layoutRegion(Ptr width, Ptr height, Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1049 */     double d4 = cmHeight / cmWidth;
/* 1050 */     Ptr ptr2 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(560); double d3 = sum(heights, j, ptr2.pointerPlus(3776), 0);
/* 1051 */     Ptr ptr1 = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(564); double d2 = sum(widths, i, ptr1.pointerPlus(4576), 0);
/*      */     double d1 = d3 / d2;
/*      */     largestRegion(width, height, d1, d4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void allocDimension(Ptr dimensions, double sumDimensions, int n, Ptr cmDimensions, int cmDimension) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore #6
/*      */     //   3: goto -> 135
/*      */     //   6: iload #5
/*      */     //   8: ifne -> 14
/*      */     //   11: goto -> 43
/*      */     //   14: iload #6
/*      */     //   16: iconst_4
/*      */     //   17: imul
/*      */     //   18: istore #27
/*      */     //   20: aload #4
/*      */     //   22: astore #25
/*      */     //   24: iload #27
/*      */     //   26: istore #26
/*      */     //   28: aload #25
/*      */     //   30: iload #26
/*      */     //   32: invokeinterface getInt : (I)I
/*      */     //   37: ifne -> 80
/*      */     //   40: goto -> 43
/*      */     //   43: iload #5
/*      */     //   45: ifeq -> 51
/*      */     //   48: goto -> 132
/*      */     //   51: iload #6
/*      */     //   53: iconst_4
/*      */     //   54: imul
/*      */     //   55: istore #22
/*      */     //   57: aload #4
/*      */     //   59: astore #20
/*      */     //   61: iload #22
/*      */     //   63: istore #21
/*      */     //   65: aload #20
/*      */     //   67: iload #21
/*      */     //   69: invokeinterface getInt : (I)I
/*      */     //   74: ifeq -> 80
/*      */     //   77: goto -> 132
/*      */     //   80: iload #6
/*      */     //   82: bipush #8
/*      */     //   84: imul
/*      */     //   85: istore #17
/*      */     //   87: aload_0
/*      */     //   88: astore #15
/*      */     //   90: iload #17
/*      */     //   92: istore #16
/*      */     //   94: iload #6
/*      */     //   96: bipush #8
/*      */     //   98: imul
/*      */     //   99: istore #13
/*      */     //   101: aload_0
/*      */     //   102: astore #11
/*      */     //   104: iload #13
/*      */     //   106: istore #12
/*      */     //   108: aload #11
/*      */     //   110: iload #12
/*      */     //   112: invokeinterface getDouble : (I)D
/*      */     //   117: dload_1
/*      */     //   118: ddiv
/*      */     //   119: dstore #7
/*      */     //   121: aload #15
/*      */     //   123: iload #16
/*      */     //   125: dload #7
/*      */     //   127: invokeinterface setDouble : (ID)V
/*      */     //   132: iinc #6, 1
/*      */     //   135: iload #6
/*      */     //   137: iload_3
/*      */     //   138: if_icmplt -> 6
/*      */     //   141: goto -> 144
/*      */     //   144: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1063	-> 0
/*      */     //   #1064	-> 6
/*      */     //   #1064	-> 14
/*      */     //   #1064	-> 43
/*      */     //   #1065	-> 51
/*      */     //   #1066	-> 80
/*      */     //   #1063	-> 132
/*      */     //   #1063	-> 135
/*      */     //   #1067	-> 144
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	145	0	dimensions	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	145	1	sumDimensions	D
/*      */     //   0	145	3	n	I
/*      */     //   0	145	4	cmDimensions	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	145	5	cmDimension	I
/*      */     //   0	145	6	i	I
/*      */     //   0	145	14	i$295	I
/*      */     //   0	145	18	i$294	I
/*      */     //   0	145	23	i$293	I
/*      */     //   0	145	28	i$292	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void allCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1072 */     Ptr ptr2 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(564); allocDimension(widths, cmWidth, j, ptr2.pointerPlus(4576), 1);
/* 1073 */     Ptr ptr1 = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(560); allocDimension(heights, cmHeight, i, ptr1.pointerPlus(3776), 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void modifyDimension(Ptr dimension, double multiplier, double n, Ptr cmDimensions) {
/* 1080 */     for (i = 0; i < n; i++) {
/* 1081 */       int k = i * 4; Ptr ptr = cmDimensions; int j = k; if (ptr.getInt(j) == 0) {
/* 1082 */         int i3 = i * 8; Ptr ptr2 = dimension; int i2 = i3, i1 = i * 8; Ptr ptr1 = dimension; int m = i1; double d = ptr1.getDouble(m) * multiplier; ptr2.setDouble(i2, d);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void modifyRegions(Ptr widths, Ptr heights, double colMultiplier, double rowMultiplier, Ptr dd) {
/* 1089 */     Ptr ptr2 = base__.Rf_gpptr(dd); double d2 = base__.Rf_gpptr(dd).getInt(564); modifyDimension(widths, colMultiplier, d2, ptr2.pointerPlus(4576));
/* 1090 */     Ptr ptr1 = base__.Rf_gpptr(dd); double d1 = base__.Rf_gpptr(dd).getInt(560); modifyDimension(heights, rowMultiplier, d1, ptr1.pointerPlus(3776));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void regionsWithoutRespect(Ptr widths, Ptr heights, Ptr dd) {
/* 1097 */     Ptr ptr4 = base__.Rf_gpptr(dd); int m = base__.Rf_gpptr(dd).getInt(564); Ptr ptr3 = base__.Rf_gpptr(dd); int k = base__.Rf_gpptr(dd).getInt(564);
/*      */     double d2 = sum(widths, k, ptr3.pointerPlus(4576), 0);
/*      */     allocDimension(widths, d2, m, ptr4.pointerPlus(4576), 0);
/* 1100 */     Ptr ptr2 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(560);
/*      */     Ptr ptr1 = base__.Rf_gpptr(dd);
/*      */     int i = base__.Rf_gpptr(dd).getInt(560);
/*      */     double d1 = sum(heights, i, ptr1.pointerPlus(3776), 0);
/*      */     allocDimension(heights, d1, j, ptr2.pointerPlus(3776), 0);
/*      */   }
/*      */   public static void regionsWithRespect(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1107 */     rm = new double[1]; cm = new double[1]; rm[0] = 0.0D; cm[0] = 0.0D; layoutRegion((Ptr)new DoublePtr(cm, 0), (Ptr)new DoublePtr(rm, 0), widths, heights, cmWidth, cmHeight, dd);
/* 1108 */     regionsWithoutRespect(widths, heights, dd);
/* 1109 */     rm$287 = rm[0]; cm$288 = cm[0]; modifyRegions(widths, heights, cm$288, rm$287, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void widthsRespectingHeights(Ptr widths, double cmWidth, double cmHeight, Ptr dd) {
/* 1119 */     respectedCols = new int[200]; nr = 0; disrespectedWidth = 0.0D; widthLeft = 0.0D; i = 0; disrespectedWidth = 0.0D;
/* 1120 */     nr = base__.Rf_gpptr(dd).getInt(560);
/* 1121 */     for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++) {
/* 1122 */       respectedCols[j] = 0;
/* 1123 */       int m = j * 8; Ptr ptr = widths; int k = m; double d = base__.Rf_gpptr(dd).getDouble(2176 + j * 8); ptr.setDouble(k, d);
/*      */     } 
/* 1125 */     for (i = 0; i < nr; i++) {
/* 1126 */       for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++)
/* 1127 */       { Ptr ptr = base__.Rf_gpptr(dd); int k = j * nr + i; if ((ptr.getByte(25396 + k) & 0xFF) != 0 && 
/* 1128 */           base__.Rf_gpptr(dd).getInt(4576 + j * 4) == 0) respectedCols[j] = 1;  } 
/* 1129 */     }  for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++) {
/* 1130 */       if (respectedCols[j] == 0)
/* 1131 */         disrespectedWidth = base__.Rf_gpptr(dd).getDouble(2176 + j * 8) + disrespectedWidth; 
/* 1132 */     }  double d2 = sumHeights(dd) * cmWidth / cmHeight;
/* 1133 */     double d1 = sumWidths(dd); widthLeft = d2 - d1 + disrespectedWidth;
/* 1134 */     for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++) {
/* 1135 */       if (respectedCols[j] == 0) {
/* 1136 */         int i1 = j * 8; Ptr ptr2 = widths; int n = i1, m = j * 8; Ptr ptr1 = widths; int k = m; double d = ptr1.getDouble(k) * widthLeft / disrespectedWidth; ptr2.setDouble(n, d);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void regionsRespectingHeight(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1143 */     widthsRespectingHeights(widths, cmWidth, cmHeight, dd);
/* 1144 */     regionsWithRespect(widths, heights, cmWidth, cmHeight, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void heightsRespectingWidths(Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1154 */     respectedRows = new int[200]; nr = 0; disrespectedHeight = 0.0D; heightLeft = 0.0D; i = 0; disrespectedHeight = 0.0D;
/* 1155 */     nr = base__.Rf_gpptr(dd).getInt(560);
/* 1156 */     for (i = 0; i < nr; i++) {
/* 1157 */       respectedRows[i] = 0;
/* 1158 */       int m = i * 8; Ptr ptr = heights; int k = m; double d = base__.Rf_gpptr(dd).getDouble(576 + i * 8); ptr.setDouble(k, d);
/*      */     } 
/* 1160 */     for (i = 0; i < nr; i++) {
/* 1161 */       for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++)
/* 1162 */       { Ptr ptr = base__.Rf_gpptr(dd); int k = j * nr + i; if ((ptr.getByte(25396 + k) & 0xFF) != 0 && 
/* 1163 */           base__.Rf_gpptr(dd).getInt(3776 + i * 4) == 0) respectedRows[i] = 1;  } 
/* 1164 */     }  for (i = 0; base__.Rf_gpptr(dd).getInt(560) > i; i++) {
/* 1165 */       if (respectedRows[i] == 0)
/* 1166 */         disrespectedHeight = base__.Rf_gpptr(dd).getDouble(576 + i * 8) + disrespectedHeight; 
/* 1167 */     }  double d2 = sumWidths(dd) * cmHeight / cmWidth;
/* 1168 */     double d1 = sumHeights(dd); heightLeft = d2 - d1 + disrespectedHeight;
/* 1169 */     for (i = 0; base__.Rf_gpptr(dd).getInt(560) > i; i++) {
/* 1170 */       if (respectedRows[i] == 0) {
/* 1171 */         int i1 = i * 8; Ptr ptr2 = heights; int n = i1, m = i * 8; Ptr ptr1 = heights; int k = m; double d = ptr1.getDouble(k) * heightLeft / disrespectedHeight; ptr2.setDouble(n, d);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void regionsRespectingWidth(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1178 */     heightsRespectingWidths(heights, cmWidth, cmHeight, dd);
/* 1179 */     regionsWithRespect(widths, heights, cmWidth, cmHeight, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void noCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1185 */     switch (base__.Rf_gpptr(dd).getInt(25392)) {
/*      */       case 0:
/* 1187 */         regionsWithoutRespect(widths, heights, dd);
/*      */         break;
/*      */       case 1:
/* 1190 */         regionsWithRespect(widths, heights, cmWidth, cmHeight, dd);
/*      */         break;
/*      */       case 2:
/* 1193 */         if (tallLayout(cmWidth, cmHeight, dd) == 0) {
/*      */ 
/*      */           
/* 1196 */           regionsRespectingHeight(widths, heights, cmWidth, cmHeight, dd);
/*      */           break;
/*      */         } 
/*      */         regionsRespectingWidth(widths, heights, cmWidth, cmHeight, dd);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   public static void notAllCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1204 */     double d6 = sumCmWidths(dd); newCmWidth = cmWidth - d6;
/* 1205 */     double d5 = sumCmHeights(dd); newCmHeight = cmHeight - d5;
/* 1206 */     noCmRegions(widths, heights, newCmWidth, newCmHeight, dd);
/* 1207 */     Ptr ptr4 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(564); allocDimension(widths, cmWidth, j, ptr4.pointerPlus(4576), 1);
/* 1208 */     Ptr ptr3 = base__.Rf_gpptr(dd); int i = base__.Rf_gpptr(dd).getInt(560); allocDimension(heights, cmHeight, i, ptr3.pointerPlus(3776), 1);
/*      */     
/* 1210 */     Ptr ptr2 = base__.Rf_gpptr(dd); double d4 = base__.Rf_gpptr(dd).getInt(564), d3 = newCmWidth / cmWidth;
/*      */     modifyDimension(widths, d3, d4, ptr2.pointerPlus(4576));
/* 1212 */     Ptr ptr1 = base__.Rf_gpptr(dd);
/*      */     double d2 = base__.Rf_gpptr(dd).getInt(560), d1 = newCmHeight / cmHeight;
/*      */     modifyDimension(heights, d1, d2, ptr1.pointerPlus(3776));
/*      */   }
/*      */   
/*      */   public static void widthCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1218 */     Ptr ptr4 = base__.Rf_gpptr(dd); int k = base__.Rf_gpptr(dd).getInt(564); allocDimension(widths, cmWidth, k, ptr4.pointerPlus(4576), 1);
/*      */     
/* 1220 */     Ptr ptr3 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(560); double d4 = sumHeights(dd);
/*      */     allocDimension(heights, d4, j, ptr3.pointerPlus(3776), 0);
/* 1222 */     Ptr ptr2 = base__.Rf_gpptr(dd); double d3 = base__.Rf_gpptr(dd).getInt(560), d2 = sumCmHeights(dd), d1 = (cmHeight - d2) / cmHeight;
/*      */     modifyDimension(heights, d1, d3, ptr2.pointerPlus(3776));
/* 1224 */     Ptr ptr1 = base__.Rf_gpptr(dd);
/*      */     int i = base__.Rf_gpptr(dd).getInt(560);
/*      */     allocDimension(heights, cmHeight, i, ptr1.pointerPlus(3776), 1);
/*      */   }
/*      */   
/*      */   public static void heightCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1230 */     Ptr ptr4 = base__.Rf_gpptr(dd); int k = base__.Rf_gpptr(dd).getInt(560); allocDimension(heights, cmHeight, k, ptr4.pointerPlus(3776), 1);
/*      */     
/* 1232 */     Ptr ptr3 = base__.Rf_gpptr(dd); int j = base__.Rf_gpptr(dd).getInt(564); double d4 = sumWidths(dd);
/*      */     allocDimension(widths, d4, j, ptr3.pointerPlus(4576), 0);
/* 1234 */     Ptr ptr2 = base__.Rf_gpptr(dd); double d3 = base__.Rf_gpptr(dd).getInt(564), d2 = sumCmWidths(dd), d1 = (cmWidth - d2) / cmWidth;
/*      */     modifyDimension(widths, d1, d3, ptr2.pointerPlus(4576));
/* 1236 */     Ptr ptr1 = base__.Rf_gpptr(dd);
/*      */     int i = base__.Rf_gpptr(dd).getInt(564);
/*      */     allocDimension(widths, cmWidth, i, ptr1.pointerPlus(4576), 1);
/*      */   }
/*      */   
/*      */   public static int allCmWidths(Ptr dd) { boolean bool;
/* 1242 */     j = 0; while (true) { if (base__.Rf_gpptr(dd).getInt(564) <= j) {
/*      */ 
/*      */         
/* 1245 */         boolean bool1 = true; break;
/*      */       }  if (base__.Rf_gpptr(dd).getInt(4576 + j * 4) != 0) {
/*      */         j++; continue;
/*      */       }  bool = false; break; }
/*      */     
/*      */     return bool; } public static int allCmHeights(Ptr dd) { boolean bool;
/* 1251 */     i = 0; while (true) { if (base__.Rf_gpptr(dd).getInt(560) <= i) {
/*      */ 
/*      */         
/* 1254 */         boolean bool1 = true; break;
/*      */       }  if (base__.Rf_gpptr(dd).getInt(3776 + i * 4) != 0) {
/*      */         i++; continue;
/*      */       }  bool = false; break; }
/*      */     
/*      */     return bool; } public static int noCmWidths(Ptr dd) { boolean bool;
/* 1260 */     j = 0; while (true) { if (base__.Rf_gpptr(dd).getInt(564) <= j) {
/*      */ 
/*      */         
/* 1263 */         boolean bool1 = true; break;
/*      */       }  if (base__.Rf_gpptr(dd).getInt(4576 + j * 4) == 0) {
/*      */         j++; continue;
/*      */       }  bool = false; break; }
/*      */     
/*      */     return bool; } public static int noCmHeights(Ptr dd) { boolean bool;
/* 1269 */     i = 0; while (true) { if (base__.Rf_gpptr(dd).getInt(560) <= i) {
/*      */ 
/*      */         
/* 1272 */         boolean bool1 = true; break;
/*      */       }  if (base__.Rf_gpptr(dd).getInt(3776 + i * 4) == 0) {
/*      */         i++; continue;
/*      */       }  bool = false;
/*      */       break; }
/*      */     
/* 1278 */     return bool; } public static void someCmRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) { if (allCmWidths(dd) == 0) {
/*      */       
/* 1280 */       if (allCmHeights(dd) == 0) {
/*      */ 
/*      */         
/* 1283 */         notAllCmRegions(widths, heights, cmWidth, cmHeight, dd); return;
/*      */       } 
/*      */       heightCmRegions(widths, heights, cmWidth, cmHeight, dd);
/*      */       return;
/*      */     } 
/* 1288 */     widthCmRegions(widths, heights, cmWidth, cmHeight, dd); } public static int allCm(Ptr dd) { return (allCmWidths(dd) == 0 || allCmHeights(dd) == 0) ? 0 : 1; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int noCm(Ptr dd) {
/* 1293 */     return (noCmWidths(dd) == 0 || noCmHeights(dd) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void layoutRegions(Ptr widths, Ptr heights, double cmWidth, double cmHeight, Ptr dd) {
/* 1300 */     for (j = 0; base__.Rf_gpptr(dd).getInt(564) > j; j++) {
/* 1301 */       int m = j * 8; Ptr ptr = widths; int k = m; double d = base__.Rf_gpptr(dd).getDouble(2176 + j * 8); ptr.setDouble(k, d);
/* 1302 */     }  for (i = 0; base__.Rf_gpptr(dd).getInt(560) > i; i++) {
/* 1303 */       int m = i * 8; Ptr ptr = heights; int k = m; double d = base__.Rf_gpptr(dd).getDouble(576 + i * 8); ptr.setDouble(k, d);
/*      */     } 
/* 1305 */     if (allCm(dd) == 0) {
/*      */       
/* 1307 */       if (noCm(dd) == 0) {
/*      */ 
/*      */         
/* 1310 */         someCmRegions(widths, heights, cmWidth, cmHeight, dd);
/*      */         return;
/*      */       } 
/*      */       noCmRegions(widths, heights, cmWidth, cmHeight, dd);
/*      */       return;
/*      */     } 
/*      */     allCmRegions(widths, heights, cmWidth, cmHeight, dd);
/*      */   } public static void subRegion(Ptr left, Ptr right, Ptr bottom, Ptr top, int mincol, int maxcol, int minrow, int maxrow, Ptr widths, Ptr heights, Ptr dd) {
/* 1318 */     int m = base__.Rf_gpptr(dd).getInt(564) + -1; totalWidth = sumRegions(widths, 0, m);
/* 1319 */     int k = base__.Rf_gpptr(dd).getInt(560) + -1; totalHeight = sumRegions(heights, 0, k);
/* 1320 */     double d16 = totalWidth / 2.0D, d15 = 0.5D - d16; int j = mincol + -1; double d14 = sumRegions(widths, 0, j), d13 = d15 + d14; left.setDouble(d13);
/* 1321 */     double d12 = totalWidth / 2.0D, d11 = 0.5D - d12, d10 = sumRegions(widths, 0, maxcol), d9 = d11 + d10; right.setDouble(d9);
/* 1322 */     double d8 = totalHeight / 2.0D, d7 = 0.5D - d8 + totalHeight;
/* 1323 */     double d6 = sumRegions(heights, 0, maxrow), d5 = d7 - d6; bottom.setDouble(d5);
/* 1324 */     double d4 = totalHeight / 2.0D, d3 = 0.5D - d4 + totalHeight;
/* 1325 */     int i = minrow + -1; double d2 = sumRegions(heights, 0, i), d1 = d3 - d2;
/*      */     top.setDouble(d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_currentFigureLocation(Ptr row, Ptr col, Ptr dd) {
/* 1335 */     maxrow = new int[1]; maxcol = new int[1]; maxrow[0] = 0; maxcol[0] = 0; if (base__.Rf_gpptr(dd).getInt(556) == 0) {
/*      */       
/* 1337 */       if (base__.Rf_gpptr(dd).getInt(0 + 35404) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1342 */         int i8 = base__.Rf_gpptr(dd).getInt(568) + -1, i7 = base__.Rf_gpptr(dd).getInt(564), i6 = i8 / i7; row.setInt(i6);
/* 1343 */         int i5 = base__.Rf_gpptr(dd).getInt(568) + -1, i4 = base__.Rf_gpptr(dd).getInt(564), i3 = i5 % i4; col.setInt(i3);
/*      */         return;
/*      */       } 
/*      */       int i2 = base__.Rf_gpptr(dd).getInt(568) + -1, i1 = base__.Rf_gpptr(dd).getInt(560), n = i2 % i1;
/*      */       row.setInt(n);
/*      */       int m = base__.Rf_gpptr(dd).getInt(568) + -1, k = base__.Rf_gpptr(dd).getInt(560), j = m / k;
/*      */       col.setInt(j);
/*      */       return;
/*      */     } 
/*      */     int i = base__.Rf_gpptr(dd).getInt(568);
/*      */     figureExtent(col, (Ptr)new IntPtr(maxcol, 0), row, (Ptr)new IntPtr(maxrow, 0), i, dd);
/*      */   }
/*      */   
/* 1356 */   public static void mapNDC2Dev(Ptr dd) { double d60 = dd.getPointer().getDouble(96), d59 = dd.getPointer().getDouble(88); asp = d60 / d59;
/*      */     
/* 1358 */     Ptr ptr20 = base__.Rf_gpptr(dd), ptr19 = base__.Rf_dpptr(dd);
/* 1359 */     double d58 = dd.getPointer().getDouble(8), d57 = dd.getPointer().getDouble(), d56 = d58 - d57; ptr19.setDouble(0 + 35884 + 8, d56); double d55 = ptr19.getDouble(0 + 35884 + 8); ptr20.setDouble(0 + 35884 + 8, d55);
/* 1360 */     Ptr ptr18 = base__.Rf_gpptr(dd), ptr17 = base__.Rf_dpptr(dd); double d54 = dd.getPointer().getDouble(); ptr17.setDouble(0 + 35884, d54); double d53 = ptr17.getDouble(0 + 35884); ptr18.setDouble(0 + 35884, d53);
/* 1361 */     Ptr ptr16 = base__.Rf_gpptr(dd), ptr15 = base__.Rf_dpptr(dd);
/* 1362 */     double d52 = dd.getPointer().getDouble(24), d51 = dd.getPointer().getDouble(16), d50 = d52 - d51; ptr15.setDouble(0 + 35884 + 24, d50); double d49 = ptr15.getDouble(0 + 35884 + 24); ptr16.setDouble(0 + 35884 + 24, d49);
/* 1363 */     Ptr ptr14 = base__.Rf_gpptr(dd), ptr13 = base__.Rf_dpptr(dd); double d48 = dd.getPointer().getDouble(16); ptr13.setDouble(0 + 35884 + 16, d48); double d47 = ptr13.getDouble(0 + 35884 + 16); ptr14.setDouble(0 + 35884 + 16, d47);
/*      */ 
/*      */     
/* 1366 */     Ptr ptr12 = base__.Rf_gpptr(dd), ptr11 = base__.Rf_dpptr(dd);
/* 1367 */     double d46 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8), d45 = dd.getPointer().getDouble(88), d44 = Math.abs(d46 * d45), d43 = 1.0D / d44; ptr11.setDouble(0 + 35804, d43); double d42 = ptr11.getDouble(0 + 35804); ptr12.setDouble(0 + 35804, d42);
/* 1368 */     Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd);
/* 1369 */     double d41 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24), d40 = dd.getPointer().getDouble(96), d39 = Math.abs(d41 * d40), d38 = 1.0D / d39; ptr9.setDouble(0 + 35812, d38); double d37 = ptr9.getDouble(0 + 35812); ptr10.setDouble(0 + 35812, d37);
/* 1370 */     Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd);
/* 1371 */     double d36 = base__.Rf_gpptr(dd).getDouble(484), d35 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d34 = d36 * d35;
/* 1372 */     double d33 = dd.getPointer().getDouble(112), d32 = d34 * d33 * asp, d31 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8); double d30 = Math.abs(d32 / d31); ptr7.setDouble(0 + 35772, d30); double d29 = ptr7.getDouble(0 + 35772); ptr8.setDouble(0 + 35772, d29);
/* 1373 */     Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd);
/* 1374 */     double d28 = base__.Rf_gpptr(dd).getDouble(484), d27 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d26 = d28 * d27;
/* 1375 */     double d25 = dd.getPointer().getDouble(112); double d24 = d26 * d25; double d23 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24); double d22 = Math.abs(d24 / d23); ptr5.setDouble(0 + 35780, d22); double d21 = ptr5.getDouble(0 + 35780); ptr6.setDouble(0 + 35780, d21);
/* 1376 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd);
/* 1377 */     double d20 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d19 = base__.Rf_gpptr(dd).getDouble(484), d18 = d20 * d19, d17 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d16 = d18 * d17;
/* 1378 */     double d15 = dd.getPointer().getDouble(112), d14 = d16 * d15 * asp, d13 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 8); double d12 = Math.abs(d14 / d13); ptr3.setDouble(0 + 35788, d12); double d11 = ptr3.getDouble(0 + 35788); ptr4.setDouble(0 + 35788, d11);
/* 1379 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd);
/* 1380 */     double d10 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d9 = base__.Rf_gpptr(dd).getDouble(484), d8 = d10 * d9, d7 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d6 = d8 * d7;
/* 1381 */     double d5 = dd.getPointer().getDouble(112); double d4 = d6 * d5; double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35884 + 24); double d2 = Math.abs(d4 / d3); ptr1.setDouble(0 + 35796, d2); double d1 = ptr1.getDouble(0 + 35796); ptr2.setDouble(0 + 35796, d1); } public static void updateOuterMargins(Ptr dd) { double d1; double d2; double d3; Ptr ptr1; Ptr ptr2; double d4; double d5; double d6; Ptr ptr3; Ptr ptr4; double d7; double d8; Ptr ptr5; Ptr ptr6; double d9; double d10; Ptr ptr7; Ptr ptr8; double d11; double d12; double d13; Ptr ptr9; Ptr ptr10; double d14; double d15; double d16; Ptr ptr11; Ptr ptr12; double d17; double d18; Ptr ptr13; Ptr ptr14; double d19; double d20; Ptr ptr15; Ptr ptr16; double d21; double d22; double d23; Ptr ptr17; Ptr ptr18; double d24; double d25; Ptr ptr19; Ptr ptr20; double d26; double d27; double d28; Ptr ptr21; Ptr ptr22; double d29; double d30; Ptr ptr23; Ptr ptr24; double d31; double d32; Ptr ptr25; Ptr ptr26; double d33; double d34; Ptr ptr27; Ptr ptr28; double d35; double d36; Ptr ptr29; Ptr ptr30; double d37; double d38; Ptr ptr31; Ptr ptr32; double d39; double d40; double d41; Ptr ptr33; Ptr ptr34; double d42; double d43; Ptr ptr35; Ptr ptr36; double d44; double d45; double d46; Ptr ptr37; Ptr ptr38; double d47; double d48; Ptr ptr39; Ptr ptr40; double d49; double d50; Ptr ptr41; Ptr ptr42; double d51; double d52; Ptr ptr43; Ptr ptr44; double d53; double d54; Ptr ptr45; Ptr ptr46;
/*      */     double d55;
/*      */     double d56;
/*      */     Ptr ptr47;
/*      */     Ptr ptr48;
/* 1386 */     switch (base__.Rf_gpptr(dd).getInt(0 + 35692)) {
/*      */       case 14:
/* 1388 */         ptr48 = base__.Rf_gpptr(dd); ptr47 = base__.Rf_dpptr(dd);
/* 1389 */         d56 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596), 14, 13, dd); ptr47.setDouble(0 + 35628, d56); d55 = ptr47.getDouble(0 + 35628); ptr48.setDouble(0 + 35628, d55);
/* 1390 */         ptr46 = base__.Rf_gpptr(dd); ptr45 = base__.Rf_dpptr(dd);
/* 1391 */         d54 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8), 14, 13, dd); ptr45.setDouble(0 + 35628 + 8, d54); d53 = ptr45.getDouble(0 + 35628 + 8); ptr46.setDouble(0 + 35628 + 8, d53);
/* 1392 */         ptr44 = base__.Rf_gpptr(dd); ptr43 = base__.Rf_dpptr(dd);
/* 1393 */         d52 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 16), 14, 13, dd); ptr43.setDouble(0 + 35628 + 16, d52); d51 = ptr43.getDouble(0 + 35628 + 16); ptr44.setDouble(0 + 35628 + 16, d51);
/* 1394 */         ptr42 = base__.Rf_gpptr(dd); ptr41 = base__.Rf_dpptr(dd);
/* 1395 */         d50 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 24), 14, 13, dd); ptr41.setDouble(0 + 35628 + 24, d50); d49 = ptr41.getDouble(0 + 35628 + 24); ptr42.setDouble(0 + 35628 + 24, d49);
/* 1396 */         ptr40 = base__.Rf_gpptr(dd); ptr39 = base__.Rf_dpptr(dd);
/* 1397 */         d48 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8), 14, 1, dd); ptr39.setDouble(0 + 35660, d48); d47 = ptr39.getDouble(0 + 35660); ptr40.setDouble(0 + 35660, d47);
/* 1398 */         ptr38 = base__.Rf_gpptr(dd); ptr37 = base__.Rf_dpptr(dd);
/* 1399 */         d46 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 24), 14, 1, dd); d45 = 1.0D - d46; ptr37.setDouble(0 + 35660 + 8, d45); d44 = ptr37.getDouble(0 + 35660 + 8); ptr38.setDouble(0 + 35660 + 8, d44);
/* 1400 */         ptr36 = base__.Rf_gpptr(dd); ptr35 = base__.Rf_dpptr(dd);
/* 1401 */         d43 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596), 14, 1, dd); ptr35.setDouble(0 + 35660 + 16, d43); d42 = ptr35.getDouble(0 + 35660 + 16); ptr36.setDouble(0 + 35660 + 16, d42);
/* 1402 */         ptr34 = base__.Rf_gpptr(dd); ptr33 = base__.Rf_dpptr(dd);
/* 1403 */         d41 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 16), 14, 1, dd); d40 = 1.0D - d41; ptr33.setDouble(0 + 35660 + 24, d40); d39 = ptr33.getDouble(0 + 35660 + 24); ptr34.setDouble(0 + 35660 + 24, d39);
/*      */         break;
/*      */       case 13:
/* 1406 */         ptr32 = base__.Rf_gpptr(dd); ptr31 = base__.Rf_dpptr(dd);
/* 1407 */         d38 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628), 13, 14, dd); ptr31.setDouble(0 + 35596, d38); d37 = ptr31.getDouble(0 + 35596); ptr32.setDouble(0 + 35596, d37);
/* 1408 */         ptr30 = base__.Rf_gpptr(dd); ptr29 = base__.Rf_dpptr(dd);
/* 1409 */         d36 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 8), 13, 14, dd); ptr29.setDouble(0 + 35596 + 8, d36); d35 = ptr29.getDouble(0 + 35596 + 8); ptr30.setDouble(0 + 35596 + 8, d35);
/* 1410 */         ptr28 = base__.Rf_gpptr(dd); ptr27 = base__.Rf_dpptr(dd);
/* 1411 */         d34 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 16), 13, 14, dd); ptr27.setDouble(0 + 35596 + 16, d34); d33 = ptr27.getDouble(0 + 35596 + 16); ptr28.setDouble(0 + 35596 + 16, d33);
/* 1412 */         ptr26 = base__.Rf_gpptr(dd); ptr25 = base__.Rf_dpptr(dd);
/* 1413 */         d32 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 24), 13, 14, dd); ptr25.setDouble(0 + 35596 + 24, d32); d31 = ptr25.getDouble(0 + 35596 + 24); ptr26.setDouble(0 + 35596 + 24, d31);
/* 1414 */         ptr24 = base__.Rf_gpptr(dd); ptr23 = base__.Rf_dpptr(dd);
/* 1415 */         d30 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 8), 13, 1, dd); ptr23.setDouble(0 + 35660, d30); d29 = ptr23.getDouble(0 + 35660); ptr24.setDouble(0 + 35660, d29);
/* 1416 */         ptr22 = base__.Rf_gpptr(dd); ptr21 = base__.Rf_dpptr(dd);
/* 1417 */         d28 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 24), 13, 1, dd); d27 = 1.0D - d28; ptr21.setDouble(0 + 35660 + 8, d27); d26 = ptr21.getDouble(0 + 35660 + 8); ptr22.setDouble(0 + 35660 + 8, d26);
/* 1418 */         ptr20 = base__.Rf_gpptr(dd); ptr19 = base__.Rf_dpptr(dd);
/* 1419 */         d25 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628), 13, 1, dd); ptr19.setDouble(0 + 35660 + 16, d25); d24 = ptr19.getDouble(0 + 35660 + 16); ptr20.setDouble(0 + 35660 + 16, d24);
/* 1420 */         ptr18 = base__.Rf_gpptr(dd); ptr17 = base__.Rf_dpptr(dd);
/* 1421 */         d23 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35628 + 16), 13, 1, dd); d22 = 1.0D - d23; ptr17.setDouble(0 + 35660 + 24, d22); d21 = ptr17.getDouble(0 + 35660 + 24); ptr18.setDouble(0 + 35660 + 24, d21);
/*      */         break;
/*      */       case 1:
/* 1424 */         ptr16 = base__.Rf_gpptr(dd); ptr15 = base__.Rf_dpptr(dd);
/* 1425 */         d20 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35660 + 16), 1, 14, dd); ptr15.setDouble(0 + 35596, d20); d19 = ptr15.getDouble(0 + 35596); ptr16.setDouble(0 + 35596, d19);
/* 1426 */         ptr14 = base__.Rf_gpptr(dd); ptr13 = base__.Rf_dpptr(dd);
/* 1427 */         d18 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35660), 1, 14, dd); ptr13.setDouble(0 + 35596 + 8, d18); d17 = ptr13.getDouble(0 + 35596 + 8); ptr14.setDouble(0 + 35596 + 8, d17);
/* 1428 */         ptr12 = base__.Rf_gpptr(dd); ptr11 = base__.Rf_dpptr(dd);
/* 1429 */         d16 = base__.Rf_gpptr(dd).getDouble(0 + 35660 + 24); d15 = Rf_GConvertYUnits(1.0D - d16, 1, 14, dd); ptr11.setDouble(0 + 35596 + 16, d15); d14 = ptr11.getDouble(0 + 35596 + 16); ptr12.setDouble(0 + 35596 + 16, d14);
/* 1430 */         ptr10 = base__.Rf_gpptr(dd); ptr9 = base__.Rf_dpptr(dd);
/* 1431 */         d13 = base__.Rf_gpptr(dd).getDouble(0 + 35660 + 8); d12 = Rf_GConvertXUnits(1.0D - d13, 1, 14, dd); ptr9.setDouble(0 + 35596 + 24, d12); d11 = ptr9.getDouble(0 + 35596 + 24); ptr10.setDouble(0 + 35596 + 24, d11);
/* 1432 */         ptr8 = base__.Rf_gpptr(dd); ptr7 = base__.Rf_dpptr(dd);
/* 1433 */         d10 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35660 + 16), 1, 13, dd); ptr7.setDouble(0 + 35628, d10); d9 = ptr7.getDouble(0 + 35628); ptr8.setDouble(0 + 35628, d9);
/* 1434 */         ptr6 = base__.Rf_gpptr(dd); ptr5 = base__.Rf_dpptr(dd);
/* 1435 */         d8 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35660), 1, 13, dd); ptr5.setDouble(0 + 35628 + 8, d8); d7 = ptr5.getDouble(0 + 35628 + 8); ptr6.setDouble(0 + 35628 + 8, d7);
/* 1436 */         ptr4 = base__.Rf_gpptr(dd); ptr3 = base__.Rf_dpptr(dd);
/* 1437 */         d6 = base__.Rf_gpptr(dd).getDouble(0 + 35660 + 24); d5 = Rf_GConvertYUnits(1.0D - d6, 1, 13, dd); ptr3.setDouble(0 + 35628 + 16, d5); d4 = ptr3.getDouble(0 + 35628 + 16); ptr4.setDouble(0 + 35628 + 16, d4);
/* 1438 */         ptr2 = base__.Rf_gpptr(dd); ptr1 = base__.Rf_dpptr(dd);
/* 1439 */         d3 = base__.Rf_gpptr(dd).getDouble(0 + 35660 + 8); d2 = Rf_GConvertXUnits(1.0D - d3, 1, 13, dd);
/*      */         ptr1.setDouble(0 + 35628 + 24, d2);
/*      */         d1 = ptr1.getDouble(0 + 35628 + 24);
/*      */         ptr2.setDouble(0 + 35628 + 24, d1);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mapInner2Dev(Ptr dd) {
/* 1456 */     x0 = xLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 8), dd);
/* 1457 */     y0 = yLinetoDev(base__.Rf_gpptr(dd).getDouble(0 + 35596), dd);
/* 1458 */     x1 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 24), 14, 1, dd);
/* 1459 */     x1 = xNDCtoDev(1.0D - x1, dd);
/* 1460 */     y1 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35596 + 16), 14, 1, dd);
/* 1461 */     y1 = yNDCtoDev(1.0D - y1, dd);
/* 1462 */     Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); double d6 = x1 - x0; ptr7.setDouble(0 + 35852 + 8, d6); double d5 = ptr7.getDouble(0 + 35852 + 8); ptr8.setDouble(0 + 35852 + 8, d5);
/* 1463 */     Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); ptr5.setDouble(0 + 35852, x0); double d4 = ptr5.getDouble(0 + 35852); ptr6.setDouble(0 + 35852, d4);
/* 1464 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); double d3 = y1 - y0; ptr3.setDouble(0 + 35852 + 24, d3); double d2 = ptr3.getDouble(0 + 35852 + 24); ptr4.setDouble(0 + 35852 + 24, d2);
/* 1465 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); ptr1.setDouble(0 + 35852 + 16, y0); double d1 = ptr1.getDouble(0 + 35852 + 16); ptr2.setDouble(0 + 35852 + 16, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mapFigureRegion(Ptr dd) {
/* 1475 */     heights = new double[200]; widths = new double[200]; y1 = new double[1]; y0 = new double[1]; x1 = new double[1]; x0 = new double[1]; maxrow = new int[1]; minrow = new int[1]; maxcol = new int[1]; mincol = new int[1]; y1[0] = 0.0D; y0[0] = 0.0D; x1[0] = 0.0D; x0[0] = 0.0D; maxrow[0] = 0; minrow[0] = 0; maxcol[0] = 0; mincol[0] = 0; if (base__.Rf_gpptr(dd).getInt(556) == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1487 */       if (base__.Rf_gpptr(dd).getInt(0 + 35404) == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 1492 */         int i2 = base__.Rf_gpptr(dd).getInt(568) + -1, i1 = base__.Rf_gpptr(dd).getInt(564); row = i2 / i1 + 1;
/* 1493 */         int n = base__.Rf_gpptr(dd).getInt(568), m = 1 - row, k = base__.Rf_gpptr(dd).getInt(564), j = m * k; col = n + j; }
/*      */       else { int i2 = base__.Rf_gpptr(dd).getInt(568) + -1, i1 = base__.Rf_gpptr(dd).getInt(560); col = i2 / i1 + 1; int n = base__.Rf_gpptr(dd).getInt(568), m = 1 - col, k = base__.Rf_gpptr(dd).getInt(560), j = m * k; row = n + j; }
/* 1495 */        double d12 = (col + -1), d11 = base__.Rf_gpptr(dd).getInt(564); x0$269 = d12 / d11; x0[0] = x0$269;
/* 1496 */       double d10 = col, d9 = base__.Rf_gpptr(dd).getInt(564); x1$270 = d10 / d9; x1[0] = x1$270;
/* 1497 */       double d8 = (base__.Rf_gpptr(dd).getInt(560) - row), d7 = base__.Rf_gpptr(dd).getInt(560); y0$271 = d8 / d7; y0[0] = y0$271;
/* 1498 */       double d6 = (base__.Rf_gpptr(dd).getInt(560) - row + 1), d5 = base__.Rf_gpptr(dd).getInt(560); y1$272 = d6 / d5; y1[0] = y1$272; }
/*      */     else { double d6 = Rf_GConvertYUnits(1.0D, 6, 13, dd) * 2.54D, d5 = Rf_GConvertXUnits(1.0D, 6, 13, dd) * 2.54D; layoutRegions((Ptr)new DoublePtr(widths, 0), (Ptr)new DoublePtr(heights, 0), d5, d6, dd); int j = base__.Rf_gpptr(dd).getInt(568); figureExtent((Ptr)new IntPtr(mincol, 0), (Ptr)new IntPtr(maxcol, 0), (Ptr)new IntPtr(minrow, 0), (Ptr)new IntPtr(maxrow, 0), j, dd); maxrow$265 = maxrow[0]; minrow$266 = minrow[0]; maxcol$267 = maxcol[0]; mincol$268 = mincol[0]; subRegion((Ptr)new DoublePtr(x0, 0), (Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y0, 0), (Ptr)new DoublePtr(y1, 0), mincol$268, maxcol$267, minrow$266, maxrow$265, (Ptr)new DoublePtr(widths, 0), (Ptr)new DoublePtr(heights, 0), dd); }
/* 1500 */      Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); x0$273 = x0[0]; ptr9.setDouble(0 + 35408, x0$273); double d4 = ptr9.getDouble(0 + 35408); ptr10.setDouble(0 + 35408, d4);
/* 1501 */     Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); x1$274 = x1[0]; ptr7.setDouble(0 + 35408 + 8, x1$274); double d3 = ptr7.getDouble(0 + 35408 + 8); ptr8.setDouble(0 + 35408 + 8, d3);
/* 1502 */     Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); y0$275 = y0[0]; ptr5.setDouble(0 + 35408 + 16, y0$275); double d2 = ptr5.getDouble(0 + 35408 + 16); ptr6.setDouble(0 + 35408 + 16, d2);
/* 1503 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); y1$276 = y1[0]; ptr3.setDouble(0 + 35408 + 24, y1$276); double d1 = ptr3.getDouble(0 + 35408 + 24); ptr4.setDouble(0 + 35408 + 24, d1);
/* 1504 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); ptr1.setInt(0 + 35456, 6); int i = ptr1.getInt(0 + 35456); ptr2.setInt(0 + 35456, i); } public static void updateFigureRegion(Ptr dd) { double d1; double d2; Ptr ptr1; Ptr ptr2; double d3; double d4; double d5; Ptr ptr3; Ptr ptr4; double d6; double d7; Ptr ptr5; Ptr ptr6; double d8; double d9; double d10; Ptr ptr7; Ptr ptr8; double d11; double d12; double d13; double d14; Ptr ptr9; Ptr ptr10; double d15;
/*      */     double d16;
/*      */     double d17;
/*      */     double d18;
/*      */     Ptr ptr11;
/*      */     Ptr ptr12;
/* 1510 */     switch (base__.Rf_gpptr(dd).getInt(0 + 35456)) {
/*      */       case 6:
/* 1512 */         ptr12 = base__.Rf_gpptr(dd); ptr11 = base__.Rf_dpptr(dd);
/* 1513 */         d18 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 8); d17 = base__.Rf_gpptr(dd).getDouble(0 + 35408); d16 = Rf_GConvertXUnits(d18 - d17, 6, 13, dd); ptr11.setDouble(0 + 35440, d16); d15 = ptr11.getDouble(0 + 35440); ptr12.setDouble(0 + 35440, d15);
/* 1514 */         ptr10 = base__.Rf_gpptr(dd); ptr9 = base__.Rf_dpptr(dd);
/* 1515 */         d14 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 24); d13 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 16); d12 = Rf_GConvertYUnits(d14 - d13, 6, 13, dd); ptr9.setDouble(0 + 35440 + 8, d12); d11 = ptr9.getDouble(0 + 35440 + 8); ptr10.setDouble(0 + 35440 + 8, d11);
/*      */         break;
/*      */       case 13:
/* 1518 */         nicWidth = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35440), 13, 6, dd);
/* 1519 */         nicHeight = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35440 + 8), 13, 6, dd);
/* 1520 */         ptr8 = base__.Rf_gpptr(dd); ptr7 = base__.Rf_dpptr(dd); d10 = nicWidth / 2.0D; d9 = 0.5D - d10; ptr7.setDouble(0 + 35408, d9); d8 = ptr7.getDouble(0 + 35408); ptr8.setDouble(0 + 35408, d8);
/* 1521 */         ptr6 = base__.Rf_gpptr(dd); ptr5 = base__.Rf_dpptr(dd); d7 = base__.Rf_gpptr(dd).getDouble(0 + 35408) + nicWidth; ptr5.setDouble(0 + 35408 + 8, d7); d6 = ptr5.getDouble(0 + 35408 + 8); ptr6.setDouble(0 + 35408 + 8, d6);
/* 1522 */         ptr4 = base__.Rf_gpptr(dd); ptr3 = base__.Rf_dpptr(dd); d5 = nicHeight / 2.0D; d4 = 0.5D - d5; ptr3.setDouble(0 + 35408 + 16, d4); d3 = ptr3.getDouble(0 + 35408 + 16); ptr4.setDouble(0 + 35408 + 16, d3);
/* 1523 */         ptr2 = base__.Rf_gpptr(dd); ptr1 = base__.Rf_dpptr(dd); d2 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 16) + nicHeight; ptr1.setDouble(0 + 35408 + 24, d2); d1 = ptr1.getDouble(0 + 35408 + 24); ptr2.setDouble(0 + 35408 + 24, d1);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mapFig2Dev(Ptr dd) {
/* 1536 */     y0 = yNICtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35408 + 16), dd);
/* 1537 */     y1 = yNICtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35408 + 24), dd);
/* 1538 */     x0 = xNICtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35408), dd);
/* 1539 */     x1 = xNICtoDev(base__.Rf_gpptr(dd).getDouble(0 + 35408 + 8), dd);
/* 1540 */     Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); double d6 = x1 - x0; ptr7.setDouble(0 + 35820 + 8, d6); double d5 = ptr7.getDouble(0 + 35820 + 8); ptr8.setDouble(0 + 35820 + 8, d5);
/* 1541 */     Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); ptr5.setDouble(0 + 35820, x0); double d4 = ptr5.getDouble(0 + 35820); ptr6.setDouble(0 + 35820, d4);
/* 1542 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); double d3 = y1 - y0; ptr3.setDouble(0 + 35820 + 24, d3); double d2 = ptr3.getDouble(0 + 35820 + 24); ptr4.setDouble(0 + 35820 + 24, d2);
/* 1543 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); ptr1.setDouble(0 + 35820 + 16, y0); double d1 = ptr1.getDouble(0 + 35820 + 16); ptr2.setDouble(0 + 35820 + 16, d1); } public static void updateFigureMargins(Ptr dd) { double d1; double d2; Ptr ptr1; Ptr ptr2; double d3; double d4; Ptr ptr3; Ptr ptr4; double d5; double d6; Ptr ptr5; Ptr ptr6; double d7; double d8; Ptr ptr7; Ptr ptr8; double d9; double d10; Ptr ptr9; Ptr ptr10; double d11; double d12; Ptr ptr11; Ptr ptr12; double d13; double d14; Ptr ptr13; Ptr ptr14;
/*      */     double d15;
/*      */     double d16;
/*      */     Ptr ptr15;
/*      */     Ptr ptr16;
/* 1548 */     switch (base__.Rf_gpptr(dd).getInt(0 + 35584)) {
/*      */       case 14:
/* 1550 */         ptr16 = base__.Rf_gpptr(dd); ptr15 = base__.Rf_dpptr(dd);
/* 1551 */         d16 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520), 14, 13, dd); ptr15.setDouble(0 + 35552, d16); d15 = ptr15.getDouble(0 + 35552); ptr16.setDouble(0 + 35552, d15);
/* 1552 */         ptr14 = base__.Rf_gpptr(dd); ptr13 = base__.Rf_dpptr(dd);
/* 1553 */         d14 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 8), 14, 13, dd); ptr13.setDouble(0 + 35552 + 8, d14); d13 = ptr13.getDouble(0 + 35552 + 8); ptr14.setDouble(0 + 35552 + 8, d13);
/* 1554 */         ptr12 = base__.Rf_gpptr(dd); ptr11 = base__.Rf_dpptr(dd);
/* 1555 */         d12 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 16), 14, 13, dd); ptr11.setDouble(0 + 35552 + 16, d12); d11 = ptr11.getDouble(0 + 35552 + 16); ptr12.setDouble(0 + 35552 + 16, d11);
/* 1556 */         ptr10 = base__.Rf_gpptr(dd); ptr9 = base__.Rf_dpptr(dd);
/* 1557 */         d10 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 24), 14, 13, dd); ptr9.setDouble(0 + 35552 + 24, d10); d9 = ptr9.getDouble(0 + 35552 + 24); ptr10.setDouble(0 + 35552 + 24, d9);
/*      */         break;
/*      */       case 13:
/* 1560 */         ptr8 = base__.Rf_gpptr(dd); ptr7 = base__.Rf_dpptr(dd);
/* 1561 */         d8 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35552), 13, 14, dd); ptr7.setDouble(0 + 35520, d8); d7 = ptr7.getDouble(0 + 35520); ptr8.setDouble(0 + 35520, d7);
/* 1562 */         ptr6 = base__.Rf_gpptr(dd); ptr5 = base__.Rf_dpptr(dd);
/* 1563 */         d6 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35552 + 8), 13, 14, dd); ptr5.setDouble(0 + 35520 + 8, d6); d5 = ptr5.getDouble(0 + 35520 + 8); ptr6.setDouble(0 + 35520 + 8, d5);
/* 1564 */         ptr4 = base__.Rf_gpptr(dd); ptr3 = base__.Rf_dpptr(dd);
/* 1565 */         d4 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35552 + 16), 13, 14, dd); ptr3.setDouble(0 + 35520 + 16, d4); d3 = ptr3.getDouble(0 + 35520 + 16); ptr4.setDouble(0 + 35520 + 16, d3);
/* 1566 */         ptr2 = base__.Rf_gpptr(dd); ptr1 = base__.Rf_dpptr(dd);
/* 1567 */         d2 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35552 + 24), 13, 14, dd);
/*      */         ptr1.setDouble(0 + 35520 + 24, d2);
/*      */         d1 = ptr1.getDouble(0 + 35520 + 24);
/*      */         ptr2.setDouble(0 + 35520 + 24, d1);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mapPlotRegion(Ptr dd) {
/* 1578 */     x0 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 8), 14, 7, dd);
/* 1579 */     y0 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520), 14, 7, dd);
/* 1580 */     double d6 = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 24), 14, 7, dd); x1 = 1.0D - d6;
/* 1581 */     double d5 = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35520 + 16), 14, 7, dd); y1 = 1.0D - d5;
/* 1582 */     if (base__.Rf_gpptr(dd).getByte(0 + 35696) == (byte)115) {
/*      */ 
/*      */       
/* 1585 */       inchWidth = Rf_GConvertXUnits(x1 - x0, 7, 13, dd);
/* 1586 */       inchHeight = Rf_GConvertYUnits(y1 - y0, 7, 13, dd);
/*      */       
/* 1588 */       if (inchWidth <= inchHeight)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1595 */         height = Rf_GConvertYUnits(inchWidth, 13, 7, dd) * 0.5D;
/* 1596 */         center = (y1 + y0) * 0.5D;
/* 1597 */         y0 = center - height;
/* 1598 */         y1 = center + height; }
/*      */       else { width = Rf_GConvertXUnits(inchHeight, 13, 7, dd) * 0.5D; center = (x1 + x0) * 0.5D; x0 = center - width; x1 = center + width; }
/*      */     
/* 1601 */     }  Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); ptr9.setDouble(0 + 35460, x0); double d4 = ptr9.getDouble(0 + 35460); ptr10.setDouble(0 + 35460, d4);
/* 1602 */     Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); ptr7.setDouble(0 + 35460 + 8, x1); double d3 = ptr7.getDouble(0 + 35460 + 8); ptr8.setDouble(0 + 35460 + 8, d3);
/* 1603 */     Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); ptr5.setDouble(0 + 35460 + 16, y0); double d2 = ptr5.getDouble(0 + 35460 + 16); ptr6.setDouble(0 + 35460 + 16, d2);
/* 1604 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); ptr3.setDouble(0 + 35460 + 24, y1); double d1 = ptr3.getDouble(0 + 35460 + 24); ptr4.setDouble(0 + 35460 + 24, d1);
/* 1605 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); ptr1.setInt(0 + 35508, 7); int i = ptr1.getInt(0 + 35508); ptr2.setInt(0 + 35508, i); } public static void updatePlotRegion(Ptr dd) { double d1; double d2; Ptr ptr1; Ptr ptr2; double d3; double d4; double d5; Ptr ptr3; Ptr ptr4; double d6; double d7; Ptr ptr5; Ptr ptr6; double d8; double d9; double d10; Ptr ptr7; Ptr ptr8; double d11; double d12; double d13; double d14; Ptr ptr9; Ptr ptr10; double d15;
/*      */     double d16;
/*      */     double d17;
/*      */     double d18;
/*      */     Ptr ptr11;
/*      */     Ptr ptr12;
/* 1611 */     switch (base__.Rf_gpptr(dd).getInt(0 + 35508)) {
/*      */       case 7:
/* 1613 */         ptr12 = base__.Rf_gpptr(dd); ptr11 = base__.Rf_dpptr(dd);
/* 1614 */         d18 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8); d17 = base__.Rf_gpptr(dd).getDouble(0 + 35460); d16 = Rf_GConvertXUnits(d18 - d17, 7, 13, dd); ptr11.setDouble(0 + 35492, d16); d15 = ptr11.getDouble(0 + 35492); ptr12.setDouble(0 + 35492, d15);
/* 1615 */         ptr10 = base__.Rf_gpptr(dd); ptr9 = base__.Rf_dpptr(dd);
/* 1616 */         d14 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24); d13 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16); d12 = Rf_GConvertYUnits(d14 - d13, 7, 13, dd); ptr9.setDouble(0 + 35492 + 8, d12); d11 = ptr9.getDouble(0 + 35492 + 8); ptr10.setDouble(0 + 35492 + 8, d11);
/*      */         break;
/*      */       case 13:
/* 1619 */         nfcWidth = Rf_GConvertXUnits(base__.Rf_gpptr(dd).getDouble(0 + 35492), 13, 7, dd);
/* 1620 */         nfcHeight = Rf_GConvertYUnits(base__.Rf_gpptr(dd).getDouble(0 + 35492 + 8), 13, 7, dd);
/* 1621 */         ptr8 = base__.Rf_gpptr(dd); ptr7 = base__.Rf_dpptr(dd); d10 = nfcWidth / 2.0D; d9 = 0.5D - d10; ptr7.setDouble(0 + 35460, d9); d8 = ptr7.getDouble(0 + 35460); ptr8.setDouble(0 + 35460, d8);
/* 1622 */         ptr6 = base__.Rf_gpptr(dd); ptr5 = base__.Rf_dpptr(dd); d7 = base__.Rf_gpptr(dd).getDouble(0 + 35460) + nfcWidth; ptr5.setDouble(0 + 35460 + 8, d7); d6 = ptr5.getDouble(0 + 35460 + 8); ptr6.setDouble(0 + 35460 + 8, d6);
/* 1623 */         ptr4 = base__.Rf_gpptr(dd); ptr3 = base__.Rf_dpptr(dd); d5 = nfcHeight / 2.0D; d4 = 0.5D - d5; ptr3.setDouble(0 + 35460 + 16, d4); d3 = ptr3.getDouble(0 + 35460 + 16); ptr4.setDouble(0 + 35460 + 16, d3);
/* 1624 */         ptr2 = base__.Rf_gpptr(dd); ptr1 = base__.Rf_dpptr(dd); d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16) + nfcHeight; ptr1.setDouble(0 + 35460 + 24, d2); d1 = ptr1.getDouble(0 + 35460 + 24); ptr2.setDouble(0 + 35460 + 24, d1);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMapWin2Fig(Ptr dd) {
/* 1634 */     if (base__.Rf_gpptr(dd).getInt(440) == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1642 */       Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd);
/* 1643 */       double d28 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d27 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d26 = d28 - d27;
/* 1644 */       double d25 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8), d24 = base__.Rf_gpptr(dd).getDouble(0 + 35700), d23 = d25 - d24; double d22 = d26 / d23; ptr7.setDouble(0 + 35916 + 8, d22); double d21 = ptr7.getDouble(0 + 35916 + 8); ptr8.setDouble(0 + 35916 + 8, d21);
/* 1645 */       Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd);
/* 1646 */       double d20 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d19 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8), d18 = base__.Rf_gpptr(dd).getDouble(0 + 35700), d17 = d19 * d18, d16 = d20 - d17; ptr5.setDouble(0 + 35916, d16); double d15 = ptr5.getDouble(0 + 35916); ptr6.setDouble(0 + 35916, d15); }
/*      */     else { Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); double d28 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8), d27 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d26 = d28 - d27; double d25 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 8), d24 = base__.Rf_gpptr(dd).getDouble(0 + 35732), d23 = d25 - d24; double d22 = d26 / d23; ptr7.setDouble(0 + 35916 + 8, d22); double d21 = ptr7.getDouble(0 + 35916 + 8); ptr8.setDouble(0 + 35916 + 8, d21); Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); double d20 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d19 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 8), d18 = base__.Rf_gpptr(dd).getDouble(0 + 35732), d17 = d19 * d18, d16 = d20 - d17; ptr5.setDouble(0 + 35916, d16); double d15 = ptr5.getDouble(0 + 35916); ptr6.setDouble(0 + 35916, d15); }
/* 1648 */      if (base__.Rf_gpptr(dd).getInt(480) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1656 */       Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd);
/* 1657 */       double d28 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d27 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d26 = d28 - d27;
/* 1658 */       double d25 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24), d24 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16), d23 = d25 - d24; double d22 = d26 / d23; ptr7.setDouble(0 + 35916 + 24, d22); double d21 = ptr7.getDouble(0 + 35916 + 24); ptr8.setDouble(0 + 35916 + 24, d21);
/* 1659 */       Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd);
/* 1660 */       double d20 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d19 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24), d18 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16), d17 = d19 * d18, d16 = d20 - d17; ptr5.setDouble(0 + 35916 + 16, d16); double d15 = ptr5.getDouble(0 + 35916 + 16); ptr6.setDouble(0 + 35916 + 16, d15); return;
/*      */     }  Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); double d14 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24), d13 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d12 = d14 - d13; double d11 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 24), d10 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 16), d9 = d11 - d10;
/*      */     double d8 = d12 / d9;
/*      */     ptr3.setDouble(0 + 35916 + 24, d8);
/*      */     double d7 = ptr3.getDouble(0 + 35916 + 24);
/*      */     ptr4.setDouble(0 + 35916 + 24, d7);
/*      */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd);
/*      */     double d6 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d5 = base__.Rf_gpptr(dd).getDouble(0 + 35916 + 24), d4 = base__.Rf_gpptr(dd).getDouble(0 + 35732 + 16), d3 = d5 * d4, d2 = d6 - d3;
/*      */     ptr1.setDouble(0 + 35916 + 16, d2);
/*      */     double d1 = ptr1.getDouble(0 + 35916 + 16);
/* 1670 */     ptr2.setDouble(0 + 35916 + 16, d1); } public static void mapping(Ptr dd, int which) { switch (which) {
/*      */       case 0:
/* 1672 */         mapNDC2Dev(dd);
/*      */       case 1:
/* 1674 */         updateOuterMargins(dd);
/* 1675 */         mapInner2Dev(dd);
/*      */       case 2:
/* 1677 */         if (base__.Rf_gpptr(dd).getInt(0 + 35512) != 0)
/* 1678 */           mapFigureRegion(dd); 
/* 1679 */         updateFigureRegion(dd);
/* 1680 */         mapFig2Dev(dd);
/*      */       case 3:
/* 1682 */         updateFigureMargins(dd);
/* 1683 */         if (base__.Rf_gpptr(dd).getInt(0 + 35516) != 0)
/* 1684 */           mapPlotRegion(dd); 
/* 1685 */         updatePlotRegion(dd);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GReset(Ptr dd) {
/* 1694 */     Ptr ptr = base__.Rf_gpptr(dd); double d5 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d4 = dd.getPointer().getDouble(104), d3 = d5 * d4;
/* 1695 */     double d2 = dd.getPointer().getDouble(88), d1 = d3 * d2;
/*      */     
/*      */     ptr.setDouble(364, d1);
/* 1698 */     mapping(dd, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int validFigureRegion(Ptr dd) {
/* 1706 */     return (base__.Rf_gpptr(dd).getDouble(0 + 35408) <= 
/*      */       
/* 1708 */       -1.1920928955078125E-7D || base__.Rf_gpptr(dd).getDouble(0 + 35408 + 8) >= 1.0000001192092896D) ? 0 : ((base__.Rf_gpptr(dd).getDouble(0 + 35408 + 16) <= -1.1920928955078125E-7D) ? 0 : ((
/* 1709 */       base__.Rf_gpptr(dd).getDouble(0 + 35408 + 24) >= 1.0000001192092896D) ? 0 : 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int validOuterMargins(Ptr dd) {
/* 1716 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35408), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 8); if (d4 >= d3) return 0; 
/* 1717 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35408 + 24);
/*      */     return (d2 >= d1) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int validPlotRegion(Ptr dd) {
/* 1724 */     return (base__.Rf_gpptr(dd).getDouble(0 + 35460) <= 
/*      */       
/* 1726 */       -1.1920928955078125E-7D || base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8) >= 1.0000001192092896D) ? 0 : ((base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16) <= -1.1920928955078125E-7D) ? 0 : ((
/* 1727 */       base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24) >= 1.0000001192092896D) ? 0 : 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int validFigureMargins(Ptr dd) {
/* 1734 */     double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35460), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8); if (d4 >= d3) return 0; 
/* 1735 */     double d2 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16), d1 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24);
/*      */     return (d2 >= d1) ? 0 : 1;
/*      */   }
/*      */   
/*      */   public static void invalidError(Ptr message, Ptr dd) {
/* 1740 */     Ptr ptr2 = base__.Rf_dpptr(dd); int j = ptr2.getInt(568) + -1; ptr2.setInt(568, j);
/* 1741 */     if (base__.Rf_dpptr(dd).getInt(568) <= 0) {
/* 1742 */       Ptr ptr = base__.Rf_dpptr(dd); int k = base__.Rf_dpptr(dd).getInt(572); ptr.setInt(568, k);
/* 1743 */     }  Ptr ptr1 = base__.Rf_gpptr(dd); int i = base__.Rf_dpptr(dd).getInt(568); ptr1.setInt(568, i);
/* 1744 */     Error.Rf_error((BytePtr)message, new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int GRecording(SEXP call, Ptr dd) {
/* 1749 */     return baseEngine__.GErecording(call, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr Rf_GNewPlot(int recording) {
/* 1759 */     MixedPtr mixedPtr1 = MixedPtr.malloc(276), mixedPtr2 = MixedPtr.malloc(276); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/* 1760 */     Rf_GRestore(dd.pointerPlus(dd$offset));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1778 */     if (base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(0 + 35764) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1803 */       if (base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt() == 0) {
/*      */         
/* 1805 */         gcontextFromGP((Ptr)mixedPtr1, dd.pointerPlus(dd$offset));
/* 1806 */         if (recording != 0) {
/* 1807 */           if (dd.getInt(dd$offset + 124) != 0) {
/* 1808 */             baseDevices__.Rf_NewFrameConfirm(dd.getPointer(dd$offset));
/*      */ 
/*      */ 
/*      */             
/* 1812 */             if (baseDevices__.Rf_NoDevices() != 0) {
/* 1813 */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("attempt to plot on null device\000".getBytes(), 0)), new Object[0]);
/*      */             }
/* 1815 */             dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */           } 
/* 1817 */           baseEngine__.GEinitDisplayList(dd.pointerPlus(dd$offset));
/*      */         } 
/* 1819 */         baseEngine__.GENewPage((Ptr)mixedPtr1, dd.pointerPlus(dd$offset));
/* 1820 */         Ptr ptr6 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr5 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr5.setInt(568, 1); int i1 = ptr5.getInt(568); ptr6.setInt(568, i1);
/* 1821 */         Rf_GReset(dd.pointerPlus(dd$offset));
/* 1822 */         Rf_GForceClip(dd.pointerPlus(dd$offset));
/*      */       } 
/*      */     } else {
/*      */       gcontextFromGP((Ptr)mixedPtr2, dd.pointerPlus(dd$offset)); Ptr ptr6 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)); int i4 = ptr6.getInt(568) + 1; ptr6.setInt(568, i4); Ptr ptr5 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); int i3 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)).getInt(568); ptr5.setInt(568, i3); int i2 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(568), i1 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(572); if (i2 > i1) {
/*      */         if (recording != 0) {
/*      */           if (dd.getInt(dd$offset + 124) != 0) {
/*      */             baseDevices__.Rf_NewFrameConfirm(dd.getPointer(dd$offset)); if (baseDevices__.Rf_NoDevices() != 0)
/*      */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("attempt to plot on null device\000".getBytes(), 0)), new Object[0]);  dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*      */           }  baseEngine__.GEinitDisplayList(dd.pointerPlus(dd$offset));
/*      */         } 
/*      */         baseEngine__.GENewPage((Ptr)mixedPtr2, dd.pointerPlus(dd$offset));
/*      */         Ptr ptr8 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr7 = base__.Rf_gpptr(dd.pointerPlus(dd$offset));
/*      */         ptr7.setInt(568, 1);
/*      */         int i5 = ptr7.getInt(568);
/*      */         ptr8.setInt(568, i5);
/*      */       } 
/*      */       Rf_GReset(dd.pointerPlus(dd$offset));
/*      */       Rf_GForceClip(dd.pointerPlus(dd$offset));
/*      */     } 
/* 1841 */     Ptr ptr4 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr3 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr3.setInt(4, 0); int n = ptr3.getInt(4); ptr4.setInt(4, n);
/* 1842 */     if (validOuterMargins(dd.pointerPlus(dd$offset)) != 0)
/*      */     
/* 1844 */     { if (validFigureRegion(dd.pointerPlus(dd$offset)) != 0)
/*      */       
/* 1846 */       { if (validFigureMargins(dd.pointerPlus(dd$offset)) != 0)
/*      */         
/* 1848 */         { if (validPlotRegion(dd.pointerPlus(dd$offset)) != 0)
/*      */           
/*      */           { 
/* 1851 */             Ptr ptr9 = base__.Rf_dpptr(dd.pointerPlus(dd$offset)), ptr8 = base__.Rf_gpptr(dd.pointerPlus(dd$offset)); ptr8.setInt(4, 1); int i5 = ptr8.getInt(4); ptr9.setInt(4, i5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1859 */             base__.Rf_setBaseDevice(1, dd.pointerPlus(dd$offset));
/* 1860 */             baseEngine__.GEdirtyDevice(dd.pointerPlus(dd$offset));
/*      */ 
/*      */             
/* 1863 */             Ptr ptr7 = dd; int i4 = dd$offset; return ptr7.pointerPlus(i4); }  if (recording != 0) invalidError((Ptr)GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("plot region too large\000".getBytes(), 0)), dd.pointerPlus(dd$offset));  xpdsaved = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2); BytePtr bytePtr3 = GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("plot region too large\000".getBytes(), 0)); Rf_GText(0.5D, 0.5D, 7, (Ptr)bytePtr3, -1, 0.5D, 0.5D, 0.0D, dd.pointerPlus(dd$offset)); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, xpdsaved); Ptr ptr6 = dd; int i3 = dd$offset; return ptr6.pointerPlus(i3); }  if (recording != 0) invalidError((Ptr)GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("figure margins too large\000".getBytes(), 0)), dd.pointerPlus(dd$offset));  i = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2); BytePtr bytePtr2 = GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("figure margins too large\000".getBytes(), 0)); Rf_GText(0.5D, 0.5D, 7, (Ptr)bytePtr2, -1, 0.5D, 0.5D, 0.0D, dd.pointerPlus(dd$offset)); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, i); Ptr ptr5 = dd; int i2 = dd$offset; return ptr5.pointerPlus(i2); }  if (recording != 0) invalidError((Ptr)GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("figure region too large\000".getBytes(), 0)), dd.pointerPlus(dd$offset));  j = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2); BytePtr bytePtr1 = GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("figure region too large\000".getBytes(), 0)); Rf_GText(0.5D, 0.5D, 7, (Ptr)bytePtr1, -1, 0.5D, 0.5D, 0.0D, dd.pointerPlus(dd$offset)); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, j); Ptr ptr = dd; int i1 = dd$offset; return ptr.pointerPlus(i1); }  if (recording != 0) invalidError((Ptr)GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("outer margins too large (figure region too small)\000".getBytes(), 0)), dd.pointerPlus(dd$offset));  k = base__.Rf_gpptr(dd.pointerPlus(dd$offset)).getInt(444); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, 2); BytePtr bytePtr = GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("outer margins too large (figure region too small)\000".getBytes(), 0)); Rf_GText(0.5D, 0.5D, 7, (Ptr)bytePtr, -1, 0.5D, 0.5D, 0.0D, dd.pointerPlus(dd$offset)); base__.Rf_gpptr(dd.pointerPlus(dd$offset)).setInt(444, k); Ptr ptr2 = dd; int m = dd$offset; return ptr2.pointerPlus(m);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GAxisPars(Ptr min, Ptr max, Ptr n, int log, int axis) {
/* 1871 */     double d7 = min.getDouble(), d6 = max.getDouble(); swap = (d7 <= d6) ? 0 : 1;
/*      */ 
/*      */     
/* 1874 */     if (swap != 0) {
/* 1875 */       t_ = min.getDouble(); double d = max.getDouble(); min.setDouble(d); max.setDouble(t_);
/*      */     } 
/*      */     
/* 1878 */     min_o = min.getDouble(); max_o = max.getDouble();
/*      */     
/* 1880 */     if (log == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1888 */       baseEngine__.GEPretty(min, max, n); } else { if (max.getDouble() > 308.0D)
/*      */         max.setDouble(308.0D);  if (min.getDouble() < -307.0D)
/* 1890 */         min.setDouble(-307.0D);  double d11 = min.getDouble(), d10 = Mathlib.pow(10.0D, d11); min.setDouble(d10); double d9 = max.getDouble(), d8 = Mathlib.pow(10.0D, d9); max.setDouble(d8); GLPretty(min, max, n); }  tmp2 = 2.220446049250313E-14D;
/* 1891 */     double d5 = max.getDouble(), d4 = min.getDouble(), d3 = Math.abs(d5 - d4), d2 = Math.abs(min.getDouble()); t_ = Rmath.Rf_fmax2(Math.abs(max.getDouble()), d2); double d1 = t_ * tmp2; if (d3 < d1) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1896 */       double d16 = max.getDouble(), d15 = min.getDouble(), d14 = Math.abs(d16 - d15), d13 = t_ * 2.220446049250313E-16D;
/*      */       double d12 = d14 / d13;
/*      */       Error.Rf_warning(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("relative range of values (%4.0f * EPS) is small (axis %d)\000".getBytes(), 0)), new Object[] { Double.valueOf(d12), Integer.valueOf(axis) });
/* 1899 */       min.setDouble(min_o);
/* 1900 */       max.setDouble(max_o);
/* 1901 */       double d11 = max.getDouble(), d10 = min.getDouble(); eps = Math.abs(d11 - d10) * 0.005D;
/* 1902 */       double d9 = min.getDouble() + eps; min.setDouble(d9);
/* 1903 */       double d8 = max.getDouble() - eps; max.setDouble(d8);
/* 1904 */       if (log != 0) {
/* 1905 */         double d20 = min.getDouble(), d19 = Mathlib.pow(10.0D, d20); min.setDouble(d19);
/* 1906 */         double d18 = max.getDouble(), d17 = Mathlib.pow(10.0D, d18); max.setDouble(d17);
/*      */       } 
/* 1908 */       n.setInt(1);
/*      */     } 
/* 1910 */     if (swap != 0) {
/* 1911 */       t_ = min.getDouble(); double d = max.getDouble(); min.setDouble(d); max.setDouble(t_);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GScale(double min, double max, int axis, Ptr dd) {
/* 1923 */     arrayOfDouble1 = new double[] { min }; arrayOfDouble2 = new double[] { max }; n = new int[1]; if (axis != 1 && axis != 3) { iftmp$211 = 0; } else { iftmp$211 = 1; }  is_xaxis = iftmp$211;
/*      */     
/* 1925 */     min_o = 0.0D; max_o = 0.0D; tmp2 = 0.0D;
/*      */     
/* 1927 */     if (is_xaxis == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1933 */       n$213 = base__.Rf_gpptr(dd).getInt(300); n[0] = n$213;
/* 1934 */       style = base__.Rf_gpptr(dd).getByte(476);
/* 1935 */       log = base__.Rf_gpptr(dd).getInt(480);
/*      */     } else {
/*      */       n$212 = base__.Rf_gpptr(dd).getInt(296); n[0] = n$212; style = base__.Rf_gpptr(dd).getByte(436); log = base__.Rf_gpptr(dd).getInt(440);
/* 1938 */     }  if (log != 0) {
/*      */       
/* 1940 */       min_o = arrayOfDouble1[0]; max_o = arrayOfDouble2[0];
/* 1941 */       min$215 = Mathlib.log10(arrayOfDouble1[0]); arrayOfDouble1[0] = min$215;
/* 1942 */       max$217 = Mathlib.log10(arrayOfDouble2[0]); arrayOfDouble2[0] = max$217;
/*      */     } 
/* 1944 */     if (Arith.R_finite(arrayOfDouble1[0]) == 0 || Arith.R_finite(arrayOfDouble2[0]) == 0) {
/* 1945 */       max$220 = arrayOfDouble2[0]; min$221 = arrayOfDouble1[0]; Error.Rf_warning(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("nonfinite axis limits [GScale(%g,%g,%d, .); log=%d]\000".getBytes(), 0)), new Object[] { Double.valueOf(min$221), Double.valueOf(max$220), Integer.valueOf(axis), Integer.valueOf(log) });
/*      */       
/* 1947 */       if (Arith.R_finite(arrayOfDouble1[0]) == 0) arrayOfDouble1[0] = -8.089619106880421E307D; 
/* 1948 */       if (Arith.R_finite(arrayOfDouble2[0]) == 0) arrayOfDouble2[0] = 8.089619106880421E307D;
/*      */     
/*      */     } 
/*      */ 
/*      */     
/* 1953 */     double d5 = Math.abs(arrayOfDouble1[0]); temp = Rmath.Rf_fmax2(Math.abs(arrayOfDouble2[0]), d5);
/* 1954 */     if (temp != 0.0D)
/*      */     
/*      */     { 
/*      */       
/* 1958 */       max$226 = arrayOfDouble2[0]; min$227 = arrayOfDouble1[0]; double d7 = Math.abs(max$226 - min$227), d6 = temp * 16.0D * 2.220446049250313E-16D; if (d7 < d6) {
/* 1959 */         min$229 = arrayOfDouble1[0]; max$230 = arrayOfDouble2[0]; if (min$229 != max$230) { iftmp$228 = 0.01D; } else { iftmp$228 = 0.4D; }  temp = iftmp$228 * temp;
/* 1960 */         min$232 = arrayOfDouble1[0] - temp; arrayOfDouble1[0] = min$232;
/* 1961 */         max$234 = arrayOfDouble2[0] + temp; arrayOfDouble2[0] = max$234;
/*      */       }  }
/*      */     else { arrayOfDouble1[0] = -1.0D; arrayOfDouble2[0] = 1.0D; }
/* 1964 */      switch (style) {
/*      */       case 114:
/* 1966 */         max$235 = arrayOfDouble2[0]; min$236 = arrayOfDouble1[0]; temp = (max$235 - min$236) * 0.04D;
/* 1967 */         min$238 = arrayOfDouble1[0] - temp; arrayOfDouble1[0] = min$238;
/* 1968 */         max$240 = arrayOfDouble2[0] + temp; arrayOfDouble2[0] = max$240;
/*      */         break;
/*      */       
/*      */       case 105:
/*      */         break;
/*      */       
/*      */       default:
/* 1975 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("axis style \"%c\" unimplemented\000".getBytes(), 0)), new Object[] { Integer.valueOf(style) });
/*      */         break;
/*      */     } 
/* 1978 */     if (log != 0) {
/* 1979 */       min$241 = arrayOfDouble1[0]; temp = Mathlib.pow(10.0D, min$241); if (temp == 0.0D) {
/* 1980 */         temp = Rmath.Rf_fmin2(min_o, 2.2473245970922734E-308D);
/* 1981 */         min$242 = Mathlib.log10(temp); arrayOfDouble1[0] = min$242;
/*      */       } 
/* 1983 */       if (arrayOfDouble2[0] < 308.25D)
/*      */       
/*      */       { 
/* 1986 */         max$245 = arrayOfDouble2[0]; tmp2 = Mathlib.pow(10.0D, max$245); } else { tmp2 = Rmath.Rf_fmax2(max_o, 1.7797162035136925E308D); max$244 = Mathlib.log10(tmp2); arrayOfDouble2[0] = max$244; }
/*      */     
/* 1988 */     }  if (is_xaxis == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1999 */       if (log == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2005 */         Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); min$252 = arrayOfDouble1[0]; ptr9.setDouble(0 + 35700 + 16, min$252); double d7 = ptr9.getDouble(0 + 35700 + 16); ptr10.setDouble(0 + 35700 + 16, d7);
/* 2006 */         Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); max$253 = arrayOfDouble2[0]; ptr7.setDouble(0 + 35700 + 24, max$253); double d6 = ptr7.getDouble(0 + 35700 + 24); ptr8.setDouble(0 + 35700 + 24, d6);
/*      */       } else {
/*      */         Ptr ptr14 = base__.Rf_gpptr(dd), ptr13 = base__.Rf_dpptr(dd); ptr13.setDouble(0 + 35700 + 16, temp); double d9 = ptr13.getDouble(0 + 35700 + 16); ptr14.setDouble(0 + 35700 + 16, d9); Ptr ptr12 = base__.Rf_gpptr(dd), ptr11 = base__.Rf_dpptr(dd); ptr11.setDouble(0 + 35700 + 24, tmp2); double d8 = ptr11.getDouble(0 + 35700 + 24); ptr12.setDouble(0 + 35700 + 24, d8); Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); min$250 = arrayOfDouble1[0]; ptr9.setDouble(0 + 35732 + 16, min$250); double d7 = ptr9.getDouble(0 + 35732 + 16); ptr10.setDouble(0 + 35732 + 16, d7); Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); max$251 = arrayOfDouble2[0]; ptr7.setDouble(0 + 35732 + 24, max$251); double d6 = ptr7.getDouble(0 + 35732 + 24); ptr8.setDouble(0 + 35732 + 24, d6);
/*      */       } 
/*      */     } else if (log == 0) {
/*      */       Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); min$248 = arrayOfDouble1[0]; ptr9.setDouble(0 + 35700, min$248); double d7 = ptr9.getDouble(0 + 35700); ptr10.setDouble(0 + 35700, d7); Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); max$249 = arrayOfDouble2[0]; ptr7.setDouble(0 + 35700 + 8, max$249); double d6 = ptr7.getDouble(0 + 35700 + 8); ptr8.setDouble(0 + 35700 + 8, d6);
/*      */     } else {
/*      */       Ptr ptr14 = base__.Rf_gpptr(dd), ptr13 = base__.Rf_dpptr(dd); ptr13.setDouble(0 + 35700, temp); double d9 = ptr13.getDouble(0 + 35700); ptr14.setDouble(0 + 35700, d9); Ptr ptr12 = base__.Rf_gpptr(dd), ptr11 = base__.Rf_dpptr(dd); ptr11.setDouble(0 + 35700 + 8, tmp2); double d8 = ptr11.getDouble(0 + 35700 + 8); ptr12.setDouble(0 + 35700 + 8, d8); Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); min$246 = arrayOfDouble1[0]; ptr9.setDouble(0 + 35732, min$246); double d7 = ptr9.getDouble(0 + 35732); ptr10.setDouble(0 + 35732, d7); Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); max$247 = arrayOfDouble2[0]; ptr7.setDouble(0 + 35732 + 8, max$247);
/*      */       double d6 = ptr7.getDouble(0 + 35732 + 8);
/*      */       ptr8.setDouble(0 + 35732 + 8, d6);
/*      */     } 
/* 2017 */     log$254 = log; Rf_GAxisPars((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new IntPtr(n, 0), log$254, axis);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2031 */     if (is_xaxis == 0) { Ptr ptr12 = base__.Rf_gpptr(dd), ptr11 = base__.Rf_dpptr(dd); min$258 = arrayOfDouble1[0]; ptr11.setDouble(452, min$258); double d9 = ptr11.getDouble(452); ptr12.setDouble(452, d9); Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); max$259 = arrayOfDouble2[0]; ptr9.setDouble(460, max$259); double d8 = ptr9.getDouble(460); ptr10.setDouble(460, d8); Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); double d7 = n[0]; ptr7.setDouble(468, d7); double d6 = ptr7.getDouble(468); ptr8.setDouble(468, d6); return; }  Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); min$255 = arrayOfDouble1[0]; ptr5.setDouble(412, min$255); double d4 = ptr5.getDouble(412); ptr6.setDouble(412, d4); Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); max$256 = arrayOfDouble2[0]; ptr3.setDouble(420, max$256); double d3 = ptr3.getDouble(420); ptr4.setDouble(420, d3); Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); double d2 = n[0]; ptr1.setDouble(428, d2); double d1 = ptr1.getDouble(428); ptr2.setDouble(428, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GSetupAxis(int axis, Ptr dd) {
/* 2044 */     n = new int[1]; max = new double[1]; min = new double[1]; if (axis != 1 && axis != 3) { iftmp$198 = 0; } else { iftmp$198 = 1; }  is_xaxis = iftmp$198;
/*      */     
/* 2046 */     if (is_xaxis == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2052 */       n$202 = base__.Rf_gpptr(dd).getInt(300); n[0] = n$202;
/* 2053 */       min$203 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 16); min[0] = min$203;
/* 2054 */       max$204 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 24); max[0] = max$204;
/*      */     } else {
/*      */       n$199 = base__.Rf_gpptr(dd).getInt(296); n[0] = n$199; min$200 = base__.Rf_gpptr(dd).getDouble(0 + 35700); min[0] = min$200; max$201 = base__.Rf_gpptr(dd).getDouble(0 + 35700 + 8); max[0] = max$201;
/* 2057 */     }  Rf_GPretty((Ptr)new DoublePtr(min, 0), (Ptr)new DoublePtr(max, 0), (Ptr)new IntPtr(n, 0));
/*      */     
/* 2059 */     if (is_xaxis == 0) { Ptr ptr12 = base__.Rf_gpptr(dd), ptr11 = base__.Rf_dpptr(dd); min$208 = min[0]; ptr11.setDouble(452, min$208); double d8 = ptr11.getDouble(452); ptr12.setDouble(452, d8); Ptr ptr10 = base__.Rf_gpptr(dd), ptr9 = base__.Rf_dpptr(dd); max$209 = max[0]; ptr9.setDouble(460, max$209); double d7 = ptr9.getDouble(460); ptr10.setDouble(460, d7); Ptr ptr8 = base__.Rf_gpptr(dd), ptr7 = base__.Rf_dpptr(dd); double d6 = n[0]; ptr7.setDouble(468, d6); double d5 = ptr7.getDouble(468); ptr8.setDouble(468, d5); return; }  Ptr ptr6 = base__.Rf_gpptr(dd), ptr5 = base__.Rf_dpptr(dd); min$205 = min[0]; ptr5.setDouble(412, min$205); double d4 = ptr5.getDouble(412); ptr6.setDouble(412, d4); Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); max$206 = max[0]; ptr3.setDouble(420, max$206); double d3 = ptr3.getDouble(420); ptr4.setDouble(420, d3); Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); double d2 = n[0]; ptr1.setDouble(428, d2); double d1 = ptr1.getDouble(428); ptr2.setDouble(428, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GInit(Ptr dp) {
/* 2079 */     dp.setInt(0);
/* 2080 */     dp.setAlignedInt(1, 0);
/*      */     
/* 2082 */     dp.setAlignedInt(4, 1);
/* 2083 */     dp.setAlignedInt(18, 0);
/* 2084 */     dp.setByte(24, (byte)111);
/*      */     
/* 2086 */     dp.setDouble(364, 0.001D);
/* 2087 */     dp.setDouble(28, 1.0D);
/* 2088 */     dp.setDouble(36, 1.0D);
/* 2089 */     dp.setDouble(484, 1.0D);
/* 2090 */     dp.setDouble(492, 1.2D);
/* 2091 */     dp.setDouble(500, 1.0D);
/* 2092 */     dp.setDouble(508, 1.0D);
/* 2093 */     dp.setDouble(516, 1.0D);
/*      */     
/* 2095 */     dp.setAlignedInt(11, -16777216);
/* 2096 */     dp.setAlignedInt(135, -16777216);
/* 2097 */     dp.setAlignedInt(136, -16777216);
/* 2098 */     dp.setAlignedInt(137, -16777216);
/* 2099 */     dp.setAlignedInt(138, -16777216);
/* 2100 */     dp.setAlignedDouble(36, 1.0D);
/*      */     
/* 2102 */     dp.setDouble(35948, 1.0D);
/* 2103 */     dp.pointerPlus(80).memcpy((Ptr)new BytePtr("\000".getBytes(), 0), 1);
/* 2104 */     dp.setAlignedInt(71, 1);
/* 2105 */     dp.setAlignedInt(131, 2);
/* 2106 */     dp.setAlignedInt(132, 1);
/* 2107 */     dp.setAlignedInt(133, 1);
/* 2108 */     dp.setAlignedInt(134, 1);
/*      */     
/* 2110 */     dp.setAlignedInt(93, 1);
/* 2111 */     dp.setAlignedInt(78, 0);
/* 2112 */     dp.setAlignedInt(81, 1);
/* 2113 */     dp.setAlignedInt(82, 1);
/* 2114 */     dp.setDouble(332, 10.0D);
/* 2115 */     dp.setAlignedInt(96, 1);
/*      */ 
/*      */     
/* 2118 */     dp.setAlignedDouble(1, 0.5D);
/* 2119 */     dp.setAlignedDouble(6, 0.0D);
/* 2120 */     dp.setDouble(388, 0.0D);
/*      */ 
/*      */     
/* 2123 */     dp.setDouble(340, 3.0D);
/* 2124 */     dp.setDouble(348, 1.0D);
/* 2125 */     dp.setDouble(356, 0.0D);
/*      */ 
/*      */     
/* 2128 */     dp.setAlignedInt(74, 5);
/* 2129 */     dp.setAlignedInt(75, 5);
/* 2130 */     dp.setAlignedInt(76, 7);
/* 2131 */     dp.setAlignedInt(77, 0);
/* 2132 */     R_NaReal$197 = Arith.R_NaReal; dp.setDouble(396, R_NaReal$197);
/* 2133 */     dp.setDouble(404, -0.5D);
/* 2134 */     dp.setDouble(412, 0.0D);
/* 2135 */     dp.setDouble(420, 1.0D);
/* 2136 */     dp.setDouble(428, 5.0D);
/* 2137 */     dp.setByte(436, (byte)114);
/* 2138 */     dp.setByte(437, (byte)115);
/* 2139 */     dp.setAlignedInt(110, 0);
/* 2140 */     dp.setAlignedInt(111, 0);
/* 2141 */     dp.setAlignedInt(112, -99);
/* 2142 */     dp.setDouble(452, 0.0D);
/* 2143 */     dp.setDouble(460, 1.0D);
/* 2144 */     dp.setDouble(468, 5.0D);
/* 2145 */     dp.setByte(476, (byte)114);
/* 2146 */     dp.setByte(477, (byte)115);
/* 2147 */     dp.setAlignedInt(120, 0);
/*      */ 
/*      */     
/* 2150 */     dp.setDouble(35588, 1.0D);
/* 2151 */     dp.setDouble(35596, 0.0D);
/* 2152 */     dp.setDouble(35604, 0.0D);
/* 2153 */     dp.setDouble(35612, 0.0D);
/* 2154 */     dp.setDouble(35620, 0.0D);
/* 2155 */     dp.setAlignedInt(8923, 14);
/* 2156 */     dp.setAlignedDouble(4426, 0.0D);
/* 2157 */     dp.setAlignedDouble(4427, 1.0D);
/* 2158 */     dp.setAlignedDouble(4428, 0.0D);
/* 2159 */     dp.setAlignedDouble(4429, 1.0D);
/* 2160 */     dp.setAlignedInt(8864, 6);
/* 2161 */     dp.setAlignedInt(8878, 1);
/*      */     
/* 2163 */     dp.setAlignedInt(8877, 7);
/* 2164 */     dp.setAlignedInt(8879, 1);
/*      */ 
/*      */ 
/*      */     
/* 2168 */     dp.setAlignedDouble(4440, 5.1D);
/* 2169 */     dp.setAlignedDouble(4441, 4.1D);
/* 2170 */     dp.setAlignedDouble(4442, 4.1D);
/* 2171 */     dp.setAlignedDouble(4443, 2.1D);
/* 2172 */     dp.setAlignedInt(8896, 14);
/*      */ 
/*      */     
/* 2175 */     dp.setAlignedInt(139, 0);
/* 2176 */     dp.setAlignedInt(8851, 0);
/*      */     
/* 2178 */     dp.setAlignedInt(140, 1);
/* 2179 */     dp.setAlignedInt(141, 1);
/* 2180 */     dp.setAlignedInt(142, 1);
/* 2181 */     dp.setAlignedInt(143, 1);
/* 2182 */     dp.setAlignedDouble(72, 1.0D);
/* 2183 */     dp.setAlignedDouble(272, 1.0D);
/* 2184 */     dp.setAlignedInt(944, 0);
/* 2185 */     dp.setAlignedInt(1144, 0);
/* 2186 */     dp.setAlignedChar(2688, (char)'\001');
/* 2187 */     dp.setAlignedInt(6348, 0);
/* 2188 */     dp.setByte(25396, (byte)0);
/*      */ 
/*      */     
/* 2191 */     dp.setAlignedInt(8941, 0);
/* 2192 */     dp.setAlignedInt(8942, -99);
/* 2193 */     dp.setByte(35696, (byte)109);
/* 2194 */     dp.setDouble(316, 1.0D);
/*      */ 
/*      */     
/* 2197 */     dp.setDouble(35700, 0.0D);
/* 2198 */     dp.setDouble(35708, 1.0D);
/* 2199 */     dp.setDouble(35716, 0.0D);
/* 2200 */     dp.setDouble(35724, 1.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_copyGPar(Ptr source, Ptr dest) {
/* 2206 */     dest.memcpy(source, 35956);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GRestore(Ptr dd) {
/* 2213 */     if (baseDevices__.Rf_NoDevices() != 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("no graphics device is active\000".getBytes(), 0)), new Object[0]); 
/* 2214 */     Ptr ptr = base__.Rf_gpptr(dd); Rf_copyGPar(base__.Rf_dpptr(dd), ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GSavePars(Ptr dd) {
/* 2275 */     Context.set__graphics$adjsave(base__.Rf_gpptr(dd).getDouble(8));
/* 2276 */     Context.set__graphics$annsave(base__.Rf_gpptr(dd).getInt(16));
/* 2277 */     Context.set__graphics$btysave(base__.Rf_gpptr(dd).getByte(24));
/* 2278 */     Context.set__graphics$cexsave(base__.Rf_gpptr(dd).getDouble(28));
/* 2279 */     Context.set__graphics$lheightsave(base__.Rf_gpptr(dd).getDouble(36));
/* 2280 */     Context.set__graphics$cexbasesave(base__.Rf_gpptr(dd).getDouble(484));
/* 2281 */     Context.set__graphics$cexlabsave(base__.Rf_gpptr(dd).getDouble(500));
/* 2282 */     Context.set__graphics$cexmainsave(base__.Rf_gpptr(dd).getDouble(492));
/* 2283 */     Context.set__graphics$cexsubsave(base__.Rf_gpptr(dd).getDouble(508));
/* 2284 */     Context.set__graphics$cexaxissave(base__.Rf_gpptr(dd).getDouble(516));
/* 2285 */     Context.set__graphics$colsave(base__.Rf_gpptr(dd).getInt(44));
/* 2286 */     Context.set__graphics$fgsave(base__.Rf_gpptr(dd).getInt(76));
/* 2287 */     Context.set__graphics$bgsave(base__.Rf_gpptr(dd).getInt(20));
/* 2288 */     Context.set__graphics$collabsave(base__.Rf_gpptr(dd).getInt(544));
/* 2289 */     Context.set__graphics$colmainsave(base__.Rf_gpptr(dd).getInt(540));
/* 2290 */     Context.set__graphics$colsubsave(base__.Rf_gpptr(dd).getInt(548));
/* 2291 */     Context.set__graphics$colaxissave(base__.Rf_gpptr(dd).getInt(552));
/* 2292 */     Context.set__graphics$crtsave(base__.Rf_gpptr(dd).getDouble(48));
/* 2293 */     Context.set__graphics$errsave(base__.Rf_gpptr(dd).getInt(72));
/* 2294 */     Ptr ptr = base__.Rf_gpptr(dd); Stdlib.strncpy((Ptr)new BytePtr(Context.get__graphics$familysave(), 0), ptr.pointerPlus(80), 201);
/* 2295 */     Context.set__graphics$fontsave(base__.Rf_gpptr(dd).getInt(284));
/* 2296 */     Context.set__graphics$fontmainsave(base__.Rf_gpptr(dd).getInt(524));
/* 2297 */     Context.set__graphics$fontlabsave(base__.Rf_gpptr(dd).getInt(528));
/* 2298 */     Context.set__graphics$fontsubsave(base__.Rf_gpptr(dd).getInt(532));
/* 2299 */     Context.set__graphics$fontaxissave(base__.Rf_gpptr(dd).getInt(536));
/* 2300 */     int k = base__.Rf_gpptr(dd).getInt(296); Context.get__graphics$labsave()[0] = k;
/* 2301 */     int j = base__.Rf_gpptr(dd).getInt(300); Context.get__graphics$labsave()[1] = j;
/* 2302 */     int i = base__.Rf_gpptr(dd).getInt(304); Context.get__graphics$labsave()[2] = i;
/* 2303 */     Context.set__graphics$lassave(base__.Rf_gpptr(dd).getInt(308));
/* 2304 */     Context.set__graphics$ltysave(base__.Rf_gpptr(dd).getInt(312));
/* 2305 */     Context.set__graphics$lwdsave(base__.Rf_gpptr(dd).getDouble(316));
/* 2306 */     Context.set__graphics$lendsave(base__.Rf_gpptr(dd).getInt(324));
/* 2307 */     Context.set__graphics$ljoinsave(base__.Rf_gpptr(dd).getInt(328));
/* 2308 */     Context.set__graphics$lmitresave(base__.Rf_gpptr(dd).getDouble(332));
/* 2309 */     double d9 = base__.Rf_gpptr(dd).getDouble(340); Context.get__graphics$mgpsave()[0] = d9;
/* 2310 */     double d8 = base__.Rf_gpptr(dd).getDouble(348); Context.get__graphics$mgpsave()[1] = d8;
/* 2311 */     double d7 = base__.Rf_gpptr(dd).getDouble(356); Context.get__graphics$mgpsave()[2] = d7;
/* 2312 */     Context.set__graphics$mkhsave(base__.Rf_gpptr(dd).getDouble(364));
/* 2313 */     Context.set__graphics$pchsave(base__.Rf_gpptr(dd).getInt(372));
/* 2314 */     Context.set__graphics$srtsave(base__.Rf_gpptr(dd).getDouble(388));
/* 2315 */     Context.set__graphics$tcksave(base__.Rf_gpptr(dd).getDouble(396));
/* 2316 */     Context.set__graphics$tclsave(base__.Rf_gpptr(dd).getDouble(404));
/* 2317 */     double d6 = base__.Rf_gpptr(dd).getDouble(412); Context.get__graphics$xaxpsave()[0] = d6;
/* 2318 */     double d5 = base__.Rf_gpptr(dd).getDouble(420); Context.get__graphics$xaxpsave()[1] = d5;
/* 2319 */     double d4 = base__.Rf_gpptr(dd).getDouble(428); Context.get__graphics$xaxpsave()[2] = d4;
/* 2320 */     Context.set__graphics$xaxssave(base__.Rf_gpptr(dd).getByte(436));
/* 2321 */     Context.set__graphics$xaxtsave(base__.Rf_gpptr(dd).getByte(437));
/* 2322 */     Context.set__graphics$xpdsave(base__.Rf_gpptr(dd).getInt(444));
/* 2323 */     double d3 = base__.Rf_gpptr(dd).getDouble(452); Context.get__graphics$yaxpsave()[0] = d3;
/* 2324 */     double d2 = base__.Rf_gpptr(dd).getDouble(460); Context.get__graphics$yaxpsave()[1] = d2;
/* 2325 */     double d1 = base__.Rf_gpptr(dd).getDouble(468); Context.get__graphics$yaxpsave()[2] = d1;
/* 2326 */     Context.set__graphics$yaxssave(base__.Rf_gpptr(dd).getByte(476));
/* 2327 */     Context.set__graphics$yaxtsave(base__.Rf_gpptr(dd).getByte(477));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GRestorePars(Ptr dd) {
/* 2334 */     Ptr ptr52 = base__.Rf_gpptr(dd); adjsave$109 = Context.get__graphics$adjsave(); ptr52.setDouble(8, adjsave$109);
/* 2335 */     Ptr ptr51 = base__.Rf_gpptr(dd); annsave$111 = Context.get__graphics$annsave(); ptr51.setInt(16, annsave$111);
/* 2336 */     Ptr ptr50 = base__.Rf_gpptr(dd); btysave$112 = Context.get__graphics$btysave(); ptr50.setByte(24, btysave$112);
/* 2337 */     Ptr ptr49 = base__.Rf_gpptr(dd); cexsave$113 = Context.get__graphics$cexsave(); ptr49.setDouble(28, cexsave$113);
/* 2338 */     Ptr ptr48 = base__.Rf_gpptr(dd); lheightsave$114 = Context.get__graphics$lheightsave(); ptr48.setDouble(36, lheightsave$114);
/* 2339 */     Ptr ptr47 = base__.Rf_gpptr(dd); cexbasesave$115 = Context.get__graphics$cexbasesave(); ptr47.setDouble(484, cexbasesave$115);
/* 2340 */     Ptr ptr46 = base__.Rf_gpptr(dd); cexlabsave$116 = Context.get__graphics$cexlabsave(); ptr46.setDouble(500, cexlabsave$116);
/* 2341 */     Ptr ptr45 = base__.Rf_gpptr(dd); cexmainsave$117 = Context.get__graphics$cexmainsave(); ptr45.setDouble(492, cexmainsave$117);
/* 2342 */     Ptr ptr44 = base__.Rf_gpptr(dd); cexsubsave$118 = Context.get__graphics$cexsubsave(); ptr44.setDouble(508, cexsubsave$118);
/* 2343 */     Ptr ptr43 = base__.Rf_gpptr(dd); cexaxissave$119 = Context.get__graphics$cexaxissave(); ptr43.setDouble(516, cexaxissave$119);
/* 2344 */     Ptr ptr42 = base__.Rf_gpptr(dd); colsave$121 = Context.get__graphics$colsave(); ptr42.setInt(44, colsave$121);
/* 2345 */     Ptr ptr41 = base__.Rf_gpptr(dd); fgsave$123 = Context.get__graphics$fgsave(); ptr41.setInt(76, fgsave$123);
/* 2346 */     Ptr ptr40 = base__.Rf_gpptr(dd); bgsave$125 = Context.get__graphics$bgsave(); ptr40.setInt(20, bgsave$125);
/* 2347 */     Ptr ptr39 = base__.Rf_gpptr(dd); collabsave$127 = Context.get__graphics$collabsave(); ptr39.setInt(544, collabsave$127);
/* 2348 */     Ptr ptr38 = base__.Rf_gpptr(dd); colmainsave$129 = Context.get__graphics$colmainsave(); ptr38.setInt(540, colmainsave$129);
/* 2349 */     Ptr ptr37 = base__.Rf_gpptr(dd); colsubsave$131 = Context.get__graphics$colsubsave(); ptr37.setInt(548, colsubsave$131);
/* 2350 */     Ptr ptr36 = base__.Rf_gpptr(dd); colaxissave$133 = Context.get__graphics$colaxissave(); ptr36.setInt(552, colaxissave$133);
/* 2351 */     Ptr ptr35 = base__.Rf_gpptr(dd); crtsave$134 = Context.get__graphics$crtsave(); ptr35.setDouble(48, crtsave$134);
/* 2352 */     Ptr ptr34 = base__.Rf_gpptr(dd); errsave$135 = Context.get__graphics$errsave(); ptr34.setInt(72, errsave$135);
/* 2353 */     Stdlib.strncpy(base__.Rf_gpptr(dd).pointerPlus(80), (Ptr)new BytePtr(Context.get__graphics$familysave(), 0), 201);
/* 2354 */     Ptr ptr33 = base__.Rf_gpptr(dd); fontsave$136 = Context.get__graphics$fontsave(); ptr33.setInt(284, fontsave$136);
/* 2355 */     Ptr ptr32 = base__.Rf_gpptr(dd); fontmainsave$137 = Context.get__graphics$fontmainsave(); ptr32.setInt(524, fontmainsave$137);
/* 2356 */     Ptr ptr31 = base__.Rf_gpptr(dd); fontlabsave$138 = Context.get__graphics$fontlabsave(); ptr31.setInt(528, fontlabsave$138);
/* 2357 */     Ptr ptr30 = base__.Rf_gpptr(dd); fontsubsave$139 = Context.get__graphics$fontsubsave(); ptr30.setInt(532, fontsubsave$139);
/* 2358 */     Ptr ptr29 = base__.Rf_gpptr(dd); fontaxissave$140 = Context.get__graphics$fontaxissave(); ptr29.setInt(536, fontaxissave$140);
/* 2359 */     Ptr ptr28 = base__.Rf_gpptr(dd); int k = Context.get__graphics$labsave()[0]; ptr28.setInt(296, k);
/* 2360 */     Ptr ptr27 = base__.Rf_gpptr(dd); int j = Context.get__graphics$labsave()[1]; ptr27.setInt(300, j);
/* 2361 */     Ptr ptr26 = base__.Rf_gpptr(dd); int i = Context.get__graphics$labsave()[2]; ptr26.setInt(304, i);
/* 2362 */     Ptr ptr25 = base__.Rf_gpptr(dd); lassave$141 = Context.get__graphics$lassave(); ptr25.setInt(308, lassave$141);
/* 2363 */     Ptr ptr24 = base__.Rf_gpptr(dd); ltysave$142 = Context.get__graphics$ltysave(); ptr24.setInt(312, ltysave$142);
/* 2364 */     Ptr ptr23 = base__.Rf_gpptr(dd); lwdsave$143 = Context.get__graphics$lwdsave(); ptr23.setDouble(316, lwdsave$143);
/* 2365 */     Ptr ptr22 = base__.Rf_gpptr(dd); lendsave$144 = Context.get__graphics$lendsave(); ptr22.setInt(324, lendsave$144);
/* 2366 */     Ptr ptr21 = base__.Rf_gpptr(dd); ljoinsave$145 = Context.get__graphics$ljoinsave(); ptr21.setInt(328, ljoinsave$145);
/* 2367 */     Ptr ptr20 = base__.Rf_gpptr(dd); lmitresave$146 = Context.get__graphics$lmitresave(); ptr20.setDouble(332, lmitresave$146);
/* 2368 */     Ptr ptr19 = base__.Rf_gpptr(dd); double d9 = Context.get__graphics$mgpsave()[0]; ptr19.setDouble(340, d9);
/* 2369 */     Ptr ptr18 = base__.Rf_gpptr(dd); double d8 = Context.get__graphics$mgpsave()[1]; ptr18.setDouble(348, d8);
/* 2370 */     Ptr ptr17 = base__.Rf_gpptr(dd); double d7 = Context.get__graphics$mgpsave()[2]; ptr17.setDouble(356, d7);
/* 2371 */     Ptr ptr16 = base__.Rf_gpptr(dd); mkhsave$147 = Context.get__graphics$mkhsave(); ptr16.setDouble(364, mkhsave$147);
/* 2372 */     Ptr ptr15 = base__.Rf_gpptr(dd); pchsave$148 = Context.get__graphics$pchsave(); ptr15.setInt(372, pchsave$148);
/* 2373 */     Ptr ptr14 = base__.Rf_gpptr(dd); srtsave$149 = Context.get__graphics$srtsave(); ptr14.setDouble(388, srtsave$149);
/* 2374 */     Ptr ptr13 = base__.Rf_gpptr(dd); tcksave$150 = Context.get__graphics$tcksave(); ptr13.setDouble(396, tcksave$150);
/* 2375 */     Ptr ptr12 = base__.Rf_gpptr(dd); tclsave$151 = Context.get__graphics$tclsave(); ptr12.setDouble(404, tclsave$151);
/* 2376 */     Ptr ptr11 = base__.Rf_gpptr(dd); double d6 = Context.get__graphics$xaxpsave()[0]; ptr11.setDouble(412, d6);
/* 2377 */     Ptr ptr10 = base__.Rf_gpptr(dd); double d5 = Context.get__graphics$xaxpsave()[1]; ptr10.setDouble(420, d5);
/* 2378 */     Ptr ptr9 = base__.Rf_gpptr(dd); double d4 = Context.get__graphics$xaxpsave()[2]; ptr9.setDouble(428, d4);
/* 2379 */     Ptr ptr8 = base__.Rf_gpptr(dd); xaxssave$152 = Context.get__graphics$xaxssave(); ptr8.setByte(436, xaxssave$152);
/* 2380 */     Ptr ptr7 = base__.Rf_gpptr(dd); xaxtsave$153 = Context.get__graphics$xaxtsave(); ptr7.setByte(437, xaxtsave$153);
/* 2381 */     Ptr ptr6 = base__.Rf_gpptr(dd); xpdsave$154 = Context.get__graphics$xpdsave(); ptr6.setInt(444, xpdsave$154);
/* 2382 */     Ptr ptr5 = base__.Rf_gpptr(dd); double d3 = Context.get__graphics$yaxpsave()[0]; ptr5.setDouble(452, d3);
/* 2383 */     Ptr ptr4 = base__.Rf_gpptr(dd); double d2 = Context.get__graphics$yaxpsave()[1]; ptr4.setDouble(460, d2);
/* 2384 */     Ptr ptr3 = base__.Rf_gpptr(dd); double d1 = Context.get__graphics$yaxpsave()[2]; ptr3.setDouble(468, d1);
/* 2385 */     Ptr ptr2 = base__.Rf_gpptr(dd); yaxssave$155 = Context.get__graphics$yaxssave(); ptr2.setByte(476, yaxssave$155);
/* 2386 */     Ptr ptr1 = base__.Rf_gpptr(dd); yaxtsave$156 = Context.get__graphics$yaxtsave(); ptr1.setByte(477, yaxtsave$156);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GSetState(int newstate, Ptr dd) {
/* 2399 */     Ptr ptr2 = base__.Rf_dpptr(dd), ptr1 = base__.Rf_gpptr(dd); ptr1.setInt(0, newstate); int i = ptr1.getInt(); ptr2.setInt(0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GCheckState(Ptr dd) {
/* 2407 */     if (base__.Rf_gpptr(dd).getInt() == 0)
/* 2408 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("plot.new has not been called yet\000".getBytes(), 0)), new Object[0]); 
/* 2409 */     if (base__.Rf_gpptr(dd).getInt(4) == 0) {
/* 2410 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid graphics state\000".getBytes(), 0)), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClipRect(Ptr x1, Ptr y1, Ptr x2, Ptr y2, int coords, Ptr dd) {
/* 2446 */     x1.setDouble(0.0D);
/* 2447 */     y1.setDouble(0.0D);
/* 2448 */     x2.setDouble(1.0D);
/* 2449 */     y2.setDouble(1.0D);
/* 2450 */     switch (base__.Rf_gpptr(dd).getInt(444)) {
/*      */       case 0:
/* 2452 */         coords$103 = coords; Rf_GConvert(x1, y1, 16, coords$103, dd);
/* 2453 */         coords$104 = coords; Rf_GConvert(x2, y2, 16, coords$104, dd);
/*      */         break;
/*      */       case 1:
/* 2456 */         coords$105 = coords; Rf_GConvert(x1, y1, 7, coords$105, dd);
/* 2457 */         coords$106 = coords; Rf_GConvert(x2, y2, 7, coords$106, dd);
/*      */         break;
/*      */       case 2:
/* 2460 */         coords$107 = coords; Rf_GConvert(x1, y1, 1, coords$107, dd);
/* 2461 */         coords$108 = coords; Rf_GConvert(x2, y2, 1, coords$108, dd);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GClip(Ptr dd) {
/* 2469 */     y2 = new double[1]; x2 = new double[1]; y1 = new double[1]; x1 = new double[1]; y2[0] = 0.0D; x2[0] = 0.0D; y1[0] = 0.0D; x1[0] = 0.0D; int j = base__.Rf_gpptr(dd).getInt(444), i = base__.Rf_gpptr(dd).getInt(448); if (j != i) {
/*      */       
/* 2471 */       setClipRect((Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y1, 0), (Ptr)new DoublePtr(x2, 0), (Ptr)new DoublePtr(y2, 0), 0, dd);
/* 2472 */       y2$99 = y2[0]; x2$100 = x2[0]; y1$101 = y1[0]; baseEngine__.GESetClip(x1[0], y1$101, x2$100, y2$99, dd);
/* 2473 */       Ptr ptr = base__.Rf_gpptr(dd); int k = base__.Rf_gpptr(dd).getInt(444); ptr.setInt(448, k);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GForceClip(Ptr dd) {
/* 2482 */     y2 = new double[1]; x2 = new double[1]; y1 = new double[1]; x1 = new double[1]; y2[0] = 0.0D; x2[0] = 0.0D; y1[0] = 0.0D; x1[0] = 0.0D; if (base__.Rf_gpptr(dd).getInt() != 0) {
/* 2483 */       setClipRect((Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y1, 0), (Ptr)new DoublePtr(x2, 0), (Ptr)new DoublePtr(y2, 0), 0, dd);
/* 2484 */       y2$95 = y2[0]; x2$96 = x2[0]; y1$97 = y1[0]; baseEngine__.GESetClip(x1[0], y1$97, x2$96, y2$95, dd);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gcontextFromGP(Ptr gc, Ptr dd) {
/* 2496 */     int i1 = base__.Rf_gpptr(dd).getInt(44); gc.setInt(i1);
/* 2497 */     int n = base__.Rf_gpptr(dd).getInt(20); gc.setAlignedInt(1, n);
/* 2498 */     double d10 = base__.Rf_gpptr(dd).getDouble(288); gc.setAlignedDouble(1, d10);
/*      */ 
/*      */ 
/*      */     
/* 2502 */     double d9 = base__.Rf_gpptr(dd).getDouble(316), d8 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d7 = d9 * d8; gc.setAlignedDouble(2, d7);
/* 2503 */     int m = base__.Rf_gpptr(dd).getInt(312); gc.setAlignedInt(6, m);
/* 2504 */     int k = base__.Rf_gpptr(dd).getInt(324); gc.setAlignedInt(7, k);
/* 2505 */     int j = base__.Rf_gpptr(dd).getInt(328); gc.setAlignedInt(8, j);
/* 2506 */     double d6 = base__.Rf_gpptr(dd).getDouble(332); gc.setDouble(36, d6);
/* 2507 */     double d5 = base__.Rf_gpptr(dd).getDouble(28); gc.setDouble(44, d5);
/*      */ 
/*      */ 
/*      */     
/* 2511 */     double d4 = base__.Rf_gpptr(dd).getDouble(376), d3 = base__.Rf_gpptr(dd).getDouble(0 + 35948), d2 = d4 * d3; gc.setDouble(52, d2);
/* 2512 */     double d1 = base__.Rf_gpptr(dd).getDouble(36); gc.setDouble(60, d1);
/* 2513 */     int i = base__.Rf_gpptr(dd).getInt(284); gc.setAlignedInt(17, i);
/* 2514 */     Ptr ptr = base__.Rf_gpptr(dd); Stdlib.strncpy(gc.pointerPlus(72), ptr.pointerPlus(80), 201);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GLine(double x1, double y1, double x2, double y2, int coords, Ptr dd) {
/* 2522 */     arrayOfDouble1 = new double[] { x1 }; arrayOfDouble2 = new double[] { y1 }; arrayOfDouble3 = new double[] { x2 }; arrayOfDouble4 = new double[] { y2 }; MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 2523 */     if (base__.Rf_gpptr(dd).getInt(312) != -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2528 */       coords$85 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$85, 0, dd);
/* 2529 */       coords$86 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), coords$86, 0, dd);
/*      */ 
/*      */ 
/*      */       
/* 2533 */       Rf_GClip(dd);
/* 2534 */       if (Arith.R_finite(arrayOfDouble1[0]) != 0 && Arith.R_finite(arrayOfDouble2[0]) != 0 && Arith.R_finite(arrayOfDouble3[0]) != 0 && Arith.R_finite(arrayOfDouble4[0]) != 0) {
/* 2535 */         y2$91 = arrayOfDouble4[0]; x2$92 = arrayOfDouble3[0]; y1$93 = arrayOfDouble2[0]; baseEngine__.GELine(arrayOfDouble1[0], y1$93, x2$92, y2$91, (Ptr)mixedPtr, dd);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void locator_close(Ptr dd) {
/* 2553 */     if (Context.get__graphics$old_close() != null) Context.get__graphics$old_close().invoke(dd); 
/* 2554 */     old_close$84 = Context.get__graphics$old_close(); dd.setAlignedPointer(53, FunctionPtr1.malloc(old_close$84));
/* 2555 */     Context.set__graphics$old_close(BytePtr.of(0).toMethodHandle());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2560 */     Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("graphics device closed during call to locator or identify\000".getBytes(), 0)), new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_GLocator(Ptr x, Ptr y, int coords, Ptr dd) {
/*      */     // Byte code:
/*      */     //   0: aload_3
/*      */     //   1: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   6: sipush #212
/*      */     //   9: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   14: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   19: invokestatic set__graphics$old_close : (Ljava/lang/invoke/MethodHandle;)V
/*      */     //   22: aload_3
/*      */     //   23: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   28: sipush #212
/*      */     //   31: ldc_w
/*      */     //   34: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   37: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   42: aload_3
/*      */     //   43: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   48: sipush #220
/*      */     //   51: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   56: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   61: ifnull -> 129
/*      */     //   64: goto -> 67
/*      */     //   67: aload_3
/*      */     //   68: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   73: sipush #220
/*      */     //   76: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   81: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   86: astore #13
/*      */     //   88: aload_3
/*      */     //   89: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   94: astore #11
/*      */     //   96: aload #13
/*      */     //   98: aload_0
/*      */     //   99: aload_1
/*      */     //   100: aload #11
/*      */     //   102: invokevirtual invoke : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   105: ifne -> 111
/*      */     //   108: goto -> 129
/*      */     //   111: iload_2
/*      */     //   112: istore #9
/*      */     //   114: aload_0
/*      */     //   115: aload_1
/*      */     //   116: iconst_0
/*      */     //   117: iload #9
/*      */     //   119: aload_3
/*      */     //   120: invokestatic Rf_GConvert : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   123: iconst_1
/*      */     //   124: istore #4
/*      */     //   126: goto -> 132
/*      */     //   129: iconst_0
/*      */     //   130: istore #4
/*      */     //   132: aload_3
/*      */     //   133: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   138: astore #7
/*      */     //   140: invokestatic get__graphics$old_close : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   143: astore #6
/*      */     //   145: aload #7
/*      */     //   147: sipush #212
/*      */     //   150: aload #6
/*      */     //   152: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   155: invokeinterface setPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   160: iconst_0
/*      */     //   161: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   164: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   169: invokestatic set__graphics$old_close : (Ljava/lang/invoke/MethodHandle;)V
/*      */     //   172: iload #4
/*      */     //   174: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2572	-> 0
/*      */     //   #2573	-> 22
/*      */     //   #2575	-> 42
/*      */     //   #2575	-> 67
/*      */     //   #2576	-> 111
/*      */     //   #2577	-> 123
/*      */     //   #2578	-> 129
/*      */     //   #2580	-> 132
/*      */     //   #2581	-> 160
/*      */     //   #2582	-> 172
/*      */     //   #2582	-> 174
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	175	0	x	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	175	1	y	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	175	2	coords	I
/*      */     //   0	175	3	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	175	4	ret	I
/*      */     //   0	175	6	old_close$81	Ljava/lang/invoke/MethodHandle;
/*      */     //   0	175	9	coords$80	I
/*      */     //   0	175	21	old_close$79	Ljava/lang/invoke/MethodHandle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMetricInfo(int c, Ptr ascent, Ptr descent, Ptr width, int units, Ptr dd) {
/* 2591 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 2592 */     MethodHandle methodHandle = dd.getPointer().getPointer(228).toMethodHandle(); Ptr ptr = dd.getPointer(); int i = c & 0xFF; methodHandle.invoke(i, (Ptr)mixedPtr, ascent, descent, width, ptr);
/* 2593 */     if (units != 0) {
/* 2594 */       double d3 = Rf_GConvertYUnits(ascent.getDouble(), 0, units, dd); ascent.setDouble(d3);
/* 2595 */       double d2 = Rf_GConvertYUnits(descent.getDouble(), 0, units, dd); descent.setDouble(d2);
/* 2596 */       double d1 = Rf_GConvertXUnits(width.getDouble(), 0, units, dd); width.setDouble(d1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMode(int mode, Ptr dd) {
/* 2609 */     if (baseDevices__.Rf_NoDevices() != 0)
/* 2610 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("No graphics device is active\000".getBytes(), 0)), new Object[0]); 
/* 2611 */     if (base__.Rf_gpptr(dd).getInt(0 + 35768) != mode) baseEngine__.GEMode(mode, dd); 
/* 2612 */     Ptr ptr4 = base__.Rf_gpptr(dd), ptr3 = base__.Rf_dpptr(dd); ptr3.setInt(0 + 35764, 0); int j = ptr3.getInt(0 + 35764); ptr4.setInt(0 + 35764, j);
/* 2613 */     Ptr ptr2 = base__.Rf_gpptr(dd), ptr1 = base__.Rf_dpptr(dd); ptr1.setInt(0 + 35768, mode); int i = ptr1.getInt(0 + 35768); ptr2.setInt(0 + 35768, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int inside(int b, double px, double py, Ptr clip) {
/* 2664 */     switch (b) { case 0:
/* 2665 */         if (clip.getDouble() <= px) break;  return 0;
/* 2666 */       case 1: if (clip.getAlignedDouble(1) >= px) break;  return 0;
/* 2667 */       case 2: if (clip.getAlignedDouble(2) <= py) break;  return 0;
/* 2668 */       case 3: if (clip.getAlignedDouble(3) >= py) break;  return 0; }
/*      */     
/* 2670 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int cross(int b, double x1, double y1, double x2, double y2, Ptr clip) {
/* 2677 */     int j = inside(b, x1, y1, clip), i = inside(b, x2, y2, clip); return (j != i) ? 
/*      */       
/* 2679 */       1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void intersect(int b, double x1, double y1, double x2, double y2, Ptr ix, Ptr iy, Ptr clip) {
/*      */     double d1, d2, d3, d4, d5, d6, d7, d8;
/* 2686 */     m = 0.0D;
/*      */     
/* 2688 */     if (x1 != x2) { double d10 = y1 - y2, d9 = x1 - x2; m = d10 / d9; }
/* 2689 */      switch (b) {
/*      */       case 0:
/* 2691 */         d8 = clip.getDouble(); ix.setDouble(d8);
/* 2692 */         d7 = (clip.getDouble() - x2) * m + y2; iy.setDouble(d7);
/*      */         break;
/*      */       case 1:
/* 2695 */         d6 = clip.getAlignedDouble(1); ix.setDouble(d6);
/* 2696 */         d5 = (clip.getAlignedDouble(1) - x2) * m + y2; iy.setDouble(d5);
/*      */         break;
/*      */       case 2:
/* 2699 */         d4 = clip.getAlignedDouble(2); iy.setDouble(d4);
/* 2700 */         if (x1 == x2) {
/* 2701 */           ix.setDouble(x2); break;
/*      */         }  d3 = (clip.getAlignedDouble(2) - y2) / m + x2; ix.setDouble(d3); break;
/*      */       case 3:
/* 2704 */         d2 = clip.getAlignedDouble(3); iy.setDouble(d2);
/* 2705 */         if (x1 == x2) {
/* 2706 */           ix.setDouble(x2);
/*      */           break;
/*      */         } 
/*      */         d1 = (clip.getAlignedDouble(3) - y2) / m + x2;
/*      */         ix.setDouble(d1);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void clipPoint(int b, double x, double y, Ptr xout, Ptr yout, Ptr cnt, int store, Ptr clip, Ptr cs) {
/* 2716 */     iy = new double[1]; ix = new double[1]; ix[0] = 0.0D; iy[0] = 0.0D;
/*      */     
/* 2718 */     int i1 = b * 36; Ptr ptr3 = cs; int n = i1; if (ptr3.getInt(n) != 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2730 */       int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; double d2 = ptr5.getDouble(i4 + 28); int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; double d1 = ptr4.getDouble(i2 + 20); if (cross(b, x, y, d1, d2, clip) != 0) {
/* 2731 */         int i9 = b * 36; Ptr ptr7 = cs; int i8 = i9; double d4 = ptr7.getDouble(i8 + 28); int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; double d3 = ptr6.getDouble(i6 + 20); intersect(b, x, y, d3, d4, (Ptr)new DoublePtr(ix, 0), (Ptr)new DoublePtr(iy, 0), clip);
/* 2732 */         if (b > 2)
/*      */         
/*      */         { 
/*      */           
/* 2736 */           if (store != 0) {
/* 2737 */             int i14 = cnt.getInt() * 8; Ptr ptr9 = xout; int i13 = i14; ix$77 = ix[0]; ptr9.setDouble(i13, ix$77);
/* 2738 */             int i12 = cnt.getInt() * 8; Ptr ptr8 = yout; int i11 = i12; iy$78 = iy[0]; ptr8.setDouble(i11, iy$78);
/*      */           } 
/* 2740 */           int i10 = cnt.getInt() + 1; cnt.setInt(i10); }
/*      */         else { iy$75 = iy[0]; ix$76 = ix[0]; clipPoint(b + 1, ix$76, iy$75, xout, yout, cnt, store, clip, cs); }
/*      */       
/*      */       }  }
/*      */     else { int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; ptr6.setInt(i6, 1); int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; ptr5.setDouble(i4 + 4, x); int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; ptr4.setDouble(i2 + 12, y); }
/* 2745 */      int m = b * 36; Ptr ptr2 = cs; int k = m; ptr2.setDouble(k + 20, x);
/* 2746 */     int j = b * 36; Ptr ptr1 = cs; int i = j; ptr1.setDouble(i + 28, y);
/*      */ 
/*      */ 
/*      */     
/* 2750 */     if (inside(b, x, y, clip) != 0) {
/* 2751 */       if (b > 2) {
/*      */ 
/*      */         
/* 2754 */         if (store != 0) {
/* 2755 */           int i6 = cnt.getInt() * 8; Ptr ptr5 = xout; int i5 = i6; ptr5.setDouble(i5, x);
/* 2756 */           int i4 = cnt.getInt() * 8; Ptr ptr4 = yout; int i3 = i4; ptr4.setDouble(i3, y);
/*      */         } 
/* 2758 */         int i2 = cnt.getInt() + 1; cnt.setInt(i2);
/*      */         return;
/*      */       } 
/*      */       clipPoint(b + 1, x, y, xout, yout, cnt, store, clip, cs);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void closeClip(Ptr xout, Ptr yout, Ptr cnt, int store, Ptr clip, Ptr cs) {
/* 2767 */     iy = new double[1]; ix = new double[1]; iy[0] = 0.0D; ix[0] = 0.0D; ix[0] = 0.0D; iy[0] = 0.0D;
/*      */ 
/*      */     
/* 2770 */     for (b = 0; b <= 3; b++) {
/* 2771 */       int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; double d4 = ptr4.getDouble(i2 + 12); int i1 = b * 36; Ptr ptr3 = cs; int n = i1; double d3 = ptr3.getDouble(n + 4); int m = b * 36; Ptr ptr2 = cs; int k = m; double d2 = ptr2.getDouble(k + 28); int j = b * 36; Ptr ptr1 = cs; int i = j; double d1 = ptr1.getDouble(i + 20); if (cross(b, d1, d2, d3, d4, clip) != 0) {
/*      */         
/* 2773 */         int i11 = b * 36; Ptr ptr8 = cs; int i10 = i11; double d8 = ptr8.getDouble(i10 + 12); int i9 = b * 36; Ptr ptr7 = cs; int i8 = i9; double d7 = ptr7.getDouble(i8 + 4); int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; double d6 = ptr6.getDouble(i6 + 28); int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; double d5 = ptr5.getDouble(i4 + 20); intersect(b, d5, d6, d7, d8, (Ptr)new DoublePtr(ix, 0), (Ptr)new DoublePtr(iy, 0), clip);
/* 2774 */         if (b > 2) {
/*      */ 
/*      */           
/* 2777 */           if (store != 0) {
/* 2778 */             int i16 = cnt.getInt() * 8; Ptr ptr10 = xout; int i15 = i16; ix$73 = ix[0]; ptr10.setDouble(i15, ix$73);
/* 2779 */             int i14 = cnt.getInt() * 8; Ptr ptr9 = yout; int i13 = i14; iy$74 = iy[0]; ptr9.setDouble(i13, iy$74);
/*      */           } 
/* 2781 */           int i12 = cnt.getInt() + 1; cnt.setInt(i12);
/*      */         } else {
/*      */           iy$71 = iy[0];
/*      */           ix$72 = ix[0];
/*      */           clipPoint(b + 1, ix$72, iy$71, xout, yout, cnt, store, clip, cs);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } public static int Rf_GClipPolygon(Ptr x, Ptr y, int n, int coords, int store, Ptr xout, Ptr yout, Ptr dd) {
/* 2790 */     MixedPtr mixedPtr1 = MixedPtr.malloc(32), mixedPtr2 = MixedPtr.malloc(144); cnt = new int[1]; cnt[0] = 0; cnt[0] = 0;
/*      */ 
/*      */     
/* 2793 */     for (i = 0; i <= 3; i++) {
/* 2794 */       mixedPtr2.setInt(i * 36, 0);
/*      */     }
/* 2796 */     setClipRect((Ptr)mixedPtr1, mixedPtr1.pointerPlus(16), mixedPtr1.pointerPlus(8), mixedPtr1.pointerPlus(24), coords, dd);
/*      */     
/* 2798 */     double d5 = mixedPtr1.getAlignedDouble(1), d4 = mixedPtr1.getDouble(); if (d5 < d4) {
/* 2799 */       d1 = mixedPtr1.getAlignedDouble(1);
/* 2800 */       double d = mixedPtr1.getDouble(); mixedPtr1.setAlignedDouble(1, d);
/* 2801 */       mixedPtr1.setDouble(d1);
/*      */     } 
/* 2803 */     double d3 = mixedPtr1.getAlignedDouble(3), d2 = mixedPtr1.getAlignedDouble(2); if (d3 < d2) {
/* 2804 */       swap = mixedPtr1.getAlignedDouble(3);
/* 2805 */       double d = mixedPtr1.getAlignedDouble(2); mixedPtr1.setAlignedDouble(3, d);
/* 2806 */       mixedPtr1.setAlignedDouble(2, swap);
/*      */     } 
/* 2808 */     for (i = 0; i < n; i++) {
/* 2809 */       int i1 = i * 8; Ptr ptr2 = y; int m = i1; double d7 = ptr2.getDouble(m); int k = i * 8; Ptr ptr1 = x; int j = k; double d6 = ptr1.getDouble(j); clipPoint(0, d6, d7, xout, yout, (Ptr)new IntPtr(cnt, 0), store, (Ptr)mixedPtr1, (Ptr)mixedPtr2);
/* 2810 */     }  closeClip(xout, yout, (Ptr)new IntPtr(cnt, 0), store, (Ptr)mixedPtr1, (Ptr)mixedPtr2);
/* 2811 */     return cnt[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GPolygon(int n, Ptr x, Ptr y, int coords, int bg, int fg, Ptr dd) {
/* 2836 */     MixedPtr mixedPtr = MixedPtr.malloc(276); vmaxsave = BytePtr.of(0); vmaxsave$offset = 0; yy = BytePtr.of(0); yy$offset = 0; xx = BytePtr.of(0); xx$offset = 0; vmaxsave = VoidPtr.toPtr(Memory.vmaxget()); vmaxsave$offset = 0;
/* 2837 */     gcontextFromGP((Ptr)mixedPtr, dd);
/*      */     
/* 2839 */     if (base__.Rf_gpptr(dd).getInt(312) == -1) {
/* 2840 */       fg = 16777215;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2846 */     DoublePtr doublePtr2 = DoublePtr.malloc(n * 8); xx$offset = 0;
/* 2847 */     DoublePtr doublePtr1 = DoublePtr.malloc(n * 8); yy$offset = 0;
/* 2848 */     if (doublePtr2.pointerPlus(xx$offset).isNull() || doublePtr1.pointerPlus(yy$offset).isNull())
/* 2849 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GPolygon)\000".getBytes(), 0), new Object[0]); 
/* 2850 */     for (i = 0; i < n; i++) {
/* 2851 */       int i9 = i * 8; DoublePtr doublePtr6 = doublePtr2; int i8 = xx$offset + i9, i7 = i * 8; Ptr ptr2 = x; int i6 = i7; double d2 = ptr2.getDouble(i6); doublePtr6.setDouble(i8, d2);
/* 2852 */       int i5 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i4 = yy$offset + i5, i3 = i * 8; Ptr ptr1 = y; int i2 = i3; double d1 = ptr1.getDouble(i2); doublePtr5.setDouble(i4, d1);
/* 2853 */       coords$66 = coords; int i1 = i * 8; DoublePtr doublePtr4 = doublePtr1; int m = yy$offset + i1, k = i * 8; DoublePtr doublePtr3 = doublePtr2; int j = xx$offset + k; Rf_GConvert(doublePtr3.pointerPlus(j), doublePtr4.pointerPlus(m), coords$66, 0, dd);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2858 */     Rf_GClip(dd);
/* 2859 */     mixedPtr.setInt(fg);
/* 2860 */     mixedPtr.setAlignedInt(1, bg);
/* 2861 */     baseEngine__.GEPolygon(n, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GPolyline(int n, Ptr x, Ptr y, int coords, Ptr dd) {
/* 2875 */     MixedPtr mixedPtr = MixedPtr.malloc(276); vmaxsave = BytePtr.of(0); vmaxsave$offset = 0; yy = BytePtr.of(0); yy$offset = 0; xx = BytePtr.of(0); xx$offset = 0; vmaxsave = VoidPtr.toPtr(Memory.vmaxget()); vmaxsave$offset = 0;
/* 2876 */     gcontextFromGP((Ptr)mixedPtr, dd);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2882 */     DoublePtr doublePtr2 = DoublePtr.malloc(n * 8); xx$offset = 0;
/* 2883 */     DoublePtr doublePtr1 = DoublePtr.malloc(n * 8); yy$offset = 0;
/* 2884 */     if (doublePtr2.pointerPlus(xx$offset).isNull() || doublePtr1.pointerPlus(yy$offset).isNull())
/* 2885 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GPolyline)\000".getBytes(), 0), new Object[0]); 
/* 2886 */     for (i = 0; i < n; i++) {
/* 2887 */       int i9 = i * 8; DoublePtr doublePtr6 = doublePtr2; int i8 = xx$offset + i9, i7 = i * 8; Ptr ptr2 = x; int i6 = i7; double d2 = ptr2.getDouble(i6); doublePtr6.setDouble(i8, d2);
/* 2888 */       int i5 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i4 = yy$offset + i5, i3 = i * 8; Ptr ptr1 = y; int i2 = i3; double d1 = ptr1.getDouble(i2); doublePtr5.setDouble(i4, d1);
/* 2889 */       coords$57 = coords; int i1 = i * 8; DoublePtr doublePtr4 = doublePtr1; int m = yy$offset + i1, k = i * 8; DoublePtr doublePtr3 = doublePtr2; int j = xx$offset + k; Rf_GConvert(doublePtr3.pointerPlus(j), doublePtr4.pointerPlus(m), coords$57, 0, dd);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2894 */     Rf_GClip(dd);
/* 2895 */     baseEngine__.GEPolyline(n, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GCircle(double x, double y, int coords, double radius, int bg, int fg, Ptr dd) {
/* 2913 */     arrayOfDouble1 = new double[] { x }; arrayOfDouble2 = new double[] { y }; MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/*      */     
/* 2915 */     double d = dd.getPointer().getDouble(88); ir = radius / d;
/* 2916 */     if (ir <= 0.0D) { iftmp$47 = 1.0D; } else { iftmp$47 = ir; }  ir = iftmp$47;
/*      */     
/* 2918 */     if (base__.Rf_gpptr(dd).getInt(312) == -1) {
/* 2919 */       fg = 16777215;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2925 */     coords$48 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$48, 0, dd);
/*      */ 
/*      */ 
/*      */     
/* 2929 */     Rf_GClip(dd);
/* 2930 */     mixedPtr.setInt(fg);
/* 2931 */     mixedPtr.setAlignedInt(1, bg);
/* 2932 */     y$49 = arrayOfDouble2[0]; baseEngine__.GECircle(arrayOfDouble1[0], y$49, ir, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GRect(double x0, double y0, double x1, double y1, int coords, int bg, int fg, Ptr dd) {
/* 2941 */     arrayOfDouble1 = new double[] { x0 }; arrayOfDouble2 = new double[] { y0 }; arrayOfDouble3 = new double[] { x1 }; arrayOfDouble4 = new double[] { y1 }; MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/*      */     
/* 2943 */     if (base__.Rf_gpptr(dd).getInt(312) == -1) {
/* 2944 */       fg = 16777215;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2950 */     coords$41 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$41, 0, dd);
/* 2951 */     coords$42 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), coords$42, 0, dd);
/*      */ 
/*      */ 
/*      */     
/* 2955 */     Rf_GClip(dd);
/* 2956 */     mixedPtr.setInt(fg);
/* 2957 */     mixedPtr.setAlignedInt(1, bg);
/* 2958 */     y1$43 = arrayOfDouble4[0]; x1$44 = arrayOfDouble3[0]; y0$45 = arrayOfDouble2[0]; baseEngine__.GERect(arrayOfDouble1[0], y0$45, x1$44, y1$43, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GPath(Ptr x, Ptr y, int npoly, Ptr nper, int winding, int bg, int fg, Ptr dd) {
/* 2966 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/*      */     
/* 2968 */     if (base__.Rf_gpptr(dd).getInt(312) == -1) {
/* 2969 */       fg = 16777215;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2974 */     Rf_GClip(dd);
/* 2975 */     mixedPtr.setInt(fg);
/* 2976 */     mixedPtr.setAlignedInt(1, bg);
/* 2977 */     baseEngine__.GEPath(x, y, npoly, nper, winding, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GRaster(Ptr image, int w, int h, double x0, double y0, double x1, double y1, double angle, int interpolate, Ptr dd) {
/* 2985 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2990 */     Rf_GClip(dd);
/*      */     
/* 2992 */     baseEngine__.GERaster(image, w, h, x0, y0, x1, y1, angle, interpolate, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GStrWidth(Ptr str, int enc, int units, Ptr dd) {
/* 3000 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 3001 */     if (mixedPtr.getAlignedInt(17) == 5) { iftmp$40 = 5; } else { iftmp$40 = enc; }  w = baseEngine__.GEStrWidth(str, iftmp$40, (Ptr)mixedPtr, dd);
/* 3002 */     if (units != 0)
/* 3003 */       w = Rf_GConvertXUnits(w, 0, units, dd); 
/* 3004 */     return w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GStrHeight(Ptr str, int enc, int units, Ptr dd) {
/* 3013 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 3014 */     if (mixedPtr.getAlignedInt(17) == 5) { iftmp$39 = 5; } else { iftmp$39 = enc; }  h = baseEngine__.GEStrHeight(str, iftmp$39, (Ptr)mixedPtr, dd);
/* 3015 */     if (units != 0)
/* 3016 */       h = Rf_GConvertYUnits(h, 0, units, dd); 
/* 3017 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GText(double x, double y, int coords, Ptr str, int enc, double xc, double yc, double rot, Ptr dd) {
/* 3026 */     arrayOfDouble1 = new double[] { x }; arrayOfDouble2 = new double[] { y }; MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3031 */     coords$35 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$35, 0, dd);
/*      */ 
/*      */ 
/*      */     
/* 3035 */     Rf_GClip(dd);
/* 3036 */     if (mixedPtr.getAlignedInt(17) == 5) { iftmp$36 = 5; } else { iftmp$36 = enc; }  y$37 = arrayOfDouble2[0]; baseEngine__.GEText(arrayOfDouble1[0], y$37, str, iftmp$36, xc, yc, rot, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GArrow(double xfrom, double yfrom, double xto, double yto, int coords, double length, double angle, int code, Ptr dd) {
/* 3052 */     y = new double[3]; x = new double[3]; ytoInch = new double[1]; xtoInch = new double[1]; yfromInch = new double[1]; xfromInch = new double[1]; xfromInch[0] = xfrom;
/* 3053 */     yfromInch[0] = yfrom;
/* 3054 */     xtoInch[0] = xto;
/* 3055 */     ytoInch[0] = yto;
/*      */ 
/*      */     
/* 3058 */     eps = 0.001D;
/*      */     
/* 3060 */     Rf_GLine(xfrom, yfrom, xto, yto, coords, dd);
/*      */     
/* 3062 */     coords$9 = coords; Rf_GConvert((Ptr)new DoublePtr(xfromInch, 0), (Ptr)new DoublePtr(yfromInch, 0), coords$9, 13, dd);
/* 3063 */     coords$10 = coords; Rf_GConvert((Ptr)new DoublePtr(xtoInch, 0), (Ptr)new DoublePtr(ytoInch, 0), coords$10, 13, dd);
/* 3064 */     if ((code & 0x3) != 0 && 
/* 3065 */       length != 0.0D) {
/*      */       
/* 3067 */       yfromInch$11 = yfromInch[0]; ytoInch$12 = ytoInch[0]; double d = yfromInch$11 - ytoInch$12; xfromInch$13 = xfromInch[0]; xtoInch$14 = xtoInch[0]; if (Mathlib.hypot(xfromInch$13 - xtoInch$14, d) >= eps) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3072 */         angle *= 0.017453292519943295D;
/* 3073 */         if ((code & 0x1) != 0) {
/* 3074 */           xtoInch$15 = xtoInch[0]; xfromInch$16 = xfromInch[0]; xc = xtoInch$15 - xfromInch$16;
/* 3075 */           ytoInch$17 = ytoInch[0]; yfromInch$18 = yfromInch[0]; yc = ytoInch$17 - yfromInch$18;
/* 3076 */           rot = Mathlib.atan2(yc, xc);
/* 3077 */           double d8 = Mathlib.cos(rot + angle) * length; xfromInch$19 = xfromInch[0]; double d7 = d8 + xfromInch$19; x[0] = d7;
/* 3078 */           double d6 = Mathlib.sin(rot + angle) * length; yfromInch$20 = yfromInch[0]; double d5 = d6 + yfromInch$20; y[0] = d5;
/* 3079 */           xfromInch$21 = xfromInch[0]; x[1] = xfromInch$21;
/* 3080 */           yfromInch$22 = yfromInch[0]; y[1] = yfromInch$22;
/* 3081 */           double d4 = Mathlib.cos(rot - angle) * length; xfromInch$23 = xfromInch[0]; double d3 = d4 + xfromInch$23; x[2] = d3;
/* 3082 */           double d2 = Mathlib.sin(rot - angle) * length; yfromInch$24 = yfromInch[0]; double d1 = d2 + yfromInch$24; y[2] = d1;
/* 3083 */           Rf_GPolyline(3, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 13, dd);
/*      */         } 
/* 3085 */         if ((code & 0x2) != 0) {
/* 3086 */           xfromInch$25 = xfromInch[0]; xtoInch$26 = xtoInch[0]; xc = xfromInch$25 - xtoInch$26;
/* 3087 */           yfromInch$27 = yfromInch[0]; ytoInch$28 = ytoInch[0]; yc = yfromInch$27 - ytoInch$28;
/* 3088 */           rot = Mathlib.atan2(yc, xc);
/* 3089 */           double d8 = Mathlib.cos(rot + angle) * length; xtoInch$29 = xtoInch[0]; double d7 = d8 + xtoInch$29; x[0] = d7;
/* 3090 */           double d6 = Mathlib.sin(rot + angle) * length; ytoInch$30 = ytoInch[0]; double d5 = d6 + ytoInch$30; y[0] = d5;
/* 3091 */           xtoInch$31 = xtoInch[0]; x[1] = xtoInch$31;
/* 3092 */           ytoInch$32 = ytoInch[0]; y[1] = ytoInch$32;
/* 3093 */           double d4 = Mathlib.cos(rot - angle) * length; xtoInch$33 = xtoInch[0]; double d3 = d4 + xtoInch$33; x[2] = d3;
/* 3094 */           double d2 = Mathlib.sin(rot - angle) * length; ytoInch$34 = ytoInch[0]; double d1 = d2 + ytoInch$34; y[2] = d1;
/* 3095 */           Rf_GPolyline(3, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 13, dd);
/*      */         } 
/*      */         return;
/*      */       } 
/*      */       Error.Rf_warning(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("zero-length arrow is of indeterminate angle and so skipped\000".getBytes(), 0)), new Object[0]);
/*      */     }  } public static void Rf_GBox(int which, Ptr dd) {
/*      */     int i, j, k;
/*      */     byte b;
/*      */     int m;
/* 3104 */     y = new double[7]; x = new double[7]; if (which != 1)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3114 */       x[0] = 0.0D; y[0] = 0.0D;
/* 3115 */       x[1] = 1.0D; y[1] = 0.0D;
/* 3116 */       x[2] = 1.0D; y[2] = 1.0D;
/* 3117 */       x[3] = 0.0D; y[3] = 1.0D; }
/*      */     else { double d14 = base__.Rf_gpptr(dd).getDouble(0 + 35460); x[0] = d14; double d13 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16); y[0] = d13; double d12 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8); x[1] = d12; double d11 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 16); y[1] = d11; double d10 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 8); x[2] = d10; double d9 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24); y[2] = d9; double d8 = base__.Rf_gpptr(dd).getDouble(0 + 35460); x[3] = d8; double d7 = base__.Rf_gpptr(dd).getDouble(0 + 35460 + 24); y[3] = d7; double d6 = x[0]; x[4] = d6; double d5 = y[0]; y[4] = d5; double d4 = x[1]; x[5] = d4; double d3 = y[1]; y[5] = d3; double d2 = x[2]; x[6] = d2; double d1 = y[2]; y[6] = d1; }
/* 3119 */      switch (which) {
/*      */       case 1:
/* 3121 */         switch (base__.Rf_gpptr(dd).getByte(24)) {
/*      */           case 79:
/*      */           case 111:
/* 3124 */             m = 
/* 3125 */               base__.Rf_gpptr(dd).getInt(44);
/*      */             Rf_GPolygon(4, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 7, 16777215, m, dd);
/*      */           case 76:
/*      */           case 108:
/* 3129 */             Rf_GPolyline(3, (Ptr)new DoublePtr(x, 3), (Ptr)new DoublePtr(y, 3), 7, dd);
/*      */           
/*      */           case 55:
/* 3132 */             Rf_GPolyline(3, (Ptr)new DoublePtr(x, 1), (Ptr)new DoublePtr(y, 1), 7, dd);
/*      */           
/*      */           case 67:
/*      */           case 91:
/*      */           case 99:
/* 3137 */             Rf_GPolyline(4, (Ptr)new DoublePtr(x, 2), (Ptr)new DoublePtr(y, 2), 7, dd);
/*      */           
/*      */           case 93:
/* 3140 */             Rf_GPolyline(4, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 7, dd);
/*      */           
/*      */           case 85:
/*      */           case 117:
/* 3144 */             Rf_GPolyline(4, (Ptr)new DoublePtr(x, 3), (Ptr)new DoublePtr(y, 3), 7, dd);
/*      */           
/*      */           case 78:
/*      */           case 110:
/*      */             return;
/*      */         } 
/* 3150 */         b = 
/* 3151 */           base__.Rf_gpptr(dd).getByte(24);
/*      */         Error.Rf_warning(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid par(\"bty\") = '%c'; no box() drawn\000".getBytes(), 0)), new Object[] { Integer.valueOf(b) });
/*      */       
/*      */       case 2:
/* 3155 */         k = 
/* 3156 */           base__.Rf_gpptr(dd).getInt(44);
/*      */         Rf_GPolygon(4, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 7, 16777215, k, dd);
/*      */       case 3:
/* 3159 */         j = 
/* 3160 */           base__.Rf_gpptr(dd).getInt(44);
/*      */         Rf_GPolygon(4, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 6, 16777215, j, dd);
/*      */       case 4:
/* 3163 */         i = 
/* 3164 */           base__.Rf_gpptr(dd).getInt(44);
/*      */         Rf_GPolygon(4, (Ptr)new DoublePtr(x, 0), (Ptr)new DoublePtr(y, 0), 1, 16777215, i, dd);
/*      */     } 
/* 3167 */     Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid argument to GBox\000".getBytes(), 0)), new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GLPretty(Ptr ul, Ptr uh, Ptr n) {
/* 3182 */     dl = ul.getDouble(); dh = uh.getDouble();
/* 3183 */     p1 = (int)Mathlib.ceil(Mathlib.log10(dl));
/* 3184 */     p2 = (int)Mathlib.floor(Mathlib.log10(dh));
/* 3185 */     if (p2 <= p1 && dh / dl > 10.0D) {
/* 3186 */       p1 = (int)Mathlib.ceil(Mathlib.log10(dl) - 0.5D);
/* 3187 */       p2 = (int)Mathlib.floor(Mathlib.log10(dh) + 0.5D);
/*      */     } 
/*      */     
/* 3190 */     if (p2 > p1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3200 */       double d4 = p1, d3 = Mathlib.pow(10.0D, d4); ul.setDouble(d3);
/* 3201 */       double d2 = p2, d1 = Mathlib.pow(10.0D, d2); uh.setDouble(d1);
/* 3202 */       if (p2 - p1 > 2) {
/*      */         
/* 3204 */         if (p2 - p1 > 3) {
/*      */ 
/*      */           
/* 3207 */           n.setInt(1); return;
/*      */         }  n.setInt(2); return;
/*      */       }  n.setInt(3);
/*      */       return;
/*      */     } 
/*      */     Rf_GPretty(ul, uh, n);
/*      */     int i = -n.getInt();
/* 3214 */     n.setInt(i); } public static void Rf_GPretty(Ptr lo, Ptr up, Ptr ndiv) { baseEngine__.GEPretty(lo, up, ndiv); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GSymbol(double x, double y, int coords, int pch, Ptr dd) {
/* 3231 */     arrayOfDouble1 = new double[] { x }; arrayOfDouble2 = new double[] { y }; MixedPtr mixedPtr = MixedPtr.malloc(276); double d6 = base__.Rf_dpptr(dd).getDouble(0 + 35948), d5 = dd.getPointer().getDouble(112), d4 = d6 * d5 * 0.5D, d3 = dd.getPointer().getDouble(96), d2 = d4 * d3, d1 = base__.Rf_gpptr(dd).getDouble(28); size = Rf_GConvertYUnits(d2 * d1, 13, 0, dd);
/* 3232 */     gcontextFromGP((Ptr)mixedPtr, dd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3237 */     coords$6 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$6, 0, dd);
/*      */ 
/*      */ 
/*      */     
/* 3241 */     Rf_GClip(dd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3246 */     mixedPtr.setAlignedInt(6, 0);
/*      */ 
/*      */ 
/*      */     
/* 3250 */     if (pch == 46) size = base__.Rf_gpptr(dd).getDouble(28); 
/* 3251 */     y$7 = arrayOfDouble2[0]; baseEngine__.GESymbol(arrayOfDouble1[0], y$7, pch, size, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMtext(Ptr str, int enc, int side, double line, int outer, double at, int las, double yadj, Ptr dd) {
/* 3269 */     angle = 0.0D;
/* 3270 */     coords = 0;
/*      */     
/* 3272 */     xadj = base__.Rf_gpptr(dd).getDouble(8);
/* 3273 */     if (outer == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3282 */       switch (side) { case 1:
/* 3283 */           coords = 8; break;
/* 3284 */         case 2: coords = 9; break;
/* 3285 */         case 3: coords = 10; break;
/* 3286 */         case 4: coords = 11; break; }
/*      */     
/*      */     } else {
/*      */       switch (side) {
/*      */         case 1:
/*      */           coords = 2;
/*      */           break;
/*      */         case 2:
/*      */           coords = 3;
/*      */           break;
/*      */         case 3:
/*      */           coords = 4;
/*      */           break;
/*      */         case 4:
/*      */           coords = 5;
/*      */           break;
/*      */       } 
/*      */     } 
/* 3304 */     switch (side) {
/*      */       case 1:
/* 3306 */         if (las != 2 && las != 3) {
/*      */ 
/*      */ 
/*      */           
/* 3310 */           double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d3 = 1.0D / d4, d2 = dd.getPointer().getDouble(80), d1 = 1.0D - d2; line = d3 * d1 + line;
/* 3311 */           angle = 0.0D; break;
/*      */         }  angle = 90.0D;
/*      */         break;
/*      */       case 2:
/* 3315 */         if (las != 1 && las != 2) {
/*      */ 
/*      */ 
/*      */           
/* 3319 */           double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d2 = 1.0D / d3, d1 = dd.getPointer().getDouble(80); line = d2 * d1 + line;
/* 3320 */           angle = 90.0D; break;
/*      */         }  angle = 0.0D;
/*      */         break;
/*      */       case 3:
/* 3324 */         if (las != 2 && las != 3) {
/*      */ 
/*      */ 
/*      */           
/* 3328 */           double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d2 = 1.0D / d3, d1 = dd.getPointer().getDouble(80); line = d2 * d1 + line;
/* 3329 */           angle = 0.0D; break;
/*      */         }  angle = 90.0D;
/*      */         break;
/*      */       case 4:
/* 3333 */         if (las != 1 && las != 2) {
/*      */ 
/*      */ 
/*      */           
/* 3337 */           double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d3 = 1.0D / d4, d2 = dd.getPointer().getDouble(80), d1 = 1.0D - d2; line = d3 * d1 + line;
/* 3338 */           angle = 90.0D; break;
/*      */         }  angle = 0.0D;
/*      */         break;
/*      */     } 
/* 3342 */     Rf_GText(at, line, coords, str, enc, xadj, yadj, angle, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GExpressionWidth(SEXP expr, int units, Ptr dd) {
/* 3358 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 3359 */     width = plotmath__.GEExpressionWidth(expr, (Ptr)mixedPtr, dd);
/* 3360 */     return (units != 0) ? 
/*      */ 
/*      */       
/* 3363 */       Rf_GConvertXUnits(width, 0, units, dd) : width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double Rf_GExpressionHeight(SEXP expr, int units, Ptr dd) {
/* 3370 */     MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 3371 */     height = plotmath__.GEExpressionHeight(expr, (Ptr)mixedPtr, dd);
/* 3372 */     return (units != 0) ? 
/*      */ 
/*      */       
/* 3375 */       Rf_GConvertYUnits(height, 0, units, dd) : height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMathText(double x, double y, int coords, SEXP expr, double xc, double yc, double rot, Ptr dd) {
/* 3393 */     arrayOfDouble1 = new double[] { x }; arrayOfDouble2 = new double[] { y }; MixedPtr mixedPtr = MixedPtr.malloc(276); gcontextFromGP((Ptr)mixedPtr, dd);
/* 3394 */     coords$3 = coords; Rf_GConvert((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), coords$3, 0, dd);
/* 3395 */     Rf_GClip(dd);
/* 3396 */     y$4 = arrayOfDouble2[0]; plotmath__.GEMathText(arrayOfDouble1[0], y$4, expr, xc, yc, rot, (Ptr)mixedPtr, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void Rf_GMMathText(SEXP str, int side, double line, int outer, double at, int las, double yadj, Ptr dd) {
/* 3402 */     width = new double[1]; descent = new double[1]; ascent = new double[1]; width[0] = 0.0D; descent[0] = 0.0D; ascent[0] = 0.0D; coords = 0;
/* 3403 */     angle = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3408 */     Rf_GMetricInfo(77, (Ptr)new DoublePtr(ascent, 0), (Ptr)new DoublePtr(descent, 0), (Ptr)new DoublePtr(width, 0), 0, dd);
/* 3409 */     if (ascent[0] == 0.0D && descent[0] == 0.0D && width[0] == 0.0D) {
/* 3410 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("metric information not available for this device\000".getBytes(), 0)), new Object[0]);
/*      */     }
/* 3412 */     xadj = base__.Rf_gpptr(dd).getDouble(8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3420 */     if (outer == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3429 */       switch (side) { case 1:
/* 3430 */           coords = 8; break;
/* 3431 */         case 2: coords = 9; break;
/* 3432 */         case 3: coords = 10; break;
/* 3433 */         case 4: coords = 11; break; }  } else { switch (side) { case 1: coords = 2; break;
/*      */         case 2: coords = 3; break;
/*      */         case 3: coords = 4; break;
/* 3436 */         case 4: coords = 5; break; }  }  switch (side) {
/*      */       case 1:
/* 3438 */         if (las != 2 && las != 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3445 */           double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d3 = 1.0D / d4, d2 = dd.getPointer().getDouble(80), d1 = 1.0D - d2; line = d3 * d1 + line;
/* 3446 */           angle = 0.0D; break;
/*      */         }  angle = 90.0D;
/*      */         break;
/*      */       case 2:
/* 3450 */         if (las != 1 && las != 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3459 */           double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d2 = 1.0D / d3, d1 = dd.getPointer().getDouble(80); line = d2 * d1 + line;
/* 3460 */           angle = 90.0D; break;
/*      */         }  angle = 0.0D;
/*      */         break;
/*      */       case 3:
/* 3464 */         if (las != 2 && las != 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3473 */           double d3 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d2 = 1.0D / d3, d1 = dd.getPointer().getDouble(80); line = d2 * d1 + line;
/* 3474 */           angle = 0.0D; break;
/*      */         }  angle = 90.0D;
/*      */         break;
/*      */       case 4:
/* 3478 */         if (las != 1 && las != 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3485 */           double d4 = base__.Rf_gpptr(dd).getDouble(0 + 35588), d3 = 1.0D / d4, d2 = dd.getPointer().getDouble(80), d1 = 1.0D - d2; line = d3 * d1 + line;
/* 3486 */           angle = 90.0D; break;
/*      */         }  angle = 0.0D;
/*      */         break;
/*      */     } 
/* 3490 */     Rf_GMathText(at, line, coords, str, xadj, yadj, angle, dd);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/graphics__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */