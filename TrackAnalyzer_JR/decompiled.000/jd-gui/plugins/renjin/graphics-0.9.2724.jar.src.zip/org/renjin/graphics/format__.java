/*     */ package org.renjin.graphics;
/*     */ 
/*     */ import org.renjin.gcc.runtime.Builtins;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.Stdlib;
/*     */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Defn;
/*     */ import org.renjin.gnur.api.Print;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class format__
/*     */ {
/*     */   public static byte[] $format_via_sprintf$buff = new byte[1000];
/*     */   
/*     */   public static void Rf_formatRaw(Ptr x, int n, Ptr fieldwidth) {
/*  52 */     fieldwidth.setInt(2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_formatString(Ptr x, int n, Ptr fieldwidth, int quote) {
/*  58 */     xmax = 0; xmax = 0;
/*     */ 
/*     */     
/*  61 */     for (i = 0; i < n; i++) {
/*  62 */       int k = i * 4; Ptr ptr = x; int j = k; SEXP sEXP = (SEXP)ptr.getPointer(j).getArray(); R_NaString$43 = Rinternals.R_NaString; if (sEXP != R_NaString$43)
/*     */       
/*  64 */       { int i2 = i * 4; Ptr ptr1 = x; int i1 = i2, m = Defn.Rstrlen((SEXP)ptr1.getPointer(i1).getArray(), quote); if (quote == 0) { iftmp$46 = 0; } else { iftmp$46 = 2; }  l = m + iftmp$46; } else { if (quote == 0) { iftmp$44 = Print.R_print.getAlignedInt(2); } else { iftmp$44 = Print.R_print.getAlignedInt(1); }  l = iftmp$44; }
/*  65 */        if (l > xmax) xmax = l; 
/*     */     } 
/*  67 */     fieldwidth.setInt(xmax);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void Rf_formatLogical(Ptr x, int n, Ptr fieldwidth) {
/*  72 */     fieldwidth.setInt(1);
/*  73 */     for (i = 0; i < n; i++) {
/*  74 */       int m = i * 4; Ptr ptr = x; int k = m, j = ptr.getInt(k); R_NaInt$39 = Arith.R_NaInt; if (j != R_NaInt$39) {
/*     */ 
/*     */         
/*  77 */         int i2 = i * 4; Ptr ptr1 = x; int i1 = i2; if (ptr1.getInt(i1) == 0 || fieldwidth.getInt() > 3)
/*     */         
/*  79 */         { int i4 = i * 4; Ptr ptr2 = x; int i3 = i4; if (ptr2.getInt(i3) == 0 && fieldwidth.getInt() <= 4) {
/*  80 */             fieldwidth.setInt(5); break;
/*     */           }  }
/*     */         else { fieldwidth.setInt(4); }
/*     */       
/*     */       } else {
/*     */         int i2 = fieldwidth.getInt(), i1 = Print.R_print.getAlignedInt(1); if (i2 < i1) {
/*     */           int i3 = Print.R_print.getAlignedInt(1); fieldwidth.setInt(i3);
/*     */         } 
/*     */       } 
/*  89 */     }  } public static void Rf_formatInteger(Ptr x, int n, Ptr fieldwidth) { naflag = 0; xmax = 0; xmin = 0; xmin = Integer.MAX_VALUE; xmax = Integer.MIN_VALUE; naflag = 0;
/*     */ 
/*     */     
/*  92 */     for (i = 0; i < n; i++) {
/*  93 */       int i1 = i * 4; Ptr ptr = x; int m = i1, k = ptr.getInt(m); R_NaInt$33 = Arith.R_NaInt; if (k != R_NaInt$33)
/*     */       
/*     */       { 
/*  96 */         int i5 = i * 4; Ptr ptr2 = x; int i4 = i5; if (ptr2.getInt(i4) < xmin) { int i7 = i * 4; Ptr ptr3 = x; int i6 = i7; xmin = ptr3.getInt(i6); }
/*  97 */          int i3 = i * 4; Ptr ptr1 = x; int i2 = i3; if (ptr1.getInt(i2) > xmax) { int i7 = i * 4; Ptr ptr3 = x; int i6 = i7; xmax = ptr3.getInt(i6); }
/*     */          }
/*     */       else { naflag = 1; }
/*     */     
/* 101 */     }  if (naflag == 0)
/* 102 */     { fieldwidth.setInt(1); }
/*     */     else { int k = Print.R_print.getAlignedInt(1); fieldwidth.setInt(k); }
/* 104 */      if (xmin >= 0) {
/*     */ 
/*     */ 
/*     */       
/* 108 */       if (xmax <= 0)
/* 109 */         return;  throw new UnsatisfiedLinkException("Rf_IndexWidth");
/*     */     } 
/*     */     int j = -xmin;
/*     */     throw new UnsatisfiedLinkException("Rf_IndexWidth"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void format_via_sprintf(double r, int d, Ptr kpower, Ptr nsig) {
/* 156 */     int m = d + -1; Stdlib.snprintf(new BytePtr($format_via_sprintf$buff, 0), 1000, new BytePtr("%#.*e\000".getBytes(), 0), new Object[] { Integer.valueOf(m), Double.valueOf(r) });
/* 157 */     int k = d + 2, j = (int)Stdlib.strtol((Ptr)new BytePtr($format_via_sprintf$buff, k / 1), BytePtr.of(0), 10); kpower.setInt(j);
/* 158 */     for (i = d; i > 1 && 
/* 159 */       $format_via_sprintf$buff[i] == (byte)48; i--);
/* 160 */     nsig.setInt(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scientific(Ptr x, Ptr neg, Ptr kpower, Ptr nsig, Ptr roundingwidens) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore #11
/*     */     //   3: dconst_0
/*     */     //   4: dstore #12
/*     */     //   6: aload_0
/*     */     //   7: invokeinterface getDouble : ()D
/*     */     //   12: dconst_0
/*     */     //   13: dcmpl
/*     */     //   14: ifeq -> 20
/*     */     //   17: goto -> 52
/*     */     //   20: aload_2
/*     */     //   21: iconst_0
/*     */     //   22: invokeinterface setInt : (I)V
/*     */     //   27: aload_3
/*     */     //   28: iconst_1
/*     */     //   29: invokeinterface setInt : (I)V
/*     */     //   34: aload_1
/*     */     //   35: iconst_0
/*     */     //   36: invokeinterface setInt : (I)V
/*     */     //   41: aload #4
/*     */     //   43: iconst_0
/*     */     //   44: invokeinterface setInt : (I)V
/*     */     //   49: goto -> 679
/*     */     //   52: aload_0
/*     */     //   53: invokeinterface getDouble : ()D
/*     */     //   58: dconst_0
/*     */     //   59: dcmpg
/*     */     //   60: iflt -> 66
/*     */     //   63: goto -> 85
/*     */     //   66: aload_1
/*     */     //   67: iconst_1
/*     */     //   68: invokeinterface setInt : (I)V
/*     */     //   73: aload_0
/*     */     //   74: invokeinterface getDouble : ()D
/*     */     //   79: dneg
/*     */     //   80: dstore #12
/*     */     //   82: goto -> 100
/*     */     //   85: aload_1
/*     */     //   86: iconst_0
/*     */     //   87: invokeinterface setInt : (I)V
/*     */     //   92: aload_0
/*     */     //   93: invokeinterface getDouble : ()D
/*     */     //   98: dstore #12
/*     */     //   100: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   103: iconst_3
/*     */     //   104: invokeinterface getAlignedInt : (I)I
/*     */     //   109: bipush #15
/*     */     //   111: if_icmpgt -> 117
/*     */     //   114: goto -> 148
/*     */     //   117: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   120: iconst_3
/*     */     //   121: invokeinterface getAlignedInt : (I)I
/*     */     //   126: istore #71
/*     */     //   128: dload #12
/*     */     //   130: iload #71
/*     */     //   132: aload_2
/*     */     //   133: aload_3
/*     */     //   134: invokestatic format_via_sprintf : (DILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   137: aload #4
/*     */     //   139: iconst_0
/*     */     //   140: invokeinterface setInt : (I)V
/*     */     //   145: goto -> 679
/*     */     //   148: dload #12
/*     */     //   150: invokestatic log10 : (D)D
/*     */     //   153: invokestatic floor : (D)D
/*     */     //   156: d2i
/*     */     //   157: istore #66
/*     */     //   159: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   162: iconst_3
/*     */     //   163: invokeinterface getAlignedInt : (I)I
/*     */     //   168: istore #65
/*     */     //   170: iload #66
/*     */     //   172: iload #65
/*     */     //   174: isub
/*     */     //   175: iconst_1
/*     */     //   176: iadd
/*     */     //   177: istore #11
/*     */     //   179: dload #12
/*     */     //   181: dstore #8
/*     */     //   183: iload #11
/*     */     //   185: bipush #-22
/*     */     //   187: if_icmpge -> 193
/*     */     //   190: goto -> 255
/*     */     //   193: iload #11
/*     */     //   195: bipush #22
/*     */     //   197: if_icmple -> 203
/*     */     //   200: goto -> 255
/*     */     //   203: iload #11
/*     */     //   205: ifge -> 211
/*     */     //   208: goto -> 235
/*     */     //   211: iload #11
/*     */     //   213: iconst_1
/*     */     //   214: iadd
/*     */     //   215: istore #63
/*     */     //   217: invokestatic get__format$tbl : ()[D
/*     */     //   220: iload #63
/*     */     //   222: daload
/*     */     //   223: dstore #61
/*     */     //   225: dload #8
/*     */     //   227: dload #61
/*     */     //   229: ddiv
/*     */     //   230: dstore #8
/*     */     //   232: goto -> 252
/*     */     //   235: iconst_1
/*     */     //   236: iload #11
/*     */     //   238: isub
/*     */     //   239: istore #60
/*     */     //   241: invokestatic get__format$tbl : ()[D
/*     */     //   244: iload #60
/*     */     //   246: daload
/*     */     //   247: dload #8
/*     */     //   249: dmul
/*     */     //   250: dstore #8
/*     */     //   252: goto -> 329
/*     */     //   255: getstatic org/renjin/gnur/api/Defn.R_dec_min_exponent : I
/*     */     //   258: istore #57
/*     */     //   260: iload #11
/*     */     //   262: iload #57
/*     */     //   264: if_icmple -> 270
/*     */     //   267: goto -> 307
/*     */     //   270: dload #8
/*     */     //   272: ldc2_w 1.0E303
/*     */     //   275: dmul
/*     */     //   276: dstore #55
/*     */     //   278: iload #11
/*     */     //   280: sipush #303
/*     */     //   283: iadd
/*     */     //   284: i2d
/*     */     //   285: dstore #52
/*     */     //   287: ldc2_w 10.0
/*     */     //   290: dload #52
/*     */     //   292: invokestatic pow : (DD)D
/*     */     //   295: dstore #50
/*     */     //   297: dload #55
/*     */     //   299: dload #50
/*     */     //   301: ddiv
/*     */     //   302: dstore #8
/*     */     //   304: goto -> 329
/*     */     //   307: iload #11
/*     */     //   309: i2d
/*     */     //   310: dstore #48
/*     */     //   312: ldc2_w 10.0
/*     */     //   315: dload #48
/*     */     //   317: invokestatic pow : (DD)D
/*     */     //   320: dstore #46
/*     */     //   322: dload #8
/*     */     //   324: dload #46
/*     */     //   326: ddiv
/*     */     //   327: dstore #8
/*     */     //   329: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   332: iconst_3
/*     */     //   333: invokeinterface getAlignedInt : (I)I
/*     */     //   338: istore #45
/*     */     //   340: invokestatic get__format$tbl : ()[D
/*     */     //   343: iload #45
/*     */     //   345: daload
/*     */     //   346: dload #8
/*     */     //   348: dcmpl
/*     */     //   349: ifgt -> 355
/*     */     //   352: goto -> 369
/*     */     //   355: dload #8
/*     */     //   357: ldc2_w 10.0
/*     */     //   360: dmul
/*     */     //   361: dstore #8
/*     */     //   363: iload #11
/*     */     //   365: iconst_1
/*     */     //   366: isub
/*     */     //   367: istore #11
/*     */     //   369: dload #8
/*     */     //   371: invokestatic nearbyint : (D)D
/*     */     //   374: dstore #14
/*     */     //   376: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   379: iconst_3
/*     */     //   380: invokeinterface getAlignedInt : (I)I
/*     */     //   385: istore #42
/*     */     //   387: aload_3
/*     */     //   388: iload #42
/*     */     //   390: invokeinterface setInt : (I)V
/*     */     //   395: iconst_1
/*     */     //   396: istore #10
/*     */     //   398: goto -> 450
/*     */     //   401: dload #14
/*     */     //   403: ldc2_w 10.0
/*     */     //   406: ddiv
/*     */     //   407: dstore #14
/*     */     //   409: dload #14
/*     */     //   411: invokestatic floor : (D)D
/*     */     //   414: dload #14
/*     */     //   416: dcmpl
/*     */     //   417: ifeq -> 423
/*     */     //   420: goto -> 447
/*     */     //   423: aload_3
/*     */     //   424: invokeinterface getInt : ()I
/*     */     //   429: iconst_1
/*     */     //   430: isub
/*     */     //   431: istore #38
/*     */     //   433: aload_3
/*     */     //   434: iload #38
/*     */     //   436: invokeinterface setInt : (I)V
/*     */     //   441: iinc #10, 1
/*     */     //   444: goto -> 450
/*     */     //   447: goto -> 467
/*     */     //   450: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   453: iconst_3
/*     */     //   454: invokeinterface getAlignedInt : (I)I
/*     */     //   459: iload #10
/*     */     //   461: if_icmpge -> 401
/*     */     //   464: goto -> 467
/*     */     //   467: aload_3
/*     */     //   468: invokeinterface getInt : ()I
/*     */     //   473: ifeq -> 479
/*     */     //   476: goto -> 504
/*     */     //   479: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   482: iconst_3
/*     */     //   483: invokeinterface getAlignedInt : (I)I
/*     */     //   488: ifgt -> 494
/*     */     //   491: goto -> 504
/*     */     //   494: aload_3
/*     */     //   495: iconst_1
/*     */     //   496: invokeinterface setInt : (I)V
/*     */     //   501: iinc #11, 1
/*     */     //   504: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   507: iconst_3
/*     */     //   508: invokeinterface getAlignedInt : (I)I
/*     */     //   513: iload #11
/*     */     //   515: iadd
/*     */     //   516: iconst_m1
/*     */     //   517: iadd
/*     */     //   518: istore #32
/*     */     //   520: aload_2
/*     */     //   521: iload #32
/*     */     //   523: invokeinterface setInt : (I)V
/*     */     //   528: getstatic org/renjin/gnur/api/Print.R_print : Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   531: iconst_3
/*     */     //   532: invokeinterface getAlignedInt : (I)I
/*     */     //   537: istore #31
/*     */     //   539: aload_2
/*     */     //   540: invokeinterface getInt : ()I
/*     */     //   545: istore #30
/*     */     //   547: iload #31
/*     */     //   549: iload #30
/*     */     //   551: isub
/*     */     //   552: istore #7
/*     */     //   554: iload #7
/*     */     //   556: ifge -> 562
/*     */     //   559: goto -> 574
/*     */     //   562: iload #7
/*     */     //   564: bipush #22
/*     */     //   566: invokestatic min : (II)I
/*     */     //   569: istore #29
/*     */     //   571: goto -> 577
/*     */     //   574: iconst_0
/*     */     //   575: istore #29
/*     */     //   577: iload #29
/*     */     //   579: istore #7
/*     */     //   581: iload #7
/*     */     //   583: iconst_1
/*     */     //   584: iadd
/*     */     //   585: istore #28
/*     */     //   587: invokestatic get__format$tbl : ()[D
/*     */     //   590: iload #28
/*     */     //   592: daload
/*     */     //   593: dstore #26
/*     */     //   595: ldc2_w 0.5
/*     */     //   598: dload #26
/*     */     //   600: ddiv
/*     */     //   601: dstore #5
/*     */     //   603: aload_2
/*     */     //   604: invokeinterface getInt : ()I
/*     */     //   609: ifgt -> 615
/*     */     //   612: goto -> 663
/*     */     //   615: aload_2
/*     */     //   616: invokeinterface getInt : ()I
/*     */     //   621: bipush #22
/*     */     //   623: if_icmple -> 629
/*     */     //   626: goto -> 663
/*     */     //   629: aload_2
/*     */     //   630: invokeinterface getInt : ()I
/*     */     //   635: iconst_1
/*     */     //   636: iadd
/*     */     //   637: istore #21
/*     */     //   639: invokestatic get__format$tbl : ()[D
/*     */     //   642: iload #21
/*     */     //   644: daload
/*     */     //   645: dload #5
/*     */     //   647: dsub
/*     */     //   648: dload #12
/*     */     //   650: dcmpl
/*     */     //   651: ifgt -> 657
/*     */     //   654: goto -> 663
/*     */     //   657: iconst_1
/*     */     //   658: istore #25
/*     */     //   660: goto -> 666
/*     */     //   663: iconst_0
/*     */     //   664: istore #25
/*     */     //   666: iload #25
/*     */     //   668: istore #16
/*     */     //   670: aload #4
/*     */     //   672: iload #16
/*     */     //   674: invokeinterface setInt : (I)V
/*     */     //   679: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #201	-> 6
/*     */     //   #202	-> 20
/*     */     //   #203	-> 27
/*     */     //   #204	-> 34
/*     */     //   #205	-> 41
/*     */     //   #207	-> 52
/*     */     //   #208	-> 66
/*     */     //   #210	-> 85
/*     */     //   #212	-> 100
/*     */     //   #213	-> 117
/*     */     //   #214	-> 137
/*     */     //   #217	-> 148
/*     */     //   #242	-> 179
/*     */     //   #244	-> 183
/*     */     //   #244	-> 193
/*     */     //   #245	-> 203
/*     */     //   #245	-> 211
/*     */     //   #245	-> 235
/*     */     //   #252	-> 255
/*     */     //   #253	-> 270
/*     */     //   #255	-> 307
/*     */     //   #256	-> 329
/*     */     //   #257	-> 355
/*     */     //   #258	-> 363
/*     */     //   #263	-> 369
/*     */     //   #265	-> 376
/*     */     //   #266	-> 395
/*     */     //   #267	-> 401
/*     */     //   #268	-> 409
/*     */     //   #269	-> 423
/*     */     //   #266	-> 441
/*     */     //   #266	-> 450
/*     */     //   #274	-> 467
/*     */     //   #274	-> 479
/*     */     //   #275	-> 494
/*     */     //   #276	-> 501
/*     */     //   #278	-> 504
/*     */     //   #286	-> 528
/*     */     //   #288	-> 554
/*     */     //   #288	-> 562
/*     */     //   #288	-> 574
/*     */     //   #288	-> 577
/*     */     //   #289	-> 581
/*     */     //   #291	-> 603
/*     */     //   #291	-> 615
/*     */     //   #291	-> 629
/*     */     //   #291	-> 657
/*     */     //   #291	-> 663
/*     */     //   #291	-> 666
/*     */     //   #215	-> 679
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	680	0	x	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	680	1	neg	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	680	2	kpower	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	680	3	nsig	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	680	4	roundingwidens	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	680	5	fuzz	D
/*     */     //   0	680	7	rgt	I
/*     */     //   0	680	8	r_prec	D
/*     */     //   0	680	10	j	I
/*     */     //   0	680	11	kp	I
/*     */     //   0	680	12	r	D
/*     */     //   0	680	14	alpha	D
/*     */     //   0	680	16	iftmp$30	I
/*     */     //   0	680	25	iftmp$29	I
/*     */     //   0	680	29	iftmp$28	I
/*     */     //   0	680	57	R_dec_min_exponent$27	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_formatReal(Ptr x, int n, Ptr w, Ptr d, Ptr e, int nsmall) {
/* 313 */     nsig = new int[1]; kpower = new int[1]; neg_i = new int[1]; roundingwidens = new int[1]; neginf = 0; posinf = 0; nanflag = 0; naflag = 0; nsig[0] = 0; kpower[0] = 0; neg = 0; neg_i[0] = 0; roundingwidens[0] = 0; mxns = 0; mxsl = 0; rgt = 0; mxl = 0; mnl = 0; nanflag = 0;
/* 314 */     naflag = 0;
/* 315 */     posinf = 0;
/* 316 */     neginf = 0;
/* 317 */     neg = 0;
/* 318 */     rgt = mxl = mxsl = mxns = Integer.MIN_VALUE;
/* 319 */     mnl = Integer.MAX_VALUE;
/*     */     
/* 321 */     for (i = 0; i < n; i++) {
/* 322 */       int m = i * 8; Ptr ptr = x; int k = m; if (Arith.R_finite(ptr.getDouble(k)) != 0)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */         
/* 328 */         int i3 = i * 8; Ptr ptr1 = x; int i2 = i3; scientific(ptr1.pointerPlus(i2), (Ptr)new IntPtr(neg_i, 0), (Ptr)new IntPtr(kpower, 0), (Ptr)new IntPtr(nsig, 0), (Ptr)new IntPtr(roundingwidens, 0));
/*     */         
/* 330 */         left = kpower[0] + 1;
/* 331 */         if (roundingwidens[0] != 0) left--;
/*     */         
/* 333 */         int i1 = Math.max(left, 1); neg_i$22 = neg_i[0]; sleft = i1 + neg_i$22;
/* 334 */         right = nsig[0] - left;
/* 335 */         if (neg_i[0] != 0) neg = 1;
/*     */ 
/*     */         
/* 338 */         if (right > rgt) rgt = right; 
/* 339 */         if (left > mxl) mxl = left; 
/* 340 */         if (left < mnl) mnl = left; 
/* 341 */         if (sleft > mxsl) mxsl = sleft; 
/* 342 */         if (nsig[0] > mxns) mxns = nsig[0];  }
/*     */       else { int i2 = i * 8; Ptr ptr1 = x; int i1 = i2; if (Arith.R_IsNA(ptr1.getDouble(i1)) == 0) { int i4 = i * 8; Ptr ptr2 = x; int i3 = i4; if (Builtins.__isnan(ptr2.getDouble(i3)) == 0) {
/*     */             int i6 = i * 8; Ptr ptr3 = x; int i5 = i6; if (ptr3.getDouble(i5) <= 0.0D) {
/*     */               neginf = 1;
/*     */             } else {
/*     */               posinf = 1;
/*     */             } 
/*     */           } else {
/*     */             nanflag = 1;
/*     */           }  }
/*     */         else
/*     */         { naflag = 1; }
/*     */          }
/*     */     
/* 356 */     }  if (Print.R_print.getAlignedInt(3) == 0) rgt = 0; 
/* 357 */     if (mxl < 0) mxsl = neg + 1;
/*     */ 
/*     */     
/* 360 */     if (rgt < 0) rgt = 0; 
/* 361 */     int j = mxsl + rgt; byte b = (rgt == 0) ? 0 : 1; wF = j + b;
/*     */ 
/*     */     
/* 364 */     if (mxl <= 100 && mnl >= -98) { iftmp$26 = 1; } else { iftmp$26 = 2; }  e.setInt(iftmp$26);
/* 365 */     if (mxns == Integer.MIN_VALUE)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 379 */       w.setInt(0);
/* 380 */       d.setInt(0);
/* 381 */       e.setInt(0); } else { int i6 = mxns + -1; d.setInt(i6); int i5 = ((d.getInt() <= 0) ? 0 : 1) + neg, i4 = d.getInt(), i3 = i5 + i4 + 4, i2 = e.getInt(), i1 = i3 + i2; w.setInt(i1); int m = w.getInt(), k = Print.R_print.getAlignedInt(4); if (m + k >= wF) { e.setInt(0); if (nsmall > rgt) { rgt = nsmall; int i7 = mxsl + rgt; byte b1 = (rgt == 0) ? 0 : 1; wF = i7 + b1; }  d.setInt(rgt); w.setInt(wF); }
/*     */        }
/* 383 */      if (naflag != 0) { int m = w.getInt(), k = Print.R_print.getAlignedInt(1); if (m < k)
/* 384 */       { int i1 = Print.R_print.getAlignedInt(1); w.setInt(i1); }  }
/* 385 */      if (nanflag != 0 && w.getInt() <= 2) w.setInt(3); 
/* 386 */     if (posinf != 0 && w.getInt() <= 2) w.setInt(3); 
/* 387 */     if (neginf != 0 && w.getInt() <= 3) w.setInt(4);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_formatComplex(Ptr x, int n, Ptr wr, Ptr dr, Ptr er, Ptr wi, Ptr di, Ptr ei, int nsmall) {
/* 405 */     MixedPtr mixedPtr = MixedPtr.malloc(16); nsig = new int[1]; kpower = new int[1]; neg_i = new int[1]; roundingwidens = new int[1]; all_im_zero = 0; all_re_zero = 0; iposinf = 0; inanflag = 0; rneginf = 0; rposinf = 0; rnanflag = 0; naflag = 0; nsig[0] = 0; kpower[0] = 0; neg = 0; neg_i[0] = 0; roundingwidens[0] = 0; i_mxns = 0; i_mxsl = 0; i_mxl = 0; i_mnl = 0; i_rt = 0; mxns = 0; mxsl = 0; mxl = 0; mnl = 0; Rf_rt = 0; all_re_zero = 1; all_im_zero = 1;
/*     */     
/* 407 */     naflag = 0;
/* 408 */     rnanflag = 0;
/* 409 */     rposinf = 0;
/* 410 */     rneginf = 0;
/* 411 */     inanflag = 0;
/* 412 */     iposinf = 0;
/* 413 */     neg = 0;
/*     */     
/* 415 */     Rf_rt = mxl = mxsl = mxns = Integer.MIN_VALUE;
/* 416 */     i_rt = i_mxl = i_mxsl = i_mxns = Integer.MIN_VALUE;
/* 417 */     i_mnl = mnl = Integer.MAX_VALUE;
/*     */     
/* 419 */     i = 0; if (i >= n) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 479 */       if (Print.R_print.getAlignedInt(3) == 0) Rf_rt = 0; 
/* 480 */       if (mxl == Integer.MIN_VALUE)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 489 */         er.setInt(0);
/* 490 */         wr.setInt(0);
/* 491 */         dr.setInt(0);
/* 492 */         wF = 0; } else { if (mxl < 0)
/*     */           mxsl = neg + 1;  if (Rf_rt < 0)
/*     */           Rf_rt = 0;  int i6 = mxsl + Rf_rt; byte b = (Rf_rt == 0) ? 0 : 1; wF = i6 + b; if (mxl <= 100 && mnl >= -99) { iftmp$13 = 1; }
/*     */         else { iftmp$13 = 2; }
/*     */          er.setInt(iftmp$13); int i5 = mxns + -1; dr.setInt(i5); int i4 = ((dr.getInt() <= 0) ? 0 : 1) + neg, i3 = dr.getInt(), i2 = i4 + i3 + 4, i1 = er.getInt(), m = i2 + i1; wr.setInt(m); }
/* 497 */        if (Print.R_print.getAlignedInt(3) == 0) i_rt = 0; 
/* 498 */       if (i_mxl == Integer.MIN_VALUE)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 507 */         ei.setInt(0);
/* 508 */         wi.setInt(0);
/* 509 */         di.setInt(0);
/* 510 */         i_wF = 0; } else { if (i_mxl < 0)
/*     */           i_mxsl = 1;  if (i_rt < 0)
/*     */           i_rt = 0;  int i5 = i_mxsl + i_rt; byte b2 = (i_rt == 0) ? 0 : 1; i_wF = i5 + b2; if (i_mxl <= 100 && i_mnl >= -99) { iftmp$14 = 1; } else { iftmp$14 = 2; }
/*     */          ei.setInt(iftmp$14); int i4 = i_mxns + -1; di.setInt(i4); byte b1 = (di.getInt() <= 0) ? 0 : 1; int i3 = di.getInt(), i2 = b1 + i3 + 4, i1 = ei.getInt(), m = i2 + i1; wi.setInt(m); }
/* 514 */        if (all_re_zero == 0)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 523 */         if (all_im_zero == 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 532 */           int i5 = wF + i_wF, i4 = wr.getInt(), i3 = wi.getInt(), i2 = i4 + i3, i1 = Print.R_print.getAlignedInt(4) * 2, m = i2 + i1; if (i5 < m)
/* 533 */           { er.setInt(0);
/* 534 */             if (nsmall > Rf_rt) { Rf_rt = nsmall; int i6 = mxsl + Rf_rt; byte b = (Rf_rt == 0) ? 0 : 1; wF = i6 + b; }
/* 535 */              dr.setInt(Rf_rt);
/* 536 */             wr.setInt(wF);
/*     */             
/* 538 */             ei.setInt(0);
/* 539 */             if (nsmall > i_rt) {
/* 540 */               i_rt = nsmall;
/* 541 */               int i6 = i_mxsl + i_rt; byte b = (i_rt == 0) ? 0 : 1; i_wF = i6 + b;
/*     */             } 
/* 543 */             di.setInt(i_rt);
/* 544 */             wi.setInt(i_wF); }  } else { int i2 = wr.getInt(), i1 = Print.R_print.getAlignedInt(4); if (i2 + i1 >= wF) { er.setInt(0); if (nsmall > Rf_rt) { Rf_rt = nsmall; int i3 = mxsl + Rf_rt; byte b = (Rf_rt == 0) ? 0 : 1; wF = i3 + b; }  dr.setInt(Rf_rt); wr.setInt(wF); }  di.setInt(0); int m = di.getInt(); ei.setInt(m); wi.setInt(i_wF); }  } else { dr.setInt(0); int i2 = dr.getInt(); er.setInt(i2); wr.setInt(wF); int i1 = wi.getInt(), m = Print.R_print.getAlignedInt(4); if (i1 + m >= i_wF) { ei.setInt(0); if (nsmall > i_rt) { i_rt = nsmall; int i3 = i_mxsl + i_rt; byte b = (i_rt == 0) ? 0 : 1; i_wF = i3 + b; }  di.setInt(i_rt); wi.setInt(i_wF); }
/*     */          }
/* 546 */        if (wr.getInt() < 0) wr.setInt(0); 
/* 547 */       if (wi.getInt() < 0) wi.setInt(0);
/*     */ 
/*     */       
/* 550 */       if (rnanflag != 0 && wr.getInt() <= 2) wr.setInt(3); 
/* 551 */       if (rposinf != 0 && wr.getInt() <= 2) wr.setInt(3); 
/* 552 */       if (rneginf != 0 && wr.getInt() <= 3) wr.setInt(4); 
/* 553 */       if (inanflag != 0 && wi.getInt() <= 2) wi.setInt(3); 
/* 554 */       if (iposinf != 0 && wi.getInt() <= 2) wi.setInt(3);
/*     */ 
/*     */ 
/*     */       
/* 558 */       if (naflag != 0) { int i3 = wr.getInt(), i2 = wi.getInt(), i1 = i3 + i2 + 2, m = Print.R_print.getAlignedInt(1); if (i1 < m) {
/* 559 */           int i11 = wr.getInt(), i10 = Print.R_print.getAlignedInt(1), i9 = wr.getInt(), i8 = wi.getInt(), i7 = i9 + i8, i6 = -2 - i7, i5 = i10 + i6, i4 = i11 + i5; wr.setInt(i4);
/*     */         }  }
/*     */       
/*     */       return;
/*     */     } 
/*     */     double d = Print.R_print.getAlignedInt(3);
/*     */     int k = i * 16;
/*     */     Ptr ptr = x;
/*     */     int j = k;
/*     */     throw new UnsatisfiedLinkException("z_prec_r");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/graphics-0.9.2724.jar!/org/renjin/graphics/format__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */