/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.renjin.gcc.analysis.FlowFunction;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.GimpleOp;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleAssignment;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordType;
/*     */ import org.renjin.gcc.gimple.type.GimpleRecordTypeDef;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.ImmutableMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SexpFlowFunction
/*     */   implements FlowFunction<Multimap<Long, GimpleCall>>
/*     */ {
/*  46 */   private Set<Long> sexpLocalVariables = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public SexpFlowFunction(GimpleCompilationUnit unit, GimpleFunction fn) {
/*  51 */     Set<String> sexpTypeIds = new HashSet<>();
/*  52 */     for (GimpleRecordTypeDef recordTypeDef : unit.getRecordTypes()) {
/*  53 */       if ("SEXPREC".equals(recordTypeDef.getName())) {
/*  54 */         sexpTypeIds.add(recordTypeDef.getId());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  59 */     for (GimpleVarDecl varDecl : fn.getVariableDeclarations()) {
/*  60 */       if (varDecl.getType() instanceof org.renjin.gcc.gimple.type.GimplePointerType && varDecl
/*  61 */         .getType().getBaseType() instanceof GimpleRecordType) {
/*     */         
/*  63 */         GimpleRecordType recordType = (GimpleRecordType)varDecl.getType().getBaseType();
/*  64 */         if (sexpTypeIds.contains(recordType.getId())) {
/*  65 */           this.sexpLocalVariables.add(Long.valueOf(varDecl.getId()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Multimap<Long, GimpleCall> initialState() {
/*  74 */     return (Multimap<Long, GimpleCall>)ImmutableMultimap.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public Multimap<Long, GimpleCall> transfer(Multimap<Long, GimpleCall> entryState, Iterable<GimpleStatement> basicBlock) {
/*  79 */     HashMultimap hashMultimap = HashMultimap.create();
/*  80 */     for (GimpleStatement statement : basicBlock) {
/*  81 */       updateValueMap(statement, (Multimap<Long, GimpleCall>)hashMultimap);
/*     */     }
/*  83 */     return (Multimap<Long, GimpleCall>)hashMultimap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateValueMap(GimpleStatement statement, Multimap<Long, GimpleCall> valueMap) {
/*  90 */     if (statement instanceof GimpleCall) {
/*  91 */       GimpleCall call = (GimpleCall)statement;
/*  92 */       if (call.getLhs() instanceof GimpleVariableRef) {
/*  93 */         GimpleVariableRef lhs = (GimpleVariableRef)call.getLhs();
/*  94 */         if (this.sexpLocalVariables.contains(Long.valueOf(lhs.getId()))) {
/*  95 */           valueMap.put(Long.valueOf(lhs.getId()), call);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     if (statement instanceof GimpleAssignment) {
/* 101 */       GimpleAssignment assignment = (GimpleAssignment)statement;
/* 102 */       if (assignment.getLHS() instanceof GimpleVariableRef) {
/* 103 */         GimpleVariableRef lhs = (GimpleVariableRef)assignment.getLHS();
/* 104 */         if (this.sexpLocalVariables.contains(Long.valueOf(lhs.getId())))
/*     */         {
/* 106 */           if (assignment.getOperator() == GimpleOp.VAR_DECL) {
/* 107 */             GimpleVariableRef rhs = assignment.getOperands().get(0);
/* 108 */             if (valueMap.containsKey(Long.valueOf(rhs.getId()))) {
/* 109 */               valueMap.putAll(Long.valueOf(lhs.getId()), valueMap.get(Long.valueOf(rhs.getId())));
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 114 */             valueMap.removeAll(Long.valueOf(lhs.getId()));
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Multimap<Long, GimpleCall> join(List<Multimap<Long, GimpleCall>> inputs) {
/* 123 */     HashMultimap hashMultimap = HashMultimap.create();
/* 124 */     for (Multimap<Long, GimpleCall> input : inputs) {
/* 125 */       hashMultimap.putAll(input);
/*     */     }
/* 127 */     return (Multimap<Long, GimpleCall>)hashMultimap;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/SexpFlowFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */