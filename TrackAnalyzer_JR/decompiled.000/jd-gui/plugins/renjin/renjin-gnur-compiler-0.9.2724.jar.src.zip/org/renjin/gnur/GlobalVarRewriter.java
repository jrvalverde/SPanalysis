/*    */ package org.renjin.gnur;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.renjin.gcc.codegen.GlobalVarTransformer;
/*    */ import org.renjin.gcc.codegen.expr.GExpr;
/*    */ import org.renjin.gcc.codegen.type.TypeOracle;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalVarRewriter
/*    */   implements GlobalVarTransformer
/*    */ {
/*    */   private final ContextVarAllocator allocator;
/* 39 */   private List<GimpleVarDecl> contextVars = new ArrayList<>();
/*    */   
/*    */   public GlobalVarRewriter(Type contextClass) {
/* 42 */     this.allocator = new ContextVarAllocator(contextClass);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean accept(GimpleVarDecl decl) {
/* 51 */     if (decl.getMangledName().equals("_ZTVN10__cxxabiv120__si_class_type_infoE")) {
/* 52 */       return false;
/*    */     }
/*    */     
/* 55 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GExpr generator(TypeOracle typeOracle, GimpleCompilationUnit unit, GimpleVarDecl decl) {
/* 61 */     this.contextVars.add(decl);
/*    */     
/* 63 */     return typeOracle.forType(decl.getType()).variable(decl, this.allocator.forUnit(unit));
/*    */   }
/*    */   
/*    */   public List<ContextField> getContextFields() {
/* 67 */     return this.allocator.getContextFields();
/*    */   }
/*    */   
/*    */   public List<GimpleVarDecl> getContextVars() {
/* 71 */     return this.contextVars;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/GlobalVarRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */