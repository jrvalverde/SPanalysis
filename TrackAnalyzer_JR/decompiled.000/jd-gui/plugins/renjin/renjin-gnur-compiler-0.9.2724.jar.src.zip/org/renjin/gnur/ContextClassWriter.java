/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.gcc.codegen.CodeGenerationContext;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.ConstantValue;
/*     */ import org.renjin.gcc.codegen.expr.ExprFactory;
/*     */ import org.renjin.gcc.codegen.expr.GExpr;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.gimple.GimpleVarDecl;
/*     */ import org.renjin.gcc.gimple.expr.GimpleConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleSymbolRef;
/*     */ import org.renjin.gcc.gimple.type.GimpleIndirectType;
/*     */ import org.renjin.gcc.symbols.SymbolTable;
/*     */ import org.renjin.primitives.Native;
/*     */ import org.renjin.repackaged.asm.ClassWriter;
/*     */ import org.renjin.repackaged.asm.MethodVisitor;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextClassWriter
/*     */ {
/*     */   private final Type contextClass;
/*     */   private final String currentMethodDescriptor;
/*     */   private final ClassWriter cv;
/*     */   
/*     */   public ContextClassWriter(Type contextClass) {
/*  51 */     this.contextClass = contextClass;
/*  52 */     this.cv = new ClassWriter(3);
/*  53 */     this.cv.visit(52, 33, contextClass.getInternalName(), null, 
/*  54 */         Type.getInternalName(Object.class), new String[0]);
/*     */     
/*  56 */     this.currentMethodDescriptor = Type.getMethodDescriptor(contextClass, new Type[0]);
/*     */     
/*  58 */     writeCurrentMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeCurrentMethod() {
/*  67 */     MethodVisitor mv = this.cv.visitMethod(9, "current", this.currentMethodDescriptor, null, null);
/*     */     
/*  69 */     mv.visitCode();
/*     */     
/*  71 */     mv.visitMethodInsn(184, Type.getInternalName(Native.class), "currentContext", 
/*  72 */         Type.getMethodDescriptor(Type.getType(Context.class), new Type[0]), false);
/*     */ 
/*     */ 
/*     */     
/*  76 */     mv.visitLdcInsn(this.contextClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     mv.visitMethodInsn(182, Type.getInternalName(Context.class), "getSingleton", 
/*  83 */         Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Class.class) }), false);
/*     */     
/*  85 */     mv.visitTypeInsn(192, this.contextClass.getInternalName());
/*     */     
/*  87 */     mv.visitInsn(176);
/*  88 */     mv.visitMaxs(1, 1);
/*  89 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   public void writeFields(List<ContextField> fields) {
/*  93 */     for (ContextField field : fields) {
/*  94 */       writeInstanceField(field);
/*     */     }
/*  96 */     for (ContextField field : fields) {
/*  97 */       writeGetter(field);
/*  98 */       writeSetter(field);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeInstanceField(ContextField sessionVar) {
/* 103 */     this.cv.visitField(1, sessionVar.getVarName(), sessionVar.getType().getDescriptor(), null, sessionVar
/* 104 */         .getInitialValue().flatMap(this::initialFieldValue).orElse(null));
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeGetter(ContextField var) {
/* 109 */     MethodVisitor mv = this.cv.visitMethod(9, var.getGetterName(), var.getGetterDescriptor(), null, null);
/* 110 */     mv.visitCode();
/*     */     
/* 112 */     writeLoadCurrentContext(mv);
/*     */ 
/*     */ 
/*     */     
/* 116 */     mv.visitFieldInsn(180, this.contextClass.getInternalName(), var.getVarName(), var.getType().getDescriptor());
/* 117 */     mv.visitInsn(var.getType().getOpcode(172));
/*     */     
/* 119 */     mv.visitMaxs(1, 1);
/* 120 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeSetter(ContextField var) {
/* 125 */     MethodVisitor mv = this.cv.visitMethod(9, var.getSetterName(), var.getSetterDescriptor(), null, null);
/* 126 */     mv.visitCode();
/*     */ 
/*     */     
/* 129 */     writeLoadCurrentContext(mv);
/*     */ 
/*     */     
/* 132 */     mv.visitVarInsn(var.getType().getOpcode(21), 0);
/*     */ 
/*     */     
/* 135 */     mv.visitFieldInsn(181, this.contextClass.getInternalName(), var.getVarName(), var.getType().getDescriptor());
/*     */     
/* 137 */     mv.visitInsn(177);
/*     */     
/* 139 */     mv.visitMaxs(1, 1);
/* 140 */     mv.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeLoadCurrentContext(MethodVisitor mv) {
/* 145 */     mv.visitMethodInsn(184, this.contextClass.getInternalName(), "current", this.currentMethodDescriptor, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private Optional<Object> initialFieldValue(JExpr initialValue) {
/* 150 */     if (initialValue instanceof ConstantValue) {
/* 151 */       return Optional.of(((ConstantValue)initialValue).getValue());
/*     */     }
/* 153 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(CodeGenerationContext output) throws IOException {
/* 158 */     output.writeClassFile(this.contextClass, this.cv.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeConstructor(CodeGenerationContext generationContext, List<ContextField> contextFields, List<GimpleVarDecl> globalVars) {
/* 165 */     MethodVisitor mv = this.cv.visitMethod(1, "<init>", "()V", null, null);
/* 166 */     mv.visitCode();
/* 167 */     mv.visitVarInsn(25, 0);
/* 168 */     mv.visitMethodInsn(183, Type.getInternalName(Object.class), "<init>", "()V", false);
/*     */     
/* 170 */     MethodGenerator methodGenerator = new MethodGenerator(this.contextClass, mv);
/*     */ 
/*     */     
/* 173 */     methodGenerator.getLocalVarAllocator().reserve(this.contextClass);
/*     */     
/* 175 */     for (ContextField contextField : contextFields) {
/* 176 */       contextField.writeFieldInit(methodGenerator);
/*     */     }
/*     */     
/* 179 */     for (GimpleVarDecl globalVar : globalVars) {
/* 180 */       writeGlobalVarInit(generationContext, methodGenerator, globalVar);
/*     */     }
/*     */     
/* 183 */     mv.visitInsn(177);
/* 184 */     mv.visitMaxs(1, 1);
/* 185 */     mv.visitEnd();
/*     */   }
/*     */   
/*     */   private void writeGlobalVarInit(CodeGenerationContext generationContext, MethodGenerator mv, GimpleVarDecl globalVar) {
/*     */     GimpleConstant gimpleConstant;
/* 190 */     GimpleExpr initialValue = globalVar.getValue();
/* 191 */     if (initialValue == null && globalVar.getType() instanceof GimpleIndirectType) {
/* 192 */       gimpleConstant = ((GimpleIndirectType)globalVar.getType()).nullValue();
/*     */     }
/*     */     
/* 195 */     if (gimpleConstant != null) {
/* 196 */       SymbolTable symbolTable = generationContext.getSymbolTable(globalVar.getUnit());
/* 197 */       ExprFactory exprFactory = new ExprFactory(generationContext.getTypeOracle(), symbolTable, mv);
/*     */ 
/*     */       
/*     */       try {
/* 201 */         GExpr initialValueExpr = exprFactory.findGenerator((GimpleExpr)gimpleConstant);
/*     */         
/* 203 */         GExpr varExpr = symbolTable.getVariable((GimpleSymbolRef)globalVar.newRef());
/*     */         
/* 205 */         varExpr.store(mv, initialValueExpr);
/* 206 */       } catch (Exception e) {
/* 207 */         System.err.println("Exception initializing per-thread global var '" + globalVar.getMangledName() + "'");
/* 208 */         e.printStackTrace(System.err);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/ContextClassWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */