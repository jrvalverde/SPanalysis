/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.renjin.gcc.codegen.MethodGenerator;
/*     */ import org.renjin.gcc.codegen.expr.JExpr;
/*     */ import org.renjin.gcc.codegen.expr.JLValue;
/*     */ import org.renjin.repackaged.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextField
/*     */ {
/*     */   private final Type contextClass;
/*     */   private String name;
/*     */   private Type type;
/*     */   private final Optional<JExpr> initialValue;
/*     */   
/*     */   public ContextField(Type contextClass, String varName, Type type, Optional<JExpr> initialValue) {
/*  38 */     this.contextClass = contextClass;
/*  39 */     this.name = varName;
/*  40 */     this.type = type;
/*  41 */     this.initialValue = initialValue;
/*     */   }
/*     */   
/*     */   public String getVarName() {
/*  45 */     return this.name;
/*     */   }
/*     */   
/*     */   public Type getType() {
/*  49 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getGetterName() {
/*  53 */     return "get__" + this.name;
/*     */   }
/*     */   
/*     */   public String getGetterDescriptor() {
/*  57 */     return Type.getMethodDescriptor(this.type, new Type[0]);
/*     */   }
/*     */   
/*     */   public String getSetterName() {
/*  61 */     return "set__" + this.name;
/*     */   }
/*     */   
/*     */   public String getSetterDescriptor() {
/*  65 */     return Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { this.type });
/*     */   }
/*     */   
/*     */   public Optional<JExpr> getInitialValue() {
/*  69 */     return this.initialValue;
/*     */   }
/*     */   
/*     */   public JLValue jvalue() {
/*  73 */     return new JLValue()
/*     */       {
/*     */         @Nonnull
/*     */         public Type getType()
/*     */         {
/*  78 */           return ContextField.this.type;
/*     */         }
/*     */ 
/*     */         
/*     */         public void load(@Nonnull MethodGenerator mv) {
/*  83 */           if (mv.getOwnerClass().equals(ContextField.this.contextClass)) {
/*     */             
/*  85 */             mv.visitVarInsn(25, 0);
/*  86 */             mv.visitFieldInsn(180, ContextField.this.contextClass.getInternalName(), ContextField.this.name, ContextField.this.type.getDescriptor());
/*     */           } else {
/*     */             
/*  89 */             mv.invokestatic(ContextField.this.contextClass, ContextField.this.getGetterName(), ContextField.this.getGetterDescriptor());
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void store(MethodGenerator mv, JExpr expr) {
/*  95 */           if (mv.getOwnerClass().equals(ContextField.this.contextClass)) {
/*     */             
/*  97 */             mv.visitVarInsn(25, 0);
/*  98 */             expr.load(mv);
/*  99 */             mv.visitFieldInsn(181, ContextField.this.contextClass.getInternalName(), ContextField.this.name, ContextField.this.type.getDescriptor());
/*     */           } else {
/*     */             
/* 102 */             expr.load(mv);
/* 103 */             mv.invokestatic(ContextField.this.contextClass, ContextField.this.getSetterName(), ContextField.this.getSetterDescriptor());
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public void writeFieldInit(MethodGenerator mv) {
/* 110 */     this.initialValue.ifPresent(value -> {
/*     */           mv.load(0, this.contextClass);
/*     */           value.load(mv);
/*     */           mv.putfield(this.contextClass, this.name, this.type);
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/ContextField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */