/*    */ package org.renjin.gnur;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.renjin.gnur.api.Rinternals;
/*    */ import org.renjin.gnur.api.annotations.Allocator;
/*    */ import org.renjin.gnur.api.annotations.PotentialMutator;
/*    */ import org.renjin.repackaged.guava.collect.Sets;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApiOracle
/*    */ {
/* 39 */   private Set<String> allocators = new HashSet<>();
/*    */   
/* 41 */   private Map<String, Method> potentialMutators = new HashMap<>();
/*    */   
/*    */   public ApiOracle() {
/* 44 */     Set<Class<?>> apiClasses = Sets.newHashSet((Object[])new Class[] { Rinternals.class });
/*    */     
/* 46 */     for (Class<?> apiClass : apiClasses) {
/* 47 */       for (Method method : apiClass.getMethods()) {
/* 48 */         if (method.getAnnotation(Allocator.class) != null) {
/* 49 */           this.allocators.add(method.getName());
/*    */         }
/* 51 */         if (method.getAnnotation(PotentialMutator.class) != null) {
/* 52 */           checkPotentialMutatorAnnotation(method);
/* 53 */           this.potentialMutators.put(method.getName(), method);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void checkPotentialMutatorAnnotation(Method method) {
/* 60 */     if (!method.getReturnType().equals(SEXP.class)) {
/* 61 */       throw new IllegalStateException("Methods annotated with @" + PotentialMutator.class.getSimpleName() + " must return " + SEXP.class
/* 62 */           .getSimpleName());
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isAllocator(String functionName) {
/* 67 */     return this.allocators.contains(functionName);
/*    */   }
/*    */   
/*    */   public boolean isPotentialMutator(String functionName) {
/* 71 */     return this.potentialMutators.containsKey(functionName);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/ApiOracle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */