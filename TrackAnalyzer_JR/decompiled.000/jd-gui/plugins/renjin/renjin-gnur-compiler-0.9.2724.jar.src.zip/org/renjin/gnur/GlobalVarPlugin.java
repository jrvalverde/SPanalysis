/*    */ package org.renjin.gnur;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import org.renjin.gcc.GimpleCompilerPlugin;
/*    */ import org.renjin.gcc.codegen.CodeGenerationContext;
/*    */ import org.renjin.gcc.codegen.FunctionGenerator;
/*    */ import org.renjin.gcc.codegen.GlobalVarTransformer;
/*    */ import org.renjin.repackaged.asm.MethodVisitor;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalVarPlugin
/*    */   extends GimpleCompilerPlugin
/*    */ {
/*    */   private final Type contextClass;
/*    */   private GlobalVarRewriter globalVarRewriter;
/*    */   
/*    */   public GlobalVarPlugin(String packageName) {
/* 62 */     this.contextClass = Type.getType("L" + packageName.replace('.', '/') + "/Context;");
/* 63 */     this.globalVarRewriter = new GlobalVarRewriter(this.contextClass);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nonnull
/*    */   public List<GlobalVarTransformer> createGlobalVarTransformers() {
/* 69 */     return Collections.singletonList(this.globalVarRewriter);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeTrampolinePrelude(MethodVisitor mv, FunctionGenerator functionGenerator) {}
/*    */ 
/*    */   
/*    */   public void writeClasses(CodeGenerationContext generationContext) throws IOException {
/* 78 */     ContextClassWriter writer = new ContextClassWriter(this.contextClass);
/* 79 */     writer.writeFields(this.globalVarRewriter.getContextFields());
/* 80 */     writer.writeConstructor(generationContext, this.globalVarRewriter
/* 81 */         .getContextFields(), this.globalVarRewriter
/* 82 */         .getContextVars());
/*    */     
/* 84 */     writer.writeTo(generationContext);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/GlobalVarPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */