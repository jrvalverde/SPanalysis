/*    */ package org.renjin.gnur;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.renjin.gcc.codegen.expr.JExpr;
/*    */ import org.renjin.gcc.codegen.expr.JLValue;
/*    */ import org.renjin.gcc.codegen.var.VarAllocator;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.repackaged.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextVarAllocator
/*    */ {
/*    */   private final Type contextClass;
/* 39 */   private List<ContextField> fields = new ArrayList<>();
/*    */   
/*    */   public ContextVarAllocator(Type contextClass) {
/* 42 */     this.contextClass = contextClass;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JLValue reserve(GimpleCompilationUnit unit, String name, Type type, Optional<JExpr> initialValue) {
/* 48 */     String varName = VarAllocator.toJavaSafeName(unit.getName()) + "$" + VarAllocator.toJavaSafeName(name);
/* 49 */     ContextField var = new ContextField(this.contextClass, varName, type, initialValue);
/*    */     
/* 51 */     this.fields.add(var);
/*    */     
/* 53 */     return var.jvalue();
/*    */   }
/*    */ 
/*    */   
/*    */   public VarAllocator forUnit(final GimpleCompilationUnit unit) {
/* 58 */     return new VarAllocator()
/*    */       {
/*    */         public JLValue reserve(String name, Type type) {
/* 61 */           return ContextVarAllocator.this.reserve(unit, name, type, Optional.empty());
/*    */         }
/*    */ 
/*    */         
/*    */         public JLValue reserve(String name, Type type, JExpr initialValue) {
/* 66 */           return ContextVarAllocator.this.reserve(unit, name, type, Optional.of(initialValue));
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ContextField> getContextFields() {
/* 73 */     return this.fields;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/ContextVarAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */