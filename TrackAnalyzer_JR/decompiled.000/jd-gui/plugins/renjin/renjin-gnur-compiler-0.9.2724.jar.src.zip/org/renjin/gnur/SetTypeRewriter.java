/*     */ package org.renjin.gnur;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.renjin.gcc.analysis.ControlFlowGraph;
/*     */ import org.renjin.gcc.analysis.DataFlowAnalysis;
/*     */ import org.renjin.gcc.analysis.FunctionBodyTransformer;
/*     */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gcc.gimple.GimpleFunction;
/*     */ import org.renjin.gcc.gimple.expr.GimpleAddressOf;
/*     */ import org.renjin.gcc.gimple.expr.GimpleExpr;
/*     */ import org.renjin.gcc.gimple.expr.GimpleFunctionRef;
/*     */ import org.renjin.gcc.gimple.expr.GimpleIntegerConstant;
/*     */ import org.renjin.gcc.gimple.expr.GimpleVariableRef;
/*     */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*     */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*     */ import org.renjin.gcc.logging.LogManager;
/*     */ import org.renjin.repackaged.guava.collect.HashMultimap;
/*     */ import org.renjin.repackaged.guava.collect.Iterables;
/*     */ import org.renjin.repackaged.guava.collect.Multimap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetTypeRewriter
/*     */   implements FunctionBodyTransformer
/*     */ {
/*     */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/*  51 */     if (!hasSetTypeOfCall(fn)) {
/*  52 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  57 */     ControlFlowGraph cfg = new ControlFlowGraph(fn);
/*  58 */     SexpFlowFunction flowFunction = new SexpFlowFunction(unit, fn);
/*  59 */     DataFlowAnalysis<Multimap<Long, GimpleCall>> flowAnalysis = new DataFlowAnalysis(cfg, flowFunction);
/*     */ 
/*     */     
/*  62 */     HashMultimap hashMultimap = HashMultimap.create();
/*  63 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/*  64 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/*  65 */         if (isSetTypeCall(statement)) {
/*  66 */           GimpleCall setTypeCall = (GimpleCall)statement;
/*  67 */           if (setTypeCall.getOperand(0) instanceof GimpleVariableRef) {
/*  68 */             GimpleVariableRef target = (GimpleVariableRef)setTypeCall.getOperand(0);
/*  69 */             Collection<GimpleCall> allocSites = ((Multimap)flowAnalysis.getState(basicBlock, statement)).get(Long.valueOf(target.getId()));
/*  70 */             int targetType = getTargetType(statement);
/*     */             
/*  72 */             for (GimpleCall allocSite : allocSites) {
/*  73 */               hashMultimap.put(allocSite, Integer.valueOf(targetType));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  82 */     boolean changed = false;
/*     */     
/*  84 */     for (GimpleCall allocSite : hashMultimap.keySet()) {
/*  85 */       Collection<Integer> types = hashMultimap.get(allocSite);
/*  86 */       if (types.size() == 1) {
/*  87 */         int targetType = ((Integer)Iterables.getOnlyElement(types)).intValue();
/*  88 */         if (allocSite.isFunctionNamed("Rf_allocList") && targetType == 6) {
/*  89 */           allocSite.setFunction((GimpleExpr)new GimpleAddressOf((GimpleExpr)new GimpleFunctionRef("Rf_allocLang")));
/*  90 */           logManager.note("changed Rf_allocList to Rf_allocLang at " + allocSite
/*  91 */               .getSourceFile() + ":" + allocSite.getLineNumber());
/*  92 */           changed = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  97 */     return changed;
/*     */   }
/*     */   
/*     */   private boolean hasSetTypeOfCall(GimpleFunction fn) {
/* 101 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/* 102 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 103 */         if (isSetTypeCall(statement)) {
/* 104 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 108 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isSetTypeCall(GimpleStatement statement) {
/* 112 */     if (statement instanceof GimpleCall) {
/* 113 */       GimpleCall call = (GimpleCall)statement;
/* 114 */       if (call.isFunctionNamed("SET_TYPEOF")) {
/* 115 */         return true;
/*     */       }
/*     */     } 
/* 118 */     return false;
/*     */   }
/*     */   
/*     */   private int getTargetType(GimpleStatement statement) {
/* 122 */     GimpleCall call = (GimpleCall)statement;
/* 123 */     if (call.getOperands().size() == 2) {
/* 124 */       GimpleExpr typeOperand = call.getOperand(1);
/* 125 */       if (typeOperand instanceof GimpleIntegerConstant) {
/* 126 */         GimpleIntegerConstant typeConstant = (GimpleIntegerConstant)typeOperand;
/* 127 */         return typeConstant.getNumberValue().intValue();
/*     */       } 
/*     */     } 
/* 130 */     return -1;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/SetTypeRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */