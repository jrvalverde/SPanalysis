/*    */ package org.renjin.gnur;
/*    */ 
/*    */ import org.renjin.gcc.analysis.FunctionBodyTransformer;
/*    */ import org.renjin.gcc.gimple.GimpleBasicBlock;
/*    */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*    */ import org.renjin.gcc.gimple.GimpleFunction;
/*    */ import org.renjin.gcc.gimple.statement.GimpleCall;
/*    */ import org.renjin.gcc.gimple.statement.GimpleStatement;
/*    */ import org.renjin.gcc.logging.LogManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutationRewriter
/*    */   implements FunctionBodyTransformer
/*    */ {
/* 31 */   private final ApiOracle apiOracle = new ApiOracle();
/*    */ 
/*    */   
/*    */   public boolean transform(LogManager logManager, GimpleCompilationUnit unit, GimpleFunction fn) {
/* 35 */     for (GimpleBasicBlock basicBlock : fn.getBasicBlocks()) {
/* 36 */       for (GimpleStatement statement : basicBlock.getStatements()) {
/* 37 */         if (statement instanceof GimpleCall) {
/* 38 */           GimpleCall call = (GimpleCall)statement;
/* 39 */           if (isDangerousMutation(call)) {
/* 40 */             logManager.warning(String.format("Call to %s discards result in %s at %s:%d", new Object[] { call
/* 41 */                     .getFunctionName(), fn
/* 42 */                     .getName(), call
/* 43 */                     .getSourceFile(), call
/* 44 */                     .getLineNumber() }));
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   private boolean isDangerousMutation(GimpleCall call) {
/* 53 */     return (this.apiOracle.isPotentialMutator(call.getFunctionName()) && call
/* 54 */       .getLhs() == null);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/MutationRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */