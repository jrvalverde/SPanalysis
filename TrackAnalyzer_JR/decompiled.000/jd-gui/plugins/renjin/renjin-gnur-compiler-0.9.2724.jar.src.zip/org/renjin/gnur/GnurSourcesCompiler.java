/*     */ package org.renjin.gnur;
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.math.special.Erf;
/*     */ import org.renjin.gcc.Gcc;
/*     */ import org.renjin.gcc.GccException;
/*     */ import org.renjin.gcc.GimpleCompiler;
/*     */ import org.renjin.gcc.gimple.GimpleCompilationUnit;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Callbacks;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Fileio;
/*     */ import org.renjin.gnur.api.GetText;
/*     */ import org.renjin.gnur.api.GetX11Image;
/*     */ import org.renjin.gnur.api.Internal;
/*     */ import org.renjin.gnur.api.Memory;
/*     */ import org.renjin.gnur.api.Parse;
/*     */ import org.renjin.gnur.api.Print;
/*     */ import org.renjin.gnur.api.PrtUtil;
/*     */ import org.renjin.gnur.api.QuartzDevice;
/*     */ import org.renjin.gnur.api.RStartup;
/*     */ import org.renjin.gnur.api.Random;
/*     */ import org.renjin.gnur.api.Rconnections;
/*     */ import org.renjin.gnur.api.Rdynload;
/*     */ import org.renjin.gnur.api.RenjinDebug;
/*     */ import org.renjin.gnur.api.RenjinFiles;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.gnur.api.Startup;
/*     */ import org.renjin.gnur.api.Utils;
/*     */ import org.renjin.gnur.api.eventloop;
/*     */ import org.renjin.gnur.api.rlocale;
/*     */ import org.renjin.gnur.api.stats_package;
/*     */ import org.renjin.gnur.api.stats_stubs;
/*     */ import org.renjin.primitives.packaging.DllInfo;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ public class GnurSourcesCompiler {
/*     */   private String packageName;
/*  43 */   private List<File> sources = Lists.newArrayList(); private String className; private boolean verbose = true;
/*  44 */   private File gimpleDirectory = new File("target/gimple");
/*     */   private File workDirectory;
/*  46 */   private File outputDirectory = new File("target/classes");
/*  47 */   private List<File> includeDirs = Lists.newArrayList();
/*  48 */   private ClassLoader linkClassLoader = getClass().getClassLoader();
/*     */   private File loggingDir;
/*     */   private boolean transformGlobalVariables;
/*     */   
/*     */   public void setPackageName(String packageName) {
/*  53 */     this.packageName = packageName;
/*     */   }
/*     */   
/*     */   public void setClassName(String className) {
/*  57 */     this.className = className;
/*     */   }
/*     */   
/*     */   public void setGimpleDirectory(File gimpleDirectory) {
/*  61 */     this.gimpleDirectory = gimpleDirectory;
/*     */   }
/*     */   
/*     */   public void setOutputDirectory(File outputDirectory) {
/*  65 */     this.outputDirectory = outputDirectory;
/*     */   }
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/*  69 */     this.verbose = verbose;
/*     */   }
/*     */   
/*     */   public void setWorkDirectory(File workDir) {
/*  73 */     this.workDirectory = workDir;
/*     */   }
/*     */   
/*     */   public void setLoggingDir(File loggingDir) {
/*  77 */     this.loggingDir = loggingDir;
/*     */   }
/*     */   
/*     */   public void addSources(File src) {
/*  81 */     if (src.exists() && src.listFiles() != null) {
/*  82 */       for (File file : src.listFiles()) {
/*  83 */         if (isSourceFile(file.getName())) {
/*  84 */           this.sources.add(file);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTransformGlobalVariables(boolean transformGlobalVariables) {
/*  91 */     this.transformGlobalVariables = transformGlobalVariables;
/*     */   }
/*     */   
/*     */   private boolean isSourceFile(String name) {
/*  95 */     return (name.endsWith(".c") || name.endsWith(".cpp") || name
/*  96 */       .toLowerCase().endsWith(".f") || name.toLowerCase().endsWith(".f90") || name
/*  97 */       .toLowerCase().endsWith(".f95") || name.toLowerCase().endsWith(".f03") || name
/*  98 */       .toLowerCase().endsWith(".for"));
/*     */   }
/*     */   
/*     */   public void setLinkClassLoader(ClassLoader linkClassLoader) {
/* 102 */     this.linkClassLoader = linkClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void compile() throws Exception {
/* 107 */     if (!this.sources.isEmpty()) {
/*     */       
/* 109 */       this.workDirectory.mkdirs();
/* 110 */       this.gimpleDirectory.mkdirs();
/*     */       
/* 112 */       if (checkUpToDate()) {
/*     */         return;
/*     */       }
/*     */       
/* 116 */       File gnurHomeDir = GnurInstallation.unpackRHome(Files.createTempDir());
/*     */       
/* 118 */       List<GimpleCompilationUnit> units = Lists.newArrayList();
/*     */       
/* 120 */       Gcc gcc = new Gcc(getWorkDirectory());
/* 121 */       gcc.extractPlugin();
/* 122 */       gcc.addIncludeDirectory(new File(gnurHomeDir, "include"));
/* 123 */       for (File includeDir : this.includeDirs) {
/* 124 */         gcc.addIncludeDirectory(includeDir);
/*     */       }
/* 126 */       gcc.setGimpleOutputDir(this.gimpleDirectory);
/*     */       
/* 128 */       for (File sourceFile : this.sources) {
/*     */         GimpleCompilationUnit unit;
/*     */         try {
/* 131 */           unit = gcc.compileToGimple(sourceFile, new String[] { "-std=gnu99" });
/* 132 */         } catch (Exception e) {
/* 133 */           throw new GccException("Error compiling " + sourceFile + " to gimple: " + e.getMessage(), e);
/*     */         } 
/*     */         
/*     */         try {
/* 137 */           units.add(unit);
/* 138 */         } catch (Exception e) {
/* 139 */           throw new RuntimeException("Exception parsing unit output of " + sourceFile, e);
/*     */         } 
/*     */       } 
/*     */       
/* 143 */       File jimpleOutput = new File("target/jimple");
/* 144 */       jimpleOutput.mkdirs();
/*     */       
/* 146 */       GimpleCompiler compiler = new GimpleCompiler();
/* 147 */       compiler.setOutputDirectory(this.outputDirectory);
/* 148 */       compiler.setPackageName(this.packageName);
/* 149 */       compiler.setClassName(this.className);
/* 150 */       compiler.setVerbose(this.verbose);
/*     */       
/* 152 */       compiler.setLinkClassLoader(this.linkClassLoader);
/* 153 */       compiler.addMathLibrary();
/*     */       
/* 155 */       setupCompiler(compiler);
/*     */       
/* 157 */       if (this.transformGlobalVariables) {
/* 158 */         compiler.addPlugin(new GlobalVarPlugin(compiler.getPackageName()));
/*     */       }
/*     */       
/* 161 */       compiler.setLoggingDirectory(this.loggingDir);
/*     */       
/* 163 */       compiler.compile(units);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setupCompiler(GimpleCompiler compiler) throws ClassNotFoundException {
/* 168 */     compiler.addReferenceClass(Class.forName("org.renjin.appl.Appl"));
/* 169 */     compiler.addReferenceClass(Class.forName("org.renjin.math.Blas"));
/* 170 */     Class<?> distributionsClass = Class.forName("org.renjin.stats.internals.Distributions");
/* 171 */     compiler.addReferenceClass(distributionsClass);
/* 172 */     compiler.addMethod("Rf_dbeta", distributionsClass, "dbeta");
/* 173 */     compiler.addMethod("Rf_pbeta", distributionsClass, "pbeta");
/* 174 */     compiler.addMethod("erf", Erf.class, "erf");
/* 175 */     compiler.addMethod("erfc", Erf.class, "erfc");
/* 176 */     compiler.addReferenceClass(Arith.class);
/* 177 */     compiler.addReferenceClass(Callbacks.class);
/* 178 */     compiler.addReferenceClass(Defn.class);
/* 179 */     compiler.addReferenceClass(Error.class);
/* 180 */     compiler.addReferenceClass(eventloop.class);
/* 181 */     compiler.addReferenceClass(Fileio.class);
/* 182 */     compiler.addReferenceClass(GetText.class);
/* 183 */     compiler.addReferenceClass(GetX11Image.class);
/* 184 */     compiler.addReferenceClass(Internal.class);
/* 185 */     compiler.addReferenceClass(Memory.class);
/* 186 */     compiler.addReferenceClass(Parse.class);
/* 187 */     compiler.addReferenceClass(Print.class);
/* 188 */     compiler.addReferenceClass(PrtUtil.class);
/* 189 */     compiler.addReferenceClass(QuartzDevice.class);
/* 190 */     compiler.addReferenceClass(R.class);
/* 191 */     compiler.addReferenceClass(R_ftp_http.class);
/* 192 */     compiler.addReferenceClass(Sort.class);
/* 193 */     compiler.addReferenceClass(Random.class);
/* 194 */     compiler.addReferenceClass(Rconnections.class);
/* 195 */     compiler.addReferenceClass(Rdynload.class);
/* 196 */     compiler.addReferenceClass(RenjinDebug.class);
/* 197 */     compiler.addReferenceClass(Rgraphics.class);
/* 198 */     compiler.addReferenceClass(Riconv.class);
/* 199 */     compiler.addReferenceClass(Rinterface.class);
/* 200 */     compiler.addReferenceClass(Rinternals.class);
/* 201 */     compiler.addReferenceClass(Rinternals2.class);
/* 202 */     compiler.addReferenceClass(rlocale.class);
/* 203 */     compiler.addReferenceClass(Rmath.class);
/* 204 */     compiler.addReferenceClass(RStartup.class);
/* 205 */     compiler.addReferenceClass(S.class);
/* 206 */     compiler.addReferenceClass(Startup.class);
/* 207 */     compiler.addReferenceClass(stats_package.class);
/* 208 */     compiler.addReferenceClass(stats_stubs.class);
/* 209 */     compiler.addReferenceClass(Utils.class);
/*     */     
/* 211 */     compiler.addRecordClass("SEXPREC", SEXP.class);
/*     */     
/* 213 */     compiler.addReferenceClass(Rdynload.class);
/* 214 */     compiler.addRecordClass("_DllInfo", DllInfo.class);
/* 215 */     compiler.addReferenceClass(RenjinFiles.class);
/*     */     
/* 217 */     compiler.addTransformer(new SetTypeRewriter());
/* 218 */     compiler.addTransformer(new MutationRewriter());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkUpToDate() {
/* 223 */     if (sourcesLastModified() < classLastModified()) {
/* 224 */       System.out.println(this.packageName + "." + this.className + "  is up to date, skipping GNU R sources compilation");
/* 225 */       return true;
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long classLastModified() {
/* 233 */     File classFile = new File(this.outputDirectory.getAbsolutePath() + File.separator + this.packageName.replace('.', File.separatorChar) + File.separator + this.className + ".class");
/*     */     
/* 235 */     System.out.println("class file (" + classFile.getAbsolutePath() + ") last modified on " + new Date(classFile.lastModified()));
/* 236 */     return classFile.lastModified();
/*     */   }
/*     */   
/*     */   private long sourcesLastModified() {
/* 240 */     long lastModified = 0L;
/* 241 */     for (File source : this.sources) {
/* 242 */       if (source.lastModified() > lastModified) {
/* 243 */         lastModified = source.lastModified();
/*     */       }
/*     */     } 
/* 246 */     System.out.println("sources last modified: " + lastModified);
/*     */     
/* 248 */     return lastModified;
/*     */   }
/*     */   
/*     */   private File getWorkDirectory() {
/* 252 */     if (this.workDirectory == null) {
/* 253 */       this.workDirectory = Files.createTempDir();
/*     */     }
/* 255 */     return this.workDirectory;
/*     */   }
/*     */   
/*     */   public void addIncludeDir(File includeDirectory) {
/* 259 */     this.includeDirs.add(includeDirectory);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/renjin-gnur-compiler-0.9.2724.jar!/org/renjin/gnur/GnurSourcesCompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */