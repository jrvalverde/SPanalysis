/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.LogicalVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogicalPrinter
/*    */   implements ColumnPrinter
/*    */ {
/*    */   private PrintWriter writer;
/*    */   private LogicalVector vector;
/*    */   private String naSymbol;
/*    */   
/*    */   public LogicalPrinter(PrintWriter writer, LogicalVector vector, String naSymbol) {
/* 33 */     this.writer = writer;
/* 34 */     this.vector = vector;
/* 35 */     this.naSymbol = naSymbol;
/*    */   }
/*    */ 
/*    */   
/*    */   public void print(int index) {
/* 40 */     int value = this.vector.getElementAsRawLogical(index);
/* 41 */     if (IntVector.isNA(value)) {
/* 42 */       this.writer.write(this.naSymbol);
/* 43 */     } else if (value == 0) {
/* 44 */       this.writer.write("FALSE");
/*    */     } else {
/* 46 */       this.writer.write("TRUE");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/LogicalPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */