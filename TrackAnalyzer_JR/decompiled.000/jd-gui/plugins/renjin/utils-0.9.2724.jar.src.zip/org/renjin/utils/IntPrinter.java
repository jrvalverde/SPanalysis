/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.renjin.sexp.IntVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntPrinter
/*    */   implements ColumnPrinter
/*    */ {
/*    */   private PrintWriter writer;
/*    */   private IntVector vector;
/*    */   private String naSymbol;
/*    */   
/*    */   public IntPrinter(PrintWriter writer, IntVector vector, String naSymbol) {
/* 32 */     this.writer = writer;
/* 33 */     this.vector = vector;
/* 34 */     this.naSymbol = naSymbol;
/*    */   }
/*    */ 
/*    */   
/*    */   public void print(int index) {
/* 39 */     int value = this.vector.getElementAsInt(index);
/* 40 */     if (IntVector.isNA(value)) {
/* 41 */       this.writer.write(this.naSymbol);
/*    */     } else {
/* 43 */       this.writer.print(value);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/IntPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */