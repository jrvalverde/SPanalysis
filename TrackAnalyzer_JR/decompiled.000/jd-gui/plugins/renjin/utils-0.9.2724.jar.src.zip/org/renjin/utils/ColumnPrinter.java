package org.renjin.utils;

public interface ColumnPrinter {
  void print(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/ColumnPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */