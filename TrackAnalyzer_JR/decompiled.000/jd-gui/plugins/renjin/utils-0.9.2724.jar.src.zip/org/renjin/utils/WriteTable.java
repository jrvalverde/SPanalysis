/*     */ package org.renjin.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.List;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.primitives.io.connections.Connection;
/*     */ import org.renjin.primitives.io.connections.Connections;
/*     */ import org.renjin.repackaged.guava.collect.Lists;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntVector;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.Logical;
/*     */ import org.renjin.sexp.LogicalVector;
/*     */ import org.renjin.sexp.Null;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WriteTable
/*     */ {
/*     */   public static void write(@Current Context context, ListVector dataFrame, SEXP connHandle, int numRows, int numColumns, Vector rowNames, String sep, String eol, String na, String dec, SEXP quote, SEXP quoteMethod) throws IOException {
/*  53 */     Connection connection = Connections.getConnection(context, connHandle);
/*  54 */     PrintWriter writer = connection.getPrintWriter();
/*     */ 
/*     */     
/*  57 */     List<ColumnPrinter> printers = Lists.newArrayList();
/*     */     
/*  59 */     if (rowNames != Null.INSTANCE)
/*     */     {
/*  61 */       printers.add(new StringPrinter(writer, (StringVector)rowNames, isColumnQuoted(quote, 0), na));
/*     */     }
/*     */     int i;
/*  64 */     for (i = 0; i < dataFrame.length(); i++) {
/*     */       
/*  66 */       SEXP column = dataFrame.getElementAsSEXP(i);
/*     */       
/*  68 */       if (column instanceof StringVector) {
/*  69 */         printers.add(new StringPrinter(writer, (StringVector)column, isColumnQuoted(quote, i), na));
/*     */       }
/*  71 */       else if (column instanceof IntVector) {
/*  72 */         if (column.inherits("factor")) {
/*  73 */           printers.add(new FactorPrinter(writer, (IntVector)column, isColumnQuoted(quote, i), na));
/*     */         } else {
/*  75 */           printers.add(new IntPrinter(writer, (IntVector)column, na));
/*     */         } 
/*  77 */       } else if (column instanceof DoubleVector) {
/*  78 */         printers.add(new DoublePrinter(writer, (DoubleVector)column, dec, na));
/*     */       }
/*  80 */       else if (column instanceof LogicalVector) {
/*  81 */         printers.add(new LogicalPrinter(writer, (LogicalVector)column, na));
/*     */       } else {
/*  83 */         throw new EvalException("Unsupported column type " + column.getTypeName(), new Object[0]);
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     for (i = 0; i != numRows; i++) {
/*  88 */       for (int j = 0; j != printers.size(); j++) {
/*  89 */         if (j > 0) {
/*  90 */           writer.print(sep);
/*     */         }
/*  92 */         ((ColumnPrinter)printers.get(j)).print(i);
/*     */       } 
/*  94 */       writer.print(eol);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isColumnQuoted(SEXP quote, int index) {
/* 100 */     if (quote instanceof LogicalVector) {
/* 101 */       return (((LogicalVector)quote).getElementAsLogical(0) == Logical.TRUE);
/*     */     }
/*     */     
/* 104 */     if (quote instanceof IntVector) {
/* 105 */       int[] columns = ((IntVector)quote).toIntArray();
/* 106 */       for (int i = 0; i < columns.length; i++) {
/* 107 */         if (columns[i] == index + 1) {
/* 108 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 112 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/WriteTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */