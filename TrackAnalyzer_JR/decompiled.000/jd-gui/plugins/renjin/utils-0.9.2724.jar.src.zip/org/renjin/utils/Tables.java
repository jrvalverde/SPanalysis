/*     */ package org.renjin.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.renjin.eval.Context;
/*     */ import org.renjin.invoke.annotations.Current;
/*     */ import org.renjin.parser.NumericLiterals;
/*     */ import org.renjin.primitives.io.connections.Connections;
/*     */ import org.renjin.primitives.io.connections.PushbackBufferedReader;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.collect.Maps;
/*     */ import org.renjin.repackaged.guava.collect.Sets;
/*     */ import org.renjin.sexp.DoubleArrayVector;
/*     */ import org.renjin.sexp.DoubleVector;
/*     */ import org.renjin.sexp.IntArrayVector;
/*     */ import org.renjin.sexp.LogicalArrayVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ import org.renjin.sexp.StringVector;
/*     */ import org.renjin.sexp.Symbols;
/*     */ import org.renjin.sexp.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tables
/*     */ {
/*     */   public static StringVector readtablehead(@Current Context context, SEXP conn, double nLines, String commentChar, boolean blankLinesSkip, String quote, String sep, boolean skipNul) throws IOException {
/*  43 */     PushbackBufferedReader reader = Connections.getConnection(context, conn).getReader();
/*     */     
/*  45 */     StringVector.Builder head = new StringVector.Builder();
/*     */     String line;
/*  47 */     while (nLines > 0.0D && (line = reader.readLine()) != null) {
/*  48 */       if (commentChar.isEmpty() || !line.startsWith(commentChar)) {
/*  49 */         head.add(line);
/*  50 */         nLines--;
/*     */       } 
/*     */     } 
/*  53 */     return (StringVector)head.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector typeconvert(StringVector vector, StringVector naStrings, boolean asIs, String dec, String numerals) {
/*  84 */     Set<String> naSet = createHashSet(naStrings);
/*  85 */     Converter<?> converter = getConverter(vector, naSet, dec.charAt(0));
/*  86 */     if (converter != null)
/*  87 */       return converter.build(vector, naSet); 
/*  88 */     if (asIs) {
/*  89 */       return (Vector)vector;
/*     */     }
/*  91 */     return buildFactor(vector, naSet);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<String> createHashSet(StringVector strings) {
/*  96 */     HashSet<String> set = Sets.newHashSet();
/*     */     
/*  98 */     for (int i = 0; i < strings.length(); i++) {
/*  99 */       String element = strings.getElementAsString(i);
/* 100 */       if (!Strings.isNullOrEmpty(element)) {
/* 101 */         set.add(element);
/*     */       }
/*     */     } 
/*     */     
/* 105 */     return set;
/*     */   }
/*     */   
/*     */   private static Vector buildFactor(StringVector vector, Set<String> naStrings) {
/* 109 */     String[] strings = vector.toArray();
/* 110 */     String[] unique = (String[])Arrays.<String>stream(strings).distinct().toArray(x$0 -> new String[x$0]);
/* 111 */     Arrays.sort((Object[])unique);
/*     */     
/* 113 */     Map<String, Integer> codes = Maps.newHashMap();
/* 114 */     StringVector.Builder levels = StringVector.newBuilder();
/* 115 */     for (int i = 0; i < unique.length; i++) {
/* 116 */       codes.put(unique[i], Integer.valueOf(i + 1));
/* 117 */       levels.set(i, unique[i]);
/*     */     } 
/*     */     
/* 120 */     IntArrayVector.Builder factor = new IntArrayVector.Builder(vector.length());
/* 121 */     for (int j = 0; j != vector.length(); j++) {
/* 122 */       String element = vector.getElementAsString(j);
/* 123 */       if (!isNa(element, naStrings)) {
/* 124 */         factor.set(j, ((Integer)codes.get(element)).intValue());
/*     */       }
/*     */     } 
/*     */     
/* 128 */     factor.setAttribute(Symbols.CLASS, (SEXP)StringVector.valueOf("factor"));
/* 129 */     factor.setAttribute(Symbols.LEVELS, (SEXP)levels.build());
/* 130 */     return (Vector)factor.build();
/*     */   }
/*     */   
/*     */   private static boolean isNa(String string, Set<String> naStrings) {
/* 134 */     return (Strings.isNullOrEmpty(string) || naStrings.contains(string));
/*     */   }
/*     */   
/*     */   private static Converter<?> getConverter(StringVector vector, Set<String> naStrings, char decimal) {
/* 138 */     Converter[] arrayOfConverter = { new LogicalConverter(), new IntConverter(), new DoubleConverter(decimal) };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     for (Converter<?> converter : arrayOfConverter) {
/* 144 */       if (converter.accept(vector, naStrings)) {
/* 145 */         return converter;
/*     */       }
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static abstract class Converter<BuilderT extends Vector.Builder>
/*     */   {
/*     */     private Converter() {}
/*     */ 
/*     */     
/*     */     public boolean accept(StringVector vector, Set<String> naStrings) {
/* 158 */       for (int i = 0; i != vector.length(); i++) {
/* 159 */         String element = vector.getElementAsString(i);
/* 160 */         if (!Tables.isNa(element, naStrings) && !accept(element)) {
/* 161 */           return false;
/*     */         }
/*     */       } 
/* 164 */       return true;
/*     */     }
/*     */     
/*     */     public Vector build(StringVector vector, Set<String> naStrings) {
/* 168 */       BuilderT builder = newBuilder(vector.length());
/* 169 */       for (int i = 0; i != vector.length(); i++) {
/* 170 */         String element = vector.getElementAsString(i);
/* 171 */         if (!Tables.isNa(element, naStrings)) {
/* 172 */           set(builder, i, element);
/*     */         }
/*     */       } 
/* 175 */       return builder.build();
/*     */     }
/*     */     abstract boolean accept(String param1String);
/*     */     abstract BuilderT newBuilder(int param1Int);
/*     */     
/*     */     abstract void set(BuilderT param1BuilderT, int param1Int, String param1String); }
/*     */   
/*     */   private static class LogicalConverter extends Converter<LogicalArrayVector.Builder> { public boolean accept(String string) {
/* 183 */       return (string.equals("T") || string.equals("F") || string.equals("TRUE") || string.equals("FALSE"));
/*     */     }
/*     */     private LogicalConverter() {}
/*     */     public void set(LogicalArrayVector.Builder builder, int index, String string) {
/* 187 */       if (string.equals("T") || string.equals("TRUE")) {
/* 188 */         builder.set(index, true);
/*     */       } else {
/* 190 */         builder.set(index, false);
/*     */       } 
/*     */     }
/*     */     
/*     */     LogicalArrayVector.Builder newBuilder(int length) {
/* 195 */       return new LogicalArrayVector.Builder(length);
/*     */     } }
/*     */   
/*     */   private static class IntConverter extends Converter<IntArrayVector.Builder> {
/*     */     private IntConverter() {}
/*     */     
/*     */     public boolean accept(String string) {
/*     */       try {
/* 203 */         double doubleValue = NumericLiterals.parseDouble(string);
/* 204 */         int intValue = (int)doubleValue;
/* 205 */         return (intValue == doubleValue);
/*     */       }
/* 207 */       catch (Exception e) {
/* 208 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(IntArrayVector.Builder builder, int index, String string) {
/* 214 */       builder.set(index, NumericLiterals.parseInt(string));
/*     */     }
/*     */ 
/*     */     
/*     */     public IntArrayVector.Builder newBuilder(int length) {
/* 219 */       return new IntArrayVector.Builder(length);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DoubleConverter
/*     */     extends Converter<DoubleArrayVector.Builder> {
/*     */     private final char decimal;
/*     */     
/*     */     public DoubleConverter(char decimal) {
/* 228 */       this.decimal = decimal;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean accept(String string) {
/*     */       try {
/* 234 */         return !DoubleVector.isNA(NumericLiterals.parseDouble(string, 0, string.length(), this.decimal, false));
/* 235 */       } catch (Exception e) {
/* 236 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void set(DoubleArrayVector.Builder builder, int index, String string) {
/* 241 */       builder.set(index, NumericLiterals.parseDouble(string, 0, string.length(), this.decimal, false));
/*     */     }
/*     */     
/*     */     DoubleArrayVector.Builder newBuilder(int length) {
/* 245 */       return new DoubleArrayVector.Builder(length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/Tables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */