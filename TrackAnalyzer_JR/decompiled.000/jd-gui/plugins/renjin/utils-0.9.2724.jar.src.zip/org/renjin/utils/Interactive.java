/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.renjin.eval.Context;
/*    */ import org.renjin.invoke.annotations.Current;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Interactive
/*    */ {
/*    */   public static int menu(@Current Context context, StringVector choices) throws IOException {
/* 31 */     return context.getSession().getSessionController().menu(choices);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/Interactive.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */