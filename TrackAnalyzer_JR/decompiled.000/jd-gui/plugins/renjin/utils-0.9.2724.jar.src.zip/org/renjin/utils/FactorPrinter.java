/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.AtomicVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ import org.renjin.sexp.Symbols;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FactorPrinter
/*    */   implements ColumnPrinter
/*    */ {
/*    */   private PrintWriter writer;
/*    */   private IntVector vector;
/*    */   private String naSymbol;
/*    */   private String[] levels;
/*    */   
/*    */   public FactorPrinter(PrintWriter writer, IntVector vector, boolean quote, String naSymbol) {
/* 38 */     this.writer = writer;
/* 39 */     this.vector = vector;
/* 40 */     this.naSymbol = naSymbol;
/* 41 */     this.levels = formatLevels(vector, quote);
/*    */   }
/*    */   
/*    */   private String[] formatLevels(IntVector vector, boolean quote) {
/* 45 */     SEXP attribute = vector.getAttribute(Symbols.LEVELS);
/* 46 */     if (!(attribute instanceof AtomicVector)) {
/* 47 */       throw new EvalException("Expected 'levels' attribute of type character", new Object[0]);
/*    */     }
/* 49 */     AtomicVector levelsVector = (AtomicVector)attribute;
/* 50 */     String[] levels = new String[levelsVector.length()];
/* 51 */     for (int i = 0; i != levelsVector.length(); i++) {
/* 52 */       if (quote) {
/* 53 */         levels[i] = "\"" + levelsVector.getElementAsString(i) + "\"";
/*    */       } else {
/* 55 */         levels[i] = levelsVector.getElementAsString(i);
/*    */       } 
/*    */     } 
/* 58 */     return levels;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void print(int index) {
/* 64 */     int valueIndex = this.vector.getElementAsInt(index);
/* 65 */     if (IntVector.isNA(valueIndex) || valueIndex > this.levels.length) {
/* 66 */       this.writer.write(this.naSymbol);
/*    */     } else {
/* 68 */       this.writer.write(this.levels[valueIndex - 1]);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/FactorPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */