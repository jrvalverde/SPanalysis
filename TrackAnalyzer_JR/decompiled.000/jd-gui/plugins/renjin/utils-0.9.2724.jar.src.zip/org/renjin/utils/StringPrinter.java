/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import org.renjin.sexp.StringVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringPrinter
/*    */   implements ColumnPrinter
/*    */ {
/*    */   private PrintWriter writer;
/*    */   private StringVector vector;
/*    */   private boolean quote;
/*    */   private String naSymbol;
/*    */   
/*    */   public StringPrinter(PrintWriter writer, StringVector vector, boolean quote, String naSymbol) {
/* 34 */     this.writer = writer;
/* 35 */     this.vector = vector;
/* 36 */     this.quote = quote;
/* 37 */     this.naSymbol = naSymbol;
/*    */   }
/*    */ 
/*    */   
/*    */   public void print(int index) {
/* 42 */     String value = this.vector.getElementAsString(index);
/* 43 */     if (value == null) {
/* 44 */       this.writer.write(this.naSymbol);
/*    */     } else {
/* 46 */       if (this.quote) {
/* 47 */         this.writer.write(34);
/*    */       }
/* 49 */       this.writer.write(value);
/* 50 */       if (this.quote)
/* 51 */         this.writer.write(34); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/StringPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */