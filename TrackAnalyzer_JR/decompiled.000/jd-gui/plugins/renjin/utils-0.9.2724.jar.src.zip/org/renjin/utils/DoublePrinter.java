/*    */ package org.renjin.utils;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.DecimalFormatSymbols;
/*    */ import org.renjin.sexp.DoubleVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoublePrinter
/*    */   implements ColumnPrinter
/*    */ {
/*    */   private final PrintWriter writer;
/*    */   private final DoubleVector vector;
/*    */   private String naSymbol;
/*    */   private final DecimalFormat format;
/*    */   
/*    */   public DoublePrinter(PrintWriter writer, DoubleVector vector, String decimal, String naSymbol) {
/* 36 */     this.writer = writer;
/* 37 */     this.vector = vector;
/* 38 */     this.naSymbol = naSymbol;
/*    */     
/* 40 */     DecimalFormatSymbols symbols = new DecimalFormatSymbols();
/* 41 */     symbols.setDecimalSeparator(decimal.charAt(0));
/*    */     
/* 43 */     this.format = new DecimalFormat();
/* 44 */     this.format.setGroupingUsed(false);
/* 45 */     this.format.setDecimalFormatSymbols(symbols);
/* 46 */     this.format.setMinimumIntegerDigits(0);
/* 47 */     this.format.setMaximumFractionDigits(6);
/*    */   }
/*    */ 
/*    */   
/*    */   public void print(int rowNumber) {
/* 52 */     double value = this.vector.getElementAsDouble(rowNumber);
/* 53 */     if (DoubleVector.isNA(value)) {
/* 54 */       this.writer.write(this.naSymbol);
/*    */     } else {
/* 56 */       this.writer.write(this.format.format(value));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/utils-0.9.2724.jar!/org/renjin/utils/DoublePrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */