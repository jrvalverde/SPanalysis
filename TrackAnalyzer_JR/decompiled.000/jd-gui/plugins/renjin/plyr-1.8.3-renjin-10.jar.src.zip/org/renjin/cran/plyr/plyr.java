/*    */ package org.renjin.cran.plyr;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import org.renjin.eval.EvalException;
/*    */ import org.renjin.sexp.IntArrayVector;
/*    */ import org.renjin.sexp.IntVector;
/*    */ import org.renjin.sexp.ListVector;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class plyr
/*    */ {
/*    */   public static ListVector plyr_split_indices(IntVector group, int n) {
/* 37 */     if (n < 0) throw new EvalException("n must be a positive integer", new Object[0]);
/*    */     
/* 39 */     List<IntArrayVector.Builder> ids = Lists.newArrayListWithCapacity(n);
/*    */     
/* 41 */     for (int i = 0; i < group.length(); i++) {
/*    */       
/* 43 */       int groupIndex = group.getElementAsInt(i) - 1;
/*    */       
/* 45 */       while (ids.size() <= groupIndex) {
/* 46 */         ids.add(new IntArrayVector.Builder());
/*    */       }
/* 48 */       ((IntArrayVector.Builder)ids.get(groupIndex)).add(i + 1);
/*    */     } 
/*    */     
/* 51 */     ListVector.Builder list = new ListVector.Builder(0, ids.size());
/* 52 */     for (int j = 0; j < ids.size(); j++) {
/* 53 */       list.add((SEXP)((IntArrayVector.Builder)ids.get(j)).build());
/*    */     }
/*    */     
/* 56 */     return list.build();
/*    */   }
/*    */   
/*    */   public static ListVector plyr_split_indices(IntVector group, double n) {
/* 60 */     return plyr_split_indices(group, (int)n);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/plyr-1.8.3-renjin-10.jar!/org/renjin/cran/plyr/plyr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */