/*    */ package org.renjin.gcc.format;
/*    */ 
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VarArgsInput
/*    */   implements FormatInput
/*    */ {
/*    */   private Formatter formatter;
/*    */   private Ptr argumentList;
/*    */   private int[] offsets;
/*    */   
/*    */   public VarArgsInput(Formatter formatter, Ptr argumentList) {
/* 29 */     this.formatter = formatter;
/* 30 */     this.argumentList = argumentList;
/* 31 */     this.offsets = new int[formatter.getArgumentTypes().size()];
/*    */     
/* 33 */     int offset = 0;
/* 34 */     for (int i = 0; i < this.offsets.length; i++) {
/* 35 */       this.offsets[i] = offset;
/* 36 */       switch (formatter.getArgumentType(i)) {
/*    */         case INTEGER:
/*    */         case POINTER:
/*    */         case STRING:
/* 40 */           offset += 4;
/*    */           break;
/*    */         case DOUBLE:
/* 43 */           offset += 8;
/*    */           break;
/*    */ 
/*    */         
/*    */         case LONG:
/* 48 */           offset += 8;
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isNA(int argumentIndex) {
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getInt(int argumentIndex) {
/* 62 */     return this.argumentList.getInt(this.offsets[argumentIndex]);
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLong(int argumentIndex) {
/* 67 */     return this.argumentList.getLong(this.offsets[argumentIndex]);
/*    */   }
/*    */ 
/*    */   
/*    */   public long getUnsignedLong(int argumentIndex) {
/* 72 */     return this.argumentList.getLong(this.offsets[argumentIndex]);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getDouble(int argumentIndex) {
/* 77 */     return this.argumentList.getDouble(this.offsets[argumentIndex]);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString(int argumentIndex) {
/* 82 */     return Stdlib.nullTerminatedString(this.argumentList.getPointer(this.offsets[argumentIndex]));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/format/VarArgsInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */