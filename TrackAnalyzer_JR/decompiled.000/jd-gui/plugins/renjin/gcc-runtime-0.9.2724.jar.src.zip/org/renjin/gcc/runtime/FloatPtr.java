/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   public static final int BYTES = 4;
/*  28 */   public static final FloatPtr NULL = new FloatPtr();
/*     */   
/*     */   public final float[] array;
/*     */   public final int offset;
/*     */   
/*     */   private FloatPtr() {
/*  34 */     this.array = null;
/*  35 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public FloatPtr(float[] array, int offset) {
/*  39 */     this.array = array;
/*  40 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public FloatPtr(float... values) {
/*  44 */     this.array = values;
/*  45 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static FloatPtr malloc(int bytes) {
/*  50 */     return new FloatPtr(new float[AbstractPtr.mallocSize(bytes, 4)]);
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getArray() {
/*  55 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  60 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  65 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  70 */     return new FloatPtr(Realloc.realloc(this.array, this.offset, mallocSize(newSizeInBytes, 4)));
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/*  75 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/*  80 */     return this.array[this.offset + offset / 4];
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/*  85 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/*  90 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/*  95 */     this.array[this.offset + offset / 4] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 100 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/* 105 */     if (bytes % 4 == 0) {
/* 106 */       return new FloatPtr(this.array, this.offset + bytes / 4);
/*     */     }
/* 108 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 114 */     return getByteViaFloat(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 119 */     setByteViaFloat(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 124 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 129 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */   
/*     */   public float unwrap() {
/* 138 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public float get(int i) {
/* 142 */     return this.array[this.offset + i];
/*     */   }
/*     */   
/*     */   public void set(int index, float value) {
/* 146 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(double[] str, int strOffset, int c, int n) {
/* 160 */     assert n % 4 == 0;
/*     */     
/* 162 */     float floatValue = memset(c);
/*     */     
/* 164 */     Arrays.fill(str, strOffset, strOffset + n / 4, floatValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float memset(int c) {
/* 171 */     return Float.intBitsToFloat(IntPtr.memset(c));
/*     */   }
/*     */   
/*     */   public static FloatPtr cast(Object voidPointer) {
/* 175 */     if (voidPointer instanceof MallocThunk) {
/* 176 */       return ((MallocThunk)voidPointer).floatPtr();
/*     */     }
/* 178 */     if (voidPointer == null) {
/* 179 */       return NULL;
/*     */     }
/* 181 */     return (FloatPtr)voidPointer;
/*     */   }
/*     */   
/*     */   public static void memcpy(FloatPtr x, FloatPtr y, int numBytes) {
/* 185 */     float[] arrayS = y.getArray();
/* 186 */     int offsetS = y.getOffset();
/* 187 */     int restY = arrayS.length - offsetS;
/* 188 */     if (restY > 0) {
/* 189 */       float[] carray = new float[numBytes];
/* 190 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 191 */         carray[i] = arrayS[j];
/*     */       }
/* 193 */       x = new FloatPtr(carray);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/FloatPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */