/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongFieldPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   private final Field field;
/*     */   
/*     */   public static Ptr addressOf(Class declaringClass, String fieldName) {
/*     */     try {
/*  37 */       return new LongFieldPtr(declaringClass.getField(fieldName));
/*  38 */     } catch (Exception e) {
/*  39 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public LongFieldPtr(Field field) {
/*  44 */     this.field = field;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  49 */     return this.field;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getOffsetInBytes() {
/*  54 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  59 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  64 */     if (bytes == 0) {
/*  65 */       return this;
/*     */     }
/*  67 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong() {
/*     */     try {
/*  74 */       return this.field.getLong(null);
/*  75 */     } catch (IllegalAccessException e) {
/*     */ 
/*     */       
/*  78 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/*     */     try {
/*  85 */       this.field.setLong(null, value);
/*  86 */     } catch (IllegalAccessException e) {
/*     */ 
/*     */       
/*  89 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/*  95 */     if (offset == 0) {
/*  96 */       return getLong();
/*     */     }
/*  98 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long intValue) {
/* 104 */     if (offset == 0) {
/* 105 */       setLong(intValue);
/*     */     } else {
/* 107 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 114 */     if (index == 0) {
/* 115 */       return getLong();
/*     */     }
/* 117 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 123 */     if (index == 0) {
/* 124 */       setLong(value);
/*     */     } else {
/* 126 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 132 */     return getByteViaLong(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 137 */     setByteViaLong(offset, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 143 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 148 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/LongFieldPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */