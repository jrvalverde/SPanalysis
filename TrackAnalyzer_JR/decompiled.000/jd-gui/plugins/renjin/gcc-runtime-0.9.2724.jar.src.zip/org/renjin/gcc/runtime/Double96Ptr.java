/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Double96Ptr
/*     */   extends AbstractPtr
/*     */ {
/*     */   public static final int BYTES = 12;
/*     */   private double[] array;
/*     */   private int offset;
/*     */   
/*     */   public Double96Ptr(double[] array, int offset) {
/*  29 */     this.array = array;
/*  30 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  35 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  40 */     return this.offset * 12;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  45 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  50 */     if (bytes % 12 == 0) {
/*  51 */       return new Double96Ptr(this.array, this.offset + bytes / 12);
/*     */     }
/*  53 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  59 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  64 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96() {
/*  69 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/*  74 */     if (offset % 12 == 0) {
/*  75 */       return this.array[this.offset + offset / 12];
/*     */     }
/*  77 */     return super.getReal96(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/*  83 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/*  88 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/*  93 */     if (offset % 12 == 0) {
/*  94 */       setAlignedReal96(this.offset + offset / 12, value);
/*     */     } else {
/*  96 */       super.setAlignedReal96(offset, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 102 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 107 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 112 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Double96Ptr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */