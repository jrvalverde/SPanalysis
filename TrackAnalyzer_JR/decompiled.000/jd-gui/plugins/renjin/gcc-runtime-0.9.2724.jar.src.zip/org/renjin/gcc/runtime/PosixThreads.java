/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PosixThreads
/*     */ {
/*     */   public static final int SUCCESS = 0;
/*     */   
/*     */   private static class PosixThread
/*     */     extends Thread
/*     */   {
/*     */     private MethodHandle startRoutine;
/*     */     private Ptr arg;
/*     */     private Ptr result;
/*     */     
/*     */     public PosixThread(MethodHandle startRoutine, Ptr arg) {
/*  44 */       this.startRoutine = startRoutine;
/*  45 */       this.arg = arg;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void start() {
/*     */       try {
/*  51 */         this.result = this.startRoutine.invoke(this.arg);
/*  52 */       } catch (Throwable throwable) {
/*  53 */         throwable.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*  58 */   private static final AtomicInteger NEXT_THREAD_ID = new AtomicInteger(0);
/*     */   
/*  60 */   private static final ConcurrentMap<Integer, PosixThread> THREAD_MAP = new ConcurrentHashMap<>();
/*     */   
/*     */   public static int pthread_attr_init(Ptr attr) {
/*  63 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_attr_destroy(Ptr attr) {
/*  67 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_create(Ptr thread, Ptr attr, MethodHandle startRoutine, Ptr arg) {
/*  71 */     PosixThread posixThread = new PosixThread(startRoutine, arg);
/*  72 */     posixThread.start();
/*     */     
/*  74 */     int threadId = NEXT_THREAD_ID.incrementAndGet();
/*     */     
/*  76 */     THREAD_MAP.put(Integer.valueOf(threadId), posixThread);
/*     */     
/*  78 */     thread.setInt(threadId);
/*     */     
/*  80 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int pthread_join(int threadId, Ptr valuePtr) {
/*  85 */     PosixThread posixThread = THREAD_MAP.get(Integer.valueOf(threadId));
/*     */     
/*     */     try {
/*  88 */       posixThread.join();
/*  89 */     } catch (InterruptedException e) {
/*  90 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  93 */     valuePtr.setPointer(posixThread.result);
/*     */     
/*  95 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutex_init(Ptr mutex, Ptr attr) {
/*  99 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutexattr_init(Ptr attr) {
/* 103 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int pthread_mutexattr_gettype(Ptr attr, Ptr type) {
/* 108 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public static int pthread_mutexattr_settype(Ptr attr, int type) {
/* 112 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int pthread_mutex_lock(Ptr mutex) {
/* 117 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutex_trylock(Ptr mutex) {
/* 121 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutex_unlock(Ptr mutex) {
/* 125 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutex_destroy(Ptr mutex) {
/* 129 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_mutexattr_destroy(Ptr attr) {
/* 133 */     return 0;
/*     */   }
/*     */   
/*     */   public static int pthread_once(Ptr onceControl, MethodHandle initRoutine) throws Throwable {
/* 137 */     synchronized (onceControl.getArray()) {
/* 138 */       if (onceControl.getInt(0) == 0) {
/* 139 */         onceControl.setInt(0, 1);
/* 140 */         initRoutine.invoke();
/*     */       } 
/*     */     } 
/* 143 */     return 0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/PosixThreads.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */