/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VoidPtr
/*     */ {
/*     */   public static int memcmp(Object x, Object y, int numBytes) {
/*  31 */     if (x instanceof DoublePtr && y instanceof DoublePtr) {
/*  32 */       return DoublePtr.memcmp((DoublePtr)x, (DoublePtr)y, numBytes);
/*     */     }
/*  34 */     if (x instanceof LongPtr && y instanceof LongPtr) {
/*  35 */       return LongPtr.memcmp((LongPtr)x, (LongPtr)y, numBytes);
/*     */     }
/*  37 */     if (x instanceof IntPtr && y instanceof IntPtr) {
/*  38 */       return IntPtr.memcmp((IntPtr)x, (IntPtr)y, numBytes);
/*     */     }
/*  40 */     throw new UnsupportedOperationException("Not implemented: memcmp(" + x
/*  41 */         .getClass().getName() + ", " + y.getClass().getName() + ", n)");
/*     */   }
/*     */   
/*     */   public static Object pointerPlus(Object p, int bytes) {
/*  45 */     if (p instanceof Ptr) {
/*  46 */       return ((Ptr)p).pointerPlus(bytes);
/*     */     }
/*  48 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void memcpy(Object x, Object y, int numBytes) {
/*  53 */     if (x instanceof DoublePtr && y instanceof DoublePtr) {
/*  54 */       DoublePtr.memcpy((DoublePtr)x, (DoublePtr)y, numBytes);
/*  55 */     } else if (x instanceof LongPtr && y instanceof LongPtr) {
/*  56 */       LongPtr.memcpy((LongPtr)x, (LongPtr)y, numBytes);
/*  57 */     } else if (x instanceof IntPtr && y instanceof IntPtr) {
/*  58 */       IntPtr.memcpy((IntPtr)x, (IntPtr)y, numBytes);
/*  59 */     } else if (x instanceof FloatPtr && y instanceof FloatPtr) {
/*  60 */       FloatPtr.memcpy((FloatPtr)x, (FloatPtr)y, numBytes);
/*  61 */     } else if (x instanceof CharPtr && y instanceof CharPtr) {
/*  62 */       CharPtr.memcpy((CharPtr)x, (CharPtr)y, numBytes);
/*  63 */     } else if (x instanceof BytePtr && y instanceof BytePtr) {
/*  64 */       BytePtr.memcpy((BytePtr)x, (BytePtr)y, numBytes);
/*     */     } else {
/*  66 */       throw new UnsupportedOperationException("Not implemented: memcpy(" + x
/*  67 */           .getClass().getName() + ", " + y.getClass().getName() + ", n)");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void memset(Object p, int value, int length) {
/*  73 */     if (p instanceof DoublePtr) {
/*  74 */       DoublePtr pd = (DoublePtr)p;
/*  75 */       DoublePtr.memset(pd.array, pd.offset, value, length);
/*  76 */     } else if (p instanceof BytePtr) {
/*  77 */       BytePtr pb = (BytePtr)p;
/*  78 */       BytePtr.memset(pb.array, pb.offset, value, length);
/*  79 */     } else if (p instanceof CharPtr) {
/*  80 */       CharPtr pc = (CharPtr)p;
/*  81 */       CharPtr.memset(pc.array, pc.offset, value, length);
/*  82 */     } else if (p instanceof ObjectPtr) {
/*  83 */       ObjectPtr po = (ObjectPtr)p;
/*  84 */       ObjectPtr.memset(po.array, po.offset, value, length);
/*     */     } else {
/*  86 */       throw new UnsupportedOperationException("TODO: p instanceof " + p.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(Object x, Object y) {
/*  97 */     if (x instanceof Ptr && y instanceof Ptr) {
/*     */       
/*  99 */       Ptr px = (Ptr)x;
/* 100 */       Ptr py = (Ptr)y;
/*     */       
/* 102 */       if (px.getArray() == py.getArray()) {
/* 103 */         return Integer.compare(px.getOffset(), py.getOffset());
/*     */       }
/*     */     } 
/*     */     
/* 107 */     return Integer.compare(System.identityHashCode(x), System.identityHashCode(y));
/*     */   }
/*     */   
/*     */   public static Ptr toPtr(Object voidPtr) {
/* 111 */     if (voidPtr == null) {
/* 112 */       return BytePtr.NULL;
/*     */     }
/* 114 */     if (voidPtr instanceof Ptr)
/* 115 */       return (Ptr)voidPtr; 
/* 116 */     if (voidPtr instanceof MethodHandle) {
/* 117 */       return FunctionPtr1.malloc((MethodHandle)voidPtr);
/*     */     }
/* 119 */     throw new UnsupportedOperationException("TODO: " + voidPtr.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assign(Object[] array, int offset, Object value) throws NoSuchMethodException {
/* 126 */     if (value instanceof MallocThunk && !array.getClass().equals(Object[].class)) {
/* 127 */       ((MallocThunk)value).assign(array, offset);
/*     */     } else {
/*     */       
/*     */       try {
/* 131 */         array[offset] = value;
/* 132 */       } catch (ArrayStoreException e) {
/* 133 */         throw new IllegalStateException("Exception storing value of class " + value
/* 134 */             .getClass().getName() + " to array of class " + array
/* 135 */             .getClass().getName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/VoidPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */