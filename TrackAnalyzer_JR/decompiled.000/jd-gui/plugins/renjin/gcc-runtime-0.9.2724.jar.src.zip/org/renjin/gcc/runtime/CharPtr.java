/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   public static final int BYTES = 2;
/*  27 */   public static final CharPtr NULL = new CharPtr();
/*     */   
/*     */   public final char[] array;
/*     */   public final int offset;
/*     */   
/*     */   private CharPtr() {
/*  33 */     this.array = null;
/*  34 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public CharPtr(char[] array, int offset) {
/*  38 */     this.array = array;
/*  39 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public CharPtr(char... array) {
/*  43 */     this.array = array;
/*  44 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getArray() {
/*  49 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  54 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  59 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public CharPtr realloc(int newSizeInBytes) {
/*  64 */     return new CharPtr(Realloc.realloc(this.array, this.offset, newSizeInBytes / 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  69 */     if (bytes % 2 == 0) {
/*  70 */       return new CharPtr(this.array, this.offset + bytes / 2);
/*     */     }
/*  72 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar() {
/*  78 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/*  83 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/*  88 */     if (offset % 2 == 0) {
/*  89 */       return this.array[this.offset + offset / 2];
/*     */     }
/*  91 */     return super.getChar(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/*  97 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 102 */     if (offset % 2 == 0) {
/* 103 */       this.array[this.offset + offset / 2] = value;
/*     */     } else {
/* 105 */       super.setChar(offset, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 111 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int byteIndex) {
/* 116 */     return getByteViaChar(byteIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 121 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 126 */     return this.offset * 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 131 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */   
/*     */   public static CharPtr fromString(String string) {
/* 135 */     int nchars = string.length();
/* 136 */     char[] array = new char[nchars + 1];
/* 137 */     System.arraycopy(string.toCharArray(), 0, array, 0, nchars);
/* 138 */     return new CharPtr(array);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */ 
/*     */   
/*     */   public String asString() {
/*     */     int length;
/* 149 */     for (length = this.offset; length < this.array.length && 
/* 150 */       this.array[length] != '\000'; length++);
/*     */ 
/*     */ 
/*     */     
/* 154 */     return new String(this.array, this.offset, length - this.offset);
/*     */   }
/*     */   
/*     */   public static CharPtr cast(Object voidPointer) {
/* 158 */     if (voidPointer instanceof MallocThunk) {
/* 159 */       return ((MallocThunk)voidPointer).charPtr();
/*     */     }
/* 161 */     if (voidPointer == null) {
/* 162 */       return NULL;
/*     */     }
/* 164 */     return (CharPtr)voidPointer;
/*     */   }
/*     */   
/*     */   public static void memset(char[] array, int offset, int value, int length) {
/* 168 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public static char memset(int byteValue) {
/* 172 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public static void memcpy(CharPtr x, CharPtr y, int numBytes) {
/* 176 */     char[] arrayS = y.getArray();
/* 177 */     int offsetS = y.getOffset();
/* 178 */     int restY = arrayS.length - offsetS;
/* 179 */     if (restY > 0) {
/* 180 */       char[] carray = new char[numBytes];
/* 181 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 182 */         carray[i] = arrayS[j];
/*     */       }
/* 184 */       x = new CharPtr(carray);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/CharPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */