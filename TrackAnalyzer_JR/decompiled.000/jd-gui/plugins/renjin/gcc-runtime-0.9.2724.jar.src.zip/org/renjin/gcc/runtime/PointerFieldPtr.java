/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointerFieldPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   private final Field field;
/*     */   
/*     */   public PointerFieldPtr(Field field) {
/*  28 */     this.field = field;
/*     */   }
/*     */   
/*     */   public static Ptr addressOf(Class declaringClass, String fieldName) {
/*     */     try {
/*  33 */       return new PointerFieldPtr(declaringClass.getField(fieldName));
/*  34 */     } catch (Exception e) {
/*  35 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  42 */     return this.field;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getOffsetInBytes() {
/*  47 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  52 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  57 */     if (bytes == 0) {
/*  58 */       return this;
/*     */     }
/*  60 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/*     */     try {
/*  67 */       return (Ptr)this.field.get(null);
/*  68 */     } catch (IllegalAccessException e) {
/*     */ 
/*     */       
/*  71 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/*     */     try {
/*  78 */       this.field.set(null, value);
/*  79 */     } catch (IllegalAccessException e) {
/*     */ 
/*     */       
/*  82 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/*  88 */     if (index == 0) {
/*  89 */       return getPointer();
/*     */     }
/*  91 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt() {
/*  97 */     return getPointer().toInt();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 102 */     setPointer(BytePtr.NULL.pointerPlus(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 107 */     if (offset == 0) {
/* 108 */       return getInt();
/*     */     }
/* 110 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int intValue) {
/* 116 */     if (offset == 0) {
/* 117 */       setInt(intValue);
/*     */     } else {
/* 119 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 126 */     if (index == 0) {
/* 127 */       return getInt();
/*     */     }
/* 129 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 135 */     if (index == 0) {
/* 136 */       setInt(value);
/*     */     } else {
/* 138 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 144 */     return getByteViaInt(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 149 */     setByteViaInt(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 154 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 164 */     if (this == o) {
/* 165 */       return true;
/*     */     }
/* 167 */     if (!(o instanceof PointerFieldPtr)) {
/* 168 */       return false;
/*     */     }
/* 170 */     PointerFieldPtr that = (PointerFieldPtr)o;
/* 171 */     return this.field.equals(that.field);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 176 */     return this.field.hashCode();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/PointerFieldPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */