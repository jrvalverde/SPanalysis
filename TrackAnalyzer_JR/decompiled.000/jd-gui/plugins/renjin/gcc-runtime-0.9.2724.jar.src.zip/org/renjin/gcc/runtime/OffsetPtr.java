/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetPtr
/*     */   implements Ptr
/*     */ {
/*     */   private Ptr ptr;
/*     */   private int offset;
/*     */   
/*     */   public OffsetPtr(Ptr ptr, int offset) {
/*  28 */     this.ptr = ptr;
/*  29 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  34 */     return this.ptr.getArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  39 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  44 */     return this.ptr.getOffsetInBytes() + this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  49 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  54 */     if (bytes == 0) {
/*  55 */       return this;
/*     */     }
/*  57 */     return this.ptr.pointerPlus(this.offset + bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/*  62 */     return this.ptr.getBoolean(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int offset) {
/*  67 */     return this.ptr.getBoolean(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int offset, boolean value) {
/*  72 */     this.ptr.setBoolean(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(boolean value) {
/*  77 */     this.ptr.setBoolean(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/*  82 */     return this.ptr.getByte(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  87 */     return this.ptr.getByte(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(byte value) {
/*  92 */     this.ptr.setByte(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  97 */     this.ptr.setByte(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/* 102 */     return this.ptr.getShort(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/* 107 */     return this.ptr.getShort(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/* 112 */     return this.ptr.getShort(this.offset + index * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/* 117 */     this.ptr.setShort(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/* 122 */     this.ptr.setShort(this.offset + index * 2, shortValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/* 127 */     this.ptr.setShort(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 132 */     return this.ptr.getChar(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 137 */     return this.ptr.getChar(this.offset + index * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/* 142 */     return this.ptr.getChar(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/* 147 */     this.ptr.setChar(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/* 152 */     this.ptr.setChar(this.offset + index * 2, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 157 */     this.ptr.setChar(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 162 */     return this.ptr.getDouble(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 167 */     return this.ptr.getDouble(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 172 */     return this.ptr.getDouble(this.offset + index * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 177 */     this.ptr.setDouble(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double value) {
/* 182 */     this.ptr.setDouble(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 187 */     this.ptr.setDouble(this.offset + index * 8, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96() {
/* 192 */     return this.ptr.getReal96(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/* 197 */     return this.ptr.getReal96(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/* 202 */     return this.ptr.getReal96(this.offset + index * 12);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/* 207 */     this.ptr.setReal96(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/* 212 */     this.ptr.setReal96(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 217 */     this.ptr.setReal96(this.offset + index * 12, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 222 */     return this.ptr.getFloat(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/* 227 */     return this.ptr.getFloat(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/* 232 */     return this.ptr.getFloat(this.offset + index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/* 237 */     this.ptr.setFloat(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 242 */     this.ptr.setFloat(this.offset + index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/* 247 */     this.ptr.setFloat(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 252 */     return this.ptr.getInt(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 257 */     return this.ptr.getInt(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 262 */     return this.ptr.getInt(this.offset + index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 267 */     this.ptr.setInt(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int value) {
/* 272 */     this.ptr.setInt(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 277 */     this.ptr.setInt(this.offset + index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 282 */     return this.ptr.getLong(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/* 287 */     return this.ptr.getLong(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 292 */     return this.ptr.getLong(this.offset + index * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/* 297 */     this.ptr.setLong(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long value) {
/* 302 */     this.ptr.setLong(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 307 */     this.ptr.setLong(this.offset + index * 8, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 312 */     return this.ptr.getPointer(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 317 */     return this.ptr.getPointer(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/* 322 */     return this.ptr.getPointer(this.offset + index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/* 327 */     this.ptr.setPointer(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 332 */     this.ptr.setPointer(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedPointer(int index, Ptr value) {
/* 337 */     this.ptr.setPointer(this.offset + index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 342 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(int byteValue, int n) {
/* 347 */     for (int i = 0; i < n; i++) {
/* 348 */       this.ptr.setByte(this.offset + i, (byte)byteValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 354 */     for (int i = 0; i < numBytes; i++) {
/* 355 */       this.ptr.setByte(this.offset + i, source.getByte(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 361 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int memcmp(Ptr other, int numBytes) {
/* 366 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 371 */     return this.ptr.copyOf(this.offset + offset, numBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 376 */     return this.ptr.copyOf(this.offset, numBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 381 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/* 386 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Ptr o) {
/* 391 */     return AbstractPtr.compare(this, o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr withOffset(int offset) {
/* 396 */     return this.ptr.pointerPlus(offset - this.ptr.getOffsetInBytes());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/OffsetPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */