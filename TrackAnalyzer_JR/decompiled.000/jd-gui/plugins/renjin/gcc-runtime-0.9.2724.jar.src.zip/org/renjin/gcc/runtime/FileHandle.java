package org.renjin.gcc.runtime;

import java.io.IOException;

public interface FileHandle {
  public static final int SEEK_SET = 0;
  
  public static final int SEEK_CURRENT = 1;
  
  public static final int SEEK_END = 2;
  
  int read() throws IOException;
  
  int getError();
  
  void clearError();
  
  void write(int paramInt) throws IOException;
  
  void rewind() throws IOException;
  
  void flush() throws IOException;
  
  void close() throws IOException;
  
  void seekSet(long paramLong) throws IOException;
  
  void seekCurrent(long paramLong) throws IOException;
  
  void seekEnd(long paramLong);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/FileHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */