/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.invoke.MethodType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsatisfiedLinkException
/*    */   extends RuntimeException
/*    */ {
/*    */   public UnsatisfiedLinkException(String functionName) {
/* 31 */     super("Function '" + functionName + "' was not found at compile-time");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MethodHandle throwingHandle(String functionName) throws NoSuchMethodException, IllegalAccessException {
/* 41 */     MethodHandle exceptionConstructor = MethodHandles.publicLookup().findConstructor(UnsatisfiedLinkException.class, 
/* 42 */         MethodType.methodType(void.class, String.class));
/*    */     
/* 44 */     exceptionConstructor = MethodHandles.insertArguments(exceptionConstructor, 0, new Object[] { functionName });
/* 45 */     MethodHandle exceptionThrower = MethodHandles.throwException(void.class, (Class)UnsatisfiedLinkException.class);
/*    */     
/* 47 */     return MethodHandles.foldArguments(exceptionThrower, exceptionConstructor);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/UnsatisfiedLinkException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */