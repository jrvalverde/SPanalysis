/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPtr
/*     */   implements Ptr
/*     */ {
/*     */   public static final int BITS_PER_BYTE = 8;
/*     */   private static final int UNSIGNED_MASK = 255;
/*     */   
/*     */   static int mallocSize(int bytes, int size) {
/*  42 */     int count = bytes / size;
/*  43 */     if (bytes % size != 0) {
/*  44 */       count++;
/*     */     }
/*  46 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getOffset() {
/*  52 */     throw new UnsupportedOperationException("No longer supported. Please recompile.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/*  57 */     setShort(0, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/*  63 */     int intValue = value;
/*     */     
/*  65 */     setByte(offset, (byte)(intValue & 0xFF));
/*  66 */     intValue >>= 8;
/*     */     
/*  68 */     setByte(offset + 1, (byte)(intValue & 0xFF));
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/*  73 */     return getShort(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/*  78 */     return 
/*     */       
/*  80 */       (short)((getByte(offset + 1) & 0xFF) << 8 | getByte(offset) & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/*  85 */     return getShort(index * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/*  90 */     setShort(index * 2, shortValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/*  95 */     return getDouble(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 100 */     return Double.longBitsToDouble(getLong(offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 105 */     return getDouble(index * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 110 */     setDouble(index * 8, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getReal96() {
/* 116 */     return getReal96(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/* 122 */     return getReal96(index * 12);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/* 127 */     return Double.longBitsToDouble(getLong(offset));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/* 133 */     setReal96(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 138 */     setReal96(index * 12, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/* 143 */     setLong(offset, Double.doubleToRawLongBits(value));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 149 */     return getChar(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/* 154 */     setChar(index * 2, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/* 159 */     return (getByte() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int offset) {
/* 164 */     return (getByte(offset) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int offset, boolean value) {
/* 169 */     setByte(offset, value ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(boolean value) {
/* 174 */     setByte(value ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/* 180 */     byte b1 = getByte(offset + 1);
/* 181 */     byte b2 = getByte(offset + 0);
/*     */     
/* 183 */     return (char)(b1 << 8 | b2 & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 188 */     return getAlignedInt(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 193 */     return getInt(index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 198 */     return (
/* 199 */       getByte(offset + 3) & 0xFF) << 24 | (
/* 200 */       getByte(offset + 2) & 0xFF) << 16 | (
/* 201 */       getByte(offset + 1) & 0xFF) << 8 | 
/* 202 */       getByte(offset) & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/* 207 */     return getByte(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 212 */     return getLong(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 217 */     return getLong(index * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/* 222 */     return (getByte(offset + 7) & 0xFFL) << 56L | (
/* 223 */       getByte(offset + 6) & 0xFFL) << 48L | (
/* 224 */       getByte(offset + 5) & 0xFFL) << 40L | (
/* 225 */       getByte(offset + 4) & 0xFFL) << 32L | (
/* 226 */       getByte(offset + 3) & 0xFFL) << 24L | (
/* 227 */       getByte(offset + 2) & 0xFFL) << 16L | (
/* 228 */       getByte(offset + 1) & 0xFFL) << 8L | 
/* 229 */       getByte(offset) & 0xFFL;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 234 */     return getFloat(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/* 239 */     return Float.intBitsToFloat(getInt(offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/* 244 */     return getFloat(index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 249 */     return getPointer(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/* 254 */     setFloat(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 259 */     setInt(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/* 264 */     setChar(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(byte value) {
/* 269 */     setByte(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 274 */     setDouble(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/* 279 */     setLong(0, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/* 284 */     setPointer(0, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 290 */     int intValue = value;
/*     */     
/* 292 */     setByte(offset, (byte)(intValue & 0xFF));
/* 293 */     intValue >>= 8;
/*     */     
/* 295 */     setByte(offset + 1, (byte)(intValue & 0xFF));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double doubleValue) {
/* 300 */     setLong(offset, Double.doubleToRawLongBits(doubleValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/* 305 */     setInt(offset, Float.floatToRawIntBits(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int intValue) {
/* 310 */     for (int i = 0; i < 4; i++) {
/* 311 */       setByte(offset + i, (byte)(intValue & 0xFF));
/* 312 */       intValue >>= 8;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long longValue) {
/* 318 */     for (int i = 0; i < 8; i++) {
/* 319 */       setByte(offset + i, (byte)(int)(longValue & 0xFFL));
/* 320 */       longValue >>= 8L;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 326 */     return getChar(index * 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 331 */     setFloat(index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 336 */     setInt(index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 341 */     setLong(index * 8, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/* 346 */     return getPointer(index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedPointer(int index, Ptr value) {
/* 351 */     setPointer(index * 4, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 357 */     return BytePtr.NULL.pointerPlus(getInt(offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 362 */     if (value.isNull()) {
/* 363 */       setInt(offset, 0);
/*     */     } else {
/* 365 */       throw new UnsupportedOperationException("Unsupported pointer store to a memory region allocated for primitives.\nThis means something went wrong during compilation and we allocated the wrong type of storage.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void memset(int intValue, int n) {
/* 372 */     byte byteValue = (byte)intValue;
/* 373 */     for (int i = 0; i < n; i++) {
/* 374 */       setByte(i, byteValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 380 */     for (int i = 0; i < numBytes; i++) {
/* 381 */       setByte(i, source.getByte(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 387 */     byte[] buffer = new byte[numBytes]; int i;
/* 388 */     for (i = 0; i < numBytes; i++) {
/* 389 */       buffer[i] = source.getByte(i);
/*     */     }
/* 391 */     for (i = 0; i < numBytes; i++) {
/* 392 */       setByte(i, buffer[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int memcmp(Ptr that, int numBytes) {
/* 398 */     for (int i = 0; i < numBytes; i++) {
/* 399 */       int b1 = getByte(i) & 0xFF;
/* 400 */       int b2 = that.getByte(i) & 0xFF;
/* 401 */       if (b1 < b2)
/* 402 */         return -1; 
/* 403 */       if (b1 > b2) {
/* 404 */         return 1;
/*     */       }
/*     */     } 
/* 407 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 412 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 417 */     return copyOf(0, numBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/* 423 */     if (isNull()) {
/* 424 */       return null;
/*     */     }
/* 426 */     return FunctionPtr.getBadHandle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int compareTo(Ptr o) {
/* 433 */     return compare(this, o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr withOffset(int offset) {
/* 438 */     return pointerPlus(offset - getOffsetInBytes());
/*     */   }
/*     */   
/*     */   public static int compare(Ptr x, Ptr y) {
/* 442 */     Object m1 = x.getArray();
/* 443 */     Object m2 = y.getArray();
/*     */     
/* 445 */     if (m1 != m2) {
/* 446 */       return Integer.compare(System.identityHashCode(m1), System.identityHashCode(m2));
/*     */     }
/*     */     
/* 449 */     if (x.isNull() && y.isNull()) {
/* 450 */       return 0;
/*     */     }
/*     */     
/* 453 */     return Integer.compare(x.getOffsetInBytes(), y.getOffsetInBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 459 */     if (!(obj instanceof Ptr)) {
/* 460 */       return false;
/*     */     }
/*     */     
/* 463 */     Ptr that = (Ptr)obj;
/*     */     
/* 465 */     return (getArray() == that.getArray() && 
/* 466 */       getOffsetInBytes() == that.getOffsetInBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   protected final byte getByteViaShort(int bytes) {
/* 471 */     int index = bytes / 2;
/* 472 */     int shift = bytes % 2 * 8;
/* 473 */     return (byte)(getAlignedShort(index) >>> shift);
/*     */   }
/*     */   
/*     */   protected final void setByteViaShort(int bytes, int value) {
/* 477 */     int index = bytes / 2;
/* 478 */     int shift = bytes % 2 * 8;
/*     */     
/* 480 */     int element = getAlignedShort(index);
/*     */     
/* 482 */     int updateMask = 255 << shift;
/*     */ 
/*     */     
/* 485 */     element &= updateMask ^ 0xFFFFFFFF;
/*     */ 
/*     */     
/* 488 */     int update = value << shift & updateMask;
/*     */ 
/*     */     
/* 491 */     setAlignedShort(index, (short)(element | update));
/*     */   }
/*     */   
/*     */   protected final byte getByteViaChar(int bytes) {
/* 495 */     int index = bytes / 2;
/* 496 */     int shift = bytes % 2 * 8;
/* 497 */     return (byte)(getAlignedChar(index) >>> shift);
/*     */   }
/*     */   
/*     */   protected final void setByteViaChar(int bytes, byte value) {
/* 501 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final byte getByteViaInt(int bytes) {
/* 509 */     int index = bytes / 4;
/* 510 */     int shift = bytes % 4 * 8;
/* 511 */     return (byte)(getAlignedInt(index) >>> shift);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setByteViaInt(int bytes, byte value) {
/* 523 */     int index = bytes / 4;
/* 524 */     int shift = bytes % 4 * 8;
/*     */     
/* 526 */     int element = getAlignedInt(index);
/*     */     
/* 528 */     int updateMask = 255 << shift;
/*     */ 
/*     */     
/* 531 */     element &= updateMask ^ 0xFFFFFFFF;
/*     */ 
/*     */     
/* 534 */     int update = value << shift & updateMask;
/*     */ 
/*     */     
/* 537 */     setAlignedInt(index, element | update);
/*     */   }
/*     */   
/*     */   protected final byte getByteViaLong(int bytes) {
/* 541 */     int index = bytes / 8;
/* 542 */     long elementBits = getAlignedLong(index);
/* 543 */     int shift = bytes % 8 * 8;
/*     */     
/* 545 */     return (byte)(int)(elementBits >>> shift);
/*     */   }
/*     */   
/*     */   protected final void setByteViaLong(int bytes, long value) {
/* 549 */     int index = bytes / 8;
/* 550 */     int shift = bytes % 8 * 8;
/*     */     
/* 552 */     long element = getAlignedLong(index);
/*     */     
/* 554 */     long updateMask = (255 << shift);
/*     */ 
/*     */     
/* 557 */     element &= updateMask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */ 
/*     */     
/* 560 */     long update = value << shift & updateMask;
/*     */ 
/*     */     
/* 563 */     setAlignedLong(index, element | update);
/*     */   }
/*     */   
/*     */   protected final byte getByteViaFloat(int bytes) {
/* 567 */     int index = bytes / 4;
/* 568 */     float element = getAlignedFloat(index);
/* 569 */     long elementBits = Float.floatToRawIntBits(element);
/* 570 */     int shift = bytes % 4 * 8;
/*     */     
/* 572 */     return (byte)(int)(elementBits >>> shift);
/*     */   }
/*     */   
/*     */   protected final void setByteViaFloat(int bytes, int value) {
/* 576 */     int index = bytes / 4;
/* 577 */     int shift = bytes % 4 * 8;
/*     */     
/* 579 */     int element = Float.floatToRawIntBits(getAlignedFloat(index));
/*     */     
/* 581 */     int updateMask = 255 << shift;
/*     */ 
/*     */     
/* 584 */     element &= updateMask ^ 0xFFFFFFFF;
/*     */ 
/*     */     
/* 587 */     int update = value << shift & updateMask;
/*     */ 
/*     */     
/* 590 */     setAlignedFloat(index, Float.intBitsToFloat(element | update));
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte getByteViaDouble(int bytes) {
/* 595 */     int index = bytes / 8;
/* 596 */     double element = getAlignedDouble(index);
/* 597 */     long elementBits = Double.doubleToRawLongBits(element);
/* 598 */     int shift = bytes % 8 * 8;
/*     */     
/* 600 */     return (byte)(int)(elementBits >>> shift);
/*     */   }
/*     */   
/*     */   protected final void setByteViaDouble(int bytes, long value) {
/* 604 */     int index = bytes / 8;
/* 605 */     int shift = bytes % 8 * 8;
/*     */     
/* 607 */     long element = Double.doubleToRawLongBits(getAlignedDouble(index));
/*     */     
/* 609 */     long updateMask = 255L << shift;
/*     */ 
/*     */     
/* 612 */     element &= updateMask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */ 
/*     */     
/* 615 */     long update = value << shift & updateMask;
/*     */ 
/*     */     
/* 618 */     setAlignedDouble(index, Double.longBitsToDouble(element | update));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/AbstractPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */