/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mathlib
/*     */ {
/*     */   public static final double FLT_RADIX = 2.0D;
/*  28 */   private static final double LN_FLT_RADIX = log(2.0D);
/*     */   
/*  30 */   private static final double LN_2 = log(2.0D);
/*     */   
/*     */   public static double acos(double x) {
/*  33 */     return Math.acos(x);
/*     */   }
/*     */   
/*     */   public static double asin(double x) {
/*  37 */     return Math.asin(x);
/*     */   }
/*     */   
/*     */   public static double atan(double x) {
/*  41 */     return Math.atan(x);
/*     */   }
/*     */   
/*     */   public static double atan2(double y, double x) {
/*  45 */     return Math.atan2(y, x);
/*     */   }
/*     */   
/*     */   public static double cos(double x) {
/*  49 */     return Math.cos(x);
/*     */   }
/*     */   
/*     */   public static double cosh(double x) {
/*  53 */     return Math.cosh(x);
/*     */   }
/*     */   
/*     */   public static double sin(double x) {
/*  57 */     return Math.sin(x);
/*     */   }
/*     */   
/*     */   public static double tan(double x) {
/*  61 */     return Math.tan(x);
/*     */   }
/*     */   
/*     */   public static double sinh(double x) {
/*  65 */     return Math.sinh(x);
/*     */   }
/*     */   
/*     */   public static double tanh(double x) {
/*  69 */     return Math.tanh(x);
/*     */   }
/*     */   
/*     */   public static double exp(double x) {
/*  73 */     return Math.exp(x);
/*     */   }
/*     */   
/*     */   public static double expm1(double x) {
/*  77 */     return Math.expm1(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double frexp(double value, IntPtr pExponent) {
/*  90 */     long bits = Double.doubleToRawLongBits(value);
/*  91 */     double realMant = 1.0D;
/*     */ 
/*     */     
/*  94 */     if (Double.isNaN(value) || value + value == value || 
/*     */       
/*  96 */       Double.isInfinite(value)) {
/*  97 */       pExponent.set(0);
/*  98 */       return value;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 103 */     boolean neg = (bits < 0L);
/* 104 */     int exponent = (int)(bits >> 52L & 0x7FFL);
/* 105 */     long mantissa = bits & 0xFFFFFFFFFFFFFL;
/*     */     
/* 107 */     if (exponent == 0) {
/* 108 */       exponent++;
/*     */     } else {
/* 110 */       mantissa |= 0x10000000000000L;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     exponent -= 1075;
/* 117 */     realMant = mantissa;
/*     */ 
/*     */     
/* 120 */     while (realMant >= 1.0D) {
/* 121 */       mantissa >>= 1L;
/* 122 */       realMant /= 2.0D;
/* 123 */       exponent++;
/*     */     } 
/*     */     
/* 126 */     if (neg) {
/* 127 */       realMant *= -1.0D;
/*     */     }
/*     */     
/* 130 */     pExponent.set(exponent);
/* 131 */     return realMant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double ldexp(double x, int d) {
/* 141 */     for (; d > 0; d--) {
/* 142 */       x *= 2.0D;
/*     */     }
/* 144 */     for (; d < 0; d++) {
/* 145 */       x *= 0.5D;
/*     */     }
/* 147 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double log(double x) {
/* 154 */     return Math.log(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double log2(double x) {
/* 161 */     return Math.log(x) / LN_2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double logb(double x) {
/* 170 */     return Math.floor(Math.log(Math.abs(x)) / LN_FLT_RADIX);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double log10(double x) {
/* 177 */     return Math.log10(x);
/*     */   }
/*     */   
/*     */   public static double log1p(double x) {
/* 181 */     return Math.log1p(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double modf(double x, DoublePtr pInteger) {
/*     */     double intValue;
/* 189 */     if (x < 0.0D) {
/* 190 */       intValue = Math.ceil(x);
/*     */     } else {
/* 192 */       intValue = Math.floor(x);
/*     */     } 
/* 194 */     double fracValue = x - intValue;
/* 195 */     pInteger.set(intValue);
/* 196 */     return fracValue;
/*     */   }
/*     */   
/*     */   public static double pow(double x, double y) {
/* 200 */     return Math.pow(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double sqrt(double x) {
/* 208 */     return Math.sqrt(x);
/*     */   }
/*     */   
/*     */   public static float sqrtf(float x) {
/* 212 */     return (float)Math.sqrt(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double cbrt(double x) {
/* 219 */     return Math.cbrt(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double hypot(double x, double y) {
/* 226 */     return Math.hypot(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double ceil(double x) {
/* 234 */     return Math.ceil(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double fabs(double x) {
/* 241 */     return Math.abs(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double floor(double x) {
/* 248 */     return Math.floor(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double trunc(double x) {
/* 255 */     if (x > 0.0D) {
/* 256 */       return Math.floor(x);
/*     */     }
/* 258 */     return Math.ceil(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double round(double x) {
/* 271 */     return Math.rint(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double rint(double x) {
/* 283 */     return Math.rint(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long lround(double x) {
/* 290 */     return Math.round(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long lrint(double x) {
/* 300 */     return (long)rint(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double fmod(double x, double y) {
/* 307 */     return x % y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double fmax(double x, double y) {
/* 314 */     return Math.max(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double fmin(double x, double y) {
/* 321 */     return Math.min(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double erf(double x) {
/* 329 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double erfc(double x) {
/* 336 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double tgamma(double x) {
/* 343 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double lgamma(double x) {
/* 350 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public static double copysign(double x, double y) {
/* 354 */     return Math.copySign(x, y);
/*     */   }
/*     */   
/*     */   public static float copysignf(float x, float y) {
/* 358 */     return Math.copySign(x, y);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Mathlib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */