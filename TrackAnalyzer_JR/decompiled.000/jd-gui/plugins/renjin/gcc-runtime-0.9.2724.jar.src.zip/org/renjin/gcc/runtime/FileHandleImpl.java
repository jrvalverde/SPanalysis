/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileHandleImpl
/*    */   extends AbstractFileHandle
/*    */ {
/*    */   private RandomAccessFile file;
/*    */   
/*    */   public FileHandleImpl(RandomAccessFile file) {
/* 32 */     this.file = file;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 37 */     return this.file.read();
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 42 */     this.file.write(b);
/*    */   }
/*    */ 
/*    */   
/*    */   public void rewind() throws IOException {
/* 47 */     this.file.seek(0L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {
/* 52 */     this.file.getFD().sync();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 57 */     this.file.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekSet(long offset) throws IOException {
/* 62 */     this.file.seek(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekCurrent(long offset) throws IOException {
/* 67 */     this.file.seek(this.file.getFilePointer() + offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekEnd(long offset) {
/* 72 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/FileHandleImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */