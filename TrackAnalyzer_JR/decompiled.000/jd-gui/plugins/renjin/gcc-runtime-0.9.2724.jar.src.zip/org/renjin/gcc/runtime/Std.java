/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Std
/*    */ {
/*    */   public static void _ZSt20__throw_length_errorPKc(Ptr errorMessage) {
/* 27 */     throw new RuntimeException(Stdlib.nullTerminatedString(errorMessage));
/*    */   }
/*    */   
/*    */   public static void _ZSt17__throw_bad_allocv(Ptr errorMessage) {
/* 31 */     throw new RuntimeException(Stdlib.nullTerminatedString(errorMessage));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Std.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */