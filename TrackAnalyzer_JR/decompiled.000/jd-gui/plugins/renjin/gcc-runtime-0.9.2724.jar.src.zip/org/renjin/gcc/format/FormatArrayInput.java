/*    */ package org.renjin.gcc.format;
/*    */ 
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatArrayInput
/*    */   implements FormatInput
/*    */ {
/*    */   private final Object[] arguments;
/*    */   
/*    */   public FormatArrayInput(Object... arguments) {
/* 29 */     this.arguments = arguments;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNA(int argumentIndex) {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getInt(int argumentIndex) {
/* 39 */     Object value = this.arguments[argumentIndex];
/* 40 */     if (value instanceof Number)
/* 41 */       return ((Number)value).intValue(); 
/* 42 */     if (value instanceof Character)
/* 43 */       return ((Character)value).charValue(); 
/* 44 */     if (value instanceof Ptr) {
/* 45 */       return ((Ptr)value).toInt();
/*    */     }
/* 47 */     throw new IllegalArgumentException("Expected integer argument at index " + argumentIndex + ", found " + value
/* 48 */         .getClass().getName());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long getLong(int argumentIndex) {
/* 54 */     return ((Number)this.arguments[argumentIndex]).longValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public long getUnsignedLong(int argumentIndex) {
/* 59 */     Object value = this.arguments[argumentIndex];
/* 60 */     if (value instanceof Long)
/* 61 */       return ((Long)value).longValue(); 
/* 62 */     if (value instanceof Integer) {
/* 63 */       return Integer.toUnsignedLong(((Integer)value).intValue());
/*    */     }
/*    */     
/* 66 */     throw new IllegalArgumentException("Expected Integer or Long argument at index " + argumentIndex + ", found " + value
/* 67 */         .getClass().getName());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public double getDouble(int argumentIndex) {
/* 73 */     return ((Number)this.arguments[argumentIndex]).doubleValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString(int argumentIndex) {
/* 78 */     Object value = this.arguments[argumentIndex];
/* 79 */     if (value instanceof String)
/* 80 */       return (String)value; 
/* 81 */     if (value instanceof Ptr) {
/* 82 */       return Stdlib.nullTerminatedString((Ptr)value);
/*    */     }
/* 84 */     throw new IllegalArgumentException("Expected string argument at index " + argumentIndex);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/format/FormatArrayInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */