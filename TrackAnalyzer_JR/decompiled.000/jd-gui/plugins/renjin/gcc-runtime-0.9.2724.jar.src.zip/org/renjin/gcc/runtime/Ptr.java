package org.renjin.gcc.runtime;

import java.lang.invoke.MethodHandle;

public interface Ptr extends Comparable<Ptr> {
  Object getArray();
  
  @Deprecated
  int getOffset();
  
  int getOffsetInBytes();
  
  Ptr realloc(int paramInt);
  
  Ptr pointerPlus(int paramInt);
  
  boolean getBoolean();
  
  boolean getBoolean(int paramInt);
  
  void setBoolean(int paramInt, boolean paramBoolean);
  
  void setBoolean(boolean paramBoolean);
  
  byte getByte();
  
  byte getByte(int paramInt);
  
  void setByte(byte paramByte);
  
  void setByte(int paramInt, byte paramByte);
  
  short getShort();
  
  short getShort(int paramInt);
  
  short getAlignedShort(int paramInt);
  
  void setShort(short paramShort);
  
  void setAlignedShort(int paramInt, short paramShort);
  
  void setShort(int paramInt, short paramShort);
  
  char getChar();
  
  char getAlignedChar(int paramInt);
  
  char getChar(int paramInt);
  
  void setChar(char paramChar);
  
  void setAlignedChar(int paramInt, char paramChar);
  
  void setChar(int paramInt, char paramChar);
  
  double getDouble();
  
  double getDouble(int paramInt);
  
  double getAlignedDouble(int paramInt);
  
  void setDouble(double paramDouble);
  
  void setDouble(int paramInt, double paramDouble);
  
  void setAlignedDouble(int paramInt, double paramDouble);
  
  double getReal96();
  
  double getReal96(int paramInt);
  
  double getAlignedReal96(int paramInt);
  
  void setReal96(double paramDouble);
  
  void setReal96(int paramInt, double paramDouble);
  
  void setAlignedReal96(int paramInt, double paramDouble);
  
  float getFloat();
  
  float getFloat(int paramInt);
  
  float getAlignedFloat(int paramInt);
  
  void setFloat(float paramFloat);
  
  void setAlignedFloat(int paramInt, float paramFloat);
  
  void setFloat(int paramInt, float paramFloat);
  
  int getInt();
  
  int getInt(int paramInt);
  
  int getAlignedInt(int paramInt);
  
  void setInt(int paramInt);
  
  void setInt(int paramInt1, int paramInt2);
  
  void setAlignedInt(int paramInt1, int paramInt2);
  
  long getLong();
  
  long getLong(int paramInt);
  
  long getAlignedLong(int paramInt);
  
  void setLong(long paramLong);
  
  void setLong(int paramInt, long paramLong);
  
  void setAlignedLong(int paramInt, long paramLong);
  
  Ptr getPointer();
  
  Ptr getPointer(int paramInt);
  
  Ptr getAlignedPointer(int paramInt);
  
  void setPointer(Ptr paramPtr);
  
  void setPointer(int paramInt, Ptr paramPtr);
  
  void setAlignedPointer(int paramInt, Ptr paramPtr);
  
  int toInt();
  
  void memset(int paramInt1, int paramInt2);
  
  void memcpy(Ptr paramPtr, int paramInt);
  
  void memmove(Ptr paramPtr, int paramInt);
  
  int memcmp(Ptr paramPtr, int paramInt);
  
  Ptr copyOf(int paramInt1, int paramInt2);
  
  Ptr copyOf(int paramInt);
  
  boolean isNull();
  
  MethodHandle toMethodHandle();
  
  int compareTo(Ptr paramPtr);
  
  Ptr withOffset(int paramInt);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Ptr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */