/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.renjin.gcc.annotations.GccSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ObjectPtr<T>
/*     */   extends AbstractPtr
/*     */ {
/*  28 */   public static final ObjectPtr NULL = new ObjectPtr();
/*     */   
/*     */   public final Object[] array;
/*     */   public final int offset;
/*     */   public Class baseType;
/*     */   
/*     */   private ObjectPtr() {
/*  35 */     this.array = null;
/*  36 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectPtr(T... array) {
/*  43 */     this.array = (Object[])array;
/*  44 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public ObjectPtr(Object[] array, int offset) {
/*  48 */     this.array = array;
/*  49 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public ObjectPtr(Class baseType, Object[] array, int offset) {
/*  53 */     this.array = array;
/*  54 */     this.offset = offset;
/*  55 */     this.baseType = baseType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getArray() {
/*  60 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  65 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  70 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectPtr<T> realloc(int newSizeInBytes) {
/*  75 */     return new ObjectPtr((T[])Realloc.realloc(this.array, this.offset, newSizeInBytes / 4));
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  80 */     if (bytes % 4 == 0) {
/*  81 */       return new ObjectPtr(this.array, this.offset + bytes / 4);
/*     */     }
/*  83 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  89 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  94 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/*  99 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 104 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */   
/*     */   public T get() {
/* 108 */     return get(0);
/*     */   }
/*     */   
/*     */   public void set(Object value) {
/* 112 */     if (value instanceof MallocThunk) {
/* 113 */       MallocThunk thunk = (MallocThunk)value;
/* 114 */       if (this.array instanceof BooleanPtr[] || BooleanPtr.class.equals(this.baseType)) {
/* 115 */         this.array[this.offset] = thunk.booleanPtr();
/*     */       }
/* 117 */       else if (this.array instanceof BytePtr[] || BytePtr.class.equals(this.baseType)) {
/* 118 */         this.array[this.offset] = thunk.bytePtr();
/*     */       }
/* 120 */       else if (this.array instanceof CharPtr[] || CharPtr.class.equals(this.baseType)) {
/* 121 */         this.array[this.offset] = thunk.charPtr();
/*     */       }
/* 123 */       else if (this.array instanceof DoublePtr[] || DoublePtr.class.equals(this.baseType)) {
/* 124 */         this.array[this.offset] = thunk.doublePtr();
/*     */       }
/* 126 */       else if (this.array instanceof FloatPtr[] || FloatPtr.class.equals(this.baseType)) {
/* 127 */         this.array[this.offset] = thunk.floatPtr();
/*     */       }
/* 129 */       else if (this.array instanceof IntPtr[] || IntPtr.class.equals(this.baseType)) {
/* 130 */         this.array[this.offset] = thunk.intPtr();
/*     */       }
/* 132 */       else if (this.array instanceof LongPtr[] || LongPtr.class.equals(this.baseType)) {
/* 133 */         this.array[this.offset] = thunk.longPtr();
/*     */       }
/* 135 */       else if (this.array instanceof ShortPtr[] || ShortPtr.class.equals(this.baseType)) {
/* 136 */         this.array[this.offset] = thunk.shortPtr();
/*     */       }
/* 138 */       else if (this.array instanceof ObjectPtr[]) {
/* 139 */         this.array[this.offset] = thunk.objectPtr(this.baseType);
/*     */       }
/* 141 */       else if (this.baseType.equals(Object.class)) {
/*     */         
/* 143 */         this.array[this.offset] = thunk;
/*     */       } else {
/* 145 */         this.array[this.offset] = thunk.recordUnitPtr(this.array.getClass().getComponentType());
/*     */       } 
/*     */     } else {
/* 148 */       this.array[this.offset] = value;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T get(int index) {
/* 154 */     return (T)this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(Object[] str, int strOffset, int c, int byteCount) {
/* 168 */     if (byteCount == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 173 */     Class<?> elementType = str.getClass().getComponentType();
/*     */     
/* 175 */     if (Ptr.class.isAssignableFrom(elementType)) {
/*     */       Object nullInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 182 */         nullInstance = elementType.getField("NULL").get(null);
/* 183 */       } catch (IllegalAccessException|NoSuchFieldException e) {
/* 184 */         throw new IllegalStateException("Cannot access NULL instance for " + elementType.getName());
/*     */       } 
/* 186 */       Arrays.fill(str, strOffset, strOffset + byteCount / 4, nullInstance);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 194 */       GccSize size = elementType.<GccSize>getAnnotation(GccSize.class);
/* 195 */       if (size == null) {
/* 196 */         throw new IllegalStateException(elementType.getClass().getName() + " is missing @GccSize annotation");
/*     */       }
/* 198 */       int numElements = byteCount / size.value();
/*     */ 
/*     */ 
/*     */       
/* 202 */       throw new UnsupportedOperationException("TODO");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ObjectPtr cast(Object voidPointer) {
/* 207 */     if (voidPointer instanceof MallocThunk) {
/* 208 */       throw new UnsupportedOperationException("Casting of void* to record type without type information. Please recompile against the latest version of gcc-bridge to resolve.");
/*     */     }
/*     */     
/* 211 */     return (ObjectPtr)voidPointer;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ObjectPtr cast(Object voidPointer, Class<?> recordType) {
/* 216 */     if (voidPointer instanceof MallocThunk) {
/* 217 */       return ((MallocThunk)voidPointer).objectPtr(recordType);
/*     */     }
/*     */     
/* 220 */     return (ObjectPtr)voidPointer;
/*     */   }
/*     */   
/*     */   public static <T> T castUnit(Object voidPointer, Class<T> recordType) {
/* 224 */     if (voidPointer instanceof MallocThunk) {
/* 225 */       return ((MallocThunk)voidPointer).recordUnitPtr(recordType);
/*     */     }
/* 227 */     return (T)recordType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 232 */     return (Ptr)this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 237 */     int byteOffset = this.offset * 4 + offset;
/* 238 */     if (byteOffset % 4 == 0) {
/* 239 */       return (Ptr)this.array[byteOffset / 4];
/*     */     }
/* 241 */     throw new UnsupportedOperationException("Unaligned access");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/ObjectPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */