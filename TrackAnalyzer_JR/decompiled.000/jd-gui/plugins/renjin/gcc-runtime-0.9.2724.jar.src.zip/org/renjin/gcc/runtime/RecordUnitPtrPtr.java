/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordUnitPtrPtr<T>
/*     */   implements Ptr
/*     */ {
/*     */   public static final int BYTES = 4;
/*     */   private T[] array;
/*     */   private int offset;
/*     */   
/*     */   public RecordUnitPtrPtr(T[] array, int offset) {
/*  31 */     this.array = array;
/*  32 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  37 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  42 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  47 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  52 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  57 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/*  62 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int offset) {
/*  67 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int offset, boolean value) {
/*  72 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(boolean value) {
/*  77 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/*  82 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  87 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(byte value) {
/*  92 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  97 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/* 102 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/* 107 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/* 112 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/* 117 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/* 122 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/* 127 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 132 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 137 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/* 142 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/* 147 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/* 152 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 157 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 162 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 167 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 172 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 177 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double value) {
/* 182 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 187 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96() {
/* 192 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/* 197 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/* 202 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/* 207 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/* 212 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 217 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 222 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/* 227 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/* 232 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/* 237 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 242 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/* 247 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 252 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 257 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 262 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 267 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int value) {
/* 272 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 277 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 282 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/* 287 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 292 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/* 297 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long value) {
/* 302 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 307 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 312 */     return new RecordUnitPtr<>(this.array[this.offset]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 317 */     return new RecordUnitPtr<>(this.array[this.offset + offset / 4]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/* 322 */     return new RecordUnitPtr<>(this.array[this.offset + index]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/* 327 */     this.array[this.offset] = (T)value.getArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 332 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedPointer(int index, Ptr value) {
/* 337 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 342 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(int byteValue, int n) {
/* 347 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 352 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 357 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int memcmp(Ptr other, int numBytes) {
/* 362 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 367 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 372 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 377 */     return (this.array == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/* 382 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Ptr o) {
/* 387 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr withOffset(int offset) {
/* 392 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/RecordUnitPtrPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */