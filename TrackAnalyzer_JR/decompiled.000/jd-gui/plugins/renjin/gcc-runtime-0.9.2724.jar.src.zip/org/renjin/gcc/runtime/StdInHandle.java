/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StdInHandle
/*    */   extends AbstractFileHandle
/*    */ {
/*    */   public int read() throws IOException {
/* 26 */     return System.in.read();
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 31 */     throw new IOException("Cannot write to stdin");
/*    */   }
/*    */ 
/*    */   
/*    */   public void rewind() throws IOException {
/* 36 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() throws IOException {}
/*    */ 
/*    */   
/*    */   public void seekSet(long offset) throws IOException {
/* 49 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekCurrent(long offset) throws IOException {
/* 54 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekEnd(long offset) {
/* 59 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/StdInHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */