/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongJumpException
/*    */   extends RuntimeException
/*    */ {
/*    */   private Ptr buf;
/*    */   private int value;
/*    */   
/*    */   public LongJumpException(Ptr buf, int value) {
/* 30 */     super("longjmp: TODO");
/* 31 */     this.buf = buf;
/* 32 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/LongJumpException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */