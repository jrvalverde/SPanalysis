/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanPtr
/*     */   extends AbstractPtr
/*     */   implements Ptr
/*     */ {
/*  24 */   public static final BooleanPtr NULL = new BooleanPtr();
/*     */   
/*     */   public final boolean[] array;
/*     */   
/*     */   public final int offset;
/*     */   
/*     */   public static BooleanPtr malloc(int bytes) {
/*  31 */     return new BooleanPtr(new boolean[bytes]);
/*     */   }
/*     */   
/*     */   private BooleanPtr() {
/*  35 */     this.array = null;
/*  36 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public BooleanPtr(boolean[] array, int offset) {
/*  40 */     this.array = array;
/*  41 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public BooleanPtr(boolean... values) {
/*  45 */     this.array = values;
/*  46 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public boolean unwrap() {
/*  50 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getArray() {
/*  55 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  60 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  65 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanPtr realloc(int newSizeInBytes) {
/*  70 */     return new BooleanPtr(Realloc.realloc(this.array, this.offset, newSizeInBytes));
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  75 */     return new BooleanPtr(this.array, this.offset + bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  80 */     return this.array[offset] ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  85 */     this.array[offset] = (value != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/*  90 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/*  95 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */   
/*     */   public static BooleanPtr cast(Object voidPointer) {
/*  99 */     if (voidPointer instanceof MallocThunk) {
/* 100 */       return ((MallocThunk)voidPointer).booleanPtr();
/*     */     }
/* 102 */     return (BooleanPtr)voidPointer;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/BooleanPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */