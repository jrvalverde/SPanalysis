/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StdOutHandle
/*    */   extends AbstractFileHandle
/*    */ {
/*    */   private final PrintStream out;
/*    */   
/*    */   public StdOutHandle(PrintStream out) {
/* 29 */     this.out = out;
/*    */   }
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 34 */     throw new UnsupportedOperationException("Cannot read from stdout");
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 39 */     this.out.write(b);
/*    */   }
/*    */ 
/*    */   
/*    */   public void rewind() throws IOException {
/* 44 */     throw new UnsupportedOperationException("Cannot rewind stdout");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void flush() throws IOException {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() throws IOException {}
/*    */ 
/*    */   
/*    */   public void seekSet(long offset) throws IOException {
/* 57 */     throw new UnsupportedOperationException("Cannot seek stdout");
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekCurrent(long offset) throws IOException {
/* 62 */     throw new UnsupportedOperationException("Cannot seek stdout");
/*    */   }
/*    */ 
/*    */   
/*    */   public void seekEnd(long offset) {
/* 67 */     throw new UnsupportedOperationException("Cannot seek stdout");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/StdOutHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */