/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   public static final int BYTES = 8;
/*  28 */   public static final LongPtr NULL = new LongPtr();
/*     */   
/*     */   public final long[] array;
/*     */   public final int offset;
/*     */   
/*     */   private LongPtr() {
/*  34 */     this.array = null;
/*  35 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public LongPtr(long[] array, int offset) {
/*  39 */     this.array = array;
/*  40 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public LongPtr(long... array) {
/*  44 */     this.array = array;
/*  45 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public static LongPtr malloc(int bytes) {
/*  49 */     return new LongPtr(new long[mallocSize(bytes, 8)]);
/*     */   }
/*     */ 
/*     */   
/*     */   public long[] getArray() {
/*  54 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  59 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  64 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public LongPtr realloc(int newSizeInBytes) {
/*  69 */     return new LongPtr(Realloc.realloc(this.array, this.offset, newSizeInBytes / 8));
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  74 */     if (bytes == 0)
/*  75 */       return this; 
/*  76 */     if (bytes % 8 == 0) {
/*  77 */       return new LongPtr(this.array, this.offset + bytes / 8);
/*     */     }
/*  79 */     return new OffsetPtr(this, this.offset * 8 + bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong() {
/*  85 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/*  90 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/*  95 */     if (offset % 8 == 0) {
/*  96 */       return this.array[this.offset + offset / 8];
/*     */     }
/*  98 */     return super.getLong(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 104 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long longValue) {
/* 109 */     if (offset % 8 == 0) {
/* 110 */       this.array[this.offset + offset / 8] = longValue;
/*     */     } else {
/* 112 */       super.setLong(offset, longValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 118 */     return Double.longBitsToDouble(this.array[this.offset]);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 123 */     return Double.longBitsToDouble(this.array[this.offset + index]);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 128 */     return getByteViaLong(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 133 */     setByteViaLong(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 138 */     return this.offset * 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 143 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */   
/*     */   public long unwrap() {
/* 147 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int memcmp(LongPtr x, LongPtr y, int n) {
/* 157 */     return memcmp(x.array, x.offset, y.array, y.offset, n);
/*     */   }
/*     */   
/*     */   public static int memcmp(long[] x, int xi, long[] y, int yi, int n) {
/* 161 */     while (n > 0) {
/* 162 */       long vx = x[xi];
/* 163 */       long vy = y[yi];
/*     */       
/* 165 */       if (vx != vy || n < 8) {
/* 166 */         return memcmp(vx, vy, n);
/*     */       }
/* 168 */       xi++;
/* 169 */       yi++;
/* 170 */       n -= 8;
/*     */     } 
/* 172 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memcmp(long x, long y, int n) {
/* 187 */     for (int i = 0; i < n; i++) {
/* 188 */       int xb = (int)(x & 0xFFL);
/* 189 */       int yb = (int)(y & 0xFFL);
/*     */       
/* 191 */       if (xb < yb)
/* 192 */         return -1; 
/* 193 */       if (xb > yb) {
/* 194 */         return 1;
/*     */       }
/* 196 */       x >>= 8L;
/* 197 */       y >>= 8L;
/*     */     } 
/* 199 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(double[] str, int strOffset, int c, int n) {
/* 213 */     assert n % 64 == 0;
/*     */     
/* 215 */     Arrays.fill(str, strOffset, strOffset + c / 64, memset(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long memset(int c) {
/* 222 */     return (c & 0xFFL) << 56L | (c & 0xFFL) << 48L | (c & 0xFFL) << 40L | (c & 0xFFL) << 32L | (c & 0xFFL) << 24L | (c & 0xFFL) << 16L | (c & 0xFFL) << 8L | c & 0xFFL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongPtr cast(Object voidPointer) {
/* 233 */     if (voidPointer instanceof MallocThunk) {
/* 234 */       return ((MallocThunk)voidPointer).longPtr();
/*     */     }
/* 236 */     if (voidPointer == null) {
/* 237 */       return NULL;
/*     */     }
/* 239 */     return (LongPtr)voidPointer;
/*     */   }
/*     */   
/*     */   public static void memcpy(LongPtr x, LongPtr y, int numBytes) {
/* 243 */     long[] arrayS = y.getArray();
/* 244 */     int offsetS = y.getOffset();
/* 245 */     int restY = arrayS.length - offsetS;
/* 246 */     if (restY > 0) {
/* 247 */       long[] carray = new long[numBytes];
/* 248 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 249 */         carray[i] = arrayS[j];
/*     */       }
/* 251 */       x = new LongPtr(carray);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static double unsignedInt64ToReal64(long i) {
/* 256 */     if (i >= 0L) {
/* 257 */       return i;
/*     */     }
/* 259 */     int upper = (int)(i >>> 32L);
/* 260 */     int lower = (int)i;
/*     */     
/* 262 */     long lowerLong = lower & 0xFFFFFFFFL;
/* 263 */     long upperLong = upper & 0xFFFFFFFFL;
/*     */     
/* 265 */     return lowerLong + upperLong * 4.294967296E9D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static long unsignedDivide(long dividend, long divisor) {
/* 276 */     return Long.divideUnsigned(dividend, divisor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static long unsignedRemainder(long dividend, long divisor) {
/* 288 */     return Long.remainderUnsigned(dividend, divisor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int compareUnsigned(long a, long b) {
/* 300 */     return Long.compareUnsigned(a, b);
/*     */   }
/*     */   
/*     */   public static long unsignedMax(long a, long b) {
/* 304 */     if (Long.compareUnsigned(a, b) > 0) {
/* 305 */       return a;
/*     */     }
/* 307 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public static long unsignedMin(long a, long b) {
/* 312 */     if (Long.compareUnsigned(a, b) < 0) {
/* 313 */       return a;
/*     */     }
/* 315 */     return b;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/LongPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */