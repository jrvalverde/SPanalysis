/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShortPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   public static final int BYTES = 2;
/*  28 */   public static final ShortPtr NULL = new ShortPtr();
/*     */   
/*     */   public final short[] array;
/*     */   public final int offset;
/*     */   
/*     */   private ShortPtr() {
/*  34 */     this.array = null;
/*  35 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public ShortPtr(short[] array, int offset) {
/*  39 */     this.array = array;
/*  40 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public ShortPtr(short... array) {
/*  44 */     this.array = array;
/*  45 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public static ShortPtr malloc(int bytes) {
/*  49 */     return new ShortPtr(new short[AbstractPtr.mallocSize(bytes, 2)]);
/*     */   }
/*     */ 
/*     */   
/*     */   public short[] getArray() {
/*  54 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  59 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  64 */     return this.offset * 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  69 */     return new ShortPtr(Realloc.realloc(this.array, this.offset, newSizeInBytes / 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  74 */     return new ShortPtr(this.array, this.offset + bytes / 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/*  79 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/*  84 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/*  89 */     if (offset % 2 == 0) {
/*  90 */       return getAlignedShort(offset / 2);
/*     */     }
/*  92 */     return super.getShort(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/*  98 */     this.array[this.offset + index] = shortValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/* 103 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/* 108 */     if (offset % 2 == 0) {
/* 109 */       setAlignedShort(offset / 2, value);
/*     */     } else {
/* 111 */       super.setShort(offset, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 117 */     return getByteViaShort(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 122 */     setByteViaShort(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 127 */     return this.offset * 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 132 */     return (this.array == null && this.offset != 0);
/*     */   }
/*     */   
/*     */   public short unwrap() {
/* 136 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void memset(short[] array, int offset, int value, int length) {
/* 146 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public static short memset(int byteValue) {
/* 150 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */   
/*     */   public static ShortPtr cast(Object voidPointer) {
/* 154 */     if (voidPointer instanceof MallocThunk) {
/* 155 */       return ((MallocThunk)voidPointer).shortPtr();
/*     */     }
/* 157 */     if (voidPointer == null) {
/* 158 */       return NULL;
/*     */     }
/* 160 */     return (ShortPtr)voidPointer;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/ShortPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */