/*     */ package org.renjin.gcc.format;
/*     */ 
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Formatter
/*     */ {
/*     */   private final String formatString;
/*     */   
/*     */   public enum ArgumentType
/*     */   {
/*  41 */     INTEGER,
/*  42 */     DOUBLE,
/*  43 */     POINTER,
/*  44 */     UNUSED, LONG, STRING;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private final List<FormatSpec> conversions = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private List<ArgumentType> argumentTypes = new ArrayList<>();
/*     */   
/*  62 */   private int currentPos = 0;
/*     */   
/*  64 */   private int currentArgumentIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormatSpec currentSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DecimalFormatSymbols dfs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Formatter(String formatString) throws IllegalArgumentException {
/*  83 */     this(Locale.getDefault(), formatString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Formatter(Locale locale, String formatString) throws IllegalArgumentException {
/* 100 */     this.formatString = formatString;
/* 101 */     this.dfs = new DecimalFormatSymbols(locale);
/*     */     
/* 103 */     consumeLiteral();
/*     */     
/* 105 */     while (this.currentPos < formatString.length()) {
/* 106 */       consumeNextSpec();
/* 107 */       consumeLiteral();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void consumeLiteral() {
/* 120 */     StringBuilder sb = new StringBuilder();
/* 121 */     while (hasMoreChars()) {
/* 122 */       char c = next();
/* 123 */       if (c == '%') {
/* 124 */         pushBack();
/*     */         break;
/*     */       } 
/* 127 */       if (c == '\\') {
/* 128 */         if (hasMoreChars()) {
/* 129 */           c = next();
/* 130 */           switch (c) {
/*     */             case 'a':
/* 132 */               sb.append('\007');
/*     */               continue;
/*     */             case 'b':
/* 135 */               sb.append('\b');
/*     */               continue;
/*     */             case 'f':
/* 138 */               sb.append('\f');
/*     */               continue;
/*     */             case 'n':
/* 141 */               sb.append(System.getProperty("line.separator"));
/*     */               continue;
/*     */             case 'r':
/* 144 */               sb.append('\r');
/*     */               continue;
/*     */             case 't':
/* 147 */               sb.append('\t');
/*     */               continue;
/*     */             case 'v':
/* 150 */               sb.append('\013');
/*     */               continue;
/*     */             case '\\':
/* 153 */               sb.append('\\');
/*     */               continue;
/*     */           } 
/* 156 */           sb.append('\\');
/* 157 */           sb.append(c);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 161 */       sb.append(c);
/*     */     } 
/*     */     
/* 164 */     if (sb.length() != 0) {
/* 165 */       FormatSpec spec = new FormatSpec(this.dfs);
/* 166 */       spec.conversionCharacter = Character.MIN_VALUE;
/* 167 */       spec.literal = sb.toString();
/* 168 */       this.conversions.add(spec);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void consumeNextSpec() {
/* 173 */     if (consumeIf('%')) {
/*     */       
/* 175 */       this.currentSpec = new FormatSpec(this.dfs);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       consumePosition();
/* 181 */       consumeFlags();
/* 182 */       consumeFieldWidth();
/* 183 */       consumePrecision();
/* 184 */       consumeSizeFlags();
/* 185 */       consumeConversionCharacter();
/*     */       
/* 187 */       if (this.currentSpec.conversionCharacter == '%') {
/* 188 */         FormatSpec spec = new FormatSpec(this.dfs);
/* 189 */         spec.conversionCharacter = Character.MIN_VALUE;
/* 190 */         spec.literal = "%";
/* 191 */         this.conversions.add(spec);
/*     */         
/*     */         return;
/*     */       } 
/* 195 */       if (this.currentSpec.leadingZeros && this.currentSpec.leftJustify) {
/* 196 */         this.currentSpec.leadingZeros = false;
/*     */       }
/* 198 */       if (this.currentSpec.precisionSet && this.currentSpec.leadingZeros) {
/* 199 */         switch (this.currentSpec.conversionCharacter) {
/*     */           case 'd':
/*     */           case 'i':
/*     */           case 'o':
/*     */           case 'x':
/* 204 */             this.currentSpec.leadingZeros = false;
/*     */             break;
/*     */         } 
/*     */       
/*     */       }
/* 209 */       if (this.currentSpec.conversionCharacter == 'u') {
/* 210 */         this.currentSpec.leadingSign = false;
/* 211 */         this.currentSpec.leadingSpace = false;
/*     */       } 
/*     */       
/* 214 */       if (this.currentSpec.conversionCharacter == 'p') {
/* 215 */         this.currentSpec.fieldWidth = 8;
/* 216 */         this.currentSpec.fieldWidthSet = true;
/* 217 */         this.currentSpec.leadingZeros = true;
/*     */       } 
/*     */       
/* 220 */       if (!this.currentSpec.positionalSpecification) {
/* 221 */         this.currentSpec.argumentPosition = this.currentArgumentIndex++;
/*     */       }
/*     */       
/* 224 */       setArgumentType(this.currentSpec.argumentPosition, this.currentSpec.getArgumentType());
/* 225 */       this.conversions.add(this.currentSpec);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setArgumentType(int argumentIndex, ArgumentType argumentType) {
/* 230 */     while (this.argumentTypes.size() < argumentIndex) {
/* 231 */       this.argumentTypes.add(ArgumentType.UNUSED);
/*     */     }
/* 233 */     if (argumentIndex == this.argumentTypes.size()) {
/* 234 */       this.argumentTypes.add(argumentType);
/*     */     } else {
/* 236 */       this.argumentTypes.set(argumentIndex, argumentType);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void consumePosition() {
/* 241 */     int argumentIndex = maybeConsumeArgumentIndex();
/* 242 */     if (argumentIndex != -1) {
/* 243 */       this.currentSpec.positionalSpecification = true;
/* 244 */       this.currentSpec.argumentPosition = argumentIndex;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void consumeFlags() {
/* 249 */     while (hasMoreChars()) {
/* 250 */       char c = peek();
/* 251 */       if (c == '\'') {
/* 252 */         this.currentSpec.thousands = true;
/*     */       }
/* 254 */       else if (c == '-') {
/* 255 */         this.currentSpec.leftJustify = true;
/* 256 */         this.currentSpec.leadingZeros = false;
/*     */       }
/* 258 */       else if (c == '+') {
/* 259 */         this.currentSpec.leadingSign = true;
/* 260 */         this.currentSpec.leadingSpace = false;
/*     */       }
/* 262 */       else if (c == ' ') {
/* 263 */         if (!this.currentSpec.leadingSign) {
/* 264 */           this.currentSpec.leadingSpace = true;
/*     */         }
/* 266 */       } else if (c == '#') {
/* 267 */         this.currentSpec.alternateForm = true;
/*     */       }
/* 269 */       else if (c == '0') {
/* 270 */         if (!this.currentSpec.leftJustify) {
/* 271 */           this.currentSpec.leadingZeros = true;
/*     */         }
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */       
/* 277 */       this.currentPos++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void consumeFieldWidth() {
/* 285 */     this.currentSpec.fieldWidth = 0;
/* 286 */     this.currentSpec.fieldWidthSet = false;
/*     */     
/* 288 */     if (consumeIf('*')) {
/* 289 */       this.currentSpec.fieldWidthSet = true;
/* 290 */       this.currentSpec.variableFieldWidth = true;
/*     */       
/* 292 */       int fieldWidthArgumentIndex = maybeConsumeArgumentIndex();
/* 293 */       if (fieldWidthArgumentIndex != -1) {
/* 294 */         this.currentSpec.argumentPositionForFieldWidth = fieldWidthArgumentIndex;
/*     */       } else {
/* 296 */         this.currentSpec.argumentPositionForFieldWidth = this.currentArgumentIndex++;
/*     */       } 
/*     */       
/* 299 */       setArgumentType(this.currentSpec.argumentPositionForFieldWidth, ArgumentType.INTEGER);
/*     */     } else {
/*     */       
/* 302 */       int digitCount = peekDigitCount();
/* 303 */       if (digitCount > 0) {
/* 304 */         this.currentSpec.fieldWidth = consumeDigits(digitCount);
/* 305 */         this.currentSpec.fieldWidthSet = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void consumePrecision() {
/* 314 */     if (consumeIf('.')) {
/* 315 */       this.currentSpec.precisionSet = true;
/*     */       
/* 317 */       if (consumeIf('*')) {
/* 318 */         this.currentSpec.variablePrecision = true;
/*     */         
/* 320 */         int precisionArgumentIndex = maybeConsumeArgumentIndex();
/* 321 */         if (precisionArgumentIndex != -1) {
/* 322 */           this.currentSpec.argumentPositionForPrecision = precisionArgumentIndex;
/*     */         } else {
/* 324 */           this.currentSpec.argumentPositionForPrecision = this.currentArgumentIndex++;
/*     */         } 
/*     */         
/* 327 */         setArgumentType(this.currentSpec.argumentPositionForPrecision, ArgumentType.INTEGER);
/*     */       } else {
/*     */         
/* 330 */         int digitCount = peekDigitCount();
/* 331 */         if (digitCount == 0) {
/* 332 */           this.currentSpec.precision = 0;
/*     */         } else {
/* 334 */           this.currentSpec.precision = consumeDigits(digitCount);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void consumeSizeFlags() {
/* 350 */     if (!consumeIf('z'))
/*     */     {
/*     */ 
/*     */       
/* 354 */       if (consumeIf('h')) {
/* 355 */         this.currentSpec.optionalh = true;
/*     */         
/* 357 */         consumeIf('h');
/*     */       }
/* 359 */       else if (consumeIf('l')) {
/* 360 */         this.currentSpec.optionall = true;
/*     */         
/* 362 */         consumeIf('l');
/*     */       }
/* 364 */       else if (consumeIf('L')) {
/* 365 */         this.currentSpec.optionalL = true;
/*     */         
/* 367 */         consumeIf('L');
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void consumeConversionCharacter() {
/* 374 */     this.currentSpec.conversionCharacter = next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int maybeConsumeArgumentIndex() {
/* 383 */     int digitCount = peekDigitCount();
/*     */     
/* 385 */     if (digitCount > 0 && this.formatString.charAt(this.currentPos + digitCount) == '$') {
/* 386 */       int argumentIndex = consumeDigits(digitCount) - 1;
/* 387 */       this.currentPos++;
/* 388 */       return argumentIndex;
/*     */     } 
/* 390 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int peekDigitCount() {
/* 398 */     int digitCount = 0;
/* 399 */     while (this.currentPos + digitCount < this.formatString.length() && 
/* 400 */       Character.isDigit(this.formatString.charAt(this.currentPos + digitCount))) {
/* 401 */       digitCount++;
/*     */     }
/* 403 */     return digitCount;
/*     */   }
/*     */   
/*     */   private int consumeDigits(int digitCount) {
/* 407 */     int number = Integer.parseInt(this.formatString.substring(this.currentPos, this.currentPos + digitCount));
/* 408 */     this.currentPos += digitCount;
/* 409 */     return number;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasMoreChars() {
/* 414 */     return (this.currentPos < this.formatString.length());
/*     */   }
/*     */   
/*     */   private char peek() {
/* 418 */     return this.formatString.charAt(this.currentPos);
/*     */   }
/*     */   
/*     */   private void pushBack() {
/* 422 */     this.currentPos--;
/*     */   }
/*     */   
/*     */   private char next() {
/* 426 */     return this.formatString.charAt(this.currentPos++);
/*     */   }
/*     */   
/*     */   private boolean consumeIf(char c) {
/* 430 */     if (this.formatString.charAt(this.currentPos) == c) {
/* 431 */       this.currentPos++;
/* 432 */       return true;
/*     */     } 
/* 434 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ArgumentType> getArgumentTypes() {
/* 439 */     return this.argumentTypes;
/*     */   }
/*     */   
/*     */   public ArgumentType getArgumentType(int i) {
/* 443 */     if (i < this.argumentTypes.size()) {
/* 444 */       return this.argumentTypes.get(i);
/*     */     }
/* 446 */     return ArgumentType.UNUSED;
/*     */   }
/*     */ 
/*     */   
/*     */   public String format(FormatInput input) {
/* 451 */     StringBuilder result = new StringBuilder();
/* 452 */     for (FormatSpec conversion : this.conversions) {
/* 453 */       result.append(conversion.format(input));
/*     */     }
/* 455 */     return result.toString();
/*     */   }
/*     */   
/*     */   public static String format(String formatString, Object... arguments) {
/* 459 */     return (new Formatter(formatString)).format(new FormatArrayInput(arguments));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/format/Formatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */