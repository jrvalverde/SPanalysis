/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Realloc
/*     */ {
/*     */   public static double[] realloc(double[] p, int offset, int newCount) {
/*  28 */     double[] np = new double[newCount];
/*  29 */     if (p != null) {
/*  30 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  32 */     return np;
/*     */   }
/*     */ 
/*     */   
/*     */   public static char[] realloc(char[] p, int offset, int newCount) {
/*  37 */     char[] np = new char[newCount];
/*  38 */     if (p != null) {
/*  39 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  41 */     return np;
/*     */   }
/*     */   
/*     */   public static int[] realloc(int[] p, int offset, int newCount) {
/*  45 */     int[] np = new int[newCount];
/*  46 */     if (p != null) {
/*  47 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  49 */     return np;
/*     */   }
/*     */   
/*     */   public static long[] realloc(long[] p, int offset, int newCount) {
/*  53 */     long[] np = new long[newCount];
/*  54 */     if (p != null) {
/*  55 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  57 */     return np;
/*     */   }
/*     */   
/*     */   public static boolean[] realloc(boolean[] p, int offset, int newCount) {
/*  61 */     boolean[] np = new boolean[newCount];
/*  62 */     if (p != null) {
/*  63 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  65 */     return np;
/*     */   }
/*     */   
/*     */   public static float[] realloc(float[] p, int offset, int newCount) {
/*  69 */     float[] np = new float[newCount];
/*  70 */     if (p != null) {
/*  71 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  73 */     return np;
/*     */   }
/*     */   
/*     */   public static short[] realloc(short[] p, int offset, int newCount) {
/*  77 */     short[] np = new short[newCount];
/*  78 */     if (p != null) {
/*  79 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  81 */     return np;
/*     */   }
/*     */   
/*     */   public static byte[] realloc(byte[] p, int offset, int newCount) {
/*  85 */     byte[] np = new byte[newCount];
/*  86 */     if (p != null) {
/*  87 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  89 */     return np;
/*     */   }
/*     */   
/*     */   public static Object[] realloc(Object[] p, int offset, int newCount) {
/*  93 */     Object[] np = new Object[newCount];
/*  94 */     if (p != null) {
/*  95 */       System.arraycopy(p, offset, np, 0, Math.min(p.length - offset, newCount));
/*     */     }
/*  97 */     return np;
/*     */   }
/*     */   
/*     */   public static Object realloc(Object p, int newSize) {
/* 101 */     if (p instanceof Ptr) {
/* 102 */       return ((Ptr)p).realloc(newSize);
/*     */     }
/* 104 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Realloc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */