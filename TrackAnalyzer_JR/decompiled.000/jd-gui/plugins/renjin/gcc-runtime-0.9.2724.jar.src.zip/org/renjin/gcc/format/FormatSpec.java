/*      */ package org.renjin.gcc.format;
/*      */ 
/*      */ import java.text.DecimalFormatSymbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class FormatSpec
/*      */ {
/*      */   private static final int DOUBLE_SIGNIFICAND_WIDTH = 53;
/*      */   public static final long DOUBLE_SIGNIF_BIT_MASK = 4503599627370495L;
/*      */   public static final long DOUBLE_SIGN_BIT_MASK = -9223372036854775808L;
/*      */   public static final long DOUBLE_EXP_BIT_MASK = 9218868437227405312L;
/*      */   private final DecimalFormatSymbols dfs;
/*      */   boolean thousands = false;
/*      */   boolean leftJustify = false;
/*      */   boolean leadingSign = false;
/*      */   boolean leadingSpace = false;
/*      */   boolean alternateForm = false;
/*      */   boolean leadingZeros = false;
/*      */   boolean variableFieldWidth = false;
/*  132 */   int fieldWidth = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean fieldWidthSet = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  147 */   int precision = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int defaultDigits = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean variablePrecision = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean precisionSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean positionalSpecification;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int argumentPosition;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int argumentPositionForFieldWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int argumentPositionForPrecision;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean optionalh = false;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean optionall = false;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean optionalL = false;
/*      */ 
/*      */ 
/*      */   
/*  198 */   char conversionCharacter = Character.MIN_VALUE;
/*      */ 
/*      */   
/*      */   String literal;
/*      */ 
/*      */ 
/*      */   
/*      */   FormatSpec(DecimalFormatSymbols dfs) {
/*  206 */     this.dfs = dfs;
/*      */   }
/*      */   
/*      */   public Formatter.ArgumentType getArgumentType() {
/*  210 */     switch (this.conversionCharacter) {
/*      */       case 'X':
/*      */       case 'b':
/*      */       case 'd':
/*      */       case 'i':
/*      */       case 'o':
/*      */       case 'u':
/*      */       case 'x':
/*  218 */         if (this.optionall) {
/*  219 */           return Formatter.ArgumentType.LONG;
/*      */         }
/*  221 */         return Formatter.ArgumentType.INTEGER;
/*      */ 
/*      */       
/*      */       case 'c':
/*  225 */         return Formatter.ArgumentType.INTEGER;
/*      */       
/*      */       case 'A':
/*      */       case 'E':
/*      */       case 'G':
/*      */       case 'a':
/*      */       case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*  234 */         return Formatter.ArgumentType.DOUBLE;
/*      */       
/*      */       case 'p':
/*  237 */         return Formatter.ArgumentType.POINTER;
/*      */       
/*      */       case 's':
/*  240 */         return Formatter.ArgumentType.STRING;
/*      */     } 
/*      */     
/*  243 */     throw new IllegalArgumentException("Invalid conversion character '" + this.conversionCharacter + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String format(FormatInput input) {
/*  250 */     if (this.literal != null) {
/*  251 */       return this.literal;
/*      */     }
/*      */     
/*  254 */     if (input.isNA(this.argumentPosition)) {
/*  255 */       return "NA";
/*      */     }
/*      */     
/*  258 */     if (this.variableFieldWidth) {
/*  259 */       int providedWidth = input.getInt(this.argumentPositionForFieldWidth);
/*  260 */       this.leftJustify = (providedWidth < 0);
/*  261 */       this.fieldWidth = Math.abs(providedWidth);
/*      */     } 
/*  263 */     if (this.variablePrecision) {
/*  264 */       this.precision = input.getInt(this.argumentPositionForPrecision);
/*  265 */       if (this.precision < 0) {
/*  266 */         this.precision = 0;
/*      */       }
/*      */     } 
/*      */     
/*  270 */     switch (this.conversionCharacter) {
/*      */       case 'd':
/*      */       case 'i':
/*  273 */         if (this.optionall) {
/*  274 */           return printDFormat(input.getLong(this.argumentPosition));
/*      */         }
/*  276 */         return printDFormat(input.getInt(this.argumentPosition));
/*      */       
/*      */       case 'u':
/*  279 */         if (this.optionall) {
/*  280 */           return printDFormat(Long.toUnsignedString(input.getUnsignedLong(this.argumentPosition)));
/*      */         }
/*  282 */         return printDFormat(Integer.toUnsignedString(input.getInt(this.argumentPosition)));
/*      */ 
/*      */       
/*      */       case 'o':
/*  286 */         if (this.optionall) {
/*  287 */           return printOFormat(input.getLong(this.argumentPosition));
/*      */         }
/*  289 */         return printOFormat(input.getInt(this.argumentPosition));
/*      */ 
/*      */       
/*      */       case 'p':
/*  293 */         return printXFormat(input.getInt(this.argumentPosition));
/*      */       
/*      */       case 'b':
/*  296 */         if (this.optionall) {
/*  297 */           return printBFormat(input.getLong(this.argumentPosition));
/*      */         }
/*  299 */         return printBFormat(input.getInt(this.argumentPosition));
/*      */ 
/*      */       
/*      */       case 'X':
/*      */       case 'x':
/*  304 */         if (this.optionall) {
/*  305 */           return printXFormat(input.getUnsignedLong(this.argumentPosition));
/*      */         }
/*  307 */         return printXFormat(input.getInt(this.argumentPosition));
/*      */ 
/*      */       
/*      */       case 'f':
/*  311 */         return printFFormat(input.getDouble(this.argumentPosition));
/*      */       
/*      */       case 'E':
/*      */       case 'e':
/*  315 */         return printEFormat(input.getDouble(this.argumentPosition));
/*      */       
/*      */       case 'G':
/*      */       case 'g':
/*  319 */         return printGFormat(input.getDouble(this.argumentPosition));
/*      */       
/*      */       case 'A':
/*      */       case 'a':
/*  323 */         return printAFormat(input.getDouble(this.argumentPosition));
/*      */       
/*      */       case 'c':
/*  326 */         return printCFormat((char)input.getInt(this.argumentPosition));
/*      */       
/*      */       case 's':
/*  329 */         return formatArgument(input.getString(this.argumentPosition));
/*      */     } 
/*      */     
/*  332 */     throw new IllegalArgumentException("Invalid conversion character '" + this.conversionCharacter + "'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String formatArgument(String s) {
/*  346 */     String s2 = "";
/*  347 */     if (this.conversionCharacter == 's' || this.conversionCharacter == 'S') {
/*      */       
/*  349 */       s2 = printSFormat(s);
/*      */     } else {
/*  351 */       throw new IllegalArgumentException("Cannot format a String with a format using a " + this.conversionCharacter + " conversion character.");
/*      */     } 
/*      */ 
/*      */     
/*  355 */     return s2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] fFormatDigits(double x) {
/*      */     String sx;
/*      */     int n1In, n2In, p;
/*      */     char[] ca3, ca4, ca5;
/*  386 */     int expon = 0;
/*  387 */     boolean minusSign = false;
/*  388 */     if (x > 0.0D) {
/*  389 */       sx = Double.toString(x);
/*  390 */     } else if (x < 0.0D) {
/*  391 */       sx = Double.toString(-x);
/*  392 */       minusSign = true;
/*      */     } else {
/*  394 */       sx = Double.toString(x);
/*  395 */       if (sx.charAt(0) == '-') {
/*  396 */         minusSign = true;
/*  397 */         sx = sx.substring(1);
/*      */       } 
/*      */     } 
/*  400 */     int ePos = sx.indexOf('E');
/*  401 */     int rPos = sx.indexOf('.');
/*  402 */     if (rPos != -1) {
/*  403 */       n1In = rPos;
/*  404 */     } else if (ePos != -1) {
/*  405 */       n1In = ePos;
/*      */     } else {
/*  407 */       n1In = sx.length();
/*      */     } 
/*  409 */     if (rPos != -1) {
/*  410 */       if (ePos != -1) {
/*  411 */         n2In = ePos - rPos - 1;
/*      */       } else {
/*  413 */         n2In = sx.length() - rPos - 1;
/*      */       } 
/*      */     } else {
/*  416 */       n2In = 0;
/*      */     } 
/*  418 */     if (ePos != -1) {
/*  419 */       int ie = ePos + 1;
/*  420 */       expon = 0;
/*  421 */       if (sx.charAt(ie) == '-') {
/*  422 */         for (; ++ie < sx.length() && 
/*  423 */           sx.charAt(ie) == '0'; ie++);
/*      */ 
/*      */ 
/*      */         
/*  427 */         if (ie < sx.length()) {
/*  428 */           expon = -Integer.parseInt(sx.substring(ie));
/*      */         }
/*      */       } else {
/*  431 */         if (sx.charAt(ie) == '+') {
/*  432 */           ie++;
/*      */         }
/*  434 */         for (; ie < sx.length() && 
/*  435 */           sx.charAt(ie) == '0'; ie++);
/*      */ 
/*      */ 
/*      */         
/*  439 */         if (ie < sx.length()) {
/*  440 */           expon = Integer.parseInt(sx.substring(ie));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  445 */     if (this.precisionSet) {
/*  446 */       p = this.precision;
/*      */     } else {
/*  448 */       p = 6;
/*      */     } 
/*  450 */     char[] ca1 = sx.toCharArray();
/*  451 */     char[] ca2 = new char[n1In + n2In];
/*      */     int j;
/*  453 */     for (j = 0; j < n1In; j++) {
/*  454 */       ca2[j] = ca1[j];
/*      */     }
/*  456 */     int i = j + 1; int k;
/*  457 */     for (k = 0; k < n2In; j++, i++, k++) {
/*  458 */       ca2[j] = ca1[i];
/*      */     }
/*  460 */     if (n1In + expon <= 0) {
/*  461 */       ca3 = new char[-expon + n2In];
/*  462 */       for (j = 0, k = 0; k < -n1In - expon; k++, j++) {
/*  463 */         ca3[j] = '0';
/*      */       }
/*  465 */       for (i = 0; i < n1In + n2In; i++, j++) {
/*  466 */         ca3[j] = ca2[i];
/*      */       }
/*      */     } else {
/*  469 */       ca3 = ca2;
/*      */     } 
/*  471 */     boolean carry = false;
/*  472 */     if (p < -expon + n2In) {
/*  473 */       if (expon < 0) {
/*  474 */         i = p;
/*      */       } else {
/*  476 */         i = p + n1In;
/*      */       } 
/*  478 */       carry = checkForCarry(ca3, i);
/*  479 */       if (carry) {
/*  480 */         carry = startSymbolicCarry(ca3, i - 1, 0);
/*      */       }
/*      */     } 
/*  483 */     if (n1In + expon <= 0) {
/*  484 */       ca4 = new char[2 + p];
/*  485 */       if (!carry) {
/*  486 */         ca4[0] = '0';
/*      */       } else {
/*  488 */         ca4[0] = '1';
/*      */       } 
/*  490 */       if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*  491 */         ca4[1] = '.';
/*  492 */         for (i = 0, j = 2; i < Math.min(p, ca3.length); i++, j++) {
/*  493 */           ca4[j] = ca3[i];
/*      */         }
/*  495 */         for (; j < ca4.length; j++) {
/*  496 */           ca4[j] = '0';
/*      */         }
/*      */       } 
/*      */     } else {
/*  500 */       if (!carry) {
/*  501 */         if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*      */           
/*  503 */           ca4 = new char[n1In + expon + p + 1];
/*      */         } else {
/*  505 */           ca4 = new char[n1In + expon];
/*      */         } 
/*  507 */         j = 0;
/*      */       } else {
/*  509 */         if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*      */           
/*  511 */           ca4 = new char[n1In + expon + p + 2];
/*      */         } else {
/*  513 */           ca4 = new char[n1In + expon + 1];
/*      */         } 
/*  515 */         ca4[0] = '1';
/*  516 */         j = 1;
/*      */       } 
/*  518 */       for (i = 0; i < Math.min(n1In + expon, ca3.length); i++, j++) {
/*  519 */         ca4[j] = ca3[i];
/*      */       }
/*  521 */       for (; i < n1In + expon; i++, j++) {
/*  522 */         ca4[j] = '0';
/*      */       }
/*  524 */       if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*  525 */         ca4[j] = '.';
/*  526 */         j++;
/*  527 */         for (k = 0; i < ca3.length && k < p; i++, j++, k++) {
/*  528 */           ca4[j] = ca3[i];
/*      */         }
/*  530 */         for (; j < ca4.length; j++) {
/*  531 */           ca4[j] = '0';
/*      */         }
/*      */       } 
/*      */     } 
/*  535 */     int nZeros = 0;
/*  536 */     if (!this.leftJustify && this.leadingZeros) {
/*  537 */       int xThousands = 0;
/*  538 */       if (this.thousands) {
/*  539 */         int xlead = 0;
/*  540 */         if (ca4[0] == '+' || ca4[0] == '-' || ca4[0] == ' ') {
/*  541 */           xlead = 1;
/*      */         }
/*  543 */         int xdp = xlead;
/*  544 */         for (; xdp < ca4.length && 
/*  545 */           ca4[xdp] != '.'; xdp++);
/*      */ 
/*      */ 
/*      */         
/*  549 */         xThousands = (xdp - xlead) / 3;
/*      */       } 
/*  551 */       if (this.fieldWidthSet) {
/*  552 */         nZeros = this.fieldWidth - ca4.length;
/*      */       }
/*  554 */       if ((!minusSign && (this.leadingSign || this.leadingSpace)) || minusSign) {
/*  555 */         nZeros--;
/*      */       }
/*  557 */       nZeros -= xThousands;
/*  558 */       if (nZeros < 0) {
/*  559 */         nZeros = 0;
/*      */       }
/*      */     } 
/*  562 */     j = 0;
/*  563 */     if ((!minusSign && (this.leadingSign || this.leadingSpace)) || minusSign) {
/*  564 */       ca5 = new char[ca4.length + nZeros + 1];
/*  565 */       j++;
/*      */     } else {
/*  567 */       ca5 = new char[ca4.length + nZeros];
/*      */     } 
/*  569 */     if (!minusSign) {
/*  570 */       if (this.leadingSign) {
/*  571 */         ca5[0] = '+';
/*      */       }
/*  573 */       if (this.leadingSpace) {
/*  574 */         ca5[0] = ' ';
/*      */       }
/*      */     } else {
/*  577 */       ca5[0] = '-';
/*      */     } 
/*  579 */     for (i = 0; i < nZeros; i++, j++) {
/*  580 */       ca5[j] = '0';
/*      */     }
/*  582 */     for (i = 0; i < ca4.length; i++, j++) {
/*  583 */       ca5[j] = ca4[i];
/*      */     }
/*      */     
/*  586 */     int lead = 0;
/*  587 */     if (ca5[0] == '+' || ca5[0] == '-' || ca5[0] == ' ') {
/*  588 */       lead = 1;
/*      */     }
/*  590 */     int dp = lead;
/*  591 */     for (; dp < ca5.length && 
/*  592 */       ca5[dp] != '.'; dp++);
/*      */ 
/*      */ 
/*      */     
/*  596 */     int nThousands = (dp - lead) / 3;
/*      */     
/*  598 */     if (dp < ca5.length) {
/*  599 */       ca5[dp] = this.dfs.getDecimalSeparator();
/*      */     }
/*  601 */     char[] ca6 = ca5;
/*  602 */     if (this.thousands && nThousands > 0) {
/*  603 */       ca6 = new char[ca5.length + nThousands + lead];
/*  604 */       ca6[0] = ca5[0];
/*  605 */       for (i = lead, k = lead; i < dp; i++) {
/*  606 */         if (i > 0 && (dp - i) % 3 == 0) {
/*      */           
/*  608 */           ca6[k] = this.dfs.getGroupingSeparator();
/*  609 */           ca6[k + 1] = ca5[i];
/*  610 */           k += 2;
/*      */         } else {
/*  612 */           ca6[k] = ca5[i];
/*  613 */           k++;
/*      */         } 
/*      */       } 
/*  616 */       for (; i < ca5.length; i++, k++) {
/*  617 */         ca6[k] = ca5[i];
/*      */       }
/*      */     } 
/*  620 */     return ca6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String fFormatString(double x) {
/*      */     char[] ca6;
/*  634 */     boolean noDigits = false;
/*      */     
/*  636 */     if (Double.isInfinite(x)) {
/*  637 */       if (x == Double.POSITIVE_INFINITY) {
/*  638 */         if (this.leadingSign) {
/*  639 */           ca6 = "+Inf".toCharArray();
/*  640 */         } else if (this.leadingSpace) {
/*  641 */           ca6 = " Inf".toCharArray();
/*      */         } else {
/*  643 */           ca6 = "Inf".toCharArray();
/*      */         } 
/*      */       } else {
/*  646 */         ca6 = "-Inf".toCharArray();
/*      */       } 
/*  648 */       noDigits = true;
/*  649 */     } else if (Double.isNaN(x)) {
/*  650 */       if (this.leadingSign) {
/*  651 */         ca6 = "+NaN".toCharArray();
/*  652 */       } else if (this.leadingSpace) {
/*  653 */         ca6 = " NaN".toCharArray();
/*      */       } else {
/*  655 */         ca6 = "NaN".toCharArray();
/*      */       } 
/*  657 */       noDigits = true;
/*      */     } else {
/*  659 */       ca6 = fFormatDigits(x);
/*      */     } 
/*  661 */     char[] ca7 = applyFloatPadding(ca6, false);
/*  662 */     return new String(ca7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] eFormatDigits(double x, char eChar) {
/*      */     char[] ca1, ca2, ca3;
/*      */     String sx;
/*  701 */     int p, eSize, expon = 0;
/*      */     
/*  703 */     boolean minusSign = false;
/*  704 */     if (x > 0.0D) {
/*  705 */       sx = Double.toString(x);
/*  706 */     } else if (x < 0.0D) {
/*  707 */       sx = Double.toString(-x);
/*  708 */       minusSign = true;
/*      */     } else {
/*  710 */       sx = Double.toString(x);
/*  711 */       if (sx.charAt(0) == '-') {
/*  712 */         minusSign = true;
/*  713 */         sx = sx.substring(1);
/*      */       } 
/*      */     } 
/*  716 */     int ePos = sx.indexOf('E');
/*  717 */     if (ePos == -1) {
/*  718 */       ePos = sx.indexOf('e');
/*      */     }
/*  720 */     int rPos = sx.indexOf('.');
/*  721 */     if (rPos != -1) {
/*  722 */       int n1In = rPos;
/*  723 */     } else if (ePos != -1) {
/*  724 */       int n1In = ePos;
/*      */     } else {
/*  726 */       int n1In = sx.length();
/*      */     } 
/*  728 */     if (rPos != -1) {
/*  729 */       if (ePos != -1) {
/*  730 */         int n2In = ePos - rPos - 1;
/*      */       } else {
/*  732 */         int n2In = sx.length() - rPos - 1;
/*      */       } 
/*      */     } else {
/*  735 */       int n2In = 0;
/*      */     } 
/*  737 */     if (ePos != -1) {
/*  738 */       int ie = ePos + 1;
/*  739 */       expon = 0;
/*  740 */       if (sx.charAt(ie) == '-') {
/*  741 */         for (; ++ie < sx.length() && 
/*  742 */           sx.charAt(ie) == '0'; ie++);
/*      */ 
/*      */ 
/*      */         
/*  746 */         if (ie < sx.length()) {
/*  747 */           expon = -Integer.parseInt(sx.substring(ie));
/*      */         }
/*      */       } else {
/*  750 */         if (sx.charAt(ie) == '+') {
/*  751 */           ie++;
/*      */         }
/*  753 */         for (; ie < sx.length() && 
/*  754 */           sx.charAt(ie) == '0'; ie++);
/*      */ 
/*      */ 
/*      */         
/*  758 */         if (ie < sx.length()) {
/*  759 */           expon = Integer.parseInt(sx.substring(ie));
/*      */         }
/*      */       } 
/*      */     } 
/*  763 */     if (rPos != -1) {
/*  764 */       expon += rPos - 1;
/*      */     }
/*  766 */     if (this.precisionSet) {
/*  767 */       p = this.precision;
/*      */     } else {
/*  769 */       p = 6;
/*      */     } 
/*  771 */     if (rPos != -1 && ePos != -1) {
/*      */       
/*  773 */       ca1 = (sx.substring(0, rPos) + sx.substring(rPos + 1, ePos)).toCharArray();
/*  774 */     } else if (rPos != -1) {
/*      */       
/*  776 */       ca1 = (sx.substring(0, rPos) + sx.substring(rPos + 1)).toCharArray();
/*  777 */     } else if (ePos != -1) {
/*  778 */       ca1 = sx.substring(0, ePos).toCharArray();
/*      */     } else {
/*  780 */       ca1 = sx.toCharArray();
/*      */     } 
/*  782 */     boolean carry = false;
/*  783 */     int i0 = 0;
/*  784 */     if (ca1[0] != '0') {
/*  785 */       i0 = 0;
/*      */     } else {
/*  787 */       for (i0 = 0; i0 < ca1.length && 
/*  788 */         ca1[i0] == '0'; i0++);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  793 */     if (i0 + p < ca1.length - 1) {
/*  794 */       carry = checkForCarry(ca1, i0 + p + 1);
/*  795 */       if (carry) {
/*  796 */         carry = startSymbolicCarry(ca1, i0 + p, i0);
/*      */       }
/*  798 */       if (carry) {
/*  799 */         ca2 = new char[i0 + p + 1];
/*  800 */         ca2[i0] = '1';
/*  801 */         for (j = 0; j < i0; j++) {
/*  802 */           ca2[j] = '0';
/*      */         }
/*  804 */         for (i = i0, j = i0 + 1; j < p + 1; i++, j++) {
/*  805 */           ca2[j] = ca1[i];
/*      */         }
/*  807 */         expon++;
/*  808 */         ca1 = ca2;
/*      */       } 
/*      */     } 
/*  811 */     if (Math.abs(expon) < 100 && !this.optionalL) {
/*  812 */       eSize = 4;
/*      */     } else {
/*  814 */       eSize = 5;
/*      */     } 
/*  816 */     if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*  817 */       ca2 = new char[2 + p + eSize];
/*      */     } else {
/*  819 */       ca2 = new char[1 + eSize];
/*      */     } 
/*  821 */     if (ca1[0] != '0') {
/*  822 */       ca2[0] = ca1[0];
/*  823 */       j = 1;
/*      */     } else {
/*  825 */       for (j = 1; j < ((ePos == -1) ? ca1.length : ePos) && 
/*  826 */         ca1[j] == '0'; j++);
/*      */ 
/*      */ 
/*      */       
/*  830 */       if ((ePos != -1 && j < ePos) || (ePos == -1 && j < ca1.length)) {
/*      */         
/*  832 */         ca2[0] = ca1[j];
/*  833 */         expon -= j;
/*  834 */         j++;
/*      */       } else {
/*  836 */         ca2[0] = '0';
/*  837 */         j = 2;
/*      */       } 
/*      */     } 
/*  840 */     if (this.alternateForm || !this.precisionSet || this.precision != 0) {
/*  841 */       ca2[1] = '.';
/*  842 */       i = 2;
/*      */     } else {
/*  844 */       i = 1;
/*      */     }  int k;
/*  846 */     for (k = 0; k < p && j < ca1.length; j++, i++, k++) {
/*  847 */       ca2[i] = ca1[j];
/*      */     }
/*  849 */     for (; i < ca2.length - eSize; i++) {
/*  850 */       ca2[i] = '0';
/*      */     }
/*  852 */     ca2[i++] = eChar;
/*  853 */     if (expon < 0) {
/*  854 */       ca2[i++] = '-';
/*      */     } else {
/*  856 */       ca2[i++] = '+';
/*      */     } 
/*  858 */     expon = Math.abs(expon);
/*  859 */     if (expon >= 100) {
/*  860 */       switch (expon / 100) {
/*      */         case 1:
/*  862 */           ca2[i] = '1';
/*      */           break;
/*      */         case 2:
/*  865 */           ca2[i] = '2';
/*      */           break;
/*      */         case 3:
/*  868 */           ca2[i] = '3';
/*      */           break;
/*      */         case 4:
/*  871 */           ca2[i] = '4';
/*      */           break;
/*      */         case 5:
/*  874 */           ca2[i] = '5';
/*      */           break;
/*      */         case 6:
/*  877 */           ca2[i] = '6';
/*      */           break;
/*      */         case 7:
/*  880 */           ca2[i] = '7';
/*      */           break;
/*      */         case 8:
/*  883 */           ca2[i] = '8';
/*      */           break;
/*      */         case 9:
/*  886 */           ca2[i] = '9';
/*      */           break;
/*      */       } 
/*  889 */       i++;
/*      */     } 
/*  891 */     switch (expon % 100 / 10) {
/*      */       case 0:
/*  893 */         ca2[i] = '0';
/*      */         break;
/*      */       case 1:
/*  896 */         ca2[i] = '1';
/*      */         break;
/*      */       case 2:
/*  899 */         ca2[i] = '2';
/*      */         break;
/*      */       case 3:
/*  902 */         ca2[i] = '3';
/*      */         break;
/*      */       case 4:
/*  905 */         ca2[i] = '4';
/*      */         break;
/*      */       case 5:
/*  908 */         ca2[i] = '5';
/*      */         break;
/*      */       case 6:
/*  911 */         ca2[i] = '6';
/*      */         break;
/*      */       case 7:
/*  914 */         ca2[i] = '7';
/*      */         break;
/*      */       case 8:
/*  917 */         ca2[i] = '8';
/*      */         break;
/*      */       case 9:
/*  920 */         ca2[i] = '9';
/*      */         break;
/*      */     } 
/*  923 */     i++;
/*  924 */     switch (expon % 10) {
/*      */       case 0:
/*  926 */         ca2[i] = '0';
/*      */         break;
/*      */       case 1:
/*  929 */         ca2[i] = '1';
/*      */         break;
/*      */       case 2:
/*  932 */         ca2[i] = '2';
/*      */         break;
/*      */       case 3:
/*  935 */         ca2[i] = '3';
/*      */         break;
/*      */       case 4:
/*  938 */         ca2[i] = '4';
/*      */         break;
/*      */       case 5:
/*  941 */         ca2[i] = '5';
/*      */         break;
/*      */       case 6:
/*  944 */         ca2[i] = '6';
/*      */         break;
/*      */       case 7:
/*  947 */         ca2[i] = '7';
/*      */         break;
/*      */       case 8:
/*  950 */         ca2[i] = '8';
/*      */         break;
/*      */       case 9:
/*  953 */         ca2[i] = '9';
/*      */         break;
/*      */     } 
/*  956 */     int nZeros = 0;
/*  957 */     if (!this.leftJustify && this.leadingZeros) {
/*  958 */       int xThousands = 0;
/*  959 */       if (this.thousands) {
/*  960 */         int xlead = 0;
/*  961 */         if (ca2[0] == '+' || ca2[0] == '-' || ca2[0] == ' ') {
/*  962 */           xlead = 1;
/*      */         }
/*  964 */         int xdp = xlead;
/*  965 */         for (; xdp < ca2.length && 
/*  966 */           ca2[xdp] != '.'; xdp++);
/*      */ 
/*      */ 
/*      */         
/*  970 */         xThousands = (xdp - xlead) / 3;
/*      */       } 
/*  972 */       if (this.fieldWidthSet) {
/*  973 */         nZeros = this.fieldWidth - ca2.length;
/*      */       }
/*  975 */       if ((!minusSign && (this.leadingSign || this.leadingSpace)) || minusSign) {
/*  976 */         nZeros--;
/*      */       }
/*  978 */       nZeros -= xThousands;
/*  979 */       if (nZeros < 0) {
/*  980 */         nZeros = 0;
/*      */       }
/*      */     } 
/*  983 */     int j = 0;
/*  984 */     if ((!minusSign && (this.leadingSign || this.leadingSpace)) || minusSign) {
/*  985 */       ca3 = new char[ca2.length + nZeros + 1];
/*  986 */       j++;
/*      */     } else {
/*  988 */       ca3 = new char[ca2.length + nZeros];
/*      */     } 
/*  990 */     if (!minusSign) {
/*  991 */       if (this.leadingSign) {
/*  992 */         ca3[0] = '+';
/*      */       }
/*  994 */       if (this.leadingSpace) {
/*  995 */         ca3[0] = ' ';
/*      */       }
/*      */     } else {
/*  998 */       ca3[0] = '-';
/*      */     } 
/* 1000 */     for (k = 0; k < nZeros; j++, k++)
/* 1001 */       ca3[j] = '0'; 
/*      */     int i;
/* 1003 */     for (i = 0; i < ca2.length && j < ca3.length; i++, j++) {
/* 1004 */       ca3[j] = ca2[i];
/*      */     }
/*      */     
/* 1007 */     int lead = 0;
/* 1008 */     if (ca3[0] == '+' || ca3[0] == '-' || ca3[0] == ' ') {
/* 1009 */       lead = 1;
/*      */     }
/* 1011 */     int dp = lead;
/* 1012 */     for (; dp < ca3.length && 
/* 1013 */       ca3[dp] != '.'; dp++);
/*      */ 
/*      */ 
/*      */     
/* 1017 */     int nThousands = dp / 3;
/*      */     
/* 1019 */     if (dp < ca3.length) {
/* 1020 */       ca3[dp] = this.dfs.getDecimalSeparator();
/*      */     }
/* 1022 */     char[] ca4 = ca3;
/* 1023 */     if (this.thousands && nThousands > 0) {
/* 1024 */       ca4 = new char[ca3.length + nThousands + lead];
/* 1025 */       ca4[0] = ca3[0];
/* 1026 */       for (i = lead, k = lead; i < dp; i++) {
/* 1027 */         if (i > 0 && (dp - i) % 3 == 0) {
/*      */           
/* 1029 */           ca4[k] = this.dfs.getGroupingSeparator();
/* 1030 */           ca4[k + 1] = ca3[i];
/* 1031 */           k += 2;
/*      */         } else {
/* 1033 */           ca4[k] = ca3[i];
/* 1034 */           k++;
/*      */         } 
/*      */       } 
/* 1037 */       for (; i < ca3.length; i++, k++) {
/* 1038 */         ca4[k] = ca3[i];
/*      */       }
/*      */     } 
/* 1041 */     return ca4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkForCarry(char[] ca1, int icarry) {
/* 1056 */     boolean carry = false;
/* 1057 */     if (icarry < ca1.length) {
/* 1058 */       if (ca1[icarry] == '6' || ca1[icarry] == '7' || ca1[icarry] == '8' || ca1[icarry] == '9') {
/*      */         
/* 1060 */         carry = true;
/* 1061 */       } else if (ca1[icarry] == '5') {
/* 1062 */         int ii = icarry + 1;
/* 1063 */         for (; ii < ca1.length && 
/* 1064 */           ca1[ii] == '0'; ii++);
/*      */ 
/*      */ 
/*      */         
/* 1068 */         carry = (ii < ca1.length);
/* 1069 */         if (!carry && icarry > 0) {
/* 1070 */           carry = (ca1[icarry - 1] == '1' || ca1[icarry - 1] == '3' || ca1[icarry - 1] == '5' || ca1[icarry - 1] == '7' || ca1[icarry - 1] == '9');
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1076 */     return carry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean startSymbolicCarry(char[] ca, int cLast, int cFirst) {
/* 1095 */     boolean carry = true;
/* 1096 */     for (int i = cLast; carry && i >= cFirst; i--) {
/* 1097 */       carry = false;
/* 1098 */       switch (ca[i]) {
/*      */         case '0':
/* 1100 */           ca[i] = '1';
/*      */           break;
/*      */         case '1':
/* 1103 */           ca[i] = '2';
/*      */           break;
/*      */         case '2':
/* 1106 */           ca[i] = '3';
/*      */           break;
/*      */         case '3':
/* 1109 */           ca[i] = '4';
/*      */           break;
/*      */         case '4':
/* 1112 */           ca[i] = '5';
/*      */           break;
/*      */         case '5':
/* 1115 */           ca[i] = '6';
/*      */           break;
/*      */         case '6':
/* 1118 */           ca[i] = '7';
/*      */           break;
/*      */         case '7':
/* 1121 */           ca[i] = '8';
/*      */           break;
/*      */         case '8':
/* 1124 */           ca[i] = '9';
/*      */           break;
/*      */         case '9':
/* 1127 */           ca[i] = '0';
/* 1128 */           carry = true;
/*      */           break;
/*      */       } 
/*      */     } 
/* 1132 */     return carry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String eFormatString(double x, char eChar) {
/*      */     char[] ca4;
/* 1148 */     boolean noDigits = false;
/*      */     
/* 1150 */     if (Double.isInfinite(x)) {
/* 1151 */       if (x == Double.POSITIVE_INFINITY) {
/* 1152 */         if (this.leadingSign) {
/* 1153 */           ca4 = "+Inf".toCharArray();
/* 1154 */         } else if (this.leadingSpace) {
/* 1155 */           ca4 = " Inf".toCharArray();
/*      */         } else {
/* 1157 */           ca4 = "Inf".toCharArray();
/*      */         } 
/*      */       } else {
/* 1160 */         ca4 = "-Inf".toCharArray();
/*      */       } 
/* 1162 */       noDigits = true;
/* 1163 */     } else if (Double.isNaN(x)) {
/* 1164 */       if (this.leadingSign) {
/* 1165 */         ca4 = "+NaN".toCharArray();
/* 1166 */       } else if (this.leadingSpace) {
/* 1167 */         ca4 = " NaN".toCharArray();
/*      */       } else {
/* 1169 */         ca4 = "NaN".toCharArray();
/*      */       } 
/* 1171 */       noDigits = true;
/*      */     } else {
/* 1173 */       ca4 = eFormatDigits(x, eChar);
/*      */     } 
/* 1175 */     char[] ca5 = applyFloatPadding(ca4, false);
/* 1176 */     return new String(ca5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] applyFloatPadding(char[] ca4, boolean noDigits) {
/* 1189 */     char[] ca5 = ca4;
/* 1190 */     if (this.fieldWidthSet)
/*      */     {
/* 1192 */       if (this.leftJustify) {
/* 1193 */         int nBlanks = this.fieldWidth - ca4.length;
/* 1194 */         if (nBlanks > 0) {
/* 1195 */           ca5 = new char[ca4.length + nBlanks]; int i;
/* 1196 */           for (i = 0; i < ca4.length; i++) {
/* 1197 */             ca5[i] = ca4[i];
/*      */           }
/* 1199 */           for (int j = 0; j < nBlanks; j++, i++) {
/* 1200 */             ca5[i] = ' ';
/*      */           }
/*      */         } 
/* 1203 */       } else if (!this.leadingZeros || noDigits) {
/* 1204 */         int nBlanks = this.fieldWidth - ca4.length;
/* 1205 */         if (nBlanks > 0) {
/* 1206 */           ca5 = new char[ca4.length + nBlanks]; int i;
/* 1207 */           for (i = 0; i < nBlanks; i++) {
/* 1208 */             ca5[i] = ' ';
/*      */           }
/* 1210 */           for (int j = 0; j < ca4.length; i++, j++) {
/* 1211 */             ca5[i] = ca4[j];
/*      */           }
/*      */         } 
/* 1214 */       } else if (this.leadingZeros) {
/* 1215 */         int nBlanks = this.fieldWidth - ca4.length;
/* 1216 */         if (nBlanks > 0) {
/* 1217 */           ca5 = new char[ca4.length + nBlanks];
/* 1218 */           int i = 0;
/* 1219 */           int j = 0;
/* 1220 */           if (ca4[0] == '-') {
/* 1221 */             ca5[0] = '-';
/* 1222 */             i++;
/* 1223 */             j++;
/*      */           } 
/* 1225 */           for (int k = 0; k < nBlanks; i++, k++) {
/* 1226 */             ca5[i] = '0';
/*      */           }
/* 1228 */           for (; j < ca4.length; i++, j++) {
/* 1229 */             ca5[i] = ca4[j];
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/* 1234 */     return ca5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printFFormat(double x) {
/* 1244 */     return fFormatString(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printEFormat(double x) {
/* 1255 */     if (this.conversionCharacter == 'e') {
/* 1256 */       return eFormatString(x, 'e');
/*      */     }
/* 1258 */     return eFormatString(x, 'E');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printGFormat(double x) {
/*      */     char[] ca4;
/* 1291 */     int savePrecision = this.precision;
/*      */ 
/*      */     
/* 1294 */     boolean noDigits = false;
/* 1295 */     if (Double.isInfinite(x)) {
/* 1296 */       if (x == Double.POSITIVE_INFINITY) {
/* 1297 */         if (this.leadingSign) {
/* 1298 */           ca4 = "+Inf".toCharArray();
/* 1299 */         } else if (this.leadingSpace) {
/* 1300 */           ca4 = " Inf".toCharArray();
/*      */         } else {
/* 1302 */           ca4 = "Inf".toCharArray();
/*      */         } 
/*      */       } else {
/* 1305 */         ca4 = "-Inf".toCharArray();
/*      */       } 
/* 1307 */       noDigits = true;
/* 1308 */     } else if (Double.isNaN(x)) {
/* 1309 */       if (this.leadingSign) {
/* 1310 */         ca4 = "+NaN".toCharArray();
/* 1311 */       } else if (this.leadingSpace) {
/* 1312 */         ca4 = " NaN".toCharArray();
/*      */       } else {
/* 1314 */         ca4 = "NaN".toCharArray();
/*      */       } 
/* 1316 */       noDigits = true;
/*      */     } else {
/* 1318 */       String sx, ret; if (!this.precisionSet) {
/* 1319 */         this.precision = 6;
/*      */       }
/* 1321 */       if (this.precision == 0) {
/* 1322 */         this.precision = 1;
/*      */       }
/* 1324 */       int ePos = -1;
/* 1325 */       if (this.conversionCharacter == 'g') {
/* 1326 */         sx = eFormatString(x, 'e').trim();
/* 1327 */         ePos = sx.indexOf('e');
/*      */       } else {
/* 1329 */         sx = eFormatString(x, 'E').trim();
/* 1330 */         ePos = sx.indexOf('E');
/*      */       } 
/* 1332 */       int i = ePos + 1;
/* 1333 */       int expon = 0;
/* 1334 */       if (sx.charAt(i) == '-') {
/* 1335 */         for (; ++i < sx.length() && 
/* 1336 */           sx.charAt(i) == '0'; i++);
/*      */ 
/*      */ 
/*      */         
/* 1340 */         if (i < sx.length()) {
/* 1341 */           expon = -Integer.parseInt(sx.substring(i));
/*      */         }
/*      */       } else {
/* 1344 */         if (sx.charAt(i) == '+') {
/* 1345 */           i++;
/*      */         }
/* 1347 */         for (; i < sx.length() && 
/* 1348 */           sx.charAt(i) == '0'; i++);
/*      */ 
/*      */ 
/*      */         
/* 1352 */         if (i < sx.length()) {
/* 1353 */           expon = Integer.parseInt(sx.substring(i));
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1359 */       if (!this.alternateForm) {
/* 1360 */         String sy, sz; if (expon >= -4 && expon < this.precision) {
/* 1361 */           sy = fFormatString(x).trim();
/*      */         } else {
/* 1363 */           sy = sx.substring(0, ePos);
/*      */         } 
/* 1365 */         i = sy.length() - 1;
/* 1366 */         for (; i >= 0 && 
/* 1367 */           sy.charAt(i) == '0'; i--);
/*      */ 
/*      */ 
/*      */         
/* 1371 */         if (i >= 0 && sy.charAt(i) == '.') {
/* 1372 */           i--;
/*      */         }
/* 1374 */         if (i == -1) {
/* 1375 */           sz = "0";
/* 1376 */         } else if (!Character.isDigit(sy.charAt(i))) {
/* 1377 */           sz = sy.substring(0, i + 1) + "0";
/*      */         } else {
/* 1379 */           sz = sy.substring(0, i + 1);
/*      */         } 
/* 1381 */         if (expon >= -4 && expon < this.precision) {
/* 1382 */           ret = sz;
/*      */         } else {
/* 1384 */           ret = sz + sx.substring(ePos);
/*      */         }
/*      */       
/* 1387 */       } else if (expon >= -4 && expon < this.precision) {
/* 1388 */         ret = fFormatString(x).trim();
/*      */       } else {
/* 1390 */         ret = sx;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1395 */       if (this.leadingSpace && 
/* 1396 */         x >= 0.0D) {
/* 1397 */         ret = " " + ret;
/*      */       }
/*      */       
/* 1400 */       ca4 = ret.toCharArray();
/*      */     } 
/*      */     
/* 1403 */     char[] ca5 = applyFloatPadding(ca4, false);
/* 1404 */     this.precision = savePrecision;
/* 1405 */     return new String(ca5);
/*      */   }
/*      */   private String printAFormat(double x) {
/*      */     char[] ca4;
/* 1409 */     int savePrecision = this.precision;
/*      */ 
/*      */     
/* 1412 */     boolean noDigits = false;
/* 1413 */     if (Double.isInfinite(x)) {
/* 1414 */       if (x == Double.POSITIVE_INFINITY) {
/* 1415 */         if (this.leadingSign) {
/* 1416 */           ca4 = "+Inf".toCharArray();
/* 1417 */         } else if (this.leadingSpace) {
/* 1418 */           ca4 = " Inf".toCharArray();
/*      */         } else {
/* 1420 */           ca4 = "Inf".toCharArray();
/*      */         } 
/*      */       } else {
/* 1423 */         ca4 = "-Inf".toCharArray();
/*      */       } 
/* 1425 */       noDigits = true;
/* 1426 */     } else if (Double.isNaN(x)) {
/* 1427 */       if (this.leadingSign) {
/* 1428 */         ca4 = "+NaN".toCharArray();
/* 1429 */       } else if (this.leadingSpace) {
/* 1430 */         ca4 = " NaN".toCharArray();
/*      */       } else {
/* 1432 */         ca4 = "NaN".toCharArray();
/*      */       } 
/* 1434 */       noDigits = true;
/*      */     } else {
/* 1436 */       if (!this.precisionSet) {
/* 1437 */         this.precision = 15;
/*      */       }
/* 1439 */       if (this.precision == 0) {
/* 1440 */         this.precision = 1;
/*      */       }
/*      */       
/* 1443 */       String hexString = "0x" + hexDouble(x, this.precision);
/* 1444 */       if (this.conversionCharacter == 'A') {
/* 1445 */         hexString = hexString.toUpperCase();
/*      */       }
/* 1447 */       ca4 = hexString.toCharArray();
/*      */     } 
/*      */     
/* 1450 */     char[] ca5 = applyFloatPadding(ca4, false);
/* 1451 */     this.precision = savePrecision;
/* 1452 */     return new String(ca5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String hexDouble(double d, int prec) {
/* 1461 */     if (!Double.isFinite(d) || d == 0.0D || prec == 0 || prec >= 13) {
/* 1462 */       return toHexString(d).substring(2);
/*      */     }
/*      */     
/* 1465 */     int exponent = Math.getExponent(d);
/* 1466 */     boolean subnormal = (exponent == -1023);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1471 */     if (subnormal) {
/* 1472 */       double scaleUp = Math.scalb(1.0D, 54);
/* 1473 */       d *= scaleUp;
/*      */ 
/*      */       
/* 1476 */       exponent = Math.getExponent(d);
/* 1477 */       assert exponent >= -1022 && exponent <= 1023 : exponent;
/*      */     } 
/*      */ 
/*      */     
/* 1481 */     int precision = 1 + prec * 4;
/* 1482 */     int shiftDistance = 53 - precision;
/*      */     
/* 1484 */     assert shiftDistance >= 1 && shiftDistance < 53;
/*      */     
/* 1486 */     long doppel = Double.doubleToLongBits(d);
/*      */     
/* 1488 */     long newSignif = (doppel & Long.MAX_VALUE) >> shiftDistance;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1493 */     long roundingBits = doppel & (-1L << shiftDistance ^ 0xFFFFFFFFFFFFFFFFL);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1500 */     boolean leastZero = ((newSignif & 0x1L) == 0L);
/* 1501 */     boolean round = ((1L << shiftDistance - 1 & roundingBits) != 0L);
/*      */     
/* 1503 */     boolean sticky = (shiftDistance > 1 && ((1L << shiftDistance - 1 ^ 0xFFFFFFFFFFFFFFFFL) & roundingBits) != 0L);
/*      */     
/* 1505 */     if ((leastZero && round && sticky) || (!leastZero && round)) {
/* 1506 */       newSignif++;
/*      */     }
/*      */     
/* 1509 */     long signBit = doppel & Long.MIN_VALUE;
/* 1510 */     newSignif = signBit | newSignif << shiftDistance;
/* 1511 */     double result = Double.longBitsToDouble(newSignif);
/*      */     
/* 1513 */     if (Double.isInfinite(result))
/*      */     {
/* 1515 */       return "1.0p+1024";
/*      */     }
/* 1517 */     String res = toHexString(result).substring(2);
/* 1518 */     if (!subnormal) {
/* 1519 */       return res;
/*      */     }
/*      */     
/* 1522 */     int idx = res.indexOf('p');
/* 1523 */     if (idx == -1) {
/*      */       assert false;
/*      */       
/* 1526 */       return null;
/*      */     } 
/*      */     
/* 1529 */     String exp = res.substring(idx + 1);
/* 1530 */     int iexp = Integer.parseInt(exp) - 54;
/* 1531 */     return res.substring(0, idx) + "p" + ((iexp < 0) ? "" : "+") + 
/*      */       
/* 1533 */       Integer.toString(iexp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toHexString(double d) {
/* 1621 */     assert Double.isFinite(d);
/*      */     
/* 1623 */     StringBuilder answer = new StringBuilder(24);
/*      */     
/* 1625 */     if (Math.copySign(1.0D, d) == -1.0D)
/*      */     {
/* 1627 */       answer.append("-");
/*      */     }
/*      */     
/* 1630 */     answer.append("0x");
/*      */     
/* 1632 */     d = Math.abs(d);
/*      */     
/* 1634 */     if (d == 0.0D) {
/* 1635 */       answer.append("0.0p+0");
/*      */     } else {
/* 1637 */       boolean subnormal = (d < 2.2250738585072014E-308D);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1642 */       long signifBits = Double.doubleToLongBits(d) & 0xFFFFFFFFFFFFFL | 0x1000000000000000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1648 */       answer.append(subnormal ? "0." : "1.");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1654 */       String signif = Long.toHexString(signifBits).substring(3, 16);
/* 1655 */       answer.append(signif.equals("0000000000000") ? "0" : signif
/*      */           
/* 1657 */           .replaceFirst("0{1,12}$", ""));
/*      */       
/* 1659 */       answer.append('p');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1666 */       int exponent = subnormal ? -1022 : Math.getExponent(d);
/*      */       
/* 1668 */       if (exponent >= 0) {
/* 1669 */         answer.append("+");
/*      */       }
/*      */       
/* 1672 */       answer.append(exponent);
/*      */     } 
/* 1674 */     return answer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printDFormat(short x) {
/* 1706 */     return printDFormat(Short.toString(x));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printDFormat(long x) {
/* 1737 */     return printDFormat(Long.toString(x));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printBFormat(long x) {
/* 1744 */     return Long.toBinaryString(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printDFormat(int x) {
/* 1776 */     return printDFormat(Integer.toString(x));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printDFormat(String sx) {
/* 1789 */     int nLeadingZeros = 0;
/* 1790 */     int nBlanks = 0, n = 0;
/* 1791 */     int i = 0, jFirst = 0;
/* 1792 */     boolean neg = (sx.charAt(0) == '-');
/* 1793 */     if (sx.equals("0") && this.precisionSet && this.precision == 0) {
/* 1794 */       sx = "";
/*      */     }
/* 1796 */     if (!neg) {
/* 1797 */       if (this.precisionSet && sx.length() < this.precision) {
/* 1798 */         nLeadingZeros = this.precision - sx.length();
/*      */       }
/*      */     }
/* 1801 */     else if (this.precisionSet && sx.length() - 1 < this.precision) {
/* 1802 */       nLeadingZeros = this.precision - sx.length() + 1;
/*      */     } 
/*      */     
/* 1805 */     if (nLeadingZeros < 0) {
/* 1806 */       nLeadingZeros = 0;
/*      */     }
/* 1808 */     if (this.fieldWidthSet) {
/* 1809 */       nBlanks = this.fieldWidth - nLeadingZeros - sx.length();
/* 1810 */       if (!neg && (this.leadingSign || this.leadingSpace)) {
/* 1811 */         nBlanks--;
/*      */       }
/*      */     } 
/* 1814 */     if (nBlanks < 0) {
/* 1815 */       nBlanks = 0;
/*      */     }
/* 1817 */     if (this.leadingSign) {
/* 1818 */       n++;
/* 1819 */     } else if (this.leadingSpace) {
/* 1820 */       n++;
/*      */     } 
/* 1822 */     n += nBlanks;
/* 1823 */     n += nLeadingZeros;
/* 1824 */     n += sx.length();
/* 1825 */     char[] ca = new char[n];
/* 1826 */     if (this.leftJustify) {
/* 1827 */       if (neg) {
/* 1828 */         ca[i++] = '-';
/* 1829 */       } else if (this.leadingSign) {
/* 1830 */         ca[i++] = '+';
/* 1831 */       } else if (this.leadingSpace) {
/* 1832 */         ca[i++] = ' ';
/*      */       } 
/* 1834 */       char[] csx = sx.toCharArray();
/* 1835 */       jFirst = neg ? 1 : 0; int j;
/* 1836 */       for (j = 0; j < nLeadingZeros; i++, j++) {
/* 1837 */         ca[i] = '0';
/*      */       }
/* 1839 */       for (j = jFirst; j < csx.length; j++, i++) {
/* 1840 */         ca[i] = csx[j];
/*      */       }
/* 1842 */       for (j = 0; j < nBlanks; i++, j++) {
/* 1843 */         ca[i] = ' ';
/*      */       }
/*      */     } else {
/* 1846 */       if (!this.leadingZeros) {
/* 1847 */         for (i = 0; i < nBlanks; i++) {
/* 1848 */           ca[i] = ' ';
/*      */         }
/* 1850 */         if (neg) {
/* 1851 */           ca[i++] = '-';
/* 1852 */         } else if (this.leadingSign) {
/* 1853 */           ca[i++] = '+';
/* 1854 */         } else if (this.leadingSpace) {
/* 1855 */           ca[i++] = ' ';
/*      */         } 
/*      */       } else {
/* 1858 */         if (neg) {
/* 1859 */           ca[i++] = '-';
/* 1860 */         } else if (this.leadingSign) {
/* 1861 */           ca[i++] = '+';
/* 1862 */         } else if (this.leadingSpace) {
/* 1863 */           ca[i++] = ' ';
/*      */         } 
/* 1865 */         for (int m = 0; m < nBlanks; m++, i++) {
/* 1866 */           ca[i] = '0';
/*      */         }
/*      */       } 
/* 1869 */       for (int j = 0; j < nLeadingZeros; j++, i++) {
/* 1870 */         ca[i] = '0';
/*      */       }
/* 1872 */       char[] csx = sx.toCharArray();
/* 1873 */       jFirst = neg ? 1 : 0;
/* 1874 */       for (int k = jFirst; k < csx.length; k++, i++) {
/* 1875 */         ca[i] = csx[k];
/*      */       }
/*      */     } 
/* 1878 */     return new String(ca);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printXFormat(short x) {
/* 1903 */     String sx = null;
/* 1904 */     if (x == Short.MIN_VALUE) {
/* 1905 */       sx = "8000";
/* 1906 */     } else if (x < 0) {
/*      */       String t;
/* 1908 */       if (x == Short.MIN_VALUE) {
/* 1909 */         t = "0";
/*      */       } else {
/* 1911 */         t = Integer.toString(-x - 1 ^ 0xFFFFFFFF ^ 0xFFFF8000, 16);
/*      */         
/* 1913 */         if (t.charAt(0) == 'F' || t.charAt(0) == 'f') {
/* 1914 */           t = t.substring(16, 32);
/*      */         }
/*      */       } 
/* 1917 */       switch (t.length()) {
/*      */         case 1:
/* 1919 */           sx = "800" + t;
/*      */           break;
/*      */         case 2:
/* 1922 */           sx = "80" + t;
/*      */           break;
/*      */         case 3:
/* 1925 */           sx = "8" + t;
/*      */           break;
/*      */         case 4:
/* 1928 */           switch (t.charAt(0)) {
/*      */             case '1':
/* 1930 */               sx = "9" + t.substring(1, 4);
/*      */               break;
/*      */             case '2':
/* 1933 */               sx = "a" + t.substring(1, 4);
/*      */               break;
/*      */             case '3':
/* 1936 */               sx = "b" + t.substring(1, 4);
/*      */               break;
/*      */             case '4':
/* 1939 */               sx = "c" + t.substring(1, 4);
/*      */               break;
/*      */             case '5':
/* 1942 */               sx = "d" + t.substring(1, 4);
/*      */               break;
/*      */             case '6':
/* 1945 */               sx = "e" + t.substring(1, 4);
/*      */               break;
/*      */             case '7':
/* 1948 */               sx = "f" + t.substring(1, 4);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } else {
/* 1954 */       sx = Integer.toString(x, 16);
/*      */     } 
/* 1956 */     return printXFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printXFormat(long x) {
/* 1981 */     String sx = null;
/* 1982 */     if (x == Long.MIN_VALUE) {
/* 1983 */       sx = "8000000000000000";
/* 1984 */     } else if (x < 0L) {
/* 1985 */       String t = Long.toString(-x - 1L ^ 0xFFFFFFFFFFFFFFFFL ^ Long.MIN_VALUE, 16);
/*      */       
/* 1987 */       switch (t.length()) {
/*      */         case 1:
/* 1989 */           sx = "800000000000000" + t;
/*      */           break;
/*      */         case 2:
/* 1992 */           sx = "80000000000000" + t;
/*      */           break;
/*      */         case 3:
/* 1995 */           sx = "8000000000000" + t;
/*      */           break;
/*      */         case 4:
/* 1998 */           sx = "800000000000" + t;
/*      */           break;
/*      */         case 5:
/* 2001 */           sx = "80000000000" + t;
/*      */           break;
/*      */         case 6:
/* 2004 */           sx = "8000000000" + t;
/*      */           break;
/*      */         case 7:
/* 2007 */           sx = "800000000" + t;
/*      */           break;
/*      */         case 8:
/* 2010 */           sx = "80000000" + t;
/*      */           break;
/*      */         case 9:
/* 2013 */           sx = "8000000" + t;
/*      */           break;
/*      */         case 10:
/* 2016 */           sx = "800000" + t;
/*      */           break;
/*      */         case 11:
/* 2019 */           sx = "80000" + t;
/*      */           break;
/*      */         case 12:
/* 2022 */           sx = "8000" + t;
/*      */           break;
/*      */         case 13:
/* 2025 */           sx = "800" + t;
/*      */           break;
/*      */         case 14:
/* 2028 */           sx = "80" + t;
/*      */           break;
/*      */         case 15:
/* 2031 */           sx = "8" + t;
/*      */           break;
/*      */         case 16:
/* 2034 */           switch (t.charAt(0)) {
/*      */             case '1':
/* 2036 */               sx = "9" + t.substring(1, 16);
/*      */               break;
/*      */             case '2':
/* 2039 */               sx = "a" + t.substring(1, 16);
/*      */               break;
/*      */             case '3':
/* 2042 */               sx = "b" + t.substring(1, 16);
/*      */               break;
/*      */             case '4':
/* 2045 */               sx = "c" + t.substring(1, 16);
/*      */               break;
/*      */             case '5':
/* 2048 */               sx = "d" + t.substring(1, 16);
/*      */               break;
/*      */             case '6':
/* 2051 */               sx = "e" + t.substring(1, 16);
/*      */               break;
/*      */             case '7':
/* 2054 */               sx = "f" + t.substring(1, 16);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } else {
/* 2060 */       sx = Long.toString(x, 16);
/*      */     } 
/* 2062 */     return printXFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printXFormat(int x) {
/* 2087 */     String sx = null;
/* 2088 */     if (x == Integer.MIN_VALUE) {
/* 2089 */       sx = "80000000";
/* 2090 */     } else if (x < 0) {
/* 2091 */       String t = Integer.toString(-x - 1 ^ 0xFFFFFFFF ^ Integer.MIN_VALUE, 16);
/*      */       
/* 2093 */       switch (t.length()) {
/*      */         case 1:
/* 2095 */           sx = "8000000" + t;
/*      */           break;
/*      */         case 2:
/* 2098 */           sx = "800000" + t;
/*      */           break;
/*      */         case 3:
/* 2101 */           sx = "80000" + t;
/*      */           break;
/*      */         case 4:
/* 2104 */           sx = "8000" + t;
/*      */           break;
/*      */         case 5:
/* 2107 */           sx = "800" + t;
/*      */           break;
/*      */         case 6:
/* 2110 */           sx = "80" + t;
/*      */           break;
/*      */         case 7:
/* 2113 */           sx = "8" + t;
/*      */           break;
/*      */         case 8:
/* 2116 */           switch (t.charAt(0)) {
/*      */             case '1':
/* 2118 */               sx = "9" + t.substring(1, 8);
/*      */               break;
/*      */             case '2':
/* 2121 */               sx = "a" + t.substring(1, 8);
/*      */               break;
/*      */             case '3':
/* 2124 */               sx = "b" + t.substring(1, 8);
/*      */               break;
/*      */             case '4':
/* 2127 */               sx = "c" + t.substring(1, 8);
/*      */               break;
/*      */             case '5':
/* 2130 */               sx = "d" + t.substring(1, 8);
/*      */               break;
/*      */             case '6':
/* 2133 */               sx = "e" + t.substring(1, 8);
/*      */               break;
/*      */             case '7':
/* 2136 */               sx = "f" + t.substring(1, 8);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } else {
/* 2142 */       sx = Integer.toString(x, 16);
/*      */     } 
/* 2144 */     return printXFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printXFormat(String sx) {
/* 2157 */     int nLeadingZeros = 0;
/* 2158 */     int nBlanks = 0;
/* 2159 */     if (sx.equals("0") && this.precisionSet && this.precision == 0) {
/* 2160 */       sx = "";
/*      */     }
/* 2162 */     if (this.precisionSet) {
/* 2163 */       nLeadingZeros = this.precision - sx.length();
/*      */     }
/* 2165 */     if (nLeadingZeros < 0) {
/* 2166 */       nLeadingZeros = 0;
/*      */     }
/* 2168 */     if (this.fieldWidthSet) {
/* 2169 */       nBlanks = this.fieldWidth - nLeadingZeros - sx.length();
/* 2170 */       if (this.alternateForm) {
/* 2171 */         nBlanks -= 2;
/*      */       }
/*      */     } 
/* 2174 */     if (nBlanks < 0) {
/* 2175 */       nBlanks = 0;
/*      */     }
/* 2177 */     int n = 0;
/* 2178 */     if (this.alternateForm) {
/* 2179 */       n += 2;
/*      */     }
/* 2181 */     n += nLeadingZeros;
/* 2182 */     n += sx.length();
/* 2183 */     n += nBlanks;
/* 2184 */     char[] ca = new char[n];
/* 2185 */     int i = 0;
/* 2186 */     if (this.leftJustify) {
/* 2187 */       if (this.alternateForm) {
/* 2188 */         ca[i++] = '0';
/* 2189 */         ca[i++] = 'x';
/*      */       } 
/* 2191 */       for (int j = 0; j < nLeadingZeros; j++, i++) {
/* 2192 */         ca[i] = '0';
/*      */       }
/* 2194 */       char[] csx = sx.toCharArray(); int k;
/* 2195 */       for (k = 0; k < csx.length; k++, i++) {
/* 2196 */         ca[i] = csx[k];
/*      */       }
/* 2198 */       for (k = 0; k < nBlanks; k++, i++) {
/* 2199 */         ca[i] = ' ';
/*      */       }
/*      */     } else {
/* 2202 */       if (!this.leadingZeros) {
/* 2203 */         for (int m = 0; m < nBlanks; m++, i++) {
/* 2204 */           ca[i] = ' ';
/*      */         }
/*      */       }
/* 2207 */       if (this.alternateForm) {
/* 2208 */         ca[i++] = '0';
/* 2209 */         ca[i++] = 'x';
/*      */       } 
/* 2211 */       if (this.leadingZeros) {
/* 2212 */         for (int m = 0; m < nBlanks; m++, i++) {
/* 2213 */           ca[i] = '0';
/*      */         }
/*      */       }
/* 2216 */       for (int j = 0; j < nLeadingZeros; j++, i++) {
/* 2217 */         ca[i] = '0';
/*      */       }
/* 2219 */       char[] csx = sx.toCharArray();
/* 2220 */       for (int k = 0; k < csx.length; k++, i++) {
/* 2221 */         ca[i] = csx[k];
/*      */       }
/*      */     } 
/* 2224 */     String caReturn = new String(ca);
/* 2225 */     if (this.conversionCharacter == 'X' || this.conversionCharacter == 'p') {
/* 2226 */       caReturn = caReturn.toUpperCase();
/*      */     }
/* 2228 */     return caReturn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printOFormat(short x) {
/* 2254 */     String sx = null;
/* 2255 */     if (x == Short.MIN_VALUE) {
/* 2256 */       sx = "100000";
/* 2257 */     } else if (x < 0) {
/* 2258 */       String t = Integer.toString(-x - 1 ^ 0xFFFFFFFF ^ 0xFFFF8000, 8);
/*      */       
/* 2260 */       switch (t.length()) {
/*      */         case 1:
/* 2262 */           sx = "10000" + t;
/*      */           break;
/*      */         case 2:
/* 2265 */           sx = "1000" + t;
/*      */           break;
/*      */         case 3:
/* 2268 */           sx = "100" + t;
/*      */           break;
/*      */         case 4:
/* 2271 */           sx = "10" + t;
/*      */           break;
/*      */         case 5:
/* 2274 */           sx = "1" + t;
/*      */           break;
/*      */       } 
/*      */     } else {
/* 2278 */       sx = Integer.toString(x, 8);
/*      */     } 
/* 2280 */     return printOFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printOFormat(long x) {
/* 2306 */     String sx = null;
/* 2307 */     if (x == Long.MIN_VALUE) {
/* 2308 */       sx = "1000000000000000000000";
/* 2309 */     } else if (x < 0L) {
/* 2310 */       String t = Long.toString(-x - 1L ^ 0xFFFFFFFFFFFFFFFFL ^ Long.MIN_VALUE, 8);
/*      */       
/* 2312 */       switch (t.length()) {
/*      */         case 1:
/* 2314 */           sx = "100000000000000000000" + t;
/*      */           break;
/*      */         case 2:
/* 2317 */           sx = "10000000000000000000" + t;
/*      */           break;
/*      */         case 3:
/* 2320 */           sx = "1000000000000000000" + t;
/*      */           break;
/*      */         case 4:
/* 2323 */           sx = "100000000000000000" + t;
/*      */           break;
/*      */         case 5:
/* 2326 */           sx = "10000000000000000" + t;
/*      */           break;
/*      */         case 6:
/* 2329 */           sx = "1000000000000000" + t;
/*      */           break;
/*      */         case 7:
/* 2332 */           sx = "100000000000000" + t;
/*      */           break;
/*      */         case 8:
/* 2335 */           sx = "10000000000000" + t;
/*      */           break;
/*      */         case 9:
/* 2338 */           sx = "1000000000000" + t;
/*      */           break;
/*      */         case 10:
/* 2341 */           sx = "100000000000" + t;
/*      */           break;
/*      */         case 11:
/* 2344 */           sx = "10000000000" + t;
/*      */           break;
/*      */         case 12:
/* 2347 */           sx = "1000000000" + t;
/*      */           break;
/*      */         case 13:
/* 2350 */           sx = "100000000" + t;
/*      */           break;
/*      */         case 14:
/* 2353 */           sx = "10000000" + t;
/*      */           break;
/*      */         case 15:
/* 2356 */           sx = "1000000" + t;
/*      */           break;
/*      */         case 16:
/* 2359 */           sx = "100000" + t;
/*      */           break;
/*      */         case 17:
/* 2362 */           sx = "10000" + t;
/*      */           break;
/*      */         case 18:
/* 2365 */           sx = "1000" + t;
/*      */           break;
/*      */         case 19:
/* 2368 */           sx = "100" + t;
/*      */           break;
/*      */         case 20:
/* 2371 */           sx = "10" + t;
/*      */           break;
/*      */         case 21:
/* 2374 */           sx = "1" + t;
/*      */           break;
/*      */       } 
/*      */     } else {
/* 2378 */       sx = Long.toString(x, 8);
/*      */     } 
/* 2380 */     return printOFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printOFormat(int x) {
/* 2406 */     String sx = null;
/* 2407 */     if (x == Integer.MIN_VALUE) {
/* 2408 */       sx = "20000000000";
/* 2409 */     } else if (x < 0) {
/* 2410 */       String t = Integer.toString(-x - 1 ^ 0xFFFFFFFF ^ Integer.MIN_VALUE, 8);
/*      */       
/* 2412 */       switch (t.length()) {
/*      */         case 1:
/* 2414 */           sx = "2000000000" + t;
/*      */           break;
/*      */         case 2:
/* 2417 */           sx = "200000000" + t;
/*      */           break;
/*      */         case 3:
/* 2420 */           sx = "20000000" + t;
/*      */           break;
/*      */         case 4:
/* 2423 */           sx = "2000000" + t;
/*      */           break;
/*      */         case 5:
/* 2426 */           sx = "200000" + t;
/*      */           break;
/*      */         case 6:
/* 2429 */           sx = "20000" + t;
/*      */           break;
/*      */         case 7:
/* 2432 */           sx = "2000" + t;
/*      */           break;
/*      */         case 8:
/* 2435 */           sx = "200" + t;
/*      */           break;
/*      */         case 9:
/* 2438 */           sx = "20" + t;
/*      */           break;
/*      */         case 10:
/* 2441 */           sx = "2" + t;
/*      */           break;
/*      */         case 11:
/* 2444 */           sx = "3" + t.substring(1);
/*      */           break;
/*      */       } 
/*      */     } else {
/* 2448 */       sx = Integer.toString(x, 8);
/*      */     } 
/* 2450 */     return printOFormat(sx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printOFormat(String sx) {
/* 2463 */     int nLeadingZeros = 0;
/* 2464 */     int nBlanks = 0;
/* 2465 */     if (sx.equals("0") && this.precisionSet && this.precision == 0) {
/* 2466 */       sx = "";
/*      */     }
/* 2468 */     if (this.precisionSet) {
/* 2469 */       nLeadingZeros = this.precision - sx.length();
/*      */     }
/* 2471 */     if (this.alternateForm) {
/* 2472 */       nLeadingZeros++;
/*      */     }
/* 2474 */     if (nLeadingZeros < 0) {
/* 2475 */       nLeadingZeros = 0;
/*      */     }
/* 2477 */     if (this.fieldWidthSet) {
/* 2478 */       nBlanks = this.fieldWidth - nLeadingZeros - sx.length();
/*      */     }
/* 2480 */     if (nBlanks < 0) {
/* 2481 */       nBlanks = 0;
/*      */     }
/* 2483 */     int n = nLeadingZeros + sx.length() + nBlanks;
/* 2484 */     char[] ca = new char[n];
/*      */     
/* 2486 */     if (this.leftJustify) {
/* 2487 */       int i; for (i = 0; i < nLeadingZeros; i++) {
/* 2488 */         ca[i] = '0';
/*      */       }
/* 2490 */       char[] csx = sx.toCharArray(); int j;
/* 2491 */       for (j = 0; j < csx.length; j++, i++) {
/* 2492 */         ca[i] = csx[j];
/*      */       }
/* 2494 */       for (j = 0; j < nBlanks; j++, i++)
/* 2495 */         ca[i] = ' '; 
/*      */     } else {
/*      */       int i;
/* 2498 */       if (this.leadingZeros) {
/* 2499 */         for (i = 0; i < nBlanks; i++) {
/* 2500 */           ca[i] = '0';
/*      */         }
/*      */       } else {
/* 2503 */         for (i = 0; i < nBlanks; i++) {
/* 2504 */           ca[i] = ' ';
/*      */         }
/*      */       } 
/* 2507 */       for (int j = 0; j < nLeadingZeros; j++, i++) {
/* 2508 */         ca[i] = '0';
/*      */       }
/* 2510 */       char[] csx = sx.toCharArray();
/* 2511 */       for (int k = 0; k < csx.length; k++, i++) {
/* 2512 */         ca[i] = csx[k];
/*      */       }
/*      */     } 
/* 2515 */     return new String(ca);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printCFormat(char x) {
/* 2537 */     int nPrint = 1;
/* 2538 */     int width = this.fieldWidth;
/* 2539 */     if (!this.fieldWidthSet) {
/* 2540 */       width = nPrint;
/*      */     }
/* 2542 */     char[] ca = new char[width];
/* 2543 */     int i = 0;
/* 2544 */     if (this.leftJustify) {
/* 2545 */       ca[0] = x;
/* 2546 */       for (i = 1; i <= width - nPrint; i++) {
/* 2547 */         ca[i] = ' ';
/*      */       }
/*      */     } else {
/* 2550 */       for (i = 0; i < width - nPrint; i++) {
/* 2551 */         ca[i] = ' ';
/*      */       }
/* 2553 */       ca[i] = x;
/*      */     } 
/* 2555 */     return new String(ca);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String printSFormat(String x) {
/* 2583 */     int nPrint = x.length();
/* 2584 */     int width = this.fieldWidth;
/* 2585 */     if (this.precisionSet && nPrint > this.precision) {
/* 2586 */       nPrint = this.precision;
/*      */     }
/* 2588 */     if (!this.fieldWidthSet) {
/* 2589 */       width = nPrint;
/*      */     }
/* 2591 */     int n = 0;
/* 2592 */     if (width > nPrint) {
/* 2593 */       n += width - nPrint;
/*      */     }
/* 2595 */     if (nPrint >= x.length()) {
/* 2596 */       n += x.length();
/*      */     } else {
/* 2598 */       n += nPrint;
/*      */     } 
/* 2600 */     char[] ca = new char[n];
/* 2601 */     int i = 0;
/* 2602 */     if (this.leftJustify) {
/* 2603 */       if (nPrint >= x.length()) {
/* 2604 */         char[] csx = x.toCharArray();
/* 2605 */         for (i = 0; i < x.length(); i++) {
/* 2606 */           ca[i] = csx[i];
/*      */         }
/*      */       } else {
/*      */         
/* 2610 */         char[] csx = x.substring(0, nPrint).toCharArray();
/* 2611 */         for (i = 0; i < nPrint; i++) {
/* 2612 */           ca[i] = csx[i];
/*      */         }
/*      */       } 
/* 2615 */       for (int j = 0; j < width - nPrint; j++, i++) {
/* 2616 */         ca[i] = ' ';
/*      */       }
/*      */     } else {
/* 2619 */       for (i = 0; i < width - nPrint; i++) {
/* 2620 */         ca[i] = ' ';
/*      */       }
/* 2622 */       if (nPrint >= x.length()) {
/* 2623 */         char[] csx = x.toCharArray();
/* 2624 */         for (int j = 0; j < x.length(); i++, j++) {
/* 2625 */           ca[i] = csx[j];
/*      */         }
/*      */       } else {
/*      */         
/* 2629 */         char[] csx = x.substring(0, nPrint).toCharArray();
/* 2630 */         for (int j = 0; j < nPrint; i++, j++) {
/* 2631 */           ca[i] = csx[j];
/*      */         }
/*      */       } 
/*      */     } 
/* 2635 */     return new String(ca);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/format/FormatSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */