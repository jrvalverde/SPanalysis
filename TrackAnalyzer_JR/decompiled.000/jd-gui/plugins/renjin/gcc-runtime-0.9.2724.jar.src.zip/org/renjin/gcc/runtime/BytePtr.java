/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BytePtr
/*     */   extends AbstractPtr
/*     */ {
/*  27 */   public static final BytePtr NULL = new BytePtr();
/*     */   
/*     */   public final byte[] array;
/*     */   public final int offset;
/*     */   
/*     */   private BytePtr() {
/*  33 */     this.array = null;
/*  34 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public BytePtr(byte... array) {
/*  38 */     this(array, 0);
/*     */   }
/*     */   
/*     */   public BytePtr(byte[] array, int offset) {
/*  42 */     this.array = array;
/*  43 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public static Ptr of(int value) {
/*  47 */     return NULL.pointerPlus(value);
/*     */   }
/*     */   
/*     */   public byte get() {
/*  51 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public void set(byte value) {
/*  55 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toArray(String constant) {
/*  62 */     return constant.getBytes(StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public static BytePtr asciiString(String string) {
/*  66 */     return new BytePtr(string.getBytes(StandardCharsets.US_ASCII), 0);
/*     */   }
/*     */   
/*     */   public static BytePtr nullTerminatedString(String string, Charset charset) {
/*  70 */     byte[] bytes = string.getBytes(charset);
/*  71 */     byte[] nullTerminatedBytes = Arrays.copyOf(bytes, bytes.length + 1);
/*  72 */     return new BytePtr(nullTerminatedBytes, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nullTerminatedStringLength() {
/*  80 */     int i = this.offset;
/*  81 */     while (i < this.array.length) {
/*  82 */       if (this.array[i] == 0) {
/*  83 */         return i - this.offset;
/*     */       }
/*  85 */       i++;
/*     */     } 
/*  87 */     throw new IllegalStateException("String is not null-terminated.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nullTerminatedString() {
/*  95 */     return new String(this.array, this.offset, nullTerminatedStringLength(), StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public String toString(int length) {
/*  99 */     return new String(this.array, this.offset, length, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */   
/*     */   public static BytePtr malloc(int bytes) {
/* 104 */     return new BytePtr(new byte[bytes]);
/*     */   }
/*     */   
/*     */   public static BytePtr fromString(String string) {
/* 108 */     return new BytePtr(string.getBytes(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(byte[] str, int strOffset, int c, int n) {
/* 121 */     Arrays.fill(str, strOffset, strOffset + n, (byte)c);
/*     */   }
/*     */   
/*     */   public static byte memset(int c) {
/* 125 */     return (byte)c;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getArray() {
/* 130 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 135 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/* 140 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public BytePtr realloc(int newSizeInBytes) {
/* 145 */     return new BytePtr(Realloc.realloc(this.array, this.offset, newSizeInBytes));
/*     */   }
/*     */ 
/*     */   
/*     */   public BytePtr copyOf(int numBytes) {
/* 150 */     return new BytePtr(Arrays.copyOf(this.array, numBytes));
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 155 */     if (source instanceof BytePtr) {
/* 156 */       BytePtr sourceBytePtr = (BytePtr)source;
/* 157 */       System.arraycopy(sourceBytePtr.array, sourceBytePtr.offset, this.array, this.offset, numBytes);
/*     */     } else {
/* 159 */       super.memcpy(source, numBytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/* 165 */     if (bytes == 0) {
/* 166 */       return this;
/*     */     }
/* 168 */     return new BytePtr(this.array, this.offset + bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 173 */     return this.array[this.offset + offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 178 */     this.array[this.offset + offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 183 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 188 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */   
/*     */   public static BytePtr cast(Object voidPointer) {
/* 192 */     if (voidPointer instanceof MallocThunk) {
/* 193 */       return ((MallocThunk)voidPointer).bytePtr();
/*     */     }
/* 195 */     if (voidPointer == null) {
/* 196 */       return NULL;
/*     */     }
/* 198 */     return (BytePtr)voidPointer;
/*     */   }
/*     */   
/*     */   public static int memcmp(BytePtr s1, BytePtr s2, int len) {
/* 202 */     for (int i = 0; i < len; i++) {
/* 203 */       byte b1 = s1.array[s1.offset + i];
/* 204 */       byte b2 = s2.array[s2.offset + i];
/* 205 */       if (b1 != b2) {
/* 206 */         int i1 = b1 & 0xFF;
/* 207 */         int i2 = b2 & 0xFF;
/* 208 */         return i1 - i2;
/*     */       } 
/*     */     } 
/* 211 */     return 0;
/*     */   }
/*     */   
/*     */   public static void memcpy(BytePtr x, BytePtr y, int numBytes) {
/* 215 */     byte[] arrayS = y.getArray();
/* 216 */     int offsetS = y.getOffset();
/* 217 */     int restY = arrayS.length - offsetS;
/* 218 */     if (restY > 0) {
/* 219 */       byte[] carray = new byte[numBytes];
/* 220 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 221 */         carray[i] = arrayS[j];
/*     */       }
/* 223 */       x = new BytePtr(carray);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/BytePtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */