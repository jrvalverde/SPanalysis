/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointerPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   private static final int BYTES = 4;
/*  30 */   public static final PointerPtr NULL = new PointerPtr(null, 0);
/*     */ 
/*     */ 
/*     */   
/*     */   private Ptr[] array;
/*     */ 
/*     */ 
/*     */   
/*     */   private int offset;
/*     */ 
/*     */ 
/*     */   
/*     */   public PointerPtr(Ptr[] array) {
/*  43 */     this.array = array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointerPtr(Ptr[] array, int offset) {
/*  52 */     checkAligned(offset);
/*  53 */     this.array = array;
/*  54 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public static PointerPtr wrap(Ptr[] array, int offset) {
/*  58 */     if (array == null) {
/*  59 */       return NULL;
/*     */     }
/*  61 */     return new PointerPtr(array, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PointerPtr malloc(Ptr value) {
/*  72 */     return new PointerPtr(new Ptr[] { value }, 0);
/*     */   }
/*     */   
/*     */   public static PointerPtr malloc(int bytes) {
/*  76 */     Ptr[] array = new Ptr[mallocSize(bytes, 4)];
/*  77 */     Arrays.fill((Object[])array, NULL);
/*     */     
/*  79 */     return new PointerPtr(array, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  84 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  89 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  94 */     if (this.array == null) {
/*  95 */       return malloc(newSizeInBytes);
/*     */     }
/*     */     
/*  98 */     Ptr[] newArray = new Ptr[mallocSize(newSizeInBytes, 4)];
/*  99 */     System.arraycopy(this.array, this.offset, newArray, 0, Math.min(this.array.length - this.offset, newArray.length));
/*     */     
/* 101 */     return new PointerPtr(newArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/* 106 */     return new PointerPtr(this.array, this.offset + bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 111 */     int byteOffset = this.offset * 4 + offset;
/* 112 */     int index = byteOffset / 4;
/* 113 */     Ptr ptr = this.array[index];
/*     */     
/* 115 */     if (ptr.isNull()) {
/* 116 */       return 0;
/*     */     }
/* 118 */     int intValue = ptr.toInt();
/* 119 */     int shift = byteOffset % 4 * 8;
/* 120 */     return (byte)(intValue >>> shift);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 125 */     if (value == 0) {
/* 126 */       this.array[index] = NULL;
/*     */     } else {
/* 128 */       super.setAlignedInt(index, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int intValue) {
/* 134 */     if (offset % 4 == 0 && intValue == 0) {
/* 135 */       this.array[offset / 4] = NULL;
/*     */     } else {
/* 137 */       super.setInt(offset, intValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 143 */     throw new UnsupportedOperationException("Unsupported primitive store to a memory region allocated for pointers.\nThis means something went wrong during compilation and we allocated the wrong type of storage.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 149 */     return this.array[checkAligned(this.offset + offset)];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 154 */     this.array[checkAligned(this.offset + offset)] = value;
/*     */   }
/*     */   
/*     */   private static int checkAligned(int bytes) {
/* 158 */     if (bytes % 4 != 0) {
/* 159 */       throw new UnsupportedOperationException("Unaligned access");
/*     */     }
/* 161 */     return bytes / 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 166 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 171 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(int intValue, int n) {
/* 176 */     if (intValue == 0 && this.offset % 4 == 0 && n % 4 == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       int index = this.offset / 4;
/* 182 */       while (n >= 4) {
/* 183 */         this.array[index] = NULL;
/* 184 */         n -= 4;
/* 185 */         index++;
/*     */       } 
/*     */     } else {
/* 188 */       super.memset(intValue, n);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 194 */     for (int i = 0; i < numBytes; i += 4) {
/* 195 */       setPointer(i, source.getPointer(i));
/*     */     }
/* 197 */     if (numBytes % 4 != 0) {
/* 198 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 204 */     if (numBytes % 4 != 0) {
/* 205 */       throw new UnsupportedOperationException("PointerPtr.memmove(PointerPtr, " + numBytes + ")");
/*     */     }
/* 207 */     int numPtr = numBytes / 4;
/* 208 */     Ptr[] buffer = new Ptr[numPtr]; int i;
/* 209 */     for (i = 0; i < numPtr; i++) {
/* 210 */       buffer[i] = source.getAlignedPointer(i);
/*     */     }
/* 212 */     for (i = 0; i < numPtr; i++) {
/* 213 */       this.array[this.offset + i] = buffer[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 219 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 224 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/PointerPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */