/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpaquePtr<T>
/*     */   implements Ptr
/*     */ {
/*     */   private T[] array;
/*     */   private int recordSize;
/*     */   private int offset;
/*     */   
/*     */   public OpaquePtr(T[] array, int offset, int recordSize) {
/*  34 */     this.array = array;
/*  35 */     this.recordSize = recordSize;
/*     */   }
/*     */   
/*     */   public T get() {
/*  39 */     return this.array[0];
/*     */   }
/*     */   
/*     */   public T get(int index) {
/*  43 */     return this.array[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  48 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  53 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  58 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  63 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  68 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/*  73 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int offset) {
/*  78 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int offset, boolean value) {
/*  83 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(boolean value) {
/*  88 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/*  93 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  98 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(byte value) {
/* 103 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 108 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/* 113 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/* 118 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/* 123 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/* 128 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 133 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/* 138 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/* 143 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 148 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 153 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 158 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 163 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 168 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double value) {
/* 173 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 178 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/* 183 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/* 188 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/* 193 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 198 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 203 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 208 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 213 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int value) {
/* 218 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 223 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/* 228 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 233 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/* 238 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long value) {
/* 243 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 248 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 253 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/* 258 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 263 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/* 268 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/* 273 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 278 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/* 283 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 288 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96() {
/* 293 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/* 298 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/* 303 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/* 308 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/* 313 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 318 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/* 323 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 328 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 333 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 338 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/* 343 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedPointer(int index, Ptr value) {
/* 348 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 353 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(int byteValue, int n) {
/* 358 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 363 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 368 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int memcmp(Ptr other, int numBytes) {
/* 373 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 378 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 383 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 388 */     return (this.array == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/* 393 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Ptr o) {
/* 398 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr withOffset(int offset) {
/* 403 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/OpaquePtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */