/*      */ package org.renjin.gcc.runtime;
/*      */ 
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.lang.invoke.MethodHandle;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Random;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.function.Function;
/*      */ import org.renjin.gcc.annotations.Struct;
/*      */ import org.renjin.gcc.format.FormatArrayInput;
/*      */ import org.renjin.gcc.format.FormatInput;
/*      */ import org.renjin.gcc.format.Formatter;
/*      */ import org.renjin.gcc.format.VarArgsInput;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Stdlib
/*      */ {
/*      */   public static final int CLOCKS_PER_SEC = 4;
/*   48 */   private static long PROGRAM_START = System.currentTimeMillis();
/*      */   
/*      */   public static BytePtr tzname;
/*      */   
/*      */   public static int timezone;
/*      */   public static int daylight;
/*   54 */   public static final Ptr stdout = new RecordUnitPtr<>(new StdOutHandle(System.out));
/*      */   
/*   56 */   public static final Ptr stderr = new RecordUnitPtr<>(new StdOutHandle(System.err));
/*      */   
/*   58 */   public static final Ptr stdin = new RecordUnitPtr<>(new StdInHandle());
/*      */   
/*      */   @Deprecated
/*      */   public static int strncmp(BytePtr x, BytePtr y, int n) {
/*   62 */     return strncmp(x, y, n);
/*      */   }
/*      */   
/*      */   public static int strncmp(Ptr x, Ptr y, int n) {
/*   66 */     for (int i = 0; i < n; i++) {
/*   67 */       byte bx = x.getByte(i);
/*   68 */       byte by = y.getByte(i);
/*      */       
/*   70 */       if (bx < by)
/*   71 */         return -1; 
/*   72 */       if (bx > by) {
/*   73 */         return 1;
/*      */       }
/*   75 */       if (bx == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*   79 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int strcmp(BytePtr x, BytePtr y) {
/*   85 */     return strncmp(x, y, 2147483647);
/*      */   }
/*      */   
/*      */   public static int strcmp(Ptr x, Ptr y) {
/*   89 */     return strncmp(x, y, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int strcasecmp(Ptr x, Ptr y) {
/*  119 */     for (int i = 0; i < Integer.MAX_VALUE; i++) {
/*  120 */       int bx = Character.toLowerCase(x.getByte(i));
/*  121 */       int by = Character.toLowerCase(y.getByte(i));
/*      */       
/*  123 */       if (bx < by)
/*  124 */         return -1; 
/*  125 */       if (bx > by) {
/*  126 */         return 1;
/*      */       }
/*  128 */       if (bx == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*  132 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr strchr(Ptr string, int ch) {
/*  148 */     int pos = 0;
/*      */     while (true) {
/*  150 */       int pc = string.getByte(pos);
/*  151 */       if (pc == ch) {
/*  152 */         return string.pointerPlus(pos);
/*      */       }
/*  154 */       if (pc == 0) {
/*      */         break;
/*      */       }
/*  157 */       pos++;
/*      */     } 
/*  159 */     return BytePtr.NULL;
/*      */   }
/*      */   
/*      */   public static Ptr strrchr(Ptr string, int ch) {
/*  163 */     int len = 0;
/*  164 */     while (string.getByte(len) != 0) {
/*  165 */       len++;
/*      */     }
/*  167 */     int pos = len - 1;
/*  168 */     while (pos > 0) {
/*  169 */       int pc = string.getByte(pos);
/*  170 */       if (pc == ch) {
/*  171 */         return string.pointerPlus(pos);
/*      */       }
/*  173 */       pos--;
/*      */     } 
/*  175 */     return BytePtr.NULL;
/*      */   }
/*      */   
/*      */   public static Ptr strstr(Ptr string, Ptr searched) {
/*  179 */     int offset = nullTerminatedString(string).indexOf(nullTerminatedString(searched));
/*  180 */     return new OffsetPtr(string, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int strcspn(Ptr str1, Ptr str2) {
/*  191 */     int i = 0;
/*      */     
/*      */     while (true) {
/*  194 */       byte c = str1.getByte(i);
/*  195 */       int j = 0;
/*      */       while (true) {
/*  197 */         byte d = str2.getByte(j);
/*  198 */         if (c == d) {
/*  199 */           return i;
/*      */         }
/*  201 */         j++;
/*  202 */         if (d == 0)
/*  203 */           i++; 
/*      */       } 
/*      */       break;
/*      */     } 
/*      */   }
/*      */   @Deprecated
/*      */   public static long strtol(Ptr string) {
/*  210 */     return strtol(string, BytePtr.NULL, 10);
/*      */   }
/*      */   
/*      */   public static long strtol(Ptr str, Ptr endptr, int radix) {
/*  214 */     return strtol(str, endptr, radix, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long strtoul(Ptr str, Ptr endptr, int radix) {
/*  233 */     return strtol(str, endptr, radix, false);
/*      */   }
/*      */   
/*      */   public static double strtold(Ptr string) {
/*  237 */     return strtod(string);
/*      */   }
/*      */   
/*      */   public static double strtod(Ptr string) {
/*  241 */     return Double.parseDouble(nullTerminatedString(string));
/*      */   }
/*      */ 
/*      */   
/*      */   static long strtol(Ptr str, Ptr endptr, int radix, boolean signed) {
/*  246 */     String s = nullTerminatedString(str);
/*      */ 
/*      */     
/*  249 */     int start = 0;
/*      */ 
/*      */     
/*  252 */     while (start < s.length() && Character.isWhitespace(s.charAt(start))) {
/*  253 */       start++;
/*      */     }
/*      */     
/*  256 */     int pos = start;
/*      */ 
/*      */     
/*  259 */     if (pos < s.length() && (s.charAt(pos) == '-' || s.charAt(pos) == '+')) {
/*  260 */       pos++;
/*      */ 
/*      */     
/*      */     }
/*  264 */     else if ((radix == 0 || radix == 16) && pos + 1 < s
/*  265 */       .length() && s.charAt(pos) == '0' && (s
/*  266 */       .charAt(pos + 1) == 'x' || s.charAt(pos + 1) == 'X')) {
/*  267 */       start += 2;
/*  268 */       pos = start;
/*  269 */       radix = 16;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  274 */     else if (radix == 0 && pos < s.length() && s.charAt(pos) == '0') {
/*  275 */       radix = 8;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  280 */     if (radix == 0) {
/*  281 */       radix = 10;
/*      */     }
/*      */ 
/*      */     
/*  285 */     while (pos < s.length() && Character.digit(s.charAt(pos), radix) != -1) {
/*  286 */       pos++;
/*      */     }
/*      */ 
/*      */     
/*  290 */     if (!endptr.isNull()) {
/*  291 */       endptr.setPointer(str.pointerPlus(pos));
/*      */     }
/*      */ 
/*      */     
/*  295 */     if (start == pos) {
/*  296 */       return 0L;
/*      */     }
/*      */     
/*  299 */     s = s.substring(start, pos);
/*      */     
/*  301 */     if (signed) {
/*      */       try {
/*  303 */         return Long.parseLong(s, radix);
/*  304 */       } catch (NumberFormatException e) {
/*  305 */         return Long.MAX_VALUE;
/*      */       } 
/*      */     }
/*      */     try {
/*  309 */       return Long.parseUnsignedLong(s, radix);
/*  310 */     } catch (NumberFormatException e) {
/*  311 */       return -1L;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr strdup(Ptr s) {
/*  317 */     int strlen = strlen(s);
/*  318 */     BytePtr dup = BytePtr.malloc(strlen + 1);
/*  319 */     strcpy(dup, s);
/*  320 */     return dup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static BytePtr strcpy(BytePtr destination, BytePtr source) {
/*  330 */     return (BytePtr)strcpy(destination, source);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr strcpy(Ptr destination, Ptr source) {
/*  339 */     int length = strlen(source);
/*  340 */     for (int i = 0; i < length + 1; i++) {
/*  341 */       destination.setByte(i, source.getByte(i));
/*      */     }
/*  343 */     return destination;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static BytePtr strncpy(BytePtr destination, BytePtr source, int num) {
/*  348 */     return (BytePtr)strncpy(destination, source, num);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr strncpy(Ptr destination, Ptr source, int num) {
/*  367 */     for (int i = 0; i < num; i++) {
/*  368 */       byte srcChar = source.getByte(i);
/*  369 */       destination.setByte(i, srcChar);
/*  370 */       if (srcChar == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*  374 */     return destination;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static int atoi(BytePtr str) {
/*  379 */     return atoi(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int atoi(Ptr str) {
/*      */     try {
/*  389 */       return Integer.parseInt(nullTerminatedString(str));
/*  390 */     } catch (NumberFormatException e) {
/*  391 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static double asinh(double x) {
/*  396 */     if (Double.isInfinite(x)) {
/*  397 */       return x;
/*      */     }
/*  399 */     return Math.log(x + Math.sqrt(x * x + 1.0D));
/*      */   }
/*      */   
/*      */   public static double atanh(double x) {
/*  403 */     return 0.5D * Math.log((1.0D + x) / (1.0D - x));
/*      */   }
/*      */   
/*      */   public static String nullTerminatedString(Ptr x) {
/*  407 */     StringBuilder str = new StringBuilder();
/*  408 */     int i = 0;
/*      */     while (true) {
/*  410 */       byte b = x.getByte(i);
/*  411 */       if (b == 0) {
/*      */         break;
/*      */       }
/*  414 */       str.append((char)b);
/*  415 */       i++;
/*      */     } 
/*  417 */     return str.toString();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static int strlen(BytePtr x) {
/*  422 */     return strlen(x);
/*      */   }
/*      */   
/*      */   public static int strlen(Ptr x) {
/*  426 */     int len = 0;
/*      */     while (true) {
/*  428 */       if (x.getByte(len) == 0) {
/*  429 */         return len;
/*      */       }
/*  431 */       len++;
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static BytePtr strcat(BytePtr dest, BytePtr src) {
/*  437 */     return (BytePtr)strcat(dest, src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr strcat(Ptr dest, Ptr src) {
/*      */     byte srcByte;
/*  447 */     int destPos = 0;
/*  448 */     while (dest.getByte(destPos) != 0) {
/*  449 */       destPos++;
/*      */     }
/*      */     
/*  452 */     int srcPos = 0;
/*      */     do {
/*  454 */       srcByte = src.getByte(srcPos++);
/*  455 */       dest.setByte(destPos++, srcByte);
/*  456 */     } while (srcByte != 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  461 */     return dest;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int printf(BytePtr format, Object... arguments) {
/*      */     String outputString;
/*      */     try {
/*  468 */       outputString = format(format, f -> new FormatArrayInput(arguments));
/*  469 */     } catch (Exception e) {
/*  470 */       return -1;
/*      */     } 
/*      */     
/*  473 */     System.out.print(outputString);
/*      */     
/*  475 */     return outputString.length();
/*      */   }
/*      */   
/*      */   public static int puts(BytePtr string) {
/*  479 */     System.out.println(string.nullTerminatedString());
/*  480 */     return 0;
/*      */   }
/*      */   
/*      */   public static int putchar(int character) {
/*  484 */     System.out.println((char)character);
/*  485 */     return character;
/*      */   }
/*      */   
/*      */   public static int sprintf(BytePtr string, BytePtr format, Object... arguments) {
/*  489 */     return snprintf(string, 2147483647, format, arguments);
/*      */   }
/*      */   
/*      */   public static int snprintf(BytePtr string, int limit, BytePtr format, Object... arguments) {
/*  493 */     return sprintf(string, limit, format, f -> new FormatArrayInput(arguments));
/*      */   }
/*      */ 
/*      */   
/*      */   public static int vsnprintf(BytePtr string, int n, BytePtr format, Ptr argumentList) {
/*  498 */     return sprintf(string, n, format, f -> new VarArgsInput(f, argumentList));
/*      */   }
/*      */ 
/*      */   
/*      */   private static int sprintf(BytePtr string, int limit, BytePtr format, Function<Formatter, FormatInput> arguments) {
/*      */     String outputString;
/*      */     try {
/*  505 */       outputString = format(format, arguments);
/*  506 */     } catch (Exception e) {
/*  507 */       return -1;
/*      */     } 
/*      */     
/*  510 */     byte[] outputBytes = outputString.getBytes();
/*      */ 
/*      */     
/*  513 */     int bytesToCopy = Math.min(outputBytes.length, limit - 1);
/*      */     
/*  515 */     if (bytesToCopy > 0)
/*      */     {
/*  517 */       System.arraycopy(outputBytes, 0, string.array, string.offset, bytesToCopy);
/*      */     }
/*      */ 
/*      */     
/*  521 */     if (limit > 0) {
/*  522 */       string.array[string.offset + bytesToCopy] = 0;
/*      */     }
/*      */     
/*  525 */     return outputBytes.length;
/*      */   }
/*      */   
/*      */   public static int sscanf(BytePtr format, Object... arguments) {
/*  529 */     throw new UnsupportedOperationException("TODO: implement " + Stdlib.class.getName() + ".sscanf");
/*      */   }
/*      */ 
/*      */   
/*      */   public static int tolower(int c) {
/*  534 */     return Character.toLowerCase(c);
/*      */   }
/*      */   
/*      */   public static int toupper(int c) {
/*  538 */     return Character.toUpperCase(c);
/*      */   }
/*      */   
/*      */   public static String format(Ptr format, Object... arguments) {
/*  542 */     return format(format, f -> new FormatArrayInput(arguments));
/*      */   }
/*      */   
/*      */   public static String format(Ptr format, Function<Formatter, FormatInput> input) {
/*  546 */     String formatString = nullTerminatedString(format);
/*  547 */     Formatter formatter = new Formatter(formatString);
/*  548 */     return formatter.format(input.apply(formatter));
/*      */   }
/*      */   
/*      */   public static void qsort(Ptr base, int nitems, int size, MethodHandle comparator) {
/*  552 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static void qsort(Object base, int nitems, int size, MethodHandle comparator) {
/*  557 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static ObjectPtr<CharPtr> __ctype_b_loc() {
/*  562 */     return CharTypes.TABLE_OBJECT_PTR;
/*      */   }
/*      */ 
/*      */   
/*      */   @Struct
/*      */   public static int[] div(int numer, int denom) {
/*  568 */     int quot = numer / denom;
/*  569 */     int rem = numer % denom;
/*      */     
/*  571 */     return new int[] { quot, rem };
/*      */   }
/*      */   
/*      */   public static double nearbyint(double arg) {
/*  575 */     return Math.round(arg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int time(IntPtr seconds) {
/*  584 */     return time(seconds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int time(Ptr seconds) {
/*  592 */     int time = (int)(System.currentTimeMillis() / 1000L);
/*  593 */     if (!seconds.isNull()) {
/*  594 */       seconds.setInt(time);
/*      */     }
/*  596 */     return time;
/*      */   }
/*      */   
/*  599 */   private static final DateFormat CTIME_FORMAT = new SimpleDateFormat("E MMM d HH:mm:ss yyyy");
/*      */ 
/*      */   
/*      */   private static final int CLOCK_REALTIME = 0;
/*      */ 
/*      */   
/*      */   private static final int CLOCK_MONOTONIC = 1;
/*      */ 
/*      */   
/*      */   private static final int CLOCK_MONOTONIC_RAW = 4;
/*      */ 
/*      */   
/*      */   private static final int CLOCK_REALTIME_COARSE = 5;
/*      */ 
/*      */   
/*      */   public static BytePtr ctime(IntPtr timePtr) {
/*  615 */     Date date = new Date(timePtr.get() * 1000L);
/*  616 */     return BytePtr.nullTerminatedString(CTIME_FORMAT.format(date) + "\n", StandardCharsets.US_ASCII);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static tm localtime(IntPtr time) {
/*  621 */     return new tm(time.unwrap());
/*      */   }
/*      */   
/*      */   public static Ptr localtime(Ptr time) {
/*  625 */     int instant = time.getInt();
/*  626 */     Calendar instance = Calendar.getInstance();
/*  627 */     instance.setTimeInMillis(instant);
/*      */     
/*  629 */     int[] tm = new int[9];
/*  630 */     tm[0] = instance.get(13);
/*  631 */     tm[1] = instance.get(12);
/*  632 */     tm[2] = instance.get(10);
/*  633 */     tm[3] = instance.get(5);
/*  634 */     tm[4] = instance.get(2);
/*  635 */     tm[5] = instance.get(1);
/*  636 */     tm[6] = instance.get(7);
/*  637 */     tm[7] = instance.get(6);
/*  638 */     tm[8] = instance.getTimeZone().inDaylightTime(new Date(instant)) ? 1 : 0;
/*      */     
/*  640 */     return new IntPtr(tm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void tzset() {
/*  650 */     TimeZone currentTimezone = TimeZone.getDefault();
/*  651 */     tzname = BytePtr.nullTerminatedString(currentTimezone.getDisplayName(), StandardCharsets.US_ASCII);
/*  652 */     timezone = currentTimezone.getOffset(System.currentTimeMillis());
/*  653 */     daylight = currentTimezone.inDaylightTime(new Date()) ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void fflush(Object file) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int clock() {
/*  666 */     long millisSinceProgramStart = System.currentTimeMillis() - PROGRAM_START;
/*  667 */     int secondsSinceProgramStart = (int)TimeUnit.MILLISECONDS.toSeconds(millisSinceProgramStart);
/*  668 */     return secondsSinceProgramStart * 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int clock_gettime(int clockId, timespec tp) {
/*  693 */     switch (clockId) {
/*      */       
/*      */       case 0:
/*      */       case 5:
/*  697 */         tp.set(System.currentTimeMillis(), TimeUnit.MILLISECONDS);
/*  698 */         return 0;
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 4:
/*  703 */         tp.set(System.nanoTime(), TimeUnit.NANOSECONDS);
/*  704 */         return 0;
/*      */     } 
/*      */ 
/*      */     
/*  708 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int clock_gettime(int clockId, Ptr tp) {
/*      */     long duration;
/*      */     TimeUnit timeUnit;
/*      */     int seconds;
/*      */     int nanoseconds;
/*  717 */     switch (clockId) {
/*      */       
/*      */       case 0:
/*      */       case 5:
/*  721 */         duration = System.currentTimeMillis();
/*  722 */         timeUnit = TimeUnit.MILLISECONDS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  740 */         seconds = (int)timeUnit.toSeconds(duration);
/*  741 */         nanoseconds = (int)(timeUnit.toNanos(duration) - TimeUnit.SECONDS.toNanos(seconds));
/*      */         
/*  743 */         tp.setAlignedInt(0, seconds);
/*  744 */         tp.setAlignedInt(1, nanoseconds);
/*      */         
/*  746 */         return 0;case 1: case 4: duration = System.nanoTime(); timeUnit = TimeUnit.NANOSECONDS; seconds = (int)timeUnit.toSeconds(duration); nanoseconds = (int)(timeUnit.toNanos(duration) - TimeUnit.SECONDS.toNanos(seconds)); tp.setAlignedInt(0, seconds); tp.setAlignedInt(1, nanoseconds); return 0;
/*      */     } 
/*      */     return -1;
/*      */   } @Deprecated
/*      */   public static Object fopen() {
/*  751 */     throw new UnsupportedOperationException("Please recompile with the latest version of Renjin.");
/*      */   }
/*      */   
/*      */   public static Ptr fopen(Ptr filename, Ptr mode) {
/*  755 */     String filenameString = nullTerminatedString(filename);
/*  756 */     String modeString = nullTerminatedString(mode);
/*      */     
/*  758 */     switch (modeString) {
/*      */       case "r":
/*      */       case "rb":
/*      */         try {
/*  762 */           return new RecordUnitPtr<>(new FileHandleImpl(new RandomAccessFile(filenameString, "r")));
/*  763 */         } catch (FileNotFoundException e) {
/*  764 */           return BytePtr.NULL;
/*      */         } 
/*      */       case "w":
/*      */       case "wb":
/*      */         try {
/*  769 */           return new RecordUnitPtr<>(new FileHandleImpl(new RandomAccessFile(filenameString, "rw")));
/*  770 */         } catch (FileNotFoundException e) {
/*  771 */           return BytePtr.NULL;
/*      */         } 
/*      */     } 
/*  774 */     throw new UnsupportedOperationException("Not implemented. Mode = " + modeString);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int fflush(Ptr stream) throws IOException {
/*  779 */     FileHandle handle = (FileHandle)stream.getArray();
/*  780 */     handle.flush();
/*  781 */     return 0;
/*      */   }
/*      */   
/*      */   public static int fprintf(Ptr stream, BytePtr format, Object... arguments) {
/*      */     try {
/*  786 */       String outputString = format(format, f -> new FormatArrayInput(arguments));
/*  787 */       BytePtr outputBytes = BytePtr.nullTerminatedString(outputString, StandardCharsets.UTF_8);
/*  788 */       int bytesWritten = fwrite(outputBytes, 1, (outputBytes.getArray()).length, stream);
/*      */       
/*  790 */       return bytesWritten;
/*  791 */     } catch (Exception e) {
/*  792 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static int fwrite(BytePtr ptr, int size, int count, Ptr stream) throws IOException {
/*  799 */     return fwrite(ptr, size, count, stream);
/*      */   }
/*      */   
/*      */   public static int fwrite(Ptr ptr, int size, int count, Ptr stream) throws IOException {
/*  803 */     FileHandle handle = (FileHandle)stream.getArray();
/*  804 */     int bytesWritten = 0;
/*      */ 
/*      */ 
/*      */     
/*  808 */     for (int i = 0; i < count * size; i++) {
/*      */       try {
/*  810 */         handle.write(ptr.getByte(i));
/*  811 */         bytesWritten++;
/*  812 */       } catch (ArrayIndexOutOfBoundsException aioobe) {
/*  813 */         i = count * size;
/*      */       } 
/*      */     } 
/*      */     
/*  817 */     return bytesWritten;
/*      */   }
/*      */   
/*      */   public static int ferror(Ptr stream) {
/*  821 */     FileHandle handle = (FileHandle)stream.getArray();
/*      */     
/*  823 */     return handle.getError();
/*      */   }
/*      */   
/*      */   public static void clearerr(Ptr stream) {
/*  827 */     FileHandle handle = (FileHandle)stream.getArray();
/*      */     
/*  829 */     handle.clearError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int fread(Ptr ptr, int size, int count, Ptr stream) throws IOException {
/*  845 */     FileHandle handle = (FileHandle)stream.getArray();
/*      */     
/*  847 */     int bytesRead = 0;
/*      */ 
/*      */ 
/*      */     
/*  851 */     for (int i = 0; i < count * size; i++) {
/*  852 */       int b = handle.read();
/*  853 */       if (b == -1) {
/*      */         break;
/*      */       }
/*  856 */       ptr.setByte(i, (byte)b);
/*  857 */       bytesRead++;
/*      */     } 
/*      */ 
/*      */     
/*  861 */     return bytesRead / size;
/*      */   }
/*      */   
/*      */   public static void rewind(Ptr stream) throws IOException {
/*  865 */     FileHandle handle = (FileHandle)stream.getArray();
/*  866 */     handle.rewind();
/*      */   }
/*      */   
/*      */   public static int fseek(Ptr stream, long offset, int whence) {
/*  870 */     FileHandle fileHandle = (FileHandle)stream.getArray();
/*      */     try {
/*  872 */       switch (whence) {
/*      */         case 0:
/*  874 */           fileHandle.seekSet(offset);
/*      */           break;
/*      */         case 1:
/*  877 */           fileHandle.seekCurrent(offset);
/*      */           break;
/*      */         case 2:
/*  880 */           fileHandle.seekEnd(offset);
/*      */           break;
/*      */       } 
/*  883 */       return 0;
/*  884 */     } catch (IOException e) {
/*  885 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static int fclose(Ptr stream) {
/*      */     try {
/*  891 */       ((FileHandle)stream.getArray()).close();
/*  892 */       return 0;
/*  893 */     } catch (IOException e) {
/*  894 */       return -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static int fgetc(Ptr stream) {
/*      */     try {
/*  900 */       return ((FileHandle)stream.getArray()).read();
/*  901 */     } catch (IOException e) {
/*  902 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int fputc(int character, Ptr stream) {
/*  921 */     FileHandle handle = (FileHandle)stream.getArray();
/*      */     try {
/*  923 */       handle.write(character);
/*  924 */       return character;
/*  925 */     } catch (IOException e) {
/*  926 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int __isinf(double x) {
/*  941 */     return Double.isInfinite(x) ? 1 : 0;
/*      */   }
/*      */   
/*      */   public static int isinf(double x) {
/*  945 */     return __isinf(x);
/*      */   }
/*      */   
/*      */   public static float logf(float x) {
/*  949 */     return (float)Math.log(x);
/*      */   }
/*      */ 
/*      */   
/*      */   public static long lroundf(float x) {
/*  954 */     if (Float.isInfinite(x)) {
/*  955 */       if (x < 0.0F) {
/*  956 */         return Long.MIN_VALUE;
/*      */       }
/*  958 */       return Long.MAX_VALUE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  964 */     long sign = (long)Math.signum(x);
/*  965 */     long closest = Math.round(Math.abs(x));
/*      */     
/*  967 */     return closest * sign;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int __cxa_guard_acquire(LongPtr guard_object) {
/*  977 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void __cxa_guard_release(LongPtr guard_object) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void __cxa_guard_abort(LongPtr p) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void __cxa_free_exception(Ptr p) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void __cxa_call_unexpected(Ptr p) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int __cxa_atexit(MethodHandle fn, Ptr arg, Ptr dso_handle) {
/* 1012 */     return 0;
/*      */   }
/*      */   
/*      */   public static int posix_memalign(Ptr memPtr, int aligment, int size) {
/* 1016 */     memPtr.setPointer(MixedPtr.malloc(size));
/* 1017 */     return 0;
/*      */   }
/*      */   
/*      */   public static void inlineAssembly() {
/* 1021 */     throw new UnsupportedOperationException("Compilation of inline assembly not supported");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1030 */   private static final ThreadLocal<Random> RANDOM = new ThreadLocal<Random>()
/*      */     {
/*      */       protected Random initialValue() {
/* 1033 */         return new Random(1L);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RAND_MAX = 2147483647;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void srand(int seed) {
/* 1060 */     ((Random)RANDOM.get()).setSeed(seed);
/*      */   }
/*      */   
/*      */   public static int rand() {
/* 1064 */     return ((Random)RANDOM.get()).nextInt(2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _setjmp(Ptr buf) {
/* 1070 */     return 0;
/*      */   }
/*      */   
/*      */   public static void longjmp(Ptr buf, int value) {
/* 1074 */     throw new LongJumpException(buf, value);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Stdlib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */