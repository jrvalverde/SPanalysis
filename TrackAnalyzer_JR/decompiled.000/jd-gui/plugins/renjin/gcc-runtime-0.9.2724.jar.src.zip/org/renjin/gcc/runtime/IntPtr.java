/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntPtr
/*     */   extends AbstractPtr
/*     */   implements Ptr
/*     */ {
/*     */   public static final int BYTES = 4;
/*  28 */   public static final IntPtr NULL = new IntPtr();
/*     */   
/*     */   public final int[] array;
/*     */   public final int offset;
/*     */   
/*     */   private IntPtr() {
/*  34 */     this.array = null;
/*  35 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public IntPtr(int[] array, int offset) {
/*  39 */     this.array = array;
/*  40 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public IntPtr(int... array) {
/*  44 */     this.array = array;
/*  45 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public static IntPtr malloc(int bytes) {
/*  49 */     return new IntPtr(new int[AbstractPtr.mallocSize(bytes, 4)]);
/*     */   }
/*     */   
/*     */   public static Ptr toPtr(int i) {
/*  53 */     if (i == 0) {
/*  54 */       return NULL;
/*     */     }
/*  56 */     throw new UnsupportedOperationException(String.format("Cannot cast integer %x to pointer", new Object[] { Integer.valueOf(i) }));
/*     */   }
/*     */ 
/*     */   
/*     */   public static int fromPtr(Ptr ptr) {
/*  61 */     if (ptr.isNull()) {
/*  62 */       return 0;
/*     */     }
/*  64 */     return ptr.toInt();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getArray() {
/*  70 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  75 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  80 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public IntPtr realloc(int newSizeInBytes) {
/*  85 */     return new IntPtr(Realloc.realloc(this.array, this.offset, newSizeInBytes / 4));
/*     */   }
/*     */   
/*     */   public int unwrap() {
/*  89 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public int get() {
/*  93 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public void set(int value) {
/*  97 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 102 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(int[] str, int strOffset, int byteValue, int n) {
/* 116 */     assert n % 4 == 0;
/*     */     
/* 118 */     Arrays.fill(str, strOffset, strOffset + n / 4, memset(byteValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memset(int byteValue) {
/* 125 */     return byteValue << 24 | (byteValue & 0xFF) << 16 | (byteValue & 0xFF) << 8 | byteValue & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memcmp(IntPtr x, IntPtr y, int n) {
/* 132 */     return memcmp(x.array, x.offset, y.array, y.offset, n);
/*     */   }
/*     */   
/*     */   public static int memcmp(int[] x, int xi, int[] y, int yi, int n) {
/* 136 */     while (n > 0) {
/* 137 */       int vx = x[xi];
/* 138 */       int vy = y[yi];
/*     */       
/* 140 */       if (vx != vy || n < 4) {
/* 141 */         return memcmp(vx, vy, n);
/*     */       }
/* 143 */       xi++;
/* 144 */       yi++;
/* 145 */       n -= 4;
/*     */     } 
/* 147 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memcmp(int x, int y, int n) {
/* 162 */     for (int i = 0; i < n; i++) {
/* 163 */       int xb = (int)(x & 0xFFL);
/* 164 */       int yb = (int)(y & 0xFFL);
/*     */       
/* 166 */       if (xb < yb)
/* 167 */         return -1; 
/* 168 */       if (xb > yb) {
/* 169 */         return 1;
/*     */       }
/* 171 */       x >>= 8;
/* 172 */       y >>= 8;
/*     */     } 
/* 174 */     return 0;
/*     */   }
/*     */   
/*     */   public static IntPtr cast(Object voidPointer) {
/* 178 */     if (voidPointer instanceof MallocThunk) {
/* 179 */       return ((MallocThunk)voidPointer).intPtr();
/*     */     }
/* 181 */     if (voidPointer == null) {
/* 182 */       return NULL;
/*     */     }
/* 184 */     return (IntPtr)voidPointer;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 189 */     return getByteViaInt(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 194 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 199 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 204 */     if (this.offset % 4 == 0) {
/* 205 */       return this.array[this.offset + offset / 4];
/*     */     }
/* 207 */     return super.getInt(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 213 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int byteOffset, int intValue) {
/* 218 */     if (byteOffset % 4 == 0) {
/* 219 */       this.array[this.offset + byteOffset / 4] = intValue;
/*     */     } else {
/* 221 */       super.setInt(byteOffset, intValue);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 227 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 232 */     setByteViaInt(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 237 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 242 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 247 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int byteCount) {
/* 252 */     if (byteCount % 4 == 0) {
/* 253 */       return new IntPtr(this.array, this.offset + byteCount / 4);
/*     */     }
/* 255 */     return new OffsetPtr(this, byteCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int unsignedCompare(int a, int b) {
/* 268 */     return Integer.compareUnsigned(a, b);
/*     */   }
/*     */   
/*     */   public static int unsignedMax(int a, int b) {
/* 272 */     if (Long.compareUnsigned(a, b) > 0) {
/* 273 */       return a;
/*     */     }
/* 275 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int unsignedMin(int a, int b) {
/* 280 */     if (Long.compareUnsigned(a, b) < 0) {
/* 281 */       return a;
/*     */     }
/* 283 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int unsignedDivide(int dividend, int divisor) {
/* 293 */     return Integer.divideUnsigned(dividend, divisor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int unsignedRemainder(int dividend, int divisor) {
/* 301 */     return Integer.remainderUnsigned(dividend, divisor);
/*     */   }
/*     */   
/*     */   public static void memcpy(IntPtr x, IntPtr y, int numBytes) {
/* 305 */     int[] arrayS = y.getArray();
/* 306 */     int offsetS = y.getOffset();
/* 307 */     int restY = arrayS.length - offsetS;
/* 308 */     if (restY > 0) {
/* 309 */       int[] carray = new int[numBytes];
/* 310 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 311 */         carray[i] = arrayS[j];
/*     */       }
/* 313 */       x = new IntPtr(carray);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/IntPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */