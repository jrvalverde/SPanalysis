/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MixedPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   private static final int POINTER_BYTES = 4;
/*     */   private ByteBuffer primitives;
/*     */   private Object[] references;
/*  40 */   private int offset = 0;
/*     */ 
/*     */   
/*     */   private MixedPtr() {}
/*     */   
/*     */   private MixedPtr(ByteBuffer primitives, Object[] references, int offset) {
/*  46 */     this.primitives = primitives;
/*  47 */     this.references = references;
/*  48 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public static MixedPtr malloc(int bytes) {
/*  52 */     MixedPtr ptr = new MixedPtr();
/*     */     try {
/*  54 */       ptr.primitives = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder());
/*  55 */       ptr.references = new Object[mallocSize(bytes, 4)];
/*  56 */     } catch (OutOfMemoryError e) {
/*  57 */       System.err.println("MixedPtr out of memory");
/*  58 */       throw e;
/*     */     } 
/*  60 */     return ptr;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  65 */     return this.primitives;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  70 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  75 */     if (newSizeInBytes == this.primitives.capacity()) {
/*  76 */       return this;
/*     */     }
/*     */     
/*  79 */     ByteBuffer source = this.primitives.asReadOnlyBuffer();
/*  80 */     source.position(0);
/*  81 */     source.limit(Math.min(source.capacity(), newSizeInBytes));
/*     */     
/*  83 */     ByteBuffer target = ByteBuffer.allocateDirect(newSizeInBytes).order(ByteOrder.nativeOrder());
/*  84 */     target.put(source);
/*  85 */     target.position(0);
/*  86 */     target.limit(newSizeInBytes);
/*     */     
/*  88 */     MixedPtr ptr = new MixedPtr();
/*  89 */     ptr.primitives = target;
/*  90 */     ptr.references = Arrays.copyOf(this.references, mallocSize(newSizeInBytes, 4));
/*  91 */     return ptr;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  96 */     if (bytes == 0) {
/*  97 */       return this;
/*     */     }
/*  99 */     return new MixedPtr(this.primitives, this.references, this.offset + bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 104 */     return this.primitives.get(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 109 */     this.primitives.put(this.offset + offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 114 */     int byteStart = this.offset + offset;
/* 115 */     if (byteStart % 4 == 0) {
/* 116 */       int index = byteStart / 4;
/*     */       
/* 118 */       Ptr ref = (Ptr)this.references[index];
/* 119 */       if (ref != null) {
/* 120 */         return ref;
/*     */       }
/*     */     } 
/*     */     
/* 124 */     return BytePtr.NULL.pointerPlus(getInt(offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void setPointer(int offset, Ptr value) {
/* 129 */     int byteStart = this.offset + offset;
/* 130 */     if (byteStart % 4 != 0) {
/* 131 */       throw new UnsupportedOperationException("Unaligned pointer storage");
/*     */     }
/* 133 */     int index = byteStart / 4;
/* 134 */     this.references[index] = value;
/*     */     
/* 136 */     setInt(offset, value.toInt());
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 141 */     return this.primitives.getDouble(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 146 */     return this.primitives.getDouble(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 151 */     return this.primitives.getDouble(this.offset + index * 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 156 */     this.primitives.putDouble(this.offset + index * 8, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 161 */     this.primitives.putDouble(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double doubleValue) {
/* 166 */     this.primitives.putDouble(this.offset + offset, doubleValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 171 */     return this.primitives.getInt(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 176 */     return this.primitives.getInt(this.offset + index * 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 181 */     return this.primitives.getInt(this.offset + offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 186 */     this.primitives.putInt(this.offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int intValue) {
/* 191 */     this.primitives.putInt(this.offset + offset, intValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 196 */     this.primitives.putInt(this.offset + index * 4, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 201 */     return getOffsetInBytes();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 211 */     if (source instanceof MixedPtr && numBytes % 4 == 0) {
/* 212 */       MixedPtr ptr = (MixedPtr)source;
/* 213 */       for (int i = 0; i < numBytes; i++) {
/* 214 */         setByte(i, source.getByte(i));
/*     */       }
/*     */       
/* 217 */       System.arraycopy(ptr.references, ptr.offset / 4, this.references, this.offset / 4, numBytes / 4);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 223 */       for (int i = 0; i < numBytes; i++) {
/* 224 */         setByte(i, source.getByte(i));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 232 */     ByteBuffer source = this.primitives.asReadOnlyBuffer();
/* 233 */     source.position(this.offset + offset);
/* 234 */     source.limit(this.offset + offset + numBytes);
/*     */     
/* 236 */     MixedPtr copy = new MixedPtr();
/* 237 */     copy.primitives = ByteBuffer.allocateDirect(numBytes).order(ByteOrder.nativeOrder());
/* 238 */     copy.primitives.put(source);
/* 239 */     copy.primitives.position(0);
/* 240 */     copy.references = Arrays.copyOfRange(this.references, (this.offset + offset) / 4, (this.offset + offset + numBytes) / 4);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     assert copy.primitives.remaining() == numBytes;
/*     */     
/* 247 */     return copy;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/MixedPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */