/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordUnitPtr<T>
/*     */   implements Ptr
/*     */ {
/*     */   private T record;
/*     */   
/*     */   public RecordUnitPtr(T record) {
/*  32 */     this.record = record;
/*     */   }
/*     */   
/*     */   public T get() {
/*  36 */     return this.record;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  41 */     return this.record;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  46 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  51 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  56 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  61 */     if (bytes == 0) {
/*  62 */       return this;
/*     */     }
/*  64 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/*  69 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int offset) {
/*  74 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int offset, boolean value) {
/*  79 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(boolean value) {
/*  84 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte() {
/*  89 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  94 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(byte value) {
/*  99 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 104 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort() {
/* 109 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int offset) {
/* 114 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(short value) {
/* 119 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int offset, short value) {
/* 124 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 129 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) {
/* 134 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(char value) {
/* 139 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChar(int offset, char value) {
/* 144 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 149 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 154 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 159 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 164 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int offset, double value) {
/* 169 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 174 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int offset) {
/* 179 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(float value) {
/* 184 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int offset, float value) {
/* 189 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 194 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int offset) {
/* 199 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAlignedInt(int index) {
/* 204 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int value) {
/* 209 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int offset, int value) {
/* 214 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 219 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAlignedLong(int index) {
/* 224 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int offset) {
/* 229 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(long value) {
/* 234 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int offset, long value) {
/* 239 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer() {
/* 244 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/* 249 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(Ptr value) {
/* 254 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPointer(int offset, Ptr value) {
/* 259 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public short getAlignedShort(int index) {
/* 264 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedShort(int index, short shortValue) {
/* 269 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAlignedChar(int index) {
/* 274 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedChar(int index, char value) {
/* 279 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 284 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96() {
/* 289 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getReal96(int offset) {
/* 294 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedReal96(int index) {
/* 299 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(double value) {
/* 304 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReal96(int offset, double value) {
/* 309 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedReal96(int index, double value) {
/* 314 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlignedFloat(int index) {
/* 319 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedFloat(int index, float value) {
/* 324 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedInt(int index, int value) {
/* 329 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedLong(int index, long value) {
/* 334 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getAlignedPointer(int index) {
/* 339 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedPointer(int index, Ptr value) {
/* 344 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 349 */     return System.identityHashCode(this.record);
/*     */   }
/*     */ 
/*     */   
/*     */   public void memset(int byteValue, int n) {
/* 354 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 359 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void memmove(Ptr source, int numBytes) {
/* 364 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int memcmp(Ptr other, int numBytes) {
/* 369 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int offset, int numBytes) {
/* 374 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr copyOf(int numBytes) {
/* 379 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 384 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/* 389 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Ptr o) {
/* 394 */     if (this.record == o.getArray()) {
/* 395 */       return 0;
/*     */     }
/* 397 */     return Integer.compare(toInt(), o.toInt());
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr withOffset(int offset) {
/* 402 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/RecordUnitPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */