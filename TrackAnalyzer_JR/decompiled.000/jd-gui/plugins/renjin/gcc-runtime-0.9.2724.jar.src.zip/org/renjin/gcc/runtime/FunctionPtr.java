/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionPtr
/*     */   extends AbstractPtr
/*     */ {
/*     */   private static MethodHandle BAD_HANDLE;
/*     */   public static final int BYTES = 4;
/*     */   private MethodHandle[] array;
/*     */   private int offset;
/*     */   
/*     */   public FunctionPtr(MethodHandle[] array, int offset) {
/*  36 */     this.array = array;
/*  37 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArray() {
/*  42 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  47 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/*  52 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/*  57 */     if (bytes % 4 == 0) {
/*  58 */       return new FunctionPtr(this.array, this.offset + bytes / 4);
/*     */     }
/*  60 */     return new OffsetPtr(this, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/*  66 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/*  71 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/*  76 */     return this.offset * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/*  81 */     return (this.array == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr getPointer(int offset) {
/*  86 */     if (offset % 4 == 0) {
/*  87 */       return new FunctionPtr1(this.array[this.offset + offset / 4]);
/*     */     }
/*  89 */     throw new UnsupportedOperationException("Unaligned pointer access");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodHandle toMethodHandle() {
/*  95 */     return this.array[0];
/*     */   }
/*     */   
/*     */   public static void invalidFunction() {
/*  99 */     throw new RuntimeException("Not a function pointer. SEGFAULT.");
/*     */   }
/*     */   
/*     */   public static MethodHandle getBadHandle() {
/* 103 */     if (BAD_HANDLE == null) {
/*     */       try {
/* 105 */         BAD_HANDLE = MethodHandles.publicLookup().findStatic(FunctionPtr.class, "invalidFunction", MethodType.methodType(void.class));
/* 106 */       } catch (NoSuchMethodException|IllegalAccessException e) {
/* 107 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/* 110 */     return BAD_HANDLE;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/FunctionPtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */