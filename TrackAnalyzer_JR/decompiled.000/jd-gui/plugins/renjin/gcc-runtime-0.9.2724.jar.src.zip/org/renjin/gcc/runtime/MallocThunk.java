/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.renjin.gcc.annotations.GccSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MallocThunk
/*     */   extends AbstractPtr
/*     */ {
/*     */   public int bytes;
/*  44 */   public Object pointer = null;
/*     */   
/*     */   public MallocThunk(int bytes) {
/*  47 */     this.bytes = bytes;
/*     */   }
/*     */   
/*     */   public BooleanPtr booleanPtr() {
/*  51 */     if (this.pointer == null) {
/*  52 */       this.pointer = new BooleanPtr(new boolean[this.bytes]);
/*     */     }
/*  54 */     return (BooleanPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public BytePtr bytePtr() {
/*  58 */     if (this.pointer == null) {
/*  59 */       this.pointer = new BytePtr(new byte[this.bytes]);
/*     */     }
/*  61 */     return (BytePtr)this.pointer;
/*     */   }
/*     */   
/*     */   public ShortPtr shortPtr() {
/*  65 */     if (this.pointer == null) {
/*  66 */       this.pointer = new ShortPtr(new short[this.bytes / 2]);
/*     */     }
/*  68 */     return (ShortPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public CharPtr charPtr() {
/*  72 */     if (this.pointer == null) {
/*  73 */       this.pointer = new CharPtr(new char[this.bytes / 2]);
/*     */     }
/*  75 */     return (CharPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public IntPtr intPtr() {
/*  79 */     if (this.pointer == null) {
/*  80 */       this.pointer = new IntPtr(new int[this.bytes / 4]);
/*     */     }
/*  82 */     return (IntPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public LongPtr longPtr() {
/*  86 */     if (this.pointer == null) {
/*  87 */       this.pointer = new LongPtr(new long[this.bytes / 8]);
/*     */     }
/*  89 */     return (LongPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public FloatPtr floatPtr() {
/*  93 */     if (this.pointer == null) {
/*  94 */       this.pointer = new FloatPtr(new float[this.bytes / 4]);
/*     */     }
/*  96 */     return (FloatPtr)this.pointer;
/*     */   }
/*     */   
/*     */   public DoublePtr doublePtr() {
/* 100 */     if (this.pointer == null) {
/* 101 */       this.pointer = new DoublePtr(new double[this.bytes / 8], 0);
/*     */     }
/* 103 */     return (DoublePtr)this.pointer;
/*     */   }
/*     */   
/*     */   public <T> T recordUnitPtr(Class<T> recordType) {
/* 107 */     if (this.pointer == null) {
/* 108 */       if (this.bytes != sizeOf(recordType)) {
/* 109 */         throw new IllegalStateException(String.format("Misclassified record pointer: %s (bug in gcc-bridge compilation)", new Object[] { recordType
/*     */                 
/* 111 */                 .getName() }));
/*     */       }
/* 113 */       Constructor<?> constructor = constructorFor(recordType);
/*     */       try {
/* 115 */         this.pointer = constructor.newInstance(new Object[0]);
/* 116 */       } catch (Exception e) {
/* 117 */         throw new RuntimeException("Failed to malloc element of type " + recordType.getClass().getName(), e);
/*     */       } 
/*     */     } 
/* 120 */     return (T)this.pointer;
/*     */   }
/*     */   
/*     */   public ObjectPtr objectPtr(Class<?> componentType) {
/* 124 */     if (this.pointer == null) {
/* 125 */       int sizeInBytes = sizeOf(componentType);
/*     */       
/* 127 */       Constructor<?> constructor = constructorFor(componentType);
/*     */       
/* 129 */       int numElements = this.bytes / sizeInBytes;
/* 130 */       Object[] array = (Object[])Array.newInstance(componentType, numElements);
/* 131 */       for (int i = 0; i < array.length; i++) {
/*     */         try {
/* 133 */           array[i] = constructor.newInstance(new Object[0]);
/* 134 */         } catch (Exception e) {
/* 135 */           throw new IllegalStateException(String.format("Exception malloc'ing array for class %s: %s", new Object[] { componentType
/* 136 */                   .getName(), e.getMessage() }), e);
/*     */         } 
/*     */       } 
/* 139 */       this.pointer = new ObjectPtr(array);
/*     */     } 
/*     */     
/* 142 */     return (ObjectPtr)this.pointer;
/*     */   }
/*     */   
/*     */   private Constructor<?> constructorFor(Class<?> componentType) {
/*     */     Constructor<?> constructor;
/*     */     try {
/* 148 */       constructor = componentType.getConstructor(new Class[0]);
/* 149 */     } catch (NoSuchMethodException e) {
/* 150 */       throw new IllegalStateException(String.format("Cannot malloc array for class %s: no default constructor.", new Object[] { componentType
/* 151 */               .getName() }), e);
/*     */     } 
/* 153 */     return constructor;
/*     */   }
/*     */ 
/*     */   
/*     */   private int sizeOf(Class<?> componentType) {
/* 158 */     if (componentType.equals(ObjectPtr.class))
/*     */     {
/* 160 */       return 4;
/*     */     }
/*     */     
/* 163 */     GccSize size = componentType.<GccSize>getAnnotation(GccSize.class);
/* 164 */     if (size == null) {
/* 165 */       throw new IllegalStateException(String.format("Cannot malloc array for class %s: @GccSize annotation is absent.", new Object[] { componentType
/* 166 */               .getName() }));
/*     */     }
/* 168 */     int sizeInBytes = size.value();
/* 169 */     if (sizeInBytes <= 0) {
/* 170 */       throw new IllegalStateException(String.format("Cannot malloc array for class %s: @GccSize = %d", new Object[] { componentType
/* 171 */               .getName(), Integer.valueOf(sizeInBytes) }));
/*     */     }
/* 173 */     return sizeInBytes;
/*     */   }
/*     */   
/*     */   public void assign(Object[] array, int offset) {
/* 177 */     if (this.pointer == null) {
/* 178 */       this.pointer = allocElement(array);
/*     */     }
/* 180 */     array[offset] = this.pointer;
/*     */   }
/*     */   
/*     */   private Object allocElement(Object[] array) {
/* 184 */     if (array instanceof BooleanPtr[])
/* 185 */       return booleanPtr(); 
/* 186 */     if (array instanceof BytePtr[])
/* 187 */       return bytePtr(); 
/* 188 */     if (array instanceof CharPtr[])
/* 189 */       return charPtr(); 
/* 190 */     if (array instanceof DoublePtr[])
/* 191 */       return doublePtr(); 
/* 192 */     if (array instanceof FloatPtr[])
/* 193 */       return floatPtr(); 
/* 194 */     if (array instanceof IntPtr[])
/* 195 */       return intPtr(); 
/* 196 */     if (array instanceof LongPtr[])
/* 197 */       return longPtr(); 
/* 198 */     if (array instanceof ShortPtr[])
/* 199 */       return shortPtr(); 
/* 200 */     if (array instanceof ObjectPtr[]) {
/* 201 */       throw new UnsupportedOperationException("TODO");
/*     */     }
/*     */ 
/*     */     
/* 205 */     Class<?> componentType = array.getClass().getComponentType();
/*     */     try {
/* 207 */       return componentType.newInstance();
/* 208 */     } catch (Exception e) {
/* 209 */       throw new RuntimeException("Exception while triggering malloc thunk for " + componentType.getName(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object malloc(int size) {
/* 226 */     return new MallocThunk(size);
/*     */   }
/*     */   
/*     */   public static Object calloc(int numElements, int elementSize) {
/* 230 */     return new MallocThunk(numElements * elementSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void free(Object ptr) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getArray() {
/* 246 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 251 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/* 256 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr realloc(int newSizeInBytes) {
/* 261 */     if (this.pointer != null) {
/* 262 */       return ((Ptr)this.pointer).realloc(newSizeInBytes);
/*     */     }
/* 264 */     return new MallocThunk(newSizeInBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int bytes) {
/* 271 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 276 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 281 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 286 */     throw new UnsupportedOperationException("TODO");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 291 */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/MallocThunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */