/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class timespec
/*    */ {
/*    */   public int tv_sec;
/*    */   public int tv_nsec;
/*    */   
/*    */   public void set(long duration, TimeUnit timeUnit) {
/* 32 */     this.tv_sec = (int)timeUnit.toSeconds(duration);
/* 33 */     this.tv_nsec = (int)timeUnit.toNanos(duration - timeUnit.convert(this.tv_sec, TimeUnit.SECONDS));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/timespec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */