/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.lang.invoke.MethodHandle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionPtr1
/*    */   extends AbstractPtr
/*    */ {
/*    */   private MethodHandle methodHandle;
/*    */   
/*    */   public static Ptr malloc(MethodHandle methodHandle) {
/* 31 */     return new FunctionPtr1(methodHandle);
/*    */   }
/*    */   
/*    */   public FunctionPtr1(MethodHandle methodHandle) {
/* 35 */     this.methodHandle = methodHandle;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getArray() {
/* 40 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOffsetInBytes() {
/* 45 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr realloc(int newSizeInBytes) {
/* 50 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public Ptr pointerPlus(int bytes) {
/* 55 */     return new OffsetPtr(this, bytes);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getByte(int offset) {
/* 60 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setByte(int offset, byte value) {
/* 65 */     throw new UnsupportedOperationException("TODO");
/*    */   }
/*    */ 
/*    */   
/*    */   public int toInt() {
/* 70 */     return System.identityHashCode(this.methodHandle);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNull() {
/* 75 */     return (this.methodHandle == null);
/*    */   }
/*    */ 
/*    */   
/*    */   public MethodHandle toMethodHandle() {
/* 80 */     return this.methodHandle;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/FunctionPtr1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */