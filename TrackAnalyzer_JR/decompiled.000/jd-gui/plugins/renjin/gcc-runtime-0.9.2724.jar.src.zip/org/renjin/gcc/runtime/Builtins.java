/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import org.renjin.gcc.format.FormatArrayInput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builtins
/*     */ {
/*  25 */   private static final ThreadLocal<IntPtr> ERRNO = new ThreadLocal<>();
/*     */   
/*     */   public static double __builtin_powi__(double base, int exponent) {
/*  28 */     return powi(base, exponent);
/*     */   }
/*     */   
/*     */   public static double powi(double base, int exponent) {
/*  32 */     if (exponent == 1)
/*  33 */       return base; 
/*  34 */     if (exponent == 2) {
/*  35 */       return base * base;
/*     */     }
/*  37 */     return Math.pow(base, exponent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr __errno_location() {
/*  45 */     IntPtr intPtr = ERRNO.get();
/*  46 */     if (intPtr == null) {
/*  47 */       intPtr = new IntPtr(new int[] { 0 });
/*  48 */       ERRNO.set(intPtr);
/*     */     } 
/*  50 */     return intPtr;
/*     */   }
/*     */   
/*     */   public static float __builtin_logf__(float x) {
/*  54 */     return (float)Math.log(x);
/*     */   }
/*     */   
/*     */   public static double __builtin_copysign__(double magnitude, double sign) {
/*  58 */     return Math.copySign(magnitude, sign);
/*     */   }
/*     */   
/*     */   public static float __builtin_copysignf__(float magnitude, float sign) {
/*  62 */     return Math.copySign(magnitude, sign);
/*     */   }
/*     */   
/*     */   public static double __builtin_exp__(double x) {
/*  66 */     return Math.exp(x);
/*     */   }
/*     */   
/*     */   public static float __builtin_sqrtf__(float f) {
/*  70 */     return (float)Math.sqrt(f);
/*     */   }
/*     */   
/*     */   public static float __builtin_cosf__(double f) {
/*  74 */     return (float)Math.cos(f);
/*     */   }
/*     */   
/*     */   public static float __builtin_sinf__(double x) {
/*  78 */     return (float)Math.sin(x);
/*     */   }
/*     */   
/*     */   public static double __builtin_sin__(double x) {
/*  82 */     return Math.sin(x);
/*     */   }
/*     */   
/*     */   public static double __builtin_log__(double x) {
/*  86 */     return Math.log(x);
/*     */   }
/*     */   
/*     */   public static double __builtin_cos__(double x) {
/*  90 */     return Math.cos(x);
/*     */   }
/*     */   
/*     */   public static double __builtin_sqrt__(double x) {
/*  94 */     return Math.sqrt(x);
/*     */   }
/*     */   public static double __builtin_atan__(double x) {
/*  97 */     return Math.atan(x);
/*     */   } public static double __builtin_atan2__(double x, double y) {
/*  99 */     return Math.atan2(x, y);
/*     */   } public static double __builtin_asin__(double x) {
/* 101 */     return Math.asin(x);
/*     */   } public static double __builtin_fmod__(double x, double y) {
/* 103 */     return Mathlib.fmod(x, y);
/*     */   }
/*     */   public static double __builtin_pow__(double x, double y) {
/* 106 */     return Math.pow(x, y);
/*     */   }
/*     */   
/*     */   public static void __builtin_puts(BytePtr string) {
/* 110 */     System.out.println(string.nullTerminatedString());
/*     */   }
/*     */ 
/*     */   
/*     */   public static int __fpclassifyd(double x) {
/* 115 */     return Double.isNaN(x) ? 0 : 1;
/*     */   }
/*     */   
/*     */   public static int _gfortran_pow_i4_i4__(int base, int exponent) {
/* 119 */     if (exponent < 0) {
/* 120 */       throw new IllegalArgumentException("exponent must be > 0: " + exponent);
/*     */     }
/* 122 */     int result = 1;
/* 123 */     for (int i = 0; i < exponent; i++) {
/* 124 */       result *= base;
/*     */     }
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int _gfortran_compare_string(int len1, BytePtr s1, int len2, BytePtr s2) {
/*     */     int len;
/*     */     byte[] s;
/* 143 */     int si, res = BytePtr.memcmp(s1, s2, (len1 < len2) ? len1 : len2);
/* 144 */     if (res != 0) {
/* 145 */       return res;
/*     */     }
/*     */     
/* 148 */     if (len1 == len2) {
/* 149 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     if (len1 < len2) {
/* 157 */       len = len2 - len1;
/* 158 */       s = s2.array;
/* 159 */       si = s2.offset + len1;
/* 160 */       res = -1;
/*     */     } else {
/*     */       
/* 163 */       len = len1 - len2;
/* 164 */       s = s1.array;
/* 165 */       si = s1.offset + len2;
/* 166 */       res = 1;
/*     */     } 
/*     */     
/* 169 */     while (len-- != 0) {
/* 170 */       if (s[si] != 32) {
/* 171 */         if (s[si] > 32) {
/* 172 */           return res;
/*     */         }
/* 174 */         return -res;
/*     */       } 
/*     */       
/* 177 */       si++;
/*     */     } 
/*     */     
/* 180 */     return 0;
/*     */   }
/*     */   
/*     */   public static float __builtin_powif__(float base, int exponent) {
/* 184 */     return powif(base, exponent);
/*     */   }
/*     */   
/*     */   public static float powif(float base, int exponent) {
/* 188 */     if (exponent == 0)
/* 189 */       return 1.0F; 
/* 190 */     if (exponent == 1)
/* 191 */       return base; 
/* 192 */     if (exponent == 2) {
/* 193 */       return base * base;
/*     */     }
/* 195 */     return (float)Math.pow(base, exponent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int __isnan(double x) {
/* 200 */     return Double.isNaN(x) ? 1 : 0;
/*     */   }
/*     */   
/*     */   public static int __finite(double x) {
/* 204 */     return (Double.isInfinite(x) || Double.isNaN(x)) ? 0 : 1;
/*     */   }
/*     */   
/*     */   public static boolean unordered(double x, double y) {
/* 208 */     return (Double.isNaN(x) || Double.isNaN(y));
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static double fmax(double x, double y) {
/* 213 */     return Mathlib.fmax(x, y);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static double hypot(double x, double y) {
/* 218 */     return Mathlib.hypot(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void _gfortran_set_options__(int x, IntPtr y) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void _gfortran_stop_string__(int x, int y) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static double[] realloc(double[] p, int offset, int newCount) {
/* 236 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static int[] realloc(int[] p, int offset, int newCount) {
/* 241 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static long[] realloc(long[] p, int offset, int newCount) {
/* 246 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static boolean[] realloc(boolean[] p, int offset, int newCount) {
/* 251 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static float[] realloc(float[] p, int offset, int newCount) {
/* 256 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static short[] realloc(short[] p, int offset, int newCount) {
/* 261 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static byte[] realloc(byte[] p, int offset, int newCount) {
/* 266 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static Object[] realloc(Object[] p, int offset, int newCount) {
/* 271 */     return Realloc.realloc(p, offset, newCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void __cxa_pure_virtual() {
/* 276 */     throw new RuntimeException("Pure virtual function invoked");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public static Ptr[] __dso_handle = new Ptr[] { BytePtr.NULL };
/*     */ 
/*     */   
/*     */   public static void undefined_std() {
/* 286 */     throw new RuntimeException("Invocation of std:: method");
/*     */   }
/*     */   
/*     */   public static void _gfortran_runtime_error_at(Ptr position, Ptr format, Object... arguments) {
/* 290 */     throw new RuntimeException(Stdlib.format(format, new Object[] { new FormatArrayInput(arguments) }));
/*     */   }
/*     */   
/*     */   public static int _gfortran_pow_i4_i4(int base, int power) {
/* 294 */     int result = 1;
/* 295 */     for (int i = 1; i <= power; i++) {
/* 296 */       result *= base;
/*     */     }
/* 298 */     return result;
/*     */   }
/* 300 */   private static volatile int __sync_synchronize_value = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public static void __sync_synchronize() {
/* 305 */     __sync_synchronize_value++;
/*     */   }
/*     */   
/*     */   public static void _gfortran_concat_string(int resultLength, Ptr result, int arg1Length, Ptr arg1, int arg2Length, Ptr arg2) {
/* 309 */     int resultPos = 0; int i;
/* 310 */     for (i = 0; i < arg1Length; i++) {
/* 311 */       result.setByte(resultPos++, arg1.getByte(i));
/*     */     }
/* 313 */     for (i = 0; i < arg2Length; i++) {
/* 314 */       result.setByte(resultPos++, arg2.getByte(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public static int __atomic_fetch_add_4(Ptr result, int value) {
/* 319 */     int previous = result.getInt();
/* 320 */     result.setInt(previous + value);
/* 321 */     return previous;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/Builtins.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */