/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractFileHandle
/*    */   implements FileHandle
/*    */ {
/* 23 */   private int error = 0;
/*    */ 
/*    */   
/*    */   public final int getError() {
/* 27 */     return this.error;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void clearError() {
/* 32 */     this.error = 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/AbstractFileHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */