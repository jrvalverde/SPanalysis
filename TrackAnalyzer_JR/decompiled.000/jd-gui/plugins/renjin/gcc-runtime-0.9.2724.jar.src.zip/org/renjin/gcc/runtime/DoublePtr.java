/*     */ package org.renjin.gcc.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoublePtr
/*     */   extends AbstractPtr
/*     */   implements Ptr
/*     */ {
/*  26 */   public static final DoublePtr NULL = new DoublePtr();
/*     */   
/*     */   public static final int BYTES = 8;
/*     */   
/*     */   public final double[] array;
/*     */   public final int offset;
/*     */   
/*     */   private DoublePtr() {
/*  34 */     this.array = null;
/*  35 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public DoublePtr(double[] array, int offset) {
/*  39 */     this.array = array;
/*  40 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public DoublePtr(double... values) {
/*  44 */     this.array = values;
/*  45 */     this.offset = 0;
/*     */   }
/*     */   
/*     */   public static DoublePtr malloc(int bytes) {
/*  49 */     return new DoublePtr(new double[AbstractPtr.mallocSize(bytes, 8)]);
/*     */   }
/*     */ 
/*     */   
/*     */   public double[] getArray() {
/*  54 */     return this.array;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  59 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetInBytes() {
/*  64 */     return this.offset * 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public DoublePtr realloc(int newSizeInBytes) {
/*  69 */     return new DoublePtr(Realloc.realloc(this.array, this.offset, newSizeInBytes / 8));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  74 */     return this.offset + "+" + Arrays.toString(this.array);
/*     */   }
/*     */   
/*     */   public double unwrap() {
/*  78 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public double get() {
/*  82 */     return this.array[this.offset];
/*     */   }
/*     */   
/*     */   public double get(int i) {
/*  86 */     return this.array[this.offset + i];
/*     */   }
/*     */   
/*     */   public void set(double x) {
/*  90 */     this.array[this.offset] = x;
/*     */   }
/*     */   
/*     */   public void set(int index, double value) {
/*  94 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memcmp(DoublePtr x, DoublePtr y, int numBytes) {
/* 107 */     return memcmp(x.array, x.offset, y.array, y.offset, numBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int memcmp(double[] x, int xi, double[] y, int yi, int n) {
/* 122 */     while (n > 0) {
/* 123 */       long xb = Double.doubleToRawLongBits(xi);
/* 124 */       long yb = Double.doubleToRawLongBits(yi);
/* 125 */       if (xb != yb || n < 8) {
/* 126 */         LongPtr.memcmp(xb, yb, n);
/*     */       }
/* 128 */       xi++;
/* 129 */       yi++;
/* 130 */       n -= 8;
/*     */     } 
/* 132 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void memset(double[] str, int strOffset, int c, int n) {
/* 146 */     assert n % 8 == 0;
/*     */     
/* 148 */     double doubleValue = memset(c);
/*     */     
/* 150 */     Arrays.fill(str, strOffset, strOffset + n / 8, doubleValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double memset(int c) {
/* 157 */     return Double.longBitsToDouble(LongPtr.memset(c));
/*     */   }
/*     */   
/*     */   public static DoublePtr cast(Object voidPointer) {
/* 161 */     if (voidPointer instanceof MallocThunk) {
/* 162 */       return ((MallocThunk)voidPointer).doublePtr();
/*     */     }
/* 164 */     if (voidPointer == null) {
/* 165 */       return NULL;
/*     */     }
/* 167 */     return (DoublePtr)voidPointer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void memcpy(Ptr source, int numBytes) {
/* 172 */     int numDoubles = numBytes / 8; int i;
/* 173 */     for (i = 0; i < numDoubles; i++) {
/* 174 */       this.array[this.offset + i] = source.getAlignedDouble(i);
/*     */     }
/*     */     
/* 177 */     for (i = numDoubles * 8; i < numBytes; i++) {
/* 178 */       setByte(i, source.getByte(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 184 */     return this.array[this.offset];
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int offset) {
/* 189 */     if (offset % 8 == 0) {
/* 190 */       return this.array[this.offset + offset / 8];
/*     */     }
/* 192 */     return super.getDouble(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getAlignedDouble(int index) {
/* 197 */     return this.array[this.offset + index];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(double value) {
/* 202 */     this.array[this.offset] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignedDouble(int index, double value) {
/* 207 */     this.array[this.offset + index] = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int offset) {
/* 212 */     return getByteViaDouble(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int offset, byte value) {
/* 217 */     setByteViaDouble(offset, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 222 */     return this.offset * 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 227 */     return (this.array == null && this.offset == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr pointerPlus(int byteCount) {
/* 232 */     if (byteCount % 8 == 0) {
/* 233 */       return new DoublePtr(this.array, this.offset + byteCount / 8);
/*     */     }
/* 235 */     return new OffsetPtr(this, byteCount);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void memcpy(DoublePtr x, DoublePtr y, int numBytes) {
/* 240 */     double[] arrayS = y.getArray();
/* 241 */     int offsetS = y.getOffset();
/* 242 */     int restY = arrayS.length - offsetS;
/* 243 */     if (restY > 0) {
/* 244 */       double[] carray = new double[numBytes];
/* 245 */       for (int i = 0, j = offsetS; j < arrayS.length && i < numBytes; j++, i++) {
/* 246 */         carray[i] = arrayS[j];
/*     */       }
/* 248 */       x = new DoublePtr(carray);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/DoublePtr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */