/*    */ package org.renjin.gcc.runtime;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class tm
/*    */ {
/*    */   public int tm_sec;
/*    */   public int tm_min;
/*    */   public int tm_hour;
/*    */   public int tm_mday;
/*    */   public int tm_mon;
/*    */   public int tm_year;
/*    */   public int tm_wday;
/*    */   public int tm_yday;
/*    */   public int tm_isdst;
/*    */   
/*    */   public tm(long instant) {
/* 32 */     Calendar instance = Calendar.getInstance();
/* 33 */     instance.setTimeInMillis(instant);
/*    */     
/* 35 */     this.tm_sec = instance.get(13);
/* 36 */     this.tm_min = instance.get(12);
/* 37 */     this.tm_hour = instance.get(10);
/* 38 */     this.tm_mday = instance.get(5);
/* 39 */     this.tm_mon = instance.get(2);
/* 40 */     this.tm_year = instance.get(1);
/* 41 */     this.tm_wday = instance.get(7);
/* 42 */     this.tm_yday = instance.get(6);
/* 43 */     this.tm_isdst = instance.getTimeZone().inDaylightTime(new Date(instant)) ? 1 : 0;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/gcc-runtime-0.9.2724.jar!/org/renjin/gcc/runtime/tm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */