/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Defn;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class baseDevices__
/*     */ {
/*     */   public static Ptr Rf_dpptr(Ptr dd) {
/*  46 */     if (Context.get__baseDevices$baseRegisterIndex() == -1)
/*  47 */       Error.Rf_error(new BytePtr("the base graphics system is not registered\000".getBytes(), 0), new Object[0]); 
/*  48 */     baseRegisterIndex$55 = Context.get__baseDevices$baseRegisterIndex(); return dd.getPointer(28 + baseRegisterIndex$55 * 4).getPointer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP getSymbolValue(SEXP symbol) {
/*  54 */     if (Rinternals.TYPEOF(symbol) != 1)
/*  55 */       Error.Rf_error(new BytePtr("argument to 'getSymbolValue' is not a symbol\000".getBytes(), 0), new Object[0]); 
/*  56 */     R_BaseEnv$22 = Rinternals.R_BaseEnv(); return Rinternals.Rf_findVar(symbol, R_BaseEnv$22);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int Rf_NoDevices() {
/* 128 */     return (Context.get__baseDevices$R_NumDevices() != 1 && Context.get__baseDevices$R_CurrentDevice() != 0) ? 0 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int Rf_NumDevices() {
/* 133 */     return Context.get__baseDevices$R_NumDevices();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr GEcurrentDevice() {
/* 141 */     if (Rf_NoDevices() != 0)
/* 142 */     { defdev = Rinternals.Rf_GetOption1(Rinternals.Rf_install(new BytePtr("device\000".getBytes(), 0)));
/* 143 */       if (Rinternals.TYPEOF(defdev) != 16 || Rinternals.Rf_length(defdev) <= 0)
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 172 */         if (Rinternals.TYPEOF(defdev) != 3)
/*     */         
/*     */         { 
/*     */ 
/*     */           
/* 177 */           Error.Rf_error(new BytePtr("no active or default device\000".getBytes(), 0), new Object[0]);
/*     */           
/* 179 */           R_CurrentDevice$50 = Context.get__baseDevices$R_CurrentDevice(); return Context.get__baseDevices$R_Devices().getAlignedPointer(R_CurrentDevice$50); }  defdev = Rinternals.Rf_lang1(defdev); Rinternals.Rf_protect(defdev); R_GlobalEnv$49 = Rinternals.R_GlobalEnv(); Rinternals.Rf_eval(defdev, R_GlobalEnv$49); R_CurrentDevice$50 = Context.get__baseDevices$R_CurrentDevice(); return Context.get__baseDevices$R_Devices().getAlignedPointer(R_CurrentDevice$50); }  devName = Defn.Rf_installTrChar(Rinternals.STRING_ELT(defdev, 0)); R_GlobalEnv$43 = Rinternals.R_GlobalEnv(); defdev = Rinternals.Rf_findVar(devName, R_GlobalEnv$43); R_UnboundValue$44 = Rinternals.R_UnboundValue; if (defdev != R_UnboundValue$44) { defdev = Rinternals.Rf_lang1(devName); Rinternals.Rf_protect(defdev); R_GlobalEnv$45 = Rinternals.R_GlobalEnv(); Rinternals.Rf_eval(defdev, R_GlobalEnv$45); } else { SEXP sEXP = Rinternals.Rf_install(new BytePtr("grDevices\000".getBytes(), 0)); ns = Rinternals.Rf_findVarInFrame(Rinternals.R_NamespaceRegistry(), sEXP); Rinternals.Rf_protect(ns); R_UnboundValue$47 = Rinternals.R_UnboundValue; if (ns != R_UnboundValue$47) { SEXP sEXP1 = Rinternals.Rf_findVar(devName, ns); R_UnboundValue$48 = Rinternals.R_UnboundValue; if (sEXP1 != R_UnboundValue$48) { defdev = Rinternals.Rf_lang1(devName); Rinternals.Rf_protect(defdev); Rinternals.Rf_eval(defdev, ns); R_CurrentDevice$50 = Context.get__baseDevices$R_CurrentDevice(); return Context.get__baseDevices$R_Devices().getAlignedPointer(R_CurrentDevice$50); }  }  Error.Rf_error(new BytePtr("no active or default device\000".getBytes(), 0), new Object[0]); }  }  R_CurrentDevice$50 = Context.get__baseDevices$R_CurrentDevice(); return Context.get__baseDevices$R_Devices().getAlignedPointer(R_CurrentDevice$50);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Ptr GEgetDevice(int i) {
/* 184 */     return Context.get__baseDevices$R_Devices().getAlignedPointer(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int Rf_curDevice() {
/* 189 */     return Context.get__baseDevices$R_CurrentDevice();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int Rf_nextDevice(int from) {
/* 195 */     nextDev = 0; if (Context.get__baseDevices$R_NumDevices() != 1) {
/*     */ 
/*     */       
/* 198 */       i = from;
/* 199 */       nextDev = 0;
/* 200 */       while (i <= 62 && nextDev == 0) {
/* 201 */         if (Context.get__baseDevices$active()[++i] == 0) continue;  nextDev = i;
/* 202 */       }  if (nextDev == 0) {
/*     */         
/* 204 */         i = 0;
/* 205 */         while (i <= 62 && nextDev == 0) {
/* 206 */           if (Context.get__baseDevices$active()[++i] == 0) continue;  nextDev = i;
/*     */         } 
/* 208 */       }  return nextDev;
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public static int Rf_prevDevice(int from) {
/* 214 */     prevDev = 0; if (Context.get__baseDevices$R_NumDevices() != 1) {
/*     */ 
/*     */       
/* 217 */       i = from;
/* 218 */       prevDev = 0;
/* 219 */       if (i <= 63)
/* 220 */         while (i > 1 && prevDev == 0) {
/* 221 */           if (Context.get__baseDevices$active()[--i] == 0) continue;  prevDev = i;
/* 222 */         }   if (prevDev == 0) {
/*     */         
/* 224 */         i = 64;
/* 225 */         while (i > 1 && prevDev == 0) {
/* 226 */           if (Context.get__baseDevices$active()[--i] == 0) continue;  prevDev = i;
/*     */         } 
/* 228 */       }  return prevDev;
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int GEdeviceNumber(Ptr dd) {
/*     */     int j;
/* 239 */     i = 1; while (true) { if (i > 63) {
/*     */         
/* 241 */         boolean bool = false; break;
/*     */       }  if (!Context.get__baseDevices$R_Devices().getAlignedPointer(i).equals(dd)) {
/*     */         i++;
/*     */         continue;
/*     */       } 
/*     */       j = i;
/*     */       break; }
/*     */     
/*     */     return j; } public static int Rf_ndevNumber(Ptr dd) { int j;
/* 250 */     i = 1; while (true) { if (i > 63) {
/*     */ 
/*     */         
/* 253 */         boolean bool = false; break;
/*     */       }  if (Context.get__baseDevices$R_Devices().getAlignedPointer(i).isNull() || !Context.get__baseDevices$R_Devices().getAlignedPointer(i).getPointer().equals(dd)) {
/*     */         i++;
/*     */         continue;
/*     */       } 
/*     */       j = i;
/*     */       break; }
/*     */     
/* 261 */     return j; } public static int Rf_selectDevice(int devNum) { if (devNum < 0 || devNum > 63 || 
/* 262 */       Context.get__baseDevices$R_Devices().getAlignedPointer(devNum).isNull() || Context.get__baseDevices$active()[devNum] == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 284 */       return Rf_selectDevice(Rf_nextDevice(devNum)); }  if (Rf_NoDevices() == 0) {
/*     */       oldd = GEcurrentDevice(); if (oldd.getPointer().getPointer(216).toMethodHandle() != null) {
/*     */         MethodHandle methodHandle = oldd.getPointer().getPointer(216).toMethodHandle(); Ptr ptr = oldd.getPointer(); methodHandle.invoke(ptr);
/*     */       } 
/*     */     }  Context.set__baseDevices$R_CurrentDevice(devNum); R_BaseEnv$38 = Rinternals.R_BaseEnv(); SEXP sEXP = Rinternals.Rf_elt(getSymbolValue(Defn.R_DevicesSymbol), devNum); Rinternals.Rf_gsetVar(Rinternals.R_DeviceSymbol, sEXP, R_BaseEnv$38);
/*     */     gdd = GEcurrentDevice();
/*     */     if (Rf_NoDevices() == 0 && gdd.getPointer().getPointer(200).toMethodHandle() != null) {
/*     */       MethodHandle methodHandle = gdd.getPointer().getPointer(200).toMethodHandle();
/*     */       Ptr ptr = gdd.getPointer();
/*     */       methodHandle.invoke(ptr);
/*     */     } 
/* 295 */     return devNum; } public static void removeDevice(int devNum, int findNext) { g = BytePtr.of(0); g$offset = 0; if (devNum > 0 && devNum <= 63 && !
/* 296 */       Context.get__baseDevices$R_Devices().getAlignedPointer(devNum).isNull() && Context.get__baseDevices$active()[devNum] != 0) {
/*     */ 
/*     */ 
/*     */       
/* 300 */       g = Context.get__baseDevices$R_Devices().getAlignedPointer(devNum); g$offset = 0;
/*     */       
/* 302 */       Context.get__baseDevices$active()[devNum] = 0;
/* 303 */       Context.set__baseDevices$R_NumDevices(Context.get__baseDevices$R_NumDevices() - 1);
/*     */       
/* 305 */       if (findNext != 0) {
/*     */         
/* 307 */         s = getSymbolValue(Defn.R_DevicesSymbol); Rinternals.Rf_protect(s);
/* 308 */         for (i = 0; i < devNum; ) { s = Rinternals.CDR(s); i++; }
/* 309 */          SEXP sEXP = Rinternals.Rf_mkString((Ptr)new BytePtr("\000".getBytes(), 0)); Rinternals.SETCAR(s, sEXP);
/*     */ 
/*     */ 
/*     */         
/* 313 */         R_CurrentDevice$30 = Context.get__baseDevices$R_CurrentDevice(); if (devNum == R_CurrentDevice$30) {
/* 314 */           Context.set__baseDevices$R_CurrentDevice(Rf_nextDevice(Context.get__baseDevices$R_CurrentDevice()));
/*     */           
/* 316 */           R_BaseEnv$33 = Rinternals.R_BaseEnv(); R_CurrentDevice$34 = Context.get__baseDevices$R_CurrentDevice(); SEXP sEXP1 = Rinternals.Rf_elt(getSymbolValue(Defn.R_DevicesSymbol), R_CurrentDevice$34); Rinternals.Rf_gsetVar(Rinternals.R_DeviceSymbol, sEXP1, R_BaseEnv$33);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 321 */           if (Context.get__baseDevices$R_CurrentDevice() != 0) {
/* 322 */             gdd = GEcurrentDevice();
/* 323 */             if (gdd.getPointer().getPointer(200).toMethodHandle() != null) { MethodHandle methodHandle1 = gdd.getPointer().getPointer(200).toMethodHandle(); Ptr ptr1 = gdd.getPointer(); methodHandle1.invoke(ptr1); }
/*     */           
/*     */           } 
/*     */         } 
/* 327 */       }  MethodHandle methodHandle = g.getPointer(g$offset).getPointer(212).toMethodHandle(); Ptr ptr = g.getPointer(g$offset); methodHandle.invoke(ptr);
/* 328 */       baseEngine__.GEdestroyDevDesc(g.pointerPlus(g$offset));
/* 329 */       Context.get__baseDevices$R_Devices().setAlignedPointer(devNum, BytePtr.of(0));
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void GEkillDevice(Ptr gdd) {
/* 335 */     removeDevice(GEdeviceNumber(gdd), 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void Rf_killDevice(int devNum) {
/* 340 */     removeDevice(devNum, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_KillAllDevices() {
/* 353 */     for (i = 63; i > 0; ) { removeDevice(i, 0); i--; }
/* 354 */      Context.set__baseDevices$R_CurrentDevice(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 368 */     if (Context.get__baseDevices$baseRegisterIndex() != -1) {
/* 369 */       baseEngine__.GEunregisterSystem(Context.get__baseDevices$baseRegisterIndex());
/* 370 */       Context.set__baseDevices$baseRegisterIndex(-1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Ptr Rf_desc2GEDesc(Ptr dd) {
/*     */     Ptr ptr;
/*     */     boolean bool;
/* 378 */     i = 1; while (true) { if (i > 63) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 383 */         Ptr ptr1 = Context.get__baseDevices$R_Devices().getPointer(); boolean bool1 = false; break;
/*     */       }  if (Context.get__baseDevices$R_Devices().getAlignedPointer(i).isNull() || !Context.get__baseDevices$R_Devices().getAlignedPointer(i).getPointer().equals(dd)) {
/*     */         i++; continue;
/*     */       }  ptr = Context.get__baseDevices$R_Devices().getAlignedPointer(i);
/*     */       bool = false;
/*     */       break; }
/*     */     
/* 390 */     return ptr.pointerPlus(bool); } public static void R_CheckDeviceAvailable() { if (Context.get__baseDevices$R_NumDevices() > 62) {
/* 391 */       Error.Rf_error(new BytePtr("too many open devices\000".getBytes(), 0), new Object[0]);
/*     */     } }
/*     */ 
/*     */   
/*     */   public static int R_CheckDeviceAvailableBool() {
/* 396 */     return (Context.get__baseDevices$R_NumDevices() <= 62) ? 
/* 397 */       1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void GEaddDevice(Ptr gdd) {
/* 407 */     s = (SEXP)BytePtr.of(0).getArray(); appnd = 0; s = getSymbolValue(Defn.R_DevicesSymbol); Rinternals.Rf_protect(s);
/*     */     
/* 409 */     if (Rf_NoDevices() == 0) {
/* 410 */       oldd = GEcurrentDevice();
/* 411 */       if (oldd.getPointer().getPointer(216).toMethodHandle() != null) { MethodHandle methodHandle = oldd.getPointer().getPointer(216).toMethodHandle(); Ptr ptr = oldd.getPointer(); methodHandle.invoke(ptr); }
/*     */     
/*     */     } 
/*     */     
/* 415 */     i = 1;
/* 416 */     SEXP sEXP = Rinternals.CDR(s); R_NilValue$16 = Rinternals.R_NilValue; if (sEXP != R_NilValue$16)
/*     */     
/*     */     { 
/* 419 */       s = Rinternals.CDR(s);
/* 420 */       appnd = 0; }
/*     */     else { appnd = 1; }
/* 422 */      while (!Context.get__baseDevices$R_Devices().getAlignedPointer(i).isNull()) {
/* 423 */       i++;
/* 424 */       SEXP sEXP1 = Rinternals.CDR(s); R_NilValue$17 = Rinternals.R_NilValue; if (sEXP1 != R_NilValue$17) {
/*     */ 
/*     */         
/* 427 */         s = Rinternals.CDR(s); continue;
/*     */       }  appnd = 1;
/* 429 */     }  Context.set__baseDevices$R_CurrentDevice(i);
/* 430 */     Context.set__baseDevices$R_NumDevices(Context.get__baseDevices$R_NumDevices() + 1);
/* 431 */     Context.get__baseDevices$R_Devices().setAlignedPointer(i, gdd);
/* 432 */     Context.get__baseDevices$active()[i] = 1;
/*     */     
/* 434 */     baseEngine__.GEregisterWithDevice(gdd);
/* 435 */     if (gdd.getPointer().getPointer(200).toMethodHandle() != null) { MethodHandle methodHandle = gdd.getPointer().getPointer(200).toMethodHandle(); Ptr ptr = gdd.getPointer(); methodHandle.invoke(ptr); }
/*     */ 
/*     */     
/* 438 */     t = Rinternals.Rf_protect(Rinternals.Rf_duplicate(getSymbolValue(Rinternals.R_DeviceSymbol)));
/* 439 */     if (appnd == 0) {
/*     */ 
/*     */       
/* 442 */       Rinternals.SETCAR(s, t);
/*     */     } else {
/*     */       R_NilValue$21 = Rinternals.R_NilValue;
/*     */       
/*     */       SEXP sEXP1 = Rinternals.Rf_cons(t, R_NilValue$21);
/*     */       
/*     */       Rinternals.SETCDR(s, sEXP1);
/*     */     } 
/*     */     
/* 451 */     if (i == 63) {
/* 452 */       Rf_killDevice(i);
/* 453 */       Error.Rf_error(new BytePtr("too many open devices\000".getBytes(), 0), new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void GEaddDevice2(Ptr gdd, Ptr name) {
/* 460 */     R_BaseEnv$13 = Rinternals.R_BaseEnv(); SEXP sEXP = Rinternals.Rf_mkString(name); Rinternals.Rf_gsetVar(Rinternals.R_DeviceSymbol, sEXP, R_BaseEnv$13);
/* 461 */     GEaddDevice(gdd);
/* 462 */     baseEngine__.GEinitDisplayList(gdd);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void GEaddDevice2f(Ptr gdd, Ptr name, Ptr file) {
/* 467 */     f = Rinternals.Rf_protect(Rinternals.Rf_mkString(name));
/* 468 */     if (!file.isNull()) {
/* 469 */       s_filepath = Rinternals.Rf_install(new BytePtr("filepath\000".getBytes(), 0));
/* 470 */       SEXP sEXP = Rinternals.Rf_mkString(file); Rinternals.Rf_setAttrib(f, s_filepath, sEXP);
/*     */     } 
/* 472 */     R_BaseEnv$11 = Rinternals.R_BaseEnv(); Rinternals.Rf_gsetVar(Rinternals.R_DeviceSymbol, f, R_BaseEnv$11);
/*     */     
/* 474 */     GEaddDevice(gdd);
/* 475 */     baseEngine__.GEinitDisplayList(gdd);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int Rf_GetOptionDeviceAsk() {
/* 481 */     ask = Rinternals.Rf_asLogical(Rinternals.Rf_GetOption1(Rinternals.Rf_install(new BytePtr("device.ask.default\000".getBytes(), 0))));
/* 482 */     R_NaInt$10 = Arith.R_NaInt; if (ask != R_NaInt$10)
/*     */     {
/*     */ 
/*     */       
/* 486 */       return (ask == 0) ? 0 : 1;
/*     */     }
/*     */     Error.Rf_warning(new BytePtr("invalid value for \"device.ask.default\", using FALSE\000".getBytes(), 0), new Object[0]);
/*     */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr GEcreateDevDesc(Ptr dev) {
/* 498 */     gdd = BytePtr.of(0); gdd$offset = 0; MixedPtr mixedPtr1 = MixedPtr.malloc(128); gdd$offset = 0;
/*     */ 
/*     */ 
/*     */     
/* 502 */     if (mixedPtr1.pointerPlus(gdd$offset).isNull())
/* 503 */       Error.Rf_error(new BytePtr("not enough memory to allocate device (in GEcreateDevDesc)\000".getBytes(), 0), new Object[0]); 
/* 504 */     for (i = 0; i <= 23; ) { mixedPtr1.setPointer(gdd$offset + 28 + i * 4, BytePtr.of(0)); i++; }
/* 505 */      mixedPtr1.setPointer(gdd$offset, dev);
/* 506 */     int m = dev.getAlignedInt(44); mixedPtr1.setInt(gdd$offset + 4, m);
/* 507 */     R_NilValue$7 = Rinternals.R_NilValue; mixedPtr1.setPointer(gdd$offset + 8, (Ptr)new RecordUnitPtr(R_NilValue$7));
/* 508 */     R_NilValue$8 = Rinternals.R_NilValue; mixedPtr1.setPointer(gdd$offset + 16, (Ptr)new RecordUnitPtr(R_NilValue$8));
/* 509 */     mixedPtr1.setInt(gdd$offset + 20, 0);
/* 510 */     mixedPtr1.setInt(gdd$offset + 24, 1);
/* 511 */     int k = Rf_GetOptionDeviceAsk(); mixedPtr1.setInt(gdd$offset + 124, k);
/* 512 */     Ptr ptr = mixedPtr1.getPointer(gdd$offset); R_NilValue$9 = Rinternals.R_NilValue; ptr.setPointer(308, (Ptr)new RecordUnitPtr(R_NilValue$9));
/* 513 */     MixedPtr mixedPtr2 = mixedPtr1; int j = gdd$offset; return mixedPtr2.pointerPlus(j);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_InitGraphics() {
/* 519 */     pNullDevice$1 = Context.get__baseDevices$pNullDevice(); pNullDevice$1$offset = Context.get__baseDevices$pNullDevice$offset(); Context.get__baseDevices$R_Devices().setPointer(pNullDevice$1.pointerPlus(pNullDevice$1$offset));
/* 520 */     Context.get__baseDevices$active()[0] = 1;
/*     */     
/* 522 */     for (i = 1; i <= 63; i++) {
/* 523 */       Context.get__baseDevices$R_Devices().setAlignedPointer(i, BytePtr.of(0));
/* 524 */       Context.get__baseDevices$active()[i] = 0;
/*     */     } 
/*     */ 
/*     */     
/* 528 */     s = Rinternals.Rf_protect(Rinternals.Rf_mkString((Ptr)new BytePtr("null device\000".getBytes(), 0)));
/* 529 */     R_BaseEnv$2 = Rinternals.R_BaseEnv(); Rinternals.Rf_gsetVar(Rinternals.R_DeviceSymbol, s, R_BaseEnv$2);
/* 530 */     s = Rinternals.Rf_protect(Rinternals.Rf_mkString((Ptr)new BytePtr("null device\000".getBytes(), 0)));
/* 531 */     R_BaseEnv$4 = Rinternals.R_BaseEnv(); R_NilValue$5 = Rinternals.R_NilValue; SEXP sEXP = Rinternals.Rf_cons(s, R_NilValue$5); Rinternals.Rf_gsetVar(Defn.R_DevicesSymbol, sEXP, R_BaseEnv$4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void Rf_NewFrameConfirm(Ptr dd) {
/* 538 */     buf = new byte[1024]; if (Defn.R_Interactive != 0)
/*     */     {
/*     */       
/* 541 */       if (dd.getAlignedPointer(71).toMethodHandle() == null || dd.getAlignedPointer(71).toMethodHandle().invoke(dd) == 0)
/*     */       {
/*     */         
/* 544 */         Defn.R_ReadConsole((Ptr)new BytePtr("Hit <Return> to see next plot: \000".getBytes(), 0), (Ptr)new BytePtr(buf, 0), 1024, 0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/baseDevices__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */