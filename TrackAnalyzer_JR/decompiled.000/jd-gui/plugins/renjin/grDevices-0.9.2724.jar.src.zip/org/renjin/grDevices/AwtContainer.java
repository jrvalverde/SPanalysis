/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AwtContainer
/*    */   implements GDContainer
/*    */ {
/*    */   private AwtPanel panel;
/*    */   private GDState state;
/*    */   private Dimension size;
/* 35 */   private int deviceNumber = -1;
/*    */   
/*    */   public AwtContainer(int w, int h) {
/* 38 */     this.size = new Dimension(w, h);
/* 39 */     this.state = new GDState();
/* 40 */     this.state.setFont(new Font(null, 0, 12));
/*    */     
/* 42 */     this.panel = new AwtPanel(this.size);
/* 43 */     this.panel.setBackground(Color.white);
/* 44 */     this.panel.setForceAntiAliasing(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public GDState getGState() {
/* 49 */     return this.state;
/*    */   }
/*    */ 
/*    */   
/*    */   public Graphics getGraphics() {
/* 54 */     return this.panel.getGraphics();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDeviceNumber(int deviceNumber) {
/* 59 */     this.deviceNumber = deviceNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDeviceNumber() {
/* 64 */     return this.deviceNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public Dimension getSize() {
/* 69 */     return this.size;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void closeDisplay() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void syncDisplay(boolean finish) {
/* 79 */     this.panel.setRepaintPaused(!finish);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void add(GDObject o) {
/* 84 */     this.panel.paint(o, this.state);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void reset() {
/* 89 */     this.panel.reset();
/*    */   }
/*    */   
/*    */   public AwtPanel getPanel() {
/* 93 */     return this.panel;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/AwtContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */