/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.jfree.graphics2d.svg.SVGGraphics2D;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.repackaged.guava.base.Strings;
/*     */ import org.renjin.repackaged.guava.hash.Hashing;
/*     */ import org.renjin.repackaged.guava.io.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SvgContainer
/*     */   implements GDContainer
/*     */ {
/*  40 */   private static final String RENJINCI_PLOT_DIR = System.getenv("RENJINCI_PLOT_DIR");
/*     */   
/*     */   private final SVGGraphics2D graphics;
/*     */   
/*     */   private final GDState state;
/*     */   
/*     */   private final Dimension size;
/*     */   private int deviceNumber;
/*     */   private final Session session;
/*     */   private final String filenameFormat;
/*     */   private boolean empty = true;
/*  51 */   private int pageNumber = 1;
/*     */ 
/*     */   
/*     */   public SvgContainer(Session session, String filenameFormat, int width, int height, Color backgroundColor) {
/*  55 */     this.session = session;
/*  56 */     this.filenameFormat = filenameFormat;
/*  57 */     this.size = new Dimension(width, height);
/*  58 */     this.graphics = new SVGGraphics2D(width, height);
/*  59 */     this.graphics.setBackground(backgroundColor);
/*  60 */     this.graphics.clearRect(0, 0, (int)this.size.getWidth(), (int)this.size.getHeight());
/*  61 */     this.state = new GDState();
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(GDObject o) {
/*  66 */     this.empty = false;
/*  67 */     o.paint(null, this.state, (Graphics)this.graphics);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  72 */     if (!this.empty) {
/*  73 */       flush();
/*     */     }
/*  75 */     this.graphics.clearRect(0, 0, (int)this.size.getWidth(), (int)this.size.getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public GDState getGState() {
/*  80 */     return this.state;
/*     */   }
/*     */ 
/*     */   
/*     */   public Graphics getGraphics() {
/*  85 */     return (Graphics)this.graphics;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncDisplay(boolean finish) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeviceNumber(int dn) {
/*  95 */     this.deviceNumber = dn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeDisplay() {
/* 100 */     flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDeviceNumber() {
/* 105 */     return this.deviceNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 110 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/* 115 */     String svg = this.graphics.getSVGDocument();
/*     */ 
/*     */     
/*     */     try {
/* 119 */       if (!Strings.isNullOrEmpty(RENJINCI_PLOT_DIR)) {
/* 120 */         flushCiObject(svg);
/*     */       }
/*     */       
/* 123 */       String filename = String.format(this.filenameFormat, new Object[] { Integer.valueOf(this.pageNumber++) });
/* 124 */       FileObject fileObject = this.session.getFileSystemManager().resolveFile(filename);
/*     */       
/* 126 */       try (Writer writer = new OutputStreamWriter(fileObject.getContent().getOutputStream(), StandardCharsets.UTF_8)) {
/* 127 */         writer.write(svg);
/*     */       } 
/* 129 */     } catch (IOException e) {
/* 130 */       throw new EvalException("Failed to write SVG file: " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void flushCiObject(String svg) throws IOException {
/* 135 */     String hashCode = Hashing.sha256().hashString(svg, StandardCharsets.UTF_8).toString();
/*     */     
/* 137 */     File plotDir = new File(RENJINCI_PLOT_DIR);
/* 138 */     if (!plotDir.exists()) {
/* 139 */       boolean created = plotDir.mkdirs();
/* 140 */       if (!created) {
/* 141 */         throw new IOException("Could not create directory " + plotDir.getAbsolutePath());
/*     */       }
/*     */     } 
/*     */     
/* 145 */     File plotFile = new File(plotDir, hashCode + ".svg");
/*     */     
/* 147 */     Files.write(svg, plotFile, StandardCharsets.UTF_8);
/*     */     
/* 149 */     this.session.getStdOut().println("<<<<plot:" + hashCode + ".svg>>>>");
/* 150 */     this.session.getStdOut().flush();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/SvgContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */