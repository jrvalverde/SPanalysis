/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GDText
/*     */   implements GDObject
/*     */ {
/*     */   private double x;
/*     */   private double y;
/*     */   private double r;
/*     */   private double h;
/*     */   private String txt;
/*     */   
/*     */   public GDText(double x, double y, double r, double h, String txt) {
/* 204 */     this.x = x;
/* 205 */     this.y = y;
/* 206 */     this.r = r;
/* 207 */     this.h = h;
/* 208 */     this.txt = txt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Component c, GDState gs, Graphics g) {
/* 213 */     if (gs.getCol() != null) {
/* 214 */       double rx = this.x;
/* 215 */       double ry = this.y;
/* 216 */       double hc = 0.0D;
/*     */       
/* 218 */       if (this.h != 0.0D) {
/* 219 */         FontMetrics fm = g.getFontMetrics();
/* 220 */         int w = fm.stringWidth(this.txt);
/* 221 */         hc = w * this.h;
/* 222 */         rx = this.x - w * this.h;
/*     */       } 
/* 224 */       int ix = (int)(rx + 0.5D);
/* 225 */       int iy = (int)(ry + 0.5D);
/*     */       
/* 227 */       if (this.r != 0.0D) {
/* 228 */         Graphics2D g2d = (Graphics2D)g;
/* 229 */         g2d.translate(this.x, this.y);
/* 230 */         double rr = -this.r / 180.0D * Math.PI;
/* 231 */         g2d.rotate(rr);
/* 232 */         if (hc != 0.0D) {
/* 233 */           g2d.translate(-hc, 0.0D);
/*     */         }
/* 235 */         g2d.drawString(this.txt, 0, 0);
/* 236 */         if (hc != 0.0D) {
/* 237 */           g2d.translate(hc, 0.0D);
/*     */         }
/* 239 */         g2d.rotate(-rr);
/* 240 */         g2d.translate(-this.x, -this.y);
/*     */       } else {
/* 242 */         g.drawString(this.txt, ix, iy);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GDText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */