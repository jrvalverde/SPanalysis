/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import java.awt.Point;
/*    */ import java.awt.event.MouseEvent;
/*    */ import java.awt.event.MouseListener;
/*    */ import java.util.Optional;
/*    */ import java.util.concurrent.ArrayBlockingQueue;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocatorSync
/*    */   implements MouseListener
/*    */ {
/* 40 */   private static final Point CANCELLED = new Point();
/*    */   
/* 42 */   private final BlockingQueue<Point> points = new ArrayBlockingQueue<>(10);
/*    */ 
/*    */   
/*    */   private boolean waiting = false;
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized Optional<Point> waitForClick() {
/* 50 */     this.points.clear();
/* 51 */     this.waiting = true;
/*    */     
/*    */     try {
/* 54 */       Point point = this.points.take();
/* 55 */       if (point == CANCELLED) {
/* 56 */         return (Optional)Optional.empty();
/*    */       }
/* 58 */       return Optional.of(point);
/*    */     }
/* 60 */     catch (InterruptedException e) {
/*    */ 
/*    */       
/* 63 */       Thread.currentThread().interrupt();
/* 64 */       return (Optional)Optional.empty();
/*    */     } finally {
/* 66 */       this.waiting = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(MouseEvent e) {
/* 72 */     if (this.waiting)
/* 73 */       if (e.getButton() == 1) {
/*    */ 
/*    */         
/* 76 */         this.points.offer(e.getPoint());
/*    */       
/*    */       }
/*    */       else {
/*    */ 
/*    */         
/* 82 */         this.points.offer(CANCELLED);
/*    */       }  
/*    */   }
/*    */   
/*    */   public void mousePressed(MouseEvent e) {}
/*    */   
/*    */   public void mouseReleased(MouseEvent e) {}
/*    */   
/*    */   public void mouseEntered(MouseEvent e) {}
/*    */   
/*    */   public void mouseExited(MouseEvent e) {}
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/LocatorSync.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */