/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.Stdlib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class s2u__
/*    */ {
/*    */   public static Ptr symbol2utf8(Ptr c0) {
/* 49 */     Stdlib.printf(new BytePtr("symbol2utf8 in = %s%n\000".getBytes(), 0), new Object[] { c0 });
/*    */     
/* 51 */     c = c0; c$offset = 0;
/* 52 */     BytePtr bytePtr = new BytePtr(Context.get__s2u$work(), 0); t$offset = 0;
/* 53 */     while ((c.getByte(c$offset) & 0xFF) != 0) {
/* 54 */       if ((c.getByte(c$offset) & 0xFF) > 31)
/*    */       
/*    */       { 
/* 57 */         int i = (c.getByte(c$offset) & 0xFF) + -32; u = Context.get__s2u$s2u()[i];
/* 58 */         if (u > 127)
/*    */         
/* 60 */         { if (u > 2047)
/*    */           
/*    */           { 
/*    */             
/* 64 */             int m = (byte)((byte)(u >> 12) | (byte)-32) & 0xFF; bytePtr.setByte(t$offset, m); bytePtr = bytePtr; t$offset++;
/* 65 */             int k = (byte)((byte)((byte)(u >> 6) & (byte)63) | (byte)Byte.MIN_VALUE) & 0xFF; bytePtr.setByte(t$offset, k); bytePtr = bytePtr; t$offset++;
/* 66 */             int j = (byte)((byte)((byte)u & (byte)63) | (byte)Byte.MIN_VALUE) & 0xFF; bytePtr.setByte(t$offset, j); bytePtr = bytePtr; t$offset++; } else { int k = (byte)((byte)(u >> 6) | (byte)-64) & 0xFF; bytePtr.setByte(t$offset, k); bytePtr = bytePtr; t$offset++; int j = (byte)((byte)((byte)u & (byte)63) | (byte)Byte.MIN_VALUE) & 0xFF; bytePtr.setByte(t$offset, j); bytePtr = bytePtr; t$offset++; }  } else { int j = u & 0xFF; bytePtr.setByte(t$offset, j); bytePtr = bytePtr; t$offset++; }
/*    */          }
/*    */       else { bytePtr.setByte(t$offset, (byte)32); bytePtr = bytePtr; t$offset++; }
/* 69 */        if (bytePtr.pointerPlus(t$offset).getOffsetInBytes() - 0 <= 32762) {
/* 70 */         c = c; c$offset++; continue;
/*    */       }  break;
/* 72 */     }  bytePtr.setByte(t$offset, (byte)0);
/* 73 */     Stdlib.printf(new BytePtr("symbol2utf8 out = %s%n\000".getBytes(), 0), new Object[] { new BytePtr(Context.get__s2u$work(), 0) });
/*    */     
/* 75 */     return (Ptr)new BytePtr(Context.get__s2u$work(), 0);
/*    */   }
/*    */   
/*    */   static {
/*    */   
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/s2u__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */