/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.GetText;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class devices__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static SEXP devcontrol(SEXP args) {
/*  56 */     gdd = baseDevices__.GEcurrentDevice();
/*     */     
/*  58 */     args = Rinternals.CDR(args);
/*  59 */     listFlag = Rinternals.Rf_asLogical(Rinternals.CAR(args));
/*  60 */     R_NaInt$25 = Arith.R_NaInt; if (listFlag == R_NaInt$25) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid argument\000".getBytes(), 0)), new Object[0]); 
/*  61 */     baseEngine__.GEinitDisplayList(gdd);
/*  62 */     boolean bool = (listFlag == 0) ? false : true; gdd.setInt(4, bool);
/*  63 */     return Rinternals.Rf_ScalarLogical(listFlag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP devdisplaylist(SEXP args) {
/*  69 */     return Rinternals.Rf_ScalarLogical(baseDevices__.GEcurrentDevice().getInt(4));
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devcopy(SEXP args) {
/*  74 */     args = Rinternals.CDR(args); if (Rinternals.LENGTH(Rinternals.CAR(args)) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("argument must have positive length\000".getBytes(), 0)), new Object[0]); 
/*  75 */     baseEngine__.GEcopyDisplayList(Rinternals2.INTEGER(Rinternals.CAR(args)).getInt() + -1);
/*  76 */     return Rinternals.R_NilValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devcur(SEXP args) {
/*  81 */     args = Rinternals.CDR(args);
/*  82 */     return Rinternals.Rf_ScalarInteger(baseDevices__.Rf_curDevice() + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devnext(SEXP args) {
/*  87 */     args = Rinternals.CDR(args); if (Rinternals.LENGTH(Rinternals.CAR(args)) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("argument must have positive length\000".getBytes(), 0)), new Object[0]); 
/*  88 */     nxt = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt();
/*  89 */     R_NaInt$24 = Arith.R_NaInt; if (nxt == R_NaInt$24) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("NA argument is invalid\000".getBytes(), 0)), new Object[0]); 
/*  90 */     return Rinternals.Rf_ScalarInteger(baseDevices__.Rf_nextDevice(nxt + -1) + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devprev(SEXP args) {
/*  95 */     args = Rinternals.CDR(args); if (Rinternals.LENGTH(Rinternals.CAR(args)) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("argument must have positive length\000".getBytes(), 0)), new Object[0]); 
/*  96 */     prev = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt();
/*  97 */     R_NaInt$23 = Arith.R_NaInt; if (prev == R_NaInt$23) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("NA argument is invalid\000".getBytes(), 0)), new Object[0]); 
/*  98 */     return Rinternals.Rf_ScalarInteger(baseDevices__.Rf_prevDevice(prev + -1) + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devset(SEXP args) {
/* 103 */     args = Rinternals.CDR(args); if (Rinternals.LENGTH(Rinternals.CAR(args)) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("argument must have positive length\000".getBytes(), 0)), new Object[0]); 
/* 104 */     devNum = Rinternals2.INTEGER(Rinternals.CAR(args)).getInt();
/* 105 */     R_NaInt$22 = Arith.R_NaInt; if (devNum == R_NaInt$22) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("NA argument is invalid\000".getBytes(), 0)), new Object[0]); 
/* 106 */     return Rinternals.Rf_ScalarInteger(baseDevices__.Rf_selectDevice(devNum + -1) + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devoff(SEXP args) {
/* 111 */     args = Rinternals.CDR(args); if (Rinternals.LENGTH(Rinternals.CAR(args)) == 0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("argument must have positive length\000".getBytes(), 0)), new Object[0]); 
/* 112 */     baseDevices__.Rf_killDevice(Rinternals2.INTEGER(Rinternals.CAR(args)).getInt() + -1);
/* 113 */     return Rinternals.R_NilValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP devsize(SEXP args) {
/* 119 */     top = new double[1]; bottom = new double[1]; right = new double[1]; left = new double[1]; top[0] = 0.0D; bottom[0] = 0.0D; right[0] = 0.0D; left[0] = 0.0D; dd = baseDevices__.GEcurrentDevice().getPointer();
/*     */ 
/*     */     
/* 122 */     dd.getPointer(264).toMethodHandle().invoke((Ptr)new DoublePtr(left, 0), (Ptr)new DoublePtr(right, 0), (Ptr)new DoublePtr(bottom, 0), (Ptr)new DoublePtr(top, 0), dd);
/* 123 */     ans = Rinternals.Rf_allocVector(14, 2);
/* 124 */     Ptr ptr2 = Rinternals2.REAL(ans); right$18 = right[0]; left$19 = left[0]; double d2 = Math.abs(right$18 - left$19); ptr2.setDouble(0, d2);
/* 125 */     Ptr ptr1 = Rinternals2.REAL(ans); bottom$20 = bottom[0]; top$21 = top[0]; double d1 = Math.abs(bottom$20 - top$21); ptr1.setDouble(8, d1);
/* 126 */     return ans;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP devholdflush(SEXP args) {
/* 131 */     dd = baseDevices__.GEcurrentDevice().getPointer();
/*     */     
/* 133 */     args = Rinternals.CDR(args);
/* 134 */     level = Rinternals.Rf_asInteger(Rinternals.CAR(args));
/* 135 */     if (dd.getPointer(316).toMethodHandle() != null) { R_NaInt$17 = Arith.R_NaInt; if (level == R_NaInt$17)
/* 136 */       { level = 0;
/* 137 */         return Rinternals.Rf_ScalarInteger(level); }  level = dd.getPointer(316).toMethodHandle().invoke(dd, level); return Rinternals.Rf_ScalarInteger(level); }  level = 0; return Rinternals.Rf_ScalarInteger(level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP devcap(SEXP args) {
/* 143 */     i = 0;
/* 144 */     dd = baseDevices__.GEcurrentDevice().getPointer();
/*     */     
/* 146 */     args = Rinternals.CDR(args);
/*     */     
/* 148 */     ans = Rinternals.Rf_allocVector(13, 9); Rinternals.Rf_protect(ans);
/* 149 */     Ptr ptr18 = Rinternals2.INTEGER(ans); int i20 = i * 4; Ptr ptr17 = ptr18; int i19 = 0 + i20, i18 = dd.getInt(320); ptr17.setInt(i19, i18);
/* 150 */     Ptr ptr16 = Rinternals2.INTEGER(ans); int i17 = ++i * 4; Ptr ptr15 = ptr16; int i16 = 0 + i17, i15 = dd.getInt(324); ptr15.setInt(i16, i15);
/*     */     
/* 152 */     Ptr ptr14 = Rinternals2.INTEGER(ans); int i14 = ++i * 4; Ptr ptr13 = ptr14; int i13 = 0 + i14; if (dd.getPointer(256).toMethodHandle() != null) { iftmp$8 = dd.getInt(328); } else { iftmp$8 = 1; }  ptr13.setInt(i13, iftmp$8);
/* 153 */     Ptr ptr12 = Rinternals2.INTEGER(ans); int i12 = ++i * 4; Ptr ptr11 = ptr12; int i11 = 0 + i12; if (dd.getPointer(260).toMethodHandle() != null) { iftmp$10 = dd.getInt(332); } else { iftmp$10 = 1; }  ptr11.setInt(i11, iftmp$10);
/* 154 */     Ptr ptr10 = Rinternals2.INTEGER(ans); int i10 = ++i * 4; Ptr ptr9 = ptr10; int i9 = 0 + i10; if (dd.getPointer(220).toMethodHandle() != null) { iftmp$12 = dd.getInt(336); } else { iftmp$12 = 1; }  ptr9.setInt(i9, iftmp$12);
/* 155 */     Ptr ptr8 = Rinternals2.INTEGER(ans); int i8 = ++i * 4; Ptr ptr7 = ptr8; int i7 = 0 + i8, i6 = dd.getInt(180); ptr7.setInt(i7, i6);
/* 156 */     Ptr ptr6 = Rinternals2.INTEGER(ans); int i5 = ++i * 4; Ptr ptr5 = ptr6; int i4 = 0 + i5, i3 = dd.getInt(184); ptr5.setInt(i4, i3);
/* 157 */     Ptr ptr4 = Rinternals2.INTEGER(ans); int i2 = ++i * 4; Ptr ptr3 = ptr4; int i1 = 0 + i2, n = dd.getInt(188); ptr3.setInt(i1, n);
/* 158 */     Ptr ptr2 = Rinternals2.INTEGER(ans); int m = ++i * 4; Ptr ptr1 = ptr2; int k = 0 + m, j = dd.getInt(192); ptr1.setInt(k, j);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     return ans;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP devcapture(SEXP args) {
/* 170 */     image = (SEXP)BytePtr.of(0).getArray(); rint = BytePtr.of(0); rint$offset = 0; size = 0; ncol = 0; nrow = 0; gdd = baseDevices__.GEcurrentDevice();
/*     */ 
/*     */ 
/*     */     
/* 174 */     args = Rinternals.CDR(args);
/*     */     
/* 176 */     native = Rinternals.Rf_asLogical(Rinternals.CAR(args));
/* 177 */     if (native != 1) native = 0;
/*     */     
/* 179 */     raster = baseEngine__.GECap(gdd);
/* 180 */     if (Rinternals.TYPEOF(raster) != 0) {
/*     */ 
/*     */       
/* 183 */       Rinternals.Rf_protect(raster);
/* 184 */       if (native == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         size = Rinternals.LENGTH(raster);
/* 192 */         R_DimSymbol$1 = Rinternals.R_DimSymbol; nrow = Rinternals2.INTEGER(Rinternals.Rf_getAttrib(raster, R_DimSymbol$1)).getInt();
/* 193 */         R_DimSymbol$2 = Rinternals.R_DimSymbol; ncol = Rinternals2.INTEGER(Rinternals.Rf_getAttrib(raster, R_DimSymbol$2)).getInt(4);
/*     */         
/* 195 */         image = Rinternals.Rf_allocVector(16, size); Rinternals.Rf_protect(image);
/* 196 */         rint = Rinternals2.INTEGER(raster); rint$offset = 0;
/* 197 */         for (i = 0; i < size; i++) {
/* 198 */           col = i % ncol + 1;
/* 199 */           row = i / ncol + 1;
/*     */           
/* 201 */           int m = i * 4; Ptr ptr = rint; int k = rint$offset + m; SEXP sEXP1 = Rinternals.Rf_mkChar(colors__.Rf_col2name(ptr.getInt(k))); int j = (col + -1) * nrow + row + -1;
/*     */           Rinternals.SET_STRING_ELT(image, j, sEXP1);
/*     */         } 
/* 204 */         idim = Rinternals.Rf_allocVector(13, 2); Rinternals.Rf_protect(idim);
/* 205 */         Rinternals2.INTEGER(idim).setInt(0, nrow);
/* 206 */         Rinternals2.INTEGER(idim).setInt(4, ncol);
/* 207 */         R_DimSymbol$4 = Rinternals.R_DimSymbol; Rinternals.Rf_setAttrib(image, R_DimSymbol$4, idim);
/*     */ 
/*     */         
/* 210 */         return image;
/*     */       } 
/*     */       SEXP sEXP = Rinternals.Rf_mkString((Ptr)new BytePtr("nativeRaster\000".getBytes(), 0));
/*     */       R_ClassSymbol$0 = Rinternals.R_ClassSymbol;
/*     */       Rinternals.Rf_setAttrib(raster, R_ClassSymbol$0, sEXP);
/*     */       return raster;
/*     */     } 
/*     */     return raster;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/devices__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */