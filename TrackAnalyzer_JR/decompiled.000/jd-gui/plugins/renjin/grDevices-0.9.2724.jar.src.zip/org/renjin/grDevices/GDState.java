/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GDState
/*    */ {
/*    */   private Color col;
/*    */   private Color fill;
/*    */   private Font font;
/*    */   
/*    */   public Color getCol() {
/* 52 */     return this.col;
/*    */   }
/*    */   
/*    */   public void setCol(Color col) {
/* 56 */     this.col = col;
/*    */   }
/*    */   
/*    */   public Color getFill() {
/* 60 */     return this.fill;
/*    */   }
/*    */   
/*    */   public void setFill(Color fill) {
/* 64 */     this.fill = fill;
/*    */   }
/*    */   
/*    */   public Font getFont() {
/* 68 */     return this.font;
/*    */   }
/*    */   
/*    */   public void setFont(Font font) {
/* 72 */     this.font = font;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GDState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */