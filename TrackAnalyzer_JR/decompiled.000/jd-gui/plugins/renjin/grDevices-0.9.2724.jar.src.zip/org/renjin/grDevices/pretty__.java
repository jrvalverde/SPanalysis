/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Mathlib;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rmath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class pretty__
/*     */ {
/*     */   public static double R_pretty(Ptr lo, Ptr up, Ptr ndiv, int min_n, double shrink_sml, Ptr high_u_fact, int eps_correction, int return_bounds) {
/*  87 */     nu = 0.0D; ns = 0.0D; unit = 0.0D; double d11 = up.getDouble(), d10 = lo.getDouble(); dx = d11 - d10;
/*     */     
/*  89 */     if (dx != 0.0D || up.getDouble() != 0.0D) {
/*     */ 
/*     */ 
/*     */       
/*  93 */       double d14 = Math.abs(up.getDouble()); cell = Rmath.Rf_fmax2(Math.abs(lo.getDouble()), d14);
/*     */       
/*  95 */       double d13 = high_u_fact.getDouble(8), d12 = high_u_fact.getDouble() * 1.5D + 0.5D; if (d13 < d12) { double d = high_u_fact.getDouble(8) + 1.0D; iftmp$0 = 1.5D / d + 1.0D; } else { double d = high_u_fact.getDouble() + 1.0D; iftmp$0 = 1.0D / d + 1.0D; }  U = iftmp$0;
/*  96 */       int i = ndiv.getInt(); U = Rmath.Rf_imax2(1, i) * 2.220446049250313E-16D * U;
/*     */       
/*  98 */       i_small = (cell * U * 3.0D <= dx) ? 0 : 1;
/*     */     } else {
/*     */       cell = 1.0D; i_small = 1;
/*     */     } 
/* 102 */     if (i_small == 0)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */       
/* 108 */       cell = dx;
/* 109 */       if (ndiv.getInt() > 1) { double d = ndiv.getInt(); cell /= d; }  } else { if (cell > 10.0D)
/*     */         cell = cell / 10.0D + 9.0D;  cell *= shrink_sml; if (min_n > 1) { double d = min_n; cell /= d; }
/*     */        }
/* 112 */      if (cell >= 4.450147717014403E-307D) {
/*     */ 
/*     */       
/* 115 */       if (cell * 10.0D > Double.MAX_VALUE) {
/* 116 */         Error.Rf_warning(new BytePtr("Internal(pretty()): very large range.. corrected\000".getBytes(), 0), new Object[0]);
/* 117 */         cell = 1.7976931348623158E307D;
/*     */       } 
/*     */     } else {
/*     */       Error.Rf_warning(new BytePtr("Internal(pretty()): very small range.. corrected\000".getBytes(), 0), new Object[0]); cell = 4.450147717014403E-307D;
/* 121 */     }  double d9 = Mathlib.floor(Mathlib.log10(cell)); base = Mathlib.pow(10.0D, d9);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     unit = base;
/* 128 */     U = base * 2.0D; double d8 = U - cell, d7 = high_u_fact.getDouble(), d6 = cell - unit, d5 = d7 * d6; if (d8 < d5) { unit = U;
/* 129 */       U = base * 5.0D; double d15 = U - cell, d14 = high_u_fact.getDouble(8), d13 = cell - unit, d12 = d14 * d13; if (d15 < d12) { unit = U;
/* 130 */         U = base * 10.0D; double d19 = U - cell, d18 = high_u_fact.getDouble(), d17 = cell - unit, d16 = d18 * d17; if (d19 < d16) unit = U;
/*     */          }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     ns = Mathlib.floor(lo.getDouble() / unit + 1.0E-10D);
/* 140 */     nu = Mathlib.ceil(up.getDouble() / unit - 1.0E-10D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (eps_correction != 0 && (eps_correction > 1 || i_small == 0)) {
/* 148 */       if (lo.getDouble() == 0.0D) { lo.setDouble(-2.2250738585072014E-308D); } else { double d = lo.getDouble() * 0.9999999999999998D; lo.setDouble(d); }
/* 149 */        if (up.getDouble() == 0.0D) { up.setDouble(2.2250738585072014E-308D); } else { double d = up.getDouble() * 1.0000000000000002D; up.setDouble(d); }
/*     */     
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 156 */       double d15 = ns * unit, d14 = lo.getDouble(), d13 = unit * 1.0E-10D, d12 = d14 + d13; if (d15 <= d12) break;  ns--;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 162 */       double d15 = nu * unit, d14 = up.getDouble(), d13 = unit * 1.0E-10D, d12 = d14 - d13; if (d15 >= d12) break;  nu++;
/*     */     } 
/* 164 */     k = (int)(nu + 0.5D - ns);
/* 165 */     if (k >= min_n)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       ndiv.setInt(k); } else { k = min_n - k; if (ns < 0.0D) { double d = (k / 2); ns -= d; int j = k / 2, i = k % 2; nu = (j + i) + nu; } else { nu = (k / 2) + nu; int j = k / 2, i = k % 2; double d = (j + i); ns -= d; }
/*     */        ndiv.setInt(min_n); }
/* 184 */      if (return_bounds == 0)
/*     */     
/*     */     { 
/*     */       
/* 188 */       lo.setDouble(ns);
/* 189 */       up.setDouble(nu);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       return unit; }  double d4 = ns * unit, d3 = lo.getDouble(); if (d4 < d3) { double d = ns * unit; lo.setDouble(d); }  double d2 = nu * unit, d1 = up.getDouble(); if (d2 > d1) { double d = nu * unit; up.setDouble(d); }  return unit;
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/pretty__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */