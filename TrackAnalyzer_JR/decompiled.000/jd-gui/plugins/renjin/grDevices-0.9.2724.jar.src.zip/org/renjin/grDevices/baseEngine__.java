/*      */ package org.renjin.grDevices;
/*      */ import java.lang.invoke.MethodHandle;
/*      */ import org.renjin.gcc.runtime.Builtins;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.Mathlib;
/*      */ import org.renjin.gcc.runtime.MixedPtr;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*      */ import org.renjin.gcc.runtime.VoidPtr;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Defn;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.Memory;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.gnur.api.Rmath;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ public class baseEngine__ {
/*      */   public static int $GEstring_to_pch$last_ipch;
/*      */   public static SEXP $GEstring_to_pch$last_pch;
/*      */   public static byte[] $GEMetricInfo$last_family = new byte[201];
/*      */   public static double $GEMetricInfo$w;
/*      */   public static double $GEMetricInfo$d;
/*      */   public static double $GEMetricInfo$a;
/*      */   public static double $GEMetricInfo$last_ps;
/*      */   public static double $GEMetricInfo$last_cex;
/*      */   public static int $GEMetricInfo$last_face;
/*      */   public static MethodHandle $GEMetricInfo$last_close;
/*      */   public static Ptr $GEMetricInfo$last_dd;
/*      */   public static int $GEMetricInfo$last_dd$offset;
/*      */   
/*      */   public static int R_GE_getVersion() {
/*   37 */     return 10;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void R_GE_checkVersionOrDie(int version) {
/*   42 */     if (version != 10) {
/*   43 */       Error.Rf_error(new BytePtr("Graphics API version mismatch\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int add_point(double x, double y, Ptr dd) {
/*   53 */     npoints$176 = Context.get__baseEngine$npoints(); max_points$177 = Context.get__baseEngine$max_points(); if (npoints$176 >= max_points$177) {
/*      */       DoublePtr doublePtr1, doublePtr2;
/*      */ 
/*      */       
/*   57 */       tmp_n = Context.get__baseEngine$max_points() + 200;
/*      */       
/*   59 */       if (tmp_n > 25000) {
/*   60 */         Error.Rf_error(new BytePtr("add_point - reached MAXNUMPTS (%d)\000".getBytes(), 0), new Object[] { Integer.valueOf(tmp_n) });
/*      */       }
/*   62 */       if (Context.get__baseEngine$max_points() != 0) {
/*      */ 
/*      */ 
/*      */         
/*   66 */         int i1 = tmp_n * 8; xpoints$183 = Context.get__baseEngine$xpoints(); xpoints$183$offset = Context.get__baseEngine$xpoints$offset(); tmp_px = xpoints$183.pointerPlus(xpoints$183$offset).realloc(i1); tmp_px$offset = 0;
/*      */ 
/*      */         
/*   69 */         int n = tmp_n * 8; ypoints$185 = Context.get__baseEngine$ypoints(); ypoints$185$offset = Context.get__baseEngine$ypoints$offset(); tmp_py = ypoints$185.pointerPlus(ypoints$185$offset).realloc(n); tmp_py$offset = 0;
/*      */       } else {
/*      */         doublePtr2 = DoublePtr.malloc(tmp_n * 8); tmp_px$offset = 0; doublePtr1 = DoublePtr.malloc(tmp_n * 8); tmp_py$offset = 0;
/*      */       } 
/*   73 */       if (doublePtr2.pointerPlus(tmp_px$offset).isNull() || doublePtr1.pointerPlus(tmp_py$offset).isNull()) {
/*   74 */         Error.Rf_error(new BytePtr("insufficient memory to allocate point array\000".getBytes(), 0), new Object[0]);
/*      */       }
/*   76 */       Context.set__baseEngine$xpoints((Ptr)doublePtr2); Context.set__baseEngine$xpoints$offset(tmp_px$offset);
/*   77 */       Context.set__baseEngine$ypoints((Ptr)doublePtr1); Context.set__baseEngine$ypoints$offset(tmp_py$offset);
/*   78 */       Context.set__baseEngine$max_points(tmp_n);
/*      */     } 
/*      */     
/*   81 */     if (Context.get__baseEngine$npoints() <= 0)
/*      */     
/*      */     { 
/*      */ 
/*      */       
/*   86 */       xpoints$193 = Context.get__baseEngine$xpoints(); xpoints$193$offset = Context.get__baseEngine$xpoints$offset(); int i3 = Context.get__baseEngine$npoints() * 8; Ptr ptr4 = xpoints$193; int i2 = xpoints$193$offset + i3; double d2 = GEtoDeviceX(x / 1200.0D, 2, dd); ptr4.setDouble(i2, d2);
/*   87 */       ypoints$196 = Context.get__baseEngine$ypoints(); ypoints$196$offset = Context.get__baseEngine$ypoints$offset(); int i1 = Context.get__baseEngine$npoints() * 8; Ptr ptr3 = ypoints$196; int n = ypoints$196$offset + i1; double d1 = GEtoDeviceY(y / 1200.0D, 2, dd); ptr3.setDouble(n, d1);
/*   88 */       Context.set__baseEngine$npoints(Context.get__baseEngine$npoints() + 1);
/*   89 */       return 1; }  xpoints$187 = Context.get__baseEngine$xpoints(); xpoints$187$offset = Context.get__baseEngine$xpoints$offset(); int m = (Context.get__baseEngine$npoints() + -1) * 8; Ptr ptr2 = xpoints$187; int k = xpoints$187$offset + m; if (ptr2.getDouble(k) != x) { xpoints$193 = Context.get__baseEngine$xpoints(); xpoints$193$offset = Context.get__baseEngine$xpoints$offset(); int i3 = Context.get__baseEngine$npoints() * 8; Ptr ptr4 = xpoints$193; int i2 = xpoints$193$offset + i3; double d2 = GEtoDeviceX(x / 1200.0D, 2, dd); ptr4.setDouble(i2, d2); ypoints$196 = Context.get__baseEngine$ypoints(); ypoints$196$offset = Context.get__baseEngine$ypoints$offset(); int i1 = Context.get__baseEngine$npoints() * 8; Ptr ptr3 = ypoints$196; int n = ypoints$196$offset + i1; double d1 = GEtoDeviceY(y / 1200.0D, 2, dd); ptr3.setDouble(n, d1); Context.set__baseEngine$npoints(Context.get__baseEngine$npoints() + 1); return 1; }  ypoints$190 = Context.get__baseEngine$ypoints(); ypoints$190$offset = Context.get__baseEngine$ypoints$offset(); int j = (Context.get__baseEngine$npoints() + -1) * 8; Ptr ptr1 = ypoints$190; int i = ypoints$190$offset + j; if (ptr1.getDouble(i) != y) { xpoints$193 = Context.get__baseEngine$xpoints(); xpoints$193$offset = Context.get__baseEngine$xpoints$offset(); int i3 = Context.get__baseEngine$npoints() * 8; Ptr ptr4 = xpoints$193; int i2 = xpoints$193$offset + i3; double d2 = GEtoDeviceX(x / 1200.0D, 2, dd); ptr4.setDouble(i2, d2); ypoints$196 = Context.get__baseEngine$ypoints(); ypoints$196$offset = Context.get__baseEngine$ypoints$offset(); int i1 = Context.get__baseEngine$npoints() * 8; Ptr ptr3 = ypoints$196; int n = ypoints$196$offset + i1; double d1 = GEtoDeviceY(y / 1200.0D, 2, dd); ptr3.setDouble(n, d1); Context.set__baseEngine$npoints(Context.get__baseEngine$npoints() + 1); return 1; }
/*      */      return 1;
/*      */   }
/*      */   public static void unregisterOne(Ptr dd, int systemNumber) { if (!dd.getPointer(28 + systemNumber * 4).isNull()) {
/*      */       MethodHandle methodHandle = dd.getPointer(28 + systemNumber * 4).getPointer(4).toMethodHandle(); R_NilValue$371 = Rinternals.R_NilValue; methodHandle.invoke(1, dd, R_NilValue$371); Ptr ptr = dd.getPointer(28 + systemNumber * 4); dd.setPointer(28 + systemNumber * 4, BytePtr.of(0));
/*      */     }  } public static void GEdestroyDevDesc(Ptr dd) { if (!dd.isNull()) {
/*      */       for (i = 0; i <= 23; ) {
/*      */         unregisterOne(dd, i); i++;
/*      */       } 
/*      */       Ptr ptr = dd.getPointer();
/*      */       dd.setPointer(BytePtr.of(0));
/*  100 */     }  } public static Ptr GEsystemState(Ptr dd, int index) { return dd.getPointer(28 + index * 4).getPointer(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registerOne(Ptr dd, int systemNumber, MethodHandle cb) {
/*  114 */     MixedPtr mixedPtr = MixedPtr.malloc(8); dd.setPointer(28 + systemNumber * 4, (Ptr)mixedPtr);
/*  115 */     if (dd.getPointer(28 + systemNumber * 4).isNull())
/*  116 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GEregister)\000".getBytes(), 0), new Object[0]); 
/*  117 */     R_NilValue$370 = Rinternals.R_NilValue;
/*  118 */     if (Rinternals.TYPEOF(cb.invoke(0, dd, R_NilValue$370)) == 0) {
/*      */       
/*  120 */       Ptr ptr = dd.getPointer(28 + systemNumber * 4);
/*  121 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GEregister)\000".getBytes(), 0), new Object[0]);
/*      */     } 
/*  123 */     dd.getPointer(28 + systemNumber * 4).setPointer(4, VoidPtr.toPtr(cb));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEregisterWithDevice(Ptr dd) {
/*  133 */     for (i = 0; i <= 23; i++) {
/*      */ 
/*      */ 
/*      */       
/*  137 */       if (!Context.get__baseEngine$registeredSystems().getAlignedPointer(i).isNull()) {
/*  138 */         MethodHandle methodHandle = Context.get__baseEngine$registeredSystems().getAlignedPointer(i).getPointer(4).toMethodHandle(); registerOne(dd, i, methodHandle);
/*      */       } 
/*      */     }  } public static double f_blend(double numerator, double denominator) {
/*  141 */     p = denominator * 2.0D * denominator;
/*  142 */     u = numerator / denominator;
/*  143 */     u2 = u * u;
/*      */     
/*  145 */     double d6 = u * u2, d5 = 10.0D - p, d4 = (p * 2.0D - 15.0D) * u, d3 = d5 + d4, d2 = (6.0D - p) * u2, d1 = d3 + d2; return d6 * d1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double g_blend(double u, double q) {
/*  151 */     double d8 = q * 2.0D, d7 = q * 12.0D, d6 = 8.0D - d7, d5 = q * 14.0D - 11.0D, d4 = q * 5.0D, d3 = (4.0D - d4) * u, d2 = (d5 + d3) * u, d1 = (d6 + d2) * u; return ((d8 + d1) * u + q) * u;
/*      */   }
/*      */   
/*      */   public static void GEregisterSystem(MethodHandle cb, Ptr systemRegisterIndex) {
/*  155 */     if (Context.get__baseEngine$numGraphicsSystems() == 23) {
/*  156 */       Error.Rf_error(new BytePtr("too many graphics systems registered\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  164 */     systemRegisterIndex.setInt(0); while (true) {
/*  165 */       int n = systemRegisterIndex.getInt(); if (!Context.get__baseEngine$registeredSystems().getAlignedPointer(n).isNull()) {
/*  166 */         int i1 = systemRegisterIndex.getInt() + 1; systemRegisterIndex.setInt(i1);
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  171 */     i = 1;
/*  172 */     if (baseDevices__.Rf_NoDevices() == 0) {
/*  173 */       devNum = baseDevices__.Rf_curDevice(); while (true) {
/*  174 */         int n = baseDevices__.Rf_NumDevices(); boolean bool = (i >= n) ? false : true; i++; if (!bool)
/*  175 */           break;  gdd = baseDevices__.GEgetDevice(devNum);
/*  176 */         int i1 = systemRegisterIndex.getInt(); registerOne(gdd, i1, cb);
/*  177 */         devNum = baseDevices__.Rf_nextDevice(devNum);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  182 */     int m = systemRegisterIndex.getInt();
/*  183 */     MixedPtr mixedPtr = MixedPtr.malloc(8); Context.get__baseEngine$registeredSystems().setAlignedPointer(m, (Ptr)mixedPtr);
/*  184 */     int k = systemRegisterIndex.getInt(); if (Context.get__baseEngine$registeredSystems().getAlignedPointer(k).isNull())
/*  185 */       Error.Rf_error(new BytePtr("unable to allocate memory (in GEregister)\000".getBytes(), 0), new Object[0]); 
/*  186 */     int j = systemRegisterIndex.getInt(); Context.get__baseEngine$registeredSystems().getAlignedPointer(j).setPointer(4, VoidPtr.toPtr(cb));
/*  187 */     Context.set__baseEngine$numGraphicsSystems(Context.get__baseEngine$numGraphicsSystems() + 1);
/*      */   }
/*      */   public static double h_blend(double u, double q) { u2 = u * u; double d4 = q * 2.0D, d3 = q * -2.0D, d2 = u * q, d1 = (d3 - d2) * u2; return ((d4 + d1) * u + q) * u; }
/*      */   public static void negative_s1_influence(double t, double s1, Ptr A0, Ptr A2) { double d4 = -s1, d3 = h_blend(-t, d4); A0.setDouble(d3); double d2 = -s1, d1 = g_blend(t, d2); A2.setDouble(d1); }
/*      */   public static void negative_s2_influence(double t, double s2, Ptr A1, Ptr A3) { double d4 = -s2, d3 = g_blend(1.0D - t, d4); A1.setDouble(d3); double d2 = -s2, d1 = h_blend(t - 1.0D, d2); A3.setDouble(d1); } public static void positive_s1_influence(double k, double t, double s1, Ptr A0, Ptr A2) { Tk = k + 1.0D + s1; if (t + k + 1.0D >= Tk) { iftmp$175 = 0.0D; } else { double d = k - Tk; iftmp$175 = f_blend(t + k + 1.0D - Tk, d); }
/*  192 */      A0.setDouble(iftmp$175); Tk = k + 1.0D - s1; double d2 = k + 2.0D - Tk, d1 = f_blend(t + k + 1.0D - Tk, d2); A2.setDouble(d1); } public static void positive_s2_influence(double k, double t, double s2, Ptr A1, Ptr A3) { Tk = k + 2.0D + s2;
/*  193 */     double d2 = k + 1.0D - Tk, d1 = f_blend(t + k + 1.0D - Tk, d2); A1.setDouble(d1);
/*      */     
/*  195 */     Tk = k + 2.0D - s2;
/*  196 */     if (t + k + 1.0D <= Tk) { iftmp$174 = 0.0D; } else { double d = k + 3.0D - Tk; iftmp$174 = f_blend(t + k + 1.0D - Tk, d); }  A3.setDouble(iftmp$174); }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEunregisterSystem(int registerIndex) {
/*  201 */     if (registerIndex >= 0) {
/*  202 */       if (Context.get__baseEngine$numGraphicsSystems() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  215 */         i = 1;
/*  216 */         if (baseDevices__.Rf_NoDevices() == 0) {
/*  217 */           devNum = baseDevices__.Rf_curDevice(); while (true) {
/*  218 */             int j = baseDevices__.Rf_NumDevices(); boolean bool = (i >= j) ? false : true; i++; if (!bool)
/*      */               break; 
/*  220 */             unregisterOne(baseDevices__.GEgetDevice(devNum), registerIndex);
/*  221 */             devNum = baseDevices__.Rf_nextDevice(devNum);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  228 */         if (!Context.get__baseEngine$registeredSystems().getAlignedPointer(registerIndex).isNull()) {
/*  229 */           Ptr ptr = Context.get__baseEngine$registeredSystems().getAlignedPointer(registerIndex);
/*  230 */           Context.get__baseEngine$registeredSystems().setAlignedPointer(registerIndex, BytePtr.of(0));
/*      */         } 
/*  232 */         Context.set__baseEngine$numGraphicsSystems(Context.get__baseEngine$numGraphicsSystems() + -1); return;
/*      */       }  Error.Rf_warning(new BytePtr("no graphics system to unregister\000".getBytes(), 0), new Object[0]);
/*      */     }  }
/*      */   public static void point_adding(Ptr A_blend, Ptr px, Ptr py, Ptr dd) { double d35 = A_blend.getDouble(), d34 = A_blend.getDouble(8), d33 = d35 + d34, d32 = A_blend.getDouble(16), d31 = d33 + d32, d30 = A_blend.getDouble(24); weights_sum = d31 + d30; double d29 = A_blend.getDouble(), d28 = py.getDouble(), d27 = d29 * d28, d26 = A_blend.getDouble(8), d25 = py.getDouble(8), d24 = d26 * d25, d23 = d27 + d24, d22 = A_blend.getDouble(16), d21 = py.getDouble(16), d20 = d22 * d21, d19 = d23 + d20, d18 = A_blend.getDouble(24), d17 = py.getDouble(24), d16 = d18 * d17; double d15 = (d19 + d16) / weights_sum, d14 = A_blend.getDouble(), d13 = px.getDouble(), d12 = d14 * d13, d11 = A_blend.getDouble(8), d10 = px.getDouble(8), d9 = d11 * d10, d8 = d12 + d9, d7 = A_blend.getDouble(16), d6 = px.getDouble(16), d5 = d7 * d6, d4 = d8 + d5, d3 = A_blend.getDouble(24), d2 = px.getDouble(24), d1 = d3 * d2; add_point((d4 + d1) / weights_sum, d15, dd); }
/*      */   public static void point_computing(Ptr A_blend, Ptr px, Ptr py, Ptr x, Ptr y) { double d36 = A_blend.getDouble(), d35 = A_blend.getDouble(8), d34 = d36 + d35, d33 = A_blend.getDouble(16), d32 = d34 + d33, d31 = A_blend.getDouble(24); weights_sum = d32 + d31;
/*      */     double d30 = A_blend.getDouble(), d29 = px.getDouble(), d28 = d30 * d29, d27 = A_blend.getDouble(8), d26 = px.getDouble(8), d25 = d27 * d26, d24 = d28 + d25, d23 = A_blend.getDouble(16), d22 = px.getDouble(16), d21 = d23 * d22, d20 = d24 + d21, d19 = A_blend.getDouble(24), d18 = px.getDouble(24), d17 = d19 * d18, d16 = (d20 + d17) / weights_sum;
/*      */     x.setDouble(d16);
/*      */     double d15 = A_blend.getDouble(), d14 = py.getDouble(), d13 = d15 * d14, d12 = A_blend.getDouble(8), d11 = py.getDouble(8), d10 = d12 * d11, d9 = d13 + d10, d8 = A_blend.getDouble(16), d7 = py.getDouble(16), d6 = d8 * d7, d5 = d9 + d6, d4 = A_blend.getDouble(24), d3 = py.getDouble(24), d2 = d4 * d3, d1 = (d5 + d2) / weights_sum;
/*  240 */     y.setDouble(d1); } public static double step_computing(int k, Ptr px, Ptr py, double s1, double s2, double precision, Ptr dd) { ymid = new double[1]; xmid = new double[1]; yend = new double[1]; xend = new double[1]; ystart = new double[1]; xstart = new double[1]; A_blend = new double[4]; ymid[0] = 0.0D; xmid[0] = 0.0D; yend[0] = 0.0D; xend[0] = 0.0D; ystart[0] = 0.0D; xstart[0] = 0.0D; if (s1 != 0.0D || s2 != 0.0D)
/*      */     
/*      */     { 
/*      */       
/*  244 */       if (s1 <= 0.0D)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  254 */         xstart$158 = px.getAlignedDouble(1); xstart[0] = xstart$158;
/*  255 */         ystart$159 = py.getAlignedDouble(1); ystart[0] = ystart$159; }
/*      */       else { if (s2 >= 0.0D) { positive_s1_influence(k, 0.0D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, 0.0D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*      */         else { positive_s1_influence(k, 0.0D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(0.0D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*      */          point_computing((Ptr)new DoublePtr(A_blend, 0), px, py, (Ptr)new DoublePtr(xstart, 0), (Ptr)new DoublePtr(ystart, 0)); }
/*  259 */        if (s2 <= 0.0D)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  269 */         xend$160 = px.getAlignedDouble(2); xend[0] = xend$160;
/*  270 */         yend$161 = py.getAlignedDouble(2); yend[0] = yend$161; }
/*      */       else { if (s1 >= 0.0D) { positive_s1_influence(k, 1.0D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, 1.0D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*      */         else { negative_s1_influence(1.0D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, 1.0D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*      */          point_computing((Ptr)new DoublePtr(A_blend, 0), px, py, (Ptr)new DoublePtr(xend, 0), (Ptr)new DoublePtr(yend, 0)); }
/*  274 */        if (s2 <= 0.0D)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  282 */         if (s1 >= 0.0D)
/*      */         
/*      */         { 
/*      */           
/*  286 */           positive_s1_influence(k, 0.5D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2));
/*  287 */           negative_s2_influence(0.5D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); } else { negative_s1_influence(0.5D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(0.5D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }  } else if (s1 >= 0.0D) { positive_s1_influence(k, 0.5D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, 0.5D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*      */       else { negative_s1_influence(0.5D, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, 0.5D, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); }
/*  289 */        point_computing((Ptr)new DoublePtr(A_blend, 0), px, py, (Ptr)new DoublePtr(xmid, 0), (Ptr)new DoublePtr(ymid, 0));
/*      */       
/*  291 */       xstart$162 = xstart[0]; xmid$163 = xmid[0]; xv1 = xstart$162 - xmid$163;
/*  292 */       ystart$164 = ystart[0]; ymid$165 = ymid[0]; yv1 = ystart$164 - ymid$165;
/*  293 */       xend$166 = xend[0]; xmid$167 = xmid[0]; xv2 = xend$166 - xmid$167;
/*  294 */       yend$168 = yend[0]; ymid$169 = ymid[0]; yv2 = yend$168 - ymid$169;
/*      */       
/*  296 */       double d12 = xv1 * xv2, d11 = yv1 * yv2; scal_prod = d12 + d11;
/*      */       
/*  298 */       double d10 = xv1 * xv1, d9 = yv1 * yv1, d8 = d10 + d9, d7 = xv2 * xv2, d6 = yv2 * yv2, d5 = d7 + d6; sides_length_prod = Mathlib.sqrt(d8 * d5);
/*      */ 
/*      */ 
/*      */       
/*  302 */       if (sides_length_prod != 0.0D)
/*      */       
/*      */       { 
/*  305 */         angle_cos = scal_prod / sides_length_prod; }
/*      */       else { angle_cos = 0.0D; }
/*  307 */        xend$170 = xend[0]; xstart$171 = xstart[0]; xlength = xend$170 - xstart$171;
/*  308 */       yend$172 = yend[0]; ystart$173 = ystart[0]; ylength = yend$172 - ystart$173;
/*      */       
/*  310 */       double d4 = xlength * xlength, d3 = ylength * ylength; start_to_end_dist = Mathlib.sqrt(d4 + d3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  319 */       devWidth = GEfromDeviceWidth(GEtoDeviceWidth(1.0D, 1, dd), 2, dd) * 1200.0D;
/*      */       
/*  321 */       devHeight = GEfromDeviceHeight(GEtoDeviceHeight(1.0D, 1, dd), 2, dd) * 1200.0D;
/*      */       
/*  323 */       double d2 = devWidth * devWidth, d1 = devHeight * devHeight; devDiag = Mathlib.sqrt(d2 + d1);
/*  324 */       if (start_to_end_dist > devDiag) {
/*  325 */         start_to_end_dist = devDiag;
/*      */       }
/*      */       
/*  328 */       number_of_steps = Mathlib.sqrt(start_to_end_dist) / 2.0D;
/*      */ 
/*      */       
/*  331 */       number_of_steps = (int)((angle_cos + 1.0D) * 10.0D) + number_of_steps;
/*      */       
/*  333 */       if (number_of_steps != 0.0D)
/*      */       
/*      */       { 
/*  336 */         step = precision / number_of_steps; }
/*      */       else { step = 1.0D; }
/*  338 */        if (step > 0.2D || step == 0.0D) {
/*  339 */         step = 0.2D;
/*      */       }
/*  341 */       return step; }  return 1.0D; }
/*      */   public static SEXP GEhandleEvent(int event, Ptr dev, SEXP data) { gdd = BytePtr.of(0); gdd$offset = 0; gdd = baseDevices__.Rf_desc2GEDesc(dev); gdd$offset = 0; for (i = 0; i <= 23; i++) { if (!Context.get__baseEngine$registeredSystems().getAlignedPointer(i).isNull()) Context.get__baseEngine$registeredSystems().getAlignedPointer(i).getPointer(4).toMethodHandle().invoke(event, gdd.pointerPlus(gdd$offset), data);  }  return Rinternals.R_NilValue; }
/*  343 */   public static double GEfromDeviceX(double value, int to, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20, d21, d22, d23, d24, d25, d26, d27; result = value; switch (to) { case 1: d27 = dd.getPointer().getDouble(); d26 = result - d27; d25 = dd.getPointer().getDouble(8); d24 = dd.getPointer().getDouble(); d23 = d25 - d24; result = d26 / d23; break;case 2: d22 = dd.getPointer().getDouble(); d21 = result - d22; d20 = dd.getPointer().getDouble(8); d19 = dd.getPointer().getDouble(); d18 = d20 - d19; d17 = d21 / d18; d16 = dd.getPointer().getDouble(8); d15 = dd.getPointer().getDouble(); d14 = Math.abs(d16 - d15); d13 = d17 * d14; d12 = dd.getPointer().getDouble(88); result = d13 * d12; break;case 3: d11 = dd.getPointer().getDouble(); d10 = result - d11; d9 = dd.getPointer().getDouble(8); d8 = dd.getPointer().getDouble(); d7 = d9 - d8; d6 = d10 / d7; d5 = dd.getPointer().getDouble(8); d4 = dd.getPointer().getDouble(); d3 = Math.abs(d5 - d4); d2 = d6 * d3; d1 = dd.getPointer().getDouble(88); result = d2 * d1 * 2.54D; break; }  return result; } public static double GEtoDeviceX(double value, int from, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7, d8, d9; result = value; switch (from) { case 3: result /= 2.54D;case 2: d9 = dd.getPointer().getDouble(88); d8 = result / d9; d7 = dd.getPointer().getDouble(8); d6 = dd.getPointer().getDouble(); d5 = Math.abs(d7 - d6); result = d8 / d5;case 1: d4 = dd.getPointer().getDouble(); d3 = dd.getPointer().getDouble(8); d2 = dd.getPointer().getDouble(); d1 = (d3 - d2) * result; result = d4 + d1; break; }  return result; } public static double GEfromDeviceY(double value, int to, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20, d21, d22, d23, d24, d25, d26, d27; result = value; switch (to) { case 1: d27 = dd.getPointer().getDouble(16); d26 = result - d27; d25 = dd.getPointer().getDouble(24); d24 = dd.getPointer().getDouble(16); d23 = d25 - d24; result = d26 / d23; break;case 2: d22 = dd.getPointer().getDouble(16); d21 = result - d22; d20 = dd.getPointer().getDouble(24); d19 = dd.getPointer().getDouble(16); d18 = d20 - d19; d17 = d21 / d18; d16 = dd.getPointer().getDouble(24); d15 = dd.getPointer().getDouble(16); d14 = Math.abs(d16 - d15); d13 = d17 * d14; d12 = dd.getPointer().getDouble(96); result = d13 * d12; break;case 3: d11 = dd.getPointer().getDouble(16); d10 = result - d11; d9 = dd.getPointer().getDouble(24); d8 = dd.getPointer().getDouble(16); d7 = d9 - d8; d6 = d10 / d7; d5 = dd.getPointer().getDouble(24); d4 = dd.getPointer().getDouble(16); d3 = Math.abs(d5 - d4); d2 = d6 * d3; d1 = dd.getPointer().getDouble(96); result = d2 * d1 * 2.54D; break; }  return result; } public static double GEtoDeviceY(double value, int from, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7, d8, d9; result = value; switch (from) { case 3: result /= 2.54D;case 2: d9 = dd.getPointer().getDouble(96); d8 = result / d9; d7 = dd.getPointer().getDouble(24); d6 = dd.getPointer().getDouble(16); d5 = Math.abs(d7 - d6); result = d8 / d5;case 1: d4 = dd.getPointer().getDouble(16); d3 = dd.getPointer().getDouble(24); d2 = dd.getPointer().getDouble(16); d1 = (d3 - d2) * result; result = d4 + d1; break; }  return result; } public static double GEfromDeviceWidth(double value, int to, Ptr dd) { double d1, d2, d3; result = value;
/*  344 */     switch (to) {
/*      */ 
/*      */       
/*      */       case 1:
/*  348 */         d3 = dd.getPointer().getDouble(8); d2 = dd.getPointer().getDouble(); d1 = d3 - d2; result /= d1;
/*      */         break;
/*      */       case 2:
/*  351 */         result = dd.getPointer().getDouble(88) * result;
/*      */         break;
/*      */       case 3:
/*  354 */         result = dd.getPointer().getDouble(88) * result * 2.54D; break;
/*      */     } 
/*  356 */     return result; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void spline_segment_computing(double step, int k, Ptr px, Ptr py, double s1, double s2, Ptr dd) {
/*      */     A_blend = new double[4];
/*      */     if (s1 >= 0.0D)
/*  369 */     { if (s2 >= 0.0D)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  377 */         for (t = 0.0D; t < 1.0D; t += step)
/*  378 */         { positive_s1_influence(k, t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2));
/*  379 */           positive_s2_influence(k, t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3));
/*      */           
/*  381 */           point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); }  return; }  for (t = 0.0D; t < 1.0D; t += step) { positive_s1_influence(k, t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); }  return; }  if (s2 >= 0.0D) { for (t = 0.0D; t < 1.0D; t += step) { negative_s1_influence(t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); }  return; }  for (t = 0.0D; t < 1.0D; t += step) { negative_s1_influence(t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); }  } public static double GEtoDeviceWidth(double value, int from, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7; result = value; switch (from) { case 3: result /= 2.54D;case 2: d7 = dd.getPointer().getDouble(88); d6 = result / d7; d5 = dd.getPointer().getDouble(8); d4 = dd.getPointer().getDouble(); d3 = Math.abs(d5 - d4); result = d6 / d3;case 1: d2 = dd.getPointer().getDouble(8); d1 = dd.getPointer().getDouble(); result = (d2 - d1) * result; break; }  return result; } public static double GEfromDeviceHeight(double value, int to, Ptr dd) { double d1, d2, d3; result = value;
/*  382 */     switch (to) {
/*      */ 
/*      */       
/*      */       case 1:
/*  386 */         d3 = dd.getPointer().getDouble(24); d2 = dd.getPointer().getDouble(16); d1 = d3 - d2; result /= d1;
/*      */         break;
/*      */       case 2:
/*  389 */         result = dd.getPointer().getDouble(96) * result;
/*      */         break;
/*      */       case 3:
/*  392 */         result = dd.getPointer().getDouble(96) * result * 2.54D; break;
/*      */     } 
/*  394 */     return result; }
/*      */ 
/*      */   
/*      */   public static void spline_last_segment_computing(double step, int k, Ptr px, Ptr py, double s1, double s2, Ptr dd) {
/*  398 */     A_blend = new double[4]; t = 1.0D;
/*      */     
/*  400 */     if (s1 >= 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  412 */       if (s2 >= 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  418 */         positive_s1_influence(k, t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2));
/*  419 */         positive_s2_influence(k, t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3));
/*      */         
/*  421 */         point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); return;
/*      */       }  positive_s1_influence(k, t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); return;
/*      */     }  if (s2 >= 0.0D) {
/*      */       negative_s1_influence(t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); positive_s2_influence(k, t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd); return;
/*      */     }  negative_s1_influence(t, s1, (Ptr)new DoublePtr(A_blend, 0), (Ptr)new DoublePtr(A_blend, 2)); negative_s2_influence(t, s2, (Ptr)new DoublePtr(A_blend, 1), (Ptr)new DoublePtr(A_blend, 3)); point_adding((Ptr)new DoublePtr(A_blend, 0), px, py, dd);
/*      */   } public static double GEtoDeviceHeight(double value, int from, Ptr dd) { double d1, d2, d3, d4, d5, d6, d7; result = value; switch (from) {
/*      */       case 3:
/*      */         result /= 2.54D;
/*      */       case 2:
/*      */         d7 = dd.getPointer().getDouble(96); d6 = result / d7;
/*      */         d5 = dd.getPointer().getDouble(24);
/*      */         d4 = dd.getPointer().getDouble(16);
/*      */         d3 = Math.abs(d5 - d4);
/*      */         result = d6 / d3;
/*      */       case 1:
/*      */         d2 = dd.getPointer().getDouble(24);
/*      */         d1 = dd.getPointer().getDouble(16);
/*      */         result = (d2 - d1) * result;
/*      */         break;
/*      */     } 
/*  441 */     return result; } public static int GE_LENDpar(SEXP value, int ind) { null = 0; if (Rinternals.TYPEOF(value) == 16) {
/*  442 */       for (i = 0; !Context.get__baseEngine$lineend().getPointer(i * 8).isNull(); ) {
/*  443 */         Ptr ptr = Context.get__baseEngine$lineend().getPointer(i * 8); if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(value, ind)), ptr) != 0) { i++; continue; }
/*  444 */          null = Context.get__baseEngine$lineend().getInt(i * 8 + 4); // Byte code: goto -> 414
/*      */       } 
/*  446 */       Error.Rf_error(new BytePtr("invalid line end\000".getBytes(), 0), new Object[0]);
/*      */     } 
/*  448 */     if (!Rinternals.Rf_isInteger(value))
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  456 */       if (Rinternals.TYPEOF(value) != 14)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  466 */         Error.Rf_error(new BytePtr("invalid line end\000".getBytes(), 0), new Object[0]); return null; }  Ptr ptr4 = Rinternals2.REAL(value); int n = ind * 8; Ptr ptr3 = ptr4; int m = 0 + n; rcode = ptr3.getDouble(m); if (Arith.R_finite(rcode) == 0 || rcode < 0.0D) Error.Rf_error(new BytePtr("invalid line end\000".getBytes(), 0), new Object[0]);  code = (int)rcode; if (code > 0) { int i1 = code + -1; nlineend$363 = Context.get__baseEngine$nlineend(); code = i1 % nlineend$363 + 1; }  return Context.get__baseEngine$lineend().getInt(code * 8 + 4); }  Ptr ptr2 = Rinternals2.INTEGER(value); int k = ind * 4; Ptr ptr1 = ptr2; int j = 0 + k; code = ptr1.getInt(j); R_NaInt$360 = Arith.R_NaInt; if (code == R_NaInt$360 || code < 0) Error.Rf_error(new BytePtr("invalid line end\000".getBytes(), 0), new Object[0]);  if (code > 0) { int m = code + -1; nlineend$361 = Context.get__baseEngine$nlineend(); code = m % nlineend$361 + 1; }  return Context.get__baseEngine$lineend().getInt(code * 8 + 4); } public static int compute_open_spline(int n, Ptr x, Ptr y, Ptr s, int repEnds, double precision, Ptr dd) { ps = new double[4]; py = new double[4]; px = new double[4]; step = 0.0D; ps[0] = 0.0D; ps[1] = 0.0D; ps[2] = 0.0D; ps[3] = 0.0D; Context.set__baseEngine$max_points(0);
/*  467 */     Context.set__baseEngine$npoints(0);
/*  468 */     Context.set__baseEngine$xpoints(BytePtr.of(0)); Context.set__baseEngine$xpoints$offset(0);
/*  469 */     Context.set__baseEngine$ypoints(BytePtr.of(0)); Context.set__baseEngine$ypoints$offset(0);
/*      */     
/*  471 */     if (repEnds != 0 && n <= 1)
/*  472 */       Error.Rf_error(new BytePtr("there must be at least two control points\000".getBytes(), 0), new Object[0]); 
/*  473 */     if (repEnds == 0 && n <= 3) {
/*  474 */       Error.Rf_error(new BytePtr("there must be at least four control points\000".getBytes(), 0), new Object[0]);
/*      */     }
/*  476 */     if (repEnds == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  507 */       for (k = 0; k + 3 < n; k++) {
/*  508 */         int i22 = k % n * 8; Ptr ptr12 = x; int i21 = i22; double d18 = GEfromDeviceX(ptr12.getDouble(i21), 2, dd) * 1200.0D; px[0] = d18; int i20 = k % n * 8; Ptr ptr11 = y; int i19 = i20; double d17 = GEfromDeviceY(ptr11.getDouble(i19), 2, dd) * 1200.0D; py[0] = d17; int i18 = k % n * 8; Ptr ptr10 = s; int i17 = i18; double d16 = ptr10.getDouble(i17); ps[0] = d16; int i16 = (k + 1) % n * 8; Ptr ptr9 = x; int i15 = i16; double d15 = GEfromDeviceX(ptr9.getDouble(i15), 2, dd) * 1200.0D; px[1] = d15; int i14 = (k + 1) % n * 8; Ptr ptr8 = y; int i13 = i14; double d14 = GEfromDeviceY(ptr8.getDouble(i13), 2, dd) * 1200.0D; py[1] = d14; int i12 = (k + 1) % n * 8; Ptr ptr7 = s; int i11 = i12; double d13 = ptr7.getDouble(i11); ps[1] = d13; int i10 = (k + 2) % n * 8; Ptr ptr6 = x; int i9 = i10; double d12 = GEfromDeviceX(ptr6.getDouble(i9), 2, dd) * 1200.0D; px[2] = d12; int i8 = (k + 2) % n * 8; Ptr ptr5 = y; int i7 = i8; double d11 = GEfromDeviceY(ptr5.getDouble(i7), 2, dd) * 1200.0D; py[2] = d11; int i6 = (k + 2) % n * 8; Ptr ptr4 = s; int i5 = i6; double d10 = ptr4.getDouble(i5); ps[2] = d10; int i4 = (k + 3) % n * 8; Ptr ptr3 = x; int i3 = i4; double d9 = GEfromDeviceX(ptr3.getDouble(i3), 2, dd) * 1200.0D; px[3] = d9; int i2 = (k + 3) % n * 8; Ptr ptr2 = y; int i1 = i2; double d8 = GEfromDeviceY(ptr2.getDouble(i1), 2, dd) * 1200.0D; py[3] = d8; int m = (k + 3) % n * 8; Ptr ptr1 = s; int j = m; double d7 = ptr1.getDouble(j); ps[3] = d7;
/*  509 */         double d6 = ps[2], d5 = ps[1]; step = step_computing(k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d5, d6, precision, dd); double d4 = ps[2], d3 = ps[1]; spline_segment_computing(step, k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d3, d4, dd);
/*      */       } 
/*  511 */       double d2 = ps[2], d1 = ps[1]; int i = n + -4; spline_last_segment_computing(step, i, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d1, d2, dd); } else { double d26 = GEfromDeviceX(x.getDouble(), 2, dd) * 1200.0D; px[0] = d26; double d25 = GEfromDeviceY(y.getDouble(), 2, dd) * 1200.0D; py[0] = d25; double d24 = s.getDouble(); ps[0] = d24; double d23 = GEfromDeviceX(x.getDouble(), 2, dd) * 1200.0D; px[1] = d23; double d22 = GEfromDeviceY(y.getDouble(), 2, dd) * 1200.0D; py[1] = d22; double d21 = s.getDouble(); ps[1] = d21; int i27 = 1 % n * 8; Ptr ptr15 = x; int i26 = i27; double d20 = GEfromDeviceX(ptr15.getDouble(i26), 2, dd) * 1200.0D; px[2] = d20; int i25 = 1 % n * 8; Ptr ptr14 = y; int i24 = i25; double d19 = GEfromDeviceY(ptr14.getDouble(i24), 2, dd) * 1200.0D; py[2] = d19; int i23 = 1 % n * 8; Ptr ptr13 = s; int i22 = i23; double d18 = ptr13.getDouble(i22); ps[2] = d18; if (n != 2) { int i33 = 2 % n * 8; Ptr ptr18 = x; int i32 = i33; double d29 = GEfromDeviceX(ptr18.getDouble(i32), 2, dd) * 1200.0D; px[3] = d29; int i31 = 2 % n * 8; Ptr ptr17 = y; int i30 = i31; double d28 = GEfromDeviceY(ptr17.getDouble(i30), 2, dd) * 1200.0D; py[3] = d28; int i29 = 2 % n * 8; Ptr ptr16 = s; int i28 = i29; double d27 = ptr16.getDouble(i28); ps[3] = d27; } else { int i33 = 1 % n * 8; Ptr ptr18 = x; int i32 = i33; double d29 = GEfromDeviceX(ptr18.getDouble(i32), 2, dd) * 1200.0D; px[3] = d29; int i31 = 1 % n * 8; Ptr ptr17 = y; int i30 = i31; double d28 = GEfromDeviceY(ptr17.getDouble(i30), 2, dd) * 1200.0D; py[3] = d28; int i29 = 1 % n * 8; Ptr ptr16 = s; int i28 = i29; double d27 = ptr16.getDouble(i28); ps[3] = d27; }  k = 0; while (true) { double d30 = ps[2], d29 = ps[1]; step = step_computing(k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d29, d30, precision, dd); double d28 = ps[2], d27 = ps[1]; spline_segment_computing(step, k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d27, d28, dd); if (k + 3 < n) { int i51 = k % n * 8; Ptr ptr27 = x; int i50 = i51; double d42 = GEfromDeviceX(ptr27.getDouble(i50), 2, dd) * 1200.0D; px[0] = d42; int i49 = k % n * 8; Ptr ptr26 = y; int i48 = i49; double d41 = GEfromDeviceY(ptr26.getDouble(i48), 2, dd) * 1200.0D; py[0] = d41; int i47 = k % n * 8; Ptr ptr25 = s; int i46 = i47; double d40 = ptr25.getDouble(i46); ps[0] = d40; int i45 = (k + 1) % n * 8; Ptr ptr24 = x; int i44 = i45; double d39 = GEfromDeviceX(ptr24.getDouble(i44), 2, dd) * 1200.0D; px[1] = d39; int i43 = (k + 1) % n * 8; Ptr ptr23 = y; int i42 = i43; double d38 = GEfromDeviceY(ptr23.getDouble(i42), 2, dd) * 1200.0D; py[1] = d38; int i41 = (k + 1) % n * 8; Ptr ptr22 = s; int i40 = i41; double d37 = ptr22.getDouble(i40); ps[1] = d37; int i39 = (k + 2) % n * 8; Ptr ptr21 = x; int i38 = i39; double d36 = GEfromDeviceX(ptr21.getDouble(i38), 2, dd) * 1200.0D; px[2] = d36; int i37 = (k + 2) % n * 8; Ptr ptr20 = y; int i36 = i37; double d35 = GEfromDeviceY(ptr20.getDouble(i36), 2, dd) * 1200.0D; py[2] = d35; int i35 = (k + 2) % n * 8; Ptr ptr19 = s; int i34 = i35; double d34 = ptr19.getDouble(i34); ps[2] = d34; int i33 = (k + 3) % n * 8; Ptr ptr18 = x; int i32 = i33; double d33 = GEfromDeviceX(ptr18.getDouble(i32), 2, dd) * 1200.0D; px[3] = d33; int i31 = (k + 3) % n * 8; Ptr ptr17 = y; int i30 = i31; double d32 = GEfromDeviceY(ptr17.getDouble(i30), 2, dd) * 1200.0D; py[3] = d32; int i29 = (k + 3) % n * 8; Ptr ptr16 = s; int i28 = i29; double d31 = ptr16.getDouble(i28); ps[3] = d31; k++; }
/*      */          break; }
/*      */        int i21 = (n + -3) % n * 8; Ptr ptr12 = x; int i20 = i21; double d17 = GEfromDeviceX(ptr12.getDouble(i20), 2, dd) * 1200.0D; px[0] = d17; int i19 = (n + -3) % n * 8; Ptr ptr11 = y; int i18 = i19; double d16 = GEfromDeviceY(ptr11.getDouble(i18), 2, dd) * 1200.0D; py[0] = d16; int i17 = (n + -3) % n * 8; Ptr ptr10 = s; int i16 = i17; double d15 = ptr10.getDouble(i16); ps[0] = d15; int i15 = (n + -2) % n * 8; Ptr ptr9 = x; int i14 = i15; double d14 = GEfromDeviceX(ptr9.getDouble(i14), 2, dd) * 1200.0D; px[1] = d14; int i13 = (n + -2) % n * 8; Ptr ptr8 = y; int i12 = i13; double d13 = GEfromDeviceY(ptr8.getDouble(i12), 2, dd) * 1200.0D; py[1] = d13; int i11 = (n + -2) % n * 8; Ptr ptr7 = s; int i10 = i11; double d12 = ptr7.getDouble(i10); ps[1] = d12; int i9 = (n + -1) % n * 8; Ptr ptr6 = x; int i8 = i9; double d11 = GEfromDeviceX(ptr6.getDouble(i8), 2, dd) * 1200.0D; px[2] = d11; int i7 = (n + -1) % n * 8; Ptr ptr5 = y; int i6 = i7; double d10 = GEfromDeviceY(ptr5.getDouble(i6), 2, dd) * 1200.0D; py[2] = d10; int i5 = (n + -1) % n * 8; Ptr ptr4 = s; int i4 = i5; double d9 = ptr4.getDouble(i4); ps[2] = d9; int i3 = (n + -1) % n * 8; Ptr ptr3 = x; int i2 = i3; double d8 = GEfromDeviceX(ptr3.getDouble(i2), 2, dd) * 1200.0D; px[3] = d8; int i1 = (n + -1) % n * 8; Ptr ptr2 = y; int m = i1; double d7 = GEfromDeviceY(ptr2.getDouble(m), 2, dd) * 1200.0D; py[3] = d7; int j = (n + -1) % n * 8; Ptr ptr1 = s; int i = j; double d6 = ptr1.getDouble(i); ps[3] = d6; double d5 = ps[2], d4 = ps[1]; step = step_computing(k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d4, d5, precision, dd); double d3 = ps[2], d2 = ps[1]; spline_segment_computing(step, k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d2, d3, dd); double d1 = py[3]; add_point(px[3], d1, dd); }
/*  514 */      return 1; }
/*      */   public static SEXP GE_LENDget(int lend) { SEXP sEXP = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue; i = 0; while (true) { if (!Context.get__baseEngine$lineend().getPointer(i * 8).isNull()) { if (Context.get__baseEngine$lineend().getInt(i * 8 + 4) != lend) { i++; continue; }
/*      */          sEXP = Rinternals.Rf_mkString(Context.get__baseEngine$lineend().getPointer(i * 8)); break; }
/*      */        Error.Rf_error(new BytePtr("invalid line end\000".getBytes(), 0), new Object[0]); break; }
/*      */      return sEXP; } public static int GE_LJOINpar(SEXP value, int ind) { null = 0; if (Rinternals.TYPEOF(value) == 16) { for (i = 0; !Context.get__baseEngine$linejoin().getPointer(i * 8).isNull(); ) { Ptr ptr = Context.get__baseEngine$linejoin().getPointer(i * 8); if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(value, ind)), ptr) != 0) { i++; continue; }
/*      */          null = Context.get__baseEngine$linejoin().getInt(i * 8 + 4); // Byte code: goto -> 414 }
/*      */        Error.Rf_error(new BytePtr("invalid line join\000".getBytes(), 0), new Object[0]); }
/*  521 */      if (!Rinternals.Rf_isInteger(value)) { if (Rinternals.TYPEOF(value) != 14)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  531 */         Error.Rf_error(new BytePtr("invalid line join\000".getBytes(), 0), new Object[0]); return null; }  Ptr ptr4 = Rinternals2.REAL(value); int n = ind * 8; Ptr ptr3 = ptr4; int m = 0 + n; rcode = ptr3.getDouble(m); if (Arith.R_finite(rcode) == 0 || rcode < 0.0D) Error.Rf_error(new BytePtr("invalid line join\000".getBytes(), 0), new Object[0]);  code = (int)rcode; if (code > 0) { int i1 = code + -1; nlinejoin$358 = Context.get__baseEngine$nlinejoin(); code = i1 % nlinejoin$358 + 1; }  return Context.get__baseEngine$linejoin().getInt(code * 8 + 4); }  Ptr ptr2 = Rinternals2.INTEGER(value); int k = ind * 4; Ptr ptr1 = ptr2; int j = 0 + k; code = ptr1.getInt(j); R_NaInt$355 = Arith.R_NaInt; if (code == R_NaInt$355 || code < 0) Error.Rf_error(new BytePtr("invalid line join\000".getBytes(), 0), new Object[0]);  if (code > 0) { int m = code + -1; nlinejoin$356 = Context.get__baseEngine$nlinejoin(); code = m % nlinejoin$356 + 1; }  return Context.get__baseEngine$linejoin().getInt(code * 8 + 4); } public static int compute_closed_spline(int n, Ptr x, Ptr y, Ptr s, double precision, Ptr dd) { ps = new double[4]; py = new double[4]; px = new double[4]; Context.set__baseEngine$max_points(0); Context.set__baseEngine$npoints(0); Context.set__baseEngine$xpoints(BytePtr.of(0)); Context.set__baseEngine$xpoints$offset(0); Context.set__baseEngine$ypoints(BytePtr.of(0)); Context.set__baseEngine$ypoints$offset(0);
/*      */     
/*  533 */     if (n <= 2) {
/*  534 */       Error.Rf_error(new BytePtr("There must be at least three control points\000".getBytes(), 0), new Object[0]);
/*      */     }
/*  536 */     int i15 = (n + -1) % n * 8; Ptr ptr9 = x; int i14 = i15; double d12 = GEfromDeviceX(ptr9.getDouble(i14), 2, dd) * 1200.0D; px[0] = d12; int i13 = (n + -1) % n * 8; Ptr ptr8 = y; int i12 = i13; double d11 = GEfromDeviceY(ptr8.getDouble(i12), 2, dd) * 1200.0D; py[0] = d11; int i11 = (n + -1) % n * 8; Ptr ptr7 = s; int i10 = i11; double d10 = ptr7.getDouble(i10); ps[0] = d10; double d9 = GEfromDeviceX(x.getDouble(), 2, dd) * 1200.0D; px[1] = d9; double d8 = GEfromDeviceY(y.getDouble(), 2, dd) * 1200.0D; py[1] = d8; double d7 = s.getDouble(); ps[1] = d7; int i9 = 1 % n * 8; Ptr ptr6 = x; int i8 = i9; double d6 = GEfromDeviceX(ptr6.getDouble(i8), 2, dd) * 1200.0D; px[2] = d6; int i7 = 1 % n * 8; Ptr ptr5 = y; int i6 = i7; double d5 = GEfromDeviceY(ptr5.getDouble(i6), 2, dd) * 1200.0D; py[2] = d5; int i5 = 1 % n * 8; Ptr ptr4 = s; int i4 = i5; double d4 = ptr4.getDouble(i4); ps[2] = d4; int i3 = 2 % n * 8; Ptr ptr3 = x; int i2 = i3; double d3 = GEfromDeviceX(ptr3.getDouble(i2), 2, dd) * 1200.0D; px[3] = d3; int i1 = 2 % n * 8; Ptr ptr2 = y; int m = i1; double d2 = GEfromDeviceY(ptr2.getDouble(m), 2, dd) * 1200.0D; py[3] = d2; int j = 2 % n * 8; Ptr ptr1 = s; int i = j; double d1 = ptr1.getDouble(i); ps[3] = d1;
/*      */     
/*  538 */     for (k = 0; k < n; k++) {
/*  539 */       double d28 = ps[2], d27 = ps[1]; step = step_computing(k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d27, d28, precision, dd); double d26 = ps[2], d25 = ps[1]; spline_segment_computing(step, k, (Ptr)new DoublePtr(px, 0), (Ptr)new DoublePtr(py, 0), d25, d26, dd);
/*  540 */       int i39 = k % n * 8; Ptr ptr21 = x; int i38 = i39; double d24 = GEfromDeviceX(ptr21.getDouble(i38), 2, dd) * 1200.0D; px[0] = d24; int i37 = k % n * 8; Ptr ptr20 = y; int i36 = i37; double d23 = GEfromDeviceY(ptr20.getDouble(i36), 2, dd) * 1200.0D; py[0] = d23; int i35 = k % n * 8; Ptr ptr19 = s; int i34 = i35; double d22 = ptr19.getDouble(i34); ps[0] = d22; int i33 = (k + 1) % n * 8; Ptr ptr18 = x; int i32 = i33; double d21 = GEfromDeviceX(ptr18.getDouble(i32), 2, dd) * 1200.0D; px[1] = d21; int i31 = (k + 1) % n * 8; Ptr ptr17 = y; int i30 = i31; double d20 = GEfromDeviceY(ptr17.getDouble(i30), 2, dd) * 1200.0D; py[1] = d20; int i29 = (k + 1) % n * 8; Ptr ptr16 = s; int i28 = i29; double d19 = ptr16.getDouble(i28); ps[1] = d19; int i27 = (k + 2) % n * 8; Ptr ptr15 = x; int i26 = i27; double d18 = GEfromDeviceX(ptr15.getDouble(i26), 2, dd) * 1200.0D; px[2] = d18; int i25 = (k + 2) % n * 8; Ptr ptr14 = y; int i24 = i25; double d17 = GEfromDeviceY(ptr14.getDouble(i24), 2, dd) * 1200.0D; py[2] = d17; int i23 = (k + 2) % n * 8; Ptr ptr13 = s; int i22 = i23; double d16 = ptr13.getDouble(i22); ps[2] = d16; int i21 = (k + 3) % n * 8; Ptr ptr12 = x; int i20 = i21; double d15 = GEfromDeviceX(ptr12.getDouble(i20), 2, dd) * 1200.0D; px[3] = d15; int i19 = (k + 3) % n * 8; Ptr ptr11 = y; int i18 = i19; double d14 = GEfromDeviceY(ptr11.getDouble(i18), 2, dd) * 1200.0D; py[3] = d14; int i17 = (k + 3) % n * 8; Ptr ptr10 = s; int i16 = i17; double d13 = ptr10.getDouble(i16); ps[3] = d13;
/*      */     } 
/*      */     
/*  543 */     return 1; } public static SEXP GE_LJOINget(int ljoin) { SEXP sEXP = (SEXP)BytePtr.of(0).getArray(); ans = Rinternals.R_NilValue; i = 0; while (true) { if (!Context.get__baseEngine$linejoin().getPointer(i * 8).isNull()) { if (Context.get__baseEngine$linejoin().getInt(i * 8 + 4) != ljoin) { i++; continue; }
/*      */          sEXP = Rinternals.Rf_mkString(Context.get__baseEngine$linejoin().getPointer(i * 8)); break; }
/*  545 */        Error.Rf_error(new BytePtr("invalid line join\000".getBytes(), 0), new Object[0]);
/*      */       break; }
/*      */     
/*      */     return sEXP; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void getClipRect(Ptr x1, Ptr y1, Ptr x2, Ptr y2, Ptr dd) {
/*  561 */     double d6 = dd.getPointer().getDouble(32), d5 = dd.getPointer().getDouble(40); if (d6 >= d5)
/*      */     
/*      */     { 
/*      */       
/*  565 */       double d8 = dd.getPointer().getDouble(32); x2.setDouble(d8);
/*  566 */       double d7 = dd.getPointer().getDouble(40); x1.setDouble(d7); }
/*      */     else { double d8 = dd.getPointer().getDouble(32); x1.setDouble(d8); double d7 = dd.getPointer().getDouble(40); x2.setDouble(d7); }
/*  568 */      double d4 = dd.getPointer().getDouble(48), d3 = dd.getPointer().getDouble(56); if (d4 >= d3) {
/*      */ 
/*      */ 
/*      */       
/*  572 */       double d8 = dd.getPointer().getDouble(48); y2.setDouble(d8);
/*  573 */       double d7 = dd.getPointer().getDouble(56); y1.setDouble(d7);
/*      */       return;
/*      */     } 
/*      */     double d2 = dd.getPointer().getDouble(48);
/*      */     y1.setDouble(d2);
/*      */     double d1 = dd.getPointer().getDouble(56);
/*      */     y2.setDouble(d1);
/*      */   } public static void getClipRectToDevice(Ptr x1, Ptr y1, Ptr x2, Ptr y2, Ptr dd) {
/*  581 */     double d6 = dd.getPointer().getDouble(), d5 = dd.getPointer().getDouble(8); if (d6 >= d5)
/*      */     
/*      */     { 
/*      */       
/*  585 */       double d8 = dd.getPointer().getDouble(); x2.setDouble(d8);
/*  586 */       double d7 = dd.getPointer().getDouble(8); x1.setDouble(d7); }
/*      */     else { double d8 = dd.getPointer().getDouble(); x1.setDouble(d8); double d7 = dd.getPointer().getDouble(8); x2.setDouble(d7); }
/*  588 */      double d4 = dd.getPointer().getDouble(16), d3 = dd.getPointer().getDouble(24); if (d4 >= d3) {
/*      */ 
/*      */ 
/*      */       
/*  592 */       double d8 = dd.getPointer().getDouble(16); y2.setDouble(d8);
/*  593 */       double d7 = dd.getPointer().getDouble(24); y1.setDouble(d7);
/*      */       return;
/*      */     } 
/*      */     double d2 = dd.getPointer().getDouble(16);
/*      */     y1.setDouble(d2);
/*      */     double d1 = dd.getPointer().getDouble(24);
/*      */     y2.setDouble(d1);
/*      */   }
/*      */   
/*      */   public static void GESetClip(double x1, double y1, double x2, double y2, Ptr dd) {
/*  603 */     d = dd.getPointer();
/*  604 */     dx1 = d.getDouble(); dx2 = d.getDouble(8); dy1 = d.getDouble(16); dy2 = d.getDouble(24);
/*      */ 
/*      */     
/*  607 */     if (dx1 > dx2)
/*      */     
/*      */     { 
/*      */       
/*  611 */       x1 = Rmath.Rf_fmin2(x1, dx1);
/*  612 */       x2 = Rmath.Rf_fmax2(x2, dx2); }
/*      */     else { x1 = Rmath.Rf_fmax2(x1, dx1); x2 = Rmath.Rf_fmin2(x2, dx2); }
/*  614 */      if (dy1 > dy2)
/*      */     
/*      */     { 
/*      */       
/*  618 */       y1 = Rmath.Rf_fmin2(y1, dy1);
/*  619 */       y2 = Rmath.Rf_fmax2(y2, dy2); }
/*      */     else { y1 = Rmath.Rf_fmax2(y1, dy1); y2 = Rmath.Rf_fmin2(y2, dy2); }
/*  621 */      MethodHandle methodHandle = d.getPointer(208).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(x1, x2, y1, y2, ptr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  626 */     double d4 = Rmath.Rf_fmin2(x1, x2); d.setDouble(32, d4);
/*  627 */     double d3 = Rmath.Rf_fmax2(x1, x2); d.setDouble(40, d3);
/*  628 */     double d2 = Rmath.Rf_fmax2(y1, y2); d.setDouble(56, d2);
/*  629 */     double d1 = Rmath.Rf_fmin2(y1, y2); d.setDouble(48, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int clipcode(double x, double y, Ptr cr) {
/*  657 */     c = 0;
/*  658 */     if (cr.getDouble() <= x)
/*      */     
/*  660 */     { if (cr.getAlignedDouble(1) < x)
/*  661 */         c |= 0x8;  } else { c |= 0x2; }
/*  662 */      if (cr.getAlignedDouble(2) <= y)
/*      */     
/*  664 */     { if (cr.getAlignedDouble(3) < y)
/*  665 */         c |= 0x4; 
/*  666 */       return c; }  c |= 0x1; return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int CSclipline(Ptr x1, Ptr y1, Ptr x2, Ptr y2, Ptr cr, Ptr clipped1, Ptr clipped2, Ptr dd) {
/*  677 */     yt = 0.0D; yb = 0.0D; xr = 0.0D; xl = 0.0D; y = 0.0D; x = 0.0D; c2 = 0; c1 = 0; clipped1.setInt(0);
/*  678 */     clipped2.setInt(0);
/*  679 */     double d2 = y1.getDouble(); c1 = clipcode(x1.getDouble(), d2, cr);
/*  680 */     double d1 = y2.getDouble(); c2 = clipcode(x2.getDouble(), d1, cr);
/*  681 */     if (c1 != 0 || c2 != 0) {
/*      */       boolean bool;
/*      */       
/*  684 */       xl = cr.getDouble();
/*  685 */       xr = cr.getAlignedDouble(1);
/*  686 */       yb = cr.getAlignedDouble(2);
/*  687 */       yt = cr.getAlignedDouble(3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  692 */       x = xl;
/*  693 */       y = yb; while (true) {
/*  694 */         if (c1 == 0 && c2 == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  731 */           boolean bool1 = true; break;
/*      */         }  if ((c1 & c2) == 0) { if (c1 == 0) { c = c2; }
/*      */           else { c = c1; }
/*      */            if ((c & 0x2) == 0) { if ((c & 0x8) == 0) { if ((c & 0x1) == 0) { if ((c & 0x4) != 0) { double d13 = x1.getDouble(), d12 = x2.getDouble(), d11 = x1.getDouble(), d10 = d12 - d11, d9 = y1.getDouble(), d8 = yt - d9, d7 = d10 * d8, d6 = y2.getDouble(), d5 = y1.getDouble(), d4 = d6 - d5, d3 = d7 / d4; x = d13 + d3; y = yt; }
/*      */                  }
/*      */               else { double d13 = x1.getDouble(), d12 = x2.getDouble(), d11 = x1.getDouble(), d10 = d12 - d11, d9 = y1.getDouble(), d8 = yb - d9, d7 = d10 * d8, d6 = y2.getDouble(), d5 = y1.getDouble(), d4 = d6 - d5, d3 = d7 / d4; x = d13 + d3; y = yb; }
/*      */                }
/*      */             else { double d13 = y1.getDouble(), d12 = y2.getDouble(), d11 = y1.getDouble(), d10 = d12 - d11, d9 = x1.getDouble(), d8 = xr - d9, d7 = d10 * d8, d6 = x2.getDouble(), d5 = x1.getDouble(), d4 = d6 - d5, d3 = d7 / d4; y = d13 + d3; x = xr; }
/*      */              }
/*      */           else { double d13 = y1.getDouble(), d12 = y2.getDouble(), d11 = y1.getDouble(), d10 = d12 - d11, d9 = x1.getDouble(), d8 = xl - d9, d7 = d10 * d8, d6 = x2.getDouble(), d5 = x1.getDouble(), d4 = d6 - d5, d3 = d7 / d4; y = d13 + d3; x = xl; }
/*      */            if (c != c1) { x2.setDouble(x); y2.setDouble(y); clipped2.setInt(1); c2 = clipcode(x, y, cr); continue; }
/*      */            x1.setDouble(x); y1.setDouble(y); clipped1.setInt(1); c1 = clipcode(x, y, cr); continue; }
/*      */          bool = false; break;
/*      */       }  return bool;
/*  745 */     }  return 1; } public static int clipLine(Ptr x1, Ptr y1, Ptr x2, Ptr y2, int toDevice, Ptr dd) { MixedPtr mixedPtr = MixedPtr.malloc(32); dummy2 = new int[1]; dummy1 = new int[1]; dummy2[0] = 0; dummy1[0] = 0; if (toDevice == 0)
/*      */     
/*      */     { 
/*  748 */       getClipRect((Ptr)mixedPtr, mixedPtr.pointerPlus(16), mixedPtr.pointerPlus(8), mixedPtr.pointerPlus(24), dd); }
/*      */     else { getClipRectToDevice((Ptr)mixedPtr, mixedPtr.pointerPlus(16), mixedPtr.pointerPlus(8), mixedPtr.pointerPlus(24), dd); }
/*  750 */      return CSclipline(x1, y1, x2, y2, (Ptr)mixedPtr, (Ptr)new IntPtr(dummy1, 0), (Ptr)new IntPtr(dummy2, 0), dd); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GELine(double x1, double y1, double x2, double y2, Ptr gc, Ptr dd) {
/*  763 */     arrayOfDouble1 = new double[] { x1 }; arrayOfDouble2 = new double[] { y1 }; arrayOfDouble3 = new double[] { x2 }; arrayOfDouble4 = new double[] { y2 }; double d = gc.getAlignedDouble(2); R_PosInf$349 = Arith.R_PosInf; if (d == R_PosInf$349 || gc.getAlignedDouble(2) < 0.0D)
/*  764 */       Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/*  765 */     if (Builtins.__isnan(gc.getAlignedDouble(2)) == 0 && gc.getAlignedInt(6) != -1) {
/*  766 */       if (dd.getPointer().getInt(128) == 0)
/*      */       
/*      */       { 
/*      */         
/*  770 */         clip_ok = clipLine((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), 0, dd); }
/*      */       else { clip_ok = clipLine((Ptr)new DoublePtr(arrayOfDouble1, 0), (Ptr)new DoublePtr(arrayOfDouble2, 0), (Ptr)new DoublePtr(arrayOfDouble3, 0), (Ptr)new DoublePtr(arrayOfDouble4, 0), 1, dd); }
/*  772 */        if (clip_ok != 0) {
/*  773 */         MethodHandle methodHandle = dd.getPointer().getPointer(224).toMethodHandle(); Ptr ptr = dd.getPointer(); y2$350 = arrayOfDouble4[0]; x2$351 = arrayOfDouble3[0]; y1$352 = arrayOfDouble2[0]; x1$353 = arrayOfDouble1[0]; methodHandle.invoke(x1$353, y1$352, x2$351, y2$350, gc, ptr);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void CScliplines(int n, Ptr x, Ptr y, Ptr gc, int toDevice, Ptr dd) {
/*  786 */     MixedPtr mixedPtr = MixedPtr.malloc(32); y2 = new double[1]; x2 = new double[1]; y1 = new double[1]; x1 = new double[1]; ind2 = new int[1]; ind1 = new int[1]; vmax = BytePtr.of(0); vmax$offset = 0; yy = BytePtr.of(0); yy$offset = 0; xx = BytePtr.of(0); xx$offset = 0; count = 0; ind2[0] = 0; ind1[0] = 0; count = 0;
/*  787 */     i = 0;
/*      */ 
/*      */ 
/*      */     
/*  791 */     vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */     
/*  793 */     if (toDevice == 0)
/*      */     
/*      */     { 
/*  796 */       getClipRect((Ptr)mixedPtr, mixedPtr.pointerPlus(16), mixedPtr.pointerPlus(8), mixedPtr.pointerPlus(24), dd); }
/*      */     else { getClipRectToDevice((Ptr)mixedPtr, mixedPtr.pointerPlus(16), mixedPtr.pointerPlus(8), mixedPtr.pointerPlus(24), dd); }
/*  798 */      DoublePtr doublePtr2 = DoublePtr.malloc(n * 8); xx$offset = 0;
/*  799 */     DoublePtr doublePtr1 = DoublePtr.malloc(n * 8); yy$offset = 0;
/*  800 */     if (doublePtr2.pointerPlus(xx$offset).isNull() || doublePtr1.pointerPlus(yy$offset).isNull()) {
/*  801 */       Error.Rf_error(new BytePtr("out of memory while clipping polyline\000".getBytes(), 0), new Object[0]);
/*      */     }
/*  803 */     x1$317 = x.getDouble(); x1[0] = x1$317; x1$318 = x1[0]; doublePtr2.setDouble(xx$offset, x1$318);
/*  804 */     y1$319 = y.getDouble(); y1[0] = y1$319; y1$320 = y1[0]; doublePtr1.setDouble(yy$offset, y1$320);
/*  805 */     count = 1;
/*      */     
/*  807 */     for (i = 1; i < n; i++) {
/*  808 */       int i5 = i * 8; Ptr ptr4 = x; int i4 = i5; x2$322 = ptr4.getDouble(i4); x2[0] = x2$322;
/*  809 */       int i3 = i * 8; Ptr ptr3 = y; int i2 = i3; y2$324 = ptr3.getDouble(i2); y2[0] = y2$324;
/*  810 */       if (CSclipline((Ptr)new DoublePtr(x1, 0), (Ptr)new DoublePtr(y1, 0), (Ptr)new DoublePtr(x2, 0), (Ptr)new DoublePtr(y2, 0), (Ptr)mixedPtr, (Ptr)new IntPtr(ind1, 0), (Ptr)new IntPtr(ind2, 0), dd) != 0)
/*  811 */         if (ind1[0] == 0 || ind2[0] == 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  818 */           if (ind1[0] == 0)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  827 */             if (ind2[0] == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  835 */               int i9 = count * 8; DoublePtr doublePtr4 = doublePtr2; int i8 = xx$offset + i9; x2$342 = x2[0]; doublePtr4.setDouble(i8, x2$342);
/*  836 */               int i7 = count * 8; DoublePtr doublePtr3 = doublePtr1; int i6 = yy$offset + i7; y2$344 = y2[0]; doublePtr3.setDouble(i6, y2$344);
/*  837 */               count++;
/*  838 */               if (n + -1 == i && count > 1)
/*  839 */               { MethodHandle methodHandle = dd.getPointer().getPointer(244).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(count, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), gc, ptr); }  } else { int i9 = count * 8; DoublePtr doublePtr4 = doublePtr2; int i8 = xx$offset + i9; x2$338 = x2[0]; doublePtr4.setDouble(i8, x2$338); int i7 = count * 8; DoublePtr doublePtr3 = doublePtr1; int i6 = yy$offset + i7; y2$340 = y2[0]; doublePtr3.setDouble(i6, y2$340); count++; if (count > 1) { MethodHandle methodHandle = dd.getPointer().getPointer(244).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(count, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), gc, ptr); }  }  } else { x1$332 = x1[0]; doublePtr2.setDouble(xx$offset, x1$332); y1$333 = y1[0]; doublePtr1.setDouble(yy$offset, y1$333); DoublePtr doublePtr4 = doublePtr2; int i7 = xx$offset + 8; x2$334 = x2[0]; doublePtr4.setDouble(i7, x2$334); DoublePtr doublePtr3 = doublePtr1; int i6 = yy$offset + 8; y2$335 = y2[0]; doublePtr3.setDouble(i6, y2$335); count = 2; if (n + -1 == i) { MethodHandle methodHandle = dd.getPointer().getPointer(244).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(count, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), gc, ptr); }  }
/*      */            }
/*      */         else { x1$327 = x1[0]; doublePtr2.setDouble(xx$offset, x1$327); y1$328 = y1[0]; doublePtr1.setDouble(yy$offset, y1$328); DoublePtr doublePtr4 = doublePtr2; int i7 = xx$offset + 8; x2$329 = x2[0]; doublePtr4.setDouble(i7, x2$329); DoublePtr doublePtr3 = doublePtr1; int i6 = yy$offset + 8; y2$330 = y2[0]; doublePtr3.setDouble(i6, y2$330); MethodHandle methodHandle = dd.getPointer().getPointer(244).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(2, doublePtr2.pointerPlus(xx$offset), doublePtr1.pointerPlus(yy$offset), gc, ptr); }
/*  842 */           int i1 = i * 8; Ptr ptr2 = x; int m = i1; x1$346 = ptr2.getDouble(m); x1[0] = x1$346;
/*  843 */       int k = i * 8; Ptr ptr1 = y; int j = k; y1$348 = ptr1.getDouble(j); y1[0] = y1$348;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clipPolyline(int n, Ptr x, Ptr y, Ptr gc, int clipToDevice, Ptr dd) {
/*  859 */     CScliplines(n, x, y, gc, clipToDevice, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEPolyline(int n, Ptr x, Ptr y, Ptr gc, Ptr dd) {
/*  867 */     double d = gc.getAlignedDouble(2); R_PosInf$314 = Arith.R_PosInf; if (d == R_PosInf$314 || gc.getAlignedDouble(2) < 0.0D)
/*  868 */       Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/*  869 */     if (Builtins.__isnan(gc.getAlignedDouble(2)) == 0 && gc.getAlignedInt(6) != -1) {
/*  870 */       if (dd.getPointer().getInt(128) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  875 */         clipPolyline(n, x, y, gc, 0, dd);
/*      */         return;
/*      */       } 
/*      */       clipPolyline(n, x, y, gc, 1, dd);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int inside(int b, double px, double py, Ptr clip) {
/*  912 */     switch (b) { case 0:
/*  913 */         if (clip.getDouble() <= px) break;  return 0;
/*  914 */       case 1: if (clip.getAlignedDouble(1) >= px) break;  return 0;
/*  915 */       case 2: if (clip.getAlignedDouble(2) <= py) break;  return 0;
/*  916 */       case 3: if (clip.getAlignedDouble(3) >= py) break;  return 0; }
/*      */     
/*  918 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int cross(int b, double x1, double y1, double x2, double y2, Ptr clip) {
/*  925 */     int j = inside(b, x1, y1, clip), i = inside(b, x2, y2, clip); return (j != i) ? 
/*      */       
/*  927 */       1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void intersect(int b, double x1, double y1, double x2, double y2, Ptr ix, Ptr iy, Ptr clip) {
/*      */     double d1, d2, d3, d4, d5, d6, d7, d8;
/*  934 */     m = 0.0D;
/*      */     
/*  936 */     if (x1 != x2) { double d10 = y1 - y2, d9 = x1 - x2; m = d10 / d9; }
/*  937 */      switch (b) {
/*      */       case 0:
/*  939 */         d8 = clip.getDouble(); ix.setDouble(d8);
/*  940 */         d7 = (clip.getDouble() - x2) * m + y2; iy.setDouble(d7);
/*      */         break;
/*      */       case 1:
/*  943 */         d6 = clip.getAlignedDouble(1); ix.setDouble(d6);
/*  944 */         d5 = (clip.getAlignedDouble(1) - x2) * m + y2; iy.setDouble(d5);
/*      */         break;
/*      */       case 2:
/*  947 */         d4 = clip.getAlignedDouble(2); iy.setDouble(d4);
/*  948 */         if (x1 == x2) {
/*  949 */           ix.setDouble(x2); break;
/*      */         }  d3 = (clip.getAlignedDouble(2) - y2) / m + x2; ix.setDouble(d3); break;
/*      */       case 3:
/*  952 */         d2 = clip.getAlignedDouble(3); iy.setDouble(d2);
/*  953 */         if (x1 == x2) {
/*  954 */           ix.setDouble(x2);
/*      */           break;
/*      */         } 
/*      */         d1 = (clip.getAlignedDouble(3) - y2) / m + x2;
/*      */         ix.setDouble(d1);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void clipPoint(int b, double x, double y, Ptr xout, Ptr yout, Ptr cnt, int store, Ptr clip, Ptr cs) {
/*  964 */     iy = new double[1]; ix = new double[1]; ix[0] = 0.0D; iy[0] = 0.0D;
/*      */     
/*  966 */     int i1 = b * 36; Ptr ptr3 = cs; int n = i1; if (ptr3.getInt(n) != 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  978 */       int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; double d2 = ptr5.getDouble(i4 + 28); int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; double d1 = ptr4.getDouble(i2 + 20); if (cross(b, x, y, d1, d2, clip) != 0) {
/*  979 */         int i9 = b * 36; Ptr ptr7 = cs; int i8 = i9; double d4 = ptr7.getDouble(i8 + 28); int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; double d3 = ptr6.getDouble(i6 + 20); intersect(b, x, y, d3, d4, (Ptr)new DoublePtr(ix, 0), (Ptr)new DoublePtr(iy, 0), clip);
/*  980 */         if (b > 2)
/*      */         
/*      */         { 
/*      */           
/*  984 */           if (store != 0) {
/*  985 */             int i14 = cnt.getInt() * 8; Ptr ptr9 = xout; int i13 = i14; ix$312 = ix[0]; ptr9.setDouble(i13, ix$312);
/*  986 */             int i12 = cnt.getInt() * 8; Ptr ptr8 = yout; int i11 = i12; iy$313 = iy[0]; ptr8.setDouble(i11, iy$313);
/*      */           } 
/*  988 */           int i10 = cnt.getInt() + 1; cnt.setInt(i10); }
/*      */         else { iy$310 = iy[0]; ix$311 = ix[0]; clipPoint(b + 1, ix$311, iy$310, xout, yout, cnt, store, clip, cs); }
/*      */       
/*      */       }  }
/*      */     else { int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; ptr6.setInt(i6, 1); int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; ptr5.setDouble(i4 + 4, x); int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; ptr4.setDouble(i2 + 12, y); }
/*  993 */      int m = b * 36; Ptr ptr2 = cs; int k = m; ptr2.setDouble(k + 20, x);
/*  994 */     int j = b * 36; Ptr ptr1 = cs; int i = j; ptr1.setDouble(i + 28, y);
/*      */ 
/*      */ 
/*      */     
/*  998 */     if (inside(b, x, y, clip) != 0) {
/*  999 */       if (b > 2) {
/*      */ 
/*      */         
/* 1002 */         if (store != 0) {
/* 1003 */           int i6 = cnt.getInt() * 8; Ptr ptr5 = xout; int i5 = i6; ptr5.setDouble(i5, x);
/* 1004 */           int i4 = cnt.getInt() * 8; Ptr ptr4 = yout; int i3 = i4; ptr4.setDouble(i3, y);
/*      */         } 
/* 1006 */         int i2 = cnt.getInt() + 1; cnt.setInt(i2);
/*      */         return;
/*      */       } 
/*      */       clipPoint(b + 1, x, y, xout, yout, cnt, store, clip, cs);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void closeClip(Ptr xout, Ptr yout, Ptr cnt, int store, Ptr clip, Ptr cs) {
/* 1015 */     iy = new double[1]; ix = new double[1]; iy[0] = 0.0D; ix[0] = 0.0D; ix[0] = 0.0D; iy[0] = 0.0D;
/*      */ 
/*      */     
/* 1018 */     for (b = 0; b <= 3; b++) {
/* 1019 */       int i3 = b * 36; Ptr ptr4 = cs; int i2 = i3; double d4 = ptr4.getDouble(i2 + 12); int i1 = b * 36; Ptr ptr3 = cs; int n = i1; double d3 = ptr3.getDouble(n + 4); int m = b * 36; Ptr ptr2 = cs; int k = m; double d2 = ptr2.getDouble(k + 28); int j = b * 36; Ptr ptr1 = cs; int i = j; double d1 = ptr1.getDouble(i + 20); if (cross(b, d1, d2, d3, d4, clip) != 0) {
/*      */         
/* 1021 */         int i11 = b * 36; Ptr ptr8 = cs; int i10 = i11; double d8 = ptr8.getDouble(i10 + 12); int i9 = b * 36; Ptr ptr7 = cs; int i8 = i9; double d7 = ptr7.getDouble(i8 + 4); int i7 = b * 36; Ptr ptr6 = cs; int i6 = i7; double d6 = ptr6.getDouble(i6 + 28); int i5 = b * 36; Ptr ptr5 = cs; int i4 = i5; double d5 = ptr5.getDouble(i4 + 20); intersect(b, d5, d6, d7, d8, (Ptr)new DoublePtr(ix, 0), (Ptr)new DoublePtr(iy, 0), clip);
/* 1022 */         if (b > 2) {
/*      */ 
/*      */           
/* 1025 */           if (store != 0) {
/* 1026 */             int i16 = cnt.getInt() * 8; Ptr ptr10 = xout; int i15 = i16; ix$308 = ix[0]; ptr10.setDouble(i15, ix$308);
/* 1027 */             int i14 = cnt.getInt() * 8; Ptr ptr9 = yout; int i13 = i14; iy$309 = iy[0]; ptr9.setDouble(i13, iy$309);
/*      */           } 
/* 1029 */           int i12 = cnt.getInt() + 1; cnt.setInt(i12);
/*      */         } else {
/*      */           iy$306 = iy[0];
/*      */           ix$307 = ix[0];
/*      */           clipPoint(b + 1, ix$307, iy$306, xout, yout, cnt, store, clip, cs);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } public static int clipPoly(Ptr x, Ptr y, int n, int store, int toDevice, Ptr xout, Ptr yout, Ptr dd) {
/* 1038 */     MixedPtr mixedPtr1 = MixedPtr.malloc(32), mixedPtr2 = MixedPtr.malloc(144); cnt = new int[1]; cnt[0] = 0; cnt[0] = 0;
/*      */ 
/*      */     
/* 1041 */     for (i = 0; i <= 3; i++)
/* 1042 */       mixedPtr2.setInt(i * 36, 0); 
/* 1043 */     if (toDevice == 0)
/*      */     
/*      */     { 
/*      */       
/* 1047 */       getClipRect((Ptr)mixedPtr1, mixedPtr1.pointerPlus(16), mixedPtr1.pointerPlus(8), mixedPtr1.pointerPlus(24), dd); } else { getClipRectToDevice((Ptr)mixedPtr1, mixedPtr1.pointerPlus(16), mixedPtr1.pointerPlus(8), mixedPtr1.pointerPlus(24), dd); }
/* 1048 */      for (i = 0; i < n; i++) {
/* 1049 */       int i1 = i * 8; Ptr ptr2 = y; int m = i1; double d2 = ptr2.getDouble(m); int k = i * 8; Ptr ptr1 = x; int j = k; double d1 = ptr1.getDouble(j); clipPoint(0, d1, d2, xout, yout, (Ptr)new IntPtr(cnt, 0), store, (Ptr)mixedPtr1, (Ptr)mixedPtr2);
/* 1050 */     }  closeClip(xout, yout, (Ptr)new IntPtr(cnt, 0), store, (Ptr)mixedPtr1, (Ptr)mixedPtr2);
/* 1051 */     return cnt[0];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clipPolygon(int n, Ptr x, Ptr y, Ptr gc, int toDevice, Ptr dd) {
/* 1057 */     vmax = BytePtr.of(0); vmax$offset = 0; yc = BytePtr.of(0); yc$offset = 0; xc = BytePtr.of(0); xc$offset = 0; xc = BytePtr.of(0); xc$offset = 0; yc = BytePtr.of(0); yc$offset = 0;
/* 1058 */     vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1063 */     if (gc.getAlignedInt(1) >>> 24 != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1077 */       yc = BytePtr.of(0); yc$offset = 0; xc = yc; xc$offset = yc$offset;
/* 1078 */       npts = clipPoly(x, y, n, 0, toDevice, xc.pointerPlus(xc$offset), yc.pointerPlus(yc$offset), dd);
/* 1079 */       if (npts > 1) {
/* 1080 */         DoublePtr doublePtr6 = DoublePtr.malloc(npts * 8); xc$offset = 0;
/* 1081 */         DoublePtr doublePtr5 = DoublePtr.malloc(npts * 8); yc$offset = 0;
/* 1082 */         npts = clipPoly(x, y, n, 1, toDevice, doublePtr6.pointerPlus(xc$offset), doublePtr5.pointerPlus(yc$offset), dd);
/* 1083 */         MethodHandle methodHandle = dd.getPointer().getPointer(240).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(npts, doublePtr6.pointerPlus(xc$offset), doublePtr5.pointerPlus(yc$offset), gc, ptr);
/*      */       }  return;
/*      */     }  DoublePtr doublePtr2 = DoublePtr.malloc((n + 1) * 8); xc$offset = 0; DoublePtr doublePtr1 = DoublePtr.malloc((n + 1) * 8); yc$offset = 0; for (i = 0; i < n; i++) {
/*      */       int i9 = i * 8; DoublePtr doublePtr6 = doublePtr2; int i8 = xc$offset + i9, i7 = i * 8; Ptr ptr2 = x; int i6 = i7; double d4 = ptr2.getDouble(i6); doublePtr6.setDouble(i8, d4); int i5 = i * 8; DoublePtr doublePtr5 = doublePtr1; int i4 = yc$offset + i5, i3 = i * 8; Ptr ptr1 = y; int i2 = i3; double d3 = ptr1.getDouble(i2);
/*      */       doublePtr5.setDouble(i4, d3);
/*      */     } 
/*      */     int i1 = n * 8;
/*      */     DoublePtr doublePtr4 = doublePtr2;
/*      */     int m = xc$offset + i1;
/*      */     double d2 = x.getDouble();
/*      */     doublePtr4.setDouble(m, d2);
/*      */     int k = n * 8;
/*      */     DoublePtr doublePtr3 = doublePtr1;
/*      */     int j = yc$offset + k;
/*      */     double d1 = y.getDouble();
/*      */     doublePtr3.setDouble(j, d1);
/* 1099 */     GEPolyline(n + 1, doublePtr2.pointerPlus(xc$offset), doublePtr1.pointerPlus(yc$offset), gc, dd); } public static void GEPolygon(int n, Ptr x, Ptr y, Ptr gc, Ptr dd) { vmaxsave = VoidPtr.toPtr(Memory.vmaxget());
/* 1100 */     double d = gc.getAlignedDouble(2); R_PosInf$295 = Arith.R_PosInf; if (d == R_PosInf$295 || gc.getAlignedDouble(2) < 0.0D)
/* 1101 */       Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/* 1102 */     if (Builtins.__isnan(gc.getAlignedDouble(2)) != 0 || gc.getAlignedInt(6) == -1)
/*      */     {
/* 1104 */       gc.setInt(16777215); } 
/* 1105 */     if (dd.getPointer().getInt(128) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1119 */       clipPolygon(n, x, y, gc, 0, dd);
/*      */       return;
/*      */     } 
/*      */     clipPolygon(n, x, y, gc, 1, dd); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void convertCircle(double x, double y, double r, int numVertices, Ptr xc, Ptr yc) {
/* 1133 */     theta = 0.0D; double d2 = numVertices; theta = 6.283185307179586D / d2;
/* 1134 */     for (i = 0; i < numVertices; i++) {
/* 1135 */       int i4 = i * 8; Ptr ptr4 = xc; int i3 = i4; double d4 = Mathlib.sin(i * theta) * r + x; ptr4.setDouble(i3, d4);
/* 1136 */       int i2 = i * 8; Ptr ptr3 = yc; int i1 = i2; double d3 = Mathlib.cos(i * theta) * r + y; ptr3.setDouble(i1, d3);
/*      */     } 
/* 1138 */     int n = numVertices * 8; Ptr ptr2 = xc; int m = n; ptr2.setDouble(m, x);
/* 1139 */     int k = numVertices * 8; Ptr ptr1 = yc; int j = k; double d1 = y + r; ptr1.setDouble(j, d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int clipCircleCode(double x, double y, double r, int toDevice, Ptr dd) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #10
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #11
/*      */     //   10: iconst_1
/*      */     //   11: newarray double
/*      */     //   13: astore #12
/*      */     //   15: iconst_1
/*      */     //   16: newarray double
/*      */     //   18: astore #13
/*      */     //   20: aload #10
/*      */     //   22: iconst_0
/*      */     //   23: dconst_0
/*      */     //   24: dastore
/*      */     //   25: aload #11
/*      */     //   27: iconst_0
/*      */     //   28: dconst_0
/*      */     //   29: dastore
/*      */     //   30: aload #12
/*      */     //   32: iconst_0
/*      */     //   33: dconst_0
/*      */     //   34: dastore
/*      */     //   35: aload #13
/*      */     //   37: iconst_0
/*      */     //   38: dconst_0
/*      */     //   39: dastore
/*      */     //   40: iload #6
/*      */     //   42: ifne -> 48
/*      */     //   45: goto -> 108
/*      */     //   48: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   51: dup
/*      */     //   52: aload #13
/*      */     //   54: iconst_0
/*      */     //   55: invokespecial <init> : ([DI)V
/*      */     //   58: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   61: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   64: dup
/*      */     //   65: aload #11
/*      */     //   67: iconst_0
/*      */     //   68: invokespecial <init> : ([DI)V
/*      */     //   71: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   74: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   77: dup
/*      */     //   78: aload #12
/*      */     //   80: iconst_0
/*      */     //   81: invokespecial <init> : ([DI)V
/*      */     //   84: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   87: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   90: dup
/*      */     //   91: aload #10
/*      */     //   93: iconst_0
/*      */     //   94: invokespecial <init> : ([DI)V
/*      */     //   97: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   100: aload #7
/*      */     //   102: invokestatic getClipRectToDevice : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   105: goto -> 165
/*      */     //   108: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   111: dup
/*      */     //   112: aload #13
/*      */     //   114: iconst_0
/*      */     //   115: invokespecial <init> : ([DI)V
/*      */     //   118: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   121: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   124: dup
/*      */     //   125: aload #11
/*      */     //   127: iconst_0
/*      */     //   128: invokespecial <init> : ([DI)V
/*      */     //   131: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   134: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   137: dup
/*      */     //   138: aload #12
/*      */     //   140: iconst_0
/*      */     //   141: invokespecial <init> : ([DI)V
/*      */     //   144: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   147: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   150: dup
/*      */     //   151: aload #10
/*      */     //   153: iconst_0
/*      */     //   154: invokespecial <init> : ([DI)V
/*      */     //   157: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   160: aload #7
/*      */     //   162: invokestatic getClipRect : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   165: dload_0
/*      */     //   166: dload #4
/*      */     //   168: dsub
/*      */     //   169: dstore #159
/*      */     //   171: aload #13
/*      */     //   173: iconst_0
/*      */     //   174: daload
/*      */     //   175: dstore #157
/*      */     //   177: dload #159
/*      */     //   179: dload #157
/*      */     //   181: dcmpl
/*      */     //   182: ifgt -> 188
/*      */     //   185: goto -> 264
/*      */     //   188: dload_0
/*      */     //   189: dload #4
/*      */     //   191: dadd
/*      */     //   192: dstore #155
/*      */     //   194: aload #12
/*      */     //   196: iconst_0
/*      */     //   197: daload
/*      */     //   198: dstore #153
/*      */     //   200: dload #155
/*      */     //   202: dload #153
/*      */     //   204: dcmpg
/*      */     //   205: iflt -> 211
/*      */     //   208: goto -> 264
/*      */     //   211: dload_2
/*      */     //   212: dload #4
/*      */     //   214: dsub
/*      */     //   215: dstore #151
/*      */     //   217: aload #11
/*      */     //   219: iconst_0
/*      */     //   220: daload
/*      */     //   221: dstore #149
/*      */     //   223: dload #151
/*      */     //   225: dload #149
/*      */     //   227: dcmpl
/*      */     //   228: ifgt -> 234
/*      */     //   231: goto -> 264
/*      */     //   234: dload_2
/*      */     //   235: dload #4
/*      */     //   237: dadd
/*      */     //   238: dstore #147
/*      */     //   240: aload #10
/*      */     //   242: iconst_0
/*      */     //   243: daload
/*      */     //   244: dstore #145
/*      */     //   246: dload #147
/*      */     //   248: dload #145
/*      */     //   250: dcmpg
/*      */     //   251: iflt -> 257
/*      */     //   254: goto -> 264
/*      */     //   257: bipush #-2
/*      */     //   259: istore #14
/*      */     //   261: goto -> 847
/*      */     //   264: dload #4
/*      */     //   266: dup2
/*      */     //   267: dmul
/*      */     //   268: dstore #8
/*      */     //   270: dload_0
/*      */     //   271: dload #4
/*      */     //   273: dsub
/*      */     //   274: dstore #143
/*      */     //   276: aload #12
/*      */     //   278: iconst_0
/*      */     //   279: daload
/*      */     //   280: dstore #141
/*      */     //   282: dload #143
/*      */     //   284: dload #141
/*      */     //   286: dcmpl
/*      */     //   287: ifgt -> 794
/*      */     //   290: goto -> 293
/*      */     //   293: dload_0
/*      */     //   294: dload #4
/*      */     //   296: dadd
/*      */     //   297: dstore #139
/*      */     //   299: aload #13
/*      */     //   301: iconst_0
/*      */     //   302: daload
/*      */     //   303: dstore #137
/*      */     //   305: dload #139
/*      */     //   307: dload #137
/*      */     //   309: dcmpg
/*      */     //   310: iflt -> 794
/*      */     //   313: goto -> 316
/*      */     //   316: dload_2
/*      */     //   317: dload #4
/*      */     //   319: dsub
/*      */     //   320: dstore #135
/*      */     //   322: aload #10
/*      */     //   324: iconst_0
/*      */     //   325: daload
/*      */     //   326: dstore #133
/*      */     //   328: dload #135
/*      */     //   330: dload #133
/*      */     //   332: dcmpl
/*      */     //   333: ifgt -> 794
/*      */     //   336: goto -> 339
/*      */     //   339: dload_2
/*      */     //   340: dload #4
/*      */     //   342: dadd
/*      */     //   343: dstore #131
/*      */     //   345: aload #11
/*      */     //   347: iconst_0
/*      */     //   348: daload
/*      */     //   349: dstore #129
/*      */     //   351: dload #131
/*      */     //   353: dload #129
/*      */     //   355: dcmpg
/*      */     //   356: iflt -> 794
/*      */     //   359: goto -> 362
/*      */     //   362: aload #13
/*      */     //   364: iconst_0
/*      */     //   365: daload
/*      */     //   366: dstore #127
/*      */     //   368: dload_0
/*      */     //   369: dload #127
/*      */     //   371: dcmpg
/*      */     //   372: iflt -> 378
/*      */     //   375: goto -> 470
/*      */     //   378: aload #11
/*      */     //   380: iconst_0
/*      */     //   381: daload
/*      */     //   382: dstore #125
/*      */     //   384: dload_2
/*      */     //   385: dload #125
/*      */     //   387: dcmpg
/*      */     //   388: iflt -> 394
/*      */     //   391: goto -> 470
/*      */     //   394: aload #13
/*      */     //   396: iconst_0
/*      */     //   397: daload
/*      */     //   398: dstore #123
/*      */     //   400: dload_0
/*      */     //   401: dload #123
/*      */     //   403: dsub
/*      */     //   404: dstore #121
/*      */     //   406: aload #13
/*      */     //   408: iconst_0
/*      */     //   409: daload
/*      */     //   410: dstore #119
/*      */     //   412: dload_0
/*      */     //   413: dload #119
/*      */     //   415: dsub
/*      */     //   416: dstore #117
/*      */     //   418: dload #121
/*      */     //   420: dload #117
/*      */     //   422: dmul
/*      */     //   423: dstore #115
/*      */     //   425: aload #11
/*      */     //   427: iconst_0
/*      */     //   428: daload
/*      */     //   429: dstore #113
/*      */     //   431: dload_2
/*      */     //   432: dload #113
/*      */     //   434: dsub
/*      */     //   435: dstore #111
/*      */     //   437: aload #11
/*      */     //   439: iconst_0
/*      */     //   440: daload
/*      */     //   441: dstore #109
/*      */     //   443: dload_2
/*      */     //   444: dload #109
/*      */     //   446: dsub
/*      */     //   447: dstore #107
/*      */     //   449: dload #111
/*      */     //   451: dload #107
/*      */     //   453: dmul
/*      */     //   454: dstore #105
/*      */     //   456: dload #115
/*      */     //   458: dload #105
/*      */     //   460: dadd
/*      */     //   461: dload #8
/*      */     //   463: dcmpl
/*      */     //   464: ifgt -> 794
/*      */     //   467: goto -> 470
/*      */     //   470: aload #12
/*      */     //   472: iconst_0
/*      */     //   473: daload
/*      */     //   474: dstore #101
/*      */     //   476: dload_0
/*      */     //   477: dload #101
/*      */     //   479: dcmpl
/*      */     //   480: ifgt -> 486
/*      */     //   483: goto -> 578
/*      */     //   486: aload #11
/*      */     //   488: iconst_0
/*      */     //   489: daload
/*      */     //   490: dstore #99
/*      */     //   492: dload_2
/*      */     //   493: dload #99
/*      */     //   495: dcmpg
/*      */     //   496: iflt -> 502
/*      */     //   499: goto -> 578
/*      */     //   502: aload #12
/*      */     //   504: iconst_0
/*      */     //   505: daload
/*      */     //   506: dstore #97
/*      */     //   508: dload_0
/*      */     //   509: dload #97
/*      */     //   511: dsub
/*      */     //   512: dstore #95
/*      */     //   514: aload #12
/*      */     //   516: iconst_0
/*      */     //   517: daload
/*      */     //   518: dstore #93
/*      */     //   520: dload_0
/*      */     //   521: dload #93
/*      */     //   523: dsub
/*      */     //   524: dstore #91
/*      */     //   526: dload #95
/*      */     //   528: dload #91
/*      */     //   530: dmul
/*      */     //   531: dstore #89
/*      */     //   533: aload #11
/*      */     //   535: iconst_0
/*      */     //   536: daload
/*      */     //   537: dstore #87
/*      */     //   539: dload_2
/*      */     //   540: dload #87
/*      */     //   542: dsub
/*      */     //   543: dstore #85
/*      */     //   545: aload #11
/*      */     //   547: iconst_0
/*      */     //   548: daload
/*      */     //   549: dstore #83
/*      */     //   551: dload_2
/*      */     //   552: dload #83
/*      */     //   554: dsub
/*      */     //   555: dstore #81
/*      */     //   557: dload #85
/*      */     //   559: dload #81
/*      */     //   561: dmul
/*      */     //   562: dstore #79
/*      */     //   564: dload #89
/*      */     //   566: dload #79
/*      */     //   568: dadd
/*      */     //   569: dload #8
/*      */     //   571: dcmpl
/*      */     //   572: ifgt -> 794
/*      */     //   575: goto -> 578
/*      */     //   578: aload #13
/*      */     //   580: iconst_0
/*      */     //   581: daload
/*      */     //   582: dstore #75
/*      */     //   584: dload_0
/*      */     //   585: dload #75
/*      */     //   587: dcmpg
/*      */     //   588: iflt -> 594
/*      */     //   591: goto -> 686
/*      */     //   594: aload #10
/*      */     //   596: iconst_0
/*      */     //   597: daload
/*      */     //   598: dstore #73
/*      */     //   600: dload_2
/*      */     //   601: dload #73
/*      */     //   603: dcmpl
/*      */     //   604: ifgt -> 610
/*      */     //   607: goto -> 686
/*      */     //   610: aload #13
/*      */     //   612: iconst_0
/*      */     //   613: daload
/*      */     //   614: dstore #71
/*      */     //   616: dload_0
/*      */     //   617: dload #71
/*      */     //   619: dsub
/*      */     //   620: dstore #69
/*      */     //   622: aload #13
/*      */     //   624: iconst_0
/*      */     //   625: daload
/*      */     //   626: dstore #67
/*      */     //   628: dload_0
/*      */     //   629: dload #67
/*      */     //   631: dsub
/*      */     //   632: dstore #65
/*      */     //   634: dload #69
/*      */     //   636: dload #65
/*      */     //   638: dmul
/*      */     //   639: dstore #63
/*      */     //   641: aload #10
/*      */     //   643: iconst_0
/*      */     //   644: daload
/*      */     //   645: dstore #61
/*      */     //   647: dload_2
/*      */     //   648: dload #61
/*      */     //   650: dsub
/*      */     //   651: dstore #59
/*      */     //   653: aload #10
/*      */     //   655: iconst_0
/*      */     //   656: daload
/*      */     //   657: dstore #57
/*      */     //   659: dload_2
/*      */     //   660: dload #57
/*      */     //   662: dsub
/*      */     //   663: dstore #55
/*      */     //   665: dload #59
/*      */     //   667: dload #55
/*      */     //   669: dmul
/*      */     //   670: dstore #53
/*      */     //   672: dload #63
/*      */     //   674: dload #53
/*      */     //   676: dadd
/*      */     //   677: dload #8
/*      */     //   679: dcmpl
/*      */     //   680: ifgt -> 794
/*      */     //   683: goto -> 686
/*      */     //   686: aload #12
/*      */     //   688: iconst_0
/*      */     //   689: daload
/*      */     //   690: dstore #49
/*      */     //   692: dload_0
/*      */     //   693: dload #49
/*      */     //   695: dcmpl
/*      */     //   696: ifgt -> 702
/*      */     //   699: goto -> 800
/*      */     //   702: aload #10
/*      */     //   704: iconst_0
/*      */     //   705: daload
/*      */     //   706: dstore #47
/*      */     //   708: dload_2
/*      */     //   709: dload #47
/*      */     //   711: dcmpl
/*      */     //   712: ifgt -> 718
/*      */     //   715: goto -> 800
/*      */     //   718: aload #12
/*      */     //   720: iconst_0
/*      */     //   721: daload
/*      */     //   722: dstore #45
/*      */     //   724: dload_0
/*      */     //   725: dload #45
/*      */     //   727: dsub
/*      */     //   728: dstore #43
/*      */     //   730: aload #12
/*      */     //   732: iconst_0
/*      */     //   733: daload
/*      */     //   734: dstore #41
/*      */     //   736: dload_0
/*      */     //   737: dload #41
/*      */     //   739: dsub
/*      */     //   740: dstore #39
/*      */     //   742: dload #43
/*      */     //   744: dload #39
/*      */     //   746: dmul
/*      */     //   747: dstore #37
/*      */     //   749: aload #10
/*      */     //   751: iconst_0
/*      */     //   752: daload
/*      */     //   753: dstore #35
/*      */     //   755: dload_2
/*      */     //   756: dload #35
/*      */     //   758: dsub
/*      */     //   759: dstore #33
/*      */     //   761: aload #10
/*      */     //   763: iconst_0
/*      */     //   764: daload
/*      */     //   765: dstore #31
/*      */     //   767: dload_2
/*      */     //   768: dload #31
/*      */     //   770: dsub
/*      */     //   771: dstore #29
/*      */     //   773: dload #33
/*      */     //   775: dload #29
/*      */     //   777: dmul
/*      */     //   778: dstore #27
/*      */     //   780: dload #37
/*      */     //   782: dload #27
/*      */     //   784: dadd
/*      */     //   785: dload #8
/*      */     //   787: dcmpl
/*      */     //   788: ifgt -> 794
/*      */     //   791: goto -> 800
/*      */     //   794: iconst_m1
/*      */     //   795: istore #14
/*      */     //   797: goto -> 847
/*      */     //   800: dload #4
/*      */     //   802: ldc2_w 6.0
/*      */     //   805: dcmpg
/*      */     //   806: ifle -> 812
/*      */     //   809: goto -> 819
/*      */     //   812: bipush #10
/*      */     //   814: istore #24
/*      */     //   816: goto -> 843
/*      */     //   819: dconst_1
/*      */     //   820: dload #4
/*      */     //   822: ddiv
/*      */     //   823: dstore #22
/*      */     //   825: dconst_1
/*      */     //   826: dload #22
/*      */     //   828: dsub
/*      */     //   829: invokestatic acos : (D)D
/*      */     //   832: dstore #18
/*      */     //   834: ldc2_w 6.283185307179586
/*      */     //   837: dload #18
/*      */     //   839: ddiv
/*      */     //   840: d2i
/*      */     //   841: istore #24
/*      */     //   843: iload #24
/*      */     //   845: istore #14
/*      */     //   847: iload #14
/*      */     //   849: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1156	-> 40
/*      */     //   #1157	-> 48
/*      */     //   #1159	-> 108
/*      */     //   #1162	-> 165
/*      */     //   #1162	-> 188
/*      */     //   #1162	-> 211
/*      */     //   #1162	-> 234
/*      */     //   #1163	-> 257
/*      */     //   #1167	-> 264
/*      */     //   #1168	-> 270
/*      */     //   #1168	-> 293
/*      */     //   #1168	-> 316
/*      */     //   #1168	-> 339
/*      */     //   #1169	-> 362
/*      */     //   #1168	-> 368
/*      */     //   #1169	-> 378
/*      */     //   #1170	-> 394
/*      */     //   #1169	-> 461
/*      */     //   #1171	-> 470
/*      */     //   #1170	-> 476
/*      */     //   #1171	-> 486
/*      */     //   #1172	-> 502
/*      */     //   #1171	-> 569
/*      */     //   #1173	-> 578
/*      */     //   #1172	-> 584
/*      */     //   #1173	-> 594
/*      */     //   #1174	-> 610
/*      */     //   #1173	-> 677
/*      */     //   #1175	-> 686
/*      */     //   #1174	-> 692
/*      */     //   #1175	-> 702
/*      */     //   #1176	-> 718
/*      */     //   #1175	-> 785
/*      */     //   #1177	-> 794
/*      */     //   #1188	-> 800
/*      */     //   #1188	-> 812
/*      */     //   #1188	-> 819
/*      */     //   #1188	-> 843
/*      */     //   #1191	-> 847
/*      */     //   #0	-> 849
/*      */     //   #1191	-> 849
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	850	0	x	D
/*      */     //   0	850	2	y	D
/*      */     //   0	850	4	r	D
/*      */     //   0	850	6	toDevice	I
/*      */     //   0	850	7	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	850	8	distance	D
/*      */     //   0	850	10	ymax	[D
/*      */     //   0	850	11	ymin	[D
/*      */     //   0	850	12	xmax	[D
/*      */     //   0	850	13	xmin	[D
/*      */     //   0	850	14	result	I
/*      */     //   0	850	24	iftmp$290	I
/*      */     //   0	850	31	ymax$289	D
/*      */     //   0	850	35	ymax$288	D
/*      */     //   0	850	41	xmax$287	D
/*      */     //   0	850	45	xmax$286	D
/*      */     //   0	850	47	ymax$285	D
/*      */     //   0	850	49	xmax$284	D
/*      */     //   0	850	57	ymax$283	D
/*      */     //   0	850	61	ymax$282	D
/*      */     //   0	850	67	xmin$281	D
/*      */     //   0	850	71	xmin$280	D
/*      */     //   0	850	73	ymax$279	D
/*      */     //   0	850	75	xmin$278	D
/*      */     //   0	850	83	ymin$277	D
/*      */     //   0	850	87	ymin$276	D
/*      */     //   0	850	93	xmax$275	D
/*      */     //   0	850	97	xmax$274	D
/*      */     //   0	850	99	ymin$273	D
/*      */     //   0	850	101	xmax$272	D
/*      */     //   0	850	109	ymin$271	D
/*      */     //   0	850	113	ymin$270	D
/*      */     //   0	850	119	xmin$269	D
/*      */     //   0	850	123	xmin$268	D
/*      */     //   0	850	125	ymin$267	D
/*      */     //   0	850	127	xmin$266	D
/*      */     //   0	850	129	ymin$265	D
/*      */     //   0	850	133	ymax$264	D
/*      */     //   0	850	137	xmin$263	D
/*      */     //   0	850	141	xmax$262	D
/*      */     //   0	850	145	ymax$261	D
/*      */     //   0	850	149	ymin$260	D
/*      */     //   0	850	153	xmax$259	D
/*      */     //   0	850	157	xmin$258	D
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GECircle(double x, double y, double radius, Ptr gc, Ptr dd) {
/* 1205 */     if (radius > 0.0D) {
/*      */       Ptr ptr2; MethodHandle methodHandle2;
/* 1207 */       double d = gc.getAlignedDouble(2); R_PosInf$255 = Arith.R_PosInf; if (d == R_PosInf$255 || gc.getAlignedDouble(2) < 0.0D)
/* 1208 */         Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/* 1209 */       if (Builtins.__isnan(gc.getAlignedDouble(2)) != 0 || gc.getAlignedInt(6) == -1)
/*      */       {
/* 1211 */         gc.setInt(16777215);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1221 */       int i = dd.getPointer().getInt(128); result = clipCircleCode(x, y, radius, i, dd);
/*      */       
/* 1223 */       switch (result) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -2:
/* 1233 */           methodHandle2 = dd.getPointer().getPointer(204).toMethodHandle(); ptr2 = dd.getPointer(); methodHandle2.invoke(x, y, radius, gc, ptr2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -1:
/*      */           return;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1256 */       if (dd.getPointer().getInt(128) == 0) {
/*      */ 
/*      */ 
/*      */         
/* 1260 */         vmax = VoidPtr.toPtr(Memory.vmaxget());
/* 1261 */         DoublePtr doublePtr2 = DoublePtr.malloc((result + 1) * 8);
/* 1262 */         DoublePtr doublePtr1 = DoublePtr.malloc((result + 1) * 8);
/* 1263 */         convertCircle(x, y, radius, result, (Ptr)doublePtr2, (Ptr)doublePtr1);
/* 1264 */         if (gc.getAlignedInt(1) >>> 24 != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1270 */           ycc = BytePtr.of(0); ycc$offset = 0; xcc = ycc; xcc$offset = ycc$offset;
/* 1271 */           boolean bool2 = (dd.getPointer().getInt(128) != 0) ? false : true; npts = clipPoly((Ptr)doublePtr2, (Ptr)doublePtr1, result, 0, bool2, xcc.pointerPlus(xcc$offset), ycc.pointerPlus(ycc$offset), dd);
/*      */           
/* 1273 */           if (npts <= 1);
/* 1274 */           DoublePtr doublePtr4 = DoublePtr.malloc(npts * 8); xcc$offset = 0;
/* 1275 */           DoublePtr doublePtr3 = DoublePtr.malloc(npts * 8); ycc$offset = 0;
/* 1276 */           boolean bool1 = (dd.getPointer().getInt(128) != 0) ? false : true; npts = clipPoly((Ptr)doublePtr2, (Ptr)doublePtr1, result, 1, bool1, doublePtr4.pointerPlus(xcc$offset), doublePtr3.pointerPlus(ycc$offset), dd);
/*      */           
/* 1278 */           MethodHandle methodHandle = dd.getPointer().getPointer(240).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(npts, doublePtr4.pointerPlus(xcc$offset), doublePtr3.pointerPlus(ycc$offset), gc, ptr);
/*      */         } 
/*      */         GEPolyline(result + 1, (Ptr)doublePtr2, (Ptr)doublePtr1, gc, dd);
/*      */       } 
/*      */       MethodHandle methodHandle1 = dd.getPointer().getPointer(204).toMethodHandle();
/*      */       Ptr ptr1 = dd.getPointer();
/*      */       methodHandle1.invoke(x, y, radius, gc, ptr1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int clipRectCode(double x0, double y0, double x1, double y1, int toDevice, Ptr dd) {
/*      */     // Byte code:
/*      */     //   0: iconst_1
/*      */     //   1: newarray double
/*      */     //   3: astore #10
/*      */     //   5: iconst_1
/*      */     //   6: newarray double
/*      */     //   8: astore #11
/*      */     //   10: iconst_1
/*      */     //   11: newarray double
/*      */     //   13: astore #12
/*      */     //   15: iconst_1
/*      */     //   16: newarray double
/*      */     //   18: astore #13
/*      */     //   20: aload #10
/*      */     //   22: iconst_0
/*      */     //   23: dconst_0
/*      */     //   24: dastore
/*      */     //   25: aload #11
/*      */     //   27: iconst_0
/*      */     //   28: dconst_0
/*      */     //   29: dastore
/*      */     //   30: aload #12
/*      */     //   32: iconst_0
/*      */     //   33: dconst_0
/*      */     //   34: dastore
/*      */     //   35: aload #13
/*      */     //   37: iconst_0
/*      */     //   38: dconst_0
/*      */     //   39: dastore
/*      */     //   40: iload #8
/*      */     //   42: ifne -> 48
/*      */     //   45: goto -> 108
/*      */     //   48: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   51: dup
/*      */     //   52: aload #13
/*      */     //   54: iconst_0
/*      */     //   55: invokespecial <init> : ([DI)V
/*      */     //   58: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   61: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   64: dup
/*      */     //   65: aload #11
/*      */     //   67: iconst_0
/*      */     //   68: invokespecial <init> : ([DI)V
/*      */     //   71: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   74: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   77: dup
/*      */     //   78: aload #12
/*      */     //   80: iconst_0
/*      */     //   81: invokespecial <init> : ([DI)V
/*      */     //   84: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   87: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   90: dup
/*      */     //   91: aload #10
/*      */     //   93: iconst_0
/*      */     //   94: invokespecial <init> : ([DI)V
/*      */     //   97: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   100: aload #9
/*      */     //   102: invokestatic getClipRectToDevice : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   105: goto -> 165
/*      */     //   108: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   111: dup
/*      */     //   112: aload #13
/*      */     //   114: iconst_0
/*      */     //   115: invokespecial <init> : ([DI)V
/*      */     //   118: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   121: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   124: dup
/*      */     //   125: aload #11
/*      */     //   127: iconst_0
/*      */     //   128: invokespecial <init> : ([DI)V
/*      */     //   131: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   134: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   137: dup
/*      */     //   138: aload #12
/*      */     //   140: iconst_0
/*      */     //   141: invokespecial <init> : ([DI)V
/*      */     //   144: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   147: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   150: dup
/*      */     //   151: aload #10
/*      */     //   153: iconst_0
/*      */     //   154: invokespecial <init> : ([DI)V
/*      */     //   157: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   160: aload #9
/*      */     //   162: invokestatic getClipRect : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   165: aload #13
/*      */     //   167: iconst_0
/*      */     //   168: daload
/*      */     //   169: dstore #46
/*      */     //   171: dload_0
/*      */     //   172: dload #46
/*      */     //   174: dcmpg
/*      */     //   175: iflt -> 181
/*      */     //   178: goto -> 198
/*      */     //   181: aload #13
/*      */     //   183: iconst_0
/*      */     //   184: daload
/*      */     //   185: dstore #44
/*      */     //   187: dload #4
/*      */     //   189: dload #44
/*      */     //   191: dcmpg
/*      */     //   192: iflt -> 297
/*      */     //   195: goto -> 198
/*      */     //   198: aload #12
/*      */     //   200: iconst_0
/*      */     //   201: daload
/*      */     //   202: dstore #42
/*      */     //   204: dload_0
/*      */     //   205: dload #42
/*      */     //   207: dcmpl
/*      */     //   208: ifgt -> 214
/*      */     //   211: goto -> 231
/*      */     //   214: aload #12
/*      */     //   216: iconst_0
/*      */     //   217: daload
/*      */     //   218: dstore #40
/*      */     //   220: dload #4
/*      */     //   222: dload #40
/*      */     //   224: dcmpl
/*      */     //   225: ifgt -> 297
/*      */     //   228: goto -> 231
/*      */     //   231: aload #11
/*      */     //   233: iconst_0
/*      */     //   234: daload
/*      */     //   235: dstore #38
/*      */     //   237: dload_2
/*      */     //   238: dload #38
/*      */     //   240: dcmpg
/*      */     //   241: iflt -> 247
/*      */     //   244: goto -> 264
/*      */     //   247: aload #11
/*      */     //   249: iconst_0
/*      */     //   250: daload
/*      */     //   251: dstore #36
/*      */     //   253: dload #6
/*      */     //   255: dload #36
/*      */     //   257: dcmpg
/*      */     //   258: iflt -> 297
/*      */     //   261: goto -> 264
/*      */     //   264: aload #10
/*      */     //   266: iconst_0
/*      */     //   267: daload
/*      */     //   268: dstore #34
/*      */     //   270: dload_2
/*      */     //   271: dload #34
/*      */     //   273: dcmpl
/*      */     //   274: ifgt -> 280
/*      */     //   277: goto -> 303
/*      */     //   280: aload #10
/*      */     //   282: iconst_0
/*      */     //   283: daload
/*      */     //   284: dstore #32
/*      */     //   286: dload #6
/*      */     //   288: dload #32
/*      */     //   290: dcmpl
/*      */     //   291: ifgt -> 297
/*      */     //   294: goto -> 303
/*      */     //   297: iconst_0
/*      */     //   298: istore #14
/*      */     //   300: goto -> 444
/*      */     //   303: aload #13
/*      */     //   305: iconst_0
/*      */     //   306: daload
/*      */     //   307: dstore #30
/*      */     //   309: dload_0
/*      */     //   310: dload #30
/*      */     //   312: dcmpl
/*      */     //   313: ifgt -> 319
/*      */     //   316: goto -> 441
/*      */     //   319: aload #12
/*      */     //   321: iconst_0
/*      */     //   322: daload
/*      */     //   323: dstore #28
/*      */     //   325: dload_0
/*      */     //   326: dload #28
/*      */     //   328: dcmpg
/*      */     //   329: iflt -> 335
/*      */     //   332: goto -> 441
/*      */     //   335: aload #13
/*      */     //   337: iconst_0
/*      */     //   338: daload
/*      */     //   339: dstore #26
/*      */     //   341: dload #4
/*      */     //   343: dload #26
/*      */     //   345: dcmpl
/*      */     //   346: ifgt -> 352
/*      */     //   349: goto -> 441
/*      */     //   352: aload #12
/*      */     //   354: iconst_0
/*      */     //   355: daload
/*      */     //   356: dstore #24
/*      */     //   358: dload #4
/*      */     //   360: dload #24
/*      */     //   362: dcmpg
/*      */     //   363: iflt -> 369
/*      */     //   366: goto -> 441
/*      */     //   369: aload #11
/*      */     //   371: iconst_0
/*      */     //   372: daload
/*      */     //   373: dstore #22
/*      */     //   375: dload_2
/*      */     //   376: dload #22
/*      */     //   378: dcmpl
/*      */     //   379: ifgt -> 385
/*      */     //   382: goto -> 441
/*      */     //   385: aload #10
/*      */     //   387: iconst_0
/*      */     //   388: daload
/*      */     //   389: dstore #20
/*      */     //   391: dload_2
/*      */     //   392: dload #20
/*      */     //   394: dcmpg
/*      */     //   395: iflt -> 401
/*      */     //   398: goto -> 441
/*      */     //   401: aload #11
/*      */     //   403: iconst_0
/*      */     //   404: daload
/*      */     //   405: dstore #18
/*      */     //   407: dload #6
/*      */     //   409: dload #18
/*      */     //   411: dcmpl
/*      */     //   412: ifgt -> 418
/*      */     //   415: goto -> 441
/*      */     //   418: aload #10
/*      */     //   420: iconst_0
/*      */     //   421: daload
/*      */     //   422: dstore #16
/*      */     //   424: dload #6
/*      */     //   426: dload #16
/*      */     //   428: dcmpg
/*      */     //   429: iflt -> 435
/*      */     //   432: goto -> 441
/*      */     //   435: iconst_1
/*      */     //   436: istore #14
/*      */     //   438: goto -> 444
/*      */     //   441: iconst_2
/*      */     //   442: istore #14
/*      */     //   444: iload #14
/*      */     //   446: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1300	-> 40
/*      */     //   #1301	-> 48
/*      */     //   #1303	-> 108
/*      */     //   #1305	-> 165
/*      */     //   #1305	-> 181
/*      */     //   #1305	-> 198
/*      */     //   #1305	-> 214
/*      */     //   #1306	-> 231
/*      */     //   #1305	-> 237
/*      */     //   #1306	-> 247
/*      */     //   #1306	-> 264
/*      */     //   #1306	-> 280
/*      */     //   #1307	-> 297
/*      */     //   #1308	-> 303
/*      */     //   #1308	-> 319
/*      */     //   #1308	-> 335
/*      */     //   #1308	-> 352
/*      */     //   #1309	-> 369
/*      */     //   #1308	-> 375
/*      */     //   #1309	-> 385
/*      */     //   #1309	-> 401
/*      */     //   #1309	-> 418
/*      */     //   #1310	-> 435
/*      */     //   #1312	-> 441
/*      */     //   #1314	-> 444
/*      */     //   #0	-> 446
/*      */     //   #1314	-> 446
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	447	0	x0	D
/*      */     //   0	447	2	y0	D
/*      */     //   0	447	4	x1	D
/*      */     //   0	447	6	y1	D
/*      */     //   0	447	8	toDevice	I
/*      */     //   0	447	9	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	447	10	ymax	[D
/*      */     //   0	447	11	ymin	[D
/*      */     //   0	447	12	xmax	[D
/*      */     //   0	447	13	xmin	[D
/*      */     //   0	447	14	result	I
/*      */     //   0	447	16	ymax$254	D
/*      */     //   0	447	18	ymin$253	D
/*      */     //   0	447	20	ymax$252	D
/*      */     //   0	447	22	ymin$251	D
/*      */     //   0	447	24	xmax$250	D
/*      */     //   0	447	26	xmin$249	D
/*      */     //   0	447	28	xmax$248	D
/*      */     //   0	447	30	xmin$247	D
/*      */     //   0	447	32	ymax$246	D
/*      */     //   0	447	34	ymax$245	D
/*      */     //   0	447	36	ymin$244	D
/*      */     //   0	447	38	ymin$243	D
/*      */     //   0	447	40	xmax$242	D
/*      */     //   0	447	42	xmax$241	D
/*      */     //   0	447	44	xmin$240	D
/*      */     //   0	447	46	xmin$239	D
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GERect(double x0, double y0, double x1, double y1, Ptr gc, Ptr dd) {
/*      */     Ptr ptr1;
/*      */     MethodHandle methodHandle1;
/*      */     Ptr ptr2;
/*      */     MethodHandle methodHandle2;
/* 1330 */     double d = gc.getAlignedDouble(2); R_PosInf$236 = Arith.R_PosInf; if (d == R_PosInf$236 || gc.getAlignedDouble(2) < 0.0D)
/* 1331 */       Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/* 1332 */     if (Builtins.__isnan(gc.getAlignedDouble(2)) != 0 || gc.getAlignedInt(6) == -1)
/*      */     {
/* 1334 */       gc.setInt(16777215);
/*      */     }
/*      */ 
/*      */     
/* 1338 */     int i = dd.getPointer().getInt(128); switch (clipRectCode(x0, y0, x1, y1, i, dd)) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1343 */         methodHandle2 = dd.getPointer().getPointer(248).toMethodHandle(); ptr2 = dd.getPointer(); methodHandle2.invoke(x0, y0, x1, y1, gc, ptr2);
/*      */         break;
/*      */       case 2:
/* 1346 */         if (dd.getPointer().getInt(128) == 0) {
/*      */ 
/*      */           
/* 1349 */           vmax = VoidPtr.toPtr(Memory.vmaxget());
/* 1350 */           DoublePtr doublePtr2 = DoublePtr.malloc(40);
/* 1351 */           DoublePtr doublePtr1 = DoublePtr.malloc(40);
/* 1352 */           doublePtr2.setDouble(0, x0); doublePtr1.setDouble(0, y0);
/* 1353 */           doublePtr2.setDouble(8, x0); doublePtr1.setDouble(8, y1);
/* 1354 */           doublePtr2.setDouble(16, x1); doublePtr1.setDouble(16, y1);
/* 1355 */           doublePtr2.setDouble(24, x1); doublePtr1.setDouble(24, y0);
/* 1356 */           doublePtr2.setDouble(32, x0); doublePtr1.setDouble(32, y0);
/* 1357 */           if (gc.getAlignedInt(1) >>> 24 != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1363 */             ycc = BytePtr.of(0); ycc$offset = 0; xcc = ycc; xcc$offset = ycc$offset;
/* 1364 */             boolean bool2 = (dd.getPointer().getInt(128) != 0) ? false : true; npts = clipPoly((Ptr)doublePtr2, (Ptr)doublePtr1, 4, 0, bool2, xcc.pointerPlus(xcc$offset), ycc.pointerPlus(ycc$offset), dd);
/* 1365 */             if (npts <= 1)
/* 1366 */               break;  DoublePtr doublePtr4 = DoublePtr.malloc(npts * 8); xcc$offset = 0;
/* 1367 */             DoublePtr doublePtr3 = DoublePtr.malloc(npts * 8); ycc$offset = 0;
/* 1368 */             boolean bool1 = (dd.getPointer().getInt(128) != 0) ? false : true; npts = clipPoly((Ptr)doublePtr2, (Ptr)doublePtr1, 4, 1, bool1, doublePtr4.pointerPlus(xcc$offset), doublePtr3.pointerPlus(ycc$offset), dd);
/* 1369 */             MethodHandle methodHandle = dd.getPointer().getPointer(240).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(npts, doublePtr4.pointerPlus(xcc$offset), doublePtr3.pointerPlus(ycc$offset), gc, ptr);
/*      */             break;
/*      */           } 
/*      */           GEPolyline(5, (Ptr)doublePtr2, (Ptr)doublePtr1, gc, dd);
/*      */           break;
/*      */         } 
/*      */         methodHandle1 = dd.getPointer().getPointer(248).toMethodHandle();
/*      */         ptr1 = dd.getPointer();
/*      */         methodHandle1.invoke(x0, y0, x1, y1, gc, ptr1);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEPath(Ptr x, Ptr y, int npoly, Ptr nper, int winding, Ptr gc, Ptr dd) {
/* 1388 */     draw = 0; if (dd.getPointer().getPointer(252).toMethodHandle() != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1394 */       double d = gc.getAlignedDouble(2); R_PosInf$234 = Arith.R_PosInf; if (d == R_PosInf$234 || gc.getAlignedDouble(2) < 0.0D)
/* 1395 */         Error.Rf_error(new BytePtr("'lwd' must be non-negative and finite\000".getBytes(), 0), new Object[0]); 
/* 1396 */       if (Builtins.__isnan(gc.getAlignedDouble(2)) != 0 || gc.getAlignedInt(6) == -1)
/* 1397 */         gc.setInt(16777215); 
/* 1398 */       if (npoly > 0) {
/*      */         
/* 1400 */         draw = 1;
/* 1401 */         for (i = 0; i < npoly; i++) {
/* 1402 */           int k = i * 4; Ptr ptr1 = nper; int j = k; if (ptr1.getInt(j) <= 1) {
/* 1403 */             draw = 0;
/*      */           }
/*      */         } 
/* 1406 */         if (draw == 0) {
/*      */ 
/*      */           
/* 1409 */           Error.Rf_error(new BytePtr("Invalid graphics path\000".getBytes(), 0), new Object[0]);
/*      */           return;
/*      */         } 
/*      */         MethodHandle methodHandle = dd.getPointer().getPointer(252).toMethodHandle();
/*      */         Ptr ptr = dd.getPointer();
/*      */         methodHandle.invoke(x, y, npoly, nper, winding, gc, ptr);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */     Error.Rf_warning(new BytePtr("path rendering is not implemented for this device\000".getBytes(), 0), new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GERaster(Ptr raster, int w, int h, double x, double y, double width, double height, double angle, int interpolate, Ptr gc, Ptr dd) {
/* 1427 */     if (dd.getPointer().getPointer(256).toMethodHandle() != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1437 */       if (width != 0.0D && height != 0.0D) {
/* 1438 */         MethodHandle methodHandle = dd.getPointer().getPointer(256).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(raster, w, h, x, y, width, height, angle, interpolate, gc, ptr);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */     Error.Rf_warning(new BytePtr("raster rendering is not implemented for this device\000".getBytes(), 0), new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP GECap(Ptr dd) {
/* 1451 */     if (dd.getPointer().getPointer(260).toMethodHandle() != null) {
/*      */ 
/*      */ 
/*      */       
/* 1455 */       MethodHandle methodHandle = dd.getPointer().getPointer(260).toMethodHandle(); Ptr ptr = dd.getPointer(); return methodHandle.invoke(ptr);
/*      */     } 
/*      */     Error.Rf_warning(new BytePtr("raster capture is not available for this device\000".getBytes(), 0), new Object[0]);
/*      */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int clipTextCode(double x, double y, Ptr str, int enc, double width, double height, double rot, double hadj, Ptr gc, int toDevice, Ptr dd) {
/* 1480 */     angle = rot * 0.017453292519943295D;
/* 1481 */     theta1 = 1.5707963267948966D - angle;
/*      */ 
/*      */     
/* 1484 */     if (Arith.R_finite(width) == 0) width = GEStrWidth(str, enc, gc, dd); 
/* 1485 */     if (Arith.R_finite(height) == 0) height = GEStrHeight(str, enc, gc, dd);
/*      */ 
/*      */     
/* 1488 */     widthInches = GEfromDeviceWidth(width, 2, dd);
/* 1489 */     heightInches = GEfromDeviceHeight(height, 2, dd);
/* 1490 */     xInches = GEfromDeviceX(x, 2, dd);
/* 1491 */     yInches = GEfromDeviceY(y, 2, dd);
/*      */     
/* 1493 */     length = Mathlib.hypot(widthInches, heightInches);
/* 1494 */     theta2 = Mathlib.atan2(heightInches, widthInches) + angle;
/*      */     
/* 1496 */     double d13 = hadj * widthInches, d12 = Mathlib.cos(angle), d11 = d13 * d12; x = xInches - d11;
/* 1497 */     double d10 = hadj * widthInches, d9 = Mathlib.sin(angle), d8 = d10 * d9; y = yInches - d8;
/* 1498 */     x0 = Mathlib.cos(theta1) * heightInches + x;
/* 1499 */     x1 = x;
/* 1500 */     x2 = Mathlib.cos(theta2) * length + x;
/* 1501 */     x3 = Mathlib.cos(angle) * widthInches + x;
/* 1502 */     y0 = Mathlib.sin(theta1) * heightInches + y;
/* 1503 */     y1 = y;
/* 1504 */     y2 = Mathlib.sin(theta2) * length + y;
/* 1505 */     y3 = Mathlib.sin(angle) * widthInches + y;
/* 1506 */     double d7 = Rmath.Rf_fmin2(x2, x3); left = Rmath.Rf_fmin2(Rmath.Rf_fmin2(x0, x1), d7);
/* 1507 */     double d6 = Rmath.Rf_fmax2(x2, x3); right = Rmath.Rf_fmax2(Rmath.Rf_fmax2(x0, x1), d6);
/* 1508 */     double d5 = Rmath.Rf_fmin2(y2, y3); bottom = Rmath.Rf_fmin2(Rmath.Rf_fmin2(y0, y1), d5);
/* 1509 */     double d4 = Rmath.Rf_fmax2(y2, y3);
/* 1510 */     double d3 = GEtoDeviceY(Rmath.Rf_fmax2(Rmath.Rf_fmax2(y0, y1), d4), 2, dd), d2 = GEtoDeviceX(right, 2, dd), d1 = GEtoDeviceY(bottom, 2, dd); return clipRectCode(GEtoDeviceX(left, 2, dd), d1, d2, d3, toDevice, dd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void clipText(double x, double y, Ptr str, int enc, double width, double height, double rot, double hadj, Ptr gc, int toDevice, Ptr dd) {
/*      */     Ptr ptr1, ptr2;
/* 1521 */     result = clipTextCode(x, y, str, enc, width, height, rot, hadj, gc, toDevice, dd);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1527 */     if (dd.getPointer().getInt(288) != 
/* 1528 */       1 || enc != 1) { iftmp$233 = dd.getPointer().getPointer(272).toMethodHandle(); } else { iftmp$233 = dd.getPointer().getPointer(292).toMethodHandle(); }
/*      */      textfn = iftmp$233;
/* 1530 */     switch (result) {
/*      */ 
/*      */       
/*      */       case 1:
/* 1534 */         ptr2 = dd.getPointer(); textfn.invoke(x, y, str, rot, hadj, gc, ptr2);
/*      */         break;
/*      */       
/*      */       case 2:
/* 1538 */         if (toDevice == 0)
/* 1539 */           break;  ptr1 = dd.getPointer(); textfn.invoke(x, y, str, rot, hadj, gc, ptr1);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int VFontFamilyCode(Ptr fontfamily) {
/* 1611 */     if (Integer.compareUnsigned(Stdlib.strlen(fontfamily), 7) > 0) {
/* 1612 */       j = fontfamily.getByte(7);
/* 1613 */       if (Stdlib.strncmp(fontfamily, (Ptr)new BytePtr("Hershey\000".getBytes(), 0), 7) != 0 || Integer.compareUnsigned(j, 8) > 0)
/* 1614 */       { for (i = 0; Context.get__baseEngine$VFontTable().getInt(i * 12 + 4) != 0; )
/* 1615 */         { Ptr ptr = Context.get__baseEngine$VFontTable().getPointer(i * 12); if (Stdlib.strcmp(fontfamily, ptr) != 0) { i++; continue; }  int k = i + 1; // Byte code: goto -> 139 }  } else { return j + 100; }
/*      */     
/* 1617 */     }  return -1;
/*      */   }
/*      */   
/*      */   public static int VFontFaceCode(int familycode, int fontface) {
/* 1621 */     face = fontface;
/* 1622 */     familycode--;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1627 */     if (fontface != 2) {
/*      */       
/* 1629 */       if (fontface == 3) {
/* 1630 */         face = 2;
/*      */       }
/*      */     } else {
/*      */       face = 3;
/*      */     } 
/* 1635 */     if (Context.get__baseEngine$VFontTable().getInt(familycode * 12 + 4) > face || 
/* 1636 */       Context.get__baseEngine$VFontTable().getInt(familycode * 12 + 8) < face)
/*      */     
/*      */     { 
/*      */       
/* 1640 */       switch (face)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*      */         case 3:
/* 1649 */           face = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1669 */           return face;case 4: if (familycode != 7) { face = 1; return face; }  face = 2; return face; }  Ptr ptr = Context.get__baseEngine$VFontTable().getPointer(familycode * 12); Error.Rf_error(new BytePtr("font face %d not supported for font family '%s'\000".getBytes(), 0), new Object[] { Integer.valueOf(fontface), ptr }); }  return face;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEText(double x, double y, Ptr str, int enc, double xc, double yc, double rot, Ptr gc, Ptr dd) {
/* 1685 */     wc = new int[1]; MixedPtr mixedPtr = MixedPtr.malloc(8); arrayOfInt1 = new int[1]; w = new double[1]; d = new double[1]; h = new double[1]; wc[0] = 0; arrayOfInt1[0] = 0; maxDepth = 0.0D; maxHeight = 0.0D; w[0] = 0.0D; d[0] = 0.0D; h[0] = 0.0D; width = 0.0D; ptr1 = BytePtr.of(0); str$offset = 0; d1 = 0.0D; d2 = 0.0D; vmax = BytePtr.of(0); vmax$offset = 0; cos_rot = 0.0D; sin_rot = 0.0D; yoff = 0.0D; xoff = 0.0D; enc2 = 0; k = 0; i = 0; s = BytePtr.of(0); s$offset = 0; sbuf = BytePtr.of(0); sbuf$offset = 0; noMetricInfo = 0; savevis = 0; vfontcode = VFontFamilyCode(gc.pointerPlus(72));
/* 1686 */     if (vfontcode <= 99) {
/*      */       
/* 1688 */       if (vfontcode < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1694 */         savevis = Defn.R_Visible;
/* 1695 */         noMetricInfo = -1;
/* 1696 */         sbuf = BytePtr.of(0); sbuf$offset = 0;
/* 1697 */         if (!str.isNull() && str.getByte() != (byte)0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1705 */           vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */           
/* 1707 */           if (gc.getAlignedInt(17) == 5) { iftmp$201 = 5; } else { iftmp$201 = enc; }  enc2 = iftmp$201;
/* 1708 */           if (enc2 == 5) {
/*      */             
/* 1710 */             if (dd.getPointer().getInt(300) != 1) {
/* 1711 */               int i2 = dd.getPointer().getInt(300); R_NaInt$203 = Arith.R_NaInt; if (i2 == R_NaInt$203) {
/* 1712 */                 enc = 2;
/* 1713 */                 enc2 = 1;
/*      */               } 
/*      */             } else {
/*      */               enc2 = 1;
/*      */             } 
/*      */           } else {
/*      */             enc2 = (dd.getPointer().getInt(288) != 1) ? 0 : 1;
/*      */           } 
/* 1721 */           x = GEfromDeviceX(x, 2, dd);
/* 1722 */           y = GEfromDeviceY(y, 2, dd);
/*      */           
/* 1724 */           k = 1;
/* 1725 */           for (s = str, s$offset = 0; s.getByte(s$offset) != (byte)0; s = s, s$offset++) {
/* 1726 */             if (s.getByte(s$offset) == (byte)10) k++; 
/*      */           } 
/* 1728 */           BytePtr bytePtr2 = BytePtr.malloc(Stdlib.strlen(str) + 1); sbuf$offset = 0; BytePtr bytePtr1 = bytePtr2; sb$offset = sbuf$offset;
/* 1729 */           i = 0;
/* 1730 */           sin_rot = rot * 0.017453292519943295D;
/* 1731 */           cos_rot = Mathlib.cos(sin_rot);
/* 1732 */           sin_rot = Mathlib.sin(sin_rot);
/* 1733 */           s = str; s$offset = 0; while (true) {
/* 1734 */             if (s.getByte(s$offset) != (byte)10 && s.getByte(s$offset) != (byte)0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1897 */               byte b1 = s.getByte(s$offset); bytePtr1.setByte(sb$offset, b1); bytePtr1 = bytePtr1; sb$offset++; } else { d2 = Arith.R_NaReal; d1 = Arith.R_NaReal; bytePtr1.setByte(sb$offset, (byte)0); ptr1 = Rinternals.Rf_reEnc((BytePtr)bytePtr2.pointerPlus(sbuf$offset), enc, enc2, 2); str$offset = 0; if (k <= 1) { xoff = x; yoff = y; } else { if (Arith.R_finite(xc) == 0) xc = 0.5D;  if (Arith.R_finite(yc) == 0) yc = 0.5D;  double d14 = 1.0D - yc, d13 = (k + -1), d12 = d14 * d13, d11 = i; yoff = d12 - d11; double d10 = gc.getDouble(60) * yoff; double d9 = gc.getDouble(44); double d8 = d10 * d9; double d7 = dd.getPointer().getDouble(112), d6 = d8 * d7; double d5 = gc.getDouble(52); double d4 = d6 * d5; double d3 = dd.getPointer().getDouble(140); yoff = GEfromDeviceHeight(d4 / d3, 2, dd); xoff = -yoff * sin_rot; yoff *= cos_rot; xoff = x + xoff; yoff = y + yoff; }  if (xc == 0.0D && yc == 0.0D) { xleft = xoff; ybottom = yoff; hadj = 0.0D; } else { height = 0.0D; d2 = GEStrWidth(ptr1.pointerPlus(str$offset), enc2, gc, dd); width = GEfromDeviceWidth(d2, 2, dd); if (Arith.R_finite(xc) == 0) xc = 0.5D;  if (Arith.R_finite(yc) != 0) { d1 = GEStrHeight(ptr1.pointerPlus(str$offset), 0, gc, dd); height = GEfromDeviceHeight(d1, 2, dd); } else { if (noMetricInfo < 0) { GEMetricInfo(77, gc, (Ptr)new DoublePtr(h, 0), (Ptr)new DoublePtr(d, 0), (Ptr)new DoublePtr(w, 0), dd); if (h[0] != 0.0D || d[0] != 0.0D || w[0] != 0.0D) { iftmp$204 = 0; } else { iftmp$204 = 1; }  noMetricInfo = iftmp$204; }  if (k <= 1 && noMetricInfo == 0) { maxHeight = 0.0D; maxDepth = 0.0D; ss = ptr1; ss$offset = str$offset; charNum = 0; done = 0; if (enc2 != 5 && !Defn.Rf_strIsASCII((BytePtr)ss.pointerPlus(ss$offset))) if (Defn.mbcslocale == 0 || enc2 != 0) { if (enc2 == 1) throw new UnsatisfiedLinkException("Rf_utf8toucs");  } else { n = Stdlib.strlen(ss.pointerPlus(ss$offset)); mixedPtr.memset(0, 8); throw new UnsatisfiedLinkException("mbrtowc"); }   if (done == 0) for (ss = ptr1, ss$offset = str$offset; ss.getByte(ss$offset) != (byte)0; ss = ss, ss$offset++) { GEMetricInfo(ss.getByte(ss$offset) & 0xFF, gc, (Ptr)new DoublePtr(h, 0), (Ptr)new DoublePtr(d, 0), (Ptr)new DoublePtr(w, 0), dd); h$226 = GEfromDeviceHeight(h[0], 2, dd); h[0] = h$226; d$228 = GEfromDeviceHeight(d[0], 2, dd); d[0] = d$228; boolean bool = (charNum != 0) ? false : true; charNum++; if (!bool) { if (h[0] > maxHeight) maxHeight = h[0];  if (d[0] > maxDepth)
/* 1898 */                             maxDepth = d[0];  } else { maxHeight = h[0]; maxDepth = d[0]; }  }   height = maxHeight - maxDepth; yc = 0.5D; } else { h$208 = GEStrHeight(ptr1.pointerPlus(str$offset), enc2, gc, dd); h[0] = h$208; height = GEfromDeviceHeight(h[0], 2, dd); yc = dd.getPointer().getDouble(72); }  }  if (dd.getPointer().getInt(136) != 2) { if (dd.getPointer().getInt(136) != 1) { hadj = 0.0D; } else { hadj = Mathlib.floor(xc * 2.0D + 0.5D) * 0.5D; if (hadj <= 1.0D) { if (hadj >= 0.0D) { iftmp$232 = hadj; } else { iftmp$232 = 0.0D; }  iftmp$231 = iftmp$232; } else { iftmp$231 = 1.0D; }  hadj = iftmp$231; }  } else { hadj = xc; }  double d8 = (xc - hadj) * width * cos_rot, d7 = xoff - d8, d6 = yc * height * sin_rot; xleft = d7 + d6; double d5 = (xc - hadj) * width * sin_rot, d4 = yoff - d5; double d3 = yc * height * cos_rot; ybottom = d4 - d3; }  xleft = GEtoDeviceX(xleft, 2, dd); ybottom = GEtoDeviceY(ybottom, 2, dd); int i2 = dd.getPointer().getInt(128); clipText(xleft, ybottom, ptr1.pointerPlus(str$offset), enc2, d2, d1, rot, hadj, gc, i2, dd); bytePtr1 = bytePtr2; sb$offset = sbuf$offset; i++; }  if (s.getByte(s$offset) != (byte)0) {
/*      */               s = s; s$offset++; continue;
/*      */             }  break;
/*      */           } 
/* 1902 */         }  Defn.R_Visible = savevis;
/*      */         return;
/*      */       } 
/*      */       byte b = (byte)vfontcode;
/*      */       gc.setByte(79, b);
/*      */       int i1 = gc.getAlignedInt(17), m = VFontFaceCode(vfontcode, i1);
/*      */       gc.setAlignedInt(17, m);
/*      */       throw new UnsatisfiedLinkException("R_GE_VText");
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("R_GE_VText");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP GEXspline(int n, Ptr x, Ptr y, Ptr s, int open, int repEnds, int draw, Ptr gc, Ptr dd) {
/* 1929 */     ypts = (SEXP)BytePtr.of(0).getArray(); xpts = (SEXP)BytePtr.of(0).getArray(); vmaxsave = BytePtr.of(0); vmaxsave$offset = 0; ys = BytePtr.of(0); ys$offset = 0; asp = 0.0D; result = (SEXP)BytePtr.of(0).getArray(); result = Rinternals.R_NilValue;
/*      */     
/* 1931 */     ipr = dd.getPointer(); double d2 = ipr.getDouble(88), d1 = ipr.getDouble(96); asp = d2 / d1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1936 */     vmaxsave = VoidPtr.toPtr(Memory.vmaxget()); vmaxsave$offset = 0;
/* 1937 */     DoublePtr doublePtr = DoublePtr.malloc(n * 8); ys$offset = 0;
/* 1938 */     for (j = 0; j < n; ) { int i2 = j * 8; DoublePtr doublePtr1 = doublePtr; int i1 = ys$offset + i2, m = j * 8; Ptr ptr = y; int k = m; double d = ptr.getDouble(k) * asp; doublePtr1.setDouble(i1, d); j++; }
/* 1939 */      if (open == 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/* 1945 */       compute_closed_spline(n, x, doublePtr.pointerPlus(ys$offset), s, 1.0D, dd);
/* 1946 */       if (draw != 0)
/* 1947 */       { ypoints$145 = Context.get__baseEngine$ypoints(); ypoints$145$offset = Context.get__baseEngine$ypoints$offset(); xpoints$146 = Context.get__baseEngine$xpoints(); xpoints$146$offset = Context.get__baseEngine$xpoints$offset(); GEPolygon(Context.get__baseEngine$npoints(), xpoints$146.pointerPlus(xpoints$146$offset), ypoints$145.pointerPlus(ypoints$145$offset), gc, dd); }  } else { compute_open_spline(n, x, doublePtr.pointerPlus(ys$offset), s, repEnds, 1.0D, dd); if (draw != 0) { ypoints$142 = Context.get__baseEngine$ypoints(); ypoints$142$offset = Context.get__baseEngine$ypoints$offset(); xpoints$143 = Context.get__baseEngine$xpoints(); xpoints$143$offset = Context.get__baseEngine$xpoints$offset(); GEPolyline(Context.get__baseEngine$npoints(), xpoints$143.pointerPlus(xpoints$143$offset), ypoints$142.pointerPlus(ypoints$142$offset), gc, dd); }
/*      */        }
/* 1949 */      if (Context.get__baseEngine$npoints() > 1) {
/*      */ 
/*      */       
/* 1952 */       npoints$149 = Context.get__baseEngine$npoints(); xpts = Rinternals.Rf_allocVector(14, npoints$149); Rinternals.Rf_protect(xpts);
/* 1953 */       npoints$150 = Context.get__baseEngine$npoints(); ypts = Rinternals.Rf_allocVector(14, npoints$150); Rinternals.Rf_protect(ypts);
/* 1954 */       i = 0; while (true) { npoints$157 = Context.get__baseEngine$npoints(); if (i >= npoints$157)
/* 1955 */           break;  Ptr ptr6 = Rinternals2.REAL(xpts); int i6 = i * 8; Ptr ptr5 = ptr6; int i5 = 0 + i6; xpoints$152 = Context.get__baseEngine$xpoints(); xpoints$152$offset = Context.get__baseEngine$xpoints$offset(); int i4 = i * 8; Ptr ptr4 = xpoints$152; int i3 = xpoints$152$offset + i4; double d4 = ptr4.getDouble(i3); ptr5.setDouble(i5, d4);
/* 1956 */         Ptr ptr3 = Rinternals2.REAL(ypts); int i2 = i * 8; Ptr ptr2 = ptr3; int i1 = 0 + i2; ypoints$155 = Context.get__baseEngine$ypoints(); ypoints$155$offset = Context.get__baseEngine$ypoints$offset(); int m = i * 8; Ptr ptr1 = ypoints$155; int k = ypoints$155$offset + m; double d3 = ptr1.getDouble(k) / asp; ptr2.setDouble(i1, d3); i++; }
/*      */       
/* 1958 */       result = Rinternals.Rf_allocVector(19, 2); Rinternals.Rf_protect(result);
/* 1959 */       Rinternals.SET_VECTOR_ELT(result, 0, xpts);
/* 1960 */       Rinternals.SET_VECTOR_ELT(result, 1, ypts);
/*      */     } 
/*      */ 
/*      */     
/* 1964 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEMode(int mode, Ptr dd) {
/* 1980 */     if (baseDevices__.Rf_NoDevices() != 0)
/* 1981 */       Error.Rf_error(new BytePtr("no graphics device is active\000".getBytes(), 0), new Object[0]); 
/* 1982 */     if (dd.getPointer().getPointer(232).toMethodHandle() != null) { MethodHandle methodHandle = dd.getPointer().getPointer(232).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(mode, ptr); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GESymbol(double x, double y, int pch, double size, Ptr gc, Ptr dd) {
/* 2011 */     str = new byte[2]; arrayOfByte1 = new byte[16]; yy = new double[4]; xx = new double[4]; if (Defn.mbcslocale == 0 || gc.getAlignedInt(17) == 5) { iftmp$129 = 255; } else { iftmp$129 = 127; }  maxchar = iftmp$129;
/*      */ 
/*      */     
/* 2014 */     R_NaInt$131 = Arith.R_NaInt; if (pch != R_NaInt$131) {
/* 2015 */       if (pch >= 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2023 */         if (pch <= 31 || Integer.compareUnsigned(pch, maxchar) > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2057 */           if (Integer.compareUnsigned(pch, maxchar) <= 0) {
/*      */             double d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20; int k, m, n; double d21, d22, d23, d24; int i1; double d25, d26, d27, d28, d29; int i2, i3;
/*      */             double d30, d31, d32, d33, d34, d35, d36, d37, d38, d39, d40, d41, d42, d43, d44, d45, d46, d47, d48, d49, d50, d51, d52, d53, d54, d55, d56, d57, d58, d59, d60, d61, d62, d63, d64, d65, d66, d67, d68, d69, d70, d71, d72, d73, d74, d75, d76, d77, d78, d79, d80, d81, d82, d83, d84, d85, d86, d87, d88, d89, d90, d91, d92, d93, d94, d95, d96, d97, d98, d99, d100, d101, d102, d103, d104, d105, d106, d107, d108, d109, d110, d111, d112, d113, d114, d115, d116, d117, d118, d119, d120, d121;
/* 2060 */             GSTR_0 = GEfromDeviceWidth(size, 2, dd);
/*      */             
/* 2062 */             switch (pch) {
/*      */               
/*      */               case 0:
/* 2065 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2066 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2067 */                 gc.setAlignedInt(1, 16777215);
/* 2068 */                 d121 = y + yc; d120 = x + xc; d119 = y - yc; GERect(x - xc, d119, d120, d121, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 1:
/* 2072 */                 xc = size * 0.375D;
/* 2073 */                 gc.setAlignedInt(1, 16777215);
/* 2074 */                 GECircle(x, y, xc, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 2:
/* 2078 */                 xc = GSTR_0 * 0.375D;
/* 2079 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2080 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2081 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2082 */                 xx[0] = x; d118 = y + r; yy[0] = d118;
/* 2083 */                 d117 = x + xc; xx[1] = d117; d116 = y - yc; yy[1] = d116;
/* 2084 */                 d115 = x - xc; xx[2] = d115; d114 = y - yc; yy[2] = d114;
/* 2085 */                 gc.setAlignedInt(1, 16777215);
/* 2086 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 3:
/* 2090 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2091 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2092 */                 d113 = x + xc; GELine(x - xc, y, d113, y, gc, dd);
/* 2093 */                 d112 = y + yc; d111 = y - yc; GELine(x, d111, x, d112, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 4:
/* 2097 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2098 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2099 */                 d110 = y + yc; d109 = x + xc; d108 = y - yc; GELine(x - xc, d108, d109, d110, gc, dd);
/* 2100 */                 d107 = y - yc; d106 = x + xc; d105 = y + yc; GELine(x - xc, d105, d106, d107, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 5:
/* 2104 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2105 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2106 */                 d104 = x - xc; xx[0] = d104; yy[0] = y;
/* 2107 */                 xx[1] = x; d103 = y + yc; yy[1] = d103;
/* 2108 */                 d102 = x + xc; xx[2] = d102; yy[2] = y;
/* 2109 */                 xx[3] = x; d101 = y - yc; yy[3] = d101;
/* 2110 */                 gc.setAlignedInt(1, 16777215);
/* 2111 */                 GEPolygon(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 6:
/* 2115 */                 xc = GSTR_0 * 0.375D;
/* 2116 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2117 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2118 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2119 */                 xx[0] = x; d100 = y - r; yy[0] = d100;
/* 2120 */                 d99 = x + xc; xx[1] = d99; d98 = y + yc; yy[1] = d98;
/* 2121 */                 d97 = x - xc; xx[2] = d97; d96 = y + yc; yy[2] = d96;
/* 2122 */                 gc.setAlignedInt(1, 16777215);
/* 2123 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 7:
/* 2127 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2128 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2129 */                 gc.setAlignedInt(1, 16777215);
/* 2130 */                 d95 = y + yc; d94 = x + xc; d93 = y - yc; GERect(x - xc, d93, d94, d95, gc, dd);
/* 2131 */                 d92 = y + yc; d91 = x + xc; d90 = y - yc; GELine(x - xc, d90, d91, d92, gc, dd);
/* 2132 */                 d89 = y - yc; d88 = x + xc; d87 = y + yc; GELine(x - xc, d87, d88, d89, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 8:
/* 2136 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2137 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2138 */                 d86 = y + yc; d85 = x + xc; d84 = y - yc; GELine(x - xc, d84, d85, d86, gc, dd);
/* 2139 */                 d83 = y - yc; d82 = x + xc; d81 = y + yc; GELine(x - xc, d81, d82, d83, gc, dd);
/* 2140 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2141 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2142 */                 d80 = x + xc; GELine(x - xc, y, d80, y, gc, dd);
/* 2143 */                 d79 = y + yc; d78 = y - yc; GELine(x, d78, x, d79, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 9:
/* 2147 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2148 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.5303300858899107D, 2, dd);
/* 2149 */                 d77 = x + xc; GELine(x - xc, y, d77, y, gc, dd);
/* 2150 */                 d76 = y + yc; d75 = y - yc; GELine(x, d75, x, d76, gc, dd);
/* 2151 */                 d74 = x - xc; xx[0] = d74; yy[0] = y;
/* 2152 */                 xx[1] = x; d73 = y + yc; yy[1] = d73;
/* 2153 */                 d72 = x + xc; xx[2] = d72; yy[2] = y;
/* 2154 */                 xx[3] = x; d71 = y - yc; yy[3] = d71;
/* 2155 */                 gc.setAlignedInt(1, 16777215);
/* 2156 */                 GEPolygon(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 10:
/* 2160 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2161 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2162 */                 gc.setAlignedInt(1, 16777215);
/* 2163 */                 GECircle(x, y, xc, gc, dd);
/* 2164 */                 d70 = x + xc; GELine(x - xc, y, d70, y, gc, dd);
/* 2165 */                 d69 = y + yc; d68 = y - yc; GELine(x, d68, x, d69, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 11:
/* 2169 */                 xc = GSTR_0 * 0.375D;
/* 2170 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2171 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2172 */                 yc = (yc + r) * 0.5D;
/* 2173 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2174 */                 xx[0] = x; d67 = y - r; yy[0] = d67;
/* 2175 */                 d66 = x + xc; xx[1] = d66; d65 = y + yc; yy[1] = d65;
/* 2176 */                 d64 = x - xc; xx[2] = d64; d63 = y + yc; yy[2] = d63;
/* 2177 */                 gc.setAlignedInt(1, 16777215);
/* 2178 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/* 2179 */                 xx[0] = x; d62 = y + r; yy[0] = d62;
/* 2180 */                 d61 = x + xc; xx[1] = d61; d60 = y - yc; yy[1] = d60;
/* 2181 */                 d59 = x - xc; xx[2] = d59; d58 = y - yc; yy[2] = d58;
/* 2182 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 12:
/* 2186 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2187 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2188 */                 d57 = x + xc; GELine(x - xc, y, d57, y, gc, dd);
/* 2189 */                 d56 = y + yc; d55 = y - yc; GELine(x, d55, x, d56, gc, dd);
/* 2190 */                 gc.setAlignedInt(1, 16777215);
/* 2191 */                 d54 = y + yc; d53 = x + xc; d52 = y - yc; GERect(x - xc, d52, d53, d54, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 13:
/* 2195 */                 xc = size * 0.375D;
/* 2196 */                 gc.setAlignedInt(1, 16777215);
/* 2197 */                 GECircle(x, y, xc, gc, dd);
/* 2198 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2199 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2200 */                 d51 = y + yc; d50 = x + xc; d49 = y - yc; GELine(x - xc, d49, d50, d51, gc, dd);
/* 2201 */                 d48 = y - yc; d47 = x + xc; d46 = y + yc; GELine(x - xc, d46, d47, d48, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 14:
/* 2205 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2206 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2207 */                 xx[0] = x; d45 = y + yc; yy[0] = d45;
/* 2208 */                 d44 = x + xc; xx[1] = d44; d43 = y - yc; yy[1] = d43;
/* 2209 */                 d42 = x - xc; xx[2] = d42; d41 = y - yc; yy[2] = d41;
/* 2210 */                 gc.setAlignedInt(1, 16777215);
/* 2211 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/* 2212 */                 d40 = y + yc; d39 = x + xc; d38 = y - yc; GERect(x - xc, d38, d39, d40, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 15:
/* 2216 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2217 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2218 */                 d37 = x - xc; xx[0] = d37; d36 = y - yc; yy[0] = d36;
/* 2219 */                 d35 = x + xc; xx[1] = d35; d34 = y - yc; yy[1] = d34;
/* 2220 */                 d33 = x + xc; xx[2] = d33; d32 = y + yc; yy[2] = d32;
/* 2221 */                 d31 = x - xc; xx[3] = d31; d30 = y + yc; yy[3] = d30;
/* 2222 */                 i3 = gc.getInt(); gc.setAlignedInt(1, i3);
/* 2223 */                 gc.setInt(16777215);
/* 2224 */                 GEPolygon(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 16:
/* 2228 */                 xc = size * 0.375D;
/* 2229 */                 i2 = gc.getInt(); gc.setAlignedInt(1, i2);
/* 2230 */                 gc.setInt(16777215);
/* 2231 */                 GECircle(x, y, xc, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 17:
/* 2235 */                 xc = GSTR_0 * 0.375D;
/* 2236 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2237 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2238 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2239 */                 xx[0] = x; d29 = y + r; yy[0] = d29;
/* 2240 */                 d28 = x + xc; xx[1] = d28; d27 = y - yc; yy[1] = d27;
/* 2241 */                 d26 = x - xc; xx[2] = d26; d25 = y - yc; yy[2] = d25;
/* 2242 */                 i1 = gc.getInt(); gc.setAlignedInt(1, i1);
/* 2243 */                 gc.setInt(16777215);
/* 2244 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 18:
/* 2248 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.375D, 2, dd);
/* 2249 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.375D, 2, dd);
/* 2250 */                 d24 = x - xc; xx[0] = d24; yy[0] = y;
/* 2251 */                 xx[1] = x; d23 = y + yc; yy[1] = d23;
/* 2252 */                 d22 = x + xc; xx[2] = d22; yy[2] = y;
/* 2253 */                 xx[3] = x; d21 = y - yc; yy[3] = d21;
/* 2254 */                 n = gc.getInt(); gc.setAlignedInt(1, n);
/* 2255 */                 gc.setInt(16777215);
/* 2256 */                 GEPolygon(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 19:
/* 2260 */                 xc = size * 0.375D;
/* 2261 */                 m = gc.getInt(); gc.setAlignedInt(1, m);
/* 2262 */                 GECircle(x, y, xc, gc, dd);
/*      */                 return;
/*      */ 
/*      */               
/*      */               case 20:
/* 2267 */                 xc = size * 0.25D;
/* 2268 */                 k = gc.getInt(); gc.setAlignedInt(1, k);
/* 2269 */                 GECircle(x, y, xc, gc, dd);
/*      */                 return;
/*      */ 
/*      */               
/*      */               case 21:
/* 2274 */                 xc = size * 0.375D;
/* 2275 */                 GECircle(x, y, xc, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 22:
/* 2279 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.33233509704478426D, 2, dd);
/* 2280 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.33233509704478426D, 2, dd);
/* 2281 */                 d20 = y + yc; d19 = x + xc; d18 = y - yc; GERect(x - xc, d18, d19, d20, gc, dd);
/*      */                 return;
/*      */               
/*      */               case 23:
/* 2285 */                 xc = GEtoDeviceWidth(GSTR_0 * 0.46999280149331263D, 2, dd);
/* 2286 */                 yc = GEtoDeviceHeight(GSTR_0 * 0.46999280149331263D, 2, dd);
/* 2287 */                 xx[0] = x; d17 = y - yc; yy[0] = d17;
/* 2288 */                 d16 = x + xc; xx[1] = d16; yy[1] = y;
/* 2289 */                 xx[2] = x; d15 = y + yc; yy[2] = d15;
/* 2290 */                 d14 = x - xc; xx[3] = d14; yy[3] = y;
/* 2291 */                 GEPolygon(4, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 24:
/* 2295 */                 xc = GSTR_0 * 0.375D;
/* 2296 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2297 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2298 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2299 */                 xx[0] = x; d13 = y + r; yy[0] = d13;
/* 2300 */                 d12 = x + xc; xx[1] = d12; d11 = y - yc; yy[1] = d11;
/* 2301 */                 d10 = x - xc; xx[2] = d10; d9 = y - yc; yy[2] = d9;
/* 2302 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */               
/*      */               case 25:
/* 2306 */                 xc = GSTR_0 * 0.375D;
/* 2307 */                 r = GEtoDeviceHeight(xc * 1.555120301556214D, 2, dd);
/* 2308 */                 yc = GEtoDeviceHeight(xc * 0.777560150778107D, 2, dd);
/* 2309 */                 xc = GEtoDeviceWidth(xc * 1.3467736870885985D, 2, dd);
/* 2310 */                 xx[0] = x; d8 = y - r; yy[0] = d8;
/* 2311 */                 d7 = x + xc; xx[1] = d7; d6 = y + yc; yy[1] = d6;
/* 2312 */                 d5 = x - xc; xx[2] = d5; d4 = y + yc; yy[2] = d4;
/* 2313 */                 GEPolygon(3, (Ptr)new DoublePtr(xx, 0), (Ptr)new DoublePtr(yy, 0), gc, dd);
/*      */                 return;
/*      */             } 
/* 2316 */             Error.Rf_warning(new BytePtr("unimplemented pch value '%d'\000".getBytes(), 0), new Object[] { Integer.valueOf(pch) });
/*      */             return;
/*      */           } 
/*      */           Error.Rf_warning(new BytePtr("pch value '%d' is invalid in this locale\000".getBytes(), 0), new Object[] { Integer.valueOf(pch) });
/*      */           return;
/*      */         } 
/*      */         if (pch != 46) {
/*      */           byte b = (byte)pch;
/*      */           str[0] = b;
/*      */           str[1] = (byte)0;
/*      */           R_NaReal$135 = Arith.R_NaReal;
/*      */           R_NaReal$136 = Arith.R_NaReal;
/*      */           if (gc.getAlignedInt(17) != 5) {
/*      */             iftmp$137 = 0;
/*      */           } else {
/*      */             iftmp$137 = 5;
/*      */           } 
/*      */           GEText(x, y, (Ptr)new BytePtr(str, 0), iftmp$137, R_NaReal$136, R_NaReal$135, 0.0D, gc, dd);
/*      */           return;
/*      */         } 
/*      */         int j = gc.getInt();
/*      */         gc.setAlignedInt(1, j);
/*      */         gc.setInt(16777215);
/*      */         xc = Math.abs(GEtoDeviceWidth(0.005D, 2, dd)) * size;
/*      */         yc = Math.abs(GEtoDeviceHeight(0.005D, 2, dd)) * size;
/*      */         if (size > 0.0D && xc < 0.5D) {
/*      */           xc = 0.5D;
/*      */         }
/*      */         if (size > 0.0D && yc < 0.5D) {
/*      */           yc = 0.5D;
/*      */         }
/*      */         double d3 = y + yc, d2 = x + xc, d1 = y - yc;
/*      */         GERect(x - xc, d1, d2, d3, gc, dd);
/*      */         return;
/*      */       } 
/*      */       if (gc.getAlignedInt(17) == 5) {
/*      */         Error.Rf_error(new BytePtr("use of negative pch with symbol font is invalid\000".getBytes(), 0), new Object[0]);
/*      */       }
/*      */       int i = -pch;
/*      */       throw new UnsatisfiedLinkException("Rf_ucstoutf8");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEPretty(Ptr lo, Ptr up, Ptr ndiv) {
/*      */     // Byte code:
/*      */     //   0: iconst_2
/*      */     //   1: newarray double
/*      */     //   3: astore_3
/*      */     //   4: iconst_1
/*      */     //   5: newarray double
/*      */     //   7: astore #4
/*      */     //   9: iconst_1
/*      */     //   10: newarray double
/*      */     //   12: astore #5
/*      */     //   14: aload_3
/*      */     //   15: iconst_0
/*      */     //   16: ldc2_w 0.8
/*      */     //   19: dastore
/*      */     //   20: aload_3
/*      */     //   21: iconst_1
/*      */     //   22: ldc2_w 1.7
/*      */     //   25: dastore
/*      */     //   26: aload_2
/*      */     //   27: invokeinterface getInt : ()I
/*      */     //   32: ifle -> 38
/*      */     //   35: goto -> 75
/*      */     //   38: aload_2
/*      */     //   39: invokeinterface getInt : ()I
/*      */     //   44: istore #95
/*      */     //   46: new org/renjin/gcc/runtime/BytePtr
/*      */     //   49: dup
/*      */     //   50: ldc_w 'invalid axis extents [GEPretty(.,.,n=%d) '
/*      */     //   53: invokevirtual getBytes : ()[B
/*      */     //   56: iconst_0
/*      */     //   57: invokespecial <init> : ([BI)V
/*      */     //   60: iconst_1
/*      */     //   61: anewarray java/lang/Object
/*      */     //   64: dup
/*      */     //   65: iconst_0
/*      */     //   66: iload #95
/*      */     //   68: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   71: aastore
/*      */     //   72: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   75: aload_0
/*      */     //   76: invokeinterface getDouble : ()D
/*      */     //   81: dstore #93
/*      */     //   83: getstatic org/renjin/gnur/api/Arith.R_PosInf : D
/*      */     //   86: dstore #91
/*      */     //   88: dload #93
/*      */     //   90: dload #91
/*      */     //   92: dcmpl
/*      */     //   93: ifeq -> 201
/*      */     //   96: goto -> 99
/*      */     //   99: aload_1
/*      */     //   100: invokeinterface getDouble : ()D
/*      */     //   105: dstore #89
/*      */     //   107: getstatic org/renjin/gnur/api/Arith.R_PosInf : D
/*      */     //   110: dstore #87
/*      */     //   112: dload #89
/*      */     //   114: dload #87
/*      */     //   116: dcmpl
/*      */     //   117: ifeq -> 201
/*      */     //   120: goto -> 123
/*      */     //   123: aload_0
/*      */     //   124: invokeinterface getDouble : ()D
/*      */     //   129: dstore #85
/*      */     //   131: getstatic org/renjin/gnur/api/Arith.R_NegInf : D
/*      */     //   134: dstore #83
/*      */     //   136: dload #85
/*      */     //   138: dload #83
/*      */     //   140: dcmpl
/*      */     //   141: ifeq -> 201
/*      */     //   144: goto -> 147
/*      */     //   147: aload_1
/*      */     //   148: invokeinterface getDouble : ()D
/*      */     //   153: dstore #81
/*      */     //   155: getstatic org/renjin/gnur/api/Arith.R_NegInf : D
/*      */     //   158: dstore #79
/*      */     //   160: dload #81
/*      */     //   162: dload #79
/*      */     //   164: dcmpl
/*      */     //   165: ifeq -> 201
/*      */     //   168: goto -> 171
/*      */     //   171: aload_1
/*      */     //   172: invokeinterface getDouble : ()D
/*      */     //   177: dstore #77
/*      */     //   179: aload_0
/*      */     //   180: invokeinterface getDouble : ()D
/*      */     //   185: dstore #75
/*      */     //   187: dload #77
/*      */     //   189: dload #75
/*      */     //   191: dsub
/*      */     //   192: invokestatic R_finite : (D)I
/*      */     //   195: ifeq -> 201
/*      */     //   198: goto -> 270
/*      */     //   201: aload_2
/*      */     //   202: invokeinterface getInt : ()I
/*      */     //   207: istore #71
/*      */     //   209: aload_1
/*      */     //   210: invokeinterface getDouble : ()D
/*      */     //   215: dstore #69
/*      */     //   217: aload_0
/*      */     //   218: invokeinterface getDouble : ()D
/*      */     //   223: dstore #67
/*      */     //   225: new org/renjin/gcc/runtime/BytePtr
/*      */     //   228: dup
/*      */     //   229: ldc_w 'infinite axis extents [GEPretty(%g,%g,%d)] '
/*      */     //   232: invokevirtual getBytes : ()[B
/*      */     //   235: iconst_0
/*      */     //   236: invokespecial <init> : ([BI)V
/*      */     //   239: iconst_3
/*      */     //   240: anewarray java/lang/Object
/*      */     //   243: dup
/*      */     //   244: iconst_0
/*      */     //   245: dload #67
/*      */     //   247: invokestatic valueOf : (D)Ljava/lang/Double;
/*      */     //   250: aastore
/*      */     //   251: dup
/*      */     //   252: iconst_1
/*      */     //   253: dload #69
/*      */     //   255: invokestatic valueOf : (D)Ljava/lang/Double;
/*      */     //   258: aastore
/*      */     //   259: dup
/*      */     //   260: iconst_2
/*      */     //   261: iload #71
/*      */     //   263: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   266: aastore
/*      */     //   267: invokestatic Rf_error : (Lorg/renjin/gcc/runtime/BytePtr;[Ljava/lang/Object;)V
/*      */     //   270: aload_0
/*      */     //   271: invokeinterface getDouble : ()D
/*      */     //   276: dstore #65
/*      */     //   278: aload #5
/*      */     //   280: iconst_0
/*      */     //   281: dload #65
/*      */     //   283: dastore
/*      */     //   284: aload_1
/*      */     //   285: invokeinterface getDouble : ()D
/*      */     //   290: dstore #63
/*      */     //   292: aload #4
/*      */     //   294: iconst_0
/*      */     //   295: dload #63
/*      */     //   297: dastore
/*      */     //   298: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   301: dup
/*      */     //   302: aload #5
/*      */     //   304: iconst_0
/*      */     //   305: invokespecial <init> : ([DI)V
/*      */     //   308: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   311: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   314: dup
/*      */     //   315: aload #4
/*      */     //   317: iconst_0
/*      */     //   318: invokespecial <init> : ([DI)V
/*      */     //   321: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   324: aload_2
/*      */     //   325: iconst_1
/*      */     //   326: ldc2_w 0.25
/*      */     //   329: new org/renjin/gcc/runtime/DoublePtr
/*      */     //   332: dup
/*      */     //   333: aload_3
/*      */     //   334: iconst_0
/*      */     //   335: invokespecial <init> : ([DI)V
/*      */     //   338: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   341: iconst_2
/*      */     //   342: iconst_0
/*      */     //   343: invokestatic R_pretty : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;IDLorg/renjin/gcc/runtime/Ptr;II)D
/*      */     //   346: dstore #6
/*      */     //   348: aload #5
/*      */     //   350: iconst_0
/*      */     //   351: daload
/*      */     //   352: dconst_1
/*      */     //   353: dadd
/*      */     //   354: dstore #59
/*      */     //   356: aload #4
/*      */     //   358: iconst_0
/*      */     //   359: daload
/*      */     //   360: dstore #57
/*      */     //   362: dload #59
/*      */     //   364: dload #57
/*      */     //   366: dcmpg
/*      */     //   367: ifle -> 373
/*      */     //   370: goto -> 540
/*      */     //   373: aload #5
/*      */     //   375: iconst_0
/*      */     //   376: daload
/*      */     //   377: dload #6
/*      */     //   379: dmul
/*      */     //   380: dstore #53
/*      */     //   382: aload_0
/*      */     //   383: invokeinterface getDouble : ()D
/*      */     //   388: dstore #51
/*      */     //   390: dload #6
/*      */     //   392: ldc2_w 1.0E-7
/*      */     //   395: dmul
/*      */     //   396: dstore #49
/*      */     //   398: dload #51
/*      */     //   400: dload #49
/*      */     //   402: dsub
/*      */     //   403: dstore #47
/*      */     //   405: dload #53
/*      */     //   407: dload #47
/*      */     //   409: dcmpg
/*      */     //   410: iflt -> 416
/*      */     //   413: goto -> 430
/*      */     //   416: aload #5
/*      */     //   418: iconst_0
/*      */     //   419: daload
/*      */     //   420: dconst_1
/*      */     //   421: dadd
/*      */     //   422: dstore #43
/*      */     //   424: aload #5
/*      */     //   426: iconst_0
/*      */     //   427: dload #43
/*      */     //   429: dastore
/*      */     //   430: aload #5
/*      */     //   432: iconst_0
/*      */     //   433: daload
/*      */     //   434: dconst_1
/*      */     //   435: dadd
/*      */     //   436: dstore #39
/*      */     //   438: aload #4
/*      */     //   440: iconst_0
/*      */     //   441: daload
/*      */     //   442: dstore #37
/*      */     //   444: dload #39
/*      */     //   446: dload #37
/*      */     //   448: dcmpg
/*      */     //   449: iflt -> 455
/*      */     //   452: goto -> 512
/*      */     //   455: aload #4
/*      */     //   457: iconst_0
/*      */     //   458: daload
/*      */     //   459: dload #6
/*      */     //   461: dmul
/*      */     //   462: dstore #33
/*      */     //   464: aload_1
/*      */     //   465: invokeinterface getDouble : ()D
/*      */     //   470: dstore #31
/*      */     //   472: dload #6
/*      */     //   474: ldc2_w 1.0E-7
/*      */     //   477: dmul
/*      */     //   478: dstore #29
/*      */     //   480: dload #31
/*      */     //   482: dload #29
/*      */     //   484: dadd
/*      */     //   485: dstore #27
/*      */     //   487: dload #33
/*      */     //   489: dload #27
/*      */     //   491: dcmpl
/*      */     //   492: ifgt -> 498
/*      */     //   495: goto -> 512
/*      */     //   498: aload #4
/*      */     //   500: iconst_0
/*      */     //   501: daload
/*      */     //   502: dconst_1
/*      */     //   503: dsub
/*      */     //   504: dstore #23
/*      */     //   506: aload #4
/*      */     //   508: iconst_0
/*      */     //   509: dload #23
/*      */     //   511: dastore
/*      */     //   512: aload #4
/*      */     //   514: iconst_0
/*      */     //   515: daload
/*      */     //   516: dstore #21
/*      */     //   518: aload #5
/*      */     //   520: iconst_0
/*      */     //   521: daload
/*      */     //   522: dstore #19
/*      */     //   524: dload #21
/*      */     //   526: dload #19
/*      */     //   528: dsub
/*      */     //   529: d2i
/*      */     //   530: istore #16
/*      */     //   532: aload_2
/*      */     //   533: iload #16
/*      */     //   535: invokeinterface setInt : (I)V
/*      */     //   540: aload #5
/*      */     //   542: iconst_0
/*      */     //   543: daload
/*      */     //   544: dload #6
/*      */     //   546: dmul
/*      */     //   547: dstore #12
/*      */     //   549: aload_0
/*      */     //   550: dload #12
/*      */     //   552: invokeinterface setDouble : (D)V
/*      */     //   557: aload #4
/*      */     //   559: iconst_0
/*      */     //   560: daload
/*      */     //   561: dload #6
/*      */     //   563: dmul
/*      */     //   564: dstore #8
/*      */     //   566: aload_1
/*      */     //   567: dload #8
/*      */     //   569: invokeinterface setDouble : (D)V
/*      */     //   574: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2333	-> 14
/*      */     //   #2338	-> 26
/*      */     //   #2339	-> 38
/*      */     //   #2340	-> 75
/*      */     //   #2340	-> 99
/*      */     //   #2341	-> 123
/*      */     //   #2340	-> 136
/*      */     //   #2341	-> 147
/*      */     //   #2342	-> 171
/*      */     //   #2341	-> 195
/*      */     //   #2343	-> 201
/*      */     //   #2347	-> 270
/*      */     //   #2351	-> 298
/*      */     //   #2360	-> 348
/*      */     //   #2361	-> 373
/*      */     //   #2362	-> 416
/*      */     //   #2363	-> 430
/*      */     //   #2363	-> 455
/*      */     //   #2364	-> 498
/*      */     //   #2365	-> 512
/*      */     //   #2367	-> 540
/*      */     //   #2368	-> 557
/*      */     //   #0	-> 574
/*      */     //   #2384	-> 574
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	575	0	lo	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	575	1	up	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	575	2	ndiv	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	575	3	high_u_fact	[D
/*      */     //   0	575	4	nu	[D
/*      */     //   0	575	5	ns	[D
/*      */     //   0	575	6	unit	D
/*      */     //   0	575	10	nu$128	D
/*      */     //   0	575	14	ns$127	D
/*      */     //   0	575	19	ns$126	D
/*      */     //   0	575	21	nu$125	D
/*      */     //   0	575	23	nu$124	D
/*      */     //   0	575	25	nu$123	D
/*      */     //   0	575	35	nu$122	D
/*      */     //   0	575	37	nu$121	D
/*      */     //   0	575	41	ns$120	D
/*      */     //   0	575	43	ns$119	D
/*      */     //   0	575	45	ns$118	D
/*      */     //   0	575	55	ns$117	D
/*      */     //   0	575	57	nu$116	D
/*      */     //   0	575	61	ns$115	D
/*      */     //   0	575	63	nu$114	D
/*      */     //   0	575	65	ns$113	D
/*      */     //   0	575	79	R_NegInf$112	D
/*      */     //   0	575	83	R_NegInf$111	D
/*      */     //   0	575	87	R_PosInf$110	D
/*      */     //   0	575	91	R_PosInf$109	D
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEMetricInfo(int c, Ptr gc, Ptr ascent, Ptr descent, Ptr width, Ptr dd) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: bipush #72
/*      */     //   3: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   8: invokestatic VFontFamilyCode : (Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   11: ifge -> 17
/*      */     //   14: goto -> 42
/*      */     //   17: aload_2
/*      */     //   18: dconst_0
/*      */     //   19: invokeinterface setDouble : (D)V
/*      */     //   24: aload_3
/*      */     //   25: dconst_0
/*      */     //   26: invokeinterface setDouble : (D)V
/*      */     //   31: aload #4
/*      */     //   33: dconst_0
/*      */     //   34: invokeinterface setDouble : (D)V
/*      */     //   39: goto -> 451
/*      */     //   42: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_dd : Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   45: astore #53
/*      */     //   47: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_dd$offset : I
/*      */     //   50: istore #54
/*      */     //   52: aload #5
/*      */     //   54: aload #53
/*      */     //   56: iload #54
/*      */     //   58: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   63: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   66: ifne -> 72
/*      */     //   69: goto -> 272
/*      */     //   72: aload #5
/*      */     //   74: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   79: sipush #212
/*      */     //   82: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   87: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   92: astore #50
/*      */     //   94: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_close : Ljava/lang/invoke/MethodHandle;
/*      */     //   97: astore #49
/*      */     //   99: aload #50
/*      */     //   101: aload #49
/*      */     //   103: if_acmpeq -> 109
/*      */     //   106: goto -> 272
/*      */     //   109: iload_0
/*      */     //   110: invokestatic abs : (I)I
/*      */     //   113: bipush #77
/*      */     //   115: if_icmpeq -> 121
/*      */     //   118: goto -> 272
/*      */     //   121: aload_1
/*      */     //   122: bipush #44
/*      */     //   124: invokeinterface getDouble : (I)D
/*      */     //   129: dstore #46
/*      */     //   131: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_cex : D
/*      */     //   134: dstore #44
/*      */     //   136: dload #46
/*      */     //   138: dload #44
/*      */     //   140: dcmpl
/*      */     //   141: ifeq -> 147
/*      */     //   144: goto -> 272
/*      */     //   147: aload_1
/*      */     //   148: bipush #52
/*      */     //   150: invokeinterface getDouble : (I)D
/*      */     //   155: dstore #42
/*      */     //   157: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_ps : D
/*      */     //   160: dstore #40
/*      */     //   162: dload #42
/*      */     //   164: dload #40
/*      */     //   166: dcmpl
/*      */     //   167: ifeq -> 173
/*      */     //   170: goto -> 272
/*      */     //   173: aload_1
/*      */     //   174: bipush #17
/*      */     //   176: invokeinterface getAlignedInt : (I)I
/*      */     //   181: istore #39
/*      */     //   183: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_face : I
/*      */     //   186: istore #38
/*      */     //   188: iload #39
/*      */     //   190: iload #38
/*      */     //   192: if_icmpeq -> 198
/*      */     //   195: goto -> 272
/*      */     //   198: aload_1
/*      */     //   199: bipush #72
/*      */     //   201: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   206: new org/renjin/gcc/runtime/BytePtr
/*      */     //   209: dup
/*      */     //   210: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_family : [B
/*      */     //   213: iconst_0
/*      */     //   214: invokespecial <init> : ([BI)V
/*      */     //   217: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   220: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*      */     //   223: ifeq -> 229
/*      */     //   226: goto -> 272
/*      */     //   229: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$a : D
/*      */     //   232: dstore #33
/*      */     //   234: aload_2
/*      */     //   235: dload #33
/*      */     //   237: invokeinterface setDouble : (D)V
/*      */     //   242: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$d : D
/*      */     //   245: dstore #31
/*      */     //   247: aload_3
/*      */     //   248: dload #31
/*      */     //   250: invokeinterface setDouble : (D)V
/*      */     //   255: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$w : D
/*      */     //   258: dstore #29
/*      */     //   260: aload #4
/*      */     //   262: dload #29
/*      */     //   264: invokeinterface setDouble : (D)V
/*      */     //   269: goto -> 451
/*      */     //   272: aload #5
/*      */     //   274: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   279: sipush #228
/*      */     //   282: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   287: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   292: astore #26
/*      */     //   294: aload #5
/*      */     //   296: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   301: astore #24
/*      */     //   303: aload #26
/*      */     //   305: iload_0
/*      */     //   306: aload_1
/*      */     //   307: aload_2
/*      */     //   308: aload_3
/*      */     //   309: aload #4
/*      */     //   311: aload #24
/*      */     //   313: invokevirtual invoke : (ILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*      */     //   316: iload_0
/*      */     //   317: invokestatic abs : (I)I
/*      */     //   320: bipush #77
/*      */     //   322: if_icmpeq -> 328
/*      */     //   325: goto -> 451
/*      */     //   328: aload #5
/*      */     //   330: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_dd : Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   333: iconst_0
/*      */     //   334: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_dd$offset : I
/*      */     //   337: aload #5
/*      */     //   339: invokeinterface getPointer : ()Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   344: sipush #212
/*      */     //   347: invokeinterface getPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   352: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
/*      */     //   357: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_close : Ljava/lang/invoke/MethodHandle;
/*      */     //   360: aload_1
/*      */     //   361: bipush #44
/*      */     //   363: invokeinterface getDouble : (I)D
/*      */     //   368: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_cex : D
/*      */     //   371: aload_1
/*      */     //   372: bipush #52
/*      */     //   374: invokeinterface getDouble : (I)D
/*      */     //   379: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_ps : D
/*      */     //   382: aload_1
/*      */     //   383: bipush #17
/*      */     //   385: invokeinterface getAlignedInt : (I)I
/*      */     //   390: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_face : I
/*      */     //   393: aload_1
/*      */     //   394: astore #13
/*      */     //   396: new org/renjin/gcc/runtime/BytePtr
/*      */     //   399: dup
/*      */     //   400: getstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$last_family : [B
/*      */     //   403: iconst_0
/*      */     //   404: invokespecial <init> : ([BI)V
/*      */     //   407: checkcast org/renjin/gcc/runtime/Ptr
/*      */     //   410: aload #13
/*      */     //   412: bipush #72
/*      */     //   414: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   419: invokestatic strcpy : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   422: pop
/*      */     //   423: aload_2
/*      */     //   424: invokeinterface getDouble : ()D
/*      */     //   429: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$a : D
/*      */     //   432: aload_3
/*      */     //   433: invokeinterface getDouble : ()D
/*      */     //   438: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$d : D
/*      */     //   441: aload #4
/*      */     //   443: invokeinterface getDouble : ()D
/*      */     //   448: putstatic org/renjin/grDevices/baseEngine__.$GEMetricInfo$w : D
/*      */     //   451: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2403	-> 0
/*      */     //   #2404	-> 11
/*      */     //   #2409	-> 17
/*      */     //   #2410	-> 24
/*      */     //   #2411	-> 31
/*      */     //   #2438	-> 42
/*      */     //   #2438	-> 72
/*      */     //   #2438	-> 109
/*      */     //   #2439	-> 121
/*      */     //   #2439	-> 147
/*      */     //   #2440	-> 173
/*      */     //   #2441	-> 198
/*      */     //   #2442	-> 229
/*      */     //   #2444	-> 272
/*      */     //   #2445	-> 316
/*      */     //   #2446	-> 328
/*      */     //   #2447	-> 360
/*      */     //   #2448	-> 382
/*      */     //   #2449	-> 393
/*      */     //   #2450	-> 423
/*      */     //   #2442	-> 451
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	452	0	c	I
/*      */     //   0	452	1	gc	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	2	ascent	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	3	descent	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	4	width	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	5	dd	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	6	vfontcode	I
/*      */     //   0	452	7	w$108	D
/*      */     //   0	452	9	d$107	D
/*      */     //   0	452	11	a$106	D
/*      */     //   0	452	15	last_face$105	I
/*      */     //   0	452	16	last_ps$104	D
/*      */     //   0	452	18	last_cex$103	D
/*      */     //   0	452	20	last_close$102	Ljava/lang/invoke/MethodHandle;
/*      */     //   0	452	29	w$101	D
/*      */     //   0	452	31	d$100	D
/*      */     //   0	452	33	a$99	D
/*      */     //   0	452	38	last_face$98	I
/*      */     //   0	452	40	last_ps$97	D
/*      */     //   0	452	44	last_cex$96	D
/*      */     //   0	452	49	last_close$95	Ljava/lang/invoke/MethodHandle;
/*      */     //   0	452	53	last_dd$94	Lorg/renjin/gcc/runtime/Ptr;
/*      */     //   0	452	54	last_dd$94$offset	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double GEStrWidth(Ptr str, int enc, Ptr gc, Ptr dd) {
/* 2464 */     vmax = BytePtr.of(0); vmax$offset = 0; enc2 = 0; sbuf = BytePtr.of(0); sbuf$offset = 0; w = 0.0D; vfontcode = VFontFamilyCode(gc.pointerPlus(72));
/* 2465 */     if (vfontcode <= 99) {
/*      */       
/* 2467 */       if (vfontcode < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2473 */         sbuf = BytePtr.of(0); sbuf$offset = 0;
/* 2474 */         w = 0.0D;
/* 2475 */         if (!str.isNull() && str.getByte() != (byte)0) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2480 */           vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */           
/* 2482 */           if (gc.getAlignedInt(17) == 5) { iftmp$93 = 5; } else { iftmp$93 = enc; }  enc2 = iftmp$93;
/* 2483 */           if (enc2 == 5)
/*      */           
/* 2485 */           { if (dd.getPointer().getInt(300) == 1) enc2 = 1;  }
/*      */           else { enc2 = (dd.getPointer().getInt(288) != 1) ? 0 : 1; }
/* 2487 */            BytePtr bytePtr2 = BytePtr.malloc(Stdlib.strlen(str) + 1); sbuf$offset = 0; BytePtr bytePtr1 = bytePtr2; sb$offset = sbuf$offset;
/* 2488 */           s = str; s$offset = 0; while (true) {
/* 2489 */             if (s.getByte(s$offset) != (byte)10 && s.getByte(s$offset) != (byte)0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2502 */               byte b1 = s.getByte(s$offset); bytePtr1.setByte(sb$offset, b1); bytePtr1 = bytePtr1; sb$offset++; } else { bytePtr1.setByte(sb$offset, (byte)0); ptr1 = Rinternals.Rf_reEnc((BytePtr)bytePtr2.pointerPlus(sbuf$offset), enc, enc2, 2); if (dd.getPointer().getInt(288) != 1 || enc2 != 1) { MethodHandle methodHandle = dd.getPointer().getPointer(268).toMethodHandle(); Ptr ptr = dd.getPointer(); wdash = methodHandle.invoke(ptr1, gc, ptr); } else { MethodHandle methodHandle = dd.getPointer().getPointer(296).toMethodHandle(); Ptr ptr = dd.getPointer(); wdash = methodHandle.invoke(ptr1, gc, ptr); }  if (wdash > w)
/* 2503 */                 w = wdash;  bytePtr1 = bytePtr2; sb$offset = sbuf$offset; }  if (s.getByte(s$offset) != (byte)0) {
/*      */               s = s; s$offset++; continue;
/*      */             }  break;
/*      */           } 
/* 2507 */         }  return w;
/*      */       } 
/*      */       byte b = (byte)vfontcode;
/*      */       gc.setByte(79, b);
/*      */       int j = gc.getAlignedInt(17), i = VFontFaceCode(vfontcode, j);
/*      */       gc.setAlignedInt(17, i);
/*      */       throw new UnsatisfiedLinkException("R_GE_VStrWidth");
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("R_GE_VStrWidth");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double GEStrHeight(Ptr str, int enc, Ptr gc, Ptr dd) {
/* 2524 */     wid = new double[1]; dsc = new double[1]; asc = new double[1]; n = 0; wid[0] = 0.0D; dsc[0] = 0.0D; asc[0] = 0.0D; vfontcode = VFontFamilyCode(gc.pointerPlus(72));
/* 2525 */     if (vfontcode <= 99) {
/*      */       
/* 2527 */       if (vfontcode < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2537 */         n = 0;
/* 2538 */         for (s = str, s$offset = 0; s.getByte(s$offset) != (byte)0; s = s, s$offset++) {
/* 2539 */           if (s.getByte(s$offset) == (byte)10) {
/* 2540 */             n++;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2548 */         double d10 = n, d9 = gc.getDouble(60), d8 = d10 * d9, d7 = gc.getDouble(44), d6 = d8 * d7, d5 = dd.getPointer().getDouble(112), d4 = d6 * d5;
/* 2549 */         double d3 = gc.getDouble(52); double d2 = d4 * d3; double d1 = dd.getPointer().getDouble(140);
/*      */         h = d2 / d1;
/* 2551 */         GEMetricInfo(77, gc, (Ptr)new DoublePtr(asc, 0), (Ptr)new DoublePtr(dsc, 0), (Ptr)new DoublePtr(wid, 0), dd);
/* 2552 */         if (asc[0] == 0.0D && dsc[0] == 0.0D && wid[0] == 0.0D) {
/* 2553 */           double d18 = gc.getDouble(60), d17 = gc.getDouble(44), d16 = d18 * d17, d15 = dd.getPointer().getDouble(112), d14 = d16 * d15;
/* 2554 */           double d13 = gc.getDouble(52); double d12 = d14 * d13; double d11 = dd.getPointer().getDouble(140); asc$91 = d12 / d11; asc[0] = asc$91;
/* 2555 */         }  asc$92 = asc[0]; h += asc$92;
/* 2556 */         return h;
/*      */       } 
/*      */       byte b = (byte)vfontcode;
/*      */       gc.setByte(79, b);
/*      */       int j = gc.getAlignedInt(17), i = VFontFaceCode(vfontcode, j);
/*      */       gc.setAlignedInt(17, i);
/*      */       throw new UnsatisfiedLinkException("R_GE_VStrHeight");
/*      */     } 
/*      */     throw new UnsatisfiedLinkException("R_GE_VStrHeight");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEStrMetric(Ptr str, int enc, Ptr gc, Ptr ascent, Ptr descent, Ptr width, Ptr dd) {
/* 2573 */     wc = new int[1]; MixedPtr mixedPtr1 = MixedPtr.malloc(8); arrayOfInt1 = new int[1]; arrayOfInt2 = new int[1]; MixedPtr mixedPtr2 = MixedPtr.malloc(8); arrayOfInt3 = new int[1]; wid = new double[1]; dsc = new double[1]; asc = new double[1]; wc[0] = 0; arrayOfInt1[0] = 0; arrayOfInt2[0] = 0; arrayOfInt3[0] = 0; vmax = BytePtr.of(0); vmax$offset = 0; noMetricInfo = 0; enc2 = 0; sbuf = BytePtr.of(0); sbuf$offset = 0; i1 = 0; lineheight = 0.0D; wid[0] = 0.0D; dsc[0] = 0.0D; asc[0] = 0.0D; h = 0.0D; vfontcode = VFontFamilyCode(gc.pointerPlus(72));
/* 2574 */     ascent.setDouble(0.0D);
/* 2575 */     descent.setDouble(0.0D);
/* 2576 */     width.setDouble(0.0D);
/* 2577 */     if (vfontcode < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2593 */       double d10 = gc.getDouble(60), d9 = gc.getDouble(44), d8 = d10 * d9, d7 = dd.getPointer().getDouble(112), d6 = d8 * d7;
/* 2594 */       double d5 = gc.getDouble(52); double d4 = d6 * d5; double d3 = dd.getPointer().getDouble(140);
/*      */ 
/*      */       
/*      */       lineheight = d4 / d3;
/*      */ 
/*      */       
/* 2600 */       vmax = VoidPtr.toPtr(Memory.vmaxget()); vmax$offset = 0;
/*      */       
/* 2602 */       GEMetricInfo(77, gc, (Ptr)new DoublePtr(asc, 0), (Ptr)new DoublePtr(dsc, 0), (Ptr)new DoublePtr(wid, 0), dd);
/* 2603 */       if (asc[0] != 0.0D || dsc[0] != 0.0D || wid[0] != 0.0D) { iftmp$63 = 0; } else { iftmp$63 = 1; }  noMetricInfo = iftmp$63;
/*      */       
/* 2605 */       if (gc.getAlignedInt(17) == 5) { iftmp$67 = 5; } else { iftmp$67 = enc; }  enc2 = iftmp$67;
/* 2606 */       if (enc2 == 5)
/*      */       
/* 2608 */       { if (dd.getPointer().getInt(300) != 1)
/* 2609 */         { int i2 = dd.getPointer().getInt(300); R_NaInt$69 = Arith.R_NaInt; if (i2 == R_NaInt$69)
/* 2610 */           { enc = 2;
/* 2611 */             enc2 = 1; }  }
/*      */         else { enc2 = 1; }
/*      */          }
/*      */       else { enc2 = (dd.getPointer().getInt(288) != 1) ? 0 : 1; }
/* 2615 */        BytePtr bytePtr1 = BytePtr.malloc(Stdlib.strlen(str) + 1); sbuf$offset = 0; BytePtr bytePtr2 = bytePtr1; sb$offset = sbuf$offset;
/* 2616 */       s = str; s$offset = 0;
/* 2617 */       while (s.getByte(s$offset) != (byte)10 && s.getByte(s$offset) != (byte)0) {
/* 2618 */         byte b = s.getByte(s$offset); bytePtr2.setByte(sb$offset, b); bytePtr2 = bytePtr2; sb$offset++; s = s; s$offset++;
/*      */       } 
/* 2620 */       bytePtr2.setByte(sb$offset, (byte)0);
/*      */       
/* 2622 */       if (noMetricInfo == 0)
/*      */       
/*      */       { 
/* 2625 */         s = Rinternals.Rf_reEnc((BytePtr)bytePtr1.pointerPlus(sbuf$offset), enc, enc2, 2); s$offset = 0;
/* 2626 */         if (enc2 == 5 || Defn.Rf_strIsASCII((BytePtr)s.pointerPlus(s$offset)))
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2649 */           while (s.getByte(s$offset) != (byte)0)
/* 2650 */           { int i2 = s.getByte(s$offset) & 0xFF; s = s; s$offset++; GEMetricInfo(i2, gc, (Ptr)new DoublePtr(asc, 0), (Ptr)new DoublePtr(dsc, 0), (Ptr)new DoublePtr(wid, 0), dd);
/*      */             
/* 2652 */             double d = ascent.getDouble(); asc$77 = asc[0]; if (d >= asc$77)
/* 2653 */               continue;  asc$78 = asc[0]; ascent.setDouble(asc$78); }  }
/*      */         else if (Defn.mbcslocale == 0 || enc2 != 0) { if (enc2 == 1)
/*      */             throw new UnsatisfiedLinkException("Rf_utf8toucs");  }
/*      */         else { m = Stdlib.strlen(s.pointerPlus(s$offset)); mixedPtr2.memset(0, 8); throw new UnsatisfiedLinkException("mbrtowc"); }
/*      */          }
/*      */       else { double d = GEStrHeight(bytePtr1.pointerPlus(sbuf$offset), enc2, gc, dd); ascent.setDouble(d); }
/* 2659 */        i1 = 0;
/* 2660 */       for (s = str, s$offset = 0; s.getByte(s$offset) != (byte)0; s = s, s$offset++) {
/* 2661 */         if (s.getByte(s$offset) == (byte)10)
/* 2662 */           i1++; 
/* 2663 */       }  h = i1 * lineheight;
/*      */ 
/*      */       
/* 2666 */       if (i1 <= 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 2671 */         s = str; s$offset = 0; }
/*      */       else { while (s.getByte(s$offset) != (byte)10) { s = s; s$offset--; }
/*      */          s = s; s$offset++; }
/* 2674 */        bytePtr2 = bytePtr1; sb$offset = sbuf$offset;
/* 2675 */       while (s.getByte(s$offset) != (byte)0) {
/* 2676 */         byte b = s.getByte(s$offset); bytePtr2.setByte(sb$offset, b); bytePtr2 = bytePtr2; sb$offset++; s = s; s$offset++;
/*      */       } 
/* 2678 */       bytePtr2.setByte(sb$offset, (byte)0);
/*      */       
/* 2680 */       if (noMetricInfo == 0)
/*      */       
/*      */       { 
/* 2683 */         s = Rinternals.Rf_reEnc((BytePtr)bytePtr1.pointerPlus(sbuf$offset), enc, enc2, 2); s$offset = 0;
/* 2684 */         if (enc2 == 5 || Defn.Rf_strIsASCII((BytePtr)s.pointerPlus(s$offset)))
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2707 */           while (s.getByte(s$offset) != (byte)0)
/* 2708 */           { int i2 = s.getByte(s$offset) & 0xFF; s = s; s$offset++; GEMetricInfo(i2, gc, (Ptr)new DoublePtr(asc, 0), (Ptr)new DoublePtr(dsc, 0), (Ptr)new DoublePtr(wid, 0), dd);
/*      */             
/* 2710 */             double d = descent.getDouble(); dsc$86 = dsc[0]; if (d >= dsc$86)
/* 2711 */               continue;  dsc$87 = dsc[0]; descent.setDouble(dsc$87); }  } else if (Defn.mbcslocale == 0 || enc2 != 0) { if (enc2 == 1)
/*      */             throw new UnsatisfiedLinkException("Rf_utf8toucs");  }
/*      */         else { n = Stdlib.strlen(s.pointerPlus(s$offset)); mixedPtr1.memset(0, 8); throw new UnsatisfiedLinkException("mbrtowc"); }
/*      */          }
/*      */       else { descent.setDouble(0.0D); }
/* 2716 */        double d2 = ascent.getDouble() + h; ascent.setDouble(d2);
/* 2717 */       double d1 = GEStrWidth(str, enc, gc, dd); width.setDouble(d1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GENewPage(Ptr gc, Ptr dd) {
/* 2730 */     MethodHandle methodHandle = dd.getPointer().getPointer(236).toMethodHandle(); Ptr ptr = dd.getPointer(); methodHandle.invoke(gc, ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int GEdeviceDirty(Ptr dd) {
/* 2742 */     return dd.getAlignedInt(5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEdirtyDevice(Ptr dd) {
/* 2755 */     dd.setAlignedInt(5, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void GEcleanDevice(Ptr dd) {
/* 2760 */     dd.setAlignedInt(5, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int GEcheckState(Ptr dd) {
/* 2774 */     result = 0; result = 1;
/* 2775 */     for (i = 0; i <= 23; i++) {
/* 2776 */       if (!dd.getPointer(28 + i * 4).isNull())
/* 2777 */       { MethodHandle methodHandle = dd.getPointer(28 + i * 4).getPointer(4).toMethodHandle();
/* 2778 */         R_NilValue$62 = Rinternals.R_NilValue; if (Rinternals.LOGICAL(methodHandle.invoke(7, dd, R_NilValue$62)).getInt() == 0)
/* 2779 */           result = 0;  } 
/* 2780 */     }  return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int GErecording(SEXP call, Ptr dd) {
/* 2790 */     R_NilValue$61 = Rinternals.R_NilValue; return (call == R_NilValue$61 || dd.getAlignedInt(6) == 0) ? 0 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GErecordGraphicOperation(SEXP op, SEXP args, Ptr dd) {
/* 2800 */     lastOperation = (SEXP)dd.getAlignedPointer(3).getArray();
/* 2801 */     if (dd.getAlignedInt(1) != 0) {
/* 2802 */       newOperation = Rinternals.Rf_list2(op, args);
/* 2803 */       R_NilValue$57 = Rinternals.R_NilValue; if (lastOperation != R_NilValue$57) {
/*      */ 
/*      */ 
/*      */         
/* 2807 */         R_NilValue$59 = Rinternals.R_NilValue; SEXP sEXP4 = Rinternals.Rf_cons(newOperation, R_NilValue$59); Rinternals.SETCDR(lastOperation, sEXP4);
/* 2808 */         SEXP sEXP3 = Rinternals.CDR(lastOperation); dd.setAlignedPointer(3, (Ptr)new RecordUnitPtr(sEXP3));
/*      */         return;
/*      */       } 
/*      */       R_NilValue$58 = Rinternals.R_NilValue;
/*      */       SEXP sEXP2 = Rinternals.Rf_cons(newOperation, R_NilValue$58);
/*      */       dd.setAlignedPointer(2, (Ptr)new RecordUnitPtr(sEXP2));
/*      */       SEXP sEXP1 = (SEXP)dd.getAlignedPointer(2).getArray();
/*      */       dd.setAlignedPointer(3, (Ptr)new RecordUnitPtr(sEXP1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEinitDisplayList(Ptr dd) {
/* 2824 */     SEXP sEXP2 = GEcreateSnapshot(dd); dd.setAlignedPointer(4, (Ptr)new RecordUnitPtr(sEXP2));
/*      */ 
/*      */ 
/*      */     
/* 2828 */     for (i = 0; i <= 23; i++) {
/* 2829 */       if (!dd.getPointer(28 + i * 4).isNull())
/* 2830 */       { MethodHandle methodHandle = dd.getPointer(28 + i * 4).getPointer(4).toMethodHandle(); R_NilValue$55 = Rinternals.R_NilValue; methodHandle.invoke(2, dd, R_NilValue$55); } 
/* 2831 */     }  R_NilValue$56 = Rinternals.R_NilValue; dd.setAlignedPointer(3, (Ptr)new RecordUnitPtr(R_NilValue$56)); SEXP sEXP1 = (SEXP)dd.getAlignedPointer(3).getArray(); dd.setAlignedPointer(2, (Ptr)new RecordUnitPtr(sEXP1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEplayDisplayList(Ptr dd) {
/* 2855 */     theList = (SEXP)BytePtr.of(0).getArray(); plotok = 0; savedDevice = 0; _this = 0; _this = baseDevices__.GEdeviceNumber(dd);
/* 2856 */     if (_this != 0) {
/* 2857 */       theList = (SEXP)dd.getAlignedPointer(2).getArray();
/* 2858 */       R_NilValue$50 = Rinternals.R_NilValue; if (theList != R_NilValue$50) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2863 */         for (i = 0; i <= 23; i++) {
/* 2864 */           if (!dd.getPointer(28 + i * 4).isNull()) {
/* 2865 */             dd.getPointer(28 + i * 4).getPointer(4).toMethodHandle().invoke(6, dd, theList);
/*      */           }
/*      */         } 
/* 2868 */         Rinternals.Rf_protect(theList);
/* 2869 */         plotok = 1;
/* 2870 */         R_NilValue$51 = Rinternals.R_NilValue; if (theList != R_NilValue$51) {
/* 2871 */           colors__.savePalette(1);
/* 2872 */           savedDevice = baseDevices__.Rf_curDevice();
/* 2873 */           baseDevices__.Rf_selectDevice(_this); while (true) {
/* 2874 */             R_NilValue$54 = Rinternals.R_NilValue; if (theList == R_NilValue$54 || plotok == 0)
/* 2875 */               break;  theOperation = Rinternals.CAR(theList);
/* 2876 */             op = Rinternals.CAR(theOperation);
/* 2877 */             args = Rinternals.CADR(theOperation);
/* 2878 */             if (Rinternals.TYPEOF(op) != 8 && Rinternals.TYPEOF(op) != 7)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2889 */               Error.Rf_warning(new BytePtr("invalid display list\000".getBytes(), 0), new Object[0]);
/* 2890 */               plotok = 0; } else { R_NilValue$52 = Rinternals.R_NilValue; Internal.invokePrimitive(Rinternals.R_NilValue, op, args, R_NilValue$52); if (GEcheckState(dd) == 0) { Error.Rf_warning(new BytePtr("display list redraw incomplete\000".getBytes(), 0), new Object[0]); plotok = 0; }
/*      */                }
/* 2892 */              theList = Rinternals.CDR(theList);
/*      */           } 
/* 2894 */           baseDevices__.Rf_selectDevice(savedDevice);
/* 2895 */           colors__.savePalette(0);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEcopyDisplayList(int fromDevice) {
/* 2911 */     gd = BytePtr.of(0); gd$offset = 0; dd = BytePtr.of(0); dd$offset = 0; dd = baseDevices__.GEcurrentDevice(); dd$offset = 0; gd = baseDevices__.GEgetDevice(fromDevice); gd$offset = 0;
/*      */ 
/*      */     
/* 2914 */     tmp = (SEXP)gd.getPointer(gd$offset + 8).getArray();
/* 2915 */     if (Rinternals.TYPEOF(tmp) != 0) tmp = Rinternals.Rf_duplicate(tmp); 
/* 2916 */     dd.setPointer(dd$offset + 8, (Ptr)new RecordUnitPtr(tmp));
/* 2917 */     SEXP sEXP = Rinternals.Rf_lastElt((SEXP)dd.getPointer(dd$offset + 8).getArray()); dd.setPointer(dd$offset + 12, (Ptr)new RecordUnitPtr(sEXP));
/*      */ 
/*      */ 
/*      */     
/* 2921 */     for (i = 0; i <= 23; i++) {
/* 2922 */       if (!dd.getPointer(dd$offset + 28 + i * 4).isNull())
/* 2923 */       { MethodHandle methodHandle = dd.getPointer(dd$offset + 28 + i * 4).getPointer(4).toMethodHandle(); R_NilValue$49 = Rinternals.R_NilValue; methodHandle.invoke(3, gd.pointerPlus(gd$offset), R_NilValue$49); } 
/* 2924 */     }  GEplayDisplayList(dd.pointerPlus(dd$offset));
/* 2925 */     if (dd.getInt(dd$offset + 4) == 0) GEinitDisplayList(dd.pointerPlus(dd$offset));
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP GEcreateSnapshot(Ptr dd) {
/* 2952 */     snapshot = (SEXP)BytePtr.of(0).getArray(); int k = Context.get__baseEngine$numGraphicsSystems() + 1; snapshot = Rinternals.Rf_allocVector(19, k); Rinternals.Rf_protect(snapshot);
/*      */ 
/*      */     
/* 2955 */     if (Rinternals.TYPEOF((SEXP)dd.getAlignedPointer(2).getArray()) != 0) {
/* 2956 */       tmp = Rinternals.Rf_duplicate((SEXP)dd.getAlignedPointer(2).getArray()); Rinternals.Rf_protect(tmp);
/* 2957 */       Rinternals.SET_VECTOR_ELT(snapshot, 0, tmp);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2963 */     for (i = 0; i <= 23; i++) {
/* 2964 */       if (!dd.getPointer(28 + i * 4).isNull()) {
/* 2965 */         MethodHandle methodHandle = dd.getPointer(28 + i * 4).getPointer(4).toMethodHandle(); R_NilValue$48 = Rinternals.R_NilValue; state = methodHandle.invoke(4, dd, R_NilValue$48); Rinternals.Rf_protect(state);
/*      */         
/* 2967 */         int m = i + 1; Rinternals.SET_VECTOR_ELT(snapshot, m, state);
/*      */       } 
/*      */     } 
/* 2970 */     engineVersion = Rinternals.Rf_allocVector(13, 1); Rinternals.Rf_protect(engineVersion);
/* 2971 */     Ptr ptr = Rinternals2.INTEGER(engineVersion); int j = R_GE_getVersion(); ptr.setInt(0, j);
/* 2972 */     SEXP sEXP = Rinternals.Rf_install(new BytePtr("engineVersion\000".getBytes(), 0)); Rinternals.Rf_setAttrib(snapshot, sEXP, engineVersion);
/*      */     
/* 2974 */     return snapshot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEplaySnapshot(SEXP snapshot, Ptr dd) {
/* 2997 */     engineVersion = R_GE_getVersion();
/* 2998 */     SEXP sEXP3 = Rinternals.Rf_install(new BytePtr("engineVersion\000".getBytes(), 0)); snapshotEngineVersion = Rinternals.Rf_getAttrib(snapshot, sEXP3); Rinternals.Rf_protect(snapshotEngineVersion);
/*      */     
/* 3000 */     if (Rinternals.TYPEOF(snapshotEngineVersion) != 0) {
/*      */ 
/*      */       
/* 3003 */       if (Rinternals2.INTEGER(snapshotEngineVersion).getInt() != engineVersion) {
/* 3004 */         snapshotVersion = Rinternals2.INTEGER(snapshotEngineVersion).getInt();
/* 3005 */         Error.Rf_warning(new BytePtr("snapshot recorded with different graphics engine version (%d - this is version %d)\000".getBytes(), 0), new Object[] { Integer.valueOf(snapshotVersion), Integer.valueOf(engineVersion) });
/*      */       } 
/*      */     } else {
/*      */       Error.Rf_warning(new BytePtr("snapshot recorded with different graphics engine version (pre 11 - this is version %d)\000".getBytes(), 0), new Object[] { Integer.valueOf(engineVersion) });
/*      */     } 
/* 3010 */     GEcleanDevice(dd);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3017 */     for (i = 0; i <= 23; i++) {
/* 3018 */       if (!dd.getPointer(28 + i * 4).isNull()) {
/* 3019 */         dd.getPointer(28 + i * 4).getPointer(4).toMethodHandle().invoke(5, dd, snapshot);
/*      */       }
/*      */     } 
/* 3022 */     SEXP sEXP2 = Rinternals.Rf_duplicate(Rinternals.VECTOR_ELT(snapshot, 0)); dd.setAlignedPointer(2, (Ptr)new RecordUnitPtr(sEXP2));
/* 3023 */     SEXP sEXP1 = Rinternals.Rf_lastElt((SEXP)dd.getAlignedPointer(2).getArray()); dd.setAlignedPointer(3, (Ptr)new RecordUnitPtr(sEXP1));
/* 3024 */     GEplayDisplayList(dd);
/* 3025 */     if (dd.getAlignedInt(1) == 0) GEinitDisplayList(dd);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_getSnapshot(SEXP call, SEXP op, SEXP args, SEXP env) {
/* 3032 */     Defn.Rf_checkArityCall(op, args, call);
/* 3033 */     return GEcreateSnapshot(baseDevices__.GEcurrentDevice());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_playSnapshot(SEXP call, SEXP op, SEXP args, SEXP env) {
/* 3039 */     Defn.Rf_checkArityCall(op, args, call);
/* 3040 */     Ptr ptr = baseDevices__.GEcurrentDevice(); GEplaySnapshot(Rinternals.CAR(args), ptr);
/* 3041 */     return Rinternals.R_NilValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP do_recordGraphics(SEXP call, SEXP op, SEXP args, SEXP env) {
/* 3055 */     parentenv = (SEXP)BytePtr.of(0).getArray(); code = (SEXP)BytePtr.of(0).getArray(); record = 0; dd = BytePtr.of(0); dd$offset = 0; x = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/* 3056 */     record = dd.getInt(dd$offset + 24);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3079 */     Defn.Rf_checkArityCall(op, args, call);
/* 3080 */     code = Rinternals.CAR(args);
/* 3081 */     list = Rinternals.CADR(args);
/* 3082 */     parentenv = Rinternals.CADDR(args);
/* 3083 */     if (!Rinternals.Rf_isLanguage(code))
/* 3084 */       Error.Rf_error(new BytePtr("'expr' argument must be an expression\000".getBytes(), 0), new Object[0]); 
/* 3085 */     if (Rinternals.TYPEOF(list) != 19)
/* 3086 */       Error.Rf_error(new BytePtr("'list' argument must be a list\000".getBytes(), 0), new Object[0]); 
/* 3087 */     if (Rinternals.TYPEOF(parentenv) == 0) {
/* 3088 */       Error.Rf_error(new BytePtr("use of NULL environment is defunct\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */     
/* 3091 */     if (Rinternals.TYPEOF(parentenv) != 4) {
/* 3092 */       Error.Rf_error(new BytePtr("'env' argument must be an environment\000".getBytes(), 0), new Object[0]);
/*      */     }
/*      */ 
/*      */     
/* 3096 */     x = Rinternals.Rf_VectorToPairList(list); Rinternals.Rf_protect(x);
/* 3097 */     xptr = x; while (true) { R_NilValue$45 = Rinternals.R_NilValue; if (xptr != R_NilValue$45) {
/* 3098 */         SEXP sEXP = Rinternals.CAR(xptr); xptr = Rinternals.CDR(xptr);
/*      */         continue;
/*      */       } 
/*      */       break; }
/*      */     
/* 3103 */     evalenv = Defn.Rf_NewEnvironment(Rinternals.R_NilValue, x, parentenv); Rinternals.Rf_protect(evalenv);
/* 3104 */     dd.setInt(dd$offset + 24, 0);
/* 3105 */     retval = Rinternals.Rf_eval(code, evalenv); Rinternals.Rf_protect(retval);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3111 */     dd.setInt(dd$offset + 24, record);
/* 3112 */     if (GErecording(call, dd.pointerPlus(dd$offset)) != 0) {
/* 3113 */       if (GEcheckState(dd.pointerPlus(dd$offset)) == 0)
/* 3114 */         Error.Rf_error(new BytePtr("invalid graphics state\000".getBytes(), 0), new Object[0]); 
/* 3115 */       GErecordGraphicOperation(op, args, dd.pointerPlus(dd$offset));
/*      */     } 
/*      */     
/* 3118 */     return retval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void GEonExit() {
/* 3140 */     i = 1;
/* 3141 */     if (baseDevices__.Rf_NoDevices() == 0) {
/* 3142 */       devNum = baseDevices__.Rf_curDevice(); while (true) {
/* 3143 */         int j = baseDevices__.Rf_NumDevices(); boolean bool = (i >= j) ? false : true; i++; if (!bool)
/* 3144 */           break;  gd = baseDevices__.GEgetDevice(devNum);
/* 3145 */         gd.setInt(24, 1);
/* 3146 */         dd = gd.getPointer();
/* 3147 */         if (dd.getPointer(276).toMethodHandle() != null) dd.getPointer(276).toMethodHandle().invoke(dd); 
/* 3148 */         devNum = baseDevices__.Rf_nextDevice(devNum);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int GEstring_to_pch(SEXP pch) {
/* 3159 */     ucs = new int[1]; wc = new int[1]; ipch = Arith.R_NaInt;
/*      */ 
/*      */ 
/*      */     
/* 3163 */     R_NaString$39 = Rinternals.R_NaString; if (pch != R_NaString$39) {
/* 3164 */       if (Rinternals.R_CHAR(pch).getByte() != (byte)0) {
/* 3165 */         last_pch$40 = $GEstring_to_pch$last_pch; if (pch != last_pch$40) {
/* 3166 */           ipch = Rinternals.R_CHAR(pch).getByte() & 0xFF;
/* 3167 */           if (Defn.IS_LATIN1(pch) == 0)
/*      */           
/*      */           { 
/* 3170 */             if (Defn.IS_UTF8(pch) == 0 && Defn.utf8locale == 0)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */               
/* 3176 */               if (Defn.mbcslocale != 0)
/*      */               
/*      */               { 
/*      */                 
/* 3180 */                 ucs[0] = 0;
/* 3181 */                 throw new UnsatisfiedLinkException("__ctype_get_mb_cur_max"); }  }
/*      */             else { wc[0] = 0; if (ipch > 127) { BytePtr bytePtr = Rinternals.R_CHAR(pch); throw new UnsatisfiedLinkException("Rf_utf8toucs"); }
/*      */                }
/*      */              }
/*      */           else if (ipch > 127) { ipch = -ipch; }
/* 3186 */            $GEstring_to_pch$last_ipch = ipch; $GEstring_to_pch$last_pch = pch;
/* 3187 */           return ipch;
/*      */         } 
/*      */         return $GEstring_to_pch$last_ipch;
/*      */       } 
/*      */       return Arith.R_NaInt;
/*      */     } 
/*      */     return Arith.R_NaInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hexdigit(int digit) {
/* 3226 */     null = 0; if (digit <= 47 || digit > 57) {
/* 3227 */       if (digit <= 64 || digit > 70) {
/* 3228 */         if (digit <= 96 || digit > 102) {
/* 3229 */           Error.Rf_error(new BytePtr("invalid hex digit in 'color' or 'lty'\000".getBytes(), 0), new Object[0]);
/*      */           return null;
/*      */         } 
/*      */         return digit + -87;
/*      */       } 
/*      */       return digit + -55;
/*      */     } 
/*      */     return digit + -48;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int GE_LTYpar(SEXP value, int ind) {
/* 3241 */     null = 0; if (Rinternals.TYPEOF(value) != 16) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3262 */       if (!Rinternals.Rf_isInteger(value)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3270 */         if (Rinternals.TYPEOF(value) != 14)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3280 */           Error.Rf_error(new BytePtr("invalid line type\000".getBytes(), 0), new Object[0]); return null; }  Ptr ptr4 = Rinternals2.REAL(value); int n = ind * 8; Ptr ptr3 = ptr4; int m = 0 + n; rcode = ptr3.getDouble(m); if (Arith.R_finite(rcode) == 0 || rcode < 0.0D)
/*      */           Error.Rf_error(new BytePtr("invalid line type\000".getBytes(), 0), new Object[0]);  code = (int)rcode; if (code > 0) { int i1 = code + -1; nlinetype$38 = Context.get__baseEngine$nlinetype(); code = i1 % nlinetype$38 + 1; }
/*      */          return Context.get__baseEngine$linetype().getInt(code * 8 + 4);
/*      */       }  Ptr ptr2 = Rinternals2.INTEGER(value); int k = ind * 4; Ptr ptr1 = ptr2; int j = 0 + k; code = ptr1.getInt(j); R_NaInt$35 = Arith.R_NaInt; if (code == R_NaInt$35 || code < 0)
/*      */         Error.Rf_error(new BytePtr("invalid line type\000".getBytes(), 0), new Object[0]);  if (code > 0) { int m = code + -1; nlinetype$36 = Context.get__baseEngine$nlinetype(); code = m % nlinetype$36 + 1; }
/*      */        return Context.get__baseEngine$linetype().getInt(code * 8 + 4);
/*      */     }  for (i = 0; !Context.get__baseEngine$linetype().getPointer(i * 8).isNull(); ) { Ptr ptr = Context.get__baseEngine$linetype().getPointer(i * 8); if (Stdlib.strcmp((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(value, ind)), ptr) != 0) { i++; continue; }
/*      */        null = Context.get__baseEngine$linetype().getInt(i * 8 + 4); // Byte code: goto -> 568 }
/*      */      code = 0; shift = 0; BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(value, ind)); p$offset = 0; len = Stdlib.strlen(bytePtr.pointerPlus(p$offset)); if (Integer.compareUnsigned(len, 1) <= 0 || Integer.compareUnsigned(len, 8) > 0 || (len & 0x1) != 0)
/*      */       Error.Rf_error(new BytePtr("invalid line type: must be length 2, 4, 6 or 8\000".getBytes(), 0), new Object[0]);  for (; bytePtr.getByte(p$offset) != (byte)0; bytePtr = bytePtr, p$offset++) { digit = hexdigit(bytePtr.getByte(p$offset)); if (digit == 0)
/*      */         Error.Rf_error(new BytePtr("invalid line type: zeroes are not allowed\000".getBytes(), 0), new Object[0]);  code = digit << shift | code; shift += 4; }
/* 3291 */      return code; } public static SEXP GE_LTYget(int lty) { for (cbuf = new byte[17], dash = new byte[8], ndash = 0, i = 0; !Context.get__baseEngine$linetype().getPointer(i * 8).isNull(); ) {
/* 3292 */       if (Context.get__baseEngine$linetype().getInt(i * 8 + 4) != lty) { i++; continue; }  SEXP sEXP = Rinternals.Rf_mkString(Context.get__baseEngine$linetype().getPointer(i * 8)); // Byte code: goto -> 206
/*      */     } 
/* 3294 */     l = lty; ndash = 0;
/* 3295 */     for (i = 0; i <= 7 && (l & 0xF) != 0; i++) {
/* 3296 */       int j = l & 0xFF & 0xF; dash[ndash] = j; ndash++;
/* 3297 */       l >>>= 4;
/*      */     } 
/* 3299 */     for (i = 0; i < ndash; ) { int j = dash[i] & 0xFF; byte b = Context.get__baseEngine$HexDigits()[j]; cbuf[i] = b; i++; }
/* 3300 */      return Rinternals.Rf_mkString((Ptr)new BytePtr(cbuf, 0)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterScale(Ptr sraster, int sw, int sh, Ptr draster, int dw, int dh) {
/* 3342 */     for (i = 0, i = 0; i < dh; i++) {
/* 3343 */       for (j = 0; j < dw; j++) {
/* 3344 */         sy = i * sh / dh;
/* 3345 */         sx = j * sw / dw;
/* 3346 */         if (sx < 0 || sx >= sw || sy < 0 || sy >= sh)
/*      */         
/*      */         { 
/* 3349 */           pixel = 0; }
/*      */         else { int i1 = (sy * sw + sx) * 4; Ptr ptr1 = sraster; int n = i1; pixel = ptr1.getInt(n); }
/* 3351 */          int m = (i * dw + j) * 4; Ptr ptr = draster; int k = m; ptr.setInt(k, pixel);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterInterpolate(Ptr sraster, int sw, int sh, Ptr draster, int dw, int dh) {
/* 3386 */     dline = BytePtr.of(0); dline$offset = 0; sline = BytePtr.of(0); sline$offset = 0; yf = 0; yp = 0; hm2 = 0; wm2 = 0; scy = 0.0D; scx = 0.0D; i = 0; double d4 = sw * 16.0D, d3 = dw; scx = d4 / d3;
/* 3387 */     double d2 = sh * 16.0D, d1 = dh; scy = d2 / d1;
/*      */     
/* 3389 */     wm2 = sw + -2;
/* 3390 */     hm2 = sh + -2;
/*      */ 
/*      */     
/* 3393 */     for (i = 0; i < dh; i++) {
/* 3394 */       ypm = (int)Rmath.Rf_fmax2(i * scy - 8.0D, 0.0D);
/* 3395 */       yp = ypm >> 4;
/* 3396 */       yf = ypm & 0xF;
/* 3397 */       int m = i * dw * 4; dline = draster; dline$offset = m;
/* 3398 */       int k = yp * sw * 4; sline = sraster; sline$offset = k;
/* 3399 */       for (j = 0; j < dw; j++) {
/* 3400 */         xpm = (int)Rmath.Rf_fmax2(j * scx - 8.0D, 0.0D);
/* 3401 */         xp = xpm >> 4;
/* 3402 */         xf = xpm & 0xF;
/*      */         
/* 3404 */         int i27 = xp * 4; Ptr ptr2 = sline; int i26 = sline$offset + i27; pixels1 = ptr2.getInt(i26);
/*      */         
/* 3406 */         if (xp <= wm2 && yp <= hm2)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3422 */           int i33 = (xp + 1) * 4; Ptr ptr5 = sline; int i32 = sline$offset + i33; pixels2 = ptr5.getInt(i32);
/* 3423 */           sw$13 = sw; xp$14 = xp; int i31 = (sw$13 + xp$14) * 4; Ptr ptr4 = sline; int i30 = sline$offset + i31; pixels3 = ptr4.getInt(i30);
/* 3424 */           sw$15 = sw; xp$16 = xp; int i29 = (sw$15 + xp$16 + 1) * 4; Ptr ptr3 = sline; int i28 = sline$offset + i29; pixels4 = ptr3.getInt(i28); } else if (yp <= hm2 || xp > wm2) { if (xp <= wm2 || yp > hm2) { pixels4 = pixels3 = pixels2 = pixels1; } else { pixels2 = pixels1; sw$10 = sw; xp$11 = xp; int i29 = (sw$10 + xp$11) * 4; Ptr ptr = sline; int i28 = sline$offset + i29; pixels3 = ptr.getInt(i28); pixels4 = pixels3; }
/*      */            }
/*      */         else { int i29 = (xp + 1) * 4; Ptr ptr = sline; int i28 = sline$offset + i29; pixels2 = ptr.getInt(i28); pixels3 = pixels1; pixels4 = pixels2; }
/* 3427 */          int i25 = 16 - xf, i24 = 16 - yf; area00 = i25 * i24;
/* 3428 */         area10 = (16 - yf) * xf;
/* 3429 */         area01 = (16 - xf) * yf;
/* 3430 */         area11 = xf * yf;
/* 3431 */         int i23 = pixels1 & 0xFF; area00$17 = area00; v00r = i23 * area00$17;
/* 3432 */         int i22 = pixels1 >>> 8 & 0xFF; area00$18 = area00; v00g = i22 * area00$18;
/* 3433 */         int i21 = pixels1 >>> 16 & 0xFF; area00$19 = area00; v00b = i21 * area00$19;
/* 3434 */         int i20 = pixels1 >>> 24; area00$20 = area00; v00a = i20 * area00$20;
/* 3435 */         int i19 = pixels2 & 0xFF; area10$21 = area10; v10r = i19 * area10$21;
/* 3436 */         int i18 = pixels2 >>> 8 & 0xFF; area10$22 = area10; v10g = i18 * area10$22;
/* 3437 */         int i17 = pixels2 >>> 16 & 0xFF; area10$23 = area10; v10b = i17 * area10$23;
/* 3438 */         int i16 = pixels2 >>> 24; area10$24 = area10; v10a = i16 * area10$24;
/* 3439 */         int i15 = pixels3 & 0xFF; area01$25 = area01; v01r = i15 * area01$25;
/* 3440 */         int i14 = pixels3 >>> 8 & 0xFF; area01$26 = area01; v01g = i14 * area01$26;
/* 3441 */         int i13 = pixels3 >>> 16 & 0xFF; area01$27 = area01; v01b = i13 * area01$27;
/* 3442 */         int i12 = pixels3 >>> 24; area01$28 = area01; v01a = i12 * area01$28;
/* 3443 */         int i11 = pixels4 & 0xFF; area11$29 = area11; v11r = i11 * area11$29;
/* 3444 */         int i10 = pixels4 >>> 8 & 0xFF; area11$30 = area11; v11g = i10 * area11$30;
/* 3445 */         int i9 = pixels4 >>> 16 & 0xFF; area11$31 = area11; v11b = i9 * area11$31;
/* 3446 */         int i8 = pixels4 >>> 24; area11$32 = area11; v11a = i8 * area11$32;
/* 3447 */         int i7 = v00r + v10r + v01r + v11r + 128 >> 8 & 0xFF;
/* 3448 */         int i6 = v00g + v10g + v01g + v11g + 128 & 0xFF00; int i5 = i7 | i6;
/* 3449 */         int i4 = v00b + v10b + v01b + v11b + 128 << 8 & 0xFF0000, i3 = i5 | i4;
/* 3450 */         int i2 = v00a + v10a + v01a + v11a + 128 << 16 & 0xFF000000; pixel = i3 | i2;
/* 3451 */         int i1 = j * 4; Ptr ptr1 = dline; int n = dline$offset + i1; ptr1.setInt(n, pixel);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterRotatedSize(int w, int h, double angle, Ptr wnew, Ptr hnew) {
/* 3464 */     int i3 = w * w, i2 = h * h; diag = Mathlib.sqrt((i3 + i2));
/* 3465 */     double d3 = w; theta = Mathlib.atan2(h, d3);
/* 3466 */     trx1 = Mathlib.cos(theta + angle) * diag;
/* 3467 */     trx2 = Mathlib.cos(theta - angle) * diag;
/* 3468 */     try1 = Mathlib.sin(theta + angle) * diag;
/* 3469 */     try2 = Mathlib.sin(angle - theta) * diag;
/* 3470 */     double d2 = Math.abs(trx2); int i1 = (int)(Rmath.Rf_fmax2(Math.abs(trx1), d2) + 0.5D); wnew.setInt(i1);
/* 3471 */     double d1 = Math.abs(try2); int n = (int)(Rmath.Rf_fmax2(Math.abs(try1), d1) + 0.5D); hnew.setInt(n);
/*      */ 
/*      */ 
/*      */     
/* 3475 */     int m = wnew.getInt(), k = Rmath.Rf_imax2(w, m); wnew.setInt(k);
/* 3476 */     int j = hnew.getInt(), i = Rmath.Rf_imax2(h, j); hnew.setInt(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterRotatedOffset(int w, int h, double angle, int botleft, Ptr xoff, Ptr yoff) {
/* 3487 */     int j = w * w, i = h * h; hypot = Mathlib.sqrt((j + i)) * 0.5D;
/*      */     
/* 3489 */     if (botleft == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3496 */       double d8 = w, d7 = Mathlib.atan2(h, d8); theta = -3.141592653589793D - d7;
/* 3497 */       dw = Mathlib.cos(theta + angle) * hypot;
/* 3498 */       dh = Mathlib.sin(theta + angle) * hypot;
/* 3499 */       double d6 = (w / 2) + dw; xoff.setDouble(d6);
/* 3500 */       double d5 = (h / 2), d4 = dh - d5; yoff.setDouble(d4);
/*      */       return;
/*      */     } 
/*      */     double d3 = w;
/*      */     theta = Mathlib.atan2(h, d3) + Math.PI;
/*      */     dw = Mathlib.cos(theta + angle) * hypot;
/*      */     dh = Mathlib.sin(theta + angle) * hypot;
/*      */     double d2 = (w / 2) + dw;
/*      */     xoff.setDouble(d2);
/*      */     double d1 = (h / 2) + dh;
/*      */     yoff.setDouble(d1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterResizeForRotation(Ptr sraster, int w, int h, Ptr newRaster, int wnew, int hnew, Ptr gc) {
/* 3517 */     yoff = 0; xoff = 0; i = 0; xoff = (wnew - w) / 2;
/* 3518 */     yoff = (hnew - h) / 2;
/*      */     
/* 3520 */     for (i = 0; i < hnew; i++) {
/* 3521 */       for (j = 0; j < wnew; j++) {
/* 3522 */         int n = (i * wnew + j) * 4; Ptr ptr = newRaster; int m = n, k = gc.getAlignedInt(1); ptr.setInt(m, k);
/*      */       } 
/*      */     } 
/* 3525 */     for (i = 0; i < h; i++) {
/* 3526 */       for (j = 0; j < w; j++) {
/* 3527 */         inew = i + yoff;
/* 3528 */         jnew = j + xoff;
/* 3529 */         int i2 = (inew * wnew + jnew) * 4; Ptr ptr2 = newRaster; int i1 = i2, n = (i * w + j) * 4; Ptr ptr1 = sraster; int m = n, k = ptr1.getInt(m); ptr2.setInt(i1, k);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void R_GE_rasterRotate(Ptr sraster, int w, int h, double angle, Ptr draster, Ptr gc, int smoothAlpha) {
/* 3561 */     cosa = 0.0D; sina = 0.0D; dline = BytePtr.of(0); dline$offset = 0; ydif = 0; hm2 = 0; wm2 = 0; ycen = 0; xcen = 0; i = 0; angle = -angle;
/*      */     
/* 3563 */     xcen = w / 2;
/* 3564 */     wm2 = w + -2;
/* 3565 */     ycen = h / 2;
/* 3566 */     hm2 = h + -2;
/* 3567 */     sina = Mathlib.sin(angle) * 16.0D;
/* 3568 */     cosa = Mathlib.cos(angle) * 16.0D;
/*      */     
/* 3570 */     for (i = 0; i < h; i++) {
/* 3571 */       ydif = ycen - i;
/* 3572 */       int k = i * w * 4; dline = draster; dline$offset = k;
/* 3573 */       for (j = 0; j < w; j++) {
/* 3574 */         xdif = xcen - j;
/* 3575 */         double d4 = -xdif * cosa, d3 = ydif * sina; xpm = (int)(d4 - d3);
/* 3576 */         double d2 = -ydif * cosa, d1 = xdif * sina; ypm = (int)(d2 + d1);
/* 3577 */         xp = (xpm >> 4) + xcen;
/* 3578 */         yp = (ypm >> 4) + ycen;
/* 3579 */         xf = xpm & 0xF;
/* 3580 */         yf = ypm & 0xF;
/*      */ 
/*      */         
/* 3583 */         if (xp >= 0 && yp >= 0 && xp <= wm2 && yp <= hm2) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3588 */           int i62 = yp * w * 4; sline = sraster; sline$offset = i62;
/*      */           
/* 3590 */           int i61 = xp * 4; Ptr ptr5 = sline; int i60 = sline$offset + i61; word00 = ptr5.getInt(i60);
/* 3591 */           int i59 = (xp + 1) * 4; Ptr ptr4 = sline; int i58 = sline$offset + i59; word10 = ptr4.getInt(i58);
/* 3592 */           w$3 = w; xp$4 = xp; int i57 = (w$3 + xp$4) * 4; Ptr ptr3 = sline; int i56 = sline$offset + i57; word01 = ptr3.getInt(i56);
/* 3593 */           w$5 = w; xp$6 = xp; int i55 = (w$5 + xp$6 + 1) * 4; Ptr ptr2 = sline; int i54 = sline$offset + i55; word11 = ptr2.getInt(i54);
/* 3594 */           int i53 = 16 - xf, i52 = 16 - yf, i51 = i53 * i52, i50 = word00 & 0xFF, i49 = i51 * i50;
/* 3595 */           int i48 = (16 - yf) * xf, i47 = word10 & 0xFF, i46 = i48 * i47;
/*      */           int i45 = i49 + i46;
/* 3597 */           int i44 = xf * yf, i43 = word11 & 0xFF, i42 = i44 * i43; int i41 = (16 - xf) * yf, i40 = word01 & 0xFF, i39 = i41 * i40, i38 = i42 + i39; rval = Integer.divideUnsigned(i45 + i38 + 128, 256);
/* 3598 */           int i37 = 16 - xf, i36 = 16 - yf, i35 = i37 * i36, i34 = word00 >>> 8 & 0xFF, i33 = i35 * i34;
/* 3599 */           int i32 = (16 - yf) * xf, i31 = word10 >>> 8 & 0xFF, i30 = i32 * i31;
/*      */           int i29 = i33 + i30;
/* 3601 */           int i28 = xf * yf, i27 = word11 >>> 8 & 0xFF, i26 = i28 * i27; int i25 = (16 - xf) * yf, i24 = word01 >>> 8 & 0xFF, i23 = i25 * i24, i22 = i26 + i23; gval = Integer.divideUnsigned(i29 + i22 + 128, 256);
/* 3602 */           int i21 = 16 - xf, i20 = 16 - yf, i19 = i21 * i20, i18 = word00 >>> 16 & 0xFF, i17 = i19 * i18;
/* 3603 */           int i16 = (16 - yf) * xf, i15 = word10 >>> 16 & 0xFF, i14 = i16 * i15;
/*      */           int i13 = i17 + i14;
/* 3605 */           int i12 = xf * yf, i11 = word11 >>> 16 & 0xFF, i10 = i12 * i11; int i9 = (16 - xf) * yf, i8 = word01 >>> 16 & 0xFF, i7 = i9 * i8, i6 = i10 + i7; bval = Integer.divideUnsigned(i13 + i6 + 128, 256);
/* 3606 */           if (smoothAlpha == 0)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */             
/* 3612 */             double d7 = Integer.toUnsignedLong(
/* 3613 */                 word11 >>> 24), d6 = Rmath.Rf_fmax2(Integer.toUnsignedLong(word01 >>> 24), d7), d5 = Integer.toUnsignedLong(word10 >>> 24); aval = (int)Rmath.Rf_fmax2(Rmath.Rf_fmax2(Integer.toUnsignedLong(word00 >>> 24), d5), d6); }
/*      */           else { int i78 = 16 - xf, i77 = 16 - yf, i76 = i78 * i77, i75 = word00 >>> 24, i74 = i76 * i75; int i73 = (16 - yf) * xf, i72 = word10 >>> 24, i71 = i73 * i72; int i70 = i74 + i71; int i69 = xf * yf, i68 = word11 >>> 24, i67 = i69 * i68; int i66 = (16 - xf) * yf, i65 = word01 >>> 24, i64 = i66 * i65, i63 = i67 + i64; aval = Integer.divideUnsigned(i70 + i63 + 128, 256); }
/* 3615 */            int i5 = j * 4; Ptr ptr1 = dline; int i4 = dline$offset + i5, i3 = gval << 8 | rval, i2 = bval << 16, i1 = i3 | i2, n = aval << 24, m = i1 | n; ptr1.setInt(i4, m);
/*      */         } else {
/*      */           int i1 = j * 4;
/*      */           Ptr ptr = dline;
/*      */           int n = dline$offset + i1, m = gc.getAlignedInt(1);
/*      */           ptr.setInt(n, m);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static {
/*      */     $GEstring_to_pch$last_ipch = 0;
/*      */     $GEstring_to_pch$last_pch = (SEXP)BytePtr.of(0).getArray();
/*      */     $GEMetricInfo$w = 0.0D;
/*      */     $GEMetricInfo$d = 0.0D;
/*      */     $GEMetricInfo$a = 0.0D;
/*      */     $GEMetricInfo$last_ps = 0.0D;
/*      */     $GEMetricInfo$last_cex = 0.0D;
/*      */     $GEMetricInfo$last_face = 1;
/*      */     $GEMetricInfo$last_close = BytePtr.of(0).toMethodHandle();
/*      */     $GEMetricInfo$last_dd = BytePtr.of(0);
/*      */     $GEMetricInfo$last_dd$offset = 0;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/baseEngine__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */