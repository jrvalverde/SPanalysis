/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.RecordUnitPtr;
/*     */ import org.renjin.gcc.runtime.Stdlib;
/*     */ import org.renjin.primitives.Native;
/*     */ import org.renjin.sexp.ListVector;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsDevices
/*     */ {
/*     */   public static Ptr newDevice(Ptr deviceClassPtr, SEXP deviceOptions) {
/*     */     Class<?> deviceClass;
/*     */     GraphicsDevice device;
/*  45 */     String deviceClassName = Stdlib.nullTerminatedString(deviceClassPtr);
/*     */ 
/*     */     
/*     */     try {
/*  49 */       deviceClass = Class.forName(deviceClassName);
/*  50 */     } catch (ClassNotFoundException e) {
/*  51 */       throw new EvalException("Could not find graphics device class '" + deviceClassName + "'", e);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  56 */       Constructor<?> constructor = deviceClass.getConstructor(new Class[] { Session.class, ListVector.class });
/*  57 */       Session session = Native.currentContext().getSession();
/*  58 */       device = (GraphicsDevice)constructor.newInstance(new Object[] { session, deviceOptions });
/*  59 */     } catch (Exception e) {
/*  60 */       throw new EvalException("Could not create graphics device", e);
/*     */     } 
/*     */     
/*  63 */     return (Ptr)new RecordUnitPtr(device);
/*     */   }
/*     */   
/*     */   public static void open(Ptr p, double w, double h) {
/*  67 */     ((GraphicsDevice)p.getArray()).open(w, h);
/*     */   }
/*     */   
/*     */   public static void close(Ptr p) {
/*  71 */     ((GraphicsDevice)p.getArray()).close();
/*     */   }
/*     */   
/*     */   public static void activate(Ptr p) {
/*  75 */     ((GraphicsDevice)p.getArray()).activate();
/*     */   }
/*     */   
/*     */   public static void circle(Ptr p, double x, double y, double r) {
/*  79 */     ((GraphicsDevice)p.getArray()).circle(x, y, r);
/*     */   }
/*     */   
/*     */   public static void clip(Ptr p, double x0, double x1, double y0, double y1) {
/*  83 */     ((GraphicsDevice)p.getArray()).clip(x0, x1, y0, y1);
/*     */   }
/*     */   
/*     */   public static void deactivate(Ptr p) {
/*  87 */     ((GraphicsDevice)p.getArray()).deactivate();
/*     */   }
/*     */   
/*     */   public static void hold(Ptr p) {
/*  91 */     ((GraphicsDevice)p.getArray()).hold();
/*     */   }
/*     */   
/*     */   public static void flush(Ptr p, boolean hold) {
/*  95 */     ((GraphicsDevice)p.getArray()).flush(hold);
/*     */   }
/*     */   
/*     */   public static Ptr locator(Ptr p) {
/*  99 */     return ((GraphicsDevice)p.getArray()).locator();
/*     */   }
/*     */   
/*     */   public static void line(Ptr p, double x1, double y1, double x2, double y2) {
/* 103 */     ((GraphicsDevice)p.getArray()).line(x1, y1, x2, y2);
/*     */   }
/*     */   
/*     */   public static Ptr metricInfo(Ptr p, int c) {
/* 107 */     return (Ptr)new DoublePtr(((GraphicsDevice)p.getArray()).metricInfo(c));
/*     */   }
/*     */   
/*     */   public static void mode(Ptr p, int mode) {
/* 111 */     ((GraphicsDevice)p.getArray()).mode(mode);
/*     */   }
/*     */   
/*     */   public static void newPage(Ptr p, int deviceNumber) {
/* 115 */     ((GraphicsDevice)p.getArray()).newPage(deviceNumber);
/*     */   }
/*     */   
/*     */   public static void path(Ptr p, int npoly, Ptr nper, Ptr x, Ptr y, boolean winding) {
/* 119 */     ((GraphicsDevice)p.getArray()).path(npoly, nper, x, y, winding);
/*     */   }
/*     */   
/*     */   public static void polygon(Ptr p, int n, Ptr x, Ptr y) {
/* 123 */     ((GraphicsDevice)p.getArray()).polygon(n, x, y);
/*     */   }
/*     */   
/*     */   public static void polyline(Ptr p, int n, Ptr x, Ptr y) {
/* 127 */     ((GraphicsDevice)p.getArray()).polyline(n, x, y);
/*     */   }
/*     */   
/*     */   public static void rect(Ptr p, double x0, double y0, double x1, double y1) {
/* 131 */     ((GraphicsDevice)p.getArray()).rect(x0, y0, x1, y1);
/*     */   }
/*     */   
/*     */   public static Ptr size(Ptr p) {
/* 135 */     return (Ptr)new DoublePtr(((GraphicsDevice)p.getArray()).size());
/*     */   }
/*     */   
/*     */   public static double strWidth(Ptr p, Ptr str) {
/* 139 */     return ((GraphicsDevice)p.getArray()).strWidth(Stdlib.nullTerminatedString(str));
/*     */   }
/*     */   
/*     */   public static void text(Ptr p, double x, double y, Ptr str, double rot, double hadj) {
/* 143 */     ((GraphicsDevice)p.getArray()).text(x, y, Stdlib.nullTerminatedString(str), rot, hadj);
/*     */   }
/*     */   
/*     */   public static void raster(Ptr p, Ptr raster, int w, int h, double x, double y, double width, double height, double rot, int interpolate) {
/* 147 */     ((GraphicsDevice)p.getArray()).raster(raster, w, h, x, y, width, height, rot, (interpolate != 0));
/*     */   }
/*     */   
/*     */   public static void setColor(Ptr p, int color) {
/* 151 */     ((GraphicsDevice)p.getArray()).setColor(color);
/*     */   }
/*     */   
/*     */   public static void setFill(Ptr p, int color) {
/* 155 */     ((GraphicsDevice)p.getArray()).setFill(color);
/*     */   }
/*     */   
/*     */   public static void setLine(Ptr p, double lwd, int lty) {
/* 159 */     ((GraphicsDevice)p.getArray()).setLine(lwd, lty);
/*     */   }
/*     */   
/*     */   public static void setFont(Ptr p, double cex, double ps, double lineheight, int fontface, Ptr fontfamily) {
/* 163 */     ((GraphicsDevice)p.getArray()).setFont(cex, ps, lineheight, fontface, Stdlib.nullTerminatedString(fontfamily));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GraphicsDevices.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */