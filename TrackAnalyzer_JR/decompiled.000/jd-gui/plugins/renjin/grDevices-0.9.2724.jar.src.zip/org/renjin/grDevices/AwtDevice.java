/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import org.renjin.eval.Session;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.sexp.ListVector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AwtDevice
/*     */   extends GraphicsDevice
/*     */   implements WindowListener
/*     */ {
/*     */   private Frame frame;
/*  47 */   private final LocatorSync locator = new LocatorSync();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(double w, double h) {
/*  65 */     if (this.frame != null) {
/*  66 */       close();
/*     */     }
/*     */     
/*  69 */     AwtContainer awtContainer = new AwtContainer((int)w, (int)h);
/*  70 */     awtContainer.getPanel().addMouseListener(this.locator);
/*     */     
/*  72 */     this.container = awtContainer;
/*     */     
/*  74 */     this.frame = new Frame("Renjin");
/*  75 */     this.frame.setSize(new Dimension((int)w, (int)h));
/*  76 */     this.frame.setResizable(false);
/*  77 */     this.frame.add(awtContainer.getPanel());
/*  78 */     this.frame.setVisible(true);
/*  79 */     this.frame.addWindowListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void activate() {
/*  84 */     super.activate();
/*  85 */     if (this.frame != null) {
/*  86 */       this.frame.requestFocus();
/*  87 */       this.frame.setTitle("Renjin " + ((this.deviceNumber > 0) ? ("(" + (this.deviceNumber + 1) + ")") : "") + " *active*");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  93 */     super.close();
/*  94 */     if (this.frame != null) {
/*  95 */       this.container = null;
/*  96 */       this.frame.removeAll();
/*  97 */       this.frame.dispose();
/*  98 */       this.frame = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deactivate() {
/* 104 */     super.deactivate();
/* 105 */     if (this.frame != null) {
/* 106 */       this.frame.setTitle("Renjin " + ((this.deviceNumber > 0) ? ("(" + (this.deviceNumber + 1) + ")") : ""));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void newPage(int deviceNumber) {
/* 112 */     super.newPage(deviceNumber);
/* 113 */     if (this.frame != null) {
/* 114 */       this.frame.setTitle("Renjin (" + (deviceNumber + 1) + ")" + (isActive() ? " *active*" : ""));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Ptr locator() {
/* 120 */     return (Ptr)this.locator
/* 121 */       .waitForClick()
/* 122 */       .map(p -> new DoublePtr(new double[] { p.getX(), p.getX()
/* 123 */           })).orElse(DoublePtr.NULL);
/*     */   }
/*     */   
/*     */   public void windowClosing(WindowEvent e) {}
/*     */   
/*     */   public void windowClosed(WindowEvent e) {}
/*     */   
/*     */   public void windowOpened(WindowEvent e) {}
/*     */   
/*     */   public void windowIconified(WindowEvent e) {}
/*     */   
/*     */   public void windowDeiconified(WindowEvent e) {}
/*     */   
/*     */   public void windowActivated(WindowEvent e) {}
/*     */   
/*     */   public void windowDeactivated(WindowEvent e) {}
/*     */   
/*     */   public AwtDevice(Session session, ListVector options) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/AwtDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */