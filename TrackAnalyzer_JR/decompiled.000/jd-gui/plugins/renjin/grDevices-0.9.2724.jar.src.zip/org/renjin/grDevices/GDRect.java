/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GDRect
/*     */   implements GDObject
/*     */ {
/*     */   private double x1;
/*     */   private double y1;
/*     */   private double x2;
/*     */   private double y2;
/*     */   
/*     */   public GDRect(double x1, double y1, double x2, double y2) {
/* 105 */     if (x1 > x2) {
/* 106 */       double tmp = x1;
/* 107 */       x1 = x2;
/* 108 */       x2 = tmp;
/*     */     } 
/* 110 */     if (y1 > y2) {
/* 111 */       double tmp = y1;
/* 112 */       y1 = y2;
/* 113 */       y2 = tmp;
/*     */     } 
/* 115 */     this.x1 = x1;
/* 116 */     this.y1 = y1;
/* 117 */     this.x2 = x2;
/* 118 */     this.y2 = y2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Component c, GDState gs, Graphics g) {
/* 123 */     int x = (int)(this.x1 + 0.5D);
/* 124 */     int y = (int)(this.y1 + 0.5D);
/* 125 */     int w = (int)(this.x2 + 0.5D) - x;
/* 126 */     int h = (int)(this.y2 + 0.5D) - y;
/* 127 */     if (gs.getFill() != null) {
/* 128 */       g.setColor(gs.getFill());
/* 129 */       g.fillRect(x, y, w + 1, h + 1);
/* 130 */       if (gs.getCol() != null) {
/* 131 */         g.setColor(gs.getCol());
/*     */       }
/*     */     } 
/* 134 */     if (gs.getCol() != null)
/* 135 */       g.drawRect(x, y, w, h); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GDRect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */