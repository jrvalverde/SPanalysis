/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Colors
/*    */ {
/*    */   public static Color valueOf(int col) {
/* 30 */     return new Color((col & 0xFF) / 255.0F, (col >> 8 & 0xFF) / 255.0F, (col >> 16 & 0xFF) / 255.0F, (col >> 24 & 0xFF) / 255.0F);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/Colors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */