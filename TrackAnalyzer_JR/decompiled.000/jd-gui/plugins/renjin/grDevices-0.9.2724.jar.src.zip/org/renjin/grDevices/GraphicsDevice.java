/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import org.renjin.gcc.runtime.DoublePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GraphicsDevice
/*     */ {
/*     */   private boolean active = false;
/*     */   private boolean holding = false;
/*  54 */   int deviceNumber = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected GDContainer container = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void open(double paramDouble1, double paramDouble2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activate() {
/*  75 */     this.active = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void circle(double x, double y, double r) {
/*  86 */     if (this.container == null)
/*  87 */       return;  this.container.add(new GDCircle(x, y, r));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clip(double x0, double x1, double y0, double y1) {
/*  99 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 102 */     this.container.add(new GDClip(x0, y0, x1, y1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 109 */     if (this.container != null) {
/* 110 */       this.container.closeDisplay();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deactivate() {
/* 118 */     this.active = false;
/*     */   }
/*     */   
/*     */   public boolean isActive() {
/* 122 */     return this.active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hold() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush(boolean flush) {
/* 141 */     this.holding = !flush;
/* 142 */     if (flush && this.container != null) {
/* 143 */       this.container.syncDisplay(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ptr locator() {
/* 153 */     return (Ptr)DoublePtr.NULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void line(double x1, double y1, double x2, double y2) {
/* 165 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 168 */     this.container.add(new GDLine(x1, y1, x2, y2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] metricInfo(int ch) {
/* 178 */     double[] res = new double[3];
/* 179 */     double ascent = 0.0D;
/* 180 */     double descent = 0.0D;
/* 181 */     double width = 8.0D;
/*     */     
/* 183 */     if (this.container != null) {
/* 184 */       Graphics g = this.container.getGraphics();
/* 185 */       if (g != null) {
/* 186 */         Font f = this.container.getGState().getFont();
/* 187 */         if (f != null) {
/* 188 */           FontMetrics fm = g.getFontMetrics(this.container.getGState().getFont());
/* 189 */           if (fm != null) {
/* 190 */             ascent = fm.getAscent();
/* 191 */             descent = fm.getDescent();
/* 192 */             width = fm.charWidth((ch == 0) ? 77 : ch);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 197 */     res[0] = ascent;
/* 198 */     res[1] = descent;
/* 199 */     res[2] = width;
/* 200 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mode(int mode) {
/* 209 */     if (!this.holding && this.container != null) this.container.syncDisplay((mode == 0));
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void newPage() {
/* 216 */     if (this.container != null) this.container.reset();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void newPage(int devNr) {
/* 225 */     this.deviceNumber = devNr;
/* 226 */     if (this.container != null) {
/* 227 */       this.container.reset();
/* 228 */       this.container.setDeviceNumber(devNr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void path(int npoly, Ptr nper, Ptr x, Ptr y, boolean winding) {
/* 241 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 244 */     this.container.add(new GDPath(npoly, nper, x, y, winding));
/*     */   }
/*     */   
/*     */   public void polygon(int n, Ptr x, Ptr y) {
/* 248 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 251 */     this.container.add(new GDPolygon(n, x, y, false));
/*     */   }
/*     */   
/*     */   public void polyline(int n, Ptr x, Ptr y) {
/* 255 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 258 */     this.container.add(new GDPolygon(n, x, y, true));
/*     */   }
/*     */   
/*     */   public void rect(double x0, double y0, double x1, double y1) {
/* 262 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 265 */     this.container.add(new GDRect(x0, y0, x1, y1));
/*     */   }
/*     */   
/*     */   public void raster(Ptr image, int imageWidth, int imageHeight, double x, double y, double w, double h, double rot, boolean interpolate) {
/* 269 */     if (this.container == null) {
/*     */       return;
/*     */     }
/* 272 */     this.container.add(new GDRaster(image, imageWidth, imageHeight, x, y, w, h, rot, interpolate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] size() {
/* 281 */     double[] res = new double[4];
/* 282 */     double width = 0.0D;
/* 283 */     double height = 0.0D;
/* 284 */     if (this.container != null) {
/* 285 */       Dimension d = this.container.getSize();
/* 286 */       width = d.getWidth();
/* 287 */       height = d.getHeight();
/*     */     } 
/* 289 */     res[0] = 0.0D;
/* 290 */     res[1] = width;
/* 291 */     res[2] = height;
/* 292 */     res[3] = 0.0D;
/* 293 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double strWidth(String str) {
/* 303 */     double width = (8 * str.length());
/* 304 */     if (this.container != null) {
/* 305 */       Graphics g = this.container.getGraphics();
/* 306 */       if (g != null) {
/* 307 */         Font f = this.container.getGState().getFont();
/* 308 */         if (f != null) {
/* 309 */           FontMetrics fm = g.getFontMetrics(f);
/* 310 */           if (fm != null) width = fm.stringWidth(str); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 314 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(double x, double y, String str, double rot, double hadj) {
/* 328 */     if (this.container == null)
/* 329 */       return;  this.container.add(new GDText(x, y, rot, hadj, str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(int cc) {
/* 340 */     if (this.container == null)
/* 341 */       return;  this.container.add(new GDColor(cc));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFill(int cc) {
/* 350 */     if (this.container == null)
/* 351 */       return;  this.container.add(new GDFill(cc));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLine(double lwd, int lty) {
/* 361 */     if (this.container == null)
/* 362 */       return;  this.container.add(new GDLinePar(lwd, lty));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(double cex, double ps, double lineheight, int fontface, String fontfamily) {
/* 377 */     if (this.container == null)
/* 378 */       return;  GDFont f = new GDFont(cex, ps, lineheight, fontface, fontfamily);
/* 379 */     this.container.add(f);
/* 380 */     this.container.getGState().setFont(f.getFont());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDeviceNumber() {
/* 389 */     return (this.container == null) ? this.deviceNumber : this.container.getDeviceNumber();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GraphicsDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */