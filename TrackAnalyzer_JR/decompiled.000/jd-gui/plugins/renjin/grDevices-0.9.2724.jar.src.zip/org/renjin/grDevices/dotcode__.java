/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*    */ import org.renjin.gnur.api.Defn;
/*    */ import org.renjin.gnur.api.Internal;
/*    */ import org.renjin.gnur.api.Rinternals;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class dotcode__
/*    */ {
/*    */   static {
/*    */   
/*    */   }
/*    */   
/*    */   public static SEXP do_Externalgr(SEXP call, SEXP op, SEXP args, SEXP env) {
/* 46 */     args = Rinternals.CDR(args);
/* 47 */     op = Defn.R_Primitive((Ptr)new BytePtr(".External\000".getBytes(), 0));
/*    */ 
/*    */     
/* 50 */     dd = baseDevices__.GEcurrentDevice();
/* 51 */     record = dd.getInt(24);
/* 52 */     dd.setInt(24, 0);
/* 53 */     retval = Internal.do_External(call, op, args, env); Rinternals.Rf_protect(retval);
/* 54 */     dd.setInt(24, record);
/* 55 */     if (baseEngine__.GErecording(call, dd) != 0)
/* 56 */     { if (baseEngine__.GEcheckState(dd) != 0)
/*    */       
/* 58 */       { baseEngine__.GErecordGraphicOperation(op, args, dd);
/*    */ 
/*    */         
/* 61 */         return retval; }  throw new UnsatisfiedLinkException("_"); }  return retval;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SEXP do_dotcallgr(SEXP call, SEXP op, SEXP args, SEXP env) {
/* 69 */     args = Rinternals.CDR(args);
/* 70 */     op = Defn.R_Primitive((Ptr)new BytePtr(".Call\000".getBytes(), 0));
/*    */ 
/*    */     
/* 73 */     dd = baseDevices__.GEcurrentDevice();
/* 74 */     record = dd.getInt(24);
/* 75 */     dd.setInt(24, 0);
/* 76 */     retval = Internal.do_dotcall(call, op, args, env); Rinternals.Rf_protect(retval);
/* 77 */     dd.setInt(24, record);
/* 78 */     if (baseEngine__.GErecording(call, dd) != 0)
/* 79 */     { if (baseEngine__.GEcheckState(dd) != 0)
/*    */       
/* 81 */       { baseEngine__.GErecordGraphicOperation(op, args, dd);
/*    */ 
/*    */         
/* 84 */         return retval; }  throw new UnsatisfiedLinkException("_"); }  return retval;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/dotcode__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */