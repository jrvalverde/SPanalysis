/*      */ package org.renjin.grDevices;
/*      */ 
/*      */ import org.renjin.gcc.runtime.Builtins;
/*      */ import org.renjin.gcc.runtime.BytePtr;
/*      */ import org.renjin.gcc.runtime.DoublePtr;
/*      */ import org.renjin.gcc.runtime.IntPtr;
/*      */ import org.renjin.gcc.runtime.Mathlib;
/*      */ import org.renjin.gcc.runtime.Ptr;
/*      */ import org.renjin.gcc.runtime.Stdlib;
/*      */ import org.renjin.gcc.runtime.Stdlib2;
/*      */ import org.renjin.gnur.api.Arith;
/*      */ import org.renjin.gnur.api.Error;
/*      */ import org.renjin.gnur.api.GetText;
/*      */ import org.renjin.gnur.api.Rinternals;
/*      */ import org.renjin.gnur.api.Rinternals2;
/*      */ import org.renjin.sexp.SEXP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class colors__
/*      */ {
/*      */   public static byte[] $incol2name$ColBuf = new byte[10];
/*      */   
/*      */   public static Ptr RGB2rgb(int r, int g, int b) {
/*   38 */     Context.get__colors$ColBuf()[0] = (byte)35;
/*   39 */     int i1 = r >>> 4 & 0xF; byte b6 = Context.get__colors$HexDigits()[i1]; Context.get__colors$ColBuf()[1] = b6;
/*   40 */     int n = r & 0xF; byte b5 = Context.get__colors$HexDigits()[n]; Context.get__colors$ColBuf()[2] = b5;
/*   41 */     int m = g >>> 4 & 0xF; byte b4 = Context.get__colors$HexDigits()[m]; Context.get__colors$ColBuf()[3] = b4;
/*   42 */     int k = g & 0xF; byte b3 = Context.get__colors$HexDigits()[k]; Context.get__colors$ColBuf()[4] = b3;
/*   43 */     int j = b >>> 4 & 0xF; byte b2 = Context.get__colors$HexDigits()[j]; Context.get__colors$ColBuf()[5] = b2;
/*   44 */     int i = b & 0xF; byte b1 = Context.get__colors$HexDigits()[i]; Context.get__colors$ColBuf()[6] = b1;
/*   45 */     Context.get__colors$ColBuf()[7] = (byte)0;
/*   46 */     return (Ptr)new BytePtr(Context.get__colors$ColBuf(), 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ptr RGBA2rgb(int r, int g, int b, int a) {
/*   52 */     Context.get__colors$ColBuf()[0] = (byte)35;
/*   53 */     int i3 = r >>> 4 & 0xF; byte b8 = Context.get__colors$HexDigits()[i3]; Context.get__colors$ColBuf()[1] = b8;
/*   54 */     int i2 = r & 0xF; byte b7 = Context.get__colors$HexDigits()[i2]; Context.get__colors$ColBuf()[2] = b7;
/*   55 */     int i1 = g >>> 4 & 0xF; byte b6 = Context.get__colors$HexDigits()[i1]; Context.get__colors$ColBuf()[3] = b6;
/*   56 */     int n = g & 0xF; byte b5 = Context.get__colors$HexDigits()[n]; Context.get__colors$ColBuf()[4] = b5;
/*   57 */     int m = b >>> 4 & 0xF; byte b4 = Context.get__colors$HexDigits()[m]; Context.get__colors$ColBuf()[5] = b4;
/*   58 */     int k = b & 0xF; byte b3 = Context.get__colors$HexDigits()[k]; Context.get__colors$ColBuf()[6] = b3;
/*   59 */     int j = a >>> 4 & 0xF; byte b2 = Context.get__colors$HexDigits()[j]; Context.get__colors$ColBuf()[7] = b2;
/*   60 */     int i = a & 0xF; byte b1 = Context.get__colors$HexDigits()[i]; Context.get__colors$ColBuf()[8] = b1;
/*   61 */     Context.get__colors$ColBuf()[9] = (byte)0;
/*   62 */     return (Ptr)new BytePtr(Context.get__colors$ColBuf(), 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ScaleColor(double x) {
/*   68 */     if (Arith.R_IsNA(x) != 0)
/*   69 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("color intensity %s, not in [0,1]\000".getBytes(), 0)), new Object[] { new BytePtr("NA\000".getBytes(), 0) }); 
/*   70 */     if (Arith.R_finite(x) == 0 || x < 0.0D || x > 1.0D)
/*   71 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("color intensity %g, not in [0,1]\000".getBytes(), 0)), new Object[] { Double.valueOf(x) }); 
/*   72 */     return (int)(long)(x * 255.0D + 0.5D);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int CheckColor(int x) {
/*   77 */     R_NaInt$89 = Arith.R_NaInt; if (x == R_NaInt$89)
/*   78 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("color intensity %s, not in 0:255\000".getBytes(), 0)), new Object[] { new BytePtr("NA\000".getBytes(), 0) }); 
/*   79 */     if (x < 0 || x > 255)
/*   80 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("color intensity %d, not in 0:255\000".getBytes(), 0)), new Object[] { Integer.valueOf(x) }); 
/*   81 */     return x;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int ScaleAlpha(double x) {
/*   86 */     if (Arith.R_IsNA(x) != 0)
/*   87 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("alpha level %s, not in [0,1]\000".getBytes(), 0)), new Object[] { new BytePtr("NA\000".getBytes(), 0) }); 
/*   88 */     if (Arith.R_finite(x) == 0 || x < 0.0D || x > 1.0D)
/*   89 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("alpha level %g, not in [0,1]\000".getBytes(), 0)), new Object[] { Double.valueOf(x) }); 
/*   90 */     return (int)(long)(x * 255.0D + 0.5D);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int CheckAlpha(int x) {
/*   95 */     R_NaInt$88 = Arith.R_NaInt; if (x == R_NaInt$88)
/*   96 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("alpha level %s, not in 0:255\000".getBytes(), 0)), new Object[] { new BytePtr("NA\000".getBytes(), 0) }); 
/*   97 */     if (x < 0 || x > 255)
/*   98 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("alpha level %d, not in 0:255\000".getBytes(), 0)), new Object[] { Integer.valueOf(x) }); 
/*   99 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void hsv2rgb(double h, double s, double v, Ptr r, Ptr g, Ptr b) {
/*  112 */     t = new double[1]; t[0] = 0.0D; if (Arith.R_finite(h) == 0 || Arith.R_finite(s) == 0 || Arith.R_finite(v) == 0)
/*  113 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("inputs must be finite\000".getBytes(), 0)), new Object[0]); 
/*  114 */     f = Mathlib.modf(h * 6.0D, new DoublePtr(t, 0));
/*  115 */     i = (int)t[0] % 6;
/*      */     
/*  117 */     p = (1.0D - s) * v;
/*  118 */     double d2 = s * f; q = (1.0D - d2) * v;
/*  119 */     double d1 = (1.0D - f) * s; t$84 = (1.0D - d1) * v; t[0] = t$84;
/*  120 */     switch (i) { case 0:
/*  121 */         r.setDouble(v); t$85 = t[0]; g.setDouble(t$85); b.setDouble(p); break;
/*  122 */       case 1: r.setDouble(q); g.setDouble(v); b.setDouble(p); break;
/*  123 */       case 2: r.setDouble(p); g.setDouble(v); t$86 = t[0]; b.setDouble(t$86); break;
/*  124 */       case 3: r.setDouble(p); g.setDouble(q); b.setDouble(v); break;
/*  125 */       case 4: t$87 = t[0]; r.setDouble(t$87); g.setDouble(p); b.setDouble(v); break;
/*  126 */       case 5: r.setDouble(v); g.setDouble(p); b.setDouble(q); break;
/*      */       default:
/*  128 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("bad hsv to rgb color conversion\000".getBytes(), 0)), new Object[0]); break; }
/*      */     
/*  130 */     Stdlib.printf(new BytePtr("b = %f\n\000".getBytes(), 0), new Object[] { b });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rgb2hsv(double r, double g, double b, Ptr h, Ptr s, Ptr v) {
/*  141 */     r_max = 1; b_max = 0;
/*      */     
/*  143 */     min = max = r;
/*  144 */     if (min <= g)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  153 */       if (b <= g)
/*      */       
/*      */       { 
/*  156 */         max = g; r_max = 0;
/*  157 */         if (b < r) min = b;  } else { max = b; b_max = 1; r_max = 0; }  }
/*      */     else if (b >= g) { min = g; if (b > r) { max = b; b_max = 1; r_max = 0; }
/*      */        }
/*      */     else { min = b; }
/*  161 */      v.setDouble(max);
/*  162 */     if (max != 0.0D) { delta = max - min; if (delta != 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  168 */         double d2 = delta / max; s.setDouble(d2);
/*      */         
/*  170 */         if (r_max == 0)
/*      */         
/*  172 */         { if (b_max == 0)
/*      */           
/*      */           { 
/*  175 */             double d3 = (b - r) / delta + 2.0D; h.setDouble(d3); } else { double d3 = (r - g) / delta + 4.0D; h.setDouble(d3); }  }
/*      */         else { double d3 = (g - b) / delta; h.setDouble(d3); }
/*  177 */          double d1 = h.getDouble() / 6.0D; h.setDouble(d1);
/*  178 */         if (h.getDouble() < 0.0D) {
/*  179 */           double d3 = h.getDouble() + 1.0D; h.setDouble(d3);
/*      */         } 
/*      */         return;
/*      */       }  }
/*      */     
/*      */     h.setDouble(0.0D);
/*      */     double d = h.getDouble();
/*  186 */     s.setDouble(d); } public static SEXP hsv(SEXP h, SEXP s, SEXP v, SEXP a) { b = new double[1]; g = new double[1]; r = new double[1]; c = (SEXP)BytePtr.of(0).getArray(); na = 0; nv = 0; ns = 0; nh = 0; max = 0; b[0] = 0.0D; g[0] = 0.0D; r[0] = 0.0D; r[0] = 0.0D; g[0] = 0.0D; b[0] = 0.0D;
/*  187 */     na = 1;
/*      */     
/*  189 */     h = Rinternals.Rf_coerceVector(h, 14); Rinternals.Rf_protect(h);
/*  190 */     s = Rinternals.Rf_coerceVector(s, 14); Rinternals.Rf_protect(s);
/*  191 */     v = Rinternals.Rf_coerceVector(v, 14); Rinternals.Rf_protect(v);
/*  192 */     if (Rinternals.TYPEOF(a) != 0) {
/*  193 */       a = Rinternals.Rf_coerceVector(a, 14);
/*  194 */       na = Rinternals.XLENGTH(a);
/*      */     } 
/*  196 */     Rinternals.Rf_protect(a);
/*      */     
/*  198 */     nh = Rinternals.XLENGTH(h);
/*  199 */     ns = Rinternals.XLENGTH(s);
/*  200 */     nv = Rinternals.XLENGTH(v);
/*  201 */     if (nh > 0 && ns > 0 && nv > 0 && na > 0) {
/*      */ 
/*      */ 
/*      */       
/*  205 */       max = nh;
/*  206 */       if (max < ns) max = ns; 
/*  207 */       if (max < nv) max = nv; 
/*  208 */       if (max < na) max = na; 
/*  209 */       c = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, max));
/*  210 */       if (max != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  215 */         if (Rinternals.TYPEOF(a) != 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  228 */           for (i = 0; i < max; i++) {
/*  229 */             Ptr ptr8 = Rinternals2.REAL(h); int i7 = i % nh * 8; Ptr ptr7 = ptr8; int i6 = 0 + i7; hh = ptr7.getDouble(i6);
/*  230 */             Ptr ptr6 = Rinternals2.REAL(s); int i5 = i % ns * 8; Ptr ptr5 = ptr6; int i4 = 0 + i5; ss = ptr5.getDouble(i4);
/*  231 */             Ptr ptr4 = Rinternals2.REAL(v); int i3 = i % nv * 8; Ptr ptr3 = ptr4; int i2 = 0 + i3; vv = ptr3.getDouble(i2);
/*  232 */             Ptr ptr2 = Rinternals2.REAL(a); int i1 = i % na * 8; Ptr ptr1 = ptr2; int n = 0 + i1; aa = ptr1.getDouble(n);
/*  233 */             if (hh < 0.0D || hh > 1.0D || ss < 0.0D || ss > 1.0D || vv < 0.0D || vv > 1.0D || aa < 0.0D || 
/*  234 */               aa > 1.0D)
/*  235 */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid hsv color\000".getBytes(), 0)), new Object[0]); 
/*  236 */             hsv2rgb(hh, ss, vv, (Ptr)new DoublePtr(r, 0), (Ptr)new DoublePtr(g, 0), (Ptr)new DoublePtr(b, 0));
/*  237 */             int m = ScaleAlpha(aa), k = ScaleColor(b[0]), j = ScaleColor(g[0]); SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(ScaleColor(r[0]), j, k, m)); Rinternals.SET_STRING_ELT(c, i, sEXP);
/*      */           }  }
/*      */         else { for (i = 0; i < max; i++) { Ptr ptr6 = Rinternals2.REAL(h); int i4 = i % nh * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; hh = ptr5.getDouble(i3); Ptr ptr4 = Rinternals2.REAL(s); int i2 = i % ns * 8; Ptr ptr3 = ptr4; int i1 = 0 + i2; ss = ptr3.getDouble(i1); Ptr ptr2 = Rinternals2.REAL(v); int n = i % nv * 8; Ptr ptr1 = ptr2; int m = 0 + n; vv = ptr1.getDouble(m); if (hh < 0.0D || hh > 1.0D || ss < 0.0D || ss > 1.0D || vv < 0.0D || vv > 1.0D)
/*      */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid hsv color\000".getBytes(), 0)), new Object[0]);  hsv2rgb(hh, ss, vv, (Ptr)new DoublePtr(r, 0), (Ptr)new DoublePtr(g, 0), (Ptr)new DoublePtr(b, 0)); int k = ScaleColor(b[0]), j = ScaleColor(g[0]); SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(ScaleColor(r[0]), j, k)); Rinternals.SET_STRING_ELT(c, i, sEXP); }
/*      */            }
/*  242 */          return c;
/*      */       } 
/*      */       return c;
/*      */     } 
/*      */     return Rinternals.Rf_allocVector(16, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double gtrans(double u) {
/*  259 */     return (u <= 0.00304D) ? (
/*      */ 
/*      */       
/*  262 */       u * 12.92D) : (Mathlib.pow(u, 0.4166666666666667D) * 1.055D - 0.055D);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int FixupColor(Ptr r, Ptr g, Ptr b) {
/*  267 */     fix = 0;
/*  268 */     if (r.getInt() >= 0) { if (r.getInt() > 255) { r.setInt(255); fix = 1; }  } else { r.setInt(0); fix = 1; }
/*  269 */      if (g.getInt() >= 0) { if (g.getInt() > 255) { g.setInt(255); fix = 1; }  } else { g.setInt(0); fix = 1; }
/*  270 */      if (b.getInt() >= 0) { if (b.getInt() > 255) { b.setInt(255); fix = 1; }
/*  271 */        return fix; }  b.setInt(0); fix = 1; return fix;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void hcl2rgb(double h, double c, double l, Ptr R, Ptr G, Ptr B) {
/*  277 */     if (l > 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  287 */       h *= 0.017453292519943295D;
/*  288 */       L = l;
/*  289 */       U = Mathlib.cos(h) * c;
/*  290 */       V = Mathlib.sin(h) * c;
/*      */ 
/*      */ 
/*      */       
/*  294 */       if (L > 0.0D || U != 0.0D || V != 0.0D) {
/*      */ 
/*      */ 
/*      */         
/*  298 */         if (L <= 7.999592D) { iftmp$76 = L / 903.3D * 100.0D; } else { iftmp$76 = Mathlib.pow((L + 16.0D) / 116.0D, 3.0D) * 100.0D; }  Y = iftmp$76;
/*  299 */         double d25 = L * 13.0D; u = U / d25 + 0.1978398D;
/*  300 */         double d24 = L * 13.0D; v = V / d24 + 0.4683363D;
/*  301 */         double d23 = Y * 9.0D * u, d22 = v * 4.0D; X = d23 / d22;
/*  302 */         double d21 = -X / 3.0D, d20 = Y * 5.0D, d19 = d21 - d20, d18 = Y * 3.0D / v; Z = d19 + d18;
/*      */       } else {
/*      */         X = 0.0D; Y = 0.0D;
/*      */         Z = 0.0D;
/*      */       } 
/*  307 */       double d17 = X * 3.240479D, d16 = Y * 1.53715D, d15 = d17 - d16, d14 = Z * 0.498535D, d13 = gtrans((d15 - d14) / 100.0D); R.setDouble(d13);
/*  308 */       double d12 = X * -0.969256D, d11 = Y * 1.875992D, d10 = d12 + d11, d9 = Z * 0.041556D, d8 = gtrans((d10 + d9) / 100.0D); G.setDouble(d8);
/*  309 */       double d7 = X * 0.055648D, d6 = Y * 0.204043D, d5 = d7 - d6, d4 = Z * 1.057311D, d3 = gtrans((d5 + d4) / 100.0D); B.setDouble(d3);
/*      */       return;
/*      */     } 
/*      */     B.setDouble(0.0D);
/*      */     double d2 = B.getDouble();
/*      */     G.setDouble(d2);
/*      */     double d1 = G.getDouble();
/*  316 */     R.setDouble(d1); } public static SEXP hcl(SEXP h, SEXP c, SEXP l, SEXP a, SEXP sfixup) { ib = new int[1]; ig = new int[1]; ir = new int[1]; b = new double[1]; g = new double[1]; r = new double[1]; ans = (SEXP)BytePtr.of(0).getArray(); fixup = 0; max = 0; na = 0; nl = 0; nc = 0; nh = 0; b[0] = 0.0D; g[0] = 0.0D; r[0] = 0.0D; na = 1;
/*      */ 
/*      */ 
/*      */     
/*  320 */     h = Rinternals.Rf_coerceVector(h, 14); Rinternals.Rf_protect(h);
/*  321 */     c = Rinternals.Rf_coerceVector(c, 14); Rinternals.Rf_protect(c);
/*  322 */     l = Rinternals.Rf_coerceVector(l, 14); Rinternals.Rf_protect(l);
/*  323 */     if (Rinternals.TYPEOF(a) != 0) {
/*  324 */       a = Rinternals.Rf_coerceVector(a, 14);
/*  325 */       na = Rinternals.XLENGTH(a);
/*      */     } 
/*  327 */     Rinternals.Rf_protect(a);
/*  328 */     fixup = Rinternals.Rf_asLogical(sfixup);
/*  329 */     nh = Rinternals.XLENGTH(h);
/*  330 */     nc = Rinternals.XLENGTH(c);
/*  331 */     nl = Rinternals.XLENGTH(l);
/*  332 */     if (nh > 0 && nc > 0 && nl > 0 && na > 0) {
/*      */ 
/*      */ 
/*      */       
/*  336 */       max = nh;
/*  337 */       if (max < nc) max = nc; 
/*  338 */       if (max < nl) max = nl; 
/*  339 */       if (max < na) max = na; 
/*  340 */       ans = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, max));
/*  341 */       if (Rinternals.TYPEOF(a) != 0)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  359 */         for (i = 0; i < max; i++)
/*  360 */         { Ptr ptr8 = Rinternals2.REAL(h); int i4 = i % nh * 8; Ptr ptr7 = ptr8; int i3 = 0 + i4; H = ptr7.getDouble(i3);
/*  361 */           Ptr ptr6 = Rinternals2.REAL(c); int i2 = i % nc * 8; Ptr ptr5 = ptr6; int i1 = 0 + i2; C = ptr5.getDouble(i1);
/*  362 */           Ptr ptr4 = Rinternals2.REAL(l); int n = i % nl * 8; Ptr ptr3 = ptr4; int m = 0 + n; L = ptr3.getDouble(m);
/*  363 */           Ptr ptr2 = Rinternals2.REAL(a); int k = i % na * 8; Ptr ptr1 = ptr2; int j = 0 + k; A = ptr1.getDouble(j);
/*  364 */           if (Arith.R_finite(A) == 0) A = 1.0D; 
/*  365 */           if (Arith.R_finite(H) == 0 || Arith.R_finite(C) == 0 || Arith.R_finite(L) == 0)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  377 */             R_NaString$75 = Rinternals.R_NaString; Rinternals.SET_STRING_ELT(ans, i, R_NaString$75); } else { if (L < 0.0D || L > 100.0D || C < 0.0D || A < 0.0D || A > 1.0D)
/*      */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid hcl color\000".getBytes(), 0)), new Object[0]);  hcl2rgb(H, C, L, (Ptr)new DoublePtr(r, 0), (Ptr)new DoublePtr(g, 0), (Ptr)new DoublePtr(b, 0)); ir$63 = (int)(r[0] * 255.0D + 0.5D); ir[0] = ir$63; ig$65 = (int)(g[0] * 255.0D + 0.5D); ig[0] = ig$65; ib$67 = (int)(b[0] * 255.0D + 0.5D); ib[0] = ib$67; if (FixupColor((Ptr)new IntPtr(ir, 0), (Ptr)new IntPtr(ig, 0), (Ptr)new IntPtr(ib, 0)) == 0 || fixup != 0) { int i5 = ScaleAlpha(A); ib$70 = ib[0]; ig$72 = ig[0]; SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(ir[0], ig$72, ib$70, i5)); Rinternals.SET_STRING_ELT(ans, i, sEXP); } else { R_NaString$68 = Rinternals.R_NaString; Rinternals.SET_STRING_ELT(ans, i, R_NaString$68); }  }  }  } else { for (i = 0; i < max; i++) { Ptr ptr6 = Rinternals2.REAL(h); int i2 = i % nh * 8; Ptr ptr5 = ptr6; int i1 = 0 + i2; H = ptr5.getDouble(i1); Ptr ptr4 = Rinternals2.REAL(c); int n = i % nc * 8; Ptr ptr3 = ptr4; int m = 0 + n; C = ptr3.getDouble(m); Ptr ptr2 = Rinternals2.REAL(l); int k = i % nl * 8; Ptr ptr1 = ptr2; int j = 0 + k; L = ptr1.getDouble(j); if (Arith.R_finite(H) == 0 || Arith.R_finite(C) == 0 || Arith.R_finite(L) == 0) { R_NaString$61 = Rinternals.R_NaString; Rinternals.SET_STRING_ELT(ans, i, R_NaString$61); } else { if (L < 0.0D || L > 100.0D || C < 0.0D)
/*      */               Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid hcl color\000".getBytes(), 0)), new Object[0]);  hcl2rgb(H, C, L, (Ptr)new DoublePtr(r, 0), (Ptr)new DoublePtr(g, 0), (Ptr)new DoublePtr(b, 0)); ir$49 = (int)(r[0] * 255.0D + 0.5D); ir[0] = ir$49; ig$51 = (int)(g[0] * 255.0D + 0.5D); ig[0] = ig$51; ib$53 = (int)(b[0] * 255.0D + 0.5D); ib[0] = ib$53; if (FixupColor((Ptr)new IntPtr(ir, 0), (Ptr)new IntPtr(ig, 0), (Ptr)new IntPtr(ib, 0)) == 0 || fixup != 0) { ib$56 = ib[0]; ig$58 = ig[0]; SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(ir[0], ig$58, ib$56)); Rinternals.SET_STRING_ELT(ans, i, sEXP); } else { R_NaString$54 = Rinternals.R_NaString; Rinternals.SET_STRING_ELT(ans, i, R_NaString$54); }  }  }
/*      */          }
/*  381 */        return ans;
/*      */     } 
/*      */     return Rinternals.Rf_allocVector(16, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP rgb(SEXP r, SEXP g, SEXP b, SEXP a, SEXP MCV, SEXP nam) {
/*  394 */     c = (SEXP)BytePtr.of(0).getArray(); mV = 0.0D; na = 0; nb = 0; ng = 0; nr = 0; l_max = 0; na = 1;
/*  395 */     max_1 = 0;
/*  396 */     mV = Rinternals.Rf_asReal(MCV);
/*      */     
/*  398 */     if (Arith.R_finite(mV) == 0 || mV == 0.0D)
/*  399 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid value of 'maxColorValue'\000".getBytes(), 0)), new Object[0]); 
/*  400 */     if (mV != 255.0D)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*  406 */       r = Rinternals.Rf_coerceVector(r, 14); Rinternals.Rf_protect(r);
/*  407 */       g = Rinternals.Rf_coerceVector(g, 14); Rinternals.Rf_protect(g);
/*  408 */       b = Rinternals.Rf_coerceVector(b, 14); Rinternals.Rf_protect(b);
/*  409 */       if (Rinternals.TYPEOF(a) != 0) a = Rinternals.Rf_coerceVector(a, 14); 
/*  410 */       max_1 = (mV != 1.0D) ? 0 : 1; } else { r = Rinternals.Rf_coerceVector(r, 13); Rinternals.Rf_protect(r); g = Rinternals.Rf_coerceVector(g, 13); Rinternals.Rf_protect(g); b = Rinternals.Rf_coerceVector(b, 13); Rinternals.Rf_protect(b); if (Rinternals.TYPEOF(a) != 0)
/*      */         a = Rinternals.Rf_coerceVector(a, 13);  }
/*  412 */      Rinternals.Rf_protect(a);
/*      */     
/*  414 */     nr = Rinternals.XLENGTH(r); ng = Rinternals.XLENGTH(g); nb = Rinternals.XLENGTH(b);
/*  415 */     if (Rinternals.TYPEOF(a) != 0) na = Rinternals.XLENGTH(a); 
/*  416 */     if (nr > 0 && ng > 0 && nb > 0 && na > 0) {
/*      */ 
/*      */ 
/*      */       
/*  420 */       l_max = nr;
/*  421 */       if (l_max < ng) l_max = ng; 
/*  422 */       if (l_max < nb) l_max = nb; 
/*  423 */       if (l_max < na) l_max = na;
/*      */       
/*  425 */       nam = Rinternals.Rf_coerceVector(nam, 16); Rinternals.Rf_protect(nam);
/*  426 */       if (Rinternals.Rf_length(nam) != 0 && Rinternals.Rf_length(nam) != l_max)
/*  427 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid 'names' vector\000".getBytes(), 0)), new Object[0]); 
/*  428 */       c = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, l_max));
/*      */       
/*  430 */       if (mV != 255.0D)
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  442 */         if (max_1 == 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  455 */           if (Rinternals.TYPEOF(a) != 0)
/*      */           
/*      */           { 
/*      */ 
/*      */             
/*  460 */             for (i = 0; i < l_max; ) { Ptr ptr8 = Rinternals2.REAL(a); int i7 = i % na * 8; Ptr ptr7 = ptr8; int i6 = 0 + i7, i5 = ScaleAlpha(ptr7.getDouble(i6) / mV); Ptr ptr6 = Rinternals2.REAL(b); int i4 = i % nb * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = ScaleColor(ptr5.getDouble(i3) / mV); Ptr ptr4 = Rinternals2.REAL(g); int i1 = i % ng * 8; Ptr ptr3 = ptr4; int n = 0 + i1, m = ScaleColor(ptr3.getDouble(n) / mV); Ptr ptr2 = Rinternals2.REAL(r); int k = i % nr * 8; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(ScaleColor(ptr1.getDouble(j) / mV), m, i2, i5)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }  } else { for (i = 0; i < l_max; ) { Ptr ptr6 = Rinternals2.REAL(b); int i4 = i % nb * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = ScaleColor(ptr5.getDouble(i3) / mV); Ptr ptr4 = Rinternals2.REAL(g); int i1 = i % ng * 8; Ptr ptr3 = ptr4; int n = 0 + i1, m = ScaleColor(ptr3.getDouble(n) / mV); Ptr ptr2 = Rinternals2.REAL(r); int k = i % nr * 8; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(ScaleColor(ptr1.getDouble(j) / mV), m, i2)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }  }  } else if (Rinternals.TYPEOF(a) != 0) { for (i = 0; i < l_max; ) { Ptr ptr8 = Rinternals2.REAL(a); int i7 = i % na * 8; Ptr ptr7 = ptr8; int i6 = 0 + i7, i5 = ScaleAlpha(ptr7.getDouble(i6)); Ptr ptr6 = Rinternals2.REAL(b); int i4 = i % nb * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = ScaleColor(ptr5.getDouble(i3)); Ptr ptr4 = Rinternals2.REAL(g); int i1 = i % ng * 8; Ptr ptr3 = ptr4; int n = 0 + i1, m = ScaleColor(ptr3.getDouble(n)); Ptr ptr2 = Rinternals2.REAL(r); int k = i % nr * 8; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(ScaleColor(ptr1.getDouble(j)), m, i2, i5)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }  } else { for (i = 0; i < l_max; ) { Ptr ptr6 = Rinternals2.REAL(b); int i4 = i % nb * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = ScaleColor(ptr5.getDouble(i3)); Ptr ptr4 = Rinternals2.REAL(g); int i1 = i % ng * 8; Ptr ptr3 = ptr4; int n = 0 + i1, m = ScaleColor(ptr3.getDouble(n)); Ptr ptr2 = Rinternals2.REAL(r); int k = i % nr * 8; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(ScaleColor(ptr1.getDouble(j)), m, i2)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }  }
/*      */          }
/*      */       else if (Rinternals.TYPEOF(a) != 0) { for (i = 0; i < l_max; ) { Ptr ptr8 = Rinternals2.INTEGER(a); int i7 = i % na * 4; Ptr ptr7 = ptr8; int i6 = 0 + i7, i5 = CheckAlpha(ptr7.getInt(i6)); Ptr ptr6 = Rinternals2.INTEGER(b); int i4 = i % nb * 4; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = CheckColor(ptr5.getInt(i3)); Ptr ptr4 = Rinternals2.INTEGER(g); int i1 = i % ng * 4; Ptr ptr3 = ptr4; int n = 0 + i1, m = CheckColor(ptr3.getInt(n)); Ptr ptr2 = Rinternals2.INTEGER(r); int k = i % nr * 4; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(CheckColor(ptr1.getInt(j)), m, i2, i5)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }
/*      */          }
/*      */       else { for (i = 0; i < l_max; ) { Ptr ptr6 = Rinternals2.INTEGER(b); int i4 = i % nb * 4; Ptr ptr5 = ptr6; int i3 = 0 + i4, i2 = CheckColor(ptr5.getInt(i3)); Ptr ptr4 = Rinternals2.INTEGER(g); int i1 = i % ng * 4; Ptr ptr3 = ptr4; int n = 0 + i1, m = CheckColor(ptr3.getInt(n)); Ptr ptr2 = Rinternals2.INTEGER(r); int k = i % nr * 4; Ptr ptr1 = ptr2; int j = 0 + k; SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(CheckColor(ptr1.getInt(j)), m, i2)); Rinternals.SET_STRING_ELT(c, i, sEXP); i++; }
/*      */          }
/*  466 */        if (Rinternals.Rf_length(nam) != 0) { R_NamesSymbol$47 = Rinternals.R_NamesSymbol; Rinternals.Rf_setAttrib(c, R_NamesSymbol$47, nam); }
/*      */       
/*  468 */       return c;
/*      */     } 
/*      */     return Rinternals.Rf_allocVector(16, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP gray(SEXP lev, SEXP a) {
/*  477 */     na = 0; nlev = 0; ans = (SEXP)BytePtr.of(0).getArray(); lev = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(lev, 14));
/*  478 */     if (Rinternals.TYPEOF(a) != 0) a = Rinternals.Rf_coerceVector(a, 14); 
/*  479 */     Rinternals.Rf_protect(a);
/*  480 */     nlev = Rinternals.LENGTH(lev);
/*  481 */     ans = Rinternals.Rf_allocVector(16, nlev); Rinternals.Rf_protect(ans);
/*  482 */     if (Rinternals.TYPEOF(a) != 0)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  491 */       na = Rinternals.Rf_length(a);
/*  492 */       for (i = 0; Math.max(na, nlev) > i; i++) {
/*  493 */         Ptr ptr4 = Rinternals2.REAL(lev); int i1 = i % nlev * 8; Ptr ptr3 = ptr4; int n = 0 + i1; level = ptr3.getDouble(n);
/*  494 */         if (Builtins.__isnan(level) != 0 || level < 0.0D || level > 1.0D)
/*  495 */           Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid gray level, must be in [0,1].\000".getBytes(), 0)), new Object[0]); 
/*  496 */         ilevel = (int)(level * 255.0D + 0.5D);
/*  497 */         Ptr ptr2 = Rinternals2.REAL(a); int m = i % na * 8; Ptr ptr1 = ptr2; int k = 0 + m;
/*  498 */         int j = ScaleAlpha(ptr1.getDouble(k)); ilevel$44 = ilevel; ilevel$45 = ilevel; SEXP sEXP = Rinternals.Rf_mkChar(RGBA2rgb(ilevel, ilevel$45, ilevel$44, j)); Rinternals.SET_STRING_ELT(ans, i, sEXP);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  503 */       return ans; }  for (i = 0; i < nlev; i++) { Ptr ptr2 = Rinternals2.REAL(lev); int k = i * 8; Ptr ptr1 = ptr2; int j = 0 + k; level = ptr1.getDouble(j); if (Builtins.__isnan(level) != 0 || level < 0.0D || level > 1.0D) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid gray level, must be in [0,1].\000".getBytes(), 0)), new Object[0]);  ilevel = (int)(level * 255.0D + 0.5D); ilevel$41 = ilevel; ilevel$42 = ilevel; SEXP sEXP = Rinternals.Rf_mkChar(RGB2rgb(ilevel, ilevel$42, ilevel$41)); Rinternals.SET_STRING_ELT(ans, i, sEXP); }  return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP RGB2hsv(SEXP rgb) {
/*  516 */     n = 0; ans = (SEXP)BytePtr.of(0).getArray(); rgb = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(rgb, 14));
/*  517 */     if (!Rinternals.Rf_isMatrix(rgb)) Error.Rf_error(new BytePtr("rgb is not a matrix (internally)\000".getBytes(), 0), new Object[0]); 
/*  518 */     R_DimSymbol$29 = Rinternals.R_DimSymbol; dd = Rinternals.Rf_getAttrib(rgb, R_DimSymbol$29);
/*  519 */     if (Rinternals2.INTEGER(dd).getInt() != 3) Error.Rf_error(new BytePtr("rgb must have 3 rows (internally)\000".getBytes(), 0), new Object[0]); 
/*  520 */     n = Rinternals2.INTEGER(dd).getInt(4);
/*      */     
/*  522 */     ans = Rinternals.Rf_protect(Rinternals.Rf_allocMatrix(14, 3, n));
/*  523 */     dmns = Rinternals.Rf_allocVector(19, 2); Rinternals.Rf_protect(dmns);
/*      */     
/*  525 */     names = Rinternals.Rf_allocVector(16, 3); Rinternals.Rf_protect(names);
/*  526 */     SEXP sEXP3 = Rinternals.Rf_mkChar((Ptr)new BytePtr("h\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 0, sEXP3);
/*  527 */     SEXP sEXP2 = Rinternals.Rf_mkChar((Ptr)new BytePtr("s\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 1, sEXP2);
/*  528 */     SEXP sEXP1 = Rinternals.Rf_mkChar((Ptr)new BytePtr("v\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 2, sEXP1);
/*  529 */     Rinternals.SET_VECTOR_ELT(dmns, 0, names);
/*      */     
/*  531 */     R_DimNamesSymbol$30 = Rinternals.R_DimNamesSymbol; dd = Rinternals.Rf_getAttrib(rgb, R_DimNamesSymbol$30); R_NilValue$31 = Rinternals.R_NilValue; if (dd != R_NilValue$31) { names = Rinternals.VECTOR_ELT(dd, 1);
/*  532 */       R_NilValue$32 = Rinternals.R_NilValue; if (names != R_NilValue$32)
/*  533 */         Rinternals.SET_VECTOR_ELT(dmns, 1, names);  }
/*  534 */      R_DimNamesSymbol$33 = Rinternals.R_DimNamesSymbol; Rinternals.Rf_setAttrib(ans, R_DimNamesSymbol$33, dmns);
/*      */ 
/*      */     
/*  537 */     for (i = i3 = 0; i < n; 
/*  538 */       ptr7 = ptr8, i5 = 0 + i6, ptr6 = Rinternals2.REAL(rgb), i4 = (i3 + 2) * 8, ptr5 = ptr6, i2 = 0 + i4, d2 = ptr5.getDouble(i2), ptr4 = Rinternals2.REAL(rgb), i1 = (i3 + 1) * 8, ptr3 = ptr4, m = 0 + i1, d1 = ptr3.getDouble(m), ptr2 = Rinternals2.REAL(rgb), k = i3 * 8, ptr1 = ptr2, j = 0 + k, rgb2hsv(ptr1.getDouble(j), d1, d2, ptr7.pointerPlus(i5), ptr9.pointerPlus(i7), ptr11.pointerPlus(i9)), i++, i3 += 3) {
/*  539 */       Ptr ptr1; int j, k; Ptr ptr2; double d1; Ptr ptr3; int m, i1; Ptr ptr4; double d2; Ptr ptr5; int i2, i4; Ptr ptr6, ptr7; int i5; Ptr ptr12 = Rinternals2.REAL(ans); int i10 = (i3 + 2) * 8; Ptr ptr11 = ptr12; int i9 = 0 + i10; Ptr ptr10 = Rinternals2.REAL(ans); int i8 = (i3 + 1) * 8; Ptr ptr9 = ptr10; int i7 = 0 + i8; Ptr ptr8 = Rinternals2.REAL(ans); int i6 = i3 * 8;
/*      */     } 
/*      */     
/*  542 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP col2rgb(SEXP colors, SEXP alpha) {
/*  550 */     n = 0; alph = 0; ans = (SEXP)BytePtr.of(0).getArray(); alph = Rinternals.Rf_asLogical(alpha);
/*  551 */     R_NaInt$20 = Arith.R_NaInt; if (alph == R_NaInt$20) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid '%s' value\000".getBytes(), 0)), new Object[] { new BytePtr("alpha\000".getBytes(), 0) }); 
/*  552 */     switch (Rinternals.TYPEOF(colors)) {
/*      */       case 13:
/*      */       case 16:
/*      */         break;
/*      */       case 14:
/*  557 */         colors = Rinternals.Rf_coerceVector(colors, 13);
/*      */         break;
/*      */       default:
/*  560 */         colors = Rinternals.Rf_coerceVector(colors, 16);
/*      */         break;
/*      */     } 
/*  563 */     Rinternals.Rf_protect(colors);
/*  564 */     n = Rinternals.LENGTH(colors);
/*      */ 
/*      */     
/*  567 */     int m = alph + 3; ans = Rinternals.Rf_allocMatrix(13, m, n); Rinternals.Rf_protect(ans);
/*  568 */     dmns = Rinternals.Rf_allocVector(19, 2); Rinternals.Rf_protect(dmns);
/*  569 */     int k = alph + 3; names = Rinternals.Rf_allocVector(16, k); Rinternals.Rf_protect(names);
/*  570 */     SEXP sEXP3 = Rinternals.Rf_mkChar((Ptr)new BytePtr("red\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 0, sEXP3);
/*  571 */     SEXP sEXP2 = Rinternals.Rf_mkChar((Ptr)new BytePtr("green\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 1, sEXP2);
/*  572 */     SEXP sEXP1 = Rinternals.Rf_mkChar((Ptr)new BytePtr("blue\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 2, sEXP1);
/*  573 */     if (alph != 0) { SEXP sEXP = Rinternals.Rf_mkChar((Ptr)new BytePtr("alpha\000".getBytes(), 0)); Rinternals.SET_STRING_ELT(names, 3, sEXP); }
/*  574 */      Rinternals.SET_VECTOR_ELT(dmns, 0, names);
/*  575 */     R_NamesSymbol$21 = Rinternals.R_NamesSymbol; names = Rinternals.Rf_getAttrib(colors, R_NamesSymbol$21); R_NilValue$22 = Rinternals.R_NilValue; if (names != R_NilValue$22)
/*  576 */       Rinternals.SET_VECTOR_ELT(dmns, 1, names); 
/*  577 */     R_DimNamesSymbol$23 = Rinternals.R_DimNamesSymbol; Rinternals.Rf_setAttrib(ans, R_DimNamesSymbol$23, dmns);
/*      */     
/*  579 */     for (i = 0, j = 0; i < n; i++) {
/*  580 */       icol = inRGBpar3(colors, i, 16777215);
/*  581 */       Ptr ptr6 = Rinternals2.INTEGER(ans); int i9 = j * 4; Ptr ptr5 = ptr6; int i8 = 0 + i9, i7 = icol & 0xFF; ptr5.setInt(i8, i7); j++;
/*  582 */       Ptr ptr4 = Rinternals2.INTEGER(ans); int i6 = j * 4; Ptr ptr3 = ptr4; int i5 = 0 + i6, i4 = icol >>> 8 & 0xFF; ptr3.setInt(i5, i4); j++;
/*  583 */       Ptr ptr2 = Rinternals2.INTEGER(ans); int i3 = j * 4; Ptr ptr1 = ptr2; int i2 = 0 + i3, i1 = icol >>> 16 & 0xFF; ptr1.setInt(i2, i1); j++;
/*  584 */       if (alph != 0) { Ptr ptr8 = Rinternals2.INTEGER(ans); int i12 = j * 4; Ptr ptr7 = ptr8; int i11 = 0 + i12, i10 = icol >>> 24; ptr7.setInt(i11, i10); j++; }
/*      */     
/*      */     } 
/*  587 */     return ans;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int StrMatch(Ptr s, Ptr t) {
/*      */     boolean bool;
/*      */     while (true) {
/*  615 */       if (s.getByte() != (byte)0 || t.getByte() != (byte)0) {
/*  616 */         if (s.getByte() != (byte)32) {
/*  617 */           if (t.getByte() != (byte)32) {
/*  618 */             byte b2 = s.getByte(); s = s.pointerPlus(1); int j = Stdlib.tolower(b2); byte b1 = t.getByte(); t = t.pointerPlus(1); int i = Stdlib.tolower(b1); if (j == i) continue;  boolean bool1 = false;
/*      */             break;
/*      */           } 
/*      */           t = t.pointerPlus(1);
/*      */           continue;
/*      */         } 
/*      */         s = s.pointerPlus(1);
/*      */         continue;
/*      */       } 
/*      */       bool = true;
/*      */       break;
/*      */     } 
/*      */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hexdigit(int digit) {
/* 1340 */     null = 0; if (digit <= 47 || digit > 57) {
/* 1341 */       if (digit <= 64 || digit > 70) {
/* 1342 */         if (digit <= 96 || digit > 102) {
/* 1343 */           Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid hex digit in 'color' or 'lty'\000".getBytes(), 0)), new Object[0]);
/*      */           return null;
/*      */         } 
/*      */         return digit + -87;
/*      */       } 
/*      */       return digit + -55;
/*      */     } 
/*      */     return digit + -48; } public static int rgb2col(Ptr rgb) { int k, m, n, i1, i2, i3, i4, i5;
/* 1351 */     r = 0; g = 0; b = 0; a = 0;
/* 1352 */     if (rgb.getByte() != (byte)35)
/* 1353 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid RGB specification\000".getBytes(), 0)), new Object[0]); 
/* 1354 */     switch (Stdlib.strlen(rgb)) {
/*      */       case 9:
/* 1356 */         i5 = hexdigit(rgb.getByte(7)) * 16; i4 = hexdigit(rgb.getByte(8)); a = i5 + i4;
/*      */       case 7:
/* 1358 */         i3 = hexdigit(rgb.getByte(1)) * 16; i2 = hexdigit(rgb.getByte(2)); r = i3 + i2;
/* 1359 */         i1 = hexdigit(rgb.getByte(3)) * 16; n = hexdigit(rgb.getByte(4)); g = i1 + n;
/* 1360 */         m = hexdigit(rgb.getByte(5)) * 16; k = hexdigit(rgb.getByte(6)); b = m + k;
/*      */         break;
/*      */       default:
/* 1363 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid RGB specification\000".getBytes(), 0)), new Object[0]); break;
/*      */     } 
/* 1365 */     if (Stdlib.strlen(rgb) != 7) {
/*      */ 
/*      */       
/* 1368 */       int i9 = g << 8 | r, i8 = b << 16, i7 = i9 | i8, i6 = a << 24; return i7 | i6;
/*      */     } 
/*      */     int j = g << 8 | r, i = b << 16;
/*      */     return j | i | 0xFF000000; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int name2col(Ptr nm) {
/* 1376 */     null = 0; if (Stdlib.strcmp(nm, (Ptr)new BytePtr("NA\000".getBytes(), 0)) != 0 && Stdlib.strcmp(nm, (Ptr)new BytePtr("transparent\000".getBytes(), 0)) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1392 */       i = 0; while (true) { if (!Context.get__colors$ColorDataBase().getPointer(i * 12).isNull()) {
/* 1393 */           if (StrMatch(Context.get__colors$ColorDataBase().getPointer(i * 12), nm) == 0) { i++; continue; }
/* 1394 */            null = Context.get__colors$ColorDataBase().getInt(i * 12 + 8); break;
/*      */         } 
/* 1396 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid color name '%s'\000".getBytes(), 0)), new Object[] { nm });
/*      */         break; }
/*      */       
/*      */       return null;
/*      */     } 
/*      */     return 16777215;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr Rf_col2name(int col) {
/* 1406 */     return incol2name(col);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Ptr incol2name(int col) {
/*      */     BytePtr bytePtr;
/*      */     boolean bool;
/* 1413 */     if (col >>> 24 != 255) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1427 */       if (col >>> 24 != 0) {
/*      */ 
/*      */         
/* 1430 */         $incol2name$ColBuf[0] = (byte)35;
/* 1431 */         int i4 = col >>> 4 & 0xF; byte b8 = Context.get__colors$HexDigits()[i4]; $incol2name$ColBuf[1] = b8;
/* 1432 */         int i3 = col & 0xF; byte b7 = Context.get__colors$HexDigits()[i3]; $incol2name$ColBuf[2] = b7;
/* 1433 */         int i2 = col >>> 12 & 0xF; byte b6 = Context.get__colors$HexDigits()[i2]; $incol2name$ColBuf[3] = b6;
/* 1434 */         int i1 = col >>> 8 & 0xF; byte b5 = Context.get__colors$HexDigits()[i1]; $incol2name$ColBuf[4] = b5;
/* 1435 */         int n = col >>> 20 & 0xF; byte b4 = Context.get__colors$HexDigits()[n]; $incol2name$ColBuf[5] = b4;
/* 1436 */         int m = col >>> 16 & 0xF; byte b3 = Context.get__colors$HexDigits()[m]; $incol2name$ColBuf[6] = b3;
/* 1437 */         int k = col >>> 28; byte b2 = Context.get__colors$HexDigits()[k]; $incol2name$ColBuf[7] = b2;
/* 1438 */         int j = col >>> 24 & 0xF; byte b1 = Context.get__colors$HexDigits()[j]; $incol2name$ColBuf[8] = b1;
/* 1439 */         $incol2name$ColBuf[9] = (byte)0;
/* 1440 */         BytePtr bytePtr1 = new BytePtr($incol2name$ColBuf, 0); boolean bool1 = false; return bytePtr1.pointerPlus(bool1);
/*      */       }  bytePtr = new BytePtr("transparent\000".getBytes(), 0); bool = false; return bytePtr.pointerPlus(bool);
/*      */     }  i = 0; while (true) { if (!Context.get__colors$ColorDataBase().getPointer(i * 12).isNull()) { if (Context.get__colors$ColorDataBase().getInt(i * 12 + 8) != col) {
/*      */           i++; continue;
/*      */         }  Ptr ptr = Context.get__colors$ColorDataBase().getPointer(i * 12); boolean bool1 = false; break; }
/*      */        $incol2name$ColBuf[0] = (byte)35; int i2 = col >>> 4 & 0xF; byte b6 = Context.get__colors$HexDigits()[i2]; $incol2name$ColBuf[1] = b6; int i1 = col & 0xF; byte b5 = Context.get__colors$HexDigits()[i1]; $incol2name$ColBuf[2] = b5; int n = col >>> 12 & 0xF; byte b4 = Context.get__colors$HexDigits()[n]; $incol2name$ColBuf[3] = b4; int m = col >>> 8 & 0xF; byte b3 = Context.get__colors$HexDigits()[m]; $incol2name$ColBuf[4] = b3; int k = col >>> 20 & 0xF; byte b2 = Context.get__colors$HexDigits()[k]; $incol2name$ColBuf[5] = b2; int j = col >>> 16 & 0xF; byte b1 = Context.get__colors$HexDigits()[j]; $incol2name$ColBuf[6] = b1; $incol2name$ColBuf[7] = (byte)0; bytePtr = new BytePtr($incol2name$ColBuf, 0); bool = false; break; }
/* 1446 */      return bytePtr.pointerPlus(bool); } public static int str2col(Ptr s, int bg) { ptr = new Ptr[1]; ptr[0] = BytePtr.of(0); if (s.getByte() != (byte)35) {
/* 1447 */       Ptr ptr2 = Stdlib2.__ctype_b_loc().getPointer(); int j = s.getByte() * 2; Ptr ptr1 = ptr2; int i = 0 + j; if ((ptr1.getChar(i) & 0x800) == 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1453 */         return name2col(s); }  indx = (int)Stdlib.strtod(s); if (ptr[0].getByte() != (byte)0)
/*      */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid color specification \"%s\"\000".getBytes(), 0)), new Object[] { s });  if (indx != 0) {
/*      */         int m = indx + -1; PaletteSize$19 = Context.get__colors$PaletteSize(); int k = m % PaletteSize$19; return Context.get__colors$Palette()[k];
/*      */       }  return bg;
/*      */     } 
/* 1458 */     return rgb2col(s); } public static int inR_GE_str2col(Ptr s) { if (Stdlib.strcmp(s, (Ptr)new BytePtr("0\000".getBytes(), 0)) == 0)
/* 1459 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid color specification \"%s\"\000".getBytes(), 0)), new Object[] { s }); 
/* 1460 */     return str2col(s, 16777215); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int Rf_RGBpar3(SEXP x, int i, int bg) {
/* 1469 */     return inRGBpar3(x, i, bg); } public static int inRGBpar3(SEXP x, int i, int bg) { Ptr ptr1; int j; int k; Ptr ptr2; Ptr ptr3; int m; int n;
/*      */     Ptr ptr4;
/*      */     IntPtr intPtr1;
/*      */     int i1;
/*      */     int i2;
/*      */     IntPtr intPtr2;
/* 1475 */     switch (Rinternals.TYPEOF(x)) {
/*      */       
/*      */       case 16:
/* 1478 */         return str2col((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(x, i)), bg);
/*      */       case 10:
/* 1480 */         intPtr2 = Rinternals.LOGICAL(x); i2 = i * 4; intPtr1 = intPtr2; i1 = 0 + i2; indx = intPtr1.getInt(i1);
/* 1481 */         R_NaInt$12 = Arith.R_NaInt; if (indx != R_NaInt$12) break;  return 16777215;
/*      */       
/*      */       case 13:
/* 1484 */         ptr4 = Rinternals2.INTEGER(x); n = i * 4; ptr3 = ptr4; m = 0 + n; indx = ptr3.getInt(m);
/* 1485 */         R_NaInt$14 = Arith.R_NaInt; if (indx != R_NaInt$14) break;  return 16777215;
/*      */       
/*      */       case 14:
/* 1488 */         ptr2 = Rinternals2.REAL(x); k = i * 8; ptr1 = ptr2; j = 0 + k; if (Arith.R_finite(ptr1.getDouble(j)) != 0) {
/* 1489 */           Ptr ptr6 = Rinternals2.REAL(x); int i4 = i * 8; Ptr ptr5 = ptr6; int i3 = 0 + i4; indx = (int)ptr5.getDouble(i3); break;
/*      */         }  return 16777215;
/*      */       default:
/* 1492 */         Error.Rf_warning(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("supplied color is neither numeric nor character\000".getBytes(), 0)), new Object[0]);
/* 1493 */         return bg;
/*      */     } 
/* 1495 */     if (indx < 0)
/* 1496 */       Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("numerical color values must be >= 0, found %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(indx) }); 
/* 1497 */     if (indx != 0) {
/* 1498 */       int i4 = indx + -1; PaletteSize$17 = Context.get__colors$PaletteSize(); int i3 = i4 % PaletteSize$17; return Context.get__colors$Palette()[i3];
/*      */     } 
/*      */     return bg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP palette(SEXP val) {
/* 1507 */     color = new int[1024]; n = 0; ans = (SEXP)BytePtr.of(0).getArray(); if (Rinternals.TYPEOF(val) != 16) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid argument type\000".getBytes(), 0)), new Object[0]);
/*      */     
/* 1509 */     PaletteSize$8 = Context.get__colors$PaletteSize(); ans = Rinternals.Rf_allocVector(16, PaletteSize$8); Rinternals.Rf_protect(ans);
/* 1510 */     j = 0; while (true) { PaletteSize$9 = Context.get__colors$PaletteSize(); if (j >= PaletteSize$9)
/* 1511 */         break;  SEXP sEXP = Rinternals.Rf_mkChar(incol2name(Context.get__colors$Palette()[j])); Rinternals.SET_STRING_ELT(ans, j, sEXP); j++; }
/* 1512 */      n = Rinternals.Rf_length(val); if (n == 1) {
/* 1513 */       BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(val, 0)); if (StrMatch((Ptr)new BytePtr("default\000".getBytes(), 0), (Ptr)bytePtr) == 0)
/*      */       
/*      */       { 
/*      */ 
/*      */         
/* 1518 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("unknown palette (need >= 2 colors)\000".getBytes(), 0)), new Object[0]); } else { for (i = 0; i <= 1023 && !Context.get__colors$DefaultPalette().getAlignedPointer(i).isNull(); i++) { int k = name2col(Context.get__colors$DefaultPalette().getAlignedPointer(i)); Context.get__colors$Palette()[i] = k; }  Context.set__colors$PaletteSize(i); }
/*      */     
/* 1520 */     }  if (n > 1) {
/* 1521 */       if (n > 1024)
/* 1522 */         Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("maximum number of colors is %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(1024) }); 
/* 1523 */       for (j = 0; j < n; j++) {
/* 1524 */         BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(val, j));
/* 1525 */         if (bytePtr.getByte() != (byte)35) { iftmp$10 = name2col((Ptr)bytePtr); } else { iftmp$10 = rgb2col((Ptr)bytePtr); }  color[j] = iftmp$10;
/*      */       } 
/* 1527 */       for (j = 0; j < n; j++) {
/* 1528 */         int k = color[j]; Context.get__colors$Palette()[j] = k;
/* 1529 */       }  Context.set__colors$PaletteSize(n);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SEXP palette2(SEXP val) {
/* 1538 */     ians = BytePtr.of(0); ians$offset = 0; n = 0; ans = (SEXP)BytePtr.of(0).getArray(); PaletteSize$4 = Context.get__colors$PaletteSize(); ans = Rinternals.Rf_protect(Rinternals.Rf_allocVector(13, PaletteSize$4));
/* 1539 */     n = Rinternals.Rf_length(val); ians = Rinternals2.INTEGER(ans); ians$offset = 0;
/* 1540 */     j = 0; while (true) { PaletteSize$6 = Context.get__colors$PaletteSize(); if (j >= PaletteSize$6) {
/* 1541 */         if (n != 0) {
/* 1542 */           if (Rinternals.TYPEOF(val) != 13) Error.Rf_error(new BytePtr("requires INTSXP argment\000".getBytes(), 0), new Object[0]); 
/* 1543 */           if (n > 1024)
/* 1544 */             Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("maximum number of colors is %d\000".getBytes(), 0)), new Object[] { Integer.valueOf(1024) }); 
/* 1545 */           for (i = 0; i < n; ) { Ptr ptr2 = Rinternals2.INTEGER(val); int i4 = i * 4; Ptr ptr1 = ptr2; int i3 = 0 + i4, i2 = ptr1.getInt(i3); Context.get__colors$Palette()[i] = i2; i++; }
/* 1546 */            Context.set__colors$PaletteSize(n);
/*      */         } 
/*      */         
/* 1549 */         return ans;
/*      */       } 
/*      */       int i1 = j * 4;
/*      */       Ptr ptr = ians;
/*      */       int m = ians$offset + i1, k = Context.get__colors$Palette()[j];
/*      */       ptr.setInt(m, k);
/*      */       j++; }
/* 1556 */      } public static SEXP colors() { for (ans = (SEXP)BytePtr.of(0).getArray(), n = 0; !Context.get__colors$ColorDataBase().getPointer(n * 12).isNull(); n++);
/* 1557 */     ans = Rinternals.Rf_protect(Rinternals.Rf_allocVector(16, n));
/* 1558 */     for (n = 0; !Context.get__colors$ColorDataBase().getPointer(n * 12).isNull(); n++) {
/* 1559 */       SEXP sEXP = Rinternals.Rf_mkChar(Context.get__colors$ColorDataBase().getPointer(n * 12)); Rinternals.SET_STRING_ELT(ans, n, sEXP);
/*      */     } 
/* 1561 */     return ans; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void savePaletteImpl(int save) {
/* 1567 */     if (save == 0) {
/*      */ 
/*      */ 
/*      */       
/* 1571 */       i = 0; while (true) { PaletteSize$3 = Context.get__colors$PaletteSize(); if (i >= PaletteSize$3)
/* 1572 */           break;  int k = Context.get__colors$Palette0()[i]; Context.get__colors$Palette()[i] = k;
/*      */         i++; }
/*      */       
/*      */       return;
/*      */     } 
/*      */     j = 0;
/*      */     while (true) {
/*      */       PaletteSize$2 = Context.get__colors$PaletteSize();
/*      */       if (j >= PaletteSize$2) {
/*      */         break;
/*      */       }
/*      */       int k = Context.get__colors$Palette()[j];
/*      */       Context.get__colors$Palette0()[j] = k;
/*      */       j++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initPalette() {
/*      */     // Byte code:
/*      */     //   0: ldc
/*      */     //   2: invokestatic set__colors$ptr_savePalette : (Ljava/lang/invoke/MethodHandle;)V
/*      */     //   5: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1587	-> 0
/*      */     //   #1600	-> 5
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void savePalette(int save) {
/* 1606 */     if (Context.get__colors$ptr_savePalette() == null) Error.Rf_error(new BytePtr("package grDevices must be loaded\000".getBytes(), 0), new Object[0]); 
/* 1607 */     Context.get__colors$ptr_savePalette().invoke(save);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/colors__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */