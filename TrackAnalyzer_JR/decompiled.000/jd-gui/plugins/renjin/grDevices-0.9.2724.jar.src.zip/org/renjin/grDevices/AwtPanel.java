/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Panel;
/*     */ import java.awt.RenderingHints;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AwtPanel
/*     */   extends Panel
/*     */ {
/*     */   private final int bufferWidth;
/*     */   private final int bufferHeight;
/*     */   private boolean forceAntiAliasing;
/*     */   private transient Image bufferImage;
/*     */   private transient Graphics bufferGraphics;
/*     */   private transient boolean paused = false;
/*  44 */   private AtomicBoolean pendingPaint = new AtomicBoolean(false);
/*     */   
/*     */   AwtPanel(Dimension size) {
/*  47 */     setSize(size);
/*  48 */     this.bufferWidth = (int)size.getWidth();
/*  49 */     this.bufferHeight = (int)size.getHeight();
/*     */   }
/*     */   
/*     */   public void setForceAntiAliasing(boolean forceAntiAliasing) {
/*  53 */     this.forceAntiAliasing = forceAntiAliasing;
/*     */   }
/*     */   
/*     */   private void initBuffer() {
/*  57 */     this.bufferImage = createImage(this.bufferWidth, this.bufferHeight);
/*  58 */     if (this.bufferImage == null) {
/*  59 */       throw new IllegalStateException("null buffer image");
/*     */     }
/*  61 */     this.bufferGraphics = this.bufferImage.getGraphics();
/*     */     
/*  63 */     if (this.forceAntiAliasing && this.bufferGraphics instanceof Graphics2D) {
/*  64 */       Graphics2D g2d = (Graphics2D)this.bufferGraphics;
/*  65 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     } 
/*     */     
/*  68 */     resetBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Graphics g) {
/*  74 */     paint(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/*  83 */     this.pendingPaint.set(false);
/*  84 */     g.drawImage(this.bufferImage, 0, 0, this);
/*     */   }
/*     */   
/*     */   public void paint(GDObject o, GDState state) {
/*  88 */     if (this.bufferImage == null) {
/*  89 */       initBuffer();
/*     */     }
/*     */     
/*  92 */     o.paint(this, state, this.bufferGraphics);
/*  93 */     if (!this.paused) {
/*  94 */       scheduleRepaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public Graphics getBufferGraphics() {
/*  99 */     return this.bufferGraphics;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 103 */     resetBuffer();
/* 104 */     scheduleRepaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void scheduleRepaint() {
/* 111 */     if (this.pendingPaint.compareAndSet(false, true)) {
/* 112 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetBuffer() {
/* 117 */     if (this.bufferGraphics != null) {
/* 118 */       this.bufferGraphics.clearRect(0, 0, this.bufferWidth, this.bufferHeight);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRepaintPaused(boolean paused) {
/* 123 */     this.paused = paused;
/* 124 */     if (!paused)
/* 125 */       scheduleRepaint(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/AwtPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */