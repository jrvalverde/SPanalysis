/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import org.renjin.eval.Session;
/*    */ import org.renjin.sexp.ListVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileDevice
/*    */   extends GraphicsDevice
/*    */ {
/*    */   private final Session session;
/*    */   private final String filename;
/*    */   private final String format;
/*    */   private final Color backgroundColor;
/*    */   
/*    */   public FileDevice(Session session, ListVector deviceOptions) {
/* 36 */     this.session = session;
/* 37 */     this.filename = deviceOptions.getElementAsString("filename");
/* 38 */     this.format = deviceOptions.getElementAsString("format");
/* 39 */     this.backgroundColor = Color.WHITE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void open(double w, double h) {
/* 44 */     if (this.format.equals("svg")) {
/* 45 */       this.container = new SvgContainer(this.session, this.filename, (int)w, (int)h, this.backgroundColor);
/*    */     } else {
/* 47 */       this.container = new ImageContainer(this.session, this.filename, this.format, this.backgroundColor, (int)w, (int)h);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/FileDevice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */