/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GDClip
/*     */   implements GDObject
/*     */ {
/*     */   private double x1;
/*     */   private double y1;
/*     */   private double x2;
/*     */   private double y2;
/*     */   
/*     */   public GDClip(double x1, double y1, double x2, double y2) {
/* 148 */     if (x1 > x2) {
/* 149 */       double tmp = x1;
/* 150 */       x1 = x2;
/* 151 */       x2 = tmp;
/*     */     } 
/* 153 */     if (y1 > y2) {
/* 154 */       double tmp = y1;
/* 155 */       y1 = y2;
/* 156 */       y2 = tmp;
/*     */     } 
/* 158 */     this.x1 = x1;
/* 159 */     this.y1 = y1;
/* 160 */     this.x2 = x2;
/* 161 */     this.y2 = y2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Component c, GDState gs, Graphics g) {
/* 166 */     g.setClip((int)(this.x1 + 0.5D), (int)(this.y1 + 0.5D), (int)(this.x2 - this.x1 + 1.7D), (int)(this.y2 - this.y1 + 1.7D));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GDClip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */