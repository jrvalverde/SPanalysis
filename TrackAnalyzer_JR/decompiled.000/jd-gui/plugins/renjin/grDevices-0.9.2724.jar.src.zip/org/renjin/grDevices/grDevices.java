package org.renjin.grDevices;

import java.lang.invoke.MethodHandle;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.primitives.packaging.DllInfo;
import org.renjin.sexp.SEXP;

public class grDevices {
  public static int Rf_nextDevice(int paramInt) {
    return baseDevices__.Rf_nextDevice(paramInt);
  }
  
  public static double GEfromDeviceWidth(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEfromDeviceWidth(paramDouble, paramInt, paramPtr);
  }
  
  public static SEXP devnext(SEXP paramSEXP) {
    return devices__.devnext(paramSEXP);
  }
  
  public static SEXP X11(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.X11(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static int inRGBpar3(SEXP paramSEXP, int paramInt1, int paramInt2) {
    return colors__.inRGBpar3(paramSEXP, paramInt1, paramInt2);
  }
  
  public static int GErecording(SEXP paramSEXP, Ptr paramPtr) {
    return baseEngine__.GErecording(paramSEXP, paramPtr);
  }
  
  public static int GEdeviceDirty(Ptr paramPtr) {
    return baseEngine__.GEdeviceDirty(paramPtr);
  }
  
  public static int Rf_RGBpar3(SEXP paramSEXP, int paramInt1, int paramInt2) {
    return colors__.Rf_RGBpar3(paramSEXP, paramInt1, paramInt2);
  }
  
  public static int Rf_GetOptionDeviceAsk() {
    return baseDevices__.Rf_GetOptionDeviceAsk();
  }
  
  public static void GELine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.GELine(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramPtr1, paramPtr2);
  }
  
  public static void R_GE_rasterScale(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4) {
    baseEngine__.R_GE_rasterScale(paramPtr1, paramInt1, paramInt2, paramPtr2, paramInt3, paramInt4);
  }
  
  public static void GEplayDisplayList(Ptr paramPtr) {
    baseEngine__.GEplayDisplayList(paramPtr);
  }
  
  public static int newJavaGDDeviceDriver(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, SEXP paramSEXP, double paramDouble1, double paramDouble2, double paramDouble3) {
    return javaGD__.newJavaGDDeviceDriver(paramPtr1, paramPtr2, paramPtr3, paramSEXP, paramDouble1, paramDouble2, paramDouble3);
  }
  
  public static int Rf_curDevice() {
    return baseDevices__.Rf_curDevice();
  }
  
  public static double GEStrWidth(Ptr paramPtr1, int paramInt, Ptr paramPtr2, Ptr paramPtr3) {
    return baseEngine__.GEStrWidth(paramPtr1, paramInt, paramPtr2, paramPtr3);
  }
  
  public static void GErecordGraphicOperation(SEXP paramSEXP1, SEXP paramSEXP2, Ptr paramPtr) {
    baseEngine__.GErecordGraphicOperation(paramSEXP1, paramSEXP2, paramPtr);
  }
  
  public static void R_GE_rasterRotate(Ptr paramPtr1, int paramInt1, int paramInt2, double paramDouble, Ptr paramPtr2, Ptr paramPtr3, int paramInt3) {
    baseEngine__.R_GE_rasterRotate(paramPtr1, paramInt1, paramInt2, paramDouble, paramPtr2, paramPtr3, paramInt3);
  }
  
  public static void GEaddDevice2f(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    baseDevices__.GEaddDevice2f(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static int Rf_ndevNumber(Ptr paramPtr) {
    return baseDevices__.Rf_ndevNumber(paramPtr);
  }
  
  public static void resizedJavaGD(Ptr paramPtr) {
    javaGD__.resizedJavaGD(paramPtr);
  }
  
  public static SEXP colors() {
    return colors__.colors();
  }
  
  public static SEXP contourLines(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.contourLines(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void GEaddDevice2(Ptr paramPtr1, Ptr paramPtr2) {
    baseDevices__.GEaddDevice2(paramPtr1, paramPtr2);
  }
  
  public static SEXP GE_LJOINget(int paramInt) {
    return baseEngine__.GE_LJOINget(paramInt);
  }
  
  public static void Rf_NewFrameConfirm(Ptr paramPtr) {
    baseDevices__.Rf_NewFrameConfirm(paramPtr);
  }
  
  public static SEXP palette2(SEXP paramSEXP) {
    return colors__.palette2(paramSEXP);
  }
  
  public static SEXP hcl(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5) {
    return colors__.hcl(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5);
  }
  
  public static int Rf_selectDevice(int paramInt) {
    return baseDevices__.Rf_selectDevice(paramInt);
  }
  
  public static SEXP RGB2hsv(SEXP paramSEXP) {
    return colors__.RGB2hsv(paramSEXP);
  }
  
  public static int GE_LJOINpar(SEXP paramSEXP, int paramInt) {
    return baseEngine__.GE_LJOINpar(paramSEXP, paramInt);
  }
  
  public static SEXP devdisplaylist(SEXP paramSEXP) {
    return devices__.devdisplaylist(paramSEXP);
  }
  
  public static SEXP getGraphicsEvent(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.getGraphicsEvent(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static double GEfromDeviceY(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEfromDeviceY(paramDouble, paramInt, paramPtr);
  }
  
  public static double GEfromDeviceX(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEfromDeviceX(paramDouble, paramInt, paramPtr);
  }
  
  public static void GEregisterWithDevice(Ptr paramPtr) {
    baseEngine__.GEregisterWithDevice(paramPtr);
  }
  
  public static void GESetClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr) {
    baseEngine__.GESetClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramPtr);
  }
  
  public static SEXP devset(SEXP paramSEXP) {
    return devices__.devset(paramSEXP);
  }
  
  public static void GEPolygon(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    baseEngine__.GEPolygon(paramInt, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static SEXP do_dotcallgr(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return dotcode__.do_dotcallgr(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP GEcreateSnapshot(Ptr paramPtr) {
    return baseEngine__.GEcreateSnapshot(paramPtr);
  }
  
  public static Ptr Quartz_C(Ptr paramPtr1, MethodHandle paramMethodHandle, Ptr paramPtr2) {
    return devQuartz__.Quartz_C(paramPtr1, paramMethodHandle, paramPtr2);
  }
  
  public static SEXP hsv(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return colors__.hsv(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static Ptr Rf_allocNewJavaGDDeviceDesc(double paramDouble) {
    return javaGD__.Rf_allocNewJavaGDDeviceDesc(paramDouble);
  }
  
  public static SEXP javaGDversion() {
    return javaGD__.javaGDversion();
  }
  
  public static SEXP javaGDobjectCall(SEXP paramSEXP) {
    return javaGD__.javaGDobjectCall(paramSEXP);
  }
  
  public static Ptr GEsystemState(Ptr paramPtr, int paramInt) {
    return baseEngine__.GEsystemState(paramPtr, paramInt);
  }
  
  public static void javaGDresize(Ptr paramPtr) {
    javaGD__.javaGDresize(paramPtr);
  }
  
  public static int Rf_NumDevices() {
    return baseDevices__.Rf_NumDevices();
  }
  
  public static SEXP devoff(SEXP paramSEXP) {
    return devices__.devoff(paramSEXP);
  }
  
  public static double GEStrHeight(Ptr paramPtr1, int paramInt, Ptr paramPtr2, Ptr paramPtr3) {
    return baseEngine__.GEStrHeight(paramPtr1, paramInt, paramPtr2, paramPtr3);
  }
  
  public static SEXP javaGDsetDisplayParam(SEXP paramSEXP) {
    return javaGD__.javaGDsetDisplayParam(paramSEXP);
  }
  
  public static SEXP palette(SEXP paramSEXP) {
    return colors__.palette(paramSEXP);
  }
  
  public static SEXP playSnapshot(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.playSnapshot(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void Rf_killDevice(int paramInt) {
    baseDevices__.Rf_killDevice(paramInt);
  }
  
  public static void GENewPage(Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.GENewPage(paramPtr1, paramPtr2);
  }
  
  public static void setupJavaGDfunctions(Ptr paramPtr) {
    jGDtalk__.setupJavaGDfunctions(paramPtr);
  }
  
  public static SEXP javaGDgetDisplayParam() {
    return javaGD__.javaGDgetDisplayParam();
  }
  
  public static Ptr incol2name(int paramInt) {
    return colors__.incol2name(paramInt);
  }
  
  public static Ptr Rf_col2name(int paramInt) {
    return colors__.Rf_col2name(paramInt);
  }
  
  public static void R_GE_rasterRotatedSize(int paramInt1, int paramInt2, double paramDouble, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.R_GE_rasterRotatedSize(paramInt1, paramInt2, paramDouble, paramPtr1, paramPtr2);
  }
  
  public static void R_GE_rasterResizeForRotation(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4, Ptr paramPtr3) {
    baseEngine__.R_GE_rasterResizeForRotation(paramPtr1, paramInt1, paramInt2, paramPtr2, paramInt3, paramInt4, paramPtr3);
  }
  
  public static int GEdeviceNumber(Ptr paramPtr) {
    return baseDevices__.GEdeviceNumber(paramPtr);
  }
  
  public static void GEStrMetric(Ptr paramPtr1, int paramInt, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5, Ptr paramPtr6) {
    baseEngine__.GEStrMetric(paramPtr1, paramInt, paramPtr2, paramPtr3, paramPtr4, paramPtr5, paramPtr6);
  }
  
  public static SEXP javaGDresizeCall(SEXP paramSEXP) {
    return javaGD__.javaGDresizeCall(paramSEXP);
  }
  
  public static void reloadJavaGD(Ptr paramPtr) {
    javaGD__.reloadJavaGD(paramPtr);
  }
  
  public static SEXP chull(SEXP paramSEXP) {
    return chull__.chull(paramSEXP);
  }
  
  public static SEXP devcap(SEXP paramSEXP) {
    return devices__.devcap(paramSEXP);
  }
  
  public static void R_GE_checkVersionOrDie(int paramInt) {
    baseEngine__.R_GE_checkVersionOrDie(paramInt);
  }
  
  public static void GEregisterSystem(MethodHandle paramMethodHandle, Ptr paramPtr) {
    baseEngine__.GEregisterSystem(paramMethodHandle, paramPtr);
  }
  
  public static double R_pretty(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt1, double paramDouble, Ptr paramPtr4, int paramInt2, int paramInt3) {
    return pretty__.R_pretty(paramPtr1, paramPtr2, paramPtr3, paramInt1, paramDouble, paramPtr4, paramInt2, paramInt3);
  }
  
  public static void initPalette() {
    colors__.initPalette();
  }
  
  public static SEXP devholdflush(SEXP paramSEXP) {
    return devices__.devholdflush(paramSEXP);
  }
  
  public static double GEtoDeviceHeight(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEtoDeviceHeight(paramDouble, paramInt, paramPtr);
  }
  
  public static int Rf_setNewJavaGDDeviceData(Ptr paramPtr1, double paramDouble, Ptr paramPtr2) {
    return javaGD__.Rf_setNewJavaGDDeviceData(paramPtr1, paramDouble, paramPtr2);
  }
  
  public static Ptr Rf_dpptr(Ptr paramPtr) {
    return baseDevices__.Rf_dpptr(paramPtr);
  }
  
  public static int initJavaGD(Ptr paramPtr1, Ptr paramPtr2, SEXP paramSEXP) {
    return jGDtalk__.initJavaGD(paramPtr1, paramPtr2, paramSEXP);
  }
  
  public static SEXP do_getSnapshot(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return baseEngine__.do_getSnapshot(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP rgb(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    return colors__.rgb(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6);
  }
  
  public static void GEonExit() {
    baseEngine__.GEonExit();
  }
  
  public static Ptr GEcreateDevDesc(Ptr paramPtr) {
    return baseDevices__.GEcreateDevDesc(paramPtr);
  }
  
  public static void GERaster(Ptr paramPtr1, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, int paramInt3, Ptr paramPtr2, Ptr paramPtr3) {
    baseEngine__.GERaster(paramPtr1, paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramInt3, paramPtr2, paramPtr3);
  }
  
  public static SEXP setGraphicsEventEnv(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.setGraphicsEventEnv(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP javaGDgetSize(SEXP paramSEXP) {
    return javaGD__.javaGDgetSize(paramSEXP);
  }
  
  public static Ptr getQuartzAPI() {
    return devQuartz__.getQuartzAPI();
  }
  
  public static void GEinitDisplayList(Ptr paramPtr) {
    baseEngine__.GEinitDisplayList(paramPtr);
  }
  
  public static Ptr Rf_desc2GEDesc(Ptr paramPtr) {
    return baseDevices__.Rf_desc2GEDesc(paramPtr);
  }
  
  public static void GEcopyDisplayList(int paramInt) {
    baseEngine__.GEcopyDisplayList(paramInt);
  }
  
  public static SEXP do_recordGraphics(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return baseEngine__.do_recordGraphics(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP devcontrol(SEXP paramSEXP) {
    return devices__.devcontrol(paramSEXP);
  }
  
  public static int R_CheckDeviceAvailableBool() {
    return baseDevices__.R_CheckDeviceAvailableBool();
  }
  
  public static Ptr symbol2utf8(Ptr paramPtr) {
    return s2u__.symbol2utf8(paramPtr);
  }
  
  public static SEXP do_Externalgr(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return dotcode__.do_Externalgr(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void GESymbol(double paramDouble1, double paramDouble2, int paramInt, double paramDouble3, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.GESymbol(paramDouble1, paramDouble2, paramInt, paramDouble3, paramPtr1, paramPtr2);
  }
  
  public static void GEplaySnapshot(SEXP paramSEXP, Ptr paramPtr) {
    baseEngine__.GEplaySnapshot(paramSEXP, paramPtr);
  }
  
  public static SEXP gray(SEXP paramSEXP1, SEXP paramSEXP2) {
    return colors__.gray(paramSEXP1, paramSEXP2);
  }
  
  public static SEXP devcur(SEXP paramSEXP) {
    return devices__.devcur(paramSEXP);
  }
  
  public static SEXP Quartz(SEXP paramSEXP) {
    return devQuartz__.Quartz(paramSEXP);
  }
  
  public static Ptr GEgetDevice(int paramInt) {
    return baseDevices__.GEgetDevice(paramInt);
  }
  
  public static void GECircle(double paramDouble1, double paramDouble2, double paramDouble3, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.GECircle(paramDouble1, paramDouble2, paramDouble3, paramPtr1, paramPtr2);
  }
  
  public static void GEMode(int paramInt, Ptr paramPtr) {
    baseEngine__.GEMode(paramInt, paramPtr);
  }
  
  public static void GEcleanDevice(Ptr paramPtr) {
    baseEngine__.GEcleanDevice(paramPtr);
  }
  
  public static SEXP do_playSnapshot(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return baseEngine__.do_playSnapshot(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void GERect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.GERect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramPtr1, paramPtr2);
  }
  
  public static SEXP bmVersion() {
    return stubs__.bmVersion();
  }
  
  public static int GEcheckState(Ptr paramPtr) {
    return baseEngine__.GEcheckState(paramPtr);
  }
  
  public static void GEunregisterSystem(int paramInt) {
    baseEngine__.GEunregisterSystem(paramInt);
  }
  
  public static double GEtoDeviceY(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEtoDeviceY(paramDouble, paramInt, paramPtr);
  }
  
  public static double GEtoDeviceX(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEtoDeviceX(paramDouble, paramInt, paramPtr);
  }
  
  public static void GEMetricInfo(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, Ptr paramPtr5) {
    baseEngine__.GEMetricInfo(paramInt, paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramPtr5);
  }
  
  public static SEXP newJavaGD(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4, SEXP paramSEXP5, SEXP paramSEXP6) {
    return javaGD__.newJavaGD(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4, paramSEXP5, paramSEXP6);
  }
  
  public static int inR_GE_str2col(Ptr paramPtr) {
    return colors__.inR_GE_str2col(paramPtr);
  }
  
  public static SEXP GE_LENDget(int paramInt) {
    return baseEngine__.GE_LENDget(paramInt);
  }
  
  public static int GEstring_to_pch(SEXP paramSEXP) {
    return baseEngine__.GEstring_to_pch(paramSEXP);
  }
  
  public static void R_GE_rasterRotatedOffset(int paramInt1, int paramInt2, double paramDouble, int paramInt3, Ptr paramPtr1, Ptr paramPtr2) {
    baseEngine__.R_GE_rasterRotatedOffset(paramInt1, paramInt2, paramDouble, paramInt3, paramPtr1, paramPtr2);
  }
  
  public static void GEPolyline(int paramInt, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4) {
    baseEngine__.GEPolyline(paramInt, paramPtr1, paramPtr2, paramPtr3, paramPtr4);
  }
  
  public static SEXP col2rgb(SEXP paramSEXP1, SEXP paramSEXP2) {
    return colors__.col2rgb(paramSEXP1, paramSEXP2);
  }
  
  public static int Rf_prevDevice(int paramInt) {
    return baseDevices__.Rf_prevDevice(paramInt);
  }
  
  public static void R_GE_rasterInterpolate(Ptr paramPtr1, int paramInt1, int paramInt2, Ptr paramPtr2, int paramInt3, int paramInt4) {
    baseEngine__.R_GE_rasterInterpolate(paramPtr1, paramInt1, paramInt2, paramPtr2, paramInt3, paramInt4);
  }
  
  public static double GEfromDeviceHeight(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEfromDeviceHeight(paramDouble, paramInt, paramPtr);
  }
  
  public static SEXP recordGraphics(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return recordGraphics__.recordGraphics(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP GEhandleEvent(int paramInt, Ptr paramPtr, SEXP paramSEXP) {
    return baseEngine__.GEhandleEvent(paramInt, paramPtr, paramSEXP);
  }
  
  public static SEXP devsize(SEXP paramSEXP) {
    return devices__.devsize(paramSEXP);
  }
  
  public static SEXP R_CreateAtVector(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return axis_scales__.R_CreateAtVector(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP makeQuartzDefault() {
    return devQuartz__.makeQuartzDefault();
  }
  
  public static SEXP R_GAxisPars(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3) {
    return axis_scales__.R_GAxisPars(paramSEXP1, paramSEXP2, paramSEXP3);
  }
  
  public static SEXP devcopy(SEXP paramSEXP) {
    return devices__.devcopy(paramSEXP);
  }
  
  public static SEXP GECap(Ptr paramPtr) {
    return baseEngine__.GECap(paramPtr);
  }
  
  public static void GEkillDevice(Ptr paramPtr) {
    baseDevices__.GEkillDevice(paramPtr);
  }
  
  public static SEXP getGraphicsEventEnv(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.getGraphicsEventEnv(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void GEText(double paramDouble1, double paramDouble2, Ptr paramPtr1, int paramInt, double paramDouble3, double paramDouble4, double paramDouble5, Ptr paramPtr2, Ptr paramPtr3) {
    baseEngine__.GEText(paramDouble1, paramDouble2, paramPtr1, paramInt, paramDouble3, paramDouble4, paramDouble5, paramPtr2, paramPtr3);
  }
  
  public static double GEtoDeviceWidth(double paramDouble, int paramInt, Ptr paramPtr) {
    return baseEngine__.GEtoDeviceWidth(paramDouble, paramInt, paramPtr);
  }
  
  public static void GEPretty(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3) {
    baseEngine__.GEPretty(paramPtr1, paramPtr2, paramPtr3);
  }
  
  public static void R_init_grDevices(DllInfo paramDllInfo) {
    init__.R_init_grDevices(paramDllInfo);
  }
  
  public static SEXP devAskNewPage(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.devAskNewPage(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP GE_LTYget(int paramInt) {
    return baseEngine__.GE_LTYget(paramInt);
  }
  
  public static void GEdirtyDevice(Ptr paramPtr) {
    baseEngine__.GEdirtyDevice(paramPtr);
  }
  
  public static Ptr GEcurrentDevice() {
    return baseDevices__.GEcurrentDevice();
  }
  
  public static void GEdestroyDevDesc(Ptr paramPtr) {
    baseEngine__.GEdestroyDevDesc(paramPtr);
  }
  
  public static int GE_LENDpar(SEXP paramSEXP, int paramInt) {
    return baseEngine__.GE_LENDpar(paramSEXP, paramInt);
  }
  
  public static int R_GE_getVersion() {
    return baseEngine__.R_GE_getVersion();
  }
  
  public static int GE_LTYpar(SEXP paramSEXP, int paramInt) {
    return baseEngine__.GE_LTYpar(paramSEXP, paramInt);
  }
  
  public static SEXP devprev(SEXP paramSEXP) {
    return devices__.devprev(paramSEXP);
  }
  
  public static void GEPath(Ptr paramPtr1, Ptr paramPtr2, int paramInt1, Ptr paramPtr3, int paramInt2, Ptr paramPtr4, Ptr paramPtr5) {
    baseEngine__.GEPath(paramPtr1, paramPtr2, paramInt1, paramPtr3, paramInt2, paramPtr4, paramPtr5);
  }
  
  public static void R_CheckDeviceAvailable() {
    baseDevices__.R_CheckDeviceAvailable();
  }
  
  public static int Rf_NoDevices() {
    return baseDevices__.Rf_NoDevices();
  }
  
  public static SEXP savePlot(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.savePlot(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static void Rf_KillAllDevices() {
    baseDevices__.Rf_KillAllDevices();
  }
  
  public static void savePalette(int paramInt) {
    colors__.savePalette(paramInt);
  }
  
  public static void Rf_InitGraphics() {
    baseDevices__.Rf_InitGraphics();
  }
  
  public static int newJavaGD_Open(Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, Ptr paramPtr4, SEXP paramSEXP, double paramDouble1, double paramDouble2) {
    return jGDtalk__.newJavaGD_Open(paramPtr1, paramPtr2, paramPtr3, paramPtr4, paramSEXP, paramDouble1, paramDouble2);
  }
  
  public static SEXP GEXspline(int paramInt1, Ptr paramPtr1, Ptr paramPtr2, Ptr paramPtr3, int paramInt2, int paramInt3, int paramInt4, Ptr paramPtr4, Ptr paramPtr5) {
    return baseEngine__.GEXspline(paramInt1, paramPtr1, paramPtr2, paramPtr3, paramInt2, paramInt3, paramInt4, paramPtr4, paramPtr5);
  }
  
  public static void GEaddDevice(Ptr paramPtr) {
    baseDevices__.GEaddDevice(paramPtr);
  }
  
  public static SEXP getSnapshot(SEXP paramSEXP1, SEXP paramSEXP2, SEXP paramSEXP3, SEXP paramSEXP4) {
    return stubs__.getSnapshot(paramSEXP1, paramSEXP2, paramSEXP3, paramSEXP4);
  }
  
  public static SEXP devcapture(SEXP paramSEXP) {
    return devices__.devcapture(paramSEXP);
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/grDevices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */