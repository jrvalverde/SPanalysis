/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Defn;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class recordGraphics__
/*     */ {
/*     */   public static SEXP recordGraphics(SEXP code, SEXP list, SEXP parentenv) {
/*  50 */     record = 0; dd = BytePtr.of(0); dd$offset = 0; x = (SEXP)BytePtr.of(0).getArray(); dd = baseDevices__.GEcurrentDevice(); dd$offset = 0;
/*  51 */     record = dd.getInt(dd$offset + 24);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (!Rinternals.Rf_isLanguage(code))
/*  75 */       Error.Rf_error(new BytePtr("'expr' argument must be an expression\000".getBytes(), 0), new Object[0]); 
/*  76 */     if (Rinternals.TYPEOF(list) != 19)
/*  77 */       Error.Rf_error(new BytePtr("'list' argument must be a list\000".getBytes(), 0), new Object[0]); 
/*  78 */     if (Rinternals.TYPEOF(parentenv) == 0) {
/*  79 */       Error.Rf_error(new BytePtr("use of NULL environment is defunct\000".getBytes(), 0), new Object[0]);
/*     */     }
/*     */     
/*  82 */     if (Rinternals.TYPEOF(parentenv) != 4) {
/*  83 */       Error.Rf_error(new BytePtr("'env' argument must be an environment\000".getBytes(), 0), new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  87 */     x = Rinternals.Rf_VectorToPairList(list); Rinternals.Rf_protect(x);
/*  88 */     xptr = x; while (true) { R_NilValue$0 = Rinternals.R_NilValue; if (xptr != R_NilValue$0) {
/*  89 */         SEXP sEXP = Rinternals.CAR(xptr); xptr = Rinternals.CDR(xptr);
/*     */         continue;
/*     */       } 
/*     */       break; }
/*     */     
/*  94 */     evalenv = Defn.Rf_NewEnvironment(Rinternals.R_NilValue, x, parentenv); Rinternals.Rf_protect(evalenv);
/*  95 */     dd.setInt(dd$offset + 24, 0);
/*  96 */     retval = Rinternals.Rf_eval(code, evalenv); Rinternals.Rf_protect(retval);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     dd.setInt(dd$offset + 24, record);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return retval;
/*     */   }
/*     */   
/*     */   static {
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/recordGraphics__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */