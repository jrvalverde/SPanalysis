/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.IntPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class chull__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static void split(int n, Ptr x, int m, Ptr in, int ii, int jj, int s, Ptr iabv, Ptr na, Ptr maxa, Ptr ibel, Ptr nb, Ptr maxb) {
/*  74 */     neg_dir = 0; vert = 0; xt = 0.0D; up = 0.0D; down = 0.0D; b = 0.0D; a = 0.0D; a = 0.0D; b = 0.0D;
/*     */     
/*  76 */     neg_dir = 0;
/*     */ 
/*     */     
/*  79 */     x = x.pointerPlus(-8);
/*     */     
/*  81 */     int i6 = ii * 8; Ptr ptr4 = x; int i5 = i6; xt = ptr4.getDouble(i5);
/*     */     
/*  83 */     int i4 = jj * 8; Ptr ptr3 = x; int i3 = i4; vert = (ptr3.getDouble(i3) != xt) ? 0 : 1;
/*  84 */     int i2 = (jj + n) * 8; Ptr ptr2 = x; int i1 = i2; double d3 = ptr2.getDouble(i1); int k = (ii + n) * 8; Ptr ptr1 = x; int j = k; double d2 = ptr1.getDouble(j); d1 = d3 - d2;
/*  85 */     if (vert == 0)
/*     */     
/*     */     { 
/*  88 */       int i10 = jj * 8; Ptr ptr6 = x; int i9 = i10; double d6 = ptr6.getDouble(i9) - xt; a = d1 / d6;
/*  89 */       int i8 = (ii + n) * 8; Ptr ptr5 = x; int i7 = i8; double d5 = ptr5.getDouble(i7), d4 = a * xt; b = d5 - d4; } else { if ((s <= 0 || d1 >= 0.0D) && (s >= 0 || d1 <= 0.0D)) { iftmp$113 = 0; } else { iftmp$113 = 1; }
/*     */        neg_dir = iftmp$113; }
/*  91 */      up = 0.0D; na.setInt(0); maxa.setInt(0);
/*  92 */     down = 0.0D; nb.setInt(0); maxb.setInt(0);
/*  93 */     for (i = 0; i < m; i++) {
/*  94 */       int i8 = i * 4; Ptr ptr = in; int i7 = i8; is = ptr.getInt(i7);
/*  95 */       if (vert == 0)
/*     */       
/*     */       { 
/*     */         
/*  99 */         int i12 = (is + n) * 8; Ptr ptr6 = x; int i11 = i12; double d5 = ptr6.getDouble(i11); int i10 = is * 8; Ptr ptr5 = x; int i9 = i10; double d4 = ptr5.getDouble(i9) * a; z = d5 - d4 - b; } else if (neg_dir == 0) { int i10 = is * 8; Ptr ptr5 = x; int i9 = i10; z = ptr5.getDouble(i9) - xt; }
/*     */       else { int i10 = is * 8; Ptr ptr5 = x; int i9 = i10; double d = ptr5.getDouble(i9); z = xt - d; }
/* 101 */        if (z <= 0.0D) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         if (s != 2 && z < 0.0D) {
/* 111 */           int i11 = nb.getInt() * 4; Ptr ptr5 = ibel; int i10 = i11; ptr5.setInt(i10, is);
/* 112 */           int i9 = nb.getInt() + 1; nb.setInt(i9);
/* 113 */           if (z <= down) {
/* 114 */             down = z;
/* 115 */             int i12 = nb.getInt(); maxb.setInt(i12);
/*     */           } 
/*     */         } 
/*     */       } else if (s != -2) {
/*     */         int i11 = na.getInt() * 4;
/*     */         Ptr ptr5 = iabv;
/*     */         int i10 = i11;
/*     */         ptr5.setInt(i10, is);
/*     */         int i9 = na.getInt() + 1;
/*     */         na.setInt(i9);
/*     */         if (z >= up) {
/*     */           up = z;
/*     */           int i12 = na.getInt();
/*     */           maxa.setInt(i12);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void in_chull(Ptr n, Ptr x, Ptr m, Ptr in, Ptr ia, Ptr ib, Ptr ih, Ptr nh, Ptr il) {
/*     */     // Byte code:
/*     */     //   0: iconst_1
/*     */     //   1: newarray int
/*     */     //   3: astore #13
/*     */     //   5: iconst_1
/*     */     //   6: newarray int
/*     */     //   8: astore #14
/*     */     //   10: iconst_1
/*     */     //   11: newarray int
/*     */     //   13: astore #15
/*     */     //   15: iconst_1
/*     */     //   16: newarray int
/*     */     //   18: astore #20
/*     */     //   20: iconst_1
/*     */     //   21: newarray int
/*     */     //   23: astore #26
/*     */     //   25: iconst_0
/*     */     //   26: istore #11
/*     */     //   28: iconst_0
/*     */     //   29: istore #12
/*     */     //   31: aload #13
/*     */     //   33: iconst_0
/*     */     //   34: iconst_0
/*     */     //   35: iastore
/*     */     //   36: aload #14
/*     */     //   38: iconst_0
/*     */     //   39: iconst_0
/*     */     //   40: iastore
/*     */     //   41: aload #15
/*     */     //   43: iconst_0
/*     */     //   44: iconst_0
/*     */     //   45: iastore
/*     */     //   46: iconst_0
/*     */     //   47: istore #16
/*     */     //   49: iconst_0
/*     */     //   50: istore #17
/*     */     //   52: iconst_0
/*     */     //   53: istore #18
/*     */     //   55: aload #20
/*     */     //   57: iconst_0
/*     */     //   58: iconst_0
/*     */     //   59: iastore
/*     */     //   60: iconst_0
/*     */     //   61: istore #21
/*     */     //   63: iconst_0
/*     */     //   64: istore #22
/*     */     //   66: iconst_0
/*     */     //   67: istore #23
/*     */     //   69: iconst_0
/*     */     //   70: istore #25
/*     */     //   72: aload #26
/*     */     //   74: iconst_0
/*     */     //   75: iconst_0
/*     */     //   76: iastore
/*     */     //   77: iconst_0
/*     */     //   78: istore #31
/*     */     //   80: iconst_0
/*     */     //   81: istore #32
/*     */     //   83: aload_0
/*     */     //   84: invokeinterface getInt : ()I
/*     */     //   89: istore #12
/*     */     //   91: iconst_1
/*     */     //   92: istore #11
/*     */     //   94: iload #11
/*     */     //   96: bipush #8
/*     */     //   98: imul
/*     */     //   99: ineg
/*     */     //   100: wide istore #572
/*     */     //   104: aload_1
/*     */     //   105: wide iload #572
/*     */     //   109: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   114: astore_1
/*     */     //   115: aload #8
/*     */     //   117: bipush #-4
/*     */     //   119: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   124: astore #8
/*     */     //   126: aload #6
/*     */     //   128: bipush #-4
/*     */     //   130: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   135: astore #6
/*     */     //   137: aload #5
/*     */     //   139: bipush #-4
/*     */     //   141: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   146: astore #5
/*     */     //   148: aload #4
/*     */     //   150: bipush #-4
/*     */     //   152: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   157: astore #4
/*     */     //   159: aload_3
/*     */     //   160: bipush #-4
/*     */     //   162: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   167: astore_3
/*     */     //   168: aload_2
/*     */     //   169: invokeinterface getInt : ()I
/*     */     //   174: iconst_1
/*     */     //   175: if_icmpeq -> 181
/*     */     //   178: goto -> 184
/*     */     //   181: goto -> 4475
/*     */     //   184: aload #8
/*     */     //   186: iconst_4
/*     */     //   187: iconst_2
/*     */     //   188: invokeinterface setInt : (II)V
/*     */     //   193: aload #8
/*     */     //   195: bipush #8
/*     */     //   197: iconst_1
/*     */     //   198: invokeinterface setInt : (II)V
/*     */     //   203: aload_3
/*     */     //   204: iconst_1
/*     */     //   205: invokeinterface getAlignedInt : (I)I
/*     */     //   210: istore #25
/*     */     //   212: aload_3
/*     */     //   213: iconst_2
/*     */     //   214: invokeinterface getAlignedInt : (I)I
/*     */     //   219: istore #23
/*     */     //   221: aload_2
/*     */     //   222: invokeinterface getInt : ()I
/*     */     //   227: iconst_2
/*     */     //   228: if_icmpeq -> 234
/*     */     //   231: goto -> 237
/*     */     //   234: goto -> 4304
/*     */     //   237: aload_2
/*     */     //   238: invokeinterface getInt : ()I
/*     */     //   243: iconst_1
/*     */     //   244: iadd
/*     */     //   245: istore #21
/*     */     //   247: iconst_1
/*     */     //   248: istore #16
/*     */     //   250: iconst_1
/*     */     //   251: istore #22
/*     */     //   253: aload_3
/*     */     //   254: iconst_1
/*     */     //   255: invokeinterface getAlignedInt : (I)I
/*     */     //   260: istore #23
/*     */     //   262: iconst_0
/*     */     //   263: istore #31
/*     */     //   265: iconst_0
/*     */     //   266: istore #32
/*     */     //   268: iconst_2
/*     */     //   269: istore #30
/*     */     //   271: goto -> 565
/*     */     //   274: iload #30
/*     */     //   276: iconst_4
/*     */     //   277: imul
/*     */     //   278: wide istore #563
/*     */     //   282: aload_3
/*     */     //   283: wide astore #561
/*     */     //   287: wide iload #563
/*     */     //   291: wide istore #562
/*     */     //   295: wide aload #561
/*     */     //   299: wide iload #562
/*     */     //   303: invokeinterface getInt : (I)I
/*     */     //   308: istore #29
/*     */     //   310: iload #29
/*     */     //   312: bipush #8
/*     */     //   314: imul
/*     */     //   315: wide istore #559
/*     */     //   319: aload_1
/*     */     //   320: wide astore #557
/*     */     //   324: wide iload #559
/*     */     //   328: wide istore #558
/*     */     //   332: wide aload #557
/*     */     //   336: wide iload #558
/*     */     //   340: invokeinterface getDouble : (I)D
/*     */     //   345: wide dstore #555
/*     */     //   349: iload #23
/*     */     //   351: bipush #8
/*     */     //   353: imul
/*     */     //   354: wide istore #553
/*     */     //   358: aload_1
/*     */     //   359: wide astore #551
/*     */     //   363: wide iload #553
/*     */     //   367: wide istore #552
/*     */     //   371: wide aload #551
/*     */     //   375: wide iload #552
/*     */     //   379: invokeinterface getDouble : (I)D
/*     */     //   384: wide dstore #549
/*     */     //   388: wide dload #555
/*     */     //   392: wide dload #549
/*     */     //   396: dsub
/*     */     //   397: dstore #9
/*     */     //   399: dload #9
/*     */     //   401: dconst_0
/*     */     //   402: dcmpg
/*     */     //   403: iflt -> 436
/*     */     //   406: goto -> 409
/*     */     //   409: dload #9
/*     */     //   411: dconst_0
/*     */     //   412: dcmpl
/*     */     //   413: ifeq -> 419
/*     */     //   416: goto -> 425
/*     */     //   419: iconst_1
/*     */     //   420: istore #31
/*     */     //   422: goto -> 436
/*     */     //   425: iconst_0
/*     */     //   426: istore #31
/*     */     //   428: iload #30
/*     */     //   430: istore #22
/*     */     //   432: iload #29
/*     */     //   434: istore #23
/*     */     //   436: iload #29
/*     */     //   438: bipush #8
/*     */     //   440: imul
/*     */     //   441: wide istore #547
/*     */     //   445: aload_1
/*     */     //   446: wide astore #545
/*     */     //   450: wide iload #547
/*     */     //   454: wide istore #546
/*     */     //   458: wide aload #545
/*     */     //   462: wide iload #546
/*     */     //   466: invokeinterface getDouble : (I)D
/*     */     //   471: wide dstore #543
/*     */     //   475: iload #25
/*     */     //   477: bipush #8
/*     */     //   479: imul
/*     */     //   480: wide istore #541
/*     */     //   484: aload_1
/*     */     //   485: wide astore #539
/*     */     //   489: wide iload #541
/*     */     //   493: wide istore #540
/*     */     //   497: wide aload #539
/*     */     //   501: wide iload #540
/*     */     //   505: invokeinterface getDouble : (I)D
/*     */     //   510: wide dstore #537
/*     */     //   514: wide dload #543
/*     */     //   518: wide dload #537
/*     */     //   522: dsub
/*     */     //   523: dstore #9
/*     */     //   525: dload #9
/*     */     //   527: dconst_0
/*     */     //   528: dcmpg
/*     */     //   529: iflt -> 535
/*     */     //   532: goto -> 549
/*     */     //   535: iconst_0
/*     */     //   536: istore #32
/*     */     //   538: iload #30
/*     */     //   540: istore #16
/*     */     //   542: iload #29
/*     */     //   544: istore #25
/*     */     //   546: goto -> 562
/*     */     //   549: dload #9
/*     */     //   551: dconst_0
/*     */     //   552: dcmpl
/*     */     //   553: ifeq -> 559
/*     */     //   556: goto -> 562
/*     */     //   559: iconst_1
/*     */     //   560: istore #32
/*     */     //   562: iinc #30, 1
/*     */     //   565: aload_2
/*     */     //   566: invokeinterface getInt : ()I
/*     */     //   571: iload #30
/*     */     //   573: if_icmpge -> 274
/*     */     //   576: goto -> 579
/*     */     //   579: iload #23
/*     */     //   581: iload #25
/*     */     //   583: if_icmpeq -> 589
/*     */     //   586: goto -> 592
/*     */     //   589: goto -> 4076
/*     */     //   592: iload #31
/*     */     //   594: ifne -> 608
/*     */     //   597: goto -> 600
/*     */     //   600: iload #32
/*     */     //   602: ifne -> 608
/*     */     //   605: goto -> 1154
/*     */     //   608: iload #31
/*     */     //   610: ifne -> 616
/*     */     //   613: goto -> 881
/*     */     //   616: iconst_1
/*     */     //   617: istore #30
/*     */     //   619: goto -> 867
/*     */     //   622: iload #30
/*     */     //   624: iconst_4
/*     */     //   625: imul
/*     */     //   626: wide istore #534
/*     */     //   630: aload_3
/*     */     //   631: wide astore #532
/*     */     //   635: wide iload #534
/*     */     //   639: wide istore #533
/*     */     //   643: wide aload #532
/*     */     //   647: wide iload #533
/*     */     //   651: invokeinterface getInt : (I)I
/*     */     //   656: istore #29
/*     */     //   658: iload #29
/*     */     //   660: bipush #8
/*     */     //   662: imul
/*     */     //   663: wide istore #530
/*     */     //   667: aload_1
/*     */     //   668: wide astore #528
/*     */     //   672: wide iload #530
/*     */     //   676: wide istore #529
/*     */     //   680: wide aload #528
/*     */     //   684: wide iload #529
/*     */     //   688: invokeinterface getDouble : (I)D
/*     */     //   693: wide dstore #526
/*     */     //   697: iload #23
/*     */     //   699: bipush #8
/*     */     //   701: imul
/*     */     //   702: wide istore #524
/*     */     //   706: aload_1
/*     */     //   707: wide astore #522
/*     */     //   711: wide iload #524
/*     */     //   715: wide istore #523
/*     */     //   719: wide aload #522
/*     */     //   723: wide iload #523
/*     */     //   727: invokeinterface getDouble : (I)D
/*     */     //   732: wide dstore #520
/*     */     //   736: wide dload #526
/*     */     //   740: wide dload #520
/*     */     //   744: dcmpl
/*     */     //   745: ifne -> 751
/*     */     //   748: goto -> 754
/*     */     //   751: goto -> 864
/*     */     //   754: iload #29
/*     */     //   756: iload #12
/*     */     //   758: iadd
/*     */     //   759: bipush #8
/*     */     //   761: imul
/*     */     //   762: wide istore #517
/*     */     //   766: aload_1
/*     */     //   767: wide astore #515
/*     */     //   771: wide iload #517
/*     */     //   775: wide istore #516
/*     */     //   779: wide aload #515
/*     */     //   783: wide iload #516
/*     */     //   787: invokeinterface getDouble : (I)D
/*     */     //   792: wide dstore #513
/*     */     //   796: iload #23
/*     */     //   798: iload #12
/*     */     //   800: iadd
/*     */     //   801: bipush #8
/*     */     //   803: imul
/*     */     //   804: wide istore #510
/*     */     //   808: aload_1
/*     */     //   809: wide astore #508
/*     */     //   813: wide iload #510
/*     */     //   817: wide istore #509
/*     */     //   821: wide aload #508
/*     */     //   825: wide iload #509
/*     */     //   829: invokeinterface getDouble : (I)D
/*     */     //   834: wide dstore #506
/*     */     //   838: wide dload #513
/*     */     //   842: wide dload #506
/*     */     //   846: dcmpg
/*     */     //   847: ifle -> 853
/*     */     //   850: goto -> 856
/*     */     //   853: goto -> 864
/*     */     //   856: iload #30
/*     */     //   858: istore #22
/*     */     //   860: iload #29
/*     */     //   862: istore #23
/*     */     //   864: iinc #30, 1
/*     */     //   867: aload_2
/*     */     //   868: invokeinterface getInt : ()I
/*     */     //   873: iload #30
/*     */     //   875: if_icmpge -> 622
/*     */     //   878: goto -> 881
/*     */     //   881: iload #32
/*     */     //   883: ifne -> 889
/*     */     //   886: goto -> 1154
/*     */     //   889: iconst_1
/*     */     //   890: istore #30
/*     */     //   892: goto -> 1140
/*     */     //   895: iload #30
/*     */     //   897: iconst_4
/*     */     //   898: imul
/*     */     //   899: wide istore #503
/*     */     //   903: aload_3
/*     */     //   904: wide astore #501
/*     */     //   908: wide iload #503
/*     */     //   912: wide istore #502
/*     */     //   916: wide aload #501
/*     */     //   920: wide iload #502
/*     */     //   924: invokeinterface getInt : (I)I
/*     */     //   929: istore #29
/*     */     //   931: iload #29
/*     */     //   933: bipush #8
/*     */     //   935: imul
/*     */     //   936: wide istore #499
/*     */     //   940: aload_1
/*     */     //   941: wide astore #497
/*     */     //   945: wide iload #499
/*     */     //   949: wide istore #498
/*     */     //   953: wide aload #497
/*     */     //   957: wide iload #498
/*     */     //   961: invokeinterface getDouble : (I)D
/*     */     //   966: wide dstore #495
/*     */     //   970: iload #25
/*     */     //   972: bipush #8
/*     */     //   974: imul
/*     */     //   975: wide istore #493
/*     */     //   979: aload_1
/*     */     //   980: wide astore #491
/*     */     //   984: wide iload #493
/*     */     //   988: wide istore #492
/*     */     //   992: wide aload #491
/*     */     //   996: wide iload #492
/*     */     //   1000: invokeinterface getDouble : (I)D
/*     */     //   1005: wide dstore #489
/*     */     //   1009: wide dload #495
/*     */     //   1013: wide dload #489
/*     */     //   1017: dcmpl
/*     */     //   1018: ifne -> 1024
/*     */     //   1021: goto -> 1027
/*     */     //   1024: goto -> 1137
/*     */     //   1027: iload #29
/*     */     //   1029: iload #12
/*     */     //   1031: iadd
/*     */     //   1032: bipush #8
/*     */     //   1034: imul
/*     */     //   1035: wide istore #486
/*     */     //   1039: aload_1
/*     */     //   1040: wide astore #484
/*     */     //   1044: wide iload #486
/*     */     //   1048: wide istore #485
/*     */     //   1052: wide aload #484
/*     */     //   1056: wide iload #485
/*     */     //   1060: invokeinterface getDouble : (I)D
/*     */     //   1065: wide dstore #482
/*     */     //   1069: iload #25
/*     */     //   1071: iload #12
/*     */     //   1073: iadd
/*     */     //   1074: bipush #8
/*     */     //   1076: imul
/*     */     //   1077: wide istore #479
/*     */     //   1081: aload_1
/*     */     //   1082: wide astore #477
/*     */     //   1086: wide iload #479
/*     */     //   1090: wide istore #478
/*     */     //   1094: wide aload #477
/*     */     //   1098: wide iload #478
/*     */     //   1102: invokeinterface getDouble : (I)D
/*     */     //   1107: wide dstore #475
/*     */     //   1111: wide dload #482
/*     */     //   1115: wide dload #475
/*     */     //   1119: dcmpl
/*     */     //   1120: ifge -> 1126
/*     */     //   1123: goto -> 1129
/*     */     //   1126: goto -> 1137
/*     */     //   1129: iload #30
/*     */     //   1131: istore #16
/*     */     //   1133: iload #29
/*     */     //   1135: istore #25
/*     */     //   1137: iinc #30, 1
/*     */     //   1140: aload_2
/*     */     //   1141: invokeinterface getInt : ()I
/*     */     //   1146: iload #30
/*     */     //   1148: if_icmpge -> 895
/*     */     //   1151: goto -> 1154
/*     */     //   1154: aload #6
/*     */     //   1156: iconst_4
/*     */     //   1157: iload #23
/*     */     //   1159: invokeinterface setInt : (II)V
/*     */     //   1164: aload #6
/*     */     //   1166: bipush #8
/*     */     //   1168: iload #25
/*     */     //   1170: invokeinterface setInt : (II)V
/*     */     //   1175: aload #7
/*     */     //   1177: iconst_3
/*     */     //   1178: invokeinterface setInt : (I)V
/*     */     //   1183: iconst_1
/*     */     //   1184: istore #17
/*     */     //   1186: iconst_1
/*     */     //   1187: istore #18
/*     */     //   1189: aload_2
/*     */     //   1190: invokeinterface getInt : ()I
/*     */     //   1195: istore #27
/*     */     //   1197: iload #22
/*     */     //   1199: iconst_4
/*     */     //   1200: imul
/*     */     //   1201: wide istore #468
/*     */     //   1205: aload_3
/*     */     //   1206: wide astore #466
/*     */     //   1210: wide iload #468
/*     */     //   1214: wide istore #467
/*     */     //   1218: aload_2
/*     */     //   1219: invokeinterface getInt : ()I
/*     */     //   1224: iconst_4
/*     */     //   1225: imul
/*     */     //   1226: wide istore #463
/*     */     //   1230: aload_3
/*     */     //   1231: wide astore #461
/*     */     //   1235: wide iload #463
/*     */     //   1239: wide istore #462
/*     */     //   1243: wide aload #461
/*     */     //   1247: wide iload #462
/*     */     //   1251: invokeinterface getInt : (I)I
/*     */     //   1256: wide istore #460
/*     */     //   1260: wide aload #466
/*     */     //   1264: wide iload #467
/*     */     //   1268: wide iload #460
/*     */     //   1272: invokeinterface setInt : (II)V
/*     */     //   1277: aload_2
/*     */     //   1278: invokeinterface getInt : ()I
/*     */     //   1283: iconst_4
/*     */     //   1284: imul
/*     */     //   1285: wide istore #457
/*     */     //   1289: aload_3
/*     */     //   1290: wide astore #455
/*     */     //   1294: wide iload #457
/*     */     //   1298: wide istore #456
/*     */     //   1302: wide aload #455
/*     */     //   1306: wide iload #456
/*     */     //   1310: iload #23
/*     */     //   1312: invokeinterface setInt : (II)V
/*     */     //   1317: aload_2
/*     */     //   1318: invokeinterface getInt : ()I
/*     */     //   1323: bipush #-2
/*     */     //   1325: iadd
/*     */     //   1326: istore #24
/*     */     //   1328: aload_2
/*     */     //   1329: invokeinterface getInt : ()I
/*     */     //   1334: iload #16
/*     */     //   1336: if_icmpeq -> 1342
/*     */     //   1339: goto -> 1346
/*     */     //   1342: iload #22
/*     */     //   1344: istore #16
/*     */     //   1346: iload #16
/*     */     //   1348: iconst_4
/*     */     //   1349: imul
/*     */     //   1350: wide istore #451
/*     */     //   1354: aload_3
/*     */     //   1355: wide astore #449
/*     */     //   1359: wide iload #451
/*     */     //   1363: wide istore #450
/*     */     //   1367: aload_2
/*     */     //   1368: invokeinterface getInt : ()I
/*     */     //   1373: iconst_m1
/*     */     //   1374: iadd
/*     */     //   1375: iconst_4
/*     */     //   1376: imul
/*     */     //   1377: wide istore #445
/*     */     //   1381: aload_3
/*     */     //   1382: wide astore #443
/*     */     //   1386: wide iload #445
/*     */     //   1390: wide istore #444
/*     */     //   1394: wide aload #443
/*     */     //   1398: wide iload #444
/*     */     //   1402: invokeinterface getInt : (I)I
/*     */     //   1407: wide istore #442
/*     */     //   1411: wide aload #449
/*     */     //   1415: wide iload #450
/*     */     //   1419: wide iload #442
/*     */     //   1423: invokeinterface setInt : (II)V
/*     */     //   1428: aload_2
/*     */     //   1429: invokeinterface getInt : ()I
/*     */     //   1434: iconst_m1
/*     */     //   1435: iadd
/*     */     //   1436: iconst_4
/*     */     //   1437: imul
/*     */     //   1438: wide istore #438
/*     */     //   1442: aload_3
/*     */     //   1443: wide astore #436
/*     */     //   1447: wide iload #438
/*     */     //   1451: wide istore #437
/*     */     //   1455: wide aload #436
/*     */     //   1459: wide iload #437
/*     */     //   1463: iload #25
/*     */     //   1465: invokeinterface setInt : (II)V
/*     */     //   1470: iload #27
/*     */     //   1472: iconst_4
/*     */     //   1473: imul
/*     */     //   1474: wide istore #434
/*     */     //   1478: aload #4
/*     */     //   1480: wide astore #432
/*     */     //   1484: wide iload #434
/*     */     //   1488: wide istore #433
/*     */     //   1492: aload #5
/*     */     //   1494: wide astore #430
/*     */     //   1498: aload #4
/*     */     //   1500: wide astore #428
/*     */     //   1504: aload #6
/*     */     //   1506: bipush #8
/*     */     //   1508: invokeinterface getInt : (I)I
/*     */     //   1513: wide istore #425
/*     */     //   1517: aload #6
/*     */     //   1519: iconst_4
/*     */     //   1520: invokeinterface getInt : (I)I
/*     */     //   1525: wide istore #422
/*     */     //   1529: aload_3
/*     */     //   1530: wide astore #420
/*     */     //   1534: iload #11
/*     */     //   1536: bipush #8
/*     */     //   1538: imul
/*     */     //   1539: wide istore #418
/*     */     //   1543: aload_1
/*     */     //   1544: wide astore #416
/*     */     //   1548: wide iload #418
/*     */     //   1552: wide istore #417
/*     */     //   1556: aload_0
/*     */     //   1557: invokeinterface getInt : ()I
/*     */     //   1562: wide aload #416
/*     */     //   1566: wide iload #417
/*     */     //   1570: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   1575: iload #24
/*     */     //   1577: wide aload #420
/*     */     //   1581: iconst_4
/*     */     //   1582: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   1587: wide iload #422
/*     */     //   1591: wide iload #425
/*     */     //   1595: iconst_0
/*     */     //   1596: wide aload #428
/*     */     //   1600: iconst_4
/*     */     //   1601: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   1606: new org/renjin/gcc/runtime/IntPtr
/*     */     //   1609: dup
/*     */     //   1610: aload #26
/*     */     //   1612: iconst_0
/*     */     //   1613: invokespecial <init> : ([II)V
/*     */     //   1616: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   1619: new org/renjin/gcc/runtime/IntPtr
/*     */     //   1622: dup
/*     */     //   1623: aload #15
/*     */     //   1625: iconst_0
/*     */     //   1626: invokespecial <init> : ([II)V
/*     */     //   1629: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   1632: wide aload #430
/*     */     //   1636: iconst_4
/*     */     //   1637: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   1642: wide aload #432
/*     */     //   1646: wide iload #433
/*     */     //   1650: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   1655: new org/renjin/gcc/runtime/IntPtr
/*     */     //   1658: dup
/*     */     //   1659: aload #13
/*     */     //   1661: iconst_0
/*     */     //   1662: invokespecial <init> : ([II)V
/*     */     //   1665: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   1668: invokestatic split : (ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   1671: iload #27
/*     */     //   1673: iconst_4
/*     */     //   1674: imul
/*     */     //   1675: wide istore #413
/*     */     //   1679: aload #4
/*     */     //   1681: wide astore #411
/*     */     //   1685: wide iload #413
/*     */     //   1689: wide istore #412
/*     */     //   1693: wide aload #411
/*     */     //   1697: wide iload #412
/*     */     //   1701: invokeinterface getInt : (I)I
/*     */     //   1706: iload #18
/*     */     //   1708: iadd
/*     */     //   1709: istore #18
/*     */     //   1711: iload #27
/*     */     //   1713: iconst_1
/*     */     //   1714: isub
/*     */     //   1715: istore #27
/*     */     //   1717: aload #15
/*     */     //   1719: iconst_0
/*     */     //   1720: iaload
/*     */     //   1721: ifne -> 1727
/*     */     //   1724: goto -> 2456
/*     */     //   1727: aload #7
/*     */     //   1729: invokeinterface getInt : ()I
/*     */     //   1734: iconst_4
/*     */     //   1735: imul
/*     */     //   1736: wide istore #406
/*     */     //   1740: aload #8
/*     */     //   1742: wide astore #404
/*     */     //   1746: wide iload #406
/*     */     //   1750: wide istore #405
/*     */     //   1754: iload #17
/*     */     //   1756: iconst_4
/*     */     //   1757: imul
/*     */     //   1758: wide istore #402
/*     */     //   1762: aload #8
/*     */     //   1764: wide astore #400
/*     */     //   1768: wide iload #402
/*     */     //   1772: wide istore #401
/*     */     //   1776: wide aload #400
/*     */     //   1780: wide iload #401
/*     */     //   1784: invokeinterface getInt : (I)I
/*     */     //   1789: wide istore #399
/*     */     //   1793: wide aload #404
/*     */     //   1797: wide iload #405
/*     */     //   1801: wide iload #399
/*     */     //   1805: invokeinterface setInt : (II)V
/*     */     //   1810: iload #17
/*     */     //   1812: iconst_4
/*     */     //   1813: imul
/*     */     //   1814: wide istore #397
/*     */     //   1818: aload #8
/*     */     //   1820: wide astore #395
/*     */     //   1824: wide iload #397
/*     */     //   1828: wide istore #396
/*     */     //   1832: aload #7
/*     */     //   1834: invokeinterface getInt : ()I
/*     */     //   1839: wide istore #394
/*     */     //   1843: wide aload #395
/*     */     //   1847: wide iload #396
/*     */     //   1851: wide iload #394
/*     */     //   1855: invokeinterface setInt : (II)V
/*     */     //   1860: aload #7
/*     */     //   1862: invokeinterface getInt : ()I
/*     */     //   1867: iconst_4
/*     */     //   1868: imul
/*     */     //   1869: wide istore #391
/*     */     //   1873: aload #6
/*     */     //   1875: wide astore #389
/*     */     //   1879: wide iload #391
/*     */     //   1883: wide istore #390
/*     */     //   1887: aload #15
/*     */     //   1889: iconst_0
/*     */     //   1890: iaload
/*     */     //   1891: iconst_4
/*     */     //   1892: imul
/*     */     //   1893: wide istore #386
/*     */     //   1897: aload #4
/*     */     //   1899: wide astore #384
/*     */     //   1903: wide iload #386
/*     */     //   1907: wide istore #385
/*     */     //   1911: wide aload #384
/*     */     //   1915: wide iload #385
/*     */     //   1919: invokeinterface getInt : (I)I
/*     */     //   1924: wide istore #383
/*     */     //   1928: wide aload #389
/*     */     //   1932: wide iload #390
/*     */     //   1936: wide iload #383
/*     */     //   1940: invokeinterface setInt : (II)V
/*     */     //   1945: aload #15
/*     */     //   1947: iconst_0
/*     */     //   1948: iaload
/*     */     //   1949: iconst_4
/*     */     //   1950: imul
/*     */     //   1951: wide istore #380
/*     */     //   1955: aload #4
/*     */     //   1957: wide astore #378
/*     */     //   1961: wide iload #380
/*     */     //   1965: wide istore #379
/*     */     //   1969: aload #26
/*     */     //   1971: iconst_0
/*     */     //   1972: iaload
/*     */     //   1973: iconst_4
/*     */     //   1974: imul
/*     */     //   1975: wide istore #375
/*     */     //   1979: aload #4
/*     */     //   1981: wide astore #373
/*     */     //   1985: wide iload #375
/*     */     //   1989: wide istore #374
/*     */     //   1993: wide aload #373
/*     */     //   1997: wide iload #374
/*     */     //   2001: invokeinterface getInt : (I)I
/*     */     //   2006: wide istore #372
/*     */     //   2010: wide aload #378
/*     */     //   2014: wide iload #379
/*     */     //   2018: wide iload #372
/*     */     //   2022: invokeinterface setInt : (II)V
/*     */     //   2027: aload #26
/*     */     //   2029: iconst_0
/*     */     //   2030: iaload
/*     */     //   2031: iconst_1
/*     */     //   2032: isub
/*     */     //   2033: wide istore #370
/*     */     //   2037: aload #26
/*     */     //   2039: iconst_0
/*     */     //   2040: wide iload #370
/*     */     //   2044: iastore
/*     */     //   2045: aload #7
/*     */     //   2047: invokeinterface getInt : ()I
/*     */     //   2052: iconst_1
/*     */     //   2053: iadd
/*     */     //   2054: wide istore #368
/*     */     //   2058: aload #7
/*     */     //   2060: wide iload #368
/*     */     //   2064: invokeinterface setInt : (I)V
/*     */     //   2069: aload #26
/*     */     //   2071: iconst_0
/*     */     //   2072: iaload
/*     */     //   2073: ifne -> 2079
/*     */     //   2076: goto -> 2419
/*     */     //   2079: iload #17
/*     */     //   2081: iconst_4
/*     */     //   2082: imul
/*     */     //   2083: wide istore #365
/*     */     //   2087: aload #8
/*     */     //   2089: wide astore #363
/*     */     //   2093: wide iload #365
/*     */     //   2097: wide istore #364
/*     */     //   2101: wide aload #363
/*     */     //   2105: wide iload #364
/*     */     //   2109: invokeinterface getInt : (I)I
/*     */     //   2114: istore #28
/*     */     //   2116: iload #27
/*     */     //   2118: iconst_4
/*     */     //   2119: imul
/*     */     //   2120: wide istore #361
/*     */     //   2124: aload #4
/*     */     //   2126: wide astore #359
/*     */     //   2130: wide iload #361
/*     */     //   2134: wide istore #360
/*     */     //   2138: iload #18
/*     */     //   2140: iconst_4
/*     */     //   2141: imul
/*     */     //   2142: wide istore #357
/*     */     //   2146: aload #5
/*     */     //   2148: wide astore #355
/*     */     //   2152: wide iload #357
/*     */     //   2156: wide istore #356
/*     */     //   2160: aload #4
/*     */     //   2162: wide astore #353
/*     */     //   2166: iload #28
/*     */     //   2168: iconst_4
/*     */     //   2169: imul
/*     */     //   2170: wide istore #351
/*     */     //   2174: aload #6
/*     */     //   2176: wide astore #349
/*     */     //   2180: wide iload #351
/*     */     //   2184: wide istore #350
/*     */     //   2188: wide aload #349
/*     */     //   2192: wide iload #350
/*     */     //   2196: invokeinterface getInt : (I)I
/*     */     //   2201: wide istore #348
/*     */     //   2205: iload #17
/*     */     //   2207: iconst_4
/*     */     //   2208: imul
/*     */     //   2209: wide istore #346
/*     */     //   2213: aload #6
/*     */     //   2215: wide astore #344
/*     */     //   2219: wide iload #346
/*     */     //   2223: wide istore #345
/*     */     //   2227: wide aload #344
/*     */     //   2231: wide iload #345
/*     */     //   2235: invokeinterface getInt : (I)I
/*     */     //   2240: wide istore #343
/*     */     //   2244: aload #4
/*     */     //   2246: wide astore #341
/*     */     //   2250: aload #26
/*     */     //   2252: iconst_0
/*     */     //   2253: iaload
/*     */     //   2254: wide istore #340
/*     */     //   2258: iload #11
/*     */     //   2260: bipush #8
/*     */     //   2262: imul
/*     */     //   2263: wide istore #338
/*     */     //   2267: aload_1
/*     */     //   2268: wide astore #336
/*     */     //   2272: wide iload #338
/*     */     //   2276: wide istore #337
/*     */     //   2280: aload_0
/*     */     //   2281: invokeinterface getInt : ()I
/*     */     //   2286: wide aload #336
/*     */     //   2290: wide iload #337
/*     */     //   2294: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2299: wide iload #340
/*     */     //   2303: wide aload #341
/*     */     //   2307: iconst_4
/*     */     //   2308: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2313: wide iload #343
/*     */     //   2317: wide iload #348
/*     */     //   2321: iconst_1
/*     */     //   2322: wide aload #353
/*     */     //   2326: iconst_4
/*     */     //   2327: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2332: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2335: dup
/*     */     //   2336: aload #20
/*     */     //   2338: iconst_0
/*     */     //   2339: invokespecial <init> : ([II)V
/*     */     //   2342: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2345: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2348: dup
/*     */     //   2349: aload #15
/*     */     //   2351: iconst_0
/*     */     //   2352: invokespecial <init> : ([II)V
/*     */     //   2355: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2358: wide aload #355
/*     */     //   2362: wide iload #356
/*     */     //   2366: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2371: wide aload #359
/*     */     //   2375: wide iload #360
/*     */     //   2379: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2384: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2387: dup
/*     */     //   2388: aload #14
/*     */     //   2390: iconst_0
/*     */     //   2391: invokespecial <init> : ([II)V
/*     */     //   2394: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2397: invokestatic split : (ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   2400: aload #20
/*     */     //   2402: iconst_0
/*     */     //   2403: iaload
/*     */     //   2404: wide istore #334
/*     */     //   2408: aload #26
/*     */     //   2410: iconst_0
/*     */     //   2411: wide iload #334
/*     */     //   2415: iastore
/*     */     //   2416: goto -> 1671
/*     */     //   2419: iload #17
/*     */     //   2421: iconst_4
/*     */     //   2422: imul
/*     */     //   2423: wide istore #332
/*     */     //   2427: aload #8
/*     */     //   2429: wide astore #330
/*     */     //   2433: wide iload #332
/*     */     //   2437: wide istore #331
/*     */     //   2441: wide aload #330
/*     */     //   2445: wide iload #331
/*     */     //   2449: invokeinterface getInt : (I)I
/*     */     //   2454: istore #17
/*     */     //   2456: iload #17
/*     */     //   2458: iconst_4
/*     */     //   2459: imul
/*     */     //   2460: wide istore #328
/*     */     //   2464: aload #8
/*     */     //   2466: wide astore #326
/*     */     //   2470: wide iload #328
/*     */     //   2474: wide istore #327
/*     */     //   2478: wide aload #326
/*     */     //   2482: wide iload #327
/*     */     //   2486: invokeinterface getInt : (I)I
/*     */     //   2491: istore #17
/*     */     //   2493: iinc #27, 1
/*     */     //   2496: iload #27
/*     */     //   2498: iconst_4
/*     */     //   2499: imul
/*     */     //   2500: wide istore #324
/*     */     //   2504: aload #4
/*     */     //   2506: wide astore #322
/*     */     //   2510: wide iload #324
/*     */     //   2514: wide istore #323
/*     */     //   2518: wide aload #322
/*     */     //   2522: wide iload #323
/*     */     //   2526: invokeinterface getInt : (I)I
/*     */     //   2531: wide istore #321
/*     */     //   2535: iload #18
/*     */     //   2537: wide iload #321
/*     */     //   2541: isub
/*     */     //   2542: istore #18
/*     */     //   2544: aload_2
/*     */     //   2545: invokeinterface getInt : ()I
/*     */     //   2550: iload #27
/*     */     //   2552: if_icmple -> 2558
/*     */     //   2555: goto -> 2561
/*     */     //   2558: goto -> 3001
/*     */     //   2561: iload #27
/*     */     //   2563: iconst_4
/*     */     //   2564: imul
/*     */     //   2565: wide istore #318
/*     */     //   2569: aload #4
/*     */     //   2571: wide astore #316
/*     */     //   2575: wide iload #318
/*     */     //   2579: wide istore #317
/*     */     //   2583: wide aload #316
/*     */     //   2587: wide iload #317
/*     */     //   2591: invokeinterface getInt : (I)I
/*     */     //   2596: ifeq -> 2456
/*     */     //   2599: goto -> 2602
/*     */     //   2602: iload #17
/*     */     //   2604: iconst_4
/*     */     //   2605: imul
/*     */     //   2606: wide istore #313
/*     */     //   2610: aload #8
/*     */     //   2612: wide astore #311
/*     */     //   2616: wide iload #313
/*     */     //   2620: wide istore #312
/*     */     //   2624: wide aload #311
/*     */     //   2628: wide iload #312
/*     */     //   2632: invokeinterface getInt : (I)I
/*     */     //   2637: istore #28
/*     */     //   2639: iload #18
/*     */     //   2641: iconst_4
/*     */     //   2642: imul
/*     */     //   2643: wide istore #309
/*     */     //   2647: aload #5
/*     */     //   2649: wide astore #307
/*     */     //   2653: wide iload #309
/*     */     //   2657: wide istore #308
/*     */     //   2661: aload #4
/*     */     //   2663: wide astore #305
/*     */     //   2667: iload #28
/*     */     //   2669: iconst_4
/*     */     //   2670: imul
/*     */     //   2671: wide istore #303
/*     */     //   2675: aload #6
/*     */     //   2677: wide astore #301
/*     */     //   2681: wide iload #303
/*     */     //   2685: wide istore #302
/*     */     //   2689: wide aload #301
/*     */     //   2693: wide iload #302
/*     */     //   2697: invokeinterface getInt : (I)I
/*     */     //   2702: wide istore #300
/*     */     //   2706: iload #17
/*     */     //   2708: iconst_4
/*     */     //   2709: imul
/*     */     //   2710: wide istore #298
/*     */     //   2714: aload #6
/*     */     //   2716: wide astore #296
/*     */     //   2720: wide iload #298
/*     */     //   2724: wide istore #297
/*     */     //   2728: wide aload #296
/*     */     //   2732: wide iload #297
/*     */     //   2736: invokeinterface getInt : (I)I
/*     */     //   2741: wide istore #295
/*     */     //   2745: iload #18
/*     */     //   2747: iconst_4
/*     */     //   2748: imul
/*     */     //   2749: wide istore #293
/*     */     //   2753: aload #5
/*     */     //   2755: wide astore #291
/*     */     //   2759: wide iload #293
/*     */     //   2763: wide istore #292
/*     */     //   2767: iload #27
/*     */     //   2769: iconst_4
/*     */     //   2770: imul
/*     */     //   2771: wide istore #289
/*     */     //   2775: aload #4
/*     */     //   2777: wide astore #287
/*     */     //   2781: wide iload #289
/*     */     //   2785: wide istore #288
/*     */     //   2789: wide aload #287
/*     */     //   2793: wide iload #288
/*     */     //   2797: invokeinterface getInt : (I)I
/*     */     //   2802: wide istore #286
/*     */     //   2806: iload #11
/*     */     //   2808: bipush #8
/*     */     //   2810: imul
/*     */     //   2811: wide istore #284
/*     */     //   2815: aload_1
/*     */     //   2816: wide astore #282
/*     */     //   2820: wide iload #284
/*     */     //   2824: wide istore #283
/*     */     //   2828: aload_0
/*     */     //   2829: invokeinterface getInt : ()I
/*     */     //   2834: wide aload #282
/*     */     //   2838: wide iload #283
/*     */     //   2842: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2847: wide iload #286
/*     */     //   2851: wide aload #291
/*     */     //   2855: wide iload #292
/*     */     //   2859: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2864: wide iload #295
/*     */     //   2868: wide iload #300
/*     */     //   2872: iconst_2
/*     */     //   2873: wide aload #305
/*     */     //   2877: iconst_4
/*     */     //   2878: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2883: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2886: dup
/*     */     //   2887: aload #26
/*     */     //   2889: iconst_0
/*     */     //   2890: invokespecial <init> : ([II)V
/*     */     //   2893: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2896: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2899: dup
/*     */     //   2900: aload #15
/*     */     //   2902: iconst_0
/*     */     //   2903: invokespecial <init> : ([II)V
/*     */     //   2906: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2909: wide aload #307
/*     */     //   2913: wide iload #308
/*     */     //   2917: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   2922: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2925: dup
/*     */     //   2926: aload #20
/*     */     //   2928: iconst_0
/*     */     //   2929: invokespecial <init> : ([II)V
/*     */     //   2932: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2935: new org/renjin/gcc/runtime/IntPtr
/*     */     //   2938: dup
/*     */     //   2939: aload #14
/*     */     //   2941: iconst_0
/*     */     //   2942: invokespecial <init> : ([II)V
/*     */     //   2945: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   2948: invokestatic split : (ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   2951: iload #27
/*     */     //   2953: iconst_4
/*     */     //   2954: imul
/*     */     //   2955: wide istore #279
/*     */     //   2959: aload #4
/*     */     //   2961: wide astore #277
/*     */     //   2965: wide iload #279
/*     */     //   2969: wide istore #278
/*     */     //   2973: aload #20
/*     */     //   2975: iconst_0
/*     */     //   2976: iaload
/*     */     //   2977: wide istore #276
/*     */     //   2981: wide aload #277
/*     */     //   2985: wide iload #278
/*     */     //   2989: wide iload #276
/*     */     //   2993: invokeinterface setInt : (II)V
/*     */     //   2998: goto -> 1717
/*     */     //   3001: aload #13
/*     */     //   3003: iconst_0
/*     */     //   3004: iaload
/*     */     //   3005: wide istore #275
/*     */     //   3009: aload #14
/*     */     //   3011: iconst_0
/*     */     //   3012: wide iload #275
/*     */     //   3016: iastore
/*     */     //   3017: aload_2
/*     */     //   3018: invokeinterface getInt : ()I
/*     */     //   3023: istore #27
/*     */     //   3025: iload #27
/*     */     //   3027: iconst_4
/*     */     //   3028: imul
/*     */     //   3029: wide istore #273
/*     */     //   3033: aload #4
/*     */     //   3035: wide astore #271
/*     */     //   3039: wide iload #273
/*     */     //   3043: wide istore #272
/*     */     //   3047: wide aload #271
/*     */     //   3051: wide iload #272
/*     */     //   3055: invokeinterface getInt : (I)I
/*     */     //   3060: wide istore #270
/*     */     //   3064: aload #26
/*     */     //   3066: iconst_0
/*     */     //   3067: wide iload #270
/*     */     //   3071: iastore
/*     */     //   3072: iconst_1
/*     */     //   3073: istore #19
/*     */     //   3075: iload #27
/*     */     //   3077: iconst_4
/*     */     //   3078: imul
/*     */     //   3079: wide istore #268
/*     */     //   3083: aload #4
/*     */     //   3085: wide astore #266
/*     */     //   3089: wide iload #268
/*     */     //   3093: wide istore #267
/*     */     //   3097: wide aload #266
/*     */     //   3101: wide iload #267
/*     */     //   3105: iconst_0
/*     */     //   3106: invokeinterface setInt : (II)V
/*     */     //   3111: iload #27
/*     */     //   3113: iconst_4
/*     */     //   3114: imul
/*     */     //   3115: wide istore #264
/*     */     //   3119: aload #4
/*     */     //   3121: wide astore #262
/*     */     //   3125: wide iload #264
/*     */     //   3129: wide istore #263
/*     */     //   3133: wide aload #262
/*     */     //   3137: wide iload #263
/*     */     //   3141: invokeinterface getInt : (I)I
/*     */     //   3146: iload #19
/*     */     //   3148: iadd
/*     */     //   3149: istore #19
/*     */     //   3151: iload #27
/*     */     //   3153: iconst_1
/*     */     //   3154: isub
/*     */     //   3155: istore #27
/*     */     //   3157: aload #14
/*     */     //   3159: iconst_0
/*     */     //   3160: iaload
/*     */     //   3161: ifne -> 3167
/*     */     //   3164: goto -> 3710
/*     */     //   3167: aload #7
/*     */     //   3169: invokeinterface getInt : ()I
/*     */     //   3174: iconst_4
/*     */     //   3175: imul
/*     */     //   3176: wide istore #257
/*     */     //   3180: aload #8
/*     */     //   3182: astore #255
/*     */     //   3184: wide iload #257
/*     */     //   3188: wide istore #256
/*     */     //   3192: iload #17
/*     */     //   3194: iconst_4
/*     */     //   3195: imul
/*     */     //   3196: istore #253
/*     */     //   3198: aload #8
/*     */     //   3200: astore #251
/*     */     //   3202: iload #253
/*     */     //   3204: istore #252
/*     */     //   3206: aload #251
/*     */     //   3208: iload #252
/*     */     //   3210: invokeinterface getInt : (I)I
/*     */     //   3215: istore #250
/*     */     //   3217: aload #255
/*     */     //   3219: wide iload #256
/*     */     //   3223: iload #250
/*     */     //   3225: invokeinterface setInt : (II)V
/*     */     //   3230: iload #17
/*     */     //   3232: iconst_4
/*     */     //   3233: imul
/*     */     //   3234: istore #248
/*     */     //   3236: aload #8
/*     */     //   3238: astore #246
/*     */     //   3240: iload #248
/*     */     //   3242: istore #247
/*     */     //   3244: aload #7
/*     */     //   3246: invokeinterface getInt : ()I
/*     */     //   3251: istore #245
/*     */     //   3253: aload #246
/*     */     //   3255: iload #247
/*     */     //   3257: iload #245
/*     */     //   3259: invokeinterface setInt : (II)V
/*     */     //   3264: aload #7
/*     */     //   3266: invokeinterface getInt : ()I
/*     */     //   3271: iconst_4
/*     */     //   3272: imul
/*     */     //   3273: istore #242
/*     */     //   3275: aload #6
/*     */     //   3277: astore #240
/*     */     //   3279: iload #242
/*     */     //   3281: istore #241
/*     */     //   3283: aload #14
/*     */     //   3285: iconst_0
/*     */     //   3286: iaload
/*     */     //   3287: iconst_4
/*     */     //   3288: imul
/*     */     //   3289: istore #237
/*     */     //   3291: aload #5
/*     */     //   3293: astore #235
/*     */     //   3295: iload #237
/*     */     //   3297: istore #236
/*     */     //   3299: aload #235
/*     */     //   3301: iload #236
/*     */     //   3303: invokeinterface getInt : (I)I
/*     */     //   3308: istore #234
/*     */     //   3310: aload #240
/*     */     //   3312: iload #241
/*     */     //   3314: iload #234
/*     */     //   3316: invokeinterface setInt : (II)V
/*     */     //   3321: aload #14
/*     */     //   3323: iconst_0
/*     */     //   3324: iaload
/*     */     //   3325: iconst_4
/*     */     //   3326: imul
/*     */     //   3327: istore #231
/*     */     //   3329: aload #5
/*     */     //   3331: astore #229
/*     */     //   3333: iload #231
/*     */     //   3335: istore #230
/*     */     //   3337: aload #26
/*     */     //   3339: iconst_0
/*     */     //   3340: iaload
/*     */     //   3341: iconst_4
/*     */     //   3342: imul
/*     */     //   3343: istore #226
/*     */     //   3345: aload #5
/*     */     //   3347: astore #224
/*     */     //   3349: iload #226
/*     */     //   3351: istore #225
/*     */     //   3353: aload #224
/*     */     //   3355: iload #225
/*     */     //   3357: invokeinterface getInt : (I)I
/*     */     //   3362: istore #223
/*     */     //   3364: aload #229
/*     */     //   3366: iload #230
/*     */     //   3368: iload #223
/*     */     //   3370: invokeinterface setInt : (II)V
/*     */     //   3375: aload #26
/*     */     //   3377: iconst_0
/*     */     //   3378: iaload
/*     */     //   3379: iconst_1
/*     */     //   3380: isub
/*     */     //   3381: istore #221
/*     */     //   3383: aload #26
/*     */     //   3385: iconst_0
/*     */     //   3386: iload #221
/*     */     //   3388: iastore
/*     */     //   3389: aload #7
/*     */     //   3391: invokeinterface getInt : ()I
/*     */     //   3396: iconst_1
/*     */     //   3397: iadd
/*     */     //   3398: istore #219
/*     */     //   3400: aload #7
/*     */     //   3402: iload #219
/*     */     //   3404: invokeinterface setInt : (I)V
/*     */     //   3409: aload #26
/*     */     //   3411: iconst_0
/*     */     //   3412: iaload
/*     */     //   3413: ifne -> 3419
/*     */     //   3416: goto -> 3685
/*     */     //   3419: iload #17
/*     */     //   3421: iconst_4
/*     */     //   3422: imul
/*     */     //   3423: istore #216
/*     */     //   3425: aload #8
/*     */     //   3427: astore #214
/*     */     //   3429: iload #216
/*     */     //   3431: istore #215
/*     */     //   3433: aload #214
/*     */     //   3435: iload #215
/*     */     //   3437: invokeinterface getInt : (I)I
/*     */     //   3442: istore #28
/*     */     //   3444: iload #18
/*     */     //   3446: iconst_4
/*     */     //   3447: imul
/*     */     //   3448: istore #212
/*     */     //   3450: aload #5
/*     */     //   3452: astore #210
/*     */     //   3454: iload #212
/*     */     //   3456: istore #211
/*     */     //   3458: iload #27
/*     */     //   3460: iconst_4
/*     */     //   3461: imul
/*     */     //   3462: istore #208
/*     */     //   3464: aload #4
/*     */     //   3466: astore #206
/*     */     //   3468: iload #208
/*     */     //   3470: istore #207
/*     */     //   3472: iload #19
/*     */     //   3474: iconst_4
/*     */     //   3475: imul
/*     */     //   3476: istore #204
/*     */     //   3478: aload #4
/*     */     //   3480: astore #202
/*     */     //   3482: iload #204
/*     */     //   3484: istore #203
/*     */     //   3486: iload #28
/*     */     //   3488: iconst_4
/*     */     //   3489: imul
/*     */     //   3490: istore #200
/*     */     //   3492: aload #6
/*     */     //   3494: astore #198
/*     */     //   3496: iload #200
/*     */     //   3498: istore #199
/*     */     //   3500: aload #198
/*     */     //   3502: iload #199
/*     */     //   3504: invokeinterface getInt : (I)I
/*     */     //   3509: istore #197
/*     */     //   3511: iload #17
/*     */     //   3513: iconst_4
/*     */     //   3514: imul
/*     */     //   3515: istore #195
/*     */     //   3517: aload #6
/*     */     //   3519: astore #193
/*     */     //   3521: iload #195
/*     */     //   3523: istore #194
/*     */     //   3525: aload #193
/*     */     //   3527: iload #194
/*     */     //   3529: invokeinterface getInt : (I)I
/*     */     //   3534: istore #192
/*     */     //   3536: iload #18
/*     */     //   3538: iconst_4
/*     */     //   3539: imul
/*     */     //   3540: istore #190
/*     */     //   3542: aload #5
/*     */     //   3544: astore #188
/*     */     //   3546: iload #190
/*     */     //   3548: istore #189
/*     */     //   3550: aload #26
/*     */     //   3552: iconst_0
/*     */     //   3553: iaload
/*     */     //   3554: istore #187
/*     */     //   3556: iload #11
/*     */     //   3558: bipush #8
/*     */     //   3560: imul
/*     */     //   3561: istore #185
/*     */     //   3563: aload_1
/*     */     //   3564: astore #183
/*     */     //   3566: iload #185
/*     */     //   3568: istore #184
/*     */     //   3570: aload_0
/*     */     //   3571: invokeinterface getInt : ()I
/*     */     //   3576: aload #183
/*     */     //   3578: iload #184
/*     */     //   3580: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3585: iload #187
/*     */     //   3587: aload #188
/*     */     //   3589: iload #189
/*     */     //   3591: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3596: iload #192
/*     */     //   3598: iload #197
/*     */     //   3600: iconst_m1
/*     */     //   3601: aload #202
/*     */     //   3603: iload #203
/*     */     //   3605: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3610: aload #206
/*     */     //   3612: iload #207
/*     */     //   3614: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3619: new org/renjin/gcc/runtime/IntPtr
/*     */     //   3622: dup
/*     */     //   3623: aload #15
/*     */     //   3625: iconst_0
/*     */     //   3626: invokespecial <init> : ([II)V
/*     */     //   3629: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   3632: aload #210
/*     */     //   3634: iload #211
/*     */     //   3636: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3641: new org/renjin/gcc/runtime/IntPtr
/*     */     //   3644: dup
/*     */     //   3645: aload #20
/*     */     //   3647: iconst_0
/*     */     //   3648: invokespecial <init> : ([II)V
/*     */     //   3651: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   3654: new org/renjin/gcc/runtime/IntPtr
/*     */     //   3657: dup
/*     */     //   3658: aload #14
/*     */     //   3660: iconst_0
/*     */     //   3661: invokespecial <init> : ([II)V
/*     */     //   3664: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   3667: invokestatic split : (ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   3670: aload #20
/*     */     //   3672: iconst_0
/*     */     //   3673: iaload
/*     */     //   3674: istore #181
/*     */     //   3676: aload #26
/*     */     //   3678: iconst_0
/*     */     //   3679: iload #181
/*     */     //   3681: iastore
/*     */     //   3682: goto -> 3111
/*     */     //   3685: iload #17
/*     */     //   3687: iconst_4
/*     */     //   3688: imul
/*     */     //   3689: istore #179
/*     */     //   3691: aload #8
/*     */     //   3693: astore #177
/*     */     //   3695: iload #179
/*     */     //   3697: istore #178
/*     */     //   3699: aload #177
/*     */     //   3701: iload #178
/*     */     //   3703: invokeinterface getInt : (I)I
/*     */     //   3708: istore #17
/*     */     //   3710: iload #17
/*     */     //   3712: iconst_4
/*     */     //   3713: imul
/*     */     //   3714: istore #175
/*     */     //   3716: aload #8
/*     */     //   3718: astore #173
/*     */     //   3720: iload #175
/*     */     //   3722: istore #174
/*     */     //   3724: aload #173
/*     */     //   3726: iload #174
/*     */     //   3728: invokeinterface getInt : (I)I
/*     */     //   3733: istore #17
/*     */     //   3735: iinc #27, 1
/*     */     //   3738: iload #27
/*     */     //   3740: iconst_4
/*     */     //   3741: imul
/*     */     //   3742: istore #171
/*     */     //   3744: aload #4
/*     */     //   3746: astore #169
/*     */     //   3748: iload #171
/*     */     //   3750: istore #170
/*     */     //   3752: aload #169
/*     */     //   3754: iload #170
/*     */     //   3756: invokeinterface getInt : (I)I
/*     */     //   3761: istore #168
/*     */     //   3763: iload #19
/*     */     //   3765: iload #168
/*     */     //   3767: isub
/*     */     //   3768: istore #19
/*     */     //   3770: iload #27
/*     */     //   3772: iload #21
/*     */     //   3774: if_icmpeq -> 3780
/*     */     //   3777: goto -> 3783
/*     */     //   3780: goto -> 4515
/*     */     //   3783: iload #27
/*     */     //   3785: iconst_4
/*     */     //   3786: imul
/*     */     //   3787: istore #166
/*     */     //   3789: aload #4
/*     */     //   3791: astore #164
/*     */     //   3793: iload #166
/*     */     //   3795: istore #165
/*     */     //   3797: aload #164
/*     */     //   3799: iload #165
/*     */     //   3801: invokeinterface getInt : (I)I
/*     */     //   3806: ifeq -> 3710
/*     */     //   3809: goto -> 3812
/*     */     //   3812: iload #17
/*     */     //   3814: iconst_4
/*     */     //   3815: imul
/*     */     //   3816: istore #161
/*     */     //   3818: aload #8
/*     */     //   3820: astore #159
/*     */     //   3822: iload #161
/*     */     //   3824: istore #160
/*     */     //   3826: aload #159
/*     */     //   3828: iload #160
/*     */     //   3830: invokeinterface getInt : (I)I
/*     */     //   3835: istore #28
/*     */     //   3837: iload #18
/*     */     //   3839: iconst_4
/*     */     //   3840: imul
/*     */     //   3841: istore #157
/*     */     //   3843: aload #5
/*     */     //   3845: astore #155
/*     */     //   3847: iload #157
/*     */     //   3849: istore #156
/*     */     //   3851: iload #19
/*     */     //   3853: iconst_4
/*     */     //   3854: imul
/*     */     //   3855: istore #153
/*     */     //   3857: aload #4
/*     */     //   3859: astore #151
/*     */     //   3861: iload #153
/*     */     //   3863: istore #152
/*     */     //   3865: iload #28
/*     */     //   3867: iconst_4
/*     */     //   3868: imul
/*     */     //   3869: istore #149
/*     */     //   3871: aload #6
/*     */     //   3873: astore #147
/*     */     //   3875: iload #149
/*     */     //   3877: istore #148
/*     */     //   3879: aload #147
/*     */     //   3881: iload #148
/*     */     //   3883: invokeinterface getInt : (I)I
/*     */     //   3888: istore #146
/*     */     //   3890: iload #17
/*     */     //   3892: iconst_4
/*     */     //   3893: imul
/*     */     //   3894: istore #144
/*     */     //   3896: aload #6
/*     */     //   3898: astore #142
/*     */     //   3900: iload #144
/*     */     //   3902: istore #143
/*     */     //   3904: aload #142
/*     */     //   3906: iload #143
/*     */     //   3908: invokeinterface getInt : (I)I
/*     */     //   3913: istore #141
/*     */     //   3915: iload #19
/*     */     //   3917: iconst_4
/*     */     //   3918: imul
/*     */     //   3919: istore #139
/*     */     //   3921: aload #4
/*     */     //   3923: astore #137
/*     */     //   3925: iload #139
/*     */     //   3927: istore #138
/*     */     //   3929: iload #27
/*     */     //   3931: iconst_4
/*     */     //   3932: imul
/*     */     //   3933: istore #135
/*     */     //   3935: aload #4
/*     */     //   3937: astore #133
/*     */     //   3939: iload #135
/*     */     //   3941: istore #134
/*     */     //   3943: aload #133
/*     */     //   3945: iload #134
/*     */     //   3947: invokeinterface getInt : (I)I
/*     */     //   3952: istore #132
/*     */     //   3954: iload #11
/*     */     //   3956: bipush #8
/*     */     //   3958: imul
/*     */     //   3959: istore #130
/*     */     //   3961: aload_1
/*     */     //   3962: astore #128
/*     */     //   3964: iload #130
/*     */     //   3966: istore #129
/*     */     //   3968: aload_0
/*     */     //   3969: invokeinterface getInt : ()I
/*     */     //   3974: aload #128
/*     */     //   3976: iload #129
/*     */     //   3978: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3983: iload #132
/*     */     //   3985: aload #137
/*     */     //   3987: iload #138
/*     */     //   3989: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   3994: iload #141
/*     */     //   3996: iload #146
/*     */     //   3998: bipush #-2
/*     */     //   4000: aload #151
/*     */     //   4002: iload #152
/*     */     //   4004: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   4009: new org/renjin/gcc/runtime/IntPtr
/*     */     //   4012: dup
/*     */     //   4013: aload #20
/*     */     //   4015: iconst_0
/*     */     //   4016: invokespecial <init> : ([II)V
/*     */     //   4019: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   4022: new org/renjin/gcc/runtime/IntPtr
/*     */     //   4025: dup
/*     */     //   4026: aload #15
/*     */     //   4028: iconst_0
/*     */     //   4029: invokespecial <init> : ([II)V
/*     */     //   4032: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   4035: aload #155
/*     */     //   4037: iload #156
/*     */     //   4039: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   4044: new org/renjin/gcc/runtime/IntPtr
/*     */     //   4047: dup
/*     */     //   4048: aload #26
/*     */     //   4050: iconst_0
/*     */     //   4051: invokespecial <init> : ([II)V
/*     */     //   4054: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   4057: new org/renjin/gcc/runtime/IntPtr
/*     */     //   4060: dup
/*     */     //   4061: aload #14
/*     */     //   4063: iconst_0
/*     */     //   4064: invokespecial <init> : ([II)V
/*     */     //   4067: checkcast org/renjin/gcc/runtime/Ptr
/*     */     //   4070: invokestatic split : (ILorg/renjin/gcc/runtime/Ptr;ILorg/renjin/gcc/runtime/Ptr;IIILorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   4073: goto -> 3157
/*     */     //   4076: aload_3
/*     */     //   4077: iconst_1
/*     */     //   4078: invokeinterface getAlignedInt : (I)I
/*     */     //   4083: istore #23
/*     */     //   4085: aload_3
/*     */     //   4086: iconst_1
/*     */     //   4087: invokeinterface getAlignedInt : (I)I
/*     */     //   4092: istore #25
/*     */     //   4094: iconst_1
/*     */     //   4095: istore #30
/*     */     //   4097: goto -> 4277
/*     */     //   4100: iload #30
/*     */     //   4102: iconst_4
/*     */     //   4103: imul
/*     */     //   4104: istore #125
/*     */     //   4106: aload_3
/*     */     //   4107: astore #123
/*     */     //   4109: iload #125
/*     */     //   4111: istore #124
/*     */     //   4113: aload #123
/*     */     //   4115: iload #124
/*     */     //   4117: invokeinterface getInt : (I)I
/*     */     //   4122: istore #29
/*     */     //   4124: iload #29
/*     */     //   4126: iload #12
/*     */     //   4128: iadd
/*     */     //   4129: bipush #8
/*     */     //   4131: imul
/*     */     //   4132: istore #120
/*     */     //   4134: aload_1
/*     */     //   4135: astore #118
/*     */     //   4137: iload #120
/*     */     //   4139: istore #119
/*     */     //   4141: aload #118
/*     */     //   4143: iload #119
/*     */     //   4145: invokeinterface getDouble : (I)D
/*     */     //   4150: dstore #116
/*     */     //   4152: iload #23
/*     */     //   4154: iload #12
/*     */     //   4156: iadd
/*     */     //   4157: bipush #8
/*     */     //   4159: imul
/*     */     //   4160: istore #113
/*     */     //   4162: aload_1
/*     */     //   4163: astore #111
/*     */     //   4165: iload #113
/*     */     //   4167: istore #112
/*     */     //   4169: aload #111
/*     */     //   4171: iload #112
/*     */     //   4173: invokeinterface getDouble : (I)D
/*     */     //   4178: dstore #109
/*     */     //   4180: dload #116
/*     */     //   4182: dload #109
/*     */     //   4184: dcmpl
/*     */     //   4185: ifgt -> 4191
/*     */     //   4188: goto -> 4199
/*     */     //   4191: iload #30
/*     */     //   4193: istore #22
/*     */     //   4195: iload #29
/*     */     //   4197: istore #23
/*     */     //   4199: iload #29
/*     */     //   4201: iload #12
/*     */     //   4203: iadd
/*     */     //   4204: bipush #8
/*     */     //   4206: imul
/*     */     //   4207: istore #106
/*     */     //   4209: aload_1
/*     */     //   4210: astore #104
/*     */     //   4212: iload #106
/*     */     //   4214: istore #105
/*     */     //   4216: aload #104
/*     */     //   4218: iload #105
/*     */     //   4220: invokeinterface getDouble : (I)D
/*     */     //   4225: dstore #102
/*     */     //   4227: iload #25
/*     */     //   4229: iload #12
/*     */     //   4231: iadd
/*     */     //   4232: bipush #8
/*     */     //   4234: imul
/*     */     //   4235: istore #99
/*     */     //   4237: aload_1
/*     */     //   4238: astore #97
/*     */     //   4240: iload #99
/*     */     //   4242: istore #98
/*     */     //   4244: aload #97
/*     */     //   4246: iload #98
/*     */     //   4248: invokeinterface getDouble : (I)D
/*     */     //   4253: dstore #95
/*     */     //   4255: dload #102
/*     */     //   4257: dload #95
/*     */     //   4259: dcmpg
/*     */     //   4260: iflt -> 4266
/*     */     //   4263: goto -> 4274
/*     */     //   4266: iload #30
/*     */     //   4268: istore #16
/*     */     //   4270: iload #29
/*     */     //   4272: istore #25
/*     */     //   4274: iinc #30, 1
/*     */     //   4277: aload_2
/*     */     //   4278: invokeinterface getInt : ()I
/*     */     //   4283: iload #30
/*     */     //   4285: if_icmpge -> 4100
/*     */     //   4288: goto -> 4291
/*     */     //   4291: iload #23
/*     */     //   4293: iload #25
/*     */     //   4295: if_icmpeq -> 4301
/*     */     //   4298: goto -> 4304
/*     */     //   4301: goto -> 4475
/*     */     //   4304: aload #6
/*     */     //   4306: iconst_4
/*     */     //   4307: iload #23
/*     */     //   4309: invokeinterface setInt : (II)V
/*     */     //   4314: aload #6
/*     */     //   4316: bipush #8
/*     */     //   4318: iload #25
/*     */     //   4320: invokeinterface setInt : (II)V
/*     */     //   4325: iload #25
/*     */     //   4327: bipush #8
/*     */     //   4329: imul
/*     */     //   4330: istore #88
/*     */     //   4332: aload_1
/*     */     //   4333: astore #86
/*     */     //   4335: iload #88
/*     */     //   4337: istore #87
/*     */     //   4339: aload #86
/*     */     //   4341: iload #87
/*     */     //   4343: invokeinterface getDouble : (I)D
/*     */     //   4348: dstore #84
/*     */     //   4350: iload #23
/*     */     //   4352: bipush #8
/*     */     //   4354: imul
/*     */     //   4355: istore #82
/*     */     //   4357: aload_1
/*     */     //   4358: astore #80
/*     */     //   4360: iload #82
/*     */     //   4362: istore #81
/*     */     //   4364: aload #80
/*     */     //   4366: iload #81
/*     */     //   4368: invokeinterface getDouble : (I)D
/*     */     //   4373: dstore #78
/*     */     //   4375: dload #84
/*     */     //   4377: dload #78
/*     */     //   4379: dcmpl
/*     */     //   4380: ifeq -> 4386
/*     */     //   4383: goto -> 4464
/*     */     //   4386: iload #25
/*     */     //   4388: iload #12
/*     */     //   4390: iadd
/*     */     //   4391: bipush #8
/*     */     //   4393: imul
/*     */     //   4394: istore #75
/*     */     //   4396: aload_1
/*     */     //   4397: astore #73
/*     */     //   4399: iload #75
/*     */     //   4401: istore #74
/*     */     //   4403: aload #73
/*     */     //   4405: iload #74
/*     */     //   4407: invokeinterface getDouble : (I)D
/*     */     //   4412: dstore #71
/*     */     //   4414: iload #23
/*     */     //   4416: iload #12
/*     */     //   4418: iadd
/*     */     //   4419: bipush #8
/*     */     //   4421: imul
/*     */     //   4422: istore #68
/*     */     //   4424: aload_1
/*     */     //   4425: astore #66
/*     */     //   4427: iload #68
/*     */     //   4429: istore #67
/*     */     //   4431: aload #66
/*     */     //   4433: iload #67
/*     */     //   4435: invokeinterface getDouble : (I)D
/*     */     //   4440: dstore #64
/*     */     //   4442: dload #71
/*     */     //   4444: dload #64
/*     */     //   4446: dcmpl
/*     */     //   4447: ifeq -> 4453
/*     */     //   4450: goto -> 4464
/*     */     //   4453: aload #7
/*     */     //   4455: iconst_2
/*     */     //   4456: invokeinterface setInt : (I)V
/*     */     //   4461: goto -> 4472
/*     */     //   4464: aload #7
/*     */     //   4466: iconst_3
/*     */     //   4467: invokeinterface setInt : (I)V
/*     */     //   4472: goto -> 4515
/*     */     //   4475: aload #7
/*     */     //   4477: iconst_2
/*     */     //   4478: invokeinterface setInt : (I)V
/*     */     //   4483: aload #6
/*     */     //   4485: astore #62
/*     */     //   4487: aload_3
/*     */     //   4488: iconst_1
/*     */     //   4489: invokeinterface getAlignedInt : (I)I
/*     */     //   4494: istore #61
/*     */     //   4496: aload #62
/*     */     //   4498: iconst_4
/*     */     //   4499: iload #61
/*     */     //   4501: invokeinterface setInt : (II)V
/*     */     //   4506: aload #8
/*     */     //   4508: iconst_4
/*     */     //   4509: iconst_1
/*     */     //   4510: invokeinterface setInt : (II)V
/*     */     //   4515: aload #7
/*     */     //   4517: invokeinterface getInt : ()I
/*     */     //   4522: iconst_1
/*     */     //   4523: isub
/*     */     //   4524: istore #57
/*     */     //   4526: aload #7
/*     */     //   4528: iload #57
/*     */     //   4530: invokeinterface setInt : (I)V
/*     */     //   4535: iconst_1
/*     */     //   4536: istore #30
/*     */     //   4538: goto -> 4594
/*     */     //   4541: iload #30
/*     */     //   4543: iconst_4
/*     */     //   4544: imul
/*     */     //   4545: istore #55
/*     */     //   4547: aload #4
/*     */     //   4549: astore #53
/*     */     //   4551: iload #55
/*     */     //   4553: istore #54
/*     */     //   4555: iload #30
/*     */     //   4557: iconst_4
/*     */     //   4558: imul
/*     */     //   4559: istore #51
/*     */     //   4561: aload #6
/*     */     //   4563: astore #49
/*     */     //   4565: iload #51
/*     */     //   4567: istore #50
/*     */     //   4569: aload #49
/*     */     //   4571: iload #50
/*     */     //   4573: invokeinterface getInt : (I)I
/*     */     //   4578: istore #48
/*     */     //   4580: aload #53
/*     */     //   4582: iload #54
/*     */     //   4584: iload #48
/*     */     //   4586: invokeinterface setInt : (II)V
/*     */     //   4591: iinc #30, 1
/*     */     //   4594: aload #7
/*     */     //   4596: invokeinterface getInt : ()I
/*     */     //   4601: iload #30
/*     */     //   4603: if_icmpge -> 4541
/*     */     //   4606: goto -> 4609
/*     */     //   4609: aload #8
/*     */     //   4611: iconst_1
/*     */     //   4612: invokeinterface getAlignedInt : (I)I
/*     */     //   4617: istore #29
/*     */     //   4619: iconst_2
/*     */     //   4620: istore #30
/*     */     //   4622: goto -> 4703
/*     */     //   4625: iload #30
/*     */     //   4627: iconst_4
/*     */     //   4628: imul
/*     */     //   4629: istore #45
/*     */     //   4631: aload #6
/*     */     //   4633: astore #43
/*     */     //   4635: iload #45
/*     */     //   4637: istore #44
/*     */     //   4639: iload #29
/*     */     //   4641: iconst_4
/*     */     //   4642: imul
/*     */     //   4643: istore #41
/*     */     //   4645: aload #4
/*     */     //   4647: astore #39
/*     */     //   4649: iload #41
/*     */     //   4651: istore #40
/*     */     //   4653: aload #39
/*     */     //   4655: iload #40
/*     */     //   4657: invokeinterface getInt : (I)I
/*     */     //   4662: istore #38
/*     */     //   4664: aload #43
/*     */     //   4666: iload #44
/*     */     //   4668: iload #38
/*     */     //   4670: invokeinterface setInt : (II)V
/*     */     //   4675: iload #29
/*     */     //   4677: iconst_4
/*     */     //   4678: imul
/*     */     //   4679: istore #36
/*     */     //   4681: aload #8
/*     */     //   4683: astore #34
/*     */     //   4685: iload #36
/*     */     //   4687: istore #35
/*     */     //   4689: aload #34
/*     */     //   4691: iload #35
/*     */     //   4693: invokeinterface getInt : (I)I
/*     */     //   4698: istore #29
/*     */     //   4700: iinc #30, 1
/*     */     //   4703: aload #7
/*     */     //   4705: invokeinterface getInt : ()I
/*     */     //   4710: iload #30
/*     */     //   4712: if_icmpge -> 4625
/*     */     //   4715: goto -> 4718
/*     */     //   4718: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #179	-> 83
/*     */     //   #180	-> 91
/*     */     //   #181	-> 94
/*     */     //   #182	-> 115
/*     */     //   #183	-> 126
/*     */     //   #184	-> 137
/*     */     //   #185	-> 148
/*     */     //   #186	-> 159
/*     */     //   #188	-> 168
/*     */     //   #191	-> 184
/*     */     //   #192	-> 193
/*     */     //   #193	-> 203
/*     */     //   #194	-> 212
/*     */     //   #195	-> 221
/*     */     //   #198	-> 237
/*     */     //   #199	-> 247
/*     */     //   #200	-> 250
/*     */     //   #201	-> 253
/*     */     //   #202	-> 262
/*     */     //   #203	-> 265
/*     */     //   #205	-> 268
/*     */     //   #206	-> 274
/*     */     //   #207	-> 310
/*     */     //   #208	-> 409
/*     */     //   #209	-> 419
/*     */     //   #211	-> 425
/*     */     //   #212	-> 428
/*     */     //   #213	-> 432
/*     */     //   #215	-> 436
/*     */     //   #216	-> 535
/*     */     //   #217	-> 538
/*     */     //   #218	-> 542
/*     */     //   #219	-> 549
/*     */     //   #220	-> 559
/*     */     //   #205	-> 562
/*     */     //   #205	-> 565
/*     */     //   #224	-> 579
/*     */     //   #229	-> 592
/*     */     //   #229	-> 600
/*     */     //   #232	-> 608
/*     */     //   #233	-> 616
/*     */     //   #234	-> 622
/*     */     //   #235	-> 658
/*     */     //   #236	-> 754
/*     */     //   #237	-> 856
/*     */     //   #238	-> 860
/*     */     //   #233	-> 864
/*     */     //   #233	-> 867
/*     */     //   #242	-> 881
/*     */     //   #243	-> 889
/*     */     //   #244	-> 895
/*     */     //   #245	-> 931
/*     */     //   #246	-> 1027
/*     */     //   #247	-> 1129
/*     */     //   #248	-> 1133
/*     */     //   #243	-> 1137
/*     */     //   #243	-> 1140
/*     */     //   #255	-> 1154
/*     */     //   #256	-> 1164
/*     */     //   #257	-> 1175
/*     */     //   #258	-> 1183
/*     */     //   #259	-> 1186
/*     */     //   #260	-> 1189
/*     */     //   #261	-> 1197
/*     */     //   #262	-> 1277
/*     */     //   #263	-> 1317
/*     */     //   #264	-> 1328
/*     */     //   #265	-> 1342
/*     */     //   #267	-> 1346
/*     */     //   #268	-> 1428
/*     */     //   #270	-> 1470
/*     */     //   #274	-> 1472
/*     */     //   #270	-> 1478
/*     */     //   #271	-> 1504
/*     */     //   #270	-> 1506
/*     */     //   #271	-> 1517
/*     */     //   #270	-> 1519
/*     */     //   #280	-> 1671
/*     */     //   #281	-> 1711
/*     */     //   #283	-> 1717
/*     */     //   #284	-> 1727
/*     */     //   #285	-> 1810
/*     */     //   #286	-> 1860
/*     */     //   #287	-> 1945
/*     */     //   #288	-> 2027
/*     */     //   #289	-> 2045
/*     */     //   #290	-> 2069
/*     */     //   #291	-> 2079
/*     */     //   #292	-> 2116
/*     */     //   #296	-> 2118
/*     */     //   #292	-> 2124
/*     */     //   #296	-> 2140
/*     */     //   #292	-> 2146
/*     */     //   #293	-> 2166
/*     */     //   #292	-> 2188
/*     */     //   #293	-> 2205
/*     */     //   #292	-> 2227
/*     */     //   #297	-> 2400
/*     */     //   #301	-> 2419
/*     */     //   #305	-> 2456
/*     */     //   #306	-> 2493
/*     */     //   #307	-> 2496
/*     */     //   #308	-> 2544
/*     */     //   #309	-> 2561
/*     */     //   #310	-> 2602
/*     */     //   #315	-> 2639
/*     */     //   #319	-> 2641
/*     */     //   #315	-> 2647
/*     */     //   #316	-> 2667
/*     */     //   #315	-> 2689
/*     */     //   #316	-> 2706
/*     */     //   #315	-> 2728
/*     */     //   #320	-> 2951
/*     */     //   #325	-> 3001
/*     */     //   #326	-> 3017
/*     */     //   #327	-> 3025
/*     */     //   #328	-> 3072
/*     */     //   #329	-> 3075
/*     */     //   #332	-> 3111
/*     */     //   #333	-> 3151
/*     */     //   #336	-> 3157
/*     */     //   #337	-> 3167
/*     */     //   #338	-> 3230
/*     */     //   #339	-> 3264
/*     */     //   #340	-> 3321
/*     */     //   #341	-> 3375
/*     */     //   #342	-> 3389
/*     */     //   #343	-> 3409
/*     */     //   #344	-> 3419
/*     */     //   #345	-> 3444
/*     */     //   #349	-> 3446
/*     */     //   #345	-> 3450
/*     */     //   #348	-> 3460
/*     */     //   #345	-> 3464
/*     */     //   #348	-> 3474
/*     */     //   #345	-> 3478
/*     */     //   #346	-> 3486
/*     */     //   #345	-> 3500
/*     */     //   #346	-> 3511
/*     */     //   #345	-> 3525
/*     */     //   #350	-> 3670
/*     */     //   #355	-> 3685
/*     */     //   #359	-> 3710
/*     */     //   #360	-> 3735
/*     */     //   #361	-> 3738
/*     */     //   #362	-> 3770
/*     */     //   #363	-> 3783
/*     */     //   #364	-> 3812
/*     */     //   #369	-> 3837
/*     */     //   #373	-> 3839
/*     */     //   #369	-> 3843
/*     */     //   #372	-> 3853
/*     */     //   #369	-> 3857
/*     */     //   #370	-> 3865
/*     */     //   #369	-> 3879
/*     */     //   #370	-> 3890
/*     */     //   #369	-> 3904
/*     */     //   #380	-> 4076
/*     */     //   #381	-> 4085
/*     */     //   #382	-> 4094
/*     */     //   #383	-> 4100
/*     */     //   #384	-> 4124
/*     */     //   #385	-> 4191
/*     */     //   #386	-> 4195
/*     */     //   #388	-> 4199
/*     */     //   #389	-> 4266
/*     */     //   #390	-> 4270
/*     */     //   #382	-> 4274
/*     */     //   #382	-> 4277
/*     */     //   #393	-> 4291
/*     */     //   #396	-> 4304
/*     */     //   #397	-> 4314
/*     */     //   #398	-> 4325
/*     */     //   #398	-> 4386
/*     */     //   #399	-> 4453
/*     */     //   #401	-> 4464
/*     */     //   #405	-> 4475
/*     */     //   #406	-> 4483
/*     */     //   #407	-> 4506
/*     */     //   #410	-> 4515
/*     */     //   #412	-> 4535
/*     */     //   #413	-> 4541
/*     */     //   #412	-> 4591
/*     */     //   #412	-> 4594
/*     */     //   #415	-> 4609
/*     */     //   #416	-> 4619
/*     */     //   #417	-> 4625
/*     */     //   #418	-> 4675
/*     */     //   #416	-> 4700
/*     */     //   #416	-> 4703
/*     */     //   #0	-> 4718
/*     */     //   #420	-> 4718
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	4719	0	n	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	1	x	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	2	m	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	3	in	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	4	ia	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	5	ib	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	6	ih	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	7	nh	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	8	il	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	4719	9	d1	D
/*     */     //   0	4719	11	x_offset	I
/*     */     //   0	4719	12	x_dim1	I
/*     */     //   0	4719	13	mxbb	[I
/*     */     //   0	4719	14	mxb	[I
/*     */     //   0	4719	15	mxa	[I
/*     */     //   0	4719	16	min	I
/*     */     //   0	4719	17	inh	I
/*     */     //   0	4719	18	nib	I
/*     */     //   0	4719	19	nia	I
/*     */     //   0	4719	20	mbb	[I
/*     */     //   0	4719	21	mp1	I
/*     */     //   0	4719	22	mx	I
/*     */     //   0	4719	23	kx	I
/*     */     //   0	4719	24	mm	I
/*     */     //   0	4719	25	kn	I
/*     */     //   0	4719	26	mb	[I
/*     */     //   0	4719	27	ma	I
/*     */     //   0	4719	28	ilinh	I
/*     */     //   0	4719	29	j	I
/*     */     //   0	4719	30	i	I
/*     */     //   0	4719	31	maxe	I
/*     */     //   0	4719	32	mine	I
/*     */     //   0	4719	37	j$110	I
/*     */     //   0	4719	42	j$109	I
/*     */     //   0	4719	46	i$108	I
/*     */     //   0	4719	52	i$107	I
/*     */     //   0	4719	56	i$106	I
/*     */     //   0	4719	83	kx$105	I
/*     */     //   0	4719	89	kn$104	I
/*     */     //   0	4719	126	i$103	I
/*     */     //   0	4719	131	x_offset$102	I
/*     */     //   0	4719	136	ma$101	I
/*     */     //   0	4719	140	nia$100	I
/*     */     //   0	4719	145	inh$99	I
/*     */     //   0	4719	150	ilinh$98	I
/*     */     //   0	4719	154	nia$97	I
/*     */     //   0	4719	158	nib$96	I
/*     */     //   0	4719	162	inh$95	I
/*     */     //   0	4719	167	ma$94	I
/*     */     //   0	4719	172	ma$93	I
/*     */     //   0	4719	176	inh$92	I
/*     */     //   0	4719	180	inh$91	I
/*     */     //   0	4719	181	mbb$90	I
/*     */     //   0	4719	186	x_offset$89	I
/*     */     //   0	4719	187	mb$88	I
/*     */     //   0	4719	191	nib$87	I
/*     */     //   0	4719	196	inh$86	I
/*     */     //   0	4719	201	ilinh$85	I
/*     */     //   0	4719	205	nia$84	I
/*     */     //   0	4719	209	ma$83	I
/*     */     //   0	4719	213	nib$82	I
/*     */     //   0	4719	217	inh$81	I
/*     */     //   0	4719	218	mb$80	I
/*     */     //   0	4719	221	mb$79	I
/*     */     //   0	4719	222	mb$78	I
/*     */     //   0	4719	227	mb$77	I
/*     */     //   0	4719	228	mb$76	I
/*     */     //   0	4719	232	mxb$75	I
/*     */     //   0	4719	233	mxb$74	I
/*     */     //   0	4719	238	mxb$73	I
/*     */     //   0	4719	239	mxb$72	I
/*     */     //   0	4719	249	inh$71	I
/*     */     //   0	4719	254	inh$70	I
/*     */     //   0	4719	260	mxb$69	I
/*     */     //   0	4719	265	ma$68	I
/*     */     //   0	4719	269	ma$67	I
/*     */     //   0	4719	270	mb$66	I
/*     */     //   0	4719	274	ma$65	I
/*     */     //   0	4719	275	mxbb$64	I
/*     */     //   0	4719	276	mbb$63	I
/*     */     //   0	4719	280	ma$62	I
/*     */     //   0	4719	285	x_offset$61	I
/*     */     //   0	4719	290	ma$60	I
/*     */     //   0	4719	294	nib$59	I
/*     */     //   0	4719	299	inh$58	I
/*     */     //   0	4719	304	ilinh$57	I
/*     */     //   0	4719	310	nib$56	I
/*     */     //   0	4719	314	inh$55	I
/*     */     //   0	4719	319	ma$54	I
/*     */     //   0	4719	325	ma$53	I
/*     */     //   0	4719	329	inh$52	I
/*     */     //   0	4719	333	inh$51	I
/*     */     //   0	4719	334	mbb$50	I
/*     */     //   0	4719	339	x_offset$49	I
/*     */     //   0	4719	340	mb$48	I
/*     */     //   0	4719	347	inh$47	I
/*     */     //   0	4719	352	ilinh$46	I
/*     */     //   0	4719	358	nib$45	I
/*     */     //   0	4719	362	ma$44	I
/*     */     //   0	4719	366	inh$43	I
/*     */     //   0	4719	367	mb$42	I
/*     */     //   0	4719	370	mb$41	I
/*     */     //   0	4719	371	mb$40	I
/*     */     //   0	4719	376	mb$39	I
/*     */     //   0	4719	377	mb$38	I
/*     */     //   0	4719	381	mxa$37	I
/*     */     //   0	4719	382	mxa$36	I
/*     */     //   0	4719	387	mxa$35	I
/*     */     //   0	4719	388	mxa$34	I
/*     */     //   0	4719	398	inh$33	I
/*     */     //   0	4719	403	inh$32	I
/*     */     //   0	4719	409	mxa$31	I
/*     */     //   0	4719	414	ma$30	I
/*     */     //   0	4719	419	x_offset$29	I
/*     */     //   0	4719	435	ma$28	I
/*     */     //   0	4719	452	min$27	I
/*     */     //   0	4719	469	mx$26	I
/*     */     //   0	4719	494	kn$25	I
/*     */     //   0	4719	500	j$24	I
/*     */     //   0	4719	504	i$23	I
/*     */     //   0	4719	525	kx$22	I
/*     */     //   0	4719	531	j$21	I
/*     */     //   0	4719	535	i$20	I
/*     */     //   0	4719	542	kn$19	I
/*     */     //   0	4719	548	j$18	I
/*     */     //   0	4719	554	kx$17	I
/*     */     //   0	4719	560	j$16	I
/*     */     //   0	4719	564	i$15	I
/*     */     //   0	4719	574	x_offset$14	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP chull(SEXP x) {
/* 429 */     nh = new int[1]; n = new int[1]; ians = BytePtr.of(0); ians$offset = 0; ans = (SEXP)BytePtr.of(0).getArray(); ih = BytePtr.of(0); ih$offset = 0; in = BytePtr.of(0); in$offset = 0; nh[0] = 0; n[0] = 0; n$0 = Rinternals.Rf_nrows(x); n[0] = n$0;
/* 430 */     IntPtr intPtr = IntPtr.malloc(n[0] * 4); in$offset = 0;
/* 431 */     j = 0; while (true) { n$4 = n[0]; if (j >= n$4) {
/* 432 */         IntPtr intPtr2 = IntPtr.malloc(n[0] * 16); ih$offset = 0;
/* 433 */         x = Rinternals.Rf_protect(Rinternals.Rf_coerceVector(x, 14));
/* 434 */         if (Rinternals.TYPEOF(x) != 14) Error.Rf_error(new BytePtr("'x' is not numeric\000".getBytes(), 0), new Object[0]); 
/* 435 */         int i7 = n[0] * 12; IntPtr intPtr5 = intPtr2; int i6 = ih$offset + i7, i5 = n[0] * 8; IntPtr intPtr4 = intPtr2; int i4 = ih$offset + i5, i3 = n[0] * 4; IntPtr intPtr3 = intPtr2; int i2 = ih$offset + i3; Ptr ptr = Rinternals2.REAL(x); in_chull((Ptr)new IntPtr(n, 0), ptr, (Ptr)new IntPtr(n, 0), intPtr.pointerPlus(in$offset), intPtr3.pointerPlus(i2), intPtr4.pointerPlus(i4), intPtr2.pointerPlus(ih$offset), (Ptr)new IntPtr(nh, 0), intPtr5.pointerPlus(i6));
/* 436 */         nh$10 = nh[0]; ans = Rinternals.Rf_allocVector(13, nh$10);
/* 437 */         ians = Rinternals2.INTEGER(ans); ians$offset = 0;
/* 438 */         i = 0; while (true) { nh$13 = nh[0]; if (i >= nh$13) break;  int i12 = i * 4; Ptr ptr1 = ians; int i11 = ians$offset + i12, i10 = (nh[0] + -1 - i) * 4; IntPtr intPtr6 = intPtr2; int i9 = ih$offset + i10, i8 = intPtr6.getInt(i9); ptr1.setInt(i11, i8); i++; }
/*     */         
/* 440 */         return ans;
/*     */       } 
/*     */       int i1 = j * 4;
/*     */       IntPtr intPtr1 = intPtr;
/*     */       int m = in$offset + i1, k = j + 1;
/*     */       intPtr1.setInt(m, k);
/*     */       j++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/chull__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */