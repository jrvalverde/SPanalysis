/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import org.renjin.gcc.runtime.Builtins;
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.MixedPtr;
/*     */ import org.renjin.gcc.runtime.PointerPtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gnur.api.Defn;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.Rinterface;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.gnur.api.Rinternals2;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class javaGD__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static int newJavaGDDeviceDriver(Ptr dd, Ptr disp_name, Ptr device_class, SEXP device_options, double width, double height, double initps) {
/*  62 */     xd = Rf_allocNewJavaGDDeviceDesc(initps);
/*  63 */     if (jGDtalk__.newJavaGD_Open(dd, xd, disp_name, device_class, device_options, width, height) != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       Rf_setNewJavaGDDeviceData(dd, 0.6D, xd);
/*     */       
/*  70 */       return 1;
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int Rf_setNewJavaGDDeviceData(Ptr dd, double gamma_fac, Ptr xd) {
/*  86 */     jGDtalk__.setupJavaGDfunctions(dd);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     dd.setAlignedDouble(4, 0.0D); double d9 = dd.getAlignedDouble(4); dd.setDouble(d9);
/*  94 */     double d8 = xd.getAlignedInt(12); dd.setAlignedDouble(5, d8); double d7 = dd.getAlignedDouble(5); dd.setAlignedDouble(1, d7);
/*  95 */     double d6 = xd.getAlignedInt(13); dd.setAlignedDouble(6, d6); double d5 = dd.getAlignedDouble(6); dd.setAlignedDouble(2, d5);
/*  96 */     dd.setAlignedDouble(7, 0.0D); double d4 = dd.getAlignedDouble(7); dd.setAlignedDouble(3, d4);
/*     */ 
/*     */ 
/*     */     
/* 100 */     dd.setAlignedDouble(13, 8.0D);
/* 101 */     dd.setAlignedDouble(14, 11.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     dd.setAlignedDouble(8, 0.49D);
/* 108 */     dd.setAlignedDouble(9, 0.3333D);
/* 109 */     dd.setAlignedDouble(10, 0.1D);
/*     */ 
/*     */ 
/*     */     
/* 113 */     jGDdpiX$17 = Context.get__javaGD$jGDdpiX(); double d3 = 1.0D / jGDdpiX$17; dd.setAlignedDouble(11, d3);
/* 114 */     jGDdpiY$18 = Context.get__javaGD$jGDdpiY(); double d2 = 1.0D / jGDdpiY$18; dd.setAlignedDouble(12, d2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     dd.setAlignedInt(32, 1);
/* 125 */     dd.setAlignedInt(34, 2);
/* 126 */     dd.setAlignedInt(33, 0);
/*     */     
/* 128 */     double d1 = xd.getAlignedInt(11); dd.setDouble(140, d1);
/* 129 */     int j = xd.getAlignedInt(5); dd.setAlignedInt(37, j);
/* 130 */     int i = xd.getAlignedInt(6); dd.setAlignedInt(38, i);
/* 131 */     dd.setAlignedInt(39, 0);
/* 132 */     dd.setAlignedInt(40, 1);
/* 133 */     dd.setDouble(164, gamma_fac);
/*     */ 
/*     */     
/* 136 */     dd.setAlignedInt(44, 0);
/*     */     
/* 138 */     xd.setAlignedInt(18, 0);
/* 139 */     dd.setAlignedPointer(43, xd);
/*     */     
/* 141 */     dd.setAlignedInt(44, 1);
/*     */     
/* 143 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr Rf_allocNewJavaGDDeviceDesc(double ps) {
/* 154 */     MixedPtr mixedPtr = MixedPtr.malloc(76); if (!mixedPtr.isNull()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       if (ps < 6.0D || ps > 24.0D) ps = 12.0D; 
/* 163 */       mixedPtr.setInt(32, -1);
/* 164 */       mixedPtr.setInt(36, -1);
/* 165 */       mixedPtr.setInt(40, 1);
/* 166 */       int i = (int)ps; mixedPtr.setInt(44, i);
/*     */       
/* 168 */       MixedPtr mixedPtr1 = mixedPtr; boolean bool1 = false;
/*     */       return mixedPtr1.pointerPlus(bool1);
/*     */     } 
/*     */     Ptr ptr = BytePtr.of(0);
/*     */     boolean bool = false;
/*     */     return ptr.pointerPlus(bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr Rf_addJavaGDDevice(Ptr display, Ptr device_class, SEXP device_options, double width, double height, double initps) {
/* 192 */     dev = BytePtr.of(0); dev$offset = 0;
/*     */ 
/*     */ 
/*     */     
/* 196 */     BytePtr bytePtr = new BytePtr("JavaGD\000".getBytes(), 0);
/*     */     
/* 198 */     baseDevices__.R_CheckDeviceAvailable();
/*     */     
/* 200 */     __oldsusp__ = Defn.R_interrupts_suspended; Defn.R_interrupts_suspended = 1;
/*     */ 
/*     */     
/* 203 */     MixedPtr mixedPtr = MixedPtr.malloc(404); dev$offset = 0; if (!mixedPtr.pointerPlus(dev$offset).isNull()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 218 */       if (newJavaGDDeviceDriver(mixedPtr.pointerPlus(dev$offset), display, device_class, device_options, width, height, initps) == 0)
/*     */       {
/*     */         
/* 221 */         Error.Rf_error(new BytePtr("unable to start device %s\000".getBytes(), 0), new Object[] { bytePtr });
/*     */       }
/*     */       
/* 224 */       R_NilValue$13 = Rinternals.R_NilValue; SEXP sEXP = Rinternals.Rf_mkString((Ptr)bytePtr); Rinternals.Rf_gsetVar(Rinternals.Rf_install(new BytePtr(".Device\000".getBytes(), 0)), sEXP, R_NilValue$13);
/* 225 */       dd = baseDevices__.GEcreateDevDesc(mixedPtr.pointerPlus(dev$offset));
/* 226 */       baseDevices__.GEaddDevice(dd);
/*     */ 
/*     */ 
/*     */       
/* 230 */       myDevID = baseDevices__.Rf_curDevice();
/* 231 */       maxJdeviceNum$14 = Context.get__javaGD$maxJdeviceNum(); if (myDevID > maxJdeviceNum$14)
/* 232 */         Context.set__javaGD$maxJdeviceNum(myDevID); 
/* 233 */       baseEngine__.GEinitDisplayList(dd);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 238 */       Defn.R_interrupts_suspended = __oldsusp__; if (Defn.R_interrupts_pending != 0 && Defn.R_interrupts_suspended == 0) Rinterface.Rf_onintr();
/*     */ 
/*     */       
/* 241 */       Ptr ptr1 = dd; boolean bool1 = false;
/*     */       return ptr1.pointerPlus(bool1);
/*     */     } 
/*     */     Ptr ptr = BytePtr.of(0);
/*     */     boolean bool = false;
/*     */     return ptr.pointerPlus(bool); } public static void reloadJavaGD(Ptr dn) {
/* 247 */     gd = baseDevices__.GEgetDevice(dn.getInt());
/* 248 */     if (!gd.isNull()) {
/* 249 */       dd = gd.getPointer();
/*     */ 
/*     */ 
/*     */       
/* 253 */       if (!dd.isNull()) resizedJavaGD(dd); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static SEXP javaGDobjectCall(SEXP dev) {
/* 258 */     ds = Context.get__javaGD$maxJdeviceNum() + 1;
/*     */ 
/*     */     
/* 261 */     ptr = BytePtr.of(0); ptr$offset = 0;
/*     */     
/* 263 */     dn = Rinternals.Rf_asInteger(dev);
/* 264 */     if (dn >= 0 && dn < ds) {
/* 265 */       gd = baseDevices__.GEgetDevice(dn);
/* 266 */       if (!gd.isNull()) {
/* 267 */         dd = gd.getPointer();
/* 268 */         if (!dd.isNull()) {
/* 269 */           xd = dd.getPointer(172);
/* 270 */           if (!xd.isNull()) { ptr = xd.getPointer(60); ptr$offset = 0; }
/*     */         
/*     */         } 
/* 273 */       }  if (!ptr.pointerPlus(ptr$offset).isNull()) {
/* 274 */         R_NilValue$11 = Rinternals.R_NilValue; R_NilValue$12 = Rinternals.R_NilValue; return Rinternals.R_MakeExternalPtr(ptr.pointerPlus(ptr$offset), R_NilValue$12, R_NilValue$11);
/*     */       } 
/*     */       return Rinternals.R_NilValue;
/*     */     } 
/* 278 */     return Rinternals.R_NilValue; } public static void javaGDresize_(int dev) { ds = 0; ds = Context.get__javaGD$maxJdeviceNum() + 1;
/* 279 */     i = 0;
/* 280 */     if (dev >= 0 && dev < ds) {
/* 281 */       i = dev;
/* 282 */       ds = dev + 1;
/*     */     } 
/* 284 */     while (i < ds) {
/* 285 */       gd = baseDevices__.GEgetDevice(i);
/* 286 */       if (!gd.isNull()) {
/* 287 */         dd = gd.getPointer();
/*     */ 
/*     */ 
/*     */         
/* 291 */         if (!dd.isNull()) {
/*     */ 
/*     */ 
/*     */           
/* 295 */           MethodHandle methodHandle = dd.getPointer(264).toMethodHandle(); Ptr ptr4 = dd, ptr3 = dd, ptr2 = dd, ptr1 = dd; methodHandle.invoke(ptr1, ptr2.pointerPlus(8), ptr3.pointerPlus(16), ptr4.pointerPlus(24), dd);
/* 296 */           baseEngine__.GEplayDisplayList(gd);
/*     */         } 
/*     */       } 
/* 299 */       i++;
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void javaGDresize(Ptr dev) {
/* 305 */     if (!dev.isNull()) javaGDresize_(dev.getInt()); 
/*     */   }
/*     */   
/*     */   public static SEXP javaGDresizeCall(SEXP dev) {
/* 309 */     javaGDresize_(Rinternals.Rf_asInteger(dev));
/* 310 */     return dev;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resizedJavaGD(Ptr dd) {
/* 319 */     MethodHandle methodHandle = dd.getAlignedPointer(66).toMethodHandle(); Ptr ptr4 = dd, ptr3 = dd, ptr2 = dd, ptr1 = dd; methodHandle.invoke(ptr1, ptr2.pointerPlus(8), ptr3.pointerPlus(16), ptr4.pointerPlus(24), dd);
/* 320 */     devNum = baseDevices__.Rf_ndevNumber(dd);
/* 321 */     if (devNum > 0)
/* 322 */       baseEngine__.GEplayDisplayList(baseDevices__.GEgetDevice(devNum)); 
/*     */   }
/*     */   
/*     */   public static SEXP newJavaGD(SEXP name, SEXP sw, SEXP sh, SEXP sps, SEXP deviceClass, SEXP deviceOptions) {
/* 326 */     w = Rinternals.Rf_asReal(sw);
/* 327 */     h = Rinternals.Rf_asReal(sh);
/* 328 */     ps = Rinternals.Rf_asReal(sps);
/* 329 */     if (Rinternals.TYPEOF(name) != 16 || Rinternals.LENGTH(name) <= 0) {
/* 330 */       Error.Rf_error(new BytePtr("invalid name\000".getBytes(), 0), new Object[0]);
/*     */     }
/* 332 */     if (Rinternals.TYPEOF(deviceClass) != 16 || Rinternals.LENGTH(deviceClass) <= 0) {
/* 333 */       Error.Rf_error(new BytePtr("invalid deviceClass\000".getBytes(), 0), new Object[0]);
/*     */     }
/* 335 */     if (Builtins.__isnan(w) != 0 || w <= 0.0D || Builtins.__isnan(h) != 0 || h <= 0.0D || Builtins.__isnan(ps) != 0 || ps <= 0.0D) {
/* 336 */       Error.Rf_error(new BytePtr("invalid width, height or ps\000".getBytes(), 0), new Object[0]);
/*     */     }
/* 338 */     BytePtr bytePtr = Rinternals.R_CHAR(Rinternals.STRING_ELT(deviceClass, 0)); Rf_addJavaGDDevice((Ptr)Rinternals.R_CHAR(Rinternals.STRING_ELT(name, 0)), (Ptr)bytePtr, deviceOptions, w, h, ps);
/* 339 */     return name;
/*     */   }
/*     */   
/*     */   public static SEXP javaGDgetSize(SEXP sDev) {
/* 343 */     PointerPtr pointerPtr = PointerPtr.malloc(28); res = Rinternals.R_NilValue;
/* 344 */     dev = Rinternals.Rf_asInteger(sDev);
/* 345 */     ds = Context.get__javaGD$maxJdeviceNum() + 1;
/* 346 */     if (dev < 0 || dev >= ds) {
/* 347 */       Error.Rf_error(new BytePtr("invalid device\000".getBytes(), 0), new Object[0]);
/*     */     }
/* 349 */     gd = baseDevices__.GEgetDevice(dev);
/* 350 */     if (!gd.isNull()) {
/* 351 */       dd = gd.getPointer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 358 */       if (!dd.isNull()) {
/* 359 */         pointerPtr.setPointer((Ptr)new BytePtr("x\000".getBytes(), 0)); pointerPtr.setAlignedPointer(1, (Ptr)new BytePtr("y\000".getBytes(), 0)); pointerPtr.setAlignedPointer(2, (Ptr)new BytePtr("width\000".getBytes(), 0)); pointerPtr.setAlignedPointer(3, (Ptr)new BytePtr("height\000".getBytes(), 0)); pointerPtr.setAlignedPointer(4, (Ptr)new BytePtr("dpiX\000".getBytes(), 0)); pointerPtr.setAlignedPointer(5, (Ptr)new BytePtr("dpiY\000".getBytes(), 0)); pointerPtr.setAlignedPointer(6, (Ptr)new BytePtr("\000".getBytes(), 0)); res = Rinternals.Rf_protect(Rinternals.Rf_mkNamed(19, (Ptr)pointerPtr));
/*     */         
/* 361 */         SEXP sEXP6 = Rinternals.Rf_ScalarReal(dd.getDouble()); Rinternals.SET_VECTOR_ELT(res, 0, sEXP6);
/* 362 */         SEXP sEXP5 = Rinternals.Rf_ScalarReal(dd.getDouble(24)); Rinternals.SET_VECTOR_ELT(res, 1, sEXP5);
/* 363 */         double d4 = dd.getDouble(8), d3 = dd.getDouble(); SEXP sEXP4 = Rinternals.Rf_ScalarReal(d4 - d3); Rinternals.SET_VECTOR_ELT(res, 2, sEXP4);
/* 364 */         double d2 = dd.getDouble(16), d1 = dd.getDouble(24); SEXP sEXP3 = Rinternals.Rf_ScalarReal(d2 - d1); Rinternals.SET_VECTOR_ELT(res, 3, sEXP3);
/* 365 */         SEXP sEXP2 = Rinternals.Rf_ScalarReal(Context.get__javaGD$jGDdpiX()); Rinternals.SET_VECTOR_ELT(res, 4, sEXP2);
/* 366 */         SEXP sEXP1 = Rinternals.Rf_ScalarReal(Context.get__javaGD$jGDdpiY()); Rinternals.SET_VECTOR_ELT(res, 5, sEXP1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP javaGDsetDisplayParam(SEXP pars) {
/* 382 */     if (Rinternals.TYPEOF(pars) != 14)
/* 383 */       pars = Rinternals.Rf_coerceVector(pars, 14); 
/* 384 */     par = Rinternals2.REAL(pars);
/* 385 */     n = Rinternals.LENGTH(pars);
/* 386 */     if (n > 0) Context.set__javaGD$jGDdpiX(par.getDouble()); 
/* 387 */     if (n > 1) Context.set__javaGD$jGDdpiY(par.getDouble(8)); 
/* 388 */     if (n > 2) Context.set__javaGD$jGDasp(par.getDouble(16)); 
/* 389 */     return pars;
/*     */   }
/*     */   
/*     */   public static SEXP javaGDgetDisplayParam() {
/* 393 */     PointerPtr pointerPtr = PointerPtr.malloc(16); pointerPtr.setPointer((Ptr)new BytePtr("dpiX\000".getBytes(), 0)); pointerPtr.setAlignedPointer(1, (Ptr)new BytePtr("dpiY\000".getBytes(), 0)); pointerPtr.setAlignedPointer(2, (Ptr)new BytePtr("aspect\000".getBytes(), 0)); pointerPtr.setAlignedPointer(3, (Ptr)new BytePtr("\000".getBytes(), 0)); res = Rinternals.Rf_mkNamed(14, (Ptr)pointerPtr);
/* 394 */     par = Rinternals2.REAL(res);
/* 395 */     jGDdpiX$0 = Context.get__javaGD$jGDdpiX(); par.setDouble(0, jGDdpiX$0);
/* 396 */     Ptr ptr2 = par; jGDdpiY$1 = Context.get__javaGD$jGDdpiY(); ptr2.setDouble(8, jGDdpiY$1);
/* 397 */     Ptr ptr1 = par; jGDasp$2 = Context.get__javaGD$jGDasp(); ptr1.setDouble(16, jGDasp$2);
/* 398 */     return res;
/*     */   }
/*     */   
/*     */   public static SEXP javaGDversion() {
/* 402 */     return Rinternals.Rf_ScalarInteger(1538);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/javaGD__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */