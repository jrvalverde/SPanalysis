package org.renjin.grDevices;

import java.awt.Component;
import java.awt.Graphics;

interface GDObject {
  void paint(Component paramComponent, GDState paramGDState, Graphics paramGraphics);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/GDObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */