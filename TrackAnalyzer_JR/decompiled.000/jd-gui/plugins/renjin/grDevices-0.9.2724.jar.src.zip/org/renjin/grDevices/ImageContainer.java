/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.apache.commons.vfs2.FileObject;
/*     */ import org.renjin.eval.EvalException;
/*     */ import org.renjin.eval.Session;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageContainer
/*     */   implements GDContainer
/*     */ {
/*     */   private final GDState state;
/*     */   private final Dimension size;
/*     */   private int deviceNumber;
/*     */   private final BufferedImage bufferedImage;
/*     */   private final Session session;
/*     */   private final String filenameFormat;
/*     */   private String formatName;
/*     */   private Graphics2D graphics;
/*     */   private boolean empty = true;
/*  49 */   private int pageNumber = 1;
/*     */   
/*     */   public ImageContainer(Session session, String filenameFormat, String formatName, Color backgroundColor, int width, int height) {
/*  52 */     this.session = session;
/*  53 */     this.filenameFormat = filenameFormat;
/*  54 */     this.formatName = formatName;
/*  55 */     this.bufferedImage = new BufferedImage(width, height, 2);
/*  56 */     this.size = new Dimension(width, height);
/*  57 */     this.graphics = this.bufferedImage.createGraphics();
/*  58 */     this.graphics.setBackground(backgroundColor);
/*  59 */     this.graphics.clearRect(0, 0, (int)this.size.getWidth(), (int)this.size.getHeight());
/*  60 */     this.state = new GDState();
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(GDObject o) {
/*  65 */     this.empty = false;
/*  66 */     o.paint(null, this.state, this.graphics);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  71 */     if (!this.empty) {
/*  72 */       flush();
/*     */     }
/*  74 */     this.graphics.setClip(null);
/*  75 */     this.graphics.clearRect(0, 0, (int)this.size.getWidth(), (int)this.size.getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public GDState getGState() {
/*  80 */     return this.state;
/*     */   }
/*     */ 
/*     */   
/*     */   public Graphics getGraphics() {
/*  85 */     return this.graphics;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncDisplay(boolean finish) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeviceNumber(int dn) {
/*  95 */     this.deviceNumber = dn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeDisplay() {
/* 100 */     flush();
/*     */   }
/*     */   
/*     */   private void flush() {
/*     */     try {
/* 105 */       String filename = String.format(this.filenameFormat, new Object[] { Integer.valueOf(this.pageNumber++) });
/* 106 */       FileObject fileObject = this.session.resolveFile(filename);
/*     */       
/* 108 */       try (OutputStream outputStream = fileObject.getContent().getOutputStream()) {
/* 109 */         ImageIO.write(this.bufferedImage, this.formatName, outputStream);
/*     */       } 
/* 111 */     } catch (IOException e) {
/* 112 */       throw new EvalException("Failed to write image: " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDeviceNumber() {
/* 118 */     return this.deviceNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 123 */     return this.size;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/ImageContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */