/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*     */ import org.renjin.gnur.api.Arith;
/*     */ import org.renjin.gnur.api.Defn;
/*     */ import org.renjin.gnur.api.Error;
/*     */ import org.renjin.gnur.api.GetText;
/*     */ import org.renjin.gnur.api.Internal;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class stubs__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static SEXP X11(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  32 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_X11(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP savePlot(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  37 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_saveplot(call, op, sEXP, env);
/*     */   }
/*     */   
/*     */   public static SEXP bmVersion() {
/*  41 */     throw new UnsatisfiedLinkException("do_bmVersion");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP contourLines(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  47 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_contourLines(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP getSnapshot(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  52 */     SEXP sEXP = Rinternals.CDR(args); return baseEngine__.do_getSnapshot(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP playSnapshot(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  57 */     SEXP sEXP = Rinternals.CDR(args); return baseEngine__.do_playSnapshot(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP getGraphicsEvent(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  62 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_getGraphicsEvent(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP getGraphicsEventEnv(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  67 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_getGraphicsEventEnv(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SEXP setGraphicsEventEnv(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  72 */     SEXP sEXP = Rinternals.CDR(args); return Internal.do_setGraphicsEventEnv(call, op, sEXP, env);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SEXP devAskNewPage(SEXP call, SEXP op, SEXP args, SEXP env) {
/*  98 */     gdd = baseDevices__.GEcurrentDevice();
/*  99 */     oldask = gdd.getInt(124);
/*     */     
/* 101 */     args = Rinternals.CDR(args);
/* 102 */     if (Rinternals.TYPEOF(Rinternals.CAR(args)) == 0)
/*     */     
/*     */     { 
/*     */ 
/*     */       
/* 107 */       Defn.R_Visible = 1;
/*     */       
/* 109 */       return Rinternals.Rf_ScalarLogical(oldask); }  ask = Rinternals.Rf_asLogical(Rinternals.CAR(args)); R_NaInt$0 = Arith.R_NaInt; if (ask == R_NaInt$0) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("invalid '%s' argument\000".getBytes(), 0)), new Object[] { new BytePtr("ask\000".getBytes(), 0) });  ask$1 = ask; gdd.setInt(124, ask$1); Defn.R_Visible = 0; return Rinternals.Rf_ScalarLogical(oldask);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/stubs__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */