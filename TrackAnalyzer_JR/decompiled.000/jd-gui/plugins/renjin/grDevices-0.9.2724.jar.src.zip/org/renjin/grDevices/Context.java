package org.renjin.grDevices;

import java.lang.invoke.MethodHandle;
import org.renjin.gcc.runtime.Ptr;
import org.renjin.primitives.Native;
import org.renjin.sexp.SEXP;

public class Context {
  public Ptr baseDevices$pNullDevice;
  
  public int baseDevices$pNullDevice$offset;
  
  public int[] baseDevices$active;
  
  public Ptr baseDevices$R_Devices;
  
  public int baseDevices$R_NumDevices;
  
  public int baseDevices$R_CurrentDevice;
  
  public int baseDevices$baseRegisterIndex;
  
  public double baseEngine$w$11908;
  
  public double baseEngine$d$11907;
  
  public double baseEngine$a$11906;
  
  public byte[] baseEngine$last_family$11909;
  
  public int baseEngine$last_face$11903;
  
  public double baseEngine$last_ps$11905;
  
  public double baseEngine$last_cex$11904;
  
  public MethodHandle baseEngine$last_close$11902;
  
  public Ptr baseEngine$last_dd$11900;
  
  public int baseEngine$last_dd$11900$offset;
  
  public int baseEngine$last_ipch$12141;
  
  public SEXP baseEngine$last_pch$12140;
  
  public int baseEngine$nlinetype;
  
  public byte[] baseEngine$HexDigits;
  
  public Ptr baseEngine$linetype;
  
  public Ptr baseEngine$ypoints;
  
  public int baseEngine$ypoints$offset;
  
  public Ptr baseEngine$xpoints;
  
  public int baseEngine$xpoints$offset;
  
  public int baseEngine$max_points;
  
  public int baseEngine$npoints;
  
  public Ptr baseEngine$VFontTable;
  
  public int baseEngine$nlinejoin;
  
  public Ptr baseEngine$linejoin;
  
  public int baseEngine$nlineend;
  
  public Ptr baseEngine$lineend;
  
  public Ptr baseEngine$registeredSystems;
  
  public int baseEngine$numGraphicsSystems;
  
  public byte[] colors$ColBuf$7367;
  
  public MethodHandle colors$ptr_savePalette;
  
  public Ptr colors$ColorDataBase;
  
  public Ptr colors$DefaultPalette;
  
  public int[] colors$Palette0;
  
  public int[] colors$Palette;
  
  public int colors$PaletteSize;
  
  public byte[] colors$HexDigits;
  
  public byte[] colors$ColBuf;
  
  public int devices$LoadInitFile;
  
  public int devices$R_ReadItemDepth;
  
  public int devices$R_InitReadItemDepth;
  
  public int devices$R_OutputCon;
  
  public Ptr init$ExtEntries;
  
  public Ptr init$CallEntries;
  
  public Ptr jGDtalk$lastGC;
  
  public int javaGD$maxJdeviceNum;
  
  public double javaGD$jGDasp;
  
  public double javaGD$jGDdpiY;
  
  public double javaGD$jGDdpiX;
  
  public byte[] s2u$work;
  
  public int[] s2u$s2u;
  
  public static Context current() {
    return (Context)Native.currentContext().getSingleton(Context.class);
  }
  
  public static Ptr get__baseDevices$pNullDevice() {
    return (current()).baseDevices$pNullDevice;
  }
  
  public static void set__baseDevices$pNullDevice(Ptr paramPtr) {
    (current()).baseDevices$pNullDevice = paramPtr;
  }
  
  public static int get__baseDevices$pNullDevice$offset() {
    return (current()).baseDevices$pNullDevice$offset;
  }
  
  public static void set__baseDevices$pNullDevice$offset(int paramInt) {
    (current()).baseDevices$pNullDevice$offset = paramInt;
  }
  
  public static int[] get__baseDevices$active() {
    return (current()).baseDevices$active;
  }
  
  public static void set__baseDevices$active(int[] paramArrayOfint) {
    (current()).baseDevices$active = paramArrayOfint;
  }
  
  public static Ptr get__baseDevices$R_Devices() {
    return (current()).baseDevices$R_Devices;
  }
  
  public static void set__baseDevices$R_Devices(Ptr paramPtr) {
    (current()).baseDevices$R_Devices = paramPtr;
  }
  
  public static int get__baseDevices$R_NumDevices() {
    return (current()).baseDevices$R_NumDevices;
  }
  
  public static void set__baseDevices$R_NumDevices(int paramInt) {
    (current()).baseDevices$R_NumDevices = paramInt;
  }
  
  public static int get__baseDevices$R_CurrentDevice() {
    return (current()).baseDevices$R_CurrentDevice;
  }
  
  public static void set__baseDevices$R_CurrentDevice(int paramInt) {
    (current()).baseDevices$R_CurrentDevice = paramInt;
  }
  
  public static int get__baseDevices$baseRegisterIndex() {
    return (current()).baseDevices$baseRegisterIndex;
  }
  
  public static void set__baseDevices$baseRegisterIndex(int paramInt) {
    (current()).baseDevices$baseRegisterIndex = paramInt;
  }
  
  public static double get__baseEngine$w$11908() {
    return (current()).baseEngine$w$11908;
  }
  
  public static void set__baseEngine$w$11908(double paramDouble) {
    (current()).baseEngine$w$11908 = paramDouble;
  }
  
  public static double get__baseEngine$d$11907() {
    return (current()).baseEngine$d$11907;
  }
  
  public static void set__baseEngine$d$11907(double paramDouble) {
    (current()).baseEngine$d$11907 = paramDouble;
  }
  
  public static double get__baseEngine$a$11906() {
    return (current()).baseEngine$a$11906;
  }
  
  public static void set__baseEngine$a$11906(double paramDouble) {
    (current()).baseEngine$a$11906 = paramDouble;
  }
  
  public static byte[] get__baseEngine$last_family$11909() {
    return (current()).baseEngine$last_family$11909;
  }
  
  public static void set__baseEngine$last_family$11909(byte[] paramArrayOfbyte) {
    (current()).baseEngine$last_family$11909 = paramArrayOfbyte;
  }
  
  public static int get__baseEngine$last_face$11903() {
    return (current()).baseEngine$last_face$11903;
  }
  
  public static void set__baseEngine$last_face$11903(int paramInt) {
    (current()).baseEngine$last_face$11903 = paramInt;
  }
  
  public static double get__baseEngine$last_ps$11905() {
    return (current()).baseEngine$last_ps$11905;
  }
  
  public static void set__baseEngine$last_ps$11905(double paramDouble) {
    (current()).baseEngine$last_ps$11905 = paramDouble;
  }
  
  public static double get__baseEngine$last_cex$11904() {
    return (current()).baseEngine$last_cex$11904;
  }
  
  public static void set__baseEngine$last_cex$11904(double paramDouble) {
    (current()).baseEngine$last_cex$11904 = paramDouble;
  }
  
  public static MethodHandle get__baseEngine$last_close$11902() {
    return (current()).baseEngine$last_close$11902;
  }
  
  public static void set__baseEngine$last_close$11902(MethodHandle paramMethodHandle) {
    (current()).baseEngine$last_close$11902 = paramMethodHandle;
  }
  
  public static Ptr get__baseEngine$last_dd$11900() {
    return (current()).baseEngine$last_dd$11900;
  }
  
  public static void set__baseEngine$last_dd$11900(Ptr paramPtr) {
    (current()).baseEngine$last_dd$11900 = paramPtr;
  }
  
  public static int get__baseEngine$last_dd$11900$offset() {
    return (current()).baseEngine$last_dd$11900$offset;
  }
  
  public static void set__baseEngine$last_dd$11900$offset(int paramInt) {
    (current()).baseEngine$last_dd$11900$offset = paramInt;
  }
  
  public static int get__baseEngine$last_ipch$12141() {
    return (current()).baseEngine$last_ipch$12141;
  }
  
  public static void set__baseEngine$last_ipch$12141(int paramInt) {
    (current()).baseEngine$last_ipch$12141 = paramInt;
  }
  
  public static SEXP get__baseEngine$last_pch$12140() {
    return (current()).baseEngine$last_pch$12140;
  }
  
  public static void set__baseEngine$last_pch$12140(SEXP paramSEXP) {
    (current()).baseEngine$last_pch$12140 = paramSEXP;
  }
  
  public static int get__baseEngine$nlinetype() {
    return (current()).baseEngine$nlinetype;
  }
  
  public static void set__baseEngine$nlinetype(int paramInt) {
    (current()).baseEngine$nlinetype = paramInt;
  }
  
  public static byte[] get__baseEngine$HexDigits() {
    return (current()).baseEngine$HexDigits;
  }
  
  public static void set__baseEngine$HexDigits(byte[] paramArrayOfbyte) {
    (current()).baseEngine$HexDigits = paramArrayOfbyte;
  }
  
  public static Ptr get__baseEngine$linetype() {
    return (current()).baseEngine$linetype;
  }
  
  public static void set__baseEngine$linetype(Ptr paramPtr) {
    (current()).baseEngine$linetype = paramPtr;
  }
  
  public static Ptr get__baseEngine$ypoints() {
    return (current()).baseEngine$ypoints;
  }
  
  public static void set__baseEngine$ypoints(Ptr paramPtr) {
    (current()).baseEngine$ypoints = paramPtr;
  }
  
  public static int get__baseEngine$ypoints$offset() {
    return (current()).baseEngine$ypoints$offset;
  }
  
  public static void set__baseEngine$ypoints$offset(int paramInt) {
    (current()).baseEngine$ypoints$offset = paramInt;
  }
  
  public static Ptr get__baseEngine$xpoints() {
    return (current()).baseEngine$xpoints;
  }
  
  public static void set__baseEngine$xpoints(Ptr paramPtr) {
    (current()).baseEngine$xpoints = paramPtr;
  }
  
  public static int get__baseEngine$xpoints$offset() {
    return (current()).baseEngine$xpoints$offset;
  }
  
  public static void set__baseEngine$xpoints$offset(int paramInt) {
    (current()).baseEngine$xpoints$offset = paramInt;
  }
  
  public static int get__baseEngine$max_points() {
    return (current()).baseEngine$max_points;
  }
  
  public static void set__baseEngine$max_points(int paramInt) {
    (current()).baseEngine$max_points = paramInt;
  }
  
  public static int get__baseEngine$npoints() {
    return (current()).baseEngine$npoints;
  }
  
  public static void set__baseEngine$npoints(int paramInt) {
    (current()).baseEngine$npoints = paramInt;
  }
  
  public static Ptr get__baseEngine$VFontTable() {
    return (current()).baseEngine$VFontTable;
  }
  
  public static void set__baseEngine$VFontTable(Ptr paramPtr) {
    (current()).baseEngine$VFontTable = paramPtr;
  }
  
  public static int get__baseEngine$nlinejoin() {
    return (current()).baseEngine$nlinejoin;
  }
  
  public static void set__baseEngine$nlinejoin(int paramInt) {
    (current()).baseEngine$nlinejoin = paramInt;
  }
  
  public static Ptr get__baseEngine$linejoin() {
    return (current()).baseEngine$linejoin;
  }
  
  public static void set__baseEngine$linejoin(Ptr paramPtr) {
    (current()).baseEngine$linejoin = paramPtr;
  }
  
  public static int get__baseEngine$nlineend() {
    return (current()).baseEngine$nlineend;
  }
  
  public static void set__baseEngine$nlineend(int paramInt) {
    (current()).baseEngine$nlineend = paramInt;
  }
  
  public static Ptr get__baseEngine$lineend() {
    return (current()).baseEngine$lineend;
  }
  
  public static void set__baseEngine$lineend(Ptr paramPtr) {
    (current()).baseEngine$lineend = paramPtr;
  }
  
  public static Ptr get__baseEngine$registeredSystems() {
    return (current()).baseEngine$registeredSystems;
  }
  
  public static void set__baseEngine$registeredSystems(Ptr paramPtr) {
    (current()).baseEngine$registeredSystems = paramPtr;
  }
  
  public static int get__baseEngine$numGraphicsSystems() {
    return (current()).baseEngine$numGraphicsSystems;
  }
  
  public static void set__baseEngine$numGraphicsSystems(int paramInt) {
    (current()).baseEngine$numGraphicsSystems = paramInt;
  }
  
  public static byte[] get__colors$ColBuf$7367() {
    return (current()).colors$ColBuf$7367;
  }
  
  public static void set__colors$ColBuf$7367(byte[] paramArrayOfbyte) {
    (current()).colors$ColBuf$7367 = paramArrayOfbyte;
  }
  
  public static MethodHandle get__colors$ptr_savePalette() {
    return (current()).colors$ptr_savePalette;
  }
  
  public static void set__colors$ptr_savePalette(MethodHandle paramMethodHandle) {
    (current()).colors$ptr_savePalette = paramMethodHandle;
  }
  
  public static Ptr get__colors$ColorDataBase() {
    return (current()).colors$ColorDataBase;
  }
  
  public static void set__colors$ColorDataBase(Ptr paramPtr) {
    (current()).colors$ColorDataBase = paramPtr;
  }
  
  public static Ptr get__colors$DefaultPalette() {
    return (current()).colors$DefaultPalette;
  }
  
  public static void set__colors$DefaultPalette(Ptr paramPtr) {
    (current()).colors$DefaultPalette = paramPtr;
  }
  
  public static int[] get__colors$Palette0() {
    return (current()).colors$Palette0;
  }
  
  public static void set__colors$Palette0(int[] paramArrayOfint) {
    (current()).colors$Palette0 = paramArrayOfint;
  }
  
  public static int[] get__colors$Palette() {
    return (current()).colors$Palette;
  }
  
  public static void set__colors$Palette(int[] paramArrayOfint) {
    (current()).colors$Palette = paramArrayOfint;
  }
  
  public static int get__colors$PaletteSize() {
    return (current()).colors$PaletteSize;
  }
  
  public static void set__colors$PaletteSize(int paramInt) {
    (current()).colors$PaletteSize = paramInt;
  }
  
  public static byte[] get__colors$HexDigits() {
    return (current()).colors$HexDigits;
  }
  
  public static void set__colors$HexDigits(byte[] paramArrayOfbyte) {
    (current()).colors$HexDigits = paramArrayOfbyte;
  }
  
  public static byte[] get__colors$ColBuf() {
    return (current()).colors$ColBuf;
  }
  
  public static void set__colors$ColBuf(byte[] paramArrayOfbyte) {
    (current()).colors$ColBuf = paramArrayOfbyte;
  }
  
  public static int get__devices$LoadInitFile() {
    return (current()).devices$LoadInitFile;
  }
  
  public static void set__devices$LoadInitFile(int paramInt) {
    (current()).devices$LoadInitFile = paramInt;
  }
  
  public static int get__devices$R_ReadItemDepth() {
    return (current()).devices$R_ReadItemDepth;
  }
  
  public static void set__devices$R_ReadItemDepth(int paramInt) {
    (current()).devices$R_ReadItemDepth = paramInt;
  }
  
  public static int get__devices$R_InitReadItemDepth() {
    return (current()).devices$R_InitReadItemDepth;
  }
  
  public static void set__devices$R_InitReadItemDepth(int paramInt) {
    (current()).devices$R_InitReadItemDepth = paramInt;
  }
  
  public static int get__devices$R_OutputCon() {
    return (current()).devices$R_OutputCon;
  }
  
  public static void set__devices$R_OutputCon(int paramInt) {
    (current()).devices$R_OutputCon = paramInt;
  }
  
  public static Ptr get__init$ExtEntries() {
    return (current()).init$ExtEntries;
  }
  
  public static void set__init$ExtEntries(Ptr paramPtr) {
    (current()).init$ExtEntries = paramPtr;
  }
  
  public static Ptr get__init$CallEntries() {
    return (current()).init$CallEntries;
  }
  
  public static void set__init$CallEntries(Ptr paramPtr) {
    (current()).init$CallEntries = paramPtr;
  }
  
  public static Ptr get__jGDtalk$lastGC() {
    return (current()).jGDtalk$lastGC;
  }
  
  public static void set__jGDtalk$lastGC(Ptr paramPtr) {
    (current()).jGDtalk$lastGC = paramPtr;
  }
  
  public static int get__javaGD$maxJdeviceNum() {
    return (current()).javaGD$maxJdeviceNum;
  }
  
  public static void set__javaGD$maxJdeviceNum(int paramInt) {
    (current()).javaGD$maxJdeviceNum = paramInt;
  }
  
  public static double get__javaGD$jGDasp() {
    return (current()).javaGD$jGDasp;
  }
  
  public static void set__javaGD$jGDasp(double paramDouble) {
    (current()).javaGD$jGDasp = paramDouble;
  }
  
  public static double get__javaGD$jGDdpiY() {
    return (current()).javaGD$jGDdpiY;
  }
  
  public static void set__javaGD$jGDdpiY(double paramDouble) {
    (current()).javaGD$jGDdpiY = paramDouble;
  }
  
  public static double get__javaGD$jGDdpiX() {
    return (current()).javaGD$jGDdpiX;
  }
  
  public static void set__javaGD$jGDdpiX(double paramDouble) {
    (current()).javaGD$jGDdpiX = paramDouble;
  }
  
  public static byte[] get__s2u$work() {
    return (current()).s2u$work;
  }
  
  public static void set__s2u$work(byte[] paramArrayOfbyte) {
    (current()).s2u$work = paramArrayOfbyte;
  }
  
  public static int[] get__s2u$s2u() {
    return (current()).s2u$s2u;
  }
  
  public static void set__s2u$s2u(int[] paramArrayOfint) {
    (current()).s2u$s2u = paramArrayOfint;
  }
  
  public Context() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: bipush #64
    //   7: newarray int
    //   9: putfield baseDevices$active : [I
    //   12: aload_0
    //   13: sipush #256
    //   16: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/PointerPtr;
    //   19: putfield baseDevices$R_Devices : Lorg/renjin/gcc/runtime/Ptr;
    //   22: aload_0
    //   23: sipush #201
    //   26: newarray byte
    //   28: putfield baseEngine$last_family$11909 : [B
    //   31: aload_0
    //   32: bipush #17
    //   34: newarray byte
    //   36: putfield baseEngine$HexDigits : [B
    //   39: aload_0
    //   40: bipush #64
    //   42: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   45: putfield baseEngine$linetype : Lorg/renjin/gcc/runtime/Ptr;
    //   48: aload_0
    //   49: bipush #108
    //   51: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   54: putfield baseEngine$VFontTable : Lorg/renjin/gcc/runtime/Ptr;
    //   57: aload_0
    //   58: bipush #32
    //   60: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   63: putfield baseEngine$linejoin : Lorg/renjin/gcc/runtime/Ptr;
    //   66: aload_0
    //   67: bipush #32
    //   69: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   72: putfield baseEngine$lineend : Lorg/renjin/gcc/runtime/Ptr;
    //   75: aload_0
    //   76: bipush #96
    //   78: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/PointerPtr;
    //   81: putfield baseEngine$registeredSystems : Lorg/renjin/gcc/runtime/Ptr;
    //   84: aload_0
    //   85: bipush #10
    //   87: newarray byte
    //   89: putfield colors$ColBuf$7367 : [B
    //   92: aload_0
    //   93: sipush #7896
    //   96: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   99: putfield colors$ColorDataBase : Lorg/renjin/gcc/runtime/Ptr;
    //   102: aload_0
    //   103: bipush #36
    //   105: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/PointerPtr;
    //   108: putfield colors$DefaultPalette : Lorg/renjin/gcc/runtime/Ptr;
    //   111: aload_0
    //   112: sipush #1024
    //   115: newarray int
    //   117: putfield colors$Palette0 : [I
    //   120: aload_0
    //   121: sipush #1024
    //   124: newarray int
    //   126: putfield colors$Palette : [I
    //   129: aload_0
    //   130: bipush #17
    //   132: newarray byte
    //   134: putfield colors$HexDigits : [B
    //   137: aload_0
    //   138: bipush #10
    //   140: newarray byte
    //   142: putfield colors$ColBuf : [B
    //   145: aload_0
    //   146: sipush #540
    //   149: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   152: putfield init$ExtEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   155: aload_0
    //   156: sipush #380
    //   159: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   162: putfield init$CallEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   165: aload_0
    //   166: sipush #276
    //   169: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   172: putfield jGDtalk$lastGC : Lorg/renjin/gcc/runtime/Ptr;
    //   175: aload_0
    //   176: ldc_w 32768
    //   179: newarray byte
    //   181: putfield s2u$work : [B
    //   184: aload_0
    //   185: sipush #224
    //   188: newarray int
    //   190: putfield s2u$s2u : [I
    //   193: aload_0
    //   194: iconst_0
    //   195: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   198: putfield baseDevices$pNullDevice : Lorg/renjin/gcc/runtime/Ptr;
    //   201: aload_0
    //   202: iconst_0
    //   203: putfield baseDevices$pNullDevice$offset : I
    //   206: aload_0
    //   207: iconst_1
    //   208: putfield baseDevices$R_NumDevices : I
    //   211: aload_0
    //   212: iconst_0
    //   213: putfield baseDevices$R_CurrentDevice : I
    //   216: aload_0
    //   217: iconst_m1
    //   218: putfield baseDevices$baseRegisterIndex : I
    //   221: aload_0
    //   222: dconst_0
    //   223: putfield baseEngine$w$11908 : D
    //   226: aload_0
    //   227: dconst_0
    //   228: putfield baseEngine$d$11907 : D
    //   231: aload_0
    //   232: dconst_0
    //   233: putfield baseEngine$a$11906 : D
    //   236: aload_0
    //   237: iconst_1
    //   238: putfield baseEngine$last_face$11903 : I
    //   241: aload_0
    //   242: dconst_0
    //   243: putfield baseEngine$last_ps$11905 : D
    //   246: aload_0
    //   247: dconst_0
    //   248: putfield baseEngine$last_cex$11904 : D
    //   251: aload_0
    //   252: iconst_0
    //   253: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   256: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
    //   261: putfield baseEngine$last_close$11902 : Ljava/lang/invoke/MethodHandle;
    //   264: aload_0
    //   265: iconst_0
    //   266: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   269: putfield baseEngine$last_dd$11900 : Lorg/renjin/gcc/runtime/Ptr;
    //   272: aload_0
    //   273: iconst_0
    //   274: putfield baseEngine$last_dd$11900$offset : I
    //   277: aload_0
    //   278: iconst_0
    //   279: putfield baseEngine$last_ipch$12141 : I
    //   282: aload_0
    //   283: iconst_0
    //   284: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   287: invokeinterface getArray : ()Ljava/lang/Object;
    //   292: checkcast org/renjin/sexp/SEXP
    //   295: putfield baseEngine$last_pch$12140 : Lorg/renjin/sexp/SEXP;
    //   298: aload_0
    //   299: bipush #6
    //   301: putfield baseEngine$nlinetype : I
    //   304: ldc_w '0123456789ABCDEF '
    //   307: invokevirtual getBytes : ()[B
    //   310: iconst_0
    //   311: aload_0
    //   312: getfield baseEngine$HexDigits : [B
    //   315: iconst_0
    //   316: bipush #17
    //   318: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   321: bipush #64
    //   323: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   326: astore_1
    //   327: aload_1
    //   328: new org/renjin/gcc/runtime/BytePtr
    //   331: dup
    //   332: ldc_w 'blank '
    //   335: invokevirtual getBytes : ()[B
    //   338: iconst_0
    //   339: invokespecial <init> : ([BI)V
    //   342: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   347: aload_1
    //   348: iconst_1
    //   349: iconst_m1
    //   350: invokeinterface setAlignedInt : (II)V
    //   355: aload_1
    //   356: iconst_2
    //   357: new org/renjin/gcc/runtime/BytePtr
    //   360: dup
    //   361: ldc_w 'solid '
    //   364: invokevirtual getBytes : ()[B
    //   367: iconst_0
    //   368: invokespecial <init> : ([BI)V
    //   371: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   376: aload_1
    //   377: iconst_3
    //   378: iconst_0
    //   379: invokeinterface setAlignedInt : (II)V
    //   384: aload_1
    //   385: iconst_4
    //   386: new org/renjin/gcc/runtime/BytePtr
    //   389: dup
    //   390: ldc_w 'dashed '
    //   393: invokevirtual getBytes : ()[B
    //   396: iconst_0
    //   397: invokespecial <init> : ([BI)V
    //   400: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   405: aload_1
    //   406: iconst_5
    //   407: bipush #68
    //   409: invokeinterface setAlignedInt : (II)V
    //   414: aload_1
    //   415: bipush #6
    //   417: new org/renjin/gcc/runtime/BytePtr
    //   420: dup
    //   421: ldc_w 'dotted '
    //   424: invokevirtual getBytes : ()[B
    //   427: iconst_0
    //   428: invokespecial <init> : ([BI)V
    //   431: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   436: aload_1
    //   437: bipush #7
    //   439: bipush #49
    //   441: invokeinterface setAlignedInt : (II)V
    //   446: aload_1
    //   447: bipush #8
    //   449: new org/renjin/gcc/runtime/BytePtr
    //   452: dup
    //   453: ldc_w 'dotdash '
    //   456: invokevirtual getBytes : ()[B
    //   459: iconst_0
    //   460: invokespecial <init> : ([BI)V
    //   463: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   468: aload_1
    //   469: bipush #9
    //   471: sipush #13361
    //   474: invokeinterface setAlignedInt : (II)V
    //   479: aload_1
    //   480: bipush #10
    //   482: new org/renjin/gcc/runtime/BytePtr
    //   485: dup
    //   486: ldc_w 'longdash '
    //   489: invokevirtual getBytes : ()[B
    //   492: iconst_0
    //   493: invokespecial <init> : ([BI)V
    //   496: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   501: aload_1
    //   502: bipush #11
    //   504: bipush #55
    //   506: invokeinterface setAlignedInt : (II)V
    //   511: aload_1
    //   512: bipush #12
    //   514: new org/renjin/gcc/runtime/BytePtr
    //   517: dup
    //   518: ldc_w 'twodash '
    //   521: invokevirtual getBytes : ()[B
    //   524: iconst_0
    //   525: invokespecial <init> : ([BI)V
    //   528: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   533: aload_1
    //   534: bipush #13
    //   536: sipush #9762
    //   539: invokeinterface setAlignedInt : (II)V
    //   544: aload_1
    //   545: bipush #14
    //   547: iconst_0
    //   548: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   551: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   556: aload_1
    //   557: bipush #15
    //   559: iconst_0
    //   560: invokeinterface setAlignedInt : (II)V
    //   565: aload_0
    //   566: getfield baseEngine$linetype : Lorg/renjin/gcc/runtime/Ptr;
    //   569: aload_1
    //   570: bipush #64
    //   572: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   577: aload_0
    //   578: iconst_0
    //   579: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   582: putfield baseEngine$ypoints : Lorg/renjin/gcc/runtime/Ptr;
    //   585: aload_0
    //   586: iconst_0
    //   587: putfield baseEngine$ypoints$offset : I
    //   590: aload_0
    //   591: iconst_0
    //   592: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   595: putfield baseEngine$xpoints : Lorg/renjin/gcc/runtime/Ptr;
    //   598: aload_0
    //   599: iconst_0
    //   600: putfield baseEngine$xpoints$offset : I
    //   603: bipush #108
    //   605: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   608: astore_2
    //   609: aload_2
    //   610: new org/renjin/gcc/runtime/BytePtr
    //   613: dup
    //   614: ldc_w 'HersheySerif '
    //   617: invokevirtual getBytes : ()[B
    //   620: iconst_0
    //   621: invokespecial <init> : ([BI)V
    //   624: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   629: aload_2
    //   630: iconst_1
    //   631: iconst_1
    //   632: invokeinterface setAlignedInt : (II)V
    //   637: aload_2
    //   638: iconst_2
    //   639: bipush #7
    //   641: invokeinterface setAlignedInt : (II)V
    //   646: aload_2
    //   647: iconst_3
    //   648: new org/renjin/gcc/runtime/BytePtr
    //   651: dup
    //   652: ldc_w 'HersheySans '
    //   655: invokevirtual getBytes : ()[B
    //   658: iconst_0
    //   659: invokespecial <init> : ([BI)V
    //   662: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   667: aload_2
    //   668: iconst_4
    //   669: iconst_1
    //   670: invokeinterface setAlignedInt : (II)V
    //   675: aload_2
    //   676: iconst_5
    //   677: iconst_4
    //   678: invokeinterface setAlignedInt : (II)V
    //   683: aload_2
    //   684: bipush #6
    //   686: new org/renjin/gcc/runtime/BytePtr
    //   689: dup
    //   690: ldc_w 'HersheyScript '
    //   693: invokevirtual getBytes : ()[B
    //   696: iconst_0
    //   697: invokespecial <init> : ([BI)V
    //   700: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   705: aload_2
    //   706: bipush #7
    //   708: iconst_1
    //   709: invokeinterface setAlignedInt : (II)V
    //   714: aload_2
    //   715: bipush #8
    //   717: iconst_4
    //   718: invokeinterface setAlignedInt : (II)V
    //   723: aload_2
    //   724: bipush #9
    //   726: new org/renjin/gcc/runtime/BytePtr
    //   729: dup
    //   730: ldc_w 'HersheyGothicEnglish '
    //   733: invokevirtual getBytes : ()[B
    //   736: iconst_0
    //   737: invokespecial <init> : ([BI)V
    //   740: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   745: aload_2
    //   746: bipush #10
    //   748: iconst_1
    //   749: invokeinterface setAlignedInt : (II)V
    //   754: aload_2
    //   755: bipush #11
    //   757: iconst_1
    //   758: invokeinterface setAlignedInt : (II)V
    //   763: aload_2
    //   764: bipush #12
    //   766: new org/renjin/gcc/runtime/BytePtr
    //   769: dup
    //   770: ldc_w 'HersheyGothicGerman '
    //   773: invokevirtual getBytes : ()[B
    //   776: iconst_0
    //   777: invokespecial <init> : ([BI)V
    //   780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   785: aload_2
    //   786: bipush #13
    //   788: iconst_1
    //   789: invokeinterface setAlignedInt : (II)V
    //   794: aload_2
    //   795: bipush #14
    //   797: iconst_1
    //   798: invokeinterface setAlignedInt : (II)V
    //   803: aload_2
    //   804: bipush #15
    //   806: new org/renjin/gcc/runtime/BytePtr
    //   809: dup
    //   810: ldc_w 'HersheyGothicItalian '
    //   813: invokevirtual getBytes : ()[B
    //   816: iconst_0
    //   817: invokespecial <init> : ([BI)V
    //   820: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   825: aload_2
    //   826: bipush #16
    //   828: iconst_1
    //   829: invokeinterface setAlignedInt : (II)V
    //   834: aload_2
    //   835: bipush #17
    //   837: iconst_1
    //   838: invokeinterface setAlignedInt : (II)V
    //   843: aload_2
    //   844: bipush #18
    //   846: new org/renjin/gcc/runtime/BytePtr
    //   849: dup
    //   850: ldc_w 'HersheySymbol '
    //   853: invokevirtual getBytes : ()[B
    //   856: iconst_0
    //   857: invokespecial <init> : ([BI)V
    //   860: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   865: aload_2
    //   866: bipush #19
    //   868: iconst_1
    //   869: invokeinterface setAlignedInt : (II)V
    //   874: aload_2
    //   875: bipush #20
    //   877: iconst_4
    //   878: invokeinterface setAlignedInt : (II)V
    //   883: aload_2
    //   884: bipush #21
    //   886: new org/renjin/gcc/runtime/BytePtr
    //   889: dup
    //   890: ldc_w 'HersheySansSymbol '
    //   893: invokevirtual getBytes : ()[B
    //   896: iconst_0
    //   897: invokespecial <init> : ([BI)V
    //   900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   905: aload_2
    //   906: bipush #22
    //   908: iconst_1
    //   909: invokeinterface setAlignedInt : (II)V
    //   914: aload_2
    //   915: bipush #23
    //   917: iconst_2
    //   918: invokeinterface setAlignedInt : (II)V
    //   923: aload_2
    //   924: bipush #24
    //   926: iconst_0
    //   927: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   930: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   935: aload_2
    //   936: bipush #25
    //   938: iconst_0
    //   939: invokeinterface setAlignedInt : (II)V
    //   944: aload_2
    //   945: bipush #26
    //   947: iconst_0
    //   948: invokeinterface setAlignedInt : (II)V
    //   953: aload_0
    //   954: getfield baseEngine$VFontTable : Lorg/renjin/gcc/runtime/Ptr;
    //   957: aload_2
    //   958: bipush #108
    //   960: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   965: aload_0
    //   966: iconst_2
    //   967: putfield baseEngine$nlinejoin : I
    //   970: bipush #32
    //   972: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   975: astore_3
    //   976: aload_3
    //   977: new org/renjin/gcc/runtime/BytePtr
    //   980: dup
    //   981: ldc_w 'round '
    //   984: invokevirtual getBytes : ()[B
    //   987: iconst_0
    //   988: invokespecial <init> : ([BI)V
    //   991: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   996: aload_3
    //   997: iconst_1
    //   998: iconst_1
    //   999: invokeinterface setAlignedInt : (II)V
    //   1004: aload_3
    //   1005: iconst_2
    //   1006: new org/renjin/gcc/runtime/BytePtr
    //   1009: dup
    //   1010: ldc_w 'mitre '
    //   1013: invokevirtual getBytes : ()[B
    //   1016: iconst_0
    //   1017: invokespecial <init> : ([BI)V
    //   1020: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1025: aload_3
    //   1026: iconst_3
    //   1027: iconst_2
    //   1028: invokeinterface setAlignedInt : (II)V
    //   1033: aload_3
    //   1034: iconst_4
    //   1035: new org/renjin/gcc/runtime/BytePtr
    //   1038: dup
    //   1039: ldc_w 'bevel '
    //   1042: invokevirtual getBytes : ()[B
    //   1045: iconst_0
    //   1046: invokespecial <init> : ([BI)V
    //   1049: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1054: aload_3
    //   1055: iconst_5
    //   1056: iconst_3
    //   1057: invokeinterface setAlignedInt : (II)V
    //   1062: aload_3
    //   1063: bipush #6
    //   1065: iconst_0
    //   1066: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1069: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1074: aload_3
    //   1075: bipush #7
    //   1077: iconst_0
    //   1078: invokeinterface setAlignedInt : (II)V
    //   1083: aload_0
    //   1084: getfield baseEngine$linejoin : Lorg/renjin/gcc/runtime/Ptr;
    //   1087: aload_3
    //   1088: bipush #32
    //   1090: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1095: aload_0
    //   1096: iconst_2
    //   1097: putfield baseEngine$nlineend : I
    //   1100: bipush #32
    //   1102: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   1105: astore #4
    //   1107: aload #4
    //   1109: new org/renjin/gcc/runtime/BytePtr
    //   1112: dup
    //   1113: ldc_w 'round '
    //   1116: invokevirtual getBytes : ()[B
    //   1119: iconst_0
    //   1120: invokespecial <init> : ([BI)V
    //   1123: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   1128: aload #4
    //   1130: iconst_1
    //   1131: iconst_1
    //   1132: invokeinterface setAlignedInt : (II)V
    //   1137: aload #4
    //   1139: iconst_2
    //   1140: new org/renjin/gcc/runtime/BytePtr
    //   1143: dup
    //   1144: ldc_w 'butt '
    //   1147: invokevirtual getBytes : ()[B
    //   1150: iconst_0
    //   1151: invokespecial <init> : ([BI)V
    //   1154: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1159: aload #4
    //   1161: iconst_3
    //   1162: iconst_2
    //   1163: invokeinterface setAlignedInt : (II)V
    //   1168: aload #4
    //   1170: iconst_4
    //   1171: new org/renjin/gcc/runtime/BytePtr
    //   1174: dup
    //   1175: ldc_w 'square '
    //   1178: invokevirtual getBytes : ()[B
    //   1181: iconst_0
    //   1182: invokespecial <init> : ([BI)V
    //   1185: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1190: aload #4
    //   1192: iconst_5
    //   1193: iconst_3
    //   1194: invokeinterface setAlignedInt : (II)V
    //   1199: aload #4
    //   1201: bipush #6
    //   1203: iconst_0
    //   1204: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1212: aload #4
    //   1214: bipush #7
    //   1216: iconst_0
    //   1217: invokeinterface setAlignedInt : (II)V
    //   1222: aload_0
    //   1223: getfield baseEngine$lineend : Lorg/renjin/gcc/runtime/Ptr;
    //   1226: aload #4
    //   1228: bipush #32
    //   1230: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   1235: aload_0
    //   1236: iconst_0
    //   1237: putfield baseEngine$numGraphicsSystems : I
    //   1240: aload_0
    //   1241: iconst_0
    //   1242: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   1245: invokeinterface toMethodHandle : ()Ljava/lang/invoke/MethodHandle;
    //   1250: putfield colors$ptr_savePalette : Ljava/lang/invoke/MethodHandle;
    //   1253: sipush #7896
    //   1256: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   1259: astore #5
    //   1261: aload #5
    //   1263: new org/renjin/gcc/runtime/BytePtr
    //   1266: dup
    //   1267: ldc_w 'white '
    //   1270: invokevirtual getBytes : ()[B
    //   1273: iconst_0
    //   1274: invokespecial <init> : ([BI)V
    //   1277: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   1282: aload #5
    //   1284: iconst_1
    //   1285: new org/renjin/gcc/runtime/BytePtr
    //   1288: dup
    //   1289: ldc_w '#FFFFFF '
    //   1292: invokevirtual getBytes : ()[B
    //   1295: iconst_0
    //   1296: invokespecial <init> : ([BI)V
    //   1299: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1304: aload #5
    //   1306: iconst_2
    //   1307: iconst_m1
    //   1308: invokeinterface setAlignedInt : (II)V
    //   1313: aload #5
    //   1315: iconst_3
    //   1316: new org/renjin/gcc/runtime/BytePtr
    //   1319: dup
    //   1320: ldc_w 'aliceblue '
    //   1323: invokevirtual getBytes : ()[B
    //   1326: iconst_0
    //   1327: invokespecial <init> : ([BI)V
    //   1330: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1335: aload #5
    //   1337: iconst_4
    //   1338: new org/renjin/gcc/runtime/BytePtr
    //   1341: dup
    //   1342: ldc_w '#F0F8FF '
    //   1345: invokevirtual getBytes : ()[B
    //   1348: iconst_0
    //   1349: invokespecial <init> : ([BI)V
    //   1352: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1357: aload #5
    //   1359: iconst_5
    //   1360: sipush #-1808
    //   1363: invokeinterface setAlignedInt : (II)V
    //   1368: aload #5
    //   1370: bipush #6
    //   1372: new org/renjin/gcc/runtime/BytePtr
    //   1375: dup
    //   1376: ldc_w 'antiquewhite '
    //   1379: invokevirtual getBytes : ()[B
    //   1382: iconst_0
    //   1383: invokespecial <init> : ([BI)V
    //   1386: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1391: aload #5
    //   1393: bipush #7
    //   1395: new org/renjin/gcc/runtime/BytePtr
    //   1398: dup
    //   1399: ldc_w '#FAEBD7 '
    //   1402: invokevirtual getBytes : ()[B
    //   1405: iconst_0
    //   1406: invokespecial <init> : ([BI)V
    //   1409: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1414: aload #5
    //   1416: bipush #8
    //   1418: ldc_w -2626566
    //   1421: invokeinterface setAlignedInt : (II)V
    //   1426: aload #5
    //   1428: bipush #9
    //   1430: new org/renjin/gcc/runtime/BytePtr
    //   1433: dup
    //   1434: ldc_w 'antiquewhite1 '
    //   1437: invokevirtual getBytes : ()[B
    //   1440: iconst_0
    //   1441: invokespecial <init> : ([BI)V
    //   1444: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1449: aload #5
    //   1451: bipush #10
    //   1453: new org/renjin/gcc/runtime/BytePtr
    //   1456: dup
    //   1457: ldc_w '#FFEFDB '
    //   1460: invokevirtual getBytes : ()[B
    //   1463: iconst_0
    //   1464: invokespecial <init> : ([BI)V
    //   1467: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1472: aload #5
    //   1474: bipush #11
    //   1476: ldc_w -2363393
    //   1479: invokeinterface setAlignedInt : (II)V
    //   1484: aload #5
    //   1486: bipush #12
    //   1488: new org/renjin/gcc/runtime/BytePtr
    //   1491: dup
    //   1492: ldc_w 'antiquewhite2 '
    //   1495: invokevirtual getBytes : ()[B
    //   1498: iconst_0
    //   1499: invokespecial <init> : ([BI)V
    //   1502: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1507: aload #5
    //   1509: bipush #13
    //   1511: new org/renjin/gcc/runtime/BytePtr
    //   1514: dup
    //   1515: ldc_w '#EEDFCC '
    //   1518: invokevirtual getBytes : ()[B
    //   1521: iconst_0
    //   1522: invokespecial <init> : ([BI)V
    //   1525: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1530: aload #5
    //   1532: bipush #14
    //   1534: ldc_w -3350546
    //   1537: invokeinterface setAlignedInt : (II)V
    //   1542: aload #5
    //   1544: bipush #15
    //   1546: new org/renjin/gcc/runtime/BytePtr
    //   1549: dup
    //   1550: ldc_w 'antiquewhite3 '
    //   1553: invokevirtual getBytes : ()[B
    //   1556: iconst_0
    //   1557: invokespecial <init> : ([BI)V
    //   1560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1565: aload #5
    //   1567: bipush #16
    //   1569: new org/renjin/gcc/runtime/BytePtr
    //   1572: dup
    //   1573: ldc_w '#CDC0B0 '
    //   1576: invokevirtual getBytes : ()[B
    //   1579: iconst_0
    //   1580: invokespecial <init> : ([BI)V
    //   1583: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1588: aload #5
    //   1590: bipush #17
    //   1592: ldc_w -5193523
    //   1595: invokeinterface setAlignedInt : (II)V
    //   1600: aload #5
    //   1602: bipush #18
    //   1604: new org/renjin/gcc/runtime/BytePtr
    //   1607: dup
    //   1608: ldc_w 'antiquewhite4 '
    //   1611: invokevirtual getBytes : ()[B
    //   1614: iconst_0
    //   1615: invokespecial <init> : ([BI)V
    //   1618: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1623: aload #5
    //   1625: bipush #19
    //   1627: new org/renjin/gcc/runtime/BytePtr
    //   1630: dup
    //   1631: ldc_w '#8B8378 '
    //   1634: invokevirtual getBytes : ()[B
    //   1637: iconst_0
    //   1638: invokespecial <init> : ([BI)V
    //   1641: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1646: aload #5
    //   1648: bipush #20
    //   1650: ldc_w -8879221
    //   1653: invokeinterface setAlignedInt : (II)V
    //   1658: aload #5
    //   1660: bipush #21
    //   1662: new org/renjin/gcc/runtime/BytePtr
    //   1665: dup
    //   1666: ldc_w 'aquamarine '
    //   1669: invokevirtual getBytes : ()[B
    //   1672: iconst_0
    //   1673: invokespecial <init> : ([BI)V
    //   1676: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1681: aload #5
    //   1683: bipush #22
    //   1685: new org/renjin/gcc/runtime/BytePtr
    //   1688: dup
    //   1689: ldc_w '#7FFFD4 '
    //   1692: invokevirtual getBytes : ()[B
    //   1695: iconst_0
    //   1696: invokespecial <init> : ([BI)V
    //   1699: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1704: aload #5
    //   1706: bipush #23
    //   1708: ldc_w -2818177
    //   1711: invokeinterface setAlignedInt : (II)V
    //   1716: aload #5
    //   1718: bipush #24
    //   1720: new org/renjin/gcc/runtime/BytePtr
    //   1723: dup
    //   1724: ldc_w 'aquamarine1 '
    //   1727: invokevirtual getBytes : ()[B
    //   1730: iconst_0
    //   1731: invokespecial <init> : ([BI)V
    //   1734: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1739: aload #5
    //   1741: bipush #25
    //   1743: new org/renjin/gcc/runtime/BytePtr
    //   1746: dup
    //   1747: ldc_w '#7FFFD4 '
    //   1750: invokevirtual getBytes : ()[B
    //   1753: iconst_0
    //   1754: invokespecial <init> : ([BI)V
    //   1757: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1762: aload #5
    //   1764: bipush #26
    //   1766: ldc_w -2818177
    //   1769: invokeinterface setAlignedInt : (II)V
    //   1774: aload #5
    //   1776: bipush #27
    //   1778: new org/renjin/gcc/runtime/BytePtr
    //   1781: dup
    //   1782: ldc_w 'aquamarine2 '
    //   1785: invokevirtual getBytes : ()[B
    //   1788: iconst_0
    //   1789: invokespecial <init> : ([BI)V
    //   1792: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1797: aload #5
    //   1799: bipush #28
    //   1801: new org/renjin/gcc/runtime/BytePtr
    //   1804: dup
    //   1805: ldc_w '#76EEC6 '
    //   1808: invokevirtual getBytes : ()[B
    //   1811: iconst_0
    //   1812: invokespecial <init> : ([BI)V
    //   1815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1820: aload #5
    //   1822: bipush #29
    //   1824: ldc_w -3740042
    //   1827: invokeinterface setAlignedInt : (II)V
    //   1832: aload #5
    //   1834: bipush #30
    //   1836: new org/renjin/gcc/runtime/BytePtr
    //   1839: dup
    //   1840: ldc_w 'aquamarine3 '
    //   1843: invokevirtual getBytes : ()[B
    //   1846: iconst_0
    //   1847: invokespecial <init> : ([BI)V
    //   1850: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1855: aload #5
    //   1857: bipush #31
    //   1859: new org/renjin/gcc/runtime/BytePtr
    //   1862: dup
    //   1863: ldc_w '#66CDAA '
    //   1866: invokevirtual getBytes : ()[B
    //   1869: iconst_0
    //   1870: invokespecial <init> : ([BI)V
    //   1873: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1878: aload #5
    //   1880: bipush #32
    //   1882: ldc_w -5583514
    //   1885: invokeinterface setAlignedInt : (II)V
    //   1890: aload #5
    //   1892: bipush #33
    //   1894: new org/renjin/gcc/runtime/BytePtr
    //   1897: dup
    //   1898: ldc_w 'aquamarine4 '
    //   1901: invokevirtual getBytes : ()[B
    //   1904: iconst_0
    //   1905: invokespecial <init> : ([BI)V
    //   1908: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1913: aload #5
    //   1915: bipush #34
    //   1917: new org/renjin/gcc/runtime/BytePtr
    //   1920: dup
    //   1921: ldc_w '#458B74 '
    //   1924: invokevirtual getBytes : ()[B
    //   1927: iconst_0
    //   1928: invokespecial <init> : ([BI)V
    //   1931: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1936: aload #5
    //   1938: bipush #35
    //   1940: ldc_w -9139387
    //   1943: invokeinterface setAlignedInt : (II)V
    //   1948: aload #5
    //   1950: bipush #36
    //   1952: new org/renjin/gcc/runtime/BytePtr
    //   1955: dup
    //   1956: ldc_w 'azure '
    //   1959: invokevirtual getBytes : ()[B
    //   1962: iconst_0
    //   1963: invokespecial <init> : ([BI)V
    //   1966: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1971: aload #5
    //   1973: bipush #37
    //   1975: new org/renjin/gcc/runtime/BytePtr
    //   1978: dup
    //   1979: ldc_w '#F0FFFF '
    //   1982: invokevirtual getBytes : ()[B
    //   1985: iconst_0
    //   1986: invokespecial <init> : ([BI)V
    //   1989: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   1994: aload #5
    //   1996: bipush #38
    //   1998: bipush #-16
    //   2000: invokeinterface setAlignedInt : (II)V
    //   2005: aload #5
    //   2007: bipush #39
    //   2009: new org/renjin/gcc/runtime/BytePtr
    //   2012: dup
    //   2013: ldc_w 'azure1 '
    //   2016: invokevirtual getBytes : ()[B
    //   2019: iconst_0
    //   2020: invokespecial <init> : ([BI)V
    //   2023: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2028: aload #5
    //   2030: bipush #40
    //   2032: new org/renjin/gcc/runtime/BytePtr
    //   2035: dup
    //   2036: ldc_w '#F0FFFF '
    //   2039: invokevirtual getBytes : ()[B
    //   2042: iconst_0
    //   2043: invokespecial <init> : ([BI)V
    //   2046: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2051: aload #5
    //   2053: bipush #41
    //   2055: bipush #-16
    //   2057: invokeinterface setAlignedInt : (II)V
    //   2062: aload #5
    //   2064: bipush #42
    //   2066: new org/renjin/gcc/runtime/BytePtr
    //   2069: dup
    //   2070: ldc_w 'azure2 '
    //   2073: invokevirtual getBytes : ()[B
    //   2076: iconst_0
    //   2077: invokespecial <init> : ([BI)V
    //   2080: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2085: aload #5
    //   2087: bipush #43
    //   2089: new org/renjin/gcc/runtime/BytePtr
    //   2092: dup
    //   2093: ldc_w '#E0EEEE '
    //   2096: invokevirtual getBytes : ()[B
    //   2099: iconst_0
    //   2100: invokespecial <init> : ([BI)V
    //   2103: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2108: aload #5
    //   2110: bipush #44
    //   2112: ldc_w -1118496
    //   2115: invokeinterface setAlignedInt : (II)V
    //   2120: aload #5
    //   2122: bipush #45
    //   2124: new org/renjin/gcc/runtime/BytePtr
    //   2127: dup
    //   2128: ldc_w 'azure3 '
    //   2131: invokevirtual getBytes : ()[B
    //   2134: iconst_0
    //   2135: invokespecial <init> : ([BI)V
    //   2138: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2143: aload #5
    //   2145: bipush #46
    //   2147: new org/renjin/gcc/runtime/BytePtr
    //   2150: dup
    //   2151: ldc_w '#C1CDCD '
    //   2154: invokevirtual getBytes : ()[B
    //   2157: iconst_0
    //   2158: invokespecial <init> : ([BI)V
    //   2161: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2166: aload #5
    //   2168: bipush #47
    //   2170: ldc_w -3289663
    //   2173: invokeinterface setAlignedInt : (II)V
    //   2178: aload #5
    //   2180: bipush #48
    //   2182: new org/renjin/gcc/runtime/BytePtr
    //   2185: dup
    //   2186: ldc_w 'azure4 '
    //   2189: invokevirtual getBytes : ()[B
    //   2192: iconst_0
    //   2193: invokespecial <init> : ([BI)V
    //   2196: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2201: aload #5
    //   2203: bipush #49
    //   2205: new org/renjin/gcc/runtime/BytePtr
    //   2208: dup
    //   2209: ldc_w '#838B8B '
    //   2212: invokevirtual getBytes : ()[B
    //   2215: iconst_0
    //   2216: invokespecial <init> : ([BI)V
    //   2219: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2224: aload #5
    //   2226: bipush #50
    //   2228: ldc_w -7631997
    //   2231: invokeinterface setAlignedInt : (II)V
    //   2236: aload #5
    //   2238: bipush #51
    //   2240: new org/renjin/gcc/runtime/BytePtr
    //   2243: dup
    //   2244: ldc_w 'beige '
    //   2247: invokevirtual getBytes : ()[B
    //   2250: iconst_0
    //   2251: invokespecial <init> : ([BI)V
    //   2254: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2259: aload #5
    //   2261: bipush #52
    //   2263: new org/renjin/gcc/runtime/BytePtr
    //   2266: dup
    //   2267: ldc_w '#F5F5DC '
    //   2270: invokevirtual getBytes : ()[B
    //   2273: iconst_0
    //   2274: invokespecial <init> : ([BI)V
    //   2277: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2282: aload #5
    //   2284: bipush #53
    //   2286: ldc_w -2296331
    //   2289: invokeinterface setAlignedInt : (II)V
    //   2294: aload #5
    //   2296: bipush #54
    //   2298: new org/renjin/gcc/runtime/BytePtr
    //   2301: dup
    //   2302: ldc_w 'bisque '
    //   2305: invokevirtual getBytes : ()[B
    //   2308: iconst_0
    //   2309: invokespecial <init> : ([BI)V
    //   2312: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2317: aload #5
    //   2319: bipush #55
    //   2321: new org/renjin/gcc/runtime/BytePtr
    //   2324: dup
    //   2325: ldc_w '#FFE4C4 '
    //   2328: invokevirtual getBytes : ()[B
    //   2331: iconst_0
    //   2332: invokespecial <init> : ([BI)V
    //   2335: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2340: aload #5
    //   2342: bipush #56
    //   2344: ldc_w -3873537
    //   2347: invokeinterface setAlignedInt : (II)V
    //   2352: aload #5
    //   2354: bipush #57
    //   2356: new org/renjin/gcc/runtime/BytePtr
    //   2359: dup
    //   2360: ldc_w 'bisque1 '
    //   2363: invokevirtual getBytes : ()[B
    //   2366: iconst_0
    //   2367: invokespecial <init> : ([BI)V
    //   2370: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2375: aload #5
    //   2377: bipush #58
    //   2379: new org/renjin/gcc/runtime/BytePtr
    //   2382: dup
    //   2383: ldc_w '#FFE4C4 '
    //   2386: invokevirtual getBytes : ()[B
    //   2389: iconst_0
    //   2390: invokespecial <init> : ([BI)V
    //   2393: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2398: aload #5
    //   2400: bipush #59
    //   2402: ldc_w -3873537
    //   2405: invokeinterface setAlignedInt : (II)V
    //   2410: aload #5
    //   2412: bipush #60
    //   2414: new org/renjin/gcc/runtime/BytePtr
    //   2417: dup
    //   2418: ldc_w 'bisque2 '
    //   2421: invokevirtual getBytes : ()[B
    //   2424: iconst_0
    //   2425: invokespecial <init> : ([BI)V
    //   2428: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2433: aload #5
    //   2435: bipush #61
    //   2437: new org/renjin/gcc/runtime/BytePtr
    //   2440: dup
    //   2441: ldc_w '#EED5B7 '
    //   2444: invokevirtual getBytes : ()[B
    //   2447: iconst_0
    //   2448: invokespecial <init> : ([BI)V
    //   2451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2456: aload #5
    //   2458: bipush #62
    //   2460: ldc_w -4729362
    //   2463: invokeinterface setAlignedInt : (II)V
    //   2468: aload #5
    //   2470: bipush #63
    //   2472: new org/renjin/gcc/runtime/BytePtr
    //   2475: dup
    //   2476: ldc_w 'bisque3 '
    //   2479: invokevirtual getBytes : ()[B
    //   2482: iconst_0
    //   2483: invokespecial <init> : ([BI)V
    //   2486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2491: aload #5
    //   2493: bipush #64
    //   2495: new org/renjin/gcc/runtime/BytePtr
    //   2498: dup
    //   2499: ldc_w '#CDB79E '
    //   2502: invokevirtual getBytes : ()[B
    //   2505: iconst_0
    //   2506: invokespecial <init> : ([BI)V
    //   2509: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2514: aload #5
    //   2516: bipush #65
    //   2518: ldc_w -6375475
    //   2521: invokeinterface setAlignedInt : (II)V
    //   2526: aload #5
    //   2528: bipush #66
    //   2530: new org/renjin/gcc/runtime/BytePtr
    //   2533: dup
    //   2534: ldc_w 'bisque4 '
    //   2537: invokevirtual getBytes : ()[B
    //   2540: iconst_0
    //   2541: invokespecial <init> : ([BI)V
    //   2544: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2549: aload #5
    //   2551: bipush #67
    //   2553: new org/renjin/gcc/runtime/BytePtr
    //   2556: dup
    //   2557: ldc_w '#8B7D6B '
    //   2560: invokevirtual getBytes : ()[B
    //   2563: iconst_0
    //   2564: invokespecial <init> : ([BI)V
    //   2567: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2572: aload #5
    //   2574: bipush #68
    //   2576: ldc_w -9732725
    //   2579: invokeinterface setAlignedInt : (II)V
    //   2584: aload #5
    //   2586: bipush #69
    //   2588: new org/renjin/gcc/runtime/BytePtr
    //   2591: dup
    //   2592: ldc_w 'black '
    //   2595: invokevirtual getBytes : ()[B
    //   2598: iconst_0
    //   2599: invokespecial <init> : ([BI)V
    //   2602: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2607: aload #5
    //   2609: bipush #70
    //   2611: new org/renjin/gcc/runtime/BytePtr
    //   2614: dup
    //   2615: ldc_w '#000000 '
    //   2618: invokevirtual getBytes : ()[B
    //   2621: iconst_0
    //   2622: invokespecial <init> : ([BI)V
    //   2625: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2630: aload #5
    //   2632: bipush #71
    //   2634: ldc_w -16777216
    //   2637: invokeinterface setAlignedInt : (II)V
    //   2642: aload #5
    //   2644: bipush #72
    //   2646: new org/renjin/gcc/runtime/BytePtr
    //   2649: dup
    //   2650: ldc_w 'blanchedalmond '
    //   2653: invokevirtual getBytes : ()[B
    //   2656: iconst_0
    //   2657: invokespecial <init> : ([BI)V
    //   2660: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2665: aload #5
    //   2667: bipush #73
    //   2669: new org/renjin/gcc/runtime/BytePtr
    //   2672: dup
    //   2673: ldc_w '#FFEBCD '
    //   2676: invokevirtual getBytes : ()[B
    //   2679: iconst_0
    //   2680: invokespecial <init> : ([BI)V
    //   2683: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2688: aload #5
    //   2690: bipush #74
    //   2692: ldc_w -3281921
    //   2695: invokeinterface setAlignedInt : (II)V
    //   2700: aload #5
    //   2702: bipush #75
    //   2704: new org/renjin/gcc/runtime/BytePtr
    //   2707: dup
    //   2708: ldc_w 'blue '
    //   2711: invokevirtual getBytes : ()[B
    //   2714: iconst_0
    //   2715: invokespecial <init> : ([BI)V
    //   2718: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2723: aload #5
    //   2725: bipush #76
    //   2727: new org/renjin/gcc/runtime/BytePtr
    //   2730: dup
    //   2731: ldc_w '#0000FF '
    //   2734: invokevirtual getBytes : ()[B
    //   2737: iconst_0
    //   2738: invokespecial <init> : ([BI)V
    //   2741: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2746: aload #5
    //   2748: bipush #77
    //   2750: ldc_w -65536
    //   2753: invokeinterface setAlignedInt : (II)V
    //   2758: aload #5
    //   2760: bipush #78
    //   2762: new org/renjin/gcc/runtime/BytePtr
    //   2765: dup
    //   2766: ldc_w 'blue1 '
    //   2769: invokevirtual getBytes : ()[B
    //   2772: iconst_0
    //   2773: invokespecial <init> : ([BI)V
    //   2776: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2781: aload #5
    //   2783: bipush #79
    //   2785: new org/renjin/gcc/runtime/BytePtr
    //   2788: dup
    //   2789: ldc_w '#0000FF '
    //   2792: invokevirtual getBytes : ()[B
    //   2795: iconst_0
    //   2796: invokespecial <init> : ([BI)V
    //   2799: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2804: aload #5
    //   2806: bipush #80
    //   2808: ldc_w -65536
    //   2811: invokeinterface setAlignedInt : (II)V
    //   2816: aload #5
    //   2818: bipush #81
    //   2820: new org/renjin/gcc/runtime/BytePtr
    //   2823: dup
    //   2824: ldc_w 'blue2 '
    //   2827: invokevirtual getBytes : ()[B
    //   2830: iconst_0
    //   2831: invokespecial <init> : ([BI)V
    //   2834: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2839: aload #5
    //   2841: bipush #82
    //   2843: new org/renjin/gcc/runtime/BytePtr
    //   2846: dup
    //   2847: ldc_w '#0000EE '
    //   2850: invokevirtual getBytes : ()[B
    //   2853: iconst_0
    //   2854: invokespecial <init> : ([BI)V
    //   2857: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2862: aload #5
    //   2864: bipush #83
    //   2866: ldc_w -1179648
    //   2869: invokeinterface setAlignedInt : (II)V
    //   2874: aload #5
    //   2876: bipush #84
    //   2878: new org/renjin/gcc/runtime/BytePtr
    //   2881: dup
    //   2882: ldc_w 'blue3 '
    //   2885: invokevirtual getBytes : ()[B
    //   2888: iconst_0
    //   2889: invokespecial <init> : ([BI)V
    //   2892: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2897: aload #5
    //   2899: bipush #85
    //   2901: new org/renjin/gcc/runtime/BytePtr
    //   2904: dup
    //   2905: ldc_w '#0000CD '
    //   2908: invokevirtual getBytes : ()[B
    //   2911: iconst_0
    //   2912: invokespecial <init> : ([BI)V
    //   2915: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2920: aload #5
    //   2922: bipush #86
    //   2924: ldc_w -3342336
    //   2927: invokeinterface setAlignedInt : (II)V
    //   2932: aload #5
    //   2934: bipush #87
    //   2936: new org/renjin/gcc/runtime/BytePtr
    //   2939: dup
    //   2940: ldc_w 'blue4 '
    //   2943: invokevirtual getBytes : ()[B
    //   2946: iconst_0
    //   2947: invokespecial <init> : ([BI)V
    //   2950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2955: aload #5
    //   2957: bipush #88
    //   2959: new org/renjin/gcc/runtime/BytePtr
    //   2962: dup
    //   2963: ldc_w '#00008B '
    //   2966: invokevirtual getBytes : ()[B
    //   2969: iconst_0
    //   2970: invokespecial <init> : ([BI)V
    //   2973: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   2978: aload #5
    //   2980: bipush #89
    //   2982: ldc_w -7667712
    //   2985: invokeinterface setAlignedInt : (II)V
    //   2990: aload #5
    //   2992: bipush #90
    //   2994: new org/renjin/gcc/runtime/BytePtr
    //   2997: dup
    //   2998: ldc_w 'blueviolet '
    //   3001: invokevirtual getBytes : ()[B
    //   3004: iconst_0
    //   3005: invokespecial <init> : ([BI)V
    //   3008: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3013: aload #5
    //   3015: bipush #91
    //   3017: new org/renjin/gcc/runtime/BytePtr
    //   3020: dup
    //   3021: ldc_w '#8A2BE2 '
    //   3024: invokevirtual getBytes : ()[B
    //   3027: iconst_0
    //   3028: invokespecial <init> : ([BI)V
    //   3031: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3036: aload #5
    //   3038: bipush #92
    //   3040: ldc_w -1954934
    //   3043: invokeinterface setAlignedInt : (II)V
    //   3048: aload #5
    //   3050: bipush #93
    //   3052: new org/renjin/gcc/runtime/BytePtr
    //   3055: dup
    //   3056: ldc_w 'brown '
    //   3059: invokevirtual getBytes : ()[B
    //   3062: iconst_0
    //   3063: invokespecial <init> : ([BI)V
    //   3066: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3071: aload #5
    //   3073: bipush #94
    //   3075: new org/renjin/gcc/runtime/BytePtr
    //   3078: dup
    //   3079: ldc_w '#A52A2A '
    //   3082: invokevirtual getBytes : ()[B
    //   3085: iconst_0
    //   3086: invokespecial <init> : ([BI)V
    //   3089: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3094: aload #5
    //   3096: bipush #95
    //   3098: ldc_w -14013787
    //   3101: invokeinterface setAlignedInt : (II)V
    //   3106: aload #5
    //   3108: bipush #96
    //   3110: new org/renjin/gcc/runtime/BytePtr
    //   3113: dup
    //   3114: ldc_w 'brown1 '
    //   3117: invokevirtual getBytes : ()[B
    //   3120: iconst_0
    //   3121: invokespecial <init> : ([BI)V
    //   3124: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3129: aload #5
    //   3131: bipush #97
    //   3133: new org/renjin/gcc/runtime/BytePtr
    //   3136: dup
    //   3137: ldc_w '#FF4040 '
    //   3140: invokevirtual getBytes : ()[B
    //   3143: iconst_0
    //   3144: invokespecial <init> : ([BI)V
    //   3147: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3152: aload #5
    //   3154: bipush #98
    //   3156: ldc_w -12566273
    //   3159: invokeinterface setAlignedInt : (II)V
    //   3164: aload #5
    //   3166: bipush #99
    //   3168: new org/renjin/gcc/runtime/BytePtr
    //   3171: dup
    //   3172: ldc_w 'brown2 '
    //   3175: invokevirtual getBytes : ()[B
    //   3178: iconst_0
    //   3179: invokespecial <init> : ([BI)V
    //   3182: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3187: aload #5
    //   3189: bipush #100
    //   3191: new org/renjin/gcc/runtime/BytePtr
    //   3194: dup
    //   3195: ldc_w '#EE3B3B '
    //   3198: invokevirtual getBytes : ()[B
    //   3201: iconst_0
    //   3202: invokespecial <init> : ([BI)V
    //   3205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3210: aload #5
    //   3212: bipush #101
    //   3214: ldc_w -12895250
    //   3217: invokeinterface setAlignedInt : (II)V
    //   3222: aload #5
    //   3224: bipush #102
    //   3226: new org/renjin/gcc/runtime/BytePtr
    //   3229: dup
    //   3230: ldc_w 'brown3 '
    //   3233: invokevirtual getBytes : ()[B
    //   3236: iconst_0
    //   3237: invokespecial <init> : ([BI)V
    //   3240: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3245: aload #5
    //   3247: bipush #103
    //   3249: new org/renjin/gcc/runtime/BytePtr
    //   3252: dup
    //   3253: ldc_w '#CD3333 '
    //   3256: invokevirtual getBytes : ()[B
    //   3259: iconst_0
    //   3260: invokespecial <init> : ([BI)V
    //   3263: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3268: aload #5
    //   3270: bipush #104
    //   3272: ldc_w -13421619
    //   3275: invokeinterface setAlignedInt : (II)V
    //   3280: aload #5
    //   3282: bipush #105
    //   3284: new org/renjin/gcc/runtime/BytePtr
    //   3287: dup
    //   3288: ldc_w 'brown4 '
    //   3291: invokevirtual getBytes : ()[B
    //   3294: iconst_0
    //   3295: invokespecial <init> : ([BI)V
    //   3298: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3303: aload #5
    //   3305: bipush #106
    //   3307: new org/renjin/gcc/runtime/BytePtr
    //   3310: dup
    //   3311: ldc_w '#8B2323 '
    //   3314: invokevirtual getBytes : ()[B
    //   3317: iconst_0
    //   3318: invokespecial <init> : ([BI)V
    //   3321: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3326: aload #5
    //   3328: bipush #107
    //   3330: ldc_w -14474357
    //   3333: invokeinterface setAlignedInt : (II)V
    //   3338: aload #5
    //   3340: bipush #108
    //   3342: new org/renjin/gcc/runtime/BytePtr
    //   3345: dup
    //   3346: ldc_w 'burlywood '
    //   3349: invokevirtual getBytes : ()[B
    //   3352: iconst_0
    //   3353: invokespecial <init> : ([BI)V
    //   3356: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3361: aload #5
    //   3363: bipush #109
    //   3365: new org/renjin/gcc/runtime/BytePtr
    //   3368: dup
    //   3369: ldc_w '#DEB887 '
    //   3372: invokevirtual getBytes : ()[B
    //   3375: iconst_0
    //   3376: invokespecial <init> : ([BI)V
    //   3379: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3384: aload #5
    //   3386: bipush #110
    //   3388: ldc_w -7882530
    //   3391: invokeinterface setAlignedInt : (II)V
    //   3396: aload #5
    //   3398: bipush #111
    //   3400: new org/renjin/gcc/runtime/BytePtr
    //   3403: dup
    //   3404: ldc_w 'burlywood1 '
    //   3407: invokevirtual getBytes : ()[B
    //   3410: iconst_0
    //   3411: invokespecial <init> : ([BI)V
    //   3414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3419: aload #5
    //   3421: bipush #112
    //   3423: new org/renjin/gcc/runtime/BytePtr
    //   3426: dup
    //   3427: ldc_w '#FFD39B '
    //   3430: invokevirtual getBytes : ()[B
    //   3433: iconst_0
    //   3434: invokespecial <init> : ([BI)V
    //   3437: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3442: aload #5
    //   3444: bipush #113
    //   3446: ldc_w -6564865
    //   3449: invokeinterface setAlignedInt : (II)V
    //   3454: aload #5
    //   3456: bipush #114
    //   3458: new org/renjin/gcc/runtime/BytePtr
    //   3461: dup
    //   3462: ldc_w 'burlywood2 '
    //   3465: invokevirtual getBytes : ()[B
    //   3468: iconst_0
    //   3469: invokespecial <init> : ([BI)V
    //   3472: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3477: aload #5
    //   3479: bipush #115
    //   3481: new org/renjin/gcc/runtime/BytePtr
    //   3484: dup
    //   3485: ldc_w '#EEC591 '
    //   3488: invokevirtual getBytes : ()[B
    //   3491: iconst_0
    //   3492: invokespecial <init> : ([BI)V
    //   3495: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3500: aload #5
    //   3502: bipush #116
    //   3504: ldc_w -7223826
    //   3507: invokeinterface setAlignedInt : (II)V
    //   3512: aload #5
    //   3514: bipush #117
    //   3516: new org/renjin/gcc/runtime/BytePtr
    //   3519: dup
    //   3520: ldc_w 'burlywood3 '
    //   3523: invokevirtual getBytes : ()[B
    //   3526: iconst_0
    //   3527: invokespecial <init> : ([BI)V
    //   3530: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3535: aload #5
    //   3537: bipush #118
    //   3539: new org/renjin/gcc/runtime/BytePtr
    //   3542: dup
    //   3543: ldc_w '#CDAA7D '
    //   3546: invokevirtual getBytes : ()[B
    //   3549: iconst_0
    //   3550: invokespecial <init> : ([BI)V
    //   3553: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3558: aload #5
    //   3560: bipush #119
    //   3562: ldc_w -8541491
    //   3565: invokeinterface setAlignedInt : (II)V
    //   3570: aload #5
    //   3572: bipush #120
    //   3574: new org/renjin/gcc/runtime/BytePtr
    //   3577: dup
    //   3578: ldc_w 'burlywood4 '
    //   3581: invokevirtual getBytes : ()[B
    //   3584: iconst_0
    //   3585: invokespecial <init> : ([BI)V
    //   3588: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3593: aload #5
    //   3595: bipush #121
    //   3597: new org/renjin/gcc/runtime/BytePtr
    //   3600: dup
    //   3601: ldc_w '#8B7355 '
    //   3604: invokevirtual getBytes : ()[B
    //   3607: iconst_0
    //   3608: invokespecial <init> : ([BI)V
    //   3611: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3616: aload #5
    //   3618: bipush #122
    //   3620: ldc_w -11177077
    //   3623: invokeinterface setAlignedInt : (II)V
    //   3628: aload #5
    //   3630: bipush #123
    //   3632: new org/renjin/gcc/runtime/BytePtr
    //   3635: dup
    //   3636: ldc_w 'cadetblue '
    //   3639: invokevirtual getBytes : ()[B
    //   3642: iconst_0
    //   3643: invokespecial <init> : ([BI)V
    //   3646: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3651: aload #5
    //   3653: bipush #124
    //   3655: new org/renjin/gcc/runtime/BytePtr
    //   3658: dup
    //   3659: ldc_w '#5F9EA0 '
    //   3662: invokevirtual getBytes : ()[B
    //   3665: iconst_0
    //   3666: invokespecial <init> : ([BI)V
    //   3669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3674: aload #5
    //   3676: bipush #125
    //   3678: ldc_w -6250913
    //   3681: invokeinterface setAlignedInt : (II)V
    //   3686: aload #5
    //   3688: bipush #126
    //   3690: new org/renjin/gcc/runtime/BytePtr
    //   3693: dup
    //   3694: ldc_w 'cadetblue1 '
    //   3697: invokevirtual getBytes : ()[B
    //   3700: iconst_0
    //   3701: invokespecial <init> : ([BI)V
    //   3704: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3709: aload #5
    //   3711: bipush #127
    //   3713: new org/renjin/gcc/runtime/BytePtr
    //   3716: dup
    //   3717: ldc_w '#98F5FF '
    //   3720: invokevirtual getBytes : ()[B
    //   3723: iconst_0
    //   3724: invokespecial <init> : ([BI)V
    //   3727: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3732: aload #5
    //   3734: sipush #128
    //   3737: sipush #-2664
    //   3740: invokeinterface setAlignedInt : (II)V
    //   3745: aload #5
    //   3747: sipush #129
    //   3750: new org/renjin/gcc/runtime/BytePtr
    //   3753: dup
    //   3754: ldc_w 'cadetblue2 '
    //   3757: invokevirtual getBytes : ()[B
    //   3760: iconst_0
    //   3761: invokespecial <init> : ([BI)V
    //   3764: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3769: aload #5
    //   3771: sipush #130
    //   3774: new org/renjin/gcc/runtime/BytePtr
    //   3777: dup
    //   3778: ldc_w '#8EE5EE '
    //   3781: invokevirtual getBytes : ()[B
    //   3784: iconst_0
    //   3785: invokespecial <init> : ([BI)V
    //   3788: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3793: aload #5
    //   3795: sipush #131
    //   3798: ldc_w -1120882
    //   3801: invokeinterface setAlignedInt : (II)V
    //   3806: aload #5
    //   3808: sipush #132
    //   3811: new org/renjin/gcc/runtime/BytePtr
    //   3814: dup
    //   3815: ldc_w 'cadetblue3 '
    //   3818: invokevirtual getBytes : ()[B
    //   3821: iconst_0
    //   3822: invokespecial <init> : ([BI)V
    //   3825: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3830: aload #5
    //   3832: sipush #133
    //   3835: new org/renjin/gcc/runtime/BytePtr
    //   3838: dup
    //   3839: ldc_w '#7AC5CD '
    //   3842: invokevirtual getBytes : ()[B
    //   3845: iconst_0
    //   3846: invokespecial <init> : ([BI)V
    //   3849: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3854: aload #5
    //   3856: sipush #134
    //   3859: ldc_w -3291782
    //   3862: invokeinterface setAlignedInt : (II)V
    //   3867: aload #5
    //   3869: sipush #135
    //   3872: new org/renjin/gcc/runtime/BytePtr
    //   3875: dup
    //   3876: ldc_w 'cadetblue4 '
    //   3879: invokevirtual getBytes : ()[B
    //   3882: iconst_0
    //   3883: invokespecial <init> : ([BI)V
    //   3886: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3891: aload #5
    //   3893: sipush #136
    //   3896: new org/renjin/gcc/runtime/BytePtr
    //   3899: dup
    //   3900: ldc_w '#53868B '
    //   3903: invokevirtual getBytes : ()[B
    //   3906: iconst_0
    //   3907: invokespecial <init> : ([BI)V
    //   3910: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3915: aload #5
    //   3917: sipush #137
    //   3920: ldc_w -7633325
    //   3923: invokeinterface setAlignedInt : (II)V
    //   3928: aload #5
    //   3930: sipush #138
    //   3933: new org/renjin/gcc/runtime/BytePtr
    //   3936: dup
    //   3937: ldc_w 'chartreuse '
    //   3940: invokevirtual getBytes : ()[B
    //   3943: iconst_0
    //   3944: invokespecial <init> : ([BI)V
    //   3947: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3952: aload #5
    //   3954: sipush #139
    //   3957: new org/renjin/gcc/runtime/BytePtr
    //   3960: dup
    //   3961: ldc_w '#7FFF00 '
    //   3964: invokevirtual getBytes : ()[B
    //   3967: iconst_0
    //   3968: invokespecial <init> : ([BI)V
    //   3971: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   3976: aload #5
    //   3978: sipush #140
    //   3981: ldc_w -16711809
    //   3984: invokeinterface setAlignedInt : (II)V
    //   3989: aload #5
    //   3991: sipush #141
    //   3994: new org/renjin/gcc/runtime/BytePtr
    //   3997: dup
    //   3998: ldc_w 'chartreuse1 '
    //   4001: invokevirtual getBytes : ()[B
    //   4004: iconst_0
    //   4005: invokespecial <init> : ([BI)V
    //   4008: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4013: aload #5
    //   4015: sipush #142
    //   4018: new org/renjin/gcc/runtime/BytePtr
    //   4021: dup
    //   4022: ldc_w '#7FFF00 '
    //   4025: invokevirtual getBytes : ()[B
    //   4028: iconst_0
    //   4029: invokespecial <init> : ([BI)V
    //   4032: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4037: aload #5
    //   4039: sipush #143
    //   4042: ldc_w -16711809
    //   4045: invokeinterface setAlignedInt : (II)V
    //   4050: aload #5
    //   4052: sipush #144
    //   4055: new org/renjin/gcc/runtime/BytePtr
    //   4058: dup
    //   4059: ldc_w 'chartreuse2 '
    //   4062: invokevirtual getBytes : ()[B
    //   4065: iconst_0
    //   4066: invokespecial <init> : ([BI)V
    //   4069: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4074: aload #5
    //   4076: sipush #145
    //   4079: new org/renjin/gcc/runtime/BytePtr
    //   4082: dup
    //   4083: ldc_w '#76EE00 '
    //   4086: invokevirtual getBytes : ()[B
    //   4089: iconst_0
    //   4090: invokespecial <init> : ([BI)V
    //   4093: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4098: aload #5
    //   4100: sipush #146
    //   4103: ldc_w -16716170
    //   4106: invokeinterface setAlignedInt : (II)V
    //   4111: aload #5
    //   4113: sipush #147
    //   4116: new org/renjin/gcc/runtime/BytePtr
    //   4119: dup
    //   4120: ldc_w 'chartreuse3 '
    //   4123: invokevirtual getBytes : ()[B
    //   4126: iconst_0
    //   4127: invokespecial <init> : ([BI)V
    //   4130: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4135: aload #5
    //   4137: sipush #148
    //   4140: new org/renjin/gcc/runtime/BytePtr
    //   4143: dup
    //   4144: ldc_w '#66CD00 '
    //   4147: invokevirtual getBytes : ()[B
    //   4150: iconst_0
    //   4151: invokespecial <init> : ([BI)V
    //   4154: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4159: aload #5
    //   4161: sipush #149
    //   4164: ldc_w -16724634
    //   4167: invokeinterface setAlignedInt : (II)V
    //   4172: aload #5
    //   4174: sipush #150
    //   4177: new org/renjin/gcc/runtime/BytePtr
    //   4180: dup
    //   4181: ldc_w 'chartreuse4 '
    //   4184: invokevirtual getBytes : ()[B
    //   4187: iconst_0
    //   4188: invokespecial <init> : ([BI)V
    //   4191: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4196: aload #5
    //   4198: sipush #151
    //   4201: new org/renjin/gcc/runtime/BytePtr
    //   4204: dup
    //   4205: ldc_w '#458B00 '
    //   4208: invokevirtual getBytes : ()[B
    //   4211: iconst_0
    //   4212: invokespecial <init> : ([BI)V
    //   4215: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4220: aload #5
    //   4222: sipush #152
    //   4225: ldc_w -16741563
    //   4228: invokeinterface setAlignedInt : (II)V
    //   4233: aload #5
    //   4235: sipush #153
    //   4238: new org/renjin/gcc/runtime/BytePtr
    //   4241: dup
    //   4242: ldc_w 'chocolate '
    //   4245: invokevirtual getBytes : ()[B
    //   4248: iconst_0
    //   4249: invokespecial <init> : ([BI)V
    //   4252: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4257: aload #5
    //   4259: sipush #154
    //   4262: new org/renjin/gcc/runtime/BytePtr
    //   4265: dup
    //   4266: ldc_w '#D2691E '
    //   4269: invokevirtual getBytes : ()[B
    //   4272: iconst_0
    //   4273: invokespecial <init> : ([BI)V
    //   4276: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4281: aload #5
    //   4283: sipush #155
    //   4286: ldc_w -14784046
    //   4289: invokeinterface setAlignedInt : (II)V
    //   4294: aload #5
    //   4296: sipush #156
    //   4299: new org/renjin/gcc/runtime/BytePtr
    //   4302: dup
    //   4303: ldc_w 'chocolate1 '
    //   4306: invokevirtual getBytes : ()[B
    //   4309: iconst_0
    //   4310: invokespecial <init> : ([BI)V
    //   4313: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4318: aload #5
    //   4320: sipush #157
    //   4323: new org/renjin/gcc/runtime/BytePtr
    //   4326: dup
    //   4327: ldc_w '#FF7F24 '
    //   4330: invokevirtual getBytes : ()[B
    //   4333: iconst_0
    //   4334: invokespecial <init> : ([BI)V
    //   4337: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4342: aload #5
    //   4344: sipush #158
    //   4347: ldc_w -14385153
    //   4350: invokeinterface setAlignedInt : (II)V
    //   4355: aload #5
    //   4357: sipush #159
    //   4360: new org/renjin/gcc/runtime/BytePtr
    //   4363: dup
    //   4364: ldc_w 'chocolate2 '
    //   4367: invokevirtual getBytes : ()[B
    //   4370: iconst_0
    //   4371: invokespecial <init> : ([BI)V
    //   4374: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4379: aload #5
    //   4381: sipush #160
    //   4384: new org/renjin/gcc/runtime/BytePtr
    //   4387: dup
    //   4388: ldc_w '#EE7621 '
    //   4391: invokevirtual getBytes : ()[B
    //   4394: iconst_0
    //   4395: invokespecial <init> : ([BI)V
    //   4398: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4403: aload #5
    //   4405: sipush #161
    //   4408: ldc_w -14584082
    //   4411: invokeinterface setAlignedInt : (II)V
    //   4416: aload #5
    //   4418: sipush #162
    //   4421: new org/renjin/gcc/runtime/BytePtr
    //   4424: dup
    //   4425: ldc_w 'chocolate3 '
    //   4428: invokevirtual getBytes : ()[B
    //   4431: iconst_0
    //   4432: invokespecial <init> : ([BI)V
    //   4435: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4440: aload #5
    //   4442: sipush #163
    //   4445: new org/renjin/gcc/runtime/BytePtr
    //   4448: dup
    //   4449: ldc_w '#CD661D '
    //   4452: invokevirtual getBytes : ()[B
    //   4455: iconst_0
    //   4456: invokespecial <init> : ([BI)V
    //   4459: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4464: aload #5
    //   4466: sipush #164
    //   4469: ldc_w -14850355
    //   4472: invokeinterface setAlignedInt : (II)V
    //   4477: aload #5
    //   4479: sipush #165
    //   4482: new org/renjin/gcc/runtime/BytePtr
    //   4485: dup
    //   4486: ldc_w 'chocolate4 '
    //   4489: invokevirtual getBytes : ()[B
    //   4492: iconst_0
    //   4493: invokespecial <init> : ([BI)V
    //   4496: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4501: aload #5
    //   4503: sipush #166
    //   4506: new org/renjin/gcc/runtime/BytePtr
    //   4509: dup
    //   4510: ldc_w '#8B4513 '
    //   4513: invokevirtual getBytes : ()[B
    //   4516: iconst_0
    //   4517: invokespecial <init> : ([BI)V
    //   4520: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4525: aload #5
    //   4527: sipush #167
    //   4530: ldc_w -15514229
    //   4533: invokeinterface setAlignedInt : (II)V
    //   4538: aload #5
    //   4540: sipush #168
    //   4543: new org/renjin/gcc/runtime/BytePtr
    //   4546: dup
    //   4547: ldc_w 'coral '
    //   4550: invokevirtual getBytes : ()[B
    //   4553: iconst_0
    //   4554: invokespecial <init> : ([BI)V
    //   4557: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4562: aload #5
    //   4564: sipush #169
    //   4567: new org/renjin/gcc/runtime/BytePtr
    //   4570: dup
    //   4571: ldc_w '#FF7F50 '
    //   4574: invokevirtual getBytes : ()[B
    //   4577: iconst_0
    //   4578: invokespecial <init> : ([BI)V
    //   4581: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4586: aload #5
    //   4588: sipush #170
    //   4591: ldc_w -11501569
    //   4594: invokeinterface setAlignedInt : (II)V
    //   4599: aload #5
    //   4601: sipush #171
    //   4604: new org/renjin/gcc/runtime/BytePtr
    //   4607: dup
    //   4608: ldc_w 'coral1 '
    //   4611: invokevirtual getBytes : ()[B
    //   4614: iconst_0
    //   4615: invokespecial <init> : ([BI)V
    //   4618: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4623: aload #5
    //   4625: sipush #172
    //   4628: new org/renjin/gcc/runtime/BytePtr
    //   4631: dup
    //   4632: ldc_w '#FF7256 '
    //   4635: invokevirtual getBytes : ()[B
    //   4638: iconst_0
    //   4639: invokespecial <init> : ([BI)V
    //   4642: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4647: aload #5
    //   4649: sipush #173
    //   4652: ldc_w -11111681
    //   4655: invokeinterface setAlignedInt : (II)V
    //   4660: aload #5
    //   4662: sipush #174
    //   4665: new org/renjin/gcc/runtime/BytePtr
    //   4668: dup
    //   4669: ldc_w 'coral2 '
    //   4672: invokevirtual getBytes : ()[B
    //   4675: iconst_0
    //   4676: invokespecial <init> : ([BI)V
    //   4679: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4684: aload #5
    //   4686: sipush #175
    //   4689: new org/renjin/gcc/runtime/BytePtr
    //   4692: dup
    //   4693: ldc_w '#EE6A50 '
    //   4696: invokevirtual getBytes : ()[B
    //   4699: iconst_0
    //   4700: invokespecial <init> : ([BI)V
    //   4703: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4708: aload #5
    //   4710: sipush #176
    //   4713: ldc_w -11506962
    //   4716: invokeinterface setAlignedInt : (II)V
    //   4721: aload #5
    //   4723: sipush #177
    //   4726: new org/renjin/gcc/runtime/BytePtr
    //   4729: dup
    //   4730: ldc_w 'coral3 '
    //   4733: invokevirtual getBytes : ()[B
    //   4736: iconst_0
    //   4737: invokespecial <init> : ([BI)V
    //   4740: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4745: aload #5
    //   4747: sipush #178
    //   4750: new org/renjin/gcc/runtime/BytePtr
    //   4753: dup
    //   4754: ldc_w '#CD5B45 '
    //   4757: invokevirtual getBytes : ()[B
    //   4760: iconst_0
    //   4761: invokespecial <init> : ([BI)V
    //   4764: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4769: aload #5
    //   4771: sipush #179
    //   4774: ldc_w -12231731
    //   4777: invokeinterface setAlignedInt : (II)V
    //   4782: aload #5
    //   4784: sipush #180
    //   4787: new org/renjin/gcc/runtime/BytePtr
    //   4790: dup
    //   4791: ldc_w 'coral4 '
    //   4794: invokevirtual getBytes : ()[B
    //   4797: iconst_0
    //   4798: invokespecial <init> : ([BI)V
    //   4801: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4806: aload #5
    //   4808: sipush #181
    //   4811: new org/renjin/gcc/runtime/BytePtr
    //   4814: dup
    //   4815: ldc_w '#8B3E2F '
    //   4818: invokevirtual getBytes : ()[B
    //   4821: iconst_0
    //   4822: invokespecial <init> : ([BI)V
    //   4825: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4830: aload #5
    //   4832: sipush #182
    //   4835: ldc_w -13681013
    //   4838: invokeinterface setAlignedInt : (II)V
    //   4843: aload #5
    //   4845: sipush #183
    //   4848: new org/renjin/gcc/runtime/BytePtr
    //   4851: dup
    //   4852: ldc_w 'cornflowerblue '
    //   4855: invokevirtual getBytes : ()[B
    //   4858: iconst_0
    //   4859: invokespecial <init> : ([BI)V
    //   4862: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4867: aload #5
    //   4869: sipush #184
    //   4872: new org/renjin/gcc/runtime/BytePtr
    //   4875: dup
    //   4876: ldc_w '#6495ED '
    //   4879: invokevirtual getBytes : ()[B
    //   4882: iconst_0
    //   4883: invokespecial <init> : ([BI)V
    //   4886: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4891: aload #5
    //   4893: sipush #185
    //   4896: ldc_w -1206940
    //   4899: invokeinterface setAlignedInt : (II)V
    //   4904: aload #5
    //   4906: sipush #186
    //   4909: new org/renjin/gcc/runtime/BytePtr
    //   4912: dup
    //   4913: ldc_w 'cornsilk '
    //   4916: invokevirtual getBytes : ()[B
    //   4919: iconst_0
    //   4920: invokespecial <init> : ([BI)V
    //   4923: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4928: aload #5
    //   4930: sipush #187
    //   4933: new org/renjin/gcc/runtime/BytePtr
    //   4936: dup
    //   4937: ldc_w '#FFF8DC '
    //   4940: invokevirtual getBytes : ()[B
    //   4943: iconst_0
    //   4944: invokespecial <init> : ([BI)V
    //   4947: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4952: aload #5
    //   4954: sipush #188
    //   4957: ldc_w -2295553
    //   4960: invokeinterface setAlignedInt : (II)V
    //   4965: aload #5
    //   4967: sipush #189
    //   4970: new org/renjin/gcc/runtime/BytePtr
    //   4973: dup
    //   4974: ldc_w 'cornsilk1 '
    //   4977: invokevirtual getBytes : ()[B
    //   4980: iconst_0
    //   4981: invokespecial <init> : ([BI)V
    //   4984: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   4989: aload #5
    //   4991: sipush #190
    //   4994: new org/renjin/gcc/runtime/BytePtr
    //   4997: dup
    //   4998: ldc_w '#FFF8DC '
    //   5001: invokevirtual getBytes : ()[B
    //   5004: iconst_0
    //   5005: invokespecial <init> : ([BI)V
    //   5008: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5013: aload #5
    //   5015: sipush #191
    //   5018: ldc_w -2295553
    //   5021: invokeinterface setAlignedInt : (II)V
    //   5026: aload #5
    //   5028: sipush #192
    //   5031: new org/renjin/gcc/runtime/BytePtr
    //   5034: dup
    //   5035: ldc_w 'cornsilk2 '
    //   5038: invokevirtual getBytes : ()[B
    //   5041: iconst_0
    //   5042: invokespecial <init> : ([BI)V
    //   5045: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5050: aload #5
    //   5052: sipush #193
    //   5055: new org/renjin/gcc/runtime/BytePtr
    //   5058: dup
    //   5059: ldc_w '#EEE8CD '
    //   5062: invokevirtual getBytes : ()[B
    //   5065: iconst_0
    //   5066: invokespecial <init> : ([BI)V
    //   5069: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5074: aload #5
    //   5076: sipush #194
    //   5079: ldc_w -3282706
    //   5082: invokeinterface setAlignedInt : (II)V
    //   5087: aload #5
    //   5089: sipush #195
    //   5092: new org/renjin/gcc/runtime/BytePtr
    //   5095: dup
    //   5096: ldc_w 'cornsilk3 '
    //   5099: invokevirtual getBytes : ()[B
    //   5102: iconst_0
    //   5103: invokespecial <init> : ([BI)V
    //   5106: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5111: aload #5
    //   5113: sipush #196
    //   5116: new org/renjin/gcc/runtime/BytePtr
    //   5119: dup
    //   5120: ldc_w '#CDC8B1 '
    //   5123: invokevirtual getBytes : ()[B
    //   5126: iconst_0
    //   5127: invokespecial <init> : ([BI)V
    //   5130: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5135: aload #5
    //   5137: sipush #197
    //   5140: ldc_w -5125939
    //   5143: invokeinterface setAlignedInt : (II)V
    //   5148: aload #5
    //   5150: sipush #198
    //   5153: new org/renjin/gcc/runtime/BytePtr
    //   5156: dup
    //   5157: ldc_w 'cornsilk4 '
    //   5160: invokevirtual getBytes : ()[B
    //   5163: iconst_0
    //   5164: invokespecial <init> : ([BI)V
    //   5167: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5172: aload #5
    //   5174: sipush #199
    //   5177: new org/renjin/gcc/runtime/BytePtr
    //   5180: dup
    //   5181: ldc_w '#8B8878 '
    //   5184: invokevirtual getBytes : ()[B
    //   5187: iconst_0
    //   5188: invokespecial <init> : ([BI)V
    //   5191: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5196: aload #5
    //   5198: sipush #200
    //   5201: ldc_w -8877941
    //   5204: invokeinterface setAlignedInt : (II)V
    //   5209: aload #5
    //   5211: sipush #201
    //   5214: new org/renjin/gcc/runtime/BytePtr
    //   5217: dup
    //   5218: ldc_w 'cyan '
    //   5221: invokevirtual getBytes : ()[B
    //   5224: iconst_0
    //   5225: invokespecial <init> : ([BI)V
    //   5228: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5233: aload #5
    //   5235: sipush #202
    //   5238: new org/renjin/gcc/runtime/BytePtr
    //   5241: dup
    //   5242: ldc_w '#00FFFF '
    //   5245: invokevirtual getBytes : ()[B
    //   5248: iconst_0
    //   5249: invokespecial <init> : ([BI)V
    //   5252: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5257: aload #5
    //   5259: sipush #203
    //   5262: sipush #-256
    //   5265: invokeinterface setAlignedInt : (II)V
    //   5270: aload #5
    //   5272: sipush #204
    //   5275: new org/renjin/gcc/runtime/BytePtr
    //   5278: dup
    //   5279: ldc_w 'cyan1 '
    //   5282: invokevirtual getBytes : ()[B
    //   5285: iconst_0
    //   5286: invokespecial <init> : ([BI)V
    //   5289: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5294: aload #5
    //   5296: sipush #205
    //   5299: new org/renjin/gcc/runtime/BytePtr
    //   5302: dup
    //   5303: ldc_w '#00FFFF '
    //   5306: invokevirtual getBytes : ()[B
    //   5309: iconst_0
    //   5310: invokespecial <init> : ([BI)V
    //   5313: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5318: aload #5
    //   5320: sipush #206
    //   5323: sipush #-256
    //   5326: invokeinterface setAlignedInt : (II)V
    //   5331: aload #5
    //   5333: sipush #207
    //   5336: new org/renjin/gcc/runtime/BytePtr
    //   5339: dup
    //   5340: ldc_w 'cyan2 '
    //   5343: invokevirtual getBytes : ()[B
    //   5346: iconst_0
    //   5347: invokespecial <init> : ([BI)V
    //   5350: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5355: aload #5
    //   5357: sipush #208
    //   5360: new org/renjin/gcc/runtime/BytePtr
    //   5363: dup
    //   5364: ldc_w '#00EEEE '
    //   5367: invokevirtual getBytes : ()[B
    //   5370: iconst_0
    //   5371: invokespecial <init> : ([BI)V
    //   5374: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5379: aload #5
    //   5381: sipush #209
    //   5384: ldc_w -1118720
    //   5387: invokeinterface setAlignedInt : (II)V
    //   5392: aload #5
    //   5394: sipush #210
    //   5397: new org/renjin/gcc/runtime/BytePtr
    //   5400: dup
    //   5401: ldc_w 'cyan3 '
    //   5404: invokevirtual getBytes : ()[B
    //   5407: iconst_0
    //   5408: invokespecial <init> : ([BI)V
    //   5411: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5416: aload #5
    //   5418: sipush #211
    //   5421: new org/renjin/gcc/runtime/BytePtr
    //   5424: dup
    //   5425: ldc_w '#00CDCD '
    //   5428: invokevirtual getBytes : ()[B
    //   5431: iconst_0
    //   5432: invokespecial <init> : ([BI)V
    //   5435: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5440: aload #5
    //   5442: sipush #212
    //   5445: ldc_w -3289856
    //   5448: invokeinterface setAlignedInt : (II)V
    //   5453: aload #5
    //   5455: sipush #213
    //   5458: new org/renjin/gcc/runtime/BytePtr
    //   5461: dup
    //   5462: ldc_w 'cyan4 '
    //   5465: invokevirtual getBytes : ()[B
    //   5468: iconst_0
    //   5469: invokespecial <init> : ([BI)V
    //   5472: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5477: aload #5
    //   5479: sipush #214
    //   5482: new org/renjin/gcc/runtime/BytePtr
    //   5485: dup
    //   5486: ldc_w '#008B8B '
    //   5489: invokevirtual getBytes : ()[B
    //   5492: iconst_0
    //   5493: invokespecial <init> : ([BI)V
    //   5496: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5501: aload #5
    //   5503: sipush #215
    //   5506: ldc_w -7632128
    //   5509: invokeinterface setAlignedInt : (II)V
    //   5514: aload #5
    //   5516: sipush #216
    //   5519: new org/renjin/gcc/runtime/BytePtr
    //   5522: dup
    //   5523: ldc_w 'darkblue '
    //   5526: invokevirtual getBytes : ()[B
    //   5529: iconst_0
    //   5530: invokespecial <init> : ([BI)V
    //   5533: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5538: aload #5
    //   5540: sipush #217
    //   5543: new org/renjin/gcc/runtime/BytePtr
    //   5546: dup
    //   5547: ldc_w '#00008B '
    //   5550: invokevirtual getBytes : ()[B
    //   5553: iconst_0
    //   5554: invokespecial <init> : ([BI)V
    //   5557: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5562: aload #5
    //   5564: sipush #218
    //   5567: ldc_w -7667712
    //   5570: invokeinterface setAlignedInt : (II)V
    //   5575: aload #5
    //   5577: sipush #219
    //   5580: new org/renjin/gcc/runtime/BytePtr
    //   5583: dup
    //   5584: ldc_w 'darkcyan '
    //   5587: invokevirtual getBytes : ()[B
    //   5590: iconst_0
    //   5591: invokespecial <init> : ([BI)V
    //   5594: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5599: aload #5
    //   5601: sipush #220
    //   5604: new org/renjin/gcc/runtime/BytePtr
    //   5607: dup
    //   5608: ldc_w '#008B8B '
    //   5611: invokevirtual getBytes : ()[B
    //   5614: iconst_0
    //   5615: invokespecial <init> : ([BI)V
    //   5618: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5623: aload #5
    //   5625: sipush #221
    //   5628: ldc_w -7632128
    //   5631: invokeinterface setAlignedInt : (II)V
    //   5636: aload #5
    //   5638: sipush #222
    //   5641: new org/renjin/gcc/runtime/BytePtr
    //   5644: dup
    //   5645: ldc_w 'darkgoldenrod '
    //   5648: invokevirtual getBytes : ()[B
    //   5651: iconst_0
    //   5652: invokespecial <init> : ([BI)V
    //   5655: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5660: aload #5
    //   5662: sipush #223
    //   5665: new org/renjin/gcc/runtime/BytePtr
    //   5668: dup
    //   5669: ldc_w '#B8860B '
    //   5672: invokevirtual getBytes : ()[B
    //   5675: iconst_0
    //   5676: invokespecial <init> : ([BI)V
    //   5679: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5684: aload #5
    //   5686: sipush #224
    //   5689: ldc_w -16021832
    //   5692: invokeinterface setAlignedInt : (II)V
    //   5697: aload #5
    //   5699: sipush #225
    //   5702: new org/renjin/gcc/runtime/BytePtr
    //   5705: dup
    //   5706: ldc_w 'darkgoldenrod1 '
    //   5709: invokevirtual getBytes : ()[B
    //   5712: iconst_0
    //   5713: invokespecial <init> : ([BI)V
    //   5716: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5721: aload #5
    //   5723: sipush #226
    //   5726: new org/renjin/gcc/runtime/BytePtr
    //   5729: dup
    //   5730: ldc_w '#FFB90F '
    //   5733: invokevirtual getBytes : ()[B
    //   5736: iconst_0
    //   5737: invokespecial <init> : ([BI)V
    //   5740: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5745: aload #5
    //   5747: sipush #227
    //   5750: ldc_w -15746561
    //   5753: invokeinterface setAlignedInt : (II)V
    //   5758: aload #5
    //   5760: sipush #228
    //   5763: new org/renjin/gcc/runtime/BytePtr
    //   5766: dup
    //   5767: ldc_w 'darkgoldenrod2 '
    //   5770: invokevirtual getBytes : ()[B
    //   5773: iconst_0
    //   5774: invokespecial <init> : ([BI)V
    //   5777: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5782: aload #5
    //   5784: sipush #229
    //   5787: new org/renjin/gcc/runtime/BytePtr
    //   5790: dup
    //   5791: ldc_w '#EEAD0E '
    //   5794: invokevirtual getBytes : ()[B
    //   5797: iconst_0
    //   5798: invokespecial <init> : ([BI)V
    //   5801: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5806: aload #5
    //   5808: sipush #230
    //   5811: ldc_w -15815186
    //   5814: invokeinterface setAlignedInt : (II)V
    //   5819: aload #5
    //   5821: sipush #231
    //   5824: new org/renjin/gcc/runtime/BytePtr
    //   5827: dup
    //   5828: ldc_w 'darkgoldenrod3 '
    //   5831: invokevirtual getBytes : ()[B
    //   5834: iconst_0
    //   5835: invokespecial <init> : ([BI)V
    //   5838: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5843: aload #5
    //   5845: sipush #232
    //   5848: new org/renjin/gcc/runtime/BytePtr
    //   5851: dup
    //   5852: ldc_w '#CD950C '
    //   5855: invokevirtual getBytes : ()[B
    //   5858: iconst_0
    //   5859: invokespecial <init> : ([BI)V
    //   5862: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5867: aload #5
    //   5869: sipush #233
    //   5872: ldc_w -15952435
    //   5875: invokeinterface setAlignedInt : (II)V
    //   5880: aload #5
    //   5882: sipush #234
    //   5885: new org/renjin/gcc/runtime/BytePtr
    //   5888: dup
    //   5889: ldc_w 'darkgoldenrod4 '
    //   5892: invokevirtual getBytes : ()[B
    //   5895: iconst_0
    //   5896: invokespecial <init> : ([BI)V
    //   5899: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5904: aload #5
    //   5906: sipush #235
    //   5909: new org/renjin/gcc/runtime/BytePtr
    //   5912: dup
    //   5913: ldc_w '#8B6508 '
    //   5916: invokevirtual getBytes : ()[B
    //   5919: iconst_0
    //   5920: invokespecial <init> : ([BI)V
    //   5923: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5928: aload #5
    //   5930: sipush #236
    //   5933: ldc_w -16226933
    //   5936: invokeinterface setAlignedInt : (II)V
    //   5941: aload #5
    //   5943: sipush #237
    //   5946: new org/renjin/gcc/runtime/BytePtr
    //   5949: dup
    //   5950: ldc_w 'darkgray '
    //   5953: invokevirtual getBytes : ()[B
    //   5956: iconst_0
    //   5957: invokespecial <init> : ([BI)V
    //   5960: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5965: aload #5
    //   5967: sipush #238
    //   5970: new org/renjin/gcc/runtime/BytePtr
    //   5973: dup
    //   5974: ldc_w '#A9A9A9 '
    //   5977: invokevirtual getBytes : ()[B
    //   5980: iconst_0
    //   5981: invokespecial <init> : ([BI)V
    //   5984: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   5989: aload #5
    //   5991: sipush #239
    //   5994: ldc_w -5658199
    //   5997: invokeinterface setAlignedInt : (II)V
    //   6002: aload #5
    //   6004: sipush #240
    //   6007: new org/renjin/gcc/runtime/BytePtr
    //   6010: dup
    //   6011: ldc_w 'darkgreen '
    //   6014: invokevirtual getBytes : ()[B
    //   6017: iconst_0
    //   6018: invokespecial <init> : ([BI)V
    //   6021: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6026: aload #5
    //   6028: sipush #241
    //   6031: new org/renjin/gcc/runtime/BytePtr
    //   6034: dup
    //   6035: ldc_w '#006400 '
    //   6038: invokevirtual getBytes : ()[B
    //   6041: iconst_0
    //   6042: invokespecial <init> : ([BI)V
    //   6045: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6050: aload #5
    //   6052: sipush #242
    //   6055: ldc_w -16751616
    //   6058: invokeinterface setAlignedInt : (II)V
    //   6063: aload #5
    //   6065: sipush #243
    //   6068: new org/renjin/gcc/runtime/BytePtr
    //   6071: dup
    //   6072: ldc_w 'darkgrey '
    //   6075: invokevirtual getBytes : ()[B
    //   6078: iconst_0
    //   6079: invokespecial <init> : ([BI)V
    //   6082: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6087: aload #5
    //   6089: sipush #244
    //   6092: new org/renjin/gcc/runtime/BytePtr
    //   6095: dup
    //   6096: ldc_w '#A9A9A9 '
    //   6099: invokevirtual getBytes : ()[B
    //   6102: iconst_0
    //   6103: invokespecial <init> : ([BI)V
    //   6106: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6111: aload #5
    //   6113: sipush #245
    //   6116: ldc_w -5658199
    //   6119: invokeinterface setAlignedInt : (II)V
    //   6124: aload #5
    //   6126: sipush #246
    //   6129: new org/renjin/gcc/runtime/BytePtr
    //   6132: dup
    //   6133: ldc_w 'darkkhaki '
    //   6136: invokevirtual getBytes : ()[B
    //   6139: iconst_0
    //   6140: invokespecial <init> : ([BI)V
    //   6143: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6148: aload #5
    //   6150: sipush #247
    //   6153: new org/renjin/gcc/runtime/BytePtr
    //   6156: dup
    //   6157: ldc_w '#BDB76B '
    //   6160: invokevirtual getBytes : ()[B
    //   6163: iconst_0
    //   6164: invokespecial <init> : ([BI)V
    //   6167: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6172: aload #5
    //   6174: sipush #248
    //   6177: ldc_w -9717827
    //   6180: invokeinterface setAlignedInt : (II)V
    //   6185: aload #5
    //   6187: sipush #249
    //   6190: new org/renjin/gcc/runtime/BytePtr
    //   6193: dup
    //   6194: ldc_w 'darkmagenta '
    //   6197: invokevirtual getBytes : ()[B
    //   6200: iconst_0
    //   6201: invokespecial <init> : ([BI)V
    //   6204: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6209: aload #5
    //   6211: sipush #250
    //   6214: new org/renjin/gcc/runtime/BytePtr
    //   6217: dup
    //   6218: ldc_w '#8B008B '
    //   6221: invokevirtual getBytes : ()[B
    //   6224: iconst_0
    //   6225: invokespecial <init> : ([BI)V
    //   6228: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6233: aload #5
    //   6235: sipush #251
    //   6238: ldc_w -7667573
    //   6241: invokeinterface setAlignedInt : (II)V
    //   6246: aload #5
    //   6248: sipush #252
    //   6251: new org/renjin/gcc/runtime/BytePtr
    //   6254: dup
    //   6255: ldc_w 'darkolivegreen '
    //   6258: invokevirtual getBytes : ()[B
    //   6261: iconst_0
    //   6262: invokespecial <init> : ([BI)V
    //   6265: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6270: aload #5
    //   6272: sipush #253
    //   6275: new org/renjin/gcc/runtime/BytePtr
    //   6278: dup
    //   6279: ldc_w '#556B2F '
    //   6282: invokevirtual getBytes : ()[B
    //   6285: iconst_0
    //   6286: invokespecial <init> : ([BI)V
    //   6289: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6294: aload #5
    //   6296: sipush #254
    //   6299: ldc_w -13669547
    //   6302: invokeinterface setAlignedInt : (II)V
    //   6307: aload #5
    //   6309: sipush #255
    //   6312: new org/renjin/gcc/runtime/BytePtr
    //   6315: dup
    //   6316: ldc_w 'darkolivegreen1 '
    //   6319: invokevirtual getBytes : ()[B
    //   6322: iconst_0
    //   6323: invokespecial <init> : ([BI)V
    //   6326: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6331: aload #5
    //   6333: sipush #256
    //   6336: new org/renjin/gcc/runtime/BytePtr
    //   6339: dup
    //   6340: ldc_w '#CAFF70 '
    //   6343: invokevirtual getBytes : ()[B
    //   6346: iconst_0
    //   6347: invokespecial <init> : ([BI)V
    //   6350: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6355: aload #5
    //   6357: sipush #257
    //   6360: ldc_w -9371702
    //   6363: invokeinterface setAlignedInt : (II)V
    //   6368: aload #5
    //   6370: sipush #258
    //   6373: new org/renjin/gcc/runtime/BytePtr
    //   6376: dup
    //   6377: ldc_w 'darkolivegreen2 '
    //   6380: invokevirtual getBytes : ()[B
    //   6383: iconst_0
    //   6384: invokespecial <init> : ([BI)V
    //   6387: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6392: aload #5
    //   6394: sipush #259
    //   6397: new org/renjin/gcc/runtime/BytePtr
    //   6400: dup
    //   6401: ldc_w '#BCEE68 '
    //   6404: invokevirtual getBytes : ()[B
    //   6407: iconst_0
    //   6408: invokespecial <init> : ([BI)V
    //   6411: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6416: aload #5
    //   6418: sipush #260
    //   6421: ldc_w -9900356
    //   6424: invokeinterface setAlignedInt : (II)V
    //   6429: aload #5
    //   6431: sipush #261
    //   6434: new org/renjin/gcc/runtime/BytePtr
    //   6437: dup
    //   6438: ldc_w 'darkolivegreen3 '
    //   6441: invokevirtual getBytes : ()[B
    //   6444: iconst_0
    //   6445: invokespecial <init> : ([BI)V
    //   6448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6453: aload #5
    //   6455: sipush #262
    //   6458: new org/renjin/gcc/runtime/BytePtr
    //   6461: dup
    //   6462: ldc_w '#A2CD5A '
    //   6465: invokevirtual getBytes : ()[B
    //   6468: iconst_0
    //   6469: invokespecial <init> : ([BI)V
    //   6472: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6477: aload #5
    //   6479: sipush #263
    //   6482: ldc_w -10826334
    //   6485: invokeinterface setAlignedInt : (II)V
    //   6490: aload #5
    //   6492: sipush #264
    //   6495: new org/renjin/gcc/runtime/BytePtr
    //   6498: dup
    //   6499: ldc_w 'darkolivegreen4 '
    //   6502: invokevirtual getBytes : ()[B
    //   6505: iconst_0
    //   6506: invokespecial <init> : ([BI)V
    //   6509: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6514: aload #5
    //   6516: sipush #265
    //   6519: new org/renjin/gcc/runtime/BytePtr
    //   6522: dup
    //   6523: ldc_w '#6E8B3D '
    //   6526: invokevirtual getBytes : ()[B
    //   6529: iconst_0
    //   6530: invokespecial <init> : ([BI)V
    //   6533: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6538: aload #5
    //   6540: sipush #266
    //   6543: ldc_w -12743826
    //   6546: invokeinterface setAlignedInt : (II)V
    //   6551: aload #5
    //   6553: sipush #267
    //   6556: new org/renjin/gcc/runtime/BytePtr
    //   6559: dup
    //   6560: ldc_w 'darkorange '
    //   6563: invokevirtual getBytes : ()[B
    //   6566: iconst_0
    //   6567: invokespecial <init> : ([BI)V
    //   6570: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6575: aload #5
    //   6577: sipush #268
    //   6580: new org/renjin/gcc/runtime/BytePtr
    //   6583: dup
    //   6584: ldc_w '#FF8C00 '
    //   6587: invokevirtual getBytes : ()[B
    //   6590: iconst_0
    //   6591: invokespecial <init> : ([BI)V
    //   6594: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6599: aload #5
    //   6601: sipush #269
    //   6604: ldc_w -16741121
    //   6607: invokeinterface setAlignedInt : (II)V
    //   6612: aload #5
    //   6614: sipush #270
    //   6617: new org/renjin/gcc/runtime/BytePtr
    //   6620: dup
    //   6621: ldc_w 'darkorange1 '
    //   6624: invokevirtual getBytes : ()[B
    //   6627: iconst_0
    //   6628: invokespecial <init> : ([BI)V
    //   6631: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6636: aload #5
    //   6638: sipush #271
    //   6641: new org/renjin/gcc/runtime/BytePtr
    //   6644: dup
    //   6645: ldc_w '#FF7F00 '
    //   6648: invokevirtual getBytes : ()[B
    //   6651: iconst_0
    //   6652: invokespecial <init> : ([BI)V
    //   6655: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6660: aload #5
    //   6662: sipush #272
    //   6665: ldc_w -16744449
    //   6668: invokeinterface setAlignedInt : (II)V
    //   6673: aload #5
    //   6675: sipush #273
    //   6678: new org/renjin/gcc/runtime/BytePtr
    //   6681: dup
    //   6682: ldc_w 'darkorange2 '
    //   6685: invokevirtual getBytes : ()[B
    //   6688: iconst_0
    //   6689: invokespecial <init> : ([BI)V
    //   6692: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6697: aload #5
    //   6699: sipush #274
    //   6702: new org/renjin/gcc/runtime/BytePtr
    //   6705: dup
    //   6706: ldc_w '#EE7600 '
    //   6709: invokevirtual getBytes : ()[B
    //   6712: iconst_0
    //   6713: invokespecial <init> : ([BI)V
    //   6716: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6721: aload #5
    //   6723: sipush #275
    //   6726: ldc_w -16746770
    //   6729: invokeinterface setAlignedInt : (II)V
    //   6734: aload #5
    //   6736: sipush #276
    //   6739: new org/renjin/gcc/runtime/BytePtr
    //   6742: dup
    //   6743: ldc_w 'darkorange3 '
    //   6746: invokevirtual getBytes : ()[B
    //   6749: iconst_0
    //   6750: invokespecial <init> : ([BI)V
    //   6753: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6758: aload #5
    //   6760: sipush #277
    //   6763: new org/renjin/gcc/runtime/BytePtr
    //   6766: dup
    //   6767: ldc_w '#CD6600 '
    //   6770: invokevirtual getBytes : ()[B
    //   6773: iconst_0
    //   6774: invokespecial <init> : ([BI)V
    //   6777: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6782: aload #5
    //   6784: sipush #278
    //   6787: ldc_w -16750899
    //   6790: invokeinterface setAlignedInt : (II)V
    //   6795: aload #5
    //   6797: sipush #279
    //   6800: new org/renjin/gcc/runtime/BytePtr
    //   6803: dup
    //   6804: ldc_w 'darkorange4 '
    //   6807: invokevirtual getBytes : ()[B
    //   6810: iconst_0
    //   6811: invokespecial <init> : ([BI)V
    //   6814: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6819: aload #5
    //   6821: sipush #280
    //   6824: new org/renjin/gcc/runtime/BytePtr
    //   6827: dup
    //   6828: ldc_w '#8B4500 '
    //   6831: invokevirtual getBytes : ()[B
    //   6834: iconst_0
    //   6835: invokespecial <init> : ([BI)V
    //   6838: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6843: aload #5
    //   6845: sipush #281
    //   6848: ldc_w -16759413
    //   6851: invokeinterface setAlignedInt : (II)V
    //   6856: aload #5
    //   6858: sipush #282
    //   6861: new org/renjin/gcc/runtime/BytePtr
    //   6864: dup
    //   6865: ldc_w 'darkorchid '
    //   6868: invokevirtual getBytes : ()[B
    //   6871: iconst_0
    //   6872: invokespecial <init> : ([BI)V
    //   6875: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6880: aload #5
    //   6882: sipush #283
    //   6885: new org/renjin/gcc/runtime/BytePtr
    //   6888: dup
    //   6889: ldc_w '#9932CC '
    //   6892: invokevirtual getBytes : ()[B
    //   6895: iconst_0
    //   6896: invokespecial <init> : ([BI)V
    //   6899: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6904: aload #5
    //   6906: sipush #284
    //   6909: ldc_w -3394919
    //   6912: invokeinterface setAlignedInt : (II)V
    //   6917: aload #5
    //   6919: sipush #285
    //   6922: new org/renjin/gcc/runtime/BytePtr
    //   6925: dup
    //   6926: ldc_w 'darkorchid1 '
    //   6929: invokevirtual getBytes : ()[B
    //   6932: iconst_0
    //   6933: invokespecial <init> : ([BI)V
    //   6936: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6941: aload #5
    //   6943: sipush #286
    //   6946: new org/renjin/gcc/runtime/BytePtr
    //   6949: dup
    //   6950: ldc_w '#BF3EFF '
    //   6953: invokevirtual getBytes : ()[B
    //   6956: iconst_0
    //   6957: invokespecial <init> : ([BI)V
    //   6960: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   6965: aload #5
    //   6967: sipush #287
    //   6970: ldc_w -49473
    //   6973: invokeinterface setAlignedInt : (II)V
    //   6978: aload #5
    //   6980: sipush #288
    //   6983: new org/renjin/gcc/runtime/BytePtr
    //   6986: dup
    //   6987: ldc_w 'darkorchid2 '
    //   6990: invokevirtual getBytes : ()[B
    //   6993: iconst_0
    //   6994: invokespecial <init> : ([BI)V
    //   6997: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7002: aload #5
    //   7004: sipush #289
    //   7007: new org/renjin/gcc/runtime/BytePtr
    //   7010: dup
    //   7011: ldc_w '#B23AEE '
    //   7014: invokevirtual getBytes : ()[B
    //   7017: iconst_0
    //   7018: invokespecial <init> : ([BI)V
    //   7021: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7026: aload #5
    //   7028: sipush #290
    //   7031: ldc_w -1164622
    //   7034: invokeinterface setAlignedInt : (II)V
    //   7039: aload #5
    //   7041: sipush #291
    //   7044: new org/renjin/gcc/runtime/BytePtr
    //   7047: dup
    //   7048: ldc_w 'darkorchid3 '
    //   7051: invokevirtual getBytes : ()[B
    //   7054: iconst_0
    //   7055: invokespecial <init> : ([BI)V
    //   7058: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7063: aload #5
    //   7065: sipush #292
    //   7068: new org/renjin/gcc/runtime/BytePtr
    //   7071: dup
    //   7072: ldc_w '#9A32CD '
    //   7075: invokevirtual getBytes : ()[B
    //   7078: iconst_0
    //   7079: invokespecial <init> : ([BI)V
    //   7082: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7087: aload #5
    //   7089: sipush #293
    //   7092: ldc_w -3329382
    //   7095: invokeinterface setAlignedInt : (II)V
    //   7100: aload #5
    //   7102: sipush #294
    //   7105: new org/renjin/gcc/runtime/BytePtr
    //   7108: dup
    //   7109: ldc_w 'darkorchid4 '
    //   7112: invokevirtual getBytes : ()[B
    //   7115: iconst_0
    //   7116: invokespecial <init> : ([BI)V
    //   7119: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7124: aload #5
    //   7126: sipush #295
    //   7129: new org/renjin/gcc/runtime/BytePtr
    //   7132: dup
    //   7133: ldc_w '#68228B '
    //   7136: invokevirtual getBytes : ()[B
    //   7139: iconst_0
    //   7140: invokespecial <init> : ([BI)V
    //   7143: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7148: aload #5
    //   7150: sipush #296
    //   7153: ldc_w -7658904
    //   7156: invokeinterface setAlignedInt : (II)V
    //   7161: aload #5
    //   7163: sipush #297
    //   7166: new org/renjin/gcc/runtime/BytePtr
    //   7169: dup
    //   7170: ldc_w 'darkred '
    //   7173: invokevirtual getBytes : ()[B
    //   7176: iconst_0
    //   7177: invokespecial <init> : ([BI)V
    //   7180: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7185: aload #5
    //   7187: sipush #298
    //   7190: new org/renjin/gcc/runtime/BytePtr
    //   7193: dup
    //   7194: ldc_w '#8B0000 '
    //   7197: invokevirtual getBytes : ()[B
    //   7200: iconst_0
    //   7201: invokespecial <init> : ([BI)V
    //   7204: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7209: aload #5
    //   7211: sipush #299
    //   7214: ldc_w -16777077
    //   7217: invokeinterface setAlignedInt : (II)V
    //   7222: aload #5
    //   7224: sipush #300
    //   7227: new org/renjin/gcc/runtime/BytePtr
    //   7230: dup
    //   7231: ldc_w 'darksalmon '
    //   7234: invokevirtual getBytes : ()[B
    //   7237: iconst_0
    //   7238: invokespecial <init> : ([BI)V
    //   7241: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7246: aload #5
    //   7248: sipush #301
    //   7251: new org/renjin/gcc/runtime/BytePtr
    //   7254: dup
    //   7255: ldc_w '#E9967A '
    //   7258: invokevirtual getBytes : ()[B
    //   7261: iconst_0
    //   7262: invokespecial <init> : ([BI)V
    //   7265: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7270: aload #5
    //   7272: sipush #302
    //   7275: ldc_w -8743191
    //   7278: invokeinterface setAlignedInt : (II)V
    //   7283: aload #5
    //   7285: sipush #303
    //   7288: new org/renjin/gcc/runtime/BytePtr
    //   7291: dup
    //   7292: ldc_w 'darkseagreen '
    //   7295: invokevirtual getBytes : ()[B
    //   7298: iconst_0
    //   7299: invokespecial <init> : ([BI)V
    //   7302: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7307: aload #5
    //   7309: sipush #304
    //   7312: new org/renjin/gcc/runtime/BytePtr
    //   7315: dup
    //   7316: ldc_w '#8FBC8F '
    //   7319: invokevirtual getBytes : ()[B
    //   7322: iconst_0
    //   7323: invokespecial <init> : ([BI)V
    //   7326: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7331: aload #5
    //   7333: sipush #305
    //   7336: ldc_w -7357297
    //   7339: invokeinterface setAlignedInt : (II)V
    //   7344: aload #5
    //   7346: sipush #306
    //   7349: new org/renjin/gcc/runtime/BytePtr
    //   7352: dup
    //   7353: ldc_w 'darkseagreen1 '
    //   7356: invokevirtual getBytes : ()[B
    //   7359: iconst_0
    //   7360: invokespecial <init> : ([BI)V
    //   7363: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7368: aload #5
    //   7370: sipush #307
    //   7373: new org/renjin/gcc/runtime/BytePtr
    //   7376: dup
    //   7377: ldc_w '#C1FFC1 '
    //   7380: invokevirtual getBytes : ()[B
    //   7383: iconst_0
    //   7384: invokespecial <init> : ([BI)V
    //   7387: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7392: aload #5
    //   7394: sipush #308
    //   7397: ldc_w -4063295
    //   7400: invokeinterface setAlignedInt : (II)V
    //   7405: aload #5
    //   7407: sipush #309
    //   7410: new org/renjin/gcc/runtime/BytePtr
    //   7413: dup
    //   7414: ldc_w 'darkseagreen2 '
    //   7417: invokevirtual getBytes : ()[B
    //   7420: iconst_0
    //   7421: invokespecial <init> : ([BI)V
    //   7424: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7429: aload #5
    //   7431: sipush #310
    //   7434: new org/renjin/gcc/runtime/BytePtr
    //   7437: dup
    //   7438: ldc_w '#B4EEB4 '
    //   7441: invokevirtual getBytes : ()[B
    //   7444: iconst_0
    //   7445: invokespecial <init> : ([BI)V
    //   7448: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7453: aload #5
    //   7455: sipush #311
    //   7458: ldc_w -4919628
    //   7461: invokeinterface setAlignedInt : (II)V
    //   7466: aload #5
    //   7468: sipush #312
    //   7471: new org/renjin/gcc/runtime/BytePtr
    //   7474: dup
    //   7475: ldc_w 'darkseagreen3 '
    //   7478: invokevirtual getBytes : ()[B
    //   7481: iconst_0
    //   7482: invokespecial <init> : ([BI)V
    //   7485: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7490: aload #5
    //   7492: sipush #313
    //   7495: new org/renjin/gcc/runtime/BytePtr
    //   7498: dup
    //   7499: ldc_w '#9BCD9B '
    //   7502: invokevirtual getBytes : ()[B
    //   7505: iconst_0
    //   7506: invokespecial <init> : ([BI)V
    //   7509: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7514: aload #5
    //   7516: sipush #314
    //   7519: ldc_w -6566501
    //   7522: invokeinterface setAlignedInt : (II)V
    //   7527: aload #5
    //   7529: sipush #315
    //   7532: new org/renjin/gcc/runtime/BytePtr
    //   7535: dup
    //   7536: ldc_w 'darkseagreen4 '
    //   7539: invokevirtual getBytes : ()[B
    //   7542: iconst_0
    //   7543: invokespecial <init> : ([BI)V
    //   7546: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7551: aload #5
    //   7553: sipush #316
    //   7556: new org/renjin/gcc/runtime/BytePtr
    //   7559: dup
    //   7560: ldc_w '#698B69 '
    //   7563: invokevirtual getBytes : ()[B
    //   7566: iconst_0
    //   7567: invokespecial <init> : ([BI)V
    //   7570: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7575: aload #5
    //   7577: sipush #317
    //   7580: ldc_w -9860247
    //   7583: invokeinterface setAlignedInt : (II)V
    //   7588: aload #5
    //   7590: sipush #318
    //   7593: new org/renjin/gcc/runtime/BytePtr
    //   7596: dup
    //   7597: ldc_w 'darkslateblue '
    //   7600: invokevirtual getBytes : ()[B
    //   7603: iconst_0
    //   7604: invokespecial <init> : ([BI)V
    //   7607: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7612: aload #5
    //   7614: sipush #319
    //   7617: new org/renjin/gcc/runtime/BytePtr
    //   7620: dup
    //   7621: ldc_w '#483D8B '
    //   7624: invokevirtual getBytes : ()[B
    //   7627: iconst_0
    //   7628: invokespecial <init> : ([BI)V
    //   7631: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7636: aload #5
    //   7638: sipush #320
    //   7641: ldc_w -7652024
    //   7644: invokeinterface setAlignedInt : (II)V
    //   7649: aload #5
    //   7651: sipush #321
    //   7654: new org/renjin/gcc/runtime/BytePtr
    //   7657: dup
    //   7658: ldc_w 'darkslategray '
    //   7661: invokevirtual getBytes : ()[B
    //   7664: iconst_0
    //   7665: invokespecial <init> : ([BI)V
    //   7668: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7673: aload #5
    //   7675: sipush #322
    //   7678: new org/renjin/gcc/runtime/BytePtr
    //   7681: dup
    //   7682: ldc_w '#2F4F4F '
    //   7685: invokevirtual getBytes : ()[B
    //   7688: iconst_0
    //   7689: invokespecial <init> : ([BI)V
    //   7692: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7697: aload #5
    //   7699: sipush #323
    //   7702: ldc_w -11579601
    //   7705: invokeinterface setAlignedInt : (II)V
    //   7710: aload #5
    //   7712: sipush #324
    //   7715: new org/renjin/gcc/runtime/BytePtr
    //   7718: dup
    //   7719: ldc_w 'darkslategray1 '
    //   7722: invokevirtual getBytes : ()[B
    //   7725: iconst_0
    //   7726: invokespecial <init> : ([BI)V
    //   7729: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7734: aload #5
    //   7736: sipush #325
    //   7739: new org/renjin/gcc/runtime/BytePtr
    //   7742: dup
    //   7743: ldc_w '#97FFFF '
    //   7746: invokevirtual getBytes : ()[B
    //   7749: iconst_0
    //   7750: invokespecial <init> : ([BI)V
    //   7753: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7758: aload #5
    //   7760: sipush #326
    //   7763: bipush #-105
    //   7765: invokeinterface setAlignedInt : (II)V
    //   7770: aload #5
    //   7772: sipush #327
    //   7775: new org/renjin/gcc/runtime/BytePtr
    //   7778: dup
    //   7779: ldc_w 'darkslategray2 '
    //   7782: invokevirtual getBytes : ()[B
    //   7785: iconst_0
    //   7786: invokespecial <init> : ([BI)V
    //   7789: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7794: aload #5
    //   7796: sipush #328
    //   7799: new org/renjin/gcc/runtime/BytePtr
    //   7802: dup
    //   7803: ldc_w '#8DEEEE '
    //   7806: invokevirtual getBytes : ()[B
    //   7809: iconst_0
    //   7810: invokespecial <init> : ([BI)V
    //   7813: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7818: aload #5
    //   7820: sipush #329
    //   7823: ldc_w -1118579
    //   7826: invokeinterface setAlignedInt : (II)V
    //   7831: aload #5
    //   7833: sipush #330
    //   7836: new org/renjin/gcc/runtime/BytePtr
    //   7839: dup
    //   7840: ldc_w 'darkslategray3 '
    //   7843: invokevirtual getBytes : ()[B
    //   7846: iconst_0
    //   7847: invokespecial <init> : ([BI)V
    //   7850: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7855: aload #5
    //   7857: sipush #331
    //   7860: new org/renjin/gcc/runtime/BytePtr
    //   7863: dup
    //   7864: ldc_w '#79CDCD '
    //   7867: invokevirtual getBytes : ()[B
    //   7870: iconst_0
    //   7871: invokespecial <init> : ([BI)V
    //   7874: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7879: aload #5
    //   7881: sipush #332
    //   7884: ldc_w -3289735
    //   7887: invokeinterface setAlignedInt : (II)V
    //   7892: aload #5
    //   7894: sipush #333
    //   7897: new org/renjin/gcc/runtime/BytePtr
    //   7900: dup
    //   7901: ldc_w 'darkslategray4 '
    //   7904: invokevirtual getBytes : ()[B
    //   7907: iconst_0
    //   7908: invokespecial <init> : ([BI)V
    //   7911: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7916: aload #5
    //   7918: sipush #334
    //   7921: new org/renjin/gcc/runtime/BytePtr
    //   7924: dup
    //   7925: ldc_w '#528B8B '
    //   7928: invokevirtual getBytes : ()[B
    //   7931: iconst_0
    //   7932: invokespecial <init> : ([BI)V
    //   7935: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7940: aload #5
    //   7942: sipush #335
    //   7945: ldc_w -7632046
    //   7948: invokeinterface setAlignedInt : (II)V
    //   7953: aload #5
    //   7955: sipush #336
    //   7958: new org/renjin/gcc/runtime/BytePtr
    //   7961: dup
    //   7962: ldc_w 'darkslategrey '
    //   7965: invokevirtual getBytes : ()[B
    //   7968: iconst_0
    //   7969: invokespecial <init> : ([BI)V
    //   7972: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   7977: aload #5
    //   7979: sipush #337
    //   7982: new org/renjin/gcc/runtime/BytePtr
    //   7985: dup
    //   7986: ldc_w '#2F4F4F '
    //   7989: invokevirtual getBytes : ()[B
    //   7992: iconst_0
    //   7993: invokespecial <init> : ([BI)V
    //   7996: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8001: aload #5
    //   8003: sipush #338
    //   8006: ldc_w -11579601
    //   8009: invokeinterface setAlignedInt : (II)V
    //   8014: aload #5
    //   8016: sipush #339
    //   8019: new org/renjin/gcc/runtime/BytePtr
    //   8022: dup
    //   8023: ldc_w 'darkturquoise '
    //   8026: invokevirtual getBytes : ()[B
    //   8029: iconst_0
    //   8030: invokespecial <init> : ([BI)V
    //   8033: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8038: aload #5
    //   8040: sipush #340
    //   8043: new org/renjin/gcc/runtime/BytePtr
    //   8046: dup
    //   8047: ldc_w '#00CED1 '
    //   8050: invokevirtual getBytes : ()[B
    //   8053: iconst_0
    //   8054: invokespecial <init> : ([BI)V
    //   8057: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8062: aload #5
    //   8064: sipush #341
    //   8067: ldc_w -3027456
    //   8070: invokeinterface setAlignedInt : (II)V
    //   8075: aload #5
    //   8077: sipush #342
    //   8080: new org/renjin/gcc/runtime/BytePtr
    //   8083: dup
    //   8084: ldc_w 'darkviolet '
    //   8087: invokevirtual getBytes : ()[B
    //   8090: iconst_0
    //   8091: invokespecial <init> : ([BI)V
    //   8094: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8099: aload #5
    //   8101: sipush #343
    //   8104: new org/renjin/gcc/runtime/BytePtr
    //   8107: dup
    //   8108: ldc_w '#9400D3 '
    //   8111: invokevirtual getBytes : ()[B
    //   8114: iconst_0
    //   8115: invokespecial <init> : ([BI)V
    //   8118: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8123: aload #5
    //   8125: sipush #344
    //   8128: ldc_w -2948972
    //   8131: invokeinterface setAlignedInt : (II)V
    //   8136: aload #5
    //   8138: sipush #345
    //   8141: new org/renjin/gcc/runtime/BytePtr
    //   8144: dup
    //   8145: ldc_w 'deeppink '
    //   8148: invokevirtual getBytes : ()[B
    //   8151: iconst_0
    //   8152: invokespecial <init> : ([BI)V
    //   8155: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8160: aload #5
    //   8162: sipush #346
    //   8165: new org/renjin/gcc/runtime/BytePtr
    //   8168: dup
    //   8169: ldc_w '#FF1493 '
    //   8172: invokevirtual getBytes : ()[B
    //   8175: iconst_0
    //   8176: invokespecial <init> : ([BI)V
    //   8179: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8184: aload #5
    //   8186: sipush #347
    //   8189: ldc_w -7138049
    //   8192: invokeinterface setAlignedInt : (II)V
    //   8197: aload #5
    //   8199: sipush #348
    //   8202: new org/renjin/gcc/runtime/BytePtr
    //   8205: dup
    //   8206: ldc_w 'deeppink1 '
    //   8209: invokevirtual getBytes : ()[B
    //   8212: iconst_0
    //   8213: invokespecial <init> : ([BI)V
    //   8216: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8221: aload #5
    //   8223: sipush #349
    //   8226: new org/renjin/gcc/runtime/BytePtr
    //   8229: dup
    //   8230: ldc_w '#FF1493 '
    //   8233: invokevirtual getBytes : ()[B
    //   8236: iconst_0
    //   8237: invokespecial <init> : ([BI)V
    //   8240: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8245: aload #5
    //   8247: sipush #350
    //   8250: ldc_w -7138049
    //   8253: invokeinterface setAlignedInt : (II)V
    //   8258: aload #5
    //   8260: sipush #351
    //   8263: new org/renjin/gcc/runtime/BytePtr
    //   8266: dup
    //   8267: ldc_w 'deeppink2 '
    //   8270: invokevirtual getBytes : ()[B
    //   8273: iconst_0
    //   8274: invokespecial <init> : ([BI)V
    //   8277: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8282: aload #5
    //   8284: sipush #352
    //   8287: new org/renjin/gcc/runtime/BytePtr
    //   8290: dup
    //   8291: ldc_w '#EE1289 '
    //   8294: invokevirtual getBytes : ()[B
    //   8297: iconst_0
    //   8298: invokespecial <init> : ([BI)V
    //   8301: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8306: aload #5
    //   8308: sipush #353
    //   8311: ldc_w -7793938
    //   8314: invokeinterface setAlignedInt : (II)V
    //   8319: aload #5
    //   8321: sipush #354
    //   8324: new org/renjin/gcc/runtime/BytePtr
    //   8327: dup
    //   8328: ldc_w 'deeppink3 '
    //   8331: invokevirtual getBytes : ()[B
    //   8334: iconst_0
    //   8335: invokespecial <init> : ([BI)V
    //   8338: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8343: aload #5
    //   8345: sipush #355
    //   8348: new org/renjin/gcc/runtime/BytePtr
    //   8351: dup
    //   8352: ldc_w '#CD1076 '
    //   8355: invokevirtual getBytes : ()[B
    //   8358: iconst_0
    //   8359: invokespecial <init> : ([BI)V
    //   8362: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8367: aload #5
    //   8369: sipush #356
    //   8372: ldc_w -9039667
    //   8375: invokeinterface setAlignedInt : (II)V
    //   8380: aload #5
    //   8382: sipush #357
    //   8385: new org/renjin/gcc/runtime/BytePtr
    //   8388: dup
    //   8389: ldc_w 'deeppink4 '
    //   8392: invokevirtual getBytes : ()[B
    //   8395: iconst_0
    //   8396: invokespecial <init> : ([BI)V
    //   8399: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8404: aload #5
    //   8406: sipush #358
    //   8409: new org/renjin/gcc/runtime/BytePtr
    //   8412: dup
    //   8413: ldc_w '#8B0A50 '
    //   8416: invokevirtual getBytes : ()[B
    //   8419: iconst_0
    //   8420: invokespecial <init> : ([BI)V
    //   8423: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8428: aload #5
    //   8430: sipush #359
    //   8433: ldc_w -11531637
    //   8436: invokeinterface setAlignedInt : (II)V
    //   8441: aload #5
    //   8443: sipush #360
    //   8446: new org/renjin/gcc/runtime/BytePtr
    //   8449: dup
    //   8450: ldc_w 'deepskyblue '
    //   8453: invokevirtual getBytes : ()[B
    //   8456: iconst_0
    //   8457: invokespecial <init> : ([BI)V
    //   8460: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8465: aload #5
    //   8467: sipush #361
    //   8470: new org/renjin/gcc/runtime/BytePtr
    //   8473: dup
    //   8474: ldc_w '#00BFFF '
    //   8477: invokevirtual getBytes : ()[B
    //   8480: iconst_0
    //   8481: invokespecial <init> : ([BI)V
    //   8484: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8489: aload #5
    //   8491: sipush #362
    //   8494: sipush #-16640
    //   8497: invokeinterface setAlignedInt : (II)V
    //   8502: aload #5
    //   8504: sipush #363
    //   8507: new org/renjin/gcc/runtime/BytePtr
    //   8510: dup
    //   8511: ldc_w 'deepskyblue1 '
    //   8514: invokevirtual getBytes : ()[B
    //   8517: iconst_0
    //   8518: invokespecial <init> : ([BI)V
    //   8521: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8526: aload #5
    //   8528: sipush #364
    //   8531: new org/renjin/gcc/runtime/BytePtr
    //   8534: dup
    //   8535: ldc_w '#00BFFF '
    //   8538: invokevirtual getBytes : ()[B
    //   8541: iconst_0
    //   8542: invokespecial <init> : ([BI)V
    //   8545: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8550: aload #5
    //   8552: sipush #365
    //   8555: sipush #-16640
    //   8558: invokeinterface setAlignedInt : (II)V
    //   8563: aload #5
    //   8565: sipush #366
    //   8568: new org/renjin/gcc/runtime/BytePtr
    //   8571: dup
    //   8572: ldc_w 'deepskyblue2 '
    //   8575: invokevirtual getBytes : ()[B
    //   8578: iconst_0
    //   8579: invokespecial <init> : ([BI)V
    //   8582: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8587: aload #5
    //   8589: sipush #367
    //   8592: new org/renjin/gcc/runtime/BytePtr
    //   8595: dup
    //   8596: ldc_w '#00B2EE '
    //   8599: invokevirtual getBytes : ()[B
    //   8602: iconst_0
    //   8603: invokespecial <init> : ([BI)V
    //   8606: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8611: aload #5
    //   8613: sipush #368
    //   8616: ldc_w -1134080
    //   8619: invokeinterface setAlignedInt : (II)V
    //   8624: aload #5
    //   8626: sipush #369
    //   8629: new org/renjin/gcc/runtime/BytePtr
    //   8632: dup
    //   8633: ldc_w 'deepskyblue3 '
    //   8636: invokevirtual getBytes : ()[B
    //   8639: iconst_0
    //   8640: invokespecial <init> : ([BI)V
    //   8643: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8648: aload #5
    //   8650: sipush #370
    //   8653: new org/renjin/gcc/runtime/BytePtr
    //   8656: dup
    //   8657: ldc_w '#009ACD '
    //   8660: invokevirtual getBytes : ()[B
    //   8663: iconst_0
    //   8664: invokespecial <init> : ([BI)V
    //   8667: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8672: aload #5
    //   8674: sipush #371
    //   8677: ldc_w -3302912
    //   8680: invokeinterface setAlignedInt : (II)V
    //   8685: aload #5
    //   8687: sipush #372
    //   8690: new org/renjin/gcc/runtime/BytePtr
    //   8693: dup
    //   8694: ldc_w 'deepskyblue4 '
    //   8697: invokevirtual getBytes : ()[B
    //   8700: iconst_0
    //   8701: invokespecial <init> : ([BI)V
    //   8704: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8709: aload #5
    //   8711: sipush #373
    //   8714: new org/renjin/gcc/runtime/BytePtr
    //   8717: dup
    //   8718: ldc_w '#00688B '
    //   8721: invokevirtual getBytes : ()[B
    //   8724: iconst_0
    //   8725: invokespecial <init> : ([BI)V
    //   8728: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8733: aload #5
    //   8735: sipush #374
    //   8738: ldc_w -7641088
    //   8741: invokeinterface setAlignedInt : (II)V
    //   8746: aload #5
    //   8748: sipush #375
    //   8751: new org/renjin/gcc/runtime/BytePtr
    //   8754: dup
    //   8755: ldc_w 'dimgray '
    //   8758: invokevirtual getBytes : ()[B
    //   8761: iconst_0
    //   8762: invokespecial <init> : ([BI)V
    //   8765: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8770: aload #5
    //   8772: sipush #376
    //   8775: new org/renjin/gcc/runtime/BytePtr
    //   8778: dup
    //   8779: ldc_w '#696969 '
    //   8782: invokevirtual getBytes : ()[B
    //   8785: iconst_0
    //   8786: invokespecial <init> : ([BI)V
    //   8789: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8794: aload #5
    //   8796: sipush #377
    //   8799: ldc_w -9868951
    //   8802: invokeinterface setAlignedInt : (II)V
    //   8807: aload #5
    //   8809: sipush #378
    //   8812: new org/renjin/gcc/runtime/BytePtr
    //   8815: dup
    //   8816: ldc_w 'dimgrey '
    //   8819: invokevirtual getBytes : ()[B
    //   8822: iconst_0
    //   8823: invokespecial <init> : ([BI)V
    //   8826: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8831: aload #5
    //   8833: sipush #379
    //   8836: new org/renjin/gcc/runtime/BytePtr
    //   8839: dup
    //   8840: ldc_w '#696969 '
    //   8843: invokevirtual getBytes : ()[B
    //   8846: iconst_0
    //   8847: invokespecial <init> : ([BI)V
    //   8850: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8855: aload #5
    //   8857: sipush #380
    //   8860: ldc_w -9868951
    //   8863: invokeinterface setAlignedInt : (II)V
    //   8868: aload #5
    //   8870: sipush #381
    //   8873: new org/renjin/gcc/runtime/BytePtr
    //   8876: dup
    //   8877: ldc_w 'dodgerblue '
    //   8880: invokevirtual getBytes : ()[B
    //   8883: iconst_0
    //   8884: invokespecial <init> : ([BI)V
    //   8887: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8892: aload #5
    //   8894: sipush #382
    //   8897: new org/renjin/gcc/runtime/BytePtr
    //   8900: dup
    //   8901: ldc_w '#1E90FF '
    //   8904: invokevirtual getBytes : ()[B
    //   8907: iconst_0
    //   8908: invokespecial <init> : ([BI)V
    //   8911: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8916: aload #5
    //   8918: sipush #383
    //   8921: sipush #-28642
    //   8924: invokeinterface setAlignedInt : (II)V
    //   8929: aload #5
    //   8931: sipush #384
    //   8934: new org/renjin/gcc/runtime/BytePtr
    //   8937: dup
    //   8938: ldc_w 'dodgerblue1 '
    //   8941: invokevirtual getBytes : ()[B
    //   8944: iconst_0
    //   8945: invokespecial <init> : ([BI)V
    //   8948: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8953: aload #5
    //   8955: sipush #385
    //   8958: new org/renjin/gcc/runtime/BytePtr
    //   8961: dup
    //   8962: ldc_w '#1E90FF '
    //   8965: invokevirtual getBytes : ()[B
    //   8968: iconst_0
    //   8969: invokespecial <init> : ([BI)V
    //   8972: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   8977: aload #5
    //   8979: sipush #386
    //   8982: sipush #-28642
    //   8985: invokeinterface setAlignedInt : (II)V
    //   8990: aload #5
    //   8992: sipush #387
    //   8995: new org/renjin/gcc/runtime/BytePtr
    //   8998: dup
    //   8999: ldc_w 'dodgerblue2 '
    //   9002: invokevirtual getBytes : ()[B
    //   9005: iconst_0
    //   9006: invokespecial <init> : ([BI)V
    //   9009: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9014: aload #5
    //   9016: sipush #388
    //   9019: new org/renjin/gcc/runtime/BytePtr
    //   9022: dup
    //   9023: ldc_w '#1C86EE '
    //   9026: invokevirtual getBytes : ()[B
    //   9029: iconst_0
    //   9030: invokespecial <init> : ([BI)V
    //   9033: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9038: aload #5
    //   9040: sipush #389
    //   9043: ldc_w -1145316
    //   9046: invokeinterface setAlignedInt : (II)V
    //   9051: aload #5
    //   9053: sipush #390
    //   9056: new org/renjin/gcc/runtime/BytePtr
    //   9059: dup
    //   9060: ldc_w 'dodgerblue3 '
    //   9063: invokevirtual getBytes : ()[B
    //   9066: iconst_0
    //   9067: invokespecial <init> : ([BI)V
    //   9070: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9075: aload #5
    //   9077: sipush #391
    //   9080: new org/renjin/gcc/runtime/BytePtr
    //   9083: dup
    //   9084: ldc_w '#1874CD '
    //   9087: invokevirtual getBytes : ()[B
    //   9090: iconst_0
    //   9091: invokespecial <init> : ([BI)V
    //   9094: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9099: aload #5
    //   9101: sipush #392
    //   9104: ldc_w -3312616
    //   9107: invokeinterface setAlignedInt : (II)V
    //   9112: aload #5
    //   9114: sipush #393
    //   9117: new org/renjin/gcc/runtime/BytePtr
    //   9120: dup
    //   9121: ldc_w 'dodgerblue4 '
    //   9124: invokevirtual getBytes : ()[B
    //   9127: iconst_0
    //   9128: invokespecial <init> : ([BI)V
    //   9131: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9136: aload #5
    //   9138: sipush #394
    //   9141: new org/renjin/gcc/runtime/BytePtr
    //   9144: dup
    //   9145: ldc_w '#104E8B '
    //   9148: invokevirtual getBytes : ()[B
    //   9151: iconst_0
    //   9152: invokespecial <init> : ([BI)V
    //   9155: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9160: aload #5
    //   9162: sipush #395
    //   9165: ldc_w -7647728
    //   9168: invokeinterface setAlignedInt : (II)V
    //   9173: aload #5
    //   9175: sipush #396
    //   9178: new org/renjin/gcc/runtime/BytePtr
    //   9181: dup
    //   9182: ldc_w 'firebrick '
    //   9185: invokevirtual getBytes : ()[B
    //   9188: iconst_0
    //   9189: invokespecial <init> : ([BI)V
    //   9192: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9197: aload #5
    //   9199: sipush #397
    //   9202: new org/renjin/gcc/runtime/BytePtr
    //   9205: dup
    //   9206: ldc_w '#B22222 '
    //   9209: invokevirtual getBytes : ()[B
    //   9212: iconst_0
    //   9213: invokespecial <init> : ([BI)V
    //   9216: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9221: aload #5
    //   9223: sipush #398
    //   9226: ldc_w -14540110
    //   9229: invokeinterface setAlignedInt : (II)V
    //   9234: aload #5
    //   9236: sipush #399
    //   9239: new org/renjin/gcc/runtime/BytePtr
    //   9242: dup
    //   9243: ldc_w 'firebrick1 '
    //   9246: invokevirtual getBytes : ()[B
    //   9249: iconst_0
    //   9250: invokespecial <init> : ([BI)V
    //   9253: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9258: aload #5
    //   9260: sipush #400
    //   9263: new org/renjin/gcc/runtime/BytePtr
    //   9266: dup
    //   9267: ldc_w '#FF3030 '
    //   9270: invokevirtual getBytes : ()[B
    //   9273: iconst_0
    //   9274: invokespecial <init> : ([BI)V
    //   9277: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9282: aload #5
    //   9284: sipush #401
    //   9287: ldc_w -13618945
    //   9290: invokeinterface setAlignedInt : (II)V
    //   9295: aload #5
    //   9297: sipush #402
    //   9300: new org/renjin/gcc/runtime/BytePtr
    //   9303: dup
    //   9304: ldc_w 'firebrick2 '
    //   9307: invokevirtual getBytes : ()[B
    //   9310: iconst_0
    //   9311: invokespecial <init> : ([BI)V
    //   9314: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9319: aload #5
    //   9321: sipush #403
    //   9324: new org/renjin/gcc/runtime/BytePtr
    //   9327: dup
    //   9328: ldc_w '#EE2C2C '
    //   9331: invokevirtual getBytes : ()[B
    //   9334: iconst_0
    //   9335: invokespecial <init> : ([BI)V
    //   9338: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9343: aload #5
    //   9345: sipush #404
    //   9348: ldc_w -13882130
    //   9351: invokeinterface setAlignedInt : (II)V
    //   9356: aload #5
    //   9358: sipush #405
    //   9361: new org/renjin/gcc/runtime/BytePtr
    //   9364: dup
    //   9365: ldc_w 'firebrick3 '
    //   9368: invokevirtual getBytes : ()[B
    //   9371: iconst_0
    //   9372: invokespecial <init> : ([BI)V
    //   9375: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9380: aload #5
    //   9382: sipush #406
    //   9385: new org/renjin/gcc/runtime/BytePtr
    //   9388: dup
    //   9389: ldc_w '#CD2626 '
    //   9392: invokevirtual getBytes : ()[B
    //   9395: iconst_0
    //   9396: invokespecial <init> : ([BI)V
    //   9399: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9404: aload #5
    //   9406: sipush #407
    //   9409: ldc_w -14276915
    //   9412: invokeinterface setAlignedInt : (II)V
    //   9417: aload #5
    //   9419: sipush #408
    //   9422: new org/renjin/gcc/runtime/BytePtr
    //   9425: dup
    //   9426: ldc_w 'firebrick4 '
    //   9429: invokevirtual getBytes : ()[B
    //   9432: iconst_0
    //   9433: invokespecial <init> : ([BI)V
    //   9436: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9441: aload #5
    //   9443: sipush #409
    //   9446: new org/renjin/gcc/runtime/BytePtr
    //   9449: dup
    //   9450: ldc_w '#8B1A1A '
    //   9453: invokevirtual getBytes : ()[B
    //   9456: iconst_0
    //   9457: invokespecial <init> : ([BI)V
    //   9460: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9465: aload #5
    //   9467: sipush #410
    //   9470: ldc_w -15066485
    //   9473: invokeinterface setAlignedInt : (II)V
    //   9478: aload #5
    //   9480: sipush #411
    //   9483: new org/renjin/gcc/runtime/BytePtr
    //   9486: dup
    //   9487: ldc_w 'floralwhite '
    //   9490: invokevirtual getBytes : ()[B
    //   9493: iconst_0
    //   9494: invokespecial <init> : ([BI)V
    //   9497: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9502: aload #5
    //   9504: sipush #412
    //   9507: new org/renjin/gcc/runtime/BytePtr
    //   9510: dup
    //   9511: ldc_w '#FFFAF0 '
    //   9514: invokevirtual getBytes : ()[B
    //   9517: iconst_0
    //   9518: invokespecial <init> : ([BI)V
    //   9521: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9526: aload #5
    //   9528: sipush #413
    //   9531: ldc_w -984321
    //   9534: invokeinterface setAlignedInt : (II)V
    //   9539: aload #5
    //   9541: sipush #414
    //   9544: new org/renjin/gcc/runtime/BytePtr
    //   9547: dup
    //   9548: ldc_w 'forestgreen '
    //   9551: invokevirtual getBytes : ()[B
    //   9554: iconst_0
    //   9555: invokespecial <init> : ([BI)V
    //   9558: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9563: aload #5
    //   9565: sipush #415
    //   9568: new org/renjin/gcc/runtime/BytePtr
    //   9571: dup
    //   9572: ldc_w '#228B22 '
    //   9575: invokevirtual getBytes : ()[B
    //   9578: iconst_0
    //   9579: invokespecial <init> : ([BI)V
    //   9582: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9587: aload #5
    //   9589: sipush #416
    //   9592: ldc_w -14513374
    //   9595: invokeinterface setAlignedInt : (II)V
    //   9600: aload #5
    //   9602: sipush #417
    //   9605: new org/renjin/gcc/runtime/BytePtr
    //   9608: dup
    //   9609: ldc_w 'gainsboro '
    //   9612: invokevirtual getBytes : ()[B
    //   9615: iconst_0
    //   9616: invokespecial <init> : ([BI)V
    //   9619: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9624: aload #5
    //   9626: sipush #418
    //   9629: new org/renjin/gcc/runtime/BytePtr
    //   9632: dup
    //   9633: ldc_w '#DCDCDC '
    //   9636: invokevirtual getBytes : ()[B
    //   9639: iconst_0
    //   9640: invokespecial <init> : ([BI)V
    //   9643: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9648: aload #5
    //   9650: sipush #419
    //   9653: ldc_w -2302756
    //   9656: invokeinterface setAlignedInt : (II)V
    //   9661: aload #5
    //   9663: sipush #420
    //   9666: new org/renjin/gcc/runtime/BytePtr
    //   9669: dup
    //   9670: ldc_w 'ghostwhite '
    //   9673: invokevirtual getBytes : ()[B
    //   9676: iconst_0
    //   9677: invokespecial <init> : ([BI)V
    //   9680: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9685: aload #5
    //   9687: sipush #421
    //   9690: new org/renjin/gcc/runtime/BytePtr
    //   9693: dup
    //   9694: ldc_w '#F8F8FF '
    //   9697: invokevirtual getBytes : ()[B
    //   9700: iconst_0
    //   9701: invokespecial <init> : ([BI)V
    //   9704: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9709: aload #5
    //   9711: sipush #422
    //   9714: sipush #-1800
    //   9717: invokeinterface setAlignedInt : (II)V
    //   9722: aload #5
    //   9724: sipush #423
    //   9727: new org/renjin/gcc/runtime/BytePtr
    //   9730: dup
    //   9731: ldc_w 'gold '
    //   9734: invokevirtual getBytes : ()[B
    //   9737: iconst_0
    //   9738: invokespecial <init> : ([BI)V
    //   9741: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9746: aload #5
    //   9748: sipush #424
    //   9751: new org/renjin/gcc/runtime/BytePtr
    //   9754: dup
    //   9755: ldc_w '#FFD700 '
    //   9758: invokevirtual getBytes : ()[B
    //   9761: iconst_0
    //   9762: invokespecial <init> : ([BI)V
    //   9765: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9770: aload #5
    //   9772: sipush #425
    //   9775: ldc_w -16721921
    //   9778: invokeinterface setAlignedInt : (II)V
    //   9783: aload #5
    //   9785: sipush #426
    //   9788: new org/renjin/gcc/runtime/BytePtr
    //   9791: dup
    //   9792: ldc_w 'gold1 '
    //   9795: invokevirtual getBytes : ()[B
    //   9798: iconst_0
    //   9799: invokespecial <init> : ([BI)V
    //   9802: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9807: aload #5
    //   9809: sipush #427
    //   9812: new org/renjin/gcc/runtime/BytePtr
    //   9815: dup
    //   9816: ldc_w '#FFD700 '
    //   9819: invokevirtual getBytes : ()[B
    //   9822: iconst_0
    //   9823: invokespecial <init> : ([BI)V
    //   9826: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9831: aload #5
    //   9833: sipush #428
    //   9836: ldc_w -16721921
    //   9839: invokeinterface setAlignedInt : (II)V
    //   9844: aload #5
    //   9846: sipush #429
    //   9849: new org/renjin/gcc/runtime/BytePtr
    //   9852: dup
    //   9853: ldc_w 'gold2 '
    //   9856: invokevirtual getBytes : ()[B
    //   9859: iconst_0
    //   9860: invokespecial <init> : ([BI)V
    //   9863: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9868: aload #5
    //   9870: sipush #430
    //   9873: new org/renjin/gcc/runtime/BytePtr
    //   9876: dup
    //   9877: ldc_w '#EEC900 '
    //   9880: invokevirtual getBytes : ()[B
    //   9883: iconst_0
    //   9884: invokespecial <init> : ([BI)V
    //   9887: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9892: aload #5
    //   9894: sipush #431
    //   9897: ldc_w -16725522
    //   9900: invokeinterface setAlignedInt : (II)V
    //   9905: aload #5
    //   9907: sipush #432
    //   9910: new org/renjin/gcc/runtime/BytePtr
    //   9913: dup
    //   9914: ldc_w 'gold3 '
    //   9917: invokevirtual getBytes : ()[B
    //   9920: iconst_0
    //   9921: invokespecial <init> : ([BI)V
    //   9924: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9929: aload #5
    //   9931: sipush #433
    //   9934: new org/renjin/gcc/runtime/BytePtr
    //   9937: dup
    //   9938: ldc_w '#CDAD00 '
    //   9941: invokevirtual getBytes : ()[B
    //   9944: iconst_0
    //   9945: invokespecial <init> : ([BI)V
    //   9948: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9953: aload #5
    //   9955: sipush #434
    //   9958: ldc_w -16732723
    //   9961: invokeinterface setAlignedInt : (II)V
    //   9966: aload #5
    //   9968: sipush #435
    //   9971: new org/renjin/gcc/runtime/BytePtr
    //   9974: dup
    //   9975: ldc_w 'gold4 '
    //   9978: invokevirtual getBytes : ()[B
    //   9981: iconst_0
    //   9982: invokespecial <init> : ([BI)V
    //   9985: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   9990: aload #5
    //   9992: sipush #436
    //   9995: new org/renjin/gcc/runtime/BytePtr
    //   9998: dup
    //   9999: ldc_w '#8B7500 '
    //   10002: invokevirtual getBytes : ()[B
    //   10005: iconst_0
    //   10006: invokespecial <init> : ([BI)V
    //   10009: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10014: aload #5
    //   10016: sipush #437
    //   10019: ldc_w -16747125
    //   10022: invokeinterface setAlignedInt : (II)V
    //   10027: aload #5
    //   10029: sipush #438
    //   10032: new org/renjin/gcc/runtime/BytePtr
    //   10035: dup
    //   10036: ldc_w 'goldenrod '
    //   10039: invokevirtual getBytes : ()[B
    //   10042: iconst_0
    //   10043: invokespecial <init> : ([BI)V
    //   10046: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10051: aload #5
    //   10053: sipush #439
    //   10056: new org/renjin/gcc/runtime/BytePtr
    //   10059: dup
    //   10060: ldc_w '#DAA520 '
    //   10063: invokevirtual getBytes : ()[B
    //   10066: iconst_0
    //   10067: invokespecial <init> : ([BI)V
    //   10070: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10075: aload #5
    //   10077: sipush #440
    //   10080: ldc_w -14637606
    //   10083: invokeinterface setAlignedInt : (II)V
    //   10088: aload #5
    //   10090: sipush #441
    //   10093: new org/renjin/gcc/runtime/BytePtr
    //   10096: dup
    //   10097: ldc_w 'goldenrod1 '
    //   10100: invokevirtual getBytes : ()[B
    //   10103: iconst_0
    //   10104: invokespecial <init> : ([BI)V
    //   10107: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10112: aload #5
    //   10114: sipush #442
    //   10117: new org/renjin/gcc/runtime/BytePtr
    //   10120: dup
    //   10121: ldc_w '#FFC125 '
    //   10124: invokevirtual getBytes : ()[B
    //   10127: iconst_0
    //   10128: invokespecial <init> : ([BI)V
    //   10131: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10136: aload #5
    //   10138: sipush #443
    //   10141: ldc_w -14302721
    //   10144: invokeinterface setAlignedInt : (II)V
    //   10149: aload #5
    //   10151: sipush #444
    //   10154: new org/renjin/gcc/runtime/BytePtr
    //   10157: dup
    //   10158: ldc_w 'goldenrod2 '
    //   10161: invokevirtual getBytes : ()[B
    //   10164: iconst_0
    //   10165: invokespecial <init> : ([BI)V
    //   10168: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10173: aload #5
    //   10175: sipush #445
    //   10178: new org/renjin/gcc/runtime/BytePtr
    //   10181: dup
    //   10182: ldc_w '#EEB422 '
    //   10185: invokevirtual getBytes : ()[B
    //   10188: iconst_0
    //   10189: invokespecial <init> : ([BI)V
    //   10192: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10197: aload #5
    //   10199: sipush #446
    //   10202: ldc_w -14502674
    //   10205: invokeinterface setAlignedInt : (II)V
    //   10210: aload #5
    //   10212: sipush #447
    //   10215: new org/renjin/gcc/runtime/BytePtr
    //   10218: dup
    //   10219: ldc_w 'goldenrod3 '
    //   10222: invokevirtual getBytes : ()[B
    //   10225: iconst_0
    //   10226: invokespecial <init> : ([BI)V
    //   10229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10234: aload #5
    //   10236: sipush #448
    //   10239: new org/renjin/gcc/runtime/BytePtr
    //   10242: dup
    //   10243: ldc_w '#CD9B1D '
    //   10246: invokevirtual getBytes : ()[B
    //   10249: iconst_0
    //   10250: invokespecial <init> : ([BI)V
    //   10253: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10258: aload #5
    //   10260: sipush #449
    //   10263: ldc_w -14836787
    //   10266: invokeinterface setAlignedInt : (II)V
    //   10271: aload #5
    //   10273: sipush #450
    //   10276: new org/renjin/gcc/runtime/BytePtr
    //   10279: dup
    //   10280: ldc_w 'goldenrod4 '
    //   10283: invokevirtual getBytes : ()[B
    //   10286: iconst_0
    //   10287: invokespecial <init> : ([BI)V
    //   10290: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10295: aload #5
    //   10297: sipush #451
    //   10300: new org/renjin/gcc/runtime/BytePtr
    //   10303: dup
    //   10304: ldc_w '#8B6914 '
    //   10307: invokevirtual getBytes : ()[B
    //   10310: iconst_0
    //   10311: invokespecial <init> : ([BI)V
    //   10314: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10319: aload #5
    //   10321: sipush #452
    //   10324: ldc_w -15439477
    //   10327: invokeinterface setAlignedInt : (II)V
    //   10332: aload #5
    //   10334: sipush #453
    //   10337: new org/renjin/gcc/runtime/BytePtr
    //   10340: dup
    //   10341: ldc_w 'gray '
    //   10344: invokevirtual getBytes : ()[B
    //   10347: iconst_0
    //   10348: invokespecial <init> : ([BI)V
    //   10351: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10356: aload #5
    //   10358: sipush #454
    //   10361: new org/renjin/gcc/runtime/BytePtr
    //   10364: dup
    //   10365: ldc_w '#BEBEBE '
    //   10368: invokevirtual getBytes : ()[B
    //   10371: iconst_0
    //   10372: invokespecial <init> : ([BI)V
    //   10375: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10380: aload #5
    //   10382: sipush #455
    //   10385: ldc_w -4276546
    //   10388: invokeinterface setAlignedInt : (II)V
    //   10393: aload #5
    //   10395: sipush #456
    //   10398: new org/renjin/gcc/runtime/BytePtr
    //   10401: dup
    //   10402: ldc_w 'gray0 '
    //   10405: invokevirtual getBytes : ()[B
    //   10408: iconst_0
    //   10409: invokespecial <init> : ([BI)V
    //   10412: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10417: aload #5
    //   10419: sipush #457
    //   10422: new org/renjin/gcc/runtime/BytePtr
    //   10425: dup
    //   10426: ldc_w '#000000 '
    //   10429: invokevirtual getBytes : ()[B
    //   10432: iconst_0
    //   10433: invokespecial <init> : ([BI)V
    //   10436: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10441: aload #5
    //   10443: sipush #458
    //   10446: ldc_w -16777216
    //   10449: invokeinterface setAlignedInt : (II)V
    //   10454: aload #5
    //   10456: sipush #459
    //   10459: new org/renjin/gcc/runtime/BytePtr
    //   10462: dup
    //   10463: ldc_w 'gray1 '
    //   10466: invokevirtual getBytes : ()[B
    //   10469: iconst_0
    //   10470: invokespecial <init> : ([BI)V
    //   10473: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10478: aload #5
    //   10480: sipush #460
    //   10483: new org/renjin/gcc/runtime/BytePtr
    //   10486: dup
    //   10487: ldc_w '#030303 '
    //   10490: invokevirtual getBytes : ()[B
    //   10493: iconst_0
    //   10494: invokespecial <init> : ([BI)V
    //   10497: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10502: aload #5
    //   10504: sipush #461
    //   10507: ldc_w -16579837
    //   10510: invokeinterface setAlignedInt : (II)V
    //   10515: aload #5
    //   10517: sipush #462
    //   10520: new org/renjin/gcc/runtime/BytePtr
    //   10523: dup
    //   10524: ldc_w 'gray2 '
    //   10527: invokevirtual getBytes : ()[B
    //   10530: iconst_0
    //   10531: invokespecial <init> : ([BI)V
    //   10534: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10539: aload #5
    //   10541: sipush #463
    //   10544: new org/renjin/gcc/runtime/BytePtr
    //   10547: dup
    //   10548: ldc_w '#050505 '
    //   10551: invokevirtual getBytes : ()[B
    //   10554: iconst_0
    //   10555: invokespecial <init> : ([BI)V
    //   10558: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10563: aload #5
    //   10565: sipush #464
    //   10568: ldc_w -16448251
    //   10571: invokeinterface setAlignedInt : (II)V
    //   10576: aload #5
    //   10578: sipush #465
    //   10581: new org/renjin/gcc/runtime/BytePtr
    //   10584: dup
    //   10585: ldc_w 'gray3 '
    //   10588: invokevirtual getBytes : ()[B
    //   10591: iconst_0
    //   10592: invokespecial <init> : ([BI)V
    //   10595: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10600: aload #5
    //   10602: sipush #466
    //   10605: new org/renjin/gcc/runtime/BytePtr
    //   10608: dup
    //   10609: ldc_w '#080808 '
    //   10612: invokevirtual getBytes : ()[B
    //   10615: iconst_0
    //   10616: invokespecial <init> : ([BI)V
    //   10619: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10624: aload #5
    //   10626: sipush #467
    //   10629: ldc_w -16250872
    //   10632: invokeinterface setAlignedInt : (II)V
    //   10637: aload #5
    //   10639: sipush #468
    //   10642: new org/renjin/gcc/runtime/BytePtr
    //   10645: dup
    //   10646: ldc_w 'gray4 '
    //   10649: invokevirtual getBytes : ()[B
    //   10652: iconst_0
    //   10653: invokespecial <init> : ([BI)V
    //   10656: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10661: aload #5
    //   10663: sipush #469
    //   10666: new org/renjin/gcc/runtime/BytePtr
    //   10669: dup
    //   10670: ldc_w '#0A0A0A '
    //   10673: invokevirtual getBytes : ()[B
    //   10676: iconst_0
    //   10677: invokespecial <init> : ([BI)V
    //   10680: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10685: aload #5
    //   10687: sipush #470
    //   10690: ldc_w -16119286
    //   10693: invokeinterface setAlignedInt : (II)V
    //   10698: aload #5
    //   10700: sipush #471
    //   10703: new org/renjin/gcc/runtime/BytePtr
    //   10706: dup
    //   10707: ldc_w 'gray5 '
    //   10710: invokevirtual getBytes : ()[B
    //   10713: iconst_0
    //   10714: invokespecial <init> : ([BI)V
    //   10717: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10722: aload #5
    //   10724: sipush #472
    //   10727: new org/renjin/gcc/runtime/BytePtr
    //   10730: dup
    //   10731: ldc_w '#0D0D0D '
    //   10734: invokevirtual getBytes : ()[B
    //   10737: iconst_0
    //   10738: invokespecial <init> : ([BI)V
    //   10741: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10746: aload #5
    //   10748: sipush #473
    //   10751: ldc_w -15921907
    //   10754: invokeinterface setAlignedInt : (II)V
    //   10759: aload #5
    //   10761: sipush #474
    //   10764: new org/renjin/gcc/runtime/BytePtr
    //   10767: dup
    //   10768: ldc_w 'gray6 '
    //   10771: invokevirtual getBytes : ()[B
    //   10774: iconst_0
    //   10775: invokespecial <init> : ([BI)V
    //   10778: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10783: aload #5
    //   10785: sipush #475
    //   10788: new org/renjin/gcc/runtime/BytePtr
    //   10791: dup
    //   10792: ldc_w '#0F0F0F '
    //   10795: invokevirtual getBytes : ()[B
    //   10798: iconst_0
    //   10799: invokespecial <init> : ([BI)V
    //   10802: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10807: aload #5
    //   10809: sipush #476
    //   10812: ldc_w -15790321
    //   10815: invokeinterface setAlignedInt : (II)V
    //   10820: aload #5
    //   10822: sipush #477
    //   10825: new org/renjin/gcc/runtime/BytePtr
    //   10828: dup
    //   10829: ldc_w 'gray7 '
    //   10832: invokevirtual getBytes : ()[B
    //   10835: iconst_0
    //   10836: invokespecial <init> : ([BI)V
    //   10839: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10844: aload #5
    //   10846: sipush #478
    //   10849: new org/renjin/gcc/runtime/BytePtr
    //   10852: dup
    //   10853: ldc_w '#121212 '
    //   10856: invokevirtual getBytes : ()[B
    //   10859: iconst_0
    //   10860: invokespecial <init> : ([BI)V
    //   10863: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10868: aload #5
    //   10870: sipush #479
    //   10873: ldc_w -15592942
    //   10876: invokeinterface setAlignedInt : (II)V
    //   10881: aload #5
    //   10883: sipush #480
    //   10886: new org/renjin/gcc/runtime/BytePtr
    //   10889: dup
    //   10890: ldc_w 'gray8 '
    //   10893: invokevirtual getBytes : ()[B
    //   10896: iconst_0
    //   10897: invokespecial <init> : ([BI)V
    //   10900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10905: aload #5
    //   10907: sipush #481
    //   10910: new org/renjin/gcc/runtime/BytePtr
    //   10913: dup
    //   10914: ldc_w '#141414 '
    //   10917: invokevirtual getBytes : ()[B
    //   10920: iconst_0
    //   10921: invokespecial <init> : ([BI)V
    //   10924: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10929: aload #5
    //   10931: sipush #482
    //   10934: ldc_w -15461356
    //   10937: invokeinterface setAlignedInt : (II)V
    //   10942: aload #5
    //   10944: sipush #483
    //   10947: new org/renjin/gcc/runtime/BytePtr
    //   10950: dup
    //   10951: ldc_w 'gray9 '
    //   10954: invokevirtual getBytes : ()[B
    //   10957: iconst_0
    //   10958: invokespecial <init> : ([BI)V
    //   10961: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10966: aload #5
    //   10968: sipush #484
    //   10971: new org/renjin/gcc/runtime/BytePtr
    //   10974: dup
    //   10975: ldc_w '#171717 '
    //   10978: invokevirtual getBytes : ()[B
    //   10981: iconst_0
    //   10982: invokespecial <init> : ([BI)V
    //   10985: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   10990: aload #5
    //   10992: sipush #485
    //   10995: ldc_w -15263977
    //   10998: invokeinterface setAlignedInt : (II)V
    //   11003: aload #5
    //   11005: sipush #486
    //   11008: new org/renjin/gcc/runtime/BytePtr
    //   11011: dup
    //   11012: ldc_w 'gray10 '
    //   11015: invokevirtual getBytes : ()[B
    //   11018: iconst_0
    //   11019: invokespecial <init> : ([BI)V
    //   11022: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11027: aload #5
    //   11029: sipush #487
    //   11032: new org/renjin/gcc/runtime/BytePtr
    //   11035: dup
    //   11036: ldc_w '#1A1A1A '
    //   11039: invokevirtual getBytes : ()[B
    //   11042: iconst_0
    //   11043: invokespecial <init> : ([BI)V
    //   11046: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11051: aload #5
    //   11053: sipush #488
    //   11056: ldc_w -15066598
    //   11059: invokeinterface setAlignedInt : (II)V
    //   11064: aload #5
    //   11066: sipush #489
    //   11069: new org/renjin/gcc/runtime/BytePtr
    //   11072: dup
    //   11073: ldc_w 'gray11 '
    //   11076: invokevirtual getBytes : ()[B
    //   11079: iconst_0
    //   11080: invokespecial <init> : ([BI)V
    //   11083: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11088: aload #5
    //   11090: sipush #490
    //   11093: new org/renjin/gcc/runtime/BytePtr
    //   11096: dup
    //   11097: ldc_w '#1C1C1C '
    //   11100: invokevirtual getBytes : ()[B
    //   11103: iconst_0
    //   11104: invokespecial <init> : ([BI)V
    //   11107: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11112: aload #5
    //   11114: sipush #491
    //   11117: ldc_w -14935012
    //   11120: invokeinterface setAlignedInt : (II)V
    //   11125: aload #5
    //   11127: sipush #492
    //   11130: new org/renjin/gcc/runtime/BytePtr
    //   11133: dup
    //   11134: ldc_w 'gray12 '
    //   11137: invokevirtual getBytes : ()[B
    //   11140: iconst_0
    //   11141: invokespecial <init> : ([BI)V
    //   11144: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11149: aload #5
    //   11151: sipush #493
    //   11154: new org/renjin/gcc/runtime/BytePtr
    //   11157: dup
    //   11158: ldc_w '#1F1F1F '
    //   11161: invokevirtual getBytes : ()[B
    //   11164: iconst_0
    //   11165: invokespecial <init> : ([BI)V
    //   11168: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11173: aload #5
    //   11175: sipush #494
    //   11178: ldc_w -14737633
    //   11181: invokeinterface setAlignedInt : (II)V
    //   11186: aload #5
    //   11188: sipush #495
    //   11191: new org/renjin/gcc/runtime/BytePtr
    //   11194: dup
    //   11195: ldc_w 'gray13 '
    //   11198: invokevirtual getBytes : ()[B
    //   11201: iconst_0
    //   11202: invokespecial <init> : ([BI)V
    //   11205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11210: aload #5
    //   11212: sipush #496
    //   11215: new org/renjin/gcc/runtime/BytePtr
    //   11218: dup
    //   11219: ldc_w '#212121 '
    //   11222: invokevirtual getBytes : ()[B
    //   11225: iconst_0
    //   11226: invokespecial <init> : ([BI)V
    //   11229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11234: aload #5
    //   11236: sipush #497
    //   11239: ldc_w -14606047
    //   11242: invokeinterface setAlignedInt : (II)V
    //   11247: aload #5
    //   11249: sipush #498
    //   11252: new org/renjin/gcc/runtime/BytePtr
    //   11255: dup
    //   11256: ldc_w 'gray14 '
    //   11259: invokevirtual getBytes : ()[B
    //   11262: iconst_0
    //   11263: invokespecial <init> : ([BI)V
    //   11266: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11271: aload #5
    //   11273: sipush #499
    //   11276: new org/renjin/gcc/runtime/BytePtr
    //   11279: dup
    //   11280: ldc_w '#242424 '
    //   11283: invokevirtual getBytes : ()[B
    //   11286: iconst_0
    //   11287: invokespecial <init> : ([BI)V
    //   11290: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11295: aload #5
    //   11297: sipush #500
    //   11300: ldc_w -14408668
    //   11303: invokeinterface setAlignedInt : (II)V
    //   11308: aload #5
    //   11310: sipush #501
    //   11313: new org/renjin/gcc/runtime/BytePtr
    //   11316: dup
    //   11317: ldc_w 'gray15 '
    //   11320: invokevirtual getBytes : ()[B
    //   11323: iconst_0
    //   11324: invokespecial <init> : ([BI)V
    //   11327: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11332: aload #5
    //   11334: sipush #502
    //   11337: new org/renjin/gcc/runtime/BytePtr
    //   11340: dup
    //   11341: ldc_w '#262626 '
    //   11344: invokevirtual getBytes : ()[B
    //   11347: iconst_0
    //   11348: invokespecial <init> : ([BI)V
    //   11351: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11356: aload #5
    //   11358: sipush #503
    //   11361: ldc_w -14277082
    //   11364: invokeinterface setAlignedInt : (II)V
    //   11369: aload #5
    //   11371: sipush #504
    //   11374: new org/renjin/gcc/runtime/BytePtr
    //   11377: dup
    //   11378: ldc_w 'gray16 '
    //   11381: invokevirtual getBytes : ()[B
    //   11384: iconst_0
    //   11385: invokespecial <init> : ([BI)V
    //   11388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11393: aload #5
    //   11395: sipush #505
    //   11398: new org/renjin/gcc/runtime/BytePtr
    //   11401: dup
    //   11402: ldc_w '#292929 '
    //   11405: invokevirtual getBytes : ()[B
    //   11408: iconst_0
    //   11409: invokespecial <init> : ([BI)V
    //   11412: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11417: aload #5
    //   11419: sipush #506
    //   11422: ldc_w -14079703
    //   11425: invokeinterface setAlignedInt : (II)V
    //   11430: aload #5
    //   11432: sipush #507
    //   11435: new org/renjin/gcc/runtime/BytePtr
    //   11438: dup
    //   11439: ldc_w 'gray17 '
    //   11442: invokevirtual getBytes : ()[B
    //   11445: iconst_0
    //   11446: invokespecial <init> : ([BI)V
    //   11449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11454: aload #5
    //   11456: sipush #508
    //   11459: new org/renjin/gcc/runtime/BytePtr
    //   11462: dup
    //   11463: ldc_w '#2B2B2B '
    //   11466: invokevirtual getBytes : ()[B
    //   11469: iconst_0
    //   11470: invokespecial <init> : ([BI)V
    //   11473: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11478: aload #5
    //   11480: sipush #509
    //   11483: ldc_w -13948117
    //   11486: invokeinterface setAlignedInt : (II)V
    //   11491: aload #5
    //   11493: sipush #510
    //   11496: new org/renjin/gcc/runtime/BytePtr
    //   11499: dup
    //   11500: ldc_w 'gray18 '
    //   11503: invokevirtual getBytes : ()[B
    //   11506: iconst_0
    //   11507: invokespecial <init> : ([BI)V
    //   11510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11515: aload #5
    //   11517: sipush #511
    //   11520: new org/renjin/gcc/runtime/BytePtr
    //   11523: dup
    //   11524: ldc_w '#2E2E2E '
    //   11527: invokevirtual getBytes : ()[B
    //   11530: iconst_0
    //   11531: invokespecial <init> : ([BI)V
    //   11534: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11539: aload #5
    //   11541: sipush #512
    //   11544: ldc_w -13750738
    //   11547: invokeinterface setAlignedInt : (II)V
    //   11552: aload #5
    //   11554: sipush #513
    //   11557: new org/renjin/gcc/runtime/BytePtr
    //   11560: dup
    //   11561: ldc_w 'gray19 '
    //   11564: invokevirtual getBytes : ()[B
    //   11567: iconst_0
    //   11568: invokespecial <init> : ([BI)V
    //   11571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11576: aload #5
    //   11578: sipush #514
    //   11581: new org/renjin/gcc/runtime/BytePtr
    //   11584: dup
    //   11585: ldc_w '#303030 '
    //   11588: invokevirtual getBytes : ()[B
    //   11591: iconst_0
    //   11592: invokespecial <init> : ([BI)V
    //   11595: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11600: aload #5
    //   11602: sipush #515
    //   11605: ldc_w -13619152
    //   11608: invokeinterface setAlignedInt : (II)V
    //   11613: aload #5
    //   11615: sipush #516
    //   11618: new org/renjin/gcc/runtime/BytePtr
    //   11621: dup
    //   11622: ldc_w 'gray20 '
    //   11625: invokevirtual getBytes : ()[B
    //   11628: iconst_0
    //   11629: invokespecial <init> : ([BI)V
    //   11632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11637: aload #5
    //   11639: sipush #517
    //   11642: new org/renjin/gcc/runtime/BytePtr
    //   11645: dup
    //   11646: ldc_w '#333333 '
    //   11649: invokevirtual getBytes : ()[B
    //   11652: iconst_0
    //   11653: invokespecial <init> : ([BI)V
    //   11656: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11661: aload #5
    //   11663: sipush #518
    //   11666: ldc_w -13421773
    //   11669: invokeinterface setAlignedInt : (II)V
    //   11674: aload #5
    //   11676: sipush #519
    //   11679: new org/renjin/gcc/runtime/BytePtr
    //   11682: dup
    //   11683: ldc_w 'gray21 '
    //   11686: invokevirtual getBytes : ()[B
    //   11689: iconst_0
    //   11690: invokespecial <init> : ([BI)V
    //   11693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11698: aload #5
    //   11700: sipush #520
    //   11703: new org/renjin/gcc/runtime/BytePtr
    //   11706: dup
    //   11707: ldc_w '#363636 '
    //   11710: invokevirtual getBytes : ()[B
    //   11713: iconst_0
    //   11714: invokespecial <init> : ([BI)V
    //   11717: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11722: aload #5
    //   11724: sipush #521
    //   11727: ldc_w -13224394
    //   11730: invokeinterface setAlignedInt : (II)V
    //   11735: aload #5
    //   11737: sipush #522
    //   11740: new org/renjin/gcc/runtime/BytePtr
    //   11743: dup
    //   11744: ldc_w 'gray22 '
    //   11747: invokevirtual getBytes : ()[B
    //   11750: iconst_0
    //   11751: invokespecial <init> : ([BI)V
    //   11754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11759: aload #5
    //   11761: sipush #523
    //   11764: new org/renjin/gcc/runtime/BytePtr
    //   11767: dup
    //   11768: ldc_w '#383838 '
    //   11771: invokevirtual getBytes : ()[B
    //   11774: iconst_0
    //   11775: invokespecial <init> : ([BI)V
    //   11778: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11783: aload #5
    //   11785: sipush #524
    //   11788: ldc_w -13092808
    //   11791: invokeinterface setAlignedInt : (II)V
    //   11796: aload #5
    //   11798: sipush #525
    //   11801: new org/renjin/gcc/runtime/BytePtr
    //   11804: dup
    //   11805: ldc_w 'gray23 '
    //   11808: invokevirtual getBytes : ()[B
    //   11811: iconst_0
    //   11812: invokespecial <init> : ([BI)V
    //   11815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11820: aload #5
    //   11822: sipush #526
    //   11825: new org/renjin/gcc/runtime/BytePtr
    //   11828: dup
    //   11829: ldc_w '#3B3B3B '
    //   11832: invokevirtual getBytes : ()[B
    //   11835: iconst_0
    //   11836: invokespecial <init> : ([BI)V
    //   11839: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11844: aload #5
    //   11846: sipush #527
    //   11849: ldc_w -12895429
    //   11852: invokeinterface setAlignedInt : (II)V
    //   11857: aload #5
    //   11859: sipush #528
    //   11862: new org/renjin/gcc/runtime/BytePtr
    //   11865: dup
    //   11866: ldc_w 'gray24 '
    //   11869: invokevirtual getBytes : ()[B
    //   11872: iconst_0
    //   11873: invokespecial <init> : ([BI)V
    //   11876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11881: aload #5
    //   11883: sipush #529
    //   11886: new org/renjin/gcc/runtime/BytePtr
    //   11889: dup
    //   11890: ldc_w '#3D3D3D '
    //   11893: invokevirtual getBytes : ()[B
    //   11896: iconst_0
    //   11897: invokespecial <init> : ([BI)V
    //   11900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11905: aload #5
    //   11907: sipush #530
    //   11910: ldc_w -12763843
    //   11913: invokeinterface setAlignedInt : (II)V
    //   11918: aload #5
    //   11920: sipush #531
    //   11923: new org/renjin/gcc/runtime/BytePtr
    //   11926: dup
    //   11927: ldc_w 'gray25 '
    //   11930: invokevirtual getBytes : ()[B
    //   11933: iconst_0
    //   11934: invokespecial <init> : ([BI)V
    //   11937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11942: aload #5
    //   11944: sipush #532
    //   11947: new org/renjin/gcc/runtime/BytePtr
    //   11950: dup
    //   11951: ldc_w '#404040 '
    //   11954: invokevirtual getBytes : ()[B
    //   11957: iconst_0
    //   11958: invokespecial <init> : ([BI)V
    //   11961: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   11966: aload #5
    //   11968: sipush #533
    //   11971: ldc_w -12566464
    //   11974: invokeinterface setAlignedInt : (II)V
    //   11979: aload #5
    //   11981: sipush #534
    //   11984: new org/renjin/gcc/runtime/BytePtr
    //   11987: dup
    //   11988: ldc_w 'gray26 '
    //   11991: invokevirtual getBytes : ()[B
    //   11994: iconst_0
    //   11995: invokespecial <init> : ([BI)V
    //   11998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12003: aload #5
    //   12005: sipush #535
    //   12008: new org/renjin/gcc/runtime/BytePtr
    //   12011: dup
    //   12012: ldc_w '#424242 '
    //   12015: invokevirtual getBytes : ()[B
    //   12018: iconst_0
    //   12019: invokespecial <init> : ([BI)V
    //   12022: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12027: aload #5
    //   12029: sipush #536
    //   12032: ldc_w -12434878
    //   12035: invokeinterface setAlignedInt : (II)V
    //   12040: aload #5
    //   12042: sipush #537
    //   12045: new org/renjin/gcc/runtime/BytePtr
    //   12048: dup
    //   12049: ldc_w 'gray27 '
    //   12052: invokevirtual getBytes : ()[B
    //   12055: iconst_0
    //   12056: invokespecial <init> : ([BI)V
    //   12059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12064: aload #5
    //   12066: sipush #538
    //   12069: new org/renjin/gcc/runtime/BytePtr
    //   12072: dup
    //   12073: ldc_w '#454545 '
    //   12076: invokevirtual getBytes : ()[B
    //   12079: iconst_0
    //   12080: invokespecial <init> : ([BI)V
    //   12083: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12088: aload #5
    //   12090: sipush #539
    //   12093: ldc_w -12237499
    //   12096: invokeinterface setAlignedInt : (II)V
    //   12101: aload #5
    //   12103: sipush #540
    //   12106: new org/renjin/gcc/runtime/BytePtr
    //   12109: dup
    //   12110: ldc_w 'gray28 '
    //   12113: invokevirtual getBytes : ()[B
    //   12116: iconst_0
    //   12117: invokespecial <init> : ([BI)V
    //   12120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12125: aload #5
    //   12127: sipush #541
    //   12130: new org/renjin/gcc/runtime/BytePtr
    //   12133: dup
    //   12134: ldc_w '#474747 '
    //   12137: invokevirtual getBytes : ()[B
    //   12140: iconst_0
    //   12141: invokespecial <init> : ([BI)V
    //   12144: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12149: aload #5
    //   12151: sipush #542
    //   12154: ldc_w -12105913
    //   12157: invokeinterface setAlignedInt : (II)V
    //   12162: aload #5
    //   12164: sipush #543
    //   12167: new org/renjin/gcc/runtime/BytePtr
    //   12170: dup
    //   12171: ldc_w 'gray29 '
    //   12174: invokevirtual getBytes : ()[B
    //   12177: iconst_0
    //   12178: invokespecial <init> : ([BI)V
    //   12181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12186: aload #5
    //   12188: sipush #544
    //   12191: new org/renjin/gcc/runtime/BytePtr
    //   12194: dup
    //   12195: ldc_w '#4A4A4A '
    //   12198: invokevirtual getBytes : ()[B
    //   12201: iconst_0
    //   12202: invokespecial <init> : ([BI)V
    //   12205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12210: aload #5
    //   12212: sipush #545
    //   12215: ldc_w -11908534
    //   12218: invokeinterface setAlignedInt : (II)V
    //   12223: aload #5
    //   12225: sipush #546
    //   12228: new org/renjin/gcc/runtime/BytePtr
    //   12231: dup
    //   12232: ldc_w 'gray30 '
    //   12235: invokevirtual getBytes : ()[B
    //   12238: iconst_0
    //   12239: invokespecial <init> : ([BI)V
    //   12242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12247: aload #5
    //   12249: sipush #547
    //   12252: new org/renjin/gcc/runtime/BytePtr
    //   12255: dup
    //   12256: ldc_w '#4D4D4D '
    //   12259: invokevirtual getBytes : ()[B
    //   12262: iconst_0
    //   12263: invokespecial <init> : ([BI)V
    //   12266: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12271: aload #5
    //   12273: sipush #548
    //   12276: ldc_w -11711155
    //   12279: invokeinterface setAlignedInt : (II)V
    //   12284: aload #5
    //   12286: sipush #549
    //   12289: new org/renjin/gcc/runtime/BytePtr
    //   12292: dup
    //   12293: ldc_w 'gray31 '
    //   12296: invokevirtual getBytes : ()[B
    //   12299: iconst_0
    //   12300: invokespecial <init> : ([BI)V
    //   12303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12308: aload #5
    //   12310: sipush #550
    //   12313: new org/renjin/gcc/runtime/BytePtr
    //   12316: dup
    //   12317: ldc_w '#4F4F4F '
    //   12320: invokevirtual getBytes : ()[B
    //   12323: iconst_0
    //   12324: invokespecial <init> : ([BI)V
    //   12327: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12332: aload #5
    //   12334: sipush #551
    //   12337: ldc_w -11579569
    //   12340: invokeinterface setAlignedInt : (II)V
    //   12345: aload #5
    //   12347: sipush #552
    //   12350: new org/renjin/gcc/runtime/BytePtr
    //   12353: dup
    //   12354: ldc_w 'gray32 '
    //   12357: invokevirtual getBytes : ()[B
    //   12360: iconst_0
    //   12361: invokespecial <init> : ([BI)V
    //   12364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12369: aload #5
    //   12371: sipush #553
    //   12374: new org/renjin/gcc/runtime/BytePtr
    //   12377: dup
    //   12378: ldc_w '#525252 '
    //   12381: invokevirtual getBytes : ()[B
    //   12384: iconst_0
    //   12385: invokespecial <init> : ([BI)V
    //   12388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12393: aload #5
    //   12395: sipush #554
    //   12398: ldc_w -11382190
    //   12401: invokeinterface setAlignedInt : (II)V
    //   12406: aload #5
    //   12408: sipush #555
    //   12411: new org/renjin/gcc/runtime/BytePtr
    //   12414: dup
    //   12415: ldc_w 'gray33 '
    //   12418: invokevirtual getBytes : ()[B
    //   12421: iconst_0
    //   12422: invokespecial <init> : ([BI)V
    //   12425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12430: aload #5
    //   12432: sipush #556
    //   12435: new org/renjin/gcc/runtime/BytePtr
    //   12438: dup
    //   12439: ldc_w '#545454 '
    //   12442: invokevirtual getBytes : ()[B
    //   12445: iconst_0
    //   12446: invokespecial <init> : ([BI)V
    //   12449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12454: aload #5
    //   12456: sipush #557
    //   12459: ldc_w -11250604
    //   12462: invokeinterface setAlignedInt : (II)V
    //   12467: aload #5
    //   12469: sipush #558
    //   12472: new org/renjin/gcc/runtime/BytePtr
    //   12475: dup
    //   12476: ldc_w 'gray34 '
    //   12479: invokevirtual getBytes : ()[B
    //   12482: iconst_0
    //   12483: invokespecial <init> : ([BI)V
    //   12486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12491: aload #5
    //   12493: sipush #559
    //   12496: new org/renjin/gcc/runtime/BytePtr
    //   12499: dup
    //   12500: ldc_w '#575757 '
    //   12503: invokevirtual getBytes : ()[B
    //   12506: iconst_0
    //   12507: invokespecial <init> : ([BI)V
    //   12510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12515: aload #5
    //   12517: sipush #560
    //   12520: ldc_w -11053225
    //   12523: invokeinterface setAlignedInt : (II)V
    //   12528: aload #5
    //   12530: sipush #561
    //   12533: new org/renjin/gcc/runtime/BytePtr
    //   12536: dup
    //   12537: ldc_w 'gray35 '
    //   12540: invokevirtual getBytes : ()[B
    //   12543: iconst_0
    //   12544: invokespecial <init> : ([BI)V
    //   12547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12552: aload #5
    //   12554: sipush #562
    //   12557: new org/renjin/gcc/runtime/BytePtr
    //   12560: dup
    //   12561: ldc_w '#595959 '
    //   12564: invokevirtual getBytes : ()[B
    //   12567: iconst_0
    //   12568: invokespecial <init> : ([BI)V
    //   12571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12576: aload #5
    //   12578: sipush #563
    //   12581: ldc_w -10921639
    //   12584: invokeinterface setAlignedInt : (II)V
    //   12589: aload #5
    //   12591: sipush #564
    //   12594: new org/renjin/gcc/runtime/BytePtr
    //   12597: dup
    //   12598: ldc_w 'gray36 '
    //   12601: invokevirtual getBytes : ()[B
    //   12604: iconst_0
    //   12605: invokespecial <init> : ([BI)V
    //   12608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12613: aload #5
    //   12615: sipush #565
    //   12618: new org/renjin/gcc/runtime/BytePtr
    //   12621: dup
    //   12622: ldc_w '#5C5C5C '
    //   12625: invokevirtual getBytes : ()[B
    //   12628: iconst_0
    //   12629: invokespecial <init> : ([BI)V
    //   12632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12637: aload #5
    //   12639: sipush #566
    //   12642: ldc_w -10724260
    //   12645: invokeinterface setAlignedInt : (II)V
    //   12650: aload #5
    //   12652: sipush #567
    //   12655: new org/renjin/gcc/runtime/BytePtr
    //   12658: dup
    //   12659: ldc_w 'gray37 '
    //   12662: invokevirtual getBytes : ()[B
    //   12665: iconst_0
    //   12666: invokespecial <init> : ([BI)V
    //   12669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12674: aload #5
    //   12676: sipush #568
    //   12679: new org/renjin/gcc/runtime/BytePtr
    //   12682: dup
    //   12683: ldc_w '#5E5E5E '
    //   12686: invokevirtual getBytes : ()[B
    //   12689: iconst_0
    //   12690: invokespecial <init> : ([BI)V
    //   12693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12698: aload #5
    //   12700: sipush #569
    //   12703: ldc_w -10592674
    //   12706: invokeinterface setAlignedInt : (II)V
    //   12711: aload #5
    //   12713: sipush #570
    //   12716: new org/renjin/gcc/runtime/BytePtr
    //   12719: dup
    //   12720: ldc_w 'gray38 '
    //   12723: invokevirtual getBytes : ()[B
    //   12726: iconst_0
    //   12727: invokespecial <init> : ([BI)V
    //   12730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12735: aload #5
    //   12737: sipush #571
    //   12740: new org/renjin/gcc/runtime/BytePtr
    //   12743: dup
    //   12744: ldc_w '#616161 '
    //   12747: invokevirtual getBytes : ()[B
    //   12750: iconst_0
    //   12751: invokespecial <init> : ([BI)V
    //   12754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12759: aload #5
    //   12761: sipush #572
    //   12764: ldc_w -10395295
    //   12767: invokeinterface setAlignedInt : (II)V
    //   12772: aload #5
    //   12774: sipush #573
    //   12777: new org/renjin/gcc/runtime/BytePtr
    //   12780: dup
    //   12781: ldc_w 'gray39 '
    //   12784: invokevirtual getBytes : ()[B
    //   12787: iconst_0
    //   12788: invokespecial <init> : ([BI)V
    //   12791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12796: aload #5
    //   12798: sipush #574
    //   12801: new org/renjin/gcc/runtime/BytePtr
    //   12804: dup
    //   12805: ldc_w '#636363 '
    //   12808: invokevirtual getBytes : ()[B
    //   12811: iconst_0
    //   12812: invokespecial <init> : ([BI)V
    //   12815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12820: aload #5
    //   12822: sipush #575
    //   12825: ldc_w -10263709
    //   12828: invokeinterface setAlignedInt : (II)V
    //   12833: aload #5
    //   12835: sipush #576
    //   12838: new org/renjin/gcc/runtime/BytePtr
    //   12841: dup
    //   12842: ldc_w 'gray40 '
    //   12845: invokevirtual getBytes : ()[B
    //   12848: iconst_0
    //   12849: invokespecial <init> : ([BI)V
    //   12852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12857: aload #5
    //   12859: sipush #577
    //   12862: new org/renjin/gcc/runtime/BytePtr
    //   12865: dup
    //   12866: ldc_w '#666666 '
    //   12869: invokevirtual getBytes : ()[B
    //   12872: iconst_0
    //   12873: invokespecial <init> : ([BI)V
    //   12876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12881: aload #5
    //   12883: sipush #578
    //   12886: ldc_w -10066330
    //   12889: invokeinterface setAlignedInt : (II)V
    //   12894: aload #5
    //   12896: sipush #579
    //   12899: new org/renjin/gcc/runtime/BytePtr
    //   12902: dup
    //   12903: ldc_w 'gray41 '
    //   12906: invokevirtual getBytes : ()[B
    //   12909: iconst_0
    //   12910: invokespecial <init> : ([BI)V
    //   12913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12918: aload #5
    //   12920: sipush #580
    //   12923: new org/renjin/gcc/runtime/BytePtr
    //   12926: dup
    //   12927: ldc_w '#696969 '
    //   12930: invokevirtual getBytes : ()[B
    //   12933: iconst_0
    //   12934: invokespecial <init> : ([BI)V
    //   12937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12942: aload #5
    //   12944: sipush #581
    //   12947: ldc_w -9868951
    //   12950: invokeinterface setAlignedInt : (II)V
    //   12955: aload #5
    //   12957: sipush #582
    //   12960: new org/renjin/gcc/runtime/BytePtr
    //   12963: dup
    //   12964: ldc_w 'gray42 '
    //   12967: invokevirtual getBytes : ()[B
    //   12970: iconst_0
    //   12971: invokespecial <init> : ([BI)V
    //   12974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   12979: aload #5
    //   12981: sipush #583
    //   12984: new org/renjin/gcc/runtime/BytePtr
    //   12987: dup
    //   12988: ldc_w '#6B6B6B '
    //   12991: invokevirtual getBytes : ()[B
    //   12994: iconst_0
    //   12995: invokespecial <init> : ([BI)V
    //   12998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13003: aload #5
    //   13005: sipush #584
    //   13008: ldc_w -9737365
    //   13011: invokeinterface setAlignedInt : (II)V
    //   13016: aload #5
    //   13018: sipush #585
    //   13021: new org/renjin/gcc/runtime/BytePtr
    //   13024: dup
    //   13025: ldc_w 'gray43 '
    //   13028: invokevirtual getBytes : ()[B
    //   13031: iconst_0
    //   13032: invokespecial <init> : ([BI)V
    //   13035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13040: aload #5
    //   13042: sipush #586
    //   13045: new org/renjin/gcc/runtime/BytePtr
    //   13048: dup
    //   13049: ldc_w '#6E6E6E '
    //   13052: invokevirtual getBytes : ()[B
    //   13055: iconst_0
    //   13056: invokespecial <init> : ([BI)V
    //   13059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13064: aload #5
    //   13066: sipush #587
    //   13069: ldc_w -9539986
    //   13072: invokeinterface setAlignedInt : (II)V
    //   13077: aload #5
    //   13079: sipush #588
    //   13082: new org/renjin/gcc/runtime/BytePtr
    //   13085: dup
    //   13086: ldc_w 'gray44 '
    //   13089: invokevirtual getBytes : ()[B
    //   13092: iconst_0
    //   13093: invokespecial <init> : ([BI)V
    //   13096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13101: aload #5
    //   13103: sipush #589
    //   13106: new org/renjin/gcc/runtime/BytePtr
    //   13109: dup
    //   13110: ldc_w '#707070 '
    //   13113: invokevirtual getBytes : ()[B
    //   13116: iconst_0
    //   13117: invokespecial <init> : ([BI)V
    //   13120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13125: aload #5
    //   13127: sipush #590
    //   13130: ldc_w -9408400
    //   13133: invokeinterface setAlignedInt : (II)V
    //   13138: aload #5
    //   13140: sipush #591
    //   13143: new org/renjin/gcc/runtime/BytePtr
    //   13146: dup
    //   13147: ldc_w 'gray45 '
    //   13150: invokevirtual getBytes : ()[B
    //   13153: iconst_0
    //   13154: invokespecial <init> : ([BI)V
    //   13157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13162: aload #5
    //   13164: sipush #592
    //   13167: new org/renjin/gcc/runtime/BytePtr
    //   13170: dup
    //   13171: ldc_w '#737373 '
    //   13174: invokevirtual getBytes : ()[B
    //   13177: iconst_0
    //   13178: invokespecial <init> : ([BI)V
    //   13181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13186: aload #5
    //   13188: sipush #593
    //   13191: ldc_w -9211021
    //   13194: invokeinterface setAlignedInt : (II)V
    //   13199: aload #5
    //   13201: sipush #594
    //   13204: new org/renjin/gcc/runtime/BytePtr
    //   13207: dup
    //   13208: ldc_w 'gray46 '
    //   13211: invokevirtual getBytes : ()[B
    //   13214: iconst_0
    //   13215: invokespecial <init> : ([BI)V
    //   13218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13223: aload #5
    //   13225: sipush #595
    //   13228: new org/renjin/gcc/runtime/BytePtr
    //   13231: dup
    //   13232: ldc_w '#757575 '
    //   13235: invokevirtual getBytes : ()[B
    //   13238: iconst_0
    //   13239: invokespecial <init> : ([BI)V
    //   13242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13247: aload #5
    //   13249: sipush #596
    //   13252: ldc_w -9079435
    //   13255: invokeinterface setAlignedInt : (II)V
    //   13260: aload #5
    //   13262: sipush #597
    //   13265: new org/renjin/gcc/runtime/BytePtr
    //   13268: dup
    //   13269: ldc_w 'gray47 '
    //   13272: invokevirtual getBytes : ()[B
    //   13275: iconst_0
    //   13276: invokespecial <init> : ([BI)V
    //   13279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13284: aload #5
    //   13286: sipush #598
    //   13289: new org/renjin/gcc/runtime/BytePtr
    //   13292: dup
    //   13293: ldc_w '#787878 '
    //   13296: invokevirtual getBytes : ()[B
    //   13299: iconst_0
    //   13300: invokespecial <init> : ([BI)V
    //   13303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13308: aload #5
    //   13310: sipush #599
    //   13313: ldc_w -8882056
    //   13316: invokeinterface setAlignedInt : (II)V
    //   13321: aload #5
    //   13323: sipush #600
    //   13326: new org/renjin/gcc/runtime/BytePtr
    //   13329: dup
    //   13330: ldc_w 'gray48 '
    //   13333: invokevirtual getBytes : ()[B
    //   13336: iconst_0
    //   13337: invokespecial <init> : ([BI)V
    //   13340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13345: aload #5
    //   13347: sipush #601
    //   13350: new org/renjin/gcc/runtime/BytePtr
    //   13353: dup
    //   13354: ldc_w '#7A7A7A '
    //   13357: invokevirtual getBytes : ()[B
    //   13360: iconst_0
    //   13361: invokespecial <init> : ([BI)V
    //   13364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13369: aload #5
    //   13371: sipush #602
    //   13374: ldc_w -8750470
    //   13377: invokeinterface setAlignedInt : (II)V
    //   13382: aload #5
    //   13384: sipush #603
    //   13387: new org/renjin/gcc/runtime/BytePtr
    //   13390: dup
    //   13391: ldc_w 'gray49 '
    //   13394: invokevirtual getBytes : ()[B
    //   13397: iconst_0
    //   13398: invokespecial <init> : ([BI)V
    //   13401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13406: aload #5
    //   13408: sipush #604
    //   13411: new org/renjin/gcc/runtime/BytePtr
    //   13414: dup
    //   13415: ldc_w '#7D7D7D '
    //   13418: invokevirtual getBytes : ()[B
    //   13421: iconst_0
    //   13422: invokespecial <init> : ([BI)V
    //   13425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13430: aload #5
    //   13432: sipush #605
    //   13435: ldc_w -8553091
    //   13438: invokeinterface setAlignedInt : (II)V
    //   13443: aload #5
    //   13445: sipush #606
    //   13448: new org/renjin/gcc/runtime/BytePtr
    //   13451: dup
    //   13452: ldc_w 'gray50 '
    //   13455: invokevirtual getBytes : ()[B
    //   13458: iconst_0
    //   13459: invokespecial <init> : ([BI)V
    //   13462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13467: aload #5
    //   13469: sipush #607
    //   13472: new org/renjin/gcc/runtime/BytePtr
    //   13475: dup
    //   13476: ldc_w '#7F7F7F '
    //   13479: invokevirtual getBytes : ()[B
    //   13482: iconst_0
    //   13483: invokespecial <init> : ([BI)V
    //   13486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13491: aload #5
    //   13493: sipush #608
    //   13496: ldc_w -8421505
    //   13499: invokeinterface setAlignedInt : (II)V
    //   13504: aload #5
    //   13506: sipush #609
    //   13509: new org/renjin/gcc/runtime/BytePtr
    //   13512: dup
    //   13513: ldc_w 'gray51 '
    //   13516: invokevirtual getBytes : ()[B
    //   13519: iconst_0
    //   13520: invokespecial <init> : ([BI)V
    //   13523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13528: aload #5
    //   13530: sipush #610
    //   13533: new org/renjin/gcc/runtime/BytePtr
    //   13536: dup
    //   13537: ldc_w '#828282 '
    //   13540: invokevirtual getBytes : ()[B
    //   13543: iconst_0
    //   13544: invokespecial <init> : ([BI)V
    //   13547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13552: aload #5
    //   13554: sipush #611
    //   13557: ldc_w -8224126
    //   13560: invokeinterface setAlignedInt : (II)V
    //   13565: aload #5
    //   13567: sipush #612
    //   13570: new org/renjin/gcc/runtime/BytePtr
    //   13573: dup
    //   13574: ldc_w 'gray52 '
    //   13577: invokevirtual getBytes : ()[B
    //   13580: iconst_0
    //   13581: invokespecial <init> : ([BI)V
    //   13584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13589: aload #5
    //   13591: sipush #613
    //   13594: new org/renjin/gcc/runtime/BytePtr
    //   13597: dup
    //   13598: ldc_w '#858585 '
    //   13601: invokevirtual getBytes : ()[B
    //   13604: iconst_0
    //   13605: invokespecial <init> : ([BI)V
    //   13608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13613: aload #5
    //   13615: sipush #614
    //   13618: ldc_w -8026747
    //   13621: invokeinterface setAlignedInt : (II)V
    //   13626: aload #5
    //   13628: sipush #615
    //   13631: new org/renjin/gcc/runtime/BytePtr
    //   13634: dup
    //   13635: ldc_w 'gray53 '
    //   13638: invokevirtual getBytes : ()[B
    //   13641: iconst_0
    //   13642: invokespecial <init> : ([BI)V
    //   13645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13650: aload #5
    //   13652: sipush #616
    //   13655: new org/renjin/gcc/runtime/BytePtr
    //   13658: dup
    //   13659: ldc_w '#878787 '
    //   13662: invokevirtual getBytes : ()[B
    //   13665: iconst_0
    //   13666: invokespecial <init> : ([BI)V
    //   13669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13674: aload #5
    //   13676: sipush #617
    //   13679: ldc_w -7895161
    //   13682: invokeinterface setAlignedInt : (II)V
    //   13687: aload #5
    //   13689: sipush #618
    //   13692: new org/renjin/gcc/runtime/BytePtr
    //   13695: dup
    //   13696: ldc_w 'gray54 '
    //   13699: invokevirtual getBytes : ()[B
    //   13702: iconst_0
    //   13703: invokespecial <init> : ([BI)V
    //   13706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13711: aload #5
    //   13713: sipush #619
    //   13716: new org/renjin/gcc/runtime/BytePtr
    //   13719: dup
    //   13720: ldc_w '#8A8A8A '
    //   13723: invokevirtual getBytes : ()[B
    //   13726: iconst_0
    //   13727: invokespecial <init> : ([BI)V
    //   13730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13735: aload #5
    //   13737: sipush #620
    //   13740: ldc_w -7697782
    //   13743: invokeinterface setAlignedInt : (II)V
    //   13748: aload #5
    //   13750: sipush #621
    //   13753: new org/renjin/gcc/runtime/BytePtr
    //   13756: dup
    //   13757: ldc_w 'gray55 '
    //   13760: invokevirtual getBytes : ()[B
    //   13763: iconst_0
    //   13764: invokespecial <init> : ([BI)V
    //   13767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13772: aload #5
    //   13774: sipush #622
    //   13777: new org/renjin/gcc/runtime/BytePtr
    //   13780: dup
    //   13781: ldc_w '#8C8C8C '
    //   13784: invokevirtual getBytes : ()[B
    //   13787: iconst_0
    //   13788: invokespecial <init> : ([BI)V
    //   13791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13796: aload #5
    //   13798: sipush #623
    //   13801: ldc_w -7566196
    //   13804: invokeinterface setAlignedInt : (II)V
    //   13809: aload #5
    //   13811: sipush #624
    //   13814: new org/renjin/gcc/runtime/BytePtr
    //   13817: dup
    //   13818: ldc_w 'gray56 '
    //   13821: invokevirtual getBytes : ()[B
    //   13824: iconst_0
    //   13825: invokespecial <init> : ([BI)V
    //   13828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13833: aload #5
    //   13835: sipush #625
    //   13838: new org/renjin/gcc/runtime/BytePtr
    //   13841: dup
    //   13842: ldc_w '#8F8F8F '
    //   13845: invokevirtual getBytes : ()[B
    //   13848: iconst_0
    //   13849: invokespecial <init> : ([BI)V
    //   13852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13857: aload #5
    //   13859: sipush #626
    //   13862: ldc_w -7368817
    //   13865: invokeinterface setAlignedInt : (II)V
    //   13870: aload #5
    //   13872: sipush #627
    //   13875: new org/renjin/gcc/runtime/BytePtr
    //   13878: dup
    //   13879: ldc_w 'gray57 '
    //   13882: invokevirtual getBytes : ()[B
    //   13885: iconst_0
    //   13886: invokespecial <init> : ([BI)V
    //   13889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13894: aload #5
    //   13896: sipush #628
    //   13899: new org/renjin/gcc/runtime/BytePtr
    //   13902: dup
    //   13903: ldc_w '#919191 '
    //   13906: invokevirtual getBytes : ()[B
    //   13909: iconst_0
    //   13910: invokespecial <init> : ([BI)V
    //   13913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13918: aload #5
    //   13920: sipush #629
    //   13923: ldc_w -7237231
    //   13926: invokeinterface setAlignedInt : (II)V
    //   13931: aload #5
    //   13933: sipush #630
    //   13936: new org/renjin/gcc/runtime/BytePtr
    //   13939: dup
    //   13940: ldc_w 'gray58 '
    //   13943: invokevirtual getBytes : ()[B
    //   13946: iconst_0
    //   13947: invokespecial <init> : ([BI)V
    //   13950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13955: aload #5
    //   13957: sipush #631
    //   13960: new org/renjin/gcc/runtime/BytePtr
    //   13963: dup
    //   13964: ldc_w '#949494 '
    //   13967: invokevirtual getBytes : ()[B
    //   13970: iconst_0
    //   13971: invokespecial <init> : ([BI)V
    //   13974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   13979: aload #5
    //   13981: sipush #632
    //   13984: ldc_w -7039852
    //   13987: invokeinterface setAlignedInt : (II)V
    //   13992: aload #5
    //   13994: sipush #633
    //   13997: new org/renjin/gcc/runtime/BytePtr
    //   14000: dup
    //   14001: ldc_w 'gray59 '
    //   14004: invokevirtual getBytes : ()[B
    //   14007: iconst_0
    //   14008: invokespecial <init> : ([BI)V
    //   14011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14016: aload #5
    //   14018: sipush #634
    //   14021: new org/renjin/gcc/runtime/BytePtr
    //   14024: dup
    //   14025: ldc_w '#969696 '
    //   14028: invokevirtual getBytes : ()[B
    //   14031: iconst_0
    //   14032: invokespecial <init> : ([BI)V
    //   14035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14040: aload #5
    //   14042: sipush #635
    //   14045: ldc_w -6908266
    //   14048: invokeinterface setAlignedInt : (II)V
    //   14053: aload #5
    //   14055: sipush #636
    //   14058: new org/renjin/gcc/runtime/BytePtr
    //   14061: dup
    //   14062: ldc_w 'gray60 '
    //   14065: invokevirtual getBytes : ()[B
    //   14068: iconst_0
    //   14069: invokespecial <init> : ([BI)V
    //   14072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14077: aload #5
    //   14079: sipush #637
    //   14082: new org/renjin/gcc/runtime/BytePtr
    //   14085: dup
    //   14086: ldc_w '#999999 '
    //   14089: invokevirtual getBytes : ()[B
    //   14092: iconst_0
    //   14093: invokespecial <init> : ([BI)V
    //   14096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14101: aload #5
    //   14103: sipush #638
    //   14106: ldc_w -6710887
    //   14109: invokeinterface setAlignedInt : (II)V
    //   14114: aload #5
    //   14116: sipush #639
    //   14119: new org/renjin/gcc/runtime/BytePtr
    //   14122: dup
    //   14123: ldc_w 'gray61 '
    //   14126: invokevirtual getBytes : ()[B
    //   14129: iconst_0
    //   14130: invokespecial <init> : ([BI)V
    //   14133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14138: aload #5
    //   14140: sipush #640
    //   14143: new org/renjin/gcc/runtime/BytePtr
    //   14146: dup
    //   14147: ldc_w '#9C9C9C '
    //   14150: invokevirtual getBytes : ()[B
    //   14153: iconst_0
    //   14154: invokespecial <init> : ([BI)V
    //   14157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14162: aload #5
    //   14164: sipush #641
    //   14167: ldc_w -6513508
    //   14170: invokeinterface setAlignedInt : (II)V
    //   14175: aload #5
    //   14177: sipush #642
    //   14180: new org/renjin/gcc/runtime/BytePtr
    //   14183: dup
    //   14184: ldc_w 'gray62 '
    //   14187: invokevirtual getBytes : ()[B
    //   14190: iconst_0
    //   14191: invokespecial <init> : ([BI)V
    //   14194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14199: aload #5
    //   14201: sipush #643
    //   14204: new org/renjin/gcc/runtime/BytePtr
    //   14207: dup
    //   14208: ldc_w '#9E9E9E '
    //   14211: invokevirtual getBytes : ()[B
    //   14214: iconst_0
    //   14215: invokespecial <init> : ([BI)V
    //   14218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14223: aload #5
    //   14225: sipush #644
    //   14228: ldc_w -6381922
    //   14231: invokeinterface setAlignedInt : (II)V
    //   14236: aload #5
    //   14238: sipush #645
    //   14241: new org/renjin/gcc/runtime/BytePtr
    //   14244: dup
    //   14245: ldc_w 'gray63 '
    //   14248: invokevirtual getBytes : ()[B
    //   14251: iconst_0
    //   14252: invokespecial <init> : ([BI)V
    //   14255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14260: aload #5
    //   14262: sipush #646
    //   14265: new org/renjin/gcc/runtime/BytePtr
    //   14268: dup
    //   14269: ldc_w '#A1A1A1 '
    //   14272: invokevirtual getBytes : ()[B
    //   14275: iconst_0
    //   14276: invokespecial <init> : ([BI)V
    //   14279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14284: aload #5
    //   14286: sipush #647
    //   14289: ldc_w -6184543
    //   14292: invokeinterface setAlignedInt : (II)V
    //   14297: aload #5
    //   14299: sipush #648
    //   14302: new org/renjin/gcc/runtime/BytePtr
    //   14305: dup
    //   14306: ldc_w 'gray64 '
    //   14309: invokevirtual getBytes : ()[B
    //   14312: iconst_0
    //   14313: invokespecial <init> : ([BI)V
    //   14316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14321: aload #5
    //   14323: sipush #649
    //   14326: new org/renjin/gcc/runtime/BytePtr
    //   14329: dup
    //   14330: ldc_w '#A3A3A3 '
    //   14333: invokevirtual getBytes : ()[B
    //   14336: iconst_0
    //   14337: invokespecial <init> : ([BI)V
    //   14340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14345: aload #5
    //   14347: sipush #650
    //   14350: ldc_w -6052957
    //   14353: invokeinterface setAlignedInt : (II)V
    //   14358: aload #5
    //   14360: sipush #651
    //   14363: new org/renjin/gcc/runtime/BytePtr
    //   14366: dup
    //   14367: ldc_w 'gray65 '
    //   14370: invokevirtual getBytes : ()[B
    //   14373: iconst_0
    //   14374: invokespecial <init> : ([BI)V
    //   14377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14382: aload #5
    //   14384: sipush #652
    //   14387: new org/renjin/gcc/runtime/BytePtr
    //   14390: dup
    //   14391: ldc_w '#A6A6A6 '
    //   14394: invokevirtual getBytes : ()[B
    //   14397: iconst_0
    //   14398: invokespecial <init> : ([BI)V
    //   14401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14406: aload #5
    //   14408: sipush #653
    //   14411: ldc_w -5855578
    //   14414: invokeinterface setAlignedInt : (II)V
    //   14419: aload #5
    //   14421: sipush #654
    //   14424: new org/renjin/gcc/runtime/BytePtr
    //   14427: dup
    //   14428: ldc_w 'gray66 '
    //   14431: invokevirtual getBytes : ()[B
    //   14434: iconst_0
    //   14435: invokespecial <init> : ([BI)V
    //   14438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14443: aload #5
    //   14445: sipush #655
    //   14448: new org/renjin/gcc/runtime/BytePtr
    //   14451: dup
    //   14452: ldc_w '#A8A8A8 '
    //   14455: invokevirtual getBytes : ()[B
    //   14458: iconst_0
    //   14459: invokespecial <init> : ([BI)V
    //   14462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14467: aload #5
    //   14469: sipush #656
    //   14472: ldc_w -5723992
    //   14475: invokeinterface setAlignedInt : (II)V
    //   14480: aload #5
    //   14482: sipush #657
    //   14485: new org/renjin/gcc/runtime/BytePtr
    //   14488: dup
    //   14489: ldc_w 'gray67 '
    //   14492: invokevirtual getBytes : ()[B
    //   14495: iconst_0
    //   14496: invokespecial <init> : ([BI)V
    //   14499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14504: aload #5
    //   14506: sipush #658
    //   14509: new org/renjin/gcc/runtime/BytePtr
    //   14512: dup
    //   14513: ldc_w '#ABABAB '
    //   14516: invokevirtual getBytes : ()[B
    //   14519: iconst_0
    //   14520: invokespecial <init> : ([BI)V
    //   14523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14528: aload #5
    //   14530: sipush #659
    //   14533: ldc_w -5526613
    //   14536: invokeinterface setAlignedInt : (II)V
    //   14541: aload #5
    //   14543: sipush #660
    //   14546: new org/renjin/gcc/runtime/BytePtr
    //   14549: dup
    //   14550: ldc_w 'gray68 '
    //   14553: invokevirtual getBytes : ()[B
    //   14556: iconst_0
    //   14557: invokespecial <init> : ([BI)V
    //   14560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14565: aload #5
    //   14567: sipush #661
    //   14570: new org/renjin/gcc/runtime/BytePtr
    //   14573: dup
    //   14574: ldc_w '#ADADAD '
    //   14577: invokevirtual getBytes : ()[B
    //   14580: iconst_0
    //   14581: invokespecial <init> : ([BI)V
    //   14584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14589: aload #5
    //   14591: sipush #662
    //   14594: ldc_w -5395027
    //   14597: invokeinterface setAlignedInt : (II)V
    //   14602: aload #5
    //   14604: sipush #663
    //   14607: new org/renjin/gcc/runtime/BytePtr
    //   14610: dup
    //   14611: ldc_w 'gray69 '
    //   14614: invokevirtual getBytes : ()[B
    //   14617: iconst_0
    //   14618: invokespecial <init> : ([BI)V
    //   14621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14626: aload #5
    //   14628: sipush #664
    //   14631: new org/renjin/gcc/runtime/BytePtr
    //   14634: dup
    //   14635: ldc_w '#B0B0B0 '
    //   14638: invokevirtual getBytes : ()[B
    //   14641: iconst_0
    //   14642: invokespecial <init> : ([BI)V
    //   14645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14650: aload #5
    //   14652: sipush #665
    //   14655: ldc_w -5197648
    //   14658: invokeinterface setAlignedInt : (II)V
    //   14663: aload #5
    //   14665: sipush #666
    //   14668: new org/renjin/gcc/runtime/BytePtr
    //   14671: dup
    //   14672: ldc_w 'gray70 '
    //   14675: invokevirtual getBytes : ()[B
    //   14678: iconst_0
    //   14679: invokespecial <init> : ([BI)V
    //   14682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14687: aload #5
    //   14689: sipush #667
    //   14692: new org/renjin/gcc/runtime/BytePtr
    //   14695: dup
    //   14696: ldc_w '#B3B3B3 '
    //   14699: invokevirtual getBytes : ()[B
    //   14702: iconst_0
    //   14703: invokespecial <init> : ([BI)V
    //   14706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14711: aload #5
    //   14713: sipush #668
    //   14716: ldc_w -5000269
    //   14719: invokeinterface setAlignedInt : (II)V
    //   14724: aload #5
    //   14726: sipush #669
    //   14729: new org/renjin/gcc/runtime/BytePtr
    //   14732: dup
    //   14733: ldc_w 'gray71 '
    //   14736: invokevirtual getBytes : ()[B
    //   14739: iconst_0
    //   14740: invokespecial <init> : ([BI)V
    //   14743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14748: aload #5
    //   14750: sipush #670
    //   14753: new org/renjin/gcc/runtime/BytePtr
    //   14756: dup
    //   14757: ldc_w '#B5B5B5 '
    //   14760: invokevirtual getBytes : ()[B
    //   14763: iconst_0
    //   14764: invokespecial <init> : ([BI)V
    //   14767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14772: aload #5
    //   14774: sipush #671
    //   14777: ldc_w -4868683
    //   14780: invokeinterface setAlignedInt : (II)V
    //   14785: aload #5
    //   14787: sipush #672
    //   14790: new org/renjin/gcc/runtime/BytePtr
    //   14793: dup
    //   14794: ldc_w 'gray72 '
    //   14797: invokevirtual getBytes : ()[B
    //   14800: iconst_0
    //   14801: invokespecial <init> : ([BI)V
    //   14804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14809: aload #5
    //   14811: sipush #673
    //   14814: new org/renjin/gcc/runtime/BytePtr
    //   14817: dup
    //   14818: ldc_w '#B8B8B8 '
    //   14821: invokevirtual getBytes : ()[B
    //   14824: iconst_0
    //   14825: invokespecial <init> : ([BI)V
    //   14828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14833: aload #5
    //   14835: sipush #674
    //   14838: ldc_w -4671304
    //   14841: invokeinterface setAlignedInt : (II)V
    //   14846: aload #5
    //   14848: sipush #675
    //   14851: new org/renjin/gcc/runtime/BytePtr
    //   14854: dup
    //   14855: ldc_w 'gray73 '
    //   14858: invokevirtual getBytes : ()[B
    //   14861: iconst_0
    //   14862: invokespecial <init> : ([BI)V
    //   14865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14870: aload #5
    //   14872: sipush #676
    //   14875: new org/renjin/gcc/runtime/BytePtr
    //   14878: dup
    //   14879: ldc_w '#BABABA '
    //   14882: invokevirtual getBytes : ()[B
    //   14885: iconst_0
    //   14886: invokespecial <init> : ([BI)V
    //   14889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14894: aload #5
    //   14896: sipush #677
    //   14899: ldc_w -4539718
    //   14902: invokeinterface setAlignedInt : (II)V
    //   14907: aload #5
    //   14909: sipush #678
    //   14912: new org/renjin/gcc/runtime/BytePtr
    //   14915: dup
    //   14916: ldc_w 'gray74 '
    //   14919: invokevirtual getBytes : ()[B
    //   14922: iconst_0
    //   14923: invokespecial <init> : ([BI)V
    //   14926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14931: aload #5
    //   14933: sipush #679
    //   14936: new org/renjin/gcc/runtime/BytePtr
    //   14939: dup
    //   14940: ldc_w '#BDBDBD '
    //   14943: invokevirtual getBytes : ()[B
    //   14946: iconst_0
    //   14947: invokespecial <init> : ([BI)V
    //   14950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14955: aload #5
    //   14957: sipush #680
    //   14960: ldc_w -4342339
    //   14963: invokeinterface setAlignedInt : (II)V
    //   14968: aload #5
    //   14970: sipush #681
    //   14973: new org/renjin/gcc/runtime/BytePtr
    //   14976: dup
    //   14977: ldc_w 'gray75 '
    //   14980: invokevirtual getBytes : ()[B
    //   14983: iconst_0
    //   14984: invokespecial <init> : ([BI)V
    //   14987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   14992: aload #5
    //   14994: sipush #682
    //   14997: new org/renjin/gcc/runtime/BytePtr
    //   15000: dup
    //   15001: ldc_w '#BFBFBF '
    //   15004: invokevirtual getBytes : ()[B
    //   15007: iconst_0
    //   15008: invokespecial <init> : ([BI)V
    //   15011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15016: aload #5
    //   15018: sipush #683
    //   15021: ldc_w -4210753
    //   15024: invokeinterface setAlignedInt : (II)V
    //   15029: aload #5
    //   15031: sipush #684
    //   15034: new org/renjin/gcc/runtime/BytePtr
    //   15037: dup
    //   15038: ldc_w 'gray76 '
    //   15041: invokevirtual getBytes : ()[B
    //   15044: iconst_0
    //   15045: invokespecial <init> : ([BI)V
    //   15048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15053: aload #5
    //   15055: sipush #685
    //   15058: new org/renjin/gcc/runtime/BytePtr
    //   15061: dup
    //   15062: ldc_w '#C2C2C2 '
    //   15065: invokevirtual getBytes : ()[B
    //   15068: iconst_0
    //   15069: invokespecial <init> : ([BI)V
    //   15072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15077: aload #5
    //   15079: sipush #686
    //   15082: ldc_w -4013374
    //   15085: invokeinterface setAlignedInt : (II)V
    //   15090: aload #5
    //   15092: sipush #687
    //   15095: new org/renjin/gcc/runtime/BytePtr
    //   15098: dup
    //   15099: ldc_w 'gray77 '
    //   15102: invokevirtual getBytes : ()[B
    //   15105: iconst_0
    //   15106: invokespecial <init> : ([BI)V
    //   15109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15114: aload #5
    //   15116: sipush #688
    //   15119: new org/renjin/gcc/runtime/BytePtr
    //   15122: dup
    //   15123: ldc_w '#C4C4C4 '
    //   15126: invokevirtual getBytes : ()[B
    //   15129: iconst_0
    //   15130: invokespecial <init> : ([BI)V
    //   15133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15138: aload #5
    //   15140: sipush #689
    //   15143: ldc_w -3881788
    //   15146: invokeinterface setAlignedInt : (II)V
    //   15151: aload #5
    //   15153: sipush #690
    //   15156: new org/renjin/gcc/runtime/BytePtr
    //   15159: dup
    //   15160: ldc_w 'gray78 '
    //   15163: invokevirtual getBytes : ()[B
    //   15166: iconst_0
    //   15167: invokespecial <init> : ([BI)V
    //   15170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15175: aload #5
    //   15177: sipush #691
    //   15180: new org/renjin/gcc/runtime/BytePtr
    //   15183: dup
    //   15184: ldc_w '#C7C7C7 '
    //   15187: invokevirtual getBytes : ()[B
    //   15190: iconst_0
    //   15191: invokespecial <init> : ([BI)V
    //   15194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15199: aload #5
    //   15201: sipush #692
    //   15204: ldc_w -3684409
    //   15207: invokeinterface setAlignedInt : (II)V
    //   15212: aload #5
    //   15214: sipush #693
    //   15217: new org/renjin/gcc/runtime/BytePtr
    //   15220: dup
    //   15221: ldc_w 'gray79 '
    //   15224: invokevirtual getBytes : ()[B
    //   15227: iconst_0
    //   15228: invokespecial <init> : ([BI)V
    //   15231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15236: aload #5
    //   15238: sipush #694
    //   15241: new org/renjin/gcc/runtime/BytePtr
    //   15244: dup
    //   15245: ldc_w '#C9C9C9 '
    //   15248: invokevirtual getBytes : ()[B
    //   15251: iconst_0
    //   15252: invokespecial <init> : ([BI)V
    //   15255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15260: aload #5
    //   15262: sipush #695
    //   15265: ldc_w -3552823
    //   15268: invokeinterface setAlignedInt : (II)V
    //   15273: aload #5
    //   15275: sipush #696
    //   15278: new org/renjin/gcc/runtime/BytePtr
    //   15281: dup
    //   15282: ldc_w 'gray80 '
    //   15285: invokevirtual getBytes : ()[B
    //   15288: iconst_0
    //   15289: invokespecial <init> : ([BI)V
    //   15292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15297: aload #5
    //   15299: sipush #697
    //   15302: new org/renjin/gcc/runtime/BytePtr
    //   15305: dup
    //   15306: ldc_w '#CCCCCC '
    //   15309: invokevirtual getBytes : ()[B
    //   15312: iconst_0
    //   15313: invokespecial <init> : ([BI)V
    //   15316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15321: aload #5
    //   15323: sipush #698
    //   15326: ldc_w -3355444
    //   15329: invokeinterface setAlignedInt : (II)V
    //   15334: aload #5
    //   15336: sipush #699
    //   15339: new org/renjin/gcc/runtime/BytePtr
    //   15342: dup
    //   15343: ldc_w 'gray81 '
    //   15346: invokevirtual getBytes : ()[B
    //   15349: iconst_0
    //   15350: invokespecial <init> : ([BI)V
    //   15353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15358: aload #5
    //   15360: sipush #700
    //   15363: new org/renjin/gcc/runtime/BytePtr
    //   15366: dup
    //   15367: ldc_w '#CFCFCF '
    //   15370: invokevirtual getBytes : ()[B
    //   15373: iconst_0
    //   15374: invokespecial <init> : ([BI)V
    //   15377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15382: aload #5
    //   15384: sipush #701
    //   15387: ldc_w -3158065
    //   15390: invokeinterface setAlignedInt : (II)V
    //   15395: aload #5
    //   15397: sipush #702
    //   15400: new org/renjin/gcc/runtime/BytePtr
    //   15403: dup
    //   15404: ldc_w 'gray82 '
    //   15407: invokevirtual getBytes : ()[B
    //   15410: iconst_0
    //   15411: invokespecial <init> : ([BI)V
    //   15414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15419: aload #5
    //   15421: sipush #703
    //   15424: new org/renjin/gcc/runtime/BytePtr
    //   15427: dup
    //   15428: ldc_w '#D1D1D1 '
    //   15431: invokevirtual getBytes : ()[B
    //   15434: iconst_0
    //   15435: invokespecial <init> : ([BI)V
    //   15438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15443: aload #5
    //   15445: sipush #704
    //   15448: ldc_w -3026479
    //   15451: invokeinterface setAlignedInt : (II)V
    //   15456: aload #5
    //   15458: sipush #705
    //   15461: new org/renjin/gcc/runtime/BytePtr
    //   15464: dup
    //   15465: ldc_w 'gray83 '
    //   15468: invokevirtual getBytes : ()[B
    //   15471: iconst_0
    //   15472: invokespecial <init> : ([BI)V
    //   15475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15480: aload #5
    //   15482: sipush #706
    //   15485: new org/renjin/gcc/runtime/BytePtr
    //   15488: dup
    //   15489: ldc_w '#D4D4D4 '
    //   15492: invokevirtual getBytes : ()[B
    //   15495: iconst_0
    //   15496: invokespecial <init> : ([BI)V
    //   15499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15504: aload #5
    //   15506: sipush #707
    //   15509: ldc_w -2829100
    //   15512: invokeinterface setAlignedInt : (II)V
    //   15517: aload #5
    //   15519: sipush #708
    //   15522: new org/renjin/gcc/runtime/BytePtr
    //   15525: dup
    //   15526: ldc_w 'gray84 '
    //   15529: invokevirtual getBytes : ()[B
    //   15532: iconst_0
    //   15533: invokespecial <init> : ([BI)V
    //   15536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15541: aload #5
    //   15543: sipush #709
    //   15546: new org/renjin/gcc/runtime/BytePtr
    //   15549: dup
    //   15550: ldc_w '#D6D6D6 '
    //   15553: invokevirtual getBytes : ()[B
    //   15556: iconst_0
    //   15557: invokespecial <init> : ([BI)V
    //   15560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15565: aload #5
    //   15567: sipush #710
    //   15570: ldc_w -2697514
    //   15573: invokeinterface setAlignedInt : (II)V
    //   15578: aload #5
    //   15580: sipush #711
    //   15583: new org/renjin/gcc/runtime/BytePtr
    //   15586: dup
    //   15587: ldc_w 'gray85 '
    //   15590: invokevirtual getBytes : ()[B
    //   15593: iconst_0
    //   15594: invokespecial <init> : ([BI)V
    //   15597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15602: aload #5
    //   15604: sipush #712
    //   15607: new org/renjin/gcc/runtime/BytePtr
    //   15610: dup
    //   15611: ldc_w '#D9D9D9 '
    //   15614: invokevirtual getBytes : ()[B
    //   15617: iconst_0
    //   15618: invokespecial <init> : ([BI)V
    //   15621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15626: aload #5
    //   15628: sipush #713
    //   15631: ldc_w -2500135
    //   15634: invokeinterface setAlignedInt : (II)V
    //   15639: aload #5
    //   15641: sipush #714
    //   15644: new org/renjin/gcc/runtime/BytePtr
    //   15647: dup
    //   15648: ldc_w 'gray86 '
    //   15651: invokevirtual getBytes : ()[B
    //   15654: iconst_0
    //   15655: invokespecial <init> : ([BI)V
    //   15658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15663: aload #5
    //   15665: sipush #715
    //   15668: new org/renjin/gcc/runtime/BytePtr
    //   15671: dup
    //   15672: ldc_w '#DBDBDB '
    //   15675: invokevirtual getBytes : ()[B
    //   15678: iconst_0
    //   15679: invokespecial <init> : ([BI)V
    //   15682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15687: aload #5
    //   15689: sipush #716
    //   15692: ldc_w -2368549
    //   15695: invokeinterface setAlignedInt : (II)V
    //   15700: aload #5
    //   15702: sipush #717
    //   15705: new org/renjin/gcc/runtime/BytePtr
    //   15708: dup
    //   15709: ldc_w 'gray87 '
    //   15712: invokevirtual getBytes : ()[B
    //   15715: iconst_0
    //   15716: invokespecial <init> : ([BI)V
    //   15719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15724: aload #5
    //   15726: sipush #718
    //   15729: new org/renjin/gcc/runtime/BytePtr
    //   15732: dup
    //   15733: ldc_w '#DEDEDE '
    //   15736: invokevirtual getBytes : ()[B
    //   15739: iconst_0
    //   15740: invokespecial <init> : ([BI)V
    //   15743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15748: aload #5
    //   15750: sipush #719
    //   15753: ldc_w -2171170
    //   15756: invokeinterface setAlignedInt : (II)V
    //   15761: aload #5
    //   15763: sipush #720
    //   15766: new org/renjin/gcc/runtime/BytePtr
    //   15769: dup
    //   15770: ldc_w 'gray88 '
    //   15773: invokevirtual getBytes : ()[B
    //   15776: iconst_0
    //   15777: invokespecial <init> : ([BI)V
    //   15780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15785: aload #5
    //   15787: sipush #721
    //   15790: new org/renjin/gcc/runtime/BytePtr
    //   15793: dup
    //   15794: ldc_w '#E0E0E0 '
    //   15797: invokevirtual getBytes : ()[B
    //   15800: iconst_0
    //   15801: invokespecial <init> : ([BI)V
    //   15804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15809: aload #5
    //   15811: sipush #722
    //   15814: ldc_w -2039584
    //   15817: invokeinterface setAlignedInt : (II)V
    //   15822: aload #5
    //   15824: sipush #723
    //   15827: new org/renjin/gcc/runtime/BytePtr
    //   15830: dup
    //   15831: ldc_w 'gray89 '
    //   15834: invokevirtual getBytes : ()[B
    //   15837: iconst_0
    //   15838: invokespecial <init> : ([BI)V
    //   15841: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15846: aload #5
    //   15848: sipush #724
    //   15851: new org/renjin/gcc/runtime/BytePtr
    //   15854: dup
    //   15855: ldc_w '#E3E3E3 '
    //   15858: invokevirtual getBytes : ()[B
    //   15861: iconst_0
    //   15862: invokespecial <init> : ([BI)V
    //   15865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15870: aload #5
    //   15872: sipush #725
    //   15875: ldc_w -1842205
    //   15878: invokeinterface setAlignedInt : (II)V
    //   15883: aload #5
    //   15885: sipush #726
    //   15888: new org/renjin/gcc/runtime/BytePtr
    //   15891: dup
    //   15892: ldc_w 'gray90 '
    //   15895: invokevirtual getBytes : ()[B
    //   15898: iconst_0
    //   15899: invokespecial <init> : ([BI)V
    //   15902: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15907: aload #5
    //   15909: sipush #727
    //   15912: new org/renjin/gcc/runtime/BytePtr
    //   15915: dup
    //   15916: ldc_w '#E5E5E5 '
    //   15919: invokevirtual getBytes : ()[B
    //   15922: iconst_0
    //   15923: invokespecial <init> : ([BI)V
    //   15926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15931: aload #5
    //   15933: sipush #728
    //   15936: ldc_w -1710619
    //   15939: invokeinterface setAlignedInt : (II)V
    //   15944: aload #5
    //   15946: sipush #729
    //   15949: new org/renjin/gcc/runtime/BytePtr
    //   15952: dup
    //   15953: ldc_w 'gray91 '
    //   15956: invokevirtual getBytes : ()[B
    //   15959: iconst_0
    //   15960: invokespecial <init> : ([BI)V
    //   15963: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15968: aload #5
    //   15970: sipush #730
    //   15973: new org/renjin/gcc/runtime/BytePtr
    //   15976: dup
    //   15977: ldc_w '#E8E8E8 '
    //   15980: invokevirtual getBytes : ()[B
    //   15983: iconst_0
    //   15984: invokespecial <init> : ([BI)V
    //   15987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   15992: aload #5
    //   15994: sipush #731
    //   15997: ldc_w -1513240
    //   16000: invokeinterface setAlignedInt : (II)V
    //   16005: aload #5
    //   16007: sipush #732
    //   16010: new org/renjin/gcc/runtime/BytePtr
    //   16013: dup
    //   16014: ldc_w 'gray92 '
    //   16017: invokevirtual getBytes : ()[B
    //   16020: iconst_0
    //   16021: invokespecial <init> : ([BI)V
    //   16024: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16029: aload #5
    //   16031: sipush #733
    //   16034: new org/renjin/gcc/runtime/BytePtr
    //   16037: dup
    //   16038: ldc_w '#EBEBEB '
    //   16041: invokevirtual getBytes : ()[B
    //   16044: iconst_0
    //   16045: invokespecial <init> : ([BI)V
    //   16048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16053: aload #5
    //   16055: sipush #734
    //   16058: ldc_w -1315861
    //   16061: invokeinterface setAlignedInt : (II)V
    //   16066: aload #5
    //   16068: sipush #735
    //   16071: new org/renjin/gcc/runtime/BytePtr
    //   16074: dup
    //   16075: ldc_w 'gray93 '
    //   16078: invokevirtual getBytes : ()[B
    //   16081: iconst_0
    //   16082: invokespecial <init> : ([BI)V
    //   16085: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16090: aload #5
    //   16092: sipush #736
    //   16095: new org/renjin/gcc/runtime/BytePtr
    //   16098: dup
    //   16099: ldc_w '#EDEDED '
    //   16102: invokevirtual getBytes : ()[B
    //   16105: iconst_0
    //   16106: invokespecial <init> : ([BI)V
    //   16109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16114: aload #5
    //   16116: sipush #737
    //   16119: ldc_w -1184275
    //   16122: invokeinterface setAlignedInt : (II)V
    //   16127: aload #5
    //   16129: sipush #738
    //   16132: new org/renjin/gcc/runtime/BytePtr
    //   16135: dup
    //   16136: ldc_w 'gray94 '
    //   16139: invokevirtual getBytes : ()[B
    //   16142: iconst_0
    //   16143: invokespecial <init> : ([BI)V
    //   16146: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16151: aload #5
    //   16153: sipush #739
    //   16156: new org/renjin/gcc/runtime/BytePtr
    //   16159: dup
    //   16160: ldc_w '#F0F0F0 '
    //   16163: invokevirtual getBytes : ()[B
    //   16166: iconst_0
    //   16167: invokespecial <init> : ([BI)V
    //   16170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16175: aload #5
    //   16177: sipush #740
    //   16180: ldc_w -986896
    //   16183: invokeinterface setAlignedInt : (II)V
    //   16188: aload #5
    //   16190: sipush #741
    //   16193: new org/renjin/gcc/runtime/BytePtr
    //   16196: dup
    //   16197: ldc_w 'gray95 '
    //   16200: invokevirtual getBytes : ()[B
    //   16203: iconst_0
    //   16204: invokespecial <init> : ([BI)V
    //   16207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16212: aload #5
    //   16214: sipush #742
    //   16217: new org/renjin/gcc/runtime/BytePtr
    //   16220: dup
    //   16221: ldc_w '#F2F2F2 '
    //   16224: invokevirtual getBytes : ()[B
    //   16227: iconst_0
    //   16228: invokespecial <init> : ([BI)V
    //   16231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16236: aload #5
    //   16238: sipush #743
    //   16241: ldc_w -855310
    //   16244: invokeinterface setAlignedInt : (II)V
    //   16249: aload #5
    //   16251: sipush #744
    //   16254: new org/renjin/gcc/runtime/BytePtr
    //   16257: dup
    //   16258: ldc_w 'gray96 '
    //   16261: invokevirtual getBytes : ()[B
    //   16264: iconst_0
    //   16265: invokespecial <init> : ([BI)V
    //   16268: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16273: aload #5
    //   16275: sipush #745
    //   16278: new org/renjin/gcc/runtime/BytePtr
    //   16281: dup
    //   16282: ldc_w '#F5F5F5 '
    //   16285: invokevirtual getBytes : ()[B
    //   16288: iconst_0
    //   16289: invokespecial <init> : ([BI)V
    //   16292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16297: aload #5
    //   16299: sipush #746
    //   16302: ldc_w -657931
    //   16305: invokeinterface setAlignedInt : (II)V
    //   16310: aload #5
    //   16312: sipush #747
    //   16315: new org/renjin/gcc/runtime/BytePtr
    //   16318: dup
    //   16319: ldc_w 'gray97 '
    //   16322: invokevirtual getBytes : ()[B
    //   16325: iconst_0
    //   16326: invokespecial <init> : ([BI)V
    //   16329: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16334: aload #5
    //   16336: sipush #748
    //   16339: new org/renjin/gcc/runtime/BytePtr
    //   16342: dup
    //   16343: ldc_w '#F7F7F7 '
    //   16346: invokevirtual getBytes : ()[B
    //   16349: iconst_0
    //   16350: invokespecial <init> : ([BI)V
    //   16353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16358: aload #5
    //   16360: sipush #749
    //   16363: ldc_w -526345
    //   16366: invokeinterface setAlignedInt : (II)V
    //   16371: aload #5
    //   16373: sipush #750
    //   16376: new org/renjin/gcc/runtime/BytePtr
    //   16379: dup
    //   16380: ldc_w 'gray98 '
    //   16383: invokevirtual getBytes : ()[B
    //   16386: iconst_0
    //   16387: invokespecial <init> : ([BI)V
    //   16390: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16395: aload #5
    //   16397: sipush #751
    //   16400: new org/renjin/gcc/runtime/BytePtr
    //   16403: dup
    //   16404: ldc_w '#FAFAFA '
    //   16407: invokevirtual getBytes : ()[B
    //   16410: iconst_0
    //   16411: invokespecial <init> : ([BI)V
    //   16414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16419: aload #5
    //   16421: sipush #752
    //   16424: ldc_w -328966
    //   16427: invokeinterface setAlignedInt : (II)V
    //   16432: aload #5
    //   16434: sipush #753
    //   16437: new org/renjin/gcc/runtime/BytePtr
    //   16440: dup
    //   16441: ldc_w 'gray99 '
    //   16444: invokevirtual getBytes : ()[B
    //   16447: iconst_0
    //   16448: invokespecial <init> : ([BI)V
    //   16451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16456: aload #5
    //   16458: sipush #754
    //   16461: new org/renjin/gcc/runtime/BytePtr
    //   16464: dup
    //   16465: ldc_w '#FCFCFC '
    //   16468: invokevirtual getBytes : ()[B
    //   16471: iconst_0
    //   16472: invokespecial <init> : ([BI)V
    //   16475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16480: aload #5
    //   16482: sipush #755
    //   16485: ldc_w -197380
    //   16488: invokeinterface setAlignedInt : (II)V
    //   16493: aload #5
    //   16495: sipush #756
    //   16498: new org/renjin/gcc/runtime/BytePtr
    //   16501: dup
    //   16502: ldc_w 'gray100 '
    //   16505: invokevirtual getBytes : ()[B
    //   16508: iconst_0
    //   16509: invokespecial <init> : ([BI)V
    //   16512: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16517: aload #5
    //   16519: sipush #757
    //   16522: new org/renjin/gcc/runtime/BytePtr
    //   16525: dup
    //   16526: ldc_w '#FFFFFF '
    //   16529: invokevirtual getBytes : ()[B
    //   16532: iconst_0
    //   16533: invokespecial <init> : ([BI)V
    //   16536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16541: aload #5
    //   16543: sipush #758
    //   16546: iconst_m1
    //   16547: invokeinterface setAlignedInt : (II)V
    //   16552: aload #5
    //   16554: sipush #759
    //   16557: new org/renjin/gcc/runtime/BytePtr
    //   16560: dup
    //   16561: ldc_w 'green '
    //   16564: invokevirtual getBytes : ()[B
    //   16567: iconst_0
    //   16568: invokespecial <init> : ([BI)V
    //   16571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16576: aload #5
    //   16578: sipush #760
    //   16581: new org/renjin/gcc/runtime/BytePtr
    //   16584: dup
    //   16585: ldc_w '#00FF00 '
    //   16588: invokevirtual getBytes : ()[B
    //   16591: iconst_0
    //   16592: invokespecial <init> : ([BI)V
    //   16595: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16600: aload #5
    //   16602: sipush #761
    //   16605: ldc_w -16711936
    //   16608: invokeinterface setAlignedInt : (II)V
    //   16613: aload #5
    //   16615: sipush #762
    //   16618: new org/renjin/gcc/runtime/BytePtr
    //   16621: dup
    //   16622: ldc_w 'green1 '
    //   16625: invokevirtual getBytes : ()[B
    //   16628: iconst_0
    //   16629: invokespecial <init> : ([BI)V
    //   16632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16637: aload #5
    //   16639: sipush #763
    //   16642: new org/renjin/gcc/runtime/BytePtr
    //   16645: dup
    //   16646: ldc_w '#00FF00 '
    //   16649: invokevirtual getBytes : ()[B
    //   16652: iconst_0
    //   16653: invokespecial <init> : ([BI)V
    //   16656: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16661: aload #5
    //   16663: sipush #764
    //   16666: ldc_w -16711936
    //   16669: invokeinterface setAlignedInt : (II)V
    //   16674: aload #5
    //   16676: sipush #765
    //   16679: new org/renjin/gcc/runtime/BytePtr
    //   16682: dup
    //   16683: ldc_w 'green2 '
    //   16686: invokevirtual getBytes : ()[B
    //   16689: iconst_0
    //   16690: invokespecial <init> : ([BI)V
    //   16693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16698: aload #5
    //   16700: sipush #766
    //   16703: new org/renjin/gcc/runtime/BytePtr
    //   16706: dup
    //   16707: ldc_w '#00EE00 '
    //   16710: invokevirtual getBytes : ()[B
    //   16713: iconst_0
    //   16714: invokespecial <init> : ([BI)V
    //   16717: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16722: aload #5
    //   16724: sipush #767
    //   16727: ldc_w -16716288
    //   16730: invokeinterface setAlignedInt : (II)V
    //   16735: aload #5
    //   16737: sipush #768
    //   16740: new org/renjin/gcc/runtime/BytePtr
    //   16743: dup
    //   16744: ldc_w 'green3 '
    //   16747: invokevirtual getBytes : ()[B
    //   16750: iconst_0
    //   16751: invokespecial <init> : ([BI)V
    //   16754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16759: aload #5
    //   16761: sipush #769
    //   16764: new org/renjin/gcc/runtime/BytePtr
    //   16767: dup
    //   16768: ldc_w '#00CD00 '
    //   16771: invokevirtual getBytes : ()[B
    //   16774: iconst_0
    //   16775: invokespecial <init> : ([BI)V
    //   16778: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16783: aload #5
    //   16785: sipush #770
    //   16788: ldc_w -16724736
    //   16791: invokeinterface setAlignedInt : (II)V
    //   16796: aload #5
    //   16798: sipush #771
    //   16801: new org/renjin/gcc/runtime/BytePtr
    //   16804: dup
    //   16805: ldc_w 'green4 '
    //   16808: invokevirtual getBytes : ()[B
    //   16811: iconst_0
    //   16812: invokespecial <init> : ([BI)V
    //   16815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16820: aload #5
    //   16822: sipush #772
    //   16825: new org/renjin/gcc/runtime/BytePtr
    //   16828: dup
    //   16829: ldc_w '#008B00 '
    //   16832: invokevirtual getBytes : ()[B
    //   16835: iconst_0
    //   16836: invokespecial <init> : ([BI)V
    //   16839: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16844: aload #5
    //   16846: sipush #773
    //   16849: ldc_w -16741632
    //   16852: invokeinterface setAlignedInt : (II)V
    //   16857: aload #5
    //   16859: sipush #774
    //   16862: new org/renjin/gcc/runtime/BytePtr
    //   16865: dup
    //   16866: ldc_w 'greenyellow '
    //   16869: invokevirtual getBytes : ()[B
    //   16872: iconst_0
    //   16873: invokespecial <init> : ([BI)V
    //   16876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16881: aload #5
    //   16883: sipush #775
    //   16886: new org/renjin/gcc/runtime/BytePtr
    //   16889: dup
    //   16890: ldc_w '#ADFF2F '
    //   16893: invokevirtual getBytes : ()[B
    //   16896: iconst_0
    //   16897: invokespecial <init> : ([BI)V
    //   16900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16905: aload #5
    //   16907: sipush #776
    //   16910: ldc_w -13631571
    //   16913: invokeinterface setAlignedInt : (II)V
    //   16918: aload #5
    //   16920: sipush #777
    //   16923: new org/renjin/gcc/runtime/BytePtr
    //   16926: dup
    //   16927: ldc_w 'grey '
    //   16930: invokevirtual getBytes : ()[B
    //   16933: iconst_0
    //   16934: invokespecial <init> : ([BI)V
    //   16937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16942: aload #5
    //   16944: sipush #778
    //   16947: new org/renjin/gcc/runtime/BytePtr
    //   16950: dup
    //   16951: ldc_w '#BEBEBE '
    //   16954: invokevirtual getBytes : ()[B
    //   16957: iconst_0
    //   16958: invokespecial <init> : ([BI)V
    //   16961: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   16966: aload #5
    //   16968: sipush #779
    //   16971: ldc_w -4276546
    //   16974: invokeinterface setAlignedInt : (II)V
    //   16979: aload #5
    //   16981: sipush #780
    //   16984: new org/renjin/gcc/runtime/BytePtr
    //   16987: dup
    //   16988: ldc_w 'grey0 '
    //   16991: invokevirtual getBytes : ()[B
    //   16994: iconst_0
    //   16995: invokespecial <init> : ([BI)V
    //   16998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17003: aload #5
    //   17005: sipush #781
    //   17008: new org/renjin/gcc/runtime/BytePtr
    //   17011: dup
    //   17012: ldc_w '#000000 '
    //   17015: invokevirtual getBytes : ()[B
    //   17018: iconst_0
    //   17019: invokespecial <init> : ([BI)V
    //   17022: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17027: aload #5
    //   17029: sipush #782
    //   17032: ldc_w -16777216
    //   17035: invokeinterface setAlignedInt : (II)V
    //   17040: aload #5
    //   17042: sipush #783
    //   17045: new org/renjin/gcc/runtime/BytePtr
    //   17048: dup
    //   17049: ldc_w 'grey1 '
    //   17052: invokevirtual getBytes : ()[B
    //   17055: iconst_0
    //   17056: invokespecial <init> : ([BI)V
    //   17059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17064: aload #5
    //   17066: sipush #784
    //   17069: new org/renjin/gcc/runtime/BytePtr
    //   17072: dup
    //   17073: ldc_w '#030303 '
    //   17076: invokevirtual getBytes : ()[B
    //   17079: iconst_0
    //   17080: invokespecial <init> : ([BI)V
    //   17083: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17088: aload #5
    //   17090: sipush #785
    //   17093: ldc_w -16579837
    //   17096: invokeinterface setAlignedInt : (II)V
    //   17101: aload #5
    //   17103: sipush #786
    //   17106: new org/renjin/gcc/runtime/BytePtr
    //   17109: dup
    //   17110: ldc_w 'grey2 '
    //   17113: invokevirtual getBytes : ()[B
    //   17116: iconst_0
    //   17117: invokespecial <init> : ([BI)V
    //   17120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17125: aload #5
    //   17127: sipush #787
    //   17130: new org/renjin/gcc/runtime/BytePtr
    //   17133: dup
    //   17134: ldc_w '#050505 '
    //   17137: invokevirtual getBytes : ()[B
    //   17140: iconst_0
    //   17141: invokespecial <init> : ([BI)V
    //   17144: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17149: aload #5
    //   17151: sipush #788
    //   17154: ldc_w -16448251
    //   17157: invokeinterface setAlignedInt : (II)V
    //   17162: aload #5
    //   17164: sipush #789
    //   17167: new org/renjin/gcc/runtime/BytePtr
    //   17170: dup
    //   17171: ldc_w 'grey3 '
    //   17174: invokevirtual getBytes : ()[B
    //   17177: iconst_0
    //   17178: invokespecial <init> : ([BI)V
    //   17181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17186: aload #5
    //   17188: sipush #790
    //   17191: new org/renjin/gcc/runtime/BytePtr
    //   17194: dup
    //   17195: ldc_w '#080808 '
    //   17198: invokevirtual getBytes : ()[B
    //   17201: iconst_0
    //   17202: invokespecial <init> : ([BI)V
    //   17205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17210: aload #5
    //   17212: sipush #791
    //   17215: ldc_w -16250872
    //   17218: invokeinterface setAlignedInt : (II)V
    //   17223: aload #5
    //   17225: sipush #792
    //   17228: new org/renjin/gcc/runtime/BytePtr
    //   17231: dup
    //   17232: ldc_w 'grey4 '
    //   17235: invokevirtual getBytes : ()[B
    //   17238: iconst_0
    //   17239: invokespecial <init> : ([BI)V
    //   17242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17247: aload #5
    //   17249: sipush #793
    //   17252: new org/renjin/gcc/runtime/BytePtr
    //   17255: dup
    //   17256: ldc_w '#0A0A0A '
    //   17259: invokevirtual getBytes : ()[B
    //   17262: iconst_0
    //   17263: invokespecial <init> : ([BI)V
    //   17266: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17271: aload #5
    //   17273: sipush #794
    //   17276: ldc_w -16119286
    //   17279: invokeinterface setAlignedInt : (II)V
    //   17284: aload #5
    //   17286: sipush #795
    //   17289: new org/renjin/gcc/runtime/BytePtr
    //   17292: dup
    //   17293: ldc_w 'grey5 '
    //   17296: invokevirtual getBytes : ()[B
    //   17299: iconst_0
    //   17300: invokespecial <init> : ([BI)V
    //   17303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17308: aload #5
    //   17310: sipush #796
    //   17313: new org/renjin/gcc/runtime/BytePtr
    //   17316: dup
    //   17317: ldc_w '#0D0D0D '
    //   17320: invokevirtual getBytes : ()[B
    //   17323: iconst_0
    //   17324: invokespecial <init> : ([BI)V
    //   17327: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17332: aload #5
    //   17334: sipush #797
    //   17337: ldc_w -15921907
    //   17340: invokeinterface setAlignedInt : (II)V
    //   17345: aload #5
    //   17347: sipush #798
    //   17350: new org/renjin/gcc/runtime/BytePtr
    //   17353: dup
    //   17354: ldc_w 'grey6 '
    //   17357: invokevirtual getBytes : ()[B
    //   17360: iconst_0
    //   17361: invokespecial <init> : ([BI)V
    //   17364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17369: aload #5
    //   17371: sipush #799
    //   17374: new org/renjin/gcc/runtime/BytePtr
    //   17377: dup
    //   17378: ldc_w '#0F0F0F '
    //   17381: invokevirtual getBytes : ()[B
    //   17384: iconst_0
    //   17385: invokespecial <init> : ([BI)V
    //   17388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17393: aload #5
    //   17395: sipush #800
    //   17398: ldc_w -15790321
    //   17401: invokeinterface setAlignedInt : (II)V
    //   17406: aload #5
    //   17408: sipush #801
    //   17411: new org/renjin/gcc/runtime/BytePtr
    //   17414: dup
    //   17415: ldc_w 'grey7 '
    //   17418: invokevirtual getBytes : ()[B
    //   17421: iconst_0
    //   17422: invokespecial <init> : ([BI)V
    //   17425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17430: aload #5
    //   17432: sipush #802
    //   17435: new org/renjin/gcc/runtime/BytePtr
    //   17438: dup
    //   17439: ldc_w '#121212 '
    //   17442: invokevirtual getBytes : ()[B
    //   17445: iconst_0
    //   17446: invokespecial <init> : ([BI)V
    //   17449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17454: aload #5
    //   17456: sipush #803
    //   17459: ldc_w -15592942
    //   17462: invokeinterface setAlignedInt : (II)V
    //   17467: aload #5
    //   17469: sipush #804
    //   17472: new org/renjin/gcc/runtime/BytePtr
    //   17475: dup
    //   17476: ldc_w 'grey8 '
    //   17479: invokevirtual getBytes : ()[B
    //   17482: iconst_0
    //   17483: invokespecial <init> : ([BI)V
    //   17486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17491: aload #5
    //   17493: sipush #805
    //   17496: new org/renjin/gcc/runtime/BytePtr
    //   17499: dup
    //   17500: ldc_w '#141414 '
    //   17503: invokevirtual getBytes : ()[B
    //   17506: iconst_0
    //   17507: invokespecial <init> : ([BI)V
    //   17510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17515: aload #5
    //   17517: sipush #806
    //   17520: ldc_w -15461356
    //   17523: invokeinterface setAlignedInt : (II)V
    //   17528: aload #5
    //   17530: sipush #807
    //   17533: new org/renjin/gcc/runtime/BytePtr
    //   17536: dup
    //   17537: ldc_w 'grey9 '
    //   17540: invokevirtual getBytes : ()[B
    //   17543: iconst_0
    //   17544: invokespecial <init> : ([BI)V
    //   17547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17552: aload #5
    //   17554: sipush #808
    //   17557: new org/renjin/gcc/runtime/BytePtr
    //   17560: dup
    //   17561: ldc_w '#171717 '
    //   17564: invokevirtual getBytes : ()[B
    //   17567: iconst_0
    //   17568: invokespecial <init> : ([BI)V
    //   17571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17576: aload #5
    //   17578: sipush #809
    //   17581: ldc_w -15263977
    //   17584: invokeinterface setAlignedInt : (II)V
    //   17589: aload #5
    //   17591: sipush #810
    //   17594: new org/renjin/gcc/runtime/BytePtr
    //   17597: dup
    //   17598: ldc_w 'grey10 '
    //   17601: invokevirtual getBytes : ()[B
    //   17604: iconst_0
    //   17605: invokespecial <init> : ([BI)V
    //   17608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17613: aload #5
    //   17615: sipush #811
    //   17618: new org/renjin/gcc/runtime/BytePtr
    //   17621: dup
    //   17622: ldc_w '#1A1A1A '
    //   17625: invokevirtual getBytes : ()[B
    //   17628: iconst_0
    //   17629: invokespecial <init> : ([BI)V
    //   17632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17637: aload #5
    //   17639: sipush #812
    //   17642: ldc_w -15066598
    //   17645: invokeinterface setAlignedInt : (II)V
    //   17650: aload #5
    //   17652: sipush #813
    //   17655: new org/renjin/gcc/runtime/BytePtr
    //   17658: dup
    //   17659: ldc_w 'grey11 '
    //   17662: invokevirtual getBytes : ()[B
    //   17665: iconst_0
    //   17666: invokespecial <init> : ([BI)V
    //   17669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17674: aload #5
    //   17676: sipush #814
    //   17679: new org/renjin/gcc/runtime/BytePtr
    //   17682: dup
    //   17683: ldc_w '#1C1C1C '
    //   17686: invokevirtual getBytes : ()[B
    //   17689: iconst_0
    //   17690: invokespecial <init> : ([BI)V
    //   17693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17698: aload #5
    //   17700: sipush #815
    //   17703: ldc_w -14935012
    //   17706: invokeinterface setAlignedInt : (II)V
    //   17711: aload #5
    //   17713: sipush #816
    //   17716: new org/renjin/gcc/runtime/BytePtr
    //   17719: dup
    //   17720: ldc_w 'grey12 '
    //   17723: invokevirtual getBytes : ()[B
    //   17726: iconst_0
    //   17727: invokespecial <init> : ([BI)V
    //   17730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17735: aload #5
    //   17737: sipush #817
    //   17740: new org/renjin/gcc/runtime/BytePtr
    //   17743: dup
    //   17744: ldc_w '#1F1F1F '
    //   17747: invokevirtual getBytes : ()[B
    //   17750: iconst_0
    //   17751: invokespecial <init> : ([BI)V
    //   17754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17759: aload #5
    //   17761: sipush #818
    //   17764: ldc_w -14737633
    //   17767: invokeinterface setAlignedInt : (II)V
    //   17772: aload #5
    //   17774: sipush #819
    //   17777: new org/renjin/gcc/runtime/BytePtr
    //   17780: dup
    //   17781: ldc_w 'grey13 '
    //   17784: invokevirtual getBytes : ()[B
    //   17787: iconst_0
    //   17788: invokespecial <init> : ([BI)V
    //   17791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17796: aload #5
    //   17798: sipush #820
    //   17801: new org/renjin/gcc/runtime/BytePtr
    //   17804: dup
    //   17805: ldc_w '#212121 '
    //   17808: invokevirtual getBytes : ()[B
    //   17811: iconst_0
    //   17812: invokespecial <init> : ([BI)V
    //   17815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17820: aload #5
    //   17822: sipush #821
    //   17825: ldc_w -14606047
    //   17828: invokeinterface setAlignedInt : (II)V
    //   17833: aload #5
    //   17835: sipush #822
    //   17838: new org/renjin/gcc/runtime/BytePtr
    //   17841: dup
    //   17842: ldc_w 'grey14 '
    //   17845: invokevirtual getBytes : ()[B
    //   17848: iconst_0
    //   17849: invokespecial <init> : ([BI)V
    //   17852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17857: aload #5
    //   17859: sipush #823
    //   17862: new org/renjin/gcc/runtime/BytePtr
    //   17865: dup
    //   17866: ldc_w '#242424 '
    //   17869: invokevirtual getBytes : ()[B
    //   17872: iconst_0
    //   17873: invokespecial <init> : ([BI)V
    //   17876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17881: aload #5
    //   17883: sipush #824
    //   17886: ldc_w -14408668
    //   17889: invokeinterface setAlignedInt : (II)V
    //   17894: aload #5
    //   17896: sipush #825
    //   17899: new org/renjin/gcc/runtime/BytePtr
    //   17902: dup
    //   17903: ldc_w 'grey15 '
    //   17906: invokevirtual getBytes : ()[B
    //   17909: iconst_0
    //   17910: invokespecial <init> : ([BI)V
    //   17913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17918: aload #5
    //   17920: sipush #826
    //   17923: new org/renjin/gcc/runtime/BytePtr
    //   17926: dup
    //   17927: ldc_w '#262626 '
    //   17930: invokevirtual getBytes : ()[B
    //   17933: iconst_0
    //   17934: invokespecial <init> : ([BI)V
    //   17937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17942: aload #5
    //   17944: sipush #827
    //   17947: ldc_w -14277082
    //   17950: invokeinterface setAlignedInt : (II)V
    //   17955: aload #5
    //   17957: sipush #828
    //   17960: new org/renjin/gcc/runtime/BytePtr
    //   17963: dup
    //   17964: ldc_w 'grey16 '
    //   17967: invokevirtual getBytes : ()[B
    //   17970: iconst_0
    //   17971: invokespecial <init> : ([BI)V
    //   17974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   17979: aload #5
    //   17981: sipush #829
    //   17984: new org/renjin/gcc/runtime/BytePtr
    //   17987: dup
    //   17988: ldc_w '#292929 '
    //   17991: invokevirtual getBytes : ()[B
    //   17994: iconst_0
    //   17995: invokespecial <init> : ([BI)V
    //   17998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18003: aload #5
    //   18005: sipush #830
    //   18008: ldc_w -14079703
    //   18011: invokeinterface setAlignedInt : (II)V
    //   18016: aload #5
    //   18018: sipush #831
    //   18021: new org/renjin/gcc/runtime/BytePtr
    //   18024: dup
    //   18025: ldc_w 'grey17 '
    //   18028: invokevirtual getBytes : ()[B
    //   18031: iconst_0
    //   18032: invokespecial <init> : ([BI)V
    //   18035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18040: aload #5
    //   18042: sipush #832
    //   18045: new org/renjin/gcc/runtime/BytePtr
    //   18048: dup
    //   18049: ldc_w '#2B2B2B '
    //   18052: invokevirtual getBytes : ()[B
    //   18055: iconst_0
    //   18056: invokespecial <init> : ([BI)V
    //   18059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18064: aload #5
    //   18066: sipush #833
    //   18069: ldc_w -13948117
    //   18072: invokeinterface setAlignedInt : (II)V
    //   18077: aload #5
    //   18079: sipush #834
    //   18082: new org/renjin/gcc/runtime/BytePtr
    //   18085: dup
    //   18086: ldc_w 'grey18 '
    //   18089: invokevirtual getBytes : ()[B
    //   18092: iconst_0
    //   18093: invokespecial <init> : ([BI)V
    //   18096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18101: aload #5
    //   18103: sipush #835
    //   18106: new org/renjin/gcc/runtime/BytePtr
    //   18109: dup
    //   18110: ldc_w '#2E2E2E '
    //   18113: invokevirtual getBytes : ()[B
    //   18116: iconst_0
    //   18117: invokespecial <init> : ([BI)V
    //   18120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18125: aload #5
    //   18127: sipush #836
    //   18130: ldc_w -13750738
    //   18133: invokeinterface setAlignedInt : (II)V
    //   18138: aload #5
    //   18140: sipush #837
    //   18143: new org/renjin/gcc/runtime/BytePtr
    //   18146: dup
    //   18147: ldc_w 'grey19 '
    //   18150: invokevirtual getBytes : ()[B
    //   18153: iconst_0
    //   18154: invokespecial <init> : ([BI)V
    //   18157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18162: aload #5
    //   18164: sipush #838
    //   18167: new org/renjin/gcc/runtime/BytePtr
    //   18170: dup
    //   18171: ldc_w '#303030 '
    //   18174: invokevirtual getBytes : ()[B
    //   18177: iconst_0
    //   18178: invokespecial <init> : ([BI)V
    //   18181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18186: aload #5
    //   18188: sipush #839
    //   18191: ldc_w -13619152
    //   18194: invokeinterface setAlignedInt : (II)V
    //   18199: aload #5
    //   18201: sipush #840
    //   18204: new org/renjin/gcc/runtime/BytePtr
    //   18207: dup
    //   18208: ldc_w 'grey20 '
    //   18211: invokevirtual getBytes : ()[B
    //   18214: iconst_0
    //   18215: invokespecial <init> : ([BI)V
    //   18218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18223: aload #5
    //   18225: sipush #841
    //   18228: new org/renjin/gcc/runtime/BytePtr
    //   18231: dup
    //   18232: ldc_w '#333333 '
    //   18235: invokevirtual getBytes : ()[B
    //   18238: iconst_0
    //   18239: invokespecial <init> : ([BI)V
    //   18242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18247: aload #5
    //   18249: sipush #842
    //   18252: ldc_w -13421773
    //   18255: invokeinterface setAlignedInt : (II)V
    //   18260: aload #5
    //   18262: sipush #843
    //   18265: new org/renjin/gcc/runtime/BytePtr
    //   18268: dup
    //   18269: ldc_w 'grey21 '
    //   18272: invokevirtual getBytes : ()[B
    //   18275: iconst_0
    //   18276: invokespecial <init> : ([BI)V
    //   18279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18284: aload #5
    //   18286: sipush #844
    //   18289: new org/renjin/gcc/runtime/BytePtr
    //   18292: dup
    //   18293: ldc_w '#363636 '
    //   18296: invokevirtual getBytes : ()[B
    //   18299: iconst_0
    //   18300: invokespecial <init> : ([BI)V
    //   18303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18308: aload #5
    //   18310: sipush #845
    //   18313: ldc_w -13224394
    //   18316: invokeinterface setAlignedInt : (II)V
    //   18321: aload #5
    //   18323: sipush #846
    //   18326: new org/renjin/gcc/runtime/BytePtr
    //   18329: dup
    //   18330: ldc_w 'grey22 '
    //   18333: invokevirtual getBytes : ()[B
    //   18336: iconst_0
    //   18337: invokespecial <init> : ([BI)V
    //   18340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18345: aload #5
    //   18347: sipush #847
    //   18350: new org/renjin/gcc/runtime/BytePtr
    //   18353: dup
    //   18354: ldc_w '#383838 '
    //   18357: invokevirtual getBytes : ()[B
    //   18360: iconst_0
    //   18361: invokespecial <init> : ([BI)V
    //   18364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18369: aload #5
    //   18371: sipush #848
    //   18374: ldc_w -13092808
    //   18377: invokeinterface setAlignedInt : (II)V
    //   18382: aload #5
    //   18384: sipush #849
    //   18387: new org/renjin/gcc/runtime/BytePtr
    //   18390: dup
    //   18391: ldc_w 'grey23 '
    //   18394: invokevirtual getBytes : ()[B
    //   18397: iconst_0
    //   18398: invokespecial <init> : ([BI)V
    //   18401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18406: aload #5
    //   18408: sipush #850
    //   18411: new org/renjin/gcc/runtime/BytePtr
    //   18414: dup
    //   18415: ldc_w '#3B3B3B '
    //   18418: invokevirtual getBytes : ()[B
    //   18421: iconst_0
    //   18422: invokespecial <init> : ([BI)V
    //   18425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18430: aload #5
    //   18432: sipush #851
    //   18435: ldc_w -12895429
    //   18438: invokeinterface setAlignedInt : (II)V
    //   18443: aload #5
    //   18445: sipush #852
    //   18448: new org/renjin/gcc/runtime/BytePtr
    //   18451: dup
    //   18452: ldc_w 'grey24 '
    //   18455: invokevirtual getBytes : ()[B
    //   18458: iconst_0
    //   18459: invokespecial <init> : ([BI)V
    //   18462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18467: aload #5
    //   18469: sipush #853
    //   18472: new org/renjin/gcc/runtime/BytePtr
    //   18475: dup
    //   18476: ldc_w '#3D3D3D '
    //   18479: invokevirtual getBytes : ()[B
    //   18482: iconst_0
    //   18483: invokespecial <init> : ([BI)V
    //   18486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18491: aload #5
    //   18493: sipush #854
    //   18496: ldc_w -12763843
    //   18499: invokeinterface setAlignedInt : (II)V
    //   18504: aload #5
    //   18506: sipush #855
    //   18509: new org/renjin/gcc/runtime/BytePtr
    //   18512: dup
    //   18513: ldc_w 'grey25 '
    //   18516: invokevirtual getBytes : ()[B
    //   18519: iconst_0
    //   18520: invokespecial <init> : ([BI)V
    //   18523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18528: aload #5
    //   18530: sipush #856
    //   18533: new org/renjin/gcc/runtime/BytePtr
    //   18536: dup
    //   18537: ldc_w '#404040 '
    //   18540: invokevirtual getBytes : ()[B
    //   18543: iconst_0
    //   18544: invokespecial <init> : ([BI)V
    //   18547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18552: aload #5
    //   18554: sipush #857
    //   18557: ldc_w -12566464
    //   18560: invokeinterface setAlignedInt : (II)V
    //   18565: aload #5
    //   18567: sipush #858
    //   18570: new org/renjin/gcc/runtime/BytePtr
    //   18573: dup
    //   18574: ldc_w 'grey26 '
    //   18577: invokevirtual getBytes : ()[B
    //   18580: iconst_0
    //   18581: invokespecial <init> : ([BI)V
    //   18584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18589: aload #5
    //   18591: sipush #859
    //   18594: new org/renjin/gcc/runtime/BytePtr
    //   18597: dup
    //   18598: ldc_w '#424242 '
    //   18601: invokevirtual getBytes : ()[B
    //   18604: iconst_0
    //   18605: invokespecial <init> : ([BI)V
    //   18608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18613: aload #5
    //   18615: sipush #860
    //   18618: ldc_w -12434878
    //   18621: invokeinterface setAlignedInt : (II)V
    //   18626: aload #5
    //   18628: sipush #861
    //   18631: new org/renjin/gcc/runtime/BytePtr
    //   18634: dup
    //   18635: ldc_w 'grey27 '
    //   18638: invokevirtual getBytes : ()[B
    //   18641: iconst_0
    //   18642: invokespecial <init> : ([BI)V
    //   18645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18650: aload #5
    //   18652: sipush #862
    //   18655: new org/renjin/gcc/runtime/BytePtr
    //   18658: dup
    //   18659: ldc_w '#454545 '
    //   18662: invokevirtual getBytes : ()[B
    //   18665: iconst_0
    //   18666: invokespecial <init> : ([BI)V
    //   18669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18674: aload #5
    //   18676: sipush #863
    //   18679: ldc_w -12237499
    //   18682: invokeinterface setAlignedInt : (II)V
    //   18687: aload #5
    //   18689: sipush #864
    //   18692: new org/renjin/gcc/runtime/BytePtr
    //   18695: dup
    //   18696: ldc_w 'grey28 '
    //   18699: invokevirtual getBytes : ()[B
    //   18702: iconst_0
    //   18703: invokespecial <init> : ([BI)V
    //   18706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18711: aload #5
    //   18713: sipush #865
    //   18716: new org/renjin/gcc/runtime/BytePtr
    //   18719: dup
    //   18720: ldc_w '#474747 '
    //   18723: invokevirtual getBytes : ()[B
    //   18726: iconst_0
    //   18727: invokespecial <init> : ([BI)V
    //   18730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18735: aload #5
    //   18737: sipush #866
    //   18740: ldc_w -12105913
    //   18743: invokeinterface setAlignedInt : (II)V
    //   18748: aload #5
    //   18750: sipush #867
    //   18753: new org/renjin/gcc/runtime/BytePtr
    //   18756: dup
    //   18757: ldc_w 'grey29 '
    //   18760: invokevirtual getBytes : ()[B
    //   18763: iconst_0
    //   18764: invokespecial <init> : ([BI)V
    //   18767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18772: aload #5
    //   18774: sipush #868
    //   18777: new org/renjin/gcc/runtime/BytePtr
    //   18780: dup
    //   18781: ldc_w '#4A4A4A '
    //   18784: invokevirtual getBytes : ()[B
    //   18787: iconst_0
    //   18788: invokespecial <init> : ([BI)V
    //   18791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18796: aload #5
    //   18798: sipush #869
    //   18801: ldc_w -11908534
    //   18804: invokeinterface setAlignedInt : (II)V
    //   18809: aload #5
    //   18811: sipush #870
    //   18814: new org/renjin/gcc/runtime/BytePtr
    //   18817: dup
    //   18818: ldc_w 'grey30 '
    //   18821: invokevirtual getBytes : ()[B
    //   18824: iconst_0
    //   18825: invokespecial <init> : ([BI)V
    //   18828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18833: aload #5
    //   18835: sipush #871
    //   18838: new org/renjin/gcc/runtime/BytePtr
    //   18841: dup
    //   18842: ldc_w '#4D4D4D '
    //   18845: invokevirtual getBytes : ()[B
    //   18848: iconst_0
    //   18849: invokespecial <init> : ([BI)V
    //   18852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18857: aload #5
    //   18859: sipush #872
    //   18862: ldc_w -11711155
    //   18865: invokeinterface setAlignedInt : (II)V
    //   18870: aload #5
    //   18872: sipush #873
    //   18875: new org/renjin/gcc/runtime/BytePtr
    //   18878: dup
    //   18879: ldc_w 'grey31 '
    //   18882: invokevirtual getBytes : ()[B
    //   18885: iconst_0
    //   18886: invokespecial <init> : ([BI)V
    //   18889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18894: aload #5
    //   18896: sipush #874
    //   18899: new org/renjin/gcc/runtime/BytePtr
    //   18902: dup
    //   18903: ldc_w '#4F4F4F '
    //   18906: invokevirtual getBytes : ()[B
    //   18909: iconst_0
    //   18910: invokespecial <init> : ([BI)V
    //   18913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18918: aload #5
    //   18920: sipush #875
    //   18923: ldc_w -11579569
    //   18926: invokeinterface setAlignedInt : (II)V
    //   18931: aload #5
    //   18933: sipush #876
    //   18936: new org/renjin/gcc/runtime/BytePtr
    //   18939: dup
    //   18940: ldc_w 'grey32 '
    //   18943: invokevirtual getBytes : ()[B
    //   18946: iconst_0
    //   18947: invokespecial <init> : ([BI)V
    //   18950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18955: aload #5
    //   18957: sipush #877
    //   18960: new org/renjin/gcc/runtime/BytePtr
    //   18963: dup
    //   18964: ldc_w '#525252 '
    //   18967: invokevirtual getBytes : ()[B
    //   18970: iconst_0
    //   18971: invokespecial <init> : ([BI)V
    //   18974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   18979: aload #5
    //   18981: sipush #878
    //   18984: ldc_w -11382190
    //   18987: invokeinterface setAlignedInt : (II)V
    //   18992: aload #5
    //   18994: sipush #879
    //   18997: new org/renjin/gcc/runtime/BytePtr
    //   19000: dup
    //   19001: ldc_w 'grey33 '
    //   19004: invokevirtual getBytes : ()[B
    //   19007: iconst_0
    //   19008: invokespecial <init> : ([BI)V
    //   19011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19016: aload #5
    //   19018: sipush #880
    //   19021: new org/renjin/gcc/runtime/BytePtr
    //   19024: dup
    //   19025: ldc_w '#545454 '
    //   19028: invokevirtual getBytes : ()[B
    //   19031: iconst_0
    //   19032: invokespecial <init> : ([BI)V
    //   19035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19040: aload #5
    //   19042: sipush #881
    //   19045: ldc_w -11250604
    //   19048: invokeinterface setAlignedInt : (II)V
    //   19053: aload #5
    //   19055: sipush #882
    //   19058: new org/renjin/gcc/runtime/BytePtr
    //   19061: dup
    //   19062: ldc_w 'grey34 '
    //   19065: invokevirtual getBytes : ()[B
    //   19068: iconst_0
    //   19069: invokespecial <init> : ([BI)V
    //   19072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19077: aload #5
    //   19079: sipush #883
    //   19082: new org/renjin/gcc/runtime/BytePtr
    //   19085: dup
    //   19086: ldc_w '#575757 '
    //   19089: invokevirtual getBytes : ()[B
    //   19092: iconst_0
    //   19093: invokespecial <init> : ([BI)V
    //   19096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19101: aload #5
    //   19103: sipush #884
    //   19106: ldc_w -11053225
    //   19109: invokeinterface setAlignedInt : (II)V
    //   19114: aload #5
    //   19116: sipush #885
    //   19119: new org/renjin/gcc/runtime/BytePtr
    //   19122: dup
    //   19123: ldc_w 'grey35 '
    //   19126: invokevirtual getBytes : ()[B
    //   19129: iconst_0
    //   19130: invokespecial <init> : ([BI)V
    //   19133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19138: aload #5
    //   19140: sipush #886
    //   19143: new org/renjin/gcc/runtime/BytePtr
    //   19146: dup
    //   19147: ldc_w '#595959 '
    //   19150: invokevirtual getBytes : ()[B
    //   19153: iconst_0
    //   19154: invokespecial <init> : ([BI)V
    //   19157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19162: aload #5
    //   19164: sipush #887
    //   19167: ldc_w -10921639
    //   19170: invokeinterface setAlignedInt : (II)V
    //   19175: aload #5
    //   19177: sipush #888
    //   19180: new org/renjin/gcc/runtime/BytePtr
    //   19183: dup
    //   19184: ldc_w 'grey36 '
    //   19187: invokevirtual getBytes : ()[B
    //   19190: iconst_0
    //   19191: invokespecial <init> : ([BI)V
    //   19194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19199: aload #5
    //   19201: sipush #889
    //   19204: new org/renjin/gcc/runtime/BytePtr
    //   19207: dup
    //   19208: ldc_w '#5C5C5C '
    //   19211: invokevirtual getBytes : ()[B
    //   19214: iconst_0
    //   19215: invokespecial <init> : ([BI)V
    //   19218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19223: aload #5
    //   19225: sipush #890
    //   19228: ldc_w -10724260
    //   19231: invokeinterface setAlignedInt : (II)V
    //   19236: aload #5
    //   19238: sipush #891
    //   19241: new org/renjin/gcc/runtime/BytePtr
    //   19244: dup
    //   19245: ldc_w 'grey37 '
    //   19248: invokevirtual getBytes : ()[B
    //   19251: iconst_0
    //   19252: invokespecial <init> : ([BI)V
    //   19255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19260: aload #5
    //   19262: sipush #892
    //   19265: new org/renjin/gcc/runtime/BytePtr
    //   19268: dup
    //   19269: ldc_w '#5E5E5E '
    //   19272: invokevirtual getBytes : ()[B
    //   19275: iconst_0
    //   19276: invokespecial <init> : ([BI)V
    //   19279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19284: aload #5
    //   19286: sipush #893
    //   19289: ldc_w -10592674
    //   19292: invokeinterface setAlignedInt : (II)V
    //   19297: aload #5
    //   19299: sipush #894
    //   19302: new org/renjin/gcc/runtime/BytePtr
    //   19305: dup
    //   19306: ldc_w 'grey38 '
    //   19309: invokevirtual getBytes : ()[B
    //   19312: iconst_0
    //   19313: invokespecial <init> : ([BI)V
    //   19316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19321: aload #5
    //   19323: sipush #895
    //   19326: new org/renjin/gcc/runtime/BytePtr
    //   19329: dup
    //   19330: ldc_w '#616161 '
    //   19333: invokevirtual getBytes : ()[B
    //   19336: iconst_0
    //   19337: invokespecial <init> : ([BI)V
    //   19340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19345: aload #5
    //   19347: sipush #896
    //   19350: ldc_w -10395295
    //   19353: invokeinterface setAlignedInt : (II)V
    //   19358: aload #5
    //   19360: sipush #897
    //   19363: new org/renjin/gcc/runtime/BytePtr
    //   19366: dup
    //   19367: ldc_w 'grey39 '
    //   19370: invokevirtual getBytes : ()[B
    //   19373: iconst_0
    //   19374: invokespecial <init> : ([BI)V
    //   19377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19382: aload #5
    //   19384: sipush #898
    //   19387: new org/renjin/gcc/runtime/BytePtr
    //   19390: dup
    //   19391: ldc_w '#636363 '
    //   19394: invokevirtual getBytes : ()[B
    //   19397: iconst_0
    //   19398: invokespecial <init> : ([BI)V
    //   19401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19406: aload #5
    //   19408: sipush #899
    //   19411: ldc_w -10263709
    //   19414: invokeinterface setAlignedInt : (II)V
    //   19419: aload #5
    //   19421: sipush #900
    //   19424: new org/renjin/gcc/runtime/BytePtr
    //   19427: dup
    //   19428: ldc_w 'grey40 '
    //   19431: invokevirtual getBytes : ()[B
    //   19434: iconst_0
    //   19435: invokespecial <init> : ([BI)V
    //   19438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19443: aload #5
    //   19445: sipush #901
    //   19448: new org/renjin/gcc/runtime/BytePtr
    //   19451: dup
    //   19452: ldc_w '#666666 '
    //   19455: invokevirtual getBytes : ()[B
    //   19458: iconst_0
    //   19459: invokespecial <init> : ([BI)V
    //   19462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19467: aload #5
    //   19469: sipush #902
    //   19472: ldc_w -10066330
    //   19475: invokeinterface setAlignedInt : (II)V
    //   19480: aload #5
    //   19482: sipush #903
    //   19485: new org/renjin/gcc/runtime/BytePtr
    //   19488: dup
    //   19489: ldc_w 'grey41 '
    //   19492: invokevirtual getBytes : ()[B
    //   19495: iconst_0
    //   19496: invokespecial <init> : ([BI)V
    //   19499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19504: aload #5
    //   19506: sipush #904
    //   19509: new org/renjin/gcc/runtime/BytePtr
    //   19512: dup
    //   19513: ldc_w '#696969 '
    //   19516: invokevirtual getBytes : ()[B
    //   19519: iconst_0
    //   19520: invokespecial <init> : ([BI)V
    //   19523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19528: aload #5
    //   19530: sipush #905
    //   19533: ldc_w -9868951
    //   19536: invokeinterface setAlignedInt : (II)V
    //   19541: aload #5
    //   19543: sipush #906
    //   19546: new org/renjin/gcc/runtime/BytePtr
    //   19549: dup
    //   19550: ldc_w 'grey42 '
    //   19553: invokevirtual getBytes : ()[B
    //   19556: iconst_0
    //   19557: invokespecial <init> : ([BI)V
    //   19560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19565: aload #5
    //   19567: sipush #907
    //   19570: new org/renjin/gcc/runtime/BytePtr
    //   19573: dup
    //   19574: ldc_w '#6B6B6B '
    //   19577: invokevirtual getBytes : ()[B
    //   19580: iconst_0
    //   19581: invokespecial <init> : ([BI)V
    //   19584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19589: aload #5
    //   19591: sipush #908
    //   19594: ldc_w -9737365
    //   19597: invokeinterface setAlignedInt : (II)V
    //   19602: aload #5
    //   19604: sipush #909
    //   19607: new org/renjin/gcc/runtime/BytePtr
    //   19610: dup
    //   19611: ldc_w 'grey43 '
    //   19614: invokevirtual getBytes : ()[B
    //   19617: iconst_0
    //   19618: invokespecial <init> : ([BI)V
    //   19621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19626: aload #5
    //   19628: sipush #910
    //   19631: new org/renjin/gcc/runtime/BytePtr
    //   19634: dup
    //   19635: ldc_w '#6E6E6E '
    //   19638: invokevirtual getBytes : ()[B
    //   19641: iconst_0
    //   19642: invokespecial <init> : ([BI)V
    //   19645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19650: aload #5
    //   19652: sipush #911
    //   19655: ldc_w -9539986
    //   19658: invokeinterface setAlignedInt : (II)V
    //   19663: aload #5
    //   19665: sipush #912
    //   19668: new org/renjin/gcc/runtime/BytePtr
    //   19671: dup
    //   19672: ldc_w 'grey44 '
    //   19675: invokevirtual getBytes : ()[B
    //   19678: iconst_0
    //   19679: invokespecial <init> : ([BI)V
    //   19682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19687: aload #5
    //   19689: sipush #913
    //   19692: new org/renjin/gcc/runtime/BytePtr
    //   19695: dup
    //   19696: ldc_w '#707070 '
    //   19699: invokevirtual getBytes : ()[B
    //   19702: iconst_0
    //   19703: invokespecial <init> : ([BI)V
    //   19706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19711: aload #5
    //   19713: sipush #914
    //   19716: ldc_w -9408400
    //   19719: invokeinterface setAlignedInt : (II)V
    //   19724: aload #5
    //   19726: sipush #915
    //   19729: new org/renjin/gcc/runtime/BytePtr
    //   19732: dup
    //   19733: ldc_w 'grey45 '
    //   19736: invokevirtual getBytes : ()[B
    //   19739: iconst_0
    //   19740: invokespecial <init> : ([BI)V
    //   19743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19748: aload #5
    //   19750: sipush #916
    //   19753: new org/renjin/gcc/runtime/BytePtr
    //   19756: dup
    //   19757: ldc_w '#737373 '
    //   19760: invokevirtual getBytes : ()[B
    //   19763: iconst_0
    //   19764: invokespecial <init> : ([BI)V
    //   19767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19772: aload #5
    //   19774: sipush #917
    //   19777: ldc_w -9211021
    //   19780: invokeinterface setAlignedInt : (II)V
    //   19785: aload #5
    //   19787: sipush #918
    //   19790: new org/renjin/gcc/runtime/BytePtr
    //   19793: dup
    //   19794: ldc_w 'grey46 '
    //   19797: invokevirtual getBytes : ()[B
    //   19800: iconst_0
    //   19801: invokespecial <init> : ([BI)V
    //   19804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19809: aload #5
    //   19811: sipush #919
    //   19814: new org/renjin/gcc/runtime/BytePtr
    //   19817: dup
    //   19818: ldc_w '#757575 '
    //   19821: invokevirtual getBytes : ()[B
    //   19824: iconst_0
    //   19825: invokespecial <init> : ([BI)V
    //   19828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19833: aload #5
    //   19835: sipush #920
    //   19838: ldc_w -9079435
    //   19841: invokeinterface setAlignedInt : (II)V
    //   19846: aload #5
    //   19848: sipush #921
    //   19851: new org/renjin/gcc/runtime/BytePtr
    //   19854: dup
    //   19855: ldc_w 'grey47 '
    //   19858: invokevirtual getBytes : ()[B
    //   19861: iconst_0
    //   19862: invokespecial <init> : ([BI)V
    //   19865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19870: aload #5
    //   19872: sipush #922
    //   19875: new org/renjin/gcc/runtime/BytePtr
    //   19878: dup
    //   19879: ldc_w '#787878 '
    //   19882: invokevirtual getBytes : ()[B
    //   19885: iconst_0
    //   19886: invokespecial <init> : ([BI)V
    //   19889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19894: aload #5
    //   19896: sipush #923
    //   19899: ldc_w -8882056
    //   19902: invokeinterface setAlignedInt : (II)V
    //   19907: aload #5
    //   19909: sipush #924
    //   19912: new org/renjin/gcc/runtime/BytePtr
    //   19915: dup
    //   19916: ldc_w 'grey48 '
    //   19919: invokevirtual getBytes : ()[B
    //   19922: iconst_0
    //   19923: invokespecial <init> : ([BI)V
    //   19926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19931: aload #5
    //   19933: sipush #925
    //   19936: new org/renjin/gcc/runtime/BytePtr
    //   19939: dup
    //   19940: ldc_w '#7A7A7A '
    //   19943: invokevirtual getBytes : ()[B
    //   19946: iconst_0
    //   19947: invokespecial <init> : ([BI)V
    //   19950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19955: aload #5
    //   19957: sipush #926
    //   19960: ldc_w -8750470
    //   19963: invokeinterface setAlignedInt : (II)V
    //   19968: aload #5
    //   19970: sipush #927
    //   19973: new org/renjin/gcc/runtime/BytePtr
    //   19976: dup
    //   19977: ldc_w 'grey49 '
    //   19980: invokevirtual getBytes : ()[B
    //   19983: iconst_0
    //   19984: invokespecial <init> : ([BI)V
    //   19987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   19992: aload #5
    //   19994: sipush #928
    //   19997: new org/renjin/gcc/runtime/BytePtr
    //   20000: dup
    //   20001: ldc_w '#7D7D7D '
    //   20004: invokevirtual getBytes : ()[B
    //   20007: iconst_0
    //   20008: invokespecial <init> : ([BI)V
    //   20011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20016: aload #5
    //   20018: sipush #929
    //   20021: ldc_w -8553091
    //   20024: invokeinterface setAlignedInt : (II)V
    //   20029: aload #5
    //   20031: sipush #930
    //   20034: new org/renjin/gcc/runtime/BytePtr
    //   20037: dup
    //   20038: ldc_w 'grey50 '
    //   20041: invokevirtual getBytes : ()[B
    //   20044: iconst_0
    //   20045: invokespecial <init> : ([BI)V
    //   20048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20053: aload #5
    //   20055: sipush #931
    //   20058: new org/renjin/gcc/runtime/BytePtr
    //   20061: dup
    //   20062: ldc_w '#7F7F7F '
    //   20065: invokevirtual getBytes : ()[B
    //   20068: iconst_0
    //   20069: invokespecial <init> : ([BI)V
    //   20072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20077: aload #5
    //   20079: sipush #932
    //   20082: ldc_w -8421505
    //   20085: invokeinterface setAlignedInt : (II)V
    //   20090: aload #5
    //   20092: sipush #933
    //   20095: new org/renjin/gcc/runtime/BytePtr
    //   20098: dup
    //   20099: ldc_w 'grey51 '
    //   20102: invokevirtual getBytes : ()[B
    //   20105: iconst_0
    //   20106: invokespecial <init> : ([BI)V
    //   20109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20114: aload #5
    //   20116: sipush #934
    //   20119: new org/renjin/gcc/runtime/BytePtr
    //   20122: dup
    //   20123: ldc_w '#828282 '
    //   20126: invokevirtual getBytes : ()[B
    //   20129: iconst_0
    //   20130: invokespecial <init> : ([BI)V
    //   20133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20138: aload #5
    //   20140: sipush #935
    //   20143: ldc_w -8224126
    //   20146: invokeinterface setAlignedInt : (II)V
    //   20151: aload #5
    //   20153: sipush #936
    //   20156: new org/renjin/gcc/runtime/BytePtr
    //   20159: dup
    //   20160: ldc_w 'grey52 '
    //   20163: invokevirtual getBytes : ()[B
    //   20166: iconst_0
    //   20167: invokespecial <init> : ([BI)V
    //   20170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20175: aload #5
    //   20177: sipush #937
    //   20180: new org/renjin/gcc/runtime/BytePtr
    //   20183: dup
    //   20184: ldc_w '#858585 '
    //   20187: invokevirtual getBytes : ()[B
    //   20190: iconst_0
    //   20191: invokespecial <init> : ([BI)V
    //   20194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20199: aload #5
    //   20201: sipush #938
    //   20204: ldc_w -8026747
    //   20207: invokeinterface setAlignedInt : (II)V
    //   20212: aload #5
    //   20214: sipush #939
    //   20217: new org/renjin/gcc/runtime/BytePtr
    //   20220: dup
    //   20221: ldc_w 'grey53 '
    //   20224: invokevirtual getBytes : ()[B
    //   20227: iconst_0
    //   20228: invokespecial <init> : ([BI)V
    //   20231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20236: aload #5
    //   20238: sipush #940
    //   20241: new org/renjin/gcc/runtime/BytePtr
    //   20244: dup
    //   20245: ldc_w '#878787 '
    //   20248: invokevirtual getBytes : ()[B
    //   20251: iconst_0
    //   20252: invokespecial <init> : ([BI)V
    //   20255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20260: aload #5
    //   20262: sipush #941
    //   20265: ldc_w -7895161
    //   20268: invokeinterface setAlignedInt : (II)V
    //   20273: aload #5
    //   20275: sipush #942
    //   20278: new org/renjin/gcc/runtime/BytePtr
    //   20281: dup
    //   20282: ldc_w 'grey54 '
    //   20285: invokevirtual getBytes : ()[B
    //   20288: iconst_0
    //   20289: invokespecial <init> : ([BI)V
    //   20292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20297: aload #5
    //   20299: sipush #943
    //   20302: new org/renjin/gcc/runtime/BytePtr
    //   20305: dup
    //   20306: ldc_w '#8A8A8A '
    //   20309: invokevirtual getBytes : ()[B
    //   20312: iconst_0
    //   20313: invokespecial <init> : ([BI)V
    //   20316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20321: aload #5
    //   20323: sipush #944
    //   20326: ldc_w -7697782
    //   20329: invokeinterface setAlignedInt : (II)V
    //   20334: aload #5
    //   20336: sipush #945
    //   20339: new org/renjin/gcc/runtime/BytePtr
    //   20342: dup
    //   20343: ldc_w 'grey55 '
    //   20346: invokevirtual getBytes : ()[B
    //   20349: iconst_0
    //   20350: invokespecial <init> : ([BI)V
    //   20353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20358: aload #5
    //   20360: sipush #946
    //   20363: new org/renjin/gcc/runtime/BytePtr
    //   20366: dup
    //   20367: ldc_w '#8C8C8C '
    //   20370: invokevirtual getBytes : ()[B
    //   20373: iconst_0
    //   20374: invokespecial <init> : ([BI)V
    //   20377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20382: aload #5
    //   20384: sipush #947
    //   20387: ldc_w -7566196
    //   20390: invokeinterface setAlignedInt : (II)V
    //   20395: aload #5
    //   20397: sipush #948
    //   20400: new org/renjin/gcc/runtime/BytePtr
    //   20403: dup
    //   20404: ldc_w 'grey56 '
    //   20407: invokevirtual getBytes : ()[B
    //   20410: iconst_0
    //   20411: invokespecial <init> : ([BI)V
    //   20414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20419: aload #5
    //   20421: sipush #949
    //   20424: new org/renjin/gcc/runtime/BytePtr
    //   20427: dup
    //   20428: ldc_w '#8F8F8F '
    //   20431: invokevirtual getBytes : ()[B
    //   20434: iconst_0
    //   20435: invokespecial <init> : ([BI)V
    //   20438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20443: aload #5
    //   20445: sipush #950
    //   20448: ldc_w -7368817
    //   20451: invokeinterface setAlignedInt : (II)V
    //   20456: aload #5
    //   20458: sipush #951
    //   20461: new org/renjin/gcc/runtime/BytePtr
    //   20464: dup
    //   20465: ldc_w 'grey57 '
    //   20468: invokevirtual getBytes : ()[B
    //   20471: iconst_0
    //   20472: invokespecial <init> : ([BI)V
    //   20475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20480: aload #5
    //   20482: sipush #952
    //   20485: new org/renjin/gcc/runtime/BytePtr
    //   20488: dup
    //   20489: ldc_w '#919191 '
    //   20492: invokevirtual getBytes : ()[B
    //   20495: iconst_0
    //   20496: invokespecial <init> : ([BI)V
    //   20499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20504: aload #5
    //   20506: sipush #953
    //   20509: ldc_w -7237231
    //   20512: invokeinterface setAlignedInt : (II)V
    //   20517: aload #5
    //   20519: sipush #954
    //   20522: new org/renjin/gcc/runtime/BytePtr
    //   20525: dup
    //   20526: ldc_w 'grey58 '
    //   20529: invokevirtual getBytes : ()[B
    //   20532: iconst_0
    //   20533: invokespecial <init> : ([BI)V
    //   20536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20541: aload #5
    //   20543: sipush #955
    //   20546: new org/renjin/gcc/runtime/BytePtr
    //   20549: dup
    //   20550: ldc_w '#949494 '
    //   20553: invokevirtual getBytes : ()[B
    //   20556: iconst_0
    //   20557: invokespecial <init> : ([BI)V
    //   20560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20565: aload #5
    //   20567: sipush #956
    //   20570: ldc_w -7039852
    //   20573: invokeinterface setAlignedInt : (II)V
    //   20578: aload #5
    //   20580: sipush #957
    //   20583: new org/renjin/gcc/runtime/BytePtr
    //   20586: dup
    //   20587: ldc_w 'grey59 '
    //   20590: invokevirtual getBytes : ()[B
    //   20593: iconst_0
    //   20594: invokespecial <init> : ([BI)V
    //   20597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20602: aload #5
    //   20604: sipush #958
    //   20607: new org/renjin/gcc/runtime/BytePtr
    //   20610: dup
    //   20611: ldc_w '#969696 '
    //   20614: invokevirtual getBytes : ()[B
    //   20617: iconst_0
    //   20618: invokespecial <init> : ([BI)V
    //   20621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20626: aload #5
    //   20628: sipush #959
    //   20631: ldc_w -6908266
    //   20634: invokeinterface setAlignedInt : (II)V
    //   20639: aload #5
    //   20641: sipush #960
    //   20644: new org/renjin/gcc/runtime/BytePtr
    //   20647: dup
    //   20648: ldc_w 'grey60 '
    //   20651: invokevirtual getBytes : ()[B
    //   20654: iconst_0
    //   20655: invokespecial <init> : ([BI)V
    //   20658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20663: aload #5
    //   20665: sipush #961
    //   20668: new org/renjin/gcc/runtime/BytePtr
    //   20671: dup
    //   20672: ldc_w '#999999 '
    //   20675: invokevirtual getBytes : ()[B
    //   20678: iconst_0
    //   20679: invokespecial <init> : ([BI)V
    //   20682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20687: aload #5
    //   20689: sipush #962
    //   20692: ldc_w -6710887
    //   20695: invokeinterface setAlignedInt : (II)V
    //   20700: aload #5
    //   20702: sipush #963
    //   20705: new org/renjin/gcc/runtime/BytePtr
    //   20708: dup
    //   20709: ldc_w 'grey61 '
    //   20712: invokevirtual getBytes : ()[B
    //   20715: iconst_0
    //   20716: invokespecial <init> : ([BI)V
    //   20719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20724: aload #5
    //   20726: sipush #964
    //   20729: new org/renjin/gcc/runtime/BytePtr
    //   20732: dup
    //   20733: ldc_w '#9C9C9C '
    //   20736: invokevirtual getBytes : ()[B
    //   20739: iconst_0
    //   20740: invokespecial <init> : ([BI)V
    //   20743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20748: aload #5
    //   20750: sipush #965
    //   20753: ldc_w -6513508
    //   20756: invokeinterface setAlignedInt : (II)V
    //   20761: aload #5
    //   20763: sipush #966
    //   20766: new org/renjin/gcc/runtime/BytePtr
    //   20769: dup
    //   20770: ldc_w 'grey62 '
    //   20773: invokevirtual getBytes : ()[B
    //   20776: iconst_0
    //   20777: invokespecial <init> : ([BI)V
    //   20780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20785: aload #5
    //   20787: sipush #967
    //   20790: new org/renjin/gcc/runtime/BytePtr
    //   20793: dup
    //   20794: ldc_w '#9E9E9E '
    //   20797: invokevirtual getBytes : ()[B
    //   20800: iconst_0
    //   20801: invokespecial <init> : ([BI)V
    //   20804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20809: aload #5
    //   20811: sipush #968
    //   20814: ldc_w -6381922
    //   20817: invokeinterface setAlignedInt : (II)V
    //   20822: aload #5
    //   20824: sipush #969
    //   20827: new org/renjin/gcc/runtime/BytePtr
    //   20830: dup
    //   20831: ldc_w 'grey63 '
    //   20834: invokevirtual getBytes : ()[B
    //   20837: iconst_0
    //   20838: invokespecial <init> : ([BI)V
    //   20841: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20846: aload #5
    //   20848: sipush #970
    //   20851: new org/renjin/gcc/runtime/BytePtr
    //   20854: dup
    //   20855: ldc_w '#A1A1A1 '
    //   20858: invokevirtual getBytes : ()[B
    //   20861: iconst_0
    //   20862: invokespecial <init> : ([BI)V
    //   20865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20870: aload #5
    //   20872: sipush #971
    //   20875: ldc_w -6184543
    //   20878: invokeinterface setAlignedInt : (II)V
    //   20883: aload #5
    //   20885: sipush #972
    //   20888: new org/renjin/gcc/runtime/BytePtr
    //   20891: dup
    //   20892: ldc_w 'grey64 '
    //   20895: invokevirtual getBytes : ()[B
    //   20898: iconst_0
    //   20899: invokespecial <init> : ([BI)V
    //   20902: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20907: aload #5
    //   20909: sipush #973
    //   20912: new org/renjin/gcc/runtime/BytePtr
    //   20915: dup
    //   20916: ldc_w '#A3A3A3 '
    //   20919: invokevirtual getBytes : ()[B
    //   20922: iconst_0
    //   20923: invokespecial <init> : ([BI)V
    //   20926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20931: aload #5
    //   20933: sipush #974
    //   20936: ldc_w -6052957
    //   20939: invokeinterface setAlignedInt : (II)V
    //   20944: aload #5
    //   20946: sipush #975
    //   20949: new org/renjin/gcc/runtime/BytePtr
    //   20952: dup
    //   20953: ldc_w 'grey65 '
    //   20956: invokevirtual getBytes : ()[B
    //   20959: iconst_0
    //   20960: invokespecial <init> : ([BI)V
    //   20963: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20968: aload #5
    //   20970: sipush #976
    //   20973: new org/renjin/gcc/runtime/BytePtr
    //   20976: dup
    //   20977: ldc_w '#A6A6A6 '
    //   20980: invokevirtual getBytes : ()[B
    //   20983: iconst_0
    //   20984: invokespecial <init> : ([BI)V
    //   20987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   20992: aload #5
    //   20994: sipush #977
    //   20997: ldc_w -5855578
    //   21000: invokeinterface setAlignedInt : (II)V
    //   21005: aload #5
    //   21007: sipush #978
    //   21010: new org/renjin/gcc/runtime/BytePtr
    //   21013: dup
    //   21014: ldc_w 'grey66 '
    //   21017: invokevirtual getBytes : ()[B
    //   21020: iconst_0
    //   21021: invokespecial <init> : ([BI)V
    //   21024: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21029: aload #5
    //   21031: sipush #979
    //   21034: new org/renjin/gcc/runtime/BytePtr
    //   21037: dup
    //   21038: ldc_w '#A8A8A8 '
    //   21041: invokevirtual getBytes : ()[B
    //   21044: iconst_0
    //   21045: invokespecial <init> : ([BI)V
    //   21048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21053: aload #5
    //   21055: sipush #980
    //   21058: ldc_w -5723992
    //   21061: invokeinterface setAlignedInt : (II)V
    //   21066: aload #5
    //   21068: sipush #981
    //   21071: new org/renjin/gcc/runtime/BytePtr
    //   21074: dup
    //   21075: ldc_w 'grey67 '
    //   21078: invokevirtual getBytes : ()[B
    //   21081: iconst_0
    //   21082: invokespecial <init> : ([BI)V
    //   21085: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21090: aload #5
    //   21092: sipush #982
    //   21095: new org/renjin/gcc/runtime/BytePtr
    //   21098: dup
    //   21099: ldc_w '#ABABAB '
    //   21102: invokevirtual getBytes : ()[B
    //   21105: iconst_0
    //   21106: invokespecial <init> : ([BI)V
    //   21109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21114: aload #5
    //   21116: sipush #983
    //   21119: ldc_w -5526613
    //   21122: invokeinterface setAlignedInt : (II)V
    //   21127: aload #5
    //   21129: sipush #984
    //   21132: new org/renjin/gcc/runtime/BytePtr
    //   21135: dup
    //   21136: ldc_w 'grey68 '
    //   21139: invokevirtual getBytes : ()[B
    //   21142: iconst_0
    //   21143: invokespecial <init> : ([BI)V
    //   21146: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21151: aload #5
    //   21153: sipush #985
    //   21156: new org/renjin/gcc/runtime/BytePtr
    //   21159: dup
    //   21160: ldc_w '#ADADAD '
    //   21163: invokevirtual getBytes : ()[B
    //   21166: iconst_0
    //   21167: invokespecial <init> : ([BI)V
    //   21170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21175: aload #5
    //   21177: sipush #986
    //   21180: ldc_w -5395027
    //   21183: invokeinterface setAlignedInt : (II)V
    //   21188: aload #5
    //   21190: sipush #987
    //   21193: new org/renjin/gcc/runtime/BytePtr
    //   21196: dup
    //   21197: ldc_w 'grey69 '
    //   21200: invokevirtual getBytes : ()[B
    //   21203: iconst_0
    //   21204: invokespecial <init> : ([BI)V
    //   21207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21212: aload #5
    //   21214: sipush #988
    //   21217: new org/renjin/gcc/runtime/BytePtr
    //   21220: dup
    //   21221: ldc_w '#B0B0B0 '
    //   21224: invokevirtual getBytes : ()[B
    //   21227: iconst_0
    //   21228: invokespecial <init> : ([BI)V
    //   21231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21236: aload #5
    //   21238: sipush #989
    //   21241: ldc_w -5197648
    //   21244: invokeinterface setAlignedInt : (II)V
    //   21249: aload #5
    //   21251: sipush #990
    //   21254: new org/renjin/gcc/runtime/BytePtr
    //   21257: dup
    //   21258: ldc_w 'grey70 '
    //   21261: invokevirtual getBytes : ()[B
    //   21264: iconst_0
    //   21265: invokespecial <init> : ([BI)V
    //   21268: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21273: aload #5
    //   21275: sipush #991
    //   21278: new org/renjin/gcc/runtime/BytePtr
    //   21281: dup
    //   21282: ldc_w '#B3B3B3 '
    //   21285: invokevirtual getBytes : ()[B
    //   21288: iconst_0
    //   21289: invokespecial <init> : ([BI)V
    //   21292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21297: aload #5
    //   21299: sipush #992
    //   21302: ldc_w -5000269
    //   21305: invokeinterface setAlignedInt : (II)V
    //   21310: aload #5
    //   21312: sipush #993
    //   21315: new org/renjin/gcc/runtime/BytePtr
    //   21318: dup
    //   21319: ldc_w 'grey71 '
    //   21322: invokevirtual getBytes : ()[B
    //   21325: iconst_0
    //   21326: invokespecial <init> : ([BI)V
    //   21329: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21334: aload #5
    //   21336: sipush #994
    //   21339: new org/renjin/gcc/runtime/BytePtr
    //   21342: dup
    //   21343: ldc_w '#B5B5B5 '
    //   21346: invokevirtual getBytes : ()[B
    //   21349: iconst_0
    //   21350: invokespecial <init> : ([BI)V
    //   21353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21358: aload #5
    //   21360: sipush #995
    //   21363: ldc_w -4868683
    //   21366: invokeinterface setAlignedInt : (II)V
    //   21371: aload #5
    //   21373: sipush #996
    //   21376: new org/renjin/gcc/runtime/BytePtr
    //   21379: dup
    //   21380: ldc_w 'grey72 '
    //   21383: invokevirtual getBytes : ()[B
    //   21386: iconst_0
    //   21387: invokespecial <init> : ([BI)V
    //   21390: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21395: aload #5
    //   21397: sipush #997
    //   21400: new org/renjin/gcc/runtime/BytePtr
    //   21403: dup
    //   21404: ldc_w '#B8B8B8 '
    //   21407: invokevirtual getBytes : ()[B
    //   21410: iconst_0
    //   21411: invokespecial <init> : ([BI)V
    //   21414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21419: aload #5
    //   21421: sipush #998
    //   21424: ldc_w -4671304
    //   21427: invokeinterface setAlignedInt : (II)V
    //   21432: aload #5
    //   21434: sipush #999
    //   21437: new org/renjin/gcc/runtime/BytePtr
    //   21440: dup
    //   21441: ldc_w 'grey73 '
    //   21444: invokevirtual getBytes : ()[B
    //   21447: iconst_0
    //   21448: invokespecial <init> : ([BI)V
    //   21451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21456: aload #5
    //   21458: sipush #1000
    //   21461: new org/renjin/gcc/runtime/BytePtr
    //   21464: dup
    //   21465: ldc_w '#BABABA '
    //   21468: invokevirtual getBytes : ()[B
    //   21471: iconst_0
    //   21472: invokespecial <init> : ([BI)V
    //   21475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21480: aload #5
    //   21482: sipush #1001
    //   21485: ldc_w -4539718
    //   21488: invokeinterface setAlignedInt : (II)V
    //   21493: aload #5
    //   21495: sipush #1002
    //   21498: new org/renjin/gcc/runtime/BytePtr
    //   21501: dup
    //   21502: ldc_w 'grey74 '
    //   21505: invokevirtual getBytes : ()[B
    //   21508: iconst_0
    //   21509: invokespecial <init> : ([BI)V
    //   21512: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21517: aload #5
    //   21519: sipush #1003
    //   21522: new org/renjin/gcc/runtime/BytePtr
    //   21525: dup
    //   21526: ldc_w '#BDBDBD '
    //   21529: invokevirtual getBytes : ()[B
    //   21532: iconst_0
    //   21533: invokespecial <init> : ([BI)V
    //   21536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21541: aload #5
    //   21543: sipush #1004
    //   21546: ldc_w -4342339
    //   21549: invokeinterface setAlignedInt : (II)V
    //   21554: aload #5
    //   21556: sipush #1005
    //   21559: new org/renjin/gcc/runtime/BytePtr
    //   21562: dup
    //   21563: ldc_w 'grey75 '
    //   21566: invokevirtual getBytes : ()[B
    //   21569: iconst_0
    //   21570: invokespecial <init> : ([BI)V
    //   21573: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21578: aload #5
    //   21580: sipush #1006
    //   21583: new org/renjin/gcc/runtime/BytePtr
    //   21586: dup
    //   21587: ldc_w '#BFBFBF '
    //   21590: invokevirtual getBytes : ()[B
    //   21593: iconst_0
    //   21594: invokespecial <init> : ([BI)V
    //   21597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21602: aload #5
    //   21604: sipush #1007
    //   21607: ldc_w -4210753
    //   21610: invokeinterface setAlignedInt : (II)V
    //   21615: aload #5
    //   21617: sipush #1008
    //   21620: new org/renjin/gcc/runtime/BytePtr
    //   21623: dup
    //   21624: ldc_w 'grey76 '
    //   21627: invokevirtual getBytes : ()[B
    //   21630: iconst_0
    //   21631: invokespecial <init> : ([BI)V
    //   21634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21639: aload #5
    //   21641: sipush #1009
    //   21644: new org/renjin/gcc/runtime/BytePtr
    //   21647: dup
    //   21648: ldc_w '#C2C2C2 '
    //   21651: invokevirtual getBytes : ()[B
    //   21654: iconst_0
    //   21655: invokespecial <init> : ([BI)V
    //   21658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21663: aload #5
    //   21665: sipush #1010
    //   21668: ldc_w -4013374
    //   21671: invokeinterface setAlignedInt : (II)V
    //   21676: aload #5
    //   21678: sipush #1011
    //   21681: new org/renjin/gcc/runtime/BytePtr
    //   21684: dup
    //   21685: ldc_w 'grey77 '
    //   21688: invokevirtual getBytes : ()[B
    //   21691: iconst_0
    //   21692: invokespecial <init> : ([BI)V
    //   21695: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21700: aload #5
    //   21702: sipush #1012
    //   21705: new org/renjin/gcc/runtime/BytePtr
    //   21708: dup
    //   21709: ldc_w '#C4C4C4 '
    //   21712: invokevirtual getBytes : ()[B
    //   21715: iconst_0
    //   21716: invokespecial <init> : ([BI)V
    //   21719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21724: aload #5
    //   21726: sipush #1013
    //   21729: ldc_w -3881788
    //   21732: invokeinterface setAlignedInt : (II)V
    //   21737: aload #5
    //   21739: sipush #1014
    //   21742: new org/renjin/gcc/runtime/BytePtr
    //   21745: dup
    //   21746: ldc_w 'grey78 '
    //   21749: invokevirtual getBytes : ()[B
    //   21752: iconst_0
    //   21753: invokespecial <init> : ([BI)V
    //   21756: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21761: aload #5
    //   21763: sipush #1015
    //   21766: new org/renjin/gcc/runtime/BytePtr
    //   21769: dup
    //   21770: ldc_w '#C7C7C7 '
    //   21773: invokevirtual getBytes : ()[B
    //   21776: iconst_0
    //   21777: invokespecial <init> : ([BI)V
    //   21780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21785: aload #5
    //   21787: sipush #1016
    //   21790: ldc_w -3684409
    //   21793: invokeinterface setAlignedInt : (II)V
    //   21798: aload #5
    //   21800: sipush #1017
    //   21803: new org/renjin/gcc/runtime/BytePtr
    //   21806: dup
    //   21807: ldc_w 'grey79 '
    //   21810: invokevirtual getBytes : ()[B
    //   21813: iconst_0
    //   21814: invokespecial <init> : ([BI)V
    //   21817: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21822: aload #5
    //   21824: sipush #1018
    //   21827: new org/renjin/gcc/runtime/BytePtr
    //   21830: dup
    //   21831: ldc_w '#C9C9C9 '
    //   21834: invokevirtual getBytes : ()[B
    //   21837: iconst_0
    //   21838: invokespecial <init> : ([BI)V
    //   21841: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21846: aload #5
    //   21848: sipush #1019
    //   21851: ldc_w -3552823
    //   21854: invokeinterface setAlignedInt : (II)V
    //   21859: aload #5
    //   21861: sipush #1020
    //   21864: new org/renjin/gcc/runtime/BytePtr
    //   21867: dup
    //   21868: ldc_w 'grey80 '
    //   21871: invokevirtual getBytes : ()[B
    //   21874: iconst_0
    //   21875: invokespecial <init> : ([BI)V
    //   21878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21883: aload #5
    //   21885: sipush #1021
    //   21888: new org/renjin/gcc/runtime/BytePtr
    //   21891: dup
    //   21892: ldc_w '#CCCCCC '
    //   21895: invokevirtual getBytes : ()[B
    //   21898: iconst_0
    //   21899: invokespecial <init> : ([BI)V
    //   21902: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21907: aload #5
    //   21909: sipush #1022
    //   21912: ldc_w -3355444
    //   21915: invokeinterface setAlignedInt : (II)V
    //   21920: aload #5
    //   21922: sipush #1023
    //   21925: new org/renjin/gcc/runtime/BytePtr
    //   21928: dup
    //   21929: ldc_w 'grey81 '
    //   21932: invokevirtual getBytes : ()[B
    //   21935: iconst_0
    //   21936: invokespecial <init> : ([BI)V
    //   21939: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21944: aload #5
    //   21946: sipush #1024
    //   21949: new org/renjin/gcc/runtime/BytePtr
    //   21952: dup
    //   21953: ldc_w '#CFCFCF '
    //   21956: invokevirtual getBytes : ()[B
    //   21959: iconst_0
    //   21960: invokespecial <init> : ([BI)V
    //   21963: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   21968: aload #5
    //   21970: sipush #1025
    //   21973: ldc_w -3158065
    //   21976: invokeinterface setAlignedInt : (II)V
    //   21981: aload #5
    //   21983: sipush #1026
    //   21986: new org/renjin/gcc/runtime/BytePtr
    //   21989: dup
    //   21990: ldc_w 'grey82 '
    //   21993: invokevirtual getBytes : ()[B
    //   21996: iconst_0
    //   21997: invokespecial <init> : ([BI)V
    //   22000: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22005: aload #5
    //   22007: sipush #1027
    //   22010: new org/renjin/gcc/runtime/BytePtr
    //   22013: dup
    //   22014: ldc_w '#D1D1D1 '
    //   22017: invokevirtual getBytes : ()[B
    //   22020: iconst_0
    //   22021: invokespecial <init> : ([BI)V
    //   22024: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22029: aload #5
    //   22031: sipush #1028
    //   22034: ldc_w -3026479
    //   22037: invokeinterface setAlignedInt : (II)V
    //   22042: aload #5
    //   22044: sipush #1029
    //   22047: new org/renjin/gcc/runtime/BytePtr
    //   22050: dup
    //   22051: ldc_w 'grey83 '
    //   22054: invokevirtual getBytes : ()[B
    //   22057: iconst_0
    //   22058: invokespecial <init> : ([BI)V
    //   22061: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22066: aload #5
    //   22068: sipush #1030
    //   22071: new org/renjin/gcc/runtime/BytePtr
    //   22074: dup
    //   22075: ldc_w '#D4D4D4 '
    //   22078: invokevirtual getBytes : ()[B
    //   22081: iconst_0
    //   22082: invokespecial <init> : ([BI)V
    //   22085: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22090: aload #5
    //   22092: sipush #1031
    //   22095: ldc_w -2829100
    //   22098: invokeinterface setAlignedInt : (II)V
    //   22103: aload #5
    //   22105: sipush #1032
    //   22108: new org/renjin/gcc/runtime/BytePtr
    //   22111: dup
    //   22112: ldc_w 'grey84 '
    //   22115: invokevirtual getBytes : ()[B
    //   22118: iconst_0
    //   22119: invokespecial <init> : ([BI)V
    //   22122: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22127: aload #5
    //   22129: sipush #1033
    //   22132: new org/renjin/gcc/runtime/BytePtr
    //   22135: dup
    //   22136: ldc_w '#D6D6D6 '
    //   22139: invokevirtual getBytes : ()[B
    //   22142: iconst_0
    //   22143: invokespecial <init> : ([BI)V
    //   22146: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22151: aload #5
    //   22153: sipush #1034
    //   22156: ldc_w -2697514
    //   22159: invokeinterface setAlignedInt : (II)V
    //   22164: aload #5
    //   22166: sipush #1035
    //   22169: new org/renjin/gcc/runtime/BytePtr
    //   22172: dup
    //   22173: ldc_w 'grey85 '
    //   22176: invokevirtual getBytes : ()[B
    //   22179: iconst_0
    //   22180: invokespecial <init> : ([BI)V
    //   22183: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22188: aload #5
    //   22190: sipush #1036
    //   22193: new org/renjin/gcc/runtime/BytePtr
    //   22196: dup
    //   22197: ldc_w '#D9D9D9 '
    //   22200: invokevirtual getBytes : ()[B
    //   22203: iconst_0
    //   22204: invokespecial <init> : ([BI)V
    //   22207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22212: aload #5
    //   22214: sipush #1037
    //   22217: ldc_w -2500135
    //   22220: invokeinterface setAlignedInt : (II)V
    //   22225: aload #5
    //   22227: sipush #1038
    //   22230: new org/renjin/gcc/runtime/BytePtr
    //   22233: dup
    //   22234: ldc_w 'grey86 '
    //   22237: invokevirtual getBytes : ()[B
    //   22240: iconst_0
    //   22241: invokespecial <init> : ([BI)V
    //   22244: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22249: aload #5
    //   22251: sipush #1039
    //   22254: new org/renjin/gcc/runtime/BytePtr
    //   22257: dup
    //   22258: ldc_w '#DBDBDB '
    //   22261: invokevirtual getBytes : ()[B
    //   22264: iconst_0
    //   22265: invokespecial <init> : ([BI)V
    //   22268: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22273: aload #5
    //   22275: sipush #1040
    //   22278: ldc_w -2368549
    //   22281: invokeinterface setAlignedInt : (II)V
    //   22286: aload #5
    //   22288: sipush #1041
    //   22291: new org/renjin/gcc/runtime/BytePtr
    //   22294: dup
    //   22295: ldc_w 'grey87 '
    //   22298: invokevirtual getBytes : ()[B
    //   22301: iconst_0
    //   22302: invokespecial <init> : ([BI)V
    //   22305: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22310: aload #5
    //   22312: sipush #1042
    //   22315: new org/renjin/gcc/runtime/BytePtr
    //   22318: dup
    //   22319: ldc_w '#DEDEDE '
    //   22322: invokevirtual getBytes : ()[B
    //   22325: iconst_0
    //   22326: invokespecial <init> : ([BI)V
    //   22329: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22334: aload #5
    //   22336: sipush #1043
    //   22339: ldc_w -2171170
    //   22342: invokeinterface setAlignedInt : (II)V
    //   22347: aload #5
    //   22349: sipush #1044
    //   22352: new org/renjin/gcc/runtime/BytePtr
    //   22355: dup
    //   22356: ldc_w 'grey88 '
    //   22359: invokevirtual getBytes : ()[B
    //   22362: iconst_0
    //   22363: invokespecial <init> : ([BI)V
    //   22366: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22371: aload #5
    //   22373: sipush #1045
    //   22376: new org/renjin/gcc/runtime/BytePtr
    //   22379: dup
    //   22380: ldc_w '#E0E0E0 '
    //   22383: invokevirtual getBytes : ()[B
    //   22386: iconst_0
    //   22387: invokespecial <init> : ([BI)V
    //   22390: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22395: aload #5
    //   22397: sipush #1046
    //   22400: ldc_w -2039584
    //   22403: invokeinterface setAlignedInt : (II)V
    //   22408: aload #5
    //   22410: sipush #1047
    //   22413: new org/renjin/gcc/runtime/BytePtr
    //   22416: dup
    //   22417: ldc_w 'grey89 '
    //   22420: invokevirtual getBytes : ()[B
    //   22423: iconst_0
    //   22424: invokespecial <init> : ([BI)V
    //   22427: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22432: aload #5
    //   22434: sipush #1048
    //   22437: new org/renjin/gcc/runtime/BytePtr
    //   22440: dup
    //   22441: ldc_w '#E3E3E3 '
    //   22444: invokevirtual getBytes : ()[B
    //   22447: iconst_0
    //   22448: invokespecial <init> : ([BI)V
    //   22451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22456: aload #5
    //   22458: sipush #1049
    //   22461: ldc_w -1842205
    //   22464: invokeinterface setAlignedInt : (II)V
    //   22469: aload #5
    //   22471: sipush #1050
    //   22474: new org/renjin/gcc/runtime/BytePtr
    //   22477: dup
    //   22478: ldc_w 'grey90 '
    //   22481: invokevirtual getBytes : ()[B
    //   22484: iconst_0
    //   22485: invokespecial <init> : ([BI)V
    //   22488: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22493: aload #5
    //   22495: sipush #1051
    //   22498: new org/renjin/gcc/runtime/BytePtr
    //   22501: dup
    //   22502: ldc_w '#E5E5E5 '
    //   22505: invokevirtual getBytes : ()[B
    //   22508: iconst_0
    //   22509: invokespecial <init> : ([BI)V
    //   22512: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22517: aload #5
    //   22519: sipush #1052
    //   22522: ldc_w -1710619
    //   22525: invokeinterface setAlignedInt : (II)V
    //   22530: aload #5
    //   22532: sipush #1053
    //   22535: new org/renjin/gcc/runtime/BytePtr
    //   22538: dup
    //   22539: ldc_w 'grey91 '
    //   22542: invokevirtual getBytes : ()[B
    //   22545: iconst_0
    //   22546: invokespecial <init> : ([BI)V
    //   22549: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22554: aload #5
    //   22556: sipush #1054
    //   22559: new org/renjin/gcc/runtime/BytePtr
    //   22562: dup
    //   22563: ldc_w '#E8E8E8 '
    //   22566: invokevirtual getBytes : ()[B
    //   22569: iconst_0
    //   22570: invokespecial <init> : ([BI)V
    //   22573: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22578: aload #5
    //   22580: sipush #1055
    //   22583: ldc_w -1513240
    //   22586: invokeinterface setAlignedInt : (II)V
    //   22591: aload #5
    //   22593: sipush #1056
    //   22596: new org/renjin/gcc/runtime/BytePtr
    //   22599: dup
    //   22600: ldc_w 'grey92 '
    //   22603: invokevirtual getBytes : ()[B
    //   22606: iconst_0
    //   22607: invokespecial <init> : ([BI)V
    //   22610: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22615: aload #5
    //   22617: sipush #1057
    //   22620: new org/renjin/gcc/runtime/BytePtr
    //   22623: dup
    //   22624: ldc_w '#EBEBEB '
    //   22627: invokevirtual getBytes : ()[B
    //   22630: iconst_0
    //   22631: invokespecial <init> : ([BI)V
    //   22634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22639: aload #5
    //   22641: sipush #1058
    //   22644: ldc_w -1315861
    //   22647: invokeinterface setAlignedInt : (II)V
    //   22652: aload #5
    //   22654: sipush #1059
    //   22657: new org/renjin/gcc/runtime/BytePtr
    //   22660: dup
    //   22661: ldc_w 'grey93 '
    //   22664: invokevirtual getBytes : ()[B
    //   22667: iconst_0
    //   22668: invokespecial <init> : ([BI)V
    //   22671: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22676: aload #5
    //   22678: sipush #1060
    //   22681: new org/renjin/gcc/runtime/BytePtr
    //   22684: dup
    //   22685: ldc_w '#EDEDED '
    //   22688: invokevirtual getBytes : ()[B
    //   22691: iconst_0
    //   22692: invokespecial <init> : ([BI)V
    //   22695: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22700: aload #5
    //   22702: sipush #1061
    //   22705: ldc_w -1184275
    //   22708: invokeinterface setAlignedInt : (II)V
    //   22713: aload #5
    //   22715: sipush #1062
    //   22718: new org/renjin/gcc/runtime/BytePtr
    //   22721: dup
    //   22722: ldc_w 'grey94 '
    //   22725: invokevirtual getBytes : ()[B
    //   22728: iconst_0
    //   22729: invokespecial <init> : ([BI)V
    //   22732: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22737: aload #5
    //   22739: sipush #1063
    //   22742: new org/renjin/gcc/runtime/BytePtr
    //   22745: dup
    //   22746: ldc_w '#F0F0F0 '
    //   22749: invokevirtual getBytes : ()[B
    //   22752: iconst_0
    //   22753: invokespecial <init> : ([BI)V
    //   22756: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22761: aload #5
    //   22763: sipush #1064
    //   22766: ldc_w -986896
    //   22769: invokeinterface setAlignedInt : (II)V
    //   22774: aload #5
    //   22776: sipush #1065
    //   22779: new org/renjin/gcc/runtime/BytePtr
    //   22782: dup
    //   22783: ldc_w 'grey95 '
    //   22786: invokevirtual getBytes : ()[B
    //   22789: iconst_0
    //   22790: invokespecial <init> : ([BI)V
    //   22793: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22798: aload #5
    //   22800: sipush #1066
    //   22803: new org/renjin/gcc/runtime/BytePtr
    //   22806: dup
    //   22807: ldc_w '#F2F2F2 '
    //   22810: invokevirtual getBytes : ()[B
    //   22813: iconst_0
    //   22814: invokespecial <init> : ([BI)V
    //   22817: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22822: aload #5
    //   22824: sipush #1067
    //   22827: ldc_w -855310
    //   22830: invokeinterface setAlignedInt : (II)V
    //   22835: aload #5
    //   22837: sipush #1068
    //   22840: new org/renjin/gcc/runtime/BytePtr
    //   22843: dup
    //   22844: ldc_w 'grey96 '
    //   22847: invokevirtual getBytes : ()[B
    //   22850: iconst_0
    //   22851: invokespecial <init> : ([BI)V
    //   22854: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22859: aload #5
    //   22861: sipush #1069
    //   22864: new org/renjin/gcc/runtime/BytePtr
    //   22867: dup
    //   22868: ldc_w '#F5F5F5 '
    //   22871: invokevirtual getBytes : ()[B
    //   22874: iconst_0
    //   22875: invokespecial <init> : ([BI)V
    //   22878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22883: aload #5
    //   22885: sipush #1070
    //   22888: ldc_w -657931
    //   22891: invokeinterface setAlignedInt : (II)V
    //   22896: aload #5
    //   22898: sipush #1071
    //   22901: new org/renjin/gcc/runtime/BytePtr
    //   22904: dup
    //   22905: ldc_w 'grey97 '
    //   22908: invokevirtual getBytes : ()[B
    //   22911: iconst_0
    //   22912: invokespecial <init> : ([BI)V
    //   22915: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22920: aload #5
    //   22922: sipush #1072
    //   22925: new org/renjin/gcc/runtime/BytePtr
    //   22928: dup
    //   22929: ldc_w '#F7F7F7 '
    //   22932: invokevirtual getBytes : ()[B
    //   22935: iconst_0
    //   22936: invokespecial <init> : ([BI)V
    //   22939: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22944: aload #5
    //   22946: sipush #1073
    //   22949: ldc_w -526345
    //   22952: invokeinterface setAlignedInt : (II)V
    //   22957: aload #5
    //   22959: sipush #1074
    //   22962: new org/renjin/gcc/runtime/BytePtr
    //   22965: dup
    //   22966: ldc_w 'grey98 '
    //   22969: invokevirtual getBytes : ()[B
    //   22972: iconst_0
    //   22973: invokespecial <init> : ([BI)V
    //   22976: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   22981: aload #5
    //   22983: sipush #1075
    //   22986: new org/renjin/gcc/runtime/BytePtr
    //   22989: dup
    //   22990: ldc_w '#FAFAFA '
    //   22993: invokevirtual getBytes : ()[B
    //   22996: iconst_0
    //   22997: invokespecial <init> : ([BI)V
    //   23000: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23005: aload #5
    //   23007: sipush #1076
    //   23010: ldc_w -328966
    //   23013: invokeinterface setAlignedInt : (II)V
    //   23018: aload #5
    //   23020: sipush #1077
    //   23023: new org/renjin/gcc/runtime/BytePtr
    //   23026: dup
    //   23027: ldc_w 'grey99 '
    //   23030: invokevirtual getBytes : ()[B
    //   23033: iconst_0
    //   23034: invokespecial <init> : ([BI)V
    //   23037: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23042: aload #5
    //   23044: sipush #1078
    //   23047: new org/renjin/gcc/runtime/BytePtr
    //   23050: dup
    //   23051: ldc_w '#FCFCFC '
    //   23054: invokevirtual getBytes : ()[B
    //   23057: iconst_0
    //   23058: invokespecial <init> : ([BI)V
    //   23061: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23066: aload #5
    //   23068: sipush #1079
    //   23071: ldc_w -197380
    //   23074: invokeinterface setAlignedInt : (II)V
    //   23079: aload #5
    //   23081: sipush #1080
    //   23084: new org/renjin/gcc/runtime/BytePtr
    //   23087: dup
    //   23088: ldc_w 'grey100 '
    //   23091: invokevirtual getBytes : ()[B
    //   23094: iconst_0
    //   23095: invokespecial <init> : ([BI)V
    //   23098: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23103: aload #5
    //   23105: sipush #1081
    //   23108: new org/renjin/gcc/runtime/BytePtr
    //   23111: dup
    //   23112: ldc_w '#FFFFFF '
    //   23115: invokevirtual getBytes : ()[B
    //   23118: iconst_0
    //   23119: invokespecial <init> : ([BI)V
    //   23122: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23127: aload #5
    //   23129: sipush #1082
    //   23132: iconst_m1
    //   23133: invokeinterface setAlignedInt : (II)V
    //   23138: aload #5
    //   23140: sipush #1083
    //   23143: new org/renjin/gcc/runtime/BytePtr
    //   23146: dup
    //   23147: ldc_w 'honeydew '
    //   23150: invokevirtual getBytes : ()[B
    //   23153: iconst_0
    //   23154: invokespecial <init> : ([BI)V
    //   23157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23162: aload #5
    //   23164: sipush #1084
    //   23167: new org/renjin/gcc/runtime/BytePtr
    //   23170: dup
    //   23171: ldc_w '#F0FFF0 '
    //   23174: invokevirtual getBytes : ()[B
    //   23177: iconst_0
    //   23178: invokespecial <init> : ([BI)V
    //   23181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23186: aload #5
    //   23188: sipush #1085
    //   23191: ldc_w -983056
    //   23194: invokeinterface setAlignedInt : (II)V
    //   23199: aload #5
    //   23201: sipush #1086
    //   23204: new org/renjin/gcc/runtime/BytePtr
    //   23207: dup
    //   23208: ldc_w 'honeydew1 '
    //   23211: invokevirtual getBytes : ()[B
    //   23214: iconst_0
    //   23215: invokespecial <init> : ([BI)V
    //   23218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23223: aload #5
    //   23225: sipush #1087
    //   23228: new org/renjin/gcc/runtime/BytePtr
    //   23231: dup
    //   23232: ldc_w '#F0FFF0 '
    //   23235: invokevirtual getBytes : ()[B
    //   23238: iconst_0
    //   23239: invokespecial <init> : ([BI)V
    //   23242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23247: aload #5
    //   23249: sipush #1088
    //   23252: ldc_w -983056
    //   23255: invokeinterface setAlignedInt : (II)V
    //   23260: aload #5
    //   23262: sipush #1089
    //   23265: new org/renjin/gcc/runtime/BytePtr
    //   23268: dup
    //   23269: ldc_w 'honeydew2 '
    //   23272: invokevirtual getBytes : ()[B
    //   23275: iconst_0
    //   23276: invokespecial <init> : ([BI)V
    //   23279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23284: aload #5
    //   23286: sipush #1090
    //   23289: new org/renjin/gcc/runtime/BytePtr
    //   23292: dup
    //   23293: ldc_w '#E0EEE0 '
    //   23296: invokevirtual getBytes : ()[B
    //   23299: iconst_0
    //   23300: invokespecial <init> : ([BI)V
    //   23303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23308: aload #5
    //   23310: sipush #1091
    //   23313: ldc_w -2036000
    //   23316: invokeinterface setAlignedInt : (II)V
    //   23321: aload #5
    //   23323: sipush #1092
    //   23326: new org/renjin/gcc/runtime/BytePtr
    //   23329: dup
    //   23330: ldc_w 'honeydew3 '
    //   23333: invokevirtual getBytes : ()[B
    //   23336: iconst_0
    //   23337: invokespecial <init> : ([BI)V
    //   23340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23345: aload #5
    //   23347: sipush #1093
    //   23350: new org/renjin/gcc/runtime/BytePtr
    //   23353: dup
    //   23354: ldc_w '#C1CDC1 '
    //   23357: invokevirtual getBytes : ()[B
    //   23360: iconst_0
    //   23361: invokespecial <init> : ([BI)V
    //   23364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23369: aload #5
    //   23371: sipush #1094
    //   23374: ldc_w -4076095
    //   23377: invokeinterface setAlignedInt : (II)V
    //   23382: aload #5
    //   23384: sipush #1095
    //   23387: new org/renjin/gcc/runtime/BytePtr
    //   23390: dup
    //   23391: ldc_w 'honeydew4 '
    //   23394: invokevirtual getBytes : ()[B
    //   23397: iconst_0
    //   23398: invokespecial <init> : ([BI)V
    //   23401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23406: aload #5
    //   23408: sipush #1096
    //   23411: new org/renjin/gcc/runtime/BytePtr
    //   23414: dup
    //   23415: ldc_w '#838B83 '
    //   23418: invokevirtual getBytes : ()[B
    //   23421: iconst_0
    //   23422: invokespecial <init> : ([BI)V
    //   23425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23430: aload #5
    //   23432: sipush #1097
    //   23435: ldc_w -8156285
    //   23438: invokeinterface setAlignedInt : (II)V
    //   23443: aload #5
    //   23445: sipush #1098
    //   23448: new org/renjin/gcc/runtime/BytePtr
    //   23451: dup
    //   23452: ldc_w 'hotpink '
    //   23455: invokevirtual getBytes : ()[B
    //   23458: iconst_0
    //   23459: invokespecial <init> : ([BI)V
    //   23462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23467: aload #5
    //   23469: sipush #1099
    //   23472: new org/renjin/gcc/runtime/BytePtr
    //   23475: dup
    //   23476: ldc_w '#FF69B4 '
    //   23479: invokevirtual getBytes : ()[B
    //   23482: iconst_0
    //   23483: invokespecial <init> : ([BI)V
    //   23486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23491: aload #5
    //   23493: sipush #1100
    //   23496: ldc_w -4953601
    //   23499: invokeinterface setAlignedInt : (II)V
    //   23504: aload #5
    //   23506: sipush #1101
    //   23509: new org/renjin/gcc/runtime/BytePtr
    //   23512: dup
    //   23513: ldc_w 'hotpink1 '
    //   23516: invokevirtual getBytes : ()[B
    //   23519: iconst_0
    //   23520: invokespecial <init> : ([BI)V
    //   23523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23528: aload #5
    //   23530: sipush #1102
    //   23533: new org/renjin/gcc/runtime/BytePtr
    //   23536: dup
    //   23537: ldc_w '#FF6EB4 '
    //   23540: invokevirtual getBytes : ()[B
    //   23543: iconst_0
    //   23544: invokespecial <init> : ([BI)V
    //   23547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23552: aload #5
    //   23554: sipush #1103
    //   23557: ldc_w -4952321
    //   23560: invokeinterface setAlignedInt : (II)V
    //   23565: aload #5
    //   23567: sipush #1104
    //   23570: new org/renjin/gcc/runtime/BytePtr
    //   23573: dup
    //   23574: ldc_w 'hotpink2 '
    //   23577: invokevirtual getBytes : ()[B
    //   23580: iconst_0
    //   23581: invokespecial <init> : ([BI)V
    //   23584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23589: aload #5
    //   23591: sipush #1105
    //   23594: new org/renjin/gcc/runtime/BytePtr
    //   23597: dup
    //   23598: ldc_w '#EE6AA7 '
    //   23601: invokevirtual getBytes : ()[B
    //   23604: iconst_0
    //   23605: invokespecial <init> : ([BI)V
    //   23608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23613: aload #5
    //   23615: sipush #1106
    //   23618: ldc_w -5805330
    //   23621: invokeinterface setAlignedInt : (II)V
    //   23626: aload #5
    //   23628: sipush #1107
    //   23631: new org/renjin/gcc/runtime/BytePtr
    //   23634: dup
    //   23635: ldc_w 'hotpink3 '
    //   23638: invokevirtual getBytes : ()[B
    //   23641: iconst_0
    //   23642: invokespecial <init> : ([BI)V
    //   23645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23650: aload #5
    //   23652: sipush #1108
    //   23655: new org/renjin/gcc/runtime/BytePtr
    //   23658: dup
    //   23659: ldc_w '#CD6090 '
    //   23662: invokevirtual getBytes : ()[B
    //   23665: iconst_0
    //   23666: invokespecial <init> : ([BI)V
    //   23669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23674: aload #5
    //   23676: sipush #1109
    //   23679: ldc_w -7315251
    //   23682: invokeinterface setAlignedInt : (II)V
    //   23687: aload #5
    //   23689: sipush #1110
    //   23692: new org/renjin/gcc/runtime/BytePtr
    //   23695: dup
    //   23696: ldc_w 'hotpink4 '
    //   23699: invokevirtual getBytes : ()[B
    //   23702: iconst_0
    //   23703: invokespecial <init> : ([BI)V
    //   23706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23711: aload #5
    //   23713: sipush #1111
    //   23716: new org/renjin/gcc/runtime/BytePtr
    //   23719: dup
    //   23720: ldc_w '#8B3A62 '
    //   23723: invokevirtual getBytes : ()[B
    //   23726: iconst_0
    //   23727: invokespecial <init> : ([BI)V
    //   23730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23735: aload #5
    //   23737: sipush #1112
    //   23740: ldc_w -10339701
    //   23743: invokeinterface setAlignedInt : (II)V
    //   23748: aload #5
    //   23750: sipush #1113
    //   23753: new org/renjin/gcc/runtime/BytePtr
    //   23756: dup
    //   23757: ldc_w 'indianred '
    //   23760: invokevirtual getBytes : ()[B
    //   23763: iconst_0
    //   23764: invokespecial <init> : ([BI)V
    //   23767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23772: aload #5
    //   23774: sipush #1114
    //   23777: new org/renjin/gcc/runtime/BytePtr
    //   23780: dup
    //   23781: ldc_w '#CD5C5C '
    //   23784: invokevirtual getBytes : ()[B
    //   23787: iconst_0
    //   23788: invokespecial <init> : ([BI)V
    //   23791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23796: aload #5
    //   23798: sipush #1115
    //   23801: ldc_w -10724147
    //   23804: invokeinterface setAlignedInt : (II)V
    //   23809: aload #5
    //   23811: sipush #1116
    //   23814: new org/renjin/gcc/runtime/BytePtr
    //   23817: dup
    //   23818: ldc_w 'indianred1 '
    //   23821: invokevirtual getBytes : ()[B
    //   23824: iconst_0
    //   23825: invokespecial <init> : ([BI)V
    //   23828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23833: aload #5
    //   23835: sipush #1117
    //   23838: new org/renjin/gcc/runtime/BytePtr
    //   23841: dup
    //   23842: ldc_w '#FF6A6A '
    //   23845: invokevirtual getBytes : ()[B
    //   23848: iconst_0
    //   23849: invokespecial <init> : ([BI)V
    //   23852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23857: aload #5
    //   23859: sipush #1118
    //   23862: ldc_w -9803009
    //   23865: invokeinterface setAlignedInt : (II)V
    //   23870: aload #5
    //   23872: sipush #1119
    //   23875: new org/renjin/gcc/runtime/BytePtr
    //   23878: dup
    //   23879: ldc_w 'indianred2 '
    //   23882: invokevirtual getBytes : ()[B
    //   23885: iconst_0
    //   23886: invokespecial <init> : ([BI)V
    //   23889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23894: aload #5
    //   23896: sipush #1120
    //   23899: new org/renjin/gcc/runtime/BytePtr
    //   23902: dup
    //   23903: ldc_w '#EE6363 '
    //   23906: invokevirtual getBytes : ()[B
    //   23909: iconst_0
    //   23910: invokespecial <init> : ([BI)V
    //   23913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23918: aload #5
    //   23920: sipush #1121
    //   23923: ldc_w -10263570
    //   23926: invokeinterface setAlignedInt : (II)V
    //   23931: aload #5
    //   23933: sipush #1122
    //   23936: new org/renjin/gcc/runtime/BytePtr
    //   23939: dup
    //   23940: ldc_w 'indianred3 '
    //   23943: invokevirtual getBytes : ()[B
    //   23946: iconst_0
    //   23947: invokespecial <init> : ([BI)V
    //   23950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23955: aload #5
    //   23957: sipush #1123
    //   23960: new org/renjin/gcc/runtime/BytePtr
    //   23963: dup
    //   23964: ldc_w '#CD5555 '
    //   23967: invokevirtual getBytes : ()[B
    //   23970: iconst_0
    //   23971: invokespecial <init> : ([BI)V
    //   23974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   23979: aload #5
    //   23981: sipush #1124
    //   23984: ldc_w -11184691
    //   23987: invokeinterface setAlignedInt : (II)V
    //   23992: aload #5
    //   23994: sipush #1125
    //   23997: new org/renjin/gcc/runtime/BytePtr
    //   24000: dup
    //   24001: ldc_w 'indianred4 '
    //   24004: invokevirtual getBytes : ()[B
    //   24007: iconst_0
    //   24008: invokespecial <init> : ([BI)V
    //   24011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24016: aload #5
    //   24018: sipush #1126
    //   24021: new org/renjin/gcc/runtime/BytePtr
    //   24024: dup
    //   24025: ldc_w '#8B3A3A '
    //   24028: invokevirtual getBytes : ()[B
    //   24031: iconst_0
    //   24032: invokespecial <init> : ([BI)V
    //   24035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24040: aload #5
    //   24042: sipush #1127
    //   24045: ldc_w -12961141
    //   24048: invokeinterface setAlignedInt : (II)V
    //   24053: aload #5
    //   24055: sipush #1128
    //   24058: new org/renjin/gcc/runtime/BytePtr
    //   24061: dup
    //   24062: ldc_w 'ivory '
    //   24065: invokevirtual getBytes : ()[B
    //   24068: iconst_0
    //   24069: invokespecial <init> : ([BI)V
    //   24072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24077: aload #5
    //   24079: sipush #1129
    //   24082: new org/renjin/gcc/runtime/BytePtr
    //   24085: dup
    //   24086: ldc_w '#FFFFF0 '
    //   24089: invokevirtual getBytes : ()[B
    //   24092: iconst_0
    //   24093: invokespecial <init> : ([BI)V
    //   24096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24101: aload #5
    //   24103: sipush #1130
    //   24106: ldc_w -983041
    //   24109: invokeinterface setAlignedInt : (II)V
    //   24114: aload #5
    //   24116: sipush #1131
    //   24119: new org/renjin/gcc/runtime/BytePtr
    //   24122: dup
    //   24123: ldc_w 'ivory1 '
    //   24126: invokevirtual getBytes : ()[B
    //   24129: iconst_0
    //   24130: invokespecial <init> : ([BI)V
    //   24133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24138: aload #5
    //   24140: sipush #1132
    //   24143: new org/renjin/gcc/runtime/BytePtr
    //   24146: dup
    //   24147: ldc_w '#FFFFF0 '
    //   24150: invokevirtual getBytes : ()[B
    //   24153: iconst_0
    //   24154: invokespecial <init> : ([BI)V
    //   24157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24162: aload #5
    //   24164: sipush #1133
    //   24167: ldc_w -983041
    //   24170: invokeinterface setAlignedInt : (II)V
    //   24175: aload #5
    //   24177: sipush #1134
    //   24180: new org/renjin/gcc/runtime/BytePtr
    //   24183: dup
    //   24184: ldc_w 'ivory2 '
    //   24187: invokevirtual getBytes : ()[B
    //   24190: iconst_0
    //   24191: invokespecial <init> : ([BI)V
    //   24194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24199: aload #5
    //   24201: sipush #1135
    //   24204: new org/renjin/gcc/runtime/BytePtr
    //   24207: dup
    //   24208: ldc_w '#EEEEE0 '
    //   24211: invokevirtual getBytes : ()[B
    //   24214: iconst_0
    //   24215: invokespecial <init> : ([BI)V
    //   24218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24223: aload #5
    //   24225: sipush #1136
    //   24228: ldc_w -2035986
    //   24231: invokeinterface setAlignedInt : (II)V
    //   24236: aload #5
    //   24238: sipush #1137
    //   24241: new org/renjin/gcc/runtime/BytePtr
    //   24244: dup
    //   24245: ldc_w 'ivory3 '
    //   24248: invokevirtual getBytes : ()[B
    //   24251: iconst_0
    //   24252: invokespecial <init> : ([BI)V
    //   24255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24260: aload #5
    //   24262: sipush #1138
    //   24265: new org/renjin/gcc/runtime/BytePtr
    //   24268: dup
    //   24269: ldc_w '#CDCDC1 '
    //   24272: invokevirtual getBytes : ()[B
    //   24275: iconst_0
    //   24276: invokespecial <init> : ([BI)V
    //   24279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24284: aload #5
    //   24286: sipush #1139
    //   24289: ldc_w -4076083
    //   24292: invokeinterface setAlignedInt : (II)V
    //   24297: aload #5
    //   24299: sipush #1140
    //   24302: new org/renjin/gcc/runtime/BytePtr
    //   24305: dup
    //   24306: ldc_w 'ivory4 '
    //   24309: invokevirtual getBytes : ()[B
    //   24312: iconst_0
    //   24313: invokespecial <init> : ([BI)V
    //   24316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24321: aload #5
    //   24323: sipush #1141
    //   24326: new org/renjin/gcc/runtime/BytePtr
    //   24329: dup
    //   24330: ldc_w '#8B8B83 '
    //   24333: invokevirtual getBytes : ()[B
    //   24336: iconst_0
    //   24337: invokespecial <init> : ([BI)V
    //   24340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24345: aload #5
    //   24347: sipush #1142
    //   24350: ldc_w -8156277
    //   24353: invokeinterface setAlignedInt : (II)V
    //   24358: aload #5
    //   24360: sipush #1143
    //   24363: new org/renjin/gcc/runtime/BytePtr
    //   24366: dup
    //   24367: ldc_w 'khaki '
    //   24370: invokevirtual getBytes : ()[B
    //   24373: iconst_0
    //   24374: invokespecial <init> : ([BI)V
    //   24377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24382: aload #5
    //   24384: sipush #1144
    //   24387: new org/renjin/gcc/runtime/BytePtr
    //   24390: dup
    //   24391: ldc_w '#F0E68C '
    //   24394: invokevirtual getBytes : ()[B
    //   24397: iconst_0
    //   24398: invokespecial <init> : ([BI)V
    //   24401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24406: aload #5
    //   24408: sipush #1145
    //   24411: ldc_w -7543056
    //   24414: invokeinterface setAlignedInt : (II)V
    //   24419: aload #5
    //   24421: sipush #1146
    //   24424: new org/renjin/gcc/runtime/BytePtr
    //   24427: dup
    //   24428: ldc_w 'khaki1 '
    //   24431: invokevirtual getBytes : ()[B
    //   24434: iconst_0
    //   24435: invokespecial <init> : ([BI)V
    //   24438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24443: aload #5
    //   24445: sipush #1147
    //   24448: new org/renjin/gcc/runtime/BytePtr
    //   24451: dup
    //   24452: ldc_w '#FFF68F '
    //   24455: invokevirtual getBytes : ()[B
    //   24458: iconst_0
    //   24459: invokespecial <init> : ([BI)V
    //   24462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24467: aload #5
    //   24469: sipush #1148
    //   24472: ldc_w -7342337
    //   24475: invokeinterface setAlignedInt : (II)V
    //   24480: aload #5
    //   24482: sipush #1149
    //   24485: new org/renjin/gcc/runtime/BytePtr
    //   24488: dup
    //   24489: ldc_w 'khaki2 '
    //   24492: invokevirtual getBytes : ()[B
    //   24495: iconst_0
    //   24496: invokespecial <init> : ([BI)V
    //   24499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24504: aload #5
    //   24506: sipush #1150
    //   24509: new org/renjin/gcc/runtime/BytePtr
    //   24512: dup
    //   24513: ldc_w '#EEE685 '
    //   24516: invokevirtual getBytes : ()[B
    //   24519: iconst_0
    //   24520: invokespecial <init> : ([BI)V
    //   24523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24528: aload #5
    //   24530: sipush #1151
    //   24533: ldc_w -8001810
    //   24536: invokeinterface setAlignedInt : (II)V
    //   24541: aload #5
    //   24543: sipush #1152
    //   24546: new org/renjin/gcc/runtime/BytePtr
    //   24549: dup
    //   24550: ldc_w 'khaki3 '
    //   24553: invokevirtual getBytes : ()[B
    //   24556: iconst_0
    //   24557: invokespecial <init> : ([BI)V
    //   24560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24565: aload #5
    //   24567: sipush #1153
    //   24570: new org/renjin/gcc/runtime/BytePtr
    //   24573: dup
    //   24574: ldc_w '#CDC673 '
    //   24577: invokevirtual getBytes : ()[B
    //   24580: iconst_0
    //   24581: invokespecial <init> : ([BI)V
    //   24584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24589: aload #5
    //   24591: sipush #1154
    //   24594: ldc_w -9189683
    //   24597: invokeinterface setAlignedInt : (II)V
    //   24602: aload #5
    //   24604: sipush #1155
    //   24607: new org/renjin/gcc/runtime/BytePtr
    //   24610: dup
    //   24611: ldc_w 'khaki4 '
    //   24614: invokevirtual getBytes : ()[B
    //   24617: iconst_0
    //   24618: invokespecial <init> : ([BI)V
    //   24621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24626: aload #5
    //   24628: sipush #1156
    //   24631: new org/renjin/gcc/runtime/BytePtr
    //   24634: dup
    //   24635: ldc_w '#8B864E '
    //   24638: invokevirtual getBytes : ()[B
    //   24641: iconst_0
    //   24642: invokespecial <init> : ([BI)V
    //   24645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24650: aload #5
    //   24652: sipush #1157
    //   24655: ldc_w -11630965
    //   24658: invokeinterface setAlignedInt : (II)V
    //   24663: aload #5
    //   24665: sipush #1158
    //   24668: new org/renjin/gcc/runtime/BytePtr
    //   24671: dup
    //   24672: ldc_w 'lavender '
    //   24675: invokevirtual getBytes : ()[B
    //   24678: iconst_0
    //   24679: invokespecial <init> : ([BI)V
    //   24682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24687: aload #5
    //   24689: sipush #1159
    //   24692: new org/renjin/gcc/runtime/BytePtr
    //   24695: dup
    //   24696: ldc_w '#E6E6FA '
    //   24699: invokevirtual getBytes : ()[B
    //   24702: iconst_0
    //   24703: invokespecial <init> : ([BI)V
    //   24706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24711: aload #5
    //   24713: sipush #1160
    //   24716: ldc_w -334106
    //   24719: invokeinterface setAlignedInt : (II)V
    //   24724: aload #5
    //   24726: sipush #1161
    //   24729: new org/renjin/gcc/runtime/BytePtr
    //   24732: dup
    //   24733: ldc_w 'lavenderblush '
    //   24736: invokevirtual getBytes : ()[B
    //   24739: iconst_0
    //   24740: invokespecial <init> : ([BI)V
    //   24743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24748: aload #5
    //   24750: sipush #1162
    //   24753: new org/renjin/gcc/runtime/BytePtr
    //   24756: dup
    //   24757: ldc_w '#FFF0F5 '
    //   24760: invokevirtual getBytes : ()[B
    //   24763: iconst_0
    //   24764: invokespecial <init> : ([BI)V
    //   24767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24772: aload #5
    //   24774: sipush #1163
    //   24777: ldc_w -659201
    //   24780: invokeinterface setAlignedInt : (II)V
    //   24785: aload #5
    //   24787: sipush #1164
    //   24790: new org/renjin/gcc/runtime/BytePtr
    //   24793: dup
    //   24794: ldc_w 'lavenderblush1 '
    //   24797: invokevirtual getBytes : ()[B
    //   24800: iconst_0
    //   24801: invokespecial <init> : ([BI)V
    //   24804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24809: aload #5
    //   24811: sipush #1165
    //   24814: new org/renjin/gcc/runtime/BytePtr
    //   24817: dup
    //   24818: ldc_w '#FFF0F5 '
    //   24821: invokevirtual getBytes : ()[B
    //   24824: iconst_0
    //   24825: invokespecial <init> : ([BI)V
    //   24828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24833: aload #5
    //   24835: sipush #1166
    //   24838: ldc_w -659201
    //   24841: invokeinterface setAlignedInt : (II)V
    //   24846: aload #5
    //   24848: sipush #1167
    //   24851: new org/renjin/gcc/runtime/BytePtr
    //   24854: dup
    //   24855: ldc_w 'lavenderblush2 '
    //   24858: invokevirtual getBytes : ()[B
    //   24861: iconst_0
    //   24862: invokespecial <init> : ([BI)V
    //   24865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24870: aload #5
    //   24872: sipush #1168
    //   24875: new org/renjin/gcc/runtime/BytePtr
    //   24878: dup
    //   24879: ldc_w '#EEE0E5 '
    //   24882: invokevirtual getBytes : ()[B
    //   24885: iconst_0
    //   24886: invokespecial <init> : ([BI)V
    //   24889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24894: aload #5
    //   24896: sipush #1169
    //   24899: ldc_w -1711890
    //   24902: invokeinterface setAlignedInt : (II)V
    //   24907: aload #5
    //   24909: sipush #1170
    //   24912: new org/renjin/gcc/runtime/BytePtr
    //   24915: dup
    //   24916: ldc_w 'lavenderblush3 '
    //   24919: invokevirtual getBytes : ()[B
    //   24922: iconst_0
    //   24923: invokespecial <init> : ([BI)V
    //   24926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24931: aload #5
    //   24933: sipush #1171
    //   24936: new org/renjin/gcc/runtime/BytePtr
    //   24939: dup
    //   24940: ldc_w '#CDC1C5 '
    //   24943: invokevirtual getBytes : ()[B
    //   24946: iconst_0
    //   24947: invokespecial <init> : ([BI)V
    //   24950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24955: aload #5
    //   24957: sipush #1172
    //   24960: ldc_w -3817011
    //   24963: invokeinterface setAlignedInt : (II)V
    //   24968: aload #5
    //   24970: sipush #1173
    //   24973: new org/renjin/gcc/runtime/BytePtr
    //   24976: dup
    //   24977: ldc_w 'lavenderblush4 '
    //   24980: invokevirtual getBytes : ()[B
    //   24983: iconst_0
    //   24984: invokespecial <init> : ([BI)V
    //   24987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   24992: aload #5
    //   24994: sipush #1174
    //   24997: new org/renjin/gcc/runtime/BytePtr
    //   25000: dup
    //   25001: ldc_w '#8B8386 '
    //   25004: invokevirtual getBytes : ()[B
    //   25007: iconst_0
    //   25008: invokespecial <init> : ([BI)V
    //   25011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25016: aload #5
    //   25018: sipush #1175
    //   25021: ldc_w -7961717
    //   25024: invokeinterface setAlignedInt : (II)V
    //   25029: aload #5
    //   25031: sipush #1176
    //   25034: new org/renjin/gcc/runtime/BytePtr
    //   25037: dup
    //   25038: ldc_w 'lawngreen '
    //   25041: invokevirtual getBytes : ()[B
    //   25044: iconst_0
    //   25045: invokespecial <init> : ([BI)V
    //   25048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25053: aload #5
    //   25055: sipush #1177
    //   25058: new org/renjin/gcc/runtime/BytePtr
    //   25061: dup
    //   25062: ldc_w '#7CFC00 '
    //   25065: invokevirtual getBytes : ()[B
    //   25068: iconst_0
    //   25069: invokespecial <init> : ([BI)V
    //   25072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25077: aload #5
    //   25079: sipush #1178
    //   25082: ldc_w -16712580
    //   25085: invokeinterface setAlignedInt : (II)V
    //   25090: aload #5
    //   25092: sipush #1179
    //   25095: new org/renjin/gcc/runtime/BytePtr
    //   25098: dup
    //   25099: ldc_w 'lemonchiffon '
    //   25102: invokevirtual getBytes : ()[B
    //   25105: iconst_0
    //   25106: invokespecial <init> : ([BI)V
    //   25109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25114: aload #5
    //   25116: sipush #1180
    //   25119: new org/renjin/gcc/runtime/BytePtr
    //   25122: dup
    //   25123: ldc_w '#FFFACD '
    //   25126: invokevirtual getBytes : ()[B
    //   25129: iconst_0
    //   25130: invokespecial <init> : ([BI)V
    //   25133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25138: aload #5
    //   25140: sipush #1181
    //   25143: ldc_w -3278081
    //   25146: invokeinterface setAlignedInt : (II)V
    //   25151: aload #5
    //   25153: sipush #1182
    //   25156: new org/renjin/gcc/runtime/BytePtr
    //   25159: dup
    //   25160: ldc_w 'lemonchiffon1 '
    //   25163: invokevirtual getBytes : ()[B
    //   25166: iconst_0
    //   25167: invokespecial <init> : ([BI)V
    //   25170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25175: aload #5
    //   25177: sipush #1183
    //   25180: new org/renjin/gcc/runtime/BytePtr
    //   25183: dup
    //   25184: ldc_w '#FFFACD '
    //   25187: invokevirtual getBytes : ()[B
    //   25190: iconst_0
    //   25191: invokespecial <init> : ([BI)V
    //   25194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25199: aload #5
    //   25201: sipush #1184
    //   25204: ldc_w -3278081
    //   25207: invokeinterface setAlignedInt : (II)V
    //   25212: aload #5
    //   25214: sipush #1185
    //   25217: new org/renjin/gcc/runtime/BytePtr
    //   25220: dup
    //   25221: ldc_w 'lemonchiffon2 '
    //   25224: invokevirtual getBytes : ()[B
    //   25227: iconst_0
    //   25228: invokespecial <init> : ([BI)V
    //   25231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25236: aload #5
    //   25238: sipush #1186
    //   25241: new org/renjin/gcc/runtime/BytePtr
    //   25244: dup
    //   25245: ldc_w '#EEE9BF '
    //   25248: invokevirtual getBytes : ()[B
    //   25251: iconst_0
    //   25252: invokespecial <init> : ([BI)V
    //   25255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25260: aload #5
    //   25262: sipush #1187
    //   25265: ldc_w -4199954
    //   25268: invokeinterface setAlignedInt : (II)V
    //   25273: aload #5
    //   25275: sipush #1188
    //   25278: new org/renjin/gcc/runtime/BytePtr
    //   25281: dup
    //   25282: ldc_w 'lemonchiffon3 '
    //   25285: invokevirtual getBytes : ()[B
    //   25288: iconst_0
    //   25289: invokespecial <init> : ([BI)V
    //   25292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25297: aload #5
    //   25299: sipush #1189
    //   25302: new org/renjin/gcc/runtime/BytePtr
    //   25305: dup
    //   25306: ldc_w '#CDC9A5 '
    //   25309: invokevirtual getBytes : ()[B
    //   25312: iconst_0
    //   25313: invokespecial <init> : ([BI)V
    //   25316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25321: aload #5
    //   25323: sipush #1190
    //   25326: ldc_w -5912115
    //   25329: invokeinterface setAlignedInt : (II)V
    //   25334: aload #5
    //   25336: sipush #1191
    //   25339: new org/renjin/gcc/runtime/BytePtr
    //   25342: dup
    //   25343: ldc_w 'lemonchiffon4 '
    //   25346: invokevirtual getBytes : ()[B
    //   25349: iconst_0
    //   25350: invokespecial <init> : ([BI)V
    //   25353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25358: aload #5
    //   25360: sipush #1192
    //   25363: new org/renjin/gcc/runtime/BytePtr
    //   25366: dup
    //   25367: ldc_w '#8B8970 '
    //   25370: invokevirtual getBytes : ()[B
    //   25373: iconst_0
    //   25374: invokespecial <init> : ([BI)V
    //   25377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25382: aload #5
    //   25384: sipush #1193
    //   25387: ldc_w -9401973
    //   25390: invokeinterface setAlignedInt : (II)V
    //   25395: aload #5
    //   25397: sipush #1194
    //   25400: new org/renjin/gcc/runtime/BytePtr
    //   25403: dup
    //   25404: ldc_w 'lightblue '
    //   25407: invokevirtual getBytes : ()[B
    //   25410: iconst_0
    //   25411: invokespecial <init> : ([BI)V
    //   25414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25419: aload #5
    //   25421: sipush #1195
    //   25424: new org/renjin/gcc/runtime/BytePtr
    //   25427: dup
    //   25428: ldc_w '#ADD8E6 '
    //   25431: invokevirtual getBytes : ()[B
    //   25434: iconst_0
    //   25435: invokespecial <init> : ([BI)V
    //   25438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25443: aload #5
    //   25445: sipush #1196
    //   25448: ldc_w -1648467
    //   25451: invokeinterface setAlignedInt : (II)V
    //   25456: aload #5
    //   25458: sipush #1197
    //   25461: new org/renjin/gcc/runtime/BytePtr
    //   25464: dup
    //   25465: ldc_w 'lightblue1 '
    //   25468: invokevirtual getBytes : ()[B
    //   25471: iconst_0
    //   25472: invokespecial <init> : ([BI)V
    //   25475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25480: aload #5
    //   25482: sipush #1198
    //   25485: new org/renjin/gcc/runtime/BytePtr
    //   25488: dup
    //   25489: ldc_w '#BFEFFF '
    //   25492: invokevirtual getBytes : ()[B
    //   25495: iconst_0
    //   25496: invokespecial <init> : ([BI)V
    //   25499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25504: aload #5
    //   25506: sipush #1199
    //   25509: sipush #-4161
    //   25512: invokeinterface setAlignedInt : (II)V
    //   25517: aload #5
    //   25519: sipush #1200
    //   25522: new org/renjin/gcc/runtime/BytePtr
    //   25525: dup
    //   25526: ldc_w 'lightblue2 '
    //   25529: invokevirtual getBytes : ()[B
    //   25532: iconst_0
    //   25533: invokespecial <init> : ([BI)V
    //   25536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25541: aload #5
    //   25543: sipush #1201
    //   25546: new org/renjin/gcc/runtime/BytePtr
    //   25549: dup
    //   25550: ldc_w '#B2DFEE '
    //   25553: invokevirtual getBytes : ()[B
    //   25556: iconst_0
    //   25557: invokespecial <init> : ([BI)V
    //   25560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25565: aload #5
    //   25567: sipush #1202
    //   25570: ldc_w -1122382
    //   25573: invokeinterface setAlignedInt : (II)V
    //   25578: aload #5
    //   25580: sipush #1203
    //   25583: new org/renjin/gcc/runtime/BytePtr
    //   25586: dup
    //   25587: ldc_w 'lightblue3 '
    //   25590: invokevirtual getBytes : ()[B
    //   25593: iconst_0
    //   25594: invokespecial <init> : ([BI)V
    //   25597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25602: aload #5
    //   25604: sipush #1204
    //   25607: new org/renjin/gcc/runtime/BytePtr
    //   25610: dup
    //   25611: ldc_w '#9AC0CD '
    //   25614: invokevirtual getBytes : ()[B
    //   25617: iconst_0
    //   25618: invokespecial <init> : ([BI)V
    //   25621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25626: aload #5
    //   25628: sipush #1205
    //   25631: ldc_w -3293030
    //   25634: invokeinterface setAlignedInt : (II)V
    //   25639: aload #5
    //   25641: sipush #1206
    //   25644: new org/renjin/gcc/runtime/BytePtr
    //   25647: dup
    //   25648: ldc_w 'lightblue4 '
    //   25651: invokevirtual getBytes : ()[B
    //   25654: iconst_0
    //   25655: invokespecial <init> : ([BI)V
    //   25658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25663: aload #5
    //   25665: sipush #1207
    //   25668: new org/renjin/gcc/runtime/BytePtr
    //   25671: dup
    //   25672: ldc_w '#68838B '
    //   25675: invokevirtual getBytes : ()[B
    //   25678: iconst_0
    //   25679: invokespecial <init> : ([BI)V
    //   25682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25687: aload #5
    //   25689: sipush #1208
    //   25692: ldc_w -7634072
    //   25695: invokeinterface setAlignedInt : (II)V
    //   25700: aload #5
    //   25702: sipush #1209
    //   25705: new org/renjin/gcc/runtime/BytePtr
    //   25708: dup
    //   25709: ldc_w 'lightcoral '
    //   25712: invokevirtual getBytes : ()[B
    //   25715: iconst_0
    //   25716: invokespecial <init> : ([BI)V
    //   25719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25724: aload #5
    //   25726: sipush #1210
    //   25729: new org/renjin/gcc/runtime/BytePtr
    //   25732: dup
    //   25733: ldc_w '#F08080 '
    //   25736: invokevirtual getBytes : ()[B
    //   25739: iconst_0
    //   25740: invokespecial <init> : ([BI)V
    //   25743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25748: aload #5
    //   25750: sipush #1211
    //   25753: ldc_w -8355600
    //   25756: invokeinterface setAlignedInt : (II)V
    //   25761: aload #5
    //   25763: sipush #1212
    //   25766: new org/renjin/gcc/runtime/BytePtr
    //   25769: dup
    //   25770: ldc_w 'lightcyan '
    //   25773: invokevirtual getBytes : ()[B
    //   25776: iconst_0
    //   25777: invokespecial <init> : ([BI)V
    //   25780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25785: aload #5
    //   25787: sipush #1213
    //   25790: new org/renjin/gcc/runtime/BytePtr
    //   25793: dup
    //   25794: ldc_w '#E0FFFF '
    //   25797: invokevirtual getBytes : ()[B
    //   25800: iconst_0
    //   25801: invokespecial <init> : ([BI)V
    //   25804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25809: aload #5
    //   25811: sipush #1214
    //   25814: bipush #-32
    //   25816: invokeinterface setAlignedInt : (II)V
    //   25821: aload #5
    //   25823: sipush #1215
    //   25826: new org/renjin/gcc/runtime/BytePtr
    //   25829: dup
    //   25830: ldc_w 'lightcyan1 '
    //   25833: invokevirtual getBytes : ()[B
    //   25836: iconst_0
    //   25837: invokespecial <init> : ([BI)V
    //   25840: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25845: aload #5
    //   25847: sipush #1216
    //   25850: new org/renjin/gcc/runtime/BytePtr
    //   25853: dup
    //   25854: ldc_w '#E0FFFF '
    //   25857: invokevirtual getBytes : ()[B
    //   25860: iconst_0
    //   25861: invokespecial <init> : ([BI)V
    //   25864: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25869: aload #5
    //   25871: sipush #1217
    //   25874: bipush #-32
    //   25876: invokeinterface setAlignedInt : (II)V
    //   25881: aload #5
    //   25883: sipush #1218
    //   25886: new org/renjin/gcc/runtime/BytePtr
    //   25889: dup
    //   25890: ldc_w 'lightcyan2 '
    //   25893: invokevirtual getBytes : ()[B
    //   25896: iconst_0
    //   25897: invokespecial <init> : ([BI)V
    //   25900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25905: aload #5
    //   25907: sipush #1219
    //   25910: new org/renjin/gcc/runtime/BytePtr
    //   25913: dup
    //   25914: ldc_w '#D1EEEE '
    //   25917: invokevirtual getBytes : ()[B
    //   25920: iconst_0
    //   25921: invokespecial <init> : ([BI)V
    //   25924: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25929: aload #5
    //   25931: sipush #1220
    //   25934: ldc_w -1118511
    //   25937: invokeinterface setAlignedInt : (II)V
    //   25942: aload #5
    //   25944: sipush #1221
    //   25947: new org/renjin/gcc/runtime/BytePtr
    //   25950: dup
    //   25951: ldc_w 'lightcyan3 '
    //   25954: invokevirtual getBytes : ()[B
    //   25957: iconst_0
    //   25958: invokespecial <init> : ([BI)V
    //   25961: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25966: aload #5
    //   25968: sipush #1222
    //   25971: new org/renjin/gcc/runtime/BytePtr
    //   25974: dup
    //   25975: ldc_w '#B4CDCD '
    //   25978: invokevirtual getBytes : ()[B
    //   25981: iconst_0
    //   25982: invokespecial <init> : ([BI)V
    //   25985: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   25990: aload #5
    //   25992: sipush #1223
    //   25995: ldc_w -3289676
    //   25998: invokeinterface setAlignedInt : (II)V
    //   26003: aload #5
    //   26005: sipush #1224
    //   26008: new org/renjin/gcc/runtime/BytePtr
    //   26011: dup
    //   26012: ldc_w 'lightcyan4 '
    //   26015: invokevirtual getBytes : ()[B
    //   26018: iconst_0
    //   26019: invokespecial <init> : ([BI)V
    //   26022: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26027: aload #5
    //   26029: sipush #1225
    //   26032: new org/renjin/gcc/runtime/BytePtr
    //   26035: dup
    //   26036: ldc_w '#7A8B8B '
    //   26039: invokevirtual getBytes : ()[B
    //   26042: iconst_0
    //   26043: invokespecial <init> : ([BI)V
    //   26046: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26051: aload #5
    //   26053: sipush #1226
    //   26056: ldc_w -7632006
    //   26059: invokeinterface setAlignedInt : (II)V
    //   26064: aload #5
    //   26066: sipush #1227
    //   26069: new org/renjin/gcc/runtime/BytePtr
    //   26072: dup
    //   26073: ldc_w 'lightgoldenrod '
    //   26076: invokevirtual getBytes : ()[B
    //   26079: iconst_0
    //   26080: invokespecial <init> : ([BI)V
    //   26083: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26088: aload #5
    //   26090: sipush #1228
    //   26093: new org/renjin/gcc/runtime/BytePtr
    //   26096: dup
    //   26097: ldc_w '#EEDD82 '
    //   26100: invokevirtual getBytes : ()[B
    //   26103: iconst_0
    //   26104: invokespecial <init> : ([BI)V
    //   26107: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26112: aload #5
    //   26114: sipush #1229
    //   26117: ldc_w -8200722
    //   26120: invokeinterface setAlignedInt : (II)V
    //   26125: aload #5
    //   26127: sipush #1230
    //   26130: new org/renjin/gcc/runtime/BytePtr
    //   26133: dup
    //   26134: ldc_w 'lightgoldenrod1 '
    //   26137: invokevirtual getBytes : ()[B
    //   26140: iconst_0
    //   26141: invokespecial <init> : ([BI)V
    //   26144: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26149: aload #5
    //   26151: sipush #1231
    //   26154: new org/renjin/gcc/runtime/BytePtr
    //   26157: dup
    //   26158: ldc_w '#FFEC8B '
    //   26161: invokevirtual getBytes : ()[B
    //   26164: iconst_0
    //   26165: invokespecial <init> : ([BI)V
    //   26168: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26173: aload #5
    //   26175: sipush #1232
    //   26178: ldc_w -7607041
    //   26181: invokeinterface setAlignedInt : (II)V
    //   26186: aload #5
    //   26188: sipush #1233
    //   26191: new org/renjin/gcc/runtime/BytePtr
    //   26194: dup
    //   26195: ldc_w 'lightgoldenrod2 '
    //   26198: invokevirtual getBytes : ()[B
    //   26201: iconst_0
    //   26202: invokespecial <init> : ([BI)V
    //   26205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26210: aload #5
    //   26212: sipush #1234
    //   26215: new org/renjin/gcc/runtime/BytePtr
    //   26218: dup
    //   26219: ldc_w '#EEDC82 '
    //   26222: invokevirtual getBytes : ()[B
    //   26225: iconst_0
    //   26226: invokespecial <init> : ([BI)V
    //   26229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26234: aload #5
    //   26236: sipush #1235
    //   26239: ldc_w -8200978
    //   26242: invokeinterface setAlignedInt : (II)V
    //   26247: aload #5
    //   26249: sipush #1236
    //   26252: new org/renjin/gcc/runtime/BytePtr
    //   26255: dup
    //   26256: ldc_w 'lightgoldenrod3 '
    //   26259: invokevirtual getBytes : ()[B
    //   26262: iconst_0
    //   26263: invokespecial <init> : ([BI)V
    //   26266: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26271: aload #5
    //   26273: sipush #1237
    //   26276: new org/renjin/gcc/runtime/BytePtr
    //   26279: dup
    //   26280: ldc_w '#CDBE70 '
    //   26283: invokevirtual getBytes : ()[B
    //   26286: iconst_0
    //   26287: invokespecial <init> : ([BI)V
    //   26290: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26295: aload #5
    //   26297: sipush #1238
    //   26300: ldc_w -9388339
    //   26303: invokeinterface setAlignedInt : (II)V
    //   26308: aload #5
    //   26310: sipush #1239
    //   26313: new org/renjin/gcc/runtime/BytePtr
    //   26316: dup
    //   26317: ldc_w 'lightgoldenrod4 '
    //   26320: invokevirtual getBytes : ()[B
    //   26323: iconst_0
    //   26324: invokespecial <init> : ([BI)V
    //   26327: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26332: aload #5
    //   26334: sipush #1240
    //   26337: new org/renjin/gcc/runtime/BytePtr
    //   26340: dup
    //   26341: ldc_w '#8B814C '
    //   26344: invokevirtual getBytes : ()[B
    //   26347: iconst_0
    //   26348: invokespecial <init> : ([BI)V
    //   26351: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26356: aload #5
    //   26358: sipush #1241
    //   26361: ldc_w -11763317
    //   26364: invokeinterface setAlignedInt : (II)V
    //   26369: aload #5
    //   26371: sipush #1242
    //   26374: new org/renjin/gcc/runtime/BytePtr
    //   26377: dup
    //   26378: ldc_w 'lightgoldenrodyellow '
    //   26381: invokevirtual getBytes : ()[B
    //   26384: iconst_0
    //   26385: invokespecial <init> : ([BI)V
    //   26388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26393: aload #5
    //   26395: sipush #1243
    //   26398: new org/renjin/gcc/runtime/BytePtr
    //   26401: dup
    //   26402: ldc_w '#FAFAD2 '
    //   26405: invokevirtual getBytes : ()[B
    //   26408: iconst_0
    //   26409: invokespecial <init> : ([BI)V
    //   26412: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26417: aload #5
    //   26419: sipush #1244
    //   26422: ldc_w -2950406
    //   26425: invokeinterface setAlignedInt : (II)V
    //   26430: aload #5
    //   26432: sipush #1245
    //   26435: new org/renjin/gcc/runtime/BytePtr
    //   26438: dup
    //   26439: ldc_w 'lightgray '
    //   26442: invokevirtual getBytes : ()[B
    //   26445: iconst_0
    //   26446: invokespecial <init> : ([BI)V
    //   26449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26454: aload #5
    //   26456: sipush #1246
    //   26459: new org/renjin/gcc/runtime/BytePtr
    //   26462: dup
    //   26463: ldc_w '#D3D3D3 '
    //   26466: invokevirtual getBytes : ()[B
    //   26469: iconst_0
    //   26470: invokespecial <init> : ([BI)V
    //   26473: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26478: aload #5
    //   26480: sipush #1247
    //   26483: ldc_w -2894893
    //   26486: invokeinterface setAlignedInt : (II)V
    //   26491: aload #5
    //   26493: sipush #1248
    //   26496: new org/renjin/gcc/runtime/BytePtr
    //   26499: dup
    //   26500: ldc_w 'lightgreen '
    //   26503: invokevirtual getBytes : ()[B
    //   26506: iconst_0
    //   26507: invokespecial <init> : ([BI)V
    //   26510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26515: aload #5
    //   26517: sipush #1249
    //   26520: new org/renjin/gcc/runtime/BytePtr
    //   26523: dup
    //   26524: ldc_w '#90EE90 '
    //   26527: invokevirtual getBytes : ()[B
    //   26530: iconst_0
    //   26531: invokespecial <init> : ([BI)V
    //   26534: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26539: aload #5
    //   26541: sipush #1250
    //   26544: ldc_w -7278960
    //   26547: invokeinterface setAlignedInt : (II)V
    //   26552: aload #5
    //   26554: sipush #1251
    //   26557: new org/renjin/gcc/runtime/BytePtr
    //   26560: dup
    //   26561: ldc_w 'lightgrey '
    //   26564: invokevirtual getBytes : ()[B
    //   26567: iconst_0
    //   26568: invokespecial <init> : ([BI)V
    //   26571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26576: aload #5
    //   26578: sipush #1252
    //   26581: new org/renjin/gcc/runtime/BytePtr
    //   26584: dup
    //   26585: ldc_w '#D3D3D3 '
    //   26588: invokevirtual getBytes : ()[B
    //   26591: iconst_0
    //   26592: invokespecial <init> : ([BI)V
    //   26595: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26600: aload #5
    //   26602: sipush #1253
    //   26605: ldc_w -2894893
    //   26608: invokeinterface setAlignedInt : (II)V
    //   26613: aload #5
    //   26615: sipush #1254
    //   26618: new org/renjin/gcc/runtime/BytePtr
    //   26621: dup
    //   26622: ldc_w 'lightpink '
    //   26625: invokevirtual getBytes : ()[B
    //   26628: iconst_0
    //   26629: invokespecial <init> : ([BI)V
    //   26632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26637: aload #5
    //   26639: sipush #1255
    //   26642: new org/renjin/gcc/runtime/BytePtr
    //   26645: dup
    //   26646: ldc_w '#FFB6C1 '
    //   26649: invokevirtual getBytes : ()[B
    //   26652: iconst_0
    //   26653: invokespecial <init> : ([BI)V
    //   26656: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26661: aload #5
    //   26663: sipush #1256
    //   26666: ldc_w -4081921
    //   26669: invokeinterface setAlignedInt : (II)V
    //   26674: aload #5
    //   26676: sipush #1257
    //   26679: new org/renjin/gcc/runtime/BytePtr
    //   26682: dup
    //   26683: ldc_w 'lightpink1 '
    //   26686: invokevirtual getBytes : ()[B
    //   26689: iconst_0
    //   26690: invokespecial <init> : ([BI)V
    //   26693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26698: aload #5
    //   26700: sipush #1258
    //   26703: new org/renjin/gcc/runtime/BytePtr
    //   26706: dup
    //   26707: ldc_w '#FFAEB9 '
    //   26710: invokevirtual getBytes : ()[B
    //   26713: iconst_0
    //   26714: invokespecial <init> : ([BI)V
    //   26717: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26722: aload #5
    //   26724: sipush #1259
    //   26727: ldc_w -4608257
    //   26730: invokeinterface setAlignedInt : (II)V
    //   26735: aload #5
    //   26737: sipush #1260
    //   26740: new org/renjin/gcc/runtime/BytePtr
    //   26743: dup
    //   26744: ldc_w 'lightpink2 '
    //   26747: invokevirtual getBytes : ()[B
    //   26750: iconst_0
    //   26751: invokespecial <init> : ([BI)V
    //   26754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26759: aload #5
    //   26761: sipush #1261
    //   26764: new org/renjin/gcc/runtime/BytePtr
    //   26767: dup
    //   26768: ldc_w '#EEA2AD '
    //   26771: invokevirtual getBytes : ()[B
    //   26774: iconst_0
    //   26775: invokespecial <init> : ([BI)V
    //   26778: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26783: aload #5
    //   26785: sipush #1262
    //   26788: ldc_w -5397778
    //   26791: invokeinterface setAlignedInt : (II)V
    //   26796: aload #5
    //   26798: sipush #1263
    //   26801: new org/renjin/gcc/runtime/BytePtr
    //   26804: dup
    //   26805: ldc_w 'lightpink3 '
    //   26808: invokevirtual getBytes : ()[B
    //   26811: iconst_0
    //   26812: invokespecial <init> : ([BI)V
    //   26815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26820: aload #5
    //   26822: sipush #1264
    //   26825: new org/renjin/gcc/runtime/BytePtr
    //   26828: dup
    //   26829: ldc_w '#CD8C95 '
    //   26832: invokevirtual getBytes : ()[B
    //   26835: iconst_0
    //   26836: invokespecial <init> : ([BI)V
    //   26839: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26844: aload #5
    //   26846: sipush #1265
    //   26849: ldc_w -6976307
    //   26852: invokeinterface setAlignedInt : (II)V
    //   26857: aload #5
    //   26859: sipush #1266
    //   26862: new org/renjin/gcc/runtime/BytePtr
    //   26865: dup
    //   26866: ldc_w 'lightpink4 '
    //   26869: invokevirtual getBytes : ()[B
    //   26872: iconst_0
    //   26873: invokespecial <init> : ([BI)V
    //   26876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26881: aload #5
    //   26883: sipush #1267
    //   26886: new org/renjin/gcc/runtime/BytePtr
    //   26889: dup
    //   26890: ldc_w '#8B5F65 '
    //   26893: invokevirtual getBytes : ()[B
    //   26896: iconst_0
    //   26897: invokespecial <init> : ([BI)V
    //   26900: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26905: aload #5
    //   26907: sipush #1268
    //   26910: ldc_w -10133621
    //   26913: invokeinterface setAlignedInt : (II)V
    //   26918: aload #5
    //   26920: sipush #1269
    //   26923: new org/renjin/gcc/runtime/BytePtr
    //   26926: dup
    //   26927: ldc_w 'lightsalmon '
    //   26930: invokevirtual getBytes : ()[B
    //   26933: iconst_0
    //   26934: invokespecial <init> : ([BI)V
    //   26937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26942: aload #5
    //   26944: sipush #1270
    //   26947: new org/renjin/gcc/runtime/BytePtr
    //   26950: dup
    //   26951: ldc_w '#FFA07A '
    //   26954: invokevirtual getBytes : ()[B
    //   26957: iconst_0
    //   26958: invokespecial <init> : ([BI)V
    //   26961: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   26966: aload #5
    //   26968: sipush #1271
    //   26971: ldc_w -8740609
    //   26974: invokeinterface setAlignedInt : (II)V
    //   26979: aload #5
    //   26981: sipush #1272
    //   26984: new org/renjin/gcc/runtime/BytePtr
    //   26987: dup
    //   26988: ldc_w 'lightsalmon1 '
    //   26991: invokevirtual getBytes : ()[B
    //   26994: iconst_0
    //   26995: invokespecial <init> : ([BI)V
    //   26998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27003: aload #5
    //   27005: sipush #1273
    //   27008: new org/renjin/gcc/runtime/BytePtr
    //   27011: dup
    //   27012: ldc_w '#FFA07A '
    //   27015: invokevirtual getBytes : ()[B
    //   27018: iconst_0
    //   27019: invokespecial <init> : ([BI)V
    //   27022: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27027: aload #5
    //   27029: sipush #1274
    //   27032: ldc_w -8740609
    //   27035: invokeinterface setAlignedInt : (II)V
    //   27040: aload #5
    //   27042: sipush #1275
    //   27045: new org/renjin/gcc/runtime/BytePtr
    //   27048: dup
    //   27049: ldc_w 'lightsalmon2 '
    //   27052: invokevirtual getBytes : ()[B
    //   27055: iconst_0
    //   27056: invokespecial <init> : ([BI)V
    //   27059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27064: aload #5
    //   27066: sipush #1276
    //   27069: new org/renjin/gcc/runtime/BytePtr
    //   27072: dup
    //   27073: ldc_w '#EE9572 '
    //   27076: invokevirtual getBytes : ()[B
    //   27079: iconst_0
    //   27080: invokespecial <init> : ([BI)V
    //   27083: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27088: aload #5
    //   27090: sipush #1277
    //   27093: ldc_w -9267730
    //   27096: invokeinterface setAlignedInt : (II)V
    //   27101: aload #5
    //   27103: sipush #1278
    //   27106: new org/renjin/gcc/runtime/BytePtr
    //   27109: dup
    //   27110: ldc_w 'lightsalmon3 '
    //   27113: invokevirtual getBytes : ()[B
    //   27116: iconst_0
    //   27117: invokespecial <init> : ([BI)V
    //   27120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27125: aload #5
    //   27127: sipush #1279
    //   27130: new org/renjin/gcc/runtime/BytePtr
    //   27133: dup
    //   27134: ldc_w '#CD8162 '
    //   27137: invokevirtual getBytes : ()[B
    //   27140: iconst_0
    //   27141: invokespecial <init> : ([BI)V
    //   27144: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27149: aload #5
    //   27151: sipush #1280
    //   27154: ldc_w -10321459
    //   27157: invokeinterface setAlignedInt : (II)V
    //   27162: aload #5
    //   27164: sipush #1281
    //   27167: new org/renjin/gcc/runtime/BytePtr
    //   27170: dup
    //   27171: ldc_w 'lightsalmon4 '
    //   27174: invokevirtual getBytes : ()[B
    //   27177: iconst_0
    //   27178: invokespecial <init> : ([BI)V
    //   27181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27186: aload #5
    //   27188: sipush #1282
    //   27191: new org/renjin/gcc/runtime/BytePtr
    //   27194: dup
    //   27195: ldc_w '#8B5742 '
    //   27198: invokevirtual getBytes : ()[B
    //   27201: iconst_0
    //   27202: invokespecial <init> : ([BI)V
    //   27205: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27210: aload #5
    //   27212: sipush #1283
    //   27215: ldc_w -12429429
    //   27218: invokeinterface setAlignedInt : (II)V
    //   27223: aload #5
    //   27225: sipush #1284
    //   27228: new org/renjin/gcc/runtime/BytePtr
    //   27231: dup
    //   27232: ldc_w 'lightseagreen '
    //   27235: invokevirtual getBytes : ()[B
    //   27238: iconst_0
    //   27239: invokespecial <init> : ([BI)V
    //   27242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27247: aload #5
    //   27249: sipush #1285
    //   27252: new org/renjin/gcc/runtime/BytePtr
    //   27255: dup
    //   27256: ldc_w '#20B2AA '
    //   27259: invokevirtual getBytes : ()[B
    //   27262: iconst_0
    //   27263: invokespecial <init> : ([BI)V
    //   27266: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27271: aload #5
    //   27273: sipush #1286
    //   27276: ldc_w -5590496
    //   27279: invokeinterface setAlignedInt : (II)V
    //   27284: aload #5
    //   27286: sipush #1287
    //   27289: new org/renjin/gcc/runtime/BytePtr
    //   27292: dup
    //   27293: ldc_w 'lightskyblue '
    //   27296: invokevirtual getBytes : ()[B
    //   27299: iconst_0
    //   27300: invokespecial <init> : ([BI)V
    //   27303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27308: aload #5
    //   27310: sipush #1288
    //   27313: new org/renjin/gcc/runtime/BytePtr
    //   27316: dup
    //   27317: ldc_w '#87CEFA '
    //   27320: invokevirtual getBytes : ()[B
    //   27323: iconst_0
    //   27324: invokespecial <init> : ([BI)V
    //   27327: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27332: aload #5
    //   27334: sipush #1289
    //   27337: ldc_w -340345
    //   27340: invokeinterface setAlignedInt : (II)V
    //   27345: aload #5
    //   27347: sipush #1290
    //   27350: new org/renjin/gcc/runtime/BytePtr
    //   27353: dup
    //   27354: ldc_w 'lightskyblue1 '
    //   27357: invokevirtual getBytes : ()[B
    //   27360: iconst_0
    //   27361: invokespecial <init> : ([BI)V
    //   27364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27369: aload #5
    //   27371: sipush #1291
    //   27374: new org/renjin/gcc/runtime/BytePtr
    //   27377: dup
    //   27378: ldc_w '#B0E2FF '
    //   27381: invokevirtual getBytes : ()[B
    //   27384: iconst_0
    //   27385: invokespecial <init> : ([BI)V
    //   27388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27393: aload #5
    //   27395: sipush #1292
    //   27398: sipush #-7504
    //   27401: invokeinterface setAlignedInt : (II)V
    //   27406: aload #5
    //   27408: sipush #1293
    //   27411: new org/renjin/gcc/runtime/BytePtr
    //   27414: dup
    //   27415: ldc_w 'lightskyblue2 '
    //   27418: invokevirtual getBytes : ()[B
    //   27421: iconst_0
    //   27422: invokespecial <init> : ([BI)V
    //   27425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27430: aload #5
    //   27432: sipush #1294
    //   27435: new org/renjin/gcc/runtime/BytePtr
    //   27438: dup
    //   27439: ldc_w '#A4D3EE '
    //   27442: invokevirtual getBytes : ()[B
    //   27445: iconst_0
    //   27446: invokespecial <init> : ([BI)V
    //   27449: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27454: aload #5
    //   27456: sipush #1295
    //   27459: ldc_w -1125468
    //   27462: invokeinterface setAlignedInt : (II)V
    //   27467: aload #5
    //   27469: sipush #1296
    //   27472: new org/renjin/gcc/runtime/BytePtr
    //   27475: dup
    //   27476: ldc_w 'lightskyblue3 '
    //   27479: invokevirtual getBytes : ()[B
    //   27482: iconst_0
    //   27483: invokespecial <init> : ([BI)V
    //   27486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27491: aload #5
    //   27493: sipush #1297
    //   27496: new org/renjin/gcc/runtime/BytePtr
    //   27499: dup
    //   27500: ldc_w '#8DB6CD '
    //   27503: invokevirtual getBytes : ()[B
    //   27506: iconst_0
    //   27507: invokespecial <init> : ([BI)V
    //   27510: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27515: aload #5
    //   27517: sipush #1298
    //   27520: ldc_w -3295603
    //   27523: invokeinterface setAlignedInt : (II)V
    //   27528: aload #5
    //   27530: sipush #1299
    //   27533: new org/renjin/gcc/runtime/BytePtr
    //   27536: dup
    //   27537: ldc_w 'lightskyblue4 '
    //   27540: invokevirtual getBytes : ()[B
    //   27543: iconst_0
    //   27544: invokespecial <init> : ([BI)V
    //   27547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27552: aload #5
    //   27554: sipush #1300
    //   27557: new org/renjin/gcc/runtime/BytePtr
    //   27560: dup
    //   27561: ldc_w '#607B8B '
    //   27564: invokevirtual getBytes : ()[B
    //   27567: iconst_0
    //   27568: invokespecial <init> : ([BI)V
    //   27571: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27576: aload #5
    //   27578: sipush #1301
    //   27581: ldc_w -7636128
    //   27584: invokeinterface setAlignedInt : (II)V
    //   27589: aload #5
    //   27591: sipush #1302
    //   27594: new org/renjin/gcc/runtime/BytePtr
    //   27597: dup
    //   27598: ldc_w 'lightslateblue '
    //   27601: invokevirtual getBytes : ()[B
    //   27604: iconst_0
    //   27605: invokespecial <init> : ([BI)V
    //   27608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27613: aload #5
    //   27615: sipush #1303
    //   27618: new org/renjin/gcc/runtime/BytePtr
    //   27621: dup
    //   27622: ldc_w '#8470FF '
    //   27625: invokevirtual getBytes : ()[B
    //   27628: iconst_0
    //   27629: invokespecial <init> : ([BI)V
    //   27632: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27637: aload #5
    //   27639: sipush #1304
    //   27642: ldc_w -36732
    //   27645: invokeinterface setAlignedInt : (II)V
    //   27650: aload #5
    //   27652: sipush #1305
    //   27655: new org/renjin/gcc/runtime/BytePtr
    //   27658: dup
    //   27659: ldc_w 'lightslategray '
    //   27662: invokevirtual getBytes : ()[B
    //   27665: iconst_0
    //   27666: invokespecial <init> : ([BI)V
    //   27669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27674: aload #5
    //   27676: sipush #1306
    //   27679: new org/renjin/gcc/runtime/BytePtr
    //   27682: dup
    //   27683: ldc_w '#778899 '
    //   27686: invokevirtual getBytes : ()[B
    //   27689: iconst_0
    //   27690: invokespecial <init> : ([BI)V
    //   27693: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27698: aload #5
    //   27700: sipush #1307
    //   27703: ldc_w -6715273
    //   27706: invokeinterface setAlignedInt : (II)V
    //   27711: aload #5
    //   27713: sipush #1308
    //   27716: new org/renjin/gcc/runtime/BytePtr
    //   27719: dup
    //   27720: ldc_w 'lightslategrey '
    //   27723: invokevirtual getBytes : ()[B
    //   27726: iconst_0
    //   27727: invokespecial <init> : ([BI)V
    //   27730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27735: aload #5
    //   27737: sipush #1309
    //   27740: new org/renjin/gcc/runtime/BytePtr
    //   27743: dup
    //   27744: ldc_w '#778899 '
    //   27747: invokevirtual getBytes : ()[B
    //   27750: iconst_0
    //   27751: invokespecial <init> : ([BI)V
    //   27754: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27759: aload #5
    //   27761: sipush #1310
    //   27764: ldc_w -6715273
    //   27767: invokeinterface setAlignedInt : (II)V
    //   27772: aload #5
    //   27774: sipush #1311
    //   27777: new org/renjin/gcc/runtime/BytePtr
    //   27780: dup
    //   27781: ldc_w 'lightsteelblue '
    //   27784: invokevirtual getBytes : ()[B
    //   27787: iconst_0
    //   27788: invokespecial <init> : ([BI)V
    //   27791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27796: aload #5
    //   27798: sipush #1312
    //   27801: new org/renjin/gcc/runtime/BytePtr
    //   27804: dup
    //   27805: ldc_w '#B0C4DE '
    //   27808: invokevirtual getBytes : ()[B
    //   27811: iconst_0
    //   27812: invokespecial <init> : ([BI)V
    //   27815: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27820: aload #5
    //   27822: sipush #1313
    //   27825: ldc_w -2177872
    //   27828: invokeinterface setAlignedInt : (II)V
    //   27833: aload #5
    //   27835: sipush #1314
    //   27838: new org/renjin/gcc/runtime/BytePtr
    //   27841: dup
    //   27842: ldc_w 'lightsteelblue1 '
    //   27845: invokevirtual getBytes : ()[B
    //   27848: iconst_0
    //   27849: invokespecial <init> : ([BI)V
    //   27852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27857: aload #5
    //   27859: sipush #1315
    //   27862: new org/renjin/gcc/runtime/BytePtr
    //   27865: dup
    //   27866: ldc_w '#CAE1FF '
    //   27869: invokevirtual getBytes : ()[B
    //   27872: iconst_0
    //   27873: invokespecial <init> : ([BI)V
    //   27876: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27881: aload #5
    //   27883: sipush #1316
    //   27886: sipush #-7734
    //   27889: invokeinterface setAlignedInt : (II)V
    //   27894: aload #5
    //   27896: sipush #1317
    //   27899: new org/renjin/gcc/runtime/BytePtr
    //   27902: dup
    //   27903: ldc_w 'lightsteelblue2 '
    //   27906: invokevirtual getBytes : ()[B
    //   27909: iconst_0
    //   27910: invokespecial <init> : ([BI)V
    //   27913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27918: aload #5
    //   27920: sipush #1318
    //   27923: new org/renjin/gcc/runtime/BytePtr
    //   27926: dup
    //   27927: ldc_w '#BCD2EE '
    //   27930: invokevirtual getBytes : ()[B
    //   27933: iconst_0
    //   27934: invokespecial <init> : ([BI)V
    //   27937: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27942: aload #5
    //   27944: sipush #1319
    //   27947: ldc_w -1125700
    //   27950: invokeinterface setAlignedInt : (II)V
    //   27955: aload #5
    //   27957: sipush #1320
    //   27960: new org/renjin/gcc/runtime/BytePtr
    //   27963: dup
    //   27964: ldc_w 'lightsteelblue3 '
    //   27967: invokevirtual getBytes : ()[B
    //   27970: iconst_0
    //   27971: invokespecial <init> : ([BI)V
    //   27974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   27979: aload #5
    //   27981: sipush #1321
    //   27984: new org/renjin/gcc/runtime/BytePtr
    //   27987: dup
    //   27988: ldc_w '#A2B5CD '
    //   27991: invokevirtual getBytes : ()[B
    //   27994: iconst_0
    //   27995: invokespecial <init> : ([BI)V
    //   27998: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28003: aload #5
    //   28005: sipush #1322
    //   28008: ldc_w -3295838
    //   28011: invokeinterface setAlignedInt : (II)V
    //   28016: aload #5
    //   28018: sipush #1323
    //   28021: new org/renjin/gcc/runtime/BytePtr
    //   28024: dup
    //   28025: ldc_w 'lightsteelblue4 '
    //   28028: invokevirtual getBytes : ()[B
    //   28031: iconst_0
    //   28032: invokespecial <init> : ([BI)V
    //   28035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28040: aload #5
    //   28042: sipush #1324
    //   28045: new org/renjin/gcc/runtime/BytePtr
    //   28048: dup
    //   28049: ldc_w '#6E7B8B '
    //   28052: invokevirtual getBytes : ()[B
    //   28055: iconst_0
    //   28056: invokespecial <init> : ([BI)V
    //   28059: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28064: aload #5
    //   28066: sipush #1325
    //   28069: ldc_w -7636114
    //   28072: invokeinterface setAlignedInt : (II)V
    //   28077: aload #5
    //   28079: sipush #1326
    //   28082: new org/renjin/gcc/runtime/BytePtr
    //   28085: dup
    //   28086: ldc_w 'lightyellow '
    //   28089: invokevirtual getBytes : ()[B
    //   28092: iconst_0
    //   28093: invokespecial <init> : ([BI)V
    //   28096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28101: aload #5
    //   28103: sipush #1327
    //   28106: new org/renjin/gcc/runtime/BytePtr
    //   28109: dup
    //   28110: ldc_w '#FFFFE0 '
    //   28113: invokevirtual getBytes : ()[B
    //   28116: iconst_0
    //   28117: invokespecial <init> : ([BI)V
    //   28120: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28125: aload #5
    //   28127: sipush #1328
    //   28130: ldc_w -2031617
    //   28133: invokeinterface setAlignedInt : (II)V
    //   28138: aload #5
    //   28140: sipush #1329
    //   28143: new org/renjin/gcc/runtime/BytePtr
    //   28146: dup
    //   28147: ldc_w 'lightyellow1 '
    //   28150: invokevirtual getBytes : ()[B
    //   28153: iconst_0
    //   28154: invokespecial <init> : ([BI)V
    //   28157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28162: aload #5
    //   28164: sipush #1330
    //   28167: new org/renjin/gcc/runtime/BytePtr
    //   28170: dup
    //   28171: ldc_w '#FFFFE0 '
    //   28174: invokevirtual getBytes : ()[B
    //   28177: iconst_0
    //   28178: invokespecial <init> : ([BI)V
    //   28181: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28186: aload #5
    //   28188: sipush #1331
    //   28191: ldc_w -2031617
    //   28194: invokeinterface setAlignedInt : (II)V
    //   28199: aload #5
    //   28201: sipush #1332
    //   28204: new org/renjin/gcc/runtime/BytePtr
    //   28207: dup
    //   28208: ldc_w 'lightyellow2 '
    //   28211: invokevirtual getBytes : ()[B
    //   28214: iconst_0
    //   28215: invokespecial <init> : ([BI)V
    //   28218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28223: aload #5
    //   28225: sipush #1333
    //   28228: new org/renjin/gcc/runtime/BytePtr
    //   28231: dup
    //   28232: ldc_w '#EEEED1 '
    //   28235: invokevirtual getBytes : ()[B
    //   28238: iconst_0
    //   28239: invokespecial <init> : ([BI)V
    //   28242: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28247: aload #5
    //   28249: sipush #1334
    //   28252: ldc_w -3019026
    //   28255: invokeinterface setAlignedInt : (II)V
    //   28260: aload #5
    //   28262: sipush #1335
    //   28265: new org/renjin/gcc/runtime/BytePtr
    //   28268: dup
    //   28269: ldc_w 'lightyellow3 '
    //   28272: invokevirtual getBytes : ()[B
    //   28275: iconst_0
    //   28276: invokespecial <init> : ([BI)V
    //   28279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28284: aload #5
    //   28286: sipush #1336
    //   28289: new org/renjin/gcc/runtime/BytePtr
    //   28292: dup
    //   28293: ldc_w '#CDCDB4 '
    //   28296: invokevirtual getBytes : ()[B
    //   28299: iconst_0
    //   28300: invokespecial <init> : ([BI)V
    //   28303: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28308: aload #5
    //   28310: sipush #1337
    //   28313: ldc_w -4928051
    //   28316: invokeinterface setAlignedInt : (II)V
    //   28321: aload #5
    //   28323: sipush #1338
    //   28326: new org/renjin/gcc/runtime/BytePtr
    //   28329: dup
    //   28330: ldc_w 'lightyellow4 '
    //   28333: invokevirtual getBytes : ()[B
    //   28336: iconst_0
    //   28337: invokespecial <init> : ([BI)V
    //   28340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28345: aload #5
    //   28347: sipush #1339
    //   28350: new org/renjin/gcc/runtime/BytePtr
    //   28353: dup
    //   28354: ldc_w '#8B8B7A '
    //   28357: invokevirtual getBytes : ()[B
    //   28360: iconst_0
    //   28361: invokespecial <init> : ([BI)V
    //   28364: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28369: aload #5
    //   28371: sipush #1340
    //   28374: ldc_w -8746101
    //   28377: invokeinterface setAlignedInt : (II)V
    //   28382: aload #5
    //   28384: sipush #1341
    //   28387: new org/renjin/gcc/runtime/BytePtr
    //   28390: dup
    //   28391: ldc_w 'limegreen '
    //   28394: invokevirtual getBytes : ()[B
    //   28397: iconst_0
    //   28398: invokespecial <init> : ([BI)V
    //   28401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28406: aload #5
    //   28408: sipush #1342
    //   28411: new org/renjin/gcc/runtime/BytePtr
    //   28414: dup
    //   28415: ldc_w '#32CD32 '
    //   28418: invokevirtual getBytes : ()[B
    //   28421: iconst_0
    //   28422: invokespecial <init> : ([BI)V
    //   28425: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28430: aload #5
    //   28432: sipush #1343
    //   28435: ldc_w -13447886
    //   28438: invokeinterface setAlignedInt : (II)V
    //   28443: aload #5
    //   28445: sipush #1344
    //   28448: new org/renjin/gcc/runtime/BytePtr
    //   28451: dup
    //   28452: ldc_w 'linen '
    //   28455: invokevirtual getBytes : ()[B
    //   28458: iconst_0
    //   28459: invokespecial <init> : ([BI)V
    //   28462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28467: aload #5
    //   28469: sipush #1345
    //   28472: new org/renjin/gcc/runtime/BytePtr
    //   28475: dup
    //   28476: ldc_w '#FAF0E6 '
    //   28479: invokevirtual getBytes : ()[B
    //   28482: iconst_0
    //   28483: invokespecial <init> : ([BI)V
    //   28486: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28491: aload #5
    //   28493: sipush #1346
    //   28496: ldc_w -1642246
    //   28499: invokeinterface setAlignedInt : (II)V
    //   28504: aload #5
    //   28506: sipush #1347
    //   28509: new org/renjin/gcc/runtime/BytePtr
    //   28512: dup
    //   28513: ldc_w 'magenta '
    //   28516: invokevirtual getBytes : ()[B
    //   28519: iconst_0
    //   28520: invokespecial <init> : ([BI)V
    //   28523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28528: aload #5
    //   28530: sipush #1348
    //   28533: new org/renjin/gcc/runtime/BytePtr
    //   28536: dup
    //   28537: ldc_w '#FF00FF '
    //   28540: invokevirtual getBytes : ()[B
    //   28543: iconst_0
    //   28544: invokespecial <init> : ([BI)V
    //   28547: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28552: aload #5
    //   28554: sipush #1349
    //   28557: ldc_w -65281
    //   28560: invokeinterface setAlignedInt : (II)V
    //   28565: aload #5
    //   28567: sipush #1350
    //   28570: new org/renjin/gcc/runtime/BytePtr
    //   28573: dup
    //   28574: ldc_w 'magenta1 '
    //   28577: invokevirtual getBytes : ()[B
    //   28580: iconst_0
    //   28581: invokespecial <init> : ([BI)V
    //   28584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28589: aload #5
    //   28591: sipush #1351
    //   28594: new org/renjin/gcc/runtime/BytePtr
    //   28597: dup
    //   28598: ldc_w '#FF00FF '
    //   28601: invokevirtual getBytes : ()[B
    //   28604: iconst_0
    //   28605: invokespecial <init> : ([BI)V
    //   28608: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28613: aload #5
    //   28615: sipush #1352
    //   28618: ldc_w -65281
    //   28621: invokeinterface setAlignedInt : (II)V
    //   28626: aload #5
    //   28628: sipush #1353
    //   28631: new org/renjin/gcc/runtime/BytePtr
    //   28634: dup
    //   28635: ldc_w 'magenta2 '
    //   28638: invokevirtual getBytes : ()[B
    //   28641: iconst_0
    //   28642: invokespecial <init> : ([BI)V
    //   28645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28650: aload #5
    //   28652: sipush #1354
    //   28655: new org/renjin/gcc/runtime/BytePtr
    //   28658: dup
    //   28659: ldc_w '#EE00EE '
    //   28662: invokevirtual getBytes : ()[B
    //   28665: iconst_0
    //   28666: invokespecial <init> : ([BI)V
    //   28669: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28674: aload #5
    //   28676: sipush #1355
    //   28679: ldc_w -1179410
    //   28682: invokeinterface setAlignedInt : (II)V
    //   28687: aload #5
    //   28689: sipush #1356
    //   28692: new org/renjin/gcc/runtime/BytePtr
    //   28695: dup
    //   28696: ldc_w 'magenta3 '
    //   28699: invokevirtual getBytes : ()[B
    //   28702: iconst_0
    //   28703: invokespecial <init> : ([BI)V
    //   28706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28711: aload #5
    //   28713: sipush #1357
    //   28716: new org/renjin/gcc/runtime/BytePtr
    //   28719: dup
    //   28720: ldc_w '#CD00CD '
    //   28723: invokevirtual getBytes : ()[B
    //   28726: iconst_0
    //   28727: invokespecial <init> : ([BI)V
    //   28730: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28735: aload #5
    //   28737: sipush #1358
    //   28740: ldc_w -3342131
    //   28743: invokeinterface setAlignedInt : (II)V
    //   28748: aload #5
    //   28750: sipush #1359
    //   28753: new org/renjin/gcc/runtime/BytePtr
    //   28756: dup
    //   28757: ldc_w 'magenta4 '
    //   28760: invokevirtual getBytes : ()[B
    //   28763: iconst_0
    //   28764: invokespecial <init> : ([BI)V
    //   28767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28772: aload #5
    //   28774: sipush #1360
    //   28777: new org/renjin/gcc/runtime/BytePtr
    //   28780: dup
    //   28781: ldc_w '#8B008B '
    //   28784: invokevirtual getBytes : ()[B
    //   28787: iconst_0
    //   28788: invokespecial <init> : ([BI)V
    //   28791: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28796: aload #5
    //   28798: sipush #1361
    //   28801: ldc_w -7667573
    //   28804: invokeinterface setAlignedInt : (II)V
    //   28809: aload #5
    //   28811: sipush #1362
    //   28814: new org/renjin/gcc/runtime/BytePtr
    //   28817: dup
    //   28818: ldc_w 'maroon '
    //   28821: invokevirtual getBytes : ()[B
    //   28824: iconst_0
    //   28825: invokespecial <init> : ([BI)V
    //   28828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28833: aload #5
    //   28835: sipush #1363
    //   28838: new org/renjin/gcc/runtime/BytePtr
    //   28841: dup
    //   28842: ldc_w '#B03060 '
    //   28845: invokevirtual getBytes : ()[B
    //   28848: iconst_0
    //   28849: invokespecial <init> : ([BI)V
    //   28852: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28857: aload #5
    //   28859: sipush #1364
    //   28862: ldc_w -10473296
    //   28865: invokeinterface setAlignedInt : (II)V
    //   28870: aload #5
    //   28872: sipush #1365
    //   28875: new org/renjin/gcc/runtime/BytePtr
    //   28878: dup
    //   28879: ldc_w 'maroon1 '
    //   28882: invokevirtual getBytes : ()[B
    //   28885: iconst_0
    //   28886: invokespecial <init> : ([BI)V
    //   28889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28894: aload #5
    //   28896: sipush #1366
    //   28899: new org/renjin/gcc/runtime/BytePtr
    //   28902: dup
    //   28903: ldc_w '#FF34B3 '
    //   28906: invokevirtual getBytes : ()[B
    //   28909: iconst_0
    //   28910: invokespecial <init> : ([BI)V
    //   28913: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28918: aload #5
    //   28920: sipush #1367
    //   28923: ldc_w -5032705
    //   28926: invokeinterface setAlignedInt : (II)V
    //   28931: aload #5
    //   28933: sipush #1368
    //   28936: new org/renjin/gcc/runtime/BytePtr
    //   28939: dup
    //   28940: ldc_w 'maroon2 '
    //   28943: invokevirtual getBytes : ()[B
    //   28946: iconst_0
    //   28947: invokespecial <init> : ([BI)V
    //   28950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28955: aload #5
    //   28957: sipush #1369
    //   28960: new org/renjin/gcc/runtime/BytePtr
    //   28963: dup
    //   28964: ldc_w '#EE30A7 '
    //   28967: invokevirtual getBytes : ()[B
    //   28970: iconst_0
    //   28971: invokespecial <init> : ([BI)V
    //   28974: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   28979: aload #5
    //   28981: sipush #1370
    //   28984: ldc_w -5820178
    //   28987: invokeinterface setAlignedInt : (II)V
    //   28992: aload #5
    //   28994: sipush #1371
    //   28997: new org/renjin/gcc/runtime/BytePtr
    //   29000: dup
    //   29001: ldc_w 'maroon3 '
    //   29004: invokevirtual getBytes : ()[B
    //   29007: iconst_0
    //   29008: invokespecial <init> : ([BI)V
    //   29011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29016: aload #5
    //   29018: sipush #1372
    //   29021: new org/renjin/gcc/runtime/BytePtr
    //   29024: dup
    //   29025: ldc_w '#CD2990 '
    //   29028: invokevirtual getBytes : ()[B
    //   29031: iconst_0
    //   29032: invokespecial <init> : ([BI)V
    //   29035: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29040: aload #5
    //   29042: sipush #1373
    //   29045: ldc_w -7329331
    //   29048: invokeinterface setAlignedInt : (II)V
    //   29053: aload #5
    //   29055: sipush #1374
    //   29058: new org/renjin/gcc/runtime/BytePtr
    //   29061: dup
    //   29062: ldc_w 'maroon4 '
    //   29065: invokevirtual getBytes : ()[B
    //   29068: iconst_0
    //   29069: invokespecial <init> : ([BI)V
    //   29072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29077: aload #5
    //   29079: sipush #1375
    //   29082: new org/renjin/gcc/runtime/BytePtr
    //   29085: dup
    //   29086: ldc_w '#8B1C62 '
    //   29089: invokevirtual getBytes : ()[B
    //   29092: iconst_0
    //   29093: invokespecial <init> : ([BI)V
    //   29096: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29101: aload #5
    //   29103: sipush #1376
    //   29106: ldc_w -10347381
    //   29109: invokeinterface setAlignedInt : (II)V
    //   29114: aload #5
    //   29116: sipush #1377
    //   29119: new org/renjin/gcc/runtime/BytePtr
    //   29122: dup
    //   29123: ldc_w 'mediumaquamarine '
    //   29126: invokevirtual getBytes : ()[B
    //   29129: iconst_0
    //   29130: invokespecial <init> : ([BI)V
    //   29133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29138: aload #5
    //   29140: sipush #1378
    //   29143: new org/renjin/gcc/runtime/BytePtr
    //   29146: dup
    //   29147: ldc_w '#66CDAA '
    //   29150: invokevirtual getBytes : ()[B
    //   29153: iconst_0
    //   29154: invokespecial <init> : ([BI)V
    //   29157: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29162: aload #5
    //   29164: sipush #1379
    //   29167: ldc_w -5583514
    //   29170: invokeinterface setAlignedInt : (II)V
    //   29175: aload #5
    //   29177: sipush #1380
    //   29180: new org/renjin/gcc/runtime/BytePtr
    //   29183: dup
    //   29184: ldc_w 'mediumblue '
    //   29187: invokevirtual getBytes : ()[B
    //   29190: iconst_0
    //   29191: invokespecial <init> : ([BI)V
    //   29194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29199: aload #5
    //   29201: sipush #1381
    //   29204: new org/renjin/gcc/runtime/BytePtr
    //   29207: dup
    //   29208: ldc_w '#0000CD '
    //   29211: invokevirtual getBytes : ()[B
    //   29214: iconst_0
    //   29215: invokespecial <init> : ([BI)V
    //   29218: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29223: aload #5
    //   29225: sipush #1382
    //   29228: ldc_w -3342336
    //   29231: invokeinterface setAlignedInt : (II)V
    //   29236: aload #5
    //   29238: sipush #1383
    //   29241: new org/renjin/gcc/runtime/BytePtr
    //   29244: dup
    //   29245: ldc_w 'mediumorchid '
    //   29248: invokevirtual getBytes : ()[B
    //   29251: iconst_0
    //   29252: invokespecial <init> : ([BI)V
    //   29255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29260: aload #5
    //   29262: sipush #1384
    //   29265: new org/renjin/gcc/runtime/BytePtr
    //   29268: dup
    //   29269: ldc_w '#BA55D3 '
    //   29272: invokevirtual getBytes : ()[B
    //   29275: iconst_0
    //   29276: invokespecial <init> : ([BI)V
    //   29279: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29284: aload #5
    //   29286: sipush #1385
    //   29289: ldc_w -2927174
    //   29292: invokeinterface setAlignedInt : (II)V
    //   29297: aload #5
    //   29299: sipush #1386
    //   29302: new org/renjin/gcc/runtime/BytePtr
    //   29305: dup
    //   29306: ldc_w 'mediumorchid1 '
    //   29309: invokevirtual getBytes : ()[B
    //   29312: iconst_0
    //   29313: invokespecial <init> : ([BI)V
    //   29316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29321: aload #5
    //   29323: sipush #1387
    //   29326: new org/renjin/gcc/runtime/BytePtr
    //   29329: dup
    //   29330: ldc_w '#E066FF '
    //   29333: invokevirtual getBytes : ()[B
    //   29336: iconst_0
    //   29337: invokespecial <init> : ([BI)V
    //   29340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29345: aload #5
    //   29347: sipush #1388
    //   29350: ldc_w -39200
    //   29353: invokeinterface setAlignedInt : (II)V
    //   29358: aload #5
    //   29360: sipush #1389
    //   29363: new org/renjin/gcc/runtime/BytePtr
    //   29366: dup
    //   29367: ldc_w 'mediumorchid2 '
    //   29370: invokevirtual getBytes : ()[B
    //   29373: iconst_0
    //   29374: invokespecial <init> : ([BI)V
    //   29377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29382: aload #5
    //   29384: sipush #1390
    //   29387: new org/renjin/gcc/runtime/BytePtr
    //   29390: dup
    //   29391: ldc_w '#D15FEE '
    //   29394: invokevirtual getBytes : ()[B
    //   29397: iconst_0
    //   29398: invokespecial <init> : ([BI)V
    //   29401: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29406: aload #5
    //   29408: sipush #1391
    //   29411: ldc_w -1155119
    //   29414: invokeinterface setAlignedInt : (II)V
    //   29419: aload #5
    //   29421: sipush #1392
    //   29424: new org/renjin/gcc/runtime/BytePtr
    //   29427: dup
    //   29428: ldc_w 'mediumorchid3 '
    //   29431: invokevirtual getBytes : ()[B
    //   29434: iconst_0
    //   29435: invokespecial <init> : ([BI)V
    //   29438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29443: aload #5
    //   29445: sipush #1393
    //   29448: new org/renjin/gcc/runtime/BytePtr
    //   29451: dup
    //   29452: ldc_w '#B452CD '
    //   29455: invokevirtual getBytes : ()[B
    //   29458: iconst_0
    //   29459: invokespecial <init> : ([BI)V
    //   29462: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29467: aload #5
    //   29469: sipush #1394
    //   29472: ldc_w -3321164
    //   29475: invokeinterface setAlignedInt : (II)V
    //   29480: aload #5
    //   29482: sipush #1395
    //   29485: new org/renjin/gcc/runtime/BytePtr
    //   29488: dup
    //   29489: ldc_w 'mediumorchid4 '
    //   29492: invokevirtual getBytes : ()[B
    //   29495: iconst_0
    //   29496: invokespecial <init> : ([BI)V
    //   29499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29504: aload #5
    //   29506: sipush #1396
    //   29509: new org/renjin/gcc/runtime/BytePtr
    //   29512: dup
    //   29513: ldc_w '#7A378B '
    //   29516: invokevirtual getBytes : ()[B
    //   29519: iconst_0
    //   29520: invokespecial <init> : ([BI)V
    //   29523: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29528: aload #5
    //   29530: sipush #1397
    //   29533: ldc_w -7653510
    //   29536: invokeinterface setAlignedInt : (II)V
    //   29541: aload #5
    //   29543: sipush #1398
    //   29546: new org/renjin/gcc/runtime/BytePtr
    //   29549: dup
    //   29550: ldc_w 'mediumpurple '
    //   29553: invokevirtual getBytes : ()[B
    //   29556: iconst_0
    //   29557: invokespecial <init> : ([BI)V
    //   29560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29565: aload #5
    //   29567: sipush #1399
    //   29570: new org/renjin/gcc/runtime/BytePtr
    //   29573: dup
    //   29574: ldc_w '#9370DB '
    //   29577: invokevirtual getBytes : ()[B
    //   29580: iconst_0
    //   29581: invokespecial <init> : ([BI)V
    //   29584: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29589: aload #5
    //   29591: sipush #1400
    //   29594: ldc_w -2396013
    //   29597: invokeinterface setAlignedInt : (II)V
    //   29602: aload #5
    //   29604: sipush #1401
    //   29607: new org/renjin/gcc/runtime/BytePtr
    //   29610: dup
    //   29611: ldc_w 'mediumpurple1 '
    //   29614: invokevirtual getBytes : ()[B
    //   29617: iconst_0
    //   29618: invokespecial <init> : ([BI)V
    //   29621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29626: aload #5
    //   29628: sipush #1402
    //   29631: new org/renjin/gcc/runtime/BytePtr
    //   29634: dup
    //   29635: ldc_w '#AB82FF '
    //   29638: invokevirtual getBytes : ()[B
    //   29641: iconst_0
    //   29642: invokespecial <init> : ([BI)V
    //   29645: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29650: aload #5
    //   29652: sipush #1403
    //   29655: sipush #-32085
    //   29658: invokeinterface setAlignedInt : (II)V
    //   29663: aload #5
    //   29665: sipush #1404
    //   29668: new org/renjin/gcc/runtime/BytePtr
    //   29671: dup
    //   29672: ldc_w 'mediumpurple2 '
    //   29675: invokevirtual getBytes : ()[B
    //   29678: iconst_0
    //   29679: invokespecial <init> : ([BI)V
    //   29682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29687: aload #5
    //   29689: sipush #1405
    //   29692: new org/renjin/gcc/runtime/BytePtr
    //   29695: dup
    //   29696: ldc_w '#9F79EE '
    //   29699: invokevirtual getBytes : ()[B
    //   29702: iconst_0
    //   29703: invokespecial <init> : ([BI)V
    //   29706: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29711: aload #5
    //   29713: sipush #1406
    //   29716: ldc_w -1148513
    //   29719: invokeinterface setAlignedInt : (II)V
    //   29724: aload #5
    //   29726: sipush #1407
    //   29729: new org/renjin/gcc/runtime/BytePtr
    //   29732: dup
    //   29733: ldc_w 'mediumpurple3 '
    //   29736: invokevirtual getBytes : ()[B
    //   29739: iconst_0
    //   29740: invokespecial <init> : ([BI)V
    //   29743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29748: aload #5
    //   29750: sipush #1408
    //   29753: new org/renjin/gcc/runtime/BytePtr
    //   29756: dup
    //   29757: ldc_w '#8968CD '
    //   29760: invokevirtual getBytes : ()[B
    //   29763: iconst_0
    //   29764: invokespecial <init> : ([BI)V
    //   29767: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29772: aload #5
    //   29774: sipush #1409
    //   29777: ldc_w -3315575
    //   29780: invokeinterface setAlignedInt : (II)V
    //   29785: aload #5
    //   29787: sipush #1410
    //   29790: new org/renjin/gcc/runtime/BytePtr
    //   29793: dup
    //   29794: ldc_w 'mediumpurple4 '
    //   29797: invokevirtual getBytes : ()[B
    //   29800: iconst_0
    //   29801: invokespecial <init> : ([BI)V
    //   29804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29809: aload #5
    //   29811: sipush #1411
    //   29814: new org/renjin/gcc/runtime/BytePtr
    //   29817: dup
    //   29818: ldc_w '#5D478B '
    //   29821: invokevirtual getBytes : ()[B
    //   29824: iconst_0
    //   29825: invokespecial <init> : ([BI)V
    //   29828: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29833: aload #5
    //   29835: sipush #1412
    //   29838: ldc_w -7649443
    //   29841: invokeinterface setAlignedInt : (II)V
    //   29846: aload #5
    //   29848: sipush #1413
    //   29851: new org/renjin/gcc/runtime/BytePtr
    //   29854: dup
    //   29855: ldc_w 'mediumseagreen '
    //   29858: invokevirtual getBytes : ()[B
    //   29861: iconst_0
    //   29862: invokespecial <init> : ([BI)V
    //   29865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29870: aload #5
    //   29872: sipush #1414
    //   29875: new org/renjin/gcc/runtime/BytePtr
    //   29878: dup
    //   29879: ldc_w '#3CB371 '
    //   29882: invokevirtual getBytes : ()[B
    //   29885: iconst_0
    //   29886: invokespecial <init> : ([BI)V
    //   29889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29894: aload #5
    //   29896: sipush #1415
    //   29899: ldc_w -9325764
    //   29902: invokeinterface setAlignedInt : (II)V
    //   29907: aload #5
    //   29909: sipush #1416
    //   29912: new org/renjin/gcc/runtime/BytePtr
    //   29915: dup
    //   29916: ldc_w 'mediumslateblue '
    //   29919: invokevirtual getBytes : ()[B
    //   29922: iconst_0
    //   29923: invokespecial <init> : ([BI)V
    //   29926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29931: aload #5
    //   29933: sipush #1417
    //   29936: new org/renjin/gcc/runtime/BytePtr
    //   29939: dup
    //   29940: ldc_w '#7B68EE '
    //   29943: invokevirtual getBytes : ()[B
    //   29946: iconst_0
    //   29947: invokespecial <init> : ([BI)V
    //   29950: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29955: aload #5
    //   29957: sipush #1418
    //   29960: ldc_w -1152901
    //   29963: invokeinterface setAlignedInt : (II)V
    //   29968: aload #5
    //   29970: sipush #1419
    //   29973: new org/renjin/gcc/runtime/BytePtr
    //   29976: dup
    //   29977: ldc_w 'mediumspringgreen '
    //   29980: invokevirtual getBytes : ()[B
    //   29983: iconst_0
    //   29984: invokespecial <init> : ([BI)V
    //   29987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   29992: aload #5
    //   29994: sipush #1420
    //   29997: new org/renjin/gcc/runtime/BytePtr
    //   30000: dup
    //   30001: ldc_w '#00FA9A '
    //   30004: invokevirtual getBytes : ()[B
    //   30007: iconst_0
    //   30008: invokespecial <init> : ([BI)V
    //   30011: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30016: aload #5
    //   30018: sipush #1421
    //   30021: ldc_w -6620672
    //   30024: invokeinterface setAlignedInt : (II)V
    //   30029: aload #5
    //   30031: sipush #1422
    //   30034: new org/renjin/gcc/runtime/BytePtr
    //   30037: dup
    //   30038: ldc_w 'mediumturquoise '
    //   30041: invokevirtual getBytes : ()[B
    //   30044: iconst_0
    //   30045: invokespecial <init> : ([BI)V
    //   30048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30053: aload #5
    //   30055: sipush #1423
    //   30058: new org/renjin/gcc/runtime/BytePtr
    //   30061: dup
    //   30062: ldc_w '#48D1CC '
    //   30065: invokevirtual getBytes : ()[B
    //   30068: iconst_0
    //   30069: invokespecial <init> : ([BI)V
    //   30072: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30077: aload #5
    //   30079: sipush #1424
    //   30082: ldc_w -3354296
    //   30085: invokeinterface setAlignedInt : (II)V
    //   30090: aload #5
    //   30092: sipush #1425
    //   30095: new org/renjin/gcc/runtime/BytePtr
    //   30098: dup
    //   30099: ldc_w 'mediumvioletred '
    //   30102: invokevirtual getBytes : ()[B
    //   30105: iconst_0
    //   30106: invokespecial <init> : ([BI)V
    //   30109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30114: aload #5
    //   30116: sipush #1426
    //   30119: new org/renjin/gcc/runtime/BytePtr
    //   30122: dup
    //   30123: ldc_w '#C71585 '
    //   30126: invokevirtual getBytes : ()[B
    //   30129: iconst_0
    //   30130: invokespecial <init> : ([BI)V
    //   30133: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30138: aload #5
    //   30140: sipush #1427
    //   30143: ldc_w -8055353
    //   30146: invokeinterface setAlignedInt : (II)V
    //   30151: aload #5
    //   30153: sipush #1428
    //   30156: new org/renjin/gcc/runtime/BytePtr
    //   30159: dup
    //   30160: ldc_w 'midnightblue '
    //   30163: invokevirtual getBytes : ()[B
    //   30166: iconst_0
    //   30167: invokespecial <init> : ([BI)V
    //   30170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30175: aload #5
    //   30177: sipush #1429
    //   30180: new org/renjin/gcc/runtime/BytePtr
    //   30183: dup
    //   30184: ldc_w '#191970 '
    //   30187: invokevirtual getBytes : ()[B
    //   30190: iconst_0
    //   30191: invokespecial <init> : ([BI)V
    //   30194: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30199: aload #5
    //   30201: sipush #1430
    //   30204: ldc_w -9430759
    //   30207: invokeinterface setAlignedInt : (II)V
    //   30212: aload #5
    //   30214: sipush #1431
    //   30217: new org/renjin/gcc/runtime/BytePtr
    //   30220: dup
    //   30221: ldc_w 'mintcream '
    //   30224: invokevirtual getBytes : ()[B
    //   30227: iconst_0
    //   30228: invokespecial <init> : ([BI)V
    //   30231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30236: aload #5
    //   30238: sipush #1432
    //   30241: new org/renjin/gcc/runtime/BytePtr
    //   30244: dup
    //   30245: ldc_w '#F5FFFA '
    //   30248: invokevirtual getBytes : ()[B
    //   30251: iconst_0
    //   30252: invokespecial <init> : ([BI)V
    //   30255: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30260: aload #5
    //   30262: sipush #1433
    //   30265: ldc_w -327691
    //   30268: invokeinterface setAlignedInt : (II)V
    //   30273: aload #5
    //   30275: sipush #1434
    //   30278: new org/renjin/gcc/runtime/BytePtr
    //   30281: dup
    //   30282: ldc_w 'mistyrose '
    //   30285: invokevirtual getBytes : ()[B
    //   30288: iconst_0
    //   30289: invokespecial <init> : ([BI)V
    //   30292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30297: aload #5
    //   30299: sipush #1435
    //   30302: new org/renjin/gcc/runtime/BytePtr
    //   30305: dup
    //   30306: ldc_w '#FFE4E1 '
    //   30309: invokevirtual getBytes : ()[B
    //   30312: iconst_0
    //   30313: invokespecial <init> : ([BI)V
    //   30316: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30321: aload #5
    //   30323: sipush #1436
    //   30326: ldc_w -1972993
    //   30329: invokeinterface setAlignedInt : (II)V
    //   30334: aload #5
    //   30336: sipush #1437
    //   30339: new org/renjin/gcc/runtime/BytePtr
    //   30342: dup
    //   30343: ldc_w 'mistyrose1 '
    //   30346: invokevirtual getBytes : ()[B
    //   30349: iconst_0
    //   30350: invokespecial <init> : ([BI)V
    //   30353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30358: aload #5
    //   30360: sipush #1438
    //   30363: new org/renjin/gcc/runtime/BytePtr
    //   30366: dup
    //   30367: ldc_w '#FFE4E1 '
    //   30370: invokevirtual getBytes : ()[B
    //   30373: iconst_0
    //   30374: invokespecial <init> : ([BI)V
    //   30377: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30382: aload #5
    //   30384: sipush #1439
    //   30387: ldc_w -1972993
    //   30390: invokeinterface setAlignedInt : (II)V
    //   30395: aload #5
    //   30397: sipush #1440
    //   30400: new org/renjin/gcc/runtime/BytePtr
    //   30403: dup
    //   30404: ldc_w 'mistyrose2 '
    //   30407: invokevirtual getBytes : ()[B
    //   30410: iconst_0
    //   30411: invokespecial <init> : ([BI)V
    //   30414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30419: aload #5
    //   30421: sipush #1441
    //   30424: new org/renjin/gcc/runtime/BytePtr
    //   30427: dup
    //   30428: ldc_w '#EED5D2 '
    //   30431: invokevirtual getBytes : ()[B
    //   30434: iconst_0
    //   30435: invokespecial <init> : ([BI)V
    //   30438: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30443: aload #5
    //   30445: sipush #1442
    //   30448: ldc_w -2959890
    //   30451: invokeinterface setAlignedInt : (II)V
    //   30456: aload #5
    //   30458: sipush #1443
    //   30461: new org/renjin/gcc/runtime/BytePtr
    //   30464: dup
    //   30465: ldc_w 'mistyrose3 '
    //   30468: invokevirtual getBytes : ()[B
    //   30471: iconst_0
    //   30472: invokespecial <init> : ([BI)V
    //   30475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30480: aload #5
    //   30482: sipush #1444
    //   30485: new org/renjin/gcc/runtime/BytePtr
    //   30488: dup
    //   30489: ldc_w '#CDB7B5 '
    //   30492: invokevirtual getBytes : ()[B
    //   30495: iconst_0
    //   30496: invokespecial <init> : ([BI)V
    //   30499: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30504: aload #5
    //   30506: sipush #1445
    //   30509: ldc_w -4868147
    //   30512: invokeinterface setAlignedInt : (II)V
    //   30517: aload #5
    //   30519: sipush #1446
    //   30522: new org/renjin/gcc/runtime/BytePtr
    //   30525: dup
    //   30526: ldc_w 'mistyrose4 '
    //   30529: invokevirtual getBytes : ()[B
    //   30532: iconst_0
    //   30533: invokespecial <init> : ([BI)V
    //   30536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30541: aload #5
    //   30543: sipush #1447
    //   30546: new org/renjin/gcc/runtime/BytePtr
    //   30549: dup
    //   30550: ldc_w '#8B7D7B '
    //   30553: invokevirtual getBytes : ()[B
    //   30556: iconst_0
    //   30557: invokespecial <init> : ([BI)V
    //   30560: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30565: aload #5
    //   30567: sipush #1448
    //   30570: ldc_w -8684149
    //   30573: invokeinterface setAlignedInt : (II)V
    //   30578: aload #5
    //   30580: sipush #1449
    //   30583: new org/renjin/gcc/runtime/BytePtr
    //   30586: dup
    //   30587: ldc_w 'moccasin '
    //   30590: invokevirtual getBytes : ()[B
    //   30593: iconst_0
    //   30594: invokespecial <init> : ([BI)V
    //   30597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30602: aload #5
    //   30604: sipush #1450
    //   30607: new org/renjin/gcc/runtime/BytePtr
    //   30610: dup
    //   30611: ldc_w '#FFE4B5 '
    //   30614: invokevirtual getBytes : ()[B
    //   30617: iconst_0
    //   30618: invokespecial <init> : ([BI)V
    //   30621: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30626: aload #5
    //   30628: sipush #1451
    //   30631: ldc_w -4856577
    //   30634: invokeinterface setAlignedInt : (II)V
    //   30639: aload #5
    //   30641: sipush #1452
    //   30644: new org/renjin/gcc/runtime/BytePtr
    //   30647: dup
    //   30648: ldc_w 'navajowhite '
    //   30651: invokevirtual getBytes : ()[B
    //   30654: iconst_0
    //   30655: invokespecial <init> : ([BI)V
    //   30658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30663: aload #5
    //   30665: sipush #1453
    //   30668: new org/renjin/gcc/runtime/BytePtr
    //   30671: dup
    //   30672: ldc_w '#FFDEAD '
    //   30675: invokevirtual getBytes : ()[B
    //   30678: iconst_0
    //   30679: invokespecial <init> : ([BI)V
    //   30682: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30687: aload #5
    //   30689: sipush #1454
    //   30692: ldc_w -5382401
    //   30695: invokeinterface setAlignedInt : (II)V
    //   30700: aload #5
    //   30702: sipush #1455
    //   30705: new org/renjin/gcc/runtime/BytePtr
    //   30708: dup
    //   30709: ldc_w 'navajowhite1 '
    //   30712: invokevirtual getBytes : ()[B
    //   30715: iconst_0
    //   30716: invokespecial <init> : ([BI)V
    //   30719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30724: aload #5
    //   30726: sipush #1456
    //   30729: new org/renjin/gcc/runtime/BytePtr
    //   30732: dup
    //   30733: ldc_w '#FFDEAD '
    //   30736: invokevirtual getBytes : ()[B
    //   30739: iconst_0
    //   30740: invokespecial <init> : ([BI)V
    //   30743: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30748: aload #5
    //   30750: sipush #1457
    //   30753: ldc_w -5382401
    //   30756: invokeinterface setAlignedInt : (II)V
    //   30761: aload #5
    //   30763: sipush #1458
    //   30766: new org/renjin/gcc/runtime/BytePtr
    //   30769: dup
    //   30770: ldc_w 'navajowhite2 '
    //   30773: invokevirtual getBytes : ()[B
    //   30776: iconst_0
    //   30777: invokespecial <init> : ([BI)V
    //   30780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30785: aload #5
    //   30787: sipush #1459
    //   30790: new org/renjin/gcc/runtime/BytePtr
    //   30793: dup
    //   30794: ldc_w '#EECFA1 '
    //   30797: invokevirtual getBytes : ()[B
    //   30800: iconst_0
    //   30801: invokespecial <init> : ([BI)V
    //   30804: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30809: aload #5
    //   30811: sipush #1460
    //   30814: ldc_w -6172690
    //   30817: invokeinterface setAlignedInt : (II)V
    //   30822: aload #5
    //   30824: sipush #1461
    //   30827: new org/renjin/gcc/runtime/BytePtr
    //   30830: dup
    //   30831: ldc_w 'navajowhite3 '
    //   30834: invokevirtual getBytes : ()[B
    //   30837: iconst_0
    //   30838: invokespecial <init> : ([BI)V
    //   30841: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30846: aload #5
    //   30848: sipush #1462
    //   30851: new org/renjin/gcc/runtime/BytePtr
    //   30854: dup
    //   30855: ldc_w '#CDB38B '
    //   30858: invokevirtual getBytes : ()[B
    //   30861: iconst_0
    //   30862: invokespecial <init> : ([BI)V
    //   30865: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30870: aload #5
    //   30872: sipush #1463
    //   30875: ldc_w -7621683
    //   30878: invokeinterface setAlignedInt : (II)V
    //   30883: aload #5
    //   30885: sipush #1464
    //   30888: new org/renjin/gcc/runtime/BytePtr
    //   30891: dup
    //   30892: ldc_w 'navajowhite4 '
    //   30895: invokevirtual getBytes : ()[B
    //   30898: iconst_0
    //   30899: invokespecial <init> : ([BI)V
    //   30902: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30907: aload #5
    //   30909: sipush #1465
    //   30912: new org/renjin/gcc/runtime/BytePtr
    //   30915: dup
    //   30916: ldc_w '#8B795E '
    //   30919: invokevirtual getBytes : ()[B
    //   30922: iconst_0
    //   30923: invokespecial <init> : ([BI)V
    //   30926: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30931: aload #5
    //   30933: sipush #1466
    //   30936: ldc_w -10585717
    //   30939: invokeinterface setAlignedInt : (II)V
    //   30944: aload #5
    //   30946: sipush #1467
    //   30949: new org/renjin/gcc/runtime/BytePtr
    //   30952: dup
    //   30953: ldc_w 'navy '
    //   30956: invokevirtual getBytes : ()[B
    //   30959: iconst_0
    //   30960: invokespecial <init> : ([BI)V
    //   30963: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30968: aload #5
    //   30970: sipush #1468
    //   30973: new org/renjin/gcc/runtime/BytePtr
    //   30976: dup
    //   30977: ldc_w '#000080 '
    //   30980: invokevirtual getBytes : ()[B
    //   30983: iconst_0
    //   30984: invokespecial <init> : ([BI)V
    //   30987: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   30992: aload #5
    //   30994: sipush #1469
    //   30997: ldc_w -8388608
    //   31000: invokeinterface setAlignedInt : (II)V
    //   31005: aload #5
    //   31007: sipush #1470
    //   31010: new org/renjin/gcc/runtime/BytePtr
    //   31013: dup
    //   31014: ldc_w 'navyblue '
    //   31017: invokevirtual getBytes : ()[B
    //   31020: iconst_0
    //   31021: invokespecial <init> : ([BI)V
    //   31024: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31029: aload #5
    //   31031: sipush #1471
    //   31034: new org/renjin/gcc/runtime/BytePtr
    //   31037: dup
    //   31038: ldc_w '#000080 '
    //   31041: invokevirtual getBytes : ()[B
    //   31044: iconst_0
    //   31045: invokespecial <init> : ([BI)V
    //   31048: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31053: aload #5
    //   31055: sipush #1472
    //   31058: ldc_w -8388608
    //   31061: invokeinterface setAlignedInt : (II)V
    //   31066: aload #5
    //   31068: sipush #1473
    //   31071: new org/renjin/gcc/runtime/BytePtr
    //   31074: dup
    //   31075: ldc_w 'oldlace '
    //   31078: invokevirtual getBytes : ()[B
    //   31081: iconst_0
    //   31082: invokespecial <init> : ([BI)V
    //   31085: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31090: aload #5
    //   31092: sipush #1474
    //   31095: new org/renjin/gcc/runtime/BytePtr
    //   31098: dup
    //   31099: ldc_w '#FDF5E6 '
    //   31102: invokevirtual getBytes : ()[B
    //   31105: iconst_0
    //   31106: invokespecial <init> : ([BI)V
    //   31109: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31114: aload #5
    //   31116: sipush #1475
    //   31119: ldc_w -1640963
    //   31122: invokeinterface setAlignedInt : (II)V
    //   31127: aload #5
    //   31129: sipush #1476
    //   31132: new org/renjin/gcc/runtime/BytePtr
    //   31135: dup
    //   31136: ldc_w 'olivedrab '
    //   31139: invokevirtual getBytes : ()[B
    //   31142: iconst_0
    //   31143: invokespecial <init> : ([BI)V
    //   31146: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31151: aload #5
    //   31153: sipush #1477
    //   31156: new org/renjin/gcc/runtime/BytePtr
    //   31159: dup
    //   31160: ldc_w '#6B8E23 '
    //   31163: invokevirtual getBytes : ()[B
    //   31166: iconst_0
    //   31167: invokespecial <init> : ([BI)V
    //   31170: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31175: aload #5
    //   31177: sipush #1478
    //   31180: ldc_w -14446997
    //   31183: invokeinterface setAlignedInt : (II)V
    //   31188: aload #5
    //   31190: sipush #1479
    //   31193: new org/renjin/gcc/runtime/BytePtr
    //   31196: dup
    //   31197: ldc_w 'olivedrab1 '
    //   31200: invokevirtual getBytes : ()[B
    //   31203: iconst_0
    //   31204: invokespecial <init> : ([BI)V
    //   31207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31212: aload #5
    //   31214: sipush #1480
    //   31217: new org/renjin/gcc/runtime/BytePtr
    //   31220: dup
    //   31221: ldc_w '#C0FF3E '
    //   31224: invokevirtual getBytes : ()[B
    //   31227: iconst_0
    //   31228: invokespecial <init> : ([BI)V
    //   31231: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31236: aload #5
    //   31238: sipush #1481
    //   31241: ldc_w -12648512
    //   31244: invokeinterface setAlignedInt : (II)V
    //   31249: aload #5
    //   31251: sipush #1482
    //   31254: new org/renjin/gcc/runtime/BytePtr
    //   31257: dup
    //   31258: ldc_w 'olivedrab2 '
    //   31261: invokevirtual getBytes : ()[B
    //   31264: iconst_0
    //   31265: invokespecial <init> : ([BI)V
    //   31268: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31273: aload #5
    //   31275: sipush #1483
    //   31278: new org/renjin/gcc/runtime/BytePtr
    //   31281: dup
    //   31282: ldc_w '#B3EE3A '
    //   31285: invokevirtual getBytes : ()[B
    //   31288: iconst_0
    //   31289: invokespecial <init> : ([BI)V
    //   31292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31297: aload #5
    //   31299: sipush #1484
    //   31302: ldc_w -12915021
    //   31305: invokeinterface setAlignedInt : (II)V
    //   31310: aload #5
    //   31312: sipush #1485
    //   31315: new org/renjin/gcc/runtime/BytePtr
    //   31318: dup
    //   31319: ldc_w 'olivedrab3 '
    //   31322: invokevirtual getBytes : ()[B
    //   31325: iconst_0
    //   31326: invokespecial <init> : ([BI)V
    //   31329: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31334: aload #5
    //   31336: sipush #1486
    //   31339: new org/renjin/gcc/runtime/BytePtr
    //   31342: dup
    //   31343: ldc_w '#9ACD32 '
    //   31346: invokevirtual getBytes : ()[B
    //   31349: iconst_0
    //   31350: invokespecial <init> : ([BI)V
    //   31353: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31358: aload #5
    //   31360: sipush #1487
    //   31363: ldc_w -13447782
    //   31366: invokeinterface setAlignedInt : (II)V
    //   31371: aload #5
    //   31373: sipush #1488
    //   31376: new org/renjin/gcc/runtime/BytePtr
    //   31379: dup
    //   31380: ldc_w 'olivedrab4 '
    //   31383: invokevirtual getBytes : ()[B
    //   31386: iconst_0
    //   31387: invokespecial <init> : ([BI)V
    //   31390: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31395: aload #5
    //   31397: sipush #1489
    //   31400: new org/renjin/gcc/runtime/BytePtr
    //   31403: dup
    //   31404: ldc_w '#698B22 '
    //   31407: invokevirtual getBytes : ()[B
    //   31410: iconst_0
    //   31411: invokespecial <init> : ([BI)V
    //   31414: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31419: aload #5
    //   31421: sipush #1490
    //   31424: ldc_w -14513303
    //   31427: invokeinterface setAlignedInt : (II)V
    //   31432: aload #5
    //   31434: sipush #1491
    //   31437: new org/renjin/gcc/runtime/BytePtr
    //   31440: dup
    //   31441: ldc_w 'orange '
    //   31444: invokevirtual getBytes : ()[B
    //   31447: iconst_0
    //   31448: invokespecial <init> : ([BI)V
    //   31451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31456: aload #5
    //   31458: sipush #1492
    //   31461: new org/renjin/gcc/runtime/BytePtr
    //   31464: dup
    //   31465: ldc_w '#FFA500 '
    //   31468: invokevirtual getBytes : ()[B
    //   31471: iconst_0
    //   31472: invokespecial <init> : ([BI)V
    //   31475: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31480: aload #5
    //   31482: sipush #1493
    //   31485: ldc_w -16734721
    //   31488: invokeinterface setAlignedInt : (II)V
    //   31493: aload #5
    //   31495: sipush #1494
    //   31498: new org/renjin/gcc/runtime/BytePtr
    //   31501: dup
    //   31502: ldc_w 'orange1 '
    //   31505: invokevirtual getBytes : ()[B
    //   31508: iconst_0
    //   31509: invokespecial <init> : ([BI)V
    //   31512: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31517: aload #5
    //   31519: sipush #1495
    //   31522: new org/renjin/gcc/runtime/BytePtr
    //   31525: dup
    //   31526: ldc_w '#FFA500 '
    //   31529: invokevirtual getBytes : ()[B
    //   31532: iconst_0
    //   31533: invokespecial <init> : ([BI)V
    //   31536: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31541: aload #5
    //   31543: sipush #1496
    //   31546: ldc_w -16734721
    //   31549: invokeinterface setAlignedInt : (II)V
    //   31554: aload #5
    //   31556: sipush #1497
    //   31559: new org/renjin/gcc/runtime/BytePtr
    //   31562: dup
    //   31563: ldc_w 'orange2 '
    //   31566: invokevirtual getBytes : ()[B
    //   31569: iconst_0
    //   31570: invokespecial <init> : ([BI)V
    //   31573: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31578: aload #5
    //   31580: sipush #1498
    //   31583: new org/renjin/gcc/runtime/BytePtr
    //   31586: dup
    //   31587: ldc_w '#EE9A00 '
    //   31590: invokevirtual getBytes : ()[B
    //   31593: iconst_0
    //   31594: invokespecial <init> : ([BI)V
    //   31597: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31602: aload #5
    //   31604: sipush #1499
    //   31607: ldc_w -16737554
    //   31610: invokeinterface setAlignedInt : (II)V
    //   31615: aload #5
    //   31617: sipush #1500
    //   31620: new org/renjin/gcc/runtime/BytePtr
    //   31623: dup
    //   31624: ldc_w 'orange3 '
    //   31627: invokevirtual getBytes : ()[B
    //   31630: iconst_0
    //   31631: invokespecial <init> : ([BI)V
    //   31634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31639: aload #5
    //   31641: sipush #1501
    //   31644: new org/renjin/gcc/runtime/BytePtr
    //   31647: dup
    //   31648: ldc_w '#CD8500 '
    //   31651: invokevirtual getBytes : ()[B
    //   31654: iconst_0
    //   31655: invokespecial <init> : ([BI)V
    //   31658: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31663: aload #5
    //   31665: sipush #1502
    //   31668: ldc_w -16742963
    //   31671: invokeinterface setAlignedInt : (II)V
    //   31676: aload #5
    //   31678: sipush #1503
    //   31681: new org/renjin/gcc/runtime/BytePtr
    //   31684: dup
    //   31685: ldc_w 'orange4 '
    //   31688: invokevirtual getBytes : ()[B
    //   31691: iconst_0
    //   31692: invokespecial <init> : ([BI)V
    //   31695: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31700: aload #5
    //   31702: sipush #1504
    //   31705: new org/renjin/gcc/runtime/BytePtr
    //   31708: dup
    //   31709: ldc_w '#8B5A00 '
    //   31712: invokevirtual getBytes : ()[B
    //   31715: iconst_0
    //   31716: invokespecial <init> : ([BI)V
    //   31719: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31724: aload #5
    //   31726: sipush #1505
    //   31729: ldc_w -16754037
    //   31732: invokeinterface setAlignedInt : (II)V
    //   31737: aload #5
    //   31739: sipush #1506
    //   31742: new org/renjin/gcc/runtime/BytePtr
    //   31745: dup
    //   31746: ldc_w 'orangered '
    //   31749: invokevirtual getBytes : ()[B
    //   31752: iconst_0
    //   31753: invokespecial <init> : ([BI)V
    //   31756: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31761: aload #5
    //   31763: sipush #1507
    //   31766: new org/renjin/gcc/runtime/BytePtr
    //   31769: dup
    //   31770: ldc_w '#FF4500 '
    //   31773: invokevirtual getBytes : ()[B
    //   31776: iconst_0
    //   31777: invokespecial <init> : ([BI)V
    //   31780: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31785: aload #5
    //   31787: sipush #1508
    //   31790: ldc_w -16759297
    //   31793: invokeinterface setAlignedInt : (II)V
    //   31798: aload #5
    //   31800: sipush #1509
    //   31803: new org/renjin/gcc/runtime/BytePtr
    //   31806: dup
    //   31807: ldc_w 'orangered1 '
    //   31810: invokevirtual getBytes : ()[B
    //   31813: iconst_0
    //   31814: invokespecial <init> : ([BI)V
    //   31817: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31822: aload #5
    //   31824: sipush #1510
    //   31827: new org/renjin/gcc/runtime/BytePtr
    //   31830: dup
    //   31831: ldc_w '#FF4500 '
    //   31834: invokevirtual getBytes : ()[B
    //   31837: iconst_0
    //   31838: invokespecial <init> : ([BI)V
    //   31841: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31846: aload #5
    //   31848: sipush #1511
    //   31851: ldc_w -16759297
    //   31854: invokeinterface setAlignedInt : (II)V
    //   31859: aload #5
    //   31861: sipush #1512
    //   31864: new org/renjin/gcc/runtime/BytePtr
    //   31867: dup
    //   31868: ldc_w 'orangered2 '
    //   31871: invokevirtual getBytes : ()[B
    //   31874: iconst_0
    //   31875: invokespecial <init> : ([BI)V
    //   31878: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31883: aload #5
    //   31885: sipush #1513
    //   31888: new org/renjin/gcc/runtime/BytePtr
    //   31891: dup
    //   31892: ldc_w '#EE4000 '
    //   31895: invokevirtual getBytes : ()[B
    //   31898: iconst_0
    //   31899: invokespecial <init> : ([BI)V
    //   31902: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31907: aload #5
    //   31909: sipush #1514
    //   31912: ldc_w -16760594
    //   31915: invokeinterface setAlignedInt : (II)V
    //   31920: aload #5
    //   31922: sipush #1515
    //   31925: new org/renjin/gcc/runtime/BytePtr
    //   31928: dup
    //   31929: ldc_w 'orangered3 '
    //   31932: invokevirtual getBytes : ()[B
    //   31935: iconst_0
    //   31936: invokespecial <init> : ([BI)V
    //   31939: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31944: aload #5
    //   31946: sipush #1516
    //   31949: new org/renjin/gcc/runtime/BytePtr
    //   31952: dup
    //   31953: ldc_w '#CD3700 '
    //   31956: invokevirtual getBytes : ()[B
    //   31959: iconst_0
    //   31960: invokespecial <init> : ([BI)V
    //   31963: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   31968: aload #5
    //   31970: sipush #1517
    //   31973: ldc_w -16762931
    //   31976: invokeinterface setAlignedInt : (II)V
    //   31981: aload #5
    //   31983: sipush #1518
    //   31986: new org/renjin/gcc/runtime/BytePtr
    //   31989: dup
    //   31990: ldc_w 'orangered4 '
    //   31993: invokevirtual getBytes : ()[B
    //   31996: iconst_0
    //   31997: invokespecial <init> : ([BI)V
    //   32000: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32005: aload #5
    //   32007: sipush #1519
    //   32010: new org/renjin/gcc/runtime/BytePtr
    //   32013: dup
    //   32014: ldc_w '#8B2500 '
    //   32017: invokevirtual getBytes : ()[B
    //   32020: iconst_0
    //   32021: invokespecial <init> : ([BI)V
    //   32024: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32029: aload #5
    //   32031: sipush #1520
    //   32034: ldc_w -16767605
    //   32037: invokeinterface setAlignedInt : (II)V
    //   32042: aload #5
    //   32044: sipush #1521
    //   32047: new org/renjin/gcc/runtime/BytePtr
    //   32050: dup
    //   32051: ldc_w 'orchid '
    //   32054: invokevirtual getBytes : ()[B
    //   32057: iconst_0
    //   32058: invokespecial <init> : ([BI)V
    //   32061: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32066: aload #5
    //   32068: sipush #1522
    //   32071: new org/renjin/gcc/runtime/BytePtr
    //   32074: dup
    //   32075: ldc_w '#DA70D6 '
    //   32078: invokevirtual getBytes : ()[B
    //   32081: iconst_0
    //   32082: invokespecial <init> : ([BI)V
    //   32085: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32090: aload #5
    //   32092: sipush #1523
    //   32095: ldc_w -2723622
    //   32098: invokeinterface setAlignedInt : (II)V
    //   32103: aload #5
    //   32105: sipush #1524
    //   32108: new org/renjin/gcc/runtime/BytePtr
    //   32111: dup
    //   32112: ldc_w 'orchid1 '
    //   32115: invokevirtual getBytes : ()[B
    //   32118: iconst_0
    //   32119: invokespecial <init> : ([BI)V
    //   32122: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32127: aload #5
    //   32129: sipush #1525
    //   32132: new org/renjin/gcc/runtime/BytePtr
    //   32135: dup
    //   32136: ldc_w '#FF83FA '
    //   32139: invokevirtual getBytes : ()[B
    //   32142: iconst_0
    //   32143: invokespecial <init> : ([BI)V
    //   32146: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32151: aload #5
    //   32153: sipush #1526
    //   32156: ldc_w -359425
    //   32159: invokeinterface setAlignedInt : (II)V
    //   32164: aload #5
    //   32166: sipush #1527
    //   32169: new org/renjin/gcc/runtime/BytePtr
    //   32172: dup
    //   32173: ldc_w 'orchid2 '
    //   32176: invokevirtual getBytes : ()[B
    //   32179: iconst_0
    //   32180: invokespecial <init> : ([BI)V
    //   32183: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32188: aload #5
    //   32190: sipush #1528
    //   32193: new org/renjin/gcc/runtime/BytePtr
    //   32196: dup
    //   32197: ldc_w '#EE7AE9 '
    //   32200: invokevirtual getBytes : ()[B
    //   32203: iconst_0
    //   32204: invokespecial <init> : ([BI)V
    //   32207: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32212: aload #5
    //   32214: sipush #1529
    //   32217: ldc_w -1475858
    //   32220: invokeinterface setAlignedInt : (II)V
    //   32225: aload #5
    //   32227: sipush #1530
    //   32230: new org/renjin/gcc/runtime/BytePtr
    //   32233: dup
    //   32234: ldc_w 'orchid3 '
    //   32237: invokevirtual getBytes : ()[B
    //   32240: iconst_0
    //   32241: invokespecial <init> : ([BI)V
    //   32244: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32249: aload #5
    //   32251: sipush #1531
    //   32254: new org/renjin/gcc/runtime/BytePtr
    //   32257: dup
    //   32258: ldc_w '#CD69C9 '
    //   32261: invokevirtual getBytes : ()[B
    //   32264: iconst_0
    //   32265: invokespecial <init> : ([BI)V
    //   32268: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32273: aload #5
    //   32275: sipush #1532
    //   32278: ldc_w -3577395
    //   32281: invokeinterface setAlignedInt : (II)V
    //   32286: aload #5
    //   32288: sipush #1533
    //   32291: new org/renjin/gcc/runtime/BytePtr
    //   32294: dup
    //   32295: ldc_w 'orchid4 '
    //   32298: invokevirtual getBytes : ()[B
    //   32301: iconst_0
    //   32302: invokespecial <init> : ([BI)V
    //   32305: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32310: aload #5
    //   32312: sipush #1534
    //   32315: new org/renjin/gcc/runtime/BytePtr
    //   32318: dup
    //   32319: ldc_w '#8B4789 '
    //   32322: invokevirtual getBytes : ()[B
    //   32325: iconst_0
    //   32326: invokespecial <init> : ([BI)V
    //   32329: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32334: aload #5
    //   32336: sipush #1535
    //   32339: ldc_w -7780469
    //   32342: invokeinterface setAlignedInt : (II)V
    //   32347: aload #5
    //   32349: sipush #1536
    //   32352: new org/renjin/gcc/runtime/BytePtr
    //   32355: dup
    //   32356: ldc_w 'palegoldenrod '
    //   32359: invokevirtual getBytes : ()[B
    //   32362: iconst_0
    //   32363: invokespecial <init> : ([BI)V
    //   32366: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32371: aload #5
    //   32373: sipush #1537
    //   32376: new org/renjin/gcc/runtime/BytePtr
    //   32379: dup
    //   32380: ldc_w '#EEE8AA '
    //   32383: invokevirtual getBytes : ()[B
    //   32386: iconst_0
    //   32387: invokespecial <init> : ([BI)V
    //   32390: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32395: aload #5
    //   32397: sipush #1538
    //   32400: ldc_w -5576466
    //   32403: invokeinterface setAlignedInt : (II)V
    //   32408: aload #5
    //   32410: sipush #1539
    //   32413: new org/renjin/gcc/runtime/BytePtr
    //   32416: dup
    //   32417: ldc_w 'palegreen '
    //   32420: invokevirtual getBytes : ()[B
    //   32423: iconst_0
    //   32424: invokespecial <init> : ([BI)V
    //   32427: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32432: aload #5
    //   32434: sipush #1540
    //   32437: new org/renjin/gcc/runtime/BytePtr
    //   32440: dup
    //   32441: ldc_w '#98FB98 '
    //   32444: invokevirtual getBytes : ()[B
    //   32447: iconst_0
    //   32448: invokespecial <init> : ([BI)V
    //   32451: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32456: aload #5
    //   32458: sipush #1541
    //   32461: ldc_w -6751336
    //   32464: invokeinterface setAlignedInt : (II)V
    //   32469: aload #5
    //   32471: sipush #1542
    //   32474: new org/renjin/gcc/runtime/BytePtr
    //   32477: dup
    //   32478: ldc_w 'palegreen1 '
    //   32481: invokevirtual getBytes : ()[B
    //   32484: iconst_0
    //   32485: invokespecial <init> : ([BI)V
    //   32488: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32493: aload #5
    //   32495: sipush #1543
    //   32498: new org/renjin/gcc/runtime/BytePtr
    //   32501: dup
    //   32502: ldc_w '#9AFF9A '
    //   32505: invokevirtual getBytes : ()[B
    //   32508: iconst_0
    //   32509: invokespecial <init> : ([BI)V
    //   32512: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32517: aload #5
    //   32519: sipush #1544
    //   32522: ldc_w -6619238
    //   32525: invokeinterface setAlignedInt : (II)V
    //   32530: aload #5
    //   32532: sipush #1545
    //   32535: new org/renjin/gcc/runtime/BytePtr
    //   32538: dup
    //   32539: ldc_w 'palegreen2 '
    //   32542: invokevirtual getBytes : ()[B
    //   32545: iconst_0
    //   32546: invokespecial <init> : ([BI)V
    //   32549: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32554: aload #5
    //   32556: sipush #1546
    //   32559: new org/renjin/gcc/runtime/BytePtr
    //   32562: dup
    //   32563: ldc_w '#90EE90 '
    //   32566: invokevirtual getBytes : ()[B
    //   32569: iconst_0
    //   32570: invokespecial <init> : ([BI)V
    //   32573: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32578: aload #5
    //   32580: sipush #1547
    //   32583: ldc_w -7278960
    //   32586: invokeinterface setAlignedInt : (II)V
    //   32591: aload #5
    //   32593: sipush #1548
    //   32596: new org/renjin/gcc/runtime/BytePtr
    //   32599: dup
    //   32600: ldc_w 'palegreen3 '
    //   32603: invokevirtual getBytes : ()[B
    //   32606: iconst_0
    //   32607: invokespecial <init> : ([BI)V
    //   32610: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32615: aload #5
    //   32617: sipush #1549
    //   32620: new org/renjin/gcc/runtime/BytePtr
    //   32623: dup
    //   32624: ldc_w '#7CCD7C '
    //   32627: invokevirtual getBytes : ()[B
    //   32630: iconst_0
    //   32631: invokespecial <init> : ([BI)V
    //   32634: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32639: aload #5
    //   32641: sipush #1550
    //   32644: ldc_w -8598148
    //   32647: invokeinterface setAlignedInt : (II)V
    //   32652: aload #5
    //   32654: sipush #1551
    //   32657: new org/renjin/gcc/runtime/BytePtr
    //   32660: dup
    //   32661: ldc_w 'palegreen4 '
    //   32664: invokevirtual getBytes : ()[B
    //   32667: iconst_0
    //   32668: invokespecial <init> : ([BI)V
    //   32671: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32676: aload #5
    //   32678: sipush #1552
    //   32681: new org/renjin/gcc/runtime/BytePtr
    //   32684: dup
    //   32685: ldc_w '#548B54 '
    //   32688: invokevirtual getBytes : ()[B
    //   32691: iconst_0
    //   32692: invokespecial <init> : ([BI)V
    //   32695: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32700: aload #5
    //   32702: sipush #1553
    //   32705: ldc_w -11236524
    //   32708: invokeinterface setAlignedInt : (II)V
    //   32713: aload #5
    //   32715: sipush #1554
    //   32718: new org/renjin/gcc/runtime/BytePtr
    //   32721: dup
    //   32722: ldc_w 'paleturquoise '
    //   32725: invokevirtual getBytes : ()[B
    //   32728: iconst_0
    //   32729: invokespecial <init> : ([BI)V
    //   32732: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32737: aload #5
    //   32739: sipush #1555
    //   32742: new org/renjin/gcc/runtime/BytePtr
    //   32745: dup
    //   32746: ldc_w '#AFEEEE '
    //   32749: invokevirtual getBytes : ()[B
    //   32752: iconst_0
    //   32753: invokespecial <init> : ([BI)V
    //   32756: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32761: aload #5
    //   32763: sipush #1556
    //   32766: ldc_w -1118545
    //   32769: invokeinterface setAlignedInt : (II)V
    //   32774: aload #5
    //   32776: sipush #1557
    //   32779: new org/renjin/gcc/runtime/BytePtr
    //   32782: dup
    //   32783: ldc_w 'paleturquoise1 '
    //   32786: invokevirtual getBytes : ()[B
    //   32789: iconst_0
    //   32790: invokespecial <init> : ([BI)V
    //   32793: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32798: aload #5
    //   32800: sipush #1558
    //   32803: new org/renjin/gcc/runtime/BytePtr
    //   32806: dup
    //   32807: ldc_w '#BBFFFF '
    //   32810: invokevirtual getBytes : ()[B
    //   32813: iconst_0
    //   32814: invokespecial <init> : ([BI)V
    //   32817: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32822: aload #5
    //   32824: sipush #1559
    //   32827: bipush #-69
    //   32829: invokeinterface setAlignedInt : (II)V
    //   32834: aload #5
    //   32836: sipush #1560
    //   32839: new org/renjin/gcc/runtime/BytePtr
    //   32842: dup
    //   32843: ldc_w 'paleturquoise2 '
    //   32846: invokevirtual getBytes : ()[B
    //   32849: iconst_0
    //   32850: invokespecial <init> : ([BI)V
    //   32853: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32858: aload #5
    //   32860: sipush #1561
    //   32863: new org/renjin/gcc/runtime/BytePtr
    //   32866: dup
    //   32867: ldc_w '#AEEEEE '
    //   32870: invokevirtual getBytes : ()[B
    //   32873: iconst_0
    //   32874: invokespecial <init> : ([BI)V
    //   32877: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32882: aload #5
    //   32884: sipush #1562
    //   32887: ldc_w -1118546
    //   32890: invokeinterface setAlignedInt : (II)V
    //   32895: aload #5
    //   32897: sipush #1563
    //   32900: new org/renjin/gcc/runtime/BytePtr
    //   32903: dup
    //   32904: ldc_w 'paleturquoise3 '
    //   32907: invokevirtual getBytes : ()[B
    //   32910: iconst_0
    //   32911: invokespecial <init> : ([BI)V
    //   32914: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32919: aload #5
    //   32921: sipush #1564
    //   32924: new org/renjin/gcc/runtime/BytePtr
    //   32927: dup
    //   32928: ldc_w '#96CDCD '
    //   32931: invokevirtual getBytes : ()[B
    //   32934: iconst_0
    //   32935: invokespecial <init> : ([BI)V
    //   32938: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32943: aload #5
    //   32945: sipush #1565
    //   32948: ldc_w -3289706
    //   32951: invokeinterface setAlignedInt : (II)V
    //   32956: aload #5
    //   32958: sipush #1566
    //   32961: new org/renjin/gcc/runtime/BytePtr
    //   32964: dup
    //   32965: ldc_w 'paleturquoise4 '
    //   32968: invokevirtual getBytes : ()[B
    //   32971: iconst_0
    //   32972: invokespecial <init> : ([BI)V
    //   32975: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   32980: aload #5
    //   32982: sipush #1567
    //   32985: new org/renjin/gcc/runtime/BytePtr
    //   32988: dup
    //   32989: ldc_w '#668B8B '
    //   32992: invokevirtual getBytes : ()[B
    //   32995: iconst_0
    //   32996: invokespecial <init> : ([BI)V
    //   32999: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33004: aload #5
    //   33006: sipush #1568
    //   33009: ldc_w -7632026
    //   33012: invokeinterface setAlignedInt : (II)V
    //   33017: aload #5
    //   33019: sipush #1569
    //   33022: new org/renjin/gcc/runtime/BytePtr
    //   33025: dup
    //   33026: ldc_w 'palevioletred '
    //   33029: invokevirtual getBytes : ()[B
    //   33032: iconst_0
    //   33033: invokespecial <init> : ([BI)V
    //   33036: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33041: aload #5
    //   33043: sipush #1570
    //   33046: new org/renjin/gcc/runtime/BytePtr
    //   33049: dup
    //   33050: ldc_w '#DB7093 '
    //   33053: invokevirtual getBytes : ()[B
    //   33056: iconst_0
    //   33057: invokespecial <init> : ([BI)V
    //   33060: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33065: aload #5
    //   33067: sipush #1571
    //   33070: ldc_w -7114533
    //   33073: invokeinterface setAlignedInt : (II)V
    //   33078: aload #5
    //   33080: sipush #1572
    //   33083: new org/renjin/gcc/runtime/BytePtr
    //   33086: dup
    //   33087: ldc_w 'palevioletred1 '
    //   33090: invokevirtual getBytes : ()[B
    //   33093: iconst_0
    //   33094: invokespecial <init> : ([BI)V
    //   33097: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33102: aload #5
    //   33104: sipush #1573
    //   33107: new org/renjin/gcc/runtime/BytePtr
    //   33110: dup
    //   33111: ldc_w '#FF82AB '
    //   33114: invokevirtual getBytes : ()[B
    //   33117: iconst_0
    //   33118: invokespecial <init> : ([BI)V
    //   33121: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33126: aload #5
    //   33128: sipush #1574
    //   33131: ldc_w -5537025
    //   33134: invokeinterface setAlignedInt : (II)V
    //   33139: aload #5
    //   33141: sipush #1575
    //   33144: new org/renjin/gcc/runtime/BytePtr
    //   33147: dup
    //   33148: ldc_w 'palevioletred2 '
    //   33151: invokevirtual getBytes : ()[B
    //   33154: iconst_0
    //   33155: invokespecial <init> : ([BI)V
    //   33158: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33163: aload #5
    //   33165: sipush #1576
    //   33168: new org/renjin/gcc/runtime/BytePtr
    //   33171: dup
    //   33172: ldc_w '#EE799F '
    //   33175: invokevirtual getBytes : ()[B
    //   33178: iconst_0
    //   33179: invokespecial <init> : ([BI)V
    //   33182: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33187: aload #5
    //   33189: sipush #1577
    //   33192: ldc_w -6325778
    //   33195: invokeinterface setAlignedInt : (II)V
    //   33200: aload #5
    //   33202: sipush #1578
    //   33205: new org/renjin/gcc/runtime/BytePtr
    //   33208: dup
    //   33209: ldc_w 'palevioletred3 '
    //   33212: invokevirtual getBytes : ()[B
    //   33215: iconst_0
    //   33216: invokespecial <init> : ([BI)V
    //   33219: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33224: aload #5
    //   33226: sipush #1579
    //   33229: new org/renjin/gcc/runtime/BytePtr
    //   33232: dup
    //   33233: ldc_w '#CD6889 '
    //   33236: invokevirtual getBytes : ()[B
    //   33239: iconst_0
    //   33240: invokespecial <init> : ([BI)V
    //   33243: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33248: aload #5
    //   33250: sipush #1580
    //   33253: ldc_w -7771955
    //   33256: invokeinterface setAlignedInt : (II)V
    //   33261: aload #5
    //   33263: sipush #1581
    //   33266: new org/renjin/gcc/runtime/BytePtr
    //   33269: dup
    //   33270: ldc_w 'palevioletred4 '
    //   33273: invokevirtual getBytes : ()[B
    //   33276: iconst_0
    //   33277: invokespecial <init> : ([BI)V
    //   33280: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33285: aload #5
    //   33287: sipush #1582
    //   33290: new org/renjin/gcc/runtime/BytePtr
    //   33293: dup
    //   33294: ldc_w '#8B475D '
    //   33297: invokevirtual getBytes : ()[B
    //   33300: iconst_0
    //   33301: invokespecial <init> : ([BI)V
    //   33304: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33309: aload #5
    //   33311: sipush #1583
    //   33314: ldc_w -10664053
    //   33317: invokeinterface setAlignedInt : (II)V
    //   33322: aload #5
    //   33324: sipush #1584
    //   33327: new org/renjin/gcc/runtime/BytePtr
    //   33330: dup
    //   33331: ldc_w 'papayawhip '
    //   33334: invokevirtual getBytes : ()[B
    //   33337: iconst_0
    //   33338: invokespecial <init> : ([BI)V
    //   33341: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33346: aload #5
    //   33348: sipush #1585
    //   33351: new org/renjin/gcc/runtime/BytePtr
    //   33354: dup
    //   33355: ldc_w '#FFEFD5 '
    //   33358: invokevirtual getBytes : ()[B
    //   33361: iconst_0
    //   33362: invokespecial <init> : ([BI)V
    //   33365: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33370: aload #5
    //   33372: sipush #1586
    //   33375: ldc_w -2756609
    //   33378: invokeinterface setAlignedInt : (II)V
    //   33383: aload #5
    //   33385: sipush #1587
    //   33388: new org/renjin/gcc/runtime/BytePtr
    //   33391: dup
    //   33392: ldc_w 'peachpuff '
    //   33395: invokevirtual getBytes : ()[B
    //   33398: iconst_0
    //   33399: invokespecial <init> : ([BI)V
    //   33402: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33407: aload #5
    //   33409: sipush #1588
    //   33412: new org/renjin/gcc/runtime/BytePtr
    //   33415: dup
    //   33416: ldc_w '#FFDAB9 '
    //   33419: invokevirtual getBytes : ()[B
    //   33422: iconst_0
    //   33423: invokespecial <init> : ([BI)V
    //   33426: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33431: aload #5
    //   33433: sipush #1589
    //   33436: ldc_w -4596993
    //   33439: invokeinterface setAlignedInt : (II)V
    //   33444: aload #5
    //   33446: sipush #1590
    //   33449: new org/renjin/gcc/runtime/BytePtr
    //   33452: dup
    //   33453: ldc_w 'peachpuff1 '
    //   33456: invokevirtual getBytes : ()[B
    //   33459: iconst_0
    //   33460: invokespecial <init> : ([BI)V
    //   33463: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33468: aload #5
    //   33470: sipush #1591
    //   33473: new org/renjin/gcc/runtime/BytePtr
    //   33476: dup
    //   33477: ldc_w '#FFDAB9 '
    //   33480: invokevirtual getBytes : ()[B
    //   33483: iconst_0
    //   33484: invokespecial <init> : ([BI)V
    //   33487: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33492: aload #5
    //   33494: sipush #1592
    //   33497: ldc_w -4596993
    //   33500: invokeinterface setAlignedInt : (II)V
    //   33505: aload #5
    //   33507: sipush #1593
    //   33510: new org/renjin/gcc/runtime/BytePtr
    //   33513: dup
    //   33514: ldc_w 'peachpuff2 '
    //   33517: invokevirtual getBytes : ()[B
    //   33520: iconst_0
    //   33521: invokespecial <init> : ([BI)V
    //   33524: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33529: aload #5
    //   33531: sipush #1594
    //   33534: new org/renjin/gcc/runtime/BytePtr
    //   33537: dup
    //   33538: ldc_w '#EECBAD '
    //   33541: invokevirtual getBytes : ()[B
    //   33544: iconst_0
    //   33545: invokespecial <init> : ([BI)V
    //   33548: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33553: aload #5
    //   33555: sipush #1595
    //   33558: ldc_w -5387282
    //   33561: invokeinterface setAlignedInt : (II)V
    //   33566: aload #5
    //   33568: sipush #1596
    //   33571: new org/renjin/gcc/runtime/BytePtr
    //   33574: dup
    //   33575: ldc_w 'peachpuff3 '
    //   33578: invokevirtual getBytes : ()[B
    //   33581: iconst_0
    //   33582: invokespecial <init> : ([BI)V
    //   33585: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33590: aload #5
    //   33592: sipush #1597
    //   33595: new org/renjin/gcc/runtime/BytePtr
    //   33598: dup
    //   33599: ldc_w '#CDAF95 '
    //   33602: invokevirtual getBytes : ()[B
    //   33605: iconst_0
    //   33606: invokespecial <init> : ([BI)V
    //   33609: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33614: aload #5
    //   33616: sipush #1598
    //   33619: ldc_w -6967347
    //   33622: invokeinterface setAlignedInt : (II)V
    //   33627: aload #5
    //   33629: sipush #1599
    //   33632: new org/renjin/gcc/runtime/BytePtr
    //   33635: dup
    //   33636: ldc_w 'peachpuff4 '
    //   33639: invokevirtual getBytes : ()[B
    //   33642: iconst_0
    //   33643: invokespecial <init> : ([BI)V
    //   33646: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33651: aload #5
    //   33653: sipush #1600
    //   33656: new org/renjin/gcc/runtime/BytePtr
    //   33659: dup
    //   33660: ldc_w '#8B7765 '
    //   33663: invokevirtual getBytes : ()[B
    //   33666: iconst_0
    //   33667: invokespecial <init> : ([BI)V
    //   33670: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33675: aload #5
    //   33677: sipush #1601
    //   33680: ldc_w -10127477
    //   33683: invokeinterface setAlignedInt : (II)V
    //   33688: aload #5
    //   33690: sipush #1602
    //   33693: new org/renjin/gcc/runtime/BytePtr
    //   33696: dup
    //   33697: ldc_w 'peru '
    //   33700: invokevirtual getBytes : ()[B
    //   33703: iconst_0
    //   33704: invokespecial <init> : ([BI)V
    //   33707: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33712: aload #5
    //   33714: sipush #1603
    //   33717: new org/renjin/gcc/runtime/BytePtr
    //   33720: dup
    //   33721: ldc_w '#CD853F '
    //   33724: invokevirtual getBytes : ()[B
    //   33727: iconst_0
    //   33728: invokespecial <init> : ([BI)V
    //   33731: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33736: aload #5
    //   33738: sipush #1604
    //   33741: ldc_w -12614195
    //   33744: invokeinterface setAlignedInt : (II)V
    //   33749: aload #5
    //   33751: sipush #1605
    //   33754: new org/renjin/gcc/runtime/BytePtr
    //   33757: dup
    //   33758: ldc_w 'pink '
    //   33761: invokevirtual getBytes : ()[B
    //   33764: iconst_0
    //   33765: invokespecial <init> : ([BI)V
    //   33768: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33773: aload #5
    //   33775: sipush #1606
    //   33778: new org/renjin/gcc/runtime/BytePtr
    //   33781: dup
    //   33782: ldc_w '#FFC0CB '
    //   33785: invokevirtual getBytes : ()[B
    //   33788: iconst_0
    //   33789: invokespecial <init> : ([BI)V
    //   33792: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33797: aload #5
    //   33799: sipush #1607
    //   33802: ldc_w -3424001
    //   33805: invokeinterface setAlignedInt : (II)V
    //   33810: aload #5
    //   33812: sipush #1608
    //   33815: new org/renjin/gcc/runtime/BytePtr
    //   33818: dup
    //   33819: ldc_w 'pink1 '
    //   33822: invokevirtual getBytes : ()[B
    //   33825: iconst_0
    //   33826: invokespecial <init> : ([BI)V
    //   33829: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33834: aload #5
    //   33836: sipush #1609
    //   33839: new org/renjin/gcc/runtime/BytePtr
    //   33842: dup
    //   33843: ldc_w '#FFB5C5 '
    //   33846: invokevirtual getBytes : ()[B
    //   33849: iconst_0
    //   33850: invokespecial <init> : ([BI)V
    //   33853: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33858: aload #5
    //   33860: sipush #1610
    //   33863: ldc_w -3820033
    //   33866: invokeinterface setAlignedInt : (II)V
    //   33871: aload #5
    //   33873: sipush #1611
    //   33876: new org/renjin/gcc/runtime/BytePtr
    //   33879: dup
    //   33880: ldc_w 'pink2 '
    //   33883: invokevirtual getBytes : ()[B
    //   33886: iconst_0
    //   33887: invokespecial <init> : ([BI)V
    //   33890: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33895: aload #5
    //   33897: sipush #1612
    //   33900: new org/renjin/gcc/runtime/BytePtr
    //   33903: dup
    //   33904: ldc_w '#EEA9B8 '
    //   33907: invokevirtual getBytes : ()[B
    //   33910: iconst_0
    //   33911: invokespecial <init> : ([BI)V
    //   33914: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33919: aload #5
    //   33921: sipush #1613
    //   33924: ldc_w -4675090
    //   33927: invokeinterface setAlignedInt : (II)V
    //   33932: aload #5
    //   33934: sipush #1614
    //   33937: new org/renjin/gcc/runtime/BytePtr
    //   33940: dup
    //   33941: ldc_w 'pink3 '
    //   33944: invokevirtual getBytes : ()[B
    //   33947: iconst_0
    //   33948: invokespecial <init> : ([BI)V
    //   33951: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33956: aload #5
    //   33958: sipush #1615
    //   33961: new org/renjin/gcc/runtime/BytePtr
    //   33964: dup
    //   33965: ldc_w '#CD919E '
    //   33968: invokevirtual getBytes : ()[B
    //   33971: iconst_0
    //   33972: invokespecial <init> : ([BI)V
    //   33975: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   33980: aload #5
    //   33982: sipush #1616
    //   33985: ldc_w -6385203
    //   33988: invokeinterface setAlignedInt : (II)V
    //   33993: aload #5
    //   33995: sipush #1617
    //   33998: new org/renjin/gcc/runtime/BytePtr
    //   34001: dup
    //   34002: ldc_w 'pink4 '
    //   34005: invokevirtual getBytes : ()[B
    //   34008: iconst_0
    //   34009: invokespecial <init> : ([BI)V
    //   34012: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34017: aload #5
    //   34019: sipush #1618
    //   34022: new org/renjin/gcc/runtime/BytePtr
    //   34025: dup
    //   34026: ldc_w '#8B636C '
    //   34029: invokevirtual getBytes : ()[B
    //   34032: iconst_0
    //   34033: invokespecial <init> : ([BI)V
    //   34036: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34041: aload #5
    //   34043: sipush #1619
    //   34046: ldc_w -9673845
    //   34049: invokeinterface setAlignedInt : (II)V
    //   34054: aload #5
    //   34056: sipush #1620
    //   34059: new org/renjin/gcc/runtime/BytePtr
    //   34062: dup
    //   34063: ldc_w 'plum '
    //   34066: invokevirtual getBytes : ()[B
    //   34069: iconst_0
    //   34070: invokespecial <init> : ([BI)V
    //   34073: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34078: aload #5
    //   34080: sipush #1621
    //   34083: new org/renjin/gcc/runtime/BytePtr
    //   34086: dup
    //   34087: ldc_w '#DDA0DD '
    //   34090: invokevirtual getBytes : ()[B
    //   34093: iconst_0
    //   34094: invokespecial <init> : ([BI)V
    //   34097: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34102: aload #5
    //   34104: sipush #1622
    //   34107: ldc_w -2252579
    //   34110: invokeinterface setAlignedInt : (II)V
    //   34115: aload #5
    //   34117: sipush #1623
    //   34120: new org/renjin/gcc/runtime/BytePtr
    //   34123: dup
    //   34124: ldc_w 'plum1 '
    //   34127: invokevirtual getBytes : ()[B
    //   34130: iconst_0
    //   34131: invokespecial <init> : ([BI)V
    //   34134: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34139: aload #5
    //   34141: sipush #1624
    //   34144: new org/renjin/gcc/runtime/BytePtr
    //   34147: dup
    //   34148: ldc_w '#FFBBFF '
    //   34151: invokevirtual getBytes : ()[B
    //   34154: iconst_0
    //   34155: invokespecial <init> : ([BI)V
    //   34158: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34163: aload #5
    //   34165: sipush #1625
    //   34168: sipush #-17409
    //   34171: invokeinterface setAlignedInt : (II)V
    //   34176: aload #5
    //   34178: sipush #1626
    //   34181: new org/renjin/gcc/runtime/BytePtr
    //   34184: dup
    //   34185: ldc_w 'plum2 '
    //   34188: invokevirtual getBytes : ()[B
    //   34191: iconst_0
    //   34192: invokespecial <init> : ([BI)V
    //   34195: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34200: aload #5
    //   34202: sipush #1627
    //   34205: new org/renjin/gcc/runtime/BytePtr
    //   34208: dup
    //   34209: ldc_w '#EEAEEE '
    //   34212: invokevirtual getBytes : ()[B
    //   34215: iconst_0
    //   34216: invokespecial <init> : ([BI)V
    //   34219: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34224: aload #5
    //   34226: sipush #1628
    //   34229: ldc_w -1134866
    //   34232: invokeinterface setAlignedInt : (II)V
    //   34237: aload #5
    //   34239: sipush #1629
    //   34242: new org/renjin/gcc/runtime/BytePtr
    //   34245: dup
    //   34246: ldc_w 'plum3 '
    //   34249: invokevirtual getBytes : ()[B
    //   34252: iconst_0
    //   34253: invokespecial <init> : ([BI)V
    //   34256: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34261: aload #5
    //   34263: sipush #1630
    //   34266: new org/renjin/gcc/runtime/BytePtr
    //   34269: dup
    //   34270: ldc_w '#CD96CD '
    //   34273: invokevirtual getBytes : ()[B
    //   34276: iconst_0
    //   34277: invokespecial <init> : ([BI)V
    //   34280: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34285: aload #5
    //   34287: sipush #1631
    //   34290: ldc_w -3303731
    //   34293: invokeinterface setAlignedInt : (II)V
    //   34298: aload #5
    //   34300: sipush #1632
    //   34303: new org/renjin/gcc/runtime/BytePtr
    //   34306: dup
    //   34307: ldc_w 'plum4 '
    //   34310: invokevirtual getBytes : ()[B
    //   34313: iconst_0
    //   34314: invokespecial <init> : ([BI)V
    //   34317: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34322: aload #5
    //   34324: sipush #1633
    //   34327: new org/renjin/gcc/runtime/BytePtr
    //   34330: dup
    //   34331: ldc_w '#8B668B '
    //   34334: invokevirtual getBytes : ()[B
    //   34337: iconst_0
    //   34338: invokespecial <init> : ([BI)V
    //   34341: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34346: aload #5
    //   34348: sipush #1634
    //   34351: ldc_w -7641461
    //   34354: invokeinterface setAlignedInt : (II)V
    //   34359: aload #5
    //   34361: sipush #1635
    //   34364: new org/renjin/gcc/runtime/BytePtr
    //   34367: dup
    //   34368: ldc_w 'powderblue '
    //   34371: invokevirtual getBytes : ()[B
    //   34374: iconst_0
    //   34375: invokespecial <init> : ([BI)V
    //   34378: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34383: aload #5
    //   34385: sipush #1636
    //   34388: new org/renjin/gcc/runtime/BytePtr
    //   34391: dup
    //   34392: ldc_w '#B0E0E6 '
    //   34395: invokevirtual getBytes : ()[B
    //   34398: iconst_0
    //   34399: invokespecial <init> : ([BI)V
    //   34402: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34407: aload #5
    //   34409: sipush #1637
    //   34412: ldc_w -1646416
    //   34415: invokeinterface setAlignedInt : (II)V
    //   34420: aload #5
    //   34422: sipush #1638
    //   34425: new org/renjin/gcc/runtime/BytePtr
    //   34428: dup
    //   34429: ldc_w 'purple '
    //   34432: invokevirtual getBytes : ()[B
    //   34435: iconst_0
    //   34436: invokespecial <init> : ([BI)V
    //   34439: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34444: aload #5
    //   34446: sipush #1639
    //   34449: new org/renjin/gcc/runtime/BytePtr
    //   34452: dup
    //   34453: ldc_w '#A020F0 '
    //   34456: invokevirtual getBytes : ()[B
    //   34459: iconst_0
    //   34460: invokespecial <init> : ([BI)V
    //   34463: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34468: aload #5
    //   34470: sipush #1640
    //   34473: ldc_w -1040224
    //   34476: invokeinterface setAlignedInt : (II)V
    //   34481: aload #5
    //   34483: sipush #1641
    //   34486: new org/renjin/gcc/runtime/BytePtr
    //   34489: dup
    //   34490: ldc_w 'purple1 '
    //   34493: invokevirtual getBytes : ()[B
    //   34496: iconst_0
    //   34497: invokespecial <init> : ([BI)V
    //   34500: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34505: aload #5
    //   34507: sipush #1642
    //   34510: new org/renjin/gcc/runtime/BytePtr
    //   34513: dup
    //   34514: ldc_w '#9B30FF '
    //   34517: invokevirtual getBytes : ()[B
    //   34520: iconst_0
    //   34521: invokespecial <init> : ([BI)V
    //   34524: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34529: aload #5
    //   34531: sipush #1643
    //   34534: ldc_w -53093
    //   34537: invokeinterface setAlignedInt : (II)V
    //   34542: aload #5
    //   34544: sipush #1644
    //   34547: new org/renjin/gcc/runtime/BytePtr
    //   34550: dup
    //   34551: ldc_w 'purple2 '
    //   34554: invokevirtual getBytes : ()[B
    //   34557: iconst_0
    //   34558: invokespecial <init> : ([BI)V
    //   34561: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34566: aload #5
    //   34568: sipush #1645
    //   34571: new org/renjin/gcc/runtime/BytePtr
    //   34574: dup
    //   34575: ldc_w '#912CEE '
    //   34578: invokevirtual getBytes : ()[B
    //   34581: iconst_0
    //   34582: invokespecial <init> : ([BI)V
    //   34585: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34590: aload #5
    //   34592: sipush #1646
    //   34595: ldc_w -1168239
    //   34598: invokeinterface setAlignedInt : (II)V
    //   34603: aload #5
    //   34605: sipush #1647
    //   34608: new org/renjin/gcc/runtime/BytePtr
    //   34611: dup
    //   34612: ldc_w 'purple3 '
    //   34615: invokevirtual getBytes : ()[B
    //   34618: iconst_0
    //   34619: invokespecial <init> : ([BI)V
    //   34622: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34627: aload #5
    //   34629: sipush #1648
    //   34632: new org/renjin/gcc/runtime/BytePtr
    //   34635: dup
    //   34636: ldc_w '#7D26CD '
    //   34639: invokevirtual getBytes : ()[B
    //   34642: iconst_0
    //   34643: invokespecial <init> : ([BI)V
    //   34646: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34651: aload #5
    //   34653: sipush #1649
    //   34656: ldc_w -3332483
    //   34659: invokeinterface setAlignedInt : (II)V
    //   34664: aload #5
    //   34666: sipush #1650
    //   34669: new org/renjin/gcc/runtime/BytePtr
    //   34672: dup
    //   34673: ldc_w 'purple4 '
    //   34676: invokevirtual getBytes : ()[B
    //   34679: iconst_0
    //   34680: invokespecial <init> : ([BI)V
    //   34683: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34688: aload #5
    //   34690: sipush #1651
    //   34693: new org/renjin/gcc/runtime/BytePtr
    //   34696: dup
    //   34697: ldc_w '#551A8B '
    //   34700: invokevirtual getBytes : ()[B
    //   34703: iconst_0
    //   34704: invokespecial <init> : ([BI)V
    //   34707: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34712: aload #5
    //   34714: sipush #1652
    //   34717: ldc_w -7660971
    //   34720: invokeinterface setAlignedInt : (II)V
    //   34725: aload #5
    //   34727: sipush #1653
    //   34730: new org/renjin/gcc/runtime/BytePtr
    //   34733: dup
    //   34734: ldc_w 'red '
    //   34737: invokevirtual getBytes : ()[B
    //   34740: iconst_0
    //   34741: invokespecial <init> : ([BI)V
    //   34744: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34749: aload #5
    //   34751: sipush #1654
    //   34754: new org/renjin/gcc/runtime/BytePtr
    //   34757: dup
    //   34758: ldc_w '#FF0000 '
    //   34761: invokevirtual getBytes : ()[B
    //   34764: iconst_0
    //   34765: invokespecial <init> : ([BI)V
    //   34768: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34773: aload #5
    //   34775: sipush #1655
    //   34778: ldc_w -16776961
    //   34781: invokeinterface setAlignedInt : (II)V
    //   34786: aload #5
    //   34788: sipush #1656
    //   34791: new org/renjin/gcc/runtime/BytePtr
    //   34794: dup
    //   34795: ldc_w 'red1 '
    //   34798: invokevirtual getBytes : ()[B
    //   34801: iconst_0
    //   34802: invokespecial <init> : ([BI)V
    //   34805: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34810: aload #5
    //   34812: sipush #1657
    //   34815: new org/renjin/gcc/runtime/BytePtr
    //   34818: dup
    //   34819: ldc_w '#FF0000 '
    //   34822: invokevirtual getBytes : ()[B
    //   34825: iconst_0
    //   34826: invokespecial <init> : ([BI)V
    //   34829: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34834: aload #5
    //   34836: sipush #1658
    //   34839: ldc_w -16776961
    //   34842: invokeinterface setAlignedInt : (II)V
    //   34847: aload #5
    //   34849: sipush #1659
    //   34852: new org/renjin/gcc/runtime/BytePtr
    //   34855: dup
    //   34856: ldc_w 'red2 '
    //   34859: invokevirtual getBytes : ()[B
    //   34862: iconst_0
    //   34863: invokespecial <init> : ([BI)V
    //   34866: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34871: aload #5
    //   34873: sipush #1660
    //   34876: new org/renjin/gcc/runtime/BytePtr
    //   34879: dup
    //   34880: ldc_w '#EE0000 '
    //   34883: invokevirtual getBytes : ()[B
    //   34886: iconst_0
    //   34887: invokespecial <init> : ([BI)V
    //   34890: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34895: aload #5
    //   34897: sipush #1661
    //   34900: ldc_w -16776978
    //   34903: invokeinterface setAlignedInt : (II)V
    //   34908: aload #5
    //   34910: sipush #1662
    //   34913: new org/renjin/gcc/runtime/BytePtr
    //   34916: dup
    //   34917: ldc_w 'red3 '
    //   34920: invokevirtual getBytes : ()[B
    //   34923: iconst_0
    //   34924: invokespecial <init> : ([BI)V
    //   34927: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34932: aload #5
    //   34934: sipush #1663
    //   34937: new org/renjin/gcc/runtime/BytePtr
    //   34940: dup
    //   34941: ldc_w '#CD0000 '
    //   34944: invokevirtual getBytes : ()[B
    //   34947: iconst_0
    //   34948: invokespecial <init> : ([BI)V
    //   34951: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34956: aload #5
    //   34958: sipush #1664
    //   34961: ldc_w -16777011
    //   34964: invokeinterface setAlignedInt : (II)V
    //   34969: aload #5
    //   34971: sipush #1665
    //   34974: new org/renjin/gcc/runtime/BytePtr
    //   34977: dup
    //   34978: ldc_w 'red4 '
    //   34981: invokevirtual getBytes : ()[B
    //   34984: iconst_0
    //   34985: invokespecial <init> : ([BI)V
    //   34988: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   34993: aload #5
    //   34995: sipush #1666
    //   34998: new org/renjin/gcc/runtime/BytePtr
    //   35001: dup
    //   35002: ldc_w '#8B0000 '
    //   35005: invokevirtual getBytes : ()[B
    //   35008: iconst_0
    //   35009: invokespecial <init> : ([BI)V
    //   35012: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35017: aload #5
    //   35019: sipush #1667
    //   35022: ldc_w -16777077
    //   35025: invokeinterface setAlignedInt : (II)V
    //   35030: aload #5
    //   35032: sipush #1668
    //   35035: new org/renjin/gcc/runtime/BytePtr
    //   35038: dup
    //   35039: ldc_w 'rosybrown '
    //   35042: invokevirtual getBytes : ()[B
    //   35045: iconst_0
    //   35046: invokespecial <init> : ([BI)V
    //   35049: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35054: aload #5
    //   35056: sipush #1669
    //   35059: new org/renjin/gcc/runtime/BytePtr
    //   35062: dup
    //   35063: ldc_w '#BC8F8F '
    //   35066: invokevirtual getBytes : ()[B
    //   35069: iconst_0
    //   35070: invokespecial <init> : ([BI)V
    //   35073: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35078: aload #5
    //   35080: sipush #1670
    //   35083: ldc_w -7368772
    //   35086: invokeinterface setAlignedInt : (II)V
    //   35091: aload #5
    //   35093: sipush #1671
    //   35096: new org/renjin/gcc/runtime/BytePtr
    //   35099: dup
    //   35100: ldc_w 'rosybrown1 '
    //   35103: invokevirtual getBytes : ()[B
    //   35106: iconst_0
    //   35107: invokespecial <init> : ([BI)V
    //   35110: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35115: aload #5
    //   35117: sipush #1672
    //   35120: new org/renjin/gcc/runtime/BytePtr
    //   35123: dup
    //   35124: ldc_w '#FFC1C1 '
    //   35127: invokevirtual getBytes : ()[B
    //   35130: iconst_0
    //   35131: invokespecial <init> : ([BI)V
    //   35134: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35139: aload #5
    //   35141: sipush #1673
    //   35144: ldc_w -4079105
    //   35147: invokeinterface setAlignedInt : (II)V
    //   35152: aload #5
    //   35154: sipush #1674
    //   35157: new org/renjin/gcc/runtime/BytePtr
    //   35160: dup
    //   35161: ldc_w 'rosybrown2 '
    //   35164: invokevirtual getBytes : ()[B
    //   35167: iconst_0
    //   35168: invokespecial <init> : ([BI)V
    //   35171: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35176: aload #5
    //   35178: sipush #1675
    //   35181: new org/renjin/gcc/runtime/BytePtr
    //   35184: dup
    //   35185: ldc_w '#EEB4B4 '
    //   35188: invokevirtual getBytes : ()[B
    //   35191: iconst_0
    //   35192: invokespecial <init> : ([BI)V
    //   35195: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35200: aload #5
    //   35202: sipush #1676
    //   35205: ldc_w -4934418
    //   35208: invokeinterface setAlignedInt : (II)V
    //   35213: aload #5
    //   35215: sipush #1677
    //   35218: new org/renjin/gcc/runtime/BytePtr
    //   35221: dup
    //   35222: ldc_w 'rosybrown3 '
    //   35225: invokevirtual getBytes : ()[B
    //   35228: iconst_0
    //   35229: invokespecial <init> : ([BI)V
    //   35232: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35237: aload #5
    //   35239: sipush #1678
    //   35242: new org/renjin/gcc/runtime/BytePtr
    //   35245: dup
    //   35246: ldc_w '#CD9B9B '
    //   35249: invokevirtual getBytes : ()[B
    //   35252: iconst_0
    //   35253: invokespecial <init> : ([BI)V
    //   35256: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35261: aload #5
    //   35263: sipush #1679
    //   35266: ldc_w -6579251
    //   35269: invokeinterface setAlignedInt : (II)V
    //   35274: aload #5
    //   35276: sipush #1680
    //   35279: new org/renjin/gcc/runtime/BytePtr
    //   35282: dup
    //   35283: ldc_w 'rosybrown4 '
    //   35286: invokevirtual getBytes : ()[B
    //   35289: iconst_0
    //   35290: invokespecial <init> : ([BI)V
    //   35293: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35298: aload #5
    //   35300: sipush #1681
    //   35303: new org/renjin/gcc/runtime/BytePtr
    //   35306: dup
    //   35307: ldc_w '#8B6969 '
    //   35310: invokevirtual getBytes : ()[B
    //   35313: iconst_0
    //   35314: invokespecial <init> : ([BI)V
    //   35317: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35322: aload #5
    //   35324: sipush #1682
    //   35327: ldc_w -9868917
    //   35330: invokeinterface setAlignedInt : (II)V
    //   35335: aload #5
    //   35337: sipush #1683
    //   35340: new org/renjin/gcc/runtime/BytePtr
    //   35343: dup
    //   35344: ldc_w 'royalblue '
    //   35347: invokevirtual getBytes : ()[B
    //   35350: iconst_0
    //   35351: invokespecial <init> : ([BI)V
    //   35354: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35359: aload #5
    //   35361: sipush #1684
    //   35364: new org/renjin/gcc/runtime/BytePtr
    //   35367: dup
    //   35368: ldc_w '#4169E1 '
    //   35371: invokevirtual getBytes : ()[B
    //   35374: iconst_0
    //   35375: invokespecial <init> : ([BI)V
    //   35378: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35383: aload #5
    //   35385: sipush #1685
    //   35388: ldc_w -2004671
    //   35391: invokeinterface setAlignedInt : (II)V
    //   35396: aload #5
    //   35398: sipush #1686
    //   35401: new org/renjin/gcc/runtime/BytePtr
    //   35404: dup
    //   35405: ldc_w 'royalblue1 '
    //   35408: invokevirtual getBytes : ()[B
    //   35411: iconst_0
    //   35412: invokespecial <init> : ([BI)V
    //   35415: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35420: aload #5
    //   35422: sipush #1687
    //   35425: new org/renjin/gcc/runtime/BytePtr
    //   35428: dup
    //   35429: ldc_w '#4876FF '
    //   35432: invokevirtual getBytes : ()[B
    //   35435: iconst_0
    //   35436: invokespecial <init> : ([BI)V
    //   35439: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35444: aload #5
    //   35446: sipush #1688
    //   35449: ldc_w -35256
    //   35452: invokeinterface setAlignedInt : (II)V
    //   35457: aload #5
    //   35459: sipush #1689
    //   35462: new org/renjin/gcc/runtime/BytePtr
    //   35465: dup
    //   35466: ldc_w 'royalblue2 '
    //   35469: invokevirtual getBytes : ()[B
    //   35472: iconst_0
    //   35473: invokespecial <init> : ([BI)V
    //   35476: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35481: aload #5
    //   35483: sipush #1690
    //   35486: new org/renjin/gcc/runtime/BytePtr
    //   35489: dup
    //   35490: ldc_w '#436EEE '
    //   35493: invokevirtual getBytes : ()[B
    //   35496: iconst_0
    //   35497: invokespecial <init> : ([BI)V
    //   35500: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35505: aload #5
    //   35507: sipush #1691
    //   35510: ldc_w -1151421
    //   35513: invokeinterface setAlignedInt : (II)V
    //   35518: aload #5
    //   35520: sipush #1692
    //   35523: new org/renjin/gcc/runtime/BytePtr
    //   35526: dup
    //   35527: ldc_w 'royalblue3 '
    //   35530: invokevirtual getBytes : ()[B
    //   35533: iconst_0
    //   35534: invokespecial <init> : ([BI)V
    //   35537: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35542: aload #5
    //   35544: sipush #1693
    //   35547: new org/renjin/gcc/runtime/BytePtr
    //   35550: dup
    //   35551: ldc_w '#3A5FCD '
    //   35554: invokevirtual getBytes : ()[B
    //   35557: iconst_0
    //   35558: invokespecial <init> : ([BI)V
    //   35561: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35566: aload #5
    //   35568: sipush #1694
    //   35571: ldc_w -3317958
    //   35574: invokeinterface setAlignedInt : (II)V
    //   35579: aload #5
    //   35581: sipush #1695
    //   35584: new org/renjin/gcc/runtime/BytePtr
    //   35587: dup
    //   35588: ldc_w 'royalblue4 '
    //   35591: invokevirtual getBytes : ()[B
    //   35594: iconst_0
    //   35595: invokespecial <init> : ([BI)V
    //   35598: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35603: aload #5
    //   35605: sipush #1696
    //   35608: new org/renjin/gcc/runtime/BytePtr
    //   35611: dup
    //   35612: ldc_w '#27408B '
    //   35615: invokevirtual getBytes : ()[B
    //   35618: iconst_0
    //   35619: invokespecial <init> : ([BI)V
    //   35622: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35627: aload #5
    //   35629: sipush #1697
    //   35632: ldc_w -7651289
    //   35635: invokeinterface setAlignedInt : (II)V
    //   35640: aload #5
    //   35642: sipush #1698
    //   35645: new org/renjin/gcc/runtime/BytePtr
    //   35648: dup
    //   35649: ldc_w 'saddlebrown '
    //   35652: invokevirtual getBytes : ()[B
    //   35655: iconst_0
    //   35656: invokespecial <init> : ([BI)V
    //   35659: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35664: aload #5
    //   35666: sipush #1699
    //   35669: new org/renjin/gcc/runtime/BytePtr
    //   35672: dup
    //   35673: ldc_w '#8B4513 '
    //   35676: invokevirtual getBytes : ()[B
    //   35679: iconst_0
    //   35680: invokespecial <init> : ([BI)V
    //   35683: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35688: aload #5
    //   35690: sipush #1700
    //   35693: ldc_w -15514229
    //   35696: invokeinterface setAlignedInt : (II)V
    //   35701: aload #5
    //   35703: sipush #1701
    //   35706: new org/renjin/gcc/runtime/BytePtr
    //   35709: dup
    //   35710: ldc_w 'salmon '
    //   35713: invokevirtual getBytes : ()[B
    //   35716: iconst_0
    //   35717: invokespecial <init> : ([BI)V
    //   35720: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35725: aload #5
    //   35727: sipush #1702
    //   35730: new org/renjin/gcc/runtime/BytePtr
    //   35733: dup
    //   35734: ldc_w '#FA8072 '
    //   35737: invokevirtual getBytes : ()[B
    //   35740: iconst_0
    //   35741: invokespecial <init> : ([BI)V
    //   35744: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35749: aload #5
    //   35751: sipush #1703
    //   35754: ldc_w -9273094
    //   35757: invokeinterface setAlignedInt : (II)V
    //   35762: aload #5
    //   35764: sipush #1704
    //   35767: new org/renjin/gcc/runtime/BytePtr
    //   35770: dup
    //   35771: ldc_w 'salmon1 '
    //   35774: invokevirtual getBytes : ()[B
    //   35777: iconst_0
    //   35778: invokespecial <init> : ([BI)V
    //   35781: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35786: aload #5
    //   35788: sipush #1705
    //   35791: new org/renjin/gcc/runtime/BytePtr
    //   35794: dup
    //   35795: ldc_w '#FF8C69 '
    //   35798: invokevirtual getBytes : ()[B
    //   35801: iconst_0
    //   35802: invokespecial <init> : ([BI)V
    //   35805: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35810: aload #5
    //   35812: sipush #1706
    //   35815: ldc_w -9859841
    //   35818: invokeinterface setAlignedInt : (II)V
    //   35823: aload #5
    //   35825: sipush #1707
    //   35828: new org/renjin/gcc/runtime/BytePtr
    //   35831: dup
    //   35832: ldc_w 'salmon2 '
    //   35835: invokevirtual getBytes : ()[B
    //   35838: iconst_0
    //   35839: invokespecial <init> : ([BI)V
    //   35842: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35847: aload #5
    //   35849: sipush #1708
    //   35852: new org/renjin/gcc/runtime/BytePtr
    //   35855: dup
    //   35856: ldc_w '#EE8262 '
    //   35859: invokevirtual getBytes : ()[B
    //   35862: iconst_0
    //   35863: invokespecial <init> : ([BI)V
    //   35866: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35871: aload #5
    //   35873: sipush #1709
    //   35876: ldc_w -10321170
    //   35879: invokeinterface setAlignedInt : (II)V
    //   35884: aload #5
    //   35886: sipush #1710
    //   35889: new org/renjin/gcc/runtime/BytePtr
    //   35892: dup
    //   35893: ldc_w 'salmon3 '
    //   35896: invokevirtual getBytes : ()[B
    //   35899: iconst_0
    //   35900: invokespecial <init> : ([BI)V
    //   35903: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35908: aload #5
    //   35910: sipush #1711
    //   35913: new org/renjin/gcc/runtime/BytePtr
    //   35916: dup
    //   35917: ldc_w '#CD7054 '
    //   35920: invokevirtual getBytes : ()[B
    //   35923: iconst_0
    //   35924: invokespecial <init> : ([BI)V
    //   35927: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35932: aload #5
    //   35934: sipush #1712
    //   35937: ldc_w -11243315
    //   35940: invokeinterface setAlignedInt : (II)V
    //   35945: aload #5
    //   35947: sipush #1713
    //   35950: new org/renjin/gcc/runtime/BytePtr
    //   35953: dup
    //   35954: ldc_w 'salmon4 '
    //   35957: invokevirtual getBytes : ()[B
    //   35960: iconst_0
    //   35961: invokespecial <init> : ([BI)V
    //   35964: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35969: aload #5
    //   35971: sipush #1714
    //   35974: new org/renjin/gcc/runtime/BytePtr
    //   35977: dup
    //   35978: ldc_w '#8B4C39 '
    //   35981: invokevirtual getBytes : ()[B
    //   35984: iconst_0
    //   35985: invokespecial <init> : ([BI)V
    //   35988: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   35993: aload #5
    //   35995: sipush #1715
    //   35998: ldc_w -13022069
    //   36001: invokeinterface setAlignedInt : (II)V
    //   36006: aload #5
    //   36008: sipush #1716
    //   36011: new org/renjin/gcc/runtime/BytePtr
    //   36014: dup
    //   36015: ldc_w 'sandybrown '
    //   36018: invokevirtual getBytes : ()[B
    //   36021: iconst_0
    //   36022: invokespecial <init> : ([BI)V
    //   36025: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36030: aload #5
    //   36032: sipush #1717
    //   36035: new org/renjin/gcc/runtime/BytePtr
    //   36038: dup
    //   36039: ldc_w '#F4A460 '
    //   36042: invokevirtual getBytes : ()[B
    //   36045: iconst_0
    //   36046: invokespecial <init> : ([BI)V
    //   36049: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36054: aload #5
    //   36056: sipush #1718
    //   36059: ldc_w -10443532
    //   36062: invokeinterface setAlignedInt : (II)V
    //   36067: aload #5
    //   36069: sipush #1719
    //   36072: new org/renjin/gcc/runtime/BytePtr
    //   36075: dup
    //   36076: ldc_w 'seagreen '
    //   36079: invokevirtual getBytes : ()[B
    //   36082: iconst_0
    //   36083: invokespecial <init> : ([BI)V
    //   36086: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36091: aload #5
    //   36093: sipush #1720
    //   36096: new org/renjin/gcc/runtime/BytePtr
    //   36099: dup
    //   36100: ldc_w '#2E8B57 '
    //   36103: invokevirtual getBytes : ()[B
    //   36106: iconst_0
    //   36107: invokespecial <init> : ([BI)V
    //   36110: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36115: aload #5
    //   36117: sipush #1721
    //   36120: ldc_w -11039954
    //   36123: invokeinterface setAlignedInt : (II)V
    //   36128: aload #5
    //   36130: sipush #1722
    //   36133: new org/renjin/gcc/runtime/BytePtr
    //   36136: dup
    //   36137: ldc_w 'seagreen1 '
    //   36140: invokevirtual getBytes : ()[B
    //   36143: iconst_0
    //   36144: invokespecial <init> : ([BI)V
    //   36147: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36152: aload #5
    //   36154: sipush #1723
    //   36157: new org/renjin/gcc/runtime/BytePtr
    //   36160: dup
    //   36161: ldc_w '#54FF9F '
    //   36164: invokevirtual getBytes : ()[B
    //   36167: iconst_0
    //   36168: invokespecial <init> : ([BI)V
    //   36171: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36176: aload #5
    //   36178: sipush #1724
    //   36181: ldc_w -6291628
    //   36184: invokeinterface setAlignedInt : (II)V
    //   36189: aload #5
    //   36191: sipush #1725
    //   36194: new org/renjin/gcc/runtime/BytePtr
    //   36197: dup
    //   36198: ldc_w 'seagreen2 '
    //   36201: invokevirtual getBytes : ()[B
    //   36204: iconst_0
    //   36205: invokespecial <init> : ([BI)V
    //   36208: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36213: aload #5
    //   36215: sipush #1726
    //   36218: new org/renjin/gcc/runtime/BytePtr
    //   36221: dup
    //   36222: ldc_w '#4EEE94 '
    //   36225: invokevirtual getBytes : ()[B
    //   36228: iconst_0
    //   36229: invokespecial <init> : ([BI)V
    //   36232: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36237: aload #5
    //   36239: sipush #1727
    //   36242: ldc_w -7016882
    //   36245: invokeinterface setAlignedInt : (II)V
    //   36250: aload #5
    //   36252: sipush #1728
    //   36255: new org/renjin/gcc/runtime/BytePtr
    //   36258: dup
    //   36259: ldc_w 'seagreen3 '
    //   36262: invokevirtual getBytes : ()[B
    //   36265: iconst_0
    //   36266: invokespecial <init> : ([BI)V
    //   36269: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36274: aload #5
    //   36276: sipush #1729
    //   36279: new org/renjin/gcc/runtime/BytePtr
    //   36282: dup
    //   36283: ldc_w '#43CD80 '
    //   36286: invokevirtual getBytes : ()[B
    //   36289: iconst_0
    //   36290: invokespecial <init> : ([BI)V
    //   36293: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36298: aload #5
    //   36300: sipush #1730
    //   36303: ldc_w -8336061
    //   36306: invokeinterface setAlignedInt : (II)V
    //   36311: aload #5
    //   36313: sipush #1731
    //   36316: new org/renjin/gcc/runtime/BytePtr
    //   36319: dup
    //   36320: ldc_w 'seagreen4 '
    //   36323: invokevirtual getBytes : ()[B
    //   36326: iconst_0
    //   36327: invokespecial <init> : ([BI)V
    //   36330: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36335: aload #5
    //   36337: sipush #1732
    //   36340: new org/renjin/gcc/runtime/BytePtr
    //   36343: dup
    //   36344: ldc_w '#2E8B57 '
    //   36347: invokevirtual getBytes : ()[B
    //   36350: iconst_0
    //   36351: invokespecial <init> : ([BI)V
    //   36354: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36359: aload #5
    //   36361: sipush #1733
    //   36364: ldc_w -11039954
    //   36367: invokeinterface setAlignedInt : (II)V
    //   36372: aload #5
    //   36374: sipush #1734
    //   36377: new org/renjin/gcc/runtime/BytePtr
    //   36380: dup
    //   36381: ldc_w 'seashell '
    //   36384: invokevirtual getBytes : ()[B
    //   36387: iconst_0
    //   36388: invokespecial <init> : ([BI)V
    //   36391: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36396: aload #5
    //   36398: sipush #1735
    //   36401: new org/renjin/gcc/runtime/BytePtr
    //   36404: dup
    //   36405: ldc_w '#FFF5EE '
    //   36408: invokevirtual getBytes : ()[B
    //   36411: iconst_0
    //   36412: invokespecial <init> : ([BI)V
    //   36415: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36420: aload #5
    //   36422: sipush #1736
    //   36425: ldc_w -1116673
    //   36428: invokeinterface setAlignedInt : (II)V
    //   36433: aload #5
    //   36435: sipush #1737
    //   36438: new org/renjin/gcc/runtime/BytePtr
    //   36441: dup
    //   36442: ldc_w 'seashell1 '
    //   36445: invokevirtual getBytes : ()[B
    //   36448: iconst_0
    //   36449: invokespecial <init> : ([BI)V
    //   36452: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36457: aload #5
    //   36459: sipush #1738
    //   36462: new org/renjin/gcc/runtime/BytePtr
    //   36465: dup
    //   36466: ldc_w '#FFF5EE '
    //   36469: invokevirtual getBytes : ()[B
    //   36472: iconst_0
    //   36473: invokespecial <init> : ([BI)V
    //   36476: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36481: aload #5
    //   36483: sipush #1739
    //   36486: ldc_w -1116673
    //   36489: invokeinterface setAlignedInt : (II)V
    //   36494: aload #5
    //   36496: sipush #1740
    //   36499: new org/renjin/gcc/runtime/BytePtr
    //   36502: dup
    //   36503: ldc_w 'seashell2 '
    //   36506: invokevirtual getBytes : ()[B
    //   36509: iconst_0
    //   36510: invokespecial <init> : ([BI)V
    //   36513: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36518: aload #5
    //   36520: sipush #1741
    //   36523: new org/renjin/gcc/runtime/BytePtr
    //   36526: dup
    //   36527: ldc_w '#EEE5DE '
    //   36530: invokevirtual getBytes : ()[B
    //   36533: iconst_0
    //   36534: invokespecial <init> : ([BI)V
    //   36537: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36542: aload #5
    //   36544: sipush #1742
    //   36547: ldc_w -2169362
    //   36550: invokeinterface setAlignedInt : (II)V
    //   36555: aload #5
    //   36557: sipush #1743
    //   36560: new org/renjin/gcc/runtime/BytePtr
    //   36563: dup
    //   36564: ldc_w 'seashell3 '
    //   36567: invokevirtual getBytes : ()[B
    //   36570: iconst_0
    //   36571: invokespecial <init> : ([BI)V
    //   36574: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36579: aload #5
    //   36581: sipush #1744
    //   36584: new org/renjin/gcc/runtime/BytePtr
    //   36587: dup
    //   36588: ldc_w '#CDC5BF '
    //   36591: invokevirtual getBytes : ()[B
    //   36594: iconst_0
    //   36595: invokespecial <init> : ([BI)V
    //   36598: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36603: aload #5
    //   36605: sipush #1745
    //   36608: ldc_w -4209203
    //   36611: invokeinterface setAlignedInt : (II)V
    //   36616: aload #5
    //   36618: sipush #1746
    //   36621: new org/renjin/gcc/runtime/BytePtr
    //   36624: dup
    //   36625: ldc_w 'seashell4 '
    //   36628: invokevirtual getBytes : ()[B
    //   36631: iconst_0
    //   36632: invokespecial <init> : ([BI)V
    //   36635: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36640: aload #5
    //   36642: sipush #1747
    //   36645: new org/renjin/gcc/runtime/BytePtr
    //   36648: dup
    //   36649: ldc_w '#8B8682 '
    //   36652: invokevirtual getBytes : ()[B
    //   36655: iconst_0
    //   36656: invokespecial <init> : ([BI)V
    //   36659: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36664: aload #5
    //   36666: sipush #1748
    //   36669: ldc_w -8223093
    //   36672: invokeinterface setAlignedInt : (II)V
    //   36677: aload #5
    //   36679: sipush #1749
    //   36682: new org/renjin/gcc/runtime/BytePtr
    //   36685: dup
    //   36686: ldc_w 'sienna '
    //   36689: invokevirtual getBytes : ()[B
    //   36692: iconst_0
    //   36693: invokespecial <init> : ([BI)V
    //   36696: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36701: aload #5
    //   36703: sipush #1750
    //   36706: new org/renjin/gcc/runtime/BytePtr
    //   36709: dup
    //   36710: ldc_w '#A0522D '
    //   36713: invokevirtual getBytes : ()[B
    //   36716: iconst_0
    //   36717: invokespecial <init> : ([BI)V
    //   36720: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36725: aload #5
    //   36727: sipush #1751
    //   36730: ldc_w -13806944
    //   36733: invokeinterface setAlignedInt : (II)V
    //   36738: aload #5
    //   36740: sipush #1752
    //   36743: new org/renjin/gcc/runtime/BytePtr
    //   36746: dup
    //   36747: ldc_w 'sienna1 '
    //   36750: invokevirtual getBytes : ()[B
    //   36753: iconst_0
    //   36754: invokespecial <init> : ([BI)V
    //   36757: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36762: aload #5
    //   36764: sipush #1753
    //   36767: new org/renjin/gcc/runtime/BytePtr
    //   36770: dup
    //   36771: ldc_w '#FF8247 '
    //   36774: invokevirtual getBytes : ()[B
    //   36777: iconst_0
    //   36778: invokespecial <init> : ([BI)V
    //   36781: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36786: aload #5
    //   36788: sipush #1754
    //   36791: ldc_w -12090625
    //   36794: invokeinterface setAlignedInt : (II)V
    //   36799: aload #5
    //   36801: sipush #1755
    //   36804: new org/renjin/gcc/runtime/BytePtr
    //   36807: dup
    //   36808: ldc_w 'sienna2 '
    //   36811: invokevirtual getBytes : ()[B
    //   36814: iconst_0
    //   36815: invokespecial <init> : ([BI)V
    //   36818: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36823: aload #5
    //   36825: sipush #1756
    //   36828: new org/renjin/gcc/runtime/BytePtr
    //   36831: dup
    //   36832: ldc_w '#EE7942 '
    //   36835: invokevirtual getBytes : ()[B
    //   36838: iconst_0
    //   36839: invokespecial <init> : ([BI)V
    //   36842: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36847: aload #5
    //   36849: sipush #1757
    //   36852: ldc_w -12420626
    //   36855: invokeinterface setAlignedInt : (II)V
    //   36860: aload #5
    //   36862: sipush #1758
    //   36865: new org/renjin/gcc/runtime/BytePtr
    //   36868: dup
    //   36869: ldc_w 'sienna3 '
    //   36872: invokevirtual getBytes : ()[B
    //   36875: iconst_0
    //   36876: invokespecial <init> : ([BI)V
    //   36879: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36884: aload #5
    //   36886: sipush #1759
    //   36889: new org/renjin/gcc/runtime/BytePtr
    //   36892: dup
    //   36893: ldc_w '#CD6839 '
    //   36896: invokevirtual getBytes : ()[B
    //   36899: iconst_0
    //   36900: invokespecial <init> : ([BI)V
    //   36903: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36908: aload #5
    //   36910: sipush #1760
    //   36913: ldc_w -13014835
    //   36916: invokeinterface setAlignedInt : (II)V
    //   36921: aload #5
    //   36923: sipush #1761
    //   36926: new org/renjin/gcc/runtime/BytePtr
    //   36929: dup
    //   36930: ldc_w 'sienna4 '
    //   36933: invokevirtual getBytes : ()[B
    //   36936: iconst_0
    //   36937: invokespecial <init> : ([BI)V
    //   36940: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36945: aload #5
    //   36947: sipush #1762
    //   36950: new org/renjin/gcc/runtime/BytePtr
    //   36953: dup
    //   36954: ldc_w '#8B4726 '
    //   36957: invokevirtual getBytes : ()[B
    //   36960: iconst_0
    //   36961: invokespecial <init> : ([BI)V
    //   36964: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   36969: aload #5
    //   36971: sipush #1763
    //   36974: ldc_w -14268533
    //   36977: invokeinterface setAlignedInt : (II)V
    //   36982: aload #5
    //   36984: sipush #1764
    //   36987: new org/renjin/gcc/runtime/BytePtr
    //   36990: dup
    //   36991: ldc_w 'skyblue '
    //   36994: invokevirtual getBytes : ()[B
    //   36997: iconst_0
    //   36998: invokespecial <init> : ([BI)V
    //   37001: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37006: aload #5
    //   37008: sipush #1765
    //   37011: new org/renjin/gcc/runtime/BytePtr
    //   37014: dup
    //   37015: ldc_w '#87CEEB '
    //   37018: invokevirtual getBytes : ()[B
    //   37021: iconst_0
    //   37022: invokespecial <init> : ([BI)V
    //   37025: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37030: aload #5
    //   37032: sipush #1766
    //   37035: ldc_w -1323385
    //   37038: invokeinterface setAlignedInt : (II)V
    //   37043: aload #5
    //   37045: sipush #1767
    //   37048: new org/renjin/gcc/runtime/BytePtr
    //   37051: dup
    //   37052: ldc_w 'skyblue1 '
    //   37055: invokevirtual getBytes : ()[B
    //   37058: iconst_0
    //   37059: invokespecial <init> : ([BI)V
    //   37062: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37067: aload #5
    //   37069: sipush #1768
    //   37072: new org/renjin/gcc/runtime/BytePtr
    //   37075: dup
    //   37076: ldc_w '#87CEFF '
    //   37079: invokevirtual getBytes : ()[B
    //   37082: iconst_0
    //   37083: invokespecial <init> : ([BI)V
    //   37086: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37091: aload #5
    //   37093: sipush #1769
    //   37096: sipush #-12665
    //   37099: invokeinterface setAlignedInt : (II)V
    //   37104: aload #5
    //   37106: sipush #1770
    //   37109: new org/renjin/gcc/runtime/BytePtr
    //   37112: dup
    //   37113: ldc_w 'skyblue2 '
    //   37116: invokevirtual getBytes : ()[B
    //   37119: iconst_0
    //   37120: invokespecial <init> : ([BI)V
    //   37123: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37128: aload #5
    //   37130: sipush #1771
    //   37133: new org/renjin/gcc/runtime/BytePtr
    //   37136: dup
    //   37137: ldc_w '#7EC0EE '
    //   37140: invokevirtual getBytes : ()[B
    //   37143: iconst_0
    //   37144: invokespecial <init> : ([BI)V
    //   37147: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37152: aload #5
    //   37154: sipush #1772
    //   37157: ldc_w -1130370
    //   37160: invokeinterface setAlignedInt : (II)V
    //   37165: aload #5
    //   37167: sipush #1773
    //   37170: new org/renjin/gcc/runtime/BytePtr
    //   37173: dup
    //   37174: ldc_w 'skyblue3 '
    //   37177: invokevirtual getBytes : ()[B
    //   37180: iconst_0
    //   37181: invokespecial <init> : ([BI)V
    //   37184: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37189: aload #5
    //   37191: sipush #1774
    //   37194: new org/renjin/gcc/runtime/BytePtr
    //   37197: dup
    //   37198: ldc_w '#6CA6CD '
    //   37201: invokevirtual getBytes : ()[B
    //   37204: iconst_0
    //   37205: invokespecial <init> : ([BI)V
    //   37208: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37213: aload #5
    //   37215: sipush #1775
    //   37218: ldc_w -3299732
    //   37221: invokeinterface setAlignedInt : (II)V
    //   37226: aload #5
    //   37228: sipush #1776
    //   37231: new org/renjin/gcc/runtime/BytePtr
    //   37234: dup
    //   37235: ldc_w 'skyblue4 '
    //   37238: invokevirtual getBytes : ()[B
    //   37241: iconst_0
    //   37242: invokespecial <init> : ([BI)V
    //   37245: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37250: aload #5
    //   37252: sipush #1777
    //   37255: new org/renjin/gcc/runtime/BytePtr
    //   37258: dup
    //   37259: ldc_w '#4A708B '
    //   37262: invokevirtual getBytes : ()[B
    //   37265: iconst_0
    //   37266: invokespecial <init> : ([BI)V
    //   37269: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37274: aload #5
    //   37276: sipush #1778
    //   37279: ldc_w -7638966
    //   37282: invokeinterface setAlignedInt : (II)V
    //   37287: aload #5
    //   37289: sipush #1779
    //   37292: new org/renjin/gcc/runtime/BytePtr
    //   37295: dup
    //   37296: ldc_w 'slateblue '
    //   37299: invokevirtual getBytes : ()[B
    //   37302: iconst_0
    //   37303: invokespecial <init> : ([BI)V
    //   37306: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37311: aload #5
    //   37313: sipush #1780
    //   37316: new org/renjin/gcc/runtime/BytePtr
    //   37319: dup
    //   37320: ldc_w '#6A5ACD '
    //   37323: invokevirtual getBytes : ()[B
    //   37326: iconst_0
    //   37327: invokespecial <init> : ([BI)V
    //   37330: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37335: aload #5
    //   37337: sipush #1781
    //   37340: ldc_w -3319190
    //   37343: invokeinterface setAlignedInt : (II)V
    //   37348: aload #5
    //   37350: sipush #1782
    //   37353: new org/renjin/gcc/runtime/BytePtr
    //   37356: dup
    //   37357: ldc_w 'slateblue1 '
    //   37360: invokevirtual getBytes : ()[B
    //   37363: iconst_0
    //   37364: invokespecial <init> : ([BI)V
    //   37367: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37372: aload #5
    //   37374: sipush #1783
    //   37377: new org/renjin/gcc/runtime/BytePtr
    //   37380: dup
    //   37381: ldc_w '#836FFF '
    //   37384: invokevirtual getBytes : ()[B
    //   37387: iconst_0
    //   37388: invokespecial <init> : ([BI)V
    //   37391: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37396: aload #5
    //   37398: sipush #1784
    //   37401: ldc_w -36989
    //   37404: invokeinterface setAlignedInt : (II)V
    //   37409: aload #5
    //   37411: sipush #1785
    //   37414: new org/renjin/gcc/runtime/BytePtr
    //   37417: dup
    //   37418: ldc_w 'slateblue2 '
    //   37421: invokevirtual getBytes : ()[B
    //   37424: iconst_0
    //   37425: invokespecial <init> : ([BI)V
    //   37428: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37433: aload #5
    //   37435: sipush #1786
    //   37438: new org/renjin/gcc/runtime/BytePtr
    //   37441: dup
    //   37442: ldc_w '#7A67EE '
    //   37445: invokevirtual getBytes : ()[B
    //   37448: iconst_0
    //   37449: invokespecial <init> : ([BI)V
    //   37452: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37457: aload #5
    //   37459: sipush #1787
    //   37462: ldc_w -1153158
    //   37465: invokeinterface setAlignedInt : (II)V
    //   37470: aload #5
    //   37472: sipush #1788
    //   37475: new org/renjin/gcc/runtime/BytePtr
    //   37478: dup
    //   37479: ldc_w 'slateblue3 '
    //   37482: invokevirtual getBytes : ()[B
    //   37485: iconst_0
    //   37486: invokespecial <init> : ([BI)V
    //   37489: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37494: aload #5
    //   37496: sipush #1789
    //   37499: new org/renjin/gcc/runtime/BytePtr
    //   37502: dup
    //   37503: ldc_w '#6959CD '
    //   37506: invokevirtual getBytes : ()[B
    //   37509: iconst_0
    //   37510: invokespecial <init> : ([BI)V
    //   37513: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37518: aload #5
    //   37520: sipush #1790
    //   37523: ldc_w -3319447
    //   37526: invokeinterface setAlignedInt : (II)V
    //   37531: aload #5
    //   37533: sipush #1791
    //   37536: new org/renjin/gcc/runtime/BytePtr
    //   37539: dup
    //   37540: ldc_w 'slateblue4 '
    //   37543: invokevirtual getBytes : ()[B
    //   37546: iconst_0
    //   37547: invokespecial <init> : ([BI)V
    //   37550: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37555: aload #5
    //   37557: sipush #1792
    //   37560: new org/renjin/gcc/runtime/BytePtr
    //   37563: dup
    //   37564: ldc_w '#473C8B '
    //   37567: invokevirtual getBytes : ()[B
    //   37570: iconst_0
    //   37571: invokespecial <init> : ([BI)V
    //   37574: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37579: aload #5
    //   37581: sipush #1793
    //   37584: ldc_w -7652281
    //   37587: invokeinterface setAlignedInt : (II)V
    //   37592: aload #5
    //   37594: sipush #1794
    //   37597: new org/renjin/gcc/runtime/BytePtr
    //   37600: dup
    //   37601: ldc_w 'slategray '
    //   37604: invokevirtual getBytes : ()[B
    //   37607: iconst_0
    //   37608: invokespecial <init> : ([BI)V
    //   37611: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37616: aload #5
    //   37618: sipush #1795
    //   37621: new org/renjin/gcc/runtime/BytePtr
    //   37624: dup
    //   37625: ldc_w '#708090 '
    //   37628: invokevirtual getBytes : ()[B
    //   37631: iconst_0
    //   37632: invokespecial <init> : ([BI)V
    //   37635: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37640: aload #5
    //   37642: sipush #1796
    //   37645: ldc_w -7307152
    //   37648: invokeinterface setAlignedInt : (II)V
    //   37653: aload #5
    //   37655: sipush #1797
    //   37658: new org/renjin/gcc/runtime/BytePtr
    //   37661: dup
    //   37662: ldc_w 'slategray1 '
    //   37665: invokevirtual getBytes : ()[B
    //   37668: iconst_0
    //   37669: invokespecial <init> : ([BI)V
    //   37672: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37677: aload #5
    //   37679: sipush #1798
    //   37682: new org/renjin/gcc/runtime/BytePtr
    //   37685: dup
    //   37686: ldc_w '#C6E2FF '
    //   37689: invokevirtual getBytes : ()[B
    //   37692: iconst_0
    //   37693: invokespecial <init> : ([BI)V
    //   37696: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37701: aload #5
    //   37703: sipush #1799
    //   37706: sipush #-7482
    //   37709: invokeinterface setAlignedInt : (II)V
    //   37714: aload #5
    //   37716: sipush #1800
    //   37719: new org/renjin/gcc/runtime/BytePtr
    //   37722: dup
    //   37723: ldc_w 'slategray2 '
    //   37726: invokevirtual getBytes : ()[B
    //   37729: iconst_0
    //   37730: invokespecial <init> : ([BI)V
    //   37733: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37738: aload #5
    //   37740: sipush #1801
    //   37743: new org/renjin/gcc/runtime/BytePtr
    //   37746: dup
    //   37747: ldc_w '#B9D3EE '
    //   37750: invokevirtual getBytes : ()[B
    //   37753: iconst_0
    //   37754: invokespecial <init> : ([BI)V
    //   37757: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37762: aload #5
    //   37764: sipush #1802
    //   37767: ldc_w -1125447
    //   37770: invokeinterface setAlignedInt : (II)V
    //   37775: aload #5
    //   37777: sipush #1803
    //   37780: new org/renjin/gcc/runtime/BytePtr
    //   37783: dup
    //   37784: ldc_w 'slategray3 '
    //   37787: invokevirtual getBytes : ()[B
    //   37790: iconst_0
    //   37791: invokespecial <init> : ([BI)V
    //   37794: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37799: aload #5
    //   37801: sipush #1804
    //   37804: new org/renjin/gcc/runtime/BytePtr
    //   37807: dup
    //   37808: ldc_w '#9FB6CD '
    //   37811: invokevirtual getBytes : ()[B
    //   37814: iconst_0
    //   37815: invokespecial <init> : ([BI)V
    //   37818: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37823: aload #5
    //   37825: sipush #1805
    //   37828: ldc_w -3295585
    //   37831: invokeinterface setAlignedInt : (II)V
    //   37836: aload #5
    //   37838: sipush #1806
    //   37841: new org/renjin/gcc/runtime/BytePtr
    //   37844: dup
    //   37845: ldc_w 'slategray4 '
    //   37848: invokevirtual getBytes : ()[B
    //   37851: iconst_0
    //   37852: invokespecial <init> : ([BI)V
    //   37855: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37860: aload #5
    //   37862: sipush #1807
    //   37865: new org/renjin/gcc/runtime/BytePtr
    //   37868: dup
    //   37869: ldc_w '#6C7B8B '
    //   37872: invokevirtual getBytes : ()[B
    //   37875: iconst_0
    //   37876: invokespecial <init> : ([BI)V
    //   37879: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37884: aload #5
    //   37886: sipush #1808
    //   37889: ldc_w -7636116
    //   37892: invokeinterface setAlignedInt : (II)V
    //   37897: aload #5
    //   37899: sipush #1809
    //   37902: new org/renjin/gcc/runtime/BytePtr
    //   37905: dup
    //   37906: ldc_w 'slategrey '
    //   37909: invokevirtual getBytes : ()[B
    //   37912: iconst_0
    //   37913: invokespecial <init> : ([BI)V
    //   37916: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37921: aload #5
    //   37923: sipush #1810
    //   37926: new org/renjin/gcc/runtime/BytePtr
    //   37929: dup
    //   37930: ldc_w '#708090 '
    //   37933: invokevirtual getBytes : ()[B
    //   37936: iconst_0
    //   37937: invokespecial <init> : ([BI)V
    //   37940: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37945: aload #5
    //   37947: sipush #1811
    //   37950: ldc_w -7307152
    //   37953: invokeinterface setAlignedInt : (II)V
    //   37958: aload #5
    //   37960: sipush #1812
    //   37963: new org/renjin/gcc/runtime/BytePtr
    //   37966: dup
    //   37967: ldc_w 'snow '
    //   37970: invokevirtual getBytes : ()[B
    //   37973: iconst_0
    //   37974: invokespecial <init> : ([BI)V
    //   37977: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   37982: aload #5
    //   37984: sipush #1813
    //   37987: new org/renjin/gcc/runtime/BytePtr
    //   37990: dup
    //   37991: ldc_w '#FFFAFA '
    //   37994: invokevirtual getBytes : ()[B
    //   37997: iconst_0
    //   37998: invokespecial <init> : ([BI)V
    //   38001: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38006: aload #5
    //   38008: sipush #1814
    //   38011: ldc_w -328961
    //   38014: invokeinterface setAlignedInt : (II)V
    //   38019: aload #5
    //   38021: sipush #1815
    //   38024: new org/renjin/gcc/runtime/BytePtr
    //   38027: dup
    //   38028: ldc_w 'snow1 '
    //   38031: invokevirtual getBytes : ()[B
    //   38034: iconst_0
    //   38035: invokespecial <init> : ([BI)V
    //   38038: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38043: aload #5
    //   38045: sipush #1816
    //   38048: new org/renjin/gcc/runtime/BytePtr
    //   38051: dup
    //   38052: ldc_w '#FFFAFA '
    //   38055: invokevirtual getBytes : ()[B
    //   38058: iconst_0
    //   38059: invokespecial <init> : ([BI)V
    //   38062: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38067: aload #5
    //   38069: sipush #1817
    //   38072: ldc_w -328961
    //   38075: invokeinterface setAlignedInt : (II)V
    //   38080: aload #5
    //   38082: sipush #1818
    //   38085: new org/renjin/gcc/runtime/BytePtr
    //   38088: dup
    //   38089: ldc_w 'snow2 '
    //   38092: invokevirtual getBytes : ()[B
    //   38095: iconst_0
    //   38096: invokespecial <init> : ([BI)V
    //   38099: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38104: aload #5
    //   38106: sipush #1819
    //   38109: new org/renjin/gcc/runtime/BytePtr
    //   38112: dup
    //   38113: ldc_w '#EEE9E9 '
    //   38116: invokevirtual getBytes : ()[B
    //   38119: iconst_0
    //   38120: invokespecial <init> : ([BI)V
    //   38123: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38128: aload #5
    //   38130: sipush #1820
    //   38133: ldc_w -1447442
    //   38136: invokeinterface setAlignedInt : (II)V
    //   38141: aload #5
    //   38143: sipush #1821
    //   38146: new org/renjin/gcc/runtime/BytePtr
    //   38149: dup
    //   38150: ldc_w 'snow3 '
    //   38153: invokevirtual getBytes : ()[B
    //   38156: iconst_0
    //   38157: invokespecial <init> : ([BI)V
    //   38160: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38165: aload #5
    //   38167: sipush #1822
    //   38170: new org/renjin/gcc/runtime/BytePtr
    //   38173: dup
    //   38174: ldc_w '#CDC9C9 '
    //   38177: invokevirtual getBytes : ()[B
    //   38180: iconst_0
    //   38181: invokespecial <init> : ([BI)V
    //   38184: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38189: aload #5
    //   38191: sipush #1823
    //   38194: ldc_w -3552819
    //   38197: invokeinterface setAlignedInt : (II)V
    //   38202: aload #5
    //   38204: sipush #1824
    //   38207: new org/renjin/gcc/runtime/BytePtr
    //   38210: dup
    //   38211: ldc_w 'snow4 '
    //   38214: invokevirtual getBytes : ()[B
    //   38217: iconst_0
    //   38218: invokespecial <init> : ([BI)V
    //   38221: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38226: aload #5
    //   38228: sipush #1825
    //   38231: new org/renjin/gcc/runtime/BytePtr
    //   38234: dup
    //   38235: ldc_w '#8B8989 '
    //   38238: invokevirtual getBytes : ()[B
    //   38241: iconst_0
    //   38242: invokespecial <init> : ([BI)V
    //   38245: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38250: aload #5
    //   38252: sipush #1826
    //   38255: ldc_w -7763573
    //   38258: invokeinterface setAlignedInt : (II)V
    //   38263: aload #5
    //   38265: sipush #1827
    //   38268: new org/renjin/gcc/runtime/BytePtr
    //   38271: dup
    //   38272: ldc_w 'springgreen '
    //   38275: invokevirtual getBytes : ()[B
    //   38278: iconst_0
    //   38279: invokespecial <init> : ([BI)V
    //   38282: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38287: aload #5
    //   38289: sipush #1828
    //   38292: new org/renjin/gcc/runtime/BytePtr
    //   38295: dup
    //   38296: ldc_w '#00FF7F '
    //   38299: invokevirtual getBytes : ()[B
    //   38302: iconst_0
    //   38303: invokespecial <init> : ([BI)V
    //   38306: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38311: aload #5
    //   38313: sipush #1829
    //   38316: ldc_w -8388864
    //   38319: invokeinterface setAlignedInt : (II)V
    //   38324: aload #5
    //   38326: sipush #1830
    //   38329: new org/renjin/gcc/runtime/BytePtr
    //   38332: dup
    //   38333: ldc_w 'springgreen1 '
    //   38336: invokevirtual getBytes : ()[B
    //   38339: iconst_0
    //   38340: invokespecial <init> : ([BI)V
    //   38343: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38348: aload #5
    //   38350: sipush #1831
    //   38353: new org/renjin/gcc/runtime/BytePtr
    //   38356: dup
    //   38357: ldc_w '#00FF7F '
    //   38360: invokevirtual getBytes : ()[B
    //   38363: iconst_0
    //   38364: invokespecial <init> : ([BI)V
    //   38367: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38372: aload #5
    //   38374: sipush #1832
    //   38377: ldc_w -8388864
    //   38380: invokeinterface setAlignedInt : (II)V
    //   38385: aload #5
    //   38387: sipush #1833
    //   38390: new org/renjin/gcc/runtime/BytePtr
    //   38393: dup
    //   38394: ldc_w 'springgreen2 '
    //   38397: invokevirtual getBytes : ()[B
    //   38400: iconst_0
    //   38401: invokespecial <init> : ([BI)V
    //   38404: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38409: aload #5
    //   38411: sipush #1834
    //   38414: new org/renjin/gcc/runtime/BytePtr
    //   38417: dup
    //   38418: ldc_w '#00EE76 '
    //   38421: invokevirtual getBytes : ()[B
    //   38424: iconst_0
    //   38425: invokespecial <init> : ([BI)V
    //   38428: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38433: aload #5
    //   38435: sipush #1835
    //   38438: ldc_w -8983040
    //   38441: invokeinterface setAlignedInt : (II)V
    //   38446: aload #5
    //   38448: sipush #1836
    //   38451: new org/renjin/gcc/runtime/BytePtr
    //   38454: dup
    //   38455: ldc_w 'springgreen3 '
    //   38458: invokevirtual getBytes : ()[B
    //   38461: iconst_0
    //   38462: invokespecial <init> : ([BI)V
    //   38465: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38470: aload #5
    //   38472: sipush #1837
    //   38475: new org/renjin/gcc/runtime/BytePtr
    //   38478: dup
    //   38479: ldc_w '#00CD66 '
    //   38482: invokevirtual getBytes : ()[B
    //   38485: iconst_0
    //   38486: invokespecial <init> : ([BI)V
    //   38489: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38494: aload #5
    //   38496: sipush #1838
    //   38499: ldc_w -10040064
    //   38502: invokeinterface setAlignedInt : (II)V
    //   38507: aload #5
    //   38509: sipush #1839
    //   38512: new org/renjin/gcc/runtime/BytePtr
    //   38515: dup
    //   38516: ldc_w 'springgreen4 '
    //   38519: invokevirtual getBytes : ()[B
    //   38522: iconst_0
    //   38523: invokespecial <init> : ([BI)V
    //   38526: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38531: aload #5
    //   38533: sipush #1840
    //   38536: new org/renjin/gcc/runtime/BytePtr
    //   38539: dup
    //   38540: ldc_w '#008B45 '
    //   38543: invokevirtual getBytes : ()[B
    //   38546: iconst_0
    //   38547: invokespecial <init> : ([BI)V
    //   38550: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38555: aload #5
    //   38557: sipush #1841
    //   38560: ldc_w -12219648
    //   38563: invokeinterface setAlignedInt : (II)V
    //   38568: aload #5
    //   38570: sipush #1842
    //   38573: new org/renjin/gcc/runtime/BytePtr
    //   38576: dup
    //   38577: ldc_w 'steelblue '
    //   38580: invokevirtual getBytes : ()[B
    //   38583: iconst_0
    //   38584: invokespecial <init> : ([BI)V
    //   38587: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38592: aload #5
    //   38594: sipush #1843
    //   38597: new org/renjin/gcc/runtime/BytePtr
    //   38600: dup
    //   38601: ldc_w '#4682B4 '
    //   38604: invokevirtual getBytes : ()[B
    //   38607: iconst_0
    //   38608: invokespecial <init> : ([BI)V
    //   38611: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38616: aload #5
    //   38618: sipush #1844
    //   38621: ldc_w -4947386
    //   38624: invokeinterface setAlignedInt : (II)V
    //   38629: aload #5
    //   38631: sipush #1845
    //   38634: new org/renjin/gcc/runtime/BytePtr
    //   38637: dup
    //   38638: ldc_w 'steelblue1 '
    //   38641: invokevirtual getBytes : ()[B
    //   38644: iconst_0
    //   38645: invokespecial <init> : ([BI)V
    //   38648: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38653: aload #5
    //   38655: sipush #1846
    //   38658: new org/renjin/gcc/runtime/BytePtr
    //   38661: dup
    //   38662: ldc_w '#63B8FF '
    //   38665: invokevirtual getBytes : ()[B
    //   38668: iconst_0
    //   38669: invokespecial <init> : ([BI)V
    //   38672: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38677: aload #5
    //   38679: sipush #1847
    //   38682: sipush #-18333
    //   38685: invokeinterface setAlignedInt : (II)V
    //   38690: aload #5
    //   38692: sipush #1848
    //   38695: new org/renjin/gcc/runtime/BytePtr
    //   38698: dup
    //   38699: ldc_w 'steelblue2 '
    //   38702: invokevirtual getBytes : ()[B
    //   38705: iconst_0
    //   38706: invokespecial <init> : ([BI)V
    //   38709: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38714: aload #5
    //   38716: sipush #1849
    //   38719: new org/renjin/gcc/runtime/BytePtr
    //   38722: dup
    //   38723: ldc_w '#5CACEE '
    //   38726: invokevirtual getBytes : ()[B
    //   38729: iconst_0
    //   38730: invokespecial <init> : ([BI)V
    //   38733: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38738: aload #5
    //   38740: sipush #1850
    //   38743: ldc_w -1135524
    //   38746: invokeinterface setAlignedInt : (II)V
    //   38751: aload #5
    //   38753: sipush #1851
    //   38756: new org/renjin/gcc/runtime/BytePtr
    //   38759: dup
    //   38760: ldc_w 'steelblue3 '
    //   38763: invokevirtual getBytes : ()[B
    //   38766: iconst_0
    //   38767: invokespecial <init> : ([BI)V
    //   38770: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38775: aload #5
    //   38777: sipush #1852
    //   38780: new org/renjin/gcc/runtime/BytePtr
    //   38783: dup
    //   38784: ldc_w '#4F94CD '
    //   38787: invokevirtual getBytes : ()[B
    //   38790: iconst_0
    //   38791: invokespecial <init> : ([BI)V
    //   38794: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38799: aload #5
    //   38801: sipush #1853
    //   38804: ldc_w -3304369
    //   38807: invokeinterface setAlignedInt : (II)V
    //   38812: aload #5
    //   38814: sipush #1854
    //   38817: new org/renjin/gcc/runtime/BytePtr
    //   38820: dup
    //   38821: ldc_w 'steelblue4 '
    //   38824: invokevirtual getBytes : ()[B
    //   38827: iconst_0
    //   38828: invokespecial <init> : ([BI)V
    //   38831: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38836: aload #5
    //   38838: sipush #1855
    //   38841: new org/renjin/gcc/runtime/BytePtr
    //   38844: dup
    //   38845: ldc_w '#36648B '
    //   38848: invokevirtual getBytes : ()[B
    //   38851: iconst_0
    //   38852: invokespecial <init> : ([BI)V
    //   38855: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38860: aload #5
    //   38862: sipush #1856
    //   38865: ldc_w -7642058
    //   38868: invokeinterface setAlignedInt : (II)V
    //   38873: aload #5
    //   38875: sipush #1857
    //   38878: new org/renjin/gcc/runtime/BytePtr
    //   38881: dup
    //   38882: ldc_w 'tan '
    //   38885: invokevirtual getBytes : ()[B
    //   38888: iconst_0
    //   38889: invokespecial <init> : ([BI)V
    //   38892: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38897: aload #5
    //   38899: sipush #1858
    //   38902: new org/renjin/gcc/runtime/BytePtr
    //   38905: dup
    //   38906: ldc_w '#D2B48C '
    //   38909: invokevirtual getBytes : ()[B
    //   38912: iconst_0
    //   38913: invokespecial <init> : ([BI)V
    //   38916: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38921: aload #5
    //   38923: sipush #1859
    //   38926: ldc_w -7555886
    //   38929: invokeinterface setAlignedInt : (II)V
    //   38934: aload #5
    //   38936: sipush #1860
    //   38939: new org/renjin/gcc/runtime/BytePtr
    //   38942: dup
    //   38943: ldc_w 'tan1 '
    //   38946: invokevirtual getBytes : ()[B
    //   38949: iconst_0
    //   38950: invokespecial <init> : ([BI)V
    //   38953: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38958: aload #5
    //   38960: sipush #1861
    //   38963: new org/renjin/gcc/runtime/BytePtr
    //   38966: dup
    //   38967: ldc_w '#FFA54F '
    //   38970: invokevirtual getBytes : ()[B
    //   38973: iconst_0
    //   38974: invokespecial <init> : ([BI)V
    //   38977: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   38982: aload #5
    //   38984: sipush #1862
    //   38987: ldc_w -11557377
    //   38990: invokeinterface setAlignedInt : (II)V
    //   38995: aload #5
    //   38997: sipush #1863
    //   39000: new org/renjin/gcc/runtime/BytePtr
    //   39003: dup
    //   39004: ldc_w 'tan2 '
    //   39007: invokevirtual getBytes : ()[B
    //   39010: iconst_0
    //   39011: invokespecial <init> : ([BI)V
    //   39014: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39019: aload #5
    //   39021: sipush #1864
    //   39024: new org/renjin/gcc/runtime/BytePtr
    //   39027: dup
    //   39028: ldc_w '#EE9A49 '
    //   39031: invokevirtual getBytes : ()[B
    //   39034: iconst_0
    //   39035: invokespecial <init> : ([BI)V
    //   39038: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39043: aload #5
    //   39045: sipush #1865
    //   39048: ldc_w -11953426
    //   39051: invokeinterface setAlignedInt : (II)V
    //   39056: aload #5
    //   39058: sipush #1866
    //   39061: new org/renjin/gcc/runtime/BytePtr
    //   39064: dup
    //   39065: ldc_w 'tan3 '
    //   39068: invokevirtual getBytes : ()[B
    //   39071: iconst_0
    //   39072: invokespecial <init> : ([BI)V
    //   39075: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39080: aload #5
    //   39082: sipush #1867
    //   39085: new org/renjin/gcc/runtime/BytePtr
    //   39088: dup
    //   39089: ldc_w '#CD853F '
    //   39092: invokevirtual getBytes : ()[B
    //   39095: iconst_0
    //   39096: invokespecial <init> : ([BI)V
    //   39099: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39104: aload #5
    //   39106: sipush #1868
    //   39109: ldc_w -12614195
    //   39112: invokeinterface setAlignedInt : (II)V
    //   39117: aload #5
    //   39119: sipush #1869
    //   39122: new org/renjin/gcc/runtime/BytePtr
    //   39125: dup
    //   39126: ldc_w 'tan4 '
    //   39129: invokevirtual getBytes : ()[B
    //   39132: iconst_0
    //   39133: invokespecial <init> : ([BI)V
    //   39136: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39141: aload #5
    //   39143: sipush #1870
    //   39146: new org/renjin/gcc/runtime/BytePtr
    //   39149: dup
    //   39150: ldc_w '#8B5A2B '
    //   39153: invokevirtual getBytes : ()[B
    //   39156: iconst_0
    //   39157: invokespecial <init> : ([BI)V
    //   39160: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39165: aload #5
    //   39167: sipush #1871
    //   39170: ldc_w -13935989
    //   39173: invokeinterface setAlignedInt : (II)V
    //   39178: aload #5
    //   39180: sipush #1872
    //   39183: new org/renjin/gcc/runtime/BytePtr
    //   39186: dup
    //   39187: ldc_w 'thistle '
    //   39190: invokevirtual getBytes : ()[B
    //   39193: iconst_0
    //   39194: invokespecial <init> : ([BI)V
    //   39197: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39202: aload #5
    //   39204: sipush #1873
    //   39207: new org/renjin/gcc/runtime/BytePtr
    //   39210: dup
    //   39211: ldc_w '#D8BFD8 '
    //   39214: invokevirtual getBytes : ()[B
    //   39217: iconst_0
    //   39218: invokespecial <init> : ([BI)V
    //   39221: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39226: aload #5
    //   39228: sipush #1874
    //   39231: ldc_w -2572328
    //   39234: invokeinterface setAlignedInt : (II)V
    //   39239: aload #5
    //   39241: sipush #1875
    //   39244: new org/renjin/gcc/runtime/BytePtr
    //   39247: dup
    //   39248: ldc_w 'thistle1 '
    //   39251: invokevirtual getBytes : ()[B
    //   39254: iconst_0
    //   39255: invokespecial <init> : ([BI)V
    //   39258: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39263: aload #5
    //   39265: sipush #1876
    //   39268: new org/renjin/gcc/runtime/BytePtr
    //   39271: dup
    //   39272: ldc_w '#FFE1FF '
    //   39275: invokevirtual getBytes : ()[B
    //   39278: iconst_0
    //   39279: invokespecial <init> : ([BI)V
    //   39282: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39287: aload #5
    //   39289: sipush #1877
    //   39292: sipush #-7681
    //   39295: invokeinterface setAlignedInt : (II)V
    //   39300: aload #5
    //   39302: sipush #1878
    //   39305: new org/renjin/gcc/runtime/BytePtr
    //   39308: dup
    //   39309: ldc_w 'thistle2 '
    //   39312: invokevirtual getBytes : ()[B
    //   39315: iconst_0
    //   39316: invokespecial <init> : ([BI)V
    //   39319: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39324: aload #5
    //   39326: sipush #1879
    //   39329: new org/renjin/gcc/runtime/BytePtr
    //   39332: dup
    //   39333: ldc_w '#EED2EE '
    //   39336: invokevirtual getBytes : ()[B
    //   39339: iconst_0
    //   39340: invokespecial <init> : ([BI)V
    //   39343: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39348: aload #5
    //   39350: sipush #1880
    //   39353: ldc_w -1125650
    //   39356: invokeinterface setAlignedInt : (II)V
    //   39361: aload #5
    //   39363: sipush #1881
    //   39366: new org/renjin/gcc/runtime/BytePtr
    //   39369: dup
    //   39370: ldc_w 'thistle3 '
    //   39373: invokevirtual getBytes : ()[B
    //   39376: iconst_0
    //   39377: invokespecial <init> : ([BI)V
    //   39380: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39385: aload #5
    //   39387: sipush #1882
    //   39390: new org/renjin/gcc/runtime/BytePtr
    //   39393: dup
    //   39394: ldc_w '#CDB5CD '
    //   39397: invokevirtual getBytes : ()[B
    //   39400: iconst_0
    //   39401: invokespecial <init> : ([BI)V
    //   39404: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39409: aload #5
    //   39411: sipush #1883
    //   39414: ldc_w -3295795
    //   39417: invokeinterface setAlignedInt : (II)V
    //   39422: aload #5
    //   39424: sipush #1884
    //   39427: new org/renjin/gcc/runtime/BytePtr
    //   39430: dup
    //   39431: ldc_w 'thistle4 '
    //   39434: invokevirtual getBytes : ()[B
    //   39437: iconst_0
    //   39438: invokespecial <init> : ([BI)V
    //   39441: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39446: aload #5
    //   39448: sipush #1885
    //   39451: new org/renjin/gcc/runtime/BytePtr
    //   39454: dup
    //   39455: ldc_w '#8B7B8B '
    //   39458: invokevirtual getBytes : ()[B
    //   39461: iconst_0
    //   39462: invokespecial <init> : ([BI)V
    //   39465: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39470: aload #5
    //   39472: sipush #1886
    //   39475: ldc_w -7636085
    //   39478: invokeinterface setAlignedInt : (II)V
    //   39483: aload #5
    //   39485: sipush #1887
    //   39488: new org/renjin/gcc/runtime/BytePtr
    //   39491: dup
    //   39492: ldc_w 'tomato '
    //   39495: invokevirtual getBytes : ()[B
    //   39498: iconst_0
    //   39499: invokespecial <init> : ([BI)V
    //   39502: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39507: aload #5
    //   39509: sipush #1888
    //   39512: new org/renjin/gcc/runtime/BytePtr
    //   39515: dup
    //   39516: ldc_w '#FF6347 '
    //   39519: invokevirtual getBytes : ()[B
    //   39522: iconst_0
    //   39523: invokespecial <init> : ([BI)V
    //   39526: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39531: aload #5
    //   39533: sipush #1889
    //   39536: ldc_w -12098561
    //   39539: invokeinterface setAlignedInt : (II)V
    //   39544: aload #5
    //   39546: sipush #1890
    //   39549: new org/renjin/gcc/runtime/BytePtr
    //   39552: dup
    //   39553: ldc_w 'tomato1 '
    //   39556: invokevirtual getBytes : ()[B
    //   39559: iconst_0
    //   39560: invokespecial <init> : ([BI)V
    //   39563: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39568: aload #5
    //   39570: sipush #1891
    //   39573: new org/renjin/gcc/runtime/BytePtr
    //   39576: dup
    //   39577: ldc_w '#FF6347 '
    //   39580: invokevirtual getBytes : ()[B
    //   39583: iconst_0
    //   39584: invokespecial <init> : ([BI)V
    //   39587: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39592: aload #5
    //   39594: sipush #1892
    //   39597: ldc_w -12098561
    //   39600: invokeinterface setAlignedInt : (II)V
    //   39605: aload #5
    //   39607: sipush #1893
    //   39610: new org/renjin/gcc/runtime/BytePtr
    //   39613: dup
    //   39614: ldc_w 'tomato2 '
    //   39617: invokevirtual getBytes : ()[B
    //   39620: iconst_0
    //   39621: invokespecial <init> : ([BI)V
    //   39624: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39629: aload #5
    //   39631: sipush #1894
    //   39634: new org/renjin/gcc/runtime/BytePtr
    //   39637: dup
    //   39638: ldc_w '#EE5C42 '
    //   39641: invokevirtual getBytes : ()[B
    //   39644: iconst_0
    //   39645: invokespecial <init> : ([BI)V
    //   39648: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39653: aload #5
    //   39655: sipush #1895
    //   39658: ldc_w -12428050
    //   39661: invokeinterface setAlignedInt : (II)V
    //   39666: aload #5
    //   39668: sipush #1896
    //   39671: new org/renjin/gcc/runtime/BytePtr
    //   39674: dup
    //   39675: ldc_w 'tomato3 '
    //   39678: invokevirtual getBytes : ()[B
    //   39681: iconst_0
    //   39682: invokespecial <init> : ([BI)V
    //   39685: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39690: aload #5
    //   39692: sipush #1897
    //   39695: new org/renjin/gcc/runtime/BytePtr
    //   39698: dup
    //   39699: ldc_w '#CD4F39 '
    //   39702: invokevirtual getBytes : ()[B
    //   39705: iconst_0
    //   39706: invokespecial <init> : ([BI)V
    //   39709: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39714: aload #5
    //   39716: sipush #1898
    //   39719: ldc_w -13021235
    //   39722: invokeinterface setAlignedInt : (II)V
    //   39727: aload #5
    //   39729: sipush #1899
    //   39732: new org/renjin/gcc/runtime/BytePtr
    //   39735: dup
    //   39736: ldc_w 'tomato4 '
    //   39739: invokevirtual getBytes : ()[B
    //   39742: iconst_0
    //   39743: invokespecial <init> : ([BI)V
    //   39746: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39751: aload #5
    //   39753: sipush #1900
    //   39756: new org/renjin/gcc/runtime/BytePtr
    //   39759: dup
    //   39760: ldc_w '#8B3626 '
    //   39763: invokevirtual getBytes : ()[B
    //   39766: iconst_0
    //   39767: invokespecial <init> : ([BI)V
    //   39770: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39775: aload #5
    //   39777: sipush #1901
    //   39780: ldc_w -14272885
    //   39783: invokeinterface setAlignedInt : (II)V
    //   39788: aload #5
    //   39790: sipush #1902
    //   39793: new org/renjin/gcc/runtime/BytePtr
    //   39796: dup
    //   39797: ldc_w 'turquoise '
    //   39800: invokevirtual getBytes : ()[B
    //   39803: iconst_0
    //   39804: invokespecial <init> : ([BI)V
    //   39807: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39812: aload #5
    //   39814: sipush #1903
    //   39817: new org/renjin/gcc/runtime/BytePtr
    //   39820: dup
    //   39821: ldc_w '#40E0D0 '
    //   39824: invokevirtual getBytes : ()[B
    //   39827: iconst_0
    //   39828: invokespecial <init> : ([BI)V
    //   39831: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39836: aload #5
    //   39838: sipush #1904
    //   39841: ldc_w -3088320
    //   39844: invokeinterface setAlignedInt : (II)V
    //   39849: aload #5
    //   39851: sipush #1905
    //   39854: new org/renjin/gcc/runtime/BytePtr
    //   39857: dup
    //   39858: ldc_w 'turquoise1 '
    //   39861: invokevirtual getBytes : ()[B
    //   39864: iconst_0
    //   39865: invokespecial <init> : ([BI)V
    //   39868: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39873: aload #5
    //   39875: sipush #1906
    //   39878: new org/renjin/gcc/runtime/BytePtr
    //   39881: dup
    //   39882: ldc_w '#00F5FF '
    //   39885: invokevirtual getBytes : ()[B
    //   39888: iconst_0
    //   39889: invokespecial <init> : ([BI)V
    //   39892: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39897: aload #5
    //   39899: sipush #1907
    //   39902: sipush #-2816
    //   39905: invokeinterface setAlignedInt : (II)V
    //   39910: aload #5
    //   39912: sipush #1908
    //   39915: new org/renjin/gcc/runtime/BytePtr
    //   39918: dup
    //   39919: ldc_w 'turquoise2 '
    //   39922: invokevirtual getBytes : ()[B
    //   39925: iconst_0
    //   39926: invokespecial <init> : ([BI)V
    //   39929: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39934: aload #5
    //   39936: sipush #1909
    //   39939: new org/renjin/gcc/runtime/BytePtr
    //   39942: dup
    //   39943: ldc_w '#00E5EE '
    //   39946: invokevirtual getBytes : ()[B
    //   39949: iconst_0
    //   39950: invokespecial <init> : ([BI)V
    //   39953: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39958: aload #5
    //   39960: sipush #1910
    //   39963: ldc_w -1121024
    //   39966: invokeinterface setAlignedInt : (II)V
    //   39971: aload #5
    //   39973: sipush #1911
    //   39976: new org/renjin/gcc/runtime/BytePtr
    //   39979: dup
    //   39980: ldc_w 'turquoise3 '
    //   39983: invokevirtual getBytes : ()[B
    //   39986: iconst_0
    //   39987: invokespecial <init> : ([BI)V
    //   39990: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   39995: aload #5
    //   39997: sipush #1912
    //   40000: new org/renjin/gcc/runtime/BytePtr
    //   40003: dup
    //   40004: ldc_w '#00C5CD '
    //   40007: invokevirtual getBytes : ()[B
    //   40010: iconst_0
    //   40011: invokespecial <init> : ([BI)V
    //   40014: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40019: aload #5
    //   40021: sipush #1913
    //   40024: ldc_w -3291904
    //   40027: invokeinterface setAlignedInt : (II)V
    //   40032: aload #5
    //   40034: sipush #1914
    //   40037: new org/renjin/gcc/runtime/BytePtr
    //   40040: dup
    //   40041: ldc_w 'turquoise4 '
    //   40044: invokevirtual getBytes : ()[B
    //   40047: iconst_0
    //   40048: invokespecial <init> : ([BI)V
    //   40051: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40056: aload #5
    //   40058: sipush #1915
    //   40061: new org/renjin/gcc/runtime/BytePtr
    //   40064: dup
    //   40065: ldc_w '#00868B '
    //   40068: invokevirtual getBytes : ()[B
    //   40071: iconst_0
    //   40072: invokespecial <init> : ([BI)V
    //   40075: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40080: aload #5
    //   40082: sipush #1916
    //   40085: ldc_w -7633408
    //   40088: invokeinterface setAlignedInt : (II)V
    //   40093: aload #5
    //   40095: sipush #1917
    //   40098: new org/renjin/gcc/runtime/BytePtr
    //   40101: dup
    //   40102: ldc_w 'violet '
    //   40105: invokevirtual getBytes : ()[B
    //   40108: iconst_0
    //   40109: invokespecial <init> : ([BI)V
    //   40112: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40117: aload #5
    //   40119: sipush #1918
    //   40122: new org/renjin/gcc/runtime/BytePtr
    //   40125: dup
    //   40126: ldc_w '#EE82EE '
    //   40129: invokevirtual getBytes : ()[B
    //   40132: iconst_0
    //   40133: invokespecial <init> : ([BI)V
    //   40136: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40141: aload #5
    //   40143: sipush #1919
    //   40146: ldc_w -1146130
    //   40149: invokeinterface setAlignedInt : (II)V
    //   40154: aload #5
    //   40156: sipush #1920
    //   40159: new org/renjin/gcc/runtime/BytePtr
    //   40162: dup
    //   40163: ldc_w 'violetred '
    //   40166: invokevirtual getBytes : ()[B
    //   40169: iconst_0
    //   40170: invokespecial <init> : ([BI)V
    //   40173: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40178: aload #5
    //   40180: sipush #1921
    //   40183: new org/renjin/gcc/runtime/BytePtr
    //   40186: dup
    //   40187: ldc_w '#D02090 '
    //   40190: invokevirtual getBytes : ()[B
    //   40193: iconst_0
    //   40194: invokespecial <init> : ([BI)V
    //   40197: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40202: aload #5
    //   40204: sipush #1922
    //   40207: ldc_w -7331632
    //   40210: invokeinterface setAlignedInt : (II)V
    //   40215: aload #5
    //   40217: sipush #1923
    //   40220: new org/renjin/gcc/runtime/BytePtr
    //   40223: dup
    //   40224: ldc_w 'violetred1 '
    //   40227: invokevirtual getBytes : ()[B
    //   40230: iconst_0
    //   40231: invokespecial <init> : ([BI)V
    //   40234: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40239: aload #5
    //   40241: sipush #1924
    //   40244: new org/renjin/gcc/runtime/BytePtr
    //   40247: dup
    //   40248: ldc_w '#FF3E96 '
    //   40251: invokevirtual getBytes : ()[B
    //   40254: iconst_0
    //   40255: invokespecial <init> : ([BI)V
    //   40258: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40263: aload #5
    //   40265: sipush #1925
    //   40268: ldc_w -6930689
    //   40271: invokeinterface setAlignedInt : (II)V
    //   40276: aload #5
    //   40278: sipush #1926
    //   40281: new org/renjin/gcc/runtime/BytePtr
    //   40284: dup
    //   40285: ldc_w 'violetred2 '
    //   40288: invokevirtual getBytes : ()[B
    //   40291: iconst_0
    //   40292: invokespecial <init> : ([BI)V
    //   40295: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40300: aload #5
    //   40302: sipush #1927
    //   40305: new org/renjin/gcc/runtime/BytePtr
    //   40308: dup
    //   40309: ldc_w '#EE3A8C '
    //   40312: invokevirtual getBytes : ()[B
    //   40315: iconst_0
    //   40316: invokespecial <init> : ([BI)V
    //   40319: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40324: aload #5
    //   40326: sipush #1928
    //   40329: ldc_w -7587090
    //   40332: invokeinterface setAlignedInt : (II)V
    //   40337: aload #5
    //   40339: sipush #1929
    //   40342: new org/renjin/gcc/runtime/BytePtr
    //   40345: dup
    //   40346: ldc_w 'violetred3 '
    //   40349: invokevirtual getBytes : ()[B
    //   40352: iconst_0
    //   40353: invokespecial <init> : ([BI)V
    //   40356: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40361: aload #5
    //   40363: sipush #1930
    //   40366: new org/renjin/gcc/runtime/BytePtr
    //   40369: dup
    //   40370: ldc_w '#CD3278 '
    //   40373: invokevirtual getBytes : ()[B
    //   40376: iconst_0
    //   40377: invokespecial <init> : ([BI)V
    //   40380: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40385: aload #5
    //   40387: sipush #1931
    //   40390: ldc_w -8899891
    //   40393: invokeinterface setAlignedInt : (II)V
    //   40398: aload #5
    //   40400: sipush #1932
    //   40403: new org/renjin/gcc/runtime/BytePtr
    //   40406: dup
    //   40407: ldc_w 'violetred4 '
    //   40410: invokevirtual getBytes : ()[B
    //   40413: iconst_0
    //   40414: invokespecial <init> : ([BI)V
    //   40417: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40422: aload #5
    //   40424: sipush #1933
    //   40427: new org/renjin/gcc/runtime/BytePtr
    //   40430: dup
    //   40431: ldc_w '#8B2252 '
    //   40434: invokevirtual getBytes : ()[B
    //   40437: iconst_0
    //   40438: invokespecial <init> : ([BI)V
    //   40441: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40446: aload #5
    //   40448: sipush #1934
    //   40451: ldc_w -11394421
    //   40454: invokeinterface setAlignedInt : (II)V
    //   40459: aload #5
    //   40461: sipush #1935
    //   40464: new org/renjin/gcc/runtime/BytePtr
    //   40467: dup
    //   40468: ldc_w 'wheat '
    //   40471: invokevirtual getBytes : ()[B
    //   40474: iconst_0
    //   40475: invokespecial <init> : ([BI)V
    //   40478: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40483: aload #5
    //   40485: sipush #1936
    //   40488: new org/renjin/gcc/runtime/BytePtr
    //   40491: dup
    //   40492: ldc_w '#F5DEB3 '
    //   40495: invokevirtual getBytes : ()[B
    //   40498: iconst_0
    //   40499: invokespecial <init> : ([BI)V
    //   40502: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40507: aload #5
    //   40509: sipush #1937
    //   40512: ldc_w -4989195
    //   40515: invokeinterface setAlignedInt : (II)V
    //   40520: aload #5
    //   40522: sipush #1938
    //   40525: new org/renjin/gcc/runtime/BytePtr
    //   40528: dup
    //   40529: ldc_w 'wheat1 '
    //   40532: invokevirtual getBytes : ()[B
    //   40535: iconst_0
    //   40536: invokespecial <init> : ([BI)V
    //   40539: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40544: aload #5
    //   40546: sipush #1939
    //   40549: new org/renjin/gcc/runtime/BytePtr
    //   40552: dup
    //   40553: ldc_w '#FFE7BA '
    //   40556: invokevirtual getBytes : ()[B
    //   40559: iconst_0
    //   40560: invokespecial <init> : ([BI)V
    //   40563: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40568: aload #5
    //   40570: sipush #1940
    //   40573: ldc_w -4528129
    //   40576: invokeinterface setAlignedInt : (II)V
    //   40581: aload #5
    //   40583: sipush #1941
    //   40586: new org/renjin/gcc/runtime/BytePtr
    //   40589: dup
    //   40590: ldc_w 'wheat2 '
    //   40593: invokevirtual getBytes : ()[B
    //   40596: iconst_0
    //   40597: invokespecial <init> : ([BI)V
    //   40600: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40605: aload #5
    //   40607: sipush #1942
    //   40610: new org/renjin/gcc/runtime/BytePtr
    //   40613: dup
    //   40614: ldc_w '#EED8AE '
    //   40617: invokevirtual getBytes : ()[B
    //   40620: iconst_0
    //   40621: invokespecial <init> : ([BI)V
    //   40624: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40629: aload #5
    //   40631: sipush #1943
    //   40634: ldc_w -5318418
    //   40637: invokeinterface setAlignedInt : (II)V
    //   40642: aload #5
    //   40644: sipush #1944
    //   40647: new org/renjin/gcc/runtime/BytePtr
    //   40650: dup
    //   40651: ldc_w 'wheat3 '
    //   40654: invokevirtual getBytes : ()[B
    //   40657: iconst_0
    //   40658: invokespecial <init> : ([BI)V
    //   40661: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40666: aload #5
    //   40668: sipush #1945
    //   40671: new org/renjin/gcc/runtime/BytePtr
    //   40674: dup
    //   40675: ldc_w '#CDBA96 '
    //   40678: invokevirtual getBytes : ()[B
    //   40681: iconst_0
    //   40682: invokespecial <init> : ([BI)V
    //   40685: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40690: aload #5
    //   40692: sipush #1946
    //   40695: ldc_w -6898995
    //   40698: invokeinterface setAlignedInt : (II)V
    //   40703: aload #5
    //   40705: sipush #1947
    //   40708: new org/renjin/gcc/runtime/BytePtr
    //   40711: dup
    //   40712: ldc_w 'wheat4 '
    //   40715: invokevirtual getBytes : ()[B
    //   40718: iconst_0
    //   40719: invokespecial <init> : ([BI)V
    //   40722: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40727: aload #5
    //   40729: sipush #1948
    //   40732: new org/renjin/gcc/runtime/BytePtr
    //   40735: dup
    //   40736: ldc_w '#8B7E66 '
    //   40739: invokevirtual getBytes : ()[B
    //   40742: iconst_0
    //   40743: invokespecial <init> : ([BI)V
    //   40746: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40751: aload #5
    //   40753: sipush #1949
    //   40756: ldc_w -10060149
    //   40759: invokeinterface setAlignedInt : (II)V
    //   40764: aload #5
    //   40766: sipush #1950
    //   40769: new org/renjin/gcc/runtime/BytePtr
    //   40772: dup
    //   40773: ldc_w 'whitesmoke '
    //   40776: invokevirtual getBytes : ()[B
    //   40779: iconst_0
    //   40780: invokespecial <init> : ([BI)V
    //   40783: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40788: aload #5
    //   40790: sipush #1951
    //   40793: new org/renjin/gcc/runtime/BytePtr
    //   40796: dup
    //   40797: ldc_w '#F5F5F5 '
    //   40800: invokevirtual getBytes : ()[B
    //   40803: iconst_0
    //   40804: invokespecial <init> : ([BI)V
    //   40807: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40812: aload #5
    //   40814: sipush #1952
    //   40817: ldc_w -657931
    //   40820: invokeinterface setAlignedInt : (II)V
    //   40825: aload #5
    //   40827: sipush #1953
    //   40830: new org/renjin/gcc/runtime/BytePtr
    //   40833: dup
    //   40834: ldc_w 'yellow '
    //   40837: invokevirtual getBytes : ()[B
    //   40840: iconst_0
    //   40841: invokespecial <init> : ([BI)V
    //   40844: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40849: aload #5
    //   40851: sipush #1954
    //   40854: new org/renjin/gcc/runtime/BytePtr
    //   40857: dup
    //   40858: ldc_w '#FFFF00 '
    //   40861: invokevirtual getBytes : ()[B
    //   40864: iconst_0
    //   40865: invokespecial <init> : ([BI)V
    //   40868: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40873: aload #5
    //   40875: sipush #1955
    //   40878: ldc_w -16711681
    //   40881: invokeinterface setAlignedInt : (II)V
    //   40886: aload #5
    //   40888: sipush #1956
    //   40891: new org/renjin/gcc/runtime/BytePtr
    //   40894: dup
    //   40895: ldc_w 'yellow1 '
    //   40898: invokevirtual getBytes : ()[B
    //   40901: iconst_0
    //   40902: invokespecial <init> : ([BI)V
    //   40905: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40910: aload #5
    //   40912: sipush #1957
    //   40915: new org/renjin/gcc/runtime/BytePtr
    //   40918: dup
    //   40919: ldc_w '#FFFF00 '
    //   40922: invokevirtual getBytes : ()[B
    //   40925: iconst_0
    //   40926: invokespecial <init> : ([BI)V
    //   40929: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40934: aload #5
    //   40936: sipush #1958
    //   40939: ldc_w -16711681
    //   40942: invokeinterface setAlignedInt : (II)V
    //   40947: aload #5
    //   40949: sipush #1959
    //   40952: new org/renjin/gcc/runtime/BytePtr
    //   40955: dup
    //   40956: ldc_w 'yellow2 '
    //   40959: invokevirtual getBytes : ()[B
    //   40962: iconst_0
    //   40963: invokespecial <init> : ([BI)V
    //   40966: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40971: aload #5
    //   40973: sipush #1960
    //   40976: new org/renjin/gcc/runtime/BytePtr
    //   40979: dup
    //   40980: ldc_w '#EEEE00 '
    //   40983: invokevirtual getBytes : ()[B
    //   40986: iconst_0
    //   40987: invokespecial <init> : ([BI)V
    //   40990: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   40995: aload #5
    //   40997: sipush #1961
    //   41000: ldc_w -16716050
    //   41003: invokeinterface setAlignedInt : (II)V
    //   41008: aload #5
    //   41010: sipush #1962
    //   41013: new org/renjin/gcc/runtime/BytePtr
    //   41016: dup
    //   41017: ldc_w 'yellow3 '
    //   41020: invokevirtual getBytes : ()[B
    //   41023: iconst_0
    //   41024: invokespecial <init> : ([BI)V
    //   41027: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41032: aload #5
    //   41034: sipush #1963
    //   41037: new org/renjin/gcc/runtime/BytePtr
    //   41040: dup
    //   41041: ldc_w '#CDCD00 '
    //   41044: invokevirtual getBytes : ()[B
    //   41047: iconst_0
    //   41048: invokespecial <init> : ([BI)V
    //   41051: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41056: aload #5
    //   41058: sipush #1964
    //   41061: ldc_w -16724531
    //   41064: invokeinterface setAlignedInt : (II)V
    //   41069: aload #5
    //   41071: sipush #1965
    //   41074: new org/renjin/gcc/runtime/BytePtr
    //   41077: dup
    //   41078: ldc_w 'yellow4 '
    //   41081: invokevirtual getBytes : ()[B
    //   41084: iconst_0
    //   41085: invokespecial <init> : ([BI)V
    //   41088: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41093: aload #5
    //   41095: sipush #1966
    //   41098: new org/renjin/gcc/runtime/BytePtr
    //   41101: dup
    //   41102: ldc_w '#8B8B00 '
    //   41105: invokevirtual getBytes : ()[B
    //   41108: iconst_0
    //   41109: invokespecial <init> : ([BI)V
    //   41112: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41117: aload #5
    //   41119: sipush #1967
    //   41122: ldc_w -16741493
    //   41125: invokeinterface setAlignedInt : (II)V
    //   41130: aload #5
    //   41132: sipush #1968
    //   41135: new org/renjin/gcc/runtime/BytePtr
    //   41138: dup
    //   41139: ldc_w 'yellowgreen '
    //   41142: invokevirtual getBytes : ()[B
    //   41145: iconst_0
    //   41146: invokespecial <init> : ([BI)V
    //   41149: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41154: aload #5
    //   41156: sipush #1969
    //   41159: new org/renjin/gcc/runtime/BytePtr
    //   41162: dup
    //   41163: ldc_w '#9ACD32 '
    //   41166: invokevirtual getBytes : ()[B
    //   41169: iconst_0
    //   41170: invokespecial <init> : ([BI)V
    //   41173: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41178: aload #5
    //   41180: sipush #1970
    //   41183: ldc_w -13447782
    //   41186: invokeinterface setAlignedInt : (II)V
    //   41191: aload #5
    //   41193: sipush #1971
    //   41196: iconst_0
    //   41197: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   41200: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41205: aload #5
    //   41207: sipush #1972
    //   41210: iconst_0
    //   41211: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   41214: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41219: aload #5
    //   41221: sipush #1973
    //   41224: iconst_0
    //   41225: invokeinterface setAlignedInt : (II)V
    //   41230: aload_0
    //   41231: getfield colors$ColorDataBase : Lorg/renjin/gcc/runtime/Ptr;
    //   41234: aload #5
    //   41236: sipush #7896
    //   41239: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   41244: aload_0
    //   41245: getfield colors$DefaultPalette : Lorg/renjin/gcc/runtime/Ptr;
    //   41248: new org/renjin/gcc/runtime/PointerPtr
    //   41251: dup
    //   41252: bipush #9
    //   41254: anewarray org/renjin/gcc/runtime/Ptr
    //   41257: dup
    //   41258: iconst_0
    //   41259: new org/renjin/gcc/runtime/BytePtr
    //   41262: dup
    //   41263: ldc_w 'black '
    //   41266: invokevirtual getBytes : ()[B
    //   41269: iconst_0
    //   41270: invokespecial <init> : ([BI)V
    //   41273: aastore
    //   41274: dup
    //   41275: iconst_1
    //   41276: new org/renjin/gcc/runtime/BytePtr
    //   41279: dup
    //   41280: ldc_w 'red '
    //   41283: invokevirtual getBytes : ()[B
    //   41286: iconst_0
    //   41287: invokespecial <init> : ([BI)V
    //   41290: aastore
    //   41291: dup
    //   41292: iconst_2
    //   41293: new org/renjin/gcc/runtime/BytePtr
    //   41296: dup
    //   41297: ldc_w 'green3 '
    //   41300: invokevirtual getBytes : ()[B
    //   41303: iconst_0
    //   41304: invokespecial <init> : ([BI)V
    //   41307: aastore
    //   41308: dup
    //   41309: iconst_3
    //   41310: new org/renjin/gcc/runtime/BytePtr
    //   41313: dup
    //   41314: ldc_w 'blue '
    //   41317: invokevirtual getBytes : ()[B
    //   41320: iconst_0
    //   41321: invokespecial <init> : ([BI)V
    //   41324: aastore
    //   41325: dup
    //   41326: iconst_4
    //   41327: new org/renjin/gcc/runtime/BytePtr
    //   41330: dup
    //   41331: ldc_w 'cyan '
    //   41334: invokevirtual getBytes : ()[B
    //   41337: iconst_0
    //   41338: invokespecial <init> : ([BI)V
    //   41341: aastore
    //   41342: dup
    //   41343: iconst_5
    //   41344: new org/renjin/gcc/runtime/BytePtr
    //   41347: dup
    //   41348: ldc_w 'magenta '
    //   41351: invokevirtual getBytes : ()[B
    //   41354: iconst_0
    //   41355: invokespecial <init> : ([BI)V
    //   41358: aastore
    //   41359: dup
    //   41360: bipush #6
    //   41362: new org/renjin/gcc/runtime/BytePtr
    //   41365: dup
    //   41366: ldc_w 'yellow '
    //   41369: invokevirtual getBytes : ()[B
    //   41372: iconst_0
    //   41373: invokespecial <init> : ([BI)V
    //   41376: aastore
    //   41377: dup
    //   41378: bipush #7
    //   41380: new org/renjin/gcc/runtime/BytePtr
    //   41383: dup
    //   41384: ldc_w 'grey '
    //   41387: invokevirtual getBytes : ()[B
    //   41390: iconst_0
    //   41391: invokespecial <init> : ([BI)V
    //   41394: aastore
    //   41395: dup
    //   41396: bipush #8
    //   41398: iconst_0
    //   41399: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   41402: aastore
    //   41403: invokespecial <init> : ([Lorg/renjin/gcc/runtime/Ptr;)V
    //   41406: bipush #36
    //   41408: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   41413: sipush #1024
    //   41416: newarray int
    //   41418: dup
    //   41419: iconst_0
    //   41420: ldc_w -16777216
    //   41423: iastore
    //   41424: dup
    //   41425: iconst_1
    //   41426: ldc_w -16776961
    //   41429: iastore
    //   41430: dup
    //   41431: iconst_2
    //   41432: ldc_w -16724736
    //   41435: iastore
    //   41436: dup
    //   41437: iconst_3
    //   41438: ldc_w -65536
    //   41441: iastore
    //   41442: dup
    //   41443: iconst_4
    //   41444: sipush #-256
    //   41447: iastore
    //   41448: dup
    //   41449: iconst_5
    //   41450: ldc_w -65281
    //   41453: iastore
    //   41454: dup
    //   41455: bipush #6
    //   41457: ldc_w -16711681
    //   41460: iastore
    //   41461: dup
    //   41462: bipush #7
    //   41464: ldc_w -4276546
    //   41467: iastore
    //   41468: iconst_0
    //   41469: aload_0
    //   41470: getfield colors$Palette : [I
    //   41473: iconst_0
    //   41474: sipush #1024
    //   41477: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   41480: aload_0
    //   41481: bipush #8
    //   41483: putfield colors$PaletteSize : I
    //   41486: ldc_w '0123456789ABCDEF '
    //   41489: invokevirtual getBytes : ()[B
    //   41492: iconst_0
    //   41493: aload_0
    //   41494: getfield colors$HexDigits : [B
    //   41497: iconst_0
    //   41498: bipush #17
    //   41500: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   41503: sipush #540
    //   41506: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   41509: astore #6
    //   41511: aload #6
    //   41513: new org/renjin/gcc/runtime/BytePtr
    //   41516: dup
    //   41517: ldc_w 'PDF '
    //   41520: invokevirtual getBytes : ()[B
    //   41523: iconst_0
    //   41524: invokespecial <init> : ([BI)V
    //   41527: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   41532: aload #6
    //   41534: iconst_1
    //   41535: ldc_w 'PDF'
    //   41538: invokestatic throwingHandle : (Ljava/lang/String;)Ljava/lang/invoke/MethodHandle;
    //   41541: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41544: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41549: aload #6
    //   41551: iconst_2
    //   41552: bipush #20
    //   41554: invokeinterface setAlignedInt : (II)V
    //   41559: aload #6
    //   41561: iconst_5
    //   41562: new org/renjin/gcc/runtime/BytePtr
    //   41565: dup
    //   41566: ldc_w 'devCairo '
    //   41569: invokevirtual getBytes : ()[B
    //   41572: iconst_0
    //   41573: invokespecial <init> : ([BI)V
    //   41576: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41581: aload #6
    //   41583: bipush #6
    //   41585: ldc_w 'devCairo'
    //   41588: invokestatic throwingHandle : (Ljava/lang/String;)Ljava/lang/invoke/MethodHandle;
    //   41591: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41594: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41599: aload #6
    //   41601: bipush #7
    //   41603: bipush #11
    //   41605: invokeinterface setAlignedInt : (II)V
    //   41610: aload #6
    //   41612: bipush #10
    //   41614: new org/renjin/gcc/runtime/BytePtr
    //   41617: dup
    //   41618: ldc_w 'devcap '
    //   41621: invokevirtual getBytes : ()[B
    //   41624: iconst_0
    //   41625: invokespecial <init> : ([BI)V
    //   41628: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41633: aload #6
    //   41635: bipush #11
    //   41637: ldc_w
    //   41640: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41643: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41648: aload #6
    //   41650: bipush #12
    //   41652: iconst_0
    //   41653: invokeinterface setAlignedInt : (II)V
    //   41658: aload #6
    //   41660: bipush #15
    //   41662: new org/renjin/gcc/runtime/BytePtr
    //   41665: dup
    //   41666: ldc_w 'devcapture '
    //   41669: invokevirtual getBytes : ()[B
    //   41672: iconst_0
    //   41673: invokespecial <init> : ([BI)V
    //   41676: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41681: aload #6
    //   41683: bipush #16
    //   41685: ldc_w
    //   41688: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41691: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41696: aload #6
    //   41698: bipush #17
    //   41700: iconst_1
    //   41701: invokeinterface setAlignedInt : (II)V
    //   41706: aload #6
    //   41708: bipush #20
    //   41710: new org/renjin/gcc/runtime/BytePtr
    //   41713: dup
    //   41714: ldc_w 'devcontrol '
    //   41717: invokevirtual getBytes : ()[B
    //   41720: iconst_0
    //   41721: invokespecial <init> : ([BI)V
    //   41724: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41729: aload #6
    //   41731: bipush #21
    //   41733: ldc_w
    //   41736: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41739: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41744: aload #6
    //   41746: bipush #22
    //   41748: iconst_1
    //   41749: invokeinterface setAlignedInt : (II)V
    //   41754: aload #6
    //   41756: bipush #25
    //   41758: new org/renjin/gcc/runtime/BytePtr
    //   41761: dup
    //   41762: ldc_w 'devcopy '
    //   41765: invokevirtual getBytes : ()[B
    //   41768: iconst_0
    //   41769: invokespecial <init> : ([BI)V
    //   41772: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41777: aload #6
    //   41779: bipush #26
    //   41781: ldc_w
    //   41784: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41787: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41792: aload #6
    //   41794: bipush #27
    //   41796: iconst_1
    //   41797: invokeinterface setAlignedInt : (II)V
    //   41802: aload #6
    //   41804: bipush #30
    //   41806: new org/renjin/gcc/runtime/BytePtr
    //   41809: dup
    //   41810: ldc_w 'devcur '
    //   41813: invokevirtual getBytes : ()[B
    //   41816: iconst_0
    //   41817: invokespecial <init> : ([BI)V
    //   41820: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41825: aload #6
    //   41827: bipush #31
    //   41829: ldc_w
    //   41832: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41835: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41840: aload #6
    //   41842: bipush #32
    //   41844: iconst_0
    //   41845: invokeinterface setAlignedInt : (II)V
    //   41850: aload #6
    //   41852: bipush #35
    //   41854: new org/renjin/gcc/runtime/BytePtr
    //   41857: dup
    //   41858: ldc_w 'devdisplaylist '
    //   41861: invokevirtual getBytes : ()[B
    //   41864: iconst_0
    //   41865: invokespecial <init> : ([BI)V
    //   41868: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41873: aload #6
    //   41875: bipush #36
    //   41877: ldc_w
    //   41880: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41883: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41888: aload #6
    //   41890: bipush #37
    //   41892: iconst_0
    //   41893: invokeinterface setAlignedInt : (II)V
    //   41898: aload #6
    //   41900: bipush #40
    //   41902: new org/renjin/gcc/runtime/BytePtr
    //   41905: dup
    //   41906: ldc_w 'devholdflush '
    //   41909: invokevirtual getBytes : ()[B
    //   41912: iconst_0
    //   41913: invokespecial <init> : ([BI)V
    //   41916: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41921: aload #6
    //   41923: bipush #41
    //   41925: ldc_w
    //   41928: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41931: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41936: aload #6
    //   41938: bipush #42
    //   41940: iconst_1
    //   41941: invokeinterface setAlignedInt : (II)V
    //   41946: aload #6
    //   41948: bipush #45
    //   41950: new org/renjin/gcc/runtime/BytePtr
    //   41953: dup
    //   41954: ldc_w 'devnext '
    //   41957: invokevirtual getBytes : ()[B
    //   41960: iconst_0
    //   41961: invokespecial <init> : ([BI)V
    //   41964: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41969: aload #6
    //   41971: bipush #46
    //   41973: ldc_w
    //   41976: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   41979: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   41984: aload #6
    //   41986: bipush #47
    //   41988: iconst_1
    //   41989: invokeinterface setAlignedInt : (II)V
    //   41994: aload #6
    //   41996: bipush #50
    //   41998: new org/renjin/gcc/runtime/BytePtr
    //   42001: dup
    //   42002: ldc_w 'devoff '
    //   42005: invokevirtual getBytes : ()[B
    //   42008: iconst_0
    //   42009: invokespecial <init> : ([BI)V
    //   42012: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42017: aload #6
    //   42019: bipush #51
    //   42021: ldc_w
    //   42024: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42027: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42032: aload #6
    //   42034: bipush #52
    //   42036: iconst_1
    //   42037: invokeinterface setAlignedInt : (II)V
    //   42042: aload #6
    //   42044: bipush #55
    //   42046: new org/renjin/gcc/runtime/BytePtr
    //   42049: dup
    //   42050: ldc_w 'devprev '
    //   42053: invokevirtual getBytes : ()[B
    //   42056: iconst_0
    //   42057: invokespecial <init> : ([BI)V
    //   42060: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42065: aload #6
    //   42067: bipush #56
    //   42069: ldc_w
    //   42072: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42075: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42080: aload #6
    //   42082: bipush #57
    //   42084: iconst_1
    //   42085: invokeinterface setAlignedInt : (II)V
    //   42090: aload #6
    //   42092: bipush #60
    //   42094: new org/renjin/gcc/runtime/BytePtr
    //   42097: dup
    //   42098: ldc_w 'devset '
    //   42101: invokevirtual getBytes : ()[B
    //   42104: iconst_0
    //   42105: invokespecial <init> : ([BI)V
    //   42108: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42113: aload #6
    //   42115: bipush #61
    //   42117: ldc_w
    //   42120: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42123: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42128: aload #6
    //   42130: bipush #62
    //   42132: iconst_1
    //   42133: invokeinterface setAlignedInt : (II)V
    //   42138: aload #6
    //   42140: bipush #65
    //   42142: new org/renjin/gcc/runtime/BytePtr
    //   42145: dup
    //   42146: ldc_w 'devsize '
    //   42149: invokevirtual getBytes : ()[B
    //   42152: iconst_0
    //   42153: invokespecial <init> : ([BI)V
    //   42156: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42161: aload #6
    //   42163: bipush #66
    //   42165: ldc_w
    //   42168: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42171: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42176: aload #6
    //   42178: bipush #67
    //   42180: iconst_0
    //   42181: invokeinterface setAlignedInt : (II)V
    //   42186: aload #6
    //   42188: bipush #70
    //   42190: new org/renjin/gcc/runtime/BytePtr
    //   42193: dup
    //   42194: ldc_w 'contourLines '
    //   42197: invokevirtual getBytes : ()[B
    //   42200: iconst_0
    //   42201: invokespecial <init> : ([BI)V
    //   42204: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42209: aload #6
    //   42211: bipush #71
    //   42213: ldc_w
    //   42216: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42219: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42224: aload #6
    //   42226: bipush #72
    //   42228: iconst_4
    //   42229: invokeinterface setAlignedInt : (II)V
    //   42234: aload #6
    //   42236: bipush #75
    //   42238: new org/renjin/gcc/runtime/BytePtr
    //   42241: dup
    //   42242: ldc_w 'getSnapshot '
    //   42245: invokevirtual getBytes : ()[B
    //   42248: iconst_0
    //   42249: invokespecial <init> : ([BI)V
    //   42252: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42257: aload #6
    //   42259: bipush #76
    //   42261: ldc_w
    //   42264: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42267: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42272: aload #6
    //   42274: bipush #77
    //   42276: iconst_0
    //   42277: invokeinterface setAlignedInt : (II)V
    //   42282: aload #6
    //   42284: bipush #80
    //   42286: new org/renjin/gcc/runtime/BytePtr
    //   42289: dup
    //   42290: ldc_w 'playSnapshot '
    //   42293: invokevirtual getBytes : ()[B
    //   42296: iconst_0
    //   42297: invokespecial <init> : ([BI)V
    //   42300: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42305: aload #6
    //   42307: bipush #81
    //   42309: ldc_w
    //   42312: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42315: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42320: aload #6
    //   42322: bipush #82
    //   42324: iconst_1
    //   42325: invokeinterface setAlignedInt : (II)V
    //   42330: aload #6
    //   42332: bipush #85
    //   42334: new org/renjin/gcc/runtime/BytePtr
    //   42337: dup
    //   42338: ldc_w 'getGraphicsEvent '
    //   42341: invokevirtual getBytes : ()[B
    //   42344: iconst_0
    //   42345: invokespecial <init> : ([BI)V
    //   42348: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42353: aload #6
    //   42355: bipush #86
    //   42357: ldc_w
    //   42360: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42363: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42368: aload #6
    //   42370: bipush #87
    //   42372: iconst_1
    //   42373: invokeinterface setAlignedInt : (II)V
    //   42378: aload #6
    //   42380: bipush #90
    //   42382: new org/renjin/gcc/runtime/BytePtr
    //   42385: dup
    //   42386: ldc_w 'getGraphicsEventEnv '
    //   42389: invokevirtual getBytes : ()[B
    //   42392: iconst_0
    //   42393: invokespecial <init> : ([BI)V
    //   42396: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42401: aload #6
    //   42403: bipush #91
    //   42405: ldc_w
    //   42408: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42411: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42416: aload #6
    //   42418: bipush #92
    //   42420: iconst_1
    //   42421: invokeinterface setAlignedInt : (II)V
    //   42426: aload #6
    //   42428: bipush #95
    //   42430: new org/renjin/gcc/runtime/BytePtr
    //   42433: dup
    //   42434: ldc_w 'setGraphicsEventEnv '
    //   42437: invokevirtual getBytes : ()[B
    //   42440: iconst_0
    //   42441: invokespecial <init> : ([BI)V
    //   42444: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42449: aload #6
    //   42451: bipush #96
    //   42453: ldc_w
    //   42456: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42459: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42464: aload #6
    //   42466: bipush #97
    //   42468: iconst_2
    //   42469: invokeinterface setAlignedInt : (II)V
    //   42474: aload #6
    //   42476: bipush #100
    //   42478: new org/renjin/gcc/runtime/BytePtr
    //   42481: dup
    //   42482: ldc_w 'devAskNewPage '
    //   42485: invokevirtual getBytes : ()[B
    //   42488: iconst_0
    //   42489: invokespecial <init> : ([BI)V
    //   42492: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42497: aload #6
    //   42499: bipush #101
    //   42501: ldc_w
    //   42504: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42507: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42512: aload #6
    //   42514: bipush #102
    //   42516: iconst_1
    //   42517: invokeinterface setAlignedInt : (II)V
    //   42522: aload #6
    //   42524: bipush #105
    //   42526: new org/renjin/gcc/runtime/BytePtr
    //   42529: dup
    //   42530: ldc_w 'do_Externalgr '
    //   42533: invokevirtual getBytes : ()[B
    //   42536: iconst_0
    //   42537: invokespecial <init> : ([BI)V
    //   42540: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42545: aload #6
    //   42547: bipush #106
    //   42549: ldc_w
    //   42552: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42555: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42560: aload #6
    //   42562: bipush #107
    //   42564: iconst_m1
    //   42565: invokeinterface setAlignedInt : (II)V
    //   42570: aload #6
    //   42572: bipush #110
    //   42574: new org/renjin/gcc/runtime/BytePtr
    //   42577: dup
    //   42578: ldc_w 'do_dotcallgr '
    //   42581: invokevirtual getBytes : ()[B
    //   42584: iconst_0
    //   42585: invokespecial <init> : ([BI)V
    //   42588: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42593: aload #6
    //   42595: bipush #111
    //   42597: ldc_w
    //   42600: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42603: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42608: aload #6
    //   42610: bipush #112
    //   42612: iconst_m1
    //   42613: invokeinterface setAlignedInt : (II)V
    //   42618: aload #6
    //   42620: bipush #115
    //   42622: new org/renjin/gcc/runtime/BytePtr
    //   42625: dup
    //   42626: ldc_w 'savePlot '
    //   42629: invokevirtual getBytes : ()[B
    //   42632: iconst_0
    //   42633: invokespecial <init> : ([BI)V
    //   42636: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42641: aload #6
    //   42643: bipush #116
    //   42645: ldc_w
    //   42648: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42651: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42656: aload #6
    //   42658: bipush #117
    //   42660: iconst_3
    //   42661: invokeinterface setAlignedInt : (II)V
    //   42666: aload #6
    //   42668: bipush #120
    //   42670: new org/renjin/gcc/runtime/BytePtr
    //   42673: dup
    //   42674: ldc_w 'Quartz '
    //   42677: invokevirtual getBytes : ()[B
    //   42680: iconst_0
    //   42681: invokespecial <init> : ([BI)V
    //   42684: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42689: aload #6
    //   42691: bipush #121
    //   42693: ldc_w
    //   42696: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42699: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42704: aload #6
    //   42706: bipush #122
    //   42708: bipush #11
    //   42710: invokeinterface setAlignedInt : (II)V
    //   42715: aload #6
    //   42717: bipush #125
    //   42719: new org/renjin/gcc/runtime/BytePtr
    //   42722: dup
    //   42723: ldc_w 'X11 '
    //   42726: invokevirtual getBytes : ()[B
    //   42729: iconst_0
    //   42730: invokespecial <init> : ([BI)V
    //   42733: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42738: aload #6
    //   42740: bipush #126
    //   42742: ldc_w
    //   42745: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42748: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42753: aload #6
    //   42755: bipush #127
    //   42757: bipush #17
    //   42759: invokeinterface setAlignedInt : (II)V
    //   42764: aload #6
    //   42766: sipush #130
    //   42769: iconst_0
    //   42770: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   42773: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42778: aload #6
    //   42780: sipush #131
    //   42783: iconst_0
    //   42784: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   42787: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42792: aload #6
    //   42794: sipush #132
    //   42797: iconst_0
    //   42798: invokeinterface setAlignedInt : (II)V
    //   42803: aload_0
    //   42804: getfield init$ExtEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   42807: aload #6
    //   42809: sipush #540
    //   42812: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   42817: sipush #380
    //   42820: invokestatic malloc : (I)Lorg/renjin/gcc/runtime/MixedPtr;
    //   42823: astore #7
    //   42825: aload #7
    //   42827: new org/renjin/gcc/runtime/BytePtr
    //   42830: dup
    //   42831: ldc_w 'Type1FontInUse '
    //   42834: invokevirtual getBytes : ()[B
    //   42837: iconst_0
    //   42838: invokespecial <init> : ([BI)V
    //   42841: invokeinterface setPointer : (Lorg/renjin/gcc/runtime/Ptr;)V
    //   42846: aload #7
    //   42848: iconst_1
    //   42849: ldc_w 'Type1FontInUse'
    //   42852: invokestatic throwingHandle : (Ljava/lang/String;)Ljava/lang/invoke/MethodHandle;
    //   42855: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42858: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42863: aload #7
    //   42865: iconst_2
    //   42866: iconst_2
    //   42867: invokeinterface setAlignedInt : (II)V
    //   42872: aload #7
    //   42874: iconst_5
    //   42875: new org/renjin/gcc/runtime/BytePtr
    //   42878: dup
    //   42879: ldc_w 'CIDFontInUse '
    //   42882: invokevirtual getBytes : ()[B
    //   42885: iconst_0
    //   42886: invokespecial <init> : ([BI)V
    //   42889: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42894: aload #7
    //   42896: bipush #6
    //   42898: ldc_w 'CIDFontInUse'
    //   42901: invokestatic throwingHandle : (Ljava/lang/String;)Ljava/lang/invoke/MethodHandle;
    //   42904: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42907: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42912: aload #7
    //   42914: bipush #7
    //   42916: iconst_2
    //   42917: invokeinterface setAlignedInt : (II)V
    //   42922: aload #7
    //   42924: bipush #10
    //   42926: new org/renjin/gcc/runtime/BytePtr
    //   42929: dup
    //   42930: ldc_w 'R_CreateAtVector '
    //   42933: invokevirtual getBytes : ()[B
    //   42936: iconst_0
    //   42937: invokespecial <init> : ([BI)V
    //   42940: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42945: aload #7
    //   42947: bipush #11
    //   42949: ldc_w
    //   42952: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   42955: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42960: aload #7
    //   42962: bipush #12
    //   42964: iconst_4
    //   42965: invokeinterface setAlignedInt : (II)V
    //   42970: aload #7
    //   42972: bipush #15
    //   42974: new org/renjin/gcc/runtime/BytePtr
    //   42977: dup
    //   42978: ldc_w 'R_GAxisPars '
    //   42981: invokevirtual getBytes : ()[B
    //   42984: iconst_0
    //   42985: invokespecial <init> : ([BI)V
    //   42988: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   42993: aload #7
    //   42995: bipush #16
    //   42997: ldc_w
    //   43000: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43003: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43008: aload #7
    //   43010: bipush #17
    //   43012: iconst_3
    //   43013: invokeinterface setAlignedInt : (II)V
    //   43018: aload #7
    //   43020: bipush #20
    //   43022: new org/renjin/gcc/runtime/BytePtr
    //   43025: dup
    //   43026: ldc_w 'chull '
    //   43029: invokevirtual getBytes : ()[B
    //   43032: iconst_0
    //   43033: invokespecial <init> : ([BI)V
    //   43036: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43041: aload #7
    //   43043: bipush #21
    //   43045: ldc_w
    //   43048: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43051: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43056: aload #7
    //   43058: bipush #22
    //   43060: iconst_1
    //   43061: invokeinterface setAlignedInt : (II)V
    //   43066: aload #7
    //   43068: bipush #25
    //   43070: new org/renjin/gcc/runtime/BytePtr
    //   43073: dup
    //   43074: ldc_w 'gray '
    //   43077: invokevirtual getBytes : ()[B
    //   43080: iconst_0
    //   43081: invokespecial <init> : ([BI)V
    //   43084: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43089: aload #7
    //   43091: bipush #26
    //   43093: ldc_w
    //   43096: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43099: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43104: aload #7
    //   43106: bipush #27
    //   43108: iconst_2
    //   43109: invokeinterface setAlignedInt : (II)V
    //   43114: aload #7
    //   43116: bipush #30
    //   43118: new org/renjin/gcc/runtime/BytePtr
    //   43121: dup
    //   43122: ldc_w 'RGB2hsv '
    //   43125: invokevirtual getBytes : ()[B
    //   43128: iconst_0
    //   43129: invokespecial <init> : ([BI)V
    //   43132: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43137: aload #7
    //   43139: bipush #31
    //   43141: ldc_w
    //   43144: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43147: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43152: aload #7
    //   43154: bipush #32
    //   43156: iconst_1
    //   43157: invokeinterface setAlignedInt : (II)V
    //   43162: aload #7
    //   43164: bipush #35
    //   43166: new org/renjin/gcc/runtime/BytePtr
    //   43169: dup
    //   43170: ldc_w 'rgb '
    //   43173: invokevirtual getBytes : ()[B
    //   43176: iconst_0
    //   43177: invokespecial <init> : ([BI)V
    //   43180: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43185: aload #7
    //   43187: bipush #36
    //   43189: ldc_w
    //   43192: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43195: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43200: aload #7
    //   43202: bipush #37
    //   43204: bipush #6
    //   43206: invokeinterface setAlignedInt : (II)V
    //   43211: aload #7
    //   43213: bipush #40
    //   43215: new org/renjin/gcc/runtime/BytePtr
    //   43218: dup
    //   43219: ldc_w 'hsv '
    //   43222: invokevirtual getBytes : ()[B
    //   43225: iconst_0
    //   43226: invokespecial <init> : ([BI)V
    //   43229: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43234: aload #7
    //   43236: bipush #41
    //   43238: ldc_w
    //   43241: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43244: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43249: aload #7
    //   43251: bipush #42
    //   43253: iconst_4
    //   43254: invokeinterface setAlignedInt : (II)V
    //   43259: aload #7
    //   43261: bipush #45
    //   43263: new org/renjin/gcc/runtime/BytePtr
    //   43266: dup
    //   43267: ldc_w 'hcl '
    //   43270: invokevirtual getBytes : ()[B
    //   43273: iconst_0
    //   43274: invokespecial <init> : ([BI)V
    //   43277: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43282: aload #7
    //   43284: bipush #46
    //   43286: ldc_w
    //   43289: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43292: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43297: aload #7
    //   43299: bipush #47
    //   43301: iconst_5
    //   43302: invokeinterface setAlignedInt : (II)V
    //   43307: aload #7
    //   43309: bipush #50
    //   43311: new org/renjin/gcc/runtime/BytePtr
    //   43314: dup
    //   43315: ldc_w 'col2rgb '
    //   43318: invokevirtual getBytes : ()[B
    //   43321: iconst_0
    //   43322: invokespecial <init> : ([BI)V
    //   43325: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43330: aload #7
    //   43332: bipush #51
    //   43334: ldc_w
    //   43337: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43340: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43345: aload #7
    //   43347: bipush #52
    //   43349: iconst_2
    //   43350: invokeinterface setAlignedInt : (II)V
    //   43355: aload #7
    //   43357: bipush #55
    //   43359: new org/renjin/gcc/runtime/BytePtr
    //   43362: dup
    //   43363: ldc_w 'colors '
    //   43366: invokevirtual getBytes : ()[B
    //   43369: iconst_0
    //   43370: invokespecial <init> : ([BI)V
    //   43373: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43378: aload #7
    //   43380: bipush #56
    //   43382: ldc_w
    //   43385: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43388: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43393: aload #7
    //   43395: bipush #57
    //   43397: iconst_0
    //   43398: invokeinterface setAlignedInt : (II)V
    //   43403: aload #7
    //   43405: bipush #60
    //   43407: new org/renjin/gcc/runtime/BytePtr
    //   43410: dup
    //   43411: ldc_w 'palette '
    //   43414: invokevirtual getBytes : ()[B
    //   43417: iconst_0
    //   43418: invokespecial <init> : ([BI)V
    //   43421: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43426: aload #7
    //   43428: bipush #61
    //   43430: ldc_w
    //   43433: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43436: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43441: aload #7
    //   43443: bipush #62
    //   43445: iconst_1
    //   43446: invokeinterface setAlignedInt : (II)V
    //   43451: aload #7
    //   43453: bipush #65
    //   43455: new org/renjin/gcc/runtime/BytePtr
    //   43458: dup
    //   43459: ldc_w 'palette2 '
    //   43462: invokevirtual getBytes : ()[B
    //   43465: iconst_0
    //   43466: invokespecial <init> : ([BI)V
    //   43469: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43474: aload #7
    //   43476: bipush #66
    //   43478: ldc_w
    //   43481: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43484: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43489: aload #7
    //   43491: bipush #67
    //   43493: iconst_1
    //   43494: invokeinterface setAlignedInt : (II)V
    //   43499: aload #7
    //   43501: bipush #70
    //   43503: new org/renjin/gcc/runtime/BytePtr
    //   43506: dup
    //   43507: ldc_w 'newJavaGD '
    //   43510: invokevirtual getBytes : ()[B
    //   43513: iconst_0
    //   43514: invokespecial <init> : ([BI)V
    //   43517: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43522: aload #7
    //   43524: bipush #71
    //   43526: ldc_w
    //   43529: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43532: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43537: aload #7
    //   43539: bipush #72
    //   43541: iconst_4
    //   43542: invokeinterface setAlignedInt : (II)V
    //   43547: aload #7
    //   43549: bipush #75
    //   43551: new org/renjin/gcc/runtime/BytePtr
    //   43554: dup
    //   43555: ldc_w 'recordGraphics '
    //   43558: invokevirtual getBytes : ()[B
    //   43561: iconst_0
    //   43562: invokespecial <init> : ([BI)V
    //   43565: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43570: aload #7
    //   43572: bipush #76
    //   43574: ldc_w
    //   43577: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43580: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43585: aload #7
    //   43587: bipush #77
    //   43589: iconst_3
    //   43590: invokeinterface setAlignedInt : (II)V
    //   43595: aload #7
    //   43597: bipush #80
    //   43599: new org/renjin/gcc/runtime/BytePtr
    //   43602: dup
    //   43603: ldc_w 'makeQuartzDefault '
    //   43606: invokevirtual getBytes : ()[B
    //   43609: iconst_0
    //   43610: invokespecial <init> : ([BI)V
    //   43613: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43618: aload #7
    //   43620: bipush #81
    //   43622: ldc_w
    //   43625: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43628: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43633: aload #7
    //   43635: bipush #82
    //   43637: iconst_0
    //   43638: invokeinterface setAlignedInt : (II)V
    //   43643: aload #7
    //   43645: bipush #85
    //   43647: new org/renjin/gcc/runtime/BytePtr
    //   43650: dup
    //   43651: ldc_w 'cairoProps '
    //   43654: invokevirtual getBytes : ()[B
    //   43657: iconst_0
    //   43658: invokespecial <init> : ([BI)V
    //   43661: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43666: aload #7
    //   43668: bipush #86
    //   43670: ldc_w
    //   43673: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
    //   43676: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43681: aload #7
    //   43683: bipush #87
    //   43685: iconst_1
    //   43686: invokeinterface setAlignedInt : (II)V
    //   43691: aload #7
    //   43693: bipush #90
    //   43695: iconst_0
    //   43696: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   43699: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43704: aload #7
    //   43706: bipush #91
    //   43708: iconst_0
    //   43709: invokestatic of : (I)Lorg/renjin/gcc/runtime/Ptr;
    //   43712: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
    //   43717: aload #7
    //   43719: bipush #92
    //   43721: iconst_0
    //   43722: invokeinterface setAlignedInt : (II)V
    //   43727: aload_0
    //   43728: getfield init$CallEntries : Lorg/renjin/gcc/runtime/Ptr;
    //   43731: aload #7
    //   43733: sipush #380
    //   43736: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
    //   43741: aload_0
    //   43742: dconst_1
    //   43743: putfield javaGD$jGDasp : D
    //   43746: aload_0
    //   43747: ldc2_w 100.0
    //   43750: putfield javaGD$jGDdpiY : D
    //   43753: aload_0
    //   43754: ldc2_w 100.0
    //   43757: putfield javaGD$jGDdpiX : D
    //   43760: sipush #224
    //   43763: newarray int
    //   43765: dup
    //   43766: iconst_0
    //   43767: bipush #32
    //   43769: iastore
    //   43770: dup
    //   43771: iconst_1
    //   43772: bipush #33
    //   43774: iastore
    //   43775: dup
    //   43776: iconst_2
    //   43777: sipush #8704
    //   43780: iastore
    //   43781: dup
    //   43782: iconst_3
    //   43783: bipush #35
    //   43785: iastore
    //   43786: dup
    //   43787: iconst_4
    //   43788: sipush #8707
    //   43791: iastore
    //   43792: dup
    //   43793: iconst_5
    //   43794: bipush #37
    //   43796: iastore
    //   43797: dup
    //   43798: bipush #6
    //   43800: bipush #38
    //   43802: iastore
    //   43803: dup
    //   43804: bipush #7
    //   43806: sipush #8717
    //   43809: iastore
    //   43810: dup
    //   43811: bipush #8
    //   43813: bipush #40
    //   43815: iastore
    //   43816: dup
    //   43817: bipush #9
    //   43819: bipush #41
    //   43821: iastore
    //   43822: dup
    //   43823: bipush #10
    //   43825: sipush #8727
    //   43828: iastore
    //   43829: dup
    //   43830: bipush #11
    //   43832: bipush #43
    //   43834: iastore
    //   43835: dup
    //   43836: bipush #12
    //   43838: bipush #44
    //   43840: iastore
    //   43841: dup
    //   43842: bipush #13
    //   43844: sipush #8722
    //   43847: iastore
    //   43848: dup
    //   43849: bipush #14
    //   43851: bipush #46
    //   43853: iastore
    //   43854: dup
    //   43855: bipush #15
    //   43857: bipush #47
    //   43859: iastore
    //   43860: dup
    //   43861: bipush #16
    //   43863: bipush #48
    //   43865: iastore
    //   43866: dup
    //   43867: bipush #17
    //   43869: bipush #49
    //   43871: iastore
    //   43872: dup
    //   43873: bipush #18
    //   43875: bipush #50
    //   43877: iastore
    //   43878: dup
    //   43879: bipush #19
    //   43881: bipush #51
    //   43883: iastore
    //   43884: dup
    //   43885: bipush #20
    //   43887: bipush #52
    //   43889: iastore
    //   43890: dup
    //   43891: bipush #21
    //   43893: bipush #53
    //   43895: iastore
    //   43896: dup
    //   43897: bipush #22
    //   43899: bipush #54
    //   43901: iastore
    //   43902: dup
    //   43903: bipush #23
    //   43905: bipush #55
    //   43907: iastore
    //   43908: dup
    //   43909: bipush #24
    //   43911: bipush #56
    //   43913: iastore
    //   43914: dup
    //   43915: bipush #25
    //   43917: bipush #57
    //   43919: iastore
    //   43920: dup
    //   43921: bipush #26
    //   43923: bipush #58
    //   43925: iastore
    //   43926: dup
    //   43927: bipush #27
    //   43929: bipush #59
    //   43931: iastore
    //   43932: dup
    //   43933: bipush #28
    //   43935: bipush #60
    //   43937: iastore
    //   43938: dup
    //   43939: bipush #29
    //   43941: bipush #61
    //   43943: iastore
    //   43944: dup
    //   43945: bipush #30
    //   43947: bipush #62
    //   43949: iastore
    //   43950: dup
    //   43951: bipush #31
    //   43953: bipush #63
    //   43955: iastore
    //   43956: dup
    //   43957: bipush #32
    //   43959: sipush #8773
    //   43962: iastore
    //   43963: dup
    //   43964: bipush #33
    //   43966: sipush #913
    //   43969: iastore
    //   43970: dup
    //   43971: bipush #34
    //   43973: sipush #914
    //   43976: iastore
    //   43977: dup
    //   43978: bipush #35
    //   43980: sipush #935
    //   43983: iastore
    //   43984: dup
    //   43985: bipush #36
    //   43987: sipush #916
    //   43990: iastore
    //   43991: dup
    //   43992: bipush #37
    //   43994: sipush #917
    //   43997: iastore
    //   43998: dup
    //   43999: bipush #38
    //   44001: sipush #934
    //   44004: iastore
    //   44005: dup
    //   44006: bipush #39
    //   44008: sipush #915
    //   44011: iastore
    //   44012: dup
    //   44013: bipush #40
    //   44015: sipush #919
    //   44018: iastore
    //   44019: dup
    //   44020: bipush #41
    //   44022: sipush #921
    //   44025: iastore
    //   44026: dup
    //   44027: bipush #42
    //   44029: sipush #977
    //   44032: iastore
    //   44033: dup
    //   44034: bipush #43
    //   44036: sipush #922
    //   44039: iastore
    //   44040: dup
    //   44041: bipush #44
    //   44043: sipush #923
    //   44046: iastore
    //   44047: dup
    //   44048: bipush #45
    //   44050: sipush #924
    //   44053: iastore
    //   44054: dup
    //   44055: bipush #46
    //   44057: sipush #925
    //   44060: iastore
    //   44061: dup
    //   44062: bipush #47
    //   44064: sipush #927
    //   44067: iastore
    //   44068: dup
    //   44069: bipush #48
    //   44071: sipush #928
    //   44074: iastore
    //   44075: dup
    //   44076: bipush #49
    //   44078: sipush #920
    //   44081: iastore
    //   44082: dup
    //   44083: bipush #50
    //   44085: sipush #929
    //   44088: iastore
    //   44089: dup
    //   44090: bipush #51
    //   44092: sipush #931
    //   44095: iastore
    //   44096: dup
    //   44097: bipush #52
    //   44099: sipush #932
    //   44102: iastore
    //   44103: dup
    //   44104: bipush #53
    //   44106: sipush #933
    //   44109: iastore
    //   44110: dup
    //   44111: bipush #54
    //   44113: sipush #962
    //   44116: iastore
    //   44117: dup
    //   44118: bipush #55
    //   44120: sipush #937
    //   44123: iastore
    //   44124: dup
    //   44125: bipush #56
    //   44127: sipush #926
    //   44130: iastore
    //   44131: dup
    //   44132: bipush #57
    //   44134: sipush #936
    //   44137: iastore
    //   44138: dup
    //   44139: bipush #58
    //   44141: sipush #918
    //   44144: iastore
    //   44145: dup
    //   44146: bipush #59
    //   44148: bipush #91
    //   44150: iastore
    //   44151: dup
    //   44152: bipush #60
    //   44154: sipush #8756
    //   44157: iastore
    //   44158: dup
    //   44159: bipush #61
    //   44161: bipush #93
    //   44163: iastore
    //   44164: dup
    //   44165: bipush #62
    //   44167: sipush #8869
    //   44170: iastore
    //   44171: dup
    //   44172: bipush #63
    //   44174: bipush #95
    //   44176: iastore
    //   44177: dup
    //   44178: bipush #64
    //   44180: ldc_w 63717
    //   44183: iastore
    //   44184: dup
    //   44185: bipush #65
    //   44187: sipush #945
    //   44190: iastore
    //   44191: dup
    //   44192: bipush #66
    //   44194: sipush #946
    //   44197: iastore
    //   44198: dup
    //   44199: bipush #67
    //   44201: sipush #967
    //   44204: iastore
    //   44205: dup
    //   44206: bipush #68
    //   44208: sipush #948
    //   44211: iastore
    //   44212: dup
    //   44213: bipush #69
    //   44215: sipush #949
    //   44218: iastore
    //   44219: dup
    //   44220: bipush #70
    //   44222: sipush #966
    //   44225: iastore
    //   44226: dup
    //   44227: bipush #71
    //   44229: sipush #947
    //   44232: iastore
    //   44233: dup
    //   44234: bipush #72
    //   44236: sipush #951
    //   44239: iastore
    //   44240: dup
    //   44241: bipush #73
    //   44243: sipush #953
    //   44246: iastore
    //   44247: dup
    //   44248: bipush #74
    //   44250: sipush #981
    //   44253: iastore
    //   44254: dup
    //   44255: bipush #75
    //   44257: sipush #954
    //   44260: iastore
    //   44261: dup
    //   44262: bipush #76
    //   44264: sipush #955
    //   44267: iastore
    //   44268: dup
    //   44269: bipush #77
    //   44271: sipush #956
    //   44274: iastore
    //   44275: dup
    //   44276: bipush #78
    //   44278: sipush #957
    //   44281: iastore
    //   44282: dup
    //   44283: bipush #79
    //   44285: sipush #959
    //   44288: iastore
    //   44289: dup
    //   44290: bipush #80
    //   44292: sipush #960
    //   44295: iastore
    //   44296: dup
    //   44297: bipush #81
    //   44299: sipush #952
    //   44302: iastore
    //   44303: dup
    //   44304: bipush #82
    //   44306: sipush #961
    //   44309: iastore
    //   44310: dup
    //   44311: bipush #83
    //   44313: sipush #963
    //   44316: iastore
    //   44317: dup
    //   44318: bipush #84
    //   44320: sipush #964
    //   44323: iastore
    //   44324: dup
    //   44325: bipush #85
    //   44327: sipush #965
    //   44330: iastore
    //   44331: dup
    //   44332: bipush #86
    //   44334: sipush #982
    //   44337: iastore
    //   44338: dup
    //   44339: bipush #87
    //   44341: sipush #969
    //   44344: iastore
    //   44345: dup
    //   44346: bipush #88
    //   44348: sipush #958
    //   44351: iastore
    //   44352: dup
    //   44353: bipush #89
    //   44355: sipush #968
    //   44358: iastore
    //   44359: dup
    //   44360: bipush #90
    //   44362: sipush #950
    //   44365: iastore
    //   44366: dup
    //   44367: bipush #91
    //   44369: bipush #123
    //   44371: iastore
    //   44372: dup
    //   44373: bipush #92
    //   44375: bipush #124
    //   44377: iastore
    //   44378: dup
    //   44379: bipush #93
    //   44381: bipush #125
    //   44383: iastore
    //   44384: dup
    //   44385: bipush #94
    //   44387: sipush #8764
    //   44390: iastore
    //   44391: dup
    //   44392: bipush #95
    //   44394: bipush #32
    //   44396: iastore
    //   44397: dup
    //   44398: bipush #96
    //   44400: bipush #32
    //   44402: iastore
    //   44403: dup
    //   44404: bipush #97
    //   44406: bipush #32
    //   44408: iastore
    //   44409: dup
    //   44410: bipush #98
    //   44412: bipush #32
    //   44414: iastore
    //   44415: dup
    //   44416: bipush #99
    //   44418: bipush #32
    //   44420: iastore
    //   44421: dup
    //   44422: bipush #100
    //   44424: bipush #32
    //   44426: iastore
    //   44427: dup
    //   44428: bipush #101
    //   44430: bipush #32
    //   44432: iastore
    //   44433: dup
    //   44434: bipush #102
    //   44436: bipush #32
    //   44438: iastore
    //   44439: dup
    //   44440: bipush #103
    //   44442: bipush #32
    //   44444: iastore
    //   44445: dup
    //   44446: bipush #104
    //   44448: bipush #32
    //   44450: iastore
    //   44451: dup
    //   44452: bipush #105
    //   44454: bipush #32
    //   44456: iastore
    //   44457: dup
    //   44458: bipush #106
    //   44460: bipush #32
    //   44462: iastore
    //   44463: dup
    //   44464: bipush #107
    //   44466: bipush #32
    //   44468: iastore
    //   44469: dup
    //   44470: bipush #108
    //   44472: bipush #32
    //   44474: iastore
    //   44475: dup
    //   44476: bipush #109
    //   44478: bipush #32
    //   44480: iastore
    //   44481: dup
    //   44482: bipush #110
    //   44484: bipush #32
    //   44486: iastore
    //   44487: dup
    //   44488: bipush #111
    //   44490: bipush #32
    //   44492: iastore
    //   44493: dup
    //   44494: bipush #112
    //   44496: bipush #32
    //   44498: iastore
    //   44499: dup
    //   44500: bipush #113
    //   44502: bipush #32
    //   44504: iastore
    //   44505: dup
    //   44506: bipush #114
    //   44508: bipush #32
    //   44510: iastore
    //   44511: dup
    //   44512: bipush #115
    //   44514: bipush #32
    //   44516: iastore
    //   44517: dup
    //   44518: bipush #116
    //   44520: bipush #32
    //   44522: iastore
    //   44523: dup
    //   44524: bipush #117
    //   44526: bipush #32
    //   44528: iastore
    //   44529: dup
    //   44530: bipush #118
    //   44532: bipush #32
    //   44534: iastore
    //   44535: dup
    //   44536: bipush #119
    //   44538: bipush #32
    //   44540: iastore
    //   44541: dup
    //   44542: bipush #120
    //   44544: bipush #32
    //   44546: iastore
    //   44547: dup
    //   44548: bipush #121
    //   44550: bipush #32
    //   44552: iastore
    //   44553: dup
    //   44554: bipush #122
    //   44556: bipush #32
    //   44558: iastore
    //   44559: dup
    //   44560: bipush #123
    //   44562: bipush #32
    //   44564: iastore
    //   44565: dup
    //   44566: bipush #124
    //   44568: bipush #32
    //   44570: iastore
    //   44571: dup
    //   44572: bipush #125
    //   44574: bipush #32
    //   44576: iastore
    //   44577: dup
    //   44578: bipush #126
    //   44580: bipush #32
    //   44582: iastore
    //   44583: dup
    //   44584: bipush #127
    //   44586: bipush #32
    //   44588: iastore
    //   44589: dup
    //   44590: sipush #128
    //   44593: sipush #8364
    //   44596: iastore
    //   44597: dup
    //   44598: sipush #129
    //   44601: sipush #978
    //   44604: iastore
    //   44605: dup
    //   44606: sipush #130
    //   44609: sipush #8242
    //   44612: iastore
    //   44613: dup
    //   44614: sipush #131
    //   44617: sipush #8804
    //   44620: iastore
    //   44621: dup
    //   44622: sipush #132
    //   44625: sipush #8260
    //   44628: iastore
    //   44629: dup
    //   44630: sipush #133
    //   44633: sipush #8734
    //   44636: iastore
    //   44637: dup
    //   44638: sipush #134
    //   44641: sipush #402
    //   44644: iastore
    //   44645: dup
    //   44646: sipush #135
    //   44649: sipush #9827
    //   44652: iastore
    //   44653: dup
    //   44654: sipush #136
    //   44657: sipush #9830
    //   44660: iastore
    //   44661: dup
    //   44662: sipush #137
    //   44665: sipush #9829
    //   44668: iastore
    //   44669: dup
    //   44670: sipush #138
    //   44673: sipush #9824
    //   44676: iastore
    //   44677: dup
    //   44678: sipush #139
    //   44681: sipush #8596
    //   44684: iastore
    //   44685: dup
    //   44686: sipush #140
    //   44689: sipush #8592
    //   44692: iastore
    //   44693: dup
    //   44694: sipush #141
    //   44697: sipush #8593
    //   44700: iastore
    //   44701: dup
    //   44702: sipush #142
    //   44705: sipush #8594
    //   44708: iastore
    //   44709: dup
    //   44710: sipush #143
    //   44713: sipush #8595
    //   44716: iastore
    //   44717: dup
    //   44718: sipush #144
    //   44721: sipush #176
    //   44724: iastore
    //   44725: dup
    //   44726: sipush #145
    //   44729: sipush #177
    //   44732: iastore
    //   44733: dup
    //   44734: sipush #146
    //   44737: sipush #8243
    //   44740: iastore
    //   44741: dup
    //   44742: sipush #147
    //   44745: sipush #8805
    //   44748: iastore
    //   44749: dup
    //   44750: sipush #148
    //   44753: sipush #215
    //   44756: iastore
    //   44757: dup
    //   44758: sipush #149
    //   44761: sipush #8733
    //   44764: iastore
    //   44765: dup
    //   44766: sipush #150
    //   44769: sipush #8706
    //   44772: iastore
    //   44773: dup
    //   44774: sipush #151
    //   44777: sipush #8226
    //   44780: iastore
    //   44781: dup
    //   44782: sipush #152
    //   44785: sipush #247
    //   44788: iastore
    //   44789: dup
    //   44790: sipush #153
    //   44793: sipush #8800
    //   44796: iastore
    //   44797: dup
    //   44798: sipush #154
    //   44801: sipush #8801
    //   44804: iastore
    //   44805: dup
    //   44806: sipush #155
    //   44809: sipush #8776
    //   44812: iastore
    //   44813: dup
    //   44814: sipush #156
    //   44817: sipush #8230
    //   44820: iastore
    //   44821: dup
    //   44822: sipush #157
    //   44825: ldc_w 63718
    //   44828: iastore
    //   44829: dup
    //   44830: sipush #158
    //   44833: ldc_w 63719
    //   44836: iastore
    //   44837: dup
    //   44838: sipush #159
    //   44841: sipush #8629
    //   44844: iastore
    //   44845: dup
    //   44846: sipush #160
    //   44849: sipush #8501
    //   44852: iastore
    //   44853: dup
    //   44854: sipush #161
    //   44857: sipush #8465
    //   44860: iastore
    //   44861: dup
    //   44862: sipush #162
    //   44865: sipush #8476
    //   44868: iastore
    //   44869: dup
    //   44870: sipush #163
    //   44873: sipush #8472
    //   44876: iastore
    //   44877: dup
    //   44878: sipush #164
    //   44881: sipush #8855
    //   44884: iastore
    //   44885: dup
    //   44886: sipush #165
    //   44889: sipush #8853
    //   44892: iastore
    //   44893: dup
    //   44894: sipush #166
    //   44897: sipush #8709
    //   44900: iastore
    //   44901: dup
    //   44902: sipush #167
    //   44905: sipush #8745
    //   44908: iastore
    //   44909: dup
    //   44910: sipush #168
    //   44913: sipush #8746
    //   44916: iastore
    //   44917: dup
    //   44918: sipush #169
    //   44921: sipush #8835
    //   44924: iastore
    //   44925: dup
    //   44926: sipush #170
    //   44929: sipush #8839
    //   44932: iastore
    //   44933: dup
    //   44934: sipush #171
    //   44937: sipush #8836
    //   44940: iastore
    //   44941: dup
    //   44942: sipush #172
    //   44945: sipush #8834
    //   44948: iastore
    //   44949: dup
    //   44950: sipush #173
    //   44953: sipush #8838
    //   44956: iastore
    //   44957: dup
    //   44958: sipush #174
    //   44961: sipush #8712
    //   44964: iastore
    //   44965: dup
    //   44966: sipush #175
    //   44969: sipush #8713
    //   44972: iastore
    //   44973: dup
    //   44974: sipush #176
    //   44977: sipush #8736
    //   44980: iastore
    //   44981: dup
    //   44982: sipush #177
    //   44985: sipush #8711
    //   44988: iastore
    //   44989: dup
    //   44990: sipush #178
    //   44993: ldc_w 63194
    //   44996: iastore
    //   44997: dup
    //   44998: sipush #179
    //   45001: ldc_w 63193
    //   45004: iastore
    //   45005: dup
    //   45006: sipush #180
    //   45009: ldc_w 63195
    //   45012: iastore
    //   45013: dup
    //   45014: sipush #181
    //   45017: sipush #8719
    //   45020: iastore
    //   45021: dup
    //   45022: sipush #182
    //   45025: sipush #8730
    //   45028: iastore
    //   45029: dup
    //   45030: sipush #183
    //   45033: sipush #8901
    //   45036: iastore
    //   45037: dup
    //   45038: sipush #184
    //   45041: sipush #172
    //   45044: iastore
    //   45045: dup
    //   45046: sipush #185
    //   45049: sipush #8743
    //   45052: iastore
    //   45053: dup
    //   45054: sipush #186
    //   45057: sipush #8744
    //   45060: iastore
    //   45061: dup
    //   45062: sipush #187
    //   45065: sipush #8660
    //   45068: iastore
    //   45069: dup
    //   45070: sipush #188
    //   45073: sipush #8656
    //   45076: iastore
    //   45077: dup
    //   45078: sipush #189
    //   45081: sipush #8657
    //   45084: iastore
    //   45085: dup
    //   45086: sipush #190
    //   45089: sipush #8658
    //   45092: iastore
    //   45093: dup
    //   45094: sipush #191
    //   45097: sipush #8659
    //   45100: iastore
    //   45101: dup
    //   45102: sipush #192
    //   45105: sipush #9674
    //   45108: iastore
    //   45109: dup
    //   45110: sipush #193
    //   45113: sipush #9001
    //   45116: iastore
    //   45117: dup
    //   45118: sipush #194
    //   45121: ldc_w 63720
    //   45124: iastore
    //   45125: dup
    //   45126: sipush #195
    //   45129: ldc_w 63721
    //   45132: iastore
    //   45133: dup
    //   45134: sipush #196
    //   45137: ldc_w 63722
    //   45140: iastore
    //   45141: dup
    //   45142: sipush #197
    //   45145: sipush #8721
    //   45148: iastore
    //   45149: dup
    //   45150: sipush #198
    //   45153: ldc_w 63723
    //   45156: iastore
    //   45157: dup
    //   45158: sipush #199
    //   45161: ldc_w 63724
    //   45164: iastore
    //   45165: dup
    //   45166: sipush #200
    //   45169: ldc_w 63725
    //   45172: iastore
    //   45173: dup
    //   45174: sipush #201
    //   45177: ldc_w 63726
    //   45180: iastore
    //   45181: dup
    //   45182: sipush #202
    //   45185: ldc_w 63727
    //   45188: iastore
    //   45189: dup
    //   45190: sipush #203
    //   45193: ldc_w 63728
    //   45196: iastore
    //   45197: dup
    //   45198: sipush #204
    //   45201: ldc_w 63729
    //   45204: iastore
    //   45205: dup
    //   45206: sipush #205
    //   45209: ldc_w 63730
    //   45212: iastore
    //   45213: dup
    //   45214: sipush #206
    //   45217: ldc_w 63731
    //   45220: iastore
    //   45221: dup
    //   45222: sipush #207
    //   45225: ldc_w 63732
    //   45228: iastore
    //   45229: dup
    //   45230: sipush #208
    //   45233: bipush #32
    //   45235: iastore
    //   45236: dup
    //   45237: sipush #209
    //   45240: sipush #9002
    //   45243: iastore
    //   45244: dup
    //   45245: sipush #210
    //   45248: sipush #8747
    //   45251: iastore
    //   45252: dup
    //   45253: sipush #211
    //   45256: sipush #8992
    //   45259: iastore
    //   45260: dup
    //   45261: sipush #212
    //   45264: ldc_w 63733
    //   45267: iastore
    //   45268: dup
    //   45269: sipush #213
    //   45272: sipush #8993
    //   45275: iastore
    //   45276: dup
    //   45277: sipush #214
    //   45280: ldc_w 63734
    //   45283: iastore
    //   45284: dup
    //   45285: sipush #215
    //   45288: ldc_w 63735
    //   45291: iastore
    //   45292: dup
    //   45293: sipush #216
    //   45296: ldc_w 63736
    //   45299: iastore
    //   45300: dup
    //   45301: sipush #217
    //   45304: ldc_w 63737
    //   45307: iastore
    //   45308: dup
    //   45309: sipush #218
    //   45312: ldc_w 63738
    //   45315: iastore
    //   45316: dup
    //   45317: sipush #219
    //   45320: ldc_w 63739
    //   45323: iastore
    //   45324: dup
    //   45325: sipush #220
    //   45328: ldc_w 63740
    //   45331: iastore
    //   45332: dup
    //   45333: sipush #221
    //   45336: ldc_w 63741
    //   45339: iastore
    //   45340: dup
    //   45341: sipush #222
    //   45344: ldc_w 63742
    //   45347: iastore
    //   45348: dup
    //   45349: sipush #223
    //   45352: bipush #32
    //   45354: iastore
    //   45355: iconst_0
    //   45356: aload_0
    //   45357: getfield s2u$s2u : [I
    //   45360: iconst_0
    //   45361: sipush #224
    //   45364: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   45367: return
  }
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */