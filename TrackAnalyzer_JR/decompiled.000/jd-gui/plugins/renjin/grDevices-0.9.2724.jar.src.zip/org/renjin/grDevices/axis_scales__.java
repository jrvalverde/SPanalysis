/*    */ package org.renjin.grDevices;
/*    */ 
/*    */ import org.renjin.gcc.runtime.BytePtr;
/*    */ import org.renjin.gcc.runtime.PointerPtr;
/*    */ import org.renjin.gcc.runtime.Ptr;
/*    */ import org.renjin.gcc.runtime.UnsatisfiedLinkException;
/*    */ import org.renjin.gnur.api.Error;
/*    */ import org.renjin.gnur.api.GetText;
/*    */ import org.renjin.gnur.api.Rinternals;
/*    */ import org.renjin.gnur.api.Rinternals2;
/*    */ import org.renjin.sexp.SEXP;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class axis_scales__
/*    */ {
/*    */   static {
/*    */   
/*    */   }
/*    */   
/*    */   public static SEXP R_CreateAtVector(SEXP axp, SEXP usr, SEXP nint, SEXP is_log) {
/* 32 */     nint_v = Rinternals.Rf_asInteger(nint);
/* 33 */     logflag = Rinternals.Rf_asLogical(is_log);
/*    */     
/* 35 */     axp = Rinternals.Rf_coerceVector(axp, 14); Rinternals.Rf_protect(axp);
/* 36 */     usr = Rinternals.Rf_coerceVector(usr, 14); Rinternals.Rf_protect(usr);
/* 37 */     if (Rinternals.LENGTH(axp) != 3) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("'%s' must be numeric of length %d\000".getBytes(), 0)), new Object[] { new BytePtr("axp\000".getBytes(), 0), Integer.valueOf(3) }); 
/* 38 */     if (Rinternals.LENGTH(usr) != 2) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("'%s' must be numeric of length %d\000".getBytes(), 0)), new Object[] { new BytePtr("usr\000".getBytes(), 0), Integer.valueOf(2) });
/*    */     
/* 40 */     Ptr ptr2 = Rinternals2.REAL(usr), ptr1 = Rinternals2.REAL(axp); throw new UnsatisfiedLinkException("Rf_CreateAtVector");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SEXP R_GAxisPars(SEXP usr, SEXP is_log, SEXP nintLog) {
/* 48 */     PointerPtr pointerPtr = PointerPtr.malloc(12); max = new double[1]; min = new double[1]; n = new int[1]; logflag = Rinternals.Rf_asLogical(is_log);
/* 49 */     n$0 = Rinternals.Rf_asInteger(nintLog); n[0] = n$0;
/*    */     
/* 51 */     pointerPtr.setPointer((Ptr)new BytePtr("axp\000".getBytes(), 0)); pointerPtr.setAlignedPointer(1, (Ptr)new BytePtr("n\000".getBytes(), 0)); pointerPtr.setAlignedPointer(2, (Ptr)new BytePtr("\000".getBytes(), 0));
/*    */ 
/*    */     
/* 54 */     usr = Rinternals.Rf_coerceVector(usr, 14);
/* 55 */     if (Rinternals.LENGTH(usr) != 2) Error.Rf_error(GetText.dgettext(new BytePtr("grDevices\000".getBytes(), 0), new BytePtr("'%s' must be numeric of length %d\000".getBytes(), 0)), new Object[] { new BytePtr("usr\000".getBytes(), 0), Integer.valueOf(2) }); 
/* 56 */     min$1 = Rinternals2.REAL(usr).getDouble(); min[0] = min$1;
/* 57 */     max$2 = Rinternals2.REAL(usr).getDouble(8); max[0] = max$2;
/*    */     
/* 59 */     throw new UnsatisfiedLinkException("Rf_GAxisPars");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/axis_scales__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */