/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.Ptr;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class jGDtalk__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static int initJavaGD(Ptr xd, Ptr driverClass, SEXP deviceOptions) {
/*  56 */     Ptr ptr = GraphicsDevices.newDevice(driverClass, deviceOptions); xd.setAlignedPointer(15, ptr);
/*  57 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendGC(Ptr xd, Ptr gc, int sendAll) {
/*     */     // Byte code:
/*     */     //   0: iload_2
/*     */     //   1: ifne -> 35
/*     */     //   4: goto -> 7
/*     */     //   7: aload_1
/*     */     //   8: invokeinterface getInt : ()I
/*     */     //   13: istore #51
/*     */     //   15: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   18: invokeinterface getInt : ()I
/*     */     //   23: istore #50
/*     */     //   25: iload #51
/*     */     //   27: iload #50
/*     */     //   29: if_icmpne -> 35
/*     */     //   32: goto -> 56
/*     */     //   35: aload_1
/*     */     //   36: invokeinterface getInt : ()I
/*     */     //   41: istore #49
/*     */     //   43: aload_0
/*     */     //   44: bipush #15
/*     */     //   46: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   51: iload #49
/*     */     //   53: invokestatic setColor : (Lorg/renjin/gcc/runtime/Ptr;I)V
/*     */     //   56: iload_2
/*     */     //   57: ifne -> 93
/*     */     //   60: goto -> 63
/*     */     //   63: aload_1
/*     */     //   64: iconst_1
/*     */     //   65: invokeinterface getAlignedInt : (I)I
/*     */     //   70: istore #46
/*     */     //   72: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   75: iconst_1
/*     */     //   76: invokeinterface getAlignedInt : (I)I
/*     */     //   81: istore #45
/*     */     //   83: iload #46
/*     */     //   85: iload #45
/*     */     //   87: if_icmpne -> 93
/*     */     //   90: goto -> 115
/*     */     //   93: aload_1
/*     */     //   94: iconst_1
/*     */     //   95: invokeinterface getAlignedInt : (I)I
/*     */     //   100: istore #44
/*     */     //   102: aload_0
/*     */     //   103: bipush #15
/*     */     //   105: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   110: iload #44
/*     */     //   112: invokestatic setFill : (Lorg/renjin/gcc/runtime/Ptr;I)V
/*     */     //   115: iload_2
/*     */     //   116: ifne -> 185
/*     */     //   119: goto -> 122
/*     */     //   122: aload_1
/*     */     //   123: iconst_2
/*     */     //   124: invokeinterface getAlignedDouble : (I)D
/*     */     //   129: dstore #40
/*     */     //   131: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   134: iconst_2
/*     */     //   135: invokeinterface getAlignedDouble : (I)D
/*     */     //   140: dstore #38
/*     */     //   142: dload #40
/*     */     //   144: dload #38
/*     */     //   146: dcmpl
/*     */     //   147: ifne -> 185
/*     */     //   150: goto -> 153
/*     */     //   153: aload_1
/*     */     //   154: bipush #6
/*     */     //   156: invokeinterface getAlignedInt : (I)I
/*     */     //   161: istore #37
/*     */     //   163: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   166: bipush #6
/*     */     //   168: invokeinterface getAlignedInt : (I)I
/*     */     //   173: istore #36
/*     */     //   175: iload #37
/*     */     //   177: iload #36
/*     */     //   179: if_icmpne -> 185
/*     */     //   182: goto -> 219
/*     */     //   185: aload_1
/*     */     //   186: bipush #6
/*     */     //   188: invokeinterface getAlignedInt : (I)I
/*     */     //   193: istore #35
/*     */     //   195: aload_1
/*     */     //   196: iconst_2
/*     */     //   197: invokeinterface getAlignedDouble : (I)D
/*     */     //   202: dstore #33
/*     */     //   204: aload_0
/*     */     //   205: bipush #15
/*     */     //   207: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   212: dload #33
/*     */     //   214: iload #35
/*     */     //   216: invokestatic setLine : (Lorg/renjin/gcc/runtime/Ptr;DI)V
/*     */     //   219: iload_2
/*     */     //   220: ifne -> 384
/*     */     //   223: goto -> 226
/*     */     //   226: aload_1
/*     */     //   227: bipush #44
/*     */     //   229: invokeinterface getDouble : (I)D
/*     */     //   234: dstore #29
/*     */     //   236: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   239: bipush #44
/*     */     //   241: invokeinterface getDouble : (I)D
/*     */     //   246: dstore #27
/*     */     //   248: dload #29
/*     */     //   250: dload #27
/*     */     //   252: dcmpl
/*     */     //   253: ifne -> 384
/*     */     //   256: goto -> 259
/*     */     //   259: aload_1
/*     */     //   260: bipush #52
/*     */     //   262: invokeinterface getDouble : (I)D
/*     */     //   267: dstore #25
/*     */     //   269: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   272: bipush #52
/*     */     //   274: invokeinterface getDouble : (I)D
/*     */     //   279: dstore #23
/*     */     //   281: dload #25
/*     */     //   283: dload #23
/*     */     //   285: dcmpl
/*     */     //   286: ifne -> 384
/*     */     //   289: goto -> 292
/*     */     //   292: aload_1
/*     */     //   293: bipush #60
/*     */     //   295: invokeinterface getDouble : (I)D
/*     */     //   300: dstore #21
/*     */     //   302: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   305: bipush #60
/*     */     //   307: invokeinterface getDouble : (I)D
/*     */     //   312: dstore #19
/*     */     //   314: dload #21
/*     */     //   316: dload #19
/*     */     //   318: dcmpl
/*     */     //   319: ifne -> 384
/*     */     //   322: goto -> 325
/*     */     //   325: aload_1
/*     */     //   326: bipush #17
/*     */     //   328: invokeinterface getAlignedInt : (I)I
/*     */     //   333: istore #18
/*     */     //   335: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   338: bipush #17
/*     */     //   340: invokeinterface getAlignedInt : (I)I
/*     */     //   345: istore #17
/*     */     //   347: iload #18
/*     */     //   349: iload #17
/*     */     //   351: if_icmpne -> 384
/*     */     //   354: goto -> 357
/*     */     //   357: aload_1
/*     */     //   358: bipush #72
/*     */     //   360: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   365: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   368: bipush #72
/*     */     //   370: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   375: invokestatic strcmp : (Lorg/renjin/gcc/runtime/Ptr;Lorg/renjin/gcc/runtime/Ptr;)I
/*     */     //   378: ifne -> 384
/*     */     //   381: goto -> 455
/*     */     //   384: aload_1
/*     */     //   385: astore #12
/*     */     //   387: aload_1
/*     */     //   388: bipush #17
/*     */     //   390: invokeinterface getAlignedInt : (I)I
/*     */     //   395: istore #11
/*     */     //   397: aload_1
/*     */     //   398: bipush #60
/*     */     //   400: invokeinterface getDouble : (I)D
/*     */     //   405: dstore #9
/*     */     //   407: aload_1
/*     */     //   408: bipush #52
/*     */     //   410: invokeinterface getDouble : (I)D
/*     */     //   415: dstore #7
/*     */     //   417: aload_1
/*     */     //   418: bipush #44
/*     */     //   420: invokeinterface getDouble : (I)D
/*     */     //   425: dstore #5
/*     */     //   427: aload_0
/*     */     //   428: bipush #15
/*     */     //   430: invokeinterface getAlignedPointer : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   435: dload #5
/*     */     //   437: dload #7
/*     */     //   439: dload #9
/*     */     //   441: iload #11
/*     */     //   443: aload #12
/*     */     //   445: bipush #72
/*     */     //   447: invokeinterface pointerPlus : (I)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   452: invokestatic setFont : (Lorg/renjin/gcc/runtime/Ptr;DDDILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   455: invokestatic get__jGDtalk$lastGC : ()Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   458: aload_1
/*     */     //   459: sipush #276
/*     */     //   462: invokeinterface memcpy : (Lorg/renjin/gcc/runtime/Ptr;I)V
/*     */     //   467: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #68	-> 0
/*     */     //   #68	-> 7
/*     */     //   #69	-> 35
/*     */     //   #72	-> 56
/*     */     //   #72	-> 63
/*     */     //   #73	-> 93
/*     */     //   #76	-> 115
/*     */     //   #76	-> 122
/*     */     //   #76	-> 153
/*     */     //   #77	-> 185
/*     */     //   #80	-> 219
/*     */     //   #80	-> 226
/*     */     //   #80	-> 259
/*     */     //   #80	-> 292
/*     */     //   #80	-> 325
/*     */     //   #80	-> 357
/*     */     //   #81	-> 384
/*     */     //   #83	-> 455
/*     */     //   #84	-> 467
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	468	0	xd	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	468	1	gc	Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   0	468	2	sendAll	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendAllGC(Ptr xd, Ptr gc) {
/*  93 */     sendGC(xd, gc, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int newJavaGD_Open(Ptr dd, Ptr xd, Ptr dsp, Ptr deviceClass, SEXP deviceOptions, double w, double h) {
/* 102 */     if (initJavaGD(xd, deviceClass, deviceOptions) == 0) {
/*     */       
/* 104 */       xd.setAlignedInt(6, -1);
/* 105 */       xd.setAlignedInt(5, -16777216);
/* 106 */       xd.setAlignedInt(7, -1);
/* 107 */       int m = (int)w; xd.setAlignedInt(12, m);
/* 108 */       int k = (int)h; xd.setAlignedInt(13, k);
/* 109 */       xd.setAlignedInt(17, 0);
/*     */       
/* 111 */       int j = (int)h, i = (int)w; GraphicsDevices.open(xd.getAlignedPointer(15), i, j);
/*     */       
/* 113 */       return 1;
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Activate(Ptr dd) {
/* 120 */     GraphicsDevices.activate(dd.getAlignedPointer(43).getPointer(60));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Close(Ptr dd) {
/* 127 */     GraphicsDevices.close(dd.getAlignedPointer(43).getPointer(60));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Circle(double x, double y, double r, Ptr gc, Ptr dd) {
/* 134 */     GraphicsDevices.circle(dd.getAlignedPointer(43).getPointer(60), x, y, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Clip(double x0, double x1, double y0, double y1, Ptr dd) {
/* 141 */     GraphicsDevices.clip(dd.getAlignedPointer(43).getPointer(60), x0, x1, y0, y1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Deactivate(Ptr dd) {
/* 147 */     GraphicsDevices.deactivate(dd.getAlignedPointer(43).getPointer(60));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Hold(Ptr dd) {
/* 153 */     GraphicsDevices.hold(dd.getAlignedPointer(43).getPointer(60));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int newJavaGD_HoldFlush(Ptr dd, int level) {
/* 160 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 162 */     if (xd.getInt(72) != 0) {
/*     */ 
/*     */ 
/*     */       
/* 166 */       ol = xd.getInt(68);
/* 167 */       int i = xd.getInt(68) + level; xd.setInt(68, i);
/*     */       
/* 169 */       if (xd.getInt(68) < 0) {
/* 170 */         xd.setInt(68, 0);
/*     */       }
/*     */       
/* 173 */       if (!xd.getPointer(60).isNull()) {
/*     */ 
/*     */         
/* 176 */         if (xd.getInt(68) != 0) {
/*     */ 
/*     */           
/* 179 */           if (ol == 0)
/*     */           {
/* 181 */             GraphicsDevices.flush(xd.getPointer(60), false); } 
/*     */         } else {
/*     */           GraphicsDevices.flush(xd.getPointer(60), true);
/* 184 */         }  return xd.getInt(68);
/*     */       } 
/*     */       return xd.getInt(68);
/*     */     } 
/*     */     return 0;
/*     */   } public static int newJavaGD_Locator(Ptr x, Ptr y, Ptr dd) {
/* 190 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 192 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */       boolean bool;
/*     */ 
/*     */       
/* 196 */       coords = GraphicsDevices.locator(xd.getPointer(60));
/* 197 */       if (!coords.isNull()) {
/* 198 */         double d2 = coords.getDouble(); x.setDouble(d2);
/* 199 */         double d1 = coords.getDouble(8); y.setDouble(d1);
/* 200 */         bool = true;
/*     */       } else {
/* 202 */         bool = false;
/*     */       } 
/*     */       return bool;
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public static void newJavaGD_Line(double x1, double y1, double x2, double y2, Ptr gc, Ptr dd) {
/* 210 */     xd = dd.getAlignedPointer(43);
/* 211 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 215 */       sendGC(xd, gc, 0);
/*     */       
/* 217 */       GraphicsDevices.line(xd.getPointer(60), x1, y1, x2, y2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_MetricInfo(int c, Ptr gc, Ptr ascent, Ptr descent, Ptr width, Ptr dd) {
/* 223 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 225 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 229 */       sendGC(xd, gc, 0);
/*     */       
/* 231 */       if (c < 0) {
/* 232 */         c = -c;
/*     */       }
/* 234 */       ac = GraphicsDevices.metricInfo(xd.getPointer(60), c);
/* 235 */       double d3 = ac.getDouble(); ascent.setDouble(d3);
/* 236 */       double d2 = ac.getDouble(8); descent.setDouble(d2);
/* 237 */       double d1 = ac.getDouble(16); width.setDouble(d1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Mode(int mode, Ptr dd) {
/* 243 */     xd = dd.getAlignedPointer(43);
/* 244 */     if (!xd.isNull() && !xd.getPointer(60).isNull())
/*     */     {
/*     */ 
/*     */       
/* 248 */       GraphicsDevices.mode(xd.getPointer(60), mode);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_NewPage(Ptr gc, Ptr dd) {
/* 254 */     xd = dd.getAlignedPointer(43);
/*     */ 
/*     */     
/* 257 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 261 */       devNr = baseDevices__.Rf_ndevNumber(dd);
/*     */       
/* 263 */       GraphicsDevices.newPage(xd.getPointer(60), devNr);
/*     */ 
/*     */       
/* 266 */       sendAllGC(xd, gc);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Path(Ptr x, Ptr y, int npoly, Ptr nper, int winding, Ptr gc, Ptr dd) {
/* 273 */     xd = dd.getAlignedPointer(43);
/*     */ 
/*     */     
/* 276 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 280 */       sendGC(xd, gc, 0);
/*     */       
/* 282 */       GraphicsDevices.path(xd.getPointer(60), npoly, nper, x, y, winding & 0x1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Polygon(int n, Ptr x, Ptr y, Ptr gc, Ptr dd) {
/* 288 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 290 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */       
/* 292 */       sendGC(xd, gc, 0);
/*     */       
/* 294 */       GraphicsDevices.polygon(xd.getPointer(60), n, x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Polyline(int n, Ptr x, Ptr y, Ptr gc, Ptr dd) {
/* 300 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 302 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 306 */       sendGC(xd, gc, 0);
/*     */       
/* 308 */       GraphicsDevices.polyline(xd.getPointer(60), n, x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Rect(double x0, double y0, double x1, double y1, Ptr gc, Ptr dd) {
/* 315 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 317 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */       
/* 319 */       sendGC(xd, gc, 0);
/*     */       
/* 321 */       GraphicsDevices.rect(xd.getPointer(60), x0, y0, x1, y1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Size(Ptr left, Ptr right, Ptr bottom, Ptr top, Ptr dd) {
/* 327 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 329 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 333 */       ac = GraphicsDevices.size(xd.getPointer(60));
/* 334 */       double d4 = ac.getDouble(); left.setDouble(d4);
/* 335 */       double d3 = ac.getDouble(8); right.setDouble(d3);
/* 336 */       double d2 = ac.getDouble(16); bottom.setDouble(d2);
/* 337 */       double d1 = ac.getDouble(24); top.setDouble(d1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ptr convertToUTF8(Ptr str, Ptr gc) {
/* 353 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double newJavaGD_StrWidthUTF8(Ptr str, Ptr gc, Ptr dd) {
/* 358 */     xd = dd.getAlignedPointer(43);
/* 359 */     res = 0.0D;
/*     */     
/* 361 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 365 */       sendGC(xd, gc, 0);
/*     */       
/* 367 */       return GraphicsDevices.strWidth(xd.getPointer(60), str);
/*     */     } 
/*     */     return 0.0D;
/*     */   }
/*     */   public static double newJavaGD_StrWidth(Ptr str, Ptr gc, Ptr dd) {
/* 372 */     return newJavaGD_StrWidthUTF8(convertToUTF8(str, gc), gc, dd);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_TextUTF8(double x, double y, Ptr str, double rot, double hadj, Ptr gc, Ptr dd) {
/* 378 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 380 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 384 */       sendGC(xd, gc, 0);
/*     */       
/* 386 */       GraphicsDevices.text(xd.getPointer(60), x, y, str, rot, hadj);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void newJavaGD_Text(double x, double y, Ptr str, double rot, double hadj, Ptr gc, Ptr dd) {
/* 391 */     Ptr ptr = convertToUTF8(str, gc); newJavaGD_TextUTF8(x, y, ptr, rot, hadj, gc, dd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void newJavaGD_Raster(Ptr raster, int w, int h, double x, double y, double width, double height, double rot, int interpolate, Ptr gc, Ptr dd) {
/* 399 */     xd = dd.getAlignedPointer(43);
/*     */     
/* 401 */     if (!xd.isNull() && !xd.getPointer(60).isNull()) {
/*     */ 
/*     */ 
/*     */       
/* 405 */       sendGC(xd, gc, 0);
/*     */       
/* 407 */       interpolate$0 = interpolate; GraphicsDevices.raster(xd.getPointer(60), raster, w, h, x, y, width, height, rot, interpolate$0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setupJavaGDfunctions(Ptr dd) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: bipush #53
/*     */     //   3: ldc
/*     */     //   5: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   8: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   13: aload_0
/*     */     //   14: bipush #50
/*     */     //   16: ldc
/*     */     //   18: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   21: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   26: aload_0
/*     */     //   27: bipush #54
/*     */     //   29: ldc
/*     */     //   31: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   34: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   39: aload_0
/*     */     //   40: bipush #66
/*     */     //   42: ldc
/*     */     //   44: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   47: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   52: aload_0
/*     */     //   53: bipush #59
/*     */     //   55: ldc
/*     */     //   57: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   60: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   65: aload_0
/*     */     //   66: bipush #52
/*     */     //   68: ldc
/*     */     //   70: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   73: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   78: aload_0
/*     */     //   79: bipush #67
/*     */     //   81: ldc
/*     */     //   83: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   86: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   91: aload_0
/*     */     //   92: bipush #68
/*     */     //   94: ldc
/*     */     //   96: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   99: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   104: aload_0
/*     */     //   105: bipush #62
/*     */     //   107: ldc
/*     */     //   109: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   112: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   117: aload_0
/*     */     //   118: bipush #51
/*     */     //   120: ldc
/*     */     //   122: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   125: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   130: aload_0
/*     */     //   131: bipush #56
/*     */     //   133: ldc
/*     */     //   135: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   138: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   143: aload_0
/*     */     //   144: bipush #61
/*     */     //   146: ldc
/*     */     //   148: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   151: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   156: aload_0
/*     */     //   157: bipush #60
/*     */     //   159: ldc
/*     */     //   161: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   164: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   169: aload_0
/*     */     //   170: bipush #55
/*     */     //   172: ldc
/*     */     //   174: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   177: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   182: aload_0
/*     */     //   183: bipush #58
/*     */     //   185: ldc
/*     */     //   187: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   190: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   195: aload_0
/*     */     //   196: bipush #57
/*     */     //   198: ldc
/*     */     //   200: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   203: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   208: aload_0
/*     */     //   209: bipush #72
/*     */     //   211: iconst_1
/*     */     //   212: invokeinterface setAlignedInt : (II)V
/*     */     //   217: aload_0
/*     */     //   218: bipush #74
/*     */     //   220: ldc
/*     */     //   222: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   225: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   230: aload_0
/*     */     //   231: bipush #73
/*     */     //   233: ldc
/*     */     //   235: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   238: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   243: aload_0
/*     */     //   244: bipush #64
/*     */     //   246: ldc
/*     */     //   248: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   251: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   256: aload_0
/*     */     //   257: bipush #63
/*     */     //   259: ldc
/*     */     //   261: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   264: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   269: aload_0
/*     */     //   270: bipush #79
/*     */     //   272: ldc
/*     */     //   274: invokestatic malloc : (Ljava/lang/invoke/MethodHandle;)Lorg/renjin/gcc/runtime/Ptr;
/*     */     //   277: invokeinterface setAlignedPointer : (ILorg/renjin/gcc/runtime/Ptr;)V
/*     */     //   282: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #413	-> 0
/*     */     //   #414	-> 13
/*     */     //   #415	-> 26
/*     */     //   #416	-> 39
/*     */     //   #417	-> 52
/*     */     //   #418	-> 65
/*     */     //   #419	-> 78
/*     */     //   #420	-> 91
/*     */     //   #421	-> 104
/*     */     //   #422	-> 117
/*     */     //   #423	-> 130
/*     */     //   #424	-> 143
/*     */     //   #425	-> 156
/*     */     //   #426	-> 169
/*     */     //   #427	-> 182
/*     */     //   #428	-> 195
/*     */     //   #430	-> 208
/*     */     //   #431	-> 217
/*     */     //   #432	-> 230
/*     */     //   #434	-> 243
/*     */     //   #436	-> 256
/*     */     //   #438	-> 269
/*     */     //   #445	-> 282
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	283	0	dd	Lorg/renjin/gcc/runtime/Ptr;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/jGDtalk__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */