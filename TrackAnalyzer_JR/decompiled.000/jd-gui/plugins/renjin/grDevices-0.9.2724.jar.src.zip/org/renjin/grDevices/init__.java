/*     */ package org.renjin.grDevices;
/*     */ 
/*     */ import org.renjin.gcc.runtime.BytePtr;
/*     */ import org.renjin.gnur.api.Rdynload;
/*     */ import org.renjin.gnur.api.Rinternals;
/*     */ import org.renjin.primitives.packaging.DllInfo;
/*     */ import org.renjin.sexp.SEXP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class init__
/*     */ {
/*     */   static {
/*     */   
/*     */   }
/*     */   
/*     */   public static SEXP cairoProps(SEXP in) {
/*  42 */     which = Rinternals.Rf_asInteger(in);
/*  43 */     return (which != 1) ? (
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  51 */       (which != 2) ? 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  59 */       Rinternals.R_NilValue : Rinternals.Rf_ScalarLogical(0)) : Rinternals.Rf_ScalarLogical(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void R_init_grDevices(DllInfo dll) {
/* 138 */     baseDevices__.Rf_InitGraphics();
/* 139 */     colors__.initPalette();
/* 140 */     Rdynload.R_registerRoutines(dll, BytePtr.of(0), Context.get__init$CallEntries(), BytePtr.of(0), Context.get__init$ExtEntries());
/* 141 */     Rdynload.R_useDynamicSymbols(dll, false);
/* 142 */     Rdynload.R_forceSymbols(dll, true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/renjin/grDevices-0.9.2724.jar!/org/renjin/grDevices/init__.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */