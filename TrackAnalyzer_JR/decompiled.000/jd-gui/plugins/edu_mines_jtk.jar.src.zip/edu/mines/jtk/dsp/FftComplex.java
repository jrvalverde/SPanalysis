/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FftComplex
/*     */ {
/*     */   private int _nfft;
/*     */   
/*     */   public FftComplex(int nfft) {
/*  46 */     Check.argument(Pfacc.nfftValid(nfft), "nfft=" + nfft + " is valid FFT length");
/*  47 */     this._nfft = nfft;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int nfftSmall(int n) {
/*  60 */     Check.argument((n <= 720720), "n does not exceed 720720");
/*  61 */     return Pfacc.nfftSmall(n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int nfftFast(int n) {
/*  74 */     Check.argument((n <= 720720), "n does not exceed 720720");
/*  75 */     return Pfacc.nfftFast(n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNfft() {
/*  83 */     return this._nfft;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex(int sign, float[] cx, float[] cy) {
/*  95 */     checkSign(sign);
/*  96 */     checkArray(2 * this._nfft, cx, "cx");
/*  97 */     checkArray(2 * this._nfft, cy, "cy");
/*  98 */     if (cx != cy)
/*  99 */       Array.ccopy(this._nfft, cx, cy); 
/* 100 */     Pfacc.transform(sign, this._nfft, cy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex1(int sign, int n2, float[][] cx, float[][] cy) {
/* 113 */     checkSign(sign);
/* 114 */     checkArray(2 * this._nfft, n2, cx, "cx");
/* 115 */     checkArray(2 * this._nfft, n2, cy, "cy");
/* 116 */     for (int i2 = 0; i2 < n2; i2++) {
/* 117 */       complexToComplex(sign, cx[i2], cy[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex2(int sign, int n1, float[][] cx, float[][] cy) {
/* 130 */     checkSign(sign);
/* 131 */     checkArray(2 * n1, this._nfft, cx, "cx");
/* 132 */     checkArray(2 * n1, this._nfft, cy, "cy");
/* 133 */     if (cx != cy)
/* 134 */       Array.ccopy(n1, this._nfft, cx, cy); 
/* 135 */     Pfacc.transform2a(sign, n1, this._nfft, cy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex1(int sign, int n2, int n3, float[][][] cx, float[][][] cy) {
/* 152 */     checkSign(sign);
/* 153 */     checkArray(2 * this._nfft, n2, n3, cx, "cx");
/* 154 */     checkArray(2 * this._nfft, n2, n3, cy, "cy");
/* 155 */     for (int i3 = 0; i3 < n3; i3++) {
/* 156 */       complexToComplex1(sign, n2, cx[i3], cy[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex2(int sign, int n1, int n3, float[][][] cx, float[][][] cy) {
/* 173 */     checkSign(sign);
/* 174 */     checkArray(2 * n1, this._nfft, n3, cx, "cx");
/* 175 */     checkArray(2 * n1, this._nfft, n3, cy, "cy");
/* 176 */     for (int i3 = 0; i3 < n3; i3++) {
/* 177 */       complexToComplex2(sign, n1, cx[i3], cy[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToComplex3(int sign, int n1, int n2, float[][][] cx, float[][][] cy) {
/* 194 */     checkSign(sign);
/* 195 */     checkArray(2 * n1, n2, this._nfft, cx, "cx");
/* 196 */     checkArray(2 * n1, n2, this._nfft, cy, "cy");
/* 197 */     float[][] cxi2 = new float[this._nfft][];
/* 198 */     float[][] cyi2 = new float[this._nfft][];
/* 199 */     for (int i2 = 0; i2 < n2; i2++) {
/* 200 */       for (int i3 = 0; i3 < this._nfft; i3++) {
/* 201 */         cxi2[i3] = cx[i3][i2];
/* 202 */         cyi2[i3] = cy[i3][i2];
/*     */       } 
/* 204 */       complexToComplex2(sign, n1, cxi2, cyi2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, float[] cx) {
/* 216 */     float s = 1.0F / this._nfft;
/* 217 */     int n = 2 * n1;
/* 218 */     while (--n >= 0) {
/* 219 */       cx[n] = cx[n] * s;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, int n2, float[][] cx) {
/* 231 */     for (int i2 = 0; i2 < n2; i2++) {
/* 232 */       scale(n1, cx[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, int n2, int n3, float[][][] cx) {
/* 245 */     for (int i3 = 0; i3 < n3; i3++) {
/* 246 */       scale(n1, n2, cx[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkSign(int sign) {
/* 255 */     Check.argument((sign == 1 || sign == -1), "sign equals 1 or -1");
/*     */   }
/*     */   
/*     */   private static void checkArray(int n, float[] a, String name) {
/* 259 */     Check.argument((a.length >= n), "dimensions of " + name + " are valid");
/*     */   }
/*     */   
/*     */   private static void checkArray(int n1, int n2, float[][] a, String name) {
/* 263 */     boolean ok = (a.length >= n2);
/* 264 */     for (int i2 = 0; i2 < n2 && ok; i2++)
/* 265 */       ok = ((a[i2]).length >= n1); 
/* 266 */     Check.argument(ok, "dimensions of " + name + " are valid");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkArray(int n1, int n2, int n3, float[][][] a, String name) {
/* 272 */     boolean ok = (a.length >= n3);
/* 273 */     for (int i3 = 0; i3 < n3 && ok; i3++) {
/* 274 */       ok = ((a[i3]).length >= n2);
/* 275 */       for (int i2 = 0; i2 < n2 && ok; i2++) {
/* 276 */         ok = ((a[i3][i2]).length >= n1);
/*     */       }
/*     */     } 
/* 279 */     Check.argument(ok, "dimensions of " + name + " are valid");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/FftComplex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */