/*    */ package edu.mines.jtk.opengl.test;
/*    */ 
/*    */ import edu.mines.jtk.opengl.Gl;
/*    */ import edu.mines.jtk.opengl.GlPainter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Texture
/*    */ {
/* 19 */   private static GlPainter painter = new GlPainter()
/*    */     {
/*    */ 
/*    */       
/* 23 */       private final int N = 64;
/* 24 */       private final byte[] _checkImage = new byte[16384];
/*    */ 
/*    */ 
/*    */       
/* 28 */       private int[] _texName = new int[1];
/*    */       private void makeCheckImage() {
/* 30 */         for (int i = 0; i < 64; i++) {
/* 31 */           for (int j = 0; j < 64; j++) {
/* 32 */             int index = (64 * i + j) * 4;
/* 33 */             int c = ((((((i & 0x8) == 0) ? 1 : 0) ^ (((j & 0x8) == 0) ? 1 : 0)) != 0) ? 1 : 0) * 255;
/* 34 */             byte b = (byte)c;
/* 35 */             this._checkImage[index] = b;
/* 36 */             this._checkImage[index + 1] = b;
/* 37 */             this._checkImage[index + 2] = b;
/* 38 */             this._checkImage[index + 3] = -1;
/*    */           } 
/*    */         } 
/*    */       }
/*    */       public void glInit() {
/* 43 */         makeCheckImage();
/* 44 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 45 */         Gl.glPixelStorei(3317, 1);
/* 46 */         Gl.glGenTextures(1, this._texName);
/* 47 */         Gl.glBindTexture(3553, this._texName[0]);
/* 48 */         Gl.glTexParameteri(3553, 10242, 10497);
/* 49 */         Gl.glTexParameteri(3553, 10243, 10497);
/* 50 */         Gl.glTexParameteri(3553, 10240, 9728);
/* 51 */         Gl.glTexParameteri(3553, 10241, 9728);
/* 52 */         Gl.glTexImage2D(3553, 0, 6408, 64, 64, 0, 6408, 5121, this._checkImage);
/*    */       }
/*    */       
/*    */       public void glResize(int width, int height, int widthOld, int heightOld) {
/* 56 */         Gl.glViewport(0, 0, width, height);
/* 57 */         Gl.glMatrixMode(5889);
/* 58 */         Gl.glLoadIdentity();
/* 59 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/*    */       }
/*    */       public void glPaint() {
/* 62 */         Gl.glClear(16640);
/* 63 */         Gl.glEnable(3553);
/* 64 */         Gl.glTexEnvf(8960, 8704, 7681.0F);
/* 65 */         Gl.glBindTexture(3553, this._texName[0]);
/* 66 */         Gl.glBegin(9);
/* 67 */         Gl.glTexCoord2f(0.0F, 0.0F); Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 68 */         Gl.glTexCoord2f(1.0F, 0.0F); Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 69 */         Gl.glTexCoord2f(1.0F, 1.0F); Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 70 */         Gl.glTexCoord2f(0.0F, 1.0F); Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 71 */         Gl.glEnd();
/* 72 */         Gl.glDisable(3553);
/* 73 */         Gl.glFlush();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 77 */     TestSimple.run(args, painter);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/test/Texture.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */