/*    */ package edu.mines.jtk.awt;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JRadioButtonMenuItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModeMenuItem
/*    */   extends JRadioButtonMenuItem
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ModeMenuItem(Mode mode) {
/* 34 */     super(mode);
/* 35 */     setIcon(null);
/* 36 */     mode.addPropertyChangeListener(new PropertyChangeListener() {
/*    */           public void propertyChange(PropertyChangeEvent e) {
/* 38 */             if (e.getPropertyName().equals("active"))
/* 39 */               ModeMenuItem.this.setSelected(((Boolean)e.getNewValue()).booleanValue()); 
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/ModeMenuItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */