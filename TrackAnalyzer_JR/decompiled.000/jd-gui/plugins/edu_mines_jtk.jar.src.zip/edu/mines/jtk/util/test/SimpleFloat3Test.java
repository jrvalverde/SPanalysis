/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Float3;
/*     */ import edu.mines.jtk.util.SimpleFloat3;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleFloat3Test
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(SimpleFloat3Test.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test123() {
/*  28 */     int n1 = 10;
/*  29 */     int n2 = 11;
/*  30 */     int n3 = 12;
/*  31 */     float[][][] a = Array.randfloat(n1, n2, n3);
/*  32 */     SimpleFloat3 sf3 = new SimpleFloat3(a);
/*  33 */     float[][][] c = Array.copy(a);
/*  34 */     test1((Float3)sf3, c);
/*  35 */     test2((Float3)sf3, c);
/*  36 */     test3((Float3)sf3, c);
/*     */   }
/*     */   
/*     */   public void testRandom() {
/*  40 */     int n1 = 10;
/*  41 */     int n2 = 11;
/*  42 */     int n3 = 12;
/*  43 */     float[][][] a = Array.randfloat(n1, n2, n3);
/*  44 */     SimpleFloat3 sf3 = new SimpleFloat3(a);
/*  45 */     float[][][] c = Array.copy(a);
/*  46 */     testRandom1((Float3)sf3, c);
/*  47 */     testRandom2((Float3)sf3, c);
/*  48 */     testRandom3((Float3)sf3, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private Random _random = new Random();
/*     */   private static final int NTRIAL = 10000;
/*     */   
/*     */   private void test1(Float3 f3, float[][][] a) {
/*  58 */     int n1 = f3.getN1();
/*  59 */     int n2 = f3.getN2();
/*  60 */     int n3 = f3.getN3();
/*  61 */     float[] b1 = new float[n1];
/*  62 */     for (int i3 = 0; i3 < n3; i3++) {
/*  63 */       for (int j = 0; j < n2; j++) {
/*  64 */         f3.get1(n1, 0, j, i3, b1);
/*  65 */         f3.set1(n1, 0, j, i3, b1);
/*  66 */         assertEqual1(n1, 0, j, i3, a, b1);
/*     */       } 
/*     */     } 
/*  69 */     float[] b2 = new float[n2];
/*  70 */     for (int i = 0; i < n3; i++) {
/*  71 */       for (int i1 = 0; i1 < n1; i1++) {
/*  72 */         f3.get2(n2, i1, 0, i, b2);
/*  73 */         f3.set2(n2, i1, 0, i, b2);
/*  74 */         assertEqual2(n2, i1, 0, i, a, b2);
/*     */       } 
/*     */     } 
/*  77 */     float[] b3 = new float[n3];
/*  78 */     for (int i2 = 0; i2 < n2; i2++) {
/*  79 */       for (int i1 = 0; i1 < n1; i1++) {
/*  80 */         f3.get3(n3, i1, i2, 0, b3);
/*  81 */         f3.set3(n3, i1, i2, 0, b3);
/*  82 */         assertEqual3(n3, i1, i2, 0, a, b3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void test2(Float3 f3, float[][][] a) {
/*  88 */     int n1 = f3.getN1();
/*  89 */     int n2 = f3.getN2();
/*  90 */     int n3 = f3.getN3();
/*  91 */     float[][] b12 = new float[n2][n1];
/*  92 */     for (int i3 = 0; i3 < n3; i3++) {
/*  93 */       f3.get12(n1, n2, 0, 0, i3, b12);
/*  94 */       f3.set12(n1, n2, 0, 0, i3, b12);
/*  95 */       assertEqual12(n1, n2, 0, 0, i3, a, b12);
/*     */     } 
/*  97 */     float[][] b13 = new float[n3][n1];
/*  98 */     for (int i2 = 0; i2 < n2; i2++) {
/*  99 */       f3.get13(n1, n3, 0, i2, 0, b13);
/* 100 */       f3.set13(n1, n3, 0, i2, 0, b13);
/* 101 */       assertEqual13(n1, n3, 0, i2, 0, a, b13);
/*     */     } 
/* 103 */     float[][] b23 = new float[n3][n2];
/* 104 */     for (int i1 = 0; i1 < n1; i1++) {
/* 105 */       f3.get23(n2, n3, i1, 0, 0, b23);
/* 106 */       f3.set23(n2, n3, i1, 0, 0, b23);
/* 107 */       assertEqual23(n2, n3, i1, 0, 0, a, b23);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void test3(Float3 f3, float[][][] a) {
/* 112 */     int n1 = f3.getN1();
/* 113 */     int n2 = f3.getN2();
/* 114 */     int n3 = f3.getN3();
/* 115 */     float[][][] b123 = new float[n3][n2][n1];
/* 116 */     f3.get123(n1, n2, n3, 0, 0, 0, b123);
/* 117 */     f3.set123(n1, n2, n3, 0, 0, 0, b123);
/* 118 */     assertEqual123(n1, n2, n3, 0, 0, 0, a, b123);
/* 119 */     float[] b = new float[n1 * n2 * n3];
/* 120 */     f3.get123(n1, n2, n3, 0, 0, 0, b);
/* 121 */     f3.set123(n1, n2, n3, 0, 0, 0, b);
/* 122 */     assertEqual123(n1, n2, n3, 0, 0, 0, a, b);
/*     */   }
/*     */   
/*     */   private void testRandom1(Float3 f3, float[][][] a) {
/* 126 */     int n1 = f3.getN1();
/* 127 */     int n2 = f3.getN2();
/* 128 */     int n3 = f3.getN3();
/* 129 */     int ntrial = 10000;
/* 130 */     float[] b1 = new float[n1];
/* 131 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/* 132 */       int m1 = 1 + this._random.nextInt(n1 - 1);
/* 133 */       int m2 = 1;
/* 134 */       int m3 = 1;
/* 135 */       int j1 = this._random.nextInt(n1 - m1);
/* 136 */       int j2 = this._random.nextInt(n2 - m2);
/* 137 */       int j3 = this._random.nextInt(n3 - m3);
/* 138 */       f3.get1(m1, j1, j2, j3, b1);
/* 139 */       f3.set1(m1, j1, j2, j3, b1);
/* 140 */       assertEqual1(m1, j1, j2, j3, a, b1);
/*     */     } 
/* 142 */     float[] b2 = new float[n2];
/* 143 */     for (int i = 0; i < ntrial; i++) {
/* 144 */       int m1 = 1;
/* 145 */       int m2 = 1 + this._random.nextInt(n2 - 1);
/* 146 */       int m3 = 1;
/* 147 */       int j1 = this._random.nextInt(n1 - m1);
/* 148 */       int j2 = this._random.nextInt(n2 - m2);
/* 149 */       int j3 = this._random.nextInt(n3 - m3);
/* 150 */       f3.get2(m2, j1, j2, j3, b2);
/* 151 */       f3.set2(m2, j1, j2, j3, b2);
/* 152 */       assertEqual2(m2, j1, j2, j3, a, b2);
/*     */     } 
/* 154 */     float[] b3 = new float[n3];
/* 155 */     for (int j = 0; j < ntrial; j++) {
/* 156 */       int m1 = 1;
/* 157 */       int m2 = 1;
/* 158 */       int m3 = 1 + this._random.nextInt(n3 - 1);
/* 159 */       int j1 = this._random.nextInt(n1 - m1);
/* 160 */       int j2 = this._random.nextInt(n2 - m2);
/* 161 */       int j3 = this._random.nextInt(n3 - m3);
/* 162 */       f3.get3(m3, j1, j2, j3, b3);
/* 163 */       f3.set3(m3, j1, j2, j3, b3);
/* 164 */       assertEqual3(m3, j1, j2, j3, a, b3);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void testRandom2(Float3 f3, float[][][] a) {
/* 169 */     int n1 = f3.getN1();
/* 170 */     int n2 = f3.getN2();
/* 171 */     int n3 = f3.getN3();
/* 172 */     int ntrial = 10000;
/* 173 */     float[][] b12 = new float[n2][n1];
/* 174 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/* 175 */       int m1 = 1 + this._random.nextInt(n1 - 1);
/* 176 */       int m2 = 1 + this._random.nextInt(n2 - 1);
/* 177 */       int m3 = 1;
/* 178 */       int j1 = this._random.nextInt(n1 - m1);
/* 179 */       int j2 = this._random.nextInt(n2 - m2);
/* 180 */       int j3 = this._random.nextInt(n3 - m3);
/* 181 */       f3.get12(m1, m2, j1, j2, j3, b12);
/* 182 */       f3.set12(m1, m2, j1, j2, j3, b12);
/* 183 */       assertEqual12(m1, m2, j1, j2, j3, a, b12);
/*     */     } 
/* 185 */     float[][] b13 = new float[n3][n1];
/* 186 */     for (int i = 0; i < ntrial; i++) {
/* 187 */       int m1 = 1 + this._random.nextInt(n1 - 1);
/* 188 */       int m2 = 1;
/* 189 */       int m3 = 1 + this._random.nextInt(n3 - 1);
/* 190 */       int j1 = this._random.nextInt(n1 - m1);
/* 191 */       int j2 = this._random.nextInt(n2 - m2);
/* 192 */       int j3 = this._random.nextInt(n3 - m3);
/* 193 */       f3.get13(m1, m3, j1, j2, j3, b13);
/* 194 */       f3.set13(m1, m3, j1, j2, j3, b13);
/* 195 */       assertEqual13(m1, m3, j1, j2, j3, a, b13);
/*     */     } 
/* 197 */     float[][] b23 = new float[n3][n2];
/* 198 */     for (int j = 0; j < ntrial; j++) {
/* 199 */       int m1 = 1;
/* 200 */       int m2 = 1 + this._random.nextInt(n2 - 1);
/* 201 */       int m3 = 1 + this._random.nextInt(n3 - 1);
/* 202 */       int j1 = this._random.nextInt(n1 - m1);
/* 203 */       int j2 = this._random.nextInt(n2 - m2);
/* 204 */       int j3 = this._random.nextInt(n3 - m3);
/* 205 */       f3.get23(m2, m3, j1, j2, j3, b23);
/* 206 */       f3.set23(m2, m3, j1, j2, j3, b23);
/* 207 */       assertEqual23(m2, m3, j1, j2, j3, a, b23);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void testRandom3(Float3 f3, float[][][] a) {
/* 212 */     int n1 = f3.getN1();
/* 213 */     int n2 = f3.getN2();
/* 214 */     int n3 = f3.getN3();
/* 215 */     int ntrial = 10000;
/* 216 */     float[][][] b123 = new float[n3][n2][n1];
/* 217 */     float[] b = new float[n1 * n2 * n3];
/* 218 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/* 219 */       int m1 = 1 + this._random.nextInt(n1 - 1);
/* 220 */       int m2 = 1 + this._random.nextInt(n2 - 1);
/* 221 */       int m3 = 1 + this._random.nextInt(n3 - 1);
/* 222 */       int j1 = this._random.nextInt(n1 - m1);
/* 223 */       int j2 = this._random.nextInt(n2 - m2);
/* 224 */       int j3 = this._random.nextInt(n3 - m3);
/* 225 */       f3.get123(m1, m2, m3, j1, j2, j3, b123);
/* 226 */       f3.set123(m1, m2, m3, j1, j2, j3, b123);
/* 227 */       assertEqual123(m1, m2, m3, j1, j2, j3, a, b123);
/* 228 */       f3.get123(m1, m2, m3, j1, j2, j3, b);
/* 229 */       f3.set123(m1, m2, m3, j1, j2, j3, b);
/* 230 */       assertEqual123(m1, m2, m3, j1, j2, j3, a, b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual1(int m1, int j1, int j2, int j3, float[][][] a, float[] s) {
/* 239 */     assertEqual123(m1, 1, 1, j1, j2, j3, a, s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual2(int m2, int j1, int j2, int j3, float[][][] a, float[] s) {
/* 247 */     assertEqual123(1, m2, 1, j1, j2, j3, a, s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual3(int m3, int j1, int j2, int j3, float[][][] a, float[] s) {
/* 255 */     assertEqual123(1, 1, m3, j1, j2, j3, a, s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual12(int m1, int m2, int j1, int j2, int j3, float[][][] a, float[][] s) {
/* 263 */     for (int i2 = 0; i2 < m2; i2++) {
/* 264 */       for (int i1 = 0; i1 < m1; i1++) {
/* 265 */         assertEquals(Float.valueOf(a[j3][i2 + j2][i1 + j1]), Float.valueOf(s[i2][i1]));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual13(int m1, int m3, int j1, int j2, int j3, float[][][] a, float[][] s) {
/* 275 */     for (int i3 = 0; i3 < m3; i3++) {
/* 276 */       for (int i1 = 0; i1 < m1; i1++) {
/* 277 */         assertEquals(Float.valueOf(a[i3 + j3][j2][i1 + j1]), Float.valueOf(s[i3][i1]));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual23(int m2, int m3, int j1, int j2, int j3, float[][][] a, float[][] s) {
/* 287 */     for (int i3 = 0; i3 < m3; i3++) {
/* 288 */       for (int i2 = 0; i2 < m2; i2++) {
/* 289 */         assertEquals(Float.valueOf(a[i3 + j3][i2 + j2][j1]), Float.valueOf(s[i3][i2]));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual123(int m1, int m2, int m3, int j1, int j2, int j3, float[][][] a, float[][][] s) {
/* 299 */     for (int i3 = 0; i3 < m3; i3++) {
/* 300 */       for (int i2 = 0; i2 < m2; i2++) {
/* 301 */         for (int i1 = 0; i1 < m1; i1++) {
/* 302 */           assertEquals(Float.valueOf(a[i3 + j3][i2 + j2][i1 + j1]), Float.valueOf(s[i3][i2][i1]));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void assertEqual123(int m1, int m2, int m3, int j1, int j2, int j3, float[][][] a, float[] s) {
/* 313 */     for (int i3 = 0; i3 < m3; i3++) {
/* 314 */       for (int i2 = 0; i2 < m2; i2++) {
/* 315 */         for (int i1 = 0; i1 < m1; i1++)
/* 316 */           assertEquals(Float.valueOf(a[i3 + j3][i2 + j2][i1 + j1]), Float.valueOf(s[i3 * m2 * m1 + i2 * m1 + i1])); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/SimpleFloat3Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */