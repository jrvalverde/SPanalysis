/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import edu.mines.jtk.util.Monitor;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuadraticSolver
/*     */ {
/*  49 */   private Quadratic _quadratic = null;
/*  50 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuadraticSolver(Quadratic quadratic) {
/*  59 */     this._quadratic = quadratic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vect solve(int numberIterations, Monitor monitor) {
/*  70 */     if (monitor == null) monitor = Monitor.NULL_MONITOR; 
/*  71 */     monitor.report(0.0D);
/*  72 */     VectConst b = this._quadratic.getB();
/*  73 */     monitor.report(1.0D / (numberIterations + 2.0D));
/*     */     
/*  75 */     double bb = b.dot(b); checkNaN(bb);
/*  76 */     if (Almost.FLOAT.zero(bb)) {
/*  77 */       LOG.fine("Gradient of quadratic is negligible.  Not solving");
/*  78 */       Vect result = VectUtil.cloneZero(b);
/*  79 */       monitor.report(1.0D);
/*  80 */       return result;
/*     */     } 
/*     */     
/*  83 */     Vect g = (Vect)b; b = null;
/*  84 */     Vect x = VectUtil.cloneZero(g);
/*  85 */     Vect p = x.clone();
/*  86 */     Vect u = x.clone();
/*  87 */     double pu = 0.0D;
/*  88 */     Vect qa = g.clone();
/*     */ 
/*     */     
/*  91 */     for (int iter = 0; iter < numberIterations; iter++) {
/*  92 */       double beta = 0.0D;
/*     */       
/*  94 */       Vect q = qa;
/*  95 */       VectUtil.copy(q, g);
/*  96 */       this._quadratic.inverseHessian(q);
/*  97 */       q.postCondition();
/*  98 */       this._quadratic.multiplyHessian(q);
/*  99 */       monitor.report((iter + 2.0D) / (numberIterations + 2.0D));
/* 100 */       if (iter > 0) {
/* 101 */         double pq = p.dot(q); checkNaN(pq);
/* 102 */         beta = Almost.FLOAT.divide(pq, pu, 0.0D);
/* 103 */         if (beta < -5.0D) beta = -5.0D; 
/* 104 */         if (beta > 5.0D) beta = 5.0D; 
/*     */       } 
/* 106 */       u.add(beta, -1.0D, q);
/*     */ 
/*     */       
/* 109 */       Vect a = qa;
/* 110 */       VectUtil.copy(a, g);
/* 111 */       this._quadratic.inverseHessian(a);
/* 112 */       a.postCondition();
/* 113 */       p.add(beta, -1.0D, a);
/*     */       
/* 115 */       double pg = p.dot(g); checkNaN(pg);
/* 116 */       pu = p.dot(u); checkNaN(pu);
/* 117 */       if (Almost.FLOAT.zero(pg) || Almost.FLOAT.zero(pu)) {
/*     */         break;
/*     */       }
/* 120 */       double scalar = -pg / pu;
/* 121 */       x.add(1.0D, scalar, p);
/* 122 */       if (iter == numberIterations - 1) {
/*     */         break;
/*     */       }
/* 125 */       g.add(1.0D, scalar, u);
/*     */     } 
/* 127 */     p.dispose();
/* 128 */     u.dispose();
/* 129 */     g.dispose();
/* 130 */     qa.dispose();
/* 131 */     monitor.report(1.0D);
/* 132 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vect solve(VectConst data, VectConst referenceModel, LinearTransform linearTransform, boolean dampOnlyPerturbation, int conjugateGradIterations, Monitor monitor) {
/* 166 */     Transform transform = new LinearTransformWrapper(linearTransform);
/* 167 */     VectConst perturbModel = null;
/* 168 */     TransformQuadratic transformQuadratic = new TransformQuadratic(data, referenceModel, perturbModel, transform, dampOnlyPerturbation);
/*     */ 
/*     */     
/* 171 */     QuadraticSolver quadraticSolver = new QuadraticSolver(transformQuadratic);
/* 172 */     Vect result = quadraticSolver.solve(conjugateGradIterations, monitor);
/* 173 */     transformQuadratic.dispose();
/* 174 */     result.add(1.0D, 1.0D, referenceModel);
/* 175 */     result.constrain();
/* 176 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkNaN(double value) {
/* 183 */     if (value * 0.0D != 0.0D)
/* 184 */       throw new IllegalStateException("Value is a NaN"); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/QuadraticSolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */