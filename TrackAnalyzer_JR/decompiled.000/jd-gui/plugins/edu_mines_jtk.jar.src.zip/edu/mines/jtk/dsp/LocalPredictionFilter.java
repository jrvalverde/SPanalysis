/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalPredictionFilter
/*     */ {
/*     */   private LocalCorrelationFilter _lcf;
/*     */   
/*     */   public LocalPredictionFilter(double sigma) {
/*  31 */     Check.argument((sigma >= 1.0D), "sigma>=1.0");
/*  32 */     this._lcf = new LocalCorrelationFilter(sigma);
/*     */   }
/*     */   
/*     */   public float[][][] apply(int[] lag1, int[] lag2, float[][] f, float[][] g) {
/*  36 */     Check.argument((lag1.length == lag2.length), "lag1.length==lag2.length");
/*  37 */     Check.argument((f != g), "f!=g");
/*     */ 
/*     */     
/*  40 */     R2Cache rcache = new R2Cache(f);
/*  41 */     int m = lag1.length;
/*  42 */     float[][][][] rkj = new float[m][m][][];
/*  43 */     float[][][] rk0 = new float[m][][];
/*  44 */     for (int k = 0; k < m; k++) {
/*  45 */       int k1 = lag1[k];
/*  46 */       int k2 = lag2[k];
/*  47 */       for (int i = 0; i < m; i++) {
/*  48 */         int j1 = lag1[i];
/*  49 */         int j2 = lag2[i];
/*  50 */         rkj[k][i] = rcache.get(j1 - k1, j2 - k2);
/*     */       } 
/*  52 */       rk0[k] = rcache.get(k1, k2);
/*     */     } 
/*     */ 
/*     */     
/*  56 */     int n1 = (f[0]).length;
/*  57 */     int n2 = f.length;
/*  58 */     double[][] rkjt = new double[m][m];
/*  59 */     double[] rk0t = new double[m];
/*  60 */     double[] at = new double[m];
/*  61 */     float[][][] a = new float[m][n2][n1];
/*  62 */     CgSolver cgs = new CgSolver(m, 100);
/*     */     
/*  64 */     double niter = 0.0D;
/*  65 */     for (int i2 = 0; i2 < n2; i2++) {
/*  66 */       int i1b = (i2 % 2 == 0) ? 0 : (n1 - 1);
/*  67 */       int i1e = (i2 % 2 == 0) ? n1 : -1;
/*  68 */       int i1s = (i2 % 2 == 0) ? 1 : -1; int i1;
/*  69 */       for (i1 = i1b; i1 != i1e; i1 += i1s) {
/*  70 */         for (int n = 0; n < m; n++) {
/*  71 */           for (int i3 = 0; i3 < m; i3++)
/*  72 */             rkjt[n][i3] = rkj[n][i3][i2][i1]; 
/*  73 */           rk0t[n] = rk0[n][i2][i1];
/*     */         } 
/*  75 */         niter += cgs.solve(rkjt, rk0t, at);
/*     */ 
/*     */ 
/*     */         
/*  79 */         for (int i = 0; i < m; i++)
/*  80 */           a[i][i2][i1] = (float)at[i]; 
/*     */       } 
/*     */     } 
/*  83 */     niter /= n1;
/*  84 */     niter /= n2;
/*  85 */     System.out.println("Average number of CG iterations = " + niter);
/*     */ 
/*     */     
/*  88 */     Array.zero(g);
/*  89 */     for (int j = 0; j < m; j++) {
/*  90 */       int j1 = lag1[j];
/*  91 */       int j2 = lag2[j];
/*  92 */       float[][] aj = a[j];
/*  93 */       int i1min = Math.max(0, j1);
/*  94 */       int i1max = Math.min(n1, n1 + j1);
/*  95 */       int i2min = Math.max(0, j2);
/*  96 */       int i2max = Math.min(n2, n2 + j2);
/*  97 */       for (int i = i2min; i < i2max; i++) {
/*  98 */         for (int i1 = i1min; i1 < i1max; i1++) {
/*  99 */           g[i][i1] = g[i][i1] + aj[i][i1] * f[i - j2][i1 - j1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyPef(int[] lag1, int[] lag2, float[][] f, float[][] g) {
/* 113 */     Check.argument((lag1.length == lag2.length), "lag1.length==lag2.length");
/* 114 */     Check.argument((f != g), "f!=g");
/*     */ 
/*     */     
/* 117 */     R2Cache rcache = new R2Cache(f);
/* 118 */     int m = lag1.length;
/* 119 */     float[][][][] rkj = new float[m][m][][];
/* 120 */     float[][][] rk0 = new float[m][][];
/* 121 */     for (int k = 0; k < m; k++) {
/* 122 */       int k1 = lag1[k];
/* 123 */       int k2 = lag2[k];
/* 124 */       for (int i = 0; i < m; i++) {
/* 125 */         int j1 = lag1[i];
/* 126 */         int j2 = lag2[i];
/* 127 */         rkj[k][i] = rcache.get(j1 - k1, j2 - k2);
/*     */       } 
/* 129 */       rk0[k] = rcache.get(k1, k2);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     int n1 = (f[0]).length;
/* 134 */     int n2 = f.length;
/* 135 */     double[][] rkjt = new double[m][m];
/* 136 */     double[] rk0t = new double[m];
/* 137 */     double[] at = new double[m];
/* 138 */     float[][][] a = new float[m][n2][n1];
/* 139 */     CgSolver cgs = new CgSolver(m, 100);
/* 140 */     double niter = 0.0D;
/* 141 */     for (int i2 = 0; i2 < n2; i2++) {
/* 142 */       int i1b = (i2 % 2 == 0) ? 0 : (n1 - 1);
/* 143 */       int i1e = (i2 % 2 == 0) ? n1 : -1;
/* 144 */       int i1s = (i2 % 2 == 0) ? 1 : -1; int i1;
/* 145 */       for (i1 = i1b; i1 != i1e; i1 += i1s) {
/* 146 */         for (int n = 0; n < m; n++) {
/* 147 */           for (int i3 = 0; i3 < m; i3++)
/* 148 */             rkjt[n][i3] = rkj[n][i3][i2][i1]; 
/* 149 */           rk0t[n] = rk0[n][i2][i1];
/*     */         } 
/* 151 */         niter += cgs.solve(rkjt, rk0t, at);
/* 152 */         for (int i = 0; i < m; i++)
/* 153 */           a[i][i2][i1] = (float)at[i]; 
/*     */       } 
/*     */     } 
/* 156 */     niter /= n1;
/* 157 */     niter /= n2;
/* 158 */     System.out.println("Average number of CG iterations = " + niter);
/*     */ 
/*     */     
/* 161 */     Array.copy(f, g);
/* 162 */     for (int j = 0; j < m; j++) {
/* 163 */       int j1 = lag1[j];
/* 164 */       int j2 = lag2[j];
/* 165 */       float[][] aj = a[j];
/* 166 */       int i1min = Math.max(0, j1);
/* 167 */       int i1max = Math.min(n1, n1 + j1);
/* 168 */       int i2min = Math.max(0, j2);
/* 169 */       int i2max = Math.min(n2, n2 + j2);
/* 170 */       for (int i = i2min; i < i2max; i++) {
/* 171 */         for (int i1 = i1min; i1 < i1max; i1++) {
/* 172 */           g[i][i1] = g[i][i1] - aj[i][i1] * f[i - j2][i1 - j1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CgSolver
/*     */   {
/*     */     CgSolver(int m, int maxiter) {
/* 223 */       this.m = m;
/* 224 */       this.maxiter = maxiter;
/* 225 */       this.p = new double[m];
/* 226 */       this.q = new double[m];
/* 227 */       this.r = new double[m];
/*     */     }
/*     */     int solve(double[][] a, double[] b, double[] x) {
/* 230 */       double rp = 0.0D;
/* 231 */       double rr = 0.0D;
/* 232 */       double bb = 0.0D;
/* 233 */       for (int i = 0; i < this.m; i++) {
/* 234 */         double[] ai = a[i];
/* 235 */         double ax = 0.0D;
/* 236 */         for (int j = 0; j < this.m; j++)
/* 237 */           ax += ai[j] * x[j]; 
/* 238 */         double bi = b[i];
/* 239 */         double ri = this.r[i] = bi - ax;
/* 240 */         bb += bi * bi;
/* 241 */         rr += ri * ri;
/*     */       } 
/* 243 */       double small = bb * TINY;
/*     */       int niter;
/* 245 */       for (niter = 0; niter < this.maxiter && rr > small; niter++) {
/* 246 */         if (niter == 0) {
/* 247 */           for (int m = 0; m < this.m; m++)
/* 248 */             this.p[m] = this.r[m]; 
/*     */         } else {
/* 250 */           double beta = rr / rp;
/* 251 */           for (int m = 0; m < this.m; m++)
/* 252 */             this.p[m] = this.r[m] + beta * this.p[m]; 
/*     */         } 
/* 254 */         double pq = 0.0D;
/* 255 */         for (int j = 0; j < this.m; j++) {
/* 256 */           double[] ai = a[j];
/* 257 */           double ap = 0.0D;
/* 258 */           for (int m = 0; m < this.m; m++)
/* 259 */             ap += ai[m] * this.p[m]; 
/* 260 */           this.q[j] = ap;
/* 261 */           pq += this.p[j] * this.q[j];
/*     */         } 
/* 263 */         double alpha = rr / pq;
/* 264 */         rp = rr;
/* 265 */         rr = 0.0D;
/* 266 */         for (int k = 0; k < this.m; k++) {
/* 267 */           x[k] = x[k] + alpha * this.p[k];
/* 268 */           this.r[k] = this.r[k] - alpha * this.q[k];
/* 269 */           rr += this.r[k] * this.r[k];
/*     */         } 
/*     */       } 
/* 272 */       if (rr > small) {
/* 273 */         System.out.println("CgSolver.solve: failed to converge");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 291 */       return niter;
/*     */     }
/* 293 */     private static final double TINY = Math.ulp(1.0F);
/*     */     private int m;
/*     */     private int maxiter;
/*     */     private double[] p;
/*     */     private double[] q;
/*     */     private double[] r; }
/*     */   
/*     */   private class R2 {
/*     */     R2(int l1, int l2, float[][] f) {
/* 302 */       int n1 = (f[0]).length;
/* 303 */       int n2 = f.length;
/* 304 */       this.l1 = l1;
/* 305 */       this.l2 = l2;
/* 306 */       this.r = new float[n2][n1];
/* 307 */       LocalPredictionFilter.this._lcf.apply(l1, l2, f, f, this.r);
/* 308 */       if (l1 == 0 && l2 == 0) {
/* 309 */         for (int i2 = 0; i2 < n2; i2++) {
/* 310 */           for (int i1 = 0; i1 < n1; i1++) {
/* 311 */             this.r[i2][i1] = this.r[i2][i1] * 1.01F;
/*     */           }
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int l1;
/*     */ 
/*     */     
/*     */     int l2;
/*     */ 
/*     */     
/*     */     float[][] r;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class R2Cache
/*     */   {
/*     */     float[][] _f;
/*     */ 
/*     */     
/*     */     ArrayList<LocalPredictionFilter.R2> _rlist;
/*     */ 
/*     */ 
/*     */     
/*     */     R2Cache(float[][] f) {
/* 341 */       this._rlist = new ArrayList<LocalPredictionFilter.R2>();
/*     */       this._f = f;
/*     */     }
/*     */     
/*     */     float[][][] get() {
/*     */       int n = this._rlist.size();
/*     */       float[][][] r = new float[n][][];
/*     */       int i = 0;
/*     */       for (LocalPredictionFilter.R2 r2 : this._rlist) {
/*     */         r[i] = r2.r;
/*     */         i++;
/*     */       } 
/*     */       return r;
/*     */     }
/*     */     
/*     */     float[][] get(int l1, int l2) {
/*     */       for (LocalPredictionFilter.R2 r21 : this._rlist) {
/*     */         if ((l1 == r21.l1 && l2 == r21.l2) || (-l1 == r21.l1 && -l2 == r21.l2))
/*     */           return r21.r; 
/*     */       } 
/*     */       LocalPredictionFilter.R2 r2 = new LocalPredictionFilter.R2(l1, l2, this._f);
/*     */       this._rlist.add(r2);
/*     */       return r2.r;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/LocalPredictionFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */