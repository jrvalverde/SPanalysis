/*     */ package edu.mines.jtk.opt.test;
/*     */ import edu.mines.jtk.opt.ArrayVect1f;
/*     */ import edu.mines.jtk.opt.Vect;
/*     */ import edu.mines.jtk.opt.VectConst;
/*     */ import edu.mines.jtk.opt.VectUtil;
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.logging.Logger;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ public class ArrayVect1fTest extends TestCase {
/*  17 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt.test");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testAll() throws Exception {
/*  23 */     float[] a = new float[31];
/*  24 */     for (int i = 0; i < a.length; ) { a[i] = i; i++; }
/*  25 */      ArrayVect1f arrayVect1f1 = new ArrayVect1f(a, 0, 3.0D);
/*  26 */     VectUtil.test((VectConst)arrayVect1f1);
/*  27 */     arrayVect1f1 = new ArrayVect1f(a, 10, 3.0D);
/*  28 */     VectUtil.test((VectConst)arrayVect1f1);
/*     */ 
/*     */     
/*  31 */     for (int j = 0; j < a.length; ) { a[j] = 1.0F; j++; }
/*  32 */      arrayVect1f1 = new ArrayVect1f(a, 0, 3.0D);
/*  33 */     Vect w = arrayVect1f1.clone();
/*  34 */     w.multiplyInverseCovariance();
/*  35 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect1f1.dot((VectConst)w));
/*  36 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect1f1.magnitude());
/*     */ 
/*     */ 
/*     */     
/*  40 */     float[] data = new float[501];
/*  41 */     Arrays.fill(data, 1.0F);
/*  42 */     int minimumSize = data.length * 4;
/*  43 */     int externalSize = 10 * minimumSize;
/*  44 */     int writeObjectSize = 10 * minimumSize;
/*  45 */     LOG.fine("minimum size = " + minimumSize);
/*  46 */     ArrayVect1f v = new ArrayVect1f(data, 0, 1.0D);
/*     */     
/*  48 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(0);
/*  49 */     ObjectOutputStream oos = new ObjectOutputStream(baos);
/*  50 */     oos.writeObject(v);
/*  51 */     oos.close();
/*  52 */     byte[] result = baos.toByteArray();
/*  53 */     externalSize = result.length;
/*  54 */     LOG.fine("externalizable size = " + externalSize);
/*     */ 
/*     */     
/*  57 */     baos = new ByteArrayOutputStream(0);
/*  58 */     oos = new ObjectOutputStream(baos);
/*  59 */     oos.writeObject(v);
/*  60 */     oos.close();
/*  61 */     result = baos.toByteArray();
/*  62 */     writeObjectSize = result.length;
/*  63 */     LOG.fine("writeObject size = " + writeObjectSize);
/*     */ 
/*     */     
/*  66 */     assert externalSize <= minimumSize + 130 : externalSize + " <= " + (minimumSize + '');
/*     */     
/*  68 */     assert writeObjectSize <= minimumSize + 130 : writeObjectSize + "<=" + (minimumSize + '');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {
/*  75 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/*  78 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect1fTest(String name) {
/*  85 */     super(name);
/*     */   }
/*     */   
/*     */   public static Test suite() {
/*     */     try {
/*     */       assert false;
/*  91 */       throw new IllegalStateException("need -ea");
/*  92 */     } catch (AssertionError e) {
/*  93 */       return (Test)new TestSuite(ArrayVect1fTest.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 100 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect1fTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */