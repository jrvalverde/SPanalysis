/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect1;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectMap;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VectMapTest
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() {
/* 25 */     Random random = new Random(32525L);
/* 26 */     VectMap vm = new VectMap(false);
/* 27 */     for (int index = 0; index < 5; index += 2) {
/* 28 */       double[] a = new double[7 * index];
/* 29 */       for (int j = 0; j < a.length; ) { a[j] = random.nextDouble(); j++; }
/* 30 */        ArrayVect1 arrayVect1 = new ArrayVect1(a, 2.0D);
/* 31 */       vm.put(index, (Vect)arrayVect1);
/*    */     } 
/* 33 */     VectUtil.test((VectConst)vm);
/* 34 */     int[] keys = vm.getKeys();
/* 35 */     assert keys.length == 3 : "keys.length = " + keys.length;
/* 36 */     assert keys[0] == 0;
/* 37 */     assert keys[1] == 2;
/* 38 */     assert keys[2] == 4; int i;
/* 39 */     for (i = 0; i < 5; i += 2) {
/* 40 */       ArrayVect1 value = (ArrayVect1)vm.get(i);
/* 41 */       assert value != null : "index=" + i;
/* 42 */       assert value.getData() != null : "index=" + i;
/* 43 */       assert value.getSize() == 7 * i : "index=" + i;
/* 44 */       assert (value.getData()).length == 7 * i : "index=" + i;
/* 45 */       assert vm.get(i + 1) == null : "index=" + i;
/*    */     } 
/*    */     
/* 48 */     vm = new VectMap(false);
/* 49 */     for (i = 1; i < 5; i++) {
/* 50 */       double[] a = new double[7 * i];
/* 51 */       for (int j = 0; j < a.length; ) { a[j] = 1.0D; j++; }
/* 52 */        ArrayVect1 arrayVect1 = new ArrayVect1(a, 1.0D);
/* 53 */       vm.put(i, (Vect)arrayVect1);
/* 54 */       assert vm.containsKey(i);
/*    */     } 
/* 56 */     assert !vm.containsKey(99);
/* 57 */     VectMap vectMap1 = vm.clone();
/* 58 */     vectMap1.multiplyInverseCovariance();
/* 59 */     assert Almost.FLOAT.equal(1.0D, vectMap1.dot((VectConst)vm));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 65 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 68 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VectMapTest(String name) {
/* 75 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 81 */       throw new IllegalStateException("need -ea");
/* 82 */     } catch (AssertionError e) {
/* 83 */       return (Test)new TestSuite(VectMapTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 90 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/VectMapTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */