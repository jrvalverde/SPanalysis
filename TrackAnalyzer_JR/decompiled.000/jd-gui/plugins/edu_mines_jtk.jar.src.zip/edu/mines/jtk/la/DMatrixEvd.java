/*     */ package edu.mines.jtk.la;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixEvd
/*     */ {
/*     */   private int _n;
/*     */   private double[][] _v;
/*     */   private double[] _d;
/*     */   private double[] _e;
/*     */   private double[][] _h;
/*     */   private double _cdivr;
/*     */   private double _cdivi;
/*     */   
/*     */   public DMatrixEvd(DMatrix a) {
/*  41 */     Check.argument(a.isSquare(), "matrix a is square");
/*  42 */     double[][] aa = a.getArray();
/*  43 */     int n = a.getN();
/*  44 */     this._n = n;
/*  45 */     this._v = new double[n][n];
/*  46 */     this._d = new double[n];
/*  47 */     this._e = new double[n];
/*  48 */     if (a.isSymmetric()) {
/*  49 */       for (int i = 0; i < n; i++) {
/*  50 */         for (int j = 0; j < n; j++) {
/*  51 */           this._v[i][j] = aa[i][j];
/*     */         }
/*     */       } 
/*  54 */       tred2();
/*  55 */       tql2();
/*     */     } else {
/*  57 */       this._h = new double[n][n];
/*  58 */       for (int i = 0; i < n; i++) {
/*  59 */         for (int j = 0; j < n; j++) {
/*  60 */           this._h[i][j] = aa[i][j];
/*     */         }
/*     */       } 
/*  63 */       orthes();
/*  64 */       hqr2();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getV() {
/*  73 */     return new DMatrix(this._n, this._n, this._v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getD() {
/*  81 */     DMatrix d = new DMatrix(this._n, this._n);
/*  82 */     double[][] da = d.getArray();
/*  83 */     for (int i = 0; i < this._n; i++) {
/*  84 */       for (int j = 0; j < this._n; j++) {
/*  85 */         da[i][j] = 0.0D;
/*     */       }
/*  87 */       da[i][i] = this._d[i];
/*  88 */       if (this._e[i] > 0.0D) {
/*  89 */         da[i][i + 1] = this._e[i];
/*  90 */       } else if (this._e[i] < 0.0D) {
/*  91 */         da[i][i - 1] = this._e[i];
/*     */       } 
/*     */     } 
/*  94 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getRealEigenvalues() {
/* 102 */     return Array.copy(this._d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getImagEigenvalues() {
/* 110 */     return Array.copy(this._e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void tred2() {
/* 127 */     int n = this._n;
/* 128 */     for (int k = 0; k < n; k++) {
/* 129 */       this._d[k] = this._v[n - 1][k];
/*     */     }
/*     */     int i;
/* 132 */     for (i = n - 1; i > 0; i--) {
/*     */ 
/*     */       
/* 135 */       double scale = 0.0D;
/* 136 */       double h = 0.0D; int m;
/* 137 */       for (m = 0; m < i; m++)
/* 138 */         scale += Math.abs(this._d[m]); 
/* 139 */       if (scale == 0.0D) {
/* 140 */         this._e[i] = this._d[i - 1];
/* 141 */         for (int i1 = 0; i1 < i; i1++) {
/* 142 */           this._d[i1] = this._v[i - 1][i1];
/* 143 */           this._v[i][i1] = 0.0D;
/* 144 */           this._v[i1][i] = 0.0D;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 149 */         for (m = 0; m < i; m++) {
/* 150 */           this._d[m] = this._d[m] / scale;
/* 151 */           h += this._d[m] * this._d[m];
/*     */         } 
/* 153 */         double f = this._d[i - 1];
/* 154 */         double g = Math.sqrt(h);
/* 155 */         if (f > 0.0D)
/* 156 */           g = -g; 
/* 157 */         this._e[i] = scale * g;
/* 158 */         h -= f * g;
/* 159 */         this._d[i - 1] = f - g; int i1;
/* 160 */         for (i1 = 0; i1 < i; i1++) {
/* 161 */           this._e[i1] = 0.0D;
/*     */         }
/*     */         
/* 164 */         for (i1 = 0; i1 < i; i1++) {
/* 165 */           f = this._d[i1];
/* 166 */           this._v[i1][i] = f;
/* 167 */           g = this._e[i1] + this._v[i1][i1] * f;
/* 168 */           for (int i3 = i1 + 1; i3 <= i - 1; i3++) {
/* 169 */             g += this._v[i3][i1] * this._d[i3];
/* 170 */             this._e[i3] = this._e[i3] + this._v[i3][i1] * f;
/*     */           } 
/* 172 */           this._e[i1] = g;
/*     */         } 
/* 174 */         f = 0.0D;
/* 175 */         for (i1 = 0; i1 < i; i1++) {
/* 176 */           this._e[i1] = this._e[i1] / h;
/* 177 */           f += this._e[i1] * this._d[i1];
/*     */         } 
/* 179 */         double hh = f / (h + h); int i2;
/* 180 */         for (i2 = 0; i2 < i; i2++) {
/* 181 */           this._e[i2] = this._e[i2] - hh * this._d[i2];
/*     */         }
/* 183 */         for (i2 = 0; i2 < i; i2++) {
/* 184 */           f = this._d[i2];
/* 185 */           g = this._e[i2];
/* 186 */           for (int i3 = i2; i3 <= i - 1; i3++) {
/* 187 */             this._v[i3][i2] = this._v[i3][i2] - f * this._e[i3] + g * this._d[i3];
/*     */           }
/* 189 */           this._d[i2] = this._v[i - 1][i2];
/* 190 */           this._v[i][i2] = 0.0D;
/*     */         } 
/*     */       } 
/* 193 */       this._d[i] = h;
/*     */     } 
/*     */ 
/*     */     
/* 197 */     for (i = 0; i < n - 1; i++) {
/* 198 */       this._v[n - 1][i] = this._v[i][i];
/* 199 */       this._v[i][i] = 1.0D;
/* 200 */       double h = this._d[i + 1];
/* 201 */       if (h != 0.0D) {
/* 202 */         for (int i2 = 0; i2 <= i; i2++)
/* 203 */           this._d[i2] = this._v[i2][i + 1] / h; 
/* 204 */         for (int i1 = 0; i1 <= i; i1++) {
/* 205 */           double g = 0.0D; int i3;
/* 206 */           for (i3 = 0; i3 <= i; i3++)
/* 207 */             g += this._v[i3][i + 1] * this._v[i3][i1]; 
/* 208 */           for (i3 = 0; i3 <= i; i3++)
/* 209 */             this._v[i3][i1] = this._v[i3][i1] - g * this._d[i3]; 
/*     */         } 
/*     */       } 
/* 212 */       for (int m = 0; m <= i; m++)
/* 213 */         this._v[m][i + 1] = 0.0D; 
/*     */     } 
/* 215 */     for (int j = 0; j < n; j++) {
/* 216 */       this._d[j] = this._v[n - 1][j];
/* 217 */       this._v[n - 1][j] = 0.0D;
/*     */     } 
/* 219 */     this._v[n - 1][n - 1] = 1.0D;
/* 220 */     this._e[0] = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void tql2() {
/* 229 */     int n = this._n;
/* 230 */     for (int i = 1; i < n; i++)
/* 231 */       this._e[i - 1] = this._e[i]; 
/* 232 */     this._e[n - 1] = 0.0D;
/* 233 */     double f = 0.0D;
/* 234 */     double tst1 = 0.0D;
/* 235 */     double eps = Math.pow(2.0D, -52.0D);
/* 236 */     for (int l = 0; l < n; l++) {
/*     */ 
/*     */       
/* 239 */       tst1 = Math.max(tst1, Math.abs(this._d[l]) + Math.abs(this._e[l]));
/* 240 */       int m = l;
/* 241 */       while (m < n && 
/* 242 */         Math.abs(this._e[m]) > eps * tst1)
/*     */       {
/* 244 */         m++;
/*     */       }
/*     */ 
/*     */       
/* 248 */       if (m > l) {
/* 249 */         int iter = 0;
/*     */         do {
/* 251 */           iter++;
/*     */ 
/*     */           
/* 254 */           double g = this._d[l];
/* 255 */           double p = (this._d[l + 1] - g) / 2.0D * this._e[l];
/* 256 */           double r = Math.hypot(p, 1.0D);
/* 257 */           if (p < 0.0D)
/* 258 */             r = -r; 
/* 259 */           this._d[l] = this._e[l] / (p + r);
/* 260 */           this._d[l + 1] = this._e[l] * (p + r);
/* 261 */           double dl1 = this._d[l + 1];
/* 262 */           double h = g - this._d[l];
/* 263 */           for (int k = l + 2; k < n; k++)
/* 264 */             this._d[k] = this._d[k] - h; 
/* 265 */           f += h;
/*     */ 
/*     */           
/* 268 */           p = this._d[m];
/* 269 */           double c = 1.0D;
/* 270 */           double c2 = c;
/* 271 */           double c3 = c;
/* 272 */           double el1 = this._e[l + 1];
/* 273 */           double s = 0.0D;
/* 274 */           double s2 = 0.0D;
/* 275 */           for (int i1 = m - 1; i1 >= l; i1--) {
/* 276 */             c3 = c2;
/* 277 */             c2 = c;
/* 278 */             s2 = s;
/* 279 */             g = c * this._e[i1];
/* 280 */             h = c * p;
/* 281 */             r = Math.hypot(p, this._e[i1]);
/* 282 */             this._e[i1 + 1] = s * r;
/* 283 */             s = this._e[i1] / r;
/* 284 */             c = p / r;
/* 285 */             p = c * this._d[i1] - s * g;
/* 286 */             this._d[i1 + 1] = h + s * (c * g + s * this._d[i1]);
/*     */ 
/*     */             
/* 289 */             for (int i2 = 0; i2 < n; i2++) {
/* 290 */               h = this._v[i2][i1 + 1];
/* 291 */               this._v[i2][i1 + 1] = s * this._v[i2][i1] + c * h;
/* 292 */               this._v[i2][i1] = c * this._v[i2][i1] - s * h;
/*     */             } 
/*     */           } 
/* 295 */           p = -s * s2 * c3 * el1 * this._e[l] / dl1;
/* 296 */           this._e[l] = s * p;
/* 297 */           this._d[l] = c * p;
/*     */         
/*     */         }
/* 300 */         while (Math.abs(this._e[l]) > eps * tst1);
/*     */       } 
/* 302 */       this._d[l] = this._d[l] + f;
/* 303 */       this._e[l] = 0.0D;
/*     */     } 
/*     */ 
/*     */     
/* 307 */     for (int j = 0; j < n - 1; j++) {
/* 308 */       int k = j;
/* 309 */       double p = this._d[j]; int m;
/* 310 */       for (m = j + 1; m < n; m++) {
/* 311 */         if (this._d[m] < p) {
/* 312 */           k = m;
/* 313 */           p = this._d[m];
/*     */         } 
/*     */       } 
/* 316 */       if (k != j) {
/* 317 */         this._d[k] = this._d[j];
/* 318 */         this._d[j] = p;
/* 319 */         for (m = 0; m < n; m++) {
/* 320 */           p = this._v[m][j];
/* 321 */           this._v[m][j] = this._v[m][k];
/* 322 */           this._v[m][k] = p;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void orthes() {
/* 334 */     int n = this._n;
/* 335 */     int low = 0;
/* 336 */     int high = n - 1;
/* 337 */     double[] ort = new double[n];
/* 338 */     for (int j = low + 1; j <= high - 1; j++) {
/*     */ 
/*     */       
/* 341 */       double scale = 0.0D;
/* 342 */       for (int k = j; k <= high; k++)
/* 343 */         scale += Math.abs(this._h[k][j - 1]); 
/* 344 */       if (scale != 0.0D) {
/*     */ 
/*     */         
/* 347 */         double h = 0.0D;
/* 348 */         for (int i1 = high; i1 >= j; i1--) {
/* 349 */           ort[i1] = this._h[i1][j - 1] / scale;
/* 350 */           h += ort[i1] * ort[i1];
/*     */         } 
/* 352 */         double g = Math.sqrt(h);
/* 353 */         if (ort[j] > 0.0D)
/* 354 */           g = -g; 
/* 355 */         h -= ort[j] * g;
/* 356 */         ort[j] = ort[j] - g;
/*     */ 
/*     */         
/* 359 */         for (int i3 = j; i3 < n; i3++) {
/* 360 */           double f = 0.0D; int i4;
/* 361 */           for (i4 = high; i4 >= j; i4--)
/* 362 */             f += ort[i4] * this._h[i4][i3]; 
/* 363 */           f /= h;
/* 364 */           for (i4 = j; i4 <= high; i4++)
/* 365 */             this._h[i4][i3] = this._h[i4][i3] - f * ort[i4]; 
/*     */         } 
/* 367 */         for (int i2 = 0; i2 <= high; i2++) {
/* 368 */           double f = 0.0D; int i4;
/* 369 */           for (i4 = high; i4 >= j; i4--)
/* 370 */             f += ort[i4] * this._h[i2][i4]; 
/* 371 */           f /= h;
/* 372 */           for (i4 = j; i4 <= high; i4++)
/* 373 */             this._h[i2][i4] = this._h[i2][i4] - f * ort[i4]; 
/*     */         } 
/* 375 */         ort[j] = scale * ort[j];
/* 376 */         this._h[j][j - 1] = scale * g;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 381 */     for (int i = 0; i < n; i++) {
/* 382 */       for (int k = 0; k < n; k++) {
/* 383 */         this._v[i][k] = (i == k) ? 1.0D : 0.0D;
/*     */       }
/*     */     } 
/* 386 */     for (int m = high - 1; m >= low + 1; m--) {
/* 387 */       if (this._h[m][m - 1] != 0.0D) {
/* 388 */         for (int i1 = m + 1; i1 <= high; i1++)
/* 389 */           ort[i1] = this._h[i1][m - 1]; 
/* 390 */         for (int k = m; k <= high; k++) {
/* 391 */           double g = 0.0D; int i2;
/* 392 */           for (i2 = m; i2 <= high; i2++)
/* 393 */             g += ort[i2] * this._v[i2][k]; 
/* 394 */           g = g / ort[m] / this._h[m][m - 1];
/* 395 */           for (i2 = m; i2 <= high; i2++) {
/* 396 */             this._v[i2][k] = this._v[i2][k] + g * ort[i2];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cdiv(double xr, double xi, double yr, double yi) {
/* 407 */     if (Math.abs(yr) > Math.abs(yi)) {
/* 408 */       double r = yi / yr;
/* 409 */       double d = yr + r * yi;
/* 410 */       this._cdivr = (xr + r * xi) / d;
/* 411 */       this._cdivi = (xi - r * xr) / d;
/*     */     } else {
/* 413 */       double r = yr / yi;
/* 414 */       double d = yi + r * yr;
/* 415 */       this._cdivr = (r * xr + xi) / d;
/* 416 */       this._cdivi = (r * xi - xr) / d;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void hqr2() {
/* 429 */     int nn = this._n;
/* 430 */     int n = nn - 1;
/* 431 */     int low = 0;
/* 432 */     int high = nn - 1;
/* 433 */     double eps = Math.pow(2.0D, -52.0D);
/* 434 */     double exshift = 0.0D;
/* 435 */     double p = 0.0D, q = 0.0D, r = 0.0D, s = 0.0D, z = 0.0D;
/*     */ 
/*     */     
/* 438 */     double norm = 0.0D;
/* 439 */     for (int i = 0; i < nn; i++) {
/* 440 */       if (i < low || i > high) {
/* 441 */         this._d[i] = this._h[i][i];
/* 442 */         this._e[i] = 0.0D;
/*     */       } 
/* 444 */       for (int m = Math.max(i - 1, 0); m < nn; m++) {
/* 445 */         norm += Math.abs(this._h[i][m]);
/*     */       }
/*     */     } 
/*     */     
/* 449 */     int iter = 0;
/* 450 */     while (n >= low) {
/*     */ 
/*     */       
/* 453 */       int l = n;
/* 454 */       while (l > low) {
/* 455 */         s = Math.abs(this._h[l - 1][l - 1]) + Math.abs(this._h[l][l]);
/* 456 */         if (s == 0.0D)
/* 457 */           s = norm; 
/* 458 */         if (Math.abs(this._h[l][l - 1]) < eps * s)
/*     */           break; 
/* 460 */         l--;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 466 */       if (l == n) {
/* 467 */         this._h[n][n] = this._h[n][n] + exshift;
/* 468 */         this._d[n] = this._h[n][n];
/* 469 */         this._e[n] = 0.0D;
/* 470 */         n--;
/* 471 */         iter = 0;
/*     */         
/*     */         continue;
/*     */       } 
/* 475 */       if (l == n - 1) {
/* 476 */         double d1 = this._h[n][n - 1] * this._h[n - 1][n];
/* 477 */         p = (this._h[n - 1][n - 1] - this._h[n][n]) / 2.0D;
/* 478 */         q = p * p + d1;
/* 479 */         z = Math.sqrt(Math.abs(q));
/* 480 */         this._h[n][n] = this._h[n][n] + exshift;
/* 481 */         this._h[n - 1][n - 1] = this._h[n - 1][n - 1] + exshift;
/* 482 */         double d2 = this._h[n][n];
/*     */ 
/*     */         
/* 485 */         if (q >= 0.0D) {
/* 486 */           if (p >= 0.0D) {
/* 487 */             z = p + z;
/*     */           } else {
/* 489 */             z = p - z;
/*     */           } 
/* 491 */           this._d[n - 1] = d2 + z;
/* 492 */           this._d[n] = this._d[n - 1];
/* 493 */           if (z != 0.0D)
/* 494 */             this._d[n] = d2 - d1 / z; 
/* 495 */           this._e[n - 1] = 0.0D;
/* 496 */           this._e[n] = 0.0D;
/* 497 */           d2 = this._h[n][n - 1];
/* 498 */           s = Math.abs(d2) + Math.abs(z);
/* 499 */           p = d2 / s;
/* 500 */           q = z / s;
/* 501 */           r = Math.sqrt(p * p + q * q);
/* 502 */           p /= r;
/* 503 */           q /= r;
/*     */ 
/*     */           
/* 506 */           for (int i4 = n - 1; i4 < nn; i4++) {
/* 507 */             z = this._h[n - 1][i4];
/* 508 */             this._h[n - 1][i4] = q * z + p * this._h[n][i4];
/* 509 */             this._h[n][i4] = q * this._h[n][i4] - p * z;
/*     */           } 
/*     */           
/*     */           int i3;
/* 513 */           for (i3 = 0; i3 <= n; i3++) {
/* 514 */             z = this._h[i3][n - 1];
/* 515 */             this._h[i3][n - 1] = q * z + p * this._h[i3][n];
/* 516 */             this._h[i3][n] = q * this._h[i3][n] - p * z;
/*     */           } 
/*     */ 
/*     */           
/* 520 */           for (i3 = low; i3 <= high; i3++) {
/* 521 */             z = this._v[i3][n - 1];
/* 522 */             this._v[i3][n - 1] = q * z + p * this._v[i3][n];
/* 523 */             this._v[i3][n] = q * this._v[i3][n] - p * z;
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 529 */           this._d[n - 1] = d2 + p;
/* 530 */           this._d[n] = d2 + p;
/* 531 */           this._e[n - 1] = z;
/* 532 */           this._e[n] = -z;
/*     */         } 
/* 534 */         n -= 2;
/* 535 */         iter = 0;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 542 */       double x = this._h[n][n];
/* 543 */       double y = 0.0D;
/* 544 */       double w = 0.0D;
/* 545 */       if (l < n) {
/* 546 */         y = this._h[n - 1][n - 1];
/* 547 */         w = this._h[n][n - 1] * this._h[n - 1][n];
/*     */       } 
/*     */ 
/*     */       
/* 551 */       if (iter == 10) {
/* 552 */         exshift += x;
/* 553 */         for (int i3 = low; i3 <= n; i3++)
/* 554 */           this._h[i3][i3] = this._h[i3][i3] - x; 
/* 555 */         s = Math.abs(this._h[n][n - 1]) + Math.abs(this._h[n - 1][n - 2]);
/* 556 */         x = y = 0.75D * s;
/* 557 */         w = -0.4375D * s * s;
/*     */       } 
/*     */ 
/*     */       
/* 561 */       if (iter == 30) {
/* 562 */         s = (y - x) / 2.0D;
/* 563 */         s = s * s + w;
/* 564 */         if (s > 0.0D) {
/* 565 */           s = Math.sqrt(s);
/* 566 */           if (y < x)
/* 567 */             s = -s; 
/* 568 */           s = x - w / ((y - x) / 2.0D + s);
/* 569 */           for (int i3 = low; i3 <= n; i3++)
/* 570 */             this._h[i3][i3] = this._h[i3][i3] - s; 
/* 571 */           exshift += s;
/* 572 */           x = y = w = 0.964D;
/*     */         } 
/*     */       } 
/*     */       
/* 576 */       iter++;
/*     */ 
/*     */       
/* 579 */       int m = n - 2;
/* 580 */       while (m >= l) {
/* 581 */         z = this._h[m][m];
/* 582 */         r = x - z;
/* 583 */         s = y - z;
/* 584 */         p = (r * s - w) / this._h[m + 1][m] + this._h[m][m + 1];
/* 585 */         q = this._h[m + 1][m + 1] - z - r - s;
/* 586 */         r = this._h[m + 2][m + 1];
/* 587 */         s = Math.abs(p) + Math.abs(q) + Math.abs(r);
/* 588 */         p /= s;
/* 589 */         q /= s;
/* 590 */         r /= s;
/* 591 */         if (m == l)
/*     */           break; 
/* 593 */         if (Math.abs(this._h[m][m - 1]) * (Math.abs(q) + Math.abs(r)) < eps * Math.abs(p) * (Math.abs(this._h[m - 1][m - 1]) + Math.abs(z) + Math.abs(this._h[m + 1][m + 1]))) {
/*     */           break;
/*     */         }
/*     */         
/* 597 */         m--;
/*     */       } 
/* 599 */       for (int i2 = m + 2; i2 <= n; i2++) {
/* 600 */         this._h[i2][i2 - 2] = 0.0D;
/* 601 */         if (i2 > m + 2) {
/* 602 */           this._h[i2][i2 - 3] = 0.0D;
/*     */         }
/*     */       } 
/*     */       
/* 606 */       for (int i1 = m; i1 <= n - 1; i1++) {
/* 607 */         boolean notlast = (i1 != n - 1);
/* 608 */         if (i1 != m) {
/* 609 */           p = this._h[i1][i1 - 1];
/* 610 */           q = this._h[i1 + 1][i1 - 1];
/* 611 */           r = notlast ? this._h[i1 + 2][i1 - 1] : 0.0D;
/* 612 */           x = Math.abs(p) + Math.abs(q) + Math.abs(r);
/* 613 */           if (x != 0.0D) {
/* 614 */             p /= x;
/* 615 */             q /= x;
/* 616 */             r /= x;
/*     */           } 
/*     */         } 
/* 619 */         if (x == 0.0D)
/*     */           break; 
/* 621 */         s = Math.sqrt(p * p + q * q + r * r);
/* 622 */         if (p < 0.0D)
/* 623 */           s = -s; 
/* 624 */         if (s != 0.0D) {
/* 625 */           if (i1 != m) {
/* 626 */             this._h[i1][i1 - 1] = -s * x;
/* 627 */           } else if (l != m) {
/* 628 */             this._h[i1][i1 - 1] = -this._h[i1][i1 - 1];
/*     */           } 
/* 630 */           p += s;
/* 631 */           x = p / s;
/* 632 */           y = q / s;
/* 633 */           z = r / s;
/* 634 */           q /= p;
/* 635 */           r /= p;
/*     */ 
/*     */           
/* 638 */           for (int i4 = i1; i4 < nn; i4++) {
/* 639 */             p = this._h[i1][i4] + q * this._h[i1 + 1][i4];
/* 640 */             if (notlast) {
/* 641 */               p += r * this._h[i1 + 2][i4];
/* 642 */               this._h[i1 + 2][i4] = this._h[i1 + 2][i4] - p * z;
/*     */             } 
/* 644 */             this._h[i1][i4] = this._h[i1][i4] - p * x;
/* 645 */             this._h[i1 + 1][i4] = this._h[i1 + 1][i4] - p * y;
/*     */           } 
/*     */           
/*     */           int i3;
/* 649 */           for (i3 = 0; i3 <= Math.min(n, i1 + 3); i3++) {
/* 650 */             p = x * this._h[i3][i1] + y * this._h[i3][i1 + 1];
/* 651 */             if (notlast) {
/* 652 */               p += z * this._h[i3][i1 + 2];
/* 653 */               this._h[i3][i1 + 2] = this._h[i3][i1 + 2] - p * r;
/*     */             } 
/* 655 */             this._h[i3][i1] = this._h[i3][i1] - p;
/* 656 */             this._h[i3][i1 + 1] = this._h[i3][i1 + 1] - p * q;
/*     */           } 
/*     */ 
/*     */           
/* 660 */           for (i3 = low; i3 <= high; i3++) {
/* 661 */             p = x * this._v[i3][i1] + y * this._v[i3][i1 + 1];
/* 662 */             if (notlast) {
/* 663 */               p += z * this._v[i3][i1 + 2];
/* 664 */               this._v[i3][i1 + 2] = this._v[i3][i1 + 2] - p * r;
/*     */             } 
/* 666 */             this._v[i3][i1] = this._v[i3][i1] - p;
/* 667 */             this._v[i3][i1 + 1] = this._v[i3][i1 + 1] - p * q;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 675 */     if (norm == 0.0D) {
/*     */       return;
/*     */     }
/* 678 */     for (n = nn - 1; n >= 0; n--) {
/* 679 */       p = this._d[n];
/* 680 */       q = this._e[n];
/*     */ 
/*     */       
/* 683 */       if (q == 0.0D) {
/* 684 */         int l = n;
/* 685 */         this._h[n][n] = 1.0D;
/* 686 */         for (int m = n - 1; m >= 0; m--) {
/* 687 */           double w = this._h[m][m] - p;
/* 688 */           r = 0.0D; int i1;
/* 689 */           for (i1 = l; i1 <= n; i1++)
/* 690 */             r += this._h[m][i1] * this._h[i1][n]; 
/* 691 */           if (this._e[m] < 0.0D) {
/* 692 */             z = w;
/* 693 */             s = r;
/*     */           } else {
/* 695 */             l = m;
/* 696 */             if (this._e[m] == 0.0D) {
/* 697 */               if (w != 0.0D) {
/* 698 */                 this._h[m][n] = -r / w;
/*     */               } else {
/* 700 */                 this._h[m][n] = -r / eps * norm;
/*     */               }
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 706 */               double x = this._h[m][m + 1];
/* 707 */               double y = this._h[m + 1][m];
/* 708 */               q = (this._d[m] - p) * (this._d[m] - p) + this._e[m] * this._e[m];
/* 709 */               double d1 = (x * s - z * r) / q;
/* 710 */               this._h[m][n] = d1;
/* 711 */               if (Math.abs(x) > Math.abs(z)) {
/* 712 */                 this._h[m + 1][n] = (-r - w * d1) / x;
/*     */               } else {
/* 714 */                 this._h[m + 1][n] = (-s - y * d1) / z;
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 719 */             double t = Math.abs(this._h[m][n]);
/* 720 */             if (eps * t * t > 1.0D) {
/* 721 */               for (i1 = m; i1 <= n; i1++) {
/* 722 */                 this._h[i1][n] = this._h[i1][n] / t;
/*     */               }
/*     */             }
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 729 */       } else if (q < 0.0D) {
/* 730 */         int l = n - 1;
/*     */ 
/*     */         
/* 733 */         if (Math.abs(this._h[n][n - 1]) > Math.abs(this._h[n - 1][n])) {
/* 734 */           this._h[n - 1][n - 1] = q / this._h[n][n - 1];
/* 735 */           this._h[n - 1][n] = -(this._h[n][n] - p) / this._h[n][n - 1];
/*     */         } else {
/* 737 */           cdiv(0.0D, -this._h[n - 1][n], this._h[n - 1][n - 1] - p, q);
/* 738 */           this._h[n - 1][n - 1] = this._cdivr;
/* 739 */           this._h[n - 1][n] = this._cdivi;
/*     */         } 
/* 741 */         this._h[n][n - 1] = 0.0D;
/* 742 */         this._h[n][n] = 1.0D;
/* 743 */         for (int m = n - 2; m >= 0; m--) {
/*     */           
/* 745 */           double ra = 0.0D;
/* 746 */           double sa = 0.0D; int i1;
/* 747 */           for (i1 = l; i1 <= n; i1++) {
/* 748 */             ra += this._h[m][i1] * this._h[i1][n - 1];
/* 749 */             sa += this._h[m][i1] * this._h[i1][n];
/*     */           } 
/* 751 */           double w = this._h[m][m] - p;
/* 752 */           if (this._e[m] < 0.0D) {
/* 753 */             z = w;
/* 754 */             r = ra;
/* 755 */             s = sa;
/*     */           } else {
/* 757 */             l = m;
/* 758 */             if (this._e[m] == 0.0D) {
/* 759 */               cdiv(-ra, -sa, w, q);
/* 760 */               this._h[m][n - 1] = this._cdivr;
/* 761 */               this._h[m][n] = this._cdivi;
/*     */             }
/*     */             else {
/*     */               
/* 765 */               double x = this._h[m][m + 1];
/* 766 */               double y = this._h[m + 1][m];
/* 767 */               double vr = (this._d[m] - p) * (this._d[m] - p) + this._e[m] * this._e[m] - q * q;
/* 768 */               double vi = (this._d[m] - p) * 2.0D * q;
/* 769 */               if (vr == 0.0D && vi == 0.0D)
/* 770 */                 vr = eps * norm * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z)); 
/* 771 */               cdiv(x * r - z * ra + q * sa, x * s - z * sa - q * ra, vr, vi);
/* 772 */               this._h[m][n - 1] = this._cdivr;
/* 773 */               this._h[m][n] = this._cdivi;
/* 774 */               if (Math.abs(x) > Math.abs(z) + Math.abs(q)) {
/* 775 */                 this._h[m + 1][n - 1] = (-ra - w * this._h[m][n - 1] + q * this._h[m][n]) / x;
/* 776 */                 this._h[m + 1][n] = (-sa - w * this._h[m][n] - q * this._h[m][n - 1]) / x;
/*     */               } else {
/* 778 */                 cdiv(-r - y * this._h[m][n - 1], -s - y * this._h[m][n], z, q);
/* 779 */                 this._h[m + 1][n - 1] = this._cdivr;
/* 780 */                 this._h[m + 1][n] = this._cdivi;
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 785 */             double t = Math.max(Math.abs(this._h[m][n - 1]), Math.abs(this._h[m][n]));
/* 786 */             if (eps * t * t > 1.0D) {
/* 787 */               for (i1 = m; i1 < n; i1++) {
/* 788 */                 this._h[i1][n - 1] = this._h[i1][n - 1] / t;
/* 789 */                 this._h[i1][n] = this._h[i1][n] / t;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 798 */     for (int k = 0; k < nn; k++) {
/* 799 */       if (k < low || k > high) {
/* 800 */         for (int m = k; m < nn; m++) {
/* 801 */           this._v[k][m] = this._h[k][m];
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 806 */     for (int j = nn - 1; j >= low; j--) {
/* 807 */       for (int m = low; m <= high; m++) {
/* 808 */         z = 0.0D;
/* 809 */         for (int i1 = low; i1 <= Math.min(j, high); i1++)
/* 810 */           z += this._v[m][i1] * this._h[i1][j]; 
/* 811 */         this._v[m][j] = z;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/DMatrixEvd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */