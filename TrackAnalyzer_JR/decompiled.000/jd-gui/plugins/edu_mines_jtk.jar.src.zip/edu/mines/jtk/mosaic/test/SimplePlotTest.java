/*    */ package edu.mines.jtk.mosaic.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.mosaic.SimplePlot;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimplePlotTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     SwingUtilities.invokeLater(new Runnable() {
/*    */           public void run() {
/* 25 */             SimplePlotTest.plot0();
/* 26 */             SimplePlotTest.plot1();
/* 27 */             SimplePlotTest.plot2();
/* 28 */             SimplePlotTest.plot3();
/*    */           }
/*    */         });
/*    */   }
/*    */   private static void plot0() {
/* 33 */     float[] f = Array.sin(Array.rampfloat(0.0F, 0.1F, 63));
/* 34 */     SimplePlot.asSequence(f);
/*    */   }
/*    */   private static void plot1() {
/* 37 */     int nx = 301;
/* 38 */     float dx = 0.1F;
/* 39 */     float fx = 0.0F;
/* 40 */     Sampling sx = new Sampling(nx, dx, fx);
/* 41 */     float[] x = Array.rampfloat(fx, dx, nx);
/* 42 */     float[] f = Array.sub(Array.mul(x, Array.sin(x)), 1.0F);
/* 43 */     SimplePlot.asPoints(sx, f);
/*    */   }
/*    */   private static void plot2() {
/* 46 */     float[][] f = Array.sin(Array.rampfloat(0.0F, 0.1F, 0.1F, 101, 101));
/* 47 */     SimplePlot.asPixels(f).addColorBar();
/*    */   }
/*    */   private static void plot3() {
/* 50 */     SimplePlot plot = new SimplePlot();
/* 51 */     plot.addGrid("H-.V-.");
/* 52 */     float[] f = Array.sin(Array.rampfloat(0.0F, 0.1F, 63));
/* 53 */     plot.addPoints(f).setStyle("r-o");
/* 54 */     float[] g = Array.cos(Array.rampfloat(0.0F, 0.1F, 63));
/* 55 */     plot.addPoints(g).setStyle("b-x");
/* 56 */     plot.setTitle("A simple plot of two arrays");
/* 57 */     plot.setVLabel("array value");
/* 58 */     plot.setHLabel("array index");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/SimplePlotTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */