/*     */ package edu.mines.jtk.awt;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModeManager
/*     */ {
/*     */   public void add(Component c) {
/*  38 */     this._cset.add(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Component c) {
/*  46 */     this._cset.remove(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(Mode m) {
/*  56 */     this._mset.add(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setActive(Mode mode, boolean active) {
/*  65 */     if (active == mode.isActive()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  71 */     Mode modeDeactivated = null;
/*  72 */     if (active && mode.isExclusive()) {
/*  73 */       for (Mode m : this._mset) {
/*  74 */         if (m != mode && m.isExclusive() && m.isActive()) {
/*  75 */           setActiveInternal(m, false);
/*  76 */           modeDeactivated = m;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  83 */     setActiveInternal(mode, active);
/*     */ 
/*     */ 
/*     */     
/*  87 */     if (!active && mode.isExclusive() && this._modeDeactivated != null) {
/*  88 */       setActiveInternal(this._modeDeactivated, true);
/*     */     }
/*     */ 
/*     */     
/*  92 */     this._modeDeactivated = modeDeactivated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private Set<Mode> _mset = new HashSet<Mode>();
/*  99 */   private Set<Component> _cset = new HashSet<Component>();
/*     */   private Mode _modeDeactivated;
/*     */   
/*     */   private void setActiveInternal(Mode mode, boolean active) {
/* 103 */     Cursor cursor = active ? mode.getCursor() : null;
/* 104 */     if (cursor == null)
/* 105 */       cursor = Cursor.getDefaultCursor(); 
/* 106 */     mode.setActiveInternal(active);
/* 107 */     for (Component c : this._cset) {
/* 108 */       c.setCursor(cursor);
/* 109 */       mode.setActive(c, active);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/ModeManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */