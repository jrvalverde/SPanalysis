/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnitsFormatException
/*    */   extends Exception
/*    */ {
/*    */   UnitsFormatException() {}
/*    */   
/*    */   UnitsFormatException(String s) {
/* 21 */     super(s);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/UnitsFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */