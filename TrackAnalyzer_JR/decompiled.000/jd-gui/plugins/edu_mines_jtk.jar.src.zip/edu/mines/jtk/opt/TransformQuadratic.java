/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformQuadratic
/*     */   implements Quadratic
/*     */ {
/*  61 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */   
/*     */   private VectConst _data;
/*     */ 
/*     */ 
/*     */   
/*     */   private VectConst _referenceModel;
/*     */ 
/*     */ 
/*     */   
/*     */   private VectConst _perturbModel;
/*     */ 
/*     */ 
/*     */   
/*     */   private Transform _transform;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _dampOnlyPerturbation = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public TransformQuadratic(VectConst data, VectConst referenceModel, VectConst perturbModel, Transform transform, boolean dampOnlyPerturbation) {
/*  86 */     this._data = data;
/*  87 */     this._referenceModel = referenceModel;
/*  88 */     this._perturbModel = perturbModel;
/*  89 */     this._transform = transform;
/*  90 */     this._dampOnlyPerturbation = dampOnlyPerturbation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTransposePrecision() {
/* 100 */     VectConst d = this._data;
/* 101 */     Vect b = getB();
/* 102 */     double bb = b.dot(b);
/* 103 */     checkNaN(bb);
/* 104 */     assert !Almost.FLOAT.zero(bb) : "Cannot test with zero-magnitude b";
/*     */ 
/*     */     
/* 107 */     Vect Fb = VectUtil.cloneZero(d);
/* 108 */     Vect bSave = b.clone();
/* 109 */     this._transform.forwardLinearized(Fb, b, this._referenceModel);
/*     */ 
/*     */     
/* 112 */     assert VectUtil.areSame(b, bSave) : "model was changed by forward model";
/* 113 */     bSave.dispose();
/*     */ 
/*     */     
/* 116 */     Vect test = d.clone();
/* 117 */     this._transform.forwardLinearized(test, b, this._referenceModel);
/* 118 */     assert VectUtil.areSame(test, Fb) : "forwardLinearized should zero data";
/* 119 */     test.dispose();
/*     */ 
/*     */     
/* 122 */     Vect Ad = VectUtil.cloneZero(b);
/* 123 */     Vect dSave = d.clone();
/* 124 */     this._transform.addTranspose(d, Ad, this._referenceModel);
/* 125 */     double transposeMagnitude = Ad.dot(Ad);
/* 126 */     checkNaN(transposeMagnitude);
/*     */ 
/*     */     
/* 129 */     assert VectUtil.areSame(d, dSave) : "data was changed by transpose";
/* 130 */     dSave.dispose();
/*     */ 
/*     */     
/* 133 */     test = b.clone();
/* 134 */     double scaleTest = 1.1D * Math.sqrt(transposeMagnitude / bb);
/* 135 */     VectUtil.scale(test, scaleTest);
/* 136 */     this._transform.addTranspose(d, test, this._referenceModel);
/*     */     
/* 138 */     assert !VectUtil.areSame(Ad, test) : "Transpose should not zero model.  Magnitude: b=" + bb + "trans=" + transposeMagnitude + " test=" + test.dot(test);
/* 139 */     test.add(1.0D, -1.0D, Ad);
/* 140 */     VectUtil.scale(test, 1.0D / scaleTest);
/* 141 */     assert VectUtil.areSame(test, b) : "Transpose did not add to model vector";
/* 142 */     test.dispose();
/*     */ 
/*     */     
/* 145 */     double dFb = d.dot(Fb);
/* 146 */     double Adb = Ad.dot(b);
/* 147 */     assert !Almost.FLOAT.zero(dFb) : "zero magnitude test: dFb is zero";
/* 148 */     assert !Almost.FLOAT.zero(Adb) : "zero magnitude test: Adb is zero";
/* 149 */     checkNaN(dFb);
/* 150 */     checkNaN(Adb);
/*     */     
/* 152 */     int significantDigits = 10;
/* 153 */     boolean matches = false;
/* 154 */     while (!matches && significantDigits > 0) {
/* 155 */       Almost almost = new Almost(significantDigits);
/* 156 */       matches = almost.equal(dFb, Adb);
/* 157 */       if (!matches) {
/* 158 */         significantDigits--;
/*     */       }
/*     */     } 
/* 161 */     if (significantDigits < 3) {
/* 162 */       LOG.severe("Transpose precision is unacceptable: dFb=" + dFb + " Adb=" + Adb);
/*     */     }
/* 164 */     Ad.dispose();
/* 165 */     Fb.dispose();
/* 166 */     b.dispose();
/* 167 */     return significantDigits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void multiplyHessian(Vect x) {
/* 174 */     Vect data = this._data.clone();
/* 175 */     this._transform.forwardLinearized(data, x, this._referenceModel);
/* 176 */     data.multiplyInverseCovariance();
/* 177 */     x.multiplyInverseCovariance();
/* 178 */     this._transform.addTranspose(data, x, this._referenceModel);
/* 179 */     data.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void inverseHessian(Vect x) {
/* 184 */     this._transform.inverseHessian(x, this._referenceModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vect getB() {
/* 195 */     Vect data = VectUtil.cloneZero(this._data);
/* 196 */     this._transform.forwardNonlinear(data, this._referenceModel);
/* 197 */     data.add(1.0D, -1.0D, this._data);
/* 198 */     this._transform.adjustRobustErrors(data);
/* 199 */     data.multiplyInverseCovariance();
/* 200 */     Vect b = null;
/* 201 */     if (this._dampOnlyPerturbation) {
/* 202 */       if (this._perturbModel != null) {
/* 203 */         b = VectUtil.cloneZero(this._perturbModel);
/*     */       } else {
/* 205 */         b = VectUtil.cloneZero(this._referenceModel);
/*     */       } 
/*     */     } else {
/* 208 */       if (this._perturbModel != null) {
/* 209 */         b = this._perturbModel.clone();
/* 210 */         b.project(0.0D, 1.0D, this._referenceModel);
/*     */       } else {
/* 212 */         b = this._referenceModel.clone();
/*     */       } 
/* 214 */       b.multiplyInverseCovariance();
/*     */     } 
/* 216 */     this._transform.addTranspose(data, b, this._referenceModel);
/* 217 */     data.dispose();
/* 218 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double evalFullObjectiveFunction(VectConst m) {
/* 239 */     Vect data = VectUtil.cloneZero(this._data);
/*     */     
/* 241 */     Vect model = m.clone();
/* 242 */     model.constrain();
/*     */     
/* 244 */     this._transform.forwardNonlinear(data, model);
/* 245 */     data.add(1.0D, -1.0D, this._data);
/* 246 */     this._transform.adjustRobustErrors(data);
/* 247 */     double eNe = data.magnitude();
/* 248 */     checkNaN(eNe);
/* 249 */     data.dispose();
/*     */ 
/*     */     
/* 252 */     if (this._dampOnlyPerturbation) {
/* 253 */       model.add(1.0D, -1.0D, this._referenceModel);
/*     */     }
/*     */     
/* 256 */     double mMm = model.magnitude();
/* 257 */     checkNaN(mMm);
/* 258 */     model.dispose();
/* 259 */     return eNe + mMm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkNaN(double value) {
/* 266 */     if (value * 0.0D != 0.0D)
/* 267 */       throw new IllegalStateException("Value is a NaN"); 
/*     */   }
/*     */   
/*     */   public void dispose() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/TransformQuadratic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */