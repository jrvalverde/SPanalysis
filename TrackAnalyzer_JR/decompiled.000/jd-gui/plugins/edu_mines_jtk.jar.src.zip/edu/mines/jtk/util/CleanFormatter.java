/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Formatter;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CleanFormatter
/*     */   extends Formatter
/*     */ {
/*  19 */   private static String s_prefix = "";
/*     */ 
/*     */ 
/*     */   
/*  23 */   private static final DateFormat TIMESTAMP_FORMAT = new SimpleDateFormat("yyyyMMdd-HHmmss");
/*     */ 
/*     */ 
/*     */   
/*  27 */   private static final String NL = System.getProperty("line.separator");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setWarningPrefix(String prefix) {
/*  35 */     s_prefix = prefix;
/*     */   }
/*     */   
/*  38 */   private Level lastLevel = Level.INFO;
/*     */ 
/*     */   
/*     */   public synchronized String format(LogRecord record) {
/*  42 */     String message = formatMessage(record);
/*  43 */     if (message == null) return null; 
/*  44 */     if (message.length() == 0) return message;
/*     */ 
/*     */     
/*  47 */     message = Localize.filter(message, record.getResourceBundle());
/*     */     
/*  49 */     if (message.endsWith("\\")) {
/*  50 */       message = message.substring(0, message.length() - 1);
/*  51 */     } else if (!message.matches("^\\s*(" + NL + ")?$")) {
/*     */       
/*  53 */       message = message + NL;
/*     */     } 
/*  55 */     Level level = record.getLevel();
/*  56 */     if (!level.equals(Level.INFO))
/*     */     {
/*  58 */       if (level.equals(Level.WARNING)) {
/*  59 */         if (message.indexOf("WARNING") == -1) {
/*  60 */           message = prependToLines(s_prefix + level + ": ", message);
/*     */         } else {
/*  62 */           message = s_prefix + message;
/*     */         } 
/*  64 */       } else if (level.equals(Level.SEVERE)) {
/*  65 */         message = prependToLines(level + ": ", message);
/*  66 */         if (!this.lastLevel.equals(Level.SEVERE)) {
/*  67 */           message = s_prefix + "**** SEVERE WARNING **** (" + record.getSourceClassName() + "." + record.getSourceMethodName() + " " + getTimeStamp(record.getMillis()) + " " + "#" + record.getThreadID() + ")" + NL + message;
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  73 */       else if (level.equals(Level.FINE) || level.equals(Level.FINER) || level.equals(Level.FINEST)) {
/*     */ 
/*     */         
/*  76 */         String shortPackage = record.getLoggerName();
/*  77 */         int index = shortPackage.lastIndexOf(".");
/*  78 */         if (index > 0) shortPackage = shortPackage.substring(index + 1); 
/*  79 */         message = prependToLines(level + " " + shortPackage + ": ", message);
/*     */       } else {
/*  81 */         message = prependToLines(level + " " + s_time_formatter.format(new Date()) + " " + record.getLoggerName() + ": ", message);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  86 */     this.lastLevel = level;
/*  87 */     return message;
/*     */   }
/*  89 */   private static DateFormat s_time_formatter = new SimpleDateFormat("HH:mm:ss.SSS");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String prependToLines(String prepend, String lines) {
/*  99 */     if (lines == null) return null; 
/* 100 */     if (prepend == null) return lines; 
/* 101 */     StringBuilder result = new StringBuilder();
/* 102 */     boolean hasFinalNL = lines.endsWith(NL);
/* 103 */     StringTokenizer divided = new StringTokenizer(lines, NL);
/* 104 */     while (divided.hasMoreTokens()) {
/* 105 */       result.append(prepend + divided.nextToken());
/* 106 */       if (divided.hasMoreTokens() || hasFinalNL) result.append(NL); 
/*     */     } 
/* 108 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTimeStamp(Date date) {
/* 117 */     synchronized (TIMESTAMP_FORMAT) {
/* 118 */       return TIMESTAMP_FORMAT.format(date);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTimeStamp(long date) {
/* 128 */     return getTimeStamp(new Date(date));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/CleanFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */