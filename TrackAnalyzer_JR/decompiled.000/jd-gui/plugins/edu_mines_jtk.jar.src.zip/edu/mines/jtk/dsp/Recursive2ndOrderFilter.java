/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Cdouble;
/*      */ import edu.mines.jtk.util.Check;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Recursive2ndOrderFilter
/*      */ {
/*      */   private float _b0;
/*      */   private float _b1;
/*      */   private float _b2;
/*      */   private float _a1;
/*      */   private float _a2;
/*      */   
/*      */   public Recursive2ndOrderFilter(float b0, float b1, float b2, float a1, float a2) {
/*   44 */     this._b0 = b0;
/*   45 */     this._b1 = b1;
/*   46 */     this._b2 = b2;
/*   47 */     this._a1 = a1;
/*   48 */     this._a2 = a2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Recursive2ndOrderFilter(double pole, double zero, double gain) {
/*   60 */     this._b0 = (float)gain;
/*   61 */     this._b1 = (float)(-gain * zero);
/*   62 */     this._a1 = (float)-pole;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Recursive2ndOrderFilter(Cdouble pole1, Cdouble pole2, Cdouble zero1, Cdouble zero2, double gain) {
/*   79 */     Check.argument(((pole1.i == 0.0D && pole2.i == 0.0D) || (pole2.r == pole1.r && -pole2.i == pole1.i)), "poles are real or conjugate pair");
/*      */ 
/*      */     
/*   82 */     Check.argument(((zero1.i == 0.0D && zero2.i == 0.0D) || (zero2.r == zero1.r && -zero2.i == zero1.i)), "zeros are real or conjugate pair");
/*      */ 
/*      */     
/*   85 */     this._b0 = (float)gain;
/*   86 */     this._b1 = (float)(-(zero1.r + zero2.r) * gain);
/*   87 */     this._b2 = (float)((zero1.times(zero2)).r * gain);
/*   88 */     this._a1 = (float)-(pole1.r + pole2.r);
/*   89 */     this._a2 = (float)(pole1.times(pole2)).r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyForward(float[] x, float[] y) {
/*  101 */     checkArrays(x, y);
/*  102 */     int n = y.length;
/*      */ 
/*      */     
/*  105 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  106 */       float yim1 = 0.0F;
/*  107 */       for (int i = 0; i < n; i++) {
/*  108 */         float xi = x[i];
/*  109 */         float yi = this._b0 * xi - this._a1 * yim1;
/*  110 */         y[i] = yi;
/*  111 */         yim1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  116 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  117 */       float yim1 = 0.0F;
/*  118 */       float xim1 = 0.0F;
/*  119 */       for (int i = 0; i < n; i++) {
/*  120 */         float xi = x[i];
/*  121 */         float yi = this._b0 * xi + this._b1 * xim1 - this._a1 * yim1;
/*  122 */         y[i] = yi;
/*  123 */         yim1 = yi;
/*  124 */         xim1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  129 */     else if (this._b2 == 0.0F) {
/*  130 */       float yim2 = 0.0F;
/*  131 */       float yim1 = 0.0F;
/*  132 */       float xim1 = 0.0F;
/*  133 */       for (int i = 0; i < n; i++) {
/*  134 */         float xi = x[i];
/*  135 */         float yi = this._b0 * xi + this._b1 * xim1 - this._a1 * yim1 - this._a2 * yim2;
/*  136 */         y[i] = yi;
/*  137 */         yim2 = yim1;
/*  138 */         yim1 = yi;
/*  139 */         xim1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  144 */     else if (this._b0 == 0.0F) {
/*  145 */       float yim2 = 0.0F;
/*  146 */       float yim1 = 0.0F;
/*  147 */       float xim2 = 0.0F;
/*  148 */       float xim1 = 0.0F;
/*  149 */       for (int i = 0; i < n; i++) {
/*  150 */         float xi = x[i];
/*  151 */         float yi = this._b1 * xim1 + this._b2 * xim2 - this._a1 * yim1 - this._a2 * yim2;
/*  152 */         y[i] = yi;
/*  153 */         yim2 = yim1;
/*  154 */         yim1 = yi;
/*  155 */         xim2 = xim1;
/*  156 */         xim1 = xi;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  162 */       float yim2 = 0.0F;
/*  163 */       float yim1 = 0.0F;
/*  164 */       float xim2 = 0.0F;
/*  165 */       float xim1 = 0.0F;
/*  166 */       for (int i = 0; i < n; i++) {
/*  167 */         float xi = x[i];
/*  168 */         float yi = this._b0 * xi + this._b1 * xim1 + this._b2 * xim2 - this._a1 * yim1 - this._a2 * yim2;
/*  169 */         y[i] = yi;
/*  170 */         yim2 = yim1;
/*  171 */         yim1 = yi;
/*  172 */         xim2 = xim1;
/*  173 */         xim1 = xi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyReverse(float[] x, float[] y) {
/*  187 */     checkArrays(x, y);
/*  188 */     int n = y.length;
/*      */ 
/*      */     
/*  191 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  192 */       float yip1 = 0.0F;
/*  193 */       for (int i = n - 1; i >= 0; i--) {
/*  194 */         float xi = x[i];
/*  195 */         float yi = this._b0 * xi - this._a1 * yip1;
/*  196 */         y[i] = yi;
/*  197 */         yip1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  202 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  203 */       float xip1 = 0.0F;
/*  204 */       float yip1 = 0.0F;
/*  205 */       for (int i = n - 1; i >= 0; i--) {
/*  206 */         float xi = x[i];
/*  207 */         float yi = this._b0 * xi + this._b1 * xip1 - this._a1 * yip1;
/*  208 */         y[i] = yi;
/*  209 */         yip1 = yi;
/*  210 */         xip1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  215 */     else if (this._b2 == 0.0F) {
/*  216 */       float xip1 = 0.0F;
/*  217 */       float yip1 = 0.0F;
/*  218 */       float yip2 = 0.0F;
/*  219 */       for (int i = n - 1; i >= 0; i--) {
/*  220 */         float xi = x[i];
/*  221 */         float yi = this._b0 * xi + this._b1 * xip1 - this._a1 * yip1 - this._a2 * yip2;
/*  222 */         y[i] = yi;
/*  223 */         yip2 = yip1;
/*  224 */         yip1 = yi;
/*  225 */         xip1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  230 */     else if (this._b0 == 0.0F) {
/*  231 */       float xip1 = 0.0F;
/*  232 */       float xip2 = 0.0F;
/*  233 */       float yip1 = 0.0F;
/*  234 */       float yip2 = 0.0F;
/*  235 */       for (int i = n - 1; i >= 0; i--) {
/*  236 */         float xi = x[i];
/*  237 */         float yi = this._b1 * xip1 + this._b2 * xip2 - this._a1 * yip1 - this._a2 * yip2;
/*  238 */         y[i] = yi;
/*  239 */         yip2 = yip1;
/*  240 */         yip1 = yi;
/*  241 */         xip2 = xip1;
/*  242 */         xip1 = xi;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  248 */       float xip1 = 0.0F;
/*  249 */       float xip2 = 0.0F;
/*  250 */       float yip1 = 0.0F;
/*  251 */       float yip2 = 0.0F;
/*  252 */       for (int i = n - 1; i >= 0; i--) {
/*  253 */         float xi = x[i];
/*  254 */         float yi = this._b0 * xi + this._b1 * xip1 + this._b2 * xip2 - this._a1 * yip1 - this._a2 * yip2;
/*  255 */         y[i] = yi;
/*  256 */         yip2 = yip1;
/*  257 */         yip1 = yi;
/*  258 */         xip2 = xip1;
/*  259 */         xip1 = xi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulateForward(float[] x, float[] y) {
/*  275 */     checkArrays(x, y);
/*  276 */     int n = y.length;
/*      */ 
/*      */     
/*  279 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  280 */       float yim1 = 0.0F;
/*  281 */       for (int i = 0; i < n; i++) {
/*  282 */         float xi = x[i];
/*  283 */         float yi = this._b0 * xi - this._a1 * yim1;
/*  284 */         y[i] = y[i] + yi;
/*  285 */         yim1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  290 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  291 */       float yim1 = 0.0F;
/*  292 */       float xim1 = 0.0F;
/*  293 */       for (int i = 0; i < n; i++) {
/*  294 */         float xi = x[i];
/*  295 */         float yi = this._b0 * xi + this._b1 * xim1 - this._a1 * yim1;
/*  296 */         y[i] = y[i] + yi;
/*  297 */         yim1 = yi;
/*  298 */         xim1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  303 */     else if (this._b2 == 0.0F) {
/*  304 */       float yim2 = 0.0F;
/*  305 */       float yim1 = 0.0F;
/*  306 */       float xim1 = 0.0F;
/*  307 */       for (int i = 0; i < n; i++) {
/*  308 */         float xi = x[i];
/*  309 */         float yi = this._b0 * xi + this._b1 * xim1 - this._a1 * yim1 - this._a2 * yim2;
/*  310 */         y[i] = y[i] + yi;
/*  311 */         yim2 = yim1;
/*  312 */         yim1 = yi;
/*  313 */         xim1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  318 */     else if (this._b0 == 0.0F) {
/*  319 */       float yim2 = 0.0F;
/*  320 */       float yim1 = 0.0F;
/*  321 */       float xim2 = 0.0F;
/*  322 */       float xim1 = 0.0F;
/*  323 */       for (int i = 0; i < n; i++) {
/*  324 */         float xi = x[i];
/*  325 */         float yi = this._b1 * xim1 + this._b2 * xim2 - this._a1 * yim1 - this._a2 * yim2;
/*  326 */         y[i] = y[i] + yi;
/*  327 */         yim2 = yim1;
/*  328 */         yim1 = yi;
/*  329 */         xim2 = xim1;
/*  330 */         xim1 = xi;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  336 */       float yim2 = 0.0F;
/*  337 */       float yim1 = 0.0F;
/*  338 */       float xim2 = 0.0F;
/*  339 */       float xim1 = 0.0F;
/*  340 */       for (int i = 0; i < n; i++) {
/*  341 */         float xi = x[i];
/*  342 */         float yi = this._b0 * xi + this._b1 * xim1 + this._b2 * xim2 - this._a1 * yim1 - this._a2 * yim2;
/*  343 */         y[i] = y[i] + yi;
/*  344 */         yim2 = yim1;
/*  345 */         yim1 = yi;
/*  346 */         xim2 = xim1;
/*  347 */         xim1 = xi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulateReverse(float[] x, float[] y) {
/*  363 */     checkArrays(x, y);
/*  364 */     int n = y.length;
/*      */ 
/*      */     
/*  367 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  368 */       float yip1 = 0.0F;
/*  369 */       for (int i = n - 1; i >= 0; i--) {
/*  370 */         float xi = x[i];
/*  371 */         float yi = this._b0 * xi - this._a1 * yip1;
/*  372 */         y[i] = y[i] + yi;
/*  373 */         yip1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  378 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  379 */       float xip1 = 0.0F;
/*  380 */       float yip1 = 0.0F;
/*  381 */       for (int i = n - 1; i >= 0; i--) {
/*  382 */         float xi = x[i];
/*  383 */         float yi = this._b0 * xi + this._b1 * xip1 - this._a1 * yip1;
/*  384 */         y[i] = y[i] + yi;
/*  385 */         yip1 = yi;
/*  386 */         xip1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  391 */     else if (this._b2 == 0.0F) {
/*  392 */       float xip1 = 0.0F;
/*  393 */       float yip1 = 0.0F;
/*  394 */       float yip2 = 0.0F;
/*  395 */       for (int i = n - 1; i >= 0; i--) {
/*  396 */         float xi = x[i];
/*  397 */         float yi = this._b0 * xi + this._b1 * xip1 - this._a1 * yip1 - this._a2 * yip2;
/*  398 */         y[i] = y[i] + yi;
/*  399 */         yip2 = yip1;
/*  400 */         yip1 = yi;
/*  401 */         xip1 = xi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  406 */     else if (this._b0 == 0.0F) {
/*  407 */       float xip1 = 0.0F;
/*  408 */       float xip2 = 0.0F;
/*  409 */       float yip1 = 0.0F;
/*  410 */       float yip2 = 0.0F;
/*  411 */       for (int i = n - 1; i >= 0; i--) {
/*  412 */         float xi = x[i];
/*  413 */         float yi = this._b1 * xip1 + this._b2 * xip2 - this._a1 * yip1 - this._a2 * yip2;
/*  414 */         y[i] = y[i] + yi;
/*  415 */         yip2 = yip1;
/*  416 */         yip1 = yi;
/*  417 */         xip2 = xip1;
/*  418 */         xip1 = xi;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  424 */       float xip1 = 0.0F;
/*  425 */       float xip2 = 0.0F;
/*  426 */       float yip1 = 0.0F;
/*  427 */       float yip2 = 0.0F;
/*  428 */       for (int i = n - 1; i >= 0; i--) {
/*  429 */         float xi = x[i];
/*  430 */         float yi = this._b0 * xi + this._b1 * xip1 + this._b2 * xip2 - this._a1 * yip1 - this._a2 * yip2;
/*  431 */         y[i] = y[i] + yi;
/*  432 */         yip2 = yip1;
/*  433 */         yip1 = yi;
/*  434 */         xip2 = xip1;
/*  435 */         xip1 = xi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1Forward(float[][] x, float[][] y) {
/*  452 */     checkArrays(x, y);
/*  453 */     int n2 = y.length;
/*  454 */     for (int i2 = 0; i2 < n2; i2++) {
/*  455 */       applyForward(x[i2], y[i2]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1Reverse(float[][] x, float[][] y) {
/*  468 */     checkArrays(x, y);
/*  469 */     int n2 = y.length;
/*  470 */     for (int i2 = 0; i2 < n2; i2++) {
/*  471 */       applyReverse(x[i2], y[i2]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2Forward(float[][] x, float[][] y) {
/*  484 */     checkArrays(x, y);
/*  485 */     int n2 = y.length;
/*  486 */     int n1 = (y[0]).length;
/*      */ 
/*      */     
/*  489 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  490 */       float[] yim1 = new float[n1];
/*  491 */       for (int i2 = 0; i2 < n2; i2++) {
/*  492 */         float[] xi = x[i2];
/*  493 */         float[] yi = y[i2];
/*  494 */         for (int i1 = 0; i1 < n1; i1++) {
/*  495 */           yi[i1] = this._b0 * xi[i1] - this._a1 * yim1[i1];
/*      */         }
/*      */         
/*  498 */         yim1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  503 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  504 */       float[] yim1 = new float[n1];
/*  505 */       float[] xim1 = new float[n1];
/*  506 */       float[] xi = new float[n1];
/*  507 */       for (int i2 = 0; i2 < n2; i2++) {
/*  508 */         float[] x2 = x[i2];
/*  509 */         float[] yi = y[i2];
/*  510 */         for (int i1 = 0; i1 < n1; i1++) {
/*  511 */           xi[i1] = x2[i1];
/*  512 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] - this._a1 * yim1[i1];
/*      */         } 
/*      */         
/*  515 */         yim1 = yi;
/*  516 */         float[] xt = xim1;
/*  517 */         xim1 = xi;
/*  518 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  523 */     else if (this._b2 == 0.0F) {
/*  524 */       float[] yim2 = new float[n1];
/*  525 */       float[] yim1 = new float[n1];
/*  526 */       float[] xim1 = new float[n1];
/*  527 */       float[] xi = new float[n1];
/*  528 */       for (int i2 = 0; i2 < n2; i2++) {
/*  529 */         float[] x2 = x[i2];
/*  530 */         float[] yi = y[i2];
/*  531 */         for (int i1 = 0; i1 < n1; i1++) {
/*  532 */           xi[i1] = x2[i1];
/*  533 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */         } 
/*      */         
/*  536 */         yim2 = yim1;
/*  537 */         yim1 = yi;
/*  538 */         float[] xt = xim1;
/*  539 */         xim1 = xi;
/*  540 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  545 */     else if (this._b0 == 0.0F) {
/*  546 */       float[] yim2 = new float[n1];
/*  547 */       float[] yim1 = new float[n1];
/*  548 */       float[] xim2 = new float[n1];
/*  549 */       float[] xim1 = new float[n1];
/*  550 */       float[] xi = new float[n1];
/*  551 */       for (int i2 = 0; i2 < n2; i2++) {
/*  552 */         float[] x2 = x[i2];
/*  553 */         float[] yi = y[i2];
/*  554 */         for (int i1 = 0; i1 < n1; i1++) {
/*  555 */           xi[i1] = x2[i1];
/*  556 */           yi[i1] = this._b1 * xim1[i1] + this._b2 * xim2[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */         } 
/*      */         
/*  559 */         yim2 = yim1;
/*  560 */         yim1 = yi;
/*  561 */         float[] xt = xim2;
/*  562 */         xim2 = xim1;
/*  563 */         xim1 = xi;
/*  564 */         xi = xt;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  570 */       float[] yim2 = new float[n1];
/*  571 */       float[] yim1 = new float[n1];
/*  572 */       float[] xim2 = new float[n1];
/*  573 */       float[] xim1 = new float[n1];
/*  574 */       float[] xi = new float[n1];
/*  575 */       for (int i2 = 0; i2 < n2; i2++) {
/*  576 */         float[] x2 = x[i2];
/*  577 */         float[] yi = y[i2];
/*  578 */         for (int i1 = 0; i1 < n1; i1++) {
/*  579 */           xi[i1] = x2[i1];
/*  580 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] + this._b2 * xim2[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */         } 
/*      */         
/*  583 */         yim2 = yim1;
/*  584 */         yim1 = yi;
/*  585 */         float[] xt = xim2;
/*  586 */         xim2 = xim1;
/*  587 */         xim1 = xi;
/*  588 */         xi = xt;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2Reverse(float[][] x, float[][] y) {
/*  602 */     checkArrays(x, y);
/*  603 */     int n2 = y.length;
/*  604 */     int n1 = (y[0]).length;
/*      */ 
/*      */     
/*  607 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  608 */       float[] yip1 = new float[n1];
/*  609 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  610 */         float[] xi = x[i2];
/*  611 */         float[] yi = y[i2];
/*  612 */         for (int i1 = 0; i1 < n1; i1++) {
/*  613 */           yi[i1] = this._b0 * xi[i1] - this._a1 * yip1[i1];
/*      */         }
/*      */         
/*  616 */         yip1 = yi;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  621 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  622 */       float[] yip1 = new float[n1];
/*  623 */       float[] xip1 = new float[n1];
/*  624 */       float[] xi = new float[n1];
/*  625 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  626 */         float[] x2 = x[i2];
/*  627 */         float[] yi = y[i2];
/*  628 */         for (int i1 = 0; i1 < n1; i1++) {
/*  629 */           xi[i1] = x2[i1];
/*  630 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] - this._a1 * yip1[i1];
/*      */         } 
/*      */         
/*  633 */         yip1 = yi;
/*  634 */         float[] xt = xip1;
/*  635 */         xip1 = xi;
/*  636 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  641 */     else if (this._b2 == 0.0F) {
/*  642 */       float[] yip2 = new float[n1];
/*  643 */       float[] yip1 = new float[n1];
/*  644 */       float[] xip1 = new float[n1];
/*  645 */       float[] xi = new float[n1];
/*  646 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  647 */         float[] x2 = x[i2];
/*  648 */         float[] yi = y[i2];
/*  649 */         for (int i1 = 0; i1 < n1; i1++) {
/*  650 */           xi[i1] = x2[i1];
/*  651 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */         } 
/*      */         
/*  654 */         yip2 = yip1;
/*  655 */         yip1 = yi;
/*  656 */         float[] xt = xip1;
/*  657 */         xip1 = xi;
/*  658 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  663 */     else if (this._b0 == 0.0F) {
/*  664 */       float[] yip2 = new float[n1];
/*  665 */       float[] yip1 = new float[n1];
/*  666 */       float[] xip2 = new float[n1];
/*  667 */       float[] xip1 = new float[n1];
/*  668 */       float[] xi = new float[n1];
/*  669 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  670 */         float[] x2 = x[i2];
/*  671 */         float[] yi = y[i2];
/*  672 */         for (int i1 = 0; i1 < n1; i1++) {
/*  673 */           xi[i1] = x2[i1];
/*  674 */           yi[i1] = this._b1 * xip1[i1] + this._b2 * xip2[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */         } 
/*      */         
/*  677 */         yip2 = yip1;
/*  678 */         yip1 = yi;
/*  679 */         float[] xt = xip2;
/*  680 */         xip2 = xip1;
/*  681 */         xip1 = xi;
/*  682 */         xi = xt;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  688 */       float[] yip2 = new float[n1];
/*  689 */       float[] yip1 = new float[n1];
/*  690 */       float[] xip2 = new float[n1];
/*  691 */       float[] xip1 = new float[n1];
/*  692 */       float[] xi = new float[n1];
/*  693 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  694 */         float[] x2 = x[i2];
/*  695 */         float[] yi = y[i2];
/*  696 */         for (int i1 = 0; i1 < n1; i1++) {
/*  697 */           xi[i1] = x2[i1];
/*  698 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] + this._b2 * xip2[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */         } 
/*      */         
/*  701 */         yip2 = yip1;
/*  702 */         yip1 = yi;
/*  703 */         float[] xt = xip2;
/*  704 */         xip2 = xip1;
/*  705 */         xip1 = xi;
/*  706 */         xi = xt;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate1Forward(float[][] x, float[][] y) {
/*  722 */     checkArrays(x, y);
/*  723 */     int n2 = y.length;
/*  724 */     for (int i2 = 0; i2 < n2; i2++) {
/*  725 */       accumulateForward(x[i2], y[i2]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate1Reverse(float[][] x, float[][] y) {
/*  740 */     checkArrays(x, y);
/*  741 */     int n2 = y.length;
/*  742 */     for (int i2 = 0; i2 < n2; i2++) {
/*  743 */       accumulateReverse(x[i2], y[i2]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate2Forward(float[][] x, float[][] y) {
/*  758 */     checkArrays(x, y);
/*  759 */     int n2 = y.length;
/*  760 */     int n1 = (y[0]).length;
/*      */ 
/*      */     
/*  763 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  764 */       float[] yim1 = new float[n1];
/*  765 */       float[] yi = new float[n1];
/*  766 */       for (int i2 = 0; i2 < n2; i2++) {
/*  767 */         float[] xi = x[i2];
/*  768 */         float[] y2 = y[i2];
/*  769 */         for (int i1 = 0; i1 < n1; i1++) {
/*  770 */           yi[i1] = this._b0 * xi[i1] - this._a1 * yim1[i1];
/*      */           
/*  772 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  774 */         float[] yt = yim1;
/*  775 */         yim1 = yi;
/*  776 */         yi = yt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  781 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  782 */       float[] yim1 = new float[n1];
/*  783 */       float[] yi = new float[n1];
/*  784 */       float[] xim1 = new float[n1];
/*  785 */       float[] xi = new float[n1];
/*  786 */       for (int i2 = 0; i2 < n2; i2++) {
/*  787 */         float[] x2 = x[i2];
/*  788 */         float[] y2 = y[i2];
/*  789 */         for (int i1 = 0; i1 < n1; i1++) {
/*  790 */           xi[i1] = x2[i1];
/*  791 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] - this._a1 * yim1[i1];
/*      */           
/*  793 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  795 */         float[] yt = yim1;
/*  796 */         yim1 = yi;
/*  797 */         yi = yt;
/*  798 */         float[] xt = xim1;
/*  799 */         xim1 = xi;
/*  800 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  805 */     else if (this._b2 == 0.0F) {
/*  806 */       float[] yim2 = new float[n1];
/*  807 */       float[] yim1 = new float[n1];
/*  808 */       float[] yi = new float[n1];
/*  809 */       float[] xim1 = new float[n1];
/*  810 */       float[] xi = new float[n1];
/*  811 */       for (int i2 = 0; i2 < n2; i2++) {
/*  812 */         float[] x2 = x[i2];
/*  813 */         float[] y2 = y[i2];
/*  814 */         for (int i1 = 0; i1 < n1; i1++) {
/*  815 */           xi[i1] = x2[i1];
/*  816 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */           
/*  818 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  820 */         float[] yt = yim2;
/*  821 */         yim2 = yim1;
/*  822 */         yim1 = yi;
/*  823 */         yi = yt;
/*  824 */         float[] xt = xim1;
/*  825 */         xim1 = xi;
/*  826 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  831 */     else if (this._b0 == 0.0F) {
/*  832 */       float[] yim2 = new float[n1];
/*  833 */       float[] yim1 = new float[n1];
/*  834 */       float[] yi = new float[n1];
/*  835 */       float[] xim2 = new float[n1];
/*  836 */       float[] xim1 = new float[n1];
/*  837 */       float[] xi = new float[n1];
/*  838 */       for (int i2 = 0; i2 < n2; i2++) {
/*  839 */         float[] x2 = x[i2];
/*  840 */         float[] y2 = y[i2];
/*  841 */         for (int i1 = 0; i1 < n1; i1++) {
/*  842 */           xi[i1] = x2[i1];
/*  843 */           yi[i1] = this._b1 * xim1[i1] + this._b2 * xim2[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */           
/*  845 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  847 */         float[] yt = yim2;
/*  848 */         yim2 = yim1;
/*  849 */         yim1 = yi;
/*  850 */         yi = yt;
/*  851 */         float[] xt = xim2;
/*  852 */         xim2 = xim1;
/*  853 */         xim1 = xi;
/*  854 */         xi = xt;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  860 */       float[] yim2 = new float[n1];
/*  861 */       float[] yim1 = new float[n1];
/*  862 */       float[] yi = new float[n1];
/*  863 */       float[] xim2 = new float[n1];
/*  864 */       float[] xim1 = new float[n1];
/*  865 */       float[] xi = new float[n1];
/*  866 */       for (int i2 = 0; i2 < n2; i2++) {
/*  867 */         float[] x2 = x[i2];
/*  868 */         float[] y2 = y[i2];
/*  869 */         for (int i1 = 0; i1 < n1; i1++) {
/*  870 */           xi[i1] = x2[i1];
/*  871 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xim1[i1] + this._b2 * xim2[i1] - this._a1 * yim1[i1] - this._a2 * yim2[i1];
/*      */           
/*  873 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  875 */         float[] yt = yim2;
/*  876 */         yim2 = yim1;
/*  877 */         yim1 = yi;
/*  878 */         yi = yt;
/*  879 */         float[] xt = xim2;
/*  880 */         xim2 = xim1;
/*  881 */         xim1 = xi;
/*  882 */         xi = xt;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate2Reverse(float[][] x, float[][] y) {
/*  899 */     checkArrays(x, y);
/*  900 */     int n2 = y.length;
/*  901 */     int n1 = (y[0]).length;
/*      */ 
/*      */     
/*  904 */     if (this._b1 == 0.0F && this._b2 == 0.0F && this._a2 == 0.0F) {
/*  905 */       float[] yip1 = new float[n1];
/*  906 */       float[] yi = new float[n1];
/*  907 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  908 */         float[] xi = x[i2];
/*  909 */         float[] y2 = y[i2];
/*  910 */         for (int i1 = 0; i1 < n1; i1++) {
/*  911 */           yi[i1] = this._b0 * xi[i1] - this._a1 * yip1[i1];
/*      */           
/*  913 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  915 */         float[] yt = yip1;
/*  916 */         yip1 = yi;
/*  917 */         yi = yt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  922 */     else if (this._b2 == 0.0F && this._a2 == 0.0F) {
/*  923 */       float[] yip1 = new float[n1];
/*  924 */       float[] yi = new float[n1];
/*  925 */       float[] xip1 = new float[n1];
/*  926 */       float[] xi = new float[n1];
/*  927 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  928 */         float[] x2 = x[i2];
/*  929 */         float[] y2 = y[i2];
/*  930 */         for (int i1 = 0; i1 < n1; i1++) {
/*  931 */           xi[i1] = x2[i1];
/*  932 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] - this._a1 * yip1[i1];
/*      */           
/*  934 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  936 */         float[] yt = yip1;
/*  937 */         yip1 = yi;
/*  938 */         yi = yt;
/*  939 */         float[] xt = xip1;
/*  940 */         xip1 = xi;
/*  941 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  946 */     else if (this._b2 == 0.0F) {
/*  947 */       float[] yip2 = new float[n1];
/*  948 */       float[] yip1 = new float[n1];
/*  949 */       float[] yi = new float[n1];
/*  950 */       float[] xip1 = new float[n1];
/*  951 */       float[] xi = new float[n1];
/*  952 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  953 */         float[] x2 = x[i2];
/*  954 */         float[] y2 = y[i2];
/*  955 */         for (int i1 = 0; i1 < n1; i1++) {
/*  956 */           xi[i1] = x2[i1];
/*  957 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */           
/*  959 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  961 */         float[] yt = yip2;
/*  962 */         yip2 = yip1;
/*  963 */         yip1 = yi;
/*  964 */         yi = yt;
/*  965 */         float[] xt = xip1;
/*  966 */         xip1 = xi;
/*  967 */         xi = xt;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  972 */     else if (this._b0 == 0.0F) {
/*  973 */       float[] yip2 = new float[n1];
/*  974 */       float[] yip1 = new float[n1];
/*  975 */       float[] yi = new float[n1];
/*  976 */       float[] xip2 = new float[n1];
/*  977 */       float[] xip1 = new float[n1];
/*  978 */       float[] xi = new float[n1];
/*  979 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  980 */         float[] x2 = x[i2];
/*  981 */         float[] y2 = y[i2];
/*  982 */         for (int i1 = 0; i1 < n1; i1++) {
/*  983 */           xi[i1] = x2[i1];
/*  984 */           yi[i1] = this._b1 * xip1[i1] + this._b2 * xip2[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */           
/*  986 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/*  988 */         float[] yt = yip2;
/*  989 */         yip2 = yip1;
/*  990 */         yip1 = yi;
/*  991 */         yi = yt;
/*  992 */         float[] xt = xip2;
/*  993 */         xip2 = xip1;
/*  994 */         xip1 = xi;
/*  995 */         xi = xt;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1001 */       float[] yip2 = new float[n1];
/* 1002 */       float[] yip1 = new float[n1];
/* 1003 */       float[] yi = new float[n1];
/* 1004 */       float[] xip2 = new float[n1];
/* 1005 */       float[] xip1 = new float[n1];
/* 1006 */       float[] xi = new float[n1];
/* 1007 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/* 1008 */         float[] x2 = x[i2];
/* 1009 */         float[] y2 = y[i2];
/* 1010 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1011 */           xi[i1] = x2[i1];
/* 1012 */           yi[i1] = this._b0 * xi[i1] + this._b1 * xip1[i1] + this._b2 * xip2[i1] - this._a1 * yip1[i1] - this._a2 * yip2[i1];
/*      */           
/* 1014 */           y2[i1] = y2[i1] + yi[i1];
/*      */         } 
/* 1016 */         float[] yt = yip2;
/* 1017 */         yip2 = yip1;
/* 1018 */         yip1 = yi;
/* 1019 */         yi = yt;
/* 1020 */         float[] xt = xip2;
/* 1021 */         xip2 = xip1;
/* 1022 */         xip1 = xi;
/* 1023 */         xi = xt;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1Forward(float[][][] x, float[][][] y) {
/* 1040 */     checkArrays(x, y);
/* 1041 */     int n3 = y.length;
/* 1042 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1043 */       apply1Forward(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1Reverse(float[][][] x, float[][][] y) {
/* 1056 */     checkArrays(x, y);
/* 1057 */     int n3 = y.length;
/* 1058 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1059 */       apply1Reverse(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2Forward(float[][][] x, float[][][] y) {
/* 1072 */     checkArrays(x, y);
/* 1073 */     int n3 = y.length;
/* 1074 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1075 */       apply2Forward(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2Reverse(float[][][] x, float[][][] y) {
/* 1088 */     checkArrays(x, y);
/* 1089 */     int n3 = y.length;
/* 1090 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1091 */       apply2Reverse(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply3Forward(float[][][] x, float[][][] y) {
/* 1104 */     checkArrays(x, y);
/* 1105 */     int n3 = y.length;
/* 1106 */     int n2 = (y[0]).length;
/* 1107 */     int n1 = (y[0][0]).length;
/* 1108 */     float[][] xy = new float[n3][n1];
/* 1109 */     for (int i2 = 0; i2 < n2; i2++) {
/* 1110 */       get2(i2, x, xy);
/* 1111 */       apply2Forward(xy, xy);
/* 1112 */       set2(i2, xy, y);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply3Reverse(float[][][] x, float[][][] y) {
/* 1125 */     checkArrays(x, y);
/* 1126 */     int n3 = y.length;
/* 1127 */     int n2 = (y[0]).length;
/* 1128 */     int n1 = (y[0][0]).length;
/* 1129 */     float[][] xy = new float[n3][n1];
/* 1130 */     for (int i2 = 0; i2 < n2; i2++) {
/* 1131 */       get2(i2, x, xy);
/* 1132 */       apply2Reverse(xy, xy);
/* 1133 */       set2(i2, xy, y);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate1Forward(float[][][] x, float[][][] y) {
/* 1148 */     checkArrays(x, y);
/* 1149 */     int n3 = y.length;
/* 1150 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1151 */       accumulate1Forward(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate1Reverse(float[][][] x, float[][][] y) {
/* 1166 */     checkArrays(x, y);
/* 1167 */     int n3 = y.length;
/* 1168 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1169 */       accumulate1Reverse(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate2Forward(float[][][] x, float[][][] y) {
/* 1184 */     checkArrays(x, y);
/* 1185 */     int n3 = y.length;
/* 1186 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1187 */       accumulate2Forward(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate2Reverse(float[][][] x, float[][][] y) {
/* 1202 */     checkArrays(x, y);
/* 1203 */     int n3 = y.length;
/* 1204 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1205 */       accumulate2Reverse(x[i3], y[i3]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate3Forward(float[][][] x, float[][][] y) {
/* 1220 */     checkArrays(x, y);
/* 1221 */     int n3 = y.length;
/* 1222 */     int n2 = (y[0]).length;
/* 1223 */     int n1 = (y[0][0]).length;
/* 1224 */     float[][] xy = new float[n3][n1];
/* 1225 */     for (int i2 = 0; i2 < n2; i2++) {
/* 1226 */       get2(i2, x, xy);
/* 1227 */       apply2Forward(xy, xy);
/* 1228 */       acc2(i2, xy, y);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void accumulate3Reverse(float[][][] x, float[][][] y) {
/* 1244 */     checkArrays(x, y);
/* 1245 */     int n3 = y.length;
/* 1246 */     int n2 = (y[0]).length;
/* 1247 */     int n1 = (y[0][0]).length;
/* 1248 */     float[][] xy = new float[n3][n1];
/* 1249 */     for (int i2 = 0; i2 < n2; i2++) {
/* 1250 */       get2(i2, x, xy);
/* 1251 */       apply2Reverse(xy, xy);
/* 1252 */       acc2(i2, xy, y);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkArrays(float[] x, float[] y) {
/* 1262 */     Check.argument((x.length == y.length), "x.length==y.length");
/*      */   }
/*      */   
/*      */   private static void checkArrays(float[][] x, float[][] y) {
/* 1266 */     Check.argument((x.length == y.length), "x.length==y.length");
/* 1267 */     Check.argument(((x[0]).length == (y[0]).length), "x[0].length==y[0].length");
/* 1268 */     Check.argument(Array.isRegular(x), "x is regular");
/* 1269 */     Check.argument(Array.isRegular(y), "y is regular");
/*      */   }
/*      */   
/*      */   private static void checkArrays(float[][][] x, float[][][] y) {
/* 1273 */     Check.argument((x.length == y.length), "x.length==y.length");
/* 1274 */     Check.argument(((x[0]).length == (y[0]).length), "x[0].length==y[0].length");
/* 1275 */     Check.argument(((x[0][0]).length == (y[0][0]).length), "x[0][0].length==y[0][0].length");
/*      */     
/* 1277 */     Check.argument(Array.isRegular(x), "x is regular");
/* 1278 */     Check.argument(Array.isRegular(y), "y is regular");
/*      */   }
/*      */   
/*      */   private void get2(int i2, float[][][] x, float[][] x2) {
/* 1282 */     int n3 = x2.length;
/* 1283 */     int n1 = (x2[0]).length;
/* 1284 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1285 */       float[] x32 = x[i3][i2];
/* 1286 */       float[] x23 = x2[i3];
/* 1287 */       for (int i1 = 0; i1 < n1; i1++) {
/* 1288 */         x23[i1] = x32[i1];
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void set2(int i2, float[][] x2, float[][][] x) {
/* 1294 */     int n3 = x2.length;
/* 1295 */     int n1 = (x2[0]).length;
/* 1296 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1297 */       float[] x32 = x[i3][i2];
/* 1298 */       float[] x23 = x2[i3];
/* 1299 */       for (int i1 = 0; i1 < n1; i1++) {
/* 1300 */         x32[i1] = x23[i1];
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void acc2(int i2, float[][] x2, float[][][] x) {
/* 1306 */     int n3 = x2.length;
/* 1307 */     int n1 = (x2[0]).length;
/* 1308 */     for (int i3 = 0; i3 < n3; i3++) {
/* 1309 */       float[] x32 = x[i3][i2];
/* 1310 */       float[] x23 = x2[i3];
/* 1311 */       for (int i1 = 0; i1 < n1; i1++)
/* 1312 */         x32[i1] = x32[i1] + x23[i1]; 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Recursive2ndOrderFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */