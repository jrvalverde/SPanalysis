/*      */ package edu.mines.jtk.mesh;
/*      */ 
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ import java.io.IOException;
/*      */ import java.io.InvalidClassException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ public class TriMesh implements Serializable {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final int NODE_MARK_MAX = 2147483646;
/*      */   private static final int TRI_MARK_MAX = 2147483646;
/*      */   private long _version;
/*      */   private int _nnode;
/*      */   private int _ntri;
/*      */   private Node _nroot;
/*      */   private Tri _troot;
/*      */   private HashSet<Node> _sampledNodes;
/*      */   private int _triMarkRed;
/*      */   private int _triMarkBlue;
/*      */   private int _nodeMarkRed;
/*      */   private int _nodeMarkBlue;
/*      */   private EdgeSet _edgeSet;
/*      */   private NodeSet _nodeSet;
/*      */   private NodeList _nodeList;
/*      */   private Node _nmin;
/*      */   private double _dmin;
/*      */   private TriList _deadTris;
/*      */   private int _nnodeListeners;
/*      */   private int _ntriListeners;
/*      */   private EventListenerList _listeners;
/*      */   private boolean _outerEnabled;
/*      */   private double _xminOuter;
/*      */   private double _yminOuter;
/*      */   private double _xmaxOuter;
/*      */   private double _ymaxOuter;
/*      */   private int _nnodeValues;
/*      */   private int _lnodeValues;
/*      */   private Map<String, NodePropertyMap> _nodePropertyMaps;
/*      */   static final boolean DEBUG = false;
/*      */   static final boolean TRACE = false;
/*      */   
/*      */   public static class Node implements Serializable {
/*      */     private static final long serialVersionUID = 1L;
/*      */     public int index;
/*      */     public Object data;
/*      */     private transient double _x;
/*      */     private transient double _y;
/*      */     private transient Node _prev;
/*      */     private transient Node _next;
/*      */     private transient int _mark;
/*      */     private transient TriMesh.Tri _tri;
/*      */     private transient int _hash;
/*      */     private transient Object[] _values;
/*      */     
/*      */     public Node(float x, float y) {
/*   69 */       this._prev = null;
/*   70 */       this._next = null;
/*   71 */       this._mark = 0;
/*   72 */       this._tri = null;
/*   73 */       this._hash = System.identityHashCode(this);
/*   74 */       setPosition(x, y);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float x() {
/*   82 */       return (float)this._x;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float y() {
/*   90 */       return (float)this._y;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Tri tri() {
/*   98 */       return this._tri;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  102 */       return "(" + x() + "," + y() + ")";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static double perturb(float x, float p) {
/*  118 */       int m = Integer.MAX_VALUE;
/*  119 */       int i = Float.floatToIntBits(p);
/*  120 */       int j = 0;
/*  121 */       for (int k = 0; k < 32; k++, i >>= 1, j <<= 1) {
/*  122 */         j |= i & 0x1;
/*      */       }
/*  124 */       double xp = (x != 0.0F) ? x : 1.4012984643248171E-46D;
/*  125 */       xp *= 1.0D + j / 2.147483647E9D * 0.1D * 1.1920928955078125E-7D;
/*  126 */       assert (float)xp == x;
/*  127 */       return xp;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setPosition(float x, float y) {
/*  134 */       assert this._tri == null;
/*  135 */       this._x = perturb(x, y);
/*  136 */       this._y = perturb(y, x);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Tri
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int index;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object data;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int INNER_BIT = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int OUTER_BIT = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeA() {
/*  175 */       return this._n0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeB() {
/*  183 */       return this._n1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeC() {
/*  191 */       return this._n2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tri triA() {
/*  199 */       return this._t0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tri triB() {
/*  207 */       return this._t1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tri triC() {
/*  215 */       return this._t2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeNearest(float x, float y) {
/*  226 */       double d0 = TriMesh.distanceSquared(this._n0, x, y);
/*  227 */       double d1 = TriMesh.distanceSquared(this._n1, x, y);
/*  228 */       double d2 = TriMesh.distanceSquared(this._n2, x, y);
/*  229 */       double dmin = d0;
/*  230 */       TriMesh.Node nmin = this._n0;
/*  231 */       if (d1 < dmin) {
/*  232 */         dmin = d1;
/*  233 */         nmin = this._n1;
/*      */       } 
/*  235 */       if (d2 < dmin) {
/*  236 */         dmin = d2;
/*  237 */         nmin = this._n2;
/*      */       } 
/*  239 */       return nmin;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tri triNabor(TriMesh.Node node) {
/*  246 */       if (node == this._n0) return this._t0; 
/*  247 */       if (node == this._n1) return this._t1; 
/*  248 */       if (node == this._n2) return this._t2; 
/*  249 */       Check.argument(false, "node is referenced by tri");
/*  250 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeNabor(Tri triNabor) {
/*  257 */       if (triNabor._t0 == this) return triNabor._n0; 
/*  258 */       if (triNabor._t1 == this) return triNabor._n1; 
/*  259 */       if (triNabor._t2 == this) return triNabor._n2; 
/*  260 */       Check.argument(false, "triNabor is a nabor of tri");
/*  261 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double centerCircle(double[] c) {
/*  270 */       double x0 = this._n0._x;
/*  271 */       double y0 = this._n0._y;
/*  272 */       double x1 = this._n1._x;
/*  273 */       double y1 = this._n1._y;
/*  274 */       double x2 = this._n2._x;
/*  275 */       double y2 = this._n2._y;
/*  276 */       Geometry.centerCircle(x0, y0, x1, y1, x2, y2, c);
/*  277 */       double xc = c[0];
/*  278 */       double yc = c[1];
/*  279 */       double dx = xc - x2;
/*  280 */       double dy = yc - y2;
/*  281 */       return dx * dx + dy * dy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] centerCircle() {
/*  289 */       double[] c = new double[2];
/*  290 */       centerCircle(c);
/*  291 */       return c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double quality() {
/*  302 */       if (this._quality < 0.0D)
/*  303 */         this._quality = quality(this._n0, this._n1, this._n2); 
/*  304 */       return this._quality;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriMesh.Node node) {
/*  313 */       return (node == this._n0 || node == this._n1 || node == this._n2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriMesh.Node na, TriMesh.Node nb) {
/*  323 */       if (na == this._n0)
/*  324 */         return (nb == this._n1 || nb == this._n2); 
/*  325 */       if (na == this._n1)
/*  326 */         return (nb == this._n0 || nb == this._n2); 
/*  327 */       if (na == this._n2) {
/*  328 */         return (nb == this._n0 || nb == this._n1);
/*      */       }
/*  330 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriMesh.Node na, TriMesh.Node nb, TriMesh.Node nc) {
/*  342 */       if (na == this._n0) {
/*  343 */         if (nb == this._n1)
/*  344 */           return (nc == this._n2); 
/*  345 */         if (nb == this._n2) {
/*  346 */           return (nc == this._n1);
/*      */         }
/*  348 */         return false;
/*      */       } 
/*  350 */       if (na == this._n1) {
/*  351 */         if (nb == this._n0)
/*  352 */           return (nc == this._n2); 
/*  353 */         if (nb == this._n2) {
/*  354 */           return (nc == this._n0);
/*      */         }
/*  356 */         return false;
/*      */       } 
/*  358 */       if (na == this._n2) {
/*  359 */         if (nb == this._n0)
/*  360 */           return (nc == this._n1); 
/*  361 */         if (nb == this._n1) {
/*  362 */           return (nc == this._n0);
/*      */         }
/*  364 */         return false;
/*      */       } 
/*      */       
/*  367 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  386 */     private static double QUALITY_FACTOR = 2.0D / MathPlus.sqrt(3.0D);
/*      */ 
/*      */     
/*      */     private transient TriMesh.Node _n0;
/*      */ 
/*      */     
/*      */     private transient TriMesh.Node _n1;
/*      */ 
/*      */     
/*      */     private transient TriMesh.Node _n2;
/*      */ 
/*      */     
/*      */     private transient Tri _t0;
/*      */ 
/*      */     
/*      */     private transient Tri _t1;
/*      */ 
/*      */     
/*      */     private transient Tri _t2;
/*      */ 
/*      */     
/*      */     private transient int _mark;
/*      */     
/*      */     private transient int _bits;
/*      */     
/*  411 */     private transient double _quality = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tri(TriMesh.Node n0, TriMesh.Node n1, TriMesh.Node n2) {
/*  423 */       init(n0, n1, n2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void init(TriMesh.Node n0, TriMesh.Node n1, TriMesh.Node n2) {
/*  437 */       this._n0 = n0;
/*  438 */       this._n1 = n1;
/*  439 */       this._n2 = n2;
/*  440 */       this._n0._tri = this;
/*  441 */       this._n1._tri = this;
/*  442 */       this._n2._tri = this;
/*  443 */       this._t0 = null;
/*  444 */       this._t1 = null;
/*  445 */       this._t2 = null;
/*  446 */       this._mark = 0;
/*  447 */       this._bits = 0;
/*  448 */       this._quality = -1.0D;
/*      */     }
/*      */     
/*      */     private final void setInner() {
/*  452 */       this._bits |= 0x1;
/*      */     }
/*      */     
/*      */     private final void clearInner() {
/*  456 */       this._bits &= 0xFFFFFFFE;
/*      */     }
/*      */     
/*      */     private final boolean isInner() {
/*  460 */       return ((this._bits & 0x1) != 0);
/*      */     }
/*      */     
/*      */     private final void setOuter() {
/*  464 */       this._bits |= 0x2;
/*      */     }
/*      */     
/*      */     private final void clearOuter() {
/*  468 */       this._bits &= 0xFFFFFFFD;
/*      */     }
/*      */     
/*      */     private final boolean isOuter() {
/*  472 */       return ((this._bits & 0x2) != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static double quality(TriMesh.Node na, TriMesh.Node nb, TriMesh.Node nc) {
/*  501 */       double xa = na._x;
/*  502 */       double ya = na._y;
/*  503 */       double xb = nb._x;
/*  504 */       double yb = nb._y;
/*  505 */       double xc = nc._x;
/*  506 */       double yc = nc._y;
/*  507 */       double xab = xa - xb;
/*  508 */       double yab = ya - yb;
/*  509 */       double xac = xa - xc;
/*  510 */       double yac = ya - yc;
/*  511 */       double xbc = xb - xc;
/*  512 */       double ybc = yb - yc;
/*  513 */       double det = xac * ybc - yac * xbc;
/*  514 */       double dab = xab * xab + yab * yab;
/*  515 */       double dac = xac * xac + yac * yac;
/*  516 */       double dbc = xbc * xbc + ybc * ybc;
/*  517 */       double dmx = dab;
/*  518 */       if (dac > dmx) dmx = dac; 
/*  519 */       if (dbc > dmx) dmx = dbc; 
/*  520 */       double quality = QUALITY_FACTOR * det / dmx;
/*      */       
/*  522 */       if (quality < 0.0D) quality = -quality; 
/*  523 */       if (quality > 1.0D) quality = 1.0D; 
/*  524 */       return (float)quality;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Edge
/*      */   {
/*      */     private TriMesh.Node _a;
/*      */ 
/*      */ 
/*      */     
/*      */     private TriMesh.Node _b;
/*      */ 
/*      */ 
/*      */     
/*      */     private TriMesh.Tri _triLeft;
/*      */ 
/*      */ 
/*      */     
/*      */     private TriMesh.Tri _triRight;
/*      */ 
/*      */ 
/*      */     
/*      */     private TriMesh.Node _nodeLeft;
/*      */ 
/*      */ 
/*      */     
/*      */     private TriMesh.Node _nodeRight;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Edge(TriMesh.Node a, TriMesh.Node b) {
/*  560 */       this(a, b, (TriMesh.Tri)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Edge(TriMesh.Node a, TriMesh.Node b, TriMesh.Tri abc) {
/*  572 */       TriMesh.Node c = (abc != null) ? TriMesh.otherNode(abc, a, b) : null;
/*  573 */       Check.argument((abc == null || c != null), "tri references nodes");
/*  574 */       this._a = a;
/*  575 */       this._b = b;
/*  576 */       if (c != null) {
/*  577 */         if (TriMesh.nodesInOrder(abc, a, b, c)) {
/*  578 */           this._triLeft = abc;
/*  579 */           this._nodeLeft = c;
/*  580 */           this._triRight = abc.triNabor(c);
/*  581 */           this._nodeRight = (this._triRight != null) ? abc.nodeNabor(this._triRight) : null;
/*      */         } else {
/*  583 */           this._triRight = abc;
/*  584 */           this._nodeRight = c;
/*  585 */           this._triLeft = abc.triNabor(c);
/*  586 */           this._nodeLeft = (this._triLeft != null) ? abc.nodeNabor(this._triLeft) : null;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeA() {
/*  596 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node nodeB() {
/*  604 */       return this._b;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Tri triLeft() {
/*  612 */       return this._triLeft;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Tri triRight() {
/*  620 */       return this._triRight;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Node nodeLeft() {
/*  628 */       return this._nodeLeft;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Node nodeRight() {
/*  636 */       return this._nodeRight;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Edge mate() {
/*  645 */       return new Edge(this._b, this._a, this._triRight, this._nodeRight, this._triLeft, this._nodeLeft);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVisibleFromPoint(double x, double y) {
/*  657 */       return (Geometry.leftOfLine(this._a._x, this._a._y, this._b._x, this._b._y, x, y) < 0.0D);
/*      */     }
/*      */     
/*      */     public boolean equals(Object object) {
/*  661 */       if (object == this)
/*  662 */         return true; 
/*  663 */       if (object != null && object.getClass() == getClass()) {
/*  664 */         Edge edge = (Edge)object;
/*  665 */         return (this._a == edge._a && this._b == edge._b);
/*      */       } 
/*  667 */       return false;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  671 */       return this._a._hash ^ this._b._hash;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Edge(TriMesh.Node a, TriMesh.Node b, TriMesh.Tri triLeft, TriMesh.Node nodeLeft, TriMesh.Tri triRight, TriMesh.Node nodeRight) {
/*  683 */       this._a = a;
/*  684 */       this._b = b;
/*  685 */       this._triLeft = triLeft;
/*  686 */       this._nodeLeft = nodeLeft;
/*  687 */       this._triRight = triRight;
/*  688 */       this._nodeRight = nodeRight;
/*      */     }
/*      */     
/*      */     private Edge(TriMesh.Tri triLeft, TriMesh.Node nodeLeft) {
/*  692 */       initLeft(triLeft, nodeLeft);
/*  693 */       this._triLeft = triLeft;
/*  694 */       this._nodeLeft = nodeLeft;
/*  695 */       this._triRight = triLeft.triNabor(nodeLeft);
/*  696 */       this._nodeRight = (this._triRight != null) ? this._triLeft.nodeNabor(this._triRight) : null;
/*      */     }
/*      */     
/*      */     private Edge(TriMesh.Tri triLeft, TriMesh.Node nodeLeft, TriMesh.Tri triRight, TriMesh.Node nodeRight) {
/*  700 */       if (triLeft != null) {
/*  701 */         initLeft(triLeft, nodeLeft);
/*  702 */       } else if (triRight != null) {
/*  703 */         initRight(triRight, nodeRight);
/*      */       } else {
/*  705 */         assert false : "either triLeft or triRight is not null";
/*      */       } 
/*  707 */       this._triLeft = triLeft;
/*  708 */       this._triRight = triRight;
/*  709 */       this._nodeLeft = nodeLeft;
/*  710 */       this._nodeRight = nodeRight;
/*      */     }
/*      */     
/*      */     private void initLeft(TriMesh.Tri triLeft, TriMesh.Node nodeLeft) {
/*  714 */       if (nodeLeft == triLeft._n0) {
/*  715 */         this._a = triLeft._n1;
/*  716 */         this._b = triLeft._n2;
/*  717 */       } else if (nodeLeft == triLeft._n1) {
/*  718 */         this._a = triLeft._n2;
/*  719 */         this._b = triLeft._n0;
/*  720 */       } else if (nodeLeft == triLeft._n2) {
/*  721 */         this._a = triLeft._n0;
/*  722 */         this._b = triLeft._n1;
/*      */       } else {
/*  724 */         assert false : "nodeLeft referenced by triLeft";
/*      */       } 
/*      */     }
/*      */     
/*      */     private void initRight(TriMesh.Tri triRight, TriMesh.Node nodeRight) {
/*  729 */       if (nodeRight == triRight._n0) {
/*  730 */         this._a = triRight._n2;
/*  731 */         this._b = triRight._n1;
/*  732 */       } else if (nodeRight == triRight._n1) {
/*  733 */         this._a = triRight._n0;
/*  734 */         this._b = triRight._n2;
/*  735 */       } else if (nodeRight == triRight._n2) {
/*  736 */         this._a = triRight._n1;
/*  737 */         this._b = triRight._n0;
/*      */       } else {
/*  739 */         assert false : "nodeRight referenced by triRight";
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NodeList
/*      */   {
/*      */     public final void add(TriMesh.Node node) {
/*  768 */       if (this._n == this._a.length) {
/*  769 */         TriMesh.Node[] t = new TriMesh.Node[this._a.length * 2];
/*  770 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  771 */         this._a = t;
/*      */       } 
/*  773 */       this._a[this._n++] = node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node remove(int index) {
/*  782 */       TriMesh.Node node = this._a[index];
/*  783 */       this._n--;
/*  784 */       if (this._n > index)
/*  785 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/*  786 */       return node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node[] trim() {
/*  794 */       if (this._n < this._a.length) {
/*  795 */         TriMesh.Node[] t = new TriMesh.Node[this._n];
/*  796 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  797 */         this._a = t;
/*      */       } 
/*  799 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/*  806 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nnode() {
/*  814 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node[] nodes() {
/*  822 */       return this._a;
/*      */     }
/*  824 */     private int _n = 0;
/*  825 */     private TriMesh.Node[] _a = new TriMesh.Node[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TriList
/*      */   {
/*      */     public final void add(TriMesh.Tri tri) {
/*  838 */       if (this._n == this._a.length) {
/*  839 */         TriMesh.Tri[] t = new TriMesh.Tri[this._a.length * 2];
/*  840 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  841 */         this._a = t;
/*      */       } 
/*  843 */       this._a[this._n++] = tri;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Tri remove(int index) {
/*  852 */       TriMesh.Tri tri = this._a[index];
/*  853 */       this._n--;
/*  854 */       if (this._n > index)
/*  855 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/*  856 */       return tri;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Tri[] trim() {
/*  864 */       if (this._n < this._a.length) {
/*  865 */         TriMesh.Tri[] t = new TriMesh.Tri[this._n];
/*  866 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  867 */         this._a = t;
/*      */       } 
/*  869 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/*  876 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int ntri() {
/*  884 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Tri[] tris() {
/*  892 */       return this._a;
/*      */     }
/*  894 */     private int _n = 0;
/*  895 */     private TriMesh.Tri[] _a = new TriMesh.Tri[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EdgeList
/*      */   {
/*      */     public final void add(TriMesh.Edge edge) {
/*  908 */       if (this._n == this._a.length) {
/*  909 */         TriMesh.Edge[] t = new TriMesh.Edge[this._a.length * 2];
/*  910 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  911 */         this._a = t;
/*      */       } 
/*  913 */       this._a[this._n++] = edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Edge remove(int index) {
/*  922 */       TriMesh.Edge edge = this._a[index];
/*  923 */       this._n--;
/*  924 */       if (this._n > index)
/*  925 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/*  926 */       return edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Edge[] trim() {
/*  934 */       if (this._n < this._a.length) {
/*  935 */         TriMesh.Edge[] t = new TriMesh.Edge[this._n];
/*  936 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  937 */         this._a = t;
/*      */       } 
/*  939 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/*  946 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nedge() {
/*  954 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Edge[] edges() {
/*  962 */       return this._a;
/*      */     }
/*  964 */     private int _n = 0;
/*  965 */     private TriMesh.Edge[] _a = new TriMesh.Edge[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NodeStepList
/*      */   {
/*      */     public final void add(TriMesh.Node node, int step) {
/*  980 */       if (this._n == this._a.length) {
/*  981 */         TriMesh.Node[] s = new TriMesh.Node[this._a.length * 2];
/*  982 */         int[] t = new int[this._a.length * 2];
/*  983 */         System.arraycopy(this._a, 0, s, 0, this._n);
/*  984 */         System.arraycopy(this._b, 0, t, 0, this._n);
/*  985 */         this._a = s;
/*  986 */         this._b = t;
/*      */       } 
/*  988 */       this._a[this._n] = node;
/*  989 */       this._b[this._n] = step;
/*  990 */       this._n++;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void trim() {
/*  997 */       if (this._n < this._a.length) {
/*  998 */         TriMesh.Node[] s = new TriMesh.Node[this._n];
/*  999 */         int[] t = new int[this._n];
/* 1000 */         System.arraycopy(this._a, 0, s, 0, this._n);
/* 1001 */         System.arraycopy(this._b, 0, t, 0, this._n);
/* 1002 */         this._a = s;
/* 1003 */         this._b = t;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1011 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nnode() {
/* 1019 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriMesh.Node[] nodes() {
/* 1027 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int[] steps() {
/* 1035 */       return this._b;
/*      */     }
/* 1037 */     private int _n = 0;
/* 1038 */     private TriMesh.Node[] _a = new TriMesh.Node[64];
/* 1039 */     private int[] _b = new int[64];
/*      */   }
/*      */ 
/*      */   
/*      */   public static class PointLocation
/*      */   {
/*      */     private TriMesh.Node _node;
/*      */     
/*      */     private TriMesh.Edge _edge;
/*      */     
/*      */     private TriMesh.Tri _tri;
/*      */     private boolean _inside;
/*      */     
/*      */     public boolean isOnNode() {
/* 1053 */       return (this._node != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOnEdge() {
/* 1061 */       return (this._edge != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInside() {
/* 1069 */       return this._inside;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOutside() {
/* 1077 */       return !this._inside;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Node node() {
/* 1085 */       return this._node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Edge edge() {
/* 1093 */       return this._edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriMesh.Tri tri() {
/* 1104 */       return this._tri;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private PointLocation(TriMesh.Tri tri) {
/* 1113 */       this._tri = tri;
/* 1114 */       this._inside = true;
/*      */     }
/*      */     private PointLocation(TriMesh.Tri tri, boolean inside) {
/* 1117 */       this._tri = tri;
/* 1118 */       this._inside = inside;
/*      */     }
/*      */     private PointLocation(TriMesh.Node node) {
/* 1121 */       this._tri = node._tri;
/* 1122 */       this._node = node;
/* 1123 */       this._inside = true;
/*      */     }
/*      */     private PointLocation(TriMesh.Edge edge) {
/* 1126 */       this._tri = edge._triLeft;
/* 1127 */       this._edge = edge;
/* 1128 */       this._inside = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodePropertyMap getNodePropertyMap(String name) {
/* 1162 */     NodePropertyMap map = this._nodePropertyMaps.get(name);
/* 1163 */     if (map == null) {
/* 1164 */       if (this._nnodeValues == this._lnodeValues) {
/* 1165 */         if (this._lnodeValues == 0) {
/* 1166 */           this._lnodeValues = 4;
/*      */         } else {
/* 1168 */           this._lnodeValues *= 2;
/*      */         } 
/* 1170 */         NodeIterator ni = getNodes();
/* 1171 */         while (ni.hasNext()) {
/* 1172 */           Node node = ni.next();
/* 1173 */           Object[] valuesOld = node._values;
/* 1174 */           Object[] valuesNew = new Object[this._lnodeValues];
/* 1175 */           for (int i = 0; i < this._nnodeValues; i++)
/* 1176 */             valuesNew[i] = valuesOld[i]; 
/* 1177 */           node._values = valuesNew;
/*      */         } 
/*      */       } 
/* 1180 */       int index = this._nnodeValues++;
/* 1181 */       map = new NodePropertyMapInternal(index);
/* 1182 */       this._nodePropertyMaps.put(name, map);
/*      */     } 
/* 1184 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean hasNodePropertyMap(String name) {
/* 1193 */     return this._nodePropertyMaps.containsKey(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String[] getNodePropertyMapNames() {
/* 1202 */     Set<String> nameSet = this._nodePropertyMaps.keySet();
/* 1203 */     String[] names = new String[nameSet.size()];
/* 1204 */     return nameSet.<String>toArray(names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addNodeListener(NodeListener nl) {
/* 1296 */     this._listeners.add(NodeListener.class, nl);
/* 1297 */     this._nnodeListeners++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeNodeListener(NodeListener nl) {
/* 1305 */     this._listeners.remove(NodeListener.class, nl);
/* 1306 */     this._nnodeListeners--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addTriListener(TriListener tl) {
/* 1314 */     this._listeners.add(TriListener.class, tl);
/* 1315 */     this._ntriListeners++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeTriListener(TriListener tl) {
/* 1323 */     this._listeners.remove(TriListener.class, tl);
/* 1324 */     this._ntriListeners--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TriMesh() {
/* 1331 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countNodes() {
/* 1339 */     return this._nnode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countTris() {
/* 1347 */     return this._ntri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getVersion() {
/* 1359 */     return this._version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean addNode(Node node) {
/* 1371 */     PointLocation pl = locatePoint(node._x, node._y);
/*      */ 
/*      */     
/* 1374 */     if (pl.isOnNode()) {
/* 1375 */       return false;
/*      */     }
/*      */     
/* 1378 */     fireNodeWillBeAdded(node);
/*      */ 
/*      */     
/* 1381 */     if (this._nroot == null) {
/* 1382 */       this._nroot = node;
/* 1383 */       this._nroot._prev = this._nroot._next = this._nroot;
/*      */     } else {
/* 1385 */       node._next = this._nroot;
/* 1386 */       node._prev = this._nroot._prev;
/* 1387 */       this._nroot._prev._next = node;
/* 1388 */       this._nroot._prev = node;
/* 1389 */       this._nroot = node;
/*      */     } 
/* 1391 */     this._nnode++;
/*      */ 
/*      */     
/* 1394 */     updatePropertyValues(node);
/*      */ 
/*      */ 
/*      */     
/* 1398 */     double factor = 0.45D * this._sampledNodes.size();
/* 1399 */     if (factor * factor * factor < this._nnode) {
/* 1400 */       this._sampledNodes.add(node);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1405 */     if (pl.isOutside() && this._nnode <= 3) {
/* 1406 */       if (this._nnode == 3) {
/* 1407 */         createFirstTri();
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1415 */       clearTriMarks();
/* 1416 */       this._edgeSet.clear();
/* 1417 */       if (pl.isInside()) {
/* 1418 */         getDelaunayEdgesInside(node, pl.tri());
/*      */       } else {
/* 1420 */         getDelaunayEdgesOutside(node, pl.tri());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1426 */       this._nodeSet.clear(); boolean more;
/* 1427 */       for (more = this._edgeSet.first(); more; more = this._edgeSet.next()) {
/* 1428 */         Node a = this._edgeSet.a;
/* 1429 */         Node b = this._edgeSet.b;
/* 1430 */         Node c = this._edgeSet.c;
/* 1431 */         Tri abc = this._edgeSet.abc;
/* 1432 */         Tri nba = makeTri(node, b, a);
/* 1433 */         linkTris(nba, node, abc, c);
/* 1434 */         if (!this._nodeSet.add(a, b, nba))
/* 1435 */           linkTris(this._nodeSet.nba, this._nodeSet.b, nba, b); 
/* 1436 */         if (!this._nodeSet.add(b, a, nba)) {
/* 1437 */           linkTris(this._nodeSet.nba, this._nodeSet.b, nba, a);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1445 */     fireNodeAdded(node);
/*      */     
/* 1447 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean removeNode(Node node) {
/* 1458 */     Tri tri = node._tri;
/*      */ 
/*      */     
/* 1461 */     if (tri == null) {
/* 1462 */       return false;
/*      */     }
/*      */     
/* 1465 */     fireNodeWillBeRemoved(node);
/*      */ 
/*      */     
/* 1468 */     this._nroot = node._next;
/* 1469 */     this._nmin = node._next;
/* 1470 */     if (this._nroot == node) {
/* 1471 */       this._nroot = null;
/* 1472 */       this._nmin = null;
/*      */     } 
/* 1474 */     node._prev._next = node._next;
/* 1475 */     node._next._prev = node._prev;
/* 1476 */     node._prev = null;
/* 1477 */     node._next = null;
/* 1478 */     node._tri = null;
/* 1479 */     this._sampledNodes.remove(node);
/* 1480 */     this._nnode--;
/*      */ 
/*      */     
/* 1483 */     if (this._nnode < 3) {
/* 1484 */       if (this._nnode == 2) {
/* 1485 */         Node n0 = this._nroot;
/* 1486 */         Node n1 = n0._next;
/* 1487 */         n0._tri = null;
/* 1488 */         n1._tri = null;
/* 1489 */         killTri(this._troot);
/* 1490 */         this._troot = null;
/*      */       } 
/* 1492 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1497 */     this._edgeSet.clear();
/* 1498 */     this._nodeList.clear();
/* 1499 */     clearTriMarks();
/* 1500 */     clearNodeMarks();
/* 1501 */     getDelaunayEdgesOpposite(node, tri);
/* 1502 */     int nnode = this._nodeList.nnode();
/* 1503 */     Node[] nodes = this._nodeList.nodes();
/*      */     
/*      */     boolean more;
/*      */     
/* 1507 */     for (more = this._edgeSet.remove(); more; more = this._edgeSet.remove()) {
/*      */ 
/*      */       
/* 1510 */       Node a = this._edgeSet.a;
/* 1511 */       Node b = this._edgeSet.b;
/* 1512 */       Node c = this._edgeSet.c;
/* 1513 */       Tri abc = this._edgeSet.abc;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1518 */       Node n = null;
/* 1519 */       for (int inode = 0; inode < nnode; inode++) {
/* 1520 */         Node m = nodes[inode];
/* 1521 */         if (m != a && m != b && !leftOfLine(a, b, m) && (
/* 1522 */           n == null || inCircle(n, b, a, m))) {
/* 1523 */           n = m;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1528 */       if (n != null) {
/*      */ 
/*      */         
/* 1531 */         Tri nba = makeTri(n, b, a);
/*      */ 
/*      */         
/* 1534 */         linkTris(nba, n, abc, c);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1539 */         if (!this._edgeSet.add(nba, a))
/* 1540 */           linkTris(this._edgeSet.abc, this._edgeSet.c, nba, a); 
/* 1541 */         if (!this._edgeSet.add(nba, b)) {
/* 1542 */           linkTris(this._edgeSet.abc, this._edgeSet.c, nba, b);
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1548 */         linkTris(abc, c, null, null);
/* 1549 */         a._tri = abc;
/* 1550 */         b._tri = abc;
/* 1551 */         this._troot = abc;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1559 */     fireNodeRemoved(node);
/*      */     
/* 1561 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean moveNode(Node node, float x, float y) {
/* 1579 */     if (x != node.x() || y != node.y()) {
/* 1580 */       Node nodeNearest = findNodeNearest(x, y);
/* 1581 */       if (node == nodeNearest || x != nodeNearest.x() || y != nodeNearest.y()) {
/* 1582 */         boolean nodeInMesh = removeNode(node);
/* 1583 */         node.setPosition(x, y);
/* 1584 */         if (nodeInMesh) {
/* 1585 */           boolean addedNode = addNode(node);
/* 1586 */           assert addedNode;
/*      */         } 
/* 1588 */         return true;
/*      */       } 
/*      */     } 
/* 1591 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node findNodeNearest(float x, float y) {
/* 1601 */     return findNodeNearest(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Edge findEdge(Node na, Node nb) {
/* 1616 */     Tri tri = findTri(na, nb);
/* 1617 */     if (tri != null) {
/* 1618 */       return edgeOfTri(tri, na, nb);
/*      */     }
/* 1620 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Tri findTri(Node node) {
/* 1632 */     return node._tri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tri findTri(Node na, Node nb) {
/* 1644 */     Tri tri = findTri(na);
/* 1645 */     if (tri != null) {
/* 1646 */       clearTriMarks();
/* 1647 */       tri = findTri(tri, na, nb);
/*      */     } 
/* 1649 */     return tri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tri findTri(Node na, Node nb, Node nc) {
/* 1662 */     Tri tri = findTri(na, nb);
/* 1663 */     if (tri != null) {
/* 1664 */       clearTriMarks();
/* 1665 */       tri = findTri(tri, na, nb, nc);
/*      */     } 
/* 1667 */     return tri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PointLocation locatePoint(float x, float y) {
/* 1677 */     return locatePoint(x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeIterator getNodes() {
/* 1685 */     return new NodeIterator() {
/*      */         public boolean hasNext() {
/* 1687 */           return (this._nnext != null);
/*      */         }
/*      */         public TriMesh.Node next() {
/* 1690 */           if (this._nnext == null)
/* 1691 */             throw new NoSuchElementException(); 
/* 1692 */           TriMesh.Node node = this._nnext;
/* 1693 */           this._nnext = node._next;
/* 1694 */           if (this._nnext == this._nroot) this._nnext = null; 
/* 1695 */           return node;
/*      */         }
/* 1697 */         private TriMesh.Node _nroot = TriMesh.this._nroot;
/* 1698 */         private TriMesh.Node _nnext = this._nroot;
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized TriIterator getTris() {
/* 1707 */     return new TriIterator() {
/*      */         public final boolean hasNext() {
/* 1709 */           return this._i.hasNext();
/*      */         } private Iterator<TriMesh.Tri> _i;
/*      */         public final TriMesh.Tri next() {
/* 1712 */           return this._i.next();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized EdgeIterator getEdgesOnHull() {
/* 1752 */     clearTriMarks();
/* 1753 */     Edge edge = getEdgeOnHull(this._troot);
/* 1754 */     final HashSet<Edge> edges = new HashSet<Edge>(128);
/* 1755 */     getEdgesOnHull(edge, edges);
/* 1756 */     return new EdgeIterator() {
/* 1757 */         private Iterator<TriMesh.Edge> i = edges.iterator();
/*      */         public final boolean hasNext() {
/* 1759 */           return this.i.hasNext();
/*      */         }
/*      */         public final TriMesh.Edge next() {
/* 1762 */           return this.i.next();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node[] getNodeNabors(Node node) {
/* 1773 */     NodeList nabors = new NodeList();
/* 1774 */     getNodeNabors(node, nabors);
/* 1775 */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getNodeNabors(Node node, NodeList nabors) {
/* 1784 */     clearNodeMarks();
/* 1785 */     clearTriMarks();
/* 1786 */     getNodeNabors(node, node._tri, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeStepList getNodeNabors(Node node, int stepMax) {
/* 1798 */     Check.argument((stepMax <= 256), "stepMax <= 256");
/*      */ 
/*      */     
/* 1801 */     clearNodeMarks();
/*      */ 
/*      */     
/* 1804 */     mark(node);
/*      */ 
/*      */     
/* 1807 */     NodeStepList list = new NodeStepList();
/*      */ 
/*      */     
/* 1810 */     for (int step = 1, nnabor1 = 0; step <= stepMax; step++) {
/*      */ 
/*      */       
/* 1813 */       if (step == 1) {
/*      */ 
/*      */         
/* 1816 */         getNodeNabors(node, step, list);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1822 */         int nnabor2 = list.nnode();
/*      */ 
/*      */         
/* 1825 */         Node[] naborNodes = list.nodes();
/* 1826 */         for (int inabor = nnabor1; inabor < nnabor2; inabor++) {
/* 1827 */           node = naborNodes[inabor];
/* 1828 */           getNodeNabors(node, step, list);
/*      */         } 
/*      */ 
/*      */         
/* 1832 */         nnabor1 = nnabor2;
/*      */       } 
/*      */     } 
/* 1835 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tri[] getTriNabors(Node node) {
/* 1844 */     TriList nabors = new TriList();
/* 1845 */     getTriNabors(node, nabors);
/* 1846 */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getTriNabors(Node node, TriList nabors) {
/* 1855 */     clearTriMarks();
/* 1856 */     getTriNabors(node, node._tri, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tri[] getTriNabors(Edge edge) {
/* 1865 */     TriList nabors = new TriList();
/* 1866 */     getTriNabors(edge, nabors);
/* 1867 */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getTriNabors(Edge edge, TriList nabors) {
/* 1876 */     Tri triLeft = edge.triLeft();
/* 1877 */     Tri triRight = edge.triRight();
/* 1878 */     if (triLeft == null && triRight == null) {
/* 1879 */       Node na = edge.nodeA();
/* 1880 */       Node nb = edge.nodeB();
/* 1881 */       edge = findEdge(na, nb);
/* 1882 */       triLeft = edge.triLeft();
/* 1883 */       triRight = edge.triRight();
/*      */     } 
/* 1885 */     if (triLeft != null)
/* 1886 */       nabors.add(triLeft); 
/* 1887 */     if (triRight != null) {
/* 1888 */       nabors.add(triRight);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Edge[] getEdgeNabors(Node node) {
/* 1901 */     EdgeList nabors = new EdgeList();
/* 1902 */     getEdgeNabors(node, nabors);
/* 1903 */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getEdgeNabors(Node node, EdgeList nabors) {
/* 1921 */     Tri tri = node.tri();
/* 1922 */     Node ta = tri.nodeA();
/* 1923 */     Node tb = tri.nodeB();
/* 1924 */     Node tc = tri.nodeC();
/*      */ 
/*      */     
/* 1927 */     Edge edge = null;
/* 1928 */     if (node == ta) {
/* 1929 */       edge = new Edge(tc, ta, tri);
/* 1930 */     } else if (node == tb) {
/* 1931 */       edge = new Edge(ta, tb, tri);
/* 1932 */     } else if (node == tc) {
/* 1933 */       edge = new Edge(tb, tc, tri);
/*      */     } else {
/* 1935 */       assert false : "tri references node";
/*      */     } 
/*      */ 
/*      */     
/* 1939 */     Edge firstEdge = edge;
/*      */ 
/*      */     
/*      */     do {
/* 1943 */       nabors.add(edge);
/*      */ 
/*      */       
/* 1946 */       node = edge.nodeA();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1951 */       tri = edge.triRight();
/* 1952 */       if (tri == null) {
/* 1953 */         tri = edge.triLeft();
/* 1954 */         Node nodeBack = edge.nodeLeft();
/* 1955 */         Tri triBack = tri.triNabor(node);
/* 1956 */         while (triBack != null) {
/* 1957 */           node = nodeBack;
/* 1958 */           nodeBack = tri.nodeNabor(triBack);
/* 1959 */           tri = triBack;
/* 1960 */           triBack = tri.triNabor(node);
/*      */         } 
/* 1962 */         edge = new Edge(null, null, tri, node);
/*      */       } else {
/* 1964 */         edge = new Edge(tri, node);
/*      */       } 
/* 1966 */     } while (!edge.equals(firstEdge));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setOuterBox(float xmin, float ymin, float xmax, float ymax) {
/* 1988 */     Check.argument((xmin < xmax), "outer box is valid");
/* 1989 */     Check.argument((ymin < ymax), "outer box is valid");
/*      */ 
/*      */     
/* 1992 */     if (xmin != this._xminOuter || xmax != this._xmaxOuter || ymin != this._yminOuter || ymax != this._ymaxOuter) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1998 */       this._xminOuter = xmin;
/* 1999 */       this._yminOuter = ymin;
/* 2000 */       this._xmaxOuter = xmax;
/* 2001 */       this._ymaxOuter = ymax;
/*      */ 
/*      */ 
/*      */       
/* 2005 */       TriIterator ti = getTris();
/* 2006 */       while (ti.hasNext()) {
/* 2007 */         Tri tri = ti.next();
/* 2008 */         tri.clearInner();
/* 2009 */         tri.clearOuter();
/*      */       } 
/*      */     } 
/*      */     
/* 2013 */     this._version++;
/* 2014 */     this._outerEnabled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableOuterBox() {
/* 2023 */     this._version++;
/* 2024 */     this._outerEnabled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void disableOuterBox() {
/* 2033 */     this._version++;
/* 2034 */     this._outerEnabled = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Node node) {
/* 2042 */     Tri tri = node.tri();
/* 2043 */     if (tri == null || isInner(tri))
/* 2044 */       return true; 
/* 2045 */     Tri[] tris = getTriNabors(node);
/* 2046 */     int ntri = tris.length;
/* 2047 */     for (int itri = 0; itri < ntri; itri++) {
/* 2048 */       if (isInner(tris[itri]))
/* 2049 */         return true; 
/*      */     } 
/* 2051 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Node node) {
/* 2059 */     return !isInner(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Tri tri) {
/* 2067 */     if (!this._outerEnabled)
/* 2068 */       return true; 
/* 2069 */     if (!tri.isInner() && !tri.isOuter())
/* 2070 */       markTriInnerOrOuter(tri); 
/* 2071 */     return tri.isInner();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Tri tri) {
/* 2079 */     return !isInner(tri);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Edge edge) {
/* 2087 */     Tri triLeft = edge.triLeft();
/* 2088 */     if (triLeft != null && isInner(triLeft))
/* 2089 */       return true; 
/* 2090 */     Tri triRight = edge.triRight();
/* 2091 */     if (triRight != null && isInner(triRight))
/* 2092 */       return true; 
/* 2093 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Edge edge) {
/* 2101 */     return !isInner(edge);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mark(Node node) {
/* 2113 */     node._mark = this._nodeMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markRed(Node node) {
/* 2122 */     node._mark = this._nodeMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markBlue(Node node) {
/* 2130 */     node._mark = this._nodeMarkBlue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarked(Node node) {
/* 2139 */     return (node._mark == this._nodeMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedRed(Node node) {
/* 2148 */     return (node._mark == this._nodeMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedBlue(Node node) {
/* 2157 */     return (node._mark == this._nodeMarkBlue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearNodeMarks() {
/* 2167 */     if (this._nodeMarkRed == 2147483646) {
/* 2168 */       Node node = this._nroot;
/*      */       while (true) {
/* 2170 */         node._mark = 0;
/* 2171 */         node = node._next;
/* 2172 */         if (node == this._nroot) {
/* 2173 */           this._nodeMarkRed = 0;
/* 2174 */           this._nodeMarkBlue = 0; break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2178 */     this._nodeMarkRed++;
/* 2179 */     this._nodeMarkBlue--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mark(Tri tri) {
/* 2191 */     tri._mark = this._triMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markRed(Tri tri) {
/* 2200 */     tri._mark = this._triMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markBlue(Tri tri) {
/* 2208 */     tri._mark = this._triMarkBlue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarked(Tri tri) {
/* 2217 */     return (tri._mark == this._triMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedRed(Tri tri) {
/* 2226 */     return (tri._mark == this._triMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedBlue(Tri tri) {
/* 2235 */     return (tri._mark == this._triMarkBlue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearTriMarks() {
/* 2248 */     if (this._triMarkRed == 2147483646) {
/* 2249 */       this._triMarkRed++;
/* 2250 */       this._triMarkBlue--;
/* 2251 */       markAllTris(this._troot);
/* 2252 */       zeroTriMarks(this._troot);
/* 2253 */       this._triMarkRed = 0;
/* 2254 */       this._triMarkBlue = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2258 */     this._triMarkRed++;
/* 2259 */     this._triMarkBlue--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void validate() {
/* 2269 */     int nnode = 0;
/* 2270 */     NodeIterator ni = getNodes();
/* 2271 */     while (ni.hasNext()) {
/* 2272 */       nnode++;
/* 2273 */       Node node = ni.next();
/* 2274 */       validate(node);
/*      */     } 
/* 2276 */     assert nnode == this._nnode;
/*      */ 
/*      */     
/* 2279 */     int ntri = 0;
/* 2280 */     TriIterator ti = getTris();
/* 2281 */     while (ti.hasNext()) {
/* 2282 */       ntri++;
/* 2283 */       Tri tri = ti.next();
/* 2284 */       validate(tri);
/*      */     } 
/* 2286 */     assert ntri == this._ntri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/* 2296 */     this._version = 0L;
/* 2297 */     this._nnode = 0;
/* 2298 */     this._ntri = 0;
/* 2299 */     this._nroot = null;
/* 2300 */     this._troot = null;
/* 2301 */     this._sampledNodes = new HashSet<Node>(256);
/* 2302 */     this._triMarkRed = 0;
/* 2303 */     this._triMarkBlue = 0;
/* 2304 */     this._nodeMarkRed = 0;
/* 2305 */     this._nodeMarkBlue = 0;
/* 2306 */     this._edgeSet = new EdgeSet(256, 0.25D);
/* 2307 */     this._nodeSet = new NodeSet(256, 0.25D);
/* 2308 */     this._nodeList = new NodeList();
/* 2309 */     this._nmin = null;
/* 2310 */     this._dmin = 0.0D;
/* 2311 */     this._deadTris = new TriList();
/* 2312 */     this._nnodeListeners = 0;
/* 2313 */     this._ntriListeners = 0;
/* 2314 */     this._listeners = new EventListenerList();
/* 2315 */     this._outerEnabled = false;
/* 2316 */     this._xminOuter = 0.0D;
/* 2317 */     this._yminOuter = 0.0D;
/* 2318 */     this._xmaxOuter = 0.0D;
/* 2319 */     this._ymaxOuter = 0.0D;
/* 2320 */     this._nnodeValues = 0;
/* 2321 */     this._lnodeValues = 0;
/* 2322 */     this._nodePropertyMaps = new HashMap<String, NodePropertyMap>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NodePropertyMapInternal
/*      */     implements NodePropertyMap
/*      */   {
/*      */     private int _index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object get(TriMesh.Node node) {
/* 2364 */       return node._values[this._index];
/*      */     }
/*      */     public void put(TriMesh.Node node, Object value) {
/* 2367 */       node._values[this._index] = value;
/*      */     }
/*      */     NodePropertyMapInternal(int index) {
/* 2370 */       this._index = index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void updatePropertyValues(Node node) {
/* 2379 */     if (this._lnodeValues == 0) {
/* 2380 */       node._values = null;
/* 2381 */     } else if (node._values == null) {
/* 2382 */       node._values = new Object[this._lnodeValues];
/* 2383 */     } else if (node._values.length != this._lnodeValues) {
/* 2384 */       Object[] valuesOld = node._values;
/* 2385 */       Object[] valuesNew = new Object[this._lnodeValues];
/* 2386 */       int n = MathPlus.min(valuesOld.length, valuesNew.length);
/* 2387 */       for (int i = 0; i < n; i++)
/* 2388 */         valuesNew[i] = valuesOld[i]; 
/* 2389 */       node._values = valuesNew;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Tri makeTri(Node n0, Node n1, Node n2) {
/* 2420 */     this._ntri++;
/* 2421 */     int ndead = this._deadTris.ntri();
/* 2422 */     if (ndead == 0) {
/* 2423 */       this._troot = new Tri(n0, n1, n2);
/*      */     } else {
/* 2425 */       this._troot = this._deadTris.remove(ndead - 1);
/* 2426 */       this._troot.init(n0, n1, n2);
/*      */     } 
/* 2428 */     if (this._ntriListeners > 0)
/* 2429 */       fireTriAdded(this._troot); 
/* 2430 */     return this._troot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void killTri(Tri tri) {
/* 2438 */     this._ntri--;
/* 2439 */     fireTriRemoved(tri);
/* 2440 */     int ndead = this._deadTris.ntri();
/* 2441 */     if (ndead < 256) {
/* 2442 */       this._deadTris.add(tri);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double distanceSquared(Node node, double x, double y) {
/* 2456 */     double dx = x - node._x;
/* 2457 */     double dy = y - node._y;
/* 2458 */     return dx * dx + dy * dy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean leftOfLine(Node a, Node b, Node n) {
/* 2466 */     return (Geometry.leftOfLine(a._x, a._y, b._x, b._y, n._x, n._y) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean leftOfLine(Node a, Node b, double x, double y) {
/* 2476 */     return (Geometry.leftOfLine(a._x, a._y, b._x, b._y, x, y) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean inCircle(Node a, Node b, Node c, Node n) {
/* 2486 */     return (Geometry.inCircle(a._x, a._y, b._x, b._y, c._x, c._y, n._x, n._y) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean inCircle(Node a, Node b, Node c, double x, double y) {
/* 2496 */     return (Geometry.inCircle(a._x, a._y, b._x, b._y, c._x, c._y, x, y) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createFirstTri() {
/* 2503 */     Check.state((this._nnode == 3), "exactly three nodes available for first tri");
/* 2504 */     Node n0 = this._nroot;
/* 2505 */     Node n1 = n0._next;
/* 2506 */     Node n2 = n1._next;
/* 2507 */     double orient = Geometry.leftOfLine(n0._x, n0._y, n1._x, n1._y, n2._x, n2._y);
/*      */ 
/*      */ 
/*      */     
/* 2511 */     Check.state((orient != 0.0D), "three nodes for first tri are not co-linear");
/* 2512 */     if (orient > 0.0D) {
/* 2513 */       makeTri(n0, n1, n2);
/*      */     } else {
/* 2515 */       makeTri(n0, n2, n1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getNodeNabors(Node node, Tri tri, NodeList nabors) {
/* 2528 */     mark(tri);
/* 2529 */     Node n0 = tri._n0;
/* 2530 */     Node n1 = tri._n1;
/* 2531 */     Node n2 = tri._n2;
/* 2532 */     Tri t0 = tri._t0;
/* 2533 */     Tri t1 = tri._t1;
/* 2534 */     Tri t2 = tri._t2;
/* 2535 */     if (node == n0) {
/* 2536 */       if (!isMarked(n1)) {
/* 2537 */         mark(n1);
/* 2538 */         nabors.add(n1);
/*      */       } 
/* 2540 */       if (!isMarked(n2)) {
/* 2541 */         mark(n2);
/* 2542 */         nabors.add(n2);
/*      */       } 
/* 2544 */       if (t1 != null && !isMarked(t1))
/* 2545 */         getNodeNabors(node, t1, nabors); 
/* 2546 */       if (t2 != null && !isMarked(t2))
/* 2547 */         getNodeNabors(node, t2, nabors); 
/* 2548 */     } else if (node == n1) {
/* 2549 */       if (!isMarked(n2)) {
/* 2550 */         mark(n2);
/* 2551 */         nabors.add(n2);
/*      */       } 
/* 2553 */       if (!isMarked(n0)) {
/* 2554 */         mark(n0);
/* 2555 */         nabors.add(n0);
/*      */       } 
/* 2557 */       if (t2 != null && !isMarked(t2))
/* 2558 */         getNodeNabors(node, t2, nabors); 
/* 2559 */       if (t0 != null && !isMarked(t0))
/* 2560 */         getNodeNabors(node, t0, nabors); 
/* 2561 */     } else if (node == n2) {
/* 2562 */       if (!isMarked(n0)) {
/* 2563 */         mark(n0);
/* 2564 */         nabors.add(n0);
/*      */       } 
/* 2566 */       if (!isMarked(n1)) {
/* 2567 */         mark(n1);
/* 2568 */         nabors.add(n1);
/*      */       } 
/* 2570 */       if (t0 != null && !isMarked(t0))
/* 2571 */         getNodeNabors(node, t0, nabors); 
/* 2572 */       if (t1 != null && !isMarked(t1))
/* 2573 */         getNodeNabors(node, t1, nabors); 
/*      */     } else {
/* 2575 */       assert false : "node is referenced by tri";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getNodeNabors(Node node, int step, NodeStepList nabors) {
/* 2587 */     Tri[] tris = getTriNabors(node);
/* 2588 */     int ntri = tris.length;
/* 2589 */     for (int itri = 0; itri < ntri; itri++) {
/* 2590 */       Tri tri = tris[itri];
/* 2591 */       Node n0 = tri._n0;
/* 2592 */       Node n1 = tri._n1;
/* 2593 */       Node n2 = tri._n2;
/* 2594 */       if (node == n0) {
/* 2595 */         if (!isMarked(n1)) {
/* 2596 */           mark(n1);
/* 2597 */           nabors.add(n1, step);
/*      */         } 
/* 2599 */         if (!isMarked(n2)) {
/* 2600 */           mark(n2);
/* 2601 */           nabors.add(n2, step);
/*      */         } 
/* 2603 */       } else if (node == n1) {
/* 2604 */         if (!isMarked(n0)) {
/* 2605 */           mark(n0);
/* 2606 */           nabors.add(n0, step);
/*      */         } 
/* 2608 */         if (!isMarked(n2)) {
/* 2609 */           mark(n2);
/* 2610 */           nabors.add(n2, step);
/*      */         } 
/* 2612 */       } else if (node == n2) {
/* 2613 */         if (!isMarked(n0)) {
/* 2614 */           mark(n0);
/* 2615 */           nabors.add(n0, step);
/*      */         } 
/* 2617 */         if (!isMarked(n1)) {
/* 2618 */           mark(n1);
/* 2619 */           nabors.add(n1, step);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getTriNabors(Node node, Tri tri, TriList nabors) {
/* 2632 */     if (tri != null) {
/* 2633 */       mark(tri);
/* 2634 */       nabors.add(tri);
/* 2635 */       Node n0 = tri._n0;
/* 2636 */       Node n1 = tri._n1;
/* 2637 */       Node n2 = tri._n2;
/* 2638 */       Tri t0 = tri._t0;
/* 2639 */       Tri t1 = tri._t1;
/* 2640 */       Tri t2 = tri._t2;
/* 2641 */       if (node == n0) {
/* 2642 */         if (t1 != null && !isMarked(t1))
/* 2643 */           getTriNabors(node, t1, nabors); 
/* 2644 */         if (t2 != null && !isMarked(t2))
/* 2645 */           getTriNabors(node, t2, nabors); 
/* 2646 */       } else if (node == n1) {
/* 2647 */         if (t2 != null && !isMarked(t2))
/* 2648 */           getTriNabors(node, t2, nabors); 
/* 2649 */         if (t0 != null && !isMarked(t0))
/* 2650 */           getTriNabors(node, t0, nabors); 
/* 2651 */       } else if (node == n2) {
/* 2652 */         if (t0 != null && !isMarked(t0))
/* 2653 */           getTriNabors(node, t0, nabors); 
/* 2654 */         if (t1 != null && !isMarked(t1))
/* 2655 */           getTriNabors(node, t1, nabors); 
/*      */       } else {
/* 2657 */         assert false : "node is referenced by tri";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node findNodeNearest(double x, double y) {
/* 2668 */     this._nmin = this._nroot;
/* 2669 */     this._dmin = distanceSquared(this._nmin, x, y);
/* 2670 */     Iterator<Node> ni = this._sampledNodes.iterator();
/* 2671 */     while (ni.hasNext()) {
/* 2672 */       Node n = ni.next();
/* 2673 */       double d = distanceSquared(n, x, y);
/* 2674 */       if (d < this._dmin) {
/* 2675 */         this._dmin = d;
/* 2676 */         this._nmin = n;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2685 */     clearNodeMarks();
/*      */     
/*      */     while (true) {
/* 2688 */       clearTriMarks();
/* 2689 */       double dmin = this._dmin;
/* 2690 */       findNodeNaborNearest(x, y, this._nmin, this._nmin._tri);
/* 2691 */       if (this._dmin >= dmin) {
/* 2692 */         return this._nmin;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearest(double x, double y, Node node, Tri tri) {
/* 2704 */     mark(tri);
/* 2705 */     Node n0 = tri._n0;
/* 2706 */     Node n1 = tri._n1;
/* 2707 */     Node n2 = tri._n2;
/* 2708 */     Tri t0 = tri._t0;
/* 2709 */     Tri t1 = tri._t1;
/* 2710 */     Tri t2 = tri._t2;
/* 2711 */     if (node == n0) {
/* 2712 */       findNodeNaborNearest(x, y, node, n1, n2, t1, t2);
/* 2713 */     } else if (node == n1) {
/* 2714 */       findNodeNaborNearest(x, y, node, n2, n0, t2, t0);
/* 2715 */     } else if (node == n2) {
/* 2716 */       findNodeNaborNearest(x, y, node, n0, n1, t0, t1);
/*      */     } else {
/* 2718 */       assert false : "node is referenced by tri";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearest(double x, double y, Node node, Node na, Node nb, Tri ta, Tri tb) {
/* 2725 */     if (!isMarked(na)) {
/* 2726 */       mark(na);
/* 2727 */       double da = distanceSquared(na, x, y);
/* 2728 */       if (da < this._dmin) {
/* 2729 */         this._dmin = da;
/* 2730 */         this._nmin = na;
/*      */       } 
/*      */     } 
/* 2733 */     if (!isMarked(nb)) {
/* 2734 */       mark(nb);
/* 2735 */       double db = distanceSquared(nb, x, y);
/* 2736 */       if (db < this._dmin) {
/* 2737 */         this._dmin = db;
/* 2738 */         this._nmin = nb;
/*      */       } 
/*      */     } 
/* 2741 */     if (ta != null && !isMarked(ta))
/* 2742 */       findNodeNaborNearest(x, y, node, ta); 
/* 2743 */     if (tb != null && !isMarked(tb)) {
/* 2744 */       findNodeNaborNearest(x, y, node, tb);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tri findTri(Tri tri, Node na, Node nb) {
/* 2753 */     if (tri != null) {
/* 2754 */       mark(tri);
/* 2755 */       Node n0 = tri._n0;
/* 2756 */       Node n1 = tri._n1;
/* 2757 */       Node n2 = tri._n2;
/* 2758 */       Tri t0 = tri._t0;
/* 2759 */       Tri t1 = tri._t1;
/* 2760 */       Tri t2 = tri._t2;
/* 2761 */       if (na == n0) {
/* 2762 */         if (nb == n1 || nb == n2 || (t1 != null && !isMarked(t1) && (tri = findTri(t1, na, nb)) != null) || (t2 != null && !isMarked(t2) && (tri = findTri(t2, na, nb)) != null))
/*      */         {
/*      */           
/* 2765 */           return tri; } 
/* 2766 */       } else if (na == n1) {
/* 2767 */         if (nb == n2 || nb == n0 || (t2 != null && !isMarked(t2) && (tri = findTri(t2, na, nb)) != null) || (t0 != null && !isMarked(t0) && (tri = findTri(t0, na, nb)) != null))
/*      */         {
/*      */           
/* 2770 */           return tri; } 
/* 2771 */       } else if (na == n2) {
/* 2772 */         if (nb == n0 || nb == n1 || (t0 != null && !isMarked(t0) && (tri = findTri(t0, na, nb)) != null) || (t1 != null && !isMarked(t1) && (tri = findTri(t1, na, nb)) != null))
/*      */         {
/*      */           
/* 2775 */           return tri; } 
/*      */       } else {
/* 2777 */         assert false : "node na is referenced by tri";
/*      */       } 
/*      */     } 
/* 2780 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tri findTri(Tri tri, Node na, Node nb, Node nc) {
/* 2789 */     if (tri != null) {
/* 2790 */       mark(tri);
/* 2791 */       Node n0 = tri._n0;
/* 2792 */       Node n1 = tri._n1;
/* 2793 */       Node n2 = tri._n2;
/* 2794 */       Tri t0 = tri._t0;
/* 2795 */       Tri t1 = tri._t1;
/* 2796 */       Tri t2 = tri._t2;
/* 2797 */       if (na == n0) {
/* 2798 */         if (nb == n1) {
/* 2799 */           if (nc == n2 || (t2 != null && !isMarked(t2) && (tri = findTri(t2, na, nb, nc)) != null))
/*      */           {
/* 2801 */             return tri; } 
/* 2802 */         } else if (nb == n2) {
/* 2803 */           if (nc == n1 || (t1 != null && !isMarked(t1) && (tri = findTri(t1, na, nb, nc)) != null))
/*      */           {
/* 2805 */             return tri; } 
/*      */         } else {
/* 2807 */           assert false : "node nb is referenced by tri";
/*      */         } 
/* 2809 */       } else if (na == n1) {
/* 2810 */         if (nb == n0) {
/* 2811 */           if (nc == n2 || (t2 != null && !isMarked(t2) && (tri = findTri(t2, na, nb, nc)) != null))
/*      */           {
/* 2813 */             return tri; } 
/* 2814 */         } else if (nb == n2) {
/* 2815 */           if (nc == n0 || (t0 != null && !isMarked(t0) && (tri = findTri(t0, na, nb, nc)) != null))
/*      */           {
/* 2817 */             return tri; } 
/*      */         } else {
/* 2819 */           assert false : "node nb is referenced by tri";
/*      */         } 
/* 2821 */       } else if (na == n2) {
/* 2822 */         if (nb == n0) {
/* 2823 */           if (nc == n1 || (t1 != null && !isMarked(t1) && (tri = findTri(t1, na, nb, nc)) != null))
/*      */           {
/* 2825 */             return tri; } 
/* 2826 */         } else if (nb == n1) {
/* 2827 */           if (nc == n0 || (t0 != null && !isMarked(t0) && (tri = findTri(t0, na, nb, nc)) != null))
/*      */           {
/* 2829 */             return tri; } 
/*      */         } else {
/* 2831 */           assert false : "node nb is referenced by tri";
/*      */         } 
/*      */       } else {
/* 2834 */         assert false : "node na is referenced by tri";
/*      */       } 
/*      */     } 
/* 2837 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PointLocation locatePoint(double x, double y) {
/* 2847 */     if (this._troot == null) {
/* 2848 */       if (this._nroot != null) {
/* 2849 */         Node node = this._nroot;
/*      */         do {
/* 2851 */           if (x == node.x() && y == node.y())
/* 2852 */             return new PointLocation(node); 
/* 2853 */           node = node._next;
/* 2854 */         } while (node != this._nroot);
/*      */       } 
/* 2856 */       return new PointLocation(null, false);
/*      */     } 
/*      */ 
/*      */     
/* 2860 */     Node nmin = this._nroot;
/* 2861 */     double dmin = distanceSquared(nmin, x, y);
/* 2862 */     Iterator<Node> ni = this._sampledNodes.iterator();
/* 2863 */     while (ni.hasNext()) {
/* 2864 */       Node n = ni.next();
/* 2865 */       double d = distanceSquared(n, x, y);
/* 2866 */       if (d < dmin) {
/* 2867 */         dmin = d;
/* 2868 */         nmin = n;
/*      */       } 
/*      */     } 
/* 2871 */     Tri tri = nmin._tri;
/* 2872 */     return locatePoint(tri, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PointLocation locatePoint(Tri tri, double x, double y) {
/* 2882 */     this._troot = tri;
/*      */ 
/*      */     
/* 2885 */     Node n0 = tri._n0;
/* 2886 */     Node n1 = tri._n1;
/* 2887 */     Node n2 = tri._n2;
/* 2888 */     double x0 = n0._x;
/* 2889 */     double y0 = n0._y;
/* 2890 */     double x1 = n1._x;
/* 2891 */     double y1 = n1._y;
/* 2892 */     double x2 = n2._x;
/* 2893 */     double y2 = n2._y;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2898 */     if (x == x0 && y == y0)
/* 2899 */       return new PointLocation(n0); 
/* 2900 */     if (x == x1 && y == y1)
/* 2901 */       return new PointLocation(n1); 
/* 2902 */     if (x == x2 && y == y2) {
/* 2903 */       return new PointLocation(n2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2913 */     double d0 = Geometry.leftOfLine(x2, y2, x1, y1, x, y);
/* 2914 */     if (d0 > 0.0D) {
/* 2915 */       Tri triNabor = tri.triNabor(n0);
/* 2916 */       if (triNabor != null) {
/* 2917 */         return locatePoint(triNabor, x, y);
/*      */       }
/* 2919 */       return new PointLocation(tri, false);
/*      */     } 
/*      */     
/* 2922 */     double d1 = Geometry.leftOfLine(x0, y0, x2, y2, x, y);
/* 2923 */     if (d1 > 0.0D) {
/* 2924 */       Tri triNabor = tri.triNabor(n1);
/* 2925 */       if (triNabor != null) {
/* 2926 */         return locatePoint(triNabor, x, y);
/*      */       }
/* 2928 */       return new PointLocation(tri, false);
/*      */     } 
/*      */     
/* 2931 */     double d2 = Geometry.leftOfLine(x1, y1, x0, y0, x, y);
/* 2932 */     if (d2 > 0.0D) {
/* 2933 */       Tri triNabor = tri.triNabor(n2);
/* 2934 */       if (triNabor != null) {
/* 2935 */         return locatePoint(triNabor, x, y);
/*      */       }
/* 2937 */       return new PointLocation(tri, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2942 */     if (d0 < 0.0D && d1 < 0.0D && d2 < 0.0D) {
/* 2943 */       return new PointLocation(tri);
/*      */     }
/*      */ 
/*      */     
/* 2947 */     if (d0 == 0.0D)
/* 2948 */       return new PointLocation(new Edge(tri, n0)); 
/* 2949 */     if (d1 == 0.0D)
/* 2950 */       return new PointLocation(new Edge(tri, n1)); 
/* 2951 */     if (d2 == 0.0D) {
/* 2952 */       return new PointLocation(new Edge(tri, n2));
/*      */     }
/*      */ 
/*      */     
/* 2956 */     assert false : "successfully located the point";
/* 2957 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayEdgesInside(Node node, Tri tri) {
/* 2966 */     if (tri != null && !isMarked(tri)) {
/* 2967 */       mark(tri);
/* 2968 */       Node n0 = tri._n0;
/* 2969 */       Node n1 = tri._n1;
/* 2970 */       Node n2 = tri._n2;
/* 2971 */       if (inCircle(n0, n1, n2, node)) {
/* 2972 */         killTri(tri);
/* 2973 */         Tri t0 = tri._t0;
/* 2974 */         Tri t1 = tri._t1;
/* 2975 */         Tri t2 = tri._t2;
/* 2976 */         this._edgeSet.addMate(tri, n0);
/* 2977 */         this._edgeSet.addMate(tri, n1);
/* 2978 */         this._edgeSet.addMate(tri, n2);
/* 2979 */         getDelaunayEdgesInside(node, t0);
/* 2980 */         getDelaunayEdgesInside(node, t1);
/* 2981 */         getDelaunayEdgesInside(node, t2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayEdgesOutside(Node node, Tri tri) {
/* 2992 */     if (tri != null && !isMarked(tri)) {
/* 2993 */       mark(tri);
/* 2994 */       Node n0 = tri._n0;
/* 2995 */       Node n1 = tri._n1;
/* 2996 */       Node n2 = tri._n2;
/* 2997 */       Tri t0 = tri._t0;
/* 2998 */       Tri t1 = tri._t1;
/* 2999 */       Tri t2 = tri._t2;
/* 3000 */       if (t0 == null && leftOfLine(n2, n1, node)) {
/* 3001 */         this._edgeSet.add(tri, n0);
/* 3002 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n1, n0));
/* 3003 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n2, n0));
/*      */       } 
/* 3005 */       if (t1 == null && leftOfLine(n0, n2, node)) {
/* 3006 */         this._edgeSet.add(tri, n1);
/* 3007 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n2, n1));
/* 3008 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n0, n1));
/*      */       } 
/* 3010 */       if (t2 == null && leftOfLine(n1, n0, node)) {
/* 3011 */         this._edgeSet.add(tri, n2);
/* 3012 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n0, n2));
/* 3013 */         getDelaunayEdgesOutside(node, getNextTriOnHull(tri, n1, n2));
/*      */       } 
/* 3015 */       if (inCircle(n0, n1, n2, node)) {
/* 3016 */         killTri(tri);
/* 3017 */         this._edgeSet.addMate(tri, n0);
/* 3018 */         this._edgeSet.addMate(tri, n1);
/* 3019 */         this._edgeSet.addMate(tri, n2);
/* 3020 */         getDelaunayEdgesOutside(node, t0);
/* 3021 */         getDelaunayEdgesOutside(node, t1);
/* 3022 */         getDelaunayEdgesOutside(node, t2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayEdgesOpposite(Node node, Tri tri) {
/* 3035 */     if (tri != null && !isMarked(tri)) {
/* 3036 */       mark(tri);
/* 3037 */       killTri(tri);
/* 3038 */       Node n0 = tri._n0;
/* 3039 */       Node n1 = tri._n1;
/* 3040 */       Node n2 = tri._n2;
/* 3041 */       Tri t0 = tri._t0;
/* 3042 */       Tri t1 = tri._t1;
/* 3043 */       Tri t2 = tri._t2;
/* 3044 */       if (node == n0) {
/* 3045 */         this._edgeSet.addMate(tri, n0);
/* 3046 */         getDelaunayEdgesOpposite(node, n1, n2, t1, t2);
/* 3047 */       } else if (node == n1) {
/* 3048 */         this._edgeSet.addMate(tri, n1);
/* 3049 */         getDelaunayEdgesOpposite(node, n2, n0, t2, t0);
/* 3050 */       } else if (node == n2) {
/* 3051 */         this._edgeSet.addMate(tri, n2);
/* 3052 */         getDelaunayEdgesOpposite(node, n0, n1, t0, t1);
/*      */       } else {
/* 3054 */         assert false : "node is referenced by tri";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void getDelaunayEdgesOpposite(Node node, Node na, Node nb, Tri ta, Tri tb) {
/* 3061 */     if (!isMarked(na)) {
/* 3062 */       mark(na);
/* 3063 */       this._nodeList.add(na);
/*      */     } 
/* 3065 */     if (!isMarked(nb)) {
/* 3066 */       mark(nb);
/* 3067 */       this._nodeList.add(nb);
/*      */     } 
/* 3069 */     getDelaunayEdgesOpposite(node, ta);
/* 3070 */     getDelaunayEdgesOpposite(node, tb);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tri getNextTriOnHull(Tri tri, Node node, Node nodeOther) {
/* 3080 */     for (Tri tnext = tri.triNabor(node); tnext != null; tnext = tri.triNabor(node)) {
/* 3081 */       node = nodeOther;
/* 3082 */       nodeOther = tri.nodeNabor(tnext);
/* 3083 */       tri = tnext;
/*      */     } 
/* 3085 */     return tri;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node findNodeNearestSlow(float x, float y) {
/* 3097 */     clearTriMarks();
/* 3098 */     clearNodeMarks();
/*      */ 
/*      */     
/* 3101 */     this._dmin = Double.MAX_VALUE;
/* 3102 */     this._nmin = null;
/* 3103 */     if (this._troot == null) {
/* 3104 */       if (this._nroot != null) {
/* 3105 */         Node node = this._nroot;
/*      */         do {
/* 3107 */           updateNodeNearest(x, y, node);
/* 3108 */           node = node._next;
/* 3109 */         } while (node != this._nroot);
/*      */       } 
/* 3111 */       assert this._nmin != null;
/* 3112 */       return this._nmin;
/*      */     } 
/*      */ 
/*      */     
/* 3116 */     PointLocation pl = locatePoint(x, y);
/*      */ 
/*      */     
/* 3119 */     if (pl.isOnNode()) {
/* 3120 */       updateNodeNearest(x, y, pl.node());
/* 3121 */       return this._nmin;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3126 */     if (pl.isInside()) {
/* 3127 */       findNodeNearestInside(x, y, pl.tri());
/*      */     } else {
/* 3129 */       findNodeNearestOutside(x, y, pl.tri());
/*      */     } 
/* 3131 */     return this._nmin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNearestInside(double x, double y, Tri tri) {
/* 3143 */     if (tri != null && !isMarked(tri)) {
/* 3144 */       mark(tri);
/* 3145 */       Node n0 = tri._n0;
/* 3146 */       Node n1 = tri._n1;
/* 3147 */       Node n2 = tri._n2;
/* 3148 */       updateNodeNearest(x, y, n0);
/* 3149 */       updateNodeNearest(x, y, n1);
/* 3150 */       updateNodeNearest(x, y, n2);
/* 3151 */       if (inCircle(n0, n1, n2, x, y)) {
/* 3152 */         Tri t0 = tri._t0;
/* 3153 */         Tri t1 = tri._t1;
/* 3154 */         Tri t2 = tri._t2;
/* 3155 */         findNodeNearestInside(x, y, t0);
/* 3156 */         findNodeNearestInside(x, y, t1);
/* 3157 */         findNodeNearestInside(x, y, t2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNearestOutside(double x, double y, Tri tri) {
/* 3170 */     if (tri != null && !isMarked(tri)) {
/* 3171 */       mark(tri);
/* 3172 */       Node n0 = tri._n0;
/* 3173 */       Node n1 = tri._n1;
/* 3174 */       Node n2 = tri._n2;
/* 3175 */       updateNodeNearest(x, y, n0);
/* 3176 */       updateNodeNearest(x, y, n1);
/* 3177 */       updateNodeNearest(x, y, n2);
/* 3178 */       Tri t0 = tri._t0;
/* 3179 */       Tri t1 = tri._t1;
/* 3180 */       Tri t2 = tri._t2;
/* 3181 */       if (t0 == null && leftOfLine(n2, n1, x, y)) {
/* 3182 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n1, n0));
/* 3183 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n2, n0));
/*      */       } 
/* 3185 */       if (t1 == null && leftOfLine(n0, n2, x, y)) {
/* 3186 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n2, n1));
/* 3187 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n0, n1));
/*      */       } 
/* 3189 */       if (t2 == null && leftOfLine(n1, n0, x, y)) {
/* 3190 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n0, n2));
/* 3191 */         findNodeNearestOutside(x, y, getNextTriOnHull(tri, n1, n2));
/*      */       } 
/* 3193 */       if (inCircle(n0, n1, n2, x, y)) {
/* 3194 */         findNodeNearestOutside(x, y, t0);
/* 3195 */         findNodeNearestOutside(x, y, t1);
/* 3196 */         findNodeNearestOutside(x, y, t2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateNodeNearest(double x, double y, Node n) {
/* 3209 */     if (!isMarked(n)) {
/* 3210 */       mark(n);
/* 3211 */       double d = distanceSquared(n, x, y);
/* 3212 */       if (d < this._dmin) {
/* 3213 */         this._dmin = d;
/* 3214 */         this._nmin = n;
/* 3215 */         this._nroot = n;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void linkTris(Tri tri, Node node, Tri triNabor, Node nodeNabor) {
/* 3224 */     if (tri != null) {
/* 3225 */       if (node == tri._n0) {
/* 3226 */         tri._t0 = triNabor;
/* 3227 */       } else if (node == tri._n1) {
/* 3228 */         tri._t1 = triNabor;
/* 3229 */       } else if (node == tri._n2) {
/* 3230 */         tri._t2 = triNabor;
/*      */       } else {
/* 3232 */         assert false : "node referenced by tri";
/*      */       } 
/*      */     }
/* 3235 */     if (triNabor != null) {
/* 3236 */       if (nodeNabor == triNabor._n0) {
/* 3237 */         triNabor._t0 = tri;
/* 3238 */       } else if (nodeNabor == triNabor._n1) {
/* 3239 */         triNabor._t1 = tri;
/* 3240 */       } else if (nodeNabor == triNabor._n2) {
/* 3241 */         triNabor._t2 = tri;
/*      */       } else {
/* 3243 */         assert false : "nodeNabor referenced by triNabor";
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void markAllTris(Tri tri) {
/* 3252 */     tri._mark = this._triMarkRed;
/* 3253 */     Tri t0 = tri._t0;
/* 3254 */     if (t0 != null && t0._mark != this._triMarkRed)
/* 3255 */       markAllTris(t0); 
/* 3256 */     Tri t1 = tri._t1;
/* 3257 */     if (t1 != null && t1._mark != this._triMarkRed)
/* 3258 */       markAllTris(t1); 
/* 3259 */     Tri t2 = tri._t2;
/* 3260 */     if (t2 != null && t2._mark != this._triMarkRed) {
/* 3261 */       markAllTris(t2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void zeroTriMarks(Tri tri) {
/* 3269 */     tri._mark = 0;
/* 3270 */     Tri t0 = tri._t0;
/* 3271 */     if (t0 != null && t0._mark != 0)
/* 3272 */       zeroTriMarks(t0); 
/* 3273 */     Tri t1 = tri._t1;
/* 3274 */     if (t1 != null && t1._mark != 0)
/* 3275 */       zeroTriMarks(t1); 
/* 3276 */     Tri t2 = tri._t2;
/* 3277 */     if (t2 != null && t2._mark != 0) {
/* 3278 */       zeroTriMarks(t2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Edge getEdgeOnHull(Tri tri) {
/* 3287 */     mark(tri);
/* 3288 */     if (tri._t0 == null)
/* 3289 */       return new Edge(tri, tri._n0); 
/* 3290 */     if (tri._t1 == null)
/* 3291 */       return new Edge(tri, tri._n1); 
/* 3292 */     if (tri._t2 == null)
/* 3293 */       return new Edge(tri, tri._n2); 
/* 3294 */     if (!isMarked(tri._t0)) {
/* 3295 */       Edge edge = getEdgeOnHull(tri._t0);
/* 3296 */       if (edge != null)
/* 3297 */         return edge; 
/*      */     } 
/* 3299 */     if (!isMarked(tri._t1)) {
/* 3300 */       Edge edge = getEdgeOnHull(tri._t1);
/* 3301 */       if (edge != null)
/* 3302 */         return edge; 
/*      */     } 
/* 3304 */     if (!isMarked(tri._t2)) {
/* 3305 */       Edge edge = getEdgeOnHull(tri._t2);
/* 3306 */       if (edge != null)
/* 3307 */         return edge; 
/*      */     } 
/* 3309 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getEdgesOnHull(Edge edge, HashSet<Edge> edges) {
/* 3317 */     if (!edges.contains(edge)) {
/* 3318 */       edges.add(edge);
/* 3319 */       getEdgesOnHull(getNextEdgeOnHull(edge.nodeA(), edge), edges);
/* 3320 */       getEdgesOnHull(getNextEdgeOnHull(edge.nodeB(), edge), edges);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Edge getNextEdgeOnHull(Node node, Edge edge) {
/* 3329 */     Tri tri = edge.triLeft();
/* 3330 */     Node next = edge.nodeLeft();
/* 3331 */     for (Tri tnext = tri.triNabor(node); tnext != null; tnext = tri.triNabor(node)) {
/* 3332 */       node = next;
/* 3333 */       next = tri.nodeNabor(tnext);
/* 3334 */       tri = tnext;
/*      */     } 
/* 3336 */     return new Edge(tri, node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Edge edgeOfTri(Tri tri, Node na, Node nb) {
/* 3360 */     Node n0 = tri._n0;
/* 3361 */     Node n1 = tri._n1;
/* 3362 */     Node n2 = tri._n2;
/* 3363 */     if (na == n0) {
/* 3364 */       if (nb == n1)
/* 3365 */         return new Edge(tri, n2); 
/* 3366 */       if (nb == n2) {
/* 3367 */         return new Edge(tri, n1);
/*      */       }
/* 3369 */       return null;
/*      */     } 
/* 3371 */     if (na == n1) {
/* 3372 */       if (nb == n0)
/* 3373 */         return new Edge(tri, n2); 
/* 3374 */       if (nb == n2) {
/* 3375 */         return new Edge(tri, n0);
/*      */       }
/* 3377 */       return null;
/*      */     } 
/* 3379 */     if (na == n2) {
/* 3380 */       if (nb == n0)
/* 3381 */         return new Edge(tri, n1); 
/* 3382 */       if (nb == n1) {
/* 3383 */         return new Edge(tri, n0);
/*      */       }
/* 3385 */       return null;
/*      */     } 
/*      */     
/* 3388 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean nodesInOrder(Tri tri, Node na, Node nb, Node nc) {
/* 3398 */     Node n0 = tri._n0;
/* 3399 */     Node n1 = tri._n1;
/* 3400 */     Node n2 = tri._n2;
/* 3401 */     return ((na == n0 && nb == n1 && nc == n2) || (na == n1 && nb == n2 && nc == n0) || (na == n2 && nb == n0 && nc == n1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Node otherNode(Tri tri, Node na, Node nb) {
/* 3412 */     Node n0 = tri._n0;
/* 3413 */     Node n1 = tri._n1;
/* 3414 */     Node n2 = tri._n2;
/* 3415 */     if (na == n0) {
/* 3416 */       if (nb == n1)
/* 3417 */         return n2; 
/* 3418 */       if (nb == n2) {
/* 3419 */         return n1;
/*      */       }
/* 3421 */       return null;
/*      */     } 
/* 3423 */     if (na == n1) {
/* 3424 */       if (nb == n0)
/* 3425 */         return n2; 
/* 3426 */       if (nb == n2) {
/* 3427 */         return n0;
/*      */       }
/* 3429 */       return null;
/*      */     } 
/* 3431 */     if (na == n2) {
/* 3432 */       if (nb == n0)
/* 3433 */         return n1; 
/* 3434 */       if (nb == n1) {
/* 3435 */         return n0;
/*      */       }
/* 3437 */       return null;
/*      */     } 
/*      */     
/* 3440 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void markTriInnerOrOuter(Tri tri) {
/* 3449 */     assert this._xminOuter < this._xmaxOuter : "outer box is valid";
/* 3450 */     assert this._yminOuter < this._ymaxOuter : "outer box is valid";
/* 3451 */     double[] po = { 0.0D, 0.0D };
/* 3452 */     double s = tri.centerCircle(po);
/* 3453 */     double r = MathPlus.sqrt(s);
/* 3454 */     double xo = po[0];
/* 3455 */     double yo = po[1];
/* 3456 */     if (xo - r >= this._xminOuter && yo - r >= this._yminOuter && xo + r <= this._xmaxOuter && yo + r <= this._ymaxOuter) {
/*      */ 
/*      */ 
/*      */       
/* 3460 */       tri.setInner();
/* 3461 */       tri.clearOuter();
/*      */     } else {
/* 3463 */       tri.setOuter();
/* 3464 */       tri.clearInner();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fireNodeWillBeAdded(Node node) {
/* 3469 */     this._version++;
/* 3470 */     if (this._nnodeListeners > 0) {
/* 3471 */       Object[] list = this._listeners.getListenerList();
/* 3472 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3473 */         if (list[i] == NodeListener.class)
/* 3474 */           ((NodeListener)list[i + 1]).nodeWillBeAdded(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeAdded(Node node) {
/* 3479 */     this._version++;
/* 3480 */     if (this._nnodeListeners > 0) {
/* 3481 */       Object[] list = this._listeners.getListenerList();
/* 3482 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3483 */         if (list[i] == NodeListener.class)
/* 3484 */           ((NodeListener)list[i + 1]).nodeAdded(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeWillBeRemoved(Node node) {
/* 3489 */     this._version++;
/* 3490 */     if (this._nnodeListeners > 0) {
/* 3491 */       Object[] list = this._listeners.getListenerList();
/* 3492 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3493 */         if (list[i] == NodeListener.class)
/* 3494 */           ((NodeListener)list[i + 1]).nodeWillBeRemoved(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeRemoved(Node node) {
/* 3499 */     this._version++;
/* 3500 */     if (this._nnodeListeners > 0) {
/* 3501 */       Object[] list = this._listeners.getListenerList();
/* 3502 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3503 */         if (list[i] == NodeListener.class)
/* 3504 */           ((NodeListener)list[i + 1]).nodeRemoved(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireTriAdded(Tri tri) {
/* 3509 */     this._version++;
/* 3510 */     if (this._ntriListeners > 0) {
/* 3511 */       Object[] list = this._listeners.getListenerList();
/* 3512 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3513 */         if (list[i] == TriListener.class)
/* 3514 */           ((TriListener)list[i + 1]).triAdded(this, tri); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireTriRemoved(Tri tri) {
/* 3519 */     this._version++;
/* 3520 */     if (this._ntriListeners > 0) {
/* 3521 */       Object[] list = this._listeners.getListenerList();
/* 3522 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 3523 */         if (list[i] == TriListener.class) {
/* 3524 */           ((TriListener)list[i + 1]).triRemoved(this, tri);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validate(Node node) {
/* 3532 */     Check.state((node == node._prev._next), "node==node._prev._next");
/* 3533 */     Check.state((node == node._next._prev), "node==node._next._prev");
/* 3534 */     Tri tri = node.tri();
/* 3535 */     if (this._troot != null) {
/* 3536 */       Check.state((tri != null), "tri!=null");
/* 3537 */       Check.state((node == tri.nodeA() || node == tri.nodeB() || node == tri.nodeC()), "node is one of tri nodes");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validate(Tri tri) {
/* 3548 */     Node na = tri.nodeA();
/* 3549 */     Node nb = tri.nodeB();
/* 3550 */     Node nc = tri.nodeC();
/* 3551 */     validate(na);
/* 3552 */     validate(nb);
/* 3553 */     validate(nc);
/* 3554 */     Tri ta = tri.triA();
/* 3555 */     Tri tb = tri.triB();
/* 3556 */     Tri tc = tri.triC();
/* 3557 */     if (ta != null)
/* 3558 */       Check.state((ta.triNabor(tri.nodeNabor(ta)) == tri), "a nabors ok"); 
/* 3559 */     if (tb != null)
/* 3560 */       Check.state((tb.triNabor(tri.nodeNabor(tb)) == tri), "b nabors ok"); 
/* 3561 */     if (tc != null) {
/* 3562 */       Check.state((tc.triNabor(tri.nodeNabor(tc)) == tri), "c nabors ok");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class EdgeSet
/*      */   {
/*      */     TriMesh.Node a;
/*      */ 
/*      */     
/*      */     TriMesh.Node b;
/*      */ 
/*      */     
/*      */     TriMesh.Node c;
/*      */ 
/*      */     
/*      */     TriMesh.Tri abc;
/*      */ 
/*      */     
/*      */     private static final int MAX_SHIFT = 30;
/*      */ 
/*      */     
/*      */     private static final int MAX_CAPACITY = 1073741824;
/*      */     
/*      */     private TriMesh.Node[] _a;
/*      */     
/*      */     private TriMesh.Node[] _b;
/*      */     
/*      */     private TriMesh.Node[] _c;
/*      */     
/*      */     private TriMesh.Tri[] _abc;
/*      */     
/*      */     private boolean[] _filled;
/*      */     
/*      */     private int _nmax;
/*      */     
/*      */     private int _n;
/*      */     
/*      */     private double _factor;
/*      */     
/*      */     private int _shift;
/*      */     
/*      */     private int _mask;
/*      */     
/*      */     private int _index;
/*      */ 
/*      */     
/*      */     EdgeSet(int capacity, double factor) {
/* 3611 */       if (capacity > 1073741824) capacity = 1073741824; 
/* 3612 */       if (factor <= 0.0D) factor = 1.0E-4D; 
/* 3613 */       if (factor >= 1.0D) factor = 0.9999D; 
/* 3614 */       for (this._nmax = 2, this._shift = 30; this._nmax < capacity; this._nmax *= 2)
/* 3615 */         this._shift--; 
/* 3616 */       this._n = 0;
/* 3617 */       this._factor = factor;
/* 3618 */       this._mask = this._nmax - 1;
/* 3619 */       this._a = new TriMesh.Node[this._nmax];
/* 3620 */       this._b = new TriMesh.Node[this._nmax];
/* 3621 */       this._c = new TriMesh.Node[this._nmax];
/* 3622 */       this._abc = new TriMesh.Tri[this._nmax];
/* 3623 */       this._filled = new boolean[this._nmax];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 3630 */       this._n = 0;
/* 3631 */       for (int i = 0; i < this._nmax; i++) {
/* 3632 */         this._filled[i] = false;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean add(TriMesh.Tri tri, TriMesh.Node node) {
/* 3644 */       if (node == tri._n0)
/* 3645 */         return add(tri._n1, tri._n2, node, tri); 
/* 3646 */       if (node == tri._n1)
/* 3647 */         return add(tri._n2, tri._n0, node, tri); 
/* 3648 */       if (node == tri._n2) {
/* 3649 */         return add(tri._n0, tri._n1, node, tri);
/*      */       }
/* 3651 */       assert false : "node is referenced by tri";
/* 3652 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean addMate(TriMesh.Tri tri, TriMesh.Node node) {
/* 3666 */       TriMesh.Tri triNabor = tri.triNabor(node);
/* 3667 */       TriMesh.Node nodeNabor = (triNabor != null) ? tri.nodeNabor(triNabor) : null;
/* 3668 */       if (node == tri._n0)
/* 3669 */         return add(tri._n2, tri._n1, nodeNabor, triNabor); 
/* 3670 */       if (node == tri._n1)
/* 3671 */         return add(tri._n0, tri._n2, nodeNabor, triNabor); 
/* 3672 */       if (node == tri._n2) {
/* 3673 */         return add(tri._n1, tri._n0, nodeNabor, triNabor);
/*      */       }
/* 3675 */       assert false : "node is referenced by tri";
/* 3676 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean remove() {
/* 3686 */       if (this._n > 0) {
/* 3687 */         int start = this._index;
/* 3688 */         for (; this._index < this._nmax; this._index++) {
/* 3689 */           if (this._filled[this._index]) {
/* 3690 */             setCurrent();
/* 3691 */             remove(this._index);
/* 3692 */             return true;
/*      */           } 
/*      */         } 
/* 3695 */         for (this._index = 0; this._index < start; this._index++) {
/* 3696 */           if (this._filled[this._index]) {
/* 3697 */             setCurrent();
/* 3698 */             remove(this._index);
/* 3699 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/* 3703 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isEmpty() {
/* 3711 */       return (this._n > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean first() {
/* 3720 */       this._index = -1;
/* 3721 */       return next();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean next() {
/* 3730 */       this._index++; for (; this._index < this._nmax; this._index++) {
/* 3731 */         if (this._filled[this._index]) {
/* 3732 */           setCurrent();
/* 3733 */           return true;
/*      */         } 
/*      */       } 
/* 3736 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hash(TriMesh.Node a, TriMesh.Node b) {
/* 3757 */       int key = a._hash ^ b._hash;
/*      */ 
/*      */ 
/*      */       
/* 3761 */       return 1327217885 * key >> this._shift & this._mask;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int indexOfMate(TriMesh.Node a, TriMesh.Node b) {
/* 3769 */       int i = hash(a, b);
/* 3770 */       while (this._filled[i]) {
/* 3771 */         if (a == this._b[i] && b == this._a[i])
/* 3772 */           return i; 
/* 3773 */         i = i - 1 & this._mask;
/*      */       } 
/* 3775 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setCurrent() {
/* 3782 */       this.a = this._a[this._index];
/* 3783 */       this.b = this._b[this._index];
/* 3784 */       this.c = this._c[this._index];
/* 3785 */       this.abc = this._abc[this._index];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean add(TriMesh.Node a, TriMesh.Node b, TriMesh.Node c, TriMesh.Tri abc) {
/* 3795 */       this._index = indexOfMate(a, b);
/* 3796 */       if (this._filled[this._index]) {
/* 3797 */         setCurrent();
/* 3798 */         remove(this._index);
/* 3799 */         return false;
/*      */       } 
/* 3801 */       this._a[this._index] = a;
/* 3802 */       this._b[this._index] = b;
/* 3803 */       this._c[this._index] = c;
/* 3804 */       this._abc[this._index] = abc;
/* 3805 */       this._filled[this._index] = true;
/* 3806 */       this._n++;
/* 3807 */       if (this._n > this._nmax * this._factor && this._nmax < 1073741824)
/* 3808 */         doubleCapacity(); 
/* 3809 */       setCurrent();
/* 3810 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void remove(int i) {
/* 3819 */       this._n--; while (true) {
/*      */         int r;
/* 3821 */         this._filled[i] = false;
/* 3822 */         int j = i;
/*      */         
/*      */         do {
/* 3825 */           i = i - 1 & this._mask;
/* 3826 */           if (!this._filled[i])
/*      */             return; 
/* 3828 */           r = hash(this._a[i], this._b[i]);
/* 3829 */         } while ((i <= r && r < j) || (r < j && j < i) || (j < i && i <= r));
/* 3830 */         this._a[j] = this._a[i];
/* 3831 */         this._b[j] = this._b[i];
/* 3832 */         this._c[j] = this._c[i];
/* 3833 */         this._abc[j] = this._abc[i];
/* 3834 */         this._filled[j] = this._filled[i];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doubleCapacity() {
/* 3843 */       EdgeSet set = new EdgeSet(2 * this._nmax, this._factor);
/* 3844 */       if (this._n > 0)
/* 3845 */         for (int i = 0; i < this._nmax; i++) {
/* 3846 */           if (this._filled[i]) {
/* 3847 */             set.add(this._a[i], this._b[i], this._c[i], this._abc[i]);
/*      */           }
/*      */         }  
/* 3850 */       this._a = set._a;
/* 3851 */       this._b = set._b;
/* 3852 */       this._c = set._c;
/* 3853 */       this._abc = set._abc;
/* 3854 */       this._filled = set._filled;
/* 3855 */       this._nmax = set._nmax;
/* 3856 */       this._n = set._n;
/* 3857 */       this._factor = set._factor;
/* 3858 */       this._shift = set._shift;
/* 3859 */       this._mask = set._mask;
/* 3860 */       this._index = set._index;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class NodeSet
/*      */   {
/*      */     TriMesh.Node a;
/*      */     
/*      */     TriMesh.Node b;
/*      */     
/*      */     TriMesh.Tri nba;
/*      */     
/*      */     private static final int MAX_SHIFT = 30;
/*      */     private static final int MAX_CAPACITY = 1073741824;
/*      */     private TriMesh.Node[] _a;
/*      */     private TriMesh.Node[] _b;
/*      */     private TriMesh.Tri[] _nba;
/*      */     private boolean[] _filled;
/*      */     private int _nmax;
/*      */     private int _n;
/*      */     private double _factor;
/*      */     private int _shift;
/*      */     private int _mask;
/*      */     private int _index;
/*      */     
/*      */     NodeSet(int capacity, double factor) {
/* 3887 */       if (capacity > 1073741824) capacity = 1073741824; 
/* 3888 */       if (factor <= 0.0D) factor = 1.0E-4D; 
/* 3889 */       if (factor >= 1.0D) factor = 0.9999D; 
/* 3890 */       for (this._nmax = 2, this._shift = 30; this._nmax < capacity; this._nmax *= 2)
/* 3891 */         this._shift--; 
/* 3892 */       this._n = 0;
/* 3893 */       this._factor = factor;
/* 3894 */       this._mask = this._nmax - 1;
/* 3895 */       this._a = new TriMesh.Node[this._nmax];
/* 3896 */       this._b = new TriMesh.Node[this._nmax];
/* 3897 */       this._nba = new TriMesh.Tri[this._nmax];
/* 3898 */       this._filled = new boolean[this._nmax];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 3905 */       this._n = 0;
/* 3906 */       for (int i = 0; i < this._nmax; i++) {
/* 3907 */         this._filled[i] = false;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean add(TriMesh.Node a, TriMesh.Node b, TriMesh.Tri nba) {
/* 3917 */       this._index = indexOfNode(a);
/* 3918 */       if (this._filled[this._index]) {
/* 3919 */         setCurrent();
/* 3920 */         remove(this._index);
/* 3921 */         return false;
/*      */       } 
/* 3923 */       this._a[this._index] = a;
/* 3924 */       this._b[this._index] = b;
/* 3925 */       this._nba[this._index] = nba;
/* 3926 */       this._filled[this._index] = true;
/* 3927 */       this._n++;
/* 3928 */       if (this._n > this._nmax * this._factor && this._nmax < 1073741824)
/* 3929 */         doubleCapacity(); 
/* 3930 */       setCurrent();
/* 3931 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hash(TriMesh.Node a) {
/* 3953 */       int key = a._hash;
/*      */ 
/*      */ 
/*      */       
/* 3957 */       return 1327217885 * key >> this._shift & this._mask;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int indexOfNode(TriMesh.Node a) {
/* 3965 */       int i = hash(a);
/* 3966 */       while (this._filled[i]) {
/* 3967 */         if (a == this._a[i])
/* 3968 */           return i; 
/* 3969 */         i = i - 1 & this._mask;
/*      */       } 
/* 3971 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setCurrent() {
/* 3978 */       this.a = this._a[this._index];
/* 3979 */       this.b = this._b[this._index];
/* 3980 */       this.nba = this._nba[this._index];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void remove(int i) {
/* 3988 */       this._n--; while (true) {
/*      */         int r;
/* 3990 */         this._filled[i] = false;
/* 3991 */         int j = i;
/*      */         
/*      */         do {
/* 3994 */           i = i - 1 & this._mask;
/* 3995 */           if (!this._filled[i])
/*      */             return; 
/* 3997 */           r = hash(this._a[i]);
/* 3998 */         } while ((i <= r && r < j) || (r < j && j < i) || (j < i && i <= r));
/* 3999 */         this._a[j] = this._a[i];
/* 4000 */         this._b[j] = this._b[i];
/* 4001 */         this._nba[j] = this._nba[i];
/* 4002 */         this._filled[j] = this._filled[i];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doubleCapacity() {
/* 4011 */       NodeSet set = new NodeSet(2 * this._nmax, this._factor);
/* 4012 */       if (this._n > 0)
/* 4013 */         for (int i = 0; i < this._nmax; i++) {
/* 4014 */           if (this._filled[i]) {
/* 4015 */             set.add(this._a[i], this._b[i], this._nba[i]);
/*      */           }
/*      */         }  
/* 4018 */       this._a = set._a;
/* 4019 */       this._b = set._b;
/* 4020 */       this._nba = set._nba;
/* 4021 */       this._filled = set._filled;
/* 4022 */       this._nmax = set._nmax;
/* 4023 */       this._n = set._n;
/* 4024 */       this._factor = set._factor;
/* 4025 */       this._shift = set._shift;
/* 4026 */       this._mask = set._mask;
/* 4027 */       this._index = set._index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 4036 */     init();
/*      */ 
/*      */     
/* 4039 */     int format = in.readInt();
/* 4040 */     if (format == 1) {
/*      */ 
/*      */       
/* 4043 */       this._version = in.readLong();
/*      */ 
/*      */       
/* 4046 */       int nnode = this._nnode = in.readInt();
/* 4047 */       Node[] nodes = new Node[nnode];
/* 4048 */       for (int inode = 0; inode < nnode; inode++) {
/* 4049 */         Node node = nodes[inode] = (Node)in.readObject();
/* 4050 */         node._x = in.readDouble();
/* 4051 */         node._y = in.readDouble();
/* 4052 */         int nvalue = in.readInt();
/* 4053 */         node._values = new Object[nvalue];
/* 4054 */         for (int ivalue = 0; ivalue < nvalue; ivalue++) {
/* 4055 */           Object value = in.readObject();
/* 4056 */           node._values[ivalue] = value;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 4061 */       int ntri = this._ntri = in.readInt();
/* 4062 */       Tri[] tris = new Tri[ntri];
/* 4063 */       for (int j = 0; j < ntri; j++) {
/* 4064 */         Tri tri = tris[j] = (Tri)in.readObject();
/* 4065 */         tri._quality = -1.0D;
/*      */       } 
/*      */ 
/*      */       
/* 4069 */       this._nroot = (Node)in.readObject();
/* 4070 */       for (int i = 0; i < nnode; i++) {
/* 4071 */         Node node = nodes[i];
/* 4072 */         node._prev = (Node)in.readObject();
/* 4073 */         node._next = (Node)in.readObject();
/* 4074 */         node._tri = (Tri)in.readObject();
/*      */       } 
/*      */ 
/*      */       
/* 4078 */       this._troot = (Tri)in.readObject();
/* 4079 */       for (int itri = 0; itri < ntri; itri++) {
/* 4080 */         Tri tri = tris[itri];
/* 4081 */         tri._n0 = (Node)in.readObject();
/* 4082 */         tri._n1 = (Node)in.readObject();
/* 4083 */         tri._n2 = (Node)in.readObject();
/* 4084 */         tri._t0 = (Tri)in.readObject();
/* 4085 */         tri._t1 = (Tri)in.readObject();
/* 4086 */         tri._t2 = (Tri)in.readObject();
/*      */       } 
/*      */ 
/*      */       
/* 4090 */       this._outerEnabled = in.readBoolean();
/* 4091 */       this._xminOuter = in.readDouble();
/* 4092 */       this._yminOuter = in.readDouble();
/* 4093 */       this._xmaxOuter = in.readDouble();
/* 4094 */       this._ymaxOuter = in.readDouble();
/*      */ 
/*      */       
/* 4097 */       this._nnodeValues = in.readInt();
/* 4098 */       this._lnodeValues = in.readInt();
/* 4099 */       this._nodePropertyMaps = (Map<String, NodePropertyMap>)in.readObject();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 4104 */       throw new InvalidClassException("invalid external format");
/*      */     } 
/*      */ 
/*      */     
/* 4108 */     sampleNodes();
/*      */ 
/*      */     
/*      */     try {
/* 4112 */       validate();
/* 4113 */     } catch (IllegalStateException ise) {
/* 4114 */       throw new IOException(ise.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 4123 */     out.writeInt(1);
/*      */ 
/*      */     
/* 4126 */     out.writeLong(this._version);
/*      */ 
/*      */     
/* 4129 */     int nnode = this._nnode;
/* 4130 */     out.writeInt(nnode);
/* 4131 */     Node[] nodes = new Node[nnode];
/* 4132 */     NodeIterator ni = getNodes();
/* 4133 */     for (int inode = 0; inode < nnode; inode++) {
/* 4134 */       Node node = nodes[inode] = ni.next();
/* 4135 */       out.writeObject(node);
/* 4136 */       out.writeDouble(node._x);
/* 4137 */       out.writeDouble(node._y);
/* 4138 */       int nvalue = node._values.length;
/* 4139 */       out.writeInt(nvalue);
/* 4140 */       for (int ivalue = 0; ivalue < nvalue; ivalue++) {
/* 4141 */         Object value = node._values[ivalue];
/* 4142 */         out.writeObject((value instanceof Serializable) ? value : null);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 4147 */     int ntri = this._ntri;
/* 4148 */     out.writeInt(ntri);
/* 4149 */     Tri[] tris = new Tri[ntri];
/* 4150 */     TriIterator ti = getTris();
/* 4151 */     for (int j = 0; j < ntri; j++) {
/* 4152 */       Tri tri = tris[j] = ti.next();
/* 4153 */       out.writeObject(tri);
/*      */     } 
/*      */ 
/*      */     
/* 4157 */     out.writeObject(this._nroot);
/* 4158 */     for (int i = 0; i < nnode; i++) {
/* 4159 */       Node node = nodes[i];
/* 4160 */       out.writeObject(node._prev);
/* 4161 */       out.writeObject(node._next);
/* 4162 */       out.writeObject(node._tri);
/*      */     } 
/*      */ 
/*      */     
/* 4166 */     out.writeObject(this._troot);
/* 4167 */     for (int itri = 0; itri < ntri; itri++) {
/* 4168 */       Tri tri = tris[itri];
/* 4169 */       out.writeObject(tri._n0);
/* 4170 */       out.writeObject(tri._n1);
/* 4171 */       out.writeObject(tri._n2);
/* 4172 */       out.writeObject(tri._t0);
/* 4173 */       out.writeObject(tri._t1);
/* 4174 */       out.writeObject(tri._t2);
/*      */     } 
/*      */ 
/*      */     
/* 4178 */     out.writeBoolean(this._outerEnabled);
/* 4179 */     out.writeDouble(this._xminOuter);
/* 4180 */     out.writeDouble(this._yminOuter);
/* 4181 */     out.writeDouble(this._xmaxOuter);
/* 4182 */     out.writeDouble(this._ymaxOuter);
/*      */ 
/*      */     
/* 4185 */     out.writeInt(this._nnodeValues);
/* 4186 */     out.writeInt(this._lnodeValues);
/* 4187 */     out.writeObject(this._nodePropertyMaps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sampleNodes() {
/* 4197 */     Random random = new Random();
/* 4198 */     this._sampledNodes.clear();
/* 4199 */     int nsamp = (int)(MathPlus.pow(this._nnode, 0.33D) / 0.45D);
/* 4200 */     Node node = this._nroot;
/* 4201 */     while (this._sampledNodes.size() < nsamp) {
/* 4202 */       int nskip = 1 + random.nextInt(this._nnode / 2);
/* 4203 */       while (--nskip > 0)
/* 4204 */         node = node._next; 
/* 4205 */       this._sampledNodes.add(node);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static interface TriListener extends EventListener {
/*      */     void triAdded(TriMesh param1TriMesh, TriMesh.Tri param1Tri);
/*      */     
/*      */     void triRemoved(TriMesh param1TriMesh, TriMesh.Tri param1Tri);
/*      */   }
/*      */   
/*      */   public static interface NodeListener extends EventListener {
/*      */     void nodeWillBeAdded(TriMesh param1TriMesh, TriMesh.Node param1Node);
/*      */     
/*      */     void nodeAdded(TriMesh param1TriMesh, TriMesh.Node param1Node);
/*      */     
/*      */     void nodeWillBeRemoved(TriMesh param1TriMesh, TriMesh.Node param1Node);
/*      */     
/*      */     void nodeRemoved(TriMesh param1TriMesh, TriMesh.Node param1Node);
/*      */   }
/*      */   
/*      */   public static interface NodePropertyMap extends Serializable {
/*      */     Object get(TriMesh.Node param1Node);
/*      */     
/*      */     void put(TriMesh.Node param1Node, Object param1Object);
/*      */   }
/*      */   
/*      */   public static interface EdgeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriMesh.Edge next();
/*      */   }
/*      */   
/*      */   public static interface TriIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriMesh.Tri next();
/*      */   }
/*      */   
/*      */   public static interface NodeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriMesh.Node next();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/TriMesh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */