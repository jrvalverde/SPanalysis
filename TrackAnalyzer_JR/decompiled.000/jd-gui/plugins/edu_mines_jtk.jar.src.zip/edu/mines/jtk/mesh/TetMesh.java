/*      */ package edu.mines.jtk.mesh;
/*      */ 
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ import java.io.IOException;
/*      */ import java.io.InvalidClassException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javax.swing.event.EventListenerList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TetMesh
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final int NODE_MARK_MAX = 2147483646;
/*      */   private static final int TET_MARK_MAX = 2147483646;
/*      */   private long _version;
/*      */   private int _nnode;
/*      */   private int _ntet;
/*      */   private Node _nroot;
/*      */   private Tet _troot;
/*      */   private HashSet<Node> _sampledNodes;
/*      */   private int _tetMarkRed;
/*      */   private int _tetMarkBlue;
/*      */   private int _nodeMarkRed;
/*      */   private int _nodeMarkBlue;
/*      */   private FaceSet _faceSet;
/*      */   private EdgeSet _edgeSet;
/*      */   private NodeList _nodeList;
/*      */   private Node _nmin;
/*      */   private double _dmin;
/*      */   private TetList _deadTets;
/*      */   private int _nnodeListeners;
/*      */   private int _ntetListeners;
/*      */   private EventListenerList _listeners;
/*      */   private boolean _outerEnabled;
/*      */   private double _xminOuter;
/*      */   private double _yminOuter;
/*      */   private double _zminOuter;
/*      */   private double _xmaxOuter;
/*      */   private double _ymaxOuter;
/*      */   private double _zmaxOuter;
/*      */   private int _nnodeValues;
/*      */   private int _lnodeValues;
/*      */   private Map<String, NodePropertyMap> _nodePropertyMaps;
/*      */   static final boolean DEBUG = false;
/*      */   static final boolean TRACE = false;
/*      */   
/*      */   public static class Node
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     public int index;
/*      */     public Object data;
/*      */     private transient double _x;
/*      */     private transient double _y;
/*      */     private transient double _z;
/*      */     private transient Node _prev;
/*      */     private transient Node _next;
/*      */     private transient TetMesh.Tet _tet;
/*      */     private transient int _mark;
/*      */     private transient int _hash;
/*      */     private transient Object[] _values;
/*      */     
/*      */     public Node(float x, float y, float z) {
/*  102 */       this._prev = null;
/*  103 */       this._next = null;
/*  104 */       this._tet = null;
/*  105 */       this._mark = 0;
/*  106 */       this._hash = System.identityHashCode(this);
/*  107 */       setPosition(x, y, z);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float x() {
/*  115 */       return (float)this._x;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float y() {
/*  123 */       return (float)this._y;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float z() {
/*  131 */       return (float)this._z;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Tet tet() {
/*  139 */       return this._tet;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  143 */       return "(" + x() + "," + y() + "," + z() + ")";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static double perturb(float x, float p) {
/*  159 */       int m = Integer.MAX_VALUE;
/*  160 */       int i = Float.floatToIntBits(p);
/*  161 */       int j = 0;
/*  162 */       for (int k = 0; k < 32; k++, i >>= 1, j <<= 1) {
/*  163 */         j |= i & 0x1;
/*      */       }
/*  165 */       double xp = (x != 0.0F) ? x : 1.4012984643248171E-46D;
/*  166 */       xp *= 1.0D + j / 2.147483647E9D * 0.1D * 1.1920928955078125E-7D;
/*  167 */       assert (float)xp == x;
/*  168 */       return xp;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setPosition(float x, float y, float z) {
/*  175 */       assert this._tet == null;
/*  176 */       this._x = perturb(x, 0.450599F * y + 0.374507F * z);
/*  177 */       this._y = perturb(y, 0.298721F * x + 0.983298F * z);
/*  178 */       this._z = perturb(z, 0.653901F * x + 0.598723F * y);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Tet
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */     
/*      */     public int index;
/*      */ 
/*      */     
/*      */     public Object data;
/*      */ 
/*      */     
/*      */     private static final int INNER_BIT = 1;
/*      */ 
/*      */     
/*      */     private static final int OUTER_BIT = 2;
/*      */     
/*      */     private static final int CENTER_BIT = 4;
/*      */     
/*      */     private transient TetMesh.Node _n0;
/*      */     
/*      */     private transient TetMesh.Node _n1;
/*      */     
/*      */     private transient TetMesh.Node _n2;
/*      */     
/*      */     private transient TetMesh.Node _n3;
/*      */     
/*      */     private transient Tet _t0;
/*      */     
/*      */     private transient Tet _t1;
/*      */     
/*      */     private transient Tet _t2;
/*      */     
/*      */     private transient Tet _t3;
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeA() {
/*  221 */       return this._n0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeB() {
/*  229 */       return this._n1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeC() {
/*  237 */       return this._n2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeD() {
/*  245 */       return this._n3;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tet tetA() {
/*  253 */       return this._t0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tet tetB() {
/*  261 */       return this._t1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tet tetC() {
/*  269 */       return this._t2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tet tetD() {
/*  277 */       return this._t3;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeNearest(float x, float y, float z) {
/*  289 */       double d0 = TetMesh.distanceSquared(this._n0, x, y, z);
/*  290 */       double d1 = TetMesh.distanceSquared(this._n1, x, y, z);
/*  291 */       double d2 = TetMesh.distanceSquared(this._n2, x, y, z);
/*  292 */       double d3 = TetMesh.distanceSquared(this._n3, x, y, z);
/*  293 */       double dmin = d0;
/*  294 */       TetMesh.Node nmin = this._n0;
/*  295 */       if (d1 < dmin) {
/*  296 */         dmin = d1;
/*  297 */         nmin = this._n1;
/*      */       } 
/*  299 */       if (d2 < dmin) {
/*  300 */         dmin = d2;
/*  301 */         nmin = this._n2;
/*      */       } 
/*  303 */       if (d3 < dmin) {
/*  304 */         dmin = d3;
/*  305 */         nmin = this._n3;
/*      */       } 
/*  307 */       return nmin;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Tet tetNabor(TetMesh.Node node) {
/*  315 */       if (node == this._n0) return this._t0; 
/*  316 */       if (node == this._n1) return this._t1; 
/*  317 */       if (node == this._n2) return this._t2; 
/*  318 */       if (node == this._n3) return this._t3; 
/*  319 */       Check.argument(false, "node is referenced by tet");
/*  320 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeNabor(Tet tetNabor) {
/*  329 */       if (tetNabor._t0 == this) return tetNabor._n0; 
/*  330 */       if (tetNabor._t1 == this) return tetNabor._n1; 
/*  331 */       if (tetNabor._t2 == this) return tetNabor._n2; 
/*  332 */       if (tetNabor._t3 == this) return tetNabor._n3; 
/*  333 */       Check.argument(false, "tetNabor is a nabor of tet");
/*  334 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeNabor(TetMesh.Node node) {
/*  343 */       Tet tetNabor = tetNabor(node);
/*  344 */       return (tetNabor != null) ? nodeNabor(tetNabor) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double centerSphere(double[] c) {
/*  353 */       if (hasCenter()) {
/*  354 */         c[0] = this._xc;
/*  355 */         c[1] = this._yc;
/*  356 */         c[2] = this._zc;
/*      */       } else {
/*  358 */         double x0 = this._n0._x;
/*  359 */         double y0 = this._n0._y;
/*  360 */         double z0 = this._n0._z;
/*  361 */         double x1 = this._n1._x;
/*  362 */         double y1 = this._n1._y;
/*  363 */         double z1 = this._n1._z;
/*  364 */         double x2 = this._n2._x;
/*  365 */         double y2 = this._n2._y;
/*  366 */         double z2 = this._n2._z;
/*  367 */         double x3 = this._n3._x;
/*  368 */         double y3 = this._n3._y;
/*  369 */         double z3 = this._n3._z;
/*  370 */         Geometry.centerSphere(x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3, c);
/*  371 */         setCenter(c[0], c[1], c[2]);
/*      */       } 
/*  373 */       double dx = this._xc - this._n3._x;
/*  374 */       double dy = this._yc - this._n3._y;
/*  375 */       double dz = this._zc - this._n3._z;
/*  376 */       return dx * dx + dy * dy + dz * dz;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] centerSphere() {
/*  384 */       double[] c = new double[3];
/*  385 */       centerSphere(c);
/*  386 */       return c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double quality() {
/*  397 */       if (this._quality < 0.0D)
/*  398 */         this._quality = quality(this._n0, this._n1, this._n2, this._n3); 
/*  399 */       return this._quality;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TetMesh.Node node) {
/*  408 */       return (node == this._n0 || node == this._n1 || node == this._n2 || node == this._n3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TetMesh.Node na, TetMesh.Node nb) {
/*  418 */       if (na == this._n0)
/*  419 */         return (nb == this._n1 || nb == this._n2 || nb == this._n3); 
/*  420 */       if (na == this._n1)
/*  421 */         return (nb == this._n0 || nb == this._n2 || nb == this._n3); 
/*  422 */       if (na == this._n2)
/*  423 */         return (nb == this._n0 || nb == this._n1 || nb == this._n3); 
/*  424 */       if (na == this._n3) {
/*  425 */         return (nb == this._n0 || nb == this._n1 || nb == this._n2);
/*      */       }
/*  427 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TetMesh.Node na, TetMesh.Node nb, TetMesh.Node nc) {
/*  439 */       if (na == this._n0) {
/*  440 */         if (nb == this._n1)
/*  441 */           return (nc == this._n2 || nc == this._n3); 
/*  442 */         if (nb == this._n2)
/*  443 */           return (nc == this._n1 || nc == this._n3); 
/*  444 */         if (nb == this._n3) {
/*  445 */           return (nc == this._n1 || nc == this._n2);
/*      */         }
/*  447 */         return false;
/*      */       } 
/*  449 */       if (na == this._n1) {
/*  450 */         if (nb == this._n0)
/*  451 */           return (nc == this._n2 || nc == this._n3); 
/*  452 */         if (nb == this._n2)
/*  453 */           return (nc == this._n0 || nc == this._n3); 
/*  454 */         if (nb == this._n3) {
/*  455 */           return (nc == this._n0 || nc == this._n2);
/*      */         }
/*  457 */         return false;
/*      */       } 
/*  459 */       if (na == this._n2) {
/*  460 */         if (nb == this._n0)
/*  461 */           return (nc == this._n1 || nc == this._n3); 
/*  462 */         if (nb == this._n1)
/*  463 */           return (nc == this._n0 || nc == this._n3); 
/*  464 */         if (nb == this._n3) {
/*  465 */           return (nc == this._n0 || nc == this._n1);
/*      */         }
/*  467 */         return false;
/*      */       } 
/*  469 */       if (na == this._n3) {
/*  470 */         if (nb == this._n0)
/*  471 */           return (nc == this._n1 || nc == this._n2); 
/*  472 */         if (nb == this._n1)
/*  473 */           return (nc == this._n0 || nc == this._n2); 
/*  474 */         if (nb == this._n2) {
/*  475 */           return (nc == this._n0 || nc == this._n1);
/*      */         }
/*  477 */         return false;
/*      */       } 
/*      */       
/*  480 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TetMesh.Node na, TetMesh.Node nb, TetMesh.Node nc, TetMesh.Node nd) {
/*  493 */       if (na == this._n0) {
/*  494 */         if (nb == this._n1) {
/*  495 */           if (nc == this._n2)
/*  496 */             return (nd == this._n3); 
/*  497 */           if (nc == this._n3) {
/*  498 */             return (nd == this._n2);
/*      */           }
/*  500 */           return false;
/*      */         } 
/*  502 */         if (nb == this._n2) {
/*  503 */           if (nc == this._n1)
/*  504 */             return (nd == this._n3); 
/*  505 */           if (nc == this._n3) {
/*  506 */             return (nd == this._n1);
/*      */           }
/*  508 */           return false;
/*      */         } 
/*  510 */         if (nb == this._n3) {
/*  511 */           if (nc == this._n1)
/*  512 */             return (nd == this._n2); 
/*  513 */           if (nc == this._n2) {
/*  514 */             return (nd == this._n1);
/*      */           }
/*  516 */           return false;
/*      */         } 
/*      */         
/*  519 */         return false;
/*      */       } 
/*  521 */       if (na == this._n1) {
/*  522 */         if (nb == this._n0) {
/*  523 */           if (nc == this._n2)
/*  524 */             return (nd == this._n3); 
/*  525 */           if (nc == this._n3) {
/*  526 */             return (nd == this._n2);
/*      */           }
/*  528 */           return false;
/*      */         } 
/*  530 */         if (nb == this._n2) {
/*  531 */           if (nc == this._n0)
/*  532 */             return (nd == this._n3); 
/*  533 */           if (nc == this._n3) {
/*  534 */             return (nd == this._n0);
/*      */           }
/*  536 */           return false;
/*      */         } 
/*  538 */         if (nb == this._n3) {
/*  539 */           if (nc == this._n0)
/*  540 */             return (nd == this._n2); 
/*  541 */           if (nc == this._n2) {
/*  542 */             return (nd == this._n0);
/*      */           }
/*  544 */           return false;
/*      */         } 
/*      */         
/*  547 */         return false;
/*      */       } 
/*  549 */       if (na == this._n2) {
/*  550 */         if (nb == this._n0) {
/*  551 */           if (nc == this._n1)
/*  552 */             return (nd == this._n3); 
/*  553 */           if (nc == this._n3) {
/*  554 */             return (nd == this._n1);
/*      */           }
/*  556 */           return false;
/*      */         } 
/*  558 */         if (nb == this._n1) {
/*  559 */           if (nc == this._n0)
/*  560 */             return (nd == this._n3); 
/*  561 */           if (nc == this._n3) {
/*  562 */             return (nd == this._n0);
/*      */           }
/*  564 */           return false;
/*      */         } 
/*  566 */         if (nb == this._n3) {
/*  567 */           if (nc == this._n0)
/*  568 */             return (nd == this._n1); 
/*  569 */           if (nc == this._n1) {
/*  570 */             return (nd == this._n0);
/*      */           }
/*  572 */           return false;
/*      */         } 
/*      */         
/*  575 */         return false;
/*      */       } 
/*  577 */       if (na == this._n3) {
/*  578 */         if (nb == this._n0) {
/*  579 */           if (nc == this._n1)
/*  580 */             return (nd == this._n2); 
/*  581 */           if (nc == this._n2) {
/*  582 */             return (nd == this._n1);
/*      */           }
/*  584 */           return false;
/*      */         } 
/*  586 */         if (nb == this._n1) {
/*  587 */           if (nc == this._n0)
/*  588 */             return (nd == this._n2); 
/*  589 */           if (nc == this._n2) {
/*  590 */             return (nd == this._n0);
/*      */           }
/*  592 */           return false;
/*      */         } 
/*  594 */         if (nb == this._n2) {
/*  595 */           if (nc == this._n0)
/*  596 */             return (nd == this._n1); 
/*  597 */           if (nc == this._n1) {
/*  598 */             return (nd == this._n0);
/*      */           }
/*  600 */           return false;
/*      */         } 
/*      */         
/*  603 */         return false;
/*      */       } 
/*      */       
/*  606 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  640 */     private transient int _mark = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  645 */     private transient int _bits = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  650 */     private transient double _quality = -1.0D;
/*      */ 
/*      */     
/*      */     private transient double _xc;
/*      */ 
/*      */     
/*      */     private transient double _yc;
/*      */ 
/*      */     
/*      */     private transient double _zc;
/*      */ 
/*      */ 
/*      */     
/*      */     private Tet(TetMesh.Node n0, TetMesh.Node n1, TetMesh.Node n2, TetMesh.Node n3) {
/*  664 */       init(n0, n1, n2, n3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void init(TetMesh.Node n0, TetMesh.Node n1, TetMesh.Node n2, TetMesh.Node n3) {
/*  687 */       this._n0 = n0;
/*  688 */       this._n1 = n1;
/*  689 */       this._n2 = n2;
/*  690 */       this._n3 = n3;
/*  691 */       this._n0._tet = this;
/*  692 */       this._n1._tet = this;
/*  693 */       this._n2._tet = this;
/*  694 */       this._n3._tet = this;
/*  695 */       this._t0 = null;
/*  696 */       this._t1 = null;
/*  697 */       this._t2 = null;
/*  698 */       this._t3 = null;
/*  699 */       this._mark = 0;
/*  700 */       this._bits = 0;
/*  701 */       this._quality = -1.0D;
/*      */     }
/*      */     
/*      */     private final void setInner() {
/*  705 */       this._bits |= 0x1;
/*      */     }
/*      */     
/*      */     private final void clearInner() {
/*  709 */       this._bits &= 0xFFFFFFFE;
/*      */     }
/*      */     
/*      */     private final boolean isInner() {
/*  713 */       return ((this._bits & 0x1) != 0);
/*      */     }
/*      */     
/*      */     private final void setOuter() {
/*  717 */       this._bits |= 0x2;
/*      */     }
/*      */     
/*      */     private final void clearOuter() {
/*  721 */       this._bits &= 0xFFFFFFFD;
/*      */     }
/*      */     
/*      */     private final boolean isOuter() {
/*  725 */       return ((this._bits & 0x2) != 0);
/*      */     }
/*      */     
/*      */     private final void setCenter(double xc, double yc, double zc) {
/*  729 */       this._xc = xc;
/*  730 */       this._yc = yc;
/*  731 */       this._zc = zc;
/*  732 */       this._bits |= 0x4;
/*      */     }
/*      */     
/*      */     private final boolean hasCenter() {
/*  736 */       return ((this._bits & 0x4) != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean intersectsPlane(double a, double b, double c, double d) {
/*  744 */       int nn = 0;
/*  745 */       int np = 0;
/*  746 */       double s0 = a * this._n0._x + b * this._n0._y + c * this._n0._z + d;
/*  747 */       if (s0 < 0.0D) nn++; 
/*  748 */       if (s0 > 0.0D) np++; 
/*  749 */       double s1 = a * this._n1._x + b * this._n1._y + c * this._n1._z + d;
/*  750 */       if (s1 < 0.0D) nn++; 
/*  751 */       if (s1 > 0.0D) np++; 
/*  752 */       double s2 = a * this._n2._x + b * this._n2._y + c * this._n2._z + d;
/*  753 */       if (s2 < 0.0D) nn++; 
/*  754 */       if (s2 > 0.0D) np++; 
/*  755 */       double s3 = a * this._n3._x + b * this._n3._y + c * this._n3._z + d;
/*  756 */       if (s3 < 0.0D) nn++; 
/*  757 */       if (s3 > 0.0D) np++; 
/*  758 */       return (nn < 4 && np < 4);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static double quality(TetMesh.Node na, TetMesh.Node nb, TetMesh.Node nc, TetMesh.Node nd) {
/*  768 */       return qualityVolumeOverLongestEdge(na, nb, nc, nd);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static double qualityVolumeOverLongestEdge(TetMesh.Node na, TetMesh.Node nb, TetMesh.Node nc, TetMesh.Node nd) {
/*  779 */       double xa = na._x;
/*  780 */       double ya = na._y;
/*  781 */       double za = na._z;
/*  782 */       double xb = nb._x;
/*  783 */       double yb = nb._y;
/*  784 */       double zb = nb._z;
/*  785 */       double xc = nc._x;
/*  786 */       double yc = nc._y;
/*  787 */       double zc = nc._z;
/*  788 */       double xd = nd._x;
/*  789 */       double yd = nd._y;
/*  790 */       double zd = nd._z;
/*      */ 
/*      */       
/*  793 */       double xab = xa - xb;
/*  794 */       double yab = ya - yb;
/*  795 */       double zab = za - zb;
/*  796 */       double xac = xa - xc;
/*  797 */       double yac = ya - yc;
/*  798 */       double zac = za - zc;
/*  799 */       double xbc = xb - xc;
/*  800 */       double ybc = yb - yc;
/*  801 */       double zbc = zb - zc;
/*  802 */       double xad = xa - xd;
/*  803 */       double yad = ya - yd;
/*  804 */       double zad = za - zd;
/*  805 */       double xbd = xb - xd;
/*  806 */       double ybd = yb - yd;
/*  807 */       double zbd = zb - zd;
/*  808 */       double xcd = xc - xd;
/*  809 */       double ycd = yc - yd;
/*  810 */       double zcd = zc - zd;
/*      */ 
/*      */       
/*  813 */       double det = xad * (ybd * zcd - zbd * ycd) + xbd * (ycd * zad - zcd * yad) + xcd * (yad * zbd - zad * ybd);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  818 */       double dab = xab * xab + yab * yab + zab * zab;
/*  819 */       double dac = xac * xac + yac * yac + zac * zac;
/*  820 */       double dbc = xbc * xbc + ybc * ybc + zbc * zbc;
/*  821 */       double dad = xad * xad + yad * yad + zad * zad;
/*  822 */       double dbd = xbd * xbd + ybd * ybd + zbd * zbd;
/*  823 */       double dcd = xcd * xcd + ycd * ycd + zcd * zcd;
/*      */ 
/*      */       
/*  826 */       double dmx = dab;
/*  827 */       if (dac > dmx) dmx = dac; 
/*  828 */       if (dbc > dmx) dmx = dbc; 
/*  829 */       if (dad > dmx) dmx = dad; 
/*  830 */       if (dbd > dmx) dmx = dbd; 
/*  831 */       if (dcd > dmx) dmx = dcd; 
/*  832 */       dmx = MathPlus.sqrt(dmx);
/*      */ 
/*      */       
/*  835 */       double quality = QUALITY_VOL_LONGEST_EDGE_FACTOR * det / dmx * dmx * dmx;
/*  836 */       if (quality < 0.0D) quality = -quality; 
/*  837 */       if (quality > 1.0D) quality = 1.0D; 
/*  838 */       return quality;
/*      */     }
/*  840 */     private static double QUALITY_VOL_LONGEST_EDGE_FACTOR = 2.0D / MathPlus.sqrt(2.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Edge
/*      */   {
/*      */     private TetMesh.Node _a;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Node _b;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Tet _tet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Edge(TetMesh.Node a, TetMesh.Node b) {
/*  958 */       this(a, b, (TetMesh.Tet)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Edge(TetMesh.Node a, TetMesh.Node b, TetMesh.Tet abcd) {
/*  970 */       Check.argument((abcd == null || abcd.references(a, b)), "tet references nodes");
/*      */ 
/*      */       
/*  973 */       this._a = a;
/*  974 */       this._b = b;
/*  975 */       this._tet = abcd;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Node nodeA() {
/*  983 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Node nodeB() {
/*  991 */       return this._b;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Tet tet() {
/*  999 */       return this._tet;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Edge mate() {
/* 1007 */       return new Edge(this._b, this._a, this._tet);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double midpoint(double[] c) {
/* 1016 */       double xa = this._a._x;
/* 1017 */       double ya = this._a._y;
/* 1018 */       double za = this._a._z;
/* 1019 */       double xb = this._b._x;
/* 1020 */       double yb = this._b._y;
/* 1021 */       double zb = this._b._z;
/* 1022 */       c[0] = 0.5D * (xa + xb);
/* 1023 */       c[1] = 0.5D * (ya + yb);
/* 1024 */       c[2] = 0.5D * (za + zb);
/* 1025 */       double dx = c[0] - xb;
/* 1026 */       double dy = c[1] - yb;
/* 1027 */       double dz = c[2] - zb;
/* 1028 */       return dx * dx + dy * dy + dz * dz;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] midpoint() {
/* 1036 */       double[] c = new double[3];
/* 1037 */       midpoint(c);
/* 1038 */       return c;
/*      */     }
/*      */     
/*      */     public boolean equals(Object object) {
/* 1042 */       if (object == this)
/* 1043 */         return true; 
/* 1044 */       if (object != null && object.getClass() == getClass()) {
/* 1045 */         Edge edge = (Edge)object;
/* 1046 */         return (this._a == edge._a && this._b == edge._b);
/*      */       } 
/* 1048 */       return false;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 1052 */       return this._a._hash ^ this._b._hash;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Edge(TetMesh.Tet abcd, TetMesh.Node a, TetMesh.Node b) {
/* 1059 */       this._a = a;
/* 1060 */       this._b = b;
/* 1061 */       this._tet = abcd;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Face
/*      */   {
/*      */     private TetMesh.Node _a;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Node _b;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Node _c;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Tet _tetLeft;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Tet _tetRight;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Node _nodeLeft;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Node _nodeRight;
/*      */ 
/*      */ 
/*      */     
/*      */     public Face(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c) {
/* 1099 */       this(a, b, c, (TetMesh.Tet)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Face(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c, TetMesh.Tet abcd) {
/* 1112 */       TetMesh.Node d = (abcd != null) ? TetMesh.otherNode(abcd, a, b, c) : null;
/* 1113 */       Check.argument((abcd == null || d != null), "tet references nodes");
/* 1114 */       this._a = a;
/* 1115 */       this._b = b;
/* 1116 */       this._c = c;
/* 1117 */       if (d != null) {
/* 1118 */         if (TetMesh.nodesInOrder(abcd, a, b, c, d)) {
/* 1119 */           this._tetLeft = abcd;
/* 1120 */           this._nodeLeft = d;
/* 1121 */           this._tetRight = abcd.tetNabor(d);
/* 1122 */           this._nodeRight = (this._tetRight != null) ? abcd.nodeNabor(this._tetRight) : null;
/*      */         } else {
/* 1124 */           this._tetRight = abcd;
/* 1125 */           this._nodeRight = d;
/* 1126 */           this._tetLeft = abcd.tetNabor(d);
/* 1127 */           this._nodeLeft = (this._tetLeft != null) ? abcd.nodeNabor(this._tetLeft) : null;
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeA() {
/* 1137 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeB() {
/* 1145 */       return this._b;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node nodeC() {
/* 1153 */       return this._c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Tet tetLeft() {
/* 1161 */       return this._tetLeft;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Tet tetRight() {
/* 1169 */       return this._tetRight;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Node nodeLeft() {
/* 1177 */       return this._nodeLeft;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Node nodeRight() {
/* 1185 */       return this._nodeRight;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Face mate() {
/* 1193 */       return new Face(this._b, this._a, this._c, this._tetRight, this._nodeRight, this._tetLeft, this._nodeLeft);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVisibleFromPoint(double x, double y, double z) {
/* 1206 */       return (Geometry.leftOfPlane(this._a._x, this._a._y, this._a._z, this._b._x, this._b._y, this._b._z, this._c._x, this._c._y, this._c._z, x, y, z) < 0.0D);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double centerCircle(double[] c) {
/* 1219 */       double xa = this._a._x;
/* 1220 */       double ya = this._a._y;
/* 1221 */       double za = this._a._z;
/* 1222 */       double xb = this._b._x;
/* 1223 */       double yb = this._b._y;
/* 1224 */       double zb = this._b._z;
/* 1225 */       double xc = this._c._x;
/* 1226 */       double yc = this._c._y;
/* 1227 */       double zc = this._c._z;
/* 1228 */       Geometry.centerCircle3D(xa, ya, za, xb, yb, zb, xc, yc, zc, c);
/* 1229 */       double dx = c[0] - xc;
/* 1230 */       double dy = c[1] - yc;
/* 1231 */       double dz = c[2] - zc;
/* 1232 */       return dx * dx + dy * dy + dz * dz;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] centerCircle() {
/* 1240 */       double[] c = new double[3];
/* 1241 */       centerCircle(c);
/* 1242 */       return c;
/*      */     }
/*      */     
/*      */     public boolean equals(Object object) {
/* 1246 */       if (object == this)
/* 1247 */         return true; 
/* 1248 */       if (object != null && object.getClass() == getClass()) {
/* 1249 */         Face face = (Face)object;
/* 1250 */         return ((this._a == face._a && this._b == face._b && this._c == face._c) || (this._a == face._b && this._b == face._c && this._c == face._a) || (this._a == face._c && this._b == face._a && this._c == face._b));
/*      */       } 
/*      */ 
/*      */       
/* 1254 */       return false;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 1258 */       return this._a._hash ^ this._b._hash ^ this._c._hash;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Face(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c, TetMesh.Tet tetLeft, TetMesh.Node nodeLeft, TetMesh.Tet tetRight, TetMesh.Node nodeRight) {
/* 1270 */       this._a = a;
/* 1271 */       this._b = b;
/* 1272 */       this._c = c;
/* 1273 */       this._tetLeft = tetLeft;
/* 1274 */       this._tetRight = tetRight;
/* 1275 */       this._nodeLeft = nodeLeft;
/* 1276 */       this._nodeRight = nodeRight;
/*      */     }
/*      */     
/*      */     private Face(TetMesh.Tet tetLeft, TetMesh.Node nodeLeft) {
/* 1280 */       initLeft(tetLeft, nodeLeft);
/* 1281 */       this._tetLeft = tetLeft;
/* 1282 */       this._nodeLeft = nodeLeft;
/* 1283 */       this._tetRight = tetLeft.tetNabor(nodeLeft);
/* 1284 */       this._nodeRight = (this._tetRight != null) ? this._tetLeft.nodeNabor(this._tetRight) : null;
/*      */     }
/*      */     
/*      */     private Face(TetMesh.Tet tetLeft, TetMesh.Node nodeLeft, TetMesh.Tet tetRight, TetMesh.Node nodeRight) {
/* 1288 */       if (tetLeft != null) {
/* 1289 */         initLeft(tetLeft, nodeLeft);
/* 1290 */       } else if (tetRight != null) {
/* 1291 */         initRight(tetRight, nodeRight);
/*      */       } else {
/* 1293 */         assert false : "either tetLeft or tetRight is not null";
/*      */       } 
/* 1295 */       this._tetLeft = tetLeft;
/* 1296 */       this._tetRight = tetRight;
/* 1297 */       this._nodeLeft = nodeLeft;
/* 1298 */       this._nodeRight = nodeRight;
/*      */     }
/*      */     
/*      */     private void initLeft(TetMesh.Tet tetLeft, TetMesh.Node nodeLeft) {
/* 1302 */       if (nodeLeft == tetLeft._n0) {
/* 1303 */         this._a = tetLeft._n1;
/* 1304 */         this._b = tetLeft._n3;
/* 1305 */         this._c = tetLeft._n2;
/* 1306 */       } else if (nodeLeft == tetLeft._n1) {
/* 1307 */         this._a = tetLeft._n2;
/* 1308 */         this._b = tetLeft._n3;
/* 1309 */         this._c = tetLeft._n0;
/* 1310 */       } else if (nodeLeft == tetLeft._n2) {
/* 1311 */         this._a = tetLeft._n3;
/* 1312 */         this._b = tetLeft._n1;
/* 1313 */         this._c = tetLeft._n0;
/* 1314 */       } else if (nodeLeft == tetLeft._n3) {
/* 1315 */         this._a = tetLeft._n0;
/* 1316 */         this._b = tetLeft._n1;
/* 1317 */         this._c = tetLeft._n2;
/*      */       } else {
/* 1319 */         assert false : "nodeLeft referenced by tetLeft";
/*      */       } 
/*      */     }
/*      */     
/*      */     private void initRight(TetMesh.Tet tetRight, TetMesh.Node nodeRight) {
/* 1324 */       if (nodeRight == tetRight._n0) {
/* 1325 */         this._a = tetRight._n1;
/* 1326 */         this._b = tetRight._n2;
/* 1327 */         this._c = tetRight._n3;
/* 1328 */       } else if (nodeRight == tetRight._n1) {
/* 1329 */         this._a = tetRight._n2;
/* 1330 */         this._b = tetRight._n0;
/* 1331 */         this._c = tetRight._n3;
/* 1332 */       } else if (nodeRight == tetRight._n2) {
/* 1333 */         this._a = tetRight._n3;
/* 1334 */         this._b = tetRight._n0;
/* 1335 */         this._c = tetRight._n1;
/* 1336 */       } else if (nodeRight == tetRight._n3) {
/* 1337 */         this._a = tetRight._n0;
/* 1338 */         this._b = tetRight._n2;
/* 1339 */         this._c = tetRight._n1;
/*      */       } else {
/* 1341 */         assert false : "nodeRight referenced by tetRight";
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NodeList
/*      */   {
/*      */     public final void add(TetMesh.Node node) {
/* 1370 */       if (this._n == this._a.length) {
/* 1371 */         TetMesh.Node[] t = new TetMesh.Node[this._a.length * 2];
/* 1372 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1373 */         this._a = t;
/*      */       } 
/* 1375 */       this._a[this._n++] = node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node remove(int index) {
/* 1384 */       TetMesh.Node node = this._a[index];
/* 1385 */       this._n--;
/* 1386 */       if (this._n > index)
/* 1387 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/* 1388 */       return node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node[] trim() {
/* 1396 */       if (this._n < this._a.length) {
/* 1397 */         TetMesh.Node[] t = new TetMesh.Node[this._n];
/* 1398 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1399 */         this._a = t;
/*      */       } 
/* 1401 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1408 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nnode() {
/* 1416 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node[] nodes() {
/* 1424 */       return this._a;
/*      */     }
/* 1426 */     private int _n = 0;
/* 1427 */     private TetMesh.Node[] _a = new TetMesh.Node[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TetList
/*      */   {
/*      */     public final void add(TetMesh.Tet tet) {
/* 1440 */       if (this._n == this._a.length) {
/* 1441 */         TetMesh.Tet[] t = new TetMesh.Tet[this._a.length * 2];
/* 1442 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1443 */         this._a = t;
/*      */       } 
/* 1445 */       this._a[this._n++] = tet;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Tet remove(int index) {
/* 1454 */       TetMesh.Tet tet = this._a[index];
/* 1455 */       this._n--;
/* 1456 */       if (this._n > index)
/* 1457 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/* 1458 */       return tet;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Tet[] trim() {
/* 1466 */       if (this._n < this._a.length) {
/* 1467 */         TetMesh.Tet[] t = new TetMesh.Tet[this._n];
/* 1468 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1469 */         this._a = t;
/*      */       } 
/* 1471 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1478 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int ntet() {
/* 1486 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Tet[] tets() {
/* 1494 */       return this._a;
/*      */     }
/* 1496 */     private int _n = 0;
/* 1497 */     private TetMesh.Tet[] _a = new TetMesh.Tet[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EdgeList
/*      */   {
/*      */     public final void add(TetMesh.Edge edge) {
/* 1510 */       if (this._n == this._a.length) {
/* 1511 */         TetMesh.Edge[] t = new TetMesh.Edge[this._a.length * 2];
/* 1512 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1513 */         this._a = t;
/*      */       } 
/* 1515 */       this._a[this._n++] = edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Edge remove(int index) {
/* 1524 */       TetMesh.Edge edge = this._a[index];
/* 1525 */       this._n--;
/* 1526 */       if (this._n > index)
/* 1527 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/* 1528 */       return edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Edge[] trim() {
/* 1536 */       if (this._n < this._a.length) {
/* 1537 */         TetMesh.Edge[] t = new TetMesh.Edge[this._n];
/* 1538 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1539 */         this._a = t;
/*      */       } 
/* 1541 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1548 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nedge() {
/* 1556 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Edge[] edges() {
/* 1564 */       return this._a;
/*      */     }
/* 1566 */     private int _n = 0;
/* 1567 */     private TetMesh.Edge[] _a = new TetMesh.Edge[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FaceList
/*      */   {
/*      */     public final void add(TetMesh.Face face) {
/* 1580 */       if (this._n == this._a.length) {
/* 1581 */         TetMesh.Face[] t = new TetMesh.Face[this._a.length * 2];
/* 1582 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1583 */         this._a = t;
/*      */       } 
/* 1585 */       this._a[this._n++] = face;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Face remove(int index) {
/* 1594 */       TetMesh.Face face = this._a[index];
/* 1595 */       this._n--;
/* 1596 */       if (this._n > index)
/* 1597 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/* 1598 */       return face;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Face[] trim() {
/* 1606 */       if (this._n < this._a.length) {
/* 1607 */         TetMesh.Face[] t = new TetMesh.Face[this._n];
/* 1608 */         System.arraycopy(this._a, 0, t, 0, this._n);
/* 1609 */         this._a = t;
/*      */       } 
/* 1611 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1618 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nface() {
/* 1626 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Face[] faces() {
/* 1634 */       return this._a;
/*      */     }
/* 1636 */     private int _n = 0;
/* 1637 */     private TetMesh.Face[] _a = new TetMesh.Face[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NodeStepList
/*      */   {
/*      */     public final void add(TetMesh.Node node, int step) {
/* 1652 */       if (this._n == this._a.length) {
/* 1653 */         TetMesh.Node[] s = new TetMesh.Node[this._a.length * 2];
/* 1654 */         int[] t = new int[this._a.length * 2];
/* 1655 */         System.arraycopy(this._a, 0, s, 0, this._n);
/* 1656 */         System.arraycopy(this._b, 0, t, 0, this._n);
/* 1657 */         this._a = s;
/* 1658 */         this._b = t;
/*      */       } 
/* 1660 */       this._a[this._n] = node;
/* 1661 */       this._b[this._n] = step;
/* 1662 */       this._n++;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void trim() {
/* 1669 */       if (this._n < this._a.length) {
/* 1670 */         TetMesh.Node[] s = new TetMesh.Node[this._n];
/* 1671 */         int[] t = new int[this._n];
/* 1672 */         System.arraycopy(this._a, 0, s, 0, this._n);
/* 1673 */         System.arraycopy(this._b, 0, t, 0, this._n);
/* 1674 */         this._a = s;
/* 1675 */         this._b = t;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/* 1683 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nnode() {
/* 1691 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TetMesh.Node[] nodes() {
/* 1699 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int[] steps() {
/* 1707 */       return this._b;
/*      */     }
/* 1709 */     private int _n = 0;
/* 1710 */     private TetMesh.Node[] _a = new TetMesh.Node[64];
/* 1711 */     private int[] _b = new int[64];
/*      */   }
/*      */ 
/*      */   
/*      */   public static class PointLocation
/*      */   {
/*      */     private TetMesh.Node _node;
/*      */     
/*      */     private TetMesh.Edge _edge;
/*      */     private TetMesh.Face _face;
/*      */     private TetMesh.Tet _tet;
/*      */     private boolean _inside;
/*      */     
/*      */     public boolean isOnNode() {
/* 1725 */       return (this._node != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOnEdge() {
/* 1733 */       return (this._edge != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOnFace() {
/* 1741 */       return (this._face != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInside() {
/* 1749 */       return this._inside;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOutside() {
/* 1757 */       return !this._inside;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Node node() {
/* 1765 */       return this._node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Edge edge() {
/* 1773 */       return this._edge;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Face face() {
/* 1781 */       return this._face;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TetMesh.Tet tet() {
/* 1792 */       return this._tet;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private PointLocation(TetMesh.Tet tet) {
/* 1802 */       this._tet = tet;
/* 1803 */       this._inside = true;
/*      */     }
/*      */     private PointLocation(TetMesh.Tet tet, boolean inside) {
/* 1806 */       this._tet = tet;
/* 1807 */       this._inside = inside;
/*      */     }
/*      */     private PointLocation(TetMesh.Node node) {
/* 1810 */       this._tet = node._tet;
/* 1811 */       this._node = node;
/* 1812 */       this._inside = true;
/*      */     }
/*      */     private PointLocation(TetMesh.Face face) {
/* 1815 */       this._tet = face._tetLeft;
/* 1816 */       this._face = face;
/* 1817 */       this._inside = true;
/*      */     }
/*      */     private PointLocation(TetMesh.Edge edge) {
/* 1820 */       this._tet = edge._tet;
/* 1821 */       this._edge = edge;
/* 1822 */       this._inside = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countNodes() {
/*      */     return this._nnode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countTets() {
/*      */     return this._ntet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getVersion() {
/*      */     return this._version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean addNode(Node node) {
/*      */     PointLocation pl = locatePoint(node._x, node._y, node._z);
/*      */     if (pl.isOnNode()) {
/*      */       return false;
/*      */     }
/*      */     fireNodeWillBeAdded(node);
/*      */     if (this._nroot == null) {
/*      */       this._nroot = node;
/*      */       this._nroot._prev = this._nroot._next = this._nroot;
/*      */     } else {
/*      */       node._next = this._nroot;
/*      */       node._prev = this._nroot._prev;
/*      */       this._nroot._prev._next = node;
/*      */       this._nroot._prev = node;
/*      */       this._nroot = node;
/*      */     } 
/*      */     this._nnode++;
/*      */     updatePropertyValues(node);
/*      */     double factor = 0.5D * this._sampledNodes.size();
/*      */     if (factor * factor * factor * factor < this._nnode) {
/*      */       this._sampledNodes.add(node);
/*      */     }
/*      */     if (pl.isOutside() && this._nnode <= 4) {
/*      */       if (this._nnode == 4) {
/*      */         createFirstTet();
/*      */       }
/*      */     } else {
/*      */       clearTetMarks();
/*      */       this._faceSet.clear();
/*      */       if (pl.isInside()) {
/*      */         getDelaunayFacesInside(node, pl.tet());
/*      */       } else {
/*      */         getDelaunayFacesOutside(node, pl.tet());
/*      */       } 
/*      */       this._edgeSet.clear();
/*      */       boolean more;
/*      */       for (more = this._faceSet.first(); more; more = this._faceSet.next()) {
/*      */         Node a = this._faceSet.a;
/*      */         Node b = this._faceSet.b;
/*      */         Node c = this._faceSet.c;
/*      */         Node d = this._faceSet.d;
/*      */         Tet abcd = this._faceSet.abcd;
/*      */         Tet nabc = makeTet(node, a, b, c);
/*      */         linkTets(nabc, node, abcd, d);
/*      */         if (!this._edgeSet.add(a, b, c, nabc)) {
/*      */           linkTets(this._edgeSet.nabc, this._edgeSet.c, nabc, c);
/*      */         }
/*      */         if (!this._edgeSet.add(b, c, a, nabc)) {
/*      */           linkTets(this._edgeSet.nabc, this._edgeSet.c, nabc, a);
/*      */         }
/*      */         if (!this._edgeSet.add(c, a, b, nabc)) {
/*      */           linkTets(this._edgeSet.nabc, this._edgeSet.c, nabc, b);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     fireNodeAdded(node);
/*      */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean removeNode(Node node) {
/*      */     Tet tet = node._tet;
/*      */     if (tet == null) {
/*      */       return false;
/*      */     }
/*      */     fireNodeWillBeRemoved(node);
/*      */     unlinkNode(node);
/*      */     if (this._nnode < 4) {
/*      */       if (this._nnode == 3) {
/*      */         Node n0 = this._nroot;
/*      */         Node n1 = n0._next;
/*      */         Node n2 = n1._next;
/*      */         n0._tet = null;
/*      */         n1._tet = null;
/*      */         n2._tet = null;
/*      */         killTet(this._troot);
/*      */         this._troot = null;
/*      */       } 
/*      */     } else {
/*      */       this._faceSet.clear();
/*      */       this._nodeList.clear();
/*      */       clearTetMarks();
/*      */       clearNodeMarks();
/*      */       getDelaunayFacesOpposite(node, tet);
/*      */       int nnode = this._nodeList.nnode();
/*      */       Node[] nodes = this._nodeList.nodes();
/*      */       boolean more;
/*      */       for (more = this._faceSet.remove(); more; more = this._faceSet.remove()) {
/*      */         Node a = this._faceSet.a;
/*      */         Node b = this._faceSet.b;
/*      */         Node c = this._faceSet.c;
/*      */         Node d = this._faceSet.d;
/*      */         Tet abcd = this._faceSet.abcd;
/*      */         Node n = null;
/*      */         for (int inode = 0; inode < nnode; inode++) {
/*      */           Node m = nodes[inode];
/*      */           if (m != a && m != b && m != c && !leftOfPlane(a, b, c, m) && (n == null || inSphere(n, a, b, c, m))) {
/*      */             n = m;
/*      */           }
/*      */         } 
/*      */         if (n != null) {
/*      */           Tet nabc = makeTet(n, a, b, c);
/*      */           linkTets(nabc, n, abcd, d);
/*      */           if (!this._faceSet.add(nabc, a)) {
/*      */             linkTets(this._faceSet.abcd, this._faceSet.d, nabc, a);
/*      */           }
/*      */           if (!this._faceSet.add(nabc, b)) {
/*      */             linkTets(this._faceSet.abcd, this._faceSet.d, nabc, b);
/*      */           }
/*      */           if (!this._faceSet.add(nabc, c)) {
/*      */             linkTets(this._faceSet.abcd, this._faceSet.d, nabc, c);
/*      */           }
/*      */         } else {
/*      */           linkTets(abcd, d, null, null);
/*      */           a._tet = abcd;
/*      */           b._tet = abcd;
/*      */           c._tet = abcd;
/*      */           this._troot = abcd;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     fireNodeRemoved(node);
/*      */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean moveNode(Node node, float x, float y, float z) {
/*      */     if (x != node.x() || y != node.y() || z != node.z()) {
/*      */       Node nodeNearest = findNodeNearest(x, y, z);
/*      */       if (node == nodeNearest || x != nodeNearest.x() || y != nodeNearest.y() || z != nodeNearest.z()) {
/*      */         boolean nodeInMesh = removeNode(node);
/*      */         node.setPosition(x, y, z);
/*      */         if (nodeInMesh) {
/*      */           boolean addedNode = addNode(node);
/*      */           assert addedNode;
/*      */         } 
/*      */         return true;
/*      */       } 
/*      */     } 
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node findNodeNearest(float x, float y, float z) {
/*      */     return findNodeNearest(x, y, z);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Edge findEdge(Node na, Node nb) {
/*      */     Tet tet = findTet(na, nb);
/*      */     if (tet != null) {
/*      */       return edgeOfTet(tet, na, nb);
/*      */     }
/*      */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Face findFace(Node na, Node nb, Node nc) {
/*      */     Tet tet = findTet(na, nb, nc);
/*      */     if (tet != null) {
/*      */       return faceOfTet(tet, na, nb, nc);
/*      */     }
/*      */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Tet findTet(Node node) {
/*      */     return node._tet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet findTet(Node na, Node nb) {
/*      */     Tet tet = findTet(na);
/*      */     if (tet != null) {
/*      */       clearTetMarks();
/*      */       tet = findTet(tet, na, nb);
/*      */     } 
/*      */     return tet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet findTet(Node na, Node nb, Node nc) {
/*      */     Tet tet = findTet(na, nb);
/*      */     if (tet != null) {
/*      */       clearTetMarks();
/*      */       tet = findTet(tet, na, nb, nc);
/*      */     } 
/*      */     return tet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet findTet(Node na, Node nb, Node nc, Node nd) {
/*      */     Tet tet = findTet(na, nb, nc);
/*      */     if (tet != null) {
/*      */       clearTetMarks();
/*      */       tet = findTet(tet, na, nb, nc, nd);
/*      */     } 
/*      */     return tet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PointLocation locatePoint(float x, float y, float z) {
/*      */     return locatePoint(x, y, z);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeIterator getNodes() {
/*      */     return new NodeIterator()
/*      */       {
/*      */         public boolean hasNext() {
/*      */           return (this._nnext != null);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TetMesh.Node next() {
/*      */           if (this._nnext == null) {
/*      */             throw new NoSuchElementException();
/*      */           }
/*      */           TetMesh.Node node = this._nnext;
/*      */           this._nnext = node._next;
/*      */           if (this._nnext == this._nroot) {
/*      */             this._nnext = null;
/*      */           }
/*      */           return node;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private TetMesh.Node _nroot = TetMesh.this._nroot;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private TetMesh.Node _nnext = this._nroot;
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized TetIterator getTets() {
/*      */     return new TetIterator()
/*      */       {
/*      */         private Iterator<TetMesh.Tet> _i;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final boolean hasNext() {
/*      */           return this._i.hasNext();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final TetMesh.Tet next() {
/*      */           return this._i.next();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized EdgeIterator getEdges() {
/*      */     return new EdgeIterator()
/*      */       {
/*      */         private Iterator _i;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final boolean hasNext() {
/*      */           return this._i.hasNext();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final TetMesh.Edge next() {
/*      */           return this._i.next();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized TetIterator getTetsInPlane(final double a, final double b, final double c, final double d) {
/*      */     return new TetIterator()
/*      */       {
/*      */         private TetMesh.Tet _tnext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private ArrayList<TetMesh.Tet> _tets;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final boolean hasNext() {
/*      */           return (this._tnext != null);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final TetMesh.Tet next() {
/*      */           if (this._tnext == null) {
/*      */             throw new NoSuchElementException();
/*      */           }
/*      */           TetMesh.Tet tet = this._tnext;
/*      */           addTet(tet._t0);
/*      */           addTet(tet._t1);
/*      */           addTet(tet._t2);
/*      */           addTet(tet._t3);
/*      */           int ntet = this._tets.size();
/*      */           if (ntet == 0) {
/*      */             this._tnext = null;
/*      */           } else {
/*      */             this._tnext = this._tets.remove(ntet - 1);
/*      */           } 
/*      */           return tet;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final void addTet(TetMesh.Tet tet) {
/*      */           if (tet != null && !TetMesh.this.isMarked(tet)) {
/*      */             TetMesh.this.mark(tet);
/*      */             if (tet.intersectsPlane(a, b, c, d)) {
/*      */               this._tets.add(tet);
/*      */             }
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeIterator getNodesNearestPlane(final double a, final double b, final double c, final double d) {
/*      */     return new NodeIterator()
/*      */       {
/*      */         public final boolean hasNext() {
/*      */           return this._iterator.hasNext();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final TetMesh.Node next() {
/*      */           return this._iterator.next();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private Iterator _iterator = null;
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Tet findTetInPlane(double a, double b, double c, double d) {
/*      */     Node node = findNodeNearestPlane(a, b, c, d);
/*      */     Tet[] tet = getTetNabors(node);
/*      */     for (int i = 0; i < tet.length; i++) {
/*      */       if (tet[i].intersectsPlane(a, b, c, d)) {
/*      */         return tet[i];
/*      */       }
/*      */     } 
/*      */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized FaceIterator getFacesOnHull() {
/*      */     clearTetMarks();
/*      */     Face face = getFaceOnHull(this._troot);
/*      */     final HashSet<Face> faces = new HashSet<Face>(128);
/*      */     getFacesOnHull(face, faces);
/*      */     return new FaceIterator()
/*      */       {
/*      */         private Iterator<TetMesh.Face> i = faces.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final boolean hasNext() {
/*      */           return this.i.hasNext();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public final TetMesh.Face next() {
/*      */           return this.i.next();
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node[] getNodeNabors(Node node) {
/*      */     NodeList nabors = new NodeList();
/*      */     getNodeNabors(node, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getNodeNabors(Node node, NodeList nabors) {
/*      */     Tet tet = node._tet;
/*      */     if (tet == null) {
/*      */       return;
/*      */     }
/*      */     clearNodeMarks();
/*      */     clearTetMarks();
/*      */     getNodeNabors(node, tet, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeStepList getNodeNabors(Node node, int stepMax) {
/*      */     Check.argument((stepMax <= 256), "stepMax <= 256");
/*      */     clearNodeMarks();
/*      */     mark(node);
/*      */     NodeStepList list = new NodeStepList();
/*      */     for (int step = 1, nnabor1 = 0; step <= stepMax; step++) {
/*      */       if (step == 1) {
/*      */         getNodeNabors(node, step, list);
/*      */       } else {
/*      */         int nnabor2 = list.nnode();
/*      */         Node[] naborNodes = list.nodes();
/*      */         for (int inabor = nnabor1; inabor < nnabor2; inabor++) {
/*      */           node = naborNodes[inabor];
/*      */           getNodeNabors(node, step, list);
/*      */         } 
/*      */         nnabor1 = nnabor2;
/*      */       } 
/*      */     } 
/*      */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet[] getTetNabors(Node node) {
/*      */     TetList nabors = new TetList();
/*      */     getTetNabors(node, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getTetNabors(Node node, TetList nabors) {
/*      */     clearTetMarks();
/*      */     getTetNabors(node, node._tet, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet[] getTetNabors(Edge edge) {
/*      */     TetList nabors = new TetList();
/*      */     getTetNabors(edge, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getTetNabors(Edge edge, TetList nabors) {
/*      */     Node na = edge.nodeA();
/*      */     Node nb = edge.nodeB();
/*      */     Tet tet = edge.tet();
/*      */     if (tet == null) {
/*      */       tet = findTet(na, nb);
/*      */     }
/*      */     if (tet == null) {
/*      */       return;
/*      */     }
/*      */     clearTetMarks();
/*      */     getTetNabors(na, nb, tet, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Tet[] getTetNabors(Face face) {
/*      */     TetList nabors = new TetList();
/*      */     getTetNabors(face, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getTetNabors(Face face, TetList nabors) {
/*      */     Tet tetLeft = face.tetLeft();
/*      */     Tet tetRight = face.tetRight();
/*      */     if (tetLeft == null && tetRight == null) {
/*      */       Node na = face.nodeA();
/*      */       Node nb = face.nodeB();
/*      */       Node nc = face.nodeC();
/*      */       face = findFace(na, nb, nc);
/*      */       tetLeft = face.tetLeft();
/*      */       tetRight = face.tetRight();
/*      */     } 
/*      */     if (tetLeft != null) {
/*      */       nabors.add(tetLeft);
/*      */     }
/*      */     if (tetRight != null) {
/*      */       nabors.add(tetRight);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Edge[] getEdgeNabors(Node node) {
/*      */     EdgeList nabors = new EdgeList();
/*      */     getEdgeNabors(node, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getEdgeNabors(Node node, EdgeList nabors) {
/*      */     Tet[] tets = getTetNabors(node);
/*      */     int ntet = tets.length;
/*      */     clearNodeMarks();
/*      */     for (int itet = 0; itet < ntet; itet++) {
/*      */       Tet tet = tets[itet];
/*      */       Node n0 = tet._n0;
/*      */       Node n1 = tet._n1;
/*      */       Node n2 = tet._n2;
/*      */       Node n3 = tet._n3;
/*      */       if (node == n0) {
/*      */         if (!isMarked(n1)) {
/*      */           mark(n1);
/*      */           nabors.add(new Edge(tet, n1, node));
/*      */         } 
/*      */         if (!isMarked(n2)) {
/*      */           mark(n2);
/*      */           nabors.add(new Edge(tet, n2, node));
/*      */         } 
/*      */         if (!isMarked(n3)) {
/*      */           mark(n3);
/*      */           nabors.add(new Edge(tet, n3, node));
/*      */         } 
/*      */       } else if (node == n1) {
/*      */         if (!isMarked(n0)) {
/*      */           mark(n0);
/*      */           nabors.add(new Edge(tet, n0, node));
/*      */         } 
/*      */         if (!isMarked(n2)) {
/*      */           mark(n2);
/*      */           nabors.add(new Edge(tet, n2, node));
/*      */         } 
/*      */         if (!isMarked(n3)) {
/*      */           mark(n3);
/*      */           nabors.add(new Edge(tet, n3, node));
/*      */         } 
/*      */       } else if (node == n2) {
/*      */         if (!isMarked(n0)) {
/*      */           mark(n0);
/*      */           nabors.add(new Edge(tet, n0, node));
/*      */         } 
/*      */         if (!isMarked(n1)) {
/*      */           mark(n1);
/*      */           nabors.add(new Edge(tet, n1, node));
/*      */         } 
/*      */         if (!isMarked(n3)) {
/*      */           mark(n3);
/*      */           nabors.add(new Edge(tet, n3, node));
/*      */         } 
/*      */       } else if (node == n3) {
/*      */         if (!isMarked(n0)) {
/*      */           mark(n0);
/*      */           nabors.add(new Edge(tet, n0, node));
/*      */         } 
/*      */         if (!isMarked(n1)) {
/*      */           mark(n1);
/*      */           nabors.add(new Edge(tet, n1, node));
/*      */         } 
/*      */         if (!isMarked(n2)) {
/*      */           mark(n2);
/*      */           nabors.add(new Edge(tet, n2, node));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Face[] getFaceNabors(Edge edge) {
/*      */     FaceList nabors = new FaceList();
/*      */     getFaceNabors(edge, nabors);
/*      */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getFaceNabors(Edge edge, FaceList nabors) {
/*      */     Node ea = edge.nodeA();
/*      */     Node eb = edge.nodeB();
/*      */     Tet tet = edge.tet();
/*      */     if (tet == null) {
/*      */       tet = findTet(ea, eb);
/*      */     }
/*      */     if (tet == null) {
/*      */       return;
/*      */     }
/*      */     Node ta = tet.nodeA();
/*      */     Node tb = tet.nodeB();
/*      */     Node tc = tet.nodeC();
/*      */     Node td = tet.nodeD();
/*      */     Face face = null;
/*      */     if ((ea == ta && eb == tb) || (ea == tb && eb == tc) || (ea == tc && eb == ta)) {
/*      */       face = new Face(ta, tb, tc, tet);
/*      */     } else if ((ea == tb && eb == td) || (ea == td && eb == tc) || (ea == tc && eb == tb)) {
/*      */       face = new Face(tb, td, tc, tet);
/*      */     } else if ((ea == tc && eb == td) || (ea == td && eb == ta) || (ea == ta && eb == tc)) {
/*      */       face = new Face(tc, td, ta, tet);
/*      */     } else if ((ea == td && eb == tb) || (ea == tb && eb == ta) || (ea == ta && eb == td)) {
/*      */       face = new Face(td, tb, ta, tet);
/*      */     } else {
/*      */       assert false : "tet references edge";
/*      */     } 
/*      */     Face firstFace = face;
/*      */     do {
/*      */       nabors.add(face);
/*      */       Node fa = face.nodeA();
/*      */       Node fb = face.nodeB();
/*      */       Node fc = face.nodeC();
/*      */       Node node = null;
/*      */       if (ea == fa && eb == fb) {
/*      */         node = fc;
/*      */       } else if (ea == fb && eb == fc) {
/*      */         node = fa;
/*      */       } else if (ea == fc && eb == fa) {
/*      */         node = fb;
/*      */       } else {
/*      */         assert false : "edge is aligned with face";
/*      */       } 
/*      */       tet = face.tetRight();
/*      */       if (tet == null) {
/*      */         tet = face.tetLeft();
/*      */         Node nodeBack = face.nodeLeft();
/*      */         Tet tetBack = tet.tetNabor(node);
/*      */         while (tetBack != null) {
/*      */           node = nodeBack;
/*      */           nodeBack = tet.nodeNabor(tetBack);
/*      */           tet = tetBack;
/*      */           tetBack = tet.tetNabor(node);
/*      */         } 
/*      */         face = new Face(null, null, tet, node);
/*      */       } else {
/*      */         face = new Face(tet, node);
/*      */       } 
/*      */     } while (!face.equals(firstFace));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setOuterBox(float xmin, float ymin, float zmin, float xmax, float ymax, float zmax) {
/*      */     Check.argument((xmin < xmax), "outer box is valid");
/*      */     Check.argument((ymin < ymax), "outer box is valid");
/*      */     Check.argument((zmin < zmax), "outer box is valid");
/*      */     if (xmin != this._xminOuter || xmax != this._xmaxOuter || ymin != this._yminOuter || ymax != this._ymaxOuter || zmin != this._zminOuter || zmax != this._zmaxOuter) {
/*      */       this._xminOuter = xmin;
/*      */       this._yminOuter = ymin;
/*      */       this._zminOuter = zmin;
/*      */       this._xmaxOuter = xmax;
/*      */       this._ymaxOuter = ymax;
/*      */       this._zmaxOuter = zmax;
/*      */       TetIterator ti = getTets();
/*      */       while (ti.hasNext()) {
/*      */         Tet tet = ti.next();
/*      */         tet.clearInner();
/*      */         tet.clearOuter();
/*      */       } 
/*      */     } 
/*      */     this._version++;
/*      */     this._outerEnabled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableOuterBox() {
/*      */     this._version++;
/*      */     this._outerEnabled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void disableOuterBox() {
/*      */     this._version++;
/*      */     this._outerEnabled = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Node node) {
/*      */     Tet tet = node.tet();
/*      */     if (tet == null || isInner(tet)) {
/*      */       return true;
/*      */     }
/*      */     Tet[] tets = getTetNabors(node);
/*      */     int ntet = tets.length;
/*      */     for (int itet = 0; itet < ntet; itet++) {
/*      */       if (isInner(tets[itet])) {
/*      */         return true;
/*      */       }
/*      */     } 
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Node node) {
/*      */     return !isInner(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Tet tet) {
/*      */     if (!this._outerEnabled) {
/*      */       return true;
/*      */     }
/*      */     if (!tet.isInner() && !tet.isOuter()) {
/*      */       markTetInnerOrOuter(tet);
/*      */     }
/*      */     return tet.isInner();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Tet tet) {
/*      */     return !isInner(tet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Edge edge) {
/*      */     Tet tet = edge.tet();
/*      */     if (tet == null) {
/*      */       tet = findTet(edge.nodeA(), edge.nodeB());
/*      */     }
/*      */     if (tet == null) {
/*      */       return false;
/*      */     }
/*      */     if (tet.isInner()) {
/*      */       return true;
/*      */     }
/*      */     Tet[] tets = getTetNabors(edge);
/*      */     int ntet = tets.length;
/*      */     for (int itet = 0; itet < ntet; itet++) {
/*      */       if (isInner(tets[itet])) {
/*      */         return true;
/*      */       }
/*      */     } 
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Edge edge) {
/*      */     return !isInner(edge);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInner(Face face) {
/*      */     Tet tetLeft = face.tetLeft();
/*      */     if (tetLeft != null && isInner(tetLeft)) {
/*      */       return true;
/*      */     }
/*      */     Tet tetRight = face.tetRight();
/*      */     if (tetRight != null && isInner(tetRight)) {
/*      */       return true;
/*      */     }
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOuter(Face face) {
/*      */     return !isInner(face);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mark(Node node) {
/*      */     node._mark = this._nodeMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markRed(Node node) {
/*      */     node._mark = this._nodeMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markBlue(Node node) {
/*      */     node._mark = this._nodeMarkBlue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unmark(Node node) {
/*      */     node._mark = this._nodeMarkRed - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarked(Node node) {
/*      */     return (node._mark == this._nodeMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedRed(Node node) {
/*      */     return (node._mark == this._nodeMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedBlue(Node node) {
/*      */     return (node._mark == this._nodeMarkBlue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearNodeMarks() {
/*      */     if (this._nodeMarkRed == 2147483646) {
/*      */       Node node = this._nroot;
/*      */       while (true) {
/*      */         node._mark = 0;
/*      */         node = node._next;
/*      */         if (node == this._nroot) {
/*      */           this._nodeMarkRed = 0;
/*      */           this._nodeMarkBlue = 0;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     this._nodeMarkRed++;
/*      */     this._nodeMarkBlue--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mark(Tet tet) {
/*      */     tet._mark = this._tetMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markRed(Tet tet) {
/*      */     tet._mark = this._tetMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markBlue(Tet tet) {
/*      */     tet._mark = this._tetMarkBlue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unmark(Tet tet) {
/*      */     tet._mark = this._tetMarkRed - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarked(Tet tet) {
/*      */     return (tet._mark == this._tetMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedRed(Tet tet) {
/*      */     return (tet._mark == this._tetMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMarkedBlue(Tet tet) {
/*      */     return (tet._mark == this._tetMarkBlue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearTetMarks() {
/*      */     if (this._tetMarkRed == 2147483646) {
/*      */       this._tetMarkRed++;
/*      */       this._tetMarkBlue--;
/*      */       markAllTets(this._troot);
/*      */       zeroTetMarks(this._troot);
/*      */       this._tetMarkRed = 0;
/*      */       this._tetMarkBlue = 0;
/*      */     } 
/*      */     this._tetMarkRed++;
/*      */     this._tetMarkBlue--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodePropertyMap getNodePropertyMap(String name) {
/*      */     NodePropertyMap map = this._nodePropertyMaps.get(name);
/*      */     if (map == null) {
/*      */       if (this._nnodeValues == this._lnodeValues) {
/*      */         if (this._lnodeValues == 0) {
/*      */           this._lnodeValues = 4;
/*      */         } else {
/*      */           this._lnodeValues *= 2;
/*      */         } 
/*      */         NodeIterator ni = getNodes();
/*      */         while (ni.hasNext()) {
/*      */           Node node = ni.next();
/*      */           Object[] valuesOld = node._values;
/*      */           Object[] valuesNew = new Object[this._lnodeValues];
/*      */           for (int i = 0; i < this._nnodeValues; i++) {
/*      */             valuesNew[i] = valuesOld[i];
/*      */           }
/*      */           node._values = valuesNew;
/*      */         } 
/*      */       } 
/*      */       int index = this._nnodeValues++;
/*      */       map = new NodePropertyMapInternal(index);
/*      */       this._nodePropertyMaps.put(name, map);
/*      */     } 
/*      */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean hasNodePropertyMap(String name) {
/*      */     return this._nodePropertyMaps.containsKey(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String[] getNodePropertyMapNames() {
/*      */     Set<String> nameSet = this._nodePropertyMaps.keySet();
/*      */     String[] names = new String[nameSet.size()];
/*      */     return nameSet.<String>toArray(names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addNodeListener(NodeListener nl) {
/*      */     this._listeners.add(NodeListener.class, nl);
/*      */     this._nnodeListeners++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeNodeListener(NodeListener nl) {
/*      */     this._listeners.remove(NodeListener.class, nl);
/*      */     this._nnodeListeners--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addTetListener(TetListener tl) {
/*      */     this._listeners.add(TetListener.class, tl);
/*      */     this._ntetListeners++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeTetListener(TetListener tl) {
/*      */     this._listeners.remove(TetListener.class, tl);
/*      */     this._ntetListeners--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void validate() {
/*      */     int nnode = 0;
/*      */     NodeIterator ni = getNodes();
/*      */     while (ni.hasNext()) {
/*      */       nnode++;
/*      */       Node node = ni.next();
/*      */       validate(node);
/*      */     } 
/*      */     Check.state((nnode == this._nnode), "nnode==_nnode");
/*      */     int ntet = 0;
/*      */     TetIterator ti = getTets();
/*      */     while (ti.hasNext()) {
/*      */       ntet++;
/*      */       Tet tet = ti.next();
/*      */       validate(tet);
/*      */     } 
/*      */     Check.state((ntet == this._ntet), "ntet==_ntet");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*      */     this._version = 0L;
/*      */     this._nnode = 0;
/*      */     this._ntet = 0;
/*      */     this._nroot = null;
/*      */     this._troot = null;
/*      */     this._sampledNodes = new HashSet<Node>(256);
/*      */     this._tetMarkRed = 0;
/*      */     this._tetMarkBlue = 0;
/*      */     this._nodeMarkRed = 0;
/*      */     this._nodeMarkBlue = 0;
/*      */     this._faceSet = new FaceSet(256, 0.25D);
/*      */     this._edgeSet = new EdgeSet(256, 0.25D);
/*      */     this._nodeList = new NodeList();
/*      */     this._nmin = null;
/*      */     this._dmin = 0.0D;
/*      */     this._deadTets = new TetList();
/*      */     this._nnodeListeners = 0;
/*      */     this._ntetListeners = 0;
/*      */     this._listeners = new EventListenerList();
/*      */     this._outerEnabled = false;
/*      */     this._xminOuter = 0.0D;
/*      */     this._yminOuter = 0.0D;
/*      */     this._zminOuter = 0.0D;
/*      */     this._xmaxOuter = 0.0D;
/*      */     this._ymaxOuter = 0.0D;
/*      */     this._zmaxOuter = 0.0D;
/*      */     this._nnodeValues = 0;
/*      */     this._lnodeValues = 0;
/*      */     this._nodePropertyMaps = new HashMap<String, NodePropertyMap>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TetMesh() {
/* 3485 */     this._nroot = null;
/* 3486 */     this._troot = null;
/*      */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NodePropertyMapInternal
/*      */     implements NodePropertyMap
/*      */   {
/*      */     private int _index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object get(TetMesh.Node node) {
/* 3517 */       Object[] values = node._values;
/* 3518 */       return values[this._index];
/*      */     }
/*      */     public void put(TetMesh.Node node, Object value) {
/* 3521 */       Object[] values = node._values;
/* 3522 */       values[this._index] = value;
/*      */     }
/*      */     NodePropertyMapInternal(int index) {
/* 3525 */       this._index = index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void updatePropertyValues(Node node) {
/* 3534 */     if (this._lnodeValues == 0) {
/* 3535 */       node._values = null;
/* 3536 */     } else if (node._values == null) {
/* 3537 */       node._values = new Object[this._lnodeValues];
/* 3538 */     } else if (node._values.length != this._lnodeValues) {
/* 3539 */       Object[] valuesOld = node._values;
/* 3540 */       Object[] valuesNew = new Object[this._lnodeValues];
/* 3541 */       int n = MathPlus.min(valuesOld.length, valuesNew.length);
/* 3542 */       for (int i = 0; i < n; i++)
/* 3543 */         valuesNew[i] = valuesOld[i]; 
/* 3544 */       node._values = valuesNew;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TetIterator getTetsInternal() {
/* 3577 */     return new TetIterator() {
/*      */         public final boolean hasNext() {
/* 3579 */           return !this._stack.isEmpty();
/*      */         } private ArrayList<TetMesh.Tet> _stack;
/*      */         public final TetMesh.Tet next() {
/* 3582 */           int ntet = this._stack.size();
/* 3583 */           if (ntet == 0)
/* 3584 */             throw new NoSuchElementException(); 
/* 3585 */           TetMesh.Tet tet = this._stack.remove(ntet - 1);
/* 3586 */           stackTet(tet._t0);
/* 3587 */           stackTet(tet._t1);
/* 3588 */           stackTet(tet._t2);
/* 3589 */           stackTet(tet._t3);
/* 3590 */           return tet;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final void stackTet(TetMesh.Tet tet) {
/* 3599 */           if (tet != null && !TetMesh.this.isMarked(tet)) {
/* 3600 */             TetMesh.this.mark(tet);
/* 3601 */             this._stack.add(tet);
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Tet makeTet(Node n0, Node n1, Node n2, Node n3) {
/* 3614 */     this._ntet++;
/* 3615 */     int ndead = this._deadTets.ntet();
/* 3616 */     if (ndead == 0) {
/* 3617 */       this._troot = new Tet(n0, n1, n2, n3);
/*      */     } else {
/* 3619 */       this._troot = this._deadTets.remove(ndead - 1);
/* 3620 */       this._troot.init(n0, n1, n2, n3);
/*      */     } 
/* 3622 */     if (this._ntetListeners > 0)
/* 3623 */       fireTetAdded(this._troot); 
/* 3624 */     return this._troot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void killTet(Tet tet) {
/* 3635 */     this._ntet--;
/* 3636 */     fireTetRemoved(tet);
/* 3637 */     int ndead = this._deadTets.ntet();
/* 3638 */     if (ndead < 256) {
/* 3639 */       this._deadTets.add(tet);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unlinkNode(Node node) {
/* 3649 */     this._nroot = node._next;
/* 3650 */     this._nmin = node._next;
/* 3651 */     if (this._nroot == node) {
/* 3652 */       this._nroot = null;
/* 3653 */       this._nmin = null;
/*      */     } 
/* 3655 */     node._prev._next = node._next;
/* 3656 */     node._next._prev = node._prev;
/* 3657 */     node._prev = null;
/* 3658 */     node._next = null;
/* 3659 */     node._tet = null;
/* 3660 */     this._sampledNodes.remove(node);
/* 3661 */     this._nnode--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double distanceSquared(Node node, double x, double y, double z) {
/* 3683 */     double dx = x - node._x;
/* 3684 */     double dy = y - node._y;
/* 3685 */     double dz = z - node._z;
/* 3686 */     return dx * dx + dy * dy + dz * dz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double distanceToPlaneSquared(Node node, double a, double b, double c, double d) {
/* 3696 */     double dp = a * node._x + b * node._y + c * node._z + d;
/* 3697 */     return dp * dp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean leftOfPlane(Node a, Node b, Node c, Node n) {
/* 3705 */     return (Geometry.leftOfPlane(a._x, a._y, a._z, b._x, b._y, b._z, c._x, c._y, c._z, n._x, n._y, n._z) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean leftOfPlane(Node a, Node b, Node c, double x, double y, double z) {
/* 3719 */     return (Geometry.leftOfPlane(a._x, a._y, a._z, b._x, b._y, b._z, c._x, c._y, c._z, x, y, z) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean inSphere(Node a, Node b, Node c, Node d, Node n) {
/* 3733 */     return (Geometry.inSphere(a._x, a._y, a._z, b._x, b._y, b._z, c._x, c._y, c._z, d._x, d._y, d._z, n._x, n._y, n._z) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean inSphere(Node a, Node b, Node c, Node d, double x, double y, double z) {
/* 3749 */     return (Geometry.inSphere(a._x, a._y, a._z, b._x, b._y, b._z, c._x, c._y, c._z, d._x, d._y, d._z, x, y, z) > 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void createFirstTet() {
/* 3761 */     Check.state((this._nnode == 4), "exactly four nodes available for first tet");
/* 3762 */     Node n0 = this._nroot;
/* 3763 */     Node n1 = n0._next;
/* 3764 */     Node n2 = n1._next;
/* 3765 */     Node n3 = n2._next;
/* 3766 */     double orient = Geometry.leftOfPlane(n0._x, n0._y, n0._z, n1._x, n1._y, n1._z, n2._x, n2._y, n2._z, n3._x, n3._y, n3._z);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3771 */     if (orient == 0.0D) {
/* 3772 */       trace("orient=" + orient);
/* 3773 */       trace("n0=(" + n0._x + "," + n0._y + "," + n0._z + ")");
/* 3774 */       trace("n1=(" + n1._x + "," + n1._y + "," + n1._z + ")");
/* 3775 */       trace("n2=(" + n2._x + "," + n2._y + "," + n2._z + ")");
/* 3776 */       trace("n3=(" + n3._x + "," + n3._y + "," + n3._z + ")");
/*      */     } 
/* 3778 */     Check.state((orient != 0.0D), "four nodes for first tet are not co-planar");
/* 3779 */     if (orient > 0.0D) {
/* 3780 */       makeTet(n0, n1, n2, n3);
/*      */     } else {
/* 3782 */       makeTet(n0, n2, n1, n3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getNodeNabors(Node node, Tet tet, NodeList nabors) {
/* 3793 */     mark(tet);
/* 3794 */     Node n0 = tet._n0;
/* 3795 */     Node n1 = tet._n1;
/* 3796 */     Node n2 = tet._n2;
/* 3797 */     Node n3 = tet._n3;
/* 3798 */     Tet t0 = tet._t0;
/* 3799 */     Tet t1 = tet._t1;
/* 3800 */     Tet t2 = tet._t2;
/* 3801 */     Tet t3 = tet._t3;
/* 3802 */     if (node == n0) {
/* 3803 */       if (!isMarked(n1)) {
/* 3804 */         mark(n1);
/* 3805 */         nabors.add(n1);
/*      */       } 
/* 3807 */       if (!isMarked(n2)) {
/* 3808 */         mark(n2);
/* 3809 */         nabors.add(n2);
/*      */       } 
/* 3811 */       if (!isMarked(n3)) {
/* 3812 */         mark(n3);
/* 3813 */         nabors.add(n3);
/*      */       } 
/* 3815 */       if (t1 != null && !isMarked(t1))
/* 3816 */         getNodeNabors(node, t1, nabors); 
/* 3817 */       if (t2 != null && !isMarked(t2))
/* 3818 */         getNodeNabors(node, t2, nabors); 
/* 3819 */       if (t3 != null && !isMarked(t3))
/* 3820 */         getNodeNabors(node, t3, nabors); 
/* 3821 */     } else if (node == n1) {
/* 3822 */       if (!isMarked(n3)) {
/* 3823 */         mark(n3);
/* 3824 */         nabors.add(n3);
/*      */       } 
/* 3826 */       if (!isMarked(n2)) {
/* 3827 */         mark(n2);
/* 3828 */         nabors.add(n2);
/*      */       } 
/* 3830 */       if (!isMarked(n0)) {
/* 3831 */         mark(n0);
/* 3832 */         nabors.add(n0);
/*      */       } 
/* 3834 */       if (t3 != null && !isMarked(t3))
/* 3835 */         getNodeNabors(node, t3, nabors); 
/* 3836 */       if (t2 != null && !isMarked(t2))
/* 3837 */         getNodeNabors(node, t2, nabors); 
/* 3838 */       if (t0 != null && !isMarked(t0))
/* 3839 */         getNodeNabors(node, t0, nabors); 
/* 3840 */     } else if (node == n2) {
/* 3841 */       if (!isMarked(n3)) {
/* 3842 */         mark(n3);
/* 3843 */         nabors.add(n3);
/*      */       } 
/* 3845 */       if (!isMarked(n0)) {
/* 3846 */         mark(n0);
/* 3847 */         nabors.add(n0);
/*      */       } 
/* 3849 */       if (!isMarked(n1)) {
/* 3850 */         mark(n1);
/* 3851 */         nabors.add(n1);
/*      */       } 
/* 3853 */       if (t3 != null && !isMarked(t3))
/* 3854 */         getNodeNabors(node, t3, nabors); 
/* 3855 */       if (t0 != null && !isMarked(t0))
/* 3856 */         getNodeNabors(node, t0, nabors); 
/* 3857 */       if (t1 != null && !isMarked(t1))
/* 3858 */         getNodeNabors(node, t1, nabors); 
/* 3859 */     } else if (node == n3) {
/* 3860 */       if (!isMarked(n1)) {
/* 3861 */         mark(n1);
/* 3862 */         nabors.add(n1);
/*      */       } 
/* 3864 */       if (!isMarked(n0)) {
/* 3865 */         mark(n0);
/* 3866 */         nabors.add(n0);
/*      */       } 
/* 3868 */       if (!isMarked(n2)) {
/* 3869 */         mark(n2);
/* 3870 */         nabors.add(n2);
/*      */       } 
/* 3872 */       if (t1 != null && !isMarked(t1))
/* 3873 */         getNodeNabors(node, t1, nabors); 
/* 3874 */       if (t0 != null && !isMarked(t0))
/* 3875 */         getNodeNabors(node, t0, nabors); 
/* 3876 */       if (t2 != null && !isMarked(t2))
/* 3877 */         getNodeNabors(node, t2, nabors); 
/*      */     } else {
/* 3879 */       assert false : "node is referenced by tet";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getNodeNabors(Node node, int step, NodeStepList list) {
/* 3891 */     Tet[] tets = getTetNabors(node);
/* 3892 */     int ntet = tets.length;
/* 3893 */     for (int itet = 0; itet < ntet; itet++) {
/* 3894 */       Tet tet = tets[itet];
/* 3895 */       Node n0 = tet._n0;
/* 3896 */       Node n1 = tet._n1;
/* 3897 */       Node n2 = tet._n2;
/* 3898 */       Node n3 = tet._n3;
/* 3899 */       if (node == n0) {
/* 3900 */         if (!isMarked(n1)) {
/* 3901 */           mark(n1);
/* 3902 */           list.add(n1, step);
/*      */         } 
/* 3904 */         if (!isMarked(n2)) {
/* 3905 */           mark(n2);
/* 3906 */           list.add(n2, step);
/*      */         } 
/* 3908 */         if (!isMarked(n3)) {
/* 3909 */           mark(n3);
/* 3910 */           list.add(n3, step);
/*      */         } 
/* 3912 */       } else if (node == n1) {
/* 3913 */         if (!isMarked(n0)) {
/* 3914 */           mark(n0);
/* 3915 */           list.add(n0, step);
/*      */         } 
/* 3917 */         if (!isMarked(n2)) {
/* 3918 */           mark(n2);
/* 3919 */           list.add(n2, step);
/*      */         } 
/* 3921 */         if (!isMarked(n3)) {
/* 3922 */           mark(n3);
/* 3923 */           list.add(n3, step);
/*      */         } 
/* 3925 */       } else if (node == n2) {
/* 3926 */         if (!isMarked(n0)) {
/* 3927 */           mark(n0);
/* 3928 */           list.add(n0, step);
/*      */         } 
/* 3930 */         if (!isMarked(n1)) {
/* 3931 */           mark(n1);
/* 3932 */           list.add(n1, step);
/*      */         } 
/* 3934 */         if (!isMarked(n3)) {
/* 3935 */           mark(n3);
/* 3936 */           list.add(n3, step);
/*      */         } 
/* 3938 */       } else if (node == n3) {
/* 3939 */         if (!isMarked(n0)) {
/* 3940 */           mark(n0);
/* 3941 */           list.add(n0, step);
/*      */         } 
/* 3943 */         if (!isMarked(n1)) {
/* 3944 */           mark(n1);
/* 3945 */           list.add(n1, step);
/*      */         } 
/* 3947 */         if (!isMarked(n2)) {
/* 3948 */           mark(n2);
/* 3949 */           list.add(n2, step);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getTetNabors(Node node, Tet tet, TetList nabors) {
/* 3963 */     if (tet != null) {
/* 3964 */       mark(tet);
/* 3965 */       nabors.add(tet);
/* 3966 */       Node n0 = tet._n0;
/* 3967 */       Node n1 = tet._n1;
/* 3968 */       Node n2 = tet._n2;
/* 3969 */       Node n3 = tet._n3;
/* 3970 */       Tet t0 = tet._t0;
/* 3971 */       Tet t1 = tet._t1;
/* 3972 */       Tet t2 = tet._t2;
/* 3973 */       Tet t3 = tet._t3;
/* 3974 */       if (node == n0) {
/* 3975 */         if (t1 != null && !isMarked(t1))
/* 3976 */           getTetNabors(node, t1, nabors); 
/* 3977 */         if (t2 != null && !isMarked(t2))
/* 3978 */           getTetNabors(node, t2, nabors); 
/* 3979 */         if (t3 != null && !isMarked(t3))
/* 3980 */           getTetNabors(node, t3, nabors); 
/* 3981 */       } else if (node == n1) {
/* 3982 */         if (t3 != null && !isMarked(t3))
/* 3983 */           getTetNabors(node, t3, nabors); 
/* 3984 */         if (t2 != null && !isMarked(t2))
/* 3985 */           getTetNabors(node, t2, nabors); 
/* 3986 */         if (t0 != null && !isMarked(t0))
/* 3987 */           getTetNabors(node, t0, nabors); 
/* 3988 */       } else if (node == n2) {
/* 3989 */         if (t3 != null && !isMarked(t3))
/* 3990 */           getTetNabors(node, t3, nabors); 
/* 3991 */         if (t0 != null && !isMarked(t0))
/* 3992 */           getTetNabors(node, t0, nabors); 
/* 3993 */         if (t1 != null && !isMarked(t1))
/* 3994 */           getTetNabors(node, t1, nabors); 
/* 3995 */       } else if (node == n3) {
/* 3996 */         if (t1 != null && !isMarked(t1))
/* 3997 */           getTetNabors(node, t1, nabors); 
/* 3998 */         if (t0 != null && !isMarked(t0))
/* 3999 */           getTetNabors(node, t0, nabors); 
/* 4000 */         if (t2 != null && !isMarked(t2))
/* 4001 */           getTetNabors(node, t2, nabors); 
/*      */       } else {
/* 4003 */         assert false : "node is referenced by tet";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getTetNabors(Node na, Node nb, Tet tet, TetList nabors) {
/* 4015 */     if (tet != null) {
/* 4016 */       mark(tet);
/* 4017 */       nabors.add(tet);
/* 4018 */       Node n0 = tet._n0;
/* 4019 */       Node n1 = tet._n1;
/* 4020 */       Node n2 = tet._n2;
/* 4021 */       Node n3 = tet._n3;
/* 4022 */       Tet t0 = tet._t0;
/* 4023 */       Tet t1 = tet._t1;
/* 4024 */       Tet t2 = tet._t2;
/* 4025 */       Tet t3 = tet._t3;
/* 4026 */       Tet tc = null;
/* 4027 */       Tet td = null;
/* 4028 */       if (na == n0) {
/* 4029 */         if (nb == n1) {
/* 4030 */           tc = t2;
/* 4031 */           td = t3;
/* 4032 */         } else if (nb == n2) {
/* 4033 */           tc = t1;
/* 4034 */           td = t3;
/* 4035 */         } else if (nb == n3) {
/* 4036 */           tc = t1;
/* 4037 */           td = t2;
/*      */         } else {
/* 4039 */           assert false : "nodes na and nb are referenced by tet";
/*      */         } 
/* 4041 */       } else if (na == n1) {
/* 4042 */         if (nb == n0) {
/* 4043 */           tc = t2;
/* 4044 */           td = t3;
/* 4045 */         } else if (nb == n2) {
/* 4046 */           tc = t0;
/* 4047 */           td = t3;
/* 4048 */         } else if (nb == n3) {
/* 4049 */           tc = t0;
/* 4050 */           td = t2;
/*      */         } else {
/* 4052 */           assert false : "nodes na and nb are referenced by tet";
/*      */         } 
/* 4054 */       } else if (na == n2) {
/* 4055 */         if (nb == n0) {
/* 4056 */           tc = t1;
/* 4057 */           td = t3;
/* 4058 */         } else if (nb == n1) {
/* 4059 */           tc = t0;
/* 4060 */           td = t3;
/* 4061 */         } else if (nb == n3) {
/* 4062 */           tc = t0;
/* 4063 */           td = t1;
/*      */         } else {
/* 4065 */           assert false : "nodes na and nb are referenced by tet";
/*      */         } 
/* 4067 */       } else if (na == n3) {
/* 4068 */         if (nb == n0) {
/* 4069 */           tc = t1;
/* 4070 */           td = t2;
/* 4071 */         } else if (nb == n1) {
/* 4072 */           tc = t0;
/* 4073 */           td = t2;
/* 4074 */         } else if (nb == n2) {
/* 4075 */           tc = t0;
/* 4076 */           td = t1;
/*      */         } else {
/* 4078 */           assert false : "nodes na and nb are referenced by tet";
/*      */         } 
/*      */       } else {
/* 4081 */         assert false : "node na is referenced by tet";
/*      */       } 
/* 4083 */       if (tc != null && !isMarked(tc)) {
/* 4084 */         getTetNabors(na, nb, tc, nabors);
/*      */       }
/* 4086 */       if (td != null && !isMarked(td)) {
/* 4087 */         getTetNabors(na, nb, td, nabors);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tet findTet(Tet tet, Node na, Node nb) {
/* 4098 */     if (tet != null) {
/* 4099 */       mark(tet);
/* 4100 */       Node n0 = tet._n0;
/* 4101 */       Node n1 = tet._n1;
/* 4102 */       Node n2 = tet._n2;
/* 4103 */       Node n3 = tet._n3;
/* 4104 */       Tet t0 = tet._t0;
/* 4105 */       Tet t1 = tet._t1;
/* 4106 */       Tet t2 = tet._t2;
/* 4107 */       Tet t3 = tet._t3;
/* 4108 */       if (na == n0) {
/* 4109 */         if (nb == n1 || nb == n2 || nb == n3 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb)) != null))
/*      */         {
/*      */ 
/*      */           
/* 4113 */           return tet; } 
/* 4114 */       } else if (na == n1) {
/* 4115 */         if (nb == n3 || nb == n2 || nb == n0 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb)) != null) || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb)) != null))
/*      */         {
/*      */ 
/*      */           
/* 4119 */           return tet; } 
/* 4120 */       } else if (na == n2) {
/* 4121 */         if (nb == n3 || nb == n0 || nb == n1 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb)) != null) || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb)) != null) || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb)) != null))
/*      */         {
/*      */ 
/*      */           
/* 4125 */           return tet; } 
/* 4126 */       } else if (na == n3) {
/* 4127 */         if (nb == n1 || nb == n0 || nb == n2 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb)) != null) || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb)) != null))
/*      */         {
/*      */ 
/*      */           
/* 4131 */           return tet; } 
/*      */       } else {
/* 4133 */         assert false : "node na is referenced by tet";
/*      */       } 
/*      */     } 
/* 4136 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tet findTet(Tet tet, Node na, Node nb, Node nc) {
/* 4145 */     if (tet != null) {
/* 4146 */       mark(tet);
/* 4147 */       Node n0 = tet._n0;
/* 4148 */       Node n1 = tet._n1;
/* 4149 */       Node n2 = tet._n2;
/* 4150 */       Node n3 = tet._n3;
/* 4151 */       Tet t0 = tet._t0;
/* 4152 */       Tet t1 = tet._t1;
/* 4153 */       Tet t2 = tet._t2;
/* 4154 */       Tet t3 = tet._t3;
/* 4155 */       if (na == n0) {
/* 4156 */         if (nb == n1) {
/* 4157 */           if (nc == n2 || nc == n3 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4160 */             return tet; } 
/* 4161 */         } else if (nb == n2) {
/* 4162 */           if (nc == n1 || nc == n3 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4165 */             return tet; } 
/* 4166 */         } else if (nb == n3) {
/* 4167 */           if (nc == n1 || nc == n2 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4170 */             return tet; } 
/*      */         } else {
/* 4172 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4174 */       } else if (na == n1) {
/* 4175 */         if (nb == n0) {
/* 4176 */           if (nc == n2 || nc == n3 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4179 */             return tet; } 
/* 4180 */         } else if (nb == n2) {
/* 4181 */           if (nc == n0 || nc == n3 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4184 */             return tet; } 
/* 4185 */         } else if (nb == n3) {
/* 4186 */           if (nc == n0 || nc == n2 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4189 */             return tet; } 
/*      */         } else {
/* 4191 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4193 */       } else if (na == n2) {
/* 4194 */         if (nb == n0) {
/* 4195 */           if (nc == n1 || nc == n3 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4198 */             return tet; } 
/* 4199 */         } else if (nb == n1) {
/* 4200 */           if (nc == n0 || nc == n3 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4203 */             return tet; } 
/* 4204 */         } else if (nb == n3) {
/* 4205 */           if (nc == n0 || nc == n1 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4208 */             return tet; } 
/*      */         } else {
/* 4210 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4212 */       } else if (na == n3) {
/* 4213 */         if (nb == n0) {
/* 4214 */           if (nc == n1 || nc == n2 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4217 */             return tet; } 
/* 4218 */         } else if (nb == n1) {
/* 4219 */           if (nc == n0 || nc == n2 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4222 */             return tet; } 
/* 4223 */         } else if (nb == n2) {
/* 4224 */           if (nc == n0 || nc == n1 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc)) != null) || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc)) != null))
/*      */           {
/*      */             
/* 4227 */             return tet; } 
/*      */         } else {
/* 4229 */           assert false : "node nb is referenced by tet";
/*      */         } 
/*      */       } else {
/* 4232 */         assert false : "node na is referenced by tet";
/*      */       } 
/*      */     } 
/* 4235 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tet findTet(Tet tet, Node na, Node nb, Node nc, Node nd) {
/* 4245 */     if (tet != null) {
/* 4246 */       mark(tet);
/* 4247 */       Node n0 = tet._n0;
/* 4248 */       Node n1 = tet._n1;
/* 4249 */       Node n2 = tet._n2;
/* 4250 */       Node n3 = tet._n3;
/* 4251 */       Tet t0 = tet._t0;
/* 4252 */       Tet t1 = tet._t1;
/* 4253 */       Tet t2 = tet._t2;
/* 4254 */       Tet t3 = tet._t3;
/* 4255 */       if (na == n0) {
/* 4256 */         if (nb == n1) {
/* 4257 */           if (nc == n2) {
/* 4258 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4260 */               return tet; } 
/* 4261 */           } else if (nc == n3) {
/* 4262 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4264 */               return tet; } 
/*      */           } else {
/* 4266 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4268 */         } else if (nb == n2) {
/* 4269 */           if (nc == n1) {
/* 4270 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4272 */               return tet; } 
/* 4273 */           } else if (nc == n3) {
/* 4274 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4276 */               return tet; } 
/*      */           } else {
/* 4278 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4280 */         } else if (nb == n3) {
/* 4281 */           if (nc == n1) {
/* 4282 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4284 */               return tet; } 
/* 4285 */           } else if (nc == n2) {
/* 4286 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4288 */               return tet; } 
/*      */           } else {
/* 4290 */             assert false : "node nc is referenced by tet";
/*      */           } 
/*      */         } else {
/* 4293 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4295 */       } else if (na == n1) {
/* 4296 */         if (nb == n0) {
/* 4297 */           if (nc == n2) {
/* 4298 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4300 */               return tet; } 
/* 4301 */           } else if (nc == n3) {
/* 4302 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4304 */               return tet; } 
/*      */           } else {
/* 4306 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4308 */         } else if (nb == n2) {
/* 4309 */           if (nc == n0) {
/* 4310 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4312 */               return tet; } 
/* 4313 */           } else if (nc == n3) {
/* 4314 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4316 */               return tet; } 
/*      */           } else {
/* 4318 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4320 */         } else if (nb == n3) {
/* 4321 */           if (nc == n0) {
/* 4322 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4324 */               return tet; } 
/* 4325 */           } else if (nc == n2) {
/* 4326 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4328 */               return tet; } 
/*      */           } else {
/* 4330 */             assert false : "node nc is referenced by tet";
/*      */           } 
/*      */         } else {
/* 4333 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4335 */       } else if (na == n2) {
/* 4336 */         if (nb == n0) {
/* 4337 */           if (nc == n1) {
/* 4338 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4340 */               return tet; } 
/* 4341 */           } else if (nc == n3) {
/* 4342 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4344 */               return tet; } 
/*      */           } else {
/* 4346 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4348 */         } else if (nb == n1) {
/* 4349 */           if (nc == n0) {
/* 4350 */             if (nd == n3 || (t3 != null && !isMarked(t3) && (tet = findTet(t3, na, nb, nc, nd)) != null))
/*      */             {
/* 4352 */               return tet; } 
/* 4353 */           } else if (nc == n3) {
/* 4354 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4356 */               return tet; } 
/*      */           } else {
/* 4358 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4360 */         } else if (nb == n3) {
/* 4361 */           if (nc == n0) {
/* 4362 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4364 */               return tet; } 
/* 4365 */           } else if (nc == n1) {
/* 4366 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4368 */               return tet; } 
/*      */           } else {
/* 4370 */             assert false : "node nc is referenced by tet";
/*      */           } 
/*      */         } else {
/* 4373 */           assert false : "node nb is referenced by tet";
/*      */         } 
/* 4375 */       } else if (na == n3) {
/* 4376 */         if (nb == n0) {
/* 4377 */           if (nc == n1) {
/* 4378 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4380 */               return tet; } 
/* 4381 */           } else if (nc == n2) {
/* 4382 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4384 */               return tet; } 
/*      */           } else {
/* 4386 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4388 */         } else if (nb == n1) {
/* 4389 */           if (nc == n0) {
/* 4390 */             if (nd == n2 || (t2 != null && !isMarked(t2) && (tet = findTet(t2, na, nb, nc, nd)) != null))
/*      */             {
/* 4392 */               return tet; } 
/* 4393 */           } else if (nc == n2) {
/* 4394 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4396 */               return tet; } 
/*      */           } else {
/* 4398 */             assert false : "node nc is referenced by tet";
/*      */           } 
/* 4400 */         } else if (nb == n2) {
/* 4401 */           if (nc == n0) {
/* 4402 */             if (nd == n1 || (t1 != null && !isMarked(t1) && (tet = findTet(t1, na, nb, nc, nd)) != null))
/*      */             {
/* 4404 */               return tet; } 
/* 4405 */           } else if (nc == n1) {
/* 4406 */             if (nd == n0 || (t0 != null && !isMarked(t0) && (tet = findTet(t0, na, nb, nc, nd)) != null))
/*      */             {
/* 4408 */               return tet; } 
/*      */           } else {
/* 4410 */             assert false : "node nc is referenced by tet";
/*      */           } 
/*      */         } else {
/* 4413 */           assert false : "node nb is referenced by tet";
/*      */         } 
/*      */       } else {
/* 4416 */         assert false : "node na is referenced by tet";
/*      */       } 
/*      */     } 
/* 4419 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node findNodeNearest(double x, double y, double z) {
/* 4428 */     if (this._nnode == 0) {
/* 4429 */       return null;
/*      */     }
/*      */     
/* 4432 */     if (this._nnode < 20) {
/* 4433 */       this._nmin = this._nroot;
/* 4434 */       this._dmin = distanceSquared(this._nmin, x, y, z);
/* 4435 */       NodeIterator nodeIterator = getNodes();
/* 4436 */       while (nodeIterator.hasNext()) {
/* 4437 */         Node n = nodeIterator.next();
/* 4438 */         double d = distanceSquared(n, x, y, z);
/* 4439 */         if (d < this._dmin) {
/* 4440 */           this._dmin = d;
/* 4441 */           this._nmin = n;
/*      */         } 
/*      */       } 
/* 4444 */       return this._nmin;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4449 */     this._nmin = this._nroot;
/* 4450 */     this._dmin = distanceSquared(this._nmin, x, y, z);
/* 4451 */     Iterator<Node> ni = this._sampledNodes.iterator();
/* 4452 */     while (ni.hasNext()) {
/* 4453 */       Node n = ni.next();
/* 4454 */       double d = distanceSquared(n, x, y, z);
/* 4455 */       if (d < this._dmin) {
/* 4456 */         this._dmin = d;
/* 4457 */         this._nmin = n;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4466 */     clearNodeMarks();
/*      */     
/*      */     while (true) {
/* 4469 */       clearTetMarks();
/* 4470 */       double dmin = this._dmin;
/* 4471 */       findNodeNaborNearest(x, y, z, this._nmin, this._nmin._tet);
/* 4472 */       if (this._dmin >= dmin) {
/* 4473 */         return this._nmin;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearest(double x, double y, double z, Node node, Tet tet) {
/* 4485 */     mark(tet);
/* 4486 */     Node n0 = tet._n0;
/* 4487 */     Node n1 = tet._n1;
/* 4488 */     Node n2 = tet._n2;
/* 4489 */     Node n3 = tet._n3;
/* 4490 */     Tet t0 = tet._t0;
/* 4491 */     Tet t1 = tet._t1;
/* 4492 */     Tet t2 = tet._t2;
/* 4493 */     Tet t3 = tet._t3;
/* 4494 */     if (node == n0) {
/* 4495 */       findNodeNaborNearest(x, y, z, node, n1, n2, n3, t1, t2, t3);
/* 4496 */     } else if (node == n1) {
/* 4497 */       findNodeNaborNearest(x, y, z, node, n3, n2, n0, t3, t2, t0);
/* 4498 */     } else if (node == n2) {
/* 4499 */       findNodeNaborNearest(x, y, z, node, n3, n0, n1, t3, t0, t1);
/* 4500 */     } else if (node == n3) {
/* 4501 */       findNodeNaborNearest(x, y, z, node, n1, n0, n2, t1, t0, t2);
/*      */     } else {
/* 4503 */       assert false : "node is referenced by tet";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearest(double x, double y, double z, Node node, Node na, Node nb, Node nc, Tet ta, Tet tb, Tet tc) {
/* 4510 */     if (!isMarked(na)) {
/* 4511 */       mark(na);
/* 4512 */       double da = distanceSquared(na, x, y, z);
/* 4513 */       if (da < this._dmin) {
/* 4514 */         this._dmin = da;
/* 4515 */         this._nmin = na;
/*      */       } 
/*      */     } 
/* 4518 */     if (!isMarked(nb)) {
/* 4519 */       mark(nb);
/* 4520 */       double db = distanceSquared(nb, x, y, z);
/* 4521 */       if (db < this._dmin) {
/* 4522 */         this._dmin = db;
/* 4523 */         this._nmin = nb;
/*      */       } 
/*      */     } 
/* 4526 */     if (!isMarked(nc)) {
/* 4527 */       mark(nc);
/* 4528 */       double dc = distanceSquared(nc, x, y, z);
/* 4529 */       if (dc < this._dmin) {
/* 4530 */         this._dmin = dc;
/* 4531 */         this._nmin = nc;
/*      */       } 
/*      */     } 
/* 4534 */     if (ta != null && !isMarked(ta))
/* 4535 */       findNodeNaborNearest(x, y, z, node, ta); 
/* 4536 */     if (tb != null && !isMarked(tb))
/* 4537 */       findNodeNaborNearest(x, y, z, node, tb); 
/* 4538 */     if (tc != null && !isMarked(tc)) {
/* 4539 */       findNodeNaborNearest(x, y, z, node, tc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node findNodeNearestPlane(double a, double b, double c, double d) {
/* 4548 */     this._nmin = this._nroot;
/* 4549 */     this._dmin = distanceToPlaneSquared(this._nmin, a, b, c, d);
/* 4550 */     Iterator<Node> ni = this._sampledNodes.iterator();
/* 4551 */     while (ni.hasNext()) {
/* 4552 */       Node n = ni.next();
/* 4553 */       double dp = distanceToPlaneSquared(n, a, b, c, d);
/* 4554 */       if (dp < this._dmin) {
/* 4555 */         this._dmin = dp;
/* 4556 */         this._nmin = n;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4565 */     clearNodeMarks();
/*      */     
/*      */     while (true) {
/* 4568 */       clearTetMarks();
/* 4569 */       double dmin = this._dmin;
/* 4570 */       findNodeNaborNearestPlane(a, b, c, d, this._nmin, this._nmin._tet);
/* 4571 */       if (this._dmin >= dmin) {
/* 4572 */         return this._nmin;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearestPlane(double a, double b, double c, double d, Node node, Tet tet) {
/* 4584 */     mark(tet);
/* 4585 */     Node n0 = tet._n0;
/* 4586 */     Node n1 = tet._n1;
/* 4587 */     Node n2 = tet._n2;
/* 4588 */     Node n3 = tet._n3;
/* 4589 */     Tet t0 = tet._t0;
/* 4590 */     Tet t1 = tet._t1;
/* 4591 */     Tet t2 = tet._t2;
/* 4592 */     Tet t3 = tet._t3;
/* 4593 */     if (node == n0) {
/* 4594 */       findNodeNaborNearestPlane(a, b, c, d, node, n1, n2, n3, t1, t2, t3);
/* 4595 */     } else if (node == n1) {
/* 4596 */       findNodeNaborNearestPlane(a, b, c, d, node, n3, n2, n0, t3, t2, t0);
/* 4597 */     } else if (node == n2) {
/* 4598 */       findNodeNaborNearestPlane(a, b, c, d, node, n3, n0, n1, t3, t0, t1);
/* 4599 */     } else if (node == n3) {
/* 4600 */       findNodeNaborNearestPlane(a, b, c, d, node, n1, n0, n2, t1, t0, t2);
/*      */     } else {
/* 4602 */       assert false : "node is referenced by tet";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNaborNearestPlane(double a, double b, double c, double d, Node node, Node na, Node nb, Node nc, Tet ta, Tet tb, Tet tc) {
/* 4609 */     if (!isMarked(na)) {
/* 4610 */       mark(na);
/* 4611 */       double da = distanceToPlaneSquared(na, a, b, c, d);
/* 4612 */       if (da < this._dmin) {
/* 4613 */         this._dmin = da;
/* 4614 */         this._nmin = na;
/*      */       } 
/*      */     } 
/* 4617 */     if (!isMarked(nb)) {
/* 4618 */       mark(nb);
/* 4619 */       double db = distanceToPlaneSquared(nb, a, b, c, d);
/* 4620 */       if (db < this._dmin) {
/* 4621 */         this._dmin = db;
/* 4622 */         this._nmin = nb;
/*      */       } 
/*      */     } 
/* 4625 */     if (!isMarked(nc)) {
/* 4626 */       mark(nc);
/* 4627 */       double dc = distanceToPlaneSquared(nc, a, b, c, d);
/* 4628 */       if (dc < this._dmin) {
/* 4629 */         this._dmin = dc;
/* 4630 */         this._nmin = nc;
/*      */       } 
/*      */     } 
/* 4633 */     if (ta != null && !isMarked(ta))
/* 4634 */       findNodeNaborNearestPlane(a, b, c, d, node, ta); 
/* 4635 */     if (tb != null && !isMarked(tb))
/* 4636 */       findNodeNaborNearestPlane(a, b, c, d, node, tb); 
/* 4637 */     if (tc != null && !isMarked(tc)) {
/* 4638 */       findNodeNaborNearestPlane(a, b, c, d, node, tc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PointLocation locatePoint(double x, double y, double z) {
/* 4648 */     if (this._troot == null) {
/* 4649 */       if (this._nroot != null) {
/* 4650 */         Node node = this._nroot;
/*      */         do {
/* 4652 */           if (x == node.x() && y == node.y() && z == node.z())
/* 4653 */             return new PointLocation(node); 
/* 4654 */           node = node._next;
/* 4655 */         } while (node != this._nroot);
/*      */       } 
/* 4657 */       return new PointLocation(null, false);
/*      */     } 
/*      */ 
/*      */     
/* 4661 */     Node nmin = this._nroot;
/* 4662 */     double dmin = distanceSquared(nmin, x, y, z);
/* 4663 */     Iterator<Node> ni = this._sampledNodes.iterator();
/* 4664 */     while (ni.hasNext()) {
/* 4665 */       Node n = ni.next();
/* 4666 */       double d = distanceSquared(n, x, y, z);
/* 4667 */       if (d < dmin) {
/* 4668 */         dmin = d;
/* 4669 */         nmin = n;
/*      */       } 
/*      */     } 
/* 4672 */     Tet tet = nmin._tet;
/* 4673 */     return locatePoint(tet, x, y, z);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PointLocation locatePoint(Tet tet, double x, double y, double z) {
/* 4683 */     this._troot = tet;
/*      */ 
/*      */     
/* 4686 */     Node n0 = tet._n0;
/* 4687 */     Node n1 = tet._n1;
/* 4688 */     Node n2 = tet._n2;
/* 4689 */     Node n3 = tet._n3;
/* 4690 */     double x0 = n0._x;
/* 4691 */     double y0 = n0._y;
/* 4692 */     double z0 = n0._z;
/* 4693 */     double x1 = n1._x;
/* 4694 */     double y1 = n1._y;
/* 4695 */     double z1 = n1._z;
/* 4696 */     double x2 = n2._x;
/* 4697 */     double y2 = n2._y;
/* 4698 */     double z2 = n2._z;
/* 4699 */     double x3 = n3._x;
/* 4700 */     double y3 = n3._y;
/* 4701 */     double z3 = n3._z;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4706 */     if (x == x0 && y == y0 && z == z0)
/* 4707 */       return new PointLocation(n0); 
/* 4708 */     if (x == x1 && y == y1 && z == z1)
/* 4709 */       return new PointLocation(n1); 
/* 4710 */     if (x == x2 && y == y2 && z == z2)
/* 4711 */       return new PointLocation(n2); 
/* 4712 */     if (x == x3 && y == y3 && z == z3) {
/* 4713 */       return new PointLocation(n3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4723 */     double d0 = Geometry.leftOfPlane(x1, y1, z1, x2, y2, z2, x3, y3, z3, x, y, z);
/* 4724 */     if (d0 > 0.0D) {
/* 4725 */       Tet tetNabor = tet.tetNabor(n0);
/* 4726 */       if (tetNabor != null) {
/* 4727 */         return locatePoint(tetNabor, x, y, z);
/*      */       }
/* 4729 */       return new PointLocation(tet, false);
/*      */     } 
/*      */     
/* 4732 */     double d1 = Geometry.leftOfPlane(x3, y3, z3, x2, y2, z2, x0, y0, z0, x, y, z);
/* 4733 */     if (d1 > 0.0D) {
/* 4734 */       Tet tetNabor = tet.tetNabor(n1);
/* 4735 */       if (tetNabor != null) {
/* 4736 */         return locatePoint(tetNabor, x, y, z);
/*      */       }
/* 4738 */       return new PointLocation(tet, false);
/*      */     } 
/*      */     
/* 4741 */     double d2 = Geometry.leftOfPlane(x3, y3, z3, x0, y0, z0, x1, y1, z1, x, y, z);
/* 4742 */     if (d2 > 0.0D) {
/* 4743 */       Tet tetNabor = tet.tetNabor(n2);
/* 4744 */       if (tetNabor != null) {
/* 4745 */         return locatePoint(tetNabor, x, y, z);
/*      */       }
/* 4747 */       return new PointLocation(tet, false);
/*      */     } 
/*      */     
/* 4750 */     double d3 = Geometry.leftOfPlane(x0, y0, z0, x2, y2, z2, x1, y1, z1, x, y, z);
/* 4751 */     if (d3 > 0.0D) {
/* 4752 */       Tet tetNabor = tet.tetNabor(n3);
/* 4753 */       if (tetNabor != null) {
/* 4754 */         return locatePoint(tetNabor, x, y, z);
/*      */       }
/* 4756 */       return new PointLocation(tet, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4761 */     if (d0 < 0.0D && d1 < 0.0D && d2 < 0.0D && d3 < 0.0D) {
/* 4762 */       return new PointLocation(tet);
/*      */     }
/*      */ 
/*      */     
/* 4766 */     if (d0 == 0.0D && d1 == 0.0D)
/* 4767 */       return new PointLocation(new Edge(tet, n2, n3)); 
/* 4768 */     if (d0 == 0.0D && d2 == 0.0D)
/* 4769 */       return new PointLocation(new Edge(tet, n3, n1)); 
/* 4770 */     if (d0 == 0.0D && d3 == 0.0D)
/* 4771 */       return new PointLocation(new Edge(tet, n1, n2)); 
/* 4772 */     if (d1 == 0.0D && d2 == 0.0D)
/* 4773 */       return new PointLocation(new Edge(tet, n0, n3)); 
/* 4774 */     if (d1 == 0.0D && d3 == 0.0D)
/* 4775 */       return new PointLocation(new Edge(tet, n2, n0)); 
/* 4776 */     if (d2 == 0.0D && d3 == 0.0D)
/* 4777 */       return new PointLocation(new Edge(tet, n0, n1)); 
/* 4778 */     if (d0 == 0.0D)
/* 4779 */       return new PointLocation(new Face(tet, n0)); 
/* 4780 */     if (d1 == 0.0D)
/* 4781 */       return new PointLocation(new Face(tet, n1)); 
/* 4782 */     if (d2 == 0.0D)
/* 4783 */       return new PointLocation(new Face(tet, n2)); 
/* 4784 */     if (d3 == 0.0D) {
/* 4785 */       return new PointLocation(new Face(tet, n3));
/*      */     }
/*      */ 
/*      */     
/* 4789 */     assert false : "successfully located the point";
/* 4790 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayFacesInside(Node node, Tet tet) {
/* 4799 */     if (tet != null && !isMarked(tet)) {
/* 4800 */       mark(tet);
/* 4801 */       Node n0 = tet._n0;
/* 4802 */       Node n1 = tet._n1;
/* 4803 */       Node n2 = tet._n2;
/* 4804 */       Node n3 = tet._n3;
/* 4805 */       if (inSphere(n0, n1, n2, n3, node)) {
/* 4806 */         killTet(tet);
/* 4807 */         Tet t0 = tet._t0;
/* 4808 */         Tet t1 = tet._t1;
/* 4809 */         Tet t2 = tet._t2;
/* 4810 */         Tet t3 = tet._t3;
/* 4811 */         this._faceSet.addMate(tet, n0);
/* 4812 */         this._faceSet.addMate(tet, n1);
/* 4813 */         this._faceSet.addMate(tet, n2);
/* 4814 */         this._faceSet.addMate(tet, n3);
/* 4815 */         getDelaunayFacesInside(node, t0);
/* 4816 */         getDelaunayFacesInside(node, t1);
/* 4817 */         getDelaunayFacesInside(node, t2);
/* 4818 */         getDelaunayFacesInside(node, t3);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayFacesOutside(Node node, Tet tet) {
/* 4829 */     if (tet != null && !isMarked(tet)) {
/* 4830 */       mark(tet);
/* 4831 */       Node n0 = tet._n0;
/* 4832 */       Node n1 = tet._n1;
/* 4833 */       Node n2 = tet._n2;
/* 4834 */       Node n3 = tet._n3;
/* 4835 */       Tet t0 = tet._t0;
/* 4836 */       Tet t1 = tet._t1;
/* 4837 */       Tet t2 = tet._t2;
/* 4838 */       Tet t3 = tet._t3;
/* 4839 */       if (t0 == null && leftOfPlane(n1, n2, n3, node)) {
/* 4840 */         this._faceSet.add(tet, n0);
/* 4841 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n1, n0));
/* 4842 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n2, n0));
/* 4843 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n3, n0));
/*      */       } 
/* 4845 */       if (t1 == null && leftOfPlane(n3, n2, n0, node)) {
/* 4846 */         this._faceSet.add(tet, n1);
/* 4847 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n3, n1));
/* 4848 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n2, n1));
/* 4849 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n0, n1));
/*      */       } 
/* 4851 */       if (t2 == null && leftOfPlane(n3, n0, n1, node)) {
/* 4852 */         this._faceSet.add(tet, n2);
/* 4853 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n3, n2));
/* 4854 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n0, n2));
/* 4855 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n1, n2));
/*      */       } 
/* 4857 */       if (t3 == null && leftOfPlane(n1, n0, n2, node)) {
/* 4858 */         this._faceSet.add(tet, n3);
/* 4859 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n1, n3));
/* 4860 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n0, n3));
/* 4861 */         getDelaunayFacesOutside(node, getNextTetOnHull(tet, n2, n3));
/*      */       } 
/* 4863 */       if (inSphere(n0, n1, n2, n3, node)) {
/* 4864 */         killTet(tet);
/* 4865 */         this._faceSet.addMate(tet, n0);
/* 4866 */         this._faceSet.addMate(tet, n1);
/* 4867 */         this._faceSet.addMate(tet, n2);
/* 4868 */         this._faceSet.addMate(tet, n3);
/* 4869 */         getDelaunayFacesOutside(node, t0);
/* 4870 */         getDelaunayFacesOutside(node, t1);
/* 4871 */         getDelaunayFacesOutside(node, t2);
/* 4872 */         getDelaunayFacesOutside(node, t3);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDelaunayFacesOpposite(Node node, Tet tet) {
/* 4885 */     if (tet != null && !isMarked(tet)) {
/* 4886 */       mark(tet);
/* 4887 */       killTet(tet);
/* 4888 */       Node n0 = tet._n0;
/* 4889 */       Node n1 = tet._n1;
/* 4890 */       Node n2 = tet._n2;
/* 4891 */       Node n3 = tet._n3;
/* 4892 */       Tet t0 = tet._t0;
/* 4893 */       Tet t1 = tet._t1;
/* 4894 */       Tet t2 = tet._t2;
/* 4895 */       Tet t3 = tet._t3;
/* 4896 */       if (node == n0) {
/* 4897 */         this._faceSet.addMate(tet, n0);
/* 4898 */         getDelaunayFacesOpposite(node, n1, n2, n3, t1, t2, t3);
/* 4899 */       } else if (node == n1) {
/* 4900 */         this._faceSet.addMate(tet, n1);
/* 4901 */         getDelaunayFacesOpposite(node, n3, n2, n0, t3, t2, t0);
/* 4902 */       } else if (node == n2) {
/* 4903 */         this._faceSet.addMate(tet, n2);
/* 4904 */         getDelaunayFacesOpposite(node, n3, n0, n1, t3, t0, t1);
/* 4905 */       } else if (node == n3) {
/* 4906 */         this._faceSet.addMate(tet, n3);
/* 4907 */         getDelaunayFacesOpposite(node, n1, n0, n2, t1, t0, t2);
/*      */       } else {
/* 4909 */         assert false : "node is referenced by tet";
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void getDelaunayFacesOpposite(Node node, Node na, Node nb, Node nc, Tet ta, Tet tb, Tet tc) {
/* 4916 */     if (!isMarked(na)) {
/* 4917 */       mark(na);
/* 4918 */       this._nodeList.add(na);
/*      */     } 
/* 4920 */     if (!isMarked(nb)) {
/* 4921 */       mark(nb);
/* 4922 */       this._nodeList.add(nb);
/*      */     } 
/* 4924 */     if (!isMarked(nc)) {
/* 4925 */       mark(nc);
/* 4926 */       this._nodeList.add(nc);
/*      */     } 
/* 4928 */     getDelaunayFacesOpposite(node, ta);
/* 4929 */     getDelaunayFacesOpposite(node, tb);
/* 4930 */     getDelaunayFacesOpposite(node, tc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Tet getNextTetOnHull(Tet tet, Node node, Node nodeOther) {
/* 4940 */     for (Tet tnext = tet.tetNabor(node); tnext != null; tnext = tet.tetNabor(node)) {
/* 4941 */       node = nodeOther;
/* 4942 */       nodeOther = tet.nodeNabor(tnext);
/* 4943 */       tet = tnext;
/*      */     } 
/* 4945 */     return tet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Node findNodeNearestSlow(float x, float y, float z) {
/* 4957 */     clearTetMarks();
/* 4958 */     clearNodeMarks();
/*      */ 
/*      */     
/* 4961 */     this._dmin = Double.MAX_VALUE;
/* 4962 */     this._nmin = null;
/* 4963 */     if (this._troot == null) {
/* 4964 */       if (this._nroot != null) {
/* 4965 */         Node node = this._nroot;
/*      */         do {
/* 4967 */           updateNodeNearest(x, y, z, node);
/* 4968 */           node = node._next;
/* 4969 */         } while (node != this._nroot);
/*      */       } 
/* 4971 */       assert this._nmin != null;
/* 4972 */       return this._nmin;
/*      */     } 
/*      */ 
/*      */     
/* 4976 */     PointLocation pl = locatePoint(x, y, z);
/*      */ 
/*      */     
/* 4979 */     if (pl.isOnNode()) {
/* 4980 */       updateNodeNearest(x, y, z, pl.node());
/* 4981 */       return this._nmin;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4986 */     if (pl.isInside()) {
/* 4987 */       findNodeNearestInside(x, y, z, pl.tet());
/*      */     } else {
/* 4989 */       findNodeNearestOutside(x, y, z, pl.tet());
/*      */     } 
/* 4991 */     return this._nmin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNearestInside(double x, double y, double z, Tet tet) {
/* 5003 */     if (tet != null && !isMarked(tet)) {
/* 5004 */       mark(tet);
/* 5005 */       Node n0 = tet._n0;
/* 5006 */       Node n1 = tet._n1;
/* 5007 */       Node n2 = tet._n2;
/* 5008 */       Node n3 = tet._n3;
/* 5009 */       updateNodeNearest(x, y, z, n0);
/* 5010 */       updateNodeNearest(x, y, z, n1);
/* 5011 */       updateNodeNearest(x, y, z, n2);
/* 5012 */       updateNodeNearest(x, y, z, n3);
/* 5013 */       if (inSphere(n0, n1, n2, n3, x, y, z)) {
/* 5014 */         Tet t0 = tet._t0;
/* 5015 */         Tet t1 = tet._t1;
/* 5016 */         Tet t2 = tet._t2;
/* 5017 */         Tet t3 = tet._t3;
/* 5018 */         findNodeNearestInside(x, y, z, t0);
/* 5019 */         findNodeNearestInside(x, y, z, t1);
/* 5020 */         findNodeNearestInside(x, y, z, t2);
/* 5021 */         findNodeNearestInside(x, y, z, t3);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findNodeNearestOutside(double x, double y, double z, Tet tet) {
/* 5034 */     if (tet != null && !isMarked(tet)) {
/* 5035 */       mark(tet);
/* 5036 */       Node n0 = tet._n0;
/* 5037 */       Node n1 = tet._n1;
/* 5038 */       Node n2 = tet._n2;
/* 5039 */       Node n3 = tet._n3;
/* 5040 */       updateNodeNearest(x, y, z, n0);
/* 5041 */       updateNodeNearest(x, y, z, n1);
/* 5042 */       updateNodeNearest(x, y, z, n2);
/* 5043 */       updateNodeNearest(x, y, z, n3);
/* 5044 */       Tet t0 = tet._t0;
/* 5045 */       Tet t1 = tet._t1;
/* 5046 */       Tet t2 = tet._t2;
/* 5047 */       Tet t3 = tet._t3;
/* 5048 */       if (t0 == null && leftOfPlane(n1, n2, n3, x, y, z)) {
/* 5049 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n1, n0));
/* 5050 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n2, n0));
/* 5051 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n3, n0));
/*      */       } 
/* 5053 */       if (t1 == null && leftOfPlane(n3, n2, n0, x, y, z)) {
/* 5054 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n3, n1));
/* 5055 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n2, n1));
/* 5056 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n0, n1));
/*      */       } 
/* 5058 */       if (t2 == null && leftOfPlane(n3, n0, n1, x, y, z)) {
/* 5059 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n3, n2));
/* 5060 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n0, n2));
/* 5061 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n1, n2));
/*      */       } 
/* 5063 */       if (t3 == null && leftOfPlane(n1, n0, n2, x, y, z)) {
/* 5064 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n1, n3));
/* 5065 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n0, n3));
/* 5066 */         findNodeNearestOutside(x, y, z, getNextTetOnHull(tet, n2, n3));
/*      */       } 
/* 5068 */       if (inSphere(n0, n1, n2, n3, x, y, z)) {
/* 5069 */         findNodeNearestOutside(x, y, z, t0);
/* 5070 */         findNodeNearestOutside(x, y, z, t1);
/* 5071 */         findNodeNearestOutside(x, y, z, t2);
/* 5072 */         findNodeNearestOutside(x, y, z, t3);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateNodeNearest(double x, double y, double z, Node n) {
/* 5085 */     if (!isMarked(n)) {
/* 5086 */       mark(n);
/* 5087 */       double d = distanceSquared(n, x, y, z);
/* 5088 */       if (d < this._dmin) {
/* 5089 */         this._dmin = d;
/* 5090 */         this._nmin = n;
/* 5091 */         this._nroot = n;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void linkTets(Tet tet, Node node, Tet tetNabor, Node nodeNabor) {
/* 5100 */     if (tet != null) {
/* 5101 */       if (node == tet._n0) {
/* 5102 */         tet._t0 = tetNabor;
/* 5103 */       } else if (node == tet._n1) {
/* 5104 */         tet._t1 = tetNabor;
/* 5105 */       } else if (node == tet._n2) {
/* 5106 */         tet._t2 = tetNabor;
/* 5107 */       } else if (node == tet._n3) {
/* 5108 */         tet._t3 = tetNabor;
/*      */       } else {
/* 5110 */         assert false : "node referenced by tet";
/*      */       } 
/*      */     }
/* 5113 */     if (tetNabor != null) {
/* 5114 */       if (nodeNabor == tetNabor._n0) {
/* 5115 */         tetNabor._t0 = tet;
/* 5116 */       } else if (nodeNabor == tetNabor._n1) {
/* 5117 */         tetNabor._t1 = tet;
/* 5118 */       } else if (nodeNabor == tetNabor._n2) {
/* 5119 */         tetNabor._t2 = tet;
/* 5120 */       } else if (nodeNabor == tetNabor._n3) {
/* 5121 */         tetNabor._t3 = tet;
/*      */       } else {
/* 5123 */         assert false : "nodeNabor referenced by tetNabor";
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void markAllTets(Tet tet) {
/* 5132 */     tet._mark = this._tetMarkRed;
/* 5133 */     Tet t0 = tet._t0;
/* 5134 */     if (t0 != null && t0._mark != this._tetMarkRed)
/* 5135 */       markAllTets(t0); 
/* 5136 */     Tet t1 = tet._t1;
/* 5137 */     if (t1 != null && t1._mark != this._tetMarkRed)
/* 5138 */       markAllTets(t1); 
/* 5139 */     Tet t2 = tet._t2;
/* 5140 */     if (t2 != null && t2._mark != this._tetMarkRed)
/* 5141 */       markAllTets(t2); 
/* 5142 */     Tet t3 = tet._t3;
/* 5143 */     if (t3 != null && t3._mark != this._tetMarkRed) {
/* 5144 */       markAllTets(t3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void zeroTetMarks(Tet tet) {
/* 5152 */     tet._mark = 0;
/* 5153 */     Tet t0 = tet._t0;
/* 5154 */     if (t0 != null && t0._mark != 0)
/* 5155 */       zeroTetMarks(t0); 
/* 5156 */     Tet t1 = tet._t1;
/* 5157 */     if (t1 != null && t1._mark != 0)
/* 5158 */       zeroTetMarks(t1); 
/* 5159 */     Tet t2 = tet._t2;
/* 5160 */     if (t2 != null && t2._mark != 0)
/* 5161 */       zeroTetMarks(t2); 
/* 5162 */     Tet t3 = tet._t3;
/* 5163 */     if (t3 != null && t3._mark != 0)
/* 5164 */       zeroTetMarks(t3); 
/*      */   }
/*      */   
/*      */   private Face getFaceOnHull(Tet tet) {
/* 5168 */     ArrayList<Tet> stack = new ArrayList<Tet>(128);
/* 5169 */     stack.add(tet);
/* 5170 */     while (!stack.isEmpty()) {
/* 5171 */       Tet t = stack.remove(stack.size() - 1);
/* 5172 */       mark(t);
/* 5173 */       if (t._t0 == null)
/* 5174 */         return new Face(t, t._n0); 
/* 5175 */       if (t._t1 == null)
/* 5176 */         return new Face(t, t._n1); 
/* 5177 */       if (t._t2 == null)
/* 5178 */         return new Face(t, t._n2); 
/* 5179 */       if (t._t3 == null)
/* 5180 */         return new Face(t, t._n3); 
/* 5181 */       if (!isMarked(t._t0))
/* 5182 */         stack.add(t._t0); 
/* 5183 */       if (!isMarked(t._t1))
/* 5184 */         stack.add(t._t1); 
/* 5185 */       if (!isMarked(t._t2))
/* 5186 */         stack.add(t._t2); 
/* 5187 */       if (!isMarked(t._t3))
/* 5188 */         stack.add(t._t3); 
/*      */     } 
/* 5190 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getFacesOnHull(Face face, HashSet<Face> faces) {
/* 5198 */     if (!faces.contains(face)) {
/* 5199 */       faces.add(face);
/* 5200 */       getFacesOnHull(getNextFaceOnHull(face.nodeA(), face), faces);
/* 5201 */       getFacesOnHull(getNextFaceOnHull(face.nodeB(), face), faces);
/* 5202 */       getFacesOnHull(getNextFaceOnHull(face.nodeC(), face), faces);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Face getNextFaceOnHull(Node node, Face face) {
/* 5211 */     Tet tet = face.tetLeft();
/* 5212 */     Node next = face.nodeLeft();
/* 5213 */     for (Tet tnext = tet.tetNabor(node); tnext != null; tnext = tet.tetNabor(node)) {
/* 5214 */       node = next;
/* 5215 */       next = tet.nodeNabor(tnext);
/* 5216 */       tet = tnext;
/*      */     } 
/* 5218 */     return new Face(tet, node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Edge edgeOfTet(Tet tet, Node na, Node nb) {
/* 5243 */     Node n0 = tet._n0;
/* 5244 */     Node n1 = tet._n1;
/* 5245 */     Node n2 = tet._n2;
/* 5246 */     Node n3 = tet._n3;
/* 5247 */     if (na == n0) {
/* 5248 */       if (nb == n1)
/* 5249 */         return new Edge(tet, n0, n1); 
/* 5250 */       if (nb == n2)
/* 5251 */         return new Edge(tet, n0, n2); 
/* 5252 */       if (nb == n3) {
/* 5253 */         return new Edge(tet, n0, n3);
/*      */       }
/* 5255 */       return null;
/*      */     } 
/* 5257 */     if (na == n1) {
/* 5258 */       if (nb == n0)
/* 5259 */         return new Edge(tet, n0, n1); 
/* 5260 */       if (nb == n2)
/* 5261 */         return new Edge(tet, n1, n2); 
/* 5262 */       if (nb == n3) {
/* 5263 */         return new Edge(tet, n1, n3);
/*      */       }
/* 5265 */       return null;
/*      */     } 
/* 5267 */     if (na == n2) {
/* 5268 */       if (nb == n0)
/* 5269 */         return new Edge(tet, n0, n2); 
/* 5270 */       if (nb == n1)
/* 5271 */         return new Edge(tet, n1, n2); 
/* 5272 */       if (nb == n3) {
/* 5273 */         return new Edge(tet, n2, n3);
/*      */       }
/* 5275 */       return null;
/*      */     } 
/* 5277 */     if (na == n3) {
/* 5278 */       if (nb == n0)
/* 5279 */         return new Edge(tet, n0, n3); 
/* 5280 */       if (nb == n1)
/* 5281 */         return new Edge(tet, n1, n3); 
/* 5282 */       if (nb == n2) {
/* 5283 */         return new Edge(tet, n2, n3);
/*      */       }
/* 5285 */       return null;
/*      */     } 
/*      */     
/* 5288 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Face faceOfTet(Tet tet, Node na, Node nb, Node nc) {
/* 5297 */     Node n0 = tet._n0;
/* 5298 */     Node n1 = tet._n1;
/* 5299 */     Node n2 = tet._n2;
/* 5300 */     Node n3 = tet._n3;
/* 5301 */     if (na == n0) {
/* 5302 */       if (nb == n1) {
/* 5303 */         if (nc == n2)
/* 5304 */           return new Face(tet, n3); 
/* 5305 */         if (nc == n3) {
/* 5306 */           return new Face(tet, n2);
/*      */         }
/* 5308 */         return null;
/*      */       } 
/* 5310 */       if (nb == n2) {
/* 5311 */         if (nc == n1)
/* 5312 */           return new Face(tet, n3); 
/* 5313 */         if (nc == n3) {
/* 5314 */           return new Face(tet, n1);
/*      */         }
/* 5316 */         return null;
/*      */       } 
/* 5318 */       if (nb == n3) {
/* 5319 */         if (nc == n1)
/* 5320 */           return new Face(tet, n2); 
/* 5321 */         if (nc == n2) {
/* 5322 */           return new Face(tet, n1);
/*      */         }
/* 5324 */         return null;
/*      */       } 
/*      */       
/* 5327 */       return null;
/*      */     } 
/* 5329 */     if (na == n1) {
/* 5330 */       if (nb == n0) {
/* 5331 */         if (nc == n2)
/* 5332 */           return new Face(tet, n3); 
/* 5333 */         if (nc == n3) {
/* 5334 */           return new Face(tet, n2);
/*      */         }
/* 5336 */         return null;
/*      */       } 
/* 5338 */       if (nb == n2) {
/* 5339 */         if (nc == n0)
/* 5340 */           return new Face(tet, n3); 
/* 5341 */         if (nc == n3) {
/* 5342 */           return new Face(tet, n0);
/*      */         }
/* 5344 */         return null;
/*      */       } 
/* 5346 */       if (nb == n3) {
/* 5347 */         if (nc == n0)
/* 5348 */           return new Face(tet, n2); 
/* 5349 */         if (nc == n2) {
/* 5350 */           return new Face(tet, n0);
/*      */         }
/* 5352 */         return null;
/*      */       } 
/*      */       
/* 5355 */       return null;
/*      */     } 
/* 5357 */     if (na == n2) {
/* 5358 */       if (nb == n0) {
/* 5359 */         if (nc == n1)
/* 5360 */           return new Face(tet, n3); 
/* 5361 */         if (nc == n3) {
/* 5362 */           return new Face(tet, n1);
/*      */         }
/* 5364 */         return null;
/*      */       } 
/* 5366 */       if (nb == n1) {
/* 5367 */         if (nc == n0)
/* 5368 */           return new Face(tet, n3); 
/* 5369 */         if (nc == n3) {
/* 5370 */           return new Face(tet, n0);
/*      */         }
/* 5372 */         return null;
/*      */       } 
/* 5374 */       if (nb == n3) {
/* 5375 */         if (nc == n0)
/* 5376 */           return new Face(tet, n1); 
/* 5377 */         if (nc == n1) {
/* 5378 */           return new Face(tet, n0);
/*      */         }
/* 5380 */         return null;
/*      */       } 
/*      */       
/* 5383 */       return null;
/*      */     } 
/* 5385 */     if (na == n3) {
/* 5386 */       if (nb == n0) {
/* 5387 */         if (nc == n1)
/* 5388 */           return new Face(tet, n2); 
/* 5389 */         if (nc == n2) {
/* 5390 */           return new Face(tet, n1);
/*      */         }
/* 5392 */         return null;
/*      */       } 
/* 5394 */       if (nb == n1) {
/* 5395 */         if (nc == n0)
/* 5396 */           return new Face(tet, n2); 
/* 5397 */         if (nc == n2) {
/* 5398 */           return new Face(tet, n0);
/*      */         }
/* 5400 */         return null;
/*      */       } 
/* 5402 */       if (nb == n2) {
/* 5403 */         if (nc == n0)
/* 5404 */           return new Face(tet, n1); 
/* 5405 */         if (nc == n1) {
/* 5406 */           return new Face(tet, n0);
/*      */         }
/* 5408 */         return null;
/*      */       } 
/*      */       
/* 5411 */       return null;
/*      */     } 
/*      */     
/* 5414 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean nodesInOrder(Tet tet, Node na, Node nb, Node nc, Node nd) {
/* 5554 */     Node n0 = tet._n0;
/* 5555 */     Node n1 = tet._n1;
/* 5556 */     Node n2 = tet._n2;
/* 5557 */     Node n3 = tet._n3;
/* 5558 */     if (na == n0) {
/* 5559 */       return ((nb == n1 && nc == n2 && nd == n3) || (nb == n2 && nc == n3 && nd == n1) || (nb == n3 && nc == n1 && nd == n2));
/*      */     }
/*      */     
/* 5562 */     if (na == n1) {
/* 5563 */       return ((nb == n2 && nc == n0 && nd == n3) || (nb == n3 && nc == n2 && nd == n0) || (nb == n0 && nc == n3 && nd == n2));
/*      */     }
/*      */     
/* 5566 */     if (na == n2) {
/* 5567 */       return ((nb == n3 && nc == n0 && nd == n1) || (nb == n0 && nc == n1 && nd == n3) || (nb == n1 && nc == n3 && nd == n0));
/*      */     }
/*      */     
/* 5570 */     if (na == n3) {
/* 5571 */       return ((nb == n0 && nc == n2 && nd == n1) || (nb == n1 && nc == n0 && nd == n2) || (nb == n2 && nc == n1 && nd == n0));
/*      */     }
/*      */ 
/*      */     
/* 5575 */     assert false : "tet references na";
/* 5576 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Node otherNode(Tet tet, Node na, Node nb, Node nc) {
/* 5586 */     Node n0 = tet._n0;
/* 5587 */     Node n1 = tet._n1;
/* 5588 */     Node n2 = tet._n2;
/* 5589 */     Node n3 = tet._n3;
/* 5590 */     if (na == n0) {
/* 5591 */       if (nb == n1) {
/* 5592 */         if (nc == n2)
/* 5593 */           return n3; 
/* 5594 */         if (nc == n3) {
/* 5595 */           return n2;
/*      */         }
/* 5597 */         return null;
/*      */       } 
/* 5599 */       if (nb == n2) {
/* 5600 */         if (nc == n1)
/* 5601 */           return n3; 
/* 5602 */         if (nc == n3) {
/* 5603 */           return n1;
/*      */         }
/* 5605 */         return null;
/*      */       } 
/* 5607 */       if (nb == n3) {
/* 5608 */         if (nc == n1)
/* 5609 */           return n2; 
/* 5610 */         if (nc == n2) {
/* 5611 */           return n1;
/*      */         }
/* 5613 */         return null;
/*      */       } 
/*      */       
/* 5616 */       return null;
/*      */     } 
/* 5618 */     if (na == n1) {
/* 5619 */       if (nb == n0) {
/* 5620 */         if (nc == n2)
/* 5621 */           return n3; 
/* 5622 */         if (nc == n3) {
/* 5623 */           return n2;
/*      */         }
/* 5625 */         return null;
/*      */       } 
/* 5627 */       if (nb == n2) {
/* 5628 */         if (nc == n0)
/* 5629 */           return n3; 
/* 5630 */         if (nc == n3) {
/* 5631 */           return n0;
/*      */         }
/* 5633 */         return null;
/*      */       } 
/* 5635 */       if (nb == n3) {
/* 5636 */         if (nc == n0)
/* 5637 */           return n2; 
/* 5638 */         if (nc == n2) {
/* 5639 */           return n0;
/*      */         }
/* 5641 */         return null;
/*      */       } 
/*      */       
/* 5644 */       return null;
/*      */     } 
/* 5646 */     if (na == n2) {
/* 5647 */       if (nb == n0) {
/* 5648 */         if (nc == n1)
/* 5649 */           return n3; 
/* 5650 */         if (nc == n3) {
/* 5651 */           return n1;
/*      */         }
/* 5653 */         return null;
/*      */       } 
/* 5655 */       if (nb == n1) {
/* 5656 */         if (nc == n0)
/* 5657 */           return n3; 
/* 5658 */         if (nc == n3) {
/* 5659 */           return n0;
/*      */         }
/* 5661 */         return null;
/*      */       } 
/* 5663 */       if (nb == n3) {
/* 5664 */         if (nc == n0)
/* 5665 */           return n1; 
/* 5666 */         if (nc == n1) {
/* 5667 */           return n0;
/*      */         }
/* 5669 */         return null;
/*      */       } 
/*      */       
/* 5672 */       return null;
/*      */     } 
/* 5674 */     if (na == n3) {
/* 5675 */       if (nb == n0) {
/* 5676 */         if (nc == n1)
/* 5677 */           return n2; 
/* 5678 */         if (nc == n2) {
/* 5679 */           return n1;
/*      */         }
/* 5681 */         return null;
/*      */       } 
/* 5683 */       if (nb == n1) {
/* 5684 */         if (nc == n0)
/* 5685 */           return n2; 
/* 5686 */         if (nc == n2) {
/* 5687 */           return n0;
/*      */         }
/* 5689 */         return null;
/*      */       } 
/* 5691 */       if (nb == n2) {
/* 5692 */         if (nc == n0)
/* 5693 */           return n1; 
/* 5694 */         if (nc == n1) {
/* 5695 */           return n0;
/*      */         }
/* 5697 */         return null;
/*      */       } 
/*      */       
/* 5700 */       return null;
/*      */     } 
/*      */     
/* 5703 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void markTetInnerOrOuter(Tet tet) {
/* 5712 */     assert this._xminOuter < this._xmaxOuter : "outer box is valid";
/* 5713 */     assert this._yminOuter < this._ymaxOuter : "outer box is valid";
/* 5714 */     assert this._zminOuter < this._zmaxOuter : "outer box is valid";
/* 5715 */     double[] po = { 0.0D, 0.0D, 0.0D };
/* 5716 */     double s = tet.centerSphere(po);
/* 5717 */     double r = MathPlus.sqrt(s);
/* 5718 */     double xo = po[0];
/* 5719 */     double yo = po[1];
/* 5720 */     double zo = po[2];
/* 5721 */     if (xo - r >= this._xminOuter && yo - r >= this._yminOuter && zo - r >= this._zminOuter && xo + r <= this._xmaxOuter && yo + r <= this._ymaxOuter && zo + r <= this._zmaxOuter) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5727 */       tet.setInner();
/* 5728 */       tet.clearOuter();
/*      */     } else {
/* 5730 */       tet.setOuter();
/* 5731 */       tet.clearInner();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fireNodeWillBeAdded(Node node) {
/* 5736 */     this._version++;
/* 5737 */     if (this._nnodeListeners > 0) {
/* 5738 */       Object[] list = this._listeners.getListenerList();
/* 5739 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5740 */         if (list[i] == NodeListener.class)
/* 5741 */           ((NodeListener)list[i + 1]).nodeWillBeAdded(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeAdded(Node node) {
/* 5746 */     this._version++;
/* 5747 */     if (this._nnodeListeners > 0) {
/* 5748 */       Object[] list = this._listeners.getListenerList();
/* 5749 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5750 */         if (list[i] == NodeListener.class)
/* 5751 */           ((NodeListener)list[i + 1]).nodeAdded(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeWillBeRemoved(Node node) {
/* 5756 */     this._version++;
/* 5757 */     if (this._nnodeListeners > 0) {
/* 5758 */       Object[] list = this._listeners.getListenerList();
/* 5759 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5760 */         if (list[i] == NodeListener.class)
/* 5761 */           ((NodeListener)list[i + 1]).nodeWillBeRemoved(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireNodeRemoved(Node node) {
/* 5766 */     this._version++;
/* 5767 */     if (this._nnodeListeners > 0) {
/* 5768 */       Object[] list = this._listeners.getListenerList();
/* 5769 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5770 */         if (list[i] == NodeListener.class)
/* 5771 */           ((NodeListener)list[i + 1]).nodeRemoved(this, node); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireTetAdded(Tet tet) {
/* 5776 */     this._version++;
/* 5777 */     if (this._ntetListeners > 0) {
/* 5778 */       Object[] list = this._listeners.getListenerList();
/* 5779 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5780 */         if (list[i] == TetListener.class)
/* 5781 */           ((TetListener)list[i + 1]).tetAdded(this, tet); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private void fireTetRemoved(Tet tet) {
/* 5786 */     this._version++;
/* 5787 */     if (this._ntetListeners > 0) {
/* 5788 */       Object[] list = this._listeners.getListenerList();
/* 5789 */       for (int i = list.length - 2; i >= 0; i -= 2) {
/* 5790 */         if (list[i] == TetListener.class) {
/* 5791 */           ((TetListener)list[i + 1]).tetRemoved(this, tet);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validate(Node node) {
/* 5799 */     Check.state((node == node._prev._next), "node==node._prev._next");
/* 5800 */     Check.state((node == node._next._prev), "node==node._next._prev");
/* 5801 */     Tet tet = node.tet();
/* 5802 */     if (this._troot != null) {
/* 5803 */       Check.state((tet != null), "tet!=null");
/* 5804 */       Check.state((node == tet.nodeA() || node == tet.nodeB() || node == tet.nodeC() || node == tet.nodeD()), "node is one of tet nodes");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validate(Tet tet) {
/* 5816 */     Node na = tet.nodeA();
/* 5817 */     Node nb = tet.nodeB();
/* 5818 */     Node nc = tet.nodeC();
/* 5819 */     Node nd = tet.nodeD();
/* 5820 */     if (!leftOfPlane(na, nb, nc, nd)) {
/* 5821 */       trace("xa=" + na._x + " ya=" + na._y + " za=" + na._z);
/* 5822 */       trace("xb=" + nb._x + " yb=" + nb._y + " zb=" + nb._z);
/* 5823 */       trace("xc=" + nc._x + " yc=" + nc._y + " zc=" + nc._z);
/* 5824 */       trace("xd=" + nd._x + " yd=" + nd._y + " zd=" + nd._z);
/*      */     } 
/* 5826 */     Check.state(leftOfPlane(na, nb, nc, nd), "leftOfPlane(na,nb,nc,nd)");
/* 5827 */     validate(na);
/* 5828 */     validate(nb);
/* 5829 */     validate(nc);
/* 5830 */     validate(nd);
/* 5831 */     Tet ta = tet.tetA();
/* 5832 */     Tet tb = tet.tetB();
/* 5833 */     Tet tc = tet.tetC();
/* 5834 */     Tet td = tet.tetD();
/* 5835 */     if (ta != null)
/* 5836 */       Check.state((ta.tetNabor(tet.nodeNabor(ta)) == tet), "a nabor ok"); 
/* 5837 */     if (tb != null)
/* 5838 */       Check.state((tb.tetNabor(tet.nodeNabor(tb)) == tet), "b nabor ok"); 
/* 5839 */     if (tc != null)
/* 5840 */       Check.state((tc.tetNabor(tet.nodeNabor(tc)) == tet), "c nabor ok"); 
/* 5841 */     if (td != null) {
/* 5842 */       Check.state((td.tetNabor(tet.nodeNabor(td)) == tet), "d nabor ok");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final void trace(String s) {}
/*      */ 
/*      */   
/*      */   private static final class FaceSet
/*      */   {
/*      */     TetMesh.Node a;
/*      */     
/*      */     TetMesh.Node b;
/*      */     
/*      */     TetMesh.Node c;
/*      */     
/*      */     TetMesh.Node d;
/*      */     
/*      */     TetMesh.Tet abcd;
/*      */     
/*      */     private static final int MAX_SHIFT = 30;
/*      */     
/*      */     private static final int MAX_CAPACITY = 1073741824;
/*      */     
/*      */     private TetMesh.Node[] _a;
/*      */     
/*      */     private TetMesh.Node[] _b;
/*      */     
/*      */     private TetMesh.Node[] _c;
/*      */     
/*      */     private TetMesh.Node[] _d;
/*      */     
/*      */     private TetMesh.Tet[] _abcd;
/*      */     
/*      */     private boolean[] _filled;
/*      */     
/*      */     private int _nmax;
/*      */     
/*      */     private int _n;
/*      */     
/*      */     private double _factor;
/*      */     
/*      */     private int _shift;
/*      */     private int _mask;
/*      */     private int _index;
/*      */     
/*      */     FaceSet(int capacity, double factor) {
/* 5889 */       if (capacity > 1073741824) capacity = 1073741824; 
/* 5890 */       if (factor <= 0.0D) factor = 1.0E-4D; 
/* 5891 */       if (factor >= 1.0D) factor = 0.9999D; 
/* 5892 */       for (this._nmax = 2, this._shift = 30; this._nmax < capacity; this._nmax *= 2)
/* 5893 */         this._shift--; 
/* 5894 */       this._n = 0;
/* 5895 */       this._factor = factor;
/* 5896 */       this._mask = this._nmax - 1;
/* 5897 */       this._a = new TetMesh.Node[this._nmax];
/* 5898 */       this._b = new TetMesh.Node[this._nmax];
/* 5899 */       this._c = new TetMesh.Node[this._nmax];
/* 5900 */       this._d = new TetMesh.Node[this._nmax];
/* 5901 */       this._abcd = new TetMesh.Tet[this._nmax];
/* 5902 */       this._filled = new boolean[this._nmax];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 5909 */       this._n = 0;
/* 5910 */       for (int i = 0; i < this._nmax; i++) {
/* 5911 */         this._filled[i] = false;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean add(TetMesh.Tet tet, TetMesh.Node node) {
/* 5923 */       if (node == tet._n0)
/* 5924 */         return add(tet._n1, tet._n3, tet._n2, node, tet); 
/* 5925 */       if (node == tet._n1)
/* 5926 */         return add(tet._n2, tet._n3, tet._n0, node, tet); 
/* 5927 */       if (node == tet._n2)
/* 5928 */         return add(tet._n3, tet._n1, tet._n0, node, tet); 
/* 5929 */       if (node == tet._n3) {
/* 5930 */         return add(tet._n0, tet._n1, tet._n2, node, tet);
/*      */       }
/* 5932 */       assert false : "node is referenced by tet";
/* 5933 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean addMate(TetMesh.Tet tet, TetMesh.Node node) {
/* 5947 */       TetMesh.Tet tetNabor = tet.tetNabor(node);
/* 5948 */       TetMesh.Node nodeNabor = (tetNabor != null) ? tet.nodeNabor(tetNabor) : null;
/* 5949 */       if (node == tet._n0)
/* 5950 */         return add(tet._n1, tet._n2, tet._n3, nodeNabor, tetNabor); 
/* 5951 */       if (node == tet._n1)
/* 5952 */         return add(tet._n3, tet._n2, tet._n0, nodeNabor, tetNabor); 
/* 5953 */       if (node == tet._n2)
/* 5954 */         return add(tet._n3, tet._n0, tet._n1, nodeNabor, tetNabor); 
/* 5955 */       if (node == tet._n3) {
/* 5956 */         return add(tet._n1, tet._n0, tet._n2, nodeNabor, tetNabor);
/*      */       }
/* 5958 */       assert false : "node is referenced by tet";
/* 5959 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean remove() {
/* 5969 */       if (this._n > 0) {
/* 5970 */         int start = this._index;
/* 5971 */         for (; this._index < this._nmax; this._index++) {
/* 5972 */           if (this._filled[this._index]) {
/* 5973 */             setCurrent();
/* 5974 */             remove(this._index);
/* 5975 */             return true;
/*      */           } 
/*      */         } 
/* 5978 */         for (this._index = 0; this._index < start; this._index++) {
/* 5979 */           if (this._filled[this._index]) {
/* 5980 */             setCurrent();
/* 5981 */             remove(this._index);
/* 5982 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/* 5986 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isEmpty() {
/* 5994 */       return (this._n > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean first() {
/* 6003 */       this._index = -1;
/* 6004 */       return next();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean next() {
/* 6013 */       this._index++; for (; this._index < this._nmax; this._index++) {
/* 6014 */         if (this._filled[this._index]) {
/* 6015 */           setCurrent();
/* 6016 */           return true;
/*      */         } 
/*      */       } 
/* 6019 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hash(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c) {
/* 6040 */       int key = a._hash ^ b._hash ^ c._hash;
/*      */ 
/*      */ 
/*      */       
/* 6044 */       return 1327217885 * key >> this._shift & this._mask;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int indexOfMate(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c) {
/* 6052 */       int i = hash(a, b, c);
/* 6053 */       while (this._filled[i]) {
/* 6054 */         TetMesh.Node ai = this._a[i];
/* 6055 */         TetMesh.Node bi = this._b[i];
/* 6056 */         TetMesh.Node ci = this._c[i];
/* 6057 */         if ((a == ai && b == ci && c == bi) || (a == bi && b == ai && c == ci) || (a == ci && b == bi && c == ai))
/*      */         {
/*      */           
/* 6060 */           return i; } 
/* 6061 */         i = i - 1 & this._mask;
/*      */       } 
/* 6063 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setCurrent() {
/* 6070 */       this.a = this._a[this._index];
/* 6071 */       this.b = this._b[this._index];
/* 6072 */       this.c = this._c[this._index];
/* 6073 */       this.d = this._d[this._index];
/* 6074 */       this.abcd = this._abcd[this._index];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean add(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c, TetMesh.Node d, TetMesh.Tet abcd) {
/* 6084 */       this._index = indexOfMate(a, b, c);
/* 6085 */       if (this._filled[this._index]) {
/* 6086 */         setCurrent();
/* 6087 */         remove(this._index);
/* 6088 */         return false;
/*      */       } 
/* 6090 */       this._a[this._index] = a;
/* 6091 */       this._b[this._index] = b;
/* 6092 */       this._c[this._index] = c;
/* 6093 */       this._d[this._index] = d;
/* 6094 */       this._abcd[this._index] = abcd;
/* 6095 */       this._filled[this._index] = true;
/* 6096 */       this._n++;
/* 6097 */       if (this._n > this._nmax * this._factor && this._nmax < 1073741824)
/* 6098 */         doubleCapacity(); 
/* 6099 */       setCurrent();
/* 6100 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void remove(int i) {
/* 6109 */       this._n--; while (true) {
/*      */         int r;
/* 6111 */         this._filled[i] = false;
/* 6112 */         int j = i;
/*      */         
/*      */         do {
/* 6115 */           i = i - 1 & this._mask;
/* 6116 */           if (!this._filled[i])
/*      */             return; 
/* 6118 */           r = hash(this._a[i], this._b[i], this._c[i]);
/* 6119 */         } while ((i <= r && r < j) || (r < j && j < i) || (j < i && i <= r));
/* 6120 */         this._a[j] = this._a[i];
/* 6121 */         this._b[j] = this._b[i];
/* 6122 */         this._c[j] = this._c[i];
/* 6123 */         this._d[j] = this._d[i];
/* 6124 */         this._abcd[j] = this._abcd[i];
/* 6125 */         this._filled[j] = this._filled[i];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doubleCapacity() {
/* 6134 */       FaceSet set = new FaceSet(2 * this._nmax, this._factor);
/* 6135 */       if (this._n > 0)
/* 6136 */         for (int i = 0; i < this._nmax; i++) {
/* 6137 */           if (this._filled[i]) {
/* 6138 */             set.add(this._a[i], this._b[i], this._c[i], this._d[i], this._abcd[i]);
/*      */           }
/*      */         }  
/* 6141 */       this._a = set._a;
/* 6142 */       this._b = set._b;
/* 6143 */       this._c = set._c;
/* 6144 */       this._d = set._d;
/* 6145 */       this._abcd = set._abcd;
/* 6146 */       this._filled = set._filled;
/* 6147 */       this._nmax = set._nmax;
/* 6148 */       this._n = set._n;
/* 6149 */       this._factor = set._factor;
/* 6150 */       this._shift = set._shift;
/* 6151 */       this._mask = set._mask;
/* 6152 */       this._index = set._index;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class EdgeSet
/*      */   {
/*      */     TetMesh.Node a;
/*      */     
/*      */     TetMesh.Node b;
/*      */     TetMesh.Node c;
/*      */     TetMesh.Tet nabc;
/*      */     private static final int MAX_SHIFT = 30;
/*      */     private static final int MAX_CAPACITY = 1073741824;
/*      */     private TetMesh.Node[] _a;
/*      */     private TetMesh.Node[] _b;
/*      */     private TetMesh.Node[] _c;
/*      */     private TetMesh.Tet[] _nabc;
/*      */     private boolean[] _filled;
/*      */     private int _nmax;
/*      */     private int _n;
/*      */     private double _factor;
/*      */     private int _shift;
/*      */     private int _mask;
/*      */     private int _index;
/*      */     
/*      */     EdgeSet(int capacity, double factor) {
/* 6179 */       if (capacity > 1073741824) capacity = 1073741824; 
/* 6180 */       if (factor <= 0.0D) factor = 1.0E-4D; 
/* 6181 */       if (factor >= 1.0D) factor = 0.9999D; 
/* 6182 */       for (this._nmax = 2, this._shift = 30; this._nmax < capacity; this._nmax *= 2)
/* 6183 */         this._shift--; 
/* 6184 */       this._n = 0;
/* 6185 */       this._factor = factor;
/* 6186 */       this._mask = this._nmax - 1;
/* 6187 */       this._a = new TetMesh.Node[this._nmax];
/* 6188 */       this._b = new TetMesh.Node[this._nmax];
/* 6189 */       this._c = new TetMesh.Node[this._nmax];
/* 6190 */       this._nabc = new TetMesh.Tet[this._nmax];
/* 6191 */       this._filled = new boolean[this._nmax];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 6198 */       this._n = 0;
/* 6199 */       for (int i = 0; i < this._nmax; i++) {
/* 6200 */         this._filled[i] = false;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean add(TetMesh.Node a, TetMesh.Node b, TetMesh.Node c, TetMesh.Tet nabc) {
/* 6210 */       this._index = indexOfMate(a, b);
/* 6211 */       if (this._filled[this._index]) {
/* 6212 */         setCurrent();
/* 6213 */         remove(this._index);
/* 6214 */         return false;
/*      */       } 
/* 6216 */       this._a[this._index] = a;
/* 6217 */       this._b[this._index] = b;
/* 6218 */       this._c[this._index] = c;
/* 6219 */       this._nabc[this._index] = nabc;
/* 6220 */       this._filled[this._index] = true;
/* 6221 */       this._n++;
/* 6222 */       if (this._n > this._nmax * this._factor && this._nmax < 1073741824)
/* 6223 */         doubleCapacity(); 
/* 6224 */       setCurrent();
/* 6225 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     int size() {
/* 6230 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int hash(TetMesh.Node a, TetMesh.Node b) {
/* 6251 */       int key = a._hash ^ b._hash;
/*      */ 
/*      */ 
/*      */       
/* 6255 */       return 1327217885 * key >> this._shift & this._mask;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int indexOfMate(TetMesh.Node a, TetMesh.Node b) {
/* 6263 */       int i = hash(a, b);
/* 6264 */       while (this._filled[i]) {
/* 6265 */         if (a == this._b[i] && b == this._a[i])
/* 6266 */           return i; 
/* 6267 */         i = i - 1 & this._mask;
/*      */       } 
/* 6269 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setCurrent() {
/* 6276 */       this.a = this._a[this._index];
/* 6277 */       this.b = this._b[this._index];
/* 6278 */       this.c = this._c[this._index];
/* 6279 */       this.nabc = this._nabc[this._index];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void remove(int i) {
/* 6287 */       this._n--; while (true) {
/*      */         int r;
/* 6289 */         this._filled[i] = false;
/* 6290 */         int j = i;
/*      */         
/*      */         do {
/* 6293 */           i = i - 1 & this._mask;
/* 6294 */           if (!this._filled[i])
/*      */             return; 
/* 6296 */           r = hash(this._a[i], this._b[i]);
/* 6297 */         } while ((i <= r && r < j) || (r < j && j < i) || (j < i && i <= r));
/* 6298 */         this._a[j] = this._a[i];
/* 6299 */         this._b[j] = this._b[i];
/* 6300 */         this._c[j] = this._c[i];
/* 6301 */         this._nabc[j] = this._nabc[i];
/* 6302 */         this._filled[j] = this._filled[i];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doubleCapacity() {
/* 6311 */       EdgeSet set = new EdgeSet(2 * this._nmax, this._factor);
/* 6312 */       if (this._n > 0)
/* 6313 */         for (int i = 0; i < this._nmax; i++) {
/* 6314 */           if (this._filled[i]) {
/* 6315 */             set.add(this._a[i], this._b[i], this._c[i], this._nabc[i]);
/*      */           }
/*      */         }  
/* 6318 */       this._a = set._a;
/* 6319 */       this._b = set._b;
/* 6320 */       this._c = set._c;
/* 6321 */       this._nabc = set._nabc;
/* 6322 */       this._filled = set._filled;
/* 6323 */       this._nmax = set._nmax;
/* 6324 */       this._n = set._n;
/* 6325 */       this._factor = set._factor;
/* 6326 */       this._shift = set._shift;
/* 6327 */       this._mask = set._mask;
/* 6328 */       this._index = set._index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 6337 */     init();
/*      */ 
/*      */     
/* 6340 */     int format = in.readInt();
/* 6341 */     if (format == 1) {
/*      */ 
/*      */       
/* 6344 */       this._version = in.readLong();
/*      */ 
/*      */       
/* 6347 */       int nnode = this._nnode = in.readInt();
/* 6348 */       Node[] nodes = new Node[nnode];
/* 6349 */       for (int inode = 0; inode < nnode; inode++) {
/* 6350 */         Node node = nodes[inode] = (Node)in.readObject();
/* 6351 */         node._x = in.readDouble();
/* 6352 */         node._y = in.readDouble();
/* 6353 */         node._z = in.readDouble();
/* 6354 */         int nvalue = in.readInt();
/* 6355 */         node._values = new Object[nvalue];
/* 6356 */         for (int ivalue = 0; ivalue < nvalue; ivalue++) {
/* 6357 */           Object value = in.readObject();
/* 6358 */           node._values[ivalue] = value;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 6363 */       int ntet = this._ntet = in.readInt();
/* 6364 */       Tet[] tets = new Tet[ntet];
/* 6365 */       for (int j = 0; j < ntet; j++) {
/* 6366 */         Tet tet = tets[j] = (Tet)in.readObject();
/* 6367 */         tet._quality = -1.0D;
/*      */       } 
/*      */ 
/*      */       
/* 6371 */       this._nroot = (Node)in.readObject();
/* 6372 */       for (int i = 0; i < nnode; i++) {
/* 6373 */         Node node = nodes[i];
/* 6374 */         node._prev = (Node)in.readObject();
/* 6375 */         node._next = (Node)in.readObject();
/* 6376 */         node._tet = (Tet)in.readObject();
/*      */       } 
/*      */ 
/*      */       
/* 6380 */       this._troot = (Tet)in.readObject();
/* 6381 */       for (int itet = 0; itet < ntet; itet++) {
/* 6382 */         Tet tet = tets[itet];
/* 6383 */         tet._n0 = (Node)in.readObject();
/* 6384 */         tet._n1 = (Node)in.readObject();
/* 6385 */         tet._n2 = (Node)in.readObject();
/* 6386 */         tet._n3 = (Node)in.readObject();
/* 6387 */         tet._t0 = (Tet)in.readObject();
/* 6388 */         tet._t1 = (Tet)in.readObject();
/* 6389 */         tet._t2 = (Tet)in.readObject();
/* 6390 */         tet._t3 = (Tet)in.readObject();
/*      */       } 
/*      */ 
/*      */       
/* 6394 */       this._outerEnabled = in.readBoolean();
/* 6395 */       this._xminOuter = in.readDouble();
/* 6396 */       this._yminOuter = in.readDouble();
/* 6397 */       this._zminOuter = in.readDouble();
/* 6398 */       this._xmaxOuter = in.readDouble();
/* 6399 */       this._ymaxOuter = in.readDouble();
/* 6400 */       this._zmaxOuter = in.readDouble();
/*      */ 
/*      */       
/* 6403 */       this._nnodeValues = in.readInt();
/* 6404 */       this._lnodeValues = in.readInt();
/* 6405 */       this._nodePropertyMaps = (Map<String, NodePropertyMap>)in.readObject();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 6410 */       throw new InvalidClassException("invalid external format");
/*      */     } 
/*      */ 
/*      */     
/* 6414 */     sampleNodes();
/*      */ 
/*      */     
/*      */     try {
/* 6418 */       validate();
/* 6419 */     } catch (IllegalStateException ise) {
/* 6420 */       throw new IOException(ise.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 6429 */     out.writeInt(1);
/*      */ 
/*      */     
/* 6432 */     out.writeLong(this._version);
/*      */ 
/*      */     
/* 6435 */     int nnode = this._nnode;
/* 6436 */     out.writeInt(nnode);
/* 6437 */     Node[] nodes = new Node[nnode];
/* 6438 */     NodeIterator ni = getNodes();
/* 6439 */     for (int inode = 0; inode < nnode; inode++) {
/* 6440 */       Node node = nodes[inode] = ni.next();
/* 6441 */       out.writeObject(node);
/* 6442 */       out.writeDouble(node._x);
/* 6443 */       out.writeDouble(node._y);
/* 6444 */       out.writeDouble(node._z);
/* 6445 */       int nvalue = node._values.length;
/* 6446 */       out.writeInt(nvalue);
/* 6447 */       for (int ivalue = 0; ivalue < nvalue; ivalue++) {
/* 6448 */         Object value = node._values[ivalue];
/* 6449 */         out.writeObject((value instanceof Serializable) ? value : null);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 6454 */     int ntet = this._ntet;
/* 6455 */     out.writeInt(ntet);
/* 6456 */     Tet[] tets = new Tet[ntet];
/* 6457 */     TetIterator ti = getTets();
/* 6458 */     for (int j = 0; j < ntet; j++) {
/* 6459 */       Tet tet = tets[j] = ti.next();
/* 6460 */       out.writeObject(tet);
/*      */     } 
/*      */ 
/*      */     
/* 6464 */     out.writeObject(this._nroot);
/* 6465 */     for (int i = 0; i < nnode; i++) {
/* 6466 */       Node node = nodes[i];
/* 6467 */       out.writeObject(node._prev);
/* 6468 */       out.writeObject(node._next);
/* 6469 */       out.writeObject(node._tet);
/*      */     } 
/*      */ 
/*      */     
/* 6473 */     out.writeObject(this._troot);
/* 6474 */     for (int itet = 0; itet < ntet; itet++) {
/* 6475 */       Tet tet = tets[itet];
/* 6476 */       out.writeObject(tet._n0);
/* 6477 */       out.writeObject(tet._n1);
/* 6478 */       out.writeObject(tet._n2);
/* 6479 */       out.writeObject(tet._n3);
/* 6480 */       out.writeObject(tet._t0);
/* 6481 */       out.writeObject(tet._t1);
/* 6482 */       out.writeObject(tet._t2);
/* 6483 */       out.writeObject(tet._t3);
/*      */     } 
/*      */ 
/*      */     
/* 6487 */     out.writeBoolean(this._outerEnabled);
/* 6488 */     out.writeDouble(this._xminOuter);
/* 6489 */     out.writeDouble(this._yminOuter);
/* 6490 */     out.writeDouble(this._zminOuter);
/* 6491 */     out.writeDouble(this._xmaxOuter);
/* 6492 */     out.writeDouble(this._ymaxOuter);
/* 6493 */     out.writeDouble(this._zmaxOuter);
/*      */ 
/*      */     
/* 6496 */     out.writeInt(this._nnodeValues);
/* 6497 */     out.writeInt(this._lnodeValues);
/* 6498 */     out.writeObject(this._nodePropertyMaps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sampleNodes() {
/* 6508 */     Random random = new Random();
/* 6509 */     this._sampledNodes.clear();
/* 6510 */     int nsamp = 2 * (int)MathPlus.pow(this._nnode, 0.25D);
/* 6511 */     Node node = this._nroot;
/* 6512 */     while (this._sampledNodes.size() < nsamp) {
/* 6513 */       int nskip = 1 + random.nextInt(this._nnode / 2);
/* 6514 */       while (--nskip > 0)
/* 6515 */         node = node._next; 
/* 6516 */       this._sampledNodes.add(node);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static interface TetListener extends EventListener {
/*      */     void tetAdded(TetMesh param1TetMesh, TetMesh.Tet param1Tet);
/*      */     
/*      */     void tetRemoved(TetMesh param1TetMesh, TetMesh.Tet param1Tet);
/*      */   }
/*      */   
/*      */   public static interface NodeListener extends EventListener {
/*      */     void nodeWillBeAdded(TetMesh param1TetMesh, TetMesh.Node param1Node);
/*      */     
/*      */     void nodeAdded(TetMesh param1TetMesh, TetMesh.Node param1Node);
/*      */     
/*      */     void nodeWillBeRemoved(TetMesh param1TetMesh, TetMesh.Node param1Node);
/*      */     
/*      */     void nodeRemoved(TetMesh param1TetMesh, TetMesh.Node param1Node);
/*      */   }
/*      */   
/*      */   public static interface NodePropertyMap extends Serializable {
/*      */     Object get(TetMesh.Node param1Node);
/*      */     
/*      */     void put(TetMesh.Node param1Node, Object param1Object);
/*      */   }
/*      */   
/*      */   public static interface FaceIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TetMesh.Face next();
/*      */   }
/*      */   
/*      */   public static interface EdgeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TetMesh.Edge next();
/*      */   }
/*      */   
/*      */   public static interface TetIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TetMesh.Tet next();
/*      */   }
/*      */   
/*      */   public static interface NodeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TetMesh.Node next();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/TetMesh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */