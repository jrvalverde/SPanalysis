/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LocalCausalFilter
/*      */ {
/*      */   private int _m;
/*      */   private int _min1;
/*      */   private int _max1;
/*      */   private int _min2;
/*      */   private int _max2;
/*      */   private int _min3;
/*      */   private int _max3;
/*      */   private int[] _lag1;
/*      */   private int[] _lag2;
/*      */   private int[] _lag3;
/*      */   
/*      */   public LocalCausalFilter(int[] lag1) {
/*  102 */     initLags(lag1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalCausalFilter(int[] lag1, int[] lag2) {
/*  116 */     initLags(lag1, lag2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalCausalFilter(int[] lag1, int[] lag2, int[] lag3) {
/*  131 */     initLags(lag1, lag2, lag3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag1() {
/*  139 */     return Array.copy(this._lag1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag2() {
/*  147 */     return Array.copy(this._lag2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag3() {
/*  155 */     return Array.copy(this._lag3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(A1 a1, float[] x, float[] y) {
/*  180 */     float[] a = new float[this._m];
/*  181 */     int n1 = x.length;
/*  182 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  183 */     for (i1 = n1 - 1; i1 >= i1lo; i1--) {
/*  184 */       a1.get(i1, a);
/*  185 */       float yi = a[0] * x[i1];
/*  186 */       for (int j = 1; j < this._m; j++) {
/*  187 */         int k1 = i1 - this._lag1[j];
/*  188 */         yi += a[j] * x[k1];
/*      */       } 
/*  190 */       y[i1] = yi;
/*      */     } 
/*  192 */     for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  193 */       a1.get(i1, a);
/*  194 */       float yi = a[0] * x[i1];
/*  195 */       for (int j = 1; j < this._m; j++) {
/*  196 */         int k1 = i1 - this._lag1[j];
/*  197 */         if (0 <= k1)
/*  198 */           yi += a[j] * x[k1]; 
/*      */       } 
/*  200 */       y[i1] = yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(A1 a1, float[] x, float[] y) {
/*  214 */     float[] a = new float[this._m];
/*  215 */     int n1 = x.length;
/*  216 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  217 */     for (i1 = 0; i1 < i1lo; i1++) {
/*  218 */       a1.get(i1, a);
/*  219 */       float xi = x[i1];
/*  220 */       y[i1] = a[0] * xi;
/*  221 */       for (int j = 1; j < this._m; j++) {
/*  222 */         int k1 = i1 - this._lag1[j];
/*  223 */         if (0 <= k1)
/*  224 */           y[k1] = y[k1] + a[j] * xi; 
/*      */       } 
/*      */     } 
/*  227 */     for (i1 = i1lo; i1 < n1; i1++) {
/*  228 */       a1.get(i1, a);
/*  229 */       float xi = x[i1];
/*  230 */       y[i1] = a[0] * xi;
/*  231 */       for (int j = 1; j < this._m; j++) {
/*  232 */         int k1 = i1 - this._lag1[j];
/*  233 */         y[k1] = y[k1] + a[j] * xi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(A1 a1, float[] y, float[] x) {
/*  248 */     float[] a = new float[this._m];
/*  249 */     int n1 = y.length;
/*  250 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  251 */     for (i1 = 0; i1 < i1lo; i1++) {
/*  252 */       a1.get(i1, a);
/*  253 */       float xi = 0.0F;
/*  254 */       for (int j = 1; j < this._m; j++) {
/*  255 */         int k1 = i1 - this._lag1[j];
/*  256 */         if (0 <= k1)
/*  257 */           xi += a[j] * x[k1]; 
/*      */       } 
/*  259 */       x[i1] = (y[i1] - xi) / a[0];
/*      */     } 
/*  261 */     for (i1 = i1lo; i1 < n1; i1++) {
/*  262 */       a1.get(i1, a);
/*  263 */       float xi = 0.0F;
/*  264 */       for (int j = 1; j < this._m; j++) {
/*  265 */         int k1 = i1 - this._lag1[j];
/*  266 */         xi += a[j] * x[k1];
/*      */       } 
/*  268 */       x[i1] = (y[i1] - xi) / a[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(A1 a1, float[] y, float[] x) {
/*  283 */     Check.argument((x != y), "x!=y");
/*  284 */     Array.zero(x);
/*  285 */     float[] a = new float[this._m];
/*  286 */     int n1 = y.length;
/*  287 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  288 */     for (i1 = n1 - 1; i1 >= i1lo; i1--) {
/*  289 */       a1.get(i1, a);
/*  290 */       float xi = x[i1] = (y[i1] - x[i1]) / a[0];
/*  291 */       for (int j = 1; j < this._m; j++) {
/*  292 */         int k1 = i1 - this._lag1[j];
/*  293 */         x[k1] = x[k1] + a[j] * xi;
/*      */       } 
/*      */     } 
/*  296 */     for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  297 */       a1.get(i1, a);
/*  298 */       float xi = x[i1] = (y[i1] - x[i1]) / a[0];
/*  299 */       for (int j = 1; j < this._m; j++) {
/*  300 */         int k1 = i1 - this._lag1[j];
/*  301 */         if (0 <= k1) {
/*  302 */           x[k1] = x[k1] + a[j] * xi;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(A2 a2, float[][] x, float[][] y) {
/*  320 */     float[] a = new float[this._m];
/*  321 */     int n1 = (x[0]).length;
/*  322 */     int n2 = x.length;
/*  323 */     int i1lo = MathPlus.max(0, this._max1);
/*  324 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  325 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  326 */     for (i2 = n2 - 1; i2 >= i2lo; i2--) {
/*  327 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  328 */         a2.get(i1, i2, a);
/*  329 */         float yi = a[0] * x[i2][i1];
/*  330 */         for (int j = 1; j < this._m; j++) {
/*  331 */           int k1 = i1 - this._lag1[j];
/*  332 */           int k2 = i2 - this._lag2[j];
/*  333 */           if (k1 < n1)
/*  334 */             yi += a[j] * x[k2][k1]; 
/*      */         } 
/*  336 */         y[i2][i1] = yi;
/*      */       } 
/*  338 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  339 */         a2.get(i1, i2, a);
/*  340 */         float yi = a[0] * x[i2][i1];
/*  341 */         for (int j = 1; j < this._m; j++) {
/*  342 */           int k1 = i1 - this._lag1[j];
/*  343 */           int k2 = i2 - this._lag2[j];
/*  344 */           yi += a[j] * x[k2][k1];
/*      */         } 
/*  346 */         y[i2][i1] = yi;
/*      */       } 
/*  348 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  349 */         a2.get(i1, i2, a);
/*  350 */         float yi = a[0] * x[i2][i1];
/*  351 */         for (int j = 1; j < this._m; j++) {
/*  352 */           int k1 = i1 - this._lag1[j];
/*  353 */           int k2 = i2 - this._lag2[j];
/*  354 */           if (0 <= k1)
/*  355 */             yi += a[j] * x[k2][k1]; 
/*      */         } 
/*  357 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  360 */     for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  361 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  362 */         a2.get(i1, i2, a);
/*  363 */         float yi = a[0] * x[i2][i1];
/*  364 */         for (int j = 1; j < this._m; j++) {
/*  365 */           int k1 = i1 - this._lag1[j];
/*  366 */           int k2 = i2 - this._lag2[j];
/*  367 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  368 */             yi += a[j] * x[k2][k1]; 
/*      */         } 
/*  370 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(A2 a2, float[][] x, float[][] y) {
/*  385 */     float[] a = new float[this._m];
/*  386 */     int n1 = (x[0]).length;
/*  387 */     int n2 = x.length;
/*  388 */     int i1lo = MathPlus.max(0, this._max1);
/*  389 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  390 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  391 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  392 */       for (int i1 = 0; i1 < n1; i1++) {
/*  393 */         a2.get(i1, i2, a);
/*  394 */         float xi = x[i2][i1];
/*  395 */         y[i2][i1] = a[0] * xi;
/*  396 */         for (int j = 1; j < this._m; j++) {
/*  397 */           int k1 = i1 - this._lag1[j];
/*  398 */           int k2 = i2 - this._lag2[j];
/*  399 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  400 */             y[k2][k1] = y[k2][k1] + a[j] * xi; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  404 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  405 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  406 */         a2.get(i1, i2, a);
/*  407 */         float xi = x[i2][i1];
/*  408 */         y[i2][i1] = a[0] * xi;
/*  409 */         for (int j = 1; j < this._m; j++) {
/*  410 */           int k1 = i1 - this._lag1[j];
/*  411 */           int k2 = i2 - this._lag2[j];
/*  412 */           if (0 <= k1)
/*  413 */             y[k2][k1] = y[k2][k1] + a[j] * xi; 
/*      */         } 
/*      */       } 
/*  416 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  417 */         a2.get(i1, i2, a);
/*  418 */         float xi = x[i2][i1];
/*  419 */         y[i2][i1] = a[0] * xi;
/*  420 */         for (int j = 1; j < this._m; j++) {
/*  421 */           int k1 = i1 - this._lag1[j];
/*  422 */           int k2 = i2 - this._lag2[j];
/*  423 */           y[k2][k1] = y[k2][k1] + a[j] * xi;
/*      */         } 
/*      */       } 
/*  426 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  427 */         a2.get(i1, i2, a);
/*  428 */         float xi = x[i2][i1];
/*  429 */         y[i2][i1] = a[0] * xi;
/*  430 */         for (int j = 1; j < this._m; j++) {
/*  431 */           int k1 = i1 - this._lag1[j];
/*  432 */           int k2 = i2 - this._lag2[j];
/*  433 */           if (k1 < n1) {
/*  434 */             y[k2][k1] = y[k2][k1] + a[j] * xi;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(A2 a2, float[][] y, float[][] x) {
/*  450 */     float[] a = new float[this._m];
/*  451 */     int n1 = (y[0]).length;
/*  452 */     int n2 = y.length;
/*  453 */     int i1lo = MathPlus.min(this._max1, n1);
/*  454 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  455 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  456 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  457 */       for (int i1 = 0; i1 < n1; i1++) {
/*  458 */         a2.get(i1, i2, a);
/*  459 */         float xi = 0.0F;
/*  460 */         for (int j = 1; j < this._m; j++) {
/*  461 */           int k1 = i1 - this._lag1[j];
/*  462 */           int k2 = i2 - this._lag2[j];
/*  463 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  464 */             xi += a[j] * x[k2][k1]; 
/*      */         } 
/*  466 */         x[i2][i1] = (y[i2][i1] - xi) / a[0];
/*      */       } 
/*      */     } 
/*  469 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  470 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  471 */         a2.get(i1, i2, a);
/*  472 */         float xi = 0.0F;
/*  473 */         for (int j = 1; j < this._m; j++) {
/*  474 */           int k1 = i1 - this._lag1[j];
/*  475 */           int k2 = i2 - this._lag2[j];
/*  476 */           if (0 <= k1)
/*  477 */             xi += a[j] * x[k2][k1]; 
/*      */         } 
/*  479 */         x[i2][i1] = (y[i2][i1] - xi) / a[0];
/*      */       } 
/*  481 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  482 */         a2.get(i1, i2, a);
/*  483 */         float xi = 0.0F;
/*  484 */         for (int j = 1; j < this._m; j++) {
/*  485 */           int k1 = i1 - this._lag1[j];
/*  486 */           int k2 = i2 - this._lag2[j];
/*  487 */           xi += a[j] * x[k2][k1];
/*      */         } 
/*  489 */         x[i2][i1] = (y[i2][i1] - xi) / a[0];
/*      */       } 
/*  491 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  492 */         a2.get(i1, i2, a);
/*  493 */         float xi = 0.0F;
/*  494 */         for (int j = 1; j < this._m; j++) {
/*  495 */           int k1 = i1 - this._lag1[j];
/*  496 */           int k2 = i2 - this._lag2[j];
/*  497 */           if (k1 < n1)
/*  498 */             xi += a[j] * x[k2][k1]; 
/*      */         } 
/*  500 */         x[i2][i1] = (y[i2][i1] - xi) / a[0];
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(A2 a2, float[][] y, float[][] x) {
/*  516 */     Check.argument((x != y), "x!=y");
/*  517 */     Array.zero(x);
/*  518 */     float[] a = new float[this._m];
/*  519 */     int n1 = (y[0]).length;
/*  520 */     int n2 = y.length;
/*  521 */     int i1lo = MathPlus.min(this._max1, n1);
/*  522 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  523 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  524 */     for (i2 = n2 - 1; i2 >= i2lo; i2--) {
/*  525 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  526 */         a2.get(i1, i2, a);
/*  527 */         float xi = x[i2][i1] = (y[i2][i1] - x[i2][i1]) / a[0];
/*  528 */         for (int j = 1; j < this._m; j++) {
/*  529 */           int k1 = i1 - this._lag1[j];
/*  530 */           int k2 = i2 - this._lag2[j];
/*  531 */           if (k1 < n1)
/*  532 */             x[k2][k1] = x[k2][k1] + a[j] * xi; 
/*      */         } 
/*      */       } 
/*  535 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  536 */         a2.get(i1, i2, a);
/*  537 */         float xi = x[i2][i1] = (y[i2][i1] - x[i2][i1]) / a[0];
/*  538 */         for (int j = 1; j < this._m; j++) {
/*  539 */           int k1 = i1 - this._lag1[j];
/*  540 */           int k2 = i2 - this._lag2[j];
/*  541 */           x[k2][k1] = x[k2][k1] + a[j] * xi;
/*      */         } 
/*      */       } 
/*  544 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  545 */         a2.get(i1, i2, a);
/*  546 */         float xi = x[i2][i1] = (y[i2][i1] - x[i2][i1]) / a[0];
/*  547 */         for (int j = 1; j < this._m; j++) {
/*  548 */           int k1 = i1 - this._lag1[j];
/*  549 */           int k2 = i2 - this._lag2[j];
/*  550 */           if (0 <= k1)
/*  551 */             x[k2][k1] = x[k2][k1] + a[j] * xi; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  555 */     for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  556 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  557 */         a2.get(i1, i2, a);
/*  558 */         float xi = x[i2][i1] = (y[i2][i1] - x[i2][i1]) / a[0];
/*  559 */         for (int j = 1; j < this._m; j++) {
/*  560 */           int k1 = i1 - this._lag1[j];
/*  561 */           int k2 = i2 - this._lag2[j];
/*  562 */           if (0 <= k1 && k1 < n1 && 0 <= k2) {
/*  563 */             x[k2][k1] = x[k2][k1] + a[j] * xi;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(A3 a3, float[][][] x, float[][][] y) {
/*  582 */     float[] a = new float[this._m];
/*  583 */     int n1 = (x[0][0]).length;
/*  584 */     int n2 = (x[0]).length;
/*  585 */     int n3 = x.length;
/*  586 */     int i1lo = MathPlus.max(0, this._max1);
/*  587 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  588 */     int i2lo = MathPlus.max(0, this._max2);
/*  589 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  590 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  591 */     for (i3 = n3 - 1; i3 >= i3lo; i3--) {
/*  592 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  593 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  594 */           a3.get(i1, i2, i3, a);
/*  595 */           float yi = a[0] * x[i3][i2][i1];
/*  596 */           for (int j = 1; j < this._m; j++) {
/*  597 */             int k1 = i1 - this._lag1[j];
/*  598 */             int k2 = i2 - this._lag2[j];
/*  599 */             int k3 = i3 - this._lag3[j];
/*  600 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/*  601 */               yi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  603 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  606 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/*  607 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  608 */           a3.get(i1, i2, i3, a);
/*  609 */           float yi = a[0] * x[i3][i2][i1];
/*  610 */           for (int j = 1; j < this._m; j++) {
/*  611 */             int k1 = i1 - this._lag1[j];
/*  612 */             int k2 = i2 - this._lag2[j];
/*  613 */             int k3 = i3 - this._lag3[j];
/*  614 */             if (k1 < n1)
/*  615 */               yi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  617 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  619 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  620 */           a3.get(i1, i2, i3, a);
/*  621 */           float yi = a[0] * x[i3][i2][i1];
/*  622 */           for (int j = 1; j < this._m; j++) {
/*  623 */             int k1 = i1 - this._lag1[j];
/*  624 */             int k2 = i2 - this._lag2[j];
/*  625 */             int k3 = i3 - this._lag3[j];
/*  626 */             yi += a[j] * x[k3][k2][k1];
/*      */           } 
/*  628 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  630 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  631 */           a3.get(i1, i2, i3, a);
/*  632 */           float yi = a[0] * x[i3][i2][i1];
/*  633 */           for (int j = 1; j < this._m; j++) {
/*  634 */             int k1 = i1 - this._lag1[j];
/*  635 */             int k2 = i2 - this._lag2[j];
/*  636 */             int k3 = i3 - this._lag3[j];
/*  637 */             if (0 <= k1)
/*  638 */               yi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  640 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  643 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  644 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  645 */           a3.get(i1, i2, i3, a);
/*  646 */           float yi = a[0] * x[i3][i2][i1];
/*  647 */           for (int j = 1; j < this._m; j++) {
/*  648 */             int k1 = i1 - this._lag1[j];
/*  649 */             int k2 = i2 - this._lag2[j];
/*  650 */             int k3 = i3 - this._lag3[j];
/*  651 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  652 */               yi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  654 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*  658 */     for (i3 = i3lo - 1; i3 >= 0; i3--) {
/*  659 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  660 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  661 */           a3.get(i1, i2, i3, a);
/*  662 */           float yi = a[0] * x[i3][i2][i1];
/*  663 */           for (int j = 1; j < this._m; j++) {
/*  664 */             int k1 = i1 - this._lag1[j];
/*  665 */             int k2 = i2 - this._lag2[j];
/*  666 */             int k3 = i3 - this._lag3[j];
/*  667 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/*  668 */               yi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  670 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(A3 a3, float[][][] x, float[][][] y) {
/*  686 */     float[] a = new float[this._m];
/*  687 */     int n1 = (x[0][0]).length;
/*  688 */     int n2 = (x[0]).length;
/*  689 */     int n3 = x.length;
/*  690 */     int i1lo = MathPlus.max(0, this._max1);
/*  691 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  692 */     int i2lo = MathPlus.max(0, this._max2);
/*  693 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  694 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  695 */     for (i3 = 0; i3 < i3lo; i3++) {
/*  696 */       for (int i2 = 0; i2 < n2; i2++) {
/*  697 */         for (int i1 = 0; i1 < n1; i1++) {
/*  698 */           a3.get(i1, i2, i3, a);
/*  699 */           float xi = x[i3][i2][i1];
/*  700 */           y[i3][i2][i1] = a[0] * xi;
/*  701 */           for (int j = 1; j < this._m; j++) {
/*  702 */             int k1 = i1 - this._lag1[j];
/*  703 */             int k2 = i2 - this._lag2[j];
/*  704 */             int k3 = i3 - this._lag3[j];
/*  705 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/*  706 */               y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  711 */     for (i3 = i3lo; i3 < n3; i3++) {
/*  712 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/*  713 */         for (int i1 = 0; i1 < n1; i1++) {
/*  714 */           a3.get(i1, i2, i3, a);
/*  715 */           float xi = x[i3][i2][i1];
/*  716 */           y[i3][i2][i1] = a[0] * xi;
/*  717 */           for (int j = 1; j < this._m; j++) {
/*  718 */             int k1 = i1 - this._lag1[j];
/*  719 */             int k2 = i2 - this._lag2[j];
/*  720 */             int k3 = i3 - this._lag3[j];
/*  721 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  722 */               y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  726 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/*  727 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  728 */           a3.get(i1, i2, i3, a);
/*  729 */           float xi = x[i3][i2][i1];
/*  730 */           y[i3][i2][i1] = a[0] * xi;
/*  731 */           for (int j = 1; j < this._m; j++) {
/*  732 */             int k1 = i1 - this._lag1[j];
/*  733 */             int k2 = i2 - this._lag2[j];
/*  734 */             int k3 = i3 - this._lag3[j];
/*  735 */             if (0 <= k1)
/*  736 */               y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*  739 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/*  740 */           a3.get(i1, i2, i3, a);
/*  741 */           float xi = x[i3][i2][i1];
/*  742 */           y[i3][i2][i1] = a[0] * xi;
/*  743 */           for (int j = 1; j < this._m; j++) {
/*  744 */             int k1 = i1 - this._lag1[j];
/*  745 */             int k2 = i2 - this._lag2[j];
/*  746 */             int k3 = i3 - this._lag3[j];
/*  747 */             y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi;
/*      */           } 
/*      */         } 
/*  750 */         for (i1 = i1hi; i1 < n1; i1++) {
/*  751 */           a3.get(i1, i2, i3, a);
/*  752 */           float xi = x[i3][i2][i1];
/*  753 */           y[i3][i2][i1] = a[0] * xi;
/*  754 */           for (int j = 1; j < this._m; j++) {
/*  755 */             int k1 = i1 - this._lag1[j];
/*  756 */             int k2 = i2 - this._lag2[j];
/*  757 */             int k3 = i3 - this._lag3[j];
/*  758 */             if (k1 < n1)
/*  759 */               y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  763 */       for (i2 = i2hi; i2 < n2; i2++) {
/*  764 */         for (int i1 = 0; i1 < n1; i1++) {
/*  765 */           a3.get(i1, i2, i3, a);
/*  766 */           float xi = x[i3][i2][i1];
/*  767 */           y[i3][i2][i1] = a[0] * xi;
/*  768 */           for (int j = 1; j < this._m; j++) {
/*  769 */             int k1 = i1 - this._lag1[j];
/*  770 */             int k2 = i2 - this._lag2[j];
/*  771 */             int k3 = i3 - this._lag3[j];
/*  772 */             if (0 <= k1 && k1 < n1 && k2 < n2) {
/*  773 */               y[k3][k2][k1] = y[k3][k2][k1] + a[j] * xi;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(A3 a3, float[][][] y, float[][][] x) {
/*  790 */     float[] a = new float[this._m];
/*  791 */     int n1 = (y[0][0]).length;
/*  792 */     int n2 = (y[0]).length;
/*  793 */     int n3 = y.length;
/*  794 */     int i1lo = MathPlus.max(0, this._max1);
/*  795 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  796 */     int i2lo = MathPlus.max(0, this._max2);
/*  797 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  798 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  799 */     for (i3 = 0; i3 < i3lo; i3++) {
/*  800 */       for (int i2 = 0; i2 < n2; i2++) {
/*  801 */         for (int i1 = 0; i1 < n1; i1++) {
/*  802 */           a3.get(i1, i2, i3, a);
/*  803 */           float xi = 0.0F;
/*  804 */           for (int j = 1; j < this._m; j++) {
/*  805 */             int k1 = i1 - this._lag1[j];
/*  806 */             int k2 = i2 - this._lag2[j];
/*  807 */             int k3 = i3 - this._lag3[j];
/*  808 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/*  809 */               xi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  811 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*      */       } 
/*      */     } 
/*  815 */     for (i3 = i3lo; i3 < n3; i3++) {
/*  816 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/*  817 */         for (int i1 = 0; i1 < n1; i1++) {
/*  818 */           a3.get(i1, i2, i3, a);
/*  819 */           float xi = 0.0F;
/*  820 */           for (int j = 1; j < this._m; j++) {
/*  821 */             int k1 = i1 - this._lag1[j];
/*  822 */             int k2 = i2 - this._lag2[j];
/*  823 */             int k3 = i3 - this._lag3[j];
/*  824 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  825 */               xi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  827 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*      */       } 
/*  830 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/*  831 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  832 */           a3.get(i1, i2, i3, a);
/*  833 */           float xi = 0.0F;
/*  834 */           for (int j = 1; j < this._m; j++) {
/*  835 */             int k1 = i1 - this._lag1[j];
/*  836 */             int k2 = i2 - this._lag2[j];
/*  837 */             int k3 = i3 - this._lag3[j];
/*  838 */             if (0 <= k1)
/*  839 */               xi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  841 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*  843 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/*  844 */           a3.get(i1, i2, i3, a);
/*  845 */           float xi = 0.0F;
/*  846 */           for (int j = 1; j < this._m; j++) {
/*  847 */             int k1 = i1 - this._lag1[j];
/*  848 */             int k2 = i2 - this._lag2[j];
/*  849 */             int k3 = i3 - this._lag3[j];
/*  850 */             xi += a[j] * x[k3][k2][k1];
/*      */           } 
/*  852 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*  854 */         for (i1 = i1hi; i1 < n1; i1++) {
/*  855 */           a3.get(i1, i2, i3, a);
/*  856 */           float xi = 0.0F;
/*  857 */           for (int j = 1; j < this._m; j++) {
/*  858 */             int k1 = i1 - this._lag1[j];
/*  859 */             int k2 = i2 - this._lag2[j];
/*  860 */             int k3 = i3 - this._lag3[j];
/*  861 */             if (k1 < n1)
/*  862 */               xi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  864 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*      */       } 
/*  867 */       for (i2 = i2hi; i2 < n2; i2++) {
/*  868 */         for (int i1 = 0; i1 < n1; i1++) {
/*  869 */           a3.get(i1, i2, i3, a);
/*  870 */           float xi = 0.0F;
/*  871 */           for (int j = 1; j < this._m; j++) {
/*  872 */             int k1 = i1 - this._lag1[j];
/*  873 */             int k2 = i2 - this._lag2[j];
/*  874 */             int k3 = i3 - this._lag3[j];
/*  875 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/*  876 */               xi += a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  878 */           x[i3][i2][i1] = (y[i3][i2][i1] - xi) / a[0];
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(A3 a3, float[][][] y, float[][][] x) {
/*  895 */     Check.argument((x != y), "x!=y");
/*  896 */     Array.zero(x);
/*  897 */     float[] a = new float[this._m];
/*  898 */     int n1 = (y[0][0]).length;
/*  899 */     int n2 = (y[0]).length;
/*  900 */     int n3 = y.length;
/*  901 */     int i1lo = MathPlus.max(0, this._max1);
/*  902 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  903 */     int i2lo = MathPlus.max(0, this._max2);
/*  904 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  905 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  906 */     for (i3 = n3 - 1; i3 >= i3lo; i3--) {
/*  907 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  908 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  909 */           a3.get(i1, i2, i3, a);
/*  910 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  911 */           for (int j = 1; j < this._m; j++) {
/*  912 */             int k1 = i1 - this._lag1[j];
/*  913 */             int k2 = i2 - this._lag2[j];
/*  914 */             int k3 = i3 - this._lag3[j];
/*  915 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/*  916 */               x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  920 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/*  921 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  922 */           a3.get(i1, i2, i3, a);
/*  923 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  924 */           for (int j = 1; j < this._m; j++) {
/*  925 */             int k1 = i1 - this._lag1[j];
/*  926 */             int k2 = i2 - this._lag2[j];
/*  927 */             int k3 = i3 - this._lag3[j];
/*  928 */             if (k1 < n1)
/*  929 */               x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*  932 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  933 */           a3.get(i1, i2, i3, a);
/*  934 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  935 */           for (int j = 1; j < this._m; j++) {
/*  936 */             int k1 = i1 - this._lag1[j];
/*  937 */             int k2 = i2 - this._lag2[j];
/*  938 */             int k3 = i3 - this._lag3[j];
/*  939 */             x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi;
/*      */           } 
/*      */         } 
/*  942 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  943 */           a3.get(i1, i2, i3, a);
/*  944 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  945 */           for (int j = 1; j < this._m; j++) {
/*  946 */             int k1 = i1 - this._lag1[j];
/*  947 */             int k2 = i2 - this._lag2[j];
/*  948 */             int k3 = i3 - this._lag3[j];
/*  949 */             if (0 <= k1)
/*  950 */               x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*  954 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  955 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  956 */           a3.get(i1, i2, i3, a);
/*  957 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  958 */           for (int j = 1; j < this._m; j++) {
/*  959 */             int k1 = i1 - this._lag1[j];
/*  960 */             int k2 = i2 - this._lag2[j];
/*  961 */             int k3 = i3 - this._lag3[j];
/*  962 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  963 */               x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  968 */     for (i3 = i3lo - 1; i3 >= 0; i3--) {
/*  969 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  970 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  971 */           a3.get(i1, i2, i3, a);
/*  972 */           float xi = x[i3][i2][i1] = (y[i3][i2][i1] - x[i3][i2][i1]) / a[0];
/*  973 */           for (int j = 1; j < this._m; j++) {
/*  974 */             int k1 = i1 - this._lag1[j];
/*  975 */             int k2 = i2 - this._lag2[j];
/*  976 */             int k3 = i3 - this._lag3[j];
/*  977 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3) {
/*  978 */               x[k3][k2][k1] = x[k3][k2][k1] + a[j] * xi;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initLags(int[] lag1) {
/*  997 */     Check.argument((lag1.length > 0), "lag1.length>0");
/*  998 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/*  999 */     for (int j = 1; j < lag1.length; j++)
/* 1000 */       Check.argument((lag1[j] > 0), "lag1[" + j + "]>0"); 
/* 1001 */     this._m = lag1.length;
/* 1002 */     this._lag1 = Array.copy(lag1);
/* 1003 */     this._lag2 = Array.zeroint(this._m);
/* 1004 */     this._lag3 = Array.zeroint(this._m);
/* 1005 */     this._min1 = Array.min(lag1);
/* 1006 */     this._max1 = Array.max(lag1);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2) {
/* 1010 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1011 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1012 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1013 */     for (int j = 1; j < lag1.length; j++) {
/* 1014 */       Check.argument((lag2[j] >= 0), "lag2[" + j + "]>=0");
/* 1015 */       if (lag2[j] == 0)
/* 1016 */         Check.argument((lag1[j] > 0), "if lag2==0, lag1[" + j + "]>0"); 
/*      */     } 
/* 1018 */     this._m = lag1.length;
/* 1019 */     this._lag1 = Array.copy(lag1);
/* 1020 */     this._lag2 = Array.copy(lag2);
/* 1021 */     this._lag3 = Array.zeroint(this._m);
/* 1022 */     this._min1 = Array.min(lag1);
/* 1023 */     this._min2 = Array.min(lag2);
/* 1024 */     this._max1 = Array.max(lag1);
/* 1025 */     this._max2 = Array.max(lag2);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2, int[] lag3) {
/* 1029 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1030 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1031 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1032 */     Check.argument((lag3[0] == 0), "lag3[0]==0");
/* 1033 */     for (int j = 1; j < lag1.length; j++) {
/* 1034 */       Check.argument((lag3[j] >= 0), "lag3[" + j + "]>=0");
/* 1035 */       if (lag3[j] == 0) {
/* 1036 */         Check.argument((lag2[j] >= 0), "if lag3==0, lag2[" + j + "]>=0");
/* 1037 */         if (lag2[j] == 0)
/* 1038 */           Check.argument((lag1[j] > 0), "if lag3==0 && lag2==0, lag1[" + j + "]>0"); 
/*      */       } 
/*      */     } 
/* 1041 */     this._m = lag1.length;
/* 1042 */     this._lag1 = Array.copy(lag1);
/* 1043 */     this._lag2 = Array.copy(lag2);
/* 1044 */     this._lag3 = Array.copy(lag3);
/* 1045 */     this._min1 = Array.min(lag1);
/* 1046 */     this._min2 = Array.min(lag2);
/* 1047 */     this._min3 = Array.min(lag3);
/* 1048 */     this._max1 = Array.max(lag1);
/* 1049 */     this._max2 = Array.max(lag2);
/* 1050 */     this._max3 = Array.max(lag3);
/*      */   }
/*      */   
/*      */   public static interface A3 {
/*      */     void get(int param1Int1, int param1Int2, int param1Int3, float[] param1ArrayOffloat);
/*      */   }
/*      */   
/*      */   public static interface A2 {
/*      */     void get(int param1Int1, int param1Int2, float[] param1ArrayOffloat);
/*      */   }
/*      */   
/*      */   public static interface A1 {
/*      */     void get(int param1Int, float[] param1ArrayOffloat);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/LocalCausalFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */