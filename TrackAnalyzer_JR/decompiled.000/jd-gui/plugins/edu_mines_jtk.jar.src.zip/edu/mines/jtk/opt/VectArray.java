/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectArray
/*     */   implements VectContainer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  19 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   
/*  21 */   private Vect[] _vect = null;
/*  22 */   private int[] _keys = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VectArray(int size) {
/*  28 */     this._vect = new Vect[size];
/*  29 */     this._keys = new int[size];
/*  30 */     for (int i = 0; i < size; ) { this._keys[i] = i; i++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void put(int index, Vect vect) {
/*  35 */     this._vect[index] = vect;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vect get(int index) {
/*  40 */     return this._vect[index];
/*     */   }
/*     */   
/*     */   public int size() {
/*  44 */     return this._vect.length;
/*     */   }
/*     */   
/*     */   public boolean containsKey(int index) {
/*  48 */     if (index >= 0 && index < this._vect.length) {
/*  49 */       return (this._vect[index] != null);
/*     */     }
/*  51 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getKeys() {
/*  56 */     return this._keys;
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/*  61 */     VectArray otherMap = (VectArray)other;
/*  62 */     double result = 0.0D;
/*  63 */     for (int i = 0; i < this._vect.length; i++) {
/*  64 */       result += this._vect[i].dot(otherMap._vect[i]);
/*     */     }
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public VectArray clone() {
/*  71 */     VectArray result = null;
/*     */     try {
/*  73 */       result = (VectArray)super.clone();
/*  74 */       result._vect = new Vect[this._vect.length];
/*  75 */       for (int i = 0; i < this._vect.length; i++) {
/*  76 */         if (this._vect[i] != null) {
/*  77 */           result._vect[i] = this._vect[i].clone();
/*     */         }
/*     */       } 
/*  80 */     } catch (CloneNotSupportedException ex) {
/*  81 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/*  82 */       e.initCause(ex);
/*  83 */       throw e;
/*     */     } 
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  90 */     this._vect = null;
/*  91 */     this._keys = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/*  96 */     double scale = Almost.FLOAT.divide(1.0D, this._vect.length, 0.0D);
/*  97 */     for (int i = 0; i < this._vect.length; i++) {
/*  98 */       this._vect[i].multiplyInverseCovariance();
/*  99 */       VectUtil.scale(this._vect[i], scale);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {
/* 105 */     for (int i = 0; i < this._vect.length; i++) {
/* 106 */       this._vect[i].constrain();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void postCondition() {
/* 112 */     for (int i = 0; i < this._vect.length; i++) {
/* 113 */       this._vect[i].postCondition();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 119 */     addOrProject(scaleThis, scaleOther, other, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 124 */     addOrProject(scaleThis, scaleOther, other, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOrProject(double scaleThis, double scaleOther, VectConst other, boolean project) {
/* 131 */     VectArray otherMap = (VectArray)other;
/* 132 */     for (int i = 0; i < this._vect.length; i++) {
/* 133 */       Vect vectTo = this._vect[i];
/* 134 */       Vect vectFrom = otherMap._vect[i];
/* 135 */       if (vectFrom == null) {
/* 136 */         throw new IllegalStateException("Cannot scale missing Vect " + i);
/*     */       }
/* 138 */       if (project) {
/* 139 */         vectTo.project(scaleThis, scaleOther, vectFrom);
/*     */       } else {
/* 141 */         vectTo.add(scaleThis, scaleOther, vectFrom);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public double magnitude() {
/* 147 */     double result = 0.0D;
/* 148 */     for (int i = 0; i < this._vect.length; i++) {
/* 149 */       result += this._vect[i].magnitude();
/*     */     }
/* 151 */     result = Almost.FLOAT.divide(result, this._vect.length, 0.0D);
/* 152 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/VectArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */