/*     */ package edu.mines.jtk.bench;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.util.concurrent.CompletionService;
/*     */ import java.util.concurrent.ExecutorCompletionService;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MtMatMulBench
/*     */ {
/*     */   public static final int NTHREAD = 8;
/*     */   
/*     */   public static void main(String[] args) {
/*  28 */     int m = 1001;
/*  29 */     int n = 1002;
/*  30 */     float[][] a = Array.randfloat(n, m);
/*  31 */     float[][] b = Array.randfloat(m, n);
/*  32 */     float[][] c1 = Array.zerofloat(m, m);
/*  33 */     float[][] c2 = Array.zerofloat(m, m);
/*  34 */     float[][] c3 = Array.zerofloat(m, m);
/*  35 */     float[][] c4 = Array.zerofloat(m, m);
/*  36 */     Stopwatch s = new Stopwatch();
/*  37 */     double mflops = 2.0E-6D * m * m * n;
/*  38 */     double maxtime = 5.0D;
/*     */     
/*  40 */     System.out.println("Methods:");
/*  41 */     System.out.println("mul1 = single-threaded");
/*  42 */     System.out.println("mul2 = multi-threaded (equal chunks)");
/*  43 */     System.out.println("mul3 = multi-threaded (atomic-integer)");
/*  44 */     System.out.println("mul4 = multi-threaded (thread-pool)");
/*  45 */     System.out.println("number of threads = 8");
/*     */     
/*  47 */     for (int ntrial = 0; ntrial < 5; ntrial++) {
/*  48 */       System.out.println();
/*     */       
/*  50 */       s.restart(); double nmul;
/*  51 */       for (nmul = 0.0D; s.time() < maxtime; nmul++)
/*  52 */         mul1(a, b, c1); 
/*  53 */       s.stop();
/*  54 */       System.out.println("mul1: rate=" + (int)(nmul * mflops / s.time()) + " mflops");
/*     */       
/*  56 */       s.restart();
/*  57 */       for (nmul = 0.0D; s.time() < maxtime; nmul++)
/*  58 */         mul2(a, b, c2); 
/*  59 */       s.stop();
/*  60 */       System.out.println("mul2: rate=" + (int)(nmul * mflops / s.time()) + " mflops");
/*     */       
/*  62 */       s.restart();
/*  63 */       for (nmul = 0.0D; s.time() < maxtime; nmul++)
/*  64 */         mul3(a, b, c3); 
/*  65 */       s.stop();
/*  66 */       System.out.println("mul3: rate=" + (int)(nmul * mflops / s.time()) + " mflops");
/*     */       
/*  68 */       s.restart();
/*  69 */       for (nmul = 0.0D; s.time() < maxtime; nmul++)
/*  70 */         mul4(a, b, c4); 
/*  71 */       s.stop();
/*  72 */       System.out.println("mul4: rate=" + (int)(nmul * mflops / s.time()) + " mflops");
/*     */       
/*  74 */       assertEquals(c1, c2);
/*  75 */       assertEquals(c1, c3);
/*  76 */       assertEquals(c1, c4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void computeColumn(int j, float[][] a, float[][] b, float[][] c) {
/*  89 */     int ni = c.length;
/*  90 */     int nk = b.length;
/*  91 */     float[] bj = new float[nk];
/*  92 */     for (int k = 0; k < nk; k++)
/*  93 */       bj[k] = b[k][j]; 
/*  94 */     for (int i = 0; i < ni; i++) {
/*  95 */       float[] ai = a[i];
/*  96 */       float cij = 0.0F;
/*  97 */       int mk = nk % 4; int m;
/*  98 */       for (m = 0; m < mk; m++)
/*  99 */         cij += ai[m] * bj[m]; 
/* 100 */       for (m = mk; m < nk; m += 4) {
/* 101 */         cij += ai[m] * bj[m];
/* 102 */         cij += ai[m + 1] * bj[m + 1];
/* 103 */         cij += ai[m + 2] * bj[m + 2];
/* 104 */         cij += ai[m + 3] * bj[m + 3];
/*     */       } 
/* 106 */       c[i][j] = cij;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mul1(float[][] a, float[][] b, float[][] c) {
/* 114 */     checkDimensions(a, b, c);
/* 115 */     int nj = (c[0]).length;
/* 116 */     for (int j = 0; j < nj; j++) {
/* 117 */       computeColumn(j, a, b, c);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mul2(final float[][] a, final float[][] b, final float[][] c) {
/* 126 */     checkDimensions(a, b, c);
/* 127 */     int nj = (c[0]).length;
/* 128 */     int mj = 1 + nj / 8;
/* 129 */     Thread[] threads = new Thread[8];
/* 130 */     for (int ithread = 0; ithread < 8; ithread++) {
/* 131 */       final int jfirst = ithread * mj;
/* 132 */       final int jlast = Math.min(jfirst + mj, nj);
/* 133 */       threads[ithread] = new Thread(new Runnable() {
/*     */             public void run() {
/* 135 */               for (int j = jfirst; j < jlast; j++)
/* 136 */                 MtMatMulBench.computeColumn(j, a, b, c); 
/*     */             }
/*     */           });
/*     */     } 
/* 140 */     startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mul3(final float[][] a, final float[][] b, final float[][] c) {
/* 149 */     checkDimensions(a, b, c);
/* 150 */     final int nj = (c[0]).length;
/* 151 */     final AtomicInteger aj = new AtomicInteger();
/* 152 */     Thread[] threads = new Thread[8];
/* 153 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/* 154 */       threads[ithread] = new Thread(new Runnable() {
/*     */             public void run() {
/* 156 */               for (int j = aj.getAndIncrement(); j < nj; j = aj.getAndIncrement())
/* 157 */                 MtMatMulBench.computeColumn(j, a, b, c); 
/*     */             }
/*     */           });
/*     */     } 
/* 161 */     startAndJoin(threads);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mul4(final float[][] a, final float[][] b, final float[][] c) {
/* 170 */     checkDimensions(a, b, c);
/* 171 */     int nj = (c[0]).length;
/* 172 */     ExecutorService es = Executors.newFixedThreadPool(8);
/* 173 */     CompletionService<Void> cs = new ExecutorCompletionService<Void>(es); int j;
/* 174 */     for (j = 0; j < nj; j++) {
/* 175 */       final int jj = j;
/* 176 */       cs.submit(new Runnable() {
/*     */             public void run() {
/* 178 */               MtMatMulBench.computeColumn(jj, a, b, c);
/*     */             }
/*     */           }null);
/*     */     } 
/*     */     try {
/* 183 */       for (j = 0; j < nj; j++)
/* 184 */         cs.take(); 
/* 185 */     } catch (InterruptedException ie) {
/* 186 */       throw new RuntimeException(ie);
/*     */     } 
/* 188 */     es.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void startAndJoin(Thread[] threads) {
/*     */     int ithread;
/* 231 */     for (ithread = 0; ithread < threads.length; ithread++)
/* 232 */       threads[ithread].start(); 
/*     */     try {
/* 234 */       for (ithread = 0; ithread < threads.length; ithread++)
/* 235 */         threads[ithread].join(); 
/* 236 */     } catch (InterruptedException ie) {
/* 237 */       throw new RuntimeException(ie);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void assertEquals(float[][] a, float[][] b) {
/* 242 */     Check.state((a.length == b.length), "same dimensions");
/* 243 */     Check.state(((a[0]).length == (b[0]).length), "same dimensions");
/* 244 */     int m = (a[0]).length;
/* 245 */     int n = a.length;
/* 246 */     for (int i = 0; i < m; i++) {
/* 247 */       for (int j = 0; j < n; j++) {
/* 248 */         Check.state((a[i][j] == b[i][j]), "same elements");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkDimensions(float[][] a, float[][] b, float[][] c) {
/* 254 */     int ma = a.length;
/* 255 */     int na = (a[0]).length;
/* 256 */     int mb = b.length;
/* 257 */     int nb = (b[0]).length;
/* 258 */     int mc = c.length;
/* 259 */     int nc = (c[0]).length;
/* 260 */     Check.argument((na == mb), "number of columns in A = number of rows in B");
/* 261 */     Check.argument((ma == mc), "number of rows in A = number of rows in C");
/* 262 */     Check.argument((nb == nc), "number of columns in B = number of columns in C");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/MtMatMulBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */