/*      */ package edu.mines.jtk.util;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class UnitsParser
/*      */ {
/*      */   static synchronized Units parse(String definition) throws ParseException {
/*   43 */     ReInit(new StringReader(definition));
/*   44 */     return units();
/*      */   }
/*      */ 
/*      */   
/*      */   public static final Units units() throws ParseException {
/*   49 */     Units e = expr();
/*   50 */     jj_consume_token(0);
/*   51 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Units expr() throws ParseException {
/*      */     Token n;
/*   58 */     Units t = term();
/*   59 */     switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk)
/*      */     { case 3:
/*      */       case 4:
/*   62 */         switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk)
/*      */         { case 3:
/*   64 */             jj_consume_token(3);
/*   65 */             switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */               case 12:
/*   67 */                 n = jj_consume_token(12);
/*      */                 break;
/*      */               case 11:
/*   70 */                 n = jj_consume_token(11);
/*      */                 break;
/*      */               default:
/*   73 */                 jj_la1[0] = jj_gen;
/*   74 */                 jj_consume_token(-1);
/*   75 */                 throw new ParseException();
/*      */             } 
/*   77 */             t.shift(Double.valueOf(n.image).doubleValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  105 */             return t;case 4: jj_consume_token(4); switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) { case 12: n = jj_consume_token(12); break;case 11: n = jj_consume_token(11); break;default: jj_la1[1] = jj_gen; jj_consume_token(-1); throw new ParseException(); }  t.shift(-Double.valueOf(n.image).doubleValue()); return t; }  jj_la1[2] = jj_gen; jj_consume_token(-1); throw new ParseException(); }  jj_la1[3] = jj_gen; return t;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Units term() throws ParseException {
/*  111 */     Units f = factor();
/*      */     while (true) {
/*      */       Units fb;
/*  114 */       switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */         case 5:
/*      */         case 6:
/*      */         case 8:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */           break;
/*      */         
/*      */         default:
/*  124 */           jj_la1[4] = jj_gen;
/*      */           break;
/*      */       } 
/*  127 */       switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */         case 5:
/*      */         case 8:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*  133 */           switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */             case 5:
/*  135 */               jj_consume_token(5);
/*      */               break;
/*      */             default:
/*  138 */               jj_la1[5] = jj_gen;
/*      */               break;
/*      */           } 
/*  141 */           fb = factor();
/*  142 */           f.mul(fb);
/*      */           continue;
/*      */         case 6:
/*  145 */           jj_consume_token(6);
/*  146 */           fb = factor();
/*  147 */           f.div(fb);
/*      */           continue;
/*      */       } 
/*  150 */       jj_la1[6] = jj_gen;
/*  151 */       jj_consume_token(-1);
/*  152 */       throw new ParseException();
/*      */     } 
/*      */     
/*  155 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Units factor() throws ParseException {
/*      */     Token n;
/*  162 */     Units p = primary();
/*  163 */     switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk)
/*      */     { case 7:
/*  165 */         jj_consume_token(7);
/*  166 */         n = jj_consume_token(11);
/*  167 */         p.pow(Integer.valueOf(n.image).intValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  173 */         return p; }  jj_la1[7] = jj_gen; return p;
/*      */   }
/*      */   
/*      */   public static final Units primary() throws ParseException {
/*      */     Units e, p;
/*      */     Token n;
/*      */     double d;
/*  180 */     switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */       case 10:
/*  182 */         n = jj_consume_token(10);
/*  183 */         p = Units.unitsFromName(n.image);
/*  184 */         if (p == null) throw new ParseException("Units /" + n.image + "/ are undefined.");
/*      */         
/*  186 */         return p;
/*      */       
/*      */       case 11:
/*      */       case 12:
/*  190 */         switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
/*      */           case 12:
/*  192 */             n = jj_consume_token(12);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  202 */             d = (new Double(n.image)).doubleValue();
/*  203 */             return (new Units()).scale(d);case 11: n = jj_consume_token(11); d = (new Double(n.image)).doubleValue(); return (new Units()).scale(d);
/*      */         }  jj_la1[8] = jj_gen; jj_consume_token(-1); throw new ParseException();
/*      */       case 8:
/*  206 */         jj_consume_token(8);
/*  207 */         e = expr();
/*  208 */         jj_consume_token(9);
/*  209 */         return e;
/*      */     } 
/*      */     
/*  212 */     jj_la1[9] = jj_gen;
/*  213 */     jj_consume_token(-1);
/*  214 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean jj_initialized_once = false;
/*      */   public static UnitsParserTokenManager token_source;
/*      */   public static ASCII_CharStream jj_input_stream;
/*      */   public static Token token;
/*      */   public static Token jj_nt;
/*      */   private static int jj_ntk;
/*      */   private static int jj_gen;
/*  225 */   private static final int[] jj_la1 = new int[10];
/*  226 */   private static final int[] jj_la1_0 = new int[] { 6144, 6144, 24, 24, 7520, 32, 7520, 128, 6144, 7424 };
/*      */ 
/*      */   
/*      */   public UnitsParser(InputStream stream) {
/*  230 */     if (jj_initialized_once) {
/*  231 */       System.out.println("ERROR: Second call to constructor of static parser. You must");
/*      */       
/*  233 */       System.out.println("       either use ReInit() or set the JavaCC option STATIC to false");
/*      */       
/*  235 */       System.out.println("       during parser generation.");
/*  236 */       throw new Error();
/*      */     } 
/*  238 */     jj_initialized_once = true;
/*  239 */     jj_input_stream = new ASCII_CharStream(stream, 1, 1);
/*  240 */     token_source = new UnitsParserTokenManager(jj_input_stream);
/*  241 */     token = new Token();
/*  242 */     jj_ntk = -1;
/*  243 */     jj_gen = 0;
/*  244 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   public static void ReInit(InputStream stream) {
/*  248 */     ASCII_CharStream.ReInit(stream, 1, 1);
/*  249 */     UnitsParserTokenManager.ReInit(jj_input_stream);
/*  250 */     token = new Token();
/*  251 */     jj_ntk = -1;
/*  252 */     jj_gen = 0;
/*  253 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   public UnitsParser(Reader stream) {
/*  257 */     if (jj_initialized_once) {
/*  258 */       System.out.println("ERROR: Second call to constructor of static parser. You must");
/*      */       
/*  260 */       System.out.println("       either use ReInit() or set the JavaCC option STATIC to false");
/*      */       
/*  262 */       System.out.println("       during parser generation.");
/*  263 */       throw new Error();
/*      */     } 
/*  265 */     jj_initialized_once = true;
/*  266 */     jj_input_stream = new ASCII_CharStream(stream, 1, 1);
/*  267 */     token_source = new UnitsParserTokenManager(jj_input_stream);
/*  268 */     token = new Token();
/*  269 */     jj_ntk = -1;
/*  270 */     jj_gen = 0;
/*  271 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   public static void ReInit(Reader stream) {
/*  275 */     ASCII_CharStream.ReInit(stream, 1, 1);
/*  276 */     UnitsParserTokenManager.ReInit(jj_input_stream);
/*  277 */     token = new Token();
/*  278 */     jj_ntk = -1;
/*  279 */     jj_gen = 0;
/*  280 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   public UnitsParser(UnitsParserTokenManager tm) {
/*  284 */     if (jj_initialized_once) {
/*  285 */       System.out.println("ERROR: Second call to constructor of static parser. You must");
/*      */       
/*  287 */       System.out.println("       either use ReInit() or set the JavaCC option STATIC to false");
/*      */       
/*  289 */       System.out.println("       during parser generation.");
/*  290 */       throw new Error();
/*      */     } 
/*  292 */     jj_initialized_once = true;
/*  293 */     token_source = tm;
/*  294 */     token = new Token();
/*  295 */     jj_ntk = -1;
/*  296 */     jj_gen = 0;
/*  297 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   public void ReInit(UnitsParserTokenManager tm) {
/*  301 */     token_source = tm;
/*  302 */     token = new Token();
/*  303 */     jj_ntk = -1;
/*  304 */     jj_gen = 0;
/*  305 */     for (int i = 0; i < 10; ) { jj_la1[i] = -1; i++; }
/*      */   
/*      */   }
/*      */   private static final Token jj_consume_token(int kind) throws ParseException {
/*      */     Token oldToken;
/*  310 */     if ((oldToken = token).next != null) { token = token.next; }
/*  311 */     else { token = token.next = UnitsParserTokenManager.getNextToken(); }
/*  312 */      jj_ntk = -1;
/*  313 */     if (token.kind == kind) {
/*  314 */       jj_gen++;
/*  315 */       return token;
/*      */     } 
/*  317 */     token = oldToken;
/*  318 */     jj_kind = kind;
/*  319 */     throw generateParseException();
/*      */   }
/*      */   
/*      */   public static final Token getNextToken() {
/*  323 */     if (token.next != null) { token = token.next; }
/*  324 */     else { token = token.next = UnitsParserTokenManager.getNextToken(); }
/*  325 */      jj_ntk = -1;
/*  326 */     jj_gen++;
/*  327 */     return token;
/*      */   }
/*      */   
/*      */   public static final Token getToken(int index) {
/*  331 */     Token t = token;
/*  332 */     for (int i = 0; i < index; i++) {
/*  333 */       if (t.next != null) { t = t.next; }
/*  334 */       else { t = t.next = UnitsParserTokenManager.getNextToken(); }
/*      */     
/*  336 */     }  return t;
/*      */   }
/*      */   
/*      */   private static final int jj_ntk() {
/*  340 */     if ((jj_nt = token.next) == null) {
/*  341 */       return jj_ntk = (token.next = UnitsParserTokenManager.getNextToken()).kind;
/*      */     }
/*  343 */     return jj_ntk = jj_nt.kind;
/*      */   }
/*      */   
/*  346 */   private static Vector<int[]> jj_expentries = (Vector)new Vector<int>();
/*      */   private static int[] jj_expentry;
/*  348 */   private static int jj_kind = -1; private static final int PLUS = 3; private static final int MINUS = 4; private static final int MUL = 5; private static final int DIV = 6; private static final int POW = 7; private static final int LP = 8; private static final int RP = 9; private static final int NAME = 10; private static final int INTEGER = 11; private static final int DOUBLE = 12;
/*      */   
/*      */   public static final ParseException generateParseException() {
/*  351 */     jj_expentries.removeAllElements();
/*  352 */     boolean[] la1tokens = new boolean[17]; int i;
/*  353 */     for (i = 0; i < 17; i++) {
/*  354 */       la1tokens[i] = false;
/*      */     }
/*  356 */     if (jj_kind >= 0) {
/*  357 */       la1tokens[jj_kind] = true;
/*  358 */       jj_kind = -1;
/*      */     } 
/*  360 */     for (i = 0; i < 10; i++) {
/*  361 */       if (jj_la1[i] == jj_gen) {
/*  362 */         for (int k = 0; k < 32; k++) {
/*  363 */           if ((jj_la1_0[i] & 1 << k) != 0) {
/*  364 */             la1tokens[k] = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*  369 */     for (i = 0; i < 17; i++) {
/*  370 */       if (la1tokens[i]) {
/*  371 */         jj_expentry = new int[1];
/*  372 */         jj_expentry[0] = i;
/*  373 */         jj_expentries.addElement(jj_expentry);
/*      */       } 
/*      */     } 
/*  376 */     int[][] exptokseq = new int[jj_expentries.size()][];
/*  377 */     for (int j = 0; j < jj_expentries.size(); j++) {
/*  378 */       exptokseq[j] = jj_expentries.elementAt(j);
/*      */     }
/*  380 */     return new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void enable_tracing() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void disable_tracing() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Token
/*      */   {
/*      */     public int kind;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int beginLine;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int beginColumn;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int endLine;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int endColumn;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String image;
/*      */ 
/*      */ 
/*      */     
/*      */     public Token next;
/*      */ 
/*      */ 
/*      */     
/*      */     public Token specialToken;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Token() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final String toString() {
/*  445 */       return this.image;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final Token newToken(int ofKind) {
/*  462 */       switch (ofKind) {
/*      */       
/*  464 */       }  return new Token();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class UnitsParserTokenManager
/*      */   {
/*      */     private static final int jjStopAtPos(int pos, int kind) {
/*  476 */       jjmatchedKind = kind;
/*  477 */       jjmatchedPos = pos;
/*  478 */       return pos + 1;
/*      */     }
/*      */     
/*      */     private static final int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  482 */       jjmatchedKind = kind;
/*  483 */       jjmatchedPos = pos; 
/*  484 */       try { curChar = UnitsParser.ASCII_CharStream.readChar(); }
/*  485 */       catch (IOException e) { return pos + 1; }
/*  486 */        return jjMoveNfa_0(state, pos + 1);
/*      */     }
/*      */     
/*      */     private static final int jjMoveStringLiteralDfa0_0() {
/*  490 */       switch (curChar) {
/*      */         
/*      */         case '(':
/*  493 */           return jjStopAtPos(0, 8);
/*      */         case ')':
/*  495 */           return jjStopAtPos(0, 9);
/*      */         case '+':
/*  497 */           return jjStopAtPos(0, 3);
/*      */         case '-':
/*  499 */           return jjStartNfaWithStates_0(0, 4, 30);
/*      */       } 
/*  501 */       return jjMoveNfa_0(0, 0);
/*      */     }
/*      */ 
/*      */     
/*      */     private static final void jjCheckNAdd(int state) {
/*  506 */       if (jjrounds[state] != jjround) {
/*      */         
/*  508 */         jjstateSet[jjnewStateCnt++] = state;
/*  509 */         jjrounds[state] = jjround;
/*      */       } 
/*      */     }
/*      */     
/*      */     private static final void jjAddStates(int start, int end) {
/*      */       do {
/*  515 */         jjstateSet[jjnewStateCnt++] = jjnextStates[start];
/*  516 */       } while (start++ != end);
/*      */     }
/*      */     
/*      */     private static final void jjCheckNAddTwoStates(int state1, int state2) {
/*  520 */       jjCheckNAdd(state1);
/*  521 */       jjCheckNAdd(state2);
/*      */     }
/*      */     
/*      */     private static final void jjCheckNAddStates(int start, int end) {
/*      */       do {
/*  526 */         jjCheckNAdd(jjnextStates[start]);
/*  527 */       } while (start++ != end);
/*      */     }
/*      */ 
/*      */     
/*      */     private static final int jjMoveNfa_0(int startState, int curPos) {
/*  532 */       int startsAt = 0;
/*  533 */       jjnewStateCnt = 33;
/*  534 */       int i = 1;
/*  535 */       jjstateSet[0] = startState;
/*      */       
/*  537 */       int kind = Integer.MAX_VALUE;
/*      */       
/*      */       while (true) {
/*  540 */         if (++jjround == Integer.MAX_VALUE)
/*  541 */           ReInitRounds(); 
/*  542 */         if (curChar < '@') {
/*      */           
/*  544 */           long l = 1L << curChar;
/*      */           
/*      */           do {
/*  547 */             switch (jjstateSet[--i]) {
/*      */               
/*      */               case 0:
/*  550 */                 if ((0x3FF000000000000L & l) != 0L) {
/*      */                   
/*  552 */                   if (kind > 11)
/*  553 */                     kind = 11; 
/*  554 */                   jjCheckNAddStates(0, 4);
/*      */                 }
/*  556 */                 else if ((0x440000000000L & l) != 0L) {
/*      */                   
/*  558 */                   if (kind > 5) {
/*  559 */                     kind = 5;
/*      */                   }
/*  561 */                 } else if (curChar == '-') {
/*  562 */                   jjCheckNAddStates(5, 10);
/*  563 */                 } else if (curChar == '%') {
/*      */                   
/*  565 */                   if (kind > 10) {
/*  566 */                     kind = 10;
/*      */                   }
/*  568 */                 } else if (curChar == '/') {
/*      */                   
/*  570 */                   if (kind > 6)
/*  571 */                     kind = 6; 
/*      */                 } 
/*  573 */                 if (curChar == '.') {
/*  574 */                   jjCheckNAddTwoStates(17, 18); break;
/*  575 */                 }  if (curChar == '*')
/*  576 */                   jjstateSet[jjnewStateCnt++] = 9; 
/*      */                 break;
/*      */               case 30:
/*  579 */                 if ((0x3FF000000000000L & l) != 0L) {
/*      */                   
/*  581 */                   if (kind > 12)
/*  582 */                     kind = 12; 
/*  583 */                   jjCheckNAddStates(11, 14);
/*      */                 }
/*  585 */                 else if (curChar == '-') {
/*  586 */                   jjCheckNAddTwoStates(25, 26);
/*  587 */                 } else if (curChar == '.') {
/*  588 */                   jjCheckNAddTwoStates(17, 18);
/*  589 */                 }  if ((0x3FF000000000000L & l) != 0L) {
/*      */                   
/*  591 */                   if (kind > 12)
/*  592 */                     kind = 12; 
/*  593 */                   jjCheckNAddStates(15, 17);
/*      */                 } 
/*  595 */                 if ((0x3FF000000000000L & l) != 0L) {
/*      */                   
/*  597 */                   if (kind > 12)
/*  598 */                     kind = 12; 
/*  599 */                   jjCheckNAddTwoStates(25, 19);
/*      */                 } 
/*  601 */                 if ((0x3FF000000000000L & l) != 0L) {
/*      */                   
/*  603 */                   if (kind > 11)
/*  604 */                     kind = 11; 
/*  605 */                   jjCheckNAdd(24);
/*      */                 } 
/*      */                 break;
/*      */               case 1:
/*  609 */                 if (curChar == '/')
/*  610 */                   kind = 6; 
/*      */                 break;
/*      */               case 9:
/*  613 */                 if (curChar == '*' && kind > 7)
/*  614 */                   kind = 7; 
/*      */                 break;
/*      */               case 10:
/*  617 */                 if (curChar == '*')
/*  618 */                   jjstateSet[jjnewStateCnt++] = 9; 
/*      */                 break;
/*      */               case 11:
/*  621 */                 if (curChar == '%')
/*  622 */                   kind = 10; 
/*      */                 break;
/*      */               case 14:
/*  625 */                 if ((0x3FF000000000000L & l) != 0L)
/*  626 */                   jjAddStates(18, 19); 
/*      */                 break;
/*      */               case 16:
/*  629 */                 if (curChar == '.')
/*  630 */                   jjCheckNAddTwoStates(17, 18); 
/*      */                 break;
/*      */               case 17:
/*  633 */                 if (curChar == '-')
/*  634 */                   jjCheckNAdd(18); 
/*      */                 break;
/*      */               case 18:
/*  637 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  639 */                 if (kind > 12)
/*  640 */                   kind = 12; 
/*  641 */                 jjCheckNAddTwoStates(18, 19);
/*      */                 break;
/*      */               case 20:
/*  644 */                 if ((0x280000000000L & l) != 0L)
/*  645 */                   jjCheckNAddTwoStates(21, 22); 
/*      */                 break;
/*      */               case 21:
/*  648 */                 if (curChar == '-')
/*  649 */                   jjCheckNAdd(22); 
/*      */                 break;
/*      */               case 22:
/*  652 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  654 */                 if (kind > 12)
/*  655 */                   kind = 12; 
/*  656 */                 jjCheckNAdd(22);
/*      */                 break;
/*      */               case 23:
/*  659 */                 if (curChar == '-')
/*  660 */                   jjCheckNAddStates(5, 10); 
/*      */                 break;
/*      */               case 24:
/*  663 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  665 */                 if (kind > 11)
/*  666 */                   kind = 11; 
/*  667 */                 jjCheckNAdd(24);
/*      */                 break;
/*      */               case 25:
/*  670 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  672 */                 if (kind > 12)
/*  673 */                   kind = 12; 
/*  674 */                 jjCheckNAddTwoStates(25, 19);
/*      */                 break;
/*      */               case 26:
/*  677 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  679 */                 if (kind > 12)
/*  680 */                   kind = 12; 
/*  681 */                 jjCheckNAddStates(15, 17);
/*      */                 break;
/*      */               case 27:
/*  684 */                 if (curChar == '.')
/*  685 */                   jjCheckNAddTwoStates(28, 29); 
/*      */                 break;
/*      */               case 28:
/*  688 */                 if (curChar == '-')
/*  689 */                   jjCheckNAdd(29); 
/*      */                 break;
/*      */               case 29:
/*  692 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  694 */                 if (kind > 12)
/*  695 */                   kind = 12; 
/*  696 */                 jjCheckNAddTwoStates(29, 19);
/*      */                 break;
/*      */               case 31:
/*  699 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  701 */                 if (kind > 12)
/*  702 */                   kind = 12; 
/*  703 */                 jjCheckNAddStates(11, 14);
/*      */                 break;
/*      */               case 32:
/*  706 */                 if ((0x3FF000000000000L & l) == 0L)
/*      */                   break; 
/*  708 */                 if (kind > 11)
/*  709 */                   kind = 11; 
/*  710 */                 jjCheckNAddStates(0, 4);
/*      */                 break;
/*      */             } 
/*      */           
/*  714 */           } while (i != startsAt);
/*      */         }
/*  716 */         else if (curChar < '') {
/*      */           
/*  718 */           long l = 1L << (curChar & 0x3F);
/*      */           
/*      */           do {
/*  721 */             switch (jjstateSet[--i]) {
/*      */               
/*      */               case 0:
/*  724 */                 if ((0x7FFFFFE07FFFFFEL & l) != 0L) {
/*      */                   
/*  726 */                   if (kind > 10)
/*  727 */                     kind = 10; 
/*  728 */                   jjCheckNAddTwoStates(13, 14);
/*      */                 }
/*  730 */                 else if (curChar == '^') {
/*      */                   
/*  732 */                   if (kind > 7)
/*  733 */                     kind = 7; 
/*      */                 } 
/*  735 */                 if (curChar == 'P') {
/*  736 */                   jjstateSet[jjnewStateCnt++] = 6; break;
/*  737 */                 }  if (curChar == 'p')
/*  738 */                   jjstateSet[jjnewStateCnt++] = 3; 
/*      */                 break;
/*      */               case 2:
/*  741 */                 if (curChar == 'r' && kind > 6)
/*  742 */                   kind = 6; 
/*      */                 break;
/*      */               case 3:
/*  745 */                 if (curChar == 'e')
/*  746 */                   jjstateSet[jjnewStateCnt++] = 2; 
/*      */                 break;
/*      */               case 4:
/*  749 */                 if (curChar == 'p')
/*  750 */                   jjstateSet[jjnewStateCnt++] = 3; 
/*      */                 break;
/*      */               case 5:
/*  753 */                 if (curChar == 'R' && kind > 6)
/*  754 */                   kind = 6; 
/*      */                 break;
/*      */               case 6:
/*  757 */                 if (curChar == 'E')
/*  758 */                   jjstateSet[jjnewStateCnt++] = 5; 
/*      */                 break;
/*      */               case 7:
/*  761 */                 if (curChar == 'P')
/*  762 */                   jjstateSet[jjnewStateCnt++] = 6; 
/*      */                 break;
/*      */               case 8:
/*  765 */                 if (curChar == '^')
/*  766 */                   kind = 7; 
/*      */                 break;
/*      */               case 12:
/*  769 */                 if ((0x7FFFFFE07FFFFFEL & l) == 0L)
/*      */                   break; 
/*  771 */                 if (kind > 10)
/*  772 */                   kind = 10; 
/*  773 */                 jjCheckNAddTwoStates(13, 14);
/*      */                 break;
/*      */               case 13:
/*  776 */                 if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                   break; 
/*  778 */                 if (kind > 10)
/*  779 */                   kind = 10; 
/*  780 */                 jjCheckNAddTwoStates(13, 14);
/*      */                 break;
/*      */               case 15:
/*  783 */                 if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                   break; 
/*  785 */                 if (kind > 10)
/*  786 */                   kind = 10; 
/*  787 */                 jjCheckNAddTwoStates(14, 15);
/*      */                 break;
/*      */               case 19:
/*  790 */                 if ((0x2000000020L & l) != 0L) {
/*  791 */                   jjAddStates(20, 22);
/*      */                 }
/*      */                 break;
/*      */             } 
/*  795 */           } while (i != startsAt);
/*      */         } else {
/*      */ 
/*      */           
/*      */           do {
/*      */ 
/*      */ 
/*      */             
/*  803 */             switch (jjstateSet[--i]) {
/*      */             
/*      */             } 
/*      */           
/*  807 */           } while (i != startsAt);
/*      */         } 
/*  809 */         if (kind != Integer.MAX_VALUE) {
/*      */           
/*  811 */           jjmatchedKind = kind;
/*  812 */           jjmatchedPos = curPos;
/*  813 */           kind = Integer.MAX_VALUE;
/*      */         } 
/*  815 */         curPos++;
/*  816 */         if ((i = jjnewStateCnt) == (startsAt = 33 - (jjnewStateCnt = startsAt)))
/*  817 */           return curPos;  
/*  818 */         try { curChar = UnitsParser.ASCII_CharStream.readChar(); }
/*  819 */         catch (IOException e) { return curPos; }
/*      */       
/*      */       } 
/*  822 */     } static final int[] jjnextStates = new int[] { 24, 25, 26, 27, 19, 24, 25, 26, 16, 30, 31, 25, 26, 27, 19, 26, 27, 19, 14, 15, 20, 21, 22 };
/*      */ 
/*      */ 
/*      */     
/*  826 */     public static final String[] jjstrLiteralImages = new String[] { "", null, null, "+", "-", null, null, null, "(", ")", null, null, null, null, null, null, null };
/*      */ 
/*      */     
/*  829 */     public static final String[] lexStateNames = new String[] { "DEFAULT" };
/*      */ 
/*      */     
/*  832 */     static final long[] jjtoToken = new long[] { 8185L };
/*      */ 
/*      */     
/*  835 */     static final long[] jjtoSkip = new long[] { 6L };
/*      */     
/*      */     private static UnitsParser.ASCII_CharStream input_stream;
/*      */     
/*  839 */     private static final int[] jjrounds = new int[33];
/*  840 */     private static final int[] jjstateSet = new int[66];
/*      */     protected static char curChar;
/*      */     
/*      */     public UnitsParserTokenManager(UnitsParser.ASCII_CharStream stream) {
/*  844 */       if (input_stream != null)
/*  845 */         throw new UnitsParser.TokenMgrError("ERROR: Second call to constructor of static lexer. You must use ReInit() to initialize the static variables.", 1); 
/*  846 */       input_stream = stream;
/*      */     }
/*      */     
/*      */     public UnitsParserTokenManager(UnitsParser.ASCII_CharStream stream, int lexState) {
/*  850 */       this(stream);
/*  851 */       SwitchTo(lexState);
/*      */     }
/*      */     
/*      */     public static void ReInit(UnitsParser.ASCII_CharStream stream) {
/*  855 */       jjmatchedPos = jjnewStateCnt = 0;
/*  856 */       curLexState = defaultLexState;
/*  857 */       input_stream = stream;
/*  858 */       ReInitRounds();
/*      */     }
/*      */ 
/*      */     
/*      */     private static final void ReInitRounds() {
/*  863 */       jjround = -2147483647;
/*  864 */       for (int i = 33; i-- > 0;)
/*  865 */         jjrounds[i] = Integer.MIN_VALUE; 
/*      */     }
/*      */     
/*      */     public static void ReInit(UnitsParser.ASCII_CharStream stream, int lexState) {
/*  869 */       ReInit(stream);
/*  870 */       SwitchTo(lexState);
/*      */     }
/*      */     
/*      */     public static void SwitchTo(int lexState) {
/*  874 */       if (lexState >= 1 || lexState < 0) {
/*  875 */         throw new UnitsParser.TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */       }
/*  877 */       curLexState = lexState;
/*      */     }
/*      */ 
/*      */     
/*      */     private static final UnitsParser.Token jjFillToken() {
/*  882 */       UnitsParser.Token t = UnitsParser.Token.newToken(jjmatchedKind);
/*  883 */       t.kind = jjmatchedKind;
/*  884 */       String im = jjstrLiteralImages[jjmatchedKind];
/*  885 */       t.image = (im == null) ? UnitsParser.ASCII_CharStream.GetImage() : im;
/*  886 */       t.beginLine = UnitsParser.ASCII_CharStream.getBeginLine();
/*  887 */       t.beginColumn = UnitsParser.ASCII_CharStream.getBeginColumn();
/*  888 */       t.endLine = UnitsParser.ASCII_CharStream.getEndLine();
/*  889 */       t.endColumn = UnitsParser.ASCII_CharStream.getEndColumn();
/*  890 */       return t;
/*      */     }
/*      */     
/*  893 */     static int curLexState = 0;
/*  894 */     static int defaultLexState = 0;
/*      */     
/*      */     static int jjnewStateCnt;
/*      */     
/*      */     static int jjround;
/*      */     
/*      */     static int jjmatchedPos;
/*      */     
/*      */     static int jjmatchedKind;
/*      */     
/*      */     public static final UnitsParser.Token getNextToken() {
/*  905 */       int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         try {
/*  912 */           curChar = UnitsParser.ASCII_CharStream.BeginToken();
/*      */         }
/*  914 */         catch (IOException e) {
/*      */           
/*  916 */           jjmatchedKind = 0;
/*  917 */           UnitsParser.Token matchedToken = jjFillToken();
/*  918 */           return matchedToken;
/*      */         } 
/*      */         
/*  921 */         try { UnitsParser.ASCII_CharStream.backup(0);
/*  922 */           while (curChar <= ' ' && (0x100000200L & 1L << curChar) != 0L) {
/*  923 */             curChar = UnitsParser.ASCII_CharStream.BeginToken();
/*      */           } }
/*  925 */         catch (IOException e1) { continue; }
/*  926 */          jjmatchedKind = Integer.MAX_VALUE;
/*  927 */         jjmatchedPos = 0;
/*  928 */         curPos = jjMoveStringLiteralDfa0_0();
/*  929 */         if (jjmatchedKind != Integer.MAX_VALUE) {
/*      */           
/*  931 */           if (jjmatchedPos + 1 < curPos)
/*  932 */             UnitsParser.ASCII_CharStream.backup(curPos - jjmatchedPos - 1); 
/*  933 */           if ((jjtoToken[jjmatchedKind >> 6] & 1L << (jjmatchedKind & 0x3F)) != 0L) {
/*      */             
/*  935 */             UnitsParser.Token matchedToken = jjFillToken();
/*  936 */             return matchedToken;
/*      */           } 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*  943 */       int error_line = UnitsParser.ASCII_CharStream.getEndLine();
/*  944 */       int error_column = UnitsParser.ASCII_CharStream.getEndColumn();
/*  945 */       String error_after = null;
/*  946 */       boolean EOFSeen = false; try {
/*  947 */         UnitsParser.ASCII_CharStream.readChar(); UnitsParser.ASCII_CharStream.backup(1);
/*  948 */       } catch (IOException e1) {
/*  949 */         EOFSeen = true;
/*  950 */         error_after = (curPos <= 1) ? "" : UnitsParser.ASCII_CharStream.GetImage();
/*  951 */         if (curChar == '\n' || curChar == '\r') {
/*  952 */           error_line++;
/*  953 */           error_column = 0;
/*      */         } else {
/*      */           
/*  956 */           error_column++;
/*      */         } 
/*  958 */       }  if (!EOFSeen) {
/*  959 */         UnitsParser.ASCII_CharStream.backup(1);
/*  960 */         error_after = (curPos <= 1) ? "" : UnitsParser.ASCII_CharStream.GetImage();
/*      */       } 
/*  962 */       throw new UnitsParser.TokenMgrError(EOFSeen, curLexState, error_line, error_column, error_after, curChar, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class TokenMgrError
/*      */     extends Error
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final int LEXICAL_ERROR = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final int STATIC_LEXER_ERROR = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final int INVALID_LEXICAL_STATE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final int LOOP_DETECTED = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int errorCode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static final String addEscapes(String str) {
/* 1011 */       StringBuffer retval = new StringBuffer();
/*      */       
/* 1013 */       for (int i = 0; i < str.length(); i++) {
/* 1014 */         char ch; switch (str.charAt(i)) {
/*      */           case '\000':
/*      */             break;
/*      */           
/*      */           case '\b':
/* 1019 */             retval.append("\\b");
/*      */             break;
/*      */           case '\t':
/* 1022 */             retval.append("\\t");
/*      */             break;
/*      */           case '\n':
/* 1025 */             retval.append("\\n");
/*      */             break;
/*      */           case '\f':
/* 1028 */             retval.append("\\f");
/*      */             break;
/*      */           case '\r':
/* 1031 */             retval.append("\\r");
/*      */             break;
/*      */           case '"':
/* 1034 */             retval.append("\\\"");
/*      */             break;
/*      */           case '\'':
/* 1037 */             retval.append("\\'");
/*      */             break;
/*      */           case '\\':
/* 1040 */             retval.append("\\\\");
/*      */             break;
/*      */           default:
/* 1043 */             if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/* 1044 */               String s = "0000" + Integer.toString(ch, 16);
/* 1045 */               retval.append("\\u" + s.substring(s.length() - 4, s.length())); break;
/*      */             } 
/* 1047 */             retval.append(ch);
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/* 1052 */       return retval.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String LexicalError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar) {
/* 1071 */       return "Lexical error at line " + errorLine + ", column " + errorColumn + ".  Encountered: " + (EOFSeen ? "<EOF> " : ("\"" + addEscapes(String.valueOf(curChar)) + "\"" + " (" + curChar + "), ")) + "after : \"" + addEscapes(errorAfter) + "\"";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getMessage() {
/* 1089 */       return super.getMessage();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TokenMgrError() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public TokenMgrError(String message, int reason) {
/* 1100 */       super(message);
/* 1101 */       this.errorCode = reason;
/*      */     }
/*      */ 
/*      */     
/*      */     public TokenMgrError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar, int reason) {
/* 1106 */       this(LexicalError(EOFSeen, lexState, errorLine, errorColumn, errorAfter, curChar), reason);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ASCII_CharStream
/*      */   {
/*      */     public static final boolean staticFlag = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static int bufsize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static int available;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static int tokenBegin;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1169 */     public static int bufpos = -1;
/*      */     
/*      */     private static int[] bufline;
/*      */     private static int[] bufcolumn;
/* 1173 */     private static int column = 0;
/* 1174 */     private static int line = 1;
/*      */     
/*      */     private static boolean prevCharIsCR = false;
/*      */     
/*      */     private static boolean prevCharIsLF = false;
/*      */     
/*      */     private static Reader inputStream;
/*      */     private static char[] buffer;
/* 1182 */     private static int maxNextCharInd = 0;
/* 1183 */     private static int inBuf = 0;
/*      */ 
/*      */     
/*      */     private static final void ExpandBuff(boolean wrapAround) {
/* 1187 */       char[] newbuffer = new char[bufsize + 2048];
/* 1188 */       int[] newbufline = new int[bufsize + 2048];
/* 1189 */       int[] newbufcolumn = new int[bufsize + 2048];
/*      */ 
/*      */       
/*      */       try {
/* 1193 */         if (wrapAround)
/*      */         {
/* 1195 */           System.arraycopy(buffer, tokenBegin, newbuffer, 0, bufsize - tokenBegin);
/* 1196 */           System.arraycopy(buffer, 0, newbuffer, bufsize - tokenBegin, bufpos);
/*      */           
/* 1198 */           buffer = newbuffer;
/*      */           
/* 1200 */           System.arraycopy(bufline, tokenBegin, newbufline, 0, bufsize - tokenBegin);
/* 1201 */           System.arraycopy(bufline, 0, newbufline, bufsize - tokenBegin, bufpos);
/* 1202 */           bufline = newbufline;
/*      */           
/* 1204 */           System.arraycopy(bufcolumn, tokenBegin, newbufcolumn, 0, bufsize - tokenBegin);
/* 1205 */           System.arraycopy(bufcolumn, 0, newbufcolumn, bufsize - tokenBegin, bufpos);
/* 1206 */           bufcolumn = newbufcolumn;
/*      */           
/* 1208 */           maxNextCharInd = bufpos += bufsize - tokenBegin;
/*      */         }
/*      */         else
/*      */         {
/* 1212 */           System.arraycopy(buffer, tokenBegin, newbuffer, 0, bufsize - tokenBegin);
/* 1213 */           buffer = newbuffer;
/*      */           
/* 1215 */           System.arraycopy(bufline, tokenBegin, newbufline, 0, bufsize - tokenBegin);
/* 1216 */           bufline = newbufline;
/*      */           
/* 1218 */           System.arraycopy(bufcolumn, tokenBegin, newbufcolumn, 0, bufsize - tokenBegin);
/* 1219 */           bufcolumn = newbufcolumn;
/*      */           
/* 1221 */           maxNextCharInd = bufpos -= tokenBegin;
/*      */         }
/*      */       
/* 1224 */       } catch (Throwable t) {
/*      */         
/* 1226 */         throw new Error(t.getMessage());
/*      */       } 
/*      */ 
/*      */       
/* 1230 */       bufsize += 2048;
/* 1231 */       available = bufsize;
/* 1232 */       tokenBegin = 0;
/*      */     }
/*      */ 
/*      */     
/*      */     private static final void FillBuff() throws IOException {
/* 1237 */       if (maxNextCharInd == available)
/*      */       {
/* 1239 */         if (available == bufsize) {
/*      */           
/* 1241 */           if (tokenBegin > 2048) {
/*      */             
/* 1243 */             bufpos = maxNextCharInd = 0;
/* 1244 */             available = tokenBegin;
/*      */           }
/* 1246 */           else if (tokenBegin < 0) {
/* 1247 */             bufpos = maxNextCharInd = 0;
/*      */           } else {
/* 1249 */             ExpandBuff(false);
/*      */           } 
/* 1251 */         } else if (available > tokenBegin) {
/* 1252 */           available = bufsize;
/* 1253 */         } else if (tokenBegin - available < 2048) {
/* 1254 */           ExpandBuff(true);
/*      */         } else {
/* 1256 */           available = tokenBegin;
/*      */         } 
/*      */       }
/*      */       try {
/*      */         int i;
/* 1261 */         if ((i = inputStream.read(buffer, maxNextCharInd, available - maxNextCharInd)) == -1) {
/*      */ 
/*      */           
/* 1264 */           inputStream.close();
/* 1265 */           throw new IOException();
/*      */         } 
/*      */         
/* 1268 */         maxNextCharInd += i;
/*      */         
/*      */         return;
/* 1271 */       } catch (IOException e) {
/* 1272 */         bufpos--;
/* 1273 */         backup(0);
/* 1274 */         if (tokenBegin == -1)
/* 1275 */           tokenBegin = bufpos; 
/* 1276 */         throw e;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public static final char BeginToken() throws IOException {
/* 1282 */       tokenBegin = -1;
/* 1283 */       char c = readChar();
/* 1284 */       tokenBegin = bufpos;
/*      */       
/* 1286 */       return c;
/*      */     }
/*      */ 
/*      */     
/*      */     private static final void UpdateLineColumn(char c) {
/* 1291 */       column++;
/*      */       
/* 1293 */       if (prevCharIsLF) {
/*      */         
/* 1295 */         prevCharIsLF = false;
/* 1296 */         line += column = 1;
/*      */       }
/* 1298 */       else if (prevCharIsCR) {
/*      */         
/* 1300 */         prevCharIsCR = false;
/* 1301 */         if (c == '\n') {
/*      */           
/* 1303 */           prevCharIsLF = true;
/*      */         } else {
/*      */           
/* 1306 */           line += column = 1;
/*      */         } 
/*      */       } 
/* 1309 */       switch (c) {
/*      */         
/*      */         case '\r':
/* 1312 */           prevCharIsCR = true;
/*      */           break;
/*      */         case '\n':
/* 1315 */           prevCharIsLF = true;
/*      */           break;
/*      */         case '\t':
/* 1318 */           column--;
/* 1319 */           column += 8 - (column & 0x7);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1325 */       bufline[bufpos] = line;
/* 1326 */       bufcolumn[bufpos] = column;
/*      */     }
/*      */ 
/*      */     
/*      */     public static final char readChar() throws IOException {
/* 1331 */       if (inBuf > 0) {
/*      */         
/* 1333 */         inBuf--;
/* 1334 */         return (char)(0xFF & buffer[(bufpos == bufsize - 1) ? (bufpos = 0) : ++bufpos]);
/*      */       } 
/*      */       
/* 1337 */       if (++bufpos >= maxNextCharInd) {
/* 1338 */         FillBuff();
/*      */       }
/* 1340 */       char c = (char)(0xFF & buffer[bufpos]);
/*      */       
/* 1342 */       UpdateLineColumn(c);
/* 1343 */       return c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int getColumn() {
/* 1352 */       return bufcolumn[bufpos];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int getLine() {
/* 1361 */       return bufline[bufpos];
/*      */     }
/*      */     
/*      */     public static final int getEndColumn() {
/* 1365 */       return bufcolumn[bufpos];
/*      */     }
/*      */     
/*      */     public static final int getEndLine() {
/* 1369 */       return bufline[bufpos];
/*      */     }
/*      */     
/*      */     public static final int getBeginColumn() {
/* 1373 */       return bufcolumn[tokenBegin];
/*      */     }
/*      */     
/*      */     public static final int getBeginLine() {
/* 1377 */       return bufline[tokenBegin];
/*      */     }
/*      */ 
/*      */     
/*      */     public static final void backup(int amount) {
/* 1382 */       inBuf += amount;
/* 1383 */       if ((bufpos -= amount) < 0) {
/* 1384 */         bufpos += bufsize;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public ASCII_CharStream(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 1390 */       if (inputStream != null) {
/* 1391 */         throw new Error("\n   ERROR: Second call to the constructor of a static ASCII_CharStream.  You must\n       either use ReInit() or set the JavaCC option STATIC to false\n       during the generation of this class.");
/*      */       }
/*      */       
/* 1394 */       inputStream = dstream;
/* 1395 */       line = startline;
/* 1396 */       column = startcolumn - 1;
/*      */       
/* 1398 */       available = bufsize = buffersize;
/* 1399 */       buffer = new char[buffersize];
/* 1400 */       bufline = new int[buffersize];
/* 1401 */       bufcolumn = new int[buffersize];
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ASCII_CharStream(Reader dstream, int startline, int startcolumn) {
/* 1407 */       this(dstream, startline, startcolumn, 4096);
/*      */     }
/*      */ 
/*      */     
/*      */     public static void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 1412 */       inputStream = dstream;
/* 1413 */       line = startline;
/* 1414 */       column = startcolumn - 1;
/*      */       
/* 1416 */       if (buffer == null || buffersize != buffer.length) {
/*      */         
/* 1418 */         available = bufsize = buffersize;
/* 1419 */         buffer = new char[buffersize];
/* 1420 */         bufline = new int[buffersize];
/* 1421 */         bufcolumn = new int[buffersize];
/*      */       } 
/* 1423 */       prevCharIsLF = prevCharIsCR = false;
/* 1424 */       tokenBegin = inBuf = maxNextCharInd = 0;
/* 1425 */       bufpos = -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static void ReInit(Reader dstream, int startline, int startcolumn) {
/* 1431 */       ReInit(dstream, startline, startcolumn, 4096);
/*      */     }
/*      */ 
/*      */     
/*      */     public ASCII_CharStream(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 1436 */       this(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ASCII_CharStream(InputStream dstream, int startline, int startcolumn) {
/* 1442 */       this(dstream, startline, startcolumn, 4096);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) {
/* 1448 */       ReInit(new InputStreamReader(dstream), startline, startcolumn, 4096);
/*      */     }
/*      */ 
/*      */     
/*      */     public static void ReInit(InputStream dstream, int startline, int startcolumn) {
/* 1453 */       ReInit(dstream, startline, startcolumn, 4096);
/*      */     }
/*      */     
/*      */     public static final String GetImage() {
/* 1457 */       if (bufpos >= tokenBegin) {
/* 1458 */         return new String(buffer, tokenBegin, bufpos - tokenBegin + 1);
/*      */       }
/* 1460 */       return new String(buffer, tokenBegin, bufsize - tokenBegin) + new String(buffer, 0, bufpos + 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static final char[] GetSuffix(int len) {
/* 1466 */       char[] ret = new char[len];
/*      */       
/* 1468 */       if (bufpos + 1 >= len) {
/* 1469 */         System.arraycopy(buffer, bufpos - len + 1, ret, 0, len);
/*      */       } else {
/*      */         
/* 1472 */         System.arraycopy(buffer, bufsize - len - bufpos - 1, ret, 0, len - bufpos - 1);
/*      */         
/* 1474 */         System.arraycopy(buffer, 0, ret, len - bufpos - 1, bufpos + 1);
/*      */       } 
/*      */       
/* 1477 */       return ret;
/*      */     }
/*      */ 
/*      */     
/*      */     public static void Done() {
/* 1482 */       buffer = null;
/* 1483 */       bufline = null;
/* 1484 */       bufcolumn = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static void adjustBeginLineColumn(int newLine, int newCol) {
/* 1492 */       int len, start = tokenBegin;
/*      */ 
/*      */       
/* 1495 */       if (bufpos >= tokenBegin) {
/*      */         
/* 1497 */         len = bufpos - tokenBegin + inBuf + 1;
/*      */       }
/*      */       else {
/*      */         
/* 1501 */         len = bufsize - tokenBegin + bufpos + 1 + inBuf;
/*      */       } 
/*      */       
/* 1504 */       int i = 0, j = 0, k = 0;
/* 1505 */       int nextColDiff = 0, columnDiff = 0;
/*      */ 
/*      */       
/* 1508 */       while (i < len && bufline[j = start % bufsize] == bufline[k = ++start % bufsize]) {
/*      */         
/* 1510 */         bufline[j] = newLine;
/* 1511 */         nextColDiff = columnDiff + bufcolumn[k] - bufcolumn[j];
/* 1512 */         bufcolumn[j] = newCol + columnDiff;
/* 1513 */         columnDiff = nextColDiff;
/* 1514 */         i++;
/*      */       } 
/*      */       
/* 1517 */       if (i < len) {
/*      */         
/* 1519 */         bufline[j] = newLine++;
/* 1520 */         bufcolumn[j] = newCol + columnDiff;
/*      */         
/* 1522 */         while (i++ < len) {
/*      */           
/* 1524 */           if (bufline[j = start % bufsize] != bufline[++start % bufsize]) {
/* 1525 */             bufline[j] = newLine++; continue;
/*      */           } 
/* 1527 */           bufline[j] = newLine;
/*      */         } 
/*      */       } 
/*      */       
/* 1531 */       line = bufline[j];
/* 1532 */       column = bufcolumn[j];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ParseException
/*      */     extends Exception
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean specialConstructor;
/*      */ 
/*      */ 
/*      */     
/*      */     public UnitsParser.Token currentToken;
/*      */ 
/*      */ 
/*      */     
/*      */     public int[][] expectedTokenSequences;
/*      */ 
/*      */ 
/*      */     
/*      */     public String[] tokenImage;
/*      */ 
/*      */ 
/*      */     
/*      */     protected String eol;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ParseException(UnitsParser.Token currentTokenVal, int[][] expectedTokenSequencesVal, String[] tokenImageVal)
/*      */     {
/* 1569 */       super("");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1676 */       this.eol = System.getProperty("line.separator", "\n"); this.specialConstructor = true; this.currentToken = currentTokenVal; this.expectedTokenSequences = expectedTokenSequencesVal; this.tokenImage = tokenImageVal; } public ParseException() { this.eol = System.getProperty("line.separator", "\n"); this.specialConstructor = false; } public ParseException(String message) { super(message); this.eol = System.getProperty("line.separator", "\n");
/*      */       this.specialConstructor = false; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected String add_escapes(String str) {
/* 1684 */       StringBuffer retval = new StringBuffer();
/*      */       
/* 1686 */       for (int i = 0; i < str.length(); i++) {
/* 1687 */         char ch; switch (str.charAt(i)) {
/*      */           case '\000':
/*      */             break;
/*      */           
/*      */           case '\b':
/* 1692 */             retval.append("\\b");
/*      */             break;
/*      */           case '\t':
/* 1695 */             retval.append("\\t");
/*      */             break;
/*      */           case '\n':
/* 1698 */             retval.append("\\n");
/*      */             break;
/*      */           case '\f':
/* 1701 */             retval.append("\\f");
/*      */             break;
/*      */           case '\r':
/* 1704 */             retval.append("\\r");
/*      */             break;
/*      */           case '"':
/* 1707 */             retval.append("\\\"");
/*      */             break;
/*      */           case '\'':
/* 1710 */             retval.append("\\'");
/*      */             break;
/*      */           case '\\':
/* 1713 */             retval.append("\\\\");
/*      */             break;
/*      */           default:
/* 1716 */             if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/* 1717 */               String s = "0000" + Integer.toString(ch, 16);
/* 1718 */               retval.append("\\u" + s.substring(s.length() - 4, s.length())); break;
/*      */             } 
/* 1720 */             retval.append(ch);
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/* 1725 */       return retval.toString();
/*      */     }
/*      */     
/*      */     public String getMessage() {
/*      */       if (!this.specialConstructor)
/*      */         return super.getMessage(); 
/*      */       String expected = "";
/*      */       int maxSize = 0;
/*      */       for (int i = 0; i < this.expectedTokenSequences.length; i++) {
/*      */         if (maxSize < (this.expectedTokenSequences[i]).length)
/*      */           maxSize = (this.expectedTokenSequences[i]).length; 
/*      */         for (int k = 0; k < (this.expectedTokenSequences[i]).length; k++)
/*      */           expected = expected + this.tokenImage[this.expectedTokenSequences[i][k]] + " "; 
/*      */         if (this.expectedTokenSequences[i][(this.expectedTokenSequences[i]).length - 1] != 0)
/*      */           expected = expected + "..."; 
/*      */         expected = expected + this.eol + "    ";
/*      */       } 
/*      */       String retval = "Encountered \"";
/*      */       UnitsParser.Token tok = this.currentToken.next;
/*      */       for (int j = 0; j < maxSize; j++) {
/*      */         if (j != 0)
/*      */           retval = retval + " "; 
/*      */         if (tok.kind == 0) {
/*      */           retval = retval + this.tokenImage[0];
/*      */           break;
/*      */         } 
/*      */         retval = retval + add_escapes(tok.image);
/*      */         tok = tok.next;
/*      */       } 
/*      */       retval = retval + "\" at line " + this.currentToken.next.beginLine + ", column " + this.currentToken.next.beginColumn + "." + this.eol;
/*      */       if (this.expectedTokenSequences.length == 1) {
/*      */         retval = retval + "Was expecting:" + this.eol + "    ";
/*      */       } else {
/*      */         retval = retval + "Was expecting one of:" + this.eol + "    ";
/*      */       } 
/*      */       retval = retval + expected;
/*      */       return retval;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/UnitsParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */