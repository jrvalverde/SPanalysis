/*     */ package edu.mines.jtk.opengl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Glu
/*     */ {
/*     */   public static final int GLU_FALSE = 0;
/*     */   public static final int GLU_TRUE = 1;
/*     */   public static final int GLU_VERSION_1_1 = 1;
/*     */   public static final int GLU_VERSION_1_2 = 1;
/*     */   public static final int GLU_VERSION_1_3 = 1;
/*     */   public static final int GLU_VERSION = 100800;
/*     */   public static final int GLU_EXTENSIONS = 100801;
/*     */   public static final int GLU_INVALID_ENUM = 100900;
/*     */   public static final int GLU_INVALID_VALUE = 100901;
/*     */   public static final int GLU_OUT_OF_MEMORY = 100902;
/*     */   public static final int GLU_INVALID_OPERATION = 100904;
/*     */   
/*     */   public static native int gluBuild1DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte);
/*     */   
/*     */   public static native int gluBuild1DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, short[] paramArrayOfshort);
/*     */   
/*     */   public static native int gluBuild1DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint);
/*     */   
/*     */   public static native int gluBuild2DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, byte[] paramArrayOfbyte);
/*     */   
/*     */   public static native int gluBuild2DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short[] paramArrayOfshort);
/*     */   
/*     */   public static native int gluBuild2DMipmaps(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int[] paramArrayOfint);
/*     */   
/*     */   public static native String gluGetString(int paramInt);
/*     */   
/*     */   public static native void gluLookAt(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9);
/*     */   
/*     */   public static native void gluOrtho2D(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*     */   
/*     */   public static native void gluPerspective(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*     */   
/*     */   public static native void gluPickMatrix(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int[] paramArrayOfint);
/*     */   
/*     */   public static native int gluProject(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int[] paramArrayOfint, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, double[] paramArrayOfdouble5);
/*     */   
/*     */   public static native int gluScaleImage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfbyte1, int paramInt5, int paramInt6, int paramInt7, byte[] paramArrayOfbyte2);
/*     */   
/*     */   public static native int gluScaleImage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short[] paramArrayOfshort1, int paramInt5, int paramInt6, int paramInt7, short[] paramArrayOfshort2);
/*     */   
/*     */   public static native int gluScaleImage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int paramInt6, int paramInt7, int[] paramArrayOfint2);
/*     */   
/*     */   public static native int gluUnProject(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, int[] paramArrayOfint, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, double[] paramArrayOfdouble5);
/*     */   
/*     */   static GlContext getContext() {
/* 148 */     return _context.get();
/*     */   }
/*     */   
/*     */   static void setContext(GlContext context) {
/* 152 */     _context.set(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private static ThreadLocal<GlContext> _context = new ThreadLocal<GlContext>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 165 */     System.loadLibrary("edu_mines_jtk_opengl");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/Glu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */