/*    */ package edu.mines.jtk.ogl.test;
/*    */ 
/*    */ import edu.mines.jtk.ogl.Gl;
/*    */ import edu.mines.jtk.ogl.GlCanvas;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Hello
/*    */ {
/* 20 */   private static GlCanvas canvas = new GlCanvas() {
/*    */       public void glInit() {
/* 22 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 23 */         System.out.println("OpenGL version=" + Gl.glGetString(7938));
/* 24 */         System.out.println("OpenGL vendor=" + Gl.glGetString(7936));
/*    */       }
/*    */       public void glResize(int x, int y, int width, int height) {
/* 27 */         Gl.glViewport(0, 0, width, height);
/* 28 */         Gl.glMatrixMode(5889);
/* 29 */         Gl.glLoadIdentity();
/* 30 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/*    */       }
/*    */       public void glPaint() {
/* 33 */         Gl.glClear(16384);
/* 34 */         Gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 35 */         Gl.glBegin(9);
/* 36 */         Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 37 */         Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 38 */         Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 39 */         Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 40 */         Gl.glEnd();
/* 41 */         Gl.glFlush();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 45 */     TestSimple.run(args, canvas);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/Hello.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */