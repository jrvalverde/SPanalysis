/*     */ package edu.mines.jtk.lapack;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixSvd
/*     */ {
/*     */   int _m;
/*     */   int _n;
/*     */   int _mn;
/*     */   double[] _s;
/*     */   double[] _u;
/*     */   double[] _vt;
/*     */   
/*     */   public DMatrixSvd(DMatrix a) {
/*  36 */     double[] aa = a.getPackedColumns();
/*  37 */     this._m = a.getM();
/*  38 */     this._n = a.getN();
/*  39 */     this._mn = Math.min(this._m, this._n);
/*  40 */     this._s = new double[this._mn];
/*  41 */     this._u = new double[this._m * this._mn];
/*  42 */     this._vt = new double[this._mn * this._n];
/*  43 */     double[] work = new double[1];
/*  44 */     Lapack.dgesvd(202, 202, this._m, this._n, aa, this._m, this._s, this._u, this._m, this._vt, this._mn, work, -1);
/*  45 */     int lwork = (int)work[0];
/*  46 */     work = new double[lwork];
/*  47 */     Lapack.dgesvd(202, 202, this._m, this._n, aa, this._m, this._s, this._u, this._m, this._vt, this._mn, work, lwork);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getU() {
/*  55 */     return new DMatrix(this._m, this._mn, Array.copy(this._u));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getS() {
/*  63 */     return DMatrix.diagonal(this._s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getSingularValues() {
/*  71 */     return Array.copy(this._s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getV() {
/*  80 */     return (new DMatrix(this._mn, this._n, this._vt)).transpose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getVTranspose() {
/*  89 */     return new DMatrix(this._mn, this._n, Array.copy(this._vt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double norm2() {
/*  97 */     return this._s[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double cond() {
/* 105 */     return this._s[0] / this._s[this._mn - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rank() {
/* 115 */     double eps = Math.ulp(1.0D);
/* 116 */     double tol = Math.max(this._m, this._n) * this._s[0] * eps;
/* 117 */     int r = 0;
/* 118 */     for (int i = 0; i < this._mn; i++) {
/* 119 */       if (this._s[i] > tol)
/* 120 */         r++; 
/*     */     } 
/* 122 */     return r;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrixSvd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */