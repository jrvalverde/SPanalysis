/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import edu.mines.jtk.dsp.FftComplex;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FftBench
/*    */ {
/*    */   public static void main(String[] args) {
/*    */     while (true) {
/* 21 */       for (int nfft = 1; nfft <= 720720; ) {
/* 22 */         int nfftSmall = FftComplex.nfftSmall(nfft);
/* 23 */         int nfftFast = FftComplex.nfftFast(nfft);
/* 24 */         double timeSmall = time(nfftSmall);
/* 25 */         if (nfftFast == nfftSmall) {
/* 26 */           System.out.printf("nsmall=%d tsmall=%.14f\n", new Object[] { Integer.valueOf(nfftSmall), Double.valueOf(timeSmall) });
/*    */         } else {
/* 28 */           double timeFast = (nfftFast > nfftSmall) ? time(nfftFast) : timeSmall;
/* 29 */           System.out.printf("nsmall=%d tsmall=%.14f tfast=%.14f\n", new Object[] { Integer.valueOf(nfftSmall), Double.valueOf(timeSmall), Double.valueOf(timeFast) });
/*    */           
/* 31 */           if (timeSmall < timeFast)
/* 32 */             System.out.println("*** WARNING: tsmall<tfast! ***"); 
/*    */         } 
/* 34 */         nfft = 1 + nfftSmall;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static double time(int nfft) {
/* 40 */     double maxtime = 2.0D;
/* 41 */     FftComplex fft = new FftComplex(nfft);
/* 42 */     float[] cx = Array.crandfloat(nfft);
/*    */     
/* 44 */     Stopwatch sw = new Stopwatch();
/* 45 */     sw.start(); int count;
/* 46 */     for (count = 0; sw.time() < maxtime; count++) {
/* 47 */       fft.complexToComplex(-1, cx, cx);
/* 48 */       fft.complexToComplex(1, cx, cx);
/* 49 */       fft.scale(nfft, cx);
/*    */     } 
/* 51 */     sw.stop();
/* 52 */     double time = sw.time() / count;
/* 53 */     return time;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/FftBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */