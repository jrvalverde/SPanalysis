/*     */ package edu.mines.jtk.sgl.test;
/*     */ 
/*     */ import edu.mines.jtk.sgl.BoundingSphere;
/*     */ import edu.mines.jtk.sgl.ColorState;
/*     */ import edu.mines.jtk.sgl.LightModelState;
/*     */ import edu.mines.jtk.sgl.MaterialState;
/*     */ import edu.mines.jtk.sgl.Node;
/*     */ import edu.mines.jtk.sgl.OrbitView;
/*     */ import edu.mines.jtk.sgl.State;
/*     */ import edu.mines.jtk.sgl.StateSet;
/*     */ import edu.mines.jtk.sgl.TriangleGroup;
/*     */ import edu.mines.jtk.sgl.World;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TriangleGroupTest
/*     */ {
/*     */   public static void main(String[] args) {
/*  25 */     float[] xyz = makeSineWave();
/*  26 */     xyz = addBulge(xyz);
/*  27 */     xyz = addTear(xyz);
/*  28 */     float[] rgb = makeColors(xyz);
/*     */ 
/*     */ 
/*     */     
/*  32 */     TriangleGroup tg = new TriangleGroup(true, xyz, rgb);
/*  33 */     System.out.println("TriangleGroup bounding sphere =\n" + tg.getBoundingSphere(true));
/*     */ 
/*     */     
/*  36 */     StateSet states = new StateSet();
/*  37 */     ColorState cs = new ColorState();
/*  38 */     cs.setColor(Color.CYAN);
/*  39 */     states.add((State)cs);
/*  40 */     LightModelState lms = new LightModelState();
/*  41 */     lms.setTwoSide(true);
/*  42 */     states.add((State)lms);
/*  43 */     MaterialState ms = new MaterialState();
/*  44 */     ms.setColorMaterial(5634);
/*  45 */     ms.setSpecular(Color.white);
/*  46 */     ms.setShininess(100.0F);
/*  47 */     states.add((State)ms);
/*  48 */     tg.setStates(states);
/*     */     
/*  50 */     World world = new World();
/*  51 */     world.addChild((Node)tg);
/*     */     
/*  53 */     TestFrame frame = new TestFrame(world);
/*  54 */     OrbitView view = frame.getOrbitView();
/*  55 */     view.setWorldSphere(new BoundingSphere(5.0D, 5.0D, 5.0D, 5.0D));
/*  56 */     frame.setSize(new Dimension(800, 600));
/*  57 */     frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private static float[] makeSineWave() {
/*  61 */     int nx = 100;
/*  62 */     int ny = 100;
/*  63 */     float dx = 10.0F / nx;
/*  64 */     float dy = 10.0F / ny;
/*  65 */     float[] xyz = new float[18 * nx * ny];
/*  66 */     for (int ix = 0, i = 0; ix < nx; ix++) {
/*  67 */       float x0 = ix * dx;
/*  68 */       float x1 = (ix + 1) * dx;
/*  69 */       for (int iy = 0; iy < ny; iy++) {
/*  70 */         float y0 = iy * dy;
/*  71 */         float y1 = (iy + 1) * dy;
/*  72 */         xyz[i++] = x0; xyz[i++] = y0; xyz[i++] = sin(x0, y0);
/*  73 */         xyz[i++] = x0; xyz[i++] = y1; xyz[i++] = sin(x0, y1);
/*  74 */         xyz[i++] = x1; xyz[i++] = y0; xyz[i++] = sin(x1, y0);
/*  75 */         xyz[i++] = x1; xyz[i++] = y0; xyz[i++] = sin(x1, y0);
/*  76 */         xyz[i++] = x0; xyz[i++] = y1; xyz[i++] = sin(x0, y1);
/*  77 */         xyz[i++] = x1; xyz[i++] = y1; xyz[i++] = sin(x1, y1);
/*     */       } 
/*     */     } 
/*  80 */     return xyz;
/*     */   }
/*     */   private static float sin(float x, float y) {
/*  83 */     return (float)(5.0D + 0.25D * Math.sin((x + y)));
/*     */   }
/*     */   
/*     */   private static float[] addBulge(float[] xyz) {
/*  87 */     int n = xyz.length;
/*  88 */     float[] t = new float[n];
/*  89 */     for (int i = 0; i < n; i += 3) {
/*  90 */       float x = xyz[i];
/*  91 */       float y = xyz[i + 1];
/*  92 */       float z = xyz[i + 2];
/*  93 */       z -= exp(x, y);
/*  94 */       t[i] = x;
/*  95 */       t[i + 1] = y;
/*  96 */       t[i + 2] = z;
/*     */     } 
/*  98 */     return t;
/*     */   }
/*     */   private static float exp(float x, float y) {
/* 101 */     x -= 5.0F;
/* 102 */     y -= 5.0F;
/* 103 */     x *= 0.4F;
/* 104 */     y *= 0.8F;
/* 105 */     return (float)(2.0D * Math.exp((-x * x - y * y)));
/*     */   }
/*     */   
/*     */   private static float[] addTear(float[] xyz) {
/* 109 */     int n = xyz.length;
/* 110 */     float[] t = new float[n];
/* 111 */     int nt = n / 9;
/* 112 */     for (int it = 0, i = 0, j = 0; it < nt; it++) {
/* 113 */       float xa = xyz[i++];
/* 114 */       float ya = xyz[i++];
/* 115 */       float za = xyz[i++];
/* 116 */       float xb = xyz[i++];
/* 117 */       float yb = xyz[i++];
/* 118 */       float zb = xyz[i++];
/* 119 */       float xc = xyz[i++];
/* 120 */       float yc = xyz[i++];
/* 121 */       float zc = xyz[i++];
/* 122 */       float x = 0.333333F * (xa + xb + xc);
/* 123 */       if (x > 5.0F) {
/* 124 */         za += exp(xa, ya);
/* 125 */         zb += exp(xb, yb);
/* 126 */         zc += exp(xc, yc);
/*     */       } 
/* 128 */       t[j++] = xa; t[j++] = ya; t[j++] = za;
/* 129 */       t[j++] = xb; t[j++] = yb; t[j++] = zb;
/* 130 */       t[j++] = xc; t[j++] = yc; t[j++] = zc;
/*     */     } 
/* 132 */     return t;
/*     */   }
/*     */   
/*     */   private static float[] makeColors(float[] xyz) {
/* 136 */     int nv = xyz.length / 3;
/* 137 */     float[] rgb = new float[3 * nv];
/* 138 */     for (int iv = 0, jv = 0, jc = 0; iv < nv; iv++) {
/* 139 */       float x = xyz[jv++];
/* 140 */       float y = xyz[jv++];
/* 141 */       float z = xyz[jv++];
/* 142 */       float s = 1.0F / (float)Math.sqrt((x * x + y * y + z * z));
/* 143 */       rgb[jc++] = x * s;
/* 144 */       rgb[jc++] = y * s;
/* 145 */       rgb[jc++] = z * s;
/*     */     } 
/* 147 */     return rgb;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/TriangleGroupTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */