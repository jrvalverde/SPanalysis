/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vector3
/*     */   extends Tuple3
/*     */ {
/*     */   public Vector3() {}
/*     */   
/*     */   public Vector3(double x, double y, double z) {
/*  29 */     super(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3(Vector3 v) {
/*  37 */     super(v.x, v.y, v.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double length() {
/*  45 */     return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double lengthSquared() {
/*  53 */     return this.x * this.x + this.y * this.y + this.z * this.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 negate() {
/*  61 */     return new Vector3(-this.x, -this.y, -this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 negateEquals() {
/*  69 */     this.x = -this.x;
/*  70 */     this.y = -this.y;
/*  71 */     this.z = -this.z;
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 normalize() {
/*  80 */     double d = length();
/*  81 */     double s = (d > 0.0D) ? (1.0D / d) : 1.0D;
/*  82 */     return new Vector3(this.x * s, this.y * s, this.z * s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 normalizeEquals() {
/*  90 */     double d = length();
/*  91 */     double s = (d > 0.0D) ? (1.0D / d) : 1.0D;
/*  92 */     this.x *= s;
/*  93 */     this.y *= s;
/*  94 */     this.z *= s;
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 plus(Vector3 v) {
/* 104 */     return new Vector3(this.x + v.x, this.y + v.y, this.z + v.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 plusEquals(Vector3 v) {
/* 113 */     this.x += v.x;
/* 114 */     this.y += v.y;
/* 115 */     this.z += v.z;
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 minus(Vector3 v) {
/* 125 */     return new Vector3(this.x - v.x, this.y - v.y, this.z - v.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 minusEquals(Vector3 v) {
/* 134 */     this.x -= v.x;
/* 135 */     this.y -= v.y;
/* 136 */     this.z -= v.z;
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 times(double s) {
/* 146 */     return new Vector3(this.x * s, this.y * s, this.z * s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 timesEquals(double s) {
/* 155 */     this.x *= s;
/* 156 */     this.y *= s;
/* 157 */     this.z *= s;
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double dot(Vector3 v) {
/* 167 */     return this.x * v.x + this.y * v.y + this.z * v.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 cross(Vector3 v) {
/* 176 */     return new Vector3(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Vector3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */