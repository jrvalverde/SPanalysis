/*      */ package edu.mines.jtk.lapack;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DMatrix
/*      */ {
/*      */   private int _m;
/*      */   private int _n;
/*      */   private double[] _a;
/*      */   
/*      */   public DMatrix(int m, int n) {
/*   51 */     this._m = m;
/*   52 */     this._n = n;
/*   53 */     this._a = new double[m * n];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix(int m, int n, double v) {
/*   63 */     this(m, n);
/*   64 */     Array.fill(v, this._a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix(int m, int n, double[] a) {
/*   80 */     Check.argument((m * n <= a.length), "m*n <= a.length");
/*   81 */     this._m = m;
/*   82 */     this._n = n;
/*   83 */     this._a = a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix(double[][] a) {
/*   97 */     Check.argument(Array.isRegular(a), "array a is regular");
/*   98 */     this._m = a.length;
/*   99 */     this._n = (a[0]).length;
/*  100 */     this._a = new double[this._m * this._n];
/*  101 */     set(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix(DMatrix a) {
/*  109 */     this(a._m, a._n, Array.copy(a._a));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getM() {
/*  117 */     return this._m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowCount() {
/*  125 */     return this._m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getN() {
/*  133 */     return this._n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumnCount() {
/*  141 */     return this._n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getArray() {
/*  149 */     return this._a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSquare() {
/*  157 */     return (this._m == this._n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSymmetric() {
/*  165 */     if (!isSquare())
/*  166 */       return false; 
/*  167 */     for (int i = 0; i < this._n; i++) {
/*  168 */       for (int j = i + 1; j < this._n; j++)
/*  169 */       { if (this._a[i + j * this._m] != this._a[j + i * this._m])
/*  170 */           return false;  } 
/*  171 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[][] get() {
/*  179 */     double[][] a = new double[this._m][this._n];
/*  180 */     get(a);
/*  181 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void get(double[][] a) {
/*  189 */     for (int i = 0; i < this._m; i++) {
/*  190 */       double[] ai = a[i];
/*  191 */       for (int j = 0; j < this._n; j++) {
/*  192 */         ai[j] = this._a[i + j * this._m];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double get(int i, int j) {
/*  204 */     return this._a[i + j * this._m];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int i0, int i1, int j0, int j1) {
/*  215 */     checkI(i0, i1);
/*  216 */     checkJ(j0, j1);
/*  217 */     int m = i1 - i0 + 1;
/*  218 */     int n = j1 - j0 + 1;
/*  219 */     double[] b = new double[m * n];
/*  220 */     for (int j = 0; j < n; j++) {
/*  221 */       for (int i = 0; i < m; i++)
/*  222 */         b[i + j * m] = this._a[i + i0 + (j + j0) * this._m]; 
/*  223 */     }  return new DMatrix(m, n, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int[] r, int[] c) {
/*  232 */     if (r == null && c == null) {
/*  233 */       return new DMatrix(this._m, this._n, Array.copy(this._a));
/*      */     }
/*  235 */     int m = (r != null) ? r.length : this._m;
/*  236 */     int n = (c != null) ? c.length : this._n;
/*  237 */     double[] b = new double[m * n];
/*  238 */     if (r == null)
/*  239 */     { for (int j = 0; j < n; j++)
/*  240 */       { for (int i = 0; i < m; i++)
/*  241 */           b[i + j * m] = this._a[i + c[j] * this._m];  }  }
/*  242 */     else if (c == null)
/*  243 */     { for (int j = 0; j < n; j++) {
/*  244 */         for (int i = 0; i < m; i++)
/*  245 */           b[i + j * m] = this._a[r[i] + j * this._m]; 
/*      */       }  }
/*  247 */     else { for (int j = 0; j < n; j++) {
/*  248 */         for (int i = 0; i < m; i++)
/*  249 */           b[i + j * m] = this._a[r[i] + c[j] * this._m]; 
/*      */       }  }
/*  251 */      return new DMatrix(m, n, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int i, int[] c) {
/*  261 */     return get(i, i, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int[] r, int j) {
/*  270 */     return get(r, j, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int i0, int i1, int[] c) {
/*  280 */     checkI(i0, i1);
/*  281 */     if (c == null) {
/*  282 */       return get(i0, i1, 0, this._n - 1);
/*      */     }
/*  284 */     int m = i1 - i0 + 1;
/*  285 */     int n = c.length;
/*  286 */     double[] b = new double[m * n];
/*  287 */     for (int j = 0; j < n; j++) {
/*  288 */       for (int i = i0; i <= i1; i++) {
/*  289 */         b[i - i0 + j * m] = this._a[i + c[j] * this._m];
/*      */       }
/*      */     } 
/*  292 */     return new DMatrix(m, n, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix get(int[] r, int j0, int j1) {
/*  303 */     checkJ(j0, j1);
/*  304 */     if (r == null) {
/*  305 */       return get(0, this._m - 1, j0, j1);
/*      */     }
/*  307 */     int m = r.length;
/*  308 */     int n = j1 - j0 + 1;
/*  309 */     double[] b = new double[m * n];
/*  310 */     for (int j = j0; j <= j1; j++) {
/*  311 */       for (int i = 0; i < m; i++) {
/*  312 */         b[i + (j - j0) * m] = this._a[r[i] + j * this._m];
/*      */       }
/*      */     } 
/*  315 */     return new DMatrix(m, n, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getPackedColumns() {
/*  324 */     return Array.copy(this._a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getPackedRows() {
/*  332 */     double[] r = new double[this._m * this._n];
/*  333 */     for (int j = 0; j < this._n; j++) {
/*  334 */       for (int i = 0; i < this._m; i++)
/*  335 */         r[i * this._n + j] = this._a[i + j * this._m]; 
/*  336 */     }  return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(double[][] a) {
/*  345 */     for (int i = 0; i < this._m; i++) {
/*  346 */       double[] ai = a[i];
/*  347 */       for (int j = 0; j < this._n; j++) {
/*  348 */         this._a[i + j * this._m] = ai[j];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int i, int j, double v) {
/*  360 */     this._a[i + j * this._m] = v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int i0, int i1, int j0, int j1, DMatrix x) {
/*  372 */     checkI(i0, i1);
/*  373 */     checkJ(j0, j1);
/*  374 */     int m = i1 - i0 + 1;
/*  375 */     int n = j1 - j0 + 1;
/*  376 */     Check.argument((m == x._m), "i1-i0+1 equals number of rows in x");
/*  377 */     Check.argument((n == x._n), "j1-j0+1 equals number of columns in x");
/*  378 */     double[] b = x._a;
/*  379 */     for (int i = 0; i < m; i++) {
/*  380 */       for (int j = 0; j < n; j++) {
/*  381 */         this._a[i + i0 + (j + j0) * this._m] = b[i + j * m];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int[] r, int[] c, DMatrix x) {
/*  391 */     if (r == null) {
/*  392 */       Check.argument((this._m == x._m), "number of rows equal in this and x");
/*      */     } else {
/*  394 */       Check.argument((r.length == x._m), "r.length equals number of rows in x");
/*      */     } 
/*  396 */     if (c == null) {
/*  397 */       Check.argument((this._n == x._n), "number of columns equal in this and x");
/*      */     } else {
/*  399 */       Check.argument((c.length == x._n), "c.length equals number of columns in x");
/*      */     } 
/*  401 */     if (r == null && c == null) {
/*  402 */       Array.copy(x._a, this._a);
/*      */     } else {
/*  404 */       int m = (r != null) ? r.length : this._m;
/*  405 */       int n = (c != null) ? c.length : this._n;
/*  406 */       double[] b = x._a;
/*  407 */       if (r == null)
/*  408 */       { for (int j = 0; j < n; j++)
/*  409 */         { for (int i = 0; i < m; i++)
/*  410 */             this._a[i + c[j] * this._m] = b[i + j * m];  }  }
/*  411 */       else if (c == null)
/*  412 */       { for (int j = 0; j < n; j++) {
/*  413 */           for (int i = 0; i < m; i++)
/*  414 */             this._a[r[i] + j * this._m] = b[i + j * m]; 
/*      */         }  }
/*  416 */       else { for (int j = 0; j < n; j++) {
/*  417 */           for (int i = 0; i < m; i++) {
/*  418 */             this._a[r[i] + c[j] * this._m] = b[i + j * m];
/*      */           }
/*      */         }  }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int i, int[] c, DMatrix x) {
/*  430 */     set(i, i, c, x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int[] r, int j, DMatrix x) {
/*  440 */     set(r, j, j, x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int i0, int i1, int[] c, DMatrix x) {
/*  451 */     checkI(i0, i1);
/*  452 */     Check.argument((i1 - i0 + 1 == x._m), "i1-i0+1 equals number of rows in x");
/*  453 */     if (c == null) {
/*  454 */       set(i0, i1, 0, this._n - 1, x);
/*      */     } else {
/*  456 */       int m = i1 - i0 + 1;
/*  457 */       int n = c.length;
/*  458 */       double[] b = x._a;
/*  459 */       for (int j = 0; j < n; j++) {
/*  460 */         for (int i = i0; i <= i1; i++) {
/*  461 */           this._a[i + c[j] * this._m] = b[i - i0 + j * m];
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void set(int[] r, int j0, int j1, DMatrix x) {
/*  475 */     checkJ(j0, j1);
/*  476 */     Check.argument((j1 - j0 + 1 == x._n), "j1-j0+1 equals number of columns in x");
/*  477 */     if (r == null) {
/*  478 */       set(0, this._m - 1, j0, j1, x);
/*      */     } else {
/*  480 */       int m = r.length;
/*  481 */       double[] b = x._a;
/*  482 */       for (int j = j0; j <= j1; j++) {
/*  483 */         for (int i = 0; i < m; i++) {
/*  484 */           this._a[r[i] + j * this._m] = b[i + (j - j0) * m];
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPackedColumns(double[] c) {
/*  495 */     Array.copy(this._m * this._n, c, this._a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPackedRows(double[] r) {
/*  503 */     for (int j = 0; j < this._n; j++) {
/*  504 */       for (int i = 0; i < this._m; i++) {
/*  505 */         this._a[i + j * this._m] = r[i * this._n + j];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix transpose() {
/*  513 */     DMatrix x = new DMatrix(this._n, this._m);
/*  514 */     double[] b = x._a;
/*  515 */     for (int j = 0; j < this._n; j++) {
/*  516 */       for (int i = 0; i < this._m; i++) {
/*  517 */         b[j + i * this._n] = this._a[i + j * this._m];
/*      */       }
/*      */     } 
/*  520 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double norm1() {
/*  528 */     double f = 0.0D;
/*  529 */     for (int j = 0; j < this._n; j++) {
/*  530 */       double s = 0.0D;
/*  531 */       for (int i = 0; i < this._m; i++)
/*  532 */         s += Math.abs(this._a[i + j * this._m]); 
/*  533 */       f = Math.max(f, s);
/*      */     } 
/*  535 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double norm2() {
/*  544 */     return (new DMatrixSvd(this)).norm2();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double normI() {
/*  552 */     double f = 0.0D;
/*  553 */     for (int i = 0; i < this._m; i++) {
/*  554 */       double s = 0.0D;
/*  555 */       for (int j = 0; j < this._n; j++)
/*  556 */         s += Math.abs(this._a[i + j * this._m]); 
/*  557 */       f = Math.max(f, s);
/*      */     } 
/*  559 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double normF() {
/*  567 */     double f = 0.0D;
/*  568 */     for (int j = 0; j < this._n; j++) {
/*  569 */       for (int i = 0; i < this._m; i++) {
/*  570 */         f = Math.hypot(f, this._a[i + j * this._m]);
/*      */       }
/*      */     } 
/*  573 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double det() {
/*  581 */     return (new DMatrixLud(this)).det();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double cond() {
/*  590 */     return (new DMatrixSvd(this)).cond();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double rank() {
/*  599 */     return (new DMatrixSvd(this)).rank();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double trace() {
/*  607 */     int mn = Math.min(this._m, this._n);
/*  608 */     double t = 0.0D;
/*  609 */     for (int i = 0; i < mn; i++)
/*  610 */       t += this._a[i + i * this._m]; 
/*  611 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrixLud lud() {
/*  619 */     return new DMatrixLud(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrixQrd qrd() {
/*  627 */     return new DMatrixQrd(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrixChd chd() {
/*  635 */     return new DMatrixChd(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrixEvd evd() {
/*  643 */     return new DMatrixEvd(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrixSvd svd() {
/*  651 */     return new DMatrixSvd(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix solve(DMatrix b) {
/*  661 */     Check.state((this._m >= this._n), "number of rows is not less than number of columns");
/*  662 */     if (this._m == this._n) {
/*  663 */       return (new DMatrixLud(this)).solve(b);
/*      */     }
/*  665 */     return (new DMatrixQrd(this)).solve(b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix inverse() {
/*  674 */     return solve(identity(this._m, this._m));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix negate() {
/*  682 */     DMatrix c = new DMatrix(this._m, this._n);
/*  683 */     Array.neg(this._a, c._a);
/*  684 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix plus(DMatrix b) {
/*  693 */     DMatrix c = new DMatrix(this._m, this._n);
/*  694 */     Array.add(this._a, b._a, c._a);
/*  695 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix plusEquals(DMatrix b) {
/*  704 */     Array.add(this._a, b._a, this._a);
/*  705 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix minus(DMatrix b) {
/*  714 */     DMatrix c = new DMatrix(this._m, this._n);
/*  715 */     Array.sub(this._a, b._a, c._a);
/*  716 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix minusEquals(DMatrix b) {
/*  725 */     Array.sub(this._a, b._a, this._a);
/*  726 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayTimes(DMatrix b) {
/*  736 */     DMatrix c = new DMatrix(this._m, this._n);
/*  737 */     Array.mul(this._a, b._a, c._a);
/*  738 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayTimesEquals(DMatrix b) {
/*  748 */     Array.mul(this._a, b._a, this._a);
/*  749 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayRightDivide(DMatrix b) {
/*  759 */     DMatrix c = new DMatrix(this._m, this._n);
/*  760 */     Array.div(this._a, b._a, c._a);
/*  761 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayRightDivideEquals(DMatrix b) {
/*  771 */     Array.div(this._a, b._a, this._a);
/*  772 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayLeftDivide(DMatrix b) {
/*  782 */     DMatrix c = new DMatrix(this._m, this._n);
/*  783 */     Array.div(b._a, this._a, c._a);
/*  784 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix arrayLeftDivideEquals(DMatrix b) {
/*  794 */     Array.div(b._a, this._a, this._a);
/*  795 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix times(double s) {
/*  804 */     DMatrix c = new DMatrix(this._m, this._n);
/*  805 */     Array.mul(this._a, s, c._a);
/*  806 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix timesEquals(double s) {
/*  815 */     Array.mul(this._a, s, this._a);
/*  816 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix times(DMatrix b) {
/*  826 */     Check.argument((this._n == b._m), "number of columns in A equals number of rows in B");
/*      */     
/*  828 */     DMatrix c = new DMatrix(this._m, b._n);
/*  829 */     Blas.dgemm(102, 111, 111, this._m, b._n, this._n, 1.0D, this._a, this._m, b._a, b._m, 1.0D, c._a, c._m);
/*      */     
/*  831 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix timesTranspose(DMatrix b) {
/*  842 */     Check.argument((this._n == b._n), "number of columns in A equals number of columns in B");
/*      */     
/*  844 */     DMatrix c = new DMatrix(this._m, b._m);
/*  845 */     Blas.dgemm(102, 111, 112, this._m, b._m, this._n, 1.0D, this._a, this._m, b._a, b._m, 1.0D, c._a, c._m);
/*      */     
/*  847 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DMatrix transposeTimes(DMatrix b) {
/*  858 */     Check.argument((this._m == b._m), "number of rows in A equals number of rows in B");
/*      */     
/*  860 */     DMatrix c = new DMatrix(this._n, b._n);
/*  861 */     Blas.dgemm(102, 112, 111, this._n, b._n, this._m, 1.0D, this._a, this._m, b._a, b._m, 1.0D, c._a, c._m);
/*      */     
/*  863 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DMatrix random(int m, int n) {
/*  874 */     DMatrix x = new DMatrix(m, n);
/*  875 */     Array.rand(x._a);
/*  876 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DMatrix random(int n) {
/*  886 */     return random(n, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DMatrix identity(int m, int n) {
/*  896 */     DMatrix x = new DMatrix(m, n);
/*  897 */     double[] xa = x._a;
/*  898 */     int mn = Math.min(m, n);
/*  899 */     for (int i = 0; i < mn; i++)
/*  900 */       xa[i + i * m] = 1.0D; 
/*  901 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DMatrix identity(int n) {
/*  910 */     return identity(n, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DMatrix diagonal(double[] d) {
/*  918 */     int n = d.length;
/*  919 */     double[] a = new double[n * n];
/*  920 */     for (int i = 0; i < n; i++)
/*  921 */       a[i + i * n] = d[i]; 
/*  922 */     return new DMatrix(n, n, a);
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj) {
/*  926 */     if (this == obj)
/*  927 */       return true; 
/*  928 */     if (obj == null || getClass() != obj.getClass())
/*  929 */       return false; 
/*  930 */     DMatrix that = (DMatrix)obj;
/*  931 */     if (this._m != that._m || this._n != that._n)
/*  932 */       return false; 
/*  933 */     double[] a = this._a;
/*  934 */     double[] b = that._a;
/*  935 */     int mn = this._m * this._n;
/*  936 */     for (int i = 0; i < mn; i++) {
/*  937 */       if (a[i] != b[i])
/*  938 */         return false; 
/*      */     } 
/*  940 */     return true;
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  944 */     int h = this._m ^ this._n;
/*  945 */     int mn = this._m * this._n;
/*  946 */     for (int i = 0; i < mn; i++) {
/*  947 */       long bits = Double.doubleToLongBits(this._a[i]);
/*  948 */       h ^= (int)(bits ^ bits >>> 32L);
/*      */     } 
/*  950 */     return h;
/*      */   }
/*      */   
/*      */   public String toString() {
/*  954 */     String ls = System.getProperty("line.separator");
/*  955 */     StringBuffer sb = new StringBuffer();
/*  956 */     String[][] s = format(this._m, this._n, this._a);
/*  957 */     int max = maxlen(s);
/*  958 */     String format = "%" + max + "s";
/*  959 */     sb.append("[[");
/*  960 */     int ncol = 77 / (max + 2);
/*  961 */     if (ncol >= 5)
/*  962 */       ncol = ncol / 5 * 5; 
/*  963 */     for (int i = 0; i < this._m; i++) {
/*  964 */       int nrow = 1 + (this._n - 1) / ncol;
/*  965 */       if (i > 0)
/*  966 */         sb.append(" ["); 
/*  967 */       for (int irow = 0, j = 0; irow < nrow; irow++) {
/*  968 */         for (int icol = 0; icol < ncol && j < this._n; icol++, j++) {
/*  969 */           sb.append(String.format(format, new Object[] { s[i][j] }));
/*  970 */           if (j < this._n - 1)
/*  971 */             sb.append(", "); 
/*      */         } 
/*  973 */         if (j < this._n) {
/*  974 */           sb.append(ls);
/*  975 */           sb.append("  ");
/*      */         }
/*  977 */         else if (i < this._m - 1) {
/*  978 */           sb.append("],");
/*  979 */           sb.append(ls);
/*      */         } else {
/*  981 */           sb.append("]]");
/*  982 */           sb.append(ls);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  987 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkI(int i) {
/* 1001 */     if (i < 0 || i >= this._m)
/* 1002 */       Check.argument((0 <= i && i < this._m), "row index i=" + i + " is in bounds"); 
/*      */   }
/*      */   
/*      */   private void checkJ(int j) {
/* 1006 */     if (j < 0 || j >= this._n)
/* 1007 */       Check.argument((0 <= j && j < this._n), "column index j=" + j + " is in bounds"); 
/*      */   }
/*      */   
/*      */   private void checkI(int i0, int i1) {
/* 1011 */     checkI(i0); checkI(i1); Check.argument((i0 <= i1), "i0<=i1");
/*      */   }
/*      */   
/*      */   private void checkJ(int j0, int j1) {
/* 1015 */     checkJ(j0); checkJ(j1); Check.argument((j0 <= j1), "j0<=j1");
/*      */   }
/*      */   
/*      */   private static String[][] format(int m, int n, double[] d) {
/*      */     String f;
/* 1020 */     int pg = 6;
/* 1021 */     String fg = "% ." + pg + "g";
/* 1022 */     int pemax = -1;
/* 1023 */     int pfmax = -1;
/* 1024 */     for (int i = 0; i < m; i++) {
/* 1025 */       for (int k = 0; k < n; k++) {
/* 1026 */         String str = String.format(fg, new Object[] { Double.valueOf(d[i + k * m]) });
/* 1027 */         str = clean(str);
/* 1028 */         int ls = str.length();
/* 1029 */         if (str.contains("e")) {
/* 1030 */           int pe = (ls > 7) ? (ls - 7) : 0;
/* 1031 */           if (pemax < pe)
/* 1032 */             pemax = pe; 
/*      */         } else {
/* 1034 */           int ip = str.indexOf('.');
/* 1035 */           int pf = (ip >= 0) ? (ls - 1 - ip) : 0;
/* 1036 */           if (pfmax < pf)
/* 1037 */             pfmax = pf; 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1041 */     String[][] s = new String[m][n];
/*      */     
/* 1043 */     if (pemax >= 0) {
/* 1044 */       if (pfmax > pg - 1)
/* 1045 */         pfmax = pg - 1; 
/* 1046 */       int pe = (pemax > pfmax) ? pemax : pfmax;
/* 1047 */       f = "% ." + pe + "e";
/*      */     } else {
/* 1049 */       int pf = pfmax;
/* 1050 */       f = "% ." + pf + "f";
/*      */     } 
/* 1052 */     for (int j = 0; j < m; j++) {
/* 1053 */       for (int k = 0; k < n; k++) {
/* 1054 */         s[j][k] = String.format(f, new Object[] { Double.valueOf(d[j + k * m]) });
/*      */       } 
/*      */     } 
/* 1057 */     return s;
/*      */   }
/*      */   private static String clean(String s) {
/* 1060 */     int len = s.length();
/* 1061 */     int iend = s.indexOf('e');
/* 1062 */     if (iend < 0)
/* 1063 */       iend = s.indexOf('E'); 
/* 1064 */     if (iend < 0)
/* 1065 */       iend = len; 
/* 1066 */     int ibeg = iend;
/* 1067 */     if (s.indexOf('.') > 0) {
/* 1068 */       while (ibeg > 0 && s.charAt(ibeg - 1) == '0')
/* 1069 */         ibeg--; 
/* 1070 */       if (ibeg > 0 && s.charAt(ibeg - 1) == '.')
/* 1071 */         ibeg--; 
/*      */     } 
/* 1073 */     if (ibeg < iend) {
/* 1074 */       String sb = s.substring(0, ibeg);
/* 1075 */       s = (iend < len) ? (sb + s.substring(iend, len)) : sb;
/*      */     } 
/* 1077 */     return s;
/*      */   }
/*      */   private static int maxlen(String[][] s) {
/* 1080 */     int max = 0;
/* 1081 */     int m = s.length;
/* 1082 */     int n = (s[0]).length;
/* 1083 */     for (int i = 0; i < m; i++) {
/* 1084 */       for (int j = 0; j < n; j++) {
/* 1085 */         int len = s[i][j].length();
/* 1086 */         if (max < len)
/* 1087 */           max = len; 
/*      */       } 
/*      */     } 
/* 1090 */     return max;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */