/*     */ package edu.mines.jtk.bench;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AwtBench
/*     */ {
/*     */   public static void main(String[] args) {
/*  29 */     testImage();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void testImage() {
/*  34 */     Dimension panelSize = new Dimension(600, 600);
/*  35 */     ImagePanel panel = new ImagePanel();
/*  36 */     panel.setSize(panelSize);
/*  37 */     panel.setPreferredSize(panelSize);
/*  38 */     panel.setBackground(Color.WHITE);
/*  39 */     BufferedImage image = panel.paintToImage(300.0D, 3.0D);
/*  40 */     writeToPng(image, "ImageAWT.png");
/*  41 */     JFrame frame = new JFrame();
/*  42 */     frame.setDefaultCloseOperation(3);
/*  43 */     frame.add(panel);
/*  44 */     frame.pack();
/*  45 */     frame.setVisible(true);
/*     */   }
/*     */   private static class ImagePanel extends JPanel { private static final long serialVersionUID = 1L;
/*     */     
/*     */     public void paintComponent(Graphics g) {
/*  50 */       super.paintComponent(g);
/*  51 */       Graphics2D g2d = (Graphics2D)g;
/*  52 */       int width = getWidth();
/*  53 */       int height = getHeight();
/*  54 */       g2d.setColor(Color.RED); int i;
/*  55 */       for (i = 0; i < 3; i++)
/*  56 */         g2d.drawLine(0, 0, i * (width - 1) / 2, height - 1); 
/*  57 */       for (i = 0; i < 2; i++)
/*  58 */         g2d.drawLine(0, 0, width - 1, i * (height - 1) / 2); 
/*  59 */       g2d.setColor(Color.BLACK);
/*  60 */       Font font = new Font("SansSerif", 0, 18);
/*  61 */       g2d.setFont(font);
/*  62 */       FontMetrics fm = g2d.getFontMetrics();
/*  63 */       int fontAscent = fm.getAscent();
/*  64 */       int fontHeight = fm.getHeight();
/*  65 */       int x = width / 2;
/*  66 */       int y = height / 2;
/*  67 */       g2d.drawLine(x, 0, x, y);
/*  68 */       y += fontAscent;
/*  69 */       int sw = fm.stringWidth("Goodbye");
/*  70 */       g2d.drawString("Goodbye", x - sw / 2, y);
/*  71 */       y += fontHeight;
/*  72 */       sw = fm.stringWidth("Hello");
/*  73 */       g2d.drawString("Hello", x - sw / 2, y);
/*  74 */       y += fontHeight;
/*  75 */       String message = "abcdefghijklmnopqrstuvwxyz0123456789";
/*  76 */       sw = fm.stringWidth(message);
/*  77 */       g2d.drawString(message, x - sw / 2, y);
/*     */     } private ImagePanel() {}
/*     */     public BufferedImage paintToImage(double dpi, double winches) {
/*  80 */       int wpixels = getWidth();
/*  81 */       int hpixels = getHeight();
/*  82 */       double scale = dpi * winches / wpixels;
/*  83 */       int wimage = (int)(scale * (wpixels - 1) + 1.5D);
/*  84 */       int himage = (int)(scale * (hpixels - 1) + 1.5D);
/*  85 */       int type = 1;
/*  86 */       BufferedImage bi = new BufferedImage(wimage, himage, type);
/*  87 */       Graphics2D g2d = (Graphics2D)bi.getGraphics();
/*  88 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */       
/*  91 */       Color fg = getForeground();
/*  92 */       g2d.setColor(getBackground());
/*  93 */       g2d.fillRect(0, 0, wimage, himage);
/*  94 */       g2d.setColor(fg);
/*  95 */       g2d.scale(scale, scale);
/*  96 */       paintComponent(g2d);
/*  97 */       g2d.dispose();
/*  98 */       return bi;
/*     */     } }
/*     */   
/*     */   private static void writeToPng(BufferedImage image, String fileName) {
/*     */     try {
/* 103 */       File file = new File(fileName);
/* 104 */       ImageIO.write(image, "png", file);
/* 105 */     } catch (IOException ioe) {
/* 106 */       throw new RuntimeException(ioe);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/AwtBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */