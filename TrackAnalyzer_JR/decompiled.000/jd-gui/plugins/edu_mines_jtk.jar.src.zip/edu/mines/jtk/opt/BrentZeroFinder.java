/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrentZeroFinder
/*     */ {
/*     */   private Function _f;
/*     */   private static final double EPS = 2.220446049250313E-16D;
/*     */   
/*     */   public BrentZeroFinder(Function f) {
/*  59 */     this._f = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double f(double x) {
/*  68 */     return this._f.evaluate(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double findZero(double a, double b, double tol) {
/*  80 */     double fa = this._f.evaluate(a);
/*  81 */     double fb = this._f.evaluate(b);
/*  82 */     return findZero(a, fa, b, fb, tol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double findZero(double a, double fa, double b, double fb, double tol) {
/*  99 */     Check.argument((a < b), "Invalid Search Interval");
/* 100 */     Check.argument(((fa <= 0.0D && fb >= 0.0D) || (fa >= 0.0D && fb <= 0.0D)), "Function values must not have same sign");
/*     */     
/* 102 */     Check.argument((tol > 0.0D), "Accuracy must be greater than zero");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     double c = a;
/* 110 */     double fc = fa;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 116 */       double e = b - a;
/*     */ 
/*     */       
/* 119 */       if (MathPlus.abs(fc) < MathPlus.abs(fb)) {
/* 120 */         a = b; fa = fb;
/* 121 */         b = c; fb = fc;
/* 122 */         c = a; fc = fa;
/*     */       } 
/*     */ 
/*     */       
/* 126 */       double d = 0.5D * (c - b);
/*     */ 
/*     */       
/* 129 */       double dtol = 4.440892098500626E-16D * MathPlus.abs(b) + 0.5D * tol;
/* 130 */       if (MathPlus.abs(d) <= dtol || fb == 0.0D) {
/* 131 */         return b;
/*     */       }
/*     */       
/* 134 */       if (MathPlus.abs(e) >= dtol && MathPlus.abs(fa) > MathPlus.abs(fb)) {
/*     */         double p;
/*     */ 
/*     */         
/*     */         double q;
/*     */ 
/*     */         
/* 141 */         if (a == c) {
/* 142 */           double s = fb / fa;
/* 143 */           p = 2.0D * d * s;
/* 144 */           q = 1.0D - s;
/*     */         } else {
/* 146 */           double r = fb / fc;
/* 147 */           double s = fb / fa;
/* 148 */           q = fa / fc;
/* 149 */           p = s * (2.0D * d * q * (q - r) - (b - a) * (r - 1.0D));
/* 150 */           q = (q - 1.0D) * (r - 1.0D) * (s - 1.0D);
/*     */         } 
/* 152 */         if (p > 0.0D) {
/* 153 */           q = -q;
/*     */         } else {
/* 155 */           p = -p;
/*     */         } 
/*     */ 
/*     */         
/* 159 */         if (2.0D * p < 3.0D * d * q - MathPlus.abs(dtol * q) && p < MathPlus.abs(0.5D * e * q)) {
/* 160 */           d = p / q;
/*     */         }
/*     */       } 
/*     */       
/* 164 */       if (MathPlus.abs(d) < dtol) {
/* 165 */         d = (d > 0.0D) ? dtol : -dtol;
/*     */       }
/*     */       
/* 168 */       a = b; fa = fb;
/* 169 */       b += d; fb = this._f.evaluate(b);
/*     */ 
/*     */       
/* 172 */       if ((fb > 0.0D && fc > 0.0D) || (fb < 0.0D && fc < 0.0D)) {
/* 173 */         c = a; fc = fa;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface Function {
/*     */     double evaluate(double param1Double);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/BrentZeroFinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */