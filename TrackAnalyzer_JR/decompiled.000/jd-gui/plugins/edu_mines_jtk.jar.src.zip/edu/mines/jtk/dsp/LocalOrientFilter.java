/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalOrientFilter
/*     */ {
/*     */   private double _sigma;
/*     */   private RecursiveGaussianFilter _rgfGradient;
/*     */   private RecursiveGaussianFilter _rgfSmoother;
/*     */   
/*     */   public LocalOrientFilter(double sigma) {
/*  60 */     this._sigma = sigma;
/*  61 */     this._rgfGradient = new RecursiveGaussianFilter(1.0D);
/*  62 */     this._rgfSmoother = new RecursiveGaussianFilter(sigma);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForTheta(float[][] x, float[][] theta) {
/*  71 */     apply(x, theta, (float[][])null, (float[][])null, (float[][])null, (float[][])null, (float[][])null, (float[][])null, (float[][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForNormal(float[][] x, float[][] u1, float[][] u2) {
/*  86 */     apply(x, (float[][])null, u1, u2, (float[][])null, (float[][])null, (float[][])null, (float[][])null, (float[][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForNormalLinear(float[][] x, float[][] u1, float[][] u2, float[][] el) {
/* 104 */     apply(x, (float[][])null, u1, u2, (float[][])null, (float[][])null, (float[][])null, (float[][])null, el);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(float[][] x, float[][] theta, float[][] u1, float[][] u2, float[][] v1, float[][] v2, float[][] eu, float[][] ev, float[][] el) {
/* 133 */     float[][][] t = new float[8][][];
/* 134 */     int nt = 0;
/* 135 */     if (theta != null) t[nt++] = theta; 
/* 136 */     if (u1 != null) t[nt++] = u1; 
/* 137 */     if (u2 != null) t[nt++] = u2; 
/* 138 */     if (v1 != null) t[nt++] = v1; 
/* 139 */     if (v2 != null) t[nt++] = v2; 
/* 140 */     if (eu != null) t[nt++] = eu; 
/* 141 */     if (ev != null) t[nt++] = ev; 
/* 142 */     if (el != null) t[nt++] = el;
/*     */ 
/*     */     
/* 145 */     int n1 = (x[0]).length;
/* 146 */     int n2 = x.length;
/* 147 */     float[][] g1 = (nt > 0) ? t[0] : new float[n2][n1];
/* 148 */     float[][] g2 = (nt > 1) ? t[1] : new float[n2][n1];
/* 149 */     this._rgfGradient.apply1X(x, g1);
/* 150 */     this._rgfGradient.applyX1(x, g2);
/*     */ 
/*     */     
/* 153 */     float[][] g11 = g1;
/* 154 */     float[][] g22 = g2;
/* 155 */     float[][] g12 = (nt > 2) ? t[2] : new float[n2][n1];
/* 156 */     for (int i2 = 0; i2 < n2; i2++) {
/* 157 */       for (int i1 = 0; i1 < n1; i1++) {
/* 158 */         float g1i = g1[i2][i1];
/* 159 */         float g2i = g2[i2][i1];
/* 160 */         g11[i2][i1] = g1i * g1i;
/* 161 */         g22[i2][i1] = g2i * g2i;
/* 162 */         g12[i2][i1] = g1i * g2i;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 167 */     float[][] h = (nt > 3) ? t[3] : new float[n2][n1];
/* 168 */     float[][][] gs = { g11, g22, g12 };
/* 169 */     for (float[][] g : gs) {
/* 170 */       this._rgfSmoother.apply0X(g, h);
/* 171 */       this._rgfSmoother.applyX0(h, g);
/*     */     } 
/*     */ 
/*     */     
/* 175 */     float[][] a = new float[2][2];
/* 176 */     float[][] z = new float[2][2];
/* 177 */     float[] e = new float[2];
/* 178 */     for (int i = 0; i < n2; i++) {
/* 179 */       for (int i1 = 0; i1 < n1; i1++) {
/* 180 */         a[0][0] = g11[i][i1];
/* 181 */         a[0][1] = g12[i][i1];
/* 182 */         a[1][0] = g12[i][i1];
/* 183 */         a[1][1] = g22[i][i1];
/* 184 */         Eigen.solveSymmetric22(a, z, e);
/* 185 */         float u1i = z[0][0];
/* 186 */         float u2i = z[0][1];
/* 187 */         if (u1i < 0.0F) {
/* 188 */           u1i = -u1i;
/* 189 */           u2i = -u2i;
/*     */         } 
/* 191 */         float v1i = -u2i;
/* 192 */         float v2i = u1i;
/* 193 */         float eui = e[0];
/* 194 */         float evi = e[1];
/* 195 */         if (theta != null) theta[i][i1] = MathPlus.asin(u2i); 
/* 196 */         if (u1 != null) u1[i][i1] = u1i; 
/* 197 */         if (u2 != null) u2[i][i1] = u2i; 
/* 198 */         if (v1 != null) v1[i][i1] = v1i; 
/* 199 */         if (v2 != null) v2[i][i1] = v2i; 
/* 200 */         if (eu != null) eu[i][i1] = eui; 
/* 201 */         if (ev != null) ev[i][i1] = evi; 
/* 202 */         if (el != null) el[i][i1] = (eui - evi) / (eui + evi);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForThetaPhi(float[][][] x, float[][][] theta, float[][][] phi) {
/* 216 */     apply(x, theta, phi, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForNormal(float[][][] x, float[][][] u1, float[][][] u2, float[][][] u3) {
/* 235 */     apply(x, (float[][][])null, (float[][][])null, u1, u2, u3, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForNormalPlanar(float[][][] x, float[][][] u1, float[][][] u2, float[][][] u3, float[][][] ep) {
/* 256 */     apply(x, (float[][][])null, (float[][][])null, u1, u2, u3, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, ep, (float[][][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForInline(float[][][] x, float[][][] w1, float[][][] w2, float[][][] w3) {
/* 275 */     apply(x, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, w1, w2, w3, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForInlineLinear(float[][][] x, float[][][] w1, float[][][] w2, float[][][] w3, float[][][] el) {
/* 297 */     apply(x, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, w1, w2, w3, (float[][][])null, (float[][][])null, (float[][][])null, (float[][][])null, el);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(float[][][] x, float[][][] theta, float[][][] phi, float[][][] u1, float[][][] u2, float[][][] u3, float[][][] v1, float[][][] v2, float[][][] v3, float[][][] w1, float[][][] w2, float[][][] w3, float[][][] eu, float[][][] ev, float[][][] ew, float[][][] ep, float[][][] el) {
/* 336 */     float[][][][] t = new float[16][][][];
/* 337 */     int nt = 0;
/* 338 */     if (theta != null) t[nt++] = theta; 
/* 339 */     if (phi != null) t[nt++] = phi; 
/* 340 */     if (u1 != null) t[nt++] = u1; 
/* 341 */     if (u2 != null) t[nt++] = u2; 
/* 342 */     if (u3 != null) t[nt++] = u3; 
/* 343 */     if (v1 != null) t[nt++] = v1; 
/* 344 */     if (v2 != null) t[nt++] = v2; 
/* 345 */     if (v3 != null) t[nt++] = v3; 
/* 346 */     if (w1 != null) t[nt++] = w1; 
/* 347 */     if (w2 != null) t[nt++] = w2; 
/* 348 */     if (w3 != null) t[nt++] = w3; 
/* 349 */     if (eu != null) t[nt++] = eu; 
/* 350 */     if (ev != null) t[nt++] = ev; 
/* 351 */     if (ew != null) t[nt++] = ew; 
/* 352 */     if (ep != null) t[nt++] = ep; 
/* 353 */     if (el != null) t[nt++] = el;
/*     */ 
/*     */     
/* 356 */     int n1 = (x[0][0]).length;
/* 357 */     int n2 = (x[0]).length;
/* 358 */     int n3 = x.length;
/* 359 */     float[][][] g1 = (nt > 0) ? t[0] : new float[n3][n2][n1];
/* 360 */     float[][][] g2 = (nt > 1) ? t[1] : new float[n3][n2][n1];
/* 361 */     float[][][] g3 = (nt > 2) ? t[2] : new float[n3][n2][n1];
/* 362 */     this._rgfGradient.apply1XX(x, g1);
/* 363 */     this._rgfGradient.applyX1X(x, g2);
/* 364 */     this._rgfGradient.applyXX1(x, g3);
/*     */ 
/*     */     
/* 367 */     float[][][] g11 = g1;
/* 368 */     float[][][] g22 = g2;
/* 369 */     float[][][] g33 = g3;
/* 370 */     float[][][] g12 = (nt > 3) ? t[3] : new float[n3][n2][n1];
/* 371 */     float[][][] g13 = (nt > 4) ? t[4] : new float[n3][n2][n1];
/* 372 */     float[][][] g23 = (nt > 5) ? t[5] : new float[n3][n2][n1];
/* 373 */     for (int i3 = 0; i3 < n3; i3++) {
/* 374 */       for (int i2 = 0; i2 < n2; i2++) {
/* 375 */         for (int i1 = 0; i1 < n1; i1++) {
/* 376 */           float g1i = g1[i3][i2][i1];
/* 377 */           float g2i = g2[i3][i2][i1];
/* 378 */           float g3i = g3[i3][i2][i1];
/* 379 */           g11[i3][i2][i1] = g1i * g1i;
/* 380 */           g22[i3][i2][i1] = g2i * g2i;
/* 381 */           g33[i3][i2][i1] = g3i * g3i;
/* 382 */           g12[i3][i2][i1] = g1i * g2i;
/* 383 */           g13[i3][i2][i1] = g1i * g3i;
/* 384 */           g23[i3][i2][i1] = g2i * g3i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 390 */     float[][][] h = (nt > 6) ? t[6] : new float[n3][n2][n1];
/* 391 */     float[][][][] gs = { g11, g22, g33, g12, g13, g23 };
/* 392 */     for (float[][][] g : gs) {
/* 393 */       this._rgfSmoother.apply0XX(g, h);
/* 394 */       this._rgfSmoother.applyX0X(h, g);
/* 395 */       this._rgfSmoother.applyXX0(g, h);
/* 396 */       Array.copy(h, g);
/*     */     } 
/*     */ 
/*     */     
/* 400 */     float[][] a = new float[3][3];
/* 401 */     float[][] z = new float[3][3];
/* 402 */     float[] e = new float[3];
/* 403 */     for (int i = 0; i < n3; i++) {
/* 404 */       for (int i2 = 0; i2 < n2; i2++) {
/* 405 */         for (int i1 = 0; i1 < n1; i1++) {
/* 406 */           a[0][0] = g11[i][i2][i1];
/* 407 */           a[0][1] = g12[i][i2][i1];
/* 408 */           a[0][2] = g13[i][i2][i1];
/* 409 */           a[1][0] = g12[i][i2][i1];
/* 410 */           a[1][1] = g22[i][i2][i1];
/* 411 */           a[1][2] = g23[i][i2][i1];
/* 412 */           a[2][0] = g13[i][i2][i1];
/* 413 */           a[2][1] = g23[i][i2][i1];
/* 414 */           a[2][2] = g33[i][i2][i1];
/* 415 */           Eigen.solveSymmetric33(a, z, e);
/* 416 */           float u1i = z[0][0];
/* 417 */           float u2i = z[0][1];
/* 418 */           float u3i = z[0][2];
/* 419 */           float v1i = z[1][0];
/* 420 */           float v2i = z[1][1];
/* 421 */           float v3i = z[1][2];
/* 422 */           if (u1i < 0.0F) {
/* 423 */             u1i = -u1i;
/* 424 */             u2i = -u2i;
/* 425 */             u3i = -u3i;
/*     */           } 
/* 427 */           if (v2i < 0.0F) {
/* 428 */             v1i = -v1i;
/* 429 */             v2i = -v2i;
/* 430 */             v3i = -v3i;
/*     */           } 
/* 432 */           float w1i = u2i * v3i - u3i * v2i;
/* 433 */           float w2i = u3i * v1i - u1i * v3i;
/* 434 */           float w3i = u1i * v2i - u2i * v1i;
/* 435 */           float eui = e[0];
/* 436 */           float evi = e[1];
/* 437 */           float ewi = e[2];
/* 438 */           if (theta != null) theta[i][i2][i1] = MathPlus.acos(u1i); 
/* 439 */           if (phi != null) phi[i][i2][i1] = MathPlus.atan2(u3i, u2i); 
/* 440 */           if (u1 != null) u1[i][i2][i1] = u1i; 
/* 441 */           if (u2 != null) u2[i][i2][i1] = u2i; 
/* 442 */           if (u3 != null) u3[i][i2][i1] = u3i; 
/* 443 */           if (v1 != null) v1[i][i2][i1] = v1i; 
/* 444 */           if (v2 != null) v2[i][i2][i1] = v2i; 
/* 445 */           if (v3 != null) v3[i][i2][i1] = v3i; 
/* 446 */           if (w1 != null) w1[i][i2][i1] = w1i; 
/* 447 */           if (w2 != null) w2[i][i2][i1] = w2i; 
/* 448 */           if (w3 != null) w3[i][i2][i1] = w3i; 
/* 449 */           if (eu != null) eu[i][i2][i1] = eui; 
/* 450 */           if (ev != null) ev[i][i2][i1] = evi; 
/* 451 */           if (ew != null) ew[i][i2][i1] = ewi; 
/* 452 */           if (ep != null || el != null) {
/* 453 */             float esi = 1.0F / (eui + ewi);
/* 454 */             if (ep != null) ep[i][i2][i1] = (eui - evi) * esi; 
/* 455 */             if (el != null) el[i][i2][i1] = (evi - ewi) * esi; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/LocalOrientFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */