/*     */ package edu.mines.jtk.io.test;
/*     */ 
/*     */ import edu.mines.jtk.io.ArrayFile;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteOrder;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayFileTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  28 */     TestSuite suite = new TestSuite(ArrayFileTest.class);
/*  29 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testBigEndian() throws IOException {
/*  33 */     test(ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */   
/*     */   public void testLittleEndian() throws IOException {
/*  37 */     test(ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void test(ByteOrder order) throws IOException {
/*  44 */     int n = 10000;
/*  45 */     File file = null;
/*  46 */     ArrayFile af = null;
/*     */     try {
/*  48 */       file = File.createTempFile("junk", "dat");
/*  49 */       af = new ArrayFile(file, "rw", order, order);
/*  50 */       testFloat(af, n);
/*  51 */       testDouble(af, n);
/*     */     } finally {
/*  53 */       if (af != null)
/*  54 */         af.close(); 
/*  55 */       if (file != null) {
/*  56 */         file.delete();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void testFloat(ArrayFile af, int n) throws IOException {
/*  63 */     float[] a = Array.randfloat(n);
/*  64 */     float[] b = Array.zerofloat(n);
/*     */     
/*  66 */     af.seek(0L);
/*  67 */     af.writeFloats(a);
/*  68 */     af.seek(0L);
/*  69 */     af.readFloats(b); int i;
/*  70 */     for (i = 0; i < n; i++) {
/*  71 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  73 */     Array.zero(b);
/*  74 */     af.seek(0L);
/*  75 */     for (i = 0; i < n; i++)
/*  76 */       af.writeFloat(a[i]); 
/*  77 */     af.seek(0L);
/*  78 */     for (i = 0; i < n; i++)
/*  79 */       b[i] = af.readFloat(); 
/*  80 */     for (i = 0; i < n; i++) {
/*  81 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  83 */     af.seek(0L);
/*  84 */     for (i = 0; i < n; i++) {
/*  85 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(af.readFloat()));
/*     */     }
/*  87 */     af.seek(0L);
/*  88 */     for (i = 0; i < n; i++)
/*  89 */       af.writeFloat(a[i]); 
/*  90 */     Array.zero(b);
/*  91 */     af.seek(0L);
/*  92 */     af.readFloats(b);
/*  93 */     for (i = 0; i < n; i++) {
/*  94 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  96 */     int mw = 3141;
/*  97 */     af.seek(0L); int j;
/*  98 */     for (j = 0; j < n; j += mw)
/*  99 */       af.writeFloats(a, j, Math.min(n - j, mw)); 
/* 100 */     Array.zero(b);
/* 101 */     af.seek(0L);
/* 102 */     int mr = 2739; int m;
/* 103 */     for (m = 0; m < n; m += mr)
/* 104 */       af.readFloats(b, m, Math.min(n - m, mr)); 
/* 105 */     for (int k = 0; k < n; k++) {
/* 106 */       assertEquals(Float.valueOf(a[k]), Float.valueOf(b[k]));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void testDouble(ArrayFile af, int n) throws IOException {
/* 112 */     double[] a = Array.randdouble(n);
/* 113 */     double[] b = Array.zerodouble(n);
/*     */     
/* 115 */     af.seek(0L);
/* 116 */     af.writeDoubles(a);
/* 117 */     af.seek(0L);
/* 118 */     af.readDoubles(b); int i;
/* 119 */     for (i = 0; i < n; i++) {
/* 120 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 122 */     Array.zero(b);
/* 123 */     af.seek(0L);
/* 124 */     for (i = 0; i < n; i++)
/* 125 */       af.writeDouble(a[i]); 
/* 126 */     af.seek(0L);
/* 127 */     for (i = 0; i < n; i++)
/* 128 */       b[i] = af.readDouble(); 
/* 129 */     for (i = 0; i < n; i++) {
/* 130 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 132 */     af.seek(0L);
/* 133 */     for (i = 0; i < n; i++) {
/* 134 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(af.readDouble()));
/*     */     }
/* 136 */     af.seek(0L);
/* 137 */     for (i = 0; i < n; i++)
/* 138 */       af.writeDouble(a[i]); 
/* 139 */     Array.zero(b);
/* 140 */     af.seek(0L);
/* 141 */     af.readDoubles(b);
/* 142 */     for (i = 0; i < n; i++) {
/* 143 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 145 */     int mw = 3141;
/* 146 */     af.seek(0L); int j;
/* 147 */     for (j = 0; j < n; j += mw)
/* 148 */       af.writeDoubles(a, j, Math.min(n - j, mw)); 
/* 149 */     Array.zero(b);
/* 150 */     af.seek(0L);
/* 151 */     int mr = 2739; int m;
/* 152 */     for (m = 0; m < n; m += mr)
/* 153 */       af.readDoubles(b, m, Math.min(n - m, mr)); 
/* 154 */     for (int k = 0; k < n; k++)
/* 155 */       assertEquals(Double.valueOf(a[k]), Double.valueOf(b[k])); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/test/ArrayFileTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */