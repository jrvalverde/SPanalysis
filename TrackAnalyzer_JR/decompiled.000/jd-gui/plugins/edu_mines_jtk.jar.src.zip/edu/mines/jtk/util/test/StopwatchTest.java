/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StopwatchTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 21 */     TestSuite suite = new TestSuite(StopwatchTest.class);
/* 22 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void test() {
/* 26 */     double sleepTime = 0.1D;
/* 27 */     double smallTime = 0.01D;
/* 28 */     Stopwatch sw = new Stopwatch();
/*    */ 
/*    */     
/* 31 */     boolean ok = true;
/* 32 */     for (int itrial = 0; itrial < 100; itrial++) {
/* 33 */       sw.reset();
/* 34 */       ok = true;
/*    */ 
/*    */       
/* 37 */       sw.start();
/* 38 */       sleep(sleepTime);
/* 39 */       ok = (ok && sleepTime - smallTime < sw.time());
/* 40 */       ok = (ok && sw.time() < sleepTime + smallTime);
/*    */ 
/*    */       
/* 43 */       sw.stop();
/* 44 */       ok = (ok && sleepTime - smallTime < sw.time());
/* 45 */       ok = (ok && sw.time() < sleepTime + smallTime);
/*    */ 
/*    */       
/* 48 */       sleep(sleepTime);
/* 49 */       sw.start();
/* 50 */       sleep(sleepTime);
/* 51 */       sw.stop();
/* 52 */       ok = (ok && 2.0D * (sleepTime - smallTime) < sw.time());
/* 53 */       ok = (ok && sw.time() < 2.0D * (sleepTime + smallTime));
/*    */ 
/*    */       
/* 56 */       sw.restart();
/* 57 */       sleep(sleepTime);
/* 58 */       sw.stop();
/* 59 */       ok = (ok && sleepTime - smallTime < sw.time());
/* 60 */       ok = (ok && sw.time() < sleepTime + smallTime);
/*    */ 
/*    */       
/* 63 */       if (ok)
/*    */         break; 
/*    */     } 
/* 66 */     assertTrue(ok);
/*    */   }
/*    */   
/*    */   private static void sleep(double time) {
/*    */     try {
/* 71 */       Thread.sleep((long)(time * 1000.0D));
/* 72 */     } catch (InterruptedException ie) {
/* 73 */       assertTrue("no exception", false);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/StopwatchTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */