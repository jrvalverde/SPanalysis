/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArgsParser
/*     */ {
/*     */   private String[] _args;
/*     */   private String _shortOpts;
/*     */   private String[] _longOpts;
/*     */   private String _longOpt;
/*     */   private ArrayList<String> _optList;
/*     */   private ArrayList<String> _valList;
/*     */   private ArrayList<String> _argList;
/*     */   
/*     */   public static class OptionException
/*     */     extends Exception
/*     */   {
/*     */     private OptionException(String msg) {
/*  81 */       super(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArgsParser(String[] args, String shortOpts) throws OptionException {
/*  96 */     this._args = args;
/*  97 */     this._shortOpts = shortOpts;
/*  98 */     this._longOpts = new String[0];
/*  99 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArgsParser(String[] args, String shortOpts, String[] longOpts) throws OptionException {
/* 120 */     this._args = args;
/* 121 */     this._shortOpts = shortOpts;
/* 122 */     this._longOpts = longOpts;
/* 123 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getOptions() {
/* 135 */     return getStrings(this._optList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValues() {
/* 144 */     return getStrings(this._valList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getOtherArgs() {
/* 152 */     return getStrings(this._argList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String s) throws OptionException {
/* 162 */     s = s.toLowerCase();
/* 163 */     if (s.equals("true"))
/* 164 */       return true; 
/* 165 */     if (s.equals("false"))
/* 166 */       return false; 
/* 167 */     throw new OptionException("the value " + s + " is not a valid boolean");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double toDouble(String s) throws OptionException {
/*     */     try {
/* 178 */       return Double.valueOf(s).doubleValue();
/* 179 */     } catch (NumberFormatException e) {
/* 180 */       throw new OptionException("the value " + s + " is not a valid double");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float toFloat(String s) throws OptionException {
/*     */     try {
/* 192 */       return Float.valueOf(s).floatValue();
/* 193 */     } catch (NumberFormatException e) {
/* 194 */       throw new OptionException("the value " + s + " is not a valid float");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInt(String s) throws OptionException {
/*     */     try {
/* 206 */       return Integer.parseInt(s);
/* 207 */     } catch (NumberFormatException e) {
/* 208 */       throw new OptionException("the value " + s + " is not a valid int");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long toLong(String s) throws OptionException {
/*     */     try {
/* 220 */       return Long.parseLong(s);
/* 221 */     } catch (NumberFormatException e) {
/* 222 */       throw new OptionException("the value " + s + " is not a valid long");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws OptionException {
/* 241 */     int n = this._args.length;
/* 242 */     this._optList = new ArrayList<String>(n);
/* 243 */     this._valList = new ArrayList<String>(n);
/* 244 */     this._argList = new ArrayList<String>(n);
/* 245 */     for (int i = 0; i < n; i++)
/* 246 */       this._argList.add(this._args[i]); 
/* 247 */     while (!this._argList.isEmpty()) {
/* 248 */       String arg = this._argList.get(0);
/* 249 */       if (arg.charAt(0) != '-' || arg.equals("-"))
/*     */         break; 
/* 251 */       this._argList.remove(0);
/* 252 */       if (arg.equals("--"))
/*     */         break; 
/* 254 */       if (arg.charAt(1) == '-') {
/* 255 */         doLongOption(arg); continue;
/*     */       } 
/* 257 */       doShortOption(arg);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doShortOption(String arg) throws OptionException {
/* 263 */     String argString = arg.substring(1);
/* 264 */     while (!argString.equals("")) {
/* 265 */       char opt = argString.charAt(0);
/* 266 */       argString = argString.substring(1);
/* 267 */       String val = "";
/* 268 */       if (shortOptionHasValue(opt)) {
/* 269 */         if (argString.equals("")) {
/* 270 */           if (this._argList.isEmpty())
/* 271 */             throw new OptionException("option -" + opt + " requires a value"); 
/* 272 */           argString = this._argList.remove(0);
/*     */         } 
/* 274 */         val = argString;
/* 275 */         argString = "";
/*     */       } 
/* 277 */       this._optList.add(new String("-" + opt));
/* 278 */       this._valList.add(val);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean shortOptionHasValue(char opt) throws OptionException {
/* 283 */     for (int i = 0; i < this._shortOpts.length(); i++) {
/* 284 */       if (opt == this._shortOpts.charAt(i) && opt != ':')
/* 285 */         return (i + 1 < this._shortOpts.length() && this._shortOpts.charAt(i + 1) == ':'); 
/*     */     } 
/* 287 */     throw new OptionException("option -" + opt + " not recognized");
/*     */   }
/*     */   
/*     */   private void doLongOption(String arg) throws OptionException {
/* 291 */     String argString = arg.substring(2);
/* 292 */     String opt = argString;
/* 293 */     String val = null;
/* 294 */     int i = argString.indexOf('=');
/* 295 */     if (i >= 0) {
/* 296 */       opt = argString.substring(0, i);
/* 297 */       val = (i + 1 < argString.length()) ? argString.substring(i + 1) : "";
/*     */     } 
/* 299 */     boolean hasValue = longOptionHasValue(opt);
/* 300 */     opt = this._longOpt;
/* 301 */     if (hasValue) {
/* 302 */       if (val == null) {
/* 303 */         if (this._argList.isEmpty())
/* 304 */           throw new OptionException("option --" + opt + " requires a value"); 
/* 305 */         val = this._argList.remove(0);
/*     */       } 
/* 307 */     } else if (val != null) {
/* 308 */       throw new OptionException("option --" + opt + " must not have a value");
/*     */     } 
/* 310 */     this._optList.add(new String("--" + opt));
/* 311 */     this._valList.add(val);
/*     */   }
/*     */   
/*     */   private boolean longOptionHasValue(String opt) throws OptionException {
/* 315 */     int lenOpt = opt.length();
/* 316 */     for (int i = 0; i < this._longOpts.length; i++) {
/* 317 */       String longOpt = this._longOpts[i];
/* 318 */       int lenLongOpt = longOpt.length();
/* 319 */       if (lenOpt <= lenLongOpt) {
/*     */         
/* 321 */         String x = longOpt.substring(0, lenOpt);
/* 322 */         if (x.equals(opt))
/*     */         
/* 324 */         { String y = longOpt.substring(lenOpt, longOpt.length());
/* 325 */           if (!y.equals("") && !y.equals("=") && i + 1 < this._longOpts.length && 
/* 326 */             opt.equals(this._longOpts[i + 1].substring(0, lenOpt)))
/* 327 */             throw new OptionException("option --" + opt + " not a unique prefix"); 
/* 328 */           int last = longOpt.length() - 1;
/* 329 */           if (longOpt.charAt(last) == '=') {
/* 330 */             this._longOpt = longOpt.substring(0, last);
/* 331 */             return true;
/*     */           } 
/* 333 */           this._longOpt = longOpt;
/* 334 */           return false; } 
/*     */       } 
/* 336 */     }  throw new OptionException("option --" + opt + " not recognized");
/*     */   }
/*     */   
/*     */   private static String[] getStrings(ArrayList<String> list) {
/* 340 */     int n = list.size();
/* 341 */     String[] a = new String[n];
/* 342 */     for (int i = 0; i < n; i++)
/* 343 */       a[i] = list.get(i); 
/* 344 */     return a;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/ArgsParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */