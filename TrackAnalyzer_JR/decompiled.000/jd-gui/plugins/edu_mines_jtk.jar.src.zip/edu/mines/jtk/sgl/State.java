package edu.mines.jtk.sgl;

public interface State {
  void apply();
  
  int getAttributeBits();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/State.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */