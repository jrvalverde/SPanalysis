/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Toolkit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrbitView
/*     */   extends View
/*     */ {
/*     */   private double _scale;
/*     */   private Vector3 _translate;
/*     */   private double _azimuth;
/*     */   private double _elevation;
/*     */   private Projection _projection;
/*     */   private BoundingSphere _worldSphere;
/*     */   private Matrix44 _worldToUnitSphere;
/*     */   private Matrix44 _unitSphereToView;
/*     */   private Stopwatch _stopwatch;
/*     */   private int _ndraw;
/*     */   
/*     */   public enum Projection
/*     */   {
/*  65 */     PERSPECTIVE, ORTHOGRAPHIC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OrbitView()
/*     */   {
/* 406 */     this._projection = Projection.PERSPECTIVE;
/* 407 */     this._worldSphere = null; init(); } public OrbitView(World world) { super(world); this._projection = Projection.PERSPECTIVE; this._worldSphere = null; init(); updateTransforms(); }
/*     */   public void reset() { init(); updateView(); }
/*     */   public void setWorldSphere(BoundingSphere worldSphere) { this._worldSphere = worldSphere; updateView(); }
/*     */   public BoundingSphere getWorldSphere() { return new BoundingSphere(this._worldSphere); }
/*     */   public void setProjection(Projection projection) { if (this._projection == projection) return;  this._projection = projection; updateView(); }
/*     */   public Projection getProjection() { return this._projection; }
/*     */   public void setAzimuth(double azimuth) { if (this._azimuth == azimuth) return;  this._azimuth = azimuth; updateView(); }
/* 414 */   public double getAzimuth() { return this._azimuth; } public void setElevation(double elevation) { if (this._elevation == elevation) return;  this._elevation = elevation; updateView(); } public double getElevation() { return this._elevation; } private void init() { this._scale = 1.0D;
/* 415 */     this._translate = new Vector3(0.0D, 0.0D, 0.0D);
/* 416 */     this._azimuth = 40.0D;
/* 417 */     this._elevation = 25.0D;
/* 418 */     this._projection = Projection.PERSPECTIVE;
/* 419 */     this._ndraw = 0;
/* 420 */     this._stopwatch = new Stopwatch();
/* 421 */     this._stopwatch.start(); }
/*     */   public void setAzimuthAndElevation(double azimuth, double elevation) { if (this._azimuth == azimuth && this._elevation == elevation) return;  this._azimuth = azimuth; this._elevation = elevation; updateView(); }
/*     */   public void setScale(double scale) { if (this._scale == scale) return;  this._scale = scale; updateView(); }
/*     */   public double getScale() { return this._scale; }
/* 425 */   public void setTranslate(Vector3 translate) { if (this._translate.equals(translate)) return;  this._translate = new Vector3(translate); updateView(); } public Vector3 getTranslate() { return new Vector3(this._translate); } public Matrix44 getWorldToUnitSphere() { return new Matrix44(this._worldToUnitSphere); } public Matrix44 getUnitSphereToView() { return new Matrix44(this._unitSphereToView); } protected void updateTransforms(ViewCanvas canvas) { Matrix44 viewToCube; double distance; int w = canvas.getWidth(); int h = canvas.getHeight(); if (w == 0 || h == 0) return;  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); double xs = screenSize.width; double ys = screenSize.height; double ss = Math.sqrt(xs * xs + ys * ys); Matrix44 cubeToPixel = Matrix44.identity(); cubeToPixel.timesEquals(Matrix44.translate(0.5D * w, 0.5D * h, 0.5D)); cubeToPixel.timesEquals(Matrix44.scale(0.5D * w, -0.5D * h, 0.5D)); canvas.setCubeToPixel(cubeToPixel); double maxscale = 3.0D; if (this._projection == Projection.PERSPECTIVE) { double r = 1.0D; double e = ss; double m = Math.min(w, h); double a = 2.0D * Math.atan(m / 2.0D * e); double d = r / Math.sin(a / 2.0D); double fovy = 2.0D * Math.atan(h / 2.0D * e) * 180.0D / Math.PI; double aspect = w / h; double znear = Math.max(d - maxscale * r, 0.1D); double zfar = Math.max(d + maxscale * r, 100.0D * znear); viewToCube = Matrix44.perspective(fovy, aspect, znear, zfar); distance = d; } else { double r = 1.0D; double m = Math.min(w, h); double d = maxscale * r; double right = w / m; double left = -right; double top = h / m; double bottom = -top; double znear = 0.0D; double zfar = 2.0D * maxscale * r; viewToCube = Matrix44.ortho(left, right, bottom, top, znear, zfar); distance = d; }  canvas.setViewToCube(viewToCube); this._unitSphereToView = Matrix44.identity(); this._unitSphereToView.timesEquals(Matrix44.translate(0.0D, 0.0D, -distance)); this._unitSphereToView.timesEquals(Matrix44.rotateX(this._elevation)); this._unitSphereToView.timesEquals(Matrix44.rotateY(-this._azimuth)); this._unitSphereToView.timesEquals(Matrix44.scale(this._scale, this._scale, this._scale)); this._unitSphereToView.timesEquals(Matrix44.translate(this._translate)); Tuple3 as = getAxesScale(); View.AxesOrientation ao = getAxesOrientation(); this._worldToUnitSphere = Matrix44.identity(); World world = getWorld(); if (world != null) { if (this._worldSphere == null) this._worldSphere = world.getBoundingSphere(true);  BoundingSphere ws = this._worldSphere; Point3 c = !ws.isEmpty() ? ws.getCenter() : new Point3(); double tx = -c.x; double ty = -c.y; double tz = -c.z; double r = !ws.isEmpty() ? ws.getRadius() : 1.0D; double s = (r > 0.0D) ? (1.0D / r) : 1.0D; double sx = s * as.x; double sy = s * as.y; double sz = s * as.z; if (ao == View.AxesOrientation.XRIGHT_YUP_ZOUT) { this._worldToUnitSphere.timesEquals(Matrix44.identity()); } else if (ao == View.AxesOrientation.XRIGHT_YOUT_ZDOWN) { this._worldToUnitSphere.timesEquals(Matrix44.rotateX(90.0D)); } else if (ao == View.AxesOrientation.XRIGHT_YIN_ZDOWN) { this._worldToUnitSphere.timesEquals(Matrix44.rotateX(90.0D)); sy = -sy; } else if (ao == View.AxesOrientation.XOUT_YRIGHT_ZUP) { this._worldToUnitSphere.timesEquals(Matrix44.rotateY(-90.0D)); this._worldToUnitSphere.timesEquals(Matrix44.rotateX(-90.0D)); }  this._worldToUnitSphere.timesEquals(Matrix44.scale(sx, sy, sz)); this._worldToUnitSphere.timesEquals(Matrix44.translate(tx, ty, tz)); }  setWorldToView(this._unitSphereToView.times(this._worldToUnitSphere)); } protected void draw(ViewCanvas canvas) { Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F); Gl.glClear(16640); Gl.glEnable(2977); Gl.glEnable(2929); World world = getWorld(); if (world == null) return;  int w = canvas.getWidth(); int h = canvas.getHeight(); Gl.glViewport(0, 0, w, h); Matrix44 viewToCube = canvas.getViewToCube(); Gl.glMatrixMode(5889); Gl.glLoadMatrixd(viewToCube.m, 0); Gl.glMatrixMode(5888); Gl.glLoadIdentity(); float[] lightPosition = { -0.1F, -0.1F, 1.0F, 0.0F }; Gl.glLightfv(16384, 4611, lightPosition, 0); Gl.glEnable(16384); Matrix44 worldToView = getWorldToView(); Gl.glLoadMatrixd(worldToView.m, 0); CullContext cc = new CullContext(canvas); world.cullApply(cc); DrawList dl = cc.getDrawList(); DrawContext dc = new DrawContext(canvas); dl.draw(dc); this._ndraw++; if (this._stopwatch.time() > 2.0D) { this._stopwatch.stop(); int rate = (int)(this._ndraw / this._stopwatch.time()); System.out.println("OrbitView: draw frames/second = " + rate); this._ndraw = 0; this._stopwatch.restart(); }  } private void updateView() { updateTransforms();
/* 426 */     repaint(); }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/OrbitView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */