/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScalarVect
/*     */   implements Vect
/*     */ {
/*  16 */   protected double _value = 0.0D;
/*     */   
/*  18 */   protected double _variance = 1.0D;
/*     */   
/*  20 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScalarVect(double value, double variance) {
/*  30 */     init(value, variance);
/*     */   }
/*     */   
/*     */   protected ScalarVect() {
/*  34 */     init(0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(double value, double variance) {
/*  43 */     this._value = value;
/*  44 */     this._variance = variance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double get() {
/*  50 */     return this._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(double value) {
/*  55 */     this._value = value;
/*     */   }
/*     */   
/*     */   public ScalarVect clone() {
/*     */     try {
/*  60 */       ScalarVect result = (ScalarVect)super.clone();
/*  61 */       return result;
/*  62 */     } catch (CloneNotSupportedException ex) {
/*  63 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/*  64 */       e.initCause(ex);
/*  65 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/*  71 */     ScalarVect rhs = (ScalarVect)other;
/*  72 */     return this._value * rhs._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     return "ScalarVect<" + this._value + ">";
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  82 */     this._value = Double.NaN;
/*  83 */     this._variance = Double.NaN;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/*  88 */     this._value = Almost.FLOAT.divide(this._value, this._variance, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {}
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/*  99 */     ScalarVect rhs = (ScalarVect)other;
/* 100 */     this._value = scaleThis * this._value + scaleOther * rhs._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 105 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/* 110 */     return Almost.FLOAT.divide(dot(this), this._variance, 0.0D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ScalarVect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */