/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Group
/*     */   extends Node
/*     */ {
/*     */   public void addChild(Node child) {
/*  32 */     Check.argument(!(child instanceof World), "child is not a world");
/*  33 */     World worldChild = child.getWorld();
/*  34 */     World worldGroup = getWorld();
/*  35 */     Check.argument((worldChild == null || worldGroup == null || worldChild == worldGroup), "child is not already in a different world");
/*     */ 
/*     */     
/*  38 */     if (child.addParent(this)) {
/*  39 */       this._childList.add(child);
/*  40 */       dirtyBoundingSphere();
/*  41 */       dirtyDraw();
/*  42 */       if (worldGroup != null) {
/*  43 */         worldGroup.updateSelectedSet(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChild(Node child) {
/*  53 */     if (child.removeParent(this)) {
/*  54 */       this._childList.remove(child);
/*  55 */       dirtyBoundingSphere();
/*  56 */       dirtyDraw();
/*  57 */       World worldGroup = getWorld();
/*  58 */       if (worldGroup != null) {
/*  59 */         worldGroup.updateSelectedSet(child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countChildren() {
/*  68 */     return this._childList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Node> getChildren() {
/*  76 */     return this._childList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cull(CullContext cc) {
/*  88 */     for (Node child : this._childList) {
/*  89 */       child.cullApply(cc);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void draw(DrawContext dc) {
/* 102 */     for (Node child : this._childList) {
/* 103 */       child.drawApply(dc);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pick(PickContext pc) {
/* 112 */     for (Node child : this._childList) {
/* 113 */       child.pickApply(pc);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 122 */     if (countChildren() == 1) {
/* 123 */       return ((Node)this._childList.get(0)).getBoundingSphere(finite);
/*     */     }
/* 125 */     BoundingBox bb = new BoundingBox();
/* 126 */     for (Node child : this._childList)
/* 127 */       bb.expandBy(child.getBoundingSphere(finite)); 
/* 128 */     if (bb.isEmpty())
/* 129 */       return BoundingSphere.empty(); 
/* 130 */     if (bb.isInfinite())
/* 131 */       return BoundingSphere.infinite(); 
/* 132 */     BoundingSphere bs = new BoundingSphere(bb.getCenter(), 0.0D);
/* 133 */     for (Node child : this._childList)
/* 134 */       bs.expandRadiusBy(child.getBoundingSphere(finite)); 
/* 135 */     return bs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getAttributeBits() {
/* 149 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   ArrayList<Node> _childList = new ArrayList<Node>(4);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Group.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */