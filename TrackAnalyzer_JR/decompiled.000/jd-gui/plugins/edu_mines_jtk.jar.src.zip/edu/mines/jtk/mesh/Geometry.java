/*      */ package edu.mines.jtk.mesh;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Geometry
/*      */ {
/*      */   private static final double EPSILON;
/*      */   private static final double SPLITTER;
/*      */   private static final double O2DERRBOUND;
/*      */   private static final double O3DERRBOUND;
/*      */   private static final double INCERRBOUND;
/*      */   private static final double INSERRBOUND;
/*      */   private static final double IOSERRBOUND;
/*      */   
/*      */   public static double leftOfLine(double xa, double ya, double xb, double yb, double xc, double yc) {
/*   50 */     double detsum, detleft = (xa - xc) * (yb - yc);
/*   51 */     double detright = (ya - yc) * (xb - xc);
/*   52 */     double det = detleft - detright;
/*      */     
/*   54 */     if (detleft > 0.0D) {
/*   55 */       if (detright <= 0.0D) {
/*   56 */         return det;
/*      */       }
/*   58 */       detsum = detleft + detright;
/*      */     }
/*   60 */     else if (detleft < 0.0D) {
/*   61 */       if (detright >= 0.0D) {
/*   62 */         return det;
/*      */       }
/*   64 */       detsum = -detleft - detright;
/*      */     } else {
/*      */       
/*   67 */       return det;
/*      */     } 
/*   69 */     double errbound = O2DERRBOUND * detsum;
/*   70 */     if (det >= errbound || -det >= errbound) {
/*   71 */       return det;
/*      */     }
/*   73 */     return leftOfLineExact(xa, ya, xb, yb, xc, yc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfLine(double[] pa, double[] pb, double[] pc) {
/*   87 */     return leftOfLine(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfLine(float[] pa, float[] pb, float[] pc) {
/*  104 */     return leftOfLine(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfLineFast(double xa, double ya, double xb, double yb, double xc, double yc) {
/*  125 */     double acx = xa - xc;
/*  126 */     double bcx = xb - xc;
/*  127 */     double acy = ya - yc;
/*  128 */     double bcy = yb - yc;
/*  129 */     return acx * bcy - acy * bcx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfLineFast(double[] pa, double[] pb, double[] pc) {
/*  145 */     return leftOfLineFast(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfLineFast(float[] pa, float[] pb, float[] pc) {
/*  164 */     return leftOfLineFast(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlane(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd) {
/*  184 */     double adx = xa - xd;
/*  185 */     double bdx = xb - xd;
/*  186 */     double cdx = xc - xd;
/*  187 */     double ady = ya - yd;
/*  188 */     double bdy = yb - yd;
/*  189 */     double cdy = yc - yd;
/*  190 */     double adz = za - zd;
/*  191 */     double bdz = zb - zd;
/*  192 */     double cdz = zc - zd;
/*      */     
/*  194 */     double bdxcdy = bdx * cdy;
/*  195 */     double cdxbdy = cdx * bdy;
/*      */     
/*  197 */     double cdxady = cdx * ady;
/*  198 */     double adxcdy = adx * cdy;
/*      */     
/*  200 */     double adxbdy = adx * bdy;
/*  201 */     double bdxady = bdx * ady;
/*      */     
/*  203 */     double det = adz * (bdxcdy - cdxbdy) + bdz * (cdxady - adxcdy) + cdz * (adxbdy - bdxady);
/*      */ 
/*      */ 
/*      */     
/*  207 */     if (adz < 0.0D) adz = -adz; 
/*  208 */     if (bdz < 0.0D) bdz = -bdz; 
/*  209 */     if (cdz < 0.0D) cdz = -cdz; 
/*  210 */     if (bdxcdy < 0.0D) bdxcdy = -bdxcdy; 
/*  211 */     if (cdxbdy < 0.0D) cdxbdy = -cdxbdy; 
/*  212 */     if (cdxady < 0.0D) cdxady = -cdxady; 
/*  213 */     if (adxcdy < 0.0D) adxcdy = -adxcdy; 
/*  214 */     if (adxbdy < 0.0D) adxbdy = -adxbdy; 
/*  215 */     if (bdxady < 0.0D) bdxady = -bdxady; 
/*  216 */     double permanent = (bdxcdy + cdxbdy) * adz + (cdxady + adxcdy) * bdz + (adxbdy + bdxady) * cdz;
/*      */ 
/*      */     
/*  219 */     double errbound = O3DERRBOUND * permanent;
/*  220 */     if (det > errbound || -det > errbound) {
/*  221 */       return det;
/*      */     }
/*      */     
/*  224 */     return leftOfPlaneExact(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlane(double[] pa, double[] pb, double[] pc, double[] pd) {
/*  238 */     return leftOfPlane(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlane(float[] pa, float[] pb, float[] pc, float[] pd) {
/*  256 */     return leftOfPlane(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlaneFast(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd) {
/*  279 */     double adx = xa - xd;
/*  280 */     double bdx = xb - xd;
/*  281 */     double cdx = xc - xd;
/*  282 */     double ady = ya - yd;
/*  283 */     double bdy = yb - yd;
/*  284 */     double cdy = yc - yd;
/*  285 */     double adz = za - zd;
/*  286 */     double bdz = zb - zd;
/*  287 */     double cdz = zc - zd;
/*      */     
/*  289 */     return adx * (bdy * cdz - bdz * cdy) + bdx * (cdy * adz - cdz * ady) + cdx * (ady * bdz - adz * bdy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlaneFast(double[] pa, double[] pb, double[] pc, double[] pd) {
/*  307 */     return leftOfPlaneFast(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double leftOfPlaneFast(float[] pa, float[] pb, float[] pc, float[] pd) {
/*  327 */     return leftOfPlaneFast(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircle(double xa, double ya, double xb, double yb, double xc, double yc, double xd, double yd) {
/*  348 */     double adx = xa - xd;
/*  349 */     double bdx = xb - xd;
/*  350 */     double cdx = xc - xd;
/*  351 */     double ady = ya - yd;
/*  352 */     double bdy = yb - yd;
/*  353 */     double cdy = yc - yd;
/*      */     
/*  355 */     double bdxcdy = bdx * cdy;
/*  356 */     double cdxbdy = cdx * bdy;
/*  357 */     double alift = adx * adx + ady * ady;
/*      */     
/*  359 */     double cdxady = cdx * ady;
/*  360 */     double adxcdy = adx * cdy;
/*  361 */     double blift = bdx * bdx + bdy * bdy;
/*      */     
/*  363 */     double adxbdy = adx * bdy;
/*  364 */     double bdxady = bdx * ady;
/*  365 */     double clift = cdx * cdx + cdy * cdy;
/*      */     
/*  367 */     double det = alift * (bdxcdy - cdxbdy) + blift * (cdxady - adxcdy) + clift * (adxbdy - bdxady);
/*      */ 
/*      */ 
/*      */     
/*  371 */     if (bdxcdy < 0.0D) bdxcdy = -bdxcdy; 
/*  372 */     if (cdxbdy < 0.0D) cdxbdy = -cdxbdy; 
/*  373 */     if (adxcdy < 0.0D) adxcdy = -adxcdy; 
/*  374 */     if (cdxady < 0.0D) cdxady = -cdxady; 
/*  375 */     if (adxbdy < 0.0D) adxbdy = -adxbdy; 
/*  376 */     if (bdxady < 0.0D) bdxady = -bdxady;
/*      */     
/*  378 */     double permanent = alift * (bdxcdy + cdxbdy) + blift * (cdxady + adxcdy) + clift * (adxbdy + bdxady);
/*      */ 
/*      */     
/*  381 */     double errbound = INCERRBOUND * permanent;
/*  382 */     if (det > errbound || -det > errbound) {
/*  383 */       return det;
/*      */     }
/*  385 */     return inCircleExact(xa, ya, xb, yb, xc, yc, xd, yd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircle(double[] pa, double[] pb, double[] pc, double[] pd) {
/*  399 */     return inCircle(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], pd[0], pd[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircle(float[] pa, float[] pb, float[] pc, float[] pd) {
/*  417 */     return inCircle(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], pd[0], pd[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircleFast(double xa, double ya, double xb, double yb, double xc, double yc, double xd, double yd) {
/*  440 */     double adx = xa - xd;
/*  441 */     double ady = ya - yd;
/*  442 */     double bdx = xb - xd;
/*  443 */     double bdy = yb - yd;
/*  444 */     double cdx = xc - xd;
/*  445 */     double cdy = yc - yd;
/*      */     
/*  447 */     double abdet = adx * bdy - bdx * ady;
/*  448 */     double bcdet = bdx * cdy - cdx * bdy;
/*  449 */     double cadet = cdx * ady - adx * cdy;
/*  450 */     double alift = adx * adx + ady * ady;
/*  451 */     double blift = bdx * bdx + bdy * bdy;
/*  452 */     double clift = cdx * cdx + cdy * cdy;
/*      */     
/*  454 */     return alift * bcdet + blift * cadet + clift * abdet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircleFast(double[] pa, double[] pb, double[] pc, double[] pd) {
/*  470 */     return inCircleFast(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], pd[0], pd[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inCircleFast(float[] pa, float[] pb, float[] pc, float[] pd) {
/*  490 */     return inCircleFast(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], pd[0], pd[1]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphere(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd, double xe, double ye, double ze) {
/*  512 */     double aex = xa - xe;
/*  513 */     double bex = xb - xe;
/*  514 */     double cex = xc - xe;
/*  515 */     double dex = xd - xe;
/*  516 */     double aey = ya - ye;
/*  517 */     double bey = yb - ye;
/*  518 */     double cey = yc - ye;
/*  519 */     double dey = yd - ye;
/*  520 */     double aez = za - ze;
/*  521 */     double bez = zb - ze;
/*  522 */     double cez = zc - ze;
/*  523 */     double dez = zd - ze;
/*      */     
/*  525 */     double aexbey = aex * bey;
/*  526 */     double bexaey = bex * aey;
/*  527 */     double ab = aexbey - bexaey;
/*  528 */     double bexcey = bex * cey;
/*  529 */     double cexbey = cex * bey;
/*  530 */     double bc = bexcey - cexbey;
/*  531 */     double cexdey = cex * dey;
/*  532 */     double dexcey = dex * cey;
/*  533 */     double cd = cexdey - dexcey;
/*  534 */     double dexaey = dex * aey;
/*  535 */     double aexdey = aex * dey;
/*  536 */     double da = dexaey - aexdey;
/*      */     
/*  538 */     double aexcey = aex * cey;
/*  539 */     double cexaey = cex * aey;
/*  540 */     double ac = aexcey - cexaey;
/*  541 */     double bexdey = bex * dey;
/*  542 */     double dexbey = dex * bey;
/*  543 */     double bd = bexdey - dexbey;
/*      */     
/*  545 */     double abc = aez * bc - bez * ac + cez * ab;
/*  546 */     double bcd = bez * cd - cez * bd + dez * bc;
/*  547 */     double cda = cez * da + dez * ac + aez * cd;
/*  548 */     double dab = dez * ab + aez * bd + bez * da;
/*      */     
/*  550 */     double alift = aex * aex + aey * aey + aez * aez;
/*  551 */     double blift = bex * bex + bey * bey + bez * bez;
/*  552 */     double clift = cex * cex + cey * cey + cez * cez;
/*  553 */     double dlift = dex * dex + dey * dey + dez * dez;
/*      */     
/*  555 */     double det = dlift * abc - clift * dab + blift * cda - alift * bcd;
/*      */     
/*  557 */     if (aez < 0.0D) aez = -aez; 
/*  558 */     if (bez < 0.0D) bez = -bez; 
/*  559 */     if (cez < 0.0D) cez = -cez; 
/*  560 */     if (dez < 0.0D) dez = -dez; 
/*  561 */     if (aexbey < 0.0D) aexbey = -aexbey; 
/*  562 */     if (bexaey < 0.0D) bexaey = -bexaey; 
/*  563 */     if (bexcey < 0.0D) bexcey = -bexcey; 
/*  564 */     if (cexbey < 0.0D) cexbey = -cexbey; 
/*  565 */     if (cexdey < 0.0D) cexdey = -cexdey; 
/*  566 */     if (dexcey < 0.0D) dexcey = -dexcey; 
/*  567 */     if (dexaey < 0.0D) dexaey = -dexaey; 
/*  568 */     if (aexdey < 0.0D) aexdey = -aexdey; 
/*  569 */     if (aexcey < 0.0D) aexcey = -aexcey; 
/*  570 */     if (cexaey < 0.0D) cexaey = -cexaey; 
/*  571 */     if (bexdey < 0.0D) bexdey = -bexdey; 
/*  572 */     if (dexbey < 0.0D) dexbey = -dexbey; 
/*  573 */     double permanent = ((cexdey + dexcey) * bez + (dexbey + bexdey) * cez + (bexcey + cexbey) * dez) * alift + ((dexaey + aexdey) * cez + (aexcey + cexaey) * dez + (cexdey + dexcey) * aez) * blift + ((aexbey + bexaey) * dez + (bexdey + dexbey) * aez + (dexaey + aexdey) * bez) * clift + ((bexcey + cexbey) * aez + (cexaey + aexcey) * bez + (aexbey + bexaey) * cez) * dlift;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  589 */     double errbound = INSERRBOUND * permanent;
/*  590 */     if (det > errbound || -det > errbound) {
/*  591 */       return det;
/*      */     }
/*      */     
/*  594 */     return inSphereExact(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd, xe, ye, ze);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphere(double[] pa, double[] pb, double[] pc, double[] pd, double[] pe) {
/*  608 */     return inSphere(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], pe[0], pe[1], pe[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphere(float[] pa, float[] pb, float[] pc, float[] pd, float[] pe) {
/*  627 */     return inSphere(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], pe[0], pe[1], pe[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphereFast(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd, double xe, double ye, double ze) {
/*  652 */     double aex = xa - xe;
/*  653 */     double bex = xb - xe;
/*  654 */     double cex = xc - xe;
/*  655 */     double dex = xd - xe;
/*  656 */     double aey = ya - ye;
/*  657 */     double bey = yb - ye;
/*  658 */     double cey = yc - ye;
/*  659 */     double dey = yd - ye;
/*  660 */     double aez = za - ze;
/*  661 */     double bez = zb - ze;
/*  662 */     double cez = zc - ze;
/*  663 */     double dez = zd - ze;
/*      */     
/*  665 */     double ab = aex * bey - bex * aey;
/*  666 */     double bc = bex * cey - cex * bey;
/*  667 */     double cd = cex * dey - dex * cey;
/*  668 */     double da = dex * aey - aex * dey;
/*      */     
/*  670 */     double ac = aex * cey - cex * aey;
/*  671 */     double bd = bex * dey - dex * bey;
/*      */     
/*  673 */     double abc = aez * bc - bez * ac + cez * ab;
/*  674 */     double bcd = bez * cd - cez * bd + dez * bc;
/*  675 */     double cda = cez * da + dez * ac + aez * cd;
/*  676 */     double dab = dez * ab + aez * bd + bez * da;
/*      */     
/*  678 */     double alift = aex * aex + aey * aey + aez * aez;
/*  679 */     double blift = bex * bex + bey * bey + bez * bez;
/*  680 */     double clift = cex * cex + cey * cey + cez * cez;
/*  681 */     double dlift = dex * dex + dey * dey + dez * dez;
/*      */     
/*  683 */     return dlift * abc - clift * dab + blift * cda - alift * bcd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphereFast(double[] pa, double[] pb, double[] pc, double[] pd, double[] pe) {
/*  699 */     return inSphereFast(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], pe[0], pe[1], pe[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inSphereFast(float[] pa, float[] pb, float[] pc, float[] pd, float[] pe) {
/*  720 */     return inSphereFast(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], pe[0], pe[1], pe[2]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphere(double xa, double ya, double za, double wa, double xb, double yb, double zb, double wb, double xc, double yc, double zc, double wc, double xd, double yd, double zd, double wd, double xe, double ye, double ze, double we) {
/*  749 */     double aex = xa - xe;
/*  750 */     double bex = xb - xe;
/*  751 */     double cex = xc - xe;
/*  752 */     double dex = xd - xe;
/*  753 */     double aey = ya - ye;
/*  754 */     double bey = yb - ye;
/*  755 */     double cey = yc - ye;
/*  756 */     double dey = yd - ye;
/*  757 */     double aez = za - ze;
/*  758 */     double bez = zb - ze;
/*  759 */     double cez = zc - ze;
/*  760 */     double dez = zd - ze;
/*  761 */     double aew = wa - we;
/*  762 */     double bew = wb - we;
/*  763 */     double cew = wc - we;
/*  764 */     double dew = wd - we;
/*      */     
/*  766 */     double aexbey = aex * bey;
/*  767 */     double bexaey = bex * aey;
/*  768 */     double ab = aexbey - bexaey;
/*  769 */     double bexcey = bex * cey;
/*  770 */     double cexbey = cex * bey;
/*  771 */     double bc = bexcey - cexbey;
/*  772 */     double cexdey = cex * dey;
/*  773 */     double dexcey = dex * cey;
/*  774 */     double cd = cexdey - dexcey;
/*  775 */     double dexaey = dex * aey;
/*  776 */     double aexdey = aex * dey;
/*  777 */     double da = dexaey - aexdey;
/*      */     
/*  779 */     double aexcey = aex * cey;
/*  780 */     double cexaey = cex * aey;
/*  781 */     double ac = aexcey - cexaey;
/*  782 */     double bexdey = bex * dey;
/*  783 */     double dexbey = dex * bey;
/*  784 */     double bd = bexdey - dexbey;
/*      */     
/*  786 */     double abc = aez * bc - bez * ac + cez * ab;
/*  787 */     double bcd = bez * cd - cez * bd + dez * bc;
/*  788 */     double cda = cez * da + dez * ac + aez * cd;
/*  789 */     double dab = dez * ab + aez * bd + bez * da;
/*      */     
/*  791 */     double alift = aex * aex + aey * aey + aez * aez;
/*  792 */     double blift = bex * bex + bey * bey + bez * bez;
/*  793 */     double clift = cex * cex + cey * cey + cez * cez;
/*  794 */     double dlift = dex * dex + dey * dey + dez * dez;
/*      */     
/*  796 */     double det = (dlift - dew) * abc - (clift - cew) * dab + (blift - bew) * cda - (alift - aew) * bcd;
/*      */ 
/*      */     
/*  799 */     if (aez < 0.0D) aez = -aez; 
/*  800 */     if (bez < 0.0D) bez = -bez; 
/*  801 */     if (cez < 0.0D) cez = -cez; 
/*  802 */     if (dez < 0.0D) dez = -dez; 
/*  803 */     if (aew < 0.0D) aew = -aew; 
/*  804 */     if (bew < 0.0D) bew = -bew; 
/*  805 */     if (cew < 0.0D) cew = -cew; 
/*  806 */     if (dew < 0.0D) dew = -dew; 
/*  807 */     if (aexbey < 0.0D) aexbey = -aexbey; 
/*  808 */     if (bexaey < 0.0D) bexaey = -bexaey; 
/*  809 */     if (bexcey < 0.0D) bexcey = -bexcey; 
/*  810 */     if (cexbey < 0.0D) cexbey = -cexbey; 
/*  811 */     if (cexdey < 0.0D) cexdey = -cexdey; 
/*  812 */     if (dexcey < 0.0D) dexcey = -dexcey; 
/*  813 */     if (dexaey < 0.0D) dexaey = -dexaey; 
/*  814 */     if (aexdey < 0.0D) aexdey = -aexdey; 
/*  815 */     if (aexcey < 0.0D) aexcey = -aexcey; 
/*  816 */     if (cexaey < 0.0D) cexaey = -cexaey; 
/*  817 */     if (bexdey < 0.0D) bexdey = -bexdey; 
/*  818 */     if (dexbey < 0.0D) dexbey = -dexbey; 
/*  819 */     double permanent = ((cexdey + dexcey) * bez + (dexbey + bexdey) * cez + (bexcey + cexbey) * dez) * (alift + aew) + ((dexaey + aexdey) * cez + (aexcey + cexaey) * dez + (cexdey + dexcey) * aez) * (blift + bew) + ((aexbey + bexaey) * dez + (bexdey + dexbey) * aez + (dexaey + aexdey) * bez) * (clift + cew) + ((bexcey + cexbey) * aez + (cexaey + aexcey) * bez + (aexbey + bexaey) * cez) * (dlift + dew);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  835 */     double errbound = IOSERRBOUND * permanent;
/*  836 */     if (det > errbound || -det > errbound) {
/*  837 */       return det;
/*      */     }
/*      */     
/*  840 */     return inOrthoSphereExact(xa, ya, za, wa, xb, yb, zb, wb, xc, yc, zc, wc, xd, yd, zd, wd, xe, ye, ze, we);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphere(double[] pa, double[] pb, double[] pc, double[] pd, double[] pe) {
/*  858 */     return inOrthoSphere(pa[0], pa[1], pa[2], pa[3], pb[0], pb[1], pb[2], pb[3], pc[0], pc[1], pc[2], pc[3], pd[0], pd[1], pd[2], pd[3], pe[0], pe[1], pe[2], pe[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphere(float[] pa, float[] pb, float[] pc, float[] pd, float[] pe) {
/*  875 */     return inOrthoSphere(pa[0], pa[1], pa[2], pa[3], pb[0], pb[1], pb[2], pb[3], pc[0], pc[1], pc[2], pc[3], pd[0], pd[1], pd[2], pd[3], pe[0], pe[1], pe[2], pe[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphereFast(double xa, double ya, double za, double wa, double xb, double yb, double zb, double wb, double xc, double yc, double zc, double wc, double xd, double yd, double zd, double wd, double xe, double ye, double ze, double we) {
/*  898 */     double aex = xa - xe;
/*  899 */     double bex = xb - xe;
/*  900 */     double cex = xc - xe;
/*  901 */     double dex = xd - xe;
/*  902 */     double aey = ya - ye;
/*  903 */     double bey = yb - ye;
/*  904 */     double cey = yc - ye;
/*  905 */     double dey = yd - ye;
/*  906 */     double aez = za - ze;
/*  907 */     double bez = zb - ze;
/*  908 */     double cez = zc - ze;
/*  909 */     double dez = zd - ze;
/*  910 */     double aew = wa - we;
/*  911 */     double bew = wb - we;
/*  912 */     double cew = wc - we;
/*  913 */     double dew = wd - we;
/*      */     
/*  915 */     double ab = aex * bey - bex * aey;
/*  916 */     double bc = bex * cey - cex * bey;
/*  917 */     double cd = cex * dey - dex * cey;
/*  918 */     double da = dex * aey - aex * dey;
/*      */     
/*  920 */     double ac = aex * cey - cex * aey;
/*  921 */     double bd = bex * dey - dex * bey;
/*      */     
/*  923 */     double abc = aez * bc - bez * ac + cez * ab;
/*  924 */     double bcd = bez * cd - cez * bd + dez * bc;
/*  925 */     double cda = cez * da + dez * ac + aez * cd;
/*  926 */     double dab = dez * ab + aez * bd + bez * da;
/*      */     
/*  928 */     double alift = aex * aex + aey * aey + aez * aez - aew;
/*  929 */     double blift = bex * bex + bey * bey + bez * bez - bew;
/*  930 */     double clift = cex * cex + cey * cey + cez * cez - cew;
/*  931 */     double dlift = dex * dex + dey * dey + dez * dez - dew;
/*      */     
/*  933 */     return dlift * abc - clift * dab + blift * cda - alift * bcd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphereFast(double[] pa, double[] pb, double[] pc, double[] pd, double[] pe) {
/*  947 */     return inOrthoSphereFast(pa[0], pa[1], pa[2], pa[3], pb[0], pb[1], pb[2], pb[3], pc[0], pc[1], pc[2], pc[3], pd[0], pd[1], pd[2], pd[3], pe[0], pe[1], pe[2], pe[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double inOrthoSphereFast(float[] pa, float[] pb, float[] pc, float[] pd, float[] pe) {
/*  966 */     return inOrthoSphereFast(pa[0], pa[1], pa[2], pa[3], pb[0], pb[1], pb[2], pb[3], pc[0], pc[1], pc[2], pc[3], pd[0], pd[1], pd[2], pd[3], pe[0], pe[1], pe[2], pe[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerCircle(float xa, float ya, float xb, float yb, float xc, float yc, float[] po) {
/*  986 */     double acx = (xa - xc);
/*  987 */     double bcx = (xb - xc);
/*  988 */     double acy = (ya - yc);
/*  989 */     double bcy = (yb - yc);
/*  990 */     double acs = acx * acx + acy * acy;
/*  991 */     double bcs = bcx * bcx + bcy * bcy;
/*  992 */     double scale = 0.5D / leftOfLine(xa, ya, xb, yb, xc, yc);
/*  993 */     po[0] = (float)(xc + scale * (acs * bcy - bcs * acy));
/*  994 */     po[1] = (float)(yc + scale * (bcs * acx - acs * bcx));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerCircle(float[] pa, float[] pb, float[] pc, float[] po) {
/* 1006 */     centerCircle(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], po);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerCircle(double xa, double ya, double xb, double yb, double xc, double yc, double[] po) {
/* 1024 */     double acx = xa - xc;
/* 1025 */     double bcx = xb - xc;
/* 1026 */     double acy = ya - yc;
/* 1027 */     double bcy = yb - yc;
/* 1028 */     double acs = acx * acx + acy * acy;
/* 1029 */     double bcs = bcx * bcx + bcy * bcy;
/* 1030 */     double scale = 0.5D / leftOfLine(xa, ya, xb, yb, xc, yc);
/* 1031 */     po[0] = xc + scale * (acs * bcy - bcs * acy);
/* 1032 */     po[1] = yc + scale * (bcs * acx - acs * bcx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerCircle(double[] pa, double[] pb, double[] pc, double[] po) {
/* 1044 */     centerCircle(pa[0], pa[1], pb[0], pb[1], pc[0], pc[1], po);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerSphere(float xa, float ya, float za, float xb, float yb, float zb, float xc, float yc, float zc, float xd, float yd, float zd, float[] po) {
/* 1063 */     double adx = (xa - xd);
/* 1064 */     double bdx = (xb - xd);
/* 1065 */     double cdx = (xc - xd);
/* 1066 */     double ady = (ya - yd);
/* 1067 */     double bdy = (yb - yd);
/* 1068 */     double cdy = (yc - yd);
/* 1069 */     double adz = (za - zd);
/* 1070 */     double bdz = (zb - zd);
/* 1071 */     double cdz = (zc - zd);
/* 1072 */     double ads = adx * adx + ady * ady + adz * adz;
/* 1073 */     double bds = bdx * bdx + bdy * bdy + bdz * bdz;
/* 1074 */     double cds = cdx * cdx + cdy * cdy + cdz * cdz;
/* 1075 */     double scale = 0.5D / leftOfPlane(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd);
/* 1076 */     po[0] = xd + (float)(scale * (ads * (bdy * cdz - cdy * bdz) + bds * (cdy * adz - ady * cdz) + cds * (ady * bdz - bdy * adz)));
/*      */ 
/*      */     
/* 1079 */     po[1] = yd + (float)(scale * (ads * (bdz * cdx - cdz * bdx) + bds * (cdz * adx - adz * cdx) + cds * (adz * bdx - bdz * adx)));
/*      */ 
/*      */     
/* 1082 */     po[2] = zd + (float)(scale * (ads * (bdx * cdy - cdx * bdy) + bds * (cdx * ady - adx * cdy) + cds * (adx * bdy - bdx * ady)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerSphere(float[] pa, float[] pb, float[] pc, float[] pd, float[] po) {
/* 1096 */     centerSphere(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], po);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerSphere(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd, double[] po) {
/* 1116 */     double adx = xa - xd;
/* 1117 */     double bdx = xb - xd;
/* 1118 */     double cdx = xc - xd;
/* 1119 */     double ady = ya - yd;
/* 1120 */     double bdy = yb - yd;
/* 1121 */     double cdy = yc - yd;
/* 1122 */     double adz = za - zd;
/* 1123 */     double bdz = zb - zd;
/* 1124 */     double cdz = zc - zd;
/* 1125 */     double ads = adx * adx + ady * ady + adz * adz;
/* 1126 */     double bds = bdx * bdx + bdy * bdy + bdz * bdz;
/* 1127 */     double cds = cdx * cdx + cdy * cdy + cdz * cdz;
/* 1128 */     double scale = 0.5D / leftOfPlane(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd);
/* 1129 */     po[0] = xd + scale * (ads * (bdy * cdz - cdy * bdz) + bds * (cdy * adz - ady * cdz) + cds * (ady * bdz - bdy * adz));
/*      */ 
/*      */     
/* 1132 */     po[1] = yd + scale * (ads * (bdz * cdx - cdz * bdx) + bds * (cdz * adx - adz * cdx) + cds * (adz * bdx - bdz * adx));
/*      */ 
/*      */     
/* 1135 */     po[2] = zd + scale * (ads * (bdx * cdy - cdx * bdy) + bds * (cdx * ady - adx * cdy) + cds * (adx * bdy - bdx * ady));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerSphere(double[] pa, double[] pb, double[] pc, double[] pd, double[] po) {
/* 1149 */     centerSphere(pa[0], pa[1], pa[2], pb[0], pb[1], pb[2], pc[0], pc[1], pc[2], pd[0], pd[1], pd[2], po);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void centerCircle3D(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double[] po) {
/* 1167 */     double acx = xa - xc;
/* 1168 */     double acy = ya - yc;
/* 1169 */     double acz = za - zc;
/* 1170 */     double bcx = xb - xc;
/* 1171 */     double bcy = yb - yc;
/* 1172 */     double bcz = zb - zc;
/* 1173 */     double acs = acx * acx + acy * acy + acz * acz;
/* 1174 */     double bcs = bcx * bcx + bcy * bcy + bcz * bcz;
/* 1175 */     double abx = leftOfLine(ya, za, yb, zb, yc, zc);
/* 1176 */     double aby = leftOfLine(za, xa, zb, xb, zc, xc);
/* 1177 */     double abz = leftOfLine(xa, ya, xb, yb, xc, yc);
/* 1178 */     double scale = 0.5D / (abx * abx + aby * aby + abz * abz);
/* 1179 */     po[0] = xc + scale * ((acs * bcy - bcs * acy) * abz - (acs * bcz - bcs * acz) * aby);
/* 1180 */     po[1] = yc + scale * ((acs * bcz - bcs * acz) * abx - (acs * bcx - bcs * acx) * abz);
/* 1181 */     po[2] = zc + scale * ((acs * bcx - bcs * acx) * aby - (acs * bcy - bcs * acy) * abx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Two
/*      */   {
/*      */     double x;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     double y;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Two() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/* 1217 */     double epsilon = 1.0D;
/* 1218 */     double splitter = 1.0D;
/* 1219 */     boolean everyOther = true;
/*      */     while (true) {
/* 1221 */       epsilon *= 0.5D;
/* 1222 */       if (everyOther)
/* 1223 */         splitter *= 2.0D; 
/* 1224 */       everyOther = !everyOther;
/* 1225 */       if (1.0D + epsilon == 1.0D) {
/* 1226 */         splitter++;
/* 1227 */         EPSILON = epsilon;
/* 1228 */         SPLITTER = splitter;
/* 1229 */         O2DERRBOUND = 4.0D * EPSILON;
/* 1230 */         O3DERRBOUND = 8.0D * EPSILON;
/* 1231 */         INCERRBOUND = 11.0D * EPSILON;
/* 1232 */         INSERRBOUND = 17.0D * EPSILON;
/* 1233 */         IOSERRBOUND = 19.0D * EPSILON;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static strictfp void twoSum(double a, double b, Two t) {
/* 1241 */     double x = a + b;
/* 1242 */     double bvirt = x - a;
/* 1243 */     double avirt = x - bvirt;
/* 1244 */     double bround = b - bvirt;
/* 1245 */     double around = a - avirt;
/* 1246 */     t.x = x;
/* 1247 */     t.y = around + bround;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void twoSumFast(double a, double b, Two t) {
/* 1255 */     double x = a + b;
/* 1256 */     double bvirt = x - a;
/* 1257 */     t.x = x;
/* 1258 */     t.y = b - bvirt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void twoDiff(double a, double b, Two t) {
/* 1266 */     double x = a - b;
/* 1267 */     double bvirt = a - x;
/* 1268 */     double avirt = x + bvirt;
/* 1269 */     double bround = bvirt - b;
/* 1270 */     double around = a - avirt;
/* 1271 */     t.x = x;
/* 1272 */     t.y = around + bround;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void split(double a, Two t) {
/* 1293 */     double c = SPLITTER * a;
/* 1294 */     double abig = c - a;
/* 1295 */     t.x = c - abig;
/* 1296 */     t.y = a - t.x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void twoProduct1Presplit(double a, double b, double bhi, double blo, Two t) {
/* 1327 */     split(a, t);
/* 1328 */     double ahi = t.x;
/* 1329 */     double alo = t.y;
/* 1330 */     t.x = a * b;
/* 1331 */     double err1 = t.x - ahi * bhi;
/* 1332 */     double err2 = err1 - alo * bhi;
/* 1333 */     double err3 = err2 - ahi * blo;
/* 1334 */     t.y = alo * blo - err3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void twoProduct2Presplit(double a, double ahi, double alo, double b, double bhi, double blo, Two t) {
/* 1344 */     t.x = a * b;
/* 1345 */     double err1 = t.x - ahi * bhi;
/* 1346 */     double err2 = err1 - alo * bhi;
/* 1347 */     double err3 = err2 - ahi * blo;
/* 1348 */     t.y = alo * blo - err3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static strictfp void twoTwoProduct(double a1, double a0, double b1, double b0, double[] x) {
/* 1359 */     Two t = new Two();
/* 1360 */     split(a0, t);
/* 1361 */     double a0hi = t.x;
/* 1362 */     double a0lo = t.y;
/* 1363 */     split(b0, t);
/* 1364 */     double b0hi = t.x;
/* 1365 */     double b0lo = t.y;
/* 1366 */     twoProduct2Presplit(a0, a0hi, a0lo, b0, b0hi, b0lo, t);
/* 1367 */     double ui = t.x;
/* 1368 */     x[0] = t.y;
/* 1369 */     split(a1, t);
/* 1370 */     double a1hi = t.x;
/* 1371 */     double a1lo = t.y;
/* 1372 */     twoProduct2Presplit(a1, a1hi, a1lo, b0, b0hi, b0lo, t);
/* 1373 */     double uj = t.x;
/* 1374 */     double u0 = t.y;
/* 1375 */     twoSum(ui, u0, t);
/* 1376 */     double uk = t.x;
/* 1377 */     double u1 = t.y;
/* 1378 */     twoSumFast(uj, uk, t);
/* 1379 */     double ul = t.x;
/* 1380 */     double u2 = t.y;
/* 1381 */     split(b1, t);
/* 1382 */     double b1hi = t.x;
/* 1383 */     double b1lo = t.y;
/* 1384 */     twoProduct2Presplit(a0, a0hi, a0lo, b1, b1hi, b1lo, t);
/* 1385 */     ui = t.x;
/* 1386 */     u0 = t.y;
/* 1387 */     twoSum(u1, u0, t);
/* 1388 */     uk = t.x;
/* 1389 */     x[1] = t.y;
/* 1390 */     twoSum(u2, uk, t);
/* 1391 */     uj = t.x;
/* 1392 */     u1 = t.y;
/* 1393 */     twoSum(ul, uj, t);
/* 1394 */     double um = t.x;
/* 1395 */     u2 = t.y;
/* 1396 */     twoProduct2Presplit(a1, a1hi, a1lo, b1, b1hi, b1lo, t);
/* 1397 */     uj = t.x;
/* 1398 */     u0 = t.y;
/* 1399 */     twoSum(ui, u0, t);
/* 1400 */     double un = t.x;
/* 1401 */     u0 = t.y;
/* 1402 */     twoSum(u1, u0, t);
/* 1403 */     ui = t.x;
/* 1404 */     x[2] = t.y;
/* 1405 */     twoSum(u2, ui, t);
/* 1406 */     uk = t.x;
/* 1407 */     u1 = t.y;
/* 1408 */     twoSum(um, uk, t);
/* 1409 */     ul = t.x;
/* 1410 */     u2 = t.y;
/* 1411 */     twoSum(uj, un, t);
/* 1412 */     uk = t.x;
/* 1413 */     u0 = t.y;
/* 1414 */     twoSum(u1, u0, t);
/* 1415 */     uj = t.x;
/* 1416 */     x[3] = t.y;
/* 1417 */     twoSum(u2, uj, t);
/* 1418 */     ui = t.x;
/* 1419 */     u1 = t.y;
/* 1420 */     twoSum(ul, ui, t);
/* 1421 */     um = t.x;
/* 1422 */     u2 = t.y;
/* 1423 */     twoSum(u1, uk, t);
/* 1424 */     ui = t.x;
/* 1425 */     x[4] = t.y;
/* 1426 */     twoSum(u2, ui, t);
/* 1427 */     uk = t.x;
/* 1428 */     x[5] = t.y;
/* 1429 */     twoSum(um, uk, t);
/* 1430 */     x[7] = t.x;
/* 1431 */     x[6] = t.y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int expansionSumZeroElimFast(int elen, double[] e, int flen, double[] f, double[] h) {
/*      */     double q;
/* 1446 */     Two t = new Two();
/* 1447 */     double enow = e[0];
/* 1448 */     double fnow = f[0];
/* 1449 */     int eindex = 0;
/* 1450 */     int findex = 0;
/* 1451 */     if (((fnow > enow) ? true : false) == ((fnow > -enow) ? true : false)) {
/* 1452 */       q = enow;
/* 1453 */       eindex++;
/* 1454 */       if (eindex < elen)
/* 1455 */         enow = e[eindex]; 
/*      */     } else {
/* 1457 */       q = fnow;
/* 1458 */       findex++;
/* 1459 */       if (findex < flen)
/* 1460 */         fnow = f[findex]; 
/*      */     } 
/* 1462 */     int hindex = 0;
/* 1463 */     if (eindex < elen && findex < flen) {
/* 1464 */       double qnew, hh; if (((fnow > enow) ? true : false) == ((fnow > -enow) ? true : false)) {
/* 1465 */         twoSumFast(enow, q, t);
/* 1466 */         qnew = t.x;
/* 1467 */         hh = t.y;
/* 1468 */         eindex++;
/* 1469 */         if (eindex < elen)
/* 1470 */           enow = e[eindex]; 
/*      */       } else {
/* 1472 */         twoSumFast(fnow, q, t);
/* 1473 */         qnew = t.x;
/* 1474 */         hh = t.y;
/* 1475 */         findex++;
/* 1476 */         if (findex < flen)
/* 1477 */           fnow = f[findex]; 
/*      */       } 
/* 1479 */       q = qnew;
/* 1480 */       if (hh != 0.0D)
/* 1481 */         h[hindex++] = hh; 
/* 1482 */       while (eindex < elen && findex < flen) {
/* 1483 */         if (((fnow > enow) ? true : false) == ((fnow > -enow) ? true : false)) {
/* 1484 */           twoSum(q, enow, t);
/* 1485 */           qnew = t.x;
/* 1486 */           hh = t.y;
/* 1487 */           eindex++;
/* 1488 */           if (eindex < elen)
/* 1489 */             enow = e[eindex]; 
/*      */         } else {
/* 1491 */           twoSum(q, fnow, t);
/* 1492 */           qnew = t.x;
/* 1493 */           hh = t.y;
/* 1494 */           findex++;
/* 1495 */           if (findex < flen)
/* 1496 */             fnow = f[findex]; 
/*      */         } 
/* 1498 */         q = qnew;
/* 1499 */         if (hh != 0.0D)
/* 1500 */           h[hindex++] = hh; 
/*      */       } 
/*      */     } 
/* 1503 */     while (eindex < elen) {
/* 1504 */       twoSum(q, enow, t);
/* 1505 */       double qnew = t.x;
/* 1506 */       double hh = t.y;
/* 1507 */       eindex++;
/* 1508 */       if (eindex < elen)
/* 1509 */         enow = e[eindex]; 
/* 1510 */       q = qnew;
/* 1511 */       if (hh != 0.0D)
/* 1512 */         h[hindex++] = hh; 
/*      */     } 
/* 1514 */     while (findex < flen) {
/* 1515 */       twoSum(q, fnow, t);
/* 1516 */       double qnew = t.x;
/* 1517 */       double hh = t.y;
/* 1518 */       findex++;
/* 1519 */       if (findex < flen)
/* 1520 */         fnow = f[findex]; 
/* 1521 */       q = qnew;
/* 1522 */       if (hh != 0.0D)
/* 1523 */         h[hindex++] = hh; 
/*      */     } 
/* 1525 */     if (q != 0.0D || hindex == 0)
/* 1526 */       h[hindex++] = q; 
/* 1527 */     return hindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int scaleExpansionZeroElim(int elen, double[] e, double b, double[] h) {
/* 1541 */     Two t = new Two();
/* 1542 */     split(b, t);
/* 1543 */     double bhi = t.x;
/* 1544 */     double blo = t.y;
/* 1545 */     twoProduct1Presplit(e[0], b, bhi, blo, t);
/* 1546 */     double q = t.x;
/* 1547 */     double hh = t.y;
/* 1548 */     int hindex = 0;
/* 1549 */     if (hh != 0.0D)
/* 1550 */       h[hindex++] = hh; 
/* 1551 */     for (int eindex = 1; eindex < elen; eindex++) {
/* 1552 */       double enow = e[eindex];
/* 1553 */       twoProduct1Presplit(enow, b, bhi, blo, t);
/* 1554 */       double product1 = t.x;
/* 1555 */       double product0 = t.y;
/* 1556 */       twoSum(q, product0, t);
/* 1557 */       double sum = t.x;
/* 1558 */       hh = t.y;
/* 1559 */       if (hh != 0.0D)
/* 1560 */         h[hindex++] = hh; 
/* 1561 */       twoSumFast(product1, sum, t);
/* 1562 */       q = t.x;
/* 1563 */       hh = t.y;
/* 1564 */       if (hh != 0.0D)
/* 1565 */         h[hindex++] = hh; 
/*      */     } 
/* 1567 */     if (q != 0.0D || hindex == 0)
/* 1568 */       h[hindex++] = q; 
/* 1569 */     return hindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double leftOfLineExact(double xa, double ya, double xb, double yb, double xc, double yc) {
/* 1585 */     Two t = new Two();
/* 1586 */     twoDiff(xa, xc, t);
/* 1587 */     double acx = t.x;
/* 1588 */     double acxtail = t.y;
/* 1589 */     twoDiff(ya, yc, t);
/* 1590 */     double acy = t.x;
/* 1591 */     double acytail = t.y;
/* 1592 */     twoDiff(xb, xc, t);
/* 1593 */     double bcx = t.x;
/* 1594 */     double bcxtail = t.y;
/* 1595 */     twoDiff(yb, yc, t);
/* 1596 */     double bcy = t.x;
/* 1597 */     double bcytail = t.y;
/*      */     
/* 1599 */     double[] axby = new double[8];
/* 1600 */     double[] bxay = new double[8];
/* 1601 */     twoTwoProduct(acx, acxtail, bcy, bcytail, axby);
/* 1602 */     double negate = -acy;
/* 1603 */     double negatetail = -acytail;
/* 1604 */     twoTwoProduct(bcx, bcxtail, negate, negatetail, bxay);
/*      */     
/* 1606 */     double[] det = new double[16];
/* 1607 */     int detlen = expansionSumZeroElimFast(8, axby, 8, bxay, det);
/*      */     
/* 1609 */     return det[detlen - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double leftOfPlaneExact(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd) {
/* 1627 */     Two t = new Two();
/* 1628 */     twoDiff(xa, xd, t);
/* 1629 */     double adx = t.x;
/* 1630 */     double adxtail = t.y;
/* 1631 */     twoDiff(ya, yd, t);
/* 1632 */     double ady = t.x;
/* 1633 */     double adytail = t.y;
/* 1634 */     twoDiff(za, zd, t);
/* 1635 */     double adz = t.x;
/* 1636 */     double adztail = t.y;
/* 1637 */     twoDiff(xb, xd, t);
/* 1638 */     double bdx = t.x;
/* 1639 */     double bdxtail = t.y;
/* 1640 */     twoDiff(yb, yd, t);
/* 1641 */     double bdy = t.x;
/* 1642 */     double bdytail = t.y;
/* 1643 */     twoDiff(zb, zd, t);
/* 1644 */     double bdz = t.x;
/* 1645 */     double bdztail = t.y;
/* 1646 */     twoDiff(xc, xd, t);
/* 1647 */     double cdx = t.x;
/* 1648 */     double cdxtail = t.y;
/* 1649 */     twoDiff(yc, yd, t);
/* 1650 */     double cdy = t.x;
/* 1651 */     double cdytail = t.y;
/* 1652 */     twoDiff(zc, zd, t);
/* 1653 */     double cdz = t.x;
/* 1654 */     double cdztail = t.y;
/*      */     
/* 1656 */     double[] axby = new double[8];
/* 1657 */     twoTwoProduct(adx, adxtail, bdy, bdytail, axby);
/* 1658 */     double negate = -ady;
/* 1659 */     double negatetail = -adytail;
/* 1660 */     double[] bxay = new double[8];
/* 1661 */     twoTwoProduct(bdx, bdxtail, negate, negatetail, bxay);
/*      */     
/* 1663 */     double[] bxcy = new double[8];
/* 1664 */     twoTwoProduct(bdx, bdxtail, cdy, cdytail, bxcy);
/* 1665 */     negate = -bdy;
/* 1666 */     negatetail = -bdytail;
/* 1667 */     double[] cxby = new double[8];
/* 1668 */     twoTwoProduct(cdx, cdxtail, negate, negatetail, cxby);
/*      */     
/* 1670 */     double[] cxay = new double[8];
/* 1671 */     twoTwoProduct(cdx, cdxtail, ady, adytail, cxay);
/* 1672 */     negate = -cdy;
/* 1673 */     negatetail = -cdytail;
/* 1674 */     double[] axcy = new double[8];
/* 1675 */     twoTwoProduct(adx, adxtail, negate, negatetail, axcy);
/*      */     
/* 1677 */     double[] t16 = new double[16];
/* 1678 */     double[] t32 = new double[32];
/* 1679 */     double[] t32t = new double[32];
/*      */ 
/*      */     
/* 1682 */     int t16len = expansionSumZeroElimFast(8, bxcy, 8, cxby, t16);
/* 1683 */     int t32len = scaleExpansionZeroElim(t16len, t16, adz, t32);
/* 1684 */     int t32tlen = scaleExpansionZeroElim(t16len, t16, adztail, t32t);
/* 1685 */     double[] adet = new double[64];
/* 1686 */     int alen = expansionSumZeroElimFast(t32len, t32, t32tlen, t32t, adet);
/*      */     
/* 1688 */     t16len = expansionSumZeroElimFast(8, cxay, 8, axcy, t16);
/* 1689 */     t32len = scaleExpansionZeroElim(t16len, t16, bdz, t32);
/* 1690 */     t32tlen = scaleExpansionZeroElim(t16len, t16, bdztail, t32t);
/* 1691 */     double[] bdet = new double[64];
/* 1692 */     int blen = expansionSumZeroElimFast(t32len, t32, t32tlen, t32t, bdet);
/*      */     
/* 1694 */     t16len = expansionSumZeroElimFast(8, axby, 8, bxay, t16);
/* 1695 */     t32len = scaleExpansionZeroElim(t16len, t16, cdz, t32);
/* 1696 */     t32tlen = scaleExpansionZeroElim(t16len, t16, cdztail, t32t);
/* 1697 */     double[] cdet = new double[64];
/* 1698 */     int clen = expansionSumZeroElimFast(t32len, t32, t32tlen, t32t, cdet);
/*      */     
/* 1700 */     double[] abdet = new double[128];
/* 1701 */     int ablen = expansionSumZeroElimFast(alen, adet, blen, bdet, abdet);
/* 1702 */     double[] det = new double[192];
/* 1703 */     int detlen = expansionSumZeroElimFast(ablen, abdet, clen, cdet, det);
/*      */     
/* 1705 */     return det[detlen - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double inCircleExact(double xa, double ya, double xb, double yb, double xc, double yc, double xd, double yd) {
/* 1722 */     Two t = new Two();
/* 1723 */     twoDiff(xa, xd, t);
/* 1724 */     double adx = t.x;
/* 1725 */     double adxtail = t.y;
/* 1726 */     twoDiff(ya, yd, t);
/* 1727 */     double ady = t.x;
/* 1728 */     double adytail = t.y;
/* 1729 */     twoDiff(xb, xd, t);
/* 1730 */     double bdx = t.x;
/* 1731 */     double bdxtail = t.y;
/* 1732 */     twoDiff(yb, yd, t);
/* 1733 */     double bdy = t.x;
/* 1734 */     double bdytail = t.y;
/* 1735 */     twoDiff(xc, xd, t);
/* 1736 */     double cdx = t.x;
/* 1737 */     double cdxtail = t.y;
/* 1738 */     twoDiff(yc, yd, t);
/* 1739 */     double cdy = t.x;
/* 1740 */     double cdytail = t.y;
/*      */     
/* 1742 */     double[] axby = new double[8];
/* 1743 */     double[] bxay = new double[8];
/* 1744 */     twoTwoProduct(adx, adxtail, bdy, bdytail, axby);
/* 1745 */     double negate = -ady;
/* 1746 */     double negatetail = -adytail;
/* 1747 */     twoTwoProduct(bdx, bdxtail, negate, negatetail, bxay);
/*      */     
/* 1749 */     double[] bxcy = new double[8];
/* 1750 */     double[] cxby = new double[8];
/* 1751 */     twoTwoProduct(bdx, bdxtail, cdy, cdytail, bxcy);
/* 1752 */     negate = -bdy;
/* 1753 */     negatetail = -bdytail;
/* 1754 */     twoTwoProduct(cdx, cdxtail, negate, negatetail, cxby);
/*      */     
/* 1756 */     double[] cxay = new double[8];
/* 1757 */     double[] axcy = new double[8];
/* 1758 */     twoTwoProduct(cdx, cdxtail, ady, adytail, cxay);
/* 1759 */     negate = -cdy;
/* 1760 */     negatetail = -cdytail;
/* 1761 */     twoTwoProduct(adx, adxtail, negate, negatetail, axcy);
/*      */     
/* 1763 */     double[] t16 = new double[16];
/* 1764 */     int t16len = expansionSumZeroElimFast(8, bxcy, 8, cxby, t16);
/*      */     
/* 1766 */     double[] detx = new double[32];
/* 1767 */     double[] detxx = new double[64];
/* 1768 */     double[] detxt = new double[32];
/* 1769 */     double[] detxxt = new double[64];
/* 1770 */     double[] detxtxt = new double[64];
/* 1771 */     double[] x1 = new double[128];
/* 1772 */     double[] x2 = new double[192];
/* 1773 */     int xlen = scaleExpansionZeroElim(t16len, t16, adx, detx);
/* 1774 */     int xxlen = scaleExpansionZeroElim(xlen, detx, adx, detxx);
/* 1775 */     int xtlen = scaleExpansionZeroElim(t16len, t16, adxtail, detxt);
/* 1776 */     int xxtlen = scaleExpansionZeroElim(xtlen, detxt, adx, detxxt);
/* 1777 */     for (int i = 0; i < xxtlen; i++)
/* 1778 */       detxxt[i] = detxxt[i] * 2.0D; 
/* 1779 */     int xtxtlen = scaleExpansionZeroElim(xtlen, detxt, adxtail, detxtxt);
/* 1780 */     int x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 1781 */     int x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/*      */     
/* 1783 */     double[] dety = new double[32];
/* 1784 */     double[] detyy = new double[64];
/* 1785 */     double[] detyt = new double[32];
/* 1786 */     double[] detyyt = new double[64];
/* 1787 */     double[] detytyt = new double[64];
/* 1788 */     double[] y1 = new double[128];
/* 1789 */     double[] y2 = new double[192];
/* 1790 */     int ylen = scaleExpansionZeroElim(t16len, t16, ady, dety);
/* 1791 */     int yylen = scaleExpansionZeroElim(ylen, dety, ady, detyy);
/* 1792 */     int ytlen = scaleExpansionZeroElim(t16len, t16, adytail, detyt);
/* 1793 */     int yytlen = scaleExpansionZeroElim(ytlen, detyt, ady, detyyt);
/* 1794 */     for (int j = 0; j < yytlen; j++)
/* 1795 */       detyyt[j] = detyyt[j] * 2.0D; 
/* 1796 */     int ytytlen = scaleExpansionZeroElim(ytlen, detyt, adytail, detytyt);
/* 1797 */     int y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 1798 */     int y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/*      */     
/* 1800 */     double[] adet = new double[384];
/* 1801 */     double[] bdet = new double[384];
/* 1802 */     double[] cdet = new double[384];
/* 1803 */     int alen = expansionSumZeroElimFast(x2len, x2, y2len, y2, adet);
/*      */     
/* 1805 */     t16len = expansionSumZeroElimFast(8, cxay, 8, axcy, t16);
/* 1806 */     xlen = scaleExpansionZeroElim(t16len, t16, bdx, detx);
/* 1807 */     xxlen = scaleExpansionZeroElim(xlen, detx, bdx, detxx);
/* 1808 */     xtlen = scaleExpansionZeroElim(t16len, t16, bdxtail, detxt);
/* 1809 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, bdx, detxxt); int k;
/* 1810 */     for (k = 0; k < xxtlen; k++)
/* 1811 */       detxxt[k] = detxxt[k] * 2.0D; 
/* 1812 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, bdxtail, detxtxt);
/* 1813 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 1814 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/*      */     
/* 1816 */     ylen = scaleExpansionZeroElim(t16len, t16, bdy, dety);
/* 1817 */     yylen = scaleExpansionZeroElim(ylen, dety, bdy, detyy);
/* 1818 */     ytlen = scaleExpansionZeroElim(t16len, t16, bdytail, detyt);
/* 1819 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, bdy, detyyt);
/* 1820 */     for (k = 0; k < yytlen; k++)
/* 1821 */       detyyt[k] = detyyt[k] * 2.0D; 
/* 1822 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, bdytail, detytyt);
/* 1823 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 1824 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 1825 */     int blen = expansionSumZeroElimFast(x2len, x2, y2len, y2, bdet);
/*      */     
/* 1827 */     t16len = expansionSumZeroElimFast(8, axby, 8, bxay, t16);
/* 1828 */     xlen = scaleExpansionZeroElim(t16len, t16, cdx, detx);
/* 1829 */     xxlen = scaleExpansionZeroElim(xlen, detx, cdx, detxx);
/* 1830 */     xtlen = scaleExpansionZeroElim(t16len, t16, cdxtail, detxt);
/* 1831 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, cdx, detxxt); int m;
/* 1832 */     for (m = 0; m < xxtlen; m++)
/* 1833 */       detxxt[m] = detxxt[m] * 2.0D; 
/* 1834 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, cdxtail, detxtxt);
/* 1835 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 1836 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 1837 */     ylen = scaleExpansionZeroElim(t16len, t16, cdy, dety);
/* 1838 */     yylen = scaleExpansionZeroElim(ylen, dety, cdy, detyy);
/* 1839 */     ytlen = scaleExpansionZeroElim(t16len, t16, cdytail, detyt);
/* 1840 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, cdy, detyyt);
/* 1841 */     for (m = 0; m < yytlen; m++)
/* 1842 */       detyyt[m] = detyyt[m] * 2.0D; 
/* 1843 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, cdytail, detytyt);
/* 1844 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 1845 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 1846 */     int clen = expansionSumZeroElimFast(x2len, x2, y2len, y2, cdet);
/*      */     
/* 1848 */     double[] abdet = new double[768];
/* 1849 */     double[] det = new double[1152];
/* 1850 */     int ablen = expansionSumZeroElimFast(alen, adet, blen, bdet, abdet);
/* 1851 */     int detlen = expansionSumZeroElimFast(ablen, abdet, clen, cdet, det);
/*      */     
/* 1853 */     return det[detlen - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double inSphereExact(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc, double xd, double yd, double zd, double xe, double ye, double ze) {
/* 1872 */     Two t = new Two();
/* 1873 */     twoDiff(xa, xe, t);
/* 1874 */     double aex = t.x;
/* 1875 */     double aextail = t.y;
/* 1876 */     twoDiff(ya, ye, t);
/* 1877 */     double aey = t.x;
/* 1878 */     double aeytail = t.y;
/* 1879 */     twoDiff(za, ze, t);
/* 1880 */     double aez = t.x;
/* 1881 */     double aeztail = t.y;
/* 1882 */     twoDiff(xb, xe, t);
/* 1883 */     double bex = t.x;
/* 1884 */     double bextail = t.y;
/* 1885 */     twoDiff(yb, ye, t);
/* 1886 */     double bey = t.x;
/* 1887 */     double beytail = t.y;
/* 1888 */     twoDiff(zb, ze, t);
/* 1889 */     double bez = t.x;
/* 1890 */     double beztail = t.y;
/* 1891 */     twoDiff(xc, xe, t);
/* 1892 */     double cex = t.x;
/* 1893 */     double cextail = t.y;
/* 1894 */     twoDiff(yc, ye, t);
/* 1895 */     double cey = t.x;
/* 1896 */     double ceytail = t.y;
/* 1897 */     twoDiff(zc, ze, t);
/* 1898 */     double cez = t.x;
/* 1899 */     double ceztail = t.y;
/* 1900 */     twoDiff(xd, xe, t);
/* 1901 */     double dex = t.x;
/* 1902 */     double dextail = t.y;
/* 1903 */     twoDiff(yd, ye, t);
/* 1904 */     double dey = t.x;
/* 1905 */     double deytail = t.y;
/* 1906 */     twoDiff(zd, ze, t);
/* 1907 */     double dez = t.x;
/* 1908 */     double deztail = t.y;
/*      */     
/* 1910 */     double[] axby = new double[8];
/* 1911 */     double[] bxay = new double[8];
/* 1912 */     double[] ab = new double[16];
/* 1913 */     twoTwoProduct(aex, aextail, bey, beytail, axby);
/* 1914 */     double negate = -aey;
/* 1915 */     double negatetail = -aeytail;
/* 1916 */     twoTwoProduct(bex, bextail, negate, negatetail, bxay);
/* 1917 */     int ablen = expansionSumZeroElimFast(8, axby, 8, bxay, ab);
/*      */     
/* 1919 */     double[] bxcy = new double[8];
/* 1920 */     double[] cxby = new double[8];
/* 1921 */     double[] bc = new double[16];
/* 1922 */     twoTwoProduct(bex, bextail, cey, ceytail, bxcy);
/* 1923 */     negate = -bey;
/* 1924 */     negatetail = -beytail;
/* 1925 */     twoTwoProduct(cex, cextail, negate, negatetail, cxby);
/* 1926 */     int bclen = expansionSumZeroElimFast(8, bxcy, 8, cxby, bc);
/*      */     
/* 1928 */     double[] cxdy = new double[8];
/* 1929 */     double[] dxcy = new double[8];
/* 1930 */     double[] cd = new double[16];
/* 1931 */     twoTwoProduct(cex, cextail, dey, deytail, cxdy);
/* 1932 */     negate = -cey;
/* 1933 */     negatetail = -ceytail;
/* 1934 */     twoTwoProduct(dex, dextail, negate, negatetail, dxcy);
/* 1935 */     int cdlen = expansionSumZeroElimFast(8, cxdy, 8, dxcy, cd);
/*      */     
/* 1937 */     double[] dxay = new double[8];
/* 1938 */     double[] axdy = new double[8];
/* 1939 */     double[] da = new double[16];
/* 1940 */     twoTwoProduct(dex, dextail, aey, aeytail, dxay);
/* 1941 */     negate = -dey;
/* 1942 */     negatetail = -deytail;
/* 1943 */     twoTwoProduct(aex, aextail, negate, negatetail, axdy);
/* 1944 */     int dalen = expansionSumZeroElimFast(8, dxay, 8, axdy, da);
/*      */     
/* 1946 */     double[] axcy = new double[8];
/* 1947 */     double[] cxay = new double[8];
/* 1948 */     double[] ac = new double[16];
/* 1949 */     twoTwoProduct(aex, aextail, cey, ceytail, axcy);
/* 1950 */     negate = -aey;
/* 1951 */     negatetail = -aeytail;
/* 1952 */     twoTwoProduct(cex, cextail, negate, negatetail, cxay);
/* 1953 */     int aclen = expansionSumZeroElimFast(8, axcy, 8, cxay, ac);
/*      */     
/* 1955 */     double[] bxdy = new double[8];
/* 1956 */     double[] dxby = new double[8];
/* 1957 */     double[] bd = new double[16];
/* 1958 */     twoTwoProduct(bex, bextail, dey, deytail, bxdy);
/* 1959 */     negate = -bey;
/* 1960 */     negatetail = -beytail;
/* 1961 */     twoTwoProduct(dex, dextail, negate, negatetail, dxby);
/* 1962 */     int bdlen = expansionSumZeroElimFast(8, bxdy, 8, dxby, bd);
/*      */     
/* 1964 */     double[] t32a = new double[32];
/* 1965 */     double[] t32b = new double[32];
/* 1966 */     double[] t64a = new double[64];
/* 1967 */     double[] t64b = new double[64];
/* 1968 */     double[] t64c = new double[64];
/* 1969 */     double[] t128 = new double[128];
/* 1970 */     double[] t192 = new double[192];
/*      */     
/* 1972 */     int t32alen = scaleExpansionZeroElim(cdlen, cd, -bez, t32a);
/* 1973 */     int t32blen = scaleExpansionZeroElim(cdlen, cd, -beztail, t32b);
/* 1974 */     int t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 1975 */     t32alen = scaleExpansionZeroElim(bdlen, bd, cez, t32a);
/* 1976 */     t32blen = scaleExpansionZeroElim(bdlen, bd, ceztail, t32b);
/* 1977 */     int t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 1978 */     t32alen = scaleExpansionZeroElim(bclen, bc, -dez, t32a);
/* 1979 */     t32blen = scaleExpansionZeroElim(bclen, bc, -deztail, t32b);
/* 1980 */     int t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 1981 */     int t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 1982 */     int t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/*      */     
/* 1984 */     double[] detx = new double[384];
/* 1985 */     double[] detxx = new double[768];
/* 1986 */     double[] detxt = new double[384];
/* 1987 */     double[] detxxt = new double[768];
/* 1988 */     double[] detxtxt = new double[768];
/* 1989 */     double[] x1 = new double[1536];
/* 1990 */     double[] x2 = new double[2304];
/* 1991 */     int xlen = scaleExpansionZeroElim(t192len, t192, aex, detx);
/* 1992 */     int xxlen = scaleExpansionZeroElim(xlen, detx, aex, detxx);
/* 1993 */     int xtlen = scaleExpansionZeroElim(t192len, t192, aextail, detxt);
/* 1994 */     int xxtlen = scaleExpansionZeroElim(xtlen, detxt, aex, detxxt);
/* 1995 */     for (int i = 0; i < xxtlen; i++)
/* 1996 */       detxxt[i] = detxxt[i] * 2.0D; 
/* 1997 */     int xtxtlen = scaleExpansionZeroElim(xtlen, detxt, aextail, detxtxt);
/* 1998 */     int x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 1999 */     int x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/*      */     
/* 2001 */     double[] dety = new double[384];
/* 2002 */     double[] detyy = new double[768];
/* 2003 */     double[] detyt = new double[384];
/* 2004 */     double[] detyyt = new double[768];
/* 2005 */     double[] detytyt = new double[768];
/* 2006 */     double[] y1 = new double[1536];
/* 2007 */     double[] y2 = new double[2304];
/* 2008 */     int ylen = scaleExpansionZeroElim(t192len, t192, aey, dety);
/* 2009 */     int yylen = scaleExpansionZeroElim(ylen, dety, aey, detyy);
/* 2010 */     int ytlen = scaleExpansionZeroElim(t192len, t192, aeytail, detyt);
/* 2011 */     int yytlen = scaleExpansionZeroElim(ytlen, detyt, aey, detyyt);
/* 2012 */     for (int j = 0; j < yytlen; j++)
/* 2013 */       detyyt[j] = detyyt[j] * 2.0D; 
/* 2014 */     int ytytlen = scaleExpansionZeroElim(ytlen, detyt, aeytail, detytyt);
/* 2015 */     int y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2016 */     int y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/*      */     
/* 2018 */     double[] detz = new double[384];
/* 2019 */     double[] detzz = new double[768];
/* 2020 */     double[] detzt = new double[384];
/* 2021 */     double[] detzzt = new double[768];
/* 2022 */     double[] detztzt = new double[768];
/* 2023 */     double[] z1 = new double[1536];
/* 2024 */     double[] z2 = new double[2304];
/* 2025 */     int zlen = scaleExpansionZeroElim(t192len, t192, aez, detz);
/* 2026 */     int zzlen = scaleExpansionZeroElim(zlen, detz, aez, detzz);
/* 2027 */     int ztlen = scaleExpansionZeroElim(t192len, t192, aeztail, detzt);
/* 2028 */     int zztlen = scaleExpansionZeroElim(ztlen, detzt, aez, detzzt);
/* 2029 */     for (int k = 0; k < zztlen; k++)
/* 2030 */       detzzt[k] = detzzt[k] * 2.0D; 
/* 2031 */     int ztztlen = scaleExpansionZeroElim(ztlen, detzt, aeztail, detztzt);
/* 2032 */     int z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2033 */     int z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/*      */     
/* 2035 */     double[] detxy = new double[4608];
/* 2036 */     double[] adet = new double[6912];
/* 2037 */     double[] bdet = new double[6912];
/* 2038 */     double[] cdet = new double[6912];
/* 2039 */     double[] ddet = new double[6912];
/* 2040 */     int xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2041 */     int alen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, adet);
/*      */     
/* 2043 */     t32alen = scaleExpansionZeroElim(dalen, da, cez, t32a);
/* 2044 */     t32blen = scaleExpansionZeroElim(dalen, da, ceztail, t32b);
/* 2045 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2046 */     t32alen = scaleExpansionZeroElim(aclen, ac, dez, t32a);
/* 2047 */     t32blen = scaleExpansionZeroElim(aclen, ac, deztail, t32b);
/* 2048 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2049 */     t32alen = scaleExpansionZeroElim(cdlen, cd, aez, t32a);
/* 2050 */     t32blen = scaleExpansionZeroElim(cdlen, cd, aeztail, t32b);
/* 2051 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2052 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2053 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2054 */     xlen = scaleExpansionZeroElim(t192len, t192, bex, detx);
/* 2055 */     xxlen = scaleExpansionZeroElim(xlen, detx, bex, detxx);
/* 2056 */     xtlen = scaleExpansionZeroElim(t192len, t192, bextail, detxt);
/* 2057 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, bex, detxxt); int m;
/* 2058 */     for (m = 0; m < xxtlen; m++)
/* 2059 */       detxxt[m] = detxxt[m] * 2.0D; 
/* 2060 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, bextail, detxtxt);
/* 2061 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2062 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2063 */     ylen = scaleExpansionZeroElim(t192len, t192, bey, dety);
/* 2064 */     yylen = scaleExpansionZeroElim(ylen, dety, bey, detyy);
/* 2065 */     ytlen = scaleExpansionZeroElim(t192len, t192, beytail, detyt);
/* 2066 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, bey, detyyt);
/* 2067 */     for (m = 0; m < yytlen; m++)
/* 2068 */       detyyt[m] = detyyt[m] * 2.0D; 
/* 2069 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, beytail, detytyt);
/* 2070 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2071 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2072 */     zlen = scaleExpansionZeroElim(t192len, t192, bez, detz);
/* 2073 */     zzlen = scaleExpansionZeroElim(zlen, detz, bez, detzz);
/* 2074 */     ztlen = scaleExpansionZeroElim(t192len, t192, beztail, detzt);
/* 2075 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, bez, detzzt);
/* 2076 */     for (m = 0; m < zztlen; m++)
/* 2077 */       detzzt[m] = detzzt[m] * 2.0D; 
/* 2078 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, beztail, detztzt);
/* 2079 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2080 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2081 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2082 */     int blen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, bdet);
/*      */     
/* 2084 */     t32alen = scaleExpansionZeroElim(ablen, ab, -dez, t32a);
/* 2085 */     t32blen = scaleExpansionZeroElim(ablen, ab, -deztail, t32b);
/* 2086 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2087 */     t32alen = scaleExpansionZeroElim(bdlen, bd, -aez, t32a);
/* 2088 */     t32blen = scaleExpansionZeroElim(bdlen, bd, -aeztail, t32b);
/* 2089 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2090 */     t32alen = scaleExpansionZeroElim(dalen, da, -bez, t32a);
/* 2091 */     t32blen = scaleExpansionZeroElim(dalen, da, -beztail, t32b);
/* 2092 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2093 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2094 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2095 */     xlen = scaleExpansionZeroElim(t192len, t192, cex, detx);
/* 2096 */     xxlen = scaleExpansionZeroElim(xlen, detx, cex, detxx);
/* 2097 */     xtlen = scaleExpansionZeroElim(t192len, t192, cextail, detxt);
/* 2098 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, cex, detxxt); int n;
/* 2099 */     for (n = 0; n < xxtlen; n++)
/* 2100 */       detxxt[n] = detxxt[n] * 2.0D; 
/* 2101 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, cextail, detxtxt);
/* 2102 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2103 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2104 */     ylen = scaleExpansionZeroElim(t192len, t192, cey, dety);
/* 2105 */     yylen = scaleExpansionZeroElim(ylen, dety, cey, detyy);
/* 2106 */     ytlen = scaleExpansionZeroElim(t192len, t192, ceytail, detyt);
/* 2107 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, cey, detyyt);
/* 2108 */     for (n = 0; n < yytlen; n++)
/* 2109 */       detyyt[n] = detyyt[n] * 2.0D; 
/* 2110 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, ceytail, detytyt);
/* 2111 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2112 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2113 */     zlen = scaleExpansionZeroElim(t192len, t192, cez, detz);
/* 2114 */     zzlen = scaleExpansionZeroElim(zlen, detz, cez, detzz);
/* 2115 */     ztlen = scaleExpansionZeroElim(t192len, t192, ceztail, detzt);
/* 2116 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, cez, detzzt);
/* 2117 */     for (n = 0; n < zztlen; n++)
/* 2118 */       detzzt[n] = detzzt[n] * 2.0D; 
/* 2119 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, ceztail, detztzt);
/* 2120 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2121 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2122 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2123 */     int clen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, cdet);
/*      */     
/* 2125 */     t32alen = scaleExpansionZeroElim(bclen, bc, aez, t32a);
/* 2126 */     t32blen = scaleExpansionZeroElim(bclen, bc, aeztail, t32b);
/* 2127 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2128 */     t32alen = scaleExpansionZeroElim(aclen, ac, -bez, t32a);
/* 2129 */     t32blen = scaleExpansionZeroElim(aclen, ac, -beztail, t32b);
/* 2130 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2131 */     t32alen = scaleExpansionZeroElim(ablen, ab, cez, t32a);
/* 2132 */     t32blen = scaleExpansionZeroElim(ablen, ab, ceztail, t32b);
/* 2133 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2134 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2135 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2136 */     xlen = scaleExpansionZeroElim(t192len, t192, dex, detx);
/* 2137 */     xxlen = scaleExpansionZeroElim(xlen, detx, dex, detxx);
/* 2138 */     xtlen = scaleExpansionZeroElim(t192len, t192, dextail, detxt);
/* 2139 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, dex, detxxt); int i1;
/* 2140 */     for (i1 = 0; i1 < xxtlen; i1++)
/* 2141 */       detxxt[i1] = detxxt[i1] * 2.0D; 
/* 2142 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, dextail, detxtxt);
/* 2143 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2144 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2145 */     ylen = scaleExpansionZeroElim(t192len, t192, dey, dety);
/* 2146 */     yylen = scaleExpansionZeroElim(ylen, dety, dey, detyy);
/* 2147 */     ytlen = scaleExpansionZeroElim(t192len, t192, deytail, detyt);
/* 2148 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, dey, detyyt);
/* 2149 */     for (i1 = 0; i1 < yytlen; i1++)
/* 2150 */       detyyt[i1] = detyyt[i1] * 2.0D; 
/* 2151 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, deytail, detytyt);
/* 2152 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2153 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2154 */     zlen = scaleExpansionZeroElim(t192len, t192, dez, detz);
/* 2155 */     zzlen = scaleExpansionZeroElim(zlen, detz, dez, detzz);
/* 2156 */     ztlen = scaleExpansionZeroElim(t192len, t192, deztail, detzt);
/* 2157 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, dez, detzzt);
/* 2158 */     for (i1 = 0; i1 < zztlen; i1++)
/* 2159 */       detzzt[i1] = detzzt[i1] * 2.0D; 
/* 2160 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, deztail, detztzt);
/* 2161 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2162 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2163 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2164 */     int dlen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, ddet);
/*      */     
/* 2166 */     double[] abdet = new double[13824];
/* 2167 */     double[] cddet = new double[13824];
/* 2168 */     double[] det = new double[27648];
/* 2169 */     ablen = expansionSumZeroElimFast(alen, adet, blen, bdet, abdet);
/* 2170 */     cdlen = expansionSumZeroElimFast(clen, cdet, dlen, ddet, cddet);
/* 2171 */     int detlen = expansionSumZeroElimFast(ablen, abdet, cdlen, cddet, det);
/*      */     
/* 2173 */     return det[detlen - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double inOrthoSphereExact(double xa, double ya, double za, double wa, double xb, double yb, double zb, double wb, double xc, double yc, double zc, double wc, double xd, double yd, double zd, double wd, double xe, double ye, double ze, double we) {
/* 2192 */     Two t = new Two();
/* 2193 */     twoDiff(xa, xe, t);
/* 2194 */     double aex = t.x;
/* 2195 */     double aextail = t.y;
/* 2196 */     twoDiff(ya, ye, t);
/* 2197 */     double aey = t.x;
/* 2198 */     double aeytail = t.y;
/* 2199 */     twoDiff(za, ze, t);
/* 2200 */     double aez = t.x;
/* 2201 */     double aeztail = t.y;
/* 2202 */     twoDiff(wa, we, t);
/*      */ 
/*      */     
/* 2205 */     twoDiff(xb, xe, t);
/* 2206 */     double bex = t.x;
/* 2207 */     double bextail = t.y;
/* 2208 */     twoDiff(yb, ye, t);
/* 2209 */     double bey = t.x;
/* 2210 */     double beytail = t.y;
/* 2211 */     twoDiff(zb, ze, t);
/* 2212 */     double bez = t.x;
/* 2213 */     double beztail = t.y;
/* 2214 */     twoDiff(wb, we, t);
/* 2215 */     double bew = t.x;
/* 2216 */     double bewtail = t.y;
/* 2217 */     twoDiff(xc, xe, t);
/* 2218 */     double cex = t.x;
/* 2219 */     double cextail = t.y;
/* 2220 */     twoDiff(yc, ye, t);
/* 2221 */     double cey = t.x;
/* 2222 */     double ceytail = t.y;
/* 2223 */     twoDiff(zc, ze, t);
/* 2224 */     double cez = t.x;
/* 2225 */     double ceztail = t.y;
/* 2226 */     twoDiff(wc, we, t);
/* 2227 */     double cew = t.x;
/* 2228 */     double cewtail = t.y;
/* 2229 */     twoDiff(xd, xe, t);
/* 2230 */     double dex = t.x;
/* 2231 */     double dextail = t.y;
/* 2232 */     twoDiff(yd, ye, t);
/* 2233 */     double dey = t.x;
/* 2234 */     double deytail = t.y;
/* 2235 */     twoDiff(zd, ze, t);
/* 2236 */     double dez = t.x;
/* 2237 */     double deztail = t.y;
/* 2238 */     twoDiff(wd, we, t);
/* 2239 */     double dew = t.x;
/* 2240 */     double dewtail = t.y;
/*      */     
/* 2242 */     double[] axby = new double[8];
/* 2243 */     double[] bxay = new double[8];
/* 2244 */     double[] ab = new double[16];
/* 2245 */     twoTwoProduct(aex, aextail, bey, beytail, axby);
/* 2246 */     double negate = -aey;
/* 2247 */     double negatetail = -aeytail;
/* 2248 */     twoTwoProduct(bex, bextail, negate, negatetail, bxay);
/* 2249 */     int ablen = expansionSumZeroElimFast(8, axby, 8, bxay, ab);
/*      */     
/* 2251 */     double[] bxcy = new double[8];
/* 2252 */     double[] cxby = new double[8];
/* 2253 */     double[] bc = new double[16];
/* 2254 */     twoTwoProduct(bex, bextail, cey, ceytail, bxcy);
/* 2255 */     negate = -bey;
/* 2256 */     negatetail = -beytail;
/* 2257 */     twoTwoProduct(cex, cextail, negate, negatetail, cxby);
/* 2258 */     int bclen = expansionSumZeroElimFast(8, bxcy, 8, cxby, bc);
/*      */     
/* 2260 */     double[] cxdy = new double[8];
/* 2261 */     double[] dxcy = new double[8];
/* 2262 */     double[] cd = new double[16];
/* 2263 */     twoTwoProduct(cex, cextail, dey, deytail, cxdy);
/* 2264 */     negate = -cey;
/* 2265 */     negatetail = -ceytail;
/* 2266 */     twoTwoProduct(dex, dextail, negate, negatetail, dxcy);
/* 2267 */     int cdlen = expansionSumZeroElimFast(8, cxdy, 8, dxcy, cd);
/*      */     
/* 2269 */     double[] dxay = new double[8];
/* 2270 */     double[] axdy = new double[8];
/* 2271 */     double[] da = new double[16];
/* 2272 */     twoTwoProduct(dex, dextail, aey, aeytail, dxay);
/* 2273 */     negate = -dey;
/* 2274 */     negatetail = -deytail;
/* 2275 */     twoTwoProduct(aex, aextail, negate, negatetail, axdy);
/* 2276 */     int dalen = expansionSumZeroElimFast(8, dxay, 8, axdy, da);
/*      */     
/* 2278 */     double[] axcy = new double[8];
/* 2279 */     double[] cxay = new double[8];
/* 2280 */     double[] ac = new double[16];
/* 2281 */     twoTwoProduct(aex, aextail, cey, ceytail, axcy);
/* 2282 */     negate = -aey;
/* 2283 */     negatetail = -aeytail;
/* 2284 */     twoTwoProduct(cex, cextail, negate, negatetail, cxay);
/* 2285 */     int aclen = expansionSumZeroElimFast(8, axcy, 8, cxay, ac);
/*      */     
/* 2287 */     double[] bxdy = new double[8];
/* 2288 */     double[] dxby = new double[8];
/* 2289 */     double[] bd = new double[16];
/* 2290 */     twoTwoProduct(bex, bextail, dey, deytail, bxdy);
/* 2291 */     negate = -bey;
/* 2292 */     negatetail = -beytail;
/* 2293 */     twoTwoProduct(dex, dextail, negate, negatetail, dxby);
/* 2294 */     int bdlen = expansionSumZeroElimFast(8, bxdy, 8, dxby, bd);
/*      */     
/* 2296 */     double[] t32a = new double[32];
/* 2297 */     double[] t32b = new double[32];
/* 2298 */     double[] t64a = new double[64];
/* 2299 */     double[] t64b = new double[64];
/* 2300 */     double[] t64c = new double[64];
/* 2301 */     double[] t128 = new double[128];
/* 2302 */     double[] t192 = new double[192];
/*      */     
/* 2304 */     int t32alen = scaleExpansionZeroElim(cdlen, cd, -bez, t32a);
/* 2305 */     int t32blen = scaleExpansionZeroElim(cdlen, cd, -beztail, t32b);
/* 2306 */     int t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2307 */     t32alen = scaleExpansionZeroElim(bdlen, bd, cez, t32a);
/* 2308 */     t32blen = scaleExpansionZeroElim(bdlen, bd, ceztail, t32b);
/* 2309 */     int t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2310 */     t32alen = scaleExpansionZeroElim(bclen, bc, -dez, t32a);
/* 2311 */     t32blen = scaleExpansionZeroElim(bclen, bc, -deztail, t32b);
/* 2312 */     int t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2313 */     int t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2314 */     int t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/*      */     
/* 2316 */     double[] detx = new double[384];
/* 2317 */     double[] detxx = new double[768];
/* 2318 */     double[] detxt = new double[384];
/* 2319 */     double[] detxxt = new double[768];
/* 2320 */     double[] detxtxt = new double[768];
/* 2321 */     double[] x1 = new double[1536];
/* 2322 */     double[] x2 = new double[2304];
/* 2323 */     int xlen = scaleExpansionZeroElim(t192len, t192, aex, detx);
/* 2324 */     int xxlen = scaleExpansionZeroElim(xlen, detx, aex, detxx);
/* 2325 */     int xtlen = scaleExpansionZeroElim(t192len, t192, aextail, detxt);
/* 2326 */     int xxtlen = scaleExpansionZeroElim(xtlen, detxt, aex, detxxt);
/* 2327 */     for (int i = 0; i < xxtlen; i++)
/* 2328 */       detxxt[i] = detxxt[i] * 2.0D; 
/* 2329 */     int xtxtlen = scaleExpansionZeroElim(xtlen, detxt, aextail, detxtxt);
/* 2330 */     int x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2331 */     int x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/*      */     
/* 2333 */     double[] dety = new double[384];
/* 2334 */     double[] detyy = new double[768];
/* 2335 */     double[] detyt = new double[384];
/* 2336 */     double[] detyyt = new double[768];
/* 2337 */     double[] detytyt = new double[768];
/* 2338 */     double[] y1 = new double[1536];
/* 2339 */     double[] y2 = new double[2304];
/* 2340 */     int ylen = scaleExpansionZeroElim(t192len, t192, aey, dety);
/* 2341 */     int yylen = scaleExpansionZeroElim(ylen, dety, aey, detyy);
/* 2342 */     int ytlen = scaleExpansionZeroElim(t192len, t192, aeytail, detyt);
/* 2343 */     int yytlen = scaleExpansionZeroElim(ytlen, detyt, aey, detyyt);
/* 2344 */     for (int j = 0; j < yytlen; j++)
/* 2345 */       detyyt[j] = detyyt[j] * 2.0D; 
/* 2346 */     int ytytlen = scaleExpansionZeroElim(ytlen, detyt, aeytail, detytyt);
/* 2347 */     int y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2348 */     int y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/*      */     
/* 2350 */     double[] detz = new double[384];
/* 2351 */     double[] detzz = new double[768];
/* 2352 */     double[] detzt = new double[384];
/* 2353 */     double[] detzzt = new double[768];
/* 2354 */     double[] detztzt = new double[768];
/* 2355 */     double[] z1 = new double[1536];
/* 2356 */     double[] z2 = new double[2304];
/* 2357 */     int zlen = scaleExpansionZeroElim(t192len, t192, aez, detz);
/* 2358 */     int zzlen = scaleExpansionZeroElim(zlen, detz, aez, detzz);
/* 2359 */     int ztlen = scaleExpansionZeroElim(t192len, t192, aeztail, detzt);
/* 2360 */     int zztlen = scaleExpansionZeroElim(ztlen, detzt, aez, detzzt);
/* 2361 */     for (int k = 0; k < zztlen; k++)
/* 2362 */       detzzt[k] = detzzt[k] * 2.0D; 
/* 2363 */     int ztztlen = scaleExpansionZeroElim(ztlen, detzt, aeztail, detztzt);
/* 2364 */     int z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2365 */     int z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/*      */     
/* 2367 */     double[] detw = new double[384];
/* 2368 */     double[] detwt = new double[384];
/* 2369 */     double[] w2 = new double[768];
/* 2370 */     int wlen = scaleExpansionZeroElim(t192len, t192, -bew, detw);
/* 2371 */     int wtlen = scaleExpansionZeroElim(t192len, t192, -bewtail, detwt);
/* 2372 */     int w2len = expansionSumZeroElimFast(wlen, detw, wtlen, detwt, w2);
/*      */     
/* 2374 */     double[] detxy = new double[4608];
/* 2375 */     double[] detxyz = new double[6912];
/* 2376 */     double[] adet = new double[7680];
/* 2377 */     int xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2378 */     int xyzlen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, detxyz);
/* 2379 */     int alen = expansionSumZeroElimFast(w2len, w2, xyzlen, detxyz, adet);
/*      */     
/* 2381 */     t32alen = scaleExpansionZeroElim(dalen, da, cez, t32a);
/* 2382 */     t32blen = scaleExpansionZeroElim(dalen, da, ceztail, t32b);
/* 2383 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2384 */     t32alen = scaleExpansionZeroElim(aclen, ac, dez, t32a);
/* 2385 */     t32blen = scaleExpansionZeroElim(aclen, ac, deztail, t32b);
/* 2386 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2387 */     t32alen = scaleExpansionZeroElim(cdlen, cd, aez, t32a);
/* 2388 */     t32blen = scaleExpansionZeroElim(cdlen, cd, aeztail, t32b);
/* 2389 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2390 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2391 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2392 */     xlen = scaleExpansionZeroElim(t192len, t192, bex, detx);
/* 2393 */     xxlen = scaleExpansionZeroElim(xlen, detx, bex, detxx);
/* 2394 */     xtlen = scaleExpansionZeroElim(t192len, t192, bextail, detxt);
/* 2395 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, bex, detxxt); int m;
/* 2396 */     for (m = 0; m < xxtlen; m++)
/* 2397 */       detxxt[m] = detxxt[m] * 2.0D; 
/* 2398 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, bextail, detxtxt);
/* 2399 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2400 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2401 */     ylen = scaleExpansionZeroElim(t192len, t192, bey, dety);
/* 2402 */     yylen = scaleExpansionZeroElim(ylen, dety, bey, detyy);
/* 2403 */     ytlen = scaleExpansionZeroElim(t192len, t192, beytail, detyt);
/* 2404 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, bey, detyyt);
/* 2405 */     for (m = 0; m < yytlen; m++)
/* 2406 */       detyyt[m] = detyyt[m] * 2.0D; 
/* 2407 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, beytail, detytyt);
/* 2408 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2409 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2410 */     zlen = scaleExpansionZeroElim(t192len, t192, bez, detz);
/* 2411 */     zzlen = scaleExpansionZeroElim(zlen, detz, bez, detzz);
/* 2412 */     ztlen = scaleExpansionZeroElim(t192len, t192, beztail, detzt);
/* 2413 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, bez, detzzt);
/* 2414 */     for (m = 0; m < zztlen; m++)
/* 2415 */       detzzt[m] = detzzt[m] * 2.0D; 
/* 2416 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, beztail, detztzt);
/* 2417 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2418 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2419 */     wlen = scaleExpansionZeroElim(t192len, t192, -bew, detw);
/* 2420 */     wtlen = scaleExpansionZeroElim(t192len, t192, -bewtail, detwt);
/* 2421 */     w2len = expansionSumZeroElimFast(wlen, detw, wtlen, detwt, w2);
/* 2422 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2423 */     xyzlen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, detxyz);
/* 2424 */     double[] bdet = new double[7680];
/* 2425 */     int blen = expansionSumZeroElimFast(w2len, w2, xyzlen, detxyz, bdet);
/*      */     
/* 2427 */     t32alen = scaleExpansionZeroElim(ablen, ab, -dez, t32a);
/* 2428 */     t32blen = scaleExpansionZeroElim(ablen, ab, -deztail, t32b);
/* 2429 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2430 */     t32alen = scaleExpansionZeroElim(bdlen, bd, -aez, t32a);
/* 2431 */     t32blen = scaleExpansionZeroElim(bdlen, bd, -aeztail, t32b);
/* 2432 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2433 */     t32alen = scaleExpansionZeroElim(dalen, da, -bez, t32a);
/* 2434 */     t32blen = scaleExpansionZeroElim(dalen, da, -beztail, t32b);
/* 2435 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2436 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2437 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2438 */     xlen = scaleExpansionZeroElim(t192len, t192, cex, detx);
/* 2439 */     xxlen = scaleExpansionZeroElim(xlen, detx, cex, detxx);
/* 2440 */     xtlen = scaleExpansionZeroElim(t192len, t192, cextail, detxt);
/* 2441 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, cex, detxxt); int n;
/* 2442 */     for (n = 0; n < xxtlen; n++)
/* 2443 */       detxxt[n] = detxxt[n] * 2.0D; 
/* 2444 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, cextail, detxtxt);
/* 2445 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2446 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2447 */     ylen = scaleExpansionZeroElim(t192len, t192, cey, dety);
/* 2448 */     yylen = scaleExpansionZeroElim(ylen, dety, cey, detyy);
/* 2449 */     ytlen = scaleExpansionZeroElim(t192len, t192, ceytail, detyt);
/* 2450 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, cey, detyyt);
/* 2451 */     for (n = 0; n < yytlen; n++)
/* 2452 */       detyyt[n] = detyyt[n] * 2.0D; 
/* 2453 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, ceytail, detytyt);
/* 2454 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2455 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2456 */     zlen = scaleExpansionZeroElim(t192len, t192, cez, detz);
/* 2457 */     zzlen = scaleExpansionZeroElim(zlen, detz, cez, detzz);
/* 2458 */     ztlen = scaleExpansionZeroElim(t192len, t192, ceztail, detzt);
/* 2459 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, cez, detzzt);
/* 2460 */     for (n = 0; n < zztlen; n++)
/* 2461 */       detzzt[n] = detzzt[n] * 2.0D; 
/* 2462 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, ceztail, detztzt);
/* 2463 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2464 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2465 */     wlen = scaleExpansionZeroElim(t192len, t192, -cew, detw);
/* 2466 */     wtlen = scaleExpansionZeroElim(t192len, t192, -cewtail, detwt);
/* 2467 */     w2len = expansionSumZeroElimFast(wlen, detw, wtlen, detwt, w2);
/* 2468 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2469 */     xyzlen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, detxyz);
/* 2470 */     double[] cdet = new double[7680];
/* 2471 */     int clen = expansionSumZeroElimFast(w2len, w2, xyzlen, detxyz, cdet);
/*      */     
/* 2473 */     t32alen = scaleExpansionZeroElim(bclen, bc, aez, t32a);
/* 2474 */     t32blen = scaleExpansionZeroElim(bclen, bc, aeztail, t32b);
/* 2475 */     t64alen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64a);
/* 2476 */     t32alen = scaleExpansionZeroElim(aclen, ac, -bez, t32a);
/* 2477 */     t32blen = scaleExpansionZeroElim(aclen, ac, -beztail, t32b);
/* 2478 */     t64blen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64b);
/* 2479 */     t32alen = scaleExpansionZeroElim(ablen, ab, cez, t32a);
/* 2480 */     t32blen = scaleExpansionZeroElim(ablen, ab, ceztail, t32b);
/* 2481 */     t64clen = expansionSumZeroElimFast(t32alen, t32a, t32blen, t32b, t64c);
/* 2482 */     t128len = expansionSumZeroElimFast(t64alen, t64a, t64blen, t64b, t128);
/* 2483 */     t192len = expansionSumZeroElimFast(t64clen, t64c, t128len, t128, t192);
/* 2484 */     xlen = scaleExpansionZeroElim(t192len, t192, dex, detx);
/* 2485 */     xxlen = scaleExpansionZeroElim(xlen, detx, dex, detxx);
/* 2486 */     xtlen = scaleExpansionZeroElim(t192len, t192, dextail, detxt);
/* 2487 */     xxtlen = scaleExpansionZeroElim(xtlen, detxt, dex, detxxt); int i1;
/* 2488 */     for (i1 = 0; i1 < xxtlen; i1++)
/* 2489 */       detxxt[i1] = detxxt[i1] * 2.0D; 
/* 2490 */     xtxtlen = scaleExpansionZeroElim(xtlen, detxt, dextail, detxtxt);
/* 2491 */     x1len = expansionSumZeroElimFast(xxlen, detxx, xxtlen, detxxt, x1);
/* 2492 */     x2len = expansionSumZeroElimFast(x1len, x1, xtxtlen, detxtxt, x2);
/* 2493 */     ylen = scaleExpansionZeroElim(t192len, t192, dey, dety);
/* 2494 */     yylen = scaleExpansionZeroElim(ylen, dety, dey, detyy);
/* 2495 */     ytlen = scaleExpansionZeroElim(t192len, t192, deytail, detyt);
/* 2496 */     yytlen = scaleExpansionZeroElim(ytlen, detyt, dey, detyyt);
/* 2497 */     for (i1 = 0; i1 < yytlen; i1++)
/* 2498 */       detyyt[i1] = detyyt[i1] * 2.0D; 
/* 2499 */     ytytlen = scaleExpansionZeroElim(ytlen, detyt, deytail, detytyt);
/* 2500 */     y1len = expansionSumZeroElimFast(yylen, detyy, yytlen, detyyt, y1);
/* 2501 */     y2len = expansionSumZeroElimFast(y1len, y1, ytytlen, detytyt, y2);
/* 2502 */     zlen = scaleExpansionZeroElim(t192len, t192, dez, detz);
/* 2503 */     zzlen = scaleExpansionZeroElim(zlen, detz, dez, detzz);
/* 2504 */     ztlen = scaleExpansionZeroElim(t192len, t192, deztail, detzt);
/* 2505 */     zztlen = scaleExpansionZeroElim(ztlen, detzt, dez, detzzt);
/* 2506 */     for (i1 = 0; i1 < zztlen; i1++)
/* 2507 */       detzzt[i1] = detzzt[i1] * 2.0D; 
/* 2508 */     ztztlen = scaleExpansionZeroElim(ztlen, detzt, deztail, detztzt);
/* 2509 */     z1len = expansionSumZeroElimFast(zzlen, detzz, zztlen, detzzt, z1);
/* 2510 */     z2len = expansionSumZeroElimFast(z1len, z1, ztztlen, detztzt, z2);
/* 2511 */     wlen = scaleExpansionZeroElim(t192len, t192, -dew, detw);
/* 2512 */     wtlen = scaleExpansionZeroElim(t192len, t192, -dewtail, detwt);
/* 2513 */     w2len = expansionSumZeroElimFast(wlen, detw, wtlen, detwt, w2);
/* 2514 */     xylen = expansionSumZeroElimFast(x2len, x2, y2len, y2, detxy);
/* 2515 */     xyzlen = expansionSumZeroElimFast(z2len, z2, xylen, detxy, detxyz);
/* 2516 */     double[] ddet = new double[7680];
/* 2517 */     int dlen = expansionSumZeroElimFast(w2len, w2, xyzlen, detxyz, ddet);
/*      */     
/* 2519 */     double[] abdet = new double[15360];
/* 2520 */     double[] cddet = new double[15360];
/* 2521 */     double[] det = new double[30720];
/* 2522 */     ablen = expansionSumZeroElimFast(alen, adet, blen, bdet, abdet);
/* 2523 */     cdlen = expansionSumZeroElimFast(clen, cdet, dlen, ddet, cddet);
/* 2524 */     int detlen = expansionSumZeroElimFast(ablen, abdet, cdlen, cddet, det);
/*      */     
/* 2526 */     return det[detlen - 1];
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/Geometry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */