/*    */ package edu.mines.jtk.ogl.test;
/*    */ 
/*    */ import edu.mines.jtk.ogl.Gl;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import java.awt.Component;
/*    */ import javax.media.opengl.GL;
/*    */ import javax.media.opengl.GLAutoDrawable;
/*    */ import javax.media.opengl.GLCanvas;
/*    */ import javax.media.opengl.GLCapabilities;
/*    */ import javax.media.opengl.GLContext;
/*    */ import javax.media.opengl.GLEventListener;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bench
/*    */   extends JFrame
/*    */   implements GLEventListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Bench() {
/* 25 */     super("Bench");
/* 26 */     GLCapabilities caps = new GLCapabilities();
/* 27 */     caps.setDoubleBuffered(true);
/* 28 */     System.out.println(caps);
/* 29 */     GLCanvas canvas = new GLCanvas(caps);
/* 30 */     canvas.addGLEventListener(this);
/* 31 */     add((Component)canvas);
/*    */   }
/*    */   
/*    */   public void init(GLAutoDrawable drawable) {
/* 35 */     Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 36 */     Gl.glMatrixMode(5889);
/* 37 */     Gl.glLoadIdentity();
/* 38 */     Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/* 39 */     System.out.println("OpenGL version=" + Gl.glGetString(7938));
/* 40 */     System.out.println("OpenGL vendor=" + Gl.glGetString(7936));
/*    */   }
/*    */   
/*    */   public void display(GLAutoDrawable drawable) {
/* 44 */     Stopwatch s = new Stopwatch();
/*    */ 
/*    */     
/* 47 */     for (int ntrial = 0; ntrial < 3; ntrial++) {
/* 48 */       s.restart();
/* 49 */       Gl.glClear(16384); int nloop;
/* 50 */       for (nloop = 0; s.time() < 1.0D; nloop++) {
/* 51 */         for (int ipoly = 0; ipoly < 100; ipoly++) {
/* 52 */           Gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 53 */           Gl.glBegin(9);
/* 54 */           Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 55 */           Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 56 */           Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 57 */           Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 58 */           Gl.glEnd();
/*    */         } 
/*    */       } 
/* 61 */       Gl.glFinish();
/* 62 */       s.stop();
/* 63 */       System.out.println("new rate=" + nloop + " loops per second");
/*    */       
/* 65 */       s.restart();
/* 66 */       GL gl = GLContext.getCurrent().getGL();
/* 67 */       gl.glClear(16384);
/* 68 */       for (nloop = 0; s.time() < 1.0D; nloop++) {
/* 69 */         for (int ipoly = 0; ipoly < 100; ipoly++) {
/* 70 */           gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 71 */           gl.glBegin(9);
/* 72 */           gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 73 */           gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 74 */           gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 75 */           gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 76 */           gl.glEnd();
/*    */         } 
/*    */       } 
/* 79 */       gl.glFinish();
/* 80 */       s.stop();
/* 81 */       System.out.println("old rate=" + nloop + " loops per second");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {}
/*    */ 
/*    */   
/*    */   public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {}
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 94 */     Bench frame = new Bench();
/* 95 */     frame.setSize(512, 512);
/* 96 */     frame.setDefaultCloseOperation(3);
/* 97 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/Bench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */