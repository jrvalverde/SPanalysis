/*     */ package edu.mines.jtk.ogl.test;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.ogl.GlCanvas;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Circle
/*     */ {
/*  23 */   private static GlCanvas canvas = new GlCanvas() {
/*     */       public void glInit() {
/*  25 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/*  26 */         Gl.glEnable(2929);
/*  27 */         listCircleInit(this._nsides);
/*  28 */         this._stopwatch.start();
/*     */       }
/*     */       public void glResize(int x, int y, int width, int height) {
/*  31 */         Gl.glViewport(0, 0, width, height);
/*  32 */         Gl.glMatrixMode(5889);
/*  33 */         Gl.glLoadIdentity();
/*  34 */         Gl.glFrustum(-0.03D, 0.03D, -0.03D, 0.03D, 0.1D, 20.0D);
/*  35 */         Gl.glMatrixMode(5888);
/*  36 */         Gl.glLoadIdentity();
/*  37 */         Gl.glTranslated(0.0D, 0.0D, -4.0D);
/*  38 */         Gl.glRotated(-80.0D, 1.0D, 0.0D, 0.0D);
/*     */       }
/*     */       public void glPaint() {
/*  41 */         Gl.glClear(16640);
/*  42 */         this._wild = !this._wild;
/*  43 */         if (!this._wild)
/*  44 */           Gl.glColor3f(1.0F, 1.0F, 1.0F); 
/*  45 */         double[] n = new double[3];
/*  46 */         for (int lat = 0; lat < this._nvert; lat++) {
/*  47 */           double theta = Math.PI * lat / this._nvert;
/*  48 */           n[2] = Math.cos(theta);
/*  49 */           double nxy = Math.sin(theta);
/*  50 */           for (int lon = 0; lon < 2 * this._nvert; lon++) {
/*  51 */             double phi = 6.283185307179586D * lon / (2 * this._nvert);
/*  52 */             n[0] = nxy * Math.sin(phi);
/*  53 */             n[1] = nxy * Math.cos(phi);
/*  54 */             if (this._wild) {
/*  55 */               Gl.glColor3f(this._random.nextFloat(), this._random.nextFloat(), this._random.nextFloat());
/*     */             }
/*     */             
/*  58 */             switch (this._imode) {
/*     */               case 0:
/*  60 */                 simpleCircle(n, n, this._r, this._nsides);
/*     */                 break;
/*     */               case 1:
/*  63 */                 listCircle(n, n, this._r);
/*     */                 break;
/*     */             } 
/*     */           } 
/*     */         } 
/*  68 */         Gl.glRotated(1.0D, 0.0D, 0.0D, 1.0D);
/*  69 */         Gl.glFlush();
/*  70 */         this._npaint++;
/*  71 */         if (this._stopwatch.time() > 2.0D) {
/*  72 */           this._stopwatch.stop();
/*  73 */           int rate = (int)(this._npaint / this._stopwatch.time());
/*  74 */           System.out.println(this._modes[this._imode] + ": frames/sec = " + rate);
/*  75 */           this._npaint = 0;
/*  76 */           this._stopwatch.restart();
/*  77 */           this._imode++;
/*  78 */           if (this._imode == this._modes.length)
/*  79 */             this._imode = 0; 
/*     */         } 
/*     */       }
/*     */       private void listCircleInit(int nsides) {
/*  83 */         Gl.glNewList(1, 4864);
/*  84 */         Gl.glBegin(9);
/*  85 */         for (int i = 0; i < nsides; i++) {
/*  86 */           double ang = 6.283185307179586D * i / nsides;
/*  87 */           double cosang = Math.cos(ang);
/*  88 */           double sinang = Math.sin(ang);
/*  89 */           Gl.glVertex2d(cosang, sinang);
/*     */         } 
/*  91 */         Gl.glEnd();
/*  92 */         Gl.glEndList();
/*     */       }
/*     */       private void listCircle(double[] c, double[] n, double r) {
/*  95 */         double tx = -Math.asin(n[1]);
/*  96 */         double ty = Math.atan2(n[0], n[2]);
/*  97 */         Gl.glPushMatrix();
/*  98 */         Gl.glTranslated(c[0], c[1], c[2]);
/*  99 */         Gl.glRotated(radToDeg(ty), 0.0D, 1.0D, 0.0D);
/* 100 */         Gl.glRotated(radToDeg(tx), 1.0D, 0.0D, 0.0D);
/* 101 */         Gl.glScaled(r, r, r);
/* 102 */         Gl.glCallList(1);
/* 103 */         Gl.glPopMatrix();
/*     */       }
/*     */       private void simpleCircle(double[] c, double[] n, double r, int nsides) {
/* 106 */         double[] u = (n[0] * n[0] < 0.33D) ? create(0.0D, n[2], -n[1]) : create(-n[2], 0.0D, n[0]);
/*     */ 
/*     */         
/* 109 */         u = scale(u, r / length(u));
/* 110 */         double[] v = cross(n, u);
/* 111 */         v = scale(v, r / length(v));
/* 112 */         Gl.glBegin(9);
/* 113 */         for (int i = 0; i < nsides; i++) {
/* 114 */           double ang = 6.283185307179586D * i / nsides;
/* 115 */           double cosang = Math.cos(ang);
/* 116 */           double sinang = Math.sin(ang);
/* 117 */           double x = c[0] + cosang * u[0] + sinang * v[0];
/* 118 */           double y = c[1] + cosang * u[1] + sinang * v[1];
/* 119 */           double z = c[2] + cosang * u[2] + sinang * v[2];
/* 120 */           Gl.glVertex3d(x, y, z);
/*     */         } 
/* 122 */         Gl.glEnd();
/*     */       }
/*     */       private double[] create(double x, double y, double z) {
/* 125 */         return new double[] { x, y, z };
/*     */       }
/*     */       private double length(double[] a) {
/* 128 */         return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
/*     */       }
/*     */       private double[] scale(double[] a, double s) {
/* 131 */         return new double[] { s * a[0], s * a[1], s * a[2] };
/*     */       }
/*     */       private double[] cross(double[] a, double[] b) {
/* 134 */         return new double[] { a[1] * b[2] - b[1] * a[2], a[2] * b[0] - b[2] * a[0], a[0] * b[1] - b[0] * a[1] };
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private double radToDeg(double rad) {
/* 141 */         return 180.0D * rad / Math.PI;
/*     */       }
/* 143 */       private int _nsides = 10;
/* 144 */       private int _nvert = 14;
/* 145 */       private double _r = 1.5707963267948966D / this._nvert * 0.4D;
/*     */       private boolean _wild;
/* 147 */       private Random _random = new Random();
/* 148 */       private Stopwatch _stopwatch = new Stopwatch();
/*     */       private int _npaint;
/*     */       private static final int X = 0;
/*     */       private static final int Y = 1;
/*     */       private static final int Z = 2;
/*     */       private static final double RFRAC = 0.4D;
/*     */       private static final int UNIT_CIRCLE = 1;
/*     */       private static final int SIMPLE_CIRCLE = 0;
/*     */       private static final int LIST_CIRCLE = 1;
/*     */       private int _imode;
/* 158 */       private String[] _modes = new String[] { "simple", "display list" };
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 164 */     TestSimple.run(args, canvas, true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/Circle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */