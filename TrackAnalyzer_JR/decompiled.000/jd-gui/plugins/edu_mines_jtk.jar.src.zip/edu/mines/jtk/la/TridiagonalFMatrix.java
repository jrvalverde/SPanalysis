/*     */ package edu.mines.jtk.la;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TridiagonalFMatrix
/*     */ {
/*     */   private int _n;
/*     */   private float[] _a;
/*     */   private float[] _b;
/*     */   private float[] _c;
/*     */   private float[] _w;
/*     */   
/*     */   public TridiagonalFMatrix(int n) {
/*  33 */     this(n, new float[n], new float[n], new float[n]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TridiagonalFMatrix(int n, float[] a, float[] b, float[] c) {
/*  45 */     this._n = n;
/*  46 */     this._a = a;
/*  47 */     this._b = b;
/*  48 */     this._c = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int n() {
/*  56 */     return this._n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] a() {
/*  64 */     return this._a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] b() {
/*  72 */     return this._b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] c() {
/*  80 */     return this._c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void solve(float[] r, float[] u) {
/*  91 */     if (this._w == null)
/*  92 */       this._w = new float[this._n]; 
/*  93 */     float t = this._b[0];
/*  94 */     u[0] = r[0] / t; int j;
/*  95 */     for (j = 1; j < this._n; j++) {
/*  96 */       this._w[j] = this._c[j - 1] / t;
/*  97 */       t = this._b[j] - this._a[j] * this._w[j];
/*  98 */       u[j] = (r[j] - this._a[j] * u[j - 1]) / t;
/*     */     } 
/* 100 */     for (j = this._n - 1; j > 0; j--) {
/* 101 */       u[j - 1] = u[j - 1] - this._w[j] * u[j];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] times(float[] x) {
/* 110 */     int n = x.length;
/* 111 */     float[] y = new float[n];
/* 112 */     times(x, y);
/* 113 */     return y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void times(float[] x, float[] y) {
/* 122 */     int n = x.length;
/* 123 */     int nm1 = n - 1;
/* 124 */     float xim1 = 0.0F;
/* 125 */     float xip1 = 0.0F;
/* 126 */     float xi = x[0];
/* 127 */     y[0] = this._b[0] * xi;
/* 128 */     if (n > 1) {
/* 129 */       xip1 = x[1];
/* 130 */       y[0] = y[0] + this._c[0] * xip1;
/* 131 */       y[n - 1] = this._a[n - 1] * x[n - 2] + this._b[n - 1] * x[n - 1];
/*     */     } 
/* 133 */     for (int i = 1; i < nm1; i++) {
/* 134 */       xim1 = xi;
/* 135 */       xi = xip1;
/* 136 */       xip1 = x[i + 1];
/* 137 */       y[i] = this._a[i] * xim1 + this._b[i] * xi + this._c[i] * xip1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/TridiagonalFMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */