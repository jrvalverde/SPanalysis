/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.util.Direct;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TriangleGroup
/*     */   extends Group
/*     */   implements Selectable
/*     */ {
/*     */   private static final int I = 0;
/*     */   private static final int J = 1;
/*     */   private static final int K = 2;
/*     */   private static final int X = 0;
/*     */   private static final int Y = 1;
/*     */   private static final int Z = 2;
/*     */   private static final int U = 0;
/*     */   private static final int V = 1;
/*     */   private static final int W = 2;
/*     */   private static final int R = 0;
/*     */   private static final int G = 1;
/*     */   private static final int B = 2;
/*     */   private static final int MIN_TRI_PER_NODE = 1024;
/*     */   
/*     */   public TriangleGroup(boolean vn, float[] xyz) {
/*  55 */     this(vn, xyz, (float[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TriangleGroup(boolean vn, float[] xyz, float[] rgb) {
/*  81 */     int[] ijk = indexVertices(!vn, xyz);
/*  82 */     float[] uvw = computeNormals(ijk, xyz);
/*  83 */     buildTree(ijk, xyz, uvw, rgb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TriangleGroup(int[] ijk, float[] xyz) {
/* 103 */     this(ijk, xyz, (float[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TriangleGroup(int[] ijk, float[] xyz, float[] rgb) {
/* 127 */     float[] uvw = computeNormals(ijk, xyz);
/* 128 */     buildTree(ijk, xyz, uvw, rgb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] indexVertices(boolean sequential, float[] xyz) {
/* 164 */     int nv = xyz.length / 3;
/* 165 */     int nt = nv / 3;
/*     */ 
/*     */     
/* 168 */     int[] ijk = new int[nv];
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (sequential) {
/* 173 */       for (int iv = 0; iv < nv; iv++)
/* 174 */         ijk[iv] = iv; 
/*     */     } else {
/* 176 */       HashMap<Vertex, Integer> vimap = new HashMap<Vertex, Integer>(nv);
/* 177 */       for (int it = 0; it < nt; it++) {
/* 178 */         for (int iv = 0, jv = 3 * it, kv = 3 * jv; iv < 3; iv++, jv++, kv += 3) {
/* 179 */           Vertex v = new Vertex(xyz[kv + 0], xyz[kv + 1], xyz[kv + 2]);
/* 180 */           Integer i = vimap.get(v);
/* 181 */           if (i == null) {
/* 182 */             i = new Integer(jv);
/* 183 */             vimap.put(v, i);
/*     */           } 
/* 185 */           ijk[jv] = i.intValue();
/*     */         } 
/*     */       } 
/*     */     } 
/* 189 */     return ijk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void selectedChanged() {
/* 196 */     System.out.println("TriangleGroup: " + this + " selected=" + isSelected());
/* 197 */     dirtyDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildTree(int[] ijk, float[] xyz, float[] uvw, float[] rgb) {
/* 215 */     float[] c = computeCenters(ijk, xyz);
/* 216 */     BoundingBoxTree bbt = new BoundingBoxTree(1024, c);
/* 217 */     buildTree(this, bbt.getRoot(), ijk, xyz, uvw, rgb);
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildTree(Group parent, BoundingBoxTree.Node bbtNode, int[] ijk, float[] xyz, float[] uvw, float[] rgb) {
/* 222 */     if (bbtNode.isLeaf()) {
/* 223 */       TriangleNode tn = new TriangleNode(bbtNode, ijk, xyz, uvw, rgb);
/* 224 */       parent.addChild(tn);
/*     */     } else {
/* 226 */       Group group = new Group();
/* 227 */       parent.addChild(group);
/* 228 */       buildTree(group, bbtNode.getLeft(), ijk, xyz, uvw, rgb);
/* 229 */       buildTree(group, bbtNode.getRight(), ijk, xyz, uvw, rgb);
/*     */     } 
/*     */   }
/*     */   
/*     */   private class TriangleNode extends Node {
/*     */     private BoundingSphere _bs;
/*     */     private int _nt;
/*     */     private FloatBuffer _vb;
/*     */     private FloatBuffer _nb;
/*     */     private FloatBuffer _cb;
/*     */     
/*     */     public TriangleNode(BoundingBoxTree.Node bbtNode, int[] ijk, float[] xyz, float[] uvw, float[] rgb) {
/* 241 */       BoundingBox bb = bbtNode.getBoundingBox();
/* 242 */       this._bs = new BoundingSphere(bb);
/* 243 */       this._nt = bbtNode.getSize();
/* 244 */       int nt = this._nt;
/* 245 */       int nv = 3 * nt;
/* 246 */       int nn = 3 * nt;
/* 247 */       int nc = 3 * nt;
/* 248 */       int[] index = bbtNode.getIndices();
/* 249 */       this._vb = Direct.newFloatBuffer(3 * nv);
/* 250 */       this._nb = (uvw != null) ? Direct.newFloatBuffer(3 * nn) : null;
/* 251 */       this._cb = (rgb != null) ? Direct.newFloatBuffer(3 * nc) : null;
/* 252 */       for (int it = 0, iv = 0, in = 0, ic = 0; it < nt; it++) {
/* 253 */         int jt = 3 * index[it];
/* 254 */         int i = 3 * ijk[jt + 0];
/* 255 */         int j = 3 * ijk[jt + 1];
/* 256 */         int k = 3 * ijk[jt + 2];
/* 257 */         this._vb.put(iv++, xyz[i + 0]);
/* 258 */         this._vb.put(iv++, xyz[i + 1]);
/* 259 */         this._vb.put(iv++, xyz[i + 2]);
/* 260 */         this._vb.put(iv++, xyz[j + 0]);
/* 261 */         this._vb.put(iv++, xyz[j + 1]);
/* 262 */         this._vb.put(iv++, xyz[j + 2]);
/* 263 */         this._vb.put(iv++, xyz[k + 0]);
/* 264 */         this._vb.put(iv++, xyz[k + 1]);
/* 265 */         this._vb.put(iv++, xyz[k + 2]);
/* 266 */         if (this._nb != null) {
/* 267 */           this._nb.put(in++, uvw[i + 0]);
/* 268 */           this._nb.put(in++, uvw[i + 1]);
/* 269 */           this._nb.put(in++, uvw[i + 2]);
/* 270 */           this._nb.put(in++, uvw[j + 0]);
/* 271 */           this._nb.put(in++, uvw[j + 1]);
/* 272 */           this._nb.put(in++, uvw[j + 2]);
/* 273 */           this._nb.put(in++, uvw[k + 0]);
/* 274 */           this._nb.put(in++, uvw[k + 1]);
/* 275 */           this._nb.put(in++, uvw[k + 2]);
/*     */         } 
/* 277 */         if (this._cb != null) {
/* 278 */           this._cb.put(ic++, rgb[i + 0]);
/* 279 */           this._cb.put(ic++, rgb[i + 1]);
/* 280 */           this._cb.put(ic++, rgb[i + 2]);
/* 281 */           this._cb.put(ic++, rgb[j + 0]);
/* 282 */           this._cb.put(ic++, rgb[j + 1]);
/* 283 */           this._cb.put(ic++, rgb[j + 2]);
/* 284 */           this._cb.put(ic++, rgb[k + 0]);
/* 285 */           this._cb.put(ic++, rgb[k + 1]);
/* 286 */           this._cb.put(ic++, rgb[k + 2]);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 292 */       return this._bs;
/*     */     }
/*     */     
/*     */     protected void draw(DrawContext dc) {
/* 296 */       boolean selected = TriangleGroup.this.isSelected();
/* 297 */       Gl.glEnableClientState(32884);
/* 298 */       Gl.glVertexPointer(3, 5126, 0, this._vb);
/* 299 */       if (this._nb != null) {
/* 300 */         Gl.glEnableClientState(32885);
/* 301 */         Gl.glNormalPointer(5126, 0, this._nb);
/*     */       } 
/* 303 */       if (this._cb != null) {
/* 304 */         Gl.glEnableClientState(32886);
/* 305 */         Gl.glColorPointer(3, 5126, 0, this._cb);
/*     */       } 
/* 307 */       if (selected) {
/* 308 */         Gl.glEnable(32823);
/* 309 */         Gl.glPolygonOffset(1.0F, 1.0F);
/*     */       } 
/* 311 */       Gl.glDrawArrays(4, 0, 3 * this._nt);
/* 312 */       if (this._nb != null)
/* 313 */         Gl.glDisableClientState(32885); 
/* 314 */       if (this._cb != null)
/* 315 */         Gl.glDisableClientState(32886); 
/* 316 */       if (selected) {
/* 317 */         Gl.glPolygonMode(1032, 6913);
/* 318 */         Gl.glDisable(2896);
/* 319 */         Gl.glColor3d(1.0D, 1.0D, 1.0D);
/* 320 */         Gl.glDrawArrays(4, 0, 3 * this._nt);
/*     */       } 
/* 322 */       Gl.glDisableClientState(32884);
/*     */     }
/*     */     
/*     */     protected void pick(PickContext pc) {
/* 326 */       Segment ps = pc.getPickSegment();
/* 327 */       for (int it = 0, jt = 0; it < this._nt; it++) {
/* 328 */         double xi = this._vb.get(jt++);
/* 329 */         double yi = this._vb.get(jt++);
/* 330 */         double zi = this._vb.get(jt++);
/* 331 */         double xj = this._vb.get(jt++);
/* 332 */         double yj = this._vb.get(jt++);
/* 333 */         double zj = this._vb.get(jt++);
/* 334 */         double xk = this._vb.get(jt++);
/* 335 */         double yk = this._vb.get(jt++);
/* 336 */         double zk = this._vb.get(jt++);
/* 337 */         Point3 p = ps.intersectWithTriangle(xi, yi, zi, xj, yj, zj, xk, yk, zk);
/* 338 */         if (p != null) {
/* 339 */           pc.addResult(p);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Vertex
/*     */   {
/*     */     float x;
/*     */     float y;
/*     */     float z;
/*     */     
/*     */     Vertex(float x, float y, float z) {
/* 353 */       this.x = x;
/* 354 */       this.y = y;
/* 355 */       this.z = z;
/*     */     }
/*     */     public boolean equals(Object o) {
/* 358 */       Vertex v = (Vertex)o;
/* 359 */       return (this.x == v.x && this.y == v.y && this.z == v.z);
/*     */     }
/*     */     public int hashCode() {
/* 362 */       return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] computeNormals(int[] ijk, float[] xyz) {
/* 392 */     int nv = xyz.length / 3;
/* 393 */     int nt = ijk.length / 3;
/* 394 */     float[] uvw = new float[3 * nv];
/*     */ 
/*     */     
/* 397 */     for (int it = 0, jt = 0; it < nt; it++) {
/*     */ 
/*     */       
/* 400 */       int i = 3 * ijk[jt++];
/* 401 */       int j = 3 * ijk[jt++];
/* 402 */       int k = 3 * ijk[jt++];
/* 403 */       float xi = xyz[i + 0];
/* 404 */       float yi = xyz[i + 1];
/* 405 */       float zi = xyz[i + 2];
/* 406 */       float xj = xyz[j + 0];
/* 407 */       float yj = xyz[j + 1];
/* 408 */       float zj = xyz[j + 2];
/* 409 */       float xk = xyz[k + 0];
/* 410 */       float yk = xyz[k + 1];
/* 411 */       float zk = xyz[k + 2];
/*     */ 
/*     */ 
/*     */       
/* 415 */       float xa = xj - xi;
/* 416 */       float ya = yj - yi;
/* 417 */       float za = zj - zi;
/* 418 */       float xb = xk - xi;
/* 419 */       float yb = yk - yi;
/* 420 */       float zb = zk - zi;
/* 421 */       float un = ya * zb - yb * za;
/* 422 */       float vn = za * xb - zb * xa;
/* 423 */       float wn = xa * yb - xb * ya;
/*     */ 
/*     */ 
/*     */       
/* 427 */       uvw[i + 0] = uvw[i + 0] + un;
/* 428 */       uvw[i + 1] = uvw[i + 1] + vn;
/* 429 */       uvw[i + 2] = uvw[i + 2] + wn;
/* 430 */       uvw[j + 0] = uvw[j + 0] + un;
/* 431 */       uvw[j + 1] = uvw[j + 1] + vn;
/* 432 */       uvw[j + 2] = uvw[j + 2] + wn;
/* 433 */       uvw[k + 0] = uvw[k + 0] + un;
/* 434 */       uvw[k + 1] = uvw[k + 1] + vn;
/* 435 */       uvw[k + 2] = uvw[k + 2] + wn;
/*     */     } 
/* 437 */     return uvw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float[] computeCenters(int[] ijk, float[] xyz) {
/* 458 */     int nt = ijk.length / 3;
/* 459 */     float[] c = new float[3 * nt];
/* 460 */     float o3 = 0.33333334F;
/* 461 */     for (int it = 0, jt = 0, jc = 0; it < nt; it++) {
/* 462 */       int i = 3 * ijk[jt++];
/* 463 */       int j = 3 * ijk[jt++];
/* 464 */       int k = 3 * ijk[jt++];
/* 465 */       float xi = xyz[i + 0];
/* 466 */       float yi = xyz[i + 1];
/* 467 */       float zi = xyz[i + 2];
/* 468 */       float xj = xyz[j + 0];
/* 469 */       float yj = xyz[j + 1];
/* 470 */       float zj = xyz[j + 2];
/* 471 */       float xk = xyz[k + 0];
/* 472 */       float yk = xyz[k + 1];
/* 473 */       float zk = xyz[k + 2];
/* 474 */       c[jc++] = (xi + xj + xk) * o3;
/* 475 */       c[jc++] = (yi + yj + yk) * o3;
/* 476 */       c[jc++] = (zi + zj + zk) * o3;
/*     */     } 
/* 478 */     return c;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/TriangleGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */