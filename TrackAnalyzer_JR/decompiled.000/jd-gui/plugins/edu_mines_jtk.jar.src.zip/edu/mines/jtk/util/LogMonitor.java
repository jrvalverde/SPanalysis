/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogMonitor
/*     */   implements Monitor
/*     */ {
/*  19 */   private Logger _log = null;
/*  20 */   private String _prefix = "";
/*  21 */   private volatile long _startTime = 0L;
/*  22 */   private volatile long _lastTime = 0L;
/*  23 */   private volatile long _currentTime = 0L;
/*  24 */   private volatile double _initFraction = 0.0D;
/*  25 */   private volatile double _lastFraction = 0.0D;
/*  26 */   private Thread _thread = null;
/*     */ 
/*     */   
/*  29 */   private static final String NL = System.getProperty("line.separator");
/*     */ 
/*     */   
/*     */   private static final long SHORTEST_INTERVAL = 10000L;
/*     */   
/*     */   private static final long LONGEST_FIRST_INTERVAL = 60000L;
/*     */   
/*     */   private static final long LONGEST_INTERVAL = 900000L;
/*     */   
/*  38 */   private static final Logger LOG = Logger.getLogger(LogMonitor.class.getName(), LogMonitor.class.getName());
/*     */ 
/*     */   
/*  41 */   private boolean _debug = LOG.isLoggable(Level.FINE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogMonitor(String prefix, Logger logger) {
/*  49 */     this._log = logger;
/*  50 */     if (prefix != null) {
/*  51 */       this._prefix = prefix;
/*     */     }
/*     */   }
/*     */   
/*     */   public void initReport(double initFraction) {
/*  56 */     if (this._initFraction != 0.0D || initFraction < this._initFraction) {
/*  57 */       throw new IllegalStateException("initReport is being called twice, or with a bad value: new value of " + initFraction + " cannot replace previous value of " + this._initFraction);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     this._initFraction = Math.min(0.99999D, initFraction);
/*  64 */     report(initFraction);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void report(double fraction) {
/*  70 */     fraction = (fraction - this._initFraction) / (1.0D - this._initFraction);
/*  71 */     synchronized (this) {
/*  72 */       if (fraction < this._lastFraction - 1.0E-4D) {
/*  73 */         IllegalStateException ex = new IllegalStateException("Progress cannot decrease from " + this._lastFraction + " to " + fraction);
/*     */         
/*  75 */         if (this._debug) {
/*  76 */           throw ex;
/*     */         }
/*  78 */         ex.printStackTrace();
/*  79 */         this._lastFraction = fraction;
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  84 */       if (this._startTime == 0L) {
/*  85 */         this._currentTime = System.currentTimeMillis();
/*  86 */         this._startTime = this._currentTime;
/*  87 */         if (fraction < 1.0D) {
/*  88 */           this._thread = new UpdateTimeThread();
/*  89 */           this._thread.setDaemon(true);
/*  90 */           this._thread.start();
/*     */         } 
/*  92 */         print(fraction, this._currentTime);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  97 */       if (fraction >= 1.0D) {
/*     */         
/*  99 */         if (fraction > this._lastFraction) {
/* 100 */           this._currentTime = System.currentTimeMillis();
/* 101 */           print(fraction, this._currentTime);
/*     */         } 
/* 103 */         if (this._thread != null) {
/* 104 */           this._thread.interrupt();
/* 105 */           this._thread = null;
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 111 */       boolean print = false;
/* 112 */       if (this._currentTime > this._lastTime + 900000L) {
/* 113 */         this._currentTime = System.currentTimeMillis();
/*     */         
/* 115 */         print = true;
/*     */       } else {
/* 117 */         boolean significantProgress = (fraction > this._lastFraction + 0.02D || (fraction > this._lastFraction + 0.01D && this._lastFraction <= 0.02D));
/*     */ 
/*     */         
/* 120 */         boolean firstProgress = (this._lastFraction == 0.0D && fraction > this._lastFraction + 0.001D);
/*     */         
/* 122 */         if (significantProgress || firstProgress) {
/*     */           
/* 124 */           this._currentTime = System.currentTimeMillis();
/* 125 */           long interval = significantProgress ? 10000L : 60000L;
/*     */           
/* 127 */           if (this._currentTime >= this._lastTime + interval) {
/* 128 */             print = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 134 */       if (print) {
/* 135 */         print(fraction, this._currentTime);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void print(double fraction, long currentTime) {
/* 146 */     synchronized (this) {
/* 147 */       if (this._log != null) {
/* 148 */         this._log.info(this._prefix + getProgressReport(this._startTime, currentTime, fraction, this._initFraction));
/*     */       }
/*     */       
/* 151 */       this._lastFraction = fraction;
/* 152 */       this._lastTime = currentTime;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getProgressReport(long startTime, long currentTime, double fraction, double initFraction) {
/* 168 */     String progress = "";
/* 169 */     long secSoFar = (currentTime - startTime) / 1000L;
/* 170 */     if (secSoFar > 0L) {
/* 171 */       progress = Localize.timeWords(secSoFar) + " ${so_far}";
/* 172 */       long secRemaining = (fraction > 0.0D) ? (long)((1.0D / fraction - 1.0D) * secSoFar) : 0L;
/*     */ 
/*     */       
/* 175 */       if (secRemaining > 0L) {
/* 176 */         String remaining = Localize.timeWords(secRemaining) + " ${remaining}";
/* 177 */         if (progress.length() > 0) {
/* 178 */           progress = remaining + ", " + progress;
/*     */         } else {
/* 180 */           progress = remaining;
/*     */         } 
/*     */       } 
/* 183 */       long total = secSoFar + secRemaining;
/* 184 */       if (progress.length() > 0) {
/* 185 */         progress = NL + "  " + progress + ", " + Localize.timeWords(total) + " ${total}";
/*     */       }
/* 187 */       if (fraction >= 1.0D) {
/* 188 */         progress = NL + "  ${Finished_in} " + Localize.timeWords(total) + " ${total}";
/*     */       }
/*     */     } 
/*     */     
/* 192 */     int percent = (int)(100.0D * (initFraction + fraction * (1.0D - initFraction)) + 0.49D);
/*     */     
/* 194 */     String message = " ${progress}: " + percent + "% ${complete_at} " + new Date() + progress;
/*     */     
/* 196 */     message = Localize.filter(message, LogMonitor.class);
/* 197 */     return message;
/*     */   }
/*     */   
/*     */   private class UpdateTimeThread
/*     */     extends Thread
/*     */   {
/*     */     public UpdateTimeThread() {
/* 204 */       super("LogMonitor.UpdateTimeThread " + new Date());
/*     */     }
/*     */     public void run() {
/*     */       try {
/* 208 */         while (LogMonitor.this._lastFraction < 0.9999D) {
/* 209 */           Thread.sleep(225000L);
/* 210 */           LogMonitor.this._currentTime = System.currentTimeMillis();
/* 211 */           if (LogMonitor.this._currentTime > LogMonitor.this._lastTime + 1800000L)
/*     */           {
/* 213 */             LogMonitor.this.print(LogMonitor.this._lastFraction, LogMonitor.this._currentTime);
/*     */           }
/*     */         } 
/* 216 */       } catch (InterruptedException e) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) throws Exception {
/* 227 */     CleanHandler.setDefaultHandler();
/*     */     
/* 229 */     Monitor monitor = new LogMonitor("${Test}", LOG);
/* 230 */     int n = 25;
/* 231 */     int pause = 25;
/* 232 */     monitor.report(0.0D);
/* 233 */     Thread.sleep(pause);
/* 234 */     monitor.report(0.0D);
/* 235 */     for (int i = 0; i < n; i++) {
/* 236 */       monitor.report(i / (n - 1.0D));
/* 237 */       Thread.sleep(pause);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/LogMonitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */