/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.ColorMap;
/*     */ import edu.mines.jtk.awt.ColorMapListener;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.DataBuffer;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PixelsView
/*     */   extends TiledView
/*     */ {
/*     */   private Sampling _s1;
/*     */   private Sampling _s2;
/*     */   private float[][] _f;
/*     */   private Orientation _orientation;
/*     */   private Interpolation _interpolation;
/*     */   private float _clipMin;
/*     */   private float _clipMax;
/*     */   private float _percMin;
/*     */   private float _percMax;
/*     */   private boolean _usePercentiles;
/*     */   private ColorMap _colorMap;
/*     */   private boolean _transposed;
/*     */   private boolean _xflipped;
/*     */   private boolean _yflipped;
/*     */   private int _nx;
/*     */   private double _dx;
/*     */   private double _fx;
/*     */   private int _ny;
/*     */   private double _dy;
/*     */   private double _fy;
/*     */   
/*     */   public enum Orientation
/*     */   {
/*  58 */     X1RIGHT_X2UP,
/*  59 */     X1DOWN_X2RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Interpolation
/*     */   {
/*  69 */     NEAREST,
/*  70 */     LINEAR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelsView(float[][] f)
/*     */   {
/* 368 */     this._orientation = Orientation.X1RIGHT_X2UP;
/*     */ 
/*     */     
/* 371 */     this._interpolation = Interpolation.LINEAR;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     this._percMin = 0.0F;
/* 377 */     this._percMax = 100.0F;
/* 378 */     this._usePercentiles = true; init(); set(f); } public PixelsView(Sampling s1, Sampling s2, float[][] f) { this._orientation = Orientation.X1RIGHT_X2UP; this._interpolation = Interpolation.LINEAR; this._percMin = 0.0F; this._percMax = 100.0F; this._usePercentiles = true; init(); set(s1, s2, f); } public void set(float[][] f) { set(new Sampling((f[0]).length), new Sampling(f.length), f); }
/*     */   public void set(Sampling s1, Sampling s2, float[][] f) { Check.argument(s1.isUniform(), "s1 is uniform"); Check.argument(s2.isUniform(), "s2 is uniform"); Check.argument(Array.isRegular(f), "f is regular"); Check.argument((s1.getCount() == (f[0]).length), "s1 consistent with f"); Check.argument((s2.getCount() == f.length), "s2 consistent with f"); this._s1 = s1; this._s2 = s2;
/*     */     this._f = Array.copy(f);
/*     */     updateClips();
/*     */     updateSampling(); }
/*     */   public void setOrientation(Orientation orientation) { if (this._orientation != orientation) {
/*     */       this._orientation = orientation;
/*     */       updateSampling();
/*     */       repaint();
/*     */     }  }
/*     */   public Orientation getOrientation() { return this._orientation; }
/*     */   public void setInterpolation(Interpolation interpolation) { if (this._interpolation != interpolation) {
/*     */       this._interpolation = interpolation;
/*     */       updateBestProjectors();
/*     */       repaint();
/*     */     }  }
/*     */   public Interpolation getInterpolation() { return this._interpolation; }
/*     */   public void setColorModel(IndexColorModel colorModel) { this._colorMap.setColorModel(colorModel);
/*     */     repaint(); }
/*     */   public IndexColorModel getColorModel() { return this._colorMap.getColorModel(); }
/* 398 */   private void init() { this._colorMap = new ColorMap(0.0D, 1.0D, ColorMap.GRAY); } public void setClips(float clipMin, float clipMax) { Check.argument((clipMin < clipMax), "clipMin<clipMax"); if (this._clipMin != clipMin || this._clipMax != clipMax) { this._usePercentiles = false; this._clipMin = clipMin; this._clipMax = clipMax; this._colorMap.setValueRange(this._clipMin, this._clipMax); repaint(); }
/*     */      }
/*     */   public float getClipMin() { return this._clipMin; }
/*     */   public float getClipMax() { return this._clipMax; }
/*     */   public void setPercentiles(float percMin, float percMax) { Check.argument((0.0F <= percMin), "0<=percMin"); Check.argument((percMin < percMax), "percMin<percMax"); Check.argument((percMax <= 100.0F), "percMax<=100"); if (this._percMin != percMin || this._percMax != percMax) {
/*     */       this._percMin = percMin; this._percMax = percMax; this._usePercentiles = true; updateClips(); repaint();
/*     */     }  }
/* 405 */   private void updateClips() { if (this._usePercentiles) {
/* 406 */       int n1 = this._s1.getCount();
/* 407 */       int n2 = this._s2.getCount();
/* 408 */       int n = n1 * n2;
/* 409 */       float[] a = null;
/* 410 */       if (this._percMin != 0.0F || this._percMax != 100.0F)
/* 411 */         a = Array.flatten(this._f); 
/* 412 */       int kmin = (int)MathPlus.rint(this._percMin * 0.01D * (n - 1));
/* 413 */       if (kmin <= 0) {
/* 414 */         this._clipMin = Array.min(this._f);
/*     */       } else {
/* 416 */         Array.quickPartialSort(kmin, a);
/* 417 */         this._clipMin = a[kmin];
/*     */       } 
/* 419 */       int kmax = (int)MathPlus.rint(this._percMax * 0.01D * (n - 1));
/* 420 */       if (kmax >= n - 1) {
/* 421 */         this._clipMax = Array.max(this._f);
/*     */       } else {
/* 423 */         Array.quickPartialSort(kmax, a);
/* 424 */         this._clipMax = a[kmax];
/*     */       } 
/* 426 */       if (this._clipMin == this._clipMax) {
/* 427 */         double tiny = MathPlus.max(1.0D, (Math.ulp(1.0F) * MathPlus.abs(this._clipMin)));
/* 428 */         this._clipMin = (float)(this._clipMin - tiny);
/* 429 */         this._clipMax = (float)(this._clipMax + tiny);
/*     */       } 
/* 431 */       this._colorMap.setValueRange(this._clipMin, this._clipMax);
/*     */     }  }
/*     */ 
/*     */   
/*     */   public float getPercentileMin() {
/*     */     return this._percMin;
/*     */   }
/*     */   
/*     */   public float getPercentileMax() {
/*     */     return this._percMax;
/*     */   }
/*     */   
/*     */   private void updateSampling() {
/* 444 */     int n1 = this._s1.getCount();
/* 445 */     int n2 = this._s2.getCount();
/* 446 */     double d1 = this._s1.getDelta();
/* 447 */     double d2 = this._s2.getDelta();
/* 448 */     double f1 = this._s1.getFirst();
/* 449 */     double f2 = this._s2.getFirst();
/* 450 */     if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 451 */       this._transposed = true;
/* 452 */       this._xflipped = false;
/* 453 */       this._yflipped = false;
/* 454 */       this._nx = n2;
/* 455 */       this._dx = d2;
/* 456 */       this._fx = f2;
/* 457 */       this._ny = n1;
/* 458 */       this._dy = d1;
/* 459 */       this._fy = f1;
/* 460 */     } else if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 461 */       this._transposed = false;
/* 462 */       this._xflipped = false;
/* 463 */       this._yflipped = true;
/* 464 */       this._nx = n1;
/* 465 */       this._dx = d1;
/* 466 */       this._fx = f1;
/* 467 */       this._ny = n2;
/* 468 */       this._dy = d2;
/* 469 */       this._fy = f2;
/*     */     } 
/* 471 */     updateBestProjectors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addColorMapListener(ColorMapListener cml) {
/*     */     this._colorMap.addListener(cml);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateBestProjectors() {
/* 481 */     double x0 = this._fx;
/* 482 */     double x1 = this._fx + this._dx * (this._nx - 1);
/* 483 */     double y0 = this._fy;
/* 484 */     double y1 = this._fy + this._dy * (this._ny - 1);
/* 485 */     if (this._xflipped) {
/* 486 */       double xt = y0;
/* 487 */       x0 = x1;
/* 488 */       x1 = xt;
/*     */     } 
/* 490 */     if (this._yflipped) {
/* 491 */       double yt = y0;
/* 492 */       y0 = y1;
/* 493 */       y1 = yt;
/*     */     } 
/*     */ 
/*     */     
/* 497 */     if (x0 == x1) {
/* 498 */       double tiny = MathPlus.max(0.5D, 1.1920928955078125E-7D * MathPlus.abs(x0));
/* 499 */       x0 -= tiny;
/* 500 */       x1 += tiny;
/*     */     } 
/* 502 */     if (y0 == y1) {
/* 503 */       double tiny = MathPlus.max(0.5D, 1.1920928955078125E-7D * MathPlus.abs(y0));
/* 504 */       y0 -= tiny;
/* 505 */       y1 += tiny;
/*     */     } 
/*     */ 
/*     */     
/* 509 */     double uxMargin = (this._nx > 1) ? (0.5D / this._nx) : 0.0D;
/* 510 */     double uyMargin = (this._ny > 1) ? (0.5D / this._ny) : 0.0D;
/*     */ 
/*     */ 
/*     */     
/* 514 */     double ux0 = uxMargin;
/* 515 */     double uy0 = uyMargin;
/* 516 */     double ux1 = 1.0D - uxMargin;
/* 517 */     double uy1 = 1.0D - uyMargin;
/*     */ 
/*     */     
/* 520 */     Projector bhp = new Projector(x0, x1, ux0, ux1);
/* 521 */     Projector bvp = new Projector(y0, y1, uy0, uy1);
/* 522 */     setBestProjectors(bhp, bvp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeColorMapListener(ColorMapListener cml) {
/*     */     this._colorMap.removeListener(cml);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] interpolateImageBytesLinear(int nx, double dx, double fx, int ny, double dy, double fy) {
/* 535 */     byte[] b = new byte[nx * ny];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 543 */     float[] temp1 = new float[nx];
/* 544 */     float[] temp2 = new float[nx];
/* 545 */     int jy1 = -2;
/*     */ 
/*     */     
/* 548 */     int[] kf = new int[nx];
/* 549 */     float[] wf = new float[nx];
/* 550 */     for (int ix = 0; ix < nx; ix++) {
/* 551 */       double xi = fx + ix * dx;
/* 552 */       double xn = (xi - this._fx) / this._dx;
/* 553 */       if (xn <= 0.0D) {
/* 554 */         kf[ix] = 0;
/* 555 */         wf[ix] = 0.0F;
/* 556 */       } else if (xn >= (this._nx - 1)) {
/* 557 */         kf[ix] = this._nx - 2;
/* 558 */         wf[ix] = 1.0F;
/*     */       } else {
/* 560 */         kf[ix] = (int)xn;
/* 561 */         wf[ix] = (float)(xn - (int)xn);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 566 */     for (int iy = 0; iy < ny; iy++) {
/* 567 */       double yi = fy + iy * dy;
/*     */ 
/*     */       
/* 570 */       double yn = MathPlus.max(0.0D, MathPlus.min((this._ny - 1), (yi - this._fy) / this._dy));
/* 571 */       int jy = MathPlus.max(0, MathPlus.min(this._ny - 2, (int)yn));
/*     */ 
/*     */       
/* 574 */       if (jy != jy1 || iy == 0) {
/*     */ 
/*     */         
/* 577 */         if (jy == jy1 + 1 && iy != 0) {
/* 578 */           float[] temp = temp1;
/* 579 */           temp1 = temp2;
/* 580 */           temp2 = temp;
/* 581 */           interpx(MathPlus.min(jy + 1, this._ny - 1), nx, kf, wf, temp2);
/*     */ 
/*     */         
/*     */         }
/* 585 */         else if (jy == jy1 - 1 && iy != 0) {
/* 586 */           float[] temp = temp1;
/* 587 */           temp1 = temp2;
/* 588 */           temp2 = temp;
/* 589 */           interpx(jy, nx, kf, wf, temp1);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 594 */           interpx(jy, nx, kf, wf, temp1);
/* 595 */           interpx(MathPlus.min(jy + 1, this._ny - 1), nx, kf, wf, temp2);
/*     */         } 
/*     */ 
/*     */         
/* 599 */         jy1 = jy;
/*     */       } 
/*     */ 
/*     */       
/* 603 */       double frac = yn - jy;
/* 604 */       interpy(nx, frac, temp1, temp2, iy * nx, b);
/*     */     } 
/* 606 */     return b;
/*     */   } public void paint(Graphics2D g2d) { byte[] b; Projector hp = getHorizontalProjector(); Projector vp = getVerticalProjector(); Transcaler ts = getTranscaler(); double vx0 = this._fx - 0.5D * this._dx; double vx1 = this._fx + this._dx * (this._nx - 0.5D); double vy0 = this._fy - 0.5D * this._dy; double vy1 = this._fy + this._dy * (this._ny - 0.5D); double ux0 = hp.u(vx0); double ux1 = hp.u(vx1); double uy0 = vp.u(vy0); double uy1 = vp.u(vy1); double uxmin = MathPlus.min(ux0, ux1); double uxmax = MathPlus.max(ux0, ux1); double uymin = MathPlus.min(uy0, uy1); double uymax = MathPlus.max(uy0, uy1); int xd = ts.x(uxmin); int yd = ts.y(uymin); int wd = ts.width(uxmax - uxmin); int hd = ts.height(uymax - uymin); Rectangle viewRect = new Rectangle(xd, yd, wd, hd); Rectangle clipRect = g2d.getClipBounds(); if (clipRect == null)
/*     */       clipRect = viewRect;  clipRect = clipRect.intersection(viewRect); if (clipRect.isEmpty())
/*     */       return;  int xc = clipRect.x; int yc = clipRect.y; int wc = clipRect.width; int hc = clipRect.height; double xu = ts.x(xc); double yu = ts.y(yc); double wu = ts.width(wc); double hu = ts.height(hc); double x0 = hp.v(xu); double y0 = vp.v(yu); double x1 = hp.v(xu + wu); double y1 = vp.v(yu + hu); int nx = wc; int ny = hc; double dx = (x1 - x0) / MathPlus.max(1, nx - 1); double dy = (y1 - y0) / MathPlus.max(1, ny - 1); double fx = x0; double fy = y0; if (this._interpolation == Interpolation.LINEAR) {
/*     */       b = interpolateImageBytesLinear(nx, dx, fx, ny, dy, fy);
/*     */     } else {
/*     */       b = interpolateImageBytesNearest(nx, dx, fx, ny, dy, fy);
/*     */     }  ColorModel colorModel = this._colorMap.getColorModel(); DataBuffer db = new DataBufferByte(b, nx * ny, 0); int dataType = 0; int[] bitMasks = { 255 }; SampleModel sm = new SinglePixelPackedSampleModel(dataType, nx, ny, bitMasks); WritableRaster wr = Raster.createWritableRaster(sm, db, null); BufferedImage bi = new BufferedImage(colorModel, wr, false, null);
/* 614 */     g2d.drawImage(bi, xc, yc, (ImageObserver)null); } private void interpx(int jy, int nx, int[] kf, float[] wf, float[] t) { float fscale = 255.0F / (this._clipMax - this._clipMin);
/* 615 */     float fshift = this._clipMin;
/* 616 */     if (this._transposed) {
/* 617 */       if (this._nx == 1) {
/* 618 */         float fc = (this._f[0][jy] - fshift) * fscale;
/* 619 */         for (int ix = 0; ix < nx; ix++)
/* 620 */           t[ix] = fc; 
/*     */       } else {
/* 622 */         for (int ix = 0; ix < nx; ix++) {
/* 623 */           int kx = kf[ix];
/* 624 */           float wx = wf[ix];
/* 625 */           float f1 = (this._f[kx][jy] - fshift) * fscale;
/* 626 */           float f2 = (this._f[kx + 1][jy] - fshift) * fscale;
/* 627 */           t[ix] = (1.0F - wx) * f1 + wx * f2;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 631 */       float[] fjy = this._f[jy];
/* 632 */       if (this._nx == 1) {
/* 633 */         float fc = (fjy[0] - fshift) * fscale;
/* 634 */         for (int ix = 0; ix < nx; ix++)
/* 635 */           t[ix] = fc; 
/*     */       } else {
/* 637 */         for (int ix = 0; ix < nx; ix++) {
/* 638 */           int kx = kf[ix];
/* 639 */           float wx = wf[ix];
/* 640 */           float f1 = (fjy[kx] - fshift) * fscale;
/* 641 */           float f2 = (fjy[kx + 1] - fshift) * fscale;
/* 642 */           t[ix] = (1.0F - wx) * f1 + wx * f2;
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void interpy(int nx, double frac, float[] temp1, float[] temp2, int kb, byte[] b) {
/* 654 */     float w2 = (float)frac;
/* 655 */     float w1 = 1.0F - w2;
/* 656 */     for (int ix = 0, ib = kb; ix < nx; ix++, ib++) {
/* 657 */       float ti = w1 * temp1[ix] + w2 * temp2[ix];
/* 658 */       if (ti < 0.0F)
/* 659 */         ti = 0.0F; 
/* 660 */       if (ti > 255.0F)
/* 661 */         ti = 255.0F; 
/* 662 */       b[ib] = (byte)(int)(ti + 0.5F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] interpolateImageBytesNearest(int nx, double dx, double fx, int ny, double dy, double fy) {
/* 676 */     byte[] b = new byte[nx * ny];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 682 */     byte[] temp = new byte[nx];
/* 683 */     int jytemp = -1;
/*     */ 
/*     */     
/* 686 */     int[] kf = new int[nx];
/* 687 */     for (int ix = 0; ix < nx; ix++) {
/* 688 */       double xi = fx + ix * dx;
/* 689 */       double xn = (xi - this._fx) / this._dx;
/* 690 */       if (xn <= 0.0D) {
/* 691 */         kf[ix] = 0;
/* 692 */       } else if (xn >= (this._nx - 1)) {
/* 693 */         kf[ix] = this._nx - 1;
/*     */       } else {
/* 695 */         kf[ix] = (int)(xn + 0.5D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 700 */     for (int iy = 0; iy < ny; iy++) {
/* 701 */       double yi = fy + iy * dy;
/*     */ 
/*     */       
/* 704 */       double yn = MathPlus.max(0.0D, MathPlus.min((this._ny - 1), (yi - this._fy) / this._dy));
/* 705 */       int jy = MathPlus.max(0, MathPlus.min(this._ny - 1, (int)(yn + 0.5D)));
/*     */ 
/*     */       
/* 708 */       if (jy != jytemp) {
/* 709 */         interpx(jy, nx, kf, temp);
/* 710 */         jytemp = jy;
/*     */       } 
/*     */ 
/*     */       
/* 714 */       for (int i = 0, j = iy * nx; i < nx; i++, j++) {
/* 715 */         b[j] = temp[i];
/*     */       }
/*     */     } 
/* 718 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void interpx(int jy, int nx, int[] kf, byte[] b) {
/* 725 */     float fscale = 255.0F / (this._clipMax - this._clipMin);
/* 726 */     float fshift = this._clipMin;
/* 727 */     if (this._transposed) {
/* 728 */       for (int ix = 0; ix < nx; ix++) {
/* 729 */         int kx = kf[ix];
/* 730 */         float fi = (this._f[kx][jy] - fshift) * fscale;
/* 731 */         if (fi < 0.0F)
/* 732 */           fi = 0.0F; 
/* 733 */         if (fi > 255.0F)
/* 734 */           fi = 255.0F; 
/* 735 */         b[ix] = (byte)(int)(fi + 0.5F);
/*     */       } 
/*     */     } else {
/* 738 */       float[] fjy = this._f[jy];
/* 739 */       for (int ix = 0; ix < nx; ix++) {
/* 740 */         int kx = kf[ix];
/* 741 */         float fi = (fjy[kx] - fshift) * fscale;
/* 742 */         if (fi < 0.0F)
/* 743 */           fi = 0.0F; 
/* 744 */         if (fi > 255.0F)
/* 745 */           fi = 255.0F; 
/* 746 */         b[ix] = (byte)(int)(fi + 0.5F);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/PixelsView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */