/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class View
/*     */ {
/*     */   private World _world;
/*     */   private Matrix44 _worldToView;
/*     */   private ArrayList<ViewCanvas> _canvasList;
/*     */   private Tuple3 _axesScale;
/*     */   private AxesOrientation _axesOrientation;
/*     */   
/*     */   public enum AxesOrientation
/*     */   {
/*  51 */     XRIGHT_YUP_ZOUT,
/*  52 */     XRIGHT_YOUT_ZDOWN,
/*  53 */     XRIGHT_YIN_ZDOWN,
/*  54 */     XOUT_YRIGHT_ZUP;
/*     */   }
/*     */   
/*     */   public AxesOrientation getAxesOrientation() {
/*  58 */     return this._axesOrientation;
/*     */   }
/*     */   
/*     */   public void setAxesOrientation(AxesOrientation axesOrientation) {
/*  62 */     this._axesOrientation = axesOrientation;
/*  63 */     updateTransforms();
/*  64 */     repaint();
/*     */   }
/*     */   
/*     */   public Tuple3 getAxesScale() {
/*  68 */     return new Tuple3(this._axesScale);
/*     */   }
/*     */   
/*     */   public void setAxesScale(Tuple3 s) {
/*  72 */     setAxesScale(s.x, s.y, s.z);
/*     */   }
/*     */   
/*     */   public void setAxesScale(double sx, double sy, double sz) {
/*  76 */     this._axesScale = new Tuple3(sx, sy, sz);
/*  77 */     updateTransforms();
/*  78 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public View() {
/* 224 */     this._worldToView = Matrix44.identity();
/* 225 */     this._canvasList = new ArrayList<ViewCanvas>(1);
/* 226 */     this._axesScale = new Tuple3(1.0D, 1.0D, 1.0D);
/* 227 */     this._axesOrientation = AxesOrientation.XRIGHT_YUP_ZOUT; } public View(World world) { this._worldToView = Matrix44.identity(); this._canvasList = new ArrayList<ViewCanvas>(1); this._axesScale = new Tuple3(1.0D, 1.0D, 1.0D); this._axesOrientation = AxesOrientation.XRIGHT_YUP_ZOUT;
/*     */     setWorld(world); }
/*     */ 
/*     */   
/*     */   public void setWorld(World world) {
/*     */     if (this._world != null)
/*     */       this._world.removeView(this); 
/*     */     this._world = world;
/*     */     if (this._world != null)
/*     */       this._world.addView(this); 
/*     */     updateTransforms();
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public World getWorld() {
/*     */     return this._world;
/*     */   }
/*     */   
/*     */   public void setWorldToView(Matrix44 worldToView) {
/*     */     this._worldToView = new Matrix44(worldToView);
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public Matrix44 getWorldToView() {
/*     */     return new Matrix44(this._worldToView);
/*     */   }
/*     */   
/*     */   public int countCanvases() {
/*     */     return this._canvasList.size();
/*     */   }
/*     */   
/*     */   public Iterator<ViewCanvas> getCanvases() {
/*     */     return this._canvasList.iterator();
/*     */   }
/*     */   
/*     */   public void updateTransforms() {
/*     */     for (ViewCanvas canvas : this._canvasList)
/*     */       updateTransforms(canvas); 
/*     */   }
/*     */   
/*     */   public void repaint() {
/*     */     for (ViewCanvas canvas : this._canvasList)
/*     */       canvas.repaint(); 
/*     */   }
/*     */   
/*     */   protected abstract void updateTransforms(ViewCanvas paramViewCanvas);
/*     */   
/*     */   protected abstract void draw(ViewCanvas paramViewCanvas);
/*     */   
/*     */   boolean addCanvas(ViewCanvas canvas) {
/*     */     if (!this._canvasList.contains(canvas)) {
/*     */       this._canvasList.add(canvas);
/*     */       updateTransforms();
/*     */       repaint();
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean removeCanvas(ViewCanvas canvas) {
/*     */     if (this._canvasList.remove(canvas)) {
/*     */       updateTransforms();
/*     */       repaint();
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/View.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */