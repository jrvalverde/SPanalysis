/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Axis
/*    */ {
/* 15 */   X, Y, Z;
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Axis.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */