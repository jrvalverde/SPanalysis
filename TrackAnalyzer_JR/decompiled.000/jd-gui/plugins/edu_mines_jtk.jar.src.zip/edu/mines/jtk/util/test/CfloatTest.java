/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.Cfloat;
/*    */ import edu.mines.jtk.util.MathPlus;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfloatTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(CfloatTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */ 
/*    */   
/*    */   public void test() {
/* 29 */     Cfloat a = new Cfloat(3.1415927F, 2.7182817F);
/* 30 */     Cfloat b = new Cfloat(2.7182817F, 3.1415927F);
/*    */     
/* 32 */     assertEquals(a, Cfloat.sub(Cfloat.add(a, b), b));
/* 33 */     assertEquals(a, Cfloat.div(Cfloat.mul(a, b), b));
/*    */     
/* 35 */     assertEquals(a, Cfloat.conj(Cfloat.conj(a)));
/*    */     
/* 37 */     assertEquals(a, Cfloat.polar(Cfloat.abs(a), Cfloat.arg(a)));
/*    */     
/* 39 */     assertEquals(a, Cfloat.exp(Cfloat.log(a)));
/*    */     
/* 41 */     assertEquals(a, Cfloat.pow(Cfloat.sqrt(a), 2.0F));
/*    */     
/* 43 */     assertEquals(Cfloat.pow(a, b), Cfloat.exp(b.times(Cfloat.log(a))));
/*    */     
/* 45 */     assertEquals(Cfloat.pow(a, b), Cfloat.exp(b.times(Cfloat.log(a))));
/*    */     
/* 47 */     assertEquals(Cfloat.sin(Cfloat.FLT_I.times(a)), Cfloat.FLT_I.times(Cfloat.sinh(a)));
/*    */ 
/*    */     
/* 50 */     assertEquals(Cfloat.cos(Cfloat.FLT_I.times(a)), Cfloat.cosh(a));
/*    */     
/* 52 */     assertEquals(Cfloat.tan(Cfloat.FLT_I.times(a)), Cfloat.FLT_I.times(Cfloat.tanh(a)));
/*    */   }
/*    */ 
/*    */   
/*    */   private void assertEquals(float expected, float actual) {
/* 57 */     float small = 1.0E-6F * MathPlus.max(MathPlus.abs(expected), MathPlus.abs(actual), 1.0F);
/* 58 */     assertEquals(expected, actual, small);
/*    */   }
/*    */   
/*    */   private void assertEquals(Cfloat expected, Cfloat actual) {
/* 62 */     assertEquals(expected.r, actual.r);
/* 63 */     assertEquals(expected.i, actual.i);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/CfloatTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */