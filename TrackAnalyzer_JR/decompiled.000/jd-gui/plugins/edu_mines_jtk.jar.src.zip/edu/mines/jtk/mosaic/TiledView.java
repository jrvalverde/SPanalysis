/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TiledView
/*     */ {
/*     */   private Tile _tile;
/*     */   
/*     */   public abstract void paint(Graphics2D paramGraphics2D);
/*     */   
/*     */   public Tile getTile() {
/*  39 */     return this._tile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector getHorizontalProjector() {
/*  50 */     return (this._tile != null) ? this._tile.getHorizontalProjector() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector getVerticalProjector() {
/*  61 */     return (this._tile != null) ? this._tile.getVerticalProjector() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transcaler getTranscaler() {
/*  72 */     return (this._tile != null) ? this._tile.getTranscaler() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBestProjectors(Projector bhp, Projector bvp) {
/*  85 */     if (!equal(this._bhp, bhp) || !equal(this._bvp, bvp)) {
/*  86 */       this._bhp = (bhp != null) ? new Projector(bhp) : null;
/*  87 */       this._bvp = (bvp != null) ? new Projector(bvp) : null;
/*  88 */       if (this._tile != null) {
/*  89 */         this._tile.alignProjectors();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Projector getBestHorizontalProjector() {
/*  98 */     return this._bhp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Projector getBestVerticalProjector() {
/* 106 */     return this._bvp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repaint() {
/* 113 */     if (this._tile != null) {
/* 114 */       this._tile.repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float getLineWidth(Graphics2D g2d) {
/* 123 */     float lineWidth = 1.0F;
/* 124 */     Stroke stroke = g2d.getStroke();
/* 125 */     if (stroke instanceof BasicStroke) {
/* 126 */       BasicStroke bs = (BasicStroke)stroke;
/* 127 */       lineWidth = bs.getLineWidth();
/*     */     } 
/* 129 */     return lineWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTile(Tile tile) {
/* 139 */     this._tile = tile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private Projector _bhp = null;
/* 147 */   private Projector _bvp = null;
/*     */   
/*     */   private boolean equal(Projector a, Projector b) {
/* 150 */     return (a == null) ? ((b == null)) : a.equals(b);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/TiledView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */