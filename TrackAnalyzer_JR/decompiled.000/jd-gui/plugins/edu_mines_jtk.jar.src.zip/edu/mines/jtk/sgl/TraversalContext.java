/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TraversalContext
/*    */ {
/*    */   public int countNodes() {
/* 26 */     return this._nodeStack.size();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node getNode() {
/* 34 */     return this._nodeStack.peek();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node getNode(int index) {
/* 49 */     if (index < 0) {
/* 50 */       return this._nodeStack.get(index + countNodes());
/*    */     }
/* 52 */     return this._nodeStack.get(index);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node[] getNodes() {
/* 64 */     int nnode = this._nodeStack.size();
/* 65 */     Node[] nodes = new Node[nnode];
/* 66 */     for (int inode = 0; inode < nnode; inode++)
/* 67 */       nodes[inode] = this._nodeStack.get(inode); 
/* 68 */     return nodes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void pushNode(Node node) {
/* 76 */     this._nodeStack.push(node);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void popNode() {
/* 84 */     this._nodeStack.pop();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 90 */   private ArrayStack<Node> _nodeStack = new ArrayStack<Node>();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/TraversalContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */