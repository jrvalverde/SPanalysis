/*     */ package edu.mines.jtk.bench;
/*     */ 
/*     */ import edu.mines.jtk.io.ArrayFile;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteOrder;
/*     */ import junit.framework.TestCase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayFileBench
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  26 */     benchBigEndian();
/*  27 */     benchLittleEndian();
/*     */   }
/*     */   
/*     */   public static void benchBigEndian() {
/*  31 */     bench(ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */   
/*     */   public static void benchLittleEndian() {
/*  35 */     bench(ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void bench(ByteOrder order) {
/*  42 */     System.out.println("order=" + order);
/*  43 */     int n = 1000000;
/*  44 */     File file = null;
/*  45 */     ArrayFile af = null;
/*     */     try {
/*  47 */       file = File.createTempFile("junk", "dat");
/*  48 */       af = new ArrayFile(file, "rw", order, order);
/*  49 */       benchFloat(af, n);
/*  50 */       benchDouble(af, n);
/*  51 */       if (af != null)
/*  52 */         af.close(); 
/*  53 */       if (file != null)
/*  54 */         file.delete(); 
/*  55 */     } catch (IOException ioe) {
/*  56 */       throw new RuntimeException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void benchFloat(ArrayFile af, int n) throws IOException {
/*  63 */     float[] a = Array.randfloat(n);
/*  64 */     float[] b = Array.zerofloat(n);
/*     */     
/*  66 */     Stopwatch sw = new Stopwatch();
/*  67 */     sw.start(); int nio;
/*  68 */     for (nio = 0; sw.time() < 5.0D; nio++) {
/*  69 */       af.seek(0L);
/*  70 */       af.writeFloats(a);
/*  71 */       af.seek(0L);
/*  72 */       af.readFloats(b);
/*     */     } 
/*  74 */     sw.stop();
/*  75 */     for (int i = 0; i < n; i++) {
/*  76 */       if (a[i] != b[i])
/*  77 */         throw new RuntimeException(" float: i/o failure"); 
/*  78 */     }  double time = sw.time();
/*  79 */     double rate = 8.0E-6D * nio * n / time;
/*  80 */     System.out.println(" float: rate=" + rate + " MB/s");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void benchDouble(ArrayFile af, int n) throws IOException {
/*  86 */     double[] a = Array.randdouble(n);
/*  87 */     double[] b = Array.zerodouble(n);
/*     */     
/*  89 */     Stopwatch sw = new Stopwatch();
/*  90 */     sw.start(); int nio;
/*  91 */     for (nio = 0; sw.time() < 5.0D; nio++) {
/*  92 */       af.seek(0L);
/*  93 */       af.writeDoubles(a);
/*  94 */       af.seek(0L);
/*  95 */       af.readDoubles(b);
/*     */     } 
/*  97 */     sw.stop();
/*  98 */     for (int i = 0; i < n; i++) {
/*  99 */       if (a[i] != b[i])
/* 100 */         throw new RuntimeException("double: i/o failure"); 
/* 101 */     }  double time = sw.time();
/* 102 */     double rate = 1.6E-5D * nio * n / time;
/* 103 */     System.out.println("double: rate=" + rate + " MB/s");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/ArrayFileBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */