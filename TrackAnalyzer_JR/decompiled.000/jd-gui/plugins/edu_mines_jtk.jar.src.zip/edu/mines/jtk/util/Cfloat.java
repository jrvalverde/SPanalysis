/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cfloat
/*     */ {
/*  19 */   public static final Cfloat FLT_I = new Cfloat(0.0F, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float r;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float i;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat() {
/*  35 */     this(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat(float r) {
/*  43 */     this(r, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat(float r, float i) {
/*  52 */     this.r = r;
/*  53 */     this.i = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat(Cfloat x) {
/*  61 */     this(x.r, x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat plus(Cfloat x) {
/*  70 */     return (new Cfloat(this)).plusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat minus(Cfloat x) {
/*  79 */     return (new Cfloat(this)).minusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat times(Cfloat x) {
/*  88 */     return (new Cfloat(this)).timesEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat over(Cfloat x) {
/*  97 */     return (new Cfloat(this)).overEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat plus(float x) {
/* 106 */     return (new Cfloat(this)).plusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat minus(float x) {
/* 115 */     return (new Cfloat(this)).minusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat times(float x) {
/* 124 */     return (new Cfloat(this)).timesEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat over(float x) {
/* 133 */     return (new Cfloat(this)).overEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat plusEquals(Cfloat x) {
/* 142 */     this.r += x.r;
/* 143 */     this.i += x.i;
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat minusEquals(Cfloat x) {
/* 153 */     this.r -= x.r;
/* 154 */     this.i -= x.i;
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat timesEquals(Cfloat x) {
/* 164 */     float tr = this.r;
/* 165 */     float ti = this.i;
/* 166 */     float xr = x.r;
/* 167 */     float xi = x.i;
/* 168 */     this.r = tr * xr - ti * xi;
/* 169 */     this.i = tr * xi + ti * xr;
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat overEquals(Cfloat x) {
/* 179 */     float tr = this.r;
/* 180 */     float ti = this.i;
/* 181 */     float xr = x.r;
/* 182 */     float xi = x.i;
/* 183 */     float d = norm(x);
/* 184 */     this.r = (tr * xr + ti * xi) / d;
/* 185 */     this.i = (ti * xr - tr * xi) / d;
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat plusEquals(float x) {
/* 195 */     this.r += x;
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat minusEquals(float x) {
/* 205 */     this.r -= x;
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat timesEquals(float x) {
/* 215 */     this.r *= x;
/* 216 */     this.i *= x;
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat overEquals(float x) {
/* 226 */     this.r /= x;
/* 227 */     this.i /= x;
/* 228 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat conjEquals() {
/* 236 */     this.i = -this.i;
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat invEquals() {
/* 245 */     this.r = -this.r;
/* 246 */     this.i = -this.i;
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat negEquals() {
/* 255 */     float d = norm();
/* 256 */     this.r /= d;
/* 257 */     this.i = -this.i / d;
/* 258 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReal() {
/* 266 */     return (this.i == 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImag() {
/* 274 */     return (this.r == 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat conj() {
/* 282 */     return new Cfloat(this.r, -this.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat inv() {
/* 290 */     float d = norm();
/* 291 */     return new Cfloat(this.r / d, -this.i / d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat neg() {
/* 299 */     return new Cfloat(-this.r, -this.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float abs() {
/* 307 */     return abs(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float arg() {
/* 315 */     return arg(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float norm() {
/* 324 */     return norm(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat sqrt() {
/* 332 */     return sqrt(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat exp() {
/* 340 */     return exp(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat log() {
/* 348 */     return log(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat log10() {
/* 356 */     return log10(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat pow(float y) {
/* 365 */     return pow(this, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat pow(Cfloat y) {
/* 374 */     return pow(this, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat sin() {
/* 382 */     return sin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat cos() {
/* 390 */     return cos(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat tan() {
/* 398 */     return tan(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat sinh() {
/* 406 */     return sinh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat cosh() {
/* 414 */     return cosh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat tanh() {
/* 422 */     return tanh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isReal(Cfloat x) {
/* 431 */     return (x.i == 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isImag(Cfloat x) {
/* 440 */     return (x.r == 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat conj(Cfloat x) {
/* 449 */     return new Cfloat(x.r, -x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cfloat inv(Cfloat x) {
/* 458 */     float d = x.norm();
/* 459 */     return new Cfloat(x.r / d, -x.i / d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat neg(Cfloat x) {
/* 468 */     return new Cfloat(-x.r, -x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat polar(float r, float a) {
/* 478 */     return new Cfloat(r * cos(a), r * sin(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat add(Cfloat x, Cfloat y) {
/* 488 */     return x.plus(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat sub(Cfloat x, Cfloat y) {
/* 498 */     return x.minus(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat mul(Cfloat x, Cfloat y) {
/* 508 */     return x.times(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat div(Cfloat x, Cfloat y) {
/* 518 */     return x.over(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float abs(Cfloat x) {
/* 527 */     float ar = abs(x.r);
/* 528 */     float ai = abs(x.i);
/* 529 */     float s = max(abs(ar), abs(ai));
/* 530 */     if (s == 0.0F)
/* 531 */       return 0.0F; 
/* 532 */     ar /= s;
/* 533 */     ai /= s;
/* 534 */     return s * sqrt(ar * ar + ai * ai);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float arg(Cfloat x) {
/* 543 */     return atan2(x.i, x.r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float norm(Cfloat x) {
/* 553 */     return x.r * x.r + x.i * x.i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat sqrt(Cfloat x) {
/* 562 */     if (x.r == 0.0F) {
/* 563 */       float f = sqrt(0.5F * abs(x.i));
/* 564 */       return new Cfloat(f, (x.i < 0.0F) ? -f : f);
/*     */     } 
/* 566 */     float t = sqrt(2.0F * (abs(x) + abs(x.r)));
/* 567 */     float u = 0.5F * t;
/* 568 */     return (x.r > 0.0F) ? new Cfloat(u, x.i / t) : new Cfloat(abs(x.i) / t, (x.i < 0.0F) ? -u : u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat exp(Cfloat x) {
/* 580 */     return polar(exp(x.r), x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat log(Cfloat x) {
/* 589 */     return new Cfloat(log(abs(x)), arg(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat log10(Cfloat x) {
/* 598 */     return log(x).overEquals(log(10.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat pow(Cfloat x, float y) {
/* 608 */     if (x.i == 0.0F)
/* 609 */       return new Cfloat(pow(x.r, y)); 
/* 610 */     Cfloat t = log(x);
/* 611 */     return polar(exp(y * t.r), y * t.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat pow(float x, Cfloat y) {
/* 621 */     if (x == 0.0F)
/* 622 */       return new Cfloat(); 
/* 623 */     return polar(pow(x, y.r), y.i * log(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat pow(Cfloat x, Cfloat y) {
/* 633 */     if (x.r == 0.0F && x.i == 0.0F)
/* 634 */       return new Cfloat(); 
/* 635 */     return exp(y.times(log(x)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat sin(Cfloat x) {
/* 644 */     return new Cfloat(sin(x.r) * cosh(x.i), cos(x.r) * sinh(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat cos(Cfloat x) {
/* 653 */     return new Cfloat(cos(x.r) * cosh(x.i), -sin(x.r) * sinh(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat tan(Cfloat x) {
/* 662 */     return sin(x).overEquals(cos(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat sinh(Cfloat x) {
/* 671 */     return new Cfloat(sinh(x.r) * cos(x.i), cosh(x.r) * sin(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat cosh(Cfloat x) {
/* 680 */     return new Cfloat(cosh(x.r) * cos(x.i), sinh(x.r) * sin(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cfloat tanh(Cfloat x) {
/* 689 */     return sinh(x).overEquals(cosh(x));
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 693 */     if (this == obj)
/* 694 */       return true; 
/* 695 */     if (obj == null || getClass() != obj.getClass())
/* 696 */       return false; 
/* 697 */     Cfloat that = (Cfloat)obj;
/* 698 */     return (this.r == that.r && this.i == that.i);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 702 */     return Float.floatToIntBits(this.r) ^ Float.floatToIntBits(this.i);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 706 */     if (this.i == 0.0F)
/* 707 */       return "(" + this.r + "+0.0i)"; 
/* 708 */     if (this.i > 0.0F) {
/* 709 */       return "(" + this.r + "+" + this.i + "i)";
/*     */     }
/* 711 */     return "(" + this.r + "-" + -this.i + "i)";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float max(float x, float y) {
/* 719 */     return (x >= y) ? x : y;
/*     */   }
/*     */   
/*     */   private static float abs(float x) {
/* 723 */     return (x >= 0.0F) ? x : -x;
/*     */   }
/*     */   
/*     */   private static float sqrt(float x) {
/* 727 */     return (float)Math.sqrt(x);
/*     */   }
/*     */   
/*     */   private static float sin(float x) {
/* 731 */     return (float)Math.sin(x);
/*     */   }
/*     */   
/*     */   private static float cos(float x) {
/* 735 */     return (float)Math.cos(x);
/*     */   }
/*     */   
/*     */   private static float sinh(float x) {
/* 739 */     return (float)Math.sinh(x);
/*     */   }
/*     */   
/*     */   private static float cosh(float x) {
/* 743 */     return (float)Math.cosh(x);
/*     */   }
/*     */   
/*     */   private static float exp(float x) {
/* 747 */     return (float)Math.exp(x);
/*     */   }
/*     */   
/*     */   private static float log(float x) {
/* 751 */     return (float)Math.log(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float pow(float x, float y) {
/* 761 */     return (float)Math.pow(x, y);
/*     */   }
/*     */   
/*     */   private static float atan2(float y, float x) {
/* 765 */     return (float)Math.atan2(y, x);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Cfloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */