/*     */ package edu.mines.jtk.ogl;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import javax.media.opengl.GLContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlDisplayList
/*     */ {
/*     */   GLContext _context;
/*     */   int _list;
/*     */   int _range;
/*     */   
/*     */   public GlDisplayList() {
/*  42 */     this(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlDisplayList(int range) {
/*  52 */     this._context = GLContext.getCurrent();
/*  53 */     Check.state((this._context != null), "OpenGL context is not null");
/*  54 */     this._list = Gl.glGenLists(range);
/*  55 */     this._range = range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int list() {
/*  64 */     return this._list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int range() {
/*  72 */     return this._range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/*  81 */     if (this._context != null) {
/*  82 */       GLContext current = GLContext.getCurrent();
/*  83 */       if (this._context == current || this._context.makeCurrent() == 1) {
/*     */         
/*     */         try {
/*  86 */           Gl.glDeleteLists(this._list, this._range);
/*     */         } finally {
/*  88 */           if (this._context != current) {
/*  89 */             this._context.release();
/*  90 */             current.makeCurrent();
/*     */           } 
/*     */         } 
/*     */       }
/*  94 */       this._context = null;
/*  95 */       this._list = 0;
/*  96 */       this._range = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*     */     try {
/* 105 */       dispose();
/*     */     } finally {
/* 107 */       super.finalize();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/GlDisplayList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */