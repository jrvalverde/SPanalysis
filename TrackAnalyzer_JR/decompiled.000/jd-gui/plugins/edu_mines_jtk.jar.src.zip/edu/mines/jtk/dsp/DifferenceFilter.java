/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DifferenceFilter
/*     */ {
/*     */   private static final float AP1 = -0.999F;
/*     */   private static final float A0P0 = 1.7954845F;
/*     */   private static final float A0P1 = -0.64490664F;
/*     */   private static final float A0P2 = -0.03850411F;
/*     */   private static final float A0P3 = -0.01793403F;
/*     */   private static final float A0P4 = -0.00708972F;
/*     */   private static final float APM0 = -0.5565992F;
/*     */   private static final float APM1 = -0.20031442F;
/*     */   private static final float APM2 = -0.08457147F;
/*     */   private static final float APM3 = -0.04141619F;
/*     */   private static final float APM4 = -0.02290331F;
/*     */   private static final float AIP0 = 0.5569527F;
/*     */   private static final float A00P0 = 2.3110454F;
/*     */   private static final float A00P1 = -0.4805547F;
/*     */   private static final float A00P2 = -0.0143204F;
/*     */   private static final float A0PM2 = -0.0291793F;
/*     */   private static final float A0PM1 = -0.1057476F;
/*     */   private static final float A0PP0 = -0.4572746F;
/*     */   private static final float A0PP1 = -0.0115732F;
/*     */   private static final float A0PP2 = -0.0047283F;
/*     */   private static final float APMM2 = -0.0149963F;
/*     */   private static final float APMM1 = -0.0408317F;
/*     */   private static final float APMP0 = -0.0945958F;
/*     */   private static final float APMP1 = -0.0223166F;
/*     */   private static final float APMP2 = -0.0062781F;
/*     */   private static final float AP0M2 = -0.0213786F;
/*     */   private static final float AP0M1 = -0.0898909F;
/*     */   private static final float AP0P0 = -0.4322719F;
/*     */   private static final float AI0P0 = 0.4327046F;
/*     */   
/*     */   public void apply(float[] x, float[] y) {
/*  48 */     int n = y.length;
/*  49 */     y[0] = x[0];
/*  50 */     for (int i = 1; i < n; i++) {
/*  51 */       y[i] = x[i] + -0.999F * x[i - 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(float[][] x, float[][] y) {
/*  62 */     int n1 = (x[0]).length;
/*  63 */     int n2 = x.length;
/*  64 */     float xm4 = 0.0F, xm3 = xm4, xm2 = xm3, xm1 = xm2, xm0 = xm1;
/*  65 */     for (int i1 = 0; i1 < n1; i1++) {
/*  66 */       xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[0][i1];
/*  67 */       y[0][i1] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4;
/*     */     } 
/*  69 */     for (int i2 = 1; i2 < n2; i2++) {
/*  70 */       xm0 = xm1 = xm2 = xm3 = xm4 = 0.0F;
/*  71 */       float xp4 = 0.0F, xp3 = xp4, xp2 = xp3, xp1 = xp2, xp0 = xp1;
/*  72 */       if (n1 >= 4)
/*  73 */         xp4 = x[i2 - 1][3]; 
/*  74 */       if (n1 >= 3)
/*  75 */         xp3 = x[i2 - 1][2]; 
/*  76 */       if (n1 >= 2)
/*  77 */         xp2 = x[i2 - 1][1]; 
/*  78 */       if (n1 >= 1)
/*  79 */         xp1 = x[i2 - 1][0]; 
/*  80 */       for (int i = 0; i < n1 - 4; i++) {
/*  81 */         xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[i2][i];
/*  82 */         xp0 = xp1; xp1 = xp2; xp2 = xp3; xp3 = xp4; xp4 = x[i2 - 1][i + 4];
/*  83 */         y[i2][i] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4 + -0.5565992F * xp0 + -0.20031442F * xp1 + -0.08457147F * xp2 + -0.04141619F * xp3 + -0.02290331F * xp4;
/*     */       } 
/*     */       
/*  86 */       if (n1 >= 4) {
/*  87 */         xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[i2][n1 - 4];
/*  88 */         xp0 = xp1; xp1 = xp2; xp2 = xp3; xp3 = xp4;
/*  89 */         y[i2][n1 - 4] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4 + -0.5565992F * xp0 + -0.20031442F * xp1 + -0.08457147F * xp2 + -0.04141619F * xp3;
/*     */       } 
/*     */       
/*  92 */       if (n1 >= 3) {
/*  93 */         xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[i2][n1 - 3];
/*  94 */         xp0 = xp1; xp1 = xp2; xp2 = xp3;
/*  95 */         y[i2][n1 - 3] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4 + -0.5565992F * xp0 + -0.20031442F * xp1 + -0.08457147F * xp2;
/*     */       } 
/*     */       
/*  98 */       if (n1 >= 2) {
/*  99 */         xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[i2][n1 - 2];
/* 100 */         xp0 = xp1; xp1 = xp2;
/* 101 */         y[i2][n1 - 2] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4 + -0.5565992F * xp0 + -0.20031442F * xp1;
/*     */       } 
/*     */       
/* 104 */       if (n1 >= 1) {
/* 105 */         xm4 = xm3; xm3 = xm2; xm2 = xm1; xm1 = xm0; xm0 = x[i2][n1 - 1];
/* 106 */         xp0 = xp1;
/* 107 */         y[i2][n1 - 1] = 1.7954845F * xm0 + -0.64490664F * xm1 + -0.03850411F * xm2 + -0.01793403F * xm3 + -0.00708972F * xm4 + -0.5565992F * xp0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(float[][][] x, float[][][] y) {
/* 119 */     int n1 = (x[0][0]).length;
/* 120 */     int n2 = (x[0]).length;
/* 121 */     int n3 = x.length;
/* 122 */     int n2m1 = n2 - 1;
/* 123 */     for (int i3 = 0; i3 < n3; i3++) {
/* 124 */       for (int i2 = 0; i2 < n2; i2++) {
/* 125 */         float x0mm2 = 0.0F, x0mm1 = 0.0F, x0mm0 = 0.0F, x0mp1 = 0.0F, x0mp2 = 0.0F;
/* 126 */         float x00m2 = 0.0F, x00m1 = 0.0F, x00m0 = 0.0F;
/* 127 */         float xm0m0 = 0.0F, xm0p1 = 0.0F, xm0p2 = 0.0F;
/* 128 */         float xmpm2 = 0.0F, xmpm1 = 0.0F, xmpm0 = 0.0F, xmpp1 = 0.0F, xmpp2 = 0.0F;
/* 129 */         if (n1 > 0) {
/* 130 */           if (i2 > 0)
/* 131 */             x0mp1 = x[i3][i2 - 1][0]; 
/* 132 */           if (i3 > 0) {
/* 133 */             xm0p1 = x[i3 - 1][i2][0];
/* 134 */             if (i2 < n2m1)
/* 135 */               xmpp1 = x[i3 - 1][i2 + 1][0]; 
/*     */           } 
/*     */         } 
/* 138 */         if (n1 > 1) {
/* 139 */           if (i2 > 0)
/* 140 */             x0mp2 = x[i3][i2 - 1][1]; 
/* 141 */           if (i3 > 0) {
/* 142 */             xm0p2 = x[i3 - 1][i2][1];
/* 143 */             if (i2 < n2m1)
/* 144 */               xmpp2 = x[i3 - 1][i2 + 1][1]; 
/*     */           } 
/*     */         } 
/* 147 */         for (int i1 = 0; i1 < n1 - 2; i1++) {
/* 148 */           x00m2 = x00m1;
/* 149 */           x00m1 = x00m0;
/* 150 */           x00m0 = x[i3][i2][i1];
/* 151 */           if (i2 > 0) {
/* 152 */             x0mm2 = x0mm1;
/* 153 */             x0mm1 = x0mm0;
/* 154 */             x0mm0 = x0mp1;
/* 155 */             x0mp1 = x0mp2;
/* 156 */             x0mp2 = x[i3][i2 - 1][i1 + 2];
/*     */           } 
/* 158 */           if (i3 > 0) {
/* 159 */             if (i2 < n2m1) {
/* 160 */               xmpm2 = xmpm1;
/* 161 */               xmpm1 = xmpm0;
/* 162 */               xmpm0 = xmpp1;
/* 163 */               xmpp1 = xmpp2;
/* 164 */               xmpp2 = x[i3 - 1][i2 + 1][i1 + 2];
/*     */             } 
/* 166 */             xm0m0 = xm0p1;
/* 167 */             xm0p1 = xm0p2;
/* 168 */             xm0p2 = x[i3 - 1][i2][i1 + 2];
/*     */           } 
/* 170 */           y[i3][i2][i1] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.0291793F * x0mp2 + -0.1057476F * x0mp1 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0149963F * xmpp2 + -0.0408317F * xmpp1 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.0213786F * xm0p2 + -0.0898909F * xm0p1 + -0.4322719F * xm0m0;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 175 */         if (n1 > 1) {
/* 176 */           x00m2 = x00m1;
/* 177 */           x00m1 = x00m0;
/* 178 */           x00m0 = x[i3][i2][n1 - 2];
/* 179 */           x0mm2 = x0mm1;
/* 180 */           x0mm1 = x0mm0;
/* 181 */           x0mm0 = x0mp1;
/* 182 */           x0mp1 = x0mp2;
/* 183 */           xmpm2 = xmpm1;
/* 184 */           xmpm1 = xmpm0;
/* 185 */           xmpm0 = xmpp1;
/* 186 */           xmpp1 = xmpp2;
/* 187 */           xm0m0 = xm0p1;
/* 188 */           xm0p1 = xm0p2;
/* 189 */           y[i3][i2][n1 - 2] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.1057476F * x0mp1 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0408317F * xmpp1 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.0898909F * xm0p1 + -0.4322719F * xm0m0;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 194 */         if (n1 > 0) {
/* 195 */           x00m2 = x00m1;
/* 196 */           x00m1 = x00m0;
/* 197 */           x00m0 = x[i3][i2][n1 - 1];
/* 198 */           x0mm2 = x0mm1;
/* 199 */           x0mm1 = x0mm0;
/* 200 */           x0mm0 = x0mp1;
/* 201 */           xmpm2 = xmpm1;
/* 202 */           xmpm1 = xmpm0;
/* 203 */           xmpm0 = xmpp1;
/* 204 */           xm0m0 = xm0p1;
/* 205 */           y[i3][i2][n1 - 1] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.4322719F * xm0m0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTranspose(float[] x, float[] y) {
/* 220 */     int n = y.length;
/* 221 */     y[n - 1] = x[n - 1];
/* 222 */     for (int i = n - 2; i >= 0; i--) {
/* 223 */       y[i] = x[i] + -0.999F * x[i + 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTranspose(float[][] x, float[][] y) {
/* 234 */     int n1 = (x[0]).length;
/* 235 */     int n2 = x.length;
/* 236 */     float xp4 = 0.0F, xp3 = xp4, xp2 = xp3, xp1 = xp2, xp0 = xp1;
/* 237 */     for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 238 */       xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[n2 - 1][i1];
/* 239 */       y[n2 - 1][i1] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4;
/*     */     } 
/* 241 */     for (int i2 = n2 - 2; i2 >= 0; i2--) {
/* 242 */       float xm4 = 0.0F, xm3 = xm4, xm2 = xm3, xm1 = xm2, xm0 = xm1;
/* 243 */       xp0 = xp1 = xp2 = xp3 = xp4 = 0.0F;
/* 244 */       if (n1 >= 4)
/* 245 */         xm4 = x[i2 + 1][n1 - 4]; 
/* 246 */       if (n1 >= 3)
/* 247 */         xm3 = x[i2 + 1][n1 - 3]; 
/* 248 */       if (n1 >= 2)
/* 249 */         xm2 = x[i2 + 1][n1 - 2]; 
/* 250 */       if (n1 >= 1)
/* 251 */         xm1 = x[i2 + 1][n1 - 1]; 
/* 252 */       for (int i = n1 - 1; i >= 4; i--) {
/* 253 */         xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[i2][i];
/* 254 */         xm0 = xm1; xm1 = xm2; xm2 = xm3; xm3 = xm4; xm4 = x[i2 + 1][i - 4];
/* 255 */         y[i2][i] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4 + -0.5565992F * xm0 + -0.20031442F * xm1 + -0.08457147F * xm2 + -0.04141619F * xm3 + -0.02290331F * xm4;
/*     */       } 
/*     */       
/* 258 */       if (n1 > 3) {
/* 259 */         xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[i2][3];
/* 260 */         xm0 = xm1; xm1 = xm2; xm2 = xm3; xm3 = xm4;
/* 261 */         y[i2][3] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4 + -0.5565992F * xm0 + -0.20031442F * xm1 + -0.08457147F * xm2 + -0.04141619F * xm3;
/*     */       } 
/*     */       
/* 264 */       if (n1 > 2) {
/* 265 */         xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[i2][2];
/* 266 */         xm0 = xm1; xm1 = xm2; xm2 = xm3;
/* 267 */         y[i2][2] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4 + -0.5565992F * xm0 + -0.20031442F * xm1 + -0.08457147F * xm2;
/*     */       } 
/*     */       
/* 270 */       if (n1 > 1) {
/* 271 */         xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[i2][1];
/* 272 */         xm0 = xm1; xm1 = xm2;
/* 273 */         y[i2][1] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4 + -0.5565992F * xm0 + -0.20031442F * xm1;
/*     */       } 
/*     */       
/* 276 */       if (n1 > 0) {
/* 277 */         xp4 = xp3; xp3 = xp2; xp2 = xp1; xp1 = xp0; xp0 = x[i2][0];
/* 278 */         xm0 = xm1;
/* 279 */         y[i2][0] = 1.7954845F * xp0 + -0.64490664F * xp1 + -0.03850411F * xp2 + -0.01793403F * xp3 + -0.00708972F * xp4 + -0.5565992F * xm0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTranspose(float[][][] x, float[][][] y) {
/* 291 */     int n1 = (x[0][0]).length;
/* 292 */     int n2 = (x[0]).length;
/* 293 */     int n3 = x.length;
/* 294 */     int n1m1 = n1 - 1;
/* 295 */     int n2m1 = n2 - 1;
/* 296 */     int n3m1 = n3 - 1;
/* 297 */     for (int i3 = n3m1; i3 >= 0; i3--) {
/* 298 */       for (int i2 = n2m1; i2 >= 0; i2--) {
/* 299 */         float x0mm2 = 0.0F, x0mm1 = 0.0F, x0mm0 = 0.0F, x0mp1 = 0.0F, x0mp2 = 0.0F;
/* 300 */         float x00m2 = 0.0F, x00m1 = 0.0F, x00m0 = 0.0F;
/* 301 */         float xm0m0 = 0.0F, xm0p1 = 0.0F, xm0p2 = 0.0F;
/* 302 */         float xmpm2 = 0.0F, xmpm1 = 0.0F, xmpm0 = 0.0F, xmpp1 = 0.0F, xmpp2 = 0.0F;
/* 303 */         if (n1 > 0) {
/* 304 */           if (i2 < n2m1)
/* 305 */             x0mp1 = x[i3][i2 + 1][n1 - 1]; 
/* 306 */           if (i3 < n3m1) {
/* 307 */             xm0p1 = x[i3 + 1][i2][n1 - 1];
/* 308 */             if (i2 > 0)
/* 309 */               xmpp1 = x[i3 + 1][i2 - 1][n1 - 1]; 
/*     */           } 
/*     */         } 
/* 312 */         if (n1 > 1) {
/* 313 */           if (i2 < n2m1)
/* 314 */             x0mp2 = x[i3][i2 + 1][n1 - 2]; 
/* 315 */           if (i3 < n3m1) {
/* 316 */             xm0p2 = x[i3 + 1][i2][n1 - 2];
/* 317 */             if (i2 > 0)
/* 318 */               xmpp2 = x[i3 + 1][i2 - 1][n1 - 2]; 
/*     */           } 
/*     */         } 
/* 321 */         for (int i1 = n1m1; i1 >= 2; i1--) {
/* 322 */           x00m2 = x00m1;
/* 323 */           x00m1 = x00m0;
/* 324 */           x00m0 = x[i3][i2][i1];
/* 325 */           if (i2 < n2m1) {
/* 326 */             x0mm2 = x0mm1;
/* 327 */             x0mm1 = x0mm0;
/* 328 */             x0mm0 = x0mp1;
/* 329 */             x0mp1 = x0mp2;
/* 330 */             x0mp2 = x[i3][i2 + 1][i1 - 2];
/*     */           } 
/* 332 */           if (i3 < n3m1) {
/* 333 */             if (i2 > 0) {
/* 334 */               xmpm2 = xmpm1;
/* 335 */               xmpm1 = xmpm0;
/* 336 */               xmpm0 = xmpp1;
/* 337 */               xmpp1 = xmpp2;
/* 338 */               xmpp2 = x[i3 + 1][i2 - 1][i1 - 2];
/*     */             } 
/* 340 */             xm0m0 = xm0p1;
/* 341 */             xm0p1 = xm0p2;
/* 342 */             xm0p2 = x[i3 + 1][i2][i1 - 2];
/*     */           } 
/* 344 */           y[i3][i2][i1] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.0291793F * x0mp2 + -0.1057476F * x0mp1 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0149963F * xmpp2 + -0.0408317F * xmpp1 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.0213786F * xm0p2 + -0.0898909F * xm0p1 + -0.4322719F * xm0m0;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 349 */         if (n1 > 1) {
/* 350 */           x00m2 = x00m1;
/* 351 */           x00m1 = x00m0;
/* 352 */           x00m0 = x[i3][i2][1];
/* 353 */           x0mm2 = x0mm1;
/* 354 */           x0mm1 = x0mm0;
/* 355 */           x0mm0 = x0mp1;
/* 356 */           x0mp1 = x0mp2;
/* 357 */           xmpm2 = xmpm1;
/* 358 */           xmpm1 = xmpm0;
/* 359 */           xmpm0 = xmpp1;
/* 360 */           xmpp1 = xmpp2;
/* 361 */           xm0m0 = xm0p1;
/* 362 */           xm0p1 = xm0p2;
/* 363 */           y[i3][i2][1] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.1057476F * x0mp1 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0408317F * xmpp1 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.0898909F * xm0p1 + -0.4322719F * xm0m0;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 368 */         if (n1 > 0) {
/* 369 */           x00m2 = x00m1;
/* 370 */           x00m1 = x00m0;
/* 371 */           x00m0 = x[i3][i2][0];
/* 372 */           x0mm2 = x0mm1;
/* 373 */           x0mm1 = x0mm0;
/* 374 */           x0mm0 = x0mp1;
/* 375 */           xmpm2 = xmpm1;
/* 376 */           xmpm1 = xmpm0;
/* 377 */           xmpm0 = xmpp1;
/* 378 */           xm0m0 = xm0p1;
/* 379 */           y[i3][i2][0] = 2.3110454F * x00m0 + -0.4805547F * x00m1 + -0.0143204F * x00m2 + -0.4572746F * x0mm0 + -0.0115732F * x0mm1 + -0.0047283F * x0mm2 + -0.0945958F * xmpm0 + -0.0223166F * xmpm1 + -0.0062781F * xmpm2 + -0.4322719F * xm0m0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverse(float[] x, float[] y) {
/* 394 */     int n = y.length;
/* 395 */     y[0] = x[0];
/* 396 */     for (int i = 1; i < n; i++) {
/* 397 */       y[i] = x[i] - -0.999F * y[i - 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverse(float[][] x, float[][] y) {
/* 409 */     int n1 = (x[0]).length;
/* 410 */     int n2 = x.length;
/* 411 */     float ym4 = 0.0F, ym3 = ym4, ym2 = ym3, ym1 = ym2, ym0 = ym1;
/* 412 */     for (int i1 = 0; i1 < n1; i1++) {
/* 413 */       ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[0][i1];
/* 414 */       y[0][i1] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4);
/*     */     } 
/* 416 */     for (int i2 = 1; i2 < n2; i2++) {
/* 417 */       ym0 = ym1 = ym2 = ym3 = ym4 = 0.0F;
/* 418 */       float yp4 = 0.0F, yp3 = yp4, yp2 = yp3, yp1 = yp2, yp0 = yp1;
/* 419 */       if (n1 >= 4)
/* 420 */         yp4 = y[i2 - 1][3]; 
/* 421 */       if (n1 >= 3)
/* 422 */         yp3 = y[i2 - 1][2]; 
/* 423 */       if (n1 >= 2)
/* 424 */         yp2 = y[i2 - 1][1]; 
/* 425 */       if (n1 >= 1)
/* 426 */         yp1 = y[i2 - 1][0]; 
/* 427 */       for (int i = 0; i < n1 - 4; i++) {
/* 428 */         ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[i2][i];
/* 429 */         yp0 = yp1; yp1 = yp2; yp2 = yp3; yp3 = yp4; yp4 = y[i2 - 1][i + 4];
/* 430 */         y[i2][i] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4 - -0.5565992F * yp0 - -0.20031442F * yp1 - -0.08457147F * yp2 - -0.04141619F * yp3 - -0.02290331F * yp4);
/*     */       } 
/*     */       
/* 433 */       if (n1 >= 4) {
/* 434 */         ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[i2][n1 - 4];
/* 435 */         yp0 = yp1; yp1 = yp2; yp2 = yp3; yp3 = yp4;
/* 436 */         y[i2][n1 - 4] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4 - -0.5565992F * yp0 - -0.20031442F * yp1 - -0.08457147F * yp2 - -0.04141619F * yp3);
/*     */       } 
/*     */       
/* 439 */       if (n1 >= 3) {
/* 440 */         ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[i2][n1 - 3];
/* 441 */         yp0 = yp1; yp1 = yp2; yp2 = yp3;
/* 442 */         y[i2][n1 - 3] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4 - -0.5565992F * yp0 - -0.20031442F * yp1 - -0.08457147F * yp2);
/*     */       } 
/*     */       
/* 445 */       if (n1 >= 2) {
/* 446 */         ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[i2][n1 - 2];
/* 447 */         yp0 = yp1; yp1 = yp2;
/* 448 */         y[i2][n1 - 2] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4 - -0.5565992F * yp0 - -0.20031442F * yp1);
/*     */       } 
/*     */       
/* 451 */       if (n1 >= 1) {
/* 452 */         ym4 = ym3; ym3 = ym2; ym2 = ym1; ym1 = ym0; float xm0 = x[i2][n1 - 1];
/* 453 */         yp0 = yp1;
/* 454 */         y[i2][n1 - 1] = ym0 = 0.5569527F * (xm0 - -0.64490664F * ym1 - -0.03850411F * ym2 - -0.01793403F * ym3 - -0.00708972F * ym4 - -0.5565992F * yp0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverse(float[][][] x, float[][][] y) {
/* 466 */     int n1 = (x[0][0]).length;
/* 467 */     int n2 = (x[0]).length;
/* 468 */     int n3 = x.length;
/* 469 */     int n2m1 = n2 - 1;
/* 470 */     for (int i3 = 0; i3 < n3; i3++) {
/* 471 */       for (int i2 = 0; i2 < n2; i2++) {
/*     */         
/* 473 */         float y0mm2 = 0.0F, y0mm1 = 0.0F, y0mm0 = 0.0F, y0mp1 = 0.0F, y0mp2 = 0.0F;
/* 474 */         float y00m2 = 0.0F, y00m1 = 0.0F, y00m0 = 0.0F;
/* 475 */         float ym0m0 = 0.0F, ym0p1 = 0.0F, ym0p2 = 0.0F;
/* 476 */         float ympm2 = 0.0F, ympm1 = 0.0F, ympm0 = 0.0F, ympp1 = 0.0F, ympp2 = 0.0F;
/* 477 */         if (n1 > 0) {
/* 478 */           if (i2 > 0)
/* 479 */             y0mp1 = y[i3][i2 - 1][0]; 
/* 480 */           if (i3 > 0) {
/* 481 */             ym0p1 = y[i3 - 1][i2][0];
/* 482 */             if (i2 < n2m1)
/* 483 */               ympp1 = y[i3 - 1][i2 + 1][0]; 
/*     */           } 
/*     */         } 
/* 486 */         if (n1 > 1) {
/* 487 */           if (i2 > 0)
/* 488 */             y0mp2 = y[i3][i2 - 1][1]; 
/* 489 */           if (i3 > 0) {
/* 490 */             ym0p2 = y[i3 - 1][i2][1];
/* 491 */             if (i2 < n2m1)
/* 492 */               ympp2 = y[i3 - 1][i2 + 1][1]; 
/*     */           } 
/*     */         } 
/* 495 */         for (int i1 = 0; i1 < n1 - 2; i1++) {
/* 496 */           float x00m0 = x[i3][i2][i1];
/* 497 */           y00m2 = y00m1;
/* 498 */           y00m1 = y00m0;
/* 499 */           if (i2 > 0) {
/* 500 */             y0mm2 = y0mm1;
/* 501 */             y0mm1 = y0mm0;
/* 502 */             y0mm0 = y0mp1;
/* 503 */             y0mp1 = y0mp2;
/* 504 */             y0mp2 = y[i3][i2 - 1][i1 + 2];
/*     */           } 
/* 506 */           if (i3 > 0) {
/* 507 */             if (i2 < n2m1) {
/* 508 */               ympm2 = ympm1;
/* 509 */               ympm1 = ympm0;
/* 510 */               ympm0 = ympp1;
/* 511 */               ympp1 = ympp2;
/* 512 */               ympp2 = y[i3 - 1][i2 + 1][i1 + 2];
/*     */             } 
/* 514 */             ym0m0 = ym0p1;
/* 515 */             ym0p1 = ym0p2;
/* 516 */             ym0p2 = y[i3 - 1][i2][i1 + 2];
/*     */           } 
/* 518 */           y[i3][i2][i1] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.0291793F * y0mp2 - -0.1057476F * y0mp1 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0149963F * ympp2 - -0.0408317F * ympp1 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.0213786F * ym0p2 - -0.0898909F * ym0p1 - -0.4322719F * ym0m0);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 523 */         if (n1 > 1) {
/* 524 */           float x00m0 = x[i3][i2][n1 - 2];
/* 525 */           y00m2 = y00m1;
/* 526 */           y00m1 = y00m0;
/* 527 */           y0mm2 = y0mm1;
/* 528 */           y0mm1 = y0mm0;
/* 529 */           y0mm0 = y0mp1;
/* 530 */           y0mp1 = y0mp2;
/* 531 */           ympm2 = ympm1;
/* 532 */           ympm1 = ympm0;
/* 533 */           ympm0 = ympp1;
/* 534 */           ympp1 = ympp2;
/* 535 */           ym0m0 = ym0p1;
/* 536 */           ym0p1 = ym0p2;
/* 537 */           y[i3][i2][n1 - 2] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.1057476F * y0mp1 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0408317F * ympp1 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.0898909F * ym0p1 - -0.4322719F * ym0m0);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 542 */         if (n1 > 0) {
/* 543 */           float x00m0 = x[i3][i2][n1 - 1];
/* 544 */           y00m2 = y00m1;
/* 545 */           y00m1 = y00m0;
/* 546 */           y0mm2 = y0mm1;
/* 547 */           y0mm1 = y0mm0;
/* 548 */           y0mm0 = y0mp1;
/* 549 */           ympm2 = ympm1;
/* 550 */           ympm1 = ympm0;
/* 551 */           ympm0 = ympp1;
/* 552 */           ym0m0 = ym0p1;
/* 553 */           y[i3][i2][n1 - 1] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.4322719F * ym0m0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverseTranspose(float[] x, float[] y) {
/* 568 */     int n = y.length;
/* 569 */     y[n - 1] = x[n - 1];
/* 570 */     for (int i = n - 2; i >= 0; i--) {
/* 571 */       y[i] = x[i] - -0.999F * y[i + 1];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverseTranspose(float[][] x, float[][] y) {
/* 583 */     int n1 = (x[0]).length;
/* 584 */     int n2 = x.length;
/* 585 */     float yp4 = 0.0F, yp3 = yp4, yp2 = yp3, yp1 = yp2, yp0 = yp1;
/* 586 */     for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 587 */       yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[n2 - 1][i1];
/* 588 */       y[n2 - 1][i1] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4);
/*     */     } 
/* 590 */     for (int i2 = n2 - 2; i2 >= 0; i2--) {
/* 591 */       float ym4 = 0.0F, ym3 = ym4, ym2 = ym3, ym1 = ym2, ym0 = ym1;
/* 592 */       yp0 = yp1 = yp2 = yp3 = yp4 = 0.0F;
/* 593 */       if (n1 >= 4)
/* 594 */         ym4 = y[i2 + 1][n1 - 4]; 
/* 595 */       if (n1 >= 3)
/* 596 */         ym3 = y[i2 + 1][n1 - 3]; 
/* 597 */       if (n1 >= 2)
/* 598 */         ym2 = y[i2 + 1][n1 - 2]; 
/* 599 */       if (n1 >= 1)
/* 600 */         ym1 = y[i2 + 1][n1 - 1]; 
/* 601 */       for (int i = n1 - 1; i >= 4; i--) {
/* 602 */         yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[i2][i];
/* 603 */         ym0 = ym1; ym1 = ym2; ym2 = ym3; ym3 = ym4; ym4 = y[i2 + 1][i - 4];
/* 604 */         y[i2][i] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4 - -0.5565992F * ym0 - -0.20031442F * ym1 - -0.08457147F * ym2 - -0.04141619F * ym3 - -0.02290331F * ym4);
/*     */       } 
/*     */       
/* 607 */       if (n1 > 3) {
/* 608 */         yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[i2][3];
/* 609 */         ym0 = ym1; ym1 = ym2; ym2 = ym3; ym3 = ym4;
/* 610 */         y[i2][3] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4 - -0.5565992F * ym0 - -0.20031442F * ym1 - -0.08457147F * ym2 - -0.04141619F * ym3);
/*     */       } 
/*     */       
/* 613 */       if (n1 > 2) {
/* 614 */         yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[i2][2];
/* 615 */         ym0 = ym1; ym1 = ym2; ym2 = ym3;
/* 616 */         y[i2][2] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4 - -0.5565992F * ym0 - -0.20031442F * ym1 - -0.08457147F * ym2);
/*     */       } 
/*     */       
/* 619 */       if (n1 > 1) {
/* 620 */         yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[i2][1];
/* 621 */         ym0 = ym1; ym1 = ym2;
/* 622 */         y[i2][1] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4 - -0.5565992F * ym0 - -0.20031442F * ym1);
/*     */       } 
/*     */       
/* 625 */       if (n1 > 0) {
/* 626 */         yp4 = yp3; yp3 = yp2; yp2 = yp1; yp1 = yp0; float xp0 = x[i2][0];
/* 627 */         ym0 = ym1;
/* 628 */         y[i2][0] = yp0 = 0.5569527F * (xp0 - -0.64490664F * yp1 - -0.03850411F * yp2 - -0.01793403F * yp3 - -0.00708972F * yp4 - -0.5565992F * ym0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyInverseTranspose(float[][][] x, float[][][] y) {
/* 640 */     int n1 = (x[0][0]).length;
/* 641 */     int n2 = (x[0]).length;
/* 642 */     int n3 = x.length;
/* 643 */     int n1m1 = n1 - 1;
/* 644 */     int n2m1 = n2 - 1;
/* 645 */     int n3m1 = n3 - 1;
/* 646 */     for (int i3 = n3m1; i3 >= 0; i3--) {
/* 647 */       for (int i2 = n2m1; i2 >= 0; i2--) {
/*     */         
/* 649 */         float y0mm2 = 0.0F, y0mm1 = 0.0F, y0mm0 = 0.0F, y0mp1 = 0.0F, y0mp2 = 0.0F;
/* 650 */         float y00m2 = 0.0F, y00m1 = 0.0F, y00m0 = 0.0F;
/* 651 */         float ym0m0 = 0.0F, ym0p1 = 0.0F, ym0p2 = 0.0F;
/* 652 */         float ympm2 = 0.0F, ympm1 = 0.0F, ympm0 = 0.0F, ympp1 = 0.0F, ympp2 = 0.0F;
/* 653 */         if (n1 > 0) {
/* 654 */           if (i2 < n2m1)
/* 655 */             y0mp1 = y[i3][i2 + 1][n1 - 1]; 
/* 656 */           if (i3 < n3m1) {
/* 657 */             ym0p1 = y[i3 + 1][i2][n1 - 1];
/* 658 */             if (i2 > 0)
/* 659 */               ympp1 = y[i3 + 1][i2 - 1][n1 - 1]; 
/*     */           } 
/*     */         } 
/* 662 */         if (n1 > 1) {
/* 663 */           if (i2 < n2m1)
/* 664 */             y0mp2 = y[i3][i2 + 1][n1 - 2]; 
/* 665 */           if (i3 < n3m1) {
/* 666 */             ym0p2 = y[i3 + 1][i2][n1 - 2];
/* 667 */             if (i2 > 0)
/* 668 */               ympp2 = y[i3 + 1][i2 - 1][n1 - 2]; 
/*     */           } 
/*     */         } 
/* 671 */         for (int i1 = n1m1; i1 >= 2; i1--) {
/* 672 */           float x00m0 = x[i3][i2][i1];
/* 673 */           y00m2 = y00m1;
/* 674 */           y00m1 = y00m0;
/* 675 */           if (i2 < n2m1) {
/* 676 */             y0mm2 = y0mm1;
/* 677 */             y0mm1 = y0mm0;
/* 678 */             y0mm0 = y0mp1;
/* 679 */             y0mp1 = y0mp2;
/* 680 */             y0mp2 = y[i3][i2 + 1][i1 - 2];
/*     */           } 
/* 682 */           if (i3 < n3m1) {
/* 683 */             if (i2 > 0) {
/* 684 */               ympm2 = ympm1;
/* 685 */               ympm1 = ympm0;
/* 686 */               ympm0 = ympp1;
/* 687 */               ympp1 = ympp2;
/* 688 */               ympp2 = y[i3 + 1][i2 - 1][i1 - 2];
/*     */             } 
/* 690 */             ym0m0 = ym0p1;
/* 691 */             ym0p1 = ym0p2;
/* 692 */             ym0p2 = y[i3 + 1][i2][i1 - 2];
/*     */           } 
/* 694 */           y[i3][i2][i1] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.0291793F * y0mp2 - -0.1057476F * y0mp1 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0149963F * ympp2 - -0.0408317F * ympp1 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.0213786F * ym0p2 - -0.0898909F * ym0p1 - -0.4322719F * ym0m0);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 699 */         if (n1 > 1) {
/* 700 */           float x00m0 = x[i3][i2][1];
/* 701 */           y00m2 = y00m1;
/* 702 */           y00m1 = y00m0;
/* 703 */           y0mm2 = y0mm1;
/* 704 */           y0mm1 = y0mm0;
/* 705 */           y0mm0 = y0mp1;
/* 706 */           y0mp1 = y0mp2;
/* 707 */           ympm2 = ympm1;
/* 708 */           ympm1 = ympm0;
/* 709 */           ympm0 = ympp1;
/* 710 */           ympp1 = ympp2;
/* 711 */           ym0m0 = ym0p1;
/* 712 */           ym0p1 = ym0p2;
/* 713 */           y[i3][i2][1] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.1057476F * y0mp1 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0408317F * ympp1 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.0898909F * ym0p1 - -0.4322719F * ym0m0);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 718 */         if (n1 > 0) {
/* 719 */           float x00m0 = x[i3][i2][0];
/* 720 */           y00m2 = y00m1;
/* 721 */           y00m1 = y00m0;
/* 722 */           y0mm2 = y0mm1;
/* 723 */           y0mm1 = y0mm0;
/* 724 */           y0mm0 = y0mp1;
/* 725 */           ympm2 = ympm1;
/* 726 */           ympm1 = ympm0;
/* 727 */           ympm0 = ympp1;
/* 728 */           ym0m0 = ym0p1;
/* 729 */           y[i3][i2][0] = y00m0 = 0.4327046F * (x00m0 - -0.4805547F * y00m1 - -0.0143204F * y00m2 - -0.4572746F * y0mm0 - -0.0115732F * y0mm1 - -0.0047283F * y0mm2 - -0.0945958F * ympm0 - -0.0223166F * ympm1 - -0.0062781F * ympm2 - -0.4322719F * ym0m0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/DifferenceFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */