/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrawList
/*    */ {
/*    */   public void append(Node[] nodes) {
/* 40 */     this._list.add(nodes);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void draw(DrawContext dc) {
/* 50 */     Node[] empty = new Node[0];
/* 51 */     Node[] nodes = empty;
/* 52 */     Node[] prevs = empty;
/* 53 */     int nnode = nodes.length;
/* 54 */     int nprev = prevs.length;
/*    */ 
/*    */     
/* 57 */     int nlist = this._list.size();
/* 58 */     for (int ilist = 0; ilist <= nlist; ilist++) {
/*    */ 
/*    */       
/* 61 */       prevs = nodes;
/* 62 */       nprev = nnode;
/*    */ 
/*    */       
/* 65 */       nodes = (ilist < nlist) ? this._list.get(ilist) : empty;
/* 66 */       nnode = nodes.length;
/*    */ 
/*    */       
/* 69 */       int mnode = (nnode < nprev) ? nnode : nprev;
/* 70 */       int knode = 0;
/* 71 */       while (knode < mnode && nodes[knode] == prevs[knode]) {
/* 72 */         knode++;
/*    */       }
/*    */       int inode;
/* 75 */       for (inode = nprev - 1; inode >= knode; inode--) {
/* 76 */         prevs[inode].drawEnd(dc);
/*    */       }
/*    */       
/* 79 */       for (inode = knode; inode < nnode; inode++) {
/* 80 */         nodes[inode].drawBegin(dc);
/*    */       }
/*    */       
/* 83 */       if (nnode > 0)
/* 84 */         nodes[nnode - 1].draw(dc); 
/*    */     } 
/*    */   }
/*    */   
/* 88 */   private ArrayList<Node[]> _list = (ArrayList)new ArrayList<Node>(32);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/DrawList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */