/*    */ package edu.mines.jtk.opengl.test;
/*    */ 
/*    */ import edu.mines.jtk.opengl.Gl;
/*    */ import edu.mines.jtk.opengl.GlPainter;
/*    */ import edu.mines.jtk.opengl.GlTextureName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlTextureNameTest
/*    */ {
/* 32 */   private static GlPainter painter = new GlPainter()
/*    */     {
/*    */       private static final int SIZE = 256;
/* 35 */       private byte[] _checkImage = null;
/*    */       private GlTextureName _textureName;
/*    */       
/*    */       private void makeCheckImage() {
/* 39 */         int n = 256;
/* 40 */         this._checkImage = new byte[n * n * 4];
/* 41 */         for (int i = 0, k = 0; i < n; i++) {
/* 42 */           for (int j = 0; j < n; j++) {
/* 43 */             int c = ((((((i & 0x10) == 0) ? 1 : 0) ^ (((j & 0x10) == 0) ? 1 : 0)) != 0) ? 1 : 0) * 255;
/* 44 */             byte b = (byte)c;
/* 45 */             this._checkImage[k++] = b;
/* 46 */             this._checkImage[k++] = b;
/* 47 */             this._checkImage[k++] = b;
/* 48 */             this._checkImage[k++] = -1;
/*    */           } 
/*    */         } 
/*    */       }
/*    */       private void makeTexture() {
/* 53 */         this._textureName = new GlTextureName();
/* 54 */         Gl.glBindTexture(3553, this._textureName.name());
/* 55 */         Gl.glTexParameteri(3553, 10242, 10497);
/* 56 */         Gl.glTexParameteri(3553, 10243, 10497);
/* 57 */         Gl.glTexParameteri(3553, 10240, 9728);
/* 58 */         Gl.glTexParameteri(3553, 10241, 9728);
/* 59 */         Gl.glTexImage2D(3553, 0, 6408, 256, 256, 0, 6408, 5121, this._checkImage);
/*    */       }
/*    */       
/*    */       public void glInit() {
/* 63 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 64 */         Gl.glPixelStorei(3317, 1);
/* 65 */         makeCheckImage();
/* 66 */         makeTexture();
/*    */       }
/*    */       public void glResize(int width, int height, int widthOld, int heightOld) {
/* 69 */         Gl.glViewport(0, 0, width, height);
/* 70 */         Gl.glMatrixMode(5889);
/* 71 */         Gl.glLoadIdentity();
/* 72 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/*    */       }
/*    */       public void glPaint() {
/* 75 */         Gl.glClear(16640);
/* 76 */         Gl.glEnable(3553);
/* 77 */         Gl.glTexEnvf(8960, 8704, 7681.0F);
/* 78 */         Gl.glBindTexture(3553, this._textureName.name());
/* 79 */         Gl.glBegin(9);
/* 80 */         Gl.glTexCoord2f(0.0F, 0.0F); Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 81 */         Gl.glTexCoord2f(1.0F, 0.0F); Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 82 */         Gl.glTexCoord2f(1.0F, 1.0F); Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 83 */         Gl.glTexCoord2f(0.0F, 1.0F); Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 84 */         Gl.glEnd();
/* 85 */         Gl.glFlush();
/* 86 */         Gl.glDisable(3553);
/* 87 */         makeTexture();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 91 */     TestSimple.run(args, painter, true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/test/GlTextureNameTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */