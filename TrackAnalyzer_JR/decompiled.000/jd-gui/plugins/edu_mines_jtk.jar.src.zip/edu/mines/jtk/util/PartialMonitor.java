/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PartialMonitor
/*    */   implements Monitor
/*    */ {
/* 16 */   private Monitor _wrapped = null;
/* 17 */   private double _begin = 0.0D;
/* 18 */   private double _end = 1.0D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PartialMonitor(Monitor wrapped, double begin, double end) {
/* 27 */     this._wrapped = wrapped;
/* 28 */     this._begin = begin;
/* 29 */     this._end = end;
/*    */   }
/*    */   
/*    */   public void report(double fraction) {
/* 33 */     if (this._wrapped == null)
/*    */       return; 
/* 35 */     this._wrapped.report(fraction * (this._end - this._begin) + this._begin);
/*    */   }
/*    */   
/*    */   public void initReport(double initFraction) {
/* 39 */     this._wrapped.initReport(initFraction * (this._end - this._begin) + this._begin);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/PartialMonitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */