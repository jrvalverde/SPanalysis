/*     */ package edu.mines.jtk.la;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixLud
/*     */ {
/*     */   int _m;
/*     */   int _n;
/*     */   double[][] _lu;
/*     */   int[] _piv;
/*     */   int _pivsign;
/*     */   
/*     */   public DMatrixLud(DMatrix a) {
/*  40 */     int m = this._m = a.getM();
/*  41 */     int n = this._n = a.getN();
/*  42 */     double[][] lu = this._lu = a.get();
/*  43 */     this._piv = new int[m];
/*  44 */     for (int i = 0; i < m; i++)
/*  45 */       this._piv[i] = i; 
/*  46 */     this._pivsign = 1;
/*     */     
/*  48 */     double[] lucolj = new double[m];
/*     */ 
/*     */     
/*  51 */     for (int j = 0; j < n; j++) {
/*     */       int k;
/*     */       
/*  54 */       for (k = 0; k < m; k++) {
/*  55 */         lucolj[k] = lu[k][j];
/*     */       }
/*     */       
/*  58 */       for (k = 0; k < m; k++) {
/*  59 */         double[] lurowi = lu[k];
/*     */ 
/*     */         
/*  62 */         int kmax = Math.min(k, j);
/*  63 */         double s = 0.0D;
/*  64 */         for (int i2 = 0; i2 < kmax; i2++)
/*  65 */           s += lurowi[i2] * lucolj[i2]; 
/*  66 */         lucolj[k] = lucolj[k] - s; lurowi[j] = lucolj[k] - s;
/*     */       } 
/*     */ 
/*     */       
/*  70 */       int p = j; int i1;
/*  71 */       for (i1 = j + 1; i1 < m; i1++) {
/*  72 */         if (Math.abs(lucolj[i1]) > Math.abs(lucolj[p]))
/*  73 */           p = i1; 
/*     */       } 
/*  75 */       if (p != j) {
/*  76 */         int i2; for (i2 = 0; i2 < n; i2++) {
/*  77 */           double t = lu[p][i2];
/*  78 */           lu[p][i2] = lu[j][i2];
/*  79 */           lu[j][i2] = t;
/*     */         } 
/*  81 */         i2 = this._piv[p];
/*  82 */         this._piv[p] = this._piv[j];
/*  83 */         this._piv[j] = i2;
/*  84 */         this._pivsign = -this._pivsign;
/*     */       } 
/*     */ 
/*     */       
/*  88 */       if (j < m && lu[j][j] != 0.0D) {
/*  89 */         for (i1 = j + 1; i1 < m; i1++) {
/*  90 */           lu[i1][j] = lu[i1][j] / lu[j][j];
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNonSingular() {
/* 100 */     for (int j = 0; j < this._n; j++) {
/* 101 */       if (this._lu[j][j] == 0.0D)
/* 102 */         return false; 
/*     */     } 
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingular() {
/* 112 */     return !isNonSingular();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getL() {
/* 120 */     double[][] l = new double[this._m][this._n];
/* 121 */     for (int i = 0; i < this._m; i++) {
/* 122 */       for (int j = 0; j < this._n; j++) {
/* 123 */         if (i > j) {
/* 124 */           l[i][j] = this._lu[i][j];
/* 125 */         } else if (i == j) {
/* 126 */           l[i][j] = 1.0D;
/*     */         } else {
/* 128 */           l[i][j] = 0.0D;
/*     */         } 
/*     */       } 
/*     */     } 
/* 132 */     return new DMatrix(this._m, this._n, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getU() {
/* 140 */     double[][] u = new double[this._n][this._n];
/* 141 */     for (int i = 0; i < this._n; i++) {
/* 142 */       for (int j = 0; j < this._n; j++) {
/* 143 */         if (i <= j) {
/* 144 */           u[i][j] = this._lu[i][j];
/*     */         } else {
/* 146 */           u[i][j] = 0.0D;
/*     */         } 
/*     */       } 
/*     */     } 
/* 150 */     return new DMatrix(this._n, this._n, u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getPivot() {
/* 158 */     int[] p = new int[this._m];
/* 159 */     for (int i = 0; i < this._m; i++)
/* 160 */       p[i] = this._piv[i]; 
/* 161 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix solve(DMatrix b) {
/* 174 */     Check.argument((b.getM() == this._m), "A and B have the same number of rows");
/* 175 */     Check.state(isNonSingular(), "A is non-singular");
/*     */ 
/*     */     
/* 178 */     int nx = b.getN();
/* 179 */     DMatrix xx = b.get(this._piv, 0, nx - 1);
/* 180 */     double[][] x = xx.getArray();
/*     */     
/*     */     int k;
/* 183 */     for (k = 0; k < this._n; k++) {
/* 184 */       for (int i = k + 1; i < this._n; i++) {
/* 185 */         for (int j = 0; j < nx; j++) {
/* 186 */           x[i][j] = x[i][j] - x[k][j] * this._lu[i][k];
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 192 */     for (k = this._n - 1; k >= 0; k--) {
/* 193 */       for (int j = 0; j < nx; j++) {
/* 194 */         x[k][j] = x[k][j] / this._lu[k][k];
/*     */       }
/* 196 */       for (int i = 0; i < k; i++) {
/* 197 */         for (int m = 0; m < nx; m++) {
/* 198 */           x[i][m] = x[i][m] - x[k][m] * this._lu[i][k];
/*     */         }
/*     */       } 
/*     */     } 
/* 202 */     return xx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double det() {
/* 211 */     Check.state((this._m == this._n), "A is square");
/* 212 */     double d = this._pivsign;
/* 213 */     for (int j = 0; j < this._n; j++)
/* 214 */       d *= this._lu[j][j]; 
/* 215 */     return d;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/DMatrixLud.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */