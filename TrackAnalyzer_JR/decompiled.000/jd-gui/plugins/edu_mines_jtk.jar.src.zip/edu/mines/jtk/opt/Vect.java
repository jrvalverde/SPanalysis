package edu.mines.jtk.opt;

public interface Vect extends VectConst {
  void add(double paramDouble1, double paramDouble2, VectConst paramVectConst);
  
  void project(double paramDouble1, double paramDouble2, VectConst paramVectConst);
  
  void dispose();
  
  void multiplyInverseCovariance();
  
  void constrain();
  
  void postCondition();
  
  Vect clone();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/Vect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */