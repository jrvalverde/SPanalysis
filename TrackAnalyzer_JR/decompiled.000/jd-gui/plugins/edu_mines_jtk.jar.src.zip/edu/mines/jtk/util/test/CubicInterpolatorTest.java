/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.CubicInterpolator;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CubicInterpolatorTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  28 */     TestSuite suite = new TestSuite(CubicInterpolatorTest.class);
/*  29 */     TestRunner.run((Test)suite);
/*     */   }
/*     */ 
/*     */   
/*     */   public void testLinearAndSpline() {
/*  34 */     int npoints = 100;
/*  35 */     Random generator = new Random(100L);
/*  36 */     float[] x = Array.randfloat(generator, npoints);
/*  37 */     float[] y = Array.randfloat(generator, npoints);
/*  38 */     Array.quickSort(x);
/*     */ 
/*     */     
/*  41 */     CubicInterpolator.Method linear = CubicInterpolator.Method.LINEAR;
/*  42 */     CubicInterpolator.Method spline = CubicInterpolator.Method.SPLINE;
/*  43 */     CubicInterpolator cl = new CubicInterpolator(linear, npoints, x, y);
/*  44 */     CubicInterpolator cs = new CubicInterpolator(spline, npoints, x, y);
/*     */ 
/*     */     
/*  47 */     for (int i = 0; i < npoints - 1; i++) {
/*     */       
/*  49 */       float xpos = 0.5F * (x[i] + x[i + 1]);
/*  50 */       float xi = x[i] + 0.2F * (x[i + 1] - x[i]);
/*  51 */       float yi0 = cl.interpolate(xi);
/*  52 */       float yi1 = cl.interpolate1(xi);
/*  53 */       float xj = x[i + 1] - 0.2F * (x[i + 1] - x[i]);
/*  54 */       float yj0 = cl.interpolate(xj);
/*  55 */       float yj1 = cl.interpolate1(xj);
/*  56 */       float[] abcd = computeCoefficients(xi, yi0, yi1, xj, yj0, yj1);
/*  57 */       assertEqual(deriv0(abcd, xpos - xi), cl.interpolate(xpos));
/*  58 */       assertEqual(deriv1(abcd, xpos - xi), cl.interpolate1(xpos));
/*  59 */       assertEqual(0.0F, cl.interpolate2(xpos));
/*  60 */       assertEqual(0.0F, cl.interpolate3(xpos));
/*     */       
/*  62 */       yi0 = cs.interpolate(xi);
/*  63 */       yi1 = cs.interpolate1(xi);
/*  64 */       yj0 = cs.interpolate(xj);
/*  65 */       yj1 = cs.interpolate1(xj);
/*  66 */       abcd = computeCoefficients(xi, yi0, yi1, xj, yj0, yj1);
/*  67 */       assertEqual(deriv0(abcd, xpos - xi), cs.interpolate(xpos));
/*  68 */       assertEqual(deriv1(abcd, xpos - xi), cs.interpolate1(xpos));
/*  69 */       assertEqual(deriv2(abcd, xpos - xi), cs.interpolate2(xpos));
/*  70 */       assertEqual(deriv3(abcd, xpos - xi), cs.interpolate3(xpos));
/*     */     } 
/*     */     
/*  73 */     float xinterval = 0.5F;
/*  74 */     checkExtrapolation(linear, cl, npoints, xinterval, x);
/*  75 */     checkExtrapolation(spline, cs, npoints, xinterval, x);
/*     */   }
/*     */ 
/*     */   
/*     */   public void testMonotonic() {
/*  80 */     int npoints = 100;
/*  81 */     Random generator = new Random(100L);
/*  82 */     float[] x = Array.randfloat(generator, npoints);
/*  83 */     float[] y = Array.randfloat(generator, npoints);
/*  84 */     Array.quickSort(x);
/*  85 */     Array.quickSort(y);
/*     */ 
/*     */     
/*  88 */     CubicInterpolator.Method monoto = CubicInterpolator.Method.MONOTONIC;
/*  89 */     CubicInterpolator cm = new CubicInterpolator(monoto, npoints, x, y);
/*     */ 
/*     */     
/*  92 */     for (int i = 0; i < npoints - 1; i++) {
/*  93 */       float xpos = 0.5F * (x[i] + x[i + 1]);
/*  94 */       float xi = x[i];
/*  95 */       float yi0 = cm.interpolate(xi);
/*  96 */       float yi1 = cm.interpolate1(xi);
/*  97 */       float xj = x[i + 1];
/*  98 */       float yj0 = cm.interpolate(xj);
/*  99 */       float yj1 = cm.interpolate1(xj);
/* 100 */       float[] abcd = computeCoefficients(xi, yi0, yi1, xj, yj0, yj1);
/* 101 */       assertEqual(deriv0(abcd, xpos - xi), cm.interpolate(xpos));
/* 102 */       assertEqual(deriv1(abcd, xpos - xi), cm.interpolate1(xpos));
/* 103 */       assertEqual(deriv2(abcd, xpos - xi), cm.interpolate2(xpos));
/* 104 */       assertEqual(deriv3(abcd, xpos - xi), cm.interpolate3(xpos));
/*     */     } 
/*     */     
/* 107 */     float xinterval = 0.5F;
/* 108 */     checkExtrapolation(monoto, cm, npoints, xinterval, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkExtrapolation(CubicInterpolator.Method type, CubicInterpolator ci, int npoints, float xinterval, float[] x) {
/* 116 */     float xpos = x[0] - 0.5F * xinterval;
/* 117 */     float xi = x[0] - xinterval;
/* 118 */     float yi0 = ci.interpolate(xi);
/* 119 */     float yi1 = ci.interpolate1(xi);
/* 120 */     float xj = x[0];
/* 121 */     float yj0 = ci.interpolate(xj);
/* 122 */     float yj1 = ci.interpolate1(xj);
/* 123 */     float[] abcd = computeCoefficients(xi, yi0, yi1, xj, yj0, yj1);
/* 124 */     assertEqual(deriv0(abcd, xpos - xi), ci.interpolate(xpos));
/* 125 */     assertEqual(deriv1(abcd, xpos - xi), ci.interpolate1(xpos));
/* 126 */     if (type == CubicInterpolator.Method.LINEAR) {
/* 127 */       assertEqual(0.0F, ci.interpolate2(xpos));
/* 128 */       assertEqual(0.0F, ci.interpolate3(xpos));
/*     */     } else {
/* 130 */       assertEqual(deriv2(abcd, xpos - xi), ci.interpolate2(xpos));
/* 131 */       assertEqual(deriv3(abcd, xpos - xi), ci.interpolate3(xpos));
/*     */     } 
/*     */     
/* 134 */     xpos = x[npoints - 1] + 0.5F * xinterval;
/* 135 */     xi = x[npoints - 1];
/* 136 */     yi0 = ci.interpolate(xi);
/* 137 */     yi1 = ci.interpolate1(xi);
/* 138 */     xj = x[npoints - 1] + xinterval;
/* 139 */     yj0 = ci.interpolate(xj);
/* 140 */     yj1 = ci.interpolate1(xj);
/* 141 */     abcd = computeCoefficients(xi, yi0, yi1, xj, yj0, yj1);
/* 142 */     assertEqual(deriv0(abcd, xpos - xi), ci.interpolate(xpos));
/* 143 */     assertEqual(deriv1(abcd, xpos - xi), ci.interpolate1(xpos));
/* 144 */     if (type == CubicInterpolator.Method.LINEAR) {
/* 145 */       assertEqual(0.0F, ci.interpolate2(xpos));
/* 146 */       assertEqual(0.0F, ci.interpolate3(xpos));
/*     */     } else {
/* 148 */       assertEqual(deriv2(abcd, xpos - xi), ci.interpolate2(xpos));
/* 149 */       assertEqual(deriv3(abcd, xpos - xi), ci.interpolate3(xpos));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] computeCoefficients(float xi, float yi0, float yi1, float xj, float yj0, float yj1) {
/* 158 */     float dx = xj - xi;
/* 159 */     float dydx = (yj0 - yi0) / dx;
/* 160 */     float a = (yi1 + yj1 - 2.0F * dydx) / dx * dx;
/* 161 */     float b = (3.0F * dydx - 2.0F * yi1 - yj1) / dx;
/* 162 */     float c = yi1;
/* 163 */     float d = yi0;
/* 164 */     return new float[] { a, b, c, d };
/*     */   }
/*     */ 
/*     */   
/*     */   private static float deriv0(float[] abcd, float dx) {
/* 169 */     return ((abcd[0] * dx + abcd[1]) * dx + abcd[2]) * dx + abcd[3];
/*     */   }
/*     */ 
/*     */   
/*     */   private static float deriv1(float[] abcd, float dx) {
/* 174 */     return (3.0F * abcd[0] * dx + 2.0F * abcd[1]) * dx + abcd[2];
/*     */   }
/*     */ 
/*     */   
/*     */   private static float deriv2(float[] abcd, float dx) {
/* 179 */     return 6.0F * abcd[0] * dx + 2.0F * abcd[1];
/*     */   }
/*     */ 
/*     */   
/*     */   private static float deriv3(float[] abcd, float dx) {
/* 184 */     return 6.0F * abcd[0];
/*     */   }
/*     */   
/*     */   private static void assertEqual(float x, float y) {
/* 188 */     assertTrue(x + " = " + y, almostEqual(x, y));
/*     */   }
/*     */   
/*     */   private static boolean almostEqual(float x, float y) {
/* 192 */     float ax = MathPlus.abs(x);
/* 193 */     float ay = MathPlus.abs(y);
/* 194 */     return (MathPlus.abs(x - y) <= 0.001F * MathPlus.max(ax, ay));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/CubicInterpolatorTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */