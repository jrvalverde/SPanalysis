/*    */ package edu.mines.jtk.la.test;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Suite
/*    */   extends TestSuite
/*    */ {
/*    */   public static Test suite() {
/* 20 */     TestSuite suite = new TestSuite();
/*    */     
/* 22 */     suite.addTestSuite(DMatrixTest.class);
/* 23 */     suite.addTestSuite(DMatrixEvdTest.class);
/* 24 */     suite.addTestSuite(DMatrixQrdTest.class);
/*    */     
/* 26 */     return (Test)suite;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 30 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/test/Suite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */