/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.DifferenceFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DifferenceFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(DifferenceFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1Impulse() {
/*  28 */     float[] e = { 0.0F, 0.0F, 0.0F, -1.0F, 2.0F, -1.0F, 0.0F, 0.0F, 0.0F };
/*  29 */     int n = e.length;
/*  30 */     float[] x = new float[n];
/*  31 */     float[] y = new float[n];
/*  32 */     float[] z = new float[n];
/*  33 */     x[(n - 1) / 2] = 1.0F;
/*  34 */     DifferenceFilter df = new DifferenceFilter();
/*  35 */     df.apply(x, y);
/*  36 */     df.applyInverse(y, z);
/*  37 */     assertEqual(x, z, 1.1920929E-6F);
/*  38 */     df.applyTranspose(x, y);
/*  39 */     df.applyInverseTranspose(y, z);
/*  40 */     assertEqual(x, z, 1.1920929E-6F);
/*  41 */     df.apply(x, y);
/*  42 */     df.applyTranspose(y, z);
/*  43 */     assertEqual(e, z, 0.02F);
/*     */   }
/*     */   
/*     */   public void test2Impulse() {
/*  47 */     float[][] e = { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, -1.0F, 4.0F, -1.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     int n1 = (e[0]).length;
/*  55 */     int n2 = e.length;
/*  56 */     float[][] x = new float[n2][n1];
/*  57 */     float[][] y = new float[n2][n1];
/*  58 */     float[][] z = new float[n2][n1];
/*  59 */     x[(n2 - 1) / 2][(n1 - 1) / 2] = 1.0F;
/*  60 */     DifferenceFilter df = new DifferenceFilter();
/*  61 */     df.apply(x, y);
/*  62 */     df.applyInverse(y, z);
/*  63 */     assertEqual(x, z, 1.1920929E-6F);
/*  64 */     df.applyTranspose(x, y);
/*  65 */     df.applyInverseTranspose(y, z);
/*  66 */     assertEqual(x, z, 1.1920929E-6F);
/*  67 */     df.apply(x, y);
/*  68 */     df.applyTranspose(y, z);
/*  69 */     assertEqual(e, z, 0.04F);
/*     */   }
/*     */   
/*     */   public void test3Impulse() {
/*  73 */     float[][][] e = { { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, -1.0F, 6.0F, -1.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } }, { { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }, { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     int n1 = (e[0][0]).length;
/* 107 */     int n2 = (e[0]).length;
/* 108 */     int n3 = e.length;
/* 109 */     float[][][] x = new float[n3][n2][n1];
/* 110 */     float[][][] y = new float[n3][n2][n1];
/* 111 */     float[][][] z = new float[n3][n2][n1];
/* 112 */     x[(n3 - 1) / 2][(n2 - 1) / 2][(n1 - 1) / 2] = 1.0F;
/* 113 */     DifferenceFilter df = new DifferenceFilter();
/* 114 */     df.apply(x, y);
/* 115 */     df.applyInverse(y, z);
/* 116 */     assertEqual(x, z, 1.1920929E-6F);
/* 117 */     df.applyTranspose(x, y);
/* 118 */     df.applyInverseTranspose(y, z);
/* 119 */     assertEqual(x, z, 1.1920929E-6F);
/* 120 */     df.apply(x, y);
/* 121 */     df.applyTranspose(y, z);
/* 122 */     assertEqual(e, z, 0.06F);
/*     */   }
/*     */   
/*     */   public void test1Random() {
/* 126 */     DifferenceFilter df = new DifferenceFilter();
/* 127 */     int n = 100;
/*     */ 
/*     */     
/* 130 */     float[] x = randfloat(n);
/* 131 */     float[] y = zerofloat(n);
/* 132 */     float[] z = zerofloat(n);
/* 133 */     df.apply(x, y);
/* 134 */     df.applyInverse(y, z);
/* 135 */     assertEqual(x, z);
/* 136 */     df.applyTranspose(x, y);
/* 137 */     df.applyInverseTranspose(y, z);
/* 138 */     assertEqual(x, z);
/*     */ 
/*     */     
/* 141 */     float tiny = n * 10.0F * 1.1920929E-7F;
/* 142 */     x = randfloat(n);
/* 143 */     y = randfloat(n);
/* 144 */     z = zerofloat(n);
/* 145 */     df.apply(x, z);
/* 146 */     float d1 = dot(z, y);
/* 147 */     df.applyTranspose(y, z);
/* 148 */     float d2 = dot(z, x);
/* 149 */     assertEquals(d1, d2, tiny);
/* 150 */     df.applyInverse(x, z);
/* 151 */     d1 = dot(z, y);
/* 152 */     df.applyInverseTranspose(y, z);
/* 153 */     d2 = dot(z, x);
/* 154 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   public void test2Random() {
/* 158 */     DifferenceFilter df = new DifferenceFilter();
/* 159 */     int n1 = 19;
/* 160 */     int n2 = 21;
/*     */ 
/*     */     
/* 163 */     float[][] x = randfloat(n1, n2);
/* 164 */     float[][] y = zerofloat(n1, n2);
/* 165 */     float[][] z = zerofloat(n1, n2);
/* 166 */     df.apply(x, y);
/* 167 */     df.applyInverse(y, z);
/* 168 */     assertEqual(x, z);
/* 169 */     df.applyTranspose(x, y);
/* 170 */     df.applyInverseTranspose(y, z);
/* 171 */     assertEqual(x, z);
/*     */ 
/*     */     
/* 174 */     float tiny = (n1 * n2) * 10.0F * 1.1920929E-7F;
/* 175 */     x = randfloat(n1, n2);
/* 176 */     y = randfloat(n1, n2);
/* 177 */     z = zerofloat(n1, n2);
/* 178 */     df.apply(x, z);
/* 179 */     float d1 = dot(z, y);
/* 180 */     df.applyTranspose(y, z);
/* 181 */     float d2 = dot(z, x);
/* 182 */     assertEquals(d1, d2, tiny);
/* 183 */     df.applyInverse(x, z);
/* 184 */     d1 = dot(z, y);
/* 185 */     df.applyInverseTranspose(y, z);
/* 186 */     d2 = dot(z, x);
/* 187 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   public void test3Random() {
/* 191 */     DifferenceFilter df = new DifferenceFilter();
/* 192 */     int n1 = 11;
/* 193 */     int n2 = 13;
/* 194 */     int n3 = 12;
/*     */ 
/*     */     
/* 197 */     float[][][] x = randfloat(n1, n2, n3);
/* 198 */     float[][][] y = zerofloat(n1, n2, n3);
/* 199 */     float[][][] z = zerofloat(n1, n2, n3);
/* 200 */     df.apply(x, y);
/* 201 */     df.applyInverse(y, z);
/* 202 */     assertEqual(x, z);
/* 203 */     df.applyTranspose(x, y);
/* 204 */     df.applyInverseTranspose(y, z);
/* 205 */     assertEqual(x, z);
/*     */ 
/*     */     
/* 208 */     float tiny = (n1 * n2 * n3) * 10.0F * 1.1920929E-7F;
/* 209 */     x = randfloat(n1, n2, n3);
/* 210 */     y = randfloat(n1, n2, n3);
/* 211 */     z = zerofloat(n1, n2, n3);
/* 212 */     df.apply(x, z);
/* 213 */     float d1 = dot(z, y);
/* 214 */     df.applyTranspose(y, z);
/* 215 */     float d2 = dot(z, x);
/* 216 */     assertEquals(d1, d2, tiny);
/* 217 */     df.applyInverse(x, z);
/* 218 */     d1 = dot(z, y);
/* 219 */     df.applyInverseTranspose(y, z);
/* 220 */     d2 = dot(z, x);
/* 221 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   private static float[] randfloat(int n1) {
/* 225 */     return Array.sub(Array.randfloat(n1), 0.5F);
/*     */   }
/*     */   private static float[][] randfloat(int n1, int n2) {
/* 228 */     return Array.sub(Array.randfloat(n1, n2), 0.5F);
/*     */   }
/*     */   private static float[][][] randfloat(int n1, int n2, int n3) {
/* 231 */     return Array.sub(Array.randfloat(n1, n2, n3), 0.5F);
/*     */   }
/*     */   
/*     */   private static float[] zerofloat(int n1) {
/* 235 */     return Array.zerofloat(n1);
/*     */   }
/*     */   private static float[][] zerofloat(int n1, int n2) {
/* 238 */     return Array.zerofloat(n1, n2);
/*     */   }
/*     */   private static float[][][] zerofloat(int n1, int n2, int n3) {
/* 241 */     return Array.zerofloat(n1, n2, n3);
/*     */   }
/*     */   
/*     */   private static float dot(float[] x, float[] y) {
/* 245 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][] x, float[][] y) {
/* 248 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][][] x, float[][][] y) {
/* 251 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[] re, float[] ra) {
/* 255 */     int n1 = re.length;
/* 256 */     float tol = n1 * 1.1920929E-7F;
/* 257 */     assertEqual(re, ra, tol);
/*     */   }
/*     */   private static void assertEqual(float[][] re, float[][] ra) {
/* 260 */     int n2 = re.length;
/* 261 */     int n1 = (re[0]).length;
/* 262 */     float tol = (n1 * n2) * 1.1920929E-7F;
/* 263 */     assertEqual(re, ra, tol);
/*     */   }
/*     */   private static void assertEqual(float[][][] re, float[][][] ra) {
/* 266 */     int n3 = re.length;
/* 267 */     int n2 = (re[0]).length;
/* 268 */     int n1 = (re[0][0]).length;
/* 269 */     float tol = (n1 * n2 * n3) * 1.1920929E-7F;
/* 270 */     assertEqual(re, ra, tol);
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[] re, float[] ra, float tol) {
/* 274 */     int n = re.length;
/* 275 */     for (int i = 0; i < n; i++)
/* 276 */       assertEquals(re[i], ra[i], tol); 
/*     */   }
/*     */   private static void assertEqual(float[][] re, float[][] ra, float tol) {
/* 279 */     int n2 = re.length;
/* 280 */     int n1 = (re[0]).length;
/* 281 */     for (int i2 = 0; i2 < n2; i2++) {
/* 282 */       for (int i1 = 0; i1 < n1; i1++)
/* 283 */         assertEquals(re[i2][i1], ra[i2][i1], tol); 
/*     */     } 
/*     */   } private static void assertEqual(float[][][] re, float[][][] ra, float tol) {
/* 286 */     int n3 = re.length;
/* 287 */     int n2 = (re[0]).length;
/* 288 */     int n1 = (re[0][0]).length;
/* 289 */     for (int i3 = 0; i3 < n3; i3++) {
/* 290 */       for (int i2 = 0; i2 < n2; i2++) {
/* 291 */         for (int i1 = 0; i1 < n1; i1++)
/* 292 */           assertEquals(re[i3][i2][i1], ra[i3][i2][i1], tol); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/DifferenceFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */