/*     */ package edu.mines.jtk.io;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayOutputAdapter
/*     */   implements ArrayOutput
/*     */ {
/*     */   private byte[] _buffer;
/*     */   private WritableByteChannel _wbc;
/*     */   private DataOutput _do;
/*     */   private ByteOrder _bo;
/*     */   private ByteBuffer _bb;
/*     */   private CharBuffer _cb;
/*     */   private ShortBuffer _sb;
/*     */   private IntBuffer _ib;
/*     */   private LongBuffer _lb;
/*     */   private FloatBuffer _fb;
/*     */   private DoubleBuffer _db;
/*     */   
/*     */   public ArrayOutputAdapter(DataOutput output) {
/*  36 */     this(output, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(RandomAccessFile file) {
/*  45 */     this(file, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(FileOutputStream stream) {
/*  54 */     this(stream, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(DataOutput output, ByteOrder order) {
/*  63 */     this(null, output, order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(RandomAccessFile file, ByteOrder order) {
/*  73 */     this(file.getChannel(), file, order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(FileOutputStream stream, ByteOrder order) {
/*  83 */     this(stream.getChannel(), new DataOutputStream(stream), order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputAdapter(WritableByteChannel channel, DataOutput output, ByteOrder order) {
/*  96 */     this._wbc = channel;
/*  97 */     this._do = output;
/*  98 */     this._bo = order;
/*  99 */     if (this._wbc != null) {
/* 100 */       this._bb = ByteBuffer.allocateDirect(4096);
/*     */     } else {
/* 102 */       this._buffer = new byte[4096];
/* 103 */       this._bb = ByteBuffer.wrap(this._buffer);
/*     */     } 
/* 105 */     if (order == ByteOrder.BIG_ENDIAN) {
/* 106 */       this._bb.order(ByteOrder.BIG_ENDIAN);
/*     */     } else {
/* 108 */       this._bb.order(ByteOrder.LITTLE_ENDIAN);
/*     */     } 
/* 110 */     this._cb = this._bb.asCharBuffer();
/* 111 */     this._sb = this._bb.asShortBuffer();
/* 112 */     this._ib = this._bb.asIntBuffer();
/* 113 */     this._lb = this._bb.asLongBuffer();
/* 114 */     this._fb = this._bb.asFloatBuffer();
/* 115 */     this._db = this._bb.asDoubleBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrder() {
/* 123 */     return this._bo;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/* 128 */     this._do.write(b);
/*     */   }
/*     */   public void write(byte[] b) throws IOException {
/* 131 */     this._do.write(b);
/*     */   }
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 134 */     this._do.write(b, off, len);
/*     */   }
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 137 */     this._do.writeBoolean(v);
/*     */   }
/*     */   public void writeByte(int v) throws IOException {
/* 140 */     this._do.writeByte(v);
/*     */   }
/*     */   public void writeShort(int v) throws IOException {
/* 143 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 144 */       this._do.write(v >>> 8 & 0xFF);
/* 145 */       this._do.write(v & 0xFF);
/*     */     } else {
/* 147 */       this._do.write(v & 0xFF);
/* 148 */       this._do.write(v >>> 8 & 0xFF);
/*     */     } 
/*     */   }
/*     */   public void writeChar(int v) throws IOException {
/* 152 */     this._do.writeShort(v);
/*     */   }
/*     */   public void writeInt(int v) throws IOException {
/* 155 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 156 */       this._do.write(v >>> 24 & 0xFF);
/* 157 */       this._do.write(v >>> 16 & 0xFF);
/* 158 */       this._do.write(v >>> 8 & 0xFF);
/* 159 */       this._do.write(v & 0xFF);
/*     */     } else {
/* 161 */       this._do.write(v & 0xFF);
/* 162 */       this._do.write(v >>> 8 & 0xFF);
/* 163 */       this._do.write(v >>> 16 & 0xFF);
/* 164 */       this._do.write(v >>> 24 & 0xFF);
/*     */     } 
/*     */   }
/*     */   public void writeLong(long v) throws IOException {
/* 168 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 169 */       this._do.write((int)(v >>> 56L) & 0xFF);
/* 170 */       this._do.write((int)(v >>> 48L) & 0xFF);
/* 171 */       this._do.write((int)(v >>> 40L) & 0xFF);
/* 172 */       this._do.write((int)(v >>> 32L) & 0xFF);
/* 173 */       this._do.write((int)(v >>> 24L) & 0xFF);
/* 174 */       this._do.write((int)(v >>> 16L) & 0xFF);
/* 175 */       this._do.write((int)(v >>> 8L) & 0xFF);
/* 176 */       this._do.write((int)v & 0xFF);
/*     */     } else {
/* 178 */       this._do.write((int)v & 0xFF);
/* 179 */       this._do.write((int)(v >>> 8L) & 0xFF);
/* 180 */       this._do.write((int)(v >>> 16L) & 0xFF);
/* 181 */       this._do.write((int)(v >>> 24L) & 0xFF);
/* 182 */       this._do.write((int)(v >>> 32L) & 0xFF);
/* 183 */       this._do.write((int)(v >>> 40L) & 0xFF);
/* 184 */       this._do.write((int)(v >>> 48L) & 0xFF);
/* 185 */       this._do.write((int)(v >>> 56L) & 0xFF);
/*     */     } 
/*     */   }
/*     */   public void writeFloat(float v) throws IOException {
/* 189 */     writeInt(Float.floatToIntBits(v));
/*     */   }
/*     */   public void writeDouble(double v) throws IOException {
/* 192 */     writeLong(Double.doubleToLongBits(v));
/*     */   }
/*     */   public void writeBytes(String s) throws IOException {
/* 195 */     this._do.writeBytes(s);
/*     */   }
/*     */   public void writeChars(String s) throws IOException {
/* 198 */     int n = s.length();
/* 199 */     for (int i = 0; i < n; i++)
/* 200 */       writeChar(s.charAt(i)); 
/*     */   }
/*     */   
/*     */   public void writeUTF(String s) throws IOException {
/* 204 */     this._do.writeUTF(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v, int k, int n) throws IOException {
/* 214 */     write(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v) throws IOException {
/* 223 */     write(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][] v) throws IOException {
/* 231 */     for (int i = 0; i < v.length; i++) {
/* 232 */       writeBytes(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][][] v) throws IOException {
/* 240 */     for (int i = 0; i < v.length; i++) {
/* 241 */       writeBytes(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v, int k, int n) throws IOException {
/* 251 */     int m = this._cb.capacity(); int j;
/* 252 */     for (j = 0; j < n; j += m) {
/* 253 */       int l = Math.min(n - j, m);
/* 254 */       this._cb.position(0).limit(l);
/* 255 */       this._cb.put(v, k + j, l);
/* 256 */       if (this._wbc != null) {
/* 257 */         this._bb.position(0).limit(l * 2);
/* 258 */         this._wbc.write(this._bb);
/*     */       } else {
/* 260 */         this._do.write(this._buffer, 0, l * 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v) throws IOException {
/* 271 */     writeChars(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][] v) throws IOException {
/* 279 */     for (int i = 0; i < v.length; i++) {
/* 280 */       writeChars(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][][] v) throws IOException {
/* 288 */     for (int i = 0; i < v.length; i++) {
/* 289 */       writeChars(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v, int k, int n) throws IOException {
/* 299 */     int m = this._sb.capacity(); int j;
/* 300 */     for (j = 0; j < n; j += m) {
/* 301 */       int l = Math.min(n - j, m);
/* 302 */       this._sb.position(0).limit(l);
/* 303 */       this._sb.put(v, k + j, l);
/* 304 */       if (this._wbc != null) {
/* 305 */         this._bb.position(0).limit(l * 2);
/* 306 */         this._wbc.write(this._bb);
/*     */       } else {
/* 308 */         this._do.write(this._buffer, 0, l * 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v) throws IOException {
/* 319 */     writeShorts(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][] v) throws IOException {
/* 327 */     for (int i = 0; i < v.length; i++) {
/* 328 */       writeShorts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][][] v) throws IOException {
/* 336 */     for (int i = 0; i < v.length; i++) {
/* 337 */       writeShorts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v, int k, int n) throws IOException {
/* 347 */     int m = this._ib.capacity(); int j;
/* 348 */     for (j = 0; j < n; j += m) {
/* 349 */       int l = Math.min(n - j, m);
/* 350 */       this._ib.position(0).limit(l);
/* 351 */       this._ib.put(v, k + j, l);
/* 352 */       if (this._wbc != null) {
/* 353 */         this._bb.position(0).limit(l * 4);
/* 354 */         this._wbc.write(this._bb);
/*     */       } else {
/* 356 */         this._do.write(this._buffer, 0, l * 4);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v) throws IOException {
/* 367 */     writeInts(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][] v) throws IOException {
/* 375 */     for (int i = 0; i < v.length; i++) {
/* 376 */       writeInts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][][] v) throws IOException {
/* 384 */     for (int i = 0; i < v.length; i++) {
/* 385 */       writeInts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v, int k, int n) throws IOException {
/* 395 */     int m = this._lb.capacity(); int j;
/* 396 */     for (j = 0; j < n; j += m) {
/* 397 */       int l = Math.min(n - j, m);
/* 398 */       this._lb.position(0).limit(l);
/* 399 */       this._lb.put(v, k + j, l);
/* 400 */       if (this._wbc != null) {
/* 401 */         this._bb.position(0).limit(l * 8);
/* 402 */         this._wbc.write(this._bb);
/*     */       } else {
/* 404 */         this._do.write(this._buffer, 0, l * 8);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v) throws IOException {
/* 415 */     writeLongs(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][] v) throws IOException {
/* 423 */     for (int i = 0; i < v.length; i++) {
/* 424 */       writeLongs(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][][] v) throws IOException {
/* 432 */     for (int i = 0; i < v.length; i++) {
/* 433 */       writeLongs(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v, int k, int n) throws IOException {
/* 443 */     int m = this._fb.capacity(); int j;
/* 444 */     for (j = 0; j < n; j += m) {
/* 445 */       int l = Math.min(n - j, m);
/* 446 */       this._fb.position(0).limit(l);
/* 447 */       this._fb.put(v, k + j, l);
/* 448 */       if (this._wbc != null) {
/* 449 */         this._bb.position(0).limit(l * 4);
/* 450 */         this._wbc.write(this._bb);
/*     */       } else {
/* 452 */         this._do.write(this._buffer, 0, l * 4);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v) throws IOException {
/* 463 */     writeFloats(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][] v) throws IOException {
/* 471 */     for (int i = 0; i < v.length; i++) {
/* 472 */       writeFloats(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][][] v) throws IOException {
/* 480 */     for (int i = 0; i < v.length; i++) {
/* 481 */       writeFloats(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v, int k, int n) throws IOException {
/* 491 */     int m = this._db.capacity(); int j;
/* 492 */     for (j = 0; j < n; j += m) {
/* 493 */       int l = Math.min(n - j, m);
/* 494 */       this._db.position(0).limit(l);
/* 495 */       this._db.put(v, k + j, l);
/* 496 */       if (this._wbc != null) {
/* 497 */         this._bb.position(0).limit(l * 8);
/* 498 */         this._wbc.write(this._bb);
/*     */       } else {
/* 500 */         this._do.write(this._buffer, 0, l * 8);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v) throws IOException {
/* 511 */     writeDoubles(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][] v) throws IOException {
/* 519 */     for (int i = 0; i < v.length; i++) {
/* 520 */       writeDoubles(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][][] v) throws IOException {
/* 528 */     for (int i = 0; i < v.length; i++)
/* 529 */       writeDoubles(v[i]); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/ArrayOutputAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */