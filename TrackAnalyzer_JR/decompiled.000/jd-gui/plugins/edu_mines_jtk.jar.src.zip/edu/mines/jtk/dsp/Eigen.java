/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Eigen
/*     */ {
/*     */   public static void solveSymmetric22(float[][] a, float[][] v, float[] d) {
/*  33 */     float a00 = a[0][0];
/*  34 */     float a01 = a[0][1], a11 = a[1][1];
/*     */ 
/*     */     
/*  37 */     float v00 = 1.0F, v01 = 0.0F;
/*  38 */     float v10 = 0.0F, v11 = 1.0F;
/*     */ 
/*     */     
/*  41 */     if (a01 != 0.0F) {
/*  42 */       float t, tiny = 0.1F * MathPlus.sqrt(1.1920929E-7F);
/*     */       
/*  44 */       float u = a11 - a00;
/*  45 */       if (MathPlus.abs(a01) < tiny * MathPlus.abs(u)) {
/*  46 */         t = a01 / u;
/*     */       } else {
/*  48 */         float f = 0.5F * u / a01;
/*  49 */         t = (f >= 0.0F) ? (1.0F / (f + MathPlus.sqrt(1.0F + f * f))) : (1.0F / (f - MathPlus.sqrt(1.0F + f * f)));
/*     */       } 
/*  51 */       float c = 1.0F / MathPlus.sqrt(1.0F + t * t);
/*  52 */       float s = t * c;
/*  53 */       u = s / (1.0F + c);
/*  54 */       float r = t * a01;
/*  55 */       a00 -= r;
/*  56 */       a11 += r;
/*  57 */       a01 = 0.0F;
/*  58 */       float vpr = v00;
/*  59 */       float vqr = v10;
/*  60 */       v00 = vpr - s * (vqr + vpr * u);
/*  61 */       v10 = vqr + s * (vpr - vqr * u);
/*  62 */       vpr = v01;
/*  63 */       vqr = v11;
/*  64 */       v01 = vpr - s * (vqr + vpr * u);
/*  65 */       v11 = vqr + s * (vpr - vqr * u);
/*     */     } 
/*     */ 
/*     */     
/*  69 */     d[0] = a00;
/*  70 */     d[1] = a11;
/*  71 */     v[0][0] = v00; v[0][1] = v01;
/*  72 */     v[1][0] = v10; v[1][1] = v11;
/*     */ 
/*     */     
/*  75 */     if (d[0] < d[1]) {
/*  76 */       float dt = d[1];
/*  77 */       d[1] = d[0];
/*  78 */       d[0] = dt;
/*  79 */       float[] vt = v[1];
/*  80 */       v[1] = v[0];
/*  81 */       v[0] = vt;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void solveSymmetric22(double[][] a, double[][] v, double[] d) {
/*  97 */     double a00 = a[0][0];
/*  98 */     double a01 = a[0][1], a11 = a[1][1];
/*     */ 
/*     */     
/* 101 */     double v00 = 1.0D, v01 = 0.0D;
/* 102 */     double v10 = 0.0D, v11 = 1.0D;
/*     */ 
/*     */     
/* 105 */     if (a01 != 0.0D) {
/* 106 */       double t, tiny = 0.10000000149011612D * MathPlus.sqrt(2.220446049250313E-16D);
/*     */       
/* 108 */       double u = a11 - a00;
/* 109 */       if (MathPlus.abs(a01) < tiny * MathPlus.abs(u)) {
/* 110 */         t = a01 / u;
/*     */       } else {
/* 112 */         double d1 = 0.5D * u / a01;
/* 113 */         t = (d1 >= 0.0D) ? (1.0D / (d1 + MathPlus.sqrt(1.0D + d1 * d1))) : (1.0D / (d1 - MathPlus.sqrt(1.0D + d1 * d1)));
/*     */       } 
/* 115 */       double c = 1.0D / MathPlus.sqrt(1.0D + t * t);
/* 116 */       double s = t * c;
/* 117 */       u = s / (1.0D + c);
/* 118 */       double r = t * a01;
/* 119 */       a00 -= r;
/* 120 */       a11 += r;
/* 121 */       a01 = 0.0D;
/* 122 */       double vpr = v00;
/* 123 */       double vqr = v10;
/* 124 */       v00 = vpr - s * (vqr + vpr * u);
/* 125 */       v10 = vqr + s * (vpr - vqr * u);
/* 126 */       vpr = v01;
/* 127 */       vqr = v11;
/* 128 */       v01 = vpr - s * (vqr + vpr * u);
/* 129 */       v11 = vqr + s * (vpr - vqr * u);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     d[0] = a00;
/* 134 */     d[1] = a11;
/* 135 */     v[0][0] = v00; v[0][1] = v01;
/* 136 */     v[1][0] = v10; v[1][1] = v11;
/*     */ 
/*     */     
/* 139 */     if (d[0] < d[1]) {
/* 140 */       double dt = d[1];
/* 141 */       d[1] = d[0];
/* 142 */       d[0] = dt;
/* 143 */       double[] vt = v[1];
/* 144 */       v[1] = v[0];
/* 145 */       v[0] = vt;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void solveSymmetric33(float[][] a, float[][] v, float[] d) {
/* 161 */     float a00 = a[0][0];
/* 162 */     float a01 = a[0][1], a11 = a[1][1];
/* 163 */     float a02 = a[0][2], a12 = a[1][2], a22 = a[2][2];
/*     */ 
/*     */     
/* 166 */     float v00 = 1.0F, v01 = 0.0F, v02 = 0.0F;
/* 167 */     float v10 = 0.0F, v11 = 1.0F, v12 = 0.0F;
/* 168 */     float v20 = 0.0F, v21 = 0.0F, v22 = 1.0F;
/*     */ 
/*     */     
/* 171 */     float tiny = 0.1F * MathPlus.sqrt(1.1920929E-7F);
/*     */ 
/*     */     
/* 174 */     float aa01 = MathPlus.abs(a01);
/* 175 */     float aa02 = MathPlus.abs(a02);
/* 176 */     float aa12 = MathPlus.abs(a12);
/*     */ 
/*     */ 
/*     */     
/* 180 */     for (int nrot = 0; aa01 + aa02 + aa12 > 0.0F; nrot++) {
/* 181 */       Check.state((nrot < 100), "number of Jacobi rotations is less than 100");
/*     */ 
/*     */ 
/*     */       
/* 185 */       if (aa01 >= aa02 && aa01 >= aa12) {
/* 186 */         float t, u = a11 - a00;
/* 187 */         if (MathPlus.abs(a01) < tiny * MathPlus.abs(u)) {
/* 188 */           t = a01 / u;
/*     */         } else {
/* 190 */           float f = 0.5F * u / a01;
/* 191 */           t = (f >= 0.0F) ? (1.0F / (f + MathPlus.sqrt(1.0F + f * f))) : (1.0F / (f - MathPlus.sqrt(1.0F + f * f)));
/*     */         } 
/* 193 */         float c = 1.0F / MathPlus.sqrt(1.0F + t * t);
/* 194 */         float s = t * c;
/* 195 */         u = s / (1.0F + c);
/* 196 */         float r = t * a01;
/* 197 */         a00 -= r;
/* 198 */         a11 += r;
/* 199 */         a01 = 0.0F;
/* 200 */         float apr = a02;
/* 201 */         float aqr = a12;
/* 202 */         a02 = apr - s * (aqr + apr * u);
/* 203 */         a12 = aqr + s * (apr - aqr * u);
/* 204 */         float vpr = v00;
/* 205 */         float vqr = v10;
/* 206 */         v00 = vpr - s * (vqr + vpr * u);
/* 207 */         v10 = vqr + s * (vpr - vqr * u);
/* 208 */         vpr = v01;
/* 209 */         vqr = v11;
/* 210 */         v01 = vpr - s * (vqr + vpr * u);
/* 211 */         v11 = vqr + s * (vpr - vqr * u);
/* 212 */         vpr = v02;
/* 213 */         vqr = v12;
/* 214 */         v02 = vpr - s * (vqr + vpr * u);
/* 215 */         v12 = vqr + s * (vpr - vqr * u);
/*     */ 
/*     */       
/*     */       }
/* 219 */       else if (aa02 >= aa01 && aa02 >= aa12) {
/* 220 */         float t, u = a22 - a00;
/* 221 */         if (MathPlus.abs(a02) < tiny * MathPlus.abs(u)) {
/* 222 */           t = a02 / u;
/*     */         } else {
/* 224 */           float f = 0.5F * u / a02;
/* 225 */           t = (f >= 0.0F) ? (1.0F / (f + MathPlus.sqrt(1.0F + f * f))) : (1.0F / (f - MathPlus.sqrt(1.0F + f * f)));
/*     */         } 
/* 227 */         float c = 1.0F / MathPlus.sqrt(1.0F + t * t);
/* 228 */         float s = t * c;
/* 229 */         u = s / (1.0F + c);
/* 230 */         float r = t * a02;
/* 231 */         a00 -= r;
/* 232 */         a22 += r;
/* 233 */         a02 = 0.0F;
/* 234 */         float apr = a01;
/* 235 */         float aqr = a12;
/* 236 */         a01 = apr - s * (aqr + apr * u);
/* 237 */         a12 = aqr + s * (apr - aqr * u);
/* 238 */         float vpr = v00;
/* 239 */         float vqr = v20;
/* 240 */         v00 = vpr - s * (vqr + vpr * u);
/* 241 */         v20 = vqr + s * (vpr - vqr * u);
/* 242 */         vpr = v01;
/* 243 */         vqr = v21;
/* 244 */         v01 = vpr - s * (vqr + vpr * u);
/* 245 */         v21 = vqr + s * (vpr - vqr * u);
/* 246 */         vpr = v02;
/* 247 */         vqr = v22;
/* 248 */         v02 = vpr - s * (vqr + vpr * u);
/* 249 */         v22 = vqr + s * (vpr - vqr * u);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 254 */         float t, u = a22 - a11;
/* 255 */         if (MathPlus.abs(a12) < tiny * MathPlus.abs(u)) {
/* 256 */           t = a12 / u;
/*     */         } else {
/* 258 */           float f = 0.5F * u / a12;
/* 259 */           t = (f >= 0.0F) ? (1.0F / (f + MathPlus.sqrt(1.0F + f * f))) : (1.0F / (f - MathPlus.sqrt(1.0F + f * f)));
/*     */         } 
/* 261 */         float c = 1.0F / MathPlus.sqrt(1.0F + t * t);
/* 262 */         float s = t * c;
/* 263 */         u = s / (1.0F + c);
/* 264 */         float r = t * a12;
/* 265 */         a11 -= r;
/* 266 */         a22 += r;
/* 267 */         a12 = 0.0F;
/* 268 */         float apr = a01;
/* 269 */         float aqr = a02;
/* 270 */         a01 = apr - s * (aqr + apr * u);
/* 271 */         a02 = aqr + s * (apr - aqr * u);
/* 272 */         float vpr = v10;
/* 273 */         float vqr = v20;
/* 274 */         v10 = vpr - s * (vqr + vpr * u);
/* 275 */         v20 = vqr + s * (vpr - vqr * u);
/* 276 */         vpr = v11;
/* 277 */         vqr = v21;
/* 278 */         v11 = vpr - s * (vqr + vpr * u);
/* 279 */         v21 = vqr + s * (vpr - vqr * u);
/* 280 */         vpr = v12;
/* 281 */         vqr = v22;
/* 282 */         v12 = vpr - s * (vqr + vpr * u);
/* 283 */         v22 = vqr + s * (vpr - vqr * u);
/*     */       } 
/*     */ 
/*     */       
/* 287 */       aa01 = MathPlus.abs(a01);
/* 288 */       aa02 = MathPlus.abs(a02);
/* 289 */       aa12 = MathPlus.abs(a12);
/*     */     } 
/*     */ 
/*     */     
/* 293 */     d[0] = a00;
/* 294 */     d[1] = a11;
/* 295 */     d[2] = a22;
/* 296 */     v[0][0] = v00; v[0][1] = v01; v[0][2] = v02;
/* 297 */     v[1][0] = v10; v[1][1] = v11; v[1][2] = v12;
/* 298 */     v[2][0] = v20; v[2][1] = v21; v[2][2] = v22;
/*     */ 
/*     */     
/* 301 */     for (int i = 0; i < 3; i++) {
/* 302 */       for (int j = i; j > 0 && d[j - 1] < d[j]; j--) {
/* 303 */         float dj = d[j];
/* 304 */         d[j] = d[j - 1];
/* 305 */         d[j - 1] = dj;
/* 306 */         float[] vj = v[j];
/* 307 */         v[j] = v[j - 1];
/* 308 */         v[j - 1] = vj;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Eigen.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */