/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineSearch
/*     */ {
/*     */   public static final int CONVERGED = 1;
/*     */   public static final int SMIN = 2;
/*     */   public static final int SMAX = 3;
/*     */   public static final int STOL = 4;
/*     */   public static final int FAILED = 5;
/*     */   private static final double SLO_FACTOR = 1.1D;
/*     */   private static final double SHI_FACTOR = 4.0D;
/*     */   private Function _func;
/*     */   private double _stol;
/*     */   private double _ftol;
/*     */   private double _gtol;
/*     */   
/*     */   public static interface Function
/*     */   {
/*     */     double[] evaluate(double param1Double);
/*     */   }
/*     */   
/*     */   public class Result
/*     */   {
/*     */     public final double s;
/*     */     public final double f;
/*     */     public final double g;
/*     */     public final int ended;
/*     */     public final int neval;
/*     */     
/*     */     public boolean converged() {
/* 154 */       return (this.ended == 1);
/*     */     }
/*     */     
/*     */     private Result(double s, double f, double g, int ended, int neval) {
/* 158 */       this.s = s;
/* 159 */       this.f = f;
/* 160 */       this.g = g;
/* 161 */       this.ended = ended;
/* 162 */       this.neval = neval;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineSearch(Function func, double stol, double ftol, double gtol) {
/* 176 */     Check.argument((stol >= 0.0D), "stol>=0.0");
/* 177 */     Check.argument((ftol >= 0.0D), "ftol>=0.0");
/* 178 */     Check.argument((gtol >= 0.0D), "gtol>=0.0");
/* 179 */     this._func = func;
/* 180 */     this._stol = stol;
/* 181 */     this._ftol = ftol;
/* 182 */     this._gtol = gtol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result search(double s, double f, double g, double smin, double smax) {
/* 200 */     Check.argument((smin >= 0.0D), "smin>=0.0");
/* 201 */     Check.argument((smin <= smax), "smin<=smax");
/* 202 */     Check.argument((smin <= s), "smin<=s");
/* 203 */     Check.argument((s <= smax), "s<=smax");
/* 204 */     Check.argument((g < 0.0D), "g<0.0");
/*     */     
/* 206 */     StepInterval si = new StepInterval();
/*     */     
/* 208 */     boolean stage1 = true;
/* 209 */     boolean bracketed = false;
/* 210 */     double finit = f;
/* 211 */     double ginit = g;
/* 212 */     double gtest = this._ftol * ginit;
/* 213 */     double width = smax - smin;
/* 214 */     double widthOld = 2.0D * width;
/*     */     
/* 216 */     double sa = 0.0D;
/* 217 */     double fa = finit;
/* 218 */     double ga = ginit;
/* 219 */     double sb = 0.0D;
/* 220 */     double fb = finit;
/* 221 */     double gb = ginit;
/* 222 */     double slo = 0.0D;
/* 223 */     double shi = s * 5.0D;
/*     */     
/* 225 */     double[] fg = this._func.evaluate(s);
/* 226 */     f = fg[0];
/* 227 */     g = fg[1];
/* 228 */     int neval = 1;
/* 229 */     int ended = 0;
/* 230 */     while (ended == 0) {
/*     */ 
/*     */       
/* 233 */       double ftest = finit + s * gtest;
/* 234 */       if (stage1 && f <= ftest && g >= 0.0D) {
/* 235 */         stage1 = false;
/*     */       }
/*     */       
/* 238 */       if (bracketed && (s <= slo || s >= shi)) {
/* 239 */         ended = 5;
/* 240 */       } else if (bracketed && shi - slo <= this._stol * shi) {
/* 241 */         ended = 4;
/* 242 */       } else if (s == smax && f <= ftest && g <= gtest) {
/* 243 */         ended = 3;
/* 244 */       } else if (s == smin && (f > ftest || g >= gtest)) {
/* 245 */         ended = 2;
/* 246 */       } else if (f <= ftest && MathPlus.abs(g) <= this._gtol * -ginit) {
/* 247 */         ended = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 256 */         if (stage1 && f <= fa && f > ftest) {
/*     */ 
/*     */           
/* 259 */           double fm = f - s * gtest;
/* 260 */           double fam = fa - sa * gtest;
/* 261 */           double fbm = fb - sb * gtest;
/* 262 */           double gm = g - gtest;
/* 263 */           double gam = ga - gtest;
/* 264 */           double gbm = gb - gtest;
/*     */ 
/*     */           
/* 267 */           si.sa = sa; si.fa = fam; si.ga = gam;
/* 268 */           si.sb = sb; si.fb = fbm; si.gb = gbm;
/* 269 */           si.bracketed = bracketed;
/* 270 */           s = updateStep(s, fm, gm, slo, shi, si);
/* 271 */           sa = si.sa; fam = si.fa; gam = si.ga;
/* 272 */           sb = si.sb; fbm = si.fb; gbm = si.gb;
/* 273 */           bracketed = si.bracketed;
/*     */ 
/*     */           
/* 276 */           fa = fam + sa * gtest;
/* 277 */           fb = fbm + sb * gtest;
/* 278 */           ga = gam + gtest;
/* 279 */           gb = gbm + gtest;
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 286 */           si.sa = sa; si.fa = fa; si.ga = ga;
/* 287 */           si.sb = sb; si.fb = fb; si.gb = gb;
/* 288 */           si.bracketed = bracketed;
/* 289 */           s = updateStep(s, f, g, slo, shi, si);
/* 290 */           sa = si.sa; fa = si.fa; ga = si.ga;
/* 291 */           sb = si.sb; fb = si.fb; gb = si.gb;
/* 292 */           bracketed = si.bracketed;
/*     */         } 
/*     */ 
/*     */         
/* 296 */         if (bracketed) {
/* 297 */           if (MathPlus.abs(sb - sa) >= 0.66D * widthOld)
/* 298 */             s = sa + 0.5D * (sb - sa); 
/* 299 */           widthOld = width;
/* 300 */           width = MathPlus.abs(sb - sa);
/*     */         } 
/*     */ 
/*     */         
/* 304 */         if (bracketed) {
/* 305 */           slo = MathPlus.min(sa, sb);
/* 306 */           shi = MathPlus.max(sa, sb);
/*     */         } else {
/* 308 */           slo = s + 1.1D * (s - sa);
/* 309 */           shi = s + 4.0D * (s - sa);
/*     */         } 
/*     */ 
/*     */         
/* 313 */         s = MathPlus.max(s, smin);
/* 314 */         s = MathPlus.min(s, smax);
/*     */ 
/*     */         
/* 317 */         if ((bracketed && (s <= slo || s >= shi)) || (bracketed && shi - slo <= this._stol * shi))
/*     */         {
/* 319 */           s = sa;
/*     */         }
/*     */       } 
/*     */       
/* 323 */       fg = this._func.evaluate(s);
/* 324 */       f = fg[0];
/* 325 */       g = fg[1];
/* 326 */       neval++;
/*     */     } 
/*     */     
/* 329 */     return new Result(s, f, g, ended, neval);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StepInterval
/*     */   {
/*     */     double sa;
/*     */     
/*     */     double fa;
/*     */     
/*     */     double ga;
/*     */     double sb;
/*     */     double fb;
/*     */     double gb;
/*     */     boolean bracketed;
/*     */     
/*     */     private StepInterval() {}
/*     */   }
/*     */   
/*     */   private double updateStep(double sp, double fp, double gp, double smin, double smax, StepInterval si) {
/* 349 */     double sa = si.sa;
/* 350 */     double fa = si.fa;
/* 351 */     double ga = si.ga;
/* 352 */     double sb = si.sb;
/* 353 */     double fb = si.fb;
/* 354 */     double gb = si.gb;
/* 355 */     boolean bracketed = si.bracketed;
/*     */     
/* 357 */     double sgng = gp * ga / MathPlus.abs(ga);
/* 358 */     double spf = sp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 364 */     if (fp > fa) {
/* 365 */       double theta = 3.0D * (fa - fp) / (sp - sa) + ga + gp;
/* 366 */       double s = MathPlus.max(MathPlus.abs(theta), MathPlus.abs(ga), MathPlus.abs(gp));
/* 367 */       double gamma = s * MathPlus.sqrt(theta / s * theta / s - ga / s * gp / s);
/* 368 */       if (sp < sa)
/* 369 */         gamma = -gamma; 
/* 370 */       double p = gamma - ga + theta;
/* 371 */       double q = gamma - ga + gamma + gp;
/* 372 */       double r = p / q;
/* 373 */       double spc = sa + r * (sp - sa);
/* 374 */       double spq = sa + ga / ((fa - fp) / (sp - sa) + ga) / 2.0D * (sp - sa);
/* 375 */       if (MathPlus.abs(spc - sa) < MathPlus.abs(spq - sa)) {
/* 376 */         spf = spc;
/*     */       } else {
/* 378 */         spf = spc + (spq - spc) / 2.0D;
/*     */       } 
/* 380 */       bracketed = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 387 */     else if (sgng < 0.0D) {
/* 388 */       double theta = 3.0D * (fa - fp) / (sp - sa) + ga + gp;
/* 389 */       double s = MathPlus.max(MathPlus.abs(theta), MathPlus.abs(ga), MathPlus.abs(gp));
/* 390 */       double gamma = s * MathPlus.sqrt(theta / s * theta / s - ga / s * gp / s);
/* 391 */       if (sp > sa)
/* 392 */         gamma = -gamma; 
/* 393 */       double p = gamma - gp + theta;
/* 394 */       double q = gamma - gp + gamma + ga;
/* 395 */       double r = p / q;
/* 396 */       double spc = sp + r * (sa - sp);
/* 397 */       double spq = sp + gp / (gp - ga) * (sa - sp);
/* 398 */       if (MathPlus.abs(spc - sp) > MathPlus.abs(spq - sp)) {
/* 399 */         spf = spc;
/*     */       } else {
/* 401 */         spf = spq;
/*     */       } 
/* 403 */       bracketed = true;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 408 */     else if (MathPlus.abs(gp) < MathPlus.abs(ga)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 414 */       double spc, theta = 3.0D * (fa - fp) / (sp - sa) + ga + gp;
/* 415 */       double s = MathPlus.max(MathPlus.abs(theta), MathPlus.abs(ga), MathPlus.abs(gp));
/*     */ 
/*     */ 
/*     */       
/* 419 */       double gamma = s * MathPlus.sqrt(MathPlus.max(0.0D, theta / s * theta / s - ga / s * gp / s));
/* 420 */       if (sp > sa)
/* 421 */         gamma = -gamma; 
/* 422 */       double p = gamma - gp + theta;
/* 423 */       double q = gamma + ga - gp + gamma;
/* 424 */       double r = p / q;
/*     */       
/* 426 */       if (r < 0.0D && gamma != 0.0D) {
/* 427 */         spc = sp + r * (sa - sp);
/* 428 */       } else if (sp > sa) {
/* 429 */         spc = smax;
/*     */       } else {
/* 431 */         spc = smin;
/*     */       } 
/* 433 */       double spq = sp + gp / (gp - ga) * (sa - sp);
/*     */ 
/*     */       
/* 436 */       if (bracketed)
/*     */       {
/*     */ 
/*     */         
/* 440 */         if (MathPlus.abs(spc - sp) < MathPlus.abs(spq - sp)) {
/* 441 */           spf = spc;
/*     */         } else {
/* 443 */           spf = spq;
/*     */         } 
/* 445 */         if (sp > sa) {
/* 446 */           spf = MathPlus.min(sp + 0.66D * (sb - sp), spf);
/*     */         } else {
/* 448 */           spf = MathPlus.max(sp + 0.66D * (sb - sp), spf);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 457 */         if (MathPlus.abs(spc - sp) > MathPlus.abs(spq - sp)) {
/* 458 */           spf = spc;
/*     */         } else {
/* 460 */           spf = spq;
/*     */         } 
/* 462 */         spf = MathPlus.min(smax, spf);
/* 463 */         spf = MathPlus.max(smin, spf);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 472 */     else if (bracketed) {
/* 473 */       double theta = 3.0D * (fp - fb) / (sb - sp) + gb + gp;
/* 474 */       double s = MathPlus.max(MathPlus.abs(theta), MathPlus.abs(gb), MathPlus.abs(gp));
/* 475 */       double gamma = s * MathPlus.sqrt(theta / s * theta / s - gb / s * gp / s);
/* 476 */       if (sp > sb)
/* 477 */         gamma = -gamma; 
/* 478 */       double p = gamma - gp + theta;
/* 479 */       double q = gamma - gp + gamma + gb;
/* 480 */       double r = p / q;
/* 481 */       double spc = sp + r * (sb - sp);
/* 482 */       spf = spc;
/* 483 */     } else if (sp > sa) {
/* 484 */       spf = smax;
/*     */     } else {
/* 486 */       spf = smin;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 491 */     if (fp > fa) {
/* 492 */       si.sb = sp;
/* 493 */       si.fb = fp;
/* 494 */       si.gb = gp;
/*     */     } else {
/* 496 */       if (sgng < 0.0D) {
/* 497 */         si.sb = sa;
/* 498 */         si.fb = fa;
/* 499 */         si.gb = ga;
/*     */       } 
/* 501 */       si.sa = sp;
/* 502 */       si.fa = fp;
/* 503 */       si.ga = gp;
/*     */     } 
/* 505 */     si.bracketed = bracketed;
/*     */ 
/*     */     
/* 508 */     return spf;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/LineSearch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */