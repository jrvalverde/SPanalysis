/*     */ package edu.mines.jtk.mesh.test;
/*     */ 
/*     */ import edu.mines.jtk.mesh.TetMesh;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TetMeshTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(TetMeshTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testNabors() {
/*  29 */     TetMesh tm = new TetMesh();
/*  30 */     TetMesh.Node n0 = new TetMesh.Node(1.0F, 0.0F, 0.0F);
/*  31 */     TetMesh.Node n1 = new TetMesh.Node(0.0F, 1.0F, 0.0F);
/*  32 */     TetMesh.Node n2 = new TetMesh.Node(0.0F, 0.0F, 1.0F);
/*  33 */     TetMesh.Node n3 = new TetMesh.Node(0.0F, 0.0F, 0.0F);
/*  34 */     TetMesh.Node n4 = new TetMesh.Node(1.1F, 1.1F, 1.1F);
/*  35 */     tm.addNode(n0);
/*  36 */     tm.addNode(n1);
/*  37 */     tm.addNode(n2);
/*  38 */     tm.addNode(n3);
/*  39 */     tm.addNode(n4);
/*  40 */     assertEquals(2, (tm.getTetNabors(n0)).length);
/*  41 */     assertEquals(2, (tm.getTetNabors(n1)).length);
/*  42 */     assertEquals(2, (tm.getTetNabors(n2)).length);
/*  43 */     assertEquals(1, (tm.getTetNabors(n3)).length);
/*  44 */     assertEquals(1, (tm.getTetNabors(n4)).length);
/*  45 */     assertEquals(2, (tm.getTetNabors(tm.findEdge(n0, n1))).length);
/*  46 */     assertEquals(2, (tm.getTetNabors(tm.findEdge(n1, n2))).length);
/*  47 */     assertEquals(2, (tm.getTetNabors(tm.findEdge(n2, n0))).length);
/*  48 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n0, n3))).length);
/*  49 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n0, n4))).length);
/*  50 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n1, n3))).length);
/*  51 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n1, n4))).length);
/*  52 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n2, n3))).length);
/*  53 */     assertEquals(1, (tm.getTetNabors(tm.findEdge(n2, n4))).length);
/*  54 */     assertEquals(2, (tm.getTetNabors(tm.findFace(n0, n1, n2))).length);
/*  55 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n0, n2, n3))).length);
/*  56 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n1, n3, n2))).length);
/*  57 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n0, n3, n1))).length);
/*  58 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n0, n4, n2))).length);
/*  59 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n0, n1, n4))).length);
/*  60 */     assertEquals(1, (tm.getTetNabors(tm.findFace(n1, n2, n4))).length);
/*  61 */     assertEquals(3, (tm.getFaceNabors(tm.findEdge(n0, n1))).length);
/*  62 */     assertEquals(3, (tm.getFaceNabors(tm.findEdge(n1, n2))).length);
/*  63 */     assertEquals(3, (tm.getFaceNabors(tm.findEdge(n2, n0))).length);
/*  64 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n0, n3))).length);
/*  65 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n0, n4))).length);
/*  66 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n1, n3))).length);
/*  67 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n1, n4))).length);
/*  68 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n2, n3))).length);
/*  69 */     assertEquals(2, (tm.getFaceNabors(tm.findEdge(n2, n4))).length);
/*  70 */     assertEquals(4, (tm.getEdgeNabors(n0)).length);
/*  71 */     assertEquals(4, (tm.getEdgeNabors(n1)).length);
/*  72 */     assertEquals(4, (tm.getEdgeNabors(n2)).length);
/*  73 */     assertEquals(3, (tm.getEdgeNabors(n3)).length);
/*  74 */     assertEquals(3, (tm.getEdgeNabors(n4)).length);
/*  75 */     assertEquals(4, (tm.getNodeNabors(n0)).length);
/*  76 */     assertEquals(4, (tm.getNodeNabors(n1)).length);
/*  77 */     assertEquals(4, (tm.getNodeNabors(n2)).length);
/*  78 */     assertEquals(3, (tm.getNodeNabors(n3)).length);
/*  79 */     assertEquals(3, (tm.getNodeNabors(n4)).length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testIO() throws IOException, ClassNotFoundException {
/*  85 */     TetMesh.Node n000 = new TetMesh.Node(0.0F, 0.0F, 0.0F);
/*  86 */     TetMesh.Node n001 = new TetMesh.Node(0.0F, 0.0F, 1.0F);
/*  87 */     TetMesh.Node n010 = new TetMesh.Node(0.0F, 1.0F, 0.0F);
/*  88 */     TetMesh.Node n011 = new TetMesh.Node(0.0F, 1.0F, 1.0F);
/*  89 */     TetMesh.Node n100 = new TetMesh.Node(1.0F, 0.0F, 0.0F);
/*  90 */     TetMesh.Node n101 = new TetMesh.Node(1.0F, 0.0F, 1.0F);
/*  91 */     TetMesh.Node n110 = new TetMesh.Node(1.0F, 1.0F, 0.0F);
/*  92 */     TetMesh.Node n111 = new TetMesh.Node(1.0F, 1.0F, 1.0F);
/*  93 */     TetMesh tm = new TetMesh();
/*  94 */     tm.addNode(n000);
/*  95 */     tm.addNode(n001);
/*  96 */     tm.addNode(n010);
/*  97 */     tm.addNode(n011);
/*  98 */     tm.addNode(n100);
/*  99 */     tm.addNode(n101);
/* 100 */     tm.addNode(n110);
/* 101 */     tm.addNode(n111);
/* 102 */     int nnode = tm.countNodes();
/* 103 */     int ntet = tm.countTets();
/* 104 */     assertEquals(8, nnode);
/* 105 */     TetMesh.NodePropertyMap map = tm.getNodePropertyMap("foo");
/* 106 */     map.put(n000, new Integer(0));
/* 107 */     map.put(n001, new Integer(1));
/* 108 */     map.put(n010, new Integer(2));
/* 109 */     map.put(n011, new Integer(3));
/* 110 */     map.put(n100, new Integer(4));
/* 111 */     map.put(n101, new Integer(5));
/* 112 */     map.put(n110, new Integer(6));
/* 113 */     map.put(n111, new Integer(7));
/*     */ 
/*     */     
/* 116 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 117 */     ObjectOutputStream oos = new ObjectOutputStream(baos);
/* 118 */     oos.writeObject(tm);
/* 119 */     baos.close();
/* 120 */     ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
/* 121 */     ObjectInputStream ois = new ObjectInputStream(bais);
/* 122 */     tm = (TetMesh)ois.readObject();
/* 123 */     bais.close();
/* 124 */     assertEquals(nnode, tm.countNodes());
/* 125 */     assertEquals(ntet, tm.countTets());
/*     */ 
/*     */     
/* 128 */     String name = tm.getNodePropertyMapNames()[0];
/* 129 */     assertEquals("foo", name);
/* 130 */     map = tm.getNodePropertyMap(name);
/* 131 */     n000 = tm.findNodeNearest(0.0F, 0.0F, 0.0F);
/* 132 */     n001 = tm.findNodeNearest(0.0F, 0.0F, 1.0F);
/* 133 */     n010 = tm.findNodeNearest(0.0F, 1.0F, 0.0F);
/* 134 */     n011 = tm.findNodeNearest(0.0F, 1.0F, 1.0F);
/* 135 */     n100 = tm.findNodeNearest(1.0F, 0.0F, 0.0F);
/* 136 */     n101 = tm.findNodeNearest(1.0F, 0.0F, 1.0F);
/* 137 */     n110 = tm.findNodeNearest(1.0F, 1.0F, 0.0F);
/* 138 */     n111 = tm.findNodeNearest(1.0F, 1.0F, 1.0F);
/* 139 */     assertEquals(0, ((Integer)map.get(n000)).intValue());
/* 140 */     assertEquals(1, ((Integer)map.get(n001)).intValue());
/* 141 */     assertEquals(2, ((Integer)map.get(n010)).intValue());
/* 142 */     assertEquals(3, ((Integer)map.get(n011)).intValue());
/* 143 */     assertEquals(4, ((Integer)map.get(n100)).intValue());
/* 144 */     assertEquals(5, ((Integer)map.get(n101)).intValue());
/* 145 */     assertEquals(6, ((Integer)map.get(n110)).intValue());
/* 146 */     assertEquals(7, ((Integer)map.get(n111)).intValue());
/*     */   }
/*     */   
/*     */   public void testTetListener() {
/* 150 */     TetMesh tm = new TetMesh();
/* 151 */     tm.addNode(new TetMesh.Node(0.0F, 0.0F, 0.0F));
/* 152 */     tm.addNode(new TetMesh.Node(1.0F, 0.0F, 0.0F));
/* 153 */     tm.addNode(new TetMesh.Node(0.0F, 1.0F, 0.0F));
/* 154 */     tm.addNode(new TetMesh.Node(0.0F, 0.0F, 1.0F));
/* 155 */     TetListener tl = new TetListener();
/* 156 */     tm.addTetListener(tl);
/* 157 */     TetMesh.Node node = new TetMesh.Node(0.1F, 0.1F, 0.1F);
/* 158 */     tm.addNode(node);
/* 159 */     assertEquals(4, tl.countAdded());
/* 160 */     assertEquals(1, tl.countRemoved());
/* 161 */     tm.removeNode(node);
/* 162 */     assertEquals(5, tl.countAdded());
/* 163 */     assertEquals(5, tl.countRemoved());
/*     */   }
/*     */   private static class TetListener implements TetMesh.TetListener { private int _nadded;
/*     */     public void tetAdded(TetMesh mesh, TetMesh.Tet tet) {
/* 167 */       this._nadded++;
/*     */     } private int _nremoved; private TetListener() {}
/*     */     public void tetRemoved(TetMesh mesh, TetMesh.Tet tet) {
/* 170 */       this._nremoved++;
/*     */     }
/*     */     public int countAdded() {
/* 173 */       return this._nadded;
/*     */     }
/*     */     public int countRemoved() {
/* 176 */       return this._nremoved;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testFinds() {
/* 183 */     TetMesh tm = new TetMesh();
/* 184 */     TetMesh.Node n0 = new TetMesh.Node(0.0F, 0.0F, 0.0F);
/* 185 */     TetMesh.Node n1 = new TetMesh.Node(1.0F, 0.0F, 0.0F);
/* 186 */     TetMesh.Node n2 = new TetMesh.Node(0.0F, 1.0F, 0.0F);
/* 187 */     TetMesh.Node n3 = new TetMesh.Node(0.0F, 0.0F, 1.0F);
/* 188 */     TetMesh.Node n4 = new TetMesh.Node(9.0F, 9.0F, 9.0F);
/* 189 */     tm.addNode(n0);
/* 190 */     tm.addNode(n1);
/* 191 */     tm.addNode(n2);
/* 192 */     tm.addNode(n3);
/* 193 */     tm.addNode(n4);
/*     */     
/* 195 */     TetMesh.Tet tet = tm.findTet(n0);
/* 196 */     assertTrue((tet != null));
/* 197 */     assertTrue((tet == tm.findTet(n0, n1)));
/* 198 */     assertTrue((tet == tm.findTet(n0, n2)));
/* 199 */     assertTrue((tet == tm.findTet(n0, n3)));
/* 200 */     assertTrue((tet == tm.findTet(n0, n1, n3)));
/* 201 */     assertTrue((tet == tm.findTet(n0, n1, n3)));
/* 202 */     assertTrue((tet == tm.findTet(n0, n2, n3)));
/* 203 */     assertTrue((tet == tm.findTet(n0, n1, n2, n3)));
/* 204 */     assertTrue((null == tm.findTet(n0, n4)));
/* 205 */     assertTrue((null == tm.findTet(n0, n1, n4)));
/* 206 */     assertTrue((null == tm.findTet(n0, n2, n4)));
/* 207 */     assertTrue((null == tm.findTet(n0, n3, n4)));
/* 208 */     assertTrue((null == tm.findTet(n0, n1, n2, n4)));
/* 209 */     assertTrue((null == tm.findTet(n0, n1, n3, n4)));
/* 210 */     assertTrue((null == tm.findTet(n0, n2, n3, n4)));
/*     */ 
/*     */     
/* 213 */     TetMesh.Edge edge = tm.findEdge(n0, n1);
/* 214 */     TetMesh.Edge e01 = new TetMesh.Edge(n0, n1, tet);
/* 215 */     TetMesh.Edge e10 = new TetMesh.Edge(n1, n0, tet);
/* 216 */     assertTrue((edge.equals(e01) || edge.equals(e10)));
/* 217 */     edge = tm.findEdge(n0, n2);
/* 218 */     TetMesh.Edge e02 = new TetMesh.Edge(n0, n2, tet);
/* 219 */     TetMesh.Edge e20 = new TetMesh.Edge(n2, n0, tet);
/* 220 */     assertTrue((edge.equals(e02) || edge.equals(e20)));
/* 221 */     edge = tm.findEdge(n0, n3);
/* 222 */     TetMesh.Edge e03 = new TetMesh.Edge(n0, n3, tet);
/* 223 */     TetMesh.Edge e30 = new TetMesh.Edge(n3, n0, tet);
/* 224 */     assertTrue((edge.equals(e03) || edge.equals(e30)));
/* 225 */     edge = tm.findEdge(n1, n2);
/* 226 */     TetMesh.Edge e12 = new TetMesh.Edge(n1, n2, tet);
/* 227 */     TetMesh.Edge e21 = new TetMesh.Edge(n2, n1, tet);
/* 228 */     assertTrue((edge.equals(e12) || edge.equals(e21)));
/* 229 */     edge = tm.findEdge(n1, n3);
/* 230 */     TetMesh.Edge e13 = new TetMesh.Edge(n1, n3, tet);
/* 231 */     TetMesh.Edge e31 = new TetMesh.Edge(n3, n1, tet);
/* 232 */     assertTrue((edge.equals(e13) || edge.equals(e31)));
/* 233 */     edge = tm.findEdge(n2, n3);
/* 234 */     TetMesh.Edge e23 = new TetMesh.Edge(n2, n3, tet);
/* 235 */     TetMesh.Edge e32 = new TetMesh.Edge(n3, n2, tet);
/* 236 */     assertTrue((edge.equals(e23) || edge.equals(e32)));
/*     */ 
/*     */     
/* 239 */     TetMesh.Face face = tm.findFace(n0, n1, n2);
/* 240 */     TetMesh.Face f102 = new TetMesh.Face(n1, n0, n2, tet);
/* 241 */     assertTrue(face.equals(f102));
/* 242 */     face = tm.findFace(n0, n1, n3);
/* 243 */     TetMesh.Face f301 = new TetMesh.Face(n3, n0, n1, tet);
/* 244 */     assertTrue(face.equals(f301));
/* 245 */     face = tm.findFace(n0, n2, n3);
/* 246 */     TetMesh.Face f320 = new TetMesh.Face(n3, n2, n0, tet);
/* 247 */     assertTrue(face.equals(f320));
/* 248 */     assertTrue((null == tm.findFace(n0, n1, n4)));
/* 249 */     assertTrue((null == tm.findFace(n0, n2, n4)));
/* 250 */     assertTrue((null == tm.findFace(n0, n3, n4)));
/*     */   }
/*     */   
/*     */   public void testSimple() {
/* 254 */     TetMesh tm = new TetMesh();
/* 255 */     TetMesh.Node n0 = new TetMesh.Node(1.0F, 0.0F, 0.0F);
/* 256 */     TetMesh.Node n1 = new TetMesh.Node(0.0F, 1.0F, 0.0F);
/* 257 */     TetMesh.Node n2 = new TetMesh.Node(0.0F, 0.0F, 1.0F);
/* 258 */     TetMesh.Node n3 = new TetMesh.Node(0.0F, 0.0F, 0.0F);
/* 259 */     TetMesh.Node n4 = new TetMesh.Node(0.9F, 0.9F, 0.9F);
/* 260 */     tm.addNode(n0);
/* 261 */     tm.addNode(n1);
/* 262 */     tm.addNode(n2);
/* 263 */     tm.addNode(n3);
/* 264 */     tm.addNode(n4);
/* 265 */     tm.removeNode(n4);
/* 266 */     tm.validate();
/*     */   }
/*     */   
/*     */   public void testLine() {
/* 270 */     TetMesh tm = new TetMesh();
/* 271 */     int n = 100; int i;
/* 272 */     for (i = 0; i < n; i++) {
/* 273 */       float x = i;
/* 274 */       float y = 3.14F;
/* 275 */       float z = 4.13F;
/* 276 */       TetMesh.Node node = new TetMesh.Node(x, y, z);
/* 277 */       tm.addNode(node);
/*     */     } 
/* 279 */     tm.validate();
/* 280 */     for (i = 0; i < n; i++) {
/* 281 */       float x = i;
/* 282 */       float y = 3.14F;
/* 283 */       float z = 4.13F;
/* 284 */       TetMesh.Node node = tm.findNodeNearest(x, y, z);
/* 285 */       tm.removeNode(node);
/*     */     } 
/* 287 */     tm.validate();
/*     */   }
/*     */   
/*     */   public void testCube() {
/* 291 */     TetMesh tm = new TetMesh();
/* 292 */     TetMesh.Node n0 = new TetMesh.Node(0.0F, 0.0F, 0.0F);
/* 293 */     TetMesh.Node n1 = new TetMesh.Node(1.0F, 0.0F, 0.0F);
/* 294 */     TetMesh.Node n2 = new TetMesh.Node(0.0F, 1.0F, 0.0F);
/* 295 */     TetMesh.Node n3 = new TetMesh.Node(0.0F, 0.0F, 1.0F);
/* 296 */     TetMesh.Node n4 = new TetMesh.Node(1.0F, 1.0F, 0.0F);
/* 297 */     TetMesh.Node n5 = new TetMesh.Node(1.0F, 0.0F, 1.0F);
/* 298 */     TetMesh.Node n6 = new TetMesh.Node(0.0F, 1.0F, 1.0F);
/* 299 */     TetMesh.Node n7 = new TetMesh.Node(1.0F, 1.0F, 1.0F);
/* 300 */     tm.addNode(n0);
/* 301 */     tm.addNode(n1);
/* 302 */     tm.addNode(n2);
/* 303 */     tm.addNode(n3);
/* 304 */     tm.addNode(n4);
/* 305 */     tm.addNode(n5);
/* 306 */     tm.addNode(n6);
/* 307 */     tm.addNode(n7);
/* 308 */     tm.removeNode(n7);
/* 309 */     tm.removeNode(n6);
/* 310 */     tm.removeNode(n5);
/* 311 */     tm.removeNode(n4);
/* 312 */     tm.removeNode(n3);
/* 313 */     tm.removeNode(n2);
/* 314 */     tm.removeNode(n1);
/* 315 */     tm.removeNode(n0);
/* 316 */     tm.validate();
/*     */   }
/*     */   
/*     */   public void testAddFindRemove() {
/* 320 */     Random random = new Random();
/* 321 */     TetMesh tm = new TetMesh();
/* 322 */     int nadd = 0;
/* 323 */     int nremove = 0;
/* 324 */     for (int niter = 0; niter < 1000; niter++) {
/* 325 */       float x = random.nextFloat();
/* 326 */       float y = random.nextFloat();
/* 327 */       float z = random.nextFloat();
/* 328 */       if (tm.countNodes() < 10 || random.nextFloat() > 0.5F) {
/* 329 */         TetMesh.Node node = new TetMesh.Node(x, y, z);
/* 330 */         boolean ok = tm.addNode(node);
/* 331 */         assertTrue(ok);
/* 332 */         tm.validate();
/* 333 */         nadd++;
/* 334 */       } else if (tm.countNodes() > 0) {
/* 335 */         TetMesh.Node node = tm.findNodeNearest(x, y, z);
/* 336 */         assertTrue((node != null));
/* 337 */         TetMesh.Node nodeSlow = tm.findNodeNearestSlow(x, y, z);
/* 338 */         assertTrue((node == nodeSlow));
/* 339 */         tm.removeNode(node);
/* 340 */         tm.validate();
/* 341 */         nremove++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void benchAddNode() {
/* 348 */     Random random = new Random();
/* 349 */     for (int itest = 0; itest < 16; itest++) {
/* 350 */       for (int nnode = 1000; nnode <= 64000; nnode *= 2) {
/* 351 */         Stopwatch sw = new Stopwatch();
/* 352 */         sw.reset();
/* 353 */         sw.start();
/* 354 */         TetMesh tm = new TetMesh();
/* 355 */         for (int inode = 0; inode < nnode; inode++) {
/* 356 */           float x = random.nextFloat();
/* 357 */           float y = random.nextFloat();
/* 358 */           float z = random.nextFloat();
/* 359 */           TetMesh.Node node = new TetMesh.Node(x, y, z);
/* 360 */           tm.addNode(node);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 366 */         sw.stop();
/* 367 */         System.out.println("Added " + nnode + " nodes to make " + tm.countTets() + " tets in " + sw.time() + " seconds.");
/*     */ 
/*     */         
/* 370 */         tm.validate();
/*     */       } 
/*     */       try {
/* 373 */         System.out.println("Sleeping");
/* 374 */         Thread.sleep(5000L, 0);
/* 375 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void benchFind() {
/* 381 */     int nnode = 1000;
/* 382 */     int nfind = 10000;
/* 383 */     int ntest = 3;
/* 384 */     Random random = new Random();
/* 385 */     Stopwatch sw = new Stopwatch();
/* 386 */     TetMesh tm = new TetMesh();
/* 387 */     for (int inode = 0; inode < nnode; inode++) {
/* 388 */       float x = random.nextFloat();
/* 389 */       float y = random.nextFloat();
/* 390 */       float z = random.nextFloat();
/* 391 */       TetMesh.Node node = new TetMesh.Node(x, y, z);
/* 392 */       tm.addNode(node);
/*     */     } 
/* 394 */     for (int itest = 0; itest < ntest; itest++) {
/* 395 */       float[] x = new float[nfind];
/* 396 */       float[] y = new float[nfind];
/* 397 */       float[] z = new float[nfind];
/* 398 */       for (int ifind = 0; ifind < nfind; ifind++) {
/* 399 */         x[ifind] = random.nextFloat();
/* 400 */         y[ifind] = random.nextFloat();
/* 401 */         z[ifind] = random.nextFloat();
/*     */       } 
/* 403 */       TetMesh.Node[] nfast = new TetMesh.Node[nfind];
/* 404 */       sw.reset();
/* 405 */       sw.start();
/* 406 */       for (int i = 0; i < nfind; i++)
/* 407 */         nfast[i] = tm.findNodeNearest(x[i], y[i], z[i]); 
/* 408 */       sw.stop();
/* 409 */       int sfast = (int)(nfind / sw.time());
/* 410 */       TetMesh.Node[] nslow = new TetMesh.Node[nfind];
/* 411 */       sw.reset();
/* 412 */       sw.start();
/* 413 */       for (int j = 0; j < nfind; j++)
/* 414 */         nslow[j] = tm.findNodeNearestSlow(x[j], y[j], z[j]); 
/* 415 */       sw.stop();
/* 416 */       int sslow = (int)(nfind / sw.time());
/* 417 */       for (int k = 0; k < nfind; k++) {
/* 418 */         if (nfast[k] != nslow[k]) {
/* 419 */           float xfast = nfast[k].x();
/* 420 */           float yfast = nfast[k].y();
/* 421 */           float zfast = nfast[k].z();
/* 422 */           float xslow = nslow[k].x();
/* 423 */           float yslow = nslow[k].y();
/* 424 */           float zslow = nslow[k].z();
/* 425 */           float dxfast = xfast - x[k];
/* 426 */           float dyfast = yfast - y[k];
/* 427 */           float dzfast = zfast - z[k];
/* 428 */           float dxslow = xslow - x[k];
/* 429 */           float dyslow = yslow - y[k];
/* 430 */           float dzslow = zslow - z[k];
/* 431 */           float dsfast = dxfast * dxfast + dyfast * dyfast + dzfast * dzfast;
/* 432 */           float dsslow = dxslow * dxslow + dyslow * dyslow + dzslow * dzslow;
/* 433 */           System.out.println("ifind=" + k + " fast/slow=" + dsfast + "/" + dsslow);
/*     */         } 
/* 435 */         assertTrue((nfast[k] == nslow[k]));
/*     */       } 
/* 437 */       System.out.println("Find fast/slow nodes per sec = " + sfast + "/" + sslow);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/test/TetMeshTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */