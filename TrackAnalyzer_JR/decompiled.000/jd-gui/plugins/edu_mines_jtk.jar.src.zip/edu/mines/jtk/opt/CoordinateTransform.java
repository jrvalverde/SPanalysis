/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoordinateTransform
/*     */ {
/*  50 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   
/*  52 */   private int _nout = 0;
/*  53 */   private int _nin = 0;
/*     */   private double[][] _hessian;
/*     */   private double[][] _b;
/*     */   private double[][] _a;
/*  57 */   private double[] _in0 = null;
/*  58 */   private double[] _out0 = null;
/*  59 */   private double[] _inScr = null;
/*  60 */   private double[] _outScr = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoordinateTransform(int dimensionOut, int dimensionIn) {
/*  67 */     this._nout = dimensionOut;
/*  68 */     this._nin = dimensionIn;
/*  69 */     this._hessian = new double[this._nin][this._nin];
/*  70 */     this._b = new double[this._nout][this._nin];
/*  71 */     this._inScr = new double[this._nin];
/*  72 */     this._outScr = new double[this._nout];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(double[] out, double[] in) {
/*  87 */     this._a = (double[][])null;
/*     */     
/*  89 */     if (in.length != this._nin) {
/*  90 */       throw new IllegalArgumentException("in must have dimension " + this._nin);
/*     */     }
/*     */     
/*  93 */     if (out.length != this._nout) {
/*  94 */       throw new IllegalArgumentException("out must have dimension " + this._nout);
/*     */     }
/*     */     
/*  97 */     if (this._in0 == null) this._in0 = (double[])in.clone(); 
/*  98 */     if (this._out0 == null) this._out0 = (double[])out.clone(); 
/*     */     int i;
/* 100 */     for (i = 0; i < this._nin; ) { this._inScr[i] = in[i] - this._in0[i]; i++; }
/* 101 */      for (i = 0; i < this._nout; ) { this._outScr[i] = out[i] - this._out0[i]; i++; }
/*     */     
/* 103 */     for (int k = 0; k < this._nin; k++) {
/* 104 */       for (int j = 0; j < this._nin; j++) {
/* 105 */         this._hessian[k][j] = this._hessian[k][j] + this._inScr[k] * this._inScr[j];
/*     */       }
/* 107 */       for (int o = 0; o < this._nout; o++) {
/* 108 */         this._b[o][k] = this._b[o][k] - this._outScr[o] * this._inScr[k];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] get(double[] in) {
/* 119 */     for (int i = 0; i < in.length; ) { this._inScr[i] = in[i] - this._in0[i]; i++; }
/* 120 */      in = null;
/*     */     
/* 122 */     if (this._a == null) {
/* 123 */       this._a = new double[this._nout][this._nin];
/* 124 */       for (int k = 0; k < this._nout; k++) {
/* 125 */         LinearQuadratic lq = new LinearQuadratic(k);
/* 126 */         QuadraticSolver qs = new QuadraticSolver(lq);
/* 127 */         ArrayVect1 solution = (ArrayVect1)qs.solve(this._nin + 4, null);
/* 128 */         double[] data = solution.getData();
/* 129 */         for (int m = 0; m < this._nin; m++) {
/* 130 */           this._a[k][m] = data[m];
/*     */         }
/* 132 */         solution.dispose();
/*     */       } 
/*     */     } 
/* 135 */     double[] result = new double[this._nout];
/* 136 */     for (int o = 0; o < this._nout; o++) {
/* 137 */       for (int k = 0; k < this._nin; k++) {
/* 138 */         result[o] = result[o] + this._a[o][k] * this._inScr[k];
/*     */       }
/*     */     } 
/* 141 */     for (int j = 0; j < result.length; ) { result[j] = result[j] + this._out0[j]; j++; }
/* 142 */      return result;
/*     */   }
/*     */   
/*     */   private class LinearQuadratic
/*     */     implements Quadratic {
/* 147 */     int _o = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     public LinearQuadratic(int o) {
/* 152 */       this._o = o;
/*     */     }
/*     */     public void multiplyHessian(Vect x) {
/* 155 */       ArrayVect1 m = (ArrayVect1)x;
/* 156 */       double[] data = m.getData();
/* 157 */       double[] oldData = (double[])data.clone();
/* 158 */       Arrays.fill(data, 0.0D);
/* 159 */       for (int i = 0; i < data.length; i++) {
/* 160 */         for (int j = 0; j < data.length; j++) {
/* 161 */           data[i] = data[i] + CoordinateTransform.this._hessian[i][j] * oldData[j];
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public Vect getB() {
/* 167 */       return new ArrayVect1((double[])CoordinateTransform.this._b[this._o].clone(), 1.0D);
/*     */     }
/*     */     
/*     */     public void inverseHessian(Vect x) {}
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/CoordinateTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */