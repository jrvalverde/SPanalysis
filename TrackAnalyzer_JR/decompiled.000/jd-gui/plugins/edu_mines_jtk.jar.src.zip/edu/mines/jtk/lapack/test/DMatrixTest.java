/*     */ package edu.mines.jtk.lapack.test;
/*     */ 
/*     */ import edu.mines.jtk.lapack.DMatrix;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  22 */     TestSuite suite = new TestSuite(DMatrixTest.class);
/*  23 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testConstruct() {
/*  27 */     int m = 3;
/*  28 */     int n = 4;
/*     */     
/*  30 */     DMatrix z1 = new DMatrix(m, n);
/*  31 */     DMatrix z2 = new DMatrix(m, n, 0.0D);
/*  32 */     assertEqualExact(z1, z2);
/*  33 */     assertTrue(z1.equals(z2));
/*  34 */     assertFalse(z1.isSquare());
/*  35 */     assertFalse(z1.isSymmetric());
/*     */     
/*  37 */     DMatrix r1 = DMatrix.random(m, n);
/*  38 */     DMatrix r2 = new DMatrix(r1);
/*  39 */     assertEqualExact(r1, r2);
/*  40 */     assertTrue(r1.equals(r2));
/*  41 */     assertNotSame(r1.getArray(), r2.getArray());
/*     */     
/*  43 */     DMatrix r3 = DMatrix.random(m, n);
/*  44 */     assertFalse(r1.equals(r3));
/*     */     
/*  46 */     DMatrix i1 = DMatrix.identity(m, n);
/*  47 */     DMatrix i2 = new DMatrix(new double[][] { { 1.0D, 0.0D, 0.0D, 0.0D }, { 0.0D, 1.0D, 0.0D, 0.0D }, { 0.0D, 0.0D, 1.0D, 0.0D } });
/*  48 */     assertTrue(z1.equals(z2));
/*  49 */     assertEqualExact(i1, i2);
/*     */   }
/*     */   
/*     */   public void testGetSet() {
/*  53 */     int m = 3;
/*  54 */     int n = 4;
/*  55 */     DMatrix s = new DMatrix(m, n);
/*     */     
/*  57 */     DMatrix r = DMatrix.random(m, n);
/*  58 */     assertEquals(m, r.getM());
/*  59 */     assertEquals(n, r.getN());
/*  60 */     assertEquals(m, r.getRowCount());
/*  61 */     assertEquals(n, r.getColumnCount());
/*     */     int i2;
/*  63 */     for (i2 = 0; i2 < m; i2++) {
/*  64 */       for (int i5 = 0; i5 < n; i5++) {
/*  65 */         s.set(i2, i5, r.get(i2, i5));
/*     */       }
/*     */     } 
/*  68 */     assertEqualExact(r, s);
/*     */     
/*  70 */     for (i2 = 0; i2 < m; i2++)
/*  71 */       s.set(i2, null, r.get(i2, null)); 
/*  72 */     assertEqualExact(r, s);
/*     */     
/*  74 */     for (int i1 = 0; i1 < n; i1++)
/*  75 */       s.set(null, i1, r.get(null, i1)); 
/*  76 */     assertEqualExact(r, s);
/*     */     
/*  78 */     for (int k = 0; k < m - 1; k++)
/*  79 */       s.set(k, k + 1, null, r.get(k, k + 1, null)); 
/*  80 */     assertEqualExact(r, s);
/*     */     
/*  82 */     for (int j = 0; j < n - 1; j++)
/*  83 */       s.set(null, j, j + 1, r.get(null, j, j + 1)); 
/*  84 */     assertEqualExact(r, s);
/*     */     
/*  86 */     for (int i = 0; i < m - 1; i++) {
/*  87 */       for (int i5 = 0; i5 < n - 1; i5++)
/*  88 */         s.set(i, i + 1, i5, i5 + 1, r.get(i, i + 1, i5, i5 + 1)); 
/*  89 */     }  assertEqualExact(r, s);
/*     */     
/*  91 */     int[] jc = { n - 1, 1 };
/*  92 */     for (int i3 = 0; i3 < m; i3++)
/*  93 */       s.set(i3, jc, r.get(i3, jc)); 
/*  94 */     assertEqualExact(r, s);
/*     */     
/*  96 */     int[] ir = { m - 1, 1 };
/*  97 */     for (int i4 = 0; i4 < n; i4++)
/*  98 */       s.set(ir, i4, r.get(ir, i4)); 
/*  99 */     assertEqualExact(r, s);
/*     */     
/* 101 */     s.set(ir, jc, r.get(ir, jc));
/* 102 */     assertEqualExact(r, s);
/*     */     
/* 104 */     s.setPackedColumns(r.getPackedColumns());
/* 105 */     assertEqualExact(r, s);
/*     */     
/* 107 */     s.setPackedRows(r.getPackedRows());
/* 108 */     assertEqualExact(r, s);
/*     */   }
/*     */   
/*     */   public void testOther() {
/* 112 */     int m = 3;
/* 113 */     int n = 4;
/*     */     
/* 115 */     DMatrix r = DMatrix.random(m, n);
/* 116 */     DMatrix s = DMatrix.random(m, n);
/* 117 */     assertFalse(s.equals(r));
/*     */     
/* 119 */     assertEqualFuzzy(r, r.plus(s).minus(s));
/* 120 */     assertEqualFuzzy(r, r.times(2.0D).times(0.5D));
/*     */     
/* 122 */     DMatrix r0 = new DMatrix(r);
/* 123 */     assertEqualFuzzy(r0, r.negate().negate());
/* 124 */     assertEqualFuzzy(r0, r.transpose().transpose());
/* 125 */     assertEqualFuzzy(r0, r.plusEquals(s).minusEquals(s));
/* 126 */     assertEqualFuzzy(r0, r.timesEquals(2.0D).timesEquals(0.5D));
/* 127 */     assertEqualFuzzy(r0, r.arrayTimes(s).arrayRightDivide(s));
/* 128 */     assertEqualFuzzy(r0, r.arrayTimesEquals(s).arrayRightDivideEquals(s));
/* 129 */     assertEqualExact(r.arrayRightDivide(s), s.arrayLeftDivide(r));
/* 130 */     assertEqualFuzzy(r0, r.arrayLeftDivideEquals(s).arrayLeftDivideEquals(s));
/*     */     
/* 132 */     DMatrix t = DMatrix.random(n, n);
/* 133 */     assertTrue(t.isSquare());
/*     */ 
/*     */     
/* 136 */     assertTrue(t.plus(t.transpose()).isSymmetric());
/*     */ 
/*     */ 
/*     */     
/* 140 */     assertEqualFuzzy(t.transposeTimes(t), t.transposeTimes(t).transpose());
/* 141 */     assertEqualFuzzy(t.timesTranspose(t), t.timesTranspose(t).transpose());
/*     */     
/* 143 */     n = t.getN();
/* 144 */     double[] a = t.getArray();
/* 145 */     double trace = 0.0D;
/* 146 */     for (int i = 0; i < n; i++)
/* 147 */       trace += a[i + i * n]; 
/* 148 */     assertTrue((trace == t.trace()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void assertEqualExact(double a, double b) {
/* 156 */     assertEquals(a, b, 0.0D);
/*     */   }
/*     */   
/*     */   static void assertEqualFuzzy(double a, double b) {
/* 160 */     double eps = Math.ulp(1.0D);
/* 161 */     double tol = 100.0D * eps * (Math.abs(a) + Math.abs(b));
/* 162 */     assertEquals(a, b, tol);
/*     */   }
/*     */   
/*     */   static void assertEqualExact(DMatrix a, DMatrix b) {
/* 166 */     assertEquals(a, b);
/*     */   }
/*     */   
/*     */   static void assertEqualFuzzy(DMatrix a, DMatrix b) {
/* 170 */     assertEquals(a.getM(), b.getM());
/* 171 */     assertEquals(a.getN(), b.getN());
/* 172 */     int m = a.getM();
/* 173 */     int n = a.getN();
/* 174 */     double eps = 1.0E-6D * Math.max(a.normF(), b.normF());
/* 175 */     for (int i = 0; i < m; i++) {
/* 176 */       for (int j = 0; j < n; j++)
/* 177 */         assertEquals(a.get(i, j), b.get(i, j), eps); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/DMatrixTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */