/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.ogl.GlCanvas;
/*     */ import edu.mines.jtk.util.Direct;
/*     */ import java.nio.FloatBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewCanvas
/*     */   extends GlCanvas
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private View _view;
/*     */   
/*     */   public ViewCanvas() {}
/*     */   
/*     */   public ViewCanvas(View view) {
/*  39 */     setView(view);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setView(View view) {
/*  47 */     if (this._view != null)
/*  48 */       this._view.removeCanvas(this); 
/*  49 */     this._view = view;
/*  50 */     if (this._view != null) {
/*  51 */       this._view.addCanvas(this);
/*  52 */       this._view.updateTransforms();
/*  53 */       this._view.repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public View getView() {
/*  62 */     return this._view;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewToCube(Matrix44 viewToCube) {
/*  71 */     this._viewToCube = new Matrix44(viewToCube);
/*  72 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getViewToCube() {
/*  80 */     return new Matrix44(this._viewToCube);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCubeToPixel(Matrix44 cubeToPixel) {
/*  89 */     this._cubeToPixel = new Matrix44(cubeToPixel);
/*  90 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getCubeToPixel() {
/*  98 */     return new Matrix44(this._cubeToPixel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPixelZ(final int xp, final int yp) {
/* 114 */     final int hp = getHeight();
/* 115 */     final FloatBuffer pixels = Direct.newFloatBuffer(1);
/* 116 */     runWithContext(new Runnable() {
/*     */           public void run() {
/* 118 */             Gl.glPushAttrib(32);
/* 119 */             Gl.glReadBuffer(1028);
/* 120 */             Gl.glReadPixels(xp, hp - 1 - yp, 1, 1, 6402, 5126, pixels);
/* 121 */             Gl.glPopAttrib();
/*     */           }
/*     */         });
/* 124 */     return pixels.get(0);
/*     */   }
/*     */   
/*     */   public void glPaint() {
/* 128 */     if (this._view != null) {
/* 129 */       this._view.draw(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void glResize(int width, int height, int widthBefore, int heightBefore) {
/* 135 */     if (this._view != null) {
/* 136 */       this._view.updateTransforms(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   private Matrix44 _viewToCube = Matrix44.identity();
/* 144 */   private Matrix44 _cubeToPixel = Matrix44.identity();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/ViewCanvas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */