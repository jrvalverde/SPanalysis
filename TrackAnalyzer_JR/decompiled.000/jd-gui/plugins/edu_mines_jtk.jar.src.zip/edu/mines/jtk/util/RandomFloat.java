/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomFloat
/*     */ {
/*     */   private static final float CS = 0.021602869F;
/*     */   private static final float CD = 0.45623308F;
/*     */   private static final float CM = 0.9999998F;
/*     */   private static final int NBITS = 24;
/*     */   
/*     */   public RandomFloat() {}
/*     */   
/*     */   public RandomFloat(int seed) {
/*  46 */     setSeed(seed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float uniform() {
/*  57 */     float uni = this._u[this._i] - this._u[this._j];
/*  58 */     if (uni < 0.0D) uni = (float)(uni + 1.0D); 
/*  59 */     this._u[this._i] = uni;
/*  60 */     if (--this._i < 0) this._i = 16; 
/*  61 */     if (--this._j < 0) this._j = 16;
/*     */ 
/*     */     
/*  64 */     this._c -= 0.45623308F;
/*  65 */     if (this._c < 0.0D) this._c += 0.9999998F;
/*     */ 
/*     */     
/*  68 */     uni -= this._c;
/*  69 */     if (uni < 0.0D) uni++; 
/*  70 */     return uni;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float normal() {
/*  81 */     float uni = this._u[this._i] - this._u[this._j];
/*  82 */     if (uni < 0.0D) uni = (float)(uni + 1.0D); 
/*  83 */     this._u[this._i] = uni;
/*  84 */     if (--this._i < 0) this._i = 16; 
/*  85 */     if (--this._j < 0) this._j = 16;
/*     */ 
/*     */     
/*  88 */     float vni = uni + uni - 1.0F;
/*     */ 
/*     */     
/*  91 */     int k = (int)(this._u[this._i] * 128.0F) % 64;
/*     */ 
/*     */     
/*  94 */     float rnor = vni * _v[k + 1];
/*  95 */     if (rnor <= _v[k] && -rnor <= _v[k]) return rnor;
/*     */ 
/*     */     
/*  98 */     float x = (Math.abs(rnor) - _v[k]) / (_v[k + 1] - _v[k]);
/*  99 */     float y = fib();
/* 100 */     float s = x + y;
/* 101 */     if (s <= 1.301198F) {
/* 102 */       if (s <= 0.9689279F) return rnor; 
/* 103 */       float f = 0.4878992F - 0.4878992F * x;
/* 104 */       if (y <= 12.6770601272583D - 12.375860214233398D * Math.exp((-0.5F * f * f))) {
/* 105 */         if (Math.exp((-0.5F * _v[k + 1] * _v[k + 1])) + (y * 0.01958303F / _v[k + 1]) <= Math.exp((-0.5F * rnor * rnor)))
/* 106 */           return rnor; 
/*     */         while (true) {
/* 108 */           y = fib();
/* 109 */           x = 0.3601016F * (float)Math.log(y);
/* 110 */           y = fib();
/* 111 */           if (-2.0D * Math.log(y) > (x * x))
/* 112 */           { float xnmx = 2.776994F - x;
/* 113 */             return (rnor >= 0.0F) ? Math.abs(xnmx) : -Math.abs(xnmx); } 
/*     */         } 
/*     */       } 
/* 116 */     }  float bmbx = 0.4878992F - 0.4878992F * x;
/* 117 */     return (rnor >= 0.0D) ? Math.abs(bmbx) : -Math.abs(bmbx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSeed(int seed) {
/* 128 */     if (seed < 0) seed = -seed; 
/* 129 */     int i1 = seed % 177 + 1;
/* 130 */     int j1 = seed % 167 + 1;
/* 131 */     int k1 = seed % 157 + 1;
/* 132 */     int l1 = seed % 147 + 1;
/*     */ 
/*     */     
/* 135 */     for (int ii = 0; ii < 17; ii++) {
/* 136 */       float s = 0.0F;
/* 137 */       float t = 0.5F;
/*     */ 
/*     */       
/* 140 */       for (int jj = 0; jj < 24; jj++) {
/* 141 */         int m1 = i1 * j1 % 179 * k1 % 179;
/* 142 */         i1 = j1;
/* 143 */         j1 = k1;
/* 144 */         k1 = m1;
/* 145 */         l1 = (53 * l1 + 1) % 169;
/* 146 */         if (l1 * m1 % 64 >= 32) s += t; 
/* 147 */         t = (float)(t * 0.5D);
/*     */       } 
/* 149 */       this._u[ii] = s;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     this._i = 16;
/* 154 */     this._j = 4;
/* 155 */     this._c = 0.021602869F;
/*     */   }
/*     */   
/*     */   private final float fib() {
/* 159 */     float r = this._u[this._i] - this._u[this._j];
/* 160 */     if (r < 0.0F) r++; 
/* 161 */     this._u[this._i] = r;
/* 162 */     if (--this._i < 0) this._i = 16; 
/* 163 */     if (--this._j < 0) this._j = 16; 
/* 164 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   private int _i = 16;
/* 173 */   private int _j = 4;
/* 174 */   private float _c = 0.021602869F;
/* 175 */   private float[] _u = new float[] { 0.8668673F, 0.36979863F, 0.8008968F, 0.41738898F, 0.82545614F, 0.96409655F, 0.45086673F, 0.64513093F, 0.1645456F, 0.27879018F, 0.067615315F, 0.96632266F, 0.01963344F, 0.029473983F, 0.16362315F, 0.39763433F, 0.26310086F };
/*     */ 
/*     */   
/*     */   private static final float AA = 12.37586F;
/*     */   
/*     */   private static final float B = 0.4878992F;
/*     */   
/*     */   private static final float C = 12.67706F;
/*     */   
/*     */   private static final float C1 = 0.9689279F;
/*     */   
/*     */   private static final float C2 = 1.301198F;
/*     */   
/*     */   private static final float PC = 0.01958303F;
/*     */   
/*     */   private static final float XN = 2.776994F;
/*     */   
/*     */   private static final float OXN = 0.3601016F;
/*     */   
/* 194 */   private static float[] _v = new float[] { 0.340945F, 0.4573146F, 0.5397793F, 0.6062427F, 0.6631691F, 0.7136975F, 0.7596125F, 0.8020356F, 0.8417227F, 0.8792102F, 0.9148948F, 0.9490791F, 0.9820005F, 1.0138493F, 1.044781F, 1.0749254F, 1.1043917F, 1.1332738F, 1.161653F, 1.189601F, 1.2171814F, 1.2444516F, 1.2714635F, 1.298265F, 1.3249007F, 1.3514125F, 1.3778399F, 1.404221F, 1.4305929F, 1.4569916F, 1.4834526F, 1.5100121F, 1.5367061F, 1.5635712F, 1.5906454F, 1.617968F, 1.6455802F, 1.6735255F, 1.7018503F, 1.7306045F, 1.7598422F, 1.7896223F, 1.82001F, 1.851077F, 1.8829044F, 1.915583F, 1.9492166F, 1.9839239F, 2.019843F, 2.0571356F, 2.095993F, 2.136645F, 2.1793714F, 2.2245176F, 2.2725184F, 2.3239338F, 2.3795006F, 2.4402218F, 2.5075116F, 2.5834658F, 2.6713915F, 2.7769942F, 2.7769942F, 2.7769942F, 2.7769942F };
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/RandomFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */