/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.FftComplex;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FftComplexTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(FftComplexTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1() {
/*  29 */     int nmax = 1000;
/*  30 */     for (int n = 2; n < nmax; n++) {
/*  31 */       int nfft = FftComplex.nfftSmall(n);
/*  32 */       FftComplex fft = new FftComplex(nfft);
/*  33 */       float[] c1 = Array.czerofloat(nfft);
/*  34 */       c1[2] = 1.0F;
/*  35 */       float[] cx = Array.ccopy(c1);
/*  36 */       fft.complexToComplex(1, cx, cx);
/*  37 */       float ra = 0.0F;
/*  38 */       float rb = 6.2831855F / nfft;
/*  39 */       float[] amp = Array.fillfloat(1.0F, nfft);
/*  40 */       float[] phs = Array.rampfloat(ra, rb, nfft);
/*  41 */       float[] cc = Array.polar(amp, phs);
/*  42 */       assertEqual(cc, cx);
/*  43 */       fft.complexToComplex(-1, cx, cx);
/*  44 */       fft.scale(nfft, cx);
/*  45 */       assertEqual(c1, cx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test2() {
/*  50 */     int n1max = 26;
/*  51 */     int n2max = 26;
/*  52 */     for (int n2 = 2; n2 < n2max; n2++) {
/*  53 */       int n2fft = FftComplex.nfftSmall(n2);
/*  54 */       FftComplex fft2 = new FftComplex(n2fft);
/*  55 */       for (int n1 = 2; n1 < n1max; n1++) {
/*  56 */         int n1fft = FftComplex.nfftSmall(n1);
/*  57 */         FftComplex fft1 = new FftComplex(n1fft);
/*  58 */         float[][] c1 = Array.czerofloat(n1fft, n2fft);
/*  59 */         c1[1][2] = 1.0F;
/*  60 */         float[][] cx = Array.ccopy(c1);
/*  61 */         fft1.complexToComplex1(1, n2fft, cx, cx);
/*  62 */         fft2.complexToComplex2(1, n1fft, cx, cx);
/*  63 */         float ra = 0.0F;
/*  64 */         float rb1 = 6.2831855F / n1fft;
/*  65 */         float rb2 = 6.2831855F / n2fft;
/*  66 */         float[][] amp = Array.fillfloat(1.0F, n1fft, n2fft);
/*  67 */         float[][] phs = Array.rampfloat(ra, rb1, rb2, n1fft, n2fft);
/*  68 */         float[][] cc = Array.polar(amp, phs);
/*  69 */         assertEqual(cc, cx);
/*  70 */         fft1.complexToComplex1(-1, n2fft, cx, cx);
/*  71 */         fft2.complexToComplex2(-1, n1fft, cx, cx);
/*  72 */         fft1.scale(n1fft, n2fft, cx);
/*  73 */         fft2.scale(n1fft, n2fft, cx);
/*  74 */         assertEqual(c1, cx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test1Random() {
/*  80 */     int nmax = 1000;
/*  81 */     for (int n = 2; n < nmax; n++) {
/*  82 */       int nfft = FftComplex.nfftSmall(n);
/*  83 */       FftComplex fft = new FftComplex(nfft);
/*  84 */       float[] cr = Array.crandfloat(nfft);
/*  85 */       float[] cx = Array.ccopy(cr);
/*  86 */       float[] cy = Array.czerofloat(nfft);
/*  87 */       fft.complexToComplex(1, cx, cy);
/*  88 */       fft.complexToComplex(-1, cy, cx);
/*  89 */       fft.scale(nfft, cx);
/*  90 */       assertEqual(cr, cx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test2Random() {
/*  95 */     int n1max = 26;
/*  96 */     int n2max = 26;
/*  97 */     for (int n2 = 2; n2 < n2max; n2++) {
/*  98 */       int n2fft = FftComplex.nfftSmall(n2);
/*  99 */       FftComplex fft2 = new FftComplex(n2fft);
/* 100 */       for (int n1 = 2; n1 < n1max; n1++) {
/* 101 */         int n1fft = FftComplex.nfftSmall(n1);
/* 102 */         FftComplex fft1 = new FftComplex(n1fft);
/* 103 */         float[][] cr = Array.crandfloat(n1fft, n2fft);
/* 104 */         float[][] cx = Array.ccopy(cr);
/* 105 */         float[][] cy = Array.czerofloat(n1fft, n2fft);
/* 106 */         fft1.complexToComplex1(1, n2fft, cx, cy);
/* 107 */         fft2.complexToComplex2(1, n1fft, cy, cy);
/* 108 */         fft1.complexToComplex1(-1, n2fft, cy, cx);
/* 109 */         fft2.complexToComplex2(-1, n1fft, cx, cx);
/* 110 */         fft1.scale(n1fft, n2fft, cx);
/* 111 */         fft2.scale(n1fft, n2fft, cx);
/* 112 */         assertEqual(cr, cx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test3Random() {
/* 118 */     int n1 = 11;
/* 119 */     int n2 = 12;
/* 120 */     int n3 = 13;
/* 121 */     int n1fft = FftComplex.nfftSmall(n1);
/* 122 */     int n2fft = FftComplex.nfftSmall(n2);
/* 123 */     int n3fft = FftComplex.nfftSmall(n3);
/* 124 */     FftComplex fft1 = new FftComplex(n1fft);
/* 125 */     FftComplex fft2 = new FftComplex(n2fft);
/* 126 */     FftComplex fft3 = new FftComplex(n3fft);
/* 127 */     float[][][] cr = Array.crandfloat(n1fft, n2fft, n3fft);
/* 128 */     float[][][] cx = Array.ccopy(cr);
/* 129 */     fft1.complexToComplex1(1, n2fft, n3fft, cx, cx);
/* 130 */     fft2.complexToComplex2(1, n1fft, n3fft, cx, cx);
/* 131 */     fft3.complexToComplex3(1, n1fft, n2fft, cx, cx);
/* 132 */     fft1.complexToComplex1(-1, n2fft, n3fft, cx, cx);
/* 133 */     fft2.complexToComplex2(-1, n1fft, n3fft, cx, cx);
/* 134 */     fft3.complexToComplex3(-1, n1fft, n2fft, cx, cx);
/* 135 */     fft1.scale(n1fft, n2fft, n3fft, cx);
/* 136 */     fft2.scale(n1fft, n2fft, n3fft, cx);
/* 137 */     fft3.scale(n1fft, n2fft, n3fft, cx);
/* 138 */     assertEqual(cr, cx);
/*     */   }
/*     */   
/*     */   private void assertEqual(float[] ca, float[] cb) {
/* 142 */     int n1 = ca.length / 2;
/* 143 */     float tolerance = n1 * 1.1920929E-7F;
/* 144 */     assertTrue(Array.cequal(tolerance, ca, cb));
/*     */   }
/*     */   
/*     */   private void assertEqual(float[][] ca, float[][] cb) {
/* 148 */     int n1 = (ca[0]).length / 2;
/* 149 */     int n2 = ca.length;
/* 150 */     float tolerance = (n1 + n2) * 1.1920929E-7F;
/* 151 */     assertTrue(Array.cequal(tolerance, ca, cb));
/*     */   }
/*     */   
/*     */   private void assertEqual(float[][][] ca, float[][][] cb) {
/* 155 */     int n1 = (ca[0][0]).length / 2;
/* 156 */     int n2 = (ca[0]).length;
/* 157 */     int n3 = ca.length;
/* 158 */     float tolerance = (n1 + n2 + n3) * 1.1920929E-7F;
/* 159 */     assertTrue(Array.cequal(tolerance, ca, cb));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/FftComplexTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */