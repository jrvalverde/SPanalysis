/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Histogram;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HistogramTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(HistogramTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testConstant() {
/*  29 */     int n = 1001;
/*  30 */     float vfill = 2.0F;
/*  31 */     float[] v = Array.fillfloat(vfill, n);
/*     */ 
/*     */     
/*  34 */     float vmin = vfill;
/*  35 */     float vmax = vfill;
/*  36 */     int nbin = 1;
/*  37 */     double dbin = 1.0D;
/*  38 */     double fbin = vmin + 0.5D * dbin;
/*  39 */     Histogram h = new Histogram(v);
/*  40 */     assertEquals(Float.valueOf(vmin), Float.valueOf(h.getMinValue()));
/*  41 */     assertEquals(Float.valueOf(vmax), Float.valueOf(h.getMaxValue()));
/*  42 */     assertEquals(nbin, h.getBinCount());
/*  43 */     assertEquals(Double.valueOf(dbin), Double.valueOf(h.getBinDelta()));
/*  44 */     assertEquals(Double.valueOf(fbin), Double.valueOf(h.getBinFirst()));
/*  45 */     assertEquals(0L, h.getLowCount());
/*  46 */     assertEquals(n, h.getInCount());
/*  47 */     assertEquals(0L, h.getHighCount());
/*     */ 
/*     */     
/*  50 */     vmin = vfill;
/*  51 */     vmax = vfill;
/*  52 */     nbin = 3;
/*  53 */     dbin = 1.0D;
/*  54 */     fbin = vmin + 0.5D * dbin;
/*  55 */     h = new Histogram(v, nbin);
/*  56 */     assertEquals(Float.valueOf(vmin), Float.valueOf(h.getMinValue()));
/*  57 */     assertEquals(Float.valueOf(vmax), Float.valueOf(h.getMaxValue()));
/*  58 */     assertEquals(nbin, h.getBinCount());
/*  59 */     assertEquals(Double.valueOf(dbin), Double.valueOf(h.getBinDelta()));
/*  60 */     assertEquals(Double.valueOf(fbin), Double.valueOf(h.getBinFirst()));
/*  61 */     assertEquals(0L, h.getLowCount());
/*  62 */     assertEquals(n, h.getInCount());
/*  63 */     assertEquals(0L, h.getHighCount());
/*     */ 
/*     */     
/*  66 */     vmin = vfill - 2.0F;
/*  67 */     vmax = vfill - 1.0F;
/*  68 */     nbin = 1;
/*  69 */     dbin = (vmax - vmin);
/*  70 */     fbin = 0.5D * (vmin + vmax);
/*  71 */     h = new Histogram(v, vmin, vmax);
/*  72 */     assertEquals(Float.valueOf(vmin), Float.valueOf(h.getMinValue()));
/*  73 */     assertEquals(Float.valueOf(vmax), Float.valueOf(h.getMaxValue()));
/*  74 */     assertEquals(nbin, h.getBinCount());
/*  75 */     assertEquals(Double.valueOf(dbin), Double.valueOf(h.getBinDelta()));
/*  76 */     assertEquals(Double.valueOf(fbin), Double.valueOf(h.getBinFirst()));
/*  77 */     assertEquals(0L, h.getLowCount());
/*  78 */     assertEquals(0L, h.getInCount());
/*  79 */     assertEquals(n, h.getHighCount());
/*     */ 
/*     */     
/*  82 */     vmin = vfill + 1.0F;
/*  83 */     vmax = vfill + 2.0F;
/*  84 */     nbin = 1;
/*  85 */     dbin = (vmax - vmin);
/*  86 */     fbin = 0.5D * (vmin + vmax);
/*  87 */     h = new Histogram(v, vmin, vmax);
/*  88 */     assertEquals(Float.valueOf(vmin), Float.valueOf(h.getMinValue()));
/*  89 */     assertEquals(Float.valueOf(vmax), Float.valueOf(h.getMaxValue()));
/*  90 */     assertEquals(nbin, h.getBinCount());
/*  91 */     assertEquals(Double.valueOf(dbin), Double.valueOf(h.getBinDelta()));
/*  92 */     assertEquals(Double.valueOf(fbin), Double.valueOf(h.getBinFirst()));
/*  93 */     assertEquals(n, h.getLowCount());
/*  94 */     assertEquals(0L, h.getInCount());
/*  95 */     assertEquals(0L, h.getHighCount());
/*     */   }
/*     */   
/*     */   public void testRamp() {
/*  99 */     int n = 1001;
/* 100 */     float[] v = Array.rampfloat(0.0F, 1.0F, n);
/* 101 */     float vmin = Array.min(v);
/* 102 */     float vmax = Array.max(v);
/* 103 */     int nbin = 10;
/* 104 */     double dbin = ((vmax - vmin) / nbin);
/* 105 */     double fbin = vmin + 0.5D * dbin;
/* 106 */     Histogram h = new Histogram(v, nbin);
/* 107 */     assertEquals(nbin, h.getBinCount());
/* 108 */     assertEquals(Double.valueOf(dbin), Double.valueOf(h.getBinDelta()));
/* 109 */     assertEquals(Double.valueOf(fbin), Double.valueOf(h.getBinFirst()));
/* 110 */     assertEquals(n, h.getInCount());
/* 111 */     assertEquals(0L, h.getLowCount());
/* 112 */     assertEquals(0L, h.getHighCount());
/*     */   }
/*     */   
/*     */   public void testGaussian() {
/* 116 */     Random r = new Random();
/* 117 */     int n = 1000;
/* 118 */     float[] v = new float[n];
/* 119 */     for (int i = 0; i < n; i++)
/* 120 */       v[i] = (float)r.nextGaussian(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/HistogramTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */