/*     */ package edu.mines.jtk.util.test;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Cfloat;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.util.Arrays;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ public class ArrayTest extends TestCase {
/*     */   private static final int SAWTOOTH = 0;
/*     */   private static final int RAND = 1;
/*     */   private static final int STAGGER = 2;
/*     */   private static final int PLATEAU = 3;
/*     */   private static final int SHUFFLE = 4;
/*     */   private static final int COPY = 0;
/*     */   private static final int REV = 1;
/*     */   private static final int REVHALF1 = 2;
/*     */   private static final int REVHALF2 = 3;
/*     */   private static final int SORT = 4;
/*     */   private static final int DITHER = 5;
/*     */   
/*     */   public static void main(String[] args) {
/*  26 */     TestSuite suite = new TestSuite(ArrayTest.class);
/*  27 */     TestRunner.run((Test)suite);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testSort() {
/*  35 */     Random r = new Random(314159L);
/*  36 */     int[] ntest = { 100, 1023, 1024, 1025 };
/*  37 */     for (int itest = 0; itest < ntest.length; itest++) {
/*  38 */       int n = ntest[itest];
/*  39 */       float[] x = new float[n]; int m;
/*  40 */       for (m = 1; m < 2 * n; m *= 2) {
/*  41 */         for (int dist = 0; dist < 5; dist++) {
/*  42 */           for (int i = 0, j = 0, k = 1; i < n; i++) {
/*  43 */             int ix = 0;
/*  44 */             switch (dist) { case 0:
/*  45 */                 ix = i % m; break;
/*  46 */               case 1: ix = r.nextInt() % m; break;
/*  47 */               case 2: ix = (i * m + i) % n; break;
/*  48 */               case 3: ix = MathPlus.min(i, m); break;
/*  49 */               case 4: j += 2; k += 2; ix = (r.nextInt() % m != 0) ? j : k; break; }
/*     */             
/*  51 */             x[i] = ix;
/*     */           } 
/*  53 */           for (int order = 0; order < 6; order++) {
/*  54 */             int i1; float[] y = null;
/*  55 */             float[] z = null;
/*  56 */             switch (order) {
/*     */               case 0:
/*  58 */                 y = Array.copy(x);
/*     */                 break;
/*     */               case 1:
/*  61 */                 y = Array.reverse(x);
/*     */                 break;
/*     */               case 2:
/*  64 */                 y = Array.copy(x);
/*  65 */                 z = Array.reverse(Array.copy(n / 2, x));
/*  66 */                 Array.copy(n / 2, 0, z, 0, y);
/*     */                 break;
/*     */               case 3:
/*  69 */                 y = Array.copy(x);
/*  70 */                 z = Array.reverse(Array.copy(n / 2, n / 2, x));
/*  71 */                 Array.copy(n / 2, 0, z, n / 2, y);
/*     */                 break;
/*     */               case 4:
/*  74 */                 y = Array.copy(x);
/*  75 */                 Arrays.sort(y);
/*     */                 break;
/*     */               case 5:
/*  78 */                 y = Array.copy(x);
/*  79 */                 for (i1 = 0; i1 < n; i1++)
/*  80 */                   y[i1] = y[i1] + (i1 % 5); 
/*     */                 break;
/*     */             } 
/*  83 */             sortAndCheck(y);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void sortAndCheck(float[] x) {
/*  90 */     int n = x.length;
/*  91 */     float[] x1 = Array.copy(x); int k;
/*  92 */     for (k = 0; k < n; k += n / 4) {
/*  93 */       Array.quickPartialSort(k, x1); int i3;
/*  94 */       for (i3 = 0; i3 < k; i3++)
/*  95 */         assertTrue((x1[i3] <= x1[k])); 
/*  96 */       for (i3 = k; i3 < n; i3++)
/*  97 */         assertTrue((x1[k] <= x1[i3])); 
/*     */     } 
/*  99 */     float[] x2 = Array.copy(x);
/* 100 */     Array.quickSort(x2);
/* 101 */     for (int i = 1; i < n; i++)
/* 102 */       assertTrue((x2[i - 1] <= x2[i])); 
/* 103 */     int[] i1 = Array.rampint(0, 1, n); int m;
/* 104 */     for (m = 0; m < n; m += n / 4) {
/* 105 */       Array.quickPartialIndexSort(m, x, i1); int i3;
/* 106 */       for (i3 = 0; i3 < m; i3++)
/* 107 */         assertTrue((x[i1[i3]] <= x[i1[m]])); 
/* 108 */       for (i3 = m + 1; i3 < n; i3++)
/* 109 */         assertTrue((x[i1[m]] <= x[i1[i3]])); 
/*     */     } 
/* 111 */     int[] i2 = Array.rampint(0, 1, n);
/* 112 */     Array.quickIndexSort(x, i2);
/* 113 */     for (int j = 1; j < n; j++)
/* 114 */       assertTrue((x[i2[j - 1]] <= x[i2[j]])); 
/*     */   }
/*     */   
/*     */   public void testFloat1() {
/* 118 */     int n1 = 8;
/* 119 */     int n2 = 6;
/* 120 */     int n3 = 4;
/* 121 */     float[] a1 = Array.rampfloat(0.0F, 1.0F, n1);
/* 122 */     float[][] a2 = Array.rampfloat(0.0F, 1.0F, 10.0F, n1, n2);
/* 123 */     float[][][] a3 = Array.rampfloat(0.0F, 1.0F, 10.0F, 100.0F, n1, n2, n3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     float[] b1 = Array.copy(a1);
/* 129 */     float[][] b2 = Array.copy(a2);
/* 130 */     float[][][] b3 = Array.copy(a3);
/* 131 */     assertEqual(b1, a1);
/* 132 */     assertEqual(b2, a2);
/* 133 */     assertEqual(b3, a3);
/*     */     
/* 135 */     Array.copy(a1, b1);
/* 136 */     Array.copy(a2, b2);
/* 137 */     Array.copy(a3, b3);
/* 138 */     assertEqual(b1, a1);
/* 139 */     assertEqual(b2, a2);
/* 140 */     assertEqual(b3, a3);
/*     */     
/* 142 */     b1 = Array.copy(n1 - 1, a1);
/* 143 */     b2 = Array.copy(n1 - 1, n2 - 1, a2);
/* 144 */     b3 = Array.copy(n1 - 1, n2 - 1, n3 - 1, a3);
/* 145 */     assertEqual(b1, Array.rampfloat(0.0F, 1.0F, n1 - 1));
/* 146 */     assertEqual(b2, Array.rampfloat(0.0F, 1.0F, 10.0F, n1 - 1, n2 - 1));
/* 147 */     assertEqual(b3, Array.rampfloat(0.0F, 1.0F, 10.0F, 100.0F, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 149 */     Array.copy(n1 - 1, a1, b1);
/* 150 */     Array.copy(n1 - 1, n2 - 1, a2, b2);
/* 151 */     Array.copy(n1 - 1, n2 - 1, n3 - 1, a3, b3);
/* 152 */     assertEqual(b1, Array.rampfloat(0.0F, 1.0F, n1 - 1));
/* 153 */     assertEqual(b2, Array.rampfloat(0.0F, 1.0F, 10.0F, n1 - 1, n2 - 1));
/* 154 */     assertEqual(b3, Array.rampfloat(0.0F, 1.0F, 10.0F, 100.0F, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 156 */     b1 = Array.copy(n1 - 1, 1, a1);
/* 157 */     b2 = Array.copy(n1 - 2, n2 - 1, 2, 1, a2);
/* 158 */     b3 = Array.copy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3);
/* 159 */     assertEqual(b1, Array.rampfloat(1.0F, 1.0F, n1 - 1));
/* 160 */     assertEqual(b2, Array.rampfloat(12.0F, 1.0F, 10.0F, n1 - 1, n2 - 1));
/* 161 */     assertEqual(b3, Array.rampfloat(123.0F, 1.0F, 10.0F, 100.0F, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 163 */     Array.copy(n1 - 1, 1, a1, 0, b1);
/* 164 */     Array.copy(n1 - 2, n2 - 1, 2, 1, a2, 0, 0, b2);
/* 165 */     Array.copy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3, 0, 0, 0, b3);
/* 166 */     assertEqual(b1, Array.rampfloat(1.0F, 1.0F, n1 - 1));
/* 167 */     assertEqual(b2, Array.rampfloat(12.0F, 1.0F, 10.0F, n1 - 1, n2 - 1));
/* 168 */     assertEqual(b3, Array.rampfloat(123.0F, 1.0F, 10.0F, 100.0F, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 170 */     b1 = Array.copy(n1 / 2, 0, 2, a1);
/* 171 */     b2 = Array.copy(n1 / 2, n2 / 2, 0, 0, 2, 2, a2);
/* 172 */     b3 = Array.copy(n1 / 2, n2 / 2, n3 / 2, 0, 0, 0, 2, 2, 2, a3);
/* 173 */     assertEqual(b1, Array.rampfloat(0.0F, 2.0F, n1 / 2));
/* 174 */     assertEqual(b2, Array.rampfloat(0.0F, 2.0F, 20.0F, n1 / 2, n2 / 2));
/* 175 */     assertEqual(b3, Array.rampfloat(0.0F, 2.0F, 20.0F, 200.0F, n1 / 2, n2 / 2, n3 / 2));
/*     */     
/* 177 */     b1 = Array.copy(a1);
/* 178 */     b2 = Array.copy(a2);
/* 179 */     b3 = Array.copy(a3);
/* 180 */     Array.copy(n1 - 1, 1, a1, 1, b1);
/* 181 */     Array.copy(n1 - 2, n2 - 1, 2, 1, a2, 2, 1, b2);
/* 182 */     Array.copy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3, 3, 2, 1, b3);
/* 183 */     assertEqual(b1, Array.rampfloat(0.0F, 1.0F, n1));
/* 184 */     assertEqual(b2, Array.rampfloat(0.0F, 1.0F, 10.0F, n1, n2));
/* 185 */     assertEqual(b3, Array.rampfloat(0.0F, 1.0F, 10.0F, 100.0F, n1, n2, n3));
/*     */     
/* 187 */     b1 = Array.reverse(Array.reverse(a1));
/* 188 */     assertEqual(b1, a1);
/*     */     
/* 190 */     b2 = Array.reshape(n1, n2, Array.flatten(a2));
/* 191 */     b3 = Array.reshape(n1, n2, n3, Array.flatten(a3));
/* 192 */     assertEqual(a2, b2);
/* 193 */     assertEqual(a3, b3);
/*     */     
/* 195 */     b2 = Array.transpose(Array.transpose(a2));
/* 196 */     assertEqual(a2, b2);
/*     */   }
/*     */   
/*     */   public void testFloat2() {
/* 200 */     int n1 = 3;
/* 201 */     int n2 = 4;
/* 202 */     int n3 = 5;
/* 203 */     float r0 = 0.0F;
/* 204 */     float ra = 2.0F;
/* 205 */     float rb1 = 1.0F;
/* 206 */     float rb2 = 2.0F;
/* 207 */     float rb3 = 4.0F;
/*     */ 
/*     */     
/* 210 */     assertEqual(Array.zerofloat(n1, n2, n3), Array.fillfloat(r0, n1, n2, n3));
/*     */     
/* 212 */     float[][][] rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 213 */     assertEqual(rx, Array.sub(Array.add(rx, rx), rx));
/* 214 */     assertEqual(rx, Array.sub(Array.add(rx, ra), ra));
/* 215 */     assertEqual(Array.fillfloat(ra, n1, n2, n3), Array.sub(Array.add(ra, rx), rx));
/*     */     
/* 217 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 218 */     assertEqual(rx, Array.div(Array.mul(rx, rx), rx));
/* 219 */     assertEqual(rx, Array.div(Array.mul(rx, ra), ra));
/* 220 */     assertEqual(Array.fillfloat(ra, n1, n2, n3), Array.div(Array.mul(ra, rx), rx));
/*     */     
/* 222 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 223 */     assertEqual(rx, Array.log(Array.exp(rx)));
/*     */     
/* 225 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 226 */     assertAlmostEqual(rx, Array.mul(Array.sqrt(rx), Array.sqrt(rx)));
/*     */     
/* 228 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 229 */     assertAlmostEqual(rx, Array.pow(Array.sqrt(rx), 2.0F));
/*     */     
/* 231 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 232 */     int[] imax = { -1, -1, -1 };
/* 233 */     float rmax = Array.max(rx, imax);
/* 234 */     assertTrue((rmax == rx[n3 - 1][n2 - 1][n1 - 1]));
/* 235 */     assertEquals(n1 - 1, imax[0]);
/* 236 */     assertEquals(n2 - 1, imax[1]);
/* 237 */     assertEquals(n3 - 1, imax[2]);
/*     */     
/* 239 */     rx = Array.rampfloat(ra, rb1, rb2, rb3, n1, n2, n3);
/* 240 */     int[] imin = { -1, -1, -1 };
/* 241 */     float rmin = Array.min(rx, imin);
/* 242 */     assertTrue((rmin == rx[0][0][0]));
/* 243 */     assertEquals(0, imin[0]);
/* 244 */     assertEquals(0, imin[1]);
/* 245 */     assertEquals(0, imin[2]);
/*     */   }
/*     */   
/*     */   private void assertEqual(float[] rx, float[] ry) {
/* 249 */     assertTrue(Array.equal(rx, ry));
/*     */   }
/*     */   
/*     */   private void assertEqual(float[][] rx, float[][] ry) {
/* 253 */     assertTrue(Array.equal(rx, ry));
/*     */   }
/*     */   
/*     */   private void assertEqual(float[][][] rx, float[][][] ry) {
/* 257 */     assertTrue(Array.equal(rx, ry));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertAlmostEqual(float[][][] rx, float[][][] ry) {
/* 273 */     float tolerance = 1.1920929E-5F;
/* 274 */     assertTrue(Array.equal(tolerance, rx, ry));
/*     */   }
/*     */   
/*     */   public void testCfloat1() {
/* 278 */     int n1 = 8;
/* 279 */     int n2 = 6;
/* 280 */     int n3 = 4;
/* 281 */     Cfloat c0 = new Cfloat(0.0F, 0.0F);
/* 282 */     Cfloat c1 = new Cfloat(1.0F, 0.0F);
/* 283 */     Cfloat c2 = new Cfloat(2.0F, 0.0F);
/* 284 */     Cfloat c10 = new Cfloat(10.0F, 0.0F);
/* 285 */     Cfloat c12 = new Cfloat(12.0F, 0.0F);
/* 286 */     Cfloat c20 = new Cfloat(20.0F, 0.0F);
/* 287 */     Cfloat c100 = new Cfloat(100.0F, 0.0F);
/* 288 */     Cfloat c123 = new Cfloat(123.0F, 0.0F);
/* 289 */     Cfloat c200 = new Cfloat(200.0F, 0.0F);
/* 290 */     float[] a1 = Array.crampfloat(c0, c1, n1);
/* 291 */     float[][] a2 = Array.crampfloat(c0, c1, c10, n1, n2);
/* 292 */     float[][][] a3 = Array.crampfloat(c0, c1, c10, c100, n1, n2, n3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     float[] b1 = Array.ccopy(a1);
/* 298 */     float[][] b2 = Array.ccopy(a2);
/* 299 */     float[][][] b3 = Array.ccopy(a3);
/* 300 */     assertEqual(b1, a1);
/* 301 */     assertEqual(b2, a2);
/* 302 */     assertEqual(b3, a3);
/*     */     
/* 304 */     Array.ccopy(a1, b1);
/* 305 */     Array.ccopy(a2, b2);
/* 306 */     Array.ccopy(a3, b3);
/* 307 */     assertEqual(b1, a1);
/* 308 */     assertEqual(b2, a2);
/* 309 */     assertEqual(b3, a3);
/*     */     
/* 311 */     b1 = Array.ccopy(n1 - 1, a1);
/* 312 */     b2 = Array.ccopy(n1 - 1, n2 - 1, a2);
/* 313 */     b3 = Array.ccopy(n1 - 1, n2 - 1, n3 - 1, a3);
/* 314 */     assertEqual(b1, Array.crampfloat(c0, c1, n1 - 1));
/* 315 */     assertEqual(b2, Array.crampfloat(c0, c1, c10, n1 - 1, n2 - 1));
/* 316 */     assertEqual(b3, Array.crampfloat(c0, c1, c10, c100, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 318 */     Array.ccopy(n1 - 1, a1, b1);
/* 319 */     Array.ccopy(n1 - 1, n2 - 1, a2, b2);
/* 320 */     Array.ccopy(n1 - 1, n2 - 1, n3 - 1, a3, b3);
/* 321 */     assertEqual(b1, Array.crampfloat(c0, c1, n1 - 1));
/* 322 */     assertEqual(b2, Array.crampfloat(c0, c1, c10, n1 - 1, n2 - 1));
/* 323 */     assertEqual(b3, Array.crampfloat(c0, c1, c10, c100, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 325 */     b1 = Array.ccopy(n1 - 1, 1, a1);
/* 326 */     b2 = Array.ccopy(n1 - 2, n2 - 1, 2, 1, a2);
/* 327 */     b3 = Array.ccopy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3);
/* 328 */     assertEqual(b1, Array.crampfloat(c1, c1, n1 - 1));
/* 329 */     assertEqual(b2, Array.crampfloat(c12, c1, c10, n1 - 1, n2 - 1));
/* 330 */     assertEqual(b3, Array.crampfloat(c123, c1, c10, c100, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 332 */     Array.ccopy(n1 - 1, 1, a1, 0, b1);
/* 333 */     Array.ccopy(n1 - 2, n2 - 1, 2, 1, a2, 0, 0, b2);
/* 334 */     Array.ccopy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3, 0, 0, 0, b3);
/* 335 */     assertEqual(b1, Array.crampfloat(c1, c1, n1 - 1));
/* 336 */     assertEqual(b2, Array.crampfloat(c12, c1, c10, n1 - 1, n2 - 1));
/* 337 */     assertEqual(b3, Array.crampfloat(c123, c1, c10, c100, n1 - 1, n2 - 1, n3 - 1));
/*     */     
/* 339 */     b1 = Array.ccopy(n1 / 2, 0, 2, a1);
/* 340 */     b2 = Array.ccopy(n1 / 2, n2 / 2, 0, 0, 2, 2, a2);
/* 341 */     b3 = Array.ccopy(n1 / 2, n2 / 2, n3 / 2, 0, 0, 0, 2, 2, 2, a3);
/* 342 */     assertEqual(b1, Array.crampfloat(c0, c2, n1 / 2));
/* 343 */     assertEqual(b2, Array.crampfloat(c0, c2, c20, n1 / 2, n2 / 2));
/* 344 */     assertEqual(b3, Array.crampfloat(c0, c2, c20, c200, n1 / 2, n2 / 2, n3 / 2));
/*     */     
/* 346 */     b1 = Array.ccopy(a1);
/* 347 */     b2 = Array.ccopy(a2);
/* 348 */     b3 = Array.ccopy(a3);
/* 349 */     Array.ccopy(n1 - 1, 1, a1, 1, b1);
/* 350 */     Array.ccopy(n1 - 2, n2 - 1, 2, 1, a2, 2, 1, b2);
/* 351 */     Array.ccopy(n1 - 3, n2 - 2, n3 - 1, 3, 2, 1, a3, 3, 2, 1, b3);
/* 352 */     assertEqual(b1, Array.crampfloat(c0, c1, n1));
/* 353 */     assertEqual(b2, Array.crampfloat(c0, c1, c10, n1, n2));
/* 354 */     assertEqual(b3, Array.crampfloat(c0, c1, c10, c100, n1, n2, n3));
/*     */     
/* 356 */     b1 = Array.creverse(Array.creverse(a1));
/* 357 */     assertEqual(b1, a1);
/*     */     
/* 359 */     b2 = Array.creshape(n1, n2, Array.cflatten(a2));
/* 360 */     b3 = Array.creshape(n1, n2, n3, Array.cflatten(a3));
/* 361 */     assertEqual(a2, b2);
/* 362 */     assertEqual(a3, b3);
/*     */     
/* 364 */     b2 = Array.ctranspose(Array.ctranspose(a2));
/* 365 */     assertEqual(a2, b2);
/*     */   }
/*     */   
/*     */   public void testCfloat2() {
/* 369 */     int n1 = 3;
/* 370 */     int n2 = 4;
/* 371 */     int n3 = 5;
/* 372 */     Cfloat c0 = new Cfloat();
/* 373 */     Cfloat ca = new Cfloat(1.0F, 2.0F);
/* 374 */     Cfloat cb1 = new Cfloat(2.0F, 3.0F);
/* 375 */     Cfloat cb2 = new Cfloat(3.0F, 4.0F);
/* 376 */     Cfloat cb3 = new Cfloat(4.0F, 5.0F);
/*     */ 
/*     */     
/* 379 */     assertEqual(Array.czerofloat(n1, n2, n3), Array.cfillfloat(c0, n1, n2, n3));
/*     */     
/* 381 */     float[][][] cx = Array.crampfloat(ca, cb1, cb2, cb3, n1, n2, n3);
/* 382 */     assertEqual(cx, Array.csub(Array.cadd(cx, cx), cx));
/* 383 */     assertEqual(cx, Array.csub(Array.cadd(cx, ca), ca));
/* 384 */     assertEqual(Array.cfillfloat(ca, n1, n2, n3), Array.csub(Array.cadd(ca, cx), cx));
/*     */     
/* 386 */     cx = Array.crampfloat(ca, cb1, cb2, cb3, n1, n2, n3);
/* 387 */     assertEqual(cx, Array.cdiv(Array.cmul(cx, cx), cx));
/* 388 */     assertEqual(cx, Array.cdiv(Array.cmul(cx, ca), ca));
/* 389 */     assertEqual(Array.cfillfloat(ca, n1, n2, n3), Array.cdiv(Array.cmul(ca, cx), cx));
/*     */     
/* 391 */     cx = Array.crampfloat(ca, cb1, cb2, cb3, n1, n2, n3);
/* 392 */     assertEqual(Array.cnorm(cx), Array.cabs(Array.cmul(cx, Array.cconj(cx))));
/*     */     
/* 394 */     float[][][] rr = Array.fillfloat(1.0F, n1, n2, n3);
/* 395 */     float[][][] ra = Array.rampfloat(0.0F, 1.0F, 1.0F, 1.0F, n1, n2, n3);
/* 396 */     cx = Array.polar(rr, ra);
/* 397 */     float[][][] rx = Array.cos(ra);
/* 398 */     float[][][] ry = Array.sin(ra);
/* 399 */     float[][][] cy = Array.cmplx(rx, ry);
/* 400 */     assertEqual(cx, cy);
/* 401 */     Cfloat ci = new Cfloat(0.0F, 1.0F);
/* 402 */     float[][][] ciw = Array.crampfloat(c0, ci, ci, ci, n1, n2, n3);
/* 403 */     float[][][] cz = Array.cexp(ciw);
/* 404 */     assertEqual(cx, cz);
/*     */   }
/*     */   
/*     */   public void testMonotonic() {
/* 408 */     double[] a = new double[0];
/* 409 */     assertTrue(Array.isMonotonic(a));
/* 410 */     assertTrue(Array.isIncreasing(a));
/* 411 */     assertTrue(Array.isDecreasing(a));
/*     */     
/* 413 */     double[] a0 = { 0.0D };
/* 414 */     assertTrue(Array.isMonotonic(a0));
/* 415 */     assertTrue(Array.isIncreasing(a0));
/* 416 */     assertTrue(Array.isDecreasing(a0));
/*     */     
/* 418 */     double[] a01 = { 0.0D, 1.0D };
/* 419 */     assertTrue(Array.isMonotonic(a01));
/* 420 */     assertTrue(Array.isIncreasing(a01));
/* 421 */     assertTrue(!Array.isDecreasing(a01));
/*     */     
/* 423 */     double[] a10 = { 1.0D, 0.0D };
/* 424 */     assertTrue(Array.isMonotonic(a10));
/* 425 */     assertTrue(!Array.isIncreasing(a10));
/* 426 */     assertTrue(Array.isDecreasing(a10));
/*     */     
/* 428 */     double[] a101 = { 1.0D, 0.0D, 1.0D };
/* 429 */     assertTrue(!Array.isMonotonic(a101));
/* 430 */     assertTrue(!Array.isIncreasing(a101));
/* 431 */     assertTrue(!Array.isDecreasing(a101));
/*     */     
/* 433 */     double[] a010 = { 0.0D, 1.0D, 0.0D };
/* 434 */     assertTrue(!Array.isMonotonic(a010));
/* 435 */     assertTrue(!Array.isIncreasing(a010));
/* 436 */     assertTrue(!Array.isDecreasing(a010));
/*     */   }
/*     */   
/*     */   public void testBinarySearch() {
/* 440 */     double[] a = new double[0];
/* 441 */     checkSearch(a, 1.0D);
/*     */     
/* 443 */     double[] a0 = { 2.0D };
/* 444 */     checkSearch(a0, 1.0D);
/* 445 */     checkSearch(a0, 2.0D);
/* 446 */     checkSearch(a0, 3.0D);
/*     */     
/* 448 */     double[] a13 = { 1.0D, 3.0D };
/* 449 */     checkSearch(a13, 0.0D);
/* 450 */     checkSearch(a13, 1.0D);
/* 451 */     checkSearch(a13, 2.0D);
/* 452 */     checkSearch(a13, 3.0D);
/* 453 */     checkSearch(a13, 4.0D);
/*     */     
/* 455 */     double[] a31 = { 3.0D, 1.0D };
/* 456 */     checkSearch(a31, 0.0D);
/* 457 */     checkSearch(a31, 1.0D);
/* 458 */     checkSearch(a31, 2.0D);
/* 459 */     checkSearch(a31, 3.0D);
/* 460 */     checkSearch(a31, 4.0D);
/*     */     
/* 462 */     double[] a135 = { 1.0D, 3.0D, 5.0D };
/* 463 */     checkSearch(a135, 0.0D);
/* 464 */     checkSearch(a135, 1.0D);
/* 465 */     checkSearch(a135, 2.0D);
/* 466 */     checkSearch(a135, 3.0D);
/* 467 */     checkSearch(a135, 4.0D);
/* 468 */     checkSearch(a135, 5.0D);
/* 469 */     checkSearch(a135, 6.0D);
/*     */     
/* 471 */     double[] a531 = { 5.0D, 3.0D, 1.0D };
/* 472 */     checkSearch(a531, 0.0D);
/* 473 */     checkSearch(a531, 1.0D);
/* 474 */     checkSearch(a531, 2.0D);
/* 475 */     checkSearch(a531, 3.0D);
/* 476 */     checkSearch(a531, 4.0D);
/* 477 */     checkSearch(a531, 5.0D);
/* 478 */     checkSearch(a531, 6.0D);
/*     */   }
/*     */   private void checkSearch(double[] a, double x) {
/* 481 */     int n = a.length;
/* 482 */     int i = Array.binarySearch(a, x);
/* 483 */     validateSearch(a, x, i);
/* 484 */     for (int is = -2; is < n + 2; is++) {
/* 485 */       i = Array.binarySearch(a, x, is);
/* 486 */       validateSearch(a, x, i);
/*     */     } 
/*     */   }
/*     */   private void validateSearch(double[] a, double x, int i) {
/* 490 */     int n = a.length;
/* 491 */     if (i >= 0) {
/* 492 */       assertTrue((a[i] == x));
/*     */     } else {
/* 494 */       i = -(i + 1);
/* 495 */       if (n == 0) {
/* 496 */         assertTrue((i == 0));
/* 497 */       } else if (n < 2 || a[0] < a[n - 1]) {
/* 498 */         if (i == 0) {
/* 499 */           assertTrue((x < a[i]));
/* 500 */         } else if (i == n) {
/* 501 */           assertTrue((a[i - 1] < x));
/*     */         } else {
/* 503 */           assertTrue((a[i - 1] < x && x < a[i]));
/*     */         }
/*     */       
/* 506 */       } else if (i == 0) {
/* 507 */         assertTrue((x > a[i]));
/* 508 */       } else if (i == n) {
/* 509 */         assertTrue((a[i - 1] > x));
/*     */       } else {
/* 511 */         assertTrue((a[i - 1] > x && x > a[i]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/ArrayTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */