/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect1
/*     */   implements Vect
/*     */ {
/*  26 */   private double[] _data = null;
/*     */   
/*  28 */   private double _variance = 1.0D;
/*     */   
/*  30 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect1(double[] data, double variance) {
/*  40 */     init(data, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(double[] data, double variance) {
/*  53 */     this._data = data;
/*  54 */     this._variance = variance;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  59 */     return this._data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getData() {
/*  65 */     return this._data;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayVect1 clone() {
/*     */     try {
/*  71 */       ArrayVect1 result = (ArrayVect1)super.clone();
/*  72 */       result._data = (double[])result._data.clone();
/*  73 */       return result;
/*  74 */     } catch (CloneNotSupportedException ex) {
/*  75 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/*  76 */       e.initCause(ex);
/*  77 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/*  83 */     double result = 0.0D;
/*  84 */     ArrayVect1 rhs = (ArrayVect1)other;
/*  85 */     for (int i = 0; i < this._data.length; i++) {
/*  86 */       result += this._data[i] * rhs._data[i];
/*     */     }
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     StringBuilder sb = new StringBuilder();
/*  94 */     sb.append("(");
/*  95 */     for (int i = 0; i < this._data.length; i++) {
/*  96 */       sb.append("" + this._data[i]);
/*  97 */       if (i < this._data.length - 1) sb.append(", "); 
/*     */     } 
/*  99 */     sb.append(")");
/* 100 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 105 */     this._data = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 110 */     double scale = Almost.FLOAT.divide(1.0D, getSize() * this._variance, 0.0D);
/* 111 */     VectUtil.scale(this, scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {}
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 122 */     ArrayVect1 rhs = (ArrayVect1)other;
/* 123 */     for (int i = 0; i < this._data.length; i++) {
/* 124 */       this._data[i] = scaleThis * this._data[i] + scaleOther * rhs._data[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 130 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/* 135 */     return Almost.FLOAT.divide(dot(this), getSize() * this._variance, 0.0D);
/*     */   }
/*     */   
/*     */   protected ArrayVect1() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */