/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AxisAlignedQuad
/*     */   extends Group
/*     */   implements Selectable, Dragable
/*     */ {
/*     */   private AxisAlignedFrame _frame;
/*     */   private boolean _handlesVisible;
/*     */   private Handle[] _h;
/*     */   private Dragger _dragger;
/*     */   
/*     */   public AxisAlignedFrame getFrame() {
/*     */     return this._frame;
/*     */   }
/*     */   
/*     */   public void dragBegin(DragContext dc) {
/*     */     this._dragger = new Dragger();
/*     */     this._dragger.dragBegin(dc);
/*     */   }
/*     */   
/*     */   public void drag(DragContext dc) {
/*     */     this._dragger.drag(dc);
/*     */   }
/*     */   
/*     */   public void dragEnd(DragContext dc) {
/*     */     this._dragger.dragEnd(dc);
/*     */     this._dragger = null;
/*     */   }
/*     */   
/*     */   protected void selectedChanged() {
/*     */     if (isSelected()) {
/*     */       updateHandles();
/*     */       showHandles();
/*     */     } else {
/*     */       hideHandles();
/*     */     } 
/*     */   }
/*     */   
/*     */   public AxisAlignedQuad(Axis axis, Point3 qa, Point3 qb) {
/*  73 */     this._h = new Handle[4];
/*     */     this._frame = new AxisAlignedFrame(axis, qa, qb);
/*     */     addChild(this._frame);
/*     */   }
/*     */   private class Dragger implements Dragable { private MouseConstrained _mouseConstrained;
/*     */     private Point3 _origin;
/*     */     
/*     */     public void dragBegin(DragContext dc) {
/*  81 */       Point3 origin = dc.getPointWorld();
/*  82 */       Vector3 normal = null;
/*  83 */       Axis axis = AxisAlignedQuad.this._frame.getAxis();
/*  84 */       if (axis == Axis.X) {
/*  85 */         normal = new Vector3(1.0D, 0.0D, 0.0D);
/*  86 */       } else if (axis == Axis.Y) {
/*  87 */         normal = new Vector3(0.0D, 1.0D, 0.0D);
/*  88 */       } else if (axis == Axis.Z) {
/*  89 */         normal = new Vector3(0.0D, 0.0D, 1.0D);
/*     */       } 
/*  91 */       Plane plane = new Plane(origin, normal);
/*  92 */       MouseEvent event = dc.getMouseEvent();
/*  93 */       Matrix44 worldToPixel = dc.getWorldToPixel();
/*  94 */       if (event.isControlDown()) {
/*  95 */         this._mouseConstrained = new MouseOnLine(event, origin, normal, worldToPixel);
/*     */       } else {
/*  97 */         this._mouseConstrained = new MouseOnPlane(event, origin, plane, worldToPixel);
/*     */       } 
/*  99 */       this._origin = origin;
/* 100 */       this._qa = AxisAlignedQuad.this._frame.getCornerMin();
/* 101 */       this._qb = AxisAlignedQuad.this._frame.getCornerMax();
/*     */     } private Point3 _qa; private Point3 _qb; private Dragger() {}
/*     */     public void drag(DragContext dc) {
/* 104 */       Point3 point = this._mouseConstrained.getPoint(dc.getMouseEvent());
/*     */ 
/*     */ 
/*     */       
/* 108 */       Vector3 vector = point.minus(this._origin);
/* 109 */       Point3 qa = this._qa.plus(vector);
/* 110 */       Point3 qb = this._qb.plus(vector);
/* 111 */       AxisAlignedQuad.this._frame.setCorners(qa, qb);
/* 112 */       AxisAlignedQuad.this.updateHandles();
/*     */     }
/*     */     public void dragEnd(DragContext dc) {
/* 115 */       this._mouseConstrained = null;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Handle
/*     */     extends HandleBox
/*     */     implements Dragable
/*     */   {
/*     */     private MouseOnPlane _mouseOnPlane;
/*     */     
/*     */     Handle(Point3 p) {
/* 127 */       super(p);
/*     */     }
/*     */     public void dragBegin(DragContext dc) {
/* 130 */       Point3 p = dc.getPointWorld();
/* 131 */       Vector3 n = null;
/* 132 */       Axis axis = AxisAlignedQuad.this._frame.getAxis();
/* 133 */       if (axis == Axis.X) {
/* 134 */         n = new Vector3(1.0D, 0.0D, 0.0D);
/* 135 */       } else if (axis == Axis.Y) {
/* 136 */         n = new Vector3(0.0D, 1.0D, 0.0D);
/* 137 */       } else if (axis == Axis.Z) {
/* 138 */         n = new Vector3(0.0D, 0.0D, 1.0D);
/*     */       } 
/* 140 */       MouseEvent event = dc.getMouseEvent();
/* 141 */       Point3 origin = getLocation();
/* 142 */       Plane plane = new Plane(p, n);
/* 143 */       Matrix44 worldToPixel = dc.getWorldToPixel();
/* 144 */       this._mouseOnPlane = new MouseOnPlane(event, origin, plane, worldToPixel);
/*     */     }
/*     */     public void drag(DragContext dc) {
/* 147 */       Point3 qnew = this._mouseOnPlane.getPoint(dc.getMouseEvent());
/*     */ 
/*     */ 
/*     */       
/* 151 */       if (this == AxisAlignedQuad.this._h[0]) {
/* 152 */         AxisAlignedQuad.this._frame.setCorners(qnew, AxisAlignedQuad.this._frame.getCorner(3));
/* 153 */       } else if (this == AxisAlignedQuad.this._h[1]) {
/* 154 */         AxisAlignedQuad.this._frame.setCorners(qnew, AxisAlignedQuad.this._frame.getCorner(2));
/* 155 */       } else if (this == AxisAlignedQuad.this._h[2]) {
/* 156 */         AxisAlignedQuad.this._frame.setCorners(qnew, AxisAlignedQuad.this._frame.getCorner(1));
/* 157 */       } else if (this == AxisAlignedQuad.this._h[3]) {
/* 158 */         AxisAlignedQuad.this._frame.setCorners(qnew, AxisAlignedQuad.this._frame.getCorner(0));
/*     */       } 
/* 160 */       AxisAlignedQuad.this.updateHandles();
/*     */     }
/*     */     public void dragEnd(DragContext dc) {
/* 163 */       this._mouseOnPlane = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateHandles() {
/* 169 */     Point3 q0 = this._frame.getCorner(0);
/* 170 */     Point3 q1 = this._frame.getCorner(1);
/* 171 */     Point3 q2 = this._frame.getCorner(2);
/* 172 */     Point3 q3 = this._frame.getCorner(3);
/* 173 */     if (this._h[0] == null) {
/* 174 */       this._h[0] = new Handle(q0);
/* 175 */       this._h[1] = new Handle(q1);
/* 176 */       this._h[2] = new Handle(q2);
/* 177 */       this._h[3] = new Handle(q3);
/*     */     } else {
/* 179 */       this._h[0].setLocation(q0);
/* 180 */       this._h[1].setLocation(q1);
/* 181 */       this._h[2].setLocation(q2);
/* 182 */       this._h[3].setLocation(q3);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void showHandles() {
/* 187 */     if (!this._handlesVisible) {
/* 188 */       this._handlesVisible = true;
/* 189 */       addChild(this._h[0]);
/* 190 */       addChild(this._h[1]);
/* 191 */       addChild(this._h[2]);
/* 192 */       addChild(this._h[3]);
/* 193 */       dirtyDraw();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void hideHandles() {
/* 198 */     if (this._handlesVisible) {
/* 199 */       this._handlesVisible = false;
/* 200 */       removeChild(this._h[0]);
/* 201 */       removeChild(this._h[1]);
/* 202 */       removeChild(this._h[2]);
/* 203 */       removeChild(this._h[3]);
/* 204 */       dirtyDraw();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/AxisAlignedQuad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */