/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cdouble
/*     */ {
/*  19 */   public static final Cdouble DBL_I = new Cdouble(0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double r;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double i;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble() {
/*  35 */     this(0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble(double r) {
/*  43 */     this(r, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble(double r, double i) {
/*  52 */     this.r = r;
/*  53 */     this.i = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble(Cdouble x) {
/*  61 */     this(x.r, x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble plus(Cdouble x) {
/*  70 */     return (new Cdouble(this)).plusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble minus(Cdouble x) {
/*  79 */     return (new Cdouble(this)).minusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble times(Cdouble x) {
/*  88 */     return (new Cdouble(this)).timesEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble over(Cdouble x) {
/*  97 */     return (new Cdouble(this)).overEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble plus(double x) {
/* 106 */     return (new Cdouble(this)).plusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble minus(double x) {
/* 115 */     return (new Cdouble(this)).minusEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble times(double x) {
/* 124 */     return (new Cdouble(this)).timesEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble over(double x) {
/* 133 */     return (new Cdouble(this)).overEquals(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble plusEquals(Cdouble x) {
/* 142 */     this.r += x.r;
/* 143 */     this.i += x.i;
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble minusEquals(Cdouble x) {
/* 153 */     this.r -= x.r;
/* 154 */     this.i -= x.i;
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble timesEquals(Cdouble x) {
/* 164 */     double tr = this.r;
/* 165 */     double ti = this.i;
/* 166 */     double xr = x.r;
/* 167 */     double xi = x.i;
/* 168 */     this.r = tr * xr - ti * xi;
/* 169 */     this.i = tr * xi + ti * xr;
/* 170 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble overEquals(Cdouble x) {
/* 179 */     double tr = this.r;
/* 180 */     double ti = this.i;
/* 181 */     double xr = x.r;
/* 182 */     double xi = x.i;
/* 183 */     double d = norm(x);
/* 184 */     this.r = (tr * xr + ti * xi) / d;
/* 185 */     this.i = (ti * xr - tr * xi) / d;
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble plusEquals(double x) {
/* 195 */     this.r += x;
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble minusEquals(double x) {
/* 205 */     this.r -= x;
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble timesEquals(double x) {
/* 215 */     this.r *= x;
/* 216 */     this.i *= x;
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble overEquals(double x) {
/* 226 */     this.r /= x;
/* 227 */     this.i /= x;
/* 228 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble conjEquals() {
/* 236 */     this.i = -this.i;
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble invEquals() {
/* 245 */     this.r = -this.r;
/* 246 */     this.i = -this.i;
/* 247 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble negEquals() {
/* 255 */     double d = norm();
/* 256 */     this.r /= d;
/* 257 */     this.i = -this.i / d;
/* 258 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReal() {
/* 266 */     return (this.i == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImag() {
/* 274 */     return (this.r == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble conj() {
/* 282 */     return new Cdouble(this.r, -this.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble inv() {
/* 290 */     double d = norm();
/* 291 */     return new Cdouble(this.r / d, -this.i / d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble neg() {
/* 299 */     return new Cdouble(-this.r, -this.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double abs() {
/* 307 */     return abs(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double arg() {
/* 315 */     return arg(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double norm() {
/* 324 */     return norm(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble sqrt() {
/* 332 */     return sqrt(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble exp() {
/* 340 */     return exp(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble log() {
/* 348 */     return log(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble log10() {
/* 356 */     return log10(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble pow(double y) {
/* 365 */     return pow(this, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble pow(Cdouble y) {
/* 374 */     return pow(this, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble sin() {
/* 382 */     return sin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble cos() {
/* 390 */     return cos(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble tan() {
/* 398 */     return tan(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble sinh() {
/* 406 */     return sinh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble cosh() {
/* 414 */     return cosh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble tanh() {
/* 422 */     return tanh(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isReal(Cdouble x) {
/* 431 */     return (x.i == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isImag(Cdouble x) {
/* 440 */     return (x.r == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble conj(Cdouble x) {
/* 449 */     return new Cdouble(x.r, -x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cdouble inv(Cdouble x) {
/* 458 */     double d = x.norm();
/* 459 */     return new Cdouble(x.r / d, -x.i / d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble neg(Cdouble x) {
/* 468 */     return new Cdouble(-x.r, -x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble polar(double r, double a) {
/* 478 */     return new Cdouble(r * cos(a), r * sin(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble add(Cdouble x, Cdouble y) {
/* 488 */     return x.plus(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble sub(Cdouble x, Cdouble y) {
/* 498 */     return x.minus(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble mul(Cdouble x, Cdouble y) {
/* 508 */     return x.times(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble div(Cdouble x, Cdouble y) {
/* 518 */     return x.over(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double abs(Cdouble x) {
/* 527 */     double ar = abs(x.r);
/* 528 */     double ai = abs(x.i);
/* 529 */     double s = max(abs(ar), abs(ai));
/* 530 */     if (s == 0.0D)
/* 531 */       return 0.0D; 
/* 532 */     ar /= s;
/* 533 */     ai /= s;
/* 534 */     return s * sqrt(ar * ar + ai * ai);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double arg(Cdouble x) {
/* 543 */     return atan2(x.i, x.r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double norm(Cdouble x) {
/* 553 */     return x.r * x.r + x.i * x.i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble sqrt(Cdouble x) {
/* 562 */     if (x.r == 0.0D) {
/* 563 */       double d = sqrt(0.5D * abs(x.i));
/* 564 */       return new Cdouble(d, (x.i < 0.0D) ? -d : d);
/*     */     } 
/* 566 */     double t = sqrt(2.0D * (abs(x) + abs(x.r)));
/* 567 */     double u = 0.5D * t;
/* 568 */     return (x.r > 0.0D) ? new Cdouble(u, x.i / t) : new Cdouble(abs(x.i) / t, (x.i < 0.0D) ? -u : u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble exp(Cdouble x) {
/* 580 */     return polar(exp(x.r), x.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble log(Cdouble x) {
/* 589 */     return new Cdouble(log(abs(x)), arg(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble log10(Cdouble x) {
/* 598 */     return log(x).overEquals(log(10.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble pow(Cdouble x, double y) {
/* 608 */     if (x.i == 0.0D)
/* 609 */       return new Cdouble(pow(x.r, y)); 
/* 610 */     Cdouble t = log(x);
/* 611 */     return polar(exp(y * t.r), y * t.i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble pow(double x, Cdouble y) {
/* 621 */     if (x == 0.0D)
/* 622 */       return new Cdouble(); 
/* 623 */     return polar(pow(x, y.r), y.i * log(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble pow(Cdouble x, Cdouble y) {
/* 633 */     if (x.r == 0.0D && x.i == 0.0D)
/* 634 */       return new Cdouble(); 
/* 635 */     return exp(y.times(log(x)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble sin(Cdouble x) {
/* 644 */     return new Cdouble(sin(x.r) * cosh(x.i), cos(x.r) * sinh(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble cos(Cdouble x) {
/* 653 */     return new Cdouble(cos(x.r) * cosh(x.i), -sin(x.r) * sinh(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble tan(Cdouble x) {
/* 662 */     return sin(x).overEquals(cos(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble sinh(Cdouble x) {
/* 671 */     return new Cdouble(sinh(x.r) * cos(x.i), cosh(x.r) * sin(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble cosh(Cdouble x) {
/* 680 */     return new Cdouble(cosh(x.r) * cos(x.i), sinh(x.r) * sin(x.i));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cdouble tanh(Cdouble x) {
/* 689 */     return sinh(x).overEquals(cosh(x));
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 693 */     if (this == obj)
/* 694 */       return true; 
/* 695 */     if (obj == null || getClass() != obj.getClass())
/* 696 */       return false; 
/* 697 */     Cdouble that = (Cdouble)obj;
/* 698 */     return (this.r == that.r && this.i == that.i);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 702 */     long rbits = Double.doubleToLongBits(this.r);
/* 703 */     long ibits = Double.doubleToLongBits(this.i);
/* 704 */     return (int)(rbits ^ rbits >>> 32L ^ ibits ^ ibits >>> 32L);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 708 */     if (this.i == 0.0D)
/* 709 */       return "(" + this.r + "+0.0i)"; 
/* 710 */     if (this.i > 0.0D) {
/* 711 */       return "(" + this.r + "+" + this.i + "i)";
/*     */     }
/* 713 */     return "(" + this.r + "-" + -this.i + "i)";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double max(double x, double y) {
/* 721 */     return (x >= y) ? x : y;
/*     */   }
/*     */   
/*     */   private static double abs(double x) {
/* 725 */     return (x >= 0.0D) ? x : -x;
/*     */   }
/*     */   
/*     */   private static double sqrt(double x) {
/* 729 */     return Math.sqrt(x);
/*     */   }
/*     */   
/*     */   private static double sin(double x) {
/* 733 */     return Math.sin(x);
/*     */   }
/*     */   
/*     */   private static double cos(double x) {
/* 737 */     return Math.cos(x);
/*     */   }
/*     */   
/*     */   private static double sinh(double x) {
/* 741 */     return Math.sinh(x);
/*     */   }
/*     */   
/*     */   private static double cosh(double x) {
/* 745 */     return Math.cosh(x);
/*     */   }
/*     */   
/*     */   private static double exp(double x) {
/* 749 */     return Math.exp(x);
/*     */   }
/*     */   
/*     */   private static double log(double x) {
/* 753 */     return Math.log(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double pow(double x, double y) {
/* 763 */     return Math.pow(x, y);
/*     */   }
/*     */   
/*     */   private static double atan2(double y, double x) {
/* 767 */     return Math.atan2(y, x);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Cdouble.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */