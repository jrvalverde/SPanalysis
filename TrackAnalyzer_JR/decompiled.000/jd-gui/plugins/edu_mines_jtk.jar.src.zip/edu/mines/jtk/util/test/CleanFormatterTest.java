/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.CleanFormatter;
/*    */ import edu.mines.jtk.util.CleanHandler;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.LogRecord;
/*    */ import java.util.logging.Logger;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CleanFormatterTest
/*    */   extends TestCase
/*    */ {
/* 23 */   private static final String NL = System.getProperty("line.separator");
/*    */ 
/*    */   
/*    */   public void testFormatter() {
/* 27 */     CleanHandler.setDefaultHandler();
/* 28 */     Logger logger = Logger.getLogger("edu.mines.jtk.util.CleanFormatter");
/* 29 */     CleanFormatter cf = new CleanFormatter();
/* 30 */     String[] messages = { "one", "two", "three" };
/* 31 */     Level[] levels = { Level.INFO, Level.WARNING, Level.SEVERE };
/* 32 */     String[] s = new String[3];
/* 33 */     for (int i = 0; i < messages.length; i++) {
/* 34 */       LogRecord lr = new LogRecord(levels[i], messages[i]);
/* 35 */       lr.setSourceClassName("Class");
/* 36 */       lr.setSourceMethodName("method");
/* 37 */       s[i] = cf.format(lr);
/* 38 */       assertTrue(s[i].endsWith(messages[i] + NL));
/* 39 */       logger.fine("|" + s[i] + "|");
/*    */     } 
/* 41 */     assert s[0].equals("one" + NL) : s[false];
/* 42 */     assert s[1].equals("WARNING: two" + NL) : s[true];
/*    */ 
/*    */     
/* 45 */     assert s[2].matches("^\\*\\*\\*\\* SEVERE WARNING \\*\\*\\*\\* \\(Class.method \\d+-\\d+ #.*\\)" + NL + "SEVERE: three" + NL + "$") : s[2];
/*    */   }
/*    */ 
/*    */   
/*    */   public void testPrepend() {
/* 50 */     String lines = CleanFormatter.prependToLines("a", "bbb" + NL + "ccc");
/* 51 */     assert lines.equals("abbb" + NL + "accc");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 57 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 60 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CleanFormatterTest(String name) {
/* 67 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 73 */       throw new IllegalStateException("need -ea");
/* 74 */     } catch (AssertionError e) {
/* 75 */       return (Test)new TestSuite(CleanFormatterTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 82 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/CleanFormatterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */