/*      */ package edu.mines.jtk.util;
/*      */ 
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Iterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RTree
/*      */   extends AbstractSet<Object>
/*      */ {
/*      */   private Node _root;
/*      */   private int _ndim;
/*      */   private int _nmin;
/*      */   private int _nmax;
/*      */   private int _size;
/*      */   private Boxer _boxer;
/*      */   private int _modIndex;
/*      */   private float[] _amin;
/*      */   private float[] _amax;
/*      */   private float[] _bmin;
/*      */   private float[] _bmax;
/*      */   private float[] _smin;
/*      */   private float[] _smax;
/*      */   private float[] _tmin;
/*      */   private float[] _tmax;
/*      */   
/*      */   public static interface Boxed
/*      */   {
/*      */     void getBounds(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*      */     
/*      */     float getDistanceSquared(float[] param1ArrayOffloat);
/*      */   }
/*      */   
/*      */   public static interface Boxer
/*      */   {
/*      */     void getBounds(Object param1Object, float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*      */     
/*      */     float getDistanceSquared(Object param1Object, float[] param1ArrayOffloat);
/*      */   }
/*      */   
/*      */   public static class Box
/*      */     implements Boxed
/*      */   {
/*      */     private int _ndim;
/*      */     private float[] _min;
/*      */     private float[] _max;
/*      */     
/*      */     public Box(float xmin, float ymin, float xmax, float ymax) {
/*  121 */       this._ndim = 2;
/*  122 */       this._min = new float[] { xmin, ymin };
/*  123 */       this._max = new float[] { xmax, ymax };
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Box(float xmin, float ymin, float zmin, float xmax, float ymax, float zmax) {
/*  139 */       this._ndim = 3;
/*  140 */       this._min = new float[] { xmin, ymin, zmin };
/*  141 */       this._max = new float[] { xmax, ymax, zmax };
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Box(float[] min, float[] max) {
/*  151 */       Check.argument((min.length == max.length), "min/max lengths are equal");
/*  152 */       this._ndim = min.length;
/*  153 */       this._min = new float[this._ndim];
/*  154 */       this._max = new float[this._ndim];
/*  155 */       for (int idim = 0; idim < this._ndim; idim++) {
/*  156 */         this._min[idim] = min[idim];
/*  157 */         this._max[idim] = max[idim];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Box(int ndim, RTree.Boxed boxed) {
/*  167 */       this._ndim = ndim;
/*  168 */       this._min = new float[this._ndim];
/*  169 */       this._max = new float[this._ndim];
/*  170 */       boxed.getBounds(this._min, this._max);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void getBounds(float[] min, float[] max) {
/*  179 */       for (int idim = 0; idim < this._ndim; idim++) {
/*  180 */         min[idim] = this._min[idim];
/*  181 */         max[idim] = this._max[idim];
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float getDistanceSquared(float[] point) {
/*  191 */       float sum = 0.0F;
/*  192 */       for (int idim = 0; idim < this._ndim; idim++) {
/*  193 */         float p = point[idim];
/*  194 */         float s = this._min[idim];
/*  195 */         float t = this._max[idim];
/*  196 */         float d = (p < s) ? (p - s) : ((p > t) ? (p - t) : 0.0F);
/*  197 */         sum += d * d;
/*      */       } 
/*  199 */       return sum;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean overlaps(Box box) {
/*  208 */       float[] bmin = box._min;
/*  209 */       float[] bmax = box._max;
/*  210 */       for (int idim = 0; idim < this._ndim; idim++) {
/*  211 */         if (this._min[idim] > bmax[idim] || this._max[idim] < bmin[idim])
/*  212 */           return false; 
/*      */       } 
/*  214 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTree(int ndim, int nmin, int nmax) {
/*  232 */     this(ndim, nmin, nmax, new DefaultBoxer(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTree(int ndim, int nmin, int nmax, Boxer boxer) {
/*  247 */     Check.argument((nmin > 0), "nmin>0");
/*  248 */     Check.argument((nmin <= nmax / 2), "nmin<=nmax/2");
/*  249 */     Check.argument((nmax >= 4), "nmax>=4");
/*  250 */     this._ndim = ndim;
/*  251 */     this._nmin = nmin;
/*  252 */     this._nmax = nmax;
/*  253 */     this._boxer = boxer;
/*  254 */     this._root = new Node(1);
/*  255 */     this._smin = new float[this._ndim];
/*  256 */     this._smax = new float[this._ndim];
/*  257 */     this._tmin = new float[this._ndim];
/*  258 */     this._tmax = new float[this._ndim];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  267 */     return this._size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  274 */     this._root = new Node(1);
/*  275 */     this._size = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  283 */     return (this._size == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean add(Object object) {
/*  292 */     Check.argument((object != null), "object is not null");
/*  293 */     Node leaf = this._root.chooseNodeFor(object);
/*  294 */     if (leaf.indexOf(object) >= 0)
/*  295 */       return false; 
/*  296 */     leaf.add(object);
/*  297 */     this._size++;
/*  298 */     this._modIndex++;
/*      */     
/*  300 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int addPacked(Object[] objects) {
/*  319 */     int size = this._size;
/*      */ 
/*      */     
/*  322 */     int n = objects.length;
/*  323 */     int[] index = new int[n];
/*  324 */     float[][] x = new float[this._ndim][n];
/*  325 */     float[] xmin = new float[3];
/*  326 */     float[] xmax = new float[3];
/*  327 */     for (int i = 0; i < n; i++) {
/*  328 */       index[i] = i;
/*  329 */       this._boxer.getBounds(objects[i], xmin, xmax);
/*  330 */       for (int idim = 0; idim < this._ndim; idim++) {
/*  331 */         x[idim][i] = 0.5F * (xmin[idim] + xmax[idim]);
/*      */       }
/*      */     } 
/*      */     
/*  335 */     addPacked(0, x, 0, n, index, objects);
/*      */ 
/*      */     
/*  338 */     return this._size - size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean remove(Object object) {
/*  347 */     Check.argument((object != null), "object is not null");
/*  348 */     Node leaf = this._root.findLeafWith(object);
/*  349 */     if (leaf == null)
/*  350 */       return false; 
/*  351 */     leaf.remove(object, null);
/*  352 */     this._size--;
/*  353 */     this._modIndex++;
/*      */     
/*  355 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Object object) {
/*  364 */     Node leaf = this._root.findLeafWith(object);
/*  365 */     return (leaf != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<Object> iterator() {
/*  382 */     return new RTreeIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLevels() {
/*  390 */     return this._root.level();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] findOverlapping(float[] min, float[] max) {
/*  400 */     Check.argument((min.length == this._ndim), "min.length equals tree ndim");
/*  401 */     Check.argument((max.length == this._ndim), "max.length equals tree ndim");
/*  402 */     ArrayList<Object> list = new ArrayList();
/*  403 */     this._root.findOverlapping(min, max, list);
/*  404 */     return list.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] findOverlapping(Box box) {
/*  414 */     Check.argument((box != null), "box is not null");
/*  415 */     Check.argument((box._ndim == this._ndim), "box ndim = tree ndim");
/*  416 */     return findOverlapping(box._min, box._max);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] findInSphere(float[] center, float radius) {
/*  429 */     Check.argument((center.length == this._ndim), "center.length equals tree ndim");
/*  430 */     ArrayList<Object> list = new ArrayList();
/*  431 */     this._root.findInSphere(center, radius, list);
/*  432 */     return list.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findNearest(float[] point) {
/*  441 */     if (isEmpty())
/*  442 */       return null; 
/*  443 */     return findNearest(1, point)[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] findNearest(int k, float[] point) {
/*  453 */     Check.argument((point.length == this._ndim), "point.length equals tree ndim");
/*  454 */     Nearest nearest = new Nearest(k, point);
/*  455 */     this._root.findNearest(nearest);
/*  456 */     return nearest.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getLeafArea() {
/*  464 */     return this._root.areaLeaf();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getLeafVolume() {
/*  472 */     return this._root.volumeLeaf();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dump() {
/*  480 */     this._root.dump(this._root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() {
/*  488 */     this._root.validate();
/*      */   }
/*      */ 
/*      */   
/*      */   private static class DefaultBoxer
/*      */     implements Boxer
/*      */   {
/*      */     private DefaultBoxer() {}
/*      */ 
/*      */     
/*      */     public final void getBounds(Object object, float[] min, float[] max) {
/*  499 */       ((RTree.Boxed)object).getBounds(min, max);
/*      */     }
/*      */     public final float getDistanceSquared(Object object, float[] point) {
/*  502 */       return ((RTree.Boxed)object).getDistanceSquared(point);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class Node
/*      */   {
/*      */     private static final float INFINITY = 3.4028235E38F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private float[] _min;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private float[] _max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Node _parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _level;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _nbox;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object[] _boxs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int level() {
/*      */       return this._level;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isLeaf() {
/*      */       return (this._level == 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int size() {
/*      */       return this._nbox;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void add(Object box) {
/*      */       if (this._nbox < RTree.this._nmax) {
/*      */         append(box);
/*      */         expandUp(box);
/*      */       } else {
/*      */         Node nodeNew = split(box);
/*      */         updateUp();
/*      */         if (this._parent == null) {
/*      */           RTree.this._root = this._parent = new Node(this._level + 1);
/*      */           this._parent.add(this);
/*      */         } 
/*      */         this._parent.add(nodeNew);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void remove(Object box, ArrayList<Object> orphans) {
/*      */       int ibox = indexOf(box);
/*      */       assert ibox >= 0 : "box is a child of this node";
/*      */       int jbox;
/*      */       for (jbox = ibox + 1; jbox < this._nbox; jbox++) {
/*      */         this._boxs[jbox - 1] = this._boxs[jbox];
/*      */       }
/*      */       this._nbox--;
/*      */       if (this._nbox >= RTree.this._nmin || this._parent == null) {
/*      */         updateUp();
/*      */       } else {
/*      */         if (orphans == null) {
/*      */           orphans = new ArrayList();
/*      */         }
/*      */         for (jbox = 0; jbox < this._nbox; jbox++) {
/*      */           orphans.add(this._boxs[jbox]);
/*      */         }
/*      */         this._nbox = 0;
/*      */         this._parent.remove(this, orphans);
/*      */         int norphan = orphans.size();
/*      */         for (int iorphan = 0; iorphan < norphan; iorphan++) {
/*      */           Object orphan = orphans.get(iorphan);
/*      */           Node parent = RTree.this._root.chooseNodeFor(orphan);
/*      */           parent.add(orphan);
/*      */         } 
/*      */         orphans.clear();
/*      */       } 
/*      */       if (RTree.this._root._nbox == 1 && RTree.this._root._level > 1) {
/*      */         RTree.this._root = (Node)RTree.this._root._boxs[0];
/*      */         RTree.this._root._parent = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void findOverlapping(float[] min, float[] max, ArrayList<Object> list) {
/*      */       for (int ibox = 0; ibox < this._nbox; ibox++) {
/*      */         Object boxi = this._boxs[ibox];
/*      */         if (overlaps(boxi, min, max)) {
/*      */           if (isLeaf()) {
/*      */             list.add(boxi);
/*      */           } else {
/*      */             ((Node)boxi).findOverlapping(min, max, list);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void findInSphere(float[] center, float radius, ArrayList<Object> list) {
/*      */       float ss = radius * radius;
/*      */       for (int ibox = 0; ibox < this._nbox; ibox++) {
/*      */         Object boxi = this._boxs[ibox];
/*      */         float ds = distanceSquared(boxi, center);
/*      */         if (ds <= ss) {
/*      */           if (isLeaf()) {
/*      */             list.add(boxi);
/*      */           } else {
/*      */             ((Node)boxi).findInSphere(center, radius, list);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Node(int level) {
/*  936 */       this._min = new float[RTree.this._ndim];
/*  937 */       this._max = new float[RTree.this._ndim];
/*      */ 
/*      */ 
/*      */       
/*  941 */       this._boxs = new Object[RTree.this._nmax]; this._level = level; for (int idim = 0; idim < RTree.this._ndim; idim++) { this._min[idim] = Float.MAX_VALUE; this._max[idim] = -3.4028235E38F; } 
/*      */     } Node chooseNodeFor(Object box) { int level = 1 + level(box); assert this._level >= level : "level of this node exceeds level of box"; if (this._level == level)
/*      */         return this;  Node node = null; float dmin = Float.MAX_VALUE; float vmin = Float.MAX_VALUE; for (int ibox = 0; ibox < this._nbox; ibox++) { Node nodei = (Node)this._boxs[ibox]; float d = nodei.volumeDelta(box); if (d <= dmin) { float v = nodei.volume(); if (d < dmin || v < vmin) { node = nodei; dmin = d; vmin = v; }  }  }  return node.chooseNodeFor(box); } Node findLeafWith(Object box) { if (isLeaf()) { for (int ibox = 0; ibox < this._nbox; ibox++) { if (this._boxs[ibox].equals(box))
/*      */             return this;  }  } else { for (int ibox = 0; ibox < this._nbox; ibox++) { Node nodei = (Node)this._boxs[ibox]; if (nodei.overlaps(box)) { Node node = nodei.findLeafWith(box); if (node != null)
/*      */               return node;  }  }  }
/*      */        return null; }
/*  947 */     private boolean overlaps(Object box) { RTree.this.loadB(box);
/*  948 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/*  949 */         if (this._min[idim] > RTree.this._bmax[idim] || this._max[idim] < RTree.this._bmin[idim])
/*  950 */           return false; 
/*      */       } 
/*  952 */       return true; }
/*      */     void findNearest(RTree.Nearest nearest) { if (isLeaf()) { for (int ibox = 0; ibox < this._nbox; ibox++)
/*      */           nearest.update(this._boxs[ibox]);  } else { ArrayList<RTree.BoxDistance> list = new ArrayList<RTree.BoxDistance>(this._nbox); int ibox; for (ibox = 0; ibox < this._nbox; ibox++) { Object box = this._boxs[ibox]; float distance = distanceSquared(box, nearest.point()); list.add(new RTree.BoxDistance(box, distance)); }  Collections.sort(list); for (ibox = 0; ibox < this._nbox; ibox++) { RTree.BoxDistance bd = list.get(ibox); if (bd.distance < nearest.cutoff())
/*      */             ((Node)bd.box).findNearest(nearest);  }
/*      */          }
/*      */        }
/*      */     float distanceSquared(float[] point) { float sum = 0.0F; for (int idim = 0; idim < RTree.this._ndim; idim++) { float p = point[idim]; float s = this._min[idim]; float t = this._max[idim]; float d = (p < s) ? (p - s) : ((p > t) ? (p - t) : 0.0F); sum += d * d; }
/*  959 */        return sum; } private boolean overlaps(Object box, float[] min, float[] max) { RTree.this.loadB(box);
/*  960 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/*  961 */         if (RTree.this._bmin[idim] > max[idim] || RTree.this._bmax[idim] < min[idim])
/*  962 */           return false; 
/*      */       } 
/*  964 */       return true; }
/*      */     float distanceSquared(Object box, float[] point) { if (box instanceof Node)
/*      */         return ((Node)box).distanceSquared(point);  return RTree.this._boxer.getDistanceSquared(box, point); }
/*      */     int indexOf(Object box) { if (box instanceof Node) { for (int ibox = 0; ibox < this._nbox; ibox++) { if (box == this._boxs[ibox])
/*      */             return ibox;  }  } else { for (int ibox = 0; ibox < this._nbox; ibox++) { if (box.equals(this._boxs[ibox]))
/*      */             return ibox;  }  }  return -1; }
/*      */     int level(Object box) { return (box instanceof Node) ? ((Node)box)._level : 0; }
/*  971 */     float volumeLeaf() { float volume = 0.0F; for (int ibox = 0; ibox < this._nbox; ibox++) { Object box = this._boxs[ibox]; if (box instanceof Node) { Node node = (Node)box; if (node.isLeaf()) { volume += volume(box); } else { volume += node.volumeLeaf(); }  }  }  return volume; } private float volume() { float v = 1.0F;
/*  972 */       for (int idim = 0; idim < RTree.this._ndim; idim++)
/*  973 */         v *= this._max[idim] - this._min[idim]; 
/*  974 */       return v; } float areaLeaf() { float area = 0.0F; for (int ibox = 0; ibox < this._nbox; ibox++) { Object box = this._boxs[ibox]; if (box instanceof Node) { Node node = (Node)box; if (node.isLeaf()) {
/*      */             area += area(box);
/*      */           } else {
/*      */             area += node.areaLeaf();
/*      */           }  }
/*      */          }
/*      */        return area; }
/*  981 */     private float volume(Object box) { RTree.this.loadB(box);
/*  982 */       float v = 1.0F;
/*  983 */       for (int idim = 0; idim < RTree.this._ndim; idim++)
/*  984 */         v *= RTree.this._bmax[idim] - RTree.this._bmin[idim]; 
/*  985 */       return v; } void dump(Object box) { int indent = 2 * (level(RTree.this._root) - level(box)); StringBuffer sb = new StringBuffer(indent); for (int i = 0; i < indent; i++)
/*      */         sb.append(' ');  System.out.println(sb.toString() + box); if (box instanceof Node) { Node node = (Node)box; int nbox = node._nbox; Object[] boxs = node._boxs; for (int ibox = 0; ibox < nbox; ibox++)
/*      */           dump(boxs[ibox]);  }  }
/*      */     void validate() { assert this._parent != null || RTree.this._root == this : "node without parent is root"; if (RTree.this._root != this) { assert this._nbox >= RTree.this._nmin : "_nbox>=_nmin"; assert this._nbox <= RTree.this._nmax : "_nbox<=_nmin"; } else if (isLeaf()) { assert this._nbox >= 0 : "_nbox>=0"; } else { assert this._nbox >= 2 : "_nbox>=2"; }  assert this._nbox <= RTree.this._nmax : "_nbox<=_nmin"; Node tmp = new Node(0); for (int ibox = 0; ibox < this._nbox; ibox++) { if (!isLeaf()) { Node node = (Node)this._boxs[ibox]; assert node._parent == this : "node._parent==this"; assert node._level == this._level - 1 : "node._level==_level-1"; node.validate(); }
/*      */          tmp.expand(this._boxs[ibox]); }
/*      */        for (int idim = 0; idim < RTree.this._ndim; idim++) { assert this._min[idim] == tmp._min[idim] : "minimum bounds are correct"; assert this._max[idim] == tmp._max[idim] : "maximum bounds are correct"; }
/*      */        }
/*  992 */     private float area(Object box) { float v = volume(box);
/*  993 */       RTree.this.loadB(box);
/*  994 */       float area = 0.0F;
/*  995 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/*  996 */         float d = RTree.this._bmax[idim] - RTree.this._bmin[idim];
/*  997 */         area += 2.0F * v / d;
/*      */       } 
/*  999 */       return area; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private float volumeDelta(Object box) {
/* 1006 */       RTree.this.loadB(box);
/* 1007 */       float vnew = 1.0F;
/* 1008 */       float vold = 1.0F;
/* 1009 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/* 1010 */         float amin = this._min[idim];
/* 1011 */         float amax = this._max[idim];
/* 1012 */         vold *= amax - amin;
/* 1013 */         float bmin = RTree.this._bmin[idim];
/* 1014 */         float bmax = RTree.this._bmax[idim];
/* 1015 */         if (bmin < amin)
/* 1016 */           amin = bmin; 
/* 1017 */         if (bmax > amax)
/* 1018 */           amax = bmax; 
/* 1019 */         vnew *= amax - amin;
/*      */       } 
/* 1021 */       return vnew - vold;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private float volumeDelta(Object abox, Object bbox) {
/* 1028 */       RTree.this.loadA(abox);
/* 1029 */       RTree.this.loadB(bbox);
/* 1030 */       float vnew = 1.0F;
/* 1031 */       float vold = 1.0F;
/* 1032 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/* 1033 */         float amin = RTree.this._amin[idim];
/* 1034 */         float amax = RTree.this._amax[idim];
/* 1035 */         vold *= amax - amin;
/* 1036 */         float bmin = RTree.this._bmin[idim];
/* 1037 */         float bmax = RTree.this._bmax[idim];
/* 1038 */         if (bmin < amin)
/* 1039 */           amin = bmin; 
/* 1040 */         if (bmax > amax)
/* 1041 */           amax = bmax; 
/* 1042 */         vnew *= amax - amin;
/*      */       } 
/* 1044 */       return vnew - vold;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void append(Object box) {
/* 1053 */       this._boxs[this._nbox++] = box;
/* 1054 */       if (box instanceof Node) {
/* 1055 */         ((Node)box)._parent = this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean expand(Object box) {
/* 1064 */       RTree.this.loadB(box);
/* 1065 */       boolean changed = false;
/* 1066 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/* 1067 */         if (RTree.this._bmin[idim] < this._min[idim]) {
/* 1068 */           this._min[idim] = RTree.this._bmin[idim];
/* 1069 */           changed = true;
/*      */         } 
/* 1071 */         if (RTree.this._bmax[idim] > this._max[idim]) {
/* 1072 */           this._max[idim] = RTree.this._bmax[idim];
/* 1073 */           changed = true;
/*      */         } 
/*      */       } 
/* 1076 */       return changed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean update() {
/* 1084 */       for (int i = 0; i < RTree.this._ndim; i++) {
/* 1085 */         RTree.this._smin[i] = this._min[i];
/* 1086 */         RTree.this._smax[i] = this._max[i];
/* 1087 */         this._min[i] = Float.MAX_VALUE;
/* 1088 */         this._max[i] = -3.4028235E38F;
/*      */       } 
/* 1090 */       for (int ibox = 0; ibox < this._nbox; ibox++)
/* 1091 */         expand(this._boxs[ibox]); 
/* 1092 */       for (int idim = 0; idim < RTree.this._ndim; idim++) {
/* 1093 */         if (this._min[idim] != RTree.this._smin[idim] || this._max[idim] != RTree.this._smax[idim])
/* 1094 */           return true; 
/*      */       } 
/* 1096 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void expandUp(Object box) {
/* 1106 */       if (expand(box) && this._parent != null) {
/* 1107 */         this._parent.expandUp(this);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateUp() {
/* 1116 */       if (update() && this._parent != null) {
/* 1117 */         this._parent.updateUp();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Node split(Object box) {
/* 1132 */       int nbox = this._nbox + 1;
/* 1133 */       Object[] boxs = new Object[nbox];
/* 1134 */       for (int ibox = 0; ibox < this._nbox; ibox++)
/* 1135 */         boxs[ibox] = this._boxs[ibox]; 
/* 1136 */       boxs[this._nbox] = box;
/* 1137 */       this._nbox = 0;
/*      */ 
/*      */       
/* 1140 */       Node node1 = this;
/* 1141 */       Node node2 = new Node(this._level);
/*      */ 
/*      */       
/* 1144 */       float dmax = -3.4028235E38F;
/* 1145 */       int imax = -1;
/* 1146 */       int jmax = -1; int i;
/* 1147 */       for (i = 0; i < nbox; i++) {
/* 1148 */         Object bbox = boxs[i];
/* 1149 */         float bvol = volume(bbox);
/* 1150 */         for (int jbox = i + 1; jbox < nbox; jbox++) {
/* 1151 */           Object abox = boxs[jbox];
/* 1152 */           float dbox = volumeDelta(abox, bbox) - bvol;
/* 1153 */           if (dbox > dmax) {
/* 1154 */             dmax = dbox;
/* 1155 */             imax = i;
/* 1156 */             jmax = jbox;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1164 */       node1.append(boxs[imax]);
/* 1165 */       node2.append(boxs[jmax]);
/* 1166 */       boxs[imax] = null;
/* 1167 */       boxs[jmax] = null;
/*      */ 
/*      */       
/* 1170 */       for (i = 2; i < nbox; i++) {
/*      */ 
/*      */         
/* 1173 */         int kbox = -1;
/*      */ 
/*      */         
/* 1176 */         Node nodek = null;
/*      */ 
/*      */         
/* 1179 */         int nsmall = RTree.this._nmin - nbox - i;
/* 1180 */         if (nsmall == node1.size()) {
/* 1181 */           nodek = node1;
/* 1182 */         } else if (nsmall == node2.size()) {
/* 1183 */           nodek = node2;
/*      */         } 
/*      */ 
/*      */         
/* 1187 */         if (nodek != null) {
/* 1188 */           for (int jbox = 0; jbox < nbox && kbox < 0; jbox++) {
/* 1189 */             if (boxs[jbox] != null) {
/* 1190 */               kbox = jbox;
/*      */             }
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1197 */           dmax = -3.4028235E38F;
/* 1198 */           for (int jbox = 0; jbox < nbox; jbox++) {
/* 1199 */             Object boxj = boxs[jbox];
/* 1200 */             if (boxj != null) {
/* 1201 */               float d1 = node1.volumeDelta(boxj);
/* 1202 */               float d2 = node2.volumeDelta(boxj);
/* 1203 */               float dbox = (d1 >= d2) ? (d1 - d2) : (d2 - d1);
/* 1204 */               if (dbox > dmax) {
/* 1205 */                 dmax = dbox;
/* 1206 */                 kbox = jbox;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1213 */           float delta1 = node1.volumeDelta(boxs[kbox]);
/* 1214 */           float delta2 = node2.volumeDelta(boxs[kbox]);
/* 1215 */           if (delta1 == delta2) {
/* 1216 */             float volume1 = node1.volume();
/* 1217 */             float volume2 = node2.volume();
/* 1218 */             if (volume1 == volume2) {
/* 1219 */               int size1 = node1.size();
/* 1220 */               int size2 = node1.size();
/* 1221 */               nodek = (size1 < size2) ? node1 : node2;
/*      */             } else {
/* 1223 */               nodek = (volume1 < volume2) ? node1 : node2;
/*      */             } 
/*      */           } else {
/* 1226 */             nodek = (delta1 < delta2) ? node1 : node2;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1231 */         nodek.append(boxs[kbox]);
/* 1232 */         boxs[kbox] = null;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1237 */       node2.update();
/* 1238 */       return node2;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class Nearest
/*      */   {
/*      */     private int _k;
/*      */     private float[] _point;
/*      */     private TreeSet<RTree.BoxDistance> _set;
/*      */     private boolean _full;
/*      */     private float _cutoff;
/*      */     
/*      */     Nearest(int k, float[] point) {
/* 1252 */       this._k = k;
/* 1253 */       this._point = point;
/* 1254 */       this._set = new TreeSet<RTree.BoxDistance>();
/* 1255 */       this._full = false;
/* 1256 */       this._cutoff = Float.MAX_VALUE;
/*      */     }
/*      */     void update(Object box) {
/* 1259 */       float d = RTree.this._boxer.getDistanceSquared(box, this._point);
/* 1260 */       if (d < this._cutoff) {
/* 1261 */         RTree.BoxDistance bd = new RTree.BoxDistance(box, d);
/* 1262 */         if (this._full)
/* 1263 */           this._set.remove(this._set.last()); 
/* 1264 */         this._set.add(bd);
/* 1265 */         this._full = (this._full || this._k == this._set.size());
/* 1266 */         if (this._full)
/* 1267 */           this._cutoff = ((RTree.BoxDistance)this._set.last()).distance; 
/*      */       } 
/*      */     }
/*      */     float[] point() {
/* 1271 */       return this._point;
/*      */     }
/*      */     float cutoff() {
/* 1274 */       return this._cutoff;
/*      */     }
/*      */     Object[] toArray() {
/* 1277 */       Object[] boxs = new Object[this._set.size()];
/* 1278 */       Iterator<RTree.BoxDistance> i = this._set.iterator();
/* 1279 */       for (int ibox = 0; i.hasNext(); ibox++)
/* 1280 */         boxs[ibox] = ((RTree.BoxDistance)i.next()).box; 
/* 1281 */       return boxs;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class BoxDistance
/*      */     implements Comparable<BoxDistance>
/*      */   {
/*      */     Object box;
/*      */ 
/*      */     
/*      */     float distance;
/*      */ 
/*      */     
/*      */     BoxDistance(Object box, float distance) {
/* 1297 */       this.box = box;
/* 1298 */       this.distance = distance;
/*      */     }
/*      */     public int compareTo(BoxDistance bd) {
/* 1301 */       if (this.distance < bd.distance)
/* 1302 */         return -1; 
/* 1303 */       if (this.distance > bd.distance) {
/* 1304 */         return 1;
/*      */       }
/* 1306 */       int th = System.identityHashCode(this.box);
/* 1307 */       int oh = System.identityHashCode(bd.box);
/* 1308 */       if (th < oh)
/* 1309 */         return -1; 
/* 1310 */       if (th > oh) {
/* 1311 */         return 1;
/*      */       }
/* 1313 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1318 */       BoxDistance bd = (BoxDistance)o;
/* 1319 */       return (this.box == bd.box && this.distance == bd.distance);
/*      */     } }
/*      */   private class RTreeIterator implements Iterator<Object> { private RTree.Node _leaf; private int _ibox; private Object _next;
/*      */     private int _modIndexExpected;
/*      */     
/*      */     public boolean hasNext() {
/* 1325 */       return (this._next != null);
/*      */     }
/*      */     public Object next() {
/* 1328 */       if (this._next == null)
/* 1329 */         throw new NoSuchElementException(); 
/* 1330 */       if (this._modIndexExpected != RTree.this._modIndex)
/* 1331 */         throw new ConcurrentModificationException(); 
/* 1332 */       Object object = this._next;
/* 1333 */       loadNext();
/* 1334 */       return object;
/*      */     }
/*      */     public void remove() {
/* 1337 */       throw new UnsupportedOperationException();
/*      */     }
/*      */     RTreeIterator() {
/* 1340 */       this._leaf = RTree.this._root;
/* 1341 */       while (!this._leaf.isLeaf())
/* 1342 */         this._leaf = (RTree.Node)this._leaf._boxs[0]; 
/* 1343 */       this._ibox = 0;
/* 1344 */       this._next = (this._ibox < this._leaf._nbox) ? this._leaf._boxs[0] : null;
/* 1345 */       this._modIndexExpected = RTree.this._modIndex;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void loadNext() {
/* 1360 */       this._ibox++;
/* 1361 */       if (this._ibox == this._leaf._nbox) {
/* 1362 */         RTree.Node node = this._leaf;
/* 1363 */         RTree.Node parent = node;
/* 1364 */         while (node == parent && parent != RTree.this._root) {
/* 1365 */           parent = node._parent;
/* 1366 */           int ibox = 1 + parent.indexOf(node);
/* 1367 */           if (ibox < parent._nbox) {
/* 1368 */             node = (RTree.Node)parent._boxs[ibox];
/* 1369 */             while (!node.isLeaf())
/* 1370 */               node = (RTree.Node)node._boxs[0]; 
/* 1371 */             this._leaf = node;
/* 1372 */             this._ibox = 0; continue;
/*      */           } 
/* 1374 */           node = parent;
/*      */         } 
/*      */       } 
/*      */       
/* 1378 */       this._next = (this._ibox < this._leaf._nbox) ? this._leaf._boxs[this._ibox] : null;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadA(Object box) {
/* 1418 */     if (box instanceof Node) {
/* 1419 */       Node node = (Node)box;
/* 1420 */       this._amin = node._min;
/* 1421 */       this._amax = node._max;
/*      */     } else {
/* 1423 */       this._boxer.getBounds(box, this._smin, this._smax);
/* 1424 */       this._amin = this._smin;
/* 1425 */       this._amax = this._smax;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadB(Object box) {
/* 1435 */     if (box instanceof Node) {
/* 1436 */       Node node = (Node)box;
/* 1437 */       this._bmin = node._min;
/* 1438 */       this._bmax = node._max;
/*      */     } else {
/* 1440 */       this._boxer.getBounds(box, this._tmin, this._tmax);
/* 1441 */       this._bmin = this._tmin;
/* 1442 */       this._bmax = this._tmax;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addPacked(int idim, float[][] x, int p, int q, int[] index, Object[] objects) {
/* 1449 */     int kdim = this._ndim - idim;
/*      */ 
/*      */     
/* 1452 */     if (p >= q) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1457 */     if (kdim == 0) {
/*      */       
/* 1459 */       for (int i = p; i < q; i++)
/*      */       {
/* 1461 */         add(objects[index[i]]);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1469 */       int n = index.length;
/* 1470 */       int nsort = q - p;
/* 1471 */       int[] isort = index;
/* 1472 */       float[] xsort = x[idim];
/* 1473 */       if (nsort < n) {
/* 1474 */         isort = new int[nsort];
/* 1475 */         xsort = new float[nsort];
/* 1476 */         float[] xidim = x[idim];
/* 1477 */         for (int jsort = 0; jsort < nsort; jsort++) {
/* 1478 */           isort[jsort] = jsort;
/* 1479 */           xsort[jsort] = xidim[index[p + jsort]];
/*      */         } 
/*      */       } 
/* 1482 */       Array.quickIndexSort(xsort, isort);
/* 1483 */       if (nsort < n) {
/* 1484 */         int jsort; for (jsort = 0; jsort < nsort; jsort++)
/* 1485 */           isort[jsort] = index[p + isort[jsort]]; 
/* 1486 */         for (jsort = 0; jsort < nsort; jsort++) {
/* 1487 */           index[p + jsort] = isort[jsort];
/*      */         }
/*      */       } 
/*      */       
/* 1491 */       int nleaf = 1 + nsort / this._nmax;
/*      */ 
/*      */       
/* 1494 */       int nslab = (int)Math.ceil(Math.pow(nleaf, 1.0D / kdim));
/*      */ 
/*      */       
/* 1497 */       int mslab = (int)Math.ceil(nsort / nslab);
/*      */ 
/*      */       
/*      */       int pslab;
/*      */       
/* 1502 */       for (pslab = p; pslab < q; pslab += mslab) {
/* 1503 */         int qslab = pslab + mslab;
/* 1504 */         if (qslab > q)
/* 1505 */           qslab = q; 
/* 1506 */         if (qslab > pslab)
/* 1507 */           addPacked(idim + 1, x, pslab, qslab, index, objects); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/RTree.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */