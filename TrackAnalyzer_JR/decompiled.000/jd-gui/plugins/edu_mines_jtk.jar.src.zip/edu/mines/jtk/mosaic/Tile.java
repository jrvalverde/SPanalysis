/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tile
/*     */   extends IPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Mosaic _mosaic;
/*     */   private int _irow;
/*     */   private int _icol;
/*     */   private ArrayList<TiledView> _tvs;
/*     */   private Projector _hp;
/*     */   private Projector _vp;
/*     */   private Projector _bhp;
/*     */   private Projector _bvp;
/*     */   private Projector _shp;
/*     */   private Projector _svp;
/*     */   private Transcaler _ts;
/*     */   private DRectangle _vr;
/*     */   
/*     */   public Mosaic getMosaic() {
/*  54 */     return this._mosaic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/*  62 */     return this._irow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnIndex() {
/*  70 */     return this._icol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBestHorizontalProjector(Projector bhp) {
/*  82 */     this._shp = bhp;
/*  83 */     alignProjectors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBestVerticalProjector(Projector bvp) {
/*  95 */     this._svp = bvp;
/*  96 */     alignProjectors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector getHorizontalProjector() {
/* 104 */     return this._hp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector getVerticalProjector() {
/* 112 */     return this._vp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transcaler getTranscaler() {
/* 120 */     return this._ts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addTiledView(TiledView tv) {
/* 131 */     boolean removed = this._tvs.remove(tv);
/* 132 */     this._tvs.add(tv);
/* 133 */     tv.setTile(this);
/* 134 */     alignProjectors();
/* 135 */     return !removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeTiledView(TiledView tv) {
/* 146 */     if (this._tvs.remove(tv)) {
/* 147 */       tv.setTile(null);
/* 148 */       alignProjectors();
/* 149 */       return true;
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countTiledViews() {
/* 159 */     return this._tvs.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TiledView getTiledView(int index) {
/* 168 */     return this._tvs.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<TiledView> getTiledViews() {
/* 176 */     return this._tvs.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DRectangle getViewRectangle() {
/* 186 */     return new DRectangle(this._vr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewRectangle(DRectangle vr) {
/* 196 */     this._mosaic.setViewRect(this, vr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/* 203 */     super.setBounds(x, y, width, height);
/* 204 */     this._ts.setMapping(width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisTop() {
/* 212 */     return this._mosaic.getTileAxisTop(this._icol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisLeft() {
/* 220 */     return this._mosaic.getTileAxisLeft(this._irow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisBottom() {
/* 228 */     return this._mosaic.getTileAxisBottom(this._icol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisRight() {
/* 236 */     return this._mosaic.getTileAxisRight(this._irow);
/*     */   }
/*     */   
/*     */   public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 240 */     g2d = createGraphics(g2d, x, y, w, h);
/*     */ 
/*     */     
/* 243 */     Transcaler tsPanel = this._ts;
/*     */ 
/*     */     
/* 246 */     this._ts = getTranscaler(w, h);
/*     */ 
/*     */     
/* 249 */     for (TiledView tv : this._tvs) {
/* 250 */       Graphics2D gtv = (Graphics2D)g2d.create();
/* 251 */       tv.paint(gtv);
/* 252 */       gtv.dispose();
/*     */     } 
/*     */ 
/*     */     
/* 256 */     this._ts = tsPanel;
/*     */     
/* 258 */     g2d.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 265 */     super.paintComponent(g);
/* 266 */     paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Tile(Mosaic mosaic, int irow, int icol) {
/* 360 */     this._tvs = new ArrayList<TiledView>();
/* 361 */     this._hp = new Projector(0.0D, 1.0D, 0.0D, 1.0D);
/* 362 */     this._vp = new Projector(0.0D, 1.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     this._ts = new Transcaler();
/* 368 */     this._vr = new DRectangle(0.0D, 0.0D, 1.0D, 1.0D); this._mosaic = mosaic;
/*     */     this._irow = irow;
/*     */     this._icol = icol;
/* 371 */     mosaic.add(this); } private void updateBestProjectors() { Projector bhp = null;
/* 372 */     Projector bvp = null;
/* 373 */     int ntv = this._tvs.size();
/* 374 */     if (this._shp == null) {
/* 375 */       int itv = ntv - 1;
/* 376 */       for (; bhp == null && itv >= 0; itv--) {
/* 377 */         TiledView tv = this._tvs.get(itv);
/* 378 */         bhp = tv.getBestHorizontalProjector();
/*     */       } 
/* 380 */       for (; itv >= 0; itv--) {
/* 381 */         TiledView tv = this._tvs.get(itv);
/* 382 */         bhp.merge(tv.getBestHorizontalProjector());
/*     */       } 
/*     */     } 
/* 385 */     if (this._svp == null) {
/* 386 */       int itv = ntv - 1;
/* 387 */       for (; bvp == null && itv >= 0; itv--) {
/* 388 */         TiledView tv = this._tvs.get(itv);
/* 389 */         bvp = tv.getBestVerticalProjector();
/*     */       } 
/* 391 */       for (; itv >= 0; itv--) {
/* 392 */         TiledView tv = this._tvs.get(itv);
/* 393 */         bvp.merge(tv.getBestVerticalProjector());
/*     */       } 
/*     */     } 
/* 396 */     this._bhp = (this._shp != null) ? this._shp : bhp;
/* 397 */     this._bvp = (this._svp != null) ? this._svp : bvp; }
/*     */ 
/*     */   
/*     */   Projector getBestHorizontalProjector() {
/*     */     return this._bhp;
/*     */   }
/*     */   
/*     */   Projector getBestVerticalProjector() {
/*     */     return this._bvp;
/*     */   }
/*     */   
/*     */   void setProjectors(Projector hp, Projector vp) {
/*     */     Check.argument((hp != null), "horizontal projector not null");
/*     */     Check.argument((vp != null), "vertical projector not null");
/*     */     this._hp = hp;
/*     */     this._vp = vp;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   void setHorizontalProjector(Projector hp) {
/*     */     Check.argument((hp != null), "horizontal projector not null");
/*     */     this._hp = hp;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   void setVerticalProjector(Projector vp) {
/*     */     Check.argument((vp != null), "vertical projector not null");
/*     */     this._vp = vp;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   void alignProjectors() {
/*     */     updateBestProjectors();
/*     */     this._mosaic.alignProjectors(this);
/*     */   }
/*     */   
/*     */   void setViewRect(DRectangle vr) {
/*     */     this._vr = new DRectangle(vr);
/*     */     this._vr.x = Math.max(0.0D, Math.min(1.0D, this._vr.x));
/*     */     this._vr.y = Math.max(0.0D, Math.min(1.0D, this._vr.y));
/*     */     this._vr.width = Math.max(0.0D, Math.min(1.0D - this._vr.x, this._vr.width));
/*     */     this._vr.height = Math.max(0.0D, Math.min(1.0D - this._vr.y, this._vr.height));
/*     */     this._ts.setMapping(this._vr.x, this._vr.y, this._vr.x + this._vr.width, this._vr.y + this._vr.height);
/*     */     repaint();
/*     */   }
/*     */   
/*     */   Transcaler getTranscaler(int w, int h) {
/*     */     return new Transcaler(this._vr.x, this._vr.y, this._vr.x + this._vr.width, this._vr.y + this._vr.height, 0, 0, w - 1, h - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/Tile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */