/*     */ package edu.mines.jtk.opt.test;
/*     */ 
/*     */ import edu.mines.jtk.opt.BrentMinFinder;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrentMinFinderTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  22 */     TestSuite suite = new TestSuite(BrentMinFinderTest.class);
/*  23 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testSimple() {
/*  27 */     BrentMinFinder bmf = new BrentMinFinder(new BrentMinFinder.Function() {
/*     */           public double evaluate(double x) {
/*  29 */             return x * (x * x - 2.0D) - 5.0D;
/*     */           }
/*     */         });
/*  32 */     double xmin = bmf.findMin(0.0D, 1.0D, 1.0E-5D);
/*  33 */     trace("xmin=" + xmin);
/*  34 */     assertEquals(0.8165D, xmin, 1.0E-5D);
/*     */   }
/*     */   
/*     */   private void trace(String s) {}
/*     */   
/*     */   abstract class BrentTestFunc
/*     */     implements BrentMinFinder.Function {
/*     */     private int _count;
/*     */     
/*     */     void findMin(double a, double b) {
/*  44 */       this._count = 0;
/*  45 */       BrentMinFinder minFinder = new BrentMinFinder(this);
/*  46 */       double xmin = minFinder.findMin(a, b, 2.220446049250313E-16D);
/*  47 */       double ymin = eval(xmin);
/*  48 */       checkMin(xmin);
/*  49 */       checkFunc(ymin);
/*  50 */       checkCount(this._count);
/*     */     } abstract double eval(double param1Double); abstract void checkMin(double param1Double);
/*     */     public double evaluate(double x) {
/*  53 */       this._count++;
/*  54 */       return eval(x);
/*     */     }
/*     */     
/*     */     abstract void checkFunc(double param1Double);
/*     */     
/*     */     abstract void checkCount(int param1Int);
/*     */   }
/*     */   
/*     */   class MinFunc1 extends BrentTestFunc {
/*     */     double eval(double x) {
/*  64 */       return (MathPlus.pow(x, 2.0D) - 2.0D) * x - 5.0D;
/*     */     }
/*     */     void checkMin(double x) {
/*  67 */       BrentMinFinderTest.assertEqual(x, 0.8164965811D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  70 */       BrentMinFinderTest.assertEqual(y, -6.0887D);
/*     */     }
/*     */     void checkCount(int count) {
/*  73 */       BrentMinFinderTest.assertEqual(count, 11.0D);
/*     */     } }
/*     */   
/*     */   class MinFunc2 extends BrentTestFunc {
/*     */     double eval(double x) {
/*  78 */       return MathPlus.pow((MathPlus.pow(x, 2.0D) - 2.0D) * x - 5.0D, 2.0D);
/*     */     }
/*     */     void checkMin(double x) {
/*  81 */       BrentMinFinderTest.assertEqual(x, 2.094551483D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  84 */       BrentMinFinderTest.assertEqual(y, 2.7186E-16D);
/*     */     }
/*     */     void checkCount(int count) {
/*  87 */       BrentMinFinderTest.assertEqual(count, 13.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   class MinFunc3 extends BrentTestFunc { double eval(double x) {
/*  92 */       return MathPlus.pow(MathPlus.cos(x) - x, 2.0D) - 2.0D;
/*     */     }
/*     */     void checkMin(double x) {
/*  95 */       BrentMinFinderTest.assertEqual(x, 0.7390851269D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  98 */       BrentMinFinderTest.assertEqual(y, -2.0D);
/*     */     }
/*     */     void checkCount(int count) {
/* 101 */       BrentMinFinderTest.assertEqual(count, 13.0D);
/*     */     } }
/*     */   
/*     */   class MinFunc4 extends BrentTestFunc {
/*     */     double eval(double x) {
/* 106 */       return MathPlus.pow(MathPlus.sin(x) - x, 2.0D) + 1.0D;
/*     */     }
/*     */     void checkMin(double x) {
/* 109 */       BrentMinFinderTest.assertEqual(x, -3.12582763E-4D);
/*     */     }
/*     */     void checkFunc(double y) {
/* 112 */       BrentMinFinderTest.assertEqual(y, 1.0D);
/*     */     }
/*     */     void checkCount(int count) {
/* 115 */       BrentMinFinderTest.assertEqual(count, 47.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   public void testMinFinder() {
/* 120 */     MinFunc1 f1 = new MinFunc1();
/* 121 */     f1.findMin(0.0D, 1.0D);
/* 122 */     MinFunc2 f2 = new MinFunc2();
/* 123 */     f2.findMin(2.0D, 3.0D);
/* 124 */     MinFunc3 f3 = new MinFunc3();
/* 125 */     f3.findMin(-1.0D, 3.0D);
/* 126 */     MinFunc4 f4 = new MinFunc4();
/* 127 */     f4.findMin(-1.0D, 3.0D);
/*     */   }
/*     */   
/*     */   private static void assertEqual(double x, double y) {
/* 131 */     assertTrue(x + " = " + y, almostEqual(x, y));
/*     */   }
/*     */   
/*     */   private static boolean almostEqual(double x, double y) {
/* 135 */     double ax = MathPlus.abs(x);
/* 136 */     double ay = MathPlus.abs(y);
/* 137 */     return (MathPlus.abs(x - y) <= 1.0E-4D * MathPlus.max(ax, ay));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/BrentMinFinderTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */