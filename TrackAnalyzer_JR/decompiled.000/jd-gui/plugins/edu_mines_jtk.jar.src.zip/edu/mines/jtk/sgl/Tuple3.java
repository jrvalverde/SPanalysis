/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tuple3
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   
/*    */   public Tuple3() {}
/*    */   
/*    */   public Tuple3(double x, double y, double z) {
/* 44 */     this.x = x;
/* 45 */     this.y = y;
/* 46 */     this.z = z;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Tuple3(Tuple3 t) {
/* 54 */     this.x = t.x;
/* 55 */     this.y = t.y;
/* 56 */     this.z = t.z;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 60 */     if (this == obj)
/* 61 */       return true; 
/* 62 */     if (obj == null || getClass() != obj.getClass())
/* 63 */       return false; 
/* 64 */     Tuple3 that = (Tuple3)obj;
/* 65 */     return (this.x == that.x && this.y == that.y && this.z == that.z);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 69 */     long xbits = Double.doubleToLongBits(this.x);
/* 70 */     long ybits = Double.doubleToLongBits(this.y);
/* 71 */     long zbits = Double.doubleToLongBits(this.z);
/* 72 */     return (int)(xbits ^ xbits >>> 32L ^ ybits ^ ybits >>> 32L ^ zbits ^ zbits >>> 32L);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return "(" + this.x + "," + this.y + "," + this.z + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Tuple3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */