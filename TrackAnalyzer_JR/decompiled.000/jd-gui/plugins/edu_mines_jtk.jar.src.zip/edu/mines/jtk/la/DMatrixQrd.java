/*     */ package edu.mines.jtk.la;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixQrd
/*     */ {
/*     */   int _m;
/*     */   int _n;
/*     */   double[][] _qr;
/*     */   double[] _rdiag;
/*     */   
/*     */   public DMatrixQrd(DMatrix a) {
/*  40 */     Check.argument((a.getM() >= a.getN()), "m >= n");
/*  41 */     int m = this._m = a.getM();
/*  42 */     int n = this._n = a.getN();
/*  43 */     this._qr = a.get();
/*  44 */     this._rdiag = new double[this._n];
/*     */ 
/*     */     
/*  47 */     for (int k = 0; k < n; k++) {
/*     */ 
/*     */       
/*  50 */       double nrm = 0.0D; int i;
/*  51 */       for (i = k; i < m; i++) {
/*  52 */         nrm = Math.hypot(nrm, this._qr[i][k]);
/*     */       }
/*  54 */       if (nrm != 0.0D) {
/*     */ 
/*     */         
/*  57 */         if (this._qr[k][k] < 0.0D)
/*  58 */           nrm = -nrm; 
/*  59 */         for (i = k; i < m; i++)
/*  60 */           this._qr[i][k] = this._qr[i][k] / nrm; 
/*  61 */         this._qr[k][k] = this._qr[k][k] + 1.0D;
/*     */ 
/*     */         
/*  64 */         for (int j = k + 1; j < n; j++) {
/*  65 */           double s = 0.0D; int i1;
/*  66 */           for (i1 = k; i1 < m; i1++)
/*  67 */             s += this._qr[i1][k] * this._qr[i1][j]; 
/*  68 */           s = -s / this._qr[k][k];
/*  69 */           for (i1 = k; i1 < m; i1++)
/*  70 */             this._qr[i1][j] = this._qr[i1][j] + s * this._qr[i1][k]; 
/*     */         } 
/*     */       } 
/*  73 */       this._rdiag[k] = -nrm;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullRank() {
/*  82 */     for (int j = 0; j < this._n; j++) {
/*  83 */       if (this._rdiag[j] == 0.0D)
/*  84 */         return false; 
/*     */     } 
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getQ() {
/*  94 */     double[][] q = new double[this._m][this._n];
/*  95 */     for (int k = this._n - 1; k >= 0; k--) {
/*  96 */       for (int i = 0; i < this._m; i++) {
/*  97 */         q[i][k] = 0.0D;
/*     */       }
/*  99 */       q[k][k] = 1.0D;
/* 100 */       for (int j = k; j < this._n; j++) {
/* 101 */         if (this._qr[k][k] != 0.0D) {
/* 102 */           double s = 0.0D; int m;
/* 103 */           for (m = k; m < this._m; m++) {
/* 104 */             s += this._qr[m][k] * q[m][j];
/*     */           }
/* 106 */           s = -s / this._qr[k][k];
/* 107 */           for (m = k; m < this._m; m++) {
/* 108 */             q[m][j] = q[m][j] + s * this._qr[m][k];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 113 */     return new DMatrix(this._m, this._n, q);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getR() {
/* 121 */     double[][] r = new double[this._n][this._n];
/* 122 */     for (int i = 0; i < this._n; i++) {
/* 123 */       r[i][i] = this._rdiag[i];
/* 124 */       for (int j = i + 1; j < this._n; j++) {
/* 125 */         r[i][j] = this._qr[i][j];
/*     */       }
/*     */     } 
/* 128 */     return new DMatrix(this._n, this._n, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix solve(DMatrix b) {
/* 141 */     Check.argument((b.getM() == this._m), "A and B have the same number of rows");
/* 142 */     Check.state(isFullRank(), "A is of full rank");
/*     */ 
/*     */     
/* 145 */     int nx = b.getN();
/* 146 */     double[][] x = b.get();
/*     */     
/*     */     int k;
/* 149 */     for (k = 0; k < this._n; k++) {
/* 150 */       for (int j = 0; j < nx; j++) {
/* 151 */         double s = 0.0D; int i;
/* 152 */         for (i = k; i < this._m; i++) {
/* 153 */           s += this._qr[i][k] * x[i][j];
/*     */         }
/* 155 */         s = -s / this._qr[k][k];
/* 156 */         for (i = k; i < this._m; i++) {
/* 157 */           x[i][j] = x[i][j] + s * this._qr[i][k];
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 163 */     for (k = this._n - 1; k >= 0; k--) {
/* 164 */       for (int j = 0; j < nx; j++)
/* 165 */         x[k][j] = x[k][j] / this._rdiag[k]; 
/* 166 */       for (int i = 0; i < k; i++) {
/* 167 */         for (int m = 0; m < nx; m++) {
/* 168 */           x[i][m] = x[i][m] - x[k][m] * this._qr[i][k];
/*     */         }
/*     */       } 
/*     */     } 
/* 172 */     return (new DMatrix(this._m, nx, x)).get(0, this._n - 1, (int[])null);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/DMatrixQrd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */