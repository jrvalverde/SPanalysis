/*    */ package edu.mines.jtk.ogl.test;
/*    */ 
/*    */ import edu.mines.jtk.ogl.Gl;
/*    */ import edu.mines.jtk.ogl.GlCanvas;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Texture
/*    */ {
/* 22 */   private static GlCanvas canvas = new GlCanvas()
/*    */     {
/*    */ 
/*    */       
/* 26 */       private final int N = 64;
/* 27 */       private final ByteBuffer _checkImage = ByteBuffer.allocateDirect(16384);
/*    */ 
/*    */ 
/*    */       
/* 31 */       private int[] _texName = new int[1];
/*    */       private void makeCheckImage() {
/* 33 */         for (int i = 0; i < 64; i++) {
/* 34 */           for (int j = 0; j < 64; j++) {
/* 35 */             int index = (64 * i + j) * 4;
/* 36 */             int c = ((((((i & 0x8) == 0) ? 1 : 0) ^ (((j & 0x8) == 0) ? 1 : 0)) != 0) ? 1 : 0) * 255;
/* 37 */             byte b = (byte)c;
/* 38 */             this._checkImage.put(index, b);
/* 39 */             this._checkImage.put(index + 1, b);
/* 40 */             this._checkImage.put(index + 2, b);
/* 41 */             this._checkImage.put(index + 3, (byte)-1);
/*    */           } 
/*    */         } 
/*    */       }
/*    */       public void glInit() {
/* 46 */         makeCheckImage();
/* 47 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 48 */         Gl.glPixelStorei(3317, 1);
/* 49 */         Gl.glGenTextures(1, this._texName, 0);
/* 50 */         Gl.glBindTexture(3553, this._texName[0]);
/* 51 */         Gl.glTexParameteri(3553, 10242, 10497);
/* 52 */         Gl.glTexParameteri(3553, 10243, 10497);
/* 53 */         Gl.glTexParameteri(3553, 10240, 9728);
/* 54 */         Gl.glTexParameteri(3553, 10241, 9728);
/* 55 */         Gl.glTexImage2D(3553, 0, 6408, 64, 64, 0, 6408, 5121, this._checkImage);
/*    */       }
/*    */       
/*    */       public void glResize(int x, int y, int width, int height) {
/* 59 */         Gl.glViewport(0, 0, width, height);
/* 60 */         Gl.glMatrixMode(5889);
/* 61 */         Gl.glLoadIdentity();
/* 62 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/*    */       }
/*    */       public void glPaint() {
/* 65 */         Gl.glClear(16640);
/* 66 */         Gl.glEnable(3553);
/* 67 */         Gl.glTexEnvf(8960, 8704, 7681.0F);
/* 68 */         Gl.glBindTexture(3553, this._texName[0]);
/* 69 */         Gl.glBegin(9);
/* 70 */         Gl.glTexCoord2f(0.0F, 0.0F); Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 71 */         Gl.glTexCoord2f(1.0F, 0.0F); Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 72 */         Gl.glTexCoord2f(1.0F, 1.0F); Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 73 */         Gl.glTexCoord2f(0.0F, 1.0F); Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 74 */         Gl.glEnd();
/* 75 */         Gl.glDisable(3553);
/* 76 */         Gl.glFlush();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 80 */     TestSimple.run(args, canvas);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/Texture.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */