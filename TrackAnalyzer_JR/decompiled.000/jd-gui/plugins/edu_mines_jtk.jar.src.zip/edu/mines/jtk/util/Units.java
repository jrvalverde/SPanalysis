/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Units
/*     */   implements Cloneable
/*     */ {
/*     */   private static final int NPOWERS = 16;
/*     */   
/*     */   public Units(String definition) throws UnitsFormatException {
/*  68 */     Units units = unitsFromDefinition(definition);
/*  69 */     this._scale = units._scale;
/*  70 */     this._shift = units._shift;
/*  71 */     for (int i = 0; i < this._power.length; i++) {
/*  72 */       this._power[i] = units._power[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  82 */       Units units = (Units)super.clone();
/*  83 */       units._power = (byte[])this._power.clone();
/*  84 */       return units;
/*  85 */     } catch (CloneNotSupportedException e) {
/*  86 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  96 */     if (object instanceof Units) return equals((Units)object); 
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Units units) {
/* 106 */     if (this._scale != units._scale) return false; 
/* 107 */     if (this._shift != units._shift) return false; 
/* 108 */     for (int i = 0; i < this._power.length; i++) {
/* 109 */       if (this._power[i] != units._power[i]) return false; 
/*     */     } 
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float toSI(float value) {
/* 122 */     return (float)((value - this._shift) * this._scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double toSI(double value) {
/* 133 */     return (value - this._shift) * this._scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float fromSI(float value) {
/* 144 */     return (float)(this._shift + value / this._scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double fromSI(double value) {
/* 155 */     return this._shift + value / this._scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float floatShiftFrom(Units units) {
/* 166 */     return (float)doubleShiftFrom(units);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double doubleShiftFrom(Units units) {
/* 177 */     Check.argument(units.haveDimensionsOf(this), "same dimensions");
/* 178 */     return fromSI(units.toSI(0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float floatScaleFrom(Units units) {
/* 189 */     return (float)doubleScaleFrom(units);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double doubleScaleFrom(Units units) {
/* 200 */     Check.argument(units.haveDimensionsOf(this), "same dimensions");
/* 201 */     return fromSI(units.toSI(1.0D)) - doubleShiftFrom(units);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean haveDimensions() {
/* 209 */     for (int i = 0; i < this._power.length; i++) {
/* 210 */       if (this._power[i] != 0) return true; 
/*     */     } 
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean haveDimensionsOf(Units units) {
/* 221 */     for (int i = 0; i < this._power.length; i++) {
/* 222 */       if (this._power[i] != units._power[i]) return false; 
/*     */     } 
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String standardDefinition() {
/* 233 */     String sd = "";
/* 234 */     boolean appending = false;
/* 235 */     if (this._scale != 1.0D) {
/* 236 */       sd = sd + this._scale;
/* 237 */       appending = true;
/*     */     } 
/* 239 */     for (int i = 0; i < _nbase; i++) {
/* 240 */       if (this._power[i] != 0) {
/* 241 */         if (appending) sd = sd + " "; 
/* 242 */         sd = sd + _bases[i];
/* 243 */         if (this._power[i] != 1) sd = sd + "^" + this._power[i]; 
/* 244 */         appending = true;
/*     */       } 
/*     */     } 
/* 247 */     if (this._shift != 0.0D) {
/* 248 */       double abs_shift = (this._shift > 0.0D) ? this._shift : -this._shift;
/* 249 */       if (appending) sd = sd + " "; 
/* 250 */       sd = sd + ((this._shift > 0.0D) ? "+ " : "- ");
/* 251 */       sd = sd + abs_shift;
/*     */     } 
/* 253 */     return sd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units add(Units units, double s) {
/* 263 */     return ((Units)units.clone()).shift(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units sub(Units units, double s) {
/* 273 */     return ((Units)units.clone()).shift(-s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units mul(Units units, double s) {
/* 283 */     return ((Units)units.clone()).scale(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units div(Units units, double s) {
/* 293 */     return ((Units)units.clone()).scale(1.0D / s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units mul(Units units1, Units units2) {
/* 303 */     return ((Units)units1.clone()).mul(units2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units div(Units units1, Units units2) {
/* 313 */     return ((Units)units1.clone()).div(units2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units inv(Units units) {
/* 322 */     return ((Units)units.clone()).inv();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Units pow(Units units, int p) {
/* 332 */     return ((Units)units.clone()).pow(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean define(String name, boolean plural, String definition) throws UnitsFormatException {
/* 368 */     return addDefinition(name, plural, definition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean isValidDefinition(String definition) {
/*     */     try {
/* 380 */       unitsFromDefinition(definition);
/* 381 */     } catch (UnitsFormatException e) {
/* 382 */       return false;
/*     */     } 
/* 384 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean isDefined(String name) {
/* 393 */     return _table.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Units scale(double s) {
/* 401 */     this._scale *= s;
/* 402 */     this._shift /= s;
/* 403 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Units shift(double s) {
/* 408 */     this._shift += s;
/* 409 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Units mul(Units u) {
/* 414 */     this._shift = (this._shift != 0.0D) ? (this._shift / u._scale) : (u._shift / this._scale);
/* 415 */     this._scale *= u._scale;
/* 416 */     for (int i = 0; i < this._power.length; i++) {
/* 417 */       this._power[i] = (byte)(this._power[i] + u._power[i]);
/*     */     }
/* 419 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Units div(Units u) {
/* 424 */     this._shift *= u._scale;
/* 425 */     this._scale /= u._scale;
/* 426 */     for (int i = 0; i < this._power.length; i++) {
/* 427 */       this._power[i] = (byte)(this._power[i] - u._power[i]);
/*     */     }
/* 429 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Units inv() {
/* 434 */     this._scale = 1.0D / this._scale;
/* 435 */     this._shift = 0.0D;
/* 436 */     for (int i = 0; i < this._power.length; i++) {
/* 437 */       this._power[i] = (byte)-this._power[i];
/*     */     }
/* 439 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Units pow(int p) {
/* 444 */     this._scale = Math.pow(this._scale, p);
/* 445 */     this._shift = 0.0D;
/* 446 */     for (int i = 0; i < this._power.length; i++) {
/* 447 */       this._power[i] = (byte)(this._power[i] * (byte)p);
/*     */     }
/* 449 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized Units unitsFromName(String name) {
/* 457 */     if (name == null || name.equals("")) return new Units();
/*     */ 
/*     */     
/* 460 */     UnitsTableEntry entry = _table.get(name);
/* 461 */     if (entry != null) {
/* 462 */       return (Units)entry._units.clone();
/*     */     }
/*     */ 
/*     */     
/* 466 */     double factor = 1.0D;
/* 467 */     int index = findPrefix(name);
/* 468 */     boolean prefix = (index >= 0);
/* 469 */     if (prefix) {
/* 470 */       factor = _prefix_factor[index];
/* 471 */       String temp = name.substring(_prefix_string[index].length());
/* 472 */       entry = _table.get(temp);
/* 473 */       if (entry != null) {
/* 474 */         Units units = (Units)entry._units.clone();
/* 475 */         units.scale(factor);
/* 476 */         return units;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 481 */     boolean suffix = (name.length() > 0 && name.charAt(name.length() - 1) == 's');
/* 482 */     if (suffix) {
/* 483 */       name = name.substring(0, name.length() - 1);
/* 484 */       entry = _table.get(name);
/* 485 */       if (entry != null && entry._plural) {
/* 486 */         Units units = (Units)entry._units.clone();
/* 487 */         return units;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 492 */     if (prefix && suffix) {
/* 493 */       name = name.substring(_prefix_string[index].length());
/* 494 */       entry = _table.get(name);
/* 495 */       if (entry != null && entry._plural) {
/* 496 */         Units units = (Units)entry._units.clone();
/* 497 */         units.scale(factor);
/* 498 */         return units;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 503 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class UnitsTableEntry
/*     */   {
/*     */     String _name;
/*     */     
/*     */     boolean _plural;
/*     */     
/*     */     Units _units;
/*     */     
/*     */     UnitsTableEntry(String name, boolean plural, Units units) {
/* 516 */       this._name = null;
/* 517 */       this._plural = false;
/* 518 */       this._units = null;
/*     */       this._name = name;
/*     */       this._plural = plural;
/*     */       this._units = units;
/* 522 */     } } private static Hashtable<String, UnitsTableEntry> _table = null;
/* 523 */   private static String[] _bases = null;
/* 524 */   private static int _nbase = 0;
/* 525 */   private static final String[] _prefix_string = new String[] { "E", "G", "M", "P", "T", "Y", "Z", "a", "atto", "c", "centi", "d", "da", "deca", "deci", "deka", "exa", "f", "femto", "giga", "h", "hecto", "k", "kilo", "m", "mega", "micro", "milli", "n", "nano", "p", "peta", "pico", "tera", "u", "y", "yocto", "yotta", "z", "zepto", "zetta" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 532 */   private static final double[] _prefix_factor = new double[] { 1.0E18D, 1.0E9D, 1000000.0D, 1.0E15D, 1.0E12D, 1.0E24D, 1.0E21D, 1.0E-18D, 1.0E-18D, 0.01D, 0.01D, 0.1D, 10.0D, 10.0D, 0.1D, 10.0D, 1.0E18D, 1.0E-15D, 1.0E-15D, 1.0E9D, 100.0D, 100.0D, 1000.0D, 1000.0D, 0.001D, 1000000.0D, 1.0E-6D, 0.001D, 1.0E-9D, 1.0E-9D, 1.0E-12D, 1.0E15D, 1.0E-12D, 1.0E12D, 1.0E-6D, 1.0E-24D, 1.0E-24D, 1.0E24D, 1.0E-21D, 1.0E-21D, 1.0E21D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 540 */     _table = new Hashtable<String, UnitsTableEntry>();
/* 541 */     _bases = new String[16];
/* 542 */     loadTable();
/*     */   }
/*     */   
/* 545 */   private double _scale = 1.0D;
/* 546 */   private double _shift = 0.0D;
/* 547 */   private byte[] _power = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized Units unitsFromDefinition(String definition) throws UnitsFormatException {
/* 555 */     Units units = unitsFromName(definition);
/* 556 */     if (units != null) return units;
/*     */ 
/*     */     
/*     */     try {
/* 560 */       return UnitsParser.parse(definition);
/* 561 */     } catch (Exception e) {
/* 562 */       throw new UnitsFormatException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findPrefix(String name) {
/* 570 */     if (name.length() < 1) return -1; 
/* 571 */     char name0 = name.charAt(0);
/* 572 */     int length = 0;
/* 573 */     int index = -1;
/* 574 */     for (int i = 0; i < _prefix_string.length; i++) {
/* 575 */       String prefix = _prefix_string[i];
/* 576 */       char prefix0 = prefix.charAt(0);
/* 577 */       if (name0 <= prefix0) {
/* 578 */         if (name0 < prefix0)
/* 579 */           break;  if (name.startsWith(prefix) && length < prefix.length()) {
/* 580 */           length = prefix.length();
/* 581 */           index = i;
/*     */         } 
/*     */       } 
/* 584 */     }  return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized boolean addDefinition(String name, boolean plural, String definition) throws UnitsFormatException {
/* 594 */     if (_table.containsKey(name)) return false;
/*     */ 
/*     */     
/* 597 */     if (definition == null || definition.equals("")) {
/* 598 */       Units units1 = new Units();
/* 599 */       if (_nbase >= units1._power.length - 1) return false; 
/* 600 */       units1._power[_nbase] = (byte)(units1._power[_nbase] + 1);
/* 601 */       _bases[_nbase++] = name;
/* 602 */       _table.put(name, new UnitsTableEntry(name, plural, units1));
/* 603 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 607 */     Units units = unitsFromDefinition(definition);
/*     */ 
/*     */     
/* 610 */     _table.put(name, new UnitsTableEntry(name, plural, units));
/* 611 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized void loadTable() {
/* 616 */     String[] specs = UnitsSpecs.specs;
/* 617 */     for (int i = 0; i < specs.length; i++) {
/* 618 */       String spec = specs[i];
/* 619 */       if (!spec.startsWith("#")) {
/* 620 */         StringTokenizer st = new StringTokenizer(spec);
/* 621 */         if (st.countTokens() >= 2) {
/* 622 */           String name = st.nextToken();
/* 623 */           String plural_str = st.nextToken();
/* 624 */           if (plural_str.equals("S") || plural_str.equals("P")) {
/* 625 */             boolean plural = plural_str.equals("P");
/* 626 */             String definition = st.hasMoreTokens() ? st.nextToken("") : null;
/* 627 */             if (definition != null) {
/* 628 */               int index = definition.indexOf("#");
/* 629 */               if (index >= 0) definition = definition.substring(0, index); 
/* 630 */               definition = definition.trim();
/*     */             } 
/* 632 */             if (definition != null && definition.equals("")) definition = null; 
/*     */             try {
/* 634 */               boolean defined = addDefinition(name, plural, definition);
/* 635 */               if (!defined) {
/* 636 */                 System.err.println("Units.loadTable: failed to define " + name + " = " + definition);
/*     */               }
/*     */             }
/* 639 */             catch (UnitsFormatException e) {
/* 640 */               System.err.println("Units.loadTable: failed to define " + name + " = " + definition + " because " + e.getMessage());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Units() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Units.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */