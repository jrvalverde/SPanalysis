/*     */ package edu.mines.jtk.mosaic.demo;
/*     */ import edu.mines.jtk.awt.Mode;
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import edu.mines.jtk.awt.ModeMenuItem;
/*     */ import edu.mines.jtk.awt.ModeToggleButton;
/*     */ import edu.mines.jtk.dsp.Real1;
/*     */ import edu.mines.jtk.dsp.RecursiveCascadeFilter;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.mosaic.PlotFrame;
/*     */ import edu.mines.jtk.mosaic.PlotPanel;
/*     */ import edu.mines.jtk.mosaic.PointsView;
/*     */ import edu.mines.jtk.mosaic.Projector;
/*     */ import edu.mines.jtk.mosaic.Tile;
/*     */ import edu.mines.jtk.mosaic.TileZoomMode;
/*     */ import edu.mines.jtk.mosaic.Transcaler;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Cdouble;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.awt.Component;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public class PolesAndZeros {
/*     */   private static final int PZP_X = 100;
/*     */   private static final int PZP_Y = 0;
/*     */   private static final int PZP_WIDTH = 400;
/*     */   private static final int PZP_HEIGHT = 440;
/*     */   private static final int RP_X = 500;
/*     */   private static final int RP_Y = 0;
/*     */   private static final int RP_WIDTH = 500;
/*     */   private static final int RP_HEIGHT = 700;
/*     */   private ArrayList<Cdouble> _poles;
/*     */   private ArrayList<Cdouble> _zeros;
/*     */   private PoleZeroPlot _pzp;
/*     */   private ResponsePlot _rp;
/*     */   
/*     */   public static void main(String[] args) {
/*  48 */     SwingUtilities.invokeLater(new Runnable() {
/*     */           public void run() {
/*  50 */             new PolesAndZeros();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PolesAndZeros() {
/*  77 */     this._poles = new ArrayList<Cdouble>(0);
/*  78 */     this._zeros = new ArrayList<Cdouble>(0);
/*  79 */     this._pzp = new PoleZeroPlot();
/*  80 */     this._rp = new ResponsePlot(false);
/*     */   }
/*     */   
/*     */   private void addPole(Cdouble pole) {
/*  84 */     this._poles.add(new Cdouble(pole));
/*  85 */     if (!pole.isReal())
/*  86 */       this._poles.add(pole.conj()); 
/*  87 */     this._pzp.updatePolesView();
/*  88 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private void removePole(Cdouble pole) {
/*  92 */     this._poles.remove(pole);
/*  93 */     if (!pole.isReal())
/*  94 */       this._poles.remove(pole.conj()); 
/*  95 */     this._pzp.updatePolesView();
/*  96 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private void movePole(Cdouble poleOld, Cdouble poleNew) {
/* 100 */     this._poles.remove(poleOld);
/* 101 */     if (!poleOld.isReal())
/* 102 */       this._poles.remove(poleOld.conj()); 
/* 103 */     this._poles.add(poleNew);
/* 104 */     if (!poleNew.isReal())
/* 105 */       this._poles.add(poleNew.conj()); 
/* 106 */     this._pzp.updatePolesView();
/* 107 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private Cdouble getPoleNearest(Cdouble z) {
/* 111 */     Cdouble pmin = null;
/* 112 */     double dmin = 0.0D;
/* 113 */     for (Cdouble p : this._poles) {
/* 114 */       double d = p.minus(z).abs();
/* 115 */       if (pmin == null || d < dmin) {
/* 116 */         pmin = p;
/* 117 */         dmin = d;
/*     */       } 
/*     */     } 
/* 120 */     return pmin;
/*     */   }
/*     */   
/*     */   private void addZero(Cdouble zero) {
/* 124 */     this._zeros.add(new Cdouble(zero));
/* 125 */     if (!zero.isReal())
/* 126 */       this._zeros.add(zero.conj()); 
/* 127 */     this._pzp.updateZerosView();
/* 128 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private void removeZero(Cdouble zero) {
/* 132 */     this._zeros.remove(zero);
/* 133 */     if (!zero.isReal())
/* 134 */       this._zeros.remove(zero.conj()); 
/* 135 */     this._pzp.updateZerosView();
/* 136 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private void moveZero(Cdouble zeroOld, Cdouble zeroNew) {
/* 140 */     this._zeros.remove(zeroOld);
/* 141 */     if (!zeroOld.isReal())
/* 142 */       this._zeros.remove(zeroOld.conj()); 
/* 143 */     this._zeros.add(zeroNew);
/* 144 */     if (!zeroNew.isReal())
/* 145 */       this._zeros.add(zeroNew.conj()); 
/* 146 */     this._pzp.updateZerosView();
/* 147 */     this._rp.updateViews();
/*     */   }
/*     */   
/*     */   private Cdouble getZeroNearest(Cdouble z) {
/* 151 */     Cdouble pmin = null;
/* 152 */     double dmin = 0.0D;
/* 153 */     for (Cdouble p : this._zeros) {
/* 154 */       double d = p.minus(z).abs();
/* 155 */       if (pmin == null || d < dmin) {
/* 156 */         pmin = p;
/* 157 */         dmin = d;
/*     */       } 
/*     */     } 
/* 160 */     return pmin;
/*     */   }
/*     */ 
/*     */   
/*     */   private class PoleZeroPlot
/*     */   {
/*     */     private PlotFrame _plotFrame;
/*     */     
/*     */     private PlotPanel _plotPanel;
/*     */     
/*     */     private PointsView _polesView;
/*     */     
/*     */     private PointsView _zerosView;
/*     */     
/*     */     private PointsView _circleView;
/*     */ 
/*     */     
/*     */     private PoleZeroPlot() {
/* 178 */       this._plotPanel = new PlotPanel();
/* 179 */       this._plotPanel.setTitle("poles and zeros");
/* 180 */       this._plotPanel.setHLabel("real");
/* 181 */       this._plotPanel.setVLabel("imaginary");
/* 182 */       this._plotPanel.setHLimits(-2.0D, 2.0D);
/* 183 */       this._plotPanel.setVLimits(-2.0D, 2.0D);
/*     */ 
/*     */       
/* 186 */       this._plotPanel.addGrid("H0-V0-");
/*     */ 
/*     */       
/* 189 */       float[][] circlePoints = makeCirclePoints();
/* 190 */       this._circleView = this._plotPanel.addPoints(circlePoints[0], circlePoints[1]);
/* 191 */       this._circleView.setLineColor(Color.RED);
/*     */ 
/*     */ 
/*     */       
/* 195 */       updatePolesView();
/* 196 */       updateZerosView();
/*     */ 
/*     */       
/* 199 */       this._plotFrame = new PlotFrame(this._plotPanel);
/* 200 */       TileZoomMode tzm = this._plotFrame.getTileZoomMode();
/*     */ 
/*     */       
/* 203 */       ModeManager mm = this._plotFrame.getModeManager();
/* 204 */       PolesAndZeros.PoleZeroMode pm = new PolesAndZeros.PoleZeroMode(mm, true);
/* 205 */       PolesAndZeros.PoleZeroMode zm = new PolesAndZeros.PoleZeroMode(mm, false);
/*     */ 
/*     */       
/* 208 */       JMenu fileMenu = new JMenu("File");
/* 209 */       fileMenu.setMnemonic('F');
/* 210 */       fileMenu.add(new PolesAndZeros.SaveAsPngAction(this._plotFrame)).setMnemonic('a');
/* 211 */       fileMenu.add(new PolesAndZeros.ExitAction()).setMnemonic('x');
/* 212 */       JMenu modeMenu = new JMenu("Mode");
/* 213 */       modeMenu.setMnemonic('M');
/* 214 */       modeMenu.add((JMenuItem)new ModeMenuItem((Mode)tzm));
/* 215 */       modeMenu.add((JMenuItem)new ModeMenuItem(pm));
/* 216 */       modeMenu.add((JMenuItem)new ModeMenuItem(zm));
/* 217 */       JMenuBar menuBar = new JMenuBar();
/* 218 */       menuBar.add(fileMenu);
/* 219 */       menuBar.add(modeMenu);
/* 220 */       this._plotFrame.setJMenuBar(menuBar);
/*     */ 
/*     */       
/* 223 */       JToolBar toolBar = new JToolBar(1);
/* 224 */       toolBar.setRollover(true);
/* 225 */       toolBar.add((Component)new ModeToggleButton((Mode)tzm));
/* 226 */       toolBar.add((Component)new ModeToggleButton(pm));
/* 227 */       toolBar.add((Component)new ModeToggleButton(zm));
/* 228 */       this._plotFrame.add(toolBar, "West");
/*     */ 
/*     */       
/* 231 */       pm.setActive(true);
/*     */ 
/*     */       
/* 234 */       this._plotFrame.setDefaultCloseOperation(3);
/* 235 */       this._plotFrame.setLocation(100, 0);
/* 236 */       this._plotFrame.setSize(400, 440);
/* 237 */       this._plotFrame.setVisible(true);
/*     */     }
/*     */ 
/*     */     
/*     */     private void updatePolesView() {
/* 242 */       int np = PolesAndZeros.this._poles.size();
/* 243 */       float[] xp = new float[np];
/* 244 */       float[] yp = new float[np];
/* 245 */       for (int ip = 0; ip < np; ip++) {
/* 246 */         Cdouble p = PolesAndZeros.this._poles.get(ip);
/* 247 */         xp[ip] = (float)p.r;
/* 248 */         yp[ip] = (float)p.i;
/*     */       } 
/* 250 */       if (this._polesView == null) {
/* 251 */         this._polesView = this._plotPanel.addPoints(xp, yp);
/* 252 */         this._polesView.setMarkStyle(PointsView.Mark.CROSS);
/* 253 */         this._polesView.setLineStyle(PointsView.Line.NONE);
/*     */       } else {
/* 255 */         this._polesView.set(xp, yp);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void updateZerosView() {
/* 261 */       int nz = PolesAndZeros.this._zeros.size();
/* 262 */       float[] xz = new float[nz];
/* 263 */       float[] yz = new float[nz];
/* 264 */       for (int iz = 0; iz < nz; iz++) {
/* 265 */         Cdouble z = PolesAndZeros.this._zeros.get(iz);
/* 266 */         xz[iz] = (float)z.r;
/* 267 */         yz[iz] = (float)z.i;
/*     */       } 
/* 269 */       if (this._zerosView == null) {
/* 270 */         this._zerosView = this._plotPanel.addPoints(xz, yz);
/* 271 */         this._zerosView.setMarkStyle(PointsView.Mark.HOLLOW_CIRCLE);
/* 272 */         this._zerosView.setLineStyle(PointsView.Line.NONE);
/*     */       } else {
/* 274 */         this._zerosView.set(xz, yz);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private float[][] makeCirclePoints() {
/* 280 */       int nt = 1000;
/* 281 */       double dt = 6.283185307179586D / (nt - 1);
/* 282 */       float[] x = new float[nt];
/* 283 */       float[] y = new float[nt];
/* 284 */       for (int it = 0; it < nt; it++) {
/* 285 */         float t = (float)(it * dt);
/* 286 */         x[it] = MathPlus.cos(t);
/* 287 */         y[it] = MathPlus.sin(t);
/*     */       } 
/* 289 */       return new float[][] { x, y };
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ResponsePlot
/*     */   {
/*     */     private boolean _db;
/*     */     
/*     */     private PlotPanel _plotPanelH;
/*     */     
/*     */     private PlotPanel _plotPanelAP;
/*     */     
/*     */     private PlotFrame _plotFrame;
/*     */     
/*     */     private SequenceView _hView;
/*     */     
/*     */     private PointsView _aView;
/*     */     private PointsView _pView;
/*     */     
/*     */     private ResponsePlot(boolean db) {
/* 310 */       this._db = db;
/*     */ 
/*     */       
/* 313 */       this._plotPanelH = new PlotPanel();
/* 314 */       this._plotPanelH.setHLabel("sample index");
/* 315 */       this._plotPanelH.setVLabel("amplitude");
/* 316 */       this._plotPanelH.setTitle("impulse response");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 323 */       this._plotPanelAP = new PlotPanel(2, 1);
/* 324 */       this._plotPanelAP.setTitle("amplitude and phase response");
/* 325 */       if (this._db) {
/*     */         
/* 327 */         this._plotPanelAP.setVLabel(0, "amplitude (dB)");
/*     */       } else {
/*     */         
/* 330 */         this._plotPanelAP.setVLabel(0, "amplitude");
/*     */       } 
/* 332 */       this._plotPanelAP.setVLimits(1, -0.5D, 0.5D);
/* 333 */       this._plotPanelAP.setVLabel(1, "phase (cycles)");
/* 334 */       this._plotPanelAP.setHLabel("frequency (cycles/sample)");
/*     */ 
/*     */ 
/*     */       
/* 338 */       updateViews();
/*     */ 
/*     */ 
/*     */       
/* 342 */       this._plotFrame = new PlotFrame(this._plotPanelH, this._plotPanelAP, PlotFrame.Split.VERTICAL);
/*     */ 
/*     */ 
/*     */       
/* 346 */       JMenu fileMenu = new JMenu("File");
/* 347 */       fileMenu.setMnemonic('F');
/* 348 */       fileMenu.add(new PolesAndZeros.SaveAsPngAction(this._plotFrame)).setMnemonic('a');
/* 349 */       fileMenu.add(new PolesAndZeros.ExitAction()).setMnemonic('x');
/* 350 */       JMenuBar menuBar = new JMenuBar();
/* 351 */       menuBar.add(fileMenu);
/* 352 */       this._plotFrame.setJMenuBar(menuBar);
/*     */ 
/*     */       
/* 355 */       this._plotFrame.setDefaultCloseOperation(3);
/* 356 */       this._plotFrame.setLocation(500, 0);
/* 357 */       this._plotFrame.setSize(500, 700);
/* 358 */       this._plotFrame.setVisible(true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void updateViews() {
/* 364 */       Real1 h = computeImpulseResponse();
/* 365 */       Real1[] ap = computeAmplitudeAndPhaseResponses();
/* 366 */       Real1 a = ap[0];
/* 367 */       Real1 p = ap[1];
/* 368 */       if (this._hView == null) {
/* 369 */         this._hView = this._plotPanelH.addSequence(h.getSampling(), h.getValues());
/* 370 */         this._aView = this._plotPanelAP.addPoints(0, 0, a.getSampling(), a.getValues());
/* 371 */         this._pView = this._plotPanelAP.addPoints(1, 0, p.getSampling(), p.getValues());
/*     */       } else {
/* 373 */         this._hView.set(h.getSampling(), h.getValues());
/* 374 */         this._aView.set(a.getSampling(), a.getValues());
/* 375 */         this._pView.set(p.getSampling(), p.getValues());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Real1 computeImpulseResponse() {
/* 383 */       int np = PolesAndZeros.this._poles.size();
/* 384 */       int nz = PolesAndZeros.this._zeros.size();
/* 385 */       Cdouble[] poles = new Cdouble[np];
/* 386 */       Cdouble[] zeros = new Cdouble[nz];
/* 387 */       PolesAndZeros.this._poles.toArray((Object[])poles);
/* 388 */       PolesAndZeros.this._zeros.toArray((Object[])zeros);
/*     */ 
/*     */       
/* 391 */       int n = 101;
/* 392 */       float[] h = new float[n];
/*     */ 
/*     */ 
/*     */       
/* 396 */       if (np > 0 || nz > 0) {
/* 397 */         float[] impulse = new float[n];
/* 398 */         impulse[0] = 1.0F;
/* 399 */         RecursiveCascadeFilter f = new RecursiveCascadeFilter(poles, zeros, 1.0D);
/* 400 */         f.applyForward(impulse, h);
/*     */       } else {
/* 402 */         h[0] = 1.0F;
/*     */       } 
/*     */       
/* 405 */       Sampling s = new Sampling(n);
/* 406 */       return new Real1(s, h);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Real1[] computeAmplitudeAndPhaseResponses() {
/* 413 */       int nf = 501;
/* 414 */       double df = 0.5D / (nf - 1);
/* 415 */       double ff = 0.0D;
/* 416 */       Sampling sf = new Sampling(nf, df, ff);
/*     */ 
/*     */       
/* 419 */       float[] af = new float[nf];
/* 420 */       float[] pf = new float[nf];
/*     */ 
/*     */       
/* 423 */       for (int jf = 0; jf < nf; jf++) {
/* 424 */         double f = ff + jf * df;
/* 425 */         Cdouble cone = new Cdouble(1.0D, 0.0D);
/* 426 */         Cdouble zinv = Cdouble.polar(1.0D, -6.283185307179586D * f);
/* 427 */         Cdouble cdouble1 = new Cdouble(1.0D, 0.0D);
/* 428 */         for (Cdouble c : PolesAndZeros.this._zeros)
/* 429 */           cdouble1.timesEquals(cone.minus(c.times(zinv))); 
/* 430 */         Cdouble q = new Cdouble(1.0D, 0.0D);
/* 431 */         for (Cdouble d : PolesAndZeros.this._poles)
/* 432 */           q.timesEquals(cone.minus(d.times(zinv))); 
/* 433 */         Cdouble h = cdouble1.over(q);
/* 434 */         af[jf] = (float)h.abs();
/* 435 */         pf[jf] = (float)h.arg();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 441 */       if (this._db) {
/* 442 */         af = Array.log10(af);
/* 443 */         af = Array.mul(20.0F, af);
/*     */       } 
/* 445 */       Real1 a = new Real1(sf, af);
/*     */ 
/*     */       
/* 448 */       pf = Array.mul(0.15915494F, pf);
/* 449 */       Real1 p = new Real1(sf, pf);
/*     */       
/* 451 */       return new Real1[] { a, p };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class PoleZeroMode
/*     */     extends Mode
/*     */   {
/*     */     private boolean _poles;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Cdouble _zedit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean _editing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Tile _tile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MouseListener _ml;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MouseMotionListener _mml;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PoleZeroMode(ModeManager modeManager, boolean forPoles)
/*     */     {
/* 515 */       super(modeManager);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 552 */       this._ml = new MouseAdapter() {
/*     */           public void mousePressed(MouseEvent e) {
/* 554 */             if (e.isShiftDown()) {
/* 555 */               PolesAndZeros.PoleZeroMode.this.add(e);
/* 556 */             } else if (e.isControlDown()) {
/* 557 */               PolesAndZeros.PoleZeroMode.this.remove(e);
/*     */             }
/* 559 */             else if (PolesAndZeros.PoleZeroMode.this.beginEdit(e)) {
/* 560 */               PolesAndZeros.PoleZeroMode.this._editing = true;
/* 561 */               PolesAndZeros.PoleZeroMode.this._tile.addMouseMotionListener(PolesAndZeros.PoleZeroMode.this._mml);
/*     */             } 
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent e) {
/* 566 */             if (PolesAndZeros.PoleZeroMode.this._editing) {
/* 567 */               PolesAndZeros.PoleZeroMode.this._tile.removeMouseMotionListener(PolesAndZeros.PoleZeroMode.this._mml);
/* 568 */               PolesAndZeros.PoleZeroMode.this.endEdit(e);
/* 569 */               PolesAndZeros.PoleZeroMode.this._editing = false;
/*     */             } 
/*     */           }
/*     */         };
/*     */ 
/*     */       
/* 575 */       this._mml = new MouseMotionAdapter()
/*     */         {
/* 577 */           public void mouseDragged(MouseEvent e) { if (PolesAndZeros.PoleZeroMode.this._editing)
/* 578 */               PolesAndZeros.PoleZeroMode.this.duringEdit(e);  } }; if (forPoles) {
/*     */         this._poles = true; setName("Poles"); setIcon(loadIcon(PolesAndZeros.class, "resources/Poles16.png")); setMnemonicKey(88); setAcceleratorKey(KeyStroke.getKeyStroke(88, 0)); setShortDescription("Add (Shift), remove (Ctrl), or drag poles");
/*     */       } else {
/*     */         setName("Zeros"); setIcon(loadIcon(PolesAndZeros.class, "resources/Zeros16.png")); setMnemonicKey(48);
/*     */         setAcceleratorKey(KeyStroke.getKeyStroke(48, 0));
/*     */         setShortDescription("Add (Shift), remove (Ctrl), or drag zeros");
/* 584 */       }  } private Cdouble pointToComplex(int x, int y) { Transcaler ts = this._tile.getTranscaler();
/* 585 */       Projector hp = this._tile.getHorizontalProjector();
/* 586 */       Projector vp = this._tile.getVerticalProjector();
/* 587 */       double xu = ts.x(x);
/* 588 */       double yu = ts.y(y);
/* 589 */       double xv = hp.v(xu);
/* 590 */       double yv = vp.v(yu);
/* 591 */       return roundToReal(new Cdouble(xv, yv)); }
/*     */     protected void setActive(Component component, boolean active) { if (component instanceof Tile)
/*     */         if (active) { component.addMouseListener(this._ml); }
/*     */         else
/*     */         { component.removeMouseListener(this._ml); }
/* 596 */           } private Point complexToPoint(Cdouble z) { Transcaler ts = this._tile.getTranscaler();
/* 597 */       Projector hp = this._tile.getHorizontalProjector();
/* 598 */       Projector vp = this._tile.getVerticalProjector();
/* 599 */       double xu = hp.u(z.r);
/* 600 */       double yu = vp.u(z.i);
/* 601 */       int xp = ts.x(xu);
/* 602 */       int yp = ts.y(yu);
/* 603 */       return new Point(xp, yp); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Cdouble roundToReal(Cdouble c) {
/* 611 */       Cdouble cr = new Cdouble(c.r, 0.0D);
/* 612 */       Point pr = complexToPoint(cr);
/* 613 */       Point p = complexToPoint(c);
/* 614 */       return (MathPlus.abs(p.y - pr.y) < 6) ? cr : c;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean closeEnough(int x, int y, Cdouble c) {
/* 620 */       Point p = complexToPoint(c);
/* 621 */       return (MathPlus.abs(p.x - x) < 6 && MathPlus.abs(p.y - y) < 6);
/*     */     }
/*     */ 
/*     */     
/*     */     private void add(MouseEvent e) {
/* 626 */       this._tile = (Tile)e.getSource();
/* 627 */       int x = e.getX();
/* 628 */       int y = e.getY();
/* 629 */       Cdouble z = pointToComplex(x, y);
/* 630 */       if (this._poles) {
/* 631 */         PolesAndZeros.this.addPole(z);
/*     */       } else {
/* 633 */         PolesAndZeros.this.addZero(z);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void remove(MouseEvent e) {
/* 639 */       this._tile = (Tile)e.getSource();
/* 640 */       int x = e.getX();
/* 641 */       int y = e.getY();
/* 642 */       Cdouble z = pointToComplex(x, y);
/* 643 */       if (this._poles) {
/* 644 */         Cdouble pole = PolesAndZeros.this.getPoleNearest(z);
/* 645 */         if (pole != null && closeEnough(x, y, pole))
/* 646 */           PolesAndZeros.this.removePole(pole); 
/*     */       } else {
/* 648 */         Cdouble zero = PolesAndZeros.this.getZeroNearest(z);
/* 649 */         if (zero != null && closeEnough(x, y, zero)) {
/* 650 */           PolesAndZeros.this.removeZero(zero);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean beginEdit(MouseEvent e) {
/* 658 */       this._tile = (Tile)e.getSource();
/* 659 */       int x = e.getX();
/* 660 */       int y = e.getY();
/* 661 */       Cdouble z = pointToComplex(x, y);
/* 662 */       if (this._poles) {
/* 663 */         Cdouble pole = PolesAndZeros.this.getPoleNearest(z);
/* 664 */         if (pole != null && closeEnough(x, y, pole)) {
/* 665 */           PolesAndZeros.this.movePole(pole, z);
/* 666 */           this._zedit = z;
/* 667 */           return true;
/*     */         } 
/*     */       } else {
/* 670 */         Cdouble zero = PolesAndZeros.this.getZeroNearest(z);
/* 671 */         if (zero != null && closeEnough(x, y, zero)) {
/* 672 */           PolesAndZeros.this.moveZero(zero, z);
/* 673 */           this._zedit = z;
/* 674 */           return true;
/*     */         } 
/*     */       } 
/* 677 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private void duringEdit(MouseEvent e) {
/* 682 */       int x = e.getX();
/* 683 */       int y = e.getY();
/* 684 */       Cdouble z = pointToComplex(x, y);
/* 685 */       if (this._poles) {
/* 686 */         PolesAndZeros.this.movePole(this._zedit, z);
/*     */       } else {
/* 688 */         PolesAndZeros.this.moveZero(this._zedit, z);
/*     */       } 
/* 690 */       this._zedit = z;
/*     */     }
/*     */ 
/*     */     
/*     */     private void endEdit(MouseEvent e) {
/* 695 */       duringEdit(e);
/* 696 */       this._editing = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ExitAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private ExitAction() {
/* 705 */       super("Exit");
/*     */     }
/*     */     public void actionPerformed(ActionEvent event) {
/* 708 */       System.exit(0);
/*     */     } }
/*     */   
/*     */   private class SaveAsPngAction extends AbstractAction { private PlotFrame _plotFrame;
/*     */     
/*     */     private SaveAsPngAction(PlotFrame plotFrame) {
/* 714 */       super("Save as PNG");
/* 715 */       this._plotFrame = plotFrame;
/*     */     }
/*     */     public void actionPerformed(ActionEvent event) {
/* 718 */       JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
/* 719 */       fc.showSaveDialog((Component)this._plotFrame);
/* 720 */       File file = fc.getSelectedFile();
/* 721 */       if (file != null) {
/* 722 */         String filename = file.getAbsolutePath();
/* 723 */         this._plotFrame.paintToPng(300.0D, 6.0D, filename);
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/demo/PolesAndZeros.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */