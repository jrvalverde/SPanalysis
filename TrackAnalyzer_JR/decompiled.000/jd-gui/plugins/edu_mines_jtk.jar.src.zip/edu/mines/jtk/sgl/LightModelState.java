/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightModelState
/*     */   implements State
/*     */ {
/*     */   public boolean hasAmbient() {
/*  31 */     return this._ambientSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getAmbient() {
/*  39 */     return toColor(this._ambient);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAmbient(Color color) {
/*  47 */     this._ambient = toArray(color);
/*  48 */     this._ambientSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetAmbient() {
/*  55 */     this._ambient = _ambientDefault;
/*  56 */     this._ambientSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasColorControl() {
/*  64 */     return this._colorControlSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColorControl() {
/*  72 */     return this._colorControl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorControl(int control) {
/*  80 */     this._colorControl = control;
/*  81 */     this._colorControlSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetColorControl() {
/*  88 */     this._colorControl = _colorControlDefault;
/*  89 */     this._colorControlSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLocalViewer() {
/*  97 */     return this._localViewerSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getLocalViewer() {
/* 105 */     return this._localViewer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalViewer(boolean local) {
/* 113 */     this._localViewer = local;
/* 114 */     this._localViewerSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetLocalViewer() {
/* 121 */     this._localViewer = _localViewerDefault;
/* 122 */     this._localViewerSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTwoSide() {
/* 130 */     return this._twoSideSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTwoSide() {
/* 138 */     return this._twoSide;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTwoSide(boolean local) {
/* 146 */     this._twoSide = local;
/* 147 */     this._twoSideSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetTwoSide() {
/* 154 */     this._twoSide = _twoSideDefault;
/* 155 */     this._twoSideSet = false;
/*     */   }
/*     */   
/*     */   public void apply() {
/* 159 */     if (this._ambientSet)
/* 160 */       Gl.glLightModelfv(2899, this._ambient, 0); 
/* 161 */     if (this._colorControlSet)
/* 162 */       Gl.glLightModelf(33272, this._colorControl); 
/* 163 */     if (this._localViewerSet)
/* 164 */       Gl.glLightModelf(2897, this._localViewer ? 1.0F : 0.0F); 
/* 165 */     if (this._twoSideSet)
/* 166 */       Gl.glLightModelf(2898, this._twoSide ? 1.0F : 0.0F); 
/*     */   }
/*     */   
/*     */   public int getAttributeBits() {
/* 170 */     return 2896;
/*     */   }
/*     */   
/* 173 */   private static float[] _ambientDefault = new float[] { 0.2F, 0.2F, 0.2F, 1.0F };
/* 174 */   private float[] _ambient = _ambientDefault;
/*     */   
/*     */   private boolean _ambientSet;
/* 177 */   private static int _colorControlDefault = 33273;
/* 178 */   private int _colorControl = _colorControlDefault;
/*     */   
/*     */   private boolean _colorControlSet;
/*     */   private static boolean _localViewerDefault = false;
/* 182 */   private boolean _localViewer = _localViewerDefault;
/*     */   
/*     */   private boolean _localViewerSet;
/*     */   private static boolean _twoSideDefault = false;
/* 186 */   private boolean _twoSide = _twoSideDefault;
/*     */   private boolean _twoSideSet;
/*     */   
/*     */   private static float[] toArray(Color c) {
/* 190 */     float r = c.getRed() / 255.0F;
/* 191 */     float g = c.getGreen() / 255.0F;
/* 192 */     float b = c.getBlue() / 255.0F;
/* 193 */     float a = c.getAlpha() / 255.0F;
/* 194 */     return new float[] { r, g, b, a };
/*     */   }
/*     */   
/*     */   private static Color toColor(float[] a) {
/* 198 */     return new Color(a[0], a[1], a[2], a[3]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/LightModelState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */