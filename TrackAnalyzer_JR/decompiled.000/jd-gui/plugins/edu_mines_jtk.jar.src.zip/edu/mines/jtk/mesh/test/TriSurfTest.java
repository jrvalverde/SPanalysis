/*    */ package edu.mines.jtk.mesh.test;
/*    */ 
/*    */ import edu.mines.jtk.mesh.TriSurf;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TriSurfTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(TriSurfTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testCube() {
/* 28 */     TriSurf.Node n000 = new TriSurf.Node(0.0F, 0.0F, 0.0F);
/* 29 */     TriSurf.Node n001 = new TriSurf.Node(0.0F, 0.0F, 1.0F);
/* 30 */     TriSurf.Node n010 = new TriSurf.Node(0.0F, 1.0F, 0.0F);
/* 31 */     TriSurf.Node n011 = new TriSurf.Node(0.0F, 1.0F, 1.0F);
/* 32 */     TriSurf.Node n100 = new TriSurf.Node(1.0F, 0.0F, 0.0F);
/* 33 */     TriSurf.Node n101 = new TriSurf.Node(1.0F, 0.0F, 1.0F);
/* 34 */     TriSurf.Node n110 = new TriSurf.Node(1.0F, 1.0F, 0.0F);
/* 35 */     TriSurf.Node n111 = new TriSurf.Node(1.0F, 1.0F, 1.0F);
/*    */     
/* 37 */     TriSurf ts = new TriSurf();
/* 38 */     ts.addNode(n000);
/* 39 */     ts.addNode(n001);
/* 40 */     ts.addNode(n010);
/* 41 */     ts.addNode(n011);
/* 42 */     assertEquals(2, ts.countFaces());
/* 43 */     ts.addNode(n100);
/* 44 */     assertEquals(6, ts.countFaces());
/* 45 */     ts.addNode(n101);
/* 46 */     ts.addNode(n110);
/* 47 */     ts.addNode(n111);
/* 48 */     assertEquals(12, ts.countFaces());
/*    */     
/* 50 */     TriSurf.Node[] nodes = { n000, n001, n010, n011, n100, n101, n110, n111 };
/* 51 */     ts.removeNodes(nodes);
/* 52 */     ts.addNodes(nodes);
/* 53 */     assertEquals(12, ts.countFaces());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/test/TriSurfTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */