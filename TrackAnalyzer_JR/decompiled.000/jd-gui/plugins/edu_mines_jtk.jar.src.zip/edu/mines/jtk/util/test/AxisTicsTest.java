/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.AxisTics;
/*    */ import edu.mines.jtk.util.MathPlus;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AxisTicsTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 22 */     TestSuite suite = new TestSuite(AxisTicsTest.class);
/* 23 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void test180() {
/* 27 */     check(-180.0D, 180.0D, 4, 3, 100.0D, -100.0D, 37, 10.0D, -180.0D);
/* 28 */     check(-180.0D, 180.0D, 5, 3, 100.0D, -100.0D, 37, 10.0D, -180.0D);
/* 29 */     check(-180.0D, 180.0D, 6, 3, 100.0D, -100.0D, 37, 10.0D, -180.0D);
/* 30 */     check(-180.0D, 180.0D, 7, 7, 50.0D, -150.0D, 37, 10.0D, -180.0D);
/* 31 */     check(-180.0D, 180.0D, 8, 7, 50.0D, -150.0D, 37, 10.0D, -180.0D);
/* 32 */     check(-180.0D, 180.0D, 9, 7, 50.0D, -150.0D, 37, 10.0D, -180.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public void testAll() {
/* 37 */     check(0.0D, 10.0D, 1.0D, 11, 1.0D, 0.0D, 101, 0.1D, 0.0D);
/* 38 */     check(0.0D, 10.0D, 11, 11, 1.0D, 0.0D, 101, 0.1D, 0.0D);
/*    */     
/* 40 */     check(0.0D, -10.0D, 1.0D, 11, 1.0D, -10.0D, 101, 0.1D, -10.0D);
/* 41 */     check(0.0D, -10.0D, 11, 11, 1.0D, -10.0D, 101, 0.1D, -10.0D);
/*    */     
/* 43 */     check(1.0D, 10.0D, 1.0D, 10, 1.0D, 1.0D, 91, 0.1D, 1.0D);
/* 44 */     check(1.0D, 10.0D, 10, 10, 1.0D, 1.0D, 91, 0.1D, 1.0D);
/*    */     
/* 46 */     check(1.0D, 10.0D, 2.0D, 5, 2.0D, 2.0D, 10, 1.0D, 1.0D);
/* 47 */     check(1.0D, 10.0D, 9, 5, 2.0D, 2.0D, 10, 1.0D, 1.0D);
/*    */     
/* 49 */     check(0.9D, 10.1D, 2.0D, 5, 2.0D, 2.0D, 10, 1.0D, 1.0D);
/* 50 */     check(0.9D, 10.1D, 9, 5, 2.0D, 2.0D, 10, 1.0D, 1.0D);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void check(double xmin, double xmax, double dtic, int nmajor, double dmajor, double fmajor, int nminor, double dminor, double fminor) {
/* 58 */     check(new AxisTics(xmin, xmax, dtic), nmajor, dmajor, fmajor, nminor, dminor, fminor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void check(double xmin, double xmax, int ntic, int nmajor, double dmajor, double fmajor, int nminor, double dminor, double fminor) {
/* 67 */     check(new AxisTics(xmin, xmax, ntic), nmajor, dmajor, fmajor, nminor, dminor, fminor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void check(AxisTics at, int nmajor, double dmajor, double fmajor, int nminor, double dminor, double fminor) {
/* 75 */     assertEquals(nmajor, at.getCountMajor());
/* 76 */     assertEquals(dmajor, at.getDeltaMajor());
/* 77 */     assertEquals(fmajor, at.getFirstMajor());
/* 78 */     assertEquals(nminor, at.getCountMinor());
/* 79 */     assertEquals(dminor, at.getDeltaMinor());
/* 80 */     assertEquals(fminor, at.getFirstMinor());
/*    */   }
/*    */   
/*    */   private void assertEquals(double e, double a) {
/* 84 */     double tiny = MathPlus.max(MathPlus.abs(e), MathPlus.abs(a)) * 100.0D * 2.220446049250313E-16D;
/* 85 */     assertEquals(e, a, tiny);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/AxisTicsTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */