/*    */ package edu.mines.jtk.la.test;
/*    */ 
/*    */ import edu.mines.jtk.la.DMatrix;
/*    */ import edu.mines.jtk.la.DMatrixEvd;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixEvdTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(DMatrixEvdTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSymmetric() {
/* 28 */     DMatrix a = new DMatrix(new double[][] { { 4.0D, 1.0D, 1.0D }, { 1.0D, 2.0D, 3.0D }, { 1.0D, 3.0D, 6.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 33 */     DMatrixEvd evd = new DMatrixEvd(a);
/* 34 */     DMatrix d = evd.getD();
/* 35 */     DMatrix v = evd.getV();
/* 36 */     DMatrixTest.assertEqualFuzzy(a.times(v), v.times(d));
/*    */   }
/*    */   
/*    */   public void testAsymmetric() {
/* 40 */     DMatrix a = new DMatrix(new double[][] { { 0.0D, 1.0D, 0.0D, 0.0D }, { 1.0D, 0.0D, 2.0E-7D, 0.0D }, { 0.0D, -2.0E-7D, 0.0D, 1.0D }, { 0.0D, 0.0D, 1.0D, 0.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     DMatrixEvd evd = new DMatrixEvd(a);
/* 47 */     DMatrix d = evd.getD();
/* 48 */     DMatrix v = evd.getV();
/* 49 */     DMatrixTest.assertEqualFuzzy(a.times(v), v.times(d));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/test/DMatrixEvdTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */