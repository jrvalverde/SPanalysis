/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Matrix44
/*     */ {
/*  28 */   public double[] m = new double[16];
/*     */   
/*     */   private static final double D2R = 0.017453292519943295D;
/*     */ 
/*     */   
/*     */   public Matrix44() {
/*  34 */     this.m[15] = 1.0D; this.m[10] = 1.0D; this.m[5] = 1.0D; this.m[0] = 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33) {
/*  61 */     set(m00, m01, m02, m03, m10, m11, m12, m13, m20, m21, m22, m23, m30, m31, m32, m33);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44(double[] m) {
/*  75 */     this.m = m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44(Matrix44 m) {
/*  83 */     set(m.m[0], m.m[4], m.m[8], m.m[12], m.m[1], m.m[5], m.m[9], m.m[13], m.m[2], m.m[6], m.m[10], m.m[14], m.m[3], m.m[7], m.m[11], m.m[15]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33) {
/* 113 */     this.m[0] = m00; this.m[4] = m01; this.m[8] = m02; this.m[12] = m03;
/* 114 */     this.m[1] = m10; this.m[5] = m11; this.m[9] = m12; this.m[13] = m13;
/* 115 */     this.m[2] = m20; this.m[6] = m21; this.m[10] = m22; this.m[14] = m23;
/* 116 */     this.m[3] = m30; this.m[7] = m31; this.m[11] = m32; this.m[15] = m33;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 inverse() {
/* 124 */     return new Matrix44(invert(this.m, new double[16]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 inverseEquals() {
/* 132 */     invert(this.m, this.m);
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 transpose() {
/* 141 */     double[] t = { this.m[0], this.m[4], this.m[8], this.m[12], this.m[1], this.m[5], this.m[9], this.m[13], this.m[2], this.m[6], this.m[10], this.m[14], this.m[3], this.m[7], this.m[11], this.m[15] };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     return new Matrix44(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 transposeEquals() {
/* 155 */     double t00 = this.m[0], t01 = this.m[1], t02 = this.m[2], t03 = this.m[3];
/* 156 */     double t10 = this.m[4], t11 = this.m[5], t12 = this.m[6], t13 = this.m[7];
/* 157 */     double t20 = this.m[8], t21 = this.m[9], t22 = this.m[10], t23 = this.m[11];
/* 158 */     double t30 = this.m[12], t31 = this.m[13], t32 = this.m[14], t33 = this.m[15];
/* 159 */     this.m[0] = t00; this.m[4] = t01; this.m[8] = t02; this.m[12] = t03;
/* 160 */     this.m[1] = t10; this.m[5] = t11; this.m[9] = t12; this.m[13] = t13;
/* 161 */     this.m[2] = t20; this.m[6] = t21; this.m[10] = t22; this.m[14] = t23;
/* 162 */     this.m[3] = t30; this.m[7] = t31; this.m[11] = t32; this.m[15] = t33;
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 times(Matrix44 a) {
/* 172 */     return new Matrix44(mul(this.m, a.m, new double[16]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 timesEquals(Matrix44 a) {
/* 181 */     mul(this.m, a.m, this.m);
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 timesTranspose(Matrix44 a) {
/* 191 */     return new Matrix44(mult(this.m, a.m, new double[16]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 timesTransposeEquals(Matrix44 a) {
/* 200 */     mult(this.m, a.m, this.m);
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 transposeTimes(Matrix44 a) {
/* 210 */     return new Matrix44(tmul(this.m, a.m, new double[16]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 transposeTimesEquals(Matrix44 a) {
/* 219 */     tmul(this.m, a.m, this.m);
/* 220 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 times(Point3 p) {
/* 232 */     double px = p.x;
/* 233 */     double py = p.y;
/* 234 */     double pz = p.z;
/* 235 */     double qx = this.m[0] * px + this.m[4] * py + this.m[8] * pz + this.m[12];
/* 236 */     double qy = this.m[1] * px + this.m[5] * py + this.m[9] * pz + this.m[13];
/* 237 */     double qz = this.m[2] * px + this.m[6] * py + this.m[10] * pz + this.m[14];
/* 238 */     double qw = this.m[3] * px + this.m[7] * py + this.m[11] * pz + this.m[15];
/* 239 */     if (qw != 1.0D) {
/* 240 */       double s = 1.0D / qw;
/* 241 */       qx *= s;
/* 242 */       qy *= s;
/* 243 */       qz *= s;
/*     */     } 
/* 245 */     return new Point3(qx, qy, qz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 times(Point4 p) {
/* 254 */     double px = p.x;
/* 255 */     double py = p.y;
/* 256 */     double pz = p.z;
/* 257 */     double pw = p.w;
/* 258 */     double qx = this.m[0] * px + this.m[4] * py + this.m[8] * pz + this.m[12] * pw;
/* 259 */     double qy = this.m[1] * px + this.m[5] * py + this.m[9] * pz + this.m[13] * pw;
/* 260 */     double qz = this.m[2] * px + this.m[6] * py + this.m[10] * pz + this.m[14] * pw;
/* 261 */     double qw = this.m[3] * px + this.m[7] * py + this.m[11] * pz + this.m[15] * pw;
/* 262 */     return new Point4(qx, qy, qz, qw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 transposeTimes(Point3 p) {
/* 274 */     double px = p.x;
/* 275 */     double py = p.y;
/* 276 */     double pz = p.z;
/* 277 */     double qx = this.m[0] * px + this.m[1] * py + this.m[2] * pz + this.m[3];
/* 278 */     double qy = this.m[4] * px + this.m[5] * py + this.m[6] * pz + this.m[7];
/* 279 */     double qz = this.m[8] * px + this.m[9] * py + this.m[10] * pz + this.m[11];
/* 280 */     double qw = this.m[12] * px + this.m[13] * py + this.m[14] * pz + this.m[15];
/* 281 */     if (qw != 1.0D) {
/* 282 */       double s = 1.0D / qw;
/* 283 */       qx *= s;
/* 284 */       qy *= s;
/* 285 */       qz *= s;
/*     */     } 
/* 287 */     return new Point3(qx, qy, qz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 transposeTimes(Point4 p) {
/* 296 */     double px = p.x;
/* 297 */     double py = p.y;
/* 298 */     double pz = p.z;
/* 299 */     double pw = p.w;
/* 300 */     double qx = this.m[0] * px + this.m[1] * py + this.m[2] * pz + this.m[3] * pw;
/* 301 */     double qy = this.m[4] * px + this.m[5] * py + this.m[6] * pz + this.m[7] * pw;
/* 302 */     double qz = this.m[8] * px + this.m[9] * py + this.m[10] * pz + this.m[11] * pw;
/* 303 */     double qw = this.m[12] * px + this.m[13] * py + this.m[14] * pz + this.m[15] * pw;
/* 304 */     return new Point4(qx, qy, qz, qw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 times(Vector3 v) {
/* 314 */     double vx = v.x;
/* 315 */     double vy = v.y;
/* 316 */     double vz = v.z;
/* 317 */     double ux = this.m[0] * vx + this.m[4] * vy + this.m[8] * vz;
/* 318 */     double uy = this.m[1] * vx + this.m[5] * vy + this.m[9] * vz;
/* 319 */     double uz = this.m[2] * vx + this.m[6] * vy + this.m[10] * vz;
/* 320 */     return new Vector3(ux, uy, uz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 transposeTimes(Vector3 v) {
/* 330 */     double vx = v.x;
/* 331 */     double vy = v.y;
/* 332 */     double vz = v.z;
/* 333 */     double ux = this.m[0] * vx + this.m[1] * vy + this.m[2] * vz;
/* 334 */     double uy = this.m[4] * vx + this.m[5] * vy + this.m[6] * vz;
/* 335 */     double uz = this.m[8] * vx + this.m[9] * vy + this.m[10] * vz;
/* 336 */     return new Vector3(ux, uy, uz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 identity() {
/* 344 */     return new Matrix44();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 translate(double tx, double ty, double tz) {
/* 355 */     return (new Matrix44()).setTranslate(tx, ty, tz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 translate(Vector3 tv) {
/* 364 */     return (new Matrix44()).setTranslate(tv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 scale(double sx, double sy, double sz) {
/* 375 */     return (new Matrix44()).setScale(sx, sy, sz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 rotate(double ra, double rx, double ry, double rz) {
/* 388 */     return (new Matrix44()).setRotate(ra, rx, ry, rz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 rotate(double ra, Vector3 rv) {
/* 399 */     return (new Matrix44()).setRotate(ra, rv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 rotateX(double ra) {
/* 409 */     return (new Matrix44()).setRotateX(ra);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 rotateY(double ra) {
/* 419 */     return (new Matrix44()).setRotateY(ra);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 rotateZ(double ra) {
/* 429 */     return (new Matrix44()).setRotateZ(ra);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 ortho(double left, double right, double bottom, double top, double znear, double zfar) {
/* 448 */     return (new Matrix44()).setOrtho(left, right, bottom, top, znear, zfar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 frustum(double left, double right, double bottom, double top, double znear, double zfar) {
/* 467 */     return (new Matrix44()).setFrustum(left, right, bottom, top, znear, zfar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Matrix44 perspective(double fovy, double aspect, double znear, double zfar) {
/* 482 */     return (new Matrix44()).setPerspective(fovy, aspect, znear, zfar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setIdentity() {
/* 494 */     set(1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 498 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setTranslate(double tx, double ty, double tz) {
/* 509 */     set(1.0D, 0.0D, 0.0D, tx, 0.0D, 1.0D, 0.0D, ty, 0.0D, 0.0D, 1.0D, tz, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 513 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setTranslate(Vector3 tv) {
/* 522 */     return setTranslate(tv.x, tv.y, tv.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setScale(double sx, double sy, double sz) {
/* 533 */     set(sx, 0.0D, 0.0D, 0.0D, 0.0D, sy, 0.0D, 0.0D, 0.0D, 0.0D, sz, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 537 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setRotate(double ra, double rx, double ry, double rz) {
/* 550 */     double rs = 1.0D / Math.sqrt(rx * rx + ry * ry + rz * rz);
/* 551 */     rx *= rs;
/* 552 */     ry *= rs;
/* 553 */     rz *= rs;
/* 554 */     double ca = Math.cos(ra * 0.017453292519943295D);
/* 555 */     double sa = Math.sin(ra * 0.017453292519943295D);
/* 556 */     double xx = rx * rx;
/* 557 */     double xy = rx * ry;
/* 558 */     double xz = rx * rz;
/* 559 */     double yx = xy;
/* 560 */     double yy = ry * ry;
/* 561 */     double yz = ry * rz;
/* 562 */     double zx = xz;
/* 563 */     double zy = yz;
/* 564 */     double zz = rz * rz;
/* 565 */     double m00 = xx + ca * (1.0D - xx) + sa * 0.0D;
/* 566 */     double m01 = xy + ca * (0.0D - xy) + sa * -rz;
/* 567 */     double m02 = xz + ca * (0.0D - xz) + sa * ry;
/* 568 */     double m10 = yx + ca * (0.0D - yx) + sa * rz;
/* 569 */     double m11 = yy + ca * (1.0D - yy) + sa * 0.0D;
/* 570 */     double m12 = yz + ca * (0.0D - yz) + sa * -rx;
/* 571 */     double m20 = zx + ca * (0.0D - zx) + sa * -ry;
/* 572 */     double m21 = zy + ca * (0.0D - zy) + sa * rx;
/* 573 */     double m22 = zz + ca * (1.0D - zz) + sa * 0.0D;
/* 574 */     set(m00, m01, m02, 0.0D, m10, m11, m12, 0.0D, m20, m21, m22, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 578 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setRotate(double ra, Vector3 rv) {
/* 589 */     return setRotate(ra, rv.x, rv.y, rv.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setRotateX(double ra) {
/* 599 */     double ca = Math.cos(ra * 0.017453292519943295D);
/* 600 */     double sa = Math.sin(ra * 0.017453292519943295D);
/* 601 */     set(1.0D, 0.0D, 0.0D, 0.0D, 0.0D, ca, -sa, 0.0D, 0.0D, sa, ca, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 605 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setRotateY(double ra) {
/* 615 */     double ca = Math.cos(ra * 0.017453292519943295D);
/* 616 */     double sa = Math.sin(ra * 0.017453292519943295D);
/* 617 */     set(ca, 0.0D, sa, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, -sa, 0.0D, ca, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 621 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setRotateZ(double ra) {
/* 631 */     double ca = Math.cos(ra * 0.017453292519943295D);
/* 632 */     double sa = Math.sin(ra * 0.017453292519943295D);
/* 633 */     set(ca, -sa, 0.0D, 0.0D, sa, ca, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 637 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setOrtho(double left, double right, double bottom, double top, double znear, double zfar) {
/* 656 */     Check.argument((left != right), "left!=right");
/* 657 */     Check.argument((bottom != top), "bottom!=top");
/* 658 */     Check.argument((znear != zfar), "znear!=zfar");
/* 659 */     double tx = -(right + left) / (right - left);
/* 660 */     double ty = -(top + bottom) / (top - bottom);
/* 661 */     double tz = -(zfar + znear) / (zfar - znear);
/* 662 */     double sx = 2.0D / (right - left);
/* 663 */     double sy = 2.0D / (top - bottom);
/* 664 */     double sz = -2.0D / (zfar - znear);
/* 665 */     set(sx, 0.0D, 0.0D, tx, 0.0D, sy, 0.0D, ty, 0.0D, 0.0D, sz, tz, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */ 
/*     */ 
/*     */     
/* 669 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setFrustum(double left, double right, double bottom, double top, double znear, double zfar) {
/* 688 */     Check.argument((left != right), "left!=right");
/* 689 */     Check.argument((bottom != top), "bottom!=top");
/* 690 */     Check.argument((znear != zfar), "znear!=zfar");
/* 691 */     double sx = 2.0D * znear / (right - left);
/* 692 */     double sy = 2.0D * znear / (top - bottom);
/* 693 */     double a = (right + left) / (right - left);
/* 694 */     double b = (top + bottom) / (top - bottom);
/* 695 */     double c = (znear + zfar) / (znear - zfar);
/* 696 */     double d = 2.0D * zfar * znear / (znear - zfar);
/* 697 */     set(sx, 0.0D, a, 0.0D, 0.0D, sy, b, 0.0D, 0.0D, 0.0D, c, d, 0.0D, 0.0D, -1.0D, 0.0D);
/*     */ 
/*     */ 
/*     */     
/* 701 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 setPerspective(double fovy, double aspect, double znear, double zfar) {
/* 716 */     double t = Math.tan(0.5D * fovy * 0.017453292519943295D);
/* 717 */     double right = t * aspect * znear;
/* 718 */     double left = -right;
/* 719 */     double top = t * znear;
/* 720 */     double bottom = -top;
/* 721 */     return setFrustum(left, right, bottom, top, znear, zfar);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 725 */     StringBuilder sb = new StringBuilder();
/* 726 */     for (int i = 0; i < 4; i++) {
/* 727 */       sb.append("| ");
/* 728 */       for (int j = 0; j < 4; j++) {
/* 729 */         sb.append(String.format("% 12.5e ", new Object[] { Double.valueOf(this.m[i + j * 4]) }));
/* 730 */       }  sb.append("|\n");
/*     */     } 
/* 732 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double[] mul(double[] a, double[] b, double[] c) {
/* 746 */     double a00 = a[0], a01 = a[4], a02 = a[8], a03 = a[12];
/* 747 */     double a10 = a[1], a11 = a[5], a12 = a[9], a13 = a[13];
/* 748 */     double a20 = a[2], a21 = a[6], a22 = a[10], a23 = a[14];
/* 749 */     double a30 = a[3], a31 = a[7], a32 = a[11], a33 = a[15];
/* 750 */     double b00 = b[0], b01 = b[4], b02 = b[8], b03 = b[12];
/* 751 */     double b10 = b[1], b11 = b[5], b12 = b[9], b13 = b[13];
/* 752 */     double b20 = b[2], b21 = b[6], b22 = b[10], b23 = b[14];
/* 753 */     double b30 = b[3], b31 = b[7], b32 = b[11], b33 = b[15];
/* 754 */     c[0] = a00 * b00 + a01 * b10 + a02 * b20 + a03 * b30;
/* 755 */     c[1] = a10 * b00 + a11 * b10 + a12 * b20 + a13 * b30;
/* 756 */     c[2] = a20 * b00 + a21 * b10 + a22 * b20 + a23 * b30;
/* 757 */     c[3] = a30 * b00 + a31 * b10 + a32 * b20 + a33 * b30;
/* 758 */     c[4] = a00 * b01 + a01 * b11 + a02 * b21 + a03 * b31;
/* 759 */     c[5] = a10 * b01 + a11 * b11 + a12 * b21 + a13 * b31;
/* 760 */     c[6] = a20 * b01 + a21 * b11 + a22 * b21 + a23 * b31;
/* 761 */     c[7] = a30 * b01 + a31 * b11 + a32 * b21 + a33 * b31;
/* 762 */     c[8] = a00 * b02 + a01 * b12 + a02 * b22 + a03 * b32;
/* 763 */     c[9] = a10 * b02 + a11 * b12 + a12 * b22 + a13 * b32;
/* 764 */     c[10] = a20 * b02 + a21 * b12 + a22 * b22 + a23 * b32;
/* 765 */     c[11] = a30 * b02 + a31 * b12 + a32 * b22 + a33 * b32;
/* 766 */     c[12] = a00 * b03 + a01 * b13 + a02 * b23 + a03 * b33;
/* 767 */     c[13] = a10 * b03 + a11 * b13 + a12 * b23 + a13 * b33;
/* 768 */     c[14] = a20 * b03 + a21 * b13 + a22 * b23 + a23 * b33;
/* 769 */     c[15] = a30 * b03 + a31 * b13 + a32 * b23 + a33 * b33;
/* 770 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double[] mult(double[] a, double[] b, double[] c) {
/* 779 */     double a00 = a[0], a01 = a[4], a02 = a[8], a03 = a[12];
/* 780 */     double a10 = a[1], a11 = a[5], a12 = a[9], a13 = a[13];
/* 781 */     double a20 = a[2], a21 = a[6], a22 = a[10], a23 = a[14];
/* 782 */     double a30 = a[3], a31 = a[7], a32 = a[11], a33 = a[15];
/* 783 */     double b00 = b[0], b01 = b[4], b02 = b[8], b03 = b[12];
/* 784 */     double b10 = b[1], b11 = b[5], b12 = b[9], b13 = b[13];
/* 785 */     double b20 = b[2], b21 = b[6], b22 = b[10], b23 = b[14];
/* 786 */     double b30 = b[3], b31 = b[7], b32 = b[11], b33 = b[15];
/* 787 */     c[0] = a00 * b00 + a01 * b01 + a02 * b02 + a03 * b03;
/* 788 */     c[1] = a10 * b00 + a11 * b01 + a12 * b02 + a13 * b03;
/* 789 */     c[2] = a20 * b00 + a21 * b01 + a22 * b02 + a23 * b03;
/* 790 */     c[3] = a30 * b00 + a31 * b01 + a32 * b02 + a33 * b03;
/* 791 */     c[4] = a00 * b10 + a01 * b11 + a02 * b12 + a03 * b13;
/* 792 */     c[5] = a10 * b10 + a11 * b11 + a12 * b12 + a13 * b13;
/* 793 */     c[6] = a20 * b10 + a21 * b11 + a22 * b12 + a23 * b13;
/* 794 */     c[7] = a30 * b10 + a31 * b11 + a32 * b12 + a33 * b13;
/* 795 */     c[8] = a00 * b20 + a01 * b21 + a02 * b22 + a03 * b23;
/* 796 */     c[9] = a10 * b20 + a11 * b21 + a12 * b22 + a13 * b23;
/* 797 */     c[10] = a20 * b20 + a21 * b21 + a22 * b22 + a23 * b23;
/* 798 */     c[11] = a30 * b20 + a31 * b21 + a32 * b22 + a33 * b23;
/* 799 */     c[12] = a00 * b30 + a01 * b31 + a02 * b32 + a03 * b33;
/* 800 */     c[13] = a10 * b30 + a11 * b31 + a12 * b32 + a13 * b33;
/* 801 */     c[14] = a20 * b30 + a21 * b31 + a22 * b32 + a23 * b33;
/* 802 */     c[15] = a30 * b30 + a31 * b31 + a32 * b32 + a33 * b33;
/* 803 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double[] tmul(double[] a, double[] b, double[] c) {
/* 812 */     double a00 = a[0], a01 = a[4], a02 = a[8], a03 = a[12];
/* 813 */     double a10 = a[1], a11 = a[5], a12 = a[9], a13 = a[13];
/* 814 */     double a20 = a[2], a21 = a[6], a22 = a[10], a23 = a[14];
/* 815 */     double a30 = a[3], a31 = a[7], a32 = a[11], a33 = a[15];
/* 816 */     double b00 = b[0], b01 = b[4], b02 = b[8], b03 = b[12];
/* 817 */     double b10 = b[1], b11 = b[5], b12 = b[9], b13 = b[13];
/* 818 */     double b20 = b[2], b21 = b[6], b22 = b[10], b23 = b[14];
/* 819 */     double b30 = b[3], b31 = b[7], b32 = b[11], b33 = b[15];
/* 820 */     c[0] = a00 * b00 + a10 * b10 + a20 * b20 + a30 * b30;
/* 821 */     c[1] = a01 * b00 + a11 * b10 + a21 * b20 + a31 * b30;
/* 822 */     c[2] = a02 * b00 + a12 * b10 + a22 * b20 + a32 * b30;
/* 823 */     c[3] = a03 * b00 + a13 * b10 + a23 * b20 + a33 * b30;
/* 824 */     c[4] = a00 * b01 + a10 * b11 + a20 * b21 + a30 * b31;
/* 825 */     c[5] = a01 * b01 + a11 * b11 + a21 * b21 + a31 * b31;
/* 826 */     c[6] = a02 * b01 + a12 * b11 + a22 * b21 + a32 * b31;
/* 827 */     c[7] = a03 * b01 + a13 * b11 + a23 * b21 + a33 * b31;
/* 828 */     c[8] = a00 * b02 + a10 * b12 + a20 * b22 + a30 * b32;
/* 829 */     c[9] = a01 * b02 + a11 * b12 + a21 * b22 + a31 * b32;
/* 830 */     c[10] = a02 * b02 + a12 * b12 + a22 * b22 + a32 * b32;
/* 831 */     c[11] = a03 * b02 + a13 * b12 + a23 * b22 + a33 * b32;
/* 832 */     c[12] = a00 * b03 + a10 * b13 + a20 * b23 + a30 * b33;
/* 833 */     c[13] = a01 * b03 + a11 * b13 + a21 * b23 + a31 * b33;
/* 834 */     c[14] = a02 * b03 + a12 * b13 + a22 * b23 + a32 * b33;
/* 835 */     c[15] = a03 * b03 + a13 * b13 + a23 * b23 + a33 * b33;
/* 836 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double[] invert(double[] a, double[] b) {
/* 852 */     double t00 = a[0];
/* 853 */     double t01 = a[4];
/* 854 */     double t02 = a[8];
/* 855 */     double t03 = a[12];
/* 856 */     double t04 = a[1];
/* 857 */     double t08 = a[2];
/* 858 */     double t12 = a[3];
/* 859 */     double t05 = a[5];
/* 860 */     double t09 = a[6];
/* 861 */     double t13 = a[7];
/* 862 */     double t06 = a[9];
/* 863 */     double t10 = a[10];
/* 864 */     double t14 = a[11];
/* 865 */     double t07 = a[13];
/* 866 */     double t11 = a[14];
/* 867 */     double t15 = a[15];
/*     */ 
/*     */     
/* 870 */     double u00 = t10 * t15;
/* 871 */     double u01 = t11 * t14;
/* 872 */     double u02 = t09 * t15;
/* 873 */     double u03 = t11 * t13;
/* 874 */     double u04 = t09 * t14;
/* 875 */     double u05 = t10 * t13;
/* 876 */     double u06 = t08 * t15;
/* 877 */     double u07 = t11 * t12;
/* 878 */     double u08 = t08 * t14;
/* 879 */     double u09 = t10 * t12;
/* 880 */     double u10 = t08 * t13;
/* 881 */     double u11 = t09 * t12;
/*     */ 
/*     */     
/* 884 */     b[0] = u00 * t05 + u03 * t06 + u04 * t07 - u01 * t05 - u02 * t06 - u05 * t07;
/* 885 */     b[1] = u01 * t04 + u06 * t06 + u09 * t07 - u00 * t04 - u07 * t06 - u08 * t07;
/* 886 */     b[2] = u02 * t04 + u07 * t05 + u10 * t07 - u03 * t04 - u06 * t05 - u11 * t07;
/* 887 */     b[3] = u05 * t04 + u08 * t05 + u11 * t06 - u04 * t04 - u09 * t05 - u10 * t06;
/* 888 */     b[4] = u01 * t01 + u02 * t02 + u05 * t03 - u00 * t01 - u03 * t02 - u04 * t03;
/* 889 */     b[5] = u00 * t00 + u07 * t02 + u08 * t03 - u01 * t00 - u06 * t02 - u09 * t03;
/* 890 */     b[6] = u03 * t00 + u06 * t01 + u11 * t03 - u02 * t00 - u07 * t01 - u10 * t03;
/* 891 */     b[7] = u04 * t00 + u09 * t01 + u10 * t02 - u05 * t00 - u08 * t01 - u11 * t02;
/*     */ 
/*     */     
/* 894 */     u00 = t02 * t07;
/* 895 */     u01 = t03 * t06;
/* 896 */     u02 = t01 * t07;
/* 897 */     u03 = t03 * t05;
/* 898 */     u04 = t01 * t06;
/* 899 */     u05 = t02 * t05;
/* 900 */     u06 = t00 * t07;
/* 901 */     u07 = t03 * t04;
/* 902 */     u08 = t00 * t06;
/* 903 */     u09 = t02 * t04;
/* 904 */     u10 = t00 * t05;
/* 905 */     u11 = t01 * t04;
/*     */ 
/*     */     
/* 908 */     b[8] = u00 * t13 + u03 * t14 + u04 * t15 - u01 * t13 - u02 * t14 - u05 * t15;
/* 909 */     b[9] = u01 * t12 + u06 * t14 + u09 * t15 - u00 * t12 - u07 * t14 - u08 * t15;
/* 910 */     b[10] = u02 * t12 + u07 * t13 + u10 * t15 - u03 * t12 - u06 * t13 - u11 * t15;
/* 911 */     b[11] = u05 * t12 + u08 * t13 + u11 * t14 - u04 * t12 - u09 * t13 - u10 * t14;
/* 912 */     b[12] = u02 * t10 + u05 * t11 + u01 * t09 - u04 * t11 - u00 * t09 - u03 * t10;
/* 913 */     b[13] = u08 * t11 + u00 * t08 + u07 * t10 - u06 * t10 - u09 * t11 - u01 * t08;
/* 914 */     b[14] = u06 * t09 + u11 * t11 + u03 * t08 - u10 * t11 - u02 * t08 - u07 * t09;
/* 915 */     b[15] = u10 * t10 + u04 * t08 + u09 * t09 - u08 * t09 - u11 * t10 - u05 * t08;
/*     */ 
/*     */     
/* 918 */     double d = t00 * b[0] + t01 * b[1] + t02 * b[2] + t03 * b[3];
/*     */ 
/*     */     
/* 921 */     d = 1.0D / d;
/* 922 */     b[0] = b[0] * d; b[1] = b[1] * d; b[2] = b[2] * d; b[3] = b[3] * d;
/* 923 */     b[4] = b[4] * d; b[5] = b[5] * d; b[6] = b[6] * d; b[7] = b[7] * d;
/* 924 */     b[8] = b[8] * d; b[9] = b[9] * d; b[10] = b[10] * d; b[11] = b[11] * d;
/* 925 */     b[12] = b[12] * d; b[13] = b[13] * d; b[14] = b[14] * d; b[15] = b[15] * d;
/* 926 */     return b;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Matrix44.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */