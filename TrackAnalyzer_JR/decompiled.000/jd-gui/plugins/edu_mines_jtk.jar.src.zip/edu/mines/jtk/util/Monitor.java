/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Monitor
/*    */ {
/* 32 */   public static final Monitor NULL_MONITOR = new Monitor() {
/*    */       public void initReport(double initFraction) {}
/*    */       
/*    */       public void report(double fraction) {}
/*    */     };
/*    */   
/*    */   void initReport(double paramDouble);
/*    */   
/*    */   void report(double paramDouble);
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Monitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */