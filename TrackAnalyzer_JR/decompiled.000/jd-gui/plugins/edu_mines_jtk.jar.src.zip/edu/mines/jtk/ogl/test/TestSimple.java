/*    */ package edu.mines.jtk.ogl.test;
/*    */ 
/*    */ import edu.mines.jtk.ogl.GlCanvas;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestSimple
/*    */ {
/*    */   private static final int SIZE = 600;
/*    */   
/*    */   public static void run(String[] args, GlCanvas canvas) {
/* 24 */     run(args, canvas, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void run(String[] args, GlCanvas canvas, boolean autoRepaint) {
/* 29 */     run(canvas, autoRepaint);
/*    */   }
/*    */   public static void run(GlCanvas canvas, boolean autoRepaint) {
/* 32 */     canvas.setAutoRepaint(autoRepaint);
/* 33 */     JFrame frame = new JFrame();
/* 34 */     frame.setDefaultCloseOperation(3);
/* 35 */     frame.setSize(new Dimension(600, 600));
/* 36 */     frame.getContentPane().add((Component)canvas, "Center");
/* 37 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/TestSimple.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */