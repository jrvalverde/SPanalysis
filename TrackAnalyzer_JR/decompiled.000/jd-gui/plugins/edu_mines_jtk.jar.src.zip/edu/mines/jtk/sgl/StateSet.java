/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateSet
/*    */   implements State
/*    */ {
/*    */   public void add(State state) {
/* 32 */     this._states.add(state);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove(State state) {
/* 40 */     this._states.remove(state);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contains(Class stateClass) {
/* 49 */     return (find(stateClass) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public State find(Class stateClass) {
/* 58 */     for (State s : this._states) {
/* 59 */       if (s.getClass().equals(stateClass))
/* 60 */         return s; 
/*    */     } 
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<State> getStates() {
/* 70 */     return this._states.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void apply() {
/* 77 */     for (State s : this._states) {
/* 78 */       s.apply();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAttributeBits() {
/* 86 */     int attributeBits = 0;
/* 87 */     for (State state : this._states)
/* 88 */       attributeBits |= state.getAttributeBits(); 
/* 89 */     return attributeBits;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 95 */   private Set<State> _states = new HashSet<State>();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/StateSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */