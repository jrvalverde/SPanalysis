/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.LocalOrientFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalOrientFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(LocalOrientFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test2() {
/*  28 */     double sigma = 8.0D;
/*  29 */     int n1 = 1 + 4 * (int)(3.0D * sigma);
/*  30 */     int n2 = n1 + 2;
/*  31 */     LocalOrientFilter lof = new LocalOrientFilter(sigma);
/*  32 */     float pi = 3.1415927F;
/*  33 */     float[] dips = { -0.49F * pi, -0.2F * pi, -0.01F, 0.01F, 0.2F * pi, 0.49F * pi };
/*  34 */     for (float dip : dips) {
/*  35 */       float k = 0.3F;
/*  36 */       float c = k * MathPlus.cos(dip);
/*  37 */       float s = k * MathPlus.sin(dip);
/*  38 */       float[][] x = Array.sin(Array.rampfloat(0.0F, c, s, n1, n2));
/*  39 */       float[][] theta = new float[n2][n1];
/*  40 */       float[][] u1 = new float[n2][n1];
/*  41 */       float[][] u2 = new float[n2][n1];
/*  42 */       float[][] v1 = new float[n2][n1];
/*  43 */       float[][] v2 = new float[n2][n1];
/*  44 */       float[][] eu = new float[n2][n1];
/*  45 */       float[][] ev = new float[n2][n1];
/*  46 */       float[][] el = new float[n2][n1];
/*  47 */       lof.apply(x, theta, u1, u2, v1, v2, eu, ev, el);
/*  48 */       assertEqual(dip, theta, 0.01D);
/*  49 */       assertEqual(MathPlus.cos(dip), u1, 0.01D);
/*  50 */       assertEqual(MathPlus.sin(dip), u2, 0.01D);
/*  51 */       assertEqual(-MathPlus.sin(dip), v1, 0.01D);
/*  52 */       assertEqual(MathPlus.cos(dip), v2, 0.01D);
/*  53 */       assertEqual(1.0D, el, 0.01D);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test3Planar() {
/*  58 */     double sigma = 6.0D;
/*  59 */     int n1 = 1 + 2 * (int)(3.0D * sigma);
/*  60 */     int n2 = n1 + 2;
/*  61 */     int n3 = n2 + 2;
/*  62 */     LocalOrientFilter lof = new LocalOrientFilter(sigma);
/*  63 */     float pi = 3.1415927F;
/*  64 */     float[] azis = { -0.5F * pi, 0.25F * pi, 0.99F * pi };
/*  65 */     float[] dips = { 0.01F * pi, 0.2F * pi, 0.49F * pi };
/*  66 */     for (float azi : azis) {
/*  67 */       for (float dip : dips) {
/*     */         
/*  69 */         float k = 0.3F;
/*  70 */         float ku1 = k * MathPlus.cos(dip);
/*  71 */         float ku2 = k * MathPlus.sin(dip) * MathPlus.cos(azi);
/*  72 */         float ku3 = k * MathPlus.sin(dip) * MathPlus.sin(azi);
/*  73 */         float[][][] x = Array.sin(Array.rampfloat(0.0F, ku1, ku2, ku3, n1, n2, n3));
/*  74 */         float[][][] theta = new float[n3][n2][n1];
/*  75 */         float[][][] phi = new float[n3][n2][n1];
/*  76 */         float[][][] u1 = new float[n3][n2][n1];
/*  77 */         float[][][] u2 = new float[n3][n2][n1];
/*  78 */         float[][][] u3 = new float[n3][n2][n1];
/*  79 */         float[][][] v1 = new float[n3][n2][n1];
/*  80 */         float[][][] v2 = new float[n3][n2][n1];
/*  81 */         float[][][] v3 = new float[n3][n2][n1];
/*  82 */         float[][][] w1 = new float[n3][n2][n1];
/*  83 */         float[][][] w2 = new float[n3][n2][n1];
/*  84 */         float[][][] w3 = new float[n3][n2][n1];
/*  85 */         float[][][] eu = new float[n3][n2][n1];
/*  86 */         float[][][] ev = new float[n3][n2][n1];
/*  87 */         float[][][] ew = new float[n3][n2][n1];
/*  88 */         float[][][] ep = new float[n3][n2][n1];
/*  89 */         float[][][] el = new float[n3][n2][n1];
/*  90 */         lof.apply(x, theta, phi, u1, u2, u3, v1, v2, v3, w1, w2, w3, eu, ev, ew, ep, el);
/*  91 */         assertEqual(dip, theta, 0.02D);
/*  92 */         assertEqual(azi, phi, 0.02D);
/*  93 */         assertEqual(MathPlus.cos(dip), u1, 0.02D);
/*  94 */         assertEqual((MathPlus.sin(dip) * MathPlus.cos(azi)), u2, 0.02D);
/*  95 */         assertEqual((MathPlus.sin(dip) * MathPlus.sin(azi)), u3, 0.02D);
/*  96 */         assertEqual(1.0D, ep, 0.02D);
/*  97 */         assertEqual(0.0D, el, 0.02D);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test3Linear() {
/* 103 */     double sigma = 6.0D;
/* 104 */     int n1 = 1 + 2 * (int)(3.0D * sigma);
/* 105 */     int n2 = n1 + 2;
/* 106 */     int n3 = n2 + 2;
/* 107 */     LocalOrientFilter lof = new LocalOrientFilter(sigma);
/* 108 */     float pi = 3.1415927F;
/* 109 */     float[] azis = { -0.5F * pi, 0.25F * pi, 0.99F * pi };
/* 110 */     float[] dips = { 0.01F * pi, 0.2F * pi, 0.49F * pi };
/* 111 */     for (float azi : azis) {
/* 112 */       for (float dip : dips) {
/*     */         
/* 114 */         float a1 = ((n1 - 1) / 2);
/* 115 */         float a2 = ((n2 - 1) / 2);
/* 116 */         float a3 = ((n3 - 1) / 2);
/* 117 */         float b1 = MathPlus.cos(dip);
/* 118 */         float b2 = MathPlus.sin(dip) * MathPlus.cos(azi);
/* 119 */         float b3 = MathPlus.sin(dip) * MathPlus.sin(azi);
/* 120 */         float[][][] x = new float[n3][n2][n1];
/* 121 */         for (int i3 = 0; i3 < n3; i3++) {
/* 122 */           float x3 = i3 - a3;
/* 123 */           for (int i2 = 0; i2 < n2; i2++) {
/* 124 */             float x2 = i2 - a2;
/* 125 */             for (int i1 = 0; i1 < n1; i1++) {
/* 126 */               float x1 = i1 - a1;
/* 127 */               float t = x1 * b1 + x2 * b2 + x3 * b3;
/* 128 */               float d1 = x1 - t * b1;
/* 129 */               float d2 = x2 - t * b2;
/* 130 */               float d3 = x3 - t * b3;
/* 131 */               x[i3][i2][i1] = MathPlus.exp(-0.125F * (d1 * d1 + d2 * d2 + d3 * d3));
/*     */             } 
/*     */           } 
/*     */         } 
/* 135 */         float[][][] theta = new float[n3][n2][n1];
/* 136 */         float[][][] phi = new float[n3][n2][n1];
/* 137 */         float[][][] u1 = new float[n3][n2][n1];
/* 138 */         float[][][] u2 = new float[n3][n2][n1];
/* 139 */         float[][][] u3 = new float[n3][n2][n1];
/* 140 */         float[][][] v1 = new float[n3][n2][n1];
/* 141 */         float[][][] v2 = new float[n3][n2][n1];
/* 142 */         float[][][] v3 = new float[n3][n2][n1];
/* 143 */         float[][][] w1 = new float[n3][n2][n1];
/* 144 */         float[][][] w2 = new float[n3][n2][n1];
/* 145 */         float[][][] w3 = new float[n3][n2][n1];
/* 146 */         float[][][] eu = new float[n3][n2][n1];
/* 147 */         float[][][] ev = new float[n3][n2][n1];
/* 148 */         float[][][] ew = new float[n3][n2][n1];
/* 149 */         float[][][] ep = new float[n3][n2][n1];
/* 150 */         float[][][] el = new float[n3][n2][n1];
/* 151 */         lof.apply(x, theta, phi, u1, u2, u3, v1, v2, v3, w1, w2, w3, eu, ev, ew, ep, el);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 159 */         assertAbsEqual(MathPlus.cos(dip), w1, 0.1D);
/* 160 */         assertAbsEqual((MathPlus.sin(dip) * MathPlus.cos(azi)), w2, 0.1D);
/* 161 */         assertAbsEqual((MathPlus.sin(dip) * MathPlus.sin(azi)), w3, 0.1D);
/* 162 */         assertEqual(0.0D, ep, 0.2D);
/* 163 */         assertEqual(1.0D, el, 0.2D);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void assertEqual(double e, float[][] a, double tol) {
/* 169 */     int n1 = (a[0]).length;
/* 170 */     int n2 = a.length;
/* 171 */     assertEquals(e, a[n2 / 2][n1 / 2], tol);
/*     */   }
/*     */   
/*     */   private static void assertEqual(double e, float[][][] a, double tol) {
/* 175 */     int n1 = (a[0][0]).length;
/* 176 */     int n2 = (a[0]).length;
/* 177 */     int n3 = a.length;
/* 178 */     assertEquals(e, a[n3 / 2][n2 / 2][n1 / 2], tol);
/*     */   }
/*     */   
/*     */   private static void assertAbsEqual(double e, float[][][] a, double tol) {
/* 182 */     int n1 = (a[0][0]).length;
/* 183 */     int n2 = (a[0]).length;
/* 184 */     int n3 = a.length;
/* 185 */     assertEquals(MathPlus.abs(e), MathPlus.abs(a[n3 / 2][n2 / 2][n1 / 2]), tol);
/*     */   }
/*     */   
/*     */   private static void print(String s, float[][][] a) {
/* 189 */     int n1 = (a[0][0]).length;
/* 190 */     int n2 = (a[0]).length;
/* 191 */     int n3 = a.length;
/* 192 */     System.out.println(s + a[n3 / 2][n2 / 2][n1 / 2]);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/LocalOrientFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */