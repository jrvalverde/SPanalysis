/*     */ package edu.mines.jtk.la;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrix
/*     */ {
/*     */   private int _m;
/*     */   private int _n;
/*     */   private double[][] _a;
/*     */   
/*     */   public DMatrix(int m, int n) {
/*  35 */     this._m = m;
/*  36 */     this._n = n;
/*  37 */     this._a = new double[m][n];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix(int m, int n, double v) {
/*  47 */     this(m, n);
/*  48 */     Array.fill(v, this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix(double[][] a) {
/*  62 */     Check.argument(Array.isRegular(a), "array a is regular");
/*  63 */     this._m = a.length;
/*  64 */     this._n = (a[0]).length;
/*  65 */     this._a = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix(DMatrix a) {
/*  73 */     this(a._m, a._n, Array.copy(a._a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getM() {
/*  81 */     return this._m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowCount() {
/*  89 */     return this._m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getN() {
/*  97 */     return this._n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnCount() {
/* 105 */     return this._n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] getArray() {
/* 113 */     return this._a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSquare() {
/* 121 */     return (this._m == this._n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSymmetric() {
/* 129 */     if (!isSquare())
/* 130 */       return false; 
/* 131 */     for (int i = 0; i < this._n; i++) {
/* 132 */       for (int j = i + 1; j < this._n; j++)
/* 133 */       { if (this._a[i][j] != this._a[j][i])
/* 134 */           return false;  } 
/* 135 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] get() {
/* 143 */     return Array.copy(this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void get(double[][] a) {
/* 151 */     Array.copy(this._a, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double get(int i, int j) {
/* 161 */     return this._a[i][j];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int i0, int i1, int j0, int j1) {
/* 172 */     checkI(i0, i1);
/* 173 */     checkJ(j0, j1);
/* 174 */     int m = i1 - i0 + 1;
/* 175 */     int n = j1 - j0 + 1;
/* 176 */     DMatrix x = new DMatrix(m, n);
/* 177 */     Array.copy(n, m, j0, i0, this._a, 0, 0, x._a);
/* 178 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int[] r, int[] c) {
/* 187 */     if (r == null && c == null) {
/* 188 */       return new DMatrix(this._m, this._n, Array.copy(this._a));
/*     */     }
/* 190 */     int m = (r != null) ? r.length : this._m;
/* 191 */     int n = (c != null) ? c.length : this._n;
/* 192 */     double[][] b = new double[m][n];
/* 193 */     if (r == null)
/* 194 */     { for (int i = 0; i < m; i++)
/* 195 */       { for (int j = 0; j < n; j++)
/* 196 */           b[i][j] = this._a[i][c[j]];  }  }
/* 197 */     else if (c == null)
/* 198 */     { for (int i = 0; i < m; i++) {
/* 199 */         for (int j = 0; j < n; j++)
/* 200 */           b[i][j] = this._a[r[i]][j]; 
/*     */       }  }
/* 202 */     else { for (int i = 0; i < m; i++) {
/* 203 */         for (int j = 0; j < n; j++)
/* 204 */           b[i][j] = this._a[r[i]][c[j]]; 
/*     */       }  }
/* 206 */      return new DMatrix(m, n, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int i, int[] c) {
/* 216 */     return get(i, i, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int[] r, int j) {
/* 225 */     return get(r, j, j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int i0, int i1, int[] c) {
/* 235 */     checkI(i0, i1);
/* 236 */     if (c == null) {
/* 237 */       return get(i0, i1, 0, this._n - 1);
/*     */     }
/* 239 */     int m = i1 - i0 + 1;
/* 240 */     int n = c.length;
/* 241 */     double[][] b = new double[m][n];
/* 242 */     for (int i = i0; i <= i1; i++) {
/* 243 */       for (int j = 0; j < n; j++) {
/* 244 */         b[i - i0][j] = this._a[i][c[j]];
/*     */       }
/*     */     } 
/* 247 */     return new DMatrix(m, n, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix get(int[] r, int j0, int j1) {
/* 258 */     checkJ(j0, j1);
/* 259 */     if (r == null) {
/* 260 */       return get(0, this._m - 1, j0, j1);
/*     */     }
/* 262 */     int m = r.length;
/* 263 */     int n = j1 - j0 + 1;
/* 264 */     double[][] b = new double[m][n];
/* 265 */     for (int i = 0; i < m; i++) {
/* 266 */       for (int j = j0; j <= j1; j++) {
/* 267 */         b[i][j - j0] = this._a[r[i]][j];
/*     */       }
/*     */     } 
/* 270 */     return new DMatrix(m, n, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getPackedColumns() {
/* 279 */     double[] c = new double[this._m * this._n];
/* 280 */     for (int i = 0; i < this._m; i++) {
/* 281 */       for (int j = 0; j < this._n; j++)
/* 282 */         c[i + j * this._m] = this._a[i][j]; 
/* 283 */     }  return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getPackedRows() {
/* 291 */     double[] r = new double[this._m * this._n];
/* 292 */     for (int i = 0; i < this._m; i++) {
/* 293 */       for (int j = 0; j < this._n; j++)
/* 294 */         r[i * this._n + j] = this._a[i][j]; 
/* 295 */     }  return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(double[][] a) {
/* 304 */     for (int i = 0; i < this._m; i++) {
/* 305 */       for (int j = 0; j < this._n; j++) {
/* 306 */         this._a[i][j] = a[i][j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int i, int j, double v) {
/* 316 */     this._a[i][j] = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int i0, int i1, int j0, int j1, DMatrix x) {
/* 328 */     checkI(i0, i1);
/* 329 */     checkJ(j0, j1);
/* 330 */     int m = i1 - i0 + 1;
/* 331 */     int n = j1 - j0 + 1;
/* 332 */     Check.argument((m == x._m), "i1-i0+1 equals number of rows in x");
/* 333 */     Check.argument((n == x._n), "j1-j0+1 equals number of columns in x");
/* 334 */     Array.copy(n, m, 0, 0, x._a, j0, i0, this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int[] r, int[] c, DMatrix x) {
/* 344 */     if (r == null) {
/* 345 */       Check.argument((this._m == x._m), "number of rows equal in this and x");
/*     */     } else {
/* 347 */       Check.argument((r.length == x._m), "r.length equals number of rows in x");
/*     */     } 
/* 349 */     if (c == null) {
/* 350 */       Check.argument((this._n == x._n), "number of columns equal in this and x");
/*     */     } else {
/* 352 */       Check.argument((c.length == x._n), "c.length equals number of columns in x");
/*     */     } 
/* 354 */     if (r == null && c == null) {
/* 355 */       Array.copy(x._a, this._a);
/*     */     } else {
/* 357 */       int m = (r != null) ? r.length : this._m;
/* 358 */       int n = (c != null) ? c.length : this._n;
/* 359 */       double[][] b = x._a;
/* 360 */       if (r == null)
/* 361 */       { for (int i = 0; i < m; i++)
/* 362 */         { for (int j = 0; j < n; j++)
/* 363 */             this._a[i][c[j]] = b[i][j];  }  }
/* 364 */       else if (c == null)
/* 365 */       { for (int i = 0; i < m; i++) {
/* 366 */           for (int j = 0; j < n; j++)
/* 367 */             this._a[r[i]][j] = b[i][j]; 
/*     */         }  }
/* 369 */       else { for (int i = 0; i < m; i++) {
/* 370 */           for (int j = 0; j < n; j++) {
/* 371 */             this._a[r[i]][c[j]] = b[i][j];
/*     */           }
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int i, int[] c, DMatrix x) {
/* 383 */     set(i, i, c, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int[] r, int j, DMatrix x) {
/* 393 */     set(r, j, j, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int i0, int i1, int[] c, DMatrix x) {
/* 404 */     checkI(i0, i1);
/* 405 */     Check.argument((i1 - i0 + 1 == x._m), "i1-i0+1 equals number of rows in x");
/* 406 */     if (c == null) {
/* 407 */       set(i0, i1, 0, this._n - 1, x);
/*     */     } else {
/* 409 */       int n = c.length;
/* 410 */       double[][] b = x._a;
/* 411 */       for (int i = i0; i <= i1; i++) {
/* 412 */         for (int j = 0; j < n; j++) {
/* 413 */           this._a[i][c[j]] = b[i - i0][j];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int[] r, int j0, int j1, DMatrix x) {
/* 427 */     checkJ(j0, j1);
/* 428 */     Check.argument((j1 - j0 + 1 == x._n), "j1-j0+1 equals number of columns in x");
/* 429 */     if (r == null) {
/* 430 */       set(0, this._m - 1, j0, j1, x);
/*     */     } else {
/* 432 */       int m = r.length;
/* 433 */       double[][] b = x._a;
/* 434 */       for (int i = 0; i < m; i++) {
/* 435 */         for (int j = j0; j <= j1; j++) {
/* 436 */           this._a[r[i]][j] = b[i][j - j0];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackedColumns(double[] c) {
/* 447 */     for (int i = 0; i < this._m; i++) {
/* 448 */       for (int j = 0; j < this._n; j++) {
/* 449 */         this._a[i][j] = c[i + j * this._m];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackedRows(double[] r) {
/* 457 */     for (int i = 0; i < this._m; i++) {
/* 458 */       for (int j = 0; j < this._n; j++) {
/* 459 */         this._a[i][j] = r[i * this._n + j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix transpose() {
/* 467 */     DMatrix x = new DMatrix(this._n, this._m);
/* 468 */     double[][] b = x._a;
/* 469 */     for (int i = 0; i < this._m; i++) {
/* 470 */       for (int j = 0; j < this._n; j++) {
/* 471 */         b[j][i] = this._a[i][j];
/*     */       }
/*     */     } 
/* 474 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double norm1() {
/* 482 */     double f = 0.0D;
/* 483 */     for (int j = 0; j < this._n; j++) {
/* 484 */       double s = 0.0D;
/* 485 */       for (int i = 0; i < this._m; i++)
/* 486 */         s += Math.abs(this._a[i][j]); 
/* 487 */       f = Math.max(f, s);
/*     */     } 
/* 489 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double norm2() {
/* 497 */     return 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double normI() {
/* 505 */     double f = 0.0D;
/* 506 */     for (int i = 0; i < this._m; i++) {
/* 507 */       double s = 0.0D;
/* 508 */       for (int j = 0; j < this._n; j++)
/* 509 */         s += Math.abs(this._a[i][j]); 
/* 510 */       f = Math.max(f, s);
/*     */     } 
/* 512 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double normF() {
/* 520 */     double f = 0.0D;
/* 521 */     for (int i = 0; i < this._m; i++) {
/* 522 */       for (int j = 0; j < this._n; j++) {
/* 523 */         f = Math.hypot(f, this._a[i][j]);
/*     */       }
/*     */     } 
/* 526 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix negate() {
/* 534 */     DMatrix c = new DMatrix(this._m, this._n);
/* 535 */     Array.neg(this._a, c._a);
/* 536 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix plus(DMatrix b) {
/* 545 */     DMatrix c = new DMatrix(this._m, this._n);
/* 546 */     Array.add(this._a, b._a, c._a);
/* 547 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix plusEquals(DMatrix b) {
/* 556 */     Array.add(this._a, b._a, this._a);
/* 557 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix minus(DMatrix b) {
/* 566 */     DMatrix c = new DMatrix(this._m, this._n);
/* 567 */     Array.sub(this._a, b._a, c._a);
/* 568 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix minusEquals(DMatrix b) {
/* 577 */     Array.sub(this._a, b._a, this._a);
/* 578 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayTimes(DMatrix b) {
/* 588 */     DMatrix c = new DMatrix(this._m, this._n);
/* 589 */     Array.mul(this._a, b._a, c._a);
/* 590 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayTimesEquals(DMatrix b) {
/* 600 */     Array.mul(this._a, b._a, this._a);
/* 601 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayRightDivide(DMatrix b) {
/* 611 */     DMatrix c = new DMatrix(this._m, this._n);
/* 612 */     Array.div(this._a, b._a, c._a);
/* 613 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayRightDivideEquals(DMatrix b) {
/* 623 */     Array.div(this._a, b._a, this._a);
/* 624 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayLeftDivide(DMatrix b) {
/* 634 */     DMatrix c = new DMatrix(this._m, this._n);
/* 635 */     Array.div(b._a, this._a, c._a);
/* 636 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix arrayLeftDivideEquals(DMatrix b) {
/* 646 */     Array.div(b._a, this._a, this._a);
/* 647 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix times(double s) {
/* 656 */     DMatrix c = new DMatrix(this._m, this._n);
/* 657 */     Array.mul(this._a, s, c._a);
/* 658 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix timesEquals(double s) {
/* 667 */     Array.mul(this._a, s, this._a);
/* 668 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix times(DMatrix b) {
/* 678 */     Check.argument((this._n == b._m), "number of columns in A equals number of rows in B");
/*     */     
/* 680 */     DMatrix c = new DMatrix(this._m, b._n);
/* 681 */     double[][] aa = this._a;
/* 682 */     double[][] ba = b._a;
/* 683 */     double[][] ca = c._a;
/* 684 */     double[] bj = new double[this._n];
/* 685 */     for (int j = 0; j < b._n; j++) {
/* 686 */       for (int k = 0; k < this._n; k++)
/* 687 */         bj[k] = ba[k][j]; 
/* 688 */       for (int i = 0; i < this._m; i++) {
/* 689 */         double[] ai = aa[i];
/* 690 */         double s = 0.0D;
/* 691 */         for (int m = 0; m < this._n; m++)
/* 692 */           s += ai[m] * bj[m]; 
/* 693 */         ca[i][j] = s;
/*     */       } 
/*     */     } 
/* 696 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double trace() {
/* 704 */     int mn = Math.min(this._m, this._n);
/* 705 */     double t = 0.0D;
/* 706 */     for (int i = 0; i < mn; i++)
/* 707 */       t += this._a[i][i]; 
/* 708 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DMatrix random(int m, int n) {
/* 719 */     DMatrix x = new DMatrix(m, n);
/* 720 */     Array.rand(x._a);
/* 721 */     return x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DMatrix identity(int m, int n) {
/* 731 */     DMatrix x = new DMatrix(m, n);
/* 732 */     double[][] xa = x._a;
/* 733 */     int mn = Math.min(m, n);
/* 734 */     for (int i = 0; i < mn; i++)
/* 735 */       xa[i][i] = 1.0D; 
/* 736 */     return x;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 740 */     if (this == obj)
/* 741 */       return true; 
/* 742 */     if (obj == null || getClass() != obj.getClass())
/* 743 */       return false; 
/* 744 */     DMatrix that = (DMatrix)obj;
/* 745 */     if (this._m != that._m || this._n != that._n)
/* 746 */       return false; 
/* 747 */     double[][] a = this._a;
/* 748 */     double[][] b = that._a;
/* 749 */     for (int i = 0; i < this._m; i++) {
/* 750 */       for (int j = 0; j < this._n; j++) {
/* 751 */         if (a[i][j] != b[i][j])
/* 752 */           return false; 
/*     */       } 
/*     */     } 
/* 755 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 759 */     int h = this._m ^ this._n;
/* 760 */     for (int i = 0; i < this._m; i++) {
/* 761 */       for (int j = 0; j < this._n; j++) {
/* 762 */         long bits = Double.doubleToLongBits(this._a[i][j]);
/* 763 */         h ^= (int)(bits ^ bits >>> 32L);
/*     */       } 
/*     */     } 
/* 766 */     return h;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 770 */     String ls = System.getProperty("line.separator");
/* 771 */     StringBuffer sb = new StringBuffer();
/* 772 */     String[][] s = format(this._a);
/* 773 */     int max = maxlen(s);
/* 774 */     String format = "%" + max + "s";
/* 775 */     sb.append("[[");
/* 776 */     int ncol = 77 / (max + 2);
/* 777 */     if (ncol >= 5)
/* 778 */       ncol = ncol / 5 * 5; 
/* 779 */     for (int i = 0; i < this._m; i++) {
/* 780 */       int nrow = 1 + (this._n - 1) / ncol;
/* 781 */       if (i > 0)
/* 782 */         sb.append(" ["); 
/* 783 */       for (int irow = 0, j = 0; irow < nrow; irow++) {
/* 784 */         for (int icol = 0; icol < ncol && j < this._n; icol++, j++) {
/* 785 */           sb.append(String.format(format, new Object[] { s[i][j] }));
/* 786 */           if (j < this._n - 1)
/* 787 */             sb.append(", "); 
/*     */         } 
/* 789 */         if (j < this._n) {
/* 790 */           sb.append(ls);
/* 791 */           sb.append("  ");
/*     */         }
/* 793 */         else if (i < this._m - 1) {
/* 794 */           sb.append("],");
/* 795 */           sb.append(ls);
/*     */         } else {
/* 797 */           sb.append("]]");
/* 798 */           sb.append(ls);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 803 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DMatrix(int m, int n, double[][] a) {
/* 818 */     this._m = m;
/* 819 */     this._n = n;
/* 820 */     this._a = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkI(int i) {
/* 831 */     if (i < 0 || i >= this._m)
/* 832 */       Check.argument((0 <= i && i < this._m), "row index i=" + i + " is in bounds"); 
/*     */   }
/*     */   
/*     */   private void checkJ(int j) {
/* 836 */     if (j < 0 || j >= this._n)
/* 837 */       Check.argument((0 <= j && j < this._n), "column index j=" + j + " is in bounds"); 
/*     */   }
/*     */   
/*     */   private void checkI(int i0, int i1) {
/* 841 */     checkI(i0); checkI(i1); Check.argument((i0 <= i1), "i0<=i1");
/*     */   }
/*     */   
/*     */   private void checkJ(int j0, int j1) {
/* 845 */     checkJ(j0); checkJ(j1); Check.argument((j0 <= j1), "j0<=j1");
/*     */   }
/*     */   
/*     */   private static String[][] format(double[][] d) {
/*     */     String f;
/* 850 */     int m = d.length;
/* 851 */     int n = (d[0]).length;
/* 852 */     int pg = 6;
/* 853 */     String fg = "% ." + pg + "g";
/* 854 */     int pemax = -1;
/* 855 */     int pfmax = -1;
/* 856 */     for (int i = 0; i < m; i++) {
/* 857 */       for (int k = 0; k < n; k++) {
/* 858 */         String str = String.format(fg, new Object[] { Double.valueOf(d[i][k]) });
/* 859 */         str = clean(str);
/* 860 */         int ls = str.length();
/* 861 */         if (str.contains("e")) {
/* 862 */           int pe = (ls > 7) ? (ls - 7) : 0;
/* 863 */           if (pemax < pe)
/* 864 */             pemax = pe; 
/*     */         } else {
/* 866 */           int ip = str.indexOf('.');
/* 867 */           int pf = (ip >= 0) ? (ls - 1 - ip) : 0;
/* 868 */           if (pfmax < pf)
/* 869 */             pfmax = pf; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 873 */     String[][] s = new String[m][n];
/*     */     
/* 875 */     if (pemax >= 0) {
/* 876 */       if (pfmax > pg - 1)
/* 877 */         pfmax = pg - 1; 
/* 878 */       int pe = (pemax > pfmax) ? pemax : pfmax;
/* 879 */       f = "% ." + pe + "e";
/*     */     } else {
/* 881 */       int pf = pfmax;
/* 882 */       f = "% ." + pf + "f";
/*     */     } 
/* 884 */     for (int j = 0; j < m; j++) {
/* 885 */       for (int k = 0; k < n; k++) {
/* 886 */         s[j][k] = String.format(f, new Object[] { Double.valueOf(d[j][k]) });
/*     */       } 
/*     */     } 
/* 889 */     return s;
/*     */   }
/*     */   private static String clean(String s) {
/* 892 */     int len = s.length();
/* 893 */     int iend = s.indexOf('e');
/* 894 */     if (iend < 0)
/* 895 */       iend = s.indexOf('E'); 
/* 896 */     if (iend < 0)
/* 897 */       iend = len; 
/* 898 */     int ibeg = iend;
/* 899 */     if (s.indexOf('.') > 0) {
/* 900 */       while (ibeg > 0 && s.charAt(ibeg - 1) == '0')
/* 901 */         ibeg--; 
/* 902 */       if (ibeg > 0 && s.charAt(ibeg - 1) == '.')
/* 903 */         ibeg--; 
/*     */     } 
/* 905 */     if (ibeg < iend) {
/* 906 */       String sb = s.substring(0, ibeg);
/* 907 */       s = (iend < len) ? (sb + s.substring(iend, len)) : sb;
/*     */     } 
/* 909 */     return s;
/*     */   }
/*     */   private static int maxlen(String[][] s) {
/* 912 */     int max = 0;
/* 913 */     int m = s.length;
/* 914 */     int n = (s[0]).length;
/* 915 */     for (int i = 0; i < m; i++) {
/* 916 */       for (int j = 0; j < n; j++) {
/* 917 */         int len = s[i][j].length();
/* 918 */         if (max < len)
/* 919 */           max = len; 
/*     */       } 
/*     */     } 
/* 922 */     return max;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/DMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */