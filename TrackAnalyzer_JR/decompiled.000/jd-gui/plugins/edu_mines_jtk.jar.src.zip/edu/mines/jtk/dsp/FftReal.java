/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FftReal
/*     */ {
/*     */   private int _nfft;
/*     */   
/*     */   public FftReal(int nfft) {
/*  61 */     Check.argument((nfft % 2 == 0 && Pfacc.nfftValid(nfft / 2)), "nfft=" + nfft + " is valid FFT length");
/*     */ 
/*     */     
/*  64 */     this._nfft = nfft;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int nfftSmall(int n) {
/*  77 */     Check.argument((n <= 1441440), "n does not exceed 1441440");
/*  78 */     return 2 * Pfacc.nfftSmall((n + 1) / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int nfftFast(int n) {
/*  91 */     Check.argument((n <= 1441440), "n does not exceed 1441440");
/*  92 */     return 2 * Pfacc.nfftFast((n + 1) / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNfft() {
/* 100 */     return this._nfft;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realToComplex(int sign, float[] rx, float[] cy) {
/* 112 */     checkSign(sign);
/* 113 */     checkArray(this._nfft, rx, "rx");
/* 114 */     checkArray(this._nfft + 2, cy, "cy");
/* 115 */     int n = this._nfft;
/* 116 */     while (--n >= 0)
/* 117 */       cy[n] = 0.5F * rx[n]; 
/* 118 */     Pfacc.transform(sign, this._nfft / 2, cy);
/* 119 */     cy[this._nfft] = 2.0F * (cy[0] - cy[1]);
/* 120 */     cy[0] = 2.0F * (cy[0] + cy[1]);
/* 121 */     cy[this._nfft + 1] = 0.0F;
/* 122 */     cy[1] = 0.0F;
/* 123 */     double theta = sign * 2.0D * Math.PI / this._nfft;
/* 124 */     double wt = Math.sin(0.5D * theta);
/* 125 */     double wpr = -2.0D * wt * wt;
/* 126 */     double wpi = Math.sin(theta);
/* 127 */     double wr = 1.0D + wpr;
/* 128 */     double wi = wpi;
/* 129 */     for (int j = 2, k = this._nfft - 2; j <= k; j += 2, k -= 2) {
/* 130 */       float sumr = cy[j] + cy[k];
/* 131 */       float sumi = cy[j + 1] + cy[k + 1];
/* 132 */       float difr = cy[j] - cy[k];
/* 133 */       float difi = cy[j + 1] - cy[k + 1];
/* 134 */       float tmpr = (float)(wi * difr + wr * sumi);
/* 135 */       float tmpi = (float)(wi * sumi - wr * difr);
/* 136 */       cy[j] = sumr + tmpr;
/* 137 */       cy[j + 1] = tmpi + difi;
/* 138 */       cy[k] = sumr - tmpr;
/* 139 */       cy[k + 1] = tmpi - difi;
/* 140 */       wt = wr;
/* 141 */       wr += wr * wpr - wi * wpi;
/* 142 */       wi += wi * wpr + wt * wpi;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToReal(int sign, float[] cx, float[] ry) {
/* 155 */     checkSign(sign);
/* 156 */     checkArray(this._nfft + 2, cx, "cx");
/* 157 */     checkArray(this._nfft, ry, "ry");
/* 158 */     if (cx != ry) {
/* 159 */       int n = this._nfft;
/* 160 */       while (--n >= 2)
/* 161 */         ry[n] = cx[n]; 
/*     */     } 
/* 163 */     ry[1] = cx[0] - cx[this._nfft];
/* 164 */     ry[0] = cx[0] + cx[this._nfft];
/* 165 */     double theta = -sign * 2.0D * Math.PI / this._nfft;
/* 166 */     double wt = Math.sin(0.5D * theta);
/* 167 */     double wpr = -2.0D * wt * wt;
/* 168 */     double wpi = Math.sin(theta);
/* 169 */     double wr = 1.0D + wpr;
/* 170 */     double wi = wpi;
/* 171 */     for (int j = 2, k = this._nfft - 2; j <= k; j += 2, k -= 2) {
/* 172 */       float sumr = ry[j] + ry[k];
/* 173 */       float sumi = ry[j + 1] + ry[k + 1];
/* 174 */       float difr = ry[j] - ry[k];
/* 175 */       float difi = ry[j + 1] - ry[k + 1];
/* 176 */       float tmpr = (float)(wi * difr - wr * sumi);
/* 177 */       float tmpi = (float)(wi * sumi + wr * difr);
/* 178 */       ry[j] = sumr + tmpr;
/* 179 */       ry[j + 1] = tmpi + difi;
/* 180 */       ry[k] = sumr - tmpr;
/* 181 */       ry[k + 1] = tmpi - difi;
/* 182 */       wt = wr;
/* 183 */       wr += wr * wpr - wi * wpi;
/* 184 */       wi += wi * wpr + wt * wpi;
/*     */     } 
/* 186 */     Pfacc.transform(sign, this._nfft / 2, ry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realToComplex1(int sign, int n2, float[][] rx, float[][] cy) {
/* 199 */     checkSign(sign);
/* 200 */     checkArray(this._nfft, n2, rx, "rx");
/* 201 */     checkArray(this._nfft + 2, n2, cy, "cy");
/* 202 */     for (int i2 = 0; i2 < n2; i2++) {
/* 203 */       realToComplex(sign, rx[i2], cy[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToReal1(int sign, int n2, float[][] cx, float[][] ry) {
/* 216 */     checkSign(sign);
/* 217 */     checkArray(this._nfft + 2, n2, cx, "cx");
/* 218 */     checkArray(this._nfft, n2, ry, "ry");
/* 219 */     for (int i2 = 0; i2 < n2; i2++) {
/* 220 */       complexToReal(sign, cx[i2], ry[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realToComplex2(int sign, int n1, float[][] rx, float[][] cy) {
/* 233 */     checkSign(sign);
/* 234 */     checkArray(n1, this._nfft, rx, "rx");
/* 235 */     checkArray(2 * n1, this._nfft / 2 + 1, cy, "cy");
/*     */ 
/*     */ 
/*     */     
/* 239 */     for (int i1 = n1 - 1, j1 = i1 * 2; i1 >= 0; i1--, j1 -= 2) {
/* 240 */       for (int i2 = this._nfft - 2, j = i2 / 2; i2 >= 0; i2 -= 2, j--) {
/* 241 */         cy[j][j1] = 0.5F * rx[i2][i1];
/* 242 */         cy[j][j1 + 1] = 0.5F * rx[i2 + 1][i1];
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 247 */     Pfacc.transform2a(sign, n1, this._nfft / 2, cy);
/*     */ 
/*     */     
/* 250 */     float[] cy0 = cy[0];
/* 251 */     float[] cyn = cy[this._nfft / 2];
/* 252 */     for (int i = 2 * n1 - 2; i >= 0; i -= 2) {
/* 253 */       cyn[i] = 2.0F * (cy0[i] - cy0[i + 1]);
/* 254 */       cy0[i] = 2.0F * (cy0[i] + cy0[i + 1]);
/* 255 */       cyn[i + 1] = 0.0F;
/* 256 */       cy0[i + 1] = 0.0F;
/*     */     } 
/* 258 */     double theta = sign * 2.0D * Math.PI / this._nfft;
/* 259 */     double wt = Math.sin(0.5D * theta);
/* 260 */     double wpr = -2.0D * wt * wt;
/* 261 */     double wpi = Math.sin(theta);
/* 262 */     double wr = 1.0D + wpr;
/* 263 */     double wi = wpi;
/* 264 */     for (int j2 = 1, k2 = this._nfft / 2 - 1; j2 <= k2; j2++, k2--) {
/* 265 */       float[] cyj2 = cy[j2];
/* 266 */       float[] cyk2 = cy[k2];
/* 267 */       for (int j = 0, k = 0; j < n1; j++, k += 2) {
/* 268 */         float sumr = cyj2[k] + cyk2[k];
/* 269 */         float sumi = cyj2[k + 1] + cyk2[k + 1];
/* 270 */         float difr = cyj2[k] - cyk2[k];
/* 271 */         float difi = cyj2[k + 1] - cyk2[k + 1];
/* 272 */         float tmpr = (float)(wi * difr + wr * sumi);
/* 273 */         float tmpi = (float)(wi * sumi - wr * difr);
/* 274 */         cyj2[k] = sumr + tmpr;
/* 275 */         cyj2[k + 1] = tmpi + difi;
/* 276 */         cyk2[k] = sumr - tmpr;
/* 277 */         cyk2[k + 1] = tmpi - difi;
/*     */       } 
/* 279 */       wt = wr;
/* 280 */       wr += wr * wpr - wi * wpi;
/* 281 */       wi += wi * wpr + wt * wpi;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToReal2(int sign, int n1, float[][] cx, float[][] ry) {
/* 295 */     checkSign(sign);
/* 296 */     checkArray(2 * n1, this._nfft / 2 + 1, cx, "cx");
/* 297 */     checkArray(n1, this._nfft, ry, "ry");
/*     */ 
/*     */ 
/*     */     
/* 301 */     for (int i1 = 0, j1 = 0; j1 < n1; i1 += 2, j1++) {
/* 302 */       float cx0 = cx[0][i1];
/* 303 */       float cxn = cx[this._nfft / 2][i1];
/* 304 */       for (int i2 = this._nfft / 2 - 1, i = 2 * i2; i2 > 0; i2--, i -= 2) {
/* 305 */         ry[i][j1] = cx[i2][i1];
/* 306 */         ry[i + 1][j1] = cx[i2][i1 + 1];
/*     */       } 
/* 308 */       ry[1][j1] = cx0 - cxn;
/* 309 */       ry[0][j1] = cx0 + cxn;
/*     */     } 
/*     */ 
/*     */     
/* 313 */     double theta = -sign * 2.0D * Math.PI / this._nfft;
/* 314 */     double wt = Math.sin(0.5D * theta);
/* 315 */     double wpr = -2.0D * wt * wt;
/* 316 */     double wpi = Math.sin(theta);
/* 317 */     double wr = 1.0D + wpr;
/* 318 */     double wi = wpi;
/* 319 */     for (int j2 = 2, k2 = this._nfft - 2; j2 <= k2; j2 += 2, k2 -= 2) {
/* 320 */       float[] ryj2r = ry[j2];
/* 321 */       float[] ryj2i = ry[j2 + 1];
/* 322 */       float[] ryk2r = ry[k2];
/* 323 */       float[] ryk2i = ry[k2 + 1];
/* 324 */       for (int i = 0; i < n1; i++) {
/* 325 */         float sumr = ryj2r[i] + ryk2r[i];
/* 326 */         float sumi = ryj2i[i] + ryk2i[i];
/* 327 */         float difr = ryj2r[i] - ryk2r[i];
/* 328 */         float difi = ryj2i[i] - ryk2i[i];
/* 329 */         float tmpr = (float)(wi * difr - wr * sumi);
/* 330 */         float tmpi = (float)(wi * sumi + wr * difr);
/* 331 */         ryj2r[i] = sumr + tmpr;
/* 332 */         ryj2i[i] = tmpi + difi;
/* 333 */         ryk2r[i] = sumr - tmpr;
/* 334 */         ryk2i[i] = tmpi - difi;
/*     */       } 
/* 336 */       wt = wr;
/* 337 */       wr += wr * wpr - wi * wpi;
/* 338 */       wi += wi * wpr + wt * wpi;
/*     */     } 
/*     */ 
/*     */     
/* 342 */     Pfacc.transform2b(sign, n1, this._nfft / 2, ry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void realToComplex1(int sign, int n2, int n3, float[][][] rx, float[][][] cy) {
/* 359 */     checkSign(sign);
/* 360 */     checkArray(this._nfft, n2, n3, rx, "rx");
/* 361 */     checkArray(this._nfft + 2, n2, n3, cy, "cy");
/* 362 */     for (int i3 = 0; i3 < n3; i3++) {
/* 363 */       realToComplex1(sign, n2, rx[i3], cy[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complexToReal1(int sign, int n2, int n3, float[][][] cx, float[][][] ry) {
/* 380 */     checkSign(sign);
/* 381 */     checkArray(this._nfft + 2, n2, n3, cx, "cx");
/* 382 */     checkArray(this._nfft, n2, n3, ry, "ry");
/* 383 */     for (int i3 = 0; i3 < n3; i3++) {
/* 384 */       complexToReal1(sign, n2, cx[i3], ry[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, float[] rx) {
/* 395 */     float s = 1.0F / this._nfft;
/* 396 */     while (--n1 >= 0) {
/* 397 */       rx[n1] = rx[n1] * s;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, int n2, float[][] rx) {
/* 409 */     for (int i2 = 0; i2 < n2; i2++) {
/* 410 */       scale(n1, rx[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scale(int n1, int n2, int n3, float[][][] rx) {
/* 423 */     for (int i3 = 0; i3 < n3; i3++) {
/* 424 */       scale(n1, n2, rx[i3]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkSign(int sign) {
/* 433 */     Check.argument((sign == 1 || sign == -1), "sign equals 1 or -1");
/*     */   }
/*     */   
/*     */   private static void checkArray(int n, float[] a, String name) {
/* 437 */     Check.argument((a.length >= n), "dimensions of " + name + " are valid");
/*     */   }
/*     */   
/*     */   private static void checkArray(int n1, int n2, float[][] a, String name) {
/* 441 */     boolean ok = (a.length >= n2);
/* 442 */     for (int i2 = 0; i2 < n2 && ok; i2++)
/* 443 */       ok = ((a[i2]).length >= n1); 
/* 444 */     Check.argument(ok, "dimensions of " + name + " are valid");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkArray(int n1, int n2, int n3, float[][][] a, String name) {
/* 450 */     boolean ok = (a.length >= n3);
/* 451 */     for (int i3 = 0; i3 < n3 && ok; i3++) {
/* 452 */       ok = ((a[i3]).length >= n2);
/* 453 */       for (int i2 = 0; i2 < n2 && ok; i2++) {
/* 454 */         ok = ((a[i3][i2]).length >= n1);
/*     */       }
/*     */     } 
/* 457 */     Check.argument(ok, "dimensions of " + name + " are valid");
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/FftReal.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */