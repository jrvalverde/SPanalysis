/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.awt.ColorMap;
/*     */ import edu.mines.jtk.awt.ColorMapListener;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.ogl.GlTextureName;
/*     */ import edu.mines.jtk.util.Clips;
/*     */ import edu.mines.jtk.util.Direct;
/*     */ import edu.mines.jtk.util.Float3;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImagePanel
/*     */   extends AxisAlignedPanel
/*     */ {
/*     */   private Axis _axis;
/*     */   private Sampling _sx;
/*     */   private Sampling _sy;
/*     */   private Sampling _sz;
/*     */   private Float3 _f3;
/*     */   private double _xmin;
/*     */   private double _ymin;
/*     */   private double _zmin;
/*     */   private double _xmax;
/*     */   private double _ymax;
/*     */   private double _zmax;
/*     */   Clips _clips;
/*     */   float _clipMin;
/*     */   float _clipMax;
/*     */   private ColorMap _colorMap;
/*     */   int _ls;
/*     */   int _lt;
/*     */   int _ms;
/*     */   int _mt;
/*     */   int _ns;
/*     */   int _nt;
/*     */   double _ds;
/*     */   double _dt;
/*     */   double _fs;
/*     */   double _ft;
/*     */   private GlTextureName[][] _tn;
/*     */   private boolean _texturesDirty;
/*     */   int _kxmin;
/*     */   int _kymin;
/*     */   int _kzmin;
/*     */   int _kxmax;
/*     */   int _kymax;
/*     */   int _kzmax;
/*     */   int _ksmin;
/*     */   int _ktmin;
/*     */   int _ksmax;
/*     */   int _ktmax;
/*     */   int _jsmin;
/*     */   int _jtmin;
/*     */   int _jsmax;
/*     */   int _jtmax;
/*     */   IntBuffer _pixels;
/*     */   float[][] _floats;
/*     */   
/*     */   public BoxConstraint getBoxConstraint() {
/*     */     return new BoxConstraint(this._sx, this._sy, this._sz);
/*     */   }
/*     */   
/*     */   public void setColorModel(IndexColorModel colorModel) {
/*     */     this._colorMap.setColorModel(colorModel);
/*     */     this._texturesDirty = true;
/*     */     dirtyDraw();
/*     */   }
/*     */   
/*     */   public IndexColorModel getColorModel() {
/*     */     return this._colorMap.getColorModel();
/*     */   }
/*     */   
/*     */   public ImagePanel(Sampling sx, Sampling sy, Sampling sz, Float3 f3) {
/* 179 */     this._clipMin = 0.0F;
/* 180 */     this._clipMax = 1.0F;
/*     */ 
/*     */     
/* 183 */     this._colorMap = new ColorMap(this._clipMin, this._clipMax, ColorMap.GRAY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     this._texturesDirty = true;
/*     */     this._sx = sx;
/*     */     this._sy = sy;
/*     */     this._sz = sz;
/*     */     this._f3 = f3;
/*     */     this._clips = new Clips(this._f3);
/*     */   }
/*     */   public void setClips(double clipMin, double clipMax) { this._clips.setClips(clipMin, clipMax);
/*     */     this._texturesDirty = true;
/*     */     dirtyDraw(); } public float getClipMin() { return this._clips.getClipMin(); } public float getClipMax() {
/*     */     return this._clips.getClipMax();
/*     */   } public void setPercentiles(double percMin, double percMax) {
/*     */     this._clips.setPercentiles(percMin, percMax);
/*     */     this._texturesDirty = true;
/*     */     dirtyDraw();
/*     */   } public float getPercentileMin() {
/*     */     return this._clips.getPercentileMin();
/*     */   } private void updateClipMinMax() {
/* 245 */     float clipMin = this._clips.getClipMin();
/* 246 */     float clipMax = this._clips.getClipMax();
/* 247 */     if (this._clipMin != clipMin || this._clipMax != clipMax) {
/* 248 */       this._clipMin = clipMin;
/* 249 */       this._clipMax = clipMax;
/* 250 */       this._colorMap.setValueRange(this._clipMin, this._clipMax);
/* 251 */       this._texturesDirty = true;
/*     */     } 
/*     */   }
/*     */   public float getPercentileMax() {
/*     */     return this._clips.getPercentileMax();
/*     */   }
/*     */   private void drawTextures() {
/* 258 */     AxisAlignedFrame frame = getFrame();
/* 259 */     if (frame == null) {
/*     */       return;
/*     */     }
/*     */     
/* 263 */     Axis axis = frame.getAxis();
/* 264 */     if (this._axis != axis) {
/* 265 */       updateSampling(axis, this._sx, this._sy, this._sz);
/*     */     }
/*     */     
/* 268 */     Point3 qmin = frame.getCornerMin();
/* 269 */     Point3 qmax = frame.getCornerMax();
/* 270 */     double xmin = qmin.x;
/* 271 */     double ymin = qmin.y;
/* 272 */     double zmin = qmin.z;
/* 273 */     double xmax = qmax.x;
/* 274 */     double ymax = qmax.y;
/* 275 */     double zmax = qmax.z;
/* 276 */     if (this._xmin != xmin || this._ymin != ymin || this._zmin != zmin || this._xmax != xmax || this._ymax != ymax || this._zmax != zmax)
/*     */     {
/* 278 */       updateBoundsAndTextures(xmin, ymin, zmin, xmax, ymax, zmax);
/*     */     }
/*     */     
/* 281 */     if (this._texturesDirty) {
/* 282 */       updateTextures();
/*     */     }
/*     */     
/* 285 */     Gl.glShadeModel(7424);
/* 286 */     Gl.glEnable(3553);
/* 287 */     Gl.glTexEnvf(8960, 8704, 7681.0F);
/*     */ 
/*     */     
/* 290 */     Gl.glEnable(32823);
/* 291 */     Gl.glPolygonOffset(1.0F, 1.0F);
/*     */ 
/*     */     
/* 294 */     float sa = 0.5F / this._ls;
/* 295 */     float ta = 0.5F / this._lt;
/* 296 */     float sb = 1.0F / this._ls;
/* 297 */     float tb = 1.0F / this._lt;
/*     */ 
/*     */     
/* 300 */     double xa = 0.5D * (this._xmin + this._xmax);
/* 301 */     double ya = 0.5D * (this._ymin + this._ymax);
/* 302 */     double za = 0.5D * (this._zmin + this._zmax);
/*     */ 
/*     */     
/* 305 */     for (int jt = this._jtmin; jt <= this._jtmax; jt++) {
/* 306 */       for (int js = this._jsmin; js <= this._jsmax; js++) {
/*     */ 
/*     */         
/* 309 */         int ks0 = js * (this._ls - 1);
/* 310 */         int kt0 = jt * (this._lt - 1);
/* 311 */         int ks1 = ks0 + this._ls - 1;
/* 312 */         int kt1 = kt0 + this._lt - 1;
/* 313 */         ks0 = MathPlus.max(this._ksmin, ks0);
/* 314 */         kt0 = MathPlus.max(this._ktmin, kt0);
/* 315 */         ks1 = MathPlus.min(this._ksmax, ks1);
/* 316 */         kt1 = MathPlus.min(this._ktmax, kt1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 328 */         float s0 = sa + (ks0 % (this._ls - 1)) * sb;
/* 329 */         float t0 = ta + (kt0 % (this._lt - 1)) * tb;
/* 330 */         float s1 = s0 + (ks1 - ks0) * sb;
/* 331 */         float t1 = t0 + (kt1 - kt0) * tb;
/*     */ 
/*     */         
/* 334 */         GlTextureName tn = this._tn[jt][js];
/* 335 */         Gl.glBindTexture(3553, tn.name());
/* 336 */         Gl.glBegin(9);
/* 337 */         if (this._axis == Axis.X) {
/* 338 */           double y0 = this._fs + ks0 * this._ds;
/* 339 */           double z0 = this._ft + kt0 * this._dt;
/* 340 */           double y1 = this._fs + ks1 * this._ds;
/* 341 */           double z1 = this._ft + kt1 * this._dt;
/* 342 */           Gl.glTexCoord2f(s0, t0); Gl.glVertex3d(xa, y0, z0);
/* 343 */           Gl.glTexCoord2f(s1, t0); Gl.glVertex3d(xa, y1, z0);
/* 344 */           Gl.glTexCoord2f(s1, t1); Gl.glVertex3d(xa, y1, z1);
/* 345 */           Gl.glTexCoord2f(s0, t1); Gl.glVertex3d(xa, y0, z1);
/* 346 */         } else if (this._axis == Axis.Y) {
/* 347 */           double x0 = this._fs + ks0 * this._ds;
/* 348 */           double z0 = this._ft + kt0 * this._dt;
/* 349 */           double x1 = this._fs + ks1 * this._ds;
/* 350 */           double z1 = this._ft + kt1 * this._dt;
/* 351 */           Gl.glTexCoord2f(s0, t0); Gl.glVertex3d(x0, ya, z0);
/* 352 */           Gl.glTexCoord2f(s1, t0); Gl.glVertex3d(x1, ya, z0);
/* 353 */           Gl.glTexCoord2f(s1, t1); Gl.glVertex3d(x1, ya, z1);
/* 354 */           Gl.glTexCoord2f(s0, t1); Gl.glVertex3d(x0, ya, z1);
/*     */         } else {
/* 356 */           double x0 = this._fs + ks0 * this._ds;
/* 357 */           double y0 = this._ft + kt0 * this._dt;
/* 358 */           double x1 = this._fs + ks1 * this._ds;
/* 359 */           double y1 = this._ft + kt1 * this._dt;
/* 360 */           Gl.glTexCoord2f(s0, t0); Gl.glVertex3d(x0, y0, za);
/* 361 */           Gl.glTexCoord2f(s1, t0); Gl.glVertex3d(x1, y0, za);
/* 362 */           Gl.glTexCoord2f(s1, t1); Gl.glVertex3d(x1, y1, za);
/* 363 */           Gl.glTexCoord2f(s0, t1); Gl.glVertex3d(x0, y1, za);
/*     */         } 
/* 365 */         Gl.glEnd();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 370 */     Gl.glBindTexture(3553, 0);
/* 371 */     Gl.glDisable(3553); } public void addColorMapListener(ColorMapListener cml) { this._colorMap.addListener(cml); } public void removeColorMapListener(ColorMapListener cml) { this._colorMap.removeListener(cml); }
/*     */   protected void draw(DrawContext dc) {
/*     */     updateClipMinMax();
/*     */     drawTextures();
/*     */   }
/*     */   private void updateSampling(Axis axis, Sampling sx, Sampling sy, Sampling sz) {
/* 377 */     disposeTextures();
/* 378 */     int nx = sx.getCount();
/* 379 */     int ny = sy.getCount();
/* 380 */     int nz = sz.getCount();
/* 381 */     double dx = sx.getDelta();
/* 382 */     double dy = sy.getDelta();
/* 383 */     double dz = sz.getDelta();
/* 384 */     double fx = sx.getFirst();
/* 385 */     double fy = sy.getFirst();
/* 386 */     double fz = sz.getFirst();
/* 387 */     this._axis = axis;
/* 388 */     this._sx = sx;
/* 389 */     this._sy = sy;
/* 390 */     this._sz = sz;
/* 391 */     this._ls = 64;
/* 392 */     this._lt = 64;
/* 393 */     if (this._axis == Axis.X) {
/* 394 */       this._ns = ny;
/* 395 */       this._ds = dy;
/* 396 */       this._fs = fy;
/* 397 */       this._nt = nz;
/* 398 */       this._dt = dz;
/* 399 */       this._ft = fz;
/* 400 */     } else if (this._axis == Axis.Y) {
/* 401 */       this._ns = nx;
/* 402 */       this._ds = dx;
/* 403 */       this._fs = fx;
/* 404 */       this._nt = nz;
/* 405 */       this._dt = dz;
/* 406 */       this._ft = fz;
/*     */     } else {
/* 408 */       this._ns = nx;
/* 409 */       this._ds = dx;
/* 410 */       this._fs = fx;
/* 411 */       this._nt = ny;
/* 412 */       this._dt = dy;
/* 413 */       this._ft = fy;
/*     */     } 
/* 415 */     this._ms = 1 + (this._ns - 2) / (this._ls - 1);
/* 416 */     this._mt = 1 + (this._nt - 2) / (this._lt - 1);
/* 417 */     this._tn = new GlTextureName[this._mt][this._ms];
/* 418 */     this._kxmin = 0; this._kxmax = -1;
/* 419 */     this._kymin = 0; this._kymax = -1;
/* 420 */     this._kzmin = 0; this._kzmax = -1;
/* 421 */     this._ksmin = 0; this._ksmax = -1;
/* 422 */     this._ktmin = 0; this._ktmax = -1;
/* 423 */     this._jsmin = 0; this._jsmax = -1;
/* 424 */     this._jtmin = 0; this._jtmax = -1;
/* 425 */     this._pixels = Direct.newIntBuffer(this._ls * this._lt);
/* 426 */     this._floats = new float[this._ls][this._lt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateBoundsAndTextures(double xmin, double ymin, double zmin, double xmax, double ymax, double zmax) {
/* 433 */     this._xmin = MathPlus.max(xmin, this._sx.getFirst());
/* 434 */     this._ymin = MathPlus.max(ymin, this._sy.getFirst());
/* 435 */     this._zmin = MathPlus.max(zmin, this._sz.getFirst());
/* 436 */     this._xmax = MathPlus.min(xmax, this._sx.getLast());
/* 437 */     this._ymax = MathPlus.min(ymax, this._sy.getLast());
/* 438 */     this._zmax = MathPlus.min(zmax, this._sz.getLast());
/* 439 */     int kxmin = this._sx.indexOfNearest(this._xmin);
/* 440 */     int kymin = this._sy.indexOfNearest(this._ymin);
/* 441 */     int kzmin = this._sz.indexOfNearest(this._zmin);
/* 442 */     int kxmax = this._sx.indexOfNearest(this._xmax);
/* 443 */     int kymax = this._sy.indexOfNearest(this._ymax);
/* 444 */     int kzmax = this._sz.indexOfNearest(this._zmax);
/* 445 */     boolean stale = false;
/* 446 */     if (this._axis == Axis.X) {
/* 447 */       stale = (this._kxmin != kxmin);
/* 448 */       this._kxmin = kxmin;
/* 449 */       this._ksmin = this._kymin = kymin;
/* 450 */       this._ktmin = this._kzmin = kzmin;
/* 451 */       this._kxmax = kxmax;
/* 452 */       this._ksmax = this._kymax = kymax;
/* 453 */       this._ktmax = this._kzmax = kzmax;
/* 454 */     } else if (this._axis == Axis.Y) {
/* 455 */       stale = (this._kymin != kymin);
/* 456 */       this._ksmin = this._kxmin = kxmin;
/* 457 */       this._kymin = kymin;
/* 458 */       this._ktmin = this._kzmin = kzmin;
/* 459 */       this._ksmax = this._kxmax = kxmax;
/* 460 */       this._kymax = kymax;
/* 461 */       this._ktmax = this._kzmax = kzmax;
/*     */     } else {
/* 463 */       stale = (this._kzmin != kzmin);
/* 464 */       this._ksmin = this._kxmin = kxmin;
/* 465 */       this._ktmin = this._kymin = kymin;
/* 466 */       this._kzmin = kzmin;
/* 467 */       this._ksmax = this._kxmax = kxmax;
/* 468 */       this._ktmax = this._kymax = kymax;
/* 469 */       this._kzmax = kzmax;
/*     */     } 
/*     */ 
/*     */     
/* 473 */     int jsmin = this._ksmin / (this._ls - 1);
/* 474 */     int jtmin = this._ktmin / (this._lt - 1);
/* 475 */     int jsmax = MathPlus.max(0, this._ksmax - 1) / (this._ls - 1);
/* 476 */     int jtmax = MathPlus.max(0, this._ktmax - 1) / (this._lt - 1);
/*     */ 
/*     */ 
/*     */     
/* 480 */     ArrayList<GlTextureName> staleList = new ArrayList<GlTextureName>();
/* 481 */     for (int jt = this._jtmin; jt <= this._jtmax; jt++) {
/* 482 */       for (int js = this._jsmin; js <= this._jsmax; js++) {
/* 483 */         if ((stale || js < jsmin || jt < jtmin || jsmax < js || jtmax < jt) && 
/* 484 */           this._tn[jt][js] != null) {
/* 485 */           staleList.add(this._tn[jt][js]);
/* 486 */           this._tn[jt][js] = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 491 */     int nstale = staleList.size();
/*     */ 
/*     */ 
/*     */     
/* 495 */     for (int i = jtmin; i <= jtmax; i++) {
/* 496 */       for (int js = jsmin; js <= jsmax; js++) {
/* 497 */         GlTextureName tn = this._tn[i][js];
/* 498 */         if (tn == null) {
/* 499 */           if (!staleList.isEmpty()) {
/* 500 */             tn = staleList.remove(--nstale);
/*     */           } else {
/* 502 */             tn = makeTexture(js, i);
/*     */           } 
/* 504 */           this._tn[i][js] = tn;
/* 505 */           loadTexture(js, i);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 511 */     while (nstale > 0) {
/* 512 */       GlTextureName tn = staleList.remove(--nstale);
/* 513 */       tn.dispose();
/*     */     } 
/*     */ 
/*     */     
/* 517 */     this._jsmin = jsmin;
/* 518 */     this._jtmin = jtmin;
/* 519 */     this._jsmax = jsmax;
/* 520 */     this._jtmax = jtmax;
/*     */ 
/*     */     
/* 523 */     this._texturesDirty = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTextures() {
/* 529 */     for (int jt = this._jtmin; jt <= this._jtmax; jt++) {
/* 530 */       for (int js = this._jsmin; js <= this._jsmax; js++) {
/* 531 */         if (this._tn[jt][js] != null) {
/* 532 */           loadTexture(js, jt);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 537 */     this._texturesDirty = false;
/*     */   }
/*     */   
/*     */   private void disposeTextures() {
/* 541 */     if (this._tn != null) {
/* 542 */       for (int jt = 0; jt < this._mt; jt++) {
/* 543 */         for (int js = 0; js < this._ms; js++) {
/* 544 */           GlTextureName tn = this._tn[jt][js];
/* 545 */           if (tn != null)
/* 546 */             tn.dispose(); 
/*     */         } 
/*     */       } 
/* 549 */       this._tn = (GlTextureName[][])null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private GlTextureName makeTexture(int js, int jt) {
/* 554 */     Gl.glPixelStorei(3317, 1);
/* 555 */     GlTextureName tn = new GlTextureName();
/* 556 */     Gl.glBindTexture(3553, tn.name());
/* 557 */     Gl.glTexParameteri(3553, 10242, 10497);
/* 558 */     Gl.glTexParameteri(3553, 10243, 10497);
/* 559 */     Gl.glTexParameteri(3553, 10240, 9729);
/* 560 */     Gl.glTexParameteri(3553, 10241, 9729);
/* 561 */     Gl.glTexImage2D(3553, 0, 6408, this._ls, this._lt, 0, 6408, 5121, this._pixels);
/*     */     
/* 563 */     Gl.glBindTexture(3553, 0);
/* 564 */     return tn;
/*     */   }
/*     */   
/*     */   private void loadTexture(int js, int jt) {
/* 568 */     int ks = js * (this._ls - 1);
/* 569 */     int kt = jt * (this._lt - 1);
/* 570 */     int ls = MathPlus.min(this._ls, this._ns - ks);
/* 571 */     int lt = MathPlus.min(this._lt, this._nt - kt);
/* 572 */     if (this._axis == Axis.X) {
/* 573 */       this._f3.get12(lt, ls, kt, ks, this._kxmin, this._floats);
/* 574 */     } else if (this._axis == Axis.Y) {
/* 575 */       this._f3.get13(lt, ls, kt, this._kymin, ks, this._floats);
/* 576 */     } else if (this._axis == Axis.Z) {
/* 577 */       this._f3.get23(lt, ls, this._kzmin, kt, ks, this._floats);
/*     */     } 
/* 579 */     float fscale = 255.0F / (this._clipMax - this._clipMin);
/* 580 */     float fshift = this._clipMin;
/* 581 */     IndexColorModel icm = this._colorMap.getColorModel();
/* 582 */     for (int is = 0; is < ls; is++) {
/* 583 */       for (int it = 0; it < lt; it++) {
/* 584 */         float fi = (this._floats[is][it] - fshift) * fscale;
/* 585 */         if (fi < 0.0F)
/* 586 */           fi = 0.0F; 
/* 587 */         if (fi > 255.0F)
/* 588 */           fi = 255.0F; 
/* 589 */         int i = (int)(fi + 0.5F);
/* 590 */         int r = icm.getRed(i);
/* 591 */         int g = icm.getGreen(i);
/* 592 */         int b = icm.getBlue(i);
/* 593 */         int a = 255;
/* 594 */         int p = r & 0xFF | (g & 0xFF) << 8 | (b & 0xFF) << 16 | (a & 0xFF) << 24;
/* 595 */         this._pixels.put(is + it * this._ls, p);
/*     */       } 
/*     */     } 
/* 598 */     Gl.glPixelStorei(3317, 1);
/* 599 */     GlTextureName tn = this._tn[jt][js];
/* 600 */     Gl.glBindTexture(3553, tn.name());
/* 601 */     Gl.glTexSubImage2D(3553, 0, 0, 0, this._ls, this._lt, 6408, 5121, this._pixels);
/*     */     
/* 603 */     Gl.glBindTexture(3553, 0);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/ImagePanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */