/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LocalCorrelationFilter
/*      */ {
/*      */   private static final float C00 = 0.0F;
/*      */   private static final float C11 = 1.0F;
/*      */   private static final float C12 = 0.5F;
/*      */   private static final float C13 = 0.33333334F;
/*      */   private static final float C14 = 0.25F;
/*      */   private static final float C16 = 0.16666667F;
/*      */   private static final float C19 = 0.11111111F;
/*      */   private static final float C29 = 0.22222222F;
/*      */   private static final float C59 = 0.5555556F;
/*      */   private static final float C000 = 0.0F;
/*      */   private static final float C109 = 0.11111111F;
/*      */   private static final float C112 = 0.083333336F;
/*      */   private static final float C118 = 0.055555556F;
/*      */   private static final float C127 = 0.037037037F;
/*      */   private static final float C227 = 0.074074075F;
/*      */   private static final float C427 = 0.14814815F;
/*      */   private static final float C727 = 0.25925925F;
/*      */   
/*      */   public LocalCorrelationFilter(double sigma) {
/*   39 */     this(sigma, sigma, sigma);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalCorrelationFilter(double sigma1, double sigma2) {
/*   53 */     this(sigma1, sigma2, sigma2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalCorrelationFilter(double sigma1, double sigma2, double sigma3) {
/*   69 */     Check.argument((sigma1 >= 1.0D), "sigma1>=1.0");
/*   70 */     Check.argument((sigma2 >= 1.0D), "sigma2>=1.0");
/*   71 */     Check.argument((sigma3 >= 1.0D), "sigma3>=1.0");
/*   72 */     this._sigma1 = sigma1;
/*   73 */     this._sigma2 = sigma2;
/*   74 */     this._sigma3 = sigma3;
/*   75 */     this._rgf1 = new RecursiveGaussianFilter(sigma1 / MathPlus.sqrt(2.0D));
/*   76 */     this._rgf2 = new RecursiveGaussianFilter(sigma2 / MathPlus.sqrt(2.0D));
/*   77 */     this._rgf3 = new RecursiveGaussianFilter(sigma3 / MathPlus.sqrt(2.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(int lag, float[] f, float[] g, float[] c) {
/*   88 */     Check.argument((f != c), "f!=c");
/*   89 */     Check.argument((g != c), "g!=c");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   96 */     int n1 = f.length;
/*   97 */     int l1 = lag;
/*   98 */     int l1f = (l1 >= 0) ? ((l1 + 0) / 2) : ((l1 - 1) / 2);
/*   99 */     int l1g = (l1 >= 0) ? ((l1 + 1) / 2) : ((l1 + 0) / 2);
/*  100 */     double scale1 = MathPlus.sqrt(Math.PI) * this._sigma1 * MathPlus.exp(-0.25D * l1 * l1 / this._sigma1 * this._sigma1);
/*  101 */     float scale = (float)scale1;
/*  102 */     int i1min = MathPlus.max(MathPlus.abs(l1f), MathPlus.abs(l1g));
/*  103 */     int i1max = n1 - i1min;
/*  104 */     float[] h = new float[n1];
/*  105 */     for (int i1 = i1min; i1 < i1max; i1++) {
/*  106 */       c[i1] = scale * f[i1 - l1f] * g[i1 + l1g];
/*      */     }
/*  108 */     if (l1f != l1g) {
/*  109 */       shift(c, h);
/*      */     } else {
/*  111 */       Array.copy(c, h);
/*  112 */     }  this._rgf1.apply0(h, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(int lag1, int lag2, float[][] f, float[][] g, float[][] c) {
/*  126 */     Check.argument((f != c), "f!=c");
/*  127 */     Check.argument((g != c), "g!=c");
/*  128 */     int n1 = (f[0]).length;
/*  129 */     int l1 = lag1;
/*  130 */     int l1f = (l1 >= 0) ? ((l1 + 0) / 2) : ((l1 - 1) / 2);
/*  131 */     int l1g = (l1 >= 0) ? ((l1 + 1) / 2) : ((l1 + 0) / 2);
/*  132 */     int n2 = f.length;
/*  133 */     int l2 = lag2;
/*  134 */     int l2f = (l2 >= 0) ? ((l2 + 0) / 2) : ((l2 - 1) / 2);
/*  135 */     int l2g = (l2 >= 0) ? ((l2 + 1) / 2) : ((l2 + 0) / 2);
/*  136 */     double scale1 = MathPlus.sqrt(Math.PI) * this._sigma1 * MathPlus.exp(-0.25D * l1 * l1 / this._sigma1 * this._sigma1);
/*  137 */     double scale2 = MathPlus.sqrt(Math.PI) * this._sigma2 * MathPlus.exp(-0.25D * l2 * l2 / this._sigma2 * this._sigma2);
/*  138 */     float scale = (float)(scale1 * scale2);
/*  139 */     int i1min = MathPlus.max(MathPlus.abs(l1f), MathPlus.abs(l1g));
/*  140 */     int i1max = n1 - i1min;
/*  141 */     int i2min = MathPlus.max(MathPlus.abs(l2f), MathPlus.abs(l2g));
/*  142 */     int i2max = n2 - i2min;
/*  143 */     float[][] h = new float[n2][n1];
/*  144 */     for (int i2 = i2min; i2 < i2max; i2++) {
/*  145 */       float[] f2 = f[i2 - l2f];
/*  146 */       float[] g2 = g[i2 + l2g];
/*  147 */       float[] c2 = c[i2];
/*  148 */       for (int i1 = i1min; i1 < i1max; i1++) {
/*  149 */         c2[i1] = scale * f2[i1 - l1f] * g2[i1 + l1g];
/*      */       }
/*      */     } 
/*  152 */     if (l1f != l1g) {
/*  153 */       shift1(c, h);
/*      */     } else {
/*  155 */       Array.copy(c, h);
/*  156 */     }  if (l2f != l2g) {
/*  157 */       shift2(h, c);
/*      */     } else {
/*  159 */       Array.copy(h, c);
/*  160 */     }  this._rgf1.apply0X(c, h);
/*  161 */     this._rgf2.applyX0(h, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(int lag1, int lag2, int lag3, float[][][] f, float[][][] g, float[][][] c) {
/*  176 */     Check.argument((f != c), "f!=c");
/*  177 */     Check.argument((g != c), "g!=c");
/*  178 */     int n1 = (f[0][0]).length;
/*  179 */     int l1 = lag1;
/*  180 */     int l1f = (l1 >= 0) ? ((l1 + 0) / 2) : ((l1 - 1) / 2);
/*  181 */     int l1g = (l1 >= 0) ? ((l1 + 1) / 2) : ((l1 + 0) / 2);
/*  182 */     int n2 = (f[0]).length;
/*  183 */     int l2 = lag2;
/*  184 */     int l2f = (l2 >= 0) ? ((l2 + 0) / 2) : ((l2 - 1) / 2);
/*  185 */     int l2g = (l2 >= 0) ? ((l2 + 1) / 2) : ((l2 + 0) / 2);
/*  186 */     int n3 = f.length;
/*  187 */     int l3 = lag3;
/*  188 */     int l3f = (l3 >= 0) ? ((l3 + 0) / 2) : ((l3 - 1) / 2);
/*  189 */     int l3g = (l3 >= 0) ? ((l3 + 1) / 2) : ((l3 + 0) / 2);
/*  190 */     double scale1 = MathPlus.sqrt(Math.PI) * this._sigma1 * MathPlus.exp(-0.25D * l1 * l1 / this._sigma1 * this._sigma1);
/*  191 */     double scale2 = MathPlus.sqrt(Math.PI) * this._sigma2 * MathPlus.exp(-0.25D * l2 * l2 / this._sigma2 * this._sigma2);
/*  192 */     double scale3 = MathPlus.sqrt(Math.PI) * this._sigma3 * MathPlus.exp(-0.25D * l3 * l3 / this._sigma3 * this._sigma3);
/*  193 */     float scale = (float)(scale1 * scale2 * scale3);
/*  194 */     int i1min = MathPlus.max(MathPlus.abs(l1f), MathPlus.abs(l1g));
/*  195 */     int i1max = n1 - i1min;
/*  196 */     int i2min = MathPlus.max(MathPlus.abs(l2f), MathPlus.abs(l2g));
/*  197 */     int i2max = n2 - i2min;
/*  198 */     int i3min = MathPlus.max(MathPlus.abs(l3f), MathPlus.abs(l3g));
/*  199 */     int i3max = n3 - i3min;
/*  200 */     float[][][] h = new float[n3][n2][n1];
/*  201 */     for (int i3 = i3min; i3 < i3max; i3++) {
/*  202 */       for (int i2 = i2min; i2 < i2max; i2++) {
/*  203 */         float[] f32 = f[i3 - l3f][i2 - l2f];
/*  204 */         float[] g32 = g[i3 + l3g][i2 + l2g];
/*  205 */         float[] c32 = c[i3][i2];
/*  206 */         for (int i1 = i1min; i1 < i1max; i1++) {
/*  207 */           c32[i1] = scale * f32[i1 - l1f] * g32[i1 + l1g];
/*      */         }
/*      */       } 
/*      */     } 
/*  211 */     if (l1f != l1g) {
/*  212 */       shift1(c, h);
/*      */     } else {
/*  214 */       Array.copy(c, h);
/*  215 */     }  if (l2f != l2g) {
/*  216 */       shift2(h, c);
/*      */     } else {
/*  218 */       Array.copy(h, c);
/*  219 */     }  if (l3f != l3g) {
/*  220 */       shift3(c, h);
/*      */     } else {
/*  222 */       Array.copy(c, h);
/*  223 */     }  this._rgf1.apply0XX(h, c);
/*  224 */     this._rgf2.applyX0X(c, h);
/*  225 */     this._rgf3.applyXX0(h, c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(int l1min, int l1max, int j1c, int k1c, float[] f, float[] g, float[][] c) {
/*  243 */     int n1f = f.length;
/*  244 */     int n1c = c.length;
/*  245 */     float[] t = new float[n1f];
/*  246 */     for (int l1 = l1min; l1 <= l1max; l1++) {
/*  247 */       apply(l1, f, g, t);
/*  248 */       for (int i1c = 0; i1c < n1c; i1c++) {
/*  249 */         c[i1c][l1 - l1min] = t[j1c + i1c * k1c];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findMaxLags(float[] f, float[] g, int min, int max, byte[] lag) {
/*  499 */     int n = f.length;
/*  500 */     for (int i = 0; i < n; i++) {
/*  501 */       lag[i] = 0;
/*      */     }
/*      */     
/*  504 */     float[] c = new float[n];
/*  505 */     float[] cmax = new float[n];
/*  506 */     for (int j = 0; j < n; j++) {
/*  507 */       cmax[j] = -3.4028235E38F;
/*      */     }
/*      */     
/*  510 */     Lags lags = new Lags(min, max);
/*  511 */     int l = (min + max) / 2;
/*      */ 
/*      */     
/*  514 */     boolean done = false;
/*  515 */     while (!done) {
/*      */ 
/*      */       
/*  518 */       apply(l, f, g, c);
/*      */ 
/*      */ 
/*      */       
/*  522 */       lags.markLag(l);
/*      */ 
/*      */       
/*  525 */       boolean foundMax = false;
/*  526 */       for (int k = 0; k < n; k++) {
/*  527 */         float ci = c[k];
/*  528 */         if (ci > cmax[k]) {
/*  529 */           cmax[k] = ci;
/*  530 */           lag[k] = (byte)l;
/*  531 */           foundMax = true;
/*      */         } 
/*      */       } 
/*  534 */       if (foundMax) {
/*  535 */         lags.markMax(l);
/*      */       }
/*      */       
/*  538 */       int[] ls = lags.nextLag();
/*  539 */       if (ls == null) {
/*  540 */         done = true; continue;
/*      */       } 
/*  542 */       l = ls[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findMaxLags(float[][] f, float[][] g, int min1, int max1, int min2, int max2, byte[][] lag1, byte[][] lag2) {
/*  564 */     int n1 = (f[0]).length;
/*  565 */     int n2 = f.length;
/*  566 */     for (int i2 = 0; i2 < n2; i2++) {
/*  567 */       for (int i1 = 0; i1 < n1; i1++) {
/*  568 */         lag1[i2][i1] = 0;
/*  569 */         lag2[i2][i1] = 0;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  574 */     float[][] c = new float[n2][n1];
/*  575 */     float[][] cmax = new float[n2][n1];
/*  576 */     for (int i = 0; i < n2; i++) {
/*  577 */       for (int i1 = 0; i1 < n1; i1++) {
/*  578 */         cmax[i][i1] = -3.4028235E38F;
/*      */       }
/*      */     } 
/*  581 */     Lags lags = new Lags(min1, max1, min2, max2);
/*  582 */     int l1 = (min1 + max1) / 2;
/*  583 */     int l2 = (min2 + max2) / 2;
/*      */ 
/*      */     
/*  586 */     boolean done = false;
/*  587 */     while (!done) {
/*      */ 
/*      */       
/*  590 */       apply(l1, l2, f, g, c);
/*      */ 
/*      */ 
/*      */       
/*  594 */       lags.markLag(l1, l2);
/*      */ 
/*      */       
/*  597 */       boolean foundMax = false;
/*  598 */       for (int j = 0; j < n2; j++) {
/*  599 */         float[] c2 = c[j];
/*  600 */         float[] cmax2 = cmax[j];
/*  601 */         for (int i1 = 0; i1 < n1; i1++) {
/*  602 */           float ci = c2[i1];
/*  603 */           if (ci > cmax2[i1]) {
/*  604 */             cmax[j][i1] = ci;
/*  605 */             lag1[j][i1] = (byte)l1;
/*  606 */             lag2[j][i1] = (byte)l2;
/*  607 */             foundMax = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*  611 */       if (foundMax) {
/*  612 */         lags.markMax(l1, l2);
/*      */       }
/*      */       
/*  615 */       int[] ls = lags.nextLag();
/*  616 */       if (ls == null) {
/*  617 */         done = true; continue;
/*      */       } 
/*  619 */       l1 = ls[0];
/*  620 */       l2 = ls[1];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findMaxLags(float[][][] f, float[][][] g, int min1, int max1, int min2, int max2, int min3, int max3, byte[][][] lag1, byte[][][] lag2, byte[][][] lag3) {
/*  631 */     int n1 = (f[0][0]).length;
/*  632 */     int n2 = (f[0]).length;
/*  633 */     int n3 = f.length;
/*  634 */     for (int i3 = 0; i3 < n3; i3++) {
/*  635 */       for (int i2 = 0; i2 < n2; i2++) {
/*  636 */         for (int i1 = 0; i1 < n1; i1++) {
/*  637 */           lag1[i3][i2][i1] = 0;
/*  638 */           lag2[i3][i2][i1] = 0;
/*  639 */           lag3[i3][i2][i1] = 0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  645 */     float[][][] c = new float[n3][n2][n1];
/*  646 */     float[][][] cmax = new float[n3][n2][n1];
/*  647 */     for (int i = 0; i < n3; i++) {
/*  648 */       for (int i2 = 0; i2 < n2; i2++) {
/*  649 */         for (int i1 = 0; i1 < n1; i1++)
/*  650 */           cmax[i][i2][i1] = -3.4028235E38F; 
/*      */       } 
/*      */     } 
/*  653 */     Lags lags = new Lags(min1, max1, min2, max2, min3, max3);
/*  654 */     int l1 = (min1 + max1) / 2;
/*  655 */     int l2 = (min2 + max2) / 2;
/*  656 */     int l3 = (min3 + max3) / 2;
/*      */ 
/*      */     
/*  659 */     boolean done = false;
/*  660 */     while (!done) {
/*      */ 
/*      */       
/*  663 */       System.out.println("findMaxLags: l1=" + l1 + " l2=" + l2 + " l3=" + l3);
/*  664 */       apply(l1, l2, l3, f, g, c);
/*      */ 
/*      */ 
/*      */       
/*  668 */       lags.markLag(l1, l2, l3);
/*      */ 
/*      */       
/*  671 */       boolean foundMax = false;
/*  672 */       for (int j = 0; j < n3; j++) {
/*  673 */         for (int i2 = 0; i2 < n2; i2++) {
/*  674 */           float[] c32 = c[j][i2];
/*  675 */           float[] cmax32 = cmax[j][i2];
/*  676 */           byte[] lag132 = lag1[j][i2];
/*  677 */           byte[] lag232 = lag2[j][i2];
/*  678 */           byte[] lag332 = lag3[j][i2];
/*  679 */           for (int i1 = 0; i1 < n1; i1++) {
/*  680 */             float ci = c32[i1];
/*  681 */             if (ci > cmax32[i1]) {
/*  682 */               cmax32[i1] = ci;
/*  683 */               lag132[i1] = (byte)l1;
/*  684 */               lag232[i1] = (byte)l2;
/*  685 */               lag332[i1] = (byte)l3;
/*  686 */               foundMax = true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  691 */       if (foundMax) {
/*  692 */         lags.markMax(l1, l2, l3);
/*      */       }
/*      */       
/*  695 */       int[] ls = lags.nextLag();
/*  696 */       if (ls == null) {
/*  697 */         done = true; continue;
/*      */       } 
/*  699 */       l1 = ls[0];
/*  700 */       l2 = ls[1];
/*  701 */       l3 = ls[2];
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void refineLags(float[] f, float[] g, byte[] l, float[] u) {
/*  707 */     int n = f.length;
/*      */ 
/*      */     
/*  710 */     int min = l[0];
/*  711 */     int max = l[0];
/*  712 */     for (int i = 1; i < n; i++) {
/*  713 */       int k = l[i];
/*  714 */       if (k < min) min = k; 
/*  715 */       if (k > max) max = k; 
/*      */     } 
/*  717 */     System.out.println("refineLags:");
/*  718 */     System.out.println("  min=" + min + " max=" + max);
/*      */ 
/*      */     
/*  721 */     float[] c = new float[n];
/*  722 */     float[] a1 = new float[n];
/*  723 */     float[] a2 = new float[n];
/*  724 */     for (int lag = min - 1; lag <= max + 1; lag++) {
/*  725 */       apply(lag, f, g, c);
/*  726 */       for (int k = 0; k < n; k++) {
/*  727 */         int m = lag - l[k];
/*  728 */         if (-1 <= m && m <= 1) {
/*  729 */           m++;
/*  730 */           float[] ck = C1[m];
/*  731 */           float ci = c[k];
/*  732 */           a1[k] = a1[k] + ck[1] * ci;
/*  733 */           a2[k] = a2[k] + ck[2] * ci;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  739 */     for (int j = 0; j < n; j++) {
/*  740 */       float a1i = a1[j];
/*  741 */       float a2i = a2[j];
/*  742 */       float w = 0.0F;
/*  743 */       if (a2i < 0.0D)
/*  744 */         w = -0.5F * a1i / a2i; 
/*  745 */       if (w < -1.0F) {
/*  746 */         w = -1.0F;
/*  747 */       } else if (w > 1.0F) {
/*  748 */         w = 1.0F;
/*      */       } 
/*  750 */       u[j] = w + l[j];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refineLags(float[][] f, float[][] g, byte[][] l1, byte[][] l2, float[][] u1, float[][] u2) {
/*  759 */     int n1 = (f[0]).length;
/*  760 */     int n2 = f.length;
/*      */ 
/*      */     
/*  763 */     int min1 = l1[0][0];
/*  764 */     int max1 = l1[0][0];
/*  765 */     int min2 = l2[0][0];
/*  766 */     int max2 = l2[0][0];
/*  767 */     for (int i2 = 0; i2 < n2; i2++) {
/*  768 */       for (int i1 = 0; i1 < n1; i1++) {
/*  769 */         int lag1 = l1[i2][i1];
/*  770 */         int j = l2[i2][i1];
/*  771 */         if (lag1 < min1) min1 = lag1; 
/*  772 */         if (lag1 > max1) max1 = lag1; 
/*  773 */         if (j < min2) min2 = j; 
/*  774 */         if (j > max2) max2 = j; 
/*      */       } 
/*      */     } 
/*  777 */     System.out.println("refineLags:");
/*  778 */     System.out.println("  min1=" + min1 + " max1=" + max1);
/*  779 */     System.out.println("  min2=" + min2 + " max2=" + max2);
/*      */ 
/*      */     
/*  782 */     float[][] c = new float[n2][n1];
/*  783 */     float[][] a1 = new float[n2][n1];
/*  784 */     float[][] a2 = new float[n2][n1];
/*  785 */     float[][] a3 = new float[n2][n1];
/*  786 */     float[][] a4 = new float[n2][n1];
/*  787 */     float[][] a5 = new float[n2][n1];
/*  788 */     for (int lag2 = min2 - 1; lag2 <= max2 + 1; lag2++) {
/*  789 */       for (int lag1 = min1 - 1; lag1 <= max1 + 1; lag1++) {
/*  790 */         apply(lag1, lag2, f, g, c);
/*  791 */         for (int j = 0; j < n2; j++) {
/*  792 */           for (int i1 = 0; i1 < n1; i1++) {
/*  793 */             int k1 = lag1 - l1[j][i1];
/*  794 */             int k2 = lag2 - l2[j][i1];
/*  795 */             if (-1 <= k1 && k1 <= 1 && -1 <= k2 && k2 <= 1) {
/*  796 */               int k = k1 + 1 + 3 * (k2 + 1);
/*  797 */               float[] ck = C2[k];
/*  798 */               float ci = c[j][i1];
/*  799 */               a1[j][i1] = a1[j][i1] + ck[1] * ci;
/*  800 */               a2[j][i1] = a2[j][i1] + ck[2] * ci;
/*  801 */               a3[j][i1] = a3[j][i1] + ck[3] * ci;
/*  802 */               a4[j][i1] = a4[j][i1] + ck[4] * ci;
/*  803 */               a5[j][i1] = a5[j][i1] + ck[5] * ci;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  811 */     for (int i = 0; i < n2; i++) {
/*  812 */       for (int i1 = 0; i1 < n1; i1++) {
/*  813 */         double w1 = 0.0D;
/*  814 */         double w2 = 0.0D;
/*  815 */         double b1 = a1[i][i1];
/*  816 */         double b2 = a2[i][i1];
/*  817 */         double a21 = -a3[i][i1];
/*  818 */         double a11 = -2.0D * a4[i][i1];
/*  819 */         double a22 = -2.0D * a5[i][i1];
/*  820 */         double d11 = a11;
/*  821 */         if (d11 > 0.0D) {
/*  822 */           double l11 = MathPlus.sqrt(d11);
/*  823 */           double l21 = a21 / l11;
/*  824 */           double d22 = a22 - l21 * l21;
/*  825 */           if (d22 > 0.0D) {
/*  826 */             double l22 = MathPlus.sqrt(d22);
/*  827 */             double v1 = b1 / l11;
/*  828 */             double v2 = (b2 - l21 * v1) / l22;
/*  829 */             w2 = v2 / l22;
/*  830 */             w1 = (v1 - l21 * w2) / l11;
/*  831 */             if (w1 < -1.0D) {
/*  832 */               w1 = -1.0D;
/*  833 */             } else if (w1 > 1.0D) {
/*  834 */               w1 = 1.0D;
/*      */             } 
/*  836 */             if (w2 < -1.0D) {
/*  837 */               w2 = -1.0D;
/*  838 */             } else if (w2 > 1.0D) {
/*  839 */               w2 = 1.0D;
/*      */             } 
/*      */           } 
/*      */         } 
/*  843 */         u1[i][i1] = (float)(w1 + l1[i][i1]);
/*  844 */         u2[i][i1] = (float)(w2 + l2[i][i1]);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refineLags(float[][][] f, float[][][] g, byte[][][] l1, byte[][][] l2, byte[][][] l3, float[][][] u1, float[][][] u2, float[][][] u3) {
/*  854 */     int n1 = (f[0][0]).length;
/*  855 */     int n2 = (f[0]).length;
/*  856 */     int n3 = f.length;
/*      */ 
/*      */     
/*  859 */     int min1 = l1[0][0][0];
/*  860 */     int max1 = l1[0][0][0];
/*  861 */     int min2 = l2[0][0][0];
/*  862 */     int max2 = l2[0][0][0];
/*  863 */     int min3 = l3[0][0][0];
/*  864 */     int max3 = l3[0][0][0];
/*  865 */     for (int i3 = 0; i3 < n3; i3++) {
/*  866 */       for (int i2 = 0; i2 < n2; i2++) {
/*  867 */         for (int i1 = 0; i1 < n1; i1++) {
/*  868 */           int lag1 = l1[i3][i2][i1];
/*  869 */           int lag2 = l2[i3][i2][i1];
/*  870 */           int j = l3[i3][i2][i1];
/*  871 */           if (lag1 < min1) min1 = lag1; 
/*  872 */           if (lag1 > max1) max1 = lag1; 
/*  873 */           if (lag2 < min2) min2 = lag2; 
/*  874 */           if (lag2 > max2) max2 = lag2; 
/*  875 */           if (j < min3) min3 = j; 
/*  876 */           if (j > max3) max3 = j; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  880 */     System.out.println("refineLags:");
/*  881 */     System.out.println("  min1=" + min1 + " max1=" + max1);
/*  882 */     System.out.println("  min2=" + min2 + " max2=" + max2);
/*  883 */     System.out.println("  min3=" + min3 + " max3=" + max3);
/*      */ 
/*      */     
/*  886 */     float[][][] c = new float[n3][n2][n1];
/*  887 */     float[][][] a1 = new float[n3][n2][n1];
/*  888 */     float[][][] a2 = new float[n3][n2][n1];
/*  889 */     float[][][] a3 = new float[n3][n2][n1];
/*  890 */     float[][][] a4 = new float[n3][n2][n1];
/*  891 */     float[][][] a5 = new float[n3][n2][n1];
/*  892 */     float[][][] a6 = new float[n3][n2][n1];
/*  893 */     float[][][] a7 = new float[n3][n2][n1];
/*  894 */     float[][][] a8 = new float[n3][n2][n1];
/*  895 */     float[][][] a9 = new float[n3][n2][n1];
/*  896 */     for (int lag3 = min3 - 1; lag3 <= max3 + 1; lag3++) {
/*  897 */       for (int lag2 = min2 - 1; lag2 <= max2 + 1; lag2++) {
/*  898 */         for (int lag1 = min1 - 1; lag1 <= max1 + 1; lag1++) {
/*  899 */           System.out.println("(" + lag1 + "," + lag2 + "," + lag3 + ")");
/*  900 */           apply(lag1, lag2, lag3, f, g, c);
/*  901 */           for (int j = 0; j < n3; j++) {
/*  902 */             for (int i2 = 0; i2 < n2; i2++) {
/*  903 */               for (int i1 = 0; i1 < n1; i1++) {
/*  904 */                 int k1 = lag1 - l1[j][i2][i1];
/*  905 */                 int k2 = lag2 - l2[j][i2][i1];
/*  906 */                 int k3 = lag3 - l3[j][i2][i1];
/*  907 */                 if (-1 <= k1 && k1 <= 1 && -1 <= k2 && k2 <= 1 && -1 <= k3 && k3 <= 1) {
/*  908 */                   int k = k1 + 1 + 3 * (k2 + 1) + 9 * (k3 + 1);
/*  909 */                   float[] ck = C3[k];
/*  910 */                   float ci = c[j][i2][i1];
/*  911 */                   a1[j][i2][i1] = a1[j][i2][i1] + ck[1] * ci;
/*  912 */                   a2[j][i2][i1] = a2[j][i2][i1] + ck[2] * ci;
/*  913 */                   a3[j][i2][i1] = a3[j][i2][i1] + ck[3] * ci;
/*  914 */                   a4[j][i2][i1] = a4[j][i2][i1] + ck[4] * ci;
/*  915 */                   a5[j][i2][i1] = a5[j][i2][i1] + ck[5] * ci;
/*  916 */                   a6[j][i2][i1] = a6[j][i2][i1] + ck[6] * ci;
/*  917 */                   a7[j][i2][i1] = a7[j][i2][i1] + ck[7] * ci;
/*  918 */                   a8[j][i2][i1] = a8[j][i2][i1] + ck[8] * ci;
/*  919 */                   a9[j][i2][i1] = a9[j][i2][i1] + ck[9] * ci;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  929 */     for (int i = 0; i < n3; i++) {
/*  930 */       for (int i2 = 0; i2 < n2; i2++) {
/*  931 */         for (int i1 = 0; i1 < n1; i1++) {
/*  932 */           double w1 = 0.0D;
/*  933 */           double w2 = 0.0D;
/*  934 */           double w3 = 0.0D;
/*  935 */           double b1 = a1[i][i2][i1];
/*  936 */           double b2 = a2[i][i2][i1];
/*  937 */           double b3 = a3[i][i2][i1];
/*  938 */           double a21 = -a4[i][i2][i1];
/*  939 */           double a31 = -a5[i][i2][i1];
/*  940 */           double a32 = -a6[i][i2][i1];
/*  941 */           double a11 = -2.0D * a7[i][i2][i1];
/*  942 */           double a22 = -2.0D * a8[i][i2][i1];
/*  943 */           double a33 = -2.0D * a9[i][i2][i1];
/*  944 */           double d11 = a11;
/*  945 */           if (d11 > 0.0D) {
/*  946 */             double l11 = MathPlus.sqrt(d11);
/*  947 */             double l21 = a21 / l11;
/*  948 */             double l31 = a31 / l11;
/*  949 */             double d22 = a22 - l21 * l21;
/*  950 */             if (d22 > 0.0D) {
/*  951 */               double l22 = MathPlus.sqrt(d22);
/*  952 */               double l32 = (a32 - l31 * l21) / l22;
/*  953 */               double d33 = a33 - l31 * l31 - l32 * l32;
/*  954 */               if (d33 > 0.0D) {
/*  955 */                 double l33 = MathPlus.sqrt(d33);
/*  956 */                 double v1 = b1 / l11;
/*  957 */                 double v2 = (b2 - l21 * v1) / l22;
/*  958 */                 double v3 = (b3 - l31 * v1 - l32 * v2) / l33;
/*  959 */                 w3 = v3 / l33;
/*  960 */                 w2 = (v2 - l32 * w3) / l22;
/*  961 */                 w1 = (v1 - l21 * w2 - l31 * w3) / l11;
/*  962 */                 if (w1 < -1.0D) {
/*  963 */                   w1 = -1.0D;
/*  964 */                 } else if (w1 > 1.0D) {
/*  965 */                   w1 = 1.0D;
/*      */                 } 
/*  967 */                 if (w2 < -1.0D) {
/*  968 */                   w2 = -1.0D;
/*  969 */                 } else if (w2 > 1.0D) {
/*  970 */                   w2 = 1.0D;
/*      */                 } 
/*  972 */                 if (w3 < -1.0D) {
/*  973 */                   w3 = -1.0D;
/*  974 */                 } else if (w3 > 1.0D) {
/*  975 */                   w3 = 1.0D;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*  980 */           u1[i][i2][i1] = (float)(w1 + l1[i][i2][i1]);
/*  981 */           u2[i][i2][i1] = (float)(w2 + l2[i][i2][i1]);
/*  982 */           u3[i][i2][i1] = (float)(w3 + l3[i][i2][i1]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyWindow(int jf, float[] f, int jg, float[] g) {
/*  992 */     float[] w1 = makeGaussianWindow(this._sigma1);
/*  993 */     applyWindow(w1, jf, f, jg, g);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyWindow(int j1f, int j2f, float[][] f, int j1g, int j2g, float[][] g) {
/* 1000 */     float[] w1 = makeGaussianWindow(this._sigma1);
/* 1001 */     float[] w2 = makeGaussianWindow(this._sigma2);
/* 1002 */     applyWindow(w1, w2, j1f, j2f, f, j1g, j2g, g);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyWindow(int j1f, int j2f, int j3f, float[][][] f, int j1g, int j2g, int j3g, float[][][] g) {
/* 1009 */     float[] w1 = makeGaussianWindow(this._sigma1);
/* 1010 */     float[] w2 = makeGaussianWindow(this._sigma2);
/* 1011 */     float[] w3 = makeGaussianWindow(this._sigma3);
/* 1012 */     applyWindow(w1, w2, w3, j1f, j2f, j3f, f, j1g, j2g, j3g, g);
/*      */   }
/*      */   
/*      */   private static class Lags
/*      */   {
/*      */     int _min1;
/*      */     int _max1;
/*      */     int _min2;
/*      */     int _max2;
/*      */     int _min3;
/*      */     int _max3;
/*      */     byte[][][] _mark;
/*      */     
/*      */     Lags(int min1, int max1) {
/* 1026 */       this(min1, max1, 0, 0, 0, 0);
/*      */     }
/*      */     Lags(int min1, int max1, int min2, int max2) {
/* 1029 */       this(min1, max1, min2, max2, 0, 0);
/*      */     }
/*      */     Lags(int min1, int max1, int min2, int max2, int min3, int max3) {
/* 1032 */       int nl1 = 1 + max1 - min1;
/* 1033 */       int nl2 = 1 + max2 - min2;
/* 1034 */       int nl3 = 1 + max3 - min3;
/* 1035 */       this._min1 = min1;
/* 1036 */       this._max1 = max1;
/* 1037 */       this._min2 = min2;
/* 1038 */       this._max2 = max2;
/* 1039 */       this._min3 = min3;
/* 1040 */       this._max3 = max3;
/* 1041 */       this._mark = new byte[nl3][nl2][nl1];
/*      */     }
/*      */     void markLag(int l1) {
/* 1044 */       markLag(l1, 0, 0);
/*      */     }
/*      */     void markLag(int l1, int l2) {
/* 1047 */       markLag(l1, l2, 0);
/*      */     }
/*      */     void markLag(int l1, int l2, int l3) {
/* 1050 */       this._mark[l3 - this._min3][l2 - this._min2][l1 - this._min1] = -1;
/*      */     }
/*      */     void markMax(int l1) {
/* 1053 */       markMax(l1, 0, 0);
/*      */     }
/*      */     void markMax(int l1, int l2) {
/* 1056 */       markMax(l1, l2, 0);
/*      */     }
/*      */     void markMax(int l1, int l2, int l3) {
/* 1059 */       this._mark[l3 - this._min3][l2 - this._min2][l1 - this._min1] = 1;
/*      */     }
/*      */     boolean isMarkedLag(int l1) {
/* 1062 */       return isMarkedLag(l1, 0, 0);
/*      */     }
/*      */     boolean isMarkedLag(int l1, int l2) {
/* 1065 */       return isMarkedLag(l1, l2, 0);
/*      */     }
/*      */     boolean isMarkedLag(int l1, int l2, int l3) {
/* 1068 */       return (!inBounds(l1, l2, l3) || this._mark[l3 - this._min3][l2 - this._min2][l1 - this._min1] != 0);
/*      */     }
/*      */     boolean isMarkedMax(int l1) {
/* 1071 */       return isMarkedMax(l1, 0, 0);
/*      */     }
/*      */     boolean isMarkedMax(int l1, int l2) {
/* 1074 */       return isMarkedMax(l1, l2, 0);
/*      */     }
/*      */     boolean isMarkedMax(int l1, int l2, int l3) {
/* 1077 */       return (inBounds(l1, l2, l3) && this._mark[l3 - this._min3][l2 - this._min2][l1 - this._min1] == 1);
/*      */     }
/*      */     boolean inBounds(int l1, int l2, int l3) {
/* 1080 */       return (l1 >= this._min1 && l1 <= this._max1 && l2 >= this._min2 && l2 <= this._max2 && l3 >= this._min3 && l3 <= this._max3);
/*      */     }
/*      */ 
/*      */     
/*      */     int[] nextLag() {
/* 1085 */       for (int l3 = this._min3; l3 <= this._max3; l3++) {
/* 1086 */         for (int l2 = this._min2; l2 <= this._max2; l2++) {
/* 1087 */           for (int l1 = this._min1; l1 <= this._max1; l1++) {
/* 1088 */             if (isMarkedMax(l1, l2, l3)) {
/* 1089 */               for (int k3 = l3 - 1; k3 <= l3 + 1; k3++) {
/* 1090 */                 for (int k2 = l2 - 1; k2 <= l2 + 1; k2++) {
/* 1091 */                   for (int k1 = l1 - 1; k1 <= l1 + 1; k1++) {
/* 1092 */                     if (!isMarkedLag(k1, k2, k3)) {
/* 1093 */                       return new int[] { k1, k2, k3 };
/*      */                     }
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 1102 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1144 */   private static final float[][] C1 = new float[][] { { 0.0F, -0.5F, 0.5F }, { 1.0F, 0.0F, -1.0F }, { 0.0F, 0.5F, 0.5F } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1172 */   private static final float[][] C2 = new float[][] { { -0.11111111F, -0.16666667F, -0.16666667F, 0.25F, 0.16666667F, 0.16666667F }, { 0.22222222F, 0.0F, -0.16666667F, 0.0F, -0.33333334F, 0.16666667F }, { -0.11111111F, 0.16666667F, -0.16666667F, -0.25F, 0.16666667F, 0.16666667F }, { 0.22222222F, -0.16666667F, 0.0F, 0.0F, 0.16666667F, -0.33333334F }, { 0.5555556F, 0.0F, 0.0F, 0.0F, -0.33333334F, -0.33333334F }, { 0.22222222F, 0.16666667F, 0.0F, 0.0F, 0.16666667F, -0.33333334F }, { -0.11111111F, -0.16666667F, 0.16666667F, -0.25F, 0.16666667F, 0.16666667F }, { 0.22222222F, 0.0F, 0.16666667F, 0.0F, -0.33333334F, 0.16666667F }, { -0.11111111F, 0.16666667F, 0.16666667F, 0.25F, 0.16666667F, 0.16666667F } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1217 */   private static final float[][] C3 = new float[][] { { -0.074074075F, -0.055555556F, -0.055555556F, -0.055555556F, 0.083333336F, 0.083333336F, 0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, 0.0F, -0.055555556F, -0.055555556F, 0.0F, 0.0F, 0.083333336F, -0.11111111F, 0.055555556F, 0.055555556F }, { -0.074074075F, 0.055555556F, -0.055555556F, -0.055555556F, -0.083333336F, -0.083333336F, 0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, -0.055555556F, 0.0F, -0.055555556F, 0.0F, 0.083333336F, 0.0F, 0.055555556F, -0.11111111F, 0.055555556F }, { 0.14814815F, 0.0F, 0.0F, -0.055555556F, 0.0F, 0.0F, 0.0F, -0.11111111F, -0.11111111F, 0.055555556F }, { 0.037037037F, 0.055555556F, 0.0F, -0.055555556F, 0.0F, -0.083333336F, 0.0F, 0.055555556F, -0.11111111F, 0.055555556F }, { -0.074074075F, -0.055555556F, 0.055555556F, -0.055555556F, -0.083333336F, 0.083333336F, -0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, 0.0F, 0.055555556F, -0.055555556F, 0.0F, 0.0F, -0.083333336F, -0.11111111F, 0.055555556F, 0.055555556F }, { -0.074074075F, 0.055555556F, 0.055555556F, -0.055555556F, 0.083333336F, -0.083333336F, -0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, -0.055555556F, -0.055555556F, 0.0F, 0.083333336F, 0.0F, 0.0F, 0.055555556F, 0.055555556F, -0.11111111F }, { 0.14814815F, 0.0F, -0.055555556F, 0.0F, 0.0F, 0.0F, 0.0F, -0.11111111F, 0.055555556F, -0.11111111F }, { 0.037037037F, 0.055555556F, -0.055555556F, 0.0F, -0.083333336F, 0.0F, 0.0F, 0.055555556F, 0.055555556F, -0.11111111F }, { 0.14814815F, -0.055555556F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.055555556F, -0.11111111F, -0.11111111F }, { 0.25925925F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.11111111F, -0.11111111F, -0.11111111F }, { 0.14814815F, 0.055555556F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.055555556F, -0.11111111F, -0.11111111F }, { 0.037037037F, -0.055555556F, 0.055555556F, 0.0F, -0.083333336F, 0.0F, 0.0F, 0.055555556F, 0.055555556F, -0.11111111F }, { 0.14814815F, 0.0F, 0.055555556F, 0.0F, 0.0F, 0.0F, 0.0F, -0.11111111F, 0.055555556F, -0.11111111F }, { 0.037037037F, 0.055555556F, 0.055555556F, 0.0F, 0.083333336F, 0.0F, 0.0F, 0.055555556F, 0.055555556F, -0.11111111F }, { -0.074074075F, -0.055555556F, -0.055555556F, 0.055555556F, 0.083333336F, -0.083333336F, -0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, 0.0F, -0.055555556F, 0.055555556F, 0.0F, 0.0F, -0.083333336F, -0.11111111F, 0.055555556F, 0.055555556F }, { -0.074074075F, 0.055555556F, -0.055555556F, 0.055555556F, -0.083333336F, 0.083333336F, -0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, -0.055555556F, 0.0F, 0.055555556F, 0.0F, -0.083333336F, 0.0F, 0.055555556F, -0.11111111F, 0.055555556F }, { 0.14814815F, 0.0F, 0.0F, 0.055555556F, 0.0F, 0.0F, 0.0F, -0.11111111F, -0.11111111F, 0.055555556F }, { 0.037037037F, 0.055555556F, 0.0F, 0.055555556F, 0.0F, 0.083333336F, 0.0F, 0.055555556F, -0.11111111F, 0.055555556F }, { -0.074074075F, -0.055555556F, 0.055555556F, 0.055555556F, -0.083333336F, -0.083333336F, 0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F }, { 0.037037037F, 0.0F, 0.055555556F, 0.055555556F, 0.0F, 0.0F, 0.083333336F, -0.11111111F, 0.055555556F, 0.055555556F }, { -0.074074075F, 0.055555556F, 0.055555556F, 0.055555556F, 0.083333336F, 0.083333336F, 0.083333336F, 0.055555556F, 0.055555556F, 0.055555556F } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double _sigma1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double _sigma2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double _sigma3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RecursiveGaussianFilter _rgf1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RecursiveGaussianFilter _rgf2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RecursiveGaussianFilter _rgf3;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1256 */   private static float S1 = 0.615728F;
/* 1257 */   private static float S2 = -0.1558022F;
/* 1258 */   private static float S3 = 0.0509014F;
/* 1259 */   private static float S4 = -0.0115417F;
/* 1260 */   private static float[] S = new float[] { S4, S3, S2, S1, S1, S2, S3, S4 };
/*      */   
/*      */   private static void shift(float[] f, float[] g) {
/* 1263 */     int n1 = f.length;
/*      */ 
/*      */ 
/*      */     
/* 1267 */     int i1b = 0;
/* 1268 */     int i1e = MathPlus.min(4, n1); int i1;
/* 1269 */     for (i1 = i1b; i1 < i1e; i1++) {
/* 1270 */       int ib = MathPlus.max(0, 4 - i1);
/* 1271 */       int ie = MathPlus.min(8, 4 - i1 + n1);
/* 1272 */       g[i1] = 0.0F;
/* 1273 */       for (int i = ib; i < ie; i++) {
/* 1274 */         g[i1] = g[i1] + S[i] * f[i1 + i - 4];
/*      */       }
/*      */     } 
/*      */     
/* 1278 */     i1b = 4;
/* 1279 */     i1e = n1 - 3;
/* 1280 */     for (i1 = i1b; i1 < i1e; i1++) {
/* 1281 */       g[i1] = S4 * (f[i1 - 4] + f[i1 + 3]) + S3 * (f[i1 - 3] + f[i1 + 2]) + S2 * (f[i1 - 2] + f[i1 + 1]) + S1 * (f[i1 - 1] + f[i1]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1288 */     i1b = MathPlus.max(0, n1 - 3);
/* 1289 */     i1e = n1;
/* 1290 */     for (i1 = i1b; i1 < i1e; i1++) {
/* 1291 */       int ib = MathPlus.max(0, 4 - i1);
/* 1292 */       int ie = MathPlus.min(8, 4 - i1 + n1);
/* 1293 */       g[i1] = 0.0F;
/* 1294 */       for (int i = ib; i < ie; i++)
/* 1295 */         g[i1] = g[i1] + S[i] * f[i1 + i - 4]; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void shift1(float[][] f, float[][] g) {
/* 1300 */     int n2 = f.length;
/* 1301 */     for (int i2 = 0; i2 < n2; i2++)
/* 1302 */       shift(f[i2], g[i2]); 
/*      */   }
/*      */   
/*      */   private static void shift2(float[][] f, float[][] g) {
/* 1306 */     int n2 = f.length;
/* 1307 */     int n1 = (f[0]).length;
/*      */ 
/*      */ 
/*      */     
/* 1311 */     int i2b = 0;
/* 1312 */     int i2e = MathPlus.min(4, n2); int i2;
/* 1313 */     for (i2 = i2b; i2 < i2e; i2++) {
/* 1314 */       int ib = MathPlus.max(0, 4 - i2);
/* 1315 */       int ie = MathPlus.min(8, 4 - i2 + n2);
/* 1316 */       for (int i1 = 0; i1 < n1; i1++)
/* 1317 */         g[i2][i1] = 0.0F; 
/* 1318 */       for (int i = ib; i < ie; i++) {
/* 1319 */         for (int j = 0; j < n1; j++) {
/* 1320 */           g[i2][j] = g[i2][j] + S[i] * f[i2 + i - 4][j];
/*      */         }
/*      */       } 
/*      */     } 
/* 1324 */     i2b = 4;
/* 1325 */     i2e = n2 - 3;
/* 1326 */     for (i2 = i2b; i2 < i2e; i2++) {
/* 1327 */       float[] g2 = g[i2];
/* 1328 */       float[] fm4 = f[i2 - 4];
/* 1329 */       float[] fm3 = f[i2 - 3];
/* 1330 */       float[] fm2 = f[i2 - 2];
/* 1331 */       float[] fm1 = f[i2 - 1];
/* 1332 */       float[] fp0 = f[i2];
/* 1333 */       float[] fp1 = f[i2 + 1];
/* 1334 */       float[] fp2 = f[i2 + 2];
/* 1335 */       float[] fp3 = f[i2 + 3];
/* 1336 */       for (int i1 = 0; i1 < n1; i1++) {
/* 1337 */         g2[i1] = S4 * (fm4[i1] + fp3[i1]) + S3 * (fm3[i1] + fp2[i1]) + S2 * (fm2[i1] + fp1[i1]) + S1 * (fm1[i1] + fp0[i1]);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1344 */     i2b = MathPlus.max(0, n2 - 3);
/* 1345 */     i2e = n2;
/* 1346 */     for (i2 = i2b; i2 < i2e; i2++) {
/* 1347 */       int ib = MathPlus.max(0, 4 - i2);
/* 1348 */       int ie = MathPlus.min(8, 4 - i2 + n2);
/* 1349 */       for (int i1 = 0; i1 < n1; i1++)
/* 1350 */         g[i2][i1] = 0.0F; 
/* 1351 */       for (int i = ib; i < ie; i++) {
/* 1352 */         for (int j = 0; j < n1; j++)
/* 1353 */           g[i2][j] = g[i2][j] + S[i] * f[i2 + i - 4][j]; 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private static void shift1(final float[][][] f, final float[][][] g) {
/* 1358 */     final int n3 = f.length;
/* 1359 */     final AtomicInteger ai = new AtomicInteger();
/* 1360 */     Thread[] threads = newThreads();
/* 1361 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/* 1362 */       threads[ithread] = new Thread(new Runnable() {
/*      */             public void run() {
/* 1364 */               for (int i3 = ai.getAndIncrement(); i3 < n3; i3 = ai.getAndIncrement()) {
/* 1365 */                 LocalCorrelationFilter.shift1(f[i3], g[i3]);
/*      */               }
/*      */             }
/*      */           });
/*      */     } 
/* 1370 */     startAndJoin(threads);
/*      */   }
/*      */   
/*      */   private static void shift2(final float[][][] f, final float[][][] g) {
/* 1374 */     final int n3 = f.length;
/* 1375 */     final AtomicInteger ai = new AtomicInteger();
/* 1376 */     Thread[] threads = newThreads();
/* 1377 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/* 1378 */       threads[ithread] = new Thread(new Runnable() {
/*      */             public void run() {
/* 1380 */               for (int i3 = ai.getAndIncrement(); i3 < n3; i3 = ai.getAndIncrement()) {
/* 1381 */                 LocalCorrelationFilter.shift2(f[i3], g[i3]);
/*      */               }
/*      */             }
/*      */           });
/*      */     } 
/* 1386 */     startAndJoin(threads);
/*      */   }
/*      */   
/*      */   private static void shift3(final float[][][] f, final float[][][] g) {
/* 1390 */     final int n3 = f.length;
/* 1391 */     final int n2 = (f[0]).length;
/* 1392 */     final AtomicInteger ai = new AtomicInteger();
/* 1393 */     Thread[] threads = newThreads();
/* 1394 */     for (int ithread = 0; ithread < threads.length; ithread++) {
/* 1395 */       threads[ithread] = new Thread(new Runnable() {
/*      */             public void run() {
/* 1397 */               float[][] f2 = new float[n3][];
/* 1398 */               float[][] g2 = new float[n3][];
/* 1399 */               for (int i2 = ai.getAndIncrement(); i2 < n2; i2 = ai.getAndIncrement()) {
/* 1400 */                 for (int i3 = 0; i3 < n3; i3++) {
/* 1401 */                   f2[i3] = f[i3][i2];
/* 1402 */                   g2[i3] = g[i3][i2];
/*      */                 } 
/* 1404 */                 LocalCorrelationFilter.shift2(f2, g2);
/*      */               } 
/*      */             }
/*      */           });
/*      */     } 
/* 1409 */     startAndJoin(threads);
/*      */   }
/*      */   
/*      */   private static Thread[] newThreads() {
/* 1413 */     int nthread = Runtime.getRuntime().availableProcessors();
/* 1414 */     return new Thread[nthread];
/*      */   }
/*      */   private static void startAndJoin(Thread[] threads) {
/*      */     int ithread;
/* 1418 */     for (ithread = 0; ithread < threads.length; ithread++)
/* 1419 */       threads[ithread].start(); 
/*      */     try {
/* 1421 */       for (ithread = 0; ithread < threads.length; ithread++)
/* 1422 */         threads[ithread].join(); 
/* 1423 */     } catch (InterruptedException ie) {
/* 1424 */       throw new RuntimeException(ie);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float[] makeGaussianWindow(double sigma) {
/* 1455 */     int m = 1 + 2 * (int)(4.0D * sigma);
/* 1456 */     int j = (m - 1) / 2;
/* 1457 */     float[] w = new float[m];
/* 1458 */     double s = -0.5D / sigma * sigma;
/* 1459 */     for (int i = 0; i < m; i++) {
/* 1460 */       double x = (i - j);
/* 1461 */       w[i] = (float)MathPlus.exp(s * x * x);
/*      */     } 
/* 1463 */     return w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void applyWindow(float[] w, int jf, float[] f, int jg, float[] g) {
/* 1481 */     int nf = f.length;
/* 1482 */     int ng = g.length;
/* 1483 */     int nw = w.length;
/* 1484 */     jf -= (nw - 1) / 2;
/* 1485 */     jg -= (nw - 1) / 2;
/* 1486 */     int imin = MathPlus.max(0, -jf, -jg);
/* 1487 */     int imax = MathPlus.min(nw, nf - jf, ng - jg);
/* 1488 */     for (int i = imin; i < imax; i++) {
/* 1489 */       g[jg + i] = w[i] * f[jf + i];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void applyWindow(float[] w1, float[] w2, int j1f, int j2f, float[][] f, int j1g, int j2g, float[][] g) {
/* 1513 */     int n1f = (f[0]).length;
/* 1514 */     int n1g = (g[0]).length;
/* 1515 */     int n1w = w1.length;
/* 1516 */     j1f -= (n1w - 1) / 2;
/* 1517 */     j1g -= (n1w - 1) / 2;
/* 1518 */     int i1min = MathPlus.max(0, -j1f, -j1g);
/* 1519 */     int i1max = MathPlus.min(n1w, n1f - j1f, n1g - j1g);
/* 1520 */     int n2f = f.length;
/* 1521 */     int n2g = g.length;
/* 1522 */     int n2w = w2.length;
/* 1523 */     j2f -= (n2w - 1) / 2;
/* 1524 */     j2g -= (n2w - 1) / 2;
/* 1525 */     int i2min = MathPlus.max(0, -j2f, -j2g);
/* 1526 */     int i2max = MathPlus.min(n2w, n2f - j2f, n2g - j2g);
/* 1527 */     for (int i2 = i2min; i2 < i2max; i2++) {
/* 1528 */       float w2i = w2[i2];
/* 1529 */       float[] f2 = f[j2f + i2];
/* 1530 */       float[] g2 = g[j2g + i2];
/* 1531 */       for (int i1 = i1min; i1 < i1max; i1++) {
/* 1532 */         g2[j1g + i1] = w2i * w1[i1] * f2[j1f + i1];
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void applyWindow(float[] w1, float[] w2, float[] w3, int j1f, int j2f, int j3f, float[][][] f, int j1g, int j2g, int j3g, float[][][] g) {
/* 1542 */     int n1f = (f[0]).length;
/* 1543 */     int n1g = (g[0]).length;
/* 1544 */     int n1w = w1.length;
/* 1545 */     j1f -= (n1w - 1) / 2;
/* 1546 */     j1g -= (n1w - 1) / 2;
/* 1547 */     int i1min = MathPlus.max(0, -j1f, -j1g);
/* 1548 */     int i1max = MathPlus.min(n1w, n1f - j1f, n1g - j1g);
/* 1549 */     int n2f = f.length;
/* 1550 */     int n2g = g.length;
/* 1551 */     int n2w = w2.length;
/* 1552 */     j2f -= (n2w - 1) / 2;
/* 1553 */     j2g -= (n2w - 1) / 2;
/* 1554 */     int i2min = MathPlus.max(0, -j2f, -j2g);
/* 1555 */     int i2max = MathPlus.min(n2w, n2f - j2f, n2g - j2g);
/* 1556 */     int n3f = f.length;
/* 1557 */     int n3g = g.length;
/* 1558 */     int n3w = w3.length;
/* 1559 */     j3f -= (n3w - 1) / 2;
/* 1560 */     j3g -= (n3w - 1) / 2;
/* 1561 */     int i3min = MathPlus.max(0, -j3f, -j3g);
/* 1562 */     int i3max = MathPlus.min(n3w, n3f - j3f, n3g - j3g);
/* 1563 */     for (int i3 = i3min; i3 < i3max; i3++) {
/* 1564 */       float w3i = w3[i3];
/* 1565 */       float[][] f3 = f[j3f + i3];
/* 1566 */       float[][] g3 = g[j3g + i3];
/* 1567 */       for (int i2 = i2min; i2 < i2max; i2++) {
/* 1568 */         float w32i = w3i * w2[i2];
/* 1569 */         float[] f32 = f3[j2f + i2];
/* 1570 */         float[] g32 = g3[j2g + i2];
/* 1571 */         for (int i1 = i1min; i1 < i1max; i1++)
/* 1572 */           g32[j1g + i1] = w32i * w1[i1] * f32[j1f + i1]; 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/LocalCorrelationFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */