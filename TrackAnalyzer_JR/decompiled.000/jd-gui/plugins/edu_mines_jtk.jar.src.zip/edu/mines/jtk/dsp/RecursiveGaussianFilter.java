/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Cdouble;
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RecursiveGaussianFilter
/*      */ {
/*      */   private Filter _filter;
/*      */   
/*      */   public enum Method
/*      */   {
/*   57 */     DERICHE,
/*   58 */     VAN_VLIET;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecursiveGaussianFilter(double sigma, Method method) {
/*   67 */     Check.argument((sigma >= 1.0D), "sigma>=1.0");
/*   68 */     this._filter = (method == Method.DERICHE) ? new DericheFilter(sigma) : new VanVlietFilter(sigma);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecursiveGaussianFilter(double sigma) {
/*   78 */     Check.argument((sigma >= 1.0D), "sigma>=1.0");
/*   79 */     this._filter = (sigma < 32.0D) ? new DericheFilter(sigma) : new VanVlietFilter(sigma);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply0(float[] x, float[] y) {
/*   90 */     this._filter.applyN(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1(float[] x, float[] y) {
/*   99 */     this._filter.applyN(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2(float[] x, float[] y) {
/*  108 */     this._filter.applyN(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply0X(float[][] x, float[][] y) {
/*  118 */     this._filter.applyNX(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1X(float[][] x, float[][] y) {
/*  128 */     this._filter.applyNX(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2X(float[][] x, float[][] y) {
/*  138 */     this._filter.applyNX(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX0(float[][] x, float[][] y) {
/*  148 */     this._filter.applyXN(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX1(float[][] x, float[][] y) {
/*  158 */     this._filter.applyXN(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX2(float[][] x, float[][] y) {
/*  168 */     this._filter.applyXN(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply0XX(float[][][] x, float[][][] y) {
/*  178 */     this._filter.applyNXX(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply1XX(float[][][] x, float[][][] y) {
/*  188 */     this._filter.applyNXX(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply2XX(float[][][] x, float[][][] y) {
/*  198 */     this._filter.applyNXX(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX0X(float[][][] x, float[][][] y) {
/*  208 */     this._filter.applyXNX(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX1X(float[][][] x, float[][][] y) {
/*  218 */     this._filter.applyXNX(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyX2X(float[][][] x, float[][][] y) {
/*  228 */     this._filter.applyXNX(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyXX0(float[][][] x, float[][][] y) {
/*  238 */     this._filter.applyXXN(0, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyXX1(float[][][] x, float[][][] y) {
/*  248 */     this._filter.applyXXN(1, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyXX2(float[][][] x, float[][][] y) {
/*  258 */     this._filter.applyXXN(2, x, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply00(float[][] x, float[][] y) {
/*  267 */     this._filter.applyXN(0, x, y);
/*  268 */     this._filter.applyNX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply10(float[][] x, float[][] y) {
/*  278 */     this._filter.applyXN(0, x, y);
/*  279 */     this._filter.applyNX(1, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply01(float[][] x, float[][] y) {
/*  289 */     this._filter.applyXN(1, x, y);
/*  290 */     this._filter.applyNX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply11(float[][] x, float[][] y) {
/*  299 */     this._filter.applyXN(1, x, y);
/*  300 */     this._filter.applyNX(1, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply20(float[][] x, float[][] y) {
/*  310 */     this._filter.applyXN(0, x, y);
/*  311 */     this._filter.applyNX(2, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply02(float[][] x, float[][] y) {
/*  321 */     this._filter.applyXN(2, x, y);
/*  322 */     this._filter.applyNX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply000(float[][][] x, float[][][] y) {
/*  331 */     this._filter.applyXXN(0, x, y);
/*  332 */     this._filter.applyXNX(0, y, y);
/*  333 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply100(float[][][] x, float[][][] y) {
/*  343 */     this._filter.applyXXN(0, x, y);
/*  344 */     this._filter.applyXNX(0, y, y);
/*  345 */     this._filter.applyNXX(1, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply010(float[][][] x, float[][][] y) {
/*  355 */     this._filter.applyXXN(0, x, y);
/*  356 */     this._filter.applyXNX(1, y, y);
/*  357 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply001(float[][][] x, float[][][] y) {
/*  367 */     this._filter.applyXXN(1, x, y);
/*  368 */     this._filter.applyXNX(0, y, y);
/*  369 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply110(float[][][] x, float[][][] y) {
/*  379 */     this._filter.applyXXN(0, x, y);
/*  380 */     this._filter.applyXNX(1, y, y);
/*  381 */     this._filter.applyNXX(1, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply101(float[][][] x, float[][][] y) {
/*  391 */     this._filter.applyXXN(1, x, y);
/*  392 */     this._filter.applyXNX(0, y, y);
/*  393 */     this._filter.applyNXX(1, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply011(float[][][] x, float[][][] y) {
/*  403 */     this._filter.applyXXN(1, x, y);
/*  404 */     this._filter.applyXNX(1, y, y);
/*  405 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply200(float[][][] x, float[][][] y) {
/*  415 */     this._filter.applyXXN(0, x, y);
/*  416 */     this._filter.applyXNX(0, y, y);
/*  417 */     this._filter.applyNXX(2, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply020(float[][][] x, float[][][] y) {
/*  427 */     this._filter.applyXXN(0, x, y);
/*  428 */     this._filter.applyXNX(2, y, y);
/*  429 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply002(float[][][] x, float[][][] y) {
/*  439 */     this._filter.applyXXN(2, x, y);
/*  440 */     this._filter.applyXNX(0, y, y);
/*  441 */     this._filter.applyNXX(0, y, y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkArrays(float[] x, float[] y) {
/*  450 */     Check.argument((x.length == y.length), "x.length==y.length");
/*      */   }
/*      */   
/*      */   private static void checkArrays(float[][] x, float[][] y) {
/*  454 */     Check.argument((x.length == y.length), "x.length==y.length");
/*  455 */     Check.argument(((x[0]).length == (y[0]).length), "x[0].length==y[0].length");
/*  456 */     Check.argument(Array.isRegular(x), "x is regular");
/*  457 */     Check.argument(Array.isRegular(y), "y is regular");
/*      */   }
/*      */   
/*      */   private static void checkArrays(float[][][] x, float[][][] y) {
/*  461 */     Check.argument((x.length == y.length), "x.length==y.length");
/*  462 */     Check.argument(((x[0]).length == (y[0]).length), "x[0].length==y[0].length");
/*  463 */     Check.argument(((x[0][0]).length == (y[0][0]).length), "x[0][0].length==y[0][0].length");
/*      */     
/*  465 */     Check.argument(Array.isRegular(x), "x is regular");
/*  466 */     Check.argument(Array.isRegular(y), "y is regular");
/*      */   }
/*      */   
/*      */   private static boolean sameArrays(float[] x, float[] y) {
/*  470 */     return (x == y);
/*      */   }
/*      */   
/*      */   private static boolean sameArrays(float[][] x, float[][] y) {
/*  474 */     if (x == y) {
/*  475 */       return true;
/*      */     }
/*  477 */     int n2 = x.length;
/*  478 */     for (int i2 = 0; i2 < n2; i2++) {
/*  479 */       if (x[i2] == y[i2])
/*  480 */         return true; 
/*      */     } 
/*  482 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static abstract class Filter
/*      */   {
/*      */     private Filter() {}
/*      */ 
/*      */     
/*      */     void applyNX(int nd, float[][] x, float[][] y) {
/*  493 */       int m2 = y.length;
/*  494 */       for (int i2 = 0; i2 < m2; i2++)
/*  495 */         applyN(nd, x[i2], y[i2]); 
/*      */     }
/*      */     
/*      */     void applyNXX(final int nd, final float[][][] x, final float[][][] y) {
/*  499 */       final int m3 = y.length;
/*  500 */       final AtomicInteger ai = new AtomicInteger();
/*  501 */       Thread[] threads = RecursiveGaussianFilter.newThreads();
/*  502 */       for (int ithread = 0; ithread < threads.length; ithread++) {
/*  503 */         threads[ithread] = new Thread(new Runnable() {
/*      */               public void run() {
/*  505 */                 for (int i3 = ai.getAndIncrement(); i3 < m3; i3 = ai.getAndIncrement())
/*  506 */                   RecursiveGaussianFilter.Filter.this.applyNX(nd, x[i3], y[i3]); 
/*      */               }
/*      */             });
/*      */       } 
/*  510 */       RecursiveGaussianFilter.startAndJoin(threads);
/*      */     }
/*      */     
/*      */     void applyXNX(final int nd, final float[][][] x, final float[][][] y) {
/*  514 */       final int m3 = y.length;
/*  515 */       final AtomicInteger ai = new AtomicInteger();
/*  516 */       Thread[] threads = RecursiveGaussianFilter.newThreads();
/*  517 */       for (int ithread = 0; ithread < threads.length; ithread++) {
/*  518 */         threads[ithread] = new Thread(new Runnable() {
/*      */               public void run() {
/*  520 */                 for (int i3 = ai.getAndIncrement(); i3 < m3; i3 = ai.getAndIncrement())
/*  521 */                   RecursiveGaussianFilter.Filter.this.applyXN(nd, x[i3], y[i3]); 
/*      */               }
/*      */             });
/*      */       } 
/*  525 */       RecursiveGaussianFilter.startAndJoin(threads);
/*      */     }
/*      */     
/*      */     void applyXXN(final int nd, final float[][][] x, final float[][][] y) {
/*  529 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  530 */       final int m3 = y.length;
/*  531 */       final int m2 = (y[0]).length;
/*  532 */       final AtomicInteger ai = new AtomicInteger();
/*  533 */       Thread[] threads = RecursiveGaussianFilter.newThreads();
/*  534 */       for (int ithread = 0; ithread < threads.length; ithread++) {
/*  535 */         threads[ithread] = new Thread(new Runnable() {
/*      */               public void run() {
/*  537 */                 float[][] x2 = new float[m3][];
/*  538 */                 float[][] y2 = new float[m3][];
/*  539 */                 for (int i2 = ai.getAndIncrement(); i2 < m2; i2 = ai.getAndIncrement()) {
/*  540 */                   for (int i3 = 0; i3 < m3; i3++) {
/*  541 */                     x2[i3] = x[i3][i2];
/*  542 */                     y2[i3] = y[i3][i2];
/*      */                   } 
/*  544 */                   RecursiveGaussianFilter.Filter.this.applyXN(nd, x2, y2);
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*  549 */       RecursiveGaussianFilter.startAndJoin(threads);
/*      */     }
/*      */     abstract void applyN(int param1Int, float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*      */     void xxxapplyXXN(int nd, float[][][] x, float[][][] y) {
/*  553 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  554 */       int m3 = y.length;
/*  555 */       int m2 = (y[0]).length;
/*  556 */       float[][] x2 = new float[m3][];
/*  557 */       float[][] y2 = new float[m3][];
/*  558 */       for (int i2 = 0; i2 < m2; i2++) {
/*  559 */         for (int i3 = 0; i3 < m3; i3++) {
/*  560 */           x2[i3] = x[i3][i2];
/*  561 */           y2[i3] = y[i3][i2];
/*      */         } 
/*  563 */         applyXN(nd, x2, y2);
/*      */       } 
/*      */     }
/*      */     abstract void applyXN(int param1Int, float[][] param1ArrayOffloat1, float[][] param1ArrayOffloat2); }
/*      */   
/*      */   private static Thread[] newThreads() {
/*  569 */     int nthread = Runtime.getRuntime().availableProcessors();
/*  570 */     return new Thread[nthread];
/*      */   }
/*      */   private static void startAndJoin(Thread[] threads) {
/*      */     int ithread;
/*  574 */     for (ithread = 0; ithread < threads.length; ithread++)
/*  575 */       threads[ithread].start(); 
/*      */     try {
/*  577 */       for (ithread = 0; ithread < threads.length; ithread++)
/*  578 */         threads[ithread].join(); 
/*  579 */     } catch (InterruptedException ie) {
/*  580 */       throw new RuntimeException(ie);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class DericheFilter
/*      */     extends Filter
/*      */   {
/*      */     DericheFilter(double sigma) {
/*  588 */       makeND(sigma);
/*      */     }
/*      */     
/*      */     void applyN(int nd, float[] x, float[] y) {
/*  592 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  593 */       if (RecursiveGaussianFilter.sameArrays(x, y))
/*  594 */         x = Array.copy(x); 
/*  595 */       int m = y.length;
/*  596 */       float n0 = this._n0[nd], n1 = this._n1[nd], n2 = this._n2[nd], n3 = this._n3[nd];
/*  597 */       float d1 = this._d1[nd], d2 = this._d2[nd], d3 = this._d3[nd], d4 = this._d4[nd];
/*  598 */       float yim4 = 0.0F, yim3 = 0.0F, yim2 = 0.0F, yim1 = 0.0F;
/*  599 */       float xim3 = 0.0F, xim2 = 0.0F, xim1 = 0.0F;
/*  600 */       for (int i = 0; i < m; i++) {
/*  601 */         float xi = x[i];
/*  602 */         float yi = n0 * xi + n1 * xim1 + n2 * xim2 + n3 * xim3 - d1 * yim1 - d2 * yim2 - d3 * yim3 - d4 * yim4;
/*      */         
/*  604 */         y[i] = yi;
/*  605 */         yim4 = yim3; yim3 = yim2; yim2 = yim1; yim1 = yi;
/*  606 */         xim3 = xim2; xim2 = xim1; xim1 = xi;
/*      */       } 
/*  608 */       n1 -= d1 * n0;
/*  609 */       n2 -= d2 * n0;
/*  610 */       n3 -= d3 * n0;
/*  611 */       float n4 = -d4 * n0;
/*  612 */       if (nd % 2 != 0) {
/*  613 */         n1 = -n1; n2 = -n2; n3 = -n3; n4 = -n4;
/*      */       } 
/*  615 */       float yip4 = 0.0F, yip3 = 0.0F, yip2 = 0.0F, yip1 = 0.0F;
/*  616 */       float xip4 = 0.0F, xip3 = 0.0F, xip2 = 0.0F, xip1 = 0.0F;
/*  617 */       for (int j = m - 1; j >= 0; j--) {
/*  618 */         float xi = x[j];
/*  619 */         float yi = n1 * xip1 + n2 * xip2 + n3 * xip3 + n4 * xip4 - d1 * yip1 - d2 * yip2 - d3 * yip3 - d4 * yip4;
/*      */         
/*  621 */         y[j] = y[j] + yi;
/*  622 */         yip4 = yip3; yip3 = yip2; yip2 = yip1; yip1 = yi;
/*  623 */         xip4 = xip3; xip3 = xip2; xip2 = xip1; xip1 = xi;
/*      */       } 
/*      */     }
/*      */     
/*      */     void applyXN(int nd, float[][] x, float[][] y) {
/*  628 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  629 */       if (RecursiveGaussianFilter.sameArrays(x, y))
/*  630 */         x = Array.copy(x); 
/*  631 */       int m2 = y.length;
/*  632 */       int m1 = (y[0]).length;
/*  633 */       float n0 = this._n0[nd], n1 = this._n1[nd], n2 = this._n2[nd], n3 = this._n3[nd];
/*  634 */       float d1 = this._d1[nd], d2 = this._d2[nd], d3 = this._d3[nd], d4 = this._d4[nd];
/*  635 */       float[] yim4 = new float[m1];
/*  636 */       float[] yim3 = new float[m1];
/*  637 */       float[] yim2 = new float[m1];
/*  638 */       float[] yim1 = new float[m1];
/*  639 */       float[] xim4 = new float[m1];
/*  640 */       float[] xim3 = new float[m1];
/*  641 */       float[] xim2 = new float[m1];
/*  642 */       float[] xim1 = new float[m1];
/*  643 */       float[] yi = new float[m1];
/*  644 */       float[] xi = new float[m1];
/*  645 */       for (int i2 = 0; i2 < m2; i2++) {
/*  646 */         float[] x2 = x[i2];
/*  647 */         float[] y2 = y[i2];
/*  648 */         for (int j = 0; j < m1; j++) {
/*  649 */           xi[j] = x2[j];
/*  650 */           yi[j] = n0 * xi[j] + n1 * xim1[j] + n2 * xim2[j] + n3 * xim3[j] - d1 * yim1[j] - d2 * yim2[j] - d3 * yim3[j] - d4 * yim4[j];
/*      */           
/*  652 */           y2[j] = yi[j];
/*      */         } 
/*  654 */         float[] yt = yim4;
/*  655 */         yim4 = yim3;
/*  656 */         yim3 = yim2;
/*  657 */         yim2 = yim1;
/*  658 */         yim1 = yi;
/*  659 */         yi = yt;
/*  660 */         float[] xt = xim3;
/*  661 */         xim3 = xim2;
/*  662 */         xim2 = xim1;
/*  663 */         xim1 = xi;
/*  664 */         xi = xt;
/*      */       } 
/*  666 */       n1 -= d1 * n0;
/*  667 */       n2 -= d2 * n0;
/*  668 */       n3 -= d3 * n0;
/*  669 */       float n4 = -d4 * n0;
/*  670 */       if (nd % 2 != 0) {
/*  671 */         n1 = -n1; n2 = -n2; n3 = -n3; n4 = -n4;
/*      */       } 
/*  673 */       float[] yip4 = yim4;
/*  674 */       float[] yip3 = yim3;
/*  675 */       float[] yip2 = yim2;
/*  676 */       float[] yip1 = yim1;
/*  677 */       float[] xip4 = xim4;
/*  678 */       float[] xip3 = xim3;
/*  679 */       float[] xip2 = xim2;
/*  680 */       float[] xip1 = xim1;
/*  681 */       for (int i1 = 0; i1 < m1; i1++) {
/*  682 */         yip4[i1] = 0.0F;
/*  683 */         yip3[i1] = 0.0F;
/*  684 */         yip2[i1] = 0.0F;
/*  685 */         yip1[i1] = 0.0F;
/*  686 */         xip4[i1] = 0.0F;
/*  687 */         xip3[i1] = 0.0F;
/*  688 */         xip2[i1] = 0.0F;
/*  689 */         xip1[i1] = 0.0F;
/*      */       } 
/*  691 */       for (int i = m2 - 1; i >= 0; i--) {
/*  692 */         float[] x2 = x[i];
/*  693 */         float[] y2 = y[i];
/*  694 */         for (int j = 0; j < m1; j++) {
/*  695 */           xi[j] = x2[j];
/*  696 */           yi[j] = n1 * xip1[j] + n2 * xip2[j] + n3 * xip3[j] + n4 * xip4[j] - d1 * yip1[j] - d2 * yip2[j] - d3 * yip3[j] - d4 * yip4[j];
/*      */           
/*  698 */           y2[j] = y2[j] + yi[j];
/*      */         } 
/*  700 */         float[] yt = yip4;
/*  701 */         yip4 = yip3;
/*  702 */         yip3 = yip2;
/*  703 */         yip2 = yip1;
/*  704 */         yip1 = yi;
/*  705 */         yi = yt;
/*  706 */         float[] xt = xip4;
/*  707 */         xip4 = xip3;
/*  708 */         xip3 = xip2;
/*  709 */         xip2 = xip1;
/*  710 */         xip1 = xi;
/*  711 */         xi = xt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  720 */     private static double a00 = 1.6797292232361107D;
/*  721 */     private static double a10 = 3.734829826910358D;
/*  722 */     private static double b00 = 1.7831906544515104D;
/*  723 */     private static double b10 = 1.7228297663338028D;
/*  724 */     private static double c00 = -0.6802783501806897D;
/*  725 */     private static double c10 = -0.2598300478959625D;
/*  726 */     private static double w00 = 0.6318113174569493D;
/*  727 */     private static double w10 = 1.996927683248777D;
/*      */     
/*  729 */     private static double a01 = 0.649402400844062D;
/*  730 */     private static double a11 = 0.9557370760729773D;
/*  731 */     private static double b01 = 1.5159726670750566D;
/*  732 */     private static double b11 = 1.526760873479114D;
/*  733 */     private static double c01 = -0.6472105276644291D;
/*  734 */     private static double c11 = -4.530692304457076D;
/*  735 */     private static double w01 = 2.071895365878265D;
/*  736 */     private static double w11 = 0.6719055957689513D;
/*      */     
/*  738 */     private static double a02 = 0.3224570510072559D;
/*  739 */     private static double a12 = -1.7382843963561239D;
/*  740 */     private static double b02 = 1.313805492651688D;
/*  741 */     private static double b12 = 1.2402181393295362D;
/*  742 */     private static double c02 = -1.3312275593739595D;
/*  743 */     private static double c12 = 3.6607035671974897D;
/*  744 */     private static double w02 = 2.1656041357418863D;
/*  745 */     private static double w12 = 0.7479888745408682D;
/*      */     
/*  747 */     private static double[] a0 = new double[] { a00, a01, a02 };
/*  748 */     private static double[] a1 = new double[] { a10, a11, a12 };
/*  749 */     private static double[] b0 = new double[] { b00, b01, b02 };
/*  750 */     private static double[] b1 = new double[] { b10, b11, b12 };
/*  751 */     private static double[] c0 = new double[] { c00, c01, c02 };
/*  752 */     private static double[] c1 = new double[] { c10, c11, c12 };
/*  753 */     private static double[] w0 = new double[] { w00, w01, w02 };
/*  754 */     private static double[] w1 = new double[] { w10, w11, w12 };
/*      */     
/*      */     private float[] _n0;
/*      */     
/*      */     private float[] _n1;
/*      */     
/*      */     private float[] _n2;
/*      */     
/*      */     private float[] _n3;
/*      */     
/*      */     private float[] _d1;
/*      */     
/*      */     private float[] _d2;
/*      */     
/*      */     private float[] _d3;
/*      */     
/*      */     private float[] _d4;
/*      */ 
/*      */     
/*      */     private void makeND(double sigma) {
/*  774 */       this._n0 = new float[3];
/*  775 */       this._n1 = new float[3];
/*  776 */       this._n2 = new float[3];
/*  777 */       this._n3 = new float[3];
/*  778 */       this._d1 = new float[3];
/*  779 */       this._d2 = new float[3];
/*  780 */       this._d3 = new float[3];
/*  781 */       this._d4 = new float[3];
/*      */ 
/*      */       
/*  784 */       for (int i = 0; i < 3; i++) {
/*  785 */         double n0 = a0[i] + c0[i];
/*  786 */         double n1 = MathPlus.exp(-b1[i] / sigma) * (c1[i] * MathPlus.sin(w1[i] / sigma) - (c0[i] + 2.0D * a0[i]) * MathPlus.cos(w1[i] / sigma)) + MathPlus.exp(-b0[i] / sigma) * (a1[i] * MathPlus.sin(w0[i] / sigma) - (2.0D * c0[i] + a0[i]) * MathPlus.cos(w0[i] / sigma));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  792 */         double n2 = 2.0D * MathPlus.exp(-(b0[i] + b1[i]) / sigma) * ((a0[i] + c0[i]) * MathPlus.cos(w1[i] / sigma) * MathPlus.cos(w0[i] / sigma) - a1[i] * MathPlus.cos(w1[i] / sigma) * MathPlus.sin(w0[i] / sigma) - c1[i] * MathPlus.cos(w0[i] / sigma) * MathPlus.sin(w1[i] / sigma)) + c0[i] * MathPlus.exp(-2.0D * b0[i] / sigma) + a0[i] * MathPlus.exp(-2.0D * b1[i] / sigma);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  798 */         double n3 = MathPlus.exp(-(b1[i] + 2.0D * b0[i]) / sigma) * (c1[i] * MathPlus.sin(w1[i] / sigma) - c0[i] * MathPlus.cos(w1[i] / sigma)) + MathPlus.exp(-(b0[i] + 2.0D * b1[i]) / sigma) * (a1[i] * MathPlus.sin(w0[i] / sigma) - a0[i] * MathPlus.cos(w0[i] / sigma));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  804 */         double d1 = -2.0D * MathPlus.exp(-b0[i] / sigma) * MathPlus.cos(w0[i] / sigma) - 2.0D * MathPlus.exp(-b1[i] / sigma) * MathPlus.cos(w1[i] / sigma);
/*      */         
/*  806 */         double d2 = 4.0D * MathPlus.exp(-(b0[i] + b1[i]) / sigma) * MathPlus.cos(w0[i] / sigma) * MathPlus.cos(w1[i] / sigma) + MathPlus.exp(-2.0D * b0[i] / sigma) + MathPlus.exp(-2.0D * b1[i] / sigma);
/*      */ 
/*      */ 
/*      */         
/*  810 */         double d3 = -2.0D * MathPlus.exp(-(b0[i] + 2.0D * b1[i]) / sigma) * MathPlus.cos(w0[i] / sigma) - 2.0D * MathPlus.exp(-(b1[i] + 2.0D * b0[i]) / sigma) * MathPlus.cos(w1[i] / sigma);
/*      */         
/*  812 */         double d4 = MathPlus.exp(-2.0D * (b0[i] + b1[i]) / sigma);
/*  813 */         this._n0[i] = (float)n0;
/*  814 */         this._n1[i] = (float)n1;
/*  815 */         this._n2[i] = (float)n2;
/*  816 */         this._n3[i] = (float)n3;
/*  817 */         this._d1[i] = (float)d1;
/*  818 */         this._d2[i] = (float)d2;
/*  819 */         this._d3[i] = (float)d3;
/*  820 */         this._d4[i] = (float)d4;
/*      */       } 
/*  822 */       scaleN(sigma);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void scaleN(double sigma) {
/*  832 */       int n = 1 + 2 * (int)(10.0D * sigma);
/*  833 */       float[] x = new float[n];
/*  834 */       float[] y0 = new float[n];
/*  835 */       float[] y1 = new float[n];
/*  836 */       float[] y2 = new float[n];
/*  837 */       int m = (n - 1) / 2;
/*  838 */       x[m] = 1.0F;
/*  839 */       applyN(0, x, y0);
/*  840 */       applyN(1, x, y1);
/*  841 */       applyN(2, x, y2);
/*  842 */       double[] s = new double[3]; int i, j;
/*  843 */       for (i = 0, j = n - 1; i < j; i++, j--) {
/*  844 */         double t = (i - m);
/*  845 */         s[0] = s[0] + (y0[j] + y0[i]);
/*  846 */         s[1] = s[1] + MathPlus.sin(t / sigma) * (y1[j] - y1[i]);
/*  847 */         s[2] = s[2] + MathPlus.cos(t * MathPlus.sqrt(2.0D) / sigma) * (y2[j] + y2[i]);
/*      */       } 
/*  849 */       s[0] = s[0] + y0[m];
/*  850 */       s[2] = s[2] + y2[m];
/*  851 */       s[1] = s[1] * sigma * MathPlus.exp(0.5D);
/*  852 */       s[2] = s[2] * -(sigma * sigma) / 2.0D * MathPlus.exp(1.0D);
/*  853 */       for (i = 0; i < 3; i++) {
/*  854 */         this._n0[i] = (float)(this._n0[i] / s[i]);
/*  855 */         this._n1[i] = (float)(this._n1[i] / s[i]);
/*  856 */         this._n2[i] = (float)(this._n2[i] / s[i]);
/*  857 */         this._n3[i] = (float)(this._n3[i] / s[i]);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class VanVlietFilter
/*      */     extends Filter
/*      */   {
/*      */     VanVlietFilter(double sigma) {
/*  866 */       makeG(sigma);
/*      */     }
/*      */     
/*      */     void applyN(int nd, float[] x, float[] y) {
/*  870 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  871 */       if (RecursiveGaussianFilter.sameArrays(x, y))
/*  872 */         x = Array.copy(x); 
/*  873 */       this._g[nd][0][0].applyForward(x, y);
/*  874 */       this._g[nd][0][1].accumulateReverse(x, y);
/*  875 */       this._g[nd][1][0].accumulateForward(x, y);
/*  876 */       this._g[nd][1][1].accumulateReverse(x, y);
/*      */     }
/*      */     
/*      */     void applyXN(int nd, float[][] x, float[][] y) {
/*  880 */       RecursiveGaussianFilter.checkArrays(x, y);
/*  881 */       if (RecursiveGaussianFilter.sameArrays(x, y))
/*  882 */         x = Array.copy(x); 
/*  883 */       this._g[nd][0][0].apply2Forward(x, y);
/*  884 */       this._g[nd][0][1].accumulate2Reverse(x, y);
/*  885 */       this._g[nd][1][0].accumulate2Forward(x, y);
/*  886 */       this._g[nd][1][1].accumulate2Reverse(x, y);
/*      */     }
/*      */ 
/*      */     
/*  890 */     private static Cdouble[][] POLES = new Cdouble[][] { { new Cdouble(1.12075D, 1.27788D), new Cdouble(1.12075D, -1.27788D), new Cdouble(1.76952D, 0.46611D), new Cdouble(1.76952D, -0.46611D) }, { new Cdouble(1.04185D, 1.24034D), new Cdouble(1.04185D, -1.24034D), new Cdouble(1.69747D, 0.4479D), new Cdouble(1.69747D, -0.4479D) }, { new Cdouble(0.9457D, 1.21064D), new Cdouble(0.9457D, -1.21064D), new Cdouble(1.60161D, 0.42647D), new Cdouble(1.60161D, -0.42647D) } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Recursive2ndOrderFilter[][][] _g;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void makeG(double sigma) {
/*  908 */       this._g = new Recursive2ndOrderFilter[3][2][2];
/*      */ 
/*      */       
/*  911 */       for (int nd = 0; nd < 3; nd++) {
/*      */ 
/*      */         
/*  914 */         Cdouble[] poles = adjustPoles(sigma, POLES[nd]);
/*      */ 
/*      */         
/*  917 */         double gain = computeGain(poles);
/*  918 */         double gg = gain * gain;
/*      */ 
/*      */         
/*  921 */         Cdouble d0 = new Cdouble(poles[0]);
/*  922 */         Cdouble d1 = new Cdouble(poles[2]);
/*  923 */         Cdouble e0 = d0.inv();
/*  924 */         Cdouble e1 = d1.inv();
/*  925 */         Cdouble g0 = gr(nd, d0, poles, gg);
/*  926 */         Cdouble g1 = gr(nd, d1, poles, gg);
/*      */ 
/*      */         
/*  929 */         double a10 = -2.0D * d0.r;
/*  930 */         double a11 = -2.0D * d1.r;
/*  931 */         double a20 = d0.norm();
/*  932 */         double a21 = d1.norm();
/*      */ 
/*      */ 
/*      */         
/*  936 */         if (nd == 0 || nd == 2) {
/*  937 */           double b10 = g0.i / e0.i;
/*  938 */           double b11 = g1.i / e1.i;
/*  939 */           double b00 = g0.r - b10 * e0.r;
/*  940 */           double b01 = g1.r - b11 * e1.r;
/*  941 */           double b20 = 0.0D;
/*  942 */           double b21 = 0.0D;
/*  943 */           this._g[nd][0][0] = makeFilter(b00, b10, b20, a10, a20);
/*  944 */           this._g[nd][1][0] = makeFilter(b01, b11, b21, a11, a21);
/*  945 */           b20 -= b00 * a20;
/*  946 */           b21 -= b01 * a21;
/*  947 */           b10 -= b00 * a10;
/*  948 */           b11 -= b01 * a11;
/*  949 */           b00 = 0.0D;
/*  950 */           b01 = 0.0D;
/*  951 */           this._g[nd][0][1] = makeFilter(b00, b10, b20, a10, a20);
/*  952 */           this._g[nd][1][1] = makeFilter(b01, b11, b21, a11, a21);
/*      */         
/*      */         }
/*  955 */         else if (nd == 1) {
/*  956 */           double b20 = g0.i / e0.i;
/*  957 */           double b21 = g1.i / e1.i;
/*  958 */           double b10 = g0.r - b20 * e0.r;
/*  959 */           double b11 = g1.r - b21 * e1.r;
/*  960 */           double b00 = 0.0D;
/*  961 */           double b01 = 0.0D;
/*  962 */           this._g[nd][0][0] = makeFilter(b00, b10, b20, a10, a20);
/*  963 */           this._g[nd][1][0] = makeFilter(b01, b11, b21, a11, a21);
/*  964 */           b20 = -b20;
/*  965 */           b21 = -b21;
/*  966 */           b10 = -b10;
/*  967 */           b11 = -b11;
/*  968 */           b00 = 0.0D;
/*  969 */           b01 = 0.0D;
/*  970 */           this._g[nd][0][1] = makeFilter(b00, b10, b20, a10, a20);
/*  971 */           this._g[nd][1][1] = makeFilter(b01, b11, b21, a11, a21);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     Recursive2ndOrderFilter makeFilter(double b0, double b1, double b2, double a1, double a2) {
/*  978 */       return new Recursive2ndOrderFilter((float)b0, (float)b1, (float)b2, (float)a1, (float)a2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Cdouble gr(int nd, Cdouble polej, Cdouble[] poles, double gain) {
/*  986 */       Cdouble pj = polej;
/*  987 */       Cdouble qj = pj.inv();
/*  988 */       Cdouble c1 = new Cdouble(1.0D, 0.0D);
/*  989 */       Cdouble gz = new Cdouble(c1);
/*  990 */       if (nd == 1) {
/*  991 */         gz.timesEquals(c1.minus(qj));
/*  992 */         gz.timesEquals(c1.plus(pj));
/*  993 */         gz.timesEquals(pj);
/*  994 */         gz.timesEquals(0.5D);
/*  995 */       } else if (nd == 2) {
/*  996 */         gz.timesEquals(c1.minus(qj));
/*  997 */         gz.timesEquals(c1.minus(pj));
/*  998 */         gz.timesEquals(-1.0D);
/*      */       } 
/* 1000 */       Cdouble gp = new Cdouble(c1);
/* 1001 */       int np = poles.length;
/* 1002 */       for (int ip = 0; ip < np; ip++) {
/* 1003 */         Cdouble pi = poles[ip];
/* 1004 */         if (!pi.equals(pj) && !pi.equals(pj.conj()))
/* 1005 */           gp.timesEquals(c1.minus(pi.times(qj))); 
/* 1006 */         gp.timesEquals(c1.minus(pi.times(pj)));
/*      */       } 
/* 1008 */       return gz.over(gp).times(gain);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static Cdouble[] adjustPoles(double sigma, Cdouble[] poles) {
/* 1014 */       double q = sigma;
/* 1015 */       double s = computeSigma(q, poles);
/* 1016 */       for (int iter = 0; MathPlus.abs(sigma - s) > sigma * 1.0E-8D; iter++) {
/*      */         
/* 1018 */         Check.state((iter < 100), "number of iterations less than 100");
/* 1019 */         s = computeSigma(q, poles);
/* 1020 */         q *= sigma / s;
/*      */       } 
/*      */ 
/*      */       
/* 1024 */       int npole = poles.length;
/* 1025 */       Cdouble[] apoles = new Cdouble[npole];
/* 1026 */       for (int ipole = 0; ipole < npole; ipole++) {
/* 1027 */         Cdouble pi = poles[ipole];
/* 1028 */         double a = MathPlus.pow(pi.abs(), 2.0D / q);
/* 1029 */         double t = MathPlus.atan2(pi.i, pi.r) * 2.0D / q;
/* 1030 */         apoles[ipole] = Cdouble.polar(a, t).inv();
/*      */       } 
/* 1032 */       return apoles;
/*      */     }
/*      */     
/*      */     private static double computeGain(Cdouble[] poles) {
/* 1036 */       int npole = poles.length;
/* 1037 */       Cdouble c1 = new Cdouble(1.0D, 0.0D);
/* 1038 */       Cdouble cg = new Cdouble(c1);
/* 1039 */       for (int ipole = 0; ipole < npole; ipole++) {
/* 1040 */         cg.timesEquals(c1.minus(poles[ipole]));
/*      */       }
/* 1042 */       return cg.r;
/*      */     }
/*      */     
/*      */     private static double computeSigma(double sigma, Cdouble[] poles) {
/* 1046 */       int npole = poles.length;
/* 1047 */       double q = sigma / 2.0D;
/* 1048 */       Cdouble c1 = new Cdouble(1.0D);
/* 1049 */       Cdouble cs = new Cdouble();
/* 1050 */       for (int ipole = 0; ipole < npole; ipole++) {
/* 1051 */         Cdouble pi = poles[ipole];
/* 1052 */         double a = MathPlus.pow(pi.abs(), -1.0D / q);
/* 1053 */         double t = MathPlus.atan2(pi.i, pi.r) / q;
/* 1054 */         Cdouble b = Cdouble.polar(a, t);
/* 1055 */         Cdouble c = c1.minus(b);
/* 1056 */         Cdouble d = c.times(c);
/* 1057 */         cs.plusEquals(b.times(2.0D).over(d));
/*      */       } 
/* 1059 */       return MathPlus.sqrt(cs.r);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/RecursiveGaussianFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */