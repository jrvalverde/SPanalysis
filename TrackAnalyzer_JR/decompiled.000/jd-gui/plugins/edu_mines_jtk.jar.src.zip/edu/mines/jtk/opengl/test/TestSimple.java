/*    */ package edu.mines.jtk.opengl.test;
/*    */ 
/*    */ import edu.mines.jtk.opengl.GlCanvas;
/*    */ import edu.mines.jtk.opengl.GlPainter;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestSimple
/*    */ {
/*    */   private static final int SIZE = 600;
/*    */   
/*    */   public static void run(String[] args, GlPainter painter) {
/* 25 */     run(args, painter, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void run(String[] args, GlPainter painter, boolean autoRepaint) {
/* 30 */     run(painter, autoRepaint);
/*    */   }
/*    */   public static void run(GlPainter painter, boolean autoRepaint) {
/* 33 */     GlCanvas canvas = new GlCanvas(painter);
/* 34 */     canvas.setAutoRepaint(autoRepaint);
/* 35 */     JFrame frame = new JFrame();
/* 36 */     frame.setDefaultCloseOperation(3);
/* 37 */     frame.setSize(new Dimension(600, 600));
/* 38 */     frame.getContentPane().add((Component)canvas, "Center");
/* 39 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/test/TestSimple.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */