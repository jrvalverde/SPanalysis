/*     */ package edu.mines.jtk.opt.test;
/*     */ 
/*     */ import edu.mines.jtk.opt.BrentZeroFinder;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrentZeroFinderTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  22 */     TestSuite suite = new TestSuite(BrentZeroFinderTest.class);
/*  23 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testForsythe() {
/*  27 */     ZeroFunc1 f1 = new ZeroFunc1();
/*  28 */     f1.findZero(2.0D, 3.0D);
/*  29 */     ZeroFunc2 f2 = new ZeroFunc2();
/*  30 */     f2.findZero(-1.0D, 3.0D);
/*  31 */     ZeroFunc3 f3 = new ZeroFunc3();
/*  32 */     f3.findZero(-1.0D, 3.0D);
/*     */   }
/*     */   
/*     */   abstract class BrentTestFunc implements BrentZeroFinder.Function { private int _count;
/*     */     
/*     */     void findZero(double a, double b) {
/*  38 */       this._count = 0;
/*  39 */       BrentZeroFinder zeroFinder = new BrentZeroFinder(this);
/*  40 */       double xzero = zeroFinder.findZero(a, b, 2.220446049250313E-16D);
/*  41 */       double yzero = evaluate(xzero);
/*  42 */       checkRoot(xzero);
/*  43 */       checkFunc(yzero);
/*  44 */       checkCount(this._count);
/*     */     } abstract double eval(double param1Double); abstract void checkRoot(double param1Double);
/*     */     public double evaluate(double x) {
/*  47 */       this._count++;
/*  48 */       return eval(x);
/*     */     }
/*     */     
/*     */     abstract void checkFunc(double param1Double);
/*     */     
/*     */     abstract void checkCount(int param1Int); }
/*     */ 
/*     */   
/*     */   class ZeroFunc1 extends BrentTestFunc {
/*     */     double eval(double x) {
/*  58 */       return (MathPlus.pow(x, 2.0D) - 2.0D) * x - 5.0D;
/*     */     }
/*     */     void checkRoot(double x) {
/*  61 */       BrentZeroFinderTest.assertEqual(x, 2.094551482D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  64 */       BrentZeroFinderTest.assertEqual(y, -1.7764E-15D);
/*     */     }
/*     */     void checkCount(int count) {
/*  67 */       BrentZeroFinderTest.assertEqual(count, 11.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   class ZeroFunc2 extends BrentTestFunc { double eval(double x) {
/*  72 */       return MathPlus.cos(x) - x;
/*     */     }
/*     */     void checkRoot(double x) {
/*  75 */       BrentZeroFinderTest.assertEqual(x, 0.7390851332D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  78 */       BrentZeroFinderTest.assertEqual(y, 0.0D);
/*     */     }
/*     */     void checkCount(int count) {
/*  81 */       BrentZeroFinderTest.assertEqual(count, 11.0D);
/*     */     } }
/*     */   
/*     */   class ZeroFunc3 extends BrentTestFunc {
/*     */     double eval(double x) {
/*  86 */       return MathPlus.sin(x) - x;
/*     */     }
/*     */     void checkRoot(double x) {
/*  89 */       BrentZeroFinderTest.assertEqual(x, -1.643737357E-8D);
/*     */     }
/*     */     void checkFunc(double y) {
/*  92 */       BrentZeroFinderTest.assertEqual(y, 0.0D);
/*     */     }
/*     */     void checkCount(int count) {
/*  95 */       BrentZeroFinderTest.assertEqual(count, 58.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void assertEqual(double x, double y) {
/* 100 */     assertTrue(x + " = " + y, almostEqual(x, y));
/*     */   }
/*     */   
/*     */   private static boolean almostEqual(double x, double y) {
/* 104 */     double ax = MathPlus.abs(x);
/* 105 */     double ay = MathPlus.abs(y);
/* 106 */     return (MathPlus.abs(x - y) <= 1.0E-4D * MathPlus.max(ax, ay));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/BrentZeroFinderTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */