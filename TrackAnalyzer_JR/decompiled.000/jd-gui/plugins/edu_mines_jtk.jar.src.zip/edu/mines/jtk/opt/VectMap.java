/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectMap
/*     */   implements VectContainer
/*     */ {
/*  19 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   
/*  21 */   private LinkedHashMap<Integer, Vect> _map = new LinkedHashMap<Integer, Vect>();
/*     */ 
/*     */   
/*     */   private boolean _cloneContents = false;
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   
/*     */   public VectMap(boolean cloneContents) {
/*  30 */     if (cloneContents) {
/*  31 */       LOG.warning("Cloning hurts performance.  Use only for testing a VectContainer that requires puts.");
/*     */     }
/*     */     
/*  34 */     this._cloneContents = cloneContents;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(int index, Vect vect) {
/*  39 */     this._map.put(Integer.valueOf(index), this._cloneContents ? vect.clone() : vect);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vect get(int index) {
/*  44 */     Vect result = getPrivate(index);
/*  45 */     if (result != null && this._cloneContents) {
/*  46 */       result = result.clone();
/*     */     }
/*  48 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Vect getPrivate(int index) {
/*  53 */     return this._map.get(Integer.valueOf(index));
/*     */   }
/*     */   
/*     */   public int size() {
/*  57 */     return this._map.size();
/*     */   }
/*     */   
/*     */   public boolean containsKey(int index) {
/*  61 */     return this._map.containsKey(Integer.valueOf(index));
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getKeys() {
/*  66 */     Set<Integer> keys = this._map.keySet();
/*  67 */     int[] result = new int[keys.size()];
/*  68 */     int i = 0;
/*  69 */     for (Integer j : keys) {
/*  70 */       result[i++] = j.intValue();
/*     */     }
/*  72 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/*  77 */     VectMap otherMap = (VectMap)other;
/*  78 */     int[] keys = getKeys();
/*  79 */     double result = 0.0D;
/*  80 */     for (int i = 0; i < keys.length; i++) {
/*  81 */       int key = keys[i];
/*  82 */       Vect lhs = getPrivate(key);
/*  83 */       Vect rhs = otherMap.getPrivate(key);
/*  84 */       result += lhs.dot(rhs);
/*     */     } 
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public VectMap clone() {
/*  91 */     VectMap result = null;
/*     */     try {
/*  93 */       result = (VectMap)super.clone();
/*  94 */       result._map = new LinkedHashMap<Integer, Vect>();
/*  95 */       int[] keys = getKeys();
/*  96 */       for (int i = 0; i < keys.length; i++) {
/*  97 */         int key = keys[i];
/*  98 */         Vect vect = getPrivate(key);
/*  99 */         result.put(key, vect.clone());
/*     */       } 
/* 101 */     } catch (CloneNotSupportedException ex) {
/* 102 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/* 103 */       e.initCause(ex);
/* 104 */       throw e;
/*     */     } 
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 111 */     int[] keys = getKeys();
/* 112 */     for (int i = 0; i < keys.length; i++) {
/* 113 */       Vect vect = getPrivate(keys[i]);
/* 114 */       vect.dispose();
/*     */     } 
/* 116 */     this._map = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 121 */     int[] keys = getKeys();
/* 122 */     double scale = Almost.FLOAT.divide(1.0D, keys.length, 0.0D);
/* 123 */     for (int i = 0; i < keys.length; i++) {
/* 124 */       Vect vect = getPrivate(keys[i]);
/* 125 */       vect.multiplyInverseCovariance();
/* 126 */       VectUtil.scale(vect, scale);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {
/* 132 */     int[] keys = getKeys();
/* 133 */     for (int i = 0; i < keys.length; i++) {
/* 134 */       Vect vect = getPrivate(keys[i]);
/* 135 */       vect.constrain();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void postCondition() {
/* 141 */     int[] keys = getKeys();
/* 142 */     for (int i = 0; i < keys.length; i++) {
/* 143 */       Vect vect = getPrivate(keys[i]);
/* 144 */       vect.postCondition();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 150 */     addOrProject(scaleThis, scaleOther, other, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 155 */     addOrProject(scaleThis, scaleOther, other, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOrProject(double scaleThis, double scaleOther, VectConst other, boolean project) {
/* 162 */     VectMap otherMap = (VectMap)other;
/* 163 */     int[] keys = getKeys();
/* 164 */     for (int i = 0; i < keys.length; i++) {
/* 165 */       int key = keys[i];
/* 166 */       Vect vectTo = getPrivate(key);
/* 167 */       Vect vectFrom = otherMap.getPrivate(key);
/* 168 */       if (vectFrom == null) {
/* 169 */         throw new IllegalStateException("Cannot scale a vector missing key " + key);
/*     */       }
/*     */       
/* 172 */       if (project) {
/* 173 */         vectTo.project(scaleThis, scaleOther, vectFrom);
/*     */       } else {
/* 175 */         vectTo.add(scaleThis, scaleOther, vectFrom);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public double magnitude() {
/* 181 */     int[] keys = getKeys();
/* 182 */     double result = 0.0D;
/* 183 */     for (int i = 0; i < keys.length; i++) {
/* 184 */       int key = keys[i];
/* 185 */       Vect vect = getPrivate(key);
/* 186 */       result += vect.magnitude();
/*     */     } 
/* 188 */     result = Almost.FLOAT.divide(result, keys.length, 0.0D);
/* 189 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/VectMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */