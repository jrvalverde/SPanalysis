/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DRectangle
/*     */ {
/*     */   public double x;
/*     */   public double y;
/*     */   public double width;
/*     */   public double height;
/*     */   
/*     */   public DRectangle(double x, double y, double width, double height) {
/*  53 */     Check.argument((width >= 0.0D), "width is non-negative");
/*  54 */     Check.argument((height >= 0.0D), "height is non-negative");
/*  55 */     this.x = x;
/*  56 */     this.y = y;
/*  57 */     this.width = width;
/*  58 */     this.height = height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DRectangle(DRectangle r) {
/*  66 */     this(r.x, r.y, r.width, r.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DRectangle union(DRectangle rect) {
/*  75 */     double xn = Math.min(this.x, rect.x);
/*  76 */     double yn = Math.min(this.y, rect.y);
/*  77 */     double wn = Math.max(this.x + this.width, rect.x + rect.width) - xn;
/*  78 */     double hn = Math.max(this.y + this.height, rect.y + rect.height) - yn;
/*  79 */     return new DRectangle(xn, yn, wn, hn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DRectangle intersection(DRectangle rect) {
/*  88 */     double xn = Math.max(this.x, rect.x);
/*  89 */     double yn = Math.max(this.y, rect.y);
/*  90 */     double wn = Math.max(Math.min(this.x + this.width, rect.x + rect.width) - xn, 0.0D);
/*  91 */     double hn = Math.max(Math.min(this.y + this.height, rect.y + rect.height) - yn, 0.0D);
/*  92 */     return new DRectangle(xn, yn, wn, hn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 100 */     return (this.width <= 0.0D || this.height <= 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(DPoint point) {
/* 109 */     return contains(point.x, point.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y) {
/* 119 */     return (this.x <= x && this.y <= y && x - this.x <= this.width && y - this.y <= this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 126 */     if (this == obj)
/* 127 */       return true; 
/* 128 */     if (obj == null || getClass() != obj.getClass())
/* 129 */       return false; 
/* 130 */     DRectangle that = (DRectangle)obj;
/* 131 */     return (this.x == that.x && this.y == that.y && this.width == that.width && this.height == that.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 138 */     long xbits = Double.doubleToLongBits(this.x);
/* 139 */     long ybits = Double.doubleToLongBits(this.y);
/* 140 */     long wbits = Double.doubleToLongBits(this.width);
/* 141 */     long hbits = Double.doubleToLongBits(this.height);
/* 142 */     return (int)(xbits ^ xbits >>> 32L ^ ybits ^ ybits >>> 32L ^ wbits ^ wbits >>> 32L ^ hbits ^ hbits >>> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "(" + this.x + "," + this.y + "," + this.width + "," + this.height + ")";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/DRectangle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */