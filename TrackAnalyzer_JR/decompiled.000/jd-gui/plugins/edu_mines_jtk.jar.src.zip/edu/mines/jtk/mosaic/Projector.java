/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Projector
/*     */ {
/*     */   private double _u0;
/*     */   private double _u1;
/*     */   private double _v0;
/*     */   private double _v1;
/*     */   private double _ushift;
/*     */   private double _uscale;
/*     */   private double _vshift;
/*     */   private double _vscale;
/*     */   
/*     */   public Projector(double v0, double v1) {
/*  68 */     this(v0, v1, 0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector(double v0, double v1, double u0, double u1) {
/*  86 */     Check.argument((0.0D <= u0), "0.0 <= u0");
/*  87 */     Check.argument((u0 < u1), "u0 < u1");
/*  88 */     Check.argument((u1 <= 1.0D), "u1 <= 1.0");
/*  89 */     Check.argument((v0 != v1), "v0 != v1");
/*  90 */     this._u0 = u0;
/*  91 */     this._u1 = u1;
/*  92 */     this._v0 = v0;
/*  93 */     this._v1 = v1;
/*  94 */     computeShiftsAndScales();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projector(Projector p) {
/* 102 */     this(p._v0, p._v1, p._u0, p._u1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double u(double v) {
/* 111 */     return this._vshift + this._vscale * v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double v(double u) {
/* 120 */     return this._ushift + this._uscale * u;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double u0() {
/* 128 */     return this._u0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double u1() {
/* 136 */     return this._u1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double v0() {
/* 144 */     return this._v0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double v1() {
/* 152 */     return this._v1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(Projector p) {
/* 162 */     if (p == null) {
/*     */       return;
/*     */     }
/*     */     
/* 166 */     double u0a = this._u0;
/* 167 */     double u1a = this._u1;
/* 168 */     double v0a = this._v0;
/* 169 */     double v1a = this._v1;
/*     */ 
/*     */     
/* 172 */     double u0b = p._u0;
/* 173 */     double u1b = p._u1;
/* 174 */     double v0b = p._v0;
/* 175 */     double v1b = p._v1;
/*     */ 
/*     */     
/* 178 */     double vmin = MathPlus.min(MathPlus.min(v0a, v1a), MathPlus.min(v0b, v1b));
/* 179 */     double vmax = MathPlus.max(MathPlus.max(v0a, v1a), MathPlus.max(v0b, v1b));
/* 180 */     this._v0 = (v0a < v1a) ? vmin : vmax;
/* 181 */     this._v1 = (v0a < v1a) ? vmax : vmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     double r0a = (v0a - this._v0) / (this._v1 - this._v0);
/* 192 */     double r0b = (v0b - this._v0) / (this._v1 - this._v0);
/* 193 */     double r1a = (v1a - this._v0) / (this._v1 - this._v0);
/* 194 */     double r1b = (v1b - this._v0) / (this._v1 - this._v0);
/* 195 */     if (r1b < 0.0D) {
/* 196 */       r0b = -r0b;
/* 197 */       r1b = -r1b;
/* 198 */       double u0t = u0b;
/* 199 */       u0b = 1.0D - u1b;
/* 200 */       u1b = 1.0D - u0t;
/* 201 */       double v0t = v0b;
/* 202 */       v0b = v1b;
/* 203 */       v1b = v0t;
/*     */     } 
/* 205 */     double u0 = 0.0D;
/* 206 */     double u1 = 1.0D;
/* 207 */     int niter = 0;
/*     */     do {
/* 209 */       this._u0 = u0;
/* 210 */       this._u1 = u1;
/* 211 */       u0 = MathPlus.max((u0a - r0a * this._u1) / (1.0D - r0a), (u0b - r0b * this._u1) / (1.0D - r0b));
/* 212 */       u1 = MathPlus.min((u1a - (1.0D - r1a) * this._u0) / r1a, (u1b - (1.0D - r1b) * this._u0) / r1b);
/* 213 */       niter++;
/* 214 */     } while ((this._u0 < u0 || u1 < this._u1) && niter < 10);
/* 215 */     assert niter < 10 : "niter<10";
/* 216 */     assert 0.0D <= this._u0 && this._u0 < this._u1 && this._u1 <= 1.0D : "_u0 and _u1 valid";
/*     */ 
/*     */     
/* 219 */     computeShiftsAndScales();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getScaleRatio(Projector p) {
/* 237 */     return this._vscale / p._vscale;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 241 */     if (this == obj)
/* 242 */       return true; 
/* 243 */     if (obj == null || getClass() != obj.getClass())
/* 244 */       return false; 
/* 245 */     Projector that = (Projector)obj;
/* 246 */     return (this._u0 == that._u0 && this._u1 == that._u1 && this._v0 == that._v0 && this._v1 == that._v1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 253 */     long u0bits = Double.doubleToLongBits(this._u0);
/* 254 */     long u1bits = Double.doubleToLongBits(this._u1);
/* 255 */     long v0bits = Double.doubleToLongBits(this._v0);
/* 256 */     long v1bits = Double.doubleToLongBits(this._v1);
/* 257 */     return (int)(u0bits ^ u0bits >>> 32L ^ u1bits ^ u1bits >>> 32L ^ v0bits ^ v0bits >>> 32L ^ v1bits ^ v1bits >>> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeShiftsAndScales() {
/* 272 */     this._uscale = (this._v1 - this._v0) / (this._u1 - this._u0);
/* 273 */     this._ushift = this._v0 - this._uscale * this._u0;
/* 274 */     this._vscale = (this._u1 - this._u0) / (this._v1 - this._v0);
/* 275 */     this._vshift = this._u0 - this._vscale * this._v0;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/Projector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */