/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterSetFormatException
/*    */   extends RuntimeException
/*    */ {
/*    */   ParameterSetFormatException() {}
/*    */   
/*    */   ParameterSetFormatException(String s) {
/* 20 */     super(s);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/ParameterSetFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */