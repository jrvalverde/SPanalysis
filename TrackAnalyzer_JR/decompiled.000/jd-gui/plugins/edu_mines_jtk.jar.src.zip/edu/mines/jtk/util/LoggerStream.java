/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerStream
/*     */   extends PrintStream
/*     */ {
/*  27 */   private Level _level = null;
/*  28 */   private Logger _logger = null;
/*  29 */   private ByteArrayOutputStream _baos = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerStream(Logger logger, Level level) {
/*  38 */     super(new ByteArrayOutputStream(), true);
/*  39 */     this._baos = (ByteArrayOutputStream)this.out;
/*  40 */     this._logger = logger;
/*  41 */     this._level = level;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void flush() {
/*  46 */     super.flush();
/*  47 */     if (this._baos.size() == 0)
/*  48 */       return;  String out1 = this._baos.toString();
/*     */     
/*  50 */     this._logger.log(this._level, out1);
/*     */     
/*  52 */     this._baos.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void println() {
/*  57 */     flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void println(Object x) {
/*  62 */     print(x);
/*  63 */     flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void println(String x) {
/*  68 */     print(x);
/*  69 */     flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/*  74 */     flush();
/*  75 */     super.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean checkError() {
/*  80 */     flush();
/*  81 */     return super.checkError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  88 */     Logger logger = Logger.getLogger("edu.mines.jtk.util");
/*  89 */     PrintStream psInfo = new LoggerStream(logger, Level.INFO);
/*  90 */     PrintStream psWarning = new LoggerStream(logger, Level.WARNING);
/*  91 */     psInfo.print(3.0D);
/*  92 */     psInfo.println("*3.=9.");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     psInfo.print(3.0D);
/*  98 */     psInfo.flush();
/*  99 */     psInfo.println("*3.=9.");
/* 100 */     psInfo.println();
/* 101 */     psInfo.print("x");
/* 102 */     psInfo.close();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/LoggerStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */