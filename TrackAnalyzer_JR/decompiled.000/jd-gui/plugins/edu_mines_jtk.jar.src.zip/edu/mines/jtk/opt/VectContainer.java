package edu.mines.jtk.opt;

public interface VectContainer extends Vect {
  void put(int paramInt, Vect paramVect);
  
  Vect get(int paramInt);
  
  int size();
  
  boolean containsKey(int paramInt);
  
  int[] getKeys();
  
  VectContainer clone();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/VectContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */