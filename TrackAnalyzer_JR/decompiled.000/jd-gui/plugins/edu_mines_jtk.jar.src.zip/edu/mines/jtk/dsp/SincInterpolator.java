/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.opt.BrentMinFinder;
/*      */ import edu.mines.jtk.util.Check;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SincInterpolator
/*      */ {
/*      */   private BrentMinFinder _maxFinder;
/*      */   private static final double EWIN_FRAC = 0.9D;
/*      */   private static final int NTAB_MAX = 16385;
/*      */   private double _emax;
/*      */   private double _fmax;
/*      */   private int _lmax;
/*      */   private KaiserWindow _kwin;
/*      */   private Extrapolation _extrap;
/*      */   private int _nxu;
/*      */   private double _dxu;
/*      */   private double _fxu;
/*      */   private double _xf;
/*      */   private double _xs;
/*      */   private double _xb;
/*      */   private int _nxum;
/*      */   private float[] _yu;
/*      */   private int _nx1u;
/*      */   private int _nx2u;
/*      */   private int _nx3u;
/*      */   private double _x1f;
/*      */   private double _x2f;
/*      */   private double _x3f;
/*      */   private double _x1s;
/*      */   private double _x2s;
/*      */   private double _x3s;
/*      */   private double _x1b;
/*      */   private double _x2b;
/*      */   private double _x3b;
/*      */   private int _nx1um;
/*      */   private int _nx2um;
/*      */   private int _nx3um;
/*      */   private float[][] _yyu;
/*      */   private float[][][] _yyyu;
/*      */   private int _lsinc;
/*      */   private int _nsinc;
/*      */   private double _dsinc;
/*      */   private float[][] _asinc;
/*      */   private double _nsincm1;
/*      */   private int _ib;
/*      */   
/*      */   public enum Extrapolation
/*      */   {
/*   76 */     ZERO,
/*   77 */     CONSTANT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SincInterpolator fromErrorAndLength(double emax, int lmax) {
/*   94 */     return new SincInterpolator(emax, 0.0D, lmax);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SincInterpolator fromErrorAndFrequency(double emax, double fmax) {
/*  109 */     return new SincInterpolator(emax, fmax, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SincInterpolator fromFrequencyAndLength(double fmax, int lmax) {
/*  129 */     return new SincInterpolator(0.0D, fmax, lmax);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SincInterpolator fromKenLarner(int lmax) {
/*  144 */     return new SincInterpolator(lmax);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SincInterpolator() {
/*      */     this(0.0D, 0.3D, 8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMaximumError() {
/*      */     return this._emax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMaximumFrequency() {
/*      */     return this._fmax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaximumLength() {
/*      */     return this._lmax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTableBytes() {
/*      */     long nbytes = 4L;
/*      */     nbytes *= this._lsinc;
/*      */     nbytes *= this._nsinc;
/*      */     return nbytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Extrapolation getExtrapolation() {
/*      */     return this._extrap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtrapolation(Extrapolation extrap) {
/*      */     this._extrap = extrap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUniformSampling(int nxu, double dxu, double fxu) {
/*      */     if (this._asinc == null) {
/*      */       makeTable();
/*      */     }
/*      */     this._nxu = nxu;
/*      */     this._dxu = dxu;
/*      */     this._fxu = fxu;
/*      */     this._xf = fxu;
/*      */     this._xs = 1.0D / dxu;
/*      */     this._xb = this._lsinc - this._xf * this._xs;
/*      */     this._nxum = nxu - this._lsinc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUniformSamples(float[] yu) {
/*      */     this._yu = yu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUniform(int nxu, double dxu, double fxu, float[] yu) {
/*      */     setUniformSampling(nxu, dxu, fxu);
/*      */     setUniformSamples(yu);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SincInterpolator(int lmax)
/*      */   {
/*  393 */     this._maxFinder = new BrentMinFinder(new BrentMinFinder.Function()
/*      */         {
/*      */           public double evaluate(double x) {
/*  396 */             return -SincInterpolator.this.interpolate(x);
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  778 */     this._extrap = Extrapolation.ZERO; Check.argument((lmax % 2 == 0), "lmax is even"); Check.argument((lmax >= 8), "lmax>=8"); Check.argument((lmax <= 16), "lmax<=16"); this._emax = 0.01D; this._fmax = 0.033D + 0.132D * Math.log(lmax); this._lmax = lmax; this._nsinc = 2049; this._dsinc = 1.0D / (this._nsinc - 1); this._lsinc = lmax; makeTableKenLarner(); } public float interpolate(double x) { double xn = this._xb + x * this._xs; int ixn = (int)xn; int kyu = this._ib + ixn; double frac = xn - ixn; if (frac < 0.0D) frac++;  int ksinc = (int)(frac * this._nsincm1 + 0.5D); float[] asinc = this._asinc[ksinc]; float yr = 0.0F; if (kyu >= 0 && kyu <= this._nxum) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) yr += this._yu[kyu] * asinc[isinc];  } else if (this._extrap == Extrapolation.ZERO) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) { if (0 <= kyu && kyu < this._nxu) yr += this._yu[kyu] * asinc[isinc];  }  } else if (this._extrap == Extrapolation.CONSTANT) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) { int jyu = (kyu < 0) ? 0 : ((this._nxu <= kyu) ? (this._nxu - 1) : kyu); yr += this._yu[jyu] * asinc[isinc]; }  }  return yr; } public void interpolate(int nx, float[] x, float[] y) { for (int ix = 0; ix < nx; ix++) y[ix] = interpolate(x[ix]);  } public void interpolate(int nx, double dx, double fx, float[] y) { if (dx == this._dxu) { shift(nx, fx, y); } else { for (int ix = 0; ix < nx; ix++) y[ix] = interpolate(fx + ix * dx);  }  } private SincInterpolator(double emax, double fmax, int lmax) { this._maxFinder = new BrentMinFinder(new BrentMinFinder.Function() { public double evaluate(double x) { return -SincInterpolator.this.interpolate(x); } }); this._extrap = Extrapolation.ZERO;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  818 */     Check.argument(((emax == 0.0D && fmax != 0.0D && lmax != 0) || (emax != 0.0D && fmax == 0.0D && lmax != 0) || (emax != 0.0D && fmax != 0.0D && lmax == 0)), "exactly one of emax, fmax, and lmax is zero");
/*      */ 
/*      */ 
/*      */     
/*  822 */     if (emax == 0.0D) {
/*  823 */       Check.argument((fmax < 0.5D), "fmax<0.5");
/*  824 */       Check.argument((lmax >= 8), "lmax>=8");
/*  825 */       Check.argument((lmax % 2 == 0), "lmax is even");
/*  826 */       Check.argument(((1.0D - 2.0D * fmax) * lmax > 1.0D), "(1.0-2.0*fmax)*lmax>1.0");
/*  827 */     } else if (fmax == 0.0D) {
/*  828 */       Check.argument((emax <= 0.1D), "emax<=0.1");
/*  829 */       Check.argument((lmax >= 8), "lmax>=8");
/*  830 */       Check.argument((lmax % 2 == 0), "lmax is even");
/*  831 */     } else if (lmax == 0) {
/*  832 */       Check.argument((emax <= 0.1D), "emax<=0.1");
/*  833 */       Check.argument((fmax < 0.5D), "fmax<0.5");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  838 */     double wwin = 2.0D * (0.5D - fmax);
/*      */ 
/*      */ 
/*      */     
/*  842 */     double ewin = emax * 0.9D;
/*  843 */     KaiserWindow kwin = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  854 */     if (emax == 0.0D) {
/*  855 */       kwin = KaiserWindow.fromWidthAndLength(wwin, lmax);
/*  856 */       ewin = 3.0D * kwin.getError();
/*  857 */       emax = ewin / 0.9D;
/*  858 */       double etabMin = 3.455751918948773D * fmax / 16384.0D;
/*  859 */       double emaxMin = etabMin / 0.09999999999999998D;
/*  860 */       if (emax < emaxMin) {
/*  861 */         emax = emaxMin;
/*  862 */         ewin = emax * 0.9D;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  873 */     else if (fmax == 0.0D) {
/*  874 */       kwin = KaiserWindow.fromErrorAndLength(ewin / 3.0D, lmax);
/*  875 */       fmax = Math.max(0.0D, 0.5D - 0.5D * kwin.getWidth());
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  884 */       kwin = KaiserWindow.fromErrorAndWidth(ewin / 3.0D, wwin);
/*  885 */       double lwin = kwin.getLength();
/*  886 */       lmax = (int)lwin;
/*  887 */       while (lmax < lwin || lmax < 8 || lmax % 2 == 1)
/*  888 */         lmax++; 
/*  889 */       kwin = KaiserWindow.fromErrorAndLength(ewin / 3.0D, lmax);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  898 */     double etab = emax - ewin;
/*  899 */     this._dsinc = (fmax > 0.0D) ? (etab / Math.PI * fmax) : 1.0D;
/*  900 */     int nsincMin = 1 + (int)Math.ceil(1.0D / this._dsinc);
/*  901 */     this._nsinc = 2;
/*  902 */     while (this._nsinc < nsincMin)
/*  903 */       this._nsinc *= 2; 
/*  904 */     this._nsinc++;
/*  905 */     this._dsinc = 1.0D / (this._nsinc - 1);
/*  906 */     this._lsinc = lmax;
/*      */ 
/*      */     
/*  909 */     this._emax = emax;
/*  910 */     this._fmax = fmax;
/*  911 */     this._lmax = lmax;
/*  912 */     this._kwin = kwin; }
/*      */   public void interpolateComplex(int nx, float[] x, float[] y) { for (int ix = 0; ix < nx; ix++) interpolateComplex(ix, x[ix], y);  }
/*      */   public void interpolateComplex(int nx, double dx, double fx, float[] y) { for (int ix = 0; ix < nx; ix++) interpolateComplex(ix, fx + ix * dx, y);  }
/*      */   public double findMax(double x) { double a = x - 0.5D * this._dxu; double b = x + 0.5D * this._dxu; double tol = this._dsinc * this._dxu; return this._maxFinder.findMin(a, b, tol); }
/*      */   public void setUniformSampling(int nx1u, double dx1u, double fx1u, int nx2u, double dx2u, double fx2u) { if (this._asinc == null) makeTable();  this._nx1u = nx1u; this._x1f = fx1u; this._x1s = 1.0D / dx1u; this._x1b = this._lsinc - this._x1f * this._x1s; this._nx1um = nx1u - this._lsinc; this._nx2u = nx2u; this._x2f = fx2u; this._x2s = 1.0D / dx2u; this._x2b = this._lsinc - this._x2f * this._x2s; this._nx2um = nx2u - this._lsinc; }
/*      */   public void setUniformSamples(float[][] yu) { this._yyu = yu; }
/*      */   public void setUniform(int nx1u, double dx1u, double fx1u, int nx2u, double dx2u, double fx2u, float[][] yu) { setUniformSampling(nx1u, dx1u, fx1u, nx2u, dx2u, fx2u); setUniformSamples(yu); }
/*      */   public float interpolate(double x1, double x2) { double x1n = this._x1b + x1 * this._x1s; double x2n = this._x2b + x2 * this._x2s; int ix1n = (int)x1n; int ix2n = (int)x2n; int ky1u = this._ib + ix1n; int ky2u = this._ib + ix2n; double frac1 = x1n - ix1n; double frac2 = x2n - ix2n; if (frac1 < 0.0D) frac1++;  if (frac2 < 0.0D) frac2++;  int ksinc1 = (int)(frac1 * this._nsincm1 + 0.5D); int ksinc2 = (int)(frac2 * this._nsincm1 + 0.5D); float[] asinc1 = this._asinc[ksinc1]; float[] asinc2 = this._asinc[ksinc2]; float yr = 0.0F; if (ky1u >= 0 && ky1u <= this._nx1um && ky2u >= 0 && ky2u <= this._nx2um) { for (int i2sinc = 0; i2sinc < this._lsinc; i2sinc++, ky2u++) { float asinc22 = asinc2[i2sinc]; float[] yyuk2 = this._yyu[ky2u]; float yr2 = 0.0F; for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++) yr2 += yyuk2[my1u] * asinc1[i1sinc];  yr += asinc22 * yr2; }  } else if (this._extrap == Extrapolation.ZERO) { for (int i2sinc = 0; i2sinc < this._lsinc; i2sinc++, ky2u++) { if (0 <= ky2u && ky2u < this._nx2u) for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++) { if (0 <= my1u && my1u < this._nx1u)
/*      */               yr += this._yyu[ky2u][my1u] * asinc2[i2sinc] * asinc1[i1sinc];  }   }  } else if (this._extrap == Extrapolation.CONSTANT) { for (int i2sinc = 0; i2sinc < this._lsinc; i2sinc++, ky2u++) { int jy2u = (ky2u < 0) ? 0 : ((this._nx2u <= ky2u) ? (this._nx2u - 2) : ky2u); for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++) { int jy1u = (my1u < 0) ? 0 : ((this._nx1u <= my1u) ? (this._nx1u - 1) : my1u); yr += this._yyu[jy2u][jy1u] * asinc2[i2sinc] * asinc1[i1sinc]; }  }  }  return yr; }
/*      */   public void setUniformSampling(int nx1u, double dx1u, double fx1u, int nx2u, double dx2u, double fx2u, int nx3u, double dx3u, double fx3u) { if (this._asinc == null)
/*  922 */       makeTable();  this._nx1u = nx1u; this._x1f = fx1u; this._x1s = 1.0D / dx1u; this._x1b = this._lsinc - this._x1f * this._x1s; this._nx1um = nx1u - this._lsinc; this._nx2u = nx2u; this._x2f = fx2u; this._x2s = 1.0D / dx2u; this._x2b = this._lsinc - this._x2f * this._x2s; this._nx2um = nx2u - this._lsinc; this._nx3u = nx3u; this._x3f = fx3u; this._x3s = 1.0D / dx3u; this._x3b = this._lsinc - this._x3f * this._x3s; this._nx3um = nx3u - this._lsinc; } private void makeTable() { this._asinc = new float[this._nsinc][this._lsinc];
/*  923 */     this._nsincm1 = (this._nsinc - 1);
/*  924 */     this._ib = -this._lsinc - this._lsinc / 2 + 1;
/*      */ 
/*      */ 
/*      */     
/*  928 */     for (int j = 0; j < this._lsinc; j++) {
/*  929 */       this._asinc[0][j] = 0.0F;
/*  930 */       this._asinc[this._nsinc - 1][j] = 0.0F;
/*      */     } 
/*  932 */     this._asinc[0][this._lsinc / 2 - 1] = 1.0F;
/*  933 */     this._asinc[this._nsinc - 1][this._lsinc / 2] = 1.0F;
/*      */ 
/*      */     
/*  936 */     for (int isinc = 1; isinc < this._nsinc - 1; isinc++) {
/*  937 */       double x = (-this._lsinc / 2 + 1) - this._dsinc * isinc;
/*  938 */       for (int i = 0; i < this._lsinc; i++, x++)
/*  939 */         this._asinc[isinc][i] = (float)(sinc(x) * this._kwin.evaluate(x)); 
/*      */     }  }
/*      */    public void setUniformSamples(float[][][] yu) {
/*      */     this._yyyu = yu;
/*      */   }
/*      */   private static double sinc(double x) {
/*  945 */     return (x != 0.0D) ? (Math.sin(Math.PI * x) / Math.PI * x) : 1.0D; } public void setUniform(int nx1u, double dx1u, double fx1u, int nx2u, double dx2u, double fx2u, int nx3u, double dx3u, double fx3u, float[][][] yu) { setUniformSampling(nx1u, dx1u, fx1u, nx2u, dx2u, fx2u, nx3u, dx3u, fx3u); setUniformSamples(yu); }
/*      */   public float interpolate(double x1, double x2, double x3) { double x1n = this._x1b + x1 * this._x1s; double x2n = this._x2b + x2 * this._x2s; double x3n = this._x3b + x3 * this._x3s; int ix1n = (int)x1n; int ix2n = (int)x2n; int ix3n = (int)x3n; int ky1u = this._ib + ix1n; int ky2u = this._ib + ix2n; int ky3u = this._ib + ix3n; double frac1 = x1n - ix1n; double frac2 = x2n - ix2n; double frac3 = x3n - ix3n; if (frac1 < 0.0D) frac1++;  if (frac2 < 0.0D) frac2++;  if (frac3 < 0.0D) frac3++;  int ksinc1 = (int)(frac1 * this._nsincm1 + 0.5D); int ksinc2 = (int)(frac2 * this._nsincm1 + 0.5D); int ksinc3 = (int)(frac3 * this._nsincm1 + 0.5D); float[] asinc1 = this._asinc[ksinc1]; float[] asinc2 = this._asinc[ksinc2]; float[] asinc3 = this._asinc[ksinc3]; float yr = 0.0F; if (ky1u >= 0 && ky1u <= this._nx1um && ky2u >= 0 && ky2u <= this._nx2um && ky3u >= 0 && ky3u <= this._nx3um) { for (int i3sinc = 0; i3sinc < this._lsinc; i3sinc++, ky3u++) { float asinc33 = asinc3[i3sinc]; float[][] yyy3 = this._yyyu[ky3u]; float yr2 = 0.0F; for (int i2sinc = 0, my2u = ky2u; i2sinc < this._lsinc; i2sinc++, my2u++) { float asinc22 = asinc2[i2sinc]; float[] yyy32 = yyy3[my2u]; float yr1 = 0.0F; for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++)
/*      */             yr1 += yyy32[my1u] * asinc1[i1sinc];  yr2 += asinc22 * yr1; }  yr += asinc33 * yr2; }  } else if (this._extrap == Extrapolation.ZERO) { for (int i3sinc = 0; i3sinc < this._lsinc; i3sinc++, ky3u++) { if (0 <= ky3u && ky3u < this._nx3u)
/*      */           for (int i2sinc = 0, my2u = ky2u; i2sinc < this._lsinc; i2sinc++, my2u++) { if (0 <= my2u && my2u < this._nx2u)
/*      */               for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++) { if (0 <= my1u && my1u < this._nx1u)
/*      */                   yr += this._yyyu[ky3u][my2u][my1u] * asinc3[i3sinc] * asinc2[i2sinc] * asinc1[i1sinc];  }   }   }  } else if (this._extrap == Extrapolation.CONSTANT) { for (int i3sinc = 0; i3sinc < this._lsinc; i3sinc++, ky3u++) { int jy3u = (ky3u < 0) ? 0 : ((this._nx3u <= ky3u) ? (this._nx3u - 2) : ky3u); for (int i2sinc = 0, my2u = ky2u; i2sinc < this._lsinc; i2sinc++, my2u++) { int jy2u = (my2u < 0) ? 0 : ((this._nx2u <= my2u) ? (this._nx2u - 2) : my2u); for (int i1sinc = 0, my1u = ky1u; i1sinc < this._lsinc; i1sinc++, my1u++) { int jy1u = (my1u < 0) ? 0 : ((this._nx1u <= my1u) ? (this._nx1u - 1) : my1u); yr += this._yyyu[jy3u][jy2u][jy1u] * asinc3[i3sinc] * asinc2[i2sinc] * asinc1[i1sinc]; }  }  }  }  return yr; }
/*  951 */   private void interpolateComplex(int ix, double x, float[] y) { double xn = this._xb + x * this._xs;
/*  952 */     int ixn = (int)xn;
/*  953 */     int kyu = this._ib + ixn;
/*      */ 
/*      */     
/*  956 */     double frac = xn - ixn;
/*  957 */     if (frac < 0.0D)
/*  958 */       frac++; 
/*  959 */     int ksinc = (int)(frac * this._nsincm1 + 0.5D);
/*  960 */     float[] asinc = this._asinc[ksinc];
/*      */ 
/*      */ 
/*      */     
/*  964 */     float yr = 0.0F;
/*  965 */     float yi = 0.0F;
/*  966 */     if (kyu >= 0 && kyu <= this._nxum) {
/*  967 */       for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) {
/*  968 */         int jyu = 2 * kyu;
/*  969 */         float asinci = asinc[isinc];
/*  970 */         yr += this._yu[jyu] * asinci;
/*  971 */         yi += this._yu[jyu + 1] * asinci;
/*      */       } 
/*  973 */     } else if (this._extrap == Extrapolation.ZERO) {
/*  974 */       for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) {
/*  975 */         if (0 <= kyu && kyu < this._nxu) {
/*  976 */           int jyu = 2 * kyu;
/*  977 */           float asinci = asinc[isinc];
/*  978 */           yr += this._yu[jyu] * asinci;
/*  979 */           yi += this._yu[jyu + 1] * asinci;
/*      */         } 
/*      */       } 
/*  982 */     } else if (this._extrap == Extrapolation.CONSTANT) {
/*  983 */       for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) {
/*  984 */         int jyu = (kyu < 0) ? 0 : ((this._nxu <= kyu) ? (2 * this._nxu - 2) : (2 * kyu));
/*  985 */         float asinci = asinc[isinc];
/*  986 */         yr += this._yu[jyu] * asinci;
/*  987 */         yi += this._yu[jyu + 1] * asinci;
/*      */       } 
/*      */     } 
/*  990 */     int jx = 2 * ix;
/*  991 */     y[jx] = yr;
/*  992 */     y[jx + 1] = yi; } public void accumulate(double x, float y) { double xn = this._xb + x * this._xs; int ixn = (int)xn; int kyu = this._ib + ixn; double frac = xn - ixn; if (frac < 0.0D)
/*      */       frac++;  int ksinc = (int)(frac * this._nsincm1 + 0.5D); float[] asinc = this._asinc[ksinc]; if (kyu >= 0 && kyu <= this._nxum) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++)
/*      */         this._yu[kyu] = this._yu[kyu] + y * asinc[isinc];  } else if (this._extrap == Extrapolation.ZERO) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) { if (0 <= kyu && kyu < this._nxu)
/*      */           this._yu[kyu] = this._yu[kyu] + y * asinc[isinc];  }  } else if (this._extrap == Extrapolation.CONSTANT) { for (int isinc = 0; isinc < this._lsinc; isinc++, kyu++) { int jyu = (kyu < 0) ? 0 : ((this._nxu <= kyu) ? (this._nxu - 1) : kyu); this._yu[jyu] = this._yu[jyu] + y * asinc[isinc]; }  }  }
/*      */   public void accumulate(int nx, float[] x, float[] y) { for (int ix = 0; ix < nx; ix++)
/*      */       accumulate(x[ix], y[ix]);  }
/*  998 */   private void shift(int nx, double fx, float[] y) { int nxu = this._nxu;
/*  999 */     double dxu = this._dxu;
/* 1000 */     double fxu = this._fxu;
/* 1001 */     double lxu = fxu + (nxu - 1) * dxu;
/*      */ 
/*      */     
/* 1004 */     double dx = dxu;
/* 1005 */     double x1 = fxu + dxu * this._lsinc / 2.0D;
/* 1006 */     double x2 = lxu - dxu * this._lsinc / 2.0D;
/* 1007 */     double x1n = (x1 - fx) / dx;
/* 1008 */     double x2n = (x2 - fx) / dx;
/* 1009 */     int ix1 = Math.max(0, Math.min(nx, (int)x1n) + 1);
/* 1010 */     int ix2 = Math.max(0, Math.min(nx, (int)x2n) - 1);
/*      */     
/*      */     int ix;
/* 1013 */     for (ix = 0; ix < ix1; ix++) {
/* 1014 */       double x = fx + ix * dx;
/* 1015 */       y[ix] = interpolate(x);
/*      */     } 
/*      */ 
/*      */     
/* 1019 */     for (ix = ix2; ix < nx; ix++) {
/* 1020 */       double x = fx + ix * dx;
/* 1021 */       y[ix] = interpolate(x);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1027 */     double xn = this._xb + (fx + ix1 * dx) * this._xs;
/* 1028 */     int ixn = (int)xn;
/* 1029 */     int kyu = this._ib + ixn;
/*      */ 
/*      */     
/* 1032 */     double frac = xn - ixn;
/* 1033 */     if (frac < 0.0D)
/* 1034 */       frac++; 
/* 1035 */     int ksinc = (int)(frac * this._nsincm1 + 0.5D);
/* 1036 */     float[] asinc = this._asinc[ksinc];
/*      */ 
/*      */     
/* 1039 */     for (int i = ix1; i < ix2; i++, kyu++) {
/* 1040 */       float yr = 0.0F;
/* 1041 */       for (int isinc = 0, jyu = kyu; isinc < this._lsinc; isinc++, jyu++)
/* 1042 */         yr += this._yu[jyu] * asinc[isinc]; 
/* 1043 */       y[i] = yr;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void makeTableKenLarner() {
/* 1053 */     this._asinc = new float[this._nsinc][this._lsinc];
/* 1054 */     this._nsincm1 = (this._nsinc - 1);
/* 1055 */     this._ib = -this._lsinc - this._lsinc / 2 + 1;
/*      */ 
/*      */ 
/*      */     
/* 1059 */     for (int j = 0; j < this._lsinc; j++) {
/* 1060 */       this._asinc[0][j] = 0.0F;
/* 1061 */       this._asinc[this._nsinc - 1][j] = 0.0F;
/*      */     } 
/* 1063 */     this._asinc[0][this._lsinc / 2 - 1] = 1.0F;
/* 1064 */     this._asinc[this._nsinc - 1][this._lsinc / 2] = 1.0F;
/*      */ 
/*      */     
/* 1067 */     for (int isinc = 1; isinc < this._nsinc - 1; isinc++) {
/* 1068 */       double frac = isinc / (this._nsinc - 1);
/* 1069 */       mksinc(frac, this._lsinc, this._asinc[isinc]);
/*      */     } 
/*      */   }
/*      */   private static void mksinc(double d, int lsinc, float[] sinc) {
/* 1073 */     double[] s = new double[lsinc];
/* 1074 */     double[] a = new double[lsinc];
/* 1075 */     double[] c = new double[lsinc];
/* 1076 */     double[] w = new double[lsinc];
/* 1077 */     double fmax = 0.033D + 0.132D * Math.log(lsinc);
/* 1078 */     if (fmax > 0.5D)
/* 1079 */       fmax = 0.5D;  int j;
/* 1080 */     for (j = 0; j < lsinc; j++) {
/* 1081 */       a[j] = sinc(2.0D * fmax * j);
/* 1082 */       c[j] = sinc(2.0D * fmax * ((lsinc / 2 - j - 1) + d));
/*      */     } 
/* 1084 */     stoepd(lsinc, a, c, s, w);
/* 1085 */     for (j = 0; j < lsinc; j++) {
/* 1086 */       sinc[j] = (float)s[j];
/*      */     }
/*      */   }
/*      */   
/*      */   private static void stoepd(int n, double[] r, double[] g, double[] f, double[] a) {
/* 1091 */     if (r[0] == 0.0D)
/*      */       return; 
/* 1093 */     a[0] = 1.0D;
/* 1094 */     double v = r[0];
/* 1095 */     f[0] = g[0] / r[0];
/* 1096 */     for (int j = 1; j < n; j++) {
/* 1097 */       a[j] = 0.0D;
/* 1098 */       f[j] = 0.0D;
/* 1099 */       double e = 0.0D;
/* 1100 */       for (int i = 0; i < j; i++)
/* 1101 */         e += a[i] * r[j - i]; 
/* 1102 */       double c = e / v;
/* 1103 */       v -= c * e;
/* 1104 */       for (int k = 0; k <= j / 2; k++) {
/* 1105 */         double bot = a[j - k] - c * a[k];
/* 1106 */         a[k] = a[k] - c * a[j - k];
/* 1107 */         a[j - k] = bot;
/*      */       } 
/* 1109 */       double w = 0.0D; int m;
/* 1110 */       for (m = 0; m < j; m++)
/* 1111 */         w += f[m] * r[j - m]; 
/* 1112 */       c = (w - g[j]) / v;
/* 1113 */       for (m = 0; m <= j; m++)
/* 1114 */         f[m] = f[m] - c * a[j - m]; 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/SincInterpolator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */