/*      */ package edu.mines.jtk.mesh;
/*      */ 
/*      */ import edu.mines.jtk.util.Check;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TriSurf
/*      */ {
/*      */   private static final int FACE_MARK_MAX = 2147483646;
/*      */   
/*      */   public static class Node
/*      */   {
/*      */     public int index;
/*      */     public Object data;
/*      */     private TetMesh.Node _meshNode;
/*      */     private TriSurf.Face _face;
/*      */     private TriSurf.Edge _edgeBefore;
/*      */     private TriSurf.Edge _edgeAfter;
/*      */     
/*      */     public Node(float x, float y, float z) {
/*   50 */       this._meshNode = new TetMesh.Node(x, y, z);
/*   51 */       this._meshNode.data = this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float x() {
/*   59 */       return this._meshNode.x();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float y() {
/*   67 */       return this._meshNode.y();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final float z() {
/*   75 */       return this._meshNode.z();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isInSurface() {
/*   83 */       return (this._face != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isOnBoundary() {
/*   91 */       return (this._edgeBefore != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriSurf.Edge edgeBefore() {
/*  101 */       return this._edgeBefore;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriSurf.Edge edgeAfter() {
/*  111 */       return this._edgeAfter;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float[] normalVector() {
/*  119 */       float[] vn = new float[3];
/*  120 */       normalVector(vn);
/*  121 */       return vn;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void normalVector(float[] vn) {
/*  129 */       vn[2] = 0.0F; vn[1] = 0.0F; vn[0] = 0.0F;
/*  130 */       TriSurf.FaceIterator fi = getFaces();
/*  131 */       while (fi.hasNext()) {
/*  132 */         TriSurf.Face face = fi.next();
/*  133 */         accNormalVector(face, vn);
/*      */       } 
/*  135 */       float x = vn[0];
/*  136 */       float y = vn[1];
/*  137 */       float z = vn[2];
/*  138 */       float s = 1.0F / (float)Math.sqrt((x * x + y * y + z * z));
/*  139 */       vn[0] = vn[0] * s;
/*  140 */       vn[1] = vn[1] * s;
/*  141 */       vn[2] = vn[2] * s;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int countFaces() {
/*  149 */       int nface = 0;
/*  150 */       TriSurf.FaceIterator fi = getFaces();
/*  151 */       while (fi.hasNext()) {
/*  152 */         TriSurf.Face face = fi.next();
/*  153 */         nface++;
/*      */       } 
/*  155 */       return nface;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriSurf.FaceIterator getFaces() {
/*  163 */       return new TriSurf.FaceIterator() {
/*      */           public boolean hasNext() {
/*  165 */             return (this._next != null);
/*      */           }
/*      */           public TriSurf.Face next() {
/*  168 */             if (this._next == null)
/*  169 */               throw new NoSuchElementException(); 
/*  170 */             TriSurf.Face face = this._next;
/*  171 */             loadNext();
/*  172 */             return face;
/*      */           }
/*  174 */           private TriSurf.Face _next = TriSurf.Node.this._face; private boolean _ccw = true;
/*      */           
/*      */           private void loadNext() {
/*  177 */             if (this._ccw) {
/*  178 */               this._next = TriSurf.Node.this.faceNext(this._next);
/*  179 */               if (this._next == null) {
/*  180 */                 this._ccw = false;
/*  181 */                 this._next = TriSurf.Node.this._face;
/*  182 */               } else if (this._next == TriSurf.Node.this._face) {
/*  183 */                 this._next = null;
/*      */               } 
/*      */             } 
/*  186 */             if (!this._ccw) {
/*  187 */               this._next = TriSurf.Node.this.facePrev(this._next);
/*      */             }
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*      */     public String toString() {
/*  194 */       return this._meshNode.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void validate() {
/*  202 */       assert this._meshNode != null;
/*  203 */       assert this._face == null || this._face.references(this);
/*  204 */       if (this._edgeBefore == null) {
/*  205 */         assert this._edgeAfter == null;
/*      */       } else {
/*  207 */         assert this == this._edgeBefore.nodeB();
/*  208 */         assert this == this._edgeAfter.nodeA();
/*  209 */         assert this == this._edgeBefore.nodeA().edgeAfter().nodeB();
/*  210 */         assert this == this._edgeAfter.nodeB().edgeBefore().nodeA();
/*      */       } 
/*  212 */       assert this._edgeBefore != null && this == this._edgeBefore.nodeB() && this._edgeAfter != null && this == this._edgeAfter.nodeA();
/*      */     }
/*      */ 
/*      */     
/*      */     private void init() {
/*  217 */       this._face = null;
/*  218 */       this._edgeBefore = null;
/*  219 */       this._edgeAfter = null;
/*      */     }
/*      */     private void setFace(TriSurf.Face face) {
/*  222 */       this._face = face;
/*      */     }
/*      */     private void setEdgeBefore(TriSurf.Edge edgeBefore) {
/*  225 */       this._edgeBefore = edgeBefore;
/*      */     }
/*      */     private void setEdgeAfter(TriSurf.Edge edgeAfter) {
/*  228 */       this._edgeAfter = edgeAfter;
/*      */     }
/*      */     private TriSurf.Face face() {
/*  231 */       return this._face;
/*      */     }
/*      */     private TriSurf.Face faceNext(TriSurf.Face face) {
/*  234 */       if (this == face.nodeA())
/*  235 */         return face.faceB(); 
/*  236 */       if (this == face.nodeB()) {
/*  237 */         return face.faceC();
/*      */       }
/*  239 */       return face.faceA();
/*      */     }
/*      */     
/*      */     private TriSurf.Face facePrev(TriSurf.Face face) {
/*  243 */       if (this == face.nodeA())
/*  244 */         return face.faceC(); 
/*  245 */       if (this == face.nodeB()) {
/*  246 */         return face.faceA();
/*      */       }
/*  248 */       return face.faceB();
/*      */     }
/*      */     
/*      */     private static void accNormalVector(TriSurf.Face face, float[] v) {
/*  252 */       Node na = face.nodeA();
/*  253 */       Node nb = face.nodeB();
/*  254 */       Node nc = face.nodeC();
/*  255 */       float xa = na.x();
/*  256 */       float ya = na.y();
/*  257 */       float za = na.z();
/*  258 */       float xb = nb.x();
/*  259 */       float yb = nb.y();
/*  260 */       float zb = nb.z();
/*  261 */       float xc = nc.x();
/*  262 */       float yc = nc.y();
/*  263 */       float zc = nc.z();
/*  264 */       float x0 = xc - xa;
/*  265 */       float y0 = yc - ya;
/*  266 */       float z0 = zc - za;
/*  267 */       float x1 = xa - xb;
/*  268 */       float y1 = ya - yb;
/*  269 */       float z1 = za - zb;
/*  270 */       v[0] = v[0] + y0 * z1 - y1 * z0;
/*  271 */       v[1] = v[1] + x1 * z0 - x0 * z1;
/*  272 */       v[2] = v[2] + x0 * y1 - x1 * y0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Edge
/*      */   {
/*      */     private TetMesh.Edge _meshEdge;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TriSurf.Face _faceLeft;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TriSurf.Face _faceRight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TriSurf.Node nodeA() {
/*  301 */       return (TriSurf.Node)(this._meshEdge.nodeA()).data;
/*      */     }
/*      */     public TriSurf.Node nodeB() {
/*  304 */       return (TriSurf.Node)(this._meshEdge.nodeB()).data;
/*      */     }
/*      */     public TriSurf.Face faceLeft() {
/*  307 */       return this._faceLeft;
/*      */     }
/*      */     public TriSurf.Face faceRight() {
/*  310 */       return this._faceRight;
/*      */     }
/*      */     public TriSurf.Node nodeLeft() {
/*  313 */       return (this._faceLeft != null) ? TriSurf.otherNode(this._faceLeft, nodeA(), nodeB()) : null;
/*      */     }
/*      */     public TriSurf.Node nodeRight() {
/*  316 */       return (this._faceRight != null) ? TriSurf.otherNode(this._faceRight, nodeA(), nodeB()) : null;
/*      */     }
/*      */     public Edge edgeBefore() {
/*  319 */       return (nodeA())._edgeBefore;
/*      */     }
/*      */     public Edge edgeAfter() {
/*  322 */       return (nodeB())._edgeAfter;
/*      */     }
/*      */     public Edge mate() {
/*  325 */       return new Edge(this._meshEdge.mate(), this._faceRight);
/*      */     }
/*      */     public boolean isInSurface() {
/*  328 */       return (this._faceRight != null);
/*      */     }
/*      */     public boolean isOnBoundary() {
/*  331 */       return (this._faceLeft == null);
/*      */     }
/*      */     public boolean equals(Object object) {
/*  334 */       if (object == this)
/*  335 */         return true; 
/*  336 */       if (object != null && object.getClass() == getClass()) {
/*  337 */         Edge other = (Edge)object;
/*  338 */         return (other.nodeA() == nodeA() && other.nodeB() == nodeB());
/*      */       } 
/*  340 */       return false;
/*      */     }
/*      */     public int hashCode() {
/*  343 */       return nodeA().hashCode() ^ nodeB().hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void validate() {
/*  349 */       assert this._meshEdge != null;
/*  350 */       assert this._faceLeft == null || this._faceLeft.references(nodeA(), nodeB());
/*  351 */       assert this._faceRight == null || this._faceRight.references(nodeA(), nodeB());
/*      */     }
/*      */     private Edge(TetMesh.Edge meshEdge, TriSurf.Face face) {
/*  354 */       this._meshEdge = meshEdge;
/*  355 */       TriSurf.Node nodeA = (TriSurf.Node)(meshEdge.nodeA()).data;
/*  356 */       TriSurf.Node nodeB = (TriSurf.Node)(meshEdge.nodeB()).data;
/*  357 */       TriSurf.Node nodeC = (face != null) ? TriSurf.otherNode(face, nodeA, nodeB) : null;
/*  358 */       Check.argument((face == null || nodeC != null), "face references edge");
/*  359 */       if (nodeC != null) {
/*  360 */         if (TriSurf.nodesInOrder(face, nodeA, nodeB, nodeC)) {
/*  361 */           this._faceLeft = face;
/*  362 */           this._faceRight = face.faceNabor(nodeC);
/*      */         } else {
/*  364 */           this._faceLeft = face.faceNabor(nodeC);
/*  365 */           this._faceRight = face;
/*      */         } 
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Face
/*      */   {
/*      */     public int index;
/*      */ 
/*      */ 
/*      */     
/*      */     public Object data;
/*      */ 
/*      */ 
/*      */     
/*      */     private TetMesh.Face _meshFace;
/*      */ 
/*      */ 
/*      */     
/*      */     private Face _faceA;
/*      */ 
/*      */ 
/*      */     
/*      */     private Face _faceB;
/*      */ 
/*      */ 
/*      */     
/*      */     private Face _faceC;
/*      */ 
/*      */ 
/*      */     
/*      */     private int _mark;
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Node nodeA() {
/*  405 */       return (TriSurf.Node)(this._meshFace.nodeA()).data;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Node nodeB() {
/*  413 */       return (TriSurf.Node)(this._meshFace.nodeB()).data;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Node nodeC() {
/*  421 */       return (TriSurf.Node)(this._meshFace.nodeC()).data;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Face faceA() {
/*  429 */       return this._faceA;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Face faceB() {
/*  437 */       return this._faceB;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Face faceC() {
/*  445 */       return this._faceC;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Face mate() {
/*  453 */       return new Face(this._meshFace.mate());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Node nodeNearest(float x, float y, float z) {
/*  465 */       TriSurf.Node na = nodeA();
/*  466 */       TriSurf.Node nb = nodeB();
/*  467 */       TriSurf.Node nc = nodeC();
/*  468 */       double da = TriSurf.distanceSquared(na, x, y, z);
/*  469 */       double db = TriSurf.distanceSquared(nb, x, y, z);
/*  470 */       double dc = TriSurf.distanceSquared(nc, x, y, z);
/*  471 */       double dmin = da;
/*  472 */       TriSurf.Node nmin = na;
/*  473 */       if (db < dmin) {
/*  474 */         dmin = db;
/*  475 */         nmin = nb;
/*      */       } 
/*  477 */       if (dc < dmin) {
/*  478 */         dmin = dc;
/*  479 */         nmin = nc;
/*      */       } 
/*  481 */       return nmin;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final Face faceNabor(TriSurf.Node node) {
/*  488 */       if (node == nodeA()) return this._faceA; 
/*  489 */       if (node == nodeB()) return this._faceB; 
/*  490 */       if (node == nodeC()) return this._faceC; 
/*  491 */       Check.argument(false, "node is referenced by face");
/*  492 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Node nodeNabor(Face faceNabor) {
/*  499 */       if (faceNabor._faceA == this) return faceNabor.nodeA(); 
/*  500 */       if (faceNabor._faceB == this) return faceNabor.nodeB(); 
/*  501 */       if (faceNabor._faceC == this) return faceNabor.nodeC(); 
/*  502 */       Check.argument(false, "faceNabor is a nabor of face");
/*  503 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double centerCircle(double[] cc) {
/*  512 */       TriSurf.Node na = nodeA();
/*  513 */       TriSurf.Node nb = nodeB();
/*  514 */       TriSurf.Node nc = nodeC();
/*  515 */       double xa = na.x();
/*  516 */       double ya = na.y();
/*  517 */       double za = na.z();
/*  518 */       double xb = nb.x();
/*  519 */       double yb = nb.y();
/*  520 */       double zb = nb.z();
/*  521 */       double xc = nc.x();
/*  522 */       double yc = nc.y();
/*  523 */       double zc = nc.z();
/*  524 */       Geometry.centerCircle3D(xa, ya, za, xb, yb, zb, xc, yc, zc, cc);
/*  525 */       double xcc = cc[0];
/*  526 */       double ycc = cc[1];
/*  527 */       double zcc = cc[2];
/*  528 */       double dx = xcc - xc;
/*  529 */       double dy = ycc - yc;
/*  530 */       double dz = zcc - yc;
/*  531 */       return dx * dx + dy * dy + dz * dz;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] centerCircle() {
/*  539 */       double[] cc = new double[3];
/*  540 */       centerCircle(cc);
/*  541 */       return cc;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float area() {
/*  549 */       return TriSurf.normalVector(this._meshFace, (float[])null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float[] normalVector() {
/*  557 */       float[] vn = new float[3];
/*  558 */       TriSurf.normalVector(this._meshFace, vn);
/*  559 */       return vn;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float normalVector(float[] vn) {
/*  568 */       return TriSurf.normalVector(this._meshFace, vn);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriSurf.Node node) {
/*  577 */       return (node == nodeA() || node == nodeB() || node == nodeC());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriSurf.Node node1, TriSurf.Node node2) {
/*  587 */       TriSurf.Node na = nodeA();
/*  588 */       TriSurf.Node nb = nodeB();
/*  589 */       TriSurf.Node nc = nodeC();
/*  590 */       if (node1 == na)
/*  591 */         return (node2 == nb || node2 == nc); 
/*  592 */       if (node1 == nb)
/*  593 */         return (node2 == na || node2 == nc); 
/*  594 */       if (node1 == nc) {
/*  595 */         return (node2 == na || node2 == nb);
/*      */       }
/*  597 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean references(TriSurf.Node node1, TriSurf.Node node2, TriSurf.Node node3) {
/*  609 */       TriSurf.Node na = nodeA();
/*  610 */       TriSurf.Node nb = nodeB();
/*  611 */       TriSurf.Node nc = nodeC();
/*  612 */       if (node1 == na) {
/*  613 */         if (node2 == nb)
/*  614 */           return (node3 == nc); 
/*  615 */         if (node2 == nc) {
/*  616 */           return (node3 == nb);
/*      */         }
/*  618 */         return false;
/*      */       } 
/*  620 */       if (node1 == nb) {
/*  621 */         if (node2 == na)
/*  622 */           return (node3 == nc); 
/*  623 */         if (node2 == nc) {
/*  624 */           return (node3 == na);
/*      */         }
/*  626 */         return false;
/*      */       } 
/*  628 */       if (node1 == nc) {
/*  629 */         if (node2 == na)
/*  630 */           return (node3 == nb); 
/*  631 */         if (node2 == nb) {
/*  632 */           return (node3 == na);
/*      */         }
/*  634 */         return false;
/*      */       } 
/*      */       
/*  637 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void validate() {
/*  645 */       assert this._meshFace != null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Face(TetMesh.Face meshFace) {
/*  652 */       this._meshFace = meshFace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FaceList
/*      */   {
/*      */     public final void add(TriSurf.Face face) {
/*  674 */       if (this._n == this._a.length) {
/*  675 */         TriSurf.Face[] t = new TriSurf.Face[this._a.length * 2];
/*  676 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  677 */         this._a = t;
/*      */       } 
/*  679 */       this._a[this._n++] = face;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Face remove(int index) {
/*  688 */       TriSurf.Face face = this._a[index];
/*  689 */       this._n--;
/*  690 */       if (this._n > index)
/*  691 */         System.arraycopy(this._a, index + 1, this._a, index, this._n - index); 
/*  692 */       return face;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Face[] trim() {
/*  700 */       if (this._n < this._a.length) {
/*  701 */         TriSurf.Face[] t = new TriSurf.Face[this._n];
/*  702 */         System.arraycopy(this._a, 0, t, 0, this._n);
/*  703 */         this._a = t;
/*      */       } 
/*  705 */       return this._a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void clear() {
/*  712 */       this._n = 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int nface() {
/*  720 */       return this._n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final TriSurf.Face[] faces() {
/*  728 */       return this._a;
/*      */     }
/*  730 */     private int _n = 0;
/*  731 */     private TriSurf.Face[] _a = new TriSurf.Face[64];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean addNode(Node node) {
/*  740 */     boolean added = this._mesh.addNode(node._meshNode);
/*  741 */     if (added)
/*  742 */       rebuild(); 
/*  743 */     return added;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean addNodes(Node[] nodes) {
/*  752 */     int nnode = nodes.length;
/*  753 */     int nadded = 0;
/*  754 */     for (int inode = 0; inode < nnode; inode++) {
/*  755 */       if (this._mesh.addNode((nodes[inode])._meshNode))
/*  756 */         nadded++; 
/*      */     } 
/*  758 */     if (nadded > 0)
/*  759 */       rebuild(); 
/*  760 */     return (nadded == nnode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean removeNode(Node node) {
/*  769 */     boolean removed = this._mesh.removeNode(node._meshNode);
/*  770 */     if (removed)
/*  771 */       rebuild(); 
/*  772 */     return removed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean removeNodes(Node[] nodes) {
/*  781 */     int nnode = nodes.length;
/*  782 */     int nremoved = 0;
/*  783 */     for (int inode = 0; inode < nnode; inode++) {
/*  784 */       if (this._mesh.removeNode((nodes[inode])._meshNode))
/*  785 */         nremoved++; 
/*      */     } 
/*  787 */     if (nremoved > 0)
/*  788 */       rebuild(); 
/*  789 */     return (nremoved == nnode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countNodes() {
/*  797 */     return this._mesh.countNodes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countFaces() {
/*  805 */     return this._faceMap.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized NodeIterator getNodes() {
/*  813 */     return new NodeIterator() {
/*      */         public final boolean hasNext() {
/*  815 */           return this._i.hasNext();
/*      */         }
/*      */         public final TriSurf.Node next() {
/*  818 */           return (TriSurf.Node)(this._i.next()).data;
/*      */         }
/*  820 */         private TetMesh.NodeIterator _i = TriSurf.this._mesh.getNodes();
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized FaceIterator getFaces() {
/*  829 */     return new FaceIterator() {
/*      */         public final boolean hasNext() {
/*  831 */           return this._i.hasNext();
/*      */         }
/*      */         public final TriSurf.Face next() {
/*  834 */           return this._i.next();
/*      */         }
/*  836 */         private Iterator _i = TriSurf.this._faceMap.values().iterator();
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Node findNodeNearest(float x, float y, float z) {
/*  848 */     TetMesh.Node meshNode = this._mesh.findNodeNearest(x, y, z);
/*  849 */     return (Node)meshNode.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Face[] getFaceNabors(Node node) {
/*  858 */     FaceList nabors = new FaceList();
/*  859 */     getFaceNabors(node, nabors);
/*  860 */     return nabors.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void getFaceNabors(Node node, FaceList nabors) {
/*  869 */     clearFaceMarks();
/*  870 */     getFaceNabors(node, node._face, nabors);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Face findFace(Node node) {
/*  880 */     return node._face;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Face findFace(Node node1, Node node2) {
/*  891 */     Face face = findFace(node1);
/*  892 */     if (face != null) {
/*      */ 
/*      */       
/*  895 */       if (face.references(node2))
/*  896 */         return face; 
/*  897 */       Face face1 = face;
/*  898 */       face = node1.faceNext(face1);
/*  899 */       while (face != face1 && face != null) {
/*  900 */         if (face.references(node2))
/*  901 */           return face; 
/*  902 */         face = node1.faceNext(face);
/*      */       } 
/*  904 */       if (face == null) {
/*  905 */         face = node1.facePrev(face1);
/*  906 */         while (face != face1 && face != null) {
/*  907 */           if (face.references(node2))
/*  908 */             return face; 
/*  909 */           face = node1.facePrev(face);
/*      */         } 
/*      */       } 
/*      */     } 
/*  913 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Face findFace(Node node1, Node node2, Node node3) {
/*  925 */     Face face = findFace(node1, node2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  930 */     if (face != null) {
/*  931 */       if (face.references(node3))
/*  932 */         return face; 
/*  933 */       face = face.faceNabor(node3);
/*  934 */       if (face != null && face.references(node3))
/*  935 */         return face; 
/*      */     } 
/*  937 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Edge findEdge(Node nodeA, Node nodeB) {
/*  948 */     TetMesh.Edge meshEdge = findMeshEdge(nodeA, nodeB);
/*  949 */     Edge edge = getEdge(meshEdge);
/*  950 */     if (meshEdge != null && edge == null) {
/*  951 */       Face face = findFace(nodeA, nodeB);
/*  952 */       if (face != null) {
/*  953 */         Node nodeC = otherNode(face, nodeA, nodeB);
/*  954 */         if (nodesInOrder(face, nodeA, nodeB, nodeC))
/*  955 */           edge = new Edge(meshEdge, face); 
/*      */       } 
/*      */     } 
/*  958 */     return edge;
/*      */   }
/*      */   
/*      */   private static class EdgeFace
/*      */     implements Comparable
/*      */   {
/*      */     TriSurf.Edge edge;
/*      */     TriSurf.Face face;
/*      */     double grade;
/*      */     
/*      */     EdgeFace(TriSurf.Edge edge, TriSurf.Face face, double grade) {
/*  969 */       this.edge = edge;
/*  970 */       this.face = face;
/*  971 */       this.grade = grade;
/*      */     }
/*      */     public int compareTo(Object object) {
/*  974 */       EdgeFace other = (EdgeFace)object;
/*  975 */       double gradeOther = other.grade;
/*  976 */       if (this.grade < gradeOther)
/*  977 */         return -1; 
/*  978 */       if (this.grade > gradeOther) {
/*  979 */         return 1;
/*      */       }
/*  981 */       TriSurf.Edge edgeOther = other.edge;
/*  982 */       int hash = this.edge.hashCode();
/*  983 */       int hashOther = edgeOther.hashCode();
/*  984 */       if (hash < hashOther)
/*  985 */         return -1; 
/*  986 */       if (hash > hashOther) {
/*  987 */         return 1;
/*      */       }
/*  989 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  998 */   private TetMesh _mesh = new TetMesh();
/*      */ 
/*      */   
/* 1001 */   private Set<TetMesh.Face> _faceSet = new HashSet<TetMesh.Face>();
/*      */ 
/*      */   
/* 1004 */   private Map<TetMesh.Face, Face> _faceMap = new HashMap<TetMesh.Face, Face>();
/*      */ 
/*      */   
/* 1007 */   private Map<TetMesh.Edge, EdgeFace> _edgeMap = new HashMap<TetMesh.Edge, EdgeFace>();
/*      */ 
/*      */ 
/*      */   
/* 1011 */   private SortedSet<EdgeFace> _edgeQueue = new TreeSet<EdgeFace>();
/*      */   
/*      */   private int _faceMarkRed;
/*      */   private int _faceMarkBlue;
/*      */   
/*      */   private void validate() {
/* 1017 */     NodeIterator ni = getNodes();
/* 1018 */     while (ni.hasNext()) {
/* 1019 */       Node node = ni.next();
/* 1020 */       node.validate();
/*      */     } 
/* 1022 */     FaceIterator fi = getFaces();
/* 1023 */     while (fi.hasNext()) {
/* 1024 */       Face face = fi.next();
/* 1025 */       face.validate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final double distanceSquared(Node node, double x, double y, double z) {
/* 1036 */     double dx = x - node.x();
/* 1037 */     double dy = y - node.y();
/* 1038 */     double dz = z - node.z();
/* 1039 */     return dx * dx + dy * dy + dz * dz;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Face findFace(Face face, Node n1, Node n2) {
/* 1048 */     if (face != null) {
/* 1049 */       mark(face);
/* 1050 */       Node na = face.nodeA();
/* 1051 */       Node nb = face.nodeB();
/* 1052 */       Node nc = face.nodeC();
/* 1053 */       Face fa = face.faceA();
/* 1054 */       Face fb = face.faceB();
/* 1055 */       Face fc = face.faceC();
/* 1056 */       if (n1 == na) {
/* 1057 */         if (n2 == nb || n2 == nc || (fb != null && !isMarked(fb) && (face = findFace(fb, n1, n2)) != null) || (fc != null && !isMarked(fc) && (face = findFace(fc, n1, n2)) != null))
/*      */         {
/*      */           
/* 1060 */           return face; } 
/* 1061 */       } else if (n1 == nb) {
/* 1062 */         if (n2 == nc || n2 == na || (fc != null && !isMarked(fc) && (face = findFace(fc, n1, n2)) != null) || (fa != null && !isMarked(fa) && (face = findFace(fa, n1, n2)) != null))
/*      */         {
/*      */           
/* 1065 */           return face; } 
/* 1066 */       } else if (n1 == nc) {
/* 1067 */         if (n2 == na || n2 == nb || (fa != null && !isMarked(fa) && (face = findFace(fa, n1, n2)) != null) || (fb != null && !isMarked(fb) && (face = findFace(fb, n1, n2)) != null))
/*      */         {
/*      */           
/* 1070 */           return face; } 
/*      */       } else {
/* 1072 */         assert false : "n1 is referenced by face";
/*      */       } 
/*      */     } 
/* 1075 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Face findFace(Face face, Node n1, Node n2, Node n3) {
/* 1084 */     if (face != null) {
/* 1085 */       mark(face);
/* 1086 */       Node na = face.nodeA();
/* 1087 */       Node nb = face.nodeB();
/* 1088 */       Node nc = face.nodeC();
/* 1089 */       Face fa = face.faceA();
/* 1090 */       Face fb = face.faceB();
/* 1091 */       Face fc = face.faceC();
/* 1092 */       if (n1 == na) {
/* 1093 */         if (n2 == nb) {
/* 1094 */           if (n3 == nc || (fc != null && !isMarked(fc) && (face = findFace(fc, n1, n2, n3)) != null))
/*      */           {
/* 1096 */             return face; } 
/* 1097 */         } else if (n2 == nc) {
/* 1098 */           if (n3 == nb || (fb != null && !isMarked(fb) && (face = findFace(fb, n1, n2, n3)) != null))
/*      */           {
/* 1100 */             return face; } 
/*      */         } else {
/* 1102 */           assert false : "n2 is referenced by face";
/*      */         } 
/* 1104 */       } else if (n1 == nb) {
/* 1105 */         if (n2 == na) {
/* 1106 */           if (n3 == nc || (fc != null && !isMarked(fc) && (face = findFace(fc, n1, n2, n3)) != null))
/*      */           {
/* 1108 */             return face; } 
/* 1109 */         } else if (n2 == nc) {
/* 1110 */           if (n3 == na || (fa != null && !isMarked(fa) && (face = findFace(fa, n1, n2, n3)) != null))
/*      */           {
/* 1112 */             return face; } 
/*      */         } else {
/* 1114 */           assert false : "n2 is referenced by face";
/*      */         } 
/* 1116 */       } else if (n1 == nc) {
/* 1117 */         if (n2 == na) {
/* 1118 */           if (n3 == nb || (fb != null && !isMarked(fb) && (face = findFace(fb, n1, n2, n3)) != null))
/*      */           {
/* 1120 */             return face; } 
/* 1121 */         } else if (n2 == nb) {
/* 1122 */           if (n3 == na || (fa != null && !isMarked(fa) && (face = findFace(fa, n1, n2, n3)) != null))
/*      */           {
/* 1124 */             return face; } 
/*      */         } else {
/* 1126 */           assert false : "n2 is referenced by face";
/*      */         } 
/*      */       } else {
/* 1129 */         assert false : "n1 is referenced by face";
/*      */       } 
/*      */     } 
/* 1132 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void mark(Face face) {
/* 1144 */     face._mark = this._faceMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void markRed(Face face) {
/* 1153 */     face._mark = this._faceMarkRed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void markBlue(Face face) {
/* 1161 */     face._mark = this._faceMarkBlue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isMarked(Face face) {
/* 1170 */     return (face._mark == this._faceMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isMarkedRed(Face face) {
/* 1179 */     return (face._mark == this._faceMarkRed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isMarkedBlue(Face face) {
/* 1188 */     return (face._mark == this._faceMarkBlue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void clearFaceMarks() {
/* 1198 */     if (this._faceMarkRed == 2147483646) {
/* 1199 */       Iterator<Face> fi = this._faceMap.values().iterator();
/* 1200 */       while (fi.hasNext()) {
/* 1201 */         Face face = fi.next();
/* 1202 */         face._mark = 0;
/*      */       } 
/* 1204 */       this._faceMarkRed = 0;
/* 1205 */       this._faceMarkBlue = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1209 */     this._faceMarkRed++;
/* 1210 */     this._faceMarkBlue--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getFaceNabors(Node node, Face face, FaceList nabors) {
/* 1220 */     if (face != null) {
/* 1221 */       mark(face);
/* 1222 */       nabors.add(face);
/* 1223 */       Node na = face.nodeA();
/* 1224 */       Node nb = face.nodeB();
/* 1225 */       Node nc = face.nodeC();
/* 1226 */       Face fa = face.faceA();
/* 1227 */       Face fb = face.faceB();
/* 1228 */       Face fc = face.faceC();
/* 1229 */       if (node == na) {
/* 1230 */         if (fb != null && !isMarked(fb))
/* 1231 */           getFaceNabors(node, fb, nabors); 
/* 1232 */         if (fc != null && !isMarked(fc))
/* 1233 */           getFaceNabors(node, fc, nabors); 
/* 1234 */       } else if (node == nb) {
/* 1235 */         if (fc != null && !isMarked(fc))
/* 1236 */           getFaceNabors(node, fc, nabors); 
/* 1237 */         if (fa != null && !isMarked(fa))
/* 1238 */           getFaceNabors(node, fa, nabors); 
/* 1239 */       } else if (node == nc) {
/* 1240 */         if (fa != null && !isMarked(fa))
/* 1241 */           getFaceNabors(node, fa, nabors); 
/* 1242 */         if (fb != null && !isMarked(fb))
/* 1243 */           getFaceNabors(node, fb, nabors); 
/*      */       } else {
/* 1245 */         assert false : "node is referenced by face";
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Edge getEdge(TetMesh.Edge meshEdge) {
/* 1251 */     EdgeFace edgeFace = this._edgeMap.get(meshEdge);
/* 1252 */     return (edgeFace != null) ? edgeFace.edge : null;
/*      */   }
/*      */   
/*      */   private EdgeFace getEdgeFace(Edge edge) {
/* 1256 */     return this._edgeMap.get(edge._meshEdge);
/*      */   }
/*      */   
/*      */   private EdgeFace getBestEdgeFace() {
/* 1260 */     return !this._edgeQueue.isEmpty() ? this._edgeQueue.last() : null;
/*      */   }
/*      */   
/*      */   private EdgeFace getNextEdgeFace(EdgeFace edgeFace) {
/* 1264 */     SortedSet<EdgeFace> headSet = this._edgeQueue.headSet(edgeFace);
/* 1265 */     return !headSet.isEmpty() ? headSet.last() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   private EdgeFace addEdge(Edge edge) {
/* 1270 */     EdgeFace edgeFace = makeEdgeFace(edge);
/* 1271 */     assert edgeFace != null : "edgeFace!=null";
/* 1272 */     Object edgeFaceOld = this._edgeMap.put(edge._meshEdge, edgeFace);
/* 1273 */     assert edgeFaceOld == null : "edge was not mapped";
/* 1274 */     boolean added = this._edgeQueue.add(edgeFace);
/* 1275 */     assert added : "edgeFace was not in queue";
/* 1276 */     return edgeFace;
/*      */   }
/*      */ 
/*      */   
/*      */   private void removeEdge(Edge edge) {
/* 1281 */     EdgeFace edgeFace = getEdgeFace(edge);
/* 1282 */     assert edgeFace != null : "edgeFace!=null";
/* 1283 */     Object edgeFaceOld = this._edgeMap.remove(edge._meshEdge);
/* 1284 */     assert edgeFaceOld != null : "edge was mapped";
/* 1285 */     boolean removed = this._edgeQueue.remove(edgeFace);
/* 1286 */     assert removed : "edgeFace was in queue";
/*      */   }
/*      */   
/*      */   private void addFace(Face face) {
/* 1290 */     boolean removed = (this._faceSet.remove(face._meshFace) || this._faceSet.remove(face._meshFace.mate()));
/*      */     
/* 1292 */     assert removed : "face not already in surface";
/* 1293 */     Face faceOld = this._faceMap.put(face._meshFace, face);
/* 1294 */     assert faceOld == null : "face not already in surface";
/*      */   }
/*      */   
/*      */   private void removeFace(Face face) {
/* 1298 */     this._faceMap.remove(face._meshFace);
/*      */   }
/*      */   
/*      */   private void init(Face face) {
/* 1302 */     trace("init: face=" + face);
/* 1303 */     trace("  meshFace A=" + face._meshFace.nodeA());
/* 1304 */     trace("  meshFace B=" + face._meshFace.nodeB());
/* 1305 */     trace("  meshFace C=" + face._meshFace.nodeC());
/* 1306 */     face._faceA = null;
/* 1307 */     face._faceB = null;
/* 1308 */     face._faceC = null;
/* 1309 */     Node nodeA = face.nodeA();
/* 1310 */     Node nodeB = face.nodeB();
/* 1311 */     Node nodeC = face.nodeC();
/* 1312 */     nodeA.setFace(face);
/* 1313 */     nodeB.setFace(face);
/* 1314 */     nodeC.setFace(face);
/* 1315 */     Edge edgeCB = makeEdge(nodeC, nodeB, face);
/* 1316 */     Edge edgeBA = makeEdge(nodeB, nodeA, face);
/* 1317 */     Edge edgeAC = makeEdge(nodeA, nodeC, face);
/* 1318 */     nodeA.setEdgeBefore(edgeBA);
/* 1319 */     nodeB.setEdgeBefore(edgeCB);
/* 1320 */     nodeC.setEdgeBefore(edgeAC);
/* 1321 */     nodeA.setEdgeAfter(edgeAC);
/* 1322 */     nodeB.setEdgeAfter(edgeBA);
/* 1323 */     nodeC.setEdgeAfter(edgeCB);
/* 1324 */     addEdge(edgeCB);
/* 1325 */     addEdge(edgeBA);
/* 1326 */     addEdge(edgeAC);
/* 1327 */     addFace(face);
/*      */   }
/*      */   
/*      */   private void extend(Edge edge, Face face) {
/* 1331 */     trace("extend: edge=" + edge + " face=" + face);
/* 1332 */     trace("  meshEdge A=" + edge._meshEdge.nodeA());
/* 1333 */     trace("  meshEdge B=" + edge._meshEdge.nodeB());
/* 1334 */     trace("  meshFace A=" + face._meshFace.nodeA());
/* 1335 */     trace("  meshFace B=" + face._meshFace.nodeB());
/* 1336 */     trace("  meshFace C=" + face._meshFace.nodeC());
/* 1337 */     assert edge.isOnBoundary();
/* 1338 */     Node nodeA = edge.nodeA();
/* 1339 */     Node nodeB = edge.nodeB();
/* 1340 */     Node nodeC = otherNode(face, nodeA, nodeB);
/* 1341 */     nodeC.setFace(face);
/* 1342 */     linkFaces(face, nodeC, edge.faceRight(), edge.nodeRight());
/* 1343 */     Edge edgeAC = makeEdge(nodeA, nodeC, face);
/* 1344 */     Edge edgeCB = makeEdge(nodeC, nodeB, face);
/* 1345 */     nodeA.setEdgeAfter(edgeAC);
/* 1346 */     nodeB.setEdgeBefore(edgeCB);
/* 1347 */     nodeC.setEdgeAfter(edgeCB);
/* 1348 */     nodeC.setEdgeBefore(edgeAC);
/* 1349 */     removeEdge(edge);
/* 1350 */     addFace(face);
/* 1351 */     addEdge(edgeAC);
/* 1352 */     addEdge(edgeCB);
/*      */   }
/*      */   
/*      */   private void fillEar(Edge edge, Face face) {
/* 1356 */     trace("fillEar: edge=" + edge + " face=" + face);
/* 1357 */     trace("  meshEdge A=" + edge._meshEdge.nodeA());
/* 1358 */     trace("  meshEdge B=" + edge._meshEdge.nodeB());
/* 1359 */     trace("  meshFace A=" + face._meshFace.nodeA());
/* 1360 */     trace("  meshFace B=" + face._meshFace.nodeB());
/* 1361 */     trace("  meshFace C=" + face._meshFace.nodeC());
/* 1362 */     Node nodeA = edge.nodeA();
/* 1363 */     Node nodeB = edge.nodeB();
/* 1364 */     Node nodeC = otherNode(face, nodeA, nodeB);
/* 1365 */     Edge edge1 = nodeC.edgeBefore();
/* 1366 */     Edge edge2 = nodeC.edgeAfter();
/* 1367 */     Node node1 = edge1.nodeA();
/* 1368 */     Node node2 = edge2.nodeB();
/* 1369 */     if (node2 == nodeA) {
/* 1370 */       linkFaces(face, nodeC, edge.faceRight(), edge.nodeRight());
/* 1371 */       linkFaces(face, nodeB, edge2.faceRight(), edge2.nodeRight());
/* 1372 */       Edge edgeCB = makeEdge(nodeC, nodeB, face);
/* 1373 */       nodeC.setEdgeAfter(edgeCB);
/* 1374 */       nodeB.setEdgeBefore(edgeCB);
/* 1375 */       nodeA.setEdgeAfter(null);
/* 1376 */       nodeA.setEdgeBefore(null);
/* 1377 */       removeEdge(edge);
/* 1378 */       removeEdge(edge2);
/* 1379 */       addFace(face);
/* 1380 */       addEdge(edgeCB);
/* 1381 */     } else if (node1 == nodeB) {
/* 1382 */       linkFaces(face, nodeC, edge.faceRight(), edge.nodeRight());
/* 1383 */       linkFaces(face, nodeA, edge1.faceRight(), edge1.nodeRight());
/* 1384 */       Edge edgeAC = makeEdge(nodeA, nodeC, face);
/* 1385 */       nodeA.setEdgeAfter(edgeAC);
/* 1386 */       nodeC.setEdgeBefore(edgeAC);
/* 1387 */       nodeB.setEdgeAfter(null);
/* 1388 */       nodeB.setEdgeBefore(null);
/* 1389 */       removeEdge(edge);
/* 1390 */       removeEdge(edge1);
/* 1391 */       addFace(face);
/* 1392 */       addEdge(edgeAC);
/*      */     } else {
/* 1394 */       assert false : "ear is valid";
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fillHole(Edge edge, Face face) {
/* 1399 */     trace("fillHole: edge=" + edge + " face=" + face);
/* 1400 */     trace("  meshEdge A=" + edge._meshEdge.nodeA());
/* 1401 */     trace("  meshEdge B=" + edge._meshEdge.nodeB());
/* 1402 */     trace("  meshFace A=" + face._meshFace.nodeA());
/* 1403 */     trace("  meshFace B=" + face._meshFace.nodeB());
/* 1404 */     trace("  meshFace C=" + face._meshFace.nodeC());
/* 1405 */     Edge edgeAB = edge;
/* 1406 */     Edge edgeBC = edge.edgeAfter();
/* 1407 */     Edge edgeCA = edge.edgeBefore();
/* 1408 */     assert edgeAB.isOnBoundary();
/* 1409 */     assert edgeBC.isOnBoundary();
/* 1410 */     assert edgeCA.isOnBoundary();
/* 1411 */     Face faceAB = edgeAB.faceRight();
/* 1412 */     Face faceBC = edgeBC.faceRight();
/* 1413 */     Face faceCA = edgeCA.faceRight();
/* 1414 */     Node nodeA = edgeAB.nodeA();
/* 1415 */     Node nodeB = edgeBC.nodeA();
/* 1416 */     Node nodeC = edgeCA.nodeA();
/* 1417 */     linkFaces(face, nodeA, faceBC, otherNode(faceBC, nodeB, nodeC));
/* 1418 */     linkFaces(face, nodeB, faceCA, otherNode(faceCA, nodeA, nodeC));
/* 1419 */     linkFaces(face, nodeC, faceAB, otherNode(faceAB, nodeA, nodeB));
/* 1420 */     nodeA.setEdgeBefore(null);
/* 1421 */     nodeB.setEdgeBefore(null);
/* 1422 */     nodeC.setEdgeBefore(null);
/* 1423 */     nodeA.setEdgeAfter(null);
/* 1424 */     nodeB.setEdgeAfter(null);
/* 1425 */     nodeC.setEdgeAfter(null);
/* 1426 */     removeEdge(edgeAB);
/* 1427 */     removeEdge(edgeBC);
/* 1428 */     removeEdge(edgeCA);
/* 1429 */     addFace(face);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EdgeFace findTwin(EdgeFace edgeFace) {
/* 1438 */     Edge edge = edgeFace.edge;
/* 1439 */     Face face = edgeFace.face;
/* 1440 */     double grade = edgeFace.grade;
/* 1441 */     Node nodeA = edge.nodeA();
/* 1442 */     Node nodeB = edge.nodeB();
/* 1443 */     Node nodeC = otherNode(face, nodeA, nodeB);
/* 1444 */     assert nodeA.isOnBoundary();
/* 1445 */     assert nodeB.isOnBoundary();
/* 1446 */     assert nodeC.isOnBoundary();
/* 1447 */     Node node1 = nodeC.edgeBefore().nodeA();
/* 1448 */     assert node1 != nodeA;
/* 1449 */     assert node1 != nodeB;
/* 1450 */     if (node1.isOnBoundary()) {
/* 1451 */       Edge edgeTwin = node1.edgeAfter();
/* 1452 */       assert nodeC == edgeTwin.nodeB();
/* 1453 */       removeEdge(edgeTwin);
/* 1454 */       EdgeFace edgeFaceTwin = addEdge(edgeTwin);
/* 1455 */       Face faceTwin = edgeFaceTwin.face;
/* 1456 */       double gradeTwin = edgeFaceTwin.grade;
/* 1457 */       if (faceTwin != null && nodesInOrder(faceTwin, node1, nodeC, nodeB) && gradeTwin > grade)
/*      */       {
/*      */         
/* 1460 */         return edgeFaceTwin; } 
/*      */     } 
/* 1462 */     Node node2 = nodeC.edgeAfter().nodeB();
/* 1463 */     assert node2 != nodeA;
/* 1464 */     assert node2 != nodeB;
/* 1465 */     if (node2.isOnBoundary()) {
/* 1466 */       Edge edgeTwin = node2.edgeBefore();
/* 1467 */       assert nodeC == edgeTwin.nodeA();
/* 1468 */       removeEdge(edgeTwin);
/* 1469 */       EdgeFace edgeFaceTwin = addEdge(edgeTwin);
/* 1470 */       Face faceTwin = edgeFaceTwin.face;
/* 1471 */       double gradeTwin = edgeFaceTwin.grade;
/* 1472 */       if (faceTwin != null && nodesInOrder(faceTwin, node2, nodeA, nodeC) && gradeTwin > grade)
/*      */       {
/*      */         
/* 1475 */         return edgeFaceTwin; } 
/*      */     } 
/* 1477 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void glue(Edge edge, Face face, Edge edgeTwin, Face faceTwin) {
/* 1484 */     trace("glue: edge=" + edge + " face=" + face);
/* 1485 */     trace("  meshEdge A=" + edge._meshEdge.nodeA());
/* 1486 */     trace("  meshEdge B=" + edge._meshEdge.nodeB());
/* 1487 */     trace("  meshFace A=" + face._meshFace.nodeA());
/* 1488 */     trace("  meshFace B=" + face._meshFace.nodeB());
/* 1489 */     trace("  meshFace C=" + face._meshFace.nodeC());
/* 1490 */     trace("  meshEdgeTwin A=" + edgeTwin._meshEdge.nodeA());
/* 1491 */     trace("  meshEdgeTwin B=" + edgeTwin._meshEdge.nodeB());
/* 1492 */     trace("  meshFaceTwin A=" + faceTwin._meshFace.nodeA());
/* 1493 */     trace("  meshFaceTwin B=" + faceTwin._meshFace.nodeB());
/* 1494 */     trace("  meshFaceTwin C=" + faceTwin._meshFace.nodeC());
/* 1495 */     Node nodeA = edge.nodeA();
/* 1496 */     Node nodeB = edge.nodeB();
/* 1497 */     Node nodeC = otherNode(face, nodeA, nodeB);
/* 1498 */     assert nodeA.isOnBoundary();
/* 1499 */     assert nodeB.isOnBoundary();
/* 1500 */     assert nodeC.isOnBoundary();
/*      */ 
/*      */     
/* 1503 */     removeEdge(edge);
/* 1504 */     removeEdge(edgeTwin);
/* 1505 */     addFace(face);
/* 1506 */     addFace(faceTwin);
/*      */ 
/*      */     
/* 1509 */     if (faceTwin.references(nodeA)) {
/* 1510 */       Node nodeD = nodeC.edgeAfter().nodeB();
/* 1511 */       assert nodeD.isOnBoundary();
/*      */ 
/*      */       
/* 1514 */       if (nodeD.edgeAfter() == nodeA.edgeBefore()) {
/* 1515 */         Edge edgeDA = nodeD.edgeAfter();
/* 1516 */         nodeA.setEdgeBefore(null);
/* 1517 */         nodeD.setEdgeBefore(null);
/* 1518 */         nodeA.setEdgeAfter(null);
/* 1519 */         nodeD.setEdgeAfter(null);
/* 1520 */         removeEdge(edgeDA);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1525 */         Edge edgeAD = makeEdge(nodeA, nodeD, faceTwin);
/* 1526 */         nodeA.setEdgeAfter(edgeAD);
/* 1527 */         nodeD.setEdgeBefore(edgeAD);
/* 1528 */         addEdge(edgeAD);
/*      */       } 
/*      */ 
/*      */       
/* 1532 */       Edge edgeCB = makeEdge(nodeC, nodeB, face);
/* 1533 */       nodeC.setEdgeAfter(edgeCB);
/* 1534 */       nodeB.setEdgeBefore(edgeCB);
/* 1535 */       addEdge(edgeCB);
/* 1536 */       linkFaces(face, nodeB, faceTwin, nodeD);
/* 1537 */       linkFaces(face, nodeC, edge.faceRight(), edge.nodeRight());
/* 1538 */       linkFaces(faceTwin, nodeA, edgeTwin.faceRight(), edgeTwin.nodeRight());
/*      */ 
/*      */     
/*      */     }
/* 1542 */     else if (faceTwin.references(nodeB)) {
/* 1543 */       Node nodeD = nodeC.edgeBefore().nodeA();
/* 1544 */       assert nodeD.isOnBoundary();
/*      */ 
/*      */       
/* 1547 */       if (nodeD.edgeBefore() == nodeB.edgeAfter()) {
/* 1548 */         Edge edgeBD = nodeD.edgeBefore();
/* 1549 */         nodeB.setEdgeBefore(null);
/* 1550 */         nodeD.setEdgeBefore(null);
/* 1551 */         nodeB.setEdgeAfter(null);
/* 1552 */         nodeD.setEdgeAfter(null);
/* 1553 */         removeEdge(edgeBD);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1558 */         Edge edgeDB = makeEdge(nodeD, nodeB, faceTwin);
/* 1559 */         nodeD.setEdgeAfter(edgeDB);
/* 1560 */         nodeB.setEdgeBefore(edgeDB);
/* 1561 */         addEdge(edgeDB);
/*      */       } 
/*      */ 
/*      */       
/* 1565 */       Edge edgeAC = makeEdge(nodeA, nodeC, face);
/* 1566 */       nodeA.setEdgeAfter(edgeAC);
/* 1567 */       nodeC.setEdgeBefore(edgeAC);
/* 1568 */       addEdge(edgeAC);
/* 1569 */       linkFaces(face, nodeA, faceTwin, nodeD);
/* 1570 */       linkFaces(face, nodeC, edge.faceRight(), edge.nodeRight());
/* 1571 */       linkFaces(faceTwin, nodeB, edgeTwin.faceRight(), edgeTwin.nodeRight());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean stitch(EdgeFace edgeFace) {
/* 1577 */     Edge edge = edgeFace.edge;
/* 1578 */     Face face = edgeFace.face;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1584 */     Node nodeA = edge.nodeA();
/* 1585 */     Node nodeB = edge.nodeB();
/* 1586 */     Node nodeC = otherNode(face, nodeA, nodeB);
/*      */ 
/*      */     
/* 1589 */     if (!validForFace(nodeA, nodeB, nodeC)) {
/* 1590 */       removeEdge(edge);
/* 1591 */       addEdge(edge);
/* 1592 */       return true;
/*      */     } 
/*      */ 
/*      */     
/* 1596 */     if (!nodeC.isInSurface()) {
/* 1597 */       extend(edge, face);
/* 1598 */       return true;
/*      */     } 
/*      */ 
/*      */     
/* 1602 */     if (nodeC.isOnBoundary()) {
/*      */ 
/*      */       
/* 1605 */       Node node1 = nodeC.edgeBefore().nodeA();
/* 1606 */       Node node2 = nodeC.edgeAfter().nodeB();
/*      */ 
/*      */       
/* 1609 */       if (node1 == nodeB && node2 == nodeA) {
/* 1610 */         fillHole(edge, face);
/* 1611 */         return true;
/*      */       } 
/*      */ 
/*      */       
/* 1615 */       if (node1 == nodeB || node2 == nodeA) {
/* 1616 */         fillEar(edge, face);
/* 1617 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1624 */       EdgeFace edgeFaceTwin = findTwin(edgeFace);
/* 1625 */       if (edgeFaceTwin != null) {
/* 1626 */         Edge edgeTwin = edgeFaceTwin.edge;
/* 1627 */         Face faceTwin = edgeFaceTwin.face;
/* 1628 */         glue(edge, face, edgeTwin, faceTwin);
/* 1629 */         return true;
/*      */       } 
/* 1631 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1638 */     assert false : "valid face for extend, fill ear, fill hole, or glue";
/* 1639 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private void rebuild() {
/* 1644 */     trace("rebuild");
/* 1645 */     init();
/* 1646 */     while (surf());
/*      */   }
/*      */ 
/*      */   
/*      */   private void init() {
/* 1651 */     trace("  init: ntets=" + this._mesh.countTets());
/* 1652 */     this._faceSet.clear();
/* 1653 */     this._faceMap.clear();
/* 1654 */     this._edgeMap.clear();
/* 1655 */     this._edgeQueue.clear();
/* 1656 */     TetMesh.TetIterator ti = this._mesh.getTets();
/* 1657 */     while (ti.hasNext()) {
/* 1658 */       TetMesh.Tet tet = ti.next();
/* 1659 */       TetMesh.Node a = tet.nodeA();
/* 1660 */       TetMesh.Node b = tet.nodeB();
/* 1661 */       TetMesh.Node c = tet.nodeC();
/* 1662 */       TetMesh.Node d = tet.nodeD();
/* 1663 */       TetMesh.Face[] meshFaces = { new TetMesh.Face(a, b, c, tet), new TetMesh.Face(b, d, c, tet), new TetMesh.Face(c, d, a, tet), new TetMesh.Face(d, b, a, tet) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1669 */       for (int i = 0; i < 4; i++) {
/* 1670 */         TetMesh.Face meshFacei = meshFaces[i];
/* 1671 */         if (!this._faceSet.contains(meshFacei.mate())) {
/* 1672 */           this._faceSet.add(meshFacei);
/* 1673 */           trace("  init: added face" + meshFacei);
/* 1674 */           trace("        node A=" + meshFacei.nodeA());
/* 1675 */           trace("        node B=" + meshFacei.nodeB());
/* 1676 */           trace("        node C=" + meshFacei.nodeC());
/*      */         } 
/*      */       } 
/* 1679 */       ((Node)a.data).init();
/* 1680 */       ((Node)b.data).init();
/* 1681 */       ((Node)c.data).init();
/* 1682 */       ((Node)d.data).init();
/*      */     } 
/* 1684 */     trace("  init: _faceSet size=" + this._faceSet.size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean surf() {
/* 1693 */     int nface = countFaces();
/*      */ 
/*      */     
/* 1696 */     if (this._faceSet.isEmpty()) {
/* 1697 */       return false;
/*      */     }
/*      */     
/* 1700 */     TetMesh.Face meshFace = null;
/* 1701 */     double rrmin = Double.MAX_VALUE;
/* 1702 */     double[] cc = new double[3];
/* 1703 */     Iterator<TetMesh.Face> mfi = this._faceSet.iterator();
/* 1704 */     while (mfi.hasNext()) {
/* 1705 */       TetMesh.Face meshFacei = mfi.next();
/* 1706 */       double rr = meshFacei.centerCircle(cc);
/* 1707 */       if (rr < rrmin) {
/* 1708 */         meshFace = meshFacei;
/* 1709 */         rrmin = rr;
/*      */       } 
/*      */     } 
/* 1712 */     assert meshFace != null;
/*      */ 
/*      */     
/* 1715 */     Face face = new Face(meshFace);
/* 1716 */     init(face);
/*      */ 
/*      */     
/* 1719 */     trace("  surf: stitching");
/* 1720 */     EdgeFace edgeFace = getBestEdgeFace();
/* 1721 */     while (edgeFace != null && edgeFace.face != null) {
/* 1722 */       if (stitch(edgeFace)) {
/* 1723 */         edgeFace = getBestEdgeFace(); continue;
/*      */       } 
/* 1725 */       edgeFace = getNextEdgeFace(edgeFace);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1730 */     trace("  surf: removing faces");
/* 1731 */     ArrayList<TetMesh.Face> faceList = new ArrayList<TetMesh.Face>();
/* 1732 */     mfi = this._faceSet.iterator();
/* 1733 */     while (mfi.hasNext()) {
/* 1734 */       TetMesh.Face meshFacei = mfi.next();
/* 1735 */       Node nodeA = (Node)(meshFacei.nodeA()).data;
/* 1736 */       Node nodeB = (Node)(meshFacei.nodeB()).data;
/* 1737 */       Node nodeC = (Node)(meshFacei.nodeC()).data;
/* 1738 */       if (nodeA.isInSurface() || nodeB.isInSurface() || nodeC.isInSurface()) {
/* 1739 */         faceList.add(meshFacei);
/*      */       }
/*      */     } 
/* 1742 */     mfi = faceList.iterator();
/* 1743 */     while (mfi.hasNext()) {
/* 1744 */       TetMesh.Face meshFacei = mfi.next();
/* 1745 */       this._faceSet.remove(meshFacei);
/*      */     } 
/*      */ 
/*      */     
/* 1749 */     trace("  surf: more faces = " + ((countFaces() > nface) ? 1 : 0));
/* 1750 */     return (countFaces() > nface);
/*      */   }
/*      */   
/*      */   private static boolean nodesInOrder(Face face, Node na, Node nb, Node nc) {
/* 1754 */     Node fa = face.nodeA();
/* 1755 */     Node fb = face.nodeB();
/* 1756 */     Node fc = face.nodeC();
/* 1757 */     return ((na == fa && nb == fb && nc == fc) || (na == fb && nb == fc && nc == fa) || (na == fc && nb == fa && nc == fb));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Node otherNode(Face face, Node na, Node nb) {
/* 1763 */     Node fa = face.nodeA();
/* 1764 */     Node fb = face.nodeB();
/* 1765 */     Node fc = face.nodeC();
/* 1766 */     if (na == fa) {
/* 1767 */       if (nb == fb)
/* 1768 */         return fc; 
/* 1769 */       if (nb == fc) {
/* 1770 */         return fb;
/*      */       }
/* 1772 */       return null;
/*      */     } 
/* 1774 */     if (na == fb) {
/* 1775 */       if (nb == fa)
/* 1776 */         return fc; 
/* 1777 */       if (nb == fc) {
/* 1778 */         return fa;
/*      */       }
/* 1780 */       return null;
/*      */     } 
/* 1782 */     if (na == fc) {
/* 1783 */       if (nb == fa)
/* 1784 */         return fb; 
/* 1785 */       if (nb == fb) {
/* 1786 */         return fa;
/*      */       }
/* 1788 */       return null;
/*      */     } 
/*      */     
/* 1791 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static TetMesh.Node otherNode(TetMesh.Face face, TetMesh.Node na, TetMesh.Node nb) {
/* 1798 */     TetMesh.Node fa = face.nodeA();
/* 1799 */     TetMesh.Node fb = face.nodeB();
/* 1800 */     TetMesh.Node fc = face.nodeC();
/* 1801 */     if (na == fa) {
/* 1802 */       if (nb == fb)
/* 1803 */         return fc; 
/* 1804 */       if (nb == fc) {
/* 1805 */         return fb;
/*      */       }
/* 1807 */       return null;
/*      */     } 
/* 1809 */     if (na == fb) {
/* 1810 */       if (nb == fa)
/* 1811 */         return fc; 
/* 1812 */       if (nb == fc) {
/* 1813 */         return fa;
/*      */       }
/* 1815 */       return null;
/*      */     } 
/* 1817 */     if (na == fc) {
/* 1818 */       if (nb == fa)
/* 1819 */         return fb; 
/* 1820 */       if (nb == fb) {
/* 1821 */         return fa;
/*      */       }
/* 1823 */       return null;
/*      */     } 
/*      */     
/* 1826 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void linkFaces(Face face, Node node, Face faceNabor, Node nodeNabor) {
/* 1833 */     if (face != null) {
/* 1834 */       if (node == face.nodeA()) {
/* 1835 */         face._faceA = faceNabor;
/* 1836 */       } else if (node == face.nodeB()) {
/* 1837 */         face._faceB = faceNabor;
/* 1838 */       } else if (node == face.nodeC()) {
/* 1839 */         face._faceC = faceNabor;
/*      */       } else {
/* 1841 */         assert false : "node referenced by face";
/*      */       } 
/*      */     }
/* 1844 */     if (faceNabor != null) {
/* 1845 */       if (nodeNabor == faceNabor.nodeA()) {
/* 1846 */         faceNabor._faceA = face;
/* 1847 */       } else if (nodeNabor == faceNabor.nodeB()) {
/* 1848 */         faceNabor._faceB = face;
/* 1849 */       } else if (nodeNabor == faceNabor.nodeC()) {
/* 1850 */         faceNabor._faceC = face;
/*      */       } else {
/* 1852 */         assert false : "nodeNabor referenced by faceNabor";
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static float normalVector(TetMesh.Face meshFace, float[] v) {
/* 1858 */     TetMesh.Node na = meshFace.nodeA();
/* 1859 */     TetMesh.Node nb = meshFace.nodeB();
/* 1860 */     TetMesh.Node nc = meshFace.nodeC();
/* 1861 */     double xa = na.x();
/* 1862 */     double ya = na.y();
/* 1863 */     double za = na.z();
/* 1864 */     double xb = nb.x();
/* 1865 */     double yb = nb.y();
/* 1866 */     double zb = nb.z();
/* 1867 */     double xc = nc.x();
/* 1868 */     double yc = nc.y();
/* 1869 */     double zc = nc.z();
/* 1870 */     double x0 = xc - xa;
/* 1871 */     double y0 = yc - ya;
/* 1872 */     double z0 = zc - za;
/* 1873 */     double x1 = xa - xb;
/* 1874 */     double y1 = ya - yb;
/* 1875 */     double z1 = za - zb;
/* 1876 */     double x2 = y0 * z1 - y1 * z0;
/* 1877 */     double y2 = x1 * z0 - x0 * z1;
/* 1878 */     double z2 = x0 * y1 - x1 * y0;
/* 1879 */     double alpha = x2 * x2 + y2 * y2 + z2 * z2;
/* 1880 */     double delta = Math.sqrt(alpha);
/* 1881 */     double scale = (delta > 0.0D) ? (1.0D / delta) : 1.0D;
/* 1882 */     if (v != null) {
/* 1883 */       v[0] = (float)(x2 * scale);
/* 1884 */       v[1] = (float)(y2 * scale);
/* 1885 */       v[2] = (float)(z2 * scale);
/*      */     } 
/* 1887 */     return (float)(0.5D * scale * alpha);
/*      */   }
/*      */   
/*      */   static double normalVector(TetMesh.Face meshFace, double[] v) {
/* 1891 */     TetMesh.Node na = meshFace.nodeA();
/* 1892 */     TetMesh.Node nb = meshFace.nodeB();
/* 1893 */     TetMesh.Node nc = meshFace.nodeC();
/* 1894 */     double xa = na.x();
/* 1895 */     double ya = na.y();
/* 1896 */     double za = na.z();
/* 1897 */     double xb = nb.x();
/* 1898 */     double yb = nb.y();
/* 1899 */     double zb = nb.z();
/* 1900 */     double xc = nc.x();
/* 1901 */     double yc = nc.y();
/* 1902 */     double zc = nc.z();
/* 1903 */     double x0 = xc - xa;
/* 1904 */     double y0 = yc - ya;
/* 1905 */     double z0 = zc - za;
/* 1906 */     double x1 = xa - xb;
/* 1907 */     double y1 = ya - yb;
/* 1908 */     double z1 = za - zb;
/* 1909 */     double x2 = y0 * z1 - y1 * z0;
/* 1910 */     double y2 = x1 * z0 - x0 * z1;
/* 1911 */     double z2 = x0 * y1 - x1 * y0;
/* 1912 */     double alpha = x2 * x2 + y2 * y2 + z2 * z2;
/* 1913 */     double delta = Math.sqrt(alpha);
/* 1914 */     double scale = (delta > 0.0D) ? (1.0D / delta) : 1.0D;
/* 1915 */     if (v != null) {
/* 1916 */       v[0] = x2 * scale;
/* 1917 */       v[1] = y2 * scale;
/* 1918 */       v[2] = z2 * scale;
/*      */     } 
/* 1920 */     return 0.5D * scale * alpha;
/*      */   }
/*      */   
/*      */   private static double angle(TetMesh.Face face1, TetMesh.Face face2) {
/* 1924 */     double[] v1 = new double[3];
/* 1925 */     double[] v2 = new double[3];
/* 1926 */     normalVector(face1, v1);
/* 1927 */     normalVector(face2, v2);
/* 1928 */     double cos12 = v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
/* 1929 */     return Math.acos(cos12);
/*      */   }
/*      */   
/*      */   private TetMesh.Edge findMeshEdge(Node nodeA, Node nodeB) {
/* 1933 */     TetMesh.Node meshNodeA = nodeA._meshNode;
/* 1934 */     TetMesh.Node meshNodeB = nodeB._meshNode;
/* 1935 */     TetMesh.Edge meshEdge = this._mesh.findEdge(meshNodeA, meshNodeB);
/* 1936 */     if (meshEdge != null && meshNodeA != meshEdge.nodeA())
/* 1937 */       meshEdge = meshEdge.mate(); 
/* 1938 */     return meshEdge;
/*      */   }
/*      */   
/*      */   private Edge makeEdge(Node nodeA, Node nodeB, Face face) {
/* 1942 */     TetMesh.Edge meshEdge = findMeshEdge(nodeA, nodeB);
/* 1943 */     return (meshEdge != null) ? new Edge(meshEdge, face) : null;
/*      */   }
/*      */   
/* 1946 */   private static final double VV_SLIVER = Math.cos(2.6179938779914944D);
/* 1947 */   private static final double VV_LARGE = Math.cos(1.7278759594743864D);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean TRACE = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EdgeFace makeEdgeFace(Edge edge) {
/* 1959 */     assert edge.isOnBoundary();
/* 1960 */     Node nodeA = edge.nodeA();
/* 1961 */     Node nodeB = edge.nodeB();
/*      */ 
/*      */     
/* 1964 */     TetMesh.Face meshFace = (edge.faceRight())._meshFace;
/*      */ 
/*      */     
/* 1967 */     double[] v = new double[3];
/* 1968 */     normalVector(meshFace, v);
/*      */ 
/*      */     
/* 1971 */     TetMesh.Edge meshEdge = edge._meshEdge;
/* 1972 */     TetMesh.Node meshNodeA = meshEdge.nodeA();
/* 1973 */     TetMesh.Node meshNodeB = meshEdge.nodeB();
/*      */ 
/*      */     
/* 1976 */     double[] cc = new double[3];
/* 1977 */     double[] vi = new double[3];
/* 1978 */     double rrBest = Double.MAX_VALUE;
/* 1979 */     double vvBest = -1.0D;
/* 1980 */     TetMesh.Face mfBest = null;
/* 1981 */     TetMesh.Face mfMate = meshFace.mate();
/*      */ 
/*      */ 
/*      */     
/* 1985 */     TetMesh.Face[] meshFaces = this._mesh.getFaceNabors(meshEdge);
/* 1986 */     int n = meshFaces.length;
/*      */ 
/*      */     
/* 1989 */     for (int i = 0; i < n; i++) {
/* 1990 */       TetMesh.Face mf = meshFaces[i];
/*      */ 
/*      */       
/* 1993 */       if (!mf.equals(mfMate)) {
/*      */         Node nodeC;
/*      */ 
/*      */         
/* 1997 */         TetMesh.Node fa = mf.nodeA();
/* 1998 */         TetMesh.Node fb = mf.nodeB();
/* 1999 */         TetMesh.Node fc = mf.nodeC();
/*      */         
/* 2001 */         if (fc == meshNodeA) {
/* 2002 */           nodeC = (Node)fb.data;
/* 2003 */         } else if (fc == meshNodeB) {
/* 2004 */           nodeC = (Node)fa.data;
/*      */         } else {
/* 2006 */           nodeC = (Node)fc.data;
/*      */         } 
/*      */ 
/*      */         
/* 2010 */         if (validForFace(nodeA, nodeB, nodeC)) {
/*      */ 
/*      */           
/* 2013 */           normalVector(mf, vi);
/*      */ 
/*      */           
/* 2016 */           double vv = v[0] * vi[0] + v[1] * vi[1] + v[2] * vi[2];
/*      */ 
/*      */           
/* 2019 */           if (vv > VV_SLIVER) {
/*      */ 
/*      */             
/* 2022 */             double rr = mf.centerCircle(cc);
/*      */ 
/*      */             
/* 2025 */             if (rr < rrBest) {
/* 2026 */               rrBest = rr;
/* 2027 */               vvBest = vv;
/* 2028 */               mfBest = mf;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2037 */     assert !this._faceMap.containsKey(mfBest) && !this._faceMap.containsKey(mfBest);
/* 2038 */     Face face = (mfBest != null) ? new Face(mfBest) : null;
/* 2039 */     double grade = (vvBest > VV_LARGE) ? (1.0D / rrBest) : (vvBest - 1.0D);
/* 2040 */     if (grade <= 0.0D)
/* 2041 */       face = null; 
/* 2042 */     return new EdgeFace(edge, face, grade);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasInternalEdge(Node nodeA, Node nodeB) {
/* 2050 */     Face face = findFace(nodeA, nodeB);
/* 2051 */     if (face == null)
/* 2052 */       return false; 
/* 2053 */     face = face.faceNabor(otherNode(face, nodeA, nodeB));
/* 2054 */     if (face == null)
/* 2055 */       return false; 
/* 2056 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean validForFace(Node nodeA, Node nodeB, Node nodeC) {
/* 2065 */     return (!nodeC.isInSurface() || (nodeC.isOnBoundary() && !hasInternalEdge(nodeB, nodeC) && !hasInternalEdge(nodeC, nodeA)));
/*      */   }
/*      */   
/*      */   private static void trace(String s) {}
/*      */   
/*      */   public static interface FaceIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriSurf.Face next();
/*      */   }
/*      */   
/*      */   public static interface EdgeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriSurf.Edge next();
/*      */   }
/*      */   
/*      */   public static interface NodeIterator {
/*      */     boolean hasNext();
/*      */     
/*      */     TriSurf.Node next();
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/TriSurf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */