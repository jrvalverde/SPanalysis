/*    */ package edu.mines.jtk.mosaic.test;
/*    */ 
/*    */ import edu.mines.jtk.mosaic.Mosaic;
/*    */ import edu.mines.jtk.mosaic.PointsView;
/*    */ import edu.mines.jtk.mosaic.TileZoomMode;
/*    */ import edu.mines.jtk.mosaic.TiledView;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Font;
/*    */ import java.util.EnumSet;
/*    */ import java.util.Set;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MosaicTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 28 */     SwingUtilities.invokeLater(new Runnable() {
/*    */           public void run() {
/* 30 */             MosaicTest.go();
/*    */           }
/*    */         });
/*    */   }
/*    */   private static void go() {
/* 35 */     int nrow = 2;
/* 36 */     int ncol = 3;
/* 37 */     Set<Mosaic.AxesPlacement> axesPlacement = EnumSet.of(Mosaic.AxesPlacement.TOP, Mosaic.AxesPlacement.LEFT, Mosaic.AxesPlacement.BOTTOM, Mosaic.AxesPlacement.RIGHT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 43 */     float[] x1 = { 0.0F, 1.0F };
/* 44 */     float[] x2 = { 0.0F, 1.0F };
/* 45 */     Mosaic mosaic = new Mosaic(nrow, ncol, axesPlacement);
/* 46 */     mosaic.setBackground(Color.WHITE);
/* 47 */     mosaic.setFont(new Font("SansSerif", 0, 12));
/* 48 */     mosaic.setWidthMinimum(1, 200);
/* 49 */     mosaic.setWidthElastic(1, 200);
/* 50 */     mosaic.setHeightElastic(0, 0);
/* 51 */     for (int irow = 0; irow < nrow; irow++) {
/* 52 */       for (int icol = 0; icol < ncol; icol++) {
/* 53 */         mosaic.getTile(irow, icol).addTiledView((TiledView)new PointsView(x1, x2));
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 59 */     mosaic.getTileAxisTop(0).setLabel("axis label");
/* 60 */     mosaic.getTileAxisTop(1).setLabel("axis label");
/* 61 */     mosaic.getTileAxisTop(2).setLabel("axis label");
/* 62 */     mosaic.getTileAxisLeft(0).setLabel("axis label");
/* 63 */     mosaic.getTileAxisLeft(1).setLabel("axis label");
/* 64 */     mosaic.getTileAxisBottom(0).setLabel("axis label");
/* 65 */     mosaic.getTileAxisBottom(1).setLabel("axis label");
/* 66 */     mosaic.getTileAxisBottom(2).setLabel("axis label");
/* 67 */     mosaic.getTileAxisRight(0).setLabel("axis label");
/* 68 */     mosaic.getTileAxisRight(1).setLabel("axis label");
/*    */     
/* 70 */     TileZoomMode zoomMode = new TileZoomMode(mosaic.getModeManager());
/* 71 */     zoomMode.setActive(true);
/*    */     
/* 73 */     JFrame frame = new JFrame();
/* 74 */     frame.setDefaultCloseOperation(3);
/* 75 */     frame.add((Component)mosaic, "Center");
/* 76 */     frame.setSize(600, 500);
/* 77 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/MosaicTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */