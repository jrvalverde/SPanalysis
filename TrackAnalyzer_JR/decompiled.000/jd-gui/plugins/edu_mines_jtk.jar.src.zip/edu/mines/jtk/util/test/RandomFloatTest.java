/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.RandomFloat;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomFloatTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 24 */     if (args.length > 0 && args[0].equals("bench"))
/* 25 */       bench(); 
/* 26 */     TestSuite suite = new TestSuite(RandomFloatTest.class);
/* 27 */     TestRunner.run((Test)suite);
/*    */   }
/*    */ 
/*    */   
/*    */   public void testNothing() {}
/*    */   
/*    */   public static void bench() {
/* 34 */     Random r = new Random();
/* 35 */     RandomFloat rf = new RandomFloat();
/* 36 */     Stopwatch sw = new Stopwatch();
/*    */ 
/*    */ 
/*    */     
/* 40 */     for (int ntrial = 0; ntrial < 3; ntrial++) {
/*    */       
/* 42 */       System.out.println();
/* 43 */       System.out.println("java.util.Random:");
/* 44 */       sw.restart();
/* 45 */       float sum = 0.0F; int nf;
/* 46 */       for (nf = 0; sw.time() < 1.0D; nf++)
/* 47 */         sum += r.nextFloat(); 
/* 48 */       sw.stop();
/* 49 */       double rate = nf / sw.time();
/* 50 */       System.out.println("  uniform: float/s=" + rate + " sum=" + sum);
/* 51 */       sw.restart();
/* 52 */       sum = 0.0F;
/* 53 */       for (nf = 0; sw.time() < 1.0D; nf++)
/* 54 */         sum += (float)r.nextGaussian(); 
/* 55 */       sw.stop();
/* 56 */       rate = nf / sw.time();
/* 57 */       System.out.println("   normal: float/s=" + rate + " sum=" + sum);
/*    */       
/* 59 */       System.out.println();
/* 60 */       System.out.println("edu.mines.jtk.util.RandomFloat:");
/* 61 */       sw.restart();
/* 62 */       sum = 0.0F;
/* 63 */       for (nf = 0; sw.time() < 1.0D; nf++)
/* 64 */         sum += rf.uniform(); 
/* 65 */       sw.stop();
/* 66 */       rate = nf / sw.time();
/* 67 */       System.out.println("  uniform: float/s=" + rate + " sum=" + sum);
/* 68 */       sw.restart();
/* 69 */       sum = 0.0F;
/* 70 */       for (nf = 0; sw.time() < 1.0D; nf++)
/* 71 */         sum += rf.normal(); 
/* 72 */       sw.stop();
/* 73 */       rate = nf / sw.time();
/* 74 */       System.out.println("   normal: float/s=" + rate + " sum=" + sum);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/RandomFloatTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */