/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArrayStack<E>
/*    */ {
/*    */   public E push(E e) {
/* 19 */     this._list.add(e);
/* 20 */     return e;
/*    */   }
/*    */   
/*    */   public E pop() {
/* 24 */     return this._list.remove(this._list.size() - 1);
/*    */   }
/*    */   
/*    */   public E peek() {
/* 28 */     return this._list.get(this._list.size() - 1);
/*    */   }
/*    */   
/*    */   public E get(int index) {
/* 32 */     return this._list.get(index);
/*    */   }
/*    */   
/*    */   public int size() {
/* 36 */     return this._list.size();
/*    */   }
/*    */   
/* 39 */   private ArrayList<E> _list = new ArrayList<E>();
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/ArrayStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */