/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MinimumPhaseFilter
/*      */ {
/*      */   private int _m;
/*      */   private int _min1;
/*      */   private int _max1;
/*      */   private int _min2;
/*      */   private int _max2;
/*      */   private int _min3;
/*      */   private int _max3;
/*      */   private int[] _lag1;
/*      */   private int[] _lag2;
/*      */   private int[] _lag3;
/*      */   private float[] _a;
/*      */   private float _a0;
/*      */   private float _a0i;
/*      */   private int _ni;
/*      */   private float[][] _ai;
/*      */   private float[] _ai0;
/*      */   private float[] _ai0i;
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1) {
/*   43 */     this(lag1, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, int[] lag2) {
/*   57 */     this(lag1, lag2, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, int[] lag2, int[] lag3) {
/*   72 */     this(lag1, lag2, lag3, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, float[] a) {
/*   85 */     initLags(lag1, a);
/*   86 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, int[] lag2, float[] a) {
/*  101 */     initLags(lag1, lag2, a);
/*  102 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, int[] lag2, float[][] a) {
/*  117 */     initLags(lag1, lag2, a[0]);
/*  118 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MinimumPhaseFilter(int[] lag1, int[] lag2, int[] lag3, float[] a) {
/*  134 */     initLags(lag1, lag2, lag3, a);
/*  135 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag1() {
/*  143 */     return Array.copy(this._lag1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag2() {
/*  151 */     return Array.copy(this._lag2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag3() {
/*  159 */     return Array.copy(this._lag3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getA() {
/*  167 */     return Array.copy(this._a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[] r) {
/*  186 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  189 */     int m1 = this._max1 - this._min1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     int n1 = r.length + 10 * m1;
/*      */ 
/*      */     
/*  199 */     int l1 = (r.length - 1) / 2;
/*  200 */     int k1 = n1 - 1 - this._max1;
/*      */ 
/*      */     
/*  203 */     float[] s = new float[n1];
/*  204 */     float[] t = new float[n1];
/*  205 */     float[] u = new float[n1];
/*      */ 
/*      */     
/*  208 */     Array.copy(r.length, 0, r, k1 - l1, s);
/*      */ 
/*      */     
/*  211 */     Array.zero(this._a);
/*  212 */     this._a[0] = MathPlus.sqrt(s[k1]);
/*  213 */     this._a0 = this._a[0];
/*  214 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  218 */     boolean converged = false;
/*  219 */     float eemax = s[k1] * epsilon;
/*  220 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  224 */       applyInverseTranspose(s, t);
/*  225 */       applyInverse(t, u);
/*  226 */       u[k1] = u[k1] + 1.0F;
/*      */ 
/*      */       
/*  229 */       u[k1] = u[k1] * 0.5F;
/*  230 */       for (int i1 = 0; i1 < k1; i1++) {
/*  231 */         u[i1] = 0.0F;
/*      */       }
/*      */       
/*  234 */       apply(u, t);
/*  235 */       converged = true;
/*  236 */       for (int j = 0; j < this._m; j++) {
/*  237 */         int j1 = k1 + this._lag1[j];
/*  238 */         if (0 <= j1 && j1 < n1) {
/*  239 */           float aj = t[j1];
/*  240 */           if (converged) {
/*  241 */             float e = this._a[j] - aj;
/*  242 */             converged = (e * e <= eemax);
/*      */           } 
/*  244 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  247 */       this._a0 = this._a[0];
/*  248 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  250 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[][] r) {
/*  269 */     Check.argument(((r[0]).length % 2 == 1), "r[0].length is odd");
/*  270 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  273 */     int m1 = this._max1 - this._min1;
/*  274 */     int m2 = this._max2 - this._min2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  281 */     int n1 = (r[0]).length + 10 * m1;
/*  282 */     int n2 = r.length + 10 * m2;
/*      */ 
/*      */     
/*  285 */     int l1 = ((r[0]).length - 1) / 2;
/*  286 */     int l2 = (r.length - 1) / 2;
/*  287 */     int k1 = n1 - 1 - this._max1;
/*  288 */     int k2 = n2 - 1 - this._max2;
/*      */ 
/*      */     
/*  291 */     float[][] s = new float[n2][n1];
/*  292 */     float[][] t = new float[n2][n1];
/*  293 */     float[][] u = new float[n2][n1];
/*      */ 
/*      */     
/*  296 */     Array.copy((r[0]).length, r.length, 0, 0, r, k1 - l1, k2 - l2, s);
/*      */ 
/*      */     
/*  299 */     Array.zero(this._a);
/*  300 */     this._a[0] = MathPlus.sqrt(s[k2][k1]);
/*  301 */     this._a0 = this._a[0];
/*  302 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  306 */     boolean converged = false;
/*  307 */     float eemax = s[k2][k1] * epsilon;
/*  308 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  312 */       applyInverseTranspose(s, t);
/*  313 */       applyInverse(t, u);
/*  314 */       u[k2][k1] = u[k2][k1] + 1.0F;
/*      */ 
/*      */       
/*  317 */       u[k2][k1] = u[k2][k1] * 0.5F;
/*  318 */       for (int i2 = 0; i2 < k2; i2++) {
/*  319 */         for (int i = 0; i < n1; i++)
/*  320 */           u[i2][i] = 0.0F; 
/*  321 */       }  for (int i1 = 0; i1 < k1; i1++) {
/*  322 */         u[k2][i1] = 0.0F;
/*      */       }
/*      */       
/*  325 */       apply(u, t);
/*  326 */       converged = true;
/*  327 */       for (int j = 0; j < this._m; j++) {
/*  328 */         int j1 = k1 + this._lag1[j];
/*  329 */         int j2 = k2 + this._lag2[j];
/*  330 */         if (0 <= j1 && j1 < n1 && 0 <= j2 && j2 < n2) {
/*  331 */           float aj = t[j2][j1];
/*  332 */           if (converged) {
/*  333 */             float e = this._a[j] - aj;
/*  334 */             converged = (e * e <= eemax);
/*      */           } 
/*  336 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  339 */       this._a0 = this._a[0];
/*  340 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  342 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[][][] r) {
/*  361 */     Check.argument(((r[0][0]).length % 2 == 1), "r[0][0].length is odd");
/*  362 */     Check.argument(((r[0]).length % 2 == 1), "r[0].length is odd");
/*  363 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  366 */     int m1 = this._max1 - this._min1;
/*  367 */     int m2 = this._max2 - this._min2;
/*  368 */     int m3 = this._max3 - this._min3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  375 */     int n1 = (r[0][0]).length + 10 * m1;
/*  376 */     int n2 = (r[0]).length + 10 * m2;
/*  377 */     int n3 = r.length + 10 * m3;
/*      */ 
/*      */     
/*  380 */     int l1 = ((r[0][0]).length - 1) / 2;
/*  381 */     int l2 = ((r[0]).length - 1) / 2;
/*  382 */     int l3 = (r.length - 1) / 2;
/*  383 */     int k1 = n1 - 1 - this._max1;
/*  384 */     int k2 = n2 - 1 - this._max2;
/*  385 */     int k3 = n3 - 1 - this._max3;
/*      */ 
/*      */     
/*  388 */     float[][][] s = new float[n3][n2][n1];
/*  389 */     float[][][] t = new float[n3][n2][n1];
/*  390 */     float[][][] u = new float[n3][n2][n1];
/*      */ 
/*      */     
/*  393 */     Array.copy((r[0][0]).length, (r[0]).length, r.length, 0, 0, 0, r, k1 - l1, k2 - l2, k3 - l3, s);
/*      */ 
/*      */     
/*  396 */     Array.zero(this._a);
/*  397 */     this._a[0] = MathPlus.sqrt(s[k3][k2][k1]);
/*  398 */     this._a0 = this._a[0];
/*  399 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  403 */     boolean converged = false;
/*  404 */     float eemax = s[k3][k2][k1] * epsilon;
/*  405 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  409 */       applyInverseTranspose(s, t);
/*  410 */       applyInverse(t, u);
/*  411 */       u[k3][k2][k1] = u[k3][k2][k1] + 1.0F;
/*      */ 
/*      */       
/*  414 */       u[k3][k2][k1] = u[k3][k2][k1] * 0.5F;
/*  415 */       for (int i3 = 0; i3 < k3; i3++) {
/*  416 */         for (int i = 0; i < n2; i++)
/*  417 */         { for (int k = 0; k < n1; k++)
/*  418 */             u[i3][i][k] = 0.0F;  } 
/*  419 */       }  for (int i2 = 0; i2 < k2; i2++) {
/*  420 */         for (int i = 0; i < n1; i++)
/*  421 */           u[k3][i2][i] = 0.0F; 
/*  422 */       }  for (int i1 = 0; i1 < k1; i1++) {
/*  423 */         u[k3][k2][i1] = 0.0F;
/*      */       }
/*      */       
/*  426 */       apply(u, t);
/*  427 */       converged = true;
/*  428 */       for (int j = 0; j < this._m; j++) {
/*  429 */         int j1 = k1 + this._lag1[j];
/*  430 */         int j2 = k2 + this._lag2[j];
/*  431 */         int j3 = k3 + this._lag3[j];
/*  432 */         if (0 <= j1 && j1 < n1 && 0 <= j2 && j2 < n2 && 0 <= j3 && j3 < n3) {
/*  433 */           float aj = t[j3][j2][j1];
/*  434 */           if (converged) {
/*  435 */             float e = this._a[j] - aj;
/*  436 */             converged = (e * e <= eemax);
/*      */           } 
/*  438 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  441 */       this._a0 = this._a[0];
/*  442 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  444 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[] x, float[] y) {
/*  453 */     int n1 = y.length;
/*  454 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  455 */     for (i1 = 0; i1 < i1lo; i1++) {
/*  456 */       float yi = this._a0 * x[i1];
/*  457 */       for (int j = 1; j < this._m; j++) {
/*  458 */         int k1 = i1 - this._lag1[j];
/*  459 */         if (0 <= k1)
/*  460 */           yi += this._a[j] * x[k1]; 
/*      */       } 
/*  462 */       y[i1] = yi;
/*      */     } 
/*  464 */     for (i1 = i1lo; i1 < n1; i1++) {
/*  465 */       float yi = this._a0 * x[i1];
/*  466 */       for (int j = 1; j < this._m; j++) {
/*  467 */         int k1 = i1 - this._lag1[j];
/*  468 */         yi += this._a[j] * x[k1];
/*      */       } 
/*  470 */       y[i1] = yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[][] x, float[][] y) {
/*  480 */     int n1 = (y[0]).length;
/*  481 */     int n2 = y.length;
/*  482 */     int i1lo = MathPlus.max(0, this._max1);
/*  483 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  484 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  485 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  486 */       for (int i1 = 0; i1 < n1; i1++) {
/*  487 */         float yi = this._a0 * x[i2][i1];
/*  488 */         for (int j = 1; j < this._m; j++) {
/*  489 */           int k1 = i1 - this._lag1[j];
/*  490 */           int k2 = i2 - this._lag2[j];
/*  491 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  492 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  494 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  497 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  498 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  499 */         float yi = this._a0 * x[i2][i1];
/*  500 */         for (int j = 1; j < this._m; j++) {
/*  501 */           int k1 = i1 - this._lag1[j];
/*  502 */           int k2 = i2 - this._lag2[j];
/*  503 */           if (0 <= k1)
/*  504 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  506 */         y[i2][i1] = yi;
/*      */       } 
/*  508 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  509 */         float yi = this._a0 * x[i2][i1];
/*  510 */         for (int j = 1; j < this._m; j++) {
/*  511 */           int k1 = i1 - this._lag1[j];
/*  512 */           int k2 = i2 - this._lag2[j];
/*  513 */           yi += this._a[j] * x[k2][k1];
/*      */         } 
/*  515 */         y[i2][i1] = yi;
/*      */       } 
/*  517 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  518 */         float yi = this._a0 * x[i2][i1];
/*  519 */         for (int j = 1; j < this._m; j++) {
/*  520 */           int k1 = i1 - this._lag1[j];
/*  521 */           int k2 = i2 - this._lag2[j];
/*  522 */           if (k1 < n1)
/*  523 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  525 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[][][] x, float[][][] y) {
/*  536 */     int n1 = (y[0][0]).length;
/*  537 */     int n2 = (y[0]).length;
/*  538 */     int n3 = y.length;
/*  539 */     int i1lo = MathPlus.max(0, this._max1);
/*  540 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  541 */     int i2lo = MathPlus.max(0, this._max2);
/*  542 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  543 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  544 */     for (i3 = 0; i3 < i3lo; i3++) {
/*  545 */       for (int i2 = 0; i2 < n2; i2++) {
/*  546 */         for (int i1 = 0; i1 < n1; i1++) {
/*  547 */           float yi = this._a0 * x[i3][i2][i1];
/*  548 */           for (int j = 1; j < this._m; j++) {
/*  549 */             int k1 = i1 - this._lag1[j];
/*  550 */             int k2 = i2 - this._lag2[j];
/*  551 */             int k3 = i3 - this._lag3[j];
/*  552 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/*  553 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  555 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*  559 */     for (i3 = i3lo; i3 < n3; i3++) {
/*  560 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/*  561 */         for (int i1 = 0; i1 < n1; i1++) {
/*  562 */           float yi = this._a0 * x[i3][i2][i1];
/*  563 */           for (int j = 1; j < this._m; j++) {
/*  564 */             int k1 = i1 - this._lag1[j];
/*  565 */             int k2 = i2 - this._lag2[j];
/*  566 */             int k3 = i3 - this._lag3[j];
/*  567 */             if (0 <= k2 && 0 <= k1 && k1 < n1)
/*  568 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  570 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  573 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/*  574 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  575 */           float yi = this._a0 * x[i3][i2][i1];
/*  576 */           for (int j = 1; j < this._m; j++) {
/*  577 */             int k1 = i1 - this._lag1[j];
/*  578 */             int k2 = i2 - this._lag2[j];
/*  579 */             int k3 = i3 - this._lag3[j];
/*  580 */             if (0 <= k1)
/*  581 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  583 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  585 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/*  586 */           float yi = this._a0 * x[i3][i2][i1];
/*  587 */           for (int j = 1; j < this._m; j++) {
/*  588 */             int k1 = i1 - this._lag1[j];
/*  589 */             int k2 = i2 - this._lag2[j];
/*  590 */             int k3 = i3 - this._lag3[j];
/*  591 */             yi += this._a[j] * x[k3][k2][k1];
/*      */           } 
/*  593 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  595 */         for (i1 = i1hi; i1 < n1; i1++) {
/*  596 */           float yi = this._a0 * x[i3][i2][i1];
/*  597 */           for (int j = 1; j < this._m; j++) {
/*  598 */             int k1 = i1 - this._lag1[j];
/*  599 */             int k2 = i2 - this._lag2[j];
/*  600 */             int k3 = i3 - this._lag3[j];
/*  601 */             if (k1 < n1)
/*  602 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  604 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  607 */       for (i2 = i2hi; i2 < n2; i2++) {
/*  608 */         for (int i1 = 0; i1 < n1; i1++) {
/*  609 */           float yi = this._a0 * x[i3][i2][i1];
/*  610 */           for (int j = 1; j < this._m; j++) {
/*  611 */             int k1 = i1 - this._lag1[j];
/*  612 */             int k2 = i2 - this._lag2[j];
/*  613 */             int k3 = i3 - this._lag3[j];
/*  614 */             if (k2 < n2 && 0 <= k1 && k1 < n1)
/*  615 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  617 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(int[][] i, float[][] x, float[][] y) {
/*  630 */     int n1 = (y[0]).length;
/*  631 */     int n2 = y.length;
/*  632 */     int i1lo = MathPlus.max(0, this._max1);
/*  633 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  634 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  635 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  636 */       for (int i1 = 0; i1 < n1; i1++) {
/*  637 */         int ii = i[i2][i1];
/*  638 */         float[] aii = this._ai[ii];
/*  639 */         float yi = this._ai0[ii] * x[i2][i1];
/*  640 */         for (int j = 1; j < this._m; j++) {
/*  641 */           int k1 = i1 - this._lag1[j];
/*  642 */           int k2 = i2 - this._lag2[j];
/*  643 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  644 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  646 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  649 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  650 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  651 */         int ii = i[i2][i1];
/*  652 */         float[] aii = this._ai[ii];
/*  653 */         float yi = this._ai0[ii] * x[i2][i1];
/*  654 */         for (int j = 1; j < this._m; j++) {
/*  655 */           int k1 = i1 - this._lag1[j];
/*  656 */           int k2 = i2 - this._lag2[j];
/*  657 */           if (0 <= k1)
/*  658 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  660 */         y[i2][i1] = yi;
/*      */       } 
/*  662 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  663 */         int ii = i[i2][i1];
/*  664 */         float[] aii = this._ai[ii];
/*  665 */         float yi = this._ai0[ii] * x[i2][i1];
/*  666 */         for (int j = 1; j < this._m; j++) {
/*  667 */           int k1 = i1 - this._lag1[j];
/*  668 */           int k2 = i2 - this._lag2[j];
/*  669 */           yi += aii[j] * x[k2][k1];
/*      */         } 
/*  671 */         y[i2][i1] = yi;
/*      */       } 
/*  673 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  674 */         int ii = i[i2][i1];
/*  675 */         float[] aii = this._ai[ii];
/*  676 */         float yi = this._ai0[ii] * x[i2][i1];
/*  677 */         for (int j = 1; j < this._m; j++) {
/*  678 */           int k1 = i1 - this._lag1[j];
/*  679 */           int k2 = i2 - this._lag2[j];
/*  680 */           if (k1 < n1)
/*  681 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  683 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[] x, float[] y) {
/*  698 */     int n1 = y.length;
/*  699 */     int i1hi = MathPlus.max(n1 - this._max1, 0); int i1;
/*  700 */     for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  701 */       float yi = this._a0 * x[i1];
/*  702 */       for (int j = 1; j < this._m; j++) {
/*  703 */         int k1 = i1 + this._lag1[j];
/*  704 */         if (k1 < n1)
/*  705 */           yi += this._a[j] * x[k1]; 
/*      */       } 
/*  707 */       y[i1] = yi;
/*      */     } 
/*  709 */     for (i1 = i1hi - 1; i1 >= 0; i1--) {
/*  710 */       float yi = this._a0 * x[i1];
/*  711 */       for (int j = 1; j < this._m; j++) {
/*  712 */         int k1 = i1 + this._lag1[j];
/*  713 */         yi += this._a[j] * x[k1];
/*      */       } 
/*  715 */       y[i1] = yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[][] x, float[][] y) {
/*  726 */     int n1 = (y[0]).length;
/*  727 */     int n2 = y.length;
/*  728 */     int i1lo = MathPlus.max(0, -this._min1);
/*  729 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  730 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/*  731 */     for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  732 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  733 */         float yi = this._a0 * x[i2][i1];
/*  734 */         for (int j = 1; j < this._m; j++) {
/*  735 */           int k1 = i1 + this._lag1[j];
/*  736 */           int k2 = i2 + this._lag2[j];
/*  737 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/*  738 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  740 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  743 */     for (i2 = i2hi - 1; i2 >= 0; i2--) {
/*  744 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  745 */         float yi = this._a0 * x[i2][i1];
/*  746 */         for (int j = 1; j < this._m; j++) {
/*  747 */           int k1 = i1 + this._lag1[j];
/*  748 */           int k2 = i2 + this._lag2[j];
/*  749 */           if (k1 < n1)
/*  750 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  752 */         y[i2][i1] = yi;
/*      */       } 
/*  754 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  755 */         float yi = this._a0 * x[i2][i1];
/*  756 */         for (int j = 1; j < this._m; j++) {
/*  757 */           int k1 = i1 + this._lag1[j];
/*  758 */           int k2 = i2 + this._lag2[j];
/*  759 */           yi += this._a[j] * x[k2][k1];
/*      */         } 
/*  761 */         y[i2][i1] = yi;
/*      */       } 
/*  763 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  764 */         float yi = this._a0 * x[i2][i1];
/*  765 */         for (int j = 1; j < this._m; j++) {
/*  766 */           int k1 = i1 + this._lag1[j];
/*  767 */           int k2 = i2 + this._lag2[j];
/*  768 */           if (0 <= k1)
/*  769 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  771 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[][][] x, float[][][] y) {
/*  783 */     int n1 = (y[0][0]).length;
/*  784 */     int n2 = (y[0]).length;
/*  785 */     int n3 = y.length;
/*  786 */     int i1lo = MathPlus.max(0, -this._min1);
/*  787 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  788 */     int i2lo = MathPlus.max(0, -this._min2);
/*  789 */     int i2hi = MathPlus.min(n2, n2 - this._max2);
/*  790 */     int i3hi = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.max(n3 - this._max3, 0) : 0; int i3;
/*  791 */     for (i3 = n3 - 1; i3 >= i3hi; i3--) {
/*  792 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  793 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  794 */           float yi = this._a0 * x[i3][i2][i1];
/*  795 */           for (int j = 1; j < this._m; j++) {
/*  796 */             int k1 = i1 + this._lag1[j];
/*  797 */             int k2 = i2 + this._lag2[j];
/*  798 */             int k3 = i3 + this._lag3[j];
/*  799 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && k3 < n3)
/*  800 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  802 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*  806 */     for (i3 = i3hi - 1; i3 >= 0; i3--) {
/*  807 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  808 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  809 */           float yi = this._a0 * x[i3][i2][i1];
/*  810 */           for (int j = 1; j < this._m; j++) {
/*  811 */             int k1 = i1 + this._lag1[j];
/*  812 */             int k2 = i2 + this._lag2[j];
/*  813 */             int k3 = i3 + this._lag3[j];
/*  814 */             if (k2 < n2 && 0 <= k1 && k1 < n1)
/*  815 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  817 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  820 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/*  821 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  822 */           float yi = this._a0 * x[i3][i2][i1];
/*  823 */           for (int j = 1; j < this._m; j++) {
/*  824 */             int k1 = i1 + this._lag1[j];
/*  825 */             int k2 = i2 + this._lag2[j];
/*  826 */             int k3 = i3 + this._lag3[j];
/*  827 */             if (k1 < n1)
/*  828 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  830 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  832 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  833 */           float yi = this._a0 * x[i3][i2][i1];
/*  834 */           for (int j = 1; j < this._m; j++) {
/*  835 */             int k1 = i1 + this._lag1[j];
/*  836 */             int k2 = i2 + this._lag2[j];
/*  837 */             int k3 = i3 + this._lag3[j];
/*  838 */             yi += this._a[j] * x[k3][k2][k1];
/*      */           } 
/*  840 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  842 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  843 */           float yi = this._a0 * x[i3][i2][i1];
/*  844 */           for (int j = 1; j < this._m; j++) {
/*  845 */             int k1 = i1 + this._lag1[j];
/*  846 */             int k2 = i2 + this._lag2[j];
/*  847 */             int k3 = i3 + this._lag3[j];
/*  848 */             if (0 <= k1)
/*  849 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  851 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  854 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  855 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  856 */           float yi = this._a0 * x[i3][i2][i1];
/*  857 */           for (int j = 1; j < this._m; j++) {
/*  858 */             int k1 = i1 + this._lag1[j];
/*  859 */             int k2 = i2 + this._lag2[j];
/*  860 */             int k3 = i3 + this._lag3[j];
/*  861 */             if (0 <= k2 && 0 <= k1 && k1 < n1)
/*  862 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  864 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(int[][] i, float[][] x, float[][] y) {
/*  878 */     int n1 = (y[0]).length;
/*  879 */     int n2 = y.length;
/*  880 */     int i1lo = MathPlus.max(0, -this._min1);
/*  881 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  882 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/*  883 */     for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  884 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  885 */         int ii = i[i2][i1];
/*  886 */         float[] aii = this._ai[ii];
/*  887 */         float yi = this._ai0[ii] * x[i2][i1];
/*  888 */         for (int j = 1; j < this._m; j++) {
/*  889 */           int k1 = i1 + this._lag1[j];
/*  890 */           int k2 = i2 + this._lag2[j];
/*  891 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/*  892 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  894 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  897 */     for (i2 = i2hi - 1; i2 >= 0; i2--) {
/*  898 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  899 */         int ii = i[i2][i1];
/*  900 */         float[] aii = this._ai[ii];
/*  901 */         float yi = this._ai0[ii] * x[i2][i1];
/*  902 */         for (int j = 1; j < this._m; j++) {
/*  903 */           int k1 = i1 + this._lag1[j];
/*  904 */           int k2 = i2 + this._lag2[j];
/*  905 */           if (k1 < n1)
/*  906 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  908 */         y[i2][i1] = yi;
/*      */       } 
/*  910 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  911 */         int ii = i[i2][i1];
/*  912 */         float[] aii = this._ai[ii];
/*  913 */         float yi = this._ai0[ii] * x[i2][i1];
/*  914 */         for (int j = 1; j < this._m; j++) {
/*  915 */           int k1 = i1 + this._lag1[j];
/*  916 */           int k2 = i2 + this._lag2[j];
/*  917 */           yi += aii[j] * x[k2][k1];
/*      */         } 
/*  919 */         y[i2][i1] = yi;
/*      */       } 
/*  921 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  922 */         int ii = i[i2][i1];
/*  923 */         float[] aii = this._ai[ii];
/*  924 */         float yi = this._ai0[ii] * x[i2][i1];
/*  925 */         for (int j = 1; j < this._m; j++) {
/*  926 */           int k1 = i1 + this._lag1[j];
/*  927 */           int k2 = i2 + this._lag2[j];
/*  928 */           if (0 <= k1)
/*  929 */             yi += aii[j] * x[k2][k1]; 
/*      */         } 
/*  931 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[] x, float[] y) {
/*  946 */     int n1 = y.length;
/*  947 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  948 */     for (i1 = 0; i1 < i1lo; i1++) {
/*  949 */       float yi = x[i1];
/*  950 */       for (int j = 1; j < this._m; j++) {
/*  951 */         int k1 = i1 - this._lag1[j];
/*  952 */         if (0 <= k1)
/*  953 */           yi -= this._a[j] * y[k1]; 
/*      */       } 
/*  955 */       y[i1] = this._a0i * yi;
/*      */     } 
/*  957 */     for (i1 = i1lo; i1 < n1; i1++) {
/*  958 */       float yi = x[i1];
/*  959 */       for (int j = 1; j < this._m; j++) {
/*  960 */         int k1 = i1 - this._lag1[j];
/*  961 */         yi -= this._a[j] * y[k1];
/*      */       } 
/*  963 */       y[i1] = this._a0i * yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[][] x, float[][] y) {
/*  974 */     int n1 = (y[0]).length;
/*  975 */     int n2 = y.length;
/*  976 */     int i1lo = MathPlus.max(0, this._max1);
/*  977 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  978 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  979 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  980 */       for (int i1 = 0; i1 < n1; i1++) {
/*  981 */         float yi = x[i2][i1];
/*  982 */         for (int j = 1; j < this._m; j++) {
/*  983 */           int k1 = i1 - this._lag1[j];
/*  984 */           int k2 = i2 - this._lag2[j];
/*  985 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  986 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/*  988 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/*      */     } 
/*  991 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  992 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  993 */         float yi = x[i2][i1];
/*  994 */         for (int j = 1; j < this._m; j++) {
/*  995 */           int k1 = i1 - this._lag1[j];
/*  996 */           int k2 = i2 - this._lag2[j];
/*  997 */           if (0 <= k1)
/*  998 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/* 1000 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/* 1002 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/* 1003 */         float yi = x[i2][i1];
/* 1004 */         for (int j = 1; j < this._m; j++) {
/* 1005 */           int k1 = i1 - this._lag1[j];
/* 1006 */           int k2 = i2 - this._lag2[j];
/* 1007 */           yi -= this._a[j] * y[k2][k1];
/*      */         } 
/* 1009 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/* 1011 */       for (i1 = i1hi; i1 < n1; i1++) {
/* 1012 */         float yi = x[i2][i1];
/* 1013 */         for (int j = 1; j < this._m; j++) {
/* 1014 */           int k1 = i1 - this._lag1[j];
/* 1015 */           int k2 = i2 - this._lag2[j];
/* 1016 */           if (k1 < n1)
/* 1017 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/* 1019 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[][][] x, float[][][] y) {
/* 1031 */     int n1 = (y[0][0]).length;
/* 1032 */     int n2 = (y[0]).length;
/* 1033 */     int n3 = y.length;
/* 1034 */     int i1lo = MathPlus.max(0, this._max1);
/* 1035 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/* 1036 */     int i2lo = MathPlus.max(0, this._max2);
/* 1037 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/* 1038 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/* 1039 */     for (i3 = 0; i3 < i3lo; i3++) {
/* 1040 */       for (int i2 = 0; i2 < n2; i2++) {
/* 1041 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1042 */           float yi = x[i3][i2][i1];
/* 1043 */           for (int j = 1; j < this._m; j++) {
/* 1044 */             int k1 = i1 - this._lag1[j];
/* 1045 */             int k2 = i2 - this._lag2[j];
/* 1046 */             int k3 = i3 - this._lag3[j];
/* 1047 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/* 1048 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1050 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1054 */     for (i3 = i3lo; i3 < n3; i3++) {
/* 1055 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/* 1056 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1057 */           float yi = x[i3][i2][i1];
/* 1058 */           for (int j = 1; j < this._m; j++) {
/* 1059 */             int k1 = i1 - this._lag1[j];
/* 1060 */             int k2 = i2 - this._lag2[j];
/* 1061 */             int k3 = i3 - this._lag3[j];
/* 1062 */             if (0 <= k2 && 0 <= k1 && k1 < n1)
/* 1063 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1065 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/* 1068 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/* 1069 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/* 1070 */           float yi = x[i3][i2][i1];
/* 1071 */           for (int j = 1; j < this._m; j++) {
/* 1072 */             int k1 = i1 - this._lag1[j];
/* 1073 */             int k2 = i2 - this._lag2[j];
/* 1074 */             int k3 = i3 - this._lag3[j];
/* 1075 */             if (0 <= k1)
/* 1076 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1078 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/* 1080 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/* 1081 */           float yi = x[i3][i2][i1];
/* 1082 */           for (int j = 1; j < this._m; j++) {
/* 1083 */             int k1 = i1 - this._lag1[j];
/* 1084 */             int k2 = i2 - this._lag2[j];
/* 1085 */             int k3 = i3 - this._lag3[j];
/* 1086 */             yi -= this._a[j] * y[k3][k2][k1];
/*      */           } 
/* 1088 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/* 1090 */         for (i1 = i1hi; i1 < n1; i1++) {
/* 1091 */           float yi = x[i3][i2][i1];
/* 1092 */           for (int j = 1; j < this._m; j++) {
/* 1093 */             int k1 = i1 - this._lag1[j];
/* 1094 */             int k2 = i2 - this._lag2[j];
/* 1095 */             int k3 = i3 - this._lag3[j];
/* 1096 */             if (k1 < n1)
/* 1097 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1099 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/* 1102 */       for (i2 = i2hi; i2 < n2; i2++) {
/* 1103 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1104 */           float yi = x[i3][i2][i1];
/* 1105 */           for (int j = 1; j < this._m; j++) {
/* 1106 */             int k1 = i1 - this._lag1[j];
/* 1107 */             int k2 = i2 - this._lag2[j];
/* 1108 */             int k3 = i3 - this._lag3[j];
/* 1109 */             if (k2 < n2 && 0 <= k1 && k1 < n1)
/* 1110 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1112 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(int[][] i, float[][] x, float[][] y) {
/* 1126 */     int n1 = (y[0]).length;
/* 1127 */     int n2 = y.length;
/* 1128 */     int i1lo = MathPlus.max(0, this._max1);
/* 1129 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/* 1130 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/* 1131 */     for (i2 = 0; i2 < i2lo; i2++) {
/* 1132 */       for (int i1 = 0; i1 < n1; i1++) {
/* 1133 */         int ii = i[i2][i1];
/* 1134 */         float[] aii = this._ai[ii];
/* 1135 */         float yi = x[i2][i1];
/* 1136 */         for (int j = 1; j < this._m; j++) {
/* 1137 */           int k1 = i1 - this._lag1[j];
/* 1138 */           int k2 = i2 - this._lag2[j];
/* 1139 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/* 1140 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1142 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/*      */     } 
/* 1145 */     for (i2 = i2lo; i2 < n2; i2++) {
/* 1146 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/* 1147 */         int ii = i[i2][i1];
/* 1148 */         float[] aii = this._ai[ii];
/* 1149 */         float yi = x[i2][i1];
/* 1150 */         for (int j = 1; j < this._m; j++) {
/* 1151 */           int k1 = i1 - this._lag1[j];
/* 1152 */           int k2 = i2 - this._lag2[j];
/* 1153 */           if (0 <= k1)
/* 1154 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1156 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/* 1158 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/* 1159 */         int ii = i[i2][i1];
/* 1160 */         float[] aii = this._ai[ii];
/* 1161 */         float yi = x[i2][i1];
/* 1162 */         for (int j = 1; j < this._m; j++) {
/* 1163 */           int k1 = i1 - this._lag1[j];
/* 1164 */           int k2 = i2 - this._lag2[j];
/* 1165 */           yi -= aii[j] * y[k2][k1];
/*      */         } 
/* 1167 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/* 1169 */       for (i1 = i1hi; i1 < n1; i1++) {
/* 1170 */         int ii = i[i2][i1];
/* 1171 */         float[] aii = this._ai[ii];
/* 1172 */         float yi = x[i2][i1];
/* 1173 */         for (int j = 1; j < this._m; j++) {
/* 1174 */           int k1 = i1 - this._lag1[j];
/* 1175 */           int k2 = i2 - this._lag2[j];
/* 1176 */           if (k1 < n1)
/* 1177 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1179 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[] x, float[] y) {
/* 1194 */     int n1 = y.length;
/* 1195 */     int i1hi = MathPlus.max(n1 - this._max1, 0); int i1;
/* 1196 */     for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/* 1197 */       float yi = x[i1];
/* 1198 */       for (int j = 1; j < this._m; j++) {
/* 1199 */         int k1 = i1 + this._lag1[j];
/* 1200 */         if (k1 < n1)
/* 1201 */           yi -= this._a[j] * y[k1]; 
/*      */       } 
/* 1203 */       y[i1] = this._a0i * yi;
/*      */     } 
/* 1205 */     for (i1 = i1hi - 1; i1 >= 0; i1--) {
/* 1206 */       float yi = x[i1];
/* 1207 */       for (int j = 1; j < this._m; j++) {
/* 1208 */         int k1 = i1 + this._lag1[j];
/* 1209 */         yi -= this._a[j] * y[k1];
/*      */       } 
/* 1211 */       y[i1] = this._a0i * yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[][] x, float[][] y) {
/* 1222 */     int n1 = (y[0]).length;
/* 1223 */     int n2 = y.length;
/* 1224 */     int i1lo = MathPlus.max(0, -this._min1);
/* 1225 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/* 1226 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/* 1227 */     for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/* 1228 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1229 */         float yi = x[i2][i1];
/* 1230 */         for (int j = 1; j < this._m; j++) {
/* 1231 */           int k1 = i1 + this._lag1[j];
/* 1232 */           int k2 = i2 + this._lag2[j];
/* 1233 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/* 1234 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/* 1236 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/*      */     } 
/* 1239 */     for (i2 = i2hi - 1; i2 >= 0; i2--) {
/* 1240 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/* 1241 */         float yi = x[i2][i1];
/* 1242 */         for (int j = 1; j < this._m; j++) {
/* 1243 */           int k1 = i1 + this._lag1[j];
/* 1244 */           int k2 = i2 + this._lag2[j];
/* 1245 */           if (k1 < n1)
/* 1246 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/* 1248 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/* 1250 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/* 1251 */         float yi = x[i2][i1];
/* 1252 */         for (int j = 1; j < this._m; j++) {
/* 1253 */           int k1 = i1 + this._lag1[j];
/* 1254 */           int k2 = i2 + this._lag2[j];
/* 1255 */           yi -= this._a[j] * y[k2][k1];
/*      */         } 
/* 1257 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/* 1259 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/* 1260 */         float yi = x[i2][i1];
/* 1261 */         for (int j = 1; j < this._m; j++) {
/* 1262 */           int k1 = i1 + this._lag1[j];
/* 1263 */           int k2 = i2 + this._lag2[j];
/* 1264 */           if (0 <= k1)
/* 1265 */             yi -= this._a[j] * y[k2][k1]; 
/*      */         } 
/* 1267 */         y[i2][i1] = this._a0i * yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[][][] x, float[][][] y) {
/* 1279 */     int n1 = (y[0][0]).length;
/* 1280 */     int n2 = (y[0]).length;
/* 1281 */     int n3 = y.length;
/* 1282 */     int i1lo = MathPlus.max(0, -this._min1);
/* 1283 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/* 1284 */     int i2lo = MathPlus.max(0, -this._min2);
/* 1285 */     int i2hi = MathPlus.min(n2, n2 - this._max2);
/* 1286 */     int i3hi = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.max(n3 - this._max3, 0) : 0; int i3;
/* 1287 */     for (i3 = n3 - 1; i3 >= i3hi; i3--) {
/* 1288 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/* 1289 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1290 */           float yi = x[i3][i2][i1];
/* 1291 */           for (int j = 1; j < this._m; j++) {
/* 1292 */             int k1 = i1 + this._lag1[j];
/* 1293 */             int k2 = i2 + this._lag2[j];
/* 1294 */             int k3 = i3 + this._lag3[j];
/* 1295 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && k3 < n3)
/* 1296 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1298 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1302 */     for (i3 = i3hi - 1; i3 >= 0; i3--) {
/* 1303 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/* 1304 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1305 */           float yi = x[i3][i2][i1];
/* 1306 */           for (int j = 1; j < this._m; j++) {
/* 1307 */             int k1 = i1 + this._lag1[j];
/* 1308 */             int k2 = i2 + this._lag2[j];
/* 1309 */             int k3 = i3 + this._lag3[j];
/* 1310 */             if (k2 < n2 && 0 <= k1 && k1 < n1)
/* 1311 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1313 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/* 1316 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/* 1317 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/* 1318 */           float yi = x[i3][i2][i1];
/* 1319 */           for (int j = 1; j < this._m; j++) {
/* 1320 */             int k1 = i1 + this._lag1[j];
/* 1321 */             int k2 = i2 + this._lag2[j];
/* 1322 */             int k3 = i3 + this._lag3[j];
/* 1323 */             if (k1 < n1)
/* 1324 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1326 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/* 1328 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/* 1329 */           float yi = x[i3][i2][i1];
/* 1330 */           for (int j = 1; j < this._m; j++) {
/* 1331 */             int k1 = i1 + this._lag1[j];
/* 1332 */             int k2 = i2 + this._lag2[j];
/* 1333 */             int k3 = i3 + this._lag3[j];
/* 1334 */             yi -= this._a[j] * y[k3][k2][k1];
/*      */           } 
/* 1336 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/* 1338 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/* 1339 */           float yi = x[i3][i2][i1];
/* 1340 */           for (int j = 1; j < this._m; j++) {
/* 1341 */             int k1 = i1 + this._lag1[j];
/* 1342 */             int k2 = i2 + this._lag2[j];
/* 1343 */             int k3 = i3 + this._lag3[j];
/* 1344 */             if (0 <= k1)
/* 1345 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1347 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/* 1350 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/* 1351 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1352 */           float yi = x[i3][i2][i1];
/* 1353 */           for (int j = 1; j < this._m; j++) {
/* 1354 */             int k1 = i1 + this._lag1[j];
/* 1355 */             int k2 = i2 + this._lag2[j];
/* 1356 */             int k3 = i3 + this._lag3[j];
/* 1357 */             if (0 <= k2 && 0 <= k1 && k1 < n1)
/* 1358 */               yi -= this._a[j] * y[k3][k2][k1]; 
/*      */           } 
/* 1360 */           y[i3][i2][i1] = this._a0i * yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(int[][] i, float[][] x, float[][] y) {
/* 1374 */     int n1 = (y[0]).length;
/* 1375 */     int n2 = y.length;
/* 1376 */     int i1lo = MathPlus.max(0, -this._min1);
/* 1377 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/* 1378 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/* 1379 */     for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/* 1380 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1381 */         int ii = i[i2][i1];
/* 1382 */         float[] aii = this._ai[ii];
/* 1383 */         float yi = x[i2][i1];
/* 1384 */         for (int j = 1; j < this._m; j++) {
/* 1385 */           int k1 = i1 + this._lag1[j];
/* 1386 */           int k2 = i2 + this._lag2[j];
/* 1387 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/* 1388 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1390 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/*      */     } 
/* 1393 */     for (i2 = i2hi - 1; i2 >= 0; i2--) {
/* 1394 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/* 1395 */         int ii = i[i2][i1];
/* 1396 */         float[] aii = this._ai[ii];
/* 1397 */         float yi = x[i2][i1];
/* 1398 */         for (int j = 1; j < this._m; j++) {
/* 1399 */           int k1 = i1 + this._lag1[j];
/* 1400 */           int k2 = i2 + this._lag2[j];
/* 1401 */           if (k1 < n1)
/* 1402 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1404 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/* 1406 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/* 1407 */         int ii = i[i2][i1];
/* 1408 */         float[] aii = this._ai[ii];
/* 1409 */         float yi = x[i2][i1];
/* 1410 */         for (int j = 1; j < this._m; j++) {
/* 1411 */           int k1 = i1 + this._lag1[j];
/* 1412 */           int k2 = i2 + this._lag2[j];
/* 1413 */           yi -= aii[j] * y[k2][k1];
/*      */         } 
/* 1415 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/* 1417 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/* 1418 */         int ii = i[i2][i1];
/* 1419 */         float[] aii = this._ai[ii];
/* 1420 */         float yi = x[i2][i1];
/* 1421 */         for (int j = 1; j < this._m; j++) {
/* 1422 */           int k1 = i1 + this._lag1[j];
/* 1423 */           int k2 = i2 + this._lag2[j];
/* 1424 */           if (0 <= k1)
/* 1425 */             yi -= aii[j] * y[k2][k1]; 
/*      */         } 
/* 1427 */         y[i2][i1] = this._ai0i[ii] * yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float[] impulse(int nlag) {
/* 1449 */     float[] a = new float[nlag];
/* 1450 */     a[0] = 1.0F;
/* 1451 */     return a;
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, float[] a) {
/* 1455 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1456 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1457 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1458 */     for (int j = 1; j < a.length; j++)
/* 1459 */       Check.argument((lag1[j] > 0), "lag1[" + j + "]>0"); 
/* 1460 */     this._m = lag1.length;
/* 1461 */     this._lag1 = Array.copy(lag1);
/* 1462 */     this._lag2 = Array.zeroint(this._m);
/* 1463 */     this._lag3 = Array.zeroint(this._m);
/* 1464 */     this._min1 = Array.min(lag1);
/* 1465 */     this._max1 = Array.max(lag1);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2, float[] a) {
/* 1469 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1470 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1471 */     Check.argument((lag2.length == a.length), "lag2.length==a.length");
/* 1472 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1473 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1474 */     for (int j = 1; j < a.length; j++) {
/* 1475 */       Check.argument((lag2[j] >= 0), "lag2[" + j + "]>=0");
/* 1476 */       if (lag2[j] == 0)
/* 1477 */         Check.argument((lag1[j] > 0), "if lag2==0, lag1[" + j + "]>0"); 
/*      */     } 
/* 1479 */     this._m = lag1.length;
/* 1480 */     this._lag1 = Array.copy(lag1);
/* 1481 */     this._lag2 = Array.copy(lag2);
/* 1482 */     this._lag3 = Array.zeroint(this._m);
/* 1483 */     this._min1 = Array.min(lag1);
/* 1484 */     this._min2 = Array.min(lag2);
/* 1485 */     this._max1 = Array.max(lag1);
/* 1486 */     this._max2 = Array.max(lag2);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2, int[] lag3, float[] a) {
/* 1490 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1491 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1492 */     Check.argument((lag2.length == a.length), "lag2.length==a.length");
/* 1493 */     Check.argument((lag3.length == a.length), "lag3.length==a.length");
/* 1494 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1495 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1496 */     Check.argument((lag3[0] == 0), "lag3[0]==0");
/* 1497 */     for (int j = 1; j < a.length; j++) {
/* 1498 */       Check.argument((lag3[j] >= 0), "lag3[" + j + "]>=0");
/* 1499 */       if (lag3[j] == 0) {
/* 1500 */         Check.argument((lag2[j] >= 0), "if lag3==0, lag2[" + j + "]>=0");
/* 1501 */         if (lag2[j] == 0)
/* 1502 */           Check.argument((lag1[j] > 0), "if lag3==0 && lag2==0, lag1[" + j + "]>0"); 
/*      */       } 
/*      */     } 
/* 1505 */     this._m = a.length;
/* 1506 */     this._lag1 = Array.copy(lag1);
/* 1507 */     this._lag2 = Array.copy(lag2);
/* 1508 */     this._lag3 = Array.copy(lag3);
/* 1509 */     this._min1 = Array.min(lag1);
/* 1510 */     this._min2 = Array.min(lag2);
/* 1511 */     this._min3 = Array.min(lag3);
/* 1512 */     this._max1 = Array.max(lag1);
/* 1513 */     this._max2 = Array.max(lag2);
/* 1514 */     this._max3 = Array.max(lag3);
/*      */   }
/*      */   
/*      */   private void initA(float[] a) {
/* 1518 */     this._a = Array.copy(a);
/* 1519 */     this._a0 = a[0];
/* 1520 */     this._a0i = 1.0F / a[0];
/*      */   }
/*      */   
/*      */   private void initA(float[][] a) {
/* 1524 */     Check.argument(Array.isRegular(a), "a is regular");
/* 1525 */     initA(a[0]);
/* 1526 */     this._ni = a.length;
/* 1527 */     this._ai = Array.copy(a);
/* 1528 */     this._ai0 = new float[this._ni];
/* 1529 */     this._ai0i = new float[this._ni];
/* 1530 */     for (int ii = 0; ii < this._ni; ii++) {
/* 1531 */       this._ai0[ii] = a[ii][0];
/* 1532 */       this._ai0i[ii] = 1.0F / a[ii][0];
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/MinimumPhaseFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */