/*    */ package edu.mines.jtk.lapack.test;
/*    */ 
/*    */ import edu.mines.jtk.lapack.DMatrix;
/*    */ import edu.mines.jtk.lapack.DMatrixChd;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixChdTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 24 */     TestSuite suite = new TestSuite(DMatrixChdTest.class);
/* 25 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSimple() {
/* 29 */     DMatrix a = new DMatrix(new double[][] { { 1.0D, 1.0D }, { 1.0D, 4.0D } });
/*    */ 
/*    */ 
/*    */     
/* 33 */     test(a);
/* 34 */     DMatrixChd chd = new DMatrixChd(a);
/* 35 */     DMatrixTest.assertEqualFuzzy(3.0D, chd.det());
/*    */   }
/*    */   
/*    */   public void testSimple2() {
/* 39 */     DMatrix a = new DMatrix(new double[][] { { 4.0D, 1.0D, 1.0D }, { 1.0D, 2.0D, 3.0D }, { 1.0D, 3.0D, 6.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     test(a);
/*    */   }
/*    */   
/*    */   public void testNotPositiveDefinite() {
/* 48 */     DMatrix a = new DMatrix(new double[][] { { 0.0D, 1.0D, 1.0D }, { 0.0D, 2.0D, 3.0D }, { 0.0D, 3.0D, 6.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     DMatrixChd chd = new DMatrixChd(a);
/* 54 */     assertFalse(chd.isPositiveDefinite());
/* 55 */     DMatrixTest.assertEqualExact(0.0D, chd.det());
/*    */   }
/*    */   
/*    */   public void testRandom() {
/* 59 */     int n = 10;
/* 60 */     DMatrix a = DMatrix.random(n, n);
/* 61 */     a.plusEquals(a.transpose());
/* 62 */     DMatrix d = DMatrix.identity(n, n);
/* 63 */     d.timesEquals(n * a.norm1());
/* 64 */     a.plusEquals(d);
/* 65 */     test(a);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void test(DMatrix a) {
/* 72 */     int m = a.getM();
/*    */     
/* 74 */     DMatrixChd chd = new DMatrixChd(a);
/* 75 */     assertTrue(chd.isPositiveDefinite());
/* 76 */     DMatrix l = chd.getL();
/* 77 */     DMatrix lt = l.transpose();
/* 78 */     DMatrix llt = l.times(lt);
/* 79 */     DMatrixTest.assertEqualFuzzy(a, llt);
/*    */     
/* 81 */     int nrhs = 10;
/* 82 */     DMatrix b = DMatrix.random(m, nrhs);
/* 83 */     DMatrix x = chd.solve(b);
/* 84 */     DMatrix ax = a.times(x);
/* 85 */     DMatrixTest.assertEqualFuzzy(ax, b);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/DMatrixChdTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */