/*     */ package edu.mines.jtk.io;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayInputStream
/*     */   extends FilterInputStream
/*     */   implements ArrayInput
/*     */ {
/*     */   private ArrayInput _ai;
/*     */   private ByteOrder _bo;
/*     */   
/*     */   public ArrayInputStream(InputStream is) {
/*  28 */     this(is, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(FileInputStream fis) {
/*  38 */     this(fis, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(String name) throws FileNotFoundException {
/*  47 */     this(new FileInputStream(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(File file) throws FileNotFoundException {
/*  56 */     this(new FileInputStream(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(InputStream is, ByteOrder bo) {
/*  65 */     super(is);
/*  66 */     this._ai = new ArrayInputAdapter(new DataInputStream(is), bo);
/*  67 */     this._bo = bo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(FileInputStream fis, ByteOrder bo) {
/*  78 */     super(fis);
/*  79 */     this._ai = new ArrayInputAdapter(fis.getChannel(), new DataInputStream(fis), bo);
/*     */     
/*  81 */     this._bo = bo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(String name, ByteOrder bo) throws FileNotFoundException {
/*  94 */     this(new FileInputStream(name), bo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputStream(File file, ByteOrder bo) throws FileNotFoundException {
/* 106 */     this(new FileInputStream(file), bo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrder() {
/* 114 */     return this._bo;
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 118 */     this._ai.readFully(b);
/*     */   }
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 121 */     this._ai.readFully(b, off, len);
/*     */   }
/*     */   public int skipBytes(int n) throws IOException {
/* 124 */     return this._ai.skipBytes(n);
/*     */   }
/*     */   public final boolean readBoolean() throws IOException {
/* 127 */     return this._ai.readBoolean();
/*     */   }
/*     */   public final byte readByte() throws IOException {
/* 130 */     return this._ai.readByte();
/*     */   }
/*     */   public final int readUnsignedByte() throws IOException {
/* 133 */     return this._ai.readUnsignedByte();
/*     */   }
/*     */   public final short readShort() throws IOException {
/* 136 */     return this._ai.readShort();
/*     */   }
/*     */   public final int readUnsignedShort() throws IOException {
/* 139 */     return this._ai.readUnsignedShort();
/*     */   }
/*     */   public final char readChar() throws IOException {
/* 142 */     return this._ai.readChar();
/*     */   }
/*     */   public final int readInt() throws IOException {
/* 145 */     return this._ai.readInt();
/*     */   }
/*     */   public final long readLong() throws IOException {
/* 148 */     return this._ai.readLong();
/*     */   }
/*     */   public final float readFloat() throws IOException {
/* 151 */     return this._ai.readFloat();
/*     */   }
/*     */   public final double readDouble() throws IOException {
/* 154 */     return this._ai.readDouble();
/*     */   }
/*     */   public final String readLine() throws IOException {
/* 157 */     return this._ai.readLine();
/*     */   }
/*     */   public final String readUTF() throws IOException {
/* 160 */     return this._ai.readUTF();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v, int k, int n) throws IOException {
/* 170 */     this._ai.readBytes(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v) throws IOException {
/* 179 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][] v) throws IOException {
/* 188 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][][] v) throws IOException {
/* 197 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v, int k, int n) throws IOException {
/* 207 */     this._ai.readChars(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v) throws IOException {
/* 216 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][] v) throws IOException {
/* 225 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][][] v) throws IOException {
/* 234 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v, int k, int n) throws IOException {
/* 244 */     this._ai.readShorts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v) throws IOException {
/* 253 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][] v) throws IOException {
/* 262 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][][] v) throws IOException {
/* 271 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v, int k, int n) throws IOException {
/* 281 */     this._ai.readInts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v) throws IOException {
/* 290 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][] v) throws IOException {
/* 299 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][][] v) throws IOException {
/* 308 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v, int k, int n) throws IOException {
/* 318 */     this._ai.readLongs(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v) throws IOException {
/* 327 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][] v) throws IOException {
/* 336 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][][] v) throws IOException {
/* 345 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v, int k, int n) throws IOException {
/* 355 */     this._ai.readFloats(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v) throws IOException {
/* 364 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][] v) throws IOException {
/* 373 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][][] v) throws IOException {
/* 382 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v, int k, int n) throws IOException {
/* 392 */     this._ai.readDoubles(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v) throws IOException {
/* 401 */     this._ai.readDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][] v) throws IOException {
/* 410 */     this._ai.readDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][][] v) throws IOException {
/* 419 */     this._ai.readDoubles(v);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/ArrayInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */