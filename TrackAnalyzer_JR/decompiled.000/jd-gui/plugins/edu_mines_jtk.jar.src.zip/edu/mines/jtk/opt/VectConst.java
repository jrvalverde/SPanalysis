package edu.mines.jtk.opt;

import java.io.Serializable;

public interface VectConst extends Cloneable, Serializable {
  double dot(VectConst paramVectConst);
  
  double magnitude();
  
  Vect clone();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/VectConst.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */