/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.Mode;
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileZoomMode
/*     */   extends Mode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Tile _tile;
/*     */   private TileAxis _axis;
/*     */   private int _xbegin;
/*     */   private int _ybegin;
/*     */   private int _xdraw;
/*     */   private int _ydraw;
/*     */   private MouseListener _ml;
/*     */   private MouseMotionListener _mml;
/*     */   
/*     */   public TileZoomMode(ModeManager modeManager) {
/*  34 */     super(modeManager);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this._ml = new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent e) {
/*  67 */           TileZoomMode.this.beginZoom(e);
/*     */         }
/*     */         public void mouseReleased(MouseEvent e) {
/*  70 */           TileZoomMode.this.endZoom(e);
/*     */         }
/*     */       };
/*     */     
/*  74 */     this._mml = new MouseMotionAdapter()
/*     */       {
/*  76 */         public void mouseDragged(MouseEvent e) { TileZoomMode.this.duringZoom(e); } };
/*     */     setName("Zoom");
/*     */     setIcon(loadIcon(TileZoomMode.class, "resources/ZoomIn16.gif"));
/*     */     setMnemonicKey(90);
/*     */     setAcceleratorKey(KeyStroke.getKeyStroke(90, 0));
/*  81 */     setShortDescription("Zoom in tile or axis"); } private void beginZoom(MouseEvent e) { this._xbegin = e.getX();
/*  82 */     this._ybegin = e.getY();
/*  83 */     Object source = e.getSource();
/*  84 */     if (source instanceof Tile) {
/*  85 */       Tile tile = this._tile = (Tile)source;
/*  86 */       drawZoom(tile, this._xbegin, this._ybegin, true, true);
/*  87 */       tile.addMouseMotionListener(this._mml);
/*  88 */     } else if (source instanceof TileAxis) {
/*  89 */       TileAxis axis = this._axis = (TileAxis)source;
/*  90 */       drawZoom(axis, this._xbegin, this._ybegin, this._axis.isHorizontal(), this._axis.isVertical());
/*  91 */       axis.addMouseMotionListener(this._mml);
/*     */     }  }
/*     */   protected void setActive(Component component, boolean active) { if (component instanceof Tile || component instanceof TileAxis)
/*     */       if (active) { component.addMouseListener(this._ml); }
/*     */       else { component.removeMouseListener(this._ml); }
/*  96 */         } private void duringZoom(MouseEvent e) { int xdraw = e.getX();
/*  97 */     int ydraw = e.getY();
/*  98 */     if (this._tile != null) {
/*  99 */       drawZoom(this._tile, this._xdraw, this._ydraw, true, true);
/* 100 */       drawZoom(this._tile, xdraw, ydraw, true, true);
/* 101 */     } else if (this._axis != null) {
/* 102 */       drawZoom(this._axis, this._xdraw, this._ydraw, this._axis.isHorizontal(), this._axis.isVertical());
/* 103 */       drawZoom(this._axis, xdraw, ydraw, this._axis.isHorizontal(), this._axis.isVertical());
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endZoom(MouseEvent e) {
/* 110 */     Tile tile = null;
/* 111 */     boolean zx = false;
/* 112 */     boolean zy = false;
/*     */ 
/*     */     
/* 115 */     if (this._tile != null) {
/* 116 */       tile = this._tile;
/* 117 */       zx = true;
/* 118 */       zy = true;
/* 119 */       drawZoom(this._tile, this._xdraw, this._ydraw, zx, zy);
/* 120 */       this._tile.removeMouseMotionListener(this._mml);
/* 121 */       this._tile = null;
/*     */ 
/*     */     
/*     */     }
/* 125 */     else if (this._axis != null) {
/* 126 */       tile = this._axis.getTile();
/* 127 */       zx = this._axis.isHorizontal();
/* 128 */       zy = this._axis.isVertical();
/* 129 */       drawZoom(this._axis, this._xdraw, this._ydraw, zx, zy);
/* 130 */       this._axis.removeMouseMotionListener(this._mml);
/* 131 */       this._axis = null;
/*     */     } 
/*     */ 
/*     */     
/* 135 */     if (tile != null && (zx || zy)) {
/* 136 */       int xmin = Math.min(this._xbegin, this._xdraw);
/* 137 */       int xmax = Math.max(this._xbegin, this._xdraw);
/* 138 */       int ymin = Math.min(this._ybegin, this._ydraw);
/* 139 */       int ymax = Math.max(this._ybegin, this._ydraw);
/* 140 */       Transcaler ts = tile.getTranscaler();
/* 141 */       DRectangle vr = tile.getViewRectangle();
/*     */ 
/*     */       
/* 144 */       if (zx) {
/* 145 */         vr.x = (xmin < xmax) ? ts.x(xmin) : 0.0D;
/* 146 */         vr.width = (xmin < xmax) ? (ts.x(xmax) - vr.x) : 1.0D;
/*     */       } 
/*     */ 
/*     */       
/* 150 */       if (zy) {
/* 151 */         vr.y = (ymin < ymax) ? ts.y(ymin) : 0.0D;
/* 152 */         vr.height = (ymin < ymax) ? (ts.y(ymax) - vr.y) : 1.0D;
/*     */       } 
/*     */ 
/*     */       
/* 156 */       double tiny = 1.0E-4D;
/* 157 */       if (vr.width < tiny) {
/* 158 */         vr.x -= (tiny - vr.width) / 2.0D;
/* 159 */         vr.width = tiny;
/*     */       } 
/* 161 */       if (vr.height < tiny) {
/* 162 */         vr.y -= (tiny - vr.height) / 2.0D;
/* 163 */         vr.height = tiny;
/*     */       } 
/* 165 */       vr.x = Math.min(1.0D - vr.width, vr.x);
/* 166 */       vr.y = Math.min(1.0D - vr.height, vr.y);
/*     */ 
/*     */       
/* 169 */       tile.setViewRectangle(vr);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawZoom(Tile tile, int x, int y, boolean bx, boolean by) {
/* 174 */     if (tile == null) {
/*     */       return;
/*     */     }
/*     */     
/* 178 */     if (tile == this._tile) {
/*     */ 
/*     */       
/* 181 */       x = Math.max(0, Math.min(tile.getWidth() - 1, x));
/* 182 */       y = Math.max(0, Math.min(tile.getHeight() - 1, y));
/*     */ 
/*     */       
/* 185 */       drawRect(tile, x, y, bx, by);
/*     */ 
/*     */       
/* 188 */       Mosaic mosaic = tile.getMosaic();
/* 189 */       int jrow = tile.getRowIndex();
/* 190 */       int jcol = tile.getColumnIndex();
/* 191 */       int nrow = mosaic.countRows();
/* 192 */       int ncol = mosaic.countColumns();
/* 193 */       for (int irow = 0; irow < nrow; irow++) {
/* 194 */         if (irow != jrow)
/* 195 */           drawZoom(mosaic.getTile(irow, jcol), x, y, true, false); 
/*     */       } 
/* 197 */       for (int icol = 0; icol < ncol; icol++) {
/* 198 */         if (icol != jcol)
/* 199 */           drawZoom(mosaic.getTile(jrow, icol), x, y, false, true); 
/*     */       } 
/* 201 */       drawZoom(mosaic.getTileAxisTop(jcol), x, y, true, false);
/* 202 */       drawZoom(mosaic.getTileAxisLeft(jrow), x, y, false, true);
/* 203 */       drawZoom(mosaic.getTileAxisBottom(jcol), x, y, true, false);
/* 204 */       drawZoom(mosaic.getTileAxisRight(jrow), x, y, false, true);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 211 */       drawRect(tile, x, y, bx, by);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawZoom(TileAxis axis, int x, int y, boolean bx, boolean by) {
/* 216 */     if (axis == null) {
/*     */       return;
/*     */     }
/*     */     
/* 220 */     if (axis == this._axis) {
/*     */ 
/*     */       
/* 223 */       x = Math.max(0, Math.min(axis.getWidth() - 1, x));
/* 224 */       y = Math.max(0, Math.min(axis.getHeight() - 1, y));
/*     */ 
/*     */       
/* 227 */       drawRect(axis, x, y, bx, by);
/*     */ 
/*     */       
/* 230 */       Mosaic mosaic = axis.getMosaic();
/* 231 */       if (axis.isHorizontal()) {
/* 232 */         int jcol = axis.getIndex();
/* 233 */         int nrow = mosaic.countRows();
/* 234 */         for (int irow = 0; irow < nrow; irow++)
/* 235 */           drawZoom(mosaic.getTile(irow, jcol), x, y, true, false); 
/* 236 */         if (axis.isTop()) {
/* 237 */           drawZoom(mosaic.getTileAxisBottom(jcol), x, y, true, false);
/*     */         } else {
/* 239 */           drawZoom(mosaic.getTileAxisTop(jcol), x, y, true, false);
/*     */         } 
/*     */       } else {
/* 242 */         int jrow = axis.getIndex();
/* 243 */         int ncol = mosaic.countColumns();
/* 244 */         for (int icol = 0; icol < ncol; icol++)
/* 245 */           drawZoom(mosaic.getTile(jrow, icol), x, y, false, true); 
/* 246 */         if (axis.isLeft()) {
/* 247 */           drawZoom(mosaic.getTileAxisRight(jrow), x, y, false, true);
/*     */         } else {
/* 249 */           drawZoom(mosaic.getTileAxisLeft(jrow), x, y, false, true);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 258 */       drawRect(axis, x, y, bx, by);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawRect(JComponent c, int x, int y, boolean bx, boolean by) {
/* 263 */     this._xdraw = x;
/* 264 */     this._ydraw = y;
/* 265 */     int xmin = bx ? Math.min(this._xbegin, this._xdraw) : -1;
/* 266 */     int xmax = bx ? Math.max(this._xbegin, this._xdraw) : c.getWidth();
/* 267 */     int ymin = by ? Math.min(this._ybegin, this._ydraw) : -1;
/* 268 */     int ymax = by ? Math.max(this._ybegin, this._ydraw) : c.getHeight();
/* 269 */     Graphics g = c.getGraphics();
/* 270 */     g.setColor(Color.RED);
/* 271 */     g.setXORMode(c.getBackground());
/* 272 */     g.drawRect(xmin, ymin, xmax - xmin, ymax - ymin);
/* 273 */     g.dispose();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/TileZoomMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */