/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import edu.mines.jtk.util.Monitor;
/*     */ import edu.mines.jtk.util.PartialMonitor;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GaussNewtonSolver
/*     */ {
/*     */   private static boolean s_expensiveDebug = false;
/*  23 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vect solve(VectConst data, VectConst referenceModel, VectConst perturbModel, Transform transform, boolean dampOnlyPerturbation, int conjugateGradIterations, int lineSearchIterations, int linearizationIterations, double lineSearchError, Monitor monitor) {
/*  93 */     if (s_expensiveDebug) {
/*  94 */       VectUtil.test(data);
/*  95 */       VectUtil.test(referenceModel);
/*  96 */       TransformQuadratic tq = new TransformQuadratic(data, referenceModel, perturbModel, transform, dampOnlyPerturbation);
/*     */       
/*  98 */       int precision = tq.getTransposePrecision();
/*  99 */       if (precision < 6) {
/* 100 */         throw new IllegalStateException("Bad transpose precision = " + precision);
/*     */       }
/* 102 */       tq.dispose();
/*     */     } 
/* 104 */     if (monitor == null) monitor = Monitor.NULL_MONITOR; 
/* 105 */     monitor.report(0.0D);
/*     */     
/* 107 */     Vect m0 = referenceModel.clone();
/* 108 */     referenceModel = null;
/* 109 */     m0.constrain();
/* 110 */     if (linearizationIterations < 1) linearizationIterations = 1;
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (int iter = 0; iter < linearizationIterations; iter++) {
/* 115 */       double frac = 3.0D * conjugateGradIterations / (3.0D * conjugateGradIterations + lineSearchIterations);
/*     */       
/* 117 */       double begin = iter / linearizationIterations;
/* 118 */       double mid = (iter + frac) / linearizationIterations;
/* 119 */       double end = (iter + 1.0D) / linearizationIterations;
/* 120 */       monitor.report(begin);
/*     */       
/* 122 */       TransformQuadratic transformQuadratic = new TransformQuadratic(data, m0, perturbModel, transform, dampOnlyPerturbation);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       QuadraticSolver quadraticSolver = new QuadraticSolver(transformQuadratic);
/*     */       
/* 129 */       Vect perturbation = quadraticSolver.solve(conjugateGradIterations, (Monitor)new PartialMonitor(monitor, begin, mid));
/*     */ 
/*     */ 
/*     */       
/* 133 */       double pp = perturbation.dot(perturbation);
/* 134 */       if (Almost.FLOAT.zero(pp)) {
/* 135 */         perturbation.dispose();
/* 136 */         transformQuadratic.dispose();
/*     */         
/*     */         break;
/*     */       } 
/*     */       
/* 141 */       double scalar = 1.0D;
/* 142 */       if (lineSearchIterations > 0) {
/* 143 */         TransformFunction transformFunction = new TransformFunction(transform, data, m0, perturbation, dampOnlyPerturbation);
/*     */ 
/*     */         
/* 146 */         ScalarSolver scalarSolver = new ScalarSolver(transformFunction);
/*     */         
/* 148 */         double scalarMin = 0.0D, scalarMax = 1.1D;
/* 149 */         double okError = lineSearchError, okFraction = lineSearchError;
/* 150 */         scalar = scalarSolver.solve(scalarMin, scalarMax, okError, okFraction, lineSearchIterations, (Monitor)new PartialMonitor(monitor, mid, end));
/*     */ 
/*     */         
/* 153 */         transformFunction.dispose();
/*     */       } 
/*     */ 
/*     */       
/* 157 */       m0.project(1.0D, scalar, perturbation);
/*     */ 
/*     */       
/* 160 */       m0.constrain();
/*     */       
/* 162 */       perturbation.dispose();
/* 163 */       transformQuadratic.dispose();
/*     */       
/* 165 */       monitor.report(end);
/*     */     } 
/* 167 */     monitor.report(1.0D);
/* 168 */     return m0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TransformFunction
/*     */     implements ScalarSolver.Function
/*     */   {
/*     */     VectConst _data;
/*     */ 
/*     */     
/*     */     VectConst _referenceModel;
/*     */ 
/*     */     
/*     */     VectConst _perturbation;
/*     */ 
/*     */     
/*     */     Vect _model;
/*     */ 
/*     */     
/*     */     TransformQuadratic _transformQuadratic;
/*     */ 
/*     */     
/*     */     public TransformFunction(Transform transform, VectConst data, VectConst referenceModel, VectConst perturbation, boolean dampOnlyPerturbation) {
/* 192 */       this._data = data;
/* 193 */       this._referenceModel = referenceModel;
/* 194 */       this._model = this._referenceModel.clone();
/* 195 */       this._perturbation = perturbation;
/* 196 */       this._transformQuadratic = new TransformQuadratic(data, referenceModel, null, transform, dampOnlyPerturbation);
/*     */     }
/*     */ 
/*     */     
/*     */     public double function(double scalar) {
/* 201 */       VectUtil.copy(this._model, this._referenceModel);
/* 202 */       this._model.project(1.0D, scalar, this._perturbation);
/* 203 */       double result = this._transformQuadratic.evalFullObjectiveFunction(this._model);
/* 204 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 209 */       this._model.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setExpensiveDebug(boolean debug) {
/* 217 */     s_expensiveDebug = debug;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/GaussNewtonSolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */