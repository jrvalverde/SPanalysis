/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import edu.mines.jtk.util.MathPlus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SamplingBench
/*    */ {
/*    */   public static void main(String[] args) {
/* 19 */     float f = 0.0F;
/* 20 */     float d = 0.33333334F;
/* 21 */     int n = 10000;
/* 22 */     double errorMaximum = 0.0D;
/* 23 */     float x = f;
/* 24 */     for (int i = 0; i < n; i++, x += d) {
/* 25 */       double xd = (f + i * d);
/* 26 */       errorMaximum = MathPlus.max(errorMaximum, MathPlus.abs(xd - x));
/*    */     } 
/* 28 */     double xf = f;
/* 29 */     double xl = (f + (n - 1) * d);
/* 30 */     double errorEstimate = (1.1920929E-7F * n) * (MathPlus.abs(xf) + MathPlus.abs(xl)) / 2.0D;
/* 31 */     System.out.println("error estimate =" + (errorEstimate / d));
/* 32 */     System.out.println("error maximum  =" + (errorMaximum / d));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/SamplingBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */