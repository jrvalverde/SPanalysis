/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineState
/*     */   implements State
/*     */ {
/*     */   public boolean hasSmooth() {
/*  29 */     return this._smoothSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSmooth() {
/*  37 */     return this._smooth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSmooth(boolean smooth) {
/*  45 */     this._smooth = smooth;
/*  46 */     this._smoothSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSmooth() {
/*  53 */     this._smooth = _smoothDefault;
/*  54 */     this._smoothSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasStipple() {
/*  62 */     return this._stippleSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStippleFactor() {
/*  70 */     return this._factor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getStipplePattern() {
/*  78 */     return this._pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStipple(int factor, short pattern) {
/*  87 */     this._factor = factor;
/*  88 */     this._pattern = pattern;
/*  89 */     this._stippleSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetStipple() {
/*  96 */     this._factor = _factorDefault;
/*  97 */     this._pattern = _patternDefault;
/*  98 */     this._stippleSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasWidth() {
/* 106 */     return this._widthSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/* 114 */     return this._width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(float width) {
/* 122 */     this._width = width;
/* 123 */     this._widthSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetWidth() {
/* 130 */     this._width = _widthDefault;
/* 131 */     this._widthSet = false;
/*     */   }
/*     */   
/*     */   public void apply() {
/* 135 */     if (this._smoothSet) {
/* 136 */       if (this._smooth) {
/* 137 */         Gl.glEnable(2848);
/*     */       } else {
/* 139 */         Gl.glDisable(2848);
/*     */       } 
/*     */     }
/* 142 */     if (this._stippleSet) {
/* 143 */       Gl.glEnable(2852);
/* 144 */       Gl.glLineStipple(this._factor, this._pattern);
/*     */     } 
/* 146 */     if (this._widthSet)
/* 147 */       Gl.glLineWidth(this._width); 
/*     */   }
/*     */   
/*     */   public int getAttributeBits() {
/* 151 */     return 8196;
/*     */   }
/*     */   
/*     */   private static boolean _smoothDefault = false;
/* 155 */   private boolean _smooth = _smoothDefault;
/*     */   
/*     */   private boolean _smoothSet;
/* 158 */   private static int _factorDefault = 1;
/* 159 */   private int _factor = _factorDefault;
/* 160 */   private static short _patternDefault = -1;
/* 161 */   private short _pattern = _patternDefault;
/*     */   
/*     */   private boolean _stippleSet;
/* 164 */   private static float _widthDefault = 1.0F;
/* 165 */   private float _width = _widthDefault;
/*     */   private boolean _widthSet;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/LineState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */