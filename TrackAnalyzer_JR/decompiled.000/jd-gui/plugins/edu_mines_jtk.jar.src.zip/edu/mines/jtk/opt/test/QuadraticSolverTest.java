/*     */ package edu.mines.jtk.opt.test;
/*     */ 
/*     */ import edu.mines.jtk.opt.ArrayVect1;
/*     */ import edu.mines.jtk.opt.Quadratic;
/*     */ import edu.mines.jtk.opt.QuadraticSolver;
/*     */ import edu.mines.jtk.opt.Vect;
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ public class QuadraticSolverTest
/*     */   extends TestCase
/*     */ {
/*  21 */   private static final String NL = System.getProperty("line.separator");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testQS() {
/*  30 */     Quadratic q = new Quadratic() {
/*     */         public void multiplyHessian(Vect x) {
/*  32 */           double[] data = ((ArrayVect1)x).getData();
/*  33 */           double[] newData = new double[data.length];
/*  34 */           newData[0] = 2.0D * data[0] + 4.0D * data[1];
/*  35 */           newData[1] = 4.0D * data[0] + 11.0D * data[1];
/*  36 */           data[0] = newData[0];
/*  37 */           data[1] = newData[1];
/*     */         }
/*     */         
/*     */         public Vect getB() {
/*  41 */           return (Vect)new QuadraticSolverTest.TestVect(new double[] { 2.0D, 1.0D }, 1.0D);
/*     */         } public void inverseHessian(Vect x) {}
/*     */       };
/*  44 */     QuadraticSolver qs = new QuadraticSolver(q);
/*     */ 
/*     */     
/*  47 */     ArrayVect1 result = (ArrayVect1)qs.solve(1, null);
/*  48 */     assert !Almost.FLOAT.equal(-3.0D, result.getData()[0]) : "result=" + result;
/*  49 */     assert !Almost.FLOAT.equal(1.0D, result.getData()[1]) : "result=" + result;
/*  50 */     result.dispose();
/*     */ 
/*     */     
/*  53 */     result = (ArrayVect1)qs.solve(2, null);
/*  54 */     assert Almost.FLOAT.equal(-3.0D, result.getData()[0]) : "result=" + result;
/*  55 */     assert Almost.FLOAT.equal(1.0D, result.getData()[1]) : "result=" + result;
/*  56 */     result.dispose();
/*     */ 
/*     */     
/*  59 */     result = (ArrayVect1)qs.solve(20, null);
/*  60 */     assert Almost.FLOAT.equal(-3.0D, result.getData()[0]) : "result=" + result;
/*  61 */     assert Almost.FLOAT.equal(1.0D, result.getData()[1]) : "result=" + result;
/*  62 */     result.dispose();
/*     */     
/*  64 */     assert TestVect.undisposed.size() == 0 : TestVect.getTraces();
/*     */     
/*  66 */     assert TestVect.max <= 5 : "max number of model vectors (" + TestVect.max + ") should be less than 5";
/*     */   }
/*     */   
/*     */   private static class TestVect
/*     */     extends ArrayVect1
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*  73 */     public static int max = 0;
/*     */     
/*  75 */     public static Map<Object, String> undisposed = Collections.synchronizedMap(new HashMap<Object, String>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestVect(double[] data, double variance) {
/*  83 */       super(data, variance);
/*  84 */       remember(this);
/*     */     }
/*     */     
/*     */     public TestVect clone() {
/*  88 */       TestVect result = (TestVect)super.clone();
/*  89 */       remember(result);
/*  90 */       return result;
/*     */     }
/*     */     private void remember(Object tv) {
/*  93 */       synchronized (undisposed) {
/*  94 */         StringWriter sw = new StringWriter();
/*  95 */         PrintWriter pw = new PrintWriter(sw);
/*  96 */         (new Exception("This vector was never disposed")).printStackTrace(pw);
/*  97 */         pw.flush();
/*  98 */         undisposed.put(tv, sw.toString());
/*  99 */         max = Math.max(max, undisposed.size());
/*     */       } 
/*     */     }
/*     */     
/*     */     public void dispose() {
/* 104 */       synchronized (undisposed) {
/* 105 */         super.dispose();
/* 106 */         undisposed.remove(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public static String getTraces() {
/* 112 */       StringBuilder sb = new StringBuilder();
/* 113 */       for (String s : undisposed.values()) {
/* 114 */         sb.append(s);
/* 115 */         sb.append(QuadraticSolverTest.NL);
/*     */       } 
/* 117 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {
/* 124 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/* 127 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuadraticSolverTest(String name) {
/* 134 */     super(name);
/*     */   }
/*     */   
/*     */   public static Test suite() {
/*     */     try {
/*     */       assert false;
/* 140 */       throw new IllegalStateException("need -ea");
/* 141 */     } catch (AssertionError e) {
/* 142 */       return (Test)new TestSuite(QuadraticSolverTest.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 149 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/QuadraticSolverTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */