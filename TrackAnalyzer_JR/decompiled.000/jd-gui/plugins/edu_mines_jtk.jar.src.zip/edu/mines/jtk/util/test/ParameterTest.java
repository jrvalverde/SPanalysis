/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.Parameter;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 21 */     TestSuite suite = new TestSuite(ParameterTest.class);
/* 22 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testParameter() {
/* 26 */     Parameter par = new Parameter("fo<o", "Hello");
/* 27 */     assertTrue(par.getString().equals("Hello"));
/* 28 */     par.setString("true");
/* 29 */     assertTrue((par.getBoolean() == true));
/* 30 */     par.setString("3141");
/* 31 */     assertTrue((par.getInt() == 3141));
/* 32 */     par.setString("3141.0");
/* 33 */     assertTrue((par.getFloat() == 3141.0F));
/* 34 */     par.setString("3.141");
/* 35 */     assertTrue((par.getDouble() == 3.141D));
/* 36 */     double[] empty = new double[0];
/* 37 */     par.setDoubles(empty);
/* 38 */     assertTrue((par.getType() == 5));
/* 39 */     par.setFloats(null);
/* 40 */     assertTrue((par.getType() == 4));
/* 41 */     float[] fvalues = { 1.2F, 3.4F };
/* 42 */     par.setFloats(fvalues);
/* 43 */     fvalues = null;
/* 44 */     fvalues = par.getFloats();
/* 45 */     assertTrue((fvalues[0] == 1.2F));
/* 46 */     assertTrue((fvalues[1] == 3.4F));
/* 47 */     par.setUnits("km/s");
/* 48 */     assertTrue(par.getUnits().equals("km/s"));
/* 49 */     boolean[] bvalues = { true, false };
/* 50 */     par.setBooleans(bvalues);
/* 51 */     bvalues = null;
/* 52 */     bvalues = par.getBooleans();
/* 53 */     assertTrue((bvalues[0] == true));
/* 54 */     assertTrue(!bvalues[1]);
/* 55 */     par.setUnits(null);
/* 56 */     assertTrue((par.getUnits() == null));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/ParameterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */