/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Stopwatch
/*    */ {
/*    */   private boolean _running;
/*    */   private long _start;
/*    */   private long _time;
/*    */   
/*    */   public void start() {
/* 30 */     if (!this._running) {
/* 31 */       this._running = true;
/* 32 */       this._start = System.nanoTime();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 40 */     if (this._running) {
/* 41 */       this._time += System.nanoTime() - this._start;
/* 42 */       this._running = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 50 */     stop();
/* 51 */     this._time = 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void restart() {
/* 58 */     reset();
/* 59 */     start();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double time() {
/* 67 */     if (this._running) {
/* 68 */       return 1.0E-9D * (this._time + System.nanoTime() - this._start);
/*    */     }
/* 70 */     return 1.0E-9D * this._time;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Stopwatch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */