/*    */ package edu.mines.jtk.la.test;
/*    */ 
/*    */ import edu.mines.jtk.la.DMatrix;
/*    */ import edu.mines.jtk.la.DMatrixLud;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixLudTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(DMatrixLudTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSingular() {
/* 28 */     DMatrix a = new DMatrix(new double[][] { { 0.0D, 0.0D }, { 3.0D, 4.0D } });
/*    */ 
/*    */ 
/*    */     
/* 32 */     DMatrixLud lud = new DMatrixLud(a);
/* 33 */     assertTrue(lud.isSingular());
/* 34 */     assertFalse(lud.isNonSingular());
/*    */   }
/*    */   
/*    */   public void testSimple() {
/* 38 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D } }));
/*    */ 
/*    */ 
/*    */     
/* 42 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D }, { 5.0D, 6.0D } }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void testRandom() {
/* 50 */     test(DMatrix.random(100, 100));
/* 51 */     test(DMatrix.random(101, 100));
/*    */   }
/*    */   
/*    */   private void test(DMatrix a) {
/* 55 */     int m = a.getM();
/* 56 */     int n = a.getN();
/*    */     
/* 58 */     DMatrixLud lud = new DMatrixLud(a);
/* 59 */     int[] piv = lud.getPivot();
/* 60 */     DMatrix l = lud.getL();
/* 61 */     DMatrix u = lud.getU();
/* 62 */     DMatrix lu = l.times(u);
/* 63 */     DMatrixTest.assertEqualFuzzy(a.get(piv, null), lu);
/*    */     
/* 65 */     if (m == n) {
/* 66 */       int nrhs = 2;
/* 67 */       DMatrix b = DMatrix.random(m, nrhs);
/* 68 */       DMatrix x = lud.solve(b);
/* 69 */       DMatrix ax = a.times(x);
/* 70 */       DMatrixTest.assertEqualFuzzy(ax, b);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/test/DMatrixLudTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */