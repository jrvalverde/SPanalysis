/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CubicInterpolator
/*     */ {
/*     */   private static final float FLT_O2 = 0.5F;
/*     */   private static final float FLT_O6 = 0.16666667F;
/*     */   private int _index;
/*     */   private float[] _xd;
/*     */   private float[][] _yd;
/*     */   
/*     */   public enum Method
/*     */   {
/*  50 */     LINEAR,
/*  51 */     MONOTONIC,
/*  52 */     SPLINE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CubicInterpolator(Method method, int n, float[] x, float[] y) {
/*  66 */     Check.argument(Array.isMonotonic(x), "array x is monotonic");
/*  67 */     this._xd = new float[n];
/*  68 */     this._yd = new float[n][4];
/*  69 */     for (int i = 0; i < n; i++) {
/*  70 */       this._xd[i] = x[i];
/*  71 */       this._yd[i][0] = y[i];
/*     */     } 
/*  73 */     if (method == Method.LINEAR) {
/*  74 */       initLinear(n, this._xd, this._yd);
/*  75 */     } else if (method == Method.MONOTONIC) {
/*  76 */       initMonotonic(n, this._xd, this._yd);
/*  77 */     } else if (method == Method.SPLINE) {
/*  78 */       initSpline(n, this._xd, this._yd);
/*     */     } else {
/*     */       assert false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float interpolate(float x) {
/*  90 */     int i = index(x);
/*  91 */     float[] yd = this._yd[i];
/*  92 */     float delx = x - this._xd[i];
/*  93 */     return yd[0] + delx * (yd[1] + delx * (yd[2] * 0.5F + delx * yd[3] * 0.16666667F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float interpolate1(float x) {
/* 103 */     int i = index(x);
/* 104 */     float[] yd = this._yd[i];
/* 105 */     float delx = x - this._xd[i];
/* 106 */     return yd[1] + delx * (yd[2] + delx * yd[3] * 0.5F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float interpolate2(float x) {
/* 115 */     int i = index(x);
/* 116 */     float[] yd = this._yd[i];
/* 117 */     float delx = x - this._xd[i];
/* 118 */     return yd[2] + delx * yd[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final float interpolate3(float x) {
/* 127 */     int i = index(x);
/* 128 */     float[] yd = this._yd[i];
/* 129 */     return yd[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpolate(int n, float[] x, float[] y) {
/* 139 */     for (int i = 0; i < n; i++) {
/* 140 */       y[i] = interpolate(x[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpolate1(int n, float[] x, float[] y) {
/* 150 */     for (int i = 0; i < n; i++) {
/* 151 */       y[i] = interpolate1(x[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpolate2(int n, float[] x, float[] y) {
/* 161 */     for (int i = 0; i < n; i++) {
/* 162 */       y[i] = interpolate2(x[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpolate3(int n, float[] x, float[] y) {
/* 172 */     for (int i = 0; i < n; i++) {
/* 173 */       y[i] = interpolate3(x[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index(float x) {
/* 187 */     int index = Array.binarySearch(this._xd, x, this._index);
/* 188 */     if (index < 0)
/* 189 */       index = (index < -1) ? (-2 - index) : 0; 
/* 190 */     this._index = index;
/* 191 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initLinear(int n, float[] x, float[][] y) {
/* 200 */     if (n == 1) {
/* 201 */       y[0][1] = 0.0F;
/* 202 */       y[0][2] = 0.0F;
/* 203 */       y[0][3] = 0.0F;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 208 */     for (int i = 0; i < n - 1; i++) {
/* 209 */       y[i][1] = (y[i + 1][0] - y[i][0]) / (x[i + 1] - x[i]);
/* 210 */       y[i][3] = 0.0F; y[i][2] = 0.0F;
/*     */     } 
/* 212 */     y[n - 1][1] = y[n - 2][1];
/* 213 */     y[n - 1][3] = 0.0F; y[n - 1][2] = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initMonotonic(int n, float[] x, float[][] y) {
/* 239 */     if (n == 1) {
/* 240 */       y[0][1] = 0.0F;
/* 241 */       y[0][2] = 0.0F;
/* 242 */       y[0][3] = 0.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 246 */     if (n == 2) {
/* 247 */       y[1][1] = (y[1][0] - y[0][0]) / (x[1] - x[0]); y[0][1] = (y[1][0] - y[0][0]) / (x[1] - x[0]);
/* 248 */       y[1][2] = 0.0F; y[0][2] = 0.0F;
/* 249 */       y[1][3] = 0.0F; y[0][3] = 0.0F;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 254 */     float h1 = x[1] - x[0];
/* 255 */     float h2 = x[2] - x[1];
/* 256 */     float hsum = h1 + h2;
/* 257 */     float del1 = (y[1][0] - y[0][0]) / h1;
/* 258 */     float del2 = (y[2][0] - y[1][0]) / h2;
/* 259 */     float w1 = (h1 + hsum) / hsum;
/* 260 */     float w2 = -h1 / hsum;
/* 261 */     y[0][1] = w1 * del1 + w2 * del2;
/* 262 */     if (y[0][1] * del1 <= 0.0F) {
/* 263 */       y[0][1] = 0.0F;
/* 264 */     } else if (del1 * del2 < 0.0F) {
/* 265 */       float dmax = 3.0F * del1;
/* 266 */       if (MathPlus.abs(y[0][1]) > MathPlus.abs(dmax)) y[0][1] = dmax;
/*     */     
/*     */     } 
/*     */     int i;
/* 270 */     for (i = 1; i < n - 1; i++) {
/*     */ 
/*     */       
/* 273 */       h1 = x[i] - x[i - 1];
/* 274 */       h2 = x[i + 1] - x[i];
/* 275 */       hsum = h1 + h2;
/* 276 */       del1 = (y[i][0] - y[i - 1][0]) / h1;
/* 277 */       del2 = (y[i + 1][0] - y[i][0]) / h2;
/*     */ 
/*     */       
/* 280 */       if (del1 * del2 <= 0.0F) {
/* 281 */         y[i][1] = 0.0F;
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 289 */         float hsum3 = hsum + hsum + hsum;
/* 290 */         w1 = (hsum + h1) / hsum3;
/* 291 */         w2 = (hsum + h2) / hsum3;
/* 292 */         float dmin = MathPlus.min(MathPlus.abs(del1), MathPlus.abs(del2));
/* 293 */         float dmax = MathPlus.max(MathPlus.abs(del1), MathPlus.abs(del2));
/* 294 */         float drat1 = del1 / dmax;
/* 295 */         float drat2 = del2 / dmax;
/* 296 */         y[i][1] = dmin / (w1 * drat1 + w2 * drat2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 301 */     w1 = -h2 / hsum;
/* 302 */     w2 = (h2 + hsum) / hsum;
/* 303 */     y[n - 1][1] = w1 * del1 + w2 * del2;
/* 304 */     if (y[n - 1][1] * del2 <= 0.0F) {
/* 305 */       y[n - 1][1] = 0.0F;
/* 306 */     } else if (del1 * del2 < 0.0F) {
/* 307 */       float dmax = 3.0F * del2;
/* 308 */       if (MathPlus.abs(y[n - 1][1]) > MathPlus.abs(dmax)) y[n - 1][1] = dmax;
/*     */     
/*     */     } 
/*     */     
/* 312 */     for (i = 0; i < n - 1; i++) {
/* 313 */       h2 = x[i + 1] - x[i];
/* 314 */       del2 = (y[i + 1][0] - y[i][0]) / h2;
/* 315 */       float divdf3 = y[i][1] + y[i + 1][1] - 2.0F * del2;
/* 316 */       y[i][2] = 2.0F * (del2 - y[i][1] - divdf3) / h2;
/* 317 */       y[i][3] = divdf3 / h2 * 6.0F / h2;
/*     */     } 
/* 319 */     y[n - 1][2] = y[n - 2][2] + (x[n - 1] - x[n - 2]) * y[n - 2][3];
/* 320 */     y[n - 1][3] = y[n - 2][3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initSpline(int n, float[] x, float[][] y) {
/* 333 */     if (n == 1) {
/* 334 */       y[0][1] = 0.0F;
/* 335 */       y[0][2] = 0.0F;
/* 336 */       y[0][3] = 0.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 340 */     if (n == 2) {
/* 341 */       y[1][1] = (y[1][0] - y[0][0]) / (x[1] - x[0]); y[0][1] = (y[1][0] - y[0][0]) / (x[1] - x[0]);
/* 342 */       y[1][2] = 0.0F; y[0][2] = 0.0F;
/* 343 */       y[1][3] = 0.0F; y[0][3] = 0.0F;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 348 */     float h1 = x[1] - x[0];
/* 349 */     float h2 = x[2] - x[1];
/* 350 */     float hsum = h1 + h2;
/* 351 */     float del1 = (y[1][0] - y[0][0]) / h1;
/* 352 */     float del2 = (y[2][0] - y[1][0]) / h2;
/* 353 */     float w1 = (h1 + hsum) / hsum;
/* 354 */     float w2 = -h1 / hsum;
/* 355 */     float sleft = w1 * del1 + w2 * del2;
/* 356 */     if (sleft * del1 <= 0.0F) {
/* 357 */       sleft = 0.0F;
/* 358 */     } else if (del1 * del2 < 0.0F) {
/* 359 */       float dmax = 3.0F * del1;
/* 360 */       if (MathPlus.abs(sleft) > MathPlus.abs(dmax)) sleft = dmax;
/*     */     
/*     */     } 
/*     */     
/* 364 */     h1 = x[n - 2] - x[n - 3];
/* 365 */     h2 = x[n - 1] - x[n - 2];
/* 366 */     hsum = h1 + h2;
/* 367 */     del1 = (y[n - 2][0] - y[n - 3][0]) / h1;
/* 368 */     del2 = (y[n - 1][0] - y[n - 2][0]) / h2;
/* 369 */     w1 = -h2 / hsum;
/* 370 */     w2 = (h2 + hsum) / hsum;
/* 371 */     float sright = w1 * del1 + w2 * del2;
/* 372 */     if (sright * del2 <= 0.0F) {
/* 373 */       sright = 0.0F;
/* 374 */     } else if (del1 * del2 < 0.0F) {
/* 375 */       float dmax = 3.0F * del2;
/* 376 */       if (MathPlus.abs(sright) > MathPlus.abs(dmax)) sright = dmax;
/*     */     
/*     */     } 
/*     */     
/* 380 */     float[] work = new float[n];
/* 381 */     work[0] = 1.0F;
/* 382 */     y[0][2] = 2.0F * sleft; int i;
/* 383 */     for (i = 1; i < n - 1; i++) {
/* 384 */       h1 = x[i] - x[i - 1];
/* 385 */       h2 = x[i + 1] - x[i];
/* 386 */       del1 = (y[i][0] - y[i - 1][0]) / h1;
/* 387 */       del2 = (y[i + 1][0] - y[i][0]) / h2;
/* 388 */       float alpha = h2 / (h1 + h2);
/* 389 */       work[i] = alpha;
/* 390 */       y[i][2] = 3.0F * (alpha * del1 + (1.0F - alpha) * del2);
/*     */     } 
/* 392 */     work[n - 1] = 0.0F;
/* 393 */     y[n - 1][2] = 2.0F * sright;
/*     */ 
/*     */     
/* 396 */     float t = 2.0F;
/* 397 */     y[0][1] = y[0][2] / t;
/* 398 */     for (i = 1; i < n; i++) {
/* 399 */       y[i][3] = (1.0F - work[i - 1]) / t;
/* 400 */       t = 2.0F - work[i] * y[i][3];
/* 401 */       y[i][1] = (y[i][2] - work[i] * y[i - 1][1]) / t;
/*     */     } 
/* 403 */     for (i = n - 2; i >= 0; ) { y[i][1] = y[i][1] - y[i + 1][3] * y[i + 1][1]; i--; }
/*     */ 
/*     */     
/* 406 */     for (i = 0; i < n - 1; i++) {
/* 407 */       h2 = x[i + 1] - x[i];
/* 408 */       del2 = (y[i + 1][0] - y[i][0]) / h2;
/* 409 */       float divdf3 = y[i][1] + y[i + 1][1] - 2.0F * del2;
/* 410 */       y[i][2] = 2.0F * (del2 - y[i][1] - divdf3) / h2;
/* 411 */       y[i][3] = divdf3 / h2 * 6.0F / h2;
/*     */     } 
/* 413 */     y[n - 1][2] = y[n - 2][2] + (x[n - 1] - x[n - 2]) * y[n - 2][3];
/* 414 */     y[n - 1][3] = y[n - 2][3];
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/CubicInterpolator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */