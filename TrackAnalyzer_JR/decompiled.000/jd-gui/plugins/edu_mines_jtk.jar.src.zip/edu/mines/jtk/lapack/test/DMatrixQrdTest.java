/*    */ package edu.mines.jtk.lapack.test;
/*    */ 
/*    */ import edu.mines.jtk.lapack.DMatrix;
/*    */ import edu.mines.jtk.lapack.DMatrixQrd;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixQrdTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(DMatrixQrdTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testRankDeficient() {
/* 28 */     DMatrix a = new DMatrix(new double[][] { { 0.0D, 0.0D }, { 3.0D, 4.0D } });
/*    */ 
/*    */ 
/*    */     
/* 32 */     DMatrixQrd qrd = new DMatrixQrd(a);
/* 33 */     assertFalse(qrd.isFullRank());
/*    */   }
/*    */   
/*    */   public void testSimple() {
/* 37 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D } }));
/*    */ 
/*    */ 
/*    */     
/* 41 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D }, { 5.0D, 6.0D } }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void testRandom() {
/* 49 */     test(DMatrix.random(100, 100));
/* 50 */     test(DMatrix.random(101, 100));
/*    */   }
/*    */   
/*    */   private void test(DMatrix a) {
/* 54 */     int m = a.getM();
/* 55 */     int n = a.getN();
/*    */     
/* 57 */     DMatrixQrd qrd = new DMatrixQrd(a);
/* 58 */     DMatrix q = qrd.getQ();
/* 59 */     DMatrix r = qrd.getR();
/* 60 */     DMatrix qr = q.times(r);
/* 61 */     DMatrixTest.assertEqualFuzzy(a, qr);
/*    */     
/* 63 */     if (m == n) {
/* 64 */       int nrhs = 2;
/* 65 */       DMatrix b = DMatrix.random(m, nrhs);
/* 66 */       DMatrix x = qrd.solve(b);
/* 67 */       DMatrix ax = a.times(x);
/* 68 */       DMatrixTest.assertEqualFuzzy(ax, b);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/DMatrixQrdTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */