/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.awt.ColorMap;
/*     */ import edu.mines.jtk.awt.ColorMapListener;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Clips;
/*     */ import edu.mines.jtk.util.Float3;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImagePanelGroup
/*     */   extends Group
/*     */ {
/*     */   private Sampling _sx;
/*     */   private Sampling _sy;
/*     */   private Sampling _sz;
/*     */   private Float3 _f3;
/*     */   private ArrayList<ImagePanel> _ipList;
/*     */   Clips _clips;
/*     */   private ColorMap _colorMap;
/*     */   
/*     */   public ImagePanelGroup(Sampling sx, Sampling sy, Sampling sz, Float3 f3) {
/*  42 */     this(sx, sy, sz, f3, new Axis[] { Axis.X, Axis.Y, Axis.Z });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePanelGroup(Sampling sx, Sampling sy, Sampling sz, Float3 f3, Axis[] axes) {
/* 205 */     this._colorMap = new ColorMap(0.0D, 1.0D, ColorMap.GRAY);
/*     */     this._clips = new Clips(f3);
/*     */     addPanels(sx, sy, sz, f3, axes);
/*     */   }
/*     */   private void addPanels(Sampling sx, Sampling sy, Sampling sz, Float3 f3, Axis[] axes) {
/* 210 */     this._sx = sx;
/* 211 */     this._sy = sy;
/* 212 */     this._sz = sz;
/* 213 */     this._f3 = f3;
/* 214 */     int nx = sx.getCount();
/* 215 */     int ny = sy.getCount();
/* 216 */     int nz = sz.getCount();
/* 217 */     double dx = sx.getDelta();
/* 218 */     double dy = sy.getDelta();
/* 219 */     double dz = sz.getDelta();
/* 220 */     double fx = sx.getFirst();
/* 221 */     double fy = sy.getFirst();
/* 222 */     double fz = sz.getFirst();
/* 223 */     double lx = fx + (nx - 1) * dx;
/* 224 */     double ly = fy + (ny - 1) * dy;
/* 225 */     double lz = fz + (nz - 1) * dz;
/* 226 */     Point3 qmin = new Point3(fx, fy, fz);
/* 227 */     Point3 qmax = new Point3(lx, ly, lz);
/* 228 */     int np = axes.length;
/* 229 */     this._ipList = new ArrayList<ImagePanel>(np);
/* 230 */     for (int jp = 0; jp < np; jp++) {
/* 231 */       AxisAlignedQuad aaq = new AxisAlignedQuad(axes[jp], qmin, qmax);
/* 232 */       ImagePanel ip = new ImagePanel(sx, sy, sz, f3);
/* 233 */       ip.setColorModel(getColorModel());
/* 234 */       aaq.getFrame().addChild(ip);
/* 235 */       addChild(aaq);
/* 236 */       this._ipList.add(ip);
/*     */     } 
/*     */   }
/*     */   
/*     */   public ImagePanel getImagePanel(Axis axis) {
/*     */     for (ImagePanel ip : this._ipList) {
/*     */       if (axis == ip.getFrame().getAxis())
/*     */         return ip; 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public Iterator<ImagePanel> getImagePanels() {
/*     */     return this._ipList.iterator();
/*     */   }
/*     */   
/*     */   public void setColorModel(IndexColorModel colorModel) {
/*     */     this._colorMap.setColorModel(colorModel);
/*     */     for (ImagePanel ip : this._ipList)
/*     */       ip.setColorModel(colorModel); 
/*     */   }
/*     */   
/*     */   public IndexColorModel getColorModel() {
/*     */     return this._colorMap.getColorModel();
/*     */   }
/*     */   
/*     */   public void setClips(double clipMin, double clipMax) {
/*     */     this._clips.setClips(clipMin, clipMax);
/*     */     clipMin = this._clips.getClipMin();
/*     */     clipMax = this._clips.getClipMax();
/*     */     for (ImagePanel ip : this._ipList)
/*     */       ip.setClips(clipMin, clipMax); 
/*     */     this._colorMap.setValueRange(clipMin, clipMax);
/*     */   }
/*     */   
/*     */   public float getClipMin() {
/*     */     return this._clips.getClipMin();
/*     */   }
/*     */   
/*     */   public float getClipMax() {
/*     */     return this._clips.getClipMax();
/*     */   }
/*     */   
/*     */   public void setPercentiles(double percMin, double percMax) {
/*     */     this._clips.setPercentiles(percMin, percMax);
/*     */     double clipMin = this._clips.getClipMin();
/*     */     double clipMax = this._clips.getClipMax();
/*     */     System.out.println("clip min=" + clipMin + " max=" + clipMax);
/*     */     for (ImagePanel ip : this._ipList)
/*     */       ip.setClips(clipMin, clipMax); 
/*     */     this._colorMap.setValueRange(clipMin, clipMax);
/*     */   }
/*     */   
/*     */   public float getPercentileMin() {
/*     */     return this._clips.getPercentileMin();
/*     */   }
/*     */   
/*     */   public float getPercentileMax() {
/*     */     return this._clips.getPercentileMax();
/*     */   }
/*     */   
/*     */   public void addColorMapListener(ColorMapListener cml) {
/*     */     this._colorMap.addListener(cml);
/*     */   }
/*     */   
/*     */   public void removeColorMapListener(ColorMapListener cml) {
/*     */     this._colorMap.removeListener(cml);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/ImagePanelGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */