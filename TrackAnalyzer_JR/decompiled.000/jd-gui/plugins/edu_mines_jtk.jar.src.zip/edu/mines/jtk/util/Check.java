/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Check
/*     */ {
/*     */   private static byte _b;
/*     */   private static short _s;
/*     */   private static int _i;
/*     */   private static long _l;
/*     */   private static float _f;
/*     */   private static double _d;
/*     */   
/*     */   public static void argument(boolean condition, String message) {
/*  24 */     if (!condition) {
/*  25 */       throw new IllegalArgumentException("required condition: " + message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void state(boolean condition, String message) {
/*  35 */     if (!condition) {
/*  36 */       throw new IllegalStateException("required condition: " + message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(int n, int i) {
/*  46 */     if (i < 0)
/*  47 */       throw new IndexOutOfBoundsException("index i=" + i + " < 0"); 
/*  48 */     if (n <= i) {
/*  49 */       throw new IndexOutOfBoundsException("index i=" + i + " >= n=" + n);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(byte[] a, int i) {
/*  59 */     _b = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(short[] a, int i) {
/*  69 */     _s = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(int[] a, int i) {
/*  79 */     _i = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(long[] a, int i) {
/*  89 */     _l = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(float[] a, int i) {
/*  99 */     _f = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void index(double[] a, int i) {
/* 109 */     _d = a[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Check() {
/* 121 */     System.out.println(_b);
/* 122 */     System.out.println(_s);
/* 123 */     System.out.println(_i);
/* 124 */     System.out.println(_l);
/* 125 */     System.out.println(_f);
/* 126 */     System.out.println(_d);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Check.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */