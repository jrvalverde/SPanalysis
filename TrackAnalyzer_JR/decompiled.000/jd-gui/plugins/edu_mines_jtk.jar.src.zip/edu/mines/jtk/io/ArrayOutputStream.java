/*     */ package edu.mines.jtk.io;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayOutputStream
/*     */   extends FilterOutputStream
/*     */   implements ArrayOutput
/*     */ {
/*     */   private ArrayOutput _ao;
/*     */   private ByteOrder _bo;
/*     */   
/*     */   public ArrayOutputStream(OutputStream os) {
/*  28 */     this(os, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(FileOutputStream fos) {
/*  38 */     this(fos, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(String name) throws FileNotFoundException {
/*  47 */     this(new FileOutputStream(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(File file) throws FileNotFoundException {
/*  56 */     this(new FileOutputStream(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(OutputStream os, ByteOrder bo) {
/*  65 */     super(os);
/*  66 */     this._ao = new ArrayOutputAdapter(new DataOutputStream(os), bo);
/*  67 */     this._bo = bo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(FileOutputStream fos, ByteOrder bo) {
/*  78 */     super(fos);
/*  79 */     this._ao = new ArrayOutputAdapter(fos.getChannel(), new DataOutputStream(fos), bo);
/*     */     
/*  81 */     this._bo = bo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(String name, ByteOrder bo) throws FileNotFoundException {
/*  94 */     this(new FileOutputStream(name), bo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayOutputStream(File file, ByteOrder bo) throws FileNotFoundException {
/* 106 */     this(new FileOutputStream(file), bo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrder() {
/* 114 */     return this._bo;
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException {
/* 118 */     this._ao.write(b);
/*     */   }
/*     */   public void write(byte[] b) throws IOException {
/* 121 */     this._ao.write(b);
/*     */   }
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 124 */     this._ao.write(b, off, len);
/*     */   }
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 127 */     this._ao.writeBoolean(v);
/*     */   }
/*     */   public void writeByte(int v) throws IOException {
/* 130 */     this._ao.writeByte(v);
/*     */   }
/*     */   public void writeShort(int v) throws IOException {
/* 133 */     this._ao.writeShort(v);
/*     */   }
/*     */   public void writeChar(int v) throws IOException {
/* 136 */     this._ao.writeChar(v);
/*     */   }
/*     */   public void writeInt(int v) throws IOException {
/* 139 */     this._ao.writeInt(v);
/*     */   }
/*     */   public void writeLong(long v) throws IOException {
/* 142 */     this._ao.writeLong(v);
/*     */   }
/*     */   public void writeFloat(float v) throws IOException {
/* 145 */     this._ao.writeFloat(v);
/*     */   }
/*     */   public void writeDouble(double v) throws IOException {
/* 148 */     this._ao.writeDouble(v);
/*     */   }
/*     */   public void writeBytes(String s) throws IOException {
/* 151 */     this._ao.writeBytes(s);
/*     */   }
/*     */   public void writeChars(String s) throws IOException {
/* 154 */     this._ao.writeChars(s);
/*     */   }
/*     */   public void writeUTF(String s) throws IOException {
/* 157 */     this._ao.writeUTF(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v, int k, int n) throws IOException {
/* 167 */     this._ao.writeBytes(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v) throws IOException {
/* 176 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][] v) throws IOException {
/* 184 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][][] v) throws IOException {
/* 192 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v, int k, int n) throws IOException {
/* 202 */     this._ao.writeChars(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v) throws IOException {
/* 211 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][] v) throws IOException {
/* 219 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][][] v) throws IOException {
/* 227 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v, int k, int n) throws IOException {
/* 237 */     this._ao.writeShorts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v) throws IOException {
/* 246 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][] v) throws IOException {
/* 254 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][][] v) throws IOException {
/* 262 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v, int k, int n) throws IOException {
/* 272 */     this._ao.writeInts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v) throws IOException {
/* 281 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][] v) throws IOException {
/* 289 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][][] v) throws IOException {
/* 297 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v, int k, int n) throws IOException {
/* 307 */     this._ao.writeLongs(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v) throws IOException {
/* 316 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][] v) throws IOException {
/* 324 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][][] v) throws IOException {
/* 332 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v, int k, int n) throws IOException {
/* 342 */     this._ao.writeFloats(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v) throws IOException {
/* 351 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][] v) throws IOException {
/* 359 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][][] v) throws IOException {
/* 367 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v, int k, int n) throws IOException {
/* 377 */     this._ao.writeDoubles(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v) throws IOException {
/* 386 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][] v) throws IOException {
/* 394 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][][] v) throws IOException {
/* 402 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/ArrayOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */