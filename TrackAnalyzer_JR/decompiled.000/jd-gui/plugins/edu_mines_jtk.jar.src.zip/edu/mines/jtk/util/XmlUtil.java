/*    */ package edu.mines.jtk.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class XmlUtil
/*    */ {
/*    */   public static String quoteAttributeValue(String s) {
/* 24 */     if (s == null) return null; 
/* 25 */     s = replaceAll("&", "&amp;", s);
/* 26 */     s = replaceAll("<", "&lt;", s);
/* 27 */     s = replaceAll("\r", "&#13;", s);
/* 28 */     s = replaceAll("\n", "&#10;", s);
/* 29 */     s = replaceAll("\t", "&#9;", s);
/* 30 */     String quote = "\"";
/* 31 */     if (s.indexOf("\"") >= 0 && s.indexOf("'") < 0) {
/* 32 */       quote = "'";
/*    */     } else {
/* 34 */       s = replaceAll("\"", "&quot;", s);
/*    */     } 
/* 36 */     return quote + s + quote;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String quoteCharacterData(String s) {
/* 47 */     char space = ' ';
/* 48 */     if (s == null) return null; 
/* 49 */     s = replaceAll("&", "&amp;", s);
/* 50 */     s = replaceAll("<", "&lt;", s);
/* 51 */     s = replaceAll("\\", "\\\\", s);
/* 52 */     s = replaceAll("\r", "\\r", s);
/* 53 */     s = replaceAll("\n", "\\n", s);
/* 54 */     s = replaceAll("\t", "\\t", s);
/* 55 */     s = replaceAll("\"", "\\\"", s);
/* 56 */     s = replaceAll("'", "\\'", s);
/* 57 */     String quote = "";
/* 58 */     if (s.length() == 0) {
/* 59 */       quote = "\"";
/*    */     } else {
/* 61 */       for (int i = 0; i < s.length(); i++) {
/* 62 */         if (s.charAt(i) <= ' ') {
/* 63 */           quote = "\"";
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     } 
/* 68 */     return quote + s + quote;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String replaceAll(String x, String y, String s) {
/* 79 */     if (s == null) return null; 
/* 80 */     int from = 0;
/* 81 */     int to = s.indexOf(x, from);
/* 82 */     if (to < 0) return s; 
/* 83 */     StringBuffer d = new StringBuffer(s.length() + 32);
/* 84 */     while (to >= 0) {
/* 85 */       d.append(s.substring(from, to));
/* 86 */       d.append(y);
/* 87 */       from = to + x.length();
/* 88 */       to = s.indexOf(x, from);
/*    */     } 
/* 90 */     return d.append(s.substring(from)).toString();
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/XmlUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */