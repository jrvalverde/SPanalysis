/*    */ package edu.mines.jtk.lapack;
/*    */ 
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Check;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixChd
/*    */ {
/*    */   private int _n;
/*    */   private double[] _l;
/*    */   private double _det;
/*    */   private boolean _pd;
/*    */   
/*    */   public DMatrixChd(DMatrix a) {
/* 33 */     Check.argument(a.isSquare(), "A is square");
/* 34 */     this._n = a.getN();
/* 35 */     this._l = a.getPackedColumns();
/*    */ 
/*    */     
/* 38 */     for (int j = 0; j < this._n; j++) {
/* 39 */       for (int k = 0; k < j; k++) {
/* 40 */         this._l[k + j * this._n] = 0.0D;
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 45 */     int info = Lapack.dpotrf(122, this._n, this._l, this._n);
/* 46 */     this._pd = (info == 0);
/*    */     
/* 48 */     this._det = 1.0D;
/* 49 */     for (int i = 0; i < this._n; i++)
/* 50 */       this._det *= this._l[i + i * this._n]; 
/* 51 */     this._det *= this._det;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositiveDefinite() {
/* 62 */     return this._pd;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DMatrix getL() {
/* 70 */     return new DMatrix(this._n, this._n, Array.copy(this._l));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double det() {
/* 78 */     return this._det;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DMatrix solve(DMatrix b) {
/* 89 */     Check.argument((this._n == b.getM()), "A and B have same number of rows");
/* 90 */     Check.state(this._pd, "A is positive-definite");
/* 91 */     int n = this._n;
/* 92 */     int nrhs = b.getN();
/* 93 */     double[] aa = this._l;
/* 94 */     int lda = this._n;
/* 95 */     double[] ba = b.getPackedColumns();
/* 96 */     int ldb = this._n;
/* 97 */     Lapack.dpotrs(122, n, nrhs, aa, lda, ba, ldb);
/* 98 */     return new DMatrix(this._n, nrhs, ba);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrixChd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */