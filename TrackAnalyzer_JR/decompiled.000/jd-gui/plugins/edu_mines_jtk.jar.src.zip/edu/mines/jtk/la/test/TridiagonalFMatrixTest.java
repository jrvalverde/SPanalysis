/*    */ package edu.mines.jtk.la.test;
/*    */ 
/*    */ import edu.mines.jtk.la.TridiagonalFMatrix;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.MathPlus;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TridiagonalFMatrixTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(TridiagonalFMatrixTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSolve() {
/* 28 */     int n = 100;
/* 29 */     float[] a = Array.randfloat(n);
/* 30 */     float[] b = Array.randfloat(n);
/* 31 */     float[] c = Array.randfloat(n);
/* 32 */     for (int i = 0; i < n; i++)
/* 33 */       b[i] = b[i] + a[i] + c[i]; 
/* 34 */     TridiagonalFMatrix t = new TridiagonalFMatrix(n, a, b, c);
/* 35 */     float[] r = Array.randfloat(n);
/* 36 */     float[] u = Array.zerofloat(n);
/* 37 */     t.solve(r, u);
/* 38 */     float[] s = t.times(u);
/* 39 */     assertEqualFuzzy(r, s);
/*    */   }
/*    */   
/*    */   private static void assertEqualFuzzy(float[] a, float[] b) {
/* 43 */     int n = a.length;
/* 44 */     double eps = 1.0E-6D * MathPlus.max(Array.max(a), Array.max(b));
/* 45 */     for (int j = 0; j < n; j++)
/* 46 */       assertEquals(a[j], b[j], eps); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/la/test/TridiagonalFMatrixTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */