/*    */ package edu.mines.jtk.dsp.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Eigen;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EigenTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 22 */     TestSuite suite = new TestSuite(EigenTest.class);
/* 23 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSymmetric22() {
/* 27 */     int nrand = 10;
/* 28 */     for (int irand = 0; irand < nrand; irand++) {
/* 29 */       float[][] a = Array.randfloat(2, 2);
/* 30 */       a = Array.add(a, Array.transpose(a));
/* 31 */       float[][] v = new float[2][2];
/* 32 */       float[] d = new float[2];
/* 33 */       Eigen.solveSymmetric22(a, v, d);
/* 34 */       check(a, v, d);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void testSymmetric33() {
/* 39 */     int nrand = 10;
/* 40 */     for (int irand = 0; irand < nrand; irand++) {
/* 41 */       float[][] a = Array.randfloat(3, 3);
/* 42 */       a = Array.add(a, Array.transpose(a));
/* 43 */       float[][] v = new float[3][3];
/* 44 */       float[] d = new float[3];
/* 45 */       Eigen.solveSymmetric33(a, v, d);
/* 46 */       check(a, v, d);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void check(float[][] a, float[][] v, float[] d) {
/* 51 */     int n = a.length;
/* 52 */     for (int k = 0; k < n; k++) {
/* 53 */       assertTrue((k == 0 || d[k - 1] >= d[k]));
/* 54 */       for (int i = 0; i < n; i++) {
/* 55 */         float av = 0.0F;
/* 56 */         for (int j = 0; j < n; j++) {
/* 57 */           av += a[i][j] * v[k][j];
/*    */         }
/* 59 */         float vd = v[k][i] * d[k];
/* 60 */         assertEquals(av, vd, 0.001D);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/EigenTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */