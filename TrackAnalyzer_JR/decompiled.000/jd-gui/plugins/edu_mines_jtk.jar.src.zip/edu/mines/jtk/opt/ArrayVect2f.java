/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.Arrays;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect2f
/*     */   implements Vect
/*     */ {
/*  28 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*  32 */   protected float[][] _data = (float[][])null;
/*  33 */   private int[] _firstSample = null;
/*     */ 
/*     */   
/*  36 */   protected double _variance = 1.0D;
/*  37 */   private int _size = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect2f(float[][] data, double variance) {
/*  45 */     init(data, null, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect2f(float[][] data, int[] firstSample, double variance) {
/*  55 */     init(data, firstSample, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(float[][] data, int[] firstSample, double variance) {
/*  68 */     this._data = data;
/*  69 */     this._variance = variance;
/*  70 */     this._firstSample = firstSample;
/*  71 */     if (this._firstSample != null && this._firstSample.length != data.length) {
/*  72 */       throw new IllegalArgumentException("Data and firstSample must have same length for slow dimension.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[][] getData() {
/*  81 */     return this._data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dataChanged() {
/*  89 */     this._size = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  95 */     if (this._size < 0) {
/*  96 */       this._size = 0;
/*  97 */       for (int i = 0; i < this._data.length && this._data.length > 0; i++) {
/*  98 */         this._size += (this._data[i]).length;
/*     */       }
/*     */     } 
/* 101 */     return this._size;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 106 */     float s1 = (float)scaleThis;
/* 107 */     float s2 = (float)scaleOther;
/* 108 */     ArrayVect2f o = (ArrayVect2f)other;
/* 109 */     for (int i = 0; i < this._data.length; i++) {
/* 110 */       for (int j = 0; j < (this._data[i]).length; j++) {
/* 111 */         this._data[i][j] = s1 * this._data[i][j] + s2 * o._data[i][j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 118 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 123 */     this._data = (float[][])null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 128 */     double scale = Almost.FLOAT.divide(1.0D, getSize() * this._variance, 0.0D);
/* 129 */     VectUtil.scale(this, scale);
/*     */   }
/*     */   
/*     */   public double magnitude() {
/* 133 */     return Almost.FLOAT.divide(dot(this), getSize() * this._variance, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {
/* 138 */     if (this._firstSample == null) {
/*     */       return;
/*     */     }
/* 141 */     for (int i = 0; i < this._data.length; i++) {
/* 142 */       Arrays.fill(this._data[i], 0, this._firstSample[i], 0.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public ArrayVect2f clone() {
/*     */     try {
/* 152 */       float[][] newData = new float[this._data.length][];
/* 153 */       for (int i = 0; i < newData.length; i++) {
/* 154 */         newData[i] = (float[])this._data[i].clone();
/*     */       }
/* 156 */       int[] newFirstSample = (this._firstSample != null) ? (int[])this._firstSample.clone() : null;
/*     */ 
/*     */       
/* 159 */       ArrayVect2f result = (ArrayVect2f)super.clone();
/* 160 */       result.init(newData, newFirstSample, this._variance);
/* 161 */       return result;
/* 162 */     } catch (CloneNotSupportedException ex) {
/* 163 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/* 164 */       e.initCause(ex);
/* 165 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/* 171 */     ArrayVect2f rhs = (ArrayVect2f)other;
/* 172 */     double result = 0.0D;
/* 173 */     for (int i = 0; i < this._data.length; i++) {
/* 174 */       for (int j = 0; j < (this._data[i]).length; j++) {
/* 175 */         result += (this._data[i][j] * rhs._data[i][j]);
/*     */       }
/*     */     } 
/* 178 */     return result;
/*     */   }
/*     */   
/*     */   protected ArrayVect2f() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect2f.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */