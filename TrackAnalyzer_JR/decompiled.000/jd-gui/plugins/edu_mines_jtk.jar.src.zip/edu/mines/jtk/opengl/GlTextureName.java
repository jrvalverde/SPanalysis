/*    */ package edu.mines.jtk.opengl;
/*    */ 
/*    */ import edu.mines.jtk.util.Check;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlTextureName
/*    */ {
/*    */   GlContext _context;
/*    */   int _name;
/*    */   
/*    */   public GlTextureName() {
/* 40 */     this._context = Gl.getContext();
/* 41 */     Check.state((this._context != null), "OpenGL context is not null");
/* 42 */     int[] names = new int[1];
/* 43 */     Gl.glGenTextures(1, names);
/* 44 */     this._name = names[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int name() {
/* 52 */     return this._name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void dispose() {
/* 61 */     if (this._context != null && !this._context.isDisposed()) {
/* 62 */       this._context.lock();
/*    */       try {
/* 64 */         int[] names = { this._name };
/* 65 */         Gl.glDeleteTextures(1, names);
/*    */       } finally {
/* 67 */         this._context.unlock();
/*    */       } 
/*    */     } 
/* 70 */     this._context = null;
/* 71 */     this._name = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/*    */     try {
/* 79 */       dispose();
/*    */     } finally {
/* 81 */       super.finalize();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/GlTextureName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */