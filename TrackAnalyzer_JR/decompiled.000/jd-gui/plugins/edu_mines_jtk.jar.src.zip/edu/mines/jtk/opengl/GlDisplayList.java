/*    */ package edu.mines.jtk.opengl;
/*    */ 
/*    */ import edu.mines.jtk.util.Check;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlDisplayList
/*    */ {
/*    */   GlContext _context;
/*    */   int _list;
/*    */   int _range;
/*    */   
/*    */   public GlDisplayList() {
/* 40 */     this(1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GlDisplayList(int range) {
/* 50 */     this._context = Gl.getContext();
/* 51 */     Check.state((this._context != null), "OpenGL context is not null");
/* 52 */     this._list = Gl.glGenLists(range);
/* 53 */     this._range = range;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int list() {
/* 62 */     return this._list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int range() {
/* 70 */     return this._range;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void dispose() {
/* 79 */     if (this._context != null && !this._context.isDisposed()) {
/* 80 */       this._context.lock();
/*    */       try {
/* 82 */         Gl.glDeleteLists(this._list, this._range);
/*    */       } finally {
/* 84 */         this._context.unlock();
/*    */       } 
/*    */     } 
/* 87 */     this._context = null;
/* 88 */     this._list = 0;
/* 89 */     this._range = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/*    */     try {
/* 97 */       dispose();
/*    */     } finally {
/* 99 */       super.finalize();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/GlDisplayList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */