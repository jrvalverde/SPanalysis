/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParameterSetParser
/*     */   extends DefaultHandler
/*     */ {
/*     */   public ParameterSetParser() {
/*  29 */     SAXParserFactory factory = SAXParserFactory.newInstance();
/*     */     try {
/*  31 */       this._parser = factory.newSAXParser();
/*  32 */     } catch (ParserConfigurationException e) {
/*  33 */       throw new RuntimeException("cannot create XML parser: " + e);
/*  34 */     } catch (SAXException e) {
/*  35 */       throw new RuntimeException("cannot create XML parser: " + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Reader reader, ParameterSet ps) throws ParameterSetFormatException {
/*  42 */     this._ps_root = ps;
/*  43 */     this._ps = null;
/*  44 */     this._p = null;
/*  45 */     this._ptype = 0;
/*  46 */     this._pdata.reset();
/*     */     try {
/*  48 */       this._parser.parse(new InputSource(reader), this);
/*  49 */     } catch (ParameterSetFormatException e) {
/*  50 */       throw e;
/*  51 */     } catch (Exception e) {
/*  52 */       e.printStackTrace(System.err);
/*  53 */       throw new ParameterSetFormatException("ParameterSetParser.parse: unknown error: " + e.getMessage() + ":" + e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws ParameterSetFormatException {
/*  66 */     if (qName.equals("parset")) {
/*  67 */       startParameterSet(attributes);
/*  68 */     } else if (qName.equals("par")) {
/*  69 */       startParameter(attributes);
/*     */     } else {
/*  71 */       throw new ParameterSetFormatException("ParameterSetParser.startElement: unrecognized XML element \"" + qName + "\"" + ".");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws ParameterSetFormatException {
/*  80 */     if (qName.equals("parset")) {
/*  81 */       endParameterSet();
/*  82 */     } else if (qName.equals("par")) {
/*  83 */       endParameter();
/*     */     } else {
/*  85 */       throw new ParameterSetFormatException("ParameterSetParser.endElement: unrecognized XML element \"" + qName + "\"" + ".");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) {
/*  92 */     if (this._p == null)
/*  93 */       return;  this._pdata.write(ch, start, length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(SAXParseException e) throws ParameterSetFormatException {
/*  99 */     String message = e.getMessage();
/* 100 */     int line = e.getLineNumber();
/* 101 */     int column = e.getColumnNumber();
/* 102 */     throw new ParameterSetFormatException("ParameterSetParser.error: " + message + " at line " + line + ", column " + column + ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private SAXParser _parser = null;
/* 112 */   private ParameterSet _ps_root = null;
/* 113 */   private ParameterSet _ps = null;
/* 114 */   private Parameter _p = null;
/* 115 */   private int _ptype = 0;
/* 116 */   private CharArrayWriter _pdata = new CharArrayWriter(256);
/*     */ 
/*     */   
/*     */   private void startParameter(Attributes attributes) throws ParameterSetFormatException {
/* 120 */     String name = attributes.getValue("name");
/* 121 */     if (name == null)
/* 122 */       throw new ParameterSetFormatException("parameter with no name"); 
/* 123 */     if (this._ps == null) {
/* 124 */       throw new ParameterSetFormatException("<par name=\"" + name + "\" ...>" + " must be specified inside a parameter set.");
/*     */     }
/*     */     
/* 127 */     this._p = this._ps.addParameter(name);
/* 128 */     String units = attributes.getValue("units");
/* 129 */     this._p.setUnits(units);
/* 130 */     String type = attributes.getValue("type");
/* 131 */     if (type != null) {
/* 132 */       if (type.equals("boolean")) {
/* 133 */         this._ptype = 1;
/* 134 */       } else if (type.equals("int")) {
/* 135 */         this._ptype = 2;
/* 136 */       } else if (type.equals("long")) {
/* 137 */         this._ptype = 3;
/* 138 */       } else if (type.equals("float")) {
/* 139 */         this._ptype = 4;
/* 140 */       } else if (type.equals("double")) {
/* 141 */         this._ptype = 5;
/* 142 */       } else if (type.equals("string")) {
/* 143 */         this._ptype = 6;
/*     */       } else {
/* 145 */         this._ptype = 6;
/*     */       } 
/*     */     } else {
/* 148 */       this._ptype = 6;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void endParameter() {
/* 153 */     this._p.setStrings(parseValues());
/* 154 */     this._p.setType(this._ptype);
/* 155 */     this._p = null;
/* 156 */     this._ptype = 0;
/* 157 */     this._pdata.reset();
/*     */   }
/*     */   
/*     */   private void startParameterSet(Attributes attributes) {
/* 161 */     String name = attributes.getValue("name");
/* 162 */     if (name == null)
/* 163 */       throw new ParameterSetFormatException("parameter set with no name"); 
/* 164 */     if (this._ps == null) {
/* 165 */       this._ps_root.setName(name);
/* 166 */       this._ps = this._ps_root;
/*     */     } else {
/* 168 */       this._ps = this._ps.addParameterSet(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void endParameterSet() {
/* 173 */     if (this._ps != this._ps_root) {
/* 174 */       this._ps = this._ps.getParent();
/*     */     }
/*     */   }
/*     */   
/*     */   private String[] parseValues() {
/* 179 */     StringParser sp = new StringParser(this._pdata.toString());
/* 180 */     ArrayList<String> vtemp = new ArrayList<String>(8);
/* 181 */     while (sp.hasMoreStrings())
/* 182 */       vtemp.add(sp.nextString()); 
/* 183 */     String[] values = new String[vtemp.size()];
/* 184 */     for (int i = 0; i < values.length; i++)
/* 185 */       values[i] = vtemp.get(i); 
/* 186 */     return values;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/ParameterSetParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */