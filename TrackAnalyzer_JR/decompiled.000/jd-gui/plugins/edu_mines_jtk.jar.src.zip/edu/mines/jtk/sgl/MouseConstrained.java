/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ import java.awt.event.MouseEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MouseConstrained
/*    */ {
/*    */   private Matrix44 _pixelToLocal;
/*    */   
/*    */   public MouseConstrained(Matrix44 localToPixel) {
/* 28 */     this._pixelToLocal = localToPixel.inverse();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract Point3 getPoint(MouseEvent paramMouseEvent);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Segment getMouseSegment(MouseEvent event) {
/* 49 */     int x = event.getX();
/* 50 */     int y = event.getY();
/* 51 */     Point3 near = new Point3(x, y, 0.0D);
/* 52 */     Point3 far = new Point3(x, y, 1.0D);
/* 53 */     near = this._pixelToLocal.times(near);
/* 54 */     far = this._pixelToLocal.times(far);
/* 55 */     return new Segment(near, far);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/MouseConstrained.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */