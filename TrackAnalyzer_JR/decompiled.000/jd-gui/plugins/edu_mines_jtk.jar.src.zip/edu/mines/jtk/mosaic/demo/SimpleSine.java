/*    */ package edu.mines.jtk.mosaic.demo;
/*    */ 
/*    */ import edu.mines.jtk.mosaic.GridView;
/*    */ import edu.mines.jtk.mosaic.PlotFrame;
/*    */ import edu.mines.jtk.mosaic.PlotPanel;
/*    */ import edu.mines.jtk.mosaic.PointsView;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import java.awt.Label;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSine
/*    */ {
/*    */   private PlotFrame _plotFrame;
/*    */   private PlotPanel _plotPanel;
/*    */   private PointsView _pointsView;
/*    */   private GridView _gridView;
/*    */   
/*    */   public static void main(String[] args) {
/* 28 */     SwingUtilities.invokeLater(new Runnable() {
/*    */           public void run() {
/* 30 */             new SimpleSine();
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public SimpleSine() {
/* 36 */     float[] x = Array.rampfloat(0.0F, 0.06283186F, 201);
/* 37 */     float[] s = Array.sin(x);
/* 38 */     this._plotPanel = new PlotPanel();
/* 39 */     this._plotPanel.setTitle("The sine function");
/* 40 */     this._plotPanel.setHLabel("x");
/* 41 */     this._plotPanel.setVLabel("sin(x)");
/* 42 */     this._gridView = this._plotPanel.addGrid();
/* 43 */     this._pointsView = this._plotPanel.addPoints(x, s);
/* 44 */     this._pointsView.setStyle("r-o");
/* 45 */     this._plotFrame = new PlotFrame(this._plotPanel);
/* 46 */     this._plotFrame.setDefaultCloseOperation(3);
/* 47 */     this._plotFrame.setVisible(true);
/* 48 */     this._plotFrame.add(new Label("In either plot or axes, click-drag to zoom, click to unzoom."), "North");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PlotFrame getPlotFrame() {
/* 54 */     return this._plotFrame;
/*    */   }
/*    */   
/*    */   public PlotPanel getPlotPanel() {
/* 58 */     return this._plotPanel;
/*    */   }
/*    */   
/*    */   public PointsView getPointsView() {
/* 62 */     return this._pointsView;
/*    */   }
/*    */   
/*    */   public GridView getGridView() {
/* 66 */     return this._gridView;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/demo/SimpleSine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */