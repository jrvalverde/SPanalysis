/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.event.AdjustmentEvent;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Set;
/*     */ import javax.swing.JScrollBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mosaic
/*     */   extends IPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int _nrow;
/*     */   private int _ncol;
/*     */   private Tile[][] _tiles;
/*     */   private TileAxis[] _axesTop;
/*     */   private TileAxis[] _axesLeft;
/*     */   private TileAxis[] _axesBottom;
/*     */   private TileAxis[] _axesRight;
/*     */   private ArrayList<Tile> _tileList;
/*     */   private ArrayList<TileAxis> _axisList;
/*     */   private HScrollBar[] _hsb;
/*     */   private VScrollBar[] _vsb;
/*     */   private int[] _wm;
/*     */   private int[] _we;
/*     */   private int[] _hm;
/*     */   private int[] _he;
/*     */   private ModeManager _modeManager;
/*     */   private static final int SCROLL_MAX = 1000000000;
/*     */   private static final double SCROLL_SCL = 1.0E-9D;
/*     */   
/*     */   public enum AxesPlacement
/*     */   {
/*  53 */     TOP, LEFT, BOTTOM, RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mosaic(int nrow, int ncol, Set<AxesPlacement> axesPlacement) {
/*  63 */     this._nrow = nrow;
/*  64 */     this._ncol = ncol;
/*     */ 
/*     */ 
/*     */     
/*  68 */     this._tiles = new Tile[nrow][ncol];
/*  69 */     this._tileList = new ArrayList<Tile>(); int i;
/*  70 */     for (i = 0; i < nrow; i++) {
/*  71 */       for (int j = 0; j < ncol; j++) {
/*  72 */         Tile tile = this._tiles[i][j] = new Tile(this, i, j);
/*  73 */         this._tileList.add(tile);
/*  74 */         add(tile);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  79 */     this._axisList = new ArrayList<TileAxis>();
/*  80 */     if (axesPlacement.contains(AxesPlacement.TOP)) {
/*  81 */       this._axesTop = new TileAxis[ncol];
/*  82 */       for (int j = 0; j < ncol; j++) {
/*  83 */         TileAxis axis = this._axesTop[j] = new TileAxis(this, TileAxis.Placement.TOP, j);
/*     */         
/*  85 */         this._axisList.add(axis);
/*  86 */         add(axis);
/*     */       } 
/*     */     } 
/*  89 */     if (axesPlacement.contains(AxesPlacement.LEFT)) {
/*  90 */       this._axesLeft = new TileAxis[nrow];
/*  91 */       for (i = 0; i < nrow; i++) {
/*  92 */         TileAxis axis = this._axesLeft[i] = new TileAxis(this, TileAxis.Placement.LEFT, i);
/*     */         
/*  94 */         this._axisList.add(axis);
/*  95 */         add(axis);
/*     */       } 
/*     */     } 
/*  98 */     if (axesPlacement.contains(AxesPlacement.BOTTOM)) {
/*  99 */       this._axesBottom = new TileAxis[ncol];
/* 100 */       for (int j = 0; j < ncol; j++) {
/* 101 */         TileAxis axis = this._axesBottom[j] = new TileAxis(this, TileAxis.Placement.BOTTOM, j);
/*     */         
/* 103 */         this._axisList.add(axis);
/* 104 */         add(axis);
/*     */       } 
/*     */     } 
/* 107 */     if (axesPlacement.contains(AxesPlacement.RIGHT)) {
/* 108 */       this._axesRight = new TileAxis[nrow];
/* 109 */       for (i = 0; i < nrow; i++) {
/* 110 */         TileAxis axis = this._axesRight[i] = new TileAxis(this, TileAxis.Placement.RIGHT, i);
/*     */         
/* 112 */         this._axisList.add(axis);
/* 113 */         add(axis);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 118 */     this._vsb = new VScrollBar[this._nrow];
/* 119 */     this._hsb = new HScrollBar[this._ncol];
/* 120 */     for (i = 0; i < this._nrow; i++) {
/* 121 */       VScrollBar vsb = this._vsb[i] = new VScrollBar(i);
/* 122 */       add(vsb);
/*     */     }  int icol;
/* 124 */     for (icol = 0; icol < this._ncol; icol++) {
/* 125 */       HScrollBar hsb = this._hsb[icol] = new HScrollBar(icol);
/* 126 */       add(hsb);
/*     */     } 
/*     */ 
/*     */     
/* 130 */     this._we = new int[ncol];
/* 131 */     this._wm = new int[ncol];
/* 132 */     for (icol = 0; icol < ncol; icol++) {
/* 133 */       this._we[icol] = 100;
/* 134 */       this._wm[icol] = 100;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     this._he = new int[nrow];
/* 139 */     this._hm = new int[nrow];
/* 140 */     for (int irow = 0; irow < nrow; irow++) {
/* 141 */       this._he[irow] = 100;
/* 142 */       this._hm[irow] = 100;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     this._modeManager = new ModeManager();
/* 147 */     for (Tile tile : this._tileList)
/* 148 */       this._modeManager.add(tile); 
/* 149 */     for (TileAxis axis : this._axisList) {
/* 150 */       this._modeManager.add(axis);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModeManager(ModeManager modeManager) {
/* 161 */     if (this._modeManager != null) {
/* 162 */       for (Tile tile : this._tileList)
/* 163 */         this._modeManager.remove(tile); 
/* 164 */       for (TileAxis axis : this._axisList)
/* 165 */         this._modeManager.remove(axis); 
/*     */     } 
/* 167 */     this._modeManager = modeManager;
/* 168 */     if (this._modeManager != null) {
/* 169 */       for (Tile tile : this._tileList)
/* 170 */         this._modeManager.add(tile); 
/* 171 */       for (TileAxis axis : this._axisList) {
/* 172 */         this._modeManager.add(axis);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countRows() {
/* 181 */     return this._nrow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countColumns() {
/* 189 */     return this._ncol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tile getTile(int irow, int icol) {
/* 199 */     return this._tiles[irow][icol];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisTop(int icol) {
/* 208 */     return (this._axesTop != null) ? this._axesTop[icol] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisLeft(int irow) {
/* 217 */     return (this._axesLeft != null) ? this._axesLeft[irow] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisBottom(int icol) {
/* 226 */     return (this._axesBottom != null) ? this._axesBottom[icol] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileAxis getTileAxisRight(int irow) {
/* 235 */     return (this._axesRight != null) ? this._axesRight[irow] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidthMinimum(int icol, int widthMinimum) {
/* 247 */     this._wm[icol] = widthMinimum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidthElastic(int icol, int widthElastic) {
/* 260 */     this._we[icol] = widthElastic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeightMinimum(int irow, int heightMinimum) {
/* 272 */     this._hm[irow] = heightMinimum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeightElastic(int irow, int heightElastic) {
/* 285 */     this._he[irow] = heightElastic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModeManager getModeManager() {
/* 293 */     return this._modeManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 298 */     super.setFont(font);
/* 299 */     if (this._tileList != null) {
/* 300 */       for (Tile tile : this._tileList)
/* 301 */         tile.setFont(font); 
/* 302 */       for (TileAxis axis : this._axisList)
/* 303 */         axis.setFont(font); 
/*     */     } 
/* 305 */     revalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setForeground(Color color) {
/* 310 */     super.setForeground(color);
/* 311 */     if (this._tileList != null) {
/* 312 */       for (Tile tile : this._tileList)
/* 313 */         tile.setForeground(color); 
/* 314 */       for (TileAxis axis : this._axisList) {
/* 315 */         axis.setForeground(color);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBackground(Color color) {
/* 321 */     super.setBackground(color);
/* 322 */     if (this._tileList != null) {
/* 323 */       for (Tile tile : this._tileList)
/* 324 */         tile.setBackground(color); 
/* 325 */       for (TileAxis axis : this._axisList) {
/* 326 */         axis.setBackground(color);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getMinimumSize() {
/* 332 */     if (isMinimumSizeSet()) {
/* 333 */       return super.getMinimumSize();
/*     */     }
/* 335 */     return new Dimension(widthMinimum(), heightMinimum());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 341 */     if (isPreferredSizeSet()) {
/* 342 */       return super.getPreferredSize();
/*     */     }
/* 344 */     return getMinimumSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 352 */     updateScrollBars();
/*     */ 
/*     */     
/* 355 */     int w = getWidth();
/* 356 */     int h = getHeight();
/* 357 */     int wf = widthFixed();
/* 358 */     int hf = heightFixed();
/* 359 */     int wfill = Math.max(0, w - wf);
/* 360 */     int hfill = Math.max(0, h - hf);
/*     */ 
/*     */     
/* 363 */     int wesum = 0;
/* 364 */     for (int icol = 0; icol < this._ncol; icol++)
/* 365 */       wesum += this._we[icol]; 
/* 366 */     int hesum = 0;
/* 367 */     for (int irow = 0; irow < this._nrow; irow++) {
/* 368 */       hesum += this._he[irow];
/*     */     }
/*     */     
/* 371 */     wesum = Math.max(1, wesum);
/* 372 */     hesum = Math.max(1, hesum);
/*     */ 
/*     */     
/* 375 */     int[] wcol = new int[this._ncol];
/* 376 */     for (int i = 0, wleft = wfill; i < this._ncol; i++) {
/* 377 */       int we = (i < this._ncol - 1) ? (wfill * this._we[i] / wesum) : wleft;
/* 378 */       if (this._we[i] == 0)
/* 379 */         we = 0; 
/* 380 */       wcol[i] = Math.max(this._wm[i], we);
/* 381 */       wleft -= wcol[i];
/*     */     } 
/*     */ 
/*     */     
/* 385 */     int[] hrow = new int[this._nrow];
/* 386 */     for (int j = 0, hleft = hfill; j < this._nrow; j++) {
/* 387 */       int he = (j < this._nrow - 1) ? (hfill * this._he[j] / hesum) : hleft;
/* 388 */       if (this._he[j] == 0)
/* 389 */         he = 0; 
/* 390 */       hrow[j] = Math.max(this._hm[j], he);
/* 391 */       hleft -= hrow[j];
/*     */     } 
/*     */ 
/*     */     
/* 395 */     int wab = widthAxesBorder();
/* 396 */     int wtb = widthTileBorder();
/*     */ 
/*     */     
/* 399 */     int wts = widthTileSpacing();
/*     */ 
/*     */     
/* 402 */     if (this._axesTop != null) {
/* 403 */       int haxis = heightMinimumAxesTop() - wab - wab;
/* 404 */       int xaxis = widthMinimumAxesLeft() + wtb;
/* 405 */       int yaxis = wab;
/* 406 */       for (int m = 0; m < this._ncol; m++) {
/* 407 */         int waxis = wcol[m];
/* 408 */         this._axesTop[m].setBounds(xaxis, yaxis, waxis, haxis);
/* 409 */         xaxis += waxis + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 414 */     if (this._axesLeft != null) {
/* 415 */       int waxis = widthMinimumAxesLeft() - wab - wab;
/* 416 */       int xaxis = wab;
/* 417 */       int yaxis = heightMinimumAxesTop() + wtb;
/* 418 */       for (int m = 0; m < this._nrow; m++) {
/* 419 */         int haxis = hrow[m];
/* 420 */         this._axesLeft[m].setBounds(xaxis, yaxis, waxis, haxis);
/* 421 */         yaxis += haxis + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 426 */     int xtile0 = wtb;
/* 427 */     int ytile0 = wtb;
/* 428 */     if (this._axesLeft != null)
/* 429 */       xtile0 += widthMinimumAxesLeft(); 
/* 430 */     if (this._axesTop != null)
/* 431 */       ytile0 += heightMinimumAxesTop(); 
/* 432 */     int xtile = xtile0;
/* 433 */     int ytile = ytile0;
/* 434 */     for (int k = 0; k < this._nrow; k++) {
/* 435 */       int htile = hrow[k];
/* 436 */       xtile = xtile0;
/* 437 */       for (int m = 0; m < this._ncol; m++) {
/* 438 */         int wtile = wcol[m];
/* 439 */         this._tiles[k][m].setBounds(xtile, ytile, wtile, htile);
/* 440 */         xtile += wtile + wtb + wts + wtb;
/*     */       } 
/* 442 */       ytile += htile + wtb + wts + wtb;
/*     */     } 
/*     */ 
/*     */     
/* 446 */     xtile -= wts + wtb;
/* 447 */     ytile -= wts + wtb;
/*     */ 
/*     */     
/* 450 */     if (this._axesBottom != null) {
/* 451 */       int haxis = heightMinimumAxesBottom() - wab - wab;
/* 452 */       int xaxis = widthMinimumAxesLeft() + wtb;
/* 453 */       int yaxis = ytile + wab;
/* 454 */       for (int m = 0; m < this._ncol; m++) {
/* 455 */         int waxis = wcol[m];
/* 456 */         this._axesBottom[m].setBounds(xaxis, yaxis, waxis, haxis);
/* 457 */         xaxis += waxis + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 462 */     if (this._axesRight != null) {
/* 463 */       int waxis = widthMinimumAxesRight() - wab - wab;
/* 464 */       int xaxis = xtile + wab;
/* 465 */       int yaxis = heightMinimumAxesTop() + wtb;
/* 466 */       for (int m = 0; m < this._nrow; m++) {
/* 467 */         int haxis = hrow[m];
/* 468 */         this._axesRight[m].setBounds(xaxis, yaxis, waxis, haxis);
/* 469 */         yaxis += haxis + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 474 */     int hhsb = heightHScrollBars();
/* 475 */     if (hhsb > 0) {
/* 476 */       int xhsb = widthMinimumAxesLeft() + wtb;
/* 477 */       int yhsb = ytile;
/* 478 */       if (this._axesBottom != null)
/* 479 */         yhsb += heightMinimumAxesBottom() - wab; 
/* 480 */       for (int m = 0; m < this._ncol; m++) {
/* 481 */         int whsb = wcol[m];
/* 482 */         this._hsb[m].setBounds(xhsb, yhsb, whsb, hhsb);
/* 483 */         xhsb += whsb + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 488 */     int wvsb = widthVScrollBars();
/* 489 */     if (wvsb > 0) {
/* 490 */       int xvsb = xtile;
/* 491 */       if (this._axesRight != null)
/* 492 */         xvsb += widthMinimumAxesRight() - wab; 
/* 493 */       int yvsb = heightMinimumAxesTop() + wtb;
/* 494 */       for (int m = 0; m < this._nrow; m++) {
/* 495 */         int hvsb = hrow[m];
/* 496 */         this._vsb[m].setBounds(xvsb, yvsb, wvsb, hvsb);
/* 497 */         yvsb += hvsb + wtb + wts + wtb;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 503 */     g2d = createGraphics(g2d, x, y, w, h);
/*     */ 
/*     */     
/* 506 */     double ws = w / getWidth();
/* 507 */     double hs = h / getHeight();
/*     */ 
/*     */     
/* 510 */     float lineWidth = getLineWidth(g2d);
/* 511 */     float wtb = lineWidth * widthTileBorder();
/* 512 */     float wab = lineWidth * widthAxesBorder();
/* 513 */     int itb = 1 + (int)(wtb / 2.0F);
/* 514 */     int iab = 1 + (int)(wab / 2.0F);
/* 515 */     BasicStroke stb = new BasicStroke(wtb);
/* 516 */     BasicStroke sab = new BasicStroke(wab);
/*     */ 
/*     */     
/* 519 */     int nc = getComponentCount();
/* 520 */     for (int ic = 0; ic < nc; ic++) {
/* 521 */       Component c = getComponent(ic);
/* 522 */       int xc = c.getX();
/* 523 */       int yc = c.getY();
/* 524 */       int wc = c.getWidth();
/* 525 */       int hc = c.getHeight();
/* 526 */       xc = (int)Math.round(xc * ws);
/* 527 */       yc = (int)Math.round(yc * hs);
/* 528 */       wc = (int)Math.round(wc * ws);
/* 529 */       hc = (int)Math.round(hc * hs);
/* 530 */       if (c instanceof IPanel) {
/* 531 */         IPanel ip = (IPanel)c;
/* 532 */         ip.paintToRect(g2d, xc, yc, wc, hc);
/* 533 */         if (wtb > 0.0F && ip instanceof Tile) {
/* 534 */           Tile tile = (Tile)ip;
/* 535 */           if (tile.countTiledViews() > 0) {
/* 536 */             g2d.setStroke(stb);
/* 537 */             g2d.drawRect(xc - itb, yc - itb, wc + itb + itb - 1, hc + itb + itb - 1);
/*     */           } 
/* 539 */         } else if (wab > 0.0F && ip instanceof TileAxis) {
/* 540 */           g2d.setStroke(sab);
/* 541 */           g2d.drawRect(xc - iab, yc - iab, wc + iab + iab - 1, hc + iab + iab - 1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 545 */     g2d.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 552 */     super.paintComponent(g);
/* 553 */     paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void alignProjectors(Tile tile) {
/* 560 */     int jrow = tile.getRowIndex();
/* 561 */     int jcol = tile.getColumnIndex();
/* 562 */     Projector bhp = tile.getBestHorizontalProjector();
/* 563 */     if (bhp != null) {
/* 564 */       bhp = new Projector(bhp);
/* 565 */       for (int i = 0; i < this._nrow; i++) {
/* 566 */         if (i != jrow)
/* 567 */           bhp.merge(this._tiles[i][jcol].getBestHorizontalProjector()); 
/*     */       } 
/*     */     } 
/* 570 */     Projector bvp = tile.getBestVerticalProjector();
/* 571 */     if (bvp != null) {
/* 572 */       bvp = new Projector(bvp);
/* 573 */       for (int i = 0; i < this._ncol; i++) {
/* 574 */         if (i != jcol)
/* 575 */           bvp.merge(this._tiles[jrow][i].getBestVerticalProjector()); 
/*     */       } 
/*     */     } 
/* 578 */     if (bhp != null && bvp != null) {
/* 579 */       tile.setProjectors(bhp, bvp);
/* 580 */     } else if (bhp != null) {
/* 581 */       tile.setHorizontalProjector(bhp);
/* 582 */     } else if (bvp != null) {
/* 583 */       tile.setVerticalProjector(bvp);
/*     */     } 
/* 585 */     bhp = tile.getHorizontalProjector();
/* 586 */     bvp = tile.getVerticalProjector();
/* 587 */     for (int irow = 0; irow < this._nrow; irow++) {
/* 588 */       if (irow != jrow)
/* 589 */         this._tiles[irow][jcol].setHorizontalProjector(bhp); 
/*     */     } 
/* 591 */     for (int icol = 0; icol < this._ncol; icol++) {
/* 592 */       if (icol != jcol)
/* 593 */         this._tiles[jrow][icol].setVerticalProjector(bvp); 
/*     */     } 
/* 595 */     repaintAxis(this._axesTop, jcol);
/* 596 */     repaintAxis(this._axesBottom, jcol);
/* 597 */     repaintAxis(this._axesLeft, jrow);
/* 598 */     repaintAxis(this._axesRight, jrow);
/*     */   }
/*     */   
/*     */   void setViewRect(Tile tile, DRectangle vr) {
/* 602 */     int wvsb = widthVScrollBars();
/* 603 */     int hhsb = heightHScrollBars();
/* 604 */     double x = Math.max(0.0D, Math.min(1.0D, vr.x));
/* 605 */     double y = Math.max(0.0D, Math.min(1.0D, vr.y));
/* 606 */     double w = Math.max(0.0D, Math.min(1.0D - vr.x, vr.width));
/* 607 */     double h = Math.max(0.0D, Math.min(1.0D - vr.y, vr.height));
/* 608 */     DRectangle tr = new DRectangle(x, y, w, h);
/* 609 */     tile.setViewRect(tr);
/* 610 */     int jrow = tile.getRowIndex();
/* 611 */     int jcol = tile.getColumnIndex();
/* 612 */     for (int irow = 0; irow < this._nrow; irow++) {
/* 613 */       if (irow != jrow) {
/* 614 */         Tile ti = this._tiles[irow][jcol];
/* 615 */         DRectangle dr = ti.getViewRectangle();
/* 616 */         dr.x = tr.x;
/* 617 */         dr.width = tr.width;
/* 618 */         ti.setViewRect(dr);
/*     */       } 
/*     */     } 
/* 621 */     for (int icol = 0; icol < this._ncol; icol++) {
/* 622 */       if (icol != jcol) {
/* 623 */         Tile ti = this._tiles[jrow][icol];
/* 624 */         DRectangle dr = ti.getViewRectangle();
/* 625 */         dr.y = tr.y;
/* 626 */         dr.height = tr.height;
/* 627 */         ti.setViewRect(dr);
/*     */       } 
/*     */     } 
/* 630 */     repaintAxis(this._axesTop, jcol);
/* 631 */     repaintAxis(this._axesBottom, jcol);
/* 632 */     repaintAxis(this._axesLeft, jrow);
/* 633 */     repaintAxis(this._axesRight, jrow);
/* 634 */     this._hsb[jcol].update();
/* 635 */     this._vsb[jrow].update();
/* 636 */     if (wvsb != widthVScrollBars() || hhsb != heightHScrollBars())
/* 637 */       revalidate(); 
/*     */   }
/*     */   
/*     */   int getHeightAxesTop() {
/* 641 */     return heightMinimumAxesTop();
/*     */   }
/*     */   
/*     */   int getHeightAxesBottom() {
/* 645 */     return heightMinimumAxesBottom();
/*     */   }
/*     */   
/*     */   int getWidthAxesLeft() {
/* 649 */     return widthMinimumAxesLeft();
/*     */   }
/*     */   
/*     */   int getWidthAxesRight() {
/* 653 */     return widthMinimumAxesRight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void repaintAxis(TileAxis[] axes, int index) {
/* 678 */     if (axes != null)
/* 679 */       repaintAxis(axes[index]); 
/*     */   }
/*     */   private void repaintAxis(TileAxis axis) {
/* 682 */     axis.repaint();
/* 683 */     axis.updateAxisTics();
/*     */   }
/*     */   
/*     */   private int widthAxesBorder() {
/* 687 */     return 0;
/*     */   }
/*     */   
/*     */   private int widthTileBorder() {
/* 691 */     return 1;
/*     */   }
/*     */   
/*     */   private int widthTileSpacing() {
/* 695 */     return 2;
/*     */   }
/*     */   
/*     */   private int widthFixed() {
/* 699 */     int width = widthMinimumAxesLeft();
/* 700 */     width += (this._ncol - 1) * widthTileSpacing();
/* 701 */     width += 2 * this._ncol * widthTileBorder();
/* 702 */     width += widthMinimumAxesRight();
/* 703 */     width += widthVScrollBars();
/* 704 */     return width;
/*     */   }
/*     */   
/*     */   private int widthMinimum() {
/* 708 */     int width = widthMinimumAxesLeft();
/* 709 */     for (int icol = 0; icol < this._ncol; icol++)
/* 710 */       width += widthMinimumColumn(icol); 
/* 711 */     width += widthMinimumAxesRight();
/* 712 */     width += (this._ncol - 1) * widthTileSpacing();
/* 713 */     width += widthMinimumVScrollBars();
/* 714 */     return width;
/*     */   }
/*     */   
/*     */   private int widthMinimumColumn(int icol) {
/* 718 */     int width = 0;
/* 719 */     if (this._axesTop != null)
/* 720 */       width = Math.max(width, this._axesTop[icol].getWidthMinimum()); 
/* 721 */     width = Math.max(width, widthMinimumTiles(icol));
/* 722 */     if (this._axesBottom != null)
/* 723 */       width = Math.max(width, this._axesBottom[icol].getWidthMinimum()); 
/* 724 */     return width;
/*     */   }
/*     */   
/*     */   private int widthMinimumTiles(int icol) {
/* 728 */     int width = widthTileBorder();
/* 729 */     width += this._wm[icol];
/* 730 */     width += widthTileBorder();
/* 731 */     return width;
/*     */   }
/*     */   
/*     */   private int widthMinimumAxesLeft() {
/* 735 */     int width = 0;
/* 736 */     if (this._axesLeft != null) {
/* 737 */       for (int irow = 0; irow < this._nrow; irow++)
/* 738 */         width = Math.max(width, this._axesLeft[irow].getWidthMinimum()); 
/* 739 */       width += 2 * widthAxesBorder();
/*     */     } 
/* 741 */     return width;
/*     */   }
/*     */   
/*     */   private int widthMinimumAxesRight() {
/* 745 */     int width = 0;
/* 746 */     if (this._axesRight != null) {
/* 747 */       for (int irow = 0; irow < this._nrow; irow++)
/* 748 */         width = Math.max(width, this._axesRight[irow].getWidthMinimum()); 
/* 749 */       width += 2 * widthAxesBorder();
/*     */     } 
/* 751 */     return width;
/*     */   }
/*     */ 
/*     */   
/*     */   private int widthMinimumVScrollBars() {
/* 756 */     return 0;
/*     */   }
/*     */   
/*     */   private int widthVScrollBars() {
/* 760 */     for (int irow = 0; irow < this._nrow; irow++) {
/* 761 */       if (this._vsb[irow].isVisible())
/* 762 */         return (this._vsb[irow].getMinimumSize()).width; 
/*     */     } 
/* 764 */     return 0;
/*     */   }
/*     */   
/*     */   private int heightFixed() {
/* 768 */     int height = heightMinimumAxesTop();
/* 769 */     height += (this._nrow - 1) * widthTileSpacing();
/* 770 */     height += 2 * this._nrow * widthTileBorder();
/* 771 */     height += heightMinimumAxesBottom();
/* 772 */     height += heightHScrollBars();
/* 773 */     return height;
/*     */   }
/*     */   
/*     */   private int heightMinimum() {
/* 777 */     int height = heightMinimumAxesTop();
/* 778 */     for (int irow = 0; irow < this._nrow; irow++)
/* 779 */       height += heightMinimumRow(irow); 
/* 780 */     height += heightMinimumAxesBottom();
/* 781 */     height += (this._nrow - 1) * widthTileSpacing();
/* 782 */     height += heightMinimumHScrollBars();
/* 783 */     return height;
/*     */   }
/*     */   
/*     */   private int heightMinimumRow(int irow) {
/* 787 */     int height = 0;
/* 788 */     if (this._axesLeft != null)
/* 789 */       height = Math.max(height, this._axesLeft[irow].getHeightMinimum()); 
/* 790 */     height = Math.max(height, heightMinimumTiles(irow));
/* 791 */     if (this._axesRight != null)
/* 792 */       height = Math.max(height, this._axesRight[irow].getHeightMinimum()); 
/* 793 */     return height;
/*     */   }
/*     */   
/*     */   private int heightMinimumTiles(int irow) {
/* 797 */     int height = widthTileBorder();
/* 798 */     height += this._hm[irow];
/* 799 */     height += widthTileBorder();
/* 800 */     return height;
/*     */   }
/*     */   
/*     */   private int heightMinimumAxesTop() {
/* 804 */     int height = 0;
/* 805 */     if (this._axesTop != null) {
/* 806 */       for (int icol = 0; icol < this._ncol; icol++)
/* 807 */         height = Math.max(height, this._axesTop[icol].getHeightMinimum()); 
/* 808 */       height += 2 * widthAxesBorder();
/*     */     } 
/* 810 */     return height;
/*     */   }
/*     */   
/*     */   private int heightMinimumAxesBottom() {
/* 814 */     int height = 0;
/* 815 */     if (this._axesBottom != null) {
/* 816 */       for (int icol = 0; icol < this._ncol; icol++)
/* 817 */         height = Math.max(height, this._axesBottom[icol].getHeightMinimum()); 
/* 818 */       height += 2 * widthAxesBorder();
/*     */     } 
/* 820 */     return height;
/*     */   }
/*     */ 
/*     */   
/*     */   private int heightMinimumHScrollBars() {
/* 825 */     return 0;
/*     */   }
/*     */   
/*     */   private int heightHScrollBars() {
/* 829 */     for (int icol = 0; icol < this._ncol; icol++) {
/* 830 */       if (this._hsb[icol].isVisible())
/* 831 */         return (this._hsb[icol].getMinimumSize()).height; 
/*     */     } 
/* 833 */     return 0;
/*     */   }
/*     */   
/*     */   private class TileScrollBar
/*     */     extends JScrollBar
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     Tile tile;
/*     */     private boolean _settingInternal;
/*     */     
/*     */     TileScrollBar(int orientation, final Tile tile) {
/* 844 */       super(orientation, 0, 1000000000, 0, 1000000000);
/* 845 */       setVisible(false);
/* 846 */       this.tile = tile;
/* 847 */       addAdjustmentListener(new AdjustmentListener() {
/*     */             public void adjustmentValueChanged(AdjustmentEvent ae) {
/* 849 */               if (Mosaic.TileScrollBar.this._settingInternal)
/*     */                 return; 
/* 851 */               DRectangle vr = tile.getViewRectangle();
/* 852 */               if (Mosaic.TileScrollBar.this.getOrientation() == 0) {
/* 853 */                 vr.x = Mosaic.TileScrollBar.this.getV();
/* 854 */                 vr.width = Mosaic.TileScrollBar.this.getE();
/*     */               } else {
/* 856 */                 vr.y = Mosaic.TileScrollBar.this.getV();
/* 857 */                 vr.height = Mosaic.TileScrollBar.this.getE();
/*     */               } 
/* 859 */               tile.setViewRectangle(vr);
/*     */             }
/*     */           });
/*     */     }
/*     */     void setV(double v) {
/* 864 */       this._settingInternal = true;
/* 865 */       setValue((int)(v * 1.0E9D + 0.5D));
/* 866 */       this._settingInternal = false;
/*     */     }
/*     */     void setE(double e) {
/* 869 */       this._settingInternal = true;
/* 870 */       setVisibleAmount((int)(e * 1.0E9D + 0.5D));
/* 871 */       setVisible((getVisibleAmount() < 1000000000));
/* 872 */       setUnitIncrement((int)(0.05D * e * 1.0E9D + 0.5D));
/* 873 */       setBlockIncrement((int)(0.5D * e * 1.0E9D + 0.5D));
/* 874 */       this._settingInternal = false;
/*     */     }
/*     */     double getV() {
/* 877 */       return 1.0E-9D * getValue();
/*     */     }
/*     */     double getE() {
/* 880 */       return 1.0E-9D * getVisibleAmount();
/*     */     }
/*     */     void update() {
/* 883 */       DRectangle vr = this.tile.getViewRectangle();
/* 884 */       if (getOrientation() == 0) {
/* 885 */         setV(vr.x);
/* 886 */         setE(vr.width);
/*     */       } else {
/* 888 */         setV(vr.y);
/* 889 */         setE(vr.height);
/*     */       } 
/*     */     } }
/*     */   
/*     */   private class HScrollBar extends TileScrollBar {
/*     */     private static final long serialVersionUID = 1L;
/*     */     int icol;
/*     */     
/*     */     HScrollBar(int icol) {
/* 898 */       super(0, Mosaic.this._tiles[0][icol]);
/* 899 */       this.icol = icol;
/*     */     }
/*     */   }
/*     */   
/*     */   private class VScrollBar extends TileScrollBar { private static final long serialVersionUID = 1L;
/*     */     
/*     */     VScrollBar(int irow) {
/* 906 */       super(1, Mosaic.this._tiles[irow][0]);
/* 907 */       this.irow = irow;
/*     */     }
/*     */     int irow; }
/*     */   
/*     */   private void updateScrollBars() {
/* 912 */     for (int icol = 0; icol < this._ncol; icol++)
/* 913 */       this._hsb[icol].update(); 
/* 914 */     for (int irow = 0; irow < this._nrow; irow++)
/* 915 */       this._vsb[irow].update(); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/Mosaic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */