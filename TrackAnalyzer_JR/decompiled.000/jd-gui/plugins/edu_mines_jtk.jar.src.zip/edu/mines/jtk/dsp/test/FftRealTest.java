/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.FftComplex;
/*     */ import edu.mines.jtk.dsp.FftReal;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import junit.framework.AssertionFailedError;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FftRealTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(FftRealTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1() {
/*  29 */     int nmax = 1000;
/*  30 */     for (int n = 2; n < nmax; n++) {
/*  31 */       int nfft = FftReal.nfftSmall(n);
/*  32 */       FftReal fft = new FftReal(nfft);
/*  33 */       int nw = nfft / 2 + 1;
/*  34 */       float[] c1 = Array.czerofloat(nw);
/*  35 */       float[] r1 = c1;
/*  36 */       r1[1] = 1.0F;
/*  37 */       float[] rx = Array.ccopy(r1);
/*  38 */       float[] cx = rx;
/*  39 */       fft.realToComplex(1, rx, cx);
/*  40 */       float ra = 0.0F;
/*  41 */       float rb = 6.2831855F / nfft;
/*  42 */       float[] amp = Array.fillfloat(1.0F, nw);
/*  43 */       float[] phs = Array.rampfloat(ra, rb, nw);
/*  44 */       float[] cc = Array.polar(amp, phs);
/*  45 */       assertComplexEqual(nw, cc, cx);
/*  46 */       fft.complexToReal(-1, cx, rx);
/*  47 */       fft.scale(nfft, rx);
/*  48 */       assertRealEqual(nfft, r1, rx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test12() {
/*  53 */     int n1max = 26;
/*  54 */     int n2max = 26;
/*  55 */     for (int n2 = 2; n2 < n2max; n2++) {
/*  56 */       int n2fft = FftComplex.nfftSmall(n2);
/*  57 */       FftComplex fft2 = new FftComplex(n2fft);
/*  58 */       for (int n1 = 2; n1 < n1max; n1++) {
/*  59 */         int n1fft = FftReal.nfftSmall(n1);
/*  60 */         FftReal fft1 = new FftReal(n1fft);
/*  61 */         int nw = n1fft / 2 + 1;
/*  62 */         float[][] c1 = Array.czerofloat(nw, n2fft);
/*  63 */         float[][] r1 = c1;
/*  64 */         r1[1][1] = 1.0F;
/*  65 */         float[][] rx = Array.ccopy(r1);
/*  66 */         float[][] cx = rx;
/*  67 */         fft1.realToComplex1(1, n2, rx, cx);
/*  68 */         fft2.complexToComplex2(1, nw, cx, cx);
/*  69 */         float ra = 0.0F;
/*  70 */         float rb1 = 6.2831855F / n1fft;
/*  71 */         float rb2 = 6.2831855F / n2fft;
/*  72 */         float[][] amp = Array.fillfloat(1.0F, nw, n2fft);
/*  73 */         float[][] phs = Array.rampfloat(ra, rb1, rb2, nw, n2fft);
/*  74 */         float[][] cc = Array.polar(amp, phs);
/*  75 */         assertComplexEqual(nw, n2fft, cc, cx);
/*  76 */         fft2.complexToComplex2(-1, nw, cx, cx);
/*  77 */         fft2.scale(nw, n2, cx);
/*  78 */         fft1.complexToReal1(-1, n2, cx, rx);
/*  79 */         fft1.scale(n1, n2, rx);
/*  80 */         assertRealEqual(n1, n2, r1, rx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test21() {
/*  86 */     int n1max = 26;
/*  87 */     int n2max = 26;
/*  88 */     for (int n2 = 2; n2 < n2max; n2++) {
/*  89 */       int n2fft = FftReal.nfftSmall(n2);
/*  90 */       FftReal fft2 = new FftReal(n2fft);
/*  91 */       int nw = n2fft / 2 + 1;
/*  92 */       for (int n1 = 2; n1 < n1max; n1++) {
/*  93 */         int n1fft = FftComplex.nfftSmall(n1);
/*  94 */         FftComplex fft1 = new FftComplex(n1fft);
/*  95 */         float[][] c1 = Array.czerofloat(n1fft, n2fft);
/*  96 */         float[][] r1 = c1;
/*  97 */         r1[1][1] = 1.0F;
/*  98 */         float[][] rx = Array.ccopy(r1);
/*  99 */         float[][] cx = rx;
/* 100 */         fft2.realToComplex2(1, n1, rx, cx);
/* 101 */         fft1.complexToComplex1(1, nw, cx, cx);
/* 102 */         float ra = 0.0F;
/* 103 */         float rb1 = 6.2831855F / n1fft;
/* 104 */         float rb2 = 6.2831855F / n2fft;
/* 105 */         float[][] amp = Array.fillfloat(1.0F, n1fft, nw);
/* 106 */         float[][] phs = Array.rampfloat(ra, rb1, rb2, n1fft, nw);
/* 107 */         float[][] cc = Array.polar(amp, phs);
/* 108 */         assertComplexEqual(n1fft, nw, cc, cx);
/* 109 */         fft1.complexToComplex1(-1, nw, cx, cx);
/* 110 */         fft1.scale(n1, nw, cx);
/* 111 */         fft2.complexToReal2(-1, n1, cx, rx);
/* 112 */         fft2.scale(n1, n2, rx);
/* 113 */         assertRealEqual(n1, n2, r1, rx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test1Random() {
/* 119 */     int nmax = 1000;
/* 120 */     for (int n = 2; n < nmax; n++) {
/* 121 */       int nfft = FftReal.nfftSmall(n);
/* 122 */       FftReal fft = new FftReal(nfft);
/* 123 */       int nw = nfft / 2 + 1;
/* 124 */       float[] rr = Array.randfloat(nfft);
/* 125 */       float[] rx = Array.copy(rr);
/* 126 */       float[] cy = Array.czerofloat(nw);
/* 127 */       fft.realToComplex(1, rx, cy);
/* 128 */       fft.complexToReal(-1, cy, rx);
/* 129 */       fft.scale(nfft, rx);
/* 130 */       assertRealEqual(nfft, rr, rx);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test12Random() {
/* 135 */     int n1max = 26;
/* 136 */     int n2max = 26;
/* 137 */     for (int n2 = 2; n2 < n2max; n2++) {
/* 138 */       int n2fft = FftComplex.nfftSmall(n2);
/* 139 */       FftComplex fft2 = new FftComplex(n2fft);
/* 140 */       for (int n1 = 2; n1 < n1max; n1++) {
/* 141 */         int n1fft = FftReal.nfftSmall(n1);
/* 142 */         FftReal fft1 = new FftReal(n1fft);
/* 143 */         int nw = n1fft / 2 + 1;
/* 144 */         float[][] rr = Array.randfloat(n1fft, n2);
/* 145 */         float[][] rx = Array.copy(rr);
/* 146 */         float[][] cy = Array.czerofloat(nw, n2fft);
/* 147 */         fft1.realToComplex1(1, n2, rx, cy);
/* 148 */         fft2.complexToComplex2(1, nw, cy, cy);
/* 149 */         fft2.complexToComplex2(-1, nw, cy, cy);
/* 150 */         fft2.scale(nw, n2, cy);
/* 151 */         fft1.complexToReal1(-1, n2, cy, rx);
/* 152 */         fft1.scale(n1, n2, rx);
/* 153 */         assertRealEqual(n1, n2, rr, rx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test21Random() {
/* 159 */     int n1max = 26;
/* 160 */     int n2max = 26;
/* 161 */     for (int n2 = 2; n2 < n2max; n2++) {
/* 162 */       int n2fft = FftReal.nfftSmall(n2);
/* 163 */       FftReal fft2 = new FftReal(n2fft);
/* 164 */       int nw = n2fft / 2 + 1;
/* 165 */       for (int n1 = 2; n1 < n1max; n1++) {
/* 166 */         int n1fft = FftComplex.nfftSmall(n1);
/* 167 */         FftComplex fft1 = new FftComplex(n1fft);
/* 168 */         float[][] rr = Array.randfloat(n1, n2fft);
/* 169 */         float[][] rx = Array.copy(rr);
/* 170 */         float[][] cy = Array.czerofloat(n1fft, nw);
/* 171 */         fft2.realToComplex2(1, n1, rx, cy);
/* 172 */         fft1.complexToComplex1(1, nw, cy, cy);
/* 173 */         fft1.complexToComplex1(-1, nw, cy, cy);
/* 174 */         fft1.scale(n1, nw, cy);
/* 175 */         fft2.complexToReal2(-1, n1, cy, rx);
/* 176 */         fft2.scale(n1, n2, rx);
/* 177 */         assertRealEqual(n1, n2, rr, rx);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assertRealEqual(int n1, float[] re, float[] ra) {
/* 183 */     float tolerance = n1 * 1.1920929E-7F;
/* 184 */     for (int i1 = 0; i1 < n1; i1++)
/* 185 */       assertEquals(re[i1], ra[i1], tolerance); 
/*     */   }
/*     */   
/*     */   private void assertRealEqual(int n1, int n2, float[][] re, float[][] ra) {
/* 189 */     float tolerance = (n1 + n2) * 1.1920929E-7F;
/* 190 */     for (int i2 = 0; i2 < n2; i2++) {
/* 191 */       for (int i1 = 0; i1 < n1; i1++) {
/*     */         try {
/* 193 */           assertEquals(re[i2][i1], ra[i2][i1], tolerance);
/* 194 */         } catch (AssertionFailedError e) {
/* 195 */           System.out.println("index i1=" + i1 + " i2=" + i2);
/* 196 */           throw e;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void assertComplexEqual(int n1, float[] ce, float[] ca) {
/* 202 */     float tolerance = n1 * 1.1920929E-7F;
/* 203 */     for (int i1 = 0; i1 < n1; i1++) {
/* 204 */       assertEquals(ce[2 * i1], ca[2 * i1], tolerance);
/* 205 */       assertEquals(ce[2 * i1 + 1], ca[2 * i1 + 1], tolerance);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assertComplexEqual(int n1, int n2, float[][] ce, float[][] ca) {
/* 210 */     float tolerance = (n1 + n2) * 1.1920929E-7F;
/* 211 */     for (int i2 = 0; i2 < n2; i2++) {
/* 212 */       for (int i1 = 0; i1 < n1; i1++) {
/*     */         try {
/* 214 */           assertEquals(ce[i2][2 * i1], ca[i2][2 * i1], tolerance);
/* 215 */           assertEquals(ce[i2][2 * i1 + 1], ca[i2][2 * i1 + 1], tolerance);
/* 216 */         } catch (AssertionFailedError e) {
/* 217 */           System.out.println("index i1=" + i1 + " i2=" + i2);
/* 218 */           throw e;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/FftRealTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */