/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect1f;
/*    */ import edu.mines.jtk.opt.ArrayVect1fs;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class ArrayVect1fsTest extends TestCase {
/*    */   public void testAll() {
/* 16 */     Random random = new Random(32525L);
/*    */     
/* 18 */     ArrayVect1f[] data = new ArrayVect1f[5];
/* 19 */     for (int i = 0; i < data.length; i++) {
/* 20 */       float[] a = new float[31];
/* 21 */       for (int k = 0; k < a.length; ) { a[k] = random.nextFloat(); k++; }
/* 22 */        data[i] = new ArrayVect1f(a, i + 3, (i + 4.0D) / 3.0D);
/*    */     } 
/* 24 */     ArrayVect1fs arrayVect1fs1 = new ArrayVect1fs(data);
/* 25 */     VectUtil.test((VectConst)arrayVect1fs1);
/* 26 */     arrayVect1fs1.dispose();
/*    */ 
/*    */ 
/*    */     
/* 30 */     data = new ArrayVect1f[5];
/* 31 */     for (int j = 0; j < data.length; j++) {
/* 32 */       float[] a = new float[31];
/* 33 */       for (int k = 0; k < a.length; ) { a[k] = 1.0F; k++; }
/* 34 */        data[j] = new ArrayVect1f(a, 0, 3.0D);
/*    */     } 
/* 36 */     ArrayVect1fs v = new ArrayVect1fs(data);
/* 37 */     VectUtil.test((VectConst)v);
/* 38 */     ArrayVect1fs arrayVect1fs2 = v.clone();
/* 39 */     arrayVect1fs2.multiplyInverseCovariance();
/* 40 */     assert Almost.FLOAT.equal(0.3333333333333333D, v.dot((VectConst)arrayVect1fs2));
/* 41 */     assert Almost.FLOAT.equal(0.3333333333333333D, v.magnitude());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 48 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 51 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayVect1fsTest(String name) {
/* 58 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 64 */       throw new IllegalStateException("need -ea");
/* 65 */     } catch (AssertionError e) {
/* 66 */       return (Test)new TestSuite(ArrayVect1fsTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 73 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect1fsTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */