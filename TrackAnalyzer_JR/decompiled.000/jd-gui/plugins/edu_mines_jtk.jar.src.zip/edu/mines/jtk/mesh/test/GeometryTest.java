/*     */ package edu.mines.jtk.mesh.test;
/*     */ 
/*     */ import edu.mines.jtk.mesh.Geometry;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeometryTest
/*     */   extends TestCase
/*     */ {
/*     */   private static final int X = 0;
/*     */   private static final int Y = 1;
/*     */   private static final int Z = 2;
/*     */   private static final boolean TRACE = false;
/*     */   
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(GeometryTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testInCircle() {
/*  31 */     float xxxx = 3.14159F;
/*  32 */     float yyyy = 9.9999999E14F;
/*  33 */     float[] pa = { xxxx, 0.0F };
/*  34 */     float[] pb = { 0.0F, yyyy };
/*  35 */     float[] pc = { 0.0F, 0.0F };
/*  36 */     float[] pd = { xxxx, yyyy };
/*     */ 
/*     */     
/*  39 */     trace("");
/*     */ 
/*     */     
/*  42 */     double ra = Geometry.inCircle(pa, pb, pc, pd);
/*  43 */     double rf = Geometry.inCircleFast(pa, pb, pc, pd);
/*  44 */     trace("0 inCircle:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/*  45 */     trace("0 inCircleFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/*  46 */     assertTrue((ra == 0.0D));
/*     */ 
/*     */     
/*  49 */     pd[0] = xxxx * 0.9999999F;
/*  50 */     ra = Geometry.inCircle(pa, pb, pc, pd);
/*  51 */     rf = Geometry.inCircleFast(pa, pb, pc, pd);
/*  52 */     trace("+ inCircle:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/*  53 */     trace("+ inCircleFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/*  54 */     assertTrue((ra > 0.0D));
/*     */ 
/*     */     
/*  57 */     pd[0] = xxxx * 1.0000001F;
/*  58 */     ra = Geometry.inCircle(pa, pb, pc, pd);
/*  59 */     rf = Geometry.inCircleFast(pa, pb, pc, pd);
/*  60 */     trace("- inCircle:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/*  61 */     trace("- inCircleFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/*  62 */     assertTrue((ra < 0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testInSphere() {
/*  68 */     float xxxx = 1.0F;
/*  69 */     float yyyy = 3.1415927F;
/*  70 */     float zzzz = 1000000.0F;
/*  71 */     float[] pa = { xxxx, 0.0F, 0.0F };
/*  72 */     float[] pb = { 0.0F, yyyy, 0.0F };
/*  73 */     float[] pc = { 0.0F, 0.0F, zzzz };
/*  74 */     float[] pd = { 0.0F, 0.0F, 0.0F };
/*  75 */     float[] pe = { xxxx, yyyy, zzzz };
/*     */ 
/*     */     
/*  78 */     trace("");
/*     */ 
/*     */     
/*  81 */     double ra = Geometry.inSphere(pa, pb, pc, pd, pe);
/*  82 */     double rf = Geometry.inSphereFast(pa, pb, pc, pd, pe);
/*  83 */     trace("0 inSphere:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/*  84 */     trace("0 inSphereFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/*  85 */     assertTrue((ra == 0.0D));
/*     */ 
/*     */     
/*  88 */     pe[0] = xxxx * 0.9999999F;
/*  89 */     ra = Geometry.inSphere(pa, pb, pc, pd, pe);
/*  90 */     rf = Geometry.inSphereFast(pa, pb, pc, pd, pe);
/*  91 */     trace("+ inSphere:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/*  92 */     trace("+ inSphereFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/*  93 */     assertTrue((ra > 0.0D));
/*     */ 
/*     */     
/*  96 */     pe[0] = xxxx * 1.0000001F;
/*  97 */     ra = Geometry.inSphere(pa, pb, pc, pd, pe);
/*  98 */     rf = Geometry.inSphereFast(pa, pb, pc, pd, pe);
/*  99 */     trace("- inSphere:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 100 */     trace("- inSphereFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 101 */     assertTrue((ra < 0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testLeftOfLine() {
/* 107 */     float xxxx = 2.0F;
/* 108 */     float yyyy = 1.0F;
/* 109 */     float aaaa = 9.9999999E14F;
/* 110 */     float[] pa = { 1.0F * xxxx, 1.0F * yyyy };
/* 111 */     float[] pb = { 2.0F * xxxx, 2.0F * yyyy };
/* 112 */     float[] pc = { aaaa * xxxx, aaaa * yyyy };
/*     */ 
/*     */     
/* 115 */     trace("");
/*     */ 
/*     */     
/* 118 */     double ra = Geometry.leftOfLine(pa, pb, pc);
/* 119 */     double rf = Geometry.leftOfLineFast(pa, pb, pc);
/* 120 */     trace("0 leftOfLine:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 121 */     trace("0 leftOfLineFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 122 */     assertTrue((ra == 0.0D));
/*     */ 
/*     */     
/* 125 */     pc[0] = aaaa * xxxx * 0.9999999F;
/* 126 */     ra = Geometry.leftOfLine(pa, pb, pc);
/* 127 */     rf = Geometry.leftOfLineFast(pa, pb, pc);
/* 128 */     trace("+ leftOfLine:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 129 */     trace("+ leftOfLineFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 130 */     assertTrue((ra > 0.0D));
/*     */ 
/*     */     
/* 133 */     pc[0] = aaaa * xxxx * 1.0000001F;
/* 134 */     ra = Geometry.leftOfLine(pa, pb, pc);
/* 135 */     rf = Geometry.leftOfLineFast(pa, pb, pc);
/* 136 */     trace("- leftOfLine:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 137 */     trace("- leftOfLineFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 138 */     assertTrue((ra < 0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testLeftOfPlane() {
/* 144 */     float xxxx = 1.0F;
/* 145 */     float yyyy = 1.0F;
/* 146 */     float zzzz = 9.9999999E14F;
/* 147 */     float[] pa = { xxxx, 0.0F, 0.1F };
/* 148 */     float[] pb = { 0.0F, yyyy, 3.3F };
/* 149 */     float[] pc = { 0.0F, yyyy, 6.7F };
/* 150 */     float[] pd = { xxxx, 0.0F, zzzz };
/*     */ 
/*     */     
/* 153 */     trace("");
/*     */ 
/*     */     
/* 156 */     double ra = Geometry.leftOfPlane(pa, pb, pc, pd);
/* 157 */     double rf = Geometry.leftOfPlaneFast(pa, pb, pc, pd);
/* 158 */     trace("0 leftOfPlane:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 159 */     trace("0 leftOfPlaneFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 160 */     assertTrue((ra == 0.0D));
/*     */ 
/*     */     
/* 163 */     pd[0] = xxxx * 0.9999999F;
/* 164 */     ra = Geometry.leftOfPlane(pa, pb, pc, pd);
/* 165 */     rf = Geometry.leftOfPlaneFast(pa, pb, pc, pd);
/* 166 */     trace("+ leftOfPlane:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 167 */     trace("+ leftOfPlaneFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 168 */     assertTrue((ra > 0.0D));
/*     */ 
/*     */     
/* 171 */     pd[0] = xxxx * 1.0000001F;
/* 172 */     ra = Geometry.leftOfPlane(pa, pb, pc, pd);
/* 173 */     rf = Geometry.leftOfPlaneFast(pa, pb, pc, pd);
/* 174 */     trace("- leftOfPlane:     " + String.format("%26.18e", new Object[] { Double.valueOf(ra) }));
/* 175 */     trace("- leftOfPlaneFast: " + String.format("%26.18e", new Object[] { Double.valueOf(rf) }));
/* 176 */     assertTrue((ra < 0.0D));
/*     */   }
/*     */   
/*     */   public void testLeftOfPlaneSpecial() {
/* 180 */     double[] pa = { 99.50000003392293D, 125.85383672388726D, 4.712236446160304D };
/* 181 */     double[] pb = { 91.50000003119546D, 125.85383641401195D, 4.712236443259705D };
/* 182 */     double[] pc = { 107.5000000366504D, 125.85383703376256D, 4.712236449060903D };
/* 183 */     double[] pd = { 27.50000030246409D, 125.8538208916998D, 122.28777353807229D };
/* 184 */     double ra = Geometry.leftOfPlane(pa, pb, pc, pd);
/* 185 */     double rf = Geometry.leftOfPlaneFast(pa, pb, pc, pd);
/* 186 */     assertTrue((ra == 0.0D));
/* 187 */     assertTrue((rf != 0.0D));
/*     */   }
/*     */   
/*     */   public void testLeftOfPlaneSpecial2() {
/* 191 */     double[] pa = { 111.50000056515266D, 125.85385176546224D, 4.712249324321081D };
/* 192 */     double[] pb = { 123.50000062597627D, 125.8538522971668D, 4.712249325708733D };
/* 193 */     double[] pc = { 105.50000053474086D, 125.85385224976321D, 4.712249323627476D };
/* 194 */     double[] pd = { 93.50000047391725D, 125.85385171805865D, 4.712249322239824D };
/* 195 */     double ra = Geometry.leftOfPlane(pa, pb, pc, pd);
/* 196 */     double rf = Geometry.leftOfPlaneFast(pa, pb, pc, pd);
/* 197 */     assertTrue((ra == 0.0D));
/* 198 */     assertTrue((rf != 0.0D));
/*     */   }
/*     */   
/*     */   public void xtestInSphereSpeed() {
/* 202 */     float[] pa = { 1.0F, 0.0F, 0.0F };
/* 203 */     float[] pb = { 0.0F, 1.0F, 0.0F };
/* 204 */     float[] pc = { 0.0F, 0.0F, 1.0F };
/* 205 */     float[] pd = { 0.0F, 0.0F, 0.0F };
/* 206 */     float[] pe = { 0.5F, 0.5F, 0.5F };
/*     */     
/* 208 */     float xa = pa[0], ya = pa[1], za = pa[2];
/* 209 */     float xb = pb[0], yb = pb[1], zb = pb[2];
/* 210 */     float xc = pc[0], yc = pc[1], zc = pc[2];
/* 211 */     float xd = pd[0], yd = pd[1], zd = pd[2];
/* 212 */     float xe = pe[0], ye = pe[1], ze = pe[2];
/*     */     
/* 214 */     trace("");
/* 215 */     Stopwatch sw = new Stopwatch();
/* 216 */     int nsphere = 0;
/* 217 */     int niter = 100;
/* 218 */     double maxtime = 2.0D;
/*     */ 
/*     */     
/*     */     while (true) {
/* 222 */       sw.reset();
/* 223 */       sw.start();
/* 224 */       for (nsphere = 0; sw.time() < maxtime; nsphere += niter) {
/* 225 */         for (int iter = 0; iter < niter; iter++) {
/* 226 */           Geometry.inSphere(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd, xe, ye, ze);
/*     */         }
/*     */       } 
/*     */       
/* 230 */       sw.stop();
/* 231 */       trace("inSphere:     sphere/s = " + (int)(nsphere / sw.time()));
/*     */       
/* 233 */       sw.reset();
/* 234 */       sw.start();
/* 235 */       for (nsphere = 0; sw.time() < maxtime; nsphere += niter) {
/* 236 */         for (int iter = 0; iter < niter; iter++) {
/* 237 */           Geometry.inSphereFast(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd, xe, ye, ze);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 242 */       sw.stop();
/* 243 */       trace("inSphereFast: sphere/s = " + (int)(nsphere / sw.time()));
/*     */       
/*     */       try {
/* 246 */         Thread.sleep(1000L, 0);
/* 247 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xtestLeftOfPlaneSpeed() {
/* 255 */     float[] pa = { 1.0F, 0.0F, 0.0F };
/* 256 */     float[] pb = { 0.0F, 1.0F, 0.0F };
/* 257 */     float[] pc = { 0.0F, 0.0F, 1.0F };
/* 258 */     float[] pd = { 0.0F, 0.0F, 0.0F };
/*     */     
/* 260 */     float xa = pa[0], ya = pa[1], za = pa[2];
/* 261 */     float xb = pb[0], yb = pb[1], zb = pb[2];
/* 262 */     float xc = pc[0], yc = pc[1], zc = pc[2];
/* 263 */     float xd = pd[0], yd = pd[1], zd = pd[2];
/*     */     
/* 265 */     trace("");
/* 266 */     Stopwatch sw = new Stopwatch();
/* 267 */     int nplane = 0;
/* 268 */     int niter = 100;
/* 269 */     double maxtime = 2.0D;
/*     */     
/* 271 */     sw.reset();
/* 272 */     sw.start();
/* 273 */     for (nplane = 0; sw.time() < maxtime; nplane += niter) {
/* 274 */       for (int iter = 0; iter < niter; iter++) {
/* 275 */         Geometry.leftOfPlane(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd);
/*     */       }
/*     */     } 
/*     */     
/* 279 */     sw.stop();
/* 280 */     trace("leftOfPlane:     plane/s = " + (int)(nplane / sw.time()));
/*     */     
/* 282 */     sw.reset();
/* 283 */     sw.start();
/* 284 */     for (nplane = 0; sw.time() < maxtime; nplane += niter) {
/* 285 */       for (int iter = 0; iter < niter; iter++) {
/* 286 */         Geometry.leftOfPlaneFast(xa, ya, za, xb, yb, zb, xc, yc, zc, xd, yd, zd);
/*     */       }
/*     */     } 
/*     */     
/* 290 */     sw.stop();
/* 291 */     trace("leftOfPlaneFast: plane/s = " + (int)(nplane / sw.time()));
/*     */   }
/*     */   
/*     */   public void testCenterCircle3D() {
/* 295 */     double[] po = { 0.0D, 0.0D, 0.0D };
/* 296 */     Geometry.centerCircle3D(0.0D, 1.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.0D, 0.0D, 1.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 300 */     assertTrue((po[0] == 0.0D));
/* 301 */     assertTrue((po[1] == 0.5D));
/* 302 */     assertTrue((po[2] == 0.5D));
/* 303 */     Geometry.centerCircle3D(0.0D, 0.0D, 1.0D, 1.0D, 0.0D, 1.0D, 1.0D, 0.0D, 0.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 307 */     assertTrue((po[0] == 0.5D));
/* 308 */     assertTrue((po[1] == 0.0D));
/* 309 */     assertTrue((po[2] == 0.5D));
/* 310 */     Geometry.centerCircle3D(1.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.0D, 0.0D, 1.0D, 0.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 314 */     assertTrue((po[0] == 0.5D));
/* 315 */     assertTrue((po[1] == 0.5D));
/* 316 */     assertTrue((po[2] == 0.0D));
/*     */     
/* 318 */     Geometry.centerCircle3D(1.0D, 1.0D, 0.0D, 1.0D, 1.0D, 1.0D, 1.0D, 0.0D, 1.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 322 */     assertTrue((po[0] == 1.0D));
/* 323 */     assertTrue((po[1] == 0.5D));
/* 324 */     assertTrue((po[2] == 0.5D));
/* 325 */     Geometry.centerCircle3D(0.0D, 1.0D, 1.0D, 1.0D, 1.0D, 1.0D, 1.0D, 1.0D, 0.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 329 */     assertTrue((po[0] == 0.5D));
/* 330 */     assertTrue((po[1] == 1.0D));
/* 331 */     assertTrue((po[2] == 0.5D));
/* 332 */     Geometry.centerCircle3D(1.0D, 0.0D, 1.0D, 1.0D, 1.0D, 1.0D, 0.0D, 1.0D, 1.0D, po);
/*     */ 
/*     */ 
/*     */     
/* 336 */     assertTrue((po[0] == 0.5D));
/* 337 */     assertTrue((po[1] == 0.5D));
/* 338 */     assertTrue((po[2] == 1.0D));
/*     */   }
/*     */   
/*     */   private static void trace(String s) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/test/GeometryTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */