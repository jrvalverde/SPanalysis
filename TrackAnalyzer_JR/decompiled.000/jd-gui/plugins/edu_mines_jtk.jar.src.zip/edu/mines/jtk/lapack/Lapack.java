/*    */ package edu.mines.jtk.lapack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Lapack
/*    */ {
/*    */   static final int JOB_A = 201;
/*    */   static final int JOB_S = 202;
/*    */   static final int JOB_O = 203;
/*    */   static final int JOB_N = 204;
/*    */   static final int JOB_V = 205;
/*    */   static final int RANGE_A = 301;
/*    */   static final int RANGE_V = 302;
/*    */   static final int RANGE_I = 303;
/*    */   
/*    */   static native int dgetrf(int paramInt1, int paramInt2, double[] paramArrayOfdouble, int paramInt3, int[] paramArrayOfint);
/*    */   
/*    */   static native int dgetrs(int paramInt1, int paramInt2, int paramInt3, double[] paramArrayOfdouble1, int paramInt4, int[] paramArrayOfint, double[] paramArrayOfdouble2, int paramInt5);
/*    */   
/*    */   static native int dpotrf(int paramInt1, int paramInt2, double[] paramArrayOfdouble, int paramInt3);
/*    */   
/*    */   static native int dpotrs(int paramInt1, int paramInt2, int paramInt3, double[] paramArrayOfdouble1, int paramInt4, double[] paramArrayOfdouble2, int paramInt5);
/*    */   
/*    */   static native int dgeqrf(int paramInt1, int paramInt2, double[] paramArrayOfdouble1, int paramInt3, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt4);
/*    */   
/*    */   static native int dorgqr(int paramInt1, int paramInt2, int paramInt3, double[] paramArrayOfdouble1, int paramInt4, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt5);
/*    */   
/*    */   static native int dormqr(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double[] paramArrayOfdouble1, int paramInt6, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt7, double[] paramArrayOfdouble4, int paramInt8);
/*    */   
/*    */   static native int dtrtrs(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double[] paramArrayOfdouble1, int paramInt6, double[] paramArrayOfdouble2, int paramInt7);
/*    */   
/*    */   static native int dgesvd(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double[] paramArrayOfdouble1, int paramInt5, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt6, double[] paramArrayOfdouble4, int paramInt7, double[] paramArrayOfdouble5, int paramInt8);
/*    */   
/*    */   static native int dsyevr(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double[] paramArrayOfdouble1, int paramInt5, double paramDouble1, double paramDouble2, int paramInt6, int paramInt7, double paramDouble3, int[] paramArrayOfint1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, int paramInt8, int[] paramArrayOfint2, double[] paramArrayOfdouble4, int paramInt9, int[] paramArrayOfint3, int paramInt10);
/*    */   
/*    */   static native int dgeev(int paramInt1, int paramInt2, int paramInt3, double[] paramArrayOfdouble1, int paramInt4, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double[] paramArrayOfdouble4, int paramInt5, double[] paramArrayOfdouble5, int paramInt6, double[] paramArrayOfdouble6, int paramInt7);
/*    */   
/*    */   static {
/* 93 */     System.loadLibrary("edu_mines_jtk_lapack");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/Lapack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */