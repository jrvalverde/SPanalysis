/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrentMinFinder
/*     */ {
/*     */   public BrentMinFinder(Function f) {
/*  66 */     this._f = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double f(double x) {
/*  75 */     return this._f.evaluate(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double findMin(double a, double b, double tol) {
/*  86 */     double x = a + GSI * (b - a);
/*  87 */     double v = x;
/*  88 */     double w = x;
/*  89 */     double fx = f(x);
/*  90 */     double fv = fx;
/*  91 */     double fw = fx;
/*  92 */     double d = 0.0D;
/*  93 */     double e = 0.0D;
/*     */ 
/*     */ 
/*     */     
/*  97 */     double xm = 0.5D * (a + b), tol1 = EPS * MathPlus.abs(x) + tol / 3.0D, tol2 = 2.0D * tol1;
/*  98 */     for (; MathPlus.abs(x - xm) > tol2 - 0.5D * (b - a); 
/*  99 */       xm = 0.5D * (a + b), tol1 = EPS * MathPlus.abs(x) + tol / 3.0D, tol2 = 2.0D * tol1) {
/*     */ 
/*     */       
/* 102 */       boolean gsstep = (MathPlus.abs(e) <= tol1);
/*     */ 
/*     */       
/* 105 */       if (!gsstep) {
/*     */ 
/*     */         
/* 108 */         double r = (x - w) * (fx - fv);
/* 109 */         double q = (x - v) * (fx - fw);
/* 110 */         double p = (x - v) * q - (x - w) * r;
/* 111 */         q = 2.0D * (q - r);
/* 112 */         if (q > 0.0D)
/* 113 */           p = -p; 
/* 114 */         q = MathPlus.abs(q);
/* 115 */         r = e;
/* 116 */         e = d;
/*     */ 
/*     */ 
/*     */         
/* 120 */         if (MathPlus.abs(p) < MathPlus.abs(0.5D * q * r) && p > q * (a - x) && p < q * (b - x)) {
/* 121 */           d = p / q;
/* 122 */           double d1 = x + d;
/* 123 */           if (d1 - a < tol2 || b - d1 < tol2) {
/* 124 */             d = (xm >= x) ? tol1 : -tol1;
/*     */           }
/*     */         } else {
/*     */           
/* 128 */           gsstep = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 133 */       if (gsstep) {
/* 134 */         e = (x >= xm) ? (a - x) : (b - x);
/* 135 */         d = GSI * e;
/*     */       } 
/*     */ 
/*     */       
/* 139 */       double u = x + ((MathPlus.abs(d) >= tol1) ? d : ((d >= 0.0D) ? tol1 : -tol1));
/* 140 */       double fu = f(u);
/*     */ 
/*     */       
/* 143 */       if (fu <= fx) {
/* 144 */         if (u >= x) {
/* 145 */           a = x;
/*     */         } else {
/* 147 */           b = x;
/* 148 */         }  v = w;
/* 149 */         w = x;
/* 150 */         x = u;
/* 151 */         fv = fw;
/* 152 */         fw = fx;
/* 153 */         fx = fu;
/*     */       } else {
/* 155 */         if (u < x) {
/* 156 */           a = u;
/*     */         } else {
/* 158 */           b = u;
/* 159 */         }  if (fu <= fw || w == x) {
/* 160 */           v = w;
/* 161 */           w = u;
/* 162 */           fv = fw;
/* 163 */           fw = fu;
/* 164 */         } else if (fu <= fv || v == x || v == w) {
/* 165 */           v = u;
/* 166 */           fv = fu;
/*     */         } 
/*     */       } 
/*     */     } 
/* 170 */     return x;
/*     */   }
/*     */ 
/*     */   
/* 174 */   private static final double GSI = 0.5D * (3.0D - MathPlus.sqrt(5.0D));
/*     */ 
/*     */   
/* 177 */   private static final double EPS = MathPlus.sqrt(2.220446049250313E-16D);
/*     */   private Function _f;
/*     */   
/*     */   public static interface Function {
/*     */     double evaluate(double param1Double);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/BrentMinFinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */