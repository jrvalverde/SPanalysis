/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PickResult
/*     */ {
/*     */   private MouseEvent _event;
/*     */   private Node[] _nodes;
/*     */   private Point3 _pointLocal;
/*     */   private Point3 _pointWorld;
/*     */   private Point3 _pointPixel;
/*     */   private double _depthPixel;
/*     */   private Matrix44 _localToWorld;
/*     */   private Matrix44 _localToPixel;
/*     */   private Matrix44 _worldToPixel;
/*     */   
/*     */   public PickResult(PickContext pc, Point3 point) {
/*  32 */     this._event = pc.getMouseEvent();
/*  33 */     this._nodes = pc.getNodes();
/*  34 */     this._localToWorld = pc.getLocalToWorld();
/*  35 */     this._localToPixel = pc.getLocalToPixel();
/*  36 */     this._worldToPixel = pc.getWorldToPixel();
/*  37 */     this._pointLocal = new Point3(point);
/*  38 */     this._pointWorld = this._localToWorld.times(point);
/*  39 */     this._pointPixel = this._localToPixel.times(point);
/*  40 */     this._depthPixel = this._pointPixel.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MouseEvent getMouseEvent() {
/*  49 */     return this._event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node[] getNodes() {
/*  58 */     return (Node[])this._nodes.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode() {
/*  67 */     return this._nodes[this._nodes.length - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dragable getDragableNode() {
/*  78 */     return (Dragable)getNode(Dragable.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Selectable getSelectableNode() {
/*  89 */     return (Selectable)getNode(Selectable.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode(Class<?> nodeClass) {
/* 100 */     for (int i = this._nodes.length - 1; i >= 0; i--) {
/* 101 */       Node node = this._nodes[i];
/* 102 */       if (nodeClass.isAssignableFrom(node.getClass()))
/* 103 */         return node; 
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getPointLocal() {
/* 113 */     return new Point3(this._pointLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getPointWorld() {
/* 121 */     return new Point3(this._pointWorld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getPointPixel() {
/* 129 */     return new Point3(this._pointPixel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPixelZ() {
/* 139 */     return this._depthPixel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getLocalToWorld() {
/* 147 */     return new Matrix44(this._localToWorld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getLocalToPixel() {
/* 155 */     return new Matrix44(this._localToPixel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getWorldToPixel() {
/* 163 */     return new Matrix44(this._worldToPixel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ViewCanvas getViewCanvas() {
/* 171 */     return (ViewCanvas)this._event.getSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public View getView() {
/* 179 */     return getViewCanvas().getView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public World getWorld() {
/* 187 */     return getView().getWorld();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/PickResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */