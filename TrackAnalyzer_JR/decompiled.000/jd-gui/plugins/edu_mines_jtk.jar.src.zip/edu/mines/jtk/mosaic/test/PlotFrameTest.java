/*    */ package edu.mines.jtk.mosaic.test;
/*    */ 
/*    */ import edu.mines.jtk.awt.ColorMap;
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.mosaic.PixelsView;
/*    */ import edu.mines.jtk.mosaic.PlotFrame;
/*    */ import edu.mines.jtk.mosaic.PlotPanel;
/*    */ import edu.mines.jtk.mosaic.PointsView;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlotFrameTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 24 */     SwingUtilities.invokeLater(new Runnable() {
/*    */           public void run() {
/* 26 */             PlotFrameTest.go();
/*    */           }
/*    */         });
/*    */   }
/*    */   private static void go() {
/* 31 */     int n1 = 101;
/* 32 */     double d1 = 0.03D;
/* 33 */     double f1 = -1.3D;
/* 34 */     Sampling s1 = new Sampling(n1, d1, f1);
/* 35 */     int n2 = 101;
/* 36 */     double d2 = 29.0D;
/* 37 */     double f2 = 33.0D;
/* 38 */     Sampling s2 = new Sampling(n2, d2, f2);
/*    */     
/* 40 */     float[][] f = Array.sin(Array.rampfloat(0.0F, 0.1F, 0.1F, n1, n2));
/* 41 */     float ax = (float)(f2 + d2 * n2 / 2.0D);
/* 42 */     float bx = (float)(0.45D * d2 * (n2 - 1));
/* 43 */     float cx = (float)(0.1D / d1);
/* 44 */     float[] x1 = Array.rampfloat((float)f1, (float)d1, n1);
/* 45 */     float[] x2 = Array.add(ax, Array.mul(bx, Array.sin(Array.mul(cx, x1))));
/*    */     
/* 47 */     PlotPanel.Orientation orientation = PlotPanel.Orientation.X1DOWN_X2RIGHT;
/* 48 */     PlotPanel panel = new PlotPanel(1, 2, orientation);
/*    */     
/* 50 */     PixelsView pxv0 = panel.addPixels(0, 0, s1, s2, f);
/* 51 */     PixelsView pxv1 = panel.addPixels(0, 1, s1, s2, f);
/* 52 */     pxv0.setColorModel(ColorMap.GRAY);
/* 53 */     pxv1.setColorModel(ColorMap.JET);
/*    */     
/* 55 */     PointsView ptv0 = panel.addPoints(0, 0, x1, x2);
/* 56 */     PointsView ptv1 = panel.addPoints(0, 1, x1, x2);
/* 57 */     ptv0.setStyle("r--.");
/* 58 */     ptv1.setStyle("k-o");
/*    */     
/* 60 */     panel.addColorBar("amplitude");
/* 61 */     panel.setTitle("A Test of PlotFrame");
/* 62 */     panel.setVLabel("depth (km)");
/* 63 */     panel.setHLabel(0, "offset (km)");
/* 64 */     panel.setHLabel(1, "velocity (km/s)");
/*    */     
/* 66 */     PlotFrame frame = new PlotFrame(panel);
/* 67 */     frame.setDefaultCloseOperation(3);
/* 68 */     frame.setFontSize(24);
/* 69 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/PlotFrameTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */