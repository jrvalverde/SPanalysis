/*     */ package edu.mines.jtk.io.test;
/*     */ 
/*     */ import edu.mines.jtk.io.DataFile;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFileTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  27 */     TestSuite suite = new TestSuite(DataFileTest.class);
/*  28 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testBigEndian() throws IOException {
/*  32 */     test(DataFile.ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */   
/*     */   public void testLittleEndian() throws IOException {
/*  36 */     test(DataFile.ByteOrder.LITTLE_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void test(DataFile.ByteOrder order) throws IOException {
/*  43 */     int n = 10000;
/*  44 */     File file = null;
/*  45 */     DataFile df = null;
/*     */     try {
/*  47 */       file = File.createTempFile("junk", "dat");
/*  48 */       df = new DataFile(file, "rw", order);
/*  49 */       testFloat(df, n);
/*  50 */       testDouble(df, n);
/*     */     } finally {
/*  52 */       if (df != null)
/*  53 */         df.close(); 
/*  54 */       if (file != null)
/*  55 */         file.delete(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void testFloat(DataFile df, int n) throws IOException {
/*  60 */     float[] a = Array.randfloat(n);
/*  61 */     float[] b = Array.zerofloat(n);
/*     */     
/*  63 */     df.seek(0L);
/*  64 */     df.writeFloats(a);
/*  65 */     df.seek(0L);
/*  66 */     df.readFloats(b); int i;
/*  67 */     for (i = 0; i < n; i++) {
/*  68 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  70 */     Array.zero(b);
/*  71 */     df.seek(0L);
/*  72 */     for (i = 0; i < n; i++)
/*  73 */       df.writeFloat(a[i]); 
/*  74 */     df.seek(0L);
/*  75 */     for (i = 0; i < n; i++)
/*  76 */       b[i] = df.readFloat(); 
/*  77 */     for (i = 0; i < n; i++) {
/*  78 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  80 */     df.seek(0L);
/*  81 */     for (i = 0; i < n; i++) {
/*  82 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(df.readFloat()));
/*     */     }
/*  84 */     df.seek(0L);
/*  85 */     for (i = 0; i < n; i++)
/*  86 */       df.writeFloat(a[i]); 
/*  87 */     Array.zero(b);
/*  88 */     df.seek(0L);
/*  89 */     df.readFloats(b);
/*  90 */     for (i = 0; i < n; i++) {
/*  91 */       assertEquals(Float.valueOf(a[i]), Float.valueOf(b[i]));
/*     */     }
/*  93 */     int mw = 3141;
/*  94 */     df.seek(0L); int j;
/*  95 */     for (j = 0; j < n; j += mw)
/*  96 */       df.writeFloats(a, j, Math.min(n - j, mw)); 
/*  97 */     Array.zero(b);
/*  98 */     df.seek(0L);
/*  99 */     int mr = 2739; int m;
/* 100 */     for (m = 0; m < n; m += mr)
/* 101 */       df.readFloats(b, m, Math.min(n - m, mr)); 
/* 102 */     for (int k = 0; k < n; k++)
/* 103 */       assertEquals(Float.valueOf(a[k]), Float.valueOf(b[k])); 
/*     */   }
/*     */   
/*     */   private static void testDouble(DataFile df, int n) throws IOException {
/* 107 */     double[] a = Array.randdouble(n);
/* 108 */     double[] b = Array.zerodouble(n);
/*     */     
/* 110 */     df.seek(0L);
/* 111 */     df.writeDoubles(a);
/* 112 */     df.seek(0L);
/* 113 */     df.readDoubles(b); int i;
/* 114 */     for (i = 0; i < n; i++) {
/* 115 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 117 */     Array.zero(b);
/* 118 */     df.seek(0L);
/* 119 */     for (i = 0; i < n; i++)
/* 120 */       df.writeDouble(a[i]); 
/* 121 */     df.seek(0L);
/* 122 */     for (i = 0; i < n; i++)
/* 123 */       b[i] = df.readDouble(); 
/* 124 */     for (i = 0; i < n; i++) {
/* 125 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 127 */     df.seek(0L);
/* 128 */     for (i = 0; i < n; i++) {
/* 129 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(df.readDouble()));
/*     */     }
/* 131 */     df.seek(0L);
/* 132 */     for (i = 0; i < n; i++)
/* 133 */       df.writeDouble(a[i]); 
/* 134 */     Array.zero(b);
/* 135 */     df.seek(0L);
/* 136 */     df.readDoubles(b);
/* 137 */     for (i = 0; i < n; i++) {
/* 138 */       assertEquals(Double.valueOf(a[i]), Double.valueOf(b[i]));
/*     */     }
/* 140 */     int mw = 3141;
/* 141 */     df.seek(0L); int j;
/* 142 */     for (j = 0; j < n; j += mw)
/* 143 */       df.writeDoubles(a, j, Math.min(n - j, mw)); 
/* 144 */     Array.zero(b);
/* 145 */     df.seek(0L);
/* 146 */     int mr = 2739; int m;
/* 147 */     for (m = 0; m < n; m += mr)
/* 148 */       df.readDoubles(b, m, Math.min(n - m, mr)); 
/* 149 */     for (int k = 0; k < n; k++)
/* 150 */       assertEquals(Double.valueOf(a[k]), Double.valueOf(b[k])); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/test/DataFileTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */