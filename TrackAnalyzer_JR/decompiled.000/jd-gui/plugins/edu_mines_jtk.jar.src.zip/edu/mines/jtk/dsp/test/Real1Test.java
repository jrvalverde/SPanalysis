/*    */ package edu.mines.jtk.dsp.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Real1;
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Real1Test
/*    */   extends TestCase
/*    */ {
/*    */   static final int N = 100;
/*    */   static final double TINY = 1.1920928955078125E-4D;
/*    */   
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(Real1Test.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 29 */   static final Real1 FILL1 = Real1.fill(1.0D, 100);
/* 30 */   static final Real1 FILL2 = Real1.fill(2.0D, 100);
/* 31 */   static final Real1 RAMP1 = Real1.ramp(0.0D, 1.0D, 100);
/* 32 */   static final Real1 RAMP2 = Real1.ramp(0.0D, 2.0D, 100);
/*    */   
/*    */   public void testMath() {
/* 35 */     Real1 ra = RAMP1;
/* 36 */     Real1 rb = RAMP1;
/* 37 */     Real1 rc = ra.plus(rb);
/* 38 */     Real1 re = RAMP2;
/* 39 */     assertEquals(re, rc);
/*    */   }
/*    */   
/*    */   public void testResample() {
/* 43 */     Real1 ra = FILL1;
/* 44 */     Sampling sa = ra.getSampling();
/* 45 */     int n1 = sa.getCount();
/* 46 */     double d1 = sa.getDelta();
/*    */     
/* 48 */     int m1 = n1 / 3;
/* 49 */     Sampling sb = sa.shift(-m1 * d1);
/* 50 */     Real1 rb = ra.resample(sb);
/* 51 */     float[] vb = rb.getValues(); int i1;
/* 52 */     for (i1 = 0; i1 < m1; i1++)
/* 53 */       assertEquals(0.0D, vb[i1], 0.0D); 
/* 54 */     for (i1 = m1; i1 < n1; i1++) {
/* 55 */       assertEquals(1.0D, vb[i1], 0.0D);
/*    */     }
/* 57 */     Sampling sc = sa.shift(m1 * d1);
/* 58 */     Real1 rc = ra.resample(sc);
/* 59 */     float[] vc = rc.getValues(); int i;
/* 60 */     for (i = 0; i < n1 - m1; i++)
/* 61 */       assertEquals(1.0D, vc[i], 0.0D); 
/* 62 */     for (i = n1 - m1; i < n1; i++)
/* 63 */       assertEquals(0.0D, vc[i], 0.0D); 
/*    */   }
/*    */   
/*    */   void assertEquals(Real1 e, Real1 a) {
/* 67 */     Sampling se = e.getSampling();
/* 68 */     Sampling sa = a.getSampling();
/* 69 */     assertTrue(sa.isEquivalentTo(se));
/* 70 */     float[] ve = e.getValues();
/* 71 */     float[] va = a.getValues();
/* 72 */     int n = ve.length;
/* 73 */     for (int i = 0; i < n; i++)
/* 74 */       assertEquals(ve[i], va[i], 1.1920928955078125E-4D); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/Real1Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */