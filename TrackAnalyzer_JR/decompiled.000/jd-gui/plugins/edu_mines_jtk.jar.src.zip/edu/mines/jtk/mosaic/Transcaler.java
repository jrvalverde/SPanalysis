/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transcaler
/*     */ {
/*     */   private static final double DMIN = -32768.0D;
/*     */   private static final double DMAX = 32767.0D;
/*     */   private double _x1u;
/*     */   private double _y1u;
/*     */   private double _x2u;
/*     */   private double _y2u;
/*     */   private int _x1d;
/*     */   private int _y1d;
/*     */   private int _x2d;
/*     */   private int _y2d;
/*     */   private double _xushift;
/*     */   private double _xuscale;
/*     */   private double _yushift;
/*     */   private double _yuscale;
/*     */   private double _xdshift;
/*     */   private double _xdscale;
/*     */   private double _ydshift;
/*     */   private double _ydscale;
/*     */   
/*     */   public Transcaler() {
/*  44 */     this(0.0D, 0.0D, 1.0D, 1.0D, 0, 0, 1, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transcaler(int width, int height) {
/*  55 */     this(0.0D, 0.0D, 1.0D, 1.0D, 0, 0, width - 1, height - 1);
/*  56 */     Check.argument((width > 0), "width>0");
/*  57 */     Check.argument((height > 0), "height>0");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transcaler(double x1u, double y1u, double x2u, double y2u, int x1d, int y1d, int x2d, int y2d) {
/*  75 */     setMapping(x1u, y1u, x2u, y2u, x1d, y1d, x2d, y2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(double x1u, double y1u, double x2u, double y2u, int x1d, int y1d, int x2d, int y2d) {
/*  93 */     this._x1u = x1u; this._x2u = x2u; this._y1u = y1u; this._y2u = y2u;
/*  94 */     this._x1d = x1d; this._x2d = x2d; this._y1d = y1d; this._y2d = y2d;
/*  95 */     computeShiftAndScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(double x1u, double y1u, double x2u, double y2u) {
/* 106 */     this._x1u = x1u; this._x2u = x2u; this._y1u = y1u; this._y2u = y2u;
/* 107 */     computeShiftAndScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(int x1d, int y1d, int x2d, int y2d) {
/* 118 */     this._x1d = x1d; this._x2d = x2d; this._y1d = y1d; this._y2d = y2d;
/* 119 */     computeShiftAndScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapping(int width, int height) {
/* 128 */     Check.argument((width > 0), "width>0");
/* 129 */     Check.argument((height > 0), "height>0");
/* 130 */     setMapping(0, 0, width - 1, height - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transcaler combineWith(Projector xp, Projector yp) {
/* 142 */     double x1v = xp.v(this._x1u);
/* 143 */     double y1v = yp.v(this._y1u);
/* 144 */     double x2v = xp.v(this._x2u);
/* 145 */     double y2v = yp.v(this._y2u);
/* 146 */     return new Transcaler(x1v, y1v, x2v, y2v, this._x1d, this._y1d, this._x2d, this._y2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int x(double xu) {
/* 155 */     double xd = this._xushift + this._xuscale * xu;
/* 156 */     if (xd < -32768.0D) {
/* 157 */       xd = -32768.0D;
/* 158 */     } else if (xd > 32767.0D) {
/* 159 */       xd = 32767.0D;
/*     */     } 
/* 161 */     return (int)xd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int y(double yu) {
/* 170 */     double yd = this._yushift + this._yuscale * yu;
/* 171 */     if (yd < -32768.0D) {
/* 172 */       yd = -32768.0D;
/* 173 */     } else if (yd > 32767.0D) {
/* 174 */       yd = 32767.0D;
/*     */     } 
/* 176 */     return (int)yd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int width(double wu) {
/* 185 */     double wd = this._xuscale * wu;
/* 186 */     if (wd < -32768.0D) {
/* 187 */       wd = -32768.0D;
/* 188 */     } else if (wd > 32767.0D) {
/* 189 */       wd = 32767.0D;
/*     */     } 
/* 191 */     return (int)(wd + 1.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int height(double hu) {
/* 200 */     double hd = this._yuscale * hu;
/* 201 */     if (hd < -32768.0D) {
/* 202 */       hd = -32768.0D;
/* 203 */     } else if (hd > 32767.0D) {
/* 204 */       hd = 32767.0D;
/*     */     } 
/* 206 */     return (int)(hd + 1.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double x(int xd) {
/* 215 */     return this._xdshift + this._xdscale * xd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double y(int yd) {
/* 224 */     return this._ydshift + this._ydscale * yd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double width(int wd) {
/* 233 */     return this._xdscale * (wd - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double height(int hd) {
/* 242 */     return this._ydscale * (hd - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeShiftAndScale() {
/* 257 */     if (this._x1u != this._x2u) {
/* 258 */       this._xuscale = (this._x2d - this._x1d) / (this._x2u - this._x1u);
/* 259 */       this._xushift = this._x1d - this._x1u * this._xuscale + 0.5D;
/*     */     } else {
/* 261 */       this._xushift = 0.5D * (this._x1d + this._x2d) + 0.5D;
/* 262 */       this._xuscale = 0.0D;
/*     */     } 
/* 264 */     if (this._x1d != this._x2d) {
/* 265 */       this._xdscale = (this._x2u - this._x1u) / (this._x2d - this._x1d);
/* 266 */       this._xdshift = this._x1u - this._x1d * this._xdscale;
/*     */     } else {
/* 268 */       this._xdshift = 0.5D * (this._x1u + this._x2u);
/* 269 */       this._xdscale = 0.0D;
/*     */     } 
/* 271 */     if (this._y1u != this._y2u) {
/* 272 */       this._yuscale = (this._y2d - this._y1d) / (this._y2u - this._y1u);
/* 273 */       this._yushift = this._y1d - this._y1u * this._yuscale + 0.5D;
/*     */     } else {
/* 275 */       this._yushift = 0.5D * (this._y1d + this._y2d) + 0.5D;
/* 276 */       this._yuscale = 0.0D;
/*     */     } 
/* 278 */     if (this._y1d != this._y2d) {
/* 279 */       this._ydscale = (this._y2u - this._y1u) / (this._y2d - this._y1d);
/* 280 */       this._ydshift = this._y1u - this._y1d * this._ydscale;
/*     */     } else {
/* 282 */       this._ydshift = 0.5D * (this._y1u + this._y2u);
/* 283 */       this._ydscale = 0.0D;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/Transcaler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */