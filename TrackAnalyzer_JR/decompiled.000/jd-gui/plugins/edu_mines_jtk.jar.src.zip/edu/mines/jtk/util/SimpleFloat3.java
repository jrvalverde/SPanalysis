/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleFloat3
/*     */   implements Float3
/*     */ {
/*     */   private int _n1;
/*     */   private int _n2;
/*     */   private int _n3;
/*     */   private float[][][] _a;
/*     */   
/*     */   public SimpleFloat3(int n1, int n2, int n3) {
/*  25 */     this._n1 = n1;
/*  26 */     this._n2 = n2;
/*  27 */     this._n3 = n3;
/*  28 */     this._a = new float[n3][n2][n1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFloat3(float[][][] a) {
/*  37 */     this._n1 = (a[0][0]).length;
/*  38 */     this._n2 = (a[0]).length;
/*  39 */     this._n3 = a.length;
/*  40 */     this._a = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getN1() {
/*  47 */     return this._n1;
/*     */   }
/*     */   
/*     */   public int getN2() {
/*  51 */     return this._n2;
/*     */   }
/*     */   
/*     */   public int getN3() {
/*  55 */     return this._n3;
/*     */   }
/*     */   
/*     */   public void get1(int m1, int j1, int j2, int j3, float[] s) {
/*  59 */     float[] a32 = this._a[j3][j2];
/*  60 */     for (int i1 = 0; i1 < m1; i1++) {
/*  61 */       s[i1] = a32[i1 + j1];
/*     */     }
/*     */   }
/*     */   
/*     */   public void get2(int m2, int j1, int j2, int j3, float[] s) {
/*  66 */     float[][] a3 = this._a[j3];
/*  67 */     for (int i2 = 0; i2 < m2; i2++) {
/*  68 */       s[i2] = a3[i2 + j2][j1];
/*     */     }
/*     */   }
/*     */   
/*     */   public void get3(int m3, int j1, int j2, int j3, float[] s) {
/*  73 */     for (int i3 = 0; i3 < m3; i3++) {
/*  74 */       s[i3] = this._a[i3 + j3][j2][j1];
/*     */     }
/*     */   }
/*     */   
/*     */   public void get12(int m1, int m2, int j1, int j2, int j3, float[][] s) {
/*  79 */     for (int i2 = 0; i2 < m2; i2++) {
/*  80 */       float[] a32 = this._a[j3][i2 + j2];
/*  81 */       float[] s2 = s[i2];
/*  82 */       for (int i1 = 0; i1 < m1; i1++) {
/*  83 */         s2[i1] = a32[i1 + j1];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void get13(int m1, int m3, int j1, int j2, int j3, float[][] s) {
/*  89 */     for (int i3 = 0; i3 < m3; i3++) {
/*  90 */       float[] a32 = this._a[i3 + j3][j2];
/*  91 */       float[] s3 = s[i3];
/*  92 */       for (int i1 = 0; i1 < m1; i1++) {
/*  93 */         s3[i1] = a32[i1 + j1];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void get23(int m2, int m3, int j1, int j2, int j3, float[][] s) {
/*  99 */     for (int i3 = 0; i3 < m3; i3++) {
/* 100 */       float[][] a3 = this._a[i3 + j3];
/* 101 */       float[] s3 = s[i3];
/* 102 */       for (int i2 = 0; i2 < m2; i2++) {
/* 103 */         s3[i2] = a3[i2 + j2][j1];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void get123(int m1, int m2, int m3, int j1, int j2, int j3, float[][][] s) {
/* 113 */     for (int i3 = 0; i3 < m3; i3++) {
/* 114 */       float[][] a3 = this._a[i3 + j3];
/* 115 */       float[][] s3 = s[i3];
/* 116 */       for (int i2 = 0; i2 < m2; i2++) {
/* 117 */         float[] a32 = a3[i2 + j2];
/* 118 */         float[] s32 = s3[i2];
/* 119 */         for (int i1 = 0; i1 < m1; i1++) {
/* 120 */           s32[i1] = a32[i1 + j1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void get123(int m1, int m2, int m3, int j1, int j2, int j3, float[] s) {
/* 131 */     for (int i3 = 0, is = 0; i3 < m3; i3++) {
/* 132 */       float[][] a3 = this._a[i3 + j3];
/* 133 */       for (int i2 = 0; i2 < m2; i2++) {
/* 134 */         float[] a32 = a3[i2 + j2];
/* 135 */         for (int i1 = 0; i1 < m1; i1++) {
/* 136 */           s[is++] = a32[i1 + j1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set1(int m1, int j1, int j2, int j3, float[] s) {
/* 143 */     float[] a32 = this._a[j3][j2];
/* 144 */     for (int i1 = 0; i1 < m1; i1++) {
/* 145 */       a32[i1 + j1] = s[i1];
/*     */     }
/*     */   }
/*     */   
/*     */   public void set2(int m2, int j1, int j2, int j3, float[] s) {
/* 150 */     float[][] a3 = this._a[j3];
/* 151 */     for (int i2 = 0; i2 < m2; i2++) {
/* 152 */       a3[i2 + j2][j1] = s[i2];
/*     */     }
/*     */   }
/*     */   
/*     */   public void set3(int m3, int j1, int j2, int j3, float[] s) {
/* 157 */     for (int i3 = 0; i3 < m3; i3++) {
/* 158 */       this._a[i3 + j3][j2][j1] = s[i3];
/*     */     }
/*     */   }
/*     */   
/*     */   public void set12(int m1, int m2, int j1, int j2, int j3, float[][] s) {
/* 163 */     for (int i2 = 0; i2 < m2; i2++) {
/* 164 */       float[] a32 = this._a[j3][i2 + j2];
/* 165 */       float[] s2 = s[i2];
/* 166 */       for (int i1 = 0; i1 < m1; i1++) {
/* 167 */         a32[i1 + j1] = s2[i1];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set13(int m1, int m3, int j1, int j2, int j3, float[][] s) {
/* 173 */     for (int i3 = 0; i3 < m3; i3++) {
/* 174 */       float[] a32 = this._a[i3 + j3][j2];
/* 175 */       float[] s3 = s[i3];
/* 176 */       for (int i1 = 0; i1 < m1; i1++) {
/* 177 */         a32[i1 + j1] = s3[i1];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set23(int m2, int m3, int j1, int j2, int j3, float[][] s) {
/* 183 */     for (int i3 = 0; i3 < m3; i3++) {
/* 184 */       float[][] a3 = this._a[i3 + j3];
/* 185 */       float[] s3 = s[i3];
/* 186 */       for (int i2 = 0; i2 < m2; i2++) {
/* 187 */         a3[i2 + j2][j1] = s3[i2];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set123(int m1, int m2, int m3, int j1, int j2, int j3, float[][][] s) {
/* 197 */     for (int i3 = 0; i3 < m3; i3++) {
/* 198 */       float[][] a3 = this._a[i3 + j3];
/* 199 */       float[][] s3 = s[i3];
/* 200 */       for (int i2 = 0; i2 < m2; i2++) {
/* 201 */         float[] a32 = a3[i2 + j2];
/* 202 */         float[] s32 = s3[i2];
/* 203 */         for (int i1 = 0; i1 < m1; i1++) {
/* 204 */           a32[i1 + j1] = s32[i1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set123(int m1, int m2, int m3, int j1, int j2, int j3, float[] s) {
/* 215 */     for (int i3 = 0, is = 0; i3 < m3; i3++) {
/* 216 */       float[][] a3 = this._a[i3 + j3];
/* 217 */       for (int i2 = 0; i2 < m2; i2++) {
/* 218 */         float[] a32 = a3[i2 + j2];
/* 219 */         for (int i1 = 0; i1 < m1; i1++)
/* 220 */           a32[i1 + j1] = s[is++]; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/SimpleFloat3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */