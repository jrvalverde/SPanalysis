/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Recursive2ndOrderFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Recursive2ndOrderFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(Recursive2ndOrderFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1() {
/*  28 */     test1(2.0F, 0.0F, 0.0F, 0.9F, 0.0F);
/*  29 */     test1(2.0F, 4.0F, 0.0F, 0.9F, 0.0F);
/*  30 */     test1(2.0F, 4.0F, 0.0F, 1.8F, 0.81F);
/*  31 */     test1(0.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*  32 */     test1(2.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*     */   }
/*     */   
/*     */   public void test1(float b0, float b1, float b2, float a1, float a2) {
/*  36 */     int n = 100;
/*     */     
/*  38 */     float[] x = Array.randfloat(n);
/*  39 */     Recursive2ndOrderFilter rf = new Recursive2ndOrderFilter(b0, b1, b2, a1, a2);
/*     */     
/*  41 */     float[] y1 = Array.copy(x);
/*  42 */     rf.applyForward(y1, y1);
/*  43 */     float[] y2 = Array.reverse(x);
/*  44 */     rf.applyReverse(y2, y2);
/*  45 */     y2 = Array.reverse(y2);
/*  46 */     assertEqual(y1, y2);
/*     */     
/*  48 */     rf.accumulateForward(y1, y1);
/*  49 */     y2 = Array.reverse(y2);
/*  50 */     rf.accumulateReverse(y2, y2);
/*  51 */     y2 = Array.reverse(y2);
/*  52 */     assertEqual(y1, y2);
/*     */   }
/*     */   
/*     */   public void test2() {
/*  56 */     test2(2.0F, 0.0F, 0.0F, 0.9F, 0.0F);
/*  57 */     test2(2.0F, 4.0F, 0.0F, 0.9F, 0.0F);
/*  58 */     test2(2.0F, 4.0F, 0.0F, 1.8F, 0.81F);
/*  59 */     test2(0.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*  60 */     test2(2.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*     */   }
/*     */   
/*     */   public void test2(float b0, float b1, float b2, float a1, float a2) {
/*  64 */     int n = 20;
/*     */     
/*  66 */     float[][] x = Array.randfloat(n, n);
/*  67 */     Recursive2ndOrderFilter rf = new Recursive2ndOrderFilter(b0, b1, b2, a1, a2);
/*     */     
/*  69 */     float[][] y1 = Array.copy(x);
/*  70 */     rf.apply1Forward(y1, y1);
/*  71 */     rf.accumulate1Forward(y1, y1);
/*     */     
/*  73 */     float[][] y2 = Array.transpose(x);
/*  74 */     rf.apply2Forward(y2, y2);
/*  75 */     rf.accumulate2Forward(y2, y2);
/*  76 */     y2 = Array.transpose(y2);
/*  77 */     assertEqual(y1, y2);
/*     */     
/*  79 */     y1 = Array.copy(x);
/*  80 */     rf.apply1Reverse(y1, y1);
/*  81 */     rf.accumulate1Reverse(y1, y1);
/*     */     
/*  83 */     y2 = Array.transpose(x);
/*  84 */     rf.apply2Reverse(y2, y2);
/*  85 */     rf.accumulate2Reverse(y2, y2);
/*  86 */     y2 = Array.transpose(y2);
/*  87 */     assertEqual(y1, y2);
/*     */   }
/*     */   
/*     */   public void test3() {
/*  91 */     test3(2.0F, 0.0F, 0.0F, 0.9F, 0.0F);
/*  92 */     test3(2.0F, 4.0F, 0.0F, 0.9F, 0.0F);
/*  93 */     test3(2.0F, 4.0F, 0.0F, 1.8F, 0.81F);
/*  94 */     test3(0.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*  95 */     test3(2.0F, 4.0F, 2.0F, 1.8F, 0.81F);
/*     */   }
/*     */   
/*     */   public void test3(float b0, float b1, float b2, float a1, float a2) {
/*  99 */     int n = 20;
/*     */     
/* 101 */     float[][][] x = Array.randfloat(n, n, n);
/* 102 */     Recursive2ndOrderFilter rf = new Recursive2ndOrderFilter(b0, b1, b2, a1, a2);
/*     */     
/* 104 */     float[][][] y1 = Array.copy(x);
/* 105 */     rf.apply1Forward(y1, y1);
/* 106 */     rf.accumulate1Forward(y1, y1);
/*     */     
/* 108 */     float[][][] y2 = transpose12(x);
/* 109 */     rf.apply2Forward(y2, y2);
/* 110 */     rf.accumulate2Forward(y2, y2);
/* 111 */     y2 = transpose12(y2);
/* 112 */     assertEqual(y1, y2);
/*     */     
/* 114 */     y2 = transpose13(x);
/* 115 */     rf.apply3Forward(y2, y2);
/* 116 */     rf.accumulate3Forward(y2, y2);
/* 117 */     y2 = transpose13(y2);
/* 118 */     assertEqual(y1, y2);
/*     */     
/* 120 */     y1 = Array.copy(x);
/* 121 */     rf.apply1Reverse(y1, y1);
/* 122 */     rf.accumulate1Reverse(y1, y1);
/*     */     
/* 124 */     y2 = transpose12(x);
/* 125 */     rf.apply2Reverse(y2, y2);
/* 126 */     rf.accumulate2Reverse(y2, y2);
/* 127 */     y2 = transpose12(y2);
/* 128 */     assertEqual(y1, y2);
/*     */     
/* 130 */     y2 = transpose13(x);
/* 131 */     rf.apply3Reverse(y2, y2);
/* 132 */     rf.accumulate3Reverse(y2, y2);
/* 133 */     y2 = transpose13(y2);
/* 134 */     assertEqual(y1, y2);
/*     */   }
/*     */   
/*     */   private void assertEqual(float[] re, float[] ra) {
/* 138 */     int n = re.length;
/* 139 */     float tolerance = n * 1.1920929E-7F;
/* 140 */     for (int i = 0; i < n; i++)
/* 141 */       assertEquals(re[i], ra[i], tolerance); 
/*     */   }
/*     */   
/*     */   private void assertEqual(float[][] re, float[][] ra) {
/* 145 */     int n2 = re.length;
/* 146 */     int n1 = (re[0]).length;
/* 147 */     float tolerance = (n1 * n2) * 1.1920929E-7F;
/* 148 */     for (int i2 = 0; i2 < n2; i2++) {
/* 149 */       for (int i1 = 0; i1 < n1; i1++)
/* 150 */         assertEquals(re[i2][i1], ra[i2][i1], tolerance); 
/*     */     } 
/*     */   }
/*     */   private void assertEqual(float[][][] re, float[][][] ra) {
/* 154 */     int n3 = re.length;
/* 155 */     int n2 = (re[0]).length;
/* 156 */     int n1 = (re[0][0]).length;
/* 157 */     float tolerance = (n1 * n2 * n3) * 1.1920929E-7F;
/* 158 */     for (int i3 = 0; i3 < n3; i3++) {
/* 159 */       for (int i2 = 0; i2 < n2; i2++) {
/* 160 */         for (int i1 = 0; i1 < n1; i1++)
/* 161 */           assertEquals(re[i3][i2][i1], ra[i3][i2][i1], tolerance); 
/*     */       } 
/*     */     } 
/*     */   } private static float[][][] transpose12(float[][][] x) {
/* 165 */     int n3 = x.length;
/* 166 */     int n2 = (x[0]).length;
/* 167 */     int n1 = (x[0][0]).length;
/* 168 */     float[][][] y = new float[n3][n1][n2];
/* 169 */     for (int i3 = 0; i3 < n3; i3++) {
/* 170 */       float[][] y3 = y[i3];
/* 171 */       for (int i2 = 0; i2 < n2; i2++) {
/* 172 */         float[] x32 = x[i3][i2];
/* 173 */         for (int i1 = 0; i1 < n1; i1++) {
/* 174 */           y3[i1][i2] = x32[i1];
/*     */         }
/*     */       } 
/*     */     } 
/* 178 */     return y;
/*     */   }
/*     */   
/*     */   private static float[][][] transpose13(float[][][] x) {
/* 182 */     int n3 = x.length;
/* 183 */     int n2 = (x[0]).length;
/* 184 */     int n1 = (x[0][0]).length;
/* 185 */     float[][][] y = new float[n1][n2][n3];
/* 186 */     for (int i2 = 0; i2 < n2; i2++) {
/* 187 */       for (int i3 = 0; i3 < n3; i3++) {
/* 188 */         float[] x32 = x[i3][i2];
/* 189 */         for (int i1 = 0; i1 < n1; i1++) {
/* 190 */           y[i1][i2][i3] = x32[i1];
/*     */         }
/*     */       } 
/*     */     } 
/* 194 */     return y;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/Recursive2ndOrderFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */