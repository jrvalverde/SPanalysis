/*     */ package edu.mines.jtk.mosaic;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class ContoursView extends TiledView {
/*     */   private Sampling _s1;
/*     */   private Sampling _s2;
/*     */   private float[][] _f;
/*     */   private Orientation _orientation;
/*     */   private float _clipMin;
/*     */   private float _clipMax;
/*     */   private float _percMin;
/*     */   private float _percMax;
/*     */   private boolean _usePercentiles;
/*     */   private boolean _xflipped;
/*     */   private boolean _yflipped;
/*     */   private int _nx;
/*     */   private double _dx;
/*     */   private double _fx;
/*     */   private int _ny;
/*     */   private double _dy;
/*     */   private double _fy;
/*     */   private Sampling _cs;
/*     */   private ArrayList<Contour> _cl;
/*     */   private static final byte WEST = 1;
/*     */   private static final byte SOUTH = 2;
/*     */   private static final byte NOT_WEST = -2;
/*     */   private static final byte NOT_SOUTH = -3;
/*     */   
/*     */   public enum Orientation {
/*  34 */     X1RIGHT_X2UP,
/*  35 */     X1DOWN_X2RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContoursView(float[][] f)
/*     */   {
/* 291 */     this._orientation = Orientation.X1RIGHT_X2UP;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     this._percMin = 0.0F;
/* 297 */     this._percMax = 100.0F;
/* 298 */     this._usePercentiles = true; set(f); } public ContoursView(Sampling s1, Sampling s2, float[][] f) { this._orientation = Orientation.X1RIGHT_X2UP; this._percMin = 0.0F; this._percMax = 100.0F; this._usePercentiles = true; set(s1, s2, f); } public void set(float[][] f) { set(new Sampling((f[0]).length), new Sampling(f.length), f); }
/*     */   public void set(Sampling s1, Sampling s2, float[][] f) { Check.argument(s1.isUniform(), "s1 is uniform"); Check.argument(s2.isUniform(), "s2 is uniform"); Check.argument(Array.isRegular(f), "f is regular"); Check.argument((s1.getCount() == (f[0]).length), "s1 consistent with f"); Check.argument((s2.getCount() == f.length), "s2 consistent with f"); this._s1 = s1;
/*     */     this._s2 = s2;
/*     */     this._f = Array.copy(f);
/*     */     updateClips();
/*     */     updateSampling();
/*     */     updateContours(); }
/*     */   public void setOrientation(Orientation orientation) { if (this._orientation != orientation) {
/*     */       this._orientation = orientation;
/*     */       updateSampling();
/*     */       repaint();
/*     */     }  }
/*     */   public Orientation getOrientation() { return this._orientation; }
/*     */   public void setClips(float clipMin, float clipMax) { Check.argument((clipMin < clipMax), "clipMin<clipMax");
/*     */     if (this._clipMin != clipMin || this._clipMax != clipMax) {
/*     */       this._clipMin = clipMin;
/*     */       this._clipMax = clipMax;
/*     */       this._usePercentiles = false;
/*     */       repaint();
/*     */     }  }
/*     */   public float getClipMin() { return this._clipMin; }
/* 319 */   private void updateClips() { if (this._usePercentiles) {
/* 320 */       float[] a = (this._percMin != 0.0F || this._percMax != 0.0F) ? Array.flatten(this._f) : null;
/* 321 */       int n = (a != null) ? a.length : 0;
/* 322 */       int kmin = (int)MathPlus.rint(this._percMin * 0.01D * (n - 1));
/* 323 */       if (kmin <= 0) {
/* 324 */         this._clipMin = Array.min(this._f);
/*     */       } else {
/* 326 */         Array.quickPartialSort(kmin, a);
/* 327 */         this._clipMin = a[kmin];
/*     */       } 
/* 329 */       int kmax = (int)MathPlus.rint(this._percMax * 0.01D * (n - 1));
/* 330 */       if (kmax >= n - 1) {
/* 331 */         this._clipMax = Array.max(this._f);
/*     */       } else {
/* 333 */         Array.quickPartialSort(kmax, a);
/* 334 */         this._clipMax = a[kmax];
/*     */       } 
/*     */     }  } public float getClipMax() { return this._clipMax; }
/*     */   public void setPercentiles(float percMin, float percMax) { Check.argument((0.0F <= percMin), "0<=percMin");
/*     */     Check.argument((percMin < percMax), "percMin<percMax");
/*     */     Check.argument((percMax <= 100.0F), "percMax<=100");
/*     */     if (this._percMin != percMin || this._percMax != percMax) {
/*     */       this._percMin = percMin;
/*     */       this._percMax = percMax;
/*     */       this._usePercentiles = true;
/*     */       updateClips();
/*     */       repaint();
/*     */     }  }
/*     */   public float getPercentileMin() { return this._percMin; }
/* 348 */   private void updateSampling() { int n1 = this._s1.getCount();
/* 349 */     int n2 = this._s2.getCount();
/* 350 */     double d1 = this._s1.getDelta();
/* 351 */     double d2 = this._s2.getDelta();
/* 352 */     double f1 = this._s1.getFirst();
/* 353 */     double f2 = this._s2.getFirst();
/* 354 */     if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/*     */       
/* 356 */       this._xflipped = false;
/* 357 */       this._yflipped = false;
/* 358 */       this._nx = n2;
/* 359 */       this._dx = d2;
/* 360 */       this._fx = f2;
/* 361 */       this._ny = n1;
/* 362 */       this._dy = d1;
/* 363 */       this._fy = f1;
/* 364 */     } else if (this._orientation == Orientation.X1RIGHT_X2UP) {
/*     */       
/* 366 */       this._xflipped = false;
/* 367 */       this._yflipped = true;
/* 368 */       this._nx = n1;
/* 369 */       this._dx = d1;
/* 370 */       this._fx = f1;
/* 371 */       this._ny = n2;
/* 372 */       this._dy = d2;
/* 373 */       this._fy = f2;
/*     */     } 
/* 375 */     updateBestProjectors(); }
/*     */ 
/*     */   
/*     */   public float getPercentileMax() {
/*     */     return this._percMax;
/*     */   }
/*     */   
/*     */   public void paint(Graphics2D g2d) {}
/*     */   
/*     */   private void updateBestProjectors() {
/* 385 */     double x0 = this._fx;
/* 386 */     double x1 = this._fx + this._dx * (this._nx - 1);
/* 387 */     double y0 = this._fy;
/* 388 */     double y1 = this._fy + this._dy * (this._ny - 1);
/* 389 */     if (this._xflipped) {
/* 390 */       double xt = y0;
/* 391 */       x0 = x1;
/* 392 */       x1 = xt;
/*     */     } 
/* 394 */     if (this._yflipped) {
/* 395 */       double yt = y0;
/* 396 */       y0 = y1;
/* 397 */       y1 = yt;
/*     */     } 
/*     */ 
/*     */     
/* 401 */     if (x0 == x1) {
/* 402 */       double tiny = MathPlus.max(0.5D, 1.1920928955078125E-7D * MathPlus.abs(x0));
/* 403 */       x0 -= tiny;
/* 404 */       x1 += tiny;
/*     */     } 
/* 406 */     if (y0 == y1) {
/* 407 */       double tiny = MathPlus.max(0.5D, 1.1920928955078125E-7D * MathPlus.abs(y0));
/* 408 */       y0 -= tiny;
/* 409 */       y1 += tiny;
/*     */     } 
/*     */ 
/*     */     
/* 413 */     double uxMargin = (this._nx > 1) ? (0.5D / this._nx) : 0.0D;
/* 414 */     double uyMargin = (this._ny > 1) ? (0.5D / this._ny) : 0.0D;
/*     */ 
/*     */ 
/*     */     
/* 418 */     double ux0 = uxMargin;
/* 419 */     double uy0 = uyMargin;
/* 420 */     double ux1 = 1.0D - uxMargin;
/* 421 */     double uy1 = 1.0D - uyMargin;
/*     */ 
/*     */     
/* 424 */     Projector bhp = new Projector(x0, x1, ux0, ux1);
/* 425 */     Projector bvp = new Projector(y0, y1, uy0, uy1);
/* 426 */     setBestProjectors(bhp, bvp);
/*     */   }
/*     */   private static class Contour {
/*     */     float fc; int ns = 0; ArrayList<float[]> x1 = (ArrayList)new ArrayList<float>(); ArrayList<float[]> x2 = (ArrayList)new ArrayList<float>(); Contour(float fc) { this.fc = fc; } void append(ContoursView.FloatList x1List, ContoursView.FloatList x2List) { this.ns++; this.x1.add(x1List.trim()); this.x2.add(x2List.trim()); } } private static class FloatList {
/* 430 */     public int n; public float[] a = new float[64]; public void add(double f) { if (this.n == this.a.length) { float[] t = new float[2 * this.a.length]; for (int i = 0; i < this.n; i++) t[i] = this.a[i];  this.a = t; }  this.a[this.n++] = (float)f; } public float[] trim() { float[] t = new float[this.n]; for (int i = 0; i < this.n; i++) t[i] = this.a[i];  return t; } private FloatList() {} } private void updateContours() { int nc = this._cs.getCount();
/* 431 */     this._cl = new ArrayList<Contour>();
/* 432 */     for (int ic = 0; ic < nc; ic++) {
/* 433 */       float fc = (float)this._cs.getValue(ic);
/* 434 */       Contour c = makeContour(fc, this._s1, this._s2, this._f);
/* 435 */       this._cl.add(c);
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Contour makeContour(float fc, Sampling s1, Sampling s2, float[][] f) {
/* 460 */     int n1 = s1.getCount();
/* 461 */     double d1 = s1.getDelta();
/* 462 */     double f1 = s1.getFirst();
/* 463 */     int n2 = s2.getCount();
/* 464 */     double d2 = s2.getDelta();
/* 465 */     double f2 = s2.getFirst();
/* 466 */     int n1m1 = n1 - 1;
/* 467 */     int n2m1 = n2 - 1;
/*     */ 
/*     */ 
/*     */     
/* 471 */     byte[][] flags = new byte[n2][n1];
/* 472 */     int ni = 0; int i2;
/* 473 */     for (i2 = 0; i2 < n2; i2++) {
/* 474 */       for (int i = 0; i < n1; i++) {
/* 475 */         if (i2 < n2m1 && between(fc, f[i2][i], f[i2 + 1][i])) {
/* 476 */           setw(i, i2, flags);
/* 477 */           ni++;
/*     */         } 
/* 479 */         if (i < n1m1 && between(fc, f[i2][i], f[i2][i + 1])) {
/* 480 */           sets(i, i2, flags);
/* 481 */           ni++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 487 */     Contour c = new Contour(fc);
/*     */ 
/*     */     
/* 490 */     i2 = n2m1; int i1, is;
/* 491 */     for (i1 = 0, is = i1 + i2 * n1; i1 < n1m1 && ni > 0; i1++, is++) {
/* 492 */       if (sset(i1, i2, flags)) {
/* 493 */         float d = delta(fc, f[i2][i1], f[i2][i1 + 1]);
/* 494 */         FloatList x1 = new FloatList();
/* 495 */         FloatList x2 = new FloatList();
/* 496 */         x1.add(f1 + (i1 + d) * d1);
/* 497 */         x2.add(f2 + i2 * d2);
/* 498 */         clrs(i1, i2, flags); int i;
/* 499 */         for (i = is - n1; i >= 0; i = connect(i, fc, n1, d1, f1, n2, d2, f2, f, flags, x1, x2))
/* 500 */           ni--; 
/* 501 */         c.append(x1, x2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 506 */     i1 = n1m1;
/* 507 */     for (i2 = 0, is = i1 + i2 * n1; i2 < n2m1 && ni > 0; i2++, is += n1) {
/* 508 */       if (wset(i1, i2, flags)) {
/* 509 */         float d = delta(fc, f[i2][i1], f[i2 + 1][i1]);
/* 510 */         FloatList x1 = new FloatList();
/* 511 */         FloatList x2 = new FloatList();
/* 512 */         x1.add(f1 + i1 * d1);
/* 513 */         x2.add(f2 + (i2 + d) * d2);
/* 514 */         clrw(i1, i2, flags); int i;
/* 515 */         for (i = is - 1; i >= 0; i = connect(i, fc, n1, d1, f1, n2, d2, f2, f, flags, x1, x2))
/* 516 */           ni--; 
/* 517 */         c.append(x1, x2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 522 */     i2 = 0;
/* 523 */     for (i1 = 0, is = i1 + i2 * n1; i1 < n1m1 && ni > 0; i1++, is++) {
/* 524 */       if (sset(i1, i2, flags)) {
/* 525 */         float d = delta(fc, f[i2][i1], f[i2][i1 + 1]);
/* 526 */         FloatList x1 = new FloatList();
/* 527 */         FloatList x2 = new FloatList();
/* 528 */         x1.add(f1 + (i1 + d) * d1);
/* 529 */         x2.add(f2 + i2 * d2);
/* 530 */         clrs(i1, i2, flags); int i;
/* 531 */         for (i = is; i >= 0; i = connect(i, fc, n1, d1, f1, n2, d2, f2, f, flags, x1, x2))
/* 532 */           ni--; 
/* 533 */         c.append(x1, x2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 538 */     i1 = 0;
/* 539 */     for (i2 = 0, is = i1 + i2 * n1; i2 < n2m1 && ni > 0; i2++, is += n1) {
/* 540 */       if (wset(i1, i2, flags)) {
/* 541 */         float d = delta(fc, f[i2][i1], f[i2 + 1][i1]);
/* 542 */         FloatList x1 = new FloatList();
/* 543 */         FloatList x2 = new FloatList();
/* 544 */         x1.add(f1 + i1 * d1);
/* 545 */         x2.add(f2 + (i2 + d) * d2);
/* 546 */         clrw(i1, i2, flags); int i;
/* 547 */         for (i = is; i >= 0; i = connect(i, fc, n1, d1, f1, n2, d2, f2, f, flags, x1, x2))
/* 548 */           ni--; 
/* 549 */         c.append(x1, x2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 554 */     for (i2 = 1; i2 < n2m1 && ni > 0; i2++) {
/* 555 */       for (i1 = 0, is = i1 + i2 * n1; i1 < n1m1 && ni > 0; i1++, is++) {
/* 556 */         if (sset(i1, i2, flags)) {
/* 557 */           float d = delta(fc, f[i2][i1], f[i2][i1 + 1]);
/* 558 */           FloatList x1 = new FloatList();
/* 559 */           FloatList x2 = new FloatList();
/* 560 */           x1.add(f1 + (i1 + d) * d1);
/* 561 */           x2.add(f2 + i2 * d2);
/* 562 */           clrs(i1, i2, flags); int i;
/* 563 */           for (i = is; i >= 0; i = connect(i, fc, n1, d1, f1, n2, d2, f2, f, flags, x1, x2))
/* 564 */             ni--; 
/* 565 */           c.append(x1, x2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 570 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int connect(int index, float fc, int n1, double d1, double f1, int n2, double d2, double f2, float[][] f, byte[][] flags, FloatList x1, FloatList x2) {
/* 588 */     int i1 = index % n1;
/* 589 */     int i2 = index / n1;
/*     */ 
/*     */     
/* 592 */     if (sset(i1, i2 + 1, flags)) {
/* 593 */       float d = delta(fc, f[i2][i1], f[i2][i1 + 1]);
/* 594 */       x1.add(f1 + (i1 + d) * d1);
/* 595 */       x2.add(f2 + (i2 + 1) * d2);
/* 596 */       clrs(i1, ++i2, flags);
/* 597 */       return (i2 < n2 - 1) ? (index + n1) : -1;
/*     */     } 
/*     */ 
/*     */     
/* 601 */     if (wset(i1 + 1, i2, flags)) {
/* 602 */       float d = delta(fc, f[i2][i1], f[i2 + 1][i1]);
/* 603 */       x1.add(f1 + (i1 + 1) * d1);
/* 604 */       x2.add(f2 + (i2 + d) * d2);
/* 605 */       clrw(++i1, i2, flags);
/* 606 */       return (i1 < n1 - 1) ? (index + 1) : -1;
/*     */     } 
/*     */ 
/*     */     
/* 610 */     if (sset(i1, i2, flags)) {
/* 611 */       float d = delta(fc, f[i2][i1], f[i2][i1 + 1]);
/* 612 */       x1.add(f1 + (i1 + d) * d1);
/* 613 */       x2.add(f2 + i2 * d2);
/* 614 */       clrs(i1, i2, flags);
/* 615 */       return (i2 > 0) ? (index - n1) : -1;
/*     */     } 
/*     */ 
/*     */     
/* 619 */     if (wset(i1, i2, flags)) {
/* 620 */       float d = delta(fc, f[i2][i1], f[i2 + 1][i1]);
/* 621 */       x1.add(f1 + i1 * d1);
/* 622 */       x2.add(f2 + (i2 + d) * d2);
/* 623 */       clrw(i1, i2, flags);
/* 624 */       return (i1 > 0) ? (index - 1) : -1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 629 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void sets(int i1, int i2, byte[][] flags) {
/* 639 */     flags[i2][i1] = (byte)(flags[i2][i1] | 0x2);
/*     */   }
/*     */   
/*     */   private static void setw(int i1, int i2, byte[][] flags) {
/* 643 */     flags[i2][i1] = (byte)(flags[i2][i1] | 0x1);
/*     */   }
/*     */   
/*     */   private static void clrs(int i1, int i2, byte[][] flags) {
/* 647 */     flags[i2][i1] = (byte)(flags[i2][i1] & 0xFFFFFFFD);
/*     */   }
/*     */   
/*     */   private static void clrw(int i1, int i2, byte[][] flags) {
/* 651 */     flags[i2][i1] = (byte)(flags[i2][i1] & 0xFFFFFFFE);
/*     */   }
/*     */   
/*     */   private static boolean sset(int i1, int i2, byte[][] flags) {
/* 655 */     return ((flags[i2][i1] & 0x2) != 0);
/*     */   }
/*     */   
/*     */   private static boolean wset(int i1, int i2, byte[][] flags) {
/* 659 */     return ((flags[i2][i1] & 0x1) != 0);
/*     */   }
/*     */   
/*     */   private static boolean between(float fc, float f1, float f2) {
/* 663 */     return (f1 <= f2) ? ((f1 <= fc && fc < f2)) : ((f2 <= fc && fc < f1));
/*     */   }
/*     */   
/*     */   private static float delta(float fc, float f1, float f2) {
/* 667 */     return (f1 != f2) ? ((fc - f1) / (f2 - f1)) : 1.0F;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/ContoursView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */