/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class World
/*     */   extends Group
/*     */ {
/*     */   public int countViews() {
/*  33 */     return this._viewList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<View> getViews() {
/*  41 */     return this._viewList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countSelected() {
/*  49 */     return this._selectedSet.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Node> getSelected() {
/*  57 */     return this._selectedSet.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSelected() {
/*  64 */     for (Node node : new ArrayList(this._selectedSet)) {
/*  65 */       if (node.isSelected()) {
/*  66 */         node.setSelected(false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSelectedExcept(Selectable nodeToIgnore) {
/*  78 */     for (Node node : new ArrayList(this._selectedSet)) {
/*  79 */       if (node != nodeToIgnore && node.isSelected()) {
/*  80 */         node.setSelected(false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dirtyDraw() {
/*  89 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dirtyBoundingSphere() {
/*  96 */     super.dirtyBoundingSphere();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void repaint() {
/* 103 */     for (View view : this._viewList) {
/* 104 */       view.repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public World getWorld() {
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateSelectedSet(Node node) {
/* 131 */     if (node instanceof Selectable) {
/* 132 */       if (node.isSelected() && this == node.getWorld()) {
/* 133 */         this._selectedSet.add(node);
/*     */       } else {
/* 135 */         this._selectedSet.remove(node);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 141 */     if (node instanceof Group) {
/* 142 */       Group group = (Group)node;
/* 143 */       Iterator<Node> children = group.getChildren();
/* 144 */       while (children.hasNext()) {
/* 145 */         Node child = children.next();
/* 146 */         updateSelectedSet(child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean addView(View view) {
/* 155 */     if (!this._viewList.contains(view)) {
/* 156 */       this._viewList.add(view);
/* 157 */       return true;
/*     */     } 
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean removeView(View view) {
/* 167 */     return this._viewList.remove(view);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private ArrayList<View> _viewList = new ArrayList<View>();
/* 174 */   private HashSet<Node> _selectedSet = new HashSet<Node>();
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/World.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */