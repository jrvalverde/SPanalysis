/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class Pfacc
/*      */ {
/*      */   private static final float P120 = 0.12053668F;
/*      */   private static final float P142 = 0.14231484F;
/*      */   private static final float P173 = 0.17364818F;
/*      */   private static final float P222 = 0.22252093F;
/*      */   private static final float P239 = 0.23931566F;
/*      */   private static final float P281 = 0.28173256F;
/*      */   private static final float P342 = 0.34202015F;
/*      */   private static final float P354 = 0.3546049F;
/*      */   private static final float P382 = 0.38268343F;
/*      */   private static final float P415 = 0.41541502F;
/*      */   private static final float P433 = 0.43388373F;
/*      */   private static final float P464 = 0.46472317F;
/*      */   private static final float P540 = 0.54064083F;
/*      */   private static final float P559 = 0.559017F;
/*      */   private static final float P568 = 0.56806475F;
/*      */   private static final float P587 = 0.58778524F;
/*      */   private static final float P623 = 0.6234898F;
/*      */   private static final float P642 = 0.64278764F;
/*      */   private static final float P654 = 0.65486073F;
/*      */   private static final float P663 = 0.66312265F;
/*      */   private static final float P707 = 0.70710677F;
/*      */   
/*      */   static boolean nfftValid(int nfft) {
/*   37 */     return (Array.binarySearch(_ntable, nfft) >= 0);
/*      */   }
/*      */   private static final float P748 = 0.7485107F; private static final float P755 = 0.7557496F; private static final float P766 = 0.76604444F;
/*      */   private static final float P781 = 0.7818315F;
/*      */   private static final float P822 = 0.82298386F;
/*      */   private static final float P841 = 0.8412535F;
/*      */   private static final float P866 = 0.8660254F;
/*      */   private static final float P885 = 0.885456F;
/*      */   private static final float P900 = 0.90096885F;
/*      */   private static final float P909 = 0.90963197F;
/*      */   private static final float P923 = 0.9238795F;
/*      */   
/*      */   static int nfftSmall(int n) {
/*   50 */     Check.argument((n <= 720720), "n does not exceed 720720");
/*   51 */     int itable = Array.binarySearch(_ntable, n);
/*   52 */     if (itable < 0) itable = -(itable + 1); 
/*   53 */     return _ntable[itable];
/*      */   }
/*      */   private static final float P935 = 0.9350162F; private static final float P939 = 0.9396926F; private static final float P951 = 0.95105654F;
/*      */   private static final float P959 = 0.959493F;
/*      */   private static final float P970 = 0.97094184F;
/*      */   private static final float P974 = 0.9749279F;
/*      */   private static final float P984 = 0.9848077F;
/*      */   private static final float P989 = 0.98982143F;
/*      */   private static final float P992 = 0.99270886F;
/*      */   private static final float PONE = 1.0F;
/*      */   private static final int NFAC = 10;
/*      */   
/*      */   static int nfftFast(int n) {
/*   66 */     Check.argument((n <= 720720), "n does not exceed 720720");
/*   67 */     int ifast = Array.binarySearch(_ntable, n);
/*   68 */     if (ifast < 0) ifast = -(ifast + 1); 
/*   69 */     int nfast = _ntable[ifast];
/*   70 */     int nstop = 2 * nfast;
/*   71 */     double cfast = _ctable[ifast];
/*   72 */     for (int i = ifast + 1; i < 240 && _ntable[i] < nstop; i++) {
/*   73 */       if (_ctable[i] < cfast) {
/*   74 */         cfast = _ctable[i];
/*   75 */         nfast = _ntable[i];
/*      */       } 
/*      */     } 
/*   78 */     return nfast;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void transform(int sign, int nfft, float[] z)
/*      */   {
/*   90 */     int nleft = nfft;
/*      */ 
/*      */     
/*   93 */     for (int jfac = 0; jfac < 10; jfac++) {
/*      */ 
/*      */       
/*   96 */       int ifac = _kfac[jfac];
/*   97 */       int ndiv = nleft / ifac;
/*   98 */       if (ndiv * ifac == nleft) {
/*      */ 
/*      */ 
/*      */         
/*  102 */         nleft = ndiv;
/*  103 */         int m = nfft / ifac;
/*      */ 
/*      */         
/*  106 */         int mu = 0;
/*  107 */         int mm = 0;
/*  108 */         for (int kfac = 1; kfac <= ifac && mm % ifac != 1; kfac++) {
/*  109 */           mu = kfac;
/*  110 */           mm = kfac * m;
/*      */         } 
/*  112 */         if (sign < 0) {
/*  113 */           mu = ifac - mu;
/*      */         }
/*      */         
/*  116 */         int jinc = 2 * mm;
/*  117 */         int jmax = 2 * nfft;
/*  118 */         int j0 = 0;
/*  119 */         int j1 = j0 + jinc;
/*      */ 
/*      */         
/*  122 */         if (ifac == 2) {
/*  123 */           pfa2(z, mu, m, j0, j1);
/*      */         } else {
/*      */           
/*  126 */           int j2 = (j1 + jinc) % jmax;
/*      */ 
/*      */           
/*  129 */           if (ifac == 3) {
/*  130 */             pfa3(z, mu, m, j0, j1, j2);
/*      */           } else {
/*      */             
/*  133 */             int j3 = (j2 + jinc) % jmax;
/*      */ 
/*      */             
/*  136 */             if (ifac == 4) {
/*  137 */               pfa4(z, mu, m, j0, j1, j2, j3);
/*      */             } else {
/*      */               
/*  140 */               int j4 = (j3 + jinc) % jmax;
/*      */ 
/*      */               
/*  143 */               if (ifac == 5) {
/*  144 */                 pfa5(z, mu, m, j0, j1, j2, j3, j4);
/*      */               } else {
/*      */                 
/*  147 */                 int j5 = (j4 + jinc) % jmax;
/*  148 */                 int j6 = (j5 + jinc) % jmax;
/*      */ 
/*      */                 
/*  151 */                 if (ifac == 7) {
/*  152 */                   pfa7(z, mu, m, j0, j1, j2, j3, j4, j5, j6);
/*      */                 } else {
/*      */                   
/*  155 */                   int j7 = (j6 + jinc) % jmax;
/*      */ 
/*      */                   
/*  158 */                   if (ifac == 8) {
/*  159 */                     pfa8(z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7);
/*      */                   } else {
/*      */                     
/*  162 */                     int j8 = (j7 + jinc) % jmax;
/*      */ 
/*      */                     
/*  165 */                     if (ifac == 9)
/*  166 */                     { pfa9(z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8); }
/*      */                     else
/*      */                     
/*  169 */                     { int j9 = (j8 + jinc) % jmax;
/*  170 */                       int j10 = (j9 + jinc) % jmax;
/*      */ 
/*      */                       
/*  173 */                       if (ifac == 11)
/*  174 */                       { pfa11(z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10); }
/*      */                       else
/*      */                       
/*  177 */                       { int j11 = (j10 + jinc) % jmax;
/*  178 */                         int j12 = (j11 + jinc) % jmax;
/*      */ 
/*      */                         
/*  181 */                         if (ifac == 13)
/*  182 */                         { pfa13(z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12); }
/*      */                         else
/*      */                         
/*  185 */                         { int j13 = (j12 + jinc) % jmax;
/*  186 */                           int j14 = (j13 + jinc) % jmax;
/*  187 */                           int j15 = (j14 + jinc) % jmax;
/*      */ 
/*      */                           
/*  190 */                           if (ifac == 16)
/*  191 */                             pfa16(z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12, j13, j14, j15);  }  }  } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  199 */     }  } private static void pfa2(float[] z, int mu, int m, int j0, int j1) { for (int i = 0; i < m; i++) {
/*  200 */       float t1r = z[j0] - z[j1];
/*  201 */       float t1i = z[j0 + 1] - z[j1 + 1];
/*  202 */       z[j0] = z[j0] + z[j1];
/*  203 */       z[j0 + 1] = z[j0 + 1] + z[j1 + 1];
/*  204 */       z[j1] = t1r;
/*  205 */       z[j1 + 1] = t1i;
/*  206 */       int jt = j1 + 2;
/*  207 */       j1 = j0 + 2;
/*  208 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa3(float[] z, int mu, int m, int j0, int j1, int j2) {
/*      */     float c1;
/*  215 */     if (mu == 1) {
/*  216 */       c1 = 0.8660254F;
/*      */     } else {
/*  218 */       c1 = -0.8660254F;
/*      */     } 
/*  220 */     for (int i = 0; i < m; i++) {
/*  221 */       float t1r = z[j1] + z[j2];
/*  222 */       float t1i = z[j1 + 1] + z[j2 + 1];
/*  223 */       float y1r = z[j0] - 0.5F * t1r;
/*  224 */       float y1i = z[j0 + 1] - 0.5F * t1i;
/*  225 */       float y2r = c1 * (z[j1] - z[j2]);
/*  226 */       float y2i = c1 * (z[j1 + 1] - z[j2 + 1]);
/*  227 */       z[j0] = z[j0] + t1r;
/*  228 */       z[j0 + 1] = z[j0 + 1] + t1i;
/*  229 */       z[j1] = y1r - y2i;
/*  230 */       z[j1 + 1] = y1i + y2r;
/*  231 */       z[j2] = y1r + y2i;
/*  232 */       z[j2 + 1] = y1i - y2r;
/*  233 */       int jt = j2 + 2;
/*  234 */       j2 = j1 + 2;
/*  235 */       j1 = j0 + 2;
/*  236 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void pfa4(float[] z, int mu, int m, int j0, int j1, int j2, int j3) {
/*      */     float c1;
/*  243 */     if (mu == 1) {
/*  244 */       c1 = 1.0F;
/*      */     } else {
/*  246 */       c1 = -1.0F;
/*      */     } 
/*  248 */     for (int i = 0; i < m; i++) {
/*  249 */       float t1r = z[j0] + z[j2];
/*  250 */       float t1i = z[j0 + 1] + z[j2 + 1];
/*  251 */       float t2r = z[j1] + z[j3];
/*  252 */       float t2i = z[j1 + 1] + z[j3 + 1];
/*  253 */       float y1r = z[j0] - z[j2];
/*  254 */       float y1i = z[j0 + 1] - z[j2 + 1];
/*  255 */       float y3r = c1 * (z[j1] - z[j3]);
/*  256 */       float y3i = c1 * (z[j1 + 1] - z[j3 + 1]);
/*  257 */       z[j0] = t1r + t2r;
/*  258 */       z[j0 + 1] = t1i + t2i;
/*  259 */       z[j1] = y1r - y3i;
/*  260 */       z[j1 + 1] = y1i + y3r;
/*  261 */       z[j2] = t1r - t2r;
/*  262 */       z[j2 + 1] = t1i - t2i;
/*  263 */       z[j3] = y1r + y3i;
/*  264 */       z[j3 + 1] = y1i - y3r;
/*  265 */       int jt = j3 + 2;
/*  266 */       j3 = j2 + 2;
/*  267 */       j2 = j1 + 2;
/*  268 */       j1 = j0 + 2;
/*  269 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa5(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4) { float c1;
/*      */     float c2;
/*      */     float c3;
/*  276 */     if (mu == 1) {
/*  277 */       c1 = 0.559017F;
/*  278 */       c2 = 0.95105654F;
/*  279 */       c3 = 0.58778524F;
/*  280 */     } else if (mu == 2) {
/*  281 */       c1 = -0.559017F;
/*  282 */       c2 = 0.58778524F;
/*  283 */       c3 = -0.95105654F;
/*  284 */     } else if (mu == 3) {
/*  285 */       c1 = -0.559017F;
/*  286 */       c2 = -0.58778524F;
/*  287 */       c3 = 0.95105654F;
/*      */     } else {
/*  289 */       c1 = 0.559017F;
/*  290 */       c2 = -0.95105654F;
/*  291 */       c3 = -0.58778524F;
/*      */     } 
/*  293 */     for (int i = 0; i < m; i++) {
/*  294 */       float t1r = z[j1] + z[j4];
/*  295 */       float t1i = z[j1 + 1] + z[j4 + 1];
/*  296 */       float t2r = z[j2] + z[j3];
/*  297 */       float t2i = z[j2 + 1] + z[j3 + 1];
/*  298 */       float t3r = z[j1] - z[j4];
/*  299 */       float t3i = z[j1 + 1] - z[j4 + 1];
/*  300 */       float t4r = z[j2] - z[j3];
/*  301 */       float t4i = z[j2 + 1] - z[j3 + 1];
/*  302 */       float t5r = t1r + t2r;
/*  303 */       float t5i = t1i + t2i;
/*  304 */       float t6r = c1 * (t1r - t2r);
/*  305 */       float t6i = c1 * (t1i - t2i);
/*  306 */       float t7r = z[j0] - 0.25F * t5r;
/*  307 */       float t7i = z[j0 + 1] - 0.25F * t5i;
/*  308 */       float y1r = t7r + t6r;
/*  309 */       float y1i = t7i + t6i;
/*  310 */       float y2r = t7r - t6r;
/*  311 */       float y2i = t7i - t6i;
/*  312 */       float y3r = c3 * t3r - c2 * t4r;
/*  313 */       float y3i = c3 * t3i - c2 * t4i;
/*  314 */       float y4r = c2 * t3r + c3 * t4r;
/*  315 */       float y4i = c2 * t3i + c3 * t4i;
/*  316 */       z[j0] = z[j0] + t5r;
/*  317 */       z[j0 + 1] = z[j0 + 1] + t5i;
/*  318 */       z[j1] = y1r - y4i;
/*  319 */       z[j1 + 1] = y1i + y4r;
/*  320 */       z[j2] = y2r - y3i;
/*  321 */       z[j2 + 1] = y2i + y3r;
/*  322 */       z[j3] = y2r + y3i;
/*  323 */       z[j3 + 1] = y2i - y3r;
/*  324 */       z[j4] = y1r + y4i;
/*  325 */       z[j4 + 1] = y1i - y4r;
/*  326 */       int jt = j4 + 2;
/*  327 */       j4 = j3 + 2;
/*  328 */       j3 = j2 + 2;
/*  329 */       j2 = j1 + 2;
/*  330 */       j1 = j0 + 2;
/*  331 */       j0 = jt;
/*      */     }  } private static void pfa7(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6) { float c1;
/*      */     float c2;
/*      */     float c3;
/*      */     float c4;
/*      */     float c5;
/*      */     float c6;
/*  338 */     if (mu == 1) {
/*  339 */       c1 = 0.6234898F;
/*  340 */       c2 = -0.22252093F;
/*  341 */       c3 = -0.90096885F;
/*  342 */       c4 = 0.7818315F;
/*  343 */       c5 = 0.9749279F;
/*  344 */       c6 = 0.43388373F;
/*  345 */     } else if (mu == 2) {
/*  346 */       c1 = -0.22252093F;
/*  347 */       c2 = -0.90096885F;
/*  348 */       c3 = 0.6234898F;
/*  349 */       c4 = 0.9749279F;
/*  350 */       c5 = -0.43388373F;
/*  351 */       c6 = -0.7818315F;
/*  352 */     } else if (mu == 3) {
/*  353 */       c1 = -0.90096885F;
/*  354 */       c2 = 0.6234898F;
/*  355 */       c3 = -0.22252093F;
/*  356 */       c4 = 0.43388373F;
/*  357 */       c5 = -0.7818315F;
/*  358 */       c6 = 0.9749279F;
/*  359 */     } else if (mu == 4) {
/*  360 */       c1 = -0.90096885F;
/*  361 */       c2 = 0.6234898F;
/*  362 */       c3 = -0.22252093F;
/*  363 */       c4 = -0.43388373F;
/*  364 */       c5 = 0.7818315F;
/*  365 */       c6 = -0.9749279F;
/*  366 */     } else if (mu == 5) {
/*  367 */       c1 = -0.22252093F;
/*  368 */       c2 = -0.90096885F;
/*  369 */       c3 = 0.6234898F;
/*  370 */       c4 = -0.9749279F;
/*  371 */       c5 = 0.43388373F;
/*  372 */       c6 = 0.7818315F;
/*      */     } else {
/*  374 */       c1 = 0.6234898F;
/*  375 */       c2 = -0.22252093F;
/*  376 */       c3 = -0.90096885F;
/*  377 */       c4 = -0.7818315F;
/*  378 */       c5 = -0.9749279F;
/*  379 */       c6 = -0.43388373F;
/*      */     } 
/*  381 */     for (int i = 0; i < m; i++) {
/*  382 */       float t1r = z[j1] + z[j6];
/*  383 */       float t1i = z[j1 + 1] + z[j6 + 1];
/*  384 */       float t2r = z[j2] + z[j5];
/*  385 */       float t2i = z[j2 + 1] + z[j5 + 1];
/*  386 */       float t3r = z[j3] + z[j4];
/*  387 */       float t3i = z[j3 + 1] + z[j4 + 1];
/*  388 */       float t4r = z[j1] - z[j6];
/*  389 */       float t4i = z[j1 + 1] - z[j6 + 1];
/*  390 */       float t5r = z[j2] - z[j5];
/*  391 */       float t5i = z[j2 + 1] - z[j5 + 1];
/*  392 */       float t6r = z[j3] - z[j4];
/*  393 */       float t6i = z[j3 + 1] - z[j4 + 1];
/*  394 */       float t7r = z[j0] - 0.5F * t3r;
/*  395 */       float t7i = z[j0 + 1] - 0.5F * t3i;
/*  396 */       float t8r = t1r - t3r;
/*  397 */       float t8i = t1i - t3i;
/*  398 */       float t9r = t2r - t3r;
/*  399 */       float t9i = t2i - t3i;
/*  400 */       float y1r = t7r + c1 * t8r + c2 * t9r;
/*  401 */       float y1i = t7i + c1 * t8i + c2 * t9i;
/*  402 */       float y2r = t7r + c2 * t8r + c3 * t9r;
/*  403 */       float y2i = t7i + c2 * t8i + c3 * t9i;
/*  404 */       float y3r = t7r + c3 * t8r + c1 * t9r;
/*  405 */       float y3i = t7i + c3 * t8i + c1 * t9i;
/*  406 */       float y4r = c6 * t4r - c4 * t5r + c5 * t6r;
/*  407 */       float y4i = c6 * t4i - c4 * t5i + c5 * t6i;
/*  408 */       float y5r = c5 * t4r - c6 * t5r - c4 * t6r;
/*  409 */       float y5i = c5 * t4i - c6 * t5i - c4 * t6i;
/*  410 */       float y6r = c4 * t4r + c5 * t5r + c6 * t6r;
/*  411 */       float y6i = c4 * t4i + c5 * t5i + c6 * t6i;
/*  412 */       z[j0] = z[j0] + t1r + t2r + t3r;
/*  413 */       z[j0 + 1] = z[j0 + 1] + t1i + t2i + t3i;
/*  414 */       z[j1] = y1r - y6i;
/*  415 */       z[j1 + 1] = y1i + y6r;
/*  416 */       z[j2] = y2r - y5i;
/*  417 */       z[j2 + 1] = y2i + y5r;
/*  418 */       z[j3] = y3r - y4i;
/*  419 */       z[j3 + 1] = y3i + y4r;
/*  420 */       z[j4] = y3r + y4i;
/*  421 */       z[j4 + 1] = y3i - y4r;
/*  422 */       z[j5] = y2r + y5i;
/*  423 */       z[j5 + 1] = y2i - y5r;
/*  424 */       z[j6] = y1r + y6i;
/*  425 */       z[j6 + 1] = y1i - y6r;
/*  426 */       int jt = j6 + 2;
/*  427 */       j6 = j5 + 2;
/*  428 */       j5 = j4 + 2;
/*  429 */       j4 = j3 + 2;
/*  430 */       j3 = j2 + 2;
/*  431 */       j2 = j1 + 2;
/*  432 */       j1 = j0 + 2;
/*  433 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa8(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7) {
/*      */     float c1, c2;
/*  440 */     if (mu == 1) {
/*  441 */       c1 = 1.0F;
/*  442 */       c2 = 0.70710677F;
/*  443 */     } else if (mu == 3) {
/*  444 */       c1 = -1.0F;
/*  445 */       c2 = -0.70710677F;
/*  446 */     } else if (mu == 5) {
/*  447 */       c1 = 1.0F;
/*  448 */       c2 = -0.70710677F;
/*      */     } else {
/*  450 */       c1 = -1.0F;
/*  451 */       c2 = 0.70710677F;
/*      */     } 
/*  453 */     float c3 = c1 * c2;
/*  454 */     for (int i = 0; i < m; i++) {
/*  455 */       float t1r = z[j0] + z[j4];
/*  456 */       float t1i = z[j0 + 1] + z[j4 + 1];
/*  457 */       float t2r = z[j0] - z[j4];
/*  458 */       float t2i = z[j0 + 1] - z[j4 + 1];
/*  459 */       float t3r = z[j1] + z[j5];
/*  460 */       float t3i = z[j1 + 1] + z[j5 + 1];
/*  461 */       float t4r = z[j1] - z[j5];
/*  462 */       float t4i = z[j1 + 1] - z[j5 + 1];
/*  463 */       float t5r = z[j2] + z[j6];
/*  464 */       float t5i = z[j2 + 1] + z[j6 + 1];
/*  465 */       float t6r = c1 * (z[j2] - z[j6]);
/*  466 */       float t6i = c1 * (z[j2 + 1] - z[j6 + 1]);
/*  467 */       float t7r = z[j3] + z[j7];
/*  468 */       float t7i = z[j3 + 1] + z[j7 + 1];
/*  469 */       float t8r = z[j3] - z[j7];
/*  470 */       float t8i = z[j3 + 1] - z[j7 + 1];
/*  471 */       float t9r = t1r + t5r;
/*  472 */       float t9i = t1i + t5i;
/*  473 */       float t10r = t3r + t7r;
/*  474 */       float t10i = t3i + t7i;
/*  475 */       float t11r = c2 * (t4r - t8r);
/*  476 */       float t11i = c2 * (t4i - t8i);
/*  477 */       float t12r = c3 * (t4r + t8r);
/*  478 */       float t12i = c3 * (t4i + t8i);
/*  479 */       float y1r = t2r + t11r;
/*  480 */       float y1i = t2i + t11i;
/*  481 */       float y2r = t1r - t5r;
/*  482 */       float y2i = t1i - t5i;
/*  483 */       float y3r = t2r - t11r;
/*  484 */       float y3i = t2i - t11i;
/*  485 */       float y5r = t12r - t6r;
/*  486 */       float y5i = t12i - t6i;
/*  487 */       float y6r = c1 * (t3r - t7r);
/*  488 */       float y6i = c1 * (t3i - t7i);
/*  489 */       float y7r = t12r + t6r;
/*  490 */       float y7i = t12i + t6i;
/*  491 */       z[j0] = t9r + t10r;
/*  492 */       z[j0 + 1] = t9i + t10i;
/*  493 */       z[j1] = y1r - y7i;
/*  494 */       z[j1 + 1] = y1i + y7r;
/*  495 */       z[j2] = y2r - y6i;
/*  496 */       z[j2 + 1] = y2i + y6r;
/*  497 */       z[j3] = y3r - y5i;
/*  498 */       z[j3 + 1] = y3i + y5r;
/*  499 */       z[j4] = t9r - t10r;
/*  500 */       z[j4 + 1] = t9i - t10i;
/*  501 */       z[j5] = y3r + y5i;
/*  502 */       z[j5 + 1] = y3i - y5r;
/*  503 */       z[j6] = y2r + y6i;
/*  504 */       z[j6 + 1] = y2i - y6r;
/*  505 */       z[j7] = y1r + y7i;
/*  506 */       z[j7 + 1] = y1i - y7r;
/*  507 */       int jt = j7 + 2;
/*  508 */       j7 = j6 + 2;
/*  509 */       j6 = j5 + 2;
/*  510 */       j5 = j4 + 2;
/*  511 */       j4 = j3 + 2;
/*  512 */       j3 = j2 + 2;
/*  513 */       j2 = j1 + 2;
/*  514 */       j1 = j0 + 2;
/*  515 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa9(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8)
/*      */   {
/*      */     float c1, c2, c3, c4, c5;
/*  522 */     if (mu == 1) {
/*  523 */       c1 = 0.8660254F;
/*  524 */       c2 = 0.76604444F;
/*  525 */       c3 = 0.64278764F;
/*  526 */       c4 = 0.17364818F;
/*  527 */       c5 = 0.9848077F;
/*  528 */     } else if (mu == 2) {
/*  529 */       c1 = -0.8660254F;
/*  530 */       c2 = 0.17364818F;
/*  531 */       c3 = 0.9848077F;
/*  532 */       c4 = -0.9396926F;
/*  533 */       c5 = 0.34202015F;
/*  534 */     } else if (mu == 4) {
/*  535 */       c1 = 0.8660254F;
/*  536 */       c2 = -0.9396926F;
/*  537 */       c3 = 0.34202015F;
/*  538 */       c4 = 0.76604444F;
/*  539 */       c5 = -0.64278764F;
/*  540 */     } else if (mu == 5) {
/*  541 */       c1 = -0.8660254F;
/*  542 */       c2 = -0.9396926F;
/*  543 */       c3 = -0.34202015F;
/*  544 */       c4 = 0.76604444F;
/*  545 */       c5 = 0.64278764F;
/*  546 */     } else if (mu == 7) {
/*  547 */       c1 = 0.8660254F;
/*  548 */       c2 = 0.17364818F;
/*  549 */       c3 = -0.9848077F;
/*  550 */       c4 = -0.9396926F;
/*  551 */       c5 = -0.34202015F;
/*      */     } else {
/*  553 */       c1 = -0.8660254F;
/*  554 */       c2 = 0.76604444F;
/*  555 */       c3 = -0.64278764F;
/*  556 */       c4 = 0.17364818F;
/*  557 */       c5 = -0.9848077F;
/*      */     } 
/*  559 */     float c6 = c1 * c2;
/*  560 */     float c7 = c1 * c3;
/*  561 */     float c8 = c1 * c4;
/*  562 */     float c9 = c1 * c5;
/*  563 */     for (int i = 0; i < m; i++) {
/*  564 */       float t1r = z[j3] + z[j6];
/*  565 */       float t1i = z[j3 + 1] + z[j6 + 1];
/*  566 */       float t2r = z[j0] - 0.5F * t1r;
/*  567 */       float t2i = z[j0 + 1] - 0.5F * t1i;
/*  568 */       float t3r = c1 * (z[j3] - z[j6]);
/*  569 */       float t3i = c1 * (z[j3 + 1] - z[j6 + 1]);
/*  570 */       float t4r = z[j0] + t1r;
/*  571 */       float t4i = z[j0 + 1] + t1i;
/*  572 */       float t5r = z[j4] + z[j7];
/*  573 */       float t5i = z[j4 + 1] + z[j7 + 1];
/*  574 */       float t6r = z[j1] - 0.5F * t5r;
/*  575 */       float t6i = z[j1 + 1] - 0.5F * t5i;
/*  576 */       float t7r = z[j4] - z[j7];
/*  577 */       float t7i = z[j4 + 1] - z[j7 + 1];
/*  578 */       float t8r = z[j1] + t5r;
/*  579 */       float t8i = z[j1 + 1] + t5i;
/*  580 */       float t9r = z[j2] + z[j5];
/*  581 */       float t9i = z[j2 + 1] + z[j5 + 1];
/*  582 */       float t10r = z[j8] - 0.5F * t9r;
/*  583 */       float t10i = z[j8 + 1] - 0.5F * t9i;
/*  584 */       float t11r = z[j2] - z[j5];
/*  585 */       float t11i = z[j2 + 1] - z[j5 + 1];
/*  586 */       float t12r = z[j8] + t9r;
/*  587 */       float t12i = z[j8 + 1] + t9i;
/*  588 */       float t13r = t8r + t12r;
/*  589 */       float t13i = t8i + t12i;
/*  590 */       float t14r = t6r + t10r;
/*  591 */       float t14i = t6i + t10i;
/*  592 */       float t15r = t6r - t10r;
/*  593 */       float t15i = t6i - t10i;
/*  594 */       float t16r = t7r + t11r;
/*  595 */       float t16i = t7i + t11i;
/*  596 */       float t17r = t7r - t11r;
/*  597 */       float t17i = t7i - t11i;
/*  598 */       float t18r = c2 * t14r - c7 * t17r;
/*  599 */       float t18i = c2 * t14i - c7 * t17i;
/*  600 */       float t19r = c4 * t14r + c9 * t17r;
/*  601 */       float t19i = c4 * t14i + c9 * t17i;
/*  602 */       float t20r = c3 * t15r + c6 * t16r;
/*  603 */       float t20i = c3 * t15i + c6 * t16i;
/*  604 */       float t21r = c5 * t15r - c8 * t16r;
/*  605 */       float t21i = c5 * t15i - c8 * t16i;
/*  606 */       float t22r = t18r + t19r;
/*  607 */       float t22i = t18i + t19i;
/*  608 */       float t23r = t20r - t21r;
/*  609 */       float t23i = t20i - t21i;
/*  610 */       float y1r = t2r + t18r;
/*  611 */       float y1i = t2i + t18i;
/*  612 */       float y2r = t2r + t19r;
/*  613 */       float y2i = t2i + t19i;
/*  614 */       float y3r = t4r - 0.5F * t13r;
/*  615 */       float y3i = t4i - 0.5F * t13i;
/*  616 */       float y4r = t2r - t22r;
/*  617 */       float y4i = t2i - t22i;
/*  618 */       float y5r = t3r - t23r;
/*  619 */       float y5i = t3i - t23i;
/*  620 */       float y6r = c1 * (t8r - t12r);
/*  621 */       float y6i = c1 * (t8i - t12i);
/*  622 */       float y7r = t21r - t3r;
/*  623 */       float y7i = t21i - t3i;
/*  624 */       float y8r = t3r + t20r;
/*  625 */       float y8i = t3i + t20i;
/*  626 */       z[j0] = t4r + t13r;
/*  627 */       z[j0 + 1] = t4i + t13i;
/*  628 */       z[j1] = y1r - y8i;
/*  629 */       z[j1 + 1] = y1i + y8r;
/*  630 */       z[j2] = y2r - y7i;
/*  631 */       z[j2 + 1] = y2i + y7r;
/*  632 */       z[j3] = y3r - y6i;
/*  633 */       z[j3 + 1] = y3i + y6r;
/*  634 */       z[j4] = y4r - y5i;
/*  635 */       z[j4 + 1] = y4i + y5r;
/*  636 */       z[j5] = y4r + y5i;
/*  637 */       z[j5 + 1] = y4i - y5r;
/*  638 */       z[j6] = y3r + y6i;
/*  639 */       z[j6 + 1] = y3i - y6r;
/*  640 */       z[j7] = y2r + y7i;
/*  641 */       z[j7 + 1] = y2i - y7r;
/*  642 */       z[j8] = y1r + y8i;
/*  643 */       z[j8 + 1] = y1i - y8r;
/*  644 */       int jt = j8 + 2;
/*  645 */       j8 = j7 + 2;
/*  646 */       j7 = j6 + 2;
/*  647 */       j6 = j5 + 2;
/*  648 */       j5 = j4 + 2;
/*  649 */       j4 = j3 + 2;
/*  650 */       j3 = j2 + 2;
/*  651 */       j2 = j1 + 2;
/*  652 */       j1 = j0 + 2;
/*  653 */       j0 = jt;
/*      */     }  } private static void pfa11(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10) { float c1; float c2; float c3; float c4;
/*      */     float c5;
/*      */     float c6;
/*      */     float c7;
/*      */     float c8;
/*      */     float c9;
/*      */     float c10;
/*  661 */     if (mu == 1) {
/*  662 */       c1 = 0.8412535F;
/*  663 */       c2 = 0.41541502F;
/*  664 */       c3 = -0.14231484F;
/*  665 */       c4 = -0.65486073F;
/*  666 */       c5 = -0.959493F;
/*  667 */       c6 = 0.54064083F;
/*  668 */       c7 = 0.90963197F;
/*  669 */       c8 = 0.98982143F;
/*  670 */       c9 = 0.7557496F;
/*  671 */       c10 = 0.28173256F;
/*  672 */     } else if (mu == 2) {
/*  673 */       c1 = 0.41541502F;
/*  674 */       c2 = -0.65486073F;
/*  675 */       c3 = -0.959493F;
/*  676 */       c4 = -0.14231484F;
/*  677 */       c5 = 0.8412535F;
/*  678 */       c6 = 0.90963197F;
/*  679 */       c7 = 0.7557496F;
/*  680 */       c8 = -0.28173256F;
/*  681 */       c9 = -0.98982143F;
/*  682 */       c10 = -0.54064083F;
/*  683 */     } else if (mu == 3) {
/*  684 */       c1 = -0.14231484F;
/*  685 */       c2 = -0.959493F;
/*  686 */       c3 = 0.41541502F;
/*  687 */       c4 = 0.8412535F;
/*  688 */       c5 = -0.65486073F;
/*  689 */       c6 = 0.98982143F;
/*  690 */       c7 = -0.28173256F;
/*  691 */       c8 = -0.90963197F;
/*  692 */       c9 = 0.54064083F;
/*  693 */       c10 = 0.7557496F;
/*  694 */     } else if (mu == 4) {
/*  695 */       c1 = -0.65486073F;
/*  696 */       c2 = -0.14231484F;
/*  697 */       c3 = 0.8412535F;
/*  698 */       c4 = -0.959493F;
/*  699 */       c5 = 0.41541502F;
/*  700 */       c6 = 0.7557496F;
/*  701 */       c7 = -0.98982143F;
/*  702 */       c8 = 0.54064083F;
/*  703 */       c9 = 0.28173256F;
/*  704 */       c10 = -0.90963197F;
/*  705 */     } else if (mu == 5) {
/*  706 */       c1 = -0.959493F;
/*  707 */       c2 = 0.8412535F;
/*  708 */       c3 = -0.65486073F;
/*  709 */       c4 = 0.41541502F;
/*  710 */       c5 = -0.14231484F;
/*  711 */       c6 = 0.28173256F;
/*  712 */       c7 = -0.54064083F;
/*  713 */       c8 = 0.7557496F;
/*  714 */       c9 = -0.90963197F;
/*  715 */       c10 = 0.98982143F;
/*  716 */     } else if (mu == 6) {
/*  717 */       c1 = -0.959493F;
/*  718 */       c2 = 0.8412535F;
/*  719 */       c3 = -0.65486073F;
/*  720 */       c4 = 0.41541502F;
/*  721 */       c5 = -0.14231484F;
/*  722 */       c6 = -0.28173256F;
/*  723 */       c7 = 0.54064083F;
/*  724 */       c8 = -0.7557496F;
/*  725 */       c9 = 0.90963197F;
/*  726 */       c10 = -0.98982143F;
/*  727 */     } else if (mu == 7) {
/*  728 */       c1 = -0.65486073F;
/*  729 */       c2 = -0.14231484F;
/*  730 */       c3 = 0.8412535F;
/*  731 */       c4 = -0.959493F;
/*  732 */       c5 = 0.41541502F;
/*  733 */       c6 = -0.7557496F;
/*  734 */       c7 = 0.98982143F;
/*  735 */       c8 = -0.54064083F;
/*  736 */       c9 = -0.28173256F;
/*  737 */       c10 = 0.90963197F;
/*  738 */     } else if (mu == 8) {
/*  739 */       c1 = -0.14231484F;
/*  740 */       c2 = -0.959493F;
/*  741 */       c3 = 0.41541502F;
/*  742 */       c4 = 0.8412535F;
/*  743 */       c5 = -0.65486073F;
/*  744 */       c6 = -0.98982143F;
/*  745 */       c7 = 0.28173256F;
/*  746 */       c8 = 0.90963197F;
/*  747 */       c9 = -0.54064083F;
/*  748 */       c10 = -0.7557496F;
/*  749 */     } else if (mu == 9) {
/*  750 */       c1 = 0.41541502F;
/*  751 */       c2 = -0.65486073F;
/*  752 */       c3 = -0.959493F;
/*  753 */       c4 = -0.14231484F;
/*  754 */       c5 = 0.8412535F;
/*  755 */       c6 = -0.90963197F;
/*  756 */       c7 = -0.7557496F;
/*  757 */       c8 = 0.28173256F;
/*  758 */       c9 = 0.98982143F;
/*  759 */       c10 = 0.54064083F;
/*      */     } else {
/*  761 */       c1 = 0.8412535F;
/*  762 */       c2 = 0.41541502F;
/*  763 */       c3 = -0.14231484F;
/*  764 */       c4 = -0.65486073F;
/*  765 */       c5 = -0.959493F;
/*  766 */       c6 = -0.54064083F;
/*  767 */       c7 = -0.90963197F;
/*  768 */       c8 = -0.98982143F;
/*  769 */       c9 = -0.7557496F;
/*  770 */       c10 = -0.28173256F;
/*      */     } 
/*  772 */     for (int i = 0; i < m; i++) {
/*  773 */       float t1r = z[j1] + z[j10];
/*  774 */       float t1i = z[j1 + 1] + z[j10 + 1];
/*  775 */       float t2r = z[j2] + z[j9];
/*  776 */       float t2i = z[j2 + 1] + z[j9 + 1];
/*  777 */       float t3r = z[j3] + z[j8];
/*  778 */       float t3i = z[j3 + 1] + z[j8 + 1];
/*  779 */       float t4r = z[j4] + z[j7];
/*  780 */       float t4i = z[j4 + 1] + z[j7 + 1];
/*  781 */       float t5r = z[j5] + z[j6];
/*  782 */       float t5i = z[j5 + 1] + z[j6 + 1];
/*  783 */       float t6r = z[j1] - z[j10];
/*  784 */       float t6i = z[j1 + 1] - z[j10 + 1];
/*  785 */       float t7r = z[j2] - z[j9];
/*  786 */       float t7i = z[j2 + 1] - z[j9 + 1];
/*  787 */       float t8r = z[j3] - z[j8];
/*  788 */       float t8i = z[j3 + 1] - z[j8 + 1];
/*  789 */       float t9r = z[j4] - z[j7];
/*  790 */       float t9i = z[j4 + 1] - z[j7 + 1];
/*  791 */       float t10r = z[j5] - z[j6];
/*  792 */       float t10i = z[j5 + 1] - z[j6 + 1];
/*  793 */       float t11r = z[j0] - 0.5F * t5r;
/*  794 */       float t11i = z[j0 + 1] - 0.5F * t5i;
/*  795 */       float t12r = t1r - t5r;
/*  796 */       float t12i = t1i - t5i;
/*  797 */       float t13r = t2r - t5r;
/*  798 */       float t13i = t2i - t5i;
/*  799 */       float t14r = t3r - t5r;
/*  800 */       float t14i = t3i - t5i;
/*  801 */       float t15r = t4r - t5r;
/*  802 */       float t15i = t4i - t5i;
/*  803 */       float y1r = t11r + c1 * t12r + c2 * t13r + c3 * t14r + c4 * t15r;
/*  804 */       float y1i = t11i + c1 * t12i + c2 * t13i + c3 * t14i + c4 * t15i;
/*  805 */       float y2r = t11r + c2 * t12r + c4 * t13r + c5 * t14r + c3 * t15r;
/*  806 */       float y2i = t11i + c2 * t12i + c4 * t13i + c5 * t14i + c3 * t15i;
/*  807 */       float y3r = t11r + c3 * t12r + c5 * t13r + c2 * t14r + c1 * t15r;
/*  808 */       float y3i = t11i + c3 * t12i + c5 * t13i + c2 * t14i + c1 * t15i;
/*  809 */       float y4r = t11r + c4 * t12r + c3 * t13r + c1 * t14r + c5 * t15r;
/*  810 */       float y4i = t11i + c4 * t12i + c3 * t13i + c1 * t14i + c5 * t15i;
/*  811 */       float y5r = t11r + c5 * t12r + c1 * t13r + c4 * t14r + c2 * t15r;
/*  812 */       float y5i = t11i + c5 * t12i + c1 * t13i + c4 * t14i + c2 * t15i;
/*  813 */       float y6r = c10 * t6r - c6 * t7r + c9 * t8r - c7 * t9r + c8 * t10r;
/*  814 */       float y6i = c10 * t6i - c6 * t7i + c9 * t8i - c7 * t9i + c8 * t10i;
/*  815 */       float y7r = c9 * t6r - c8 * t7r + c6 * t8r + c10 * t9r - c7 * t10r;
/*  816 */       float y7i = c9 * t6i - c8 * t7i + c6 * t8i + c10 * t9i - c7 * t10i;
/*  817 */       float y8r = c8 * t6r - c10 * t7r - c7 * t8r + c6 * t9r + c9 * t10r;
/*  818 */       float y8i = c8 * t6i - c10 * t7i - c7 * t8i + c6 * t9i + c9 * t10i;
/*  819 */       float y9r = c7 * t6r + c9 * t7r - c10 * t8r - c8 * t9r - c6 * t10r;
/*  820 */       float y9i = c7 * t6i + c9 * t7i - c10 * t8i - c8 * t9i - c6 * t10i;
/*  821 */       float y10r = c6 * t6r + c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r;
/*  822 */       float y10i = c6 * t6i + c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i;
/*  823 */       z[j0] = z[j0] + t1r + t2r + t3r + t4r + t5r;
/*  824 */       z[j0 + 1] = z[j0 + 1] + t1i + t2i + t3i + t4i + t5i;
/*  825 */       z[j1] = y1r - y10i;
/*  826 */       z[j1 + 1] = y1i + y10r;
/*  827 */       z[j2] = y2r - y9i;
/*  828 */       z[j2 + 1] = y2i + y9r;
/*  829 */       z[j3] = y3r - y8i;
/*  830 */       z[j3 + 1] = y3i + y8r;
/*  831 */       z[j4] = y4r - y7i;
/*  832 */       z[j4 + 1] = y4i + y7r;
/*  833 */       z[j5] = y5r - y6i;
/*  834 */       z[j5 + 1] = y5i + y6r;
/*  835 */       z[j6] = y5r + y6i;
/*  836 */       z[j6 + 1] = y5i - y6r;
/*  837 */       z[j7] = y4r + y7i;
/*  838 */       z[j7 + 1] = y4i - y7r;
/*  839 */       z[j8] = y3r + y8i;
/*  840 */       z[j8 + 1] = y3i - y8r;
/*  841 */       z[j9] = y2r + y9i;
/*  842 */       z[j9 + 1] = y2i - y9r;
/*  843 */       z[j10] = y1r + y10i;
/*  844 */       z[j10 + 1] = y1i - y10r;
/*  845 */       int jt = j10 + 2;
/*  846 */       j10 = j9 + 2;
/*  847 */       j9 = j8 + 2;
/*  848 */       j8 = j7 + 2;
/*  849 */       j7 = j6 + 2;
/*  850 */       j6 = j5 + 2;
/*  851 */       j5 = j4 + 2;
/*  852 */       j4 = j3 + 2;
/*  853 */       j3 = j2 + 2;
/*  854 */       j2 = j1 + 2;
/*  855 */       j1 = j0 + 2;
/*  856 */       j0 = jt;
/*      */     }  } private static void pfa13(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12) { float c1; float c2; float c3; float c4; float c5; float c6;
/*      */     float c7;
/*      */     float c8;
/*      */     float c9;
/*      */     float c10;
/*      */     float c11;
/*      */     float c12;
/*  864 */     if (mu == 1) {
/*  865 */       c1 = 0.885456F;
/*  866 */       c2 = 0.56806475F;
/*  867 */       c3 = 0.12053668F;
/*  868 */       c4 = -0.3546049F;
/*  869 */       c5 = -0.7485107F;
/*  870 */       c6 = -0.97094184F;
/*  871 */       c7 = 0.46472317F;
/*  872 */       c8 = 0.82298386F;
/*  873 */       c9 = 0.99270886F;
/*  874 */       c10 = 0.9350162F;
/*  875 */       c11 = 0.66312265F;
/*  876 */       c12 = 0.23931566F;
/*  877 */     } else if (mu == 2) {
/*  878 */       c1 = 0.56806475F;
/*  879 */       c2 = -0.3546049F;
/*  880 */       c3 = -0.97094184F;
/*  881 */       c4 = -0.7485107F;
/*  882 */       c5 = 0.12053668F;
/*  883 */       c6 = 0.885456F;
/*  884 */       c7 = 0.82298386F;
/*  885 */       c8 = 0.9350162F;
/*  886 */       c9 = 0.23931566F;
/*  887 */       c10 = -0.66312265F;
/*  888 */       c11 = -0.99270886F;
/*  889 */       c12 = -0.46472317F;
/*  890 */     } else if (mu == 3) {
/*  891 */       c1 = 0.12053668F;
/*  892 */       c2 = -0.97094184F;
/*  893 */       c3 = -0.3546049F;
/*  894 */       c4 = 0.885456F;
/*  895 */       c5 = 0.56806475F;
/*  896 */       c6 = -0.7485107F;
/*  897 */       c7 = 0.99270886F;
/*  898 */       c8 = 0.23931566F;
/*  899 */       c9 = -0.9350162F;
/*  900 */       c10 = -0.46472317F;
/*  901 */       c11 = 0.82298386F;
/*  902 */       c12 = 0.66312265F;
/*  903 */     } else if (mu == 4) {
/*  904 */       c1 = -0.3546049F;
/*  905 */       c2 = -0.7485107F;
/*  906 */       c3 = 0.885456F;
/*  907 */       c4 = 0.12053668F;
/*  908 */       c5 = -0.97094184F;
/*  909 */       c6 = 0.56806475F;
/*  910 */       c7 = 0.9350162F;
/*  911 */       c8 = -0.66312265F;
/*  912 */       c9 = -0.46472317F;
/*  913 */       c10 = 0.99270886F;
/*  914 */       c11 = -0.23931566F;
/*  915 */       c12 = -0.82298386F;
/*  916 */     } else if (mu == 5) {
/*  917 */       c1 = -0.7485107F;
/*  918 */       c2 = 0.12053668F;
/*  919 */       c3 = 0.56806475F;
/*  920 */       c4 = -0.97094184F;
/*  921 */       c5 = 0.885456F;
/*  922 */       c6 = -0.3546049F;
/*  923 */       c7 = 0.66312265F;
/*  924 */       c8 = -0.99270886F;
/*  925 */       c9 = 0.82298386F;
/*  926 */       c10 = -0.23931566F;
/*  927 */       c11 = -0.46472317F;
/*  928 */       c12 = 0.9350162F;
/*  929 */     } else if (mu == 6) {
/*  930 */       c1 = -0.97094184F;
/*  931 */       c2 = 0.885456F;
/*  932 */       c3 = -0.7485107F;
/*  933 */       c4 = 0.56806475F;
/*  934 */       c5 = -0.3546049F;
/*  935 */       c6 = 0.12053668F;
/*  936 */       c7 = 0.23931566F;
/*  937 */       c8 = -0.46472317F;
/*  938 */       c9 = 0.66312265F;
/*  939 */       c10 = -0.82298386F;
/*  940 */       c11 = 0.9350162F;
/*  941 */       c12 = -0.99270886F;
/*  942 */     } else if (mu == 7) {
/*  943 */       c1 = -0.97094184F;
/*  944 */       c2 = 0.885456F;
/*  945 */       c3 = -0.7485107F;
/*  946 */       c4 = 0.56806475F;
/*  947 */       c5 = -0.3546049F;
/*  948 */       c6 = 0.12053668F;
/*  949 */       c7 = -0.23931566F;
/*  950 */       c8 = 0.46472317F;
/*  951 */       c9 = -0.66312265F;
/*  952 */       c10 = 0.82298386F;
/*  953 */       c11 = -0.9350162F;
/*  954 */       c12 = 0.99270886F;
/*  955 */     } else if (mu == 8) {
/*  956 */       c1 = -0.7485107F;
/*  957 */       c2 = 0.12053668F;
/*  958 */       c3 = 0.56806475F;
/*  959 */       c4 = -0.97094184F;
/*  960 */       c5 = 0.885456F;
/*  961 */       c6 = -0.3546049F;
/*  962 */       c7 = -0.66312265F;
/*  963 */       c8 = 0.99270886F;
/*  964 */       c9 = -0.82298386F;
/*  965 */       c10 = 0.23931566F;
/*  966 */       c11 = 0.46472317F;
/*  967 */       c12 = -0.9350162F;
/*  968 */     } else if (mu == 9) {
/*  969 */       c1 = -0.3546049F;
/*  970 */       c2 = -0.7485107F;
/*  971 */       c3 = 0.885456F;
/*  972 */       c4 = 0.12053668F;
/*  973 */       c5 = -0.97094184F;
/*  974 */       c6 = 0.56806475F;
/*  975 */       c7 = -0.9350162F;
/*  976 */       c8 = 0.66312265F;
/*  977 */       c9 = 0.46472317F;
/*  978 */       c10 = -0.99270886F;
/*  979 */       c11 = 0.23931566F;
/*  980 */       c12 = 0.82298386F;
/*  981 */     } else if (mu == 10) {
/*  982 */       c1 = 0.12053668F;
/*  983 */       c2 = -0.97094184F;
/*  984 */       c3 = -0.3546049F;
/*  985 */       c4 = 0.885456F;
/*  986 */       c5 = 0.56806475F;
/*  987 */       c6 = -0.7485107F;
/*  988 */       c7 = -0.99270886F;
/*  989 */       c8 = -0.23931566F;
/*  990 */       c9 = 0.9350162F;
/*  991 */       c10 = 0.46472317F;
/*  992 */       c11 = -0.82298386F;
/*  993 */       c12 = -0.66312265F;
/*  994 */     } else if (mu == 11) {
/*  995 */       c1 = 0.56806475F;
/*  996 */       c2 = -0.3546049F;
/*  997 */       c3 = -0.97094184F;
/*  998 */       c4 = -0.7485107F;
/*  999 */       c5 = 0.12053668F;
/* 1000 */       c6 = 0.885456F;
/* 1001 */       c7 = -0.82298386F;
/* 1002 */       c8 = -0.9350162F;
/* 1003 */       c9 = -0.23931566F;
/* 1004 */       c10 = 0.66312265F;
/* 1005 */       c11 = 0.99270886F;
/* 1006 */       c12 = 0.46472317F;
/*      */     } else {
/* 1008 */       c1 = 0.885456F;
/* 1009 */       c2 = 0.56806475F;
/* 1010 */       c3 = 0.12053668F;
/* 1011 */       c4 = -0.3546049F;
/* 1012 */       c5 = -0.7485107F;
/* 1013 */       c6 = -0.97094184F;
/* 1014 */       c7 = -0.46472317F;
/* 1015 */       c8 = -0.82298386F;
/* 1016 */       c9 = -0.99270886F;
/* 1017 */       c10 = -0.9350162F;
/* 1018 */       c11 = -0.66312265F;
/* 1019 */       c12 = -0.23931566F;
/*      */     } 
/* 1021 */     for (int i = 0; i < m; i++) {
/* 1022 */       float t1r = z[j1] + z[j12];
/* 1023 */       float t1i = z[j1 + 1] + z[j12 + 1];
/* 1024 */       float t2r = z[j2] + z[j11];
/* 1025 */       float t2i = z[j2 + 1] + z[j11 + 1];
/* 1026 */       float t3r = z[j3] + z[j10];
/* 1027 */       float t3i = z[j3 + 1] + z[j10 + 1];
/* 1028 */       float t4r = z[j4] + z[j9];
/* 1029 */       float t4i = z[j4 + 1] + z[j9 + 1];
/* 1030 */       float t5r = z[j5] + z[j8];
/* 1031 */       float t5i = z[j5 + 1] + z[j8 + 1];
/* 1032 */       float t6r = z[j6] + z[j7];
/* 1033 */       float t6i = z[j6 + 1] + z[j7 + 1];
/* 1034 */       float t7r = z[j1] - z[j12];
/* 1035 */       float t7i = z[j1 + 1] - z[j12 + 1];
/* 1036 */       float t8r = z[j2] - z[j11];
/* 1037 */       float t8i = z[j2 + 1] - z[j11 + 1];
/* 1038 */       float t9r = z[j3] - z[j10];
/* 1039 */       float t9i = z[j3 + 1] - z[j10 + 1];
/* 1040 */       float t10r = z[j4] - z[j9];
/* 1041 */       float t10i = z[j4 + 1] - z[j9 + 1];
/* 1042 */       float t11r = z[j5] - z[j8];
/* 1043 */       float t11i = z[j5 + 1] - z[j8 + 1];
/* 1044 */       float t12r = z[j6] - z[j7];
/* 1045 */       float t12i = z[j6 + 1] - z[j7 + 1];
/* 1046 */       float t13r = z[j0] - 0.5F * t6r;
/* 1047 */       float t13i = z[j0 + 1] - 0.5F * t6i;
/* 1048 */       float t14r = t1r - t6r;
/* 1049 */       float t14i = t1i - t6i;
/* 1050 */       float t15r = t2r - t6r;
/* 1051 */       float t15i = t2i - t6i;
/* 1052 */       float t16r = t3r - t6r;
/* 1053 */       float t16i = t3i - t6i;
/* 1054 */       float t17r = t4r - t6r;
/* 1055 */       float t17i = t4i - t6i;
/* 1056 */       float t18r = t5r - t6r;
/* 1057 */       float t18i = t5i - t6i;
/* 1058 */       float y1r = t13r + c1 * t14r + c2 * t15r + c3 * t16r + c4 * t17r + c5 * t18r;
/* 1059 */       float y1i = t13i + c1 * t14i + c2 * t15i + c3 * t16i + c4 * t17i + c5 * t18i;
/* 1060 */       float y2r = t13r + c2 * t14r + c4 * t15r + c6 * t16r + c5 * t17r + c3 * t18r;
/* 1061 */       float y2i = t13i + c2 * t14i + c4 * t15i + c6 * t16i + c5 * t17i + c3 * t18i;
/* 1062 */       float y3r = t13r + c3 * t14r + c6 * t15r + c4 * t16r + c1 * t17r + c2 * t18r;
/* 1063 */       float y3i = t13i + c3 * t14i + c6 * t15i + c4 * t16i + c1 * t17i + c2 * t18i;
/* 1064 */       float y4r = t13r + c4 * t14r + c5 * t15r + c1 * t16r + c3 * t17r + c6 * t18r;
/* 1065 */       float y4i = t13i + c4 * t14i + c5 * t15i + c1 * t16i + c3 * t17i + c6 * t18i;
/* 1066 */       float y5r = t13r + c5 * t14r + c3 * t15r + c2 * t16r + c6 * t17r + c1 * t18r;
/* 1067 */       float y5i = t13i + c5 * t14i + c3 * t15i + c2 * t16i + c6 * t17i + c1 * t18i;
/* 1068 */       float y6r = t13r + c6 * t14r + c1 * t15r + c5 * t16r + c2 * t17r + c4 * t18r;
/* 1069 */       float y6i = t13i + c6 * t14i + c1 * t15i + c5 * t16i + c2 * t17i + c4 * t18i;
/* 1070 */       float y7r = c12 * t7r - c7 * t8r + c11 * t9r - c8 * t10r + c10 * t11r - c9 * t12r;
/* 1071 */       float y7i = c12 * t7i - c7 * t8i + c11 * t9i - c8 * t10i + c10 * t11i - c9 * t12i;
/* 1072 */       float y8r = c11 * t7r - c9 * t8r + c8 * t9r - c12 * t10r - c7 * t11r + c10 * t12r;
/* 1073 */       float y8i = c11 * t7i - c9 * t8i + c8 * t9i - c12 * t10i - c7 * t11i + c10 * t12i;
/* 1074 */       float y9r = c10 * t7r - c11 * t8r - c7 * t9r + c9 * t10r - c12 * t11r - c8 * t12r;
/* 1075 */       float y9i = c10 * t7i - c11 * t8i - c7 * t9i + c9 * t10i - c12 * t11i - c8 * t12i;
/* 1076 */       float y10r = c9 * t7r + c12 * t8r - c10 * t9r - c7 * t10r + c8 * t11r + c11 * t12r;
/* 1077 */       float y10i = c9 * t7i + c12 * t8i - c10 * t9i - c7 * t10i + c8 * t11i + c11 * t12i;
/* 1078 */       float y11r = c8 * t7r + c10 * t8r + c12 * t9r - c11 * t10r - c9 * t11r - c7 * t12r;
/* 1079 */       float y11i = c8 * t7i + c10 * t8i + c12 * t9i - c11 * t10i - c9 * t11i - c7 * t12i;
/* 1080 */       float y12r = c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r + c11 * t11r + c12 * t12r;
/* 1081 */       float y12i = c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i + c11 * t11i + c12 * t12i;
/* 1082 */       z[j0] = z[j0] + t1r + t2r + t3r + t4r + t5r + t6r;
/* 1083 */       z[j0 + 1] = z[j0 + 1] + t1i + t2i + t3i + t4i + t5i + t6i;
/* 1084 */       z[j1] = y1r - y12i;
/* 1085 */       z[j1 + 1] = y1i + y12r;
/* 1086 */       z[j2] = y2r - y11i;
/* 1087 */       z[j2 + 1] = y2i + y11r;
/* 1088 */       z[j3] = y3r - y10i;
/* 1089 */       z[j3 + 1] = y3i + y10r;
/* 1090 */       z[j4] = y4r - y9i;
/* 1091 */       z[j4 + 1] = y4i + y9r;
/* 1092 */       z[j5] = y5r - y8i;
/* 1093 */       z[j5 + 1] = y5i + y8r;
/* 1094 */       z[j6] = y6r - y7i;
/* 1095 */       z[j6 + 1] = y6i + y7r;
/* 1096 */       z[j7] = y6r + y7i;
/* 1097 */       z[j7 + 1] = y6i - y7r;
/* 1098 */       z[j8] = y5r + y8i;
/* 1099 */       z[j8 + 1] = y5i - y8r;
/* 1100 */       z[j9] = y4r + y9i;
/* 1101 */       z[j9 + 1] = y4i - y9r;
/* 1102 */       z[j10] = y3r + y10i;
/* 1103 */       z[j10 + 1] = y3i - y10r;
/* 1104 */       z[j11] = y2r + y11i;
/* 1105 */       z[j11 + 1] = y2i - y11r;
/* 1106 */       z[j12] = y1r + y12i;
/* 1107 */       z[j12 + 1] = y1i - y12r;
/* 1108 */       int jt = j12 + 2;
/* 1109 */       j12 = j11 + 2;
/* 1110 */       j11 = j10 + 2;
/* 1111 */       j10 = j9 + 2;
/* 1112 */       j9 = j8 + 2;
/* 1113 */       j8 = j7 + 2;
/* 1114 */       j7 = j6 + 2;
/* 1115 */       j6 = j5 + 2;
/* 1116 */       j5 = j4 + 2;
/* 1117 */       j4 = j3 + 2;
/* 1118 */       j3 = j2 + 2;
/* 1119 */       j2 = j1 + 2;
/* 1120 */       j1 = j0 + 2;
/* 1121 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa16(float[] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12, int j13, int j14, int j15) {
/*      */     float c1, c2, c3, c4;
/* 1129 */     if (mu == 1) {
/* 1130 */       c1 = 1.0F;
/* 1131 */       c2 = 0.9238795F;
/* 1132 */       c3 = 0.38268343F;
/* 1133 */       c4 = 0.70710677F;
/* 1134 */     } else if (mu == 3) {
/* 1135 */       c1 = -1.0F;
/* 1136 */       c2 = 0.38268343F;
/* 1137 */       c3 = 0.9238795F;
/* 1138 */       c4 = -0.70710677F;
/* 1139 */     } else if (mu == 5) {
/* 1140 */       c1 = 1.0F;
/* 1141 */       c2 = -0.38268343F;
/* 1142 */       c3 = 0.9238795F;
/* 1143 */       c4 = -0.70710677F;
/* 1144 */     } else if (mu == 7) {
/* 1145 */       c1 = -1.0F;
/* 1146 */       c2 = -0.9238795F;
/* 1147 */       c3 = 0.38268343F;
/* 1148 */       c4 = 0.70710677F;
/* 1149 */     } else if (mu == 9) {
/* 1150 */       c1 = 1.0F;
/* 1151 */       c2 = -0.9238795F;
/* 1152 */       c3 = -0.38268343F;
/* 1153 */       c4 = 0.70710677F;
/* 1154 */     } else if (mu == 11) {
/* 1155 */       c1 = -1.0F;
/* 1156 */       c2 = -0.38268343F;
/* 1157 */       c3 = -0.9238795F;
/* 1158 */       c4 = -0.70710677F;
/* 1159 */     } else if (mu == 13) {
/* 1160 */       c1 = 1.0F;
/* 1161 */       c2 = 0.38268343F;
/* 1162 */       c3 = -0.9238795F;
/* 1163 */       c4 = -0.70710677F;
/*      */     } else {
/* 1165 */       c1 = -1.0F;
/* 1166 */       c2 = 0.9238795F;
/* 1167 */       c3 = -0.38268343F;
/* 1168 */       c4 = 0.70710677F;
/*      */     } 
/* 1170 */     float c5 = c1 * c4;
/* 1171 */     float c6 = c1 * c3;
/* 1172 */     float c7 = c1 * c2;
/* 1173 */     for (int i = 0; i < m; i++) {
/* 1174 */       float t1r = z[j0] + z[j8];
/* 1175 */       float t1i = z[j0 + 1] + z[j8 + 1];
/* 1176 */       float t2r = z[j4] + z[j12];
/* 1177 */       float t2i = z[j4 + 1] + z[j12 + 1];
/* 1178 */       float t3r = z[j0] - z[j8];
/* 1179 */       float t3i = z[j0 + 1] - z[j8 + 1];
/* 1180 */       float t4r = c1 * (z[j4] - z[j12]);
/* 1181 */       float t4i = c1 * (z[j4 + 1] - z[j12 + 1]);
/* 1182 */       float t5r = t1r + t2r;
/* 1183 */       float t5i = t1i + t2i;
/* 1184 */       float t6r = t1r - t2r;
/* 1185 */       float t6i = t1i - t2i;
/* 1186 */       float t7r = z[j1] + z[j9];
/* 1187 */       float t7i = z[j1 + 1] + z[j9 + 1];
/* 1188 */       float t8r = z[j5] + z[j13];
/* 1189 */       float t8i = z[j5 + 1] + z[j13 + 1];
/* 1190 */       float t9r = z[j1] - z[j9];
/* 1191 */       float t9i = z[j1 + 1] - z[j9 + 1];
/* 1192 */       float t10r = z[j5] - z[j13];
/* 1193 */       float t10i = z[j5 + 1] - z[j13 + 1];
/* 1194 */       float t11r = t7r + t8r;
/* 1195 */       float t11i = t7i + t8i;
/* 1196 */       float t12r = t7r - t8r;
/* 1197 */       float t12i = t7i - t8i;
/* 1198 */       float t13r = z[j2] + z[j10];
/* 1199 */       float t13i = z[j2 + 1] + z[j10 + 1];
/* 1200 */       float t14r = z[j6] + z[j14];
/* 1201 */       float t14i = z[j6 + 1] + z[j14 + 1];
/* 1202 */       float t15r = z[j2] - z[j10];
/* 1203 */       float t15i = z[j2 + 1] - z[j10 + 1];
/* 1204 */       float t16r = z[j6] - z[j14];
/* 1205 */       float t16i = z[j6 + 1] - z[j14 + 1];
/* 1206 */       float t17r = t13r + t14r;
/* 1207 */       float t17i = t13i + t14i;
/* 1208 */       float t18r = c4 * (t15r - t16r);
/* 1209 */       float t18i = c4 * (t15i - t16i);
/* 1210 */       float t19r = c5 * (t15r + t16r);
/* 1211 */       float t19i = c5 * (t15i + t16i);
/* 1212 */       float t20r = c1 * (t13r - t14r);
/* 1213 */       float t20i = c1 * (t13i - t14i);
/* 1214 */       float t21r = z[j3] + z[j11];
/* 1215 */       float t21i = z[j3 + 1] + z[j11 + 1];
/* 1216 */       float t22r = z[j7] + z[j15];
/* 1217 */       float t22i = z[j7 + 1] + z[j15 + 1];
/* 1218 */       float t23r = z[j3] - z[j11];
/* 1219 */       float t23i = z[j3 + 1] - z[j11 + 1];
/* 1220 */       float t24r = z[j7] - z[j15];
/* 1221 */       float t24i = z[j7 + 1] - z[j15 + 1];
/* 1222 */       float t25r = t21r + t22r;
/* 1223 */       float t25i = t21i + t22i;
/* 1224 */       float t26r = t21r - t22r;
/* 1225 */       float t26i = t21i - t22i;
/* 1226 */       float t27r = t9r + t24r;
/* 1227 */       float t27i = t9i + t24i;
/* 1228 */       float t28r = t10r + t23r;
/* 1229 */       float t28i = t10i + t23i;
/* 1230 */       float t29r = t9r - t24r;
/* 1231 */       float t29i = t9i - t24i;
/* 1232 */       float t30r = t10r - t23r;
/* 1233 */       float t30i = t10i - t23i;
/* 1234 */       float t31r = t5r + t17r;
/* 1235 */       float t31i = t5i + t17i;
/* 1236 */       float t32r = t11r + t25r;
/* 1237 */       float t32i = t11i + t25i;
/* 1238 */       float t33r = t3r + t18r;
/* 1239 */       float t33i = t3i + t18i;
/* 1240 */       float t34r = c2 * t29r - c6 * t30r;
/* 1241 */       float t34i = c2 * t29i - c6 * t30i;
/* 1242 */       float t35r = t3r - t18r;
/* 1243 */       float t35i = t3i - t18i;
/* 1244 */       float t36r = c7 * t27r - c3 * t28r;
/* 1245 */       float t36i = c7 * t27i - c3 * t28i;
/* 1246 */       float t37r = t4r + t19r;
/* 1247 */       float t37i = t4i + t19i;
/* 1248 */       float t38r = c3 * t27r + c7 * t28r;
/* 1249 */       float t38i = c3 * t27i + c7 * t28i;
/* 1250 */       float t39r = t4r - t19r;
/* 1251 */       float t39i = t4i - t19i;
/* 1252 */       float t40r = c6 * t29r + c2 * t30r;
/* 1253 */       float t40i = c6 * t29i + c2 * t30i;
/* 1254 */       float t41r = c4 * (t12r - t26r);
/* 1255 */       float t41i = c4 * (t12i - t26i);
/* 1256 */       float t42r = c5 * (t12r + t26r);
/* 1257 */       float t42i = c5 * (t12i + t26i);
/* 1258 */       float y1r = t33r + t34r;
/* 1259 */       float y1i = t33i + t34i;
/* 1260 */       float y2r = t6r + t41r;
/* 1261 */       float y2i = t6i + t41i;
/* 1262 */       float y3r = t35r + t40r;
/* 1263 */       float y3i = t35i + t40i;
/* 1264 */       float y4r = t5r - t17r;
/* 1265 */       float y4i = t5i - t17i;
/* 1266 */       float y5r = t35r - t40r;
/* 1267 */       float y5i = t35i - t40i;
/* 1268 */       float y6r = t6r - t41r;
/* 1269 */       float y6i = t6i - t41i;
/* 1270 */       float y7r = t33r - t34r;
/* 1271 */       float y7i = t33i - t34i;
/* 1272 */       float y9r = t38r - t37r;
/* 1273 */       float y9i = t38i - t37i;
/* 1274 */       float y10r = t42r - t20r;
/* 1275 */       float y10i = t42i - t20i;
/* 1276 */       float y11r = t36r + t39r;
/* 1277 */       float y11i = t36i + t39i;
/* 1278 */       float y12r = c1 * (t11r - t25r);
/* 1279 */       float y12i = c1 * (t11i - t25i);
/* 1280 */       float y13r = t36r - t39r;
/* 1281 */       float y13i = t36i - t39i;
/* 1282 */       float y14r = t42r + t20r;
/* 1283 */       float y14i = t42i + t20i;
/* 1284 */       float y15r = t38r + t37r;
/* 1285 */       float y15i = t38i + t37i;
/* 1286 */       z[j0] = t31r + t32r;
/* 1287 */       z[j0 + 1] = t31i + t32i;
/* 1288 */       z[j1] = y1r - y15i;
/* 1289 */       z[j1 + 1] = y1i + y15r;
/* 1290 */       z[j2] = y2r - y14i;
/* 1291 */       z[j2 + 1] = y2i + y14r;
/* 1292 */       z[j3] = y3r - y13i;
/* 1293 */       z[j3 + 1] = y3i + y13r;
/* 1294 */       z[j4] = y4r - y12i;
/* 1295 */       z[j4 + 1] = y4i + y12r;
/* 1296 */       z[j5] = y5r - y11i;
/* 1297 */       z[j5 + 1] = y5i + y11r;
/* 1298 */       z[j6] = y6r - y10i;
/* 1299 */       z[j6 + 1] = y6i + y10r;
/* 1300 */       z[j7] = y7r - y9i;
/* 1301 */       z[j7 + 1] = y7i + y9r;
/* 1302 */       z[j8] = t31r - t32r;
/* 1303 */       z[j8 + 1] = t31i - t32i;
/* 1304 */       z[j9] = y7r + y9i;
/* 1305 */       z[j9 + 1] = y7i - y9r;
/* 1306 */       z[j10] = y6r + y10i;
/* 1307 */       z[j10 + 1] = y6i - y10r;
/* 1308 */       z[j11] = y5r + y11i;
/* 1309 */       z[j11 + 1] = y5i - y11r;
/* 1310 */       z[j12] = y4r + y12i;
/* 1311 */       z[j12 + 1] = y4i - y12r;
/* 1312 */       z[j13] = y3r + y13i;
/* 1313 */       z[j13 + 1] = y3i - y13r;
/* 1314 */       z[j14] = y2r + y14i;
/* 1315 */       z[j14 + 1] = y2i - y14r;
/* 1316 */       z[j15] = y1r + y15i;
/* 1317 */       z[j15 + 1] = y1i - y15r;
/* 1318 */       int jt = j15 + 2;
/* 1319 */       j15 = j14 + 2;
/* 1320 */       j14 = j13 + 2;
/* 1321 */       j13 = j12 + 2;
/* 1322 */       j12 = j11 + 2;
/* 1323 */       j11 = j10 + 2;
/* 1324 */       j10 = j9 + 2;
/* 1325 */       j9 = j8 + 2;
/* 1326 */       j8 = j7 + 2;
/* 1327 */       j7 = j6 + 2;
/* 1328 */       j6 = j5 + 2;
/* 1329 */       j5 = j4 + 2;
/* 1330 */       j4 = j3 + 2;
/* 1331 */       j3 = j2 + 2;
/* 1332 */       j2 = j1 + 2;
/* 1333 */       j1 = j0 + 2;
/* 1334 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void transform2a(int sign, int n1, int nfft, float[][] z)
/*      */   {
/* 1351 */     int nleft = nfft;
/*      */ 
/*      */     
/* 1354 */     for (int jfac = 0; jfac < 10; jfac++) {
/*      */ 
/*      */       
/* 1357 */       int ifac = _kfac[jfac];
/* 1358 */       int ndiv = nleft / ifac;
/* 1359 */       if (ndiv * ifac == nleft) {
/*      */ 
/*      */ 
/*      */         
/* 1363 */         nleft = ndiv;
/* 1364 */         int m = nfft / ifac;
/*      */ 
/*      */         
/* 1367 */         int mu = 0;
/* 1368 */         int mm = 0;
/* 1369 */         for (int kfac = 1; kfac <= ifac && mm % ifac != 1; kfac++) {
/* 1370 */           mu = kfac;
/* 1371 */           mm = kfac * m;
/*      */         } 
/* 1373 */         if (sign < 0) {
/* 1374 */           mu = ifac - mu;
/*      */         }
/*      */         
/* 1377 */         int jinc = mm;
/* 1378 */         int jmax = nfft;
/* 1379 */         int j0 = 0;
/* 1380 */         int j1 = j0 + jinc;
/*      */ 
/*      */         
/* 1383 */         if (ifac == 2) {
/* 1384 */           pfa2a(n1, z, mu, m, j0, j1);
/*      */         } else {
/*      */           
/* 1387 */           int j2 = (j1 + jinc) % jmax;
/*      */ 
/*      */           
/* 1390 */           if (ifac == 3) {
/* 1391 */             pfa3a(n1, z, mu, m, j0, j1, j2);
/*      */           } else {
/*      */             
/* 1394 */             int j3 = (j2 + jinc) % jmax;
/*      */ 
/*      */             
/* 1397 */             if (ifac == 4) {
/* 1398 */               pfa4a(n1, z, mu, m, j0, j1, j2, j3);
/*      */             } else {
/*      */               
/* 1401 */               int j4 = (j3 + jinc) % jmax;
/*      */ 
/*      */               
/* 1404 */               if (ifac == 5) {
/* 1405 */                 pfa5a(n1, z, mu, m, j0, j1, j2, j3, j4);
/*      */               } else {
/*      */                 
/* 1408 */                 int j5 = (j4 + jinc) % jmax;
/* 1409 */                 int j6 = (j5 + jinc) % jmax;
/*      */ 
/*      */                 
/* 1412 */                 if (ifac == 7) {
/* 1413 */                   pfa7a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6);
/*      */                 } else {
/*      */                   
/* 1416 */                   int j7 = (j6 + jinc) % jmax;
/*      */ 
/*      */                   
/* 1419 */                   if (ifac == 8) {
/* 1420 */                     pfa8a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7);
/*      */                   } else {
/*      */                     
/* 1423 */                     int j8 = (j7 + jinc) % jmax;
/*      */ 
/*      */                     
/* 1426 */                     if (ifac == 9)
/* 1427 */                     { pfa9a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8); }
/*      */                     else
/*      */                     
/* 1430 */                     { int j9 = (j8 + jinc) % jmax;
/* 1431 */                       int j10 = (j9 + jinc) % jmax;
/*      */ 
/*      */                       
/* 1434 */                       if (ifac == 11)
/* 1435 */                       { pfa11a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10); }
/*      */                       else
/*      */                       
/* 1438 */                       { int j11 = (j10 + jinc) % jmax;
/* 1439 */                         int j12 = (j11 + jinc) % jmax;
/*      */ 
/*      */                         
/* 1442 */                         if (ifac == 13)
/* 1443 */                         { pfa13a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12); }
/*      */                         else
/*      */                         
/* 1446 */                         { int j13 = (j12 + jinc) % jmax;
/* 1447 */                           int j14 = (j13 + jinc) % jmax;
/* 1448 */                           int j15 = (j14 + jinc) % jmax;
/*      */ 
/*      */                           
/* 1451 */                           if (ifac == 16)
/* 1452 */                             pfa16a(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12, j13, j14, j15);  }  }  } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1460 */     }  } private static void pfa2a(int n1, float[][] z, int mu, int m, int j0, int j1) { int m1 = 2 * n1;
/* 1461 */     for (int i = 0; i < m; i++) {
/* 1462 */       float[] zj0 = z[j0];
/* 1463 */       float[] zj1 = z[j1];
/* 1464 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1465 */         float t1r = zj0[i1] - zj1[i1];
/* 1466 */         float t1i = zj0[i1 + 1] - zj1[i1 + 1];
/* 1467 */         zj0[i1] = zj0[i1] + zj1[i1];
/* 1468 */         zj0[i1 + 1] = zj0[i1 + 1] + zj1[i1 + 1];
/* 1469 */         zj1[i1] = t1r;
/* 1470 */         zj1[i1 + 1] = t1i;
/*      */       } 
/* 1472 */       int jt = j1 + 1;
/* 1473 */       j1 = j0 + 1;
/* 1474 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */   
/*      */   private static void pfa3a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2) {
/*      */     float c1;
/* 1480 */     int m1 = 2 * n1;
/*      */     
/* 1482 */     if (mu == 1) {
/* 1483 */       c1 = 0.8660254F;
/*      */     } else {
/* 1485 */       c1 = -0.8660254F;
/*      */     } 
/* 1487 */     for (int i = 0; i < m; i++) {
/* 1488 */       float[] zj0 = z[j0];
/* 1489 */       float[] zj1 = z[j1];
/* 1490 */       float[] zj2 = z[j2];
/* 1491 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1492 */         float t1r = zj1[i1] + zj2[i1];
/* 1493 */         float t1i = zj1[i1 + 1] + zj2[i1 + 1];
/* 1494 */         float y1r = zj0[i1] - 0.5F * t1r;
/* 1495 */         float y1i = zj0[i1 + 1] - 0.5F * t1i;
/* 1496 */         float y2r = c1 * (zj1[i1] - zj2[i1]);
/* 1497 */         float y2i = c1 * (zj1[i1 + 1] - zj2[i1 + 1]);
/* 1498 */         zj0[i1] = zj0[i1] + t1r;
/* 1499 */         zj0[i1 + 1] = zj0[i1 + 1] + t1i;
/* 1500 */         zj1[i1] = y1r - y2i;
/* 1501 */         zj1[i1 + 1] = y1i + y2r;
/* 1502 */         zj2[i1] = y1r + y2i;
/* 1503 */         zj2[i1 + 1] = y1i - y2r;
/*      */       } 
/* 1505 */       int jt = j2 + 1;
/* 1506 */       j2 = j1 + 1;
/* 1507 */       j1 = j0 + 1;
/* 1508 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa4a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3) {
/*      */     float c1;
/* 1514 */     int m1 = 2 * n1;
/*      */     
/* 1516 */     if (mu == 1) {
/* 1517 */       c1 = 1.0F;
/*      */     } else {
/* 1519 */       c1 = -1.0F;
/*      */     } 
/* 1521 */     for (int i = 0; i < m; i++) {
/* 1522 */       float[] zj0 = z[j0];
/* 1523 */       float[] zj1 = z[j1];
/* 1524 */       float[] zj2 = z[j2];
/* 1525 */       float[] zj3 = z[j3];
/* 1526 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1527 */         float t1r = zj0[i1] + zj2[i1];
/* 1528 */         float t1i = zj0[i1 + 1] + zj2[i1 + 1];
/* 1529 */         float t2r = zj1[i1] + zj3[i1];
/* 1530 */         float t2i = zj1[i1 + 1] + zj3[i1 + 1];
/* 1531 */         float y1r = zj0[i1] - zj2[i1];
/* 1532 */         float y1i = zj0[i1 + 1] - zj2[i1 + 1];
/* 1533 */         float y3r = c1 * (zj1[i1] - zj3[i1]);
/* 1534 */         float y3i = c1 * (zj1[i1 + 1] - zj3[i1 + 1]);
/* 1535 */         zj0[i1] = t1r + t2r;
/* 1536 */         zj0[i1 + 1] = t1i + t2i;
/* 1537 */         zj1[i1] = y1r - y3i;
/* 1538 */         zj1[i1 + 1] = y1i + y3r;
/* 1539 */         zj2[i1] = t1r - t2r;
/* 1540 */         zj2[i1 + 1] = t1i - t2i;
/* 1541 */         zj3[i1] = y1r + y3i;
/* 1542 */         zj3[i1 + 1] = y1i - y3r;
/*      */       } 
/* 1544 */       int jt = j3 + 1;
/* 1545 */       j3 = j2 + 1;
/* 1546 */       j2 = j1 + 1;
/* 1547 */       j1 = j0 + 1;
/* 1548 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa5a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4) {
/*      */     float c1, c2, c3;
/* 1554 */     int m1 = 2 * n1;
/*      */     
/* 1556 */     if (mu == 1) {
/* 1557 */       c1 = 0.559017F;
/* 1558 */       c2 = 0.95105654F;
/* 1559 */       c3 = 0.58778524F;
/* 1560 */     } else if (mu == 2) {
/* 1561 */       c1 = -0.559017F;
/* 1562 */       c2 = 0.58778524F;
/* 1563 */       c3 = -0.95105654F;
/* 1564 */     } else if (mu == 3) {
/* 1565 */       c1 = -0.559017F;
/* 1566 */       c2 = -0.58778524F;
/* 1567 */       c3 = 0.95105654F;
/*      */     } else {
/* 1569 */       c1 = 0.559017F;
/* 1570 */       c2 = -0.95105654F;
/* 1571 */       c3 = -0.58778524F;
/*      */     } 
/* 1573 */     for (int i = 0; i < m; i++) {
/* 1574 */       float[] zj0 = z[j0];
/* 1575 */       float[] zj1 = z[j1];
/* 1576 */       float[] zj2 = z[j2];
/* 1577 */       float[] zj3 = z[j3];
/* 1578 */       float[] zj4 = z[j4];
/* 1579 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1580 */         float t1r = zj1[i1] + zj4[i1];
/* 1581 */         float t1i = zj1[i1 + 1] + zj4[i1 + 1];
/* 1582 */         float t2r = zj2[i1] + zj3[i1];
/* 1583 */         float t2i = zj2[i1 + 1] + zj3[i1 + 1];
/* 1584 */         float t3r = zj1[i1] - zj4[i1];
/* 1585 */         float t3i = zj1[i1 + 1] - zj4[i1 + 1];
/* 1586 */         float t4r = zj2[i1] - zj3[i1];
/* 1587 */         float t4i = zj2[i1 + 1] - zj3[i1 + 1];
/* 1588 */         float t5r = t1r + t2r;
/* 1589 */         float t5i = t1i + t2i;
/* 1590 */         float t6r = c1 * (t1r - t2r);
/* 1591 */         float t6i = c1 * (t1i - t2i);
/* 1592 */         float t7r = zj0[i1] - 0.25F * t5r;
/* 1593 */         float t7i = zj0[i1 + 1] - 0.25F * t5i;
/* 1594 */         float y1r = t7r + t6r;
/* 1595 */         float y1i = t7i + t6i;
/* 1596 */         float y2r = t7r - t6r;
/* 1597 */         float y2i = t7i - t6i;
/* 1598 */         float y3r = c3 * t3r - c2 * t4r;
/* 1599 */         float y3i = c3 * t3i - c2 * t4i;
/* 1600 */         float y4r = c2 * t3r + c3 * t4r;
/* 1601 */         float y4i = c2 * t3i + c3 * t4i;
/* 1602 */         zj0[i1] = zj0[i1] + t5r;
/* 1603 */         zj0[i1 + 1] = zj0[i1 + 1] + t5i;
/* 1604 */         zj1[i1] = y1r - y4i;
/* 1605 */         zj1[i1 + 1] = y1i + y4r;
/* 1606 */         zj2[i1] = y2r - y3i;
/* 1607 */         zj2[i1 + 1] = y2i + y3r;
/* 1608 */         zj3[i1] = y2r + y3i;
/* 1609 */         zj3[i1 + 1] = y2i - y3r;
/* 1610 */         zj4[i1] = y1r + y4i;
/* 1611 */         zj4[i1 + 1] = y1i - y4r;
/*      */       } 
/* 1613 */       int jt = j4 + 1;
/* 1614 */       j4 = j3 + 1;
/* 1615 */       j3 = j2 + 1;
/* 1616 */       j2 = j1 + 1;
/* 1617 */       j1 = j0 + 1;
/* 1618 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa7a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6) {
/*      */     float c1, c2, c3, c4, c5, c6;
/* 1624 */     int m1 = 2 * n1;
/*      */     
/* 1626 */     if (mu == 1) {
/* 1627 */       c1 = 0.6234898F;
/* 1628 */       c2 = -0.22252093F;
/* 1629 */       c3 = -0.90096885F;
/* 1630 */       c4 = 0.7818315F;
/* 1631 */       c5 = 0.9749279F;
/* 1632 */       c6 = 0.43388373F;
/* 1633 */     } else if (mu == 2) {
/* 1634 */       c1 = -0.22252093F;
/* 1635 */       c2 = -0.90096885F;
/* 1636 */       c3 = 0.6234898F;
/* 1637 */       c4 = 0.9749279F;
/* 1638 */       c5 = -0.43388373F;
/* 1639 */       c6 = -0.7818315F;
/* 1640 */     } else if (mu == 3) {
/* 1641 */       c1 = -0.90096885F;
/* 1642 */       c2 = 0.6234898F;
/* 1643 */       c3 = -0.22252093F;
/* 1644 */       c4 = 0.43388373F;
/* 1645 */       c5 = -0.7818315F;
/* 1646 */       c6 = 0.9749279F;
/* 1647 */     } else if (mu == 4) {
/* 1648 */       c1 = -0.90096885F;
/* 1649 */       c2 = 0.6234898F;
/* 1650 */       c3 = -0.22252093F;
/* 1651 */       c4 = -0.43388373F;
/* 1652 */       c5 = 0.7818315F;
/* 1653 */       c6 = -0.9749279F;
/* 1654 */     } else if (mu == 5) {
/* 1655 */       c1 = -0.22252093F;
/* 1656 */       c2 = -0.90096885F;
/* 1657 */       c3 = 0.6234898F;
/* 1658 */       c4 = -0.9749279F;
/* 1659 */       c5 = 0.43388373F;
/* 1660 */       c6 = 0.7818315F;
/*      */     } else {
/* 1662 */       c1 = 0.6234898F;
/* 1663 */       c2 = -0.22252093F;
/* 1664 */       c3 = -0.90096885F;
/* 1665 */       c4 = -0.7818315F;
/* 1666 */       c5 = -0.9749279F;
/* 1667 */       c6 = -0.43388373F;
/*      */     } 
/* 1669 */     for (int i = 0; i < m; i++) {
/* 1670 */       float[] zj0 = z[j0];
/* 1671 */       float[] zj1 = z[j1];
/* 1672 */       float[] zj2 = z[j2];
/* 1673 */       float[] zj3 = z[j3];
/* 1674 */       float[] zj4 = z[j4];
/* 1675 */       float[] zj5 = z[j5];
/* 1676 */       float[] zj6 = z[j6];
/* 1677 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1678 */         float t1r = zj1[i1] + zj6[i1];
/* 1679 */         float t1i = zj1[i1 + 1] + zj6[i1 + 1];
/* 1680 */         float t2r = zj2[i1] + zj5[i1];
/* 1681 */         float t2i = zj2[i1 + 1] + zj5[i1 + 1];
/* 1682 */         float t3r = zj3[i1] + zj4[i1];
/* 1683 */         float t3i = zj3[i1 + 1] + zj4[i1 + 1];
/* 1684 */         float t4r = zj1[i1] - zj6[i1];
/* 1685 */         float t4i = zj1[i1 + 1] - zj6[i1 + 1];
/* 1686 */         float t5r = zj2[i1] - zj5[i1];
/* 1687 */         float t5i = zj2[i1 + 1] - zj5[i1 + 1];
/* 1688 */         float t6r = zj3[i1] - zj4[i1];
/* 1689 */         float t6i = zj3[i1 + 1] - zj4[i1 + 1];
/* 1690 */         float t7r = zj0[i1] - 0.5F * t3r;
/* 1691 */         float t7i = zj0[i1 + 1] - 0.5F * t3i;
/* 1692 */         float t8r = t1r - t3r;
/* 1693 */         float t8i = t1i - t3i;
/* 1694 */         float t9r = t2r - t3r;
/* 1695 */         float t9i = t2i - t3i;
/* 1696 */         float y1r = t7r + c1 * t8r + c2 * t9r;
/* 1697 */         float y1i = t7i + c1 * t8i + c2 * t9i;
/* 1698 */         float y2r = t7r + c2 * t8r + c3 * t9r;
/* 1699 */         float y2i = t7i + c2 * t8i + c3 * t9i;
/* 1700 */         float y3r = t7r + c3 * t8r + c1 * t9r;
/* 1701 */         float y3i = t7i + c3 * t8i + c1 * t9i;
/* 1702 */         float y4r = c6 * t4r - c4 * t5r + c5 * t6r;
/* 1703 */         float y4i = c6 * t4i - c4 * t5i + c5 * t6i;
/* 1704 */         float y5r = c5 * t4r - c6 * t5r - c4 * t6r;
/* 1705 */         float y5i = c5 * t4i - c6 * t5i - c4 * t6i;
/* 1706 */         float y6r = c4 * t4r + c5 * t5r + c6 * t6r;
/* 1707 */         float y6i = c4 * t4i + c5 * t5i + c6 * t6i;
/* 1708 */         zj0[i1] = zj0[i1] + t1r + t2r + t3r;
/* 1709 */         zj0[i1 + 1] = zj0[i1 + 1] + t1i + t2i + t3i;
/* 1710 */         zj1[i1] = y1r - y6i;
/* 1711 */         zj1[i1 + 1] = y1i + y6r;
/* 1712 */         zj2[i1] = y2r - y5i;
/* 1713 */         zj2[i1 + 1] = y2i + y5r;
/* 1714 */         zj3[i1] = y3r - y4i;
/* 1715 */         zj3[i1 + 1] = y3i + y4r;
/* 1716 */         zj4[i1] = y3r + y4i;
/* 1717 */         zj4[i1 + 1] = y3i - y4r;
/* 1718 */         zj5[i1] = y2r + y5i;
/* 1719 */         zj5[i1 + 1] = y2i - y5r;
/* 1720 */         zj6[i1] = y1r + y6i;
/* 1721 */         zj6[i1 + 1] = y1i - y6r;
/*      */       } 
/* 1723 */       int jt = j6 + 1;
/* 1724 */       j6 = j5 + 1;
/* 1725 */       j5 = j4 + 1;
/* 1726 */       j4 = j3 + 1;
/* 1727 */       j3 = j2 + 1;
/* 1728 */       j2 = j1 + 1;
/* 1729 */       j1 = j0 + 1;
/* 1730 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa8a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7) {
/*      */     float c1, c2;
/* 1736 */     int m1 = 2 * n1;
/*      */     
/* 1738 */     if (mu == 1) {
/* 1739 */       c1 = 1.0F;
/* 1740 */       c2 = 0.70710677F;
/* 1741 */     } else if (mu == 3) {
/* 1742 */       c1 = -1.0F;
/* 1743 */       c2 = -0.70710677F;
/* 1744 */     } else if (mu == 5) {
/* 1745 */       c1 = 1.0F;
/* 1746 */       c2 = -0.70710677F;
/*      */     } else {
/* 1748 */       c1 = -1.0F;
/* 1749 */       c2 = 0.70710677F;
/*      */     } 
/* 1751 */     float c3 = c1 * c2;
/* 1752 */     for (int i = 0; i < m; i++) {
/* 1753 */       float[] zj0 = z[j0];
/* 1754 */       float[] zj1 = z[j1];
/* 1755 */       float[] zj2 = z[j2];
/* 1756 */       float[] zj3 = z[j3];
/* 1757 */       float[] zj4 = z[j4];
/* 1758 */       float[] zj5 = z[j5];
/* 1759 */       float[] zj6 = z[j6];
/* 1760 */       float[] zj7 = z[j7];
/* 1761 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1762 */         float t1r = zj0[i1] + zj4[i1];
/* 1763 */         float t1i = zj0[i1 + 1] + zj4[i1 + 1];
/* 1764 */         float t2r = zj0[i1] - zj4[i1];
/* 1765 */         float t2i = zj0[i1 + 1] - zj4[i1 + 1];
/* 1766 */         float t3r = zj1[i1] + zj5[i1];
/* 1767 */         float t3i = zj1[i1 + 1] + zj5[i1 + 1];
/* 1768 */         float t4r = zj1[i1] - zj5[i1];
/* 1769 */         float t4i = zj1[i1 + 1] - zj5[i1 + 1];
/* 1770 */         float t5r = zj2[i1] + zj6[i1];
/* 1771 */         float t5i = zj2[i1 + 1] + zj6[i1 + 1];
/* 1772 */         float t6r = c1 * (zj2[i1] - zj6[i1]);
/* 1773 */         float t6i = c1 * (zj2[i1 + 1] - zj6[i1 + 1]);
/* 1774 */         float t7r = zj3[i1] + zj7[i1];
/* 1775 */         float t7i = zj3[i1 + 1] + zj7[i1 + 1];
/* 1776 */         float t8r = zj3[i1] - zj7[i1];
/* 1777 */         float t8i = zj3[i1 + 1] - zj7[i1 + 1];
/* 1778 */         float t9r = t1r + t5r;
/* 1779 */         float t9i = t1i + t5i;
/* 1780 */         float t10r = t3r + t7r;
/* 1781 */         float t10i = t3i + t7i;
/* 1782 */         float t11r = c2 * (t4r - t8r);
/* 1783 */         float t11i = c2 * (t4i - t8i);
/* 1784 */         float t12r = c3 * (t4r + t8r);
/* 1785 */         float t12i = c3 * (t4i + t8i);
/* 1786 */         float y1r = t2r + t11r;
/* 1787 */         float y1i = t2i + t11i;
/* 1788 */         float y2r = t1r - t5r;
/* 1789 */         float y2i = t1i - t5i;
/* 1790 */         float y3r = t2r - t11r;
/* 1791 */         float y3i = t2i - t11i;
/* 1792 */         float y5r = t12r - t6r;
/* 1793 */         float y5i = t12i - t6i;
/* 1794 */         float y6r = c1 * (t3r - t7r);
/* 1795 */         float y6i = c1 * (t3i - t7i);
/* 1796 */         float y7r = t12r + t6r;
/* 1797 */         float y7i = t12i + t6i;
/* 1798 */         zj0[i1] = t9r + t10r;
/* 1799 */         zj0[i1 + 1] = t9i + t10i;
/* 1800 */         zj1[i1] = y1r - y7i;
/* 1801 */         zj1[i1 + 1] = y1i + y7r;
/* 1802 */         zj2[i1] = y2r - y6i;
/* 1803 */         zj2[i1 + 1] = y2i + y6r;
/* 1804 */         zj3[i1] = y3r - y5i;
/* 1805 */         zj3[i1 + 1] = y3i + y5r;
/* 1806 */         zj4[i1] = t9r - t10r;
/* 1807 */         zj4[i1 + 1] = t9i - t10i;
/* 1808 */         zj5[i1] = y3r + y5i;
/* 1809 */         zj5[i1 + 1] = y3i - y5r;
/* 1810 */         zj6[i1] = y2r + y6i;
/* 1811 */         zj6[i1 + 1] = y2i - y6r;
/* 1812 */         zj7[i1] = y1r + y7i;
/* 1813 */         zj7[i1 + 1] = y1i - y7r;
/*      */       } 
/* 1815 */       int jt = j7 + 1;
/* 1816 */       j7 = j6 + 1;
/* 1817 */       j6 = j5 + 1;
/* 1818 */       j5 = j4 + 1;
/* 1819 */       j4 = j3 + 1;
/* 1820 */       j3 = j2 + 1;
/* 1821 */       j2 = j1 + 1;
/* 1822 */       j1 = j0 + 1;
/* 1823 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa9a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8) {
/*      */     float c1, c2, c3, c4, c5;
/* 1829 */     int m1 = 2 * n1;
/*      */     
/* 1831 */     if (mu == 1) {
/* 1832 */       c1 = 0.8660254F;
/* 1833 */       c2 = 0.76604444F;
/* 1834 */       c3 = 0.64278764F;
/* 1835 */       c4 = 0.17364818F;
/* 1836 */       c5 = 0.9848077F;
/* 1837 */     } else if (mu == 2) {
/* 1838 */       c1 = -0.8660254F;
/* 1839 */       c2 = 0.17364818F;
/* 1840 */       c3 = 0.9848077F;
/* 1841 */       c4 = -0.9396926F;
/* 1842 */       c5 = 0.34202015F;
/* 1843 */     } else if (mu == 4) {
/* 1844 */       c1 = 0.8660254F;
/* 1845 */       c2 = -0.9396926F;
/* 1846 */       c3 = 0.34202015F;
/* 1847 */       c4 = 0.76604444F;
/* 1848 */       c5 = -0.64278764F;
/* 1849 */     } else if (mu == 5) {
/* 1850 */       c1 = -0.8660254F;
/* 1851 */       c2 = -0.9396926F;
/* 1852 */       c3 = -0.34202015F;
/* 1853 */       c4 = 0.76604444F;
/* 1854 */       c5 = 0.64278764F;
/* 1855 */     } else if (mu == 7) {
/* 1856 */       c1 = 0.8660254F;
/* 1857 */       c2 = 0.17364818F;
/* 1858 */       c3 = -0.9848077F;
/* 1859 */       c4 = -0.9396926F;
/* 1860 */       c5 = -0.34202015F;
/*      */     } else {
/* 1862 */       c1 = -0.8660254F;
/* 1863 */       c2 = 0.76604444F;
/* 1864 */       c3 = -0.64278764F;
/* 1865 */       c4 = 0.17364818F;
/* 1866 */       c5 = -0.9848077F;
/*      */     } 
/* 1868 */     float c6 = c1 * c2;
/* 1869 */     float c7 = c1 * c3;
/* 1870 */     float c8 = c1 * c4;
/* 1871 */     float c9 = c1 * c5;
/* 1872 */     for (int i = 0; i < m; i++) {
/* 1873 */       float[] zj0 = z[j0];
/* 1874 */       float[] zj1 = z[j1];
/* 1875 */       float[] zj2 = z[j2];
/* 1876 */       float[] zj3 = z[j3];
/* 1877 */       float[] zj4 = z[j4];
/* 1878 */       float[] zj5 = z[j5];
/* 1879 */       float[] zj6 = z[j6];
/* 1880 */       float[] zj7 = z[j7];
/* 1881 */       float[] zj8 = z[j8];
/* 1882 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 1883 */         float t1r = zj3[i1] + zj6[i1];
/* 1884 */         float t1i = zj3[i1 + 1] + zj6[i1 + 1];
/* 1885 */         float t2r = zj0[i1] - 0.5F * t1r;
/* 1886 */         float t2i = zj0[i1 + 1] - 0.5F * t1i;
/* 1887 */         float t3r = c1 * (zj3[i1] - zj6[i1]);
/* 1888 */         float t3i = c1 * (zj3[i1 + 1] - zj6[i1 + 1]);
/* 1889 */         float t4r = zj0[i1] + t1r;
/* 1890 */         float t4i = zj0[i1 + 1] + t1i;
/* 1891 */         float t5r = zj4[i1] + zj7[i1];
/* 1892 */         float t5i = zj4[i1 + 1] + zj7[i1 + 1];
/* 1893 */         float t6r = zj1[i1] - 0.5F * t5r;
/* 1894 */         float t6i = zj1[i1 + 1] - 0.5F * t5i;
/* 1895 */         float t7r = zj4[i1] - zj7[i1];
/* 1896 */         float t7i = zj4[i1 + 1] - zj7[i1 + 1];
/* 1897 */         float t8r = zj1[i1] + t5r;
/* 1898 */         float t8i = zj1[i1 + 1] + t5i;
/* 1899 */         float t9r = zj2[i1] + zj5[i1];
/* 1900 */         float t9i = zj2[i1 + 1] + zj5[i1 + 1];
/* 1901 */         float t10r = zj8[i1] - 0.5F * t9r;
/* 1902 */         float t10i = zj8[i1 + 1] - 0.5F * t9i;
/* 1903 */         float t11r = zj2[i1] - zj5[i1];
/* 1904 */         float t11i = zj2[i1 + 1] - zj5[i1 + 1];
/* 1905 */         float t12r = zj8[i1] + t9r;
/* 1906 */         float t12i = zj8[i1 + 1] + t9i;
/* 1907 */         float t13r = t8r + t12r;
/* 1908 */         float t13i = t8i + t12i;
/* 1909 */         float t14r = t6r + t10r;
/* 1910 */         float t14i = t6i + t10i;
/* 1911 */         float t15r = t6r - t10r;
/* 1912 */         float t15i = t6i - t10i;
/* 1913 */         float t16r = t7r + t11r;
/* 1914 */         float t16i = t7i + t11i;
/* 1915 */         float t17r = t7r - t11r;
/* 1916 */         float t17i = t7i - t11i;
/* 1917 */         float t18r = c2 * t14r - c7 * t17r;
/* 1918 */         float t18i = c2 * t14i - c7 * t17i;
/* 1919 */         float t19r = c4 * t14r + c9 * t17r;
/* 1920 */         float t19i = c4 * t14i + c9 * t17i;
/* 1921 */         float t20r = c3 * t15r + c6 * t16r;
/* 1922 */         float t20i = c3 * t15i + c6 * t16i;
/* 1923 */         float t21r = c5 * t15r - c8 * t16r;
/* 1924 */         float t21i = c5 * t15i - c8 * t16i;
/* 1925 */         float t22r = t18r + t19r;
/* 1926 */         float t22i = t18i + t19i;
/* 1927 */         float t23r = t20r - t21r;
/* 1928 */         float t23i = t20i - t21i;
/* 1929 */         float y1r = t2r + t18r;
/* 1930 */         float y1i = t2i + t18i;
/* 1931 */         float y2r = t2r + t19r;
/* 1932 */         float y2i = t2i + t19i;
/* 1933 */         float y3r = t4r - 0.5F * t13r;
/* 1934 */         float y3i = t4i - 0.5F * t13i;
/* 1935 */         float y4r = t2r - t22r;
/* 1936 */         float y4i = t2i - t22i;
/* 1937 */         float y5r = t3r - t23r;
/* 1938 */         float y5i = t3i - t23i;
/* 1939 */         float y6r = c1 * (t8r - t12r);
/* 1940 */         float y6i = c1 * (t8i - t12i);
/* 1941 */         float y7r = t21r - t3r;
/* 1942 */         float y7i = t21i - t3i;
/* 1943 */         float y8r = t3r + t20r;
/* 1944 */         float y8i = t3i + t20i;
/* 1945 */         zj0[i1] = t4r + t13r;
/* 1946 */         zj0[i1 + 1] = t4i + t13i;
/* 1947 */         zj1[i1] = y1r - y8i;
/* 1948 */         zj1[i1 + 1] = y1i + y8r;
/* 1949 */         zj2[i1] = y2r - y7i;
/* 1950 */         zj2[i1 + 1] = y2i + y7r;
/* 1951 */         zj3[i1] = y3r - y6i;
/* 1952 */         zj3[i1 + 1] = y3i + y6r;
/* 1953 */         zj4[i1] = y4r - y5i;
/* 1954 */         zj4[i1 + 1] = y4i + y5r;
/* 1955 */         zj5[i1] = y4r + y5i;
/* 1956 */         zj5[i1 + 1] = y4i - y5r;
/* 1957 */         zj6[i1] = y3r + y6i;
/* 1958 */         zj6[i1 + 1] = y3i - y6r;
/* 1959 */         zj7[i1] = y2r + y7i;
/* 1960 */         zj7[i1 + 1] = y2i - y7r;
/* 1961 */         zj8[i1] = y1r + y8i;
/* 1962 */         zj8[i1 + 1] = y1i - y8r;
/*      */       } 
/* 1964 */       int jt = j8 + 1;
/* 1965 */       j8 = j7 + 1;
/* 1966 */       j7 = j6 + 1;
/* 1967 */       j6 = j5 + 1;
/* 1968 */       j5 = j4 + 1;
/* 1969 */       j4 = j3 + 1;
/* 1970 */       j3 = j2 + 1;
/* 1971 */       j2 = j1 + 1;
/* 1972 */       j1 = j0 + 1;
/* 1973 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void pfa11a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10) {
/*      */     float c1, c2, c3, c4, c5, c6, c7, c8, c9, c10;
/* 1980 */     int m1 = 2 * n1;
/*      */     
/* 1982 */     if (mu == 1) {
/* 1983 */       c1 = 0.8412535F;
/* 1984 */       c2 = 0.41541502F;
/* 1985 */       c3 = -0.14231484F;
/* 1986 */       c4 = -0.65486073F;
/* 1987 */       c5 = -0.959493F;
/* 1988 */       c6 = 0.54064083F;
/* 1989 */       c7 = 0.90963197F;
/* 1990 */       c8 = 0.98982143F;
/* 1991 */       c9 = 0.7557496F;
/* 1992 */       c10 = 0.28173256F;
/* 1993 */     } else if (mu == 2) {
/* 1994 */       c1 = 0.41541502F;
/* 1995 */       c2 = -0.65486073F;
/* 1996 */       c3 = -0.959493F;
/* 1997 */       c4 = -0.14231484F;
/* 1998 */       c5 = 0.8412535F;
/* 1999 */       c6 = 0.90963197F;
/* 2000 */       c7 = 0.7557496F;
/* 2001 */       c8 = -0.28173256F;
/* 2002 */       c9 = -0.98982143F;
/* 2003 */       c10 = -0.54064083F;
/* 2004 */     } else if (mu == 3) {
/* 2005 */       c1 = -0.14231484F;
/* 2006 */       c2 = -0.959493F;
/* 2007 */       c3 = 0.41541502F;
/* 2008 */       c4 = 0.8412535F;
/* 2009 */       c5 = -0.65486073F;
/* 2010 */       c6 = 0.98982143F;
/* 2011 */       c7 = -0.28173256F;
/* 2012 */       c8 = -0.90963197F;
/* 2013 */       c9 = 0.54064083F;
/* 2014 */       c10 = 0.7557496F;
/* 2015 */     } else if (mu == 4) {
/* 2016 */       c1 = -0.65486073F;
/* 2017 */       c2 = -0.14231484F;
/* 2018 */       c3 = 0.8412535F;
/* 2019 */       c4 = -0.959493F;
/* 2020 */       c5 = 0.41541502F;
/* 2021 */       c6 = 0.7557496F;
/* 2022 */       c7 = -0.98982143F;
/* 2023 */       c8 = 0.54064083F;
/* 2024 */       c9 = 0.28173256F;
/* 2025 */       c10 = -0.90963197F;
/* 2026 */     } else if (mu == 5) {
/* 2027 */       c1 = -0.959493F;
/* 2028 */       c2 = 0.8412535F;
/* 2029 */       c3 = -0.65486073F;
/* 2030 */       c4 = 0.41541502F;
/* 2031 */       c5 = -0.14231484F;
/* 2032 */       c6 = 0.28173256F;
/* 2033 */       c7 = -0.54064083F;
/* 2034 */       c8 = 0.7557496F;
/* 2035 */       c9 = -0.90963197F;
/* 2036 */       c10 = 0.98982143F;
/* 2037 */     } else if (mu == 6) {
/* 2038 */       c1 = -0.959493F;
/* 2039 */       c2 = 0.8412535F;
/* 2040 */       c3 = -0.65486073F;
/* 2041 */       c4 = 0.41541502F;
/* 2042 */       c5 = -0.14231484F;
/* 2043 */       c6 = -0.28173256F;
/* 2044 */       c7 = 0.54064083F;
/* 2045 */       c8 = -0.7557496F;
/* 2046 */       c9 = 0.90963197F;
/* 2047 */       c10 = -0.98982143F;
/* 2048 */     } else if (mu == 7) {
/* 2049 */       c1 = -0.65486073F;
/* 2050 */       c2 = -0.14231484F;
/* 2051 */       c3 = 0.8412535F;
/* 2052 */       c4 = -0.959493F;
/* 2053 */       c5 = 0.41541502F;
/* 2054 */       c6 = -0.7557496F;
/* 2055 */       c7 = 0.98982143F;
/* 2056 */       c8 = -0.54064083F;
/* 2057 */       c9 = -0.28173256F;
/* 2058 */       c10 = 0.90963197F;
/* 2059 */     } else if (mu == 8) {
/* 2060 */       c1 = -0.14231484F;
/* 2061 */       c2 = -0.959493F;
/* 2062 */       c3 = 0.41541502F;
/* 2063 */       c4 = 0.8412535F;
/* 2064 */       c5 = -0.65486073F;
/* 2065 */       c6 = -0.98982143F;
/* 2066 */       c7 = 0.28173256F;
/* 2067 */       c8 = 0.90963197F;
/* 2068 */       c9 = -0.54064083F;
/* 2069 */       c10 = -0.7557496F;
/* 2070 */     } else if (mu == 9) {
/* 2071 */       c1 = 0.41541502F;
/* 2072 */       c2 = -0.65486073F;
/* 2073 */       c3 = -0.959493F;
/* 2074 */       c4 = -0.14231484F;
/* 2075 */       c5 = 0.8412535F;
/* 2076 */       c6 = -0.90963197F;
/* 2077 */       c7 = -0.7557496F;
/* 2078 */       c8 = 0.28173256F;
/* 2079 */       c9 = 0.98982143F;
/* 2080 */       c10 = 0.54064083F;
/*      */     } else {
/* 2082 */       c1 = 0.8412535F;
/* 2083 */       c2 = 0.41541502F;
/* 2084 */       c3 = -0.14231484F;
/* 2085 */       c4 = -0.65486073F;
/* 2086 */       c5 = -0.959493F;
/* 2087 */       c6 = -0.54064083F;
/* 2088 */       c7 = -0.90963197F;
/* 2089 */       c8 = -0.98982143F;
/* 2090 */       c9 = -0.7557496F;
/* 2091 */       c10 = -0.28173256F;
/*      */     } 
/* 2093 */     for (int i = 0; i < m; i++) {
/* 2094 */       float[] zj0 = z[j0];
/* 2095 */       float[] zj1 = z[j1];
/* 2096 */       float[] zj2 = z[j2];
/* 2097 */       float[] zj3 = z[j3];
/* 2098 */       float[] zj4 = z[j4];
/* 2099 */       float[] zj5 = z[j5];
/* 2100 */       float[] zj6 = z[j6];
/* 2101 */       float[] zj7 = z[j7];
/* 2102 */       float[] zj8 = z[j8];
/* 2103 */       float[] zj9 = z[j9];
/* 2104 */       float[] zj10 = z[j10];
/* 2105 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 2106 */         float t1r = zj1[i1] + zj10[i1];
/* 2107 */         float t1i = zj1[i1 + 1] + zj10[i1 + 1];
/* 2108 */         float t2r = zj2[i1] + zj9[i1];
/* 2109 */         float t2i = zj2[i1 + 1] + zj9[i1 + 1];
/* 2110 */         float t3r = zj3[i1] + zj8[i1];
/* 2111 */         float t3i = zj3[i1 + 1] + zj8[i1 + 1];
/* 2112 */         float t4r = zj4[i1] + zj7[i1];
/* 2113 */         float t4i = zj4[i1 + 1] + zj7[i1 + 1];
/* 2114 */         float t5r = zj5[i1] + zj6[i1];
/* 2115 */         float t5i = zj5[i1 + 1] + zj6[i1 + 1];
/* 2116 */         float t6r = zj1[i1] - zj10[i1];
/* 2117 */         float t6i = zj1[i1 + 1] - zj10[i1 + 1];
/* 2118 */         float t7r = zj2[i1] - zj9[i1];
/* 2119 */         float t7i = zj2[i1 + 1] - zj9[i1 + 1];
/* 2120 */         float t8r = zj3[i1] - zj8[i1];
/* 2121 */         float t8i = zj3[i1 + 1] - zj8[i1 + 1];
/* 2122 */         float t9r = zj4[i1] - zj7[i1];
/* 2123 */         float t9i = zj4[i1 + 1] - zj7[i1 + 1];
/* 2124 */         float t10r = zj5[i1] - zj6[i1];
/* 2125 */         float t10i = zj5[i1 + 1] - zj6[i1 + 1];
/* 2126 */         float t11r = zj0[i1] - 0.5F * t5r;
/* 2127 */         float t11i = zj0[i1 + 1] - 0.5F * t5i;
/* 2128 */         float t12r = t1r - t5r;
/* 2129 */         float t12i = t1i - t5i;
/* 2130 */         float t13r = t2r - t5r;
/* 2131 */         float t13i = t2i - t5i;
/* 2132 */         float t14r = t3r - t5r;
/* 2133 */         float t14i = t3i - t5i;
/* 2134 */         float t15r = t4r - t5r;
/* 2135 */         float t15i = t4i - t5i;
/* 2136 */         float y1r = t11r + c1 * t12r + c2 * t13r + c3 * t14r + c4 * t15r;
/* 2137 */         float y1i = t11i + c1 * t12i + c2 * t13i + c3 * t14i + c4 * t15i;
/* 2138 */         float y2r = t11r + c2 * t12r + c4 * t13r + c5 * t14r + c3 * t15r;
/* 2139 */         float y2i = t11i + c2 * t12i + c4 * t13i + c5 * t14i + c3 * t15i;
/* 2140 */         float y3r = t11r + c3 * t12r + c5 * t13r + c2 * t14r + c1 * t15r;
/* 2141 */         float y3i = t11i + c3 * t12i + c5 * t13i + c2 * t14i + c1 * t15i;
/* 2142 */         float y4r = t11r + c4 * t12r + c3 * t13r + c1 * t14r + c5 * t15r;
/* 2143 */         float y4i = t11i + c4 * t12i + c3 * t13i + c1 * t14i + c5 * t15i;
/* 2144 */         float y5r = t11r + c5 * t12r + c1 * t13r + c4 * t14r + c2 * t15r;
/* 2145 */         float y5i = t11i + c5 * t12i + c1 * t13i + c4 * t14i + c2 * t15i;
/* 2146 */         float y6r = c10 * t6r - c6 * t7r + c9 * t8r - c7 * t9r + c8 * t10r;
/* 2147 */         float y6i = c10 * t6i - c6 * t7i + c9 * t8i - c7 * t9i + c8 * t10i;
/* 2148 */         float y7r = c9 * t6r - c8 * t7r + c6 * t8r + c10 * t9r - c7 * t10r;
/* 2149 */         float y7i = c9 * t6i - c8 * t7i + c6 * t8i + c10 * t9i - c7 * t10i;
/* 2150 */         float y8r = c8 * t6r - c10 * t7r - c7 * t8r + c6 * t9r + c9 * t10r;
/* 2151 */         float y8i = c8 * t6i - c10 * t7i - c7 * t8i + c6 * t9i + c9 * t10i;
/* 2152 */         float y9r = c7 * t6r + c9 * t7r - c10 * t8r - c8 * t9r - c6 * t10r;
/* 2153 */         float y9i = c7 * t6i + c9 * t7i - c10 * t8i - c8 * t9i - c6 * t10i;
/* 2154 */         float y10r = c6 * t6r + c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r;
/* 2155 */         float y10i = c6 * t6i + c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i;
/* 2156 */         zj0[i1] = zj0[i1] + t1r + t2r + t3r + t4r + t5r;
/* 2157 */         zj0[i1 + 1] = zj0[i1 + 1] + t1i + t2i + t3i + t4i + t5i;
/* 2158 */         zj1[i1] = y1r - y10i;
/* 2159 */         zj1[i1 + 1] = y1i + y10r;
/* 2160 */         zj2[i1] = y2r - y9i;
/* 2161 */         zj2[i1 + 1] = y2i + y9r;
/* 2162 */         zj3[i1] = y3r - y8i;
/* 2163 */         zj3[i1 + 1] = y3i + y8r;
/* 2164 */         zj4[i1] = y4r - y7i;
/* 2165 */         zj4[i1 + 1] = y4i + y7r;
/* 2166 */         zj5[i1] = y5r - y6i;
/* 2167 */         zj5[i1 + 1] = y5i + y6r;
/* 2168 */         zj6[i1] = y5r + y6i;
/* 2169 */         zj6[i1 + 1] = y5i - y6r;
/* 2170 */         zj7[i1] = y4r + y7i;
/* 2171 */         zj7[i1 + 1] = y4i - y7r;
/* 2172 */         zj8[i1] = y3r + y8i;
/* 2173 */         zj8[i1 + 1] = y3i - y8r;
/* 2174 */         zj9[i1] = y2r + y9i;
/* 2175 */         zj9[i1 + 1] = y2i - y9r;
/* 2176 */         zj10[i1] = y1r + y10i;
/* 2177 */         zj10[i1 + 1] = y1i - y10r;
/*      */       } 
/* 2179 */       int jt = j10 + 1;
/* 2180 */       j10 = j9 + 1;
/* 2181 */       j9 = j8 + 1;
/* 2182 */       j8 = j7 + 1;
/* 2183 */       j7 = j6 + 1;
/* 2184 */       j6 = j5 + 1;
/* 2185 */       j5 = j4 + 1;
/* 2186 */       j4 = j3 + 1;
/* 2187 */       j3 = j2 + 1;
/* 2188 */       j2 = j1 + 1;
/* 2189 */       j1 = j0 + 1;
/* 2190 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void pfa13a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12) {
/*      */     float c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12;
/* 2197 */     int m1 = 2 * n1;
/*      */     
/* 2199 */     if (mu == 1) {
/* 2200 */       c1 = 0.885456F;
/* 2201 */       c2 = 0.56806475F;
/* 2202 */       c3 = 0.12053668F;
/* 2203 */       c4 = -0.3546049F;
/* 2204 */       c5 = -0.7485107F;
/* 2205 */       c6 = -0.97094184F;
/* 2206 */       c7 = 0.46472317F;
/* 2207 */       c8 = 0.82298386F;
/* 2208 */       c9 = 0.99270886F;
/* 2209 */       c10 = 0.9350162F;
/* 2210 */       c11 = 0.66312265F;
/* 2211 */       c12 = 0.23931566F;
/* 2212 */     } else if (mu == 2) {
/* 2213 */       c1 = 0.56806475F;
/* 2214 */       c2 = -0.3546049F;
/* 2215 */       c3 = -0.97094184F;
/* 2216 */       c4 = -0.7485107F;
/* 2217 */       c5 = 0.12053668F;
/* 2218 */       c6 = 0.885456F;
/* 2219 */       c7 = 0.82298386F;
/* 2220 */       c8 = 0.9350162F;
/* 2221 */       c9 = 0.23931566F;
/* 2222 */       c10 = -0.66312265F;
/* 2223 */       c11 = -0.99270886F;
/* 2224 */       c12 = -0.46472317F;
/* 2225 */     } else if (mu == 3) {
/* 2226 */       c1 = 0.12053668F;
/* 2227 */       c2 = -0.97094184F;
/* 2228 */       c3 = -0.3546049F;
/* 2229 */       c4 = 0.885456F;
/* 2230 */       c5 = 0.56806475F;
/* 2231 */       c6 = -0.7485107F;
/* 2232 */       c7 = 0.99270886F;
/* 2233 */       c8 = 0.23931566F;
/* 2234 */       c9 = -0.9350162F;
/* 2235 */       c10 = -0.46472317F;
/* 2236 */       c11 = 0.82298386F;
/* 2237 */       c12 = 0.66312265F;
/* 2238 */     } else if (mu == 4) {
/* 2239 */       c1 = -0.3546049F;
/* 2240 */       c2 = -0.7485107F;
/* 2241 */       c3 = 0.885456F;
/* 2242 */       c4 = 0.12053668F;
/* 2243 */       c5 = -0.97094184F;
/* 2244 */       c6 = 0.56806475F;
/* 2245 */       c7 = 0.9350162F;
/* 2246 */       c8 = -0.66312265F;
/* 2247 */       c9 = -0.46472317F;
/* 2248 */       c10 = 0.99270886F;
/* 2249 */       c11 = -0.23931566F;
/* 2250 */       c12 = -0.82298386F;
/* 2251 */     } else if (mu == 5) {
/* 2252 */       c1 = -0.7485107F;
/* 2253 */       c2 = 0.12053668F;
/* 2254 */       c3 = 0.56806475F;
/* 2255 */       c4 = -0.97094184F;
/* 2256 */       c5 = 0.885456F;
/* 2257 */       c6 = -0.3546049F;
/* 2258 */       c7 = 0.66312265F;
/* 2259 */       c8 = -0.99270886F;
/* 2260 */       c9 = 0.82298386F;
/* 2261 */       c10 = -0.23931566F;
/* 2262 */       c11 = -0.46472317F;
/* 2263 */       c12 = 0.9350162F;
/* 2264 */     } else if (mu == 6) {
/* 2265 */       c1 = -0.97094184F;
/* 2266 */       c2 = 0.885456F;
/* 2267 */       c3 = -0.7485107F;
/* 2268 */       c4 = 0.56806475F;
/* 2269 */       c5 = -0.3546049F;
/* 2270 */       c6 = 0.12053668F;
/* 2271 */       c7 = 0.23931566F;
/* 2272 */       c8 = -0.46472317F;
/* 2273 */       c9 = 0.66312265F;
/* 2274 */       c10 = -0.82298386F;
/* 2275 */       c11 = 0.9350162F;
/* 2276 */       c12 = -0.99270886F;
/* 2277 */     } else if (mu == 7) {
/* 2278 */       c1 = -0.97094184F;
/* 2279 */       c2 = 0.885456F;
/* 2280 */       c3 = -0.7485107F;
/* 2281 */       c4 = 0.56806475F;
/* 2282 */       c5 = -0.3546049F;
/* 2283 */       c6 = 0.12053668F;
/* 2284 */       c7 = -0.23931566F;
/* 2285 */       c8 = 0.46472317F;
/* 2286 */       c9 = -0.66312265F;
/* 2287 */       c10 = 0.82298386F;
/* 2288 */       c11 = -0.9350162F;
/* 2289 */       c12 = 0.99270886F;
/* 2290 */     } else if (mu == 8) {
/* 2291 */       c1 = -0.7485107F;
/* 2292 */       c2 = 0.12053668F;
/* 2293 */       c3 = 0.56806475F;
/* 2294 */       c4 = -0.97094184F;
/* 2295 */       c5 = 0.885456F;
/* 2296 */       c6 = -0.3546049F;
/* 2297 */       c7 = -0.66312265F;
/* 2298 */       c8 = 0.99270886F;
/* 2299 */       c9 = -0.82298386F;
/* 2300 */       c10 = 0.23931566F;
/* 2301 */       c11 = 0.46472317F;
/* 2302 */       c12 = -0.9350162F;
/* 2303 */     } else if (mu == 9) {
/* 2304 */       c1 = -0.3546049F;
/* 2305 */       c2 = -0.7485107F;
/* 2306 */       c3 = 0.885456F;
/* 2307 */       c4 = 0.12053668F;
/* 2308 */       c5 = -0.97094184F;
/* 2309 */       c6 = 0.56806475F;
/* 2310 */       c7 = -0.9350162F;
/* 2311 */       c8 = 0.66312265F;
/* 2312 */       c9 = 0.46472317F;
/* 2313 */       c10 = -0.99270886F;
/* 2314 */       c11 = 0.23931566F;
/* 2315 */       c12 = 0.82298386F;
/* 2316 */     } else if (mu == 10) {
/* 2317 */       c1 = 0.12053668F;
/* 2318 */       c2 = -0.97094184F;
/* 2319 */       c3 = -0.3546049F;
/* 2320 */       c4 = 0.885456F;
/* 2321 */       c5 = 0.56806475F;
/* 2322 */       c6 = -0.7485107F;
/* 2323 */       c7 = -0.99270886F;
/* 2324 */       c8 = -0.23931566F;
/* 2325 */       c9 = 0.9350162F;
/* 2326 */       c10 = 0.46472317F;
/* 2327 */       c11 = -0.82298386F;
/* 2328 */       c12 = -0.66312265F;
/* 2329 */     } else if (mu == 11) {
/* 2330 */       c1 = 0.56806475F;
/* 2331 */       c2 = -0.3546049F;
/* 2332 */       c3 = -0.97094184F;
/* 2333 */       c4 = -0.7485107F;
/* 2334 */       c5 = 0.12053668F;
/* 2335 */       c6 = 0.885456F;
/* 2336 */       c7 = -0.82298386F;
/* 2337 */       c8 = -0.9350162F;
/* 2338 */       c9 = -0.23931566F;
/* 2339 */       c10 = 0.66312265F;
/* 2340 */       c11 = 0.99270886F;
/* 2341 */       c12 = 0.46472317F;
/*      */     } else {
/* 2343 */       c1 = 0.885456F;
/* 2344 */       c2 = 0.56806475F;
/* 2345 */       c3 = 0.12053668F;
/* 2346 */       c4 = -0.3546049F;
/* 2347 */       c5 = -0.7485107F;
/* 2348 */       c6 = -0.97094184F;
/* 2349 */       c7 = -0.46472317F;
/* 2350 */       c8 = -0.82298386F;
/* 2351 */       c9 = -0.99270886F;
/* 2352 */       c10 = -0.9350162F;
/* 2353 */       c11 = -0.66312265F;
/* 2354 */       c12 = -0.23931566F;
/*      */     } 
/* 2356 */     for (int i = 0; i < m; i++) {
/* 2357 */       float[] zj0 = z[j0];
/* 2358 */       float[] zj1 = z[j1];
/* 2359 */       float[] zj2 = z[j2];
/* 2360 */       float[] zj3 = z[j3];
/* 2361 */       float[] zj4 = z[j4];
/* 2362 */       float[] zj5 = z[j5];
/* 2363 */       float[] zj6 = z[j6];
/* 2364 */       float[] zj7 = z[j7];
/* 2365 */       float[] zj8 = z[j8];
/* 2366 */       float[] zj9 = z[j9];
/* 2367 */       float[] zj10 = z[j10];
/* 2368 */       float[] zj11 = z[j11];
/* 2369 */       float[] zj12 = z[j12];
/* 2370 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 2371 */         float t1r = zj1[i1] + zj12[i1];
/* 2372 */         float t1i = zj1[i1 + 1] + zj12[i1 + 1];
/* 2373 */         float t2r = zj2[i1] + zj11[i1];
/* 2374 */         float t2i = zj2[i1 + 1] + zj11[i1 + 1];
/* 2375 */         float t3r = zj3[i1] + zj10[i1];
/* 2376 */         float t3i = zj3[i1 + 1] + zj10[i1 + 1];
/* 2377 */         float t4r = zj4[i1] + zj9[i1];
/* 2378 */         float t4i = zj4[i1 + 1] + zj9[i1 + 1];
/* 2379 */         float t5r = zj5[i1] + zj8[i1];
/* 2380 */         float t5i = zj5[i1 + 1] + zj8[i1 + 1];
/* 2381 */         float t6r = zj6[i1] + zj7[i1];
/* 2382 */         float t6i = zj6[i1 + 1] + zj7[i1 + 1];
/* 2383 */         float t7r = zj1[i1] - zj12[i1];
/* 2384 */         float t7i = zj1[i1 + 1] - zj12[i1 + 1];
/* 2385 */         float t8r = zj2[i1] - zj11[i1];
/* 2386 */         float t8i = zj2[i1 + 1] - zj11[i1 + 1];
/* 2387 */         float t9r = zj3[i1] - zj10[i1];
/* 2388 */         float t9i = zj3[i1 + 1] - zj10[i1 + 1];
/* 2389 */         float t10r = zj4[i1] - zj9[i1];
/* 2390 */         float t10i = zj4[i1 + 1] - zj9[i1 + 1];
/* 2391 */         float t11r = zj5[i1] - zj8[i1];
/* 2392 */         float t11i = zj5[i1 + 1] - zj8[i1 + 1];
/* 2393 */         float t12r = zj6[i1] - zj7[i1];
/* 2394 */         float t12i = zj6[i1 + 1] - zj7[i1 + 1];
/* 2395 */         float t13r = zj0[i1] - 0.5F * t6r;
/* 2396 */         float t13i = zj0[i1 + 1] - 0.5F * t6i;
/* 2397 */         float t14r = t1r - t6r;
/* 2398 */         float t14i = t1i - t6i;
/* 2399 */         float t15r = t2r - t6r;
/* 2400 */         float t15i = t2i - t6i;
/* 2401 */         float t16r = t3r - t6r;
/* 2402 */         float t16i = t3i - t6i;
/* 2403 */         float t17r = t4r - t6r;
/* 2404 */         float t17i = t4i - t6i;
/* 2405 */         float t18r = t5r - t6r;
/* 2406 */         float t18i = t5i - t6i;
/* 2407 */         float y1r = t13r + c1 * t14r + c2 * t15r + c3 * t16r + c4 * t17r + c5 * t18r;
/* 2408 */         float y1i = t13i + c1 * t14i + c2 * t15i + c3 * t16i + c4 * t17i + c5 * t18i;
/* 2409 */         float y2r = t13r + c2 * t14r + c4 * t15r + c6 * t16r + c5 * t17r + c3 * t18r;
/* 2410 */         float y2i = t13i + c2 * t14i + c4 * t15i + c6 * t16i + c5 * t17i + c3 * t18i;
/* 2411 */         float y3r = t13r + c3 * t14r + c6 * t15r + c4 * t16r + c1 * t17r + c2 * t18r;
/* 2412 */         float y3i = t13i + c3 * t14i + c6 * t15i + c4 * t16i + c1 * t17i + c2 * t18i;
/* 2413 */         float y4r = t13r + c4 * t14r + c5 * t15r + c1 * t16r + c3 * t17r + c6 * t18r;
/* 2414 */         float y4i = t13i + c4 * t14i + c5 * t15i + c1 * t16i + c3 * t17i + c6 * t18i;
/* 2415 */         float y5r = t13r + c5 * t14r + c3 * t15r + c2 * t16r + c6 * t17r + c1 * t18r;
/* 2416 */         float y5i = t13i + c5 * t14i + c3 * t15i + c2 * t16i + c6 * t17i + c1 * t18i;
/* 2417 */         float y6r = t13r + c6 * t14r + c1 * t15r + c5 * t16r + c2 * t17r + c4 * t18r;
/* 2418 */         float y6i = t13i + c6 * t14i + c1 * t15i + c5 * t16i + c2 * t17i + c4 * t18i;
/* 2419 */         float y7r = c12 * t7r - c7 * t8r + c11 * t9r - c8 * t10r + c10 * t11r - c9 * t12r;
/* 2420 */         float y7i = c12 * t7i - c7 * t8i + c11 * t9i - c8 * t10i + c10 * t11i - c9 * t12i;
/* 2421 */         float y8r = c11 * t7r - c9 * t8r + c8 * t9r - c12 * t10r - c7 * t11r + c10 * t12r;
/* 2422 */         float y8i = c11 * t7i - c9 * t8i + c8 * t9i - c12 * t10i - c7 * t11i + c10 * t12i;
/* 2423 */         float y9r = c10 * t7r - c11 * t8r - c7 * t9r + c9 * t10r - c12 * t11r - c8 * t12r;
/* 2424 */         float y9i = c10 * t7i - c11 * t8i - c7 * t9i + c9 * t10i - c12 * t11i - c8 * t12i;
/* 2425 */         float y10r = c9 * t7r + c12 * t8r - c10 * t9r - c7 * t10r + c8 * t11r + c11 * t12r;
/* 2426 */         float y10i = c9 * t7i + c12 * t8i - c10 * t9i - c7 * t10i + c8 * t11i + c11 * t12i;
/* 2427 */         float y11r = c8 * t7r + c10 * t8r + c12 * t9r - c11 * t10r - c9 * t11r - c7 * t12r;
/* 2428 */         float y11i = c8 * t7i + c10 * t8i + c12 * t9i - c11 * t10i - c9 * t11i - c7 * t12i;
/* 2429 */         float y12r = c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r + c11 * t11r + c12 * t12r;
/* 2430 */         float y12i = c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i + c11 * t11i + c12 * t12i;
/* 2431 */         zj0[i1] = zj0[i1] + t1r + t2r + t3r + t4r + t5r + t6r;
/* 2432 */         zj0[i1 + 1] = zj0[i1 + 1] + t1i + t2i + t3i + t4i + t5i + t6i;
/* 2433 */         zj1[i1] = y1r - y12i;
/* 2434 */         zj1[i1 + 1] = y1i + y12r;
/* 2435 */         zj2[i1] = y2r - y11i;
/* 2436 */         zj2[i1 + 1] = y2i + y11r;
/* 2437 */         zj3[i1] = y3r - y10i;
/* 2438 */         zj3[i1 + 1] = y3i + y10r;
/* 2439 */         zj4[i1] = y4r - y9i;
/* 2440 */         zj4[i1 + 1] = y4i + y9r;
/* 2441 */         zj5[i1] = y5r - y8i;
/* 2442 */         zj5[i1 + 1] = y5i + y8r;
/* 2443 */         zj6[i1] = y6r - y7i;
/* 2444 */         zj6[i1 + 1] = y6i + y7r;
/* 2445 */         zj7[i1] = y6r + y7i;
/* 2446 */         zj7[i1 + 1] = y6i - y7r;
/* 2447 */         zj8[i1] = y5r + y8i;
/* 2448 */         zj8[i1 + 1] = y5i - y8r;
/* 2449 */         zj9[i1] = y4r + y9i;
/* 2450 */         zj9[i1 + 1] = y4i - y9r;
/* 2451 */         zj10[i1] = y3r + y10i;
/* 2452 */         zj10[i1 + 1] = y3i - y10r;
/* 2453 */         zj11[i1] = y2r + y11i;
/* 2454 */         zj11[i1 + 1] = y2i - y11r;
/* 2455 */         zj12[i1] = y1r + y12i;
/* 2456 */         zj12[i1 + 1] = y1i - y12r;
/*      */       } 
/* 2458 */       int jt = j12 + 1;
/* 2459 */       j12 = j11 + 1;
/* 2460 */       j11 = j10 + 1;
/* 2461 */       j10 = j9 + 1;
/* 2462 */       j9 = j8 + 1;
/* 2463 */       j8 = j7 + 1;
/* 2464 */       j7 = j6 + 1;
/* 2465 */       j6 = j5 + 1;
/* 2466 */       j5 = j4 + 1;
/* 2467 */       j4 = j3 + 1;
/* 2468 */       j3 = j2 + 1;
/* 2469 */       j2 = j1 + 1;
/* 2470 */       j1 = j0 + 1;
/* 2471 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void pfa16a(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12, int j13, int j14, int j15) {
/*      */     float c1, c2, c3, c4;
/* 2478 */     int m1 = 2 * n1;
/*      */     
/* 2480 */     if (mu == 1) {
/* 2481 */       c1 = 1.0F;
/* 2482 */       c2 = 0.9238795F;
/* 2483 */       c3 = 0.38268343F;
/* 2484 */       c4 = 0.70710677F;
/* 2485 */     } else if (mu == 3) {
/* 2486 */       c1 = -1.0F;
/* 2487 */       c2 = 0.38268343F;
/* 2488 */       c3 = 0.9238795F;
/* 2489 */       c4 = -0.70710677F;
/* 2490 */     } else if (mu == 5) {
/* 2491 */       c1 = 1.0F;
/* 2492 */       c2 = -0.38268343F;
/* 2493 */       c3 = 0.9238795F;
/* 2494 */       c4 = -0.70710677F;
/* 2495 */     } else if (mu == 7) {
/* 2496 */       c1 = -1.0F;
/* 2497 */       c2 = -0.9238795F;
/* 2498 */       c3 = 0.38268343F;
/* 2499 */       c4 = 0.70710677F;
/* 2500 */     } else if (mu == 9) {
/* 2501 */       c1 = 1.0F;
/* 2502 */       c2 = -0.9238795F;
/* 2503 */       c3 = -0.38268343F;
/* 2504 */       c4 = 0.70710677F;
/* 2505 */     } else if (mu == 11) {
/* 2506 */       c1 = -1.0F;
/* 2507 */       c2 = -0.38268343F;
/* 2508 */       c3 = -0.9238795F;
/* 2509 */       c4 = -0.70710677F;
/* 2510 */     } else if (mu == 13) {
/* 2511 */       c1 = 1.0F;
/* 2512 */       c2 = 0.38268343F;
/* 2513 */       c3 = -0.9238795F;
/* 2514 */       c4 = -0.70710677F;
/*      */     } else {
/* 2516 */       c1 = -1.0F;
/* 2517 */       c2 = 0.9238795F;
/* 2518 */       c3 = -0.38268343F;
/* 2519 */       c4 = 0.70710677F;
/*      */     } 
/* 2521 */     float c5 = c1 * c4;
/* 2522 */     float c6 = c1 * c3;
/* 2523 */     float c7 = c1 * c2;
/* 2524 */     for (int i = 0; i < m; i++) {
/* 2525 */       float[] zj0 = z[j0];
/* 2526 */       float[] zj1 = z[j1];
/* 2527 */       float[] zj2 = z[j2];
/* 2528 */       float[] zj3 = z[j3];
/* 2529 */       float[] zj4 = z[j4];
/* 2530 */       float[] zj5 = z[j5];
/* 2531 */       float[] zj6 = z[j6];
/* 2532 */       float[] zj7 = z[j7];
/* 2533 */       float[] zj8 = z[j8];
/* 2534 */       float[] zj9 = z[j9];
/* 2535 */       float[] zj10 = z[j10];
/* 2536 */       float[] zj11 = z[j11];
/* 2537 */       float[] zj12 = z[j12];
/* 2538 */       float[] zj13 = z[j13];
/* 2539 */       float[] zj14 = z[j14];
/* 2540 */       float[] zj15 = z[j15];
/* 2541 */       for (int i1 = 0; i1 < m1; i1 += 2) {
/* 2542 */         float t1r = zj0[i1] + zj8[i1];
/* 2543 */         float t1i = zj0[i1 + 1] + zj8[i1 + 1];
/* 2544 */         float t2r = zj4[i1] + zj12[i1];
/* 2545 */         float t2i = zj4[i1 + 1] + zj12[i1 + 1];
/* 2546 */         float t3r = zj0[i1] - zj8[i1];
/* 2547 */         float t3i = zj0[i1 + 1] - zj8[i1 + 1];
/* 2548 */         float t4r = c1 * (zj4[i1] - zj12[i1]);
/* 2549 */         float t4i = c1 * (zj4[i1 + 1] - zj12[i1 + 1]);
/* 2550 */         float t5r = t1r + t2r;
/* 2551 */         float t5i = t1i + t2i;
/* 2552 */         float t6r = t1r - t2r;
/* 2553 */         float t6i = t1i - t2i;
/* 2554 */         float t7r = zj1[i1] + zj9[i1];
/* 2555 */         float t7i = zj1[i1 + 1] + zj9[i1 + 1];
/* 2556 */         float t8r = zj5[i1] + zj13[i1];
/* 2557 */         float t8i = zj5[i1 + 1] + zj13[i1 + 1];
/* 2558 */         float t9r = zj1[i1] - zj9[i1];
/* 2559 */         float t9i = zj1[i1 + 1] - zj9[i1 + 1];
/* 2560 */         float t10r = zj5[i1] - zj13[i1];
/* 2561 */         float t10i = zj5[i1 + 1] - zj13[i1 + 1];
/* 2562 */         float t11r = t7r + t8r;
/* 2563 */         float t11i = t7i + t8i;
/* 2564 */         float t12r = t7r - t8r;
/* 2565 */         float t12i = t7i - t8i;
/* 2566 */         float t13r = zj2[i1] + zj10[i1];
/* 2567 */         float t13i = zj2[i1 + 1] + zj10[i1 + 1];
/* 2568 */         float t14r = zj6[i1] + zj14[i1];
/* 2569 */         float t14i = zj6[i1 + 1] + zj14[i1 + 1];
/* 2570 */         float t15r = zj2[i1] - zj10[i1];
/* 2571 */         float t15i = zj2[i1 + 1] - zj10[i1 + 1];
/* 2572 */         float t16r = zj6[i1] - zj14[i1];
/* 2573 */         float t16i = zj6[i1 + 1] - zj14[i1 + 1];
/* 2574 */         float t17r = t13r + t14r;
/* 2575 */         float t17i = t13i + t14i;
/* 2576 */         float t18r = c4 * (t15r - t16r);
/* 2577 */         float t18i = c4 * (t15i - t16i);
/* 2578 */         float t19r = c5 * (t15r + t16r);
/* 2579 */         float t19i = c5 * (t15i + t16i);
/* 2580 */         float t20r = c1 * (t13r - t14r);
/* 2581 */         float t20i = c1 * (t13i - t14i);
/* 2582 */         float t21r = zj3[i1] + zj11[i1];
/* 2583 */         float t21i = zj3[i1 + 1] + zj11[i1 + 1];
/* 2584 */         float t22r = zj7[i1] + zj15[i1];
/* 2585 */         float t22i = zj7[i1 + 1] + zj15[i1 + 1];
/* 2586 */         float t23r = zj3[i1] - zj11[i1];
/* 2587 */         float t23i = zj3[i1 + 1] - zj11[i1 + 1];
/* 2588 */         float t24r = zj7[i1] - zj15[i1];
/* 2589 */         float t24i = zj7[i1 + 1] - zj15[i1 + 1];
/* 2590 */         float t25r = t21r + t22r;
/* 2591 */         float t25i = t21i + t22i;
/* 2592 */         float t26r = t21r - t22r;
/* 2593 */         float t26i = t21i - t22i;
/* 2594 */         float t27r = t9r + t24r;
/* 2595 */         float t27i = t9i + t24i;
/* 2596 */         float t28r = t10r + t23r;
/* 2597 */         float t28i = t10i + t23i;
/* 2598 */         float t29r = t9r - t24r;
/* 2599 */         float t29i = t9i - t24i;
/* 2600 */         float t30r = t10r - t23r;
/* 2601 */         float t30i = t10i - t23i;
/* 2602 */         float t31r = t5r + t17r;
/* 2603 */         float t31i = t5i + t17i;
/* 2604 */         float t32r = t11r + t25r;
/* 2605 */         float t32i = t11i + t25i;
/* 2606 */         float t33r = t3r + t18r;
/* 2607 */         float t33i = t3i + t18i;
/* 2608 */         float t34r = c2 * t29r - c6 * t30r;
/* 2609 */         float t34i = c2 * t29i - c6 * t30i;
/* 2610 */         float t35r = t3r - t18r;
/* 2611 */         float t35i = t3i - t18i;
/* 2612 */         float t36r = c7 * t27r - c3 * t28r;
/* 2613 */         float t36i = c7 * t27i - c3 * t28i;
/* 2614 */         float t37r = t4r + t19r;
/* 2615 */         float t37i = t4i + t19i;
/* 2616 */         float t38r = c3 * t27r + c7 * t28r;
/* 2617 */         float t38i = c3 * t27i + c7 * t28i;
/* 2618 */         float t39r = t4r - t19r;
/* 2619 */         float t39i = t4i - t19i;
/* 2620 */         float t40r = c6 * t29r + c2 * t30r;
/* 2621 */         float t40i = c6 * t29i + c2 * t30i;
/* 2622 */         float t41r = c4 * (t12r - t26r);
/* 2623 */         float t41i = c4 * (t12i - t26i);
/* 2624 */         float t42r = c5 * (t12r + t26r);
/* 2625 */         float t42i = c5 * (t12i + t26i);
/* 2626 */         float y1r = t33r + t34r;
/* 2627 */         float y1i = t33i + t34i;
/* 2628 */         float y2r = t6r + t41r;
/* 2629 */         float y2i = t6i + t41i;
/* 2630 */         float y3r = t35r + t40r;
/* 2631 */         float y3i = t35i + t40i;
/* 2632 */         float y4r = t5r - t17r;
/* 2633 */         float y4i = t5i - t17i;
/* 2634 */         float y5r = t35r - t40r;
/* 2635 */         float y5i = t35i - t40i;
/* 2636 */         float y6r = t6r - t41r;
/* 2637 */         float y6i = t6i - t41i;
/* 2638 */         float y7r = t33r - t34r;
/* 2639 */         float y7i = t33i - t34i;
/* 2640 */         float y9r = t38r - t37r;
/* 2641 */         float y9i = t38i - t37i;
/* 2642 */         float y10r = t42r - t20r;
/* 2643 */         float y10i = t42i - t20i;
/* 2644 */         float y11r = t36r + t39r;
/* 2645 */         float y11i = t36i + t39i;
/* 2646 */         float y12r = c1 * (t11r - t25r);
/* 2647 */         float y12i = c1 * (t11i - t25i);
/* 2648 */         float y13r = t36r - t39r;
/* 2649 */         float y13i = t36i - t39i;
/* 2650 */         float y14r = t42r + t20r;
/* 2651 */         float y14i = t42i + t20i;
/* 2652 */         float y15r = t38r + t37r;
/* 2653 */         float y15i = t38i + t37i;
/* 2654 */         zj0[i1] = t31r + t32r;
/* 2655 */         zj0[i1 + 1] = t31i + t32i;
/* 2656 */         zj1[i1] = y1r - y15i;
/* 2657 */         zj1[i1 + 1] = y1i + y15r;
/* 2658 */         zj2[i1] = y2r - y14i;
/* 2659 */         zj2[i1 + 1] = y2i + y14r;
/* 2660 */         zj3[i1] = y3r - y13i;
/* 2661 */         zj3[i1 + 1] = y3i + y13r;
/* 2662 */         zj4[i1] = y4r - y12i;
/* 2663 */         zj4[i1 + 1] = y4i + y12r;
/* 2664 */         zj5[i1] = y5r - y11i;
/* 2665 */         zj5[i1 + 1] = y5i + y11r;
/* 2666 */         zj6[i1] = y6r - y10i;
/* 2667 */         zj6[i1 + 1] = y6i + y10r;
/* 2668 */         zj7[i1] = y7r - y9i;
/* 2669 */         zj7[i1 + 1] = y7i + y9r;
/* 2670 */         zj8[i1] = t31r - t32r;
/* 2671 */         zj8[i1 + 1] = t31i - t32i;
/* 2672 */         zj9[i1] = y7r + y9i;
/* 2673 */         zj9[i1 + 1] = y7i - y9r;
/* 2674 */         zj10[i1] = y6r + y10i;
/* 2675 */         zj10[i1 + 1] = y6i - y10r;
/* 2676 */         zj11[i1] = y5r + y11i;
/* 2677 */         zj11[i1 + 1] = y5i - y11r;
/* 2678 */         zj12[i1] = y4r + y12i;
/* 2679 */         zj12[i1 + 1] = y4i - y12r;
/* 2680 */         zj13[i1] = y3r + y13i;
/* 2681 */         zj13[i1 + 1] = y3i - y13r;
/* 2682 */         zj14[i1] = y2r + y14i;
/* 2683 */         zj14[i1 + 1] = y2i - y14r;
/* 2684 */         zj15[i1] = y1r + y15i;
/* 2685 */         zj15[i1 + 1] = y1i - y15r;
/*      */       } 
/* 2687 */       int jt = j15 + 1;
/* 2688 */       j15 = j14 + 1;
/* 2689 */       j14 = j13 + 1;
/* 2690 */       j13 = j12 + 1;
/* 2691 */       j12 = j11 + 1;
/* 2692 */       j11 = j10 + 1;
/* 2693 */       j10 = j9 + 1;
/* 2694 */       j9 = j8 + 1;
/* 2695 */       j8 = j7 + 1;
/* 2696 */       j7 = j6 + 1;
/* 2697 */       j6 = j5 + 1;
/* 2698 */       j5 = j4 + 1;
/* 2699 */       j4 = j3 + 1;
/* 2700 */       j3 = j2 + 1;
/* 2701 */       j2 = j1 + 1;
/* 2702 */       j1 = j0 + 1;
/* 2703 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void transform2b(int sign, int n1, int nfft, float[][] z)
/*      */   {
/* 2720 */     int nleft = nfft;
/*      */ 
/*      */     
/* 2723 */     for (int jfac = 0; jfac < 10; jfac++) {
/*      */ 
/*      */       
/* 2726 */       int ifac = _kfac[jfac];
/* 2727 */       int ndiv = nleft / ifac;
/* 2728 */       if (ndiv * ifac == nleft) {
/*      */ 
/*      */ 
/*      */         
/* 2732 */         nleft = ndiv;
/* 2733 */         int m = nfft / ifac;
/*      */ 
/*      */         
/* 2736 */         int mu = 0;
/* 2737 */         int mm = 0;
/* 2738 */         for (int kfac = 1; kfac <= ifac && mm % ifac != 1; kfac++) {
/* 2739 */           mu = kfac;
/* 2740 */           mm = kfac * m;
/*      */         } 
/* 2742 */         if (sign < 0) {
/* 2743 */           mu = ifac - mu;
/*      */         }
/*      */         
/* 2746 */         int jinc = 2 * mm;
/* 2747 */         int jmax = 2 * nfft;
/* 2748 */         int j0 = 0;
/* 2749 */         int j1 = j0 + jinc;
/*      */ 
/*      */         
/* 2752 */         if (ifac == 2) {
/* 2753 */           pfa2b(n1, z, mu, m, j0, j1);
/*      */         } else {
/*      */           
/* 2756 */           int j2 = (j1 + jinc) % jmax;
/*      */ 
/*      */           
/* 2759 */           if (ifac == 3) {
/* 2760 */             pfa3b(n1, z, mu, m, j0, j1, j2);
/*      */           } else {
/*      */             
/* 2763 */             int j3 = (j2 + jinc) % jmax;
/*      */ 
/*      */             
/* 2766 */             if (ifac == 4) {
/* 2767 */               pfa4b(n1, z, mu, m, j0, j1, j2, j3);
/*      */             } else {
/*      */               
/* 2770 */               int j4 = (j3 + jinc) % jmax;
/*      */ 
/*      */               
/* 2773 */               if (ifac == 5) {
/* 2774 */                 pfa5b(n1, z, mu, m, j0, j1, j2, j3, j4);
/*      */               } else {
/*      */                 
/* 2777 */                 int j5 = (j4 + jinc) % jmax;
/* 2778 */                 int j6 = (j5 + jinc) % jmax;
/*      */ 
/*      */                 
/* 2781 */                 if (ifac == 7) {
/* 2782 */                   pfa7b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6);
/*      */                 } else {
/*      */                   
/* 2785 */                   int j7 = (j6 + jinc) % jmax;
/*      */ 
/*      */                   
/* 2788 */                   if (ifac == 8) {
/* 2789 */                     pfa8b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7);
/*      */                   } else {
/*      */                     
/* 2792 */                     int j8 = (j7 + jinc) % jmax;
/*      */ 
/*      */                     
/* 2795 */                     if (ifac == 9)
/* 2796 */                     { pfa9b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8); }
/*      */                     else
/*      */                     
/* 2799 */                     { int j9 = (j8 + jinc) % jmax;
/* 2800 */                       int j10 = (j9 + jinc) % jmax;
/*      */ 
/*      */                       
/* 2803 */                       if (ifac == 11)
/* 2804 */                       { pfa11b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10); }
/*      */                       else
/*      */                       
/* 2807 */                       { int j11 = (j10 + jinc) % jmax;
/* 2808 */                         int j12 = (j11 + jinc) % jmax;
/*      */ 
/*      */                         
/* 2811 */                         if (ifac == 13)
/* 2812 */                         { pfa13b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12); }
/*      */                         else
/*      */                         
/* 2815 */                         { int j13 = (j12 + jinc) % jmax;
/* 2816 */                           int j14 = (j13 + jinc) % jmax;
/* 2817 */                           int j15 = (j14 + jinc) % jmax;
/*      */ 
/*      */                           
/* 2820 */                           if (ifac == 16)
/* 2821 */                             pfa16b(n1, z, mu, m, j0, j1, j2, j3, j4, j5, j6, j7, j8, j9, j10, j11, j12, j13, j14, j15);  }  }  } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2829 */     }  } private static void pfa2b(int n1, float[][] z, int mu, int m, int j0, int j1) { for (int i = 0; i < m; i++) {
/* 2830 */       float[] zj0r = z[j0];
/* 2831 */       float[] zj0i = z[j0 + 1];
/* 2832 */       float[] zj1r = z[j1];
/* 2833 */       float[] zj1i = z[j1 + 1];
/* 2834 */       for (int i1 = 0; i1 < n1; i1++) {
/* 2835 */         float t1r = zj0r[i1] - zj1r[i1];
/* 2836 */         float t1i = zj0i[i1] - zj1i[i1];
/* 2837 */         zj0r[i1] = zj0r[i1] + zj1r[i1];
/* 2838 */         zj0i[i1] = zj0i[i1] + zj1i[i1];
/* 2839 */         zj1r[i1] = t1r;
/* 2840 */         zj1i[i1] = t1i;
/*      */       } 
/* 2842 */       int jt = j1 + 2;
/* 2843 */       j1 = j0 + 2;
/* 2844 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa3b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2) {
/*      */     float c1;
/* 2851 */     if (mu == 1) {
/* 2852 */       c1 = 0.8660254F;
/*      */     } else {
/* 2854 */       c1 = -0.8660254F;
/*      */     } 
/* 2856 */     for (int i = 0; i < m; i++) {
/* 2857 */       float[] zj0r = z[j0];
/* 2858 */       float[] zj0i = z[j0 + 1];
/* 2859 */       float[] zj1r = z[j1];
/* 2860 */       float[] zj1i = z[j1 + 1];
/* 2861 */       float[] zj2r = z[j2];
/* 2862 */       float[] zj2i = z[j2 + 1];
/* 2863 */       for (int i1 = 0; i1 < n1; i1++) {
/* 2864 */         float t1r = zj1r[i1] + zj2r[i1];
/* 2865 */         float t1i = zj1i[i1] + zj2i[i1];
/* 2866 */         float y1r = zj0r[i1] - 0.5F * t1r;
/* 2867 */         float y1i = zj0i[i1] - 0.5F * t1i;
/* 2868 */         float y2r = c1 * (zj1r[i1] - zj2r[i1]);
/* 2869 */         float y2i = c1 * (zj1i[i1] - zj2i[i1]);
/* 2870 */         zj0r[i1] = zj0r[i1] + t1r;
/* 2871 */         zj0i[i1] = zj0i[i1] + t1i;
/* 2872 */         zj1r[i1] = y1r - y2i;
/* 2873 */         zj1i[i1] = y1i + y2r;
/* 2874 */         zj2r[i1] = y1r + y2i;
/* 2875 */         zj2i[i1] = y1i - y2r;
/*      */       } 
/* 2877 */       int jt = j2 + 2;
/* 2878 */       j2 = j1 + 2;
/* 2879 */       j1 = j0 + 2;
/* 2880 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void pfa4b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3) {
/*      */     float c1;
/* 2887 */     if (mu == 1) {
/* 2888 */       c1 = 1.0F;
/*      */     } else {
/* 2890 */       c1 = -1.0F;
/*      */     } 
/* 2892 */     for (int i = 0; i < m; i++) {
/* 2893 */       float[] zj0r = z[j0];
/* 2894 */       float[] zj0i = z[j0 + 1];
/* 2895 */       float[] zj1r = z[j1];
/* 2896 */       float[] zj1i = z[j1 + 1];
/* 2897 */       float[] zj2r = z[j2];
/* 2898 */       float[] zj2i = z[j2 + 1];
/* 2899 */       float[] zj3r = z[j3];
/* 2900 */       float[] zj3i = z[j3 + 1];
/* 2901 */       for (int i1 = 0; i1 < n1; i1++) {
/* 2902 */         float t1r = zj0r[i1] + zj2r[i1];
/* 2903 */         float t1i = zj0i[i1] + zj2i[i1];
/* 2904 */         float t2r = zj1r[i1] + zj3r[i1];
/* 2905 */         float t2i = zj1i[i1] + zj3i[i1];
/* 2906 */         float y1r = zj0r[i1] - zj2r[i1];
/* 2907 */         float y1i = zj0i[i1] - zj2i[i1];
/* 2908 */         float y3r = c1 * (zj1r[i1] - zj3r[i1]);
/* 2909 */         float y3i = c1 * (zj1i[i1] - zj3i[i1]);
/* 2910 */         zj0r[i1] = t1r + t2r;
/* 2911 */         zj0i[i1] = t1i + t2i;
/* 2912 */         zj1r[i1] = y1r - y3i;
/* 2913 */         zj1i[i1] = y1i + y3r;
/* 2914 */         zj2r[i1] = t1r - t2r;
/* 2915 */         zj2i[i1] = t1i - t2i;
/* 2916 */         zj3r[i1] = y1r + y3i;
/* 2917 */         zj3i[i1] = y1i - y3r;
/*      */       } 
/* 2919 */       int jt = j3 + 2;
/* 2920 */       j3 = j2 + 2;
/* 2921 */       j2 = j1 + 2;
/* 2922 */       j1 = j0 + 2;
/* 2923 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa5b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4) { float c1;
/*      */     float c2;
/*      */     float c3;
/* 2930 */     if (mu == 1) {
/* 2931 */       c1 = 0.559017F;
/* 2932 */       c2 = 0.95105654F;
/* 2933 */       c3 = 0.58778524F;
/* 2934 */     } else if (mu == 2) {
/* 2935 */       c1 = -0.559017F;
/* 2936 */       c2 = 0.58778524F;
/* 2937 */       c3 = -0.95105654F;
/* 2938 */     } else if (mu == 3) {
/* 2939 */       c1 = -0.559017F;
/* 2940 */       c2 = -0.58778524F;
/* 2941 */       c3 = 0.95105654F;
/*      */     } else {
/* 2943 */       c1 = 0.559017F;
/* 2944 */       c2 = -0.95105654F;
/* 2945 */       c3 = -0.58778524F;
/*      */     } 
/* 2947 */     for (int i = 0; i < m; i++) {
/* 2948 */       float[] zj0r = z[j0];
/* 2949 */       float[] zj0i = z[j0 + 1];
/* 2950 */       float[] zj1r = z[j1];
/* 2951 */       float[] zj1i = z[j1 + 1];
/* 2952 */       float[] zj2r = z[j2];
/* 2953 */       float[] zj2i = z[j2 + 1];
/* 2954 */       float[] zj3r = z[j3];
/* 2955 */       float[] zj3i = z[j3 + 1];
/* 2956 */       float[] zj4r = z[j4];
/* 2957 */       float[] zj4i = z[j4 + 1];
/* 2958 */       for (int i1 = 0; i1 < n1; i1++) {
/* 2959 */         float t1r = zj1r[i1] + zj4r[i1];
/* 2960 */         float t1i = zj1i[i1] + zj4i[i1];
/* 2961 */         float t2r = zj2r[i1] + zj3r[i1];
/* 2962 */         float t2i = zj2i[i1] + zj3i[i1];
/* 2963 */         float t3r = zj1r[i1] - zj4r[i1];
/* 2964 */         float t3i = zj1i[i1] - zj4i[i1];
/* 2965 */         float t4r = zj2r[i1] - zj3r[i1];
/* 2966 */         float t4i = zj2i[i1] - zj3i[i1];
/* 2967 */         float t5r = t1r + t2r;
/* 2968 */         float t5i = t1i + t2i;
/* 2969 */         float t6r = c1 * (t1r - t2r);
/* 2970 */         float t6i = c1 * (t1i - t2i);
/* 2971 */         float t7r = zj0r[i1] - 0.25F * t5r;
/* 2972 */         float t7i = zj0i[i1] - 0.25F * t5i;
/* 2973 */         float y1r = t7r + t6r;
/* 2974 */         float y1i = t7i + t6i;
/* 2975 */         float y2r = t7r - t6r;
/* 2976 */         float y2i = t7i - t6i;
/* 2977 */         float y3r = c3 * t3r - c2 * t4r;
/* 2978 */         float y3i = c3 * t3i - c2 * t4i;
/* 2979 */         float y4r = c2 * t3r + c3 * t4r;
/* 2980 */         float y4i = c2 * t3i + c3 * t4i;
/* 2981 */         zj0r[i1] = zj0r[i1] + t5r;
/* 2982 */         zj0i[i1] = zj0i[i1] + t5i;
/* 2983 */         zj1r[i1] = y1r - y4i;
/* 2984 */         zj1i[i1] = y1i + y4r;
/* 2985 */         zj2r[i1] = y2r - y3i;
/* 2986 */         zj2i[i1] = y2i + y3r;
/* 2987 */         zj3r[i1] = y2r + y3i;
/* 2988 */         zj3i[i1] = y2i - y3r;
/* 2989 */         zj4r[i1] = y1r + y4i;
/* 2990 */         zj4i[i1] = y1i - y4r;
/*      */       } 
/* 2992 */       int jt = j4 + 2;
/* 2993 */       j4 = j3 + 2;
/* 2994 */       j3 = j2 + 2;
/* 2995 */       j2 = j1 + 2;
/* 2996 */       j1 = j0 + 2;
/* 2997 */       j0 = jt;
/*      */     }  } private static void pfa7b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6) { float c1;
/*      */     float c2;
/*      */     float c3;
/*      */     float c4;
/*      */     float c5;
/*      */     float c6;
/* 3004 */     if (mu == 1) {
/* 3005 */       c1 = 0.6234898F;
/* 3006 */       c2 = -0.22252093F;
/* 3007 */       c3 = -0.90096885F;
/* 3008 */       c4 = 0.7818315F;
/* 3009 */       c5 = 0.9749279F;
/* 3010 */       c6 = 0.43388373F;
/* 3011 */     } else if (mu == 2) {
/* 3012 */       c1 = -0.22252093F;
/* 3013 */       c2 = -0.90096885F;
/* 3014 */       c3 = 0.6234898F;
/* 3015 */       c4 = 0.9749279F;
/* 3016 */       c5 = -0.43388373F;
/* 3017 */       c6 = -0.7818315F;
/* 3018 */     } else if (mu == 3) {
/* 3019 */       c1 = -0.90096885F;
/* 3020 */       c2 = 0.6234898F;
/* 3021 */       c3 = -0.22252093F;
/* 3022 */       c4 = 0.43388373F;
/* 3023 */       c5 = -0.7818315F;
/* 3024 */       c6 = 0.9749279F;
/* 3025 */     } else if (mu == 4) {
/* 3026 */       c1 = -0.90096885F;
/* 3027 */       c2 = 0.6234898F;
/* 3028 */       c3 = -0.22252093F;
/* 3029 */       c4 = -0.43388373F;
/* 3030 */       c5 = 0.7818315F;
/* 3031 */       c6 = -0.9749279F;
/* 3032 */     } else if (mu == 5) {
/* 3033 */       c1 = -0.22252093F;
/* 3034 */       c2 = -0.90096885F;
/* 3035 */       c3 = 0.6234898F;
/* 3036 */       c4 = -0.9749279F;
/* 3037 */       c5 = 0.43388373F;
/* 3038 */       c6 = 0.7818315F;
/*      */     } else {
/* 3040 */       c1 = 0.6234898F;
/* 3041 */       c2 = -0.22252093F;
/* 3042 */       c3 = -0.90096885F;
/* 3043 */       c4 = -0.7818315F;
/* 3044 */       c5 = -0.9749279F;
/* 3045 */       c6 = -0.43388373F;
/*      */     } 
/* 3047 */     for (int i = 0; i < m; i++) {
/* 3048 */       float[] zj0r = z[j0];
/* 3049 */       float[] zj0i = z[j0 + 1];
/* 3050 */       float[] zj1r = z[j1];
/* 3051 */       float[] zj1i = z[j1 + 1];
/* 3052 */       float[] zj2r = z[j2];
/* 3053 */       float[] zj2i = z[j2 + 1];
/* 3054 */       float[] zj3r = z[j3];
/* 3055 */       float[] zj3i = z[j3 + 1];
/* 3056 */       float[] zj4r = z[j4];
/* 3057 */       float[] zj4i = z[j4 + 1];
/* 3058 */       float[] zj5r = z[j5];
/* 3059 */       float[] zj5i = z[j5 + 1];
/* 3060 */       float[] zj6r = z[j6];
/* 3061 */       float[] zj6i = z[j6 + 1];
/* 3062 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3063 */         float t1r = zj1r[i1] + zj6r[i1];
/* 3064 */         float t1i = zj1i[i1] + zj6i[i1];
/* 3065 */         float t2r = zj2r[i1] + zj5r[i1];
/* 3066 */         float t2i = zj2i[i1] + zj5i[i1];
/* 3067 */         float t3r = zj3r[i1] + zj4r[i1];
/* 3068 */         float t3i = zj3i[i1] + zj4i[i1];
/* 3069 */         float t4r = zj1r[i1] - zj6r[i1];
/* 3070 */         float t4i = zj1i[i1] - zj6i[i1];
/* 3071 */         float t5r = zj2r[i1] - zj5r[i1];
/* 3072 */         float t5i = zj2i[i1] - zj5i[i1];
/* 3073 */         float t6r = zj3r[i1] - zj4r[i1];
/* 3074 */         float t6i = zj3i[i1] - zj4i[i1];
/* 3075 */         float t7r = zj0r[i1] - 0.5F * t3r;
/* 3076 */         float t7i = zj0i[i1] - 0.5F * t3i;
/* 3077 */         float t8r = t1r - t3r;
/* 3078 */         float t8i = t1i - t3i;
/* 3079 */         float t9r = t2r - t3r;
/* 3080 */         float t9i = t2i - t3i;
/* 3081 */         float y1r = t7r + c1 * t8r + c2 * t9r;
/* 3082 */         float y1i = t7i + c1 * t8i + c2 * t9i;
/* 3083 */         float y2r = t7r + c2 * t8r + c3 * t9r;
/* 3084 */         float y2i = t7i + c2 * t8i + c3 * t9i;
/* 3085 */         float y3r = t7r + c3 * t8r + c1 * t9r;
/* 3086 */         float y3i = t7i + c3 * t8i + c1 * t9i;
/* 3087 */         float y4r = c6 * t4r - c4 * t5r + c5 * t6r;
/* 3088 */         float y4i = c6 * t4i - c4 * t5i + c5 * t6i;
/* 3089 */         float y5r = c5 * t4r - c6 * t5r - c4 * t6r;
/* 3090 */         float y5i = c5 * t4i - c6 * t5i - c4 * t6i;
/* 3091 */         float y6r = c4 * t4r + c5 * t5r + c6 * t6r;
/* 3092 */         float y6i = c4 * t4i + c5 * t5i + c6 * t6i;
/* 3093 */         zj0r[i1] = zj0r[i1] + t1r + t2r + t3r;
/* 3094 */         zj0i[i1] = zj0i[i1] + t1i + t2i + t3i;
/* 3095 */         zj1r[i1] = y1r - y6i;
/* 3096 */         zj1i[i1] = y1i + y6r;
/* 3097 */         zj2r[i1] = y2r - y5i;
/* 3098 */         zj2i[i1] = y2i + y5r;
/* 3099 */         zj3r[i1] = y3r - y4i;
/* 3100 */         zj3i[i1] = y3i + y4r;
/* 3101 */         zj4r[i1] = y3r + y4i;
/* 3102 */         zj4i[i1] = y3i - y4r;
/* 3103 */         zj5r[i1] = y2r + y5i;
/* 3104 */         zj5i[i1] = y2i - y5r;
/* 3105 */         zj6r[i1] = y1r + y6i;
/* 3106 */         zj6i[i1] = y1i - y6r;
/*      */       } 
/* 3108 */       int jt = j6 + 2;
/* 3109 */       j6 = j5 + 2;
/* 3110 */       j5 = j4 + 2;
/* 3111 */       j4 = j3 + 2;
/* 3112 */       j3 = j2 + 2;
/* 3113 */       j2 = j1 + 2;
/* 3114 */       j1 = j0 + 2;
/* 3115 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa8b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7) {
/*      */     float c1, c2;
/* 3122 */     if (mu == 1) {
/* 3123 */       c1 = 1.0F;
/* 3124 */       c2 = 0.70710677F;
/* 3125 */     } else if (mu == 3) {
/* 3126 */       c1 = -1.0F;
/* 3127 */       c2 = -0.70710677F;
/* 3128 */     } else if (mu == 5) {
/* 3129 */       c1 = 1.0F;
/* 3130 */       c2 = -0.70710677F;
/*      */     } else {
/* 3132 */       c1 = -1.0F;
/* 3133 */       c2 = 0.70710677F;
/*      */     } 
/* 3135 */     float c3 = c1 * c2;
/* 3136 */     for (int i = 0; i < m; i++) {
/* 3137 */       float[] zj0r = z[j0];
/* 3138 */       float[] zj0i = z[j0 + 1];
/* 3139 */       float[] zj1r = z[j1];
/* 3140 */       float[] zj1i = z[j1 + 1];
/* 3141 */       float[] zj2r = z[j2];
/* 3142 */       float[] zj2i = z[j2 + 1];
/* 3143 */       float[] zj3r = z[j3];
/* 3144 */       float[] zj3i = z[j3 + 1];
/* 3145 */       float[] zj4r = z[j4];
/* 3146 */       float[] zj4i = z[j4 + 1];
/* 3147 */       float[] zj5r = z[j5];
/* 3148 */       float[] zj5i = z[j5 + 1];
/* 3149 */       float[] zj6r = z[j6];
/* 3150 */       float[] zj6i = z[j6 + 1];
/* 3151 */       float[] zj7r = z[j7];
/* 3152 */       float[] zj7i = z[j7 + 1];
/* 3153 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3154 */         float t1r = zj0r[i1] + zj4r[i1];
/* 3155 */         float t1i = zj0i[i1] + zj4i[i1];
/* 3156 */         float t2r = zj0r[i1] - zj4r[i1];
/* 3157 */         float t2i = zj0i[i1] - zj4i[i1];
/* 3158 */         float t3r = zj1r[i1] + zj5r[i1];
/* 3159 */         float t3i = zj1i[i1] + zj5i[i1];
/* 3160 */         float t4r = zj1r[i1] - zj5r[i1];
/* 3161 */         float t4i = zj1i[i1] - zj5i[i1];
/* 3162 */         float t5r = zj2r[i1] + zj6r[i1];
/* 3163 */         float t5i = zj2i[i1] + zj6i[i1];
/* 3164 */         float t6r = c1 * (zj2r[i1] - zj6r[i1]);
/* 3165 */         float t6i = c1 * (zj2i[i1] - zj6i[i1]);
/* 3166 */         float t7r = zj3r[i1] + zj7r[i1];
/* 3167 */         float t7i = zj3i[i1] + zj7i[i1];
/* 3168 */         float t8r = zj3r[i1] - zj7r[i1];
/* 3169 */         float t8i = zj3i[i1] - zj7i[i1];
/* 3170 */         float t9r = t1r + t5r;
/* 3171 */         float t9i = t1i + t5i;
/* 3172 */         float t10r = t3r + t7r;
/* 3173 */         float t10i = t3i + t7i;
/* 3174 */         float t11r = c2 * (t4r - t8r);
/* 3175 */         float t11i = c2 * (t4i - t8i);
/* 3176 */         float t12r = c3 * (t4r + t8r);
/* 3177 */         float t12i = c3 * (t4i + t8i);
/* 3178 */         float y1r = t2r + t11r;
/* 3179 */         float y1i = t2i + t11i;
/* 3180 */         float y2r = t1r - t5r;
/* 3181 */         float y2i = t1i - t5i;
/* 3182 */         float y3r = t2r - t11r;
/* 3183 */         float y3i = t2i - t11i;
/* 3184 */         float y5r = t12r - t6r;
/* 3185 */         float y5i = t12i - t6i;
/* 3186 */         float y6r = c1 * (t3r - t7r);
/* 3187 */         float y6i = c1 * (t3i - t7i);
/* 3188 */         float y7r = t12r + t6r;
/* 3189 */         float y7i = t12i + t6i;
/* 3190 */         zj0r[i1] = t9r + t10r;
/* 3191 */         zj0i[i1] = t9i + t10i;
/* 3192 */         zj1r[i1] = y1r - y7i;
/* 3193 */         zj1i[i1] = y1i + y7r;
/* 3194 */         zj2r[i1] = y2r - y6i;
/* 3195 */         zj2i[i1] = y2i + y6r;
/* 3196 */         zj3r[i1] = y3r - y5i;
/* 3197 */         zj3i[i1] = y3i + y5r;
/* 3198 */         zj4r[i1] = t9r - t10r;
/* 3199 */         zj4i[i1] = t9i - t10i;
/* 3200 */         zj5r[i1] = y3r + y5i;
/* 3201 */         zj5i[i1] = y3i - y5r;
/* 3202 */         zj6r[i1] = y2r + y6i;
/* 3203 */         zj6i[i1] = y2i - y6r;
/* 3204 */         zj7r[i1] = y1r + y7i;
/* 3205 */         zj7i[i1] = y1i - y7r;
/*      */       } 
/* 3207 */       int jt = j7 + 2;
/* 3208 */       j7 = j6 + 2;
/* 3209 */       j6 = j5 + 2;
/* 3210 */       j5 = j4 + 2;
/* 3211 */       j4 = j3 + 2;
/* 3212 */       j3 = j2 + 2;
/* 3213 */       j2 = j1 + 2;
/* 3214 */       j1 = j0 + 2;
/* 3215 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void pfa9b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8)
/*      */   {
/*      */     float c1, c2, c3, c4, c5;
/* 3222 */     if (mu == 1) {
/* 3223 */       c1 = 0.8660254F;
/* 3224 */       c2 = 0.76604444F;
/* 3225 */       c3 = 0.64278764F;
/* 3226 */       c4 = 0.17364818F;
/* 3227 */       c5 = 0.9848077F;
/* 3228 */     } else if (mu == 2) {
/* 3229 */       c1 = -0.8660254F;
/* 3230 */       c2 = 0.17364818F;
/* 3231 */       c3 = 0.9848077F;
/* 3232 */       c4 = -0.9396926F;
/* 3233 */       c5 = 0.34202015F;
/* 3234 */     } else if (mu == 4) {
/* 3235 */       c1 = 0.8660254F;
/* 3236 */       c2 = -0.9396926F;
/* 3237 */       c3 = 0.34202015F;
/* 3238 */       c4 = 0.76604444F;
/* 3239 */       c5 = -0.64278764F;
/* 3240 */     } else if (mu == 5) {
/* 3241 */       c1 = -0.8660254F;
/* 3242 */       c2 = -0.9396926F;
/* 3243 */       c3 = -0.34202015F;
/* 3244 */       c4 = 0.76604444F;
/* 3245 */       c5 = 0.64278764F;
/* 3246 */     } else if (mu == 7) {
/* 3247 */       c1 = 0.8660254F;
/* 3248 */       c2 = 0.17364818F;
/* 3249 */       c3 = -0.9848077F;
/* 3250 */       c4 = -0.9396926F;
/* 3251 */       c5 = -0.34202015F;
/*      */     } else {
/* 3253 */       c1 = -0.8660254F;
/* 3254 */       c2 = 0.76604444F;
/* 3255 */       c3 = -0.64278764F;
/* 3256 */       c4 = 0.17364818F;
/* 3257 */       c5 = -0.9848077F;
/*      */     } 
/* 3259 */     float c6 = c1 * c2;
/* 3260 */     float c7 = c1 * c3;
/* 3261 */     float c8 = c1 * c4;
/* 3262 */     float c9 = c1 * c5;
/* 3263 */     for (int i = 0; i < m; i++) {
/* 3264 */       float[] zj0r = z[j0];
/* 3265 */       float[] zj0i = z[j0 + 1];
/* 3266 */       float[] zj1r = z[j1];
/* 3267 */       float[] zj1i = z[j1 + 1];
/* 3268 */       float[] zj2r = z[j2];
/* 3269 */       float[] zj2i = z[j2 + 1];
/* 3270 */       float[] zj3r = z[j3];
/* 3271 */       float[] zj3i = z[j3 + 1];
/* 3272 */       float[] zj4r = z[j4];
/* 3273 */       float[] zj4i = z[j4 + 1];
/* 3274 */       float[] zj5r = z[j5];
/* 3275 */       float[] zj5i = z[j5 + 1];
/* 3276 */       float[] zj6r = z[j6];
/* 3277 */       float[] zj6i = z[j6 + 1];
/* 3278 */       float[] zj7r = z[j7];
/* 3279 */       float[] zj7i = z[j7 + 1];
/* 3280 */       float[] zj8r = z[j8];
/* 3281 */       float[] zj8i = z[j8 + 1];
/* 3282 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3283 */         float t1r = zj3r[i1] + zj6r[i1];
/* 3284 */         float t1i = zj3i[i1] + zj6i[i1];
/* 3285 */         float t2r = zj0r[i1] - 0.5F * t1r;
/* 3286 */         float t2i = zj0i[i1] - 0.5F * t1i;
/* 3287 */         float t3r = c1 * (zj3r[i1] - zj6r[i1]);
/* 3288 */         float t3i = c1 * (zj3i[i1] - zj6i[i1]);
/* 3289 */         float t4r = zj0r[i1] + t1r;
/* 3290 */         float t4i = zj0i[i1] + t1i;
/* 3291 */         float t5r = zj4r[i1] + zj7r[i1];
/* 3292 */         float t5i = zj4i[i1] + zj7i[i1];
/* 3293 */         float t6r = zj1r[i1] - 0.5F * t5r;
/* 3294 */         float t6i = zj1i[i1] - 0.5F * t5i;
/* 3295 */         float t7r = zj4r[i1] - zj7r[i1];
/* 3296 */         float t7i = zj4i[i1] - zj7i[i1];
/* 3297 */         float t8r = zj1r[i1] + t5r;
/* 3298 */         float t8i = zj1i[i1] + t5i;
/* 3299 */         float t9r = zj2r[i1] + zj5r[i1];
/* 3300 */         float t9i = zj2i[i1] + zj5i[i1];
/* 3301 */         float t10r = zj8r[i1] - 0.5F * t9r;
/* 3302 */         float t10i = zj8i[i1] - 0.5F * t9i;
/* 3303 */         float t11r = zj2r[i1] - zj5r[i1];
/* 3304 */         float t11i = zj2i[i1] - zj5i[i1];
/* 3305 */         float t12r = zj8r[i1] + t9r;
/* 3306 */         float t12i = zj8i[i1] + t9i;
/* 3307 */         float t13r = t8r + t12r;
/* 3308 */         float t13i = t8i + t12i;
/* 3309 */         float t14r = t6r + t10r;
/* 3310 */         float t14i = t6i + t10i;
/* 3311 */         float t15r = t6r - t10r;
/* 3312 */         float t15i = t6i - t10i;
/* 3313 */         float t16r = t7r + t11r;
/* 3314 */         float t16i = t7i + t11i;
/* 3315 */         float t17r = t7r - t11r;
/* 3316 */         float t17i = t7i - t11i;
/* 3317 */         float t18r = c2 * t14r - c7 * t17r;
/* 3318 */         float t18i = c2 * t14i - c7 * t17i;
/* 3319 */         float t19r = c4 * t14r + c9 * t17r;
/* 3320 */         float t19i = c4 * t14i + c9 * t17i;
/* 3321 */         float t20r = c3 * t15r + c6 * t16r;
/* 3322 */         float t20i = c3 * t15i + c6 * t16i;
/* 3323 */         float t21r = c5 * t15r - c8 * t16r;
/* 3324 */         float t21i = c5 * t15i - c8 * t16i;
/* 3325 */         float t22r = t18r + t19r;
/* 3326 */         float t22i = t18i + t19i;
/* 3327 */         float t23r = t20r - t21r;
/* 3328 */         float t23i = t20i - t21i;
/* 3329 */         float y1r = t2r + t18r;
/* 3330 */         float y1i = t2i + t18i;
/* 3331 */         float y2r = t2r + t19r;
/* 3332 */         float y2i = t2i + t19i;
/* 3333 */         float y3r = t4r - 0.5F * t13r;
/* 3334 */         float y3i = t4i - 0.5F * t13i;
/* 3335 */         float y4r = t2r - t22r;
/* 3336 */         float y4i = t2i - t22i;
/* 3337 */         float y5r = t3r - t23r;
/* 3338 */         float y5i = t3i - t23i;
/* 3339 */         float y6r = c1 * (t8r - t12r);
/* 3340 */         float y6i = c1 * (t8i - t12i);
/* 3341 */         float y7r = t21r - t3r;
/* 3342 */         float y7i = t21i - t3i;
/* 3343 */         float y8r = t3r + t20r;
/* 3344 */         float y8i = t3i + t20i;
/* 3345 */         zj0r[i1] = t4r + t13r;
/* 3346 */         zj0i[i1] = t4i + t13i;
/* 3347 */         zj1r[i1] = y1r - y8i;
/* 3348 */         zj1i[i1] = y1i + y8r;
/* 3349 */         zj2r[i1] = y2r - y7i;
/* 3350 */         zj2i[i1] = y2i + y7r;
/* 3351 */         zj3r[i1] = y3r - y6i;
/* 3352 */         zj3i[i1] = y3i + y6r;
/* 3353 */         zj4r[i1] = y4r - y5i;
/* 3354 */         zj4i[i1] = y4i + y5r;
/* 3355 */         zj5r[i1] = y4r + y5i;
/* 3356 */         zj5i[i1] = y4i - y5r;
/* 3357 */         zj6r[i1] = y3r + y6i;
/* 3358 */         zj6i[i1] = y3i - y6r;
/* 3359 */         zj7r[i1] = y2r + y7i;
/* 3360 */         zj7i[i1] = y2i - y7r;
/* 3361 */         zj8r[i1] = y1r + y8i;
/* 3362 */         zj8i[i1] = y1i - y8r;
/*      */       } 
/* 3364 */       int jt = j8 + 2;
/* 3365 */       j8 = j7 + 2;
/* 3366 */       j7 = j6 + 2;
/* 3367 */       j6 = j5 + 2;
/* 3368 */       j5 = j4 + 2;
/* 3369 */       j4 = j3 + 2;
/* 3370 */       j3 = j2 + 2;
/* 3371 */       j2 = j1 + 2;
/* 3372 */       j1 = j0 + 2;
/* 3373 */       j0 = jt;
/*      */     }  } private static void pfa11b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10) { float c1; float c2; float c3; float c4;
/*      */     float c5;
/*      */     float c6;
/*      */     float c7;
/*      */     float c8;
/*      */     float c9;
/*      */     float c10;
/* 3381 */     if (mu == 1) {
/* 3382 */       c1 = 0.8412535F;
/* 3383 */       c2 = 0.41541502F;
/* 3384 */       c3 = -0.14231484F;
/* 3385 */       c4 = -0.65486073F;
/* 3386 */       c5 = -0.959493F;
/* 3387 */       c6 = 0.54064083F;
/* 3388 */       c7 = 0.90963197F;
/* 3389 */       c8 = 0.98982143F;
/* 3390 */       c9 = 0.7557496F;
/* 3391 */       c10 = 0.28173256F;
/* 3392 */     } else if (mu == 2) {
/* 3393 */       c1 = 0.41541502F;
/* 3394 */       c2 = -0.65486073F;
/* 3395 */       c3 = -0.959493F;
/* 3396 */       c4 = -0.14231484F;
/* 3397 */       c5 = 0.8412535F;
/* 3398 */       c6 = 0.90963197F;
/* 3399 */       c7 = 0.7557496F;
/* 3400 */       c8 = -0.28173256F;
/* 3401 */       c9 = -0.98982143F;
/* 3402 */       c10 = -0.54064083F;
/* 3403 */     } else if (mu == 3) {
/* 3404 */       c1 = -0.14231484F;
/* 3405 */       c2 = -0.959493F;
/* 3406 */       c3 = 0.41541502F;
/* 3407 */       c4 = 0.8412535F;
/* 3408 */       c5 = -0.65486073F;
/* 3409 */       c6 = 0.98982143F;
/* 3410 */       c7 = -0.28173256F;
/* 3411 */       c8 = -0.90963197F;
/* 3412 */       c9 = 0.54064083F;
/* 3413 */       c10 = 0.7557496F;
/* 3414 */     } else if (mu == 4) {
/* 3415 */       c1 = -0.65486073F;
/* 3416 */       c2 = -0.14231484F;
/* 3417 */       c3 = 0.8412535F;
/* 3418 */       c4 = -0.959493F;
/* 3419 */       c5 = 0.41541502F;
/* 3420 */       c6 = 0.7557496F;
/* 3421 */       c7 = -0.98982143F;
/* 3422 */       c8 = 0.54064083F;
/* 3423 */       c9 = 0.28173256F;
/* 3424 */       c10 = -0.90963197F;
/* 3425 */     } else if (mu == 5) {
/* 3426 */       c1 = -0.959493F;
/* 3427 */       c2 = 0.8412535F;
/* 3428 */       c3 = -0.65486073F;
/* 3429 */       c4 = 0.41541502F;
/* 3430 */       c5 = -0.14231484F;
/* 3431 */       c6 = 0.28173256F;
/* 3432 */       c7 = -0.54064083F;
/* 3433 */       c8 = 0.7557496F;
/* 3434 */       c9 = -0.90963197F;
/* 3435 */       c10 = 0.98982143F;
/* 3436 */     } else if (mu == 6) {
/* 3437 */       c1 = -0.959493F;
/* 3438 */       c2 = 0.8412535F;
/* 3439 */       c3 = -0.65486073F;
/* 3440 */       c4 = 0.41541502F;
/* 3441 */       c5 = -0.14231484F;
/* 3442 */       c6 = -0.28173256F;
/* 3443 */       c7 = 0.54064083F;
/* 3444 */       c8 = -0.7557496F;
/* 3445 */       c9 = 0.90963197F;
/* 3446 */       c10 = -0.98982143F;
/* 3447 */     } else if (mu == 7) {
/* 3448 */       c1 = -0.65486073F;
/* 3449 */       c2 = -0.14231484F;
/* 3450 */       c3 = 0.8412535F;
/* 3451 */       c4 = -0.959493F;
/* 3452 */       c5 = 0.41541502F;
/* 3453 */       c6 = -0.7557496F;
/* 3454 */       c7 = 0.98982143F;
/* 3455 */       c8 = -0.54064083F;
/* 3456 */       c9 = -0.28173256F;
/* 3457 */       c10 = 0.90963197F;
/* 3458 */     } else if (mu == 8) {
/* 3459 */       c1 = -0.14231484F;
/* 3460 */       c2 = -0.959493F;
/* 3461 */       c3 = 0.41541502F;
/* 3462 */       c4 = 0.8412535F;
/* 3463 */       c5 = -0.65486073F;
/* 3464 */       c6 = -0.98982143F;
/* 3465 */       c7 = 0.28173256F;
/* 3466 */       c8 = 0.90963197F;
/* 3467 */       c9 = -0.54064083F;
/* 3468 */       c10 = -0.7557496F;
/* 3469 */     } else if (mu == 9) {
/* 3470 */       c1 = 0.41541502F;
/* 3471 */       c2 = -0.65486073F;
/* 3472 */       c3 = -0.959493F;
/* 3473 */       c4 = -0.14231484F;
/* 3474 */       c5 = 0.8412535F;
/* 3475 */       c6 = -0.90963197F;
/* 3476 */       c7 = -0.7557496F;
/* 3477 */       c8 = 0.28173256F;
/* 3478 */       c9 = 0.98982143F;
/* 3479 */       c10 = 0.54064083F;
/*      */     } else {
/* 3481 */       c1 = 0.8412535F;
/* 3482 */       c2 = 0.41541502F;
/* 3483 */       c3 = -0.14231484F;
/* 3484 */       c4 = -0.65486073F;
/* 3485 */       c5 = -0.959493F;
/* 3486 */       c6 = -0.54064083F;
/* 3487 */       c7 = -0.90963197F;
/* 3488 */       c8 = -0.98982143F;
/* 3489 */       c9 = -0.7557496F;
/* 3490 */       c10 = -0.28173256F;
/*      */     } 
/* 3492 */     for (int i = 0; i < m; i++) {
/* 3493 */       float[] zj0r = z[j0];
/* 3494 */       float[] zj0i = z[j0 + 1];
/* 3495 */       float[] zj1r = z[j1];
/* 3496 */       float[] zj1i = z[j1 + 1];
/* 3497 */       float[] zj2r = z[j2];
/* 3498 */       float[] zj2i = z[j2 + 1];
/* 3499 */       float[] zj3r = z[j3];
/* 3500 */       float[] zj3i = z[j3 + 1];
/* 3501 */       float[] zj4r = z[j4];
/* 3502 */       float[] zj4i = z[j4 + 1];
/* 3503 */       float[] zj5r = z[j5];
/* 3504 */       float[] zj5i = z[j5 + 1];
/* 3505 */       float[] zj6r = z[j6];
/* 3506 */       float[] zj6i = z[j6 + 1];
/* 3507 */       float[] zj7r = z[j7];
/* 3508 */       float[] zj7i = z[j7 + 1];
/* 3509 */       float[] zj8r = z[j8];
/* 3510 */       float[] zj8i = z[j8 + 1];
/* 3511 */       float[] zj9r = z[j9];
/* 3512 */       float[] zj9i = z[j9 + 1];
/* 3513 */       float[] zj10r = z[j10];
/* 3514 */       float[] zj10i = z[j10 + 1];
/* 3515 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3516 */         float t1r = zj1r[i1] + zj10r[i1];
/* 3517 */         float t1i = zj1i[i1] + zj10i[i1];
/* 3518 */         float t2r = zj2r[i1] + zj9r[i1];
/* 3519 */         float t2i = zj2i[i1] + zj9i[i1];
/* 3520 */         float t3r = zj3r[i1] + zj8r[i1];
/* 3521 */         float t3i = zj3i[i1] + zj8i[i1];
/* 3522 */         float t4r = zj4r[i1] + zj7r[i1];
/* 3523 */         float t4i = zj4i[i1] + zj7i[i1];
/* 3524 */         float t5r = zj5r[i1] + zj6r[i1];
/* 3525 */         float t5i = zj5i[i1] + zj6i[i1];
/* 3526 */         float t6r = zj1r[i1] - zj10r[i1];
/* 3527 */         float t6i = zj1i[i1] - zj10i[i1];
/* 3528 */         float t7r = zj2r[i1] - zj9r[i1];
/* 3529 */         float t7i = zj2i[i1] - zj9i[i1];
/* 3530 */         float t8r = zj3r[i1] - zj8r[i1];
/* 3531 */         float t8i = zj3i[i1] - zj8i[i1];
/* 3532 */         float t9r = zj4r[i1] - zj7r[i1];
/* 3533 */         float t9i = zj4i[i1] - zj7i[i1];
/* 3534 */         float t10r = zj5r[i1] - zj6r[i1];
/* 3535 */         float t10i = zj5i[i1] - zj6i[i1];
/* 3536 */         float t11r = zj0r[i1] - 0.5F * t5r;
/* 3537 */         float t11i = zj0i[i1] - 0.5F * t5i;
/* 3538 */         float t12r = t1r - t5r;
/* 3539 */         float t12i = t1i - t5i;
/* 3540 */         float t13r = t2r - t5r;
/* 3541 */         float t13i = t2i - t5i;
/* 3542 */         float t14r = t3r - t5r;
/* 3543 */         float t14i = t3i - t5i;
/* 3544 */         float t15r = t4r - t5r;
/* 3545 */         float t15i = t4i - t5i;
/* 3546 */         float y1r = t11r + c1 * t12r + c2 * t13r + c3 * t14r + c4 * t15r;
/* 3547 */         float y1i = t11i + c1 * t12i + c2 * t13i + c3 * t14i + c4 * t15i;
/* 3548 */         float y2r = t11r + c2 * t12r + c4 * t13r + c5 * t14r + c3 * t15r;
/* 3549 */         float y2i = t11i + c2 * t12i + c4 * t13i + c5 * t14i + c3 * t15i;
/* 3550 */         float y3r = t11r + c3 * t12r + c5 * t13r + c2 * t14r + c1 * t15r;
/* 3551 */         float y3i = t11i + c3 * t12i + c5 * t13i + c2 * t14i + c1 * t15i;
/* 3552 */         float y4r = t11r + c4 * t12r + c3 * t13r + c1 * t14r + c5 * t15r;
/* 3553 */         float y4i = t11i + c4 * t12i + c3 * t13i + c1 * t14i + c5 * t15i;
/* 3554 */         float y5r = t11r + c5 * t12r + c1 * t13r + c4 * t14r + c2 * t15r;
/* 3555 */         float y5i = t11i + c5 * t12i + c1 * t13i + c4 * t14i + c2 * t15i;
/* 3556 */         float y6r = c10 * t6r - c6 * t7r + c9 * t8r - c7 * t9r + c8 * t10r;
/* 3557 */         float y6i = c10 * t6i - c6 * t7i + c9 * t8i - c7 * t9i + c8 * t10i;
/* 3558 */         float y7r = c9 * t6r - c8 * t7r + c6 * t8r + c10 * t9r - c7 * t10r;
/* 3559 */         float y7i = c9 * t6i - c8 * t7i + c6 * t8i + c10 * t9i - c7 * t10i;
/* 3560 */         float y8r = c8 * t6r - c10 * t7r - c7 * t8r + c6 * t9r + c9 * t10r;
/* 3561 */         float y8i = c8 * t6i - c10 * t7i - c7 * t8i + c6 * t9i + c9 * t10i;
/* 3562 */         float y9r = c7 * t6r + c9 * t7r - c10 * t8r - c8 * t9r - c6 * t10r;
/* 3563 */         float y9i = c7 * t6i + c9 * t7i - c10 * t8i - c8 * t9i - c6 * t10i;
/* 3564 */         float y10r = c6 * t6r + c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r;
/* 3565 */         float y10i = c6 * t6i + c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i;
/* 3566 */         zj0r[i1] = zj0r[i1] + t1r + t2r + t3r + t4r + t5r;
/* 3567 */         zj0i[i1] = zj0i[i1] + t1i + t2i + t3i + t4i + t5i;
/* 3568 */         zj1r[i1] = y1r - y10i;
/* 3569 */         zj1i[i1] = y1i + y10r;
/* 3570 */         zj2r[i1] = y2r - y9i;
/* 3571 */         zj2i[i1] = y2i + y9r;
/* 3572 */         zj3r[i1] = y3r - y8i;
/* 3573 */         zj3i[i1] = y3i + y8r;
/* 3574 */         zj4r[i1] = y4r - y7i;
/* 3575 */         zj4i[i1] = y4i + y7r;
/* 3576 */         zj5r[i1] = y5r - y6i;
/* 3577 */         zj5i[i1] = y5i + y6r;
/* 3578 */         zj6r[i1] = y5r + y6i;
/* 3579 */         zj6i[i1] = y5i - y6r;
/* 3580 */         zj7r[i1] = y4r + y7i;
/* 3581 */         zj7i[i1] = y4i - y7r;
/* 3582 */         zj8r[i1] = y3r + y8i;
/* 3583 */         zj8i[i1] = y3i - y8r;
/* 3584 */         zj9r[i1] = y2r + y9i;
/* 3585 */         zj9i[i1] = y2i - y9r;
/* 3586 */         zj10r[i1] = y1r + y10i;
/* 3587 */         zj10i[i1] = y1i - y10r;
/*      */       } 
/* 3589 */       int jt = j10 + 2;
/* 3590 */       j10 = j9 + 2;
/* 3591 */       j9 = j8 + 2;
/* 3592 */       j8 = j7 + 2;
/* 3593 */       j7 = j6 + 2;
/* 3594 */       j6 = j5 + 2;
/* 3595 */       j5 = j4 + 2;
/* 3596 */       j4 = j3 + 2;
/* 3597 */       j3 = j2 + 2;
/* 3598 */       j2 = j1 + 2;
/* 3599 */       j1 = j0 + 2;
/* 3600 */       j0 = jt;
/*      */     }  } private static void pfa13b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12) { float c1; float c2; float c3; float c4; float c5; float c6;
/*      */     float c7;
/*      */     float c8;
/*      */     float c9;
/*      */     float c10;
/*      */     float c11;
/*      */     float c12;
/* 3608 */     if (mu == 1) {
/* 3609 */       c1 = 0.885456F;
/* 3610 */       c2 = 0.56806475F;
/* 3611 */       c3 = 0.12053668F;
/* 3612 */       c4 = -0.3546049F;
/* 3613 */       c5 = -0.7485107F;
/* 3614 */       c6 = -0.97094184F;
/* 3615 */       c7 = 0.46472317F;
/* 3616 */       c8 = 0.82298386F;
/* 3617 */       c9 = 0.99270886F;
/* 3618 */       c10 = 0.9350162F;
/* 3619 */       c11 = 0.66312265F;
/* 3620 */       c12 = 0.23931566F;
/* 3621 */     } else if (mu == 2) {
/* 3622 */       c1 = 0.56806475F;
/* 3623 */       c2 = -0.3546049F;
/* 3624 */       c3 = -0.97094184F;
/* 3625 */       c4 = -0.7485107F;
/* 3626 */       c5 = 0.12053668F;
/* 3627 */       c6 = 0.885456F;
/* 3628 */       c7 = 0.82298386F;
/* 3629 */       c8 = 0.9350162F;
/* 3630 */       c9 = 0.23931566F;
/* 3631 */       c10 = -0.66312265F;
/* 3632 */       c11 = -0.99270886F;
/* 3633 */       c12 = -0.46472317F;
/* 3634 */     } else if (mu == 3) {
/* 3635 */       c1 = 0.12053668F;
/* 3636 */       c2 = -0.97094184F;
/* 3637 */       c3 = -0.3546049F;
/* 3638 */       c4 = 0.885456F;
/* 3639 */       c5 = 0.56806475F;
/* 3640 */       c6 = -0.7485107F;
/* 3641 */       c7 = 0.99270886F;
/* 3642 */       c8 = 0.23931566F;
/* 3643 */       c9 = -0.9350162F;
/* 3644 */       c10 = -0.46472317F;
/* 3645 */       c11 = 0.82298386F;
/* 3646 */       c12 = 0.66312265F;
/* 3647 */     } else if (mu == 4) {
/* 3648 */       c1 = -0.3546049F;
/* 3649 */       c2 = -0.7485107F;
/* 3650 */       c3 = 0.885456F;
/* 3651 */       c4 = 0.12053668F;
/* 3652 */       c5 = -0.97094184F;
/* 3653 */       c6 = 0.56806475F;
/* 3654 */       c7 = 0.9350162F;
/* 3655 */       c8 = -0.66312265F;
/* 3656 */       c9 = -0.46472317F;
/* 3657 */       c10 = 0.99270886F;
/* 3658 */       c11 = -0.23931566F;
/* 3659 */       c12 = -0.82298386F;
/* 3660 */     } else if (mu == 5) {
/* 3661 */       c1 = -0.7485107F;
/* 3662 */       c2 = 0.12053668F;
/* 3663 */       c3 = 0.56806475F;
/* 3664 */       c4 = -0.97094184F;
/* 3665 */       c5 = 0.885456F;
/* 3666 */       c6 = -0.3546049F;
/* 3667 */       c7 = 0.66312265F;
/* 3668 */       c8 = -0.99270886F;
/* 3669 */       c9 = 0.82298386F;
/* 3670 */       c10 = -0.23931566F;
/* 3671 */       c11 = -0.46472317F;
/* 3672 */       c12 = 0.9350162F;
/* 3673 */     } else if (mu == 6) {
/* 3674 */       c1 = -0.97094184F;
/* 3675 */       c2 = 0.885456F;
/* 3676 */       c3 = -0.7485107F;
/* 3677 */       c4 = 0.56806475F;
/* 3678 */       c5 = -0.3546049F;
/* 3679 */       c6 = 0.12053668F;
/* 3680 */       c7 = 0.23931566F;
/* 3681 */       c8 = -0.46472317F;
/* 3682 */       c9 = 0.66312265F;
/* 3683 */       c10 = -0.82298386F;
/* 3684 */       c11 = 0.9350162F;
/* 3685 */       c12 = -0.99270886F;
/* 3686 */     } else if (mu == 7) {
/* 3687 */       c1 = -0.97094184F;
/* 3688 */       c2 = 0.885456F;
/* 3689 */       c3 = -0.7485107F;
/* 3690 */       c4 = 0.56806475F;
/* 3691 */       c5 = -0.3546049F;
/* 3692 */       c6 = 0.12053668F;
/* 3693 */       c7 = -0.23931566F;
/* 3694 */       c8 = 0.46472317F;
/* 3695 */       c9 = -0.66312265F;
/* 3696 */       c10 = 0.82298386F;
/* 3697 */       c11 = -0.9350162F;
/* 3698 */       c12 = 0.99270886F;
/* 3699 */     } else if (mu == 8) {
/* 3700 */       c1 = -0.7485107F;
/* 3701 */       c2 = 0.12053668F;
/* 3702 */       c3 = 0.56806475F;
/* 3703 */       c4 = -0.97094184F;
/* 3704 */       c5 = 0.885456F;
/* 3705 */       c6 = -0.3546049F;
/* 3706 */       c7 = -0.66312265F;
/* 3707 */       c8 = 0.99270886F;
/* 3708 */       c9 = -0.82298386F;
/* 3709 */       c10 = 0.23931566F;
/* 3710 */       c11 = 0.46472317F;
/* 3711 */       c12 = -0.9350162F;
/* 3712 */     } else if (mu == 9) {
/* 3713 */       c1 = -0.3546049F;
/* 3714 */       c2 = -0.7485107F;
/* 3715 */       c3 = 0.885456F;
/* 3716 */       c4 = 0.12053668F;
/* 3717 */       c5 = -0.97094184F;
/* 3718 */       c6 = 0.56806475F;
/* 3719 */       c7 = -0.9350162F;
/* 3720 */       c8 = 0.66312265F;
/* 3721 */       c9 = 0.46472317F;
/* 3722 */       c10 = -0.99270886F;
/* 3723 */       c11 = 0.23931566F;
/* 3724 */       c12 = 0.82298386F;
/* 3725 */     } else if (mu == 10) {
/* 3726 */       c1 = 0.12053668F;
/* 3727 */       c2 = -0.97094184F;
/* 3728 */       c3 = -0.3546049F;
/* 3729 */       c4 = 0.885456F;
/* 3730 */       c5 = 0.56806475F;
/* 3731 */       c6 = -0.7485107F;
/* 3732 */       c7 = -0.99270886F;
/* 3733 */       c8 = -0.23931566F;
/* 3734 */       c9 = 0.9350162F;
/* 3735 */       c10 = 0.46472317F;
/* 3736 */       c11 = -0.82298386F;
/* 3737 */       c12 = -0.66312265F;
/* 3738 */     } else if (mu == 11) {
/* 3739 */       c1 = 0.56806475F;
/* 3740 */       c2 = -0.3546049F;
/* 3741 */       c3 = -0.97094184F;
/* 3742 */       c4 = -0.7485107F;
/* 3743 */       c5 = 0.12053668F;
/* 3744 */       c6 = 0.885456F;
/* 3745 */       c7 = -0.82298386F;
/* 3746 */       c8 = -0.9350162F;
/* 3747 */       c9 = -0.23931566F;
/* 3748 */       c10 = 0.66312265F;
/* 3749 */       c11 = 0.99270886F;
/* 3750 */       c12 = 0.46472317F;
/*      */     } else {
/* 3752 */       c1 = 0.885456F;
/* 3753 */       c2 = 0.56806475F;
/* 3754 */       c3 = 0.12053668F;
/* 3755 */       c4 = -0.3546049F;
/* 3756 */       c5 = -0.7485107F;
/* 3757 */       c6 = -0.97094184F;
/* 3758 */       c7 = -0.46472317F;
/* 3759 */       c8 = -0.82298386F;
/* 3760 */       c9 = -0.99270886F;
/* 3761 */       c10 = -0.9350162F;
/* 3762 */       c11 = -0.66312265F;
/* 3763 */       c12 = -0.23931566F;
/*      */     } 
/* 3765 */     for (int i = 0; i < m; i++) {
/* 3766 */       float[] zj0r = z[j0];
/* 3767 */       float[] zj0i = z[j0 + 1];
/* 3768 */       float[] zj1r = z[j1];
/* 3769 */       float[] zj1i = z[j1 + 1];
/* 3770 */       float[] zj2r = z[j2];
/* 3771 */       float[] zj2i = z[j2 + 1];
/* 3772 */       float[] zj3r = z[j3];
/* 3773 */       float[] zj3i = z[j3 + 1];
/* 3774 */       float[] zj4r = z[j4];
/* 3775 */       float[] zj4i = z[j4 + 1];
/* 3776 */       float[] zj5r = z[j5];
/* 3777 */       float[] zj5i = z[j5 + 1];
/* 3778 */       float[] zj6r = z[j6];
/* 3779 */       float[] zj6i = z[j6 + 1];
/* 3780 */       float[] zj7r = z[j7];
/* 3781 */       float[] zj7i = z[j7 + 1];
/* 3782 */       float[] zj8r = z[j8];
/* 3783 */       float[] zj8i = z[j8 + 1];
/* 3784 */       float[] zj9r = z[j9];
/* 3785 */       float[] zj9i = z[j9 + 1];
/* 3786 */       float[] zj10r = z[j10];
/* 3787 */       float[] zj10i = z[j10 + 1];
/* 3788 */       float[] zj11r = z[j11];
/* 3789 */       float[] zj11i = z[j11 + 1];
/* 3790 */       float[] zj12r = z[j12];
/* 3791 */       float[] zj12i = z[j12 + 1];
/* 3792 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3793 */         float t1r = zj1r[i1] + zj12r[i1];
/* 3794 */         float t1i = zj1i[i1] + zj12i[i1];
/* 3795 */         float t2r = zj2r[i1] + zj11r[i1];
/* 3796 */         float t2i = zj2i[i1] + zj11i[i1];
/* 3797 */         float t3r = zj3r[i1] + zj10r[i1];
/* 3798 */         float t3i = zj3i[i1] + zj10i[i1];
/* 3799 */         float t4r = zj4r[i1] + zj9r[i1];
/* 3800 */         float t4i = zj4i[i1] + zj9i[i1];
/* 3801 */         float t5r = zj5r[i1] + zj8r[i1];
/* 3802 */         float t5i = zj5i[i1] + zj8i[i1];
/* 3803 */         float t6r = zj6r[i1] + zj7r[i1];
/* 3804 */         float t6i = zj6i[i1] + zj7i[i1];
/* 3805 */         float t7r = zj1r[i1] - zj12r[i1];
/* 3806 */         float t7i = zj1i[i1] - zj12i[i1];
/* 3807 */         float t8r = zj2r[i1] - zj11r[i1];
/* 3808 */         float t8i = zj2i[i1] - zj11i[i1];
/* 3809 */         float t9r = zj3r[i1] - zj10r[i1];
/* 3810 */         float t9i = zj3i[i1] - zj10i[i1];
/* 3811 */         float t10r = zj4r[i1] - zj9r[i1];
/* 3812 */         float t10i = zj4i[i1] - zj9i[i1];
/* 3813 */         float t11r = zj5r[i1] - zj8r[i1];
/* 3814 */         float t11i = zj5i[i1] - zj8i[i1];
/* 3815 */         float t12r = zj6r[i1] - zj7r[i1];
/* 3816 */         float t12i = zj6i[i1] - zj7i[i1];
/* 3817 */         float t13r = zj0r[i1] - 0.5F * t6r;
/* 3818 */         float t13i = zj0i[i1] - 0.5F * t6i;
/* 3819 */         float t14r = t1r - t6r;
/* 3820 */         float t14i = t1i - t6i;
/* 3821 */         float t15r = t2r - t6r;
/* 3822 */         float t15i = t2i - t6i;
/* 3823 */         float t16r = t3r - t6r;
/* 3824 */         float t16i = t3i - t6i;
/* 3825 */         float t17r = t4r - t6r;
/* 3826 */         float t17i = t4i - t6i;
/* 3827 */         float t18r = t5r - t6r;
/* 3828 */         float t18i = t5i - t6i;
/* 3829 */         float y1r = t13r + c1 * t14r + c2 * t15r + c3 * t16r + c4 * t17r + c5 * t18r;
/* 3830 */         float y1i = t13i + c1 * t14i + c2 * t15i + c3 * t16i + c4 * t17i + c5 * t18i;
/* 3831 */         float y2r = t13r + c2 * t14r + c4 * t15r + c6 * t16r + c5 * t17r + c3 * t18r;
/* 3832 */         float y2i = t13i + c2 * t14i + c4 * t15i + c6 * t16i + c5 * t17i + c3 * t18i;
/* 3833 */         float y3r = t13r + c3 * t14r + c6 * t15r + c4 * t16r + c1 * t17r + c2 * t18r;
/* 3834 */         float y3i = t13i + c3 * t14i + c6 * t15i + c4 * t16i + c1 * t17i + c2 * t18i;
/* 3835 */         float y4r = t13r + c4 * t14r + c5 * t15r + c1 * t16r + c3 * t17r + c6 * t18r;
/* 3836 */         float y4i = t13i + c4 * t14i + c5 * t15i + c1 * t16i + c3 * t17i + c6 * t18i;
/* 3837 */         float y5r = t13r + c5 * t14r + c3 * t15r + c2 * t16r + c6 * t17r + c1 * t18r;
/* 3838 */         float y5i = t13i + c5 * t14i + c3 * t15i + c2 * t16i + c6 * t17i + c1 * t18i;
/* 3839 */         float y6r = t13r + c6 * t14r + c1 * t15r + c5 * t16r + c2 * t17r + c4 * t18r;
/* 3840 */         float y6i = t13i + c6 * t14i + c1 * t15i + c5 * t16i + c2 * t17i + c4 * t18i;
/* 3841 */         float y7r = c12 * t7r - c7 * t8r + c11 * t9r - c8 * t10r + c10 * t11r - c9 * t12r;
/* 3842 */         float y7i = c12 * t7i - c7 * t8i + c11 * t9i - c8 * t10i + c10 * t11i - c9 * t12i;
/* 3843 */         float y8r = c11 * t7r - c9 * t8r + c8 * t9r - c12 * t10r - c7 * t11r + c10 * t12r;
/* 3844 */         float y8i = c11 * t7i - c9 * t8i + c8 * t9i - c12 * t10i - c7 * t11i + c10 * t12i;
/* 3845 */         float y9r = c10 * t7r - c11 * t8r - c7 * t9r + c9 * t10r - c12 * t11r - c8 * t12r;
/* 3846 */         float y9i = c10 * t7i - c11 * t8i - c7 * t9i + c9 * t10i - c12 * t11i - c8 * t12i;
/* 3847 */         float y10r = c9 * t7r + c12 * t8r - c10 * t9r - c7 * t10r + c8 * t11r + c11 * t12r;
/* 3848 */         float y10i = c9 * t7i + c12 * t8i - c10 * t9i - c7 * t10i + c8 * t11i + c11 * t12i;
/* 3849 */         float y11r = c8 * t7r + c10 * t8r + c12 * t9r - c11 * t10r - c9 * t11r - c7 * t12r;
/* 3850 */         float y11i = c8 * t7i + c10 * t8i + c12 * t9i - c11 * t10i - c9 * t11i - c7 * t12i;
/* 3851 */         float y12r = c7 * t7r + c8 * t8r + c9 * t9r + c10 * t10r + c11 * t11r + c12 * t12r;
/* 3852 */         float y12i = c7 * t7i + c8 * t8i + c9 * t9i + c10 * t10i + c11 * t11i + c12 * t12i;
/* 3853 */         zj0r[i1] = zj0r[i1] + t1r + t2r + t3r + t4r + t5r + t6r;
/* 3854 */         zj0i[i1] = zj0i[i1] + t1i + t2i + t3i + t4i + t5i + t6i;
/* 3855 */         zj1r[i1] = y1r - y12i;
/* 3856 */         zj1i[i1] = y1i + y12r;
/* 3857 */         zj2r[i1] = y2r - y11i;
/* 3858 */         zj2i[i1] = y2i + y11r;
/* 3859 */         zj3r[i1] = y3r - y10i;
/* 3860 */         zj3i[i1] = y3i + y10r;
/* 3861 */         zj4r[i1] = y4r - y9i;
/* 3862 */         zj4i[i1] = y4i + y9r;
/* 3863 */         zj5r[i1] = y5r - y8i;
/* 3864 */         zj5i[i1] = y5i + y8r;
/* 3865 */         zj6r[i1] = y6r - y7i;
/* 3866 */         zj6i[i1] = y6i + y7r;
/* 3867 */         zj7r[i1] = y6r + y7i;
/* 3868 */         zj7i[i1] = y6i - y7r;
/* 3869 */         zj8r[i1] = y5r + y8i;
/* 3870 */         zj8i[i1] = y5i - y8r;
/* 3871 */         zj9r[i1] = y4r + y9i;
/* 3872 */         zj9i[i1] = y4i - y9r;
/* 3873 */         zj10r[i1] = y3r + y10i;
/* 3874 */         zj10i[i1] = y3i - y10r;
/* 3875 */         zj11r[i1] = y2r + y11i;
/* 3876 */         zj11i[i1] = y2i - y11r;
/* 3877 */         zj12r[i1] = y1r + y12i;
/* 3878 */         zj12i[i1] = y1i - y12r;
/*      */       } 
/* 3880 */       int jt = j12 + 2;
/* 3881 */       j12 = j11 + 2;
/* 3882 */       j11 = j10 + 2;
/* 3883 */       j10 = j9 + 2;
/* 3884 */       j9 = j8 + 2;
/* 3885 */       j8 = j7 + 2;
/* 3886 */       j7 = j6 + 2;
/* 3887 */       j6 = j5 + 2;
/* 3888 */       j5 = j4 + 2;
/* 3889 */       j4 = j3 + 2;
/* 3890 */       j3 = j2 + 2;
/* 3891 */       j2 = j1 + 2;
/* 3892 */       j1 = j0 + 2;
/* 3893 */       j0 = jt;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pfa16b(int n1, float[][] z, int mu, int m, int j0, int j1, int j2, int j3, int j4, int j5, int j6, int j7, int j8, int j9, int j10, int j11, int j12, int j13, int j14, int j15) {
/*      */     float c1, c2, c3, c4;
/* 3901 */     if (mu == 1) {
/* 3902 */       c1 = 1.0F;
/* 3903 */       c2 = 0.9238795F;
/* 3904 */       c3 = 0.38268343F;
/* 3905 */       c4 = 0.70710677F;
/* 3906 */     } else if (mu == 3) {
/* 3907 */       c1 = -1.0F;
/* 3908 */       c2 = 0.38268343F;
/* 3909 */       c3 = 0.9238795F;
/* 3910 */       c4 = -0.70710677F;
/* 3911 */     } else if (mu == 5) {
/* 3912 */       c1 = 1.0F;
/* 3913 */       c2 = -0.38268343F;
/* 3914 */       c3 = 0.9238795F;
/* 3915 */       c4 = -0.70710677F;
/* 3916 */     } else if (mu == 7) {
/* 3917 */       c1 = -1.0F;
/* 3918 */       c2 = -0.9238795F;
/* 3919 */       c3 = 0.38268343F;
/* 3920 */       c4 = 0.70710677F;
/* 3921 */     } else if (mu == 9) {
/* 3922 */       c1 = 1.0F;
/* 3923 */       c2 = -0.9238795F;
/* 3924 */       c3 = -0.38268343F;
/* 3925 */       c4 = 0.70710677F;
/* 3926 */     } else if (mu == 11) {
/* 3927 */       c1 = -1.0F;
/* 3928 */       c2 = -0.38268343F;
/* 3929 */       c3 = -0.9238795F;
/* 3930 */       c4 = -0.70710677F;
/* 3931 */     } else if (mu == 13) {
/* 3932 */       c1 = 1.0F;
/* 3933 */       c2 = 0.38268343F;
/* 3934 */       c3 = -0.9238795F;
/* 3935 */       c4 = -0.70710677F;
/*      */     } else {
/* 3937 */       c1 = -1.0F;
/* 3938 */       c2 = 0.9238795F;
/* 3939 */       c3 = -0.38268343F;
/* 3940 */       c4 = 0.70710677F;
/*      */     } 
/* 3942 */     float c5 = c1 * c4;
/* 3943 */     float c6 = c1 * c3;
/* 3944 */     float c7 = c1 * c2;
/* 3945 */     for (int i = 0; i < m; i++) {
/* 3946 */       float[] zj0r = z[j0];
/* 3947 */       float[] zj0i = z[j0 + 1];
/* 3948 */       float[] zj1r = z[j1];
/* 3949 */       float[] zj1i = z[j1 + 1];
/* 3950 */       float[] zj2r = z[j2];
/* 3951 */       float[] zj2i = z[j2 + 1];
/* 3952 */       float[] zj3r = z[j3];
/* 3953 */       float[] zj3i = z[j3 + 1];
/* 3954 */       float[] zj4r = z[j4];
/* 3955 */       float[] zj4i = z[j4 + 1];
/* 3956 */       float[] zj5r = z[j5];
/* 3957 */       float[] zj5i = z[j5 + 1];
/* 3958 */       float[] zj6r = z[j6];
/* 3959 */       float[] zj6i = z[j6 + 1];
/* 3960 */       float[] zj7r = z[j7];
/* 3961 */       float[] zj7i = z[j7 + 1];
/* 3962 */       float[] zj8r = z[j8];
/* 3963 */       float[] zj8i = z[j8 + 1];
/* 3964 */       float[] zj9r = z[j9];
/* 3965 */       float[] zj9i = z[j9 + 1];
/* 3966 */       float[] zj10r = z[j10];
/* 3967 */       float[] zj10i = z[j10 + 1];
/* 3968 */       float[] zj11r = z[j11];
/* 3969 */       float[] zj11i = z[j11 + 1];
/* 3970 */       float[] zj12r = z[j12];
/* 3971 */       float[] zj12i = z[j12 + 1];
/* 3972 */       float[] zj13r = z[j13];
/* 3973 */       float[] zj13i = z[j13 + 1];
/* 3974 */       float[] zj14r = z[j14];
/* 3975 */       float[] zj14i = z[j14 + 1];
/* 3976 */       float[] zj15r = z[j15];
/* 3977 */       float[] zj15i = z[j15 + 1];
/* 3978 */       for (int i1 = 0; i1 < n1; i1++) {
/* 3979 */         float t1r = zj0r[i1] + zj8r[i1];
/* 3980 */         float t1i = zj0i[i1] + zj8i[i1];
/* 3981 */         float t2r = zj4r[i1] + zj12r[i1];
/* 3982 */         float t2i = zj4i[i1] + zj12i[i1];
/* 3983 */         float t3r = zj0r[i1] - zj8r[i1];
/* 3984 */         float t3i = zj0i[i1] - zj8i[i1];
/* 3985 */         float t4r = c1 * (zj4r[i1] - zj12r[i1]);
/* 3986 */         float t4i = c1 * (zj4i[i1] - zj12i[i1]);
/* 3987 */         float t5r = t1r + t2r;
/* 3988 */         float t5i = t1i + t2i;
/* 3989 */         float t6r = t1r - t2r;
/* 3990 */         float t6i = t1i - t2i;
/* 3991 */         float t7r = zj1r[i1] + zj9r[i1];
/* 3992 */         float t7i = zj1i[i1] + zj9i[i1];
/* 3993 */         float t8r = zj5r[i1] + zj13r[i1];
/* 3994 */         float t8i = zj5i[i1] + zj13i[i1];
/* 3995 */         float t9r = zj1r[i1] - zj9r[i1];
/* 3996 */         float t9i = zj1i[i1] - zj9i[i1];
/* 3997 */         float t10r = zj5r[i1] - zj13r[i1];
/* 3998 */         float t10i = zj5i[i1] - zj13i[i1];
/* 3999 */         float t11r = t7r + t8r;
/* 4000 */         float t11i = t7i + t8i;
/* 4001 */         float t12r = t7r - t8r;
/* 4002 */         float t12i = t7i - t8i;
/* 4003 */         float t13r = zj2r[i1] + zj10r[i1];
/* 4004 */         float t13i = zj2i[i1] + zj10i[i1];
/* 4005 */         float t14r = zj6r[i1] + zj14r[i1];
/* 4006 */         float t14i = zj6i[i1] + zj14i[i1];
/* 4007 */         float t15r = zj2r[i1] - zj10r[i1];
/* 4008 */         float t15i = zj2i[i1] - zj10i[i1];
/* 4009 */         float t16r = zj6r[i1] - zj14r[i1];
/* 4010 */         float t16i = zj6i[i1] - zj14i[i1];
/* 4011 */         float t17r = t13r + t14r;
/* 4012 */         float t17i = t13i + t14i;
/* 4013 */         float t18r = c4 * (t15r - t16r);
/* 4014 */         float t18i = c4 * (t15i - t16i);
/* 4015 */         float t19r = c5 * (t15r + t16r);
/* 4016 */         float t19i = c5 * (t15i + t16i);
/* 4017 */         float t20r = c1 * (t13r - t14r);
/* 4018 */         float t20i = c1 * (t13i - t14i);
/* 4019 */         float t21r = zj3r[i1] + zj11r[i1];
/* 4020 */         float t21i = zj3i[i1] + zj11i[i1];
/* 4021 */         float t22r = zj7r[i1] + zj15r[i1];
/* 4022 */         float t22i = zj7i[i1] + zj15i[i1];
/* 4023 */         float t23r = zj3r[i1] - zj11r[i1];
/* 4024 */         float t23i = zj3i[i1] - zj11i[i1];
/* 4025 */         float t24r = zj7r[i1] - zj15r[i1];
/* 4026 */         float t24i = zj7i[i1] - zj15i[i1];
/* 4027 */         float t25r = t21r + t22r;
/* 4028 */         float t25i = t21i + t22i;
/* 4029 */         float t26r = t21r - t22r;
/* 4030 */         float t26i = t21i - t22i;
/* 4031 */         float t27r = t9r + t24r;
/* 4032 */         float t27i = t9i + t24i;
/* 4033 */         float t28r = t10r + t23r;
/* 4034 */         float t28i = t10i + t23i;
/* 4035 */         float t29r = t9r - t24r;
/* 4036 */         float t29i = t9i - t24i;
/* 4037 */         float t30r = t10r - t23r;
/* 4038 */         float t30i = t10i - t23i;
/* 4039 */         float t31r = t5r + t17r;
/* 4040 */         float t31i = t5i + t17i;
/* 4041 */         float t32r = t11r + t25r;
/* 4042 */         float t32i = t11i + t25i;
/* 4043 */         float t33r = t3r + t18r;
/* 4044 */         float t33i = t3i + t18i;
/* 4045 */         float t34r = c2 * t29r - c6 * t30r;
/* 4046 */         float t34i = c2 * t29i - c6 * t30i;
/* 4047 */         float t35r = t3r - t18r;
/* 4048 */         float t35i = t3i - t18i;
/* 4049 */         float t36r = c7 * t27r - c3 * t28r;
/* 4050 */         float t36i = c7 * t27i - c3 * t28i;
/* 4051 */         float t37r = t4r + t19r;
/* 4052 */         float t37i = t4i + t19i;
/* 4053 */         float t38r = c3 * t27r + c7 * t28r;
/* 4054 */         float t38i = c3 * t27i + c7 * t28i;
/* 4055 */         float t39r = t4r - t19r;
/* 4056 */         float t39i = t4i - t19i;
/* 4057 */         float t40r = c6 * t29r + c2 * t30r;
/* 4058 */         float t40i = c6 * t29i + c2 * t30i;
/* 4059 */         float t41r = c4 * (t12r - t26r);
/* 4060 */         float t41i = c4 * (t12i - t26i);
/* 4061 */         float t42r = c5 * (t12r + t26r);
/* 4062 */         float t42i = c5 * (t12i + t26i);
/* 4063 */         float y1r = t33r + t34r;
/* 4064 */         float y1i = t33i + t34i;
/* 4065 */         float y2r = t6r + t41r;
/* 4066 */         float y2i = t6i + t41i;
/* 4067 */         float y3r = t35r + t40r;
/* 4068 */         float y3i = t35i + t40i;
/* 4069 */         float y4r = t5r - t17r;
/* 4070 */         float y4i = t5i - t17i;
/* 4071 */         float y5r = t35r - t40r;
/* 4072 */         float y5i = t35i - t40i;
/* 4073 */         float y6r = t6r - t41r;
/* 4074 */         float y6i = t6i - t41i;
/* 4075 */         float y7r = t33r - t34r;
/* 4076 */         float y7i = t33i - t34i;
/* 4077 */         float y9r = t38r - t37r;
/* 4078 */         float y9i = t38i - t37i;
/* 4079 */         float y10r = t42r - t20r;
/* 4080 */         float y10i = t42i - t20i;
/* 4081 */         float y11r = t36r + t39r;
/* 4082 */         float y11i = t36i + t39i;
/* 4083 */         float y12r = c1 * (t11r - t25r);
/* 4084 */         float y12i = c1 * (t11i - t25i);
/* 4085 */         float y13r = t36r - t39r;
/* 4086 */         float y13i = t36i - t39i;
/* 4087 */         float y14r = t42r + t20r;
/* 4088 */         float y14i = t42i + t20i;
/* 4089 */         float y15r = t38r + t37r;
/* 4090 */         float y15i = t38i + t37i;
/* 4091 */         zj0r[i1] = t31r + t32r;
/* 4092 */         zj0i[i1] = t31i + t32i;
/* 4093 */         zj1r[i1] = y1r - y15i;
/* 4094 */         zj1i[i1] = y1i + y15r;
/* 4095 */         zj2r[i1] = y2r - y14i;
/* 4096 */         zj2i[i1] = y2i + y14r;
/* 4097 */         zj3r[i1] = y3r - y13i;
/* 4098 */         zj3i[i1] = y3i + y13r;
/* 4099 */         zj4r[i1] = y4r - y12i;
/* 4100 */         zj4i[i1] = y4i + y12r;
/* 4101 */         zj5r[i1] = y5r - y11i;
/* 4102 */         zj5i[i1] = y5i + y11r;
/* 4103 */         zj6r[i1] = y6r - y10i;
/* 4104 */         zj6i[i1] = y6i + y10r;
/* 4105 */         zj7r[i1] = y7r - y9i;
/* 4106 */         zj7i[i1] = y7i + y9r;
/* 4107 */         zj8r[i1] = t31r - t32r;
/* 4108 */         zj8i[i1] = t31i - t32i;
/* 4109 */         zj9r[i1] = y7r + y9i;
/* 4110 */         zj9i[i1] = y7i - y9r;
/* 4111 */         zj10r[i1] = y6r + y10i;
/* 4112 */         zj10i[i1] = y6i - y10r;
/* 4113 */         zj11r[i1] = y5r + y11i;
/* 4114 */         zj11i[i1] = y5i - y11r;
/* 4115 */         zj12r[i1] = y4r + y12i;
/* 4116 */         zj12i[i1] = y4i - y12r;
/* 4117 */         zj13r[i1] = y3r + y13i;
/* 4118 */         zj13i[i1] = y3i - y13r;
/* 4119 */         zj14r[i1] = y2r + y14i;
/* 4120 */         zj14i[i1] = y2i - y14r;
/* 4121 */         zj15r[i1] = y1r + y15i;
/* 4122 */         zj15i[i1] = y1i - y15r;
/*      */       } 
/* 4124 */       int jt = j15 + 2;
/* 4125 */       j15 = j14 + 2;
/* 4126 */       j14 = j13 + 2;
/* 4127 */       j13 = j12 + 2;
/* 4128 */       j12 = j11 + 2;
/* 4129 */       j11 = j10 + 2;
/* 4130 */       j10 = j9 + 2;
/* 4131 */       j9 = j8 + 2;
/* 4132 */       j8 = j7 + 2;
/* 4133 */       j7 = j6 + 2;
/* 4134 */       j6 = j5 + 2;
/* 4135 */       j5 = j4 + 2;
/* 4136 */       j4 = j3 + 2;
/* 4137 */       j3 = j2 + 2;
/* 4138 */       j2 = j1 + 2;
/* 4139 */       j1 = j0 + 2;
/* 4140 */       j0 = jt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4191 */   private static final int[] _kfac = new int[] { 16, 13, 11, 9, 8, 7, 5, 4, 3, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NTABLE = 240;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4201 */   private static final int[] _ntable = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 21, 22, 24, 26, 28, 30, 33, 35, 36, 39, 40, 42, 44, 45, 48, 52, 55, 56, 60, 63, 65, 66, 70, 72, 77, 78, 80, 84, 88, 90, 91, 99, 104, 105, 110, 112, 117, 120, 126, 130, 132, 140, 143, 144, 154, 156, 165, 168, 176, 180, 182, 195, 198, 208, 210, 220, 231, 234, 240, 252, 260, 264, 273, 280, 286, 308, 312, 315, 330, 336, 360, 364, 385, 390, 396, 420, 429, 440, 455, 462, 468, 495, 504, 520, 528, 546, 560, 572, 585, 616, 624, 630, 660, 693, 715, 720, 728, 770, 780, 792, 819, 840, 858, 880, 910, 924, 936, 990, 1001, 1008, 1040, 1092, 1144, 1155, 1170, 1232, 1260, 1287, 1320, 1365, 1386, 1430, 1456, 1540, 1560, 1584, 1638, 1680, 1716, 1820, 1848, 1872, 1980, 2002, 2145, 2184, 2288, 2310, 2340, 2520, 2574, 2640, 2730, 2772, 2860, 3003, 3080, 3120, 3276, 3432, 3465, 3640, 3696, 3960, 4004, 4095, 4290, 4368, 4620, 4680, 5005, 5040, 5148, 5460, 5544, 5720, 6006, 6160, 6435, 6552, 6864, 6930, 7280, 7920, 8008, 8190, 8580, 9009, 9240, 9360, 10010, 10296, 10920, 11088, 11440, 12012, 12870, 13104, 13860, 15015, 16016, 16380, 17160, 18018, 18480, 20020, 20592, 21840, 24024, 25740, 27720, 30030, 32760, 34320, 36036, 40040, 45045, 48048, 51480, 55440, 60060, 65520, 72072, 80080, 90090, 102960, 120120, 144144, 180180, 240240, 360360, 720720 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4230 */   private static final double[] _ctable = new double[] { 1.54844595E-6D, 1.60858985E-6D, 1.73777398E-6D, 1.78300246E-6D, 1.86692603E-6D, 2.02796424E-6D, 2.05593203E-6D, 2.03027471E-6D, 2.13199871E-6D, 2.23464061E-6D, 2.45504197E-6D, 2.24507775E-6D, 2.77484785E-6D, 2.71335681E-6D, 2.60084271E-6D, 2.66712117E-6D, 2.77849063E-6D, 2.84002694E-6D, 3.17837121E-6D, 3.73373597E-6D, 3.15791133E-6D, 4.24124687E-6D, 3.58681599E-6D, 3.74904075E-6D, 4.74708669E-6D, 4.38838644E-6D, 4.01250829E-6D, 5.62735292E-6D, 4.3411639E-6D, 5.17084182E-6D, 5.52020262E-6D, 4.98530294E-6D, 5.2024893E-6D, 6.81986102E-6D, 7.10553295E-6D, 5.93798174E-6D, 5.87481339E-6D, 7.01743322E-6D, 8.61901953E-6D, 8.32813604E-6D, 7.91730898E-6D, 6.8840368E-6D, 1.002803645E-5D, 1.02678457E-5D, 8.19893573E-6D, 8.28260941E-6D, 1.014724144E-5D, 9.34954606E-6D, 1.232645727E-5D, 1.214189591E-5D, 1.269497208E-5D, 1.102202755E-5D, 1.388176589E-5D, 1.172641106E-5D, 1.503375461E-5D, 1.113972204E-5D, 1.364655225E-5D, 1.703912278E-5D, 1.477596306E-5D, 1.424973677E-5D, 2.127456187E-5D, 1.398938399E-5D, 2.00864429E-5D, 1.869909587E-5D, 1.986433148E-5D, 1.651781665E-5D, 2.092824006E-5D, 1.702478496E-5D, 2.499906394E-5D, 2.500343282E-5D, 2.465807389E-5D, 2.632305568E-5D, 2.308853872E-5D, 2.566435179E-5D, 2.996843066E-5D, 3.179869821E-5D, 2.372351388E-5D, 2.578195392E-5D, 3.236648622E-5D, 3.062192175E-5D, 3.688562326E-5D, 2.903319322E-5D, 4.464405117E-5D, 3.835181037E-5D, 3.890755813E-5D, 3.489790229E-5D, 4.193095941E-5D, 3.661590772E-5D, 3.585050946E-5D, 4.948000296E-5D, 5.19463679E-5D, 5.316664012E-5D, 4.831628715E-5D, 4.470982143E-5D, 6.71179171E-5D, 5.416880764E-5D, 6.503589644E-5D, 6.376341005E-5D, 6.060697752E-5D, 6.481361636E-5D, 5.49474666E-5D, 6.84295036E-5D, 6.725764749E-5D, 7.9550419E-5D, 6.51735139E-5D, 8.783546746E-5D, 8.145918907E-5D, 8.208007212E-5D, 8.453260181E-5D, 7.714824943E-5D, 8.332986646E-5D, 9.686623465E-5D, 1.1742291007E-4D, 8.016979016E-5D, 1.0372863801E-4D, 1.1169975463E-4D, 1.0527145635E-4D, 1.0259693695E-4D, 1.2171112596E-4D, 9.645574497E-5D, 1.4179527113E-4D, 1.1871442125E-4D, 1.4121545403E-4D, 1.2558781115E-4D, 1.2962723272E-4D, 1.4012872534E-4D, 1.7282139776E-4D, 1.2333743842E-4D, 1.5017243965E-4D, 1.5933147632E-4D, 1.8467637839E-4D, 1.6783978549E-4D, 1.7760241178E-4D, 1.8111945022E-4D, 1.5790303508E-4D, 2.1759913091E-4D, 1.7785473273E-4D, 2.1290391156E-4D, 2.1022786937E-4D, 2.5198138131E-4D, 2.2553766468E-4D, 2.2349921892E-4D, 2.2576645627E-4D, 2.2422478451E-4D, 2.6572035023E-4D, 2.1417878529E-4D, 2.8409252164E-4D, 2.8290960452E-4D, 2.6774495388E-4D, 2.8504340401E-4D, 2.8006152125E-4D, 3.7010347376E-4D, 3.7949981053E-4D, 3.3613022319E-4D, 4.0431974162E-4D, 3.6459661264E-4D, 3.535121779E-4D, 3.3107438017E-4D, 4.668997669E-4D, 3.9452432539E-4D, 4.564721969E-4D, 4.2150673401E-4D, 5.0466112371E-4D, 5.5797101449E-4D, 4.7941598851E-4D, 4.9189587426E-4D, 5.2933403805E-4D, 6.056849108E-4D, 5.6200897868E-4D, 6.0222489477E-4D, 5.884253819E-4D, 6.0084033613E-4D, 7.4850523169E-4D, 7.0305370305E-4D, 8.1422764228E-4D, 7.3423753666E-4D, 7.3504587156E-4D, 7.5785092698E-4D, 9.8138167565E-4D, 7.3504587156E-4D, 9.3946503989E-4D, 9.1880733945E-4D, 9.0674513354E-4D, 0.00105810882198D, 0.0012059000602D, 0.00104322916667D, 0.00124255583127D, 0.00113291855204D, 0.00130338541667D, 0.00122432762836D, 0.00130234070221D, 0.0013344437042D, 0.00158214849921D, 0.00153958493467D, 0.00166694421316D, 0.00183424908425D, 0.00157344854674D, 0.00164180327869D, 0.00210620399579D, 0.00198316831683D, 0.00195414634146D, 0.00197145669291D, 0.00228132118451D, 0.00241495778046D, 0.00264248021108D, 0.00243970767357D, 0.00246068796069D, 0.00314937106918D, 0.00341226575809D, 0.00304407294833D, 0.00342979452055D, 0.00391780821918D, 0.00339491525424D, 0.00423467230444D, 0.00427991452991D, 0.00422573839662D, 0.0051358974359D, 0.00532712765957D, 0.00522976501305D, 0.00671812080537D, 0.00644051446945D, 0.00747388059701D, 0.00785490196078D, 0.00890222222222D, 0.01032474226804D, 0.01088586956522D, 0.01131638418079D, 0.01125280898876D, 0.01371232876712D, 0.01390972222222D, 0.01663636363636D, 0.01917142857143D, 0.02201098901099D, 0.02425301204819D, 0.02849295774648D, 0.03531578947368D, 0.04575D, 0.06190909090909D, 0.10542105263158D, 0.24033333333333D };
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Pfacc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */