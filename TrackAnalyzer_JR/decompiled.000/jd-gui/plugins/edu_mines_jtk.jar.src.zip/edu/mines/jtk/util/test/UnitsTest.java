/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Units;
/*     */ import edu.mines.jtk.util.UnitsFormatException;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnitsTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  22 */     TestSuite suite = new TestSuite(UnitsTest.class);
/*  23 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testDefine() {
/*  27 */     boolean defined = false;
/*     */     try {
/*  29 */       defined = Units.define("degrees F", false, "degF");
/*  30 */       assertTrue(defined);
/*  31 */       defined = Units.define("degrees C", false, "degC");
/*  32 */       assertTrue(defined);
/*  33 */       defined = Units.define("cubic_inches", false, "in^3");
/*  34 */       assertTrue(defined);
/*  35 */       defined = Units.isDefined("m");
/*  36 */       assertTrue(defined);
/*  37 */       defined = Units.define("m", false, "meters");
/*  38 */       assertTrue(!defined);
/*  39 */       defined = true;
/*  40 */     } catch (UnitsFormatException e) {
/*  41 */       assertTrue(false);
/*     */     } 
/*  43 */     defined = true;
/*     */     try {
/*  45 */       Units.define("foo_inches", false, "foo inches");
/*  46 */     } catch (UnitsFormatException e) {
/*  47 */       defined = false;
/*     */     } 
/*  49 */     assertTrue(!defined);
/*     */   }
/*     */   
/*     */   public void testConversion() {
/*     */     try {
/*  54 */       Units.define("degrees F", false, "degF");
/*  55 */       Units.define("degrees C", false, "degC");
/*  56 */       Units.define("cubic_inches", false, "in^3");
/*  57 */     } catch (UnitsFormatException e) {
/*  58 */       assertTrue(false);
/*     */     } 
/*     */ 
/*     */     
/*  62 */     String[][] conversions = { { "m", "foo", "invalid", "invalid" }, { "foo", "m", "invalid", "invalid" }, { "s", "m", "incompatible", "incompatible" }, { "m", "meters", "0", "1" }, { "-1 cm", "m", "0", "-0.01" }, { "degC", "degF", "32", "1.8" }, { "degrees C", "degrees F", "32", "1.8" }, { "degrees_Celsius", "degrees_Fahrenheit", "32", "1.8" }, { "10^-2 m^2", "(0.1 m)^2", "0", "1" }, { "ft/s", "m/s", "0", "0.3048" }, { "ampere hour", "coulomb", "0", "3600" }, { "cubic_inches/min", "m^3/s", "0", "2.73117733333E-7" }, { "avoirdupois_ounce/ft^2", "kg/m^2", "0", "0.305151693637" }, { "kgf*s^2/m", "kg", "0", "9.80665" }, { "kilogram*meter/second^2", "kilogram*meter/second/second", "0", "1.0" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     for (int i = 0; i < conversions.length; i++) {
/*  81 */       String from = conversions[i][0];
/*  82 */       String to = conversions[i][1];
/*  83 */       Units fromUnits = null;
/*  84 */       Units toUnits = null;
/*     */       try {
/*  86 */         fromUnits = new Units(from);
/*  87 */         toUnits = new Units(to);
/*  88 */       } catch (UnitsFormatException e) {
/*  89 */         assertTrue(conversions[i][2].equals("invalid"));
/*     */       } 
/*     */       
/*  92 */       if (fromUnits.haveDimensionsOf(toUnits)) {
/*  93 */         float shift = toUnits.floatShiftFrom(fromUnits);
/*  94 */         float scale = toUnits.floatScaleFrom(fromUnits);
/*  95 */         float shiftExpected = Float.parseFloat(conversions[i][2]);
/*  96 */         float scaleExpected = Float.parseFloat(conversions[i][3]);
/*  97 */         assertTrue((shift == shiftExpected));
/*  98 */         assertTrue((scale == scaleExpected));
/*     */       } else {
/* 100 */         assertTrue(conversions[i][2].equals("incompatible"));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testSpecification() {
/*     */     try {
/* 107 */       Units.define("degrees F", false, "degF");
/* 108 */     } catch (UnitsFormatException e) {
/* 109 */       assertTrue(false);
/*     */     } 
/*     */     
/* 112 */     String[][] specifications = { { "", "" }, { "foo", "invalid" }, { "%", "0.01" }, { "kHz", "1000.0 second^-1" }, { "kgf*s^2/m", "9.80665 kilogram" }, { "degrees F", "0.5555555555555556 kelvin - 459.67" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     for (int i = 0; i < specifications.length; i++) {
/* 122 */       String sd = null;
/*     */       try {
/* 124 */         sd = (new Units(specifications[i][0])).standardDefinition();
/* 125 */         assertTrue(sd.equals(specifications[i][1]));
/* 126 */       } catch (UnitsFormatException e) {
/* 127 */         assertTrue(specifications[i][1].equals("invalid"));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/UnitsTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */