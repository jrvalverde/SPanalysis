/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import edu.mines.jtk.io.DataFile;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataFileBench
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 25 */     benchBigEndian();
/* 26 */     benchLittleEndian();
/*    */   }
/*    */   
/*    */   public static void benchBigEndian() {
/* 30 */     bench(DataFile.ByteOrder.BIG_ENDIAN);
/*    */   }
/*    */   
/*    */   public static void benchLittleEndian() {
/* 34 */     bench(DataFile.ByteOrder.LITTLE_ENDIAN);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void bench(DataFile.ByteOrder order) {
/* 41 */     System.out.println("order=" + order);
/* 42 */     int n = 1000000;
/* 43 */     File file = null;
/* 44 */     DataFile df = null;
/*    */     try {
/* 46 */       file = File.createTempFile("junk", "dat");
/* 47 */       df = new DataFile(file, "rw", order);
/* 48 */       benchFloat(df, n);
/* 49 */       benchDouble(df, n);
/* 50 */       if (df != null)
/* 51 */         df.close(); 
/* 52 */       if (file != null)
/* 53 */         file.delete(); 
/* 54 */     } catch (IOException ioe) {
/* 55 */       throw new RuntimeException(ioe);
/*    */     } 
/*    */   }
/*    */   
/*    */   private static void benchFloat(DataFile df, int n) throws IOException {
/* 60 */     float[] a = Array.randfloat(n);
/* 61 */     float[] b = Array.zerofloat(n);
/*    */     
/* 63 */     Stopwatch sw = new Stopwatch();
/* 64 */     sw.start(); int nio;
/* 65 */     for (nio = 0; sw.time() < 5.0D; nio++) {
/* 66 */       df.seek(0L);
/* 67 */       df.writeFloats(a);
/* 68 */       df.seek(0L);
/* 69 */       df.readFloats(b);
/*    */     } 
/* 71 */     sw.stop();
/* 72 */     for (int i = 0; i < n; i++) {
/* 73 */       if (a[i] != b[i])
/* 74 */         throw new RuntimeException(" float: i/o failure"); 
/* 75 */     }  double time = sw.time();
/* 76 */     double rate = 8.0E-6D * nio * n / time;
/* 77 */     System.out.println(" float: rate=" + rate + " MB/s");
/*    */   }
/*    */   
/*    */   private static void benchDouble(DataFile df, int n) throws IOException {
/* 81 */     double[] a = Array.randdouble(n);
/* 82 */     double[] b = Array.zerodouble(n);
/*    */     
/* 84 */     Stopwatch sw = new Stopwatch();
/* 85 */     sw.start(); int nio;
/* 86 */     for (nio = 0; sw.time() < 5.0D; nio++) {
/* 87 */       df.seek(0L);
/* 88 */       df.writeDoubles(a);
/* 89 */       df.seek(0L);
/* 90 */       df.readDoubles(b);
/*    */     } 
/* 92 */     sw.stop();
/* 93 */     for (int i = 0; i < n; i++) {
/* 94 */       if (a[i] != b[i])
/* 95 */         throw new RuntimeException("double: i/o failure"); 
/* 96 */     }  double time = sw.time();
/* 97 */     double rate = 1.6E-5D * nio * n / time;
/* 98 */     System.out.println("double: rate=" + rate + " MB/s");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/DataFileBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */