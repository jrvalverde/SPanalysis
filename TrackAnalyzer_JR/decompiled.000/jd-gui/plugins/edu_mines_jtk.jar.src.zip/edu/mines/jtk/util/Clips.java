/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clips
/*     */ {
/*     */   private boolean _clipsDirty;
/*     */   private float _clipMin;
/*     */   private float _clipMax;
/*     */   private float _percMin;
/*     */   private float _percMax;
/*     */   private boolean _usePercentiles;
/*     */   private Object _f;
/*     */   
/*     */   public Clips(float[] f) {
/*  43 */     this(0.0D, 100.0D, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Clips(float[][] f) {
/*  52 */     this(0.0D, 100.0D, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Clips(float[][][] f) {
/*  61 */     this(0.0D, 100.0D, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Clips(Float3 f3) {
/*  70 */     this(0.0D, 100.0D, f3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Clips(double percMin, double percMax, float[] f)
/*     */   {
/* 210 */     this._clipsDirty = true;
/*     */ 
/*     */     
/* 213 */     this._percMin = 0.0F;
/* 214 */     this._percMax = 100.0F;
/* 215 */     this._usePercentiles = true; this._percMin = (float)percMin; this._percMax = (float)percMax; this._f = f; } public Clips(double percMin, double percMax, float[][] f) { this._clipsDirty = true; this._percMin = 0.0F; this._percMax = 100.0F; this._usePercentiles = true; this._percMin = (float)percMin; this._percMax = (float)percMax; this._f = f; } public Clips(double percMin, double percMax, float[][][] f) { this._clipsDirty = true; this._percMin = 0.0F; this._percMax = 100.0F; this._usePercentiles = true; this._percMin = (float)percMin; this._percMax = (float)percMax; this._f = f; } public Clips(double percMin, double percMax, Float3 f3) { this._clipsDirty = true; this._percMin = 0.0F; this._percMax = 100.0F; this._usePercentiles = true; this._percMin = (float)percMin; this._percMax = (float)percMax; this._f = f3; }
/*     */   public void setClips(double clipMin, double clipMax) { Check.argument((clipMin < clipMax), "clipMin<clipMax"); if (this._clipMin != (float)clipMin || this._clipMax != (float)clipMax || this._usePercentiles) { this._usePercentiles = false; this._clipMin = (float)clipMin; this._clipMax = (float)clipMax; this._clipsDirty = false; }
/*     */      }
/*     */   public float getClipMin() { updateClips(); return this._clipMin; }
/* 219 */   public float getClipMax() { updateClips(); return this._clipMax; } private void updateClips() { if (this._clipsDirty && this._usePercentiles) {
/* 220 */       boolean clipsComputed = false;
/*     */ 
/*     */       
/* 223 */       if (this._percMin == 0.0F && this._percMax == 100.0F) {
/* 224 */         if (this._f instanceof float[]) {
/* 225 */           float[] a = (float[])this._f;
/* 226 */           this._clipMin = Array.min(a);
/* 227 */           this._clipMax = Array.max(a);
/* 228 */           clipsComputed = true;
/* 229 */         } else if (this._f instanceof float[][]) {
/* 230 */           float[][] a = (float[][])this._f;
/* 231 */           this._clipMin = Array.min(a);
/* 232 */           this._clipMax = Array.max(a);
/* 233 */           clipsComputed = true;
/* 234 */         } else if (this._f instanceof float[][][]) {
/* 235 */           float[][][] a = (float[][][])this._f;
/* 236 */           this._clipMin = Array.min(a);
/* 237 */           this._clipMax = Array.max(a);
/* 238 */           clipsComputed = true;
/* 239 */         } else if (this._f instanceof Float3) {
/* 240 */           Float3 f3 = (Float3)this._f;
/* 241 */           int n1 = f3.getN1();
/* 242 */           int n2 = f3.getN2();
/* 243 */           int n3 = f3.getN3();
/* 244 */           float[][] a = new float[n2][n1];
/* 245 */           for (int i3 = 0; i3 < n3; i3++) {
/* 246 */             f3.get12(n1, n2, 0, 0, i3, a);
/* 247 */             this._clipMin = Math.min(this._clipMin, Array.min(a));
/* 248 */             this._clipMax = Math.max(this._clipMax, Array.max(a));
/*     */           } 
/* 250 */           clipsComputed = true;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 256 */         float[] a = null;
/* 257 */         if (this._f instanceof float[]) {
/* 258 */           a = Array.copy((float[])this._f);
/* 259 */         } else if (this._f instanceof float[][]) {
/* 260 */           a = Array.flatten((float[][])this._f);
/* 261 */         } else if (this._f instanceof float[][][]) {
/* 262 */           a = Array.flatten((float[][][])this._f);
/* 263 */         } else if (this._f instanceof Float3) {
/* 264 */           Float3 f3 = (Float3)this._f;
/* 265 */           int n1 = f3.getN1();
/* 266 */           int n2 = f3.getN2();
/* 267 */           int n3 = f3.getN3();
/* 268 */           a = new float[n1 * n2 * n3];
/* 269 */           f3.get123(n1, n2, n3, 0, 0, 0, a);
/*     */         } 
/* 271 */         if (a != null) {
/* 272 */           int n = a.length;
/* 273 */           int kmin = (int)Math.rint(this._percMin * 0.01D * (n - 1));
/* 274 */           if (kmin <= 0) {
/* 275 */             this._clipMin = Array.min(a);
/*     */           } else {
/* 277 */             Array.quickPartialSort(kmin, a);
/* 278 */             this._clipMin = a[kmin];
/*     */           } 
/* 280 */           int kmax = (int)Math.rint(this._percMax * 0.01D * (n - 1));
/* 281 */           if (kmax >= n - 1) {
/* 282 */             this._clipMax = Array.max(a);
/*     */           } else {
/* 284 */             Array.quickPartialSort(kmax, a);
/* 285 */             this._clipMax = a[kmax];
/*     */           } 
/* 287 */           clipsComputed = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 292 */       if (clipsComputed)
/* 293 */       { makeClipsValid();
/* 294 */         this._clipsDirty = false; } 
/*     */     }  }
/*     */   public void setPercentiles(double percMin, double percMax) { Check.argument((0.0D <= percMin), "0<=percMin"); Check.argument((percMin < percMax), "percMin<percMax"); Check.argument((percMax <= 100.0D), "percMax<=100"); if (this._percMin != (float)percMin || this._percMax != (float)percMax || !this._usePercentiles) { this._usePercentiles = true; this._percMin = (float)percMin; this._percMax = (float)percMax; this._clipsDirty = true; }
/*     */      }
/*     */   public float getPercentileMin() { return this._percMin; }
/* 299 */   public float getPercentileMax() { return this._percMax; } private void makeClipsValid() { if (this._clipMin >= this._clipMax) {
/* 300 */       double clipAvg = 0.5D * (this._clipMin + this._clipMax);
/* 301 */       double tiny = Math.max(1.0D, Math.ulp(1.0F) * Math.abs(clipAvg));
/* 302 */       this._clipMin = (float)(this._clipMin - tiny);
/* 303 */       this._clipMax = (float)(this._clipMax + tiny);
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Clips.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */