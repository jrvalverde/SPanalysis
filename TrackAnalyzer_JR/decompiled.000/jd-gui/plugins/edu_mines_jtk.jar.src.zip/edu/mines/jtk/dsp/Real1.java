/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Real1
/*     */ {
/*     */   Sampling _s;
/*     */   float[] _v;
/*     */   
/*     */   public Real1(Sampling s) {
/*  36 */     this._s = s;
/*  37 */     this._v = new float[s.getCount()];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1(float[] v) {
/*  47 */     this._s = new Sampling(v.length, 1.0D, 0.0D);
/*  48 */     this._v = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1(Sampling s, float[] v) {
/*  58 */     Check.argument((s.getCount() == v.length), "v.length equals the number of samples in s");
/*     */     
/*  60 */     this._s = s;
/*  61 */     this._v = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1(int n, double d, double f) {
/*  71 */     this(new Sampling(n, d, f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1(int n, double d, double f, float[] v) {
/*  83 */     this(new Sampling(n, d, f), v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1(Real1 r) {
/*  93 */     this(r._s, Array.copy(r._v));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling getSampling() {
/* 101 */     return this._s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getValues() {
/* 109 */     return this._v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1 resample(Sampling s) {
/* 129 */     Sampling t = this._s;
/*     */ 
/*     */     
/* 132 */     int[] overlap = t.overlapWith(s);
/*     */ 
/*     */     
/* 135 */     if (overlap != null) {
/* 136 */       int ni = overlap[0];
/* 137 */       int it = overlap[1];
/* 138 */       int is = overlap[2];
/* 139 */       Real1 rt = this;
/* 140 */       Real1 rs = new Real1(s);
/* 141 */       float[] xt = rt.getValues();
/* 142 */       float[] xs = rs.getValues();
/* 143 */       while (--ni >= 0)
/* 144 */         xs[is++] = xt[it++]; 
/* 145 */       return rs;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     throw new UnsupportedOperationException("no interpolation, yet");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1 plus(Real1 ra) {
/* 159 */     return add(this, ra);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1 plus(float ar) {
/* 168 */     return add(this, ar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Real1 convolve(Real1 ra) {
/* 178 */     Real1 rx = this;
/* 179 */     Real1 ry = ra;
/* 180 */     Sampling sx = rx.getSampling();
/* 181 */     Sampling sy = ry.getSampling();
/* 182 */     double dx = sx.getDelta();
/* 183 */     double dy = sy.getDelta();
/* 184 */     Check.state(sx.isUniform(), "sampling is uniform");
/* 185 */     Check.argument(sy.isUniform(), "sampling is uniform");
/* 186 */     Check.argument((dx == dy), "sampling intervals are equal");
/* 187 */     int lx = sx.getCount();
/* 188 */     int ly = sy.getCount();
/* 189 */     double fx = sx.getFirst();
/* 190 */     double fy = sy.getFirst();
/* 191 */     float[] x = rx.getValues();
/* 192 */     float[] y = ry.getValues();
/* 193 */     int lz = lx + ly - 1;
/* 194 */     double dz = dx;
/* 195 */     double fz = fx + fy;
/* 196 */     float[] z = new float[lz];
/* 197 */     Conv.conv(lx, 0, x, ly, 0, y, lz, 0, z);
/* 198 */     return new Real1(lz, dz, fz, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling getFourierSampling(int nmin) {
/* 214 */     int nt = this._s.getCount();
/* 215 */     double dt = this._s.getDelta();
/* 216 */     int nfft = FftReal.nfftSmall(MathPlus.max(nmin, nt));
/* 217 */     int nf = nfft / 2 + 1;
/* 218 */     double df = 1.0D / nfft * dt;
/* 219 */     double ff = 0.0D;
/* 220 */     return new Sampling(nf, df, ff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 zero(int n) {
/* 239 */     return new Real1(new Sampling(n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 zero(Sampling s) {
/* 248 */     return new Real1(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 fill(double ar, int n) {
/* 258 */     return fill(ar, new Sampling(n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 fill(double ar, Sampling s) {
/* 268 */     int n = s.getCount();
/* 269 */     return new Real1(s, Array.fillfloat((float)ar, n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 ramp(double fv, double dv, int nv) {
/* 281 */     return ramp(fv, dv, new Sampling(nv));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 ramp(double fv, double dv, Sampling s) {
/* 294 */     int n = s.getCount();
/* 295 */     double d = s.getDelta();
/* 296 */     double f = s.getFirst();
/* 297 */     return new Real1(s, Array.rampfloat((float)(fv - f * dv), (float)(d * dv), n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 add(Real1 ra, Real1 rb) {
/* 308 */     return binaryOp(ra, rb, _add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 add(float ar, Real1 rb) {
/* 318 */     return binaryOp(ar, rb, _add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 add(Real1 ra, float br) {
/* 328 */     return binaryOp(ra, br, _add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 sub(Real1 ra, Real1 rb) {
/* 339 */     return binaryOp(ra, rb, _sub);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 sub(float ar, Real1 rb) {
/* 349 */     return binaryOp(ar, rb, _sub);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 sub(Real1 ra, float br) {
/* 359 */     return binaryOp(ra, br, _sub);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 mul(Real1 ra, Real1 rb) {
/* 370 */     return binaryOp(ra, rb, _mul);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 mul(float ar, Real1 rb) {
/* 380 */     return binaryOp(ar, rb, _mul);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 mul(Real1 ra, float br) {
/* 390 */     return binaryOp(ra, br, _mul);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 div(Real1 ra, Real1 rb) {
/* 401 */     return binaryOp(ra, rb, _div);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 div(float ar, Real1 rb) {
/* 411 */     return binaryOp(ar, rb, _div);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Real1 div(Real1 ra, float br) {
/* 421 */     return binaryOp(ra, br, _div);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Real1 binaryOp(Real1 ra, Real1 rb, Binary ab) {
/* 444 */     Sampling sa = ra.getSampling();
/* 445 */     Sampling sb = rb.getSampling();
/* 446 */     Check.argument(sa.isEquivalentTo(sb), "samplings equivalent");
/* 447 */     Sampling sc = sa;
/* 448 */     Real1 rc = new Real1(sc);
/* 449 */     float[] va = ra.getValues();
/* 450 */     float[] vb = rb.getValues();
/* 451 */     float[] vc = rc.getValues();
/* 452 */     ab.apply(vc.length, va, 0, vb, 0, vc, 0);
/* 453 */     return rc;
/*     */   }
/*     */   private static Real1 binaryOp(float ar, Real1 rb, Binary ab) {
/* 456 */     Sampling sb = rb.getSampling();
/* 457 */     Sampling sc = sb;
/* 458 */     Real1 rc = new Real1(sc);
/* 459 */     float[] vb = rb.getValues();
/* 460 */     float[] vc = rc.getValues();
/* 461 */     ab.apply(vc.length, ar, vb, 0, vc, 0);
/* 462 */     return rc;
/*     */   }
/*     */   private static Real1 binaryOp(Real1 ra, float br, Binary ab) {
/* 465 */     Sampling sa = ra.getSampling();
/* 466 */     Sampling sc = sa;
/* 467 */     Real1 rc = new Real1(sc);
/* 468 */     float[] va = ra.getValues();
/* 469 */     float[] vc = rc.getValues();
/* 470 */     ab.apply(vc.length, va, 0, br, vc, 0);
/* 471 */     return rc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 481 */   private static Binary _add = new Binary()
/*     */     {
/*     */       public void apply(int n, float[] a, int ia, float[] b, int ib, float[] c, int ic)
/*     */       {
/* 485 */         while (--n >= 0)
/* 486 */           c[ic++] = a[ia++] + b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float a, float[] b, int ib, float[] c, int ic) {
/* 489 */         while (--n >= 0)
/* 490 */           c[ic++] = a + b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float[] a, int ia, float b, float[] c, int ic) {
/* 493 */         while (--n >= 0)
/* 494 */           c[ic++] = a[ia++] + b; 
/*     */       }
/*     */     };
/* 497 */   private static Binary _sub = new Binary()
/*     */     {
/*     */       public void apply(int n, float[] a, int ia, float[] b, int ib, float[] c, int ic)
/*     */       {
/* 501 */         while (--n >= 0)
/* 502 */           c[ic++] = a[ia++] - b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float a, float[] b, int ib, float[] c, int ic) {
/* 505 */         while (--n >= 0)
/* 506 */           c[ic++] = a - b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float[] a, int ia, float b, float[] c, int ic) {
/* 509 */         while (--n >= 0)
/* 510 */           c[ic++] = a[ia++] - b; 
/*     */       }
/*     */     }; private static interface Binary {
/* 513 */     void apply(int param1Int1, float[] param1ArrayOffloat1, int param1Int2, float[] param1ArrayOffloat2, int param1Int3, float[] param1ArrayOffloat3, int param1Int4); void apply(int param1Int1, float param1Float, float[] param1ArrayOffloat1, int param1Int2, float[] param1ArrayOffloat2, int param1Int3); void apply(int param1Int1, float[] param1ArrayOffloat1, int param1Int2, float param1Float, float[] param1ArrayOffloat2, int param1Int3); } private static Binary _mul = new Binary()
/*     */     {
/*     */       public void apply(int n, float[] a, int ia, float[] b, int ib, float[] c, int ic)
/*     */       {
/* 517 */         while (--n >= 0)
/* 518 */           c[ic++] = a[ia++] * b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float a, float[] b, int ib, float[] c, int ic) {
/* 521 */         while (--n >= 0)
/* 522 */           c[ic++] = a * b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float[] a, int ia, float b, float[] c, int ic) {
/* 525 */         while (--n >= 0)
/* 526 */           c[ic++] = a[ia++] * b; 
/*     */       }
/*     */     };
/* 529 */   private static Binary _div = new Binary()
/*     */     {
/*     */       public void apply(int n, float[] a, int ia, float[] b, int ib, float[] c, int ic)
/*     */       {
/* 533 */         while (--n >= 0)
/* 534 */           c[ic++] = a[ia++] / b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float a, float[] b, int ib, float[] c, int ic) {
/* 537 */         while (--n >= 0)
/* 538 */           c[ic++] = a / b[ib++]; 
/*     */       }
/*     */       public void apply(int n, float[] a, int ia, float b, float[] c, int ic) {
/* 541 */         while (--n >= 0)
/* 542 */           c[ic++] = a[ia++] / b; 
/*     */       }
/*     */     };
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Real1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */