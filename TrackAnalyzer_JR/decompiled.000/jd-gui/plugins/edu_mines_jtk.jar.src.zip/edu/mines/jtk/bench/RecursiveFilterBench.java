/*     */ package edu.mines.jtk.bench;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecursiveFilterBench
/*     */ {
/*     */   public static void main(String[] args) {
/*  20 */     double maxtime = 5.0D;
/*  21 */     int n1 = 4000;
/*  22 */     int n2 = 4000;
/*  23 */     float b0 = 2.0F;
/*  24 */     float b1 = -3.2F;
/*  25 */     float b2 = 1.28F;
/*  26 */     float a1 = -1.8F;
/*  27 */     float a2 = 0.81F;
/*  28 */     float[][] x = Array.rampfloat(0.0F, 0.0F, 1.0F, n1, n2);
/*  29 */     float[][] y = Array.zerofloat(n1, n2);
/*  30 */     double mflop = 9.0D * n1 * n2 * 1.0E-6D;
/*     */ 
/*     */     
/*  33 */     Stopwatch sw = new Stopwatch();
/*     */     while (true) {
/*  35 */       sw.restart(); int n;
/*  36 */       for (n = 0; sw.time() < maxtime; n++)
/*  37 */         filter1(b0, b1, b2, a1, a2, x, y); 
/*  38 */       sw.stop();
/*  39 */       double sum = Array.sum(y);
/*  40 */       double rate = n * mflop / sw.time();
/*  41 */       System.out.println("filter1: rate=" + rate + " sum=" + sum);
/*     */       
/*  43 */       sw.restart();
/*  44 */       for (n = 0; sw.time() < maxtime; n++)
/*  45 */         filter2a(b0, b1, b2, a1, a2, x, y); 
/*  46 */       sw.stop();
/*  47 */       sum = Array.sum(y);
/*  48 */       rate = n * mflop / sw.time();
/*  49 */       System.out.println("filter2a: rate=" + rate + " sum=" + sum);
/*     */       
/*  51 */       sw.restart();
/*  52 */       for (n = 0; sw.time() < maxtime; n++)
/*  53 */         filter2b(b0, b1, b2, a1, a2, x, y); 
/*  54 */       sw.stop();
/*  55 */       sum = Array.sum(y);
/*  56 */       rate = n * mflop / sw.time();
/*  57 */       System.out.println("filter2b: rate=" + rate + " sum=" + sum);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void filter(float b0, float b1, float b2, float a1, float a2, float[] x, float[] y) {
/*  65 */     int n = y.length;
/*  66 */     float yim2 = 0.0F;
/*  67 */     float yim1 = 0.0F;
/*  68 */     float xim2 = 0.0F;
/*  69 */     float xim1 = 0.0F;
/*  70 */     for (int i = 0; i < n; i++) {
/*  71 */       float xi = x[i];
/*  72 */       float yi = b0 * xi + b1 * xim1 + b2 * xim2 - a1 * yim1 - a2 * yim2;
/*  73 */       y[i] = yi;
/*  74 */       yim2 = yim1;
/*  75 */       yim1 = yi;
/*  76 */       xim2 = xim1;
/*  77 */       xim1 = xi;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void filter1(float b0, float b1, float b2, float a1, float a2, float[][] x, float[][] y) {
/*  85 */     int n2 = y.length;
/*  86 */     for (int i2 = 0; i2 < n2; i2++) {
/*  87 */       filter(b0, b1, b2, a1, a2, x[i2], y[i2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void filter2a(float b0, float b1, float b2, float a1, float a2, float[][] x, float[][] y) {
/*  95 */     int n2 = y.length;
/*  96 */     int n1 = (y[0]).length;
/*  97 */     float[] xt = new float[n2];
/*  98 */     float[] yt = new float[n2];
/*  99 */     for (int i1 = 0; i1 < n1; i1++) {
/* 100 */       int i2; for (i2 = 0; i2 < n2; i2++) {
/* 101 */         xt[i2] = x[i2][i1];
/*     */       }
/* 103 */       filter(b0, b1, b2, a1, a2, xt, yt);
/* 104 */       for (i2 = 0; i2 < n2; i2++) {
/* 105 */         y[i2][i1] = yt[i2];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void filter2b(float b0, float b1, float b2, float a1, float a2, float[][] x, float[][] y) {
/* 114 */     int n2 = y.length;
/* 115 */     int n1 = (y[0]).length;
/* 116 */     float[] yim2 = new float[n1];
/* 117 */     float[] yim1 = new float[n1];
/* 118 */     float[] xim2 = new float[n1];
/* 119 */     float[] xim1 = new float[n1];
/* 120 */     float[] xi = new float[n1];
/* 121 */     for (int i2 = 0; i2 < n2; i2++) {
/* 122 */       float[] xi2 = x[i2];
/* 123 */       float[] yi = y[i2];
/* 124 */       for (int i1 = 0; i1 < n1; i1++) {
/* 125 */         xi[i1] = xi2[i1];
/* 126 */         yi[i1] = b0 * xi[i1] + b1 * xim1[i1] + b2 * xim2[i1] - a1 * yim1[i1] - a2 * yim2[i1];
/*     */       } 
/*     */       
/* 129 */       yim2 = yim1;
/* 130 */       yim1 = yi;
/* 131 */       float[] xt = xim2;
/* 132 */       xim2 = xim1;
/* 133 */       xim1 = xi;
/* 134 */       xi = xt;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/RecursiveFilterBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */