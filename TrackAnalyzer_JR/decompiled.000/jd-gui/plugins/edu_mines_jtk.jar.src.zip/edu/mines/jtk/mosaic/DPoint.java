/*    */ package edu.mines.jtk.mosaic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DPoint
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   
/*    */   public DPoint(double x, double y) {
/* 32 */     this.x = x;
/* 33 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DPoint(DPoint p) {
/* 41 */     this(p.x, p.y);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 45 */     if (this == obj)
/* 46 */       return true; 
/* 47 */     if (obj == null || getClass() != obj.getClass())
/* 48 */       return false; 
/* 49 */     DPoint that = (DPoint)obj;
/* 50 */     return (this.x == that.x && this.y == that.y);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 54 */     long xbits = Double.doubleToLongBits(this.x);
/* 55 */     long ybits = Double.doubleToLongBits(this.y);
/* 56 */     return (int)(xbits ^ xbits >>> 32L ^ ybits ^ ybits >>> 32L);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     return "(" + this.x + "," + this.y + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/DPoint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */