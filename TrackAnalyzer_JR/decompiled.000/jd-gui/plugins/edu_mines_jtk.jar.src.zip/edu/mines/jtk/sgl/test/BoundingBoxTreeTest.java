/*    */ package edu.mines.jtk.sgl.test;
/*    */ 
/*    */ import edu.mines.jtk.sgl.BoundingBox;
/*    */ import edu.mines.jtk.sgl.BoundingBoxTree;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundingBoxTreeTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(BoundingBoxTreeTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testRandom() {
/* 28 */     int minSize = 10;
/* 29 */     int n = 10000;
/* 30 */     float[] x = Array.randfloat(n);
/* 31 */     float[] y = Array.randfloat(n);
/* 32 */     float[] z = Array.randfloat(n);
/* 33 */     BoundingBoxTree bbt = new BoundingBoxTree(minSize, x, y, z);
/* 34 */     BoundingBoxTree.Node root = bbt.getRoot();
/* 35 */     test(root, minSize, x, y, z);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void test(BoundingBoxTree.Node node, int minSize, float[] x, float[] y, float[] z) {
/* 44 */     int[] i = node.getIndices();
/* 45 */     int n = i.length;
/* 46 */     assertTrue((minSize <= n));
/* 47 */     BoundingBox bb = node.getBoundingBox();
/* 48 */     for (int j = 0; j < n; j++) {
/* 49 */       int ij = i[j];
/* 50 */       assertTrue(bb.contains(x[ij], y[ij], z[ij]));
/*    */     } 
/* 52 */     BoundingBoxTree.Node left = node.getLeft();
/* 53 */     BoundingBoxTree.Node right = node.getRight();
/* 54 */     if (left != null) {
/* 55 */       assertTrue(bb.contains(left.getBoundingBox()));
/* 56 */       assertTrue(bb.contains(right.getBoundingBox()));
/* 57 */       test(left, minSize, x, y, z);
/* 58 */       test(right, minSize, x, y, z);
/*    */     } else {
/* 60 */       assertTrue((n / 2 < minSize));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/BoundingBoxTreeTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */