/*    */ package edu.mines.jtk.mosaic.test;
/*    */ 
/*    */ import edu.mines.jtk.awt.ColorMap;
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.mosaic.PixelsView;
/*    */ import edu.mines.jtk.mosaic.PlotFrame;
/*    */ import edu.mines.jtk.mosaic.PlotPanel;
/*    */ import edu.mines.jtk.util.Array;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PixelsViewTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 24 */     int n1 = 11;
/* 25 */     int n2 = 11;
/* 26 */     float d1 = 1.0F / Math.max(1, n1 - 1);
/* 27 */     float d2 = 1.0F / Math.max(1, n2 - 1);
/* 28 */     float[][] f = Array.rampfloat(0.0F, d1, d2, n1, n2);
/*    */     
/* 30 */     Sampling s1 = new Sampling(n1, 0.5D, 0.25D * (n1 - 1));
/* 31 */     Sampling s2 = new Sampling(n2, 0.5D, 0.25D * (n2 - 1));
/*    */     
/* 33 */     PlotPanel panel = new PlotPanel(1, 2);
/* 34 */     PixelsView pv0 = panel.addPixels(0, 0, f);
/* 35 */     pv0.setInterpolation(PixelsView.Interpolation.NEAREST);
/* 36 */     pv0.setColorModel(ColorMap.JET);
/* 37 */     pv0.setPercentiles(0.0F, 100.0F);
/*    */     
/* 39 */     PixelsView pv0b = panel.addPixels(0, 0, s1, s2, f);
/* 40 */     pv0b.setInterpolation(PixelsView.Interpolation.LINEAR);
/* 41 */     pv0b.setColorModel(ColorMap.GRAY);
/* 42 */     pv0b.setPercentiles(0.0F, 100.0F);
/*    */     
/* 44 */     PixelsView pv1 = panel.addPixels(0, 1, f);
/* 45 */     pv1.setInterpolation(PixelsView.Interpolation.LINEAR);
/* 46 */     pv1.setColorModel(ColorMap.GRAY);
/* 47 */     pv1.setPercentiles(0.0F, 100.0F);
/*    */     
/* 49 */     PixelsView pv1b = panel.addPixels(0, 1, s1, s2, f);
/* 50 */     pv1b.setInterpolation(PixelsView.Interpolation.NEAREST);
/* 51 */     pv1b.setColorModel(ColorMap.JET);
/* 52 */     pv1b.setPercentiles(0.0F, 100.0F);
/*    */     
/* 54 */     PlotFrame frame = new PlotFrame(panel);
/* 55 */     frame.setDefaultCloseOperation(3);
/* 56 */     frame.setVisible(true);
/* 57 */     frame.paintToPng(300.0D, 6.0D, "junk.png");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/PixelsViewTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */