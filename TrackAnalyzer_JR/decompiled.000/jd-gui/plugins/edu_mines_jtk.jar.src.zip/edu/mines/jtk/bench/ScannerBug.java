/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import java.util.Scanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScannerBug
/*    */ {
/* 17 */   private static final String eol = System.getProperty("line.separator");
/* 18 */   private static final String input1 = "line 1" + eol + "" + eol + "line 3" + eol + "" + eol + "line 5" + eol + "" + eol + "line 7" + eol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   private static final String input2 = "line 1" + eol + " " + eol + "line 3" + eol + " " + eol + "line 5" + eol + " " + eol + "line 7" + eol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void scan(String input) {
/* 35 */     Scanner s = new Scanner(input);
/* 36 */     while (s.hasNextLine()) {
/* 37 */       s.findInLine("5");
/* 38 */       System.out.println(s.nextLine());
/*    */     } 
/*    */   }
/*    */   public static void main(String[] args) {
/* 42 */     System.out.println("Scanning input with empty lines (incorrectly):");
/* 43 */     scan(input1);
/* 44 */     System.out.println("Scanning input without empty lines (correctly):");
/* 45 */     scan(input2);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/ScannerBug.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */