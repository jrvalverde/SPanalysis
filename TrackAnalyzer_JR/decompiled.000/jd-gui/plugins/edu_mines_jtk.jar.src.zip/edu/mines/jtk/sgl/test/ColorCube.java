/*     */ package edu.mines.jtk.sgl.test;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.sgl.BoundingSphere;
/*     */ import edu.mines.jtk.sgl.DrawContext;
/*     */ import edu.mines.jtk.sgl.MaterialState;
/*     */ import edu.mines.jtk.sgl.Matrix44;
/*     */ import edu.mines.jtk.sgl.Node;
/*     */ import edu.mines.jtk.sgl.PickContext;
/*     */ import edu.mines.jtk.sgl.Point3;
/*     */ import edu.mines.jtk.sgl.Segment;
/*     */ import edu.mines.jtk.sgl.Selectable;
/*     */ import edu.mines.jtk.sgl.State;
/*     */ import edu.mines.jtk.sgl.StateSet;
/*     */ import edu.mines.jtk.sgl.TransformGroup;
/*     */ import edu.mines.jtk.sgl.World;
/*     */ import edu.mines.jtk.util.Direct;
/*     */ import java.awt.Color;
/*     */ import java.nio.FloatBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorCube
/*     */   extends Node
/*     */   implements Selectable
/*     */ {
/*     */   protected void selectedChanged() {
/*  28 */     System.out.println("ColorCube: " + this + " selected=" + isSelected());
/*  29 */     dirtyDraw();
/*     */   }
/*     */   
/*     */   protected BoundingSphere computeBoundingSphere(boolean finite) {
/*  33 */     Point3 c = new Point3(0.5D, 0.5D, 0.5D);
/*  34 */     double r = 0.5D * Math.sqrt(3.0D);
/*  35 */     return new BoundingSphere(c, r);
/*     */   }
/*     */   
/*     */   protected void draw(DrawContext dc) {
/*  39 */     Gl.glEnableClientState(32884);
/*  40 */     Gl.glEnableClientState(32885);
/*  41 */     Gl.glEnableClientState(32886);
/*  42 */     Gl.glVertexPointer(3, 5126, 0, _vb);
/*  43 */     Gl.glNormalPointer(5126, 0, _nb);
/*  44 */     Gl.glColorPointer(3, 5126, 0, _cb);
/*  45 */     if (isSelected()) {
/*  46 */       Gl.glEnable(32823);
/*  47 */       Gl.glPolygonOffset(1.0F, 1.0F);
/*     */     } 
/*  49 */     Gl.glDrawArrays(7, 0, 24);
/*  50 */     Gl.glDisableClientState(32885);
/*  51 */     Gl.glDisableClientState(32886);
/*  52 */     if (isSelected()) {
/*  53 */       Gl.glPolygonMode(1032, 6913);
/*  54 */       Gl.glDisable(2896);
/*  55 */       Gl.glColor3d(1.0D, 1.0D, 1.0D);
/*  56 */       Gl.glDrawArrays(7, 0, 24);
/*     */     } 
/*  58 */     Gl.glDisableClientState(32884);
/*     */   }
/*     */   
/*     */   protected void pick(PickContext pc) {
/*  62 */     Segment ps = pc.getPickSegment();
/*  63 */     for (int iside = 0; iside < 6; iside++) {
/*  64 */       double xa = _va[12 * iside + 0];
/*  65 */       double ya = _va[12 * iside + 1];
/*  66 */       double za = _va[12 * iside + 2];
/*  67 */       double xb = _va[12 * iside + 3];
/*  68 */       double yb = _va[12 * iside + 4];
/*  69 */       double zb = _va[12 * iside + 5];
/*  70 */       double xc = _va[12 * iside + 6];
/*  71 */       double yc = _va[12 * iside + 7];
/*  72 */       double zc = _va[12 * iside + 8];
/*  73 */       double xd = _va[12 * iside + 9];
/*  74 */       double yd = _va[12 * iside + 10];
/*  75 */       double zd = _va[12 * iside + 11];
/*  76 */       Point3 p = ps.intersectWithTriangle(xa, ya, za, xb, yb, zb, xc, yc, zc);
/*  77 */       Point3 q = ps.intersectWithTriangle(xa, ya, za, xc, yc, zc, xd, yd, zd);
/*  78 */       if (p != null)
/*  79 */         pc.addResult(p); 
/*  80 */       if (q != null) {
/*  81 */         pc.addResult(q);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private static float[] _va = new float[] { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private static float[] _na = new float[] { -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static float[] _ca = new float[] { 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static FloatBuffer _vb = Direct.newFloatBuffer(_va);
/* 114 */   private static FloatBuffer _nb = Direct.newFloatBuffer(_na);
/* 115 */   private static FloatBuffer _cb = Direct.newFloatBuffer(_ca);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 121 */     StateSet states = new StateSet();
/* 122 */     MaterialState ms = new MaterialState();
/* 123 */     ms.setColorMaterialFront(5634);
/* 124 */     ms.setSpecularFront(Color.white);
/* 125 */     ms.setShininessFront(100.0F);
/* 126 */     states.add((State)ms);
/*     */     
/* 128 */     ColorCube cc1 = new ColorCube();
/* 129 */     ColorCube cc2 = new ColorCube();
/* 130 */     cc1.setStates(states);
/* 131 */     cc2.setStates(states);
/*     */     
/* 133 */     TransformGroup tg1 = new TransformGroup(Matrix44.translate(-2.0D, 0.0D, 0.0D));
/* 134 */     TransformGroup tg2 = new TransformGroup(Matrix44.translate(2.0D, 0.0D, 0.0D));
/* 135 */     tg1.addChild(cc1);
/* 136 */     tg2.addChild(cc2);
/*     */     
/* 138 */     World world = new World();
/* 139 */     world.addChild((Node)tg1);
/* 140 */     world.addChild((Node)tg2);
/*     */     
/* 142 */     TestFrame frame = new TestFrame(world);
/* 143 */     frame.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/ColorCube.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */