/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect1;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectArray;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VectArrayTest
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() {
/* 24 */     Random random = new Random(32525L);
/* 25 */     VectArray vm = new VectArray(5);
/* 26 */     for (int index = 0; index < 5; index++) {
/* 27 */       double[] a = new double[7 * index];
/* 28 */       for (int k = 0; k < a.length; ) { a[k] = random.nextDouble(); k++; }
/* 29 */        ArrayVect1 arrayVect1 = new ArrayVect1(a, 2.0D);
/* 30 */       vm.put(index, (Vect)arrayVect1);
/* 31 */       assert vm.containsKey(index);
/*    */     } 
/* 33 */     assert !vm.containsKey(99);
/* 34 */     VectUtil.test((VectConst)vm);
/* 35 */     int[] keys = vm.getKeys();
/* 36 */     assert keys.length == 5 : "keys.length = " + keys.length;
/* 37 */     for (int i = 0; i < 5; ) { assert keys[i] == i; i++; }
/* 38 */      int j; for (j = 0; j < 5; j++) {
/* 39 */       ArrayVect1 value = (ArrayVect1)vm.get(j);
/* 40 */       assert value != null : "index=" + j;
/* 41 */       assert value.getData() != null : "index=" + j;
/* 42 */       assert value.getSize() == 7 * j : "index=" + j;
/* 43 */       assert (value.getData()).length == 7 * j : "index=" + j;
/*    */     } 
/*    */     
/* 46 */     vm = new VectArray(5);
/* 47 */     for (j = 0; j < 5; j++) {
/* 48 */       double[] a = new double[7 * j + 1];
/* 49 */       for (int k = 0; k < a.length; ) { a[k] = 1.0D; k++; }
/* 50 */        ArrayVect1 arrayVect1 = new ArrayVect1(a, 1.0D);
/* 51 */       vm.put(j, (Vect)arrayVect1);
/*    */     } 
/* 53 */     VectArray vectArray1 = vm.clone();
/* 54 */     vectArray1.multiplyInverseCovariance();
/* 55 */     assert Almost.FLOAT.equal(1.0D, vectArray1.dot((VectConst)vm)) : vectArray1.dot((VectConst)vm);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 61 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 64 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VectArrayTest(String name) {
/* 71 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 77 */       throw new IllegalStateException("need -ea");
/* 78 */     } catch (AssertionError e) {
/* 79 */       return (Test)new TestSuite(VectArrayTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 86 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/VectArrayTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */