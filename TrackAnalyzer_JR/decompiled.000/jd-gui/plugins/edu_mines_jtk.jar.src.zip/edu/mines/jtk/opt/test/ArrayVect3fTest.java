/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect3f;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class ArrayVect3fTest extends TestCase {
/*    */   public void testAll() {
/* 15 */     float[][][] a = new float[13][17][11];
/* 16 */     for (int i = 0; i < a.length; i++) {
/* 17 */       for (int k = 0; k < (a[i]).length; k++) {
/* 18 */         for (int m = 0; m < (a[i][k]).length; m++) {
/* 19 */           a[i][k][m] = i + 2.5F * k - 1.7F * m;
/*    */         }
/*    */       } 
/*    */     } 
/* 23 */     ArrayVect3f arrayVect3f = new ArrayVect3f(a, 2.2D);
/* 24 */     VectUtil.test((VectConst)arrayVect3f);
/*    */ 
/*    */     
/* 27 */     for (int j = 0; j < a.length; j++) {
/* 28 */       for (int k = 0; k < (a[j]).length; k++) {
/* 29 */         for (int m = 0; m < (a[j][k]).length; m++) {
/* 30 */           a[j][k][m] = 1.0F;
/*    */         }
/*    */       } 
/*    */     } 
/* 34 */     arrayVect3f = new ArrayVect3f(a, 7.0D);
/* 35 */     Vect w = arrayVect3f.clone();
/* 36 */     w.multiplyInverseCovariance();
/* 37 */     assert Almost.FLOAT.equal(0.14285714285714285D, arrayVect3f.dot((VectConst)w));
/* 38 */     assert Almost.FLOAT.equal(0.14285714285714285D, arrayVect3f.magnitude());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 44 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 47 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayVect3fTest(String name) {
/* 54 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 60 */       throw new IllegalStateException("need -ea");
/* 61 */     } catch (AssertionError e) {
/* 62 */       return (Test)new TestSuite(ArrayVect3fTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 69 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect3fTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */