/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MouseOnLine
/*     */   extends MouseConstrained
/*     */ {
/*     */   private double _ymouse;
/*     */   private Point3 _origin;
/*     */   private Vector3 _vector;
/*     */   private Vector3 _delta;
/*     */   private double _length;
/*     */   private Mode _mode;
/*     */   
/*     */   public MouseOnLine(MouseEvent event, Point3 origin, Vector3 vector, Matrix44 localToPixel) {
/*  38 */     super(localToPixel);
/*     */     
/*  40 */     this._ymouse = event.getY();
/*  41 */     this._origin = new Point3(origin);
/*  42 */     this._vector = vector.normalize();
/*     */ 
/*     */ 
/*     */     
/*  46 */     Segment mouseSegment = getMouseSegment(event);
/*  47 */     Point3 mouseNear = mouseSegment.getA();
/*  48 */     Point3 mouseFar = mouseSegment.getB();
/*  49 */     Vector3 mouseVector = mouseFar.minus(mouseNear).normalize();
/*  50 */     double d = mouseVector.dot(this._vector);
/*  51 */     if (d < 0.0D) {
/*  52 */       d = -d;
/*  53 */       this._vector.negateEquals();
/*     */     } 
/*  55 */     this._mode = (d < 0.867D) ? Mode.NEAREST : Mode.PUSH_PULL;
/*  56 */     this._length = mouseSegment.length();
/*  57 */     this._delta = origin.minus(getPointOnLine(event));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getPoint(MouseEvent event) {
/*  66 */     return getPointOnLine(event).plusEquals(this._delta);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private enum Mode
/*     */   {
/*  73 */     NEAREST,
/*  74 */     PUSH_PULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point3 getPointOnLine(MouseEvent event) {
/*  86 */     Point3 point = null;
/*     */ 
/*     */     
/*  89 */     if (this._mode == Mode.NEAREST) {
/*     */ 
/*     */       
/*  92 */       Segment segment = getMouseSegment(event);
/*  93 */       Point3 p1 = segment.getA();
/*  94 */       Vector3 v1 = segment.getB().minus(p1);
/*     */ 
/*     */       
/*  97 */       Point3 p2 = this._origin;
/*  98 */       Vector3 v2 = this._vector;
/*     */ 
/*     */       
/* 101 */       Vector3 a = p2.minus(p1);
/* 102 */       Vector3 b = v1;
/* 103 */       Vector3 c = v1.cross(v2);
/* 104 */       double cc = c.lengthSquared();
/* 105 */       double t = a.cross(b).dot(c) / cc;
/* 106 */       point = p2.plus(v2.times(t));
/*     */ 
/*     */     
/*     */     }
/* 110 */     else if (this._mode == Mode.PUSH_PULL) {
/*     */ 
/*     */       
/* 113 */       Canvas canvas = (Canvas)event.getSource();
/* 114 */       double height = canvas.getHeight();
/* 115 */       double ymouse = event.getY();
/* 116 */       double scale = 0.05D * (this._ymouse - ymouse) / height;
/* 117 */       point = this._origin.plus(this._vector.times(scale * this._length));
/*     */     } 
/*     */     
/* 120 */     return point;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/MouseOnLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */