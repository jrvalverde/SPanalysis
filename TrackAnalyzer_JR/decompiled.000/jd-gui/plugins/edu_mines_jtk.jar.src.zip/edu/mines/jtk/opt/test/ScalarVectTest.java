/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ScalarVect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class ScalarVectTest
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() {
/* 15 */     ScalarVect scalarVect2 = new ScalarVect(0.266D, 3.0D);
/* 16 */     VectUtil.test((VectConst)scalarVect2);
/*    */ 
/*    */     
/* 19 */     ScalarVect scalarVect1 = new ScalarVect(-666.266D, 8.0D);
/* 20 */     VectUtil.test((VectConst)scalarVect1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 27 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 30 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScalarVectTest(String name) {
/* 37 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 43 */       throw new IllegalStateException("need -ea");
/* 44 */     } catch (AssertionError e) {
/* 45 */       return (Test)new TestSuite(ScalarVectTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 52 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ScalarVectTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */