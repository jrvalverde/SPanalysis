/*     */ package edu.mines.jtk.lapack;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixLud
/*     */ {
/*     */   private int _m;
/*     */   private int _n;
/*     */   private double[] _lu;
/*     */   private int _npiv;
/*     */   private int[] _ipiv;
/*     */   private int[] _p;
/*     */   private double _det;
/*     */   private boolean _singular;
/*     */   
/*     */   public DMatrixLud(DMatrix a) {
/*  39 */     this._m = a.getM();
/*  40 */     this._n = a.getN();
/*  41 */     this._lu = a.getPackedColumns();
/*  42 */     this._npiv = Math.min(this._m, this._n);
/*  43 */     this._ipiv = new int[this._npiv];
/*  44 */     int info = Lapack.dgetrf(this._m, this._n, this._lu, this._m, this._ipiv);
/*  45 */     this._p = new int[this._m]; int i;
/*  46 */     for (i = 0; i < this._m; i++)
/*  47 */       this._p[i] = i; 
/*  48 */     this._det = 1.0D;
/*  49 */     for (i = 0; i < this._m; i++) {
/*  50 */       int j = i;
/*  51 */       if (i < this._npiv) {
/*  52 */         j = this._ipiv[i] - 1;
/*  53 */         this._det *= this._lu[i + i * this._m];
/*  54 */         if (j != i) {
/*  55 */           int pi = this._p[i];
/*  56 */           this._p[i] = this._p[j];
/*  57 */           this._p[j] = pi;
/*  58 */           this._det = -this._det;
/*     */         } 
/*     */       } 
/*     */     } 
/*  62 */     this._singular = (info > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingular() {
/*  71 */     return this._singular;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getL() {
/*  80 */     int m = this._m;
/*  81 */     int n = Math.min(this._m, this._n);
/*  82 */     double[] l = new double[m * n];
/*  83 */     for (int j = 0; j < n; j++) {
/*  84 */       l[j + j * m] = 1.0D;
/*  85 */       for (int i = j + 1; i < m; i++) {
/*  86 */         l[i + j * m] = this._lu[i + j * this._m];
/*     */       }
/*     */     } 
/*  89 */     return new DMatrix(m, n, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getU() {
/*  98 */     int m = Math.min(this._m, this._n);
/*  99 */     int n = this._n;
/* 100 */     double[] u = new double[m * n];
/* 101 */     for (int j = 0; j < n; j++) {
/* 102 */       int imax = Math.min(m - 1, j);
/* 103 */       for (int i = 0; i <= imax; i++) {
/* 104 */         u[i + j * m] = this._lu[i + j * this._m];
/*     */       }
/*     */     } 
/* 107 */     return new DMatrix(m, n, u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getP() {
/* 116 */     int m = this._m;
/* 117 */     int n = this._m;
/* 118 */     double[] p = new double[m * n];
/* 119 */     for (int i = 0; i < m; i++) {
/* 120 */       p[this._p[i] + i * m] = 1.0D;
/*     */     }
/* 122 */     return new DMatrix(m, n, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getPivotIndices() {
/* 132 */     return Array.copy(this._p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double det() {
/* 141 */     Check.argument((this._m == this._n), "A is square");
/* 142 */     return this._det;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix solve(DMatrix b) {
/* 153 */     Check.argument((this._m == this._n), "A is square");
/* 154 */     Check.argument((this._m == b.getM()), "A and B have same number of rows");
/* 155 */     Check.state(!this._singular, "A is not singular");
/* 156 */     int n = this._n;
/* 157 */     int nrhs = b.getN();
/* 158 */     double[] aa = this._lu;
/* 159 */     int lda = this._m;
/* 160 */     int[] ipiv = this._ipiv;
/* 161 */     double[] ba = b.getPackedColumns();
/* 162 */     int ldb = this._m;
/* 163 */     Lapack.dgetrs(111, n, nrhs, aa, lda, ipiv, ba, ldb);
/* 164 */     return new DMatrix(this._m, nrhs, ba);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrixLud.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */