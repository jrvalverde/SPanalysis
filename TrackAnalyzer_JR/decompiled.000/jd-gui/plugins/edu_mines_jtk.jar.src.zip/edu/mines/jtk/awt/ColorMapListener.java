package edu.mines.jtk.awt;

import java.util.EventListener;

public interface ColorMapListener extends EventListener {
  void colorMapChanged(ColorMap paramColorMap);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/ColorMapListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */