/*     */ package edu.mines.jtk.awt;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import javax.swing.event.EventListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorMap
/*     */ {
/*  40 */   public static final IndexColorModel GRAY = getGray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final IndexColorModel JET = getJet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final IndexColorModel HUE = getHue();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final IndexColorModel PRISM = getPrism();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final IndexColorModel RED_WHITE_BLUE = getRedWhiteBlue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double _vmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double _vmax;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IndexColorModel _colorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color[] _colors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventListenerList _colorMapListeners;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorMap(double vmin, double vmax, IndexColorModel colorModel) {
/* 317 */     this._vmin = 0.0D;
/* 318 */     this._vmax = 1.0D;
/*     */     
/* 320 */     this._colors = new Color[256];
/* 321 */     this._colorMapListeners = new EventListenerList(); Check.argument(colorModel.isValid(0), "0 is valid for color model"); Check.argument(colorModel.isValid(255), "255 is valid for color model"); this._vmin = vmin; this._vmax = vmax; this._colorModel = colorModel; cacheColors();
/*     */   }
/*     */   public ColorMap(double vmin, double vmax, Color[] c) { this(vmin, vmax, getReds(c), getGreens(c), getBlues(c)); }
/* 324 */   public ColorMap(double vmin, double vmax, byte[] r, byte[] g, byte[] b) { this(vmin, vmax, new IndexColorModel(8, 256, r, g, b)); } public ColorMap(double vmin, double vmax, float[] r, float[] g, float[] b) { this(vmin, vmax, getBytes(r), getBytes(g), getBytes(b)); } public double getMinValue() { return this._vmin; } public double getMaxValue() { return this._vmax; } public IndexColorModel getColorModel() { return this._colorModel; } public Color getColor(double v) { return this._colors[getIndex(v)]; } public int getIndex(double v) { v = Math.max(this._vmin, Math.min(this._vmax, v)); return (int)Math.round(255.0D * (v - this._vmin) / (this._vmax - this._vmin)); } public void setValueRange(double vmin, double vmax) { if (this._vmin != vmin || this._vmax != vmax) { this._vmin = vmin; this._vmax = vmax; fireColorMapChanged(); }  } public void setColorModel(IndexColorModel colorModel) { this._colorModel = colorModel; cacheColors(); fireColorMapChanged(); } private void fireColorMapChanged() { Object[] listeners = this._colorMapListeners.getListenerList();
/* 325 */     for (int i = listeners.length - 2; i >= 0; i -= 2)
/* 326 */     { ColorMapListener cml = (ColorMapListener)listeners[i + 1];
/* 327 */       cml.colorMapChanged(this); }  }
/*     */   public void addListener(ColorMapListener cml) { this._colorMapListeners.add(ColorMapListener.class, cml); cml.colorMapChanged(this); }
/*     */   public void removeListener(ColorMapListener cml) { this._colorMapListeners.remove(ColorMapListener.class, cml); }
/*     */   public static IndexColorModel getGray() { return getGray(0.0D, 1.0D); }
/*     */   public static IndexColorModel getGray(double g0, double g255) { Color[] c = new Color[256]; for (int i = 0; i < 256; i++) { float g = (float)(g0 + i * (g255 - g0) / 255.0D); c[i] = new Color(g, g, g); }  return makeIndexColorModel(c); }
/* 332 */   public static IndexColorModel getJet() { Color[] c = new Color[256]; for (int i = 0; i < 256; i++) { float x = i / 255.0F; if (x < 0.125F) { float a = x / 0.125F; c[i] = new Color(0.0F, 0.0F, 0.5F + 0.5F * a); } else if (x < 0.375F) { float a = (x - 0.125F) / 0.25F; c[i] = new Color(0.0F, a, 1.0F); } else if (x < 0.625F) { float a = (x - 0.375F) / 0.25F; c[i] = new Color(a, 1.0F, 1.0F - a); } else if (x < 0.875F) { float a = (x - 0.625F) / 0.25F; c[i] = new Color(1.0F, 1.0F - a, 0.0F); } else { float a = (x - 0.875F) / 0.125F; c[i] = new Color(1.0F - 0.5F * a, 0.0F, 0.0F); }  }  return makeIndexColorModel(c); } public static IndexColorModel getPrism() { return getHue(0.0D, 8.0D); } public static IndexColorModel getHue() { return getHue(0.0D, 0.67D); } public static IndexColorModel getHue(double h0, double h255) { Color[] c = new Color[256]; for (int i = 0; i < 256; i++) { float h = (float)(h0 + i * (h255 - h0) / 255.0D); c[i] = Color.getHSBColor(h, 1.0F, 1.0F); }  return makeIndexColorModel(c); } public static IndexColorModel getRedWhiteBlue() { Color[] c = new Color[256]; for (int i = 0; i < 256; i++) { float x = i / 255.0F; if (x < 0.5F) { float a = x / 0.5F; c[i] = new Color(1.0F, a, a); } else { float a = (x - 0.5F) / 0.5F; c[i] = new Color(1.0F - a, 1.0F - a, 1.0F); }  }  return makeIndexColorModel(c); } public static IndexColorModel makeIndexColorModel(Color[] c) { return new IndexColorModel(8, 256, getReds(c), getGreens(c), getBlues(c)); } private void cacheColors() { for (int index = 0; index < 256; index++)
/* 333 */       this._colors[index] = new Color(this._colorModel.getRGB(index));  }
/*     */ 
/*     */   
/*     */   private static byte[] getReds(Color[] color) {
/* 337 */     int n = color.length;
/* 338 */     byte[] r = new byte[n];
/* 339 */     for (int i = 0; i < n; i++)
/* 340 */       r[i] = (byte)color[i].getRed(); 
/* 341 */     return r;
/*     */   }
/*     */   
/*     */   private static byte[] getGreens(Color[] color) {
/* 345 */     int n = color.length;
/* 346 */     byte[] g = new byte[n];
/* 347 */     for (int i = 0; i < n; i++)
/* 348 */       g[i] = (byte)color[i].getGreen(); 
/* 349 */     return g;
/*     */   }
/*     */   
/*     */   private static byte[] getBlues(Color[] color) {
/* 353 */     int n = color.length;
/* 354 */     byte[] b = new byte[n];
/* 355 */     for (int i = 0; i < n; i++)
/* 356 */       b[i] = (byte)color[i].getBlue(); 
/* 357 */     return b;
/*     */   }
/*     */   
/*     */   private static byte[] getBytes(float[] f) {
/* 361 */     int n = f.length;
/* 362 */     byte[] b = new byte[n];
/* 363 */     for (int i = 0; i < n; i++)
/* 364 */       b[i] = (byte)(int)(f[i] * 255.0F + 0.5F); 
/* 365 */     return b;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/ColorMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */