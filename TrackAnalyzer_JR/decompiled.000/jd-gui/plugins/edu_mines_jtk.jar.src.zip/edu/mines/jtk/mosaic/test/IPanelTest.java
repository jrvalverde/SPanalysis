/*     */ package edu.mines.jtk.mosaic.test;
/*     */ 
/*     */ import edu.mines.jtk.mosaic.IPanel;
/*     */ import edu.mines.jtk.mosaic.Transcaler;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.RenderingHints;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IPanelTest
/*     */ {
/*     */   static class Title
/*     */     extends IPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private String _text;
/*     */     
/*     */     Title(String text) {
/*  30 */       this._text = text;
/*  31 */       Font font = getFont();
/*  32 */       setFont(font.deriveFont(2.0F * font.getSize2D()));
/*     */     }
/*     */     public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/*  35 */       g2d = createGraphics(g2d, x, y, w, h);
/*  36 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */       
/*  40 */       FontMetrics fm = g2d.getFontMetrics();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  47 */       int wt = fm.stringWidth(this._text);
/*  48 */       int xt = Math.max(0, Math.min(w - wt, (w - wt) / 2));
/*  49 */       int yt = h / 2;
/*  50 */       g2d.drawString(this._text, xt, yt);
/*  51 */       g2d.dispose();
/*     */     }
/*     */     protected void paintComponent(Graphics g) {
/*  54 */       super.paintComponent(g);
/*  55 */       paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */     }
/*     */   }
/*     */   
/*     */   static class Wave extends IPanel {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private double _cycles;
/*     */     
/*     */     Wave(double cycles) {
/*  64 */       this._cycles = cycles;
/*     */     }
/*     */     public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/*  67 */       g2d = createGraphics(g2d, x, y, w, h);
/*     */ 
/*     */ 
/*     */       
/*  71 */       double x1u = 0.0D;
/*  72 */       double y1u = 1.0D;
/*  73 */       double x2u = 6.283185307179586D * this._cycles;
/*  74 */       double y2u = -1.0D;
/*  75 */       int x1d = 0;
/*  76 */       int y1d = 0;
/*  77 */       int x2d = w - 1;
/*  78 */       int y2d = h - 1;
/*  79 */       Transcaler ts = new Transcaler(x1u, y1u, x2u, y2u, x1d, y1d, x2d, y2d);
/*  80 */       int nx = 10000;
/*  81 */       double dx = (x2u - x1u) / (nx - 1);
/*  82 */       double fx = 0.0D;
/*  83 */       int x1 = ts.x(fx);
/*  84 */       int y1 = ts.y(Math.sin(fx));
/*  85 */       for (int ix = 1; ix < nx; ix++) {
/*  86 */         double xi = fx + ix * dx;
/*  87 */         int x2 = ts.x(xi);
/*  88 */         int y2 = ts.y(Math.sin(xi));
/*  89 */         g2d.drawLine(x1, y1, x2, y2);
/*  90 */         x1 = x2;
/*  91 */         y1 = y2;
/*     */       } 
/*  93 */       g2d.dispose();
/*     */     }
/*     */     protected void paintComponent(Graphics g) {
/*  96 */       super.paintComponent(g);
/*  97 */       paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 103 */     IPanel mosaic = new IPanel();
/* 104 */     mosaic.setLayout(new GridLayout(2, 1));
/* 105 */     mosaic.add((Component)new Title("A Sine Wave"));
/* 106 */     mosaic.add((Component)new Wave(5.0D));
/* 107 */     mosaic.setPreferredSize(new Dimension(800, 500));
/*     */     
/* 109 */     JFrame frame = new JFrame();
/* 110 */     frame.setDefaultCloseOperation(3);
/* 111 */     frame.add((Component)mosaic);
/* 112 */     frame.pack();
/* 113 */     frame.setVisible(true);
/*     */     try {
/* 115 */       mosaic.paintToPng(1000.0D, 3.0D, "junk.png");
/* 116 */     } catch (IOException ioe) {
/* 117 */       throw new RuntimeException(ioe);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/IPanelTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */