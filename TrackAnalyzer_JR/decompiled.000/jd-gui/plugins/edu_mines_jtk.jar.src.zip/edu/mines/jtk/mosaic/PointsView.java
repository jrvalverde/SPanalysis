/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointsView
/*     */   extends TiledView
/*     */ {
/*     */   int _ns;
/*     */   ArrayList<Integer> _nx;
/*     */   ArrayList<float[]> _x1;
/*     */   ArrayList<float[]> _x2;
/*     */   int _nxmax;
/*     */   private Orientation _orientation;
/*     */   private Line _lineStyle;
/*     */   private float _lineWidth;
/*     */   private Color _lineColor;
/*     */   private Mark _markStyle;
/*     */   private float _markSize;
/*     */   private Color _markColor;
/*     */   
/*     */   public enum Orientation
/*     */   {
/*  48 */     X1RIGHT_X2UP,
/*  49 */     X1DOWN_X2RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Mark
/*     */   {
/*  57 */     NONE,
/*  58 */     POINT,
/*  59 */     PLUS,
/*  60 */     CROSS,
/*  61 */     ASTERISK,
/*  62 */     HOLLOW_CIRCLE,
/*  63 */     HOLLOW_SQUARE,
/*  64 */     FILLED_CIRCLE,
/*  65 */     FILLED_SQUARE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Line
/*     */   {
/*  73 */     NONE,
/*  74 */     SOLID,
/*  75 */     DASH,
/*  76 */     DOT,
/*  77 */     DASH_DOT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView(float[] x2)
/*     */   {
/* 474 */     this._nx = new ArrayList<Integer>();
/* 475 */     this._x1 = (ArrayList)new ArrayList<float>();
/* 476 */     this._x2 = (ArrayList)new ArrayList<float>();
/*     */     
/* 478 */     this._orientation = Orientation.X1RIGHT_X2UP;
/* 479 */     this._lineStyle = Line.SOLID;
/* 480 */     this._lineWidth = 0.0F;
/* 481 */     this._lineColor = null;
/* 482 */     this._markStyle = Mark.NONE;
/* 483 */     this._markSize = -1.0F;
/* 484 */     this._markColor = null; float[] x1 = Array.rampfloat(0.0F, 1.0F, x2.length); set(x1, x2); } public PointsView(Sampling s1, float[] x2) { this._nx = new ArrayList<Integer>(); this._x1 = (ArrayList)new ArrayList<float>(); this._x2 = (ArrayList)new ArrayList<float>(); this._orientation = Orientation.X1RIGHT_X2UP; this._lineStyle = Line.SOLID; this._lineWidth = 0.0F; this._lineColor = null; this._markStyle = Mark.NONE; this._markSize = -1.0F; this._markColor = null; set(s1, x2); } public PointsView(float[] x1, float[] x2) { this._nx = new ArrayList<Integer>(); this._x1 = (ArrayList)new ArrayList<float>(); this._x2 = (ArrayList)new ArrayList<float>(); this._orientation = Orientation.X1RIGHT_X2UP; this._lineStyle = Line.SOLID; this._lineWidth = 0.0F; this._lineColor = null; this._markStyle = Mark.NONE; this._markSize = -1.0F; this._markColor = null; set(x1, x2); } public PointsView(float[][] x1, float[][] x2) { this._nx = new ArrayList<Integer>(); this._x1 = (ArrayList)new ArrayList<float>(); this._x2 = (ArrayList)new ArrayList<float>(); this._orientation = Orientation.X1RIGHT_X2UP; this._lineStyle = Line.SOLID; this._lineWidth = 0.0F; this._lineColor = null; this._markStyle = Mark.NONE; this._markSize = -1.0F; this._markColor = null; set(x1, x2); }
/*     */   public void set(Sampling s1, float[] x2) { Check.argument((s1.getCount() == x2.length), "s1 count equals x2 length"); int n1 = x2.length; float[] x1 = new float[n1]; for (int i1 = 0; i1 < n1; i1++)
/*     */       x1[i1] = (float)s1.getValue(i1);  set(x1, x2); }
/*     */   public void set(float[] x1, float[] x2) { Check.argument((x1.length == x2.length), "x1.length equals x2.length"); this._ns = 1; this._nx.clear(); this._x1.clear(); this._x2.clear(); this._nxmax = x1.length; this._nx.add(Integer.valueOf(x1.length)); this._x1.add(Array.copy(x1)); this._x2.add(Array.copy(x2)); updateBestProjectors(); repaint(); }
/*     */   public void set(float[][] x1, float[][] x2) { Check.argument((x1.length == x2.length), "x1.length equals x2.length"); this._ns = x1.length; this._nx.clear(); this._x1.clear(); this._x2.clear(); this._nxmax = 0; for (int is = 0; is < this._ns; is++) { Check.argument(((x1[is]).length == (x2[is]).length), "x1[i].length equals x2[i].length"); this._nxmax = MathPlus.max(this._nxmax, (x1[is]).length); this._nx.add(Integer.valueOf((x1[is]).length)); this._x1.add(Array.copy(x1[is])); this._x2.add(Array.copy(x2[is])); }  updateBestProjectors(); repaint(); }
/*     */   public void setOrientation(Orientation orientation) { if (this._orientation != orientation) { this._orientation = orientation; updateBestProjectors(); repaint(); }  }
/*     */   public Orientation getOrientation() { return this._orientation; }
/*     */   public void setStyle(String style) { if (style.contains("r")) { setLineColor(Color.RED); setMarkColor(Color.RED); } else if (style.contains("g")) { setLineColor(Color.GREEN); setMarkColor(Color.GREEN); } else if (style.contains("b")) { setLineColor(Color.BLUE); setMarkColor(Color.BLUE); } else if (style.contains("c")) { setLineColor(Color.CYAN); setMarkColor(Color.CYAN); } else if (style.contains("m")) { setLineColor(Color.MAGENTA); setMarkColor(Color.MAGENTA); } else if (style.contains("y")) { setLineColor(Color.YELLOW); setMarkColor(Color.YELLOW); } else if (style.contains("k")) { setLineColor(Color.BLACK); setMarkColor(Color.BLACK); } else if (style.contains("w")) { setLineColor(Color.WHITE); setMarkColor(Color.WHITE); } else { setLineColor((Color)null); setMarkColor((Color)null); }  if (style.contains("--.")) { setLineStyle(Line.DASH_DOT); } else if (style.contains("--")) { setLineStyle(Line.DASH); } else if (style.contains("-.")) { setLineStyle(Line.DOT); } else if (style.contains("-")) { setLineStyle(Line.SOLID); } else { setLineStyle(Line.NONE); }  if (style.contains("+")) { setMarkStyle(Mark.PLUS); } else if (style.contains("x")) { setMarkStyle(Mark.CROSS); } else if (style.contains("o")) { setMarkStyle(Mark.HOLLOW_CIRCLE); } else if (style.contains("O")) { setMarkStyle(Mark.FILLED_CIRCLE); } else if (style.contains("s")) { setMarkStyle(Mark.HOLLOW_SQUARE); } else if (style.contains("S")) { setMarkStyle(Mark.FILLED_SQUARE); } else if (style.contains(".")) { int i = style.indexOf("."); if (i == 0 || style.charAt(i - 1) != '-')
/* 492 */         setMarkStyle(Mark.POINT);  } else { setMarkStyle(Mark.NONE); }  } private void updateBestProjectors() { float x1min = Float.MAX_VALUE;
/* 493 */     float x2min = Float.MAX_VALUE;
/* 494 */     float x1max = -3.4028235E38F;
/* 495 */     float x2max = -3.4028235E38F;
/* 496 */     for (int is = 0; is < this._ns; is++) {
/* 497 */       int nx = ((Integer)this._nx.get(is)).intValue();
/* 498 */       float[] x1 = this._x1.get(is);
/* 499 */       float[] x2 = this._x2.get(is);
/* 500 */       for (int ix = 0; ix < nx; ix++) {
/* 501 */         float x1i = x1[ix];
/* 502 */         float x2i = x2[ix];
/* 503 */         x1min = MathPlus.min(x1min, x1i);
/* 504 */         x2min = MathPlus.min(x2min, x2i);
/* 505 */         x1max = MathPlus.max(x1max, x1i);
/* 506 */         x2max = MathPlus.max(x2max, x2i);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 516 */     double u0 = 0.0D;
/* 517 */     double u1 = 1.0D;
/* 518 */     if (this._markStyle != Mark.NONE || this._lineWidth > 1.0F) {
/* 519 */       u0 = 0.01D;
/* 520 */       u1 = 0.99D;
/*     */     } 
/*     */ 
/*     */     
/* 524 */     Projector bhp = null;
/* 525 */     Projector bvp = null;
/* 526 */     if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 527 */       bhp = (x1min < x1max) ? new Projector(x1min, x1max, u0, u1) : null;
/* 528 */       bvp = (x2min < x2max) ? new Projector(x2max, x2min, u0, u1) : null;
/* 529 */     } else if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 530 */       bhp = (x2min < x2max) ? new Projector(x2min, x2max, u0, u1) : null;
/* 531 */       bvp = (x1min < x1max) ? new Projector(x1min, x1max, u0, u1) : null;
/*     */     } 
/* 533 */     setBestProjectors(bhp, bvp); }
/*     */   public void setLineStyle(Line style) { this._lineStyle = style; repaint(); }
/*     */   public void setLineWidth(float width) { if (this._lineWidth != width) { this._lineWidth = width; updateBestProjectors(); repaint(); }  }
/*     */   public void setLineColor(Color color) { if (!equalColors(this._lineColor, color)) { this._lineColor = color; repaint(); }  }
/* 537 */   public void setMarkStyle(Mark style) { if (this._markStyle != style) { this._markStyle = style; updateBestProjectors(); repaint(); }  } public void setMarkSize(float size) { if (this._markSize != size) { this._markSize = size; updateBestProjectors(); repaint(); }  } public void setMarkColor(Color color) { if (!equalColors(this._markColor, color)) { this._markColor = color; repaint(); }  } public void paint(Graphics2D g2d) { g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); Projector hp = getHorizontalProjector(); Projector vp = getVerticalProjector(); Transcaler ts = getTranscaler(); float fontSize = g2d.getFont().getSize2D(); float lineWidth = 1.0F; Stroke stroke = g2d.getStroke(); if (stroke instanceof BasicStroke) { BasicStroke bs = (BasicStroke)stroke; lineWidth = bs.getLineWidth(); }  Graphics2D gline = null; if (this._lineStyle != Line.NONE) { gline = (Graphics2D)g2d.create(); float[] dash = null; if (this._lineStyle != Line.SOLID) { float dotLength = lineWidth; float dashLength = 5.0F * lineWidth; float gapLength = 5.0F * lineWidth; if (this._lineStyle == Line.DASH) { dash = new float[] { dashLength, gapLength }; } else if (this._lineStyle == Line.DOT) { dash = new float[] { dotLength, gapLength }; } else if (this._lineStyle == Line.DASH_DOT) { dash = new float[] { dashLength, gapLength, dotLength, gapLength }; }  }  float width = lineWidth; if (this._lineWidth != 0.0F) width *= this._lineWidth;  BasicStroke bs = null; if (dash != null) { int cap = 1; int join = 1; float miter = 10.0F; float phase = 0.0F; bs = new BasicStroke(width, cap, join, miter, dash, phase); } else { bs = new BasicStroke(width); }  gline.setStroke(bs); if (this._lineColor != null) gline.setColor(this._lineColor);  }  Graphics2D gmark = null; int markSize = MathPlus.round(fontSize / 2.0F); if (this._markStyle != Mark.NONE) { gmark = (Graphics2D)g2d.create(); if (this._markSize >= 0.0F) markSize = MathPlus.round(this._markSize * lineWidth);  if (this._markColor != null) gmark.setColor(this._markColor);  float width = lineWidth; if (this._lineWidth != 0.0F) width *= this._lineWidth;  BasicStroke bs = new BasicStroke(width); gmark.setStroke(bs); }  int[] x = new int[this._nxmax]; int[] y = new int[this._nxmax]; for (int is = 0; is < this._ns; is++) { int n = ((Integer)this._nx.get(is)).intValue(); float[] x1 = this._x1.get(is); float[] x2 = this._x2.get(is); computeXY(hp, vp, ts, n, x1, x2, x, y); if (gline != null) gline.drawPolyline(x, y, n);  if (gmark != null) if (this._markStyle == Mark.POINT) { paintPoint(gmark, n, x, y); } else if (this._markStyle == Mark.PLUS) { paintPlus(gmark, markSize, n, x, y); } else if (this._markStyle == Mark.CROSS) { paintCross(gmark, markSize, n, x, y); } else if (this._markStyle == Mark.FILLED_CIRCLE) { paintFilledCircle(gmark, markSize, n, x, y); } else if (this._markStyle == Mark.HOLLOW_CIRCLE) { paintHollowCircle(gmark, markSize, n, x, y); } else if (this._markStyle == Mark.FILLED_SQUARE) { paintFilledSquare(gmark, markSize, n, x, y); } else if (this._markStyle == Mark.HOLLOW_SQUARE) { paintHollowSquare(gmark, markSize, n, x, y); }   }  } private boolean equalColors(Color ca, Color cb) { return (ca == null) ? ((cb == null)) : ca.equals(cb); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeXY(Projector hp, Projector vp, Transcaler ts, int n, float[] x1, float[] x2, int[] x, int[] y) {
/* 544 */     ts = ts.combineWith(hp, vp);
/* 545 */     float[] xv = null;
/* 546 */     float[] yv = null;
/* 547 */     if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 548 */       xv = x1;
/* 549 */       yv = x2;
/* 550 */     } else if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 551 */       xv = x2;
/* 552 */       yv = x1;
/*     */     } 
/* 554 */     for (int i = 0; i < n; i++) {
/* 555 */       x[i] = ts.x(xv[i]);
/* 556 */       y[i] = ts.y(yv[i]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintPoint(Graphics2D g2d, int n, int[] x, int[] y) {
/* 575 */     for (int i = 0; i < n; i++) {
/* 576 */       int xi = x[i];
/* 577 */       int yi = y[i];
/* 578 */       g2d.drawLine(xi, yi, xi, yi);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintPlus(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 583 */     int wh = 2 * s / 2;
/* 584 */     int xy = wh / 2;
/* 585 */     for (int i = 0; i < n; i++) {
/* 586 */       int xi = x[i];
/* 587 */       int yi = y[i];
/* 588 */       g2d.drawLine(xi - xy, yi, xi + xy, yi);
/* 589 */       g2d.drawLine(xi, yi - xy, xi, yi + xy);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintCross(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 594 */     int wh = 2 * s / 2;
/* 595 */     int xy = wh / 2;
/* 596 */     for (int i = 0; i < n; i++) {
/* 597 */       int xi = x[i];
/* 598 */       int yi = y[i];
/* 599 */       g2d.drawLine(xi - xy, yi - xy, xi + xy, yi + xy);
/* 600 */       g2d.drawLine(xi + xy, yi - xy, xi - xy, yi + xy);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintFilledCircle(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 607 */     int wh = 1 + 2 * s / 2;
/* 608 */     int xy = wh / 2;
/* 609 */     for (int i = 0; i < n; i++) {
/* 610 */       g2d.fillOval(x[i] - xy, y[i] - xy, wh, wh);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void paintHollowCircle(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 616 */     int wh = 1 + 2 * s / 2;
/* 617 */     int xy = wh / 2;
/* 618 */     for (int i = 0; i < n; i++) {
/* 619 */       g2d.drawOval(x[i] - xy, y[i] - xy, wh - 1, wh - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void paintFilledSquare(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 625 */     int wh = 1 + 2 * s / 2;
/* 626 */     int xy = wh / 2;
/* 627 */     for (int i = 0; i < n; i++) {
/* 628 */       g2d.fillRect(x[i] - xy, y[i] - xy, wh, wh);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void paintHollowSquare(Graphics2D g2d, int s, int n, int[] x, int[] y) {
/* 634 */     int wh = 1 + 2 * s / 2;
/* 635 */     int xy = wh / 2;
/* 636 */     for (int i = 0; i < n; i++)
/* 637 */       g2d.drawRect(x[i] - xy, y[i] - xy, wh - 1, wh - 1); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/PointsView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */