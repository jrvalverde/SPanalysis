/*     */ package edu.mines.jtk.opengl.test;
/*     */ 
/*     */ import edu.mines.jtk.opengl.Gl;
/*     */ import edu.mines.jtk.opengl.GlPainter;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.FloatBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sphere
/*     */ {
/*  22 */   private static GlPainter painter = new GlPainter()
/*     */     {
/*     */       private FloatBuffer _buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private void computeVertices() {
/*  35 */         int nphi = 50;
/*  36 */         int ntheta = 100;
/*     */         
/*  38 */         float dphi = 0.06283186F;
/*  39 */         float dtheta = 0.06283186F;
/*     */         
/*  41 */         float[] vertices = new float[88200];
/*     */ 
/*     */         
/*  44 */         float[] phiSin = new float[50];
/*  45 */         float[] phiCos = new float[50];
/*  46 */         for (int i = 0; i < 50; i++) {
/*  47 */           float phi = i * 0.06283186F;
/*  48 */           phiSin[i] = (float)Math.sin(phi);
/*  49 */           phiCos[i] = (float)Math.cos(phi);
/*     */         } 
/*  51 */         float[] thetaSin = new float[100];
/*  52 */         float[] thetaCos = new float[100];
/*  53 */         for (int j = 0; j < 100; j++) {
/*  54 */           float theta = j * 0.06283186F;
/*  55 */           thetaSin[j] = (float)Math.sin(theta);
/*  56 */           thetaCos[j] = (float)Math.cos(theta);
/*     */         } 
/*     */ 
/*     */         
/*  60 */         int index = 0;
/*  61 */         for (int m = 0; m < 100; m++) {
/*     */           
/*  63 */           vertices[index++] = 0.0F;
/*  64 */           vertices[index++] = 0.0F;
/*  65 */           vertices[index++] = 1.0F;
/*     */           
/*  67 */           vertices[index++] = thetaCos[m] * phiSin[1];
/*  68 */           vertices[index++] = thetaSin[m] * phiSin[1];
/*  69 */           vertices[index++] = phiCos[1];
/*     */           
/*  71 */           int n = (m + 1) % 100;
/*  72 */           vertices[index++] = thetaCos[n] * phiSin[1];
/*  73 */           vertices[index++] = thetaSin[n] * phiSin[1];
/*  74 */           vertices[index++] = phiCos[1];
/*     */         } 
/*     */ 
/*     */         
/*  78 */         for (int ip = 1; ip < 49; ip++) {
/*  79 */           for (int it = 0; it < 100; it++) {
/*  80 */             int jt = (it + 1) % 100;
/*  81 */             vertices[index++] = thetaCos[it] * phiSin[ip];
/*  82 */             vertices[index++] = thetaSin[it] * phiSin[ip];
/*  83 */             vertices[index++] = phiCos[ip];
/*     */             
/*  85 */             vertices[index++] = thetaCos[it] * phiSin[ip + 1];
/*  86 */             vertices[index++] = thetaSin[it] * phiSin[ip + 1];
/*  87 */             vertices[index++] = phiCos[ip + 1];
/*     */             
/*  89 */             vertices[index++] = thetaCos[jt] * phiSin[ip];
/*  90 */             vertices[index++] = thetaSin[jt] * phiSin[ip];
/*  91 */             vertices[index++] = phiCos[ip];
/*     */             
/*  93 */             vertices[index] = vertices[index - 3];
/*  94 */             index++;
/*  95 */             vertices[index] = vertices[index - 3];
/*  96 */             index++;
/*  97 */             vertices[index] = vertices[index - 3];
/*  98 */             index++;
/*     */             
/* 100 */             vertices[index] = vertices[index - 9];
/* 101 */             index++;
/* 102 */             vertices[index] = vertices[index - 9];
/* 103 */             index++;
/* 104 */             vertices[index] = vertices[index - 9];
/* 105 */             index++;
/*     */             
/* 107 */             vertices[index++] = thetaCos[jt] * phiSin[ip + 1];
/* 108 */             vertices[index++] = thetaSin[jt] * phiSin[ip + 1];
/* 109 */             vertices[index++] = phiCos[ip + 1];
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 114 */         for (int k = 0; k < 100; k++) {
/* 115 */           vertices[index++] = thetaCos[k] * phiSin[49];
/* 116 */           vertices[index++] = thetaSin[k] * phiSin[49];
/* 117 */           vertices[index++] = phiCos[49];
/*     */ 
/*     */           
/* 120 */           vertices[index++] = 0.0F;
/* 121 */           vertices[index++] = 0.0F;
/* 122 */           vertices[index++] = 1.0F;
/*     */           
/* 124 */           int n = (k + 1) % 100;
/* 125 */           vertices[index++] = thetaCos[n] * phiSin[49];
/* 126 */           vertices[index++] = thetaSin[n] * phiSin[49];
/* 127 */           vertices[index++] = phiCos[49];
/*     */         } 
/*     */         
/* 130 */         this._buffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
/*     */         
/* 132 */         this._buffer.put(vertices);
/*     */       }
/*     */       
/*     */       public void glInit() {
/* 136 */         computeVertices();
/*     */         
/* 138 */         float[] mat_specular = { 1.0F, 1.0F, 1.0F, 1.0F };
/* 139 */         float[] mat_shininess = { 50.0F };
/* 140 */         float[] light_position = { 1.0F, -3.0F, 1.0F, 0.0F };
/* 141 */         float[] white_light = { 1.0F, 1.0F, 1.0F, 1.0F };
/* 142 */         float[] lmodel_ambient = { 0.1F, 0.1F, 0.1F, 1.0F };
/*     */         
/* 144 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 145 */         Gl.glShadeModel(7425);
/* 146 */         Gl.glMaterialfv(1028, 4610, mat_specular);
/* 147 */         Gl.glMaterialfv(1028, 5633, mat_shininess);
/* 148 */         Gl.glLightfv(16384, 4611, light_position);
/* 149 */         Gl.glLightfv(16384, 4609, white_light);
/* 150 */         Gl.glLightfv(16384, 4610, white_light);
/* 151 */         Gl.glLightModelfv(2899, lmodel_ambient);
/* 152 */         Gl.glLightModeli(2898, 0);
/*     */       }
/*     */       
/*     */       public void glResize(int width, int height, int widthOld, int heightOld) {
/* 156 */         Gl.glViewport(0, 0, width, height);
/* 157 */         Gl.glMatrixMode(5889);
/* 158 */         Gl.glLoadIdentity();
/* 159 */         Gl.glOrtho(-1.2D, 1.2D, -1.2D, 1.2D, -2.0D, 2.0D);
/* 160 */         Gl.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */       
/*     */       public void glPaint() {
/* 164 */         Gl.glClear(16640);
/* 165 */         Gl.glEnable(2896);
/* 166 */         Gl.glEnable(16384);
/* 167 */         Gl.glEnable(2929);
/* 168 */         Gl.glEnableClientState(32885);
/* 169 */         Gl.glEnableClientState(32884);
/* 170 */         Gl.glVertexPointer(3, 5126, 0, this._buffer);
/* 171 */         Gl.glNormalPointer(5126, 0, this._buffer);
/* 172 */         Gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 173 */         Gl.glDrawArrays(4, 0, this._buffer.capacity() / 3);
/* 174 */         Gl.glFlush();
/*     */       }
/*     */     };
/*     */   
/*     */   public static void main(String[] args) {
/* 179 */     TestSimple.run(args, painter);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/test/Sphere.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */