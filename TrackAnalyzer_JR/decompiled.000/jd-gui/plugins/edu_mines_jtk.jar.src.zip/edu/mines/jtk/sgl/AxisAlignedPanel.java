/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AxisAlignedPanel
/*    */   extends Node
/*    */ {
/*    */   private AxisAlignedFrame _frame;
/*    */   
/*    */   public AxisAlignedPanel() {}
/*    */   
/*    */   public AxisAlignedPanel(AxisAlignedFrame frame) {
/* 30 */     setFrame(frame);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedFrame getFrame() {
/* 38 */     return this._frame;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFrame(AxisAlignedFrame frame) {
/* 48 */     this._frame = frame;
/* 49 */     if (this._frame != null) {
/* 50 */       BoxConstraint constraint = getBoxConstraint();
/* 51 */       if (constraint != null)
/* 52 */         this._frame.setBoxConstraint(constraint); 
/*    */     } 
/* 54 */     dirtyBoundingSphere();
/* 55 */     dirtyDraw();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BoxConstraint getBoxConstraint() {
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 80 */     if (this._frame == null) {
/* 81 */       return new BoundingSphere();
/*    */     }
/* 83 */     return this._frame.computeBoundingSphereOfFrame(finite);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void pick(PickContext pc) {
/* 95 */     if (this._frame != null)
/* 96 */       this._frame.pickOnFrame(pc); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/AxisAlignedPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */