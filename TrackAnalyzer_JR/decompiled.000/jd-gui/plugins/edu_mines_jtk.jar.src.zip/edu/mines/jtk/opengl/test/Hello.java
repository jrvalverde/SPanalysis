/*    */ package edu.mines.jtk.opengl.test;
/*    */ 
/*    */ import edu.mines.jtk.opengl.Gl;
/*    */ import edu.mines.jtk.opengl.GlPainter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Hello
/*    */ {
/* 20 */   private static GlPainter painter = new GlPainter() {
/*    */       public void glInit() {
/* 22 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 23 */         System.out.println("OpenGL version=" + Gl.glGetString(7938));
/* 24 */         System.out.println("OpenGL vendor=" + Gl.glGetString(7936));
/*    */       }
/*    */       public void glResize(int width, int height, int widthOld, int heightOld) {
/* 27 */         Gl.glViewport(0, 0, width, height);
/* 28 */         Gl.glMatrixMode(5889);
/* 29 */         Gl.glLoadIdentity();
/* 30 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/*    */       }
/*    */       public void glPaint() {
/* 33 */         Gl.glClear(16384);
/*    */         
/* 35 */         Gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 36 */         Gl.glBegin(9);
/* 37 */         Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 38 */         Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 39 */         Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 40 */         Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 41 */         Gl.glEnd();
/* 42 */         Gl.glFlush();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 46 */     TestSimple.run(args, painter);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/test/Hello.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */