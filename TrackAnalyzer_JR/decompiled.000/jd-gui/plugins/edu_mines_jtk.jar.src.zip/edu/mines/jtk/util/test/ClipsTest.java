/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Clips;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipsTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 22 */     TestSuite suite = new TestSuite(ClipsTest.class);
/* 23 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testPercentiles() {
/* 27 */     double tiny = 1.1920928955078125E-6D;
/* 28 */     int n = 101;
/*    */ 
/*    */ 
/*    */     
/* 32 */     float[] f = Array.rampfloat(0.0F, 1.0F, n);
/* 33 */     Clips clips = new Clips(f);
/* 34 */     for (int imin = 0, imax = n - 1; imin < imax; imin++, imax--) {
/* 35 */       double pmin = 100.0D * imin / (n - 1);
/* 36 */       double pmax = 100.0D * imax / (n - 1);
/* 37 */       clips.setPercentiles(pmin, pmax);
/* 38 */       float cmin = clips.getClipMin();
/* 39 */       float cmax = clips.getClipMax();
/* 40 */       assertEquals(imin, cmin, tiny);
/* 41 */       assertEquals(imax, cmax, tiny);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/ClipsTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */