/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Node
/*     */ {
/*     */   private boolean _selected;
/*     */   
/*     */   public final boolean isSelected() {
/*  56 */     return this._selected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelected(boolean selected) {
/*  70 */     if (this instanceof Selectable && this._selected != selected) {
/*     */ 
/*     */       
/*  73 */       this._selected = selected;
/*  74 */       selectedChanged();
/*     */ 
/*     */       
/*  77 */       World world = getWorld();
/*  78 */       if (world != null) {
/*  79 */         world.updateSelectedSet(this);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countParents() {
/*  88 */     return this._parentList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Group> getParents() {
/*  96 */     return this._parentList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public World getWorld() {
/* 104 */     for (Group parent : this._parentList) {
/* 105 */       World world = parent.getWorld();
/* 106 */       if (world != null)
/* 107 */         return world; 
/*     */     } 
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dirtyDraw() {
/* 117 */     for (Group parent : this._parentList) {
/* 118 */       parent.dirtyDraw();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingSphere getBoundingSphere(boolean finite) {
/* 129 */     if (this._boundingSphere == null || this._boundingSphereFinite != finite) {
/* 130 */       this._boundingSphere = computeBoundingSphere(finite);
/* 131 */       this._boundingSphereFinite = finite;
/*     */     } 
/* 133 */     return this._boundingSphere;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dirtyBoundingSphere() {
/* 142 */     if (this._boundingSphere != null) {
/* 143 */       this._boundingSphere = null;
/* 144 */       for (Group parent : this._parentList) {
/* 145 */         parent.dirtyBoundingSphere();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStates(StateSet states) {
/* 154 */     this._states = states;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void selectedChanged() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 186 */     return finite ? BoundingSphere.empty() : BoundingSphere.infinite();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getAttributeBits() {
/* 208 */     return 1048575;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cullApply(CullContext cc) {
/* 224 */     if (cc.frustumIntersectsSphereOf(this)) {
/* 225 */       cullBegin(cc);
/* 226 */       cull(cc);
/* 227 */       cullEnd(cc);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cullBegin(CullContext cc) {
/* 237 */     cc.pushNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cull(CullContext cc) {
/* 246 */     cc.appendNodes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cullEnd(CullContext cc) {
/* 254 */     cc.popNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawApply(DrawContext dc) {
/* 268 */     drawBegin(dc);
/* 269 */     draw(dc);
/* 270 */     drawEnd(dc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawBegin(DrawContext dc) {
/* 280 */     dc.pushNode(this);
/* 281 */     int bits = getAttributeBits();
/* 282 */     if (bits != 1048575 && this._states != null)
/* 283 */       bits |= this._states.getAttributeBits(); 
/* 284 */     Gl.glPushAttrib(bits);
/* 285 */     if (this._states != null) {
/* 286 */       this._states.apply();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void draw(DrawContext dc) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawEnd(DrawContext dc) {
/* 303 */     Gl.glPopAttrib();
/* 304 */     dc.popNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickApply(PickContext pc) {
/* 320 */     if (pc.segmentIntersectsSphereOf(this)) {
/* 321 */       pickBegin(pc);
/* 322 */       pick(pc);
/* 323 */       pickEnd(pc);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickBegin(PickContext pc) {
/* 333 */     pc.pushNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pick(PickContext pc) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickEnd(PickContext pc) {
/* 351 */     pc.popNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean addParent(Group parent) {
/* 364 */     if (!this._parentList.contains(parent)) {
/* 365 */       this._parentList.add(parent);
/* 366 */       return true;
/*     */     } 
/* 368 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean removeParent(Group parent) {
/* 379 */     return this._parentList.remove(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 386 */   private BoundingSphere _boundingSphere = null;
/*     */   private boolean _boundingSphereFinite = false;
/* 388 */   private ArrayList<Group> _parentList = new ArrayList<Group>(2);
/*     */   private StateSet _states;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Node.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */