/*    */ package edu.mines.jtk.lapack.test;
/*    */ 
/*    */ import edu.mines.jtk.lapack.DMatrix;
/*    */ import edu.mines.jtk.lapack.DMatrixEvd;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixEvdTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     TestSuite suite = new TestSuite(DMatrixEvdTest.class);
/* 24 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSymmetric() {
/* 28 */     DMatrix a = new DMatrix(new double[][] { { 4.0D, 1.0D, 1.0D }, { 1.0D, 2.0D, 3.0D }, { 1.0D, 3.0D, 6.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 33 */     test(a);
/* 34 */     a = DMatrix.random(10, 10);
/* 35 */     a.plusEquals(a.transpose());
/* 36 */     test(a);
/*    */   }
/*    */   
/*    */   public void testAsymmetric() {
/* 40 */     DMatrix a = new DMatrix(new double[][] { { 0.0D, 1.0D, 0.0D, 0.0D }, { 1.0D, 0.0D, 2.0E-7D, 0.0D }, { 0.0D, -2.0E-7D, 0.0D, 1.0D }, { 0.0D, 0.0D, 1.0D, 0.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     test(a);
/* 47 */     a = DMatrix.random(10, 10);
/* 48 */     test(a);
/*    */   }
/*    */   
/*    */   private void test(DMatrix a) {
/* 52 */     DMatrixEvd evd = new DMatrixEvd(a);
/* 53 */     DMatrix d = evd.getD();
/* 54 */     DMatrix v = evd.getV();
/* 55 */     DMatrixTest.assertEqualFuzzy(a.times(v), v.times(d));
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/DMatrixEvdTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */