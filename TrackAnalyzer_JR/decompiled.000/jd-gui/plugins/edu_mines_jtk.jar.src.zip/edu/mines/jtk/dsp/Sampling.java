/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sampling
/*     */ {
/*     */   public static final double DEFAULT_TOLERANCE = 1.0E-6D;
/*     */   private int _n;
/*     */   private double _d;
/*     */   private double _f;
/*     */   private double[] _v;
/*     */   private double _t;
/*     */   private double _td;
/*     */   
/*     */   public Sampling(int n) {
/*  90 */     this(n, 1.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling(int n, double d, double f) {
/* 100 */     this(n, d, f, 1.0E-6D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling(int n, double d, double f, double t) {
/* 111 */     Check.argument((n > 0), "n>0");
/* 112 */     Check.argument((d > 0.0D), "d>0.0");
/* 113 */     this._n = n;
/* 114 */     this._d = d;
/* 115 */     this._f = f;
/* 116 */     this._v = null;
/* 117 */     this._t = t;
/* 118 */     this._td = this._t * this._d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling(double[] v) {
/* 133 */     this(v, 1.0E-6D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling(double[] v, double t) {
/* 148 */     Check.argument((v.length > 0), "v.length>0");
/* 149 */     Check.argument(Array.isIncreasing(v), "v is increasing");
/* 150 */     this._n = v.length;
/* 151 */     this._d = (this._n < 2) ? 1.0D : ((v[this._n - 1] - v[0]) / (this._n - 1));
/* 152 */     this._f = v[0];
/* 153 */     this._t = t;
/* 154 */     this._td = this._t * this._d;
/* 155 */     boolean uniform = true;
/* 156 */     for (int i = 0; i < this._n && uniform; i++) {
/* 157 */       double vi = this._f + i * this._d;
/* 158 */       if (!almostEqual(v[i], vi, this._td))
/* 159 */         uniform = false; 
/*     */     } 
/* 161 */     this._v = uniform ? null : Array.copy(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() {
/* 169 */     return this._n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDelta() {
/* 178 */     return this._d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getFirst() {
/* 186 */     return this._f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLast() {
/* 194 */     return (this._v != null) ? this._v[this._n - 1] : (this._f + (this._n - 1) * this._d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(int i) {
/* 203 */     Check.index(this._n, i);
/* 204 */     return value(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getValues() {
/* 214 */     double[] v = null;
/* 215 */     if (this._v != null) {
/* 216 */       v = Array.copy(this._v);
/*     */     } else {
/* 218 */       v = new double[this._n];
/* 219 */       for (int i = 0; i < this._n; i++)
/* 220 */         v[i] = this._f + i * this._d; 
/*     */     } 
/* 222 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUniform() {
/* 236 */     return (this._v == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalentTo(Sampling s) {
/* 247 */     Sampling t = this;
/* 248 */     if (t.isUniform() != s.isUniform())
/* 249 */       return false; 
/* 250 */     if (t.isUniform()) {
/* 251 */       if (t.getCount() != s.getCount())
/* 252 */         return false; 
/* 253 */       double d1 = tinyWith(s);
/* 254 */       double tf = t.getFirst();
/* 255 */       double tl = t.getLast();
/* 256 */       double sf = s.getFirst();
/* 257 */       double sl = s.getLast();
/* 258 */       return (almostEqual(tf, sf, d1) && almostEqual(tl, sl, d1));
/*     */     } 
/* 260 */     double tiny = tinyWith(s);
/* 261 */     for (int i = 0; i < this._n; i++) {
/* 262 */       if (!almostEqual(this._v[i], s.value(i), tiny))
/* 263 */         return false; 
/*     */     } 
/* 265 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatible(Sampling s) {
/* 278 */     Sampling t = this;
/* 279 */     int nt = t.getCount();
/* 280 */     int ns = s.getCount();
/* 281 */     double tf = t.getFirst();
/* 282 */     double sf = s.getFirst();
/* 283 */     double tl = t.getLast();
/* 284 */     double sl = s.getLast();
/* 285 */     int it = 0;
/* 286 */     int is = 0;
/* 287 */     int jt = nt - 1;
/* 288 */     int js = ns - 1;
/* 289 */     if (tl < sf)
/* 290 */       return true; 
/* 291 */     if (sl < tf) {
/* 292 */       return true;
/*     */     }
/* 294 */     if (tf < sf) {
/* 295 */       it = t.indexOf(sf);
/*     */     } else {
/* 297 */       is = s.indexOf(tf);
/*     */     } 
/* 299 */     if (it < 0 || is < 0)
/* 300 */       return false; 
/* 301 */     if (tl < sl) {
/* 302 */       js = s.indexOf(tl);
/*     */     } else {
/* 304 */       jt = t.indexOf(sl);
/*     */     } 
/* 306 */     if (jt < 0 || js < 0)
/* 307 */       return false; 
/* 308 */     int mt = 1 + jt - it;
/* 309 */     int ms = 1 + js - is;
/* 310 */     if (mt != ms)
/* 311 */       return false; 
/* 312 */     if (!t.isUniform() || !s.isUniform()) {
/* 313 */       double tiny = tinyWith(s);
/* 314 */       for (jt = it, js = is; jt != mt; jt++, js++) {
/* 315 */         if (!almostEqual(t.value(jt), s.value(js), tiny))
/* 316 */           return false; 
/*     */       } 
/*     */     } 
/* 319 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOf(double x) {
/* 332 */     int i = -1;
/* 333 */     if (isUniform()) {
/* 334 */       int j = (int)Math.round((x - this._f) / this._d);
/* 335 */       if (0 <= j && j < this._n && almostEqual(x, this._f + j * this._d, this._td))
/* 336 */         i = j; 
/*     */     } else {
/* 338 */       int j = Array.binarySearch(this._v, x);
/* 339 */       if (0 <= j) {
/* 340 */         i = j;
/*     */       } else {
/* 342 */         j = -(j + 1);
/* 343 */         if (j > 0 && almostEqual(x, this._v[j - 1], this._td)) {
/* 344 */           i = j - 1;
/* 345 */         } else if (j < this._n && almostEqual(x, this._v[j], this._td)) {
/* 346 */           i = j;
/*     */         } 
/*     */       } 
/*     */     } 
/* 350 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfNearest(double x) {
/* 359 */     int i = -1;
/* 360 */     if (isUniform()) {
/* 361 */       i = (int)Math.round((x - this._f) / this._d);
/* 362 */       if (i < 0)
/* 363 */         i = 0; 
/* 364 */       if (i >= this._n)
/* 365 */         i = this._n - 1; 
/*     */     } else {
/* 367 */       i = Array.binarySearch(this._v, x);
/* 368 */       if (i < 0) {
/* 369 */         i = -(i + 1);
/* 370 */         if (i == this._n) {
/* 371 */           i = this._n - 1;
/* 372 */         } else if (i > 0 && Math.abs(x - this._v[i - 1]) < Math.abs(x - this._v[i])) {
/* 373 */           i--;
/*     */         } 
/*     */       } 
/*     */     } 
/* 377 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double valueOfNearest(double x) {
/* 386 */     return getValue(indexOfNearest(x));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] overlapWith(Sampling s) {
/* 419 */     Sampling t = this;
/* 420 */     int nt = t.getCount();
/* 421 */     int ns = s.getCount();
/* 422 */     double tf = t.getFirst();
/* 423 */     double sf = s.getFirst();
/* 424 */     double tl = t.getLast();
/* 425 */     double sl = s.getLast();
/* 426 */     int it = 0;
/* 427 */     int is = 0;
/* 428 */     int jt = nt - 1;
/* 429 */     int js = ns - 1;
/* 430 */     if (tl < sf)
/* 431 */       return new int[] { 0, nt, 0 }; 
/* 432 */     if (sl < tf) {
/* 433 */       return new int[] { 0, 0, ns };
/*     */     }
/* 435 */     if (tf < sf) {
/* 436 */       it = t.indexOf(sf);
/*     */     } else {
/* 438 */       is = s.indexOf(tf);
/*     */     } 
/* 440 */     if (it < 0 || is < 0)
/* 441 */       return null; 
/* 442 */     if (tl < sl) {
/* 443 */       js = s.indexOf(tl);
/*     */     } else {
/* 445 */       jt = t.indexOf(sl);
/*     */     } 
/* 447 */     if (jt < 0 || js < 0)
/* 448 */       return null; 
/* 449 */     int mt = 1 + jt - it;
/* 450 */     int ms = 1 + js - is;
/* 451 */     if (mt != ms)
/* 452 */       return null; 
/* 453 */     if (!t.isUniform() || !s.isUniform()) {
/* 454 */       double tiny = tinyWith(s);
/* 455 */       for (jt = it, js = is; jt != mt; jt++, js++) {
/* 456 */         if (!almostEqual(t.value(jt), s.value(js), tiny))
/* 457 */           return null; 
/*     */       } 
/*     */     } 
/* 460 */     return new int[] { mt, it, is };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling mergeWith(Sampling s) {
/* 484 */     Sampling t = this;
/* 485 */     int[] overlap = t.overlapWith(s);
/* 486 */     if (overlap == null)
/* 487 */       return null; 
/* 488 */     int n = overlap[0];
/* 489 */     int it = overlap[1];
/* 490 */     int is = overlap[2];
/* 491 */     int nt = t.getCount();
/* 492 */     int ns = s.getCount();
/* 493 */     int nm = nt + ns - n;
/* 494 */     if (n > 0 && t.isUniform() && s.isUniform()) {
/* 495 */       double dm = t.getDelta();
/* 496 */       double fm = (it == 0) ? s.getFirst() : t.getFirst();
/* 497 */       return new Sampling(nm, dm, fm);
/*     */     } 
/* 499 */     double[] vm = new double[nm];
/* 500 */     int jm = 0;
/* 501 */     for (int j = 0; j < it; j++)
/* 502 */       vm[jm++] = t.value(j); 
/* 503 */     for (int i = 0; i < is; i++)
/* 504 */       vm[jm++] = s.value(i);  int jt;
/* 505 */     for (jt = it; jt < it + n; jt++)
/* 506 */       vm[jm++] = t.value(jt); 
/* 507 */     for (jt = it + n; jt < nt; jt++)
/* 508 */       vm[jm++] = t.value(jt); 
/* 509 */     for (int js = is + n; js < ns; js++)
/* 510 */       vm[jm++] = s.value(js); 
/* 511 */     return new Sampling(vm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling shift(double s) {
/* 523 */     if (this._v == null) {
/* 524 */       return new Sampling(this._n, this._d, this._f + s, this._t);
/*     */     }
/* 526 */     double[] v = new double[this._n];
/* 527 */     for (int i = 0; i < this._n; i++)
/* 528 */       v[i] = this._v[i] + s; 
/* 529 */     return new Sampling(v, this._t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling prepend(int m) {
/* 543 */     int n = this._n + m;
/* 544 */     double f = this._f - m * this._d;
/* 545 */     if (this._v == null) {
/* 546 */       return new Sampling(n, this._d, f, this._t);
/*     */     }
/* 548 */     double[] v = new double[n]; int i;
/* 549 */     for (i = 0; i < m; i++)
/* 550 */       v[i] = f + i * this._d; 
/* 551 */     for (i = m; i < n; i++)
/* 552 */       v[i] = this._v[i - m]; 
/* 553 */     return new Sampling(v, this._t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling append(int m) {
/* 567 */     int n = this._n + m;
/* 568 */     if (this._v == null) {
/* 569 */       return new Sampling(n, this._d, this._f, this._t);
/*     */     }
/* 571 */     double[] v = new double[n]; int i;
/* 572 */     for (i = 0; i < this._n; i++)
/* 573 */       v[i] = this._v[i]; 
/* 574 */     for (i = this._n; i < n; i++)
/* 575 */       v[i] = this._f + i * this._d; 
/* 576 */     return new Sampling(v, this._t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling decimate(int m) {
/* 590 */     Check.argument((m > 0), "m>0");
/* 591 */     int n = 1 + (this._n - 1) / m;
/* 592 */     if (this._v == null) {
/* 593 */       return new Sampling(n, m * this._d, this._f, this._t);
/*     */     }
/* 595 */     double[] v = new double[n]; int j;
/* 596 */     for (int i = 0; i < n; i++, j += m)
/* 597 */       v[i] = this._v[j]; 
/* 598 */     return new Sampling(v, this._t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling interpolate(int m) {
/* 612 */     Check.argument((m > 0), "m>0");
/* 613 */     int n = this._n + (this._n - 1) * (m - 1);
/* 614 */     if (this._v == null) {
/* 615 */       return new Sampling(n, this._d / m, this._f, this._t);
/*     */     }
/* 617 */     double[] v = new double[n];
/* 618 */     v[0] = this._v[0]; int j;
/* 619 */     for (int i = 1; i < this._n; i++, j += m) {
/* 620 */       v[j] = this._v[i];
/* 621 */       double dk = (v[j] - v[j - m]) / m;
/* 622 */       double vk = v[j - m];
/* 623 */       for (int k = j - m + 1; k < j; k++, vk += dk)
/* 624 */         v[k] = vk; 
/*     */     } 
/* 626 */     return new Sampling(v, this._t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value(int i) {
/* 641 */     return (this._v != null) ? this._v[i] : (this._f + i * this._d);
/*     */   }
/*     */   
/*     */   private boolean almostEqual(double v1, double v2, double tiny) {
/* 645 */     double diff = v1 - v2;
/* 646 */     return (diff < 0.0D) ? ((-diff < tiny)) : ((diff < tiny));
/*     */   }
/*     */   
/*     */   private double tinyWith(Sampling s) {
/* 650 */     return (this._td < s._td) ? this._td : s._td;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Sampling.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */