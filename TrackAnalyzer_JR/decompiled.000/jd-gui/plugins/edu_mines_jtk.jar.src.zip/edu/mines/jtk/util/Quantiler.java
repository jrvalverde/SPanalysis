/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Quantiler
/*     */ {
/*     */   private float _q;
/*     */   private float _fnull;
/*     */   private double _m0;
/*     */   private double _m1;
/*     */   private double _m2;
/*     */   private double _m3;
/*     */   private double _m4;
/*     */   private double _q0;
/*     */   private double _q1;
/*     */   private double _q2;
/*     */   private double _q3;
/*     */   private double _q4;
/*     */   private double _f0;
/*     */   private double _f1;
/*     */   private double _f2;
/*     */   private double _f3;
/*     */   private double _f4;
/*     */   private double _d0;
/*     */   private double _d1;
/*     */   private double _d2;
/*     */   private double _d3;
/*     */   private double _d4;
/*     */   private boolean _ignoreNull;
/*     */   private boolean _inited;
/*     */   
/*     */   public Quantiler(float q) {
/*  37 */     Check.argument((0.0F <= q), "0.0f<=q");
/*  38 */     Check.argument((q <= 1.0F), "q<=1.0f");
/*  39 */     this._q = q;
/*  40 */     this._m0 = -1.0D;
/*  41 */     this._q2 = 0.0D;
/*  42 */     this._inited = (this._q == 0.0D || this._q == 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Quantiler(float q, float fnull) {
/*  51 */     Check.argument((0.0F <= q), "0.0f<=q");
/*  52 */     Check.argument((q <= 1.0F), "q<=1.0f");
/*  53 */     this._q = q;
/*  54 */     this._fnull = fnull;
/*  55 */     this._ignoreNull = true;
/*  56 */     this._m0 = -1.0D;
/*  57 */     this._q2 = fnull;
/*  58 */     this._inited = (this._q == 0.0D || this._q == 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float estimate() {
/*  66 */     return (float)this._q2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float update(float f) {
/*  75 */     if (!this._inited) {
/*  76 */       initOne(f);
/*     */     } else {
/*  78 */       updateOne(f);
/*     */     } 
/*  80 */     return estimate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float update(float[] f) {
/*  89 */     int n = f.length;
/*  90 */     int i = 0;
/*  91 */     for (; !this._inited && i < n; i++)
/*  92 */       initOne(f[i]); 
/*  93 */     for (; i < n; i++)
/*  94 */       updateOne(f[i]); 
/*  95 */     return estimate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float update(float[][] f) {
/* 104 */     int n = f.length;
/* 105 */     for (int i = 0; i < n; i++)
/* 106 */       update(f[i]); 
/* 107 */     return estimate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float update(float[][][] f) {
/* 116 */     int n = f.length;
/* 117 */     for (int i = 0; i < n; i++)
/* 118 */       update(f[i]); 
/* 119 */     return estimate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float[] f) {
/* 129 */     Quantiler qu = new Quantiler(q);
/* 130 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float[][] f) {
/* 140 */     Quantiler qu = new Quantiler(q);
/* 141 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float[][][] f) {
/* 151 */     Quantiler qu = new Quantiler(q);
/* 152 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float fnull, float[] f) {
/* 163 */     Quantiler qu = new Quantiler(q, fnull);
/* 164 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float fnull, float[][] f) {
/* 175 */     Quantiler qu = new Quantiler(q, fnull);
/* 176 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float estimate(float q, float fnull, float[][][] f) {
/* 187 */     Quantiler qu = new Quantiler(q, fnull);
/* 188 */     return qu.update(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initOne(float f) {
/* 206 */     if (this._ignoreNull && f == this._fnull) {
/*     */       return;
/*     */     }
/*     */     
/* 210 */     if (this._m0 < 0.0D) {
/* 211 */       this._m0 = 0.0D;
/* 212 */       this._q0 = f;
/* 213 */     } else if (this._m1 == 0.0D) {
/* 214 */       this._m1 = 1.0D;
/* 215 */       this._q1 = f;
/* 216 */     } else if (this._m2 == 0.0D) {
/* 217 */       this._m2 = 2.0D;
/* 218 */       this._q2 = f;
/* 219 */     } else if (this._m3 == 0.0D) {
/* 220 */       this._m3 = 3.0D;
/* 221 */       this._q3 = f;
/* 222 */     } else if (this._m4 == 0.0D) {
/* 223 */       this._m4 = 4.0D;
/* 224 */       this._q4 = f;
/*     */     } 
/* 226 */     if (this._m4 == 0.0D) {
/*     */       return;
/*     */     }
/*     */     
/* 230 */     double[] y = { this._q0, this._q1, this._q2, this._q3, this._q4 };
/* 231 */     for (int i = 1; i < 5; i++) {
/* 232 */       for (int j = i; j > 0 && y[j - 1] > y[j]; j--) {
/* 233 */         double ytemp = y[j - 1];
/* 234 */         y[j - 1] = y[j];
/* 235 */         y[j] = ytemp;
/*     */       } 
/*     */     } 
/* 238 */     this._q0 = y[0];
/* 239 */     this._q1 = y[1];
/* 240 */     this._q2 = y[2];
/* 241 */     this._q3 = y[3];
/* 242 */     this._q4 = y[4];
/*     */ 
/*     */     
/* 245 */     this._f0 = 0.0D;
/* 246 */     this._f1 = 2.0D * this._q;
/* 247 */     this._f2 = 4.0D * this._q;
/* 248 */     this._f3 = 2.0D + 2.0D * this._q;
/* 249 */     this._f4 = 4.0D;
/*     */ 
/*     */     
/* 252 */     this._d0 = 0.0D;
/* 253 */     this._d1 = this._q / 2.0D;
/* 254 */     this._d2 = this._q;
/* 255 */     this._d3 = (1.0D + this._q) / 2.0D;
/* 256 */     this._d4 = 1.0D;
/*     */ 
/*     */     
/* 259 */     this._inited = true;
/*     */   }
/*     */   
/*     */   private void updateOne(float f) {
/* 263 */     assert this._inited : "quantiler is initialized";
/*     */ 
/*     */     
/* 266 */     if (this._ignoreNull && f == this._fnull) {
/*     */       return;
/*     */     }
/*     */     
/* 270 */     if (this._q == 0.0F) {
/* 271 */       if (f < this._q2)
/* 272 */         this._q2 = f; 
/* 273 */     } else if (this._q == 1.0F) {
/* 274 */       if (f > this._q2) {
/* 275 */         this._q2 = f;
/*     */       }
/*     */     } else {
/*     */       
/* 279 */       if (f < this._q0) {
/* 280 */         this._m1++;
/* 281 */         this._m2++;
/* 282 */         this._m3++;
/* 283 */         this._m4++;
/* 284 */         this._q0 = f;
/* 285 */       } else if (f < this._q1) {
/* 286 */         this._m1++;
/* 287 */         this._m2++;
/* 288 */         this._m3++;
/* 289 */         this._m4++;
/* 290 */       } else if (f < this._q2) {
/* 291 */         this._m2++;
/* 292 */         this._m3++;
/* 293 */         this._m4++;
/* 294 */       } else if (f < this._q3) {
/* 295 */         this._m3++;
/* 296 */         this._m4++;
/* 297 */       } else if (f < this._q4) {
/* 298 */         this._m4++;
/*     */       } else {
/* 300 */         this._m4++;
/* 301 */         this._q4 = f;
/*     */       } 
/*     */ 
/*     */       
/* 305 */       this._f0 += this._d0;
/* 306 */       this._f1 += this._d1;
/* 307 */       this._f2 += this._d2;
/* 308 */       this._f3 += this._d3;
/* 309 */       this._f4 += this._d4;
/*     */ 
/*     */ 
/*     */       
/* 313 */       double mm = this._m1 - 1.0D;
/* 314 */       double mp = this._m1 + 1.0D;
/* 315 */       if (this._f1 >= mp && this._m2 > mp) {
/* 316 */         this._q1 = qp(mp, this._m0, this._m1, this._m2, this._q0, this._q1, this._q2);
/* 317 */         this._m1 = mp;
/* 318 */       } else if (this._f1 <= mm && this._m0 < mm) {
/* 319 */         this._q1 = qm(mm, this._m0, this._m1, this._m2, this._q0, this._q1, this._q2);
/* 320 */         this._m1 = mm;
/*     */       } 
/* 322 */       mm = this._m2 - 1.0D;
/* 323 */       mp = this._m2 + 1.0D;
/* 324 */       if (this._f2 >= mp && this._m3 > mp) {
/* 325 */         this._q2 = qp(mp, this._m1, this._m2, this._m3, this._q1, this._q2, this._q3);
/* 326 */         this._m2 = mp;
/* 327 */       } else if (this._f2 <= mm && this._m1 < mm) {
/* 328 */         this._q2 = qm(mm, this._m1, this._m2, this._m3, this._q1, this._q2, this._q3);
/* 329 */         this._m2 = mm;
/*     */       } 
/* 331 */       mm = this._m3 - 1.0D;
/* 332 */       mp = this._m3 + 1.0D;
/* 333 */       if (this._f3 >= mp && this._m4 > mp) {
/* 334 */         this._q3 = qp(mp, this._m2, this._m3, this._m4, this._q2, this._q3, this._q4);
/* 335 */         this._m3 = mp;
/* 336 */       } else if (this._f3 <= mm && this._m2 < mm) {
/* 337 */         this._q3 = qm(mm, this._m2, this._m3, this._m4, this._q2, this._q3, this._q4);
/* 338 */         this._m3 = mm;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double qp(double mp, double m0, double m1, double m2, double q0, double q1, double q2) {
/* 348 */     double qt = q1 + ((mp - m0) * (q2 - q1) / (m2 - m1) + (m2 - mp) * (q1 - q0) / (m1 - m0)) / (m2 - m0);
/* 349 */     return (qt <= q2) ? qt : (q1 + (q2 - q1) / (m2 - m1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double qm(double mm, double m0, double m1, double m2, double q0, double q1, double q2) {
/* 357 */     double qt = q1 - ((mm - m0) * (q2 - q1) / (m2 - m1) + (m2 - mm) * (q1 - q0) / (m1 - m0)) / (m2 - m0);
/* 358 */     return (q0 <= qt) ? qt : (q1 + (q0 - q1) / (m0 - m1));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Quantiler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */