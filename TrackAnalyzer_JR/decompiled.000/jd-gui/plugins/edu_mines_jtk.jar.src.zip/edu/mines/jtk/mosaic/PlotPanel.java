/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlotPanel
/*     */   extends IPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int _colorBarWidthMinimum;
/*     */   private Mosaic _mosaic;
/*     */   private ColorBar _colorBar;
/*     */   private String _colorBarFormat;
/*     */   private String _colorBarLabel;
/*     */   private PixelsView _colorBarPixelsView;
/*     */   private Title _title;
/*     */   private Orientation _orientation;
/*     */   private AxesPlacement _axesPlacement;
/*     */   
/*     */   public enum AxesPlacement
/*     */   {
/*  55 */     LEFT_TOP,
/*  56 */     LEFT_BOTTOM,
/*  57 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Orientation
/*     */   {
/*  66 */     X1RIGHT_X2UP,
/*  67 */     X1DOWN_X2RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel() {
/*  75 */     this(1, 1, Orientation.X1RIGHT_X2UP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel(int nrow, int ncol) {
/*  85 */     this(nrow, ncol, Orientation.X1RIGHT_X2UP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel(Orientation orientation) {
/*  93 */     this(1, 1, orientation);
/*     */   }
/*     */   
/*     */   public PlotPanel(int nrow, int ncol, Orientation orientation) {
/*  97 */     this(nrow, ncol, orientation, axesPlacement(orientation));
/*     */   }
/*     */   private static AxesPlacement axesPlacement(Orientation orientation) {
/*     */     AxesPlacement axesPlacement;
/* 101 */     if (orientation == Orientation.X1DOWN_X2RIGHT) {
/* 102 */       axesPlacement = AxesPlacement.LEFT_TOP;
/*     */     } else {
/* 104 */       axesPlacement = AxesPlacement.LEFT_BOTTOM;
/*     */     } 
/* 106 */     return axesPlacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel(int nrow, int ncol, Orientation orientation, AxesPlacement axesPlacement) {
/*     */     Set<Mosaic.AxesPlacement> axesPlacementSet;
/* 231 */     this._colorBarWidthMinimum = 0; this._orientation = orientation; this._axesPlacement = axesPlacement; setLayout(new GridBagLayout()); if (axesPlacement == AxesPlacement.LEFT_TOP) {
/*     */       axesPlacementSet = EnumSet.of(Mosaic.AxesPlacement.LEFT, Mosaic.AxesPlacement.TOP);
/*     */     } else if (axesPlacement == AxesPlacement.LEFT_BOTTOM) {
/*     */       axesPlacementSet = EnumSet.of(Mosaic.AxesPlacement.LEFT, Mosaic.AxesPlacement.BOTTOM);
/*     */     } else {
/*     */       axesPlacementSet = EnumSet.noneOf(Mosaic.AxesPlacement.class);
/*     */     }  this._mosaic = new Mosaic(nrow, ncol, axesPlacementSet); GridBagConstraints gbc = new GridBagConstraints(); gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.gridheight = 1; gbc.weightx = 100.0D; gbc.weighty = 100.0D; gbc.fill = 1; add(this._mosaic, gbc);
/*     */     setPreferredSize(new Dimension(200 + 300 * ncol, 100 + 300 * nrow));
/*     */     revalidate();
/*     */   } public Mosaic getMosaic() { return this._mosaic; } public Tile getTile(int irow, int icol) { return this._mosaic.getTile(irow, icol); }
/* 241 */   public void setColorBarFormat(String format) { this._colorBarFormat = format;
/* 242 */     if (this._colorBar != null) {
/* 243 */       this._colorBar.setFormat(format);
/* 244 */       revalidate();
/*     */     }  }
/*     */   public ColorBar addColorBar() { return addColorBar((String)null); }
/*     */   public ColorBar addColorBar(String label) { this._colorBarLabel = label; if (this._colorBar == null) { this._colorBar = new ColorBar(label); this._colorBar.setFont(getFont()); this._colorBar.setForeground(getForeground()); this._colorBar.setBackground(getBackground()); if (this._colorBarFormat != null)
/*     */         this._colorBar.setFormat(this._colorBarFormat);  if (this._colorBarWidthMinimum != 0)
/*     */         this._colorBar.setWidthMinimum(this._colorBarWidthMinimum);  if (this._colorBarPixelsView != null) { this._colorBarPixelsView.addColorMapListener(this._colorBar); GridBagConstraints gbc = new GridBagConstraints(); gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 1; gbc.gridheight = 1; gbc.weightx = 0.0D; gbc.weighty = 0.0D; gbc.fill = 3; gbc.anchor = 17; int top = this._mosaic.getHeightAxesTop(); int left = 25; int bottom = this._mosaic.getHeightAxesBottom(); int right = 0; gbc.insets = new Insets(top, left, bottom, right); add(this._colorBar, gbc); revalidate(); }
/*     */        }
/*     */     else { this._colorBar.setLabel(label); revalidate(); }
/* 252 */      return this._colorBar; } public void removeColorBar() { if (this._colorBar != null) {
/* 253 */       if (this._colorBarPixelsView != null)
/* 254 */         this._colorBarPixelsView.removeColorMapListener(this._colorBar); 
/* 255 */       remove(this._colorBar);
/* 256 */       revalidate();
/* 257 */       this._colorBar = null;
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTitle(String title) {
/* 267 */     setTitle(title);
/*     */   } public void setColorBarWidthMinimum(int widthMinimum) {
/*     */     this._colorBarWidthMinimum = widthMinimum;
/*     */     if (this._colorBar != null) {
/*     */       this._colorBar.setWidthMinimum(widthMinimum);
/*     */       revalidate();
/*     */     } 
/*     */   } public void setTitle(String title) {
/* 275 */     if (title != null) {
/* 276 */       if (this._title == null) {
/* 277 */         this._title = new Title(title);
/* 278 */         Font font = getFont();
/* 279 */         font.deriveFont(1.5F * font.getSize2D());
/* 280 */         this._title.setFont(getFont());
/* 281 */         this._title.setForeground(getForeground());
/* 282 */         this._title.setBackground(getBackground());
/* 283 */         GridBagConstraints gbc = new GridBagConstraints();
/* 284 */         gbc.gridx = 0;
/* 285 */         gbc.gridy = 0;
/* 286 */         gbc.gridwidth = 1;
/* 287 */         gbc.gridheight = 1;
/* 288 */         gbc.weightx = 0.0D;
/* 289 */         gbc.weighty = 0.0D;
/* 290 */         gbc.fill = 1;
/* 291 */         int top = 0;
/* 292 */         int left = this._mosaic.getWidthAxesLeft();
/* 293 */         int bottom = 0;
/* 294 */         int right = this._mosaic.getWidthAxesRight();
/* 295 */         gbc.insets = new Insets(top, left, bottom, right);
/* 296 */         add(this._title, gbc);
/* 297 */         revalidate();
/*     */       } else {
/* 299 */         this._title.set(title);
/*     */       } 
/* 301 */     } else if (this._title != null) {
/* 302 */       remove(this._title);
/* 303 */       revalidate();
/* 304 */       this._title = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTitle() {
/* 313 */     setTitle((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLimits(double hmin, double vmin, double hmax, double vmax) {
/* 326 */     setHLimits(hmin, hmax);
/* 327 */     setVLimits(vmin, vmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLimits(double hmin, double hmax) {
/* 338 */     setHLimits(0, hmin, hmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLimits(double vmin, double vmax) {
/* 349 */     setVLimits(0, vmin, vmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLimits(int icol, double hmin, double hmax) {
/* 361 */     Check.argument((hmin < hmax), "hmin<hmax");
/* 362 */     setBestHorizontalProjector(icol, new Projector(hmin, hmax));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLimits(int irow, double vmin, double vmax) {
/* 374 */     Check.argument((vmin < vmax), "vmin<vmax");
/* 375 */     if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 376 */       setBestVerticalProjector(irow, new Projector(vmax, vmin));
/*     */     } else {
/* 378 */       setBestVerticalProjector(irow, new Projector(vmin, vmax));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLimitsDefault() {
/* 387 */     setHLimitsDefault();
/* 388 */     setVLimitsDefault();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLimitsDefault() {
/* 396 */     setHLimitsDefault(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLimitsDefault() {
/* 404 */     setVLimitsDefault(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLimitsDefault(int icol) {
/* 414 */     setBestHorizontalProjector(icol, (Projector)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLimitsDefault(int irow) {
/* 424 */     setBestVerticalProjector(irow, (Projector)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLabel(String label) {
/* 432 */     setHLabel(0, label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLabel(String label) {
/* 440 */     setVLabel(0, label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHLabel(int icol, String label) {
/* 449 */     if (this._axesPlacement == AxesPlacement.LEFT_TOP) {
/* 450 */       this._mosaic.getTileAxisTop(icol).setLabel(label);
/*     */     } else {
/* 452 */       this._mosaic.getTileAxisBottom(icol).setLabel(label);
/*     */     } 
/* 454 */     adjustColorBar();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVLabel(int irow, String label) {
/* 463 */     this._mosaic.getTileAxisLeft(irow).setLabel(label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHFormat(String format) {
/* 471 */     setHFormat(0, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVFormat(String format) {
/* 479 */     setVFormat(0, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHFormat(int icol, String format) {
/* 488 */     if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 489 */       this._mosaic.getTileAxisTop(icol).setFormat(format);
/*     */     } else {
/* 491 */       this._mosaic.getTileAxisBottom(icol).setFormat(format);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVFormat(int irow, String format) {
/* 501 */     this._mosaic.getTileAxisLeft(irow).setFormat(format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridView addGrid() {
/* 509 */     return addGrid(0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridView addGrid(String parameters) {
/* 520 */     return addGrid(0, 0, parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridView addGrid(int irow, int icol) {
/* 530 */     GridView gv = new GridView();
/* 531 */     return addGridView(irow, icol, gv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GridView addGrid(int irow, int icol, String parameters) {
/* 544 */     GridView gv = new GridView(parameters);
/* 545 */     return addGridView(irow, icol, gv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelsView addPixels(float[][] f) {
/* 556 */     return addPixels(0, 0, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelsView addPixels(Sampling s1, Sampling s2, float[][] f) {
/* 568 */     return addPixels(0, 0, s1, s2, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelsView addPixels(int irow, int icol, float[][] f) {
/* 581 */     PixelsView pv = new PixelsView(f);
/* 582 */     return addPixelsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelsView addPixels(int irow, int icol, Sampling s1, Sampling s2, float[][] f) {
/* 597 */     PixelsView pv = new PixelsView(s1, s2, f);
/* 598 */     return addPixelsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(float[] x1, float[] x2) {
/* 608 */     return addPoints(0, 0, x1, x2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(float[] x2) {
/* 618 */     return addPoints(0, 0, x2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(Sampling s1, float[] x2) {
/* 628 */     return addPoints(0, 0, s1, x2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(float[][] x1, float[][] x2) {
/* 638 */     return addPoints(0, 0, x1, x2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(int irow, int icol, float[] x1, float[] x2) {
/* 650 */     PointsView pv = new PointsView(x1, x2);
/* 651 */     return addPointsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(int irow, int icol, float[] x2) {
/* 663 */     PointsView pv = new PointsView(x2);
/* 664 */     return addPointsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(int irow, int icol, Sampling s1, float[] x2) {
/* 676 */     PointsView pv = new PointsView(s1, x2);
/* 677 */     return addPointsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointsView addPoints(int irow, int icol, float[][] x1, float[][] x2) {
/* 689 */     PointsView pv = new PointsView(x1, x2);
/* 690 */     return addPointsView(irow, icol, pv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceView addSequence(float[] f) {
/* 700 */     return addSequence(0, 0, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceView addSequence(Sampling sx, float[] f) {
/* 710 */     return addSequence(0, 0, sx, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceView addSequence(int irow, int icol, float[] f) {
/* 722 */     SequenceView sv = new SequenceView(f);
/* 723 */     return addSequenceView(irow, icol, sv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceView addSequence(int irow, int icol, Sampling sx, float[] f) {
/* 735 */     SequenceView sv = new SequenceView(sx, f);
/* 736 */     return addSequenceView(irow, icol, sv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addTiledView(TiledView tv) {
/* 747 */     return addTiledView(0, 0, tv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addTiledView(int irow, int icol, TiledView tv) {
/* 761 */     return this._mosaic.getTile(irow, icol).addTiledView(tv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(TiledView tv) {
/* 771 */     int nrow = this._mosaic.countRows();
/* 772 */     int ncol = this._mosaic.countColumns();
/* 773 */     for (int irow = 0; irow < nrow; irow++) {
/* 774 */       for (int icol = 0; icol < ncol; icol++) {
/* 775 */         if (getTile(irow, icol).removeTiledView(tv))
/* 776 */           return true; 
/*     */       } 
/*     */     } 
/* 779 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 788 */     super.setFont(font);
/* 789 */     if (this._mosaic != null)
/* 790 */       this._mosaic.setFont(font); 
/* 791 */     if (this._colorBar != null)
/* 792 */       this._colorBar.setFont(font); 
/* 793 */     if (this._title != null)
/* 794 */       this._title.setFont(font.deriveFont(1.5F * font.getSize2D())); 
/* 795 */     adjustColorBar();
/* 796 */     revalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForeground(Color color) {
/* 804 */     super.setForeground(color);
/* 805 */     if (this._mosaic != null)
/* 806 */       this._mosaic.setForeground(color); 
/* 807 */     if (this._colorBar != null)
/* 808 */       this._colorBar.setForeground(color); 
/* 809 */     if (this._title != null) {
/* 810 */       this._title.setForeground(color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackground(Color color) {
/* 818 */     super.setBackground(color);
/* 819 */     if (this._mosaic != null)
/* 820 */       this._mosaic.setBackground(color); 
/* 821 */     if (this._colorBar != null)
/* 822 */       this._colorBar.setBackground(color); 
/* 823 */     if (this._title != null) {
/* 824 */       this._title.setBackground(color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Title
/*     */     extends IPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Title(String text) {
/* 847 */       this.text = text;
/*     */     }
/*     */     
/*     */     void set(String text) {
/* 851 */       this.text = text;
/* 852 */       repaint();
/*     */     }
/*     */     
/*     */     public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 856 */       g2d = createGraphics(g2d, x, y, w, h);
/* 857 */       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */       
/* 861 */       Font font = g2d.getFont();
/* 862 */       FontMetrics fm = g2d.getFontMetrics();
/* 863 */       FontRenderContext frc = g2d.getFontRenderContext();
/* 864 */       LineMetrics lm = font.getLineMetrics(this.text, frc);
/*     */ 
/*     */       
/* 867 */       int fd = Math.round(lm.getDescent());
/*     */       
/* 869 */       int wt = fm.stringWidth(this.text);
/* 870 */       int xt = Math.max(0, Math.min(w - wt, (w - wt) / 2));
/* 871 */       int yt = h - 1 - 2 * fd;
/* 872 */       g2d.drawString(this.text, xt, yt);
/*     */       
/* 874 */       g2d.dispose();
/*     */     }
/*     */     
/*     */     protected void paintComponent(Graphics g) {
/* 878 */       super.paintComponent(g);
/* 879 */       paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */     }
/*     */     
/*     */     public Dimension getMinimumSize() {
/* 883 */       if (isMinimumSizeSet()) {
/* 884 */         return super.getMinimumSize();
/*     */       }
/* 886 */       Font font = getFont();
/* 887 */       FontMetrics fm = getFontMetrics(font);
/* 888 */       int fh = fm.getHeight();
/* 889 */       int fd = fm.getDescent();
/* 890 */       int wt = fm.stringWidth(this.text);
/* 891 */       return new Dimension(wt, fd + fh);
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 895 */       if (isPreferredSizeSet()) {
/* 896 */         return super.getPreferredSize();
/*     */       }
/* 898 */       return getMinimumSize();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private GridView addGridView(int irow, int icol, GridView gv) {
/* 904 */     this._mosaic.getTile(irow, icol).addTiledView(gv);
/* 905 */     return gv;
/*     */   }
/*     */   
/*     */   private PixelsView addPixelsView(int irow, int icol, PixelsView pv) {
/* 909 */     if (this._colorBar != null && this._colorBarPixelsView != null)
/* 910 */       this._colorBarPixelsView.removeColorMapListener(this._colorBar); 
/* 911 */     this._colorBarPixelsView = pv;
/* 912 */     if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 913 */       this._colorBarPixelsView.setOrientation(PixelsView.Orientation.X1RIGHT_X2UP);
/* 914 */     } else if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 915 */       this._colorBarPixelsView.setOrientation(PixelsView.Orientation.X1DOWN_X2RIGHT);
/*     */     } 
/* 917 */     if (this._colorBar != null)
/* 918 */       this._colorBarPixelsView.addColorMapListener(this._colorBar); 
/* 919 */     this._mosaic.getTile(irow, icol).addTiledView(this._colorBarPixelsView);
/* 920 */     return this._colorBarPixelsView;
/*     */   }
/*     */   
/*     */   private PointsView addPointsView(int irow, int icol, PointsView pv) {
/* 924 */     if (this._orientation == Orientation.X1RIGHT_X2UP) {
/* 925 */       pv.setOrientation(PointsView.Orientation.X1RIGHT_X2UP);
/* 926 */     } else if (this._orientation == Orientation.X1DOWN_X2RIGHT) {
/* 927 */       pv.setOrientation(PointsView.Orientation.X1DOWN_X2RIGHT);
/*     */     } 
/* 929 */     this._mosaic.getTile(irow, icol).addTiledView(pv);
/* 930 */     return pv;
/*     */   }
/*     */   
/*     */   private SequenceView addSequenceView(int irow, int icol, SequenceView sv) {
/* 934 */     this._mosaic.getTile(irow, icol).addTiledView(sv);
/* 935 */     return sv;
/*     */   }
/*     */   
/*     */   private void setBestHorizontalProjector(int icol, Projector p) {
/* 939 */     int nrow = getMosaic().countRows();
/* 940 */     for (int irow = 0; irow < nrow; irow++)
/* 941 */       getTile(irow, icol).setBestHorizontalProjector(p); 
/*     */   }
/*     */   
/*     */   private void setBestVerticalProjector(int irow, Projector p) {
/* 945 */     int ncol = getMosaic().countColumns();
/* 946 */     for (int icol = 0; icol < ncol; icol++) {
/* 947 */       getTile(irow, icol).setBestVerticalProjector(p);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustColorBar() {
/* 955 */     if (this._colorBar != null) {
/* 956 */       removeColorBar();
/* 957 */       addColorBar(this._colorBarLabel);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/PlotPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */