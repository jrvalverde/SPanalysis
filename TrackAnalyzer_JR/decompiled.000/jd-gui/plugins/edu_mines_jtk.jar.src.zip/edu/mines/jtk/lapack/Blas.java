/*    */ package edu.mines.jtk.lapack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Blas
/*    */ {
/*    */   static final int ROW_MAJOR = 101;
/*    */   static final int COL_MAJOR = 102;
/*    */   static final int NO_TRANS = 111;
/*    */   static final int TRANS = 112;
/*    */   static final int CONJ_TRANS = 113;
/*    */   static final int UPPER = 121;
/*    */   static final int LOWER = 122;
/*    */   static final int NON_UNIT = 131;
/*    */   static final int UNIT = 132;
/*    */   static final int LEFT = 141;
/*    */   static final int RIGHT = 142;
/*    */   
/*    */   static native void dgemm(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double[] paramArrayOfdouble1, int paramInt7, double[] paramArrayOfdouble2, int paramInt8, double paramDouble2, double[] paramArrayOfdouble3, int paramInt9);
/*    */   
/*    */   static native void dtrsm(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble, double[] paramArrayOfdouble1, int paramInt8, double[] paramArrayOfdouble2, int paramInt9);
/*    */   
/*    */   static {
/* 43 */     System.loadLibrary("edu_mines_jtk_lapack");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/Blas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */