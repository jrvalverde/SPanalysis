/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.ColorMap;
/*     */ import edu.mines.jtk.awt.ColorMapListener;
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorBar
/*     */   extends IPanel
/*     */   implements ColorMapListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ColorBar() {
/*  31 */     this((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private Mosaic _mosaic = new Mosaic(1, 1, EnumSet.of(Mosaic.AxesPlacement.RIGHT)); public ColorBar(String label) {
/*  41 */     if (label != null)
/*  42 */       this._mosaic.getTileAxisRight(0).setLabel(label); 
/*  43 */     this._mosaic.setWidthMinimum(0, 25);
/*  44 */     this._mosaic.setWidthElastic(0, 0);
/*  45 */     this._tile = this._mosaic.getTile(0, 0);
/*  46 */     setLayout(new BorderLayout());
/*  47 */     add(this._mosaic, "Center");
/*     */   }
/*     */ 
/*     */   
/*     */   private Tile _tile;
/*     */   private PixelsView _pixels;
/*     */   
/*     */   public void setLabel(String label) {
/*  55 */     this._mosaic.getTileAxisRight(0).setLabel(label);
/*  56 */     revalidate();
/*     */   }
/*     */   
/*     */   public void setWidthMinimum(int widthMinimum) {
/*  60 */     this._mosaic.getTileAxisRight(0).setWidthMinimum(widthMinimum);
/*  61 */     revalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormat(String format) {
/*  72 */     this._mosaic.getTileAxisRight(0).setFormat(format);
/*  73 */     revalidate();
/*     */   }
/*     */   
/*     */   public void colorMapChanged(ColorMap cm) {
/*  77 */     float vmin = (float)cm.getMinValue();
/*  78 */     float vmax = (float)cm.getMaxValue();
/*  79 */     if (vmin == vmax) {
/*  80 */       vmin -= Math.ulp(vmin);
/*  81 */       vmax += Math.ulp(vmax);
/*     */     } 
/*  83 */     int nv = 256;
/*  84 */     double dv = ((vmax - vmin) / (nv - 1));
/*  85 */     double fv = vmin;
/*  86 */     Sampling vs = new Sampling(nv, dv, fv);
/*  87 */     float[][] va = new float[nv][1];
/*  88 */     Color[] ca = new Color[nv];
/*  89 */     for (int iv = 0; iv < nv; iv++) {
/*  90 */       float vi = (float)vs.getValue(iv);
/*  91 */       va[iv][0] = vi;
/*  92 */       ca[iv] = cm.getColor(vi);
/*     */     } 
/*  94 */     if (this._pixels == null) {
/*  95 */       this._pixels = new PixelsView(va);
/*  96 */       this._pixels.setOrientation(PixelsView.Orientation.X1RIGHT_X2UP);
/*  97 */       this._pixels.setInterpolation(PixelsView.Interpolation.LINEAR);
/*  98 */       this._pixels.setClips(vmin, vmax);
/*  99 */       this._tile.addTiledView(this._pixels);
/*     */     } 
/* 101 */     IndexColorModel icm = ColorMap.makeIndexColorModel(ca);
/* 102 */     this._pixels.setColorModel(icm);
/* 103 */     Sampling s1 = new Sampling(1);
/* 104 */     Sampling s2 = vs;
/* 105 */     this._pixels.set(s1, s2, va);
/*     */   }
/*     */   
/*     */   public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 109 */     this._mosaic.paintToRect(g2d, x, y, w, h);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 114 */     super.setFont(font);
/* 115 */     if (this._mosaic != null)
/* 116 */       this._mosaic.setFont(font); 
/* 117 */     revalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setForeground(Color color) {
/* 122 */     super.setForeground(color);
/* 123 */     if (this._mosaic != null) {
/* 124 */       this._mosaic.setForeground(color);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBackground(Color color) {
/* 129 */     super.setBackground(color);
/* 130 */     if (this._mosaic != null) {
/* 131 */       this._mosaic.setBackground(color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 138 */     super.paintComponent(g);
/* 139 */     paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/ColorBar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */