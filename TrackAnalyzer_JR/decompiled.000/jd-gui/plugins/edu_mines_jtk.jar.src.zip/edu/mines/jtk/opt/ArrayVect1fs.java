/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect1fs
/*     */   implements Vect
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*  21 */   protected ArrayVect1f[] _data = null;
/*     */ 
/*     */   
/*  24 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect1fs(ArrayVect1f[] data) {
/*  29 */     init(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(ArrayVect1f[] data) {
/*  36 */     this._data = data;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  41 */     return this._data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect1f[] getData() {
/*  47 */     return this._data;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayVect1fs clone() {
/*     */     try {
/*  53 */       ArrayVect1fs result = (ArrayVect1fs)super.clone();
/*  54 */       if (this._data != null) {
/*  55 */         ArrayVect1f[] data = (ArrayVect1f[])this._data.clone();
/*  56 */         for (int i = 0; i < data.length; i++) {
/*  57 */           data[i] = data[i].clone();
/*     */         }
/*  59 */         result.init(data);
/*     */       } 
/*  61 */       return result;
/*  62 */     } catch (CloneNotSupportedException ex) {
/*  63 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/*  64 */       e.initCause(ex);
/*  65 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/*  71 */     double result = 0.0D;
/*  72 */     ArrayVect1fs rhs = (ArrayVect1fs)other;
/*  73 */     for (int i = 0; i < this._data.length; i++) {
/*  74 */       result += this._data[i].dot(rhs._data[i]);
/*     */     }
/*  76 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  81 */     StringBuilder sb = new StringBuilder();
/*  82 */     sb.append("(");
/*  83 */     for (int i = 0; i < this._data.length; i++) {
/*  84 */       sb.append("" + this._data[i]);
/*  85 */       if (i < this._data.length - 1) sb.append(", "); 
/*     */     } 
/*  87 */     sb.append(")");
/*  88 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  93 */     for (int i = 0; i < this._data.length; i++) {
/*  94 */       this._data[i].dispose();
/*     */     }
/*  96 */     this._data = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 101 */     double scale = Almost.FLOAT.divide(1.0D, getSize(), 0.0D);
/* 102 */     for (int i = 0; i < this._data.length; i++) {
/* 103 */       this._data[i].multiplyInverseCovariance();
/* 104 */       VectUtil.scale(this._data[i], scale);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {
/* 110 */     for (int i = 0; i < this._data.length; i++) {
/* 111 */       this._data[i].constrain();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 120 */     ArrayVect1fs rhs = (ArrayVect1fs)other;
/* 121 */     for (int i = 0; i < this._data.length; i++) {
/* 122 */       this._data[i].add(scaleThis, scaleOther, rhs._data[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 128 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/* 133 */     double result = 0.0D;
/* 134 */     for (int i = 0; i < this._data.length; i++) {
/* 135 */       result += this._data[i].magnitude();
/*     */     }
/* 137 */     result = Almost.FLOAT.divide(result, getSize(), 0.0D);
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 144 */     out.writeInt(this._data.length);
/* 145 */     for (int i = 0; i < this._data.length; i++) {
/* 146 */       out.writeObject(this._data[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 153 */     int length = in.readInt();
/* 154 */     this._data = new ArrayVect1f[length];
/* 155 */     for (int i = 0; i < this._data.length; i++)
/* 156 */       this._data[i] = (ArrayVect1f)in.readObject(); 
/*     */   }
/*     */   
/*     */   public ArrayVect1fs() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect1fs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */