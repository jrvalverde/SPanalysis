/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.CausalFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CausalFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(CausalFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1Random() {
/*  28 */     int[] lag1 = { 0, 1, 2 };
/*  29 */     float[] a = { 1.0F, -1.8F, 0.81F };
/*  30 */     CausalFilter cf = new CausalFilter(lag1, a);
/*  31 */     int n = 100;
/*  32 */     float tiny = n * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/*  35 */     float[] x = randfloat(n);
/*  36 */     float[] y = randfloat(n);
/*  37 */     float[] ax = zerofloat(n);
/*  38 */     float[] ay = zerofloat(n);
/*  39 */     cf.apply(x, ax);
/*  40 */     cf.applyTranspose(y, ay);
/*  41 */     float dyx = dot(y, ax);
/*  42 */     float dxy = dot(x, ay);
/*  43 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/*  47 */     x = randfloat(n);
/*  48 */     y = randfloat(n);
/*  49 */     float[] bx = zerofloat(n);
/*  50 */     float[] by = zerofloat(n);
/*  51 */     cf.applyInverse(x, bx);
/*  52 */     cf.applyInverseTranspose(y, by);
/*  53 */     dyx = dot(y, bx);
/*  54 */     dxy = dot(x, by);
/*  55 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/*  59 */     x = randfloat(n);
/*  60 */     y = Array.copy(x);
/*  61 */     cf.apply(y, y);
/*  62 */     cf.applyInverse(y, y);
/*  63 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/*  67 */     x = randfloat(n);
/*  68 */     y = Array.copy(x);
/*  69 */     cf.applyInverseTranspose(y, y);
/*  70 */     cf.applyTranspose(y, y);
/*  71 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void test2Random() {
/*  76 */     int[] lag1 = { 0, 1, 2, 3, 4, -4, -3, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */     
/*  80 */     int[] lag2 = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/*  84 */     float[] a = { 1.7954845F, -0.64490664F, -0.03850411F, -0.01793403F, -0.00708972F, -0.02290331F, -0.04141619F, -0.08457147F, -0.20031442F, -0.5565992F };
/*     */ 
/*     */ 
/*     */     
/*  88 */     CausalFilter cf = new CausalFilter(lag1, lag2, a);
/*  89 */     int n1 = 19;
/*  90 */     int n2 = 21;
/*  91 */     float tiny = (n1 * n2) * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/*  94 */     float[][] x = randfloat(n1, n2);
/*  95 */     float[][] y = randfloat(n1, n2);
/*  96 */     float[][] ax = zerofloat(n1, n2);
/*  97 */     float[][] ay = zerofloat(n1, n2);
/*  98 */     cf.apply(x, ax);
/*  99 */     cf.applyTranspose(y, ay);
/* 100 */     float dyx = dot(y, ax);
/* 101 */     float dxy = dot(x, ay);
/* 102 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 106 */     x = randfloat(n1, n2);
/* 107 */     y = randfloat(n1, n2);
/* 108 */     float[][] bx = zerofloat(n1, n2);
/* 109 */     float[][] by = zerofloat(n1, n2);
/* 110 */     cf.applyInverse(x, bx);
/* 111 */     cf.applyInverseTranspose(y, by);
/* 112 */     dyx = dot(y, bx);
/* 113 */     dxy = dot(x, by);
/* 114 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 118 */     x = randfloat(n1, n2);
/* 119 */     y = Array.copy(x);
/* 120 */     cf.apply(y, y);
/* 121 */     cf.applyInverse(y, y);
/* 122 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/* 126 */     x = randfloat(n1, n2);
/* 127 */     y = Array.copy(x);
/* 128 */     cf.applyInverseTranspose(y, y);
/* 129 */     cf.applyTranspose(y, y);
/* 130 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void test3Random() {
/* 135 */     int[] lag1 = { 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     int[] lag2 = { 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     float[] a = { 2.3110454F, -0.4805547F, -0.0143204F, -0.0291793F, -0.1057476F, -0.4572746F, -0.0115732F, -0.0047283F, -0.0149963F, -0.0408317F, -0.0945958F, -0.0223166F, -0.0062781F, -0.0213786F, -0.0898909F, -0.4322719F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     CausalFilter cf = new CausalFilter(lag1, lag2, lag3, a);
/* 160 */     int n1 = 11;
/* 161 */     int n2 = 13;
/* 162 */     int n3 = 12;
/* 163 */     float tiny = (n1 * n2 * n3) * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/* 166 */     float[][][] x = randfloat(n1, n2, n3);
/* 167 */     float[][][] y = randfloat(n1, n2, n3);
/* 168 */     float[][][] ax = zerofloat(n1, n2, n3);
/* 169 */     float[][][] ay = zerofloat(n1, n2, n3);
/* 170 */     cf.apply(x, ax);
/* 171 */     cf.applyTranspose(y, ay);
/* 172 */     float dyx = dot(y, ax);
/* 173 */     float dxy = dot(x, ay);
/* 174 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 178 */     x = randfloat(n1, n2, n3);
/* 179 */     y = randfloat(n1, n2, n3);
/* 180 */     float[][][] bx = zerofloat(n1, n2, n3);
/* 181 */     float[][][] by = zerofloat(n1, n2, n3);
/* 182 */     cf.applyInverse(x, bx);
/* 183 */     cf.applyInverseTranspose(y, by);
/* 184 */     dyx = dot(y, bx);
/* 185 */     dxy = dot(x, by);
/* 186 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 190 */     x = randfloat(n1, n2, n3);
/* 191 */     y = Array.copy(x);
/* 192 */     cf.apply(y, y);
/* 193 */     cf.applyInverse(y, y);
/* 194 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/* 198 */     x = randfloat(n1, n2, n3);
/* 199 */     y = Array.copy(x);
/* 200 */     cf.applyInverseTranspose(y, y);
/* 201 */     cf.applyTranspose(y, y);
/* 202 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void testFactorFomelExample() {
/* 207 */     float[] r = { 24.0F, 242.0F, 867.0F, 1334.0F, 867.0F, 242.0F, 24.0F };
/* 208 */     int n = r.length;
/* 209 */     int[] lag1 = { 0, 1, 2, 3 };
/* 210 */     CausalFilter cf = new CausalFilter(lag1);
/* 211 */     cf.factorWilsonBurg(10, 0.0F, r);
/* 212 */     float[] a = cf.getA();
/* 213 */     assertEquals(24.0F, a[0], 1.1920929E-6F);
/* 214 */     assertEquals(26.0F, a[1], 1.1920929E-6F);
/* 215 */     assertEquals(9.0F, a[2], 1.1920929E-6F);
/* 216 */     assertEquals(1.0F, a[3], 1.1920929E-6F);
/*     */   }
/*     */   
/*     */   public void testFactorLaplacian2() {
/* 220 */     float[][] r = { { 0.0F, -0.999F, 0.0F }, { -0.999F, 4.0F, -0.999F }, { 0.0F, -0.999F, 0.0F } };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     int[] lag1 = { 0, 1, 2, 3, 4, -4, -3, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */     
/* 229 */     int[] lag2 = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/* 233 */     CausalFilter cf = new CausalFilter(lag1, lag2);
/* 234 */     cf.factorWilsonBurg(100, 1.1920929E-7F, r);
/* 235 */     float[][] s = new float[3][3];
/* 236 */     float[][] t = new float[3][3];
/* 237 */     s[1][1] = 1.0F;
/* 238 */     cf.apply(s, t);
/* 239 */     cf.applyTranspose(t, s);
/* 240 */     float emax = 0.01F * r[1][1];
/* 241 */     for (int i2 = 0; i2 < 3; i2++) {
/* 242 */       for (int i1 = 0; i1 < 3; i1++) {
/* 243 */         assertEquals(r[i2][i1], s[i2][i1], emax);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testFactorLaplacian3() {
/* 252 */     float[][][] r = { { { 0.0F, 0.0F, 0.0F }, { 0.0F, -0.999F, 0.0F }, { 0.0F, 0.0F, 0.0F } }, { { 0.0F, -0.999F, 0.0F }, { -0.999F, 6.0F, -0.999F }, { 0.0F, -0.999F, 0.0F } }, { { 0.0F, 0.0F, 0.0F }, { 0.0F, -0.999F, 0.0F }, { 0.0F, 0.0F, 0.0F } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     int[] lag1 = { 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     int[] lag2 = { 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     CausalFilter cf = new CausalFilter(lag1, lag2, lag3);
/* 286 */     cf.factorWilsonBurg(100, 1.1920929E-7F, r);
/* 287 */     float[][][] s = new float[3][3][3];
/* 288 */     float[][][] t = new float[3][3][3];
/* 289 */     s[1][1][1] = 1.0F;
/* 290 */     cf.apply(s, t);
/* 291 */     cf.applyTranspose(t, s);
/* 292 */     float emax = 0.01F * r[1][1][1];
/* 293 */     for (int i3 = 0; i3 < 3; i3++) {
/* 294 */       for (int i2 = 0; i2 < 3; i2++) {
/* 295 */         for (int i1 = 0; i1 < 3; i1++) {
/* 296 */           assertEquals(r[i3][i2][i1], s[i3][i2][i1], emax);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xtestFactorPlane2Filter() {
/* 306 */     int[] lag1 = { 0, 1, 2, 3, -3, -2, -1, 0, 1 };
/*     */ 
/*     */ 
/*     */     
/* 310 */     int[] lag2 = { 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/* 314 */     float[][] s = new float[3][7];
/* 315 */     float[][] t = new float[3][7];
/* 316 */     int maxiter = 100;
/* 317 */     float epsilon = 1.1920929E-7F;
/* 318 */     int ntheta = 33;
/* 319 */     float dtheta = 3.1415927F / (ntheta - 1);
/* 320 */     float ftheta = -1.5707964F;
/* 321 */     ntheta = 2;
/* 322 */     dtheta = 0.7853982F;
/* 323 */     ftheta = -0.3926991F;
/* 324 */     CausalFilter cf = new CausalFilter(lag1, lag2);
/* 325 */     for (int itheta = 0; itheta < ntheta; itheta++) {
/* 326 */       float theta = ftheta + itheta * dtheta;
/* 327 */       float n1 = MathPlus.cos(theta);
/* 328 */       float n2 = MathPlus.sin(theta);
/* 329 */       System.out.println("theta=" + theta + " n1=" + n1 + " n2=" + n2);
/* 330 */       float m12 = 0.5F * (n1 - n2);
/* 331 */       float p12 = 0.5F * (n1 + n2);
/* 332 */       float[][] r = { { -m12 * m12, -2.0F * m12 * p12, -p12 * p12 }, { 2.0F * m12 * p12, 1.01F, 2.0F * m12 * p12 }, { -p12 * p12, -2.0F * m12 * p12, -m12 * m12 } };
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 337 */       cf.factorWilsonBurg(maxiter, epsilon, r);
/* 338 */       Array.dump(r);
/* 339 */       Array.zero(s);
/* 340 */       int k1 = ((s[0]).length - 1) / 2;
/* 341 */       int k2 = (s.length - 1) / 2;
/* 342 */       s[k2][k1] = 1.0F;
/* 343 */       cf.apply(s, t);
/* 344 */       cf.applyTranspose(t, s);
/* 345 */       Array.dump(s);
/* 346 */       Array.dump(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xtestFactorPlane3Filter() {
/* 380 */     int[] lag1 = { 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     int[] lag2 = { 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, -3, -3, -3, -3, -3, -3, -3, -2, -2, -2, -2, -2, -2, -2, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 422 */     float[][][] s = new float[3][7][7];
/* 423 */     float[][][] t = new float[3][7][7];
/* 424 */     int m = lag1.length;
/* 425 */     float[] amax = new float[m];
/* 426 */     int maxiter = 100;
/* 427 */     float epsilon = 1.1920929E-7F;
/* 428 */     int nphi = 19;
/* 429 */     float dphi = 6.2831855F / (nphi - 1);
/* 430 */     float fphi = -3.1415927F;
/* 431 */     int ntheta = 5;
/* 432 */     float dtheta = 1.5707964F / (ntheta - 1);
/* 433 */     float ftheta = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     CausalFilter cf = new CausalFilter(lag1, lag2, lag3);
/* 441 */     for (int iphi = 0; iphi < nphi; iphi++) {
/* 442 */       float phi = fphi + iphi * dphi;
/* 443 */       for (int itheta = 0; itheta < ntheta; itheta++) {
/* 444 */         float theta = ftheta + itheta * dtheta;
/* 445 */         float n1 = MathPlus.cos(theta);
/* 446 */         float n2 = MathPlus.sin(theta) * MathPlus.cos(phi);
/* 447 */         float n3 = MathPlus.sin(theta) * MathPlus.sin(phi);
/* 448 */         System.out.println("\nphi=" + phi + " theta=" + theta + " n1=" + n1 + " n2=" + n2 + " n3=" + n3);
/*     */         
/* 450 */         float m12 = 0.5F * (n1 - n2);
/* 451 */         float m13 = 0.5F * (n1 - n3);
/* 452 */         float m23 = 0.5F * (n2 - n3);
/* 453 */         float p12 = 0.5F * (n1 + n2);
/* 454 */         float p13 = 0.5F * (n1 + n3);
/* 455 */         float p23 = 0.5F * (n2 + n3);
/* 456 */         float[][][] r = { { { 0.0F, -m23 * m23, 0.0F }, { -m13 * m13, -2.0F * (m13 * p13 + m23 * p23), -p13 * p13 }, { 0.0F, -p23 * p23, 0.0F } }, { { -m12 * m12, 2.0F * (-m12 * p12 + m23 * p23), -p12 * p12 }, { 2.0F * (m12 * p12 + m13 * p13), 2.02F, 2.0F * (m12 * p12 + m13 * p13) }, { -p12 * p12, 2.0F * (-m12 * p12 + m23 * p23), -m12 * m12 } }, { { 0.0F, -p23 * p23, 0.0F }, { -p13 * p13, -2.0F * (m13 * p13 + m23 * p23), -m13 * m13 }, { 0.0F, -m23 * m23, 0.0F } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 469 */         cf.factorWilsonBurg(maxiter, epsilon, r);
/* 470 */         float[] a = cf.getA();
/* 471 */         for (int i = 0; i < m; i++) {
/* 472 */           if (MathPlus.abs(a[i]) > amax[i]) {
/* 473 */             amax[i] = MathPlus.abs(a[i]);
/*     */           }
/*     */         } 
/* 476 */         Array.zero(s);
/* 477 */         int k1 = ((s[0][0]).length - 1) / 2;
/* 478 */         int k2 = ((s[0]).length - 1) / 2;
/* 479 */         int k3 = (s.length - 1) / 2;
/* 480 */         s[k3][k2][k1] = 1.0F;
/* 481 */         cf.apply(s, t);
/* 482 */         cf.applyTranspose(t, s);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 487 */     for (int j = 0; j < m; j++) {
/* 488 */       System.out.println("lag1=" + lag1[j] + " lag2=" + lag2[j] + " lag3=" + lag3[j] + " amax=" + amax[j]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] randfloat(int n1) {
/* 498 */     return Array.sub(Array.randfloat(n1), 0.5F);
/*     */   }
/*     */   private static float[][] randfloat(int n1, int n2) {
/* 501 */     return Array.sub(Array.randfloat(n1, n2), 0.5F);
/*     */   }
/*     */   private static float[][][] randfloat(int n1, int n2, int n3) {
/* 504 */     return Array.sub(Array.randfloat(n1, n2, n3), 0.5F);
/*     */   }
/*     */   
/*     */   private static float[] zerofloat(int n1) {
/* 508 */     return Array.zerofloat(n1);
/*     */   }
/*     */   private static float[][] zerofloat(int n1, int n2) {
/* 511 */     return Array.zerofloat(n1, n2);
/*     */   }
/*     */   private static float[][][] zerofloat(int n1, int n2, int n3) {
/* 514 */     return Array.zerofloat(n1, n2, n3);
/*     */   }
/*     */   
/*     */   private static float dot(float[] x, float[] y) {
/* 518 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][] x, float[][] y) {
/* 521 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][][] x, float[][][] y) {
/* 524 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[] re, float[] ra) {
/* 528 */     int n = re.length;
/* 529 */     float tolerance = n * 1.1920929E-7F;
/* 530 */     for (int i = 0; i < n; i++)
/* 531 */       assertEquals(re[i], ra[i], tolerance); 
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[][] re, float[][] ra) {
/* 535 */     int n2 = re.length;
/* 536 */     int n1 = (re[0]).length;
/* 537 */     float tolerance = (n1 * n2) * 1.1920929E-7F;
/* 538 */     for (int i2 = 0; i2 < n2; i2++) {
/* 539 */       for (int i1 = 0; i1 < n1; i1++)
/* 540 */         assertEquals(re[i2][i1], ra[i2][i1], tolerance); 
/*     */     } 
/*     */   }
/*     */   private static void assertEqual(float[][][] re, float[][][] ra) {
/* 544 */     int n3 = re.length;
/* 545 */     int n2 = (re[0]).length;
/* 546 */     int n1 = (re[0][0]).length;
/* 547 */     float tolerance = (n1 * n2 * n3) * 1.1920929E-7F;
/* 548 */     for (int i3 = 0; i3 < n3; i3++) {
/* 549 */       for (int i2 = 0; i2 < n2; i2++) {
/* 550 */         for (int i1 = 0; i1 < n1; i1++)
/* 551 */           assertEquals(re[i3][i2][i1], ra[i3][i2][i1], tolerance); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/CausalFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */