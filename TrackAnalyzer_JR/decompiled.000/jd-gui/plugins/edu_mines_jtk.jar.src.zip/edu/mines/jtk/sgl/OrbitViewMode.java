/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ 
/*     */ public class OrbitViewMode extends Mode {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ViewCanvas _canvas;
/*     */   private OrbitView _view;
/*     */   private int _xmouse;
/*     */   private int _ymouse;
/*     */   private double _zmouse;
/*     */   private double _scale;
/*     */   private double _azimuth;
/*     */   private double _elevation;
/*     */   private Vector3 _translate;
/*     */   private Point3 _translateP;
/*     */   private Matrix44 _translateM;
/*     */   private boolean _rotating;
/*     */   private boolean _scaling;
/*     */   private boolean _translating;
/*     */   private KeyListener _kl;
/*     */   private MouseListener _ml;
/*     */   private MouseMotionListener _mml;
/*     */   
/*  30 */   public OrbitViewMode(ModeManager modeManager) { super(modeManager);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this._kl = new KeyAdapter() {
/*     */         public void keyPressed(KeyEvent e) {
/*  75 */           ViewCanvas canvas = (ViewCanvas)e.getSource();
/*  76 */           OrbitView view = (OrbitView)canvas.getView();
/*  77 */           int kc = e.getKeyCode();
/*     */ 
/*     */           
/*  80 */           if (kc == 36) {
/*  81 */             view.reset();
/*     */           
/*     */           }
/*  84 */           else if (kc == 34) {
/*  85 */             Tuple3 s = view.getAxesScale();
/*  86 */             view.setAxesScale(s.x, s.y, s.z / 1.1D);
/*     */           
/*     */           }
/*  89 */           else if (kc == 33) {
/*  90 */             Tuple3 s = view.getAxesScale();
/*  91 */             view.setAxesScale(s.x, s.y, s.z * 1.1D);
/*     */           
/*     */           }
/*  94 */           else if (kc == 155) {
/*  95 */             OrbitView.Projection projection = view.getProjection();
/*  96 */             if (projection == OrbitView.Projection.ORTHOGRAPHIC) {
/*  97 */               projection = OrbitView.Projection.PERSPECTIVE;
/*  98 */             } else if (projection == OrbitView.Projection.PERSPECTIVE) {
/*  99 */               projection = OrbitView.Projection.ORTHOGRAPHIC;
/*     */             } 
/* 101 */             view.setProjection(projection);
/*     */           
/*     */           }
/* 104 */           else if (e.isControlDown()) {
/* 105 */             double scale = view.getScale();
/* 106 */             if (kc == 38) {
/* 107 */               scale *= 0.9D;
/* 108 */             } else if (kc == 40) {
/* 109 */               scale *= 1.1D;
/*     */             } 
/* 111 */             view.setScale(scale);
/*     */ 
/*     */           
/*     */           }
/* 115 */           else if (e.isShiftDown()) {
/* 116 */             Matrix44 viewToCube = OrbitViewMode.this._canvas.getViewToCube();
/* 117 */             Matrix44 unitSphereToView = OrbitViewMode.this._view.getUnitSphereToView();
/* 118 */             Matrix44 unitSphereToCube = viewToCube.times(unitSphereToView);
/* 119 */             Matrix44 cubeToUnitSphere = unitSphereToCube.inverse();
/* 120 */             Vector3 translate = view.getTranslate();
/* 121 */             Matrix44 m = Matrix44.translate(translate).times(cubeToUnitSphere);
/* 122 */             double xc = 0.0D;
/* 123 */             double yc = 0.0D;
/* 124 */             double zc = 0.0D;
/* 125 */             Point3 c1 = new Point3(xc, yc, zc);
/* 126 */             if (kc == 37) {
/* 127 */               xc -= 0.05D;
/* 128 */             } else if (kc == 39) {
/* 129 */               xc += 0.05D;
/* 130 */             } else if (kc == 38) {
/* 131 */               yc += 0.05D;
/* 132 */             } else if (kc == 40) {
/* 133 */               yc -= 0.05D;
/*     */             } 
/* 135 */             Point3 c2 = new Point3(xc, yc, zc);
/* 136 */             translate.plusEquals(m.times(c2).minus(m.times(c1)));
/* 137 */             view.setTranslate(translate);
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 143 */             double azimuth = view.getAzimuth();
/* 144 */             double elevation = view.getElevation();
/* 145 */             if (kc == 37) {
/* 146 */               azimuth += 5.0D;
/* 147 */             } else if (kc == 39) {
/* 148 */               azimuth -= 5.0D;
/* 149 */             } else if (kc == 38) {
/* 150 */               elevation -= 5.0D;
/* 151 */             } else if (kc == 40) {
/* 152 */               elevation += 5.0D;
/*     */             } 
/* 154 */             view.setAzimuthAndElevation(azimuth, elevation);
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 159 */     this._ml = new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent e) {
/* 161 */           if (e.isControlDown()) {
/* 162 */             OrbitViewMode.this.beginScale(e);
/* 163 */             OrbitViewMode.this._scaling = true;
/* 164 */           } else if (e.isShiftDown()) {
/* 165 */             OrbitViewMode.this.beginTranslate(e);
/* 166 */             OrbitViewMode.this._translating = true;
/*     */           } else {
/* 168 */             OrbitViewMode.this.beginRotate(e);
/* 169 */             OrbitViewMode.this._rotating = true;
/*     */           } 
/*     */         }
/*     */         public void mouseReleased(MouseEvent e) {
/* 173 */           if (OrbitViewMode.this._scaling) {
/* 174 */             OrbitViewMode.this.endScale(e);
/* 175 */             OrbitViewMode.this._scaling = false;
/* 176 */           } else if (OrbitViewMode.this._translating) {
/* 177 */             OrbitViewMode.this.endTranslate(e);
/* 178 */             OrbitViewMode.this._translating = false;
/* 179 */           } else if (OrbitViewMode.this._rotating) {
/* 180 */             OrbitViewMode.this.endRotate(e);
/* 181 */             OrbitViewMode.this._rotating = false;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 186 */     this._mml = new MouseMotionAdapter()
/*     */       {
/* 188 */         public void mouseDragged(MouseEvent e) { if (OrbitViewMode.this._scaling) {
/* 189 */             OrbitViewMode.this.duringScale(e);
/* 190 */           } else if (OrbitViewMode.this._translating) {
/* 191 */             OrbitViewMode.this.duringTranslate(e);
/* 192 */           } else if (OrbitViewMode.this._rotating) {
/* 193 */             OrbitViewMode.this.duringRotate(e);
/*     */           }  } }; setName("View"); Class<OrbitViewMode> cls = OrbitViewMode.class;
/*     */     setIcon(loadIcon(cls, "resources/ViewHandIcon16.png"));
/*     */     setCursor(loadCursor(cls, "resources/ViewHandCursor16.png", 3, 2));
/*     */     setMnemonicKey(32);
/*     */     setAcceleratorKey(KeyStroke.getKeyStroke(32, 0));
/* 199 */     setShortDescription("Manipulate view"); } private void beginScale(MouseEvent e) { this._ymouse = e.getY();
/* 200 */     this._canvas = (ViewCanvas)e.getSource();
/* 201 */     this._canvas.addMouseMotionListener(this._mml);
/* 202 */     this._view = (OrbitView)this._canvas.getView();
/* 203 */     this._scale = this._view.getScale(); }
/*     */   protected void setActive(Component component, boolean active) { if (component instanceof ViewCanvas)
/*     */       if (active) { component.addMouseListener(this._ml); component.addKeyListener(this._kl); }
/*     */       else { component.removeMouseListener(this._ml); component.removeKeyListener(this._kl); }
/* 207 */         } private void duringScale(MouseEvent e) { int h = this._canvas.getHeight();
/* 208 */     int y = e.getY();
/* 209 */     int dy = y - this._ymouse;
/* 210 */     double ds = 2.0D * dy / h;
/* 211 */     this._view.setScale(this._scale * Math.pow(10.0D, ds)); }
/*     */ 
/*     */   
/*     */   private void endScale(MouseEvent e) {
/* 215 */     this._canvas.removeMouseMotionListener(this._mml);
/*     */   }
/*     */   
/*     */   private void beginTranslate(MouseEvent e) {
/* 219 */     this._xmouse = e.getX();
/* 220 */     this._ymouse = e.getY();
/* 221 */     this._canvas = (ViewCanvas)e.getSource();
/* 222 */     this._canvas.addMouseMotionListener(this._mml);
/* 223 */     this._view = (OrbitView)this._canvas.getView();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     this._zmouse = this._canvas.getPixelZ(this._xmouse, this._ymouse);
/* 230 */     if (this._zmouse == 1.0D) {
/* 231 */       this._zmouse = 0.5D;
/*     */     }
/*     */     
/* 234 */     Matrix44 cubeToPixel = this._canvas.getCubeToPixel();
/* 235 */     Matrix44 viewToCube = this._canvas.getViewToCube();
/* 236 */     Matrix44 viewToPixel = cubeToPixel.times(viewToCube);
/* 237 */     Matrix44 unitSphereToView = this._view.getUnitSphereToView();
/* 238 */     Matrix44 unitSphereToPixel = viewToPixel.times(unitSphereToView);
/* 239 */     Matrix44 pixelToUnitSphere = unitSphereToPixel.inverse();
/*     */ 
/*     */     
/* 242 */     this._translate = this._view.getTranslate();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     this._translateM = Matrix44.translate(this._translate).times(pixelToUnitSphere);
/*     */ 
/*     */     
/* 250 */     this._translateP = this._translateM.times(new Point3(this._xmouse, this._ymouse, this._zmouse));
/*     */   }
/*     */   
/*     */   private void duringTranslate(MouseEvent e) {
/* 254 */     int x = e.getX();
/* 255 */     int y = e.getY();
/* 256 */     Point3 p = new Point3(x, y, this._zmouse);
/* 257 */     Vector3 t = this._translate.plus(this._translateM.times(p).minus(this._translateP));
/* 258 */     this._view.setTranslate(t);
/*     */   }
/*     */   
/*     */   private void endTranslate(MouseEvent e) {
/* 262 */     this._canvas.removeMouseMotionListener(this._mml);
/*     */   }
/*     */   
/*     */   private void beginRotate(MouseEvent e) {
/* 266 */     this._xmouse = e.getX();
/* 267 */     this._ymouse = e.getY();
/* 268 */     this._canvas = (ViewCanvas)e.getSource();
/* 269 */     this._canvas.addMouseMotionListener(this._mml);
/* 270 */     this._view = (OrbitView)this._canvas.getView();
/* 271 */     this._azimuth = this._view.getAzimuth();
/* 272 */     this._elevation = this._view.getElevation();
/*     */   }
/*     */   
/*     */   private void duringRotate(MouseEvent e) {
/* 276 */     int w = this._canvas.getWidth();
/* 277 */     int h = this._canvas.getHeight();
/* 278 */     int x = e.getX();
/* 279 */     int y = e.getY();
/* 280 */     int dx = x - this._xmouse;
/* 281 */     int dy = y - this._ymouse;
/* 282 */     double da = -360.0D * dx / w;
/* 283 */     double de = 360.0D * dy / h;
/* 284 */     this._view.setAzimuthAndElevation(this._azimuth + da, this._elevation + de);
/*     */   }
/*     */   
/*     */   private void endRotate(MouseEvent e) {
/* 288 */     this._canvas.removeMouseMotionListener(this._mml);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/OrbitViewMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */