/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect2f;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class ArrayVect2fTest
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() {
/* 18 */     float[][] a = new float[31][21];
/* 19 */     for (int i = 0; i < a.length; i++) {
/* 20 */       for (int m = 0; m < (a[i]).length; m++) {
/* 21 */         a[i][m] = i + 2.5F * m;
/*    */       }
/*    */     } 
/* 24 */     ArrayVect2f arrayVect2f1 = new ArrayVect2f(a, 2.0D);
/* 25 */     VectUtil.test((VectConst)arrayVect2f1);
/*    */ 
/*    */     
/* 28 */     for (int j = 0; j < a.length; j++) {
/* 29 */       for (int m = 0; m < (a[j]).length; m++) {
/* 30 */         a[j][m] = 1.0F;
/*    */       }
/*    */     } 
/* 33 */     arrayVect2f1 = new ArrayVect2f(a, 3.0D);
/* 34 */     Vect w = arrayVect2f1.clone();
/* 35 */     w.multiplyInverseCovariance();
/* 36 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect2f1.dot((VectConst)w));
/* 37 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect2f1.magnitude());
/*    */ 
/*    */ 
/*    */     
/* 41 */     Random random = new Random(352L);
/* 42 */     float[][] arrayOfFloat1 = new float[201][];
/* 43 */     boolean oneWasShort = false;
/* 44 */     boolean oneWasLong = false;
/* 45 */     for (int k = 0; k < arrayOfFloat1.length; k++) {
/* 46 */       arrayOfFloat1[k] = new float[random.nextInt(11)];
/* 47 */       if ((arrayOfFloat1[k]).length == 0) oneWasShort = true; 
/* 48 */       for (int m = 0; m < (arrayOfFloat1[k]).length; m++) {
/* 49 */         oneWasLong = true;
/* 50 */         arrayOfFloat1[k][m] = 5.0F * random.nextFloat() - 2.0F;
/*    */       } 
/*    */     } 
/* 53 */     assert oneWasShort;
/* 54 */     assert oneWasLong;
/* 55 */     ArrayVect2f arrayVect2f2 = new ArrayVect2f(arrayOfFloat1, 2.5D);
/* 56 */     VectUtil.test((VectConst)arrayVect2f2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 63 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 66 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayVect2fTest(String name) {
/* 73 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 79 */       throw new IllegalStateException("need -ea");
/* 80 */     } catch (AssertionError e) {
/* 81 */       return (Test)new TestSuite(ArrayVect2fTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 88 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect2fTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */