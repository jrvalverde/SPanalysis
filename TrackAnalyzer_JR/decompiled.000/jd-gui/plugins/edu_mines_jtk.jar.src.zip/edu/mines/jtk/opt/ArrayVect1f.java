/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect1f
/*     */   implements Vect
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  30 */   protected float[] _data = null;
/*     */ 
/*     */   
/*  33 */   protected double _variance = 1.0D;
/*     */ 
/*     */ 
/*     */   
/*  37 */   protected int _firstSample = 0;
/*     */ 
/*     */   
/*  40 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect1f(float[] data, int firstSample, double variance) {
/*  51 */     init(data, firstSample, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(float[] data, int firstSample, double variance) {
/*  66 */     this._data = data;
/*  67 */     this._firstSample = firstSample;
/*  68 */     this._variance = variance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstSample() {
/*  75 */     return this._firstSample;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  80 */     return this._data.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getData() {
/*  86 */     return this._data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(float[] data) {
/*  93 */     System.arraycopy(data, 0, this._data, 0, this._data.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fillContainer(VectContainer container, int[] firstSamples, float[][] data, double variance) {
/* 107 */     for (int i = 0; i < data.length; i++) {
/* 108 */       container.put(i, new ArrayVect1f(data[i], firstSamples[i], variance));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void extractContainer(float[][] data, VectContainer container) {
/* 118 */     for (int i = 0; i < data.length; i++) {
/* 119 */       ArrayVect1f trace = (ArrayVect1f)container.get(i);
/* 120 */       float[] traceData = trace.getData();
/* 121 */       System.arraycopy(traceData, 0, data[i], 0, (data[i]).length);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayVect1f clone() {
/*     */     try {
/* 128 */       ArrayVect1f result = (ArrayVect1f)super.clone();
/* 129 */       if (this._data != null) {
/* 130 */         float[] newData = (float[])this._data.clone();
/* 131 */         result.init(newData, this._firstSample, this._variance);
/*     */       } 
/* 133 */       return result;
/* 134 */     } catch (CloneNotSupportedException ex) {
/* 135 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/* 136 */       e.initCause(ex);
/* 137 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 143 */     StringBuilder sb = new StringBuilder();
/* 144 */     sb.append("(");
/* 145 */     for (int i = 0; i < this._data.length; i++) {
/* 146 */       sb.append("" + this._data[i]);
/* 147 */       if (i < this._data.length - 1) sb.append(", "); 
/*     */     } 
/* 149 */     sb.append(")");
/* 150 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/* 155 */     double result = 0.0D;
/* 156 */     ArrayVect1f rhs = (ArrayVect1f)other;
/* 157 */     int i = 0;
/* 158 */     for (; i < this._data.length; 
/* 159 */       i++) {
/* 160 */       result += (this._data[i] * rhs._data[i]);
/*     */     }
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 167 */     this._data = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 172 */     double scale = Almost.FLOAT.divide(1.0D, getSize() * this._variance, 0.0D);
/* 173 */     VectUtil.scale(this, scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {
/* 178 */     Arrays.fill(this._data, 0, this._firstSample, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/* 183 */     float s1 = (float)scaleThis;
/* 184 */     float s2 = (float)scaleOther;
/* 185 */     ArrayVect1f rhs = (ArrayVect1f)other;
/* 186 */     for (int i = 0; i < this._data.length; i++) {
/* 187 */       this._data[i] = s1 * this._data[i] + s2 * rhs._data[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/* 193 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/* 198 */     return Almost.FLOAT.divide(dot(this), getSize() * this._variance, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 207 */     out.writeObject(this._data);
/* 208 */     out.writeDouble(this._variance);
/* 209 */     out.writeInt(this._firstSample);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 215 */     this._data = (float[])in.readObject();
/* 216 */     this._variance = in.readDouble();
/* 217 */     this._firstSample = in.readInt();
/*     */   }
/*     */   
/*     */   protected ArrayVect1f() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect1f.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */