/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlotFrame
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PlotPanel _panelTL;
/*     */   private PlotPanel _panelBR;
/*     */   private Split _split;
/*     */   private JSplitPane _splitPane;
/*     */   private MainPanel _panelMain;
/*     */   private ModeManager _modeManager;
/*     */   private TileZoomMode _tileZoomMode;
/*     */   private MouseTrackMode _mouseTrackMode;
/*     */   
/*     */   public enum Split
/*     */   {
/*  58 */     HORIZONTAL,
/*  59 */     VERTICAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotFrame(PlotPanel panel) {
/*  67 */     this._panelTL = panel;
/*  68 */     this._panelBR = panel;
/*  69 */     this._panelMain = new MainPanel();
/*  70 */     this._panelMain.setLayout(new BorderLayout());
/*  71 */     this._panelMain.add(this._panelTL, "Center");
/*  72 */     setSize(this._panelMain.getPreferredSize());
/*  73 */     add(this._panelMain, "Center");
/*  74 */     setBackground(Color.WHITE);
/*  75 */     addModeManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotFrame(PlotPanel panelTL, PlotPanel panelBR, Split split) {
/*  85 */     this._panelTL = panelTL;
/*  86 */     this._panelBR = panelBR;
/*  87 */     this._split = split;
/*  88 */     this._panelMain = new MainPanel();
/*  89 */     this._panelMain.setLayout(new BorderLayout());
/*  90 */     double resizeWeight = 0.5D;
/*  91 */     if (this._split == Split.HORIZONTAL) {
/*  92 */       this._splitPane = new JSplitPane(1, this._panelTL, this._panelBR);
/*     */       
/*  94 */       double colTL = this._panelTL.getMosaic().countColumns();
/*  95 */       double colBR = this._panelBR.getMosaic().countColumns();
/*  96 */       resizeWeight = colTL / (colTL + colBR);
/*     */     } else {
/*  98 */       this._splitPane = new JSplitPane(0, this._panelTL, this._panelBR);
/*     */       
/* 100 */       double rowTL = this._panelTL.getMosaic().countRows();
/* 101 */       double rowBR = this._panelBR.getMosaic().countRows();
/* 102 */       resizeWeight = rowTL / (rowTL + rowBR);
/*     */     } 
/* 104 */     this._splitPane.setResizeWeight(resizeWeight);
/* 105 */     this._splitPane.setOneTouchExpandable(true);
/* 106 */     this._panelMain.add(this._splitPane, "Center");
/* 107 */     setSize(this._panelMain.getPreferredSize());
/* 108 */     add(this._panelMain, "Center");
/* 109 */     setBackground(Color.WHITE);
/* 110 */     addModeManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel getPlotPanel() {
/* 119 */     return this._panelTL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel getPlotPanelTopLeft() {
/* 128 */     return this._panelTL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlotPanel getPlotPanelBottomRight() {
/* 137 */     return this._panelBR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModeManager getModeManager() {
/* 145 */     return this._modeManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileZoomMode getTileZoomMode() {
/* 154 */     return this._tileZoomMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MouseTrackMode getMouseTrackMode() {
/* 163 */     return this._mouseTrackMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintToPng(final double dpi, final double win, final String fileName) {
/* 177 */     SwingUtilities.invokeLater(new Runnable() {
/*     */           public void run() {
/*     */             try {
/* 180 */               PlotFrame.this._panelMain.paintToPng(dpi, win, fileName);
/* 181 */             } catch (IOException ioe) {
/* 182 */               throw new RuntimeException(ioe);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFontSize(int size) {
/* 193 */     Font font = getFont();
/* 194 */     if (font == null)
/* 195 */       font = UIManager.getFont("Panel.font"); 
/* 196 */     if (font != null) {
/* 197 */       setFont(font.deriveFont(size));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 205 */     super.setFont(font);
/* 206 */     if (this._panelMain != null)
/* 207 */       this._panelMain.setFont(font); 
/* 208 */     if (this._panelTL != null)
/* 209 */       this._panelTL.setFont(font); 
/* 210 */     if (this._panelBR != null && this._panelBR != this._panelTL) {
/* 211 */       this._panelBR.setFont(font);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForeground(Color color) {
/* 219 */     super.setForeground(color);
/* 220 */     if (this._panelMain != null)
/* 221 */       this._panelMain.setForeground(color); 
/* 222 */     if (this._panelTL != null)
/* 223 */       this._panelTL.setForeground(color); 
/* 224 */     if (this._panelBR != null && this._panelBR != this._panelTL) {
/* 225 */       this._panelBR.setForeground(color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackground(Color color) {
/* 233 */     super.setBackground(color);
/* 234 */     if (this._panelMain != null)
/* 235 */       this._panelMain.setBackground(color); 
/* 236 */     if (this._panelTL != null)
/* 237 */       this._panelTL.setBackground(color); 
/* 238 */     if (this._panelBR != null && this._panelBR != this._panelTL) {
/* 239 */       this._panelBR.setBackground(color);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MainPanel
/*     */     extends IPanel
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MainPanel() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 263 */       if (PlotFrame.this._split == null) {
/* 264 */         PlotFrame.this._panelTL.paintToRect(g2d, x, y, w, h);
/*     */       } else {
/* 266 */         double ws = w / PlotFrame.this._splitPane.getWidth();
/* 267 */         double hs = h / PlotFrame.this._splitPane.getHeight();
/* 268 */         int nc = PlotFrame.this._splitPane.getComponentCount();
/* 269 */         for (int ic = 0; ic < nc; ic++) {
/* 270 */           Component c = PlotFrame.this._splitPane.getComponent(ic);
/* 271 */           int xc = c.getX();
/* 272 */           int yc = c.getY();
/* 273 */           int wc = c.getWidth();
/* 274 */           int hc = c.getHeight();
/* 275 */           xc = (int)Math.round(xc * ws);
/* 276 */           yc = (int)Math.round(yc * hs);
/* 277 */           wc = (int)Math.round(wc * ws);
/* 278 */           hc = (int)Math.round(hc * hs);
/* 279 */           if (c instanceof IPanel) {
/* 280 */             IPanel ip = (IPanel)c;
/* 281 */             ip.paintToRect(g2d, xc, yc, wc, hc);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addModeManager() {
/* 292 */     this._modeManager = new ModeManager();
/* 293 */     this._panelTL.getMosaic().setModeManager(this._modeManager);
/* 294 */     if (this._panelBR != this._panelTL)
/* 295 */       this._panelBR.getMosaic().setModeManager(this._modeManager); 
/* 296 */     this._tileZoomMode = new TileZoomMode(this._modeManager);
/* 297 */     this._mouseTrackMode = new MouseTrackMode(this._modeManager);
/* 298 */     this._tileZoomMode.setActive(true);
/* 299 */     this._mouseTrackMode.setActive(true);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/PlotFrame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */