/*     */ package edu.mines.jtk.io;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayFile
/*     */   implements ArrayInput, ArrayOutput, Closeable
/*     */ {
/*     */   private RandomAccessFile _raf;
/*     */   private ByteOrder _bor;
/*     */   private ByteOrder _bow;
/*     */   private ArrayInput _ai;
/*     */   private ArrayOutput _ao;
/*     */   
/*     */   public ArrayFile(String name, String mode) throws FileNotFoundException {
/*  37 */     this(name, mode, ByteOrder.BIG_ENDIAN, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayFile(File file, String mode) throws FileNotFoundException {
/*  46 */     this(file, mode, ByteOrder.BIG_ENDIAN, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayFile(String name, String mode, ByteOrder bor, ByteOrder bow) throws FileNotFoundException {
/*  59 */     this((name != null) ? new File(name) : null, mode, bor, bow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayFile(File file, String mode, ByteOrder bor, ByteOrder bow) throws FileNotFoundException {
/*  72 */     this(new RandomAccessFile(file, mode), bor, bow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayFile(RandomAccessFile raf, ByteOrder bor, ByteOrder bow) {
/*  83 */     this._raf = raf;
/*  84 */     this._bor = bor;
/*  85 */     this._bow = bow;
/*  86 */     this._ai = new ArrayInputAdapter(raf, bor);
/*  87 */     this._ao = new ArrayOutputAdapter(raf, bow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrderRead() {
/*  95 */     return this._bor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrderWrite() {
/* 103 */     return this._bow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 112 */     return this._raf.read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 121 */     return this._raf.read(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 132 */     return this._raf.read(b, off, len);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 136 */     this._ai.readFully(b);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 140 */     this._ai.readFully(b, off, len);
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException {
/* 144 */     return this._ai.skipBytes(n);
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException {
/* 148 */     this._ao.write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 152 */     this._ao.write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 156 */     this._ao.write(b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFilePointer() throws IOException {
/* 165 */     return this._raf.getFilePointer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(long off) throws IOException {
/* 179 */     this._raf.seek(off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws IOException {
/* 187 */     return this._raf.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(long newLength) throws IOException {
/* 202 */     this._raf.setLength(newLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 209 */     this._raf.close();
/* 210 */     this._raf = null;
/* 211 */     this._ai = null;
/* 212 */     this._ao = null;
/*     */   }
/*     */   
/*     */   public final boolean readBoolean() throws IOException {
/* 216 */     return this._ai.readBoolean();
/*     */   }
/*     */   
/*     */   public final byte readByte() throws IOException {
/* 220 */     return this._ai.readByte();
/*     */   }
/*     */   
/*     */   public final int readUnsignedByte() throws IOException {
/* 224 */     return this._ai.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public final short readShort() throws IOException {
/* 228 */     return this._ai.readShort();
/*     */   }
/*     */   
/*     */   public final int readUnsignedShort() throws IOException {
/* 232 */     return this._ai.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public final char readChar() throws IOException {
/* 236 */     return this._ai.readChar();
/*     */   }
/*     */   
/*     */   public final int readInt() throws IOException {
/* 240 */     return this._ai.readInt();
/*     */   }
/*     */   
/*     */   public final long readLong() throws IOException {
/* 244 */     return this._ai.readLong();
/*     */   }
/*     */   
/*     */   public final float readFloat() throws IOException {
/* 248 */     return this._ai.readFloat();
/*     */   }
/*     */   
/*     */   public final double readDouble() throws IOException {
/* 252 */     return this._ai.readDouble();
/*     */   }
/*     */   
/*     */   public final String readLine() throws IOException {
/* 256 */     return this._ai.readLine();
/*     */   }
/*     */   
/*     */   public final String readUTF() throws IOException {
/* 260 */     return this._ai.readUTF();
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException {
/* 264 */     this._ao.writeBoolean(v);
/*     */   }
/*     */   
/*     */   public void writeByte(int v) throws IOException {
/* 268 */     this._ao.writeByte(v);
/*     */   }
/*     */   
/*     */   public void writeShort(int v) throws IOException {
/* 272 */     this._ao.writeShort(v);
/*     */   }
/*     */   
/*     */   public void writeChar(int v) throws IOException {
/* 276 */     this._ao.writeChar(v);
/*     */   }
/*     */   
/*     */   public void writeInt(int v) throws IOException {
/* 280 */     this._ao.writeInt(v);
/*     */   }
/*     */   
/*     */   public void writeLong(long v) throws IOException {
/* 284 */     this._ao.writeLong(v);
/*     */   }
/*     */   
/*     */   public void writeFloat(float v) throws IOException {
/* 288 */     this._ao.writeFloat(v);
/*     */   }
/*     */   
/*     */   public void writeDouble(double v) throws IOException {
/* 292 */     this._ao.writeDouble(v);
/*     */   }
/*     */   
/*     */   public void writeBytes(String s) throws IOException {
/* 296 */     this._ao.writeBytes(s);
/*     */   }
/*     */   
/*     */   public void writeChars(String s) throws IOException {
/* 300 */     this._ao.writeChars(s);
/*     */   }
/*     */   
/*     */   public void writeUTF(String s) throws IOException {
/* 304 */     this._ao.writeUTF(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v, int k, int n) throws IOException {
/* 314 */     this._ai.readBytes(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v) throws IOException {
/* 323 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][] v) throws IOException {
/* 332 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][][] v) throws IOException {
/* 341 */     this._ai.readBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v, int k, int n) throws IOException {
/* 351 */     this._ai.readChars(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v) throws IOException {
/* 360 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][] v) throws IOException {
/* 369 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][][] v) throws IOException {
/* 378 */     this._ai.readChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v, int k, int n) throws IOException {
/* 388 */     this._ai.readShorts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v) throws IOException {
/* 397 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][] v) throws IOException {
/* 406 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][][] v) throws IOException {
/* 415 */     this._ai.readShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v, int k, int n) throws IOException {
/* 425 */     this._ai.readInts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v) throws IOException {
/* 434 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][] v) throws IOException {
/* 443 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][][] v) throws IOException {
/* 452 */     this._ai.readInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v, int k, int n) throws IOException {
/* 462 */     this._ai.readLongs(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v) throws IOException {
/* 471 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][] v) throws IOException {
/* 480 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][][] v) throws IOException {
/* 489 */     this._ai.readLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v, int k, int n) throws IOException {
/* 499 */     this._ai.readFloats(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v) throws IOException {
/* 508 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][] v) throws IOException {
/* 517 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][][] v) throws IOException {
/* 526 */     this._ai.readFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v, int k, int n) throws IOException {
/* 536 */     this._ai.readDoubles(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v) throws IOException {
/* 545 */     this._ai.readDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][] v) throws IOException {
/* 554 */     this._ai.readDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][][] v) throws IOException {
/* 563 */     this._ai.readDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v, int k, int n) throws IOException {
/* 573 */     this._ao.writeBytes(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] v) throws IOException {
/* 582 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][] v) throws IOException {
/* 590 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[][][] v) throws IOException {
/* 598 */     this._ao.writeBytes(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v, int k, int n) throws IOException {
/* 608 */     this._ao.writeChars(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[] v) throws IOException {
/* 617 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][] v) throws IOException {
/* 625 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeChars(char[][][] v) throws IOException {
/* 633 */     this._ao.writeChars(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v, int k, int n) throws IOException {
/* 643 */     this._ao.writeShorts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[] v) throws IOException {
/* 652 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][] v) throws IOException {
/* 660 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeShorts(short[][][] v) throws IOException {
/* 668 */     this._ao.writeShorts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v, int k, int n) throws IOException {
/* 678 */     this._ao.writeInts(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[] v) throws IOException {
/* 687 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][] v) throws IOException {
/* 695 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInts(int[][][] v) throws IOException {
/* 703 */     this._ao.writeInts(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v, int k, int n) throws IOException {
/* 713 */     this._ao.writeLongs(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[] v) throws IOException {
/* 722 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][] v) throws IOException {
/* 730 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeLongs(long[][][] v) throws IOException {
/* 738 */     this._ao.writeLongs(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v, int k, int n) throws IOException {
/* 748 */     this._ao.writeFloats(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[] v) throws IOException {
/* 757 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][] v) throws IOException {
/* 765 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFloats(float[][][] v) throws IOException {
/* 773 */     this._ao.writeFloats(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v, int k, int n) throws IOException {
/* 783 */     this._ao.writeDoubles(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[] v) throws IOException {
/* 792 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][] v) throws IOException {
/* 800 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDoubles(double[][][] v) throws IOException {
/* 808 */     this._ao.writeDoubles(v);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/ArrayFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */