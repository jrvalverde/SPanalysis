/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.util.Direct;
/*     */ import java.awt.Color;
/*     */ import java.nio.FloatBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandleBox
/*     */   extends Handle
/*     */ {
/*     */   public HandleBox(Point3 p) {
/*  29 */     super(p);
/*  30 */     addChild(_box);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandleBox(double x, double y, double z) {
/*  40 */     super(x, y, z);
/*  41 */     addChild(_box);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setColor(Color color) {
/*  49 */     _colorState.setColor(color);
/*  50 */     _box.dirtyDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Box
/*     */     extends Node
/*     */   {
/*     */     Box() {
/*  59 */       StateSet states = new StateSet();
/*  60 */       HandleBox._materialState = new MaterialState();
/*  61 */       HandleBox._materialState.setColorMaterialFront(5634);
/*  62 */       HandleBox._materialState.setSpecularFront(Color.white);
/*  63 */       HandleBox._materialState.setShininessFront(100.0F);
/*  64 */       states.add(HandleBox._materialState);
/*  65 */       HandleBox._colorState = new ColorState();
/*  66 */       HandleBox._colorState.setColor(Color.YELLOW);
/*  67 */       states.add(HandleBox._colorState);
/*  68 */       setStates(states);
/*     */     }
/*     */     protected void draw(DrawContext dc) {
/*  71 */       Gl.glPushClientAttrib(2);
/*  72 */       Gl.glEnableClientState(32884);
/*  73 */       Gl.glEnableClientState(32885);
/*  74 */       Gl.glVertexPointer(3, 5126, 0, HandleBox._vb);
/*  75 */       Gl.glNormalPointer(5126, 0, HandleBox._nb);
/*  76 */       Gl.glDrawArrays(7, 0, 24);
/*  77 */       Gl.glPopClientAttrib();
/*     */     }
/*     */     protected void pick(PickContext pc) {
/*  80 */       Segment ps = pc.getPickSegment();
/*  81 */       for (int iside = 0, index = 0; iside < 6; iside++, index += 12) {
/*  82 */         double xa = HandleBox._va[index + 0];
/*  83 */         double ya = HandleBox._va[index + 1];
/*  84 */         double za = HandleBox._va[index + 2];
/*  85 */         double xb = HandleBox._va[index + 3];
/*  86 */         double yb = HandleBox._va[index + 4];
/*  87 */         double zb = HandleBox._va[index + 5];
/*  88 */         double xc = HandleBox._va[index + 6];
/*  89 */         double yc = HandleBox._va[index + 7];
/*  90 */         double zc = HandleBox._va[index + 8];
/*  91 */         double xd = HandleBox._va[index + 9];
/*  92 */         double yd = HandleBox._va[index + 10];
/*  93 */         double zd = HandleBox._va[index + 11];
/*  94 */         Point3 p = ps.intersectWithTriangle(xa, ya, za, xb, yb, zb, xc, yc, zc);
/*  95 */         Point3 q = ps.intersectWithTriangle(xa, ya, za, xc, yc, zc, xd, yd, zd);
/*  96 */         if (p != null)
/*  97 */           pc.addResult(p); 
/*  98 */         if (q != null)
/*  99 */           pc.addResult(q); 
/*     */       } 
/*     */     }
/*     */     protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 103 */       return new BoundingSphere(0.0D, 0.0D, 0.0D, Math.sqrt(3.0D));
/*     */     }
/*     */   }
/*     */   
/* 107 */   private static Box _box = new Box();
/* 108 */   private static ColorState _colorState = new ColorState();
/* 109 */   private static MaterialState _materialState = new MaterialState();
/*     */ 
/*     */   
/* 112 */   private static float[] _va = new float[] { -1.0F, -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static float[] _na = new float[] { -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 0.0F, 0.0F, -1.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   private static FloatBuffer _vb = Direct.newFloatBuffer(_va);
/* 129 */   private static FloatBuffer _nb = Direct.newFloatBuffer(_na);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/HandleBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */