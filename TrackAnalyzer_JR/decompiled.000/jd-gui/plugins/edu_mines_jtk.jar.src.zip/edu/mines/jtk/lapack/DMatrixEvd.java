/*     */ package edu.mines.jtk.lapack;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixEvd
/*     */ {
/*     */   private int _n;
/*     */   private double[] _v;
/*     */   private double[] _d;
/*     */   private double[] _e;
/*     */   
/*     */   public DMatrixEvd(DMatrix a) {
/*  37 */     Check.argument(a.isSquare(), "A is square");
/*  38 */     this._n = a.getN();
/*  39 */     this._v = new double[this._n * this._n];
/*  40 */     this._d = new double[this._n];
/*  41 */     this._e = new double[this._n];
/*  42 */     double[] aa = a.getPackedColumns();
/*  43 */     if (a.isSymmetric()) {
/*  44 */       int[] m = new int[1];
/*  45 */       int[] isuppz = new int[2 * this._n];
/*  46 */       double[] work = new double[1];
/*  47 */       int[] iwork = new int[1];
/*  48 */       int info = Lapack.dsyevr(205, 301, 122, this._n, aa, this._n, 0.0D, 0.0D, 0, 0, 0.0D, m, this._d, this._v, this._n, isuppz, work, -1, iwork, -1);
/*     */       
/*  50 */       if (info > 0)
/*  51 */         throw new RuntimeException("internal error in LAPACK dsyevr"); 
/*  52 */       int lwork = (int)work[0];
/*  53 */       work = new double[lwork];
/*  54 */       int liwork = iwork[0];
/*  55 */       iwork = new int[liwork];
/*  56 */       info = Lapack.dsyevr(205, 301, 122, this._n, aa, this._n, 0.0D, 0.0D, 0, 0, 0.0D, m, this._d, this._v, this._n, isuppz, work, lwork, iwork, liwork);
/*     */       
/*  58 */       if (info > 0)
/*  59 */         throw new RuntimeException("internal error in LAPACK dsyevr"); 
/*     */     } else {
/*  61 */       double[] work = new double[1];
/*  62 */       int info = Lapack.dgeev(204, 205, this._n, aa, this._n, this._d, this._e, this._v, this._n, this._v, this._n, work, -1);
/*  63 */       int lwork = (int)work[0];
/*  64 */       work = new double[lwork];
/*  65 */       info = Lapack.dgeev(204, 205, this._n, aa, this._n, this._d, this._e, this._v, this._n, this._v, this._n, work, lwork);
/*  66 */       if (info > 0) {
/*  67 */         throw new RuntimeException("LAPACK dgeev failed to converge");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getV() {
/*  76 */     return new DMatrix(this._n, this._n, this._v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getD() {
/*  84 */     double[] d = new double[this._n * this._n];
/*  85 */     for (int i = 0; i < this._n; i++) {
/*  86 */       for (int j = 0; j < this._n; j++) {
/*  87 */         d[i + j * this._n] = 0.0D;
/*     */       }
/*  89 */       d[i + i * this._n] = this._d[i];
/*  90 */       if (this._e[i] > 0.0D) {
/*  91 */         d[i + (i + 1) * this._n] = this._e[i];
/*  92 */       } else if (this._e[i] < 0.0D) {
/*  93 */         d[i + (i - 1) * this._n] = this._e[i];
/*     */       } 
/*     */     } 
/*  96 */     return new DMatrix(this._n, this._n, d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getRealEigenvalues() {
/* 104 */     return Array.copy(this._d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getImagEigenvalues() {
/* 112 */     return Array.copy(this._e);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrixEvd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */