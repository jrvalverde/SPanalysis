/*    */ package edu.mines.jtk.dsp.test;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Suite
/*    */   extends TestSuite
/*    */ {
/*    */   public static Test suite() {
/* 20 */     TestSuite suite = new TestSuite();
/*    */     
/* 22 */     suite.addTestSuite(EigenTest.class);
/* 23 */     suite.addTestSuite(FftComplexTest.class);
/* 24 */     suite.addTestSuite(FftRealTest.class);
/* 25 */     suite.addTestSuite(HistogramTest.class);
/* 26 */     suite.addTestSuite(LocalCausalFilterTest.class);
/* 27 */     suite.addTestSuite(LocalOrientFilterTest.class);
/* 28 */     suite.addTestSuite(Real1Test.class);
/* 29 */     suite.addTestSuite(Recursive2ndOrderFilterTest.class);
/* 30 */     suite.addTestSuite(SamplingTest.class);
/* 31 */     suite.addTestSuite(SincInterpolatorTest.class);
/*    */     
/* 33 */     return (Test)suite;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 37 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/Suite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */