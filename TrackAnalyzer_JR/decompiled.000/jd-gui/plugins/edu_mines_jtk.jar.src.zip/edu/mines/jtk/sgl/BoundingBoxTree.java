/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingBoxTree
/*     */ {
/*     */   private int _n;
/*     */   private int[] _i;
/*     */   private float[] _x;
/*     */   private float[] _y;
/*     */   private float[] _z;
/*     */   private Node _root;
/*     */   
/*     */   public class Node
/*     */   {
/*     */     private BoundingBox _bb;
/*     */     private int _kmin;
/*     */     private int _kmax;
/*     */     private Node _left;
/*     */     private Node _right;
/*     */     
/*     */     public BoundingBox getBoundingBox() {
/*  49 */       return new BoundingBox(this._bb);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getSize() {
/*  57 */       return 1 + this._kmax - this._kmin;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int[] getIndices() {
/*  65 */       return Array.copy(1 + this._kmax - this._kmin, this._kmin, BoundingBoxTree.this._i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Node getLeft() {
/*  73 */       return this._left;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Node getRight() {
/*  81 */       return this._right;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isLeaf() {
/*  89 */       return (this._left == null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBoxTree(int minSize, float[] xyz) {
/* 107 */     Check.argument((minSize > 0), "minSize>0");
/* 108 */     this._n = xyz.length / 3;
/* 109 */     this._i = Array.rampint(0, 1, this._n);
/* 110 */     this._x = Array.copy(this._n, 0, 3, xyz);
/* 111 */     this._y = Array.copy(this._n, 1, 3, xyz);
/* 112 */     this._z = Array.copy(this._n, 2, 3, xyz);
/* 113 */     this._root = new Node();
/* 114 */     this._root._bb = new BoundingBox(this._x, this._y, this._z);
/* 115 */     this._root._kmin = 0;
/* 116 */     this._root._kmax = this._n - 1;
/* 117 */     split(minSize, this._root);
/* 118 */     this._x = this._y = this._z = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBoxTree(int minSize, float[] x, float[] y, float[] z) {
/* 129 */     Check.argument((minSize > 0), "minSize>0");
/* 130 */     Check.argument((x.length == y.length), "x.length==y.length");
/* 131 */     Check.argument((x.length == z.length), "x.length==z.length");
/* 132 */     this._n = x.length;
/* 133 */     this._i = Array.rampint(0, 1, this._n);
/* 134 */     this._x = Array.copy(x);
/* 135 */     this._y = Array.copy(y);
/* 136 */     this._z = Array.copy(z);
/* 137 */     this._root = new Node();
/* 138 */     this._root._bb = new BoundingBox(this._x, this._y, this._z);
/* 139 */     this._root._kmin = 0;
/* 140 */     this._root._kmax = this._n - 1;
/* 141 */     split(minSize, this._root);
/* 142 */     this._x = this._y = this._z = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getRoot() {
/* 150 */     return this._root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void split(int minSize, Node node) {
/*     */     float[] a;
/* 171 */     int kmin = node._kmin;
/* 172 */     int kmax = node._kmax;
/* 173 */     int n = 1 + kmax - kmin;
/* 174 */     if (n / 2 < minSize) {
/*     */       return;
/*     */     }
/*     */     
/* 178 */     BoundingBox bb = node._bb;
/* 179 */     Point3 min = bb.getMin();
/* 180 */     Point3 max = bb.getMax();
/* 181 */     double xdif = max.x - min.x;
/* 182 */     double ydif = max.y - min.y;
/* 183 */     double zdif = max.z - min.z;
/* 184 */     double adif = MathPlus.max(xdif, ydif, zdif);
/*     */     
/* 186 */     if (adif == xdif) {
/* 187 */       a = this._x;
/* 188 */     } else if (adif == ydif) {
/* 189 */       a = this._y;
/*     */     } else {
/* 191 */       a = this._z;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     int[] i = new int[n];
/* 199 */     for (int k = kmin; k <= kmax; k++)
/* 200 */       i[k - kmin] = this._i[k]; 
/* 201 */     int kmid = kmin + n / 2;
/* 202 */     Array.quickPartialIndexSort(kmid - kmin, a, i);
/* 203 */     for (int j = kmin; j <= kmax; j++) {
/* 204 */       this._i[j] = i[j - kmin];
/*     */     }
/*     */     
/* 207 */     Node left = new Node();
/* 208 */     Node right = new Node();
/* 209 */     if (adif == xdif) {
/* 210 */       float spltx = this._x[this._i[kmid]];
/* 211 */       left._bb = new BoundingBox(min.x, min.y, min.z, spltx, max.y, max.z);
/*     */       
/* 213 */       right._bb = new BoundingBox(spltx, min.y, min.z, max.x, max.y, max.z);
/*     */     }
/* 215 */     else if (adif == ydif) {
/* 216 */       float splty = this._y[this._i[kmid]];
/* 217 */       left._bb = new BoundingBox(min.x, min.y, min.z, max.x, splty, max.z);
/*     */       
/* 219 */       right._bb = new BoundingBox(min.x, splty, min.z, max.x, max.y, max.z);
/*     */     } else {
/*     */       
/* 222 */       float spltz = this._z[this._i[kmid]];
/* 223 */       left._bb = new BoundingBox(min.x, min.y, min.z, max.x, max.y, spltz);
/*     */       
/* 225 */       right._bb = new BoundingBox(min.x, min.y, spltz, max.x, max.y, max.z);
/*     */     } 
/*     */     
/* 228 */     left._kmin = kmin;
/* 229 */     left._kmax = kmid - 1;
/* 230 */     right._kmin = kmid;
/* 231 */     right._kmax = kmax;
/* 232 */     node._left = left;
/* 233 */     node._right = right;
/*     */ 
/*     */     
/* 236 */     split(minSize, left);
/* 237 */     split(minSize, right);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/BoundingBoxTree.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */