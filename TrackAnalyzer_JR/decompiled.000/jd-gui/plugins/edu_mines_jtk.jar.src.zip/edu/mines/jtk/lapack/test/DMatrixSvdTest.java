/*    */ package edu.mines.jtk.lapack.test;
/*    */ 
/*    */ import edu.mines.jtk.lapack.DMatrix;
/*    */ import edu.mines.jtk.lapack.DMatrixSvd;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DMatrixSvdTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 26 */     TestSuite suite = new TestSuite(DMatrixSvdTest.class);
/* 27 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testSimple() {
/* 31 */     test(new DMatrix(new double[][] { { 1.0D, 0.0D }, { 0.0D, 2.0D }, { 0.0D, 0.0D } }));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D } }));
/*    */ 
/*    */ 
/*    */     
/* 40 */     test(new DMatrix(new double[][] { { 0.0D, 2.0D }, { 3.0D, 4.0D }, { 5.0D, 6.0D } }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void testRandom() {
/* 48 */     test(DMatrix.random(100, 100));
/* 49 */     test(DMatrix.random(10, 100));
/* 50 */     test(DMatrix.random(100, 10));
/*    */   }
/*    */   
/*    */   public void testCond() {
/* 54 */     DMatrix a = new DMatrix(new double[][] { { 1.0D, 3.0D }, { 7.0D, 9.0D } });
/*    */ 
/*    */ 
/*    */     
/* 58 */     int m = a.getM();
/* 59 */     int n = a.getN();
/* 60 */     DMatrixSvd svd = new DMatrixSvd(a);
/* 61 */     double[] s = svd.getSingularValues();
/* 62 */     double smax = Array.max(s);
/* 63 */     DMatrixTest.assertEqualExact(s[0], smax);
/* 64 */     double smin = Array.min(s);
/* 65 */     DMatrixTest.assertEqualExact(s[Math.min(m, n) - 1], smin);
/* 66 */     double cond = svd.cond();
/* 67 */     DMatrixTest.assertEqualExact(smax / smin, cond);
/*    */   }
/*    */   
/*    */   public void testRank() {
/* 71 */     DMatrix a = new DMatrix(new double[][] { { 1.0D, 3.0D }, { 7.0D, 9.0D } });
/*    */ 
/*    */ 
/*    */     
/* 75 */     DMatrixSvd svda = new DMatrixSvd(a);
/* 76 */     DMatrixTest.assertEqualExact(svda.rank(), 2.0D);
/* 77 */     DMatrix b = new DMatrix(new double[][] { { 1.0D, 3.0D }, { 7.0D, 9.0D }, { 0.0D, 0.0D } });
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 82 */     DMatrixSvd svdb = new DMatrixSvd(b);
/* 83 */     DMatrixTest.assertEqualExact(svdb.rank(), 2.0D);
/* 84 */     DMatrix c = new DMatrix(new double[][] { { 1.0D, 3.0D, 0.0D }, { 7.0D, 9.0D, 0.0D } });
/*    */ 
/*    */ 
/*    */     
/* 88 */     DMatrixSvd svdc = new DMatrixSvd(c);
/* 89 */     DMatrixTest.assertEqualExact(svdc.rank(), 2.0D);
/*    */   }
/*    */   
/*    */   private void test(DMatrix a) {
/* 93 */     DMatrixSvd svd = new DMatrixSvd(a);
/* 94 */     DMatrix u = svd.getU();
/* 95 */     DMatrix s = svd.getS();
/* 96 */     DMatrix vt = svd.getVTranspose();
/* 97 */     DMatrix usvt = u.times(s).times(vt);
/* 98 */     DMatrixTest.assertEqualFuzzy(a, usvt);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/DMatrixSvdTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */