/*    */ package edu.mines.jtk.awt;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JToggleButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModeToggleButton
/*    */   extends JToggleButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ModeToggleButton(Mode mode) {
/* 34 */     super(mode);
/* 35 */     setText(null);
/* 36 */     setMnemonic(0);
/* 37 */     mode.addPropertyChangeListener(new PropertyChangeListener() {
/*    */           public void propertyChange(PropertyChangeEvent e) {
/* 39 */             if (e.getPropertyName().equals("active"))
/* 40 */               ModeToggleButton.this.setSelected(((Boolean)e.getNewValue()).booleanValue()); 
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/ModeToggleButton.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */