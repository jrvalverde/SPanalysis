/*     */ package edu.mines.jtk.opengl;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlCanvas
/*     */   extends Canvas
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private GlPainter _painter;
/*     */   private GlContext _context;
/*     */   private boolean _inited;
/*     */   private int _width;
/*     */   private int _height;
/*     */   private boolean _autoRepaint;
/*     */   
/*     */   public GlCanvas() {
/*  29 */     this((GlPainter)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlCanvas(GlPainter painter) {
/*  37 */     this._painter = painter;
/*  38 */     this._context = new GlContext(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlContext getContext() {
/*  46 */     return this._context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRepaint(boolean autoRepaint) {
/*  57 */     this._autoRepaint = autoRepaint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/*  64 */     this._context.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glInit() {
/*  78 */     if (this._painter != null) {
/*  79 */       this._painter.glInit();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glResize(int width, int height, int widthBefore, int heightBefore) {
/* 100 */     if (this._painter != null) {
/* 101 */       this._painter.glResize(width, height, widthBefore, heightBefore);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glPaint() {
/* 112 */     if (this._painter != null) {
/* 113 */       this._painter.glPaint();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 125 */     this._context.lock();
/*     */     try {
/* 127 */       if (!this._inited) {
/* 128 */         glInit();
/* 129 */         this._inited = true;
/*     */       } 
/* 131 */       int width = getWidth();
/* 132 */       int height = getHeight();
/* 133 */       if (this._width != width || this._height != height) {
/* 134 */         glResize(width, height, this._width, this._height);
/* 135 */         this._width = width;
/* 136 */         this._height = height;
/*     */       } 
/* 138 */       glPaint();
/* 139 */       this._context.swapBuffers();
/* 140 */       if (this._autoRepaint)
/* 141 */         repaint(); 
/*     */     } finally {
/* 143 */       this._context.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Graphics g) {
/* 153 */     paint(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/*     */     try {
/* 161 */       dispose();
/*     */     } finally {
/* 163 */       super.finalize();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/GlCanvas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */