/*     */ package edu.mines.jtk.opt.test;
/*     */ 
/*     */ import edu.mines.jtk.opt.LineSearch;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineSearchTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(LineSearchTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT1() {
/*  31 */     trace("Function 1");
/*  32 */     LineSearch.Function func = new LineSearch.Function() {
/*     */         public double[] evaluate(double s) {
/*  34 */           double t = 1.0D / (s * s + this.beta);
/*  35 */           double f = -s * t;
/*  36 */           double g = (s * s - this.beta) * t * t;
/*  37 */           return new double[] { f, g };
/*     */         }
/*  39 */         private double beta = 2.0D;
/*     */       };
/*  41 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.001D, 0.1D);
/*  42 */     double[] se = { 1.4D, 1.4D, 10.0D, 37.0D };
/*  43 */     double[] ge = { -0.0092D, 0.0047D, 0.0094D, 7.3E-4D };
/*  44 */     int[] ne = { 7, 4, 2, 5 };
/*  45 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT2() {
/*  52 */     trace("Function 2");
/*  53 */     LineSearch.Function func = new LineSearch.Function() {
/*     */         public double[] evaluate(double s) {
/*  55 */           double t = s + this.beta2;
/*  56 */           double f = t * t * t * t * t - 2.0D * t * t * t * t;
/*  57 */           double g = 5.0D * t * t * t * t - 8.0D * t * t * t;
/*  58 */           return new double[] { f, g };
/*     */         }
/*  60 */         private double beta2 = 0.004D;
/*     */       };
/*  62 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.1D, 0.1D);
/*  63 */     double[] se = { 1.6D, 1.6D, 1.6D, 1.6D };
/*  64 */     double[] ge = { 7.1E-9D, 1.0E-10D, -5.0E-9D, -2.3E-8D };
/*  65 */     int[] ne = { 13, 9, 9, 12 };
/*  66 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT3() {
/*  73 */     trace("Function 3");
/*  74 */     LineSearch.Function func = new LineSearch.Function() { public double[] evaluate(double s) {
/*     */           double f, g;
/*  76 */           int nwig = 39;
/*     */           
/*  78 */           if (s < 1.0D - this.beta3) {
/*  79 */             f = 1.0D - s;
/*  80 */             g = -1.0D;
/*  81 */           } else if (s < 1.0D + this.beta3) {
/*  82 */             f = (s - 1.0D) * (s - 1.0D) / 2.0D * this.beta3 + this.beta3 / 2.0D;
/*  83 */             g = (s - 1.0D) / this.beta3;
/*     */           } else {
/*  85 */             f = s - 1.0D;
/*  86 */             g = 1.0D;
/*     */           } 
/*  88 */           double t1 = 2.0D * nwig * MathPlus.atan(1.0D);
/*  89 */           double t2 = (1.0D - this.beta3) / t1;
/*  90 */           f += t2 * MathPlus.sin(t1 * s);
/*  91 */           g += (1.0D - this.beta3) * MathPlus.cos(t1 * s);
/*  92 */           return new double[] { f, g };
/*     */         }
/*  94 */         private double beta3 = 0.01D; }
/*     */       ;
/*  96 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.1D, 0.1D);
/*  97 */     double[] se = { 1.0D, 1.0D, 1.0D, 1.0D };
/*  98 */     double[] ge = { -5.1E-5D, -1.9E-4D, -2.0E-6D, -1.6E-5D };
/*  99 */     int[] ne = { 13, 13, 11, 14 };
/* 100 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT4() {
/* 107 */     trace("Function 4");
/* 108 */     LineSearch.Function func = new LineSearch.Function() {
/*     */         public double[] evaluate(double s) {
/* 110 */           double a1 = 0.001D;
/* 111 */           double a2 = 0.001D;
/* 112 */           double t1 = MathPlus.sqrt(1.0D + a1 * a1) - a1;
/* 113 */           double t2 = MathPlus.sqrt(1.0D + a2 * a2) - a2;
/* 114 */           double f = t1 * MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * MathPlus.sqrt(s * s + a1 * a1);
/* 115 */           double g = -t1 * (1.0D - s) / MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * s / MathPlus.sqrt(s * s + a1 * a1);
/*     */           
/* 117 */           return new double[] { f, g };
/*     */         }
/*     */       };
/* 120 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.001D, 0.001D);
/* 121 */     double[] se = { 0.08D, 0.1D, 0.35D, 0.83D };
/* 122 */     double[] ge = { -6.9E-5D, -4.9E-5D, -2.9E-6D, 1.6E-5D };
/* 123 */     int[] ne = { 5, 2, 4, 5 };
/* 124 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT5() {
/* 131 */     trace("Function 5");
/* 132 */     LineSearch.Function func = new LineSearch.Function() {
/*     */         public double[] evaluate(double s) {
/* 134 */           double a1 = 0.01D;
/* 135 */           double a2 = 0.001D;
/* 136 */           double t1 = MathPlus.sqrt(1.0D + a1 * a1) - a1;
/* 137 */           double t2 = MathPlus.sqrt(1.0D + a2 * a2) - a2;
/* 138 */           double f = t1 * MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * MathPlus.sqrt(s * s + a1 * a1);
/* 139 */           double g = -t1 * (1.0D - s) / MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * s / MathPlus.sqrt(s * s + a1 * a1);
/*     */           
/* 141 */           return new double[] { f, g };
/*     */         }
/*     */       };
/* 144 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.001D, 0.001D);
/* 145 */     double[] se = { 0.075D, 0.078D, 0.073D, 0.076D };
/* 146 */     double[] ge = { 1.9E-4D, 7.4E-4D, -2.6E-4D, 4.5E-4D };
/* 147 */     int[] ne = { 7, 4, 8, 9 };
/* 148 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMT6() {
/* 155 */     trace("Function 6");
/* 156 */     LineSearch.Function func = new LineSearch.Function() {
/*     */         public double[] evaluate(double s) {
/* 158 */           double a1 = 0.001D;
/* 159 */           double a2 = 0.01D;
/* 160 */           double t1 = MathPlus.sqrt(1.0D + a1 * a1) - a1;
/* 161 */           double t2 = MathPlus.sqrt(1.0D + a2 * a2) - a2;
/* 162 */           double f = t1 * MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * MathPlus.sqrt(s * s + a1 * a1);
/* 163 */           double g = -t1 * (1.0D - s) / MathPlus.sqrt((1.0D - s) * (1.0D - s) + a2 * a2) + t2 * s / MathPlus.sqrt(s * s + a1 * a1);
/*     */           
/* 165 */           return new double[] { f, g };
/*     */         }
/*     */       };
/* 168 */     LineSearch ls = new LineSearch(func, 1.0E-10D, 0.001D, 0.001D);
/* 169 */     double[] se = { 0.93D, 0.93D, 0.92D, 0.92D };
/* 170 */     double[] ge = { 5.2E-4D, 8.4E-5D, -2.4E-4D, -3.2E-4D };
/* 171 */     int[] ne = { 14, 12, 9, 12 };
/* 172 */     testMT(func, ls, se, ge, ne);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void testMT(LineSearch.Function func, LineSearch ls, double[] se, double[] ge, int[] ne) {
/* 179 */     double s = 0.001D;
/* 180 */     for (int ie = 0; ie < se.length; ie++, s *= 100.0D) {
/* 181 */       double[] fg = func.evaluate(0.0D);
/* 182 */       double f = fg[0];
/* 183 */       double g = fg[1];
/* 184 */       double smin = 0.0D;
/* 185 */       double smax = 4.0D * MathPlus.max(1.0D, s);
/* 186 */       LineSearch.Result lsr = ls.search(s, f, g, smin, smax);
/* 187 */       trace("s0=" + s);
/* 188 */       trace(" s=" + lsr.s + " f'(s)=" + lsr.g + " ended=" + lsr.ended + " neval=" + lsr.neval);
/*     */ 
/*     */       
/* 191 */       assertTrue(lsr.converged());
/* 192 */       assertEquals(se[ie], lsr.s, 0.1D * MathPlus.abs(se[ie]));
/*     */       
/* 194 */       assertEquals(ne[ie], lsr.neval);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void trace(String s) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/LineSearchTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */