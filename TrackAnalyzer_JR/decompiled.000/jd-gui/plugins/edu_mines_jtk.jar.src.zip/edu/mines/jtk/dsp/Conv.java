/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Conv
/*     */ {
/*     */   public static void conv(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/*  88 */     convFast(lx, kx, x, ly, ky, y, lz, kz, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void conv(int lx1, int lx2, int kx1, int kx2, float[][] x, int ly1, int ly2, int ky1, int ky2, float[][] y, int lz1, int lz2, int kz1, int kz2, float[][] z) {
/* 114 */     zero(lz1, lz2, z);
/* 115 */     int ilo2 = kz2 - kx2 - ky2;
/* 116 */     int ihi2 = ilo2 + lz2 - 1;
/* 117 */     for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 118 */       int jlo2 = Math.max(0, i2 - ly2 + 1);
/* 119 */       int jhi2 = Math.min(lx2 - 1, i2);
/* 120 */       for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 121 */         convSum(lx1, kx1, x[j2], ly1, ky1, y[i2 - j2], lz1, kz1, z[i2 - ilo2]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void conv(int lx1, int lx2, int lx3, int kx1, int kx2, int kx3, float[][][] x, int ly1, int ly2, int ly3, int ky1, int ky2, int ky3, float[][][] y, int lz1, int lz2, int lz3, int kz1, int kz2, int kz3, float[][][] z) {
/* 155 */     zero(lz1, lz2, lz3, z);
/* 156 */     int ilo2 = kz2 - kx2 - ky2;
/* 157 */     int ilo3 = kz3 - kx3 - ky3;
/* 158 */     int ihi2 = ilo2 + lz2 - 1;
/* 159 */     int ihi3 = ilo3 + lz3 - 1;
/* 160 */     for (int i3 = ilo3; i3 <= ihi3; i3++) {
/* 161 */       int jlo3 = Math.max(0, i3 - ly3 + 1);
/* 162 */       int jhi3 = Math.min(lx3 - 1, i3);
/* 163 */       for (int j3 = jlo3; j3 <= jhi3; j3++) {
/* 164 */         for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 165 */           int jlo2 = Math.max(0, i2 - ly2 + 1);
/* 166 */           int jhi2 = Math.min(lx2 - 1, i2);
/* 167 */           for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 168 */             convSum(lx1, kx1, x[j3][j2], ly1, ky1, y[i3 - j3][i2 - j2], lz1, kz1, z[i3 - ilo3][i2 - ilo2]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void xcor(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/* 194 */     reverse(lx, x);
/* 195 */     kx = 1 - kx - lx;
/* 196 */     conv(lx, kx, x, ly, ky, y, lz, kz, z);
/* 197 */     reverse(lx, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void xcor(int lx1, int lx2, int kx1, int kx2, float[][] x, int ly1, int ly2, int ky1, int ky2, float[][] y, int lz1, int lz2, int kz1, int kz2, float[][] z) {
/* 223 */     reverse(lx1, lx2, x);
/* 224 */     kx1 = 1 - kx1 - lx1;
/* 225 */     kx2 = 1 - kx2 - lx2;
/* 226 */     conv(lx1, lx2, kx1, kx2, x, ly1, ly2, ky1, ky2, y, lz1, lz2, kz1, kz2, z);
/* 227 */     reverse(lx1, lx2, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void xcor(int lx1, int lx2, int lx3, int kx1, int kx2, int kx3, float[][][] x, int ly1, int ly2, int ly3, int ky1, int ky2, int ky3, float[][][] y, int lz1, int lz2, int lz3, int kz1, int kz2, int kz3, float[][][] z) {
/* 259 */     reverse(lx1, lx2, lx3, x);
/* 260 */     kx1 = 1 - kx1 - lx1;
/* 261 */     kx2 = 1 - kx2 - lx2;
/* 262 */     kx3 = 1 - kx3 - lx3;
/* 263 */     conv(lx1, lx2, lx3, kx1, kx2, kx3, x, ly1, ly2, ly3, ky1, ky2, ky3, y, lz1, lz2, lz3, kz1, kz2, kz3, z);
/*     */ 
/*     */     
/* 266 */     reverse(lx1, lx2, lx3, x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convFast(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/* 346 */     if (lx > ly) {
/* 347 */       int lt = lx; lx = ly; ly = lt;
/* 348 */       int kt = kx; kx = ky; ky = kt;
/* 349 */       float[] t = x; x = y; y = t;
/*     */     } 
/*     */ 
/*     */     
/* 353 */     int imin = kz - kx - ky;
/* 354 */     int imax = imin + lz - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     int ilo = imin;
/* 362 */     int ihi = Math.min(-1, imax); int i, iz;
/* 363 */     for (i = ilo, iz = i - imin; i <= ihi; i++, iz++) {
/* 364 */       z[iz] = 0.0F;
/*     */     }
/*     */     
/* 367 */     ilo = Math.max(0, imin);
/* 368 */     ihi = Math.min(lx - 2, imax);
/* 369 */     int jlo = 0;
/* 370 */     int jhi = ilo;
/* 371 */     for (i = ilo, iz = i - imin; i < ihi; i += 2, iz += 2, jhi += 2) {
/* 372 */       float sa = 0.0F;
/* 373 */       float sb = 0.0F;
/* 374 */       float yb = y[i - jlo + 1]; int j;
/* 375 */       for (j = jlo; j < jhi; j += 2) {
/* 376 */         float f1 = x[j];
/* 377 */         sb += f1 * yb;
/* 378 */         float ya = y[i - j];
/* 379 */         sa += f1 * ya;
/* 380 */         float xb = x[j + 1];
/* 381 */         sb += xb * ya;
/* 382 */         yb = y[i - j - 1];
/* 383 */         sa += xb * yb;
/*     */       } 
/* 385 */       float xa = x[j];
/* 386 */       sb += xa * yb;
/* 387 */       if (j == jhi) {
/* 388 */         float ya = y[i - j];
/* 389 */         sa += xa * ya;
/* 390 */         float xb = x[j + 1];
/* 391 */         sb += xb * ya;
/*     */       } 
/* 393 */       z[iz] = sa;
/* 394 */       z[iz + 1] = sb;
/*     */     } 
/* 396 */     if (i == ihi) {
/* 397 */       jlo = 0;
/* 398 */       jhi = i;
/* 399 */       float sa = 0.0F;
/* 400 */       for (int j = jlo; j <= jhi; j++)
/* 401 */         sa += x[j] * y[i - j]; 
/* 402 */       z[iz] = sa;
/*     */     } 
/*     */ 
/*     */     
/* 406 */     ilo = Math.max(lx - 1, imin);
/* 407 */     ihi = Math.min(ly - 1, imax);
/* 408 */     jlo = 0;
/* 409 */     jhi = lx - 1;
/* 410 */     for (i = ilo, iz = i - imin; i < ihi; i += 2, iz += 2) {
/* 411 */       float sa = 0.0F;
/* 412 */       float sb = 0.0F;
/* 413 */       float yb = y[i - jlo + 1]; int j;
/* 414 */       for (j = jlo; j < jhi; j += 2) {
/* 415 */         float xa = x[j];
/* 416 */         sb += xa * yb;
/* 417 */         float ya = y[i - j];
/* 418 */         sa += xa * ya;
/* 419 */         float xb = x[j + 1];
/* 420 */         sb += xb * ya;
/* 421 */         yb = y[i - j - 1];
/* 422 */         sa += xb * yb;
/*     */       } 
/* 424 */       if (j == jhi) {
/* 425 */         float xa = x[j];
/* 426 */         sb += xa * yb;
/* 427 */         float ya = y[i - j];
/* 428 */         sa += xa * ya;
/*     */       } 
/* 430 */       z[iz] = sa;
/* 431 */       z[iz + 1] = sb;
/*     */     } 
/* 433 */     if (i == ihi) {
/* 434 */       float sa = 0.0F;
/* 435 */       for (int j = jlo; j <= jhi; j++)
/* 436 */         sa += x[j] * y[i - j]; 
/* 437 */       z[iz] = sa;
/*     */     } 
/*     */ 
/*     */     
/* 441 */     ilo = Math.max(ly, imin);
/* 442 */     ihi = Math.min(lx + ly - 2, imax);
/* 443 */     jlo = ihi - ly + 1;
/* 444 */     jhi = lx - 1;
/* 445 */     for (i = ihi, iz = i - imin; i > ilo; i -= 2, iz -= 2, jlo -= 2) {
/* 446 */       float sa = 0.0F;
/* 447 */       float sb = 0.0F;
/* 448 */       float yb = y[i - jhi - 1]; int j;
/* 449 */       for (j = jhi; j > jlo; j -= 2) {
/* 450 */         float f1 = x[j];
/* 451 */         sb += f1 * yb;
/* 452 */         float ya = y[i - j];
/* 453 */         sa += f1 * ya;
/* 454 */         float xb = x[j - 1];
/* 455 */         sb += xb * ya;
/* 456 */         yb = y[i - j + 1];
/* 457 */         sa += xb * yb;
/*     */       } 
/* 459 */       float xa = x[j];
/* 460 */       sb += xa * yb;
/* 461 */       if (j == jlo) {
/* 462 */         float ya = y[i - j];
/* 463 */         sa += xa * ya;
/* 464 */         float xb = x[j - 1];
/* 465 */         sb += xb * ya;
/*     */       } 
/* 467 */       z[iz] = sa;
/* 468 */       z[iz - 1] = sb;
/*     */     } 
/* 470 */     if (i == ilo) {
/* 471 */       jlo = i - ly + 1;
/* 472 */       jhi = lx - 1;
/* 473 */       float sa = 0.0F;
/* 474 */       for (int j = jhi; j >= jlo; j--)
/* 475 */         sa += x[j] * y[i - j]; 
/* 476 */       z[iz] = sa;
/*     */     } 
/*     */ 
/*     */     
/* 480 */     ilo = Math.max(lx + ly - 1, imin);
/* 481 */     ihi = imax;
/* 482 */     for (i = ilo, iz = i - imin; i <= ihi; i++, iz++) {
/* 483 */       z[iz] = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convSum(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/* 496 */     if (lx > ly) {
/* 497 */       int lt = lx; lx = ly; ly = lt;
/* 498 */       int kt = kx; kx = ky; ky = kt;
/* 499 */       float[] t = x; x = y; y = t;
/*     */     } 
/*     */ 
/*     */     
/* 503 */     int imin = kz - kx - ky;
/* 504 */     int imax = imin + lz - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     int ilo = Math.max(0, imin);
/* 512 */     int ihi = Math.min(lx - 2, imax);
/* 513 */     int jlo = 0;
/* 514 */     int jhi = ilo; int i, iz;
/* 515 */     for (i = ilo, iz = i - imin; i < ihi; i += 2, iz += 2, jhi += 2) {
/* 516 */       float sa = z[iz];
/* 517 */       float sb = z[iz + 1];
/* 518 */       float yb = y[i - jlo + 1]; int j;
/* 519 */       for (j = jlo; j < jhi; j += 2) {
/* 520 */         float f1 = x[j];
/* 521 */         sb += f1 * yb;
/* 522 */         float ya = y[i - j];
/* 523 */         sa += f1 * ya;
/* 524 */         float xb = x[j + 1];
/* 525 */         sb += xb * ya;
/* 526 */         yb = y[i - j - 1];
/* 527 */         sa += xb * yb;
/*     */       } 
/* 529 */       float xa = x[j];
/* 530 */       sb += xa * yb;
/* 531 */       if (j == jhi) {
/* 532 */         float ya = y[i - j];
/* 533 */         sa += xa * ya;
/* 534 */         float xb = x[j + 1];
/* 535 */         sb += xb * ya;
/*     */       } 
/* 537 */       z[iz] = sa;
/* 538 */       z[iz + 1] = sb;
/*     */     } 
/* 540 */     if (i == ihi) {
/* 541 */       jlo = 0;
/* 542 */       jhi = i;
/* 543 */       float sa = z[iz];
/* 544 */       for (int j = jlo; j <= jhi; j++)
/* 545 */         sa += x[j] * y[i - j]; 
/* 546 */       z[iz] = sa;
/*     */     } 
/*     */ 
/*     */     
/* 550 */     ilo = Math.max(lx - 1, imin);
/* 551 */     ihi = Math.min(ly - 1, imax);
/* 552 */     jlo = 0;
/* 553 */     jhi = lx - 1;
/* 554 */     for (i = ilo, iz = i - imin; i < ihi; i += 2, iz += 2) {
/* 555 */       float sa = z[iz];
/* 556 */       float sb = z[iz + 1];
/* 557 */       float yb = y[i - jlo + 1]; int j;
/* 558 */       for (j = jlo; j < jhi; j += 2) {
/* 559 */         float xa = x[j];
/* 560 */         sb += xa * yb;
/* 561 */         float ya = y[i - j];
/* 562 */         sa += xa * ya;
/* 563 */         float xb = x[j + 1];
/* 564 */         sb += xb * ya;
/* 565 */         yb = y[i - j - 1];
/* 566 */         sa += xb * yb;
/*     */       } 
/* 568 */       if (j == jhi) {
/* 569 */         float xa = x[j];
/* 570 */         sb += xa * yb;
/* 571 */         float ya = y[i - j];
/* 572 */         sa += xa * ya;
/*     */       } 
/* 574 */       z[iz] = sa;
/* 575 */       z[iz + 1] = sb;
/*     */     } 
/* 577 */     if (i == ihi) {
/* 578 */       float sa = z[iz];
/* 579 */       for (int j = jlo; j <= jhi; j++)
/* 580 */         sa += x[j] * y[i - j]; 
/* 581 */       z[iz] = sa;
/*     */     } 
/*     */ 
/*     */     
/* 585 */     ilo = Math.max(ly, imin);
/* 586 */     ihi = Math.min(lx + ly - 2, imax);
/* 587 */     jlo = ihi - ly + 1;
/* 588 */     jhi = lx - 1;
/* 589 */     for (i = ihi, iz = i - imin; i > ilo; i -= 2, iz -= 2, jlo -= 2) {
/* 590 */       float sa = z[iz];
/* 591 */       float sb = z[iz - 1];
/* 592 */       float yb = y[i - jhi - 1]; int j;
/* 593 */       for (j = jhi; j > jlo; j -= 2) {
/* 594 */         float f1 = x[j];
/* 595 */         sb += f1 * yb;
/* 596 */         float ya = y[i - j];
/* 597 */         sa += f1 * ya;
/* 598 */         float xb = x[j - 1];
/* 599 */         sb += xb * ya;
/* 600 */         yb = y[i - j + 1];
/* 601 */         sa += xb * yb;
/*     */       } 
/* 603 */       float xa = x[j];
/* 604 */       sb += xa * yb;
/* 605 */       if (j == jlo) {
/* 606 */         float ya = y[i - j];
/* 607 */         sa += xa * ya;
/* 608 */         float xb = x[j - 1];
/* 609 */         sb += xb * ya;
/*     */       } 
/* 611 */       z[iz] = sa;
/* 612 */       z[iz - 1] = sb;
/*     */     } 
/* 614 */     if (i == ilo) {
/* 615 */       jlo = i - ly + 1;
/* 616 */       jhi = lx - 1;
/* 617 */       float sa = z[iz];
/* 618 */       for (int j = jhi; j >= jlo; j--)
/* 619 */         sa += x[j] * y[i - j]; 
/* 620 */       z[iz] = sa;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void zero(int n1, float[] z) {
/* 625 */     for (int i1 = 0; i1 < n1; i1++)
/* 626 */       z[i1] = 0.0F; 
/*     */   }
/*     */   
/*     */   private static void zero(int n1, int n2, float[][] z) {
/* 630 */     for (int i2 = 0; i2 < n2; i2++)
/* 631 */       zero(n1, z[i2]); 
/*     */   }
/*     */   
/*     */   private static void zero(int n1, int n2, int n3, float[][][] z) {
/* 635 */     for (int i3 = 0; i3 < n3; i3++)
/* 636 */       zero(n1, n2, z[i3]); 
/*     */   }
/*     */   
/*     */   private static void reverse(int n1, float[] z) {
/* 640 */     for (int i1 = 0, j1 = n1 - 1; i1 < j1; i1++, j1--) {
/* 641 */       float zt = z[i1];
/* 642 */       z[i1] = z[j1];
/* 643 */       z[j1] = zt;
/*     */     } 
/*     */   } private static void reverse(int n1, int n2, float[][] z) {
/*     */     int i2;
/*     */     int j2;
/* 648 */     for (i2 = 0, j2 = n2 - 1; i2 < j2; i2++, j2--) {
/* 649 */       float[] zt = z[i2];
/* 650 */       z[i2] = z[j2];
/* 651 */       z[j2] = zt;
/*     */     } 
/* 653 */     for (i2 = 0; i2 < n2; i2++)
/* 654 */       reverse(n1, z[i2]); 
/*     */   } private static void reverse(int n1, int n2, int n3, float[][][] z) {
/*     */     int i3;
/*     */     int j3;
/* 658 */     for (i3 = 0, j3 = n3 - 1; i3 < j3; i3++, j3--) {
/* 659 */       float[][] zt = z[i3];
/* 660 */       z[i3] = z[j3];
/* 661 */       z[j3] = zt;
/*     */     } 
/* 663 */     for (i3 = 0; i3 < n3; i3++)
/* 664 */       reverse(n1, n2, z[i3]); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Conv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */