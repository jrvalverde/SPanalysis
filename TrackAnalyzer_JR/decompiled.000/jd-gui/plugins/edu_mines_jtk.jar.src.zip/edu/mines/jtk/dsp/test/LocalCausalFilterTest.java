/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.LocalCausalFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalCausalFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(LocalCausalFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1Random() {
/*  28 */     int[] lag1 = { 0, 1, 2 };
/*  29 */     final float[] ar = { 1.0F, -1.8F, 0.81F };
/*  30 */     final float[] as = { 1.0F, -1.6F, 0.64F };
/*  31 */     LocalCausalFilter lcf = new LocalCausalFilter(lag1);
/*  32 */     LocalCausalFilter.A1 a1 = new LocalCausalFilter.A1() {
/*     */         public void get(int i1, float[] a) {
/*  34 */           if (i1 % 2 == 0) {
/*  35 */             a[0] = ar[0]; a[1] = ar[1]; a[2] = ar[2];
/*     */           } else {
/*  37 */             a[0] = as[0]; a[1] = as[1]; a[2] = as[2];
/*     */           } 
/*     */         }
/*     */       };
/*  41 */     int n = 100;
/*  42 */     float tiny = n * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/*  45 */     float[] x = randfloat(n);
/*  46 */     float[] y = randfloat(n);
/*  47 */     float[] ax = zerofloat(n);
/*  48 */     float[] ay = zerofloat(n);
/*  49 */     lcf.apply(a1, x, ax);
/*  50 */     lcf.applyTranspose(a1, y, ay);
/*  51 */     float dyx = dot(y, ax);
/*  52 */     float dxy = dot(x, ay);
/*  53 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/*  57 */     x = randfloat(n);
/*  58 */     y = randfloat(n);
/*  59 */     float[] bx = zerofloat(n);
/*  60 */     float[] by = zerofloat(n);
/*  61 */     lcf.applyInverse(a1, x, bx);
/*  62 */     lcf.applyInverseTranspose(a1, y, by);
/*  63 */     dyx = dot(y, bx);
/*  64 */     dxy = dot(x, by);
/*  65 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/*  69 */     x = randfloat(n);
/*  70 */     y = Array.copy(x);
/*  71 */     lcf.apply(a1, y, y);
/*  72 */     lcf.applyInverse(a1, y, y);
/*  73 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/*  77 */     x = randfloat(n);
/*  78 */     y = zerofloat(n);
/*  79 */     lcf.applyInverseTranspose(a1, x, y);
/*  80 */     lcf.applyTranspose(a1, y, y);
/*  81 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void test2Random() {
/*  86 */     int[] lag1 = { 0, 1, 2, 3, 4, -4, -3, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */     
/*  90 */     int[] lag2 = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/*  94 */     float[] aa = { 1.7954845F, -0.64490664F, -0.03850411F, -0.01793403F, -0.00708972F, -0.02290331F, -0.04141619F, -0.08457147F, -0.20031442F, -0.5565992F };
/*     */ 
/*     */ 
/*     */     
/*  98 */     final float[] ar = Array.mul(1.0F, aa);
/*  99 */     final float[] as = Array.mul(2.0F, aa);
/* 100 */     LocalCausalFilter lcf = new LocalCausalFilter(lag1, lag2);
/* 101 */     LocalCausalFilter.A2 a2 = new LocalCausalFilter.A2() {
/*     */         public void get(int i1, int i2, float[] a) {
/* 103 */           if ((i1 + i2) % 2 == 0) {
/* 104 */             Array.copy(ar, a);
/*     */           } else {
/* 106 */             Array.copy(as, a);
/*     */           } 
/*     */         }
/*     */       };
/* 110 */     int n1 = 19;
/* 111 */     int n2 = 21;
/* 112 */     float tiny = (n1 * n2) * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/* 115 */     float[][] x = randfloat(n1, n2);
/* 116 */     float[][] y = randfloat(n1, n2);
/* 117 */     float[][] ax = zerofloat(n1, n2);
/* 118 */     float[][] ay = zerofloat(n1, n2);
/* 119 */     lcf.apply(a2, x, ax);
/* 120 */     lcf.applyTranspose(a2, y, ay);
/* 121 */     float dyx = dot(y, ax);
/* 122 */     float dxy = dot(x, ay);
/* 123 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 127 */     x = randfloat(n1, n2);
/* 128 */     y = randfloat(n1, n2);
/* 129 */     float[][] bx = zerofloat(n1, n2);
/* 130 */     float[][] by = zerofloat(n1, n2);
/* 131 */     lcf.applyInverse(a2, x, bx);
/* 132 */     lcf.applyInverseTranspose(a2, y, by);
/* 133 */     dyx = dot(y, bx);
/* 134 */     dxy = dot(x, by);
/* 135 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 139 */     x = randfloat(n1, n2);
/* 140 */     y = Array.copy(x);
/* 141 */     lcf.apply(a2, y, y);
/* 142 */     lcf.applyInverse(a2, y, y);
/* 143 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/* 147 */     x = randfloat(n1, n2);
/* 148 */     y = zerofloat(n1, n2);
/* 149 */     lcf.applyInverseTranspose(a2, x, y);
/* 150 */     lcf.applyTranspose(a2, y, y);
/* 151 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void test3Random() {
/* 156 */     int[] lag1 = { 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     int[] lag2 = { 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     float[] aa = { 2.3110454F, -0.4805547F, -0.0143204F, -0.0291793F, -0.1057476F, -0.4572746F, -0.0115732F, -0.0047283F, -0.0149963F, -0.0408317F, -0.0945958F, -0.0223166F, -0.0062781F, -0.0213786F, -0.0898909F, -0.4322719F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     final float[] ar = Array.mul(1.0F, aa);
/* 181 */     final float[] as = Array.mul(2.0F, aa);
/* 182 */     LocalCausalFilter lcf = new LocalCausalFilter(lag1, lag2, lag3);
/* 183 */     LocalCausalFilter.A3 a3 = new LocalCausalFilter.A3() {
/*     */         public void get(int i1, int i2, int i3, float[] a) {
/* 185 */           if ((i1 + i2 + i3) % 2 == 0) {
/* 186 */             Array.copy(ar, a);
/*     */           } else {
/* 188 */             Array.copy(as, a);
/*     */           } 
/*     */         }
/*     */       };
/* 192 */     int n1 = 11;
/* 193 */     int n2 = 13;
/* 194 */     int n3 = 12;
/* 195 */     float tiny = (n1 * n2 * n3) * 10.0F * 1.1920929E-7F;
/*     */ 
/*     */     
/* 198 */     float[][][] x = randfloat(n1, n2, n3);
/* 199 */     float[][][] y = randfloat(n1, n2, n3);
/* 200 */     float[][][] ax = zerofloat(n1, n2, n3);
/* 201 */     float[][][] ay = zerofloat(n1, n2, n3);
/* 202 */     lcf.apply(a3, x, ax);
/* 203 */     lcf.applyTranspose(a3, y, ay);
/* 204 */     float dyx = dot(y, ax);
/* 205 */     float dxy = dot(x, ay);
/* 206 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 210 */     x = randfloat(n1, n2, n3);
/* 211 */     y = randfloat(n1, n2, n3);
/* 212 */     float[][][] bx = zerofloat(n1, n2, n3);
/* 213 */     float[][][] by = zerofloat(n1, n2, n3);
/* 214 */     lcf.applyInverse(a3, x, bx);
/* 215 */     lcf.applyInverseTranspose(a3, y, by);
/* 216 */     dyx = dot(y, bx);
/* 217 */     dxy = dot(x, by);
/* 218 */     assertEquals(dyx, dxy, tiny);
/*     */ 
/*     */ 
/*     */     
/* 222 */     x = randfloat(n1, n2, n3);
/* 223 */     y = Array.copy(x);
/* 224 */     lcf.apply(a3, y, y);
/* 225 */     lcf.applyInverse(a3, y, y);
/* 226 */     assertEqual(x, y);
/*     */ 
/*     */ 
/*     */     
/* 230 */     x = randfloat(n1, n2, n3);
/* 231 */     y = zerofloat(n1, n2, n3);
/* 232 */     lcf.applyInverseTranspose(a3, x, y);
/* 233 */     lcf.applyTranspose(a3, y, y);
/* 234 */     assertEqual(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] randfloat(int n1) {
/* 242 */     return Array.sub(Array.randfloat(n1), 0.5F);
/*     */   }
/*     */   private static float[][] randfloat(int n1, int n2) {
/* 245 */     return Array.sub(Array.randfloat(n1, n2), 0.5F);
/*     */   }
/*     */   private static float[][][] randfloat(int n1, int n2, int n3) {
/* 248 */     return Array.sub(Array.randfloat(n1, n2, n3), 0.5F);
/*     */   }
/*     */   
/*     */   private static float[] zerofloat(int n1) {
/* 252 */     return Array.zerofloat(n1);
/*     */   }
/*     */   private static float[][] zerofloat(int n1, int n2) {
/* 255 */     return Array.zerofloat(n1, n2);
/*     */   }
/*     */   private static float[][][] zerofloat(int n1, int n2, int n3) {
/* 258 */     return Array.zerofloat(n1, n2, n3);
/*     */   }
/*     */   
/*     */   private static float dot(float[] x, float[] y) {
/* 262 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][] x, float[][] y) {
/* 265 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][][] x, float[][][] y) {
/* 268 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[] re, float[] ra) {
/* 272 */     int n = re.length;
/* 273 */     float tolerance = n * 1.1920929E-7F;
/* 274 */     for (int i = 0; i < n; i++)
/* 275 */       assertEquals(re[i], ra[i], tolerance); 
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[][] re, float[][] ra) {
/* 279 */     int n2 = re.length;
/* 280 */     int n1 = (re[0]).length;
/* 281 */     float tolerance = (n1 * n2) * 1.1920929E-7F;
/* 282 */     for (int i2 = 0; i2 < n2; i2++) {
/* 283 */       for (int i1 = 0; i1 < n1; i1++)
/* 284 */         assertEquals(re[i2][i1], ra[i2][i1], tolerance); 
/*     */     } 
/*     */   }
/*     */   private static void assertEqual(float[][][] re, float[][][] ra) {
/* 288 */     int n3 = re.length;
/* 289 */     int n2 = (re[0]).length;
/* 290 */     int n1 = (re[0][0]).length;
/* 291 */     float tolerance = (n1 * n2 * n3) * 1.1920929E-7F;
/* 292 */     for (int i3 = 0; i3 < n3; i3++) {
/* 293 */       for (int i2 = 0; i2 < n2; i2++) {
/* 294 */         for (int i1 = 0; i1 < n1; i1++)
/* 295 */           assertEquals(re[i3][i2][i1], ra[i3][i2][i1], tolerance); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/LocalCausalFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */