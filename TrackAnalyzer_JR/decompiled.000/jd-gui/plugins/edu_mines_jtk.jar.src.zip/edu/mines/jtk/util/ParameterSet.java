/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.StringReader;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterSet
/*     */   implements Cloneable, Externalizable
/*     */ {
/*     */   private String _name;
/*     */   private ParameterSet _parent;
/*     */   
/*     */   public ParameterSet() {}
/*     */   
/*     */   public ParameterSet(String name) {
/*  39 */     setNameAndParent(name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  49 */       ParameterSet ps = (ParameterSet)super.clone();
/*  50 */       ps._parent = null;
/*  51 */       ps._pars = new LinkedHashMap<String, Parameter>();
/*  52 */       ps._parsets = new LinkedHashMap<String, ParameterSet>();
/*  53 */       return ps.replaceWith(this);
/*  54 */     } catch (CloneNotSupportedException e) {
/*  55 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet replaceWith(ParameterSet parset) {
/*  68 */     if (parset == this) return this; 
/*  69 */     setName(parset.getName());
/*  70 */     clear();
/*  71 */     Iterator<Parameter> pi = parset.getParameters();
/*  72 */     while (pi.hasNext()) {
/*  73 */       ((Parameter)pi.next()).copyTo(this);
/*     */     }
/*  75 */     Iterator<ParameterSet> psi = parset.getParameterSets();
/*  76 */     while (psi.hasNext()) {
/*  77 */       ((ParameterSet)psi.next()).copyTo(this);
/*     */     }
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  87 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/*  96 */     moveTo(this._parent, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parameter getParameter(String name) {
/* 106 */     return this._pars.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet getParameterSet(String name) {
/* 116 */     return this._parsets.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parameter addParameter(String name) {
/* 128 */     if (name == null) return null; 
/* 129 */     Parameter par = new Parameter(name);
/* 130 */     insert(name, par);
/* 131 */     return par;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet addParameterSet(String name) {
/* 143 */     if (name == null) return null; 
/* 144 */     ParameterSet parset = new ParameterSet(name, null);
/* 145 */     insert(name, parset);
/* 146 */     return parset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String name, boolean defaultValue) throws ParameterConvertException {
/* 160 */     Parameter par = getParameter(name);
/* 161 */     return (par != null) ? par.getBoolean() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt(String name, int defaultValue) throws ParameterConvertException {
/* 175 */     Parameter par = getParameter(name);
/* 176 */     return (par != null) ? par.getInt() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong(String name, long defaultValue) throws ParameterConvertException {
/* 190 */     Parameter par = getParameter(name);
/* 191 */     return (par != null) ? par.getLong() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat(String name, float defaultValue) throws ParameterConvertException {
/* 205 */     Parameter par = getParameter(name);
/* 206 */     return (par != null) ? par.getFloat() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble(String name, double defaultValue) throws ParameterConvertException {
/* 220 */     Parameter par = getParameter(name);
/* 221 */     return (par != null) ? par.getDouble() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String name, String defaultValue) throws ParameterConvertException {
/* 235 */     Parameter par = getParameter(name);
/* 236 */     return (par != null) ? par.getString() : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean[] getBooleans(String name, boolean[] defaultValues) throws ParameterConvertException {
/* 250 */     Parameter par = getParameter(name);
/* 251 */     return (par != null) ? par.getBooleans() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getInts(String name, int[] defaultValues) throws ParameterConvertException {
/* 265 */     Parameter par = getParameter(name);
/* 266 */     return (par != null) ? par.getInts() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long[] getLongs(String name, long[] defaultValues) throws ParameterConvertException {
/* 280 */     Parameter par = getParameter(name);
/* 281 */     return (par != null) ? par.getLongs() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getFloats(String name, float[] defaultValues) throws ParameterConvertException {
/* 295 */     Parameter par = getParameter(name);
/* 296 */     return (par != null) ? par.getFloats() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getDoubles(String name, double[] defaultValues) throws ParameterConvertException {
/* 310 */     Parameter par = getParameter(name);
/* 311 */     return (par != null) ? par.getDoubles() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getStrings(String name, String[] defaultValues) throws ParameterConvertException {
/* 325 */     Parameter par = getParameter(name);
/* 326 */     return (par != null) ? par.getStrings() : defaultValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnits(String name, String defaultUnits) {
/* 337 */     Parameter par = getParameter(name);
/* 338 */     return (par != null) ? par.getUnits() : defaultUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBoolean(String name, boolean value) {
/* 349 */     Parameter par = getParameter(name);
/* 350 */     if (par == null) par = addParameter(name); 
/* 351 */     par.setBoolean(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInt(String name, int value) {
/* 362 */     Parameter par = getParameter(name);
/* 363 */     if (par == null) par = addParameter(name); 
/* 364 */     par.setInt(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLong(String name, long value) {
/* 375 */     Parameter par = getParameter(name);
/* 376 */     if (par == null) par = addParameter(name); 
/* 377 */     par.setLong(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFloat(String name, float value) {
/* 388 */     Parameter par = getParameter(name);
/* 389 */     if (par == null) par = addParameter(name); 
/* 390 */     par.setFloat(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDouble(String name, double value) {
/* 401 */     Parameter par = getParameter(name);
/* 402 */     if (par == null) par = addParameter(name); 
/* 403 */     par.setDouble(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString(String name, String value) {
/* 414 */     Parameter par = getParameter(name);
/* 415 */     if (par == null) par = addParameter(name); 
/* 416 */     par.setString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBooleans(String name, boolean[] values) {
/* 427 */     Parameter par = getParameter(name);
/* 428 */     if (par == null) par = addParameter(name); 
/* 429 */     par.setBooleans(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInts(String name, int[] values) {
/* 440 */     Parameter par = getParameter(name);
/* 441 */     if (par == null) par = addParameter(name); 
/* 442 */     par.setInts(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLongs(String name, long[] values) {
/* 453 */     Parameter par = getParameter(name);
/* 454 */     if (par == null) par = addParameter(name); 
/* 455 */     par.setLongs(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFloats(String name, float[] values) {
/* 466 */     Parameter par = getParameter(name);
/* 467 */     if (par == null) par = addParameter(name); 
/* 468 */     par.setFloats(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDoubles(String name, double[] values) {
/* 479 */     Parameter par = getParameter(name);
/* 480 */     if (par == null) par = addParameter(name); 
/* 481 */     par.setDoubles(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStrings(String name, String[] values) {
/* 492 */     Parameter par = getParameter(name);
/* 493 */     if (par == null) par = addParameter(name); 
/* 494 */     par.setStrings(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnits(String name, String units) {
/* 505 */     Parameter par = getParameter(name);
/* 506 */     if (par == null) par = addParameter(name); 
/* 507 */     par.setUnits(units);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet copyTo(ParameterSet parent) {
/* 519 */     return copyTo(parent, getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet copyTo(ParameterSet parent, String name) {
/* 532 */     if (parent == this._parent && name == this._name) return this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 538 */     ParameterSet ps = new ParameterSet(name);
/*     */ 
/*     */     
/* 541 */     Iterator<Parameter> pi = getParameters();
/* 542 */     while (pi.hasNext()) {
/* 543 */       ((Parameter)pi.next()).copyTo(ps);
/*     */     }
/*     */ 
/*     */     
/* 547 */     Iterator<ParameterSet> psi = getParameterSets();
/* 548 */     while (psi.hasNext()) {
/* 549 */       ((ParameterSet)psi.next()).copyTo(ps);
/*     */     }
/*     */ 
/*     */     
/* 553 */     if (parent != null) parent.insert(name, ps); 
/* 554 */     return ps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet moveTo(ParameterSet parent) {
/* 566 */     return moveTo(parent, getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet moveTo(ParameterSet parent, String name) {
/* 580 */     if (parent == this._parent && name == this._name) return this;
/*     */ 
/*     */     
/* 583 */     for (ParameterSet ps = parent; ps != null; ps = ps.getParent()) {
/* 584 */       if (ps == this) {
/* 585 */         throw new IllegalArgumentException("ParameterSet.moveTo: specified parent \"" + parent.getName() + "\"" + " cannot be this parameter set \"" + getName() + "\"" + " or a subset of this parameter set.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 593 */     if (this._parent != null) this._parent.remove(this); 
/* 594 */     if (parent != null) {
/* 595 */       parent.insert(name, this);
/*     */     } else {
/* 597 */       setNameAndParent(name, null);
/*     */     } 
/*     */     
/* 600 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 609 */     if (this._parent != null) this._parent.remove(this);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String name) {
/*     */     Parameter par;
/* 621 */     if ((par = getParameter(name)) != null)
/* 622 */     { par.remove(); }
/* 623 */     else { ParameterSet parset; if ((parset = getParameterSet(name)) != null) {
/* 624 */         parset.remove();
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countParameters() {
/* 633 */     return this._pars.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countParameterSets() {
/* 641 */     return this._parsets.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 651 */     Iterator<Parameter> pi = getParameters();
/* 652 */     while (pi.hasNext()) {
/* 653 */       ((Parameter)pi.next()).setParent(null);
/*     */     }
/* 655 */     Iterator<ParameterSet> psi = getParameterSets();
/* 656 */     while (psi.hasNext()) {
/* 657 */       ((ParameterSet)psi.next()).setParent(null);
/*     */     }
/*     */ 
/*     */     
/* 661 */     this._pars.clear();
/* 662 */     this._parsets.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterSet getParent() {
/* 672 */     return this._parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Parameter> getParameters() {
/* 680 */     return this._pars.values().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<ParameterSet> getParameterSets() {
/* 688 */     return this._parsets.values().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fromString(String s) throws ParameterSetFormatException {
/* 700 */     clear();
/* 701 */     ParameterSetParser psp = new ParameterSetParser();
/* 702 */     psp.parse(new BufferedReader(new StringReader(s)), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 714 */     String indent = "";
/* 715 */     ParameterSet parent = getParent();
/* 716 */     for (; parent != null; 
/* 717 */       parent = parent.getParent()) {
/* 718 */       indent = indent + "  ";
/*     */     }
/*     */ 
/*     */     
/* 722 */     StringBuffer sb = new StringBuffer(256);
/* 723 */     String name = XmlUtil.quoteAttributeValue((this._name != null) ? this._name : "");
/* 724 */     sb.append(indent).append("<parset name=").append(name).append(">\n");
/*     */ 
/*     */     
/* 727 */     Iterator<Parameter> pi = getParameters();
/* 728 */     while (pi.hasNext()) {
/* 729 */       Parameter p = pi.next();
/* 730 */       sb.append(p.toString());
/*     */     } 
/*     */ 
/*     */     
/* 734 */     Iterator<ParameterSet> psi = getParameterSets();
/* 735 */     while (psi.hasNext()) {
/* 736 */       ParameterSet ps = psi.next();
/* 737 */       sb.append(ps.toString());
/*     */     } 
/*     */ 
/*     */     
/* 741 */     sb.append(indent).append("</parset>\n");
/* 742 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 752 */     if (o == this)
/* 753 */       return true; 
/* 754 */     if (o == null || getClass() != o.getClass())
/* 755 */       return false; 
/* 756 */     ParameterSet other = (ParameterSet)o;
/*     */ 
/*     */     
/* 759 */     if (this._name == null) {
/* 760 */       if (other._name != null)
/* 761 */         return false; 
/* 762 */     } else if (!this._name.equals(other._name)) {
/* 763 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 767 */     int npars = countParameters();
/* 768 */     if (npars != other.countParameters()) {
/* 769 */       return false;
/*     */     }
/*     */     
/* 772 */     int nparsets = countParameterSets();
/* 773 */     if (nparsets != other.countParameterSets()) {
/* 774 */       return false;
/*     */     }
/*     */     
/* 777 */     if (npars > 0) {
/* 778 */       Parameter[] these = new Parameter[npars];
/* 779 */       Parameter[] those = new Parameter[npars];
/* 780 */       int i = 0;
/* 781 */       Iterator<Parameter> pi = getParameters();
/* 782 */       while (pi.hasNext()) {
/* 783 */         these[i++] = pi.next();
/*     */       }
/* 785 */       i = 0;
/* 786 */       pi = other.getParameters();
/* 787 */       while (pi.hasNext()) {
/* 788 */         those[i++] = pi.next();
/*     */       }
/* 790 */       sortParametersByName(these);
/* 791 */       sortParametersByName(those);
/* 792 */       for (i = 0; i < npars; i++) {
/* 793 */         if (!these[i].equals(those[i])) {
/* 794 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 799 */     if (nparsets > 0) {
/* 800 */       ParameterSet[] these = new ParameterSet[nparsets];
/* 801 */       ParameterSet[] those = new ParameterSet[nparsets];
/* 802 */       int i = 0;
/* 803 */       Iterator<ParameterSet> psi = getParameterSets();
/* 804 */       while (psi.hasNext()) {
/* 805 */         these[i++] = psi.next();
/*     */       }
/* 807 */       i = 0;
/* 808 */       psi = other.getParameterSets();
/* 809 */       while (psi.hasNext()) {
/* 810 */         those[i++] = psi.next();
/*     */       }
/* 812 */       sortParameterSetsByName(these);
/* 813 */       sortParameterSetsByName(those);
/* 814 */       for (i = 0; i < nparsets; i++) {
/* 815 */         if (!these[i].equals(those[i])) {
/* 816 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 821 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 829 */     String name = (this._name != null) ? this._name : "name";
/* 830 */     int code = name.hashCode();
/* 831 */     Iterator<Parameter> pars = getParameters();
/* 832 */     while (pars.hasNext()) {
/* 833 */       code ^= ((Parameter)pars.next()).hashCode();
/*     */     }
/* 835 */     Iterator<ParameterSet> parsets = getParameterSets();
/* 836 */     while (parsets.hasNext()) {
/* 837 */       code ^= ((ParameterSet)parsets.next()).hashCode();
/*     */     }
/* 839 */     return code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 850 */     out.writeUTF(toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException, ParameterSetFormatException {
/* 866 */     String s = in.readUTF();
/* 867 */     fromString(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void remove(Parameter par) {
/* 874 */     if (par == null)
/* 875 */       return;  this._pars.remove(par.getName());
/* 876 */     par.setParent(null);
/*     */   }
/*     */   
/*     */   void insert(String name, Parameter par) {
/* 880 */     if (name == null || par == null)
/* 881 */       return;  par.remove();
/* 882 */     remove(name);
/* 883 */     this._pars.put(name, par);
/* 884 */     par.setNameAndParent(name, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 892 */   private LinkedHashMap<String, Parameter> _pars = new LinkedHashMap<String, Parameter>(8);
/*     */   
/* 894 */   private LinkedHashMap<String, ParameterSet> _parsets = new LinkedHashMap<String, ParameterSet>(8);
/*     */ 
/*     */   
/*     */   private ParameterSet(String name, ParameterSet parent) {
/* 898 */     setNameAndParent(name, parent);
/*     */   }
/*     */   
/*     */   private void setParent(ParameterSet parent) {
/* 902 */     this._parent = parent;
/*     */   }
/*     */   
/*     */   private void setNameAndParent(String name, ParameterSet parent) {
/* 906 */     this._name = name;
/* 907 */     if (this._name != null && this._name.equals("")) this._name = null; 
/* 908 */     this._parent = parent;
/*     */   }
/*     */   
/*     */   private void remove(ParameterSet parset) {
/* 912 */     if (parset == null)
/* 913 */       return;  this._parsets.remove(parset.getName());
/* 914 */     parset.setParent(null);
/*     */   }
/*     */   
/*     */   private void insert(String name, ParameterSet parset) {
/* 918 */     if (name == null || parset == null)
/* 919 */       return;  parset.remove();
/* 920 */     remove(name);
/* 921 */     this._parsets.put(name, parset);
/* 922 */     parset.setNameAndParent(name, this);
/*     */   }
/*     */   
/*     */   private static void swap(Object[] v, int i, int j) {
/* 926 */     Object temp = v[i];
/* 927 */     v[i] = v[j];
/* 928 */     v[j] = temp;
/*     */   }
/*     */   
/*     */   private static void qsortParameters(Parameter[] v, int left, int right) {
/* 932 */     if (left >= right)
/* 933 */       return;  swap((Object[])v, left, (left + right) / 2);
/* 934 */     int last = left;
/* 935 */     for (int i = left + 1; i <= right; i++) {
/* 936 */       if (v[i].getName().compareTo(v[left].getName()) < 0)
/* 937 */         swap((Object[])v, ++last, i); 
/* 938 */     }  swap((Object[])v, left, last);
/* 939 */     qsortParameters(v, left, last - 1);
/* 940 */     qsortParameters(v, last + 1, right);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void qsortParameterSets(ParameterSet[] v, int left, int right) {
/* 945 */     if (left >= right)
/* 946 */       return;  swap((Object[])v, left, (left + right) / 2);
/* 947 */     int last = left;
/* 948 */     for (int i = left + 1; i <= right; i++) {
/* 949 */       if (v[i].getName().compareTo(v[left].getName()) < 0)
/* 950 */         swap((Object[])v, ++last, i); 
/* 951 */     }  swap((Object[])v, left, last);
/* 952 */     qsortParameterSets(v, left, last - 1);
/* 953 */     qsortParameterSets(v, last + 1, right);
/*     */   }
/*     */   
/*     */   private static void sortParametersByName(Parameter[] v) {
/* 957 */     qsortParameters(v, 0, v.length - 1);
/*     */   }
/*     */   
/*     */   private static void sortParameterSetsByName(ParameterSet[] v) {
/* 961 */     qsortParameterSets(v, 0, v.length - 1);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/ParameterSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */