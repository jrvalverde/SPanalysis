package edu.mines.jtk.opengl;

public interface GlPainter {
  void glInit();
  
  void glResize(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void glPaint();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/GlPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */