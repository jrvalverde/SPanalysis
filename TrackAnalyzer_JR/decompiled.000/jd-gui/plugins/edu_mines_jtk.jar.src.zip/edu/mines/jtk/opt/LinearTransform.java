package edu.mines.jtk.opt;

public interface LinearTransform {
  void forward(Vect paramVect, VectConst paramVectConst);
  
  void addTranspose(VectConst paramVectConst, Vect paramVect);
  
  void inverseHessian(Vect paramVect);
  
  void adjustRobustErrors(Vect paramVect);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/LinearTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */