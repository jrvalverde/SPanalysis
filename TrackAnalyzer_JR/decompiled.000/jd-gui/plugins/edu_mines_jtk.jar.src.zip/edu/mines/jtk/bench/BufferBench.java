/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferBench
/*    */ {
/*    */   public static void main(String[] args) {
/* 20 */     testOutOfMemory();
/*    */   }
/*    */   
/*    */   public static void testOutOfMemory() {
/* 24 */     int capacity = 100000000;
/* 25 */     int nbuf = 100;
/* 26 */     byte data = 31;
/* 27 */     for (int ibuf = 0; ibuf < nbuf; ibuf++) {
/* 28 */       ByteBuffer bb = newByteBuffer(capacity);
/* 29 */       bb.put(capacity / 2, data);
/* 30 */       bb.put(capacity - 1, data);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static ByteBuffer newByteBuffer(int capacity) {
/* 37 */     ByteBuffer bb = null;
/*    */     try {
/* 39 */       System.out.println("allocating " + capacity + " bytes");
/* 40 */       bb = ByteBuffer.allocateDirect(capacity).order(ByteOrder.nativeOrder());
/* 41 */     } catch (OutOfMemoryError e1) {
/* 42 */       System.gc();
/* 43 */       System.out.println("attempted gc after exception: " + e1);
/* 44 */       System.out.println("now attempting to allocate again");
/*    */       try {
/* 46 */         bb = ByteBuffer.allocateDirect(capacity);
/* 47 */       } catch (OutOfMemoryError e2) {
/* 48 */         System.out.println("failed allocate after gc" + e2.getMessage());
/*    */       } 
/*    */     } 
/* 51 */     return bb;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/BufferBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */