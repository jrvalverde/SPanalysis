/*    */ package edu.mines.jtk.mosaic.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.mosaic.PlotFrame;
/*    */ import edu.mines.jtk.mosaic.PlotPanel;
/*    */ import edu.mines.jtk.mosaic.SequenceView;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceViewTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 24 */     int nx = 101;
/* 25 */     float dx = 0.1F;
/* 26 */     float fx = -0.5F * dx * (nx - 1);
/* 27 */     Sampling sx = new Sampling(nx, dx, fx);
/* 28 */     float[] f1 = Array.rampfloat(fx, dx, nx);
/* 29 */     float[] f2 = Array.add(0.5F, Array.sin(f1));
/*    */     
/* 31 */     PlotPanel panel = new PlotPanel(2, 1);
/*    */     
/* 33 */     SequenceView sv1 = panel.addSequence(0, 0, sx, f1);
/* 34 */     sv1.setColor(Color.RED);
/*    */     
/* 36 */     SequenceView sv2 = panel.addSequence(1, 0, sx, f2);
/* 37 */     sv2.setZero(SequenceView.Zero.MIDDLE);
/*    */     
/* 39 */     PlotFrame frame = new PlotFrame(panel);
/* 40 */     frame.setDefaultCloseOperation(3);
/* 41 */     frame.setSize(950, 500);
/* 42 */     frame.setVisible(true);
/* 43 */     frame.paintToPng(300.0D, 6.0D, "junk.png");
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/test/SequenceViewTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */