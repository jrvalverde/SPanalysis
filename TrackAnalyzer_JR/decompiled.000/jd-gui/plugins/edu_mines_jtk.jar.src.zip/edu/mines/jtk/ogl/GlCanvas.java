/*     */ package edu.mines.jtk.ogl;
/*     */ 
/*     */ import java.awt.GraphicsDevice;
/*     */ import javax.media.opengl.GLAutoDrawable;
/*     */ import javax.media.opengl.GLCanvas;
/*     */ import javax.media.opengl.GLCapabilities;
/*     */ import javax.media.opengl.GLCapabilitiesChooser;
/*     */ import javax.media.opengl.GLContext;
/*     */ import javax.media.opengl.GLEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlCanvas
/*     */   extends GLCanvas
/*     */   implements GLEventListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private boolean _autoRepaint;
/*     */   private Runnable _runnable;
/*     */   
/*     */   public GlCanvas() {
/*  28 */     addGLEventListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlCanvas(GLCapabilities capabilities) {
/*  35 */     super(capabilities);
/*  36 */     addGLEventListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GlCanvas(GLCapabilities capabilities, GLCapabilitiesChooser chooser, GLContext shareWith, GraphicsDevice device) {
/*  48 */     super(capabilities, chooser, shareWith, device);
/*  49 */     addGLEventListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRepaint(boolean autoRepaint) {
/*  60 */     this._autoRepaint = autoRepaint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runWithContext(Runnable runnable) {
/*  70 */     this._runnable = runnable;
/*     */     try {
/*  72 */       display();
/*     */     } finally {
/*  74 */       this._runnable = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glInit() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glResize(int x, int y, int width, int height) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void glPaint() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(GLAutoDrawable drawable) {
/* 119 */     glInit();
/*     */   }
/*     */   
/*     */   public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
/* 123 */     glResize(x, y, w, h);
/*     */   }
/*     */   
/*     */   public void display(GLAutoDrawable drawable) {
/* 127 */     if (this._runnable != null) {
/* 128 */       this._runnable.run();
/*     */     } else {
/* 130 */       glPaint();
/* 131 */       if (this._autoRepaint)
/* 132 */         repaint(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/GlCanvas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */