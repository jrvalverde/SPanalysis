/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Direct
/*     */ {
/*     */   public static ByteBuffer newByteBuffer(int capacity) {
/*  48 */     ByteBuffer b = null;
/*     */     try {
/*  50 */       b = ByteBuffer.allocateDirect(capacity);
/*  51 */     } catch (OutOfMemoryError e1) {
/*  52 */       System.gc();
/*     */       try {
/*  54 */         b = ByteBuffer.allocateDirect(capacity);
/*  55 */       } catch (OutOfMemoryError e2) {
/*  56 */         throw new OutOfMemoryError("cannot allocate direct buffer");
/*     */       } 
/*     */     } 
/*  59 */     b.order(ByteOrder.nativeOrder());
/*  60 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer newByteBuffer(byte[] a) {
/*  71 */     ByteBuffer b = newByteBuffer(a.length);
/*  72 */     b.put(a);
/*  73 */     b.flip();
/*  74 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DoubleBuffer newDoubleBuffer(int capacity) {
/*  83 */     return newByteBuffer(8 * capacity).asDoubleBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DoubleBuffer newDoubleBuffer(double[] a) {
/*  94 */     DoubleBuffer b = newDoubleBuffer(a.length);
/*  95 */     b.put(a);
/*  96 */     b.flip();
/*  97 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FloatBuffer newFloatBuffer(int capacity) {
/* 106 */     return newByteBuffer(4 * capacity).asFloatBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FloatBuffer newFloatBuffer(float[] a) {
/* 117 */     FloatBuffer b = newFloatBuffer(a.length);
/* 118 */     b.put(a);
/* 119 */     b.flip();
/* 120 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer newIntBuffer(int capacity) {
/* 129 */     return newByteBuffer(4 * capacity).asIntBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntBuffer newIntBuffer(int[] a) {
/* 140 */     IntBuffer b = newIntBuffer(a.length);
/* 141 */     b.put(a);
/* 142 */     b.flip();
/* 143 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongBuffer newLongBuffer(int capacity) {
/* 152 */     return newByteBuffer(8 * capacity).asLongBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongBuffer newLongBuffer(long[] a) {
/* 163 */     LongBuffer b = newLongBuffer(a.length);
/* 164 */     b.put(a);
/* 165 */     b.flip();
/* 166 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ShortBuffer newShortBuffer(int capacity) {
/* 175 */     return newByteBuffer(2 * capacity).asShortBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ShortBuffer newShortBuffer(short[] a) {
/* 186 */     ShortBuffer b = newShortBuffer(a.length);
/* 187 */     b.put(a);
/* 188 */     b.flip();
/* 189 */     return b;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Direct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */