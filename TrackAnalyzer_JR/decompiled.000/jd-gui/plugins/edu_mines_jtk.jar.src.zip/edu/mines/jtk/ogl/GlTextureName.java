/*    */ package edu.mines.jtk.ogl;
/*    */ 
/*    */ import edu.mines.jtk.util.Check;
/*    */ import javax.media.opengl.GLContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlTextureName
/*    */ {
/*    */   GLContext _context;
/*    */   int _name;
/*    */   
/*    */   public GlTextureName() {
/* 42 */     this._context = GLContext.getCurrent();
/* 43 */     Check.state((this._context != null), "OpenGL context is not null");
/* 44 */     int[] names = new int[1];
/* 45 */     Gl.glGenTextures(1, names, 0);
/* 46 */     this._name = names[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int name() {
/* 55 */     return this._name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void dispose() {
/* 64 */     if (this._context != null) {
/* 65 */       GLContext current = GLContext.getCurrent();
/* 66 */       if (this._context == current || this._context.makeCurrent() == 1) {
/*    */         
/*    */         try {
/*    */           
/* 70 */           int[] names = { this._name };
/* 71 */           Gl.glDeleteTextures(1, names, 0);
/*    */         } finally {
/* 73 */           if (this._context != current) {
/* 74 */             this._context.release();
/* 75 */             current.makeCurrent();
/*    */           } 
/*    */         } 
/*    */       }
/* 79 */       this._context = null;
/* 80 */       this._name = 0;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void finalize() throws Throwable {
/*    */     try {
/* 89 */       dispose();
/*    */     } finally {
/* 91 */       super.finalize();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/GlTextureName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */