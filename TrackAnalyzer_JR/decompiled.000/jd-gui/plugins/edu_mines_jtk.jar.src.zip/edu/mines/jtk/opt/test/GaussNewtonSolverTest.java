/*     */ package edu.mines.jtk.opt.test;
/*     */ import edu.mines.jtk.opt.ArrayVect1;
/*     */ import edu.mines.jtk.opt.GaussNewtonSolver;
/*     */ import edu.mines.jtk.opt.LinearTransform;
/*     */ import edu.mines.jtk.opt.LinearTransformWrapper;
/*     */ import edu.mines.jtk.opt.QuadraticSolver;
/*     */ import edu.mines.jtk.opt.Transform;
/*     */ import edu.mines.jtk.opt.Vect;
/*     */ import edu.mines.jtk.opt.VectConst;
/*     */ import edu.mines.jtk.opt.VectUtil;
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ public class GaussNewtonSolverTest extends TestCase {
/*  23 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   private static boolean printedUndisposed = false;
/*     */   private static boolean projectWasTested = false;
/*  26 */   private static final String NL = System.getProperty("line.separator");
/*     */   
/*     */   private static class TestVect
/*     */     extends ArrayVect1
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*  32 */     public static int max = 0;
/*     */     
/*  34 */     public static int total = 0;
/*     */     
/*  36 */     public static Map<Object, String> undisposed = Collections.synchronizedMap(new HashMap<Object, String>());
/*     */ 
/*     */ 
/*     */     
/*  40 */     public String identity = "default";
/*     */ 
/*     */     
/*     */     public void add(double scaleThis, double scaleOther, VectConst other) {
/*  44 */       assertSameType(other);
/*  45 */       super.add(scaleThis, scaleOther, other);
/*     */     }
/*     */     
/*     */     public void project(double scaleThis, double scaleOther, VectConst other) {
/*  49 */       TestVect tv = (TestVect)other;
/*  50 */       if (!this.identity.equals(tv.identity)) GaussNewtonSolverTest.projectWasTested = true; 
/*  51 */       super.add(scaleThis, scaleOther, other);
/*     */     }
/*     */     
/*     */     public double dot(VectConst other) {
/*  55 */       assertSameType(other);
/*  56 */       return super.dot(other);
/*     */     }
/*     */     
/*     */     private void assertSameType(VectConst other) {
/*  60 */       TestVect tv = (TestVect)other;
/*  61 */       if (!this.identity.equals(tv.identity)) {
/*  62 */         throw new IllegalArgumentException("different types");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TestVect(double[] data, double variance, String identity) {
/*  72 */       super(data, variance);
/*  73 */       this.identity = identity;
/*  74 */       remember(this);
/*     */     }
/*     */     
/*     */     public TestVect clone() {
/*  78 */       TestVect result = (TestVect)super.clone();
/*  79 */       remember(result);
/*  80 */       return result;
/*     */     }
/*     */     private void remember(Object tv) {
/*  83 */       synchronized (undisposed) {
/*  84 */         StringWriter sw = new StringWriter();
/*  85 */         PrintWriter pw = new PrintWriter(sw);
/*  86 */         (new Exception("This vector was never disposed")).printStackTrace(pw);
/*  87 */         pw.flush();
/*  88 */         undisposed.put(tv, sw.toString());
/*     */ 
/*     */         
/*  91 */         max = Math.max(max, undisposed.size());
/*  92 */         total++;
/*  93 */         if (undisposed.size() > 12 && !GaussNewtonSolverTest.printedUndisposed) {
/*  94 */           GaussNewtonSolverTest.LOG.severe("**********************************************");
/*  95 */           GaussNewtonSolverTest.LOG.severe(getTraces());
/*  96 */           GaussNewtonSolverTest.LOG.severe("**********************************************");
/*  97 */           GaussNewtonSolverTest.printedUndisposed = true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void dispose() {
/* 103 */       synchronized (undisposed) {
/* 104 */         super.dispose();
/* 105 */         undisposed.remove(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static String getTraces() {
/* 112 */       StringBuilder sb = new StringBuilder();
/* 113 */       for (String s : undisposed.values()) {
/* 114 */         sb.append(s);
/* 115 */         sb.append(GaussNewtonSolverTest.NL);
/*     */       } 
/* 117 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testMain() throws Exception {
/* 125 */     GaussNewtonSolver.setExpensiveDebug(true);
/*     */     
/* 127 */     final double[] coord = { 0.0D, 1.0D, 3.0D, 4.0D };
/* 128 */     TestVect data = new TestVect(new double[] { 0.0D, 8.0D, 8.0D, 20.0D }, 1.0E-4D, "data");
/*     */ 
/*     */ 
/*     */     
/* 132 */     LinearTransform linearTransform = new LinearTransform() {
/*     */         public void forward(Vect data1, VectConst model) {
/* 134 */           VectUtil.zero(data1);
/* 135 */           double[] d = ((ArrayVect1)data1).getData();
/* 136 */           double[] m = ((ArrayVect1)model).getData();
/* 137 */           for (int i = 0; i < coord.length; i++) {
/* 138 */             d[i] = d[i] + m[0];
/* 139 */             d[i] = d[i] + coord[i] * m[1];
/*     */           } 
/*     */         }
/*     */         public void addTranspose(VectConst data1, Vect model) {
/* 143 */           double[] d = ((ArrayVect1)data1).getData();
/* 144 */           double[] m = ((ArrayVect1)model).getData();
/* 145 */           for (int i = 0; i < coord.length; i++) {
/* 146 */             m[0] = m[0] + d[i];
/* 147 */             m[1] = m[1] + coord[i] * d[i];
/*     */           } 
/*     */         }
/*     */         
/*     */         public void inverseHessian(Vect model) {}
/*     */         
/*     */         public void adjustRobustErrors(Vect dataError) {}
/*     */       };
/* 155 */     TestVect model = new TestVect(new double[] { -1.0D, -1.0D }, 1.0D, "model");
/* 156 */     boolean dampOnlyPerturbation = false;
/* 157 */     int conjugateGradIterations = 2;
/* 158 */     ArrayVect1 result = (ArrayVect1)QuadraticSolver.solve((VectConst)data, (VectConst)model, linearTransform, dampOnlyPerturbation, conjugateGradIterations, null);
/*     */ 
/*     */     
/* 161 */     LOG.fine("data = " + data);
/* 162 */     LOG.fine("model = " + model);
/* 163 */     LOG.fine("result = " + result);
/*     */     
/* 165 */     assert (new Almost(4)).equal(1.0D, result.getData()[0]) : "result=" + result;
/* 166 */     assert (new Almost(5)).equal(4.0D, result.getData()[1]) : "result=" + result;
/*     */     
/* 168 */     model.dispose();
/* 169 */     result.dispose();
/*     */     
/* 171 */     double[] dampPerturb = null;
/*     */     
/* 173 */     TestVect testVect1 = new TestVect(new double[] { 0.9D, 3.9D }, 1.0D, "model");
/* 174 */     boolean bool1 = true;
/* 175 */     int j = 2;
/* 176 */     ArrayVect1 arrayVect11 = (ArrayVect1)QuadraticSolver.solve((VectConst)data, (VectConst)testVect1, linearTransform, bool1, j, null);
/*     */ 
/*     */     
/* 179 */     LOG.fine("data = " + data);
/* 180 */     LOG.fine("model = " + testVect1);
/* 181 */     LOG.fine("result = " + arrayVect11);
/*     */     
/* 183 */     dampPerturb = arrayVect11.getData();
/* 184 */     assert (new Almost(4)).equal(1.0D, arrayVect11.getData()[0]) : "result=" + arrayVect11;
/* 185 */     assert (new Almost(5)).equal(4.0D, arrayVect11.getData()[1]) : "result=" + arrayVect11;
/* 186 */     testVect1.dispose();
/* 187 */     arrayVect11.dispose();
/*     */ 
/*     */     
/* 190 */     testVect1 = new TestVect(new double[] { 0.9D, 3.9D }, 1.0D, "model");
/* 191 */     bool1 = false;
/* 192 */     j = 2;
/* 193 */     arrayVect11 = (ArrayVect1)QuadraticSolver.solve((VectConst)data, (VectConst)testVect1, linearTransform, bool1, j, null);
/*     */ 
/*     */     
/* 196 */     LOG.fine("data = " + data);
/* 197 */     LOG.fine("model = " + testVect1);
/* 198 */     LOG.fine("result = " + arrayVect11);
/*     */     
/* 200 */     double[] dampAll = arrayVect11.getData();
/* 201 */     assert (new Almost(4)).equal(1.0D, arrayVect11.getData()[0]) : "result=" + arrayVect11;
/* 202 */     assert (new Almost(5)).equal(4.0D, arrayVect11.getData()[1]) : "result=" + arrayVect11;
/* 203 */     assert dampAll[0] > dampPerturb[0];
/* 204 */     assert dampAll[1] < dampPerturb[1];
/*     */     
/* 206 */     double dampAll2 = 0.0D;
/* 207 */     double dampPerturb2 = 0.0D;
/* 208 */     for (int i = 0; i < 2; i++) {
/* 209 */       dampAll2 += dampAll[i] * dampAll[i];
/* 210 */       dampPerturb2 += dampPerturb[i] * dampPerturb[i];
/*     */     } 
/* 212 */     LOG.fine("dampAll2=" + dampAll2 + " dampPerturb2=" + dampPerturb2);
/* 213 */     assert dampAll2 < dampPerturb2;
/*     */     
/* 215 */     testVect1.dispose();
/* 216 */     arrayVect11.dispose();
/*     */     
/* 218 */     assert TestVect.max < 10 : "max=" + TestVect.max;
/*     */     
/* 220 */     for (int twice = 0; twice < 2; twice++) {
/* 221 */       boolean project = (twice == 1);
/* 222 */       TestVect perturb = new TestVect(new double[2], 1.0D, "perturb");
/*     */       
/* 224 */       TestVect testVect2 = new TestVect(new double[] { 0.9D, 3.9D }, 1.0D, "model");
/* 225 */       boolean bool2 = false;
/* 226 */       int linearizationIterations = 3;
/* 227 */       int lineSearchIterations = 20;
/* 228 */       double lineSearchError = 1.0E-6D;
/* 229 */       int k = 1;
/* 230 */       LinearTransformWrapper linearTransformWrapper2 = new LinearTransformWrapper(linearTransform);
/*     */       
/* 232 */       ArrayVect1 arrayVect1 = (ArrayVect1)GaussNewtonSolver.solve((VectConst)data, (VectConst)testVect2, project ? (VectConst)perturb : null, (Transform)linearTransformWrapper2, bool2, k, lineSearchIterations, linearizationIterations, lineSearchError, null);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       LOG.fine("data = " + data);
/* 238 */       LOG.fine("model = " + testVect2);
/* 239 */       LOG.fine("result = " + arrayVect1);
/* 240 */       assert (new Almost(3)).equal(1.0D, arrayVect1.getData()[0]) : "result=" + arrayVect1;
/* 241 */       assert (new Almost(4)).equal(4.0D, arrayVect1.getData()[1]) : "result=" + arrayVect1;
/* 242 */       testVect2.dispose();
/* 243 */       arrayVect1.dispose();
/*     */ 
/*     */       
/* 246 */       testVect2 = new TestVect(new double[] { 0.9D, 3.9D }, 1.0D, "model");
/* 247 */       bool2 = true;
/* 248 */       linearizationIterations = 3;
/* 249 */       lineSearchIterations = 30;
/* 250 */       lineSearchError = 1.0E-6D;
/* 251 */       k = 2;
/* 252 */       LinearTransformWrapper linearTransformWrapper1 = new LinearTransformWrapper(linearTransform);
/*     */       
/* 254 */       arrayVect1 = (ArrayVect1)GaussNewtonSolver.solve((VectConst)data, (VectConst)testVect2, project ? (VectConst)perturb : null, (Transform)linearTransformWrapper1, bool2, k, lineSearchIterations, linearizationIterations, lineSearchError, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 260 */       LOG.fine("data = " + data);
/* 261 */       LOG.fine("model = " + testVect2);
/* 262 */       LOG.fine("result = " + arrayVect1);
/*     */       
/* 264 */       assert (new Almost(4)).equal(1.0D, arrayVect1.getData()[0]) : "result=" + arrayVect1;
/* 265 */       assert (new Almost(5)).equal(4.0D, arrayVect1.getData()[1]) : "result=" + arrayVect1;
/* 266 */       testVect2.dispose();
/* 267 */       arrayVect1.dispose();
/*     */       
/* 269 */       perturb.dispose();
/*     */     } 
/* 271 */     data.dispose();
/*     */     
/* 273 */     if (TestVect.undisposed.size() > 0) {
/* 274 */       throw new IllegalStateException(TestVect.getTraces());
/*     */     }
/* 276 */     assert TestVect.max <= 10 : "max=" + TestVect.max;
/*     */     
/* 278 */     assert projectWasTested;
/*     */     
/* 280 */     GaussNewtonSolver.setExpensiveDebug(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {
/* 286 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/* 289 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussNewtonSolverTest(String name) {
/* 295 */     super(name);
/*     */   }
/*     */   public static Test suite() {
/*     */     try {
/*     */       assert false;
/* 300 */       throw new IllegalStateException("need -ea");
/* 301 */     } catch (AssertionError e) {
/* 302 */       return (Test)new TestSuite(GaussNewtonSolverTest.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 309 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/GaussNewtonSolverTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */