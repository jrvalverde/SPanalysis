/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point3
/*     */   extends Tuple3
/*     */ {
/*     */   public Point3() {}
/*     */   
/*     */   public Point3(double x, double y, double z) {
/*  29 */     super(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3(Point4 p) {
/*  38 */     super(p.x / p.w, p.y / p.w, p.z / p.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3(Point3 p) {
/*  46 */     super(p.x, p.y, p.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 plus(Vector3 v) {
/*  55 */     return new Point3(this.x + v.x, this.y + v.y, this.z + v.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 minus(Vector3 v) {
/*  64 */     return new Point3(this.x - v.x, this.y - v.y, this.z - v.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 minus(Point3 q) {
/*  73 */     return new Vector3(this.x - q.x, this.y - q.y, this.z - q.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 plusEquals(Vector3 v) {
/*  82 */     this.x += v.x;
/*  83 */     this.y += v.y;
/*  84 */     this.z += v.z;
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 minusEquals(Vector3 v) {
/*  94 */     this.x -= v.x;
/*  95 */     this.y -= v.y;
/*  96 */     this.z -= v.z;
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 affine(double a, Point3 q) {
/* 107 */     double b = 1.0D - a;
/* 108 */     Point3 p = this;
/* 109 */     return new Point3(b * p.x + a * q.x, b * p.y + a * q.y, b * p.z + a * q.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distanceTo(Point3 q) {
/* 118 */     double dx = this.x - q.x;
/* 119 */     double dy = this.y - q.y;
/* 120 */     double dz = this.z - q.z;
/* 121 */     return Math.sqrt(dx * dx + dy * dy + dz * dz);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Point3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */