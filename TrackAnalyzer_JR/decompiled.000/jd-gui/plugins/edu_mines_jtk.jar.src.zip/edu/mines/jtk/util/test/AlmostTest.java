/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AlmostTest
/*     */   extends TestCase
/*     */ {
/*     */   public void testEverything() {
/*  24 */     Almost a = new Almost();
/*     */ 
/*     */     
/*  27 */     assert a.between(1.0D, 0.0D, 2.0D);
/*  28 */     assert a.between(-1.0D, 0.0D, -2.0D);
/*  29 */     assert a.between(-1.0D, -0.5D, -2.0D);
/*  30 */     assert a.outside(1.0D, 0.0D, 2.0D) == 0;
/*  31 */     assert a.outside(1.0D, 0.5D, 2.0D) == 0;
/*  32 */     assert a.outside(-1.0D, 0.0D, -2.0D) == 0;
/*  33 */     assert a.outside(-1.0D, -0.5D, -2.0D) == 0;
/*  34 */     assert a.cmp(1.0D, 0.0D) > 0;
/*  35 */     assert a.cmp(0.0D, 1.0D) < 0;
/*  36 */     assert a.cmp(1.0D, 1.0D) == 0;
/*  37 */     assert a.cmp(0.0D, 0.0D) == 0;
/*  38 */     assert a.equal(3.0D, 3.0D);
/*  39 */     assert a.equal(0.0D, 0.0D);
/*  40 */     assert a.zero(0.0D);
/*     */ 
/*     */     
/*  43 */     assert a.zero(a.getMinValue() / 2.0D);
/*  44 */     assert !a.zero(a.getMinValue() * 2.0D);
/*  45 */     assert 1.0D != 1.0D + a.getEpsilon();
/*  46 */     assert 1.0D != 1.0D - a.getEpsilon();
/*  47 */     assert 0.0D != a.getMinValue();
/*  48 */     assert a.equal(1.0D, 1.0D + a.getEpsilon() / 2.0D);
/*  49 */     assert !a.equal(1.0D, 1.0D + a.getEpsilon() * 2.1D);
/*  50 */     assert a.equal(1.0D, 1.000000000001D);
/*  51 */     assert a.getMinValue() / 2.0D > 0.0D;
/*  52 */     assert a.equal(0.0D, a.getMinValue() / 2.0D);
/*  53 */     assert a.between(1.0D, 1.000000000001D, 2.0D);
/*  54 */     assert a.between(-1.0D, -1.000000000001D, -2.0D);
/*  55 */     assert a.outside(1.0D, 1.000000000001D, 2.0D) == 0;
/*  56 */     assert a.cmp(1.0D, 1.000000000001D) == 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testHashCode() {
/*  63 */     Almost a = new Almost(0.001D, 1.0E-6D);
/*  64 */     assert a.hashCodeOf(new Double(1.0E-8D), 100) == 0;
/*  65 */     assert a.hashCodeOf(new Double(0.99999999D), 100) == 1;
/*  66 */     assert a.hashCodeOf(new Double(1.00000001D), 100) == 1;
/*  67 */     assert a.hashCodeOf(new Long(123456789L), 100) == 123456789;
/*  68 */     assert a.hashCodeOf(new Double(3.1415D), 4) == a.hashCodeOf(new Double(3.1415926D), 4);
/*     */     
/*  70 */     assert a.hashCodeOf(new Double(3.1415D), 5) != a.hashCodeOf(new Double(3.1415926D), 5);
/*     */     
/*  72 */     assert a.hashCodeOf(new Double(-3.1415D), 4) == a.hashCodeOf(new Double(-3.1415926D), 4);
/*     */     
/*  74 */     assert a.hashCodeOf(new Double(-3.1415D), 5) != a.hashCodeOf(new Double(-3.1415926D), 5);
/*     */     
/*  76 */     assert a.hashCodeOf(new Double(314.15D), 4) == a.hashCodeOf(new Double(314.15926D), 4);
/*     */     
/*  78 */     assert a.hashCodeOf(new Double(314.15D), 5) != a.hashCodeOf(new Double(314.15926D), 5);
/*     */     
/*  80 */     assert a.hashCodeOf(new Double(-314.15D), 4) == a.hashCodeOf(new Double(-314.15926D), 4);
/*     */     
/*  82 */     assert a.hashCodeOf(new Double(-314.15D), 5) != a.hashCodeOf(new Double(-314.15926D), 5);
/*     */     
/*  84 */     assert a.hashCodeOf(new Double(0.0031415D), 4) == a.hashCodeOf(new Double(0.0031415926D), 4);
/*     */     
/*  86 */     assert a.hashCodeOf(new Double(0.0031415D), 5) != a.hashCodeOf(new Double(0.0031415926D), 5);
/*     */ 
/*     */ 
/*     */     
/*  90 */     a = new Almost(1.0E-4D);
/*  91 */     assert a.equal(0.0031415D, 0.0031415926D);
/*  92 */     assert a.hashCodeOf(new Double(0.0031415D)) == a.hashCodeOf(new Double(0.0031415926D));
/*     */ 
/*     */     
/*  95 */     a = new Almost(1.0E-5D);
/*  96 */     assert !a.equal(0.0031415D, 0.0031415926D);
/*  97 */     assert a.hashCodeOf(new Double(0.0031415D)) != a.hashCodeOf(new Double(0.0031415926D));
/*     */ 
/*     */     
/* 100 */     a = new Almost(4);
/* 101 */     assert a.equal(0.0031415D, 0.0031415926D);
/* 102 */     assert a.hashCodeOf(new Double(0.0031415D)) == a.hashCodeOf(new Double(0.0031415926D));
/*     */ 
/*     */     
/* 105 */     a = new Almost(5);
/* 106 */     assert !a.equal(0.0031415D, 0.0031415926D);
/* 107 */     assert a.hashCodeOf(new Double(0.0031415D)) != a.hashCodeOf(new Double(0.0031415926D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testNaNs() {
/*     */     try {
/* 116 */       Almost.FLOAT.equal(3.0D, Double.NaN); assert false;
/* 117 */     } catch (IllegalArgumentException e) {} try {
/* 118 */       Almost.FLOAT.equal(0.0D, Double.NaN); assert false;
/* 119 */     } catch (IllegalArgumentException e) {} try {
/* 120 */       Almost.FLOAT.equal(3.0D, Double.NaN); assert false;
/* 121 */     } catch (IllegalArgumentException e) {} try {
/* 122 */       Almost.FLOAT.equal(0.0D, Double.NaN); assert false;
/* 123 */     } catch (IllegalArgumentException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testAlmostObjectMethod() {
/* 130 */     Almost af1 = new Almost(1.1920928955078125E-6D, 1.401298464324817E-43D);
/* 131 */     Almost af2 = new Almost(1.1920928955078125E-6D);
/* 132 */     Almost af3 = new Almost();
/* 133 */     Almost ad = new Almost(2.220446049250313E-15D, 4.94E-322D);
/* 134 */     assert af1.equals(af2) : af1 + " " + af2;
/* 135 */     assert af1.equals(af3) : af1 + " " + af3;
/* 136 */     assert af2.equals(af3) : af2 + " " + af3;
/* 137 */     assert af1.hashCode() == af2.hashCode() : af1 + " " + af2;
/* 138 */     assert af1.hashCode() == af3.hashCode() : af1 + " " + af3;
/* 139 */     assert af2.hashCode() == af3.hashCode() : af2 + " " + af3;
/*     */     
/* 141 */     assert af1.toString().equals(af2.toString()) : af1.toString() + " " + af2.toString();
/*     */     
/* 143 */     assert af1.toString().equals(af3.toString()) : af1.toString() + " " + af3.toString();
/*     */     
/* 145 */     assert af2.toString().equals(af3.toString()) : af2.toString() + " " + af3.toString();
/* 146 */     for (Almost af : new Almost[] { af1, af2, af3 }) {
/* 147 */       assert !af.equals(ad);
/* 148 */       assert af.hashCode() != ad.hashCode();
/* 149 */       assert !af.toString().equals(ad.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {
/* 156 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/* 159 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AlmostTest(String name) {
/* 165 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Test suite() {
/* 170 */     return (Test)new TestSuite(AlmostTest.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 176 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/AlmostTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */