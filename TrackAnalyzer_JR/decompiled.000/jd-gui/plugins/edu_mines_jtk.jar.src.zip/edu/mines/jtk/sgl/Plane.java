/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Plane
/*     */ {
/*     */   private double _a;
/*     */   private double _b;
/*     */   private double _c;
/*     */   private double _d;
/*     */   
/*     */   public Plane(double a, double b, double c, double d) {
/*  31 */     set(a, b, c, d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Plane(Point3 p, Vector3 n) {
/*  42 */     set(n.x, n.y, n.z, -(n.x * p.x + n.y * p.y + n.z * p.z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Plane(Plane p) {
/*  50 */     this._a = p._a;
/*  51 */     this._b = p._b;
/*  52 */     this._c = p._c;
/*  53 */     this._d = p._d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(double a, double b, double c, double d) {
/*  64 */     this._a = a;
/*  65 */     this._b = b;
/*  66 */     this._c = c;
/*  67 */     this._d = d;
/*  68 */     normalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getA() {
/*  76 */     return this._a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getB() {
/*  84 */     return this._b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getC() {
/*  92 */     return this._c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getD() {
/* 100 */     return this._d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3 getNormal() {
/* 109 */     return new Vector3(this._a, this._b, this._c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distanceTo(double x, double y, double z) {
/* 122 */     return this._a * x + this._b * y + this._c * z + this._d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distanceTo(Point3 p) {
/* 133 */     return distanceTo(p.x, p.y, p.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(Matrix44 m) {
/* 151 */     transformWithInverse(m.inverse());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transformWithInverse(Matrix44 mi) {
/* 162 */     double[] m = mi.m;
/* 163 */     double a = m[0] * this._a + m[1] * this._b + m[2] * this._c + m[3] * this._d;
/* 164 */     double b = m[4] * this._a + m[5] * this._b + m[6] * this._c + m[7] * this._d;
/* 165 */     double c = m[8] * this._a + m[9] * this._b + m[10] * this._c + m[11] * this._d;
/* 166 */     double d = m[12] * this._a + m[13] * this._b + m[14] * this._c + m[15] * this._d;
/* 167 */     set(a, b, c, d);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 171 */     return "(" + this._a + "," + this._b + "," + this._c + "," + this._d + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Plane() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void normalize() {
/* 183 */     double s = 1.0D / Math.sqrt(this._a * this._a + this._b * this._b + this._c * this._c);
/* 184 */     this._a *= s;
/* 185 */     this._b *= s;
/* 186 */     this._c *= s;
/* 187 */     this._d *= s;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Plane.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */