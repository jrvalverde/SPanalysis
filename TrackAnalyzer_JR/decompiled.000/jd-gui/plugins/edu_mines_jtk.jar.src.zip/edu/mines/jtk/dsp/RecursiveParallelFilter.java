/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Cdouble;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecursiveParallelFilter
/*     */ {
/*     */   private int _np;
/*     */   private int _nz;
/*     */   private int _nc;
/*     */   private int _nr;
/*     */   private float _c;
/*     */   private float _g;
/*     */   private int _n1;
/*     */   private int _n2;
/*     */   private Recursive2ndOrderFilter[] _f1;
/*     */   private Recursive2ndOrderFilter[] _f2;
/*     */   
/*     */   public RecursiveParallelFilter(Cdouble[] poles, Cdouble[] zeros, double gain) {
/*  45 */     init(poles, zeros, gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForward(float[] x, float[] y) {
/*  56 */     scale(this._c, x, y);
/*  57 */     for (int i1 = 0; i1 < this._n1; i1++) {
/*  58 */       this._f1[i1].accumulateForward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyReverse(float[] x, float[] y) {
/*  69 */     scale(this._c, x, y);
/*  70 */     for (int i1 = 0; i1 < this._n1; i1++) {
/*  71 */       this._f1[i1].accumulateReverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForwardReverse(float[] x, float[] y) {
/*  85 */     scale(this._c * this._g, x, y);
/*  86 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/*  87 */       this._f2[i2].accumulateForward(x, y);
/*  88 */       this._f2[i2 + 1].accumulateReverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Forward(float[][] x, float[][] y) {
/* 100 */     scale(this._c, x, y);
/* 101 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 102 */       this._f1[i1].accumulate1Forward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Reverse(float[][] x, float[][] y) {
/* 113 */     scale(this._c, x, y);
/* 114 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 115 */       this._f1[i1].accumulate1Reverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1ForwardReverse(float[][] x, float[][] y) {
/* 127 */     scale(this._c * this._g, x, y);
/* 128 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 129 */       this._f2[i2].accumulate1Forward(x, y);
/* 130 */       this._f2[i2 + 1].accumulate1Reverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Forward(float[][] x, float[][] y) {
/* 142 */     scale(this._c, x, y);
/* 143 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 144 */       this._f1[i1].accumulate2Forward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Reverse(float[][] x, float[][] y) {
/* 155 */     scale(this._c, x, y);
/* 156 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 157 */       this._f1[i1].accumulate2Reverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2ForwardReverse(float[][] x, float[][] y) {
/* 169 */     scale(this._c * this._g, x, y);
/* 170 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 171 */       this._f2[i2].accumulate2Forward(x, y);
/* 172 */       this._f2[i2 + 1].accumulate2Reverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Forward(float[][][] x, float[][][] y) {
/* 184 */     scale(this._c, x, y);
/* 185 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 186 */       this._f1[i1].accumulate1Forward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Reverse(float[][][] x, float[][][] y) {
/* 197 */     scale(this._c, x, y);
/* 198 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 199 */       this._f1[i1].accumulate1Reverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1ForwardReverse(float[][][] x, float[][][] y) {
/* 211 */     scale(this._c * this._g, x, y);
/* 212 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 213 */       this._f2[i2].accumulate1Forward(x, y);
/* 214 */       this._f2[i2 + 1].accumulate1Reverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Forward(float[][][] x, float[][][] y) {
/* 226 */     scale(this._c, x, y);
/* 227 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 228 */       this._f1[i1].accumulate2Forward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Reverse(float[][][] x, float[][][] y) {
/* 239 */     scale(this._c, x, y);
/* 240 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 241 */       this._f1[i1].accumulate2Reverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2ForwardReverse(float[][][] x, float[][][] y) {
/* 253 */     scale(this._c * this._g, x, y);
/* 254 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 255 */       this._f2[i2].accumulate2Forward(x, y);
/* 256 */       this._f2[i2 + 1].accumulate2Reverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3Forward(float[][][] x, float[][][] y) {
/* 268 */     scale(this._c, x, y);
/* 269 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 270 */       this._f1[i1].accumulate3Forward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3Reverse(float[][][] x, float[][][] y) {
/* 281 */     scale(this._c, x, y);
/* 282 */     for (int i1 = 0; i1 < this._n1; i1++) {
/* 283 */       this._f1[i1].accumulate3Reverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3ForwardReverse(float[][][] x, float[][][] y) {
/* 295 */     scale(this._c * this._g, x, y);
/* 296 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 297 */       this._f2[i2].accumulate3Forward(x, y);
/* 298 */       this._f2[i2 + 1].accumulate3Reverse(x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyFrf(float[] x, float[] y) {
/* 306 */     scale(this._c * this._g, x, y);
/* 307 */     for (int i2 = 0; i2 < this._n2; i2 += 2) {
/* 308 */       this._f2[i2].accumulateForward(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyFrr(float[] x, float[] y) {
/* 317 */     scale(this._c * this._g, x, y);
/* 318 */     for (int i2 = 0; i2 < this._n2; i2 += 2)
/*     */     {
/* 320 */       this._f2[i2 + 1].accumulateReverse(x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RecursiveParallelFilter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(Cdouble[] poles, Cdouble[] zeros, double gain) {
/* 333 */     poles = nonZero(poles);
/* 334 */     zeros = nonZero(zeros);
/*     */ 
/*     */     
/* 337 */     Check.argument((zeros.length <= poles.length), "number of non-zero zeros does not exceed number of non-zero poles");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     Check.argument(polesUnique(poles), "all poles are unique");
/*     */ 
/*     */     
/* 345 */     this._np = poles.length;
/* 346 */     this._nz = zeros.length;
/*     */ 
/*     */     
/* 349 */     poles = sort(poles);
/* 350 */     zeros = sort(zeros);
/*     */ 
/*     */     
/* 353 */     this._nc = 0;
/* 354 */     this._nr = 0;
/* 355 */     for (int ip = 0; ip < this._np; ip++) {
/* 356 */       if ((poles[ip]).i != 0.0D) {
/* 357 */         this._nc++;
/*     */       } else {
/* 359 */         this._nr++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 366 */     this._n1 = this._nr + this._nc / 2;
/* 367 */     this._n2 = 2 * this._n1;
/* 368 */     this._f1 = new Recursive2ndOrderFilter[this._n1];
/* 369 */     this._f2 = new Recursive2ndOrderFilter[this._n2];
/* 370 */     double c = (this._nz == this._np) ? gain : 0.0D;
/* 371 */     for (int i1 = 0, i2 = 0, jp = 0; i1 < this._n1; jp++) {
/* 372 */       double fb0, fb1, fb2, rb0, rb1, rb2, b0, b1, b2, a1, a2; Cdouble pj = poles[jp];
/* 373 */       Cdouble hi = hi(pj, poles, zeros, gain);
/* 374 */       Cdouble hj = hr(pj, poles, zeros, gain);
/* 375 */       Cdouble hihj = hi.times(hj);
/*     */       
/* 377 */       if (pj.i == 0.0D) {
/* 378 */         a1 = -pj.r;
/* 379 */         a2 = 0.0D;
/* 380 */         b0 = hj.r;
/* 381 */         b1 = 0.0D;
/* 382 */         b2 = 0.0D;
/* 383 */         fb0 = hihj.r;
/* 384 */         fb1 = 0.0D;
/* 385 */         fb2 = 0.0D;
/* 386 */         rb0 = 0.0D;
/* 387 */         rb1 = -fb0 * a1;
/* 388 */         rb2 = 0.0D;
/*     */       } else {
/* 390 */         jp++;
/* 391 */         Cdouble qj = pj.inv();
/* 392 */         a1 = -2.0D * pj.r;
/* 393 */         a2 = pj.norm();
/* 394 */         b0 = hj.r - hj.i * qj.r / qj.i;
/* 395 */         b1 = hj.i / qj.i;
/* 396 */         b2 = 0.0D;
/* 397 */         fb0 = hihj.r - hihj.i * qj.r / qj.i;
/* 398 */         fb1 = hihj.i / qj.i;
/* 399 */         fb2 = 0.0D;
/* 400 */         rb0 = 0.0D;
/* 401 */         rb1 = fb1 - fb0 * a1;
/* 402 */         rb2 = -fb0 * a2;
/*     */       } 
/* 404 */       this._f1[i1++] = makeFilter(b0, b1, b2, a1, a2);
/* 405 */       this._f2[i2++] = makeFilter(fb0, fb1, fb2, a1, a2);
/* 406 */       this._f2[i2++] = makeFilter(rb0, rb1, rb2, a1, a2);
/* 407 */       if (this._nz == this._np)
/* 408 */         c -= b0; 
/*     */     } 
/* 410 */     this._c = (float)c;
/* 411 */     this._g = (float)gain;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Recursive2ndOrderFilter makeFilter(double b0, double b1, double b2, double a1, double a2) {
/* 416 */     return new Recursive2ndOrderFilter((float)b0, (float)b1, (float)b2, (float)a1, (float)a2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cdouble hi(Cdouble z, Cdouble[] poles, Cdouble[] zeros, double gain) {
/* 440 */     Cdouble c1 = new Cdouble(1.0D, 0.0D);
/* 441 */     Cdouble hz = new Cdouble(c1);
/* 442 */     for (int iz = 0; iz < this._nz; iz++) {
/* 443 */       Cdouble zi = zeros[iz];
/* 444 */       hz.timesEquals(c1.minus(zi.times(z)));
/*     */     } 
/* 446 */     Cdouble hp = new Cdouble(c1);
/* 447 */     for (int ip = 0; ip < this._np; ip++) {
/* 448 */       Cdouble pi = poles[ip];
/* 449 */       hp.timesEquals(c1.minus(pi.times(z)));
/*     */     } 
/* 451 */     return hz.over(hp).times(gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cdouble hr(Cdouble polej, Cdouble[] poles, Cdouble[] zeros, double gain) {
/* 464 */     Cdouble pj = polej;
/* 465 */     Cdouble qj = pj.inv();
/* 466 */     Cdouble c1 = new Cdouble(1.0D, 0.0D);
/* 467 */     Cdouble hz = new Cdouble(c1);
/* 468 */     for (int iz = 0; iz < this._nz; iz++) {
/* 469 */       Cdouble zi = zeros[iz];
/* 470 */       hz.timesEquals(c1.minus(zi.times(qj)));
/*     */     } 
/* 472 */     Cdouble hp = new Cdouble(c1);
/* 473 */     for (int ip = 0; ip < this._np; ip++) {
/* 474 */       Cdouble pi = poles[ip];
/* 475 */       if (!pi.equals(pj) && !pi.equals(pj.conj()))
/* 476 */         hp.timesEquals(c1.minus(pi.times(qj))); 
/*     */     } 
/* 478 */     return hz.over(hp).times(gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean polesUnique(Cdouble[] poles) {
/* 485 */     int np = poles.length;
/* 486 */     for (int ip = 0; ip < np; ip++) {
/* 487 */       Cdouble pi = poles[ip];
/* 488 */       for (int jp = ip + 1; jp < np; jp++) {
/* 489 */         Cdouble pj = poles[jp];
/* 490 */         if (pi.equals(pj))
/* 491 */           return false; 
/*     */       } 
/*     */     } 
/* 494 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Cdouble[] nonZero(Cdouble[] c) {
/* 501 */     int n = c.length;
/* 502 */     int m = 0;
/* 503 */     for (int i = 0; i < n; i++) {
/* 504 */       if ((c[i]).r != 0.0D || (c[i]).i != 0.0D)
/* 505 */         m++; 
/*     */     } 
/* 507 */     Cdouble[] d = new Cdouble[m];
/* 508 */     m = 0;
/* 509 */     for (int j = 0; j < n; j++) {
/* 510 */       if ((c[j]).r != 0.0D || (c[j]).i != 0.0D)
/* 511 */         d[j] = c[j]; 
/*     */     } 
/* 513 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Cdouble[] sort(Cdouble[] c) {
/* 523 */     int n = c.length;
/* 524 */     Cdouble[] cs = new Cdouble[n];
/* 525 */     int ns = 0; int i;
/* 526 */     for (i = 0; i < n; i++) {
/* 527 */       if (!c[i].isReal()) {
/* 528 */         Cdouble cc = c[i].conj();
/* 529 */         int j = 0;
/* 530 */         while (j < n && !cc.equals(c[j]))
/* 531 */           j++; 
/* 532 */         Check.argument((j < n), "complex " + c[i] + " has a conjugate mate");
/* 533 */         if (i < j) {
/* 534 */           cs[ns++] = c[i];
/* 535 */           cs[ns++] = c[j];
/*     */         } 
/*     */       } 
/*     */     } 
/* 539 */     for (i = 0; i < n; i++) {
/* 540 */       if (c[i].isReal())
/* 541 */         cs[ns++] = c[i]; 
/*     */     } 
/* 543 */     return cs;
/*     */   }
/*     */   
/*     */   private static void scale(float s, float[] x, float[] y) {
/* 547 */     int n1 = y.length;
/* 548 */     for (int i1 = 0; i1 < n1; i1++)
/* 549 */       y[i1] = s * x[i1]; 
/*     */   }
/*     */   
/*     */   private static void scale(float s, float[][] x, float[][] y) {
/* 553 */     int n2 = y.length;
/* 554 */     int n1 = (y[0]).length;
/* 555 */     for (int i2 = 0; i2 < n2; i2++) {
/* 556 */       float[] x2 = x[i2];
/* 557 */       float[] y2 = y[i2];
/* 558 */       for (int i1 = 0; i1 < n1; i1++)
/* 559 */         y2[i1] = s * x2[i1]; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void scale(float s, float[][][] x, float[][][] y) {
/* 564 */     int n3 = y.length;
/* 565 */     int n2 = (y[0]).length;
/* 566 */     int n1 = (y[0][0]).length;
/* 567 */     for (int i3 = 0; i3 < n3; i3++) {
/* 568 */       float[][] x3 = x[i3];
/* 569 */       float[][] y3 = y[i3];
/* 570 */       for (int i2 = 0; i2 < n2; i2++) {
/* 571 */         float[] x32 = x3[i2];
/* 572 */         float[] y32 = y3[i2];
/* 573 */         for (int i1 = 0; i1 < n1; i1++)
/* 574 */           y32[i1] = s * x32[i1]; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/RecursiveParallelFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */