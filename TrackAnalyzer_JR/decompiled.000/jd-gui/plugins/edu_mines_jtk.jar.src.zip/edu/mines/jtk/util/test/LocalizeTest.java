/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Localize;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalizeTest
/*     */   extends TestCase
/*     */ {
/*     */   public void testAll() throws Exception {
/*  23 */     long seconds = 569L;
/*  24 */     String words = Localize.timeWords(seconds);
/*  25 */     assert words.equals("9 minutes 29 seconds") : words;
/*     */ 
/*     */     
/*  28 */     seconds = 629L;
/*  29 */     words = Localize.timeWords(seconds);
/*  30 */     assert words.equals("10 minutes") : words;
/*     */ 
/*     */     
/*  33 */     seconds = 630L;
/*  34 */     words = Localize.timeWords(seconds);
/*  35 */     assert words.equals("11 minutes") : words;
/*     */ 
/*     */     
/*  38 */     seconds = 34169L;
/*  39 */     words = Localize.timeWords(seconds);
/*  40 */     assert words.equals("9 hours 29 minutes") : words;
/*     */ 
/*     */     
/*  43 */     seconds = 34230L;
/*  44 */     words = Localize.timeWords(seconds);
/*  45 */     assert words.equals("9 hours 31 minutes") : words;
/*     */ 
/*     */     
/*  48 */     seconds = 37830L;
/*  49 */     words = Localize.timeWords(seconds);
/*  50 */     assert words.equals("11 hours") : words;
/*     */ 
/*     */     
/*  53 */     seconds = 819030L;
/*  54 */     words = Localize.timeWords(seconds);
/*  55 */     assert words.equals("9 days 12 hours") : words;
/*     */ 
/*     */     
/*  58 */     seconds = 905430L;
/*  59 */     words = Localize.timeWords(seconds);
/*  60 */     assert words.equals("10 days") : words;
/*     */ 
/*     */     
/*  63 */     seconds = 907200L;
/*  64 */     words = Localize.timeWords(seconds);
/*  65 */     assert words.equals("11 days") : words;
/*     */ 
/*     */ 
/*     */     
/*  69 */     seconds = 7200L;
/*  70 */     words = Localize.timeWords(seconds);
/*  71 */     assert words.equals("2 hours") : words;
/*     */ 
/*     */ 
/*     */     
/*  75 */     seconds = 7199L;
/*  76 */     words = Localize.timeWords(seconds);
/*  77 */     assert words.equals("2 hours") : words;
/*     */ 
/*     */ 
/*     */     
/*  81 */     seconds = 172800L;
/*  82 */     words = Localize.timeWords(seconds);
/*  83 */     assert words.equals("2 days") : words;
/*     */ 
/*     */ 
/*     */     
/*  87 */     seconds = 172799L;
/*  88 */     words = Localize.timeWords(seconds);
/*  89 */     assert words.equals("2 days") : words;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {
/*  96 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/*  99 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalizeTest(String name) {
/* 106 */     super(name);
/*     */   }
/*     */   
/*     */   public static Test suite() {
/*     */     try {
/*     */       assert false;
/* 112 */       throw new IllegalStateException("need -ea");
/* 113 */     } catch (AssertionError e) {
/* 114 */       return (Test)new TestSuite(LocalizeTest.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 121 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/LocalizeTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */