/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoxConstraint
/*     */ {
/*     */   private double _xmin;
/*     */   private double _ymin;
/*     */   private double _zmin;
/*     */   private double _xmax;
/*     */   private double _ymax;
/*     */   private double _zmax;
/*     */   private double _dxmin;
/*     */   private double _dymin;
/*     */   private double _dzmin;
/*     */   private Sampling _sx;
/*     */   private Sampling _sy;
/*     */   private Sampling _sz;
/*     */   private boolean _sampled;
/*     */   
/*     */   public BoxConstraint(BoundingBox box) {
/*  27 */     this(box.getMin(), box.getMax(), 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxConstraint(BoundingBox box, double dxmin, double dymin, double dzmin) {
/*  41 */     this(box.getMin(), box.getMax(), dxmin, dymin, dzmin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxConstraint(Point3 p, Point3 q) {
/*  51 */     this(p, q, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxConstraint(Point3 p, Point3 q, double dxmin, double dymin, double dzmin) {
/*  66 */     this._xmin = Math.min(p.x, q.x);
/*  67 */     this._ymin = Math.min(p.y, q.y);
/*  68 */     this._zmin = Math.min(p.z, q.z);
/*  69 */     this._xmax = Math.max(p.x, q.x);
/*  70 */     this._ymax = Math.max(p.y, q.y);
/*  71 */     this._zmax = Math.max(p.z, q.z);
/*  72 */     this._dxmin = dxmin;
/*  73 */     this._dymin = dymin;
/*  74 */     this._dzmin = dzmin;
/*  75 */     this._sampled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxConstraint(Sampling sx, Sampling sy, Sampling sz) {
/*  86 */     this(sx, sy, sz, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxConstraint(Sampling sx, Sampling sy, Sampling sz, double dxmin, double dymin, double dzmin) {
/* 103 */     this._xmin = sx.getFirst();
/* 104 */     this._ymin = sy.getFirst();
/* 105 */     this._zmin = sz.getFirst();
/* 106 */     this._xmax = sx.getLast();
/* 107 */     this._ymax = sy.getLast();
/* 108 */     this._zmax = sz.getLast();
/* 109 */     this._dxmin = dxmin;
/* 110 */     this._dymin = dymin;
/* 111 */     this._dzmin = dzmin;
/* 112 */     this._sx = sx;
/* 113 */     this._sy = sy;
/* 114 */     this._sz = sz;
/* 115 */     this._sampled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox getBoundingBox() {
/* 123 */     return new BoundingBox(this._xmin, this._ymin, this._zmin, this._xmax, this._ymax, this._zmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingSphere getBoundingSphere() {
/* 131 */     BoundingSphere bs = new BoundingSphere();
/* 132 */     bs.expandBy(getBoundingBox());
/* 133 */     return bs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPoint(Point3 p) {
/* 142 */     return (this._xmin <= p.x && p.x <= this._xmax && this._ymin <= p.y && p.y <= this._ymax && this._zmin <= p.z && p.z <= this._zmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void constrainPoint(Point3 p) {
/* 152 */     p.x = Math.max(this._xmin, Math.min(this._xmax, p.x));
/* 153 */     p.y = Math.max(this._ymin, Math.min(this._ymax, p.y));
/* 154 */     p.z = Math.max(this._zmin, Math.min(this._zmax, p.z));
/* 155 */     if (this._sampled) {
/* 156 */       p.x = this._sx.valueOfNearest(p.x);
/* 157 */       p.y = this._sy.valueOfNearest(p.y);
/* 158 */       p.z = this._sz.valueOfNearest(p.z);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void constrainBox(Point3 p, Point3 q) {
/* 169 */     double ax = Math.min(p.x, q.x);
/* 170 */     double bx = Math.max(p.x, q.x);
/* 171 */     double dx = Math.max(bx - ax, this._dxmin);
/* 172 */     if (p.x <= q.x) {
/* 173 */       ax = Math.max(this._xmin, Math.min(this._xmax, ax));
/* 174 */       bx = Math.min(this._xmax, ax + dx);
/* 175 */       ax = Math.max(this._xmin, bx - dx);
/*     */     } else {
/* 177 */       bx = Math.min(this._xmax, Math.max(this._xmin, bx));
/* 178 */       ax = Math.max(this._xmin, bx - dx);
/* 179 */       bx = Math.min(this._xmax, ax + dx);
/*     */     } 
/* 181 */     if (this._sampled) {
/* 182 */       ax = this._sx.valueOfNearest(ax);
/* 183 */       bx = this._sx.valueOfNearest(bx);
/*     */     } 
/* 185 */     if (p.x <= q.x) {
/* 186 */       p.x = ax;
/* 187 */       q.x = bx;
/*     */     } else {
/* 189 */       p.x = bx;
/* 190 */       q.x = ax;
/*     */     } 
/* 192 */     double ay = Math.min(p.y, q.y);
/* 193 */     double by = Math.max(p.y, q.y);
/* 194 */     double dy = Math.max(by - ay, this._dymin);
/* 195 */     if (p.y <= q.y) {
/* 196 */       ay = Math.max(this._ymin, Math.min(this._ymax, ay));
/* 197 */       by = Math.min(this._ymax, ay + dy);
/* 198 */       ay = Math.max(this._ymin, by - dy);
/*     */     } else {
/* 200 */       by = Math.min(this._ymax, Math.max(this._ymin, by));
/* 201 */       ay = Math.max(this._ymin, by - dy);
/* 202 */       by = Math.min(this._ymax, ay + dy);
/*     */     } 
/* 204 */     if (this._sampled) {
/* 205 */       ay = this._sy.valueOfNearest(ay);
/* 206 */       by = this._sy.valueOfNearest(by);
/*     */     } 
/* 208 */     if (p.y <= q.y) {
/* 209 */       p.y = ay;
/* 210 */       q.y = by;
/*     */     } else {
/* 212 */       p.y = by;
/* 213 */       q.y = ay;
/*     */     } 
/* 215 */     double az = Math.min(p.z, q.z);
/* 216 */     double bz = Math.max(p.z, q.z);
/* 217 */     double dz = Math.max(bz - az, this._dzmin);
/* 218 */     if (p.z <= q.z) {
/* 219 */       az = Math.max(this._zmin, Math.min(this._zmax, az));
/* 220 */       bz = Math.min(this._zmax, az + dz);
/* 221 */       az = Math.max(this._zmin, bz - dz);
/*     */     } else {
/* 223 */       bz = Math.min(this._zmax, Math.max(this._zmin, bz));
/* 224 */       az = Math.max(this._zmin, bz - dz);
/* 225 */       bz = Math.min(this._zmax, az + dz);
/*     */     } 
/* 227 */     if (this._sampled) {
/* 228 */       az = this._sz.valueOfNearest(az);
/* 229 */       bz = this._sz.valueOfNearest(bz);
/*     */     } 
/* 231 */     if (p.z <= q.z) {
/* 232 */       p.z = az;
/* 233 */       q.z = bz;
/*     */     } else {
/* 235 */       p.z = bz;
/* 236 */       q.z = az;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/BoxConstraint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */