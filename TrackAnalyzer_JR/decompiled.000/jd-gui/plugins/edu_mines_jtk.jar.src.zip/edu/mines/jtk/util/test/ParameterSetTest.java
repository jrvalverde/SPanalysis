/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.Parameter;
/*     */ import edu.mines.jtk.util.ParameterSet;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterSetTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  25 */     TestSuite suite = new TestSuite(ParameterSetTest.class);
/*  26 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testClone() {
/*  30 */     ParameterSet root = new ParameterSet("root");
/*  31 */     String s1 = root.toString();
/*  32 */     ParameterSet foo = root.addParameterSet("foo");
/*  33 */     foo.addParameter("bar");
/*  34 */     ParameterSet temp = (ParameterSet)root.clone();
/*  35 */     temp.remove("foo");
/*  36 */     root.replaceWith(temp);
/*  37 */     String s2 = root.toString();
/*  38 */     assertTrue(s1.equals(s2));
/*     */   }
/*     */   
/*     */   public void testSpecialCharacters() {
/*  42 */     ParameterSet root = new ParameterSet("foo<&>\"'\\ bar");
/*  43 */     Parameter foo = root.addParameter("foo");
/*  44 */     String[] sa = { "foo", "foo<&>\"'\\ bar", "foo\nbar", "foo\\nbar", "foo\tbar", "foo\\tbar", "foo\"bar", "foo\\", "foo \\" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     foo.setStrings(sa);
/*  56 */     String s1 = root.toString();
/*     */     
/*  58 */     root.fromString(s1);
/*  59 */     String s2 = root.toString();
/*     */     
/*  61 */     assertTrue(s1.equals(s2));
/*  62 */     foo = root.getParameter("foo");
/*  63 */     String[] sb = foo.getStrings();
/*  64 */     assertTrue((sa.length == sb.length));
/*  65 */     for (int i = 0; i < sa.length; i++) {
/*  66 */       assertTrue(sa[i].equals(sb[i]));
/*     */     }
/*     */   }
/*     */   
/*     */   public void testGeneral() {
/*  71 */     ParameterSet psroot = new ParameterSet();
/*     */     
/*  73 */     ParameterSet ss1 = psroot.addParameterSet("ss1");
/*  74 */     Parameter pb1 = ss1.addParameter("pb1");
/*  75 */     pb1.setBoolean(true);
/*  76 */     Parameter pi1 = ss1.addParameter("pi1");
/*  77 */     pi1.setInt(1);
/*  78 */     Parameter pf1 = ss1.addParameter("pf1");
/*  79 */     pf1.setFloat(1.0F);
/*  80 */     Parameter pd1 = ss1.addParameter("pd1");
/*  81 */     pd1.setDouble(1.0D);
/*  82 */     Parameter ps1 = ss1.addParameter("ps1");
/*  83 */     ps1.setString("1.0");
/*     */     
/*  85 */     ParameterSet ss2 = ss1.copyTo(psroot, "ss2");
/*  86 */     ss1.remove();
/*  87 */     ss2.moveTo(psroot, "ss1");
/*     */     
/*  89 */     ss1 = psroot.getParameterSet("ss1");
/*  90 */     ss1.setName("ss2");
/*  91 */     ss2 = psroot.getParameterSet("ss2");
/*  92 */     ss2.setName("ss1");
/*  93 */     ss1 = psroot.getParameterSet("ss1");
/*     */     
/*  95 */     Parameter pfind = ss1.getParameter("ps1");
/*  96 */     assertTrue((pfind != null));
/*  97 */     pfind = ss1.getParameter("foo");
/*  98 */     assertTrue((pfind == null));
/*     */     
/* 100 */     boolean b1 = ss1.getParameter("pb1").getBoolean();
/* 101 */     assertTrue((b1 == true));
/* 102 */     int i1 = ss1.getParameter("pi1").getInt();
/* 103 */     assertTrue((i1 == 1));
/* 104 */     float f1 = ss1.getParameter("pf1").getFloat();
/* 105 */     assertTrue((f1 == 1.0F));
/* 106 */     double d1 = ss1.getParameter("pd1").getDouble();
/* 107 */     assertTrue((d1 == 1.0D));
/* 108 */     String s1 = ss1.getParameter("ps1").getString();
/* 109 */     assertTrue(s1.equals("1.0"));
/*     */     
/* 111 */     String str1 = psroot.toString();
/*     */     
/* 113 */     psroot.fromString(str1);
/* 114 */     String str2 = psroot.toString();
/*     */     
/* 116 */     assertTrue(str1.equals(str2));
/*     */     
/* 118 */     ParameterSet psrootClone = (ParameterSet)psroot.clone();
/* 119 */     assertTrue(psroot.equals(psrootClone));
/* 120 */     assertTrue((psroot.hashCode() == psrootClone.hashCode()));
/*     */   }
/*     */   
/*     */   public void testSetGet() {
/* 124 */     ParameterSet ps = new ParameterSet();
/*     */     
/* 126 */     ps.setBoolean("pb", true);
/* 127 */     ps.setInt("pi", 1);
/* 128 */     ps.setLong("pl", 1L);
/* 129 */     ps.setFloat("pf", 1.0F);
/* 130 */     ps.setDouble("pd", 1.0D);
/* 131 */     ps.setString("ps", "1.0");
/*     */     
/* 133 */     boolean b = ps.getBoolean("pb", false);
/* 134 */     assertTrue((b == true));
/* 135 */     int i = ps.getInt("pi", 0);
/* 136 */     assertTrue((i == 1));
/* 137 */     long l = ps.getLong("pl", 0L);
/* 138 */     assertTrue((l == 1L));
/* 139 */     float f = ps.getFloat("pf", 0.0F);
/* 140 */     assertTrue((f == 1.0F));
/* 141 */     double d = ps.getDouble("pd", 0.0D);
/* 142 */     assertTrue((d == 1.0D));
/* 143 */     String s = ps.getString("ps", "0.0");
/* 144 */     assertTrue(s.equals("1.0"));
/*     */     
/* 146 */     b = ps.getBoolean("qb", false);
/* 147 */     assertTrue(!b);
/* 148 */     i = ps.getInt("qi", 0);
/* 149 */     assertTrue((i == 0));
/* 150 */     l = ps.getLong("ql", 0L);
/* 151 */     assertTrue((l == 0L));
/* 152 */     f = ps.getFloat("qf", 0.0F);
/* 153 */     assertTrue((f == 0.0F));
/* 154 */     d = ps.getDouble("qd", 0.0D);
/* 155 */     assertTrue((d == 0.0D));
/* 156 */     s = ps.getString("qs", "0.0");
/* 157 */     assertTrue(s.equals("0.0"));
/*     */   }
/*     */   
/*     */   public void disable_testFile() {
/* 161 */     FileReader file = null;
/*     */     try {
/* 163 */       file = new FileReader("Input_Display.pwflow");
/*     */     }
/* 165 */     catch (FileNotFoundException e) {
/* 166 */       System.out.println("ParameterSet.testFile: FileNotFoundException: " + e.getMessage());
/*     */ 
/*     */       
/* 169 */       assertTrue(false);
/*     */     } 
/* 171 */     BufferedReader input = new BufferedReader(file);
/* 172 */     StringBuffer buffer = new StringBuffer();
/*     */     try {
/*     */       String s;
/* 175 */       while ((s = input.readLine()) != null) {
/* 176 */         buffer.append(s);
/* 177 */         buffer.append('\n');
/*     */       } 
/* 179 */       input.close();
/* 180 */     } catch (IOException e) {
/* 181 */       System.out.println("ParameterSet.testFile: IOException: " + e.getMessage());
/*     */       
/* 183 */       assertTrue(false);
/*     */     } 
/* 185 */     ParameterSet parset = new ParameterSet();
/* 186 */     parset.fromString(buffer.toString());
/* 187 */     System.out.println("parset read from file:\n" + parset.toString());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/ParameterSetTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */