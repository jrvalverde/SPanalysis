/*     */ package edu.mines.jtk.sgl.test;
/*     */ 
/*     */ import edu.mines.jtk.sgl.Matrix44;
/*     */ import edu.mines.jtk.sgl.Point3;
/*     */ import edu.mines.jtk.sgl.Point4;
/*     */ import edu.mines.jtk.sgl.Tuple3;
/*     */ import edu.mines.jtk.sgl.Tuple4;
/*     */ import edu.mines.jtk.sgl.Vector3;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MatrixPointVectorTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  25 */     TestSuite suite = new TestSuite(MatrixPointVectorTest.class);
/*  26 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testMatrix() {
/*  30 */     int ntrial = 10;
/*  31 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*  32 */       Matrix44 i = Matrix44.identity();
/*  33 */       Matrix44 a = randomMatrix44();
/*     */       
/*  35 */       Matrix44 at = a.transpose();
/*  36 */       assertEquals(a, at.transpose());
/*     */       
/*  38 */       Matrix44 ai = a.inverse();
/*  39 */       assertEquals(a, ai.inverse());
/*     */       
/*  41 */       assertEquals(i, a.times(ai));
/*  42 */       assertEquals(i, a.transpose().timesTranspose(ai));
/*  43 */       assertEquals(i, a.transposeTimes(ai.transpose()));
/*     */       
/*  45 */       Matrix44 ac = new Matrix44(a);
/*  46 */       assertEquals(i, ac.timesEquals(ai));
/*  47 */       ac = new Matrix44(a);
/*  48 */       assertEquals(i, ac.transposeEquals().timesTranspose(ai));
/*  49 */       ac = new Matrix44(a);
/*  50 */       assertEquals(i, ac.transposeTimesEquals(ai.transpose()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testVector() {
/*  55 */     int ntrial = 10;
/*  56 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*  57 */       Vector3 u = randomVector3();
/*  58 */       Vector3 v = randomVector3();
/*  59 */       Vector3 vc = new Vector3(v);
/*  60 */       assertEquals((Tuple3)v, (Tuple3)v.negate().negate());
/*  61 */       assertEquals((Tuple3)v, (Tuple3)vc.negateEquals().negateEquals());
/*  62 */       assertEquals(1.0D, v.normalize().length());
/*  63 */       assertEquals(1.0D, vc.normalizeEquals().length());
/*  64 */       assertEquals(1.0D, v.normalize().lengthSquared());
/*  65 */       assertEquals(v.dot(v), v.lengthSquared());
/*  66 */       assertEquals(0.0D, u.cross(v).dot(u));
/*  67 */       assertEquals(0.0D, u.cross(v).dot(v));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testPoint() {
/*  72 */     int ntrial = 10;
/*  73 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*  74 */       Point3 p = randomPoint3();
/*  75 */       Point3 pc = new Point3(p);
/*  76 */       Vector3 v = randomVector3();
/*  77 */       assertEquals((Tuple3)p, (Tuple3)p.plus(v).minus(v));
/*  78 */       assertEquals((Tuple3)p, (Tuple3)pc.plusEquals(v).minusEquals(v));
/*  79 */       Point3 q = p.minus(v);
/*  80 */       assertEquals(q.distanceTo(p), v.length());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testMatrixVector() {
/*  85 */     int ntrial = 10;
/*  86 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*  87 */       Vector3 v = randomVector3();
/*  88 */       Matrix44 a = randomMatrix33();
/*  89 */       Matrix44 ata = a.transposeTimes(a);
/*  90 */       assertEquals((Tuple3)ata.times(v), (Tuple3)a.transposeTimes(a.times(v)));
/*  91 */       Matrix44 aat = a.timesTranspose(a);
/*  92 */       assertEquals((Tuple3)aat.times(v), (Tuple3)a.times(a.transposeTimes(v)));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testMatrixPoint() {
/*  97 */     int ntrial = 10;
/*  98 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*     */       
/* 100 */       Matrix44 a = randomMatrix33();
/* 101 */       Matrix44 ata = a.transposeTimes(a);
/* 102 */       Matrix44 aat = a.timesTranspose(a);
/* 103 */       Point3 p3 = randomPoint3();
/* 104 */       assertEquals((Tuple3)ata.times(p3), (Tuple3)a.transposeTimes(a.times(p3)));
/* 105 */       assertEquals((Tuple3)aat.times(p3), (Tuple3)a.times(a.transposeTimes(p3)));
/* 106 */       a = randomMatrix44();
/* 107 */       ata = a.transposeTimes(a);
/* 108 */       aat = a.timesTranspose(a);
/* 109 */       Point4 p4 = randomPoint4();
/* 110 */       assertEquals((Tuple4)ata.times(p4), (Tuple4)a.transposeTimes(a.times(p4)));
/* 111 */       assertEquals((Tuple4)aat.times(p4), (Tuple4)a.times(a.transposeTimes(p4)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static Random _random = new Random(314159L);
/*     */ 
/*     */   
/*     */   private static final double TOLERANCE = 2.220446049250313E-14D;
/*     */ 
/*     */ 
/*     */   
/*     */   private static Matrix44 randomMatrix33() {
/* 126 */     double[] m = new double[16];
/* 127 */     for (int i = 0; i < 16; i++)
/* 128 */       m[i] = _random.nextDouble(); 
/* 129 */     m[0] = m[0] + 4.0D;
/* 130 */     m[5] = m[5] + 4.0D;
/* 131 */     m[10] = m[10] + 4.0D;
/* 132 */     m[12] = 0.0D; m[3] = 0.0D;
/* 133 */     m[13] = 0.0D; m[7] = 0.0D;
/* 134 */     m[14] = 0.0D; m[11] = 0.0D;
/* 135 */     m[15] = 1.0D;
/* 136 */     return new Matrix44(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Matrix44 randomMatrix44() {
/* 143 */     double[] m = new double[16];
/* 144 */     for (int i = 0; i < 16; i++)
/* 145 */       m[i] = _random.nextDouble(); 
/* 146 */     m[0] = m[0] + 4.0D;
/* 147 */     m[5] = m[5] + 4.0D;
/* 148 */     m[10] = m[10] + 4.0D;
/* 149 */     m[15] = m[15] + 4.0D;
/* 150 */     return new Matrix44(m);
/*     */   }
/*     */   
/*     */   private static Point3 randomPoint3() {
/* 154 */     double x = _random.nextDouble();
/* 155 */     double y = _random.nextDouble();
/* 156 */     double z = _random.nextDouble();
/* 157 */     return new Point3(x, y, z);
/*     */   }
/*     */   
/*     */   private static Vector3 randomVector3() {
/* 161 */     double x = _random.nextDouble();
/* 162 */     double y = _random.nextDouble();
/* 163 */     double z = _random.nextDouble();
/* 164 */     return new Vector3(x, y, z);
/*     */   }
/*     */   
/*     */   private static Point4 randomPoint4() {
/* 168 */     double x = _random.nextDouble();
/* 169 */     double y = _random.nextDouble();
/* 170 */     double z = _random.nextDouble();
/* 171 */     double w = _random.nextDouble();
/* 172 */     return new Point4(x, y, z, w);
/*     */   }
/*     */   
/*     */   private static void assertEquals(Matrix44 e, Matrix44 a) {
/* 176 */     double[] em = e.m;
/* 177 */     double[] am = a.m;
/* 178 */     for (int i = 0; i < 16; i++)
/* 179 */       assertEquals(em[i], am[i], 2.220446049250313E-14D); 
/*     */   }
/*     */   
/*     */   private static void assertEquals(Tuple3 e, Tuple3 a) {
/* 183 */     assertEquals(e.x, a.x, 2.220446049250313E-14D);
/* 184 */     assertEquals(e.y, a.y, 2.220446049250313E-14D);
/* 185 */     assertEquals(e.z, a.z, 2.220446049250313E-14D);
/*     */   }
/*     */   
/*     */   private static void assertEquals(Tuple4 e, Tuple4 a) {
/* 189 */     assertEquals(e.x, a.x, 2.220446049250313E-14D);
/* 190 */     assertEquals(e.y, a.y, 2.220446049250313E-14D);
/* 191 */     assertEquals(e.z, a.z, 2.220446049250313E-14D);
/* 192 */     assertEquals(e.w, a.w, 2.220446049250313E-14D);
/*     */   }
/*     */   
/*     */   private static void assertEquals(double e, double a) {
/* 196 */     assertEquals(e, a, 2.220446049250313E-14D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/MatrixPointVectorTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */