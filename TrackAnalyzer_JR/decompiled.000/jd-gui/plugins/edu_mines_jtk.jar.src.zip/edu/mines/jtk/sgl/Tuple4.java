/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tuple4
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   public double w;
/*    */   
/*    */   public Tuple4() {}
/*    */   
/*    */   public Tuple4(double x, double y, double z, double w) {
/* 50 */     this.x = x;
/* 51 */     this.y = y;
/* 52 */     this.z = z;
/* 53 */     this.w = w;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Tuple4(Tuple4 t) {
/* 61 */     this.x = t.x;
/* 62 */     this.y = t.y;
/* 63 */     this.z = t.z;
/* 64 */     this.w = t.w;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 68 */     if (this == obj)
/* 69 */       return true; 
/* 70 */     if (obj == null || getClass() != obj.getClass())
/* 71 */       return false; 
/* 72 */     Tuple4 that = (Tuple4)obj;
/* 73 */     return (this.x == that.x && this.y == that.y && this.z == that.z && this.w == that.w);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 80 */     long xbits = Double.doubleToLongBits(this.x);
/* 81 */     long ybits = Double.doubleToLongBits(this.y);
/* 82 */     long zbits = Double.doubleToLongBits(this.z);
/* 83 */     long wbits = Double.doubleToLongBits(this.w);
/* 84 */     return (int)(xbits ^ xbits >>> 32L ^ ybits ^ ybits >>> 32L ^ zbits ^ zbits >>> 32L ^ wbits ^ wbits >>> 32L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "(" + this.x + "," + this.y + "," + this.z + "," + this.w + ")";
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Tuple4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */