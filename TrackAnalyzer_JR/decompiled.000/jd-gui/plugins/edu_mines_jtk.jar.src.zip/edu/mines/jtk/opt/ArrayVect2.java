/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect2
/*     */   implements Vect
/*     */ {
/*  27 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*  31 */   private double[][] _data = (double[][])null;
/*     */ 
/*     */   
/*  34 */   private double _variance = 1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect2(double[][] data, double variance) {
/*  42 */     init(data, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(double[][] data, double variance) {
/*  54 */     this._data = data;
/*  55 */     this._variance = variance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[][] getData() {
/*  62 */     return this._data;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  67 */     return this._data.length * (this._data[0]).length;
/*     */   }
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/*  71 */     ArrayVect2 o = (ArrayVect2)other;
/*  72 */     for (int i = 0; i < this._data.length && this._data.length > 0; i++) {
/*  73 */       for (int j = 0; j < (this._data[0]).length; j++) {
/*  74 */         this._data[i][j] = scaleThis * this._data[i][j] + scaleOther * o._data[i][j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/*  81 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  86 */     this._data = (double[][])null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/*  91 */     double scale = Almost.FLOAT.divide(1.0D, getSize() * this._variance, 0.0D);
/*  92 */     VectUtil.scale(this, scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/*  97 */     return Almost.FLOAT.divide(dot(this), getSize() * this._variance, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {}
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public ArrayVect2 clone() {
/*     */     try {
/* 109 */       double[][] newData = new double[this._data.length][];
/* 110 */       for (int i = 0; i < newData.length; i++) {
/* 111 */         newData[i] = (double[])this._data[i].clone();
/*     */       }
/* 113 */       ArrayVect2 result = (ArrayVect2)super.clone();
/* 114 */       result.init(newData, this._variance);
/* 115 */       return result;
/* 116 */     } catch (CloneNotSupportedException ex) {
/* 117 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/* 118 */       e.initCause(ex);
/* 119 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/* 125 */     ArrayVect2 rhs = (ArrayVect2)other;
/* 126 */     double result = 0.0D;
/* 127 */     for (int i = 0; i < this._data.length; i++) {
/* 128 */       for (int j = 0; j < (this._data[0]).length; j++) {
/* 129 */         result += this._data[i][j] * rhs._data[i][j];
/*     */       }
/*     */     } 
/* 132 */     return result;
/*     */   }
/*     */   
/*     */   protected ArrayVect2() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */