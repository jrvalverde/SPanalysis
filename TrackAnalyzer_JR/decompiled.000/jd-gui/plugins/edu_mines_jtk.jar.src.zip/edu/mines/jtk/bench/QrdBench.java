/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import edu.mines.jtk.la.DMatrix;
/*    */ import edu.mines.jtk.la.DMatrixQrd;
/*    */ import edu.mines.jtk.lapack.DMatrix;
/*    */ import edu.mines.jtk.lapack.DMatrixQrd;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QrdBench
/*    */ {
/*    */   public static void main(String[] args) {
/* 20 */     double maxtime = 5.0D;
/* 21 */     int m = 100;
/* 22 */     int n = 5;
/* 23 */     int nrhs = 5;
/*    */ 
/*    */     
/* 26 */     DMatrix aj = DMatrix.random(m, n);
/*    */     
/* 28 */     DMatrix bj = DMatrix.random(m, nrhs);
/*    */ 
/*    */ 
/*    */     
/* 32 */     DMatrix al = new DMatrix(aj.get());
/*    */     
/* 34 */     DMatrix bl = new DMatrix(bj.get());
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     Stopwatch sw = new Stopwatch();
/*    */ 
/*    */     
/*    */     while (true) {
/* 43 */       DMatrixQrd qrdj = null;
/* 44 */       DMatrix xj = null;
/* 45 */       sw.restart(); int nqrd;
/* 46 */       for (nqrd = 0; sw.time() < maxtime; nqrd++) {
/* 47 */         qrdj = new DMatrixQrd(aj);
/* 48 */         xj = qrdj.solve(bj);
/*    */       } 
/* 50 */       sw.stop();
/* 51 */       double sum = Array.sum(xj.getArray());
/* 52 */       double rate = nqrd / sw.time();
/* 53 */       System.out.println("Pure Java: rate=" + rate + " sum=" + sum);
/*    */ 
/*    */       
/* 56 */       DMatrixQrd qrdl = null;
/* 57 */       DMatrix xl = null;
/* 58 */       sw.restart();
/* 59 */       for (nqrd = 0; sw.time() < maxtime; nqrd++) {
/* 60 */         qrdl = new DMatrixQrd(al);
/* 61 */         xl = qrdl.solve(bl);
/*    */       } 
/* 63 */       sw.stop();
/* 64 */       sum = Array.sum(xl.getArray());
/* 65 */       rate = nqrd / sw.time();
/* 66 */       System.out.println("   LAPACK: rate=" + rate + " sum=" + sum);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/QrdBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */