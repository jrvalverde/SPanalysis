/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayVect3f
/*     */   implements Vect
/*     */ {
/*  28 */   protected float[][][] _data = (float[][][])null;
/*     */ 
/*     */   
/*  31 */   protected double _variance = 1.0D;
/*     */ 
/*     */   
/*  34 */   private static final Logger LOG = Logger.getLogger("edu.mines.jtk.opt");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayVect3f(float[][][] data, double variance) {
/*  43 */     init(data, variance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getVariance() {
/*  50 */     return this._variance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(float[][][] data, double variance) {
/*  61 */     this._data = data;
/*  62 */     this._variance = variance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[][][] getData() {
/*  69 */     return this._data;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  75 */     return this._data.length * (this._data[0]).length * (this._data[0][0]).length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(double scaleThis, double scaleOther, VectConst other) {
/*  80 */     float s1 = (float)scaleThis;
/*  81 */     float s2 = (float)scaleOther;
/*  82 */     ArrayVect3f rhs = (ArrayVect3f)other;
/*  83 */     for (int i = 0; i < this._data.length; i++) {
/*  84 */       for (int j = 0; j < (this._data[0]).length; j++) {
/*  85 */         for (int k = 0; k < (this._data[0][0]).length; k++) {
/*  86 */           this._data[i][j][k] = s1 * this._data[i][j][k] + s2 * rhs._data[i][j][k];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void project(double scaleThis, double scaleOther, VectConst other) {
/*  94 */     add(scaleThis, scaleOther, other);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  99 */     this._data = (float[][][])null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void multiplyInverseCovariance() {
/* 104 */     double scale = Almost.FLOAT.divide(1.0D, getSize() * this._variance, 0.0D);
/* 105 */     VectUtil.scale(this, scale);
/*     */   }
/*     */ 
/*     */   
/*     */   public double magnitude() {
/* 110 */     return Almost.FLOAT.divide(dot(this), getSize() * this._variance, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void constrain() {}
/*     */ 
/*     */   
/*     */   public void postCondition() {}
/*     */ 
/*     */   
/*     */   public ArrayVect3f clone() {
/*     */     try {
/* 122 */       float[][][] newData = new float[this._data.length][(this._data[0]).length][];
/* 123 */       for (int i = 0; i < newData.length; i++) {
/* 124 */         for (int j = 0; j < (newData[0]).length; j++) {
/* 125 */           newData[i][j] = (float[])this._data[i][j].clone();
/*     */         }
/*     */       } 
/* 128 */       ArrayVect3f result = (ArrayVect3f)super.clone();
/* 129 */       result.init(newData, this._variance);
/* 130 */       return result;
/* 131 */     } catch (CloneNotSupportedException ex) {
/* 132 */       IllegalStateException e = new IllegalStateException(ex.getMessage());
/* 133 */       e.initCause(ex);
/* 134 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double dot(VectConst other) {
/* 140 */     double result = 0.0D;
/* 141 */     ArrayVect3f rhs = (ArrayVect3f)other;
/* 142 */     for (int i = 0; i < this._data.length; i++) {
/* 143 */       for (int j = 0; j < (this._data[0]).length; j++) {
/* 144 */         for (int k = 0; k < (this._data[0][0]).length; k++) {
/* 145 */           result += (this._data[i][j][k] * rhs._data[i][j][k]);
/*     */         }
/*     */       } 
/*     */     } 
/* 149 */     return result;
/*     */   }
/*     */   
/*     */   protected ArrayVect3f() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/ArrayVect3f.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */