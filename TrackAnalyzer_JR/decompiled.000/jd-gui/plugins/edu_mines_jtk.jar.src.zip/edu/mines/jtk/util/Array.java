/*       */ package edu.mines.jtk.util;
/*       */ 
/*       */ import java.util.Random;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ public class Array
/*       */ {
/*       */   public static byte[] zerobyte(int n1) {
/*    96 */     return new byte[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] zerobyte(int n1, int n2) {
/*   105 */     return new byte[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] zerobyte(int n1, int n2, int n3) {
/*   115 */     return new byte[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(byte[] rx) {
/*   123 */     int n1 = rx.length;
/*   124 */     for (int i1 = 0; i1 < n1; i1++) {
/*   125 */       rx[i1] = 0;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(byte[][] rx) {
/*   133 */     int n2 = rx.length;
/*   134 */     for (int i2 = 0; i2 < n2; i2++) {
/*   135 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(byte[][][] rx) {
/*   143 */     int n3 = rx.length;
/*   144 */     for (int i3 = 0; i3 < n3; i3++) {
/*   145 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] zeroshort(int n1) {
/*   153 */     return new short[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] zeroshort(int n1, int n2) {
/*   162 */     return new short[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] zeroshort(int n1, int n2, int n3) {
/*   172 */     return new short[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(short[] rx) {
/*   180 */     int n1 = rx.length;
/*   181 */     for (int i1 = 0; i1 < n1; i1++) {
/*   182 */       rx[i1] = 0;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(short[][] rx) {
/*   190 */     int n2 = rx.length;
/*   191 */     for (int i2 = 0; i2 < n2; i2++) {
/*   192 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(short[][][] rx) {
/*   200 */     int n3 = rx.length;
/*   201 */     for (int i3 = 0; i3 < n3; i3++) {
/*   202 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] zeroint(int n1) {
/*   210 */     return new int[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] zeroint(int n1, int n2) {
/*   219 */     return new int[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] zeroint(int n1, int n2, int n3) {
/*   229 */     return new int[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(int[] rx) {
/*   237 */     int n1 = rx.length;
/*   238 */     for (int i1 = 0; i1 < n1; i1++) {
/*   239 */       rx[i1] = 0;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(int[][] rx) {
/*   247 */     int n2 = rx.length;
/*   248 */     for (int i2 = 0; i2 < n2; i2++) {
/*   249 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(int[][][] rx) {
/*   257 */     int n3 = rx.length;
/*   258 */     for (int i3 = 0; i3 < n3; i3++) {
/*   259 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] zerolong(int n1) {
/*   267 */     return new long[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] zerolong(int n1, int n2) {
/*   276 */     return new long[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] zerolong(int n1, int n2, int n3) {
/*   286 */     return new long[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(long[] rx) {
/*   294 */     int n1 = rx.length;
/*   295 */     for (int i1 = 0; i1 < n1; i1++) {
/*   296 */       rx[i1] = 0L;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(long[][] rx) {
/*   304 */     int n2 = rx.length;
/*   305 */     for (int i2 = 0; i2 < n2; i2++) {
/*   306 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(long[][][] rx) {
/*   314 */     int n3 = rx.length;
/*   315 */     for (int i3 = 0; i3 < n3; i3++) {
/*   316 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] zerofloat(int n1) {
/*   324 */     return new float[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] zerofloat(int n1, int n2) {
/*   333 */     return new float[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] zerofloat(int n1, int n2, int n3) {
/*   343 */     return new float[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(float[] rx) {
/*   351 */     int n1 = rx.length;
/*   352 */     for (int i1 = 0; i1 < n1; i1++) {
/*   353 */       rx[i1] = 0.0F;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(float[][] rx) {
/*   361 */     int n2 = rx.length;
/*   362 */     for (int i2 = 0; i2 < n2; i2++) {
/*   363 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(float[][][] rx) {
/*   371 */     int n3 = rx.length;
/*   372 */     for (int i3 = 0; i3 < n3; i3++) {
/*   373 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] czerofloat(int n1) {
/*   381 */     return new float[2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] czerofloat(int n1, int n2) {
/*   390 */     return new float[n2][2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] czerofloat(int n1, int n2, int n3) {
/*   400 */     return new float[n3][n2][2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(float[] cx) {
/*   408 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(float[][] cx) {
/*   416 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(float[][][] cx) {
/*   424 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] zerodouble(int n1) {
/*   432 */     return new double[n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] zerodouble(int n1, int n2) {
/*   441 */     return new double[n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] zerodouble(int n1, int n2, int n3) {
/*   451 */     return new double[n3][n2][n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(double[] rx) {
/*   459 */     int n1 = rx.length;
/*   460 */     for (int i1 = 0; i1 < n1; i1++) {
/*   461 */       rx[i1] = 0.0D;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(double[][] rx) {
/*   469 */     int n2 = rx.length;
/*   470 */     for (int i2 = 0; i2 < n2; i2++) {
/*   471 */       zero(rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void zero(double[][][] rx) {
/*   479 */     int n3 = rx.length;
/*   480 */     for (int i3 = 0; i3 < n3; i3++) {
/*   481 */       zero(rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] czerodouble(int n1) {
/*   489 */     return new double[2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] czerodouble(int n1, int n2) {
/*   498 */     return new double[n2][2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] czerodouble(int n1, int n2, int n3) {
/*   508 */     return new double[n3][n2][2 * n1];
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(double[] cx) {
/*   516 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(double[][] cx) {
/*   524 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void czero(double[][][] cx) {
/*   532 */     zero(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] randint(int n1) {
/*   543 */     return randint(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] randint(int n1, int n2) {
/*   552 */     return randint(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] randint(int n1, int n2, int n3) {
/*   562 */     return randint(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] randint(Random random, int n1) {
/*   571 */     int[] rx = new int[n1];
/*   572 */     rand(random, rx);
/*   573 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] randint(Random random, int n1, int n2) {
/*   583 */     int[][] rx = new int[n2][n1];
/*   584 */     rand(random, rx);
/*   585 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] randint(Random random, int n1, int n2, int n3) {
/*   596 */     int[][][] rx = new int[n3][n2][n1];
/*   597 */     rand(random, rx);
/*   598 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(int[] rx) {
/*   606 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(int[][] rx) {
/*   614 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(int[][][] rx) {
/*   622 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, int[] rx) {
/*   631 */     int n1 = rx.length;
/*   632 */     for (int i1 = 0; i1 < n1; i1++) {
/*   633 */       rx[i1] = random.nextInt();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, int[][] rx) {
/*   642 */     int n2 = rx.length;
/*   643 */     for (int i2 = 0; i2 < n2; i2++) {
/*   644 */       rand(random, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, int[][][] rx) {
/*   653 */     int n3 = rx.length;
/*   654 */     for (int i3 = 0; i3 < n3; i3++) {
/*   655 */       rand(random, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] randlong(int n1) {
/*   663 */     return randlong(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] randlong(int n1, int n2) {
/*   672 */     return randlong(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] randlong(int n1, int n2, int n3) {
/*   682 */     return randlong(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] randlong(Random random, int n1) {
/*   691 */     long[] rx = new long[n1];
/*   692 */     rand(random, rx);
/*   693 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] randlong(Random random, int n1, int n2) {
/*   703 */     long[][] rx = new long[n2][n1];
/*   704 */     rand(random, rx);
/*   705 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] randlong(Random random, int n1, int n2, int n3) {
/*   716 */     long[][][] rx = new long[n3][n2][n1];
/*   717 */     rand(random, rx);
/*   718 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(long[] rx) {
/*   726 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(long[][] rx) {
/*   734 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(long[][][] rx) {
/*   742 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, long[] rx) {
/*   751 */     int n1 = rx.length;
/*   752 */     for (int i1 = 0; i1 < n1; i1++) {
/*   753 */       rx[i1] = random.nextLong();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, long[][] rx) {
/*   762 */     int n2 = rx.length;
/*   763 */     for (int i2 = 0; i2 < n2; i2++) {
/*   764 */       rand(random, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, long[][][] rx) {
/*   773 */     int n3 = rx.length;
/*   774 */     for (int i3 = 0; i3 < n3; i3++) {
/*   775 */       rand(random, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] randfloat(int n1) {
/*   783 */     return randfloat(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] randfloat(int n1, int n2) {
/*   792 */     return randfloat(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] randfloat(int n1, int n2, int n3) {
/*   802 */     return randfloat(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] randfloat(Random random, int n1) {
/*   811 */     float[] rx = new float[n1];
/*   812 */     rand(random, rx);
/*   813 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] randfloat(Random random, int n1, int n2) {
/*   823 */     float[][] rx = new float[n2][n1];
/*   824 */     rand(random, rx);
/*   825 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] randfloat(Random random, int n1, int n2, int n3) {
/*   836 */     float[][][] rx = new float[n3][n2][n1];
/*   837 */     rand(random, rx);
/*   838 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(float[] rx) {
/*   846 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(float[][] rx) {
/*   854 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(float[][][] rx) {
/*   862 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, float[] rx) {
/*   871 */     int n1 = rx.length;
/*   872 */     for (int i1 = 0; i1 < n1; i1++) {
/*   873 */       rx[i1] = random.nextFloat();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, float[][] rx) {
/*   882 */     int n2 = rx.length;
/*   883 */     for (int i2 = 0; i2 < n2; i2++) {
/*   884 */       rand(random, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, float[][][] rx) {
/*   893 */     int n3 = rx.length;
/*   894 */     for (int i3 = 0; i3 < n3; i3++) {
/*   895 */       rand(random, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] crandfloat(int n1) {
/*   903 */     return crandfloat(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] crandfloat(int n1, int n2) {
/*   912 */     return crandfloat(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] crandfloat(int n1, int n2, int n3) {
/*   922 */     return crandfloat(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] crandfloat(Random random, int n1) {
/*   931 */     float[] cx = new float[2 * n1];
/*   932 */     crand(random, cx);
/*   933 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] crandfloat(Random random, int n1, int n2) {
/*   943 */     float[][] cx = new float[n2][2 * n1];
/*   944 */     crand(random, cx);
/*   945 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] crandfloat(Random random, int n1, int n2, int n3) {
/*   956 */     float[][][] cx = new float[n3][n2][2 * n1];
/*   957 */     crand(random, cx);
/*   958 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(float[] cx) {
/*   966 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(float[][] cx) {
/*   974 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(float[][][] cx) {
/*   982 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, float[] cx) {
/*   991 */     rand(random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, float[][] cx) {
/*  1000 */     rand(random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, float[][][] cx) {
/*  1009 */     rand(random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] randdouble(int n1) {
/*  1017 */     return randdouble(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] randdouble(int n1, int n2) {
/*  1026 */     return randdouble(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] randdouble(int n1, int n2, int n3) {
/*  1036 */     return randdouble(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] randdouble(Random random, int n1) {
/*  1045 */     double[] rx = new double[n1];
/*  1046 */     rand(random, rx);
/*  1047 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] randdouble(Random random, int n1, int n2) {
/*  1057 */     double[][] rx = new double[n2][n1];
/*  1058 */     rand(random, rx);
/*  1059 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] randdouble(Random random, int n1, int n2, int n3) {
/*  1070 */     double[][][] rx = new double[n3][n2][n1];
/*  1071 */     rand(random, rx);
/*  1072 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(double[] rx) {
/*  1080 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(double[][] rx) {
/*  1088 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(double[][][] rx) {
/*  1096 */     rand(_random, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, double[] rx) {
/*  1105 */     int n1 = rx.length;
/*  1106 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1107 */       rx[i1] = random.nextDouble();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, double[][] rx) {
/*  1116 */     int n2 = rx.length;
/*  1117 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1118 */       rand(random, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void rand(Random random, double[][][] rx) {
/*  1127 */     int n3 = rx.length;
/*  1128 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1129 */       rand(random, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] cranddouble(int n1) {
/*  1137 */     return cranddouble(_random, n1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] cranddouble(int n1, int n2) {
/*  1146 */     return cranddouble(_random, n1, n2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] cranddouble(int n1, int n2, int n3) {
/*  1156 */     return cranddouble(_random, n1, n2, n3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] cranddouble(Random random, int n1) {
/*  1165 */     double[] cx = new double[2 * n1];
/*  1166 */     crand(random, cx);
/*  1167 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] cranddouble(Random random, int n1, int n2) {
/*  1177 */     double[][] cx = new double[n2][2 * n1];
/*  1178 */     crand(random, cx);
/*  1179 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] cranddouble(Random random, int n1, int n2, int n3) {
/*  1190 */     double[][][] cx = new double[n3][n2][2 * n1];
/*  1191 */     crand(random, cx);
/*  1192 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(double[] cx) {
/*  1200 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(double[][] cx) {
/*  1208 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(double[][][] cx) {
/*  1216 */     crand(_random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, double[] cx) {
/*  1225 */     rand(random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, double[][] cx) {
/*  1234 */     rand(random, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void crand(Random random, double[][][] cx) {
/*  1243 */     rand(random, cx);
/*       */   }
/*  1245 */   private static Random _random = new Random();
/*       */ 
/*       */   
/*       */   private static final int NSMALL_SORT = 7;
/*       */ 
/*       */   
/*       */   private static final int NLARGE_SORT = 40;
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] fillbyte(byte ra, int n1) {
/*  1256 */     byte[] rx = new byte[n1];
/*  1257 */     fill(ra, rx);
/*  1258 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] fillbyte(byte ra, int n1, int n2) {
/*  1268 */     byte[][] rx = new byte[n2][n1];
/*  1269 */     fill(ra, rx);
/*  1270 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] fillbyte(byte ra, int n1, int n2, int n3) {
/*  1281 */     byte[][][] rx = new byte[n3][n2][n1];
/*  1282 */     fill(ra, rx);
/*  1283 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(byte ra, byte[] rx) {
/*  1292 */     int n1 = rx.length;
/*  1293 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1294 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(byte ra, byte[][] rx) {
/*  1303 */     int n2 = rx.length;
/*  1304 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1305 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(byte ra, byte[][][] rx) {
/*  1314 */     int n3 = rx.length;
/*  1315 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1316 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] fillshort(short ra, int n1) {
/*  1325 */     short[] rx = new short[n1];
/*  1326 */     fill(ra, rx);
/*  1327 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] fillshort(short ra, int n1, int n2) {
/*  1337 */     short[][] rx = new short[n2][n1];
/*  1338 */     fill(ra, rx);
/*  1339 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] fillshort(short ra, int n1, int n2, int n3) {
/*  1350 */     short[][][] rx = new short[n3][n2][n1];
/*  1351 */     fill(ra, rx);
/*  1352 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(short ra, short[] rx) {
/*  1361 */     int n1 = rx.length;
/*  1362 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1363 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(short ra, short[][] rx) {
/*  1372 */     int n2 = rx.length;
/*  1373 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1374 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(short ra, short[][][] rx) {
/*  1383 */     int n3 = rx.length;
/*  1384 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1385 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] fillint(int ra, int n1) {
/*  1394 */     int[] rx = new int[n1];
/*  1395 */     fill(ra, rx);
/*  1396 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] fillint(int ra, int n1, int n2) {
/*  1406 */     int[][] rx = new int[n2][n1];
/*  1407 */     fill(ra, rx);
/*  1408 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] fillint(int ra, int n1, int n2, int n3) {
/*  1419 */     int[][][] rx = new int[n3][n2][n1];
/*  1420 */     fill(ra, rx);
/*  1421 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(int ra, int[] rx) {
/*  1430 */     int n1 = rx.length;
/*  1431 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1432 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(int ra, int[][] rx) {
/*  1441 */     int n2 = rx.length;
/*  1442 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1443 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(int ra, int[][][] rx) {
/*  1452 */     int n3 = rx.length;
/*  1453 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1454 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] filllong(long ra, int n1) {
/*  1463 */     long[] rx = new long[n1];
/*  1464 */     fill(ra, rx);
/*  1465 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] filllong(long ra, int n1, int n2) {
/*  1475 */     long[][] rx = new long[n2][n1];
/*  1476 */     fill(ra, rx);
/*  1477 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] filllong(long ra, int n1, int n2, int n3) {
/*  1488 */     long[][][] rx = new long[n3][n2][n1];
/*  1489 */     fill(ra, rx);
/*  1490 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(long ra, long[] rx) {
/*  1499 */     int n1 = rx.length;
/*  1500 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1501 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(long ra, long[][] rx) {
/*  1510 */     int n2 = rx.length;
/*  1511 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1512 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(long ra, long[][][] rx) {
/*  1521 */     int n3 = rx.length;
/*  1522 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1523 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] fillfloat(float ra, int n1) {
/*  1532 */     float[] rx = new float[n1];
/*  1533 */     fill(ra, rx);
/*  1534 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] fillfloat(float ra, int n1, int n2) {
/*  1544 */     float[][] rx = new float[n2][n1];
/*  1545 */     fill(ra, rx);
/*  1546 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] fillfloat(float ra, int n1, int n2, int n3) {
/*  1557 */     float[][][] rx = new float[n3][n2][n1];
/*  1558 */     fill(ra, rx);
/*  1559 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(float ra, float[] rx) {
/*  1568 */     int n1 = rx.length;
/*  1569 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1570 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(float ra, float[][] rx) {
/*  1579 */     int n2 = rx.length;
/*  1580 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1581 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(float ra, float[][][] rx) {
/*  1590 */     int n3 = rx.length;
/*  1591 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1592 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cfillfloat(Cfloat ca, int n1) {
/*  1601 */     float[] cx = new float[2 * n1];
/*  1602 */     cfill(ca, cx);
/*  1603 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] cfillfloat(Cfloat ca, int n1, int n2) {
/*  1613 */     float[][] cx = new float[n2][2 * n1];
/*  1614 */     cfill(ca, cx);
/*  1615 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] cfillfloat(Cfloat ca, int n1, int n2, int n3) {
/*  1626 */     float[][][] cx = new float[n3][n2][2 * n1];
/*  1627 */     cfill(ca, cx);
/*  1628 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cfloat ca, float[] cx) {
/*  1637 */     int n1 = cx.length / 2;
/*  1638 */     float ar = ca.r;
/*  1639 */     float ai = ca.i;
/*  1640 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/*  1641 */       cx[ir] = ar;
/*  1642 */       cx[ii] = ai;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cfloat ca, float[][] cx) {
/*  1652 */     int n2 = cx.length;
/*  1653 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1654 */       cfill(ca, cx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cfloat ca, float[][][] cx) {
/*  1663 */     int n3 = cx.length;
/*  1664 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1665 */       cfill(ca, cx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] filldouble(double ra, int n1) {
/*  1674 */     double[] rx = new double[n1];
/*  1675 */     fill(ra, rx);
/*  1676 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] filldouble(double ra, int n1, int n2) {
/*  1686 */     double[][] rx = new double[n2][n1];
/*  1687 */     fill(ra, rx);
/*  1688 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] filldouble(double ra, int n1, int n2, int n3) {
/*  1699 */     double[][][] rx = new double[n3][n2][n1];
/*  1700 */     fill(ra, rx);
/*  1701 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(double ra, double[] rx) {
/*  1710 */     int n1 = rx.length;
/*  1711 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1712 */       rx[i1] = ra;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(double ra, double[][] rx) {
/*  1721 */     int n2 = rx.length;
/*  1722 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1723 */       fill(ra, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void fill(double ra, double[][][] rx) {
/*  1732 */     int n3 = rx.length;
/*  1733 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1734 */       fill(ra, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] cfilldouble(Cdouble ca, int n1) {
/*  1743 */     double[] cx = new double[2 * n1];
/*  1744 */     cfill(ca, cx);
/*  1745 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] cfilldouble(Cdouble ca, int n1, int n2) {
/*  1755 */     double[][] cx = new double[n2][2 * n1];
/*  1756 */     cfill(ca, cx);
/*  1757 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] cfilldouble(Cdouble ca, int n1, int n2, int n3) {
/*  1768 */     double[][][] cx = new double[n3][n2][2 * n1];
/*  1769 */     cfill(ca, cx);
/*  1770 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cdouble ca, double[] cx) {
/*  1779 */     int n1 = cx.length / 2;
/*  1780 */     double ar = ca.r;
/*  1781 */     double ai = ca.i;
/*  1782 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/*  1783 */       cx[ir] = ar;
/*  1784 */       cx[ii] = ai;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cdouble ca, double[][] cx) {
/*  1794 */     int n2 = cx.length;
/*  1795 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1796 */       cfill(ca, cx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cfill(Cdouble ca, double[][][] cx) {
/*  1805 */     int n3 = cx.length;
/*  1806 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1807 */       cfill(ca, cx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] rampbyte(byte ra, byte rb1, int n1) {
/*  1821 */     byte[] rx = new byte[n1];
/*  1822 */     ramp(ra, rb1, rx);
/*  1823 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] rampbyte(byte ra, byte rb1, byte rb2, int n1, int n2) {
/*  1837 */     byte[][] rx = new byte[n2][n1];
/*  1838 */     ramp(ra, rb1, rb2, rx);
/*  1839 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] rampbyte(byte ra, byte rb1, byte rb2, byte rb3, int n1, int n2, int n3) {
/*  1855 */     byte[][][] rx = new byte[n3][n2][n1];
/*  1856 */     ramp(ra, rb1, rb2, rb3, rx);
/*  1857 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(byte ra, byte rb1, byte[] rx) {
/*  1868 */     int n1 = rx.length;
/*  1869 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1870 */       rx[i1] = (byte)(ra + rb1 * i1);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(byte ra, byte rb1, byte rb2, byte[][] rx) {
/*  1882 */     int n2 = rx.length;
/*  1883 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1884 */       ramp((byte)(ra + rb2 * i2), rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(byte ra, byte rb1, byte rb2, byte rb3, byte[][][] rx) {
/*  1898 */     int n3 = rx.length;
/*  1899 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1900 */       ramp((byte)(ra + rb3 * i3), rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] rampshort(short ra, short rb1, int n1) {
/*  1911 */     short[] rx = new short[n1];
/*  1912 */     ramp(ra, rb1, rx);
/*  1913 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] rampshort(short ra, short rb1, short rb2, int n1, int n2) {
/*  1927 */     short[][] rx = new short[n2][n1];
/*  1928 */     ramp(ra, rb1, rb2, rx);
/*  1929 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] rampshort(short ra, short rb1, short rb2, short rb3, int n1, int n2, int n3) {
/*  1945 */     short[][][] rx = new short[n3][n2][n1];
/*  1946 */     ramp(ra, rb1, rb2, rb3, rx);
/*  1947 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(short ra, short rb1, short[] rx) {
/*  1958 */     int n1 = rx.length;
/*  1959 */     for (int i1 = 0; i1 < n1; i1++) {
/*  1960 */       rx[i1] = (short)(ra + rb1 * i1);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(short ra, short rb1, short rb2, short[][] rx) {
/*  1972 */     int n2 = rx.length;
/*  1973 */     for (int i2 = 0; i2 < n2; i2++) {
/*  1974 */       ramp((short)(ra + rb2 * i2), rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(short ra, short rb1, short rb2, short rb3, short[][][] rx) {
/*  1988 */     int n3 = rx.length;
/*  1989 */     for (int i3 = 0; i3 < n3; i3++) {
/*  1990 */       ramp((short)(ra + rb3 * i3), rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] rampint(int ra, int rb1, int n1) {
/*  2001 */     int[] rx = new int[n1];
/*  2002 */     ramp(ra, rb1, rx);
/*  2003 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] rampint(int ra, int rb1, int rb2, int n1, int n2) {
/*  2017 */     int[][] rx = new int[n2][n1];
/*  2018 */     ramp(ra, rb1, rb2, rx);
/*  2019 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] rampint(int ra, int rb1, int rb2, int rb3, int n1, int n2, int n3) {
/*  2035 */     int[][][] rx = new int[n3][n2][n1];
/*  2036 */     ramp(ra, rb1, rb2, rb3, rx);
/*  2037 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(int ra, int rb1, int[] rx) {
/*  2048 */     int n1 = rx.length;
/*  2049 */     for (int i1 = 0; i1 < n1; i1++) {
/*  2050 */       rx[i1] = ra + rb1 * i1;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(int ra, int rb1, int rb2, int[][] rx) {
/*  2062 */     int n2 = rx.length;
/*  2063 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2064 */       ramp(ra + rb2 * i2, rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(int ra, int rb1, int rb2, int rb3, int[][][] rx) {
/*  2078 */     int n3 = rx.length;
/*  2079 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2080 */       ramp(ra + rb3 * i3, rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] ramplong(long ra, long rb1, int n1) {
/*  2091 */     long[] rx = new long[n1];
/*  2092 */     ramp(ra, rb1, rx);
/*  2093 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] ramplong(long ra, long rb1, long rb2, int n1, int n2) {
/*  2107 */     long[][] rx = new long[n2][n1];
/*  2108 */     ramp(ra, rb1, rb2, rx);
/*  2109 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] ramplong(long ra, long rb1, long rb2, long rb3, int n1, int n2, int n3) {
/*  2125 */     long[][][] rx = new long[n3][n2][n1];
/*  2126 */     ramp(ra, rb1, rb2, rb3, rx);
/*  2127 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(long ra, long rb1, long[] rx) {
/*  2138 */     int n1 = rx.length;
/*  2139 */     for (int i1 = 0; i1 < n1; i1++) {
/*  2140 */       rx[i1] = ra + rb1 * i1;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(long ra, long rb1, long rb2, long[][] rx) {
/*  2152 */     int n2 = rx.length;
/*  2153 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2154 */       ramp(ra + rb2 * i2, rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(long ra, long rb1, long rb2, long rb3, long[][][] rx) {
/*  2168 */     int n3 = rx.length;
/*  2169 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2170 */       ramp(ra + rb3 * i3, rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] rampfloat(float ra, float rb1, int n1) {
/*  2181 */     float[] rx = new float[n1];
/*  2182 */     ramp(ra, rb1, rx);
/*  2183 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] rampfloat(float ra, float rb1, float rb2, int n1, int n2) {
/*  2197 */     float[][] rx = new float[n2][n1];
/*  2198 */     ramp(ra, rb1, rb2, rx);
/*  2199 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] rampfloat(float ra, float rb1, float rb2, float rb3, int n1, int n2, int n3) {
/*  2215 */     float[][][] rx = new float[n3][n2][n1];
/*  2216 */     ramp(ra, rb1, rb2, rb3, rx);
/*  2217 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(float ra, float rb1, float[] rx) {
/*  2228 */     int n1 = rx.length;
/*  2229 */     for (int i1 = 0; i1 < n1; i1++) {
/*  2230 */       rx[i1] = ra + rb1 * i1;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(float ra, float rb1, float rb2, float[][] rx) {
/*  2242 */     int n2 = rx.length;
/*  2243 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2244 */       ramp(ra + rb2 * i2, rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(float ra, float rb1, float rb2, float rb3, float[][][] rx) {
/*  2258 */     int n3 = rx.length;
/*  2259 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2260 */       ramp(ra + rb3 * i3, rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] crampfloat(Cfloat ca, Cfloat cb1, int n1) {
/*  2271 */     float[] cx = new float[2 * n1];
/*  2272 */     cramp(ca, cb1, cx);
/*  2273 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] crampfloat(Cfloat ca, Cfloat cb1, Cfloat cb2, int n1, int n2) {
/*  2287 */     float[][] cx = new float[n2][2 * n1];
/*  2288 */     cramp(ca, cb1, cb2, cx);
/*  2289 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] crampfloat(Cfloat ca, Cfloat cb1, Cfloat cb2, Cfloat cb3, int n1, int n2, int n3) {
/*  2305 */     float[][][] cx = new float[n3][n2][2 * n1];
/*  2306 */     cramp(ca, cb1, cb2, cb3, cx);
/*  2307 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cfloat ca, Cfloat cb1, float[] cx) {
/*  2318 */     int n1 = cx.length / 2;
/*  2319 */     float ar = ca.r;
/*  2320 */     float ai = ca.i;
/*  2321 */     float br = cb1.r;
/*  2322 */     float bi = cb1.i;
/*  2323 */     for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/*  2324 */       cx[ir] = ar + br * i1;
/*  2325 */       cx[ii] = ai + bi * i1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cfloat ca, Cfloat cb1, Cfloat cb2, float[][] cx) {
/*  2338 */     int n2 = cx.length;
/*  2339 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2340 */       cramp(ca.plus(cb2.times(i2)), cb1, cx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cfloat ca, Cfloat cb1, Cfloat cb2, Cfloat cb3, float[][][] cx) {
/*  2354 */     int n3 = cx.length;
/*  2355 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2356 */       cramp(ca.plus(cb3.times(i3)), cb1, cb2, cx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] rampdouble(double ra, double rb1, int n1) {
/*  2367 */     double[] rx = new double[n1];
/*  2368 */     ramp(ra, rb1, rx);
/*  2369 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] rampdouble(double ra, double rb1, double rb2, int n1, int n2) {
/*  2383 */     double[][] rx = new double[n2][n1];
/*  2384 */     ramp(ra, rb1, rb2, rx);
/*  2385 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] rampdouble(double ra, double rb1, double rb2, double rb3, int n1, int n2, int n3) {
/*  2401 */     double[][][] rx = new double[n3][n2][n1];
/*  2402 */     ramp(ra, rb1, rb2, rb3, rx);
/*  2403 */     return rx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(double ra, double rb1, double[] rx) {
/*  2414 */     int n1 = rx.length;
/*  2415 */     for (int i1 = 0; i1 < n1; i1++) {
/*  2416 */       rx[i1] = ra + rb1 * i1;
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(double ra, double rb1, double rb2, double[][] rx) {
/*  2428 */     int n2 = rx.length;
/*  2429 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2430 */       ramp(ra + rb2 * i2, rb1, rx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ramp(double ra, double rb1, double rb2, double rb3, double[][][] rx) {
/*  2444 */     int n3 = rx.length;
/*  2445 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2446 */       ramp(ra + rb3 * i3, rb1, rb2, rx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] crampdouble(Cdouble ca, Cdouble cb1, int n1) {
/*  2457 */     double[] cx = new double[2 * n1];
/*  2458 */     cramp(ca, cb1, cx);
/*  2459 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] crampdouble(Cdouble ca, Cdouble cb1, Cdouble cb2, int n1, int n2) {
/*  2473 */     double[][] cx = new double[n2][2 * n1];
/*  2474 */     cramp(ca, cb1, cb2, cx);
/*  2475 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] crampdouble(Cdouble ca, Cdouble cb1, Cdouble cb2, Cdouble cb3, int n1, int n2, int n3) {
/*  2491 */     double[][][] cx = new double[n3][n2][2 * n1];
/*  2492 */     cramp(ca, cb1, cb2, cb3, cx);
/*  2493 */     return cx;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cdouble ca, Cdouble cb1, double[] cx) {
/*  2504 */     int n1 = cx.length / 2;
/*  2505 */     double ar = ca.r;
/*  2506 */     double ai = ca.i;
/*  2507 */     double br = cb1.r;
/*  2508 */     double bi = cb1.i;
/*  2509 */     for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/*  2510 */       cx[ir] = ar + br * i1;
/*  2511 */       cx[ii] = ai + bi * i1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cdouble ca, Cdouble cb1, Cdouble cb2, double[][] cx) {
/*  2524 */     int n2 = cx.length;
/*  2525 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2526 */       cramp(ca.plus(cb2.times(i2)), cb1, cx[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void cramp(Cdouble ca, Cdouble cb1, Cdouble cb2, Cdouble cb3, double[][][] cx) {
/*  2540 */     int n3 = cx.length;
/*  2541 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2542 */       cramp(ca.plus(cb3.times(i3)), cb1, cb2, cx[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] copy(byte[] rx) {
/*  2554 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] copy(byte[][] rx) {
/*  2563 */     int n2 = rx.length;
/*  2564 */     byte[][] ry = new byte[n2][];
/*  2565 */     for (int i2 = 0; i2 < n2; i2++)
/*  2566 */       ry[i2] = copy(rx[i2]); 
/*  2567 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] copy(byte[][][] rx) {
/*  2576 */     int n3 = rx.length;
/*  2577 */     byte[][][] ry = new byte[n3][][];
/*  2578 */     for (int i3 = 0; i3 < n3; i3++)
/*  2579 */       ry[i3] = copy(rx[i3]); 
/*  2580 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(byte[] rx, byte[] ry) {
/*  2589 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(byte[][] rx, byte[][] ry) {
/*  2598 */     int n2 = rx.length;
/*  2599 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2600 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(byte[][][] rx, byte[][][] ry) {
/*  2609 */     int n3 = rx.length;
/*  2610 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2611 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] copy(int n1, byte[] rx) {
/*  2621 */     byte[] ry = new byte[n1];
/*  2622 */     copy(n1, rx, ry);
/*  2623 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] copy(int n1, int n2, byte[][] rx) {
/*  2634 */     byte[][] ry = new byte[n2][n1];
/*  2635 */     copy(n1, n2, rx, ry);
/*  2636 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] copy(int n1, int n2, int n3, byte[][][] rx) {
/*  2648 */     byte[][][] ry = new byte[n3][n2][n1];
/*  2649 */     copy(n1, n2, n3, rx, ry);
/*  2650 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, byte[] rx, byte[] ry) {
/*  2660 */     for (int i1 = 0; i1 < n1; i1++) {
/*  2661 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, byte[][] rx, byte[][] ry) {
/*  2672 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2673 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, byte[][][] rx, byte[][][] ry) {
/*  2686 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2687 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] copy(int n1, int j1, byte[] rx) {
/*  2700 */     byte[] ry = new byte[n1];
/*  2701 */     copy(n1, j1, rx, 0, ry);
/*  2702 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] copy(int n1, int n2, int j1, int j2, byte[][] rx) {
/*  2717 */     byte[][] ry = new byte[n2][n1];
/*  2718 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  2719 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, byte[][][] rx) {
/*  2736 */     byte[][][] ry = new byte[n3][n2][n1];
/*  2737 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  2738 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] copy(int n1, int j1, int k1, byte[] rx) {
/*  2752 */     byte[] ry = new byte[n1];
/*  2753 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  2754 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, byte[][] rx) {
/*  2771 */     byte[][] ry = new byte[n2][n1];
/*  2772 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  2773 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, byte[][][] rx) {
/*  2793 */     byte[][][] ry = new byte[n3][n2][n1];
/*  2794 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  2795 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, byte[] rx, int j1y, byte[] ry) {
/*  2810 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  2811 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, byte[][] rx, int j1y, int j2y, byte[][] ry) {
/*  2829 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2830 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, byte[][][] rx, int j1y, int j2y, int j3y, byte[][][] ry) {
/*  2851 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2852 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, byte[] rx, int j1y, int k1y, byte[] ry) {
/*       */     int iy;
/*  2869 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  2870 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, byte[][] rx, int j1y, int j2y, int k1y, int k2y, byte[][] ry) {
/*  2892 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2893 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, byte[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, byte[][][] ry) {
/*  2920 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2921 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] copy(short[] rx) {
/*  2930 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] copy(short[][] rx) {
/*  2939 */     int n2 = rx.length;
/*  2940 */     short[][] ry = new short[n2][];
/*  2941 */     for (int i2 = 0; i2 < n2; i2++)
/*  2942 */       ry[i2] = copy(rx[i2]); 
/*  2943 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] copy(short[][][] rx) {
/*  2952 */     int n3 = rx.length;
/*  2953 */     short[][][] ry = new short[n3][][];
/*  2954 */     for (int i3 = 0; i3 < n3; i3++)
/*  2955 */       ry[i3] = copy(rx[i3]); 
/*  2956 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(short[] rx, short[] ry) {
/*  2965 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(short[][] rx, short[][] ry) {
/*  2974 */     int n2 = rx.length;
/*  2975 */     for (int i2 = 0; i2 < n2; i2++) {
/*  2976 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(short[][][] rx, short[][][] ry) {
/*  2985 */     int n3 = rx.length;
/*  2986 */     for (int i3 = 0; i3 < n3; i3++) {
/*  2987 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] copy(int n1, short[] rx) {
/*  2997 */     short[] ry = new short[n1];
/*  2998 */     copy(n1, rx, ry);
/*  2999 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] copy(int n1, int n2, short[][] rx) {
/*  3010 */     short[][] ry = new short[n2][n1];
/*  3011 */     copy(n1, n2, rx, ry);
/*  3012 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] copy(int n1, int n2, int n3, short[][][] rx) {
/*  3024 */     short[][][] ry = new short[n3][n2][n1];
/*  3025 */     copy(n1, n2, n3, rx, ry);
/*  3026 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, short[] rx, short[] ry) {
/*  3036 */     for (int i1 = 0; i1 < n1; i1++) {
/*  3037 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, short[][] rx, short[][] ry) {
/*  3048 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3049 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, short[][][] rx, short[][][] ry) {
/*  3062 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3063 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] copy(int n1, int j1, short[] rx) {
/*  3076 */     short[] ry = new short[n1];
/*  3077 */     copy(n1, j1, rx, 0, ry);
/*  3078 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] copy(int n1, int n2, int j1, int j2, short[][] rx) {
/*  3093 */     short[][] ry = new short[n2][n1];
/*  3094 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  3095 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, short[][][] rx) {
/*  3112 */     short[][][] ry = new short[n3][n2][n1];
/*  3113 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  3114 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] copy(int n1, int j1, int k1, short[] rx) {
/*  3128 */     short[] ry = new short[n1];
/*  3129 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  3130 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, short[][] rx) {
/*  3147 */     short[][] ry = new short[n2][n1];
/*  3148 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  3149 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, short[][][] rx) {
/*  3169 */     short[][][] ry = new short[n3][n2][n1];
/*  3170 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  3171 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, short[] rx, int j1y, short[] ry) {
/*  3186 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  3187 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, short[][] rx, int j1y, int j2y, short[][] ry) {
/*  3205 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3206 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, short[][][] rx, int j1y, int j2y, int j3y, short[][][] ry) {
/*  3227 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3228 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, short[] rx, int j1y, int k1y, short[] ry) {
/*       */     int iy;
/*  3245 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  3246 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, short[][] rx, int j1y, int j2y, int k1y, int k2y, short[][] ry) {
/*  3268 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3269 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, short[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, short[][][] ry) {
/*  3296 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3297 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] copy(int[] rx) {
/*  3306 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] copy(int[][] rx) {
/*  3315 */     int n2 = rx.length;
/*  3316 */     int[][] ry = new int[n2][];
/*  3317 */     for (int i2 = 0; i2 < n2; i2++)
/*  3318 */       ry[i2] = copy(rx[i2]); 
/*  3319 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] copy(int[][][] rx) {
/*  3328 */     int n3 = rx.length;
/*  3329 */     int[][][] ry = new int[n3][][];
/*  3330 */     for (int i3 = 0; i3 < n3; i3++)
/*  3331 */       ry[i3] = copy(rx[i3]); 
/*  3332 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int[] rx, int[] ry) {
/*  3341 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int[][] rx, int[][] ry) {
/*  3350 */     int n2 = rx.length;
/*  3351 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3352 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int[][][] rx, int[][][] ry) {
/*  3361 */     int n3 = rx.length;
/*  3362 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3363 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] copy(int n1, int[] rx) {
/*  3373 */     int[] ry = new int[n1];
/*  3374 */     copy(n1, rx, ry);
/*  3375 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] copy(int n1, int n2, int[][] rx) {
/*  3386 */     int[][] ry = new int[n2][n1];
/*  3387 */     copy(n1, n2, rx, ry);
/*  3388 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] copy(int n1, int n2, int n3, int[][][] rx) {
/*  3400 */     int[][][] ry = new int[n3][n2][n1];
/*  3401 */     copy(n1, n2, n3, rx, ry);
/*  3402 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int[] rx, int[] ry) {
/*  3412 */     for (int i1 = 0; i1 < n1; i1++) {
/*  3413 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int[][] rx, int[][] ry) {
/*  3424 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3425 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int[][][] rx, int[][][] ry) {
/*  3438 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3439 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] copy(int n1, int j1, int[] rx) {
/*  3452 */     int[] ry = new int[n1];
/*  3453 */     copy(n1, j1, rx, 0, ry);
/*  3454 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] copy(int n1, int n2, int j1, int j2, int[][] rx) {
/*  3469 */     int[][] ry = new int[n2][n1];
/*  3470 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  3471 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int[][][] rx) {
/*  3488 */     int[][][] ry = new int[n3][n2][n1];
/*  3489 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  3490 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] copy(int n1, int j1, int k1, int[] rx) {
/*  3504 */     int[] ry = new int[n1];
/*  3505 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  3506 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, int[][] rx) {
/*  3523 */     int[][] ry = new int[n2][n1];
/*  3524 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  3525 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, int[][][] rx) {
/*  3545 */     int[][][] ry = new int[n3][n2][n1];
/*  3546 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  3547 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int[] rx, int j1y, int[] ry) {
/*  3562 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  3563 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int[][] rx, int j1y, int j2y, int[][] ry) {
/*  3581 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3582 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int[][][] rx, int j1y, int j2y, int j3y, int[][][] ry) {
/*  3603 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3604 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, int[] rx, int j1y, int k1y, int[] ry) {
/*       */     int iy;
/*  3621 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  3622 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, int[][] rx, int j1y, int j2y, int k1y, int k2y, int[][] ry) {
/*  3644 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3645 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, int[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, int[][][] ry) {
/*  3672 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3673 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] copy(long[] rx) {
/*  3682 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] copy(long[][] rx) {
/*  3691 */     int n2 = rx.length;
/*  3692 */     long[][] ry = new long[n2][];
/*  3693 */     for (int i2 = 0; i2 < n2; i2++)
/*  3694 */       ry[i2] = copy(rx[i2]); 
/*  3695 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] copy(long[][][] rx) {
/*  3704 */     int n3 = rx.length;
/*  3705 */     long[][][] ry = new long[n3][][];
/*  3706 */     for (int i3 = 0; i3 < n3; i3++)
/*  3707 */       ry[i3] = copy(rx[i3]); 
/*  3708 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(long[] rx, long[] ry) {
/*  3717 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(long[][] rx, long[][] ry) {
/*  3726 */     int n2 = rx.length;
/*  3727 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3728 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(long[][][] rx, long[][][] ry) {
/*  3737 */     int n3 = rx.length;
/*  3738 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3739 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] copy(int n1, long[] rx) {
/*  3749 */     long[] ry = new long[n1];
/*  3750 */     copy(n1, rx, ry);
/*  3751 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] copy(int n1, int n2, long[][] rx) {
/*  3762 */     long[][] ry = new long[n2][n1];
/*  3763 */     copy(n1, n2, rx, ry);
/*  3764 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] copy(int n1, int n2, int n3, long[][][] rx) {
/*  3776 */     long[][][] ry = new long[n3][n2][n1];
/*  3777 */     copy(n1, n2, n3, rx, ry);
/*  3778 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, long[] rx, long[] ry) {
/*  3788 */     for (int i1 = 0; i1 < n1; i1++) {
/*  3789 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, long[][] rx, long[][] ry) {
/*  3800 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3801 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, long[][][] rx, long[][][] ry) {
/*  3814 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3815 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] copy(int n1, int j1, long[] rx) {
/*  3828 */     long[] ry = new long[n1];
/*  3829 */     copy(n1, j1, rx, 0, ry);
/*  3830 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] copy(int n1, int n2, int j1, int j2, long[][] rx) {
/*  3845 */     long[][] ry = new long[n2][n1];
/*  3846 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  3847 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, long[][][] rx) {
/*  3864 */     long[][][] ry = new long[n3][n2][n1];
/*  3865 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  3866 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] copy(int n1, int j1, int k1, long[] rx) {
/*  3880 */     long[] ry = new long[n1];
/*  3881 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  3882 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, long[][] rx) {
/*  3899 */     long[][] ry = new long[n2][n1];
/*  3900 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  3901 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, long[][][] rx) {
/*  3921 */     long[][][] ry = new long[n3][n2][n1];
/*  3922 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  3923 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, long[] rx, int j1y, long[] ry) {
/*  3938 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  3939 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, long[][] rx, int j1y, int j2y, long[][] ry) {
/*  3957 */     for (int i2 = 0; i2 < n2; i2++) {
/*  3958 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, long[][][] rx, int j1y, int j2y, int j3y, long[][][] ry) {
/*  3979 */     for (int i3 = 0; i3 < n3; i3++) {
/*  3980 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, long[] rx, int j1y, int k1y, long[] ry) {
/*       */     int iy;
/*  3997 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  3998 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, long[][] rx, int j1y, int j2y, int k1y, int k2y, long[][] ry) {
/*  4020 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4021 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, long[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, long[][][] ry) {
/*  4048 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4049 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] copy(float[] rx) {
/*  4058 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] copy(float[][] rx) {
/*  4067 */     int n2 = rx.length;
/*  4068 */     float[][] ry = new float[n2][];
/*  4069 */     for (int i2 = 0; i2 < n2; i2++)
/*  4070 */       ry[i2] = copy(rx[i2]); 
/*  4071 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] copy(float[][][] rx) {
/*  4080 */     int n3 = rx.length;
/*  4081 */     float[][][] ry = new float[n3][][];
/*  4082 */     for (int i3 = 0; i3 < n3; i3++)
/*  4083 */       ry[i3] = copy(rx[i3]); 
/*  4084 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(float[] rx, float[] ry) {
/*  4093 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(float[][] rx, float[][] ry) {
/*  4102 */     int n2 = rx.length;
/*  4103 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4104 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(float[][][] rx, float[][][] ry) {
/*  4113 */     int n3 = rx.length;
/*  4114 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4115 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] copy(int n1, float[] rx) {
/*  4125 */     float[] ry = new float[n1];
/*  4126 */     copy(n1, rx, ry);
/*  4127 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] copy(int n1, int n2, float[][] rx) {
/*  4138 */     float[][] ry = new float[n2][n1];
/*  4139 */     copy(n1, n2, rx, ry);
/*  4140 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] copy(int n1, int n2, int n3, float[][][] rx) {
/*  4152 */     float[][][] ry = new float[n3][n2][n1];
/*  4153 */     copy(n1, n2, n3, rx, ry);
/*  4154 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, float[] rx, float[] ry) {
/*  4164 */     for (int i1 = 0; i1 < n1; i1++) {
/*  4165 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, float[][] rx, float[][] ry) {
/*  4176 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4177 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, float[][][] rx, float[][][] ry) {
/*  4190 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4191 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] copy(int n1, int j1, float[] rx) {
/*  4204 */     float[] ry = new float[n1];
/*  4205 */     copy(n1, j1, rx, 0, ry);
/*  4206 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] copy(int n1, int n2, int j1, int j2, float[][] rx) {
/*  4221 */     float[][] ry = new float[n2][n1];
/*  4222 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  4223 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, float[][][] rx) {
/*  4240 */     float[][][] ry = new float[n3][n2][n1];
/*  4241 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  4242 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] copy(int n1, int j1, int k1, float[] rx) {
/*  4256 */     float[] ry = new float[n1];
/*  4257 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  4258 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, float[][] rx) {
/*  4275 */     float[][] ry = new float[n2][n1];
/*  4276 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  4277 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, float[][][] rx) {
/*  4297 */     float[][][] ry = new float[n3][n2][n1];
/*  4298 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  4299 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, float[] rx, int j1y, float[] ry) {
/*  4314 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  4315 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, float[][] rx, int j1y, int j2y, float[][] ry) {
/*  4333 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4334 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, float[][][] rx, int j1y, int j2y, int j3y, float[][][] ry) {
/*  4355 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4356 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, float[] rx, int j1y, int k1y, float[] ry) {
/*       */     int iy;
/*  4373 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  4374 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, float[][] rx, int j1y, int j2y, int k1y, int k2y, float[][] ry) {
/*  4396 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4397 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, float[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, float[][][] ry) {
/*  4424 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4425 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] ccopy(float[] cx) {
/*  4434 */     return ccopy(cx.length / 2, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] ccopy(float[][] cx) {
/*  4443 */     int n2 = cx.length;
/*  4444 */     float[][] cy = new float[n2][];
/*  4445 */     for (int i2 = 0; i2 < n2; i2++)
/*  4446 */       cy[i2] = ccopy(cx[i2]); 
/*  4447 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] ccopy(float[][][] cx) {
/*  4456 */     int n3 = cx.length;
/*  4457 */     float[][][] cy = new float[n3][][];
/*  4458 */     for (int i3 = 0; i3 < n3; i3++)
/*  4459 */       cy[i3] = ccopy(cx[i3]); 
/*  4460 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(float[] cx, float[] cy) {
/*  4469 */     ccopy(cx.length / 2, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(float[][] cx, float[][] cy) {
/*  4478 */     int n2 = cx.length;
/*  4479 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4480 */       ccopy(cx[i2], cy[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(float[][][] cx, float[][][] cy) {
/*  4489 */     int n3 = cx.length;
/*  4490 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4491 */       ccopy(cx[i3], cy[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] ccopy(int n1, float[] cx) {
/*  4501 */     float[] cy = new float[2 * n1];
/*  4502 */     ccopy(n1, cx, cy);
/*  4503 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] ccopy(int n1, int n2, float[][] cx) {
/*  4514 */     float[][] cy = new float[n2][2 * n1];
/*  4515 */     ccopy(n1, n2, cx, cy);
/*  4516 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] ccopy(int n1, int n2, int n3, float[][][] cx) {
/*  4528 */     float[][][] cy = new float[n3][n2][2 * n1];
/*  4529 */     ccopy(n1, n2, n3, cx, cy);
/*  4530 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, float[] cx, float[] cy) {
/*  4540 */     copy(2 * n1, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, float[][] cx, float[][] cy) {
/*  4551 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4552 */       ccopy(n1, cx[i2], cy[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, float[][][] cx, float[][][] cy) {
/*  4565 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4566 */       ccopy(n1, n2, cx[i3], cy[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] ccopy(int n1, int j1, float[] cx) {
/*  4579 */     float[] cy = new float[2 * n1];
/*  4580 */     ccopy(n1, j1, cx, 0, cy);
/*  4581 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] ccopy(int n1, int n2, int j1, int j2, float[][] cx) {
/*  4596 */     float[][] cy = new float[n2][2 * n1];
/*  4597 */     ccopy(n1, n2, j1, j2, cx, 0, 0, cy);
/*  4598 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] ccopy(int n1, int n2, int n3, int j1, int j2, int j3, float[][][] cx) {
/*  4615 */     float[][][] cy = new float[n3][n2][2 * n1];
/*  4616 */     ccopy(n1, n2, n3, j1, j2, j3, cx, 0, 0, 0, cy);
/*  4617 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] ccopy(int n1, int j1, int k1, float[] cx) {
/*  4631 */     float[] cy = new float[2 * n1];
/*  4632 */     ccopy(n1, j1, k1, cx, 0, 1, cy);
/*  4633 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] ccopy(int n1, int n2, int j1, int j2, int k1, int k2, float[][] cx) {
/*  4650 */     float[][] cy = new float[n2][2 * n1];
/*  4651 */     ccopy(n1, n2, j1, j2, k1, k2, cx, 0, 0, 1, 1, cy);
/*  4652 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] ccopy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, float[][][] cx) {
/*  4672 */     float[][][] cy = new float[n3][n2][2 * n1];
/*  4673 */     ccopy(n1, n2, n3, j1, j2, j3, k1, k2, k3, cx, 0, 0, 0, 1, 1, 1, cy);
/*  4674 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int j1x, float[] cx, int j1y, float[] cy) {
/*  4689 */     for (int i1 = 0, ix = 2 * j1x, iy = 2 * j1y; i1 < n1; i1++) {
/*  4690 */       cy[iy++] = cx[ix++];
/*  4691 */       cy[iy++] = cx[ix++];
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int j1x, int j2x, float[][] cx, int j1y, int j2y, float[][] cy) {
/*  4710 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4711 */       ccopy(n1, j1x, cx[j2x + i2], j1y, cy[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, int j1x, int j2x, int j3x, float[][][] cx, int j1y, int j2y, int j3y, float[][][] cy) {
/*  4732 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4733 */       ccopy(n1, n2, j1x, j2x, cx[j3x + i3], j1y, j2y, cy[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int j1x, int k1x, float[] cx, int j1y, int k1y, float[] cy) {
/*  4750 */     int k1x2 = k1x * 2;
/*  4751 */     int k1y2 = k1y * 2; int iy;
/*  4752 */     for (int i1 = 0, ix = 2 * j1x; i1 < n1; i1++, ix += k1x2, iy += k1y2) {
/*  4753 */       cy[iy] = cx[ix];
/*  4754 */       cy[iy + 1] = cx[ix + 1];
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, float[][] cx, int j1y, int j2y, int k1y, int k2y, float[][] cy) {
/*  4777 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4778 */       ccopy(n1, j1x, k1x, cx[j2x + i2 * k2x], j1y, k1y, cy[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, float[][][] cx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, float[][][] cy) {
/*  4805 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4806 */       ccopy(n1, n2, j1x, j2x, k1x, k2x, cx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, cy[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] copy(double[] rx) {
/*  4817 */     return copy(rx.length, rx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] copy(double[][] rx) {
/*  4826 */     int n2 = rx.length;
/*  4827 */     double[][] ry = new double[n2][];
/*  4828 */     for (int i2 = 0; i2 < n2; i2++)
/*  4829 */       ry[i2] = copy(rx[i2]); 
/*  4830 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] copy(double[][][] rx) {
/*  4839 */     int n3 = rx.length;
/*  4840 */     double[][][] ry = new double[n3][][];
/*  4841 */     for (int i3 = 0; i3 < n3; i3++)
/*  4842 */       ry[i3] = copy(rx[i3]); 
/*  4843 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(double[] rx, double[] ry) {
/*  4852 */     copy(rx.length, rx, ry);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(double[][] rx, double[][] ry) {
/*  4861 */     int n2 = rx.length;
/*  4862 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4863 */       copy(rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(double[][][] rx, double[][][] ry) {
/*  4872 */     int n3 = rx.length;
/*  4873 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4874 */       copy(rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] copy(int n1, double[] rx) {
/*  4884 */     double[] ry = new double[n1];
/*  4885 */     copy(n1, rx, ry);
/*  4886 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] copy(int n1, int n2, double[][] rx) {
/*  4897 */     double[][] ry = new double[n2][n1];
/*  4898 */     copy(n1, n2, rx, ry);
/*  4899 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] copy(int n1, int n2, int n3, double[][][] rx) {
/*  4911 */     double[][][] ry = new double[n3][n2][n1];
/*  4912 */     copy(n1, n2, n3, rx, ry);
/*  4913 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, double[] rx, double[] ry) {
/*  4923 */     for (int i1 = 0; i1 < n1; i1++) {
/*  4924 */       ry[i1] = rx[i1];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, double[][] rx, double[][] ry) {
/*  4935 */     for (int i2 = 0; i2 < n2; i2++) {
/*  4936 */       copy(n1, rx[i2], ry[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, double[][][] rx, double[][][] ry) {
/*  4949 */     for (int i3 = 0; i3 < n3; i3++) {
/*  4950 */       copy(n1, n2, rx[i3], ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] copy(int n1, int j1, double[] rx) {
/*  4963 */     double[] ry = new double[n1];
/*  4964 */     copy(n1, j1, rx, 0, ry);
/*  4965 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] copy(int n1, int n2, int j1, int j2, double[][] rx) {
/*  4980 */     double[][] ry = new double[n2][n1];
/*  4981 */     copy(n1, n2, j1, j2, rx, 0, 0, ry);
/*  4982 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, double[][][] rx) {
/*  4999 */     double[][][] ry = new double[n3][n2][n1];
/*  5000 */     copy(n1, n2, n3, j1, j2, j3, rx, 0, 0, 0, ry);
/*  5001 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] copy(int n1, int j1, int k1, double[] rx) {
/*  5015 */     double[] ry = new double[n1];
/*  5016 */     copy(n1, j1, k1, rx, 0, 1, ry);
/*  5017 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] copy(int n1, int n2, int j1, int j2, int k1, int k2, double[][] rx) {
/*  5034 */     double[][] ry = new double[n2][n1];
/*  5035 */     copy(n1, n2, j1, j2, k1, k2, rx, 0, 0, 1, 1, ry);
/*  5036 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] copy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, double[][][] rx) {
/*  5056 */     double[][][] ry = new double[n3][n2][n1];
/*  5057 */     copy(n1, n2, n3, j1, j2, j3, k1, k2, k3, rx, 0, 0, 0, 1, 1, 1, ry);
/*  5058 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, double[] rx, int j1y, double[] ry) {
/*  5073 */     for (int i1 = 0, ix = j1x, iy = j1y; i1 < n1; i1++) {
/*  5074 */       ry[iy++] = rx[ix++];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, double[][] rx, int j1y, int j2y, double[][] ry) {
/*  5092 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5093 */       copy(n1, j1x, rx[j2x + i2], j1y, ry[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, double[][][] rx, int j1y, int j2y, int j3y, double[][][] ry) {
/*  5114 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5115 */       copy(n1, n2, j1x, j2x, rx[j3x + i3], j1y, j2y, ry[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int j1x, int k1x, double[] rx, int j1y, int k1y, double[] ry) {
/*       */     int iy;
/*  5132 */     for (int i1 = 0, ix = j1x; i1 < n1; i1++, ix += k1x, iy += k1y) {
/*  5133 */       ry[iy] = rx[ix];
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, double[][] rx, int j1y, int j2y, int k1y, int k2y, double[][] ry) {
/*  5155 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5156 */       copy(n1, j1x, k1x, rx[j2x + i2 * k2x], j1y, k1y, ry[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void copy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, double[][][] rx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, double[][][] ry) {
/*  5183 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5184 */       copy(n1, n2, j1x, j2x, k1x, k2x, rx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, ry[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] ccopy(double[] cx) {
/*  5193 */     return ccopy(cx.length / 2, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] ccopy(double[][] cx) {
/*  5202 */     int n2 = cx.length;
/*  5203 */     double[][] cy = new double[n2][];
/*  5204 */     for (int i2 = 0; i2 < n2; i2++)
/*  5205 */       cy[i2] = ccopy(cx[i2]); 
/*  5206 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] ccopy(double[][][] cx) {
/*  5215 */     int n3 = cx.length;
/*  5216 */     double[][][] cy = new double[n3][][];
/*  5217 */     for (int i3 = 0; i3 < n3; i3++)
/*  5218 */       cy[i3] = ccopy(cx[i3]); 
/*  5219 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(double[] cx, double[] cy) {
/*  5228 */     ccopy(cx.length / 2, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(double[][] cx, double[][] cy) {
/*  5237 */     int n2 = cx.length;
/*  5238 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5239 */       ccopy(cx[i2], cy[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(double[][][] cx, double[][][] cy) {
/*  5248 */     int n3 = cx.length;
/*  5249 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5250 */       ccopy(cx[i3], cy[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] ccopy(int n1, double[] cx) {
/*  5260 */     double[] cy = new double[2 * n1];
/*  5261 */     ccopy(n1, cx, cy);
/*  5262 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] ccopy(int n1, int n2, double[][] cx) {
/*  5273 */     double[][] cy = new double[n2][2 * n1];
/*  5274 */     ccopy(n1, n2, cx, cy);
/*  5275 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] ccopy(int n1, int n2, int n3, double[][][] cx) {
/*  5287 */     double[][][] cy = new double[n3][n2][2 * n1];
/*  5288 */     ccopy(n1, n2, n3, cx, cy);
/*  5289 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, double[] cx, double[] cy) {
/*  5299 */     copy(2 * n1, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, double[][] cx, double[][] cy) {
/*  5310 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5311 */       ccopy(n1, cx[i2], cy[i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, double[][][] cx, double[][][] cy) {
/*  5324 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5325 */       ccopy(n1, n2, cx[i3], cy[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] ccopy(int n1, int j1, double[] cx) {
/*  5338 */     double[] cy = new double[2 * n1];
/*  5339 */     ccopy(n1, j1, cx, 0, cy);
/*  5340 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] ccopy(int n1, int n2, int j1, int j2, double[][] cx) {
/*  5355 */     double[][] cy = new double[n2][2 * n1];
/*  5356 */     ccopy(n1, n2, j1, j2, cx, 0, 0, cy);
/*  5357 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] ccopy(int n1, int n2, int n3, int j1, int j2, int j3, double[][][] cx) {
/*  5374 */     double[][][] cy = new double[n3][n2][2 * n1];
/*  5375 */     ccopy(n1, n2, n3, j1, j2, j3, cx, 0, 0, 0, cy);
/*  5376 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] ccopy(int n1, int j1, int k1, double[] cx) {
/*  5390 */     double[] cy = new double[2 * n1];
/*  5391 */     ccopy(n1, j1, k1, cx, 0, 1, cy);
/*  5392 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] ccopy(int n1, int n2, int j1, int j2, int k1, int k2, double[][] cx) {
/*  5409 */     double[][] cy = new double[n2][2 * n1];
/*  5410 */     ccopy(n1, n2, j1, j2, k1, k2, cx, 0, 0, 1, 1, cy);
/*  5411 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] ccopy(int n1, int n2, int n3, int j1, int j2, int j3, int k1, int k2, int k3, double[][][] cx) {
/*  5431 */     double[][][] cy = new double[n3][n2][2 * n1];
/*  5432 */     ccopy(n1, n2, n3, j1, j2, j3, k1, k2, k3, cx, 0, 0, 0, 1, 1, 1, cy);
/*  5433 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int j1x, double[] cx, int j1y, double[] cy) {
/*  5448 */     for (int i1 = 0, ix = 2 * j1x, iy = 2 * j1y; i1 < n1; i1++) {
/*  5449 */       cy[iy++] = cx[ix++];
/*  5450 */       cy[iy++] = cx[ix++];
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int j1x, int j2x, double[][] cx, int j1y, int j2y, double[][] cy) {
/*  5469 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5470 */       ccopy(n1, j1x, cx[j2x + i2], j1y, cy[j2y + i2]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, int j1x, int j2x, int j3x, double[][][] cx, int j1y, int j2y, int j3y, double[][][] cy) {
/*  5491 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5492 */       ccopy(n1, n2, j1x, j2x, cx[j3x + i3], j1y, j2y, cy[j3y + i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int j1x, int k1x, double[] cx, int j1y, int k1y, double[] cy) {
/*  5509 */     int k1x2 = k1x * 2;
/*  5510 */     int k1y2 = k1y * 2; int iy;
/*  5511 */     for (int i1 = 0, ix = 2 * j1x; i1 < n1; i1++, ix += k1x2, iy += k1y2) {
/*  5512 */       cy[iy] = cx[ix];
/*  5513 */       cy[iy + 1] = cx[ix + 1];
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int j1x, int j2x, int k1x, int k2x, double[][] cx, int j1y, int j2y, int k1y, int k2y, double[][] cy) {
/*  5536 */     for (int i2 = 0; i2 < n2; i2++) {
/*  5537 */       ccopy(n1, j1x, k1x, cx[j2x + i2 * k2x], j1y, k1y, cy[j2y + i2 * k2y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void ccopy(int n1, int n2, int n3, int j1x, int j2x, int j3x, int k1x, int k2x, int k3x, double[][][] cx, int j1y, int j2y, int j3y, int k1y, int k2y, int k3y, double[][][] cy) {
/*  5564 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5565 */       ccopy(n1, n2, j1x, j2x, k1x, k2x, cx[j3x + i3 * k3x], j1y, j2y, k1y, k2y, cy[j3y + i3 * k3y]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] reverse(byte[] rx) {
/*  5574 */     byte[] ry = new byte[rx.length];
/*  5575 */     reverse(rx, ry);
/*  5576 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(byte[] rx, byte[] ry) {
/*  5580 */     int n1 = rx.length;
/*  5581 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5582 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static short[] reverse(short[] rx) {
/*  5586 */     short[] ry = new short[rx.length];
/*  5587 */     reverse(rx, ry);
/*  5588 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(short[] rx, short[] ry) {
/*  5592 */     int n1 = rx.length;
/*  5593 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5594 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static int[] reverse(int[] rx) {
/*  5598 */     int[] ry = new int[rx.length];
/*  5599 */     reverse(rx, ry);
/*  5600 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(int[] rx, int[] ry) {
/*  5604 */     int n1 = rx.length;
/*  5605 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5606 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static long[] reverse(long[] rx) {
/*  5610 */     long[] ry = new long[rx.length];
/*  5611 */     reverse(rx, ry);
/*  5612 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(long[] rx, long[] ry) {
/*  5616 */     int n1 = rx.length;
/*  5617 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5618 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static float[] reverse(float[] rx) {
/*  5622 */     float[] ry = new float[rx.length];
/*  5623 */     reverse(rx, ry);
/*  5624 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(float[] rx, float[] ry) {
/*  5628 */     int n1 = rx.length;
/*  5629 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5630 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static float[] creverse(float[] rx) {
/*  5634 */     float[] ry = new float[rx.length];
/*  5635 */     reverse(rx, ry);
/*  5636 */     return ry;
/*       */   }
/*       */   
/*       */   public static void creverse(float[] rx, float[] ry) {
/*  5640 */     int n1 = rx.length / 2;
/*  5641 */     for (int i1 = 0, j1 = 2 * n1 - 2; i1 < n1; i1 += 2, j1 -= 2) {
/*  5642 */       ry[j1] = rx[i1];
/*  5643 */       ry[j1 + 1] = rx[i1 + 1];
/*       */     } 
/*       */   }
/*       */   
/*       */   public static double[] reverse(double[] rx) {
/*  5648 */     double[] ry = new double[rx.length];
/*  5649 */     reverse(rx, ry);
/*  5650 */     return ry;
/*       */   }
/*       */   
/*       */   public static void reverse(double[] rx, double[] ry) {
/*  5654 */     int n1 = rx.length;
/*  5655 */     for (int i1 = 0, j1 = n1 - 1; i1 < n1; i1++, j1--)
/*  5656 */       ry[j1] = rx[i1]; 
/*       */   }
/*       */   
/*       */   public static double[] creverse(double[] rx) {
/*  5660 */     double[] ry = new double[rx.length];
/*  5661 */     reverse(rx, ry);
/*  5662 */     return ry;
/*       */   }
/*       */   
/*       */   public static void creverse(double[] rx, double[] ry) {
/*  5666 */     int n1 = rx.length / 2;
/*  5667 */     for (int i1 = 0, j1 = 2 * n1 - 2; i1 < n1; i1 += 2, j1 -= 2) {
/*  5668 */       ry[j1] = rx[i1];
/*  5669 */       ry[j1 + 1] = rx[i1 + 1];
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] flatten(byte[][] rx) {
/*  5682 */     int n = 0;
/*  5683 */     int n2 = rx.length;
/*  5684 */     for (int i2 = 0; i2 < n2; i2++)
/*  5685 */       n += (rx[i2]).length; 
/*  5686 */     byte[] ry = new byte[n];
/*  5687 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5688 */       int n1 = (rx[i]).length;
/*  5689 */       copy(n1, 0, rx[i], iy, ry);
/*  5690 */       iy += n1;
/*       */     } 
/*  5692 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[] flatten(byte[][][] rx) {
/*  5701 */     int n = 0;
/*  5702 */     int n3 = rx.length;
/*  5703 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5704 */       int n2 = (rx[i3]).length;
/*  5705 */       for (int i2 = 0; i2 < n2; i2++)
/*  5706 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5708 */     byte[] ry = new byte[n];
/*  5709 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5710 */       int n2 = (rx[i]).length;
/*  5711 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5712 */         int n1 = (rx[i][i2]).length;
/*  5713 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5714 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5717 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] flatten(short[][] rx) {
/*  5726 */     int n = 0;
/*  5727 */     int n2 = rx.length;
/*  5728 */     for (int i2 = 0; i2 < n2; i2++)
/*  5729 */       n += (rx[i2]).length; 
/*  5730 */     short[] ry = new short[n];
/*  5731 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5732 */       int n1 = (rx[i]).length;
/*  5733 */       copy(n1, 0, rx[i], iy, ry);
/*  5734 */       iy += n1;
/*       */     } 
/*  5736 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[] flatten(short[][][] rx) {
/*  5745 */     int n = 0;
/*  5746 */     int n3 = rx.length;
/*  5747 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5748 */       int n2 = (rx[i3]).length;
/*  5749 */       for (int i2 = 0; i2 < n2; i2++)
/*  5750 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5752 */     short[] ry = new short[n];
/*  5753 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5754 */       int n2 = (rx[i]).length;
/*  5755 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5756 */         int n1 = (rx[i][i2]).length;
/*  5757 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5758 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5761 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] flatten(int[][] rx) {
/*  5770 */     int n = 0;
/*  5771 */     int n2 = rx.length;
/*  5772 */     for (int i2 = 0; i2 < n2; i2++)
/*  5773 */       n += (rx[i2]).length; 
/*  5774 */     int[] ry = new int[n];
/*  5775 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5776 */       int n1 = (rx[i]).length;
/*  5777 */       copy(n1, 0, rx[i], iy, ry);
/*  5778 */       iy += n1;
/*       */     } 
/*  5780 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[] flatten(int[][][] rx) {
/*  5789 */     int n = 0;
/*  5790 */     int n3 = rx.length;
/*  5791 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5792 */       int n2 = (rx[i3]).length;
/*  5793 */       for (int i2 = 0; i2 < n2; i2++)
/*  5794 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5796 */     int[] ry = new int[n];
/*  5797 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5798 */       int n2 = (rx[i]).length;
/*  5799 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5800 */         int n1 = (rx[i][i2]).length;
/*  5801 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5802 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5805 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] flatten(long[][] rx) {
/*  5814 */     int n = 0;
/*  5815 */     int n2 = rx.length;
/*  5816 */     for (int i2 = 0; i2 < n2; i2++)
/*  5817 */       n += (rx[i2]).length; 
/*  5818 */     long[] ry = new long[n];
/*  5819 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5820 */       int n1 = (rx[i]).length;
/*  5821 */       copy(n1, 0, rx[i], iy, ry);
/*  5822 */       iy += n1;
/*       */     } 
/*  5824 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[] flatten(long[][][] rx) {
/*  5833 */     int n = 0;
/*  5834 */     int n3 = rx.length;
/*  5835 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5836 */       int n2 = (rx[i3]).length;
/*  5837 */       for (int i2 = 0; i2 < n2; i2++)
/*  5838 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5840 */     long[] ry = new long[n];
/*  5841 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5842 */       int n2 = (rx[i]).length;
/*  5843 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5844 */         int n1 = (rx[i][i2]).length;
/*  5845 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5846 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5849 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] flatten(float[][] rx) {
/*  5858 */     int n = 0;
/*  5859 */     int n2 = rx.length;
/*  5860 */     for (int i2 = 0; i2 < n2; i2++)
/*  5861 */       n += (rx[i2]).length; 
/*  5862 */     float[] ry = new float[n];
/*  5863 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5864 */       int n1 = (rx[i]).length;
/*  5865 */       copy(n1, 0, rx[i], iy, ry);
/*  5866 */       iy += n1;
/*       */     } 
/*  5868 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] flatten(float[][][] rx) {
/*  5877 */     int n = 0;
/*  5878 */     int n3 = rx.length;
/*  5879 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5880 */       int n2 = (rx[i3]).length;
/*  5881 */       for (int i2 = 0; i2 < n2; i2++)
/*  5882 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5884 */     float[] ry = new float[n];
/*  5885 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5886 */       int n2 = (rx[i]).length;
/*  5887 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5888 */         int n1 = (rx[i][i2]).length;
/*  5889 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5890 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5893 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cflatten(float[][] cx) {
/*  5902 */     return flatten(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cflatten(float[][][] cx) {
/*  5911 */     return flatten(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] flatten(double[][] rx) {
/*  5920 */     int n = 0;
/*  5921 */     int n2 = rx.length;
/*  5922 */     for (int i2 = 0; i2 < n2; i2++)
/*  5923 */       n += (rx[i2]).length; 
/*  5924 */     double[] ry = new double[n];
/*  5925 */     for (int i = 0, iy = 0; i < n2; i++) {
/*  5926 */       int n1 = (rx[i]).length;
/*  5927 */       copy(n1, 0, rx[i], iy, ry);
/*  5928 */       iy += n1;
/*       */     } 
/*  5930 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] flatten(double[][][] rx) {
/*  5939 */     int n = 0;
/*  5940 */     int n3 = rx.length;
/*  5941 */     for (int i3 = 0; i3 < n3; i3++) {
/*  5942 */       int n2 = (rx[i3]).length;
/*  5943 */       for (int i2 = 0; i2 < n2; i2++)
/*  5944 */         n += (rx[i3][i2]).length; 
/*       */     } 
/*  5946 */     double[] ry = new double[n];
/*  5947 */     for (int i = 0, iy = 0; i < n3; i++) {
/*  5948 */       int n2 = (rx[i]).length;
/*  5949 */       for (int i2 = 0; i2 < n2; i2++) {
/*  5950 */         int n1 = (rx[i][i2]).length;
/*  5951 */         copy(n1, 0, rx[i][i2], iy, ry);
/*  5952 */         iy += n1;
/*       */       } 
/*       */     } 
/*  5955 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] cflatten(double[][] cx) {
/*  5964 */     return flatten(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[] cflatten(double[][][] cx) {
/*  5973 */     return flatten(cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] reshape(int n1, int n2, byte[] rx) {
/*  5987 */     byte[][] ry = new byte[n2][n1];
/*  5988 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  5989 */       copy(n1, ix, rx, 0, ry[i2]);
/*  5990 */       ix += n1;
/*       */     } 
/*  5992 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][][] reshape(int n1, int n2, int n3, byte[] rx) {
/*  6004 */     byte[][][] ry = new byte[n3][n2][n1];
/*  6005 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6006 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6007 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6008 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6011 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] reshape(int n1, int n2, short[] rx) {
/*  6022 */     short[][] ry = new short[n2][n1];
/*  6023 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  6024 */       copy(n1, ix, rx, 0, ry[i2]);
/*  6025 */       ix += n1;
/*       */     } 
/*  6027 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][][] reshape(int n1, int n2, int n3, short[] rx) {
/*  6039 */     short[][][] ry = new short[n3][n2][n1];
/*  6040 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6041 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6042 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6043 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6046 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] reshape(int n1, int n2, int[] rx) {
/*  6057 */     int[][] ry = new int[n2][n1];
/*  6058 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  6059 */       copy(n1, ix, rx, 0, ry[i2]);
/*  6060 */       ix += n1;
/*       */     } 
/*  6062 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][][] reshape(int n1, int n2, int n3, int[] rx) {
/*  6074 */     int[][][] ry = new int[n3][n2][n1];
/*  6075 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6076 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6077 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6078 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6081 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] reshape(int n1, int n2, long[] rx) {
/*  6092 */     long[][] ry = new long[n2][n1];
/*  6093 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  6094 */       copy(n1, ix, rx, 0, ry[i2]);
/*  6095 */       ix += n1;
/*       */     } 
/*  6097 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][][] reshape(int n1, int n2, int n3, long[] rx) {
/*  6109 */     long[][][] ry = new long[n3][n2][n1];
/*  6110 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6111 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6112 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6113 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6116 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] reshape(int n1, int n2, float[] rx) {
/*  6127 */     float[][] ry = new float[n2][n1];
/*  6128 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  6129 */       copy(n1, ix, rx, 0, ry[i2]);
/*  6130 */       ix += n1;
/*       */     } 
/*  6132 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] reshape(int n1, int n2, int n3, float[] rx) {
/*  6144 */     float[][][] ry = new float[n3][n2][n1];
/*  6145 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6146 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6147 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6148 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6151 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] creshape(int n1, int n2, float[] cx) {
/*  6162 */     return reshape(2 * n1, n2, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][][] creshape(int n1, int n2, int n3, float[] cx) {
/*  6174 */     return reshape(2 * n1, n2, n3, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] reshape(int n1, int n2, double[] rx) {
/*  6185 */     double[][] ry = new double[n2][n1];
/*  6186 */     for (int i2 = 0, ix = 0; i2 < n2; i2++) {
/*  6187 */       copy(n1, ix, rx, 0, ry[i2]);
/*  6188 */       ix += n1;
/*       */     } 
/*  6190 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] reshape(int n1, int n2, int n3, double[] rx) {
/*  6202 */     double[][][] ry = new double[n3][n2][n1];
/*  6203 */     for (int i3 = 0, ix = 0; i3 < n3; i3++) {
/*  6204 */       for (int i2 = 0; i2 < n2; i2++) {
/*  6205 */         copy(n1, ix, rx, 0, ry[i3][i2]);
/*  6206 */         ix += n1;
/*       */       } 
/*       */     } 
/*  6209 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] creshape(int n1, int n2, double[] cx) {
/*  6220 */     return reshape(2 * n1, n2, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][][] creshape(int n1, int n2, int n3, double[] cx) {
/*  6232 */     return reshape(2 * n1, n2, n3, cx);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte[][] transpose(byte[][] rx) {
/*  6244 */     int n2 = rx.length;
/*  6245 */     int n1 = (rx[0]).length;
/*  6246 */     byte[][] ry = new byte[n1][n2];
/*  6247 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6248 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6249 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6252 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static short[][] transpose(short[][] rx) {
/*  6261 */     int n2 = rx.length;
/*  6262 */     int n1 = (rx[0]).length;
/*  6263 */     short[][] ry = new short[n1][n2];
/*  6264 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6265 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6266 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6269 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int[][] transpose(int[][] rx) {
/*  6278 */     int n2 = rx.length;
/*  6279 */     int n1 = (rx[0]).length;
/*  6280 */     int[][] ry = new int[n1][n2];
/*  6281 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6282 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6283 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6286 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static long[][] transpose(long[][] rx) {
/*  6295 */     int n2 = rx.length;
/*  6296 */     int n1 = (rx[0]).length;
/*  6297 */     long[][] ry = new long[n1][n2];
/*  6298 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6299 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6300 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6303 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] transpose(float[][] rx) {
/*  6312 */     int n2 = rx.length;
/*  6313 */     int n1 = (rx[0]).length;
/*  6314 */     float[][] ry = new float[n1][n2];
/*  6315 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6316 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6317 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6320 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[][] ctranspose(float[][] cx) {
/*  6329 */     int n2 = cx.length;
/*  6330 */     int n1 = (cx[0]).length / 2;
/*  6331 */     float[][] cy = new float[n1][2 * n2];
/*  6332 */     for (int i2 = 0, iy = 0; i2 < n2; i2++, iy += 2) {
/*  6333 */       for (int i1 = 0, ix = 0; i1 < n1; i1++, ix += 2) {
/*  6334 */         cy[i1][iy] = cx[i2][ix];
/*  6335 */         cy[i1][iy + 1] = cx[i2][ix + 1];
/*       */       } 
/*       */     } 
/*  6338 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] transpose(double[][] rx) {
/*  6347 */     int n2 = rx.length;
/*  6348 */     int n1 = (rx[0]).length;
/*  6349 */     double[][] ry = new double[n1][n2];
/*  6350 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6351 */       for (int i1 = 0; i1 < n1; i1++) {
/*  6352 */         ry[i1][i2] = rx[i2][i1];
/*       */       }
/*       */     } 
/*  6355 */     return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static double[][] ctranspose(double[][] cx) {
/*  6364 */     int n2 = cx.length;
/*  6365 */     int n1 = (cx[0]).length / 2;
/*  6366 */     double[][] cy = new double[n1][2 * n2];
/*  6367 */     for (int i2 = 0, iy = 0; i2 < n2; i2++, iy += 2) {
/*  6368 */       for (int i1 = 0, ix = 0; i1 < n1; i1++, ix += 2) {
/*  6369 */         cy[i1][iy] = cx[i2][ix];
/*  6370 */         cy[i1][iy + 1] = cx[i2][ix + 1];
/*       */       } 
/*       */     } 
/*  6373 */     return cy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(byte[] rx, byte[] ry) {
/*  6386 */     int n1 = rx.length;
/*  6387 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6388 */       if (rx[i1] != ry[i1])
/*  6389 */         return false; 
/*       */     } 
/*  6391 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(byte[][] rx, byte[][] ry) {
/*  6401 */     int n2 = rx.length;
/*  6402 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6403 */       if (!equal(rx[i2], ry[i2]))
/*  6404 */         return false; 
/*       */     } 
/*  6406 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(byte[][][] rx, byte[][][] ry) {
/*  6416 */     int n3 = rx.length;
/*  6417 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6418 */       if (!equal(rx[i3], ry[i3]))
/*  6419 */         return false; 
/*       */     } 
/*  6421 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(short[] rx, short[] ry) {
/*  6431 */     int n1 = rx.length;
/*  6432 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6433 */       if (rx[i1] != ry[i1])
/*  6434 */         return false; 
/*       */     } 
/*  6436 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(short[][] rx, short[][] ry) {
/*  6446 */     int n2 = rx.length;
/*  6447 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6448 */       if (!equal(rx[i2], ry[i2]))
/*  6449 */         return false; 
/*       */     } 
/*  6451 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(short[][][] rx, short[][][] ry) {
/*  6461 */     int n3 = rx.length;
/*  6462 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6463 */       if (!equal(rx[i3], ry[i3]))
/*  6464 */         return false; 
/*       */     } 
/*  6466 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(int[] rx, int[] ry) {
/*  6476 */     int n1 = rx.length;
/*  6477 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6478 */       if (rx[i1] != ry[i1])
/*  6479 */         return false; 
/*       */     } 
/*  6481 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(int[][] rx, int[][] ry) {
/*  6491 */     int n2 = rx.length;
/*  6492 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6493 */       if (!equal(rx[i2], ry[i2]))
/*  6494 */         return false; 
/*       */     } 
/*  6496 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(int[][][] rx, int[][][] ry) {
/*  6506 */     int n3 = rx.length;
/*  6507 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6508 */       if (!equal(rx[i3], ry[i3]))
/*  6509 */         return false; 
/*       */     } 
/*  6511 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(long[] rx, long[] ry) {
/*  6521 */     int n1 = rx.length;
/*  6522 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6523 */       if (rx[i1] != ry[i1])
/*  6524 */         return false; 
/*       */     } 
/*  6526 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(long[][] rx, long[][] ry) {
/*  6536 */     int n2 = rx.length;
/*  6537 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6538 */       if (!equal(rx[i2], ry[i2]))
/*  6539 */         return false; 
/*       */     } 
/*  6541 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(long[][][] rx, long[][][] ry) {
/*  6551 */     int n3 = rx.length;
/*  6552 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6553 */       if (!equal(rx[i3], ry[i3]))
/*  6554 */         return false; 
/*       */     } 
/*  6556 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float[] rx, float[] ry) {
/*  6566 */     int n1 = rx.length;
/*  6567 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6568 */       if (rx[i1] != ry[i1])
/*  6569 */         return false; 
/*       */     } 
/*  6571 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float[][] rx, float[][] ry) {
/*  6581 */     int n2 = rx.length;
/*  6582 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6583 */       if (!equal(rx[i2], ry[i2]))
/*  6584 */         return false; 
/*       */     } 
/*  6586 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float[][][] rx, float[][][] ry) {
/*  6596 */     int n3 = rx.length;
/*  6597 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6598 */       if (!equal(rx[i3], ry[i3]))
/*  6599 */         return false; 
/*       */     } 
/*  6601 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float tolerance, float[] rx, float[] ry) {
/*  6613 */     int n1 = rx.length;
/*  6614 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6615 */       if (!equal(tolerance, rx[i1], ry[i1]))
/*  6616 */         return false; 
/*       */     } 
/*  6618 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float tolerance, float[][] rx, float[][] ry) {
/*  6630 */     int n2 = rx.length;
/*  6631 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6632 */       if (!equal(tolerance, rx[i2], ry[i2]))
/*  6633 */         return false; 
/*       */     } 
/*  6635 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(float tolerance, float[][][] rx, float[][][] ry) {
/*  6648 */     int n3 = rx.length;
/*  6649 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6650 */       if (!equal(tolerance, rx[i3], ry[i3]))
/*  6651 */         return false; 
/*       */     } 
/*  6653 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float[] cx, float[] cy) {
/*  6663 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float[][] cx, float[][] cy) {
/*  6673 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float[][][] cx, float[][][] cy) {
/*  6683 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float tolerance, float[] cx, float[] cy) {
/*  6695 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float tolerance, float[][] cx, float[][] cy) {
/*  6707 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(float tolerance, float[][][] cx, float[][][] cy) {
/*  6720 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */   private static boolean equal(float tolerance, float ra, float rb) {
/*  6723 */     return (ra < rb) ? ((rb - ra <= tolerance)) : ((ra - rb <= tolerance));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double[] rx, double[] ry) {
/*  6733 */     int n1 = rx.length;
/*  6734 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6735 */       if (rx[i1] != ry[i1])
/*  6736 */         return false; 
/*       */     } 
/*  6738 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double[][] rx, double[][] ry) {
/*  6748 */     int n2 = rx.length;
/*  6749 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6750 */       if (!equal(rx[i2], ry[i2]))
/*  6751 */         return false; 
/*       */     } 
/*  6753 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double[][][] rx, double[][][] ry) {
/*  6763 */     int n3 = rx.length;
/*  6764 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6765 */       if (!equal(rx[i3], ry[i3]))
/*  6766 */         return false; 
/*       */     } 
/*  6768 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double tolerance, double[] rx, double[] ry) {
/*  6780 */     int n1 = rx.length;
/*  6781 */     for (int i1 = 0; i1 < n1; i1++) {
/*  6782 */       if (!equal(tolerance, rx[i1], ry[i1]))
/*  6783 */         return false; 
/*       */     } 
/*  6785 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double tolerance, double[][] rx, double[][] ry) {
/*  6797 */     int n2 = rx.length;
/*  6798 */     for (int i2 = 0; i2 < n2; i2++) {
/*  6799 */       if (!equal(tolerance, rx[i2], ry[i2]))
/*  6800 */         return false; 
/*       */     } 
/*  6802 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean equal(double tolerance, double[][][] rx, double[][][] ry) {
/*  6815 */     int n3 = rx.length;
/*  6816 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6817 */       if (!equal(tolerance, rx[i3], ry[i3]))
/*  6818 */         return false; 
/*       */     } 
/*  6820 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double[] cx, double[] cy) {
/*  6830 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double[][] cx, double[][] cy) {
/*  6840 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double[][][] cx, double[][][] cy) {
/*  6850 */     return equal(cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double tolerance, double[] cx, double[] cy) {
/*  6862 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double tolerance, double[][] cx, double[][] cy) {
/*  6874 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean cequal(double tolerance, double[][][] cx, double[][][] cy) {
/*  6887 */     return equal(tolerance, cx, cy);
/*       */   }
/*       */   private static boolean equal(double tolerance, double ra, double rb) {
/*  6890 */     return (ra < rb) ? ((rb - ra <= tolerance)) : ((ra - rb <= tolerance));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(byte[][] a) {
/*  6904 */     int n2 = a.length;
/*  6905 */     int n1 = (a[0]).length;
/*  6906 */     for (int i2 = 1; i2 < n2; i2++) {
/*  6907 */       if ((a[i2]).length != n1)
/*  6908 */         return false; 
/*       */     } 
/*  6910 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(byte[][][] a) {
/*  6921 */     int n3 = a.length;
/*  6922 */     int n2 = (a[0]).length;
/*  6923 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6924 */       if ((a[i3]).length != n2 || !isRegular(a[i3]))
/*  6925 */         return false; 
/*       */     } 
/*  6927 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(short[][] a) {
/*  6938 */     int n2 = a.length;
/*  6939 */     int n1 = (a[0]).length;
/*  6940 */     for (int i2 = 1; i2 < n2; i2++) {
/*  6941 */       if ((a[i2]).length != n1)
/*  6942 */         return false; 
/*       */     } 
/*  6944 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(short[][][] a) {
/*  6955 */     int n3 = a.length;
/*  6956 */     int n2 = (a[0]).length;
/*  6957 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6958 */       if ((a[i3]).length != n2 || !isRegular(a[i3]))
/*  6959 */         return false; 
/*       */     } 
/*  6961 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(int[][] a) {
/*  6972 */     int n2 = a.length;
/*  6973 */     int n1 = (a[0]).length;
/*  6974 */     for (int i2 = 1; i2 < n2; i2++) {
/*  6975 */       if ((a[i2]).length != n1)
/*  6976 */         return false; 
/*       */     } 
/*  6978 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(int[][][] a) {
/*  6989 */     int n3 = a.length;
/*  6990 */     int n2 = (a[0]).length;
/*  6991 */     for (int i3 = 0; i3 < n3; i3++) {
/*  6992 */       if ((a[i3]).length != n2 || !isRegular(a[i3]))
/*  6993 */         return false; 
/*       */     } 
/*  6995 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(float[][] a) {
/*  7006 */     int n2 = a.length;
/*  7007 */     int n1 = (a[0]).length;
/*  7008 */     for (int i2 = 1; i2 < n2; i2++) {
/*  7009 */       if ((a[i2]).length != n1)
/*  7010 */         return false; 
/*       */     } 
/*  7012 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(float[][][] a) {
/*  7023 */     int n3 = a.length;
/*  7024 */     int n2 = (a[0]).length;
/*  7025 */     for (int i3 = 0; i3 < n3; i3++) {
/*  7026 */       if ((a[i3]).length != n2 || !isRegular(a[i3]))
/*  7027 */         return false; 
/*       */     } 
/*  7029 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(double[][] a) {
/*  7040 */     int n2 = a.length;
/*  7041 */     int n1 = (a[0]).length;
/*  7042 */     for (int i2 = 1; i2 < n2; i2++) {
/*  7043 */       if ((a[i2]).length != n1)
/*  7044 */         return false; 
/*       */     } 
/*  7046 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isRegular(double[][][] a) {
/*  7057 */     int n3 = a.length;
/*  7058 */     int n2 = (a[0]).length;
/*  7059 */     for (int i3 = 0; i3 < n3; i3++) {
/*  7060 */       if ((a[i3]).length != n2 || !isRegular(a[i3]))
/*  7061 */         return false; 
/*       */     } 
/*  7063 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(byte[] a) {
/*  7077 */     int n = a.length;
/*  7078 */     if (n > 1)
/*  7079 */       for (int i = 1; i < n; i++) {
/*  7080 */         if (a[i - 1] >= a[i]) {
/*  7081 */           return false;
/*       */         }
/*       */       }  
/*  7084 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(byte[] a) {
/*  7095 */     int n = a.length;
/*  7096 */     if (n > 1)
/*  7097 */       for (int i = 1; i < n; i++) {
/*  7098 */         if (a[i - 1] <= a[i]) {
/*  7099 */           return false;
/*       */         }
/*       */       }  
/*  7102 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(byte[] a) {
/*  7113 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(short[] a) {
/*  7124 */     int n = a.length;
/*  7125 */     if (n > 1)
/*  7126 */       for (int i = 1; i < n; i++) {
/*  7127 */         if (a[i - 1] >= a[i]) {
/*  7128 */           return false;
/*       */         }
/*       */       }  
/*  7131 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(short[] a) {
/*  7142 */     int n = a.length;
/*  7143 */     if (n > 1)
/*  7144 */       for (int i = 1; i < n; i++) {
/*  7145 */         if (a[i - 1] <= a[i]) {
/*  7146 */           return false;
/*       */         }
/*       */       }  
/*  7149 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(short[] a) {
/*  7160 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(int[] a) {
/*  7171 */     int n = a.length;
/*  7172 */     if (n > 1)
/*  7173 */       for (int i = 1; i < n; i++) {
/*  7174 */         if (a[i - 1] >= a[i]) {
/*  7175 */           return false;
/*       */         }
/*       */       }  
/*  7178 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(int[] a) {
/*  7189 */     int n = a.length;
/*  7190 */     if (n > 1)
/*  7191 */       for (int i = 1; i < n; i++) {
/*  7192 */         if (a[i - 1] <= a[i]) {
/*  7193 */           return false;
/*       */         }
/*       */       }  
/*  7196 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(int[] a) {
/*  7207 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(long[] a) {
/*  7218 */     int n = a.length;
/*  7219 */     if (n > 1)
/*  7220 */       for (int i = 1; i < n; i++) {
/*  7221 */         if (a[i - 1] >= a[i]) {
/*  7222 */           return false;
/*       */         }
/*       */       }  
/*  7225 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(long[] a) {
/*  7236 */     int n = a.length;
/*  7237 */     if (n > 1)
/*  7238 */       for (int i = 1; i < n; i++) {
/*  7239 */         if (a[i - 1] <= a[i]) {
/*  7240 */           return false;
/*       */         }
/*       */       }  
/*  7243 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(long[] a) {
/*  7254 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(float[] a) {
/*  7265 */     int n = a.length;
/*  7266 */     if (n > 1)
/*  7267 */       for (int i = 1; i < n; i++) {
/*  7268 */         if (a[i - 1] >= a[i]) {
/*  7269 */           return false;
/*       */         }
/*       */       }  
/*  7272 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(float[] a) {
/*  7283 */     int n = a.length;
/*  7284 */     if (n > 1)
/*  7285 */       for (int i = 1; i < n; i++) {
/*  7286 */         if (a[i - 1] <= a[i]) {
/*  7287 */           return false;
/*       */         }
/*       */       }  
/*  7290 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(float[] a) {
/*  7301 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isIncreasing(double[] a) {
/*  7312 */     int n = a.length;
/*  7313 */     if (n > 1)
/*  7314 */       for (int i = 1; i < n; i++) {
/*  7315 */         if (a[i - 1] >= a[i]) {
/*  7316 */           return false;
/*       */         }
/*       */       }  
/*  7319 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isDecreasing(double[] a) {
/*  7330 */     int n = a.length;
/*  7331 */     if (n > 1)
/*  7332 */       for (int i = 1; i < n; i++) {
/*  7333 */         if (a[i - 1] <= a[i]) {
/*  7334 */           return false;
/*       */         }
/*       */       }  
/*  7337 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static boolean isMonotonic(double[] a) {
/*  7348 */     return (isIncreasing(a) || isDecreasing(a));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(byte[] a) {
/*  7360 */     int n = a.length;
/*  7361 */     if (n < 7) {
/*  7362 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7364 */       int[] m = new int[2];
/*  7365 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(byte[] a, int[] i) {
/*  7376 */     int n = a.length;
/*  7377 */     if (n < 7) {
/*  7378 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7380 */       int[] m = new int[2];
/*  7381 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, byte[] a) {
/*  7394 */     int n = a.length;
/*  7395 */     int p = 0;
/*  7396 */     int q = n - 1;
/*  7397 */     int[] m = (n > 7) ? new int[2] : null;
/*  7398 */     while (q - p >= 7) {
/*  7399 */       m[0] = p;
/*  7400 */       m[1] = q;
/*  7401 */       quickPartition(a, m);
/*  7402 */       if (k < m[0]) {
/*  7403 */         q = m[0] - 1; continue;
/*  7404 */       }  if (k > m[1]) {
/*  7405 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7410 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, byte[] a, int[] i) {
/*  7423 */     int n = i.length;
/*  7424 */     int p = 0;
/*  7425 */     int q = n - 1;
/*  7426 */     int[] m = (n > 7) ? new int[2] : null;
/*  7427 */     while (q - p >= 7) {
/*  7428 */       m[0] = p;
/*  7429 */       m[1] = q;
/*  7430 */       quickPartition(a, i, m);
/*  7431 */       if (k < m[0]) {
/*  7432 */         q = m[0] - 1; continue;
/*  7433 */       }  if (k > m[1]) {
/*  7434 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7439 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(short[] a) {
/*  7448 */     int n = a.length;
/*  7449 */     if (n < 7) {
/*  7450 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7452 */       int[] m = new int[2];
/*  7453 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(short[] a, int[] i) {
/*  7464 */     int n = a.length;
/*  7465 */     if (n < 7) {
/*  7466 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7468 */       int[] m = new int[2];
/*  7469 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, short[] a) {
/*  7482 */     int n = a.length;
/*  7483 */     int p = 0;
/*  7484 */     int q = n - 1;
/*  7485 */     int[] m = (n > 7) ? new int[2] : null;
/*  7486 */     while (q - p >= 7) {
/*  7487 */       m[0] = p;
/*  7488 */       m[1] = q;
/*  7489 */       quickPartition(a, m);
/*  7490 */       if (k < m[0]) {
/*  7491 */         q = m[0] - 1; continue;
/*  7492 */       }  if (k > m[1]) {
/*  7493 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7498 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, short[] a, int[] i) {
/*  7511 */     int n = i.length;
/*  7512 */     int p = 0;
/*  7513 */     int q = n - 1;
/*  7514 */     int[] m = (n > 7) ? new int[2] : null;
/*  7515 */     while (q - p >= 7) {
/*  7516 */       m[0] = p;
/*  7517 */       m[1] = q;
/*  7518 */       quickPartition(a, i, m);
/*  7519 */       if (k < m[0]) {
/*  7520 */         q = m[0] - 1; continue;
/*  7521 */       }  if (k > m[1]) {
/*  7522 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7527 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(int[] a) {
/*  7536 */     int n = a.length;
/*  7537 */     if (n < 7) {
/*  7538 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7540 */       int[] m = new int[2];
/*  7541 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(int[] a, int[] i) {
/*  7552 */     int n = a.length;
/*  7553 */     if (n < 7) {
/*  7554 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7556 */       int[] m = new int[2];
/*  7557 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, int[] a) {
/*  7570 */     int n = a.length;
/*  7571 */     int p = 0;
/*  7572 */     int q = n - 1;
/*  7573 */     int[] m = (n > 7) ? new int[2] : null;
/*  7574 */     while (q - p >= 7) {
/*  7575 */       m[0] = p;
/*  7576 */       m[1] = q;
/*  7577 */       quickPartition(a, m);
/*  7578 */       if (k < m[0]) {
/*  7579 */         q = m[0] - 1; continue;
/*  7580 */       }  if (k > m[1]) {
/*  7581 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7586 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, int[] a, int[] i) {
/*  7599 */     int n = i.length;
/*  7600 */     int p = 0;
/*  7601 */     int q = n - 1;
/*  7602 */     int[] m = (n > 7) ? new int[2] : null;
/*  7603 */     while (q - p >= 7) {
/*  7604 */       m[0] = p;
/*  7605 */       m[1] = q;
/*  7606 */       quickPartition(a, i, m);
/*  7607 */       if (k < m[0]) {
/*  7608 */         q = m[0] - 1; continue;
/*  7609 */       }  if (k > m[1]) {
/*  7610 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7615 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(long[] a) {
/*  7624 */     int n = a.length;
/*  7625 */     if (n < 7) {
/*  7626 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7628 */       int[] m = new int[2];
/*  7629 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(long[] a, int[] i) {
/*  7640 */     int n = a.length;
/*  7641 */     if (n < 7) {
/*  7642 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7644 */       int[] m = new int[2];
/*  7645 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, long[] a) {
/*  7658 */     int n = a.length;
/*  7659 */     int p = 0;
/*  7660 */     int q = n - 1;
/*  7661 */     int[] m = (n > 7) ? new int[2] : null;
/*  7662 */     while (q - p >= 7) {
/*  7663 */       m[0] = p;
/*  7664 */       m[1] = q;
/*  7665 */       quickPartition(a, m);
/*  7666 */       if (k < m[0]) {
/*  7667 */         q = m[0] - 1; continue;
/*  7668 */       }  if (k > m[1]) {
/*  7669 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7674 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, long[] a, int[] i) {
/*  7687 */     int n = i.length;
/*  7688 */     int p = 0;
/*  7689 */     int q = n - 1;
/*  7690 */     int[] m = (n > 7) ? new int[2] : null;
/*  7691 */     while (q - p >= 7) {
/*  7692 */       m[0] = p;
/*  7693 */       m[1] = q;
/*  7694 */       quickPartition(a, i, m);
/*  7695 */       if (k < m[0]) {
/*  7696 */         q = m[0] - 1; continue;
/*  7697 */       }  if (k > m[1]) {
/*  7698 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7703 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(float[] a) {
/*  7712 */     int n = a.length;
/*  7713 */     if (n < 7) {
/*  7714 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7716 */       int[] m = new int[2];
/*  7717 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(float[] a, int[] i) {
/*  7728 */     int n = a.length;
/*  7729 */     if (n < 7) {
/*  7730 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7732 */       int[] m = new int[2];
/*  7733 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, float[] a) {
/*  7746 */     int n = a.length;
/*  7747 */     int p = 0;
/*  7748 */     int q = n - 1;
/*  7749 */     int[] m = (n > 7) ? new int[2] : null;
/*  7750 */     while (q - p >= 7) {
/*  7751 */       m[0] = p;
/*  7752 */       m[1] = q;
/*  7753 */       quickPartition(a, m);
/*  7754 */       if (k < m[0]) {
/*  7755 */         q = m[0] - 1; continue;
/*  7756 */       }  if (k > m[1]) {
/*  7757 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7762 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, float[] a, int[] i) {
/*  7775 */     int n = i.length;
/*  7776 */     int p = 0;
/*  7777 */     int q = n - 1;
/*  7778 */     int[] m = (n > 7) ? new int[2] : null;
/*  7779 */     while (q - p >= 7) {
/*  7780 */       m[0] = p;
/*  7781 */       m[1] = q;
/*  7782 */       quickPartition(a, i, m);
/*  7783 */       if (k < m[0]) {
/*  7784 */         q = m[0] - 1; continue;
/*  7785 */       }  if (k > m[1]) {
/*  7786 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7791 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickSort(double[] a) {
/*  7800 */     int n = a.length;
/*  7801 */     if (n < 7) {
/*  7802 */       insertionSort(a, 0, n - 1);
/*       */     } else {
/*  7804 */       int[] m = new int[2];
/*  7805 */       quickSort(a, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickIndexSort(double[] a, int[] i) {
/*  7816 */     int n = a.length;
/*  7817 */     if (n < 7) {
/*  7818 */       insertionSort(a, i, 0, n - 1);
/*       */     } else {
/*  7820 */       int[] m = new int[2];
/*  7821 */       quickSort(a, i, 0, n - 1, m);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialSort(int k, double[] a) {
/*  7834 */     int n = a.length;
/*  7835 */     int p = 0;
/*  7836 */     int q = n - 1;
/*  7837 */     int[] m = (n > 7) ? new int[2] : null;
/*  7838 */     while (q - p >= 7) {
/*  7839 */       m[0] = p;
/*  7840 */       m[1] = q;
/*  7841 */       quickPartition(a, m);
/*  7842 */       if (k < m[0]) {
/*  7843 */         q = m[0] - 1; continue;
/*  7844 */       }  if (k > m[1]) {
/*  7845 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7850 */     insertionSort(a, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void quickPartialIndexSort(int k, double[] a, int[] i) {
/*  7863 */     int n = i.length;
/*  7864 */     int p = 0;
/*  7865 */     int q = n - 1;
/*  7866 */     int[] m = (n > 7) ? new int[2] : null;
/*  7867 */     while (q - p >= 7) {
/*  7868 */       m[0] = p;
/*  7869 */       m[1] = q;
/*  7870 */       quickPartition(a, i, m);
/*  7871 */       if (k < m[0]) {
/*  7872 */         q = m[0] - 1; continue;
/*  7873 */       }  if (k > m[1]) {
/*  7874 */         p = m[1] + 1;
/*       */         continue;
/*       */       } 
/*       */       return;
/*       */     } 
/*  7879 */     insertionSort(a, i, p, q);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static int med3(byte[] a, int i, int j, int k) {
/*  7887 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(byte[] a, int[] i, int j, int k, int l) {
/*  7892 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(byte[] a, int i, int j) {
/*  7897 */     byte ai = a[i];
/*  7898 */     a[i] = a[j];
/*  7899 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(byte[] a, int i, int j, int n) {
/*  7902 */     while (n > 0) {
/*  7903 */       byte ai = a[i];
/*  7904 */       a[i++] = a[j];
/*  7905 */       a[j++] = ai;
/*  7906 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(byte[] a, int p, int q) {
/*  7910 */     for (int i = p; i <= q; i++) {
/*  7911 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  7912 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(byte[] a, int[] i, int p, int q) {
/*  7915 */     for (int j = p; j <= q; j++) {
/*  7916 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  7917 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(byte[] a, int p, int q, int[] m) {
/*  7920 */     if (q - p <= 7) {
/*  7921 */       insertionSort(a, p, q);
/*       */     } else {
/*  7923 */       m[0] = p;
/*  7924 */       m[1] = q;
/*  7925 */       quickPartition(a, m);
/*  7926 */       int r = m[0];
/*  7927 */       int s = m[1];
/*  7928 */       if (p < r - 1)
/*  7929 */         quickSort(a, p, r - 1, m); 
/*  7930 */       if (q > s + 1)
/*  7931 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(byte[] a, int[] i, int p, int q, int[] m) {
/*  7935 */     if (q - p <= 7) {
/*  7936 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  7938 */       m[0] = p;
/*  7939 */       m[1] = q;
/*  7940 */       quickPartition(a, i, m);
/*  7941 */       int r = m[0];
/*  7942 */       int s = m[1];
/*  7943 */       if (p < r - 1)
/*  7944 */         quickSort(a, i, p, r - 1, m); 
/*  7945 */       if (q > s + 1)
/*  7946 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(byte[] x, int[] m) {
/*  7950 */     int p = m[0];
/*  7951 */     int q = m[1];
/*  7952 */     int n = q - p + 1;
/*  7953 */     int k = (p + q) / 2;
/*  7954 */     if (n > 7) {
/*  7955 */       int j = p;
/*  7956 */       int l = q;
/*  7957 */       if (n > 40) {
/*  7958 */         int i = n / 8;
/*  7959 */         j = med3(x, j, j + i, j + 2 * i);
/*  7960 */         k = med3(x, k - i, k, k + i);
/*  7961 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  7963 */       k = med3(x, j, k, l);
/*       */     } 
/*  7965 */     byte y = x[k];
/*  7966 */     int a = p, b = p;
/*  7967 */     int c = q, d = q;
/*       */     while (true) {
/*  7969 */       if (b <= c && x[b] <= y) {
/*  7970 */         if (x[b] == y)
/*  7971 */           swap(x, a++, b); 
/*  7972 */         b++; continue;
/*       */       } 
/*  7974 */       while (c >= b && x[c] >= y) {
/*  7975 */         if (x[c] == y)
/*  7976 */           swap(x, c, d--); 
/*  7977 */         c--;
/*       */       } 
/*  7979 */       if (b > c)
/*       */         break; 
/*  7981 */       swap(x, b, c);
/*  7982 */       b++;
/*  7983 */       c--;
/*       */     } 
/*  7985 */     int r = Math.min(a - p, b - a);
/*  7986 */     int s = Math.min(d - c, q - d);
/*  7987 */     int t = q + 1;
/*  7988 */     swap(x, p, b - r, r);
/*  7989 */     swap(x, b, t - s, s);
/*  7990 */     m[0] = p + b - a;
/*  7991 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(byte[] x, int[] i, int[] m) {
/*  7994 */     int p = m[0];
/*  7995 */     int q = m[1];
/*  7996 */     int n = q - p + 1;
/*  7997 */     int k = (p + q) / 2;
/*  7998 */     if (n > 7) {
/*  7999 */       int j = p;
/*  8000 */       int l = q;
/*  8001 */       if (n > 40) {
/*  8002 */         int i1 = n / 8;
/*  8003 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8004 */         k = med3(x, i, k - i1, k, k + i1);
/*  8005 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8007 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8009 */     byte y = x[i[k]];
/*  8010 */     int a = p, b = p;
/*  8011 */     int c = q, d = q;
/*       */     while (true) {
/*  8013 */       if (b <= c && x[i[b]] <= y) {
/*  8014 */         if (x[i[b]] == y)
/*  8015 */           swap(i, a++, b); 
/*  8016 */         b++; continue;
/*       */       } 
/*  8018 */       while (c >= b && x[i[c]] >= y) {
/*  8019 */         if (x[i[c]] == y)
/*  8020 */           swap(i, c, d--); 
/*  8021 */         c--;
/*       */       } 
/*  8023 */       if (b > c)
/*       */         break; 
/*  8025 */       swap(i, b, c);
/*  8026 */       b++;
/*  8027 */       c--;
/*       */     } 
/*  8029 */     int r = Math.min(a - p, b - a);
/*  8030 */     int s = Math.min(d - c, q - d);
/*  8031 */     int t = q + 1;
/*  8032 */     swap(i, p, b - r, r);
/*  8033 */     swap(i, b, t - s, s);
/*  8034 */     m[0] = p + b - a;
/*  8035 */     m[1] = q - d - c;
/*       */   }
/*       */   private static int med3(short[] a, int i, int j, int k) {
/*  8038 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(short[] a, int[] i, int j, int k, int l) {
/*  8043 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(short[] a, int i, int j) {
/*  8048 */     short ai = a[i];
/*  8049 */     a[i] = a[j];
/*  8050 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(short[] a, int i, int j, int n) {
/*  8053 */     while (n > 0) {
/*  8054 */       short ai = a[i];
/*  8055 */       a[i++] = a[j];
/*  8056 */       a[j++] = ai;
/*  8057 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(short[] a, int p, int q) {
/*  8061 */     for (int i = p; i <= q; i++) {
/*  8062 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  8063 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(short[] a, int[] i, int p, int q) {
/*  8066 */     for (int j = p; j <= q; j++) {
/*  8067 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  8068 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(short[] a, int p, int q, int[] m) {
/*  8071 */     if (q - p <= 7) {
/*  8072 */       insertionSort(a, p, q);
/*       */     } else {
/*  8074 */       m[0] = p;
/*  8075 */       m[1] = q;
/*  8076 */       quickPartition(a, m);
/*  8077 */       int r = m[0];
/*  8078 */       int s = m[1];
/*  8079 */       if (p < r - 1)
/*  8080 */         quickSort(a, p, r - 1, m); 
/*  8081 */       if (q > s + 1)
/*  8082 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(short[] a, int[] i, int p, int q, int[] m) {
/*  8086 */     if (q - p <= 7) {
/*  8087 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  8089 */       m[0] = p;
/*  8090 */       m[1] = q;
/*  8091 */       quickPartition(a, i, m);
/*  8092 */       int r = m[0];
/*  8093 */       int s = m[1];
/*  8094 */       if (p < r - 1)
/*  8095 */         quickSort(a, i, p, r - 1, m); 
/*  8096 */       if (q > s + 1)
/*  8097 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(short[] x, int[] m) {
/*  8101 */     int p = m[0];
/*  8102 */     int q = m[1];
/*  8103 */     int n = q - p + 1;
/*  8104 */     int k = (p + q) / 2;
/*  8105 */     if (n > 7) {
/*  8106 */       int j = p;
/*  8107 */       int l = q;
/*  8108 */       if (n > 40) {
/*  8109 */         int i = n / 8;
/*  8110 */         j = med3(x, j, j + i, j + 2 * i);
/*  8111 */         k = med3(x, k - i, k, k + i);
/*  8112 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  8114 */       k = med3(x, j, k, l);
/*       */     } 
/*  8116 */     short y = x[k];
/*  8117 */     int a = p, b = p;
/*  8118 */     int c = q, d = q;
/*       */     while (true) {
/*  8120 */       if (b <= c && x[b] <= y) {
/*  8121 */         if (x[b] == y)
/*  8122 */           swap(x, a++, b); 
/*  8123 */         b++; continue;
/*       */       } 
/*  8125 */       while (c >= b && x[c] >= y) {
/*  8126 */         if (x[c] == y)
/*  8127 */           swap(x, c, d--); 
/*  8128 */         c--;
/*       */       } 
/*  8130 */       if (b > c)
/*       */         break; 
/*  8132 */       swap(x, b, c);
/*  8133 */       b++;
/*  8134 */       c--;
/*       */     } 
/*  8136 */     int r = Math.min(a - p, b - a);
/*  8137 */     int s = Math.min(d - c, q - d);
/*  8138 */     int t = q + 1;
/*  8139 */     swap(x, p, b - r, r);
/*  8140 */     swap(x, b, t - s, s);
/*  8141 */     m[0] = p + b - a;
/*  8142 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(short[] x, int[] i, int[] m) {
/*  8145 */     int p = m[0];
/*  8146 */     int q = m[1];
/*  8147 */     int n = q - p + 1;
/*  8148 */     int k = (p + q) / 2;
/*  8149 */     if (n > 7) {
/*  8150 */       int j = p;
/*  8151 */       int l = q;
/*  8152 */       if (n > 40) {
/*  8153 */         int i1 = n / 8;
/*  8154 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8155 */         k = med3(x, i, k - i1, k, k + i1);
/*  8156 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8158 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8160 */     short y = x[i[k]];
/*  8161 */     int a = p, b = p;
/*  8162 */     int c = q, d = q;
/*       */     while (true) {
/*  8164 */       if (b <= c && x[i[b]] <= y) {
/*  8165 */         if (x[i[b]] == y)
/*  8166 */           swap(i, a++, b); 
/*  8167 */         b++; continue;
/*       */       } 
/*  8169 */       while (c >= b && x[i[c]] >= y) {
/*  8170 */         if (x[i[c]] == y)
/*  8171 */           swap(i, c, d--); 
/*  8172 */         c--;
/*       */       } 
/*  8174 */       if (b > c)
/*       */         break; 
/*  8176 */       swap(i, b, c);
/*  8177 */       b++;
/*  8178 */       c--;
/*       */     } 
/*  8180 */     int r = Math.min(a - p, b - a);
/*  8181 */     int s = Math.min(d - c, q - d);
/*  8182 */     int t = q + 1;
/*  8183 */     swap(i, p, b - r, r);
/*  8184 */     swap(i, b, t - s, s);
/*  8185 */     m[0] = p + b - a;
/*  8186 */     m[1] = q - d - c;
/*       */   }
/*       */   private static int med3(int[] a, int i, int j, int k) {
/*  8189 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(int[] a, int[] i, int j, int k, int l) {
/*  8194 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(int[] a, int i, int j) {
/*  8199 */     int ai = a[i];
/*  8200 */     a[i] = a[j];
/*  8201 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(int[] a, int i, int j, int n) {
/*  8204 */     while (n > 0) {
/*  8205 */       int ai = a[i];
/*  8206 */       a[i++] = a[j];
/*  8207 */       a[j++] = ai;
/*  8208 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(int[] a, int p, int q) {
/*  8212 */     for (int i = p; i <= q; i++) {
/*  8213 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  8214 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(int[] a, int[] i, int p, int q) {
/*  8217 */     for (int j = p; j <= q; j++) {
/*  8218 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  8219 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(int[] a, int p, int q, int[] m) {
/*  8222 */     if (q - p <= 7) {
/*  8223 */       insertionSort(a, p, q);
/*       */     } else {
/*  8225 */       m[0] = p;
/*  8226 */       m[1] = q;
/*  8227 */       quickPartition(a, m);
/*  8228 */       int r = m[0];
/*  8229 */       int s = m[1];
/*  8230 */       if (p < r - 1)
/*  8231 */         quickSort(a, p, r - 1, m); 
/*  8232 */       if (q > s + 1)
/*  8233 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(int[] a, int[] i, int p, int q, int[] m) {
/*  8237 */     if (q - p <= 7) {
/*  8238 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  8240 */       m[0] = p;
/*  8241 */       m[1] = q;
/*  8242 */       quickPartition(a, i, m);
/*  8243 */       int r = m[0];
/*  8244 */       int s = m[1];
/*  8245 */       if (p < r - 1)
/*  8246 */         quickSort(a, i, p, r - 1, m); 
/*  8247 */       if (q > s + 1)
/*  8248 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(int[] x, int[] m) {
/*  8252 */     int p = m[0];
/*  8253 */     int q = m[1];
/*  8254 */     int n = q - p + 1;
/*  8255 */     int k = (p + q) / 2;
/*  8256 */     if (n > 7) {
/*  8257 */       int j = p;
/*  8258 */       int l = q;
/*  8259 */       if (n > 40) {
/*  8260 */         int i = n / 8;
/*  8261 */         j = med3(x, j, j + i, j + 2 * i);
/*  8262 */         k = med3(x, k - i, k, k + i);
/*  8263 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  8265 */       k = med3(x, j, k, l);
/*       */     } 
/*  8267 */     int y = x[k];
/*  8268 */     int a = p, b = p;
/*  8269 */     int c = q, d = q;
/*       */     while (true) {
/*  8271 */       if (b <= c && x[b] <= y) {
/*  8272 */         if (x[b] == y)
/*  8273 */           swap(x, a++, b); 
/*  8274 */         b++; continue;
/*       */       } 
/*  8276 */       while (c >= b && x[c] >= y) {
/*  8277 */         if (x[c] == y)
/*  8278 */           swap(x, c, d--); 
/*  8279 */         c--;
/*       */       } 
/*  8281 */       if (b > c)
/*       */         break; 
/*  8283 */       swap(x, b, c);
/*  8284 */       b++;
/*  8285 */       c--;
/*       */     } 
/*  8287 */     int r = Math.min(a - p, b - a);
/*  8288 */     int s = Math.min(d - c, q - d);
/*  8289 */     int t = q + 1;
/*  8290 */     swap(x, p, b - r, r);
/*  8291 */     swap(x, b, t - s, s);
/*  8292 */     m[0] = p + b - a;
/*  8293 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(int[] x, int[] i, int[] m) {
/*  8296 */     int p = m[0];
/*  8297 */     int q = m[1];
/*  8298 */     int n = q - p + 1;
/*  8299 */     int k = (p + q) / 2;
/*  8300 */     if (n > 7) {
/*  8301 */       int j = p;
/*  8302 */       int l = q;
/*  8303 */       if (n > 40) {
/*  8304 */         int i1 = n / 8;
/*  8305 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8306 */         k = med3(x, i, k - i1, k, k + i1);
/*  8307 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8309 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8311 */     int y = x[i[k]];
/*  8312 */     int a = p, b = p;
/*  8313 */     int c = q, d = q;
/*       */     while (true) {
/*  8315 */       if (b <= c && x[i[b]] <= y) {
/*  8316 */         if (x[i[b]] == y)
/*  8317 */           swap(i, a++, b); 
/*  8318 */         b++; continue;
/*       */       } 
/*  8320 */       while (c >= b && x[i[c]] >= y) {
/*  8321 */         if (x[i[c]] == y)
/*  8322 */           swap(i, c, d--); 
/*  8323 */         c--;
/*       */       } 
/*  8325 */       if (b > c)
/*       */         break; 
/*  8327 */       swap(i, b, c);
/*  8328 */       b++;
/*  8329 */       c--;
/*       */     } 
/*  8331 */     int r = Math.min(a - p, b - a);
/*  8332 */     int s = Math.min(d - c, q - d);
/*  8333 */     int t = q + 1;
/*  8334 */     swap(i, p, b - r, r);
/*  8335 */     swap(i, b, t - s, s);
/*  8336 */     m[0] = p + b - a;
/*  8337 */     m[1] = q - d - c;
/*       */   }
/*       */   private static int med3(long[] a, int i, int j, int k) {
/*  8340 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(long[] a, int[] i, int j, int k, int l) {
/*  8345 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(long[] a, int i, int j) {
/*  8350 */     long ai = a[i];
/*  8351 */     a[i] = a[j];
/*  8352 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(long[] a, int i, int j, int n) {
/*  8355 */     while (n > 0) {
/*  8356 */       long ai = a[i];
/*  8357 */       a[i++] = a[j];
/*  8358 */       a[j++] = ai;
/*  8359 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(long[] a, int p, int q) {
/*  8363 */     for (int i = p; i <= q; i++) {
/*  8364 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  8365 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(long[] a, int[] i, int p, int q) {
/*  8368 */     for (int j = p; j <= q; j++) {
/*  8369 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  8370 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(long[] a, int p, int q, int[] m) {
/*  8373 */     if (q - p <= 7) {
/*  8374 */       insertionSort(a, p, q);
/*       */     } else {
/*  8376 */       m[0] = p;
/*  8377 */       m[1] = q;
/*  8378 */       quickPartition(a, m);
/*  8379 */       int r = m[0];
/*  8380 */       int s = m[1];
/*  8381 */       if (p < r - 1)
/*  8382 */         quickSort(a, p, r - 1, m); 
/*  8383 */       if (q > s + 1)
/*  8384 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(long[] a, int[] i, int p, int q, int[] m) {
/*  8388 */     if (q - p <= 7) {
/*  8389 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  8391 */       m[0] = p;
/*  8392 */       m[1] = q;
/*  8393 */       quickPartition(a, i, m);
/*  8394 */       int r = m[0];
/*  8395 */       int s = m[1];
/*  8396 */       if (p < r - 1)
/*  8397 */         quickSort(a, i, p, r - 1, m); 
/*  8398 */       if (q > s + 1)
/*  8399 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(long[] x, int[] m) {
/*  8403 */     int p = m[0];
/*  8404 */     int q = m[1];
/*  8405 */     int n = q - p + 1;
/*  8406 */     int k = (p + q) / 2;
/*  8407 */     if (n > 7) {
/*  8408 */       int j = p;
/*  8409 */       int l = q;
/*  8410 */       if (n > 40) {
/*  8411 */         int i = n / 8;
/*  8412 */         j = med3(x, j, j + i, j + 2 * i);
/*  8413 */         k = med3(x, k - i, k, k + i);
/*  8414 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  8416 */       k = med3(x, j, k, l);
/*       */     } 
/*  8418 */     long y = x[k];
/*  8419 */     int a = p, b = p;
/*  8420 */     int c = q, d = q;
/*       */     while (true) {
/*  8422 */       if (b <= c && x[b] <= y) {
/*  8423 */         if (x[b] == y)
/*  8424 */           swap(x, a++, b); 
/*  8425 */         b++; continue;
/*       */       } 
/*  8427 */       while (c >= b && x[c] >= y) {
/*  8428 */         if (x[c] == y)
/*  8429 */           swap(x, c, d--); 
/*  8430 */         c--;
/*       */       } 
/*  8432 */       if (b > c)
/*       */         break; 
/*  8434 */       swap(x, b, c);
/*  8435 */       b++;
/*  8436 */       c--;
/*       */     } 
/*  8438 */     int r = Math.min(a - p, b - a);
/*  8439 */     int s = Math.min(d - c, q - d);
/*  8440 */     int t = q + 1;
/*  8441 */     swap(x, p, b - r, r);
/*  8442 */     swap(x, b, t - s, s);
/*  8443 */     m[0] = p + b - a;
/*  8444 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(long[] x, int[] i, int[] m) {
/*  8447 */     int p = m[0];
/*  8448 */     int q = m[1];
/*  8449 */     int n = q - p + 1;
/*  8450 */     int k = (p + q) / 2;
/*  8451 */     if (n > 7) {
/*  8452 */       int j = p;
/*  8453 */       int l = q;
/*  8454 */       if (n > 40) {
/*  8455 */         int i1 = n / 8;
/*  8456 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8457 */         k = med3(x, i, k - i1, k, k + i1);
/*  8458 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8460 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8462 */     long y = x[i[k]];
/*  8463 */     int a = p, b = p;
/*  8464 */     int c = q, d = q;
/*       */     while (true) {
/*  8466 */       if (b <= c && x[i[b]] <= y) {
/*  8467 */         if (x[i[b]] == y)
/*  8468 */           swap(i, a++, b); 
/*  8469 */         b++; continue;
/*       */       } 
/*  8471 */       while (c >= b && x[i[c]] >= y) {
/*  8472 */         if (x[i[c]] == y)
/*  8473 */           swap(i, c, d--); 
/*  8474 */         c--;
/*       */       } 
/*  8476 */       if (b > c)
/*       */         break; 
/*  8478 */       swap(i, b, c);
/*  8479 */       b++;
/*  8480 */       c--;
/*       */     } 
/*  8482 */     int r = Math.min(a - p, b - a);
/*  8483 */     int s = Math.min(d - c, q - d);
/*  8484 */     int t = q + 1;
/*  8485 */     swap(i, p, b - r, r);
/*  8486 */     swap(i, b, t - s, s);
/*  8487 */     m[0] = p + b - a;
/*  8488 */     m[1] = q - d - c;
/*       */   }
/*       */   private static int med3(float[] a, int i, int j, int k) {
/*  8491 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(float[] a, int[] i, int j, int k, int l) {
/*  8496 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(float[] a, int i, int j) {
/*  8501 */     float ai = a[i];
/*  8502 */     a[i] = a[j];
/*  8503 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(float[] a, int i, int j, int n) {
/*  8506 */     while (n > 0) {
/*  8507 */       float ai = a[i];
/*  8508 */       a[i++] = a[j];
/*  8509 */       a[j++] = ai;
/*  8510 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(float[] a, int p, int q) {
/*  8514 */     for (int i = p; i <= q; i++) {
/*  8515 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  8516 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(float[] a, int[] i, int p, int q) {
/*  8519 */     for (int j = p; j <= q; j++) {
/*  8520 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  8521 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(float[] a, int p, int q, int[] m) {
/*  8524 */     if (q - p <= 7) {
/*  8525 */       insertionSort(a, p, q);
/*       */     } else {
/*  8527 */       m[0] = p;
/*  8528 */       m[1] = q;
/*  8529 */       quickPartition(a, m);
/*  8530 */       int r = m[0];
/*  8531 */       int s = m[1];
/*  8532 */       if (p < r - 1)
/*  8533 */         quickSort(a, p, r - 1, m); 
/*  8534 */       if (q > s + 1)
/*  8535 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(float[] a, int[] i, int p, int q, int[] m) {
/*  8539 */     if (q - p <= 7) {
/*  8540 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  8542 */       m[0] = p;
/*  8543 */       m[1] = q;
/*  8544 */       quickPartition(a, i, m);
/*  8545 */       int r = m[0];
/*  8546 */       int s = m[1];
/*  8547 */       if (p < r - 1)
/*  8548 */         quickSort(a, i, p, r - 1, m); 
/*  8549 */       if (q > s + 1)
/*  8550 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(float[] x, int[] m) {
/*  8554 */     int p = m[0];
/*  8555 */     int q = m[1];
/*  8556 */     int n = q - p + 1;
/*  8557 */     int k = (p + q) / 2;
/*  8558 */     if (n > 7) {
/*  8559 */       int j = p;
/*  8560 */       int l = q;
/*  8561 */       if (n > 40) {
/*  8562 */         int i = n / 8;
/*  8563 */         j = med3(x, j, j + i, j + 2 * i);
/*  8564 */         k = med3(x, k - i, k, k + i);
/*  8565 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  8567 */       k = med3(x, j, k, l);
/*       */     } 
/*  8569 */     float y = x[k];
/*  8570 */     int a = p, b = p;
/*  8571 */     int c = q, d = q;
/*       */     while (true) {
/*  8573 */       if (b <= c && x[b] <= y) {
/*  8574 */         if (x[b] == y)
/*  8575 */           swap(x, a++, b); 
/*  8576 */         b++; continue;
/*       */       } 
/*  8578 */       while (c >= b && x[c] >= y) {
/*  8579 */         if (x[c] == y)
/*  8580 */           swap(x, c, d--); 
/*  8581 */         c--;
/*       */       } 
/*  8583 */       if (b > c)
/*       */         break; 
/*  8585 */       swap(x, b, c);
/*  8586 */       b++;
/*  8587 */       c--;
/*       */     } 
/*  8589 */     int r = Math.min(a - p, b - a);
/*  8590 */     int s = Math.min(d - c, q - d);
/*  8591 */     int t = q + 1;
/*  8592 */     swap(x, p, b - r, r);
/*  8593 */     swap(x, b, t - s, s);
/*  8594 */     m[0] = p + b - a;
/*  8595 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(float[] x, int[] i, int[] m) {
/*  8598 */     int p = m[0];
/*  8599 */     int q = m[1];
/*  8600 */     int n = q - p + 1;
/*  8601 */     int k = (p + q) / 2;
/*  8602 */     if (n > 7) {
/*  8603 */       int j = p;
/*  8604 */       int l = q;
/*  8605 */       if (n > 40) {
/*  8606 */         int i1 = n / 8;
/*  8607 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8608 */         k = med3(x, i, k - i1, k, k + i1);
/*  8609 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8611 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8613 */     float y = x[i[k]];
/*  8614 */     int a = p, b = p;
/*  8615 */     int c = q, d = q;
/*       */     while (true) {
/*  8617 */       if (b <= c && x[i[b]] <= y) {
/*  8618 */         if (x[i[b]] == y)
/*  8619 */           swap(i, a++, b); 
/*  8620 */         b++; continue;
/*       */       } 
/*  8622 */       while (c >= b && x[i[c]] >= y) {
/*  8623 */         if (x[i[c]] == y)
/*  8624 */           swap(i, c, d--); 
/*  8625 */         c--;
/*       */       } 
/*  8627 */       if (b > c)
/*       */         break; 
/*  8629 */       swap(i, b, c);
/*  8630 */       b++;
/*  8631 */       c--;
/*       */     } 
/*  8633 */     int r = Math.min(a - p, b - a);
/*  8634 */     int s = Math.min(d - c, q - d);
/*  8635 */     int t = q + 1;
/*  8636 */     swap(i, p, b - r, r);
/*  8637 */     swap(i, b, t - s, s);
/*  8638 */     m[0] = p + b - a;
/*  8639 */     m[1] = q - d - c;
/*       */   }
/*       */   private static int med3(double[] a, int i, int j, int k) {
/*  8642 */     return (a[i] < a[j]) ? ((a[j] < a[k]) ? j : ((a[i] < a[k]) ? k : i)) : ((a[j] > a[k]) ? j : ((a[i] > a[k]) ? k : i));
/*       */   }
/*       */ 
/*       */   
/*       */   private static int med3(double[] a, int[] i, int j, int k, int l) {
/*  8647 */     return (a[i[j]] < a[i[k]]) ? ((a[i[k]] < a[i[l]]) ? k : ((a[i[j]] < a[i[l]]) ? l : j)) : ((a[i[k]] > a[i[l]]) ? k : ((a[i[j]] > a[i[l]]) ? l : j));
/*       */   }
/*       */ 
/*       */   
/*       */   private static void swap(double[] a, int i, int j) {
/*  8652 */     double ai = a[i];
/*  8653 */     a[i] = a[j];
/*  8654 */     a[j] = ai;
/*       */   }
/*       */   private static void swap(double[] a, int i, int j, int n) {
/*  8657 */     while (n > 0) {
/*  8658 */       double ai = a[i];
/*  8659 */       a[i++] = a[j];
/*  8660 */       a[j++] = ai;
/*  8661 */       n--;
/*       */     } 
/*       */   }
/*       */   private static void insertionSort(double[] a, int p, int q) {
/*  8665 */     for (int i = p; i <= q; i++) {
/*  8666 */       for (int j = i; j > p && a[j - 1] > a[j]; j--)
/*  8667 */         swap(a, j, j - 1); 
/*       */     } 
/*       */   } private static void insertionSort(double[] a, int[] i, int p, int q) {
/*  8670 */     for (int j = p; j <= q; j++) {
/*  8671 */       for (int k = j; k > p && a[i[k - 1]] > a[i[k]]; k--)
/*  8672 */         swap(i, k, k - 1); 
/*       */     } 
/*       */   } private static void quickSort(double[] a, int p, int q, int[] m) {
/*  8675 */     if (q - p <= 7) {
/*  8676 */       insertionSort(a, p, q);
/*       */     } else {
/*  8678 */       m[0] = p;
/*  8679 */       m[1] = q;
/*  8680 */       quickPartition(a, m);
/*  8681 */       int r = m[0];
/*  8682 */       int s = m[1];
/*  8683 */       if (p < r - 1)
/*  8684 */         quickSort(a, p, r - 1, m); 
/*  8685 */       if (q > s + 1)
/*  8686 */         quickSort(a, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickSort(double[] a, int[] i, int p, int q, int[] m) {
/*  8690 */     if (q - p <= 7) {
/*  8691 */       insertionSort(a, i, p, q);
/*       */     } else {
/*  8693 */       m[0] = p;
/*  8694 */       m[1] = q;
/*  8695 */       quickPartition(a, i, m);
/*  8696 */       int r = m[0];
/*  8697 */       int s = m[1];
/*  8698 */       if (p < r - 1)
/*  8699 */         quickSort(a, i, p, r - 1, m); 
/*  8700 */       if (q > s + 1)
/*  8701 */         quickSort(a, i, s + 1, q, m); 
/*       */     } 
/*       */   }
/*       */   private static void quickPartition(double[] x, int[] m) {
/*  8705 */     int p = m[0];
/*  8706 */     int q = m[1];
/*  8707 */     int n = q - p + 1;
/*  8708 */     int k = (p + q) / 2;
/*  8709 */     if (n > 7) {
/*  8710 */       int j = p;
/*  8711 */       int l = q;
/*  8712 */       if (n > 40) {
/*  8713 */         int i = n / 8;
/*  8714 */         j = med3(x, j, j + i, j + 2 * i);
/*  8715 */         k = med3(x, k - i, k, k + i);
/*  8716 */         l = med3(x, l - 2 * i, l - i, l);
/*       */       } 
/*  8718 */       k = med3(x, j, k, l);
/*       */     } 
/*  8720 */     double y = x[k];
/*  8721 */     int a = p, b = p;
/*  8722 */     int c = q, d = q;
/*       */     while (true) {
/*  8724 */       if (b <= c && x[b] <= y) {
/*  8725 */         if (x[b] == y)
/*  8726 */           swap(x, a++, b); 
/*  8727 */         b++; continue;
/*       */       } 
/*  8729 */       while (c >= b && x[c] >= y) {
/*  8730 */         if (x[c] == y)
/*  8731 */           swap(x, c, d--); 
/*  8732 */         c--;
/*       */       } 
/*  8734 */       if (b > c)
/*       */         break; 
/*  8736 */       swap(x, b, c);
/*  8737 */       b++;
/*  8738 */       c--;
/*       */     } 
/*  8740 */     int r = Math.min(a - p, b - a);
/*  8741 */     int s = Math.min(d - c, q - d);
/*  8742 */     int t = q + 1;
/*  8743 */     swap(x, p, b - r, r);
/*  8744 */     swap(x, b, t - s, s);
/*  8745 */     m[0] = p + b - a;
/*  8746 */     m[1] = q - d - c;
/*       */   }
/*       */   private static void quickPartition(double[] x, int[] i, int[] m) {
/*  8749 */     int p = m[0];
/*  8750 */     int q = m[1];
/*  8751 */     int n = q - p + 1;
/*  8752 */     int k = (p + q) / 2;
/*  8753 */     if (n > 7) {
/*  8754 */       int j = p;
/*  8755 */       int l = q;
/*  8756 */       if (n > 40) {
/*  8757 */         int i1 = n / 8;
/*  8758 */         j = med3(x, i, j, j + i1, j + 2 * i1);
/*  8759 */         k = med3(x, i, k - i1, k, k + i1);
/*  8760 */         l = med3(x, i, l - 2 * i1, l - i1, l);
/*       */       } 
/*  8762 */       k = med3(x, i, j, k, l);
/*       */     } 
/*  8764 */     double y = x[i[k]];
/*  8765 */     int a = p, b = p;
/*  8766 */     int c = q, d = q;
/*       */     while (true) {
/*  8768 */       if (b <= c && x[i[b]] <= y) {
/*  8769 */         if (x[i[b]] == y)
/*  8770 */           swap(i, a++, b); 
/*  8771 */         b++; continue;
/*       */       } 
/*  8773 */       while (c >= b && x[i[c]] >= y) {
/*  8774 */         if (x[i[c]] == y)
/*  8775 */           swap(i, c, d--); 
/*  8776 */         c--;
/*       */       } 
/*  8778 */       if (b > c)
/*       */         break; 
/*  8780 */       swap(i, b, c);
/*  8781 */       b++;
/*  8782 */       c--;
/*       */     } 
/*  8784 */     int r = Math.min(a - p, b - a);
/*  8785 */     int s = Math.min(d - c, q - d);
/*  8786 */     int t = q + 1;
/*  8787 */     swap(i, p, b - r, r);
/*  8788 */     swap(i, b, t - s, s);
/*  8789 */     m[0] = p + b - a;
/*  8790 */     m[1] = q - d - c;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(byte[] a, byte x) {
/*  8809 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(byte[] a, byte x, int i) {
/*  8830 */     int n = a.length;
/*  8831 */     int nm1 = n - 1;
/*  8832 */     int low = 0;
/*  8833 */     int high = nm1;
/*  8834 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  8835 */     if (i < n) {
/*  8836 */       high = (0 <= i) ? i : -(i + 1);
/*  8837 */       low = high - 1;
/*  8838 */       int step = 1;
/*  8839 */       if (increasing) {
/*  8840 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  8841 */           high = low; 
/*  8842 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  8843 */           low = high; 
/*       */       } else {
/*  8845 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  8846 */           high = low; 
/*  8847 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  8848 */           low = high; 
/*       */       } 
/*  8850 */       if (low < 0) low = 0; 
/*  8851 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  8853 */     if (increasing) {
/*  8854 */       while (low <= high) {
/*  8855 */         int mid = low + high >> 1;
/*  8856 */         byte amid = a[mid];
/*  8857 */         if (amid < x) {
/*  8858 */           low = mid + 1; continue;
/*  8859 */         }  if (amid > x) {
/*  8860 */           high = mid - 1; continue;
/*       */         } 
/*  8862 */         return mid;
/*       */       } 
/*       */     } else {
/*  8865 */       while (low <= high) {
/*  8866 */         int mid = low + high >> 1;
/*  8867 */         byte amid = a[mid];
/*  8868 */         if (amid > x) {
/*  8869 */           low = mid + 1; continue;
/*  8870 */         }  if (amid < x) {
/*  8871 */           high = mid - 1; continue;
/*       */         } 
/*  8873 */         return mid;
/*       */       } 
/*       */     } 
/*  8876 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(short[] a, short x) {
/*  8892 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(short[] a, short x, int i) {
/*  8913 */     int n = a.length;
/*  8914 */     int nm1 = n - 1;
/*  8915 */     int low = 0;
/*  8916 */     int high = nm1;
/*  8917 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  8918 */     if (i < n) {
/*  8919 */       high = (0 <= i) ? i : -(i + 1);
/*  8920 */       low = high - 1;
/*  8921 */       int step = 1;
/*  8922 */       if (increasing) {
/*  8923 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  8924 */           high = low; 
/*  8925 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  8926 */           low = high; 
/*       */       } else {
/*  8928 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  8929 */           high = low; 
/*  8930 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  8931 */           low = high; 
/*       */       } 
/*  8933 */       if (low < 0) low = 0; 
/*  8934 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  8936 */     if (increasing) {
/*  8937 */       while (low <= high) {
/*  8938 */         int mid = low + high >> 1;
/*  8939 */         short amid = a[mid];
/*  8940 */         if (amid < x) {
/*  8941 */           low = mid + 1; continue;
/*  8942 */         }  if (amid > x) {
/*  8943 */           high = mid - 1; continue;
/*       */         } 
/*  8945 */         return mid;
/*       */       } 
/*       */     } else {
/*  8948 */       while (low <= high) {
/*  8949 */         int mid = low + high >> 1;
/*  8950 */         short amid = a[mid];
/*  8951 */         if (amid > x) {
/*  8952 */           low = mid + 1; continue;
/*  8953 */         }  if (amid < x) {
/*  8954 */           high = mid - 1; continue;
/*       */         } 
/*  8956 */         return mid;
/*       */       } 
/*       */     } 
/*  8959 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(int[] a, int x) {
/*  8975 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(int[] a, int x, int i) {
/*  8996 */     int n = a.length;
/*  8997 */     int nm1 = n - 1;
/*  8998 */     int low = 0;
/*  8999 */     int high = nm1;
/*  9000 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  9001 */     if (i < n) {
/*  9002 */       high = (0 <= i) ? i : -(i + 1);
/*  9003 */       low = high - 1;
/*  9004 */       int step = 1;
/*  9005 */       if (increasing) {
/*  9006 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  9007 */           high = low; 
/*  9008 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  9009 */           low = high; 
/*       */       } else {
/*  9011 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  9012 */           high = low; 
/*  9013 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  9014 */           low = high; 
/*       */       } 
/*  9016 */       if (low < 0) low = 0; 
/*  9017 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  9019 */     if (increasing) {
/*  9020 */       while (low <= high) {
/*  9021 */         int mid = low + high >> 1;
/*  9022 */         int amid = a[mid];
/*  9023 */         if (amid < x) {
/*  9024 */           low = mid + 1; continue;
/*  9025 */         }  if (amid > x) {
/*  9026 */           high = mid - 1; continue;
/*       */         } 
/*  9028 */         return mid;
/*       */       } 
/*       */     } else {
/*  9031 */       while (low <= high) {
/*  9032 */         int mid = low + high >> 1;
/*  9033 */         int amid = a[mid];
/*  9034 */         if (amid > x) {
/*  9035 */           low = mid + 1; continue;
/*  9036 */         }  if (amid < x) {
/*  9037 */           high = mid - 1; continue;
/*       */         } 
/*  9039 */         return mid;
/*       */       } 
/*       */     } 
/*  9042 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(long[] a, long x) {
/*  9058 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(long[] a, long x, int i) {
/*  9079 */     int n = a.length;
/*  9080 */     int nm1 = n - 1;
/*  9081 */     int low = 0;
/*  9082 */     int high = nm1;
/*  9083 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  9084 */     if (i < n) {
/*  9085 */       high = (0 <= i) ? i : -(i + 1);
/*  9086 */       low = high - 1;
/*  9087 */       int step = 1;
/*  9088 */       if (increasing) {
/*  9089 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  9090 */           high = low; 
/*  9091 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  9092 */           low = high; 
/*       */       } else {
/*  9094 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  9095 */           high = low; 
/*  9096 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  9097 */           low = high; 
/*       */       } 
/*  9099 */       if (low < 0) low = 0; 
/*  9100 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  9102 */     if (increasing) {
/*  9103 */       while (low <= high) {
/*  9104 */         int mid = low + high >> 1;
/*  9105 */         long amid = a[mid];
/*  9106 */         if (amid < x) {
/*  9107 */           low = mid + 1; continue;
/*  9108 */         }  if (amid > x) {
/*  9109 */           high = mid - 1; continue;
/*       */         } 
/*  9111 */         return mid;
/*       */       } 
/*       */     } else {
/*  9114 */       while (low <= high) {
/*  9115 */         int mid = low + high >> 1;
/*  9116 */         long amid = a[mid];
/*  9117 */         if (amid > x) {
/*  9118 */           low = mid + 1; continue;
/*  9119 */         }  if (amid < x) {
/*  9120 */           high = mid - 1; continue;
/*       */         } 
/*  9122 */         return mid;
/*       */       } 
/*       */     } 
/*  9125 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(float[] a, float x) {
/*  9141 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(float[] a, float x, int i) {
/*  9162 */     int n = a.length;
/*  9163 */     int nm1 = n - 1;
/*  9164 */     int low = 0;
/*  9165 */     int high = nm1;
/*  9166 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  9167 */     if (i < n) {
/*  9168 */       high = (0 <= i) ? i : -(i + 1);
/*  9169 */       low = high - 1;
/*  9170 */       int step = 1;
/*  9171 */       if (increasing) {
/*  9172 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  9173 */           high = low; 
/*  9174 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  9175 */           low = high; 
/*       */       } else {
/*  9177 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  9178 */           high = low; 
/*  9179 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  9180 */           low = high; 
/*       */       } 
/*  9182 */       if (low < 0) low = 0; 
/*  9183 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  9185 */     if (increasing) {
/*  9186 */       while (low <= high) {
/*  9187 */         int mid = low + high >> 1;
/*  9188 */         float amid = a[mid];
/*  9189 */         if (amid < x) {
/*  9190 */           low = mid + 1; continue;
/*  9191 */         }  if (amid > x) {
/*  9192 */           high = mid - 1; continue;
/*       */         } 
/*  9194 */         return mid;
/*       */       } 
/*       */     } else {
/*  9197 */       while (low <= high) {
/*  9198 */         int mid = low + high >> 1;
/*  9199 */         float amid = a[mid];
/*  9200 */         if (amid > x) {
/*  9201 */           low = mid + 1; continue;
/*  9202 */         }  if (amid < x) {
/*  9203 */           high = mid - 1; continue;
/*       */         } 
/*  9205 */         return mid;
/*       */       } 
/*       */     } 
/*  9208 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(double[] a, double x) {
/*  9224 */     return binarySearch(a, x, a.length);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static int binarySearch(double[] a, double x, int i) {
/*  9245 */     int n = a.length;
/*  9246 */     int nm1 = n - 1;
/*  9247 */     int low = 0;
/*  9248 */     int high = nm1;
/*  9249 */     boolean increasing = (n < 2 || a[0] < a[1]);
/*  9250 */     if (i < n) {
/*  9251 */       high = (0 <= i) ? i : -(i + 1);
/*  9252 */       low = high - 1;
/*  9253 */       int step = 1;
/*  9254 */       if (increasing) {
/*  9255 */         for (; 0 < low && x < a[low]; low -= step, step += step)
/*  9256 */           high = low; 
/*  9257 */         for (; high < nm1 && a[high] < x; high += step, step += step)
/*  9258 */           low = high; 
/*       */       } else {
/*  9260 */         for (; 0 < low && x > a[low]; low -= step, step += step)
/*  9261 */           high = low; 
/*  9262 */         for (; high < nm1 && a[high] > x; high += step, step += step)
/*  9263 */           low = high; 
/*       */       } 
/*  9265 */       if (low < 0) low = 0; 
/*  9266 */       if (high > nm1) high = nm1; 
/*       */     } 
/*  9268 */     if (increasing) {
/*  9269 */       while (low <= high) {
/*  9270 */         int mid = low + high >> 1;
/*  9271 */         double amid = a[mid];
/*  9272 */         if (amid < x) {
/*  9273 */           low = mid + 1; continue;
/*  9274 */         }  if (amid > x) {
/*  9275 */           high = mid - 1; continue;
/*       */         } 
/*  9277 */         return mid;
/*       */       } 
/*       */     } else {
/*  9280 */       while (low <= high) {
/*  9281 */         int mid = low + high >> 1;
/*  9282 */         double amid = a[mid];
/*  9283 */         if (amid > x) {
/*  9284 */           low = mid + 1; continue;
/*  9285 */         }  if (amid < x) {
/*  9286 */           high = mid - 1; continue;
/*       */         } 
/*  9288 */         return mid;
/*       */       } 
/*       */     } 
/*  9291 */     return -(low + 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] add(float[] rx, float[] ry) {
/*  9298 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static float[] add(float ra, float[] ry) {
/*  9301 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static float[] add(float[] rx, float rb) {
/*  9304 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static float[][] add(float[][] rx, float[][] ry) {
/*  9307 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static float[][] add(float ra, float[][] ry) {
/*  9310 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static float[][] add(float[][] rx, float rb) {
/*  9313 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static float[][][] add(float[][][] rx, float[][][] ry) {
/*  9316 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] add(float ra, float[][][] ry) {
/*  9319 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static float[][][] add(float[][][] rx, float rb) {
/*  9322 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static void add(float[] rx, float[] ry, float[] rz) {
/*  9325 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(float ra, float[] ry, float[] rz) {
/*  9328 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(float[] rx, float rb, float[] rz) {
/*  9331 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static void add(float[][] rx, float[][] ry, float[][] rz) {
/*  9334 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(float ra, float[][] ry, float[][] rz) {
/*  9337 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(float[][] rx, float rb, float[][] rz) {
/*  9340 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static void add(float[][][] rx, float[][][] ry, float[][][] rz) {
/*  9343 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(float ra, float[][][] ry, float[][][] rz) {
/*  9346 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(float[][][] rx, float rb, float[][][] rz) {
/*  9349 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static float[] sub(float[] rx, float[] ry) {
/*  9352 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static float[] sub(float ra, float[] ry) {
/*  9355 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static float[] sub(float[] rx, float rb) {
/*  9358 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static float[][] sub(float[][] rx, float[][] ry) {
/*  9361 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static float[][] sub(float ra, float[][] ry) {
/*  9364 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static float[][] sub(float[][] rx, float rb) {
/*  9367 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static float[][][] sub(float[][][] rx, float[][][] ry) {
/*  9370 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] sub(float ra, float[][][] ry) {
/*  9373 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static float[][][] sub(float[][][] rx, float rb) {
/*  9376 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static void sub(float[] rx, float[] ry, float[] rz) {
/*  9379 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(float ra, float[] ry, float[] rz) {
/*  9382 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(float[] rx, float rb, float[] rz) {
/*  9385 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static void sub(float[][] rx, float[][] ry, float[][] rz) {
/*  9388 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(float ra, float[][] ry, float[][] rz) {
/*  9391 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(float[][] rx, float rb, float[][] rz) {
/*  9394 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static void sub(float[][][] rx, float[][][] ry, float[][][] rz) {
/*  9397 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(float ra, float[][][] ry, float[][][] rz) {
/*  9400 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(float[][][] rx, float rb, float[][][] rz) {
/*  9403 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static float[] mul(float[] rx, float[] ry) {
/*  9406 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static float[] mul(float ra, float[] ry) {
/*  9409 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static float[] mul(float[] rx, float rb) {
/*  9412 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static float[][] mul(float[][] rx, float[][] ry) {
/*  9415 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static float[][] mul(float ra, float[][] ry) {
/*  9418 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static float[][] mul(float[][] rx, float rb) {
/*  9421 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static float[][][] mul(float[][][] rx, float[][][] ry) {
/*  9424 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] mul(float ra, float[][][] ry) {
/*  9427 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static float[][][] mul(float[][][] rx, float rb) {
/*  9430 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static void mul(float[] rx, float[] ry, float[] rz) {
/*  9433 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(float ra, float[] ry, float[] rz) {
/*  9436 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(float[] rx, float rb, float[] rz) {
/*  9439 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static void mul(float[][] rx, float[][] ry, float[][] rz) {
/*  9442 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(float ra, float[][] ry, float[][] rz) {
/*  9445 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(float[][] rx, float rb, float[][] rz) {
/*  9448 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static void mul(float[][][] rx, float[][][] ry, float[][][] rz) {
/*  9451 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(float ra, float[][][] ry, float[][][] rz) {
/*  9454 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(float[][][] rx, float rb, float[][][] rz) {
/*  9457 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static float[] div(float[] rx, float[] ry) {
/*  9460 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static float[] div(float ra, float[] ry) {
/*  9463 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static float[] div(float[] rx, float rb) {
/*  9466 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static float[][] div(float[][] rx, float[][] ry) {
/*  9469 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static float[][] div(float ra, float[][] ry) {
/*  9472 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static float[][] div(float[][] rx, float rb) {
/*  9475 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static float[][][] div(float[][][] rx, float[][][] ry) {
/*  9478 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] div(float ra, float[][][] ry) {
/*  9481 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static float[][][] div(float[][][] rx, float rb) {
/*  9484 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static void div(float[] rx, float[] ry, float[] rz) {
/*  9487 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(float ra, float[] ry, float[] rz) {
/*  9490 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(float[] rx, float rb, float[] rz) {
/*  9493 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   public static void div(float[][] rx, float[][] ry, float[][] rz) {
/*  9496 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(float ra, float[][] ry, float[][] rz) {
/*  9499 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(float[][] rx, float rb, float[][] rz) {
/*  9502 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   public static void div(float[][][] rx, float[][][] ry, float[][][] rz) {
/*  9505 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(float ra, float[][][] ry, float[][][] rz) {
/*  9508 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(float[][][] rx, float rb, float[][][] rz) {
/*  9511 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   public static double[] add(double[] rx, double[] ry) {
/*  9514 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static double[] add(double ra, double[] ry) {
/*  9517 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static double[] add(double[] rx, double rb) {
/*  9520 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static double[][] add(double[][] rx, double[][] ry) {
/*  9523 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static double[][] add(double ra, double[][] ry) {
/*  9526 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static double[][] add(double[][] rx, double rb) {
/*  9529 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static double[][][] add(double[][][] rx, double[][][] ry) {
/*  9532 */     return _add.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] add(double ra, double[][][] ry) {
/*  9535 */     return _add.apply(ra, ry);
/*       */   }
/*       */   public static double[][][] add(double[][][] rx, double rb) {
/*  9538 */     return _add.apply(rx, rb);
/*       */   }
/*       */   public static void add(double[] rx, double[] ry, double[] rz) {
/*  9541 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(double ra, double[] ry, double[] rz) {
/*  9544 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(double[] rx, double rb, double[] rz) {
/*  9547 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static void add(double[][] rx, double[][] ry, double[][] rz) {
/*  9550 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(double ra, double[][] ry, double[][] rz) {
/*  9553 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(double[][] rx, double rb, double[][] rz) {
/*  9556 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static void add(double[][][] rx, double[][][] ry, double[][][] rz) {
/*  9559 */     _add.apply(rx, ry, rz);
/*       */   }
/*       */   public static void add(double ra, double[][][] ry, double[][][] rz) {
/*  9562 */     _add.apply(ra, ry, rz);
/*       */   }
/*       */   public static void add(double[][][] rx, double rb, double[][][] rz) {
/*  9565 */     _add.apply(rx, rb, rz);
/*       */   }
/*       */   public static double[] sub(double[] rx, double[] ry) {
/*  9568 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static double[] sub(double ra, double[] ry) {
/*  9571 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static double[] sub(double[] rx, double rb) {
/*  9574 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static double[][] sub(double[][] rx, double[][] ry) {
/*  9577 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static double[][] sub(double ra, double[][] ry) {
/*  9580 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static double[][] sub(double[][] rx, double rb) {
/*  9583 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static double[][][] sub(double[][][] rx, double[][][] ry) {
/*  9586 */     return _sub.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] sub(double ra, double[][][] ry) {
/*  9589 */     return _sub.apply(ra, ry);
/*       */   }
/*       */   public static double[][][] sub(double[][][] rx, double rb) {
/*  9592 */     return _sub.apply(rx, rb);
/*       */   }
/*       */   public static void sub(double[] rx, double[] ry, double[] rz) {
/*  9595 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(double ra, double[] ry, double[] rz) {
/*  9598 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(double[] rx, double rb, double[] rz) {
/*  9601 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static void sub(double[][] rx, double[][] ry, double[][] rz) {
/*  9604 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(double ra, double[][] ry, double[][] rz) {
/*  9607 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(double[][] rx, double rb, double[][] rz) {
/*  9610 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static void sub(double[][][] rx, double[][][] ry, double[][][] rz) {
/*  9613 */     _sub.apply(rx, ry, rz);
/*       */   }
/*       */   public static void sub(double ra, double[][][] ry, double[][][] rz) {
/*  9616 */     _sub.apply(ra, ry, rz);
/*       */   }
/*       */   public static void sub(double[][][] rx, double rb, double[][][] rz) {
/*  9619 */     _sub.apply(rx, rb, rz);
/*       */   }
/*       */   public static double[] mul(double[] rx, double[] ry) {
/*  9622 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static double[] mul(double ra, double[] ry) {
/*  9625 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static double[] mul(double[] rx, double rb) {
/*  9628 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static double[][] mul(double[][] rx, double[][] ry) {
/*  9631 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static double[][] mul(double ra, double[][] ry) {
/*  9634 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static double[][] mul(double[][] rx, double rb) {
/*  9637 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static double[][][] mul(double[][][] rx, double[][][] ry) {
/*  9640 */     return _mul.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] mul(double ra, double[][][] ry) {
/*  9643 */     return _mul.apply(ra, ry);
/*       */   }
/*       */   public static double[][][] mul(double[][][] rx, double rb) {
/*  9646 */     return _mul.apply(rx, rb);
/*       */   }
/*       */   public static void mul(double[] rx, double[] ry, double[] rz) {
/*  9649 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(double ra, double[] ry, double[] rz) {
/*  9652 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(double[] rx, double rb, double[] rz) {
/*  9655 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static void mul(double[][] rx, double[][] ry, double[][] rz) {
/*  9658 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(double ra, double[][] ry, double[][] rz) {
/*  9661 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(double[][] rx, double rb, double[][] rz) {
/*  9664 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static void mul(double[][][] rx, double[][][] ry, double[][][] rz) {
/*  9667 */     _mul.apply(rx, ry, rz);
/*       */   }
/*       */   public static void mul(double ra, double[][][] ry, double[][][] rz) {
/*  9670 */     _mul.apply(ra, ry, rz);
/*       */   }
/*       */   public static void mul(double[][][] rx, double rb, double[][][] rz) {
/*  9673 */     _mul.apply(rx, rb, rz);
/*       */   }
/*       */   public static double[] div(double[] rx, double[] ry) {
/*  9676 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static double[] div(double ra, double[] ry) {
/*  9679 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static double[] div(double[] rx, double rb) {
/*  9682 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static double[][] div(double[][] rx, double[][] ry) {
/*  9685 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static double[][] div(double ra, double[][] ry) {
/*  9688 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static double[][] div(double[][] rx, double rb) {
/*  9691 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static double[][][] div(double[][][] rx, double[][][] ry) {
/*  9694 */     return _div.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] div(double ra, double[][][] ry) {
/*  9697 */     return _div.apply(ra, ry);
/*       */   }
/*       */   public static double[][][] div(double[][][] rx, double rb) {
/*  9700 */     return _div.apply(rx, rb);
/*       */   }
/*       */   public static void div(double[] rx, double[] ry, double[] rz) {
/*  9703 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(double ra, double[] ry, double[] rz) {
/*  9706 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(double[] rx, double rb, double[] rz) {
/*  9709 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   public static void div(double[][] rx, double[][] ry, double[][] rz) {
/*  9712 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(double ra, double[][] ry, double[][] rz) {
/*  9715 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(double[][] rx, double rb, double[][] rz) {
/*  9718 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   public static void div(double[][][] rx, double[][][] ry, double[][][] rz) {
/*  9721 */     _div.apply(rx, ry, rz);
/*       */   }
/*       */   public static void div(double ra, double[][][] ry, double[][][] rz) {
/*  9724 */     _div.apply(ra, ry, rz);
/*       */   }
/*       */   public static void div(double[][][] rx, double rb, double[][][] rz) {
/*  9727 */     _div.apply(rx, rb, rz);
/*       */   }
/*       */   private static abstract class Binary { private Binary() {}
/*       */     float[] apply(float[] rx, float[] ry) {
/*  9731 */       int n1 = rx.length;
/*  9732 */       float[] rz = new float[n1];
/*  9733 */       apply(rx, ry, rz);
/*  9734 */       return rz;
/*       */     }
/*       */     float[] apply(float ra, float[] ry) {
/*  9737 */       int n1 = ry.length;
/*  9738 */       float[] rz = new float[n1];
/*  9739 */       apply(ra, ry, rz);
/*  9740 */       return rz;
/*       */     }
/*       */     float[] apply(float[] rx, float rb) {
/*  9743 */       int n1 = rx.length;
/*  9744 */       float[] rz = new float[n1];
/*  9745 */       apply(rx, rb, rz);
/*  9746 */       return rz;
/*       */     }
/*       */     float[][] apply(float[][] rx, float[][] ry) {
/*  9749 */       int n2 = rx.length;
/*  9750 */       float[][] rz = new float[n2][];
/*  9751 */       for (int i2 = 0; i2 < n2; i2++)
/*  9752 */         rz[i2] = apply(rx[i2], ry[i2]); 
/*  9753 */       return rz;
/*       */     }
/*       */     float[][] apply(float ra, float[][] ry) {
/*  9756 */       int n2 = ry.length;
/*  9757 */       float[][] rz = new float[n2][];
/*  9758 */       for (int i2 = 0; i2 < n2; i2++)
/*  9759 */         rz[i2] = apply(ra, ry[i2]); 
/*  9760 */       return rz;
/*       */     }
/*       */     float[][] apply(float[][] rx, float rb) {
/*  9763 */       int n2 = rx.length;
/*  9764 */       float[][] rz = new float[n2][];
/*  9765 */       for (int i2 = 0; i2 < n2; i2++)
/*  9766 */         rz[i2] = apply(rx[i2], rb); 
/*  9767 */       return rz;
/*       */     }
/*       */     float[][][] apply(float[][][] rx, float[][][] ry) {
/*  9770 */       int n3 = rx.length;
/*  9771 */       float[][][] rz = new float[n3][][];
/*  9772 */       for (int i3 = 0; i3 < n3; i3++)
/*  9773 */         rz[i3] = apply(rx[i3], ry[i3]); 
/*  9774 */       return rz;
/*       */     }
/*       */     float[][][] apply(float ra, float[][][] ry) {
/*  9777 */       int n3 = ry.length;
/*  9778 */       float[][][] rz = new float[n3][][];
/*  9779 */       for (int i3 = 0; i3 < n3; i3++)
/*  9780 */         rz[i3] = apply(ra, ry[i3]); 
/*  9781 */       return rz;
/*       */     }
/*       */     float[][][] apply(float[][][] rx, float rb) {
/*  9784 */       int n3 = rx.length;
/*  9785 */       float[][][] rz = new float[n3][][];
/*  9786 */       for (int i3 = 0; i3 < n3; i3++)
/*  9787 */         rz[i3] = apply(rx[i3], rb); 
/*  9788 */       return rz;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     void apply(float[][] rx, float[][] ry, float[][] rz) {
/*  9794 */       int n2 = rx.length;
/*  9795 */       for (int i2 = 0; i2 < n2; i2++)
/*  9796 */         apply(rx[i2], ry[i2], rz[i2]); 
/*       */     }
/*       */     void apply(float ra, float[][] ry, float[][] rz) {
/*  9799 */       int n2 = ry.length;
/*  9800 */       for (int i2 = 0; i2 < n2; i2++)
/*  9801 */         apply(ra, ry[i2], rz[i2]); 
/*       */     }
/*       */     void apply(float[][] rx, float rb, float[][] rz) {
/*  9804 */       int n2 = rx.length;
/*  9805 */       for (int i2 = 0; i2 < n2; i2++)
/*  9806 */         apply(rx[i2], rb, rz[i2]); 
/*       */     }
/*       */     void apply(float[][][] rx, float[][][] ry, float[][][] rz) {
/*  9809 */       int n3 = rx.length;
/*  9810 */       for (int i3 = 0; i3 < n3; i3++)
/*  9811 */         apply(rx[i3], ry[i3], rz[i3]); 
/*       */     }
/*       */     void apply(float ra, float[][][] ry, float[][][] rz) {
/*  9814 */       int n3 = ry.length;
/*  9815 */       for (int i3 = 0; i3 < n3; i3++)
/*  9816 */         apply(ra, ry[i3], rz[i3]); 
/*       */     }
/*       */     void apply(float[][][] rx, float rb, float[][][] rz) {
/*  9819 */       int n3 = rx.length;
/*  9820 */       for (int i3 = 0; i3 < n3; i3++)
/*  9821 */         apply(rx[i3], rb, rz[i3]); 
/*       */     }
/*       */     double[] apply(double[] rx, double[] ry) {
/*  9824 */       int n1 = rx.length;
/*  9825 */       double[] rz = new double[n1];
/*  9826 */       apply(rx, ry, rz);
/*  9827 */       return rz;
/*       */     }
/*       */     double[] apply(double ra, double[] ry) {
/*  9830 */       int n1 = ry.length;
/*  9831 */       double[] rz = new double[n1];
/*  9832 */       apply(ra, ry, rz);
/*  9833 */       return rz;
/*       */     }
/*       */     double[] apply(double[] rx, double rb) {
/*  9836 */       int n1 = rx.length;
/*  9837 */       double[] rz = new double[n1];
/*  9838 */       apply(rx, rb, rz);
/*  9839 */       return rz;
/*       */     }
/*       */     double[][] apply(double[][] rx, double[][] ry) {
/*  9842 */       int n2 = rx.length;
/*  9843 */       double[][] rz = new double[n2][];
/*  9844 */       for (int i2 = 0; i2 < n2; i2++)
/*  9845 */         rz[i2] = apply(rx[i2], ry[i2]); 
/*  9846 */       return rz;
/*       */     }
/*       */     double[][] apply(double ra, double[][] ry) {
/*  9849 */       int n2 = ry.length;
/*  9850 */       double[][] rz = new double[n2][];
/*  9851 */       for (int i2 = 0; i2 < n2; i2++)
/*  9852 */         rz[i2] = apply(ra, ry[i2]); 
/*  9853 */       return rz;
/*       */     }
/*       */     double[][] apply(double[][] rx, double rb) {
/*  9856 */       int n2 = rx.length;
/*  9857 */       double[][] rz = new double[n2][];
/*  9858 */       for (int i2 = 0; i2 < n2; i2++)
/*  9859 */         rz[i2] = apply(rx[i2], rb); 
/*  9860 */       return rz;
/*       */     }
/*       */     double[][][] apply(double[][][] rx, double[][][] ry) {
/*  9863 */       int n3 = rx.length;
/*  9864 */       double[][][] rz = new double[n3][][];
/*  9865 */       for (int i3 = 0; i3 < n3; i3++)
/*  9866 */         rz[i3] = apply(rx[i3], ry[i3]); 
/*  9867 */       return rz;
/*       */     }
/*       */     double[][][] apply(double ra, double[][][] ry) {
/*  9870 */       int n3 = ry.length;
/*  9871 */       double[][][] rz = new double[n3][][];
/*  9872 */       for (int i3 = 0; i3 < n3; i3++)
/*  9873 */         rz[i3] = apply(ra, ry[i3]); 
/*  9874 */       return rz;
/*       */     }
/*       */     double[][][] apply(double[][][] rx, double rb) {
/*  9877 */       int n3 = rx.length;
/*  9878 */       double[][][] rz = new double[n3][][];
/*  9879 */       for (int i3 = 0; i3 < n3; i3++)
/*  9880 */         rz[i3] = apply(rx[i3], rb); 
/*  9881 */       return rz;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     void apply(double[][] rx, double[][] ry, double[][] rz) {
/*  9887 */       int n2 = rx.length;
/*  9888 */       for (int i2 = 0; i2 < n2; i2++)
/*  9889 */         apply(rx[i2], ry[i2], rz[i2]); 
/*       */     }
/*       */     void apply(double ra, double[][] ry, double[][] rz) {
/*  9892 */       int n2 = ry.length;
/*  9893 */       for (int i2 = 0; i2 < n2; i2++)
/*  9894 */         apply(ra, ry[i2], rz[i2]); 
/*       */     }
/*       */     void apply(double[][] rx, double rb, double[][] rz) {
/*  9897 */       int n2 = rx.length;
/*  9898 */       for (int i2 = 0; i2 < n2; i2++)
/*  9899 */         apply(rx[i2], rb, rz[i2]); 
/*       */     }
/*       */     void apply(double[][][] rx, double[][][] ry, double[][][] rz) {
/*  9902 */       int n3 = rx.length;
/*  9903 */       for (int i3 = 0; i3 < n3; i3++)
/*  9904 */         apply(rx[i3], ry[i3], rz[i3]); 
/*       */     }
/*       */     void apply(double ra, double[][][] ry, double[][][] rz) {
/*  9907 */       int n3 = ry.length;
/*  9908 */       for (int i3 = 0; i3 < n3; i3++)
/*  9909 */         apply(ra, ry[i3], rz[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2, float[] param1ArrayOffloat3); abstract void apply(float param1Float, float[] param1ArrayOffloat1, float[] param1ArrayOffloat2); abstract void apply(float[] param1ArrayOffloat1, float param1Float, float[] param1ArrayOffloat2);
/*       */     void apply(double[][][] rx, double rb, double[][][] rz) {
/*  9912 */       int n3 = rx.length;
/*  9913 */       for (int i3 = 0; i3 < n3; i3++)
/*  9914 */         apply(rx[i3], rb, rz[i3]); 
/*       */     } abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2, double[] param1ArrayOfdouble3); abstract void apply(double param1Double, double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, double param1Double, double[] param1ArrayOfdouble2); }
/*  9917 */   private static Binary _add = new Binary() {
/*       */       void apply(float[] rx, float[] ry, float[] rz) {
/*  9919 */         int n1 = rx.length;
/*  9920 */         for (int i1 = 0; i1 < n1; i1++)
/*  9921 */           rz[i1] = rx[i1] + ry[i1]; 
/*       */       }
/*       */       void apply(float ra, float[] ry, float[] rz) {
/*  9924 */         int n1 = ry.length;
/*  9925 */         for (int i1 = 0; i1 < n1; i1++)
/*  9926 */           rz[i1] = ra + ry[i1]; 
/*       */       }
/*       */       void apply(float[] rx, float rb, float[] rz) {
/*  9929 */         int n1 = rx.length;
/*  9930 */         for (int i1 = 0; i1 < n1; i1++)
/*  9931 */           rz[i1] = rx[i1] + rb; 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] rz) {
/*  9934 */         int n1 = rx.length;
/*  9935 */         for (int i1 = 0; i1 < n1; i1++)
/*  9936 */           rz[i1] = rx[i1] + ry[i1]; 
/*       */       }
/*       */       void apply(double ra, double[] ry, double[] rz) {
/*  9939 */         int n1 = ry.length;
/*  9940 */         for (int i1 = 0; i1 < n1; i1++)
/*  9941 */           rz[i1] = ra + ry[i1]; 
/*       */       }
/*       */       void apply(double[] rx, double rb, double[] rz) {
/*  9944 */         int n1 = rx.length;
/*  9945 */         for (int i1 = 0; i1 < n1; i1++)
/*  9946 */           rz[i1] = rx[i1] + rb; 
/*       */       }
/*       */     };
/*  9949 */   private static Binary _sub = new Binary() {
/*       */       void apply(float[] rx, float[] ry, float[] rz) {
/*  9951 */         int n1 = rx.length;
/*  9952 */         for (int i1 = 0; i1 < n1; i1++)
/*  9953 */           rz[i1] = rx[i1] - ry[i1]; 
/*       */       }
/*       */       void apply(float ra, float[] ry, float[] rz) {
/*  9956 */         int n1 = ry.length;
/*  9957 */         for (int i1 = 0; i1 < n1; i1++)
/*  9958 */           rz[i1] = ra - ry[i1]; 
/*       */       }
/*       */       void apply(float[] rx, float rb, float[] rz) {
/*  9961 */         int n1 = rx.length;
/*  9962 */         for (int i1 = 0; i1 < n1; i1++)
/*  9963 */           rz[i1] = rx[i1] - rb; 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] rz) {
/*  9966 */         int n1 = rx.length;
/*  9967 */         for (int i1 = 0; i1 < n1; i1++)
/*  9968 */           rz[i1] = rx[i1] - ry[i1]; 
/*       */       }
/*       */       void apply(double ra, double[] ry, double[] rz) {
/*  9971 */         int n1 = ry.length;
/*  9972 */         for (int i1 = 0; i1 < n1; i1++)
/*  9973 */           rz[i1] = ra - ry[i1]; 
/*       */       }
/*       */       void apply(double[] rx, double rb, double[] rz) {
/*  9976 */         int n1 = rx.length;
/*  9977 */         for (int i1 = 0; i1 < n1; i1++)
/*  9978 */           rz[i1] = rx[i1] - rb; 
/*       */       }
/*       */     };
/*  9981 */   private static Binary _mul = new Binary() {
/*       */       void apply(float[] rx, float[] ry, float[] rz) {
/*  9983 */         int n1 = rx.length;
/*  9984 */         for (int i1 = 0; i1 < n1; i1++)
/*  9985 */           rz[i1] = rx[i1] * ry[i1]; 
/*       */       }
/*       */       void apply(float ra, float[] ry, float[] rz) {
/*  9988 */         int n1 = ry.length;
/*  9989 */         for (int i1 = 0; i1 < n1; i1++)
/*  9990 */           rz[i1] = ra * ry[i1]; 
/*       */       }
/*       */       void apply(float[] rx, float rb, float[] rz) {
/*  9993 */         int n1 = rx.length;
/*  9994 */         for (int i1 = 0; i1 < n1; i1++)
/*  9995 */           rz[i1] = rx[i1] * rb; 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] rz) {
/*  9998 */         int n1 = rx.length;
/*  9999 */         for (int i1 = 0; i1 < n1; i1++)
/* 10000 */           rz[i1] = rx[i1] * ry[i1]; 
/*       */       }
/*       */       void apply(double ra, double[] ry, double[] rz) {
/* 10003 */         int n1 = ry.length;
/* 10004 */         for (int i1 = 0; i1 < n1; i1++)
/* 10005 */           rz[i1] = ra * ry[i1]; 
/*       */       }
/*       */       void apply(double[] rx, double rb, double[] rz) {
/* 10008 */         int n1 = rx.length;
/* 10009 */         for (int i1 = 0; i1 < n1; i1++)
/* 10010 */           rz[i1] = rx[i1] * rb; 
/*       */       }
/*       */     };
/* 10013 */   private static Binary _div = new Binary() {
/*       */       void apply(float[] rx, float[] ry, float[] rz) {
/* 10015 */         int n1 = rx.length;
/* 10016 */         for (int i1 = 0; i1 < n1; i1++)
/* 10017 */           rz[i1] = rx[i1] / ry[i1]; 
/*       */       }
/*       */       void apply(float ra, float[] ry, float[] rz) {
/* 10020 */         int n1 = ry.length;
/* 10021 */         for (int i1 = 0; i1 < n1; i1++)
/* 10022 */           rz[i1] = ra / ry[i1]; 
/*       */       }
/*       */       void apply(float[] rx, float rb, float[] rz) {
/* 10025 */         int n1 = rx.length;
/* 10026 */         for (int i1 = 0; i1 < n1; i1++)
/* 10027 */           rz[i1] = rx[i1] / rb; 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] rz) {
/* 10030 */         int n1 = rx.length;
/* 10031 */         for (int i1 = 0; i1 < n1; i1++)
/* 10032 */           rz[i1] = rx[i1] / ry[i1]; 
/*       */       }
/*       */       void apply(double ra, double[] ry, double[] rz) {
/* 10035 */         int n1 = ry.length;
/* 10036 */         for (int i1 = 0; i1 < n1; i1++)
/* 10037 */           rz[i1] = ra / ry[i1]; 
/*       */       }
/*       */       void apply(double[] rx, double rb, double[] rz) {
/* 10040 */         int n1 = rx.length;
/* 10041 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10042 */           rz[i1] = rx[i1] / rb;
/*       */         }
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] abs(float[] rx) {
/* 10050 */     return _abs.apply(rx);
/*       */   }
/*       */   public static float[][] abs(float[][] rx) {
/* 10053 */     return _abs.apply(rx);
/*       */   }
/*       */   public static float[][][] abs(float[][][] rx) {
/* 10056 */     return _abs.apply(rx);
/*       */   }
/*       */   public static void abs(float[] rx, float[] ry) {
/* 10059 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static void abs(float[][] rx, float[][] ry) {
/* 10062 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static void abs(float[][][] rx, float[][][] ry) {
/* 10065 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static float[] neg(float[] rx) {
/* 10068 */     return _neg.apply(rx);
/*       */   }
/*       */   public static float[][] neg(float[][] rx) {
/* 10071 */     return _neg.apply(rx);
/*       */   }
/*       */   public static float[][][] neg(float[][][] rx) {
/* 10074 */     return _neg.apply(rx);
/*       */   }
/*       */   public static void neg(float[] rx, float[] ry) {
/* 10077 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static void neg(float[][] rx, float[][] ry) {
/* 10080 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static void neg(float[][][] rx, float[][][] ry) {
/* 10083 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static float[] cos(float[] rx) {
/* 10086 */     return _cos.apply(rx);
/*       */   }
/*       */   public static float[][] cos(float[][] rx) {
/* 10089 */     return _cos.apply(rx);
/*       */   }
/*       */   public static float[][][] cos(float[][][] rx) {
/* 10092 */     return _cos.apply(rx);
/*       */   }
/*       */   public static void cos(float[] rx, float[] ry) {
/* 10095 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static void cos(float[][] rx, float[][] ry) {
/* 10098 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static void cos(float[][][] rx, float[][][] ry) {
/* 10101 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static float[] sin(float[] rx) {
/* 10104 */     return _sin.apply(rx);
/*       */   }
/*       */   public static float[][] sin(float[][] rx) {
/* 10107 */     return _sin.apply(rx);
/*       */   }
/*       */   public static float[][][] sin(float[][][] rx) {
/* 10110 */     return _sin.apply(rx);
/*       */   }
/*       */   public static void sin(float[] rx, float[] ry) {
/* 10113 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static void sin(float[][] rx, float[][] ry) {
/* 10116 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static void sin(float[][][] rx, float[][][] ry) {
/* 10119 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static float[] exp(float[] rx) {
/* 10122 */     return _exp.apply(rx);
/*       */   }
/*       */   public static float[][] exp(float[][] rx) {
/* 10125 */     return _exp.apply(rx);
/*       */   }
/*       */   public static float[][][] exp(float[][][] rx) {
/* 10128 */     return _exp.apply(rx);
/*       */   }
/*       */   public static void exp(float[] rx, float[] ry) {
/* 10131 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static void exp(float[][] rx, float[][] ry) {
/* 10134 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static void exp(float[][][] rx, float[][][] ry) {
/* 10137 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static float[] log(float[] rx) {
/* 10140 */     return _log.apply(rx);
/*       */   }
/*       */   public static float[][] log(float[][] rx) {
/* 10143 */     return _log.apply(rx);
/*       */   }
/*       */   public static float[][][] log(float[][][] rx) {
/* 10146 */     return _log.apply(rx);
/*       */   }
/*       */   public static void log(float[] rx, float[] ry) {
/* 10149 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static void log(float[][] rx, float[][] ry) {
/* 10152 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static void log(float[][][] rx, float[][][] ry) {
/* 10155 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static float[] log10(float[] rx) {
/* 10158 */     return _log10.apply(rx);
/*       */   }
/*       */   public static float[][] log10(float[][] rx) {
/* 10161 */     return _log10.apply(rx);
/*       */   }
/*       */   public static float[][][] log10(float[][][] rx) {
/* 10164 */     return _log10.apply(rx);
/*       */   }
/*       */   public static void log10(float[] rx, float[] ry) {
/* 10167 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static void log10(float[][] rx, float[][] ry) {
/* 10170 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static void log10(float[][][] rx, float[][][] ry) {
/* 10173 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static float[] sqrt(float[] rx) {
/* 10176 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static float[][] sqrt(float[][] rx) {
/* 10179 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static float[][][] sqrt(float[][][] rx) {
/* 10182 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static void sqrt(float[] rx, float[] ry) {
/* 10185 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static void sqrt(float[][] rx, float[][] ry) {
/* 10188 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static void sqrt(float[][][] rx, float[][][] ry) {
/* 10191 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static float[] sgn(float[] rx) {
/* 10194 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static float[][] sgn(float[][] rx) {
/* 10197 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static float[][][] sgn(float[][][] rx) {
/* 10200 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static void sgn(float[] rx, float[] ry) {
/* 10203 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   public static void sgn(float[][] rx, float[][] ry) {
/* 10206 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   public static void sgn(float[][][] rx, float[][][] ry) {
/* 10209 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   public static double[] abs(double[] rx) {
/* 10212 */     return _abs.apply(rx);
/*       */   }
/*       */   public static double[][] abs(double[][] rx) {
/* 10215 */     return _abs.apply(rx);
/*       */   }
/*       */   public static double[][][] abs(double[][][] rx) {
/* 10218 */     return _abs.apply(rx);
/*       */   }
/*       */   public static void abs(double[] rx, double[] ry) {
/* 10221 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static void abs(double[][] rx, double[][] ry) {
/* 10224 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static void abs(double[][][] rx, double[][][] ry) {
/* 10227 */     _abs.apply(rx, ry);
/*       */   }
/*       */   public static double[] neg(double[] rx) {
/* 10230 */     return _neg.apply(rx);
/*       */   }
/*       */   public static double[][] neg(double[][] rx) {
/* 10233 */     return _neg.apply(rx);
/*       */   }
/*       */   public static double[][][] neg(double[][][] rx) {
/* 10236 */     return _neg.apply(rx);
/*       */   }
/*       */   public static void neg(double[] rx, double[] ry) {
/* 10239 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static void neg(double[][] rx, double[][] ry) {
/* 10242 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static void neg(double[][][] rx, double[][][] ry) {
/* 10245 */     _neg.apply(rx, ry);
/*       */   }
/*       */   public static double[] cos(double[] rx) {
/* 10248 */     return _cos.apply(rx);
/*       */   }
/*       */   public static double[][] cos(double[][] rx) {
/* 10251 */     return _cos.apply(rx);
/*       */   }
/*       */   public static double[][][] cos(double[][][] rx) {
/* 10254 */     return _cos.apply(rx);
/*       */   }
/*       */   public static void cos(double[] rx, double[] ry) {
/* 10257 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static void cos(double[][] rx, double[][] ry) {
/* 10260 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static void cos(double[][][] rx, double[][][] ry) {
/* 10263 */     _cos.apply(rx, ry);
/*       */   }
/*       */   public static double[] sin(double[] rx) {
/* 10266 */     return _sin.apply(rx);
/*       */   }
/*       */   public static double[][] sin(double[][] rx) {
/* 10269 */     return _sin.apply(rx);
/*       */   }
/*       */   public static double[][][] sin(double[][][] rx) {
/* 10272 */     return _sin.apply(rx);
/*       */   }
/*       */   public static void sin(double[] rx, double[] ry) {
/* 10275 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static void sin(double[][] rx, double[][] ry) {
/* 10278 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static void sin(double[][][] rx, double[][][] ry) {
/* 10281 */     _sin.apply(rx, ry);
/*       */   }
/*       */   public static double[] exp(double[] rx) {
/* 10284 */     return _exp.apply(rx);
/*       */   }
/*       */   public static double[][] exp(double[][] rx) {
/* 10287 */     return _exp.apply(rx);
/*       */   }
/*       */   public static double[][][] exp(double[][][] rx) {
/* 10290 */     return _exp.apply(rx);
/*       */   }
/*       */   public static void exp(double[] rx, double[] ry) {
/* 10293 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static void exp(double[][] rx, double[][] ry) {
/* 10296 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static void exp(double[][][] rx, double[][][] ry) {
/* 10299 */     _exp.apply(rx, ry);
/*       */   }
/*       */   public static double[] log(double[] rx) {
/* 10302 */     return _log.apply(rx);
/*       */   }
/*       */   public static double[][] log(double[][] rx) {
/* 10305 */     return _log.apply(rx);
/*       */   }
/*       */   public static double[][][] log(double[][][] rx) {
/* 10308 */     return _log.apply(rx);
/*       */   }
/*       */   public static void log(double[] rx, double[] ry) {
/* 10311 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static void log(double[][] rx, double[][] ry) {
/* 10314 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static void log(double[][][] rx, double[][][] ry) {
/* 10317 */     _log.apply(rx, ry);
/*       */   }
/*       */   public static double[] log10(double[] rx) {
/* 10320 */     return _log10.apply(rx);
/*       */   }
/*       */   public static double[][] log10(double[][] rx) {
/* 10323 */     return _log10.apply(rx);
/*       */   }
/*       */   public static double[][][] log10(double[][][] rx) {
/* 10326 */     return _log10.apply(rx);
/*       */   }
/*       */   public static void log10(double[] rx, double[] ry) {
/* 10329 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static void log10(double[][] rx, double[][] ry) {
/* 10332 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static void log10(double[][][] rx, double[][][] ry) {
/* 10335 */     _log10.apply(rx, ry);
/*       */   }
/*       */   public static double[] sqrt(double[] rx) {
/* 10338 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static double[][] sqrt(double[][] rx) {
/* 10341 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static double[][][] sqrt(double[][][] rx) {
/* 10344 */     return _sqrt.apply(rx);
/*       */   }
/*       */   public static void sqrt(double[] rx, double[] ry) {
/* 10347 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static void sqrt(double[][] rx, double[][] ry) {
/* 10350 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static void sqrt(double[][][] rx, double[][][] ry) {
/* 10353 */     _sqrt.apply(rx, ry);
/*       */   }
/*       */   public static double[] sgn(double[] rx) {
/* 10356 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static double[][] sgn(double[][] rx) {
/* 10359 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static double[][][] sgn(double[][][] rx) {
/* 10362 */     return _sgn.apply(rx);
/*       */   }
/*       */   public static void sgn(double[] rx, double[] ry) {
/* 10365 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   public static void sgn(double[][] rx, double[][] ry) {
/* 10368 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   public static void sgn(double[][][] rx, double[][][] ry) {
/* 10371 */     _sgn.apply(rx, ry);
/*       */   }
/*       */   private static abstract class Unary { private Unary() {}
/*       */     float[] apply(float[] rx) {
/* 10375 */       int n1 = rx.length;
/* 10376 */       float[] ry = new float[n1];
/* 10377 */       apply(rx, ry);
/* 10378 */       return ry;
/*       */     }
/*       */     float[][] apply(float[][] rx) {
/* 10381 */       int n2 = rx.length;
/* 10382 */       float[][] ry = new float[n2][];
/* 10383 */       for (int i2 = 0; i2 < n2; i2++)
/* 10384 */         ry[i2] = apply(rx[i2]); 
/* 10385 */       return ry;
/*       */     }
/*       */     float[][][] apply(float[][][] rx) {
/* 10388 */       int n3 = rx.length;
/* 10389 */       float[][][] ry = new float[n3][][];
/* 10390 */       for (int i3 = 0; i3 < n3; i3++)
/* 10391 */         ry[i3] = apply(rx[i3]); 
/* 10392 */       return ry;
/*       */     }
/*       */     
/*       */     void apply(float[][] rx, float[][] ry) {
/* 10396 */       int n2 = rx.length;
/* 10397 */       for (int i2 = 0; i2 < n2; i2++)
/* 10398 */         apply(rx[i2], ry[i2]); 
/*       */     }
/*       */     void apply(float[][][] rx, float[][][] ry) {
/* 10401 */       int n3 = rx.length;
/* 10402 */       for (int i3 = 0; i3 < n3; i3++)
/* 10403 */         apply(rx[i3], ry[i3]); 
/*       */     }
/*       */     double[] apply(double[] rx) {
/* 10406 */       int n1 = rx.length;
/* 10407 */       double[] ry = new double[n1];
/* 10408 */       apply(rx, ry);
/* 10409 */       return ry;
/*       */     }
/*       */     double[][] apply(double[][] rx) {
/* 10412 */       int n2 = rx.length;
/* 10413 */       double[][] ry = new double[n2][];
/* 10414 */       for (int i2 = 0; i2 < n2; i2++)
/* 10415 */         ry[i2] = apply(rx[i2]); 
/* 10416 */       return ry;
/*       */     }
/*       */     double[][][] apply(double[][][] rx) {
/* 10419 */       int n3 = rx.length;
/* 10420 */       double[][][] ry = new double[n3][][];
/* 10421 */       for (int i3 = 0; i3 < n3; i3++)
/* 10422 */         ry[i3] = apply(rx[i3]); 
/* 10423 */       return ry;
/*       */     }
/*       */     
/*       */     void apply(double[][] rx, double[][] ry) {
/* 10427 */       int n2 = rx.length;
/* 10428 */       for (int i2 = 0; i2 < n2; i2++)
/* 10429 */         apply(rx[i2], ry[i2]); 
/*       */     }
/*       */     void apply(double[][][] rx, double[][][] ry) {
/* 10432 */       int n3 = rx.length;
/* 10433 */       for (int i3 = 0; i3 < n3; i3++)
/* 10434 */         apply(rx[i3], ry[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2); }
/* 10437 */   private static Unary _abs = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10439 */         int n1 = rx.length;
/* 10440 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10441 */           float rxi = rx[i1];
/* 10442 */           ry[i1] = (rxi >= 0.0F) ? rxi : -rxi;
/*       */         } 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10446 */         int n1 = rx.length;
/* 10447 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10448 */           double rxi = rx[i1];
/* 10449 */           ry[i1] = (rxi >= 0.0D) ? rxi : -rxi;
/*       */         } 
/*       */       }
/*       */     };
/* 10453 */   private static Unary _neg = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10455 */         int n1 = rx.length;
/* 10456 */         for (int i1 = 0; i1 < n1; i1++)
/* 10457 */           ry[i1] = -rx[i1]; 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10460 */         int n1 = rx.length;
/* 10461 */         for (int i1 = 0; i1 < n1; i1++)
/* 10462 */           ry[i1] = -rx[i1]; 
/*       */       }
/*       */     };
/* 10465 */   private static Unary _cos = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10467 */         int n1 = rx.length;
/* 10468 */         for (int i1 = 0; i1 < n1; i1++)
/* 10469 */           ry[i1] = (float)Math.cos(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10472 */         int n1 = rx.length;
/* 10473 */         for (int i1 = 0; i1 < n1; i1++)
/* 10474 */           ry[i1] = Math.cos(rx[i1]); 
/*       */       }
/*       */     };
/* 10477 */   private static Unary _sin = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10479 */         int n1 = rx.length;
/* 10480 */         for (int i1 = 0; i1 < n1; i1++)
/* 10481 */           ry[i1] = (float)Math.sin(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10484 */         int n1 = rx.length;
/* 10485 */         for (int i1 = 0; i1 < n1; i1++)
/* 10486 */           ry[i1] = Math.sin(rx[i1]); 
/*       */       }
/*       */     };
/* 10489 */   private static Unary _exp = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10491 */         int n1 = rx.length;
/* 10492 */         for (int i1 = 0; i1 < n1; i1++)
/* 10493 */           ry[i1] = (float)Math.exp(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10496 */         int n1 = rx.length;
/* 10497 */         for (int i1 = 0; i1 < n1; i1++)
/* 10498 */           ry[i1] = Math.exp(rx[i1]); 
/*       */       }
/*       */     };
/* 10501 */   private static Unary _log = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10503 */         int n1 = rx.length;
/* 10504 */         for (int i1 = 0; i1 < n1; i1++)
/* 10505 */           ry[i1] = (float)Math.log(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10508 */         int n1 = rx.length;
/* 10509 */         for (int i1 = 0; i1 < n1; i1++)
/* 10510 */           ry[i1] = Math.log(rx[i1]); 
/*       */       }
/*       */     };
/* 10513 */   private static Unary _log10 = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10515 */         int n1 = rx.length;
/* 10516 */         for (int i1 = 0; i1 < n1; i1++)
/* 10517 */           ry[i1] = (float)Math.log10(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10520 */         int n1 = rx.length;
/* 10521 */         for (int i1 = 0; i1 < n1; i1++)
/* 10522 */           ry[i1] = Math.log10(rx[i1]); 
/*       */       }
/*       */     };
/* 10525 */   private static Unary _sqrt = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10527 */         int n1 = rx.length;
/* 10528 */         for (int i1 = 0; i1 < n1; i1++)
/* 10529 */           ry[i1] = (float)Math.sqrt(rx[i1]); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10532 */         int n1 = rx.length;
/* 10533 */         for (int i1 = 0; i1 < n1; i1++)
/* 10534 */           ry[i1] = Math.sqrt(rx[i1]); 
/*       */       }
/*       */     };
/* 10537 */   private static Unary _sgn = new Unary() {
/*       */       void apply(float[] rx, float[] ry) {
/* 10539 */         int n1 = rx.length;
/* 10540 */         for (int i1 = 0; i1 < n1; i1++)
/* 10541 */           ry[i1] = (rx[i1] > 0.0F) ? 1.0F : ((rx[i1] < 0.0F) ? -1.0F : 0.0F); 
/*       */       }
/*       */       void apply(double[] rx, double[] ry) {
/* 10544 */         int n1 = rx.length;
/* 10545 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10546 */           ry[i1] = (rx[i1] > 0.0D) ? 1.0D : ((rx[i1] < 0.0D) ? -1.0D : 0.0D);
/*       */         }
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] pow(float[] rx, float ra) {
/* 10554 */     int n1 = rx.length;
/* 10555 */     float[] ry = new float[n1];
/* 10556 */     pow(rx, ra, ry);
/* 10557 */     return ry;
/*       */   }
/*       */   public static float[][] pow(float[][] rx, float ra) {
/* 10560 */     int n2 = rx.length;
/* 10561 */     float[][] ry = new float[n2][];
/* 10562 */     for (int i2 = 0; i2 < n2; i2++)
/* 10563 */       ry[i2] = pow(rx[i2], ra); 
/* 10564 */     return ry;
/*       */   }
/*       */   public static float[][][] pow(float[][][] rx, float ra) {
/* 10567 */     int n3 = rx.length;
/* 10568 */     float[][][] ry = new float[n3][][];
/* 10569 */     for (int i3 = 0; i3 < n3; i3++)
/* 10570 */       ry[i3] = pow(rx[i3], ra); 
/* 10571 */     return ry;
/*       */   }
/*       */   public static void pow(float[] rx, float ra, float[] ry) {
/* 10574 */     int n1 = rx.length;
/* 10575 */     for (int i1 = 0; i1 < n1; i1++)
/* 10576 */       ry[i1] = (float)Math.pow(rx[i1], ra); 
/*       */   }
/*       */   public static void pow(float[][] rx, float ra, float[][] ry) {
/* 10579 */     int n2 = rx.length;
/* 10580 */     for (int i2 = 0; i2 < n2; i2++)
/* 10581 */       pow(rx[i2], ra, ry[i2]); 
/*       */   }
/*       */   public static void pow(float[][][] rx, float ra, float[][][] ry) {
/* 10584 */     int n3 = rx.length;
/* 10585 */     for (int i3 = 0; i3 < n3; i3++)
/* 10586 */       pow(rx[i3], ra, ry[i3]); 
/*       */   }
/*       */   public static double[] pow(double[] rx, double ra) {
/* 10589 */     int n1 = rx.length;
/* 10590 */     double[] ry = new double[n1];
/* 10591 */     pow(rx, ra, ry);
/* 10592 */     return ry;
/*       */   }
/*       */   public static double[][] pow(double[][] rx, double ra) {
/* 10595 */     int n2 = rx.length;
/* 10596 */     double[][] ry = new double[n2][];
/* 10597 */     for (int i2 = 0; i2 < n2; i2++)
/* 10598 */       ry[i2] = pow(rx[i2], ra); 
/* 10599 */     return ry;
/*       */   }
/*       */   public static double[][][] pow(double[][][] rx, double ra) {
/* 10602 */     int n3 = rx.length;
/* 10603 */     double[][][] ry = new double[n3][][];
/* 10604 */     for (int i3 = 0; i3 < n3; i3++)
/* 10605 */       ry[i3] = pow(rx[i3], ra); 
/* 10606 */     return ry;
/*       */   }
/*       */   public static void pow(double[] rx, double ra, double[] ry) {
/* 10609 */     int n1 = rx.length;
/* 10610 */     for (int i1 = 0; i1 < n1; i1++)
/* 10611 */       ry[i1] = Math.pow(rx[i1], ra); 
/*       */   }
/*       */   public static void pow(double[][] rx, double ra, double[][] ry) {
/* 10614 */     int n2 = rx.length;
/* 10615 */     for (int i2 = 0; i2 < n2; i2++)
/* 10616 */       pow(rx[i2], ra, ry[i2]); 
/*       */   }
/*       */   public static void pow(double[][][] rx, double ra, double[][][] ry) {
/* 10619 */     int n3 = rx.length;
/* 10620 */     for (int i3 = 0; i3 < n3; i3++) {
/* 10621 */       pow(rx[i3], ra, ry[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte sum(byte[] rx) {
/* 10628 */     int n1 = rx.length;
/* 10629 */     byte sum = 0;
/* 10630 */     for (int i1 = 0; i1 < n1; i1++)
/* 10631 */       sum = (byte)(sum + rx[i1]); 
/* 10632 */     return sum;
/*       */   }
/*       */   public static byte sum(byte[][] rx) {
/* 10635 */     int n2 = rx.length;
/* 10636 */     byte sum = 0;
/* 10637 */     for (int i2 = 0; i2 < n2; i2++)
/* 10638 */       sum = (byte)(sum + sum(rx[i2])); 
/* 10639 */     return sum;
/*       */   }
/*       */   public static byte sum(byte[][][] rx) {
/* 10642 */     int n3 = rx.length;
/* 10643 */     byte sum = 0;
/* 10644 */     for (int i3 = 0; i3 < n3; i3++)
/* 10645 */       sum = (byte)(sum + sum(rx[i3])); 
/* 10646 */     return sum;
/*       */   }
/*       */   public static short sum(short[] rx) {
/* 10649 */     int n1 = rx.length;
/* 10650 */     short sum = 0;
/* 10651 */     for (int i1 = 0; i1 < n1; i1++)
/* 10652 */       sum = (short)(sum + rx[i1]); 
/* 10653 */     return sum;
/*       */   }
/*       */   public static short sum(short[][] rx) {
/* 10656 */     int n2 = rx.length;
/* 10657 */     short sum = 0;
/* 10658 */     for (int i2 = 0; i2 < n2; i2++)
/* 10659 */       sum = (short)(sum + sum(rx[i2])); 
/* 10660 */     return sum;
/*       */   }
/*       */   public static short sum(short[][][] rx) {
/* 10663 */     int n3 = rx.length;
/* 10664 */     short sum = 0;
/* 10665 */     for (int i3 = 0; i3 < n3; i3++)
/* 10666 */       sum = (short)(sum + sum(rx[i3])); 
/* 10667 */     return sum;
/*       */   }
/*       */   public static int sum(int[] rx) {
/* 10670 */     int n1 = rx.length;
/* 10671 */     int sum = 0;
/* 10672 */     for (int i1 = 0; i1 < n1; i1++)
/* 10673 */       sum += rx[i1]; 
/* 10674 */     return sum;
/*       */   }
/*       */   public static int sum(int[][] rx) {
/* 10677 */     int n2 = rx.length;
/* 10678 */     int sum = 0;
/* 10679 */     for (int i2 = 0; i2 < n2; i2++)
/* 10680 */       sum += sum(rx[i2]); 
/* 10681 */     return sum;
/*       */   }
/*       */   public static int sum(int[][][] rx) {
/* 10684 */     int n3 = rx.length;
/* 10685 */     int sum = 0;
/* 10686 */     for (int i3 = 0; i3 < n3; i3++)
/* 10687 */       sum += sum(rx[i3]); 
/* 10688 */     return sum;
/*       */   }
/*       */   public static long sum(long[] rx) {
/* 10691 */     int n1 = rx.length;
/* 10692 */     long sum = 0L;
/* 10693 */     for (int i1 = 0; i1 < n1; i1++)
/* 10694 */       sum += rx[i1]; 
/* 10695 */     return sum;
/*       */   }
/*       */   public static long sum(long[][] rx) {
/* 10698 */     int n2 = rx.length;
/* 10699 */     long sum = 0L;
/* 10700 */     for (int i2 = 0; i2 < n2; i2++)
/* 10701 */       sum += sum(rx[i2]); 
/* 10702 */     return sum;
/*       */   }
/*       */   public static long sum(long[][][] rx) {
/* 10705 */     int n3 = rx.length;
/* 10706 */     long sum = 0L;
/* 10707 */     for (int i3 = 0; i3 < n3; i3++)
/* 10708 */       sum += sum(rx[i3]); 
/* 10709 */     return sum;
/*       */   }
/*       */   public static float sum(float[] rx) {
/* 10712 */     int n1 = rx.length;
/* 10713 */     float sum = 0.0F;
/* 10714 */     for (int i1 = 0; i1 < n1; i1++)
/* 10715 */       sum += rx[i1]; 
/* 10716 */     return sum;
/*       */   }
/*       */   public static float sum(float[][] rx) {
/* 10719 */     int n2 = rx.length;
/* 10720 */     float sum = 0.0F;
/* 10721 */     for (int i2 = 0; i2 < n2; i2++)
/* 10722 */       sum += sum(rx[i2]); 
/* 10723 */     return sum;
/*       */   }
/*       */   public static float sum(float[][][] rx) {
/* 10726 */     int n3 = rx.length;
/* 10727 */     float sum = 0.0F;
/* 10728 */     for (int i3 = 0; i3 < n3; i3++)
/* 10729 */       sum += sum(rx[i3]); 
/* 10730 */     return sum;
/*       */   }
/*       */   public static double sum(double[] rx) {
/* 10733 */     int n1 = rx.length;
/* 10734 */     double sum = 0.0D;
/* 10735 */     for (int i1 = 0; i1 < n1; i1++)
/* 10736 */       sum += rx[i1]; 
/* 10737 */     return sum;
/*       */   }
/*       */   public static double sum(double[][] rx) {
/* 10740 */     int n2 = rx.length;
/* 10741 */     double sum = 0.0D;
/* 10742 */     for (int i2 = 0; i2 < n2; i2++)
/* 10743 */       sum += sum(rx[i2]); 
/* 10744 */     return sum;
/*       */   }
/*       */   public static double sum(double[][][] rx) {
/* 10747 */     int n3 = rx.length;
/* 10748 */     double sum = 0.0D;
/* 10749 */     for (int i3 = 0; i3 < n3; i3++)
/* 10750 */       sum += sum(rx[i3]); 
/* 10751 */     return sum;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static byte max(byte[] rx) {
/* 10758 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static byte max(byte[][] rx) {
/* 10761 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static byte max(byte[][][] rx) {
/* 10764 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static byte max(byte[] rx, int[] index) {
/* 10767 */     int i1max = 0;
/* 10768 */     byte max = rx[0];
/* 10769 */     int n1 = rx.length;
/* 10770 */     for (int i1 = 1; i1 < n1; i1++) {
/* 10771 */       if (rx[i1] > max) {
/* 10772 */         max = rx[i1];
/* 10773 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 10776 */     if (index != null)
/* 10777 */       index[0] = i1max; 
/* 10778 */     return max;
/*       */   }
/*       */   public static byte max(byte[][] rx, int[] index) {
/* 10781 */     int i1max = 0;
/* 10782 */     int i2max = 0;
/* 10783 */     byte max = rx[0][0];
/* 10784 */     int n2 = rx.length;
/* 10785 */     for (int i2 = 0; i2 < n2; i2++) {
/* 10786 */       byte[] rxi2 = rx[i2];
/* 10787 */       int n1 = rxi2.length;
/* 10788 */       for (int i1 = 0; i1 < n1; i1++) {
/* 10789 */         if (rxi2[i1] > max) {
/* 10790 */           max = rxi2[i1];
/* 10791 */           i2max = i2;
/* 10792 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 10796 */     if (index != null) {
/* 10797 */       index[0] = i1max;
/* 10798 */       index[1] = i2max;
/*       */     } 
/* 10800 */     return max;
/*       */   }
/*       */   public static byte max(byte[][][] rx, int[] index) {
/* 10803 */     int i1max = 0;
/* 10804 */     int i2max = 0;
/* 10805 */     int i3max = 0;
/* 10806 */     byte max = rx[0][0][0];
/* 10807 */     int n3 = rx.length;
/* 10808 */     for (int i3 = 0; i3 < n3; i3++) {
/* 10809 */       byte[][] rxi3 = rx[i3];
/* 10810 */       int n2 = rxi3.length;
/* 10811 */       for (int i2 = 0; i2 < n2; i2++) {
/* 10812 */         byte[] rxi3i2 = rxi3[i2];
/* 10813 */         int n1 = rxi3i2.length;
/* 10814 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10815 */           if (rxi3i2[i1] > max) {
/* 10816 */             max = rxi3i2[i1];
/* 10817 */             i1max = i1;
/* 10818 */             i2max = i2;
/* 10819 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 10824 */     if (index != null) {
/* 10825 */       index[0] = i1max;
/* 10826 */       index[1] = i2max;
/* 10827 */       index[2] = i3max;
/*       */     } 
/* 10829 */     return max;
/*       */   }
/*       */   public static byte min(byte[] rx) {
/* 10832 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static byte min(byte[][] rx) {
/* 10835 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static byte min(byte[][][] rx) {
/* 10838 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static byte min(byte[] rx, int[] index) {
/* 10841 */     int i1min = 0;
/* 10842 */     byte min = rx[0];
/* 10843 */     int n1 = rx.length;
/* 10844 */     for (int i1 = 1; i1 < n1; i1++) {
/* 10845 */       if (rx[i1] < min) {
/* 10846 */         min = rx[i1];
/* 10847 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 10850 */     if (index != null)
/* 10851 */       index[0] = i1min; 
/* 10852 */     return min;
/*       */   }
/*       */   public static byte min(byte[][] rx, int[] index) {
/* 10855 */     int i1min = 0;
/* 10856 */     int i2min = 0;
/* 10857 */     byte min = rx[0][0];
/* 10858 */     int n2 = rx.length;
/* 10859 */     for (int i2 = 0; i2 < n2; i2++) {
/* 10860 */       byte[] rxi2 = rx[i2];
/* 10861 */       int n1 = rxi2.length;
/* 10862 */       for (int i1 = 0; i1 < n1; i1++) {
/* 10863 */         if (rxi2[i1] < min) {
/* 10864 */           min = rxi2[i1];
/* 10865 */           i2min = i2;
/* 10866 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 10870 */     if (index != null) {
/* 10871 */       index[0] = i1min;
/* 10872 */       index[1] = i2min;
/*       */     } 
/* 10874 */     return min;
/*       */   }
/*       */   public static byte min(byte[][][] rx, int[] index) {
/* 10877 */     int i1min = 0;
/* 10878 */     int i2min = 0;
/* 10879 */     int i3min = 0;
/* 10880 */     byte min = rx[0][0][0];
/* 10881 */     int n3 = rx.length;
/* 10882 */     for (int i3 = 0; i3 < n3; i3++) {
/* 10883 */       byte[][] rxi3 = rx[i3];
/* 10884 */       int n2 = rxi3.length;
/* 10885 */       for (int i2 = 0; i2 < n2; i2++) {
/* 10886 */         byte[] rxi3i2 = rxi3[i2];
/* 10887 */         int n1 = rxi3i2.length;
/* 10888 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10889 */           if (rxi3i2[i1] < min) {
/* 10890 */             min = rxi3i2[i1];
/* 10891 */             i1min = i1;
/* 10892 */             i2min = i2;
/* 10893 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 10898 */     if (index != null) {
/* 10899 */       index[0] = i1min;
/* 10900 */       index[1] = i2min;
/* 10901 */       index[2] = i3min;
/*       */     } 
/* 10903 */     return min;
/*       */   }
/*       */   public static short max(short[] rx) {
/* 10906 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static short max(short[][] rx) {
/* 10909 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static short max(short[][][] rx) {
/* 10912 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static short max(short[] rx, int[] index) {
/* 10915 */     int i1max = 0;
/* 10916 */     short max = rx[0];
/* 10917 */     int n1 = rx.length;
/* 10918 */     for (int i1 = 1; i1 < n1; i1++) {
/* 10919 */       if (rx[i1] > max) {
/* 10920 */         max = rx[i1];
/* 10921 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 10924 */     if (index != null)
/* 10925 */       index[0] = i1max; 
/* 10926 */     return max;
/*       */   }
/*       */   public static short max(short[][] rx, int[] index) {
/* 10929 */     int i1max = 0;
/* 10930 */     int i2max = 0;
/* 10931 */     short max = rx[0][0];
/* 10932 */     int n2 = rx.length;
/* 10933 */     for (int i2 = 0; i2 < n2; i2++) {
/* 10934 */       short[] rxi2 = rx[i2];
/* 10935 */       int n1 = rxi2.length;
/* 10936 */       for (int i1 = 0; i1 < n1; i1++) {
/* 10937 */         if (rxi2[i1] > max) {
/* 10938 */           max = rxi2[i1];
/* 10939 */           i2max = i2;
/* 10940 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 10944 */     if (index != null) {
/* 10945 */       index[0] = i1max;
/* 10946 */       index[1] = i2max;
/*       */     } 
/* 10948 */     return max;
/*       */   }
/*       */   public static short max(short[][][] rx, int[] index) {
/* 10951 */     int i1max = 0;
/* 10952 */     int i2max = 0;
/* 10953 */     int i3max = 0;
/* 10954 */     short max = rx[0][0][0];
/* 10955 */     int n3 = rx.length;
/* 10956 */     for (int i3 = 0; i3 < n3; i3++) {
/* 10957 */       short[][] rxi3 = rx[i3];
/* 10958 */       int n2 = rxi3.length;
/* 10959 */       for (int i2 = 0; i2 < n2; i2++) {
/* 10960 */         short[] rxi3i2 = rxi3[i2];
/* 10961 */         int n1 = rxi3i2.length;
/* 10962 */         for (int i1 = 0; i1 < n1; i1++) {
/* 10963 */           if (rxi3i2[i1] > max) {
/* 10964 */             max = rxi3i2[i1];
/* 10965 */             i1max = i1;
/* 10966 */             i2max = i2;
/* 10967 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 10972 */     if (index != null) {
/* 10973 */       index[0] = i1max;
/* 10974 */       index[1] = i2max;
/* 10975 */       index[2] = i3max;
/*       */     } 
/* 10977 */     return max;
/*       */   }
/*       */   public static short min(short[] rx) {
/* 10980 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static short min(short[][] rx) {
/* 10983 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static short min(short[][][] rx) {
/* 10986 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static short min(short[] rx, int[] index) {
/* 10989 */     int i1min = 0;
/* 10990 */     short min = rx[0];
/* 10991 */     int n1 = rx.length;
/* 10992 */     for (int i1 = 1; i1 < n1; i1++) {
/* 10993 */       if (rx[i1] < min) {
/* 10994 */         min = rx[i1];
/* 10995 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 10998 */     if (index != null)
/* 10999 */       index[0] = i1min; 
/* 11000 */     return min;
/*       */   }
/*       */   public static short min(short[][] rx, int[] index) {
/* 11003 */     int i1min = 0;
/* 11004 */     int i2min = 0;
/* 11005 */     short min = rx[0][0];
/* 11006 */     int n2 = rx.length;
/* 11007 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11008 */       short[] rxi2 = rx[i2];
/* 11009 */       int n1 = rxi2.length;
/* 11010 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11011 */         if (rxi2[i1] < min) {
/* 11012 */           min = rxi2[i1];
/* 11013 */           i2min = i2;
/* 11014 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11018 */     if (index != null) {
/* 11019 */       index[0] = i1min;
/* 11020 */       index[1] = i2min;
/*       */     } 
/* 11022 */     return min;
/*       */   }
/*       */   public static short min(short[][][] rx, int[] index) {
/* 11025 */     int i1min = 0;
/* 11026 */     int i2min = 0;
/* 11027 */     int i3min = 0;
/* 11028 */     short min = rx[0][0][0];
/* 11029 */     int n3 = rx.length;
/* 11030 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11031 */       short[][] rxi3 = rx[i3];
/* 11032 */       int n2 = rxi3.length;
/* 11033 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11034 */         short[] rxi3i2 = rxi3[i2];
/* 11035 */         int n1 = rxi3i2.length;
/* 11036 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11037 */           if (rxi3i2[i1] < min) {
/* 11038 */             min = rxi3i2[i1];
/* 11039 */             i1min = i1;
/* 11040 */             i2min = i2;
/* 11041 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11046 */     if (index != null) {
/* 11047 */       index[0] = i1min;
/* 11048 */       index[1] = i2min;
/* 11049 */       index[2] = i3min;
/*       */     } 
/* 11051 */     return min;
/*       */   }
/*       */   public static int max(int[] rx) {
/* 11054 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static int max(int[][] rx) {
/* 11057 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static int max(int[][][] rx) {
/* 11060 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static int max(int[] rx, int[] index) {
/* 11063 */     int i1max = 0;
/* 11064 */     int max = rx[0];
/* 11065 */     int n1 = rx.length;
/* 11066 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11067 */       if (rx[i1] > max) {
/* 11068 */         max = rx[i1];
/* 11069 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 11072 */     if (index != null)
/* 11073 */       index[0] = i1max; 
/* 11074 */     return max;
/*       */   }
/*       */   public static int max(int[][] rx, int[] index) {
/* 11077 */     int i1max = 0;
/* 11078 */     int i2max = 0;
/* 11079 */     int max = rx[0][0];
/* 11080 */     int n2 = rx.length;
/* 11081 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11082 */       int[] rxi2 = rx[i2];
/* 11083 */       int n1 = rxi2.length;
/* 11084 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11085 */         if (rxi2[i1] > max) {
/* 11086 */           max = rxi2[i1];
/* 11087 */           i2max = i2;
/* 11088 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11092 */     if (index != null) {
/* 11093 */       index[0] = i1max;
/* 11094 */       index[1] = i2max;
/*       */     } 
/* 11096 */     return max;
/*       */   }
/*       */   public static int max(int[][][] rx, int[] index) {
/* 11099 */     int i1max = 0;
/* 11100 */     int i2max = 0;
/* 11101 */     int i3max = 0;
/* 11102 */     int max = rx[0][0][0];
/* 11103 */     int n3 = rx.length;
/* 11104 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11105 */       int[][] rxi3 = rx[i3];
/* 11106 */       int n2 = rxi3.length;
/* 11107 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11108 */         int[] rxi3i2 = rxi3[i2];
/* 11109 */         int n1 = rxi3i2.length;
/* 11110 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11111 */           if (rxi3i2[i1] > max) {
/* 11112 */             max = rxi3i2[i1];
/* 11113 */             i1max = i1;
/* 11114 */             i2max = i2;
/* 11115 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11120 */     if (index != null) {
/* 11121 */       index[0] = i1max;
/* 11122 */       index[1] = i2max;
/* 11123 */       index[2] = i3max;
/*       */     } 
/* 11125 */     return max;
/*       */   }
/*       */   public static int min(int[] rx) {
/* 11128 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static int min(int[][] rx) {
/* 11131 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static int min(int[][][] rx) {
/* 11134 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static int min(int[] rx, int[] index) {
/* 11137 */     int i1min = 0;
/* 11138 */     int min = rx[0];
/* 11139 */     int n1 = rx.length;
/* 11140 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11141 */       if (rx[i1] < min) {
/* 11142 */         min = rx[i1];
/* 11143 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 11146 */     if (index != null)
/* 11147 */       index[0] = i1min; 
/* 11148 */     return min;
/*       */   }
/*       */   public static int min(int[][] rx, int[] index) {
/* 11151 */     int i1min = 0;
/* 11152 */     int i2min = 0;
/* 11153 */     int min = rx[0][0];
/* 11154 */     int n2 = rx.length;
/* 11155 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11156 */       int[] rxi2 = rx[i2];
/* 11157 */       int n1 = rxi2.length;
/* 11158 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11159 */         if (rxi2[i1] < min) {
/* 11160 */           min = rxi2[i1];
/* 11161 */           i2min = i2;
/* 11162 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11166 */     if (index != null) {
/* 11167 */       index[0] = i1min;
/* 11168 */       index[1] = i2min;
/*       */     } 
/* 11170 */     return min;
/*       */   }
/*       */   public static int min(int[][][] rx, int[] index) {
/* 11173 */     int i1min = 0;
/* 11174 */     int i2min = 0;
/* 11175 */     int i3min = 0;
/* 11176 */     int min = rx[0][0][0];
/* 11177 */     int n3 = rx.length;
/* 11178 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11179 */       int[][] rxi3 = rx[i3];
/* 11180 */       int n2 = rxi3.length;
/* 11181 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11182 */         int[] rxi3i2 = rxi3[i2];
/* 11183 */         int n1 = rxi3i2.length;
/* 11184 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11185 */           if (rxi3i2[i1] < min) {
/* 11186 */             min = rxi3i2[i1];
/* 11187 */             i1min = i1;
/* 11188 */             i2min = i2;
/* 11189 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11194 */     if (index != null) {
/* 11195 */       index[0] = i1min;
/* 11196 */       index[1] = i2min;
/* 11197 */       index[2] = i3min;
/*       */     } 
/* 11199 */     return min;
/*       */   }
/*       */   public static long max(long[] rx) {
/* 11202 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static long max(long[][] rx) {
/* 11205 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static long max(long[][][] rx) {
/* 11208 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static long max(long[] rx, int[] index) {
/* 11211 */     int i1max = 0;
/* 11212 */     long max = rx[0];
/* 11213 */     int n1 = rx.length;
/* 11214 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11215 */       if (rx[i1] > max) {
/* 11216 */         max = rx[i1];
/* 11217 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 11220 */     if (index != null)
/* 11221 */       index[0] = i1max; 
/* 11222 */     return max;
/*       */   }
/*       */   public static long max(long[][] rx, int[] index) {
/* 11225 */     int i1max = 0;
/* 11226 */     int i2max = 0;
/* 11227 */     long max = rx[0][0];
/* 11228 */     int n2 = rx.length;
/* 11229 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11230 */       long[] rxi2 = rx[i2];
/* 11231 */       int n1 = rxi2.length;
/* 11232 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11233 */         if (rxi2[i1] > max) {
/* 11234 */           max = rxi2[i1];
/* 11235 */           i2max = i2;
/* 11236 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11240 */     if (index != null) {
/* 11241 */       index[0] = i1max;
/* 11242 */       index[1] = i2max;
/*       */     } 
/* 11244 */     return max;
/*       */   }
/*       */   public static long max(long[][][] rx, int[] index) {
/* 11247 */     int i1max = 0;
/* 11248 */     int i2max = 0;
/* 11249 */     int i3max = 0;
/* 11250 */     long max = rx[0][0][0];
/* 11251 */     int n3 = rx.length;
/* 11252 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11253 */       long[][] rxi3 = rx[i3];
/* 11254 */       int n2 = rxi3.length;
/* 11255 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11256 */         long[] rxi3i2 = rxi3[i2];
/* 11257 */         int n1 = rxi3i2.length;
/* 11258 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11259 */           if (rxi3i2[i1] > max) {
/* 11260 */             max = rxi3i2[i1];
/* 11261 */             i1max = i1;
/* 11262 */             i2max = i2;
/* 11263 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11268 */     if (index != null) {
/* 11269 */       index[0] = i1max;
/* 11270 */       index[1] = i2max;
/* 11271 */       index[2] = i3max;
/*       */     } 
/* 11273 */     return max;
/*       */   }
/*       */   public static long min(long[] rx) {
/* 11276 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static long min(long[][] rx) {
/* 11279 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static long min(long[][][] rx) {
/* 11282 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static long min(long[] rx, int[] index) {
/* 11285 */     int i1min = 0;
/* 11286 */     long min = rx[0];
/* 11287 */     int n1 = rx.length;
/* 11288 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11289 */       if (rx[i1] < min) {
/* 11290 */         min = rx[i1];
/* 11291 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 11294 */     if (index != null)
/* 11295 */       index[0] = i1min; 
/* 11296 */     return min;
/*       */   }
/*       */   public static long min(long[][] rx, int[] index) {
/* 11299 */     int i1min = 0;
/* 11300 */     int i2min = 0;
/* 11301 */     long min = rx[0][0];
/* 11302 */     int n2 = rx.length;
/* 11303 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11304 */       long[] rxi2 = rx[i2];
/* 11305 */       int n1 = rxi2.length;
/* 11306 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11307 */         if (rxi2[i1] < min) {
/* 11308 */           min = rxi2[i1];
/* 11309 */           i2min = i2;
/* 11310 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11314 */     if (index != null) {
/* 11315 */       index[0] = i1min;
/* 11316 */       index[1] = i2min;
/*       */     } 
/* 11318 */     return min;
/*       */   }
/*       */   public static long min(long[][][] rx, int[] index) {
/* 11321 */     int i1min = 0;
/* 11322 */     int i2min = 0;
/* 11323 */     int i3min = 0;
/* 11324 */     long min = rx[0][0][0];
/* 11325 */     int n3 = rx.length;
/* 11326 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11327 */       long[][] rxi3 = rx[i3];
/* 11328 */       int n2 = rxi3.length;
/* 11329 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11330 */         long[] rxi3i2 = rxi3[i2];
/* 11331 */         int n1 = rxi3i2.length;
/* 11332 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11333 */           if (rxi3i2[i1] < min) {
/* 11334 */             min = rxi3i2[i1];
/* 11335 */             i1min = i1;
/* 11336 */             i2min = i2;
/* 11337 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11342 */     if (index != null) {
/* 11343 */       index[0] = i1min;
/* 11344 */       index[1] = i2min;
/* 11345 */       index[2] = i3min;
/*       */     } 
/* 11347 */     return min;
/*       */   }
/*       */   public static float max(float[] rx) {
/* 11350 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static float max(float[][] rx) {
/* 11353 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static float max(float[][][] rx) {
/* 11356 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static float max(float[] rx, int[] index) {
/* 11359 */     int i1max = 0;
/* 11360 */     float max = rx[0];
/* 11361 */     int n1 = rx.length;
/* 11362 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11363 */       if (rx[i1] > max) {
/* 11364 */         max = rx[i1];
/* 11365 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 11368 */     if (index != null)
/* 11369 */       index[0] = i1max; 
/* 11370 */     return max;
/*       */   }
/*       */   public static float max(float[][] rx, int[] index) {
/* 11373 */     int i1max = 0;
/* 11374 */     int i2max = 0;
/* 11375 */     float max = rx[0][0];
/* 11376 */     int n2 = rx.length;
/* 11377 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11378 */       float[] rxi2 = rx[i2];
/* 11379 */       int n1 = rxi2.length;
/* 11380 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11381 */         if (rxi2[i1] > max) {
/* 11382 */           max = rxi2[i1];
/* 11383 */           i2max = i2;
/* 11384 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11388 */     if (index != null) {
/* 11389 */       index[0] = i1max;
/* 11390 */       index[1] = i2max;
/*       */     } 
/* 11392 */     return max;
/*       */   }
/*       */   public static float max(float[][][] rx, int[] index) {
/* 11395 */     int i1max = 0;
/* 11396 */     int i2max = 0;
/* 11397 */     int i3max = 0;
/* 11398 */     float max = rx[0][0][0];
/* 11399 */     int n3 = rx.length;
/* 11400 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11401 */       float[][] rxi3 = rx[i3];
/* 11402 */       int n2 = rxi3.length;
/* 11403 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11404 */         float[] rxi3i2 = rxi3[i2];
/* 11405 */         int n1 = rxi3i2.length;
/* 11406 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11407 */           if (rxi3i2[i1] > max) {
/* 11408 */             max = rxi3i2[i1];
/* 11409 */             i1max = i1;
/* 11410 */             i2max = i2;
/* 11411 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11416 */     if (index != null) {
/* 11417 */       index[0] = i1max;
/* 11418 */       index[1] = i2max;
/* 11419 */       index[2] = i3max;
/*       */     } 
/* 11421 */     return max;
/*       */   }
/*       */   public static float min(float[] rx) {
/* 11424 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static float min(float[][] rx) {
/* 11427 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static float min(float[][][] rx) {
/* 11430 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static float min(float[] rx, int[] index) {
/* 11433 */     int i1min = 0;
/* 11434 */     float min = rx[0];
/* 11435 */     int n1 = rx.length;
/* 11436 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11437 */       if (rx[i1] < min) {
/* 11438 */         min = rx[i1];
/* 11439 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 11442 */     if (index != null)
/* 11443 */       index[0] = i1min; 
/* 11444 */     return min;
/*       */   }
/*       */   public static float min(float[][] rx, int[] index) {
/* 11447 */     int i1min = 0;
/* 11448 */     int i2min = 0;
/* 11449 */     float min = rx[0][0];
/* 11450 */     int n2 = rx.length;
/* 11451 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11452 */       float[] rxi2 = rx[i2];
/* 11453 */       int n1 = rxi2.length;
/* 11454 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11455 */         if (rxi2[i1] < min) {
/* 11456 */           min = rxi2[i1];
/* 11457 */           i2min = i2;
/* 11458 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11462 */     if (index != null) {
/* 11463 */       index[0] = i1min;
/* 11464 */       index[1] = i2min;
/*       */     } 
/* 11466 */     return min;
/*       */   }
/*       */   public static float min(float[][][] rx, int[] index) {
/* 11469 */     int i1min = 0;
/* 11470 */     int i2min = 0;
/* 11471 */     int i3min = 0;
/* 11472 */     float min = rx[0][0][0];
/* 11473 */     int n3 = rx.length;
/* 11474 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11475 */       float[][] rxi3 = rx[i3];
/* 11476 */       int n2 = rxi3.length;
/* 11477 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11478 */         float[] rxi3i2 = rxi3[i2];
/* 11479 */         int n1 = rxi3i2.length;
/* 11480 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11481 */           if (rxi3i2[i1] < min) {
/* 11482 */             min = rxi3i2[i1];
/* 11483 */             i1min = i1;
/* 11484 */             i2min = i2;
/* 11485 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11490 */     if (index != null) {
/* 11491 */       index[0] = i1min;
/* 11492 */       index[1] = i2min;
/* 11493 */       index[2] = i3min;
/*       */     } 
/* 11495 */     return min;
/*       */   }
/*       */   public static double max(double[] rx) {
/* 11498 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static double max(double[][] rx) {
/* 11501 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static double max(double[][][] rx) {
/* 11504 */     return max(rx, (int[])null);
/*       */   }
/*       */   public static double max(double[] rx, int[] index) {
/* 11507 */     int i1max = 0;
/* 11508 */     double max = rx[0];
/* 11509 */     int n1 = rx.length;
/* 11510 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11511 */       if (rx[i1] > max) {
/* 11512 */         max = rx[i1];
/* 11513 */         i1max = i1;
/*       */       } 
/*       */     } 
/* 11516 */     if (index != null)
/* 11517 */       index[0] = i1max; 
/* 11518 */     return max;
/*       */   }
/*       */   public static double max(double[][] rx, int[] index) {
/* 11521 */     int i1max = 0;
/* 11522 */     int i2max = 0;
/* 11523 */     double max = rx[0][0];
/* 11524 */     int n2 = rx.length;
/* 11525 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11526 */       double[] rxi2 = rx[i2];
/* 11527 */       int n1 = rxi2.length;
/* 11528 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11529 */         if (rxi2[i1] > max) {
/* 11530 */           max = rxi2[i1];
/* 11531 */           i2max = i2;
/* 11532 */           i1max = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11536 */     if (index != null) {
/* 11537 */       index[0] = i1max;
/* 11538 */       index[1] = i2max;
/*       */     } 
/* 11540 */     return max;
/*       */   }
/*       */   public static double max(double[][][] rx, int[] index) {
/* 11543 */     int i1max = 0;
/* 11544 */     int i2max = 0;
/* 11545 */     int i3max = 0;
/* 11546 */     double max = rx[0][0][0];
/* 11547 */     int n3 = rx.length;
/* 11548 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11549 */       double[][] rxi3 = rx[i3];
/* 11550 */       int n2 = rxi3.length;
/* 11551 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11552 */         double[] rxi3i2 = rxi3[i2];
/* 11553 */         int n1 = rxi3i2.length;
/* 11554 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11555 */           if (rxi3i2[i1] > max) {
/* 11556 */             max = rxi3i2[i1];
/* 11557 */             i1max = i1;
/* 11558 */             i2max = i2;
/* 11559 */             i3max = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11564 */     if (index != null) {
/* 11565 */       index[0] = i1max;
/* 11566 */       index[1] = i2max;
/* 11567 */       index[2] = i3max;
/*       */     } 
/* 11569 */     return max;
/*       */   }
/*       */   public static double min(double[] rx) {
/* 11572 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static double min(double[][] rx) {
/* 11575 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static double min(double[][][] rx) {
/* 11578 */     return min(rx, (int[])null);
/*       */   }
/*       */   public static double min(double[] rx, int[] index) {
/* 11581 */     int i1min = 0;
/* 11582 */     double min = rx[0];
/* 11583 */     int n1 = rx.length;
/* 11584 */     for (int i1 = 1; i1 < n1; i1++) {
/* 11585 */       if (rx[i1] < min) {
/* 11586 */         min = rx[i1];
/* 11587 */         i1min = i1;
/*       */       } 
/*       */     } 
/* 11590 */     if (index != null)
/* 11591 */       index[0] = i1min; 
/* 11592 */     return min;
/*       */   }
/*       */   public static double min(double[][] rx, int[] index) {
/* 11595 */     int i1min = 0;
/* 11596 */     int i2min = 0;
/* 11597 */     double min = rx[0][0];
/* 11598 */     int n2 = rx.length;
/* 11599 */     for (int i2 = 0; i2 < n2; i2++) {
/* 11600 */       double[] rxi2 = rx[i2];
/* 11601 */       int n1 = rxi2.length;
/* 11602 */       for (int i1 = 0; i1 < n1; i1++) {
/* 11603 */         if (rxi2[i1] < min) {
/* 11604 */           min = rxi2[i1];
/* 11605 */           i2min = i2;
/* 11606 */           i1min = i1;
/*       */         } 
/*       */       } 
/*       */     } 
/* 11610 */     if (index != null) {
/* 11611 */       index[0] = i1min;
/* 11612 */       index[1] = i2min;
/*       */     } 
/* 11614 */     return min;
/*       */   }
/*       */   public static double min(double[][][] rx, int[] index) {
/* 11617 */     int i1min = 0;
/* 11618 */     int i2min = 0;
/* 11619 */     int i3min = 0;
/* 11620 */     double min = rx[0][0][0];
/* 11621 */     int n3 = rx.length;
/* 11622 */     for (int i3 = 0; i3 < n3; i3++) {
/* 11623 */       double[][] rxi3 = rx[i3];
/* 11624 */       int n2 = rxi3.length;
/* 11625 */       for (int i2 = 0; i2 < n2; i2++) {
/* 11626 */         double[] rxi3i2 = rxi3[i2];
/* 11627 */         int n1 = rxi3i2.length;
/* 11628 */         for (int i1 = 0; i1 < n1; i1++) {
/* 11629 */           if (rxi3i2[i1] < min) {
/* 11630 */             min = rxi3i2[i1];
/* 11631 */             i1min = i1;
/* 11632 */             i2min = i2;
/* 11633 */             i3min = i3;
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/* 11638 */     if (index != null) {
/* 11639 */       index[0] = i1min;
/* 11640 */       index[1] = i2min;
/* 11641 */       index[2] = i3min;
/*       */     } 
/* 11643 */     return min;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cadd(float[] cx, float[] cy) {
/* 11650 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static float[] cadd(Cfloat ca, float[] cy) {
/* 11653 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static float[] cadd(float[] cx, Cfloat cb) {
/* 11656 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static float[][] cadd(float[][] cx, float[][] cy) {
/* 11659 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static float[][] cadd(Cfloat ca, float[][] cy) {
/* 11662 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static float[][] cadd(float[][] cx, Cfloat cb) {
/* 11665 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static float[][][] cadd(float[][][] cx, float[][][] cy) {
/* 11668 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static float[][][] cadd(Cfloat ca, float[][][] cy) {
/* 11671 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static float[][][] cadd(float[][][] cx, Cfloat cb) {
/* 11674 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static void cadd(float[] cx, float[] cy, float[] cz) {
/* 11677 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cfloat ca, float[] cy, float[] cz) {
/* 11680 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(float[] cx, Cfloat cb, float[] cz) {
/* 11683 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cadd(float[][] cx, float[][] cy, float[][] cz) {
/* 11686 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cfloat ca, float[][] cy, float[][] cz) {
/* 11689 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(float[][] cx, Cfloat cb, float[][] cz) {
/* 11692 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cadd(float[][][] cx, float[][][] cy, float[][][] cz) {
/* 11695 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cfloat ca, float[][][] cy, float[][][] cz) {
/* 11698 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(float[][][] cx, Cfloat cb, float[][][] cz) {
/* 11701 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static float[] csub(float[] cx, float[] cy) {
/* 11704 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static float[] csub(Cfloat ca, float[] cy) {
/* 11707 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static float[] csub(float[] cx, Cfloat cb) {
/* 11710 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static float[][] csub(float[][] cx, float[][] cy) {
/* 11713 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static float[][] csub(Cfloat ca, float[][] cy) {
/* 11716 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static float[][] csub(float[][] cx, Cfloat cb) {
/* 11719 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static float[][][] csub(float[][][] cx, float[][][] cy) {
/* 11722 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static float[][][] csub(Cfloat ca, float[][][] cy) {
/* 11725 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static float[][][] csub(float[][][] cx, Cfloat cb) {
/* 11728 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static void csub(float[] cx, float[] cy, float[] cz) {
/* 11731 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cfloat ca, float[] cy, float[] cz) {
/* 11734 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(float[] cx, Cfloat cb, float[] cz) {
/* 11737 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static void csub(float[][] cx, float[][] cy, float[][] cz) {
/* 11740 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cfloat ca, float[][] cy, float[][] cz) {
/* 11743 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(float[][] cx, Cfloat cb, float[][] cz) {
/* 11746 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static void csub(float[][][] cx, float[][][] cy, float[][][] cz) {
/* 11749 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cfloat ca, float[][][] cy, float[][][] cz) {
/* 11752 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(float[][][] cx, Cfloat cb, float[][][] cz) {
/* 11755 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static float[] cmul(float[] cx, float[] cy) {
/* 11758 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static float[] cmul(Cfloat ca, float[] cy) {
/* 11761 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static float[] cmul(float[] cx, Cfloat cb) {
/* 11764 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static float[][] cmul(float[][] cx, float[][] cy) {
/* 11767 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static float[][] cmul(Cfloat ca, float[][] cy) {
/* 11770 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static float[][] cmul(float[][] cx, Cfloat cb) {
/* 11773 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static float[][][] cmul(float[][][] cx, float[][][] cy) {
/* 11776 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static float[][][] cmul(Cfloat ca, float[][][] cy) {
/* 11779 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static float[][][] cmul(float[][][] cx, Cfloat cb) {
/* 11782 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static void cmul(float[] cx, float[] cy, float[] cz) {
/* 11785 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cfloat ca, float[] cy, float[] cz) {
/* 11788 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(float[] cx, Cfloat cb, float[] cz) {
/* 11791 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cmul(float[][] cx, float[][] cy, float[][] cz) {
/* 11794 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cfloat ca, float[][] cy, float[][] cz) {
/* 11797 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(float[][] cx, Cfloat cb, float[][] cz) {
/* 11800 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cmul(float[][][] cx, float[][][] cy, float[][][] cz) {
/* 11803 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cfloat ca, float[][][] cy, float[][][] cz) {
/* 11806 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(float[][][] cx, Cfloat cb, float[][][] cz) {
/* 11809 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static float[] cdiv(float[] cx, float[] cy) {
/* 11812 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static float[] cdiv(Cfloat ca, float[] cy) {
/* 11815 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static float[] cdiv(float[] cx, Cfloat cb) {
/* 11818 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static float[][] cdiv(float[][] cx, float[][] cy) {
/* 11821 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static float[][] cdiv(Cfloat ca, float[][] cy) {
/* 11824 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static float[][] cdiv(float[][] cx, Cfloat cb) {
/* 11827 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static float[][][] cdiv(float[][][] cx, float[][][] cy) {
/* 11830 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static float[][][] cdiv(Cfloat ca, float[][][] cy) {
/* 11833 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static float[][][] cdiv(float[][][] cx, Cfloat cb) {
/* 11836 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static void cdiv(float[] cx, float[] cy, float[] cz) {
/* 11839 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cfloat ca, float[] cy, float[] cz) {
/* 11842 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(float[] cx, Cfloat cb, float[] cz) {
/* 11845 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cdiv(float[][] cx, float[][] cy, float[][] cz) {
/* 11848 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cfloat ca, float[][] cy, float[][] cz) {
/* 11851 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(float[][] cx, Cfloat cb, float[][] cz) {
/* 11854 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cdiv(float[][][] cx, float[][][] cy, float[][][] cz) {
/* 11857 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cfloat ca, float[][][] cy, float[][][] cz) {
/* 11860 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(float[][][] cx, Cfloat cb, float[][][] cz) {
/* 11863 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   public static double[] cadd(double[] cx, double[] cy) {
/* 11866 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static double[] cadd(Cdouble ca, double[] cy) {
/* 11869 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static double[] cadd(double[] cx, Cdouble cb) {
/* 11872 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static double[][] cadd(double[][] cx, double[][] cy) {
/* 11875 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static double[][] cadd(Cdouble ca, double[][] cy) {
/* 11878 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static double[][] cadd(double[][] cx, Cdouble cb) {
/* 11881 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static double[][][] cadd(double[][][] cx, double[][][] cy) {
/* 11884 */     return _cadd.apply(cx, cy);
/*       */   }
/*       */   public static double[][][] cadd(Cdouble ca, double[][][] cy) {
/* 11887 */     return _cadd.apply(ca, cy);
/*       */   }
/*       */   public static double[][][] cadd(double[][][] cx, Cdouble cb) {
/* 11890 */     return _cadd.apply(cx, cb);
/*       */   }
/*       */   public static void cadd(double[] cx, double[] cy, double[] cz) {
/* 11893 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cdouble ca, double[] cy, double[] cz) {
/* 11896 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(double[] cx, Cdouble cb, double[] cz) {
/* 11899 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cadd(double[][] cx, double[][] cy, double[][] cz) {
/* 11902 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cdouble ca, double[][] cy, double[][] cz) {
/* 11905 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(double[][] cx, Cdouble cb, double[][] cz) {
/* 11908 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cadd(double[][][] cx, double[][][] cy, double[][][] cz) {
/* 11911 */     _cadd.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cadd(Cdouble ca, double[][][] cy, double[][][] cz) {
/* 11914 */     _cadd.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cadd(double[][][] cx, Cdouble cb, double[][][] cz) {
/* 11917 */     _cadd.apply(cx, cb, cz);
/*       */   }
/*       */   public static double[] csub(double[] cx, double[] cy) {
/* 11920 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static double[] csub(Cdouble ca, double[] cy) {
/* 11923 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static double[] csub(double[] cx, Cdouble cb) {
/* 11926 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static double[][] csub(double[][] cx, double[][] cy) {
/* 11929 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static double[][] csub(Cdouble ca, double[][] cy) {
/* 11932 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static double[][] csub(double[][] cx, Cdouble cb) {
/* 11935 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static double[][][] csub(double[][][] cx, double[][][] cy) {
/* 11938 */     return _csub.apply(cx, cy);
/*       */   }
/*       */   public static double[][][] csub(Cdouble ca, double[][][] cy) {
/* 11941 */     return _csub.apply(ca, cy);
/*       */   }
/*       */   public static double[][][] csub(double[][][] cx, Cdouble cb) {
/* 11944 */     return _csub.apply(cx, cb);
/*       */   }
/*       */   public static void csub(double[] cx, double[] cy, double[] cz) {
/* 11947 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cdouble ca, double[] cy, double[] cz) {
/* 11950 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(double[] cx, Cdouble cb, double[] cz) {
/* 11953 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static void csub(double[][] cx, double[][] cy, double[][] cz) {
/* 11956 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cdouble ca, double[][] cy, double[][] cz) {
/* 11959 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(double[][] cx, Cdouble cb, double[][] cz) {
/* 11962 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static void csub(double[][][] cx, double[][][] cy, double[][][] cz) {
/* 11965 */     _csub.apply(cx, cy, cz);
/*       */   }
/*       */   public static void csub(Cdouble ca, double[][][] cy, double[][][] cz) {
/* 11968 */     _csub.apply(ca, cy, cz);
/*       */   }
/*       */   public static void csub(double[][][] cx, Cdouble cb, double[][][] cz) {
/* 11971 */     _csub.apply(cx, cb, cz);
/*       */   }
/*       */   public static double[] cmul(double[] cx, double[] cy) {
/* 11974 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static double[] cmul(Cdouble ca, double[] cy) {
/* 11977 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static double[] cmul(double[] cx, Cdouble cb) {
/* 11980 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static double[][] cmul(double[][] cx, double[][] cy) {
/* 11983 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static double[][] cmul(Cdouble ca, double[][] cy) {
/* 11986 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static double[][] cmul(double[][] cx, Cdouble cb) {
/* 11989 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static double[][][] cmul(double[][][] cx, double[][][] cy) {
/* 11992 */     return _cmul.apply(cx, cy);
/*       */   }
/*       */   public static double[][][] cmul(Cdouble ca, double[][][] cy) {
/* 11995 */     return _cmul.apply(ca, cy);
/*       */   }
/*       */   public static double[][][] cmul(double[][][] cx, Cdouble cb) {
/* 11998 */     return _cmul.apply(cx, cb);
/*       */   }
/*       */   public static void cmul(double[] cx, double[] cy, double[] cz) {
/* 12001 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cdouble ca, double[] cy, double[] cz) {
/* 12004 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(double[] cx, Cdouble cb, double[] cz) {
/* 12007 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cmul(double[][] cx, double[][] cy, double[][] cz) {
/* 12010 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cdouble ca, double[][] cy, double[][] cz) {
/* 12013 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(double[][] cx, Cdouble cb, double[][] cz) {
/* 12016 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cmul(double[][][] cx, double[][][] cy, double[][][] cz) {
/* 12019 */     _cmul.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cmul(Cdouble ca, double[][][] cy, double[][][] cz) {
/* 12022 */     _cmul.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cmul(double[][][] cx, Cdouble cb, double[][][] cz) {
/* 12025 */     _cmul.apply(cx, cb, cz);
/*       */   }
/*       */   public static double[] cdiv(double[] cx, double[] cy) {
/* 12028 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static double[] cdiv(Cdouble ca, double[] cy) {
/* 12031 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static double[] cdiv(double[] cx, Cdouble cb) {
/* 12034 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static double[][] cdiv(double[][] cx, double[][] cy) {
/* 12037 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static double[][] cdiv(Cdouble ca, double[][] cy) {
/* 12040 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static double[][] cdiv(double[][] cx, Cdouble cb) {
/* 12043 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static double[][][] cdiv(double[][][] cx, double[][][] cy) {
/* 12046 */     return _cdiv.apply(cx, cy);
/*       */   }
/*       */   public static double[][][] cdiv(Cdouble ca, double[][][] cy) {
/* 12049 */     return _cdiv.apply(ca, cy);
/*       */   }
/*       */   public static double[][][] cdiv(double[][][] cx, Cdouble cb) {
/* 12052 */     return _cdiv.apply(cx, cb);
/*       */   }
/*       */   public static void cdiv(double[] cx, double[] cy, double[] cz) {
/* 12055 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cdouble ca, double[] cy, double[] cz) {
/* 12058 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(double[] cx, Cdouble cb, double[] cz) {
/* 12061 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cdiv(double[][] cx, double[][] cy, double[][] cz) {
/* 12064 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cdouble ca, double[][] cy, double[][] cz) {
/* 12067 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(double[][] cx, Cdouble cb, double[][] cz) {
/* 12070 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   public static void cdiv(double[][][] cx, double[][][] cy, double[][][] cz) {
/* 12073 */     _cdiv.apply(cx, cy, cz);
/*       */   }
/*       */   public static void cdiv(Cdouble ca, double[][][] cy, double[][][] cz) {
/* 12076 */     _cdiv.apply(ca, cy, cz);
/*       */   }
/*       */   public static void cdiv(double[][][] cx, Cdouble cb, double[][][] cz) {
/* 12079 */     _cdiv.apply(cx, cb, cz);
/*       */   }
/*       */   private static abstract class CBinary { private CBinary() {}
/*       */     float[] apply(float[] cx, float[] cy) {
/* 12083 */       int n1 = cx.length / 2;
/* 12084 */       float[] cz = new float[2 * n1];
/* 12085 */       apply(cx, cy, cz);
/* 12086 */       return cz;
/*       */     }
/*       */     float[] apply(Cfloat ca, float[] cy) {
/* 12089 */       int n1 = cy.length / 2;
/* 12090 */       float[] cz = new float[2 * n1];
/* 12091 */       apply(ca, cy, cz);
/* 12092 */       return cz;
/*       */     }
/*       */     float[] apply(float[] cx, Cfloat cb) {
/* 12095 */       int n1 = cx.length / 2;
/* 12096 */       float[] cz = new float[2 * n1];
/* 12097 */       apply(cx, cb, cz);
/* 12098 */       return cz;
/*       */     }
/*       */     float[][] apply(float[][] cx, float[][] cy) {
/* 12101 */       int n2 = cx.length;
/* 12102 */       float[][] cz = new float[n2][];
/* 12103 */       for (int i2 = 0; i2 < n2; i2++)
/* 12104 */         cz[i2] = apply(cx[i2], cy[i2]); 
/* 12105 */       return cz;
/*       */     }
/*       */     float[][] apply(Cfloat ca, float[][] cy) {
/* 12108 */       int n2 = cy.length;
/* 12109 */       float[][] cz = new float[n2][];
/* 12110 */       for (int i2 = 0; i2 < n2; i2++)
/* 12111 */         cz[i2] = apply(ca, cy[i2]); 
/* 12112 */       return cz;
/*       */     }
/*       */     float[][] apply(float[][] cx, Cfloat cb) {
/* 12115 */       int n2 = cx.length;
/* 12116 */       float[][] cz = new float[n2][];
/* 12117 */       for (int i2 = 0; i2 < n2; i2++)
/* 12118 */         cz[i2] = apply(cx[i2], cb); 
/* 12119 */       return cz;
/*       */     }
/*       */     float[][][] apply(float[][][] cx, float[][][] cy) {
/* 12122 */       int n3 = cx.length;
/* 12123 */       float[][][] cz = new float[n3][][];
/* 12124 */       for (int i3 = 0; i3 < n3; i3++)
/* 12125 */         cz[i3] = apply(cx[i3], cy[i3]); 
/* 12126 */       return cz;
/*       */     }
/*       */     float[][][] apply(Cfloat ca, float[][][] cy) {
/* 12129 */       int n3 = cy.length;
/* 12130 */       float[][][] cz = new float[n3][][];
/* 12131 */       for (int i3 = 0; i3 < n3; i3++)
/* 12132 */         cz[i3] = apply(ca, cy[i3]); 
/* 12133 */       return cz;
/*       */     }
/*       */     float[][][] apply(float[][][] cx, Cfloat cb) {
/* 12136 */       int n3 = cx.length;
/* 12137 */       float[][][] cz = new float[n3][][];
/* 12138 */       for (int i3 = 0; i3 < n3; i3++)
/* 12139 */         cz[i3] = apply(cx[i3], cb); 
/* 12140 */       return cz;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     void apply(float[][] cx, float[][] cy, float[][] cz) {
/* 12146 */       int n2 = cx.length;
/* 12147 */       for (int i2 = 0; i2 < n2; i2++)
/* 12148 */         apply(cx[i2], cy[i2], cz[i2]); 
/*       */     }
/*       */     void apply(Cfloat ca, float[][] cy, float[][] cz) {
/* 12151 */       int n2 = cy.length;
/* 12152 */       for (int i2 = 0; i2 < n2; i2++)
/* 12153 */         apply(ca, cy[i2], cz[i2]); 
/*       */     }
/*       */     void apply(float[][] cx, Cfloat cb, float[][] cz) {
/* 12156 */       int n2 = cx.length;
/* 12157 */       for (int i2 = 0; i2 < n2; i2++)
/* 12158 */         apply(cx[i2], cb, cz[i2]); 
/*       */     }
/*       */     void apply(float[][][] cx, float[][][] cy, float[][][] cz) {
/* 12161 */       int n3 = cx.length;
/* 12162 */       for (int i3 = 0; i3 < n3; i3++)
/* 12163 */         apply(cx[i3], cy[i3], cz[i3]); 
/*       */     }
/*       */     void apply(Cfloat ca, float[][][] cy, float[][][] cz) {
/* 12166 */       int n3 = cy.length;
/* 12167 */       for (int i3 = 0; i3 < n3; i3++)
/* 12168 */         apply(ca, cy[i3], cz[i3]); 
/*       */     }
/*       */     void apply(float[][][] cx, Cfloat cb, float[][][] cz) {
/* 12171 */       int n3 = cx.length;
/* 12172 */       for (int i3 = 0; i3 < n3; i3++)
/* 12173 */         apply(cx[i3], cb, cz[i3]); 
/*       */     }
/*       */     double[] apply(double[] cx, double[] cy) {
/* 12176 */       int n1 = cx.length / 2;
/* 12177 */       double[] cz = new double[2 * n1];
/* 12178 */       apply(cx, cy, cz);
/* 12179 */       return cz;
/*       */     }
/*       */     double[] apply(Cdouble ca, double[] cy) {
/* 12182 */       int n1 = cy.length / 2;
/* 12183 */       double[] cz = new double[2 * n1];
/* 12184 */       apply(ca, cy, cz);
/* 12185 */       return cz;
/*       */     }
/*       */     double[] apply(double[] cx, Cdouble cb) {
/* 12188 */       int n1 = cx.length / 2;
/* 12189 */       double[] cz = new double[2 * n1];
/* 12190 */       apply(cx, cb, cz);
/* 12191 */       return cz;
/*       */     }
/*       */     double[][] apply(double[][] cx, double[][] cy) {
/* 12194 */       int n2 = cx.length;
/* 12195 */       double[][] cz = new double[n2][];
/* 12196 */       for (int i2 = 0; i2 < n2; i2++)
/* 12197 */         cz[i2] = apply(cx[i2], cy[i2]); 
/* 12198 */       return cz;
/*       */     }
/*       */     double[][] apply(Cdouble ca, double[][] cy) {
/* 12201 */       int n2 = cy.length;
/* 12202 */       double[][] cz = new double[n2][];
/* 12203 */       for (int i2 = 0; i2 < n2; i2++)
/* 12204 */         cz[i2] = apply(ca, cy[i2]); 
/* 12205 */       return cz;
/*       */     }
/*       */     double[][] apply(double[][] cx, Cdouble cb) {
/* 12208 */       int n2 = cx.length;
/* 12209 */       double[][] cz = new double[n2][];
/* 12210 */       for (int i2 = 0; i2 < n2; i2++)
/* 12211 */         cz[i2] = apply(cx[i2], cb); 
/* 12212 */       return cz;
/*       */     }
/*       */     double[][][] apply(double[][][] cx, double[][][] cy) {
/* 12215 */       int n3 = cx.length;
/* 12216 */       double[][][] cz = new double[n3][][];
/* 12217 */       for (int i3 = 0; i3 < n3; i3++)
/* 12218 */         cz[i3] = apply(cx[i3], cy[i3]); 
/* 12219 */       return cz;
/*       */     }
/*       */     double[][][] apply(Cdouble ca, double[][][] cy) {
/* 12222 */       int n3 = cy.length;
/* 12223 */       double[][][] cz = new double[n3][][];
/* 12224 */       for (int i3 = 0; i3 < n3; i3++)
/* 12225 */         cz[i3] = apply(ca, cy[i3]); 
/* 12226 */       return cz;
/*       */     }
/*       */     double[][][] apply(double[][][] cx, Cdouble cb) {
/* 12229 */       int n3 = cx.length;
/* 12230 */       double[][][] cz = new double[n3][][];
/* 12231 */       for (int i3 = 0; i3 < n3; i3++)
/* 12232 */         cz[i3] = apply(cx[i3], cb); 
/* 12233 */       return cz;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     void apply(double[][] cx, double[][] cy, double[][] cz) {
/* 12239 */       int n2 = cx.length;
/* 12240 */       for (int i2 = 0; i2 < n2; i2++)
/* 12241 */         apply(cx[i2], cy[i2], cz[i2]); 
/*       */     }
/*       */     void apply(Cdouble ca, double[][] cy, double[][] cz) {
/* 12244 */       int n2 = cy.length;
/* 12245 */       for (int i2 = 0; i2 < n2; i2++)
/* 12246 */         apply(ca, cy[i2], cz[i2]); 
/*       */     }
/*       */     void apply(double[][] cx, Cdouble cb, double[][] cz) {
/* 12249 */       int n2 = cx.length;
/* 12250 */       for (int i2 = 0; i2 < n2; i2++)
/* 12251 */         apply(cx[i2], cb, cz[i2]); 
/*       */     }
/*       */     void apply(double[][][] cx, double[][][] cy, double[][][] cz) {
/* 12254 */       int n3 = cx.length;
/* 12255 */       for (int i3 = 0; i3 < n3; i3++)
/* 12256 */         apply(cx[i3], cy[i3], cz[i3]); 
/*       */     }
/*       */     void apply(Cdouble ca, double[][][] cy, double[][][] cz) {
/* 12259 */       int n3 = cy.length;
/* 12260 */       for (int i3 = 0; i3 < n3; i3++)
/* 12261 */         apply(ca, cy[i3], cz[i3]); 
/*       */     }
/*       */     void apply(double[][][] cx, Cdouble cb, double[][][] cz) {
/* 12264 */       int n3 = cx.length;
/* 12265 */       for (int i3 = 0; i3 < n3; i3++)
/* 12266 */         apply(cx[i3], cb, cz[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2, float[] param1ArrayOffloat3); abstract void apply(Cfloat param1Cfloat, float[] param1ArrayOffloat1, float[] param1ArrayOffloat2); abstract void apply(float[] param1ArrayOffloat1, Cfloat param1Cfloat, float[] param1ArrayOffloat2); abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2, double[] param1ArrayOfdouble3); abstract void apply(Cdouble param1Cdouble, double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, Cdouble param1Cdouble, double[] param1ArrayOfdouble2); }
/* 12269 */   private static CBinary _cadd = new CBinary() {
/*       */       void apply(float[] cx, float[] cy, float[] cz) {
/* 12271 */         int n1 = cx.length / 2;
/* 12272 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12273 */           cz[ir] = cx[ir] + cy[ir];
/* 12274 */           cz[ii] = cx[ii] + cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(Cfloat ca, float[] cy, float[] cz) {
/* 12278 */         int n1 = cy.length / 2;
/* 12279 */         float ar = ca.r;
/* 12280 */         float ai = ca.i;
/* 12281 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12282 */           cz[ir] = ar + cy[ir];
/* 12283 */           cz[ii] = ai + cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(float[] cx, Cfloat cb, float[] cz) {
/* 12287 */         int n1 = cx.length / 2;
/* 12288 */         float br = cb.r;
/* 12289 */         float bi = cb.i;
/* 12290 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12291 */           cz[ir] = cx[ir] + br;
/* 12292 */           cz[ii] = cx[ii] + bi;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy, double[] cz) {
/* 12296 */         int n1 = cx.length / 2;
/* 12297 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12298 */           cz[ir] = cx[ir] + cy[ir];
/* 12299 */           cz[ii] = cx[ii] + cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(Cdouble ca, double[] cy, double[] cz) {
/* 12303 */         int n1 = cy.length / 2;
/* 12304 */         double ar = ca.r;
/* 12305 */         double ai = ca.i;
/* 12306 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12307 */           cz[ir] = ar + cy[ir];
/* 12308 */           cz[ii] = ai + cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, Cdouble cb, double[] cz) {
/* 12312 */         int n1 = cx.length / 2;
/* 12313 */         double br = cb.r;
/* 12314 */         double bi = cb.i;
/* 12315 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12316 */           cz[ir] = cx[ir] + br;
/* 12317 */           cz[ii] = cx[ii] + bi;
/*       */         } 
/*       */       }
/*       */     };
/* 12321 */   private static CBinary _csub = new CBinary() {
/*       */       void apply(float[] cx, float[] cy, float[] cz) {
/* 12323 */         int n1 = cx.length / 2;
/* 12324 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12325 */           cz[ir] = cx[ir] - cy[ir];
/* 12326 */           cz[ii] = cx[ii] - cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(Cfloat ca, float[] cy, float[] cz) {
/* 12330 */         float ar = ca.r;
/* 12331 */         float ai = ca.i;
/* 12332 */         int n1 = cy.length / 2;
/* 12333 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12334 */           cz[ir] = ar - cy[ir];
/* 12335 */           cz[ii] = ai - cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(float[] cx, Cfloat cb, float[] cz) {
/* 12339 */         float br = cb.r;
/* 12340 */         float bi = cb.i;
/* 12341 */         int n1 = cx.length / 2;
/* 12342 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12343 */           cz[ir] = cx[ir] - br;
/* 12344 */           cz[ii] = cx[ii] - bi;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy, double[] cz) {
/* 12348 */         int n1 = cx.length / 2;
/* 12349 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12350 */           cz[ir] = cx[ir] - cy[ir];
/* 12351 */           cz[ii] = cx[ii] - cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(Cdouble ca, double[] cy, double[] cz) {
/* 12355 */         double ar = ca.r;
/* 12356 */         double ai = ca.i;
/* 12357 */         int n1 = cy.length / 2;
/* 12358 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12359 */           cz[ir] = ar - cy[ir];
/* 12360 */           cz[ii] = ai - cy[ii];
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, Cdouble cb, double[] cz) {
/* 12364 */         double br = cb.r;
/* 12365 */         double bi = cb.i;
/* 12366 */         int n1 = cx.length / 2;
/* 12367 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12368 */           cz[ir] = cx[ir] - br;
/* 12369 */           cz[ii] = cx[ii] - bi;
/*       */         } 
/*       */       }
/*       */     };
/* 12373 */   private static CBinary _cmul = new CBinary() {
/*       */       void apply(float[] cx, float[] cy, float[] cz) {
/* 12375 */         int n1 = cx.length / 2;
/* 12376 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12377 */           float xr = cx[ir];
/* 12378 */           float xi = cx[ii];
/* 12379 */           float yr = cy[ir];
/* 12380 */           float yi = cy[ii];
/* 12381 */           cz[ir] = xr * yr - xi * yi;
/* 12382 */           cz[ii] = xr * yi + xi * yr;
/*       */         } 
/*       */       }
/*       */       void apply(Cfloat ca, float[] cy, float[] cz) {
/* 12386 */         float ar = ca.r;
/* 12387 */         float ai = ca.i;
/* 12388 */         int n1 = cy.length / 2;
/* 12389 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12390 */           float yr = cy[ir];
/* 12391 */           float yi = cy[ii];
/* 12392 */           cz[ir] = ar * yr - ai * yi;
/* 12393 */           cz[ii] = ar * yi + ai * yr;
/*       */         } 
/*       */       }
/*       */       void apply(float[] cx, Cfloat cb, float[] cz) {
/* 12397 */         float br = cb.r;
/* 12398 */         float bi = cb.i;
/* 12399 */         int n1 = cx.length / 2;
/* 12400 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12401 */           float xr = cx[ir];
/* 12402 */           float xi = cx[ii];
/* 12403 */           cz[ir] = xr * br - xi * bi;
/* 12404 */           cz[ii] = xr * bi + xi * br;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy, double[] cz) {
/* 12408 */         int n1 = cx.length / 2;
/* 12409 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12410 */           double xr = cx[ir];
/* 12411 */           double xi = cx[ii];
/* 12412 */           double yr = cy[ir];
/* 12413 */           double yi = cy[ii];
/* 12414 */           cz[ir] = xr * yr - xi * yi;
/* 12415 */           cz[ii] = xr * yi + xi * yr;
/*       */         } 
/*       */       }
/*       */       void apply(Cdouble ca, double[] cy, double[] cz) {
/* 12419 */         double ar = ca.r;
/* 12420 */         double ai = ca.i;
/* 12421 */         int n1 = cy.length / 2;
/* 12422 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12423 */           double yr = cy[ir];
/* 12424 */           double yi = cy[ii];
/* 12425 */           cz[ir] = ar * yr - ai * yi;
/* 12426 */           cz[ii] = ar * yi + ai * yr;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, Cdouble cb, double[] cz) {
/* 12430 */         double br = cb.r;
/* 12431 */         double bi = cb.i;
/* 12432 */         int n1 = cx.length / 2;
/* 12433 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12434 */           double xr = cx[ir];
/* 12435 */           double xi = cx[ii];
/* 12436 */           cz[ir] = xr * br - xi * bi;
/* 12437 */           cz[ii] = xr * bi + xi * br;
/*       */         } 
/*       */       }
/*       */     };
/* 12441 */   private static CBinary _cdiv = new CBinary() {
/*       */       void apply(float[] cx, float[] cy, float[] cz) {
/* 12443 */         int n1 = cx.length / 2;
/* 12444 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12445 */           float xr = cx[ir];
/* 12446 */           float xi = cx[ii];
/* 12447 */           float yr = cy[ir];
/* 12448 */           float yi = cy[ii];
/* 12449 */           float yd = yr * yr + yi * yi;
/* 12450 */           cz[ir] = (xr * yr + xi * yi) / yd;
/* 12451 */           cz[ii] = (xi * yr - xr * yi) / yd;
/*       */         } 
/*       */       }
/*       */       void apply(Cfloat ca, float[] cy, float[] cz) {
/* 12455 */         float ar = ca.r;
/* 12456 */         float ai = ca.i;
/* 12457 */         int n1 = cy.length / 2;
/* 12458 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12459 */           float yr = cy[ir];
/* 12460 */           float yi = cy[ii];
/* 12461 */           float yd = yr * yr + yi * yi;
/* 12462 */           cz[ir] = (ar * yr + ai * yi) / yd;
/* 12463 */           cz[ii] = (ai * yr - ar * yi) / yd;
/*       */         } 
/*       */       }
/*       */       void apply(float[] cx, Cfloat cb, float[] cz) {
/* 12467 */         float br = cb.r;
/* 12468 */         float bi = cb.i;
/* 12469 */         float bd = br * br + bi * bi;
/* 12470 */         int n1 = cx.length / 2;
/* 12471 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12472 */           float xr = cx[ir];
/* 12473 */           float xi = cx[ii];
/* 12474 */           cz[ir] = (xr * br + xi * bi) / bd;
/* 12475 */           cz[ii] = (xi * br - xr * bi) / bd;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy, double[] cz) {
/* 12479 */         int n1 = cx.length / 2;
/* 12480 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12481 */           double xr = cx[ir];
/* 12482 */           double xi = cx[ii];
/* 12483 */           double yr = cy[ir];
/* 12484 */           double yi = cy[ii];
/* 12485 */           double yd = yr * yr + yi * yi;
/* 12486 */           cz[ir] = (xr * yr + xi * yi) / yd;
/* 12487 */           cz[ii] = (xi * yr - xr * yi) / yd;
/*       */         } 
/*       */       }
/*       */       void apply(Cdouble ca, double[] cy, double[] cz) {
/* 12491 */         double ar = ca.r;
/* 12492 */         double ai = ca.i;
/* 12493 */         int n1 = cy.length / 2;
/* 12494 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12495 */           double yr = cy[ir];
/* 12496 */           double yi = cy[ii];
/* 12497 */           double yd = yr * yr + yi * yi;
/* 12498 */           cz[ir] = (ar * yr + ai * yi) / yd;
/* 12499 */           cz[ii] = (ai * yr - ar * yi) / yd;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, Cdouble cb, double[] cz) {
/* 12503 */         double br = cb.r;
/* 12504 */         double bi = cb.i;
/* 12505 */         double bd = br * br + bi * bi;
/* 12506 */         int n1 = cx.length / 2;
/* 12507 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12508 */           double xr = cx[ir];
/* 12509 */           double xi = cx[ii];
/* 12510 */           cz[ir] = (xr * br + xi * bi) / bd;
/* 12511 */           cz[ii] = (xi * br - xr * bi) / bd;
/*       */         } 
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cneg(float[] cx) {
/* 12520 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static float[][] cneg(float[][] cx) {
/* 12523 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static float[][][] cneg(float[][][] cx) {
/* 12526 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static void cneg(float[] cx, float[] cy) {
/* 12529 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static void cneg(float[][] cx, float[][] cy) {
/* 12532 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static void cneg(float[][][] cx, float[][][] cy) {
/* 12535 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static float[] cconj(float[] cx) {
/* 12538 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static float[][] cconj(float[][] cx) {
/* 12541 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static float[][][] cconj(float[][][] cx) {
/* 12544 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static void cconj(float[] cx, float[] cy) {
/* 12547 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static void cconj(float[][] cx, float[][] cy) {
/* 12550 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static void cconj(float[][][] cx, float[][][] cy) {
/* 12553 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static float[] ccos(float[] cx) {
/* 12556 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static float[][] ccos(float[][] cx) {
/* 12559 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static float[][][] ccos(float[][][] cx) {
/* 12562 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static void ccos(float[] cx, float[] cy) {
/* 12565 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static void ccos(float[][] cx, float[][] cy) {
/* 12568 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static void ccos(float[][][] cx, float[][][] cy) {
/* 12571 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static float[] csin(float[] cx) {
/* 12574 */     return _csin.apply(cx);
/*       */   }
/*       */   public static float[][] csin(float[][] cx) {
/* 12577 */     return _csin.apply(cx);
/*       */   }
/*       */   public static float[][][] csin(float[][][] cx) {
/* 12580 */     return _csin.apply(cx);
/*       */   }
/*       */   public static void csin(float[] cx, float[] cy) {
/* 12583 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static void csin(float[][] cx, float[][] cy) {
/* 12586 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static void csin(float[][][] cx, float[][][] cy) {
/* 12589 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static float[] csqrt(float[] cx) {
/* 12592 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static float[][] csqrt(float[][] cx) {
/* 12595 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static float[][][] csqrt(float[][][] cx) {
/* 12598 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static void csqrt(float[] cx, float[] cy) {
/* 12601 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static void csqrt(float[][] cx, float[][] cy) {
/* 12604 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static void csqrt(float[][][] cx, float[][][] cy) {
/* 12607 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static float[] cexp(float[] cx) {
/* 12610 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static float[][] cexp(float[][] cx) {
/* 12613 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static float[][][] cexp(float[][][] cx) {
/* 12616 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static void cexp(float[] cx, float[] cy) {
/* 12619 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static void cexp(float[][] cx, float[][] cy) {
/* 12622 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static void cexp(float[][][] cx, float[][][] cy) {
/* 12625 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static float[] clog(float[] cx) {
/* 12628 */     return _clog.apply(cx);
/*       */   }
/*       */   public static float[][] clog(float[][] cx) {
/* 12631 */     return _clog.apply(cx);
/*       */   }
/*       */   public static float[][][] clog(float[][][] cx) {
/* 12634 */     return _clog.apply(cx);
/*       */   }
/*       */   public static void clog(float[] cx, float[] cy) {
/* 12637 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static void clog(float[][] cx, float[][] cy) {
/* 12640 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static void clog(float[][][] cx, float[][][] cy) {
/* 12643 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static float[] clog10(float[] cx) {
/* 12646 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static float[][] clog10(float[][] cx) {
/* 12649 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static float[][][] clog10(float[][][] cx) {
/* 12652 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static void clog10(float[] cx, float[] cy) {
/* 12655 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   public static void clog10(float[][] cx, float[][] cy) {
/* 12658 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   public static void clog10(float[][][] cx, float[][][] cy) {
/* 12661 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   public static double[] cneg(double[] cx) {
/* 12664 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static double[][] cneg(double[][] cx) {
/* 12667 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static double[][][] cneg(double[][][] cx) {
/* 12670 */     return _cneg.apply(cx);
/*       */   }
/*       */   public static void cneg(double[] cx, double[] cy) {
/* 12673 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static void cneg(double[][] cx, double[][] cy) {
/* 12676 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static void cneg(double[][][] cx, double[][][] cy) {
/* 12679 */     _cneg.apply(cx, cy);
/*       */   }
/*       */   public static double[] cconj(double[] cx) {
/* 12682 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static double[][] cconj(double[][] cx) {
/* 12685 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static double[][][] cconj(double[][][] cx) {
/* 12688 */     return _cconj.apply(cx);
/*       */   }
/*       */   public static void cconj(double[] cx, double[] cy) {
/* 12691 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static void cconj(double[][] cx, double[][] cy) {
/* 12694 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static void cconj(double[][][] cx, double[][][] cy) {
/* 12697 */     _cconj.apply(cx, cy);
/*       */   }
/*       */   public static double[] ccos(double[] cx) {
/* 12700 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static double[][] ccos(double[][] cx) {
/* 12703 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static double[][][] ccos(double[][][] cx) {
/* 12706 */     return _ccos.apply(cx);
/*       */   }
/*       */   public static void ccos(double[] cx, double[] cy) {
/* 12709 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static void ccos(double[][] cx, double[][] cy) {
/* 12712 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static void ccos(double[][][] cx, double[][][] cy) {
/* 12715 */     _ccos.apply(cx, cy);
/*       */   }
/*       */   public static double[] csin(double[] cx) {
/* 12718 */     return _csin.apply(cx);
/*       */   }
/*       */   public static double[][] csin(double[][] cx) {
/* 12721 */     return _csin.apply(cx);
/*       */   }
/*       */   public static double[][][] csin(double[][][] cx) {
/* 12724 */     return _csin.apply(cx);
/*       */   }
/*       */   public static void csin(double[] cx, double[] cy) {
/* 12727 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static void csin(double[][] cx, double[][] cy) {
/* 12730 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static void csin(double[][][] cx, double[][][] cy) {
/* 12733 */     _csin.apply(cx, cy);
/*       */   }
/*       */   public static double[] csqrt(double[] cx) {
/* 12736 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static double[][] csqrt(double[][] cx) {
/* 12739 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static double[][][] csqrt(double[][][] cx) {
/* 12742 */     return _csqrt.apply(cx);
/*       */   }
/*       */   public static void csqrt(double[] cx, double[] cy) {
/* 12745 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static void csqrt(double[][] cx, double[][] cy) {
/* 12748 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static void csqrt(double[][][] cx, double[][][] cy) {
/* 12751 */     _csqrt.apply(cx, cy);
/*       */   }
/*       */   public static double[] cexp(double[] cx) {
/* 12754 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static double[][] cexp(double[][] cx) {
/* 12757 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static double[][][] cexp(double[][][] cx) {
/* 12760 */     return _cexp.apply(cx);
/*       */   }
/*       */   public static void cexp(double[] cx, double[] cy) {
/* 12763 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static void cexp(double[][] cx, double[][] cy) {
/* 12766 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static void cexp(double[][][] cx, double[][][] cy) {
/* 12769 */     _cexp.apply(cx, cy);
/*       */   }
/*       */   public static double[] clog(double[] cx) {
/* 12772 */     return _clog.apply(cx);
/*       */   }
/*       */   public static double[][] clog(double[][] cx) {
/* 12775 */     return _clog.apply(cx);
/*       */   }
/*       */   public static double[][][] clog(double[][][] cx) {
/* 12778 */     return _clog.apply(cx);
/*       */   }
/*       */   public static void clog(double[] cx, double[] cy) {
/* 12781 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static void clog(double[][] cx, double[][] cy) {
/* 12784 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static void clog(double[][][] cx, double[][][] cy) {
/* 12787 */     _clog.apply(cx, cy);
/*       */   }
/*       */   public static double[] clog10(double[] cx) {
/* 12790 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static double[][] clog10(double[][] cx) {
/* 12793 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static double[][][] clog10(double[][][] cx) {
/* 12796 */     return _clog10.apply(cx);
/*       */   }
/*       */   public static void clog10(double[] cx, double[] cy) {
/* 12799 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   public static void clog10(double[][] cx, double[][] cy) {
/* 12802 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   public static void clog10(double[][][] cx, double[][][] cy) {
/* 12805 */     _clog10.apply(cx, cy);
/*       */   }
/*       */   private static abstract class ComplexToComplex { private ComplexToComplex() {}
/*       */     float[] apply(float[] cx) {
/* 12809 */       int n1 = cx.length / 2;
/* 12810 */       float[] cy = new float[2 * n1];
/* 12811 */       apply(cx, cy);
/* 12812 */       return cy;
/*       */     }
/*       */     float[][] apply(float[][] cx) {
/* 12815 */       int n2 = cx.length;
/* 12816 */       float[][] cy = new float[n2][];
/* 12817 */       for (int i2 = 0; i2 < n2; i2++)
/* 12818 */         cy[i2] = apply(cx[i2]); 
/* 12819 */       return cy;
/*       */     }
/*       */     float[][][] apply(float[][][] cx) {
/* 12822 */       int n3 = cx.length;
/* 12823 */       float[][][] cy = new float[n3][][];
/* 12824 */       for (int i3 = 0; i3 < n3; i3++)
/* 12825 */         cy[i3] = apply(cx[i3]); 
/* 12826 */       return cy;
/*       */     }
/*       */     
/*       */     void apply(float[][] cx, float[][] cy) {
/* 12830 */       int n2 = cx.length;
/* 12831 */       for (int i2 = 0; i2 < n2; i2++)
/* 12832 */         apply(cx[i2], cy[i2]); 
/*       */     }
/*       */     void apply(float[][][] cx, float[][][] cy) {
/* 12835 */       int n3 = cx.length;
/* 12836 */       for (int i3 = 0; i3 < n3; i3++)
/* 12837 */         apply(cx[i3], cy[i3]); 
/*       */     }
/*       */     double[] apply(double[] cx) {
/* 12840 */       int n1 = cx.length / 2;
/* 12841 */       double[] cy = new double[2 * n1];
/* 12842 */       apply(cx, cy);
/* 12843 */       return cy;
/*       */     }
/*       */     double[][] apply(double[][] cx) {
/* 12846 */       int n2 = cx.length;
/* 12847 */       double[][] cy = new double[n2][];
/* 12848 */       for (int i2 = 0; i2 < n2; i2++)
/* 12849 */         cy[i2] = apply(cx[i2]); 
/* 12850 */       return cy;
/*       */     }
/*       */     double[][][] apply(double[][][] cx) {
/* 12853 */       int n3 = cx.length;
/* 12854 */       double[][][] cy = new double[n3][][];
/* 12855 */       for (int i3 = 0; i3 < n3; i3++)
/* 12856 */         cy[i3] = apply(cx[i3]); 
/* 12857 */       return cy;
/*       */     }
/*       */     
/*       */     void apply(double[][] cx, double[][] cy) {
/* 12861 */       int n2 = cx.length;
/* 12862 */       for (int i2 = 0; i2 < n2; i2++)
/* 12863 */         apply(cx[i2], cy[i2]); 
/*       */     }
/*       */     void apply(double[][][] cx, double[][][] cy) {
/* 12866 */       int n3 = cx.length;
/* 12867 */       for (int i3 = 0; i3 < n3; i3++)
/* 12868 */         apply(cx[i3], cy[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2); }
/* 12871 */   private static ComplexToComplex _cneg = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12873 */         int n1 = cx.length;
/* 12874 */         for (int i1 = 0; i1 < n1; i1++)
/* 12875 */           cy[i1] = -cx[i1]; 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12878 */         int n1 = cx.length;
/* 12879 */         for (int i1 = 0; i1 < n1; i1++)
/* 12880 */           cy[i1] = -cx[i1]; 
/*       */       }
/*       */     };
/* 12883 */   private static ComplexToComplex _cconj = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12885 */         int n1 = cx.length / 2;
/* 12886 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12887 */           cy[ir] = cx[ir];
/* 12888 */           cy[ii] = -cx[ii];
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12892 */         int n1 = cx.length / 2;
/* 12893 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12894 */           cy[ir] = cx[ir];
/* 12895 */           cy[ii] = -cx[ii];
/*       */         } 
/*       */       }
/*       */     };
/* 12899 */   private static ComplexToComplex _ccos = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12901 */         Cfloat ct = new Cfloat();
/* 12902 */         int n1 = cx.length / 2;
/* 12903 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12904 */           ct.r = cx[ir];
/* 12905 */           ct.i = cx[ii];
/* 12906 */           Cfloat ce = Cfloat.cos(ct);
/* 12907 */           cy[ir] = ce.r;
/* 12908 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12912 */         Cdouble ct = new Cdouble();
/* 12913 */         int n1 = cx.length / 2;
/* 12914 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12915 */           ct.r = cx[ir];
/* 12916 */           ct.i = cx[ii];
/* 12917 */           Cdouble ce = Cdouble.cos(ct);
/* 12918 */           cy[ir] = ce.r;
/* 12919 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/* 12923 */   private static ComplexToComplex _csin = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12925 */         Cfloat ct = new Cfloat();
/* 12926 */         int n1 = cx.length / 2;
/* 12927 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12928 */           ct.r = cx[ir];
/* 12929 */           ct.i = cx[ii];
/* 12930 */           Cfloat ce = Cfloat.sin(ct);
/* 12931 */           cy[ir] = ce.r;
/* 12932 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12936 */         Cdouble ct = new Cdouble();
/* 12937 */         int n1 = cx.length / 2;
/* 12938 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12939 */           ct.r = cx[ir];
/* 12940 */           ct.i = cx[ii];
/* 12941 */           Cdouble ce = Cdouble.sin(ct);
/* 12942 */           cy[ir] = ce.r;
/* 12943 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/* 12947 */   private static ComplexToComplex _csqrt = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12949 */         Cfloat ct = new Cfloat();
/* 12950 */         int n1 = cx.length / 2;
/* 12951 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12952 */           ct.r = cx[ir];
/* 12953 */           ct.i = cx[ii];
/* 12954 */           Cfloat ce = Cfloat.sqrt(ct);
/* 12955 */           cy[ir] = ce.r;
/* 12956 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12960 */         Cdouble ct = new Cdouble();
/* 12961 */         int n1 = cx.length / 2;
/* 12962 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12963 */           ct.r = cx[ir];
/* 12964 */           ct.i = cx[ii];
/* 12965 */           Cdouble ce = Cdouble.sqrt(ct);
/* 12966 */           cy[ir] = ce.r;
/* 12967 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/* 12971 */   private static ComplexToComplex _cexp = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12973 */         Cfloat ct = new Cfloat();
/* 12974 */         int n1 = cx.length / 2;
/* 12975 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12976 */           ct.r = cx[ir];
/* 12977 */           ct.i = cx[ii];
/* 12978 */           Cfloat ce = Cfloat.exp(ct);
/* 12979 */           cy[ir] = ce.r;
/* 12980 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 12984 */         Cdouble ct = new Cdouble();
/* 12985 */         int n1 = cx.length / 2;
/* 12986 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 12987 */           ct.r = cx[ir];
/* 12988 */           ct.i = cx[ii];
/* 12989 */           Cdouble ce = Cdouble.exp(ct);
/* 12990 */           cy[ir] = ce.r;
/* 12991 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/* 12995 */   private static ComplexToComplex _clog = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 12997 */         Cfloat ct = new Cfloat();
/* 12998 */         int n1 = cx.length / 2;
/* 12999 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13000 */           ct.r = cx[ir];
/* 13001 */           ct.i = cx[ii];
/* 13002 */           Cfloat ce = Cfloat.log(ct);
/* 13003 */           cy[ir] = ce.r;
/* 13004 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 13008 */         Cdouble ct = new Cdouble();
/* 13009 */         int n1 = cx.length / 2;
/* 13010 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13011 */           ct.r = cx[ir];
/* 13012 */           ct.i = cx[ii];
/* 13013 */           Cdouble ce = Cdouble.log(ct);
/* 13014 */           cy[ir] = ce.r;
/* 13015 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/* 13019 */   private static ComplexToComplex _clog10 = new ComplexToComplex() {
/*       */       void apply(float[] cx, float[] cy) {
/* 13021 */         Cfloat ct = new Cfloat();
/* 13022 */         int n1 = cx.length / 2;
/* 13023 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13024 */           ct.r = cx[ir];
/* 13025 */           ct.i = cx[ii];
/* 13026 */           Cfloat ce = Cfloat.log10(ct);
/* 13027 */           cy[ir] = ce.r;
/* 13028 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] cy) {
/* 13032 */         Cdouble ct = new Cdouble();
/* 13033 */         int n1 = cx.length / 2;
/* 13034 */         for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13035 */           ct.r = cx[ir];
/* 13036 */           ct.i = cx[ii];
/* 13037 */           Cdouble ce = Cdouble.log10(ct);
/* 13038 */           cy[ir] = ce.r;
/* 13039 */           cy[ii] = ce.i;
/*       */         } 
/*       */       }
/*       */     };
/*       */   
/*       */   public static float[] cpow(float[] cx, float ra) {
/* 13045 */     int n1 = cx.length / 2;
/* 13046 */     float[] cy = new float[2 * n1];
/* 13047 */     cpow(cx, ra, cy);
/* 13048 */     return cy;
/*       */   }
/*       */   public static float[][] cpow(float[][] cx, float ra) {
/* 13051 */     int n2 = cx.length;
/* 13052 */     float[][] cy = new float[n2][];
/* 13053 */     for (int i2 = 0; i2 < n2; i2++)
/* 13054 */       cy[i2] = cpow(cx[i2], ra); 
/* 13055 */     return cy;
/*       */   }
/*       */   public static float[][][] cpow(float[][][] cx, float ra) {
/* 13058 */     int n3 = cx.length;
/* 13059 */     float[][][] cy = new float[n3][][];
/* 13060 */     for (int i3 = 0; i3 < n3; i3++)
/* 13061 */       cy[i3] = cpow(cx[i3], ra); 
/* 13062 */     return cy;
/*       */   }
/*       */   public static void cpow(float[] cx, float ra, float[] cy) {
/* 13065 */     Cfloat ct = new Cfloat();
/* 13066 */     int n1 = cx.length / 2;
/* 13067 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13068 */       ct.r = cx[ir];
/* 13069 */       ct.i = cx[ii];
/* 13070 */       Cfloat ce = Cfloat.pow(ct, ra);
/* 13071 */       cy[ir] = ce.r;
/* 13072 */       cy[ii] = ce.i;
/*       */     } 
/*       */   }
/*       */   public static void cpow(float[][] cx, float ra, float[][] cy) {
/* 13076 */     int n2 = cx.length;
/* 13077 */     for (int i2 = 0; i2 < n2; i2++)
/* 13078 */       cpow(cx[i2], ra, cy[i2]); 
/*       */   }
/*       */   public static void cpow(float[][][] cx, float ra, float[][][] cy) {
/* 13081 */     int n3 = cx.length;
/* 13082 */     for (int i3 = 0; i3 < n3; i3++)
/* 13083 */       cpow(cx[i3], ra, cy[i3]); 
/*       */   }
/*       */   public static float[] cpow(float[] cx, Cfloat ca) {
/* 13086 */     int n1 = cx.length / 2;
/* 13087 */     float[] cy = new float[2 * n1];
/* 13088 */     cpow(cx, ca, cy);
/* 13089 */     return cy;
/*       */   }
/*       */   public static float[][] cpow(float[][] cx, Cfloat ca) {
/* 13092 */     int n2 = cx.length;
/* 13093 */     float[][] cy = new float[n2][];
/* 13094 */     for (int i2 = 0; i2 < n2; i2++)
/* 13095 */       cy[i2] = cpow(cx[i2], ca); 
/* 13096 */     return cy;
/*       */   }
/*       */   public static float[][][] cpow(float[][][] cx, Cfloat ca) {
/* 13099 */     int n3 = cx.length;
/* 13100 */     float[][][] cy = new float[n3][][];
/* 13101 */     for (int i3 = 0; i3 < n3; i3++)
/* 13102 */       cy[i3] = cpow(cx[i3], ca); 
/* 13103 */     return cy;
/*       */   }
/*       */   public static void cpow(float[] cx, Cfloat ca, float[] cy) {
/* 13106 */     Cfloat ct = new Cfloat();
/* 13107 */     int n1 = cx.length / 2;
/* 13108 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13109 */       ct.r = cx[ir];
/* 13110 */       ct.i = cx[ii];
/* 13111 */       Cfloat ce = Cfloat.pow(ct, ca);
/* 13112 */       cy[ir] = ce.r;
/* 13113 */       cy[ii] = ce.i;
/*       */     } 
/*       */   }
/*       */   public static void cpow(float[][] cx, Cfloat ca, float[][] cy) {
/* 13117 */     int n2 = cx.length;
/* 13118 */     for (int i2 = 0; i2 < n2; i2++)
/* 13119 */       cpow(cx[i2], ca, cy[i2]); 
/*       */   }
/*       */   public static void cpow(float[][][] cx, Cfloat ca, float[][][] cy) {
/* 13122 */     int n3 = cx.length;
/* 13123 */     for (int i3 = 0; i3 < n3; i3++)
/* 13124 */       cpow(cx[i3], ca, cy[i3]); 
/*       */   }
/*       */   public static double[] cpow(double[] cx, double ra) {
/* 13127 */     int n1 = cx.length / 2;
/* 13128 */     double[] cy = new double[2 * n1];
/* 13129 */     cpow(cx, ra, cy);
/* 13130 */     return cy;
/*       */   }
/*       */   public static double[][] cpow(double[][] cx, double ra) {
/* 13133 */     int n2 = cx.length;
/* 13134 */     double[][] cy = new double[n2][];
/* 13135 */     for (int i2 = 0; i2 < n2; i2++)
/* 13136 */       cy[i2] = cpow(cx[i2], ra); 
/* 13137 */     return cy;
/*       */   }
/*       */   public static double[][][] cpow(double[][][] cx, double ra) {
/* 13140 */     int n3 = cx.length;
/* 13141 */     double[][][] cy = new double[n3][][];
/* 13142 */     for (int i3 = 0; i3 < n3; i3++)
/* 13143 */       cy[i3] = cpow(cx[i3], ra); 
/* 13144 */     return cy;
/*       */   }
/*       */   public static void cpow(double[] cx, double ra, double[] cy) {
/* 13147 */     Cdouble ct = new Cdouble();
/* 13148 */     int n1 = cx.length / 2;
/* 13149 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13150 */       ct.r = cx[ir];
/* 13151 */       ct.i = cx[ii];
/* 13152 */       Cdouble ce = Cdouble.pow(ct, ra);
/* 13153 */       cy[ir] = ce.r;
/* 13154 */       cy[ii] = ce.i;
/*       */     } 
/*       */   }
/*       */   public static void cpow(double[][] cx, double ra, double[][] cy) {
/* 13158 */     int n2 = cx.length;
/* 13159 */     for (int i2 = 0; i2 < n2; i2++)
/* 13160 */       cpow(cx[i2], ra, cy[i2]); 
/*       */   }
/*       */   public static void cpow(double[][][] cx, double ra, double[][][] cy) {
/* 13163 */     int n3 = cx.length;
/* 13164 */     for (int i3 = 0; i3 < n3; i3++)
/* 13165 */       cpow(cx[i3], ra, cy[i3]); 
/*       */   }
/*       */   public static double[] cpow(double[] cx, Cdouble ca) {
/* 13168 */     int n1 = cx.length / 2;
/* 13169 */     double[] cy = new double[2 * n1];
/* 13170 */     cpow(cx, ca, cy);
/* 13171 */     return cy;
/*       */   }
/*       */   public static double[][] cpow(double[][] cx, Cdouble ca) {
/* 13174 */     int n2 = cx.length;
/* 13175 */     double[][] cy = new double[n2][];
/* 13176 */     for (int i2 = 0; i2 < n2; i2++)
/* 13177 */       cy[i2] = cpow(cx[i2], ca); 
/* 13178 */     return cy;
/*       */   }
/*       */   public static double[][][] cpow(double[][][] cx, Cdouble ca) {
/* 13181 */     int n3 = cx.length;
/* 13182 */     double[][][] cy = new double[n3][][];
/* 13183 */     for (int i3 = 0; i3 < n3; i3++)
/* 13184 */       cy[i3] = cpow(cx[i3], ca); 
/* 13185 */     return cy;
/*       */   }
/*       */   public static void cpow(double[] cx, Cdouble ca, double[] cy) {
/* 13188 */     Cdouble ct = new Cdouble();
/* 13189 */     int n1 = cx.length / 2;
/* 13190 */     for (int ir = 0, ii = 1, nn = 2 * n1; ir < nn; ir += 2, ii += 2) {
/* 13191 */       ct.r = cx[ir];
/* 13192 */       ct.i = cx[ii];
/* 13193 */       Cdouble ce = Cdouble.pow(ct, ca);
/* 13194 */       cy[ir] = ce.r;
/* 13195 */       cy[ii] = ce.i;
/*       */     } 
/*       */   }
/*       */   public static void cpow(double[][] cx, Cdouble ca, double[][] cy) {
/* 13199 */     int n2 = cx.length;
/* 13200 */     for (int i2 = 0; i2 < n2; i2++)
/* 13201 */       cpow(cx[i2], ca, cy[i2]); 
/*       */   }
/*       */   public static void cpow(double[][][] cx, Cdouble ca, double[][][] cy) {
/* 13204 */     int n3 = cx.length;
/* 13205 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13206 */       cpow(cx[i3], ca, cy[i3]);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] creal(float[] cx) {
/* 13213 */     return _creal.apply(cx);
/*       */   }
/*       */   public static float[][] creal(float[][] cx) {
/* 13216 */     return _creal.apply(cx);
/*       */   }
/*       */   public static float[][][] creal(float[][][] cx) {
/* 13219 */     return _creal.apply(cx);
/*       */   }
/*       */   public static void creal(float[] cx, float[] cy) {
/* 13222 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static void creal(float[][] cx, float[][] cy) {
/* 13225 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static void creal(float[][][] cx, float[][][] cy) {
/* 13228 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static float[] cimag(float[] cx) {
/* 13231 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static float[][] cimag(float[][] cx) {
/* 13234 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static float[][][] cimag(float[][][] cx) {
/* 13237 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static void cimag(float[] cx, float[] cy) {
/* 13240 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static void cimag(float[][] cx, float[][] cy) {
/* 13243 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static void cimag(float[][][] cx, float[][][] cy) {
/* 13246 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static float[] cabs(float[] cx) {
/* 13249 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static float[][] cabs(float[][] cx) {
/* 13252 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static float[][][] cabs(float[][][] cx) {
/* 13255 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static void cabs(float[] cx, float[] cy) {
/* 13258 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static void cabs(float[][] cx, float[][] cy) {
/* 13261 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static void cabs(float[][][] cx, float[][][] cy) {
/* 13264 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static float[] carg(float[] cx) {
/* 13267 */     return _carg.apply(cx);
/*       */   }
/*       */   public static float[][] carg(float[][] cx) {
/* 13270 */     return _carg.apply(cx);
/*       */   }
/*       */   public static float[][][] carg(float[][][] cx) {
/* 13273 */     return _carg.apply(cx);
/*       */   }
/*       */   public static void carg(float[] cx, float[] cy) {
/* 13276 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static void carg(float[][] cx, float[][] cy) {
/* 13279 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static void carg(float[][][] cx, float[][][] cy) {
/* 13282 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static float[] cnorm(float[] cx) {
/* 13285 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static float[][] cnorm(float[][] cx) {
/* 13288 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static float[][][] cnorm(float[][][] cx) {
/* 13291 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static void cnorm(float[] cx, float[] cy) {
/* 13294 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   public static void cnorm(float[][] cx, float[][] cy) {
/* 13297 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   public static void cnorm(float[][][] cx, float[][][] cy) {
/* 13300 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   public static double[] creal(double[] cx) {
/* 13303 */     return _creal.apply(cx);
/*       */   }
/*       */   public static double[][] creal(double[][] cx) {
/* 13306 */     return _creal.apply(cx);
/*       */   }
/*       */   public static double[][][] creal(double[][][] cx) {
/* 13309 */     return _creal.apply(cx);
/*       */   }
/*       */   public static void creal(double[] cx, double[] cy) {
/* 13312 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static void creal(double[][] cx, double[][] cy) {
/* 13315 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static void creal(double[][][] cx, double[][][] cy) {
/* 13318 */     _creal.apply(cx, cy);
/*       */   }
/*       */   public static double[] cimag(double[] cx) {
/* 13321 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static double[][] cimag(double[][] cx) {
/* 13324 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static double[][][] cimag(double[][][] cx) {
/* 13327 */     return _cimag.apply(cx);
/*       */   }
/*       */   public static void cimag(double[] cx, double[] cy) {
/* 13330 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static void cimag(double[][] cx, double[][] cy) {
/* 13333 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static void cimag(double[][][] cx, double[][][] cy) {
/* 13336 */     _cimag.apply(cx, cy);
/*       */   }
/*       */   public static double[] cabs(double[] cx) {
/* 13339 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static double[][] cabs(double[][] cx) {
/* 13342 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static double[][][] cabs(double[][][] cx) {
/* 13345 */     return _cabs.apply(cx);
/*       */   }
/*       */   public static void cabs(double[] cx, double[] cy) {
/* 13348 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static void cabs(double[][] cx, double[][] cy) {
/* 13351 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static void cabs(double[][][] cx, double[][][] cy) {
/* 13354 */     _cabs.apply(cx, cy);
/*       */   }
/*       */   public static double[] carg(double[] cx) {
/* 13357 */     return _carg.apply(cx);
/*       */   }
/*       */   public static double[][] carg(double[][] cx) {
/* 13360 */     return _carg.apply(cx);
/*       */   }
/*       */   public static double[][][] carg(double[][][] cx) {
/* 13363 */     return _carg.apply(cx);
/*       */   }
/*       */   public static void carg(double[] cx, double[] cy) {
/* 13366 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static void carg(double[][] cx, double[][] cy) {
/* 13369 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static void carg(double[][][] cx, double[][][] cy) {
/* 13372 */     _carg.apply(cx, cy);
/*       */   }
/*       */   public static double[] cnorm(double[] cx) {
/* 13375 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static double[][] cnorm(double[][] cx) {
/* 13378 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static double[][][] cnorm(double[][][] cx) {
/* 13381 */     return _cnorm.apply(cx);
/*       */   }
/*       */   public static void cnorm(double[] cx, double[] cy) {
/* 13384 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   public static void cnorm(double[][] cx, double[][] cy) {
/* 13387 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   public static void cnorm(double[][][] cx, double[][][] cy) {
/* 13390 */     _cnorm.apply(cx, cy);
/*       */   }
/*       */   private static abstract class ComplexToReal { private ComplexToReal() {}
/*       */     float[] apply(float[] cx) {
/* 13394 */       int n1 = cx.length / 2;
/* 13395 */       float[] cy = new float[n1];
/* 13396 */       apply(cx, cy);
/* 13397 */       return cy;
/*       */     }
/*       */     float[][] apply(float[][] cx) {
/* 13400 */       int n2 = cx.length;
/* 13401 */       float[][] cy = new float[n2][];
/* 13402 */       for (int i2 = 0; i2 < n2; i2++)
/* 13403 */         cy[i2] = apply(cx[i2]); 
/* 13404 */       return cy;
/*       */     }
/*       */     float[][][] apply(float[][][] cx) {
/* 13407 */       int n3 = cx.length;
/* 13408 */       float[][][] cy = new float[n3][][];
/* 13409 */       for (int i3 = 0; i3 < n3; i3++)
/* 13410 */         cy[i3] = apply(cx[i3]); 
/* 13411 */       return cy;
/*       */     }
/*       */     
/*       */     void apply(float[][] cx, float[][] ry) {
/* 13415 */       int n2 = cx.length;
/* 13416 */       for (int i2 = 0; i2 < n2; i2++)
/* 13417 */         apply(cx[i2], ry[i2]); 
/*       */     }
/*       */     void apply(float[][][] cx, float[][][] ry) {
/* 13420 */       int n3 = cx.length;
/* 13421 */       for (int i3 = 0; i3 < n3; i3++)
/* 13422 */         apply(cx[i3], ry[i3]); 
/*       */     }
/*       */     double[] apply(double[] cx) {
/* 13425 */       int n1 = cx.length / 2;
/* 13426 */       double[] cy = new double[n1];
/* 13427 */       apply(cx, cy);
/* 13428 */       return cy;
/*       */     }
/*       */     double[][] apply(double[][] cx) {
/* 13431 */       int n2 = cx.length;
/* 13432 */       double[][] cy = new double[n2][];
/* 13433 */       for (int i2 = 0; i2 < n2; i2++)
/* 13434 */         cy[i2] = apply(cx[i2]); 
/* 13435 */       return cy;
/*       */     }
/*       */     double[][][] apply(double[][][] cx) {
/* 13438 */       int n3 = cx.length;
/* 13439 */       double[][][] cy = new double[n3][][];
/* 13440 */       for (int i3 = 0; i3 < n3; i3++)
/* 13441 */         cy[i3] = apply(cx[i3]); 
/* 13442 */       return cy;
/*       */     }
/*       */     
/*       */     void apply(double[][] cx, double[][] ry) {
/* 13446 */       int n2 = cx.length;
/* 13447 */       for (int i2 = 0; i2 < n2; i2++)
/* 13448 */         apply(cx[i2], ry[i2]); 
/*       */     }
/*       */     void apply(double[][][] cx, double[][][] ry) {
/* 13451 */       int n3 = cx.length;
/* 13452 */       for (int i3 = 0; i3 < n3; i3++)
/* 13453 */         apply(cx[i3], ry[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2); }
/* 13456 */   private static ComplexToReal _creal = new ComplexToReal() {
/*       */       void apply(float[] cx, float[] ry) {
/* 13458 */         int n1 = cx.length / 2;
/* 13459 */         for (int i1 = 0, ir = 0; i1 < n1; i1++, ir += 2)
/* 13460 */           ry[i1] = cx[ir]; 
/*       */       }
/*       */       void apply(double[] cx, double[] ry) {
/* 13463 */         int n1 = cx.length / 2;
/* 13464 */         for (int i1 = 0, ir = 0; i1 < n1; i1++, ir += 2)
/* 13465 */           ry[i1] = cx[ir]; 
/*       */       }
/*       */     };
/* 13468 */   private static ComplexToReal _cimag = new ComplexToReal() {
/*       */       void apply(float[] cx, float[] ry) {
/* 13470 */         int n1 = cx.length / 2;
/* 13471 */         for (int i1 = 0, ii = 1; i1 < n1; i1++, ii += 2)
/* 13472 */           ry[i1] = cx[ii]; 
/*       */       }
/*       */       void apply(double[] cx, double[] ry) {
/* 13475 */         int n1 = cx.length / 2;
/* 13476 */         for (int i1 = 0, ii = 1; i1 < n1; i1++, ii += 2)
/* 13477 */           ry[i1] = cx[ii]; 
/*       */       }
/*       */     };
/* 13480 */   private static ComplexToReal _cabs = new ComplexToReal() {
/*       */       void apply(float[] cx, float[] ry) {
/* 13482 */         Cfloat ct = new Cfloat();
/* 13483 */         int n1 = cx.length / 2;
/* 13484 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13485 */           ct.r = cx[ir];
/* 13486 */           ct.i = cx[ii];
/* 13487 */           ry[i1] = Cfloat.abs(ct);
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] ry) {
/* 13491 */         Cdouble ct = new Cdouble();
/* 13492 */         int n1 = cx.length / 2;
/* 13493 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13494 */           ct.r = cx[ir];
/* 13495 */           ct.i = cx[ii];
/* 13496 */           ry[i1] = Cdouble.abs(ct);
/*       */         } 
/*       */       }
/*       */     };
/* 13500 */   private static ComplexToReal _carg = new ComplexToReal() {
/*       */       void apply(float[] cx, float[] ry) {
/* 13502 */         Cfloat ct = new Cfloat();
/* 13503 */         int n1 = cx.length / 2;
/* 13504 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13505 */           ct.r = cx[ir];
/* 13506 */           ct.i = cx[ii];
/* 13507 */           ry[i1] = Cfloat.arg(ct);
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] ry) {
/* 13511 */         Cdouble ct = new Cdouble();
/* 13512 */         int n1 = cx.length / 2;
/* 13513 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13514 */           ct.r = cx[ir];
/* 13515 */           ct.i = cx[ii];
/* 13516 */           ry[i1] = Cdouble.arg(ct);
/*       */         } 
/*       */       }
/*       */     };
/* 13520 */   private static ComplexToReal _cnorm = new ComplexToReal() {
/*       */       void apply(float[] cx, float[] ry) {
/* 13522 */         int n1 = cx.length / 2;
/* 13523 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13524 */           float cr = cx[ir];
/* 13525 */           float ci = cx[ii];
/* 13526 */           ry[i1] = cr * cr + ci * ci;
/*       */         } 
/*       */       }
/*       */       void apply(double[] cx, double[] ry) {
/* 13530 */         int n1 = cx.length / 2;
/* 13531 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13532 */           double cr = cx[ir];
/* 13533 */           double ci = cx[ii];
/* 13534 */           ry[i1] = cr * cr + ci * ci;
/*       */         } 
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] cmplx(float[] rx, float[] ry) {
/* 13543 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static float[][] cmplx(float[][] rx, float[][] ry) {
/* 13546 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] cmplx(float[][][] rx, float[][][] ry) {
/* 13549 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static void cmplx(float[] rx, float[] ry, float[] cz) {
/* 13552 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static void cmplx(float[][] rx, float[][] ry, float[][] cz) {
/* 13555 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static void cmplx(float[][][] rx, float[][][] ry, float[][][] cz) {
/* 13558 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static float[] polar(float[] rx, float[] ry) {
/* 13561 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static float[][] polar(float[][] rx, float[][] ry) {
/* 13564 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static float[][][] polar(float[][][] rx, float[][][] ry) {
/* 13567 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static void polar(float[] rx, float[] ry, float[] cz) {
/* 13570 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   public static void polar(float[][] rx, float[][] ry, float[][] cz) {
/* 13573 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   public static void polar(float[][][] rx, float[][][] ry, float[][][] cz) {
/* 13576 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   public static double[] cmplx(double[] rx, double[] ry) {
/* 13579 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static double[][] cmplx(double[][] rx, double[][] ry) {
/* 13582 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] cmplx(double[][][] rx, double[][][] ry) {
/* 13585 */     return _cmplx.apply(rx, ry);
/*       */   }
/*       */   public static void cmplx(double[] rx, double[] ry, double[] cz) {
/* 13588 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static void cmplx(double[][] rx, double[][] ry, double[][] cz) {
/* 13591 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static void cmplx(double[][][] rx, double[][][] ry, double[][][] cz) {
/* 13594 */     _cmplx.apply(rx, ry, cz);
/*       */   }
/*       */   public static double[] polar(double[] rx, double[] ry) {
/* 13597 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static double[][] polar(double[][] rx, double[][] ry) {
/* 13600 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static double[][][] polar(double[][][] rx, double[][][] ry) {
/* 13603 */     return _polar.apply(rx, ry);
/*       */   }
/*       */   public static void polar(double[] rx, double[] ry, double[] cz) {
/* 13606 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   public static void polar(double[][] rx, double[][] ry, double[][] cz) {
/* 13609 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   public static void polar(double[][][] rx, double[][][] ry, double[][][] cz) {
/* 13612 */     _polar.apply(rx, ry, cz);
/*       */   }
/*       */   private static abstract class RealToComplex { private RealToComplex() {}
/*       */     float[] apply(float[] rx, float[] ry) {
/* 13616 */       int n1 = rx.length;
/* 13617 */       float[] cz = new float[2 * n1];
/* 13618 */       apply(rx, ry, cz);
/* 13619 */       return cz;
/*       */     }
/*       */     float[][] apply(float[][] rx, float[][] ry) {
/* 13622 */       int n2 = rx.length;
/* 13623 */       float[][] cz = new float[n2][];
/* 13624 */       for (int i2 = 0; i2 < n2; i2++)
/* 13625 */         cz[i2] = apply(rx[i2], ry[i2]); 
/* 13626 */       return cz;
/*       */     }
/*       */     float[][][] apply(float[][][] rx, float[][][] ry) {
/* 13629 */       int n3 = rx.length;
/* 13630 */       float[][][] cz = new float[n3][][];
/* 13631 */       for (int i3 = 0; i3 < n3; i3++)
/* 13632 */         cz[i3] = apply(rx[i3], ry[i3]); 
/* 13633 */       return cz;
/*       */     }
/*       */     
/*       */     void apply(float[][] rx, float[][] ry, float[][] cz) {
/* 13637 */       int n2 = rx.length;
/* 13638 */       for (int i2 = 0; i2 < n2; i2++)
/* 13639 */         apply(rx[i2], ry[i2], cz[i2]); 
/*       */     }
/*       */     void apply(float[][][] rx, float[][][] ry, float[][][] cz) {
/* 13642 */       int n3 = cz.length;
/* 13643 */       for (int i3 = 0; i3 < n3; i3++)
/* 13644 */         apply(rx[i3], ry[i3], cz[i3]); 
/*       */     }
/*       */     double[] apply(double[] rx, double[] ry) {
/* 13647 */       int n1 = rx.length;
/* 13648 */       double[] cz = new double[2 * n1];
/* 13649 */       apply(rx, ry, cz);
/* 13650 */       return cz;
/*       */     }
/*       */     double[][] apply(double[][] rx, double[][] ry) {
/* 13653 */       int n2 = rx.length;
/* 13654 */       double[][] cz = new double[n2][];
/* 13655 */       for (int i2 = 0; i2 < n2; i2++)
/* 13656 */         cz[i2] = apply(rx[i2], ry[i2]); 
/* 13657 */       return cz;
/*       */     }
/*       */     double[][][] apply(double[][][] rx, double[][][] ry) {
/* 13660 */       int n3 = rx.length;
/* 13661 */       double[][][] cz = new double[n3][][];
/* 13662 */       for (int i3 = 0; i3 < n3; i3++)
/* 13663 */         cz[i3] = apply(rx[i3], ry[i3]); 
/* 13664 */       return cz;
/*       */     }
/*       */     
/*       */     void apply(double[][] rx, double[][] ry, double[][] cz) {
/* 13668 */       int n2 = rx.length;
/* 13669 */       for (int i2 = 0; i2 < n2; i2++)
/* 13670 */         apply(rx[i2], ry[i2], cz[i2]); 
/*       */     }
/*       */     void apply(double[][][] rx, double[][][] ry, double[][][] cz) {
/* 13673 */       int n3 = cz.length;
/* 13674 */       for (int i3 = 0; i3 < n3; i3++)
/* 13675 */         apply(rx[i3], ry[i3], cz[i3]); 
/*       */     } abstract void apply(float[] param1ArrayOffloat1, float[] param1ArrayOffloat2, float[] param1ArrayOffloat3);
/*       */     abstract void apply(double[] param1ArrayOfdouble1, double[] param1ArrayOfdouble2, double[] param1ArrayOfdouble3); }
/* 13678 */   private static RealToComplex _cmplx = new RealToComplex() {
/*       */       void apply(float[] rx, float[] ry, float[] cz) {
/* 13680 */         int n1 = rx.length;
/* 13681 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13682 */           cz[ir] = rx[i1];
/* 13683 */           cz[ii] = ry[i1];
/*       */         } 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] cz) {
/* 13687 */         int n1 = rx.length;
/* 13688 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13689 */           cz[ir] = rx[i1];
/* 13690 */           cz[ii] = ry[i1];
/*       */         } 
/*       */       }
/*       */     };
/* 13694 */   private static RealToComplex _polar = new RealToComplex() {
/*       */       void apply(float[] rx, float[] ry, float[] cz) {
/* 13696 */         int n1 = rx.length;
/* 13697 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13698 */           float r = rx[i1];
/* 13699 */           float a = ry[i1];
/* 13700 */           cz[ir] = r * (float)Math.cos(a);
/* 13701 */           cz[ii] = r * (float)Math.sin(a);
/*       */         } 
/*       */       }
/*       */       void apply(double[] rx, double[] ry, double[] cz) {
/* 13705 */         int n1 = rx.length;
/* 13706 */         for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13707 */           double r = rx[i1];
/* 13708 */           double a = ry[i1];
/* 13709 */           cz[ir] = r * Math.cos(a);
/* 13710 */           cz[ii] = r * Math.sin(a);
/*       */         } 
/*       */       }
/*       */     };
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Cfloat csum(float[] cx) {
/* 13719 */     int n1 = cx.length / 2;
/* 13720 */     float sr = 0.0F;
/* 13721 */     float si = 0.0F;
/* 13722 */     for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13723 */       sr += cx[ir];
/* 13724 */       si += cx[ii];
/*       */     } 
/* 13726 */     return new Cfloat(sr, si);
/*       */   }
/*       */   public static Cfloat csum(float[][] cx) {
/* 13729 */     int n2 = cx.length;
/* 13730 */     Cfloat s = new Cfloat();
/* 13731 */     for (int i2 = 0; i2 < n2; i2++)
/* 13732 */       s.plusEquals(csum(cx[i2])); 
/* 13733 */     return s;
/*       */   }
/*       */   public static Cfloat csum(float[][][] cx) {
/* 13736 */     int n3 = cx.length;
/* 13737 */     Cfloat s = new Cfloat();
/* 13738 */     for (int i3 = 0; i3 < n3; i3++)
/* 13739 */       s.plusEquals(csum(cx[i3])); 
/* 13740 */     return s;
/*       */   }
/*       */   public static Cdouble csum(double[] cx) {
/* 13743 */     int n1 = cx.length / 2;
/* 13744 */     double sr = 0.0D;
/* 13745 */     double si = 0.0D;
/* 13746 */     for (int i1 = 0, ir = 0, ii = 1; i1 < n1; i1++, ir += 2, ii += 2) {
/* 13747 */       sr += cx[ir];
/* 13748 */       si += cx[ii];
/*       */     } 
/* 13750 */     return new Cdouble(sr, si);
/*       */   }
/*       */   public static Cdouble csum(double[][] cx) {
/* 13753 */     int n2 = cx.length;
/* 13754 */     Cdouble s = new Cdouble();
/* 13755 */     for (int i2 = 0; i2 < n2; i2++)
/* 13756 */       s.plusEquals(csum(cx[i2])); 
/* 13757 */     return s;
/*       */   }
/*       */   public static Cdouble csum(double[][][] cx) {
/* 13760 */     int n3 = cx.length;
/* 13761 */     Cdouble s = new Cdouble();
/* 13762 */     for (int i3 = 0; i3 < n3; i3++)
/* 13763 */       s.plusEquals(csum(cx[i3])); 
/* 13764 */     return s;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static float[] tofloat(byte[] rx) {
/* 13771 */     int n1 = rx.length;
/* 13772 */     float[] ry = new float[n1];
/* 13773 */     for (int i1 = 0; i1 < n1; i1++)
/* 13774 */       ry[i1] = rx[i1]; 
/* 13775 */     return ry;
/*       */   }
/*       */   public static float[][] tofloat(byte[][] rx) {
/* 13778 */     int n1 = (rx[0]).length;
/* 13779 */     int n2 = rx.length;
/* 13780 */     float[][] ry = new float[n2][n1];
/* 13781 */     for (int i2 = 0; i2 < n2; i2++) {
/* 13782 */       for (int i1 = 0; i1 < n1; i1++)
/* 13783 */         ry[i2][i1] = rx[i2][i1]; 
/* 13784 */     }  return ry;
/*       */   }
/*       */   public static float[][][] tofloat(byte[][][] rx) {
/* 13787 */     int n1 = (rx[0][0]).length;
/* 13788 */     int n2 = (rx[0]).length;
/* 13789 */     int n3 = rx.length;
/* 13790 */     float[][][] ry = new float[n3][n2][n1];
/* 13791 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13792 */       for (int i2 = 0; i2 < n2; i2++)
/* 13793 */       { for (int i1 = 0; i1 < n1; i1++)
/* 13794 */           ry[i3][i2][i1] = rx[i3][i2][i1];  } 
/* 13795 */     }  return ry;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static void dump(byte[] rx) {
/* 13802 */     ByteIterator li = new ByteIterator(rx);
/* 13803 */     String[] s = format(li);
/* 13804 */     dump(s);
/*       */   }
/*       */   public static void dump(byte[][] rx) {
/* 13807 */     ByteIterator li = new ByteIterator(rx);
/* 13808 */     String[] s = format(li);
/* 13809 */     int n2 = rx.length;
/* 13810 */     int[] n = new int[n2];
/* 13811 */     for (int i2 = 0; i2 < n2; i2++)
/* 13812 */       n[i2] = (rx[i2]).length; 
/* 13813 */     dump(n, s);
/*       */   }
/*       */   public static void dump(byte[][][] rx) {
/* 13816 */     ByteIterator li = new ByteIterator(rx);
/* 13817 */     String[] s = format(li);
/* 13818 */     int n3 = rx.length;
/* 13819 */     int[][] n = new int[n3][];
/* 13820 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13821 */       int n2 = (rx[i3]).length;
/* 13822 */       n[i3] = new int[n2];
/* 13823 */       for (int i2 = 0; i2 < n2; i2++)
/* 13824 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13826 */     dump(n, s);
/*       */   }
/*       */   public static void dump(short[] rx) {
/* 13829 */     ShortIterator li = new ShortIterator(rx);
/* 13830 */     String[] s = format(li);
/* 13831 */     dump(s);
/*       */   }
/*       */   public static void dump(short[][] rx) {
/* 13834 */     ShortIterator li = new ShortIterator(rx);
/* 13835 */     String[] s = format(li);
/* 13836 */     int n2 = rx.length;
/* 13837 */     int[] n = new int[n2];
/* 13838 */     for (int i2 = 0; i2 < n2; i2++)
/* 13839 */       n[i2] = (rx[i2]).length; 
/* 13840 */     dump(n, s);
/*       */   }
/*       */   public static void dump(short[][][] rx) {
/* 13843 */     ShortIterator li = new ShortIterator(rx);
/* 13844 */     String[] s = format(li);
/* 13845 */     int n3 = rx.length;
/* 13846 */     int[][] n = new int[n3][];
/* 13847 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13848 */       int n2 = (rx[i3]).length;
/* 13849 */       n[i3] = new int[n2];
/* 13850 */       for (int i2 = 0; i2 < n2; i2++)
/* 13851 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13853 */     dump(n, s);
/*       */   }
/*       */   public static void dump(int[] rx) {
/* 13856 */     IntIterator li = new IntIterator(rx);
/* 13857 */     String[] s = format(li);
/* 13858 */     dump(s);
/*       */   }
/*       */   public static void dump(int[][] rx) {
/* 13861 */     IntIterator li = new IntIterator(rx);
/* 13862 */     String[] s = format(li);
/* 13863 */     int n2 = rx.length;
/* 13864 */     int[] n = new int[n2];
/* 13865 */     for (int i2 = 0; i2 < n2; i2++)
/* 13866 */       n[i2] = (rx[i2]).length; 
/* 13867 */     dump(n, s);
/*       */   }
/*       */   public static void dump(int[][][] rx) {
/* 13870 */     IntIterator li = new IntIterator(rx);
/* 13871 */     String[] s = format(li);
/* 13872 */     int n3 = rx.length;
/* 13873 */     int[][] n = new int[n3][];
/* 13874 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13875 */       int n2 = (rx[i3]).length;
/* 13876 */       n[i3] = new int[n2];
/* 13877 */       for (int i2 = 0; i2 < n2; i2++)
/* 13878 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13880 */     dump(n, s);
/*       */   }
/*       */   public static void dump(long[] rx) {
/* 13883 */     LongIterator li = new LongIterator(rx);
/* 13884 */     String[] s = format(li);
/* 13885 */     dump(s);
/*       */   }
/*       */   public static void dump(long[][] rx) {
/* 13888 */     LongIterator li = new LongIterator(rx);
/* 13889 */     String[] s = format(li);
/* 13890 */     int n2 = rx.length;
/* 13891 */     int[] n = new int[n2];
/* 13892 */     for (int i2 = 0; i2 < n2; i2++)
/* 13893 */       n[i2] = (rx[i2]).length; 
/* 13894 */     dump(n, s);
/*       */   }
/*       */   public static void dump(long[][][] rx) {
/* 13897 */     LongIterator li = new LongIterator(rx);
/* 13898 */     String[] s = format(li);
/* 13899 */     int n3 = rx.length;
/* 13900 */     int[][] n = new int[n3][];
/* 13901 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13902 */       int n2 = (rx[i3]).length;
/* 13903 */       n[i3] = new int[n2];
/* 13904 */       for (int i2 = 0; i2 < n2; i2++)
/* 13905 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13907 */     dump(n, s);
/*       */   }
/*       */   public static void dump(float[] rx) {
/* 13910 */     FloatIterator di = new FloatIterator(rx);
/* 13911 */     String[] s = format(di);
/* 13912 */     dump(s);
/*       */   }
/*       */   public static void dump(float[][] rx) {
/* 13915 */     FloatIterator di = new FloatIterator(rx);
/* 13916 */     String[] s = format(di);
/* 13917 */     int n2 = rx.length;
/* 13918 */     int[] n = new int[n2];
/* 13919 */     for (int i2 = 0; i2 < n2; i2++)
/* 13920 */       n[i2] = (rx[i2]).length; 
/* 13921 */     dump(n, s);
/*       */   }
/*       */   public static void dump(float[][][] rx) {
/* 13924 */     FloatIterator di = new FloatIterator(rx);
/* 13925 */     String[] s = format(di);
/* 13926 */     int n3 = rx.length;
/* 13927 */     int[][] n = new int[n3][];
/* 13928 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13929 */       int n2 = (rx[i3]).length;
/* 13930 */       n[i3] = new int[n2];
/* 13931 */       for (int i2 = 0; i2 < n2; i2++)
/* 13932 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13934 */     dump(n, s);
/*       */   }
/*       */   public static void cdump(float[] cx) {
/* 13937 */     FloatIterator di = new FloatIterator(cx);
/* 13938 */     String[] s = format(di);
/* 13939 */     cdump(s);
/*       */   }
/*       */   public static void cdump(float[][] cx) {
/* 13942 */     FloatIterator di = new FloatIterator(cx);
/* 13943 */     String[] s = format(di);
/* 13944 */     int n2 = cx.length;
/* 13945 */     int[] n = new int[n2];
/* 13946 */     for (int i2 = 0; i2 < n2; i2++)
/* 13947 */       n[i2] = (cx[i2]).length / 2; 
/* 13948 */     cdump(n, s);
/*       */   }
/*       */   public static void cdump(float[][][] cx) {
/* 13951 */     FloatIterator di = new FloatIterator(cx);
/* 13952 */     String[] s = format(di);
/* 13953 */     int n3 = cx.length;
/* 13954 */     int[][] n = new int[n3][];
/* 13955 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13956 */       int n2 = (cx[i3]).length;
/* 13957 */       n[i3] = new int[n2];
/* 13958 */       for (int i2 = 0; i2 < n2; i2++)
/* 13959 */         n[i3][i2] = (cx[i3][i2]).length / 2; 
/*       */     } 
/* 13961 */     cdump(n, s);
/*       */   }
/*       */   public static void dump(double[] rx) {
/* 13964 */     DoubleIterator di = new DoubleIterator(rx);
/* 13965 */     String[] s = format(di);
/* 13966 */     dump(s);
/*       */   }
/*       */   public static void dump(double[][] rx) {
/* 13969 */     DoubleIterator di = new DoubleIterator(rx);
/* 13970 */     String[] s = format(di);
/* 13971 */     int n2 = rx.length;
/* 13972 */     int[] n = new int[n2];
/* 13973 */     for (int i2 = 0; i2 < n2; i2++)
/* 13974 */       n[i2] = (rx[i2]).length; 
/* 13975 */     dump(n, s);
/*       */   }
/*       */   public static void dump(double[][][] rx) {
/* 13978 */     DoubleIterator di = new DoubleIterator(rx);
/* 13979 */     String[] s = format(di);
/* 13980 */     int n3 = rx.length;
/* 13981 */     int[][] n = new int[n3][];
/* 13982 */     for (int i3 = 0; i3 < n3; i3++) {
/* 13983 */       int n2 = (rx[i3]).length;
/* 13984 */       n[i3] = new int[n2];
/* 13985 */       for (int i2 = 0; i2 < n2; i2++)
/* 13986 */         n[i3][i2] = (rx[i3][i2]).length; 
/*       */     } 
/* 13988 */     dump(n, s);
/*       */   }
/*       */   public static void cdump(double[] cx) {
/* 13991 */     DoubleIterator di = new DoubleIterator(cx);
/* 13992 */     String[] s = format(di);
/* 13993 */     cdump(s);
/*       */   }
/*       */   public static void cdump(double[][] cx) {
/* 13996 */     DoubleIterator di = new DoubleIterator(cx);
/* 13997 */     String[] s = format(di);
/* 13998 */     int n2 = cx.length;
/* 13999 */     int[] n = new int[n2];
/* 14000 */     for (int i2 = 0; i2 < n2; i2++)
/* 14001 */       n[i2] = (cx[i2]).length / 2; 
/* 14002 */     cdump(n, s);
/*       */   }
/*       */   public static void cdump(double[][][] cx) {
/* 14005 */     DoubleIterator di = new DoubleIterator(cx);
/* 14006 */     String[] s = format(di);
/* 14007 */     int n3 = cx.length;
/* 14008 */     int[][] n = new int[n3][];
/* 14009 */     for (int i3 = 0; i3 < n3; i3++) {
/* 14010 */       int n2 = (cx[i3]).length;
/* 14011 */       n[i3] = new int[n2];
/* 14012 */       for (int i2 = 0; i2 < n2; i2++)
/* 14013 */         n[i3][i2] = (cx[i3][i2]).length / 2; 
/*       */     } 
/* 14015 */     cdump(n, s);
/*       */   }
/*       */   private static int maxlen(String[] s) {
/* 14018 */     int max = 0;
/* 14019 */     int n = s.length;
/* 14020 */     for (int i = 0; i < n; i++) {
/* 14021 */       int len = s[i].length();
/* 14022 */       if (max < len)
/* 14023 */         max = len; 
/*       */     } 
/* 14025 */     return max;
/*       */   }
/*       */   private static void dump(String[] s) {
/* 14028 */     int max = maxlen(s);
/* 14029 */     int n1 = s.length;
/* 14030 */     String format = "%" + max + "s";
/* 14031 */     System.out.print("{");
/* 14032 */     int ncol = 78 / (max + 2);
/* 14033 */     int nrow = 1 + (n1 - 1) / ncol;
/* 14034 */     if (nrow > 1 && ncol >= 5) {
/* 14035 */       ncol = ncol / 5 * 5;
/* 14036 */       nrow = 1 + (n1 - 1) / ncol;
/*       */     } 
/* 14038 */     for (int irow = 0, i1 = 0; irow < nrow; irow++) {
/* 14039 */       for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++) {
/* 14040 */         System.out.printf(format, new Object[] { s[i1] });
/* 14041 */         if (i1 < n1 - 1)
/* 14042 */           System.out.print(", "); 
/*       */       } 
/* 14044 */       if (i1 < n1) {
/* 14045 */         System.out.println();
/* 14046 */         System.out.print(" ");
/*       */       } else {
/* 14048 */         System.out.println("}");
/*       */       } 
/*       */     } 
/*       */   }
/*       */   private static void dump(int[] n, String[] s) {
/* 14053 */     int max = maxlen(s);
/* 14054 */     int n2 = n.length;
/* 14055 */     String format = "%" + max + "s";
/* 14056 */     System.out.print("{{");
/* 14057 */     int ncol = 77 / (max + 2);
/* 14058 */     if (ncol >= 5)
/* 14059 */       ncol = ncol / 5 * 5; 
/* 14060 */     for (int i2 = 0, i = 0; i2 < n2; i2++) {
/* 14061 */       int n1 = n[i2];
/* 14062 */       int nrow = 1 + (n1 - 1) / ncol;
/* 14063 */       if (i2 > 0)
/* 14064 */         System.out.print(" {"); 
/* 14065 */       for (int irow = 0, i1 = 0; irow < nrow; irow++) {
/* 14066 */         for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++, i++) {
/* 14067 */           System.out.printf(format, new Object[] { s[i] });
/* 14068 */           if (i1 < n1 - 1)
/* 14069 */             System.out.print(", "); 
/*       */         } 
/* 14071 */         if (i1 < n1) {
/* 14072 */           System.out.println();
/* 14073 */           System.out.print("  ");
/*       */         }
/* 14075 */         else if (i2 < n2 - 1) {
/* 14076 */           System.out.println("},");
/*       */         } else {
/* 14078 */           System.out.println("}}");
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */   
/*       */   private static void dump(int[][] n, String[] s) {
/* 14085 */     int max = maxlen(s);
/* 14086 */     int n3 = n.length;
/* 14087 */     String format = "%" + max + "s";
/* 14088 */     System.out.print("{{{");
/* 14089 */     int ncol = 76 / (max + 2);
/* 14090 */     if (ncol >= 5)
/* 14091 */       ncol = ncol / 5 * 5; 
/* 14092 */     for (int i3 = 0, i = 0; i3 < n3; i3++) {
/* 14093 */       if (i3 > 0)
/* 14094 */         System.out.print(" {{"); 
/* 14095 */       int n2 = (n[i3]).length;
/* 14096 */       for (int i2 = 0; i2 < n2; i2++) {
/* 14097 */         int n1 = n[i3][i2];
/* 14098 */         int nrow = 1 + (n1 - 1) / ncol;
/* 14099 */         if (i2 > 0)
/* 14100 */           System.out.print("  {"); 
/* 14101 */         for (int irow = 0, i1 = 0; irow < nrow; irow++) {
/* 14102 */           for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++, i++) {
/* 14103 */             System.out.printf(format, new Object[] { s[i] });
/* 14104 */             if (i1 < n1 - 1)
/* 14105 */               System.out.print(", "); 
/*       */           } 
/* 14107 */           if (i1 < n1) {
/* 14108 */             System.out.println();
/* 14109 */             System.out.print("   ");
/*       */           }
/* 14111 */           else if (i2 < n2 - 1) {
/* 14112 */             System.out.println("},");
/* 14113 */           } else if (i3 < n3 - 1) {
/* 14114 */             System.out.println("}},");
/*       */           } else {
/* 14116 */             System.out.println("}}}");
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */   
/*       */   private static void format(String sr, String si, StringBuilder sb) {
/* 14124 */     sb.delete(0, sb.length());
/* 14125 */     sb.append('(');
/* 14126 */     if (sr.charAt(0) == ' ') {
/* 14127 */       sb.append(sr.substring(1, sr.length()));
/*       */     } else {
/* 14129 */       sb.append(sr);
/*       */     } 
/* 14131 */     if (si.charAt(0) == ' ') {
/* 14132 */       sb.append('+');
/* 14133 */       sb.append(si.substring(1, si.length()));
/*       */     } else {
/* 14135 */       sb.append(si);
/*       */     } 
/* 14137 */     sb.append('i');
/* 14138 */     sb.append(')');
/*       */   }
/*       */   private static void cdump(String[] s) {
/* 14141 */     int max = 2 * maxlen(s) + 3;
/* 14142 */     StringBuilder sb = new StringBuilder(max);
/* 14143 */     int n1 = s.length / 2;
/* 14144 */     String format = "%" + max + "s";
/* 14145 */     System.out.print("{");
/* 14146 */     int ncol = 78 / (max + 2);
/* 14147 */     int nrow = 1 + (n1 - 1) / ncol;
/* 14148 */     if (nrow > 1 && ncol >= 5) {
/* 14149 */       ncol = ncol / 5 * 5;
/* 14150 */       nrow = 1 + (n1 - 1) / ncol;
/*       */     } 
/* 14152 */     for (int irow = 0, i1 = 0, ir = 0, ii = 1; irow < nrow; irow++) {
/* 14153 */       for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++, ir += 2, ii += 2) {
/* 14154 */         format(s[ir], s[ii], sb);
/* 14155 */         System.out.printf(format, new Object[] { sb });
/* 14156 */         if (i1 < n1 - 1)
/* 14157 */           System.out.print(", "); 
/*       */       } 
/* 14159 */       if (i1 < n1) {
/* 14160 */         System.out.println();
/* 14161 */         System.out.print(" ");
/*       */       } else {
/* 14163 */         System.out.println("}");
/*       */       } 
/*       */     } 
/*       */   }
/*       */   private static void cdump(int[] n, String[] s) {
/* 14168 */     int max = 2 * maxlen(s) + 3;
/* 14169 */     StringBuilder sb = new StringBuilder(max);
/* 14170 */     int n2 = n.length;
/* 14171 */     String format = "%" + max + "s";
/* 14172 */     System.out.print("{{");
/* 14173 */     int ncol = 77 / (max + 2);
/* 14174 */     if (ncol >= 5)
/* 14175 */       ncol = ncol / 5 * 5; 
/* 14176 */     for (int i2 = 0, ir = 0, ii = 1; i2 < n2; i2++) {
/* 14177 */       int n1 = n[i2];
/* 14178 */       int nrow = 1 + (n1 - 1) / ncol;
/* 14179 */       if (i2 > 0)
/* 14180 */         System.out.print(" {"); 
/* 14181 */       for (int irow = 0, i1 = 0; irow < nrow; irow++) {
/* 14182 */         for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++, ir += 2, ii += 2) {
/* 14183 */           format(s[ir], s[ii], sb);
/* 14184 */           System.out.printf(format, new Object[] { sb });
/* 14185 */           if (i1 < n1 - 1)
/* 14186 */             System.out.print(", "); 
/*       */         } 
/* 14188 */         if (i1 < n1) {
/* 14189 */           System.out.println();
/* 14190 */           System.out.print("  ");
/*       */         }
/* 14192 */         else if (i2 < n2 - 1) {
/* 14193 */           System.out.println("},");
/*       */         } else {
/* 14195 */           System.out.println("}}");
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */   
/*       */   private static void cdump(int[][] n, String[] s) {
/* 14202 */     int max = 2 * maxlen(s) + 3;
/* 14203 */     StringBuilder sb = new StringBuilder(max);
/* 14204 */     int n3 = n.length;
/* 14205 */     String format = "%" + max + "s";
/* 14206 */     System.out.print("{{{");
/* 14207 */     int ncol = 76 / (max + 2);
/* 14208 */     if (ncol >= 5)
/* 14209 */       ncol = ncol / 5 * 5; 
/* 14210 */     for (int i3 = 0, ir = 0, ii = 1; i3 < n3; i3++) {
/* 14211 */       if (i3 > 0)
/* 14212 */         System.out.print(" {{"); 
/* 14213 */       int n2 = (n[i3]).length;
/* 14214 */       for (int i2 = 0; i2 < n2; i2++) {
/* 14215 */         int n1 = n[i3][i2];
/* 14216 */         int nrow = 1 + (n1 - 1) / ncol;
/* 14217 */         if (i2 > 0)
/* 14218 */           System.out.print("  {"); 
/* 14219 */         for (int irow = 0, i1 = 0; irow < nrow; irow++) {
/* 14220 */           for (int icol = 0; icol < ncol && i1 < n1; icol++, i1++, ir += 2, ii += 2) {
/* 14221 */             format(s[ir], s[ii], sb);
/* 14222 */             System.out.printf(format, new Object[] { sb });
/* 14223 */             if (i1 < n1 - 1)
/* 14224 */               System.out.print(", "); 
/*       */           } 
/* 14226 */           if (i1 < n1) {
/* 14227 */             System.out.println();
/* 14228 */             System.out.print("   ");
/*       */           }
/* 14230 */           else if (i2 < n2 - 1) {
/* 14231 */             System.out.println("},");
/* 14232 */           } else if (i3 < n3 - 1) {
/* 14233 */             System.out.println("}},");
/*       */           } else {
/* 14235 */             System.out.println("}}}");
/*       */           } 
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */   private static class ByteIterator { private byte[] _a1; private byte[][] _a2; private byte[][][] _a3; private int _n; private int _i; private int _i1; private int _i2; private int _i3;
/*       */     
/*       */     ByteIterator(byte[] a) {
/* 14244 */       this._n = a.length;
/* 14245 */       this._i = 0;
/* 14246 */       this._i1 = 0;
/* 14247 */       this._a1 = a;
/*       */     }
/*       */     ByteIterator(byte[][] a) {
/* 14250 */       this._n = 0;
/* 14251 */       int n2 = a.length;
/* 14252 */       for (int i2 = 0; i2 < n2; i2++)
/* 14253 */         this._n += (a[i2]).length; 
/* 14254 */       this._i = 0;
/* 14255 */       this._i1 = 0;
/* 14256 */       this._i2 = 0;
/* 14257 */       this._a2 = a;
/*       */     }
/*       */     ByteIterator(byte[][][] a) {
/* 14260 */       this._n = 0;
/* 14261 */       int n3 = a.length;
/* 14262 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14263 */         int n2 = (a[i3]).length;
/* 14264 */         for (int i2 = 0; i2 < n2; i2++)
/* 14265 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14267 */       this._i = 0;
/* 14268 */       this._i1 = 0;
/* 14269 */       this._i2 = 0;
/* 14270 */       this._i3 = 0;
/* 14271 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14274 */       return this._n;
/*       */     }
/*       */     byte get() {
/* 14277 */       assert this._i < this._n;
/* 14278 */       byte a = 0;
/* 14279 */       if (this._a1 != null) {
/* 14280 */         a = this._a1[this._i1++];
/* 14281 */       } else if (this._a2 != null) {
/* 14282 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14283 */           this._i1 = 0;
/* 14284 */           this._i2++;
/*       */         } 
/* 14286 */         a = this._a2[this._i2][this._i1++];
/* 14287 */       } else if (this._a3 != null) {
/* 14288 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14289 */           this._i1 = 0;
/* 14290 */           this._i2++;
/* 14291 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14292 */             this._i1 = 0;
/* 14293 */             this._i2 = 0;
/* 14294 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14297 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14299 */       this._i++;
/* 14300 */       return a;
/*       */     }
/*       */     void reset() {
/* 14303 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */   private static class ShortIterator { private short[] _a1; private short[][] _a2; private short[][][] _a3; private int _n;
/*       */     private int _i;
/*       */     private int _i1;
/*       */     private int _i2;
/*       */     private int _i3;
/*       */     
/*       */     ShortIterator(short[] a) {
/* 14312 */       this._n = a.length;
/* 14313 */       this._i = 0;
/* 14314 */       this._i1 = 0;
/* 14315 */       this._a1 = a;
/*       */     }
/*       */     ShortIterator(short[][] a) {
/* 14318 */       this._n = 0;
/* 14319 */       int n2 = a.length;
/* 14320 */       for (int i2 = 0; i2 < n2; i2++)
/* 14321 */         this._n += (a[i2]).length; 
/* 14322 */       this._i = 0;
/* 14323 */       this._i1 = 0;
/* 14324 */       this._i2 = 0;
/* 14325 */       this._a2 = a;
/*       */     }
/*       */     ShortIterator(short[][][] a) {
/* 14328 */       this._n = 0;
/* 14329 */       int n3 = a.length;
/* 14330 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14331 */         int n2 = (a[i3]).length;
/* 14332 */         for (int i2 = 0; i2 < n2; i2++)
/* 14333 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14335 */       this._i = 0;
/* 14336 */       this._i1 = 0;
/* 14337 */       this._i2 = 0;
/* 14338 */       this._i3 = 0;
/* 14339 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14342 */       return this._n;
/*       */     }
/*       */     short get() {
/* 14345 */       assert this._i < this._n;
/* 14346 */       short a = 0;
/* 14347 */       if (this._a1 != null) {
/* 14348 */         a = this._a1[this._i1++];
/* 14349 */       } else if (this._a2 != null) {
/* 14350 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14351 */           this._i1 = 0;
/* 14352 */           this._i2++;
/*       */         } 
/* 14354 */         a = this._a2[this._i2][this._i1++];
/* 14355 */       } else if (this._a3 != null) {
/* 14356 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14357 */           this._i1 = 0;
/* 14358 */           this._i2++;
/* 14359 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14360 */             this._i1 = 0;
/* 14361 */             this._i2 = 0;
/* 14362 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14365 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14367 */       this._i++;
/* 14368 */       return a;
/*       */     }
/*       */     void reset() {
/* 14371 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */   private static class IntIterator { private int[] _a1; private int[][] _a2; private int[][][] _a3; private int _n;
/*       */     private int _i;
/*       */     private int _i1;
/*       */     private int _i2;
/*       */     private int _i3;
/*       */     
/*       */     IntIterator(int[] a) {
/* 14380 */       this._n = a.length;
/* 14381 */       this._i = 0;
/* 14382 */       this._i1 = 0;
/* 14383 */       this._a1 = a;
/*       */     }
/*       */     IntIterator(int[][] a) {
/* 14386 */       this._n = 0;
/* 14387 */       int n2 = a.length;
/* 14388 */       for (int i2 = 0; i2 < n2; i2++)
/* 14389 */         this._n += (a[i2]).length; 
/* 14390 */       this._i = 0;
/* 14391 */       this._i1 = 0;
/* 14392 */       this._i2 = 0;
/* 14393 */       this._a2 = a;
/*       */     }
/*       */     IntIterator(int[][][] a) {
/* 14396 */       this._n = 0;
/* 14397 */       int n3 = a.length;
/* 14398 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14399 */         int n2 = (a[i3]).length;
/* 14400 */         for (int i2 = 0; i2 < n2; i2++)
/* 14401 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14403 */       this._i = 0;
/* 14404 */       this._i1 = 0;
/* 14405 */       this._i2 = 0;
/* 14406 */       this._i3 = 0;
/* 14407 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14410 */       return this._n;
/*       */     }
/*       */     int get() {
/* 14413 */       assert this._i < this._n;
/* 14414 */       int a = 0;
/* 14415 */       if (this._a1 != null) {
/* 14416 */         a = this._a1[this._i1++];
/* 14417 */       } else if (this._a2 != null) {
/* 14418 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14419 */           this._i1 = 0;
/* 14420 */           this._i2++;
/*       */         } 
/* 14422 */         a = this._a2[this._i2][this._i1++];
/* 14423 */       } else if (this._a3 != null) {
/* 14424 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14425 */           this._i1 = 0;
/* 14426 */           this._i2++;
/* 14427 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14428 */             this._i1 = 0;
/* 14429 */             this._i2 = 0;
/* 14430 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14433 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14435 */       this._i++;
/* 14436 */       return a;
/*       */     }
/*       */     void reset() {
/* 14439 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */   private static class LongIterator { private long[] _a1; private long[][] _a2; private long[][][] _a3; private int _n;
/*       */     private int _i;
/*       */     private int _i1;
/*       */     private int _i2;
/*       */     private int _i3;
/*       */     
/*       */     LongIterator(long[] a) {
/* 14448 */       this._n = a.length;
/* 14449 */       this._i = 0;
/* 14450 */       this._i1 = 0;
/* 14451 */       this._a1 = a;
/*       */     }
/*       */     LongIterator(long[][] a) {
/* 14454 */       this._n = 0;
/* 14455 */       int n2 = a.length;
/* 14456 */       for (int i2 = 0; i2 < n2; i2++)
/* 14457 */         this._n += (a[i2]).length; 
/* 14458 */       this._i = 0;
/* 14459 */       this._i1 = 0;
/* 14460 */       this._i2 = 0;
/* 14461 */       this._a2 = a;
/*       */     }
/*       */     LongIterator(long[][][] a) {
/* 14464 */       this._n = 0;
/* 14465 */       int n3 = a.length;
/* 14466 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14467 */         int n2 = (a[i3]).length;
/* 14468 */         for (int i2 = 0; i2 < n2; i2++)
/* 14469 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14471 */       this._i = 0;
/* 14472 */       this._i1 = 0;
/* 14473 */       this._i2 = 0;
/* 14474 */       this._i3 = 0;
/* 14475 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14478 */       return this._n;
/*       */     }
/*       */     long get() {
/* 14481 */       assert this._i < this._n;
/* 14482 */       long a = 0L;
/* 14483 */       if (this._a1 != null) {
/* 14484 */         a = this._a1[this._i1++];
/* 14485 */       } else if (this._a2 != null) {
/* 14486 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14487 */           this._i1 = 0;
/* 14488 */           this._i2++;
/*       */         } 
/* 14490 */         a = this._a2[this._i2][this._i1++];
/* 14491 */       } else if (this._a3 != null) {
/* 14492 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14493 */           this._i1 = 0;
/* 14494 */           this._i2++;
/* 14495 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14496 */             this._i1 = 0;
/* 14497 */             this._i2 = 0;
/* 14498 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14501 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14503 */       this._i++;
/* 14504 */       return a;
/*       */     }
/*       */     void reset() {
/* 14507 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */   private static class FloatIterator { private float[] _a1; private float[][] _a2; private float[][][] _a3; private int _n;
/*       */     private int _i;
/*       */     private int _i1;
/*       */     private int _i2;
/*       */     private int _i3;
/*       */     
/*       */     FloatIterator(float[] a) {
/* 14516 */       this._n = a.length;
/* 14517 */       this._i = 0;
/* 14518 */       this._i1 = 0;
/* 14519 */       this._a1 = a;
/*       */     }
/*       */     FloatIterator(float[][] a) {
/* 14522 */       this._n = 0;
/* 14523 */       int n2 = a.length;
/* 14524 */       for (int i2 = 0; i2 < n2; i2++)
/* 14525 */         this._n += (a[i2]).length; 
/* 14526 */       this._i = 0;
/* 14527 */       this._i1 = 0;
/* 14528 */       this._i2 = 0;
/* 14529 */       this._a2 = a;
/*       */     }
/*       */     FloatIterator(float[][][] a) {
/* 14532 */       this._n = 0;
/* 14533 */       int n3 = a.length;
/* 14534 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14535 */         int n2 = (a[i3]).length;
/* 14536 */         for (int i2 = 0; i2 < n2; i2++)
/* 14537 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14539 */       this._i = 0;
/* 14540 */       this._i1 = 0;
/* 14541 */       this._i2 = 0;
/* 14542 */       this._i3 = 0;
/* 14543 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14546 */       return this._n;
/*       */     }
/*       */     float get() {
/* 14549 */       assert this._i < this._n;
/* 14550 */       float a = 0.0F;
/* 14551 */       if (this._a1 != null) {
/* 14552 */         a = this._a1[this._i1++];
/* 14553 */       } else if (this._a2 != null) {
/* 14554 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14555 */           this._i1 = 0;
/* 14556 */           this._i2++;
/*       */         } 
/* 14558 */         a = this._a2[this._i2][this._i1++];
/* 14559 */       } else if (this._a3 != null) {
/* 14560 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14561 */           this._i1 = 0;
/* 14562 */           this._i2++;
/* 14563 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14564 */             this._i1 = 0;
/* 14565 */             this._i2 = 0;
/* 14566 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14569 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14571 */       this._i++;
/* 14572 */       return a;
/*       */     }
/*       */     void reset() {
/* 14575 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */   private static class DoubleIterator { private double[] _a1; private double[][] _a2; private double[][][] _a3; private int _n;
/*       */     private int _i;
/*       */     private int _i1;
/*       */     private int _i2;
/*       */     private int _i3;
/*       */     
/*       */     DoubleIterator(double[] a) {
/* 14584 */       this._n = a.length;
/* 14585 */       this._i = 0;
/* 14586 */       this._i1 = 0;
/* 14587 */       this._a1 = a;
/*       */     }
/*       */     DoubleIterator(double[][] a) {
/* 14590 */       this._n = 0;
/* 14591 */       int n2 = a.length;
/* 14592 */       for (int i2 = 0; i2 < n2; i2++)
/* 14593 */         this._n += (a[i2]).length; 
/* 14594 */       this._i = 0;
/* 14595 */       this._i1 = 0;
/* 14596 */       this._i2 = 0;
/* 14597 */       this._a2 = a;
/*       */     }
/*       */     DoubleIterator(double[][][] a) {
/* 14600 */       this._n = 0;
/* 14601 */       int n3 = a.length;
/* 14602 */       for (int i3 = 0; i3 < n3; i3++) {
/* 14603 */         int n2 = (a[i3]).length;
/* 14604 */         for (int i2 = 0; i2 < n2; i2++)
/* 14605 */           this._n += (a[i3][i2]).length; 
/*       */       } 
/* 14607 */       this._i = 0;
/* 14608 */       this._i1 = 0;
/* 14609 */       this._i2 = 0;
/* 14610 */       this._i3 = 0;
/* 14611 */       this._a3 = a;
/*       */     }
/*       */     int count() {
/* 14614 */       return this._n;
/*       */     }
/*       */     double get() {
/* 14617 */       assert this._i < this._n;
/* 14618 */       double a = 0.0D;
/* 14619 */       if (this._a1 != null) {
/* 14620 */         a = this._a1[this._i1++];
/* 14621 */       } else if (this._a2 != null) {
/* 14622 */         while (this._i1 >= (this._a2[this._i2]).length) {
/* 14623 */           this._i1 = 0;
/* 14624 */           this._i2++;
/*       */         } 
/* 14626 */         a = this._a2[this._i2][this._i1++];
/* 14627 */       } else if (this._a3 != null) {
/* 14628 */         while (this._i1 >= (this._a3[this._i3][this._i2]).length) {
/* 14629 */           this._i1 = 0;
/* 14630 */           this._i2++;
/* 14631 */           while (this._i2 >= (this._a3[this._i3]).length) {
/* 14632 */             this._i1 = 0;
/* 14633 */             this._i2 = 0;
/* 14634 */             this._i3++;
/*       */           } 
/*       */         } 
/* 14637 */         a = this._a3[this._i3][this._i2][this._i1++];
/*       */       } 
/* 14639 */       this._i++;
/* 14640 */       return a;
/*       */     }
/*       */     void reset() {
/* 14643 */       this._i = this._i1 = this._i2 = this._i3 = 0;
/*       */     } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String[] format(ByteIterator li) {
/* 14651 */     int n = li.count();
/* 14652 */     String[] s = new String[n];
/* 14653 */     for (int i = 0; i < n; i++) {
/* 14654 */       s[i] = String.format("% d", new Object[] { Byte.valueOf(li.get()) });
/* 14655 */     }  return s;
/*       */   }
/*       */   private static String[] format(ShortIterator li) {
/* 14658 */     int n = li.count();
/* 14659 */     String[] s = new String[n];
/* 14660 */     for (int i = 0; i < n; i++) {
/* 14661 */       s[i] = String.format("% d", new Object[] { Short.valueOf(li.get()) });
/* 14662 */     }  return s;
/*       */   }
/*       */   private static String[] format(IntIterator li) {
/* 14665 */     int n = li.count();
/* 14666 */     String[] s = new String[n];
/* 14667 */     for (int i = 0; i < n; i++) {
/* 14668 */       s[i] = String.format("% d", new Object[] { Integer.valueOf(li.get()) });
/* 14669 */     }  return s;
/*       */   }
/*       */   private static String[] format(LongIterator li) {
/* 14672 */     int n = li.count();
/* 14673 */     String[] s = new String[n];
/* 14674 */     for (int i = 0; i < n; i++) {
/* 14675 */       s[i] = String.format("% d", new Object[] { Long.valueOf(li.get()) });
/* 14676 */     }  return s;
/*       */   } private static String[] format(DoubleIterator di) {
/*       */     String f;
/* 14679 */     int pg = 6;
/* 14680 */     String fg = "% ." + pg + "g";
/* 14681 */     int pemax = -1;
/* 14682 */     int pfmax = -1;
/* 14683 */     int n = di.count();
/* 14684 */     for (int i = 0; i < n; i++) {
/* 14685 */       String str = String.format(fg, new Object[] { Double.valueOf(di.get()) });
/* 14686 */       str = clean(str);
/* 14687 */       int ls = str.length();
/* 14688 */       if (str.contains("e")) {
/* 14689 */         int pe = (ls > 7) ? (ls - 7) : 0;
/* 14690 */         if (pemax < pe)
/* 14691 */           pemax = pe; 
/*       */       } else {
/* 14693 */         int ip = str.indexOf('.');
/* 14694 */         int pf = (ip >= 0) ? (ls - 1 - ip) : 0;
/* 14695 */         if (pfmax < pf)
/* 14696 */           pfmax = pf; 
/*       */       } 
/*       */     } 
/* 14699 */     String[] s = new String[n];
/*       */     
/* 14701 */     if (pemax >= 0) {
/* 14702 */       if (pfmax > pg - 1)
/* 14703 */         pfmax = pg - 1; 
/* 14704 */       int pe = (pemax > pfmax) ? pemax : pfmax;
/* 14705 */       f = "% ." + pe + "e";
/*       */     } else {
/* 14707 */       int pf = pfmax;
/* 14708 */       f = "% ." + pf + "f";
/*       */     } 
/* 14710 */     di.reset();
/* 14711 */     for (int j = 0; j < n; j++) {
/* 14712 */       s[j] = String.format(f, new Object[] { Double.valueOf(di.get()) });
/* 14713 */     }  return s;
/*       */   } private static String[] format(FloatIterator di) {
/*       */     String f;
/* 14716 */     int pg = 6;
/* 14717 */     String fg = "% ." + pg + "g";
/* 14718 */     int pemax = -1;
/* 14719 */     int pfmax = -1;
/* 14720 */     int n = di.count();
/* 14721 */     for (int i = 0; i < n; i++) {
/* 14722 */       String str = String.format(fg, new Object[] { Float.valueOf(di.get()) });
/* 14723 */       str = clean(str);
/* 14724 */       int ls = str.length();
/* 14725 */       if (str.contains("e")) {
/* 14726 */         int pe = (ls > 7) ? (ls - 7) : 0;
/* 14727 */         if (pemax < pe)
/* 14728 */           pemax = pe; 
/*       */       } else {
/* 14730 */         int ip = str.indexOf('.');
/* 14731 */         int pf = (ip >= 0) ? (ls - 1 - ip) : 0;
/* 14732 */         if (pfmax < pf)
/* 14733 */           pfmax = pf; 
/*       */       } 
/*       */     } 
/* 14736 */     String[] s = new String[n];
/*       */     
/* 14738 */     if (pemax >= 0) {
/* 14739 */       if (pfmax > pg - 1)
/* 14740 */         pfmax = pg - 1; 
/* 14741 */       int pe = (pemax > pfmax) ? pemax : pfmax;
/* 14742 */       f = "% ." + pe + "e";
/*       */     } else {
/* 14744 */       int pf = pfmax;
/* 14745 */       f = "% ." + pf + "f";
/*       */     } 
/* 14747 */     di.reset();
/* 14748 */     for (int j = 0; j < n; j++) {
/* 14749 */       s[j] = String.format(f, new Object[] { Float.valueOf(di.get()) });
/* 14750 */     }  return s;
/*       */   }
/*       */   private static String clean(String s) {
/* 14753 */     int len = s.length();
/* 14754 */     int iend = s.indexOf('e');
/* 14755 */     if (iend < 0)
/* 14756 */       iend = s.indexOf('E'); 
/* 14757 */     if (iend < 0)
/* 14758 */       iend = len; 
/* 14759 */     int ibeg = iend;
/* 14760 */     if (s.indexOf('.') > 0) {
/* 14761 */       while (ibeg > 0 && s.charAt(ibeg - 1) == '0')
/* 14762 */         ibeg--; 
/* 14763 */       if (ibeg > 0 && s.charAt(ibeg - 1) == '.')
/* 14764 */         ibeg--; 
/*       */     } 
/* 14766 */     if (ibeg < iend) {
/* 14767 */       String sb = s.substring(0, ibeg);
/* 14768 */       s = (iend < len) ? (sb + s.substring(iend, len)) : sb;
/*       */     } 
/* 14770 */     return s;
/*       */   }
/*       */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Array.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */