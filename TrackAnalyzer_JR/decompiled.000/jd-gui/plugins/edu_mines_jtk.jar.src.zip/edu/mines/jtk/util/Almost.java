/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Almost
/*     */   implements Serializable, Comparator<Number>
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*  24 */   private static final Logger LOG = Logger.getLogger(Almost.class.getName());
/*     */ 
/*     */ 
/*     */   
/*  28 */   private double _epsilon = 1.1920928955078125E-6D;
/*     */ 
/*     */ 
/*     */   
/*  32 */   private double _minValue = 1.401298464324817E-43D;
/*     */ 
/*     */   
/*  35 */   public static final Almost FLOAT = new Almost();
/*     */ 
/*     */   
/*  38 */   public static final Almost DOUBLE = new Almost(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Almost(double epsilon, double minValue) {
/*  56 */     this._epsilon = Math.abs(epsilon);
/*  57 */     this._minValue = Math.abs(minValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Almost(double epsilon) {
/*  70 */     this._epsilon = Math.abs(epsilon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Almost(int significantDigits) {
/*  79 */     significantDigits = Math.abs(significantDigits);
/*  80 */     this._epsilon = 1.0D;
/*  81 */     while (significantDigits > 0) {
/*  82 */       this._epsilon *= 0.1D;
/*  83 */       significantDigits--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Almost(boolean isDouble) {
/*  92 */     if (isDouble) {
/*  93 */       this._epsilon = 2.220446049250313E-15D;
/*  94 */       this._minValue = 4.94E-322D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getEpsilon() {
/* 102 */     return this._epsilon;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinValue() {
/* 108 */     return this._minValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean between(double x, double x1, double x2) {
/* 117 */     return (cmp(x, x1) * cmp(x, x2) <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int outside(double x, double x1, double x2) {
/* 128 */     int i = 0;
/* 129 */     if (between(x, x1, x2)) { i = 0; }
/* 130 */     else if (between(x1, x, x2)) { i = -1; }
/* 131 */     else if (between(x2, x, x1)) { i = 1; }
/* 132 */      return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean zero(double r) {
/* 140 */     if (r < 0.0D) r = -r; 
/* 141 */     return (r < this._minValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equal(double r1, double r2) {
/* 150 */     return (cmp(r1, r2) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean lt(double r1, double r2) {
/* 158 */     return (cmp(r1, r2) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean le(double r1, double r2) {
/* 165 */     return (cmp(r1, r2) <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean gt(double r1, double r2) {
/* 172 */     return (cmp(r1, r2) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean ge(double r1, double r2) {
/* 179 */     return (cmp(r1, r2) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int cmp(double r1, double r2) {
/* 187 */     if (r1 == r2) return 0;
/*     */ 
/*     */     
/* 190 */     double ar1 = r1;
/* 191 */     double ar2 = r2;
/* 192 */     if (ar1 < 0.0D) ar1 = -ar1; 
/* 193 */     if (ar2 < 0.0D) ar2 = -ar2; 
/* 194 */     if (ar1 < this._minValue && ar2 < this._minValue) return 0;
/*     */     
/* 196 */     if (0.0D * r1 * r2 != 0.0D) {
/* 197 */       throw new IllegalArgumentException("Comparing a NaN");
/*     */     }
/* 199 */     double er1 = this._epsilon * ar1;
/* 200 */     double er2 = this._epsilon * ar2;
/* 201 */     if (r1 - er1 > r2 + er2)
/* 202 */       return 1; 
/* 203 */     if (r1 + er1 < r2 - er2) {
/* 204 */       return -1;
/*     */     }
/* 206 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCodeOf(Number number, int significantDigits) {
/* 218 */     if (number instanceof Long || number instanceof Integer) {
/* 219 */       return number.intValue();
/*     */     }
/* 221 */     double value = number.doubleValue();
/*     */     
/* 223 */     if (zero(value)) return 0;
/*     */     
/* 225 */     boolean flipSign = (value < 0.0D);
/* 226 */     if (flipSign) value = -value; 
/* 227 */     int pow = 0;
/*     */     
/* 229 */     while (value < 0.1D) { value *= 10.0D; pow++; }
/* 230 */      while (value > 1.0D) { value *= 0.1D; pow--; }
/*     */     
/* 232 */     if (equal(value, 1.0D) || equal(value, 0.1D)) return 1;
/*     */     
/* 234 */     for (int i = 0; i < Math.abs(significantDigits); ) { value *= 10.0D; i++; }
/* 235 */      int result = (new Long((long)(value + 0.5D))).intValue();
/*     */     
/* 237 */     result = 100 * result + pow;
/* 238 */     if (flipSign) result = -result; 
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCodeOf(Number number) {
/* 249 */     double epsilon = this._epsilon;
/* 250 */     int digits = 0;
/* 251 */     while (epsilon < 0.99D) { epsilon *= 10.0D; digits++; }
/* 252 */      return hashCodeOf(number, digits);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double divide(double top, double bottom, boolean limitIsOne) {
/* 264 */     return divide(top, bottom, limitIsOne ? 1.0D : 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double reciprocal(double value) {
/* 271 */     return divide(1.0D, value, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double divide(double top, double bottom, double limit) {
/* 283 */     double sign = 1.0D;
/* 284 */     if ((top > 0.0D && bottom < 0.0D) || (top < 0.0D && bottom > 0.0D)) sign = -1.0D;
/*     */     
/* 286 */     if (top < 0.0D) top = -top; 
/* 287 */     if (bottom < 0.0D) bottom = -bottom;
/*     */     
/* 289 */     if (bottom >= 1.0D || top < bottom * 0.1D * 3.4028234663852886E38D)
/*     */     {
/* 291 */       return sign * top / bottom; } 
/* 292 */     if (equal(top, bottom)) {
/* 293 */       if (zero(top)) {
/* 294 */         return limit;
/*     */       }
/* 296 */       return sign;
/*     */     } 
/* 298 */     return sign * 0.01D * 3.4028234663852886E38D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(Number n1, Number n2) {
/* 304 */     return cmp(n1.doubleValue(), n2.doubleValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 309 */     if (this == object) return true; 
/* 310 */     if (object == null || getClass() != object.getClass()) return false; 
/* 311 */     if (hashCode() != object.hashCode()) return false; 
/* 312 */     Almost other = (Almost)object;
/* 313 */     if (this._epsilon != other._epsilon) return false; 
/* 314 */     if (this._minValue != other._minValue) return false; 
/* 315 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 320 */     return (new Long(Double.doubleToLongBits(this._epsilon) ^ Double.doubleToLongBits(this._minValue))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 326 */     return "Almost<eps=" + this._epsilon + ",min=" + this._minValue + ">";
/*     */   }
/*     */   
/*     */   public Almost() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Almost.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */