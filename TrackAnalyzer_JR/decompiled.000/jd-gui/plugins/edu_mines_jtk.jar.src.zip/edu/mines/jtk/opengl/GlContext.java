/*     */ package edu.mines.jtk.opengl;
/*     */ public class GlContext { private long _peer; private ReentrantLock _lock; private boolean _gotProcAddresses; private boolean _locked; long glBlendColor; long glBlendEquation; long glDrawRangeElements; long glColorTable; long glColorTableParameterfv; long glColorTableParameteriv; long glCopyColorTable; long glGetColorTable; long glGetColorTableParameterfv; long glGetColorTableParameteriv; long glColorSubTable; long glCopyColorSubTable; long glConvolutionFilter1D; long glConvolutionFilter2D; long glConvolutionParameterf; long glConvolutionParameterfv; long glConvolutionParameteri; long glConvolutionParameteriv; long glCopyConvolutionFilter1D; long glCopyConvolutionFilter2D; long glGetConvolutionFilter; long glGetConvolutionParameterfv; long glGetConvolutionParameteriv; long glGetSeparableFilter; long glSeparableFilter2D; long glGetHistogram; long glGetHistogramParameterfv; long glGetHistogramParameteriv; long glGetMinmax; long glGetMinmaxParameterfv; long glGetMinmaxParameteriv; long glHistogram; long glMinmax; long glResetHistogram; long glResetMinmax; long glTexImage3D; long glTexSubImage3D; long glCopyTexSubImage3D; long glActiveTexture; long glClientActiveTexture; long glMultiTexCoord1d; long glMultiTexCoord1dv; long glMultiTexCoord1f; long glMultiTexCoord1fv; long glMultiTexCoord1i; long glMultiTexCoord1iv; long glMultiTexCoord1s; long glMultiTexCoord1sv;
/*     */   long glMultiTexCoord2d;
/*     */   long glMultiTexCoord2dv;
/*     */   long glMultiTexCoord2f;
/*     */   long glMultiTexCoord2fv;
/*     */   long glMultiTexCoord2i;
/*     */   long glMultiTexCoord2iv;
/*     */   long glMultiTexCoord2s;
/*     */   long glMultiTexCoord2sv;
/*     */   long glMultiTexCoord3d;
/*     */   long glMultiTexCoord3dv;
/*     */   long glMultiTexCoord3f;
/*     */   long glMultiTexCoord3fv;
/*     */   long glMultiTexCoord3i;
/*     */   long glMultiTexCoord3iv;
/*     */   long glMultiTexCoord3s;
/*     */   long glMultiTexCoord3sv;
/*     */   long glMultiTexCoord4d;
/*     */   long glMultiTexCoord4dv;
/*     */   long glMultiTexCoord4f;
/*     */   long glMultiTexCoord4fv;
/*     */   long glMultiTexCoord4i;
/*     */   long glMultiTexCoord4iv;
/*     */   long glMultiTexCoord4s;
/*     */   long glMultiTexCoord4sv;
/*     */   long glLoadTransposeMatrixf;
/*     */   long glLoadTransposeMatrixd;
/*     */   long glMultTransposeMatrixf;
/*     */   long glMultTransposeMatrixd;
/*     */   long glSampleCoverage;
/*     */   long glCompressedTexImage3D;
/*     */   long glCompressedTexImage2D;
/*     */   long glCompressedTexImage1D;
/*     */   long glCompressedTexSubImage3D;
/*     */   long glCompressedTexSubImage2D;
/*     */   long glCompressedTexSubImage1D;
/*     */   long glGetCompressedTexImage;
/*     */   long glBlendFuncSeparate;
/*     */   long glFogCoordf;
/*     */   long glFogCoordfv;
/*     */   long glFogCoordd;
/*     */   long glFogCoorddv;
/*     */   long glFogCoordPointer;
/*     */   long glMultiDrawArrays;
/*     */   long glMultiDrawElements;
/*     */   long glPointParameterf;
/*     */   long glPointParameterfv;
/*     */   long glPointParameteri;
/*     */   long glPointParameteriv;
/*     */   long glSecondaryColor3b;
/*     */   long glSecondaryColor3bv;
/*     */   long glSecondaryColor3d;
/*     */   long glSecondaryColor3dv;
/*     */   long glSecondaryColor3f;
/*     */   long glSecondaryColor3fv;
/*     */   long glSecondaryColor3i;
/*     */   long glSecondaryColor3iv;
/*     */   long glSecondaryColor3s;
/*     */   long glSecondaryColor3sv;
/*     */   long glSecondaryColor3ub;
/*     */   long glSecondaryColor3ubv;
/*     */   long glSecondaryColor3ui;
/*     */   long glSecondaryColor3uiv;
/*     */   long glSecondaryColor3us;
/*     */   long glSecondaryColor3usv;
/*     */   long glSecondaryColorPointer;
/*     */   long glWindowPos2d;
/*     */   long glWindowPos2dv;
/*     */   long glWindowPos2f;
/*     */   long glWindowPos2fv;
/*     */   long glWindowPos2i;
/*     */   long glWindowPos2iv;
/*     */   long glWindowPos2s;
/*     */   long glWindowPos2sv;
/*     */   long glWindowPos3d;
/*     */   long glWindowPos3dv;
/*     */   long glWindowPos3f;
/*     */   long glWindowPos3fv;
/*     */   long glWindowPos3i;
/*     */   long glWindowPos3iv;
/*     */   long glWindowPos3s;
/*     */   long glWindowPos3sv;
/*     */   long glGenQueries;
/*     */   long glDeleteQueries;
/*     */   long glIsQuery;
/*     */   long glBeginQuery;
/*     */   long glEndQuery;
/*     */   long glGetQueryiv;
/*     */   long glGetQueryObjectiv;
/*     */   long glGetQueryObjectuiv;
/*     */   long glBindBuffer;
/*     */   long glDeleteBuffers;
/*     */   long glGenBuffers;
/*     */   long glIsBuffer;
/*     */   long glBufferData;
/*     */   long glBufferSubData;
/*     */   long glGetBufferSubData;
/*     */   long glMapBuffer;
/*     */   long glUnmapBuffer;
/*     */   long glGetBufferParameteriv;
/*     */   long glGetBufferPointerv;
/*     */   
/*     */   public void lock() {
/*     */     Check.state((this._peer != 0L), "this OpenGL context has not been disposed");
/*     */     this._lock.acquire();
/*     */     if (this._lock.holds() == 1L) {
/*     */       if (Gl.getContext() != null) {
/*     */         this._lock.release();
/*     */         Check.state(false, "current thread has no other OpenGL context locked");
/*     */       } 
/*     */       if (!lock(this._peer)) {
/*     */         this._lock.release();
/*     */         Check.state(false, "successfully locked OpenGL context peer");
/*     */       } 
/*     */       this._locked = true;
/*     */       Gl.setContext(this);
/*     */       getProcAddresses();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void unlock() {
/*     */     Check.state((this._peer != 0L), "this OpenGL context has not been disposed");
/*     */     if (this._lock.holds() == 1L) {
/*     */       Check.state((Gl.getContext() == this), "this OpenGL context is locked in current thread");
/*     */       if (!unlock(this._peer))
/*     */         Check.state(false, "successfully unlocked OpenGL context peer"); 
/*     */       Gl.setContext(null);
/*     */       this._locked = false;
/*     */     } 
/*     */     this._lock.release();
/*     */   }
/*     */   
/*     */   public boolean isLocked() {
/*     */     return this._locked;
/*     */   }
/*     */   
/*     */   public void swapBuffers() {
/*     */     Check.state((this._peer != 0L), "this OpenGL context has not been disposed");
/*     */     Check.state((Gl.getContext() == this), "this OpenGL context is locked in current thread");
/*     */     swapBuffers(this._peer);
/*     */   }
/*     */   
/* 144 */   public GlContext(Canvas canvas) { this._lock = new ReentrantLock();
/*     */     this._peer = makeGlAwtCanvasContext(canvas);
/*     */     Check.state((this._peer != 0L), "successfully created OpenGL context peer"); } public synchronized void dispose() { Check.state((this._peer != 0L), "this OpenGL context has not been disposed");
/*     */     Check.state(!this._locked, "this OpenGL context is not locked in any thread");
/*     */     killGlContext(this._peer);
/*     */     this._peer = 0L;
/*     */     this._gotProcAddresses = false; } public boolean isDisposed() {
/*     */     return (this._peer == 0L);
/*     */   } protected void finalize() throws Throwable {
/*     */     try {
/*     */       dispose();
/*     */     } finally {
/*     */       super.finalize();
/*     */     } 
/*     */   } private static class ReentrantLock {
/*     */     public void acquire() {
/* 160 */       Check.state(!Thread.interrupted(), "thread is not interrupted");
/* 161 */       Thread caller = Thread.currentThread();
/* 162 */       synchronized (this) {
/* 163 */         if (this._owner == caller) {
/* 164 */           this._holds++;
/*     */         } else {
/*     */           try {
/* 167 */             while (this._owner != null)
/* 168 */               wait(); 
/* 169 */             this._owner = caller;
/* 170 */             this._holds = 1L;
/*     */           }
/* 172 */           catch (InterruptedException ex) {
/* 173 */             notify();
/* 174 */             Check.state(false, "thread is not interrupted");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     public synchronized void release() {
/* 180 */       Check.state((this._owner == Thread.currentThread()), "thread owns the lock");
/* 181 */       if (--this._holds == 0L) {
/* 182 */         this._owner = null;
/* 183 */         notify();
/*     */       } 
/*     */     }
/*     */     public synchronized long holds() {
/* 187 */       return this._holds;
/*     */     }
/* 189 */     private Thread _owner = null;
/* 190 */     private long _holds = 0L;
/*     */     private ReentrantLock() {} }
/*     */   
/*     */   static {
/* 194 */     System.loadLibrary("edu_mines_jtk_opengl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getProcAddresses() {
/* 359 */     if (this._gotProcAddresses) {
/*     */       return;
/*     */     }
/*     */     
/* 363 */     this.glBlendColor = getProcAddress("glBlendColor");
/* 364 */     this.glBlendEquation = getProcAddress("glBlendEquation");
/* 365 */     this.glDrawRangeElements = getProcAddress("glDrawRangeElements");
/* 366 */     this.glColorTable = getProcAddress("glColorTable");
/* 367 */     this.glColorTableParameterfv = getProcAddress("glColorTableParameterfv");
/* 368 */     this.glColorTableParameteriv = getProcAddress("glColorTableParameteriv");
/* 369 */     this.glCopyColorTable = getProcAddress("glCopyColorTable");
/* 370 */     this.glGetColorTable = getProcAddress("glGetColorTable");
/* 371 */     this.glGetColorTableParameterfv = getProcAddress("glGetColorTableParameterfv");
/* 372 */     this.glGetColorTableParameteriv = getProcAddress("glGetColorTableParameteriv");
/* 373 */     this.glColorSubTable = getProcAddress("glColorSubTable");
/* 374 */     this.glCopyColorSubTable = getProcAddress("glCopyColorSubTable");
/* 375 */     this.glConvolutionFilter1D = getProcAddress("glConvolutionFilter1D");
/* 376 */     this.glConvolutionFilter2D = getProcAddress("glConvolutionFilter2D");
/* 377 */     this.glConvolutionParameterf = getProcAddress("glConvolutionParameterf");
/* 378 */     this.glConvolutionParameterfv = getProcAddress("glConvolutionParameterfv");
/* 379 */     this.glConvolutionParameteri = getProcAddress("glConvolutionParameteri");
/* 380 */     this.glConvolutionParameteriv = getProcAddress("glConvolutionParameteriv");
/* 381 */     this.glCopyConvolutionFilter1D = getProcAddress("glCopyConvolutionFilter1D");
/* 382 */     this.glCopyConvolutionFilter2D = getProcAddress("glCopyConvolutionFilter2D");
/* 383 */     this.glGetConvolutionFilter = getProcAddress("glGetConvolutionFilter");
/* 384 */     this.glGetConvolutionParameterfv = getProcAddress("glGetConvolutionParameterfv");
/* 385 */     this.glGetConvolutionParameteriv = getProcAddress("glGetConvolutionParameteriv");
/* 386 */     this.glGetSeparableFilter = getProcAddress("glGetSeparableFilter");
/* 387 */     this.glSeparableFilter2D = getProcAddress("glSeparableFilter2D");
/* 388 */     this.glGetHistogram = getProcAddress("glGetHistogram");
/* 389 */     this.glGetHistogramParameterfv = getProcAddress("glGetHistogramParameterfv");
/* 390 */     this.glGetHistogramParameteriv = getProcAddress("glGetHistogramParameteriv");
/* 391 */     this.glGetMinmax = getProcAddress("glGetMinmax");
/* 392 */     this.glGetMinmaxParameterfv = getProcAddress("glGetMinmaxParameterfv");
/* 393 */     this.glGetMinmaxParameteriv = getProcAddress("glGetMinmaxParameteriv");
/* 394 */     this.glHistogram = getProcAddress("glHistogram");
/* 395 */     this.glMinmax = getProcAddress("glMinmax");
/* 396 */     this.glResetHistogram = getProcAddress("glResetHistogram");
/* 397 */     this.glResetMinmax = getProcAddress("glResetMinmax");
/* 398 */     this.glTexImage3D = getProcAddress("glTexImage3D");
/* 399 */     this.glTexSubImage3D = getProcAddress("glTexSubImage3D");
/* 400 */     this.glCopyTexSubImage3D = getProcAddress("glCopyTexSubImage3D");
/*     */ 
/*     */     
/* 403 */     this.glActiveTexture = getProcAddress("glActiveTexture");
/* 404 */     this.glClientActiveTexture = getProcAddress("glClientActiveTexture");
/* 405 */     this.glMultiTexCoord1d = getProcAddress("glMultiTexCoord1d");
/* 406 */     this.glMultiTexCoord1dv = getProcAddress("glMultiTexCoord1dv");
/* 407 */     this.glMultiTexCoord1f = getProcAddress("glMultiTexCoord1f");
/* 408 */     this.glMultiTexCoord1fv = getProcAddress("glMultiTexCoord1fv");
/* 409 */     this.glMultiTexCoord1i = getProcAddress("glMultiTexCoord1i");
/* 410 */     this.glMultiTexCoord1iv = getProcAddress("glMultiTexCoord1iv");
/* 411 */     this.glMultiTexCoord1s = getProcAddress("glMultiTexCoord1s");
/* 412 */     this.glMultiTexCoord1sv = getProcAddress("glMultiTexCoord1sv");
/* 413 */     this.glMultiTexCoord2d = getProcAddress("glMultiTexCoord2d");
/* 414 */     this.glMultiTexCoord2dv = getProcAddress("glMultiTexCoord2dv");
/* 415 */     this.glMultiTexCoord2f = getProcAddress("glMultiTexCoord2f");
/* 416 */     this.glMultiTexCoord2fv = getProcAddress("glMultiTexCoord2fv");
/* 417 */     this.glMultiTexCoord2i = getProcAddress("glMultiTexCoord2i");
/* 418 */     this.glMultiTexCoord2iv = getProcAddress("glMultiTexCoord2iv");
/* 419 */     this.glMultiTexCoord2s = getProcAddress("glMultiTexCoord2s");
/* 420 */     this.glMultiTexCoord2sv = getProcAddress("glMultiTexCoord2sv");
/* 421 */     this.glMultiTexCoord3d = getProcAddress("glMultiTexCoord3d");
/* 422 */     this.glMultiTexCoord3dv = getProcAddress("glMultiTexCoord3dv");
/* 423 */     this.glMultiTexCoord3f = getProcAddress("glMultiTexCoord3f");
/* 424 */     this.glMultiTexCoord3fv = getProcAddress("glMultiTexCoord3fv");
/* 425 */     this.glMultiTexCoord3i = getProcAddress("glMultiTexCoord3i");
/* 426 */     this.glMultiTexCoord3iv = getProcAddress("glMultiTexCoord3iv");
/* 427 */     this.glMultiTexCoord3s = getProcAddress("glMultiTexCoord3s");
/* 428 */     this.glMultiTexCoord3sv = getProcAddress("glMultiTexCoord3sv");
/* 429 */     this.glMultiTexCoord4d = getProcAddress("glMultiTexCoord4d");
/* 430 */     this.glMultiTexCoord4dv = getProcAddress("glMultiTexCoord4dv");
/* 431 */     this.glMultiTexCoord4f = getProcAddress("glMultiTexCoord4f");
/* 432 */     this.glMultiTexCoord4fv = getProcAddress("glMultiTexCoord4fv");
/* 433 */     this.glMultiTexCoord4i = getProcAddress("glMultiTexCoord4i");
/* 434 */     this.glMultiTexCoord4iv = getProcAddress("glMultiTexCoord4iv");
/* 435 */     this.glMultiTexCoord4s = getProcAddress("glMultiTexCoord4s");
/* 436 */     this.glMultiTexCoord4sv = getProcAddress("glMultiTexCoord4sv");
/* 437 */     this.glLoadTransposeMatrixf = getProcAddress("glLoadTransposeMatrixf");
/* 438 */     this.glLoadTransposeMatrixd = getProcAddress("glLoadTransposeMatrixd");
/* 439 */     this.glMultTransposeMatrixf = getProcAddress("glMultTransposeMatrixf");
/* 440 */     this.glMultTransposeMatrixd = getProcAddress("glMultTransposeMatrixd");
/* 441 */     this.glSampleCoverage = getProcAddress("glSampleCoverage");
/* 442 */     this.glCompressedTexImage3D = getProcAddress("glCompressedTexImage3D");
/* 443 */     this.glCompressedTexImage2D = getProcAddress("glCompressedTexImage2D");
/* 444 */     this.glCompressedTexImage1D = getProcAddress("glCompressedTexImage1D");
/* 445 */     this.glCompressedTexSubImage3D = getProcAddress("glCompressedTexSubImage3D");
/* 446 */     this.glCompressedTexSubImage2D = getProcAddress("glCompressedTexSubImage2D");
/* 447 */     this.glCompressedTexSubImage1D = getProcAddress("glCompressedTexSubImage1D");
/* 448 */     this.glGetCompressedTexImage = getProcAddress("glGetCompressedTexImage");
/*     */ 
/*     */     
/* 451 */     this.glBlendFuncSeparate = getProcAddress("glBlendFuncSeparate");
/* 452 */     this.glFogCoordf = getProcAddress("glFogCoordf");
/* 453 */     this.glFogCoordfv = getProcAddress("glFogCoordfv");
/* 454 */     this.glFogCoordd = getProcAddress("glFogCoordd");
/* 455 */     this.glFogCoorddv = getProcAddress("glFogCoorddv");
/* 456 */     this.glFogCoordPointer = getProcAddress("glFogCoordPointer");
/* 457 */     this.glMultiDrawArrays = getProcAddress("glMultiDrawArrays");
/* 458 */     this.glMultiDrawElements = getProcAddress("glMultiDrawElements");
/* 459 */     this.glPointParameterf = getProcAddress("glPointParameterf");
/* 460 */     this.glPointParameterfv = getProcAddress("glPointParameterfv");
/* 461 */     this.glPointParameteri = getProcAddress("glPointParameteri");
/* 462 */     this.glPointParameteriv = getProcAddress("glPointParameteriv");
/* 463 */     this.glSecondaryColor3b = getProcAddress("glSecondaryColor3b");
/* 464 */     this.glSecondaryColor3bv = getProcAddress("glSecondaryColor3bv");
/* 465 */     this.glSecondaryColor3d = getProcAddress("glSecondaryColor3d");
/* 466 */     this.glSecondaryColor3dv = getProcAddress("glSecondaryColor3dv");
/* 467 */     this.glSecondaryColor3f = getProcAddress("glSecondaryColor3f");
/* 468 */     this.glSecondaryColor3fv = getProcAddress("glSecondaryColor3fv");
/* 469 */     this.glSecondaryColor3i = getProcAddress("glSecondaryColor3i");
/* 470 */     this.glSecondaryColor3iv = getProcAddress("glSecondaryColor3iv");
/* 471 */     this.glSecondaryColor3s = getProcAddress("glSecondaryColor3s");
/* 472 */     this.glSecondaryColor3sv = getProcAddress("glSecondaryColor3sv");
/* 473 */     this.glSecondaryColor3ub = getProcAddress("glSecondaryColor3ub");
/* 474 */     this.glSecondaryColor3ubv = getProcAddress("glSecondaryColor3ubv");
/* 475 */     this.glSecondaryColor3ui = getProcAddress("glSecondaryColor3ui");
/* 476 */     this.glSecondaryColor3uiv = getProcAddress("glSecondaryColor3uiv");
/* 477 */     this.glSecondaryColor3us = getProcAddress("glSecondaryColor3us");
/* 478 */     this.glSecondaryColor3usv = getProcAddress("glSecondaryColor3usv");
/* 479 */     this.glSecondaryColorPointer = getProcAddress("glSecondaryColorPointer");
/* 480 */     this.glWindowPos2d = getProcAddress("glWindowPos2d");
/* 481 */     this.glWindowPos2dv = getProcAddress("glWindowPos2dv");
/* 482 */     this.glWindowPos2f = getProcAddress("glWindowPos2f");
/* 483 */     this.glWindowPos2fv = getProcAddress("glWindowPos2fv");
/* 484 */     this.glWindowPos2i = getProcAddress("glWindowPos2i");
/* 485 */     this.glWindowPos2iv = getProcAddress("glWindowPos2iv");
/* 486 */     this.glWindowPos2s = getProcAddress("glWindowPos2s");
/* 487 */     this.glWindowPos2sv = getProcAddress("glWindowPos2sv");
/* 488 */     this.glWindowPos3d = getProcAddress("glWindowPos3d");
/* 489 */     this.glWindowPos3dv = getProcAddress("glWindowPos3dv");
/* 490 */     this.glWindowPos3f = getProcAddress("glWindowPos3f");
/* 491 */     this.glWindowPos3fv = getProcAddress("glWindowPos3fv");
/* 492 */     this.glWindowPos3i = getProcAddress("glWindowPos3i");
/* 493 */     this.glWindowPos3iv = getProcAddress("glWindowPos3iv");
/* 494 */     this.glWindowPos3s = getProcAddress("glWindowPos3s");
/* 495 */     this.glWindowPos3sv = getProcAddress("glWindowPos3sv");
/*     */ 
/*     */     
/* 498 */     this.glGenQueries = getProcAddress("glGenQueries");
/* 499 */     this.glDeleteQueries = getProcAddress("glDeleteQueries");
/* 500 */     this.glIsQuery = getProcAddress("glIsQuery");
/* 501 */     this.glBeginQuery = getProcAddress("glBeginQuery");
/* 502 */     this.glEndQuery = getProcAddress("glEndQuery");
/* 503 */     this.glGetQueryiv = getProcAddress("glGetQueryiv");
/* 504 */     this.glGetQueryObjectiv = getProcAddress("glGetQueryObjectiv");
/* 505 */     this.glGetQueryObjectuiv = getProcAddress("glGetQueryObjectuiv");
/* 506 */     this.glBindBuffer = getProcAddress("glBindBuffer");
/* 507 */     this.glDeleteBuffers = getProcAddress("glDeleteBuffers");
/* 508 */     this.glGenBuffers = getProcAddress("glGenBuffers");
/* 509 */     this.glIsBuffer = getProcAddress("glIsBuffer");
/* 510 */     this.glBufferData = getProcAddress("glBufferData");
/* 511 */     this.glBufferSubData = getProcAddress("glBufferSubData");
/* 512 */     this.glGetBufferSubData = getProcAddress("glGetBufferSubData");
/* 513 */     this.glMapBuffer = getProcAddress("glMapBuffer");
/* 514 */     this.glUnmapBuffer = getProcAddress("glUnmapBuffer");
/* 515 */     this.glGetBufferParameteriv = getProcAddress("glGetBufferParameteriv");
/* 516 */     this.glGetBufferPointerv = getProcAddress("glGetBufferPointerv");
/*     */ 
/*     */     
/* 519 */     this._gotProcAddresses = true;
/*     */   }
/*     */   
/*     */   private static native void killGlContext(long paramLong);
/*     */   
/*     */   private static native long makeGlAwtCanvasContext(Canvas paramCanvas);
/*     */   
/*     */   private static native boolean lock(long paramLong);
/*     */   
/*     */   private static native boolean unlock(long paramLong);
/*     */   
/*     */   private static native boolean swapBuffers(long paramLong);
/*     */   
/*     */   private static native long getProcAddress(String paramString); }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opengl/GlContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */