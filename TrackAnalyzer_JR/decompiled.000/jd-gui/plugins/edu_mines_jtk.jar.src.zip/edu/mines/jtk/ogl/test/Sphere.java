/*     */ package edu.mines.jtk.ogl.test;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import edu.mines.jtk.ogl.GlCanvas;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.FloatBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sphere
/*     */ {
/*  23 */   private static GlCanvas canvas = new GlCanvas()
/*     */     {
/*     */       private FloatBuffer _buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private void computeVertices() {
/*  36 */         int nphi = 50;
/*  37 */         int ntheta = 100;
/*     */         
/*  39 */         float dphi = 0.06283186F;
/*  40 */         float dtheta = 0.06283186F;
/*     */         
/*  42 */         float[] vertices = new float[88200];
/*     */ 
/*     */         
/*  45 */         float[] phiSin = new float[50];
/*  46 */         float[] phiCos = new float[50];
/*  47 */         for (int i = 0; i < 50; i++) {
/*  48 */           float phi = i * 0.06283186F;
/*  49 */           phiSin[i] = (float)Math.sin(phi);
/*  50 */           phiCos[i] = (float)Math.cos(phi);
/*     */         } 
/*  52 */         float[] thetaSin = new float[100];
/*  53 */         float[] thetaCos = new float[100];
/*  54 */         for (int j = 0; j < 100; j++) {
/*  55 */           float theta = j * 0.06283186F;
/*  56 */           thetaSin[j] = (float)Math.sin(theta);
/*  57 */           thetaCos[j] = (float)Math.cos(theta);
/*     */         } 
/*     */ 
/*     */         
/*  61 */         int index = 0;
/*  62 */         for (int m = 0; m < 100; m++) {
/*     */           
/*  64 */           vertices[index++] = 0.0F;
/*  65 */           vertices[index++] = 0.0F;
/*  66 */           vertices[index++] = 1.0F;
/*     */           
/*  68 */           vertices[index++] = thetaCos[m] * phiSin[1];
/*  69 */           vertices[index++] = thetaSin[m] * phiSin[1];
/*  70 */           vertices[index++] = phiCos[1];
/*     */           
/*  72 */           int n = (m + 1) % 100;
/*  73 */           vertices[index++] = thetaCos[n] * phiSin[1];
/*  74 */           vertices[index++] = thetaSin[n] * phiSin[1];
/*  75 */           vertices[index++] = phiCos[1];
/*     */         } 
/*     */ 
/*     */         
/*  79 */         for (int ip = 1; ip < 49; ip++) {
/*  80 */           for (int it = 0; it < 100; it++) {
/*  81 */             int jt = (it + 1) % 100;
/*  82 */             vertices[index++] = thetaCos[it] * phiSin[ip];
/*  83 */             vertices[index++] = thetaSin[it] * phiSin[ip];
/*  84 */             vertices[index++] = phiCos[ip];
/*     */             
/*  86 */             vertices[index++] = thetaCos[it] * phiSin[ip + 1];
/*  87 */             vertices[index++] = thetaSin[it] * phiSin[ip + 1];
/*  88 */             vertices[index++] = phiCos[ip + 1];
/*     */             
/*  90 */             vertices[index++] = thetaCos[jt] * phiSin[ip];
/*  91 */             vertices[index++] = thetaSin[jt] * phiSin[ip];
/*  92 */             vertices[index++] = phiCos[ip];
/*     */             
/*  94 */             vertices[index] = vertices[index - 3];
/*  95 */             index++;
/*  96 */             vertices[index] = vertices[index - 3];
/*  97 */             index++;
/*  98 */             vertices[index] = vertices[index - 3];
/*  99 */             index++;
/*     */             
/* 101 */             vertices[index] = vertices[index - 9];
/* 102 */             index++;
/* 103 */             vertices[index] = vertices[index - 9];
/* 104 */             index++;
/* 105 */             vertices[index] = vertices[index - 9];
/* 106 */             index++;
/*     */             
/* 108 */             vertices[index++] = thetaCos[jt] * phiSin[ip + 1];
/* 109 */             vertices[index++] = thetaSin[jt] * phiSin[ip + 1];
/* 110 */             vertices[index++] = phiCos[ip + 1];
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 115 */         for (int k = 0; k < 100; k++) {
/* 116 */           vertices[index++] = thetaCos[k] * phiSin[49];
/* 117 */           vertices[index++] = thetaSin[k] * phiSin[49];
/* 118 */           vertices[index++] = phiCos[49];
/*     */ 
/*     */           
/* 121 */           vertices[index++] = 0.0F;
/* 122 */           vertices[index++] = 0.0F;
/* 123 */           vertices[index++] = 1.0F;
/*     */           
/* 125 */           int n = (k + 1) % 100;
/* 126 */           vertices[index++] = thetaCos[n] * phiSin[49];
/* 127 */           vertices[index++] = thetaSin[n] * phiSin[49];
/* 128 */           vertices[index++] = phiCos[49];
/*     */         } 
/*     */         
/* 131 */         this._buffer = ByteBuffer.allocateDirect(vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
/*     */         
/* 133 */         this._buffer.put(vertices);
/* 134 */         this._buffer.rewind();
/*     */       }
/*     */       
/*     */       public void glInit() {
/* 138 */         computeVertices();
/*     */         
/* 140 */         float[] mat_specular = { 1.0F, 1.0F, 1.0F, 1.0F };
/* 141 */         float[] mat_shininess = { 50.0F };
/* 142 */         float[] light_position = { 1.0F, -3.0F, 1.0F, 0.0F };
/* 143 */         float[] white_light = { 1.0F, 1.0F, 1.0F, 1.0F };
/* 144 */         float[] lmodel_ambient = { 0.1F, 0.1F, 0.1F, 1.0F };
/*     */         
/* 146 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 147 */         Gl.glShadeModel(7425);
/* 148 */         Gl.glMaterialfv(1028, 4610, mat_specular, 0);
/* 149 */         Gl.glMaterialfv(1028, 5633, mat_shininess, 0);
/* 150 */         Gl.glLightfv(16384, 4611, light_position, 0);
/* 151 */         Gl.glLightfv(16384, 4609, white_light, 0);
/* 152 */         Gl.glLightfv(16384, 4610, white_light, 0);
/* 153 */         Gl.glLightModelfv(2899, lmodel_ambient, 0);
/* 154 */         Gl.glLightModeli(2898, 0);
/*     */       }
/*     */       
/*     */       public void glResize(int x, int y, int width, int height) {
/* 158 */         Gl.glViewport(0, 0, width, height);
/* 159 */         Gl.glMatrixMode(5889);
/* 160 */         Gl.glLoadIdentity();
/* 161 */         Gl.glOrtho(-1.2D, 1.2D, -1.2D, 1.2D, -2.0D, 2.0D);
/* 162 */         Gl.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*     */       
/*     */       public void glPaint() {
/* 166 */         Gl.glClear(16640);
/* 167 */         Gl.glEnable(2896);
/* 168 */         Gl.glEnable(16384);
/* 169 */         Gl.glEnable(2929);
/* 170 */         Gl.glEnableClientState(32885);
/* 171 */         Gl.glEnableClientState(32884);
/* 172 */         Gl.glVertexPointer(3, 5126, 0, this._buffer);
/* 173 */         Gl.glNormalPointer(5126, 0, this._buffer);
/* 174 */         Gl.glColor3f(1.0F, 1.0F, 1.0F);
/* 175 */         Gl.glDrawArrays(4, 0, this._buffer.capacity() / 3);
/* 176 */         Gl.glFlush();
/*     */       }
/*     */     };
/*     */   
/*     */   public static void main(String[] args) {
/* 181 */     TestSimple.run(args, canvas);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/Sphere.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */