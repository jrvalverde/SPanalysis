/*      */ package edu.mines.jtk.util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Parameter
/*      */   implements Cloneable
/*      */ {
/*      */   public static final int NULL = 0;
/*      */   public static final int BOOLEAN = 1;
/*      */   public static final int INT = 2;
/*      */   public static final int LONG = 3;
/*      */   public static final int FLOAT = 4;
/*      */   public static final int DOUBLE = 5;
/*      */   public static final int STRING = 6;
/*      */   private String _name;
/*      */   private ParameterSet _parent;
/*      */   private String _units;
/*      */   private Object _values;
/*      */   
/*      */   public Parameter(String name) {
/*   74 */     setNameAndParent(name, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, boolean value) {
/*   83 */     setNameAndParent(name, null);
/*   84 */     setBoolean(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, int value) {
/*   93 */     setNameAndParent(name, null);
/*   94 */     setInt(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, long value) {
/*  103 */     setNameAndParent(name, null);
/*  104 */     setLong(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, float value) {
/*  113 */     setNameAndParent(name, null);
/*  114 */     setFloat(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, double value) {
/*  123 */     setNameAndParent(name, null);
/*  124 */     setDouble(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, String value) {
/*  133 */     setNameAndParent(name, null);
/*  134 */     setString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, boolean[] values) {
/*  143 */     setNameAndParent(name, null);
/*  144 */     setBooleans(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, int[] values) {
/*  153 */     setNameAndParent(name, null);
/*  154 */     setInts(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, long[] values) {
/*  163 */     setNameAndParent(name, null);
/*  164 */     setLongs(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, float[] values) {
/*  173 */     setNameAndParent(name, null);
/*  174 */     setFloats(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, double[] values) {
/*  183 */     setNameAndParent(name, null);
/*  184 */     setDoubles(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, String[] values) {
/*  193 */     setNameAndParent(name, null);
/*  194 */     setStrings(values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, boolean value, String units) {
/*  204 */     setNameAndParent(name, null);
/*  205 */     setBoolean(value);
/*  206 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, int value, String units) {
/*  216 */     setNameAndParent(name, null);
/*  217 */     setInt(value);
/*  218 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, long value, String units) {
/*  228 */     setNameAndParent(name, null);
/*  229 */     setLong(value);
/*  230 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, float value, String units) {
/*  240 */     setNameAndParent(name, null);
/*  241 */     setFloat(value);
/*  242 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, double value, String units) {
/*  252 */     setNameAndParent(name, null);
/*  253 */     setDouble(value);
/*  254 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, String value, String units) {
/*  264 */     setNameAndParent(name, null);
/*  265 */     setString(value);
/*  266 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, boolean[] values, String units) {
/*  276 */     setNameAndParent(name, null);
/*  277 */     setBooleans(values);
/*  278 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, int[] values, String units) {
/*  288 */     setNameAndParent(name, null);
/*  289 */     setInts(values);
/*  290 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, long[] values, String units) {
/*  300 */     setNameAndParent(name, null);
/*  301 */     setLongs(values);
/*  302 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, float[] values, String units) {
/*  312 */     setNameAndParent(name, null);
/*  313 */     setFloats(values);
/*  314 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, double[] values, String units) {
/*  324 */     setNameAndParent(name, null);
/*  325 */     setDoubles(values);
/*  326 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter(String name, String[] values, String units) {
/*  336 */     setNameAndParent(name, null);
/*  337 */     setStrings(values);
/*  338 */     setUnits(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() {
/*      */     try {
/*  348 */       Parameter p = (Parameter)super.clone();
/*  349 */       p._parent = null;
/*  350 */       return p.replaceWith(this);
/*  351 */     } catch (CloneNotSupportedException e) {
/*  352 */       throw new InternalError();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter replaceWith(Parameter par) {
/*  365 */     if (par == this) return this; 
/*  366 */     setName(par.getName());
/*  367 */     setUnits(par.getUnits());
/*  368 */     setValues(par.getValues());
/*  369 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter copyTo(ParameterSet parent) {
/*  381 */     return copyTo(parent, getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter copyTo(ParameterSet parent, String name) {
/*  394 */     if (parent == this._parent && name == this._name) return this; 
/*  395 */     Parameter p = (parent != null) ? parent.addParameter(name) : new Parameter(name);
/*  396 */     p.setUnits(getUnits());
/*  397 */     p.setValues(getValues());
/*  398 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter moveTo(ParameterSet parent) {
/*  410 */     return moveTo(parent, getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parameter moveTo(ParameterSet parent, String name) {
/*  423 */     if (parent == this._parent && name == this._name) return this; 
/*  424 */     if (this._parent != null) this._parent.remove(this); 
/*  425 */     if (parent != null) {
/*  426 */       parent.insert(name, this);
/*      */     } else {
/*  428 */       setNameAndParent(name, null);
/*      */     } 
/*  430 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove() {
/*  439 */     if (this._parent != null) this._parent.remove(this);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  447 */     return this._name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  456 */     moveTo(this._parent, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUnits() {
/*  464 */     return this._units;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnits(String units) {
/*  472 */     this._units = units;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() {
/*  480 */     if (this._values instanceof boolean[])
/*  481 */       return 1; 
/*  482 */     if (this._values instanceof int[])
/*  483 */       return 2; 
/*  484 */     if (this._values instanceof long[])
/*  485 */       return 3; 
/*  486 */     if (this._values instanceof float[])
/*  487 */       return 4; 
/*  488 */     if (this._values instanceof double[])
/*  489 */       return 5; 
/*  490 */     if (this._values instanceof String[]) {
/*  491 */       return 6;
/*      */     }
/*  493 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setType(int type) {
/*  505 */     if (type == 1) {
/*  506 */       this._values = valuesAsBooleans(this._values, false);
/*  507 */     } else if (type == 2) {
/*  508 */       this._values = valuesAsInts(this._values, false);
/*  509 */     } else if (type == 3) {
/*  510 */       this._values = valuesAsLongs(this._values, false);
/*  511 */     } else if (type == 4) {
/*  512 */       this._values = valuesAsFloats(this._values, false);
/*  513 */     } else if (type == 5) {
/*  514 */       this._values = valuesAsDoubles(this._values, false);
/*  515 */     } else if (type == 6) {
/*  516 */       this._values = valuesAsStrings(this._values, false);
/*      */     } else {
/*  518 */       this._values = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterSet getParent() {
/*  528 */     return this._parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean() throws ParameterConvertException {
/*  540 */     boolean[] values = valuesAsBooleans(this._values, false);
/*  541 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt() throws ParameterConvertException {
/*  553 */     int[] values = valuesAsInts(this._values, false);
/*  554 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong() throws ParameterConvertException {
/*  566 */     long[] values = valuesAsLongs(this._values, false);
/*  567 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat() throws ParameterConvertException {
/*  579 */     float[] values = valuesAsFloats(this._values, false);
/*  580 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble() throws ParameterConvertException {
/*  592 */     double[] values = valuesAsDoubles(this._values, false);
/*  593 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString() throws ParameterConvertException {
/*  605 */     String[] values = valuesAsStrings(this._values, false);
/*  606 */     return values[values.length - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean[] getBooleans() throws ParameterConvertException {
/*  617 */     return valuesAsBooleans(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getInts() throws ParameterConvertException {
/*  628 */     return valuesAsInts(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongs() throws ParameterConvertException {
/*  639 */     return valuesAsLongs(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getFloats() throws ParameterConvertException {
/*  650 */     return valuesAsFloats(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double[] getDoubles() throws ParameterConvertException {
/*  661 */     return valuesAsDoubles(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getStrings() throws ParameterConvertException {
/*  672 */     return valuesAsStrings(this._values, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(boolean value) {
/*  680 */     this._values = new boolean[1];
/*  681 */     ((boolean[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int value) {
/*  689 */     this._values = new int[1];
/*  690 */     ((int[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(long value) {
/*  698 */     this._values = new long[1];
/*  699 */     ((long[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(float value) {
/*  707 */     this._values = new float[1];
/*  708 */     ((float[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(double value) {
/*  716 */     this._values = new double[1];
/*  717 */     ((double[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String value) {
/*  725 */     this._values = new String[1];
/*  726 */     ((String[])this._values)[0] = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBooleans(boolean[] values) {
/*  734 */     int length = (values == null) ? 0 : values.length;
/*  735 */     this._values = new boolean[length];
/*  736 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInts(int[] values) {
/*  744 */     int length = (values == null) ? 0 : values.length;
/*  745 */     this._values = new int[length];
/*  746 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLongs(long[] values) {
/*  754 */     int length = (values == null) ? 0 : values.length;
/*  755 */     this._values = new long[length];
/*  756 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloats(float[] values) {
/*  764 */     int length = (values == null) ? 0 : values.length;
/*  765 */     this._values = new float[length];
/*  766 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDoubles(double[] values) {
/*  774 */     int length = (values == null) ? 0 : values.length;
/*  775 */     this._values = new double[length];
/*  776 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStrings(String[] values) {
/*  784 */     int length = (values == null) ? 0 : values.length;
/*  785 */     this._values = new String[length];
/*  786 */     if (length > 0) System.arraycopy(values, 0, this._values, 0, length);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNull() {
/*  794 */     return (getType() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBoolean() {
/*  802 */     return (getType() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInt() {
/*  810 */     return (getType() == 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLong() {
/*  818 */     return (getType() == 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFloat() {
/*  826 */     return (getType() == 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDouble() {
/*  834 */     return (getType() == 5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isString() {
/*  842 */     return (getType() == 6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  854 */     String indent = "";
/*  855 */     ParameterSet parent = getParent();
/*  856 */     for (; parent != null; 
/*  857 */       parent = parent.getParent()) {
/*  858 */       indent = indent + "  ";
/*      */     }
/*      */ 
/*      */     
/*  862 */     String name = XmlUtil.quoteAttributeValue(this._name);
/*  863 */     String units = XmlUtil.quoteAttributeValue(this._units);
/*  864 */     String type = XmlUtil.quoteAttributeValue(getTypeString());
/*  865 */     String[] values = valuesAsStrings(this._values, true);
/*  866 */     for (int i = 0; i < values.length; i++) {
/*  867 */       values[i] = XmlUtil.quoteCharacterData(values[i]);
/*      */     }
/*      */ 
/*      */     
/*  871 */     StringBuffer sb = new StringBuffer(256);
/*  872 */     sb.append(indent).append("<par name=").append(name);
/*  873 */     sb.append(" type=").append(type);
/*  874 */     if (units != null) sb.append(" units=").append(units); 
/*  875 */     if (isNull() || values.length == 0) {
/*  876 */       sb.append("/>\n");
/*  877 */     } else if (values.length == 1) {
/*  878 */       sb.append("> ").append(values[0]).append(" </par>\n");
/*      */     } else {
/*  880 */       sb.append(">\n");
/*  881 */       for (int j = 0; j < values.length; j++) {
/*  882 */         sb.append(indent).append("  ").append(values[j]).append("\n");
/*      */       }
/*  884 */       sb.append(indent).append("</par>\n");
/*      */     } 
/*  886 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/*  895 */     if (o == this)
/*  896 */       return true; 
/*  897 */     if (o == null || getClass() != o.getClass())
/*  898 */       return false; 
/*  899 */     Parameter other = (Parameter)o;
/*      */ 
/*      */     
/*  902 */     if (this._name == null) {
/*  903 */       if (other._name != null)
/*  904 */         return false; 
/*  905 */     } else if (!this._name.equals(other._name)) {
/*  906 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  910 */     if (this._units == null) {
/*  911 */       if (other._units != null)
/*  912 */         return false; 
/*  913 */     } else if (!this._units.equals(other._units)) {
/*  914 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  918 */     if (getType() != other.getType()) {
/*  919 */       return false;
/*      */     }
/*      */     
/*  922 */     int nvalues = countValues();
/*  923 */     if (nvalues != other.countValues()) {
/*  924 */       return false;
/*      */     }
/*      */     
/*  927 */     int type = getType();
/*  928 */     if (type == 1) {
/*  929 */       boolean[] values = (boolean[])this._values;
/*  930 */       boolean[] otherValues = (boolean[])other._values;
/*  931 */       for (int i = 0; i < nvalues; i++) {
/*  932 */         if (values[i] != otherValues[i])
/*  933 */           return false; 
/*      */       } 
/*  935 */     } else if (type == 2) {
/*  936 */       int[] values = (int[])this._values;
/*  937 */       int[] otherValues = (int[])other._values;
/*  938 */       for (int i = 0; i < nvalues; i++) {
/*  939 */         if (values[i] != otherValues[i])
/*  940 */           return false; 
/*      */       } 
/*  942 */     } else if (type == 3) {
/*  943 */       long[] values = (long[])this._values;
/*  944 */       long[] otherValues = (long[])other._values;
/*  945 */       for (int i = 0; i < nvalues; i++) {
/*  946 */         if (values[i] != otherValues[i])
/*  947 */           return false; 
/*      */       } 
/*  949 */     } else if (type == 4) {
/*  950 */       float[] values = (float[])this._values;
/*  951 */       float[] otherValues = (float[])other._values;
/*  952 */       for (int i = 0; i < nvalues; i++) {
/*  953 */         if (values[i] != otherValues[i])
/*  954 */           return false; 
/*      */       } 
/*  956 */     } else if (type == 5) {
/*  957 */       double[] values = (double[])this._values;
/*  958 */       double[] otherValues = (double[])other._values;
/*  959 */       for (int i = 0; i < nvalues; i++) {
/*  960 */         if (values[i] != otherValues[i])
/*  961 */           return false; 
/*      */       } 
/*  963 */     } else if (type == 6) {
/*  964 */       String[] values = (String[])this._values;
/*  965 */       String[] otherValues = (String[])other._values;
/*  966 */       for (int i = 0; i < nvalues; i++) {
/*  967 */         if (!values[i].equals(otherValues[i])) {
/*  968 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  973 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  982 */     String name = (this._name != null) ? this._name : "name";
/*  983 */     String units = (this._units != null) ? this._units : "units";
/*  984 */     int type = getType();
/*  985 */     int code = name.hashCode() ^ units.hashCode() ^ type;
/*  986 */     int nvalues = countValues();
/*  987 */     if (type == 1) {
/*  988 */       boolean[] values = (boolean[])this._values;
/*  989 */       for (int i = 0; i < nvalues; i++) {
/*  990 */         code ^= values[i] ? 1 : 0;
/*      */       }
/*  992 */     } else if (type == 2) {
/*  993 */       int[] values = (int[])this._values;
/*  994 */       for (int i = 0; i < nvalues; i++) {
/*  995 */         code ^= values[i];
/*      */       }
/*  997 */     } else if (type == 3) {
/*  998 */       long[] values = (long[])this._values;
/*  999 */       for (int i = 0; i < nvalues; i++) {
/* 1000 */         long bits = values[i];
/* 1001 */         code ^= (int)bits ^ (int)(bits >> 32L);
/*      */       } 
/* 1003 */     } else if (type == 4) {
/* 1004 */       float[] values = (float[])this._values;
/* 1005 */       for (int i = 0; i < nvalues; i++)
/* 1006 */         code ^= Float.floatToIntBits(values[i]); 
/* 1007 */     } else if (type == 5) {
/* 1008 */       double[] values = (double[])this._values;
/* 1009 */       for (int i = 0; i < nvalues; i++) {
/* 1010 */         long bits = Double.doubleToLongBits(values[i]);
/* 1011 */         code ^= (int)bits ^ (int)(bits >> 32L);
/*      */       } 
/* 1013 */     } else if (type == 6) {
/* 1014 */       String[] values = (String[])this._values;
/* 1015 */       for (int i = 0; i < nvalues; i++) {
/* 1016 */         code ^= values[i].hashCode();
/*      */       }
/*      */     } 
/* 1019 */     return code;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Parameter(String name, ParameterSet parent) {
/* 1027 */     setNameAndParent(name, parent);
/*      */   }
/*      */   
/*      */   void setParent(ParameterSet parent) {
/* 1031 */     this._parent = parent;
/*      */   }
/*      */   
/*      */   void setNameAndParent(String name, ParameterSet parent) {
/* 1035 */     this._name = name;
/* 1036 */     if (this._name != null && this._name.equals("")) this._name = null; 
/* 1037 */     this._parent = parent;
/*      */   }
/*      */   
/*      */   Object getValues() {
/* 1041 */     int n = 0;
/* 1042 */     Object values = null;
/* 1043 */     if (this._values instanceof boolean[]) {
/* 1044 */       n = ((boolean[])this._values).length;
/* 1045 */       values = new boolean[n];
/* 1046 */     } else if (this._values instanceof int[]) {
/* 1047 */       n = ((int[])this._values).length;
/* 1048 */       values = new int[n];
/* 1049 */     } else if (this._values instanceof long[]) {
/* 1050 */       n = ((long[])this._values).length;
/* 1051 */       values = new long[n];
/* 1052 */     } else if (this._values instanceof float[]) {
/* 1053 */       n = ((float[])this._values).length;
/* 1054 */       values = new float[n];
/* 1055 */     } else if (this._values instanceof double[]) {
/* 1056 */       n = ((double[])this._values).length;
/* 1057 */       values = new double[n];
/* 1058 */     } else if (this._values instanceof String[]) {
/* 1059 */       n = ((String[])this._values).length;
/* 1060 */       values = new String[n];
/*      */     } 
/* 1062 */     if (n > 0) System.arraycopy(this._values, 0, values, 0, n); 
/* 1063 */     return values;
/*      */   }
/*      */   
/*      */   void setValues(Object values) {
/* 1067 */     int n = 0;
/* 1068 */     this._values = null;
/* 1069 */     if (values instanceof boolean[]) {
/* 1070 */       n = ((boolean[])values).length;
/* 1071 */       this._values = new boolean[n];
/* 1072 */     } else if (values instanceof int[]) {
/* 1073 */       n = ((int[])values).length;
/* 1074 */       this._values = new int[n];
/* 1075 */     } else if (values instanceof long[]) {
/* 1076 */       n = ((long[])values).length;
/* 1077 */       this._values = new long[n];
/* 1078 */     } else if (values instanceof float[]) {
/* 1079 */       n = ((float[])values).length;
/* 1080 */       this._values = new float[n];
/* 1081 */     } else if (values instanceof double[]) {
/* 1082 */       n = ((double[])values).length;
/* 1083 */       this._values = new double[n];
/* 1084 */     } else if (values instanceof String[]) {
/* 1085 */       n = ((String[])values).length;
/* 1086 */       this._values = new String[n];
/*      */     } 
/* 1088 */     if (n > 0) System.arraycopy(values, 0, this._values, 0, n);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int countValues() {
/* 1101 */     if (getType() == 1)
/* 1102 */       return ((boolean[])this._values).length; 
/* 1103 */     if (getType() == 2)
/* 1104 */       return ((int[])this._values).length; 
/* 1105 */     if (getType() == 3)
/* 1106 */       return ((long[])this._values).length; 
/* 1107 */     if (getType() == 4)
/* 1108 */       return ((float[])this._values).length; 
/* 1109 */     if (getType() == 5)
/* 1110 */       return ((double[])this._values).length; 
/* 1111 */     if (getType() == 6) {
/* 1112 */       return ((String[])this._values).length;
/*      */     }
/* 1114 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean[] valuesAsBooleans(Object values, boolean copy) {
/* 1119 */     boolean[] bvalues = null;
/* 1120 */     if (values instanceof boolean[]) {
/* 1121 */       bvalues = (boolean[])values;
/* 1122 */       if (copy) {
/* 1123 */         bvalues = new boolean[bvalues.length];
/* 1124 */         System.arraycopy(values, 0, bvalues, 0, bvalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1128 */         if (values instanceof String[]) {
/* 1129 */           String[] svalues = (String[])values;
/* 1130 */           bvalues = new boolean[svalues.length];
/* 1131 */           for (int i = 0; i < svalues.length; i++) {
/* 1132 */             String s = svalues[i].toLowerCase();
/* 1133 */             if (s.equals("true")) {
/* 1134 */               bvalues[i] = true;
/* 1135 */             } else if (s.equals("false")) {
/* 1136 */               bvalues[i] = false;
/*      */             } else {
/* 1138 */               throw new Exception();
/*      */             } 
/*      */           } 
/* 1141 */         } else if (values == null) {
/* 1142 */           bvalues = new boolean[0];
/*      */         } else {
/* 1144 */           throw new Exception();
/*      */         } 
/* 1146 */       } catch (Exception e) {
/* 1147 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to boolean.";
/*      */         
/* 1149 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1152 */     return bvalues;
/*      */   }
/*      */   
/*      */   private static int[] valuesAsInts(Object values, boolean copy) {
/* 1156 */     int[] ivalues = null;
/* 1157 */     if (values instanceof int[]) {
/* 1158 */       ivalues = (int[])values;
/* 1159 */       if (copy) {
/* 1160 */         ivalues = new int[ivalues.length];
/* 1161 */         System.arraycopy(values, 0, ivalues, 0, ivalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1165 */         if (values instanceof String[]) {
/* 1166 */           String[] svalues = (String[])values;
/* 1167 */           ivalues = new int[svalues.length];
/* 1168 */           for (int i = 0; i < svalues.length; i++) {
/* 1169 */             ivalues[i] = Integer.valueOf(svalues[i]).intValue();
/*      */           }
/* 1171 */         } else if (values == null) {
/* 1172 */           ivalues = new int[0];
/*      */         } else {
/* 1174 */           throw new Exception();
/*      */         } 
/* 1176 */       } catch (Exception e) {
/* 1177 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to int.";
/*      */         
/* 1179 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1182 */     return ivalues;
/*      */   }
/*      */   
/*      */   private static long[] valuesAsLongs(Object values, boolean copy) {
/* 1186 */     long[] lvalues = null;
/* 1187 */     if (values instanceof long[]) {
/* 1188 */       lvalues = (long[])values;
/* 1189 */       if (copy) {
/* 1190 */         lvalues = new long[lvalues.length];
/* 1191 */         System.arraycopy(values, 0, lvalues, 0, lvalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1195 */         if (values instanceof String[]) {
/* 1196 */           String[] svalues = (String[])values;
/* 1197 */           lvalues = new long[svalues.length];
/* 1198 */           for (int i = 0; i < svalues.length; i++) {
/* 1199 */             lvalues[i] = Long.valueOf(svalues[i]).longValue();
/*      */           }
/* 1201 */         } else if (values == null) {
/* 1202 */           lvalues = new long[0];
/*      */         } else {
/* 1204 */           throw new Exception();
/*      */         } 
/* 1206 */       } catch (Exception e) {
/* 1207 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to long.";
/*      */         
/* 1209 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1212 */     return lvalues;
/*      */   }
/*      */   
/*      */   private static float[] valuesAsFloats(Object values, boolean copy) {
/* 1216 */     float[] fvalues = null;
/* 1217 */     if (values instanceof float[]) {
/* 1218 */       fvalues = (float[])values;
/* 1219 */       if (copy) {
/* 1220 */         fvalues = new float[fvalues.length];
/* 1221 */         System.arraycopy(values, 0, fvalues, 0, fvalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1225 */         if (values instanceof int[]) {
/* 1226 */           int[] ivalues = (int[])values;
/* 1227 */           fvalues = new float[ivalues.length];
/* 1228 */           for (int i = 0; i < ivalues.length; i++) {
/* 1229 */             fvalues[i] = ivalues[i];
/*      */           }
/* 1231 */         } else if (values instanceof double[]) {
/* 1232 */           double[] dvalues = (double[])values;
/* 1233 */           fvalues = new float[dvalues.length];
/* 1234 */           for (int i = 0; i < dvalues.length; i++) {
/* 1235 */             fvalues[i] = (float)dvalues[i];
/*      */           }
/* 1237 */         } else if (values instanceof String[]) {
/* 1238 */           String[] svalues = (String[])values;
/* 1239 */           fvalues = new float[svalues.length];
/* 1240 */           for (int i = 0; i < svalues.length; i++) {
/* 1241 */             fvalues[i] = Float.valueOf(svalues[i]).floatValue();
/*      */           }
/* 1243 */         } else if (values == null) {
/* 1244 */           fvalues = new float[0];
/*      */         } else {
/* 1246 */           throw new Exception();
/*      */         } 
/* 1248 */       } catch (Exception e) {
/* 1249 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to float.";
/*      */         
/* 1251 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1254 */     return fvalues;
/*      */   }
/*      */   
/*      */   private static double[] valuesAsDoubles(Object values, boolean copy) {
/* 1258 */     double[] dvalues = null;
/* 1259 */     if (values instanceof double[]) {
/* 1260 */       dvalues = (double[])values;
/* 1261 */       if (copy) {
/* 1262 */         dvalues = new double[dvalues.length];
/* 1263 */         System.arraycopy(values, 0, dvalues, 0, dvalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1267 */         if (values instanceof int[]) {
/* 1268 */           int[] ivalues = (int[])values;
/* 1269 */           dvalues = new double[ivalues.length];
/* 1270 */           for (int i = 0; i < ivalues.length; i++) {
/* 1271 */             dvalues[i] = ivalues[i];
/*      */           }
/* 1273 */         } else if (values instanceof float[]) {
/* 1274 */           float[] fvalues = (float[])values;
/* 1275 */           dvalues = new double[fvalues.length];
/* 1276 */           for (int i = 0; i < fvalues.length; i++) {
/* 1277 */             dvalues[i] = fvalues[i];
/*      */           }
/* 1279 */         } else if (values instanceof String[]) {
/* 1280 */           String[] svalues = (String[])values;
/* 1281 */           dvalues = new double[svalues.length];
/* 1282 */           for (int i = 0; i < svalues.length; i++) {
/* 1283 */             dvalues[i] = Double.valueOf(svalues[i]).doubleValue();
/*      */           }
/* 1285 */         } else if (values == null) {
/* 1286 */           dvalues = new double[0];
/*      */         } else {
/* 1288 */           throw new Exception();
/*      */         } 
/* 1290 */       } catch (Exception e) {
/* 1291 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to double.";
/*      */         
/* 1293 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1296 */     return dvalues;
/*      */   }
/*      */   
/*      */   private static String[] valuesAsStrings(Object values, boolean copy) {
/* 1300 */     String[] svalues = null;
/* 1301 */     if (values instanceof String[]) {
/* 1302 */       svalues = (String[])values;
/* 1303 */       if (copy) {
/* 1304 */         svalues = new String[svalues.length];
/* 1305 */         System.arraycopy(values, 0, svalues, 0, svalues.length);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 1309 */         if (values instanceof boolean[]) {
/* 1310 */           boolean[] bvalues = (boolean[])values;
/* 1311 */           svalues = new String[bvalues.length];
/* 1312 */           for (int i = 0; i < bvalues.length; i++) {
/* 1313 */             svalues[i] = bvalues[i] ? "true" : "false";
/*      */           }
/* 1315 */         } else if (values instanceof int[]) {
/* 1316 */           int[] ivalues = (int[])values;
/* 1317 */           svalues = new String[ivalues.length];
/* 1318 */           for (int i = 0; i < ivalues.length; i++) {
/* 1319 */             svalues[i] = Integer.toString(ivalues[i]);
/*      */           }
/* 1321 */         } else if (values instanceof long[]) {
/* 1322 */           long[] lvalues = (long[])values;
/* 1323 */           svalues = new String[lvalues.length];
/* 1324 */           for (int i = 0; i < lvalues.length; i++) {
/* 1325 */             svalues[i] = Long.toString(lvalues[i]);
/*      */           }
/* 1327 */         } else if (values instanceof float[]) {
/* 1328 */           float[] fvalues = (float[])values;
/* 1329 */           svalues = new String[fvalues.length];
/* 1330 */           for (int i = 0; i < fvalues.length; i++) {
/* 1331 */             svalues[i] = Float.toString(fvalues[i]);
/*      */           }
/* 1333 */         } else if (values instanceof double[]) {
/* 1334 */           double[] dvalues = (double[])values;
/* 1335 */           svalues = new String[dvalues.length];
/* 1336 */           for (int i = 0; i < dvalues.length; i++) {
/* 1337 */             svalues[i] = Double.toString(dvalues[i]);
/*      */           }
/* 1339 */         } else if (values == null) {
/* 1340 */           svalues = new String[0];
/*      */         } else {
/* 1342 */           throw new Exception();
/*      */         } 
/* 1344 */       } catch (Exception e) {
/* 1345 */         String msg = "Parameter cannot convert " + getTypeString(values) + " to String.";
/*      */         
/* 1347 */         throw new ParameterConvertException(msg);
/*      */       } 
/*      */     } 
/* 1350 */     return svalues;
/*      */   }
/*      */   
/*      */   private String getTypeString() {
/* 1354 */     return getTypeString(this._values);
/*      */   }
/*      */   
/*      */   private static String getTypeString(Object values) {
/* 1358 */     if (values instanceof boolean[])
/* 1359 */       return "boolean"; 
/* 1360 */     if (values instanceof int[])
/* 1361 */       return "int"; 
/* 1362 */     if (values instanceof long[])
/* 1363 */       return "long"; 
/* 1364 */     if (values instanceof float[])
/* 1365 */       return "float"; 
/* 1366 */     if (values instanceof double[])
/* 1367 */       return "double"; 
/* 1368 */     if (values instanceof String[]) {
/* 1369 */       return "string";
/*      */     }
/* 1371 */     return "null";
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Parameter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */