/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Conv;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  27 */     TestSuite suite = new TestSuite(ConvTest.class);
/*  28 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1Random() {
/*  32 */     int ntest = 1000;
/*  33 */     int kmin = -2;
/*  34 */     int kmax = 2;
/*  35 */     int lmin = 1;
/*  36 */     int lmax = 8;
/*  37 */     for (int itest = 0; itest < ntest; itest++) {
/*  38 */       int lx = lmin + this._random.nextInt(1 + lmax - lmin);
/*  39 */       int ly = lmin + this._random.nextInt(1 + lmax - lmin);
/*  40 */       int lz = lmin + this._random.nextInt(1 + lmax - lmin);
/*  41 */       int kx = kmin + this._random.nextInt(1 + kmax - kmin);
/*  42 */       int ky = kmin + this._random.nextInt(1 + kmax - kmin);
/*  43 */       int kz = kmin + this._random.nextInt(1 + kmax - kmin);
/*  44 */       float[] x = Array.randfloat(lx);
/*  45 */       float[] y = Array.randfloat(ly);
/*  46 */       float[] zs = Array.zerofloat(lz);
/*  47 */       float[] zf = Array.zerofloat(lz);
/*     */       
/*  49 */       convSimple(lx, kx, x, ly, ky, y, lz, kz, zs);
/*  50 */       Conv.conv(lx, kx, x, ly, ky, y, lz, kz, zf);
/*  51 */       assertEquals(zs, zf);
/*     */       
/*  53 */       xcorSimple(lx, kx, x, ly, ky, y, lz, kz, zs);
/*  54 */       Conv.xcor(lx, kx, x, ly, ky, y, lz, kz, zf);
/*  55 */       assertEquals(zs, zf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test2Random() {
/*  60 */     int ntest = 1000;
/*  61 */     int kmin = -2;
/*  62 */     int kmax = 2;
/*  63 */     int lmin = 1;
/*  64 */     int lmax = 8;
/*  65 */     for (int itest = 0; itest < ntest; itest++) {
/*  66 */       int lx1 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  67 */       int lx2 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  68 */       int ly1 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  69 */       int ly2 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  70 */       int lz1 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  71 */       int lz2 = lmin + this._random.nextInt(1 + lmax - lmin);
/*  72 */       int kx1 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  73 */       int kx2 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  74 */       int ky1 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  75 */       int ky2 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  76 */       int kz1 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  77 */       int kz2 = kmin + this._random.nextInt(1 + kmax - kmin);
/*  78 */       float[][] x = Array.randfloat(lx1, lx2);
/*  79 */       float[][] y = Array.randfloat(ly1, ly2);
/*  80 */       float[][] zs = Array.zerofloat(lz1, lz2);
/*  81 */       float[][] zf = Array.zerofloat(lz1, lz2);
/*     */       
/*  83 */       convSimple(lx1, lx2, kx1, kx2, x, ly1, ly2, ky1, ky2, y, lz1, lz2, kz1, kz2, zs);
/*  84 */       Conv.conv(lx1, lx2, kx1, kx2, x, ly1, ly2, ky1, ky2, y, lz1, lz2, kz1, kz2, zf);
/*  85 */       assertEquals(zs, zf);
/*     */       
/*  87 */       xcorSimple(lx1, lx2, kx1, kx2, x, ly1, ly2, ky1, ky2, y, lz1, lz2, kz1, kz2, zs);
/*  88 */       Conv.xcor(lx1, lx2, kx1, kx2, x, ly1, ly2, ky1, ky2, y, lz1, lz2, kz1, kz2, zf);
/*  89 */       assertEquals(zs, zf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void test3Random() {
/*  94 */     int ntest = 100;
/*  95 */     int kmin = -2;
/*  96 */     int kmax = 2;
/*  97 */     int lmin = 1;
/*  98 */     int lmax = 8;
/*  99 */     for (int itest = 0; itest < ntest; itest++) {
/* 100 */       int lx1 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 101 */       int lx2 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 102 */       int lx3 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 103 */       int ly1 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 104 */       int ly2 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 105 */       int ly3 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 106 */       int lz1 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 107 */       int lz2 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 108 */       int lz3 = lmin + this._random.nextInt(1 + lmax - lmin);
/* 109 */       int kx1 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 110 */       int kx2 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 111 */       int kx3 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 112 */       int ky1 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 113 */       int ky2 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 114 */       int ky3 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 115 */       int kz1 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 116 */       int kz2 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 117 */       int kz3 = kmin + this._random.nextInt(1 + kmax - kmin);
/* 118 */       float[][][] x = Array.randfloat(lx1, lx2, lx3);
/* 119 */       float[][][] y = Array.randfloat(ly1, ly2, ly3);
/* 120 */       float[][][] zs = Array.zerofloat(lz1, lz2, lz3);
/* 121 */       float[][][] zf = Array.zerofloat(lz1, lz2, lz3);
/*     */       
/* 123 */       convSimple(lx1, lx2, lx3, kx1, kx2, kx3, x, ly1, ly2, ly3, ky1, ky2, ky3, y, lz1, lz2, lz3, kz1, kz2, kz3, zs);
/*     */ 
/*     */       
/* 126 */       Conv.conv(lx1, lx2, lx3, kx1, kx2, kx3, x, ly1, ly2, ly3, ky1, ky2, ky3, y, lz1, lz2, lz3, kz1, kz2, kz3, zf);
/*     */ 
/*     */       
/* 129 */       assertEquals(zs, zf);
/*     */       
/* 131 */       xcorSimple(lx1, lx2, lx3, kx1, kx2, kx3, x, ly1, ly2, ly3, ky1, ky2, ky3, y, lz1, lz2, lz3, kz1, kz2, kz3, zs);
/*     */ 
/*     */       
/* 134 */       Conv.xcor(lx1, lx2, lx3, kx1, kx2, kx3, x, ly1, ly2, ly3, ky1, ky2, ky3, y, lz1, lz2, lz3, kz1, kz2, kz3, zf);
/*     */ 
/*     */       
/* 137 */       assertEquals(zs, zf);
/*     */     } 
/*     */   }
/*     */   
/* 141 */   private Random _random = new Random();
/*     */ 
/*     */   
/*     */   private static final float TOLERANCE = 1.1920929E-4F;
/*     */ 
/*     */   
/*     */   private static void convSimple(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/* 148 */     int ilo = kz - kx - ky;
/* 149 */     int ihi = ilo + lz - 1;
/* 150 */     for (int i = ilo; i <= ihi; i++) {
/* 151 */       int jlo = MathPlus.max(0, i - ly + 1);
/* 152 */       int jhi = MathPlus.min(lx - 1, i);
/* 153 */       float sum = 0.0F;
/* 154 */       for (int j = jlo; j <= jhi; j++)
/* 155 */         sum += x[j] * y[i - j]; 
/* 156 */       z[i - ilo] = sum;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void xcorSimple(int lx, int kx, float[] x, int ly, int ky, float[] y, int lz, int kz, float[] z) {
/* 165 */     int ilo = kz + kx - ky;
/* 166 */     int ihi = ilo + lz - 1;
/* 167 */     for (int i = ilo; i <= ihi; i++) {
/* 168 */       int jlo = MathPlus.max(0, -i);
/* 169 */       int jhi = MathPlus.min(lx - 1, ly - 1 - i);
/* 170 */       float sum = 0.0F;
/* 171 */       for (int j = jlo; j <= jhi; j++)
/* 172 */         sum += x[j] * y[i + j]; 
/* 173 */       z[i - ilo] = sum;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convSimple(int lx1, int lx2, int kx1, int kx2, float[][] x, int ly1, int ly2, int ky1, int ky2, float[][] y, int lz1, int lz2, int kz1, int kz2, float[][] z) {
/* 182 */     int ilo1 = kz1 - kx1 - ky1;
/* 183 */     int ihi1 = ilo1 + lz1 - 1;
/* 184 */     int ilo2 = kz2 - kx2 - ky2;
/* 185 */     int ihi2 = ilo2 + lz2 - 1;
/* 186 */     for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 187 */       for (int i1 = ilo1; i1 <= ihi1; i1++) {
/* 188 */         int jlo1 = MathPlus.max(0, i1 - ly1 + 1);
/* 189 */         int jhi1 = MathPlus.min(lx1 - 1, i1);
/* 190 */         int jlo2 = MathPlus.max(0, i2 - ly2 + 1);
/* 191 */         int jhi2 = MathPlus.min(lx2 - 1, i2);
/* 192 */         float sum = 0.0F;
/* 193 */         for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 194 */           for (int j1 = jlo1; j1 <= jhi1; j1++) {
/* 195 */             sum += x[j2][j1] * y[i2 - j2][i1 - j1];
/*     */           }
/*     */         } 
/* 198 */         z[i2 - ilo2][i1 - ilo1] = sum;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void xcorSimple(int lx1, int lx2, int kx1, int kx2, float[][] x, int ly1, int ly2, int ky1, int ky2, float[][] y, int lz1, int lz2, int kz1, int kz2, float[][] z) {
/* 208 */     int ilo1 = kz1 + kx1 - ky1;
/* 209 */     int ihi1 = ilo1 + lz1 - 1;
/* 210 */     int ilo2 = kz2 + kx2 - ky2;
/* 211 */     int ihi2 = ilo2 + lz2 - 1;
/* 212 */     for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 213 */       for (int i1 = ilo1; i1 <= ihi1; i1++) {
/* 214 */         int jlo1 = MathPlus.max(0, -i1);
/* 215 */         int jhi1 = MathPlus.min(lx1 - 1, ly1 - 1 - i1);
/* 216 */         int jlo2 = MathPlus.max(0, -i2);
/* 217 */         int jhi2 = MathPlus.min(lx2 - 1, ly2 - 1 - i2);
/* 218 */         float sum = 0.0F;
/* 219 */         for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 220 */           for (int j1 = jlo1; j1 <= jhi1; j1++) {
/* 221 */             sum += x[j2][j1] * y[i2 + j2][i1 + j1];
/*     */           }
/*     */         } 
/* 224 */         z[i2 - ilo2][i1 - ilo1] = sum;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convSimple(int lx1, int lx2, int lx3, int kx1, int kx2, int kx3, float[][][] x, int ly1, int ly2, int ly3, int ky1, int ky2, int ky3, float[][][] y, int lz1, int lz2, int lz3, int kz1, int kz2, int kz3, float[][][] z) {
/* 234 */     int ilo1 = kz1 - kx1 - ky1;
/* 235 */     int ilo2 = kz2 - kx2 - ky2;
/* 236 */     int ilo3 = kz3 - kx3 - ky3;
/* 237 */     int ihi1 = ilo1 + lz1 - 1;
/* 238 */     int ihi2 = ilo2 + lz2 - 1;
/* 239 */     int ihi3 = ilo3 + lz3 - 1;
/* 240 */     for (int i3 = ilo3; i3 <= ihi3; i3++) {
/* 241 */       for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 242 */         for (int i1 = ilo1; i1 <= ihi1; i1++) {
/* 243 */           int jlo1 = MathPlus.max(0, i1 - ly1 + 1);
/* 244 */           int jlo2 = MathPlus.max(0, i2 - ly2 + 1);
/* 245 */           int jlo3 = MathPlus.max(0, i3 - ly3 + 1);
/* 246 */           int jhi1 = MathPlus.min(lx1 - 1, i1);
/* 247 */           int jhi2 = MathPlus.min(lx2 - 1, i2);
/* 248 */           int jhi3 = MathPlus.min(lx3 - 1, i3);
/* 249 */           float sum = 0.0F;
/* 250 */           for (int j3 = jlo3; j3 <= jhi3; j3++) {
/* 251 */             for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 252 */               for (int j1 = jlo1; j1 <= jhi1; j1++) {
/* 253 */                 sum += x[j3][j2][j1] * y[i3 - j3][i2 - j2][i1 - j1];
/*     */               }
/*     */             } 
/*     */           } 
/* 257 */           z[i3 - ilo3][i2 - ilo2][i1 - ilo1] = sum;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void xcorSimple(int lx1, int lx2, int lx3, int kx1, int kx2, int kx3, float[][][] x, int ly1, int ly2, int ly3, int ky1, int ky2, int ky3, float[][][] y, int lz1, int lz2, int lz3, int kz1, int kz2, int kz3, float[][][] z) {
/* 268 */     int ilo1 = kz1 + kx1 - ky1;
/* 269 */     int ilo2 = kz2 + kx2 - ky2;
/* 270 */     int ilo3 = kz3 + kx3 - ky3;
/* 271 */     int ihi1 = ilo1 + lz1 - 1;
/* 272 */     int ihi2 = ilo2 + lz2 - 1;
/* 273 */     int ihi3 = ilo3 + lz3 - 1;
/* 274 */     for (int i3 = ilo3; i3 <= ihi3; i3++) {
/* 275 */       for (int i2 = ilo2; i2 <= ihi2; i2++) {
/* 276 */         for (int i1 = ilo1; i1 <= ihi1; i1++) {
/* 277 */           int jlo1 = MathPlus.max(0, -i1);
/* 278 */           int jlo2 = MathPlus.max(0, -i2);
/* 279 */           int jlo3 = MathPlus.max(0, -i3);
/* 280 */           int jhi1 = MathPlus.min(lx1 - 1, ly1 - 1 - i1);
/* 281 */           int jhi2 = MathPlus.min(lx2 - 1, ly2 - 1 - i2);
/* 282 */           int jhi3 = MathPlus.min(lx3 - 1, ly3 - 1 - i3);
/* 283 */           float sum = 0.0F;
/* 284 */           for (int j3 = jlo3; j3 <= jhi3; j3++) {
/* 285 */             for (int j2 = jlo2; j2 <= jhi2; j2++) {
/* 286 */               for (int j1 = jlo1; j1 <= jhi1; j1++) {
/* 287 */                 sum += x[j3][j2][j1] * y[i3 + j3][i2 + j2][i1 + j1];
/*     */               }
/*     */             } 
/*     */           } 
/* 291 */           z[i3 - ilo3][i2 - ilo2][i1 - ilo1] = sum;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void assertEquals(float[] a, float[] b) {
/* 299 */     int n = a.length;
/* 300 */     for (int i = 0; i < n; i++)
/* 301 */       assertEquals(a[i], b[i], 1.1920929E-4F); 
/*     */   }
/*     */   
/*     */   private static void assertEquals(float[][] a, float[][] b) {
/* 305 */     int n = a.length;
/* 306 */     for (int i = 0; i < n; i++)
/* 307 */       assertEquals(a[i], b[i]); 
/*     */   }
/*     */   
/*     */   private static void assertEquals(float[][][] a, float[][][] b) {
/* 311 */     int n = a.length;
/* 312 */     for (int i = 0; i < n; i++)
/* 313 */       assertEquals(a[i], b[i]); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/ConvTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */