/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Cdouble;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecursiveCascadeFilter
/*     */ {
/*     */   private int _n1;
/*     */   private Recursive2ndOrderFilter[] _f1;
/*     */   
/*     */   public RecursiveCascadeFilter(Cdouble[] poles, Cdouble[] zeros, double gain) {
/*  43 */     init(poles, zeros, gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForward(float[] x, float[] y) {
/*  54 */     this._f1[0].applyForward(x, y);
/*  55 */     for (int i1 = 1; i1 < this._n1; i1++) {
/*  56 */       this._f1[i1].applyForward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyReverse(float[] x, float[] y) {
/*  67 */     this._f1[0].applyReverse(x, y);
/*  68 */     for (int i1 = 1; i1 < this._n1; i1++) {
/*  69 */       this._f1[i1].applyReverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyForwardReverse(float[] x, float[] y) {
/*  80 */     this._f1[0].applyForward(x, y);
/*  81 */     this._f1[0].applyReverse(y, y);
/*  82 */     for (int i1 = 1; i1 < this._n1; i1++) {
/*  83 */       this._f1[i1].applyForward(y, y);
/*  84 */       this._f1[i1].applyReverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Forward(float[][] x, float[][] y) {
/*  96 */     this._f1[0].apply1Forward(x, y);
/*  97 */     for (int i1 = 1; i1 < this._n1; i1++) {
/*  98 */       this._f1[i1].apply1Forward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Reverse(float[][] x, float[][] y) {
/* 109 */     this._f1[0].apply1Reverse(x, y);
/* 110 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 111 */       this._f1[i1].apply1Reverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1ForwardReverse(float[][] x, float[][] y) {
/* 123 */     this._f1[0].apply1Forward(x, y);
/* 124 */     this._f1[0].apply1Reverse(y, y);
/* 125 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 126 */       this._f1[i1].apply1Forward(y, y);
/* 127 */       this._f1[i1].apply1Reverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Forward(float[][] x, float[][] y) {
/* 139 */     this._f1[0].apply2Forward(x, y);
/* 140 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 141 */       this._f1[i1].apply2Forward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Reverse(float[][] x, float[][] y) {
/* 152 */     this._f1[0].apply2Reverse(x, y);
/* 153 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 154 */       this._f1[i1].apply2Reverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2ForwardReverse(float[][] x, float[][] y) {
/* 166 */     this._f1[0].apply2Forward(x, y);
/* 167 */     this._f1[0].apply2Reverse(y, y);
/* 168 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 169 */       this._f1[i1].apply2Forward(y, y);
/* 170 */       this._f1[i1].apply2Reverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Forward(float[][][] x, float[][][] y) {
/* 182 */     this._f1[0].apply1Forward(x, y);
/* 183 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 184 */       this._f1[i1].apply1Forward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1Reverse(float[][][] x, float[][][] y) {
/* 195 */     this._f1[0].apply1Reverse(x, y);
/* 196 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 197 */       this._f1[i1].apply1Reverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply1ForwardReverse(float[][][] x, float[][][] y) {
/* 209 */     this._f1[0].apply1Forward(x, y);
/* 210 */     this._f1[0].apply1Reverse(y, y);
/* 211 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 212 */       this._f1[i1].apply1Forward(y, y);
/* 213 */       this._f1[i1].apply1Reverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Forward(float[][][] x, float[][][] y) {
/* 225 */     this._f1[0].apply2Forward(x, y);
/* 226 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 227 */       this._f1[i1].apply2Forward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2Reverse(float[][][] x, float[][][] y) {
/* 238 */     this._f1[0].apply2Reverse(x, y);
/* 239 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 240 */       this._f1[i1].apply2Reverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply2ForwardReverse(float[][][] x, float[][][] y) {
/* 252 */     this._f1[0].apply2Forward(x, y);
/* 253 */     this._f1[0].apply2Reverse(y, y);
/* 254 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 255 */       this._f1[i1].apply2Forward(y, y);
/* 256 */       this._f1[i1].apply2Reverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3Forward(float[][][] x, float[][][] y) {
/* 268 */     this._f1[0].apply3Forward(x, y);
/* 269 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 270 */       this._f1[i1].apply3Forward(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3Reverse(float[][][] x, float[][][] y) {
/* 281 */     this._f1[0].apply3Reverse(x, y);
/* 282 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 283 */       this._f1[i1].apply3Reverse(y, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply3ForwardReverse(float[][][] x, float[][][] y) {
/* 295 */     this._f1[0].apply3Forward(x, y);
/* 296 */     this._f1[0].apply3Reverse(y, y);
/* 297 */     for (int i1 = 1; i1 < this._n1; i1++) {
/* 298 */       this._f1[i1].apply3Forward(y, y);
/* 299 */       this._f1[i1].apply3Reverse(y, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected RecursiveCascadeFilter() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(Cdouble[] poles, Cdouble[] zeros, double gain) {
/* 310 */     Check.argument((poles.length > 0 || zeros.length > 0), "at least one pole or zero is specified");
/*     */ 
/*     */ 
/*     */     
/* 314 */     poles = sortPolesOrZeros(poles);
/* 315 */     zeros = sortPolesOrZeros(zeros);
/*     */ 
/*     */     
/* 318 */     int np = poles.length;
/* 319 */     int nz = zeros.length;
/* 320 */     this._n1 = MathPlus.max((np + 1) / 2, (nz + 1) / 2);
/* 321 */     this._f1 = new Recursive2ndOrderFilter[this._n1];
/* 322 */     gain = MathPlus.pow(gain, 1.0D / this._n1);
/* 323 */     Cdouble c0 = new Cdouble(0.0D, 0.0D);
/* 324 */     for (int i1 = 0, ip = 0, iz = 0; i1 < this._n1; i1++) {
/* 325 */       Cdouble pole1 = (ip < np) ? poles[ip++] : c0;
/* 326 */       Cdouble pole2 = (ip < np) ? poles[ip++] : c0;
/* 327 */       Cdouble zero1 = (iz < nz) ? zeros[iz++] : c0;
/* 328 */       Cdouble zero2 = (iz < nz) ? zeros[iz++] : c0;
/* 329 */       this._f1[i1] = new Recursive2ndOrderFilter(pole1, pole2, zero1, zero2, gain);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Cdouble[] sortPolesOrZeros(Cdouble[] c) {
/* 346 */     c = (Cdouble[])c.clone();
/* 347 */     int n = c.length;
/* 348 */     Cdouble[] cs = new Cdouble[n];
/* 349 */     int ns = 0; int i;
/* 350 */     for (i = 0; i < n; i++) {
/* 351 */       if (c[i] != null && !c[i].isReal()) {
/* 352 */         Cdouble cc = c[i].conj();
/*     */         int j;
/* 354 */         for (j = i + 1; j < n && !cc.equals(c[j]); j++);
/*     */         
/* 356 */         Check.argument((j < n), "complex " + c[i] + " has a conjugate mate");
/* 357 */         cs[ns++] = c[i];
/* 358 */         cs[ns++] = c[j];
/* 359 */         c[i] = null;
/* 360 */         c[j] = null;
/*     */       } 
/*     */     } 
/* 363 */     for (i = 0; i < n; i++) {
/* 364 */       if (c[i] != null && c[i].isReal())
/* 365 */         cs[ns++] = c[i]; 
/*     */     } 
/* 367 */     return cs;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/RecursiveCascadeFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */