/*    */ package edu.mines.jtk.lapack.test;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Suite
/*    */   extends TestSuite
/*    */ {
/*    */   public static Test suite() {
/* 20 */     TestSuite suite = new TestSuite();
/*    */     
/* 22 */     suite.addTestSuite(DMatrixTest.class);
/* 23 */     suite.addTestSuite(DMatrixChdTest.class);
/* 24 */     suite.addTestSuite(DMatrixEvdTest.class);
/* 25 */     suite.addTestSuite(DMatrixLudTest.class);
/* 26 */     suite.addTestSuite(DMatrixQrdTest.class);
/* 27 */     suite.addTestSuite(DMatrixSvdTest.class);
/*    */     
/* 29 */     return (Test)suite;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 33 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/test/Suite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */