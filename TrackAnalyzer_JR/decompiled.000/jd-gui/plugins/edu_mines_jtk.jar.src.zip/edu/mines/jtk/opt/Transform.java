package edu.mines.jtk.opt;

public interface Transform {
  void forwardNonlinear(Vect paramVect, VectConst paramVectConst);
  
  void forwardLinearized(Vect paramVect, VectConst paramVectConst1, VectConst paramVectConst2);
  
  void addTranspose(VectConst paramVectConst1, Vect paramVect, VectConst paramVectConst2);
  
  void inverseHessian(Vect paramVect, VectConst paramVectConst);
  
  void adjustRobustErrors(Vect paramVect);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/Transform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */