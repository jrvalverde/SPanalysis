/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Suite
/*    */   extends TestSuite
/*    */ {
/*    */   public static Test suite() {
/* 22 */     TestSuite suite = new TestSuite();
/*    */     
/* 24 */     suite.addTestSuite(ArrayVect1fsTest.class);
/* 25 */     suite.addTestSuite(ArrayVect1fTest.class);
/* 26 */     suite.addTestSuite(ArrayVect1Test.class);
/* 27 */     suite.addTestSuite(ArrayVect2fTest.class);
/* 28 */     suite.addTestSuite(ArrayVect2Test.class);
/* 29 */     suite.addTestSuite(ArrayVect3fTest.class);
/* 30 */     suite.addTestSuite(BrentMinFinderTest.class);
/* 31 */     suite.addTestSuite(BrentZeroFinderTest.class);
/* 32 */     suite.addTestSuite(CoordinateTransformTest.class);
/* 33 */     suite.addTestSuite(GaussNewtonSolverTest.class);
/* 34 */     suite.addTestSuite(LineSearchTest.class);
/* 35 */     suite.addTestSuite(QuadraticSolverTest.class);
/* 36 */     suite.addTestSuite(ScalarSolverTest.class);
/* 37 */     suite.addTestSuite(ScalarVectTest.class);
/* 38 */     suite.addTestSuite(VectArrayTest.class);
/* 39 */     suite.addTestSuite(VectMapTest.class);
/* 40 */     return (Test)suite;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 47 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/Suite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */