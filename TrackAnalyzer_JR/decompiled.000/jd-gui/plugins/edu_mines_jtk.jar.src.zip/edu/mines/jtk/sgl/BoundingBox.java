/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingBox
/*     */ {
/*     */   private double _xmin;
/*     */   private double _ymin;
/*     */   private double _zmin;
/*     */   private double _xmax;
/*     */   private double _ymax;
/*     */   private double _zmax;
/*     */   
/*     */   public BoundingBox() {
/*  33 */     setEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(Point3 p) {
/*  41 */     this._xmin = this._xmax = p.x;
/*  42 */     this._ymin = this._ymax = p.y;
/*  43 */     this._zmin = this._zmax = p.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(Point3 p, Point3 q) {
/*  53 */     this._xmin = Math.min(p.x, q.x);
/*  54 */     this._ymin = Math.min(p.y, q.y);
/*  55 */     this._zmin = Math.min(p.z, q.z);
/*  56 */     this._xmax = Math.max(p.x, q.x);
/*  57 */     this._ymax = Math.max(p.y, q.y);
/*  58 */     this._zmax = Math.max(p.z, q.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(double xmin, double ymin, double zmin, double xmax, double ymax, double zmax) {
/*  74 */     Check.argument((xmin <= xmax), "xmin<=xmax");
/*  75 */     Check.argument((ymin <= ymax), "ymin<=ymax");
/*  76 */     Check.argument((zmin <= zmax), "zmin<=zmax");
/*  77 */     this._xmin = xmin;
/*  78 */     this._ymin = ymin;
/*  79 */     this._zmin = zmin;
/*  80 */     this._xmax = xmax;
/*  81 */     this._ymax = ymax;
/*  82 */     this._zmax = zmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(float[] xyz) {
/*  94 */     this();
/*  95 */     expandBy(xyz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(float[] x, float[] y, float[] z) {
/* 105 */     this();
/* 106 */     expandBy(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox(BoundingBox bb) {
/* 114 */     this._xmin = bb._xmin;
/* 115 */     this._ymin = bb._ymin;
/* 116 */     this._zmin = bb._zmin;
/* 117 */     this._xmax = bb._xmax;
/* 118 */     this._ymax = bb._ymax;
/* 119 */     this._zmax = bb._zmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 127 */     return (this._xmin > this._xmax || this._ymin > this._ymax || this._zmin > this._zmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfinite() {
/* 135 */     return (this._xmin == Double.NEGATIVE_INFINITY && this._ymin == Double.NEGATIVE_INFINITY && this._zmin == Double.NEGATIVE_INFINITY && this._xmax == Double.POSITIVE_INFINITY && this._ymax == Double.POSITIVE_INFINITY && this._zmax == Double.POSITIVE_INFINITY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getMin() {
/* 148 */     Check.state(!isEmpty(), "bounding box is not empty");
/* 149 */     return new Point3(this._xmin, this._ymin, this._zmin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getMax() {
/* 157 */     Check.state(!isEmpty(), "bounding box is not empty");
/* 158 */     return new Point3(this._xmax, this._ymax, this._zmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getCenter() {
/* 166 */     Check.state(!isEmpty(), "bounding box is not empty");
/* 167 */     Check.state(!isInfinite(), "bounding box is not infinite");
/* 168 */     return isInfinite() ? new Point3(0.0D, 0.0D, 0.0D) : new Point3(0.5D * (this._xmin + this._xmax), 0.5D * (this._ymin + this._ymax), 0.5D * (this._zmin + this._zmax));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRadius() {
/* 178 */     return Math.sqrt(getRadiusSquared());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRadiusSquared() {
/* 186 */     Check.state(!isEmpty(), "bounding box is not empty");
/* 187 */     double dx = this._xmax - this._xmin;
/* 188 */     double dy = this._ymax - this._ymin;
/* 189 */     double dz = this._zmax - this._zmin;
/* 190 */     return 0.25D * (dx * dx + dy * dy + dz * dz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getCorner(int index) {
/* 203 */     Check.state(!isEmpty(), "bounding box is not empty");
/* 204 */     double x = ((index & 0x1) == 0) ? this._xmin : this._xmax;
/* 205 */     double y = ((index & 0x2) == 0) ? this._ymin : this._ymax;
/* 206 */     double z = ((index & 0x4) == 0) ? this._zmin : this._zmax;
/* 207 */     return new Point3(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(Point3 p) {
/* 215 */     expandBy(p.x, p.y, p.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(double x, double y, double z) {
/* 225 */     if (this._xmin > x) this._xmin = x; 
/* 226 */     if (this._ymin > y) this._ymin = y; 
/* 227 */     if (this._zmin > z) this._zmin = z; 
/* 228 */     if (this._xmax < x) this._xmax = x; 
/* 229 */     if (this._ymax < y) this._ymax = y; 
/* 230 */     if (this._zmax < z) this._zmax = z;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(float[] xyz) {
/* 242 */     int n = xyz.length;
/* 243 */     for (int i = 0; i < n; i += 3) {
/* 244 */       expandBy(xyz[i], xyz[i + 1], xyz[i + 2]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(float[] x, float[] y, float[] z) {
/* 254 */     int n = x.length;
/* 255 */     for (int i = 0; i < n; i++) {
/* 256 */       expandBy(x[i], y[i], z[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(BoundingBox bb) {
/* 264 */     if (this._xmin > bb._xmin) this._xmin = bb._xmin; 
/* 265 */     if (this._ymin > bb._ymin) this._ymin = bb._ymin; 
/* 266 */     if (this._zmin > bb._zmin) this._zmin = bb._zmin; 
/* 267 */     if (this._xmax < bb._xmax) this._xmax = bb._xmax; 
/* 268 */     if (this._ymax < bb._ymax) this._ymax = bb._ymax; 
/* 269 */     if (this._zmax < bb._zmax) this._zmax = bb._zmax;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandBy(BoundingSphere bs) {
/* 277 */     if (!bs.isInfinite()) {
/* 278 */       if (!bs.isEmpty()) {
/* 279 */         double r = bs.getRadius();
/* 280 */         Point3 c = bs.getCenter();
/* 281 */         double x = c.x;
/* 282 */         double y = c.y;
/* 283 */         double z = c.z;
/* 284 */         if (this._xmin > x - r) this._xmin = x - r; 
/* 285 */         if (this._ymin > y - r) this._ymin = y - r; 
/* 286 */         if (this._zmin > z - r) this._zmin = z - r; 
/* 287 */         if (this._xmax < x + r) this._xmax = x + r; 
/* 288 */         if (this._ymax < y + r) this._ymax = y + r; 
/* 289 */         if (this._zmax < z + r) this._zmax = z + r; 
/*     */       } 
/*     */     } else {
/* 292 */       setInfinite();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(double x, double y, double z) {
/* 304 */     return (this._xmin <= x && x <= this._xmax && this._ymin <= y && y <= this._ymax && this._zmin <= z && z <= this._zmax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point3 p) {
/* 315 */     return contains(p.x, p.y, p.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(BoundingBox bb) {
/* 324 */     return (contains(bb._xmin, bb._ymin, bb._zmin) && contains(bb._xmax, bb._ymax, bb._zmax));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(BoundingBox bb) {
/* 334 */     return (Math.max(this._xmin, bb._xmin) <= Math.min(this._xmax, bb._xmax) && Math.max(this._ymin, bb._ymin) <= Math.min(this._ymax, bb._ymax) && Math.max(this._zmin, bb._zmin) <= Math.min(this._zmax, bb._zmax));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BoundingBox empty() {
/* 344 */     return new BoundingBox();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BoundingBox infinite() {
/* 352 */     BoundingBox bb = new BoundingBox();
/* 353 */     bb.setInfinite();
/* 354 */     return bb;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 358 */     return "{" + getMin() + ":" + getMax() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEmpty() {
/* 375 */     this._xmin = Double.POSITIVE_INFINITY;
/* 376 */     this._ymin = Double.POSITIVE_INFINITY;
/* 377 */     this._zmin = Double.POSITIVE_INFINITY;
/* 378 */     this._xmax = Double.NEGATIVE_INFINITY;
/* 379 */     this._ymax = Double.NEGATIVE_INFINITY;
/* 380 */     this._zmax = Double.NEGATIVE_INFINITY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInfinite() {
/* 387 */     this._xmin = Double.NEGATIVE_INFINITY;
/* 388 */     this._ymin = Double.NEGATIVE_INFINITY;
/* 389 */     this._zmin = Double.NEGATIVE_INFINITY;
/* 390 */     this._xmax = Double.POSITIVE_INFINITY;
/* 391 */     this._ymax = Double.POSITIVE_INFINITY;
/* 392 */     this._zmax = Double.POSITIVE_INFINITY;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/BoundingBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */