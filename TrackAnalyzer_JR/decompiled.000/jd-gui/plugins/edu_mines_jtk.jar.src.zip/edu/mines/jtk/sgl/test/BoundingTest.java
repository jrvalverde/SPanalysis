/*     */ package edu.mines.jtk.sgl.test;
/*     */ 
/*     */ import edu.mines.jtk.sgl.BoundingBox;
/*     */ import edu.mines.jtk.sgl.BoundingSphere;
/*     */ import edu.mines.jtk.sgl.Point3;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  25 */     TestSuite suite = new TestSuite(BoundingTest.class);
/*  26 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testBox() {
/*  30 */     BoundingBox bb = new BoundingBox();
/*  31 */     bb.expandBy(0.0D, 0.0D, 0.0D);
/*  32 */     bb.expandBy(1.0D, 1.0D, 1.0D);
/*  33 */     double a = 2.220446049250313E-15D;
/*  34 */     double b = 1.0D - a;
/*  35 */     assertTrue(bb.contains(new Point3(a, a, a)));
/*  36 */     assertTrue(bb.contains(new Point3(a, a, b)));
/*  37 */     assertTrue(bb.contains(new Point3(a, b, a)));
/*  38 */     assertTrue(bb.contains(new Point3(a, b, b)));
/*  39 */     assertTrue(bb.contains(new Point3(b, a, a)));
/*  40 */     assertTrue(bb.contains(new Point3(b, a, b)));
/*  41 */     assertTrue(bb.contains(new Point3(b, b, a)));
/*  42 */     assertTrue(bb.contains(new Point3(b, b, b)));
/*  43 */     a = -2.220446049250313E-15D;
/*  44 */     b = 1.0D - a;
/*  45 */     assertTrue(!bb.contains(new Point3(a, a, a)));
/*  46 */     assertTrue(!bb.contains(new Point3(a, a, b)));
/*  47 */     assertTrue(!bb.contains(new Point3(a, b, a)));
/*  48 */     assertTrue(!bb.contains(new Point3(a, b, b)));
/*  49 */     assertTrue(!bb.contains(new Point3(b, a, a)));
/*  50 */     assertTrue(!bb.contains(new Point3(b, a, b)));
/*  51 */     assertTrue(!bb.contains(new Point3(b, b, a)));
/*  52 */     assertTrue(!bb.contains(new Point3(b, b, b)));
/*     */   }
/*     */   
/*     */   public void testBoxExpand() {
/*  56 */     int ntrial = 100;
/*  57 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/*  58 */       BoundingBox bb = new BoundingBox();
/*  59 */       assertTrue(bb.isEmpty());
/*  60 */       int nexpand = 100;
/*  61 */       for (int iexpand = 0; iexpand < nexpand; iexpand++) {
/*  62 */         Point3 c = randomPoint3();
/*  63 */         double r = randomDouble();
/*  64 */         BoundingSphere bs = new BoundingSphere(c, r);
/*  65 */         bb.expandBy(bs);
/*  66 */         assertTrue(!bb.isEmpty());
/*  67 */         int npoint = 100;
/*  68 */         for (int ipoint = 0; ipoint < npoint; ipoint++) {
/*  69 */           Point3 p = randomPoint3();
/*  70 */           if (bs.contains(p))
/*  71 */             assertTrue(bb.contains(p)); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testSphere() {
/*  78 */     BoundingSphere bs = new BoundingSphere();
/*  79 */     bs.expandBy(0.0D, 0.0D, 0.0D);
/*  80 */     bs.expandBy(1.0D, 1.0D, 1.0D);
/*  81 */     double a = 2.220446049250313E-15D;
/*  82 */     double b = 1.0D - a;
/*  83 */     assertTrue(bs.contains(new Point3(a, a, a)));
/*  84 */     assertTrue(bs.contains(new Point3(a, a, b)));
/*  85 */     assertTrue(bs.contains(new Point3(a, b, a)));
/*  86 */     assertTrue(bs.contains(new Point3(a, b, b)));
/*  87 */     assertTrue(bs.contains(new Point3(b, a, a)));
/*  88 */     assertTrue(bs.contains(new Point3(b, a, b)));
/*  89 */     assertTrue(bs.contains(new Point3(b, b, a)));
/*  90 */     assertTrue(bs.contains(new Point3(b, b, b)));
/*  91 */     a = -2.220446049250313E-15D;
/*  92 */     b = 1.0D - a;
/*  93 */     assertTrue(!bs.contains(new Point3(a, a, a)));
/*  94 */     assertTrue(!bs.contains(new Point3(a, a, b)));
/*  95 */     assertTrue(!bs.contains(new Point3(a, b, a)));
/*  96 */     assertTrue(!bs.contains(new Point3(a, b, b)));
/*  97 */     assertTrue(!bs.contains(new Point3(b, a, a)));
/*  98 */     assertTrue(!bs.contains(new Point3(b, a, b)));
/*  99 */     assertTrue(!bs.contains(new Point3(b, b, a)));
/* 100 */     assertTrue(!bs.contains(new Point3(b, b, b)));
/*     */   }
/*     */   
/*     */   public void testSphereExpand() {
/* 104 */     int ntrial = 100;
/* 105 */     for (int itrial = 0; itrial < ntrial; itrial++) {
/* 106 */       BoundingSphere bs = new BoundingSphere();
/* 107 */       assertTrue(bs.isEmpty());
/* 108 */       int nexpand = 100;
/* 109 */       for (int iexpand = 0; iexpand < nexpand; iexpand++) {
/* 110 */         Point3 p = randomPoint3();
/* 111 */         Point3 q = randomPoint3();
/* 112 */         BoundingBox bb = new BoundingBox(p, q);
/* 113 */         if (randomDouble() > 0.5D) {
/* 114 */           bs.expandBy(bb);
/*     */         } else {
/* 116 */           bs.expandRadiusBy(bb);
/*     */         } 
/* 118 */         assertTrue(!bs.isEmpty());
/* 119 */         int npoint = 100;
/* 120 */         for (int ipoint = 0; ipoint < npoint; ipoint++) {
/* 121 */           Point3 r = randomPoint3();
/* 122 */           if (bb.contains(r)) {
/* 123 */             assertTrue(bs.contains(r));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 132 */   private static Random _random = new Random(314159L);
/*     */ 
/*     */ 
/*     */   
/*     */   private static double randomDouble() {
/* 137 */     return _random.nextDouble();
/*     */   }
/*     */   
/*     */   private static Point3 randomPoint3() {
/* 141 */     double x = _random.nextDouble();
/* 142 */     double y = _random.nextDouble();
/* 143 */     double z = _random.nextDouble();
/* 144 */     return new Point3(x, y, z);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/BoundingTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */