/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.ArgsParser;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArgsParserTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 21 */     TestSuite suite = new TestSuite(ArgsParserTest.class);
/* 22 */     TestRunner.run((Test)suite);
/*    */   }
/*    */   
/*    */   public void testArgsParser() {
/* 26 */     String[][] args = { { "-a3.14", "-b", "foo" }, { "-a", "3.14", "-b", "foo" }, { "--alpha", "3.14", "--beta", "foo" }, { "--a=3.14", "--b", "foo" } };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 32 */     for (int iarg = 0; iarg < args.length; iarg++) {
/* 33 */       float a = 0.0F;
/* 34 */       boolean b = false;
/*    */       try {
/* 36 */         String shortOpts = "ha:b";
/* 37 */         String[] longOpts = { "help", "alpha=", "beta" };
/* 38 */         ArgsParser ap = new ArgsParser(args[iarg], shortOpts, longOpts);
/* 39 */         String[] opts = ap.getOptions();
/* 40 */         String[] vals = ap.getValues();
/* 41 */         for (int i = 0; i < opts.length; i++) {
/* 42 */           String opt = opts[i];
/* 43 */           String val = vals[i];
/* 44 */           if (opt.equals("-h") || opt.equals("--help")) {
/* 45 */             assertTrue(false);
/* 46 */           } else if (opt.equals("-a") || opt.equals("--alpha")) {
/* 47 */             a = ArgsParser.toFloat(val);
/* 48 */           } else if (opt.equals("-b") || opt.equals("--beta")) {
/* 49 */             b = true;
/*    */           } 
/*    */         } 
/* 52 */         String[] otherArgs = ap.getOtherArgs();
/* 53 */         assertTrue((otherArgs.length == 1));
/* 54 */         assertTrue(otherArgs[0].equals("foo"));
/* 55 */         assertTrue((a == 3.14F));
/* 56 */         assertTrue((b == true));
/* 57 */       } catch (edu.mines.jtk.util.ArgsParser.OptionException e) {
/* 58 */         assertTrue("no exceptions: e=" + e.getMessage(), false);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/ArgsParserTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */