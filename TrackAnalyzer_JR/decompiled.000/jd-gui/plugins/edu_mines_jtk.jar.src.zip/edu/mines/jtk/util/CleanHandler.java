/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public class CleanHandler
/*     */   extends Handler {
/*  19 */   private static List<PrintStream> s_printStreams = new LinkedList<PrintStream>();
/*     */ 
/*     */   
/*     */   private static boolean s_setDefault;
/*     */ 
/*     */ 
/*     */   
/*     */   public CleanHandler() {
/*  27 */     setFormatter(new CleanFormatter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addGlobalLogFile(String fileName) throws FileNotFoundException {
/*  37 */     s_printStreams.add(new PrintStream(new FileOutputStream(fileName), true));
/*     */   }
/*     */ 
/*     */   
/*     */   public void publish(LogRecord record) {
/*  42 */     if (record == null || !isLoggable(record))
/*  43 */       return;  String message = getFormatter().format(record);
/*  44 */     if (message == null)
/*  45 */       return;  if (record.getLevel().intValue() > Level.INFO.intValue()) {
/*  46 */       System.err.print(message);
/*  47 */       System.err.flush();
/*     */     } else {
/*  49 */       System.out.print(message);
/*  50 */       System.out.flush();
/*     */     } 
/*  52 */     for (PrintStream ps : s_printStreams) {
/*  53 */       ps.print(message);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */   
/*     */   public void flush() {}
/*     */   
/*     */   public static void testLogger() {
/*  63 */     setDefaultHandler();
/*     */     
/*  65 */     assert null != CleanHandler.class.getResource("CleanHandler.properties");
/*     */ 
/*     */ 
/*     */     
/*  69 */     assert null != ResourceBundle.getBundle("edu.mines.jtk.util.CleanHandler") : "can't find rb";
/*     */     
/*  71 */     Logger logger = Logger.getLogger("edu.mines.jtk.util", "edu.mines.jtk.util.CleanHandler");
/*     */ 
/*     */     
/*  74 */     logger.severe("test a severe");
/*  75 */     logger.warning("test a warning");
/*  76 */     logger.info("test an info");
/*  77 */     logger.info("test a\\");
/*  78 */     logger.info(" continued info");
/*  79 */     logger.config("test an config");
/*  80 */     logger.fine("test a fine");
/*  81 */     logger.finer("test a finer");
/*  82 */     logger.finest("test a finest");
/*  83 */     logger.info("testmessage");
/*  84 */     logger.info("Try this:>>${testmessage}<<");
/*  85 */     logger.info("Try this:>>${testmessage}<< >>${testmessage}<<");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  91 */     testLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultHandler() {
/*  99 */     synchronized (CleanHandler.class) {
/* 100 */       if (s_setDefault)
/*     */         return; 
/* 102 */       if (System.getProperties().getProperty("java.util.logging.config.file") == null && System.getProperties().getProperty("java.util.logging.config.class") == null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 107 */           LogManager.getLogManager().readConfiguration(new ByteArrayInputStream("handlers=edu.mines.jtk.util.CleanHandler\n.level=INFO\n".getBytes()));
/*     */ 
/*     */         
/*     */         }
/* 111 */         catch (IOException e) {
/* 112 */           e.printStackTrace();
/* 113 */           throw new IllegalStateException("This should never fail " + e.getMessage());
/*     */         } 
/*     */       }
/*     */       
/* 117 */       s_setDefault = true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/CleanHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */