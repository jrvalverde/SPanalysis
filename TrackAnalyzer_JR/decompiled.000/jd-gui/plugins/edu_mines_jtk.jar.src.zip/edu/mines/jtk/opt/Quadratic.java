package edu.mines.jtk.opt;

public interface Quadratic {
  void multiplyHessian(Vect paramVect);
  
  void inverseHessian(Vect paramVect);
  
  Vect getB();
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/Quadratic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */