/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Histogram
/*     */ {
/*     */   private float _vmin;
/*     */   private float _vmax;
/*     */   private boolean _computedMinMax;
/*     */   private Sampling _sbin;
/*     */   private long[] _h;
/*     */   private long _nin;
/*     */   private long _nlo;
/*     */   private long _nhi;
/*     */   
/*     */   public Histogram(float[] v) {
/*  52 */     initMinMax(v);
/*  53 */     init(v, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Histogram(float[] v, int nbin) {
/*  63 */     initMinMax(v);
/*  64 */     init(v, nbin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Histogram(float[] v, float vmin, float vmax) {
/*  76 */     Check.argument((vmin <= vmax), "vmin<=vmax");
/*  77 */     initMinMax(vmin, vmax);
/*  78 */     init(v, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Histogram(float[] v, float vmin, float vmax, int nbin) {
/*  90 */     Check.argument((vmin <= vmax), "vmin<=vmax");
/*  91 */     initMinMax(vmin, vmax);
/*  92 */     init(v, nbin);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinValue() {
/* 100 */     return this._vmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxValue() {
/* 108 */     return this._vmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBinCount() {
/* 116 */     return this._sbin.getCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBinDelta() {
/* 124 */     return this._sbin.getDelta();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBinFirst() {
/* 132 */     return this._sbin.getFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sampling getBinSampling() {
/* 141 */     return this._sbin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long[] getCounts() {
/* 149 */     return Array.copy(this._h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getDensities() {
/* 158 */     int nbin = getBinCount();
/* 159 */     float[] d = new float[nbin];
/* 160 */     double s = 1.0D / this._nin;
/* 161 */     for (int ibin = 0; ibin < nbin; ibin++)
/* 162 */       d[ibin] = (float)(s * this._h[ibin]); 
/* 163 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getInCount() {
/* 171 */     return this._nin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLowCount() {
/* 179 */     return this._nlo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getHighCount() {
/* 187 */     return this._nhi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initMinMax(float[] v) {
/* 203 */     int n = v.length;
/* 204 */     this._vmin = this._vmax = v[0];
/* 205 */     for (int i = 1; i < n; i++) {
/* 206 */       float vi = v[i];
/* 207 */       if (vi < this._vmin)
/* 208 */         this._vmin = vi; 
/* 209 */       if (vi > this._vmax)
/* 210 */         this._vmax = vi; 
/*     */     } 
/* 212 */     this._computedMinMax = true;
/*     */   }
/*     */   
/*     */   private void initMinMax(float vmin, float vmax) {
/* 216 */     this._vmin = vmin;
/* 217 */     this._vmax = vmax;
/* 218 */     this._computedMinMax = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float[] trim(float[] v) {
/*     */     float[] t;
/* 227 */     if (this._computedMinMax) {
/* 228 */       t = Array.copy(v);
/*     */     } else {
/* 230 */       int n = v.length;
/* 231 */       t = new float[n];
/* 232 */       int m = 0;
/* 233 */       for (int i = 0; i < n; i++) {
/* 234 */         float vi = v[i];
/* 235 */         if (this._vmin <= vi && vi <= this._vmax)
/* 236 */           t[m++] = vi; 
/*     */       } 
/* 238 */       if (m < n)
/* 239 */         t = Array.copy(m, t); 
/*     */     } 
/* 241 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(float[] v, int nbin) {
/* 251 */     double dbin = ((this._vmax - this._vmin) / MathPlus.max(1, nbin));
/* 252 */     if (dbin == 0.0D) {
/* 253 */       dbin = MathPlus.max(1.0D, 2.0D * MathPlus.abs(this._vmin) * 1.1920928955078125E-7D);
/*     */     }
/*     */     
/* 256 */     if (nbin == 0) {
/*     */ 
/*     */       
/* 259 */       nbin = 1;
/*     */ 
/*     */       
/* 262 */       if (this._vmin < this._vmax) {
/*     */ 
/*     */         
/* 265 */         float[] t = trim(v);
/* 266 */         int j = t.length;
/*     */ 
/*     */         
/* 269 */         if (j > 0) {
/*     */ 
/*     */           
/* 272 */           int k25 = (int)MathPlus.rint(0.25D * (j - 1));
/* 273 */           Array.quickPartialSort(k25, t);
/* 274 */           double v25 = t[k25];
/* 275 */           int k75 = (int)MathPlus.rint(0.75D * (j - 1));
/* 276 */           Array.quickPartialSort(k75, t);
/* 277 */           double v75 = t[k75];
/*     */ 
/*     */           
/* 280 */           if (v25 < v75) {
/* 281 */             dbin = 2.0D * (v75 - v25) * MathPlus.pow(j, -0.3333333333333333D);
/* 282 */             nbin = MathPlus.max(1, (int)MathPlus.floor((this._vmax - this._vmin) / dbin));
/* 283 */             dbin = ((this._vmax - this._vmin) / nbin);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 288 */     double fbin = this._vmin + 0.5D * dbin;
/* 289 */     this._sbin = new Sampling(nbin, dbin, fbin);
/*     */ 
/*     */     
/* 292 */     double vscl = 1.0D / dbin;
/* 293 */     int n = v.length;
/* 294 */     this._nlo = 0L;
/* 295 */     this._nhi = 0L;
/* 296 */     this._h = new long[nbin];
/* 297 */     this._nin = 0L;
/* 298 */     for (int i = 0; i < n; i++) {
/* 299 */       float vi = v[i];
/* 300 */       if (vi < this._vmin) {
/* 301 */         this._nlo++;
/* 302 */       } else if (vi > this._vmax) {
/* 303 */         this._nhi++;
/*     */       } else {
/* 305 */         int ibin = (int)MathPlus.rint((vi - fbin) * vscl);
/* 306 */         if (ibin < 0) {
/* 307 */           ibin = 0;
/* 308 */         } else if (ibin >= nbin) {
/* 309 */           ibin = nbin - 1;
/*     */         } 
/* 311 */         this._h[ibin] = this._h[ibin] + 1L;
/* 312 */         this._nin++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/Histogram.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */