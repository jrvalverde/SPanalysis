/*     */ package edu.mines.jtk.opt;
/*     */ 
/*     */ import edu.mines.jtk.util.Almost;
/*     */ import edu.mines.jtk.util.LoggerStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VectUtil
/*     */ {
/*  20 */   private static final Logger LOG = Logger.getLogger(VectUtil.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scale(Vect v, double scalar) {
/*  28 */     v.add(scalar, 0.0D, v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void zero(Vect v) {
/*  35 */     scale(v, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copy(Vect to, VectConst from) {
/*  44 */     to.add(0.0D, 1.0D, from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vect cloneZero(VectConst v) {
/*  53 */     Vect result = v.clone();
/*  54 */     zero(result);
/*  55 */     return result;
/*     */   }
/*     */   
/*  58 */   static final Almost ALMOST_DOT = new Almost(1.5E-5D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areSame(VectConst v1, VectConst v2) {
/*  67 */     double aa = v1.dot(v1);
/*  68 */     double ab = v1.dot(v2);
/*  69 */     double bb = v2.dot(v2);
/*     */     
/*  71 */     return (ALMOST_DOT.equal(aa, bb) && ALMOST_DOT.equal(aa, ab) && ALMOST_DOT.equal(ab, bb));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void test(VectConst vect) {
/*  83 */     double originalDot = vect.dot(vect);
/*  84 */     ass(!Almost.FLOAT.zero(originalDot), "cannot test a zero vector");
/*     */     
/*  86 */     Vect t = cloneZero(vect);
/*  87 */     ass(Almost.FLOAT.zero(t.dot(t)), "cloneZero() did not work");
/*     */     
/*  89 */     copy(t, vect);
/*  90 */     double check = t.dot(vect) / vect.dot(vect);
/*  91 */     ass(Almost.FLOAT.equal(check, 1.0D), "not 1. check=" + check);
/*     */     
/*  93 */     scale(t, 0.5D);
/*  94 */     check = t.dot(vect) / vect.dot(vect);
/*  95 */     ass(Almost.FLOAT.equal(check, 0.5D), "not 0.5 check=" + check);
/*     */     
/*  97 */     t.add(1.0D, 1.0D, vect);
/*  98 */     check = t.dot(vect) / vect.dot(vect);
/*  99 */     ass(Almost.FLOAT.equal(check, 1.5D), "not 1.5 check=" + check);
/*     */     
/* 101 */     t.add(2.0D, -5.0D, vect);
/* 102 */     check = t.dot(vect) / vect.dot(vect);
/* 103 */     ass(Almost.FLOAT.equal(check, -2.0D), "not -2, check=" + check);
/*     */     
/* 105 */     t.project(0.0D, 1.0D, vect);
/* 106 */     t.project(1.75D, -0.75D, vect);
/* 107 */     ass(areSame(t, vect), "project failed");
/*     */     
/* 109 */     t.dispose();
/* 110 */     ass(Almost.FLOAT.equal(originalDot, vect.dot(vect)), "exercise of clone damaged original");
/*     */ 
/*     */     
/* 113 */     t = vect.clone();
/* 114 */     t.multiplyInverseCovariance();
/* 115 */     double mag1 = vect.dot(t);
/* 116 */     t.dispose();
/* 117 */     double mag2 = vect.magnitude();
/* 118 */     ass(Almost.FLOAT.equal(mag1, mag2), "magnitude() inconsistent with multiplyInverseCovariance() and dot(): " + mag1 + "!=" + mag2);
/*     */ 
/*     */ 
/*     */     
/* 122 */     ass((mag1 > 0.0D), "inverse covariance gave zero magnitude");
/* 123 */     ass((mag2 > 0.0D), "magnitude was zero when dot product was not zero");
/*     */ 
/*     */     
/* 126 */     t = vect.clone();
/* 127 */     t.constrain();
/* 128 */     double mag3 = t.magnitude();
/* 129 */     ass((mag3 > 0.0D), "constrain() gave zero magnitude");
/* 130 */     t.dispose();
/*     */ 
/*     */     
/* 133 */     t = vect.clone();
/* 134 */     t.postCondition();
/* 135 */     t.dispose();
/*     */ 
/*     */     
/* 138 */     String vs = vect.toString();
/* 139 */     assert vs != null && vs.length() > 0;
/*     */ 
/*     */     
/* 142 */     byte[] data = null;
/*     */     try {
/* 144 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 145 */       ObjectOutputStream oos = new ObjectOutputStream(baos);
/* 146 */       t = vect.clone();
/* 147 */       oos.writeObject(t);
/* 148 */       oos.flush();
/* 149 */       oos.close();
/* 150 */       t.dispose();
/* 151 */       t = null;
/* 152 */       data = baos.toByteArray();
/* 153 */     } catch (IOException e) {
/* 154 */       e.printStackTrace((PrintStream)new LoggerStream(LOG, Level.SEVERE));
/* 155 */       ass(false, "writing serialization failed " + e.getMessage());
/*     */     } 
/*     */     try {
/* 158 */       ByteArrayInputStream bais = new ByteArrayInputStream(data);
/* 159 */       ObjectInputStream ois = new ObjectInputStream(bais);
/* 160 */       t = (Vect)ois.readObject();
/* 161 */       ass(areSame(t, vect), "Serialization did not preserve Vect " + t.dot(t) + "==" + t.dot(vect) + "==" + vect.dot(vect));
/*     */ 
/*     */ 
/*     */       
/* 165 */       scale(t, 0.5D);
/* 166 */       double tt = t.dot(t);
/* 167 */       double tv = t.dot(vect);
/* 168 */       double vv = vect.dot(vect);
/* 169 */       ass((tt > 0.0D), "Scaling set serialized vect to zero magnitude");
/* 170 */       ass(Almost.FLOAT.equal(tt * 2.0D, tv), "Serialized vector does not have independent magnitude tt=" + tt + " tv=" + tv);
/*     */ 
/*     */       
/* 173 */       ass(Almost.FLOAT.equal(tv * 2.0D, vv), "serialized vector does not have independent magnitude tv=" + tv + " vv=" + vv);
/*     */ 
/*     */       
/* 176 */       t.dispose();
/* 177 */     } catch (IOException e) {
/* 178 */       e.printStackTrace((PrintStream)new LoggerStream(LOG, Level.SEVERE));
/* 179 */       ass(false, "reading serialization failed " + e.getMessage());
/* 180 */     } catch (ClassNotFoundException e) {
/* 181 */       e.printStackTrace((PrintStream)new LoggerStream(LOG, Level.SEVERE));
/* 182 */       ass(false, "Can't find class just written " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTransposePrecision(VectConst data, VectConst model, Transform transform) {
/* 195 */     int precision = 200;
/* 196 */     boolean dampOnlyPerturbation = true;
/* 197 */     test(data);
/* 198 */     test(model);
/* 199 */     TransformQuadratic tq = new TransformQuadratic(data, model, null, transform, dampOnlyPerturbation);
/*     */     
/* 201 */     precision = Math.min(precision, tq.getTransposePrecision());
/* 202 */     return precision;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void ass(boolean condition, String requirement) {
/* 207 */     if (!condition) throw new IllegalStateException(requirement); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/VectUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */