/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect1;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayVect1Test
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() throws Exception {
/* 24 */     double[] a = new double[31];
/* 25 */     for (int i = 0; i < a.length; ) { a[i] = i; i++; }
/* 26 */      ArrayVect1 arrayVect1 = new ArrayVect1(a, 3.0D);
/* 27 */     VectUtil.test((VectConst)arrayVect1);
/*    */ 
/*    */     
/* 30 */     for (int j = 0; j < a.length; ) { a[j] = 1.0D; j++; }
/* 31 */      arrayVect1 = new ArrayVect1(a, 3.0D);
/* 32 */     Vect w = arrayVect1.clone();
/* 33 */     w.multiplyInverseCovariance();
/* 34 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect1.dot((VectConst)w));
/* 35 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect1.magnitude());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 41 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 44 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayVect1Test(String name) {
/* 50 */     super(name);
/*    */   }
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 55 */       throw new IllegalStateException("need -ea");
/* 56 */     } catch (AssertionError e) {
/* 57 */       return (Test)new TestSuite(ArrayVect1Test.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 63 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect1Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */