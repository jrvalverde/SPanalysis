/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Cdouble;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButterworthFilter
/*     */   extends RecursiveCascadeFilter
/*     */ {
/*     */   private Cdouble[] _poles;
/*     */   private Cdouble[] _zeros;
/*     */   private double _gain;
/*     */   
/*     */   public enum Type
/*     */   {
/*  24 */     LOW_PASS, HIGH_PASS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ButterworthFilter(double fl, double al, double fh, double ah) {
/*  46 */     Check.argument((0.0D < fl), "0.0<fl");
/*  47 */     Check.argument((fl < fh), "fl<fh");
/*  48 */     Check.argument((fh < 0.5D), "fh<0.5");
/*  49 */     Check.argument((0.0D < al), "0.0<al");
/*  50 */     Check.argument((al < 1.0D), "al<1.0");
/*  51 */     Check.argument((al != ah), "al!=ah");
/*  52 */     Check.argument((0.0D < ah), "0.0<ah");
/*  53 */     Check.argument((ah < 1.0D), "ah<1.0");
/*  54 */     double wl = 6.283185307179586D * fl;
/*  55 */     double wh = 6.283185307179586D * fh;
/*  56 */     double xl = 2.0D * MathPlus.tan(wl / 2.0D);
/*  57 */     double xh = 2.0D * MathPlus.tan(wh / 2.0D);
/*  58 */     double pl = al * al;
/*  59 */     double ph = ah * ah;
/*  60 */     if (al >= ah) {
/*  61 */       int np = (int)MathPlus.ceil(0.5D * MathPlus.log(pl * (1.0D - ph) / ph * (1.0D - pl)) / MathPlus.log(xh / xl));
/*  62 */       double xc = xl * MathPlus.pow(pl / (1.0D - pl), 0.5D / np);
/*  63 */       double wc = 2.0D * MathPlus.atan(xc / 2.0D);
/*  64 */       double fc = 0.5D * wc / Math.PI;
/*  65 */       makePolesZerosGain(fc, np, Type.LOW_PASS);
/*     */     } else {
/*  67 */       int np = (int)MathPlus.ceil(0.5D * MathPlus.log(ph * (1.0D - pl) / pl * (1.0D - ph)) / MathPlus.log(xh / xl));
/*  68 */       double xc = xh * MathPlus.pow((1.0D - ph) / ph, 0.5D / np);
/*  69 */       double wc = 2.0D * MathPlus.atan(xc / 2.0D);
/*  70 */       double fc = 0.5D * wc / Math.PI;
/*  71 */       makePolesZerosGain(fc, np, Type.HIGH_PASS);
/*     */     } 
/*  73 */     init(this._poles, this._zeros, this._gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ButterworthFilter(double fc, int np, Type type) {
/*  85 */     Check.argument((0.0D < fc), "0.0<fc");
/*  86 */     Check.argument((fc < 0.5D), "fc<0.5");
/*  87 */     Check.argument((np > 0), "np>0");
/*  88 */     makePolesZerosGain(fc, np, type);
/*  89 */     init(this._poles, this._zeros, this._gain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void makePolesZerosGain(double fc, int np, Type type) {
/* 100 */     boolean lowpass = (type == Type.LOW_PASS);
/* 101 */     double omegac = 2.0D * MathPlus.tan(Math.PI * fc);
/* 102 */     double dtheta = Math.PI / np;
/* 103 */     double ftheta = 0.5D * dtheta * (np + 1);
/* 104 */     this._poles = new Cdouble[np];
/* 105 */     this._zeros = new Cdouble[np];
/* 106 */     Cdouble c1 = new Cdouble(1.0D, 0.0D);
/* 107 */     Cdouble c2 = new Cdouble(2.0D, 0.0D);
/* 108 */     Cdouble zj = lowpass ? c1.neg() : c1;
/* 109 */     Cdouble gain = new Cdouble(c1);
/* 110 */     for (int j = 0, k = np - 1; j < np; j++, k--) {
/* 111 */       double theta = ftheta + j * dtheta;
/* 112 */       Cdouble sj = Cdouble.polar(omegac, theta);
/* 113 */       this._zeros[j] = zj;
/* 114 */       if (j == k) {
/* 115 */         this._poles[j] = c2.plus(sj).over(c2.minus(sj));
/* 116 */         (this._poles[j]).i = 0.0D;
/* 117 */       } else if (j < k) {
/* 118 */         this._poles[j] = c2.plus(sj).over(c2.minus(sj));
/* 119 */         this._poles[k] = this._poles[j].conj();
/*     */       } 
/* 121 */       if (lowpass) {
/* 122 */         gain.timesEquals(sj.over(sj.minus(c2)));
/*     */       } else {
/* 124 */         gain.timesEquals(c2.over(c2.minus(sj)));
/*     */       } 
/*     */     } 
/* 127 */     this._gain = gain.r;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/ButterworthFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */