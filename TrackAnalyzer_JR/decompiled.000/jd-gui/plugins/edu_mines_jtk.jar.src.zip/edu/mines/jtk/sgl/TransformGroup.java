/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformGroup
/*     */   extends Group
/*     */ {
/*     */   private Matrix44 _transform;
/*     */   
/*     */   public TransformGroup(Matrix44 transform) {
/*  24 */     this._transform = new Matrix44(transform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix44 getTransform() {
/*  32 */     return new Matrix44(this._transform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransform(Matrix44 transform) {
/*  40 */     this._transform = new Matrix44(transform);
/*  41 */     dirtyBoundingSphere();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cullBegin(CullContext cc) {
/*  52 */     super.cullBegin(cc);
/*  53 */     cc.pushLocalToWorld(this._transform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cullEnd(CullContext cc) {
/*  61 */     cc.popLocalToWorld();
/*  62 */     super.cullEnd(cc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawBegin(DrawContext dc) {
/*  70 */     super.drawBegin(dc);
/*  71 */     dc.pushLocalToWorld(this._transform);
/*  72 */     Gl.glPushMatrix();
/*  73 */     Gl.glMultMatrixd(this._transform.m, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawEnd(DrawContext dc) {
/*  81 */     dc.popLocalToWorld();
/*  82 */     Gl.glPopMatrix();
/*  83 */     super.drawEnd(dc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickBegin(PickContext pc) {
/*  91 */     super.pickBegin(pc);
/*  92 */     pc.pushLocalToWorld(this._transform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickEnd(PickContext pc) {
/* 100 */     pc.popLocalToWorld();
/* 101 */     super.pickEnd(pc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BoundingSphere computeBoundingSphere(boolean finite) {
/* 112 */     BoundingSphere bs = super.computeBoundingSphere(finite);
/* 113 */     if (!bs.isEmpty() && !bs.isInfinite()) {
/* 114 */       double r = bs.getRadius();
/* 115 */       Point3 c = bs.getCenter();
/* 116 */       Point3 x = new Point3(c.x + r, c.y, c.z);
/* 117 */       Point3 y = new Point3(c.x, c.y + r, c.z);
/* 118 */       Point3 z = new Point3(c.x, c.y, c.z + r);
/* 119 */       c = this._transform.times(c);
/* 120 */       x = this._transform.times(x);
/* 121 */       y = this._transform.times(y);
/* 122 */       z = this._transform.times(z);
/* 123 */       Vector3 cx = c.minus(x);
/* 124 */       Vector3 cy = c.minus(y);
/* 125 */       Vector3 cz = c.minus(z);
/* 126 */       double lx = cx.length();
/* 127 */       double ly = cy.length();
/* 128 */       double lz = cz.length();
/* 129 */       r = lx;
/* 130 */       if (r < ly) r = ly; 
/* 131 */       if (r < lz) r = lz; 
/* 132 */       bs = new BoundingSphere(c, r);
/*     */     } 
/* 134 */     return bs;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/TransformGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */