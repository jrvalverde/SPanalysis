/*    */ package edu.mines.jtk.sgl;
/*    */ 
/*    */ import java.awt.event.MouseEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MouseOnPlane
/*    */   extends MouseConstrained
/*    */ {
/*    */   private Vector3 _normal;
/*    */   private Plane _plane;
/*    */   private Vector3 _delta;
/*    */   
/*    */   public MouseOnPlane(MouseEvent event, Point3 origin, Plane plane, Matrix44 localToPixel) {
/* 38 */     super(localToPixel);
/*    */     
/* 40 */     this._normal = plane.getNormal();
/* 41 */     this._plane = new Plane(plane);
/* 42 */     this._delta = origin.minus(getPointOnPlane(event));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Point3 getPoint(MouseEvent event) {
/* 53 */     return getPointOnPlane(event).plusEquals(this._delta);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Point3 getPointOnPlane(MouseEvent event) {
/*    */     Point3 point;
/* 75 */     Segment segment = getMouseSegment(event);
/* 76 */     Point3 a = segment.getA();
/* 77 */     Point3 b = segment.getB();
/* 78 */     Vector3 d = b.minus(a);
/*    */ 
/*    */     
/* 81 */     double den = d.dot(this._normal);
/*    */     
/* 83 */     double num = -this._plane.distanceTo(a);
/* 84 */     double t = num / den;
/*    */     
/* 86 */     if (t <= 0.0D) {
/* 87 */       point = a;
/* 88 */     } else if (t >= 1.0D) {
/* 89 */       point = b;
/*    */     } else {
/* 91 */       point = a.plus(d.times(t));
/*    */     } 
/*    */     
/* 94 */     return point;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/MouseOnPlane.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */