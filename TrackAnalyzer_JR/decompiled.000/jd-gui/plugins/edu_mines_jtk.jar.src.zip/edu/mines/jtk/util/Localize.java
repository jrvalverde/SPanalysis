/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.MatchResult;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Localize
/*     */ {
/*  17 */   private static final Logger LOG = Logger.getLogger(Localize.class.getName());
/*  18 */   private static final Pattern s_tokens = Pattern.compile("[$][{](.+?)[}]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String filter(String message, ResourceBundle catalog) {
/*  28 */     if (catalog == null) {
/*  29 */       return message;
/*     */     }
/*     */     
/*     */     try {
/*  33 */       message = catalog.getString(message);
/*  34 */     } catch (MissingResourceException ex) {}
/*     */ 
/*     */     
/*  37 */     Matcher matcher = s_tokens.matcher(message);
/*  38 */     int numberMatches = 0;
/*  39 */     for (; matcher.find(); numberMatches++);
/*     */ 
/*     */     
/*  42 */     for (int match = numberMatches; match > 0; match--) {
/*  43 */       matcher.reset();
/*  44 */       for (int i = 0; i < match; i++) {
/*  45 */         matcher.find();
/*     */       }
/*  47 */       MatchResult mr = matcher.toMatchResult();
/*     */       try {
/*  49 */         String key = mr.group(1);
/*  50 */         String replacement = catalog.getString(key);
/*  51 */         int start = mr.start();
/*  52 */         int end = mr.end();
/*  53 */         message = message.substring(0, start) + replacement + message.substring(end);
/*     */       }
/*  55 */       catch (MissingResourceException ex) {}
/*     */     } 
/*  57 */     return message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String filter(String message, Class<?> resourceClass) {
/*  74 */     ClassLoader cl = resourceClass.getClassLoader();
/*  75 */     if (cl == null) {
/*  76 */       LOG.warning("Could not get ClassLoader from " + resourceClass.getName());
/*  77 */       cl = ClassLoader.getSystemClassLoader();
/*     */     } 
/*  79 */     Locale currentLocale = Locale.getDefault();
/*  80 */     String name = resourceClass.getName();
/*  81 */     ResourceBundle catalog = ResourceBundle.getBundle(name, currentLocale, cl);
/*     */     
/*  83 */     if (catalog == null) {
/*  84 */       LOG.warning("Could not get ResourceBundle " + name + " for " + currentLocale + " from " + cl);
/*     */     }
/*     */     
/*  87 */     return filter(message, catalog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String timeWords(long seconds) {
/*  95 */     if (seconds == 0L) {
/*  96 */       return filter("0 ${seconds}", Localize.class);
/*     */     }
/*  98 */     String result = "";
/*  99 */     long minutes = seconds / 60L;
/* 100 */     long hours = minutes / 60L;
/* 101 */     long days = hours / 24L;
/* 102 */     seconds %= 60L;
/* 103 */     minutes %= 60L;
/* 104 */     hours %= 24L;
/*     */     
/* 106 */     if (hours >= 12L) days++; 
/* 107 */     hours = minutes = seconds = 0L;
/*     */     
/* 109 */     if (minutes >= 30L) {
/* 110 */       hours++;
/* 111 */       days += hours / 24L;
/* 112 */       hours %= 24L;
/*     */     } 
/* 114 */     minutes = seconds = 0L;
/* 115 */     if (minutes >= 10L || hours > 0L) {
/* 116 */       if (seconds >= 30L) {
/* 117 */         minutes++;
/* 118 */         hours += minutes / 60L;
/* 119 */         minutes %= 60L;
/*     */       } 
/* 121 */       seconds = 0L;
/*     */     } 
/* 123 */     if (seconds != 0L)
/* 124 */       result = " " + seconds + " ${second" + ((seconds > 1L) ? "s}" : "}") + result; 
/* 125 */     if (minutes != 0L)
/* 126 */       result = " " + minutes + " ${minute" + ((minutes > 1L) ? "s}" : "}") + result; 
/* 127 */     if (hours != 0L)
/* 128 */       result = " " + hours + " ${hour" + ((hours > 1L) ? "s}" : "}") + result; 
/* 129 */     if (days != 0L) {
/* 130 */       result = " " + days + " ${day" + ((days > 1L) ? "s}" : "}") + result;
/*     */     }
/* 132 */     return filter(result.trim(), Localize.class);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/Localize.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */