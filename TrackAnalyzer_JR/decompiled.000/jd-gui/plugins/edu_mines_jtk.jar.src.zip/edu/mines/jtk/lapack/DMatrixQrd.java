/*     */ package edu.mines.jtk.lapack;
/*     */ 
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMatrixQrd
/*     */ {
/*     */   int _m;
/*     */   int _n;
/*     */   int _k;
/*     */   double[] _qr;
/*     */   double[] _tau;
/*     */   double[] _work;
/*     */   int _lwork;
/*     */   
/*     */   public DMatrixQrd(DMatrix a) {
/*  36 */     Check.argument((a.getM() >= a.getN()), "m >= n");
/*  37 */     this._m = a.getM();
/*  38 */     this._n = a.getN();
/*  39 */     this._k = Math.min(this._m, this._n);
/*  40 */     this._qr = a.getPackedColumns();
/*  41 */     this._tau = new double[this._k];
/*  42 */     this._work = new double[1];
/*  43 */     Lapack.dgeqrf(this._m, this._n, this._qr, this._m, this._tau, this._work, -1);
/*  44 */     this._lwork = (int)this._work[0];
/*  45 */     this._work = new double[this._lwork];
/*  46 */     Lapack.dgeqrf(this._m, this._n, this._qr, this._m, this._tau, this._work, this._lwork);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFullRank() {
/*  54 */     for (int j = 0; j < this._n; j++) {
/*  55 */       if (this._qr[j + j * this._m] == 0.0D)
/*  56 */         return false; 
/*     */     } 
/*  58 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getQ() {
/*  66 */     double[] q = Array.copy(this._qr);
/*  67 */     Lapack.dorgqr(this._m, this._n, this._k, q, this._m, this._tau, this._work, this._lwork);
/*  68 */     return new DMatrix(this._m, this._n, q);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix getR() {
/*  76 */     double[] r = new double[this._n * this._n];
/*  77 */     for (int j = 0; j < this._n; j++) {
/*  78 */       for (int i = 0; i <= j; i++)
/*  79 */         r[i + j * this._n] = this._qr[i + j * this._m]; 
/*  80 */     }  return new DMatrix(this._n, this._n, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DMatrix solve(DMatrix b) {
/*  93 */     Check.argument((b.getM() == this._m), "A and B have the same number of rows");
/*  94 */     Check.state(isFullRank(), "A is of full rank");
/*     */ 
/*     */ 
/*     */     
/*  98 */     int nrhs = b.getN();
/*  99 */     DMatrix c = new DMatrix(b);
/* 100 */     double[] ca = c.getArray();
/* 101 */     Lapack.dormqr(141, 112, this._m, nrhs, this._k, this._qr, this._m, this._tau, ca, this._m, this._work, this._lwork);
/*     */ 
/*     */     
/* 104 */     Blas.dtrsm(102, 141, 121, 111, 131, this._n, nrhs, 1.0D, this._qr, this._m, ca, this._m);
/*     */ 
/*     */     
/* 107 */     DMatrix x = c.get(0, this._n - 1, (int[])null);
/* 108 */     return x;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/lapack/DMatrixQrd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */