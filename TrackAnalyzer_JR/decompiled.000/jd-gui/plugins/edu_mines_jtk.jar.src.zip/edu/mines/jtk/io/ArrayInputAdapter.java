/*     */ package edu.mines.jtk.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.LongBuffer;
/*     */ import java.nio.ShortBuffer;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayInputAdapter
/*     */   implements ArrayInput
/*     */ {
/*     */   private byte[] _buffer;
/*     */   private ReadableByteChannel _rbc;
/*     */   private DataInput _di;
/*     */   private ByteOrder _bo;
/*     */   private ByteBuffer _bb;
/*     */   private CharBuffer _cb;
/*     */   private ShortBuffer _sb;
/*     */   private IntBuffer _ib;
/*     */   private LongBuffer _lb;
/*     */   private FloatBuffer _fb;
/*     */   private DoubleBuffer _db;
/*     */   
/*     */   public ArrayInputAdapter(DataInput input) {
/*  36 */     this(input, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(RandomAccessFile file) {
/*  45 */     this(file, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(FileInputStream stream) {
/*  54 */     this(stream, ByteOrder.BIG_ENDIAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(DataInput input, ByteOrder order) {
/*  63 */     this(null, input, order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(RandomAccessFile file, ByteOrder order) {
/*  73 */     this(file.getChannel(), file, order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(FileInputStream stream, ByteOrder order) {
/*  83 */     this(stream.getChannel(), new DataInputStream(stream), order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInputAdapter(ReadableByteChannel channel, DataInput input, ByteOrder order) {
/*  96 */     this._rbc = channel;
/*  97 */     this._di = input;
/*  98 */     this._bo = order;
/*  99 */     if (this._rbc != null) {
/* 100 */       this._bb = ByteBuffer.allocateDirect(4096);
/*     */     } else {
/* 102 */       this._buffer = new byte[4096];
/* 103 */       this._bb = ByteBuffer.wrap(this._buffer);
/*     */     } 
/* 105 */     if (order == ByteOrder.BIG_ENDIAN) {
/* 106 */       this._bb.order(ByteOrder.BIG_ENDIAN);
/*     */     } else {
/* 108 */       this._bb.order(ByteOrder.LITTLE_ENDIAN);
/*     */     } 
/* 110 */     this._cb = this._bb.asCharBuffer();
/* 111 */     this._sb = this._bb.asShortBuffer();
/* 112 */     this._ib = this._bb.asIntBuffer();
/* 113 */     this._lb = this._bb.asLongBuffer();
/* 114 */     this._fb = this._bb.asFloatBuffer();
/* 115 */     this._db = this._bb.asDoubleBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteOrder getByteOrder() {
/* 123 */     return this._bo;
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException {
/* 127 */     this._di.readFully(b);
/*     */   }
/*     */   public void readFully(byte[] b, int off, int len) throws IOException {
/* 130 */     this._di.readFully(b, off, len);
/*     */   }
/*     */   public int skipBytes(int n) throws IOException {
/* 133 */     return this._di.skipBytes(n);
/*     */   }
/*     */   public final boolean readBoolean() throws IOException {
/* 136 */     return this._di.readBoolean();
/*     */   }
/*     */   public final byte readByte() throws IOException {
/* 139 */     return this._di.readByte();
/*     */   }
/*     */   public final int readUnsignedByte() throws IOException {
/* 142 */     return this._di.readUnsignedByte();
/*     */   }
/*     */   public final short readShort() throws IOException {
/* 145 */     int b1 = this._di.readUnsignedByte();
/* 146 */     int b2 = this._di.readUnsignedByte();
/* 147 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 148 */       return (short)((b1 << 8) + b2);
/*     */     }
/* 150 */     return (short)((b2 << 8) + b1);
/*     */   }
/*     */   
/*     */   public final int readUnsignedShort() throws IOException {
/* 154 */     return readShort() & 0xFFFF;
/*     */   }
/*     */   public final char readChar() throws IOException {
/* 157 */     return (char)readShort();
/*     */   }
/*     */   public final int readInt() throws IOException {
/* 160 */     int b1 = this._di.readUnsignedByte();
/* 161 */     int b2 = this._di.readUnsignedByte();
/* 162 */     int b3 = this._di.readUnsignedByte();
/* 163 */     int b4 = this._di.readUnsignedByte();
/* 164 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 165 */       return (b1 << 24) + (b2 << 16) + (b3 << 8) + b4;
/*     */     }
/* 167 */     return (b4 << 24) + (b3 << 16) + (b2 << 8) + b1;
/*     */   }
/*     */   
/*     */   public final long readLong() throws IOException {
/* 171 */     int i1 = readInt();
/* 172 */     int i2 = readInt();
/* 173 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/* 174 */       return (i1 << 32L) + (i2 & 0xFFFFFFFFL);
/*     */     }
/* 176 */     return (i2 << 32L) + (i1 & 0xFFFFFFFFL);
/*     */   }
/*     */   
/*     */   public final float readFloat() throws IOException {
/* 180 */     return Float.intBitsToFloat(readInt());
/*     */   }
/*     */   public final double readDouble() throws IOException {
/* 183 */     return Double.longBitsToDouble(readLong());
/*     */   }
/*     */   public final String readLine() throws IOException {
/* 186 */     return this._di.readLine();
/*     */   }
/*     */   public final String readUTF() throws IOException {
/* 189 */     return this._di.readUTF();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v, int k, int n) throws IOException {
/* 199 */     readFully(v, k, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[] v) throws IOException {
/* 208 */     readFully(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][] v) throws IOException {
/* 217 */     for (int i = 0; i < v.length; i++) {
/* 218 */       readBytes(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readBytes(byte[][][] v) throws IOException {
/* 227 */     for (int i = 0; i < v.length; i++) {
/* 228 */       readBytes(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v, int k, int n) throws IOException {
/* 238 */     int m = this._cb.capacity(); int j;
/* 239 */     for (j = 0; j < n; j += m) {
/* 240 */       int l = Math.min(n - j, m);
/* 241 */       if (this._rbc != null) {
/* 242 */         this._bb.position(0).limit(l * 2);
/* 243 */         this._rbc.read(this._bb);
/*     */       } else {
/* 245 */         this._di.readFully(this._buffer, 0, l * 2);
/*     */       } 
/* 247 */       this._cb.position(0).limit(l);
/* 248 */       this._cb.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[] v) throws IOException {
/* 258 */     readChars(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][] v) throws IOException {
/* 267 */     for (int i = 0; i < v.length; i++) {
/* 268 */       readChars(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readChars(char[][][] v) throws IOException {
/* 277 */     for (int i = 0; i < v.length; i++) {
/* 278 */       readChars(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v, int k, int n) throws IOException {
/* 288 */     int m = this._sb.capacity(); int j;
/* 289 */     for (j = 0; j < n; j += m) {
/* 290 */       int l = Math.min(n - j, m);
/* 291 */       if (this._rbc != null) {
/* 292 */         this._bb.position(0).limit(l * 2);
/* 293 */         this._rbc.read(this._bb);
/*     */       } else {
/* 295 */         this._di.readFully(this._buffer, 0, l * 2);
/*     */       } 
/* 297 */       this._sb.position(0).limit(l);
/* 298 */       this._sb.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[] v) throws IOException {
/* 308 */     readShorts(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][] v) throws IOException {
/* 317 */     for (int i = 0; i < v.length; i++) {
/* 318 */       readShorts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readShorts(short[][][] v) throws IOException {
/* 327 */     for (int i = 0; i < v.length; i++) {
/* 328 */       readShorts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v, int k, int n) throws IOException {
/* 338 */     int m = this._ib.capacity(); int j;
/* 339 */     for (j = 0; j < n; j += m) {
/* 340 */       int l = Math.min(n - j, m);
/* 341 */       if (this._rbc != null) {
/* 342 */         this._bb.position(0).limit(l * 4);
/* 343 */         this._rbc.read(this._bb);
/*     */       } else {
/* 345 */         this._di.readFully(this._buffer, 0, l * 4);
/*     */       } 
/* 347 */       this._ib.position(0).limit(l);
/* 348 */       this._ib.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[] v) throws IOException {
/* 358 */     readInts(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][] v) throws IOException {
/* 367 */     for (int i = 0; i < v.length; i++) {
/* 368 */       readInts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readInts(int[][][] v) throws IOException {
/* 377 */     for (int i = 0; i < v.length; i++) {
/* 378 */       readInts(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v, int k, int n) throws IOException {
/* 388 */     int m = this._lb.capacity(); int j;
/* 389 */     for (j = 0; j < n; j += m) {
/* 390 */       int l = Math.min(n - j, m);
/* 391 */       if (this._rbc != null) {
/* 392 */         this._bb.position(0).limit(l * 8);
/* 393 */         this._rbc.read(this._bb);
/*     */       } else {
/* 395 */         this._di.readFully(this._buffer, 0, l * 8);
/*     */       } 
/* 397 */       this._lb.position(0).limit(l);
/* 398 */       this._lb.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[] v) throws IOException {
/* 408 */     readLongs(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][] v) throws IOException {
/* 417 */     for (int i = 0; i < v.length; i++) {
/* 418 */       readLongs(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readLongs(long[][][] v) throws IOException {
/* 427 */     for (int i = 0; i < v.length; i++) {
/* 428 */       readLongs(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v, int k, int n) throws IOException {
/* 438 */     int m = this._fb.capacity(); int j;
/* 439 */     for (j = 0; j < n; j += m) {
/* 440 */       int l = Math.min(n - j, m);
/* 441 */       if (this._rbc != null) {
/* 442 */         this._bb.position(0).limit(l * 4);
/* 443 */         this._rbc.read(this._bb);
/*     */       } else {
/* 445 */         this._di.readFully(this._buffer, 0, l * 4);
/*     */       } 
/* 447 */       this._fb.position(0).limit(l);
/* 448 */       this._fb.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[] v) throws IOException {
/* 458 */     readFloats(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][] v) throws IOException {
/* 467 */     for (int i = 0; i < v.length; i++) {
/* 468 */       readFloats(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFloats(float[][][] v) throws IOException {
/* 477 */     for (int i = 0; i < v.length; i++) {
/* 478 */       readFloats(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v, int k, int n) throws IOException {
/* 488 */     int m = this._db.capacity(); int j;
/* 489 */     for (j = 0; j < n; j += m) {
/* 490 */       int l = Math.min(n - j, m);
/* 491 */       if (this._rbc != null) {
/* 492 */         this._bb.position(0).limit(l * 8);
/* 493 */         this._rbc.read(this._bb);
/*     */       } else {
/* 495 */         this._di.readFully(this._buffer, 0, l * 8);
/*     */       } 
/* 497 */       this._db.position(0).limit(l);
/* 498 */       this._db.get(v, k + j, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[] v) throws IOException {
/* 508 */     readDoubles(v, 0, v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][] v) throws IOException {
/* 517 */     for (int i = 0; i < v.length; i++) {
/* 518 */       readDoubles(v[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readDoubles(double[][][] v) throws IOException {
/* 527 */     for (int i = 0; i < v.length; i++)
/* 528 */       readDoubles(v[i]); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/ArrayInputAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */