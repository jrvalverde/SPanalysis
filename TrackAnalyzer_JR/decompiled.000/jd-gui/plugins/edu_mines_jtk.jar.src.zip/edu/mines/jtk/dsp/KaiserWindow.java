/*     */ package edu.mines.jtk.dsp;
/*     */ 
/*     */ import edu.mines.jtk.util.Check;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KaiserWindow
/*     */ {
/*     */   private double _error;
/*     */   private double _width;
/*     */   private double _length;
/*     */   private double _alpha;
/*     */   private double _scale;
/*     */   private double _xxmax;
/*     */   
/*     */   public static KaiserWindow fromErrorAndWidth(double error, double width) {
/*  64 */     Check.argument((error > 0.0D), "error>0.0");
/*  65 */     Check.argument((error < 1.0D), "error<1.0");
/*  66 */     Check.argument((width > 0.0D), "width>0.0");
/*  67 */     double a = -20.0D * MathPlus.log10(error);
/*  68 */     double d = (a > 21.0D) ? ((a - 7.95D) / 14.36D) : 0.9222D;
/*  69 */     double length = d / width;
/*  70 */     return new KaiserWindow(error, width, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KaiserWindow fromErrorAndLength(double error, double length) {
/*  80 */     Check.argument((error > 0.0D), "error>0.0");
/*  81 */     Check.argument((error < 1.0D), "error<1.0");
/*  82 */     Check.argument((length > 0.0D), "length>0");
/*  83 */     double a = -20.0D * MathPlus.log10(error);
/*  84 */     double d = (a > 21.0D) ? ((a - 7.95D) / 14.36D) : 0.9222D;
/*  85 */     double width = d / length;
/*  86 */     return new KaiserWindow(error, width, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KaiserWindow fromWidthAndLength(double width, double length) {
/*  97 */     Check.argument((width > 0.0D), "width>0.0");
/*  98 */     Check.argument((length > 0.0D), "length>0");
/*  99 */     Check.argument((width * length >= 1.0D), "width*length>=1.0");
/* 100 */     double d = width * length;
/* 101 */     double a = 14.36D * d + 7.95D;
/* 102 */     double error = MathPlus.pow(10.0D, -a / 20.0D);
/* 103 */     return new KaiserWindow(error, width, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double evaluate(double x) {
/* 112 */     double xx = x * x;
/* 113 */     return (xx <= this._xxmax) ? (this._scale * ino(this._alpha * MathPlus.sqrt(1.0D - xx / this._xxmax))) : 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getError() {
/* 121 */     return this._error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getLength() {
/* 129 */     return this._length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/* 137 */     return this._width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KaiserWindow(double error, double width, double length) {
/* 151 */     this._error = error;
/* 152 */     this._width = width;
/* 153 */     this._length = length;
/* 154 */     double a = -20.0D * MathPlus.log10(this._error);
/* 155 */     if (a <= 21.0D) {
/* 156 */       this._alpha = 0.0D;
/* 157 */     } else if (a <= 50.0D) {
/* 158 */       this._alpha = 0.5842D * MathPlus.pow(a - 21.0D, 0.4D) + 0.07886D * (a - 21.0D);
/*     */     } else {
/* 160 */       this._alpha = 0.1102D * (a - 8.7D);
/*     */     } 
/* 162 */     this._scale = 1.0D / ino(this._alpha);
/* 163 */     this._xxmax = 0.25D * this._length * this._length;
/*     */   }
/*     */   
/*     */   private double ino(double x) {
/* 167 */     double s = 1.0D;
/* 168 */     double ds = 1.0D;
/* 169 */     double d = 0.0D;
/*     */     while (true) {
/* 171 */       d += 2.0D;
/* 172 */       ds *= x * x / d * d;
/* 173 */       s += ds;
/* 174 */       if (ds <= s * 2.220446049250313E-16D)
/* 175 */         return s; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/KaiserWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */