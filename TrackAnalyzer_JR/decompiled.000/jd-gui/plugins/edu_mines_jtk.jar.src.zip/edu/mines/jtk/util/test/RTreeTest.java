/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import edu.mines.jtk.util.RTree;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.util.ArrayList;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTreeTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  27 */     TestSuite suite = new TestSuite(RTreeTest.class);
/*  28 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testRandom() {
/*  32 */     RTree rt = new RTree(3, 4, 12);
/*  33 */     STree st = new STree(3);
/*  34 */     int n = 1000;
/*  35 */     for (int i = 0; i < n; i++) {
/*  36 */       RTree.Box box = randomBox(0.2F);
/*  37 */       rt.add(box);
/*  38 */       st.add((RTree.Boxed)box);
/*  39 */       assertEquals(rt.size(), st.size());
/*     */     } 
/*  41 */     rt.validate();
/*  42 */     while (rt.size() > 0) {
/*  43 */       RTree.Box box = randomBox(0.4F);
/*  44 */       Object[] rb = rt.findOverlapping(box);
/*  45 */       Object[] sb = st.findOverlapping((RTree.Boxed)box);
/*  46 */       assertEquals(rb.length, sb.length);
/*  47 */       for (int ib = 0; ib < rb.length; ib++) {
/*  48 */         RTree.Box rbi = (RTree.Box)rb[ib];
/*  49 */         RTree.Box sbi = (RTree.Box)sb[ib];
/*  50 */         rt.remove(rbi);
/*  51 */         st.remove((RTree.Boxed)sbi);
/*  52 */         assertEquals(rt.size(), st.size());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testNearest() {
/*  58 */     RTree rt = new RTree(3, 4, 12);
/*  59 */     STree st = new STree(3);
/*  60 */     int n = 100;
/*  61 */     for (int i = 0; i < n; i++) {
/*  62 */       RTree.Box box = randomBox(0.2F);
/*  63 */       rt.add(box);
/*  64 */       st.add((RTree.Boxed)box);
/*     */     } 
/*  66 */     rt.validate();
/*  67 */     int k = 3;
/*  68 */     for (int j = 0; j < n; j++) {
/*  69 */       float[] point = randomPoint();
/*  70 */       Object[] rb = rt.findNearest(k, point);
/*  71 */       Object[] sb = st.findNearest(k, point);
/*  72 */       assertEquals(k, rb.length);
/*  73 */       assertEquals(k, sb.length);
/*  74 */       for (int m = 0; m < k; m++) {
/*  75 */         float rd = ((RTree.Box)rb[m]).getDistanceSquared(point);
/*  76 */         float sd = ((RTree.Box)sb[m]).getDistanceSquared(point);
/*  77 */         assertEquals(sd, rd, 0.0F);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testIterator() {
/*  83 */     RTree rt = new RTree(3, 4, 12);
/*  84 */     int n = 100;
/*  85 */     for (int i = 0; i < n; i++) {
/*  86 */       rt.add(randomBox(0.2F));
/*     */     }
/*  88 */     Iterator rti = rt.iterator();
/*  89 */     Object box = rti.next();
/*  90 */     rt.remove(box);
/*  91 */     rt.add(box);
/*  92 */     boolean cmeThrown = false;
/*     */     try {
/*  94 */       rti.next();
/*  95 */     } catch (ConcurrentModificationException cme) {
/*  96 */       cmeThrown = true;
/*     */     } 
/*  98 */     assertTrue(cmeThrown);
/*     */     
/* 100 */     Object[] boxs = rt.toArray();
/* 101 */     int nbox = boxs.length;
/* 102 */     for (int ibox = 0; ibox < nbox; ibox++) {
/* 103 */       boolean removed = rt.remove(boxs[ibox]);
/* 104 */       assertTrue(removed);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void xtestTriangle() {
/* 109 */     RTree rt = new RTree(3, 6, 12);
/* 110 */     STree st = new STree(3);
/*     */ 
/*     */     
/* 113 */     int nsurf = 5;
/* 114 */     int nx = 100;
/* 115 */     int ny = 100;
/* 116 */     int nt = nsurf * 2 * nx * ny;
/* 117 */     int np = nt;
/* 118 */     float radius = 2.0F / nx;
/* 119 */     Triangle[] ts = makeSurfaceTriangles(nsurf, nx, ny);
/*     */     
/* 121 */     Point[] ps = makeSurfacePoints(nsurf, np);
/* 122 */     Point[] pr = makeRandomPoints(np);
/* 123 */     Point[][] psr = { ps, pr };
/*     */     
/* 125 */     System.out.println();
/* 126 */     Stopwatch sw = new Stopwatch();
/* 127 */     double time = 3.0D;
/* 128 */     float[] point = new float[3];
/*     */ 
/*     */     
/* 131 */     boolean pack = true;
/* 132 */     sw.restart();
/* 133 */     if (pack) {
/* 134 */       rt.addPacked((Object[])ts);
/*     */     } else {
/* 136 */       for (int i = 0; i < nt; i++)
/* 137 */         rt.add(ts[i]); 
/*     */     } 
/* 139 */     sw.stop();
/* 140 */     System.out.println("RTree added " + rt.size() + " triangles at " + (int)(rt.size() / sw.time()) + " triangle/sec");
/*     */ 
/*     */     
/* 143 */     System.out.println("  leaf area=" + rt.getLeafArea() + " volume=" + rt.getLeafVolume());
/*     */     
/* 145 */     sw.restart();
/* 146 */     for (int it = 0; it < nt; it++)
/* 147 */       st.add(ts[it]); 
/* 148 */     sw.stop();
/* 149 */     System.out.println("STree added " + st.size() + " triangles at " + (int)(st.size() / sw.time()) + " triangle/sec");
/*     */ 
/*     */     
/* 152 */     assertEquals(rt.size(), st.size());
/* 153 */     for (int ip = 0; ip < 100; ip++) {
/* 154 */       Point p = ps[ip % np];
/* 155 */       point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 156 */       Object[] rb = rt.findInSphere(point, radius);
/* 157 */       Object[] sb = st.findInSphere(point, radius);
/* 158 */       assertEquals(sb.length, rb.length);
/*     */     } 
/* 160 */     System.out.println("RTree has " + rt.size() + " objects in " + rt.getLevels() + " levels.");
/*     */ 
/*     */ 
/*     */     
/* 164 */     for (int isr = 0; isr < 2; isr++) {
/* 165 */       Point[] pp = psr[isr];
/* 166 */       if (isr == 0) {
/* 167 */         System.out.println("Points on surfaces:");
/*     */       } else {
/* 169 */         System.out.println("Random points:");
/*     */       } 
/*     */ 
/*     */       
/* 173 */       int nr = 0;
/* 174 */       sw.restart(); for (; sw.time() < time; nr++) {
/* 175 */         Point p = pp[nr % np];
/* 176 */         point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 177 */         rt.findNearest(point);
/*     */       } 
/* 179 */       sw.stop();
/* 180 */       System.out.println("  RTree findNearest/sec = " + (int)(nr / sw.time()));
/* 181 */       int ns = 0;
/* 182 */       sw.restart(); for (; sw.time() < time; ns++) {
/* 183 */         Point p = pp[nr % np];
/* 184 */         point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 185 */         st.findNearest(point);
/*     */       } 
/* 187 */       sw.stop();
/* 188 */       System.out.println("  STree findNearest/sec = " + (int)(ns / sw.time()));
/*     */ 
/*     */       
/* 191 */       nr = 0;
/* 192 */       sw.restart(); for (; sw.time() < time; nr++) {
/* 193 */         Point p = ps[nr % np];
/* 194 */         point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 195 */         rt.findInSphere(point, radius);
/*     */       } 
/* 197 */       sw.stop();
/* 198 */       System.out.println("  RTree findInSphere/sec = " + (int)(nr / sw.time()));
/* 199 */       ns = 0;
/* 200 */       sw.restart(); for (; sw.time() < time; ns++) {
/* 201 */         Point p = ps[nr % np];
/* 202 */         point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 203 */         st.findInSphere(point, radius);
/*     */       } 
/* 205 */       sw.stop();
/* 206 */       System.out.println("  STree findInSphere/sec = " + (int)(ns / sw.time()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void xtestPoint() {
/* 211 */     RTree rt = new RTree(3, 6, 12);
/* 212 */     STree st = new STree(3);
/* 213 */     int n = 100000;
/* 214 */     Point[] ps = new Point[n];
/* 215 */     for (int i = 0; i < n; i++) {
/* 216 */       ps[i] = new Point();
/*     */     }
/* 218 */     System.out.println();
/* 219 */     Stopwatch sw = new Stopwatch();
/* 220 */     sw.restart(); int j;
/* 221 */     for (j = 0; j < n; j++)
/* 222 */       rt.add(ps[j]); 
/* 223 */     sw.stop();
/* 224 */     System.out.println("RTree add points/sec=" + (int)(n / sw.time()));
/* 225 */     sw.restart();
/* 226 */     for (j = 0; j < n; j++)
/* 227 */       st.add(ps[j]); 
/* 228 */     sw.stop();
/* 229 */     float radius = 0.1F;
/* 230 */     System.out.println("STree add points/sec=" + (int)(n / sw.time()));
/* 231 */     for (int k = 0; k < 100; k++) {
/* 232 */       float[] arrayOfFloat = randomPoint();
/* 233 */       Object[] rb = rt.findInSphere(arrayOfFloat, radius);
/* 234 */       Object[] sb = st.findInSphere(arrayOfFloat, radius);
/* 235 */       assertEquals(sb.length, rb.length);
/*     */     } 
/* 237 */     double time = 3.0D;
/* 238 */     float[] point = new float[3];
/* 239 */     int nr = 0;
/* 240 */     sw.restart(); for (; sw.time() < time; nr++) {
/* 241 */       Point p = ps[nr % n];
/* 242 */       point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 243 */       rt.findInSphere(point, radius);
/*     */     } 
/* 245 */     sw.stop();
/* 246 */     System.out.println("RTree findInSphere/sec = " + (int)(nr / sw.time()));
/* 247 */     int ns = 0;
/* 248 */     sw.restart(); for (; sw.time() < time; ns++) {
/* 249 */       Point p = ps[nr % n];
/* 250 */       point[0] = p.x; point[1] = p.y; point[2] = p.z;
/* 251 */       st.findInSphere(point, radius);
/*     */     } 
/* 253 */     sw.stop();
/* 254 */     System.out.println("STree findInSphere/sec = " + (int)(ns / sw.time()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class STree
/*     */   {
/*     */     private HashSet<RTree.Boxed> _set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int _ndim;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float[] _amin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float[] _amax;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float[] _bmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private float[] _bmax;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public STree(int ndim) {
/* 328 */       this._set = new HashSet<RTree.Boxed>(); this._ndim = ndim; this._amin = new float[this._ndim]; this._amax = new float[this._ndim]; this._bmin = new float[this._ndim]; this._bmax = new float[this._ndim];
/*     */     }
/*     */     public boolean add(RTree.Boxed boxed) { return this._set.add(boxed); }
/*     */     public boolean remove(RTree.Boxed boxed) { return this._set.remove(boxed); }
/*     */     public int size() { return this._set.size(); }
/*     */     public boolean contains(RTree.Boxed boxed) { return this._set.contains(boxed); }
/*     */     public Object[] findOverlapping(RTree.Boxed boxed) { boxed.getBounds(this._amin, this._amax); ArrayList<RTree.Boxed> list = new ArrayList<RTree.Boxed>(); Iterator<RTree.Boxed> i = this._set.iterator(); while (i.hasNext()) { RTree.Boxed b = i.next(); b.getBounds(this._bmin, this._bmax); if (overlapsAB())
/* 335 */           list.add(b);  }  return list.toArray(); } public Object findNearest(float[] point) { return findNearest(1, point)[0]; } private boolean overlapsAB() { for (int idim = 0; idim < this._ndim; idim++) {
/* 336 */         if (this._amin[idim] > this._bmax[idim] || this._amax[idim] < this._bmin[idim])
/* 337 */           return false; 
/*     */       } 
/* 339 */       return true; }
/*     */     public Object[] findNearest(int n, float[] point) { ArrayList<RTree.Boxed> list = new ArrayList<RTree.Boxed>(); for (int i = 0; i < n; i++) { float dmin = Float.MAX_VALUE; RTree.Boxed bmin = null; Iterator<RTree.Boxed> si = this._set.iterator(); while (si.hasNext()) { RTree.Boxed b = si.next(); if (list.contains(b))
/*     */             continue;  float d = b.getDistanceSquared(point); if (d < dmin) { dmin = d; bmin = b; }  }  list.add(bmin); }  return list.toArray(); } public Object[] findInSphere(float[] point, float radius) { ArrayList<RTree.Boxed> list = new ArrayList<RTree.Boxed>(); Iterator<RTree.Boxed> i = this._set.iterator(); float s = radius * radius; while (i.hasNext()) { RTree.Boxed b = i.next(); if (b.getDistanceSquared(point) < s)
/*     */           list.add(b);  }  return list.toArray(); }
/* 343 */   } private static Random _random = new Random();
/*     */   static {
/* 345 */     int seed = _random.nextInt();
/*     */     
/* 347 */     _random.setSeed(seed);
/*     */   }
/*     */   
/*     */   private RTree.Box randomBox(float size) {
/* 351 */     float xmin = (1.0F - size) * _random.nextFloat();
/* 352 */     float ymin = (1.0F - size) * _random.nextFloat();
/* 353 */     float zmin = (1.0F - size) * _random.nextFloat();
/* 354 */     float xmax = xmin + size * _random.nextFloat();
/* 355 */     float ymax = ymin + size * _random.nextFloat();
/* 356 */     float zmax = zmin + size * _random.nextFloat();
/* 357 */     return new RTree.Box(xmin, ymin, zmin, xmax, ymax, zmax);
/*     */   }
/*     */   
/*     */   private float[] randomPoint() {
/* 361 */     float x = _random.nextFloat();
/* 362 */     float y = _random.nextFloat();
/* 363 */     float z = _random.nextFloat();
/* 364 */     return new float[] { x, y, z };
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Point
/*     */     implements RTree.Boxed
/*     */   {
/*     */     float x;
/*     */     float y;
/*     */     float z;
/*     */     
/*     */     Point() {
/* 376 */       this.x = RTreeTest._random.nextFloat();
/* 377 */       this.y = RTreeTest._random.nextFloat();
/* 378 */       this.z = RTreeTest._random.nextFloat();
/*     */     }
/*     */     Point(float x, float y, float z) {
/* 381 */       this.x = x;
/* 382 */       this.y = y;
/* 383 */       this.z = z;
/*     */     }
/*     */     public void getBounds(float[] min, float[] max) {
/* 386 */       min[0] = this.x; min[1] = this.y; min[2] = this.z;
/* 387 */       max[0] = this.x; max[1] = this.y; max[2] = this.z;
/*     */     }
/*     */     public float getDistanceSquared(float[] point) {
/* 390 */       float dx = this.x - point[0];
/* 391 */       float dy = this.y - point[1];
/* 392 */       float dz = this.z - point[2];
/* 393 */       return dx * dx + dy * dy + dz * dz;
/*     */     } }
/*     */   private static class Triangle implements RTree.Boxed { float x0; float y0; float z0; float x1; float y1;
/*     */     float z1;
/*     */     float x2;
/*     */     float y2;
/*     */     float z2;
/*     */     
/*     */     Triangle(float size) {
/* 402 */       this.x0 = (1.0F - size) * RTreeTest._random.nextFloat();
/* 403 */       this.y0 = (1.0F - size) * RTreeTest._random.nextFloat();
/* 404 */       this.z0 = (1.0F - size) * RTreeTest._random.nextFloat();
/* 405 */       this.x1 = this.x0 + size * RTreeTest._random.nextFloat();
/* 406 */       this.y1 = this.y0 + size * RTreeTest._random.nextFloat();
/* 407 */       this.z1 = this.z0 + size * RTreeTest._random.nextFloat();
/* 408 */       this.x2 = this.x0 + size * RTreeTest._random.nextFloat();
/* 409 */       this.y2 = this.y0 + size * RTreeTest._random.nextFloat();
/* 410 */       this.z2 = this.z0 + size * RTreeTest._random.nextFloat();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Triangle(float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2) {
/* 417 */       this.x0 = x0; this.y0 = y0; this.z0 = z0;
/* 418 */       this.x1 = x1; this.y1 = y1; this.z1 = z1;
/* 419 */       this.x2 = x2; this.y2 = y2; this.z2 = z2;
/*     */     }
/*     */     public void getBounds(float[] min, float[] max) {
/* 422 */       min[0] = (this.x0 <= this.x1) ? ((this.x0 <= this.x2) ? this.x0 : this.x2) : ((this.x1 <= this.x2) ? this.x1 : this.x2);
/* 423 */       min[1] = (this.y0 <= this.y1) ? ((this.y0 <= this.y2) ? this.y0 : this.y2) : ((this.y1 <= this.y2) ? this.y1 : this.y2);
/* 424 */       min[2] = (this.z0 <= this.z1) ? ((this.z0 <= this.z2) ? this.z0 : this.z2) : ((this.z1 <= this.z2) ? this.z1 : this.z2);
/* 425 */       max[0] = (this.x0 >= this.x1) ? ((this.x0 >= this.x2) ? this.x0 : this.x2) : ((this.x1 >= this.x2) ? this.x1 : this.x2);
/* 426 */       max[1] = (this.y0 >= this.y1) ? ((this.y0 >= this.y2) ? this.y0 : this.y2) : ((this.y1 >= this.y2) ? this.y1 : this.y2);
/* 427 */       max[2] = (this.z0 >= this.z1) ? ((this.z0 >= this.z2) ? this.z0 : this.z2) : ((this.z1 >= this.z2) ? this.z1 : this.z2);
/*     */     }
/*     */     public float getDistanceSquared(float[] point) {
/* 430 */       float q, xp = point[0];
/* 431 */       float yp = point[1];
/* 432 */       float zp = point[2];
/* 433 */       float x0p = this.x0 - xp;
/* 434 */       float y0p = this.y0 - yp;
/* 435 */       float z0p = this.z0 - zp;
/* 436 */       float x10 = this.x1 - this.x0;
/* 437 */       float y10 = this.y1 - this.y0;
/* 438 */       float z10 = this.z1 - this.z0;
/* 439 */       float x20 = this.x2 - this.x0;
/* 440 */       float y20 = this.y2 - this.y0;
/* 441 */       float z20 = this.z2 - this.z0;
/* 442 */       float a = x10 * x10 + y10 * y10 + z10 * z10;
/* 443 */       float b = x10 * x20 + y10 * y20 + z10 * z20;
/* 444 */       float c = x20 * x20 + y20 * y20 + z20 * z20;
/* 445 */       float d = x10 * x0p + y10 * y0p + z10 * z0p;
/* 446 */       float e = x20 * x0p + y20 * y0p + z20 * z0p;
/* 447 */       float f = x0p * x0p + y0p * y0p + z0p * z0p;
/* 448 */       float det = MathPlus.abs(a * c - b * b);
/* 449 */       float s = b * e - c * d;
/* 450 */       float t = b * d - a * e;
/*     */       
/* 452 */       if (s + t <= det) {
/* 453 */         if (s < 0.0F) {
/* 454 */           if (t < 0.0F) {
/* 455 */             if (d < 0.0F) {
/* 456 */               t = 0.0F;
/* 457 */               if (-d >= a) {
/* 458 */                 s = 1.0F;
/* 459 */                 q = a + 2.0F * d + f;
/*     */               } else {
/* 461 */                 s = -d / a;
/* 462 */                 q = d * s + f;
/*     */               } 
/*     */             } else {
/* 465 */               s = 0.0F;
/* 466 */               if (e >= 0.0F) {
/* 467 */                 t = 0.0F;
/* 468 */                 q = f;
/* 469 */               } else if (-e >= c) {
/* 470 */                 t = 1.0F;
/* 471 */                 q = c + 2.0F * e + f;
/*     */               } else {
/* 473 */                 t = -e / c;
/* 474 */                 q = e * t + f;
/*     */               } 
/*     */             } 
/*     */           } else {
/* 478 */             s = 0.0F;
/* 479 */             if (e >= 0.0F) {
/* 480 */               t = 0.0F;
/* 481 */               q = f;
/* 482 */             } else if (-e >= c) {
/* 483 */               t = 1.0F;
/* 484 */               q = c + 2.0F * e + f;
/*     */             } else {
/* 486 */               t = -e / c;
/* 487 */               q = e * t + f;
/*     */             } 
/*     */           } 
/* 490 */         } else if (t < 0.0F) {
/* 491 */           t = 0.0F;
/* 492 */           if (d >= 0.0F) {
/* 493 */             s = 0.0F;
/* 494 */             q = f;
/* 495 */           } else if (-d >= a) {
/* 496 */             s = 1.0F;
/* 497 */             q = a + 2.0F * d + f;
/*     */           } else {
/* 499 */             s = -d / a;
/* 500 */             q = d * s + f;
/*     */           } 
/*     */         } else {
/* 503 */           float odet = 1.0F / det;
/* 504 */           s *= odet;
/* 505 */           t *= odet;
/* 506 */           q = s * (a * s + b * t + 2.0F * d) + t * (b * s + c * t + 2.0F * e) + f;
/*     */         }
/*     */       
/* 509 */       } else if (s < 0.0F) {
/* 510 */         float bd = b + d;
/* 511 */         float ce = c + e;
/* 512 */         if (ce > bd) {
/* 513 */           float num = ce - bd;
/* 514 */           float den = a - 2.0F * b + c;
/* 515 */           if (num >= den) {
/* 516 */             s = 1.0F;
/* 517 */             t = 0.0F;
/* 518 */             q = a + 2.0F * d + f;
/*     */           } else {
/* 520 */             s = num / den;
/* 521 */             t = 1.0F - s;
/* 522 */             q = s * (a * s + b * t + 2.0F * d) + t * (b * s + c * t + 2.0F * e) + f;
/*     */           } 
/*     */         } else {
/* 525 */           s = 0.0F;
/* 526 */           if (ce <= 0.0F) {
/* 527 */             t = 1.0F;
/* 528 */             q = c + 2.0F * e + f;
/* 529 */           } else if (e >= 0.0F) {
/* 530 */             t = 0.0F;
/* 531 */             q = f;
/*     */           } else {
/* 533 */             t = -e / c;
/* 534 */             q = e * t + f;
/*     */           } 
/*     */         } 
/* 537 */       } else if (t < 0.0F) {
/* 538 */         float be = b + e;
/* 539 */         float ad = a + d;
/* 540 */         if (ad > be) {
/* 541 */           float num = ad - be;
/* 542 */           float den = a - 2.0F * b + c;
/* 543 */           if (num >= den) {
/* 544 */             t = 1.0F;
/* 545 */             s = 0.0F;
/* 546 */             q = c + 2.0F * e + f;
/*     */           } else {
/* 548 */             t = num / den;
/* 549 */             s = 1.0F - t;
/* 550 */             q = s * (a * s + b * t + 2.0F * d) + t * (b * s + c * t + 2.0F * e) + f;
/*     */           } 
/*     */         } else {
/* 553 */           t = 0.0F;
/* 554 */           if (ad <= 0.0F) {
/* 555 */             s = 1.0F;
/* 556 */             q = a + 2.0F * d + f;
/* 557 */           } else if (d >= 0.0F) {
/* 558 */             s = 0.0F;
/* 559 */             q = f;
/*     */           } else {
/* 561 */             s = -d / a;
/* 562 */             q = d * s + f;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 566 */         float num = c + e - b - d;
/* 567 */         if (num <= 0.0F) {
/* 568 */           s = 0.0F;
/* 569 */           t = 1.0F;
/* 570 */           q = c + 2.0F * e + f;
/*     */         } else {
/* 572 */           float den = a - 2.0F * b + c;
/* 573 */           if (num >= den) {
/* 574 */             s = 1.0F;
/* 575 */             t = 0.0F;
/* 576 */             q = a + 2.0F * d + f;
/*     */           } else {
/* 578 */             s = num / den;
/* 579 */             t = 1.0F - s;
/* 580 */             q = s * (a * s + b * t + 2.0F * d) + t * (b * s + c * t + 2.0F * e) + f;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 585 */       return q;
/*     */     } }
/*     */ 
/*     */   
/*     */   private Triangle[] makeSurfaceTriangles(int nsurf, int nx, int ny) {
/* 590 */     int nt = nsurf * 2 * nx * ny;
/* 591 */     Triangle[] t = new Triangle[nt];
/* 592 */     float dx = 1.0F / nx;
/* 593 */     float dy = 1.0F / ny;
/* 594 */     for (int isurf = 0, it = 0; isurf < nsurf; isurf++) {
/* 595 */       for (int ix = 0; ix < nx; ix++) {
/* 596 */         float x = ix * dx;
/* 597 */         for (int iy = 0; iy < ny; iy++) {
/* 598 */           float y = iy * dy;
/* 599 */           Point pa = pointOnSurface(isurf, x, y);
/* 600 */           Point pb = pointOnSurface(isurf, x + dx, y);
/* 601 */           Point pc = pointOnSurface(isurf, x + dx, y + dy);
/* 602 */           Point pd = pointOnSurface(isurf, x, y + dy);
/* 603 */           t[it++] = new Triangle(pa.x, pa.y, pa.z, pb.x, pb.y, pb.z, pd.x, pd.y, pd.z);
/* 604 */           t[it++] = new Triangle(pb.x, pb.y, pb.z, pc.x, pc.y, pc.z, pd.x, pd.y, pd.z);
/*     */         } 
/*     */       } 
/*     */     } 
/* 608 */     return t;
/*     */   }
/*     */   
/*     */   private Point[] makeSurfacePoints(int nsurf, int np) {
/* 612 */     Point[] p = new Point[np];
/* 613 */     for (int ip = 0; ip < np; ip++) {
/* 614 */       float x = _random.nextFloat();
/* 615 */       float y = _random.nextFloat();
/* 616 */       int isurf = _random.nextInt(nsurf);
/* 617 */       p[ip] = pointOnSurface(isurf, x, y);
/*     */     } 
/* 619 */     return p;
/*     */   }
/*     */   
/*     */   private Point pointOnSurface(int isurf, float x, float y) {
/* 623 */     float z = 0.1F + isurf * 0.1F + 0.05F * MathPlus.sin(20.0F * x + 20.0F * y);
/* 624 */     return new Point(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point[] makeRandomPoints(int np) {
/* 637 */     Point[] p = new Point[np];
/* 638 */     for (int ip = 0; ip < np; ip++)
/* 639 */       p[ip] = new Point(); 
/* 640 */     return p;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/RTreeTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */