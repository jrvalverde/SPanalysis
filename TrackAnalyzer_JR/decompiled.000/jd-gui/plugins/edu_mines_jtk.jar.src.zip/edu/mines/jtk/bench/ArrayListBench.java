/*    */ package edu.mines.jtk.bench;
/*    */ 
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayListBench
/*    */ {
/*    */   private static final int INITIAL_CAPACITY = 8;
/*    */   
/*    */   static interface ListMaker
/*    */   {
/*    */     void makeList(int param1Int);
/*    */   }
/*    */   
/*    */   public static class FloatList
/*    */   {
/*    */     public int n;
/* 24 */     public float[] a = new float[8];
/*    */     public void add(float f) {
/* 26 */       if (this.n == this.a.length) {
/* 27 */         float[] t = new float[2 * this.a.length];
/* 28 */         for (int i = 0; i < this.n; i++)
/* 29 */           t[i] = this.a[i]; 
/* 30 */         this.a = t;
/*    */       } 
/* 32 */       this.a[this.n++] = f;
/*    */     }
/*    */     public float[] trim() {
/* 35 */       float[] t = new float[this.n];
/* 36 */       for (int i = 0; i < this.n; i++)
/* 37 */         t[i] = this.a[i]; 
/* 38 */       return t;
/*    */     }
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 43 */     double maxtime = 2.0D;
/* 44 */     int n = 10000;
/*    */     
/*    */     while (true) {
/* 47 */       double rate = benchArrayList(maxtime, n);
/* 48 */       System.out.println("ArrayList<Float> rate=" + rate);
/* 49 */       rate = benchFloatList(maxtime, n);
/* 50 */       System.out.println("FloatList        rate=" + rate);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static double benchList(double maxtime, int n, ListMaker lm) {
/* 60 */     Stopwatch sw = new Stopwatch();
/* 61 */     sw.start();
/*    */     int niter;
/* 63 */     for (niter = 0; sw.time() < maxtime; niter++)
/* 64 */       lm.makeList(n); 
/* 65 */     sw.stop();
/* 66 */     double rate = n * niter / sw.time() * 1.0E-6D;
/* 67 */     return rate;
/*    */   }
/*    */   
/*    */   static double benchArrayList(double maxtime, int n) {
/* 71 */     return benchList(maxtime, n, new ListMaker() {
/*    */           public void makeList(int n) {
/* 73 */             ArrayList<Float> list = new ArrayList<Float>(8);
/* 74 */             float f = 0.0F;
/* 75 */             for (int i = 0; i < n; i++) {
/* 76 */               list.add(Float.valueOf(f));
/* 77 */               f++;
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   static double benchFloatList(double maxtime, int n) {
/* 84 */     return benchList(maxtime, n, new ListMaker() {
/*    */           public void makeList(int n) {
/* 86 */             ArrayListBench.FloatList list = new ArrayListBench.FloatList();
/* 87 */             float f = 0.0F;
/* 88 */             for (int i = 0; i < n; i++) {
/* 89 */               list.add(f);
/* 90 */               f++;
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/bench/ArrayListBench.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */