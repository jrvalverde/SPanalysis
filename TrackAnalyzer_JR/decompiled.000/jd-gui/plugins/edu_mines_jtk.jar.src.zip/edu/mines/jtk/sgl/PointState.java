/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PointState
/*     */   implements State
/*     */ {
/*     */   public boolean hasSmooth() {
/*  29 */     return this._smoothSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSmooth() {
/*  37 */     return this._smooth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSmooth(boolean smooth) {
/*  45 */     this._smooth = smooth;
/*  46 */     this._smoothSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSmooth() {
/*  53 */     this._smooth = _smoothDefault;
/*  54 */     this._smoothSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSize() {
/*  62 */     return this._sizeSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSize() {
/*  70 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(float size) {
/*  78 */     this._size = size;
/*  79 */     this._sizeSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetSize() {
/*  86 */     this._size = _sizeDefault;
/*  87 */     this._sizeSet = false;
/*     */   }
/*     */   
/*     */   public void apply() {
/*  91 */     if (this._smoothSet) {
/*  92 */       if (this._smooth) {
/*  93 */         Gl.glEnable(2832);
/*     */       } else {
/*  95 */         Gl.glDisable(2832);
/*     */       } 
/*     */     }
/*  98 */     if (this._sizeSet)
/*  99 */       Gl.glPointSize(this._size); 
/*     */   }
/*     */   
/*     */   public int getAttributeBits() {
/* 103 */     return 8194;
/*     */   }
/*     */   
/*     */   private static boolean _smoothDefault = false;
/* 107 */   private boolean _smooth = _smoothDefault;
/*     */   
/*     */   private boolean _smoothSet;
/* 110 */   private static float _sizeDefault = 1.0F;
/* 111 */   private float _size = _sizeDefault;
/*     */   private boolean _sizeSet;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/PointState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */