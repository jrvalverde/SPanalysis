/*    */ package edu.mines.jtk.sgl.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.sgl.ImagePanelGroup;
/*    */ import edu.mines.jtk.sgl.Node;
/*    */ import edu.mines.jtk.sgl.World;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Float3;
/*    */ import edu.mines.jtk.util.SimpleFloat3;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImagePanelGroupTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     int nx = 101;
/* 24 */     int ny = 121;
/* 25 */     int nz = 141;
/* 26 */     double dx = 1.0D / (nx - 1);
/* 27 */     double dy = dx;
/* 28 */     double dz = dx;
/* 29 */     double fx = 0.0D;
/* 30 */     double fy = 0.0D;
/* 31 */     double fz = 0.0D;
/* 32 */     Sampling sx = new Sampling(nx, dx, fx);
/* 33 */     Sampling sy = new Sampling(ny, dy, fy);
/* 34 */     Sampling sz = new Sampling(nz, dz, fz);
/* 35 */     float kx = 12.566371F * (float)dx;
/* 36 */     float ky = 12.566371F * (float)dy;
/* 37 */     float kz = 12.566371F * (float)dz;
/* 38 */     float[][][] f = Array.sin(Array.rampfloat(0.0F, kz, ky, kx, nz, ny, nx));
/* 39 */     SimpleFloat3 simpleFloat3 = new SimpleFloat3(f);
/* 40 */     ImagePanelGroup ipg = new ImagePanelGroup(sx, sy, sz, (Float3)simpleFloat3);
/* 41 */     ipg.setPercentiles(1.0D, 99.0D);
/* 42 */     World world = new World();
/* 43 */     world.addChild((Node)ipg);
/* 44 */     TestFrame frame = new TestFrame(world);
/* 45 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/ImagePanelGroupTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */