/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.awt.Mode;
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MouseTrackMode
/*     */   extends Mode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Tile _tile;
/*     */   private int _xmouse;
/*     */   private int _ymouse;
/*     */   private MouseListener _ml;
/*     */   private MouseMotionListener _mml;
/*     */   
/*     */   public MouseTrackMode(ModeManager modeManager) {
/*  32 */     super(modeManager);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this._ml = new MouseAdapter() {
/*     */         public void mouseEntered(MouseEvent e) {
/*  70 */           MouseTrackMode.this.beginTracking(e);
/*     */         }
/*     */         public void mouseExited(MouseEvent e) {
/*  73 */           MouseTrackMode.this.endTracking(e);
/*     */         }
/*     */       };
/*     */     
/*  77 */     this._mml = new MouseMotionAdapter() {
/*     */         public void mouseDragged(MouseEvent e) {
/*  79 */           MouseTrackMode.this.duringTracking(e);
/*     */         }
/*     */         
/*  82 */         public void mouseMoved(MouseEvent e) { MouseTrackMode.this.duringTracking(e); }
/*     */       }; setName("Track");
/*     */     setIcon(loadIcon(MouseTrackMode.class, "resources/Track24.gif"));
/*     */     setMnemonicKey(90);
/*     */     setAcceleratorKey(KeyStroke.getKeyStroke(84, 0));
/*  87 */     setShortDescription("Track mouse in tile"); } public boolean isExclusive() { return false; } private void beginTracking(MouseEvent e) { this._xmouse = e.getX();
/*  88 */     this._ymouse = e.getY();
/*  89 */     this._tile = (Tile)e.getSource();
/*  90 */     beginTracking(this._tile.getTileAxisTop(), this._xmouse, this._ymouse);
/*  91 */     beginTracking(this._tile.getTileAxisLeft(), this._xmouse, this._ymouse);
/*  92 */     beginTracking(this._tile.getTileAxisBottom(), this._xmouse, this._ymouse);
/*  93 */     beginTracking(this._tile.getTileAxisRight(), this._xmouse, this._ymouse);
/*  94 */     fireTrack();
/*  95 */     this._tile.addMouseMotionListener(this._mml); }
/*     */   protected void setActive(Component component, boolean active) { if (component instanceof Tile)
/*     */       if (active) { component.addMouseListener(this._ml); } else { component.removeMouseListener(this._ml); }
/*  98 */         } private void beginTracking(TileAxis ta, int x, int y) { if (ta != null)
/*  99 */       ta.beginTracking(x, y);  }
/*     */ 
/*     */   
/*     */   private void duringTracking(MouseEvent e) {
/* 103 */     this._xmouse = e.getX();
/* 104 */     this._ymouse = e.getY();
/* 105 */     this._tile = (Tile)e.getSource();
/* 106 */     duringTracking(this._tile.getTileAxisTop(), this._xmouse, this._ymouse);
/* 107 */     duringTracking(this._tile.getTileAxisLeft(), this._xmouse, this._ymouse);
/* 108 */     duringTracking(this._tile.getTileAxisBottom(), this._xmouse, this._ymouse);
/* 109 */     duringTracking(this._tile.getTileAxisRight(), this._xmouse, this._ymouse);
/* 110 */     fireTrack();
/*     */   }
/*     */   private void duringTracking(TileAxis ta, int x, int y) {
/* 113 */     if (ta != null)
/* 114 */       ta.duringTracking(x, y); 
/*     */   }
/*     */   
/*     */   private void endTracking(MouseEvent e) {
/* 118 */     this._tile.removeMouseMotionListener(this._mml);
/* 119 */     endTracking(this._tile.getTileAxisTop());
/* 120 */     endTracking(this._tile.getTileAxisLeft());
/* 121 */     endTracking(this._tile.getTileAxisBottom());
/* 122 */     endTracking(this._tile.getTileAxisRight());
/* 123 */     fireTrack();
/* 124 */     this._tile = null;
/*     */   }
/*     */   private void endTracking(TileAxis ta) {
/* 127 */     if (ta != null)
/* 128 */       ta.endTracking(); 
/*     */   }
/*     */   
/*     */   private void fireTrack() {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/MouseTrackMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */