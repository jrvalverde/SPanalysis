/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.SincInterpolator;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SincInterpolatorTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  28 */     TestSuite suite = new TestSuite(SincInterpolatorTest.class);
/*  29 */     TestRunner.run((Test)suite);
/*     */   }
/*     */ 
/*     */   
/*  33 */   private double[] _emaxs = new double[] { 0.1D, 0.01D, 0.001D };
/*  34 */   private double[] _fmaxs = new double[] { 0.1D, 0.3D, 0.4D, 0.45D };
/*  35 */   private int[] _lmaxs = new int[] { 8, 10, 12, 14, 16 };
/*     */   
/*     */   public void testKenLarner() {
/*  38 */     for (int lmax = 8; lmax <= 16; lmax += 2) {
/*  39 */       trace("testKenLarner: lmax=" + lmax);
/*  40 */       SincInterpolator si = SincInterpolator.fromKenLarner(lmax);
/*  41 */       testInterpolator(si);
/*  42 */       double fmax = si.getMaximumFrequency();
/*  43 */       si = SincInterpolator.fromFrequencyAndLength(fmax, lmax);
/*  44 */       testInterpolator(si);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testExtrapolation() {
/*  49 */     SincInterpolator si = new SincInterpolator();
/*  50 */     Random random = new Random();
/*  51 */     int lmax = si.getMaximumLength();
/*  52 */     int nxu = 2 * lmax;
/*  53 */     int npad = lmax;
/*  54 */     double dxu = 1.0D;
/*  55 */     double fxu = npad;
/*  56 */     int nx = npad + nxu + npad;
/*  57 */     double dx = 0.999D;
/*  58 */     double fx = npad;
/*  59 */     float[] yi = new float[nxu];
/*  60 */     float[] yz = new float[nx];
/*  61 */     float[] yc = new float[nx];
/*  62 */     float[] yo = new float[nx];
/*  63 */     float[] yt = new float[nx];
/*  64 */     for (int ixu = 0; ixu < nxu; ixu++) {
/*  65 */       yc[ixu + npad] = random.nextFloat(); yz[ixu + npad] = random.nextFloat(); yi[ixu] = random.nextFloat();
/*  66 */     }  for (int ipad = 0; ipad < npad; ipad++) {
/*  67 */       yc[ipad] = yc[npad];
/*  68 */       yc[npad + nxu + ipad] = yc[npad + nxu - 1];
/*     */     } 
/*  70 */     si.setExtrapolation(SincInterpolator.Extrapolation.ZERO);
/*  71 */     si.setUniform(nxu, dxu, fxu, yi);
/*  72 */     si.interpolate(nx, dx, fx, yo);
/*  73 */     si.setUniform(npad + nxu + npad, dxu, 0.0D, yz);
/*  74 */     si.interpolate(nx, dx, fx, yt); int ix;
/*  75 */     for (ix = 0; ix < nx; ix++)
/*  76 */       assertEquals(yo[ix], yt[ix], 0.0D); 
/*  77 */     si.setExtrapolation(SincInterpolator.Extrapolation.CONSTANT);
/*  78 */     si.setUniform(nxu, dxu, fxu, yi);
/*  79 */     si.interpolate(nx, dx, fx, yo);
/*  80 */     si.setUniform(npad + nxu + npad, dxu, 0.0D, yc);
/*  81 */     si.interpolate(nx, dx, fx, yt);
/*  82 */     for (ix = 0; ix < nx; ix++)
/*  83 */       assertEquals(yo[ix], yt[ix], 0.0D); 
/*     */   }
/*     */   
/*     */   public void testComplex() {
/*  87 */     SincInterpolator si = new SincInterpolator();
/*  88 */     Random random = new Random();
/*  89 */     int nxu = 100;
/*  90 */     double dxu = 3.14159D;
/*  91 */     double fxu = 1.23456D;
/*  92 */     float[] yr = new float[nxu];
/*  93 */     float[] yi = new float[nxu];
/*  94 */     float[] yc = new float[2 * nxu];
/*  95 */     for (int ixu = 0; ixu < nxu; ixu++) {
/*  96 */       yc[2 * ixu] = random.nextFloat(); yr[ixu] = random.nextFloat();
/*  97 */       yc[2 * ixu + 1] = random.nextFloat(); yi[ixu] = random.nextFloat();
/*     */     } 
/*  99 */     si.setUniformSampling(nxu, dxu, fxu);
/* 100 */     int nx = 200;
/* 101 */     double dx = -0.9D * dxu;
/* 102 */     double fx = fxu + (nxu + 30) * dxu;
/* 103 */     float[] zr = new float[nx];
/* 104 */     float[] zi = new float[nx];
/* 105 */     float[] zc = new float[2 * nx];
/* 106 */     si.setExtrapolation(SincInterpolator.Extrapolation.ZERO);
/* 107 */     si.setUniformSamples(yr);
/* 108 */     si.interpolate(nx, dx, fx, zr);
/* 109 */     si.setUniformSamples(yi);
/* 110 */     si.interpolate(nx, dx, fx, zi);
/* 111 */     si.setUniformSamples(yc);
/* 112 */     si.interpolateComplex(nx, dx, fx, zc); int ix;
/* 113 */     for (ix = 0; ix < nx; ix++) {
/* 114 */       assertEquals(zr[ix], zc[2 * ix], 0.0D);
/* 115 */       assertEquals(zi[ix], zc[2 * ix + 1], 0.0D);
/*     */     } 
/* 117 */     si.setExtrapolation(SincInterpolator.Extrapolation.CONSTANT);
/* 118 */     si.setUniformSamples(yr);
/* 119 */     si.interpolate(nx, dx, fx, zr);
/* 120 */     si.setUniformSamples(yi);
/* 121 */     si.interpolate(nx, dx, fx, zi);
/* 122 */     si.setUniformSamples(yc);
/* 123 */     si.interpolateComplex(nx, dx, fx, zc);
/* 124 */     for (ix = 0; ix < nx; ix++) {
/* 125 */       assertEquals(zr[ix], zc[2 * ix], 0.0D);
/* 126 */       assertEquals(zi[ix], zc[2 * ix + 1], 0.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testErrorAndFrequency() {
/* 131 */     for (int iemax = 0; iemax < this._emaxs.length; iemax++) {
/* 132 */       double emax = this._emaxs[iemax];
/* 133 */       for (int ifmax = 0; ifmax < this._fmaxs.length; ifmax++) {
/* 134 */         double fmax = this._fmaxs[ifmax];
/* 135 */         SincInterpolator si = SincInterpolator.fromErrorAndFrequency(emax, fmax);
/*     */         
/* 137 */         testInterpolator(si);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testErrorAndLength() {
/* 143 */     for (int iemax = 0; iemax < this._emaxs.length; iemax++) {
/* 144 */       double emax = this._emaxs[iemax];
/* 145 */       for (int ilmax = 0; ilmax < this._lmaxs.length; ilmax++) {
/* 146 */         int lmax = this._lmaxs[ilmax];
/* 147 */         SincInterpolator si = SincInterpolator.fromErrorAndLength(emax, lmax);
/*     */         
/* 149 */         testInterpolator(si);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void testFrequencyAndLength() {
/* 155 */     for (int ifmax = 0; ifmax < this._fmaxs.length; ifmax++) {
/* 156 */       double fmax = this._fmaxs[ifmax];
/* 157 */       for (int ilmax = 0; ilmax < this._lmaxs.length; ilmax++) {
/* 158 */         int lmax = this._lmaxs[ilmax];
/* 159 */         if ((1.0D - 2.0D * fmax) * lmax > 1.0D) {
/* 160 */           SincInterpolator si = SincInterpolator.fromFrequencyAndLength(fmax, lmax);
/*     */           
/* 162 */           testInterpolator(si);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testAccumulate() {
/* 170 */     Random random = new Random(123456L);
/* 171 */     for (int repeat = 0; repeat < 5; repeat++) {
/*     */       
/* 173 */       for (SincInterpolator.Extrapolation extrapolation : SincInterpolator.Extrapolation.values()) {
/* 174 */         int nxu = 201;
/* 175 */         double fxu = Math.PI;
/* 176 */         double dxu = Math.E;
/* 177 */         double exu = fxu + dxu * (nxu - 1);
/* 178 */         float[] yu = new float[nxu];
/* 179 */         for (int i = 0; i < nxu; i++) {
/* 180 */           yu[i] = 2.0F * random.nextFloat() - 1.0F;
/*     */         }
/*     */         
/* 183 */         int nx = 2 * nxu;
/* 184 */         float[] x = new float[nx];
/* 185 */         float[] y = new float[nx];
/* 186 */         for (int j = 0; j < nxu; j++) {
/* 187 */           x[j] = (float)((1.2D * random.nextFloat() - 0.1D) * (exu - fxu) + fxu);
/* 188 */           y[j] = 2.0F * random.nextFloat() - 1.0F;
/*     */         } 
/*     */ 
/*     */         
/* 192 */         SincInterpolator si = new SincInterpolator();
/* 193 */         si.setExtrapolation(extrapolation);
/* 194 */         si.setUniformSampling(nxu, dxu, fxu);
/*     */ 
/*     */         
/* 197 */         float[] yi = new float[nx];
/* 198 */         si.setUniformSamples(yu);
/* 199 */         si.interpolate(nx, x, yi);
/*     */ 
/*     */         
/* 202 */         float[] ya = new float[nxu];
/* 203 */         si.setUniformSamples(ya);
/* 204 */         si.accumulate(nx, x, y);
/*     */ 
/*     */         
/* 207 */         double yuYa = 0.0D;
/* 208 */         for (int ixu = 0; ixu < nxu; ixu++) {
/* 209 */           yuYa += (yu[ixu] * ya[ixu]);
/*     */         }
/* 211 */         double yYi = 0.0D;
/* 212 */         for (int ix = 0; ix < nx; ix++) {
/* 213 */           yYi += (y[ix] * yi[ix]);
/*     */         }
/* 215 */         double ratio = yuYa / yYi;
/* 216 */         String message = "yu.ya=" + yuYa + " y.yi=" + yYi + " ratio=" + ratio;
/*     */         
/* 218 */         trace(message);
/* 219 */         assert ratio > 0.99999D && ratio < 1.00001D : message;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void testInterpolator(SincInterpolator si) {
/* 225 */     testInterpolatorWithSweep(si);
/*     */   }
/*     */   
/*     */   private void testInterpolatorWithSweep(SincInterpolator si) {
/* 229 */     double emax = si.getMaximumError();
/* 230 */     double fmax = si.getMaximumFrequency();
/* 231 */     int lmax = si.getMaximumLength();
/* 232 */     long nbytes = si.getTableBytes();
/* 233 */     trace("lmax=" + lmax + " fmax=" + fmax + " emax=" + emax + " nbytes=" + nbytes);
/*     */ 
/*     */     
/* 236 */     int nmax = (int)(1000.0D * fmax);
/* 237 */     double xmax = Math.PI * nmax / fmax;
/* 238 */     double dxu = 1.0D;
/* 239 */     double fxu = 0.0D;
/* 240 */     int nxu = 1 + (int)((xmax - fxu) / dxu);
/* 241 */     dxu = (xmax - fxu) / (nxu - 1);
/* 242 */     float[] yu = new float[nxu];
/* 243 */     for (int ixu = 0; ixu < nxu; ixu++) {
/* 244 */       double x = fxu + ixu * dxu;
/* 245 */       yu[ixu] = (float)sweep(fmax, nmax, x);
/*     */     } 
/* 247 */     si.setUniform(nxu, dxu, fxu, yu);
/* 248 */     si.setExtrapolation(SincInterpolator.Extrapolation.CONSTANT);
/*     */ 
/*     */ 
/*     */     
/* 252 */     double dx = 0.01D * dxu;
/* 253 */     double fx = 0.0D;
/* 254 */     int nx = 1 + (int)((xmax - fx) / dx);
/* 255 */     dx = (xmax - fx) / (nx - 1);
/* 256 */     float[] y = new float[nx];
/* 257 */     si.interpolate(nx, dx, fx, y);
/*     */ 
/*     */     
/* 260 */     double error = 0.0D;
/* 261 */     for (int ix = 0; ix < nx; ix++) {
/* 262 */       double x = fx + ix * dx;
/* 263 */       double yi = y[ix];
/* 264 */       double ys = sweep(fmax, nmax, x);
/* 265 */       double ei = Math.abs(yi - ys);
/* 266 */       if (ei > emax)
/* 267 */         trace("    x=" + x + " ys=" + ys + " yi=" + yi); 
/* 268 */       error = Math.max(error, ei);
/* 269 */       assertEquals(ys, yi, emax);
/*     */     } 
/* 271 */     trace("  error=" + error);
/* 272 */     if (error > emax) {
/* 273 */       trace("  WARNING: error = " + error + " > emax = " + emax);
/*     */     }
/*     */     
/* 276 */     double shift = 0.5D * dxu;
/* 277 */     nx = nxu;
/* 278 */     dx = dxu;
/* 279 */     fx = fxu + shift;
/* 280 */     si.interpolate(nx, dx, fx, y);
/* 281 */     error = 0.0D;
/* 282 */     for (int i = 0; i < nx; i++) {
/* 283 */       double x = fx + i * dx;
/* 284 */       double yi = y[i];
/* 285 */       double ys = sweep(fmax, nmax, x);
/* 286 */       double ei = Math.abs(yi - ys);
/* 287 */       if (ei > emax)
/* 288 */         trace("    x=" + x + " ys=" + ys + " yi=" + yi); 
/* 289 */       error = Math.max(error, ei);
/* 290 */       assertEquals(ys, yi, emax);
/*     */     } 
/* 292 */     trace("  error=" + error);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double sweep(double fmax, int nmax, double x) {
/* 301 */     return Math.cos(6.283185307179586D * nmax * Math.cos(x * fmax / nmax));
/*     */   }
/*     */   
/*     */   private static void trace(String s) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/SincInterpolatorTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */