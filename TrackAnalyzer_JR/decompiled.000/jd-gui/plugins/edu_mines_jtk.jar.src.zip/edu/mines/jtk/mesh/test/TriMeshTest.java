/*     */ package edu.mines.jtk.mesh.test;
/*     */ 
/*     */ import edu.mines.jtk.mesh.TriMesh;
/*     */ import edu.mines.jtk.util.Stopwatch;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Random;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TriMeshTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  24 */     TestSuite suite = new TestSuite(TriMeshTest.class);
/*  25 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testNabors() {
/*  29 */     TriMesh tm = new TriMesh();
/*  30 */     TriMesh.Node n0 = new TriMesh.Node(1.0F, 0.0F);
/*  31 */     TriMesh.Node n1 = new TriMesh.Node(0.0F, 1.0F);
/*  32 */     TriMesh.Node n2 = new TriMesh.Node(0.0F, 0.0F);
/*  33 */     TriMesh.Node n3 = new TriMesh.Node(1.1F, 1.1F);
/*  34 */     tm.addNode(n0);
/*  35 */     tm.addNode(n1);
/*  36 */     tm.addNode(n2);
/*  37 */     tm.addNode(n3);
/*  38 */     assertEquals(2, (tm.getTriNabors(n0)).length);
/*  39 */     assertEquals(2, (tm.getTriNabors(n1)).length);
/*  40 */     assertEquals(1, (tm.getTriNabors(n2)).length);
/*  41 */     assertEquals(1, (tm.getTriNabors(n3)).length);
/*  42 */     assertEquals(2, (tm.getTriNabors(tm.findEdge(n0, n1))).length);
/*  43 */     assertEquals(1, (tm.getTriNabors(tm.findEdge(n0, n2))).length);
/*  44 */     assertEquals(1, (tm.getTriNabors(tm.findEdge(n1, n2))).length);
/*  45 */     assertEquals(1, (tm.getTriNabors(tm.findEdge(n0, n3))).length);
/*  46 */     assertEquals(1, (tm.getTriNabors(tm.findEdge(n1, n3))).length);
/*  47 */     assertEquals(3, (tm.getEdgeNabors(n0)).length);
/*  48 */     assertEquals(3, (tm.getEdgeNabors(n1)).length);
/*  49 */     assertEquals(2, (tm.getEdgeNabors(n2)).length);
/*  50 */     assertEquals(2, (tm.getEdgeNabors(n3)).length);
/*  51 */     assertEquals(3, (tm.getNodeNabors(n0)).length);
/*  52 */     assertEquals(3, (tm.getNodeNabors(n1)).length);
/*  53 */     assertEquals(2, (tm.getNodeNabors(n2)).length);
/*  54 */     assertEquals(2, (tm.getNodeNabors(n3)).length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void testIO() throws IOException, ClassNotFoundException {
/*  60 */     TriMesh.Node n00 = new TriMesh.Node(0.0F, 0.0F);
/*  61 */     TriMesh.Node n01 = new TriMesh.Node(0.0F, 1.0F);
/*  62 */     TriMesh.Node n10 = new TriMesh.Node(1.0F, 0.0F);
/*  63 */     TriMesh.Node n11 = new TriMesh.Node(1.0F, 1.0F);
/*  64 */     TriMesh tm = new TriMesh();
/*  65 */     tm.addNode(n00);
/*  66 */     tm.addNode(n01);
/*  67 */     tm.addNode(n10);
/*  68 */     tm.addNode(n11);
/*  69 */     int nnode = tm.countNodes();
/*  70 */     int ntri = tm.countTris();
/*  71 */     assertEquals(4, nnode);
/*  72 */     TriMesh.NodePropertyMap map = tm.getNodePropertyMap("foo");
/*  73 */     map.put(n00, new Integer(0));
/*  74 */     map.put(n01, new Integer(1));
/*  75 */     map.put(n10, new Integer(2));
/*  76 */     map.put(n11, new Integer(3));
/*     */ 
/*     */     
/*  79 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  80 */     ObjectOutputStream oos = new ObjectOutputStream(baos);
/*  81 */     oos.writeObject(tm);
/*  82 */     baos.close();
/*  83 */     ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
/*  84 */     ObjectInputStream ois = new ObjectInputStream(bais);
/*  85 */     tm = (TriMesh)ois.readObject();
/*  86 */     bais.close();
/*  87 */     assertEquals(nnode, tm.countNodes());
/*  88 */     assertEquals(ntri, tm.countTris());
/*     */ 
/*     */     
/*  91 */     String name = tm.getNodePropertyMapNames()[0];
/*  92 */     assertEquals("foo", name);
/*  93 */     map = tm.getNodePropertyMap(name);
/*  94 */     n00 = tm.findNodeNearest(0.0F, 0.0F);
/*  95 */     n01 = tm.findNodeNearest(0.0F, 1.0F);
/*  96 */     n10 = tm.findNodeNearest(1.0F, 0.0F);
/*  97 */     n11 = tm.findNodeNearest(1.0F, 1.0F);
/*  98 */     assertEquals(0, ((Integer)map.get(n00)).intValue());
/*  99 */     assertEquals(1, ((Integer)map.get(n01)).intValue());
/* 100 */     assertEquals(2, ((Integer)map.get(n10)).intValue());
/* 101 */     assertEquals(3, ((Integer)map.get(n11)).intValue());
/*     */   }
/*     */   
/*     */   public void testTriListener() {
/* 105 */     TriMesh tm = new TriMesh();
/* 106 */     tm.addNode(new TriMesh.Node(0.0F, 0.0F));
/* 107 */     tm.addNode(new TriMesh.Node(1.0F, 0.0F));
/* 108 */     tm.addNode(new TriMesh.Node(0.0F, 1.0F));
/* 109 */     TriListener tl = new TriListener();
/* 110 */     tm.addTriListener(tl);
/* 111 */     TriMesh.Node node = new TriMesh.Node(0.1F, 0.1F);
/* 112 */     tm.addNode(node);
/* 113 */     assertEquals(3, tl.countAdded());
/* 114 */     assertEquals(1, tl.countRemoved());
/* 115 */     tm.removeNode(node);
/* 116 */     assertEquals(4, tl.countAdded());
/* 117 */     assertEquals(4, tl.countRemoved());
/*     */   }
/*     */   private static class TriListener implements TriMesh.TriListener { private int _nadded;
/*     */     public void triAdded(TriMesh mesh, TriMesh.Tri tri) {
/* 121 */       this._nadded++;
/*     */     } private int _nremoved; private TriListener() {}
/*     */     public void triRemoved(TriMesh mesh, TriMesh.Tri tri) {
/* 124 */       this._nremoved++;
/*     */     }
/*     */     public int countAdded() {
/* 127 */       return this._nadded;
/*     */     }
/*     */     public int countRemoved() {
/* 130 */       return this._nremoved;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testSimple() {
/* 137 */     TriMesh tm = new TriMesh();
/* 138 */     TriMesh.Node n0 = new TriMesh.Node(0.0F, 0.0F);
/* 139 */     TriMesh.Node n1 = new TriMesh.Node(1.0F, 0.0F);
/* 140 */     TriMesh.Node n2 = new TriMesh.Node(0.0F, 1.0F);
/* 141 */     TriMesh.Node n3 = new TriMesh.Node(0.3F, 0.3F);
/* 142 */     tm.addNode(n0);
/* 143 */     tm.addNode(n1);
/* 144 */     tm.addNode(n2);
/* 145 */     tm.addNode(n3);
/* 146 */     tm.removeNode(n3);
/* 147 */     tm.validate();
/*     */   }
/*     */   
/*     */   public void testSquare() {
/* 151 */     TriMesh tm = new TriMesh();
/* 152 */     TriMesh.Node n0 = new TriMesh.Node(0.0F, 0.0F);
/* 153 */     TriMesh.Node n1 = new TriMesh.Node(1.0F, 0.0F);
/* 154 */     TriMesh.Node n2 = new TriMesh.Node(0.0F, 1.0F);
/* 155 */     TriMesh.Node n3 = new TriMesh.Node(1.0F, 1.0F);
/* 156 */     tm.addNode(n0);
/* 157 */     tm.addNode(n1);
/* 158 */     tm.addNode(n2);
/* 159 */     tm.addNode(n3);
/* 160 */     tm.removeNode(n3);
/* 161 */     tm.removeNode(n2);
/* 162 */     tm.removeNode(n1);
/* 163 */     tm.removeNode(n0);
/* 164 */     tm.validate();
/*     */   }
/*     */   
/*     */   public void testAddFindRemove() {
/* 168 */     Random random = new Random();
/* 169 */     TriMesh tm = new TriMesh();
/* 170 */     int nadd = 0;
/* 171 */     int nremove = 0;
/* 172 */     for (int niter = 0; niter < 1000; niter++) {
/* 173 */       float x = random.nextFloat();
/* 174 */       float y = random.nextFloat();
/* 175 */       if (tm.countNodes() < 10 || random.nextFloat() > 0.5F) {
/* 176 */         TriMesh.Node node = new TriMesh.Node(x, y);
/* 177 */         boolean ok = tm.addNode(node);
/* 178 */         assertTrue(ok);
/* 179 */         tm.validate();
/* 180 */         nadd++;
/* 181 */       } else if (tm.countNodes() > 0) {
/* 182 */         TriMesh.Node node = tm.findNodeNearest(x, y);
/* 183 */         assertTrue((node != null));
/* 184 */         TriMesh.Node nodeSlow = tm.findNodeNearestSlow(x, y);
/* 185 */         assertTrue((node == nodeSlow));
/* 186 */         tm.removeNode(node);
/* 187 */         tm.validate();
/* 188 */         nremove++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void benchAddNode() {
/* 195 */     Random random = new Random();
/* 196 */     for (int itest = 0; itest < 3; itest++) {
/* 197 */       for (int nnode = 1000; nnode <= 64000; nnode *= 2) {
/* 198 */         Stopwatch sw = new Stopwatch();
/* 199 */         sw.restart();
/* 200 */         TriMesh tm = new TriMesh();
/* 201 */         for (int inode = 0; inode < nnode; inode++) {
/* 202 */           float x = random.nextFloat();
/* 203 */           float y = random.nextFloat();
/* 204 */           TriMesh.Node node = new TriMesh.Node(x, y);
/* 205 */           tm.addNode(node);
/*     */         } 
/* 207 */         sw.stop();
/* 208 */         System.out.println("Added " + nnode + " nodes to make " + tm.countTris() + " tris in " + sw.time() + " seconds.");
/*     */ 
/*     */         
/* 211 */         tm.validate();
/*     */       } 
/*     */       try {
/* 214 */         System.out.println("Sleeping");
/* 215 */         Thread.sleep(5000L, 0);
/* 216 */       } catch (InterruptedException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void benchFind() {
/* 222 */     int nnode = 1000;
/* 223 */     int nfind = 10000;
/* 224 */     int ntest = 3;
/* 225 */     Random random = new Random();
/* 226 */     Stopwatch sw = new Stopwatch();
/* 227 */     TriMesh tm = new TriMesh();
/* 228 */     for (int inode = 0; inode < nnode; inode++) {
/* 229 */       float x = random.nextFloat();
/* 230 */       float y = random.nextFloat();
/* 231 */       TriMesh.Node node = new TriMesh.Node(x, y);
/* 232 */       tm.addNode(node);
/*     */     } 
/* 234 */     for (int itest = 0; itest < ntest; itest++) {
/* 235 */       float[] x = new float[nfind];
/* 236 */       float[] y = new float[nfind];
/* 237 */       for (int ifind = 0; ifind < nfind; ifind++) {
/* 238 */         x[ifind] = random.nextFloat();
/* 239 */         y[ifind] = random.nextFloat();
/*     */       } 
/* 241 */       TriMesh.Node[] nfast = new TriMesh.Node[nfind];
/* 242 */       sw.reset();
/* 243 */       sw.start();
/* 244 */       for (int i = 0; i < nfind; i++)
/* 245 */         nfast[i] = tm.findNodeNearest(x[i], y[i]); 
/* 246 */       sw.stop();
/* 247 */       int sfast = (int)(nfind / sw.time());
/* 248 */       TriMesh.Node[] nslow = new TriMesh.Node[nfind];
/* 249 */       sw.reset();
/* 250 */       sw.start();
/* 251 */       for (int j = 0; j < nfind; j++)
/* 252 */         nslow[j] = tm.findNodeNearestSlow(x[j], y[j]); 
/* 253 */       sw.stop();
/* 254 */       int sslow = (int)(nfind / sw.time());
/* 255 */       for (int k = 0; k < nfind; k++) {
/* 256 */         if (nfast[k] != nslow[k]) {
/* 257 */           float xfast = nfast[k].x();
/* 258 */           float yfast = nfast[k].y();
/* 259 */           float xslow = nslow[k].x();
/* 260 */           float yslow = nslow[k].y();
/* 261 */           float dxfast = xfast - x[k];
/* 262 */           float dyfast = yfast - y[k];
/* 263 */           float dxslow = xslow - x[k];
/* 264 */           float dyslow = yslow - y[k];
/* 265 */           float dsfast = dxfast * dxfast + dyfast * dyfast;
/* 266 */           float dsslow = dxslow * dxslow + dyslow * dyslow;
/* 267 */           System.out.println("ifind=" + k + " fast/slow=" + dsfast + "/" + dsslow);
/*     */         } 
/* 269 */         assertTrue((nfast[k] == nslow[k]));
/*     */       } 
/* 271 */       System.out.println("Find fast/slow nodes per sec = " + sfast + "/" + sslow);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mesh/test/TriMeshTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */