/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SamplingTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  21 */     TestSuite suite = new TestSuite(SamplingTest.class);
/*  22 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void testUniform() {
/*  26 */     int n = 1000;
/*  27 */     double d = 0.3333333333333333D;
/*  28 */     double f = 0.16666666666666666D;
/*  29 */     double tiny = d * 1.0E-6D;
/*  30 */     double[] v = new double[n];
/*  31 */     double vi = f;
/*  32 */     for (int i = 0; i < n; i++, vi += d)
/*  33 */       v[i] = vi; 
/*  34 */     Sampling us = new Sampling(n, d, f);
/*  35 */     Sampling vs = new Sampling(v);
/*     */     
/*  37 */     assertTrue(us.isUniform());
/*  38 */     assertTrue(vs.isUniform());
/*  39 */     assertTrue(us.isEquivalentTo(vs));
/*     */     
/*  41 */     for (int j = 0; j < n; j++, vi += d) {
/*  42 */       int k = us.indexOf(v[j]);
/*  43 */       assertEquals(j, k);
/*  44 */       k = vs.indexOf(v[j]);
/*  45 */       assertEquals(j, k);
/*     */     } 
/*     */     
/*  48 */     int[] overlap = us.overlapWith(vs);
/*  49 */     assertEquals(n, overlap[0]);
/*  50 */     assertEquals(0, overlap[1]);
/*  51 */     assertEquals(0, overlap[2]);
/*     */     
/*  53 */     Sampling sm = us.mergeWith(vs);
/*  54 */     assertTrue(sm.isEquivalentTo(us));
/*  55 */     assertTrue(sm.isEquivalentTo(vs));
/*     */     
/*  57 */     Sampling sr = us.shift(10.0D * d);
/*  58 */     overlap = us.overlapWith(sr);
/*  59 */     assertEquals(n - 10, overlap[0]);
/*  60 */     assertEquals(10, overlap[1]);
/*  61 */     assertEquals(0, overlap[2]);
/*     */     
/*  63 */     Sampling sl = us.shift(-10.0D * d);
/*  64 */     overlap = us.overlapWith(sl);
/*  65 */     assertEquals(n - 10, overlap[0]);
/*  66 */     assertEquals(0, overlap[1]);
/*  67 */     assertEquals(10, overlap[2]);
/*     */     
/*  69 */     sr = us.shift(n * d);
/*  70 */     overlap = us.overlapWith(sr);
/*  71 */     assertEquals(0, overlap[0]);
/*  72 */     assertEquals(n, overlap[1]);
/*  73 */     assertEquals(0, overlap[2]);
/*     */     
/*  75 */     sl = us.shift(-n * d);
/*  76 */     overlap = us.overlapWith(sl);
/*  77 */     assertEquals(0, overlap[0]);
/*  78 */     assertEquals(0, overlap[1]);
/*  79 */     assertEquals(n, overlap[2]);
/*     */     
/*  81 */     sm = us.mergeWith(sr);
/*  82 */     sm = sm.mergeWith(sl);
/*  83 */     assertEquals(n * 3, sm.getCount());
/*  84 */     assertTrue(sm.isUniform());
/*     */     
/*  86 */     sr = us.shift((2 * n) * d);
/*  87 */     sm = us.mergeWith(sr);
/*  88 */     assertEquals(n * 2, sm.getCount());
/*  89 */     assertTrue(!sm.isUniform());
/*     */     
/*  91 */     Sampling sp = us.prepend(100);
/*  92 */     assertEquals(n + 100, sp.getCount());
/*  93 */     assertEquals(f - 100.0D * d, sp.getFirst(), tiny);
/*     */     
/*  95 */     Sampling sa = us.append(100);
/*  96 */     assertEquals(n + 100, sa.getCount());
/*  97 */     assertEquals(f, sa.getFirst(), tiny);
/*     */     
/*  99 */     Sampling sd = us.decimate(3);
/* 100 */     assertEquals(1 + (n - 1) / 3, sd.getCount());
/* 101 */     assertEquals(d * 3.0D, sd.getDelta(), tiny);
/* 102 */     assertEquals(f, sd.getFirst(), tiny);
/*     */     
/* 104 */     Sampling si = us.interpolate(3);
/* 105 */     assertEquals(1 + (n - 1) * 3, si.getCount());
/* 106 */     assertEquals(d / 3.0D, si.getDelta(), tiny);
/* 107 */     assertEquals(f, si.getFirst(), tiny);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/SamplingTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */