/*     */ package edu.mines.jtk.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AxisTics
/*     */ {
/*     */   private double _xmin;
/*     */   private double _xmax;
/*     */   private int _mtic;
/*     */   private int _ntic;
/*     */   private double _dtic;
/*     */   private double _ftic;
/*     */   private int _nticMinor;
/*     */   private double _dticMinor;
/*     */   private double _fticMinor;
/*     */   
/*     */   public AxisTics(double x1, double x2, double dtic) {
/*  50 */     double xmin = MathPlus.min(x1, x2);
/*  51 */     double xmax = MathPlus.max(x1, x2);
/*  52 */     xmin -= (xmax - xmin) * 1.1920928955078125E-7D;
/*  53 */     xmax += (xmax - xmin) * 1.1920928955078125E-7D;
/*  54 */     double d = MathPlus.abs(dtic);
/*  55 */     double f = MathPlus.ceil(xmin / d) * d;
/*     */ 
/*     */ 
/*     */     
/*  59 */     int n = 1 + (int)((xmax - f) / d);
/*  60 */     this._xmin = xmin;
/*  61 */     this._xmax = xmax;
/*  62 */     this._ntic = n;
/*  63 */     this._dtic = d;
/*  64 */     this._ftic = f;
/*  65 */     computeMultiple();
/*  66 */     computeMinorTics();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisTics(double x1, double x2, int ntic) {
/*  76 */     double xmin = this._xmin = MathPlus.min(x1, x2);
/*  77 */     double xmax = this._xmax = MathPlus.max(x1, x2);
/*  78 */     xmin -= (xmax - xmin) * 1.1920928955078125E-7D;
/*  79 */     xmax += (xmax - xmin) * 1.1920928955078125E-7D;
/*  80 */     int nmax = (ntic >= 2) ? ntic : 2;
/*  81 */     double dmax = (xmax - xmin) / (nmax - 1);
/*  82 */     int nmult = _mult.length;
/*  83 */     int nbest = 0;
/*  84 */     int mbest = 0;
/*  85 */     double dbest = 0.0D;
/*  86 */     double fbest = 0.0D;
/*  87 */     for (int imult = 0; imult < nmult; imult++) {
/*  88 */       int m = _mult[imult];
/*  89 */       int l = (int)MathPlus.floor(MathPlus.log10(dmax / m));
/*  90 */       double d = m * MathPlus.pow(10.0D, l);
/*  91 */       double f = MathPlus.ceil(xmin / d) * d;
/*  92 */       int n = 1 + (int)((xmax - f) / d);
/*  93 */       if (n > nmax) {
/*  94 */         d *= 10.0D;
/*  95 */         f = MathPlus.ceil(xmin / d) * d;
/*  96 */         n = 1 + (int)((xmax - f) / d);
/*     */       } 
/*  98 */       if (nbest < n && n <= ntic) {
/*  99 */         nbest = n;
/* 100 */         mbest = m;
/* 101 */         dbest = d;
/* 102 */         fbest = f;
/*     */       } 
/*     */     } 
/* 105 */     nbest = 1 + (int)((xmax - fbest) / dbest);
/* 106 */     if (nbest < 2) {
/* 107 */       this._ntic = 2;
/* 108 */       this._dtic = this._xmax - this._xmin;
/* 109 */       this._ftic = this._xmin;
/* 110 */       computeMultiple();
/*     */     } else {
/* 112 */       this._ntic = nbest;
/* 113 */       this._dtic = dbest;
/* 114 */       this._ftic = fbest;
/* 115 */       this._mtic = mbest;
/*     */     } 
/* 117 */     computeMinorTics();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCountMajor() {
/* 125 */     return this._ntic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDeltaMajor() {
/* 133 */     return this._dtic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getFirstMajor() {
/* 141 */     return this._ftic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCountMinor() {
/* 149 */     return this._nticMinor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDeltaMinor() {
/* 157 */     return this._dticMinor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getFirstMinor() {
/* 165 */     return this._fticMinor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMultiple() {
/* 175 */     return this._mtic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private static final int[] _mult = new int[] { 2, 5, 10 };
/*     */   
/*     */   private void computeMultiple() {
/* 194 */     this._mtic = 1;
/* 195 */     double l10 = MathPlus.log10(this._dtic / 10.0D);
/* 196 */     double l5 = MathPlus.log10(this._dtic / 5.0D);
/* 197 */     double l2 = MathPlus.log10(this._dtic / 2.0D);
/* 198 */     if (almostEqual(MathPlus.rint(l10), l10)) {
/* 199 */       this._mtic = 10;
/* 200 */     } else if (almostEqual(MathPlus.rint(l5), l5)) {
/* 201 */       this._mtic = 5;
/* 202 */     } else if (almostEqual(MathPlus.rint(l2), l2)) {
/* 203 */       this._mtic = 2;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void computeMinorTics() {
/* 208 */     double dm = this._dtic / this._mtic;
/* 209 */     double fm = this._ftic;
/* 210 */     while (this._xmin <= fm - dm)
/* 211 */       fm -= dm; 
/* 212 */     int nm = 1 + (int)((this._xmax - fm) / dm);
/* 213 */     this._nticMinor = nm;
/* 214 */     this._dticMinor = dm;
/* 215 */     this._fticMinor = fm;
/*     */   }
/*     */   
/*     */   private static boolean almostEqual(double x1, double x2) {
/* 219 */     return (MathPlus.abs(x1 - x2) <= MathPlus.max(MathPlus.abs(x1), MathPlus.abs(x2)) * 100.0D * 2.220446049250313E-16D);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/AxisTics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */