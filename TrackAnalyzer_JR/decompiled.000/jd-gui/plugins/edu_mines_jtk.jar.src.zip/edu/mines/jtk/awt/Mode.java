/*     */ package edu.mines.jtk.awt;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.HeadlessException;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Mode
/*     */   extends AbstractAction
/*     */ {
/*     */   private ModeManager _manager;
/*     */   private boolean _active;
/*     */   private Cursor _cursor;
/*     */   
/*     */   public void setActive(boolean active) {
/*  44 */     if (isEnabled() && this._active != active) {
/*  45 */       this._manager.setActive(this, active);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  53 */     return this._active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExclusive() {
/*  64 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent event) {
/*  72 */     setActive(!this._active);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  77 */     if (!enabled && isActive())
/*  78 */       setActive(false); 
/*  79 */     super.setEnabled(enabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/*  91 */     putValue("Name", name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIcon(Icon icon) {
/* 103 */     putValue("SmallIcon", icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMnemonicKey(int mk) {
/* 115 */     putValue("MnemonicKey", new Integer(mk));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAcceleratorKey(KeyStroke ak) {
/* 126 */     putValue("AcceleratorKey", ak);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShortDescription(String sd) {
/* 138 */     putValue("ShortDescription", sd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLongDescription(String ld) {
/* 149 */     putValue("LongDescription", ld);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCursor(Cursor cursor) {
/* 158 */     this._cursor = cursor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cursor getCursor() {
/* 166 */     return this._cursor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mode(ModeManager manager) {
/* 245 */     this._active = false;
/* 246 */     this._cursor = null; manager.add(this); this._manager = manager;
/*     */   }
/*     */   protected static Icon loadIcon(Class cls, String res) { URL url = cls.getResource(res); return (url != null) ? new ImageIcon(url) : null; } protected static Cursor loadCursor(Class cls, String res, int x, int y) { URL url = cls.getResource(res); if (url == null) return null;  Toolkit toolkit = Toolkit.getDefaultToolkit(); Image image = toolkit.getImage(url); if (image == null)
/* 249 */       return null;  image = resizeCursorImage(image); Point point = new Point(x, y); return toolkit.createCustomCursor(image, point, res); } private static Image resizeCursorImage(Image image) { image = (new ImageIcon(image)).getImage();
/* 250 */     int w = image.getWidth(null);
/* 251 */     int h = image.getHeight(null);
/* 252 */     Dimension size = new Dimension(w, h);
/*     */     try {
/* 254 */       size = Toolkit.getDefaultToolkit().getBestCursorSize(w, h);
/* 255 */     } catch (HeadlessException e) {
/* 256 */       return image;
/*     */     } 
/* 258 */     if (w == size.width && h == size.height)
/* 259 */       return image; 
/* 260 */     w = size.width;
/* 261 */     h = size.height;
/* 262 */     boolean hasAlpha = hasAlpha(image);
/* 263 */     BufferedImage bimage = null;
/* 264 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*     */     try {
/* 266 */       int transparency = hasAlpha ? 2 : 1;
/* 267 */       GraphicsDevice gs = ge.getDefaultScreenDevice();
/* 268 */       GraphicsConfiguration gc = gs.getDefaultConfiguration();
/* 269 */       bimage = gc.createCompatibleImage(w, h, transparency);
/* 270 */     } catch (HeadlessException e) {
/* 271 */       int type = hasAlpha ? 2 : 1;
/*     */ 
/*     */       
/* 274 */       bimage = new BufferedImage(w, h, type);
/*     */     } 
/* 276 */     Graphics g = bimage.createGraphics();
/* 277 */     g.drawImage(image, 0, 0, null);
/* 278 */     g.dispose();
/* 279 */     return bimage; }
/*     */   protected abstract void setActive(Component paramComponent, boolean paramBoolean); void setActiveInternal(boolean active) { Boolean oldValue = Boolean.valueOf(this._active);
/*     */     Boolean newValue = Boolean.valueOf(active);
/*     */     firePropertyChange("active", oldValue, newValue);
/* 283 */     this._active = active; } private static boolean hasAlpha(Image image) { if (image instanceof BufferedImage) {
/* 284 */       BufferedImage bimage = (BufferedImage)image;
/* 285 */       return bimage.getColorModel().hasAlpha();
/*     */     } 
/* 287 */     PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
/*     */     try {
/* 289 */       pg.grabPixels();
/* 290 */     } catch (InterruptedException e) {
/* 291 */       return true;
/*     */     } 
/* 293 */     ColorModel cm = pg.getColorModel();
/* 294 */     return cm.hasAlpha(); }
/*     */ 
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/awt/Mode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */