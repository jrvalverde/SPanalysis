/*    */ package edu.mines.jtk.sgl.test;
/*    */ import edu.mines.jtk.awt.Mode;
/*    */ import edu.mines.jtk.awt.ModeManager;
/*    */ import edu.mines.jtk.awt.ModeMenuItem;
/*    */ import edu.mines.jtk.awt.ModeToggleButton;
/*    */ import edu.mines.jtk.sgl.OrbitView;
/*    */ import edu.mines.jtk.sgl.OrbitViewMode;
/*    */ import edu.mines.jtk.sgl.SelectDragMode;
/*    */ import edu.mines.jtk.sgl.View;
/*    */ import edu.mines.jtk.sgl.ViewCanvas;
/*    */ import edu.mines.jtk.sgl.World;
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.Action;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.JPopupMenu;
/*    */ import javax.swing.JToolBar;
/*    */ 
/*    */ public class TestFrame extends JFrame {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public TestFrame(World world) {
/* 27 */     OrbitView view = (world != null) ? new OrbitView(world) : new OrbitView();
/* 28 */     view.setAxesOrientation(View.AxesOrientation.XRIGHT_YOUT_ZDOWN);
/* 29 */     ViewCanvas canvas = new ViewCanvas((View)view);
/* 30 */     canvas.setView((View)view);
/*    */     
/* 32 */     ModeManager mm = new ModeManager();
/* 33 */     mm.add((Component)canvas);
/* 34 */     OrbitViewMode ovm = new OrbitViewMode(mm);
/* 35 */     SelectDragMode sdm = new SelectDragMode(mm);
/*    */     
/* 37 */     JPopupMenu.setDefaultLightWeightPopupEnabled(false);
/* 38 */     ToolTipManager.sharedInstance().setLightWeightPopupEnabled(false);
/*    */     
/* 40 */     JMenu fileMenu = new JMenu("File");
/* 41 */     fileMenu.setMnemonic('F');
/* 42 */     Action exitAction = new AbstractAction("Exit") { private static final long serialVersionUID = 1L;
/*    */         
/*    */         public void actionPerformed(ActionEvent event) {
/* 45 */           System.exit(0);
/*    */         } }
/*    */       ;
/* 48 */     JMenuItem exitItem = fileMenu.add(exitAction);
/* 49 */     exitItem.setMnemonic('x');
/*    */     
/* 51 */     JMenu modeMenu = new JMenu("Mode");
/* 52 */     modeMenu.setMnemonic('M');
/* 53 */     ModeMenuItem modeMenuItem1 = new ModeMenuItem((Mode)ovm);
/* 54 */     modeMenu.add((JMenuItem)modeMenuItem1);
/* 55 */     ModeMenuItem modeMenuItem2 = new ModeMenuItem((Mode)sdm);
/* 56 */     modeMenu.add((JMenuItem)modeMenuItem2);
/*    */     
/* 58 */     JMenuBar menuBar = new JMenuBar();
/* 59 */     menuBar.add(fileMenu);
/* 60 */     menuBar.add(modeMenu);
/*    */     
/* 62 */     JToolBar toolBar = new JToolBar(1);
/* 63 */     toolBar.setRollover(true);
/* 64 */     ModeToggleButton modeToggleButton1 = new ModeToggleButton((Mode)ovm);
/* 65 */     toolBar.add((Component)modeToggleButton1);
/* 66 */     ModeToggleButton modeToggleButton2 = new ModeToggleButton((Mode)sdm);
/* 67 */     toolBar.add((Component)modeToggleButton2);
/*    */     
/* 69 */     ovm.setActive(true);
/*    */     
/* 71 */     setDefaultCloseOperation(3);
/* 72 */     setSize(new Dimension(600, 600));
/* 73 */     add((Component)canvas, "Center");
/* 74 */     add(toolBar, "West");
/* 75 */     setJMenuBar(menuBar);
/*    */     
/* 77 */     this._view = view;
/*    */   } private static final int SIZE = 600; private OrbitView _view;
/*    */   
/*    */   public OrbitView getOrbitView() {
/* 81 */     return this._view;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 85 */     TestFrame frame = new TestFrame(null);
/* 86 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/TestFrame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */