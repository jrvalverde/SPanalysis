/*      */ package edu.mines.jtk.dsp;
/*      */ 
/*      */ import edu.mines.jtk.util.Array;
/*      */ import edu.mines.jtk.util.Check;
/*      */ import edu.mines.jtk.util.MathPlus;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CausalFilter
/*      */ {
/*      */   private int _m;
/*      */   private int _min1;
/*      */   private int _max1;
/*      */   private int _min2;
/*      */   private int _max2;
/*      */   private int _min3;
/*      */   private int _max3;
/*      */   private int[] _lag1;
/*      */   private int[] _lag2;
/*      */   private int[] _lag3;
/*      */   private float[] _a;
/*      */   private float _a0;
/*      */   private float _a0i;
/*      */   
/*      */   public CausalFilter(int[] lag1) {
/*   49 */     this(lag1, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CausalFilter(int[] lag1, int[] lag2) {
/*   63 */     this(lag1, lag2, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CausalFilter(int[] lag1, int[] lag2, int[] lag3) {
/*   78 */     this(lag1, lag2, lag3, impulse(lag1.length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CausalFilter(int[] lag1, float[] a) {
/*   91 */     initLags(lag1, a);
/*   92 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CausalFilter(int[] lag1, int[] lag2, float[] a) {
/*  107 */     initLags(lag1, lag2, a);
/*  108 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CausalFilter(int[] lag1, int[] lag2, int[] lag3, float[] a) {
/*  124 */     initLags(lag1, lag2, lag3, a);
/*  125 */     initA(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag1() {
/*  133 */     return Array.copy(this._lag1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag2() {
/*  141 */     return Array.copy(this._lag2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getLag3() {
/*  149 */     return Array.copy(this._lag3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float[] getA() {
/*  157 */     return Array.copy(this._a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[] r) {
/*  176 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  179 */     int m1 = this._max1 - this._min1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  186 */     int n1 = r.length + 10 * m1;
/*      */ 
/*      */     
/*  189 */     int l1 = (r.length - 1) / 2;
/*  190 */     int k1 = n1 - 1 - this._max1;
/*      */ 
/*      */     
/*  193 */     float[] s = new float[n1];
/*  194 */     float[] t = new float[n1];
/*  195 */     float[] u = new float[n1];
/*      */ 
/*      */     
/*  198 */     Array.copy(r.length, 0, r, k1 - l1, s);
/*      */ 
/*      */     
/*  201 */     Array.zero(this._a);
/*  202 */     this._a[0] = MathPlus.sqrt(s[k1]);
/*  203 */     this._a0 = this._a[0];
/*  204 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  208 */     boolean converged = false;
/*  209 */     float eemax = s[k1] * epsilon;
/*  210 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  214 */       applyInverseTranspose(s, t);
/*  215 */       applyInverse(t, u);
/*  216 */       u[k1] = u[k1] + 1.0F;
/*      */ 
/*      */       
/*  219 */       u[k1] = u[k1] * 0.5F;
/*  220 */       for (int i1 = 0; i1 < k1; i1++) {
/*  221 */         u[i1] = 0.0F;
/*      */       }
/*      */       
/*  224 */       apply(u, t);
/*  225 */       converged = true;
/*  226 */       for (int j = 0; j < this._m; j++) {
/*  227 */         int j1 = k1 + this._lag1[j];
/*  228 */         if (0 <= j1 && j1 < n1) {
/*  229 */           float aj = t[j1];
/*  230 */           if (converged) {
/*  231 */             float e = this._a[j] - aj;
/*  232 */             converged = (e * e <= eemax);
/*      */           } 
/*  234 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  237 */       this._a0 = this._a[0];
/*  238 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  240 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[][] r) {
/*  259 */     Check.argument(((r[0]).length % 2 == 1), "r[0].length is odd");
/*  260 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  263 */     int m1 = this._max1 - this._min1;
/*  264 */     int m2 = this._max2 - this._min2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  271 */     int n1 = (r[0]).length + 10 * m1;
/*  272 */     int n2 = r.length + 10 * m2;
/*      */ 
/*      */     
/*  275 */     int l1 = ((r[0]).length - 1) / 2;
/*  276 */     int l2 = (r.length - 1) / 2;
/*  277 */     int k1 = n1 - 1 - this._max1;
/*  278 */     int k2 = n2 - 1 - this._max2;
/*      */ 
/*      */     
/*  281 */     float[][] s = new float[n2][n1];
/*  282 */     float[][] t = new float[n2][n1];
/*  283 */     float[][] u = new float[n2][n1];
/*      */ 
/*      */     
/*  286 */     Array.copy((r[0]).length, r.length, 0, 0, r, k1 - l1, k2 - l2, s);
/*      */ 
/*      */     
/*  289 */     Array.zero(this._a);
/*  290 */     this._a[0] = MathPlus.sqrt(s[k2][k1]);
/*  291 */     this._a0 = this._a[0];
/*  292 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  296 */     boolean converged = false;
/*  297 */     float eemax = s[k2][k1] * epsilon;
/*  298 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  302 */       applyInverseTranspose(s, t);
/*  303 */       applyInverse(t, u);
/*  304 */       u[k2][k1] = u[k2][k1] + 1.0F;
/*      */ 
/*      */       
/*  307 */       u[k2][k1] = u[k2][k1] * 0.5F;
/*  308 */       for (int i2 = 0; i2 < k2; i2++) {
/*  309 */         for (int i = 0; i < n1; i++)
/*  310 */           u[i2][i] = 0.0F; 
/*  311 */       }  for (int i1 = 0; i1 < k1; i1++) {
/*  312 */         u[k2][i1] = 0.0F;
/*      */       }
/*      */       
/*  315 */       apply(u, t);
/*  316 */       converged = true;
/*  317 */       for (int j = 0; j < this._m; j++) {
/*  318 */         int j1 = k1 + this._lag1[j];
/*  319 */         int j2 = k2 + this._lag2[j];
/*  320 */         if (0 <= j1 && j1 < n1 && 0 <= j2 && j2 < n2) {
/*  321 */           float aj = t[j2][j1];
/*  322 */           if (converged) {
/*  323 */             float e = this._a[j] - aj;
/*  324 */             converged = (e * e <= eemax);
/*      */           } 
/*  326 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  329 */       this._a0 = this._a[0];
/*  330 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  332 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void factorWilsonBurg(int maxiter, float epsilon, float[][][] r) {
/*  351 */     Check.argument(((r[0][0]).length % 2 == 1), "r[0][0].length is odd");
/*  352 */     Check.argument(((r[0]).length % 2 == 1), "r[0].length is odd");
/*  353 */     Check.argument((r.length % 2 == 1), "r.length is odd");
/*      */ 
/*      */     
/*  356 */     int m1 = this._max1 - this._min1;
/*  357 */     int m2 = this._max2 - this._min2;
/*  358 */     int m3 = this._max3 - this._min3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  365 */     int n1 = (r[0][0]).length + 10 * m1;
/*  366 */     int n2 = (r[0]).length + 10 * m2;
/*  367 */     int n3 = r.length + 10 * m3;
/*      */ 
/*      */     
/*  370 */     int l1 = ((r[0][0]).length - 1) / 2;
/*  371 */     int l2 = ((r[0]).length - 1) / 2;
/*  372 */     int l3 = (r.length - 1) / 2;
/*  373 */     int k1 = n1 - 1 - this._max1;
/*  374 */     int k2 = n2 - 1 - this._max2;
/*  375 */     int k3 = n3 - 1 - this._max3;
/*      */ 
/*      */     
/*  378 */     float[][][] s = new float[n3][n2][n1];
/*  379 */     float[][][] t = new float[n3][n2][n1];
/*  380 */     float[][][] u = new float[n3][n2][n1];
/*      */ 
/*      */     
/*  383 */     Array.copy((r[0][0]).length, (r[0]).length, r.length, 0, 0, 0, r, k1 - l1, k2 - l2, k3 - l3, s);
/*      */ 
/*      */     
/*  386 */     Array.zero(this._a);
/*  387 */     this._a[0] = MathPlus.sqrt(s[k3][k2][k1]);
/*  388 */     this._a0 = this._a[0];
/*  389 */     this._a0i = 1.0F / this._a[0];
/*      */ 
/*      */ 
/*      */     
/*  393 */     boolean converged = false;
/*  394 */     float eemax = s[k3][k2][k1] * epsilon;
/*  395 */     for (int niter = 0; niter < maxiter && !converged; niter++) {
/*      */ 
/*      */ 
/*      */       
/*  399 */       applyInverseTranspose(s, t);
/*  400 */       applyInverse(t, u);
/*  401 */       u[k3][k2][k1] = u[k3][k2][k1] + 1.0F;
/*      */ 
/*      */       
/*  404 */       u[k3][k2][k1] = u[k3][k2][k1] * 0.5F;
/*  405 */       for (int i3 = 0; i3 < k3; i3++) {
/*  406 */         for (int i = 0; i < n2; i++)
/*  407 */         { for (int k = 0; k < n1; k++)
/*  408 */             u[i3][i][k] = 0.0F;  } 
/*  409 */       }  for (int i2 = 0; i2 < k2; i2++) {
/*  410 */         for (int i = 0; i < n1; i++)
/*  411 */           u[k3][i2][i] = 0.0F; 
/*  412 */       }  for (int i1 = 0; i1 < k1; i1++) {
/*  413 */         u[k3][k2][i1] = 0.0F;
/*      */       }
/*      */       
/*  416 */       apply(u, t);
/*  417 */       converged = true;
/*  418 */       for (int j = 0; j < this._m; j++) {
/*  419 */         int j1 = k1 + this._lag1[j];
/*  420 */         int j2 = k2 + this._lag2[j];
/*  421 */         int j3 = k3 + this._lag3[j];
/*  422 */         if (0 <= j1 && j1 < n1 && 0 <= j2 && j2 < n2 && 0 <= j3 && j3 < n3) {
/*  423 */           float aj = t[j3][j2][j1];
/*  424 */           if (converged) {
/*  425 */             float e = this._a[j] - aj;
/*  426 */             converged = (e * e <= eemax);
/*      */           } 
/*  428 */           this._a[j] = aj;
/*      */         } 
/*      */       } 
/*  431 */       this._a0 = this._a[0];
/*  432 */       this._a0i = 1.0F / this._a[0];
/*      */     } 
/*  434 */     Check.state(converged, "Wilson-Burg iterations converged");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[] x, float[] y) {
/*  458 */     int n1 = x.length;
/*  459 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  460 */     for (i1 = n1 - 1; i1 >= i1lo; i1--) {
/*  461 */       float yi = this._a0 * x[i1];
/*  462 */       for (int j = 1; j < this._m; j++) {
/*  463 */         int k1 = i1 - this._lag1[j];
/*  464 */         yi += this._a[j] * x[k1];
/*      */       } 
/*  466 */       y[i1] = yi;
/*      */     } 
/*  468 */     for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  469 */       float yi = this._a0 * x[i1];
/*  470 */       for (int j = 1; j < this._m; j++) {
/*  471 */         int k1 = i1 - this._lag1[j];
/*  472 */         if (0 <= k1)
/*  473 */           yi += this._a[j] * x[k1]; 
/*      */       } 
/*  475 */       y[i1] = yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[] x, float[] y) {
/*  488 */     int n1 = x.length;
/*  489 */     int i1hi = MathPlus.max(n1 - this._max1, 0); int i1;
/*  490 */     for (i1 = 0; i1 < i1hi; i1++) {
/*  491 */       float yi = this._a0 * x[i1];
/*  492 */       for (int j = 1; j < this._m; j++) {
/*  493 */         int k1 = i1 + this._lag1[j];
/*  494 */         yi += this._a[j] * x[k1];
/*      */       } 
/*  496 */       y[i1] = yi;
/*      */     } 
/*  498 */     for (i1 = i1hi; i1 < n1; i1++) {
/*  499 */       float yi = this._a0 * x[i1];
/*  500 */       for (int j = 1; j < this._m; j++) {
/*  501 */         int k1 = i1 + this._lag1[j];
/*  502 */         if (k1 < n1)
/*  503 */           yi += this._a[j] * x[k1]; 
/*      */       } 
/*  505 */       y[i1] = yi;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[] y, float[] x) {
/*  518 */     int n1 = y.length;
/*  519 */     int i1lo = MathPlus.min(this._max1, n1); int i1;
/*  520 */     for (i1 = 0; i1 < i1lo; i1++) {
/*  521 */       float xi = y[i1];
/*  522 */       for (int j = 1; j < this._m; j++) {
/*  523 */         int k1 = i1 - this._lag1[j];
/*  524 */         if (0 <= k1)
/*  525 */           xi -= this._a[j] * x[k1]; 
/*      */       } 
/*  527 */       x[i1] = xi * this._a0i;
/*      */     } 
/*  529 */     for (i1 = i1lo; i1 < n1; i1++) {
/*  530 */       float xi = y[i1];
/*  531 */       for (int j = 1; j < this._m; j++) {
/*  532 */         int k1 = i1 - this._lag1[j];
/*  533 */         xi -= this._a[j] * x[k1];
/*      */       } 
/*  535 */       x[i1] = xi * this._a0i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[] y, float[] x) {
/*  548 */     int n1 = y.length;
/*  549 */     int i1hi = MathPlus.max(n1 - this._max1, 0); int i1;
/*  550 */     for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  551 */       float xi = y[i1];
/*  552 */       for (int j = 1; j < this._m; j++) {
/*  553 */         int k1 = i1 + this._lag1[j];
/*  554 */         if (k1 < n1)
/*  555 */           xi -= this._a[j] * x[k1]; 
/*      */       } 
/*  557 */       x[i1] = xi * this._a0i;
/*      */     } 
/*  559 */     for (i1 = i1hi - 1; i1 >= 0; i1--) {
/*  560 */       float xi = y[i1];
/*  561 */       for (int j = 1; j < this._m; j++) {
/*  562 */         int k1 = i1 + this._lag1[j];
/*  563 */         xi -= this._a[j] * x[k1];
/*      */       } 
/*  565 */       x[i1] = xi * this._a0i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[][] x, float[][] y) {
/*  581 */     int n1 = (x[0]).length;
/*  582 */     int n2 = x.length;
/*  583 */     int i1lo = MathPlus.max(0, this._max1);
/*  584 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  585 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  586 */     for (i2 = n2 - 1; i2 >= i2lo; i2--) {
/*  587 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  588 */         float yi = this._a0 * x[i2][i1];
/*  589 */         for (int j = 1; j < this._m; j++) {
/*  590 */           int k1 = i1 - this._lag1[j];
/*  591 */           int k2 = i2 - this._lag2[j];
/*  592 */           if (k1 < n1)
/*  593 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  595 */         y[i2][i1] = yi;
/*      */       } 
/*  597 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  598 */         float yi = this._a0 * x[i2][i1];
/*  599 */         for (int j = 1; j < this._m; j++) {
/*  600 */           int k1 = i1 - this._lag1[j];
/*  601 */           int k2 = i2 - this._lag2[j];
/*  602 */           yi += this._a[j] * x[k2][k1];
/*      */         } 
/*  604 */         y[i2][i1] = yi;
/*      */       } 
/*  606 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  607 */         float yi = this._a0 * x[i2][i1];
/*  608 */         for (int j = 1; j < this._m; j++) {
/*  609 */           int k1 = i1 - this._lag1[j];
/*  610 */           int k2 = i2 - this._lag2[j];
/*  611 */           if (0 <= k1)
/*  612 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  614 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  617 */     for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  618 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  619 */         float yi = this._a0 * x[i2][i1];
/*  620 */         for (int j = 1; j < this._m; j++) {
/*  621 */           int k1 = i1 - this._lag1[j];
/*  622 */           int k2 = i2 - this._lag2[j];
/*  623 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  624 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  626 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[][] x, float[][] y) {
/*  640 */     int n1 = (x[0]).length;
/*  641 */     int n2 = x.length;
/*  642 */     int i1lo = MathPlus.max(0, -this._min1);
/*  643 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  644 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/*  645 */     for (i2 = 0; i2 < i2hi; i2++) {
/*  646 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  647 */         float yi = this._a0 * x[i2][i1];
/*  648 */         for (int j = 1; j < this._m; j++) {
/*  649 */           int k1 = i1 + this._lag1[j];
/*  650 */           int k2 = i2 + this._lag2[j];
/*  651 */           if (0 <= k1)
/*  652 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  654 */         y[i2][i1] = yi;
/*      */       } 
/*  656 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  657 */         float yi = this._a0 * x[i2][i1];
/*  658 */         for (int j = 1; j < this._m; j++) {
/*  659 */           int k1 = i1 + this._lag1[j];
/*  660 */           int k2 = i2 + this._lag2[j];
/*  661 */           yi += this._a[j] * x[k2][k1];
/*      */         } 
/*  663 */         y[i2][i1] = yi;
/*      */       } 
/*  665 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  666 */         float yi = this._a0 * x[i2][i1];
/*  667 */         for (int j = 1; j < this._m; j++) {
/*  668 */           int k1 = i1 + this._lag1[j];
/*  669 */           int k2 = i2 + this._lag2[j];
/*  670 */           if (k1 < n1)
/*  671 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  673 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*  676 */     for (i2 = i2hi; i2 < n2; i2++) {
/*  677 */       for (int i1 = 0; i1 < n1; i1++) {
/*  678 */         float yi = this._a0 * x[i2][i1];
/*  679 */         for (int j = 1; j < this._m; j++) {
/*  680 */           int k1 = i1 + this._lag1[j];
/*  681 */           int k2 = i2 + this._lag2[j];
/*  682 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/*  683 */             yi += this._a[j] * x[k2][k1]; 
/*      */         } 
/*  685 */         y[i2][i1] = yi;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[][] y, float[][] x) {
/*  699 */     int n1 = (y[0]).length;
/*  700 */     int n2 = y.length;
/*  701 */     int i1lo = MathPlus.min(this._max1, n1);
/*  702 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  703 */     int i2lo = (i1lo <= i1hi) ? MathPlus.min(this._max2, n2) : n2; int i2;
/*  704 */     for (i2 = 0; i2 < i2lo; i2++) {
/*  705 */       for (int i1 = 0; i1 < n1; i1++) {
/*  706 */         float xi = y[i2][i1];
/*  707 */         for (int j = 1; j < this._m; j++) {
/*  708 */           int k1 = i1 - this._lag1[j];
/*  709 */           int k2 = i2 - this._lag2[j];
/*  710 */           if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  711 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  713 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*      */     } 
/*  716 */     for (i2 = i2lo; i2 < n2; i2++) {
/*  717 */       int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  718 */         float xi = y[i2][i1];
/*  719 */         for (int j = 1; j < this._m; j++) {
/*  720 */           int k1 = i1 - this._lag1[j];
/*  721 */           int k2 = i2 - this._lag2[j];
/*  722 */           if (0 <= k1)
/*  723 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  725 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*  727 */       for (i1 = i1lo; i1 < i1hi; i1++) {
/*  728 */         float xi = y[i2][i1];
/*  729 */         for (int j = 1; j < this._m; j++) {
/*  730 */           int k1 = i1 - this._lag1[j];
/*  731 */           int k2 = i2 - this._lag2[j];
/*  732 */           xi -= this._a[j] * x[k2][k1];
/*      */         } 
/*  734 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*  736 */       for (i1 = i1hi; i1 < n1; i1++) {
/*  737 */         float xi = y[i2][i1];
/*  738 */         for (int j = 1; j < this._m; j++) {
/*  739 */           int k1 = i1 - this._lag1[j];
/*  740 */           int k2 = i2 - this._lag2[j];
/*  741 */           if (k1 < n1)
/*  742 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  744 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[][] y, float[][] x) {
/*  758 */     int n1 = (y[0]).length;
/*  759 */     int n2 = y.length;
/*  760 */     int i1lo = MathPlus.max(0, -this._min1);
/*  761 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  762 */     int i2hi = (i1lo <= i1hi) ? MathPlus.max(n2 - this._max2, 0) : 0; int i2;
/*  763 */     for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  764 */       for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  765 */         float xi = y[i2][i1];
/*  766 */         for (int j = 1; j < this._m; j++) {
/*  767 */           int k1 = i1 + this._lag1[j];
/*  768 */           int k2 = i2 + this._lag2[j];
/*  769 */           if (0 <= k1 && k1 < n1 && k2 < n2)
/*  770 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  772 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*      */     } 
/*  775 */     for (i2 = i2hi - 1; i2 >= 0; i2--) {
/*  776 */       int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  777 */         float xi = y[i2][i1];
/*  778 */         for (int j = 1; j < this._m; j++) {
/*  779 */           int k1 = i1 + this._lag1[j];
/*  780 */           int k2 = i2 + this._lag2[j];
/*  781 */           if (k1 < n1)
/*  782 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  784 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*  786 */       for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  787 */         float xi = y[i2][i1];
/*  788 */         for (int j = 1; j < this._m; j++) {
/*  789 */           int k1 = i1 + this._lag1[j];
/*  790 */           int k2 = i2 + this._lag2[j];
/*  791 */           xi -= this._a[j] * x[k2][k1];
/*      */         } 
/*  793 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*  795 */       for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  796 */         float xi = y[i2][i1];
/*  797 */         for (int j = 1; j < this._m; j++) {
/*  798 */           int k1 = i1 + this._lag1[j];
/*  799 */           int k2 = i2 + this._lag2[j];
/*  800 */           if (0 <= k1)
/*  801 */             xi -= this._a[j] * x[k2][k1]; 
/*      */         } 
/*  803 */         x[i2][i1] = xi * this._a0i;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void apply(float[][][] x, float[][][] y) {
/*  820 */     int n1 = (x[0][0]).length;
/*  821 */     int n2 = (x[0]).length;
/*  822 */     int n3 = x.length;
/*  823 */     int i1lo = MathPlus.max(0, this._max1);
/*  824 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/*  825 */     int i2lo = MathPlus.max(0, this._max2);
/*  826 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/*  827 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/*  828 */     for (i3 = n3 - 1; i3 >= i3lo; i3--) {
/*  829 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/*  830 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  831 */           float yi = this._a0 * x[i3][i2][i1];
/*  832 */           for (int j = 1; j < this._m; j++) {
/*  833 */             int k1 = i1 - this._lag1[j];
/*  834 */             int k2 = i2 - this._lag2[j];
/*  835 */             int k3 = i3 - this._lag3[j];
/*  836 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/*  837 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  839 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  842 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/*  843 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/*  844 */           float yi = this._a0 * x[i3][i2][i1];
/*  845 */           for (int j = 1; j < this._m; j++) {
/*  846 */             int k1 = i1 - this._lag1[j];
/*  847 */             int k2 = i2 - this._lag2[j];
/*  848 */             int k3 = i3 - this._lag3[j];
/*  849 */             if (k1 < n1)
/*  850 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  852 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  854 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/*  855 */           float yi = this._a0 * x[i3][i2][i1];
/*  856 */           for (int j = 1; j < this._m; j++) {
/*  857 */             int k1 = i1 - this._lag1[j];
/*  858 */             int k2 = i2 - this._lag2[j];
/*  859 */             int k3 = i3 - this._lag3[j];
/*  860 */             yi += this._a[j] * x[k3][k2][k1];
/*      */           } 
/*  862 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  864 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/*  865 */           float yi = this._a0 * x[i3][i2][i1];
/*  866 */           for (int j = 1; j < this._m; j++) {
/*  867 */             int k1 = i1 - this._lag1[j];
/*  868 */             int k2 = i2 - this._lag2[j];
/*  869 */             int k3 = i3 - this._lag3[j];
/*  870 */             if (0 <= k1)
/*  871 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  873 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  876 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/*  877 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  878 */           float yi = this._a0 * x[i3][i2][i1];
/*  879 */           for (int j = 1; j < this._m; j++) {
/*  880 */             int k1 = i1 - this._lag1[j];
/*  881 */             int k2 = i2 - this._lag2[j];
/*  882 */             int k3 = i3 - this._lag3[j];
/*  883 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  884 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  886 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*  890 */     for (i3 = i3lo - 1; i3 >= 0; i3--) {
/*  891 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/*  892 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/*  893 */           float yi = this._a0 * x[i3][i2][i1];
/*  894 */           for (int j = 1; j < this._m; j++) {
/*  895 */             int k1 = i1 - this._lag1[j];
/*  896 */             int k2 = i2 - this._lag2[j];
/*  897 */             int k3 = i3 - this._lag3[j];
/*  898 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/*  899 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  901 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyTranspose(float[][][] x, float[][][] y) {
/*  916 */     int n1 = (x[0][0]).length;
/*  917 */     int n2 = (x[0]).length;
/*  918 */     int n3 = x.length;
/*  919 */     int i1lo = MathPlus.max(0, -this._min1);
/*  920 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/*  921 */     int i2lo = MathPlus.max(0, -this._min2);
/*  922 */     int i2hi = MathPlus.min(n2, n2 - this._max2);
/*  923 */     int i3hi = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.max(n3 - this._max3, 0) : 0; int i3;
/*  924 */     for (i3 = 0; i3 < i3hi; i3++) {
/*  925 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/*  926 */         for (int i1 = 0; i1 < n1; i1++) {
/*  927 */           float yi = this._a0 * x[i3][i2][i1];
/*  928 */           for (int j = 1; j < this._m; j++) {
/*  929 */             int k1 = i1 + this._lag1[j];
/*  930 */             int k2 = i2 + this._lag2[j];
/*  931 */             int k3 = i3 + this._lag3[j];
/*  932 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/*  933 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  935 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  938 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/*  939 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/*  940 */           float yi = this._a0 * x[i3][i2][i1];
/*  941 */           for (int j = 1; j < this._m; j++) {
/*  942 */             int k1 = i1 + this._lag1[j];
/*  943 */             int k2 = i2 + this._lag2[j];
/*  944 */             int k3 = i3 + this._lag3[j];
/*  945 */             if (0 <= k1)
/*  946 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  948 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  950 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/*  951 */           float yi = this._a0 * x[i3][i2][i1];
/*  952 */           for (int j = 1; j < this._m; j++) {
/*  953 */             int k1 = i1 + this._lag1[j];
/*  954 */             int k2 = i2 + this._lag2[j];
/*  955 */             int k3 = i3 + this._lag3[j];
/*  956 */             yi += this._a[j] * x[k3][k2][k1];
/*      */           } 
/*  958 */           y[i3][i2][i1] = yi;
/*      */         } 
/*  960 */         for (i1 = i1hi; i1 < n1; i1++) {
/*  961 */           float yi = this._a0 * x[i3][i2][i1];
/*  962 */           for (int j = 1; j < this._m; j++) {
/*  963 */             int k1 = i1 + this._lag1[j];
/*  964 */             int k2 = i2 + this._lag2[j];
/*  965 */             int k3 = i3 + this._lag3[j];
/*  966 */             if (k1 < n1)
/*  967 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  969 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*  972 */       for (i2 = i2hi; i2 < n2; i2++) {
/*  973 */         for (int i1 = 0; i1 < n1; i1++) {
/*  974 */           float yi = this._a0 * x[i3][i2][i1];
/*  975 */           for (int j = 1; j < this._m; j++) {
/*  976 */             int k1 = i1 + this._lag1[j];
/*  977 */             int k2 = i2 + this._lag2[j];
/*  978 */             int k3 = i3 + this._lag3[j];
/*  979 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/*  980 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  982 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*  986 */     for (i3 = i3hi; i3 < n3; i3++) {
/*  987 */       for (int i2 = 0; i2 < n2; i2++) {
/*  988 */         for (int i1 = 0; i1 < n1; i1++) {
/*  989 */           float yi = this._a0 * x[i3][i2][i1];
/*  990 */           for (int j = 1; j < this._m; j++) {
/*  991 */             int k1 = i1 + this._lag1[j];
/*  992 */             int k2 = i2 + this._lag2[j];
/*  993 */             int k3 = i3 + this._lag3[j];
/*  994 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && k3 < n3)
/*  995 */               yi += this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/*  997 */           y[i3][i2][i1] = yi;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverse(float[][][] y, float[][][] x) {
/* 1012 */     int n1 = (y[0][0]).length;
/* 1013 */     int n2 = (y[0]).length;
/* 1014 */     int n3 = y.length;
/* 1015 */     int i1lo = MathPlus.max(0, this._max1);
/* 1016 */     int i1hi = MathPlus.min(n1, n1 + this._min1);
/* 1017 */     int i2lo = MathPlus.max(0, this._max2);
/* 1018 */     int i2hi = MathPlus.min(n2, n2 + this._min2);
/* 1019 */     int i3lo = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.min(this._max3, n3) : n3; int i3;
/* 1020 */     for (i3 = 0; i3 < i3lo; i3++) {
/* 1021 */       for (int i2 = 0; i2 < n2; i2++) {
/* 1022 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1023 */           float xi = y[i3][i2][i1];
/* 1024 */           for (int j = 1; j < this._m; j++) {
/* 1025 */             int k1 = i1 - this._lag1[j];
/* 1026 */             int k2 = i2 - this._lag2[j];
/* 1027 */             int k3 = i3 - this._lag3[j];
/* 1028 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && 0 <= k3)
/* 1029 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1031 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1035 */     for (i3 = i3lo; i3 < n3; i3++) {
/* 1036 */       int i2; for (i2 = 0; i2 < i2lo; i2++) {
/* 1037 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1038 */           float xi = y[i3][i2][i1];
/* 1039 */           for (int j = 1; j < this._m; j++) {
/* 1040 */             int k1 = i1 - this._lag1[j];
/* 1041 */             int k2 = i2 - this._lag2[j];
/* 1042 */             int k3 = i3 - this._lag3[j];
/* 1043 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/* 1044 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1046 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/* 1049 */       for (i2 = i2lo; i2 < i2hi; i2++) {
/* 1050 */         int i1; for (i1 = 0; i1 < i1lo; i1++) {
/* 1051 */           float xi = y[i3][i2][i1];
/* 1052 */           for (int j = 1; j < this._m; j++) {
/* 1053 */             int k1 = i1 - this._lag1[j];
/* 1054 */             int k2 = i2 - this._lag2[j];
/* 1055 */             int k3 = i3 - this._lag3[j];
/* 1056 */             if (0 <= k1)
/* 1057 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1059 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/* 1061 */         for (i1 = i1lo; i1 < i1hi; i1++) {
/* 1062 */           float xi = y[i3][i2][i1];
/* 1063 */           for (int j = 1; j < this._m; j++) {
/* 1064 */             int k1 = i1 - this._lag1[j];
/* 1065 */             int k2 = i2 - this._lag2[j];
/* 1066 */             int k3 = i3 - this._lag3[j];
/* 1067 */             xi -= this._a[j] * x[k3][k2][k1];
/*      */           } 
/* 1069 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/* 1071 */         for (i1 = i1hi; i1 < n1; i1++) {
/* 1072 */           float xi = y[i3][i2][i1];
/* 1073 */           for (int j = 1; j < this._m; j++) {
/* 1074 */             int k1 = i1 - this._lag1[j];
/* 1075 */             int k2 = i2 - this._lag2[j];
/* 1076 */             int k3 = i3 - this._lag3[j];
/* 1077 */             if (k1 < n1)
/* 1078 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1080 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/* 1083 */       for (i2 = i2hi; i2 < n2; i2++) {
/* 1084 */         for (int i1 = 0; i1 < n1; i1++) {
/* 1085 */           float xi = y[i3][i2][i1];
/* 1086 */           for (int j = 1; j < this._m; j++) {
/* 1087 */             int k1 = i1 - this._lag1[j];
/* 1088 */             int k2 = i2 - this._lag2[j];
/* 1089 */             int k3 = i3 - this._lag3[j];
/* 1090 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/* 1091 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1093 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyInverseTranspose(float[][][] y, float[][][] x) {
/* 1108 */     int n1 = (y[0][0]).length;
/* 1109 */     int n2 = (y[0]).length;
/* 1110 */     int n3 = y.length;
/* 1111 */     int i1lo = MathPlus.max(0, -this._min1);
/* 1112 */     int i1hi = MathPlus.min(n1, n1 - this._max1);
/* 1113 */     int i2lo = MathPlus.max(0, -this._min2);
/* 1114 */     int i2hi = MathPlus.min(n2, n2 - this._max2);
/* 1115 */     int i3hi = (i1lo <= i1hi && i2lo <= i2hi) ? MathPlus.max(n3 - this._max3, 0) : 0; int i3;
/* 1116 */     for (i3 = n3 - 1; i3 >= i3hi; i3--) {
/* 1117 */       for (int i2 = n2 - 1; i2 >= 0; i2--) {
/* 1118 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1119 */           float xi = y[i3][i2][i1];
/* 1120 */           for (int j = 1; j < this._m; j++) {
/* 1121 */             int k1 = i1 + this._lag1[j];
/* 1122 */             int k2 = i2 + this._lag2[j];
/* 1123 */             int k3 = i3 + this._lag3[j];
/* 1124 */             if (0 <= k1 && k1 < n1 && 0 <= k2 && k2 < n2 && k3 < n3)
/* 1125 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1127 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1131 */     for (i3 = i3hi - 1; i3 >= 0; i3--) {
/* 1132 */       int i2; for (i2 = n2 - 1; i2 >= i2hi; i2--) {
/* 1133 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1134 */           float xi = y[i3][i2][i1];
/* 1135 */           for (int j = 1; j < this._m; j++) {
/* 1136 */             int k1 = i1 + this._lag1[j];
/* 1137 */             int k2 = i2 + this._lag2[j];
/* 1138 */             int k3 = i3 + this._lag3[j];
/* 1139 */             if (0 <= k1 && k1 < n1 && k2 < n2)
/* 1140 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1142 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/* 1145 */       for (i2 = i2hi - 1; i2 >= i2lo; i2--) {
/* 1146 */         int i1; for (i1 = n1 - 1; i1 >= i1hi; i1--) {
/* 1147 */           float xi = y[i3][i2][i1];
/* 1148 */           for (int j = 1; j < this._m; j++) {
/* 1149 */             int k1 = i1 + this._lag1[j];
/* 1150 */             int k2 = i2 + this._lag2[j];
/* 1151 */             int k3 = i3 + this._lag3[j];
/* 1152 */             if (k1 < n1)
/* 1153 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1155 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/* 1157 */         for (i1 = i1hi - 1; i1 >= i1lo; i1--) {
/* 1158 */           float xi = y[i3][i2][i1];
/* 1159 */           for (int j = 1; j < this._m; j++) {
/* 1160 */             int k1 = i1 + this._lag1[j];
/* 1161 */             int k2 = i2 + this._lag2[j];
/* 1162 */             int k3 = i3 + this._lag3[j];
/* 1163 */             xi -= this._a[j] * x[k3][k2][k1];
/*      */           } 
/* 1165 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/* 1167 */         for (i1 = i1lo - 1; i1 >= 0; i1--) {
/* 1168 */           float xi = y[i3][i2][i1];
/* 1169 */           for (int j = 1; j < this._m; j++) {
/* 1170 */             int k1 = i1 + this._lag1[j];
/* 1171 */             int k2 = i2 + this._lag2[j];
/* 1172 */             int k3 = i3 + this._lag3[j];
/* 1173 */             if (0 <= k1)
/* 1174 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1176 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/* 1179 */       for (i2 = i2lo - 1; i2 >= 0; i2--) {
/* 1180 */         for (int i1 = n1 - 1; i1 >= 0; i1--) {
/* 1181 */           float xi = y[i3][i2][i1];
/* 1182 */           for (int j = 1; j < this._m; j++) {
/* 1183 */             int k1 = i1 + this._lag1[j];
/* 1184 */             int k2 = i2 + this._lag2[j];
/* 1185 */             int k3 = i3 + this._lag3[j];
/* 1186 */             if (0 <= k1 && k1 < n1 && 0 <= k2)
/* 1187 */               xi -= this._a[j] * x[k3][k2][k1]; 
/*      */           } 
/* 1189 */           x[i3][i2][i1] = xi * this._a0i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static float[] impulse(int nlag) {
/* 1209 */     float[] a = new float[nlag];
/* 1210 */     a[0] = 1.0F;
/* 1211 */     return a;
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, float[] a) {
/* 1215 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1216 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1217 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1218 */     for (int j = 1; j < a.length; j++)
/* 1219 */       Check.argument((lag1[j] > 0), "lag1[" + j + "]>0"); 
/* 1220 */     this._m = lag1.length;
/* 1221 */     this._lag1 = Array.copy(lag1);
/* 1222 */     this._lag2 = Array.zeroint(this._m);
/* 1223 */     this._lag3 = Array.zeroint(this._m);
/* 1224 */     this._min1 = Array.min(lag1);
/* 1225 */     this._max1 = Array.max(lag1);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2, float[] a) {
/* 1229 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1230 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1231 */     Check.argument((lag2.length == a.length), "lag2.length==a.length");
/* 1232 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1233 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1234 */     for (int j = 1; j < a.length; j++) {
/* 1235 */       Check.argument((lag2[j] >= 0), "lag2[" + j + "]>=0");
/* 1236 */       if (lag2[j] == 0)
/* 1237 */         Check.argument((lag1[j] > 0), "if lag2==0, lag1[" + j + "]>0"); 
/*      */     } 
/* 1239 */     this._m = lag1.length;
/* 1240 */     this._lag1 = Array.copy(lag1);
/* 1241 */     this._lag2 = Array.copy(lag2);
/* 1242 */     this._lag3 = Array.zeroint(this._m);
/* 1243 */     this._min1 = Array.min(lag1);
/* 1244 */     this._min2 = Array.min(lag2);
/* 1245 */     this._max1 = Array.max(lag1);
/* 1246 */     this._max2 = Array.max(lag2);
/*      */   }
/*      */   
/*      */   private void initLags(int[] lag1, int[] lag2, int[] lag3, float[] a) {
/* 1250 */     Check.argument((lag1.length > 0), "lag1.length>0");
/* 1251 */     Check.argument((lag1.length == a.length), "lag1.length==a.length");
/* 1252 */     Check.argument((lag2.length == a.length), "lag2.length==a.length");
/* 1253 */     Check.argument((lag3.length == a.length), "lag3.length==a.length");
/* 1254 */     Check.argument((lag1[0] == 0), "lag1[0]==0");
/* 1255 */     Check.argument((lag2[0] == 0), "lag2[0]==0");
/* 1256 */     Check.argument((lag3[0] == 0), "lag3[0]==0");
/* 1257 */     for (int j = 1; j < a.length; j++) {
/* 1258 */       Check.argument((lag3[j] >= 0), "lag3[" + j + "]>=0");
/* 1259 */       if (lag3[j] == 0) {
/* 1260 */         Check.argument((lag2[j] >= 0), "if lag3==0, lag2[" + j + "]>=0");
/* 1261 */         if (lag2[j] == 0)
/* 1262 */           Check.argument((lag1[j] > 0), "if lag3==0 && lag2==0, lag1[" + j + "]>0"); 
/*      */       } 
/*      */     } 
/* 1265 */     this._m = a.length;
/* 1266 */     this._lag1 = Array.copy(lag1);
/* 1267 */     this._lag2 = Array.copy(lag2);
/* 1268 */     this._lag3 = Array.copy(lag3);
/* 1269 */     this._min1 = Array.min(lag1);
/* 1270 */     this._min2 = Array.min(lag2);
/* 1271 */     this._min3 = Array.min(lag3);
/* 1272 */     this._max1 = Array.max(lag1);
/* 1273 */     this._max2 = Array.max(lag2);
/* 1274 */     this._max3 = Array.max(lag3);
/*      */   }
/*      */   
/*      */   private void initA(float[] a) {
/* 1278 */     this._a = Array.copy(a);
/* 1279 */     this._a0 = a[0];
/* 1280 */     this._a0i = 1.0F / a[0];
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/CausalFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */