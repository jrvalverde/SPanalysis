/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.CoordinateTransform;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import edu.mines.jtk.util.Array;
/*    */ import java.util.Arrays;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoordinateTransformTest
/*    */   extends TestCase
/*    */ {
/*    */   public void testAll() throws Exception {
/* 27 */     double[][] in = { { 1.0D, 1.0D }, { 2.0D, 2.0D }, { 3.0D, 4.0D } };
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 32 */     double[][] out = { { 2.0D }, { 4.0D }, { 7.0D } };
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     double[][] inCopy = Array.copy(in);
/* 38 */     double[][] outCopy = Array.copy(out);
/*    */     
/* 40 */     CoordinateTransform ls = new CoordinateTransform(1, 2);
/* 41 */     for (int j = 0; j < out.length; j++) {
/* 42 */       ls.add(out[j], in[j]);
/*    */     }
/* 44 */     Almost almost = new Almost();
/*    */ 
/*    */     
/* 47 */     double a = 1.0D, b = 1.0D;
/*    */     
/* 49 */     assert almost.equal(a + b, ls.get(new double[] { a, b })[0]) : a + "+" + b + "!=" + ls.get(new double[] { a, b })[false];
/*    */     
/* 51 */     a = 2.0D; b = 2.0D;
/*    */     
/* 53 */     assert almost.equal(a + b, ls.get(new double[] { a, b })[0]) : a + "+" + b + "!=" + ls.get(new double[] { a, b })[false];
/*    */     
/* 55 */     a = 3.0D; b = 4.0D;
/*    */     
/* 57 */     assert almost.equal(a + b, ls.get(new double[] { a, b })[0]) : a + "+" + b + "!=" + ls.get(new double[] { a, b })[false];
/*    */     
/* 59 */     a = 1.0D; b = 3.0D;
/*    */     
/* 61 */     assert almost.equal(a + b, ls.get(new double[] { a, b })[0]) : a + "+" + b + "!=" + ls.get(new double[] { a, b })[false];
/*    */     
/* 63 */     a = 3.0D; b = 7.0D;
/*    */     
/* 65 */     assert almost.equal(a + b, ls.get(new double[] { a, b })[0]) : a + "+" + b + "!=" + ls.get(new double[] { a, b })[false];
/*    */ 
/*    */     
/* 68 */     assert Arrays.deepEquals((Object[])in, (Object[])inCopy) : Arrays.deepToString((Object[])in) + " " + Arrays.deepToString((Object[])inCopy);
/*    */     
/* 70 */     assert Arrays.deepEquals((Object[])out, (Object[])outCopy) : Arrays.deepToString((Object[])out) + " " + Arrays.deepToString((Object[])outCopy);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 76 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 79 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CoordinateTransformTest(String name) {
/* 85 */     super(name);
/*    */   }
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 90 */       throw new IllegalStateException("need -ea");
/* 91 */     } catch (AssertionError e) {
/* 92 */       return (Test)new TestSuite(CoordinateTransformTest.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 98 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/CoordinateTransformTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */