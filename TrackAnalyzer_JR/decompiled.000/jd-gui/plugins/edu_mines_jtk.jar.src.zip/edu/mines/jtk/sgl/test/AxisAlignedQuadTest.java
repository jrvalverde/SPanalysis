/*    */ package edu.mines.jtk.sgl.test;
/*    */ 
/*    */ import edu.mines.jtk.dsp.Sampling;
/*    */ import edu.mines.jtk.sgl.Axis;
/*    */ import edu.mines.jtk.sgl.AxisAlignedFrame;
/*    */ import edu.mines.jtk.sgl.AxisAlignedQuad;
/*    */ import edu.mines.jtk.sgl.ImagePanel;
/*    */ import edu.mines.jtk.sgl.Node;
/*    */ import edu.mines.jtk.sgl.Point3;
/*    */ import edu.mines.jtk.sgl.World;
/*    */ import edu.mines.jtk.util.Float3;
/*    */ import edu.mines.jtk.util.MathPlus;
/*    */ import edu.mines.jtk.util.SimpleFloat3;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AxisAlignedQuadTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     int nx = 101;
/* 24 */     int ny = 121;
/* 25 */     int nz = 141;
/* 26 */     double dx = 1.0D / (nx - 1);
/* 27 */     double dy = dx;
/* 28 */     double dz = dx;
/* 29 */     double fx = 0.0D;
/* 30 */     double fy = 0.0D;
/* 31 */     double fz = 0.0D;
/* 32 */     double lx = fx + (nx - 1) * dx;
/* 33 */     double ly = fy + (ny - 1) * dy;
/* 34 */     double lz = fz + (nz - 1) * dz;
/*    */     
/* 36 */     Point3 qmin = new Point3(fx, fy, fz);
/* 37 */     Point3 qmax = new Point3(lx, ly, lz);
/*    */     
/* 39 */     AxisAlignedQuad aaq = new AxisAlignedQuad(Axis.Y, qmin, qmax);
/* 40 */     AxisAlignedFrame aaf = aaq.getFrame();
/* 41 */     Sampling sx = new Sampling(nx, dx, fx);
/* 42 */     Sampling sy = new Sampling(ny, dy, fy);
/* 43 */     Sampling sz = new Sampling(nz, dz, fz);
/* 44 */     float[][][] a = new float[nx][ny][nz];
/* 45 */     for (int ix = 0; ix < nx; ix++) {
/* 46 */       float x = (float)(ix * dx);
/* 47 */       for (int iy = 0; iy < ny; iy++) {
/* 48 */         float y = (float)(iy * dy);
/* 49 */         for (int iz = 0; iz < nz; iz++) {
/* 50 */           float z = (float)(iz * dz);
/*    */           
/* 52 */           a[ix][iy][iz] = MathPlus.sin(12.566371F * (x + y + z));
/*    */         } 
/*    */       } 
/*    */     } 
/* 56 */     SimpleFloat3 simpleFloat3 = new SimpleFloat3(a);
/* 57 */     ImagePanel iop = new ImagePanel(sx, sy, sz, (Float3)simpleFloat3);
/* 58 */     aaf.addChild((Node)iop);
/*    */     
/* 60 */     World world = new World();
/* 61 */     world.addChild((Node)aaq);
/*    */     
/* 63 */     TestFrame frame = new TestFrame(world);
/* 64 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/test/AxisAlignedQuadTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */