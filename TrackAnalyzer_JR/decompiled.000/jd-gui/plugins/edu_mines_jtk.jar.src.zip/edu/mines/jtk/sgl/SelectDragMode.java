/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.awt.Mode;
/*     */ import edu.mines.jtk.awt.ModeManager;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ public class SelectDragMode
/*     */   extends Mode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ViewCanvas _canvas;
/*     */   private View _view;
/*     */   private World _world;
/*     */   private PickResult _pickResult;
/*     */   private Dragable _dragable;
/*     */   private Selectable _selectable;
/*     */   private DragContext _dragContext;
/*     */   private boolean _selecting;
/*     */   private MouseListener _ml;
/*     */   private MouseMotionListener _mml;
/*     */   
/*     */   public SelectDragMode(ModeManager modeManager) {
/*  30 */     super(modeManager);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this._ml = new MouseAdapter()
/*     */       {
/*     */         
/*     */         public void mousePressed(MouseEvent e)
/*     */         {
/*  70 */           SelectDragMode.this._selecting = true;
/*     */ 
/*     */           
/*  73 */           SelectDragMode.this._pickResult = SelectDragMode.this.pick(e);
/*  74 */           if (SelectDragMode.this._pickResult != null) {
/*  75 */             SelectDragMode.this._selectable = SelectDragMode.this._pickResult.getSelectableNode();
/*  76 */             SelectDragMode.this._dragable = SelectDragMode.this._pickResult.getDragableNode();
/*     */           } 
/*     */ 
/*     */           
/*  80 */           SelectDragMode.this._canvas = (ViewCanvas)e.getSource();
/*  81 */           SelectDragMode.this._view = SelectDragMode.this._canvas.getView();
/*  82 */           if (SelectDragMode.this._view != null) {
/*  83 */             SelectDragMode.this._world = SelectDragMode.this._view.getWorld();
/*     */           }
/*     */           
/*  86 */           SelectDragMode.this._canvas.addMouseMotionListener(SelectDragMode.this._mml);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void mouseReleased(MouseEvent e) {
/*  92 */           if (SelectDragMode.this._dragContext != null) {
/*  93 */             SelectDragMode.this._dragable.dragEnd(SelectDragMode.this._dragContext);
/*     */ 
/*     */           
/*     */           }
/*  97 */           else if (SelectDragMode.this._selecting) {
/*     */ 
/*     */             
/* 100 */             if (e.isControlDown()) {
/* 101 */               if (SelectDragMode.this._selectable != null) {
/* 102 */                 SelectDragMode.this._selectable.setSelected(!SelectDragMode.this._selectable.isSelected());
/*     */               
/*     */               }
/*     */             }
/* 106 */             else if (e.isShiftDown()) {
/* 107 */               if (SelectDragMode.this._selectable != null) {
/* 108 */                 SelectDragMode.this._selectable.setSelected(true);
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 113 */             else if (SelectDragMode.this._selectable != null) {
/* 114 */               SelectDragMode.this._world.clearSelectedExcept(SelectDragMode.this._selectable);
/* 115 */               SelectDragMode.this._selectable.setSelected(true);
/*     */             }
/* 117 */             else if (SelectDragMode.this._world != null) {
/* 118 */               SelectDragMode.this._world.clearSelected();
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 124 */           SelectDragMode.this._dragable = null;
/* 125 */           SelectDragMode.this._dragContext = null;
/* 126 */           SelectDragMode.this._selectable = null;
/* 127 */           SelectDragMode.this._selecting = false;
/*     */ 
/*     */           
/* 130 */           SelectDragMode.this._canvas.removeMouseMotionListener(SelectDragMode.this._mml);
/*     */         }
/*     */       };
/*     */     
/* 134 */     this._mml = new MouseMotionAdapter()
/*     */       {
/*     */         
/*     */         public void mouseDragged(MouseEvent e)
/*     */         {
/* 139 */           SelectDragMode.this._selecting = (SelectDragMode.this._dragContext == null);
/* 140 */           if (SelectDragMode.this._selecting && SelectDragMode.this._pickResult != null) {
/* 141 */             Point3 pp = SelectDragMode.this._pickResult.getPointPixel();
/* 142 */             Point3 pd = new Point3(e.getX(), e.getY(), pp.z);
/* 143 */             if (pp.distanceTo(pd) >= 2.0D) {
/* 144 */               SelectDragMode.this._selecting = false;
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 149 */           if (!SelectDragMode.this._selecting && SelectDragMode.this._dragable != null && SelectDragMode.this._dragContext == null) {
/* 150 */             SelectDragMode.this._dragContext = new DragContext(SelectDragMode.this._pickResult);
/* 151 */             SelectDragMode.this._dragable.dragBegin(SelectDragMode.this._dragContext);
/*     */           } 
/*     */ 
/*     */           
/* 155 */           if (SelectDragMode.this._dragContext != null) {
/* 156 */             SelectDragMode.this._dragContext.update(e);
/* 157 */             SelectDragMode.this._dragable.drag(SelectDragMode.this._dragContext);
/*     */           }  } }; setName("Select"); Class<SelectDragMode> cls = SelectDragMode.class;
/*     */     setIcon(loadIcon(cls, "resources/SelectDragIcon16.png"));
/*     */     setCursor(loadCursor(cls, "resources/SelectDragCursor16.png", 1, 1));
/*     */     setMnemonicKey(83);
/*     */     setAcceleratorKey(KeyStroke.getKeyStroke(83, 0));
/* 163 */     setShortDescription("Select/drag"); } private PickResult pick(MouseEvent event) { ViewCanvas canvas = (ViewCanvas)event.getSource();
/* 164 */     canvas.addMouseMotionListener(this._mml);
/* 165 */     View view = canvas.getView();
/* 166 */     if (view == null)
/* 167 */       return null; 
/* 168 */     World world = view.getWorld();
/* 169 */     if (world == null)
/* 170 */       return null; 
/* 171 */     PickContext pc = new PickContext(event);
/* 172 */     world.pickApply(pc);
/* 173 */     PickResult pickResult = pc.getClosest();
/* 174 */     if (pickResult != null) {
/* 175 */       Point3 pointLocal = pickResult.getPointLocal();
/* 176 */       Point3 pointWorld = pickResult.getPointWorld();
/* 177 */       System.out.println("Pick");
/* 178 */       System.out.println("  local=" + pointLocal);
/* 179 */       System.out.println("  world=" + pointWorld);
/*     */     } else {
/* 181 */       System.out.println("Pick nothing");
/*     */     } 
/* 183 */     return pickResult; }
/*     */ 
/*     */   
/*     */   protected void setActive(Component component, boolean active) {
/*     */     if (component instanceof ViewCanvas)
/*     */       if (active) {
/*     */         component.addMouseListener(this._ml);
/*     */       } else {
/*     */         component.removeMouseListener(this._ml);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/SelectDragMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */