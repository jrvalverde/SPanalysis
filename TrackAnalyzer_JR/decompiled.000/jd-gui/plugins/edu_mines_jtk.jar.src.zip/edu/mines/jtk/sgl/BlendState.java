/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ import edu.mines.jtk.ogl.Gl;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlendState
/*     */   implements State
/*     */ {
/*     */   public boolean hasColor() {
/*  31 */     return this._colorSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/*  39 */     return this._color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Color color) {
/*  47 */     this._color = color;
/*  48 */     this._colorSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetColor() {
/*  55 */     this._color = _colorDefault;
/*  56 */     this._colorSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasEquation() {
/*  64 */     return this._equationSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEquation() {
/*  72 */     return this._equation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEquation(int mode) {
/*  80 */     this._equation = mode;
/*  81 */     this._equationSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetEquation() {
/*  88 */     this._equation = _equationDefault;
/*  89 */     this._equationSet = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasBlendFunction() {
/*  97 */     return this._functionSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSfactor() {
/* 105 */     return this._sfactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDfactor() {
/* 113 */     return this._dfactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFunction(int sfactor, int dfactor) {
/* 122 */     this._sfactor = sfactor;
/* 123 */     this._dfactor = dfactor;
/* 124 */     this._functionSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFunction() {
/* 131 */     this._sfactor = _sfactorDefault;
/* 132 */     this._dfactor = _dfactorDefault;
/* 133 */     this._functionSet = false;
/*     */   }
/*     */   
/*     */   public void apply() {
/* 137 */     Gl.glEnable(3042);
/* 138 */     if (this._colorSet) {
/* 139 */       float r = this._color.getRed() / 255.0F;
/* 140 */       float g = this._color.getGreen() / 255.0F;
/* 141 */       float b = this._color.getBlue() / 255.0F;
/* 142 */       float a = this._color.getAlpha() / 255.0F;
/* 143 */       Gl.glBlendColor(r, g, b, a);
/*     */     } 
/* 145 */     if (this._equationSet)
/* 146 */       Gl.glBlendEquation(this._equation); 
/* 147 */     if (this._functionSet)
/* 148 */       Gl.glBlendFunc(this._sfactor, this._dfactor); 
/*     */   }
/*     */   
/*     */   public int getAttributeBits() {
/* 152 */     return 24576;
/*     */   }
/*     */   
/* 155 */   private static Color _colorDefault = new Color(0.0F, 0.0F, 0.0F, 0.0F);
/* 156 */   private Color _color = _colorDefault;
/*     */   
/*     */   private boolean _colorSet;
/* 159 */   private static int _equationDefault = 32774;
/* 160 */   private int _equation = _equationDefault;
/*     */   
/*     */   private boolean _equationSet;
/* 163 */   private static int _sfactorDefault = 1;
/* 164 */   private static int _dfactorDefault = 0;
/* 165 */   private int _sfactor = _sfactorDefault;
/* 166 */   private int _dfactor = _dfactorDefault;
/*     */   private boolean _functionSet;
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/BlendState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */