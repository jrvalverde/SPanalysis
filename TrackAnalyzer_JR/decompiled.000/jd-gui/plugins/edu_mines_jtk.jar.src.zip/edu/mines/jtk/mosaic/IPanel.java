/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageTypeSpecifier;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.metadata.IIOMetadata;
/*     */ import javax.imageio.metadata.IIOMetadataNode;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/*  71 */     g2d = createGraphics(g2d, x, y, w, h);
/*     */ 
/*     */     
/*  74 */     double ws = w / getWidth();
/*  75 */     double hs = h / getHeight();
/*  76 */     int nc = getComponentCount();
/*  77 */     for (int ic = 0; ic < nc; ic++) {
/*  78 */       Component c = getComponent(ic);
/*  79 */       int xc = c.getX();
/*  80 */       int yc = c.getY();
/*  81 */       int wc = c.getWidth();
/*  82 */       int hc = c.getHeight();
/*  83 */       xc = (int)Math.round(xc * ws);
/*  84 */       yc = (int)Math.round(yc * hs);
/*  85 */       wc = (int)Math.round(wc * ws);
/*  86 */       hc = (int)Math.round(hc * hs);
/*  87 */       if (c instanceof IPanel) {
/*  88 */         IPanel ip = (IPanel)c;
/*  89 */         ip.paintToRect(g2d, xc, yc, wc, hc);
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     g2d.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintToImage(BufferedImage image) {
/* 101 */     Graphics2D g2d = image.createGraphics();
/*     */ 
/*     */     
/* 104 */     g2d.setColor(getBackground());
/* 105 */     g2d.fillRect(0, 0, image.getWidth(), image.getHeight());
/* 106 */     g2d.setColor(getForeground());
/* 107 */     g2d.setFont(getFont());
/*     */ 
/*     */     
/* 110 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     paintToRect(g2d, 0, 0, image.getWidth(), image.getHeight());
/*     */     
/* 117 */     g2d.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage paintToImage(int width) {
/* 128 */     int wpanel = getWidth();
/* 129 */     int hpanel = getHeight();
/* 130 */     double scale = width / wpanel;
/* 131 */     int wimage = (int)(scale * wpanel + 0.5D);
/* 132 */     int himage = (int)(scale * hpanel + 0.5D);
/* 133 */     int type = 1;
/* 134 */     BufferedImage image = new BufferedImage(wimage, himage, type);
/* 135 */     paintToImage(image);
/* 136 */     return image;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintToPng(double dpi, double win, String fileName) throws IOException {
/* 150 */     BufferedImage image = paintToImage((int)Math.ceil(dpi * win));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     Iterator<ImageWriter> i = ImageIO.getImageWritersBySuffix("png");
/* 156 */     if (!i.hasNext())
/* 157 */       throw new IOException("cannot get a PNG image writer"); 
/* 158 */     ImageWriter iw = i.next();
/* 159 */     FileOutputStream fos = new FileOutputStream(fileName);
/* 160 */     ImageOutputStream ios = ImageIO.createImageOutputStream(fos);
/* 161 */     iw.setOutput(ios);
/* 162 */     ImageWriteParam iwp = iw.getDefaultWriteParam();
/* 163 */     ImageTypeSpecifier its = new ImageTypeSpecifier(image);
/* 164 */     IIOMetadata imd = iw.getDefaultImageMetadata(its, iwp);
/* 165 */     String format = "javax_imageio_png_1.0";
/* 166 */     IIOMetadataNode tree = (IIOMetadataNode)imd.getAsTree(format);
/* 167 */     IIOMetadataNode node = new IIOMetadataNode("pHYs");
/* 168 */     String dpm = Integer.toString((int)Math.ceil(dpi / 0.0254D));
/* 169 */     node.setAttribute("pixelsPerUnitXAxis", dpm);
/* 170 */     node.setAttribute("pixelsPerUnitYAxis", dpm);
/* 171 */     node.setAttribute("unitSpecifier", "meter");
/* 172 */     tree.appendChild(node);
/* 173 */     imd.setFromTree(format, tree);
/* 174 */     iw.write(new IIOImage(image, null, imd));
/* 175 */     ios.flush();
/* 176 */     ios.close();
/* 177 */     fos.flush();
/* 178 */     fos.close();
/* 179 */     iw.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeScale(int w, int h) {
/* 194 */     double wscale = w / getWidth();
/* 195 */     double hscale = h / getHeight();
/* 196 */     double scale = Math.min(wscale, hscale);
/* 197 */     return scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Graphics2D createGraphics(Graphics2D g2d, int x, int y, int w, int h) {
/* 227 */     g2d = (Graphics2D)g2d.create();
/*     */ 
/*     */     
/* 230 */     double scale = computeScale(w, h);
/*     */ 
/*     */     
/* 233 */     Rectangle clipRect = g2d.getClipBounds();
/* 234 */     Rectangle g2dRect = new Rectangle(x, y, w, h);
/* 235 */     g2d.setClip((clipRect == null) ? g2dRect : clipRect.intersection(g2dRect));
/*     */ 
/*     */     
/* 238 */     g2d.translate(x, y);
/*     */ 
/*     */     
/* 241 */     float lineWidth = (float)scale;
/* 242 */     g2d.setStroke(new BasicStroke(lineWidth));
/*     */ 
/*     */     
/* 245 */     Font font = getFont();
/* 246 */     float fontSize = (float)scale * font.getSize2D();
/* 247 */     g2d.setFont(font.deriveFont(fontSize));
/*     */     
/* 249 */     return g2d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float getLineWidth(Graphics2D g2d) {
/* 258 */     float lineWidth = 1.0F;
/* 259 */     Stroke stroke = g2d.getStroke();
/* 260 */     if (stroke instanceof BasicStroke) {
/* 261 */       BasicStroke bs = (BasicStroke)stroke;
/* 262 */       lineWidth = bs.getLineWidth();
/*     */     } 
/* 264 */     return lineWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void scaleLineWidth(Graphics2D g2d, double scale) {
/* 277 */     float lineWidth = getLineWidth(g2d);
/* 278 */     lineWidth = (float)(lineWidth * scale);
/* 279 */     g2d.setStroke(new BasicStroke(lineWidth));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/IPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */