/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.util.AxisTics;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.LineMetrics;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.RepaintManager;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileAxis
/*     */   extends IPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int _widthMinimum;
/*     */   private Mosaic _mosaic;
/*     */   private Placement _placement;
/*     */   private int _index;
/*     */   private String _label;
/*     */   private String _format;
/*     */   private int _xtrack;
/*     */   private int _ytrack;
/*     */   private boolean _tracking;
/*     */   private double _interval;
/*     */   private int _ticLabelWidth;
/*     */   private int _ticLabelHeight;
/*     */   private AxisTics _axisTics;
/*     */   
/*     */   public enum Placement
/*     */   {
/*  41 */     TOP, LEFT, BOTTOM, RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mosaic getMosaic() {
/*  49 */     return this._mosaic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/*  57 */     return this._index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Placement getPlacement() {
/*  65 */     return this._placement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tile getTile() {
/*  73 */     if (isTop())
/*  74 */       return this._mosaic.getTile(0, this._index); 
/*  75 */     if (isLeft())
/*  76 */       return this._mosaic.getTile(this._index, 0); 
/*  77 */     if (isBottom()) {
/*  78 */       int irow = this._mosaic.countRows() - 1;
/*  79 */       return this._mosaic.getTile(irow, this._index);
/*  80 */     }  if (isRight()) {
/*  81 */       int icol = this._mosaic.countColumns() - 1;
/*  82 */       return this._mosaic.getTile(this._index, icol);
/*     */     } 
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTop() {
/*  93 */     return (this._placement == Placement.TOP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeft() {
/* 101 */     return (this._placement == Placement.LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBottom() {
/* 109 */     return (this._placement == Placement.BOTTOM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRight() {
/* 117 */     return (this._placement == Placement.RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHorizontal() {
/* 126 */     return (this._placement == Placement.TOP || this._placement == Placement.BOTTOM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVertical() {
/* 135 */     return (this._placement == Placement.LEFT || this._placement == Placement.RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterval(double interval) {
/* 146 */     this._interval = interval;
/* 147 */     updateAxisTics();
/* 148 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String label) {
/* 156 */     this._label = label;
/* 157 */     updateAxisTics();
/* 158 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormat(String format) {
/* 169 */     this._format = format;
/* 170 */     updateAxisTics();
/* 171 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 176 */     super.setFont(font);
/* 177 */     updateAxisTics();
/* 178 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/* 183 */     super.setBounds(x, y, width, height);
/* 184 */     updateAxisTics();
/* 185 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisTics getAxisTics() {
/* 193 */     return this._axisTics;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintToRect(Graphics2D g2d, int x, int y, int w, int h) {
/* 199 */     if (this._axisTics == null) {
/*     */       return;
/*     */     }
/*     */     
/* 203 */     Tile tile = getTile();
/* 204 */     if (tile == null) {
/*     */       return;
/*     */     }
/*     */     
/* 208 */     g2d = createGraphics(g2d, x, y, w, h);
/* 209 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 212 */     g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     Projector p = isHorizontal() ? tile.getHorizontalProjector() : tile.getVerticalProjector();
/*     */ 
/*     */     
/* 220 */     Transcaler t = tile.getTranscaler(w, h);
/*     */ 
/*     */     
/* 223 */     Font font = g2d.getFont();
/* 224 */     FontMetrics fm = g2d.getFontMetrics();
/* 225 */     FontRenderContext frc = g2d.getFontRenderContext();
/* 226 */     LineMetrics lm = font.getLineMetrics("0.123456789", frc);
/* 227 */     int fh = Math.round(lm.getHeight());
/* 228 */     int fa = Math.round(lm.getAscent());
/* 229 */     int fd = Math.round(lm.getDescent());
/* 230 */     int fl = Math.round(lm.getLeading());
/*     */ 
/*     */     
/* 233 */     int tl = 2 * fa / 3;
/*     */ 
/*     */     
/* 236 */     boolean isHorizontal = isHorizontal();
/* 237 */     boolean isTop = isTop();
/* 238 */     boolean isLeft = isLeft();
/*     */ 
/*     */     
/* 241 */     int nticMajor = this._axisTics.getCountMajor();
/* 242 */     double dticMajor = this._axisTics.getDeltaMajor();
/* 243 */     double fticMajor = this._axisTics.getFirstMajor();
/* 244 */     int nticMinor = this._axisTics.getCountMinor();
/* 245 */     double dticMinor = this._axisTics.getDeltaMinor();
/* 246 */     double fticMinor = this._axisTics.getFirstMinor();
/* 247 */     int mtic = this._axisTics.getMultiple();
/*     */ 
/*     */     
/* 250 */     int ktic = (int)Math.round((fticMajor - fticMinor) / dticMinor);
/* 251 */     for (int itic = 0; itic < nticMinor; itic++) {
/* 252 */       if (itic == ktic) {
/* 253 */         ktic += mtic;
/*     */       } else {
/* 255 */         double vtic = fticMinor + itic * dticMinor;
/* 256 */         double utic = p.u(vtic);
/* 257 */         if (isHorizontal) {
/* 258 */           x = t.x(utic);
/* 259 */           if (isTop) {
/* 260 */             g2d.drawLine(x, h - 1, x, h - 1 - tl / 2);
/*     */           } else {
/* 262 */             g2d.drawLine(x, 0, x, tl / 2);
/*     */           } 
/*     */         } else {
/* 265 */           y = t.y(utic);
/* 266 */           if (isLeft) {
/* 267 */             g2d.drawLine(w - 1, y, w - 1 - tl / 2, y);
/*     */           } else {
/* 269 */             g2d.drawLine(0, y, tl / 2, y);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 276 */     int wsmax = 0;
/* 277 */     double tiny = 1.0E-6D * Math.abs(dticMajor);
/* 278 */     for (int i = 0; i < nticMajor; i++) {
/* 279 */       double vtic = fticMajor + i * dticMajor;
/* 280 */       double utic = p.u(vtic);
/* 281 */       if (Math.abs(vtic) < tiny)
/* 282 */         vtic = 0.0D; 
/* 283 */       String stic = formatTic(vtic);
/* 284 */       if (isHorizontal) {
/* 285 */         x = t.x(utic);
/* 286 */         if (isTop) {
/* 287 */           y = h - 1;
/* 288 */           g2d.drawLine(x, y, x, y - tl);
/* 289 */           y -= tl + fd;
/*     */         } else {
/* 291 */           y = 0;
/* 292 */           g2d.drawLine(x, y, x, y + tl);
/* 293 */           y += tl + fa;
/*     */         } 
/* 295 */         int ws = fm.stringWidth(stic);
/* 296 */         int xs = Math.max(0, Math.min(w - ws, x - ws / 2));
/* 297 */         int ys = y;
/* 298 */         g2d.drawString(stic, xs, ys);
/*     */       } else {
/* 300 */         y = t.y(utic);
/* 301 */         if (isLeft) {
/* 302 */           x = w - 1;
/* 303 */           g2d.drawLine(x, y, x - tl, y);
/* 304 */           x -= tl + fd;
/*     */         } else {
/* 306 */           x = 0;
/* 307 */           g2d.drawLine(x, y, x + tl, y);
/* 308 */           x += tl + fd;
/*     */         } 
/* 310 */         int ws = fm.stringWidth(stic);
/* 311 */         if (ws > wsmax)
/* 312 */           wsmax = ws; 
/* 313 */         int xs = isLeft ? (x - ws) : x;
/* 314 */         int ys = Math.max(fa, Math.min(h - 1, y + (int)Math.round(0.3D * fa)));
/* 315 */         g2d.drawString(stic, xs, ys);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 320 */     if (this._label != null) {
/* 321 */       if (isHorizontal) {
/* 322 */         int wl = fm.stringWidth(this._label);
/* 323 */         int xl = Math.max(0, Math.min(w - wl, (w - wl) / 2));
/* 324 */         int yl = isTop ? (h - 1 - tl - fh - fd) : (tl + fh + fa);
/* 325 */         g2d.drawString(this._label, xl, yl);
/*     */       } else {
/* 327 */         int wl = fm.stringWidth(this._label);
/*     */ 
/*     */ 
/*     */         
/* 331 */         int xl = isLeft ? (fa + fd) : (w - 1 - fd - fd - fl);
/* 332 */         int yl = Math.max(wl, Math.min(h, (h + wl) / 2));
/* 333 */         g2d.translate(xl, yl);
/* 334 */         g2d.rotate(-1.5707963267948966D);
/* 335 */         g2d.drawString(this._label, 0, 0);
/* 336 */         g2d.rotate(1.5707963267948966D);
/* 337 */         g2d.translate(-xl, -yl);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 342 */     g2d.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 349 */     super.paintComponent(g);
/* 350 */     endTracking();
/* 351 */     paintToRect((Graphics2D)g, 0, 0, getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getWidthMinimum() {
/*     */     if (this._widthMinimum != 0) {
/*     */       return this._widthMinimum;
/*     */     }
/*     */     FontMetrics fm = getFontMetrics(getFont());
/*     */     int ticLabelWidth = this._ticLabelWidth;
/*     */     if (ticLabelWidth == 0) {
/*     */       ticLabelWidth = maxTicLabelWidth(fm);
/*     */     }
/*     */     int width = 0;
/*     */     if (isVertical()) {
/*     */       width = ticLabelWidth + fm.getHeight();
/*     */       if (this._label != null) {
/*     */         width += fm.getHeight();
/*     */       }
/*     */     } else {
/*     */       width = 50;
/*     */       if (this._label != null) {
/*     */         width = Math.max(width, fm.stringWidth(this._label));
/*     */       }
/*     */     } 
/*     */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setWidthMinimum(int widthMinimum) {
/*     */     this._widthMinimum = widthMinimum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getHeightMinimum() {
/*     */     FontMetrics fm = getFontMetrics(getFont());
/*     */     int height = 0;
/*     */     if (isHorizontal()) {
/*     */       height = fm.getHeight() + fm.getAscent();
/*     */       if (this._label != null) {
/*     */         height += fm.getHeight();
/*     */       }
/*     */     } else {
/*     */       height = 50;
/*     */       if (this._label != null) {
/*     */         height = Math.max(height, fm.stringWidth(this._label));
/*     */       }
/*     */     } 
/*     */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateAxisTics() {
/*     */     double u0, u1, du;
/*     */     Tile tile = getTile();
/*     */     if (tile == null) {
/*     */       return;
/*     */     }
/*     */     int w = getWidth();
/*     */     int h = getHeight();
/*     */     if (w == 0 || h == 0) {
/*     */       return;
/*     */     }
/*     */     Projector p = isHorizontal() ? tile.getHorizontalProjector() : tile.getVerticalProjector();
/*     */     Transcaler t = tile.getTranscaler(w, h);
/*     */     Font font = getFont();
/*     */     FontRenderContext frc = new FontRenderContext(null, true, false);
/*     */     boolean isHorizontal = isHorizontal();
/*     */     double umin = p.u0();
/*     */     double umax = p.u1();
/*     */     double vmin = Math.min(p.v0(), p.v1());
/*     */     double vmax = Math.max(p.v0(), p.v1());
/*     */     if (isHorizontal) {
/*     */       u0 = Math.max(umin, t.x(0));
/*     */       u1 = Math.min(umax, t.x(w - 1));
/*     */       du = Math.min(umax - umin, t.width(w));
/*     */     } else {
/*     */       u0 = Math.max(umin, t.y(0));
/*     */       u1 = Math.min(umax, t.y(h - 1));
/*     */       du = Math.min(umax - umin, t.height(h));
/*     */     } 
/*     */     double v0 = Math.max(vmin, Math.min(vmax, p.v(u0)));
/*     */     double v1 = Math.max(vmin, Math.min(vmax, p.v(u1)));
/*     */     double dv = Math.abs(p.v(u0 + du) - p.v(u0));
/*     */     int ticLabelWidth = 0;
/*     */     int ticLabelHeight = 0;
/*     */     int ntic = 0;
/*     */     double dtic = 0.0D;
/*     */     int nmax;
/*     */     for (nmax = 20; nmax >= 2; nmax = ntic - 1) {
/*     */       AxisTics at;
/*     */       if (this._interval == 0.0D) {
/*     */         at = new AxisTics(vmin, vmin + dv, nmax);
/*     */       } else {
/*     */         at = new AxisTics(vmin, vmin + dv, this._interval);
/*     */       } 
/*     */       ntic = at.getCountMajor();
/*     */       dtic = at.getDeltaMajor();
/*     */       double va = Math.ceil(vmin / dtic) * dtic;
/*     */       double vb = Math.floor(vmax / dtic) * dtic;
/*     */       Rectangle2D.Double r = new Rectangle2D.Double();
/*     */       Rectangle2D.union(font.getStringBounds(formatTic(va), frc), r, r);
/*     */       Rectangle2D.union(font.getStringBounds(formatTic(va + dtic), frc), r, r);
/*     */       Rectangle2D.union(font.getStringBounds(formatTic(vb - dtic), frc), r, r);
/*     */       Rectangle2D.union(font.getStringBounds(formatTic(vb), frc), r, r);
/*     */       ticLabelWidth = (int)Math.ceil(r.width);
/*     */       ticLabelHeight = (int)Math.ceil(r.height);
/*     */       if (this._interval != 0.0D) {
/*     */         break;
/*     */       }
/*     */       if (isHorizontal ? ((ticLabelWidth * ntic) < 0.7D * w) : ((ticLabelHeight * ntic) < 0.6D * h)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     this._axisTics = new AxisTics(v0, v1, dtic);
/*     */     if (this._ticLabelWidth != ticLabelWidth || this._ticLabelHeight != ticLabelHeight) {
/*     */       this._ticLabelWidth = ticLabelWidth;
/*     */       this._ticLabelHeight = ticLabelHeight;
/*     */       revalidateLater();
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TileAxis(Mosaic mosaic, Placement placement, int index) {
/* 604 */     this._format = "%1.4G";
/*     */     this._mosaic = mosaic;
/*     */     this._placement = placement;
/*     */     this._index = index;
/*     */     mosaic.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxTicLabelWidth(FontMetrics fm) {
/* 617 */     double vtic = -0.0123456789D;
/* 618 */     return fm.stringWidth(formatTic(vtic));
/*     */   } void beginTracking(int x, int y) { if (!this._tracking) {
/*     */       this._xtrack = x; this._ytrack = y;
/*     */       this._tracking = true;
/*     */       paintTrack(x, y);
/* 623 */     }  } private String formatTic(double v) { String s = String.format(this._format, new Object[] { Double.valueOf(v) });
/* 624 */     int len = s.length();
/* 625 */     int iend = s.indexOf('e');
/* 626 */     if (iend < 0)
/* 627 */       iend = s.indexOf('E'); 
/* 628 */     if (iend < 0)
/* 629 */       iend = len; 
/* 630 */     int ibeg = iend;
/* 631 */     if (s.indexOf('.') > 0) {
/* 632 */       while (ibeg > 0 && s.charAt(ibeg - 1) == '0')
/* 633 */         ibeg--; 
/* 634 */       if (ibeg > 0 && s.charAt(ibeg - 1) == '.')
/* 635 */         ibeg--; 
/*     */     } 
/* 637 */     if (ibeg < iend) {
/* 638 */       String sb = s.substring(0, ibeg);
/* 639 */       s = (iend < len) ? (sb + s.substring(iend, len)) : sb;
/*     */     } 
/* 641 */     return s; }
/*     */ 
/*     */   
/*     */   void duringTracking(int x, int y) {
/*     */     if (this._tracking) {
/*     */       paintTrack(this._xtrack, this._ytrack);
/*     */     }
/*     */     this._xtrack = x;
/*     */     this._ytrack = y;
/*     */     this._tracking = true;
/*     */     paintTrack(this._xtrack, this._ytrack);
/*     */   }
/*     */   
/*     */   private void revalidateLater() {
/* 655 */     SwingUtilities.invokeLater(new Runnable()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run()
/*     */           {
/* 663 */             TileAxis.this.invalidate();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 668 */             RepaintManager.currentManager(TileAxis.this).addInvalidComponent(TileAxis.this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 677 */             RepaintManager.currentManager(TileAxis.this).validateInvalidComponents();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   void endTracking() {
/*     */     if (this._tracking) {
/*     */       paintTrack(this._xtrack, this._ytrack);
/*     */       this._tracking = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintTrack(int x, int y) {
/*     */     int w = getWidth();
/*     */     int h = getHeight();
/*     */     Graphics g = getGraphics();
/*     */     g.setColor(Color.BLUE);
/*     */     g.setXORMode(getBackground());
/*     */     if (isHorizontal()) {
/*     */       g.drawLine(x, -1, x, h);
/*     */     } else {
/*     */       g.drawLine(-1, y, w, y);
/*     */     } 
/*     */     g.dispose();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/TileAxis.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */