/*    */ package edu.mines.jtk.util.test;
/*    */ 
/*    */ import edu.mines.jtk.util.Array;
/*    */ import edu.mines.jtk.util.Quantiler;
/*    */ import edu.mines.jtk.util.Stopwatch;
/*    */ import java.util.Random;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuantilerTest
/*    */   extends TestCase
/*    */ {
/*    */   public static void main(String[] args) {
/* 23 */     if (args.length > 0 && args[0].equals("bench"))
/* 24 */       bench(); 
/* 25 */     TestSuite suite = new TestSuite(QuantilerTest.class);
/* 26 */     TestRunner.run((Test)suite);
/*    */   }
/*    */ 
/*    */   
/*    */   public void testLinear() {
/* 31 */     int n = 101;
/* 32 */     float[] f = new float[n]; int i;
/* 33 */     for (i = 0; i < n; i++) {
/* 34 */       f[i] = i / (n - 1);
/*    */     }
/* 36 */     for (i = 0; i < n; i++) {
/* 37 */       float q = f[i];
/* 38 */       Quantiler quantiler = new Quantiler(q);
/* 39 */       int nupdate = 20;
/* 40 */       for (int iupdate = 0; iupdate < nupdate; iupdate++) {
/* 41 */         quantiler.update(f);
/*    */       }
/* 43 */       float e = quantiler.estimate();
/* 44 */       float elo = q - 0.01F;
/* 45 */       float ehi = q + 0.01F;
/* 46 */       assertTrue((elo <= e));
/* 47 */       assertTrue((e <= ehi));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void testRandom() {
/* 52 */     int n = 10000;
/* 53 */     float[] f = Array.randfloat(new Random(314159L), n);
/* 54 */     int ntest = 101;
/* 55 */     for (int itest = 0; itest < ntest; itest++) {
/* 56 */       float q = itest / (ntest - 1);
/* 57 */       Quantiler quantiler = new Quantiler(q);
/* 58 */       quantiler.update(f);
/* 59 */       float e = quantiler.estimate();
/* 60 */       float elo = q - 0.01F;
/* 61 */       float ehi = q + 0.01F;
/* 62 */       assertTrue((elo <= e));
/* 63 */       assertTrue((e <= ehi));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void bench() {
/* 71 */     Stopwatch sw = new Stopwatch();
/* 72 */     int n = 1000001;
/* 73 */     double maxtime = 2.0D;
/*    */ 
/*    */     
/* 76 */     for (int ntrial = 0; ntrial < 3; ntrial++) {
/* 77 */       float[] f1 = Array.randfloat(n);
/*    */       
/* 79 */       float q1 = 0.0F;
/* 80 */       sw.restart(); int nq;
/* 81 */       for (nq = 0; sw.time() < maxtime; nq++) {
/* 82 */         Quantiler quantiler = new Quantiler(0.5F);
/* 83 */         quantiler.update(f1);
/* 84 */         q1 = quantiler.estimate();
/*    */       } 
/* 86 */       sw.stop();
/* 87 */       int rate = (int)(1.0E-6D * nq * n / sw.time());
/* 88 */       System.out.println("Quantiler:        median=" + q1 + " rate=" + rate);
/*    */       
/* 90 */       float q2 = 0.0F;
/* 91 */       sw.restart();
/* 92 */       for (nq = 0; sw.time() < maxtime; nq++) {
/* 93 */         float[] f2 = Array.copy(f1);
/* 94 */         Array.quickPartialSort(n / 2, f2);
/* 95 */         q2 = f2[n / 2];
/*    */       } 
/* 97 */       sw.stop();
/* 98 */       rate = (int)(1.0E-6D * nq * n / sw.time());
/* 99 */       System.out.println("quickPartialSort: median=" + q2 + " rate=" + rate);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/QuantilerTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */