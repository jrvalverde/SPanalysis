/*     */ package edu.mines.jtk.dsp.test;
/*     */ 
/*     */ import edu.mines.jtk.dsp.MinimumPhaseFilter;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimumPhaseFilterTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  23 */     TestSuite suite = new TestSuite(MinimumPhaseFilterTest.class);
/*  24 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test1Random() {
/*  28 */     int[] lag1 = { 0, 1, 2 };
/*  29 */     float[] a = { 2.0F, 1.8F, 0.81F };
/*  30 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, a);
/*  31 */     int n = 100;
/*     */ 
/*     */     
/*  34 */     float[] x = randfloat(n);
/*  35 */     float[] y = zerofloat(n);
/*  36 */     float[] z = zerofloat(n);
/*  37 */     mpf.apply(x, y);
/*  38 */     mpf.applyInverse(y, z);
/*  39 */     assertEqual(x, z);
/*  40 */     mpf.applyTranspose(x, y);
/*  41 */     mpf.applyInverseTranspose(y, z);
/*  42 */     assertEqual(x, z);
/*     */ 
/*     */     
/*  45 */     float tiny = n * 10.0F * 1.1920929E-7F;
/*  46 */     x = randfloat(n);
/*  47 */     y = randfloat(n);
/*  48 */     z = zerofloat(n);
/*  49 */     mpf.apply(x, z);
/*  50 */     float d1 = dot(z, y);
/*  51 */     mpf.applyTranspose(y, z);
/*  52 */     float d2 = dot(z, x);
/*  53 */     assertEquals(d1, d2, tiny);
/*  54 */     mpf.applyInverse(x, z);
/*  55 */     d1 = dot(z, y);
/*  56 */     mpf.applyInverseTranspose(y, z);
/*  57 */     d2 = dot(z, x);
/*  58 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   public void test2Random() {
/*  62 */     int[] lag1 = { 0, 1, 2, 3, 4, -4, -3, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */     
/*  66 */     int[] lag2 = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/*  70 */     float[] a = { 1.7954845F, -0.64490664F, -0.03850411F, -0.01793403F, -0.00708972F, -0.02290331F, -0.04141619F, -0.08457147F, -0.20031442F, -0.5565992F };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2, a);
/*  76 */     int n1 = 19;
/*  77 */     int n2 = 21;
/*     */ 
/*     */     
/*  80 */     float[][] x = randfloat(n1, n2);
/*  81 */     float[][] y = zerofloat(n1, n2);
/*  82 */     float[][] z = zerofloat(n1, n2);
/*  83 */     mpf.apply(x, y);
/*  84 */     mpf.applyInverse(y, z);
/*  85 */     assertEqual(x, z);
/*  86 */     mpf.applyTranspose(x, y);
/*  87 */     mpf.applyInverseTranspose(y, z);
/*  88 */     assertEqual(x, z);
/*     */ 
/*     */     
/*  91 */     float tiny = (n1 * n2) * 10.0F * 1.1920929E-7F;
/*  92 */     x = randfloat(n1, n2);
/*  93 */     y = randfloat(n1, n2);
/*  94 */     z = zerofloat(n1, n2);
/*  95 */     mpf.apply(x, z);
/*  96 */     float d1 = dot(z, y);
/*  97 */     mpf.applyTranspose(y, z);
/*  98 */     float d2 = dot(z, x);
/*  99 */     assertEquals(d1, d2, tiny);
/* 100 */     mpf.applyInverse(x, z);
/* 101 */     d1 = dot(z, y);
/* 102 */     mpf.applyInverseTranspose(y, z);
/* 103 */     d2 = dot(z, x);
/* 104 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   public void test3Random() {
/* 108 */     int[] lag1 = { 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     int[] lag2 = { 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     float[] a = { 2.3110454F, -0.4805547F, -0.0143204F, -0.0291793F, -0.1057476F, -0.4572746F, -0.0115732F, -0.0047283F, -0.0149963F, -0.0408317F, -0.0945958F, -0.0223166F, -0.0062781F, -0.0213786F, -0.0898909F, -0.4322719F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2, lag3, a);
/* 133 */     int n1 = 11;
/* 134 */     int n2 = 13;
/* 135 */     int n3 = 12;
/*     */ 
/*     */     
/* 138 */     float[][][] x = randfloat(n1, n2, n3);
/* 139 */     float[][][] y = zerofloat(n1, n2, n3);
/* 140 */     float[][][] z = zerofloat(n1, n2, n3);
/* 141 */     mpf.apply(x, y);
/* 142 */     mpf.applyInverse(y, z);
/* 143 */     assertEqual(x, z);
/* 144 */     mpf.applyTranspose(x, y);
/* 145 */     mpf.applyInverseTranspose(y, z);
/* 146 */     assertEqual(x, z);
/*     */ 
/*     */     
/* 149 */     float tiny = (n1 * n2 * n3) * 10.0F * 1.1920929E-7F;
/* 150 */     x = randfloat(n1, n2, n3);
/* 151 */     y = randfloat(n1, n2, n3);
/* 152 */     z = zerofloat(n1, n2, n3);
/* 153 */     mpf.apply(x, z);
/* 154 */     float d1 = dot(z, y);
/* 155 */     mpf.applyTranspose(y, z);
/* 156 */     float d2 = dot(z, x);
/* 157 */     assertEquals(d1, d2, tiny);
/* 158 */     mpf.applyInverse(x, z);
/* 159 */     d1 = dot(z, y);
/* 160 */     mpf.applyInverseTranspose(y, z);
/* 161 */     d2 = dot(z, x);
/* 162 */     assertEquals(d1, d2, tiny);
/*     */   }
/*     */   
/*     */   public void testFactorFomelExample() {
/* 166 */     float[] r = { 24.0F, 242.0F, 867.0F, 1334.0F, 867.0F, 242.0F, 24.0F };
/* 167 */     int n = r.length;
/* 168 */     int[] lag1 = { 0, 1, 2, 3 };
/* 169 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1);
/* 170 */     mpf.factorWilsonBurg(10, 0.0F, r);
/* 171 */     int nlag = lag1.length;
/* 172 */     float[] x = new float[nlag];
/* 173 */     float[] a = new float[nlag];
/* 174 */     x[0] = 1.0F;
/* 175 */     mpf.apply(x, a);
/* 176 */     assertEquals(24.0F, a[0], 1.1920929E-6F);
/* 177 */     assertEquals(26.0F, a[1], 1.1920929E-6F);
/* 178 */     assertEquals(9.0F, a[2], 1.1920929E-6F);
/* 179 */     assertEquals(1.0F, a[3], 1.1920929E-6F);
/*     */   }
/*     */   
/*     */   public void testFactorLaplacian2() {
/* 183 */     float[][] r = { { 0.0F, -0.999F, 0.0F }, { -0.999F, 4.0F, -0.999F }, { 0.0F, -0.999F, 0.0F } };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     int[] lag1 = { 0, 1, 2, 3, 4, -4, -3, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */     
/* 192 */     int[] lag2 = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/* 196 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2);
/* 197 */     mpf.factorWilsonBurg(100, 1.1920929E-7F, r);
/* 198 */     float[][] s = new float[3][3];
/* 199 */     float[][] t = new float[3][3];
/* 200 */     s[1][1] = 1.0F;
/* 201 */     mpf.apply(s, t);
/* 202 */     mpf.applyTranspose(t, s);
/* 203 */     float emax = 0.01F * r[1][1];
/* 204 */     for (int i2 = 0; i2 < 3; i2++) {
/* 205 */       for (int i1 = 0; i1 < 3; i1++) {
/* 206 */         assertEquals(r[i2][i1], s[i2][i1], emax);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testFactorLaplacian3() {
/* 215 */     float[][][] r = { { { 0.0F, 0.0F, 0.0F }, { 0.0F, -0.999F, 0.0F }, { 0.0F, 0.0F, 0.0F } }, { { 0.0F, -0.999F, 0.0F }, { -0.999F, 6.0F, -0.999F }, { 0.0F, -0.999F, 0.0F } }, { { 0.0F, 0.0F, 0.0F }, { 0.0F, -0.999F, 0.0F }, { 0.0F, 0.0F, 0.0F } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     int[] lag1 = { 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     int[] lag2 = { 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2, lag3);
/* 249 */     mpf.factorWilsonBurg(100, 1.1920929E-7F, r);
/* 250 */     float[][][] s = new float[3][3][3];
/* 251 */     float[][][] t = new float[3][3][3];
/* 252 */     s[1][1][1] = 1.0F;
/* 253 */     mpf.apply(s, t);
/* 254 */     mpf.applyTranspose(t, s);
/* 255 */     float emax = 0.01F * r[1][1][1];
/* 256 */     for (int i3 = 0; i3 < 3; i3++) {
/* 257 */       for (int i2 = 0; i2 < 3; i2++) {
/* 258 */         for (int i1 = 0; i1 < 3; i1++) {
/* 259 */           assertEquals(r[i3][i2][i1], s[i3][i2][i1], emax);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xtestFactorPlane2Filter() {
/* 269 */     int[] lag1 = { 0, 1, 2, 3, -3, -2, -1, 0, 1 };
/*     */ 
/*     */ 
/*     */     
/* 273 */     int[] lag2 = { 0, 0, 0, 0, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */     
/* 277 */     float[][] s = new float[3][7];
/* 278 */     float[][] t = new float[3][7];
/* 279 */     int maxiter = 100;
/* 280 */     float epsilon = 1.1920929E-7F;
/* 281 */     int ntheta = 33;
/* 282 */     float dtheta = 3.1415927F / (ntheta - 1);
/* 283 */     float ftheta = -1.5707964F;
/* 284 */     ntheta = 2;
/* 285 */     dtheta = 0.7853982F;
/* 286 */     ftheta = -0.3926991F;
/* 287 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2);
/* 288 */     for (int itheta = 0; itheta < ntheta; itheta++) {
/* 289 */       float theta = ftheta + itheta * dtheta;
/* 290 */       float n1 = MathPlus.cos(theta);
/* 291 */       float n2 = MathPlus.sin(theta);
/* 292 */       System.out.println("theta=" + theta + " n1=" + n1 + " n2=" + n2);
/* 293 */       float m12 = 0.5F * (n1 - n2);
/* 294 */       float p12 = 0.5F * (n1 + n2);
/* 295 */       float[][] r = { { -m12 * m12, -2.0F * m12 * p12, -p12 * p12 }, { 2.0F * m12 * p12, 1.01F, 2.0F * m12 * p12 }, { -p12 * p12, -2.0F * m12 * p12, -m12 * m12 } };
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       mpf.factorWilsonBurg(maxiter, epsilon, r);
/* 301 */       Array.dump(r);
/* 302 */       Array.zero(s);
/* 303 */       int k1 = ((s[0]).length - 1) / 2;
/* 304 */       int k2 = (s.length - 1) / 2;
/* 305 */       s[k2][k1] = 1.0F;
/* 306 */       mpf.apply(s, t);
/* 307 */       mpf.applyTranspose(t, s);
/* 308 */       Array.dump(s);
/* 309 */       Array.dump(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xtestFactorPlane3Filter() {
/* 343 */     int[] lag1 = { 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, 3 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     int[] lag2 = { 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, -3, -3, -3, -3, -3, -3, -3, -2, -2, -2, -2, -2, -2, -2, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     int[] lag3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 385 */     float[][][] s = new float[3][7][7];
/* 386 */     float[][][] t = new float[3][7][7];
/* 387 */     int m = lag1.length;
/* 388 */     float[] amax = new float[m];
/* 389 */     int maxiter = 100;
/* 390 */     float epsilon = 1.1920929E-7F;
/* 391 */     int nphi = 19;
/* 392 */     float dphi = 6.2831855F / (nphi - 1);
/* 393 */     float fphi = -3.1415927F;
/* 394 */     int ntheta = 5;
/* 395 */     float dtheta = 1.5707964F / (ntheta - 1);
/* 396 */     float ftheta = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 403 */     MinimumPhaseFilter mpf = new MinimumPhaseFilter(lag1, lag2, lag3);
/* 404 */     for (int iphi = 0; iphi < nphi; iphi++) {
/* 405 */       float phi = fphi + iphi * dphi;
/* 406 */       for (int itheta = 0; itheta < ntheta; itheta++) {
/* 407 */         float theta = ftheta + itheta * dtheta;
/* 408 */         float n1 = MathPlus.cos(theta);
/* 409 */         float n2 = MathPlus.sin(theta) * MathPlus.cos(phi);
/* 410 */         float n3 = MathPlus.sin(theta) * MathPlus.sin(phi);
/* 411 */         System.out.println("\nphi=" + phi + " theta=" + theta + " n1=" + n1 + " n2=" + n2 + " n3=" + n3);
/*     */         
/* 413 */         float m12 = 0.5F * (n1 - n2);
/* 414 */         float m13 = 0.5F * (n1 - n3);
/* 415 */         float m23 = 0.5F * (n2 - n3);
/* 416 */         float p12 = 0.5F * (n1 + n2);
/* 417 */         float p13 = 0.5F * (n1 + n3);
/* 418 */         float p23 = 0.5F * (n2 + n3);
/* 419 */         float[][][] r = { { { 0.0F, -m23 * m23, 0.0F }, { -m13 * m13, -2.0F * (m13 * p13 + m23 * p23), -p13 * p13 }, { 0.0F, -p23 * p23, 0.0F } }, { { -m12 * m12, 2.0F * (-m12 * p12 + m23 * p23), -p12 * p12 }, { 2.0F * (m12 * p12 + m13 * p13), 2.02F, 2.0F * (m12 * p12 + m13 * p13) }, { -p12 * p12, 2.0F * (-m12 * p12 + m23 * p23), -m12 * m12 } }, { { 0.0F, -p23 * p23, 0.0F }, { -p13 * p13, -2.0F * (m13 * p13 + m23 * p23), -m13 * m13 }, { 0.0F, -m23 * m23, 0.0F } } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 432 */         mpf.factorWilsonBurg(maxiter, epsilon, r);
/* 433 */         float[] a = mpf.getA();
/* 434 */         for (int i = 0; i < m; i++) {
/* 435 */           if (MathPlus.abs(a[i]) > amax[i]) {
/* 436 */             amax[i] = MathPlus.abs(a[i]);
/*     */           }
/*     */         } 
/* 439 */         Array.zero(s);
/* 440 */         int k1 = ((s[0][0]).length - 1) / 2;
/* 441 */         int k2 = ((s[0]).length - 1) / 2;
/* 442 */         int k3 = (s.length - 1) / 2;
/* 443 */         s[k3][k2][k1] = 1.0F;
/* 444 */         mpf.apply(s, t);
/* 445 */         mpf.applyTranspose(t, s);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 450 */     for (int j = 0; j < m; j++) {
/* 451 */       System.out.println("lag1=" + lag1[j] + " lag2=" + lag2[j] + " lag3=" + lag3[j] + " amax=" + amax[j]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] randfloat(int n1) {
/* 461 */     return Array.sub(Array.randfloat(n1), 0.5F);
/*     */   }
/*     */   private static float[][] randfloat(int n1, int n2) {
/* 464 */     return Array.sub(Array.randfloat(n1, n2), 0.5F);
/*     */   }
/*     */   private static float[][][] randfloat(int n1, int n2, int n3) {
/* 467 */     return Array.sub(Array.randfloat(n1, n2, n3), 0.5F);
/*     */   }
/*     */   
/*     */   private static float[] zerofloat(int n1) {
/* 471 */     return Array.zerofloat(n1);
/*     */   }
/*     */   private static float[][] zerofloat(int n1, int n2) {
/* 474 */     return Array.zerofloat(n1, n2);
/*     */   }
/*     */   private static float[][][] zerofloat(int n1, int n2, int n3) {
/* 477 */     return Array.zerofloat(n1, n2, n3);
/*     */   }
/*     */   
/*     */   private static float dot(float[] x, float[] y) {
/* 481 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][] x, float[][] y) {
/* 484 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   private static float dot(float[][][] x, float[][][] y) {
/* 487 */     return Array.sum(Array.mul(x, y));
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[] re, float[] ra) {
/* 491 */     int n = re.length;
/* 492 */     float tolerance = n * 1.1920929E-7F;
/* 493 */     for (int i = 0; i < n; i++)
/* 494 */       assertEquals(re[i], ra[i], tolerance); 
/*     */   }
/*     */   
/*     */   private static void assertEqual(float[][] re, float[][] ra) {
/* 498 */     int n2 = re.length;
/* 499 */     int n1 = (re[0]).length;
/* 500 */     float tolerance = (n1 * n2) * 1.1920929E-7F;
/* 501 */     for (int i2 = 0; i2 < n2; i2++) {
/* 502 */       for (int i1 = 0; i1 < n1; i1++)
/* 503 */         assertEquals(re[i2][i1], ra[i2][i1], tolerance); 
/*     */     } 
/*     */   }
/*     */   private static void assertEqual(float[][][] re, float[][][] ra) {
/* 507 */     int n3 = re.length;
/* 508 */     int n2 = (re[0]).length;
/* 509 */     int n1 = (re[0][0]).length;
/* 510 */     float tolerance = (n1 * n2 * n3) * 1.1920929E-7F;
/* 511 */     for (int i3 = 0; i3 < n3; i3++) {
/* 512 */       for (int i2 = 0; i2 < n2; i2++) {
/* 513 */         for (int i1 = 0; i1 < n1; i1++)
/* 514 */           assertEquals(re[i3][i2][i1], ra[i3][i2][i1], tolerance); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/dsp/test/MinimumPhaseFilterTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */