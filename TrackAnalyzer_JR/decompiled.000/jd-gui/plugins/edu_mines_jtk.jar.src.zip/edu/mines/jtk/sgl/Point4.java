/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point4
/*     */   extends Tuple4
/*     */ {
/*     */   public Point4() {
/*  20 */     super(0.0D, 0.0D, 0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4(double x, double y, double z) {
/*  30 */     super(x, y, z, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4(double x, double y, double z, double w) {
/*  41 */     super(x, y, z, w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4(Point3 p) {
/*  50 */     super(p.x, p.y, p.z, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4(Point4 p) {
/*  58 */     super(p.x, p.y, p.z, p.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 homogenize() {
/*  67 */     return new Point4(this.x / this.w, this.y / this.w, this.z / this.w, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 homogenizeEquals() {
/*  76 */     this.x /= this.w;
/*  77 */     this.y /= this.w;
/*  78 */     this.z /= this.w;
/*  79 */     this.w = 1.0D;
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 plus(Vector3 v) {
/*  89 */     return new Point4(this.x + v.x, this.y + v.y, this.z + v.z, this.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 minus(Vector3 v) {
/*  98 */     return new Point4(this.x - v.x, this.y - v.y, this.z - v.z, this.w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 plusEquals(Vector3 v) {
/* 107 */     this.x += v.x;
/* 108 */     this.y += v.y;
/* 109 */     this.z += v.z;
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 minusEquals(Vector3 v) {
/* 119 */     this.x -= v.x;
/* 120 */     this.y -= v.y;
/* 121 */     this.z -= v.z;
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point4 affine(double a, Point4 q) {
/* 132 */     double b = 1.0D - a;
/* 133 */     Point4 p = this;
/* 134 */     return new Point4(b * p.x + a * q.x, b * p.y + a * q.y, b * p.z + a * q.z, b * p.w + a * q.w);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Point4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */