/*    */ package edu.mines.jtk.opt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LinearTransformWrapper
/*    */   implements Transform
/*    */ {
/* 14 */   private LinearTransform _linearTransform = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LinearTransformWrapper(LinearTransform linearTransform) {
/* 20 */     this._linearTransform = linearTransform;
/*    */   }
/*    */ 
/*    */   
/*    */   public void forwardNonlinear(Vect data, VectConst model) {
/* 25 */     this._linearTransform.forward(data, model);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void forwardLinearized(Vect data, VectConst model, VectConst modelReference) {
/* 32 */     this._linearTransform.forward(data, model);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addTranspose(VectConst data, Vect model, VectConst modelReference) {
/* 39 */     this._linearTransform.addTranspose(data, model);
/*    */   }
/*    */ 
/*    */   
/*    */   public void inverseHessian(Vect model, VectConst modelReference) {
/* 44 */     this._linearTransform.inverseHessian(model);
/*    */   }
/*    */ 
/*    */   
/*    */   public void adjustRobustErrors(Vect dataError) {
/* 49 */     this._linearTransform.adjustRobustErrors(dataError);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/LinearTransformWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */