/*    */ package edu.mines.jtk.ogl.test;
/*    */ 
/*    */ import edu.mines.jtk.ogl.Gl;
/*    */ import edu.mines.jtk.ogl.GlCanvas;
/*    */ import edu.mines.jtk.ogl.GlTextureName;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlTextureNameTest
/*    */ {
/* 34 */   private static GlCanvas canvas = new GlCanvas()
/*    */     {
/*    */       private static final int SIZE = 256;
/* 37 */       private ByteBuffer _checkImage = null;
/*    */       private GlTextureName _textureName;
/*    */       
/*    */       private void makeCheckImage() {
/* 41 */         int n = 256;
/* 42 */         this._checkImage = ByteBuffer.allocateDirect(n * n * 4);
/* 43 */         for (int i = 0, k = 0; i < n; i++) {
/* 44 */           for (int j = 0; j < n; j++) {
/* 45 */             int c = ((((((i & 0x10) == 0) ? 1 : 0) ^ (((j & 0x10) == 0) ? 1 : 0)) != 0) ? 1 : 0) * 255;
/* 46 */             byte b = (byte)c;
/* 47 */             this._checkImage.put(k++, b);
/* 48 */             this._checkImage.put(k++, b);
/* 49 */             this._checkImage.put(k++, b);
/* 50 */             this._checkImage.put(k++, (byte)-1);
/*    */           } 
/*    */         } 
/*    */       }
/*    */       private void makeTexture() {
/* 55 */         this._textureName = new GlTextureName();
/* 56 */         Gl.glBindTexture(3553, this._textureName.name());
/* 57 */         Gl.glTexParameteri(3553, 10242, 10497);
/* 58 */         Gl.glTexParameteri(3553, 10243, 10497);
/* 59 */         Gl.glTexParameteri(3553, 10240, 9728);
/* 60 */         Gl.glTexParameteri(3553, 10241, 9728);
/* 61 */         Gl.glTexImage2D(3553, 0, 6408, 256, 256, 0, 6408, 5121, this._checkImage);
/*    */       }
/*    */       
/*    */       public void glInit() {
/* 65 */         Gl.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/* 66 */         Gl.glPixelStorei(3317, 1);
/* 67 */         makeCheckImage();
/* 68 */         makeTexture();
/*    */       }
/*    */       public void glResize(int x, int y, int width, int height) {
/* 71 */         Gl.glViewport(0, 0, width, height);
/* 72 */         Gl.glMatrixMode(5889);
/* 73 */         Gl.glLoadIdentity();
/* 74 */         Gl.glOrtho(0.0D, 1.0D, 0.0D, 1.0D, -1.0D, 1.0D);
/* 75 */         Gl.glMatrixMode(5888);
/*    */       }
/*    */       public void glPaint() {
/* 78 */         Gl.glClear(16640);
/* 79 */         Gl.glEnable(3553);
/* 80 */         Gl.glTexEnvf(8960, 8704, 7681.0F);
/* 81 */         Gl.glBindTexture(3553, this._textureName.name());
/* 82 */         Gl.glBegin(9);
/* 83 */         Gl.glTexCoord2f(0.0F, 0.0F); Gl.glVertex3f(0.25F, 0.25F, 0.0F);
/* 84 */         Gl.glTexCoord2f(1.0F, 0.0F); Gl.glVertex3f(0.75F, 0.25F, 0.0F);
/* 85 */         Gl.glTexCoord2f(1.0F, 1.0F); Gl.glVertex3f(0.75F, 0.75F, 0.0F);
/* 86 */         Gl.glTexCoord2f(0.0F, 1.0F); Gl.glVertex3f(0.25F, 0.75F, 0.0F);
/* 87 */         Gl.glEnd();
/* 88 */         Gl.glFlush();
/* 89 */         Gl.glDisable(3553);
/* 90 */         makeTexture();
/*    */       }
/*    */     };
/*    */   public static void main(String[] args) {
/* 94 */     TestSimple.run(args, canvas, true);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/ogl/test/GlTextureNameTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */