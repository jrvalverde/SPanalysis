/*     */ package edu.mines.jtk.opt.test;
/*     */ 
/*     */ import edu.mines.jtk.opt.ScalarSolver;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScalarSolverTest
/*     */   extends TestCase
/*     */ {
/*     */   public void testLinearObjFunc() throws Exception {
/*  25 */     double answer = 0.3333333333333333D;
/*  26 */     final int[] calls = { 0 };
/*  27 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/*  29 */             calls[0] = calls[0] + 1;
/*  30 */             return Math.abs(scalar - 0.3333333333333333D);
/*     */           }
/*     */         });
/*     */     
/*  34 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 20, null);
/*  35 */     assert xmin > 0.3323333333333333D : "xmin > answer - 0.001";
/*  36 */     assert xmin > 0.33299999999999996D : "xmin > answer*(1. - 0.001)";
/*  37 */     assert xmin < 0.3343333333333333D : "xmin < answer - 0.001";
/*  38 */     assert xmin < 0.3336666666666666D : "xmin < answer*(1. + 0.001)";
/*     */     
/*  40 */     assert calls[0] == 14 : "calls[0] == 14 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testNonUnitScalarRange() throws Exception {
/*  48 */     double answer = 0.3333333333333333D;
/*  49 */     final int[] calls = { 0 };
/*  50 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/*  52 */             calls[0] = calls[0] + 1;
/*  53 */             return Math.abs(scalar - 0.3333333333333333D);
/*     */           }
/*     */         });
/*  56 */     double xmin = solver.solve(-1.0D, 2.0D, 0.001D, 0.001D, 20, null);
/*  57 */     assert xmin > 0.3323333333333333D : "xmin > answer - 0.001";
/*  58 */     assert xmin > 0.33299999999999996D : "xmin > answer*(1. - 0.001)";
/*  59 */     assert xmin < 0.3343333333333333D : "xmin < answer - 0.001";
/*  60 */     assert xmin < 0.3336666666666666D : "xmin < answer*(1. + 0.001)";
/*     */     
/*  62 */     assert calls[0] == 15 : "calls[0] == 15 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testRightHandSide() throws Exception {
/*  70 */     double answer = 0.03D;
/*  71 */     final int[] calls = { 0 };
/*  72 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/*  74 */             calls[0] = calls[0] + 1;
/*  75 */             return Math.abs(scalar - 0.03D);
/*     */           }
/*     */         });
/*  78 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 20, null);
/*  79 */     assert xmin > 0.028999999999999998D : "xmin > answer - 0.001";
/*  80 */     assert xmin > 0.02997D : "xmin > answer*(1. - 0.001)";
/*  81 */     assert xmin < 0.031D : "xmin < answer - 0.001";
/*  82 */     assert xmin < 0.030029999999999994D : "xmin < answer*(1. + 0.001)";
/*     */     
/*  84 */     assert calls[0] == 16 : "calls[0] == 16 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testLeftHandSide2() throws Exception {
/*  91 */     double answer = 0.98D;
/*  92 */     final int[] calls = { 0 };
/*  93 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/*  95 */             calls[0] = calls[0] + 1;
/*  96 */             return Math.abs(scalar - 0.98D);
/*     */           }
/*     */         });
/*  99 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 20, null);
/* 100 */     assert xmin > 0.979D : "xmin > answer - 0.001";
/* 101 */     assert xmin > 0.97902D : "xmin > answer*(1. - 0.001)";
/* 102 */     assert xmin < 0.981D : "xmin < answer - 0.001";
/* 103 */     assert xmin < 0.9809799999999999D : "xmin < answer*(1. + 0.001)";
/*     */     
/* 105 */     assert calls[0] == 12 : "calls[0] == 12 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testParabola() throws Exception {
/* 112 */     double answer = 0.3333333333333333D;
/* 113 */     final int[] calls = { 0 };
/* 114 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/* 116 */             calls[0] = calls[0] + 1;
/* 117 */             return (scalar - 0.3333333333333333D) * (scalar - 0.3333333333333333D);
/*     */           }
/*     */         });
/* 120 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 7, null);
/* 121 */     assert xmin > 0.3323333333333333D : "xmin > answer - 0.001";
/* 122 */     assert xmin > 0.33299999999999996D : "xmin > answer*(1. - 0.001)";
/* 123 */     assert xmin < 0.3343333333333333D : "xmin < answer - 0.001";
/* 124 */     assert xmin < 0.3336666666666666D : "xmin < answer*(1. + 0.001)";
/*     */     
/* 126 */     assert calls[0] == 6 : "Number == 6 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testPositiveCurvature() throws Exception {
/* 133 */     double answer = 0.3333333333333333D;
/* 134 */     final int[] calls = { 0 };
/* 135 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/* 137 */             calls[0] = calls[0] + 1;
/* 138 */             return Math.sqrt(Math.abs(scalar - 0.3333333333333333D));
/*     */           }
/*     */         });
/* 141 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 20, null);
/* 142 */     assert xmin > 0.3323333333333333D : "xmin > answer - 0.001";
/* 143 */     assert xmin > 0.33299999999999996D : "xmin > answer*(1. - 0.001)";
/* 144 */     assert xmin < 0.3343333333333333D : "xmin < answer - 0.001";
/* 145 */     assert xmin < 0.3336666666666666D : "xmin < answer*(1. + 0.001)";
/*     */     
/* 147 */     assert calls[0] == 16 : "Number == 16 != " + calls[false];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testStepFunction() throws Exception {
/* 154 */     double answer = 0.3333333333333333D;
/* 155 */     final int[] calls = { 0 };
/* 156 */     ScalarSolver solver = new ScalarSolver(new ScalarSolver.Function() {
/*     */           public double function(double scalar) {
/* 158 */             calls[0] = calls[0] + 1;
/* 159 */             if (scalar < 0.3333333333333333D) return 3.0D; 
/* 160 */             return scalar - 0.3333333333333333D;
/*     */           }
/*     */         });
/* 163 */     double xmin = solver.solve(0.0D, 1.0D, 0.001D, 0.001D, 50, null);
/* 164 */     assert xmin > 0.3323333333333333D : "xmin > answer - 0.001";
/* 165 */     assert xmin > 0.33299999999999996D : "xmin > answer*(1. - 0.001)";
/* 166 */     assert xmin < 0.3343333333333333D : "xmin < answer - 0.001";
/* 167 */     assert xmin < 0.3336666666666666D : "xmin < answer*(1. + 0.001)";
/*     */     
/* 169 */     assert calls[0] == 29 : "Number == 29 != " + calls[false];
/*     */   }
/*     */   
/*     */   protected void setUp() throws Exception {
/* 173 */     super.setUp();
/*     */   }
/*     */   protected void tearDown() throws Exception {
/* 176 */     super.tearDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScalarSolverTest(String name) {
/* 183 */     super(name);
/*     */   }
/*     */   
/*     */   public static Test suite() {
/*     */     try {
/*     */       assert false;
/* 189 */       throw new IllegalStateException("need -ea");
/* 190 */     } catch (AssertionError e) {
/* 191 */       return (Test)new TestSuite(ScalarSolverTest.class);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 198 */     TestRunner.run(suite());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ScalarSolverTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */