/*     */ package edu.mines.jtk.mosaic;
/*     */ 
/*     */ import edu.mines.jtk.dsp.Sampling;
/*     */ import edu.mines.jtk.util.Array;
/*     */ import edu.mines.jtk.util.Check;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequenceView
/*     */   extends TiledView
/*     */ {
/*     */   Sampling _sx;
/*     */   float[] _f;
/*     */   private Color _color;
/*     */   private Zero _zero;
/*     */   
/*     */   public enum Zero
/*     */   {
/*  50 */     NORMAL, ALWAYS, MIDDLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequenceView(float[] f)
/*     */   {
/* 194 */     this._color = null;
/* 195 */     this._zero = Zero.ALWAYS; set(f); } public SequenceView(Sampling sx, float[] f) { this._color = null; this._zero = Zero.ALWAYS; set(sx, f); }
/*     */   public void set(float[] f) { set(new Sampling(f.length), f); }
/*     */   public void set(Sampling sx, float[] f) { Check.argument((sx.getCount() == f.length), "sx count equals length of f"); this._sx = sx;
/*     */     this._f = Array.copy(f);
/*     */     updateBestProjectors();
/*     */     repaint(); }
/* 201 */   public Sampling getSampling() { return this._sx; } private void updateBestProjectors() { double nx = this._sx.getCount();
/* 202 */     double xf = this._sx.getFirst();
/* 203 */     double xl = this._sx.getLast();
/* 204 */     double xmin = Math.min(xf, xl);
/* 205 */     double xmax = Math.max(xf, xl);
/* 206 */     if (xmin == xmax) {
/* 207 */       double tiny = Math.max(1.0D, Math.ulp(1.0F) * Math.abs(xmin));
/* 208 */       xmin -= tiny;
/* 209 */       xmax += tiny;
/*     */     } 
/*     */ 
/*     */     
/* 213 */     double fmin = this._f[0];
/* 214 */     double fmax = this._f[0];
/* 215 */     for (int ix = 0; ix < nx; ix++) {
/* 216 */       if (this._f[ix] < fmin)
/* 217 */         fmin = this._f[ix]; 
/* 218 */       if (this._f[ix] > fmax) {
/* 219 */         fmax = this._f[ix];
/*     */       }
/*     */     } 
/*     */     
/* 223 */     if (this._zero == Zero.ALWAYS) {
/* 224 */       fmin = Math.min(0.0D, fmin);
/* 225 */       fmax = Math.max(0.0D, fmax);
/* 226 */     } else if (this._zero == Zero.MIDDLE) {
/* 227 */       fmax = Math.max(Math.abs(fmin), Math.abs(fmax));
/* 228 */       fmin = -fmax;
/*     */     } 
/* 230 */     if (fmin == fmax) {
/* 231 */       double tiny = Math.max(1.0D, Math.ulp(1.0F) * Math.abs(fmin));
/* 232 */       fmin -= tiny;
/* 233 */       fmax += tiny;
/*     */     } 
/*     */ 
/*     */     
/* 237 */     double rbx = ballRadiusX();
/* 238 */     double rby = ballRadiusY();
/* 239 */     Projector bhp = new Projector(xmin, xmax, rbx, 1.0D - rbx);
/* 240 */     Projector bvp = new Projector(fmax, fmin, rby, 1.0D - rby);
/* 241 */     setBestProjectors(bhp, bvp); }
/*     */   public float[] getFunction() { return Array.copy(this._f); }
/*     */   public void setZero(Zero zero) { if (this._zero != zero) { this._zero = zero; updateBestProjectors(); repaint(); }  }
/*     */   public void setColor(Color color) { if (!equalColors(this._color, color)) { this._color = color; repaint(); }  }
/* 245 */   public void paint(Graphics2D g2d) { g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); int nx = this._sx.getCount(); double dx = this._sx.getDelta(); double fx = this._sx.getFirst(); double lx = this._sx.getLast(); Projector bhp = getBestHorizontalProjector(); Projector bvp = getBestVerticalProjector(); Projector hp = getHorizontalProjector(); Projector vp = getVerticalProjector(); Transcaler ts = getTranscaler(); double rbx = ballRadiusX() * hp.getScaleRatio(bhp); double rby = ballRadiusY() * vp.getScaleRatio(bvp); int rx = ts.width(rbx); int ry = ts.height(rby); int rb = Math.max(0, Math.min(rx, ry) - 1); if (this._color != null) g2d.setColor(this._color);  int xf = ts.x(hp.u(fx)); int xl = ts.x(hp.u(lx)); int x1 = Math.min(xf, xl) - rb; int x2 = Math.max(xf, xl) + rb; int y0 = ts.y(vp.u(0.0D)); g2d.drawLine(x1, y0, x2, y0); for (int ix = 0; ix < nx; ix++) { double xi = fx + ix * dx; double fi = this._f[ix]; int x = ts.x(hp.u(xi)); int y = ts.y(vp.u(fi)); g2d.drawLine(x, y0, x, y); g2d.fillOval(x - rb, y - rb, 1 + 2 * rb, 1 + 2 * rb); }  } private double ballRadiusX() { double nx = this._sx.getCount();
/* 246 */     return 0.9D / 2.0D * nx; }
/*     */ 
/*     */   
/*     */   private double ballRadiusY() {
/* 250 */     return 0.04D;
/*     */   }
/*     */   
/*     */   private boolean equalColors(Color ca, Color cb) {
/* 254 */     return (ca == null) ? ((cb == null)) : ca.equals(cb);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/mosaic/SequenceView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */