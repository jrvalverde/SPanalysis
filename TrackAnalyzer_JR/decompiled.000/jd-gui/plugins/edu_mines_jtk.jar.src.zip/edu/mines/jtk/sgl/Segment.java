/*     */ package edu.mines.jtk.sgl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Segment
/*     */ {
/*     */   private static final double TINY = 2.220446049250313E-13D;
/*     */   private Point3 _a;
/*     */   private Point3 _b;
/*     */   private Vector3 _d;
/*     */   
/*     */   public Segment(Point3 a, Point3 b) {
/*  24 */     this._a = new Point3(a);
/*  25 */     this._b = new Point3(b);
/*  26 */     this._d = this._b.minus(this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Segment(Segment ls) {
/*  34 */     this(ls._a, ls._b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getA() {
/*  42 */     return new Point3(this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 getB() {
/*  50 */     return new Point3(this._b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double length() {
/*  58 */     return this._a.distanceTo(this._b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(Matrix44 m) {
/*  66 */     this._a = m.times(this._a);
/*  67 */     this._b = m.times(this._b);
/*  68 */     this._d = this._b.minus(this._a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3 intersectWithTriangle(double xa, double ya, double za, double xb, double yb, double zb, double xc, double yc, double zc) {
/*  90 */     double xd = this._d.x;
/*  91 */     double yd = this._d.y;
/*  92 */     double zd = this._d.z;
/*  93 */     double xba = xb - xa;
/*  94 */     double yba = yb - ya;
/*  95 */     double zba = zb - za;
/*  96 */     double xca = xc - xa;
/*  97 */     double yca = yc - ya;
/*  98 */     double zca = zc - za;
/*  99 */     double xp = yd * zca - zd * yca;
/* 100 */     double yp = zd * xca - xd * zca;
/* 101 */     double zp = xd * yca - yd * xca;
/* 102 */     double a = xba * xp + yba * yp + zba * zp;
/* 103 */     if (-2.220446049250313E-13D < a && a < 2.220446049250313E-13D)
/* 104 */       return null; 
/* 105 */     double f = 1.0D / a;
/* 106 */     double xaa = this._a.x - xa;
/* 107 */     double yaa = this._a.y - ya;
/* 108 */     double zaa = this._a.z - za;
/* 109 */     double u = f * (xaa * xp + yaa * yp + zaa * zp);
/* 110 */     if (u < 0.0D || u > 1.0D)
/* 111 */       return null; 
/* 112 */     double xq = yaa * zba - zaa * yba;
/* 113 */     double yq = zaa * xba - xaa * zba;
/* 114 */     double zq = xaa * yba - yaa * xba;
/* 115 */     double v = f * (xd * xq + yd * yq + zd * zq);
/* 116 */     if (v < 0.0D || u + v > 1.0D)
/* 117 */       return null; 
/* 118 */     double t = f * (xca * xq + yca * yq + zca * zq);
/* 119 */     if (t < 0.0D || 1.0D < t)
/* 120 */       return null; 
/* 121 */     double w = 1.0D - u - v;
/* 122 */     double xi = w * xa + u * xb + v * xc;
/* 123 */     double yi = w * ya + u * yb + v * yc;
/* 124 */     double zi = w * za + u * zb + v * zc;
/* 125 */     return new Point3(xi, yi, zi);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/sgl/Segment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */