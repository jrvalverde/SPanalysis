/*      */ package edu.mines.jtk.io;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.FileDescriptor;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.DoubleBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.nio.LongBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.nio.channels.FileChannel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DataFile
/*      */   implements DataInput, DataOutput, Closeable
/*      */ {
/*      */   private RandomAccessFile _raf;
/*      */   private FileChannel _fc;
/*      */   private ByteOrder _bo;
/*      */   private ByteBuffer _bb;
/*      */   private CharBuffer _cb;
/*      */   private ShortBuffer _sb;
/*      */   private IntBuffer _ib;
/*      */   private LongBuffer _lb;
/*      */   private FloatBuffer _fb;
/*      */   private DoubleBuffer _db;
/*      */   
/*      */   public enum ByteOrder
/*      */   {
/*   45 */     BIG_ENDIAN,
/*   46 */     LITTLE_ENDIAN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteOrder nativeByteOrder() {
/*   54 */     if (java.nio.ByteOrder.nativeOrder() == java.nio.ByteOrder.BIG_ENDIAN) {
/*   55 */       return ByteOrder.BIG_ENDIAN;
/*      */     }
/*   57 */     return ByteOrder.LITTLE_ENDIAN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataFile(String name, String mode) throws FileNotFoundException {
/*   69 */     this(name, mode, ByteOrder.BIG_ENDIAN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataFile(File file, String mode) throws FileNotFoundException {
/*   80 */     this(file, mode, ByteOrder.BIG_ENDIAN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataFile(String name, String mode, ByteOrder order) throws FileNotFoundException {
/*   92 */     this((name != null) ? new File(name) : null, mode, order);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataFile(File file, String mode, ByteOrder order) throws FileNotFoundException {
/*  104 */     this._raf = new RandomAccessFile(file, mode);
/*  105 */     this._fc = this._raf.getChannel();
/*  106 */     this._bo = order;
/*  107 */     this._bb = ByteBuffer.allocateDirect(4096);
/*  108 */     if (order == ByteOrder.BIG_ENDIAN) {
/*  109 */       this._bb.order(java.nio.ByteOrder.BIG_ENDIAN);
/*      */     } else {
/*  111 */       this._bb.order(java.nio.ByteOrder.LITTLE_ENDIAN);
/*      */     } 
/*  113 */     this._cb = this._bb.asCharBuffer();
/*  114 */     this._sb = this._bb.asShortBuffer();
/*  115 */     this._ib = this._bb.asIntBuffer();
/*  116 */     this._lb = this._bb.asLongBuffer();
/*  117 */     this._fb = this._bb.asFloatBuffer();
/*  118 */     this._db = this._bb.asDoubleBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FileDescriptor getFD() throws IOException {
/*  126 */     return this._raf.getFD();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FileChannel getChannel() {
/*  134 */     return this._raf.getChannel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteOrder getByteOrder() {
/*  142 */     return this._bo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int read() throws IOException {
/*  151 */     return this._raf.read();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int read(byte[] b) throws IOException {
/*  160 */     return this._raf.read(b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int read(byte[] b, int off, int len) throws IOException {
/*  171 */     return this._raf.read(b, off, len);
/*      */   }
/*      */   
/*      */   public void readFully(byte[] b) throws IOException {
/*  175 */     this._raf.readFully(b);
/*      */   }
/*      */   
/*      */   public void readFully(byte[] b, int off, int len) throws IOException {
/*  179 */     this._raf.readFully(b, off, len);
/*      */   }
/*      */   
/*      */   public int skipBytes(int n) throws IOException {
/*  183 */     return this._raf.skipBytes(n);
/*      */   }
/*      */   
/*      */   public void write(int b) throws IOException {
/*  187 */     this._raf.write(b);
/*      */   }
/*      */   
/*      */   public void write(byte[] b) throws IOException {
/*  191 */     this._raf.write(b);
/*      */   }
/*      */   
/*      */   public void write(byte[] b, int off, int len) throws IOException {
/*  195 */     this._raf.write(b, off, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getFilePointer() throws IOException {
/*  204 */     return this._raf.getFilePointer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void seek(long off) throws IOException {
/*  218 */     this._raf.seek(off);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long length() throws IOException {
/*  226 */     return this._raf.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLength(long newLength) throws IOException {
/*  241 */     this._raf.setLength(newLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*  248 */     this._raf.close();
/*  249 */     this._raf = null;
/*  250 */     this._fc = null;
/*  251 */     this._bb = null;
/*      */   }
/*      */   
/*      */   public final boolean readBoolean() throws IOException {
/*  255 */     return this._raf.readBoolean();
/*      */   }
/*      */   
/*      */   public final byte readByte() throws IOException {
/*  259 */     return this._raf.readByte();
/*      */   }
/*      */   
/*      */   public final int readUnsignedByte() throws IOException {
/*  263 */     return this._raf.readUnsignedByte();
/*      */   }
/*      */   
/*      */   public final short readShort() throws IOException {
/*  267 */     int b1 = this._raf.read();
/*  268 */     int b2 = this._raf.read();
/*  269 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  270 */       return (short)((b1 << 8) + b2);
/*      */     }
/*  272 */     return (short)((b2 << 8) + b1);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int readUnsignedShort() throws IOException {
/*  277 */     return readShort() & 0xFFFF;
/*      */   }
/*      */   
/*      */   public final char readChar() throws IOException {
/*  281 */     return (char)readShort();
/*      */   }
/*      */   
/*      */   public final int readInt() throws IOException {
/*  285 */     int b1 = this._raf.read();
/*  286 */     int b2 = this._raf.read();
/*  287 */     int b3 = this._raf.read();
/*  288 */     int b4 = this._raf.read();
/*  289 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  290 */       return (b1 << 24) + (b2 << 16) + (b3 << 8) + b4;
/*      */     }
/*  292 */     return (b4 << 24) + (b3 << 16) + (b2 << 8) + b1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long readLong() throws IOException {
/*  297 */     int i1 = readInt();
/*  298 */     int i2 = readInt();
/*  299 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  300 */       return (i1 << 32L) + (i2 & 0xFFFFFFFFL);
/*      */     }
/*  302 */     return (i2 << 32L) + (i1 & 0xFFFFFFFFL);
/*      */   }
/*      */ 
/*      */   
/*      */   public final float readFloat() throws IOException {
/*  307 */     return Float.intBitsToFloat(readInt());
/*      */   }
/*      */   
/*      */   public final double readDouble() throws IOException {
/*  311 */     return Double.longBitsToDouble(readLong());
/*      */   }
/*      */   
/*      */   public final String readLine() throws IOException {
/*  315 */     return this._raf.readLine();
/*      */   }
/*      */   
/*      */   public final String readUTF() throws IOException {
/*  319 */     return this._raf.readUTF();
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean v) throws IOException {
/*  323 */     this._raf.writeBoolean(v);
/*      */   }
/*      */   
/*      */   public void writeByte(int v) throws IOException {
/*  327 */     this._raf.writeByte(v);
/*      */   }
/*      */   
/*      */   public void writeShort(int v) throws IOException {
/*  331 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  332 */       this._raf.write(v >>> 8 & 0xFF);
/*  333 */       this._raf.write(v & 0xFF);
/*      */     } else {
/*  335 */       this._raf.write(v & 0xFF);
/*  336 */       this._raf.write(v >>> 8 & 0xFF);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeChar(int v) throws IOException {
/*  341 */     this._raf.writeShort(v);
/*      */   }
/*      */   
/*      */   public void writeInt(int v) throws IOException {
/*  345 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  346 */       this._raf.write(v >>> 24 & 0xFF);
/*  347 */       this._raf.write(v >>> 16 & 0xFF);
/*  348 */       this._raf.write(v >>> 8 & 0xFF);
/*  349 */       this._raf.write(v & 0xFF);
/*      */     } else {
/*  351 */       this._raf.write(v & 0xFF);
/*  352 */       this._raf.write(v >>> 8 & 0xFF);
/*  353 */       this._raf.write(v >>> 16 & 0xFF);
/*  354 */       this._raf.write(v >>> 24 & 0xFF);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeLong(long v) throws IOException {
/*  359 */     if (this._bo == ByteOrder.BIG_ENDIAN) {
/*  360 */       this._raf.write((int)(v >>> 56L) & 0xFF);
/*  361 */       this._raf.write((int)(v >>> 48L) & 0xFF);
/*  362 */       this._raf.write((int)(v >>> 40L) & 0xFF);
/*  363 */       this._raf.write((int)(v >>> 32L) & 0xFF);
/*  364 */       this._raf.write((int)(v >>> 24L) & 0xFF);
/*  365 */       this._raf.write((int)(v >>> 16L) & 0xFF);
/*  366 */       this._raf.write((int)(v >>> 8L) & 0xFF);
/*  367 */       this._raf.write((int)v & 0xFF);
/*      */     } else {
/*  369 */       this._raf.write((int)v & 0xFF);
/*  370 */       this._raf.write((int)(v >>> 8L) & 0xFF);
/*  371 */       this._raf.write((int)(v >>> 16L) & 0xFF);
/*  372 */       this._raf.write((int)(v >>> 24L) & 0xFF);
/*  373 */       this._raf.write((int)(v >>> 32L) & 0xFF);
/*  374 */       this._raf.write((int)(v >>> 40L) & 0xFF);
/*  375 */       this._raf.write((int)(v >>> 48L) & 0xFF);
/*  376 */       this._raf.write((int)(v >>> 56L) & 0xFF);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void writeFloat(float v) throws IOException {
/*  381 */     writeInt(Float.floatToIntBits(v));
/*      */   }
/*      */   
/*      */   public void writeDouble(double v) throws IOException {
/*  385 */     writeLong(Double.doubleToLongBits(v));
/*      */   }
/*      */   
/*      */   public void writeBytes(String s) throws IOException {
/*  389 */     this._raf.writeBytes(s);
/*      */   }
/*      */   
/*      */   public void writeChars(String s) throws IOException {
/*  393 */     int n = s.length();
/*  394 */     for (int i = 0; i < n; i++) {
/*  395 */       writeChar(s.charAt(i));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeUTF(String s) throws IOException {
/*  400 */     this._raf.writeUTF(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readBytes(byte[] v, int k, int n) throws IOException {
/*  410 */     readFully(v, k, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readBytes(byte[] v) throws IOException {
/*  419 */     readFully(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readBytes(byte[][] v) throws IOException {
/*  428 */     for (int i = 0; i < v.length; i++) {
/*  429 */       readBytes(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readBytes(byte[][][] v) throws IOException {
/*  438 */     for (int i = 0; i < v.length; i++) {
/*  439 */       readBytes(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readChars(char[] v, int k, int n) throws IOException {
/*  449 */     int m = this._cb.capacity(); int j;
/*  450 */     for (j = 0; j < n; j += m) {
/*  451 */       int l = Math.min(n - j, m);
/*  452 */       this._bb.position(0).limit(l * 2);
/*  453 */       this._fc.read(this._bb);
/*  454 */       this._cb.position(0).limit(l);
/*  455 */       this._cb.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readChars(char[] v) throws IOException {
/*  465 */     readChars(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readChars(char[][] v) throws IOException {
/*  474 */     for (int i = 0; i < v.length; i++) {
/*  475 */       readChars(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readChars(char[][][] v) throws IOException {
/*  484 */     for (int i = 0; i < v.length; i++) {
/*  485 */       readChars(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readShorts(short[] v, int k, int n) throws IOException {
/*  495 */     int m = this._sb.capacity(); int j;
/*  496 */     for (j = 0; j < n; j += m) {
/*  497 */       int l = Math.min(n - j, m);
/*  498 */       this._bb.position(0).limit(l * 2);
/*  499 */       this._fc.read(this._bb);
/*  500 */       this._sb.position(0).limit(l);
/*  501 */       this._sb.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readShorts(short[] v) throws IOException {
/*  511 */     readShorts(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readShorts(short[][] v) throws IOException {
/*  520 */     for (int i = 0; i < v.length; i++) {
/*  521 */       readShorts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readShorts(short[][][] v) throws IOException {
/*  530 */     for (int i = 0; i < v.length; i++) {
/*  531 */       readShorts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readInts(int[] v, int k, int n) throws IOException {
/*  541 */     int m = this._ib.capacity(); int j;
/*  542 */     for (j = 0; j < n; j += m) {
/*  543 */       int l = Math.min(n - j, m);
/*  544 */       this._bb.position(0).limit(l * 4);
/*  545 */       this._fc.read(this._bb);
/*  546 */       this._ib.position(0).limit(l);
/*  547 */       this._ib.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readInts(int[] v) throws IOException {
/*  557 */     readInts(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readInts(int[][] v) throws IOException {
/*  566 */     for (int i = 0; i < v.length; i++) {
/*  567 */       readInts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readInts(int[][][] v) throws IOException {
/*  576 */     for (int i = 0; i < v.length; i++) {
/*  577 */       readInts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readLongs(long[] v, int k, int n) throws IOException {
/*  587 */     int m = this._lb.capacity(); int j;
/*  588 */     for (j = 0; j < n; j += m) {
/*  589 */       int l = Math.min(n - j, m);
/*  590 */       this._bb.position(0).limit(l * 8);
/*  591 */       this._fc.read(this._bb);
/*  592 */       this._lb.position(0).limit(l);
/*  593 */       this._lb.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readLongs(long[] v) throws IOException {
/*  603 */     readLongs(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readLongs(long[][] v) throws IOException {
/*  612 */     for (int i = 0; i < v.length; i++) {
/*  613 */       readLongs(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readLongs(long[][][] v) throws IOException {
/*  622 */     for (int i = 0; i < v.length; i++) {
/*  623 */       readLongs(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readFloats(float[] v, int k, int n) throws IOException {
/*  633 */     int m = this._fb.capacity(); int j;
/*  634 */     for (j = 0; j < n; j += m) {
/*  635 */       int l = Math.min(n - j, m);
/*  636 */       this._bb.position(0).limit(l * 4);
/*  637 */       this._fc.read(this._bb);
/*  638 */       this._fb.position(0).limit(l);
/*  639 */       this._fb.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readFloats(float[] v) throws IOException {
/*  649 */     readFloats(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readFloats(float[][] v) throws IOException {
/*  658 */     for (int i = 0; i < v.length; i++) {
/*  659 */       readFloats(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readFloats(float[][][] v) throws IOException {
/*  668 */     for (int i = 0; i < v.length; i++) {
/*  669 */       readFloats(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readDoubles(double[] v, int k, int n) throws IOException {
/*  679 */     int m = this._db.capacity(); int j;
/*  680 */     for (j = 0; j < n; j += m) {
/*  681 */       int l = Math.min(n - j, m);
/*  682 */       this._bb.position(0).limit(l * 8);
/*  683 */       this._fc.read(this._bb);
/*  684 */       this._db.position(0).limit(l);
/*  685 */       this._db.get(v, k + j, l);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readDoubles(double[] v) throws IOException {
/*  695 */     readDoubles(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readDoubles(double[][] v) throws IOException {
/*  704 */     for (int i = 0; i < v.length; i++) {
/*  705 */       readDoubles(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readDoubles(double[][][] v) throws IOException {
/*  714 */     for (int i = 0; i < v.length; i++) {
/*  715 */       readDoubles(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBytes(byte[] v, int k, int n) throws IOException {
/*  725 */     write(v, k, n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBytes(byte[] v) throws IOException {
/*  734 */     write(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBytes(byte[][] v) throws IOException {
/*  742 */     for (int i = 0; i < v.length; i++) {
/*  743 */       writeBytes(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBytes(byte[][][] v) throws IOException {
/*  751 */     for (int i = 0; i < v.length; i++) {
/*  752 */       writeBytes(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeChars(char[] v, int k, int n) throws IOException {
/*  762 */     int m = this._cb.capacity(); int j;
/*  763 */     for (j = 0; j < n; j += m) {
/*  764 */       int l = Math.min(n - j, m);
/*  765 */       this._cb.position(0).limit(l);
/*  766 */       this._cb.put(v, k + j, l);
/*  767 */       this._bb.position(0).limit(l * 2);
/*  768 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeChars(char[] v) throws IOException {
/*  778 */     writeChars(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeChars(char[][] v) throws IOException {
/*  786 */     for (int i = 0; i < v.length; i++) {
/*  787 */       writeChars(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeChars(char[][][] v) throws IOException {
/*  795 */     for (int i = 0; i < v.length; i++) {
/*  796 */       writeChars(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeShorts(short[] v, int k, int n) throws IOException {
/*  806 */     int m = this._sb.capacity(); int j;
/*  807 */     for (j = 0; j < n; j += m) {
/*  808 */       int l = Math.min(n - j, m);
/*  809 */       this._sb.position(0).limit(l);
/*  810 */       this._sb.put(v, k + j, l);
/*  811 */       this._bb.position(0).limit(l * 2);
/*  812 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeShorts(short[] v) throws IOException {
/*  822 */     writeShorts(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeShorts(short[][] v) throws IOException {
/*  830 */     for (int i = 0; i < v.length; i++) {
/*  831 */       writeShorts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeShorts(short[][][] v) throws IOException {
/*  839 */     for (int i = 0; i < v.length; i++) {
/*  840 */       writeShorts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeInts(int[] v, int k, int n) throws IOException {
/*  850 */     int m = this._ib.capacity(); int j;
/*  851 */     for (j = 0; j < n; j += m) {
/*  852 */       int l = Math.min(n - j, m);
/*  853 */       this._ib.position(0).limit(l);
/*  854 */       this._ib.put(v, k + j, l);
/*  855 */       this._bb.position(0).limit(l * 4);
/*  856 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeInts(int[] v) throws IOException {
/*  866 */     writeInts(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeInts(int[][] v) throws IOException {
/*  874 */     for (int i = 0; i < v.length; i++) {
/*  875 */       writeInts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeInts(int[][][] v) throws IOException {
/*  883 */     for (int i = 0; i < v.length; i++) {
/*  884 */       writeInts(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeLongs(long[] v, int k, int n) throws IOException {
/*  894 */     int m = this._lb.capacity(); int j;
/*  895 */     for (j = 0; j < n; j += m) {
/*  896 */       int l = Math.min(n - j, m);
/*  897 */       this._lb.position(0).limit(l);
/*  898 */       this._lb.put(v, k + j, l);
/*  899 */       this._bb.position(0).limit(l * 8);
/*  900 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeLongs(long[] v) throws IOException {
/*  910 */     writeLongs(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeLongs(long[][] v) throws IOException {
/*  918 */     for (int i = 0; i < v.length; i++) {
/*  919 */       writeLongs(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeLongs(long[][][] v) throws IOException {
/*  927 */     for (int i = 0; i < v.length; i++) {
/*  928 */       writeLongs(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFloats(float[] v, int k, int n) throws IOException {
/*  938 */     int m = this._fb.capacity(); int j;
/*  939 */     for (j = 0; j < n; j += m) {
/*  940 */       int l = Math.min(n - j, m);
/*  941 */       this._fb.position(0).limit(l);
/*  942 */       this._fb.put(v, k + j, l);
/*  943 */       this._bb.position(0).limit(l * 4);
/*  944 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFloats(float[] v) throws IOException {
/*  954 */     writeFloats(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFloats(float[][] v) throws IOException {
/*  962 */     for (int i = 0; i < v.length; i++) {
/*  963 */       writeFloats(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFloats(float[][][] v) throws IOException {
/*  971 */     for (int i = 0; i < v.length; i++) {
/*  972 */       writeFloats(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDoubles(double[] v, int k, int n) throws IOException {
/*  982 */     int m = this._db.capacity(); int j;
/*  983 */     for (j = 0; j < n; j += m) {
/*  984 */       int l = Math.min(n - j, m);
/*  985 */       this._db.position(0).limit(l);
/*  986 */       this._db.put(v, k + j, l);
/*  987 */       this._bb.position(0).limit(l * 8);
/*  988 */       this._fc.write(this._bb);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDoubles(double[] v) throws IOException {
/*  998 */     writeDoubles(v, 0, v.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDoubles(double[][] v) throws IOException {
/* 1006 */     for (int i = 0; i < v.length; i++) {
/* 1007 */       writeDoubles(v[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDoubles(double[][][] v) throws IOException {
/* 1015 */     for (int i = 0; i < v.length; i++)
/* 1016 */       writeDoubles(v[i]); 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/io/DataFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */