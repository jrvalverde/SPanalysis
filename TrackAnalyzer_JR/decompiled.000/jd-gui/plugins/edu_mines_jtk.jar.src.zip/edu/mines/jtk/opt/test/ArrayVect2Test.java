/*    */ package edu.mines.jtk.opt.test;
/*    */ 
/*    */ import edu.mines.jtk.opt.ArrayVect2;
/*    */ import edu.mines.jtk.opt.Vect;
/*    */ import edu.mines.jtk.opt.VectConst;
/*    */ import edu.mines.jtk.opt.VectUtil;
/*    */ import edu.mines.jtk.util.Almost;
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class ArrayVect2Test extends TestCase {
/*    */   public void testAll() {
/* 15 */     double[][] a = new double[31][21];
/* 16 */     for (int i = 0; i < a.length; i++) {
/* 17 */       for (int k = 0; k < (a[i]).length; k++) {
/* 18 */         a[i][k] = i + 2.4D * k;
/*    */       }
/*    */     } 
/* 21 */     ArrayVect2 arrayVect2 = new ArrayVect2(a, 2.0D);
/* 22 */     VectUtil.test((VectConst)arrayVect2);
/*    */ 
/*    */     
/* 25 */     for (int j = 0; j < a.length; j++) {
/* 26 */       for (int k = 0; k < (a[j]).length; k++) {
/* 27 */         a[j][k] = 1.0D;
/*    */       }
/*    */     } 
/* 30 */     arrayVect2 = new ArrayVect2(a, 3.0D);
/* 31 */     Vect w = arrayVect2.clone();
/* 32 */     w.multiplyInverseCovariance();
/* 33 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect2.dot((VectConst)w));
/* 34 */     assert Almost.FLOAT.equal(0.3333333333333333D, arrayVect2.magnitude());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setUp() throws Exception {
/* 40 */     super.setUp();
/*    */   }
/*    */   protected void tearDown() throws Exception {
/* 43 */     super.tearDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayVect2Test(String name) {
/* 50 */     super(name);
/*    */   }
/*    */   
/*    */   public static Test suite() {
/*    */     try {
/*    */       assert false;
/* 56 */       throw new IllegalStateException("need -ea");
/* 57 */     } catch (AssertionError e) {
/* 58 */       return (Test)new TestSuite(ArrayVect2Test.class);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 65 */     TestRunner.run(suite());
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/opt/test/ArrayVect2Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */