/*     */ package edu.mines.jtk.util.test;
/*     */ 
/*     */ import edu.mines.jtk.util.MathPlus;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestSuite;
/*     */ import junit.textui.TestRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MathPlusTest
/*     */   extends TestCase
/*     */ {
/*     */   public static void main(String[] args) {
/*  20 */     TestSuite suite = new TestSuite(MathPlusTest.class);
/*  21 */     TestRunner.run((Test)suite);
/*     */   }
/*     */   
/*     */   public void test() {
/*  25 */     assertEquals(0.0F, MathPlus.sin(3.1415927F));
/*  26 */     assertEquals(0.0D, MathPlus.sin(Math.PI));
/*     */     
/*  28 */     assertEquals(1.0F, MathPlus.cos(6.2831855F));
/*  29 */     assertEquals(1.0D, MathPlus.cos(6.283185307179586D));
/*     */     
/*  31 */     assertEquals(1.0F, MathPlus.tan(0.7853982F));
/*  32 */     assertEquals(1.0D, MathPlus.tan(0.7853981633974483D));
/*     */     
/*  34 */     assertEquals(1.5707964F, MathPlus.asin(1.0F));
/*  35 */     assertEquals(1.5707963267948966D, MathPlus.asin(1.0D));
/*     */     
/*  37 */     assertEquals(1.5707964F, MathPlus.acos(0.0F));
/*  38 */     assertEquals(1.5707963267948966D, MathPlus.acos(0.0D));
/*     */     
/*  40 */     assertEquals(0.7853982F, MathPlus.atan(1.0F));
/*  41 */     assertEquals(0.7853981633974483D, MathPlus.atan(1.0D));
/*     */     
/*  43 */     assertEquals(1.5707964F, MathPlus.atan2(1.0F, 0.0F));
/*  44 */     assertEquals(1.5707963267948966D, MathPlus.atan2(1.0D, 0.0D));
/*     */     
/*  46 */     assertEquals(-2.3561945F, MathPlus.atan2(-1.0F, -1.0F));
/*  47 */     assertEquals(-2.356194490192345D, MathPlus.atan2(-1.0D, -1.0D));
/*     */     
/*  49 */     assertEquals(3.1415927F, MathPlus.toRadians(180.0F));
/*  50 */     assertEquals(Math.PI, MathPlus.toRadians(180.0D));
/*     */     
/*  52 */     assertEquals(180.0F, MathPlus.toDegrees(3.1415927F));
/*  53 */     assertEquals(180.0D, MathPlus.toDegrees(Math.PI));
/*     */     
/*  55 */     assertEquals(1.0F, MathPlus.log(MathPlus.exp(1.0F)));
/*  56 */     assertEquals(1.0D, MathPlus.log(MathPlus.exp(1.0D)));
/*     */     
/*  58 */     assertEquals(3.0F, MathPlus.sqrt(MathPlus.pow(3.0F, 2.0F)));
/*  59 */     assertEquals(3.0D, MathPlus.sqrt(MathPlus.pow(3.0D, 2.0D)));
/*     */     
/*  61 */     assertEquals(MathPlus.tanh(1.0F), MathPlus.sinh(1.0F) / MathPlus.cosh(1.0F));
/*  62 */     assertEquals(MathPlus.tanh(1.0D), MathPlus.sinh(1.0D) / MathPlus.cosh(1.0D));
/*     */     
/*  64 */     assertEquals(4.0F, MathPlus.ceil(3.1415927F));
/*  65 */     assertEquals(4.0D, MathPlus.ceil(Math.PI));
/*  66 */     assertEquals(-3.0F, MathPlus.ceil(-3.1415927F));
/*  67 */     assertEquals(-3.0D, MathPlus.ceil(-3.141592653589793D));
/*     */     
/*  69 */     assertEquals(3.0F, MathPlus.floor(3.1415927F));
/*  70 */     assertEquals(3.0D, MathPlus.floor(Math.PI));
/*  71 */     assertEquals(-4.0F, MathPlus.floor(-3.1415927F));
/*  72 */     assertEquals(-4.0D, MathPlus.floor(-3.141592653589793D));
/*     */     
/*  74 */     assertEquals(3.0F, MathPlus.rint(3.1415927F));
/*  75 */     assertEquals(3.0D, MathPlus.rint(Math.PI));
/*  76 */     assertEquals(-3.0F, MathPlus.rint(-3.1415927F));
/*  77 */     assertEquals(-3.0D, MathPlus.rint(-3.141592653589793D));
/*     */     
/*  79 */     assertEquals(3, MathPlus.round(3.1415927F));
/*  80 */     assertEquals(3L, MathPlus.round(Math.PI));
/*  81 */     assertEquals(-3, MathPlus.round(-3.1415927F));
/*  82 */     assertEquals(-3L, MathPlus.round(-3.141592653589793D));
/*     */     
/*  84 */     assertEquals(3, MathPlus.round(2.7182817F));
/*  85 */     assertEquals(3L, MathPlus.round(Math.E));
/*  86 */     assertEquals(-3, MathPlus.round(-2.7182817F));
/*  87 */     assertEquals(-3L, MathPlus.round(-2.718281828459045D));
/*     */     
/*  89 */     assertEquals(1.0F, MathPlus.signum(3.1415927F));
/*  90 */     assertEquals(1.0D, MathPlus.signum(Math.PI));
/*  91 */     assertEquals(-1.0F, MathPlus.signum(-3.1415927F));
/*  92 */     assertEquals(-1.0D, MathPlus.signum(-3.141592653589793D));
/*  93 */     assertEquals(0.0F, MathPlus.signum(0.0F));
/*  94 */     assertEquals(0.0D, MathPlus.signum(0.0D));
/*     */     
/*  96 */     assertEquals(2, MathPlus.abs(2));
/*  97 */     assertEquals(2L, MathPlus.abs(2L));
/*  98 */     assertEquals(2.0F, MathPlus.abs(2.0F));
/*  99 */     assertEquals(2.0D, MathPlus.abs(2.0D));
/* 100 */     assertEquals(2, MathPlus.abs(-2));
/* 101 */     assertEquals(2L, MathPlus.abs(-2L));
/* 102 */     assertEquals(2.0F, MathPlus.abs(-2.0F));
/* 103 */     assertEquals(2.0D, MathPlus.abs(-2.0D));
/*     */     
/* 105 */     assertEquals(4, MathPlus.max(1, 3, 4, 2));
/* 106 */     assertEquals(4L, MathPlus.max(1L, 3L, 4L, 2L));
/* 107 */     assertEquals(4.0F, MathPlus.max(1.0F, 3.0F, 4.0F, 2.0F));
/* 108 */     assertEquals(4.0D, MathPlus.max(1.0D, 3.0D, 4.0D, 2.0D));
/*     */     
/* 110 */     assertEquals(1, MathPlus.min(3, 1, 4, 2));
/* 111 */     assertEquals(1L, MathPlus.min(3L, 1L, 4L, 2L));
/* 112 */     assertEquals(1.0F, MathPlus.min(3.0F, 1.0F, 4.0F, 2.0F));
/* 113 */     assertEquals(1.0D, MathPlus.min(3.0D, 1.0D, 4.0D, 2.0D));
/*     */   }
/*     */   
/*     */   private void assertEquals(float expected, float actual) {
/* 117 */     float small = 1.0E-6F * MathPlus.max(MathPlus.abs(expected), MathPlus.abs(actual), 1.0F);
/* 118 */     assertEquals(expected, actual, small);
/*     */   }
/*     */   
/*     */   private void assertEquals(double expected, double actual) {
/* 122 */     double small = 9.999999960041972E-13D * MathPlus.max(MathPlus.abs(expected), MathPlus.abs(actual), 1.0D);
/* 123 */     assertEquals(expected, actual, small);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/edu_mines_jtk.jar!/edu/mines/jtk/util/test/MathPlusTest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */