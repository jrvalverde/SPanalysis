/*      */ import java.awt.geom.Point2D;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ChemotaxisStatistic
/*      */ {
/*      */   static double computeFMIIndex(float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, int paramInt1, int paramInt2, int paramInt3, ArrayList paramArrayList) {
/*   17 */     float[][] arrayOfFloat1 = paramArrayOffloat1;
/*      */     
/*   19 */     float[][] arrayOfFloat2 = paramArrayOffloat2;
/*      */     
/*   21 */     int i = paramInt1;
/*      */     
/*   23 */     int j = paramInt2;
/*      */     
/*   25 */     int k = 0;
/*      */ 
/*      */ 
/*      */     
/*   29 */     double[] arrayOfDouble1 = new double[j];
/*      */     
/*   31 */     double[] arrayOfDouble2 = new double[j];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   37 */     for (byte b1 = 0; b1 < j; b1++) {
/*      */       
/*   39 */       k = ((Integer)paramArrayList.get(b1)).intValue();
/*      */       
/*   41 */       byte b = 0;
/*      */       
/*   43 */       double d1 = 0.0D;
/*      */       
/*   45 */       if (i <= k)
/*      */       {
/*   47 */         while (b < i - 1) {
/*      */ 
/*      */ 
/*      */           
/*   51 */           d1 += Point2D.distance((new Float(arrayOfFloat1[b1][b])).doubleValue(), (
/*      */               
/*   53 */               new Float(arrayOfFloat2[b1][b])).doubleValue(), (new Float(
/*      */                 
/*   55 */                 arrayOfFloat1[b1][b + 1])).doubleValue(), (new Float(
/*      */                 
/*   57 */                 arrayOfFloat2[b1][b + 1])).doubleValue());
/*      */           
/*   59 */           b++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   67 */       b = 0;
/*      */       
/*   69 */       if (i > k)
/*      */       {
/*   71 */         while (b < k - 1) {
/*      */ 
/*      */ 
/*      */           
/*   75 */           d1 += Point2D.distance((new Float(arrayOfFloat1[b1][b])).doubleValue(), (
/*      */               
/*   77 */               new Float(arrayOfFloat2[b1][b])).doubleValue(), (new Float(
/*      */                 
/*   79 */                 arrayOfFloat1[b1][b + 1])).doubleValue(), (new Float(
/*      */                 
/*   81 */                 arrayOfFloat2[b1][b + 1])).doubleValue());
/*      */           
/*   83 */           b++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*   89 */       arrayOfDouble1[b1] = d1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     if (paramInt3 == 1)
/*      */     {
/*      */ 
/*      */       
/*   99 */       for (byte b = 0; b < j; b++) {
/*      */         
/*  101 */         k = ((Integer)paramArrayList.get(b)).intValue();
/*      */         
/*  103 */         double d1 = 0.0D;
/*      */         
/*  105 */         float f = 0.0F;
/*      */         
/*  107 */         if (i <= k)
/*      */         {
/*  109 */           f = arrayOfFloat2[b][i - 1];
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  115 */         if (i > k)
/*      */         {
/*  117 */           f = arrayOfFloat2[b][k - 1];
/*      */         }
/*      */ 
/*      */         
/*  121 */         d1 = f;
/*      */         
/*  123 */         arrayOfDouble2[b] = d1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  129 */     if (paramInt3 == 2)
/*      */     {
/*      */ 
/*      */       
/*  133 */       for (byte b = 0; b < j; b++) {
/*      */         
/*  135 */         k = ((Integer)paramArrayList.get(b)).intValue();
/*      */         
/*  137 */         double d1 = 0.0D;
/*      */         
/*  139 */         float f = 0.0F;
/*      */         
/*  141 */         if (i <= k)
/*      */         {
/*  143 */           f = arrayOfFloat1[b][i - 1];
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  149 */         if (i > k)
/*      */         {
/*  151 */           f = arrayOfFloat1[b][k - 1];
/*      */         }
/*      */ 
/*      */         
/*  155 */         d1 = f;
/*      */         
/*  157 */         arrayOfDouble2[b] = d1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  165 */     double d = 0.0D;
/*      */     
/*  167 */     for (byte b2 = 0; b2 < j; b2++) {
/*      */       
/*  169 */       if (arrayOfDouble1[b2] == 0.0D) {
/*      */         
/*  171 */         d += 0.0D;
/*      */       }
/*      */       else {
/*      */         
/*  175 */         d += arrayOfDouble2[b2] / arrayOfDouble1[b2];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  181 */     return roundDoubleNumbers(d / j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double roundDoubleNumbers(double paramDouble) {
/*  192 */     double d = paramDouble;
/*      */     
/*  194 */     d *= 100.0D;
/*      */     
/*  196 */     d = Math.round(d);
/*      */     
/*  198 */     d /= 100.0D;
/*      */     
/*  200 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ArrayList computeDirectionality(float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, ArrayList paramArrayList, int paramInt) {
/*  211 */     ArrayList arrayList = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/*  215 */     int i = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  221 */     float f1 = 0.0F;
/*      */     
/*  223 */     float f2 = 0.0F;
/*      */ 
/*      */ 
/*      */     
/*  227 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  229 */       double d1 = 0.0D;
/*      */       
/*  231 */       double d2 = 0.0D;
/*      */       
/*  233 */       i = ((Integer)paramArrayList.get(b)).intValue();
/*      */ 
/*      */ 
/*      */       
/*  237 */       byte b1 = 0;
/*      */       
/*  239 */       while (b1 < i - 1) {
/*      */         
/*  241 */         d1 += Point2D.distance((new Float(paramArrayOffloat1[b][b1])).doubleValue(), (
/*      */             
/*  243 */             new Float(paramArrayOffloat2[b][b1])).doubleValue(), (new Float(
/*      */               
/*  245 */               paramArrayOffloat1[b][b1 + 1])).doubleValue(), (new Float(
/*      */               
/*  247 */               paramArrayOffloat2[b][b1 + 1])).doubleValue());
/*      */         
/*  249 */         b1++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  257 */       f1 = paramArrayOffloat1[b][i - 1];
/*      */       
/*  259 */       f2 = paramArrayOffloat2[b][i - 1];
/*      */       
/*  261 */       d2 = Math.sqrt(Math.pow((new Float(f1))
/*      */             
/*  263 */             .doubleValue(), 2.0D) + 
/*      */           
/*  265 */           Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */       
/*  269 */       double d3 = d2 / d1;
/*      */       
/*  271 */       arrayList.add(new Double(d3));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  277 */     return arrayList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static ArrayList computeDistandVelocity(String paramString, float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, ArrayList paramArrayList, int paramInt, double paramDouble) {
/*  287 */     int i = 0;
/*      */ 
/*      */     
/*  290 */     ArrayList arrayList = new ArrayList();
/*      */     
/*  292 */     if (paramString.equals("velocity"))
/*      */     {
/*  294 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  296 */         i = ((Integer)paramArrayList.get(b)).intValue();
/*      */         
/*  298 */         byte b1 = 0;
/*      */         
/*  300 */         double d = 0.0D;
/*      */         
/*  302 */         while (b1 < i - 1) {
/*      */           
/*  304 */           d += Point2D.distance((new Float(paramArrayOffloat1[b][b1])).doubleValue(), (
/*      */               
/*  306 */               new Float(paramArrayOffloat2[b][b1])).doubleValue(), (new Float(
/*      */                 
/*  308 */                 paramArrayOffloat1[b][b1 + 1])).doubleValue(), (new Float(
/*      */                 
/*  310 */                 paramArrayOffloat2[b][b1 + 1])).doubleValue());
/*      */           
/*  312 */           b1++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  320 */         if (paramDouble * (i - 1) == 0.0D) {
/*      */           
/*  322 */           d = 0.0D;
/*      */         }
/*      */         else {
/*      */           
/*  326 */           d /= paramDouble * (i - 1);
/*      */         } 
/*      */ 
/*      */         
/*  330 */         arrayList.add(new Double(d));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  336 */     if (paramString.equals("accumulated distance"))
/*      */     {
/*  338 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  340 */         i = ((Integer)paramArrayList.get(b)).intValue();
/*      */         
/*  342 */         byte b1 = 0;
/*      */         
/*  344 */         double d = 0.0D;
/*      */         
/*  346 */         while (b1 < i - 1) {
/*      */           
/*  348 */           d += Point2D.distance((new Float(paramArrayOffloat1[b][b1])).doubleValue(), (
/*      */               
/*  350 */               new Float(paramArrayOffloat2[b][b1])).doubleValue(), (new Float(
/*      */                 
/*  352 */                 paramArrayOffloat1[b][b1 + 1])).doubleValue(), (new Float(
/*      */                 
/*  354 */                 paramArrayOffloat2[b][b1 + 1])).doubleValue());
/*      */           
/*  356 */           b1++;
/*      */         } 
/*      */ 
/*      */         
/*  360 */         arrayList.add(new Double(d));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  366 */     if (paramString.equals("euclid distance"))
/*      */     {
/*  368 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  370 */         i = ((Integer)paramArrayList.get(b)).intValue();
/*      */         
/*  372 */         double d = 0.0D;
/*      */ 
/*      */ 
/*      */         
/*  376 */         float f1 = paramArrayOffloat1[b][i - 1];
/*      */         
/*  378 */         float f2 = paramArrayOffloat2[b][i - 1];
/*      */         
/*  380 */         d = Math.sqrt(Math.pow((new Float(f1))
/*      */               
/*  382 */               .doubleValue(), 2.0D) + 
/*      */             
/*  384 */             Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */         
/*  388 */         arrayList.add(new Double(d));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  394 */     return arrayList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double[] computeVariables(String paramString, float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, ArrayList paramArrayList, int paramInt, double paramDouble) {
/*  406 */     double d1 = 0.0D;
/*      */     
/*  408 */     double d2 = 0.0D;
/*      */     
/*  410 */     double d3 = 0.0D;
/*      */     
/*  412 */     double d4 = 0.0D;
/*      */     
/*  414 */     double[] arrayOfDouble = new double[4];
/*      */ 
/*      */ 
/*      */     
/*  418 */     ArrayList arrayList = computeDistandVelocity(paramString, paramArrayOffloat1, paramArrayOffloat2, paramArrayList, paramInt, paramDouble);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  424 */     for (byte b1 = 0; b1 < arrayList.size(); b1++) {
/*      */       
/*  426 */       Double double_ = arrayList.get(b1);
/*      */       
/*  428 */       if (double_.doubleValue() > d1)
/*      */       {
/*  430 */         d1 = double_.doubleValue();
/*      */       }
/*      */     } 
/*      */     
/*  434 */     d2 = d1;
/*      */ 
/*      */ 
/*      */     
/*  438 */     for (byte b2 = 0; b2 < arrayList.size(); b2++) {
/*      */       
/*  440 */       Double double_ = arrayList.get(b2);
/*      */       
/*  442 */       if (double_.doubleValue() < d2)
/*      */       {
/*  444 */         d2 = double_.doubleValue();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  452 */     for (byte b3 = 0; b3 < arrayList.size(); b3++) {
/*      */       
/*  454 */       Double double_ = arrayList.get(b3);
/*      */       
/*  456 */       d3 += double_.doubleValue();
/*      */     } 
/*      */ 
/*      */     
/*  460 */     d3 /= arrayList.size();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     for (byte b4 = 0; b4 < arrayList.size(); b4++) {
/*      */       
/*  468 */       Double double_ = arrayList.get(b4);
/*      */       
/*  470 */       d4 += Math.pow(double_.doubleValue() - d3, 2.0D);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  475 */     double d5 = arrayList.size();
/*      */     
/*  477 */     double d6 = 1.0D / (d5 - 1.0D);
/*      */ 
/*      */     
/*  480 */     d4 = Math.sqrt(d6 * d4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  486 */     d1 = roundDoubleNumbers(d1);
/*      */     
/*  488 */     d2 = roundDoubleNumbers(d2);
/*      */     
/*  490 */     d3 = roundDoubleNumbers(d3);
/*      */     
/*  492 */     d4 = roundDoubleNumbers(d4);
/*      */ 
/*      */ 
/*      */     
/*  496 */     arrayOfDouble[0] = d1;
/*      */     
/*  498 */     arrayOfDouble[1] = d2;
/*      */     
/*  500 */     arrayOfDouble[2] = d3;
/*      */     
/*  502 */     arrayOfDouble[3] = d4;
/*      */     
/*  504 */     return arrayOfDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double[] centerofMassSeries(int paramInt1, float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, int paramInt2, ArrayList paramArrayList) {
/*  515 */     float[][] arrayOfFloat1 = paramArrayOffloat1;
/*      */     
/*  517 */     float[][] arrayOfFloat2 = paramArrayOffloat2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  523 */     double d1 = 0.0D;
/*      */     
/*  525 */     double d2 = 0.0D;
/*      */     
/*  527 */     double d3 = 0.0D;
/*      */     
/*  529 */     double[] arrayOfDouble = new double[3];
/*      */ 
/*      */ 
/*      */     
/*  533 */     int i = 0;
/*      */     
/*  535 */     for (byte b = 0; b < paramInt2; b++) {
/*      */       
/*  537 */       i = ((Integer)paramArrayList.get(b)).intValue();
/*      */       
/*  539 */       if (paramInt1 <= i) {
/*      */         
/*  541 */         d1 += arrayOfFloat1[b][paramInt1 - 1];
/*      */         
/*  543 */         d2 += arrayOfFloat2[b][paramInt1 - 1];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       if (paramInt1 > i) {
/*      */         
/*  551 */         d1 += arrayOfFloat1[b][i - 1];
/*      */         
/*  553 */         d2 += arrayOfFloat2[b][i - 1];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  561 */     if (paramInt2 != 0) {
/*      */       
/*  563 */       d1 /= paramInt2;
/*      */       
/*  565 */       d2 /= paramInt2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  571 */     d3 = Point2D.distance(0.0D, 0.0D, d1, d2);
/*      */ 
/*      */ 
/*      */     
/*  575 */     d3 = roundDoubleNumbers(d3);
/*      */     
/*  577 */     d1 = roundDoubleNumbers(d1);
/*      */     
/*  579 */     d2 = roundDoubleNumbers(d2);
/*      */ 
/*      */ 
/*      */     
/*  583 */     arrayOfDouble[0] = d1;
/*      */     
/*  585 */     arrayOfDouble[1] = d2;
/*      */     
/*  587 */     arrayOfDouble[2] = d3;
/*      */ 
/*      */ 
/*      */     
/*  591 */     return arrayOfDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double computeChemotaxisIndex(float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, int paramInt1, int paramInt2, ArrayList paramArrayList) {
/*  602 */     float[][] arrayOfFloat1 = paramArrayOffloat1;
/*      */     
/*  604 */     float[][] arrayOfFloat2 = paramArrayOffloat2;
/*      */     
/*  606 */     int i = paramInt1;
/*      */     
/*  608 */     int j = paramInt2;
/*      */     
/*  610 */     int k = 0;
/*      */ 
/*      */ 
/*      */     
/*  614 */     double[] arrayOfDouble1 = new double[j];
/*      */     
/*  616 */     double[] arrayOfDouble2 = new double[j];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  624 */     for (byte b1 = 0; b1 < j; b1++) {
/*      */       
/*  626 */       k = ((Integer)paramArrayList.get(b1)).intValue();
/*      */       
/*  628 */       byte b = 0;
/*      */       
/*  630 */       double d1 = 0.0D;
/*      */       
/*  632 */       if (i <= k)
/*      */       {
/*  634 */         while (b < i - 1) {
/*      */ 
/*      */ 
/*      */           
/*  638 */           d1 += Point2D.distance((new Float(arrayOfFloat1[b1][b])).doubleValue(), (
/*      */               
/*  640 */               new Float(arrayOfFloat2[b1][b])).doubleValue(), (new Float(
/*      */                 
/*  642 */                 arrayOfFloat1[b1][b + 1])).doubleValue(), (new Float(
/*      */                 
/*  644 */                 arrayOfFloat2[b1][b + 1])).doubleValue());
/*      */           
/*  646 */           b++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  654 */       b = 0;
/*      */       
/*  656 */       if (i > k)
/*      */       {
/*  658 */         while (b < k - 1) {
/*      */ 
/*      */ 
/*      */           
/*  662 */           d1 += Point2D.distance((new Float(arrayOfFloat1[b1][b])).doubleValue(), (
/*      */               
/*  664 */               new Float(arrayOfFloat2[b1][b])).doubleValue(), (new Float(
/*      */                 
/*  666 */                 arrayOfFloat1[b1][b + 1])).doubleValue(), (new Float(
/*      */                 
/*  668 */                 arrayOfFloat2[b1][b + 1])).doubleValue());
/*      */           
/*  670 */           b++;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  676 */       arrayOfDouble1[b1] = d1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  684 */     for (byte b2 = 0; b2 < j; b2++) {
/*      */       
/*  686 */       double d1 = 0.0D;
/*      */       
/*  688 */       k = ((Integer)paramArrayList.get(b2)).intValue();
/*      */ 
/*      */ 
/*      */       
/*  692 */       float f1 = 0.0F;
/*      */       
/*  694 */       float f2 = 0.0F;
/*      */       
/*  696 */       if (i <= k) {
/*      */         
/*  698 */         f1 = arrayOfFloat1[b2][i - 1];
/*      */         
/*  700 */         f2 = arrayOfFloat2[b2][i - 1];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  706 */       if (i > k) {
/*      */         
/*  708 */         f1 = arrayOfFloat1[b2][k - 1];
/*      */         
/*  710 */         f2 = arrayOfFloat2[b2][k - 1];
/*      */       } 
/*      */ 
/*      */       
/*  714 */       d1 = Math.sqrt(Math.pow((new Float(f1))
/*      */             
/*  716 */             .doubleValue(), 2.0D) + 
/*      */           
/*  718 */           Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */       
/*  722 */       arrayOfDouble2[b2] = d1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  728 */     double d = 0.0D;
/*      */     
/*  730 */     for (byte b3 = 0; b3 < j; b3++) {
/*      */       
/*  732 */       if (arrayOfDouble1[b3] == 0.0D) {
/*      */         
/*  734 */         d += 0.0D;
/*      */       }
/*      */       else {
/*      */         
/*  738 */         d += arrayOfDouble2[b3] / arrayOfDouble1[b3];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  746 */     return roundDoubleNumbers(d / j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static double[] computeRayleighTest(String paramString, double paramDouble, float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, ArrayList paramArrayList, int paramInt) {
/*  755 */     int i = 0;
/*      */     
/*  757 */     double d1 = 0.0D;
/*      */     
/*  759 */     double d2 = 0.0D;
/*      */     
/*  761 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/*  765 */     if (paramString.equals("Use endpoints"))
/*      */     {
/*  767 */       for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */         
/*  769 */         i = ((Integer)paramArrayList.get(b1)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  775 */         double d7 = (new Float(paramArrayOffloat1[b1][i - 1])).doubleValue();
/*      */         
/*  777 */         double d8 = (new Float(paramArrayOffloat2[b1][i - 1])).doubleValue();
/*      */ 
/*      */ 
/*      */         
/*  781 */         if (d7 != 0.0D || d8 != 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  789 */           double d = Math.sqrt(Math.pow(d7, 2.0D) + 
/*      */               
/*  791 */               Math.pow(d8, 2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  797 */           d1 += d7 / d;
/*      */           
/*  799 */           d2 += d8 / d;
/*      */           
/*  801 */           b++;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  813 */     if (paramString.equals("Endpoints with dist greater than"))
/*      */     {
/*  815 */       if (paramDouble > 0.0D)
/*      */       {
/*      */ 
/*      */         
/*  819 */         for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */           
/*  821 */           i = ((Integer)paramArrayList.get(b1)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  827 */           double d7 = (new Float(paramArrayOffloat1[b1][i - 1])).doubleValue();
/*      */           
/*  829 */           double d8 = (new Float(paramArrayOffloat2[b1][i - 1])).doubleValue();
/*      */ 
/*      */ 
/*      */           
/*  833 */           if (d7 != 0.0D || d8 != 0.0D) {
/*      */             
/*  835 */             double d = Math.sqrt(Math.pow(d7, 2.0D) + 
/*      */                 
/*  837 */                 Math.pow(d8, 2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  843 */             if (d >= paramDouble) {
/*      */ 
/*      */ 
/*      */               
/*  847 */               d1 += d7 / d;
/*      */               
/*  849 */               d2 += d8 / d;
/*      */               
/*  851 */               b++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  869 */     if (paramString.equals("First point with dist greater than"))
/*      */     {
/*  871 */       if (paramDouble > 0.0D)
/*      */       {
/*      */ 
/*      */         
/*  875 */         for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */           
/*  877 */           i = ((Integer)paramArrayList.get(b1)).intValue();
/*      */ 
/*      */ 
/*      */           
/*  881 */           for (byte b2 = 0; b2 < i; b2++) {
/*      */ 
/*      */ 
/*      */             
/*  885 */             double d7 = (new Float(paramArrayOffloat1[b1][b2])).doubleValue();
/*      */             
/*  887 */             double d8 = (new Float(paramArrayOffloat2[b1][b2])).doubleValue();
/*      */ 
/*      */ 
/*      */             
/*  891 */             if (d7 != 0.0D || d8 != 0.0D) {
/*      */               
/*  893 */               double d = Math.sqrt(Math.pow(d7, 2.0D) + 
/*      */                   
/*  895 */                   Math.pow(d8, 2.0D));
/*      */ 
/*      */ 
/*      */               
/*  899 */               if (d >= paramDouble) {
/*      */                 
/*  901 */                 d1 += d7 / d;
/*      */                 
/*  903 */                 d2 += d8 / d;
/*      */                 
/*  905 */                 b++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  923 */     d1 /= b;
/*      */     
/*  925 */     d2 /= b;
/*      */ 
/*      */ 
/*      */     
/*  929 */     double d3 = Math.sqrt(Math.pow(d1, 2.0D) + Math.pow(d2, 2.0D));
/*      */     
/*  931 */     double d4 = b * Math.pow(d3, 2.0D);
/*      */     
/*  933 */     double d5 = Math.exp(-d4);
/*      */     
/*  935 */     double d6 = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  941 */     if (b < 50) {
/*      */       
/*  943 */       d6 = 1.0D + (2.0D * d4 - Math.pow(d4, 2.0D)) / (4 * b) - (24.0D * d4 - 132.0D * Math.pow(d4, 2.0D) + 76.0D * Math.pow(d4, 3.0D) - 9.0D * Math.pow(d4, 4.0D)) / 288.0D * Math.pow(b, 2.0D);
/*      */     }
/*      */     else {
/*      */       
/*  947 */       d6 = 1.0D;
/*      */     } 
/*      */ 
/*      */     
/*  951 */     d5 = d6 * d5;
/*      */ 
/*      */     
/*  954 */     double[] arrayOfDouble = new double[2];
/*  955 */     arrayOfDouble[0] = b;
/*  956 */     arrayOfDouble[1] = d5;
/*      */     
/*  958 */     return arrayOfDouble;
/*      */   }
/*      */ 
/*      */   
/*      */   static double[] computeRayleighTestVectorData(float[][] paramArrayOffloat1, float[][] paramArrayOffloat2, ArrayList paramArrayList, int paramInt) {
/*  963 */     int i = 0;
/*      */ 
/*      */ 
/*      */     
/*  967 */     ArrayList arrayList1 = new ArrayList();
/*      */     
/*  969 */     ArrayList arrayList2 = new ArrayList();
/*      */     
/*  971 */     ArrayList arrayList3 = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/*  975 */     for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */       
/*  977 */       i = ((Integer)paramArrayList.get(b1)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  983 */       double d5 = (new Float(paramArrayOffloat1[b1][i - 1])).doubleValue();
/*      */       
/*  985 */       double d6 = (new Float(paramArrayOffloat2[b1][i - 1])).doubleValue();
/*      */ 
/*      */ 
/*      */       
/*  989 */       if (d5 != 0.0D || d6 != 0.0D) {
/*      */ 
/*      */ 
/*      */         
/*  993 */         double d = Math.sqrt(Math.pow(d5, 2.0D) + 
/*      */             
/*  995 */             Math.pow(d6, 2.0D));
/*      */         
/*  997 */         arrayList1.add(new Double(roundDoubleNumbers(d)));
/*      */         
/*  999 */         arrayList2.add(new Double(roundDoubleNumbers(d)));
/*      */         
/* 1001 */         arrayList3.add(new Double(roundDoubleNumbers(d)));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1009 */     for (int j = 1; j <= arrayList1.size(); j++) {
/*      */       
/* 1011 */       Double double_ = Collections.<Double>min(arrayList3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1017 */       if (arrayList1.indexOf(double_) == arrayList1.lastIndexOf(double_)) {
/*      */         
/* 1019 */         arrayList3.remove(double_);
/*      */         
/* 1021 */         int k = arrayList1.indexOf(double_);
/*      */         
/* 1023 */         arrayList2.set(k, new Double(j));
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1029 */         int k = j;
/*      */         
/* 1031 */         boolean bool = true;
/*      */         
/* 1033 */         byte b4 = 0;
/*      */ 
/*      */         
/*      */         while (true) {
/* 1037 */           bool = arrayList3.remove(double_);
/*      */           
/* 1039 */           if (bool) {
/*      */             
/* 1041 */             b4++;
/*      */ 
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/* 1053 */         j += b4 - 1;
/*      */         
/* 1055 */         for (byte b5 = 0; b5 < arrayList1.size(); b5++) {
/*      */ 
/*      */ 
/*      */           
/* 1059 */           if (((Double)arrayList1.get(b5)).equals(double_))
/*      */           {
/* 1061 */             arrayList2.set(b5, new Double(k));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1073 */     double d1 = 0.0D;
/*      */     
/* 1075 */     double d2 = 0.0D;
/*      */     
/* 1077 */     byte b2 = 0;
/*      */ 
/*      */ 
/*      */     
/* 1081 */     for (byte b3 = 0; b3 < paramInt; b3++) {
/*      */       
/* 1083 */       i = ((Integer)paramArrayList.get(b3)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1089 */       double d5 = (new Float(paramArrayOffloat1[b3][i - 1])).doubleValue();
/*      */       
/* 1091 */       double d6 = (new Float(paramArrayOffloat2[b3][i - 1])).doubleValue();
/*      */ 
/*      */ 
/*      */       
/* 1095 */       if (d5 != 0.0D || d6 != 0.0D) {
/*      */         
/* 1097 */         double d = Math.sqrt(Math.pow(d5, 2.0D) + 
/*      */             
/* 1099 */             Math.pow(d6, 2.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1105 */         d1 += ((Double)arrayList2.get(b2)).doubleValue() * d5 / d;
/*      */         
/* 1107 */         d2 += ((Double)arrayList2.get(b2)).doubleValue() * d6 / d;
/*      */         
/* 1109 */         b2++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1117 */     double d3 = Math.sqrt(Math.pow(d1, 2.0D) + Math.pow(d2, 2.0D)) / Math.sqrt(Math.pow(b2, 3.0D));
/*      */ 
/*      */ 
/*      */     
/* 1121 */     double d4 = Math.exp(-6.0D * Math.pow(d3, 2.0D) * Math.pow(b2, 2.0D) / ((b2 + 1) * (b2 * 2 + 1)));
/*      */ 
/*      */     
/* 1124 */     double[] arrayOfDouble = new double[2];
/* 1125 */     arrayOfDouble[0] = b2;
/* 1126 */     arrayOfDouble[1] = d4;
/*      */     
/* 1128 */     return arrayOfDouble;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/chemotaxis_tool.jar!/ChemotaxisStatistic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */