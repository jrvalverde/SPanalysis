/*     */ import ij.gui.PlotWindow;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScalingDialog
/*     */   extends JDialog
/*     */   implements ItemListener, ActionListener, WindowListener
/*     */ {
/*     */   JComboBox chooseScalingBox;
/*     */   JTextField minFieldX;
/*     */   JTextField maxFieldX;
/*     */   JTextField minFieldY;
/*     */   JTextField maxFieldY;
/*     */   JTextField fractionField;
/*     */   JButton setButton;
/*  37 */   float minimumX = 0.0F;
/*     */   
/*  39 */   float maximumX = 0.0F;
/*     */   
/*  41 */   float minimumY = 0.0F;
/*     */   
/*  43 */   float maximumY = 0.0F;
/*     */   
/*  45 */   double fraction = 1.0D;
/*     */   
/*     */   boolean auto = true;
/*     */   
/*     */   int _currentHeight;
/*     */   
/*     */   int _currentWidth;
/*     */   
/*     */   public ScalingDialog(ChemotaxisGUI paramChemotaxisGUI) {
/*  54 */     super(paramChemotaxisGUI);
/*  55 */     addWindowListener(this);
/*  56 */     setLayout(new GridLayout(0, 4));
/*     */     
/*  58 */     setTitle("Set axis scaling [unit]:");
/*     */     
/*  60 */     add(new JLabel());
/*  61 */     add(new JLabel());
/*  62 */     add(new JLabel());
/*  63 */     add(new JLabel());
/*     */ 
/*     */     
/*  66 */     this.chooseScalingBox = new JComboBox();
/*  67 */     this.chooseScalingBox.addItem("Auto");
/*  68 */     this.chooseScalingBox.addItem("Manual");
/*  69 */     this.chooseScalingBox.setSelectedItem("Auto");
/*  70 */     this.chooseScalingBox.addItemListener(this);
/*  71 */     add(this.chooseScalingBox);
/*  72 */     add(new JLabel());
/*  73 */     add(new JLabel());
/*  74 */     this.setButton = new JButton("Set scaling");
/*  75 */     this.setButton.addActionListener(this);
/*  76 */     add(this.setButton);
/*     */     
/*  78 */     add(new JLabel());
/*  79 */     add(new JLabel());
/*  80 */     add(new JLabel());
/*  81 */     add(new JLabel());
/*     */     
/*  83 */     add(new JLabel(" Min x axis"));
/*  84 */     this.minFieldX = new JTextField();
/*  85 */     this.minFieldX.setEditable(false);
/*  86 */     add(this.minFieldX);
/*  87 */     add(new JLabel(" Max x axis"));
/*  88 */     this.maxFieldX = new JTextField();
/*  89 */     this.maxFieldX.setEditable(false);
/*  90 */     add(this.maxFieldX);
/*     */     
/*  92 */     add(new JLabel(" Min y axis"));
/*  93 */     this.minFieldY = new JTextField();
/*  94 */     this.minFieldY.setEditable(false);
/*  95 */     add(this.minFieldY);
/*  96 */     add(new JLabel(" Max y axis"));
/*  97 */     this.maxFieldY = new JTextField();
/*  98 */     this.maxFieldY.setEditable(false);
/*  99 */     add(this.maxFieldY);
/*     */     
/* 101 */     add(new JLabel(" Size factor"));
/* 102 */     this.fractionField = new JTextField("1");
/* 103 */     this.fractionField.setEditable(false);
/* 104 */     add(this.fractionField);
/* 105 */     add(new JLabel());
/* 106 */     add(new JLabel());
/*     */     
/* 108 */     add(new JLabel());
/* 109 */     add(new JLabel());
/* 110 */     add(new JLabel());
/* 111 */     add(new JLabel());
/*     */     
/* 113 */     setAlwaysOnTop(true);
/* 114 */     pack();
/*     */   }
/*     */   
/*     */   public void itemStateChanged(ItemEvent paramItemEvent) {
/* 118 */     if (paramItemEvent.getSource() == this.chooseScalingBox) {
/*     */       
/* 120 */       String str = (String)this.chooseScalingBox.getSelectedItem();
/*     */       
/* 122 */       if (str.equals("Auto")) {
/* 123 */         this.minFieldX.setEditable(false);
/* 124 */         this.maxFieldX.setEditable(false);
/* 125 */         this.minFieldY.setEditable(false);
/* 126 */         this.maxFieldY.setEditable(false);
/* 127 */         this.fractionField.setEditable(false);
/*     */       } else {
/*     */         
/* 130 */         this.minFieldX.setEditable(true);
/* 131 */         this.maxFieldX.setEditable(true);
/* 132 */         this.minFieldY.setEditable(true);
/* 133 */         this.maxFieldY.setEditable(true);
/* 134 */         this.fractionField.setEditable(true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int paramInt) {
/* 142 */     this._currentWidth = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHeight(int paramInt) {
/* 147 */     this._currentHeight = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 152 */     if (paramActionEvent.getSource() == this.setButton) {
/* 153 */       String str = (String)this.chooseScalingBox.getSelectedItem();
/* 154 */       if (str.equals("Auto")) {
/* 155 */         this.auto = true;
/*     */         
/* 157 */         PlotWindow.plotHeight = this._currentHeight;
/*     */         
/* 159 */         PlotWindow.plotWidth = this._currentWidth;
/*     */       } else {
/*     */         
/* 162 */         this.auto = false;
/*     */         
/*     */         try {
/* 165 */           String str1 = this.minFieldX.getText();
/*     */           
/* 167 */           this.minimumX = Float.valueOf(str1).floatValue();
/*     */           
/* 169 */           str1 = this.minFieldY.getText();
/*     */           
/* 171 */           this.minimumY = Float.valueOf(str1).floatValue();
/*     */           
/* 173 */           str1 = this.maxFieldX.getText();
/*     */           
/* 175 */           this.maximumX = Float.valueOf(str1).floatValue();
/*     */           
/* 177 */           str1 = this.maxFieldY.getText();
/*     */           
/* 179 */           this.maximumY = Float.valueOf(str1).floatValue();
/*     */           
/* 181 */           str1 = this.fractionField.getText();
/*     */           
/* 183 */           this.fraction = Double.valueOf(str1).doubleValue();
/*     */           
/* 185 */           PlotWindow.plotHeight = (int)(this.fraction * (Math.abs(this.minimumY) + Math.abs(this.maximumY)));
/*     */           
/* 187 */           PlotWindow.plotWidth = (int)(this.fraction * (Math.abs(this.minimumX) + Math.abs(this.maximumX)));
/*     */         }
/* 189 */         catch (NumberFormatException numberFormatException) {
/* 190 */           JOptionPane.showMessageDialog(this, 
/* 191 */               "Please enter correct values setting auto mode!");
/* 192 */           this.auto = true;
/* 193 */           this.chooseScalingBox.setSelectedItem("Auto");
/*     */           
/* 195 */           PlotWindow.plotHeight = this._currentHeight;
/*     */           
/* 197 */           PlotWindow.plotWidth = this._currentWidth;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 202 */         if (this.minimumX >= this.maximumX || this.minimumY >= this.maximumY) {
/* 203 */           JOptionPane.showMessageDialog(this, 
/* 204 */               "Minimum can't be greater or equal than maximum!");
/* 205 */           this.auto = true;
/* 206 */           this.chooseScalingBox.setSelectedItem("Auto");
/*     */           
/* 208 */           PlotWindow.plotHeight = this._currentHeight;
/*     */           
/* 210 */           PlotWindow.plotWidth = this._currentWidth;
/*     */         } 
/*     */       } 
/*     */       
/* 214 */       setVisible(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowOpened(WindowEvent paramWindowEvent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void windowClosing(WindowEvent paramWindowEvent) {
/*     */     try {
/* 226 */       String str = this.minFieldX.getText();
/*     */       
/* 228 */       this.minimumX = Float.valueOf(str).floatValue();
/*     */       
/* 230 */       str = this.minFieldY.getText();
/*     */       
/* 232 */       this.minimumY = Float.valueOf(str).floatValue();
/*     */       
/* 234 */       str = this.maxFieldX.getText();
/*     */       
/* 236 */       this.maximumX = Float.valueOf(str).floatValue();
/*     */       
/* 238 */       str = this.maxFieldY.getText();
/*     */       
/* 240 */       this.maximumY = Float.valueOf(str).floatValue();
/*     */       
/* 242 */       str = this.fractionField.getText();
/*     */       
/* 244 */       double d = Double.valueOf(str).doubleValue();
/*     */       
/* 246 */       PlotWindow.plotHeight = (int)(d * (Math.abs(this.minimumY) + Math.abs(this.maximumY)));
/*     */       
/* 248 */       PlotWindow.plotWidth = (int)(d * (Math.abs(this.minimumX) + Math.abs(this.maximumX)));
/*     */     }
/* 250 */     catch (NumberFormatException numberFormatException) {
/* 251 */       this.auto = true;
/* 252 */       this.chooseScalingBox.setSelectedItem("Auto");
/*     */       
/* 254 */       PlotWindow.plotHeight = this._currentHeight;
/*     */       
/* 256 */       PlotWindow.plotWidth = this._currentWidth;
/*     */     } 
/*     */ 
/*     */     
/* 260 */     if (this.minimumX >= this.maximumX || this.minimumY >= this.maximumY) {
/* 261 */       this.auto = true;
/* 262 */       this.chooseScalingBox.setSelectedItem("Auto");
/*     */       
/* 264 */       PlotWindow.plotHeight = this._currentHeight;
/*     */       
/* 266 */       PlotWindow.plotWidth = this._currentWidth;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void windowClosed(WindowEvent paramWindowEvent) {}
/*     */   
/*     */   public void windowIconified(WindowEvent paramWindowEvent) {}
/*     */   
/*     */   public void windowDeiconified(WindowEvent paramWindowEvent) {}
/*     */   
/*     */   public void windowActivated(WindowEvent paramWindowEvent) {}
/*     */   
/*     */   public void windowDeactivated(WindowEvent paramWindowEvent) {}
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/chemotaxis_tool.jar!/ScalingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */