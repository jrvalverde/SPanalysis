/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.WindowManager;
/*      */ import ij.gui.Plot;
/*      */ import ij.gui.PlotWindow;
/*      */ import ij.measure.ResultsTable;
/*      */ import ij.plugin.PlugIn;
/*      */ import ij.process.ImageProcessor;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.CardLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.awt.geom.Point2D;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Hashtable;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Vector;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTextPane;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ 
/*      */ public class Chemotaxis_Tool
/*      */   implements PlugIn, ActionListener, ItemListener, WindowListener, ChangeListener {
/*   42 */   ChemotaxisGUI gui = null;
/*      */ 
/*      */   
/*   45 */   ScalingDialog _dialog = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float[][] x_values;
/*      */ 
/*      */ 
/*      */   
/*      */   float[][] y_values;
/*      */ 
/*      */ 
/*      */   
/*   58 */   float _angleBetweenCircle = 66.0F;
/*      */ 
/*      */ 
/*      */   
/*   62 */   float _angleBetweenDiagram = 66.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList _openInfoWindows;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList _selectedDatasets;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList _currentOpenWindows;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList _currentOpenDiagrams;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   Vector _maxVector = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   int _maxPosition = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   float _anglePosition = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int _currentSelectedDataset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   ArrayList _variableSliceNumber = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList _importedData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashSliceNumber;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   LinkedList _listArrayList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashImportedDataset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashSlicesImported;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashTracks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashCurrentDataset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashCurrentPosition;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashPlot;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Hashtable _hashWindow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   float _coordSize = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   float _calxy = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  210 */   double _timeInterval = 2.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String _unitsPath;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String _unitsTime;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int _plotHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int _plotWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void run(String paramString) {
/*  236 */     PlotWindow.plotHeight = 500;
/*      */     
/*  238 */     PlotWindow.plotWidth = 500;
/*      */     
/*  240 */     this._plotHeight = 500;
/*      */     
/*  242 */     this._plotWidth = 500;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  247 */     this.gui = new ChemotaxisGUI(this);
/*      */ 
/*      */     
/*  250 */     this._dialog = new ScalingDialog(this.gui);
/*      */     
/*  252 */     this._dialog.setHeight(this._plotHeight);
/*      */     
/*  254 */     this._dialog.setWidth(this._plotWidth);
/*      */ 
/*      */     
/*  257 */     this._openInfoWindows = new ArrayList();
/*      */     
/*  259 */     this._hashImportedDataset = new Hashtable();
/*      */     
/*  261 */     this._hashSlicesImported = new Hashtable();
/*      */     
/*  263 */     this._hashTracks = new Hashtable();
/*      */     
/*  265 */     this._hashCurrentDataset = new Hashtable();
/*      */     
/*  267 */     this._hashCurrentPosition = new Hashtable();
/*      */     
/*  269 */     this._hashPlot = new Hashtable();
/*      */     
/*  271 */     this._hashWindow = new Hashtable();
/*      */     
/*  273 */     this._currentOpenWindows = new ArrayList();
/*      */     
/*  275 */     this._currentOpenDiagrams = new ArrayList();
/*      */     
/*  277 */     this._importedData = new ArrayList();
/*      */     
/*  279 */     this._hashSliceNumber = new Hashtable();
/*      */     
/*  281 */     this._selectedDatasets = new ArrayList();
/*      */     
/*  283 */     this._listArrayList = new LinkedList();
/*      */     
/*  285 */     this._maxVector = new Vector();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void itemStateChanged(ItemEvent paramItemEvent) {
/*  297 */     if (paramItemEvent.getSource() == this.gui.sectorDataset) {
/*      */       
/*  299 */       String str = (String)this.gui.selectionBoundary.getSelectedItem();
/*      */       
/*  301 */       if (str.equals("Angular sector"))
/*      */       {
/*  303 */         this.gui.sectorDisabled();
/*      */       }
/*      */ 
/*      */       
/*  307 */       if (str.equals("Circular sector"))
/*      */       {
/*  309 */         this.gui.circleDisabled();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  317 */     if (paramItemEvent.getSource() == this.gui.importedDataset) {
/*      */       
/*  319 */       String str = (String)this.gui.importedDataset.getSelectedItem();
/*      */       
/*  321 */       if (this._hashSlicesImported.containsKey(str)) {
/*      */         
/*  323 */         ArrayList arrayList = (ArrayList)this._hashSlicesImported.get(str);
/*      */         
/*  325 */         if (arrayList.size() == 1) {
/*      */           
/*  327 */           this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */           
/*  329 */           this.gui.numberofSlicesType.setSelectedItem("Use only slices equal to");
/*      */         } 
/*      */ 
/*      */         
/*  333 */         if (arrayList.size() == 2)
/*      */         {
/*  335 */           this.gui.numberofSlicesType.setSelectedItem("Use slice range from.. to..");
/*      */           
/*  337 */           this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */           
/*  339 */           this.gui.secondSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(1))));
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  349 */         this.gui.firstSlicesField.setText("");
/*      */         
/*  351 */         this.gui.secondSlicesField.setText("");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  358 */     if (paramItemEvent.getSource() == this.gui.numberofSlicesType) {
/*      */       
/*  360 */       String str1 = (String)this.gui.numberofSlicesType.getSelectedItem();
/*      */       
/*  362 */       String str2 = (String)this.gui.importedDataset.getSelectedItem();
/*      */       
/*  364 */       if (str1.equals("Use slice range from.. to.."))
/*      */       {
/*  366 */         this.gui.secondSlicesField.setEditable(true);
/*      */       }
/*      */ 
/*      */       
/*  370 */       if (str1.equals("Use only slices equal to"))
/*      */       {
/*  372 */         this.gui.secondSlicesField.setEditable(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  378 */       if (this._hashSlicesImported.containsKey(str2)) {
/*      */         
/*  380 */         ArrayList arrayList = (ArrayList)this._hashSlicesImported.get(str2);
/*      */         
/*  382 */         if (arrayList.size() == 1) {
/*      */           
/*  384 */           if (str1.equals("Use slice range from.. to..")) {
/*      */             
/*  386 */             this.gui.firstSlicesField.setText("");
/*      */             
/*  388 */             this.gui.secondSlicesField.setText("");
/*      */           } 
/*      */ 
/*      */           
/*  392 */           if (str1.equals("Use only slices equal to")) {
/*      */             
/*  394 */             this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */             
/*  396 */             this.gui.secondSlicesField.setText("");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  402 */         if (arrayList.size() == 2) {
/*      */           
/*  404 */           if (str1.equals("Use only slices equal to")) {
/*      */             
/*  406 */             this.gui.firstSlicesField.setText("");
/*      */             
/*  408 */             this.gui.secondSlicesField.setText("");
/*      */           } 
/*      */ 
/*      */           
/*  412 */           if (str1.equals("Use slice range from.. to..")) {
/*      */             
/*  414 */             this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */             
/*  416 */             this.gui.secondSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(1))));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  430 */     if (paramItemEvent.getSource() == this.gui.timeUnits) {
/*      */       
/*  432 */       String str1 = (String)this.gui.timeUnits.getSelectedItem();
/*      */       
/*  434 */       String str2 = (String)this.gui.pathUnits.getSelectedItem();
/*      */       
/*  436 */       this.gui.velocityThresholdLabel.setText("Threshold value [" + str2 + "/" + str1 + "]:");
/*      */       
/*  438 */       this.gui.rangeVelocityLabel.setText("Range interval [" + str2 + "/" + str1 + "]:");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  445 */     if (paramItemEvent.getSource() == this.gui.pathUnits) {
/*      */       
/*  447 */       String str1 = (String)this.gui.timeUnits.getSelectedItem();
/*      */       
/*  449 */       String str2 = (String)this.gui.pathUnits.getSelectedItem();
/*      */       
/*  451 */       this.gui.distanceThresholdLabel.setText("Threshold value [" + str2 + "]:");
/*      */       
/*  453 */       this.gui.velocityThresholdLabel.setText("Threshold value [" + str2 + "/" + str1 + "]:");
/*      */       
/*  455 */       this.gui.rangeVelocityLabel.setText("Range interval [" + str2 + "/" + str1 + "]:");
/*      */       
/*  457 */       this.gui.radiusLabel.setText("Radius [" + str2 + "]:");
/*      */       
/*  459 */       this.gui.distanceRayleighLabel.setText("Distance from origin [" + str2 + "]:");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  465 */     if (paramItemEvent.getSource() == this.gui.pathSelection) {
/*      */       
/*  467 */       String str = (String)this.gui.pathSelection.getSelectedItem();
/*      */       
/*  469 */       if (str.equals("less than") || str.equals("more than")) {
/*      */         
/*  471 */         this.gui.firstThresPathField.setEditable(true);
/*      */         
/*  473 */         this.gui.secondThresPathField.setEditable(false);
/*      */       } 
/*      */ 
/*      */       
/*  477 */       if (str.equals("between")) {
/*      */         
/*  479 */         this.gui.firstThresPathField.setEditable(true);
/*      */         
/*  481 */         this.gui.secondThresPathField.setEditable(true);
/*      */       } 
/*      */ 
/*      */       
/*  485 */       this.gui.firstThresPathField.setText("");
/*      */       
/*  487 */       this.gui.secondThresPathField.setText("");
/*      */     } 
/*      */ 
/*      */     
/*  491 */     if (paramItemEvent.getSource() == this.gui.velocitySelection) {
/*      */       
/*  493 */       String str = (String)this.gui.velocitySelection.getSelectedItem();
/*      */       
/*  495 */       if (str.equals("slower than") || str.equals("faster than")) {
/*      */         
/*  497 */         this.gui.firstThresVelocityField.setEditable(true);
/*      */         
/*  499 */         this.gui.secondThresVelocityField.setEditable(false);
/*      */       } 
/*      */ 
/*      */       
/*  503 */       if (str.equals("between")) {
/*      */         
/*  505 */         this.gui.firstThresVelocityField.setEditable(true);
/*      */         
/*  507 */         this.gui.secondThresVelocityField.setEditable(true);
/*      */       } 
/*      */ 
/*      */       
/*  511 */       this.gui.firstThresVelocityField.setText("");
/*      */       
/*  513 */       this.gui.secondThresVelocityField.setText("");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  519 */     if (paramItemEvent.getSource() == this.gui.plotSelection) {
/*      */       
/*  521 */       String str = (String)this.gui.plotSelection.getSelectedItem();
/*      */       
/*  523 */       if (str.equals("No marking"))
/*      */       {
/*  525 */         this.gui.colorBorderField.setEditable(false);
/*      */       }
/*  527 */       if (str.equals("Mark up/down"))
/*      */       {
/*  529 */         this.gui.colorBorderField.setEditable(false);
/*      */       }
/*  531 */       if (str.equals("Mark left/right"))
/*      */       {
/*  533 */         this.gui.colorBorderField.setEditable(false);
/*      */       }
/*  535 */       if (str.equals("Mark more/less accumulated"))
/*      */       {
/*  537 */         this.gui.colorBorderField.setEditable(true);
/*      */       }
/*  539 */       if (str.equals("Mark more/less euclid"))
/*      */       {
/*  541 */         this.gui.colorBorderField.setEditable(true);
/*      */       }
/*  543 */       if (str.equals("Mark faster/slower"))
/*      */       {
/*  545 */         this.gui.colorBorderField.setEditable(true);
/*      */       }
/*  547 */       if (str.equals("Mark directionality"))
/*      */       {
/*  549 */         this.gui.colorBorderField.setEditable(true);
/*      */       }
/*      */ 
/*      */       
/*  553 */       this.gui.colorBorderField.setText("");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  561 */     if (paramItemEvent.getSource() == this.gui.plotSize) {
/*      */       
/*  563 */       String str = (String)this.gui.plotSize.getSelectedItem();
/*      */       
/*  565 */       if (str.equals("400x400")) {
/*      */         
/*  567 */         PlotWindow.plotHeight = 400;
/*      */         
/*  569 */         PlotWindow.plotWidth = 400;
/*      */         
/*  571 */         this._plotHeight = 400;
/*      */         
/*  573 */         this._plotWidth = 400;
/*      */         
/*  575 */         this._dialog.setHeight(this._plotHeight);
/*      */         
/*  577 */         this._dialog.setWidth(this._plotWidth);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  582 */       if (str.equals("450x450")) {
/*      */         
/*  584 */         PlotWindow.plotHeight = 450;
/*      */         
/*  586 */         PlotWindow.plotWidth = 450;
/*      */         
/*  588 */         this._plotHeight = 450;
/*      */         
/*  590 */         this._plotWidth = 450;
/*      */         
/*  592 */         this._dialog.setHeight(this._plotHeight);
/*      */         
/*  594 */         this._dialog.setWidth(this._plotWidth);
/*      */       } 
/*      */ 
/*      */       
/*  598 */       if (str.equals("500x500")) {
/*      */         
/*  600 */         PlotWindow.plotHeight = 500;
/*      */         
/*  602 */         PlotWindow.plotWidth = 500;
/*      */         
/*  604 */         this._plotHeight = 500;
/*      */         
/*  606 */         this._plotWidth = 500;
/*      */         
/*  608 */         this._dialog.setHeight(this._plotHeight);
/*      */         
/*  610 */         this._dialog.setWidth(this._plotWidth);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  618 */     if (paramItemEvent.getSource() == this.gui.selectionDistance) {
/*      */       
/*  620 */       String str = (String)this.gui.selectionDistance.getSelectedItem();
/*      */       
/*  622 */       if (str.equals("Use endpoints"))
/*      */       {
/*  624 */         this.gui.minDistancefromOriginField.setEditable(false);
/*      */       }
/*  626 */       if (str.equals("Endpoints with dist greater than"))
/*      */       {
/*  628 */         this.gui.minDistancefromOriginField.setEditable(true);
/*      */       }
/*  630 */       if (str.equals("First point with dist greater than"))
/*      */       {
/*  632 */         this.gui.minDistancefromOriginField.setEditable(true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  638 */       this.gui.minDistancefromOriginField.setText("");
/*      */       
/*  640 */       this.gui.pValueField.setText("");
/*      */       
/*  642 */       this.gui.numberofUsedTracksField.setText("");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  650 */     if (paramItemEvent.getSource() == this.gui.selectionBoundary) {
/*      */       
/*  652 */       CardLayout cardLayout = (CardLayout)this.gui.cardPanelSector.getLayout();
/*      */       
/*  654 */       cardLayout.show(this.gui.cardPanelSector, (String)paramItemEvent.getItem());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  660 */     if (paramItemEvent.getSource() == this.gui.statisticSelection) {
/*      */       
/*  662 */       CardLayout cardLayout = (CardLayout)this.gui.cardPanelStatistics.getLayout();
/*      */       
/*  664 */       cardLayout.show(this.gui.cardPanelStatistics, (String)paramItemEvent.getItem());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void windowActivated(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void windowClosed(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void windowDeactivated(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void windowDeiconified(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */   
/*      */   public void windowIconified(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */   
/*      */   public void windowOpened(WindowEvent paramWindowEvent) {}
/*      */ 
/*      */   
/*      */   public void windowClosing(WindowEvent paramWindowEvent) {
/*  692 */     if (paramWindowEvent.getSource() == this.gui) {
/*      */       
/*  694 */       if (this._openInfoWindows != null) {
/*      */         
/*  696 */         for (byte b = 0; b < this._openInfoWindows.size(); b++)
/*      */         {
/*  698 */           ((JFrame)this._openInfoWindows.get(b)).dispose();
/*      */         }
/*      */ 
/*      */         
/*  702 */         this._openInfoWindows.clear();
/*      */       } 
/*      */ 
/*      */       
/*  706 */       this._currentOpenWindows.clear();
/*      */       
/*  708 */       this._currentOpenDiagrams.clear();
/*      */       
/*  710 */       WindowManager.closeAllWindows();
/*      */       
/*  712 */       this.gui.dispose();
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  720 */       if (paramWindowEvent.getSource() instanceof JFrame)
/*      */       {
/*  722 */         if (this._openInfoWindows.contains(paramWindowEvent.getSource()))
/*      */         {
/*  724 */           this._openInfoWindows.remove(paramWindowEvent.getSource());
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  734 */       if (paramWindowEvent.getSource() instanceof PlotWindow) {
/*      */ 
/*      */ 
/*      */         
/*  738 */         if (this._currentOpenWindows.contains(paramWindowEvent.getSource())) {
/*      */           
/*  740 */           for (byte b = 0; b < this._currentOpenWindows.size(); b++)
/*      */           {
/*  742 */             ((PlotWindow)this._currentOpenWindows.get(b)).dispose();
/*      */           }
/*      */ 
/*      */           
/*  746 */           this._currentOpenWindows.clear();
/*      */           
/*  748 */           this.gui.plotClosed();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  754 */         if (this._currentOpenDiagrams.contains(paramWindowEvent.getSource())) {
/*      */           
/*  756 */           for (byte b = 0; b < this._currentOpenDiagrams.size(); b++)
/*      */           {
/*  758 */             ((PlotWindow)this._currentOpenDiagrams.get(b)).dispose();
/*      */           }
/*      */ 
/*      */           
/*  762 */           this._currentOpenDiagrams.clear();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void actionPerformed(ActionEvent paramActionEvent) {
/*  782 */     if (paramActionEvent.getSource() == this.gui.butclearAllDatasets) {
/*      */       
/*  784 */       this._selectedDatasets.clear();
/*      */       
/*  786 */       this._hashSlicesImported.clear();
/*      */       
/*  788 */       this._hashImportedDataset.clear();
/*      */       
/*  790 */       this._importedData.clear();
/*      */       
/*  792 */       this._hashSliceNumber.clear();
/*      */       
/*  794 */       this._listArrayList.clear();
/*      */       
/*  796 */       this._hashTracks.clear();
/*      */       
/*  798 */       this._hashCurrentDataset.clear();
/*      */       
/*  800 */       this._hashCurrentPosition.clear();
/*      */       
/*  802 */       this._hashPlot.clear();
/*      */       
/*  804 */       this._hashWindow.clear();
/*      */       
/*  806 */       this.gui.pValueField.setText("");
/*      */       
/*  808 */       this.gui.pValueFieldExtRayleigh.setText("");
/*      */       
/*  810 */       this.gui.minDistancefromOriginField.setText("");
/*      */       
/*  812 */       this.gui.numberofUsedTracksField.setText("");
/*      */       
/*  814 */       this.gui.numberofUsedTracksFieldExtRayleigh.setText("");
/*      */       
/*  816 */       this.gui.sectorDataset.removeAllItems();
/*      */       
/*  818 */       this.gui.velocityDataset.removeAllItems();
/*      */       
/*  820 */       this.gui.plotAnimation.removeAllItems();
/*      */       
/*  822 */       this.gui.statisticDataset.removeAllItems();
/*      */       
/*  824 */       this.gui.extendedstatisticDataset.removeAllItems();
/*      */       
/*  826 */       this.gui.firstSlicesField.setText("");
/*      */       
/*  828 */       this.gui.secondSlicesField.setText("");
/*      */       
/*  830 */       this.gui.firstThresPathField.setText("");
/*      */       
/*  832 */       this.gui.secondThresPathField.setText("");
/*      */       
/*  834 */       this.gui.firstThresVelocityField.setText("");
/*      */       
/*  836 */       this.gui.secondThresVelocityField.setText("");
/*      */       
/*  838 */       this.gui.firstSplitField.setText("");
/*      */       
/*  840 */       this.gui.secondSplitField.setText("");
/*      */       
/*  842 */       this.gui.importedDataset.removeItemListener(this);
/*      */       
/*  844 */       this.gui.importedDataset.removeAllItems();
/*      */       
/*  846 */       this.gui.importedDataset.addItemListener(this);
/*      */       
/*  848 */       this.gui.selectedDataset1.removeAllItems();
/*      */       
/*  850 */       this.gui.selectedDataset1.removeAllItems();
/*      */       
/*  852 */       this.gui.selectedDataset2.removeAllItems();
/*      */       
/*  854 */       this.gui.selectedDataset3.removeAllItems();
/*      */       
/*  856 */       this.gui.selectedDataset4.removeAllItems();
/*      */       
/*  858 */       this.gui.selectedData1.setSelected(false);
/*      */       
/*  860 */       this.gui.selectedData2.setSelected(false);
/*      */       
/*  862 */       this.gui.selectedData3.setSelected(false);
/*      */       
/*  864 */       this.gui.selectedData4.setSelected(false);
/*      */       
/*  866 */       this.gui.disableButtons();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  874 */     if (paramActionEvent.getSource() == this.gui.butcloseAllPlots) {
/*      */       
/*  876 */       if (this._openInfoWindows != null) {
/*      */         
/*  878 */         for (byte b = 0; b < this._openInfoWindows.size(); b++)
/*      */         {
/*  880 */           ((JFrame)this._openInfoWindows.get(b)).dispose();
/*      */         }
/*      */ 
/*      */         
/*  884 */         this._openInfoWindows.clear();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  892 */       WindowManager.closeAllWindows();
/*      */       
/*  894 */       this.gui.plotClosed();
/*      */       
/*  896 */       this._currentOpenWindows.clear();
/*      */       
/*  898 */       this._currentOpenDiagrams.clear();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  906 */     if (paramActionEvent.getSource() == this.gui.butshowThresholdFunctions)
/*      */     {
/*  908 */       if (((JButton)paramActionEvent.getSource()).getText().equals("Open restrictions")) {
/*      */         
/*  910 */         this.gui.selectedThresholds.setVisible(true);
/*      */         
/*  912 */         this.gui.setSize(770, 780);
/*      */         
/*  914 */         this.gui.butshowThresholdFunctions.setText("Close restrictions");
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  922 */         this.gui.selectedThresholds.setVisible(false);
/*      */         
/*  924 */         this.gui.setSize(770, 580);
/*      */         
/*  926 */         this.gui.butshowThresholdFunctions.setText("Open restrictions");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     if (paramActionEvent.getSource() == this.gui.butExtRayleighTest) {
/*      */       
/*  939 */       String str = (String)this.gui.extendedstatisticDataset.getSelectedItem();
/*      */       
/*  941 */       int i = ((Integer)this._hashCurrentPosition.get(str)).intValue();
/*      */       
/*  943 */       ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(i));
/*      */ 
/*      */ 
/*      */       
/*  947 */       int j = ((Integer)this._hashTracks.get(str)).intValue();
/*      */       
/*  949 */       i *= 2;
/*      */ 
/*      */       
/*  952 */       float[][] arrayOfFloat1 = this._listArrayList.get(i);
/*      */       
/*  954 */       float[][] arrayOfFloat2 = this._listArrayList.get(i + 1);
/*      */ 
/*      */       
/*  957 */       double[] arrayOfDouble = ChemotaxisStatistic.computeRayleighTestVectorData(arrayOfFloat1, arrayOfFloat2, arrayList, j);
/*      */ 
/*      */       
/*  960 */       this.gui.numberofUsedTracksFieldExtRayleigh.setText(String.valueOf((int)arrayOfDouble[0]));
/*      */       
/*  962 */       this.gui.pValueFieldExtRayleigh.setText(String.valueOf(arrayOfDouble[1]));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  972 */     if (paramActionEvent.getSource() == this.gui.butRayleighTest) {
/*      */       
/*  974 */       boolean bool = true;
/*      */ 
/*      */       
/*  977 */       String str1 = (String)this.gui.statisticDataset.getSelectedItem();
/*      */       
/*  979 */       int i = ((Integer)this._hashCurrentPosition.get(str1)).intValue();
/*      */       
/*  981 */       ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(i));
/*      */ 
/*      */ 
/*      */       
/*  985 */       int j = ((Integer)this._hashTracks.get(str1)).intValue();
/*      */       
/*  987 */       i *= 2;
/*      */       
/*  989 */       float[][] arrayOfFloat1 = this._listArrayList.get(i);
/*      */       
/*  991 */       float[][] arrayOfFloat2 = this._listArrayList.get(i + 1);
/*      */       
/*  993 */       String str2 = (String)this.gui.selectionDistance.getSelectedItem();
/*      */ 
/*      */       
/*  996 */       double d = 0.0D;
/*      */       
/*  998 */       if (str2.equals("Endpoints with dist greater than")) {
/*      */         
/* 1000 */         String str = this.gui.minDistancefromOriginField.getText();
/*      */ 
/*      */         
/*      */         try {
/* 1004 */           d = Double.valueOf(str).doubleValue();
/*      */ 
/*      */         
/*      */         }
/* 1008 */         catch (NumberFormatException numberFormatException) {
/*      */           
/* 1010 */           JOptionPane.showMessageDialog(this.gui, "Please enter a number!");
/*      */           
/* 1012 */           this.gui.pValueField.setText("");
/* 1013 */           bool = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1020 */       if (str2.equals("First point with dist greater than")) {
/*      */         
/* 1022 */         String str = this.gui.minDistancefromOriginField.getText();
/*      */         try {
/* 1024 */           d = Double.valueOf(str).doubleValue();
/*      */         }
/* 1026 */         catch (NumberFormatException numberFormatException) {
/* 1027 */           JOptionPane.showMessageDialog(this.gui, "Please enter a number!");
/* 1028 */           this.gui.pValueField.setText("");
/* 1029 */           bool = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1034 */       if (bool) {
/*      */         
/* 1036 */         double[] arrayOfDouble = ChemotaxisStatistic.computeRayleighTest(str2, d, arrayOfFloat1, arrayOfFloat2, arrayList, j);
/*      */         
/* 1038 */         this.gui.numberofUsedTracksField.setText(String.valueOf((int)arrayOfDouble[0]));
/*      */         
/* 1040 */         this.gui.pValueField.setText(String.valueOf(arrayOfDouble[1]));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1051 */     if (paramActionEvent.getSource() == this.gui.butcenterofMassStat)
/*      */     {
/*      */ 
/*      */       
/* 1055 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1057 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1059 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1061 */         int i = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1065 */         int j = ((Integer)Collections.<Integer>max(arrayList)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1069 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1071 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */         
/* 1075 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1077 */         String[] arrayOfString = { "Slice", "Center of mass x [" + this._unitsPath + "]", "Center of mass y [" + this._unitsPath + "]", "Center of mass length [" + this._unitsPath + "]" };
/*      */         
/* 1079 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1081 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1089 */         for (byte b2 = 1; b2 <= j; b2++) {
/*      */           
/* 1091 */           double[] arrayOfDouble = ChemotaxisStatistic.centerofMassSeries(b2, arrayOfFloat1, arrayOfFloat2, i, arrayList);
/*      */ 
/*      */ 
/*      */           
/* 1095 */           resultsTable.incrementCounter();
/*      */           
/* 1097 */           resultsTable.addValue(0, b2);
/*      */           
/* 1099 */           resultsTable.addValue(1, arrayOfDouble[0]);
/*      */           
/* 1101 */           resultsTable.addValue(2, arrayOfDouble[1]);
/*      */           
/* 1103 */           resultsTable.addValue(3, arrayOfDouble[2]);
/*      */         } 
/*      */ 
/*      */         
/* 1107 */         resultsTable.show("Center of mass series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1115 */     if (paramActionEvent.getSource() == this.gui.butDirectionalitySliceSeries)
/*      */     {
/*      */ 
/*      */       
/* 1119 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1121 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1123 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */ 
/*      */ 
/*      */         
/* 1127 */         int i = ((Integer)Collections.<Integer>max(arrayList)).intValue();
/*      */         
/* 1129 */         int j = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1133 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1135 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */         
/* 1139 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1141 */         String[] arrayOfString = { "Slice", "Directionality" };
/*      */         
/* 1143 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1145 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 1149 */         for (byte b2 = 1; b2 <= i; b2++) {
/*      */ 
/*      */ 
/*      */           
/* 1153 */           double d = ChemotaxisStatistic.computeChemotaxisIndex(arrayOfFloat1, arrayOfFloat2, b2, j, arrayList);
/*      */ 
/*      */ 
/*      */           
/* 1157 */           resultsTable.incrementCounter();
/*      */           
/* 1159 */           resultsTable.addValue(0, b2);
/*      */           
/* 1161 */           resultsTable.addValue(1, d);
/*      */         } 
/*      */ 
/*      */         
/* 1165 */         resultsTable.show("Directionality series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1175 */     if (paramActionEvent.getSource() == this.gui.butDirectionalityTrackSeries)
/*      */     {
/*      */ 
/*      */       
/* 1179 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1181 */         int i = 0;
/*      */         
/* 1183 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1185 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1187 */         int j = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */         
/* 1190 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1192 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */         
/* 1194 */         ArrayList arrayList1 = ChemotaxisStatistic.computeDirectionality(arrayOfFloat1, arrayOfFloat2, arrayList, j);
/*      */ 
/*      */ 
/*      */         
/* 1198 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1200 */         String[] arrayOfString = { "Track Number", "Directionality", "Endpoint X Value", "Endpoint Y Value" };
/*      */         
/* 1202 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1204 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 1208 */         for (byte b2 = 0; b2 < j; b2++) {
/*      */           
/* 1210 */           i = ((Integer)arrayList.get(b2)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1216 */           float f1 = arrayOfFloat1[b2][i - 1];
/*      */           
/* 1218 */           float f2 = arrayOfFloat2[b2][i - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1224 */           resultsTable.incrementCounter();
/*      */           
/* 1226 */           resultsTable.addValue(0, (b2 + 1));
/*      */           
/* 1228 */           resultsTable.addValue(1, ((Double)arrayList1.get(b2)).doubleValue());
/*      */           
/* 1230 */           resultsTable.addValue(2, (new Float(f1)).doubleValue());
/*      */           
/* 1232 */           resultsTable.addValue(3, (new Float(f2)).doubleValue());
/*      */         } 
/*      */ 
/*      */         
/* 1236 */         resultsTable.show("Directionality series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1244 */     if (paramActionEvent.getSource() == this.gui.butFMISliceSeries)
/*      */     {
/*      */ 
/*      */       
/* 1248 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1250 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1252 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1254 */         int i = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1258 */         int j = ((Integer)Collections.<Integer>max(arrayList)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1262 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1264 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */         
/* 1268 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1270 */         String[] arrayOfString = { "Slice", "x FMI", "y FMI" };
/*      */         
/* 1272 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1274 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 1278 */         for (byte b2 = 1; b2 <= j; b2++) {
/*      */ 
/*      */ 
/*      */           
/* 1282 */           double d1 = ChemotaxisStatistic.computeFMIIndex(arrayOfFloat1, arrayOfFloat2, b2, i, 1, arrayList);
/*      */           
/* 1284 */           double d2 = ChemotaxisStatistic.computeFMIIndex(arrayOfFloat1, arrayOfFloat2, b2, i, 2, arrayList);
/*      */ 
/*      */ 
/*      */           
/* 1288 */           resultsTable.incrementCounter();
/*      */           
/* 1290 */           resultsTable.addValue(0, b2);
/*      */           
/* 1292 */           resultsTable.addValue(1, d2);
/*      */           
/* 1294 */           resultsTable.addValue(2, d1);
/*      */         } 
/*      */ 
/*      */         
/* 1298 */         resultsTable.show("FMI index series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1308 */     if (paramActionEvent.getSource() == this.gui.butFMITrackSeries)
/*      */     {
/*      */ 
/*      */       
/* 1312 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1314 */         int i = 0;
/*      */         
/* 1316 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1318 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1320 */         int j = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 1324 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1326 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */         
/* 1330 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1332 */         String[] arrayOfString = { "Track Number", "x FMI", "y FMI", "Endpoint X Value", "Endpoint Y Value" };
/*      */         
/* 1334 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1336 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 1340 */         for (byte b2 = 0; b2 < j; b2++) {
/*      */           
/* 1342 */           i = ((Integer)arrayList.get(b2)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1348 */           double d1 = 0.0D;
/*      */           
/* 1350 */           byte b3 = 0;
/*      */ 
/*      */ 
/*      */           
/* 1354 */           while (b3 < i - 1) {
/*      */             
/* 1356 */             d1 += Point2D.distance((new Float(arrayOfFloat1[b2][b3])).doubleValue(), (
/*      */                 
/* 1358 */                 new Float(arrayOfFloat2[b2][b3])).doubleValue(), (new Float(
/*      */                   
/* 1360 */                   arrayOfFloat1[b2][b3 + 1])).doubleValue(), (new Float(
/*      */                   
/* 1362 */                   arrayOfFloat2[b2][b3 + 1])).doubleValue());
/*      */             
/* 1364 */             b3++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1372 */           float f1 = arrayOfFloat2[b2][i - 1];
/*      */ 
/*      */ 
/*      */           
/* 1376 */           float f2 = arrayOfFloat1[b2][i - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1382 */           double d2 = roundDoubleNumbers(f2 / d1);
/*      */           
/* 1384 */           double d3 = roundDoubleNumbers(f1 / d1);
/*      */ 
/*      */ 
/*      */           
/* 1388 */           resultsTable.incrementCounter();
/*      */           
/* 1390 */           resultsTable.addValue(0, (b2 + 1));
/*      */           
/* 1392 */           resultsTable.addValue(1, d2);
/*      */           
/* 1394 */           resultsTable.addValue(2, d3);
/*      */           
/* 1396 */           resultsTable.addValue(3, (new Float(f2)).doubleValue());
/*      */           
/* 1398 */           resultsTable.addValue(4, (new Float(f1)).doubleValue());
/*      */         } 
/*      */ 
/*      */         
/* 1402 */         resultsTable.show("Directionality series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1412 */     if (paramActionEvent.getSource() == this.gui.butVelocityTrackSeries)
/*      */     {
/*      */ 
/*      */       
/* 1416 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1418 */         boolean bool = false;
/*      */         
/* 1420 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1422 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1424 */         int i = ((Integer)this._hashTracks.get(str)).intValue();
/*      */         
/* 1426 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1428 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1433 */         ArrayList arrayList1 = ChemotaxisStatistic.computeDistandVelocity("velocity", arrayOfFloat1, arrayOfFloat2, arrayList, i, this._timeInterval);
/*      */ 
/*      */ 
/*      */         
/* 1437 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1439 */         String[] arrayOfString = { "Track Number", "Velocity [" + this._unitsPath + "/" + this._unitsTime + "]" };
/*      */         
/* 1441 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1443 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1449 */         for (byte b2 = 0; b2 < i; b2++) {
/*      */           
/* 1451 */           float f = ((Double)arrayList1.get(b2)).floatValue();
/*      */           
/* 1453 */           f = roundFloatNumbers(f);
/*      */           
/* 1455 */           resultsTable.incrementCounter();
/*      */           
/* 1457 */           resultsTable.addValue(0, (b2 + 1));
/*      */           
/* 1459 */           resultsTable.addValue(1, f);
/*      */         } 
/*      */ 
/*      */         
/* 1463 */         resultsTable.show("Velocity series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1473 */     if (paramActionEvent.getSource() == this.gui.butDistanceTrackSeries)
/*      */     {
/*      */ 
/*      */       
/* 1477 */       for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */         
/* 1479 */         boolean bool = false;
/*      */         
/* 1481 */         String str = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */         
/* 1483 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */         
/* 1485 */         int i = ((Integer)this._hashTracks.get(str)).intValue();
/*      */         
/* 1487 */         float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */         
/* 1489 */         float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1495 */         ArrayList arrayList1 = ChemotaxisStatistic.computeDistandVelocity("accumulated distance", arrayOfFloat1, arrayOfFloat2, arrayList, i, this._timeInterval);
/*      */         
/* 1497 */         ArrayList arrayList2 = ChemotaxisStatistic.computeDistandVelocity("euclid distance", arrayOfFloat1, arrayOfFloat2, arrayList, i, this._timeInterval);
/*      */ 
/*      */ 
/*      */         
/* 1501 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 1503 */         String[] arrayOfString = { "Track Number", "Accumulated distance [" + this._unitsPath + "]", "Euclidean distance [" + this._unitsPath + "]" };
/*      */         
/* 1505 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 1507 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 1511 */         for (byte b2 = 0; b2 < i; b2++) {
/*      */           
/* 1513 */           float f1 = ((Double)arrayList1.get(b2)).floatValue();
/*      */           
/* 1515 */           f1 = roundFloatNumbers(f1);
/*      */           
/* 1517 */           float f2 = ((Double)arrayList2.get(b2)).floatValue();
/*      */           
/* 1519 */           f2 = roundFloatNumbers(f2);
/*      */           
/* 1521 */           resultsTable.incrementCounter();
/*      */           
/* 1523 */           resultsTable.addValue(0, (b2 + 1));
/*      */           
/* 1525 */           resultsTable.addValue(1, f1);
/*      */           
/* 1527 */           resultsTable.addValue(2, f2);
/*      */         } 
/*      */ 
/*      */         
/* 1531 */         resultsTable.show("Distance series for " + str);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1541 */     if (paramActionEvent.getSource() == this.gui.anglePosField) {
/*      */       
/* 1543 */       String str = this.gui.anglePosField.getText();
/*      */ 
/*      */       
/*      */       try {
/* 1547 */         this._anglePosition = Float.valueOf(str).floatValue();
/*      */       }
/* 1549 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 1551 */         JOptionPane.showMessageDialog(this.gui, "Please enter a number!");
/*      */       } 
/*      */ 
/*      */       
/* 1555 */       this._anglePosition = angleCorrection(this._anglePosition);
/*      */       
/* 1557 */       plotSector();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1563 */     if (paramActionEvent.getSource() == this.gui.angleInteriorCircleField) {
/*      */       
/* 1565 */       if (!this._maxVector.isEmpty())
/*      */       {
/* 1567 */         this._maxVector.clear();
/*      */       }
/*      */ 
/*      */       
/* 1571 */       String str = this.gui.angleInteriorCircleField.getText();
/*      */ 
/*      */       
/*      */       try {
/* 1575 */         this._angleBetweenCircle = Float.valueOf(str).floatValue();
/*      */         
/* 1577 */         if (this._angleBetweenCircle > 180.0F) {
/*      */           
/* 1579 */           this._angleBetweenCircle = 180.0F;
/*      */           
/* 1581 */           this.gui.angleInteriorCircleField.setText(String.valueOf(this._angleBetweenCircle));
/*      */         } 
/*      */ 
/*      */         
/* 1585 */         if (this._angleBetweenCircle < 1.0F)
/*      */         {
/* 1587 */           this._angleBetweenCircle = 1.0F;
/*      */           
/* 1589 */           this.gui.angleInteriorCircleField.setText(String.valueOf(this._angleBetweenCircle));
/*      */         }
/*      */       
/*      */       }
/* 1593 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 1595 */         JOptionPane.showMessageDialog(this.gui, "Please enter a number!");
/*      */       } 
/*      */ 
/*      */       
/* 1599 */       plotSector();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1605 */     if (paramActionEvent.getSource() == this.gui.butturnRight) {
/*      */       
/* 1607 */       this._anglePosition--;
/*      */       
/* 1609 */       this._anglePosition = angleCorrection(this._anglePosition);
/*      */       
/* 1611 */       this.gui.anglePosField.setText(String.valueOf(this._anglePosition));
/*      */       
/* 1613 */       plotSector();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1619 */     if (paramActionEvent.getSource() == this.gui.butturnLeft) {
/*      */       
/* 1621 */       this._anglePosition++;
/*      */       
/* 1623 */       this._anglePosition = angleCorrection(this._anglePosition);
/*      */       
/* 1625 */       this.gui.anglePosField.setText(String.valueOf(this._anglePosition));
/*      */       
/* 1627 */       plotSector();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1635 */     if (paramActionEvent.getSource() == this.gui.butcloseSector) {
/*      */       
/* 1637 */       if (!this._maxVector.isEmpty())
/*      */       {
/* 1639 */         this._maxVector.clear();
/*      */       }
/*      */ 
/*      */       
/* 1643 */       if (this._angleBetweenCircle >= 2.0F) {
/*      */         
/* 1645 */         this._angleBetweenCircle--;
/*      */         
/* 1647 */         this.gui.angleInteriorCircleField.setText(String.valueOf(this._angleBetweenCircle));
/*      */         
/* 1649 */         plotSector();
/*      */       }
/*      */       else {
/*      */         
/* 1653 */         JOptionPane.showMessageDialog(this.gui, "Interior angle can't be less than 1 degree");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1659 */     if (paramActionEvent.getSource() == this.gui.butopenSector) {
/*      */       
/* 1661 */       if (!this._maxVector.isEmpty())
/*      */       {
/* 1663 */         this._maxVector.clear();
/*      */       }
/*      */ 
/*      */       
/* 1667 */       if (this._angleBetweenCircle <= 179.0F) {
/*      */         
/* 1669 */         this._angleBetweenCircle++;
/*      */         
/* 1671 */         this.gui.angleInteriorCircleField.setText(String.valueOf(this._angleBetweenCircle));
/*      */         
/* 1673 */         plotSector();
/*      */       }
/*      */       else {
/*      */         
/* 1677 */         JOptionPane.showMessageDialog(this.gui, "Interior angle can't be greater than 180 degrees");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1685 */     if (paramActionEvent.getSource() == this.gui.butshowMax) {
/*      */       
/* 1687 */       if (this._maxVector.isEmpty()) {
/*      */         
/* 1689 */         this._maxPosition = 0;
/*      */         
/* 1691 */         this._anglePosition = 0.0F;
/*      */         
/* 1693 */         int i = 0;
/*      */ 
/*      */ 
/*      */         
/* 1697 */         while (this._anglePosition < 360.0F) {
/*      */           
/* 1699 */           int j = countCells(this._angleBetweenCircle, this._currentSelectedDataset);
/*      */           
/* 1701 */           if (j > i)
/*      */           {
/* 1703 */             i = j;
/*      */           }
/*      */ 
/*      */           
/* 1707 */           this._anglePosition++;
/*      */         } 
/*      */ 
/*      */         
/* 1711 */         this._anglePosition = 0.0F;
/*      */         
/* 1713 */         while (this._anglePosition < 360.0F) {
/*      */           
/* 1715 */           int j = countCells(this._angleBetweenCircle, this._currentSelectedDataset);
/*      */           
/* 1717 */           if (j == i)
/*      */           {
/* 1719 */             this._maxVector.add(new Float(this._anglePosition));
/*      */           }
/*      */ 
/*      */           
/* 1723 */           this._anglePosition++;
/*      */         } 
/*      */ 
/*      */         
/* 1727 */         this._anglePosition = ((Float)this._maxVector.firstElement()).floatValue();
/*      */         
/* 1729 */         this._maxPosition++;
/*      */         
/* 1731 */         this.gui.anglePosField.setText(String.valueOf(this._anglePosition));
/*      */ 
/*      */       
/*      */       }
/* 1735 */       else if (this._maxPosition < this._maxVector.size()) {
/*      */         
/* 1737 */         this._anglePosition = ((Float)this._maxVector.get(this._maxPosition)).floatValue();
/*      */         
/* 1739 */         this.gui.anglePosField.setText(String.valueOf(this._anglePosition));
/*      */         
/* 1741 */         this._maxPosition++;
/*      */       }
/*      */       else {
/*      */         
/* 1745 */         this._maxPosition = 0;
/*      */         
/* 1747 */         this._anglePosition = ((Float)this._maxVector.get(this._maxPosition)).floatValue();
/*      */         
/* 1749 */         this.gui.anglePosField.setText(String.valueOf(this._anglePosition));
/*      */         
/* 1751 */         this._maxPosition++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1757 */       plotSector();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1763 */     if (paramActionEvent.getSource() == this.gui.butshowSector) {
/*      */ 
/*      */ 
/*      */       
/* 1767 */       this._maxVector.clear();
/*      */       
/* 1769 */       this._anglePosition = 0.0F;
/*      */       
/* 1771 */       String str = (String)this.gui.sectorDataset.getSelectedItem();
/*      */ 
/*      */ 
/*      */       
/* 1775 */       if (str.equals("All datasets")) {
/*      */         
/* 1777 */         this.gui.butshowMax.setEnabled(false);
/*      */       }
/*      */       else {
/*      */         
/* 1781 */         this.gui.butshowMax.setEnabled(true);
/*      */       } 
/*      */ 
/*      */       
/* 1785 */       plotSector();
/*      */       
/* 1787 */       this.gui.sectorEnabled();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1793 */     if (paramActionEvent.getSource() == this.gui.butshowCircle) {
/*      */       
/* 1795 */       plotCircle((new Integer(this.gui.radiusCircleField.getText())).intValue());
/*      */       
/* 1797 */       this.gui.circleEnabled();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1803 */     if (paramActionEvent.getSource() == this.gui.butopenRadius) {
/*      */       
/* 1805 */       int i = (new Integer(this.gui.radiusCircleField.getText())).intValue();
/*      */       
/* 1807 */       i++;
/*      */       
/* 1809 */       this.gui.radiusCircleField.setText(String.valueOf(i));
/*      */       
/* 1811 */       plotCircle(i);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1817 */     if (paramActionEvent.getSource() == this.gui.butcloseRadius) {
/*      */       
/* 1819 */       int i = (new Integer(this.gui.radiusCircleField.getText())).intValue();
/*      */       
/* 1821 */       if (i >= 2) {
/*      */         
/* 1823 */         i--;
/*      */         
/* 1825 */         this.gui.radiusCircleField.setText(String.valueOf(i));
/*      */         
/* 1827 */         plotCircle(i);
/*      */       }
/*      */       else {
/*      */         
/* 1831 */         JOptionPane.showMessageDialog(this.gui, "Not possible");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1839 */     if (paramActionEvent.getSource() == this.gui.butImport) {
/*      */       
/* 1841 */       JFileChooser jFileChooser = new JFileChooser();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1863 */       int i = jFileChooser.showOpenDialog(this.gui);
/*      */       
/* 1865 */       if (i == 0) {
/*      */         
/*      */         try {
/*      */           
/* 1869 */           readData(jFileChooser.getSelectedFile().getAbsolutePath(), jFileChooser.getSelectedFile().getName());
/*      */         }
/* 1871 */         catch (IOException iOException) {
/*      */           
/* 1873 */           JOptionPane.showMessageDialog(this.gui, "Error reading from file");
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1885 */     if (paramActionEvent.getSource() == this.gui.butplotVelocityHistogram) {
/*      */ 
/*      */ 
/*      */       
/* 1889 */       String str1 = (String)this.gui.velocityDataset.getSelectedItem();
/*      */       
/* 1891 */       int i = ((Integer)this._hashTracks.get(str1)).intValue();
/* 1892 */       int j = ((Integer)this._hashCurrentPosition.get(str1)).intValue();
/* 1893 */       ArrayList arrayList1 = (ArrayList)this._hashSliceNumber.get(new Integer(j));
/* 1894 */       j *= 2;
/*      */       
/* 1896 */       float[][] arrayOfFloat1 = this._listArrayList.get(j);
/* 1897 */       float[][] arrayOfFloat2 = this._listArrayList.get(j + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1902 */       boolean bool = true;
/*      */       
/* 1904 */       ResultsTable resultsTable = new ResultsTable();
/*      */       
/* 1906 */       String[] arrayOfString = { "Bin number", "Number counts [counts]" };
/*      */       
/* 1908 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */       {
/* 1910 */         resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1916 */       int k = 0;
/*      */       
/* 1918 */       int m = 0;
/*      */       
/* 1920 */       char c = '✐';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1928 */       ArrayList arrayList = ChemotaxisStatistic.computeDistandVelocity("velocity", arrayOfFloat1, arrayOfFloat2, arrayList1, i, this._timeInterval);
/*      */ 
/*      */ 
/*      */       
/* 1932 */       ArrayList arrayList2 = new ArrayList();
/*      */       
/* 1934 */       ArrayList arrayList3 = new ArrayList();
/*      */ 
/*      */ 
/*      */       
/* 1938 */       for (byte b2 = 0; b2 < arrayList.size(); b2++) {
/*      */         
/* 1940 */         float f = ((Double)arrayList.get(b2)).floatValue();
/*      */         
/* 1942 */         f = roundFloatNumbers(f);
/*      */ 
/*      */ 
/*      */         
/* 1946 */         f *= c;
/*      */         
/* 1948 */         arrayList2.add(new Integer(Math.round(f)));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1956 */       for (byte b3 = 0; b3 < arrayList2.size(); b3++) {
/*      */         
/* 1958 */         Integer integer = arrayList2.get(b3);
/*      */         
/* 1960 */         if (integer.intValue() > m)
/*      */         {
/* 1962 */           m = integer.intValue();
/*      */         }
/*      */       } 
/*      */       
/* 1966 */       k = m;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1972 */       for (byte b4 = 0; b4 < arrayList2.size(); b4++) {
/*      */         
/* 1974 */         Integer integer = arrayList2.get(b4);
/*      */         
/* 1976 */         if (integer.intValue() < k)
/*      */         {
/* 1978 */           k = integer.intValue();
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1984 */       int n = 0;
/*      */       
/* 1986 */       int i1 = 0;
/*      */ 
/*      */ 
/*      */       
/* 1990 */       String str2 = this.gui.rangeVelocityField.getText();
/*      */ 
/*      */       
/*      */       try {
/* 1994 */         float f = Float.valueOf(str2).floatValue();
/*      */         
/* 1996 */         f *= c;
/*      */         
/* 1998 */         n = Math.round(f);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2004 */         i1 = m - k;
/*      */ 
/*      */ 
/*      */         
/* 2008 */         int i2 = i1 % n;
/*      */         
/* 2010 */         if (i2 != 0)
/*      */         {
/* 2012 */           bool = false;
/*      */           
/* 2014 */           this.gui.rangeVelocityField.setText("");
/*      */           
/* 2016 */           JOptionPane.showMessageDialog(this.gui, "wrong value");
/*      */         }
/*      */       
/*      */       }
/* 2020 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 2022 */         JOptionPane.showMessageDialog(this.gui, "no value!");
/*      */         
/* 2024 */         bool = false;
/*      */         
/* 2026 */         this.gui.rangeVelocityField.setText("");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2032 */       if (bool) {
/*      */ 
/*      */ 
/*      */         
/* 2036 */         int i2 = i1 / n;
/*      */         
/* 2038 */         float[] arrayOfFloat3 = new float[i2];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2044 */         byte b5 = 0;
/*      */ 
/*      */ 
/*      */         
/* 2048 */         byte b6 = 0;
/*      */         
/* 2050 */         int i3 = k;
/*      */         
/* 2052 */         while (b6 < i2) {
/*      */           
/* 2054 */           byte b8 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2060 */           for (byte b9 = 0; b9 < arrayList2.size(); b9++) {
/*      */             
/* 2062 */             int i4 = ((Integer)arrayList2.get(b9)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2068 */             if (i4 >= i3 && i4 <= i3 + n)
/*      */             {
/* 2070 */               b8++;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2078 */           if (b8 > b5)
/*      */           {
/* 2080 */             b5 = b8;
/*      */           }
/*      */ 
/*      */           
/* 2084 */           arrayOfFloat3[b6] = b8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2090 */           resultsTable.incrementCounter();
/*      */           
/* 2092 */           resultsTable.addValue(0, Double.valueOf((b6 + 1)).doubleValue());
/*      */           
/* 2094 */           resultsTable.addValue(1, Double.valueOf(b8).doubleValue());
/*      */           
/* 2096 */           b6++;
/*      */           
/* 2098 */           i3 += n;
/*      */         } 
/*      */ 
/*      */         
/* 2102 */         b5 += 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2108 */         float[] arrayOfFloat4 = new float[1];
/*      */         
/* 2110 */         Plot plot = new Plot("Chemotaxis Diagram", 
/*      */             
/* 2112 */             "x axis velocity [" + this._unitsPath + "/" + this._unitsTime + "]", "y axis [counts]", arrayOfFloat4, arrayOfFloat4);
/*      */ 
/*      */ 
/*      */         
/* 2116 */         float f1 = (new Integer(k)).floatValue();
/*      */         
/* 2118 */         f1 /= c;
/*      */         
/* 2120 */         float f2 = (new Integer(m)).floatValue();
/*      */         
/* 2122 */         f2 /= c;
/*      */         
/* 2124 */         float f3 = (new Integer(n)).floatValue();
/*      */         
/* 2126 */         f3 /= c;
/*      */ 
/*      */ 
/*      */         
/* 2130 */         plot.setLimits(f1, f2, 0.0D, b5);
/*      */         
/* 2132 */         plot.addLabel(0.0D, 0.0D, "Range interval: " + f3 + " [" + this._unitsTime + "/" + this._unitsPath + "]");
/*      */ 
/*      */ 
/*      */         
/* 2136 */         byte b7 = 0;
/*      */         
/* 2138 */         while (b7 < i2) {
/*      */ 
/*      */ 
/*      */           
/* 2142 */           float f4 = (new Integer(k)).floatValue();
/*      */           
/* 2144 */           f4 /= c;
/*      */           
/* 2146 */           float f5 = (new Integer(k + n)).floatValue();
/*      */           
/* 2148 */           f5 /= c;
/*      */ 
/*      */ 
/*      */           
/* 2152 */           float[] arrayOfFloat5 = { f4, f4 };
/*      */           
/* 2154 */           float[] arrayOfFloat6 = { 0, arrayOfFloat3[b7] };
/*      */           
/* 2156 */           float[] arrayOfFloat7 = { f5, f5 };
/*      */           
/* 2158 */           float[] arrayOfFloat8 = { 0, arrayOfFloat3[b7] };
/*      */           
/* 2160 */           float[] arrayOfFloat9 = { f4, f5 };
/*      */           
/* 2162 */           float[] arrayOfFloat10 = { arrayOfFloat3[b7], arrayOfFloat3[b7] };
/*      */           
/* 2164 */           plot.addPoints(arrayOfFloat5, arrayOfFloat6, 2);
/*      */           
/* 2166 */           plot.addPoints(arrayOfFloat7, arrayOfFloat8, 2);
/*      */           
/* 2168 */           plot.addPoints(arrayOfFloat9, arrayOfFloat10, 2);
/*      */           
/* 2170 */           k += n;
/*      */           
/* 2172 */           b7++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2178 */         PlotWindow plotWindow = plot.show();
/*      */         
/* 2180 */         plotWindow.addWindowListener(this);
/*      */         
/* 2182 */         plotWindow.setResizable(false);
/*      */ 
/*      */ 
/*      */         
/* 2186 */         plotWindow.setTitle("Velocity histogram for " + str1);
/*      */         
/* 2188 */         resultsTable.show("Velocity histogram for " + str1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2198 */     if (paramActionEvent.getSource() == this.gui.butshowZantlPlot) {
/*      */ 
/*      */ 
/*      */       
/* 2202 */       String str = this.gui.anglePosDensityField.getText();
/*      */ 
/*      */ 
/*      */       
/* 2206 */       boolean bool = true;
/*      */       
/* 2208 */       float f = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2214 */         f = Float.valueOf(str).floatValue();
/*      */         
/* 2216 */         if (f > 359.0F)
/*      */         {
/* 2218 */           f %= 360.0F;
/*      */           
/* 2220 */           this.gui.anglePosDensityField.setText(String.valueOf(f));
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 2226 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 2228 */         JOptionPane.showMessageDialog(this.gui, "Position must be between 0 and 360 degrees");
/*      */         
/* 2230 */         bool = false;
/*      */         
/* 2232 */         this.gui.anglePosDensityField.setText("");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2238 */       ResultsTable resultsTable = null;
/*      */ 
/*      */ 
/*      */       
/* 2242 */       if (bool) {
/*      */ 
/*      */ 
/*      */         
/* 2246 */         if (this.gui.openDiagramBox.isSelected())
/*      */         {
/* 2248 */           this._currentOpenDiagrams.clear();
/*      */         }
/*      */ 
/*      */         
/* 2252 */         for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */           PlotWindow plotWindow;
/* 2254 */           String str1 = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */ 
/*      */ 
/*      */           
/* 2258 */           int i = ((Integer)this._hashTracks.get(str1)).intValue();
/*      */ 
/*      */ 
/*      */           
/* 2262 */           resultsTable = new ResultsTable();
/*      */           
/* 2264 */           String[] arrayOfString = { "Interior Angle [deg]", "Density" };
/*      */           
/* 2266 */           for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */           {
/* 2268 */             resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2274 */           float[] arrayOfFloat1 = new float[360];
/*      */           
/* 2276 */           float[] arrayOfFloat2 = new float[360];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2282 */           float f1 = this._anglePosition;
/*      */ 
/*      */ 
/*      */           
/* 2286 */           this._anglePosition = f;
/*      */ 
/*      */ 
/*      */           
/* 2290 */           int j = 0;
/*      */           
/* 2292 */           float f2 = 0.0F;
/*      */           
/* 2294 */           for (byte b2 = 0; b2 < 'Ũ'; b2++) {
/*      */             
/* 2296 */             arrayOfFloat1[b2] = b2;
/*      */             
/* 2298 */             if (b2 <= '´')
/*      */             {
/* 2300 */               j = countCells(b2, b);
/*      */             }
/*      */ 
/*      */             
/* 2304 */             if (b2 > '´') {
/*      */               
/* 2306 */               this._anglePosition = (f + 180.0F) % 360.0F;
/*      */               
/* 2308 */               int k = 180 - b2 % 180;
/*      */               
/* 2310 */               j = countCells(k, b);
/*      */               
/* 2312 */               j = i - j;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2318 */             f2 = (new Integer(j)).floatValue() / (new Integer(i)).floatValue();
/*      */             
/* 2320 */             arrayOfFloat2[b2] = f2;
/*      */ 
/*      */ 
/*      */             
/* 2324 */             resultsTable.incrementCounter();
/*      */             
/* 2326 */             resultsTable.addValue(0, Double.valueOf(b2).doubleValue());
/*      */             
/* 2328 */             resultsTable.addValue(1, Double.valueOf(f2).doubleValue());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2336 */           float[] arrayOfFloat3 = new float[1];
/*      */           
/* 2338 */           Plot plot = new Plot("Density plot", 
/*      */               
/* 2340 */               "x axis [deg]", "y axis [counts]", arrayOfFloat3, arrayOfFloat3);
/*      */           
/* 2342 */           plot.setLimits(0.0D, 360.0D, 0.0D, 1.0D);
/*      */           
/* 2344 */           plot.addPoints(arrayOfFloat1, arrayOfFloat2, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2352 */           if (this._currentOpenDiagrams.size() < this._listArrayList.size() / 2) {
/*      */             
/* 2354 */             plotWindow = plot.show();
/*      */             
/* 2356 */             this._currentOpenDiagrams.add(plotWindow);
/*      */             
/* 2358 */             plotWindow.addWindowListener(this);
/*      */             
/* 2360 */             plotWindow.setResizable(false);
/*      */           }
/*      */           else {
/*      */             
/* 2364 */             plotWindow = this._currentOpenDiagrams.get(b / 2);
/*      */             
/* 2366 */             plotWindow.drawPlot(plot);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2372 */           plotWindow.setTitle("Density plot for " + str1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2378 */           if (this.gui.showDataTablesBox.isSelected())
/*      */           {
/* 2380 */             resultsTable.show("Density plot for " + str1);
/*      */           }
/*      */ 
/*      */           
/* 2384 */           this._anglePosition = f1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2402 */     if (paramActionEvent.getSource() == this.gui.butshowHistogram) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2408 */       ArrayList arrayList = new ArrayList();
/*      */       
/* 2410 */       ResultsTable resultsTable = null;
/*      */ 
/*      */ 
/*      */       
/* 2414 */       int i = 0;
/*      */       
/* 2416 */       int j = 0;
/*      */       
/* 2418 */       getangleInteriorDiagramField();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2424 */       String str = this.gui.diagramRangeField.getText();
/*      */ 
/*      */       
/*      */       try {
/* 2428 */         j = Integer.valueOf(str).intValue();
/*      */         
/* 2430 */         if (j > 180 || j < 1) {
/*      */           
/* 2432 */           j = 10;
/*      */           
/* 2434 */           this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */         } 
/*      */ 
/*      */         
/* 2438 */         if (360 % j != 0)
/*      */         {
/* 2440 */           j = 10;
/*      */           
/* 2442 */           this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */         }
/*      */       
/*      */       }
/* 2446 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 2448 */         JOptionPane.showMessageDialog(this.gui, "Setting default!");
/*      */         
/* 2450 */         j = 10;
/*      */         
/* 2452 */         this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2460 */       for (byte b1 = 0; b1 < this._listArrayList.size(); b1 += 2) {
/*      */         
/* 2462 */         String str1 = (String)this._hashCurrentDataset.get(new Integer(b1 / 2));
/*      */ 
/*      */ 
/*      */         
/* 2466 */         resultsTable = new ResultsTable();
/*      */         
/* 2468 */         String[] arrayOfString = { "Bin number", "Number counts [counts]" };
/*      */         
/* 2470 */         for (byte b3 = 0; b3 < arrayOfString.length; b3++)
/*      */         {
/* 2472 */           resultsTable.setHeading(b3, arrayOfString[b3]);
/*      */         }
/*      */ 
/*      */         
/* 2476 */         float[] arrayOfFloat = new float[360 / j];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2482 */         float f = this._anglePosition;
/*      */ 
/*      */ 
/*      */         
/* 2486 */         this._anglePosition = 0.0F;
/*      */         
/* 2488 */         byte b4 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2494 */         byte b5 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2500 */         int k = 0;
/*      */         
/* 2502 */         while (this._anglePosition < 360.0F) {
/*      */           
/* 2504 */           int m = 0;
/*      */           
/* 2506 */           for (byte b = 0; b < j; b++) {
/*      */             
/* 2508 */             m += countCells(this._angleBetweenDiagram, b1);
/*      */             
/* 2510 */             this._anglePosition++;
/*      */           } 
/*      */ 
/*      */           
/* 2514 */           b5++;
/*      */ 
/*      */ 
/*      */           
/* 2518 */           resultsTable.incrementCounter();
/*      */           
/* 2520 */           resultsTable.addValue(0, Double.valueOf(b5).doubleValue());
/*      */           
/* 2522 */           resultsTable.addValue(1, Double.valueOf(m).doubleValue());
/*      */ 
/*      */ 
/*      */           
/* 2526 */           if (m > k)
/*      */           {
/* 2528 */             k = m;
/*      */           }
/* 2530 */           arrayOfFloat[b4] = m;
/*      */           
/* 2532 */           b4++;
/*      */         } 
/*      */ 
/*      */         
/* 2536 */         k += 4;
/*      */         
/* 2538 */         this._anglePosition = f;
/*      */ 
/*      */ 
/*      */         
/* 2542 */         arrayList.add(arrayOfFloat);
/*      */ 
/*      */ 
/*      */         
/* 2546 */         if (k > i)
/*      */         {
/* 2548 */           i = k;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2558 */       if (this.gui.openDiagramBox.isSelected())
/*      */       {
/* 2560 */         this._currentOpenDiagrams.clear();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2566 */       for (byte b2 = 0; b2 < arrayList.size(); b2++) {
/*      */         PlotWindow plotWindow;
/* 2568 */         String str1 = (String)this._hashCurrentDataset.get(new Integer(b2));
/*      */         
/* 2570 */         float[] arrayOfFloat1 = arrayList.get(b2);
/*      */ 
/*      */ 
/*      */         
/* 2574 */         float[] arrayOfFloat2 = new float[1];
/*      */         
/* 2576 */         Plot plot = new Plot("Chemotaxis histogram", 
/*      */             
/* 2578 */             "x axis [deg]", "y axis [counts]", arrayOfFloat2, arrayOfFloat2);
/*      */         
/* 2580 */         plot.setLimits(0.0D, 360.0D, 0.0D, i);
/*      */         
/* 2582 */         if (this.gui.showAdditionalInfoDiagram.isSelected())
/*      */         {
/* 2584 */           plot.addLabel(0.0D, 0.0D, "Range interval: " + j + " [deg]" + " Interior Angle: " + this._angleBetweenDiagram + " [deg]");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2590 */         byte b = 0;
/*      */         
/* 2592 */         int k = 0;
/*      */         
/* 2594 */         while (b < 360 / j) {
/*      */           
/* 2596 */           float[] arrayOfFloat3 = { k, k };
/*      */           
/* 2598 */           float[] arrayOfFloat4 = { 0, arrayOfFloat1[b] };
/*      */           
/* 2600 */           float[] arrayOfFloat5 = { (k + j), (k + j) };
/*      */           
/* 2602 */           float[] arrayOfFloat6 = { 0, arrayOfFloat1[b] };
/*      */           
/* 2604 */           float[] arrayOfFloat7 = { k, (k + j) };
/*      */           
/* 2606 */           float[] arrayOfFloat8 = { arrayOfFloat1[b], arrayOfFloat1[b] };
/*      */           
/* 2608 */           plot.addPoints(arrayOfFloat3, arrayOfFloat4, 2);
/*      */           
/* 2610 */           plot.addPoints(arrayOfFloat5, arrayOfFloat6, 2);
/*      */           
/* 2612 */           plot.addPoints(arrayOfFloat7, arrayOfFloat8, 2);
/*      */           
/* 2614 */           k += j;
/*      */           
/* 2616 */           b++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2628 */         if (this._currentOpenDiagrams.size() < this._listArrayList.size() / 2) {
/*      */           
/* 2630 */           plotWindow = plot.show();
/*      */           
/* 2632 */           this._currentOpenDiagrams.add(plotWindow);
/*      */           
/* 2634 */           plotWindow.addWindowListener(this);
/*      */           
/* 2636 */           plotWindow.setResizable(false);
/*      */         }
/*      */         else {
/*      */           
/* 2640 */           plotWindow = this._currentOpenDiagrams.get(b2);
/*      */           
/* 2642 */           plotWindow.drawPlot(plot);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2648 */         plotWindow.setTitle("Histogram for " + str1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2654 */         if (this.gui.showDataTablesBox.isSelected())
/*      */         {
/* 2656 */           resultsTable.show("Histogram for " + str1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2666 */     if (paramActionEvent.getSource() == this.gui.butshowRoseDiagram) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2672 */       ArrayList arrayList = new ArrayList();
/*      */       
/* 2674 */       ResultsTable resultsTable = null;
/*      */ 
/*      */ 
/*      */       
/* 2678 */       int i = 0;
/*      */       
/* 2680 */       int j = 0;
/*      */       
/* 2682 */       getangleInteriorDiagramField();
/*      */       
/* 2684 */       String str = this.gui.diagramRangeField.getText();
/*      */ 
/*      */       
/*      */       try {
/* 2688 */         j = Integer.valueOf(str).intValue();
/*      */         
/* 2690 */         if (j > 180 || j < 1) {
/*      */           
/* 2692 */           j = 10;
/*      */           
/* 2694 */           this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */         } 
/*      */ 
/*      */         
/* 2698 */         if (360 % j != 0)
/*      */         {
/* 2700 */           j = 10;
/*      */           
/* 2702 */           this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */         }
/*      */       
/*      */       }
/* 2706 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 2708 */         JOptionPane.showMessageDialog(this.gui, "Setting default!");
/*      */         
/* 2710 */         j = 10;
/*      */         
/* 2712 */         this.gui.diagramRangeField.setText(String.valueOf(j));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2720 */       for (byte b1 = 0; b1 < this._listArrayList.size(); b1 += 2) {
/*      */         
/* 2722 */         String str1 = (String)this._hashCurrentDataset.get(new Integer(b1 / 2));
/*      */ 
/*      */ 
/*      */         
/* 2726 */         resultsTable = new ResultsTable();
/*      */         
/* 2728 */         String[] arrayOfString = { "Leaf number", "Number counts [counts]" };
/*      */         
/* 2730 */         for (byte b3 = 0; b3 < arrayOfString.length; b3++)
/*      */         {
/* 2732 */           resultsTable.setHeading(b3, arrayOfString[b3]);
/*      */         }
/*      */ 
/*      */         
/* 2736 */         float[] arrayOfFloat = new float[360 / j];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2742 */         float f = this._anglePosition;
/*      */ 
/*      */ 
/*      */         
/* 2746 */         this._anglePosition = 0.0F;
/*      */         
/* 2748 */         byte b4 = 0;
/*      */         
/* 2750 */         int k = 0;
/*      */         
/* 2752 */         byte b5 = 0;
/*      */         
/* 2754 */         while (this._anglePosition < 360.0F) {
/*      */           
/* 2756 */           int m = 0;
/*      */           
/* 2758 */           for (byte b = 0; b < j; b++) {
/*      */             
/* 2760 */             m += countCells(this._angleBetweenDiagram, b1);
/*      */             
/* 2762 */             this._anglePosition++;
/*      */           } 
/*      */ 
/*      */           
/* 2766 */           b5++;
/*      */ 
/*      */ 
/*      */           
/* 2770 */           resultsTable.incrementCounter();
/*      */           
/* 2772 */           resultsTable.addValue(0, Double.valueOf(b5).doubleValue());
/*      */           
/* 2774 */           resultsTable.addValue(1, Double.valueOf(m).doubleValue());
/*      */           
/* 2776 */           if (m > k)
/*      */           {
/* 2778 */             k = m;
/*      */           }
/* 2780 */           arrayOfFloat[b4] = m;
/*      */           
/* 2782 */           b4++;
/*      */         } 
/*      */ 
/*      */         
/* 2786 */         k += 4;
/*      */         
/* 2788 */         this._anglePosition = f;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2794 */         arrayList.add(arrayOfFloat);
/*      */ 
/*      */ 
/*      */         
/* 2798 */         if (k > i)
/*      */         {
/* 2800 */           i = k;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2806 */       if (this.gui.openDiagramBox.isSelected())
/*      */       {
/* 2808 */         this._currentOpenDiagrams.clear();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2814 */       for (byte b2 = 0; b2 < arrayList.size(); b2++) {
/*      */         PlotWindow plotWindow;
/* 2816 */         String str1 = (String)this._hashCurrentDataset.get(new Integer(b2));
/*      */         
/* 2818 */         float[] arrayOfFloat1 = arrayList.get(b2);
/*      */ 
/*      */ 
/*      */         
/* 2822 */         float[] arrayOfFloat2 = new float[1];
/*      */         
/* 2824 */         Plot plot = new Plot("Chemotaxis Diagram", 
/*      */             
/* 2826 */             "x axis [counts]", "y axis [counts]", arrayOfFloat2, arrayOfFloat2);
/*      */         
/* 2828 */         plot.setLimits(-i, i, -i, i);
/*      */         
/* 2830 */         if (this.gui.showAdditionalInfoDiagram.isSelected())
/*      */         {
/* 2832 */           plot.addLabel(0.0D, 0.0D, "Range interval: " + j + " [deg]" + " Interior Angle: " + this._angleBetweenDiagram + " [deg]");
/*      */         }
/*      */ 
/*      */         
/* 2836 */         float[] arrayOfFloat3 = new float[2];
/*      */         
/* 2838 */         float[] arrayOfFloat4 = { -i, i };
/*      */         
/* 2840 */         plot.addPoints(arrayOfFloat3, arrayOfFloat4, 2);
/*      */         
/* 2842 */         plot.addPoints(arrayOfFloat4, arrayOfFloat3, 2);
/*      */         
/* 2844 */         byte b = 0;
/*      */         
/* 2846 */         int k = 0;
/*      */         
/* 2848 */         while (b < 360 / j) {
/*      */           
/* 2850 */           float[] arrayOfFloat5 = {
/*      */ 
/*      */ 
/*      */               
/* 2854 */               0, (new Double(Math.cos(Math.toRadians(k)) * 
/*      */                 
/* 2856 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2858 */           float[] arrayOfFloat6 = {
/*      */ 
/*      */ 
/*      */               
/* 2862 */               0, (new Double(Math.sin(Math.toRadians(k)) * 
/*      */                 
/* 2864 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2866 */           float[] arrayOfFloat7 = {
/*      */ 
/*      */ 
/*      */               
/* 2870 */               0, (new Double(Math.cos(
/*      */                   
/* 2872 */                   Math.toRadians((k + j))) * 
/*      */                 
/* 2874 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2876 */           float[] arrayOfFloat8 = {
/*      */ 
/*      */ 
/*      */               
/* 2880 */               0, (new Double(Math.sin(
/*      */                   
/* 2882 */                   Math.toRadians((k + j))) * 
/*      */                 
/* 2884 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2886 */           float[] arrayOfFloat9 = {
/*      */               
/* 2888 */               (new Double(Math.cos(Math.toRadians(k)) * 
/*      */                 
/* 2890 */                 arrayOfFloat1[b])).floatValue(), (
/*      */               
/* 2892 */               new Double(Math.cos(
/*      */                   
/* 2894 */                   Math.toRadians((k + j))) * 
/*      */                 
/* 2896 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2898 */           float[] arrayOfFloat10 = {
/*      */               
/* 2900 */               (new Double(Math.sin(Math.toRadians(k)) * 
/*      */                 
/* 2902 */                 arrayOfFloat1[b])).floatValue(), (
/*      */               
/* 2904 */               new Double(Math.sin(
/*      */                   
/* 2906 */                   Math.toRadians((k + j))) * 
/*      */                 
/* 2908 */                 arrayOfFloat1[b])).floatValue()
/*      */             };
/* 2910 */           plot.addPoints(arrayOfFloat5, arrayOfFloat6, 2);
/*      */           
/* 2912 */           plot.addPoints(arrayOfFloat7, arrayOfFloat8, 2);
/*      */           
/* 2914 */           plot.addPoints(arrayOfFloat9, arrayOfFloat10, 2);
/*      */           
/* 2916 */           k += j;
/*      */           
/* 2918 */           b++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2930 */         if (this._currentOpenDiagrams.size() < this._listArrayList.size() / 2) {
/*      */           
/* 2932 */           plotWindow = plot.show();
/*      */           
/* 2934 */           this._currentOpenDiagrams.add(plotWindow);
/*      */           
/* 2936 */           plotWindow.addWindowListener(this);
/*      */           
/* 2938 */           plotWindow.setResizable(false);
/*      */         }
/*      */         else {
/*      */           
/* 2942 */           plotWindow = this._currentOpenDiagrams.get(b2);
/*      */           
/* 2944 */           plotWindow.drawPlot(plot);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2950 */         plotWindow.setTitle("Rose plot for " + str1);
/*      */ 
/*      */ 
/*      */         
/* 2954 */         if (this.gui.showDataTablesBox.isSelected())
/*      */         {
/* 2956 */           resultsTable.show("Rose Plot for " + str1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2966 */     if (paramActionEvent.getSource() == this.gui.butshowCircularPlot) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2972 */       ArrayList arrayList = new ArrayList();
/*      */ 
/*      */ 
/*      */       
/* 2976 */       ArrayList arrayList1 = new ArrayList();
/*      */ 
/*      */ 
/*      */       
/* 2980 */       ResultsTable resultsTable = null;
/*      */ 
/*      */ 
/*      */       
/* 2984 */       float f = 0.0F;
/*      */       
/* 2986 */       getangleInteriorDiagramField();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2994 */       for (byte b1 = 0; b1 < this._listArrayList.size(); b1 += 2) {
/*      */         
/* 2996 */         String str = (String)this._hashCurrentDataset.get(new Integer(b1 / 2));
/*      */         
/* 2998 */         resultsTable = new ResultsTable();
/*      */         
/* 3000 */         String[] arrayOfString = { "Angle pos [deg]", "Number counts [counts]" };
/*      */         
/* 3002 */         for (byte b3 = 0; b3 < arrayOfString.length; b3++)
/*      */         {
/* 3004 */           resultsTable.setHeading(b3, arrayOfString[b3]);
/*      */         }
/*      */ 
/*      */         
/* 3008 */         float[] arrayOfFloat = new float[360];
/*      */ 
/*      */ 
/*      */         
/* 3012 */         float f1 = this._anglePosition;
/*      */         
/* 3014 */         this._anglePosition = 0.0F;
/*      */         
/* 3016 */         byte b4 = 0;
/*      */         
/* 3018 */         float f2 = 0.0F;
/*      */         
/* 3020 */         while (this._anglePosition < 360.0F) {
/*      */           
/* 3022 */           float f3 = countCells(this._angleBetweenDiagram, b1);
/*      */ 
/*      */ 
/*      */           
/* 3026 */           resultsTable.incrementCounter();
/*      */           
/* 3028 */           resultsTable.addValue(0, Double.valueOf(this._anglePosition).doubleValue());
/*      */           
/* 3030 */           resultsTable.addValue(1, Double.valueOf(f3).doubleValue());
/*      */           
/* 3032 */           arrayOfFloat[b4] = f3;
/*      */           
/* 3034 */           if (f3 > f2)
/*      */           {
/* 3036 */             f2 = f3;
/*      */           }
/* 3038 */           this._anglePosition++;
/*      */           
/* 3040 */           b4++;
/*      */         } 
/*      */ 
/*      */         
/* 3044 */         this._anglePosition = f1;
/*      */ 
/*      */ 
/*      */         
/* 3048 */         arrayList.add(arrayOfFloat);
/*      */         
/* 3050 */         arrayList1.add(new Float(f2));
/*      */ 
/*      */ 
/*      */         
/* 3054 */         if (f2 > f)
/*      */         {
/* 3056 */           f = f2;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3062 */       if (this.gui.openDiagramBox.isSelected())
/*      */       {
/* 3064 */         this._currentOpenDiagrams.clear();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3070 */       for (byte b2 = 0; b2 < arrayList.size(); b2++) {
/*      */         PlotWindow plotWindow;
/* 3072 */         String str = (String)this._hashCurrentDataset.get(new Integer(b2));
/*      */         
/* 3074 */         float[] arrayOfFloat1 = arrayList.get(b2);
/*      */ 
/*      */ 
/*      */         
/* 3078 */         byte b3 = 100;
/*      */         
/* 3080 */         float f1 = b3 + (f + 1.0F) * 3.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3086 */         float[] arrayOfFloat2 = new float[1];
/*      */         
/* 3088 */         Plot plot = new Plot("Chemotaxis Diagram", "", 
/*      */             
/* 3090 */             "", arrayOfFloat2, arrayOfFloat2);
/*      */         
/* 3092 */         plot.setLimits(-f1, f1, -f1, f1);
/*      */         
/* 3094 */         float[] arrayOfFloat3 = new float[1];
/*      */         
/* 3096 */         float[] arrayOfFloat4 = new float[1];
/*      */         
/* 3098 */         plot.setLineWidth(2);
/*      */         
/* 3100 */         plot.addPoints(arrayOfFloat3, arrayOfFloat4, 5);
/*      */         
/* 3102 */         if (this.gui.showAdditionalInfoDiagram.isSelected())
/*      */         {
/* 3104 */           plot.addLabel(0.0D, 0.0D, "Max counts: " + (Float)arrayList1.get(b2) + " Interior Angle: " + this._angleBetweenDiagram + " [deg]");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3110 */         float[] arrayOfFloat5 = new float[360];
/*      */         
/* 3112 */         float[] arrayOfFloat6 = new float[360];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3120 */         for (byte b4 = 0; b4 < 'Ũ'; b4++) {
/*      */           
/* 3122 */           arrayOfFloat5[b4] = (new Double(Math.cos(Math.toRadians(b4)) * 
/*      */               
/* 3124 */               b3)).floatValue();
/*      */           
/* 3126 */           arrayOfFloat6[b4] = (new Double(Math.sin(Math.toRadians(b4)) * 
/*      */               
/* 3128 */               b3)).floatValue();
/*      */         } 
/*      */ 
/*      */         
/* 3132 */         plot.addPoints(arrayOfFloat5, arrayOfFloat6, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3138 */         plot.setColor(Color.blue);
/*      */         
/* 3140 */         plot.setLineWidth(2);
/*      */         
/* 3142 */         for (byte b5 = 0; b5 < 'Ũ'; b5++) {
/*      */           
/* 3144 */           byte b6 = 0;
/*      */           
/* 3146 */           for (byte b7 = 0; b7 < (new Float(arrayOfFloat1[b5])).intValue(); b7++) {
/*      */             
/* 3148 */             float[] arrayOfFloat7 = { (new Double(Math.cos(Math.toRadians(b5)) * (
/*      */                   
/* 3150 */                   b3 + 4 + b7 + b6))).floatValue() };
/*      */             
/* 3152 */             float[] arrayOfFloat8 = { (new Double(Math.sin(Math.toRadians(b5)) * (
/*      */                   
/* 3154 */                   b3 + 4 + b7 + b6))).floatValue() };
/*      */             
/* 3156 */             b6 += 2;
/*      */             
/* 3158 */             if (arrayOfFloat1[b5] == ((Float)arrayList1.get(b2)).floatValue()) {
/*      */               
/* 3160 */               plot.setColor(Color.red);
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 3166 */               plot.setColor(Color.blue);
/*      */             } 
/*      */ 
/*      */             
/* 3170 */             plot.addPoints(arrayOfFloat7, arrayOfFloat8, 6);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3182 */         if (this._currentOpenDiagrams.size() < this._listArrayList.size() / 2) {
/*      */           
/* 3184 */           plotWindow = plot.show();
/*      */           
/* 3186 */           this._currentOpenDiagrams.add(plotWindow);
/*      */           
/* 3188 */           plotWindow.addWindowListener(this);
/*      */           
/* 3190 */           plotWindow.setResizable(false);
/*      */         }
/*      */         else {
/*      */           
/* 3194 */           plotWindow = this._currentOpenDiagrams.get(b2);
/*      */           
/* 3196 */           plotWindow.drawPlot(plot);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3202 */         plotWindow.setTitle("Circular plot for " + str);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3208 */         if (this.gui.showDataTablesBox.isSelected())
/*      */         {
/* 3210 */           resultsTable.show("Circular plot for " + str);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3218 */     if (paramActionEvent.getSource() == this.gui.butShowOriginalDataset) {
/*      */       
/* 3220 */       String str = (String)this.gui.importedDataset.getSelectedItem();
/*      */       
/* 3222 */       Integer integer = (Integer)this._hashImportedDataset.get(str);
/*      */       
/* 3224 */       int i = integer.intValue();
/*      */ 
/*      */ 
/*      */       
/* 3228 */       ResultsTable resultsTable = new ResultsTable();
/*      */       
/* 3230 */       String[] arrayOfString = { "Track n", "Slice n", "X", "Y" };
/*      */       
/* 3232 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */       {
/* 3234 */         resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3240 */       ArrayList arrayList = this._importedData.get(i - 1);
/*      */       
/* 3242 */       for (byte b2 = 0; b2 < arrayList.size(); b2 += 4) {
/*      */         
/* 3244 */         resultsTable.incrementCounter();
/*      */         
/* 3246 */         resultsTable.addValue(0, ((Float)arrayList.get(b2)).doubleValue());
/*      */         
/* 3248 */         resultsTable.addValue(1, ((Float)arrayList.get(b2 + 1)).doubleValue());
/*      */         
/* 3250 */         resultsTable.addValue(2, ((Float)arrayList.get(b2 + 2)).doubleValue());
/*      */         
/* 3252 */         resultsTable.addValue(3, ((Float)arrayList.get(b2 + 3)).doubleValue());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3258 */       resultsTable.show("Original data for " + str);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3264 */     if (paramActionEvent.getSource() == this.gui.butshowcurrentData) {
/*      */       
/* 3266 */       String str = (String)this.gui.importedDataset.getSelectedItem();
/*      */       
/* 3268 */       if (this._hashCurrentDataset.contains(str)) {
/*      */ 
/*      */ 
/*      */         
/* 3272 */         int i = ((Integer)this._hashCurrentPosition.get(str)).intValue();
/*      */         
/* 3274 */         ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(i));
/*      */         
/* 3276 */         i *= 2;
/*      */         
/* 3278 */         int j = 0;
/*      */         
/* 3280 */         int k = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */         
/* 3284 */         float[][] arrayOfFloat1 = this._listArrayList.get(i);
/*      */         
/* 3286 */         float[][] arrayOfFloat2 = this._listArrayList.get(i + 1);
/*      */ 
/*      */ 
/*      */         
/* 3290 */         ResultsTable resultsTable = new ResultsTable();
/*      */         
/* 3292 */         String[] arrayOfString = { "Track n", "Slice n", "X [" + this._unitsPath + "]", "Y [" + this._unitsPath + "]" };
/*      */         
/* 3294 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */         {
/* 3296 */           resultsTable.setHeading(b1, arrayOfString[b1]);
/*      */         }
/*      */ 
/*      */         
/* 3300 */         for (byte b2 = 0; b2 < k; b2++) {
/*      */           
/* 3302 */           j = ((Integer)arrayList.get(b2)).intValue();
/*      */           
/* 3304 */           for (byte b = 0; b < j; b++) {
/*      */             
/* 3306 */             resultsTable.incrementCounter();
/*      */             
/* 3308 */             resultsTable.addValue(0, (new Integer(b2 + 1)).doubleValue());
/*      */             
/* 3310 */             resultsTable.addValue(1, (new Integer(b + 1)).doubleValue());
/*      */             
/* 3312 */             resultsTable.addValue(2, (new Float(arrayOfFloat1[b2][b])).doubleValue());
/*      */             
/* 3314 */             resultsTable.addValue(3, (new Float(arrayOfFloat2[b2][b])).doubleValue());
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 3320 */         resultsTable.show("Current used data for " + str);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 3326 */         JOptionPane.showMessageDialog(this.gui, "No current data available!");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3338 */     if (paramActionEvent.getSource() == this.gui.butaddDataset) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3344 */       boolean bool = true;
/*      */ 
/*      */ 
/*      */       
/* 3348 */       String str = (String)this.gui.importedDataset.getSelectedItem();
/*      */ 
/*      */ 
/*      */       
/* 3352 */       if (this._hashSlicesImported.containsKey(str)) {
/*      */ 
/*      */ 
/*      */         
/* 3356 */         if (this.gui.numberofSlicesType.getSelectedItem().equals("Use only slices equal to")) {
/*      */           ArrayList arrayList;
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 3362 */             arrayList = (ArrayList)this._hashSlicesImported.get(str);
/*      */             
/* 3364 */             if (arrayList.size() == 1)
/*      */             {
/* 3366 */               if (Integer.valueOf(this.gui.firstSlicesField.getText()) != (Integer)arrayList.get(0))
/*      */               {
/* 3368 */                 this._hashSlicesImported.remove(str);
/*      */                 
/* 3370 */                 arrayList = new ArrayList();
/*      */                 
/* 3372 */                 arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */                 
/* 3374 */                 this._hashSlicesImported.put(str, arrayList);
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 3384 */           catch (NumberFormatException numberFormatException) {
/*      */             
/* 3386 */             arrayList = (ArrayList)this._hashSlicesImported.get(str);
/*      */             
/* 3388 */             JOptionPane.showMessageDialog(this.gui, "Setting old value!");
/*      */             
/* 3390 */             this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3398 */           if (arrayList.size() == 2) {
/*      */             try
/*      */             {
/*      */               
/* 3402 */               arrayList = new ArrayList();
/*      */               
/* 3404 */               this._hashSlicesImported.remove(str);
/*      */               
/* 3406 */               arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */               
/* 3408 */               this._hashSlicesImported.put(str, arrayList);
/*      */ 
/*      */             
/*      */             }
/* 3412 */             catch (NumberFormatException numberFormatException)
/*      */             {
/* 3414 */               this.gui.firstSlicesField.setText("0");
/*      */               
/* 3416 */               this.gui.secondSlicesField.setText("");
/*      */               
/* 3418 */               arrayList.add(new Integer(0));
/*      */               
/* 3420 */               this._hashSlicesImported.put(str, arrayList);
/*      */               
/* 3422 */               JOptionPane.showMessageDialog(this.gui, "Please enter correct value for number of slices!");
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 3436 */           ArrayList arrayList = (ArrayList)this._hashSlicesImported.get(str);
/*      */ 
/*      */ 
/*      */           
/* 3440 */           if (arrayList.size() == 1) {
/*      */             
/*      */             try {
/*      */               
/* 3444 */               arrayList = new ArrayList();
/*      */               
/* 3446 */               this._hashSlicesImported.remove(str);
/*      */               
/* 3448 */               arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */               
/* 3450 */               arrayList.add(Integer.valueOf(this.gui.secondSlicesField.getText()));
/*      */               
/* 3452 */               if (Integer.valueOf(this.gui.secondSlicesField.getText()).intValue() < Integer.valueOf(this.gui.firstSlicesField.getText()).intValue())
/*      */               {
/* 3454 */                 JOptionPane.showMessageDialog(this.gui, "Second value can`t be smaller than the first");
/*      */               
/*      */               }
/*      */               else
/*      */               {
/*      */                 
/* 3460 */                 this._hashSlicesImported.put(str, arrayList);
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/* 3466 */             catch (NumberFormatException numberFormatException) {
/*      */               
/* 3468 */               this.gui.firstSlicesField.setText("0");
/*      */               
/* 3470 */               this.gui.secondSlicesField.setText("0");
/*      */               
/* 3472 */               arrayList.add(new Integer(0));
/*      */               
/* 3474 */               arrayList.add(new Integer(0));
/*      */               
/* 3476 */               this._hashSlicesImported.put(str, arrayList);
/*      */               
/* 3478 */               JOptionPane.showMessageDialog(this.gui, "Please enter correct value for number of slices!");
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3488 */           if (arrayList.size() == 2) {
/*      */             
/*      */             try {
/*      */               
/* 3492 */               if (Integer.valueOf(this.gui.firstSlicesField.getText()) != (Integer)arrayList.get(0) || Integer.valueOf(this.gui.secondSlicesField.getText()) != (Integer)arrayList.get(1))
/*      */               {
/* 3494 */                 this._hashSlicesImported.remove(str);
/*      */                 
/* 3496 */                 arrayList = new ArrayList();
/*      */                 
/* 3498 */                 arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */                 
/* 3500 */                 arrayList.add(Integer.valueOf(this.gui.secondSlicesField.getText()));
/*      */                 
/* 3502 */                 if (Integer.valueOf(this.gui.secondSlicesField.getText()).intValue() < Integer.valueOf(this.gui.firstSlicesField.getText()).intValue())
/*      */                 {
/* 3504 */                   JOptionPane.showMessageDialog(this.gui, "Second value can`t be smaller than the first");
/*      */                 
/*      */                 }
/*      */                 else
/*      */                 {
/*      */                   
/* 3510 */                   this._hashSlicesImported.put(str, arrayList);
/*      */ 
/*      */                 
/*      */                 }
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/* 3520 */             catch (NumberFormatException numberFormatException) {
/*      */               
/* 3522 */               arrayList = (ArrayList)this._hashSlicesImported.get(str);
/*      */               
/* 3524 */               JOptionPane.showMessageDialog(this.gui, "Setting old values!");
/*      */               
/* 3526 */               this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(0))));
/*      */               
/* 3528 */               this.gui.firstSlicesField.setText(String.valueOf(String.valueOf(arrayList.get(1))));
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } else {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3544 */           if (this.gui.numberofSlicesType.getSelectedItem().equals("Use only slices equal to"))
/*      */           {
/* 3546 */             ArrayList arrayList = new ArrayList();
/*      */             
/* 3548 */             arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */             
/* 3550 */             if (Integer.valueOf(this.gui.firstSlicesField.getText()).intValue() < 0)
/*      */             {
/* 3552 */               bool = false;
/*      */               
/* 3554 */               JOptionPane.showMessageDialog(this.gui, "value can`t be less than 0");
/*      */             
/*      */             }
/*      */             else
/*      */             {
/*      */               
/* 3560 */               this._hashSlicesImported.put(str, arrayList);
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 3568 */             ArrayList arrayList = new ArrayList();
/*      */             
/* 3570 */             arrayList.add(Integer.valueOf(this.gui.firstSlicesField.getText()));
/*      */             
/* 3572 */             arrayList.add(Integer.valueOf(this.gui.secondSlicesField.getText()));
/*      */             
/* 3574 */             if (Integer.valueOf(this.gui.secondSlicesField.getText()).intValue() < Integer.valueOf(this.gui.firstSlicesField.getText()).intValue())
/*      */             {
/* 3576 */               bool = false;
/*      */               
/* 3578 */               JOptionPane.showMessageDialog(this.gui, "Second value can`t be smaller than the first");
/*      */             
/*      */             }
/*      */             else
/*      */             {
/*      */               
/* 3584 */               this._hashSlicesImported.put(str, arrayList);
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 3592 */         catch (NumberFormatException numberFormatException) {
/*      */           
/* 3594 */           bool = false;
/*      */           
/* 3596 */           JOptionPane.showMessageDialog(this.gui, "Please enter correct value for number of slices!");
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3604 */       if (bool)
/*      */       {
/* 3606 */         if (!this._selectedDatasets.contains(str)) {
/*      */           
/* 3608 */           this.gui.butCompute.setEnabled(true);
/*      */           
/* 3610 */           this._selectedDatasets.add(str);
/*      */           
/* 3612 */           this.gui.selectedDataset1.addItem(str);
/*      */           
/* 3614 */           this.gui.selectedDataset2.addItem(str);
/*      */           
/* 3616 */           this.gui.selectedDataset3.addItem(str);
/*      */           
/* 3618 */           this.gui.selectedDataset4.addItem(str);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3634 */     if (paramActionEvent.getSource() == this.gui.butCompute) {
/*      */       
/* 3636 */       boolean bool = true;
/*      */ 
/*      */ 
/*      */       
/* 3640 */       this._maxVector.clear();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3646 */       ArrayList arrayList = new ArrayList();
/*      */ 
/*      */ 
/*      */       
/* 3650 */       if (this.gui.selectedData1.isSelected()) {
/*      */         
/* 3652 */         String str = (String)this.gui.selectedDataset1.getSelectedItem();
/*      */         
/* 3654 */         if (!arrayList.contains(str))
/*      */         {
/* 3656 */           arrayList.add(str);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3662 */       if (this.gui.selectedData2.isSelected()) {
/*      */         
/* 3664 */         String str = (String)this.gui.selectedDataset2.getSelectedItem();
/*      */         
/* 3666 */         if (!arrayList.contains(str))
/*      */         {
/* 3668 */           arrayList.add(str);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3674 */       if (this.gui.selectedData3.isSelected()) {
/*      */         
/* 3676 */         String str = (String)this.gui.selectedDataset3.getSelectedItem();
/*      */         
/* 3678 */         if (!arrayList.contains(str))
/*      */         {
/* 3680 */           arrayList.add(str);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3686 */       if (this.gui.selectedData4.isSelected()) {
/*      */         
/* 3688 */         String str = (String)this.gui.selectedDataset4.getSelectedItem();
/*      */         
/* 3690 */         if (!arrayList.contains(str))
/*      */         {
/* 3692 */           arrayList.add(str);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3702 */       this._unitsPath = (String)this.gui.pathUnits.getSelectedItem();
/*      */       
/* 3704 */       this._unitsTime = (String)this.gui.timeUnits.getSelectedItem();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3710 */       int i = 0;
/*      */       
/* 3712 */       int j = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3718 */       byte b1 = 0;
/*      */       
/* 3720 */       double d1 = 0.0D;
/*      */       
/* 3722 */       double d2 = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3728 */       if (this.gui.thresholdPathBox.isSelected()) {
/*      */         
/* 3730 */         String str = (String)this.gui.pathSelection.getSelectedItem();
/*      */         
/* 3732 */         if (str.equals("less than"))
/*      */         {
/* 3734 */           b1 = 1;
/*      */         }
/*      */ 
/*      */         
/* 3738 */         if (str.equals("more than"))
/*      */         {
/* 3740 */           b1 = 2;
/*      */         }
/*      */ 
/*      */         
/* 3744 */         if (str.equals("between"))
/*      */         {
/* 3746 */           b1 = 3;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3756 */       byte b2 = 0;
/*      */       
/* 3758 */       double d3 = 0.0D;
/*      */       
/* 3760 */       double d4 = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3766 */       if (this.gui.thresholdVelocityBox.isSelected()) {
/*      */         
/* 3768 */         String str = (String)this.gui.velocitySelection.getSelectedItem();
/*      */         
/* 3770 */         if (str.equals("slower than"))
/*      */         {
/* 3772 */           b2 = 1;
/*      */         }
/*      */ 
/*      */         
/* 3776 */         if (str.equals("faster than"))
/*      */         {
/* 3778 */           b2 = 2;
/*      */         }
/*      */ 
/*      */         
/* 3782 */         if (str.equals("between"))
/*      */         {
/* 3784 */           b2 = 3;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 3798 */         if (this.gui.splitBox.isSelected()) {
/*      */           
/* 3800 */           i = (new Integer(this.gui.firstSplitField.getText())).intValue();
/*      */           
/* 3802 */           j = (new Integer(this.gui.secondSplitField.getText())).intValue();
/*      */           
/* 3804 */           if (i > j) {
/*      */             
/* 3806 */             bool = false;
/*      */             
/* 3808 */             JOptionPane.showMessageDialog(this.gui, "Second split position can't be greater than the first!");
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3814 */           for (byte b = 0; b < arrayList.size(); b++) {
/*      */             
/* 3816 */             String str = arrayList.get(b);
/*      */             
/* 3818 */             ArrayList arrayList1 = (ArrayList)this._hashSlicesImported.get(str);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3824 */             if (arrayList1.size() == 1) {
/*      */               
/* 3826 */               int k = ((Integer)arrayList1.get(0)).intValue();
/*      */               
/* 3828 */               if (i > k || j > k) {
/*      */                 
/* 3830 */                 bool = false;
/*      */                 
/* 3832 */                 JOptionPane.showMessageDialog(this.gui, "Split position can't be greater than number of slices in your datasets!");
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 3838 */             if (arrayList1.size() == 2) {
/*      */               
/* 3840 */               int k = ((Integer)arrayList1.get(0)).intValue();
/*      */               
/* 3842 */               int m = ((Integer)arrayList1.get(1)).intValue();
/*      */               
/* 3844 */               if (i > m || j > m) {
/*      */                 
/* 3846 */                 bool = false;
/*      */                 
/* 3848 */                 JOptionPane.showMessageDialog(this.gui, "Split position can't be greater than number of slices in your datasets!");
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3858 */           if (i < 1 || j < 1) {
/*      */             
/* 3860 */             bool = false;
/*      */             
/* 3862 */             JOptionPane.showMessageDialog(this.gui, "Split position can't take values < 1!");
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3872 */         if (this.gui.thresholdPathBox.isSelected()) {
/*      */           
/* 3874 */           if (b1 == 1 || b1 == 2)
/*      */           {
/* 3876 */             d1 = (new Double(this.gui.firstThresPathField.getText()))
/*      */               
/* 3878 */               .doubleValue();
/*      */           }
/*      */ 
/*      */           
/* 3882 */           if (b1 == 3) {
/*      */             
/* 3884 */             d1 = (new Double(this.gui.firstThresPathField.getText()))
/*      */               
/* 3886 */               .doubleValue();
/*      */             
/* 3888 */             d2 = (new Double(this.gui.secondThresPathField.getText()))
/*      */               
/* 3890 */               .doubleValue();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3900 */         if (this.gui.thresholdVelocityBox.isSelected()) {
/*      */           
/* 3902 */           if (b2 == 1 || b2 == 2)
/*      */           {
/* 3904 */             d3 = (new Double(this.gui.firstThresVelocityField.getText()))
/*      */               
/* 3906 */               .doubleValue();
/*      */           }
/*      */ 
/*      */           
/* 3910 */           if (b2 == 3) {
/*      */             
/* 3912 */             d3 = (new Double(this.gui.firstThresVelocityField.getText()))
/*      */               
/* 3914 */               .doubleValue();
/*      */             
/* 3916 */             d4 = (new Double(this.gui.secondThresVelocityField.getText()))
/*      */               
/* 3918 */               .doubleValue();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3928 */         if (!this.gui.selectedData1.isSelected() && !this.gui.selectedData2.isSelected() && !this.gui.selectedData3.isSelected() && !this.gui.selectedData4.isSelected())
/*      */         {
/* 3930 */           bool = false;
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 3936 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 3938 */         JOptionPane.showMessageDialog(this.gui, "Please enter correct values!");
/*      */         
/* 3940 */         bool = false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 3950 */         this._calxy = (new Float(this.gui.xyCalibrationField.getText())).floatValue();
/*      */       }
/* 3952 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 3954 */         JOptionPane.showMessageDialog(this.gui, "Please enter a correct value for Settings\\XY Calibration!");
/*      */         
/* 3956 */         bool = false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 3964 */         this._timeInterval = (new Double(this.gui.timeSettingsField.getText())).doubleValue();
/*      */         
/* 3966 */         if (this._timeInterval <= 0.0D)
/*      */         {
/* 3968 */           JOptionPane.showMessageDialog(this.gui, "Please enter a correct value for Settings\\Time interval!");
/*      */           
/* 3970 */           bool = false;
/*      */         }
/*      */       
/*      */       }
/* 3974 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 3976 */         JOptionPane.showMessageDialog(this.gui, "Please enter a correct value for Settings\\Time interval!");
/*      */         
/* 3978 */         bool = false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3988 */       if (bool) {
/*      */ 
/*      */ 
/*      */         
/* 3992 */         this.gui.plotClosed();
/*      */ 
/*      */ 
/*      */         
/* 3996 */         this._listArrayList.clear();
/*      */         
/* 3998 */         this._hashCurrentDataset.clear();
/*      */ 
/*      */ 
/*      */         
/* 4002 */         this._hashSliceNumber.clear();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4010 */         this.gui.statisticDataset.removeAllItems();
/*      */         
/* 4012 */         this.gui.extendedstatisticDataset.removeAllItems();
/*      */         
/* 4014 */         this.gui.plotAnimation.removeAllItems();
/*      */         
/* 4016 */         this.gui.velocityDataset.removeAllItems();
/*      */         
/* 4018 */         this.gui.sectorDataset.removeAllItems();
/*      */ 
/*      */ 
/*      */         
/* 4022 */         for (byte b3 = 0; b3 < arrayList.size(); b3++) {
/*      */           
/* 4024 */           this.gui.plotAnimation.addItem(arrayList.get(b3));
/*      */           
/* 4026 */           this.gui.statisticDataset.addItem(arrayList.get(b3));
/*      */           
/* 4028 */           this.gui.extendedstatisticDataset.addItem(arrayList.get(b3));
/*      */           
/* 4030 */           this.gui.velocityDataset.addItem(arrayList.get(b3));
/*      */           
/* 4032 */           this.gui.sectorDataset.addItem(arrayList.get(b3));
/*      */         } 
/*      */ 
/*      */         
/* 4036 */         if (arrayList.size() > 1)
/*      */         {
/* 4038 */           this.gui.sectorDataset.addItem("All datasets");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4046 */         for (byte b4 = 0; b4 < arrayList.size(); b4++) {
/*      */ 
/*      */ 
/*      */           
/* 4050 */           this._variableSliceNumber = new ArrayList();
/*      */           
/* 4052 */           int k = 0;
/*      */ 
/*      */ 
/*      */           
/* 4056 */           String str = arrayList.get(b4);
/*      */           
/* 4058 */           this._hashCurrentDataset.put(new Integer(b4), str);
/*      */           
/* 4060 */           this._hashCurrentPosition.put(str, new Integer(b4));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4066 */           ArrayList arrayList1 = (ArrayList)this._hashSlicesImported.get(str);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4072 */           Integer integer = (Integer)this._hashImportedDataset.get(str);
/*      */           
/* 4074 */           int m = integer.intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4080 */           ArrayList arrayList2 = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4086 */           ArrayList arrayList3 = new ArrayList();
/*      */           
/* 4088 */           ArrayList arrayList4 = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4096 */           ArrayList arrayList5 = this._importedData.get(m - 1);
/*      */           
/* 4098 */           for (byte b5 = 0; b5 < arrayList5.size(); b5 += 4) {
/*      */             
/* 4100 */             arrayList2.add(arrayList5.get(b5));
/*      */             
/* 4102 */             arrayList3.add(arrayList5.get(b5 + 2));
/*      */             
/* 4104 */             arrayList4.add(arrayList5.get(b5 + 3));
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4112 */           k = ((Float)arrayList2
/*      */             
/* 4114 */             .get(arrayList2.size() - 1)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4124 */           int[] arrayOfInt = new int[3 * k];
/*      */ 
/*      */ 
/*      */           
/* 4128 */           byte b6 = 1;
/*      */           
/* 4130 */           for (byte b7 = 0; b7 <= 3 * k - 3; b7 += 3) {
/*      */             
/* 4132 */             arrayOfInt[b7] = arrayList2.indexOf(new Float(
/*      */                   
/* 4134 */                   b6));
/*      */             
/* 4136 */             arrayOfInt[b7 + 1] = arrayList2
/*      */               
/* 4138 */               .lastIndexOf(new Float(b6));
/*      */             
/* 4140 */             arrayOfInt[b7 + 2] = b6;
/*      */             
/* 4142 */             b6++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4150 */           ArrayList arrayList6 = new ArrayList();
/*      */           
/* 4152 */           ArrayList arrayList7 = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4158 */           k = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4164 */           if (arrayList1.size() == 1) {
/*      */             
/* 4166 */             int i1 = ((Integer)arrayList1.get(0)).intValue();
/*      */             
/* 4168 */             for (byte b = 0; b <= arrayOfInt.length - 3; b += 3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4174 */               if (arrayOfInt[b + 1] != -1 && arrayOfInt[b] != -1)
/*      */               {
/* 4176 */                 if (arrayOfInt[b + 1] - arrayOfInt[b] == i1 - 1) {
/*      */                   
/* 4178 */                   k++;
/*      */                   
/* 4180 */                   this._variableSliceNumber.add(new Integer(arrayOfInt[b + 1] - arrayOfInt[b] + 1));
/*      */                   
/* 4182 */                   for (int i2 = arrayOfInt[b]; i2 <= arrayOfInt[b + 1]; i2++) {
/*      */ 
/*      */ 
/*      */                     
/* 4186 */                     arrayList6.add(new Float(((Float)arrayList3.get(i2)).floatValue() * this._calxy));
/*      */                     
/* 4188 */                     arrayList7.add(new Float(((Float)arrayList4.get(i2)).floatValue() * this._calxy));
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4204 */           if (arrayList1.size() == 2) {
/*      */             
/* 4206 */             int i1 = ((Integer)arrayList1.get(0)).intValue();
/*      */             
/* 4208 */             int i2 = ((Integer)arrayList1.get(1)).intValue();
/*      */             
/* 4210 */             for (byte b = 0; b <= arrayOfInt.length - 3; b += 3) {
/*      */ 
/*      */ 
/*      */               
/* 4214 */               if (arrayOfInt[b + 1] != -1 && arrayOfInt[b] != -1)
/*      */               {
/* 4216 */                 if (arrayOfInt[b + 1] - arrayOfInt[b] >= i1 - 1 && arrayOfInt[b + 1] - arrayOfInt[b] <= i2 - 1) {
/*      */                   
/* 4218 */                   k++;
/*      */                   
/* 4220 */                   this._variableSliceNumber.add(new Integer(arrayOfInt[b + 1] - arrayOfInt[b] + 1));
/*      */                   
/* 4222 */                   for (int i3 = arrayOfInt[b]; i3 <= arrayOfInt[b + 1]; i3++) {
/*      */ 
/*      */ 
/*      */                     
/* 4226 */                     arrayList6.add(new Float(((Float)arrayList3.get(i3)).floatValue() * this._calxy));
/*      */                     
/* 4228 */                     arrayList7.add(new Float(((Float)arrayList4.get(i3)).floatValue() * this._calxy));
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4246 */           updateNumberofTracks(str, k);
/*      */ 
/*      */ 
/*      */           
/* 4250 */           int n = 0;
/*      */           
/* 4252 */           if (this._variableSliceNumber.isEmpty()) {
/*      */ 
/*      */ 
/*      */             
/* 4256 */             if (arrayList1.size() == 1)
/*      */             {
/* 4258 */               JOptionPane.showMessageDialog(this.gui, "No tracks available for current number of slices");
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4264 */             if (arrayList1.size() == 2)
/*      */             {
/* 4266 */               JOptionPane.showMessageDialog(this.gui, "No tracks available for current range of used number of slices");
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/* 4278 */             n = ((Integer)Collections.<Integer>max(this._variableSliceNumber)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4286 */             if (this.gui.splitBox.isSelected()) {
/*      */               
/* 4288 */               int i1 = j - i - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4294 */               byte b8 = 0;
/*      */               
/* 4296 */               for (byte b9 = 0; b9 < k; b9++) {
/*      */                 
/* 4298 */                 if (((Integer)this._variableSliceNumber.get(b9)).intValue() >= i)
/*      */                 {
/* 4300 */                   b8++;
/*      */                 }
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4308 */               this.x_values = new float[b8][i1];
/*      */               
/* 4310 */               this.y_values = new float[b8][i1];
/*      */ 
/*      */ 
/*      */               
/* 4314 */               ArrayList arrayList8 = new ArrayList();
/*      */ 
/*      */ 
/*      */               
/* 4318 */               int i2 = 0;
/*      */               
/* 4320 */               b8 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4326 */               for (byte b10 = 0; b10 < k; b10++) {
/*      */ 
/*      */ 
/*      */                 
/* 4330 */                 boolean bool1 = false;
/*      */ 
/*      */ 
/*      */                 
/* 4334 */                 int i3 = ((Integer)this._variableSliceNumber.get(b10)).intValue();
/*      */                 
/* 4336 */                 if (i3 >= i && i3 < j) {
/*      */                   
/* 4338 */                   i3 -= i - 1;
/*      */                   
/* 4340 */                   arrayList8.add(new Integer(i3));
/*      */                   
/* 4342 */                   b8++;
/*      */                   
/* 4344 */                   bool1 = true;
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 4350 */                 if (i3 >= j) {
/*      */                   
/* 4352 */                   i3 = i1;
/*      */                   
/* 4354 */                   arrayList8.add(new Integer(i3));
/*      */                   
/* 4356 */                   b8++;
/*      */                   
/* 4358 */                   bool1 = true;
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 4364 */                 if (bool1) {
/*      */                   
/* 4366 */                   this.x_values[b8 - 1][0] = 0.0F;
/*      */                   
/* 4368 */                   this.y_values[b8 - 1][0] = 0.0F;
/*      */ 
/*      */ 
/*      */                   
/* 4372 */                   byte b = 1;
/*      */                   
/* 4374 */                   while (b < i3) {
/*      */                     
/* 4376 */                     float f1 = ((Float)arrayList6.get(b + i2 + i - 1)).floatValue() - (
/*      */                       
/* 4378 */                       (Float)arrayList6.get(i2 + i - 1)).floatValue();
/*      */                     
/* 4380 */                     float f2 = 
/*      */                       
/* 4382 */                       -(((Float)arrayList7.get(b + i2 + i - 1)).floatValue() - ((Float)arrayList7.get(i2 + i - 1)).floatValue());
/*      */                     
/* 4384 */                     this.x_values[b8 - 1][b] = f1;
/*      */                     
/* 4386 */                     this.y_values[b8 - 1][b] = f2;
/*      */                     
/* 4388 */                     b++;
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 4396 */                 i2 += ((Integer)this._variableSliceNumber.get(b10)).intValue();
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4404 */               updateNumberofTracks(str, b8);
/*      */               
/* 4406 */               this._variableSliceNumber = arrayList8;
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */ 
/*      */               
/* 4414 */               int i1 = 0;
/*      */               
/* 4416 */               int i2 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4422 */               this.x_values = new float[k][n];
/*      */               
/* 4424 */               this.y_values = new float[k][n];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4430 */               for (byte b = 0; b < k; b++) {
/*      */                 
/* 4432 */                 this.x_values[b][0] = 0.0F;
/*      */                 
/* 4434 */                 this.y_values[b][0] = 0.0F;
/*      */ 
/*      */ 
/*      */                 
/* 4438 */                 byte b8 = 1;
/*      */                 
/* 4440 */                 i1 = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */                 
/* 4442 */                 while (b8 < i1) {
/*      */                   
/* 4444 */                   float f1 = ((Float)arrayList6.get(b8 + i2)).floatValue() - (
/*      */                     
/* 4446 */                     (Float)arrayList6.get(i2)).floatValue();
/*      */                   
/* 4448 */                   float f2 = 
/*      */                     
/* 4450 */                     -(((Float)arrayList7.get(b8 + i2)).floatValue() - ((Float)arrayList7.get(i2)).floatValue());
/*      */                   
/* 4452 */                   this.x_values[b][b8] = f1;
/*      */                   
/* 4454 */                   this.y_values[b][b8] = f2;
/*      */                   
/* 4456 */                   b8++;
/*      */                 } 
/*      */ 
/*      */                 
/* 4460 */                 i2 += i1;
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4470 */             if (this.gui.thresholdPathBox.isSelected()) {
/*      */ 
/*      */ 
/*      */               
/* 4474 */               if (b1 == 1)
/*      */               {
/* 4476 */                 if (this.gui.euclideanDistance.isSelected()) {
/*      */                   
/* 4478 */                   thresholdFunctionPath(d1, 0.0D, "euclid", 1, str);
/*      */                 }
/*      */                 else {
/*      */                   
/* 4482 */                   thresholdFunctionPath(d1, 0.0D, "accumulated", 1, str);
/*      */                 } 
/*      */               }
/*      */ 
/*      */ 
/*      */               
/* 4488 */               if (b1 == 2)
/*      */               {
/* 4490 */                 if (this.gui.euclideanDistance.isSelected()) {
/*      */                   
/* 4492 */                   thresholdFunctionPath(d1, 0.0D, "euclid", 2, str);
/*      */                 }
/*      */                 else {
/*      */                   
/* 4496 */                   thresholdFunctionPath(d1, 0.0D, "accumulated", 2, str);
/*      */                 } 
/*      */               }
/*      */ 
/*      */ 
/*      */               
/* 4502 */               if (b1 == 3)
/*      */               {
/* 4504 */                 if (this.gui.euclideanDistance.isSelected()) {
/*      */                   
/* 4506 */                   thresholdFunctionPath(d1, d2, "euclid", 3, str);
/*      */                 }
/*      */                 else {
/*      */                   
/* 4510 */                   thresholdFunctionPath(d1, d2, "accumulated", 3, str);
/*      */                 } 
/*      */               }
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4520 */             if (this.gui.thresholdVelocityBox.isSelected()) {
/*      */               
/* 4522 */               if (b2 == 1)
/*      */               {
/* 4524 */                 thresholdFunctionVelocity(d3, 0.0D, 1, str);
/*      */               }
/* 4526 */               if (b2 == 2)
/*      */               {
/* 4528 */                 thresholdFunctionVelocity(d3, 0.0D, 2, str);
/*      */               }
/* 4530 */               if (b2 == 3)
/*      */               {
/* 4532 */                 thresholdFunctionVelocity(d3, d4, 3, str);
/*      */               }
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4540 */             this._listArrayList.add(this.x_values);
/*      */             
/* 4542 */             this._listArrayList.add(this.y_values);
/*      */             
/* 4544 */             this._hashSliceNumber.put(new Integer(b4), this._variableSliceNumber);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4550 */           this.gui.valuesComputed(this._angleBetweenDiagram);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4558 */     if (paramActionEvent.getSource() == this.gui.butsetAxisScaling) {
/* 4559 */       this._dialog.setTitle("Set axis scaling [" + this._unitsPath + "]:");
/* 4560 */       int i = this.gui.getX() + (this.gui.getWidth() - this._dialog.getWidth()) / 2;
/* 4561 */       int j = this.gui.getY() + (this.gui.getHeight() - this._dialog.getHeight()) / 2;
/* 4562 */       this._dialog.setLocation(i, j);
/*      */       
/* 4564 */       this._dialog.setVisible(true);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4569 */     if (paramActionEvent.getSource() == this.gui.butplotGraph) {
/*      */ 
/*      */ 
/*      */       
/* 4573 */       this._hashPlot.clear();
/*      */       
/* 4575 */       byte b1 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4581 */       String str = (String)this.gui.plotSelection.getSelectedItem();
/*      */       
/* 4583 */       if (str.equals("Mark more/less accumulated"))
/*      */       {
/* 4585 */         b1 = 1;
/*      */       }
/*      */ 
/*      */       
/* 4589 */       if (str.equals("Mark faster/slower"))
/*      */       {
/* 4591 */         b1 = 2;
/*      */       }
/*      */ 
/*      */       
/* 4595 */       if (str.equals("Mark up/down"))
/*      */       {
/* 4597 */         b1 = 3;
/*      */       }
/*      */ 
/*      */       
/* 4601 */       if (str.equals("Mark left/right"))
/*      */       {
/* 4603 */         b1 = 4;
/*      */       }
/*      */ 
/*      */       
/* 4607 */       if (str.equals("Mark more/less euclid"))
/*      */       {
/* 4609 */         b1 = 5;
/*      */       }
/*      */ 
/*      */       
/* 4613 */       if (str.equals("No marking"))
/*      */       {
/* 4615 */         b1 = 6;
/*      */       }
/*      */ 
/*      */       
/* 4619 */       if (str.equals("Mark directionality"))
/*      */       {
/* 4621 */         b1 = 7;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4628 */       if (this._dialog.auto) {
/*      */         
/* 4630 */         float f1 = 0.0F;
/*      */         
/* 4632 */         float f2 = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4638 */         if (this._listArrayList.size() > 1) {
/*      */ 
/*      */ 
/*      */           
/* 4642 */           ArrayList arrayList = new ArrayList();
/*      */           
/* 4644 */           for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */             
/* 4646 */             String str1 = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */             
/* 4648 */             int i = ((Integer)this._hashTracks.get(str1)).intValue();
/*      */             
/* 4650 */             ArrayList arrayList1 = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */ 
/*      */ 
/*      */             
/* 4654 */             float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */             
/* 4656 */             float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4664 */             int j = 0;
/*      */             
/* 4666 */             for (byte b3 = 0; b3 < i; b3++) {
/*      */               
/* 4668 */               j = ((Integer)arrayList1.get(b3)).intValue();
/*      */               
/* 4670 */               for (byte b4 = 1; b4 < j; b4++) {
/*      */                 
/* 4672 */                 if (f1 < Math.abs(arrayOfFloat1[b3][b4]))
/*      */                 {
/* 4674 */                   f1 = Math.abs(arrayOfFloat1[b3][b4]);
/*      */                 }
/* 4676 */                 if (f2 < Math.abs(arrayOfFloat2[b3][b4]))
/*      */                 {
/* 4678 */                   f2 = Math.abs(arrayOfFloat2[b3][b4]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/* 4684 */             if (f1 > f2) {
/*      */               
/* 4686 */               arrayList.add(new Float(f1));
/*      */             }
/*      */             else {
/*      */               
/* 4690 */               arrayList.add(new Float(f2));
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 4696 */           this._coordSize = ((Float)Collections.<Float>max(arrayList)).floatValue() + 5.0F;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4708 */       if (this.gui.openNewPlotBox.isSelected())
/*      */       {
/* 4710 */         this._currentOpenWindows.clear();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4718 */       for (byte b2 = 0; b2 < this._listArrayList.size(); b2 += 2)
/*      */       {
/* 4720 */         plotGraph(b1, b2);
/*      */       }
/*      */ 
/*      */       
/* 4724 */       this.gui.plotGraphClicked();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4734 */     if (paramActionEvent.getSource() == this.gui.butanimateGraph)
/*      */     {
/* 4736 */       showAnimatedGraph();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4744 */     if (paramActionEvent.getSource() == this.gui.butshowDatasetInformation)
/*      */     {
/* 4746 */       datasetNotes();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateNumberofTracks(String paramString, int paramInt) {
/* 4756 */     if (this._hashTracks.containsKey(paramString)) {
/*      */       
/* 4758 */       this._hashTracks.remove(paramString);
/*      */       
/* 4760 */       this._hashTracks.put(paramString, new Integer(paramInt));
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 4766 */       this._hashTracks.put(paramString, new Integer(paramInt));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void getangleInteriorDiagramField() {
/* 4778 */     String str = this.gui.angleInteriorDiagramField.getText();
/*      */ 
/*      */     
/*      */     try {
/* 4782 */       this._angleBetweenDiagram = Float.valueOf(str).floatValue();
/*      */       
/* 4784 */       if (this._angleBetweenDiagram > 180.0F) {
/*      */         
/* 4786 */         this._angleBetweenDiagram = 180.0F;
/*      */         
/* 4788 */         this.gui.angleInteriorDiagramField.setText(String.valueOf(this._angleBetweenDiagram));
/*      */       } 
/*      */ 
/*      */       
/* 4792 */       if (this._angleBetweenDiagram < 1.0F)
/*      */       {
/* 4794 */         this._angleBetweenDiagram = 1.0F;
/*      */         
/* 4796 */         this.gui.angleInteriorDiagramField.setText(String.valueOf(this._angleBetweenDiagram));
/*      */       }
/*      */     
/*      */     }
/* 4800 */     catch (NumberFormatException numberFormatException) {
/*      */       
/* 4802 */       JOptionPane.showMessageDialog(this.gui, "Setting default!");
/*      */       
/* 4804 */       this._angleBetweenDiagram = 66.0F;
/*      */       
/* 4806 */       this.gui.angleInteriorDiagramField.setText(String.valueOf(this._angleBetweenDiagram));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void datasetNotes() {
/* 4818 */     boolean bool1 = false;
/*      */     
/* 4820 */     boolean bool2 = false;
/*      */     
/* 4822 */     for (byte b = 0; b < this._listArrayList.size(); b += 2) {
/*      */       
/* 4824 */       String str1 = (String)this._hashCurrentDataset.get(new Integer(b / 2));
/*      */       
/* 4826 */       ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(b / 2));
/*      */       
/* 4828 */       ArrayList arrayList1 = (ArrayList)this._hashSlicesImported.get(str1);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4833 */       int i = ((Integer)Collections.<Integer>max(arrayList)).intValue();
/*      */ 
/*      */ 
/*      */       
/* 4837 */       String str2 = "";
/*      */       
/* 4839 */       if (arrayList1.size() == 1)
/*      */       {
/* 4841 */         str2 = "equal to " + arrayList1.get(0);
/*      */       }
/*      */ 
/*      */       
/* 4845 */       if (arrayList1.size() == 2)
/*      */       {
/* 4847 */         str2 = "from " + arrayList1.get(0) + " to " + arrayList1.get(1);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4853 */       int j = ((Integer)this._hashTracks.get(str1)).intValue();
/*      */ 
/*      */       
/* 4856 */       float[][] arrayOfFloat1 = this._listArrayList.get(b);
/*      */       
/* 4858 */       float[][] arrayOfFloat2 = this._listArrayList.get(b + 1);
/*      */ 
/*      */ 
/*      */       
/* 4862 */       JFrame jFrame = new JFrame("Values for " + str1);
/*      */       
/* 4864 */       this._openInfoWindows.add(jFrame);
/*      */       
/* 4866 */       jFrame.addWindowListener(this);
/*      */       
/* 4868 */       jFrame.setLayout(new BorderLayout());
/*      */       
/* 4870 */       JTextPane jTextPane = new JTextPane();
/*      */       
/* 4872 */       jTextPane.setEditable(false);
/*      */       
/* 4874 */       jTextPane.setBackground(new Color(235, 235, 228));
/*      */       
/* 4876 */       jTextPane.setSize(300, 500);
/*      */ 
/*      */ 
/*      */       
/* 4880 */       double[] arrayOfDouble1 = ChemotaxisStatistic.computeVariables("accumulated distance", arrayOfFloat1, arrayOfFloat2, arrayList, j, this._timeInterval);
/*      */       
/* 4882 */       double[] arrayOfDouble2 = ChemotaxisStatistic.computeVariables("euclid distance", arrayOfFloat1, arrayOfFloat2, arrayList, j, this._timeInterval);
/*      */       
/* 4884 */       double[] arrayOfDouble3 = ChemotaxisStatistic.computeVariables("velocity", arrayOfFloat1, arrayOfFloat2, arrayList, j, this._timeInterval);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4890 */       double d1 = 0.0D;
/*      */       
/* 4892 */       double d2 = 0.0D;
/*      */       
/* 4894 */       double d3 = 0.0D;
/*      */ 
/*      */ 
/*      */       
/* 4898 */       int k = 0;
/*      */       
/* 4900 */       for (byte b1 = 0; b1 < j; b1++) {
/*      */         
/* 4902 */         k = ((Integer)arrayList.get(b1)).intValue();
/*      */         
/* 4904 */         d1 += arrayOfFloat1[b1][k - 1];
/*      */         
/* 4906 */         d2 += arrayOfFloat2[b1][k - 1];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4912 */       if (j != 0) {
/*      */         
/* 4914 */         d1 /= j;
/*      */         
/* 4916 */         d2 /= j;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4922 */       d3 = Point2D.distance(0.0D, 0.0D, d1, d2);
/*      */       
/* 4924 */       d3 = roundDoubleNumbers(d3);
/*      */       
/* 4926 */       d1 = roundDoubleNumbers(d1);
/*      */       
/* 4928 */       d2 = roundDoubleNumbers(d2);
/*      */ 
/*      */ 
/*      */       
/* 4932 */       Font font = new Font("Helvetica", 0, 15);
/*      */       
/* 4934 */       jTextPane.setFont(font);
/*      */       
/* 4936 */       jTextPane.setContentType("text/html");
/*      */ 
/*      */ 
/*      */       
/* 4940 */       jTextPane.setText("<b>Slice length in dataset:</b>&nbsp;" + str2 + "<br>" + 
/*      */           
/* 4942 */           "<b>Number of current used tracks:</b>&nbsp;" + j + "<br><br>" + 
/*      */           
/* 4944 */           "<b>x Forward migration index:</b>&nbsp;" + ChemotaxisStatistic.computeFMIIndex(arrayOfFloat1, arrayOfFloat2, i, j, 2, arrayList) + "<br>" + 
/*      */           
/* 4946 */           "<b>y Forward migration index:</b>&nbsp;" + ChemotaxisStatistic.computeFMIIndex(arrayOfFloat1, arrayOfFloat2, i, j, 1, arrayList) + "<br>" + 
/*      */           
/* 4948 */           "<b>Directionality:</b>&nbsp;" + ChemotaxisStatistic.computeChemotaxisIndex(arrayOfFloat1, arrayOfFloat2, i, j, arrayList) + "<br><br>" + 
/*      */           
/* 4950 */           "<b>Center of mass</b><br>" + 
/*      */           
/* 4952 */           "<b>x:</b>&nbsp;" + d1 + " [" + this._unitsPath + "]" + "<br>" + 
/*      */           
/* 4954 */           "<b>y:</b>&nbsp;" + d2 + " [" + this._unitsPath + "]" + "<br>" + 
/*      */           
/* 4956 */           "<b>Length:</b>&nbsp;" + d3 + " [" + this._unitsPath + "]" + "<br><br>" + 
/*      */           
/* 4958 */           "<b>Accumulated distance</b><br>" + 
/*      */           
/* 4960 */           "<b>Max Distance:</b>&nbsp;&nbsp;" + arrayOfDouble1[0] + " [" + this._unitsPath + "]<br>" + 
/*      */           
/* 4962 */           "<b>Min Distance:</b>&nbsp;&nbsp;" + arrayOfDouble1[1] + " [" + this._unitsPath + "]<br>" + 
/*      */           
/* 4964 */           "<b>Mean Distance:</b>&nbsp;" + arrayOfDouble1[2] + " [" + this._unitsPath + "]" + "<b>  SD:</b>&nbsp;" + arrayOfDouble1[3] + " [" + this._unitsPath + "]" + "<br><br>" + 
/*      */           
/* 4966 */           "<b>Euclidean distance</b><br>" + 
/*      */           
/* 4968 */           "<b>Max Distance:</b>&nbsp;&nbsp;" + arrayOfDouble2[0] + " [" + this._unitsPath + "]<br>" + 
/*      */           
/* 4970 */           "<b>Min Distance:</b>&nbsp;&nbsp;" + arrayOfDouble2[1] + " [" + this._unitsPath + "]<br>" + 
/*      */           
/* 4972 */           "<b>Mean Distance:</b>&nbsp;" + arrayOfDouble2[2] + " [" + this._unitsPath + "]" + "<b>  SD:</b>&nbsp;" + arrayOfDouble2[3] + " [" + this._unitsPath + "]" + "<br><br>" + 
/*      */           
/* 4974 */           "<b>Velocity</b><br>" + 
/*      */           
/* 4976 */           "<b>Max Velocity:</b>&nbsp;&nbsp;" + arrayOfDouble3[0] + " [" + this._unitsPath + "/" + this._unitsTime + "]<br>" + 
/*      */           
/* 4978 */           "<b>Min Velocity:</b>&nbsp;&nbsp;" + arrayOfDouble3[1] + " [" + this._unitsPath + "/" + this._unitsTime + "]<br>" + 
/*      */           
/* 4980 */           "<b>Mean Velocity:</b>&nbsp;" + arrayOfDouble3[2] + " [" + this._unitsPath + "/" + this._unitsTime + "]" + "<b>  SD:</b>&nbsp;" + arrayOfDouble3[3] + " [" + this._unitsPath + "]" + "<br><br>");
/*      */ 
/*      */ 
/*      */       
/* 4984 */       JScrollPane jScrollPane = new JScrollPane(jTextPane);
/*      */       
/* 4986 */       jFrame.add(jScrollPane, "Center");
/*      */       
/* 4988 */       jFrame.setSize(330, 400);
/*      */       
/* 4990 */       jFrame.setLocation(bool1, bool2);
/*      */       
/* 4992 */       jFrame.setVisible(true);
/*      */ 
/*      */ 
/*      */       
/* 4996 */       bool1 += true;
/*      */       
/* 4998 */       bool2 += true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readData(String paramString1, String paramString2) throws FileNotFoundException, IOException {
/* 5008 */     BufferedReader bufferedReader = new BufferedReader(new FileReader(paramString1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5014 */     String str = bufferedReader.readLine();
/*      */ 
/*      */ 
/*      */     
/* 5018 */     ArrayList arrayList = new ArrayList();
/*      */     
/* 5020 */     while ((str = bufferedReader.readLine()) != null) {
/*      */       
/* 5022 */       String[] arrayOfString = str.split("\t");
/*      */       
/* 5024 */       arrayList.add(new Float(arrayOfString[1]));
/*      */       
/* 5026 */       arrayList.add(new Float(arrayOfString[2]));
/*      */       
/* 5028 */       arrayList.add(new Float(arrayOfString[3]));
/*      */       
/* 5030 */       arrayList.add(new Float(arrayOfString[4]));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5036 */     this._importedData.add(arrayList);
/*      */ 
/*      */ 
/*      */     
/* 5040 */     IJ.showStatus("Dataset imported");
/*      */     
/* 5042 */     paramString2 = this._importedData.size() + ": " + paramString2;
/*      */     
/* 5044 */     this._hashImportedDataset.put(paramString2, new Integer(this._importedData.size()));
/*      */     
/* 5046 */     this.gui.datasetImported(paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int countCells(float paramFloat, int paramInt) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _hashCurrentDataset : Ljava/util/Hashtable;
/*      */     //   4: new java/lang/Integer
/*      */     //   7: dup
/*      */     //   8: iload_2
/*      */     //   9: iconst_2
/*      */     //   10: idiv
/*      */     //   11: invokespecial <init> : (I)V
/*      */     //   14: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   17: checkcast java/lang/String
/*      */     //   20: astore_3
/*      */     //   21: aload_0
/*      */     //   22: getfield _hashSliceNumber : Ljava/util/Hashtable;
/*      */     //   25: new java/lang/Integer
/*      */     //   28: dup
/*      */     //   29: iload_2
/*      */     //   30: iconst_2
/*      */     //   31: idiv
/*      */     //   32: invokespecial <init> : (I)V
/*      */     //   35: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   38: checkcast java/util/ArrayList
/*      */     //   41: astore #4
/*      */     //   43: aload_0
/*      */     //   44: getfield _hashTracks : Ljava/util/Hashtable;
/*      */     //   47: aload_3
/*      */     //   48: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   51: checkcast java/lang/Integer
/*      */     //   54: invokevirtual intValue : ()I
/*      */     //   57: istore #5
/*      */     //   59: aload_0
/*      */     //   60: getfield _listArrayList : Ljava/util/LinkedList;
/*      */     //   63: iload_2
/*      */     //   64: invokevirtual get : (I)Ljava/lang/Object;
/*      */     //   67: checkcast [[F
/*      */     //   70: astore #6
/*      */     //   72: aload_0
/*      */     //   73: getfield _listArrayList : Ljava/util/LinkedList;
/*      */     //   76: iload_2
/*      */     //   77: iconst_1
/*      */     //   78: iadd
/*      */     //   79: invokevirtual get : (I)Ljava/lang/Object;
/*      */     //   82: checkcast [[F
/*      */     //   85: astore #7
/*      */     //   87: iconst_0
/*      */     //   88: istore #8
/*      */     //   90: fload_1
/*      */     //   91: fstore #9
/*      */     //   93: aload_0
/*      */     //   94: aload_0
/*      */     //   95: getfield _anglePosition : F
/*      */     //   98: fload #9
/*      */     //   100: fconst_2
/*      */     //   101: fdiv
/*      */     //   102: fadd
/*      */     //   103: invokevirtual angleCorrection : (F)F
/*      */     //   106: fstore #10
/*      */     //   108: aload_0
/*      */     //   109: aload_0
/*      */     //   110: getfield _anglePosition : F
/*      */     //   113: fload #9
/*      */     //   115: fconst_2
/*      */     //   116: fdiv
/*      */     //   117: fsub
/*      */     //   118: invokevirtual angleCorrection : (F)F
/*      */     //   121: fstore #11
/*      */     //   123: new java/lang/Float
/*      */     //   126: dup
/*      */     //   127: fload #10
/*      */     //   129: f2d
/*      */     //   130: invokestatic toRadians : (D)D
/*      */     //   133: invokestatic tan : (D)D
/*      */     //   136: invokespecial <init> : (D)V
/*      */     //   139: astore #12
/*      */     //   141: aload_0
/*      */     //   142: aload #12
/*      */     //   144: invokevirtual floatValue : ()F
/*      */     //   147: invokevirtual roundNumber : (F)F
/*      */     //   150: fstore #13
/*      */     //   152: new java/lang/Float
/*      */     //   155: dup
/*      */     //   156: fload #11
/*      */     //   158: f2d
/*      */     //   159: invokestatic toRadians : (D)D
/*      */     //   162: invokestatic tan : (D)D
/*      */     //   165: invokespecial <init> : (D)V
/*      */     //   168: astore #14
/*      */     //   170: aload_0
/*      */     //   171: aload #14
/*      */     //   173: invokevirtual floatValue : ()F
/*      */     //   176: invokevirtual roundNumber : (F)F
/*      */     //   179: fstore #15
/*      */     //   181: iconst_0
/*      */     //   182: istore #16
/*      */     //   184: iconst_0
/*      */     //   185: istore #17
/*      */     //   187: goto -> 1460
/*      */     //   190: aload #4
/*      */     //   192: iload #17
/*      */     //   194: invokevirtual get : (I)Ljava/lang/Object;
/*      */     //   197: checkcast java/lang/Integer
/*      */     //   200: invokevirtual intValue : ()I
/*      */     //   203: istore #16
/*      */     //   205: aload #6
/*      */     //   207: iload #17
/*      */     //   209: aaload
/*      */     //   210: iload #16
/*      */     //   212: iconst_1
/*      */     //   213: isub
/*      */     //   214: faload
/*      */     //   215: fstore #18
/*      */     //   217: aload #7
/*      */     //   219: iload #17
/*      */     //   221: aaload
/*      */     //   222: iload #16
/*      */     //   224: iconst_1
/*      */     //   225: isub
/*      */     //   226: faload
/*      */     //   227: fstore #19
/*      */     //   229: fload #10
/*      */     //   231: fconst_0
/*      */     //   232: fcmpl
/*      */     //   233: ifle -> 259
/*      */     //   236: fload #10
/*      */     //   238: ldc 90.0
/*      */     //   240: fcmpg
/*      */     //   241: ifge -> 259
/*      */     //   244: fload #11
/*      */     //   246: fconst_0
/*      */     //   247: fcmpl
/*      */     //   248: ifle -> 259
/*      */     //   251: fload #11
/*      */     //   253: ldc 90.0
/*      */     //   255: fcmpg
/*      */     //   256: iflt -> 291
/*      */     //   259: fload #10
/*      */     //   261: ldc 270.0
/*      */     //   263: fcmpl
/*      */     //   264: ifle -> 316
/*      */     //   267: fload #10
/*      */     //   269: ldc 360.0
/*      */     //   271: fcmpg
/*      */     //   272: ifge -> 316
/*      */     //   275: fload #11
/*      */     //   277: ldc 270.0
/*      */     //   279: fcmpl
/*      */     //   280: ifle -> 316
/*      */     //   283: fload #11
/*      */     //   285: ldc 360.0
/*      */     //   287: fcmpg
/*      */     //   288: ifge -> 316
/*      */     //   291: fload #19
/*      */     //   293: fload #13
/*      */     //   295: fload #18
/*      */     //   297: fmul
/*      */     //   298: fcmpg
/*      */     //   299: ifgt -> 316
/*      */     //   302: fload #19
/*      */     //   304: fload #15
/*      */     //   306: fload #18
/*      */     //   308: fmul
/*      */     //   309: fcmpl
/*      */     //   310: iflt -> 316
/*      */     //   313: iinc #8, 1
/*      */     //   316: fload #10
/*      */     //   318: ldc 90.0
/*      */     //   320: fcmpl
/*      */     //   321: ifle -> 348
/*      */     //   324: fload #10
/*      */     //   326: ldc 180.0
/*      */     //   328: fcmpg
/*      */     //   329: ifge -> 348
/*      */     //   332: fload #11
/*      */     //   334: ldc 90.0
/*      */     //   336: fcmpl
/*      */     //   337: ifle -> 348
/*      */     //   340: fload #11
/*      */     //   342: ldc 180.0
/*      */     //   344: fcmpg
/*      */     //   345: iflt -> 380
/*      */     //   348: fload #10
/*      */     //   350: ldc 180.0
/*      */     //   352: fcmpl
/*      */     //   353: ifle -> 405
/*      */     //   356: fload #10
/*      */     //   358: ldc 270.0
/*      */     //   360: fcmpg
/*      */     //   361: ifge -> 405
/*      */     //   364: fload #11
/*      */     //   366: ldc 180.0
/*      */     //   368: fcmpl
/*      */     //   369: ifle -> 405
/*      */     //   372: fload #11
/*      */     //   374: ldc 270.0
/*      */     //   376: fcmpg
/*      */     //   377: ifge -> 405
/*      */     //   380: fload #19
/*      */     //   382: fload #13
/*      */     //   384: fload #18
/*      */     //   386: fmul
/*      */     //   387: fcmpl
/*      */     //   388: iflt -> 405
/*      */     //   391: fload #19
/*      */     //   393: fload #15
/*      */     //   395: fload #18
/*      */     //   397: fmul
/*      */     //   398: fcmpg
/*      */     //   399: ifgt -> 405
/*      */     //   402: iinc #8, 1
/*      */     //   405: fload #10
/*      */     //   407: fconst_0
/*      */     //   408: fcmpl
/*      */     //   409: ifle -> 559
/*      */     //   412: fload #10
/*      */     //   414: ldc 90.0
/*      */     //   416: fcmpg
/*      */     //   417: ifge -> 559
/*      */     //   420: fload #11
/*      */     //   422: ldc 180.0
/*      */     //   424: fcmpl
/*      */     //   425: ifle -> 461
/*      */     //   428: fload #11
/*      */     //   430: ldc 270.0
/*      */     //   432: fcmpg
/*      */     //   433: ifge -> 461
/*      */     //   436: fload #19
/*      */     //   438: fload #13
/*      */     //   440: fload #18
/*      */     //   442: fmul
/*      */     //   443: fcmpg
/*      */     //   444: ifgt -> 461
/*      */     //   447: fload #19
/*      */     //   449: fload #15
/*      */     //   451: fload #18
/*      */     //   453: fmul
/*      */     //   454: fcmpg
/*      */     //   455: ifgt -> 461
/*      */     //   458: iinc #8, 1
/*      */     //   461: fload #11
/*      */     //   463: ldc 270.0
/*      */     //   465: fcmpl
/*      */     //   466: ifle -> 502
/*      */     //   469: fload #11
/*      */     //   471: ldc 360.0
/*      */     //   473: fcmpg
/*      */     //   474: ifge -> 502
/*      */     //   477: fload #19
/*      */     //   479: fload #13
/*      */     //   481: fload #18
/*      */     //   483: fmul
/*      */     //   484: fcmpg
/*      */     //   485: ifgt -> 502
/*      */     //   488: fload #19
/*      */     //   490: fload #15
/*      */     //   492: fload #18
/*      */     //   494: fmul
/*      */     //   495: fcmpl
/*      */     //   496: iflt -> 502
/*      */     //   499: iinc #8, 1
/*      */     //   502: fload #11
/*      */     //   504: ldc 270.0
/*      */     //   506: fcmpl
/*      */     //   507: ifne -> 531
/*      */     //   510: fload #18
/*      */     //   512: fconst_0
/*      */     //   513: fcmpl
/*      */     //   514: iflt -> 531
/*      */     //   517: fload #19
/*      */     //   519: fload #13
/*      */     //   521: fload #18
/*      */     //   523: fmul
/*      */     //   524: fcmpg
/*      */     //   525: ifgt -> 531
/*      */     //   528: iinc #8, 1
/*      */     //   531: fload #11
/*      */     //   533: fconst_0
/*      */     //   534: fcmpl
/*      */     //   535: ifne -> 559
/*      */     //   538: fload #19
/*      */     //   540: fconst_0
/*      */     //   541: fcmpl
/*      */     //   542: iflt -> 559
/*      */     //   545: fload #19
/*      */     //   547: fload #13
/*      */     //   549: fload #18
/*      */     //   551: fmul
/*      */     //   552: fcmpg
/*      */     //   553: ifgt -> 559
/*      */     //   556: iinc #8, 1
/*      */     //   559: fload #10
/*      */     //   561: ldc 90.0
/*      */     //   563: fcmpl
/*      */     //   564: ifle -> 713
/*      */     //   567: fload #10
/*      */     //   569: ldc 180.0
/*      */     //   571: fcmpg
/*      */     //   572: ifge -> 713
/*      */     //   575: fload #11
/*      */     //   577: fconst_0
/*      */     //   578: fcmpl
/*      */     //   579: ifle -> 615
/*      */     //   582: fload #11
/*      */     //   584: ldc 90.0
/*      */     //   586: fcmpg
/*      */     //   587: ifge -> 615
/*      */     //   590: fload #19
/*      */     //   592: fload #13
/*      */     //   594: fload #18
/*      */     //   596: fmul
/*      */     //   597: fcmpl
/*      */     //   598: iflt -> 615
/*      */     //   601: fload #19
/*      */     //   603: fload #15
/*      */     //   605: fload #18
/*      */     //   607: fmul
/*      */     //   608: fcmpl
/*      */     //   609: iflt -> 615
/*      */     //   612: iinc #8, 1
/*      */     //   615: fload #11
/*      */     //   617: ldc 270.0
/*      */     //   619: fcmpl
/*      */     //   620: ifle -> 656
/*      */     //   623: fload #11
/*      */     //   625: ldc 360.0
/*      */     //   627: fcmpg
/*      */     //   628: ifge -> 656
/*      */     //   631: fload #19
/*      */     //   633: fload #13
/*      */     //   635: fload #18
/*      */     //   637: fmul
/*      */     //   638: fcmpl
/*      */     //   639: iflt -> 656
/*      */     //   642: fload #19
/*      */     //   644: fload #15
/*      */     //   646: fload #18
/*      */     //   648: fmul
/*      */     //   649: fcmpl
/*      */     //   650: iflt -> 656
/*      */     //   653: iinc #8, 1
/*      */     //   656: fload #11
/*      */     //   658: ldc 90.0
/*      */     //   660: fcmpl
/*      */     //   661: ifne -> 685
/*      */     //   664: fload #18
/*      */     //   666: fconst_0
/*      */     //   667: fcmpg
/*      */     //   668: ifgt -> 685
/*      */     //   671: fload #19
/*      */     //   673: fload #13
/*      */     //   675: fload #18
/*      */     //   677: fmul
/*      */     //   678: fcmpl
/*      */     //   679: iflt -> 685
/*      */     //   682: iinc #8, 1
/*      */     //   685: fload #11
/*      */     //   687: fconst_0
/*      */     //   688: fcmpl
/*      */     //   689: ifne -> 713
/*      */     //   692: fload #19
/*      */     //   694: fconst_0
/*      */     //   695: fcmpl
/*      */     //   696: iflt -> 713
/*      */     //   699: fload #19
/*      */     //   701: fload #13
/*      */     //   703: fload #18
/*      */     //   705: fmul
/*      */     //   706: fcmpl
/*      */     //   707: iflt -> 713
/*      */     //   710: iinc #8, 1
/*      */     //   713: fload #10
/*      */     //   715: ldc 180.0
/*      */     //   717: fcmpl
/*      */     //   718: ifle -> 868
/*      */     //   721: fload #10
/*      */     //   723: ldc 270.0
/*      */     //   725: fcmpg
/*      */     //   726: ifge -> 868
/*      */     //   729: fload #11
/*      */     //   731: ldc 90.0
/*      */     //   733: fcmpl
/*      */     //   734: ifle -> 770
/*      */     //   737: fload #11
/*      */     //   739: ldc 180.0
/*      */     //   741: fcmpg
/*      */     //   742: ifge -> 770
/*      */     //   745: fload #19
/*      */     //   747: fload #13
/*      */     //   749: fload #18
/*      */     //   751: fmul
/*      */     //   752: fcmpl
/*      */     //   753: iflt -> 770
/*      */     //   756: fload #19
/*      */     //   758: fload #15
/*      */     //   760: fload #18
/*      */     //   762: fmul
/*      */     //   763: fcmpg
/*      */     //   764: ifgt -> 770
/*      */     //   767: iinc #8, 1
/*      */     //   770: fload #11
/*      */     //   772: fconst_0
/*      */     //   773: fcmpl
/*      */     //   774: ifle -> 810
/*      */     //   777: fload #11
/*      */     //   779: ldc 90.0
/*      */     //   781: fcmpg
/*      */     //   782: ifge -> 810
/*      */     //   785: fload #19
/*      */     //   787: fload #13
/*      */     //   789: fload #18
/*      */     //   791: fmul
/*      */     //   792: fcmpl
/*      */     //   793: iflt -> 810
/*      */     //   796: fload #19
/*      */     //   798: fload #15
/*      */     //   800: fload #18
/*      */     //   802: fmul
/*      */     //   803: fcmpl
/*      */     //   804: iflt -> 810
/*      */     //   807: iinc #8, 1
/*      */     //   810: fload #11
/*      */     //   812: ldc 90.0
/*      */     //   814: fcmpl
/*      */     //   815: ifne -> 839
/*      */     //   818: fload #18
/*      */     //   820: fconst_0
/*      */     //   821: fcmpg
/*      */     //   822: ifgt -> 839
/*      */     //   825: fload #19
/*      */     //   827: fload #13
/*      */     //   829: fload #18
/*      */     //   831: fmul
/*      */     //   832: fcmpl
/*      */     //   833: iflt -> 839
/*      */     //   836: iinc #8, 1
/*      */     //   839: fload #11
/*      */     //   841: ldc 180.0
/*      */     //   843: fcmpl
/*      */     //   844: ifne -> 868
/*      */     //   847: fload #19
/*      */     //   849: fconst_0
/*      */     //   850: fcmpg
/*      */     //   851: ifgt -> 868
/*      */     //   854: fload #19
/*      */     //   856: fload #13
/*      */     //   858: fload #18
/*      */     //   860: fmul
/*      */     //   861: fcmpl
/*      */     //   862: iflt -> 868
/*      */     //   865: iinc #8, 1
/*      */     //   868: fload #10
/*      */     //   870: ldc 270.0
/*      */     //   872: fcmpl
/*      */     //   873: ifle -> 1024
/*      */     //   876: fload #10
/*      */     //   878: ldc 360.0
/*      */     //   880: fcmpg
/*      */     //   881: ifge -> 1024
/*      */     //   884: fload #11
/*      */     //   886: ldc 180.0
/*      */     //   888: fcmpl
/*      */     //   889: ifle -> 925
/*      */     //   892: fload #11
/*      */     //   894: ldc 270.0
/*      */     //   896: fcmpg
/*      */     //   897: ifge -> 925
/*      */     //   900: fload #19
/*      */     //   902: fload #13
/*      */     //   904: fload #18
/*      */     //   906: fmul
/*      */     //   907: fcmpg
/*      */     //   908: ifgt -> 925
/*      */     //   911: fload #19
/*      */     //   913: fload #15
/*      */     //   915: fload #18
/*      */     //   917: fmul
/*      */     //   918: fcmpg
/*      */     //   919: ifgt -> 925
/*      */     //   922: iinc #8, 1
/*      */     //   925: fload #11
/*      */     //   927: ldc 90.0
/*      */     //   929: fcmpl
/*      */     //   930: ifle -> 966
/*      */     //   933: fload #11
/*      */     //   935: ldc 180.0
/*      */     //   937: fcmpg
/*      */     //   938: ifge -> 966
/*      */     //   941: fload #19
/*      */     //   943: fload #13
/*      */     //   945: fload #18
/*      */     //   947: fmul
/*      */     //   948: fcmpg
/*      */     //   949: ifgt -> 966
/*      */     //   952: fload #19
/*      */     //   954: fload #15
/*      */     //   956: fload #18
/*      */     //   958: fmul
/*      */     //   959: fcmpg
/*      */     //   960: ifgt -> 966
/*      */     //   963: iinc #8, 1
/*      */     //   966: fload #11
/*      */     //   968: ldc 180.0
/*      */     //   970: fcmpl
/*      */     //   971: ifne -> 995
/*      */     //   974: fload #19
/*      */     //   976: fconst_0
/*      */     //   977: fcmpg
/*      */     //   978: ifgt -> 995
/*      */     //   981: fload #19
/*      */     //   983: fload #13
/*      */     //   985: fload #18
/*      */     //   987: fmul
/*      */     //   988: fcmpg
/*      */     //   989: ifgt -> 995
/*      */     //   992: iinc #8, 1
/*      */     //   995: fload #11
/*      */     //   997: ldc 270.0
/*      */     //   999: fcmpl
/*      */     //   1000: ifne -> 1024
/*      */     //   1003: fload #18
/*      */     //   1005: fconst_0
/*      */     //   1006: fcmpl
/*      */     //   1007: iflt -> 1024
/*      */     //   1010: fload #19
/*      */     //   1012: fload #13
/*      */     //   1014: fload #18
/*      */     //   1016: fmul
/*      */     //   1017: fcmpg
/*      */     //   1018: ifgt -> 1024
/*      */     //   1021: iinc #8, 1
/*      */     //   1024: fload #10
/*      */     //   1026: ldc 90.0
/*      */     //   1028: fcmpl
/*      */     //   1029: ifne -> 1126
/*      */     //   1032: fload #11
/*      */     //   1034: fconst_0
/*      */     //   1035: fcmpl
/*      */     //   1036: ifle -> 1047
/*      */     //   1039: fload #11
/*      */     //   1041: ldc 90.0
/*      */     //   1043: fcmpg
/*      */     //   1044: iflt -> 1063
/*      */     //   1047: fload #11
/*      */     //   1049: ldc 270.0
/*      */     //   1051: fcmpl
/*      */     //   1052: ifle -> 1084
/*      */     //   1055: fload #11
/*      */     //   1057: ldc 360.0
/*      */     //   1059: fcmpg
/*      */     //   1060: ifge -> 1084
/*      */     //   1063: fload #18
/*      */     //   1065: fconst_0
/*      */     //   1066: fcmpl
/*      */     //   1067: iflt -> 1084
/*      */     //   1070: fload #19
/*      */     //   1072: fload #15
/*      */     //   1074: fload #18
/*      */     //   1076: fmul
/*      */     //   1077: fcmpl
/*      */     //   1078: iflt -> 1084
/*      */     //   1081: iinc #8, 1
/*      */     //   1084: fload #11
/*      */     //   1086: fconst_0
/*      */     //   1087: fcmpl
/*      */     //   1088: ifne -> 1108
/*      */     //   1091: fload #18
/*      */     //   1093: fconst_0
/*      */     //   1094: fcmpl
/*      */     //   1095: iflt -> 1108
/*      */     //   1098: fload #19
/*      */     //   1100: fconst_0
/*      */     //   1101: fcmpl
/*      */     //   1102: iflt -> 1108
/*      */     //   1105: iinc #8, 1
/*      */     //   1108: fload #11
/*      */     //   1110: ldc 270.0
/*      */     //   1112: fcmpl
/*      */     //   1113: ifne -> 1126
/*      */     //   1116: fload #18
/*      */     //   1118: fconst_0
/*      */     //   1119: fcmpl
/*      */     //   1120: iflt -> 1126
/*      */     //   1123: iinc #8, 1
/*      */     //   1126: fload #10
/*      */     //   1128: ldc 180.0
/*      */     //   1130: fcmpl
/*      */     //   1131: ifne -> 1228
/*      */     //   1134: fload #11
/*      */     //   1136: fconst_0
/*      */     //   1137: fcmpl
/*      */     //   1138: ifle -> 1149
/*      */     //   1141: fload #11
/*      */     //   1143: ldc 90.0
/*      */     //   1145: fcmpg
/*      */     //   1146: iflt -> 1165
/*      */     //   1149: fload #11
/*      */     //   1151: ldc 90.0
/*      */     //   1153: fcmpl
/*      */     //   1154: ifle -> 1186
/*      */     //   1157: fload #11
/*      */     //   1159: ldc 180.0
/*      */     //   1161: fcmpg
/*      */     //   1162: ifge -> 1186
/*      */     //   1165: fload #19
/*      */     //   1167: fconst_0
/*      */     //   1168: fcmpl
/*      */     //   1169: iflt -> 1186
/*      */     //   1172: fload #19
/*      */     //   1174: fload #15
/*      */     //   1176: fload #18
/*      */     //   1178: fmul
/*      */     //   1179: fcmpg
/*      */     //   1180: ifgt -> 1186
/*      */     //   1183: iinc #8, 1
/*      */     //   1186: fload #11
/*      */     //   1188: fconst_0
/*      */     //   1189: fcmpl
/*      */     //   1190: ifne -> 1203
/*      */     //   1193: fload #19
/*      */     //   1195: fconst_0
/*      */     //   1196: fcmpl
/*      */     //   1197: iflt -> 1203
/*      */     //   1200: iinc #8, 1
/*      */     //   1203: fload #11
/*      */     //   1205: ldc 90.0
/*      */     //   1207: fcmpl
/*      */     //   1208: ifne -> 1228
/*      */     //   1211: fload #18
/*      */     //   1213: fconst_0
/*      */     //   1214: fcmpg
/*      */     //   1215: ifgt -> 1228
/*      */     //   1218: fload #19
/*      */     //   1220: fconst_0
/*      */     //   1221: fcmpl
/*      */     //   1222: iflt -> 1228
/*      */     //   1225: iinc #8, 1
/*      */     //   1228: fload #10
/*      */     //   1230: ldc 270.0
/*      */     //   1232: fcmpl
/*      */     //   1233: ifne -> 1332
/*      */     //   1236: fload #11
/*      */     //   1238: ldc 90.0
/*      */     //   1240: fcmpl
/*      */     //   1241: ifle -> 1252
/*      */     //   1244: fload #11
/*      */     //   1246: ldc 180.0
/*      */     //   1248: fcmpg
/*      */     //   1249: iflt -> 1268
/*      */     //   1252: fload #11
/*      */     //   1254: ldc 180.0
/*      */     //   1256: fcmpl
/*      */     //   1257: ifle -> 1289
/*      */     //   1260: fload #11
/*      */     //   1262: ldc 270.0
/*      */     //   1264: fcmpg
/*      */     //   1265: ifge -> 1289
/*      */     //   1268: fload #18
/*      */     //   1270: fconst_0
/*      */     //   1271: fcmpg
/*      */     //   1272: ifgt -> 1289
/*      */     //   1275: fload #19
/*      */     //   1277: fload #15
/*      */     //   1279: fload #18
/*      */     //   1281: fmul
/*      */     //   1282: fcmpg
/*      */     //   1283: ifgt -> 1289
/*      */     //   1286: iinc #8, 1
/*      */     //   1289: fload #11
/*      */     //   1291: ldc 90.0
/*      */     //   1293: fcmpl
/*      */     //   1294: ifne -> 1307
/*      */     //   1297: fload #18
/*      */     //   1299: fconst_0
/*      */     //   1300: fcmpg
/*      */     //   1301: ifgt -> 1307
/*      */     //   1304: iinc #8, 1
/*      */     //   1307: fload #11
/*      */     //   1309: ldc 180.0
/*      */     //   1311: fcmpl
/*      */     //   1312: ifne -> 1332
/*      */     //   1315: fload #18
/*      */     //   1317: fconst_0
/*      */     //   1318: fcmpg
/*      */     //   1319: ifgt -> 1332
/*      */     //   1322: fload #19
/*      */     //   1324: fconst_0
/*      */     //   1325: fcmpg
/*      */     //   1326: ifgt -> 1332
/*      */     //   1329: iinc #8, 1
/*      */     //   1332: fload #10
/*      */     //   1334: ldc 360.0
/*      */     //   1336: fcmpl
/*      */     //   1337: ifne -> 1457
/*      */     //   1340: fload #11
/*      */     //   1342: ldc 180.0
/*      */     //   1344: fcmpl
/*      */     //   1345: ifle -> 1377
/*      */     //   1348: fload #11
/*      */     //   1350: ldc 270.0
/*      */     //   1352: fcmpg
/*      */     //   1353: ifge -> 1377
/*      */     //   1356: fload #19
/*      */     //   1358: fconst_0
/*      */     //   1359: fcmpg
/*      */     //   1360: ifgt -> 1377
/*      */     //   1363: fload #19
/*      */     //   1365: fload #15
/*      */     //   1367: fload #18
/*      */     //   1369: fmul
/*      */     //   1370: fcmpg
/*      */     //   1371: ifgt -> 1377
/*      */     //   1374: iinc #8, 1
/*      */     //   1377: fload #11
/*      */     //   1379: ldc 270.0
/*      */     //   1381: fcmpl
/*      */     //   1382: ifle -> 1414
/*      */     //   1385: fload #11
/*      */     //   1387: ldc 360.0
/*      */     //   1389: fcmpg
/*      */     //   1390: ifge -> 1414
/*      */     //   1393: fload #19
/*      */     //   1395: fconst_0
/*      */     //   1396: fcmpg
/*      */     //   1397: ifgt -> 1414
/*      */     //   1400: fload #19
/*      */     //   1402: fload #15
/*      */     //   1404: fload #18
/*      */     //   1406: fmul
/*      */     //   1407: fcmpl
/*      */     //   1408: iflt -> 1414
/*      */     //   1411: iinc #8, 1
/*      */     //   1414: fload #11
/*      */     //   1416: ldc 180.0
/*      */     //   1418: fcmpl
/*      */     //   1419: ifne -> 1432
/*      */     //   1422: fload #19
/*      */     //   1424: fconst_0
/*      */     //   1425: fcmpg
/*      */     //   1426: ifgt -> 1432
/*      */     //   1429: iinc #8, 1
/*      */     //   1432: fload #11
/*      */     //   1434: ldc 270.0
/*      */     //   1436: fcmpl
/*      */     //   1437: ifne -> 1457
/*      */     //   1440: fload #18
/*      */     //   1442: fconst_0
/*      */     //   1443: fcmpl
/*      */     //   1444: iflt -> 1457
/*      */     //   1447: fload #19
/*      */     //   1449: fconst_0
/*      */     //   1450: fcmpg
/*      */     //   1451: ifgt -> 1457
/*      */     //   1454: iinc #8, 1
/*      */     //   1457: iinc #17, 1
/*      */     //   1460: iload #17
/*      */     //   1462: iload #5
/*      */     //   1464: if_icmplt -> 190
/*      */     //   1467: iload #8
/*      */     //   1469: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #5056	-> 0
/*      */     //   #5058	-> 21
/*      */     //   #5060	-> 43
/*      */     //   #5064	-> 59
/*      */     //   #5066	-> 72
/*      */     //   #5070	-> 87
/*      */     //   #5072	-> 90
/*      */     //   #5074	-> 93
/*      */     //   #5076	-> 108
/*      */     //   #5080	-> 123
/*      */     //   #5082	-> 141
/*      */     //   #5084	-> 152
/*      */     //   #5086	-> 170
/*      */     //   #5094	-> 181
/*      */     //   #5096	-> 184
/*      */     //   #5098	-> 190
/*      */     //   #5100	-> 205
/*      */     //   #5102	-> 217
/*      */     //   #5108	-> 229
/*      */     //   #5110	-> 259
/*      */     //   #5112	-> 291
/*      */     //   #5114	-> 302
/*      */     //   #5116	-> 313
/*      */     //   #5124	-> 316
/*      */     //   #5126	-> 348
/*      */     //   #5128	-> 380
/*      */     //   #5130	-> 391
/*      */     //   #5132	-> 402
/*      */     //   #5140	-> 405
/*      */     //   #5142	-> 420
/*      */     //   #5144	-> 436
/*      */     //   #5146	-> 447
/*      */     //   #5148	-> 458
/*      */     //   #5154	-> 461
/*      */     //   #5156	-> 477
/*      */     //   #5158	-> 488
/*      */     //   #5160	-> 499
/*      */     //   #5166	-> 502
/*      */     //   #5168	-> 510
/*      */     //   #5170	-> 528
/*      */     //   #5176	-> 531
/*      */     //   #5178	-> 538
/*      */     //   #5180	-> 556
/*      */     //   #5190	-> 559
/*      */     //   #5192	-> 575
/*      */     //   #5194	-> 590
/*      */     //   #5196	-> 601
/*      */     //   #5198	-> 612
/*      */     //   #5204	-> 615
/*      */     //   #5206	-> 631
/*      */     //   #5208	-> 642
/*      */     //   #5210	-> 653
/*      */     //   #5216	-> 656
/*      */     //   #5218	-> 664
/*      */     //   #5220	-> 682
/*      */     //   #5226	-> 685
/*      */     //   #5228	-> 692
/*      */     //   #5230	-> 710
/*      */     //   #5240	-> 713
/*      */     //   #5242	-> 729
/*      */     //   #5244	-> 745
/*      */     //   #5246	-> 756
/*      */     //   #5248	-> 767
/*      */     //   #5254	-> 770
/*      */     //   #5256	-> 785
/*      */     //   #5258	-> 796
/*      */     //   #5260	-> 807
/*      */     //   #5266	-> 810
/*      */     //   #5268	-> 818
/*      */     //   #5270	-> 836
/*      */     //   #5276	-> 839
/*      */     //   #5278	-> 847
/*      */     //   #5280	-> 865
/*      */     //   #5290	-> 868
/*      */     //   #5292	-> 884
/*      */     //   #5294	-> 900
/*      */     //   #5296	-> 911
/*      */     //   #5298	-> 922
/*      */     //   #5304	-> 925
/*      */     //   #5306	-> 941
/*      */     //   #5308	-> 952
/*      */     //   #5310	-> 963
/*      */     //   #5316	-> 966
/*      */     //   #5318	-> 974
/*      */     //   #5320	-> 992
/*      */     //   #5326	-> 995
/*      */     //   #5328	-> 1003
/*      */     //   #5330	-> 1021
/*      */     //   #5340	-> 1024
/*      */     //   #5342	-> 1032
/*      */     //   #5344	-> 1047
/*      */     //   #5346	-> 1063
/*      */     //   #5348	-> 1081
/*      */     //   #5354	-> 1084
/*      */     //   #5356	-> 1091
/*      */     //   #5358	-> 1105
/*      */     //   #5364	-> 1108
/*      */     //   #5366	-> 1116
/*      */     //   #5368	-> 1123
/*      */     //   #5378	-> 1126
/*      */     //   #5380	-> 1134
/*      */     //   #5382	-> 1157
/*      */     //   #5384	-> 1165
/*      */     //   #5386	-> 1183
/*      */     //   #5392	-> 1186
/*      */     //   #5394	-> 1193
/*      */     //   #5396	-> 1200
/*      */     //   #5402	-> 1203
/*      */     //   #5404	-> 1211
/*      */     //   #5406	-> 1225
/*      */     //   #5414	-> 1228
/*      */     //   #5416	-> 1236
/*      */     //   #5418	-> 1252
/*      */     //   #5420	-> 1268
/*      */     //   #5422	-> 1286
/*      */     //   #5428	-> 1289
/*      */     //   #5430	-> 1297
/*      */     //   #5432	-> 1304
/*      */     //   #5438	-> 1307
/*      */     //   #5440	-> 1315
/*      */     //   #5442	-> 1329
/*      */     //   #5452	-> 1332
/*      */     //   #5454	-> 1340
/*      */     //   #5456	-> 1356
/*      */     //   #5458	-> 1374
/*      */     //   #5464	-> 1377
/*      */     //   #5466	-> 1393
/*      */     //   #5468	-> 1411
/*      */     //   #5474	-> 1414
/*      */     //   #5476	-> 1422
/*      */     //   #5478	-> 1429
/*      */     //   #5484	-> 1432
/*      */     //   #5486	-> 1440
/*      */     //   #5488	-> 1454
/*      */     //   #5096	-> 1457
/*      */     //   #5498	-> 1467
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void thresholdFunctionVelocity(double paramDouble1, double paramDouble2, int paramInt, String paramString) {
/* 5508 */     int i = 0;
/*      */     
/* 5510 */     int j = ((Integer)this._hashTracks.get(paramString)).intValue();
/*      */ 
/*      */ 
/*      */     
/* 5514 */     ArrayList arrayList1 = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/* 5518 */     if (paramInt == 1)
/*      */     {
/* 5520 */       for (byte b = 0; b < j; b++) {
/*      */         
/* 5522 */         i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */         
/* 5524 */         byte b4 = 0;
/*      */         
/* 5526 */         double d = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5532 */         while (b4 < i - 1) {
/*      */           
/* 5534 */           d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */               
/* 5536 */               .doubleValue(), (
/*      */               
/* 5538 */               new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                 
/* 5540 */                 this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                 
/* 5542 */                 this.y_values[b][b4 + 1])).doubleValue());
/*      */           
/* 5544 */           b4++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5550 */         if (this._timeInterval * (i - 1) == 0.0D) {
/*      */           
/* 5552 */           d = 0.0D;
/*      */         }
/*      */         else {
/*      */           
/* 5556 */           d /= this._timeInterval * (i - 1);
/*      */         } 
/*      */ 
/*      */         
/* 5560 */         if (d < paramDouble1)
/*      */         {
/* 5562 */           arrayList1.add(new Integer(b));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5574 */     if (paramInt == 2)
/*      */     {
/* 5576 */       for (byte b = 0; b < j; b++) {
/*      */         
/* 5578 */         i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */         
/* 5580 */         byte b4 = 0;
/*      */         
/* 5582 */         double d = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5588 */         while (b4 < i - 1) {
/*      */           
/* 5590 */           d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */               
/* 5592 */               .doubleValue(), (
/*      */               
/* 5594 */               new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                 
/* 5596 */                 this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                 
/* 5598 */                 this.y_values[b][b4 + 1])).doubleValue());
/*      */           
/* 5600 */           b4++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5608 */         if (this._timeInterval * (i - 1) == 0.0D) {
/*      */           
/* 5610 */           d = 0.0D;
/*      */         }
/*      */         else {
/*      */           
/* 5614 */           d /= this._timeInterval * (i - 1);
/*      */         } 
/*      */ 
/*      */         
/* 5618 */         if (d > paramDouble1)
/*      */         {
/* 5620 */           arrayList1.add(new Integer(b));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5632 */     if (paramInt == 3)
/*      */     {
/* 5634 */       for (byte b = 0; b < j; b++) {
/*      */         
/* 5636 */         i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */         
/* 5638 */         byte b4 = 0;
/*      */         
/* 5640 */         double d = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5646 */         while (b4 < i - 1) {
/*      */           
/* 5648 */           d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */               
/* 5650 */               .doubleValue(), (
/*      */               
/* 5652 */               new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                 
/* 5654 */                 this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                 
/* 5656 */                 this.y_values[b][b4 + 1])).doubleValue());
/*      */           
/* 5658 */           b4++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5666 */         if (this._timeInterval * (i - 1) == 0.0D) {
/*      */           
/* 5668 */           d = 0.0D;
/*      */         }
/*      */         else {
/*      */           
/* 5672 */           d /= this._timeInterval * (i - 1);
/*      */         } 
/*      */ 
/*      */         
/* 5676 */         if (d > paramDouble1 && d < paramDouble2)
/*      */         {
/* 5678 */           arrayList1.add(new Integer(b));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5692 */     int k = 0;
/*      */ 
/*      */ 
/*      */     
/* 5696 */     for (byte b1 = 0; b1 < j; b1++) {
/*      */       
/* 5698 */       if (arrayList1.contains(new Integer(b1))) {
/*      */         
/* 5700 */         i = ((Integer)this._variableSliceNumber.get(b1)).intValue();
/*      */         
/* 5702 */         if (i > k)
/*      */         {
/* 5704 */           k = i;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5714 */     ArrayList arrayList2 = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/* 5718 */     float[][] arrayOfFloat1 = new float[arrayList1.size()][k];
/*      */     
/* 5720 */     float[][] arrayOfFloat2 = new float[arrayList1.size()][k];
/*      */     
/* 5722 */     byte b2 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5728 */     for (byte b3 = 0; b3 < j; b3++) {
/*      */       
/* 5730 */       if (arrayList1.contains(new Integer(b3))) {
/*      */         
/* 5732 */         byte b = 0;
/*      */         
/* 5734 */         i = ((Integer)this._variableSliceNumber.get(b3)).intValue();
/*      */         
/* 5736 */         arrayList2.add(new Integer(i));
/*      */         
/* 5738 */         while (b < i) {
/*      */           
/* 5740 */           arrayOfFloat1[b2][b] = this.x_values[b3][b];
/*      */           
/* 5742 */           arrayOfFloat2[b2][b] = this.y_values[b3][b];
/*      */           
/* 5744 */           b++;
/*      */         } 
/*      */ 
/*      */         
/* 5748 */         b2++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5756 */     this._variableSliceNumber = arrayList2;
/*      */     
/* 5758 */     j = b2;
/*      */     
/* 5760 */     updateNumberofTracks(paramString, j);
/*      */     
/* 5762 */     this.x_values = arrayOfFloat1;
/*      */     
/* 5764 */     this.y_values = arrayOfFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void thresholdFunctionPath(double paramDouble1, double paramDouble2, String paramString1, int paramInt, String paramString2) {
/* 5778 */     int i = 0;
/*      */     
/* 5780 */     int j = ((Integer)this._hashTracks.get(paramString2)).intValue();
/*      */ 
/*      */ 
/*      */     
/* 5784 */     ArrayList arrayList1 = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5790 */     if (paramString1.equals("euclid")) {
/*      */       
/* 5792 */       if (paramInt == 1)
/*      */       {
/* 5794 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5796 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5798 */           boolean bool = false;
/*      */           
/* 5800 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 5804 */           float f1 = this.x_values[b][i - 1];
/*      */           
/* 5806 */           float f2 = this.y_values[b][i - 1];
/*      */           
/* 5808 */           d = Math.sqrt(Math.pow((new Float(f1))
/*      */                 
/* 5810 */                 .doubleValue(), 2.0D) + 
/*      */               
/* 5812 */               Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */           
/* 5816 */           if (d < paramDouble1)
/*      */           {
/* 5818 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5828 */       if (paramInt == 2)
/*      */       {
/* 5830 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5832 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5834 */           boolean bool = false;
/*      */           
/* 5836 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 5840 */           float f1 = this.x_values[b][i - 1];
/*      */           
/* 5842 */           float f2 = this.y_values[b][i - 1];
/*      */           
/* 5844 */           d = Math.sqrt(Math.pow((new Float(f1))
/*      */                 
/* 5846 */                 .doubleValue(), 2.0D) + 
/*      */               
/* 5848 */               Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */           
/* 5852 */           if (d > paramDouble1)
/*      */           {
/* 5854 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5864 */       if (paramInt == 3)
/*      */       {
/* 5866 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5868 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5870 */           boolean bool = false;
/*      */           
/* 5872 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 5876 */           float f1 = this.x_values[b][i - 1];
/*      */           
/* 5878 */           float f2 = this.y_values[b][i - 1];
/*      */           
/* 5880 */           d = Math.sqrt(Math.pow((new Float(f1))
/*      */                 
/* 5882 */                 .doubleValue(), 2.0D) + 
/*      */               
/* 5884 */               Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */ 
/*      */ 
/*      */           
/* 5888 */           if (d > paramDouble1 && d < paramDouble2)
/*      */           {
/* 5890 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5906 */     if (paramString1.equals("accumulated")) {
/*      */       
/* 5908 */       if (paramInt == 1)
/*      */       {
/* 5910 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5912 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5914 */           byte b4 = 0;
/*      */           
/* 5916 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 5920 */           while (b4 < i - 1) {
/*      */             
/* 5922 */             d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */                 
/* 5924 */                 .doubleValue(), (
/*      */                 
/* 5926 */                 new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                   
/* 5928 */                   this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                   
/* 5930 */                   this.y_values[b][b4 + 1])).doubleValue());
/*      */             
/* 5932 */             b4++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 5938 */           if (d < paramDouble1)
/*      */           {
/* 5940 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5950 */       if (paramInt == 2)
/*      */       {
/* 5952 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5954 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5956 */           byte b4 = 0;
/*      */           
/* 5958 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 5962 */           while (b4 < i - 1) {
/*      */             
/* 5964 */             d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */                 
/* 5966 */                 .doubleValue(), (
/*      */                 
/* 5968 */                 new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                   
/* 5970 */                   this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                   
/* 5972 */                   this.y_values[b][b4 + 1])).doubleValue());
/*      */             
/* 5974 */             b4++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 5980 */           if (d > paramDouble1)
/*      */           {
/* 5982 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5992 */       if (paramInt == 3)
/*      */       {
/* 5994 */         for (byte b = 0; b < j; b++) {
/*      */           
/* 5996 */           i = ((Integer)this._variableSliceNumber.get(b)).intValue();
/*      */           
/* 5998 */           byte b4 = 0;
/*      */           
/* 6000 */           double d = 0.0D;
/*      */ 
/*      */ 
/*      */           
/* 6004 */           while (b4 < i - 1) {
/*      */             
/* 6006 */             d += Point2D.distance((new Float(this.x_values[b][b4]))
/*      */                 
/* 6008 */                 .doubleValue(), (
/*      */                 
/* 6010 */                 new Float(this.y_values[b][b4])).doubleValue(), (new Float(
/*      */                   
/* 6012 */                   this.x_values[b][b4 + 1])).doubleValue(), (new Float(
/*      */                   
/* 6014 */                   this.y_values[b][b4 + 1])).doubleValue());
/*      */             
/* 6016 */             b4++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6022 */           if (d > paramDouble1 && d < paramDouble2)
/*      */           {
/* 6024 */             arrayList1.add(new Integer(b));
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6038 */     int k = 0;
/*      */ 
/*      */ 
/*      */     
/* 6042 */     for (byte b1 = 0; b1 < j; b1++) {
/*      */       
/* 6044 */       if (arrayList1.contains(new Integer(b1))) {
/*      */         
/* 6046 */         i = ((Integer)this._variableSliceNumber.get(b1)).intValue();
/*      */         
/* 6048 */         if (i > k)
/*      */         {
/* 6050 */           k = i;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6060 */     ArrayList arrayList2 = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/* 6064 */     float[][] arrayOfFloat1 = new float[arrayList1.size()][k];
/*      */     
/* 6066 */     float[][] arrayOfFloat2 = new float[arrayList1.size()][k];
/*      */     
/* 6068 */     byte b2 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6074 */     for (byte b3 = 0; b3 < j; b3++) {
/*      */       
/* 6076 */       if (arrayList1.contains(new Integer(b3))) {
/*      */         
/* 6078 */         byte b = 0;
/*      */         
/* 6080 */         i = ((Integer)this._variableSliceNumber.get(b3)).intValue();
/*      */         
/* 6082 */         arrayList2.add(new Integer(i));
/*      */         
/* 6084 */         while (b < i) {
/*      */           
/* 6086 */           arrayOfFloat1[b2][b] = this.x_values[b3][b];
/*      */           
/* 6088 */           arrayOfFloat2[b2][b] = this.y_values[b3][b];
/*      */           
/* 6090 */           b++;
/*      */         } 
/*      */ 
/*      */         
/* 6094 */         b2++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 6100 */     this._variableSliceNumber = arrayList2;
/*      */     
/* 6102 */     j = b2;
/*      */ 
/*      */ 
/*      */     
/* 6106 */     updateNumberofTracks(paramString2, j);
/*      */     
/* 6108 */     this.x_values = arrayOfFloat1;
/*      */     
/* 6110 */     this.y_values = arrayOfFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void plotGraph(int paramInt1, int paramInt2) {
/* 6120 */     String str = (String)this._hashCurrentDataset.get(new Integer(paramInt2 / 2));
/*      */     
/* 6122 */     ArrayList arrayList1 = (ArrayList)this._hashSliceNumber.get(new Integer(paramInt2 / 2));
/*      */     
/* 6124 */     int i = ((Integer)this._hashTracks.get(str)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6129 */     float[][] arrayOfFloat1 = this._listArrayList.get(paramInt2);
/*      */     
/* 6131 */     float[][] arrayOfFloat2 = this._listArrayList.get(paramInt2 + 1);
/*      */ 
/*      */ 
/*      */     
/* 6135 */     double d1 = 0.0D;
/*      */     
/* 6137 */     double d2 = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6142 */     byte b1 = 0;
/*      */     
/* 6144 */     byte b2 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6150 */     ArrayList arrayList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6156 */     if (paramInt1 == 1)
/*      */     {
/*      */ 
/*      */       
/* 6160 */       arrayList = ChemotaxisStatistic.computeDistandVelocity("accumulated distance", arrayOfFloat1, arrayOfFloat2, arrayList1, i, this._timeInterval);
/*      */     }
/*      */ 
/*      */     
/* 6164 */     if (paramInt1 == 2)
/*      */     {
/*      */ 
/*      */       
/* 6168 */       arrayList = ChemotaxisStatistic.computeDistandVelocity("velocity", arrayOfFloat1, arrayOfFloat2, arrayList1, i, this._timeInterval);
/*      */     }
/*      */ 
/*      */     
/* 6172 */     if (paramInt1 == 5)
/*      */     {
/*      */ 
/*      */       
/* 6176 */       arrayList = ChemotaxisStatistic.computeDistandVelocity("euclid distance", arrayOfFloat1, arrayOfFloat2, arrayList1, i, this._timeInterval);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6182 */     if (paramInt1 == 7)
/*      */     {
/*      */       
/* 6185 */       arrayList = ChemotaxisStatistic.computeDirectionality(arrayOfFloat1, arrayOfFloat2, arrayList1, i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6193 */     if (this.gui.showCenterofMass.isSelected()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6199 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6201 */         int j = ((Integer)arrayList1.get(b)).intValue();
/*      */         
/* 6203 */         d1 += arrayOfFloat1[b][j - 1];
/*      */         
/* 6205 */         d2 += arrayOfFloat2[b][j - 1];
/*      */       } 
/*      */ 
/*      */       
/* 6209 */       if (i != 0) {
/*      */         
/* 6211 */         d1 /= i;
/*      */         
/* 6213 */         d2 /= i;
/*      */       } 
/*      */ 
/*      */       
/* 6217 */       d1 = roundDoubleNumbers(d1);
/*      */       
/* 6219 */       d2 = roundDoubleNumbers(d2);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6227 */     float[] arrayOfFloat3 = new float[1];
/*      */     
/* 6229 */     Plot plot = new Plot(str, "x axis [" + 
/*      */         
/* 6231 */         this._unitsPath + "]", "y axis  [" + 
/*      */         
/* 6233 */         this._unitsPath + "]", arrayOfFloat3, arrayOfFloat3);
/*      */ 
/*      */     
/* 6236 */     if (this._dialog.auto) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6241 */       float[] arrayOfFloat6 = { this._coordSize, -this._coordSize };
/*      */       
/* 6243 */       float[] arrayOfFloat7 = new float[2];
/*      */       
/* 6245 */       plot.setLimits(-this._coordSize, this._coordSize, -this._coordSize, this._coordSize);
/*      */       
/* 6247 */       plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */       
/* 6249 */       plot.addPoints(arrayOfFloat7, arrayOfFloat6, 2);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 6254 */       float[] arrayOfFloat6 = { this._dialog.minimumX, this._dialog.maximumX };
/*      */       
/* 6256 */       float[] arrayOfFloat7 = new float[2];
/*      */       
/* 6258 */       float[] arrayOfFloat8 = { this._dialog.minimumY, this._dialog.maximumY };
/*      */       
/* 6260 */       plot.setLimits(this._dialog.minimumX, this._dialog.maximumX, this._dialog.minimumY, this._dialog.maximumY);
/*      */       
/* 6262 */       plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */       
/* 6264 */       plot.addPoints(arrayOfFloat7, arrayOfFloat8, 2);
/*      */     } 
/*      */     
/* 6267 */     plot.draw();
/*      */ 
/*      */ 
/*      */     
/* 6271 */     plot.setLineWidth(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6281 */     float[] arrayOfFloat4 = new float[1];
/*      */     
/* 6283 */     float[] arrayOfFloat5 = new float[1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6291 */     if (paramInt1 == 6) {
/*      */       
/* 6293 */       int j = 0;
/*      */       
/* 6295 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6297 */         j = ((Integer)arrayList1.get(b)).intValue();
/*      */         
/* 6299 */         float[] arrayOfFloat6 = new float[j];
/*      */         
/* 6301 */         float[] arrayOfFloat7 = new float[j];
/*      */         
/* 6303 */         arrayOfFloat4[0] = arrayOfFloat1[b][j - 1];
/*      */         
/* 6305 */         arrayOfFloat5[0] = arrayOfFloat2[b][j - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6311 */         if (!this.gui.plotEndpoints.isSelected()) {
/*      */ 
/*      */ 
/*      */           
/* 6315 */           for (byte b3 = 0; b3 < j; b3++) {
/*      */             
/* 6317 */             arrayOfFloat6[b3] = arrayOfFloat1[b][b3];
/*      */             
/* 6319 */             arrayOfFloat7[b3] = arrayOfFloat2[b][b3];
/*      */           } 
/*      */ 
/*      */           
/* 6323 */           plot.setLineWidth(1);
/*      */           
/* 6325 */           plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */         } 
/*      */ 
/*      */         
/* 6329 */         plot.setLineWidth(3);
/*      */         
/* 6331 */         plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */       } 
/*      */ 
/*      */       
/* 6335 */       plot.setColor(Color.black);
/*      */       
/* 6337 */       if (this.gui.showAdditionalInfo.isSelected()) {
/*      */         
/* 6339 */         plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i);
/*      */         
/* 6341 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 6343 */           plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6355 */     if (paramInt1 == 3) {
/*      */       
/* 6357 */       int j = 0;
/*      */       
/* 6359 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6361 */         j = ((Integer)arrayList1.get(b)).intValue();
/*      */         
/* 6363 */         float[] arrayOfFloat6 = new float[j];
/*      */         
/* 6365 */         float[] arrayOfFloat7 = new float[j];
/*      */         
/* 6367 */         arrayOfFloat4[0] = arrayOfFloat1[b][j - 1];
/*      */         
/* 6369 */         arrayOfFloat5[0] = arrayOfFloat2[b][j - 1];
/*      */ 
/*      */ 
/*      */         
/* 6373 */         if (arrayOfFloat5[0] >= 0.0F) {
/*      */           
/* 6375 */           plot.setColor(Color.black);
/*      */           
/* 6377 */           b1++;
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 6383 */           plot.setColor(Color.red);
/*      */           
/* 6385 */           b2++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6393 */         if (!this.gui.plotEndpoints.isSelected()) {
/*      */ 
/*      */ 
/*      */           
/* 6397 */           for (byte b3 = 0; b3 < j; b3++) {
/*      */             
/* 6399 */             arrayOfFloat6[b3] = arrayOfFloat1[b][b3];
/*      */             
/* 6401 */             arrayOfFloat7[b3] = arrayOfFloat2[b][b3];
/*      */           } 
/*      */ 
/*      */           
/* 6405 */           plot.setLineWidth(1);
/*      */           
/* 6407 */           plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */         } 
/*      */ 
/*      */         
/* 6411 */         plot.setLineWidth(3);
/*      */         
/* 6413 */         plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */       } 
/*      */ 
/*      */       
/* 6417 */       plot.setColor(Color.black);
/*      */       
/* 6419 */       if (this.gui.showAdditionalInfo.isSelected()) {
/*      */         
/* 6421 */         plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i + "  Counts up: " + b1 + "  Counts down: " + b2);
/*      */         
/* 6423 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 6425 */           plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6439 */     if (paramInt1 == 4) {
/*      */       
/* 6441 */       int j = 0;
/*      */       
/* 6443 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6445 */         j = ((Integer)arrayList1.get(b)).intValue();
/*      */         
/* 6447 */         float[] arrayOfFloat6 = new float[j];
/*      */         
/* 6449 */         float[] arrayOfFloat7 = new float[j];
/*      */         
/* 6451 */         arrayOfFloat4[0] = arrayOfFloat1[b][j - 1];
/*      */         
/* 6453 */         arrayOfFloat5[0] = arrayOfFloat2[b][j - 1];
/*      */ 
/*      */ 
/*      */         
/* 6457 */         if (arrayOfFloat4[0] <= 0.0F) {
/*      */           
/* 6459 */           plot.setColor(Color.black);
/*      */           
/* 6461 */           b1++;
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 6467 */           plot.setColor(Color.red);
/*      */           
/* 6469 */           b2++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6477 */         if (!this.gui.plotEndpoints.isSelected()) {
/*      */ 
/*      */ 
/*      */           
/* 6481 */           for (byte b3 = 0; b3 < j; b3++) {
/*      */             
/* 6483 */             arrayOfFloat6[b3] = arrayOfFloat1[b][b3];
/*      */             
/* 6485 */             arrayOfFloat7[b3] = arrayOfFloat2[b][b3];
/*      */           } 
/*      */ 
/*      */           
/* 6489 */           plot.setLineWidth(1);
/*      */           
/* 6491 */           plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */         } 
/*      */ 
/*      */         
/* 6495 */         plot.setLineWidth(3);
/*      */         
/* 6497 */         plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */       } 
/*      */ 
/*      */       
/* 6501 */       plot.setColor(Color.black);
/*      */       
/* 6503 */       if (this.gui.showAdditionalInfo.isSelected()) {
/*      */         
/* 6505 */         plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i + "  Counts left: " + b1 + "  Counts right: " + b2);
/*      */         
/* 6507 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 6509 */           plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6521 */     if (paramInt1 == 1 || paramInt1 == 2 || paramInt1 == 5 || paramInt1 == 7) {
/*      */       
/* 6523 */       double d = 0.0D;
/*      */       
/* 6525 */       int j = 0;
/*      */ 
/*      */       
/*      */       try {
/* 6529 */         d = (new Double(this.gui.colorBorderField.getText())).doubleValue();
/*      */       }
/* 6531 */       catch (NumberFormatException numberFormatException) {
/*      */         
/* 6533 */         d = 0.0D;
/*      */         
/* 6535 */         this.gui.colorBorderField.setText(String.valueOf(d));
/*      */       } 
/*      */ 
/*      */       
/* 6539 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 6541 */         j = ((Integer)arrayList1.get(b)).intValue();
/*      */         
/* 6543 */         float[] arrayOfFloat6 = new float[j];
/*      */         
/* 6545 */         float[] arrayOfFloat7 = new float[j];
/*      */         
/* 6547 */         arrayOfFloat4[0] = arrayOfFloat1[b][j - 1];
/*      */         
/* 6549 */         arrayOfFloat5[0] = arrayOfFloat2[b][j - 1];
/*      */ 
/*      */ 
/*      */         
/* 6553 */         if (((Double)arrayList.get(b)).doubleValue() >= d) {
/*      */           
/* 6555 */           plot.setColor(Color.black);
/*      */           
/* 6557 */           b1++;
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 6563 */           plot.setColor(Color.red);
/*      */           
/* 6565 */           b2++;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6571 */         if (!this.gui.plotEndpoints.isSelected()) {
/*      */ 
/*      */ 
/*      */           
/* 6575 */           for (byte b3 = 0; b3 < j; b3++) {
/*      */             
/* 6577 */             arrayOfFloat6[b3] = arrayOfFloat1[b][b3];
/*      */             
/* 6579 */             arrayOfFloat7[b3] = arrayOfFloat2[b][b3];
/*      */           } 
/*      */ 
/*      */           
/* 6583 */           plot.setLineWidth(1);
/*      */           
/* 6585 */           plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */         } 
/*      */ 
/*      */         
/* 6589 */         plot.setLineWidth(3);
/*      */         
/* 6591 */         plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */       } 
/*      */ 
/*      */       
/* 6595 */       plot.setColor(Color.black);
/*      */ 
/*      */ 
/*      */       
/* 6599 */       if (paramInt1 == 2) {
/*      */         
/* 6601 */         if (this.gui.showAdditionalInfo.isSelected())
/*      */         {
/* 6603 */           plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i + "  Counts faster: " + b1 + "  Counts slower: " + b2);
/*      */           
/* 6605 */           if (this.gui.showCenterofMass.isSelected())
/*      */           {
/* 6607 */             plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 6615 */       else if (paramInt1 == 7) {
/*      */         
/* 6617 */         if (this.gui.showAdditionalInfo.isSelected())
/*      */         {
/* 6619 */           plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i + "  Counts directionality greater: " + b1 + "  Counts directionality less: " + b2);
/*      */           
/* 6621 */           if (this.gui.showCenterofMass.isSelected())
/*      */           {
/* 6623 */             plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 6633 */       else if (this.gui.showAdditionalInfo.isSelected()) {
/*      */         
/* 6635 */         plot.addLabel(0.0D, 0.0D, "Number of tracks: " + i + "  Counts more: " + b1 + "  Counts less: " + b2);
/*      */         
/* 6637 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 6639 */           plot.addLabel(0.0D, 0.04D, "Center of mass [" + this._unitsPath + "]: x=" + d1 + " y=" + d2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6651 */     if (this.gui.showCenterofMass.isSelected()) {
/*      */ 
/*      */ 
/*      */       
/* 6655 */       float[] arrayOfFloat6 = { (new Float(d1)).floatValue() };
/*      */       
/* 6657 */       float[] arrayOfFloat7 = { (new Float(d2)).floatValue() };
/*      */       
/* 6659 */       plot.setColor(Color.blue);
/*      */       
/* 6661 */       plot.setLineWidth(3);
/*      */       
/* 6663 */       plot.addPoints(arrayOfFloat6, arrayOfFloat7, 5);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6669 */     PlotWindow plotWindow = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6674 */     if (this._currentOpenWindows.size() < this._listArrayList.size() / 2) {
/*      */ 
/*      */       
/* 6677 */       plotWindow = plot.show();
/*      */ 
/*      */       
/* 6680 */       this._currentOpenWindows.add(plotWindow);
/*      */       
/* 6682 */       plotWindow.addWindowListener(this);
/*      */       
/* 6684 */       plotWindow.setResizable(false);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 6689 */       plotWindow = this._currentOpenWindows.get(paramInt2 / 2);
/*      */       
/* 6691 */       plotWindow.drawPlot(plot);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6699 */     ArrayList arrayList2 = new ArrayList();
/*      */     
/* 6701 */     arrayList2.add(new Integer(paramInt1));
/*      */     
/* 6703 */     arrayList2.add(new Integer(paramInt2));
/*      */     
/* 6705 */     arrayList2.add(new Integer(i));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6711 */     this._hashPlot.put(str, arrayList2);
/*      */     
/* 6713 */     this._hashWindow.put(str, plotWindow);
/*      */     
/* 6715 */     plotWindow.setTitle("Chemotaxis Plot for " + str);
/*      */     
/* 6717 */     this.gui.butshowSector.setEnabled(true);
/*      */     
/* 6719 */     this.gui.butshowCircle.setEnabled(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void showAnimatedGraph() {
/* 6737 */     byte b1 = 0;
/*      */ 
/*      */ 
/*      */     
/* 6741 */     String str1 = (String)this.gui.markingAnimation.getSelectedItem();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6749 */     if (str1.equals("Mark up/down"))
/*      */     {
/*      */ 
/*      */       
/* 6753 */       b1 = 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6759 */     if (str1.equals("Mark left/right"))
/*      */     {
/*      */ 
/*      */       
/* 6763 */       b1 = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6769 */     if (str1.equals("No marking"))
/*      */     {
/*      */ 
/*      */       
/* 6773 */       b1 = 3;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6785 */     float f1 = 0.0F;
/*      */     
/* 6787 */     float f2 = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6793 */     ImageStack imageStack = null;
/*      */ 
/*      */ 
/*      */     
/* 6797 */     String str2 = (String)this.gui.plotAnimation.getSelectedItem();
/*      */     
/* 6799 */     int i = ((Integer)this._hashCurrentPosition.get(str2)).intValue();
/*      */     
/* 6801 */     ArrayList arrayList = (ArrayList)this._hashSliceNumber.get(new Integer(i));
/*      */ 
/*      */ 
/*      */     
/* 6805 */     i *= 2;
/*      */ 
/*      */ 
/*      */     
/* 6809 */     int j = 0;
/*      */     
/* 6811 */     int k = ((Integer)this._hashTracks.get(str2)).intValue();
/*      */ 
/*      */ 
/*      */     
/* 6815 */     float[][] arrayOfFloat1 = this._listArrayList.get(i);
/*      */     
/* 6817 */     float[][] arrayOfFloat2 = this._listArrayList.get(i + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6825 */     for (byte b2 = 0; b2 < k; b2++) {
/*      */       
/* 6827 */       j = ((Integer)arrayList.get(b2)).intValue();
/*      */       
/* 6829 */       for (byte b = 1; b < j; b++) {
/*      */         
/* 6831 */         if (f1 < Math.abs(arrayOfFloat1[b2][b]))
/*      */         {
/* 6833 */           f1 = Math.abs(arrayOfFloat1[b2][b]);
/*      */         }
/* 6835 */         if (f2 < Math.abs(arrayOfFloat2[b2][b]))
/*      */         {
/* 6837 */           f2 = Math.abs(arrayOfFloat2[b2][b]);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 6843 */     if (f1 > f2) {
/*      */       
/* 6845 */       this._coordSize = f1 + 5.0F;
/*      */     }
/*      */     else {
/*      */       
/* 6849 */       this._coordSize = f2 + 5.0F;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6855 */     byte b3 = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6861 */     int m = ((Integer)Collections.<Integer>max(arrayList)).intValue();
/*      */ 
/*      */ 
/*      */     
/* 6865 */     while (b3 <= m) {
/*      */ 
/*      */       
/* 6868 */       float[] arrayOfFloat3 = new float[1];
/*      */ 
/*      */ 
/*      */       
/* 6872 */       Plot plot = new Plot("Chemotaxis Animation ", "x axis [" + 
/*      */           
/* 6874 */           this._unitsPath + "]", "y axis [" + 
/*      */           
/* 6876 */           this._unitsPath + "]", arrayOfFloat3, arrayOfFloat3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6881 */       if (this._dialog.auto) {
/*      */ 
/*      */         
/* 6884 */         float[] arrayOfFloat8 = { this._coordSize, -this._coordSize };
/*      */         
/* 6886 */         float[] arrayOfFloat9 = new float[2];
/*      */         
/* 6888 */         plot.setLimits(-this._coordSize, this._coordSize, -this._coordSize, this._coordSize);
/*      */         
/* 6890 */         plot.addPoints(arrayOfFloat8, arrayOfFloat9, 2);
/*      */         
/* 6892 */         plot.addPoints(arrayOfFloat9, arrayOfFloat8, 2);
/*      */       }
/*      */       else {
/*      */         
/* 6896 */         float[] arrayOfFloat8 = { this._dialog.minimumX, this._dialog.maximumX };
/*      */         
/* 6898 */         float[] arrayOfFloat9 = new float[2];
/*      */         
/* 6900 */         float[] arrayOfFloat10 = { this._dialog.minimumY, this._dialog.maximumY };
/*      */         
/* 6902 */         plot.setLimits(this._dialog.minimumX, this._dialog.maximumX, this._dialog.minimumY, this._dialog.maximumY);
/*      */         
/* 6904 */         plot.addPoints(arrayOfFloat8, arrayOfFloat9, 2);
/*      */         
/* 6906 */         plot.addPoints(arrayOfFloat9, arrayOfFloat10, 2);
/*      */       } 
/*      */       
/* 6909 */       plot.draw();
/*      */ 
/*      */ 
/*      */       
/* 6913 */       float[] arrayOfFloat4 = new float[1];
/*      */       
/* 6915 */       float[] arrayOfFloat5 = new float[1];
/*      */       
/* 6917 */       float[] arrayOfFloat6 = new float[b3];
/*      */       
/* 6919 */       float[] arrayOfFloat7 = new float[b3];
/*      */ 
/*      */ 
/*      */       
/* 6923 */       for (byte b = 0; b < k; b++) {
/*      */         
/* 6925 */         j = ((Integer)arrayList.get(b)).intValue();
/*      */         
/* 6927 */         if (b3 <= j) {
/*      */           
/* 6929 */           arrayOfFloat4[0] = arrayOfFloat1[b][b3 - 1];
/*      */           
/* 6931 */           arrayOfFloat5[0] = arrayOfFloat2[b][b3 - 1];
/*      */           
/* 6933 */           for (byte b4 = 0; b4 < b3; b4++) {
/*      */             
/* 6935 */             arrayOfFloat6[b4] = arrayOfFloat1[b][b4];
/*      */             
/* 6937 */             arrayOfFloat7[b4] = arrayOfFloat2[b][b4];
/*      */           } 
/*      */ 
/*      */           
/* 6941 */           if (b1 == 1)
/*      */           {
/* 6943 */             if (arrayOfFloat5[0] >= 0.0F) {
/*      */ 
/*      */ 
/*      */               
/* 6947 */               plot.setColor(Color.black);
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */ 
/*      */               
/* 6955 */               plot.setColor(Color.red);
/*      */             } 
/*      */           }
/*      */           
/* 6959 */           if (b1 == 2)
/*      */           {
/* 6961 */             if (arrayOfFloat4[0] <= 0.0F) {
/*      */ 
/*      */ 
/*      */               
/* 6965 */               plot.setColor(Color.black);
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 6975 */               plot.setColor(Color.red);
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6983 */           if (b1 == 3)
/*      */           {
/* 6985 */             plot.setColor(Color.black);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6991 */           plot.setLineWidth(1);
/*      */           
/* 6993 */           plot.addPoints(arrayOfFloat6, arrayOfFloat7, 2);
/*      */           
/* 6995 */           plot.setLineWidth(3);
/*      */           
/* 6997 */           plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 7003 */           float[] arrayOfFloat8 = new float[j];
/*      */           
/* 7005 */           float[] arrayOfFloat9 = new float[j];
/*      */           
/* 7007 */           arrayOfFloat4[0] = arrayOfFloat1[b][j - 1];
/*      */           
/* 7009 */           arrayOfFloat5[0] = arrayOfFloat2[b][j - 1];
/*      */           
/* 7011 */           for (byte b4 = 0; b4 < j; b4++) {
/*      */             
/* 7013 */             arrayOfFloat8[b4] = arrayOfFloat1[b][b4];
/*      */             
/* 7015 */             arrayOfFloat9[b4] = arrayOfFloat2[b][b4];
/*      */           } 
/*      */ 
/*      */           
/* 7019 */           if (arrayOfFloat5[0] >= 0.0F) {
/*      */             
/* 7021 */             plot.setColor(Color.black);
/*      */           }
/*      */           else {
/*      */             
/* 7025 */             plot.setColor(Color.red);
/*      */           } 
/*      */ 
/*      */           
/* 7029 */           plot.setLineWidth(1);
/*      */           
/* 7031 */           plot.addPoints(arrayOfFloat8, arrayOfFloat9, 2);
/*      */           
/* 7033 */           plot.setLineWidth(3);
/*      */           
/* 7035 */           plot.addPoints(arrayOfFloat4, arrayOfFloat5, 0);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7043 */       ImageProcessor imageProcessor = plot.getProcessor();
/*      */       
/* 7045 */       if (b3 == 1)
/*      */       {
/* 7047 */         imageStack = new ImageStack(imageProcessor.getWidth(), imageProcessor.getHeight());
/*      */       }
/* 7049 */       imageStack.addSlice(null, imageProcessor);
/*      */       
/* 7051 */       b3++;
/*      */     } 
/*      */ 
/*      */     
/* 7055 */     (new ImagePlus("Chemotaxis Animation for " + str2, imageStack)).show();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void plotSector() {
/* 7069 */     String str = (String)this.gui.sectorDataset.getSelectedItem();
/*      */     
/* 7071 */     if (str.equals("All datasets")) {
/*      */       
/* 7073 */       int i = this.gui.sectorDataset.getItemCount();
/*      */       
/* 7075 */       for (byte b = 0; b < i - 1; b++)
/*      */       {
/* 7077 */         str = this.gui.sectorDataset.getItemAt(b);
/*      */         
/* 7079 */         PlotWindow plotWindow = (PlotWindow)this._hashWindow.get(str);
/*      */         
/* 7081 */         ArrayList arrayList = (ArrayList)this._hashPlot.get(str);
/*      */         
/* 7083 */         int j = ((Integer)arrayList.get(0)).intValue();
/*      */         
/* 7085 */         int k = ((Integer)arrayList.get(1)).intValue();
/*      */         
/* 7087 */         int m = ((Integer)arrayList.get(2)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7093 */         plotGraph(j, k);
/*      */ 
/*      */ 
/*      */         
/* 7097 */         float f1 = angleCorrection(this._anglePosition + this._angleBetweenCircle / 2.0F);
/*      */         
/* 7099 */         float f2 = angleCorrection(this._anglePosition - this._angleBetweenCircle / 2.0F);
/*      */ 
/*      */ 
/*      */         
/* 7103 */         float[] arrayOfFloat1 = calculatePoints(f1);
/*      */         
/* 7105 */         float[] arrayOfFloat2 = { 0, arrayOfFloat1[0] };
/*      */         
/* 7107 */         float[] arrayOfFloat3 = { 0, arrayOfFloat1[1] };
/*      */ 
/*      */ 
/*      */         
/* 7111 */         arrayOfFloat1 = calculatePoints(f2);
/*      */ 
/*      */ 
/*      */         
/* 7115 */         float[] arrayOfFloat4 = { 0, arrayOfFloat1[0] };
/*      */         
/* 7117 */         float[] arrayOfFloat5 = { 0, arrayOfFloat1[1] };
/*      */ 
/*      */ 
/*      */         
/* 7121 */         plotWindow.setColor(Color.green);
/*      */         
/* 7123 */         plotWindow.setLineWidth(2);
/*      */         
/* 7125 */         plotWindow.addPoints(arrayOfFloat2, arrayOfFloat3, 2);
/*      */         
/* 7127 */         plotWindow.addPoints(arrayOfFloat4, arrayOfFloat5, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7133 */         int n = countCells(this._angleBetweenCircle, k);
/*      */         
/* 7135 */         this._currentSelectedDataset = k;
/*      */         
/* 7137 */         this.gui.countsInsideSectorField.setText("see plot");
/*      */         
/* 7139 */         this.gui.countsOutsideSectorField.setText("see plot");
/*      */ 
/*      */ 
/*      */         
/* 7143 */         plotWindow.setColor(Color.black);
/*      */         
/* 7145 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 7147 */           plotWindow.addLabel(0.0D, 0.08D, "Counts in sector: " + n + " Counts outside: " + (m - n));
/*      */           
/* 7149 */           plotWindow.addLabel(0.0D, 0.12D, "Interior angle [deg]: " + this._angleBetweenCircle + " Angle [deg]: " + this._anglePosition);
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */           
/* 7155 */           plotWindow.addLabel(0.0D, 0.04D, "Counts in sector: " + n + " Counts outside: " + (m - n));
/*      */           
/* 7157 */           plotWindow.addLabel(0.0D, 0.08D, "Interior angle [deg]: " + this._angleBetweenCircle + " Angle [deg]: " + this._anglePosition);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 7167 */       PlotWindow plotWindow = (PlotWindow)this._hashWindow.get(str);
/*      */       
/* 7169 */       ArrayList arrayList = (ArrayList)this._hashPlot.get(str);
/*      */       
/* 7171 */       int i = ((Integer)arrayList.get(0)).intValue();
/*      */       
/* 7173 */       int j = ((Integer)arrayList.get(1)).intValue();
/*      */       
/* 7175 */       int k = ((Integer)arrayList.get(2)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7181 */       plotGraph(i, j);
/*      */ 
/*      */ 
/*      */       
/* 7185 */       float f1 = angleCorrection(this._anglePosition + this._angleBetweenCircle / 2.0F);
/*      */       
/* 7187 */       float f2 = angleCorrection(this._anglePosition - this._angleBetweenCircle / 2.0F);
/*      */ 
/*      */ 
/*      */       
/* 7191 */       float[] arrayOfFloat1 = calculatePoints(f1);
/*      */       
/* 7193 */       float[] arrayOfFloat2 = { 0, arrayOfFloat1[0] };
/*      */       
/* 7195 */       float[] arrayOfFloat3 = { 0, arrayOfFloat1[1] };
/*      */ 
/*      */ 
/*      */       
/* 7199 */       arrayOfFloat1 = calculatePoints(f2);
/*      */ 
/*      */ 
/*      */       
/* 7203 */       float[] arrayOfFloat4 = { 0, arrayOfFloat1[0] };
/*      */       
/* 7205 */       float[] arrayOfFloat5 = { 0, arrayOfFloat1[1] };
/*      */ 
/*      */ 
/*      */       
/* 7209 */       plotWindow.setColor(Color.green);
/*      */       
/* 7211 */       plotWindow.setLineWidth(2);
/*      */       
/* 7213 */       plotWindow.addPoints(arrayOfFloat2, arrayOfFloat3, 2);
/*      */       
/* 7215 */       plotWindow.addPoints(arrayOfFloat4, arrayOfFloat5, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7221 */       int m = countCells(this._angleBetweenCircle, j);
/*      */       
/* 7223 */       this._currentSelectedDataset = j;
/*      */       
/* 7225 */       this.gui.countsInsideSectorField.setText(String.valueOf(m));
/*      */       
/* 7227 */       this.gui.countsOutsideSectorField.setText(String.valueOf(k - m));
/*      */ 
/*      */ 
/*      */       
/* 7231 */       plotWindow.setColor(Color.black);
/*      */       
/* 7233 */       if (this.gui.showCenterofMass.isSelected()) {
/*      */         
/* 7235 */         plotWindow.addLabel(0.0D, 0.08D, "Counts in sector: " + m + " Counts outside: " + (k - m));
/*      */         
/* 7237 */         plotWindow.addLabel(0.0D, 0.12D, "Interior angle [deg]: " + this._angleBetweenCircle + " Angle [deg]: " + this._anglePosition);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 7243 */         plotWindow.addLabel(0.0D, 0.04D, "Counts in sector: " + m + " Counts outside: " + (k - m));
/*      */         
/* 7245 */         plotWindow.addLabel(0.0D, 0.08D, "Interior angle [deg]: " + this._angleBetweenCircle + " Angle [deg]: " + this._anglePosition);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float[] calculatePoints(float paramFloat) {
/* 7259 */     float f1 = this._coordSize * 2.0F;
/*      */     
/* 7261 */     double d1 = f1 * Math.cos(Math.toRadians(paramFloat));
/*      */     
/* 7263 */     double d2 = f1 * Math.sin(Math.toRadians(paramFloat));
/*      */     
/* 7265 */     Float float_1 = new Float(d1);
/*      */     
/* 7267 */     Float float_2 = new Float(d2);
/*      */     
/* 7269 */     float f2 = roundNumber(float_1.floatValue());
/*      */     
/* 7271 */     float f3 = roundNumber(float_2.floatValue());
/*      */     
/* 7273 */     return new float[] { f2, f3 };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void plotCircle(int paramInt) {
/* 7287 */     String str = (String)this.gui.sectorDataset.getSelectedItem();
/*      */     
/* 7289 */     if (str.equals("All datasets")) {
/*      */       
/* 7291 */       int i = this.gui.sectorDataset.getItemCount();
/*      */       
/* 7293 */       for (byte b = 0; b < i - 1; b++)
/*      */       {
/* 7295 */         str = this.gui.sectorDataset.getItemAt(b);
/*      */         
/* 7297 */         PlotWindow plotWindow = (PlotWindow)this._hashWindow.get(str);
/*      */         
/* 7299 */         ArrayList arrayList1 = (ArrayList)this._hashPlot.get(str);
/*      */         
/* 7301 */         int j = ((Integer)arrayList1.get(0)).intValue();
/*      */         
/* 7303 */         int k = ((Integer)arrayList1.get(1)).intValue();
/*      */         
/* 7305 */         int m = ((Integer)arrayList1.get(2)).intValue();
/*      */         
/* 7307 */         ArrayList arrayList2 = (ArrayList)this._hashSliceNumber.get(new Integer(k / 2));
/*      */ 
/*      */ 
/*      */         
/* 7311 */         float[][] arrayOfFloat1 = this._listArrayList.get(k);
/*      */         
/* 7313 */         float[][] arrayOfFloat2 = this._listArrayList.get(k + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7319 */         plotGraph(j, k);
/*      */ 
/*      */ 
/*      */         
/* 7323 */         float[] arrayOfFloat3 = new float[360];
/*      */         
/* 7325 */         float[] arrayOfFloat4 = new float[360];
/*      */         
/* 7327 */         for (byte b1 = 0; b1 < 'Ũ'; b1++) {
/*      */           
/* 7329 */           arrayOfFloat3[b1] = (new Double(Math.cos(Math.toRadians(b1)) * paramInt))
/*      */             
/* 7331 */             .floatValue();
/*      */           
/* 7333 */           arrayOfFloat4[b1] = (new Double(Math.sin(Math.toRadians(b1)) * paramInt))
/*      */             
/* 7335 */             .floatValue();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7341 */         plotWindow.setColor(Color.green);
/*      */         
/* 7343 */         plotWindow.setLineWidth(2);
/*      */         
/* 7345 */         plotWindow.addPoints(arrayOfFloat3, arrayOfFloat4, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7351 */         byte b2 = 0;
/*      */         
/* 7353 */         int n = 0;
/*      */ 
/*      */ 
/*      */         
/* 7357 */         for (byte b3 = 0; b3 < m; b3++) {
/*      */           
/* 7359 */           n = ((Integer)arrayList2.get(b3)).intValue();
/*      */           
/* 7361 */           float f1 = arrayOfFloat1[b3][n - 1];
/*      */           
/* 7363 */           float f2 = arrayOfFloat2[b3][n - 1];
/*      */           
/* 7365 */           double d = Math.sqrt(Math.pow((new Float(f1))
/*      */                 
/* 7367 */                 .doubleValue(), 2.0D) + 
/*      */               
/* 7369 */               Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */           
/* 7371 */           if (d <= paramInt)
/*      */           {
/* 7373 */             b2++;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 7379 */         this.gui.countsInsideCircleField.setText("see plot");
/*      */         
/* 7381 */         int i1 = m - b2;
/*      */         
/* 7383 */         this.gui.countsOutsideCircleField.setText("see plot");
/*      */ 
/*      */ 
/*      */         
/* 7387 */         plotWindow.setColor(Color.black);
/*      */         
/* 7389 */         if (this.gui.showCenterofMass.isSelected())
/*      */         {
/* 7391 */           plotWindow.addLabel(0.0D, 0.08D, "Counts inside circle: " + b2 + " Counts outside: " + i1);
/*      */           
/* 7393 */           plotWindow.addLabel(0.0D, 0.12D, "Radius [" + this._unitsPath + "]: " + paramInt);
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */           
/* 7399 */           plotWindow.addLabel(0.0D, 0.04D, "Counts inside circle: " + b2 + " Counts outside: " + i1);
/*      */           
/* 7401 */           plotWindow.addLabel(0.0D, 0.08D, "Radius [" + this._unitsPath + "]: " + paramInt);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 7411 */       PlotWindow plotWindow = (PlotWindow)this._hashWindow.get(str);
/*      */       
/* 7413 */       ArrayList arrayList1 = (ArrayList)this._hashPlot.get(str);
/*      */       
/* 7415 */       int i = ((Integer)arrayList1.get(0)).intValue();
/*      */       
/* 7417 */       int j = ((Integer)arrayList1.get(1)).intValue();
/*      */       
/* 7419 */       int k = ((Integer)arrayList1.get(2)).intValue();
/*      */       
/* 7421 */       ArrayList arrayList2 = (ArrayList)this._hashSliceNumber.get(new Integer(j / 2));
/*      */ 
/*      */ 
/*      */       
/* 7425 */       float[][] arrayOfFloat1 = this._listArrayList.get(j);
/*      */       
/* 7427 */       float[][] arrayOfFloat2 = this._listArrayList.get(j + 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7433 */       plotGraph(i, j);
/*      */ 
/*      */ 
/*      */       
/* 7437 */       float[] arrayOfFloat3 = new float[360];
/*      */       
/* 7439 */       float[] arrayOfFloat4 = new float[360];
/*      */       
/* 7441 */       for (byte b1 = 0; b1 < 'Ũ'; b1++) {
/*      */         
/* 7443 */         arrayOfFloat3[b1] = (new Double(Math.cos(Math.toRadians(b1)) * paramInt))
/*      */           
/* 7445 */           .floatValue();
/*      */         
/* 7447 */         arrayOfFloat4[b1] = (new Double(Math.sin(Math.toRadians(b1)) * paramInt))
/*      */           
/* 7449 */           .floatValue();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7455 */       plotWindow.setColor(Color.green);
/*      */       
/* 7457 */       plotWindow.setLineWidth(2);
/*      */       
/* 7459 */       plotWindow.addPoints(arrayOfFloat3, arrayOfFloat4, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7465 */       byte b2 = 0;
/*      */       
/* 7467 */       int m = 0;
/*      */ 
/*      */ 
/*      */       
/* 7471 */       for (byte b3 = 0; b3 < k; b3++) {
/*      */         
/* 7473 */         m = ((Integer)arrayList2.get(b3)).intValue();
/*      */         
/* 7475 */         float f1 = arrayOfFloat1[b3][m - 1];
/*      */         
/* 7477 */         float f2 = arrayOfFloat2[b3][m - 1];
/*      */         
/* 7479 */         double d = Math.sqrt(Math.pow((new Float(f1))
/*      */               
/* 7481 */               .doubleValue(), 2.0D) + 
/*      */             
/* 7483 */             Math.pow((new Float(f2)).doubleValue(), 2.0D));
/*      */         
/* 7485 */         if (d <= paramInt)
/*      */         {
/* 7487 */           b2++;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 7493 */       this.gui.countsInsideCircleField.setText(String.valueOf(b2));
/*      */       
/* 7495 */       int n = k - b2;
/*      */       
/* 7497 */       this.gui.countsOutsideCircleField.setText(String.valueOf(n));
/*      */ 
/*      */ 
/*      */       
/* 7501 */       plotWindow.setColor(Color.black);
/*      */       
/* 7503 */       if (this.gui.showCenterofMass.isSelected()) {
/*      */         
/* 7505 */         plotWindow.addLabel(0.0D, 0.08D, "Counts inside circle: " + b2 + " Counts outside: " + n);
/*      */         
/* 7507 */         plotWindow.addLabel(0.0D, 0.12D, "Radius [" + this._unitsPath + "]: " + paramInt);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 7513 */         plotWindow.addLabel(0.0D, 0.04D, "Counts inside circle: " + b2 + " Counts outside: " + n);
/*      */         
/* 7515 */         plotWindow.addLabel(0.0D, 0.08D, "Radius [" + this._unitsPath + "]: " + paramInt);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double roundDoubleNumbers(double paramDouble) {
/* 7533 */     double d = paramDouble;
/*      */     
/* 7535 */     d *= 100.0D;
/*      */     
/* 7537 */     d = Math.round(d);
/*      */     
/* 7539 */     d /= 100.0D;
/*      */     
/* 7541 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float roundFloatNumbers(float paramFloat) {
/* 7549 */     float f = paramFloat;
/*      */     
/* 7551 */     f *= 100.0F;
/*      */     
/* 7553 */     f = Math.round(f);
/*      */     
/* 7555 */     f /= 100.0F;
/*      */     
/* 7557 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float roundNumber(float paramFloat) {
/* 7567 */     float f = paramFloat * 10000.0F;
/*      */     
/* 7569 */     f = Math.round(f);
/*      */     
/* 7571 */     f /= 10000.0F;
/*      */     
/* 7573 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   float angleCorrection(float paramFloat) {
/* 7579 */     float f = paramFloat;
/*      */     
/* 7581 */     if (f < 0.0F) {
/*      */       
/* 7583 */       f %= 360.0F;
/*      */       
/* 7585 */       f += 360.0F;
/*      */     } 
/*      */ 
/*      */     
/* 7589 */     if (f > 360.0F)
/*      */     {
/* 7591 */       f %= 360.0F;
/*      */     }
/*      */ 
/*      */     
/* 7595 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stateChanged(ChangeEvent paramChangeEvent) {
/* 7602 */     JTabbedPane jTabbedPane = (JTabbedPane)paramChangeEvent.getSource();
/*      */     
/* 7604 */     int i = jTabbedPane.getSelectedIndex();
/*      */ 
/*      */     
/* 7607 */     if (i == 1) {
/* 7608 */       if (this._dialog.auto) {
/* 7609 */         PlotWindow.plotHeight = this._plotHeight;
/* 7610 */         PlotWindow.plotWidth = this._plotWidth;
/*      */       } else {
/*      */         
/* 7613 */         PlotWindow.plotHeight = (int)(this._dialog.fraction * (Math.abs(this._dialog.minimumY) + Math.abs(this._dialog.maximumY)));
/*      */         
/* 7615 */         PlotWindow.plotWidth = (int)(this._dialog.fraction * (Math.abs(this._dialog.minimumX) + Math.abs(this._dialog.maximumX)));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 7621 */     if (i == 3) {
/*      */       
/* 7623 */       PlotWindow.plotHeight = this._plotHeight;
/* 7624 */       PlotWindow.plotWidth = this._plotWidth;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/chemotaxis_tool.jar!/Chemotaxis_Tool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */