/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.CardLayout;
/*      */ import java.awt.Container;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Toolkit;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.BoxLayout;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTextField;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ChemotaxisGUI
/*      */   extends JFrame
/*      */ {
/*      */   JPanel cardPanelSector;
/*      */   JPanel cardPanelStatistics;
/*      */   JPanel selectedThresholds;
/*      */   JTextField angleInteriorCircleField;
/*      */   JTextField numberofUsedTracksField;
/*      */   JTextField numberofUsedTracksFieldExtRayleigh;
/*      */   JTextField angleInteriorDiagramField;
/*      */   JTextField anglePosField;
/*      */   JTextField countsInsideSectorField;
/*      */   JTextField anglePosDensityField;
/*      */   JTextField countsOutsideSectorField;
/*      */   JTextField countsInsideCircleField;
/*      */   JTextField countsOutsideCircleField;
/*      */   JTextField radiusCircleField;
/*      */   JTextField firstSplitField;
/*      */   JTextField secondSplitField;
/*      */   JTextField firstThresPathField;
/*      */   JTextField secondThresPathField;
/*      */   JTextField firstThresVelocityField;
/*      */   JTextField secondThresVelocityField;
/*      */   JTextField firstSlicesField;
/*      */   JTextField secondSlicesField;
/*      */   JTextField xyCalibrationField;
/*      */   JTextField timeSettingsField;
/*      */   JTextField colorBorderField;
/*      */   JTextField diagramRangeField;
/*      */   JTextField scaleManuallyField;
/*      */   JTextField rangeVelocityField;
/*      */   JTextField minDistancefromOriginField;
/*      */   JTextField pValueField;
/*      */   JTextField pValueFieldExtRayleigh;
/*      */   JButton butRayleighTest;
/*      */   JButton butExtRayleighTest;
/*      */   JButton butshowMax;
/*      */   JButton butsetAxisScaling;
/*      */   JButton butaddDataset;
/*      */   JButton butFMISliceSeries;
/*      */   JButton butFMITrackSeries;
/*      */   JButton butDirectionalitySliceSeries;
/*      */   JButton butDirectionalityTrackSeries;
/*      */   JButton butVelocityTrackSeries;
/*      */   JButton butDistanceTrackSeries;
/*      */   JButton butclearAllDatasets;
/*      */   JButton butcenterofMassStat;
/*      */   JButton butplotGraph;
/*      */   JButton butshowHistogram;
/*      */   JButton butshowRoseDiagram;
/*      */   JButton butshowCircularPlot;
/*      */   JButton butturnRight;
/*      */   JButton butturnLeft;
/*      */   JButton butopenSector;
/*      */   JButton butcloseSector;
/*      */   JButton butopenRadius;
/*      */   JButton butcloseRadius;
/*      */   JButton butshowCircle;
/*      */   JButton butCompute;
/*      */   JButton butshowSector;
/*      */   JButton butplotVelocityHistogram;
/*      */   JButton butImport;
/*      */   JButton butcloseAllPlots;
/*      */   JButton butselectDataset;
/*      */   JButton butShowOriginalDataset;
/*      */   JButton butanimateGraph;
/*      */   JButton butshowDatasetInformation;
/*      */   JButton butshowThresholdFunctions;
/*      */   JButton butshowcurrentData;
/*      */   JButton butshowZantlPlot;
/*      */   JComboBox selectionDistance;
/*      */   JComboBox importedDataset;
/*      */   JComboBox statisticDataset;
/*      */   JComboBox extendedstatisticDataset;
/*      */   JComboBox timeUnits;
/*      */   JComboBox pathUnits;
/*      */   JComboBox plotSize;
/*      */   JComboBox markingAnimation;
/*      */   JComboBox plotSelection;
/*      */   JComboBox numberofSlicesType;
/*      */   JComboBox sectorDataset;
/*      */   JComboBox selectionBoundary;
/*      */   JComboBox pathSelection;
/*      */   JComboBox velocitySelection;
/*      */   JComboBox velocityDataset;
/*      */   JComboBox plotAnimation;
/*      */   JComboBox statisticSelection;
/*      */   JComboBox selectedDataset1;
/*      */   JComboBox selectedDataset2;
/*      */   JComboBox selectedDataset3;
/*      */   JComboBox selectedDataset4;
/*      */   JCheckBox thresholdPathBox;
/*      */   JCheckBox thresholdVelocityBox;
/*      */   JCheckBox openNewPlotBox;
/*      */   JCheckBox openDiagramBox;
/*      */   JCheckBox showDataTablesBox;
/*      */   JCheckBox showCenterofMass;
/*      */   JCheckBox showAdditionalInfo;
/*      */   JCheckBox showAdditionalInfoDiagram;
/*      */   JCheckBox splitBox;
/*      */   JCheckBox plotEndpoints;
/*      */   JCheckBox selectedData1;
/*      */   JCheckBox selectedData2;
/*      */   JCheckBox selectedData3;
/*      */   JCheckBox selectedData4;
/*      */   JRadioButton accumulatedDistance;
/*      */   JRadioButton euclideanDistance;
/*      */   JLabel distanceThresholdLabel;
/*      */   JLabel distanceRayleighLabel;
/*      */   JLabel velocityThresholdLabel;
/*      */   JLabel rangeVelocityLabel;
/*      */   JLabel radiusLabel;
/*      */   
/*      */   public ChemotaxisGUI(Chemotaxis_Tool paramChemotaxis_Tool) {
/*  228 */     super("Chemotaxis and Migration Tool");
/*  229 */     Container container = getContentPane();
/*  230 */     container.setLayout(new BoxLayout(container, 1));
/*  231 */     addWindowListener(paramChemotaxis_Tool);
/*      */ 
/*      */     
/*  234 */     JPanel jPanel1 = new JPanel();
/*  235 */     jPanel1.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  237 */     jPanel1.add(new JLabel(""));
/*  238 */     jPanel1.add(new JLabel(""));
/*  239 */     jPanel1.add(new JLabel(""));
/*  240 */     jPanel1.add(new JLabel(""));
/*      */     
/*  242 */     this.selectedData1 = new JCheckBox("Selected Dataset 1", false);
/*  243 */     this.selectedDataset1 = new JComboBox();
/*  244 */     this.selectedData2 = new JCheckBox("Selected Dataset 2", false);
/*  245 */     this.selectedDataset2 = new JComboBox();
/*  246 */     jPanel1.add(this.selectedData1);
/*  247 */     jPanel1.add(this.selectedDataset1);
/*  248 */     jPanel1.add(this.selectedData2);
/*  249 */     jPanel1.add(this.selectedDataset2);
/*      */     
/*  251 */     this.selectedData3 = new JCheckBox("Selected Dataset 3", false);
/*  252 */     this.selectedDataset3 = new JComboBox();
/*  253 */     this.selectedData4 = new JCheckBox("Selected Dataset 4", false);
/*  254 */     this.selectedDataset4 = new JComboBox();
/*  255 */     jPanel1.add(this.selectedData3);
/*  256 */     jPanel1.add(this.selectedDataset3);
/*  257 */     jPanel1.add(this.selectedData4);
/*  258 */     jPanel1.add(this.selectedDataset4);
/*      */     
/*  260 */     jPanel1.add(new JLabel(""));
/*  261 */     jPanel1.add(new JLabel(""));
/*  262 */     jPanel1.add(new JLabel(""));
/*  263 */     jPanel1.add(new JLabel(""));
/*      */     
/*  265 */     this.butshowThresholdFunctions = new JButton("Open restrictions");
/*  266 */     this.butshowThresholdFunctions.addActionListener(paramChemotaxis_Tool);
/*  267 */     jPanel1.add(this.butshowThresholdFunctions);
/*  268 */     jPanel1.add(new JLabel(""));
/*  269 */     jPanel1.add(new JLabel(""));
/*  270 */     jPanel1.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */     
/*  274 */     this.selectedThresholds = new JPanel();
/*  275 */     this.selectedThresholds.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  277 */     this.splitBox = new JCheckBox("Split dataset");
/*  278 */     this.splitBox
/*  279 */       .setToolTipText("<html>Splits the dataset<br>at the specified position</html>");
/*  280 */     this.selectedThresholds.add(this.splitBox);
/*  281 */     this.selectedThresholds.add(new JLabel(""));
/*  282 */     this.selectedThresholds.add(new JLabel(""));
/*  283 */     this.selectedThresholds.add(new JLabel(""));
/*      */     
/*  285 */     this.selectedThresholds.add(new JLabel("From slice .. to .."));
/*  286 */     this.firstSplitField = new JTextField();
/*  287 */     this.selectedThresholds.add(this.firstSplitField);
/*  288 */     this.secondSplitField = new JTextField();
/*  289 */     this.selectedThresholds.add(this.secondSplitField);
/*  290 */     this.selectedThresholds.add(new JLabel(""));
/*      */ 
/*      */     
/*  293 */     this.thresholdPathBox = new JCheckBox("Set threshold distance", false);
/*  294 */     this.thresholdPathBox
/*  295 */       .setToolTipText("<html>only values less or greater <br>than threshold value are taken</html>");
/*  296 */     this.selectedThresholds.add(this.thresholdPathBox);
/*  297 */     this.accumulatedDistance = new JRadioButton("Accumulated distance", true);
/*  298 */     this.euclideanDistance = new JRadioButton("Euclidean distance", false);
/*      */     
/*  300 */     ButtonGroup buttonGroup = new ButtonGroup();
/*  301 */     buttonGroup.add(this.accumulatedDistance);
/*  302 */     buttonGroup.add(this.euclideanDistance);
/*  303 */     this.selectedThresholds.add(this.accumulatedDistance);
/*  304 */     this.selectedThresholds.add(this.euclideanDistance);
/*  305 */     this.selectedThresholds.add(new JLabel(""));
/*      */ 
/*      */     
/*  308 */     this.distanceThresholdLabel = new JLabel("Threshold value [unit]:");
/*  309 */     this.selectedThresholds.add(this.distanceThresholdLabel);
/*  310 */     this.pathSelection = new JComboBox();
/*  311 */     this.pathSelection.addItem("less than");
/*  312 */     this.pathSelection.addItem("more than");
/*  313 */     this.pathSelection.addItem("between");
/*  314 */     this.pathSelection.setSelectedItem("less than");
/*  315 */     this.pathSelection.addItemListener(paramChemotaxis_Tool);
/*  316 */     this.selectedThresholds.add(this.pathSelection);
/*  317 */     this.firstThresPathField = new JTextField();
/*  318 */     this.selectedThresholds.add(this.firstThresPathField);
/*  319 */     this.secondThresPathField = new JTextField();
/*  320 */     this.selectedThresholds.add(this.secondThresPathField);
/*      */     
/*  322 */     this.thresholdVelocityBox = new JCheckBox("Set threshold velocity", false);
/*  323 */     this.thresholdVelocityBox
/*  324 */       .setToolTipText("<html>only values slower or faster <br>than threshold value are taken</html>");
/*  325 */     this.selectedThresholds.add(this.thresholdVelocityBox);
/*  326 */     this.selectedThresholds.add(new JLabel(""));
/*  327 */     this.selectedThresholds.add(new JLabel(""));
/*  328 */     this.selectedThresholds.add(new JLabel(""));
/*      */ 
/*      */     
/*  331 */     this.velocityThresholdLabel = new JLabel("Threshold value [unit/sec]:");
/*  332 */     this.selectedThresholds.add(this.velocityThresholdLabel);
/*  333 */     this.velocitySelection = new JComboBox();
/*  334 */     this.velocitySelection.addItem("slower than");
/*  335 */     this.velocitySelection.addItem("faster than");
/*  336 */     this.velocitySelection.addItem("between");
/*  337 */     this.velocitySelection.setSelectedItem("slower than");
/*  338 */     this.velocitySelection.addItemListener(paramChemotaxis_Tool);
/*  339 */     this.selectedThresholds.add(this.velocitySelection);
/*  340 */     this.firstThresVelocityField = new JTextField();
/*  341 */     this.secondThresVelocityField = new JTextField();
/*  342 */     this.selectedThresholds.add(this.firstThresVelocityField);
/*  343 */     this.selectedThresholds.add(this.secondThresVelocityField);
/*  344 */     this.selectedThresholds.setBorder(BorderFactory.createEtchedBorder(1));
/*      */ 
/*      */     
/*  347 */     JPanel jPanel2 = new JPanel();
/*  348 */     jPanel2.add(new JLabel(""));
/*  349 */     jPanel2.add(new JLabel(""));
/*  350 */     jPanel2.add(new JLabel(""));
/*  351 */     jPanel2.add(new JLabel(""));
/*  352 */     jPanel2.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  354 */     this.butCompute = new JButton("Apply settings");
/*  355 */     this.butCompute.addActionListener(paramChemotaxis_Tool);
/*  356 */     this.butCompute.setToolTipText("<html>Apply all settings</html>");
/*  357 */     jPanel2.add(this.butCompute);
/*  358 */     this.butshowDatasetInformation = new JButton("Show info");
/*  359 */     this.butshowDatasetInformation.setToolTipText("<html>Shows some statistic<br>values about the dataset</html>");
/*  360 */     this.butshowDatasetInformation.addActionListener(paramChemotaxis_Tool);
/*  361 */     jPanel2.add(this.butshowDatasetInformation);
/*  362 */     jPanel2.add(new JLabel(""));
/*  363 */     this.butcloseAllPlots = new JButton("Close all windows");
/*  364 */     this.butcloseAllPlots.addActionListener(paramChemotaxis_Tool);
/*  365 */     jPanel2.add(this.butcloseAllPlots);
/*      */     
/*  367 */     jPanel2.add(new JLabel(""));
/*  368 */     jPanel2.add(new JLabel(""));
/*  369 */     jPanel2.add(new JLabel(""));
/*  370 */     jPanel2.add(new JLabel(""));
/*      */ 
/*      */     
/*  373 */     JPanel jPanel3 = new JPanel();
/*  374 */     jPanel3.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  376 */     jPanel3.add(new JLabel(""));
/*  377 */     jPanel3.add(new JLabel(""));
/*  378 */     jPanel3.add(new JLabel(""));
/*  379 */     jPanel3.add(new JLabel(""));
/*      */     
/*  381 */     this.butplotGraph = new JButton("Plot graph");
/*  382 */     this.butplotGraph.addActionListener(paramChemotaxis_Tool);
/*  383 */     jPanel3.add(this.butplotGraph);
/*  384 */     jPanel3.add(new JLabel("Set marking:"));
/*  385 */     this.plotSelection = new JComboBox();
/*  386 */     this.plotSelection.addItem("No marking");
/*  387 */     this.plotSelection.addItem("Mark up/down");
/*  388 */     this.plotSelection.addItem("Mark left/right");
/*  389 */     this.plotSelection.addItem("Mark more/less accumulated");
/*  390 */     this.plotSelection.addItem("Mark more/less euclid");
/*  391 */     this.plotSelection.addItem("Mark faster/slower");
/*  392 */     this.plotSelection.addItem("Mark directionality");
/*  393 */     this.plotSelection.setSelectedItem("Mark up/down");
/*  394 */     this.plotSelection.addItemListener(paramChemotaxis_Tool);
/*  395 */     jPanel3.add(this.plotSelection);
/*  396 */     this.colorBorderField = new JTextField();
/*  397 */     jPanel3.add(this.colorBorderField);
/*      */ 
/*      */     
/*  400 */     this.butsetAxisScaling = new JButton("Set axis scaling");
/*  401 */     this.butsetAxisScaling.addActionListener(paramChemotaxis_Tool);
/*  402 */     jPanel3.add(this.butsetAxisScaling);
/*  403 */     jPanel3.add(new JLabel(""));
/*  404 */     jPanel3.add(new JLabel(""));
/*  405 */     jPanel3.add(new JLabel(""));
/*      */ 
/*      */     
/*  408 */     this.openNewPlotBox = new JCheckBox("Open in new window", false);
/*  409 */     this.openNewPlotBox.setToolTipText("<html>Opens the graph in a new window</html>");
/*  410 */     jPanel3.add(this.openNewPlotBox);
/*  411 */     this.plotEndpoints = new JCheckBox("Plot only endpoints");
/*  412 */     this.plotEndpoints
/*  413 */       .setToolTipText("<html>If selected only<br>endpoints are plotted</html>");
/*  414 */     jPanel3.add(this.plotEndpoints);
/*  415 */     this.showCenterofMass = new JCheckBox("Show center of mass", true);
/*  416 */     jPanel3.add(this.showCenterofMass);
/*  417 */     this.showAdditionalInfo = new JCheckBox("Show additional info", true);
/*  418 */     jPanel3.add(this.showAdditionalInfo);
/*      */     
/*  420 */     jPanel3.add(new JLabel(""));
/*  421 */     jPanel3.add(new JLabel(""));
/*  422 */     jPanel3.add(new JLabel(""));
/*  423 */     jPanel3.add(new JLabel(""));
/*      */     
/*  425 */     this.butanimateGraph = new JButton("Animate Plot");
/*  426 */     this.butanimateGraph.addActionListener(paramChemotaxis_Tool);
/*  427 */     jPanel3.add(this.butanimateGraph);
/*  428 */     jPanel3.add(new JLabel("Set marking:"));
/*  429 */     this.markingAnimation = new JComboBox();
/*  430 */     this.markingAnimation.addItem("No marking");
/*  431 */     this.markingAnimation.addItem("Mark up/down");
/*  432 */     this.markingAnimation.addItem("Mark left/right");
/*  433 */     jPanel3.add(this.markingAnimation);
/*  434 */     jPanel3.add(new JLabel(""));
/*      */     
/*  436 */     this.plotAnimation = new JComboBox();
/*  437 */     jPanel3.add(this.plotAnimation);
/*  438 */     jPanel3.add(new JLabel(""));
/*  439 */     jPanel3.add(new JLabel(""));
/*  440 */     jPanel3.add(new JLabel(""));
/*  441 */     jPanel3.add(new JLabel(""));
/*  442 */     jPanel3.add(new JLabel(""));
/*  443 */     jPanel3.add(new JLabel(""));
/*  444 */     jPanel3.add(new JLabel(""));
/*      */ 
/*      */     
/*  447 */     JPanel jPanel4 = new JPanel();
/*  448 */     jPanel4.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  450 */     jPanel4.add(new JLabel(""));
/*  451 */     jPanel4.add(new JLabel(""));
/*  452 */     jPanel4.add(new JLabel(""));
/*  453 */     jPanel4.add(new JLabel(""));
/*      */     
/*  455 */     jPanel4.add(new JLabel("Interior angle [deg]:"));
/*  456 */     this.angleInteriorDiagramField = new JTextField("66");
/*  457 */     this.angleInteriorDiagramField.setToolTipText("<html>Range from 1 to 180 degrees</html>");
/*  458 */     jPanel4.add(this.angleInteriorDiagramField);
/*  459 */     jPanel4.add(new JLabel("Range interval [deg]:"));
/*  460 */     this.diagramRangeField = new JTextField("10");
/*  461 */     this.diagramRangeField.setToolTipText("<html>Interval for histogram and Rose plot</html>");
/*  462 */     jPanel4.add(this.diagramRangeField);
/*      */     
/*  464 */     this.butshowHistogram = new JButton("Plot histogram");
/*  465 */     this.butshowHistogram.addActionListener(paramChemotaxis_Tool);
/*  466 */     jPanel4.add(this.butshowHistogram);
/*  467 */     this.butshowRoseDiagram = new JButton("Plot Rose diagram");
/*  468 */     this.butshowRoseDiagram.addActionListener(paramChemotaxis_Tool);
/*  469 */     jPanel4.add(this.butshowRoseDiagram);
/*  470 */     this.butshowCircularPlot = new JButton("Circular plot");
/*  471 */     this.butshowCircularPlot.addActionListener(paramChemotaxis_Tool);
/*  472 */     jPanel4.add(this.butshowCircularPlot);
/*  473 */     jPanel4.add(new JLabel(""));
/*      */     
/*  475 */     jPanel4.add(new JLabel("Angle position [deg]:"));
/*  476 */     this.anglePosDensityField = new JTextField("0");
/*  477 */     jPanel4.add(this.anglePosDensityField);
/*  478 */     jPanel4.add(new JLabel(""));
/*  479 */     jPanel4.add(new JLabel(""));
/*      */     
/*  481 */     this.butshowZantlPlot = new JButton("Density plot");
/*  482 */     this.butshowZantlPlot.addActionListener(paramChemotaxis_Tool);
/*  483 */     jPanel4.add(this.butshowZantlPlot);
/*  484 */     jPanel4.add(new JLabel(""));
/*  485 */     jPanel4.add(new JLabel(""));
/*  486 */     jPanel4.add(new JLabel(""));
/*      */     
/*  488 */     this.openDiagramBox = new JCheckBox("Open in new window", false);
/*  489 */     jPanel4.add(this.openDiagramBox);
/*  490 */     this.showDataTablesBox = new JCheckBox("Show data table", false);
/*  491 */     jPanel4.add(this.showDataTablesBox);
/*  492 */     this.showAdditionalInfoDiagram = new JCheckBox("Show additional info", false);
/*  493 */     jPanel4.add(this.showAdditionalInfoDiagram);
/*  494 */     jPanel4.add(new JLabel(""));
/*      */     
/*  496 */     this.butplotVelocityHistogram = new JButton("Velocity histogram");
/*  497 */     this.butplotVelocityHistogram.addActionListener(paramChemotaxis_Tool);
/*  498 */     jPanel4.add(this.butplotVelocityHistogram);
/*  499 */     this.velocityDataset = new JComboBox();
/*  500 */     jPanel4.add(this.velocityDataset);
/*  501 */     this.rangeVelocityLabel = new JLabel("Range interval [unit/sec]:");
/*  502 */     jPanel4.add(this.rangeVelocityLabel);
/*  503 */     this.rangeVelocityField = new JTextField("");
/*  504 */     jPanel4.add(this.rangeVelocityField);
/*      */     
/*  506 */     jPanel4.add(new JLabel(""));
/*  507 */     jPanel4.add(new JLabel(""));
/*  508 */     jPanel4.add(new JLabel(""));
/*  509 */     jPanel4.add(new JLabel(""));
/*      */ 
/*      */     
/*  512 */     JPanel jPanel5 = new JPanel();
/*  513 */     jPanel5.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  515 */     jPanel5.add(new JLabel(""));
/*  516 */     jPanel5.add(new JLabel(""));
/*  517 */     jPanel5.add(new JLabel(""));
/*  518 */     jPanel5.add(new JLabel(""));
/*      */     
/*  520 */     this.butshowCircle = new JButton("Show circle");
/*  521 */     this.butshowCircle.addActionListener(paramChemotaxis_Tool);
/*  522 */     this.butshowCircle.setEnabled(false);
/*  523 */     jPanel5.add(this.butshowCircle);
/*  524 */     jPanel5.add(new JLabel(""));
/*  525 */     this.radiusLabel = new JLabel("Radius [unit]:");
/*  526 */     jPanel5.add(this.radiusLabel);
/*  527 */     this.radiusCircleField = new JTextField();
/*  528 */     this.radiusCircleField.setText("10");
/*  529 */     jPanel5.add(this.radiusCircleField);
/*      */     
/*  531 */     jPanel5.add(new JLabel("Counts inside:"));
/*  532 */     this.countsInsideCircleField = new JTextField("");
/*  533 */     this.countsInsideCircleField.setEditable(false);
/*  534 */     jPanel5.add(this.countsInsideCircleField);
/*  535 */     jPanel5.add(new JLabel("Counts outside:"));
/*  536 */     this.countsOutsideCircleField = new JTextField("");
/*  537 */     this.countsOutsideCircleField.setEditable(false);
/*  538 */     jPanel5.add(this.countsOutsideCircleField);
/*      */     
/*  540 */     this.butopenRadius = new JButton("Increase radius");
/*  541 */     this.butopenRadius.addActionListener(paramChemotaxis_Tool);
/*  542 */     jPanel5.add(this.butopenRadius);
/*  543 */     this.butcloseRadius = new JButton("Reduce radius");
/*  544 */     this.butcloseRadius.addActionListener(paramChemotaxis_Tool);
/*  545 */     jPanel5.add(this.butcloseRadius);
/*  546 */     jPanel5.add(new JLabel(""));
/*  547 */     jPanel5.add(new JLabel(""));
/*      */     
/*  549 */     jPanel5.add(new JLabel(""));
/*  550 */     jPanel5.add(new JLabel(""));
/*  551 */     jPanel5.add(new JLabel(""));
/*  552 */     jPanel5.add(new JLabel(""));
/*      */     
/*  554 */     jPanel5.add(new JLabel(""));
/*  555 */     jPanel5.add(new JLabel(""));
/*  556 */     jPanel5.add(new JLabel(""));
/*  557 */     jPanel5.add(new JLabel(""));
/*      */     
/*  559 */     jPanel5.add(new JLabel(""));
/*  560 */     jPanel5.add(new JLabel(""));
/*  561 */     jPanel5.add(new JLabel(""));
/*  562 */     jPanel5.add(new JLabel(""));
/*      */     
/*  564 */     JPanel jPanel6 = new JPanel();
/*  565 */     jPanel6.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  567 */     jPanel6.add(new JLabel(""));
/*  568 */     jPanel6.add(new JLabel(""));
/*  569 */     jPanel6.add(new JLabel(""));
/*  570 */     jPanel6.add(new JLabel(""));
/*      */     
/*  572 */     this.butshowSector = new JButton("Show sector");
/*  573 */     this.butshowSector.addActionListener(paramChemotaxis_Tool);
/*  574 */     this.butshowSector.setEnabled(false);
/*  575 */     jPanel6.add(this.butshowSector);
/*  576 */     this.butshowMax = new JButton("Show maxima");
/*  577 */     this.butshowMax.addActionListener(paramChemotaxis_Tool);
/*  578 */     jPanel6.add(this.butshowMax);
/*  579 */     jPanel6.add(new JLabel(""));
/*  580 */     jPanel6.add(new JLabel(""));
/*      */     
/*  582 */     jPanel6.add(new JLabel("Angle position [deg]:"));
/*  583 */     this.anglePosField = new JTextField("0");
/*  584 */     this.anglePosField.addActionListener(paramChemotaxis_Tool);
/*  585 */     jPanel6.add(this.anglePosField);
/*  586 */     jPanel6.add(new JLabel("Interior angle [deg]:"));
/*  587 */     this.angleInteriorCircleField = new JTextField("66");
/*  588 */     this.angleInteriorCircleField.addActionListener(paramChemotaxis_Tool);
/*  589 */     jPanel6.add(this.angleInteriorCircleField);
/*      */     
/*  591 */     jPanel6.add(new JLabel("Counts inside:"));
/*  592 */     this.countsInsideSectorField = new JTextField("");
/*  593 */     this.countsInsideSectorField.setEditable(false);
/*  594 */     jPanel6.add(this.countsInsideSectorField);
/*  595 */     jPanel6.add(new JLabel("Counts outside:"));
/*  596 */     this.countsOutsideSectorField = new JTextField("");
/*  597 */     this.countsOutsideSectorField.setEditable(false);
/*  598 */     jPanel6.add(this.countsOutsideSectorField);
/*      */     
/*  600 */     this.butturnLeft = new JButton("Anti clockwise rotation");
/*  601 */     this.butturnLeft.addActionListener(paramChemotaxis_Tool);
/*  602 */     jPanel6.add(this.butturnLeft);
/*  603 */     this.butturnRight = new JButton("Clockwise rotation");
/*  604 */     this.butturnRight.addActionListener(paramChemotaxis_Tool);
/*  605 */     jPanel6.add(this.butturnRight);
/*  606 */     this.butopenSector = new JButton("Open angle");
/*  607 */     this.butopenSector.addActionListener(paramChemotaxis_Tool);
/*  608 */     jPanel6.add(this.butopenSector);
/*  609 */     this.butcloseSector = new JButton("Close angle");
/*  610 */     this.butcloseSector.addActionListener(paramChemotaxis_Tool);
/*  611 */     jPanel6.add(this.butcloseSector);
/*      */     
/*  613 */     jPanel6.add(new JLabel(""));
/*  614 */     jPanel6.add(new JLabel(""));
/*  615 */     jPanel6.add(new JLabel(""));
/*  616 */     jPanel6.add(new JLabel(""));
/*  617 */     jPanel6.add(new JLabel(""));
/*  618 */     jPanel6.add(new JLabel(""));
/*  619 */     jPanel6.add(new JLabel(""));
/*  620 */     jPanel6.add(new JLabel(""));
/*      */ 
/*      */     
/*  623 */     this.cardPanelSector = new JPanel(new CardLayout());
/*  624 */     this.cardPanelSector.add(jPanel6, "Angular sector");
/*  625 */     this.cardPanelSector.add(jPanel5, "Circular sector");
/*      */ 
/*      */     
/*  628 */     JPanel jPanel7 = new JPanel();
/*  629 */     String[] arrayOfString1 = { "Angular sector", "Circular sector" };
/*  630 */     this.selectionBoundary = new JComboBox(arrayOfString1);
/*  631 */     this.selectionBoundary.setEditable(false);
/*  632 */     this.selectionBoundary.addItemListener(paramChemotaxis_Tool);
/*  633 */     jPanel7.add(this.selectionBoundary);
/*  634 */     this.sectorDataset = new JComboBox();
/*  635 */     this.sectorDataset.addItem("                      ");
/*  636 */     this.sectorDataset.addItemListener(paramChemotaxis_Tool);
/*  637 */     jPanel7.add(this.sectorDataset);
/*  638 */     JPanel jPanel8 = new JPanel(new BorderLayout());
/*  639 */     jPanel8.add(jPanel7, "North");
/*  640 */     jPanel8.add(this.cardPanelSector, "Center");
/*      */ 
/*      */ 
/*      */     
/*  644 */     JPanel jPanel9 = new JPanel();
/*  645 */     jPanel9.setLayout(new GridLayout(0, 4, 5, 5));
/*  646 */     jPanel9.add(new JLabel(""));
/*  647 */     jPanel9.add(new JLabel(""));
/*  648 */     jPanel9.add(new JLabel(""));
/*  649 */     jPanel9.add(new JLabel(""));
/*      */     
/*  651 */     jPanel9.add(new JLabel("Imported datasets:"));
/*  652 */     this.importedDataset = new JComboBox();
/*  653 */     this.importedDataset
/*  654 */       .setToolTipText("<html>Imported Datasets</html>");
/*  655 */     this.importedDataset.addItemListener(paramChemotaxis_Tool);
/*  656 */     jPanel9.add(this.importedDataset);
/*  657 */     jPanel9.add(new JLabel(""));
/*  658 */     jPanel9.add(new JLabel(""));
/*      */     
/*  660 */     jPanel9.add(new JLabel("Number of slices:"));
/*  661 */     this.numberofSlicesType = new JComboBox();
/*  662 */     this.numberofSlicesType.addItem("Use only slices equal to");
/*  663 */     this.numberofSlicesType.addItem("Use slice range from.. to..");
/*  664 */     this.numberofSlicesType.setSelectedItem("Use only slices equal to");
/*  665 */     this.numberofSlicesType.addItemListener(paramChemotaxis_Tool);
/*  666 */     jPanel9.add(this.numberofSlicesType);
/*  667 */     this.firstSlicesField = new JTextField();
/*  668 */     jPanel9.add(this.firstSlicesField);
/*  669 */     this.secondSlicesField = new JTextField();
/*  670 */     jPanel9.add(this.secondSlicesField);
/*      */     
/*  672 */     jPanel9.add(new JLabel(""));
/*  673 */     jPanel9.add(new JLabel(""));
/*  674 */     jPanel9.add(new JLabel(""));
/*  675 */     jPanel9.add(new JLabel(""));
/*      */     
/*  677 */     this.butShowOriginalDataset = new JButton("Show original data");
/*  678 */     this.butShowOriginalDataset.addActionListener(paramChemotaxis_Tool);
/*  679 */     jPanel9.add(this.butShowOriginalDataset);
/*  680 */     this.butshowcurrentData = new JButton("Show current data");
/*  681 */     this.butshowcurrentData.addActionListener(paramChemotaxis_Tool);
/*  682 */     jPanel9.add(this.butshowcurrentData);
/*  683 */     this.butaddDataset = new JButton("Add dataset");
/*  684 */     this.butaddDataset.addActionListener(paramChemotaxis_Tool);
/*  685 */     jPanel9.add(this.butaddDataset);
/*  686 */     this.butclearAllDatasets = new JButton("Remove all datasets");
/*  687 */     this.butclearAllDatasets.addActionListener(paramChemotaxis_Tool);
/*  688 */     jPanel9.add(this.butclearAllDatasets);
/*      */     
/*  690 */     jPanel9.add(new JLabel(""));
/*  691 */     jPanel9.add(new JLabel(""));
/*  692 */     jPanel9.add(new JLabel(""));
/*  693 */     jPanel9.add(new JLabel(""));
/*      */     
/*  695 */     jPanel9.add(new JLabel(""));
/*  696 */     jPanel9.add(new JLabel(""));
/*  697 */     jPanel9.add(new JLabel(""));
/*  698 */     this.butImport = new JButton("Import data");
/*  699 */     this.butImport.addActionListener(paramChemotaxis_Tool);
/*  700 */     jPanel9.add(this.butImport);
/*      */     
/*  702 */     jPanel9.add(new JLabel(""));
/*  703 */     jPanel9.add(new JLabel(""));
/*  704 */     jPanel9.add(new JLabel(""));
/*  705 */     jPanel9.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */     
/*  709 */     JPanel jPanel10 = new JPanel();
/*  710 */     jPanel10.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  712 */     jPanel10.add(new JLabel(""));
/*  713 */     jPanel10.add(new JLabel(""));
/*  714 */     jPanel10.add(new JLabel(""));
/*  715 */     jPanel10.add(new JLabel(""));
/*      */     
/*  717 */     jPanel10.add(new JLabel("X/Y Calibration"));
/*  718 */     this.xyCalibrationField = new JTextField("1.0");
/*  719 */     this.xyCalibrationField
/*  720 */       .setToolTipText("<html>XY Calibration respective<br>to your microscope environment</html>");
/*  721 */     jPanel10.add(this.xyCalibrationField);
/*  722 */     this.pathUnits = new JComboBox();
/*  723 */     this.pathUnits.addItem("mm");
/*  724 */     this.pathUnits.addItem("µm");
/*  725 */     this.pathUnits.addItem("nm");
/*  726 */     this.pathUnits.addItem("unit");
/*  727 */     this.pathUnits.setSelectedItem("unit");
/*  728 */     this.pathUnits.addItemListener(paramChemotaxis_Tool);
/*  729 */     jPanel10.add(this.pathUnits);
/*  730 */     jPanel10.add(new JLabel(""));
/*      */     
/*  732 */     jPanel10.add(new JLabel("Time interval"));
/*  733 */     this.timeSettingsField = new JTextField("2.0");
/*  734 */     this.timeSettingsField
/*  735 */       .setToolTipText("<html>Sets the time interval between slicesField</html>");
/*  736 */     jPanel10.add(this.timeSettingsField);
/*  737 */     this.timeUnits = new JComboBox();
/*  738 */     this.timeUnits.addItem("sec");
/*  739 */     this.timeUnits.addItem("min");
/*  740 */     this.timeUnits.addItem("unit");
/*  741 */     this.timeUnits.setSelectedItem("sec");
/*  742 */     this.timeUnits.addItemListener(paramChemotaxis_Tool);
/*  743 */     jPanel10.add(this.timeUnits);
/*  744 */     jPanel10.add(new JLabel(""));
/*      */     
/*  746 */     jPanel10.add(new JLabel("Plot size [pixel]"));
/*  747 */     this.plotSize = new JComboBox();
/*  748 */     this.plotSize.addItem("400x400");
/*  749 */     this.plotSize.addItem("450x450");
/*  750 */     this.plotSize.addItem("500x500");
/*  751 */     this.plotSize.setSelectedItem("500x500");
/*  752 */     this.plotSize.addItemListener(paramChemotaxis_Tool);
/*  753 */     jPanel10.add(this.plotSize);
/*  754 */     jPanel10.add(new JLabel(""));
/*  755 */     jPanel10.add(new JLabel(""));
/*      */ 
/*      */     
/*  758 */     jPanel10.add(new JLabel(""));
/*  759 */     jPanel10.add(new JLabel(""));
/*  760 */     jPanel10.add(new JLabel(""));
/*  761 */     jPanel10.add(new JLabel(""));
/*  762 */     jPanel10.add(new JLabel(""));
/*  763 */     jPanel10.add(new JLabel(""));
/*  764 */     jPanel10.add(new JLabel(""));
/*  765 */     jPanel10.add(new JLabel(""));
/*  766 */     jPanel10.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */     
/*  770 */     JPanel jPanel11 = new JPanel();
/*  771 */     jPanel11.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  773 */     jPanel11.add(new JLabel(""));
/*  774 */     jPanel11.add(new JLabel(""));
/*  775 */     jPanel11.add(new JLabel(""));
/*  776 */     jPanel11.add(new JLabel(""));
/*      */     
/*  778 */     jPanel11.add(new JLabel("<html><b>Slice series: </b></html>"));
/*  779 */     jPanel11.add(new JLabel(""));
/*  780 */     jPanel11.add(new JLabel("<html><b>Track series: </b></html>"));
/*  781 */     jPanel11.add(new JLabel(""));
/*      */     
/*  783 */     this.butcenterofMassStat = new JButton("Center of mass");
/*  784 */     this.butcenterofMassStat.addActionListener(paramChemotaxis_Tool);
/*  785 */     jPanel11.add(this.butcenterofMassStat);
/*  786 */     jPanel11.add(new JLabel(""));
/*  787 */     this.butVelocityTrackSeries = new JButton("Velocity");
/*  788 */     this.butVelocityTrackSeries.addActionListener(paramChemotaxis_Tool);
/*  789 */     jPanel11.add(this.butVelocityTrackSeries);
/*  790 */     jPanel11.add(new JLabel(""));
/*      */     
/*  792 */     this.butFMISliceSeries = new JButton("FMI");
/*  793 */     this.butFMISliceSeries.addActionListener(paramChemotaxis_Tool);
/*  794 */     jPanel11.add(this.butFMISliceSeries);
/*  795 */     jPanel11.add(new JLabel(""));
/*  796 */     this.butDistanceTrackSeries = new JButton("Distance");
/*  797 */     this.butDistanceTrackSeries.addActionListener(paramChemotaxis_Tool);
/*  798 */     jPanel11.add(this.butDistanceTrackSeries);
/*  799 */     jPanel11.add(new JLabel(""));
/*      */ 
/*      */     
/*  802 */     this.butDirectionalitySliceSeries = new JButton("Directionality");
/*  803 */     this.butDirectionalitySliceSeries.addActionListener(paramChemotaxis_Tool);
/*  804 */     jPanel11.add(this.butDirectionalitySliceSeries);
/*  805 */     jPanel11.add(new JLabel(""));
/*  806 */     this.butFMITrackSeries = new JButton("FMI");
/*  807 */     this.butFMITrackSeries.addActionListener(paramChemotaxis_Tool);
/*  808 */     jPanel11.add(this.butFMITrackSeries);
/*  809 */     jPanel11.add(new JLabel(""));
/*      */     
/*  811 */     jPanel11.add(new JLabel(""));
/*  812 */     jPanel11.add(new JLabel(""));
/*  813 */     this.butDirectionalityTrackSeries = new JButton("Directionality");
/*  814 */     this.butDirectionalityTrackSeries.addActionListener(paramChemotaxis_Tool);
/*  815 */     jPanel11.add(this.butDirectionalityTrackSeries);
/*  816 */     jPanel11.add(new JLabel(""));
/*      */ 
/*      */     
/*  819 */     jPanel11.add(new JLabel(""));
/*  820 */     jPanel11.add(new JLabel(""));
/*  821 */     jPanel11.add(new JLabel(""));
/*  822 */     jPanel11.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  827 */     JPanel jPanel12 = new JPanel();
/*  828 */     jPanel12.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  830 */     jPanel12.add(new JLabel(""));
/*  831 */     jPanel12.add(new JLabel(""));
/*  832 */     jPanel12.add(new JLabel(""));
/*  833 */     jPanel12.add(new JLabel(""));
/*      */     
/*  835 */     jPanel12.add(new JLabel("Selected Dataset"));
/*  836 */     this.statisticDataset = new JComboBox();
/*  837 */     jPanel12.add(this.statisticDataset);
/*  838 */     jPanel12.add(new JLabel(""));
/*  839 */     jPanel12.add(new JLabel(""));
/*      */     
/*  841 */     this.distanceRayleighLabel = new JLabel("Distance from origin [unit]:");
/*  842 */     jPanel12.add(this.distanceRayleighLabel);
/*  843 */     this.selectionDistance = new JComboBox();
/*  844 */     this.selectionDistance.addItem("Use endpoints");
/*  845 */     this.selectionDistance.addItem("Endpoints with dist greater than");
/*  846 */     this.selectionDistance.addItem("First point with dist greater than");
/*  847 */     this.selectionDistance.setSelectedItem("Use endpoints");
/*  848 */     this.selectionDistance.addItemListener(paramChemotaxis_Tool);
/*  849 */     jPanel12.add(this.selectionDistance);
/*  850 */     this.minDistancefromOriginField = new JTextField();
/*  851 */     jPanel12.add(this.minDistancefromOriginField);
/*  852 */     jPanel12.add(new JLabel(""));
/*      */     
/*  854 */     jPanel12.add(new JLabel(""));
/*  855 */     jPanel12.add(new JLabel(""));
/*  856 */     jPanel12.add(new JLabel(""));
/*  857 */     jPanel12.add(new JLabel(""));
/*      */     
/*  859 */     jPanel12.add(new JLabel("Number of used tracks (n):"));
/*  860 */     this.numberofUsedTracksField = new JTextField();
/*  861 */     this.numberofUsedTracksField.setEditable(false);
/*  862 */     jPanel12.add(this.numberofUsedTracksField);
/*  863 */     jPanel12.add(new JLabel(""));
/*  864 */     jPanel12.add(new JLabel(""));
/*      */     
/*  866 */     jPanel12.add(new JLabel("p-value:"));
/*  867 */     this.pValueField = new JTextField();
/*  868 */     this.pValueField.setEditable(false);
/*  869 */     jPanel12.add(this.pValueField);
/*  870 */     jPanel12.add(new JLabel(""));
/*  871 */     this.butRayleighTest = new JButton("Compute Rayleigh Test");
/*  872 */     this.butRayleighTest.addActionListener(paramChemotaxis_Tool);
/*  873 */     jPanel12.add(this.butRayleighTest);
/*      */     
/*  875 */     jPanel12.add(new JLabel(""));
/*  876 */     jPanel12.add(new JLabel(""));
/*  877 */     jPanel12.add(new JLabel(""));
/*  878 */     jPanel12.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  883 */     JPanel jPanel13 = new JPanel();
/*  884 */     jPanel13.setLayout(new GridLayout(0, 4, 5, 5));
/*      */     
/*  886 */     jPanel13.add(new JLabel(""));
/*  887 */     jPanel13.add(new JLabel(""));
/*  888 */     jPanel13.add(new JLabel(""));
/*  889 */     jPanel13.add(new JLabel(""));
/*      */     
/*  891 */     jPanel13.add(new JLabel("Selected Dataset"));
/*  892 */     this.extendedstatisticDataset = new JComboBox();
/*  893 */     jPanel13.add(this.extendedstatisticDataset);
/*  894 */     jPanel13.add(new JLabel(""));
/*  895 */     jPanel13.add(new JLabel(""));
/*      */     
/*  897 */     jPanel13.add(new JLabel(""));
/*  898 */     jPanel13.add(new JLabel(""));
/*  899 */     jPanel13.add(new JLabel(""));
/*  900 */     jPanel13.add(new JLabel(""));
/*      */     
/*  902 */     jPanel13.add(new JLabel("Number of used tracks (n):"));
/*  903 */     this.numberofUsedTracksFieldExtRayleigh = new JTextField();
/*  904 */     this.numberofUsedTracksFieldExtRayleigh.setEditable(false);
/*  905 */     jPanel13.add(this.numberofUsedTracksFieldExtRayleigh);
/*  906 */     jPanel13.add(new JLabel(""));
/*  907 */     jPanel13.add(new JLabel(""));
/*      */     
/*  909 */     jPanel13.add(new JLabel("p-value:"));
/*  910 */     this.pValueFieldExtRayleigh = new JTextField();
/*  911 */     this.pValueFieldExtRayleigh.setEditable(false);
/*  912 */     jPanel13.add(this.pValueFieldExtRayleigh);
/*  913 */     jPanel13.add(new JLabel(""));
/*  914 */     this.butExtRayleighTest = new JButton("Compute Rayleigh Test");
/*  915 */     this.butExtRayleighTest.addActionListener(paramChemotaxis_Tool);
/*  916 */     jPanel13.add(this.butExtRayleighTest);
/*      */     
/*  918 */     jPanel13.add(new JLabel(""));
/*  919 */     jPanel13.add(new JLabel(""));
/*  920 */     jPanel13.add(new JLabel(""));
/*  921 */     jPanel13.add(new JLabel(""));
/*      */     
/*  923 */     jPanel13.add(new JLabel(""));
/*  924 */     jPanel13.add(new JLabel(""));
/*  925 */     jPanel13.add(new JLabel(""));
/*  926 */     jPanel13.add(new JLabel(""));
/*      */ 
/*      */ 
/*      */     
/*  930 */     this.cardPanelStatistics = new JPanel(new CardLayout());
/*  931 */     this.cardPanelStatistics.add(jPanel11, "Series functions");
/*  932 */     this.cardPanelStatistics.add(jPanel12, "Rayleigh test");
/*  933 */     this.cardPanelStatistics.add(jPanel13, "Rayleigh test for vector data");
/*      */ 
/*      */ 
/*      */     
/*  937 */     JPanel jPanel14 = new JPanel();
/*  938 */     String[] arrayOfString2 = { "Series functions", "Rayleigh test", "Rayleigh test for vector data" };
/*  939 */     this.statisticSelection = new JComboBox(arrayOfString2);
/*  940 */     this.statisticSelection.setEditable(false);
/*  941 */     this.statisticSelection.addItemListener(paramChemotaxis_Tool);
/*  942 */     jPanel14.add(this.statisticSelection);
/*  943 */     JPanel jPanel15 = new JPanel(new BorderLayout());
/*  944 */     jPanel15.add(jPanel14, "North");
/*  945 */     jPanel15.add(this.cardPanelStatistics, "Center");
/*      */ 
/*      */ 
/*      */     
/*  949 */     JPanel jPanel16 = new JPanel();
/*  950 */     jPanel16.setLayout(new GridLayout(0, 2, 5, 5));
/*      */     
/*  952 */     JPanel jPanel17 = new JPanel();
/*  953 */     jPanel17.setLayout(new BoxLayout(jPanel17, 1));
/*  954 */     jPanel17.add(new JLabel("    "));
/*  955 */     JLabel jLabel1 = new JLabel();
/*  956 */     jLabel1.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage(ChemotaxisGUI.class
/*  957 */             .getResource("ibidi.gif"))));
/*  958 */     jPanel17.add(jLabel1);
/*  959 */     jPanel17.add(new JLabel("    "));
/*  960 */     JLabel jLabel2 = new JLabel();
/*  961 */     jLabel2.setIcon(new ImageIcon(Toolkit.getDefaultToolkit().getImage(ChemotaxisGUI.class
/*  962 */             .getResource("slide.gif"))));
/*  963 */     jPanel17.add(jLabel2);
/*  964 */     JPanel jPanel18 = new JPanel();
/*  965 */     jPanel18.setLayout(new BoxLayout(jPanel18, 1));
/*  966 */     jPanel18.add(new JLabel("    "));
/*  967 */     jPanel18
/*  968 */       .add(new JLabel(
/*  969 */           "<html>Chemotaxis and Migration Tool 1.01<beta<br>written 2006 Gerhard Trapp<br>Contact: <FONT COLOR=\"#0000FF\">gtrapp@ibidi.de</FONT><br><br>This plug-in is a free software tool <br>for analyzing chemotactical or migration data obtained <br>by video microscopy.<br>It's made for ibidis \"µ-Slide Chemotaxis\" - a chamber <br>for visual chemotaxis assays - or similar experimental set-ups.<br><br></html>"));
/*      */     
/*  971 */     jPanel18.add(new JLabel("<html>Please visit <FONT COLOR=\"#0000FF\">www.ibidi.com</FONT> for further information.</html>"));
/*      */     
/*  973 */     jPanel16.add(jPanel17);
/*  974 */     jPanel16.add(jPanel18);
/*      */ 
/*      */     
/*  977 */     JTabbedPane jTabbedPane = new JTabbedPane();
/*  978 */     jTabbedPane.addTab("Import dataset", jPanel9);
/*  979 */     jTabbedPane.setMnemonicAt(0, 49);
/*  980 */     jTabbedPane.addTab("Plot feature", jPanel3);
/*  981 */     jTabbedPane.setMnemonicAt(1, 49);
/*  982 */     jTabbedPane.addTab("Sector feature", jPanel8);
/*  983 */     jTabbedPane.setMnemonicAt(2, 49);
/*  984 */     jTabbedPane.addTab("Diagram feature", jPanel4);
/*  985 */     jTabbedPane.setMnemonicAt(3, 49);
/*  986 */     jTabbedPane.addTab("Statistic feature", jPanel15);
/*  987 */     jTabbedPane.setMnemonicAt(4, 49);
/*  988 */     jTabbedPane.addTab("Settings", jPanel10);
/*  989 */     jTabbedPane.setMnemonicAt(5, 49);
/*  990 */     jTabbedPane.addTab("About", jPanel16);
/*  991 */     jTabbedPane.setMnemonicAt(6, 49);
/*  992 */     jTabbedPane.setBorder(BorderFactory.createEtchedBorder(1));
/*  993 */     jTabbedPane.addChangeListener(paramChemotaxis_Tool);
/*      */     
/*  995 */     container.add(jPanel1);
/*  996 */     container.add(this.selectedThresholds);
/*  997 */     this.selectedThresholds.setVisible(false);
/*  998 */     container.add(jPanel2);
/*  999 */     container.add(jTabbedPane);
/* 1000 */     disableButtons();
/*      */     
/* 1002 */     setSize(770, 580);
/*      */     
/* 1004 */     setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   void disableButtons() {
/* 1009 */     this.butshowHistogram.setEnabled(false);
/* 1010 */     this.butanimateGraph.setEnabled(false);
/* 1011 */     this.butshowRoseDiagram.setEnabled(false);
/* 1012 */     this.butshowZantlPlot.setEnabled(false);
/* 1013 */     this.butCompute.setEnabled(false);
/* 1014 */     this.butshowMax.setEnabled(false);
/* 1015 */     this.butturnRight.setEnabled(false);
/* 1016 */     this.butturnLeft.setEnabled(false);
/* 1017 */     this.butopenSector.setEnabled(false);
/* 1018 */     this.butcloseSector.setEnabled(false);
/* 1019 */     this.butshowCircularPlot.setEnabled(false);
/* 1020 */     this.butshowSector.setEnabled(false);
/* 1021 */     this.butshowMax.setEnabled(false);
/* 1022 */     this.butcenterofMassStat.setEnabled(false);
/* 1023 */     this.butDirectionalitySliceSeries.setEnabled(false);
/* 1024 */     this.butFMISliceSeries.setEnabled(false);
/* 1025 */     this.butDirectionalityTrackSeries.setEnabled(false);
/* 1026 */     this.butFMITrackSeries.setEnabled(false);
/* 1027 */     this.butVelocityTrackSeries.setEnabled(false);
/* 1028 */     this.butDistanceTrackSeries.setEnabled(false);
/* 1029 */     this.angleInteriorCircleField.setEnabled(false);
/* 1030 */     this.angleInteriorDiagramField.setEnabled(false);
/* 1031 */     this.anglePosDensityField.setEnabled(false);
/* 1032 */     this.anglePosField.setEnabled(false);
/* 1033 */     this.countsInsideSectorField.setEnabled(false);
/* 1034 */     this.countsOutsideSectorField.setEnabled(false);
/* 1035 */     this.butplotGraph.setEnabled(false);
/* 1036 */     this.butsetAxisScaling.setEnabled(false);
/* 1037 */     this.butRayleighTest.setEnabled(false);
/* 1038 */     this.butExtRayleighTest.setEnabled(false);
/* 1039 */     this.radiusCircleField.setEnabled(false);
/* 1040 */     this.butShowOriginalDataset.setEnabled(false);
/* 1041 */     this.firstSplitField.setEditable(false);
/* 1042 */     this.secondSplitField.setEditable(false);
/* 1043 */     this.firstThresPathField.setEditable(false);
/* 1044 */     this.secondThresPathField.setEditable(false);
/* 1045 */     this.firstThresVelocityField.setEditable(false);
/* 1046 */     this.secondThresVelocityField.setEditable(false);
/* 1047 */     this.butopenRadius.setEnabled(false);
/* 1048 */     this.butcloseRadius.setEnabled(false);
/* 1049 */     this.diagramRangeField.setEnabled(false);
/* 1050 */     this.butshowDatasetInformation.setEnabled(false);
/* 1051 */     this.colorBorderField.setEditable(false);
/* 1052 */     this.butplotVelocityHistogram.setEnabled(false);
/* 1053 */     this.rangeVelocityField.setEditable(false);
/* 1054 */     this.butshowcurrentData.setEnabled(false);
/* 1055 */     this.butclearAllDatasets.setEnabled(false);
/* 1056 */     this.firstSlicesField.setEditable(false);
/* 1057 */     this.secondSlicesField.setEditable(false);
/* 1058 */     this.butaddDataset.setEnabled(false);
/* 1059 */     this.numberofSlicesType.setEnabled(false);
/* 1060 */     this.minDistancefromOriginField.setEditable(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void valuesComputed(float paramFloat) {
/* 1067 */     this.butplotGraph.setEnabled(true);
/* 1068 */     this.butsetAxisScaling.setEnabled(true);
/* 1069 */     this.butRayleighTest.setEnabled(true);
/* 1070 */     this.butExtRayleighTest.setEnabled(true);
/* 1071 */     this.butanimateGraph.setEnabled(true);
/* 1072 */     this.butCompute.setEnabled(true);
/* 1073 */     this.butcenterofMassStat.setEnabled(true);
/* 1074 */     this.butDirectionalitySliceSeries.setEnabled(true);
/* 1075 */     this.butFMISliceSeries.setEnabled(true);
/* 1076 */     this.butDirectionalityTrackSeries.setEnabled(true);
/* 1077 */     this.butFMITrackSeries.setEnabled(true);
/* 1078 */     this.butVelocityTrackSeries.setEnabled(true);
/* 1079 */     this.butDistanceTrackSeries.setEnabled(true);
/* 1080 */     this.angleInteriorDiagramField.setEnabled(true);
/* 1081 */     this.anglePosDensityField.setEnabled(true);
/* 1082 */     this.butshowHistogram.setEnabled(true);
/* 1083 */     this.butshowRoseDiagram.setEnabled(true);
/* 1084 */     this.butshowZantlPlot.setEnabled(true);
/* 1085 */     this.butshowCircularPlot.setEnabled(true);
/* 1086 */     this.butshowDatasetInformation.setEnabled(true);
/* 1087 */     this.diagramRangeField.setEnabled(true);
/* 1088 */     this.angleInteriorDiagramField.setText(String.valueOf(paramFloat));
/* 1089 */     this.butplotVelocityHistogram.setEnabled(true);
/* 1090 */     this.rangeVelocityField.setEditable(true);
/* 1091 */     this.butshowcurrentData.setEnabled(true);
/*      */   }
/*      */ 
/*      */   
/*      */   void sectorEnabled() {
/* 1096 */     this.butturnRight.setEnabled(true);
/* 1097 */     this.butturnLeft.setEnabled(true);
/* 1098 */     this.butopenSector.setEnabled(true);
/* 1099 */     this.butcloseSector.setEnabled(true);
/* 1100 */     this.angleInteriorCircleField.setEnabled(true);
/* 1101 */     this.anglePosField.setEnabled(true);
/* 1102 */     this.countsInsideSectorField.setEnabled(true);
/* 1103 */     this.countsOutsideSectorField.setEnabled(true);
/*      */   }
/*      */   
/*      */   void sectorDisabled() {
/* 1107 */     this.butturnRight.setEnabled(false);
/* 1108 */     this.butturnLeft.setEnabled(false);
/* 1109 */     this.butopenSector.setEnabled(false);
/* 1110 */     this.butcloseSector.setEnabled(false);
/* 1111 */     this.angleInteriorCircleField.setEnabled(false);
/* 1112 */     this.anglePosField.setEnabled(false);
/* 1113 */     this.countsInsideSectorField.setEnabled(false);
/* 1114 */     this.countsOutsideSectorField.setEnabled(false);
/* 1115 */     this.butshowMax.setEnabled(false);
/* 1116 */     this.anglePosField.setText("0");
/*      */   }
/*      */   
/*      */   void circleDisabled() {
/* 1120 */     this.butopenRadius.setEnabled(false);
/* 1121 */     this.butcloseRadius.setEnabled(false);
/* 1122 */     this.radiusCircleField.setEnabled(false);
/* 1123 */     this.countsInsideCircleField.setEnabled(false);
/* 1124 */     this.countsOutsideCircleField.setEnabled(false);
/* 1125 */     this.butshowMax.setEnabled(false);
/*      */   }
/*      */ 
/*      */   
/*      */   void circleEnabled() {
/* 1130 */     this.butopenRadius.setEnabled(true);
/* 1131 */     this.butcloseRadius.setEnabled(true);
/* 1132 */     this.radiusCircleField.setEnabled(true);
/* 1133 */     this.countsInsideCircleField.setEnabled(true);
/* 1134 */     this.countsOutsideCircleField.setEnabled(true);
/* 1135 */     this.butshowMax.setEnabled(false);
/*      */   }
/*      */ 
/*      */   
/*      */   void datasetImported(String paramString) {
/* 1140 */     this.importedDataset.addItem(paramString);
/* 1141 */     this.numberofSlicesType.setSelectedItem("Use only slices equal to");
/* 1142 */     this.firstSlicesField.setText("");
/* 1143 */     this.secondSlicesField.setText("");
/* 1144 */     this.importedDataset.setSelectedItem(paramString);
/* 1145 */     this.butShowOriginalDataset.setEnabled(true);
/* 1146 */     this.firstSplitField.setEditable(true);
/* 1147 */     this.secondSplitField.setEditable(true);
/* 1148 */     this.firstThresPathField.setEditable(true);
/* 1149 */     this.firstThresVelocityField.setEditable(true);
/* 1150 */     this.butclearAllDatasets.setEnabled(true);
/* 1151 */     this.firstSlicesField.setEditable(true);
/* 1152 */     this.butaddDataset.setEnabled(true);
/* 1153 */     this.numberofSlicesType.setEnabled(true);
/*      */   }
/*      */ 
/*      */   
/*      */   void plotGraphClicked() {
/* 1158 */     this.butshowMax.setEnabled(false);
/* 1159 */     this.butturnRight.setEnabled(false);
/* 1160 */     this.butturnLeft.setEnabled(false);
/* 1161 */     this.butopenSector.setEnabled(false);
/* 1162 */     this.butcloseSector.setEnabled(false);
/* 1163 */     this.butopenRadius.setEnabled(false);
/* 1164 */     this.butcloseRadius.setEnabled(false);
/* 1165 */     this.radiusCircleField.setEnabled(false);
/* 1166 */     this.angleInteriorCircleField.setEnabled(false);
/* 1167 */     this.anglePosField.setEnabled(false);
/* 1168 */     this.countsInsideSectorField.setEnabled(false);
/* 1169 */     this.countsOutsideSectorField.setEnabled(false);
/*      */   }
/*      */ 
/*      */   
/*      */   void plotClosed() {
/* 1174 */     this.butopenRadius.setEnabled(false);
/* 1175 */     this.butcloseRadius.setEnabled(false);
/* 1176 */     this.butshowCircle.setEnabled(false);
/* 1177 */     this.butshowSector.setEnabled(false);
/* 1178 */     this.butshowSector.setEnabled(false);
/* 1179 */     this.butshowMax.setEnabled(false);
/* 1180 */     this.radiusCircleField.setEnabled(false);
/* 1181 */     this.angleInteriorCircleField.setEnabled(false);
/* 1182 */     this.anglePosField.setEnabled(false);
/* 1183 */     this.countsInsideSectorField.setEnabled(false);
/* 1184 */     this.countsOutsideSectorField.setEnabled(false);
/* 1185 */     this.butturnRight.setEnabled(false);
/* 1186 */     this.butturnLeft.setEnabled(false);
/* 1187 */     this.butopenSector.setEnabled(false);
/* 1188 */     this.butcloseSector.setEnabled(false);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/chemotaxis_tool.jar!/ChemotaxisGUI.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */