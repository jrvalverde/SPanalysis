/*     */ package inra.ijpb.label.select;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RelationalOperator
/*     */ {
/*  23 */   public static final RelationalOperator GT = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/*  28 */         return (value1 > value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/*  34 */         return (value1 > value2);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final RelationalOperator LT = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/*  46 */         return (value1 < value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/*  52 */         return (value1 < value2);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final RelationalOperator GE = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/*  64 */         return (value1 >= value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/*  70 */         return (value1 >= value2);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final RelationalOperator LE = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/*  82 */         return (value1 <= value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/*  88 */         return (value1 <= value2);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final RelationalOperator EQ = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/* 100 */         return (value1 == value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/* 106 */         return (value1 == value2);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final RelationalOperator NE = new RelationalOperator()
/*     */     {
/*     */       
/*     */       public boolean evaluate(int value1, int value2)
/*     */       {
/* 118 */         return (value1 != value2);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean evaluate(double value1, double value2) {
/* 124 */         return (value1 != value2);
/*     */       }
/*     */     };
/*     */   
/*     */   boolean evaluate(int paramInt1, int paramInt2);
/*     */   
/*     */   boolean evaluate(double paramDouble1, double paramDouble2);
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/select/RelationalOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */