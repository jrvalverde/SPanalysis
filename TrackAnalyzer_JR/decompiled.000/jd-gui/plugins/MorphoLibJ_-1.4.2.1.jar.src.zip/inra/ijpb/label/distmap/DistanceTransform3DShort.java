/*     */ package inra.ijpb.label.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3DShort
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private short[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private Image3D labels;
/*     */   private Image3D distmap;
/*     */   
/*     */   public DistanceTransform3DShort(ChamferWeights3D weights) {
/*  83 */     this(weights.getShortWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(short[] weights) {
/*  92 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(ChamferWeights3D weights, boolean normalize) {
/* 105 */     this(weights.getShortWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DShort(short[] weights, boolean normalize) {
/* 118 */     this.weights = weights;
/* 119 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 140 */     this.sizeX = image.getWidth();
/* 141 */     this.sizeY = image.getHeight();
/* 142 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 145 */     this.labels = Images3D.createWrapper(image);
/*     */ 
/*     */     
/* 148 */     ImageStack resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 16);
/* 149 */     this.distmap = Images3D.createWrapper(resultStack);
/*     */ 
/*     */     
/* 152 */     initializeResultSlices();
/*     */ 
/*     */     
/* 155 */     forwardScan();
/* 156 */     backwardScan();
/*     */ 
/*     */     
/* 159 */     if (this.normalizeMap)
/*     */     {
/* 161 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 164 */     fireStatusChanged(this, "");
/* 165 */     return resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 178 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 181 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 183 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 185 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 187 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 189 */           int val = this.labels.get(x, y, z);
/* 190 */           this.distmap.set(x, y, z, (val == 0) ? 0 : 32767);
/*     */         } 
/*     */       } 
/*     */     } 
/* 194 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 199 */     fireStatusChanged(this, "Forward scan...");
/*     */ 
/*     */     
/* 202 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 205 */     offsets.add(new WeightedOffset(-1, -1, -1, this.weights[2]));
/* 206 */     offsets.add(new WeightedOffset(0, -1, -1, this.weights[1]));
/* 207 */     offsets.add(new WeightedOffset(1, -1, -1, this.weights[2]));
/* 208 */     offsets.add(new WeightedOffset(-1, 0, -1, this.weights[1]));
/* 209 */     offsets.add(new WeightedOffset(0, 0, -1, this.weights[0]));
/* 210 */     offsets.add(new WeightedOffset(1, 0, -1, this.weights[1]));
/* 211 */     offsets.add(new WeightedOffset(-1, 1, -1, this.weights[2]));
/* 212 */     offsets.add(new WeightedOffset(0, 1, -1, this.weights[1]));
/* 213 */     offsets.add(new WeightedOffset(1, 1, -1, this.weights[2]));
/*     */ 
/*     */     
/* 216 */     offsets.add(new WeightedOffset(-1, -1, 0, this.weights[1]));
/* 217 */     offsets.add(new WeightedOffset(0, -1, 0, this.weights[0]));
/* 218 */     offsets.add(new WeightedOffset(1, -1, 0, this.weights[1]));
/* 219 */     offsets.add(new WeightedOffset(-1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 222 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 224 */       fireProgressChanged(this, z, this.sizeZ);
/* 225 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 227 */         for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */           
/* 230 */           int label = this.labels.get(x, y, z);
/*     */ 
/*     */           
/* 233 */           if (label != 0) {
/*     */ 
/*     */ 
/*     */             
/* 237 */             int currentDist = this.distmap.get(x, y, z);
/* 238 */             int newDist = currentDist;
/*     */ 
/*     */             
/* 241 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 243 */               int x2 = x + offset.dx;
/* 244 */               int y2 = y + offset.dy;
/* 245 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 248 */               if (x2 < 0 || x2 >= this.sizeX)
/*     */                 continue; 
/* 250 */               if (y2 < 0 || y2 >= this.sizeY)
/*     */                 continue; 
/* 252 */               if (z2 < 0 || z2 >= this.sizeZ) {
/*     */                 continue;
/*     */               }
/* 255 */               if (this.labels.get(x2, y2, z2) != label) {
/*     */ 
/*     */                 
/* 258 */                 newDist = offset.weight;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 263 */               newDist = Math.min(newDist, this.distmap.get(x2, y2, z2) + offset.weight);
/*     */             } 
/*     */ 
/*     */             
/* 267 */             if (newDist < currentDist)
/*     */             {
/* 269 */               this.distmap.set(x, y, z, newDist); } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 274 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 279 */     fireStatusChanged(this, "Backward scan...");
/*     */ 
/*     */     
/* 282 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 285 */     offsets.add(new WeightedOffset(-1, -1, 1, this.weights[2]));
/* 286 */     offsets.add(new WeightedOffset(0, -1, 1, this.weights[1]));
/* 287 */     offsets.add(new WeightedOffset(1, -1, 1, this.weights[2]));
/* 288 */     offsets.add(new WeightedOffset(-1, 0, 1, this.weights[1]));
/* 289 */     offsets.add(new WeightedOffset(0, 0, 1, this.weights[0]));
/* 290 */     offsets.add(new WeightedOffset(1, 0, 1, this.weights[1]));
/* 291 */     offsets.add(new WeightedOffset(-1, 1, 1, this.weights[2]));
/* 292 */     offsets.add(new WeightedOffset(0, 1, 1, this.weights[1]));
/* 293 */     offsets.add(new WeightedOffset(1, 1, 1, this.weights[2]));
/*     */ 
/*     */     
/* 296 */     offsets.add(new WeightedOffset(-1, 1, 0, this.weights[1]));
/* 297 */     offsets.add(new WeightedOffset(0, 1, 0, this.weights[0]));
/* 298 */     offsets.add(new WeightedOffset(1, 1, 0, this.weights[1]));
/* 299 */     offsets.add(new WeightedOffset(1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 302 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 304 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 306 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 308 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */           
/* 311 */           int label = this.labels.get(x, y, z);
/*     */ 
/*     */           
/* 314 */           if (label != 0) {
/*     */ 
/*     */ 
/*     */             
/* 318 */             int currentDist = this.distmap.get(x, y, z);
/* 319 */             int newDist = currentDist;
/*     */ 
/*     */             
/* 322 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 324 */               int x2 = x + offset.dx;
/* 325 */               int y2 = y + offset.dy;
/* 326 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 329 */               if (x2 < 0 || x2 >= this.sizeX)
/*     */                 continue; 
/* 331 */               if (y2 < 0 || y2 >= this.sizeY)
/*     */                 continue; 
/* 333 */               if (z2 < 0 || z2 >= this.sizeZ) {
/*     */                 continue;
/*     */               }
/* 336 */               if (this.labels.get(x2, y2, z2) != label) {
/*     */ 
/*     */                 
/* 339 */                 newDist = offset.weight;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 344 */               newDist = Math.min(newDist, this.distmap.get(x2, y2, z2) + offset.weight);
/*     */             } 
/*     */ 
/*     */             
/* 348 */             if (newDist < currentDist)
/*     */             {
/* 350 */               this.distmap.set(x, y, z, newDist);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 357 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 362 */     fireStatusChanged(this, "Normalize map...");
/* 363 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 365 */       fireProgressChanged(this, z, this.sizeZ);
/* 366 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 368 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 370 */           if (this.labels.get(x, y, z) != 0)
/*     */           {
/* 372 */             this.distmap.set(x, y, z, this.distmap.get(x, y, z) / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 377 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private class WeightedOffset
/*     */   {
/*     */     int dx;
/*     */     int dy;
/*     */     int dz;
/*     */     short weight;
/*     */     
/*     */     public WeightedOffset(int dx, int dy, int dz, short weight) {
/* 389 */       this.dx = dx;
/* 390 */       this.dy = dy;
/* 391 */       this.dz = dz;
/* 392 */       this.weight = weight;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/distmap/DistanceTransform3DShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */