/*      */ package inra.ijpb.label;
/*      */ 
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.gui.PlotWindow;
/*      */ import ij.gui.PointRoi;
/*      */ import ij.gui.ProfilePlot;
/*      */ import ij.gui.Roi;
/*      */ import ij.gui.ShapeRoi;
/*      */ import ij.measure.ResultsTable;
/*      */ import ij.plugin.Selection;
/*      */ import ij.process.ByteProcessor;
/*      */ import ij.process.ColorProcessor;
/*      */ import ij.process.FloatPolygon;
/*      */ import ij.process.FloatProcessor;
/*      */ import ij.process.ImageProcessor;
/*      */ import ij.process.ShortProcessor;
/*      */ import inra.ijpb.data.Cursor2D;
/*      */ import inra.ijpb.data.Cursor3D;
/*      */ import inra.ijpb.label.distmap.DistanceTransform3DFloat;
/*      */ import inra.ijpb.label.distmap.DistanceTransform3DShort;
/*      */ import java.awt.Color;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LabelImages
/*      */ {
/*      */   public static final boolean isLabelImageType(ImagePlus imagePlus) {
/*   82 */     int type = imagePlus.getType();
/*   83 */     return !(type != 0 && type != 3 && 
/*   84 */       type != 1 && type != 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor createLabelImage(int width, int height, int nLabels) {
/*  103 */     if (nLabels < 256)
/*      */     {
/*  105 */       return (ImageProcessor)new ByteProcessor(width, height);
/*      */     }
/*  107 */     if (nLabels < 65536)
/*      */     {
/*  109 */       return (ImageProcessor)new ShortProcessor(width, height);
/*      */     }
/*  111 */     if (nLabels < 8388608)
/*      */     {
/*  113 */       return (ImageProcessor)new FloatProcessor(width, height);
/*      */     }
/*      */ 
/*      */     
/*  117 */     IJ.error("Too many classes");
/*  118 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack createLabelStack(int width, int height, int depth, int nLabels) {
/*  139 */     if (nLabels < 256)
/*      */     {
/*  141 */       return ImageStack.create(width, height, depth, 8);
/*      */     }
/*  143 */     if (nLabels < 65536)
/*      */     {
/*  145 */       return ImageStack.create(width, height, depth, 16);
/*      */     }
/*  147 */     if (nLabels < 8388608)
/*      */     {
/*  149 */       return ImageStack.create(width, height, depth, 32);
/*      */     }
/*      */ 
/*      */     
/*  153 */     IJ.error("Too many classes");
/*  154 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ByteProcessor createLabelImage(ImageProcessor... images) {
/*  190 */     ImageProcessor refImage = images[0];
/*  191 */     int width = refImage.getWidth();
/*  192 */     int height = refImage.getHeight();
/*      */     
/*  194 */     ByteProcessor result = new ByteProcessor(width, height);
/*      */     
/*  196 */     int label = 0; byte b; int i; ImageProcessor[] arrayOfImageProcessor;
/*  197 */     for (i = (arrayOfImageProcessor = images).length, b = 0; b < i; ) { ImageProcessor image = arrayOfImageProcessor[b];
/*      */       
/*  199 */       label++;
/*  200 */       for (int y = 0; y < height; y++) {
/*      */         
/*  202 */         for (int x = 0; x < width; x++) {
/*      */           
/*  204 */           if (image.get(x, y) > 0)
/*      */           {
/*  206 */             result.set(x, y, label);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */     
/*  212 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack labelBoundaries(ImageStack image) {
/*  225 */     int sizeX = image.getWidth();
/*  226 */     int sizeY = image.getHeight();
/*  227 */     int sizeZ = image.getSize();
/*      */     
/*  229 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*      */     
/*  231 */     for (int z = 0; z < sizeZ - 1; z++) {
/*      */       
/*  233 */       for (int y = 0; y < sizeY - 1; y++) {
/*      */         
/*  235 */         for (int x = 0; x < sizeX - 1; x++) {
/*      */           
/*  237 */           double value = image.getVoxel(x, y, z);
/*  238 */           if (image.getVoxel(x + 1, y, z) != value)
/*  239 */             result.setVoxel(x, y, z, 255.0D); 
/*  240 */           if (image.getVoxel(x, y + 1, z) != value)
/*  241 */             result.setVoxel(x, y, z, 255.0D); 
/*  242 */           if (image.getVoxel(x, y, z + 1) != value) {
/*  243 */             result.setVoxel(x, y, z, 255.0D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  248 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor labelBoundaries(ImageProcessor image) {
/*  261 */     int sizeX = image.getWidth();
/*  262 */     int sizeY = image.getHeight();
/*      */     
/*  264 */     ByteProcessor result = new ByteProcessor(sizeX, sizeY);
/*      */     
/*  266 */     for (int y = 0; y < sizeY - 1; y++) {
/*      */       
/*  268 */       for (int x = 0; x < sizeX - 1; x++) {
/*      */         
/*  270 */         double value = image.getf(x, y);
/*  271 */         if (image.getf(x + 1, y) != value)
/*  272 */           result.setf(x, y, 255.0F); 
/*  273 */         if (image.getf(x, y + 1) != value)
/*  274 */           result.setf(x, y, 255.0F); 
/*  275 */         if (image.getf(x, y) != value)
/*  276 */           result.setf(x, y, 255.0F); 
/*      */       } 
/*      */     } 
/*  279 */     return (ImageProcessor)result;
/*      */   }
/*      */ 
/*      */   
/*      */   public static final ImageProcessor binarize(ImageProcessor image, int label) {
/*  284 */     int sizeX = image.getWidth();
/*  285 */     int sizeY = image.getHeight();
/*      */     
/*  287 */     ByteProcessor result = new ByteProcessor(sizeX, sizeY);
/*  288 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  290 */       for (int x = 0; x < sizeX; x++) {
/*      */ 
/*      */         
/*  293 */         int val = (int)image.getf(x, y);
/*  294 */         if (val == label)
/*      */         {
/*  296 */           result.set(x, y, 255);
/*      */         }
/*      */       } 
/*      */     } 
/*  300 */     return (ImageProcessor)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus cropLabel(ImagePlus imagePlus, int label, int border) {
/*      */     ImagePlus croppedPlus;
/*  315 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-crop";
/*      */ 
/*      */ 
/*      */     
/*  319 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  321 */       ImageProcessor image = imagePlus.getProcessor();
/*  322 */       ImageProcessor cropped = cropLabel(image, label, border);
/*  323 */       croppedPlus = new ImagePlus(newName, cropped);
/*      */     }
/*      */     else {
/*      */       
/*  327 */       ImageStack image = imagePlus.getStack();
/*  328 */       ImageStack cropped = cropLabel(image, label, border);
/*  329 */       croppedPlus = new ImagePlus(newName, cropped);
/*      */     } 
/*      */     
/*  332 */     return croppedPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor cropLabel(ImageProcessor image, int label, int border) {
/*  348 */     int sizeX = image.getWidth();
/*  349 */     int sizeY = image.getHeight();
/*      */ 
/*      */     
/*  352 */     int xmin = Integer.MAX_VALUE;
/*  353 */     int xmax = Integer.MIN_VALUE;
/*  354 */     int ymin = Integer.MAX_VALUE;
/*  355 */     int ymax = Integer.MIN_VALUE;
/*      */ 
/*      */     
/*  358 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  360 */       for (int x = 0; x < sizeX; x++) {
/*      */ 
/*      */         
/*  363 */         int val = image.get(x, y);
/*  364 */         if (val == label) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  370 */           xmin = Math.min(xmin, x);
/*  371 */           xmax = Math.max(xmax, x);
/*  372 */           ymin = Math.min(ymin, y);
/*  373 */           ymax = Math.max(ymax, y);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  378 */     int sizeX2 = xmax - xmin + 1 + 2 * border;
/*  379 */     int sizeY2 = ymax - ymin + 1 + 2 * border;
/*      */ 
/*      */     
/*  382 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX2, sizeY2);
/*      */ 
/*      */     
/*  385 */     for (int i = ymin, y2 = border; i <= ymax; i++, y2++) {
/*      */       
/*  387 */       for (int x = xmin, x2 = border; x <= xmax; x++, x2++) {
/*      */         
/*  389 */         if (image.get(x, i) == label)
/*      */         {
/*  391 */           byteProcessor.set(x2, y2, 255);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  396 */     return (ImageProcessor)byteProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack cropLabel(ImageStack image, int label, int border) {
/*  413 */     int sizeX = image.getWidth();
/*  414 */     int sizeY = image.getHeight();
/*  415 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/*  418 */     int xmin = Integer.MAX_VALUE;
/*  419 */     int xmax = Integer.MIN_VALUE;
/*  420 */     int ymin = Integer.MAX_VALUE;
/*  421 */     int ymax = Integer.MIN_VALUE;
/*  422 */     int zmin = Integer.MAX_VALUE;
/*  423 */     int zmax = Integer.MIN_VALUE;
/*      */ 
/*      */     
/*  426 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  428 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  430 */         for (int x = 0; x < sizeX; x++) {
/*      */ 
/*      */           
/*  433 */           int val = (int)image.getVoxel(x, y, z);
/*  434 */           if (val == label) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  440 */             xmin = Math.min(xmin, x);
/*  441 */             xmax = Math.max(xmax, x);
/*  442 */             ymin = Math.min(ymin, y);
/*  443 */             ymax = Math.max(ymax, y);
/*  444 */             zmin = Math.min(zmin, z);
/*  445 */             zmax = Math.max(zmax, z);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  451 */     int sizeX2 = xmax - xmin + 1 + 2 * border;
/*  452 */     int sizeY2 = ymax - ymin + 1 + 2 * border;
/*  453 */     int sizeZ2 = zmax - zmin + 1 + 2 * border;
/*      */ 
/*      */     
/*  456 */     ImageStack result = ImageStack.create(sizeX2, sizeY2, sizeZ2, 8);
/*      */ 
/*      */     
/*  459 */     for (int i = zmin, z2 = border; i <= zmax; i++, z2++) {
/*      */       
/*  461 */       for (int y = ymin, y2 = border; y <= ymax; y++, y2++) {
/*      */         
/*  463 */         for (int x = xmin, x2 = border; x <= xmax; x++, x2++) {
/*      */           
/*  465 */           if ((int)image.getVoxel(x, y, i) == label)
/*      */           {
/*  467 */             result.setVoxel(x2, y2, z2, 255.0D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  473 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus sizeOpening(ImagePlus labelImage, int minElementCount) {
/*      */     ImagePlus resultPlus;
/*  493 */     boolean isPlanar = (labelImage.getStackSize() == 1);
/*      */ 
/*      */     
/*  496 */     String newName = String.valueOf(labelImage.getShortTitle()) + "-sizeOpening";
/*      */     
/*  498 */     if (isPlanar) {
/*      */       
/*  500 */       ImageProcessor image = labelImage.getProcessor();
/*  501 */       ImageProcessor result = areaOpening(image, minElementCount);
/*  502 */       if (!(result instanceof ColorProcessor))
/*  503 */         result.setLut(image.getLut()); 
/*  504 */       resultPlus = new ImagePlus(newName, result);
/*      */     }
/*      */     else {
/*      */       
/*  508 */       ImageStack image = labelImage.getStack();
/*  509 */       ImageStack result = volumeOpening(image, minElementCount);
/*  510 */       result.setColorModel(image.getColorModel());
/*  511 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */ 
/*      */     
/*  515 */     double min = labelImage.getDisplayRangeMin();
/*  516 */     double max = labelImage.getDisplayRangeMax();
/*  517 */     resultPlus.setDisplayRange(min, max);
/*      */ 
/*      */     
/*  520 */     resultPlus.copyScale(labelImage);
/*  521 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor areaOpening(ImageProcessor labelImage, int nPixelMin) {
/*  537 */     int[] labels = findAllLabels(labelImage);
/*  538 */     int[] areas = pixelCount(labelImage, labels);
/*      */ 
/*      */     
/*  541 */     ArrayList<Integer> labelsToKeep = new ArrayList<Integer>(labels.length);
/*  542 */     for (int i = 0; i < labels.length; i++) {
/*      */       
/*  544 */       if (areas[i] >= nPixelMin)
/*      */       {
/*  546 */         labelsToKeep.add(Integer.valueOf(labels[i]));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  551 */     int[] labels2 = new int[labelsToKeep.size()];
/*  552 */     for (int j = 0; j < labelsToKeep.size(); j++)
/*      */     {
/*  554 */       labels2[j] = ((Integer)labelsToKeep.get(j)).intValue();
/*      */     }
/*      */ 
/*      */     
/*  558 */     ImageProcessor result = keepLabels(labelImage, labels2);
/*      */     
/*  560 */     if (!(result instanceof ColorProcessor))
/*  561 */       result.setLut(labelImage.getLut()); 
/*  562 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack volumeOpening(ImageStack labelImage, int nVoxelMin) {
/*  579 */     int[] labels = findAllLabels(labelImage);
/*  580 */     int[] vols = voxelCount(labelImage, labels);
/*      */ 
/*      */     
/*  583 */     ArrayList<Integer> labelsToKeep = new ArrayList<Integer>(labels.length);
/*  584 */     for (int i = 0; i < labels.length; i++) {
/*      */       
/*  586 */       if (vols[i] >= nVoxelMin)
/*      */       {
/*  588 */         labelsToKeep.add(Integer.valueOf(labels[i]));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  593 */     int[] labels2 = new int[labelsToKeep.size()];
/*  594 */     for (int j = 0; j < labelsToKeep.size(); j++)
/*      */     {
/*  596 */       labels2[j] = ((Integer)labelsToKeep.get(j)).intValue();
/*      */     }
/*      */ 
/*      */     
/*  600 */     ImageStack result = keepLabels(labelImage, labels2);
/*      */ 
/*      */     
/*  603 */     result.setColorModel(labelImage.getColorModel());
/*      */     
/*  605 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus labelToRgb(ImagePlus imagePlus, byte[][] lut, Color bgColor) {
/*      */     ImagePlus resultPlus;
/*  620 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-rgb";
/*      */ 
/*      */     
/*  623 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/*  626 */       ImageProcessor image = imagePlus.getProcessor();
/*  627 */       ColorProcessor colorProcessor = labelToRgb(image, lut, bgColor);
/*  628 */       resultPlus = new ImagePlus(newName, (ImageProcessor)colorProcessor);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  633 */       ImageStack image = imagePlus.getStack();
/*  634 */       ImageStack result = labelToRgb(image, lut, bgColor);
/*  635 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */     
/*  638 */     resultPlus.copyScale(imagePlus);
/*  639 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ColorProcessor labelToRgb(ImageProcessor image, byte[][] lut, Color bgColor) {
/*  653 */     int width = image.getWidth();
/*  654 */     int height = image.getHeight();
/*      */     
/*  656 */     int bgColorCode = bgColor.getRGB();
/*      */     
/*  658 */     ColorProcessor result = new ColorProcessor(width, height);
/*  659 */     for (int y = 0; y < height; y++) {
/*      */       
/*  661 */       for (int x = 0; x < width; x++) {
/*      */         
/*  663 */         int index = (int)image.getf(x, y);
/*  664 */         if (index == 0) {
/*      */           
/*  666 */           result.set(x, y, bgColorCode);
/*      */         }
/*      */         else {
/*      */           
/*  670 */           byte[] rgb = lut[index - 1];
/*  671 */           int color = (rgb[0] & 0xFF) << 16 | (
/*  672 */             rgb[1] & 0xFF) << 8 | rgb[2] & 0xFF;
/*  673 */           result.set(x, y, color);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  678 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack labelToRgb(ImageStack image, byte[][] lut, Color bgColor) {
/*  692 */     int sizeX = image.getWidth();
/*  693 */     int sizeY = image.getHeight();
/*  694 */     int sizeZ = image.getSize();
/*      */     
/*  696 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 24);
/*      */     
/*  698 */     int bgColorCode = bgColor.getRGB();
/*      */     
/*  700 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  702 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  704 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/*  706 */           int index = (int)image.getVoxel(x, y, z);
/*  707 */           if (index == 0) {
/*      */             
/*  709 */             result.setVoxel(x, y, z, bgColorCode);
/*      */           }
/*      */           else {
/*      */             
/*  713 */             byte[] rgb = lut[index - 1];
/*  714 */             int color = (rgb[0] & 0xFF) << 16 | (
/*  715 */               rgb[1] & 0xFF) << 8 | rgb[2] & 0xFF;
/*  716 */             result.setVoxel(x, y, z, color);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  722 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeBorderLabels(ImagePlus imagePlus) {
/*  732 */     if (imagePlus.getStackSize() == 1) {
/*      */       
/*  734 */       removeBorderLabels(imagePlus.getProcessor());
/*      */     } else {
/*  736 */       removeBorderLabels(imagePlus.getStack());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeBorderLabels(ImageProcessor image) {
/*  746 */     int[] labels = findBorderLabels(image);
/*  747 */     replaceLabels(image, labels, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int[] findBorderLabels(ImageProcessor image) {
/*  752 */     int sizeX = image.getWidth();
/*  753 */     int sizeY = image.getHeight();
/*      */     
/*  755 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*      */ 
/*      */     
/*  758 */     for (int x = 0; x < sizeX; x++) {
/*      */       
/*  760 */       labelSet.add(Integer.valueOf((int)image.getf(x, 0)));
/*  761 */       labelSet.add(Integer.valueOf((int)image.getf(x, sizeY - 1)));
/*      */     } 
/*      */ 
/*      */     
/*  765 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  767 */       labelSet.add(Integer.valueOf((int)image.getf(0, y)));
/*  768 */       labelSet.add(Integer.valueOf((int)image.getf(sizeX - 1, y)));
/*      */     } 
/*      */ 
/*      */     
/*  772 */     labelSet.remove(Integer.valueOf(0));
/*      */ 
/*      */     
/*  775 */     int[] labels = new int[labelSet.size()];
/*  776 */     int i = 0;
/*  777 */     Iterator<Integer> iter = labelSet.iterator();
/*  778 */     while (iter.hasNext())
/*      */     {
/*  780 */       labels[i++] = ((Integer)iter.next()).intValue();
/*      */     }
/*      */     
/*  783 */     return labels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeBorderLabels(ImageStack image) {
/*  792 */     int[] labels = findBorderLabels(image);
/*  793 */     replaceLabels(image, labels, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int[] findBorderLabels(ImageStack image) {
/*  798 */     int sizeX = image.getWidth();
/*  799 */     int sizeY = image.getHeight();
/*  800 */     int sizeZ = image.getSize();
/*      */     
/*  802 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/*      */ 
/*      */     
/*  805 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  807 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/*  809 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, y, 0)));
/*  810 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, y, sizeZ - 1)));
/*      */       } 
/*      */     } 
/*      */     
/*      */     int z;
/*  815 */     for (z = 0; z < sizeZ; z++) {
/*      */       
/*  817 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/*  819 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, 0, z)));
/*  820 */         labelSet.add(Integer.valueOf((int)image.getVoxel(x, sizeY - 1, z)));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  825 */     for (z = 0; z < sizeZ; z++) {
/*      */       
/*  827 */       for (int j = 0; j < sizeY; j++) {
/*      */         
/*  829 */         labelSet.add(Integer.valueOf((int)image.getVoxel(0, j, z)));
/*  830 */         labelSet.add(Integer.valueOf((int)image.getVoxel(sizeX - 1, j, z)));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  835 */     labelSet.remove(Integer.valueOf(0));
/*      */ 
/*      */     
/*  838 */     int[] labels = new int[labelSet.size()];
/*  839 */     int i = 0;
/*  840 */     Iterator<Integer> iter = labelSet.iterator();
/*  841 */     while (iter.hasNext())
/*      */     {
/*  843 */       labels[i++] = ((Integer)iter.next()).intValue();
/*      */     }
/*      */     
/*  846 */     return labels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus keepLargestLabel(ImagePlus imagePlus) {
/*      */     ImagePlus resultPlus;
/*  858 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-largest";
/*      */ 
/*      */     
/*  861 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/*  864 */       ImageProcessor image = imagePlus.getProcessor();
/*  865 */       ImageProcessor result = keepLargestLabel(image);
/*  866 */       resultPlus = new ImagePlus(newName, result);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  871 */       ImageStack image = imagePlus.getStack();
/*  872 */       ImageStack result = keepLargestLabel(image);
/*  873 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */     
/*  876 */     resultPlus.copyScale(imagePlus);
/*  877 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor keepLargestLabel(ImageProcessor image) {
/*  890 */     int sizeX = image.getWidth();
/*  891 */     int sizeY = image.getHeight();
/*      */     
/*  893 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX, sizeY);
/*      */ 
/*      */     
/*  896 */     int[] labels = findAllLabels(image);
/*  897 */     if (labels.length == 0)
/*      */     {
/*  899 */       throw new RuntimeException("Can not select a label in an empty image");
/*      */     }
/*      */ 
/*      */     
/*  903 */     int[] areas = pixelCount(image, labels);
/*  904 */     int largestLabel = labels[indexOfMax(areas)];
/*      */ 
/*      */     
/*  907 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/*  909 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/*  911 */         int label = (int)image.getf(x, y);
/*  912 */         if (label == largestLabel) {
/*  913 */           byteProcessor.set(x, y, 255);
/*      */         } else {
/*  915 */           byteProcessor.set(x, y, 0);
/*      */         } 
/*      */       } 
/*      */     } 
/*  919 */     return (ImageProcessor)byteProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack keepLargestLabel(ImageStack image) {
/*  932 */     int sizeX = image.getWidth();
/*  933 */     int sizeY = image.getHeight();
/*  934 */     int sizeZ = image.getSize();
/*      */     
/*  936 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*      */ 
/*      */     
/*  939 */     int[] labels = findAllLabels(image);
/*  940 */     if (labels.length == 0)
/*      */     {
/*  942 */       throw new RuntimeException("Can not select a label in an empty image");
/*      */     }
/*      */ 
/*      */     
/*  946 */     int[] volumes = voxelCount(image, labels);
/*  947 */     int largestLabel = labels[indexOfMax(volumes)];
/*      */ 
/*      */     
/*  950 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/*  952 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/*  954 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/*  956 */           int label = (int)image.getVoxel(x, y, z);
/*  957 */           if (label == largestLabel) {
/*  958 */             result.setVoxel(x, y, z, 255.0D);
/*      */           } else {
/*  960 */             result.setVoxel(x, y, z, 0.0D);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  965 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeLargestLabel(ImagePlus imagePlus) {
/*  977 */     if (imagePlus.getStackSize() == 1) {
/*  978 */       removeLargestLabel(imagePlus.getProcessor());
/*      */     } else {
/*  980 */       removeLargestLabel(imagePlus.getStack());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeLargestLabel(ImageProcessor image) {
/*  993 */     int sizeX = image.getWidth();
/*  994 */     int sizeY = image.getHeight();
/*      */ 
/*      */     
/*  997 */     int[] labels = findAllLabels(image);
/*  998 */     if (labels.length == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1005 */     int[] areas = pixelCount(image, labels);
/* 1006 */     int largestLabel = labels[indexOfMax(areas)];
/*      */ 
/*      */     
/* 1009 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/* 1011 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/* 1013 */         int label = (int)image.getf(x, y);
/* 1014 */         if (label == largestLabel) {
/* 1015 */           image.setf(x, y, 0.0F);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void removeLargestLabel(ImageStack image) {
/* 1030 */     int sizeX = image.getWidth();
/* 1031 */     int sizeY = image.getHeight();
/* 1032 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/* 1035 */     int[] labels = findAllLabels(image);
/* 1036 */     if (labels.length == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1043 */     int[] volumes = voxelCount(image, labels);
/* 1044 */     int largestLabel = labels[indexOfMax(volumes)];
/*      */ 
/*      */     
/* 1047 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1049 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1051 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1053 */           int label = (int)image.getVoxel(x, y, z);
/* 1054 */           if (label == largestLabel) {
/* 1055 */             image.setVoxel(x, y, z, 0.0D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int indexOfMax(int[] values) {
/* 1071 */     int indMax = -1;
/* 1072 */     int volumeMax = Integer.MIN_VALUE;
/* 1073 */     for (int i = 0; i < values.length; i++) {
/*      */       
/* 1075 */       if (values[i] > volumeMax) {
/*      */         
/* 1077 */         volumeMax = values[i];
/* 1078 */         indMax = i;
/*      */       } 
/*      */     } 
/* 1081 */     return indMax;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] pixelCount(ImagePlus image, int[] labels) {
/* 1098 */     return (image.getStackSize() == 1) ? 
/* 1099 */       pixelCount(image.getProcessor(), labels) : 
/* 1100 */       voxelCount(image.getStack(), labels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] pixelCount(ImageProcessor image, int[] labels) {
/* 1118 */     int width = image.getWidth();
/* 1119 */     int height = image.getHeight();
/*      */ 
/*      */     
/* 1122 */     HashMap<Integer, Integer> labelIndices = mapLabelIndices(labels);
/*      */ 
/*      */     
/* 1125 */     int nLabels = labels.length;
/* 1126 */     int[] counts = new int[nLabels];
/*      */ 
/*      */     
/* 1129 */     for (int y = 0; y < height; y++) {
/*      */       
/* 1131 */       for (int x = 0; x < width; x++) {
/*      */         
/* 1133 */         int label = (int)image.getf(x, y);
/* 1134 */         if (label != 0) {
/*      */           
/* 1136 */           int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 1137 */           counts[labelIndex] = counts[labelIndex] + 1;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1141 */     return counts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] voxelCount(ImageStack image, int[] labels) {
/* 1158 */     HashMap<Integer, Integer> labelIndices = mapLabelIndices(labels);
/*      */ 
/*      */     
/* 1161 */     int nLabels = labels.length;
/* 1162 */     int[] counts = new int[nLabels];
/*      */ 
/*      */     
/* 1165 */     int sizeX = image.getWidth();
/* 1166 */     int sizeY = image.getHeight();
/* 1167 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/* 1170 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1172 */       IJ.showProgress(z, sizeZ);
/* 1173 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1175 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1177 */           int label = (int)image.getVoxel(x, y, z);
/*      */           
/* 1179 */           if (label != 0) {
/*      */             
/* 1181 */             int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 1182 */             counts[labelIndex] = counts[labelIndex] + 1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1187 */     return counts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int findLargestLabel(ImagePlus imagePlus) {
/* 1197 */     int max = 0;
/* 1198 */     for (int i = 1; i <= imagePlus.getImageStackSize(); i++) {
/*      */       
/* 1200 */       ImageProcessor slice = imagePlus.getStack().getProcessor(i);
/* 1201 */       for (int j = 0; j < slice.getPixelCount(); j++)
/*      */       {
/* 1203 */         max = Math.max(max, (int)slice.getf(j));
/*      */       }
/*      */     } 
/* 1206 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] findAllLabels(ImagePlus image) {
/* 1219 */     return (image.getStackSize() == 1) ? findAllLabels(image.getProcessor()) : 
/* 1220 */       findAllLabels(image.getStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] findAllLabels(ImageStack image) {
/* 1233 */     int sizeX = image.getWidth();
/* 1234 */     int sizeY = image.getHeight();
/* 1235 */     int sizeZ = image.getSize();
/*      */     
/* 1237 */     TreeSet<Integer> labels = new TreeSet<Integer>();
/*      */ 
/*      */     
/* 1240 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1242 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1244 */         for (int x = 0; x < sizeX; x++)
/*      */         {
/* 1246 */           labels.add(Integer.valueOf((int)image.getVoxel(x, y, z)));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1252 */     if (labels.contains(Integer.valueOf(0))) {
/* 1253 */       labels.remove(Integer.valueOf(0));
/*      */     }
/*      */     
/* 1256 */     int[] array = new int[labels.size()];
/* 1257 */     Iterator<Integer> iterator = labels.iterator();
/* 1258 */     for (int i = 0; i < labels.size(); i++) {
/* 1259 */       array[i] = ((Integer)iterator.next()).intValue();
/*      */     }
/* 1261 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] findAllLabels(ImageProcessor image) {
/* 1274 */     int sizeX = image.getWidth();
/* 1275 */     int sizeY = image.getHeight();
/*      */     
/* 1277 */     TreeSet<Integer> labels = new TreeSet<Integer>();
/*      */ 
/*      */     
/* 1280 */     if (image instanceof FloatProcessor) {
/*      */ 
/*      */       
/* 1283 */       for (int y = 0; y < sizeY; y++)
/*      */       {
/* 1285 */         for (int x = 0; x < sizeX; x++) {
/* 1286 */           labels.add(Integer.valueOf((int)image.getf(x, y)));
/*      */         }
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1292 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1294 */         for (int x = 0; x < sizeX; x++) {
/* 1295 */           labels.add(Integer.valueOf(image.get(x, y)));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1300 */     if (labels.contains(Integer.valueOf(0))) {
/* 1301 */       labels.remove(Integer.valueOf(0));
/*      */     }
/*      */     
/* 1304 */     int[] array = new int[labels.size()];
/* 1305 */     Iterator<Integer> iterator = labels.iterator();
/* 1306 */     for (int i = 0; i < labels.size(); i++) {
/* 1307 */       array[i] = ((Integer)iterator.next()).intValue();
/*      */     }
/* 1309 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImagePlus imagePlus, int[] labels, int newLabel) {
/* 1323 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/* 1326 */       ImageProcessor image = imagePlus.getProcessor();
/* 1327 */       replaceLabels(image, labels, newLabel);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1332 */       ImageStack image = imagePlus.getStack();
/* 1333 */       replaceLabels(image, labels, newLabel);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImagePlus imagePlus, float[] labels, float newLabel) {
/* 1348 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/* 1351 */       ImageProcessor image = imagePlus.getProcessor();
/* 1352 */       replaceLabels(image, labels, newLabel);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1357 */       ImageStack image = imagePlus.getStack();
/* 1358 */       replaceLabels(image, labels, newLabel);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImageProcessor image, int[] labels, int newLabel) {
/* 1371 */     int sizeX = image.getWidth();
/* 1372 */     int sizeY = image.getHeight();
/*      */     
/* 1374 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 1375 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1377 */       labelSet.add(Integer.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1380 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/* 1382 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/* 1384 */         int value = (int)image.getf(x, y);
/* 1385 */         if (value != newLabel)
/*      */         {
/* 1387 */           if (labelSet.contains(Integer.valueOf(value))) {
/* 1388 */             image.setf(x, y, newLabel);
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImageProcessor image, float[] labels, float newLabel) {
/* 1402 */     int sizeX = image.getWidth();
/* 1403 */     int sizeY = image.getHeight();
/*      */     
/* 1405 */     TreeSet<Float> labelSet = new TreeSet<Float>();
/* 1406 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1408 */       labelSet.add(Float.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1411 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/* 1413 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/* 1415 */         float value = image.getf(x, y);
/* 1416 */         if (value != newLabel)
/*      */         {
/* 1418 */           if (labelSet.contains(Float.valueOf(value))) {
/* 1419 */             image.setf(x, y, newLabel);
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImageStack image, int[] labels, int newLabel) {
/* 1433 */     int sizeX = image.getWidth();
/* 1434 */     int sizeY = image.getHeight();
/* 1435 */     int sizeZ = image.getSize();
/*      */     
/* 1437 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 1438 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1440 */       labelSet.add(Integer.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1443 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1445 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1447 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1449 */           int value = (int)image.getVoxel(x, y, z);
/* 1450 */           if (value != newLabel)
/*      */           {
/* 1452 */             if (labelSet.contains(Integer.valueOf(value))) {
/* 1453 */               image.setVoxel(x, y, z, newLabel);
/*      */             }
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replaceLabels(ImageStack image, float[] labels, float newLabel) {
/* 1471 */     int sizeX = image.getWidth();
/* 1472 */     int sizeY = image.getHeight();
/* 1473 */     int sizeZ = image.getSize();
/*      */     
/* 1475 */     TreeSet<Float> labelSet = new TreeSet<Float>();
/* 1476 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1478 */       labelSet.add(Float.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1481 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1483 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1485 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1487 */           float value = (float)image.getVoxel(x, y, z);
/* 1488 */           if (value != newLabel)
/*      */           {
/* 1490 */             if (labelSet.contains(Float.valueOf(value))) {
/* 1491 */               image.setVoxel(x, y, z, newLabel);
/*      */             }
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void remapLabels(ImagePlus imagePlus) {
/* 1507 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/* 1510 */       ImageProcessor image = imagePlus.getProcessor();
/* 1511 */       remapLabels(image);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1516 */       ImageStack image = imagePlus.getStack();
/* 1517 */       remapLabels(image);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void remapLabels(ImageProcessor image) {
/* 1529 */     int[] labels = findAllLabels(image);
/* 1530 */     HashMap<Integer, Integer> map = mapLabelIndices(labels);
/*      */     
/* 1532 */     for (int y = 0; y < image.getHeight(); y++) {
/*      */       
/* 1534 */       for (int x = 0; x < image.getWidth(); x++) {
/*      */         
/* 1536 */         int label = (int)image.getf(x, y);
/* 1537 */         if (label != 0)
/*      */         {
/* 1539 */           image.setf(x, y, (((Integer)map.get(Integer.valueOf(label))).intValue() + 1));
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void remapLabels(ImageStack image) {
/* 1552 */     int[] labels = findAllLabels(image);
/* 1553 */     HashMap<Integer, Integer> map = mapLabelIndices(labels);
/*      */     
/* 1555 */     for (int z = 0; z < image.getSize(); z++) {
/*      */       
/* 1557 */       for (int y = 0; y < image.getHeight(); y++) {
/*      */         
/* 1559 */         for (int x = 0; x < image.getWidth(); x++) {
/*      */           
/* 1561 */           int label = (int)image.getVoxel(x, y, z);
/* 1562 */           if (label != 0)
/*      */           {
/* 1564 */             image.setVoxel(x, y, z, (((Integer)map.get(Integer.valueOf(label))).intValue() + 1));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImagePlus keepLabels(ImagePlus imagePlus, int[] labels) {
/*      */     ImagePlus resultPlus;
/* 1583 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-keepLabels";
/*      */ 
/*      */     
/* 1586 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/* 1589 */       ImageProcessor image = imagePlus.getProcessor();
/* 1590 */       ImageProcessor result = keepLabels(image, labels);
/* 1591 */       if (!(result instanceof ColorProcessor))
/* 1592 */         result.setLut(image.getLut()); 
/* 1593 */       resultPlus = new ImagePlus(newName, result);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1598 */       ImageStack image = imagePlus.getStack();
/* 1599 */       ImageStack result = keepLabels(image, labels);
/* 1600 */       result.setColorModel(image.getColorModel());
/* 1601 */       resultPlus = new ImagePlus(newName, result);
/*      */     } 
/*      */     
/* 1604 */     resultPlus.copyScale(imagePlus);
/* 1605 */     resultPlus.setDisplayRange(imagePlus.getDisplayRangeMin(), imagePlus.getDisplayRangeMax());
/*      */     
/* 1607 */     return resultPlus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageProcessor keepLabels(ImageProcessor image, int[] labels) {
/* 1621 */     int sizeX = image.getWidth();
/* 1622 */     int sizeY = image.getHeight();
/*      */     
/* 1624 */     ImageProcessor result = image.createProcessor(sizeX, sizeY);
/*      */     
/* 1626 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 1627 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1629 */       labelSet.add(Integer.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1632 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/* 1634 */       for (int x = 0; x < sizeX; x++) {
/*      */         
/* 1636 */         int value = (int)image.getf(x, y);
/* 1637 */         if (value != 0)
/*      */         {
/* 1639 */           if (labelSet.contains(Integer.valueOf(value)))
/* 1640 */             result.setf(x, y, value); 
/*      */         }
/*      */       } 
/*      */     } 
/* 1644 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack keepLabels(ImageStack image, int[] labels) {
/* 1658 */     int sizeX = image.getWidth();
/* 1659 */     int sizeY = image.getHeight();
/* 1660 */     int sizeZ = image.getSize();
/*      */     
/* 1662 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, image.getBitDepth());
/*      */     
/* 1664 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 1665 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1667 */       labelSet.add(Integer.valueOf(labels[i]));
/*      */     }
/*      */     
/* 1670 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1672 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1674 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1676 */           int value = (int)image.getVoxel(x, y, z);
/* 1677 */           if (value != 0)
/*      */           {
/* 1679 */             if (labelSet.contains(Integer.valueOf(value)))
/* 1680 */               result.setVoxel(x, y, z, value); 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1685 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final FloatProcessor applyLut(ImageProcessor labelImage, double[] values) {
/* 1701 */     int width = labelImage.getWidth();
/* 1702 */     int height = labelImage.getHeight();
/*      */     
/* 1704 */     FloatProcessor resultImage = new FloatProcessor(width, height);
/*      */ 
/*      */     
/* 1707 */     int[] labels = findAllLabels(labelImage);
/*      */ 
/*      */     
/* 1710 */     HashMap<Integer, Integer> labelIndices = mapLabelIndices(labels);
/*      */     
/* 1712 */     for (int y = 0; y < height; y++) {
/*      */       
/* 1714 */       for (int x = 0; x < width; x++) {
/*      */         
/* 1716 */         int label = (int)labelImage.getf(x, y);
/* 1717 */         if (label == 0) {
/*      */           
/* 1719 */           resultImage.setf(x, y, Float.NaN);
/*      */         }
/*      */         else {
/*      */           
/* 1723 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*      */           
/* 1725 */           if (index >= values.length) {
/* 1726 */             throw new RuntimeException("Try to access index " + index + 
/* 1727 */                 " in array with " + values.length + " values");
/*      */           }
/*      */           
/* 1730 */           double value = values[index];
/* 1731 */           resultImage.setf(x, y, (float)value);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1735 */     return resultImage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack applyLut(ImageStack labelImage, double[] values) {
/* 1751 */     int sizeX = labelImage.getWidth();
/* 1752 */     int sizeY = labelImage.getHeight();
/* 1753 */     int sizeZ = labelImage.getSize();
/*      */     
/* 1755 */     ImageStack resultImage = ImageStack.create(sizeX, sizeY, sizeZ, 32);
/*      */ 
/*      */     
/* 1758 */     int[] labels = findAllLabels(labelImage);
/*      */ 
/*      */     
/* 1761 */     HashMap<Integer, Integer> labelIndices = mapLabelIndices(labels);
/*      */ 
/*      */     
/* 1764 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 1766 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 1768 */         for (int x = 0; x < sizeX; x++) {
/*      */           
/* 1770 */           int label = (int)labelImage.getVoxel(x, y, z);
/* 1771 */           if (label == 0) {
/*      */             
/* 1773 */             resultImage.setVoxel(x, y, z, Double.NaN);
/*      */           }
/*      */           else {
/*      */             
/* 1777 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*      */             
/* 1779 */             if (index >= values.length)
/*      */             {
/* 1781 */               throw new RuntimeException("Try to access index " + index + 
/* 1782 */                   " in array with " + values.length + " values");
/*      */             }
/*      */             
/* 1785 */             double value = values[index];
/* 1786 */             resultImage.setVoxel(x, y, z, value);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1791 */     return resultImage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final HashMap<Integer, Integer> mapLabelIndices(int[] labels) {
/* 1815 */     int nLabels = labels.length;
/* 1816 */     HashMap<Integer, Integer> labelIndices = new HashMap<Integer, Integer>();
/* 1817 */     for (int i = 0; i < nLabels; i++)
/*      */     {
/* 1819 */       labelIndices.put(Integer.valueOf(labels[i]), Integer.valueOf(i));
/*      */     }
/*      */     
/* 1822 */     return labelIndices;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void mergeLabels(ImagePlus labelImage, Roi roi, boolean verbose) {
/* 1839 */     if (roi == null) {
/*      */       
/* 1841 */       IJ.showMessage("Please select some labels to merge using the freehand or point selection tool.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1846 */     ArrayList<Float> list = getSelectedLabels(labelImage, roi);
/*      */ 
/*      */     
/* 1849 */     if (list.size() > 1) {
/*      */       
/* 1851 */       float finalValue = ((Float)list.remove(0)).floatValue();
/* 1852 */       float[] labelArray = new float[list.size()];
/* 1853 */       int i = 0;
/*      */       
/* 1855 */       for (Float f : list) {
/* 1856 */         labelArray[i++] = (f != null) ? f.floatValue() : Float.NaN;
/*      */       }
/* 1858 */       String sLabels = new String((long)labelArray[0]);
/* 1859 */       for (int j = 1; j < labelArray.length; j++)
/* 1860 */         sLabels = String.valueOf(sLabels) + ", " + (long)labelArray[j]; 
/* 1861 */       if (verbose)
/* 1862 */         IJ.log("Merging label(s) " + sLabels + " to label " + 
/* 1863 */             (long)finalValue); 
/* 1864 */       replaceLabels(labelImage, 
/* 1865 */           labelArray, finalValue);
/*      */     } else {
/*      */       
/* 1868 */       IJ.error("Please select two or more different labels to merge");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void mergeLabelsWithGap(ImagePlus labelImage, Roi roi, int conn, boolean verbose) {
/* 1888 */     if (roi == null) {
/*      */       
/* 1890 */       IJ.showMessage("Please select some labels to merge using the freehand or point selection tool.");
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1896 */     ArrayList<Float> list = getSelectedLabels(labelImage, roi);
/* 1897 */     if (list.size() <= 1)
/*      */     {
/* 1899 */       IJ.error("Please select two or more different labels to merge");
/*      */     }
/*      */ 
/*      */     
/* 1903 */     float finalValue = ((Float)list.get(0)).floatValue();
/*      */ 
/*      */     
/* 1906 */     float[] labelArray = new float[list.size()];
/* 1907 */     int i = 0;
/* 1908 */     for (Float f : list) {
/* 1909 */       labelArray[i++] = (f != null) ? f.floatValue() : Float.NaN;
/*      */     }
/*      */     
/* 1912 */     String sLabels = new String((long)labelArray[0]);
/* 1913 */     for (int j = 1; j < labelArray.length; j++)
/* 1914 */       sLabels = String.valueOf(sLabels) + ", " + (long)labelArray[j]; 
/* 1915 */     if (verbose) {
/* 1916 */       IJ.log("Merging label(s) " + sLabels + " to label " + 
/* 1917 */           (long)finalValue + " filling gap with conn " + conn);
/*      */     }
/* 1919 */     mergeLabelsWithGap(labelImage, labelArray, finalValue, conn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void mergeLabelsWithGap(ImagePlus imagePlus, float[] labels, float newLabel, int conn) {
/* 1940 */     if (imagePlus.getStackSize() == 1) {
/*      */ 
/*      */       
/* 1943 */       ImageProcessor image = imagePlus.getProcessor();
/* 1944 */       mergeLabelsWithGap(image, labels, newLabel, conn);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1949 */       ImageStack image = imagePlus.getStack();
/* 1950 */       mergeLabelsWithGap(image, labels, newLabel, conn);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void mergeLabelsWithGap(ImageProcessor image, float[] labels, float newLabel, int conn) {
/* 1972 */     int shifts[][], sizeX = image.getWidth();
/* 1973 */     int sizeY = image.getHeight();
/*      */ 
/*      */     
/* 1976 */     TreeSet<Float> labelSet = new TreeSet<Float>();
/* 1977 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 1979 */       labelSet.add(Float.valueOf(labels[i]));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1984 */     if (conn == 4) {
/*      */       
/* 1986 */       shifts = new int[][] { { 0, -1 }, { -1 }, { 1 }, { 0, 1 } };
/*      */     }
/* 1988 */     else if (conn == 8) {
/*      */       
/* 1990 */       shifts = new int[][] {
/* 1991 */           { -1, -1 }, { 0, -1 }, { 1, -1
/* 1992 */           }, { -1 }, { 1
/* 1993 */           }, { -1, 1 }, { 0, 1 }, { 1, 1 }
/*      */         };
/*      */     } else {
/*      */       
/* 1997 */       throw new IllegalArgumentException("Connectivity value should be either 4 or 8.");
/*      */     } 
/*      */ 
/*      */     
/* 2001 */     ArrayList<Cursor2D> boundaryPixels = new ArrayList<Cursor2D>();
/*      */ 
/*      */     
/* 2004 */     for (int y = 0; y < sizeY; y++) {
/*      */       
/* 2006 */       for (int x = 0; x < sizeX; x++) {
/*      */ 
/*      */         
/* 2009 */         if (image.getf(x, y) == 0.0F) {
/*      */ 
/*      */ 
/*      */           
/* 2013 */           ArrayList<Float> neighborLabels = new ArrayList<Float>(shifts.length); byte b; int j, arrayOfInt[][];
/* 2014 */           for (j = (arrayOfInt = shifts).length, b = 0; b < j; ) { int[] shift = arrayOfInt[b];
/*      */             
/* 2016 */             int x2 = x + shift[0];
/* 2017 */             if (x2 >= 0 && x2 < sizeX) {
/*      */               
/* 2019 */               int y2 = y + shift[1];
/* 2020 */               if (y2 >= 0 && y2 < sizeY) {
/*      */                 
/* 2022 */                 float value2 = image.getf(x2, y2);
/* 2023 */                 if (value2 != 0.0F)
/*      */                 {
/* 2025 */                   if (!neighborLabels.contains(Float.valueOf(value2)))
/*      */                   {
/* 2027 */                     neighborLabels.add(Float.valueOf(value2)); }  } 
/*      */               } 
/*      */             } 
/*      */             b++; }
/*      */           
/* 2032 */           if (neighborLabels.size() > 1 && labelSet.containsAll(neighborLabels)) {
/* 2033 */             boundaryPixels.add(new Cursor2D(x, y));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2038 */     replaceLabels(image, labels, newLabel);
/*      */     
/* 2040 */     for (Cursor2D c : boundaryPixels) {
/* 2041 */       image.setf(c.getX(), c.getY(), newLabel);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void mergeLabelsWithGap(ImageStack image, float[] labels, float newLabel, int conn) {
/* 2058 */     int shifts[][], sizeX = image.getWidth();
/* 2059 */     int sizeY = image.getHeight();
/* 2060 */     int sizeZ = image.getSize();
/*      */ 
/*      */     
/* 2063 */     TreeSet<Float> labelSet = new TreeSet<Float>();
/* 2064 */     for (int i = 0; i < labels.length; i++)
/*      */     {
/* 2066 */       labelSet.add(Float.valueOf(labels[i]));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2071 */     if (conn == 6) {
/*      */       
/* 2073 */       shifts = new int[][] { { 0, 0, -1 }, { 0, -1 }, { -1 }, { 1 }, { 0, 1 }, { 0, 0, 1 } };
/*      */     }
/* 2075 */     else if (conn == 26) {
/*      */       
/* 2077 */       shifts = new int[][] {
/*      */           
/* 2079 */           { -1, -1, -1 }, { 0, -1, -1 }, { 1, -1, -1 }, { -1, -1 }, { 0, 0, -1 }, { 1, -1 }, { -1, 1, -1 }, { 0, 1, -1 }, { 1, 1, -1
/*      */           },
/* 2081 */           { -1, -1 }, { 0, -1 }, { 1, -1 }, { -1 }, { 1 }, { -1, 1 }, { 0, 1 }, { 1, 1
/*      */           },
/* 2083 */           { -1, -1, 1 }, { 0, -1, 1 }, { 1, -1, 1 }, { -1, 1 }, { 0, 0, 1 }, { 1, 1 }, { -1, 1, 1 }, { 0, 1, 1 }, { 1, 1, 1 }
/*      */         };
/*      */     } else {
/*      */       
/* 2087 */       throw new IllegalArgumentException("Connectivity value should be either 6 or 26.");
/*      */     } 
/*      */ 
/*      */     
/* 2091 */     ArrayList<Cursor3D> boundaryVoxels = new ArrayList<Cursor3D>();
/*      */ 
/*      */     
/* 2094 */     for (int z = 0; z < sizeZ; z++) {
/*      */       
/* 2096 */       for (int y = 0; y < sizeY; y++) {
/*      */         
/* 2098 */         for (int x = 0; x < sizeX; x++) {
/*      */ 
/*      */           
/* 2101 */           if (image.getVoxel(x, y, z) == 0.0D) {
/*      */ 
/*      */ 
/*      */             
/* 2105 */             ArrayList<Float> neighborLabels = new ArrayList<Float>(shifts.length); byte b; int j, arrayOfInt[][];
/* 2106 */             for (j = (arrayOfInt = shifts).length, b = 0; b < j; ) { int[] shift = arrayOfInt[b];
/*      */               
/* 2108 */               int x2 = x + shift[0];
/* 2109 */               if (x2 >= 0 && x2 < sizeX) {
/*      */                 
/* 2111 */                 int y2 = y + shift[1];
/* 2112 */                 if (y2 >= 0 && y2 < sizeY) {
/*      */                   
/* 2114 */                   int z2 = z + shift[2];
/* 2115 */                   if (z2 >= 0 && z2 < sizeZ) {
/*      */                     
/* 2117 */                     float value2 = (float)image.getVoxel(x2, y2, z2);
/* 2118 */                     if (value2 != 0.0F)
/*      */                     {
/* 2120 */                       if (!neighborLabels.contains(Float.valueOf(value2)))
/*      */                       {
/* 2122 */                         neighborLabels.add(Float.valueOf(value2)); }  } 
/*      */                   } 
/*      */                 } 
/*      */               }  b++; }
/*      */             
/* 2127 */             if (neighborLabels.size() > 1 && labelSet.containsAll(neighborLabels)) {
/* 2128 */               boundaryVoxels.add(new Cursor3D(x, y, z));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2134 */     replaceLabels(image, labels, newLabel);
/*      */     
/* 2136 */     for (Cursor3D c : boundaryVoxels) {
/* 2137 */       image.setVoxel(c.getX(), c.getY(), c.getZ(), newLabel);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeLabels(ImagePlus labelImage, Roi roi, boolean verbose) {
/* 2152 */     if (roi == null) {
/*      */       
/* 2154 */       IJ.showMessage("Please select at least one label to be removed using the freehand or point selection tools.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2159 */     ArrayList<Float> list = getSelectedLabels(labelImage, roi);
/*      */     
/* 2161 */     if (list.size() > 0) {
/*      */ 
/*      */       
/* 2164 */       float[] labelArray = new float[list.size()];
/* 2165 */       int i = 0;
/* 2166 */       for (Float f : list) {
/* 2167 */         labelArray[i++] = (f != null) ? f.floatValue() : Float.NaN;
/*      */       }
/* 2169 */       String sLabels = new String((long)labelArray[0]);
/* 2170 */       for (int j = 1; j < labelArray.length; j++)
/* 2171 */         sLabels = String.valueOf(sLabels) + ", " + (long)labelArray[j]; 
/* 2172 */       if (verbose) {
/* 2173 */         IJ.log("Removing label(s) " + sLabels + "...");
/*      */       }
/* 2175 */       replaceLabels(labelImage, 
/* 2176 */           labelArray, 0.0F);
/*      */     } else {
/*      */       
/* 2179 */       IJ.error("Please select at least one label to remove.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image) {
/* 2194 */     float[] weights = { 3.0F, 4.0F, 5.0F };
/* 2195 */     DistanceTransform3DFloat distanceTransform3DFloat = new DistanceTransform3DFloat(weights);
/* 2196 */     return distanceTransform3DFloat.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image, short[] weights, boolean normalize) {
/* 2217 */     DistanceTransform3DShort distanceTransform3DShort = new DistanceTransform3DShort(weights, normalize);
/*      */     
/* 2219 */     return distanceTransform3DShort.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ImageStack distanceMap(ImageStack image, float[] weights, boolean normalize) {
/* 2240 */     DistanceTransform3DFloat distanceTransform3DFloat = new DistanceTransform3DFloat(weights, normalize);
/* 2241 */     return distanceTransform3DFloat.distanceMap(image);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ArrayList<Float> getSelectedLabels(ImagePlus labelImage, Roi roi) {
/* 2257 */     ArrayList<Float> list = new ArrayList<Float>();
/* 2258 */     labelImage.setRoi(roi);
/*      */     
/* 2260 */     if (roi instanceof PointRoi) {
/*      */       
/* 2262 */       int[] xpoints = (roi.getPolygon()).xpoints;
/* 2263 */       int[] ypoints = (roi.getPolygon()).ypoints;
/*      */ 
/*      */       
/* 2266 */       if (labelImage.getImageStackSize() > 1) {
/*      */         
/* 2268 */         ImageStack labelStack = labelImage.getImageStack();
/* 2269 */         for (int i = 0; i < xpoints.length; i++) {
/*      */           
/* 2271 */           float value = (float)labelStack.getVoxel(
/* 2272 */               xpoints[i], 
/* 2273 */               ypoints[i], (
/* 2274 */               (PointRoi)roi).getPointPosition(i) - 1);
/* 2275 */           if (Float.compare(0.0F, value) != 0 && 
/* 2276 */             !list.contains(Float.valueOf(value))) {
/* 2277 */             list.add(Float.valueOf(value));
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/* 2282 */         ImageProcessor ip = labelImage.getProcessor();
/* 2283 */         for (int i = 0; i < xpoints.length; i++)
/*      */         {
/* 2285 */           float value = ip.getf(xpoints[i], ypoints[i]);
/* 2286 */           if (Float.compare(0.0F, value) != 0 && 
/* 2287 */             !list.contains(Float.valueOf(value))) {
/* 2288 */             list.add(Float.valueOf(value));
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/* 2293 */     } else if (roi.isLine() && roi.getStrokeWidth() <= 1.0F) {
/*      */ 
/*      */ 
/*      */       
/* 2297 */       boolean interpolateOption = PlotWindow.interpolate;
/*      */       
/* 2299 */       PlotWindow.interpolate = false;
/*      */       
/* 2301 */       float[] values = (new ProfilePlot(labelImage))
/* 2302 */         .getPlot().getYValues();
/* 2303 */       PlotWindow.interpolate = interpolateOption;
/*      */       
/* 2305 */       for (int i = 0; i < values.length; i++) {
/*      */         
/* 2307 */         if (Float.compare(0.0F, values[i]) != 0 && 
/* 2308 */           !list.contains(Float.valueOf(values[i]))) {
/* 2309 */           list.add(Float.valueOf(values[i]));
/*      */         }
/*      */       } 
/* 2312 */     } else if (roi.getType() == 7) {
/*      */       
/* 2314 */       int width = Math.round(roi.getStrokeWidth());
/* 2315 */       FloatPolygon p = roi.getFloatPolygon();
/* 2316 */       int n = p.npoints;
/* 2317 */       ImageProcessor ip = labelImage.getProcessor();
/*      */       
/* 2319 */       double x2 = (p.xpoints[0] - p.xpoints[1] - p.xpoints[0]);
/* 2320 */       double y2 = (p.ypoints[0] - p.ypoints[1] - p.ypoints[0]);
/* 2321 */       for (int i = 0; i < n; ) {
/*      */         
/* 2323 */         double x1 = x2;
/* 2324 */         double y1 = y2;
/* 2325 */         x2 = p.xpoints[i];
/* 2326 */         y2 = p.ypoints[i];
/*      */         
/* 2328 */         double dx = x2 - x1;
/* 2329 */         double dy = y1 - y2;
/* 2330 */         double length = (float)Math.sqrt(dx * dx + dy * dy);
/* 2331 */         dx /= length;
/* 2332 */         dy /= length;
/* 2333 */         double x = x2 - dy * width / 2.0D;
/* 2334 */         double y = y2 - dx * width / 2.0D;
/*      */         
/* 2336 */         int n2 = width;
/*      */         
/*      */         while (true) {
/* 2339 */           float value = ip.getf((int)(x + 0.5D), (int)(y + 0.5D));
/* 2340 */           if (Float.compare(0.0F, value) != 0 && 
/* 2341 */             !list.contains(Float.valueOf(value)))
/* 2342 */             list.add(Float.valueOf(value)); 
/* 2343 */           x += dy;
/* 2344 */           y += dx;
/* 2345 */           if (--n2 <= 0)
/*      */             i++; 
/*      */         } 
/*      */       } 
/* 2349 */     } else if (roi.getType() == 0 && roi.getCornerDiameter() == 0) {
/*      */       
/* 2351 */       Rectangle rect = roi.getBounds();
/*      */       
/* 2353 */       int x0 = rect.x;
/* 2354 */       int y0 = rect.y;
/*      */       
/* 2356 */       int lastX = x0 + rect.width;
/* 2357 */       int lastY = y0 + rect.height;
/* 2358 */       ImageProcessor ip = labelImage.getProcessor();
/* 2359 */       for (int x = x0; x < lastX; x++) {
/* 2360 */         for (int y = y0; y < lastY; y++) {
/*      */           
/* 2362 */           float value = ip.getf(x, y);
/* 2363 */           if (Float.compare(0.0F, value) != 0 && 
/* 2364 */             !list.contains(Float.valueOf(value))) {
/* 2365 */             list.add(Float.valueOf(value));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2370 */       ShapeRoi shapeRoi = roi.isLine() ? new ShapeRoi(Selection.lineToArea(roi)) : 
/* 2371 */         new ShapeRoi(roi);
/* 2372 */       Rectangle rect = shapeRoi.getBounds();
/*      */       
/* 2374 */       int lastX = rect.x + rect.width;
/* 2375 */       if (lastX >= labelImage.getWidth())
/* 2376 */         lastX = labelImage.getWidth() - 1; 
/* 2377 */       int lastY = rect.y + rect.height;
/* 2378 */       if (lastY >= labelImage.getHeight())
/* 2379 */         lastY = labelImage.getHeight() - 1; 
/* 2380 */       int firstX = Math.max(rect.x, 0);
/* 2381 */       int firstY = Math.max(rect.y, 0);
/*      */       
/* 2383 */       ImageProcessor ip = labelImage.getProcessor();
/*      */ 
/*      */       
/* 2386 */       ByteProcessor bp = new ByteProcessor(rect.width, rect.height);
/* 2387 */       bp.setValue(255.0D);
/* 2388 */       shapeRoi.setLocation(0, 0);
/* 2389 */       bp.fill((Roi)shapeRoi);
/*      */       
/* 2391 */       for (int x = firstX, rectX = 0; x < lastX; x++, rectX++) {
/* 2392 */         for (int y = firstY, rectY = 0; y < lastY; y++, rectY++) {
/* 2393 */           if (bp.getf(rectX, rectY) > 0.0F)
/*      */           
/* 2395 */           { float value = ip.getf(x, y);
/* 2396 */             if (Float.compare(0.0F, value) != 0 && 
/* 2397 */               !list.contains(Float.valueOf(value)))
/* 2398 */               list.add(Float.valueOf(value));  } 
/*      */         } 
/*      */       } 
/* 2401 */     }  return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getTotalOverlap(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 2416 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 2417 */       sourceImage.getHeight() != targetImage.getHeight())
/* 2418 */       return -1.0D; 
/* 2419 */     double intersection = 0.0D;
/* 2420 */     double numPixTarget = 0.0D;
/*      */     
/* 2422 */     for (int i = 0; i < sourceImage.getWidth(); i++) {
/* 2423 */       for (int j = 0; j < sourceImage.getHeight(); j++) {
/*      */         
/* 2425 */         if (sourceImage.getf(i, j) > 0.0F)
/*      */         {
/* 2427 */           if (sourceImage.getf(i, j) == targetImage.getf(i, j))
/* 2428 */             intersection++; 
/*      */         }
/* 2430 */         if (targetImage.getf(i, j) > 0.0F)
/* 2431 */           numPixTarget++; 
/*      */       } 
/*      */     } 
/* 2434 */     return intersection / numPixTarget;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getTargetOverlapPerLabel(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 2450 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 2451 */       sourceImage.getHeight() != targetImage.getHeight()) {
/* 2452 */       return null;
/*      */     }
/* 2454 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 2455 */     double[] intersection = new double[sourceLabels.length];
/*      */     
/* 2457 */     HashMap<Integer, Integer> sourceLabelIndices = mapLabelIndices(sourceLabels);
/*      */     
/* 2459 */     int[] targetLabels = findAllLabels(targetImage);
/* 2460 */     int[] numPixTarget = pixelCount(targetImage, targetLabels);
/*      */ 
/*      */     
/* 2463 */     HashMap<Integer, Integer> targetLabelIndices = mapLabelIndices(targetLabels);
/*      */     
/*      */     int i;
/* 2466 */     for (i = 0; i < sourceImage.getWidth(); i++) {
/* 2467 */       for (int k = 0; k < sourceImage.getHeight(); k++) {
/* 2468 */         if (sourceImage.getf(i, k) > 0.0F)
/*      */         {
/* 2470 */           if (sourceImage.getf(i, k) == targetImage.getf(i, k))
/* 2471 */             intersection[((Integer)sourceLabelIndices.get(Integer.valueOf((int)sourceImage.getf(i, k)))).intValue()] = intersection[((Integer)sourceLabelIndices.get(Integer.valueOf((int)sourceImage.getf(i, k)))).intValue()] + 1.0D;  } 
/*      */       } 
/*      */     } 
/* 2474 */     for (i = 0; i < intersection.length; i++) {
/* 2475 */       intersection[i] = (targetLabelIndices.get(Integer.valueOf(sourceLabels[i])) != null) ? (
/* 2476 */         intersection[i] / numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()]) : 0.0D;
/*      */     }
/* 2478 */     ResultsTable table = new ResultsTable();
/* 2479 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 2480 */       table.incrementCounter();
/* 2481 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 2482 */       table.addValue("TargetOverlap", intersection[j]);
/*      */     } 
/* 2484 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getTotalOverlap(ImageStack sourceImage, ImageStack targetImage) {
/* 2499 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 2500 */       sourceImage.getHeight() != targetImage.getHeight())
/* 2501 */       return -1.0D; 
/* 2502 */     double intersection = 0.0D;
/* 2503 */     double numPixTarget = 0.0D;
/*      */     
/* 2505 */     for (int k = 0; k < sourceImage.getSize(); k++) {
/*      */       
/* 2507 */       ImageProcessor ls = sourceImage.getProcessor(k + 1);
/* 2508 */       ImageProcessor lt = targetImage.getProcessor(k + 1);
/* 2509 */       for (int i = 0; i < sourceImage.getWidth(); i++) {
/* 2510 */         for (int j = 0; j < sourceImage.getHeight(); j++) {
/*      */           
/* 2512 */           if (ls.getf(i, j) > 0.0F)
/*      */           {
/* 2514 */             if (ls.getf(i, j) == lt.getf(i, j))
/* 2515 */               intersection++; 
/*      */           }
/* 2517 */           if (lt.getf(i, j) > 0.0F)
/* 2518 */             numPixTarget++; 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2522 */     return intersection / numPixTarget;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getTotalOverlap(ImagePlus sourceImage, ImagePlus targetImage) {
/* 2537 */     return getTotalOverlap(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getTargetOverlapPerLabel(ImageStack sourceImage, ImageStack targetImage) {
/* 2554 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 2555 */       sourceImage.getHeight() != targetImage.getHeight()) {
/* 2556 */       return null;
/*      */     }
/* 2558 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 2559 */     double[] intersection = new double[sourceLabels.length];
/*      */     
/* 2561 */     HashMap<Integer, Integer> sourceLabelIndices = mapLabelIndices(sourceLabels);
/*      */     
/* 2563 */     int[] targetLabels = findAllLabels(targetImage);
/* 2564 */     int[] numPixTarget = voxelCount(targetImage, targetLabels);
/*      */ 
/*      */     
/* 2567 */     HashMap<Integer, Integer> targetLabelIndices = mapLabelIndices(targetLabels);
/*      */     
/* 2569 */     for (int k = 0; k < sourceImage.getSize(); k++) {
/*      */       
/* 2571 */       ImageProcessor ls = sourceImage.getProcessor(k + 1);
/* 2572 */       ImageProcessor lt = targetImage.getProcessor(k + 1);
/* 2573 */       for (int m = 0; m < sourceImage.getWidth(); m++) {
/* 2574 */         for (int n = 0; n < sourceImage.getHeight(); n++) {
/* 2575 */           if (ls.getf(m, n) > 0.0F)
/*      */           {
/* 2577 */             if (ls.getf(m, n) == lt.getf(m, n))
/* 2578 */               intersection[((Integer)sourceLabelIndices.get(Integer.valueOf((int)ls.getf(m, n)))).intValue()] = intersection[((Integer)sourceLabelIndices.get(Integer.valueOf((int)ls.getf(m, n)))).intValue()] + 1.0D;  } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2582 */     for (int i = 0; i < intersection.length; i++) {
/* 2583 */       intersection[i] = (targetLabelIndices.get(Integer.valueOf(sourceLabels[i])) != null) ? (
/* 2584 */         intersection[i] / numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()]) : 0.0D;
/*      */     }
/* 2586 */     ResultsTable table = new ResultsTable();
/* 2587 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 2588 */       table.incrementCounter();
/* 2589 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 2590 */       table.addValue("TargetOverlap", intersection[j]);
/*      */     } 
/* 2592 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getTargetOverlapPerLabel(ImagePlus sourceImage, ImagePlus targetImage) {
/* 2608 */     return getTargetOverlapPerLabel(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getJaccardIndex(ImageProcessor labelImage1, ImageProcessor labelImage2) {
/* 2622 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2623 */       labelImage1.getHeight() != labelImage2.getHeight())
/* 2624 */       return -1.0D; 
/* 2625 */     double intersection = 0.0D;
/* 2626 */     double numPix1 = 0.0D;
/* 2627 */     double numPix2 = 0.0D;
/*      */     
/* 2629 */     for (int i = 0; i < labelImage1.getWidth(); i++) {
/* 2630 */       for (int j = 0; j < labelImage1.getHeight(); j++) {
/*      */         
/* 2632 */         if (labelImage1.getf(i, j) > 0.0F) {
/*      */           
/* 2634 */           numPix1++;
/* 2635 */           if (labelImage1.getf(i, j) == labelImage2.getf(i, j))
/* 2636 */             intersection++; 
/*      */         } 
/* 2638 */         if (labelImage2.getf(i, j) > 0.0F)
/* 2639 */           numPix2++; 
/*      */       } 
/*      */     } 
/* 2642 */     return intersection / (numPix1 + numPix2 - intersection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getJaccardIndexPerLabel(ImageProcessor labelImage1, ImageProcessor labelImage2) {
/* 2656 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2657 */       labelImage1.getHeight() != labelImage2.getHeight()) {
/* 2658 */       return null;
/*      */     }
/* 2660 */     int[] labels1 = findAllLabels(labelImage1);
/* 2661 */     int[] numPix1 = pixelCount(labelImage1, labels1);
/* 2662 */     double[] intersection = new double[labels1.length];
/*      */     
/* 2664 */     HashMap<Integer, Integer> labelIndices1 = mapLabelIndices(labels1);
/*      */     
/* 2666 */     int[] labels2 = findAllLabels(labelImage2);
/* 2667 */     int[] numPix2 = pixelCount(labelImage2, labels2);
/*      */ 
/*      */     
/* 2670 */     HashMap<Integer, Integer> labelIndices2 = mapLabelIndices(labels2);
/*      */     
/*      */     int i;
/* 2673 */     for (i = 0; i < labelImage1.getWidth(); i++) {
/* 2674 */       for (int k = 0; k < labelImage1.getHeight(); k++) {
/* 2675 */         if (labelImage1.getf(i, k) > 0.0F)
/*      */         {
/* 2677 */           if (labelImage1.getf(i, k) == labelImage2.getf(i, k))
/* 2678 */             intersection[((Integer)labelIndices1.get(Integer.valueOf((int)labelImage1.getf(i, k)))).intValue()] = intersection[((Integer)labelIndices1.get(Integer.valueOf((int)labelImage1.getf(i, k)))).intValue()] + 1.0D;  } 
/*      */       } 
/*      */     } 
/* 2681 */     for (i = 0; i < intersection.length; i++) {
/*      */       
/* 2683 */       int num2 = (labelIndices2.get(Integer.valueOf(labels1[i])) != null) ? numPix2[((Integer)labelIndices2.get(Integer.valueOf(labels1[i]))).intValue()] : 0;
/* 2684 */       intersection[i] = intersection[i] / ((numPix1[i] + num2) - intersection[i]);
/*      */     } 
/*      */     
/* 2687 */     ResultsTable table = new ResultsTable();
/* 2688 */     for (int j = 0; j < labels1.length; j++) {
/* 2689 */       table.incrementCounter();
/* 2690 */       table.addLabel(Integer.toString(labels1[j]));
/* 2691 */       table.addValue("JaccardIndex", intersection[j]);
/*      */     } 
/* 2693 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getJaccardIndex(ImageStack labelImage1, ImageStack labelImage2) {
/* 2707 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2708 */       labelImage1.getHeight() != labelImage2.getHeight() || 
/* 2709 */       labelImage1.getSize() != labelImage2.getSize())
/* 2710 */       return -1.0D; 
/* 2711 */     double intersection = 0.0D;
/* 2712 */     double numPix1 = 0.0D;
/* 2713 */     double numPix2 = 0.0D;
/*      */     
/* 2715 */     for (int k = 0; k < labelImage1.getSize(); k++) {
/*      */       
/* 2717 */       ImageProcessor l1 = labelImage1.getProcessor(k + 1);
/* 2718 */       ImageProcessor l2 = labelImage2.getProcessor(k + 1);
/* 2719 */       for (int i = 0; i < labelImage1.getWidth(); i++) {
/* 2720 */         for (int j = 0; j < labelImage1.getHeight(); j++) {
/*      */           
/* 2722 */           if (l1.getf(i, j) > 0.0F) {
/*      */             
/* 2724 */             numPix1++;
/* 2725 */             if (l1.getf(i, j) == l2.getf(i, j))
/* 2726 */               intersection++; 
/*      */           } 
/* 2728 */           if (l2.getf(i, j) > 0.0F)
/* 2729 */             numPix2++; 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2733 */     return intersection / (numPix1 + numPix2 - intersection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getJaccardIndexPerLabel(ImageStack labelImage1, ImageStack labelImage2) {
/* 2747 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2748 */       labelImage1.getHeight() != labelImage2.getHeight()) {
/* 2749 */       return null;
/*      */     }
/* 2751 */     int[] labels1 = findAllLabels(labelImage1);
/* 2752 */     int[] numPix1 = voxelCount(labelImage1, labels1);
/* 2753 */     double[] intersection = new double[labels1.length];
/*      */     
/* 2755 */     HashMap<Integer, Integer> labelIndices1 = mapLabelIndices(labels1);
/*      */     
/* 2757 */     int[] labels2 = findAllLabels(labelImage2);
/* 2758 */     int[] numPix2 = voxelCount(labelImage2, labels2);
/*      */ 
/*      */     
/* 2761 */     HashMap<Integer, Integer> labelIndices2 = mapLabelIndices(labels2);
/*      */ 
/*      */     
/* 2764 */     for (int k = 0; k < labelImage1.getSize(); k++) {
/*      */       
/* 2766 */       ImageProcessor l1 = labelImage1.getProcessor(k + 1);
/* 2767 */       ImageProcessor l2 = labelImage2.getProcessor(k + 1);
/* 2768 */       for (int m = 0; m < labelImage1.getWidth(); m++) {
/* 2769 */         for (int n = 0; n < labelImage1.getHeight(); n++) {
/* 2770 */           if (l1.getf(m, n) > 0.0F)
/*      */           {
/* 2772 */             if (l1.getf(m, n) == l2.getf(m, n))
/* 2773 */               intersection[((Integer)labelIndices1.get(Integer.valueOf((int)l1.getf(m, n)))).intValue()] = intersection[((Integer)labelIndices1.get(Integer.valueOf((int)l1.getf(m, n)))).intValue()] + 1.0D;  } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2777 */     for (int i = 0; i < intersection.length; i++) {
/*      */       
/* 2779 */       int num2 = (labelIndices2.get(Integer.valueOf(labels1[i])) != null) ? numPix2[((Integer)labelIndices2.get(Integer.valueOf(labels1[i]))).intValue()] : 0;
/* 2780 */       intersection[i] = intersection[i] / ((numPix1[i] + num2) - intersection[i]);
/*      */     } 
/*      */     
/* 2783 */     ResultsTable table = new ResultsTable();
/* 2784 */     for (int j = 0; j < labels1.length; j++) {
/* 2785 */       table.incrementCounter();
/* 2786 */       table.addLabel(Integer.toString(labels1[j]));
/* 2787 */       table.addValue("JaccardIndex", intersection[j]);
/*      */     } 
/* 2789 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getJaccardIndex(ImagePlus labelImage1, ImagePlus labelImage2) {
/* 2803 */     return getJaccardIndex(labelImage1.getImageStack(), labelImage2.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getJaccardIndexPerLabel(ImagePlus labelImage1, ImagePlus labelImage2) {
/* 2817 */     return getJaccardIndexPerLabel(labelImage1.getImageStack(), labelImage2.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getDiceCoefficient(ImageProcessor labelImage1, ImageProcessor labelImage2) {
/* 2830 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2831 */       labelImage1.getHeight() != labelImage2.getHeight())
/* 2832 */       return -1.0D; 
/* 2833 */     double intersection = 0.0D;
/* 2834 */     double numPix1 = 0.0D;
/* 2835 */     double numPix2 = 0.0D;
/*      */     
/* 2837 */     for (int i = 0; i < labelImage1.getWidth(); i++) {
/* 2838 */       for (int j = 0; j < labelImage1.getHeight(); j++) {
/*      */         
/* 2840 */         if (labelImage1.getf(i, j) > 0.0F) {
/*      */           
/* 2842 */           numPix1++;
/* 2843 */           if (labelImage1.getf(i, j) == labelImage2.getf(i, j))
/* 2844 */             intersection++; 
/*      */         } 
/* 2846 */         if (labelImage2.getf(i, j) > 0.0F)
/* 2847 */           numPix2++; 
/*      */       } 
/*      */     } 
/* 2850 */     return 2.0D * intersection / (numPix1 + numPix2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getDiceCoefficientPerLabel(ImageProcessor labelImage1, ImageProcessor labelImage2) {
/* 2864 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2865 */       labelImage1.getHeight() != labelImage2.getHeight()) {
/* 2866 */       return null;
/*      */     }
/* 2868 */     int[] labels1 = findAllLabels(labelImage1);
/* 2869 */     int[] numPix1 = pixelCount(labelImage1, labels1);
/* 2870 */     double[] intersection = new double[labels1.length];
/*      */     
/* 2872 */     HashMap<Integer, Integer> labelIndices1 = mapLabelIndices(labels1);
/*      */     
/* 2874 */     int[] labels2 = findAllLabels(labelImage2);
/* 2875 */     int[] numPix2 = pixelCount(labelImage2, labels2);
/*      */ 
/*      */     
/* 2878 */     HashMap<Integer, Integer> labelIndices2 = mapLabelIndices(labels2);
/*      */     
/*      */     int i;
/* 2881 */     for (i = 0; i < labelImage1.getWidth(); i++) {
/* 2882 */       for (int k = 0; k < labelImage1.getHeight(); k++) {
/* 2883 */         if (labelImage1.getf(i, k) > 0.0F)
/*      */         {
/* 2885 */           if (labelImage1.getf(i, k) == labelImage2.getf(i, k))
/* 2886 */             intersection[((Integer)labelIndices1.get(Integer.valueOf((int)labelImage1.getf(i, k)))).intValue()] = intersection[((Integer)labelIndices1.get(Integer.valueOf((int)labelImage1.getf(i, k)))).intValue()] + 1.0D;  } 
/*      */       } 
/*      */     } 
/* 2889 */     for (i = 0; i < intersection.length; i++) {
/*      */       
/* 2891 */       int num2 = (labelIndices2.get(Integer.valueOf(labels1[i])) != null) ? numPix2[((Integer)labelIndices2.get(Integer.valueOf(labels1[i]))).intValue()] : 0;
/* 2892 */       intersection[i] = 2.0D * intersection[i] / (numPix1[i] + num2);
/*      */     } 
/*      */     
/* 2895 */     ResultsTable table = new ResultsTable();
/* 2896 */     for (int j = 0; j < labels1.length; j++) {
/* 2897 */       table.incrementCounter();
/* 2898 */       table.addLabel(Integer.toString(labels1[j]));
/* 2899 */       table.addValue("DiceCoefficient", intersection[j]);
/*      */     } 
/* 2901 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getDiceCoefficient(ImageStack labelImage1, ImageStack labelImage2) {
/* 2914 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2915 */       labelImage1.getHeight() != labelImage2.getHeight())
/* 2916 */       return -1.0D; 
/* 2917 */     double intersection = 0.0D;
/* 2918 */     double numPix1 = 0.0D;
/* 2919 */     double numPix2 = 0.0D;
/*      */     
/* 2921 */     for (int k = 0; k < labelImage1.getSize(); k++) {
/*      */       
/* 2923 */       ImageProcessor l1 = labelImage1.getProcessor(k + 1);
/* 2924 */       ImageProcessor l2 = labelImage2.getProcessor(k + 1);
/* 2925 */       for (int i = 0; i < labelImage1.getWidth(); i++) {
/* 2926 */         for (int j = 0; j < labelImage1.getHeight(); j++) {
/*      */           
/* 2928 */           if (l1.getf(i, j) > 0.0F) {
/*      */             
/* 2930 */             numPix1++;
/* 2931 */             if (l1.getf(i, j) == l2.getf(i, j))
/* 2932 */               intersection++; 
/*      */           } 
/* 2934 */           if (l2.getf(i, j) > 0.0F)
/* 2935 */             numPix2++; 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2939 */     return 2.0D * intersection / (numPix1 + numPix2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getDiceCoefficientPerLabel(ImageStack labelImage1, ImageStack labelImage2) {
/* 2953 */     if (labelImage1.getWidth() != labelImage2.getWidth() || 
/* 2954 */       labelImage1.getHeight() != labelImage2.getHeight()) {
/* 2955 */       return null;
/*      */     }
/* 2957 */     int[] labels1 = findAllLabels(labelImage1);
/* 2958 */     int[] numPix1 = voxelCount(labelImage1, labels1);
/* 2959 */     double[] intersection = new double[labels1.length];
/*      */     
/* 2961 */     HashMap<Integer, Integer> labelIndices1 = mapLabelIndices(labels1);
/*      */     
/* 2963 */     int[] labels2 = findAllLabels(labelImage2);
/* 2964 */     int[] numPix2 = voxelCount(labelImage2, labels2);
/*      */ 
/*      */     
/* 2967 */     HashMap<Integer, Integer> labelIndices2 = mapLabelIndices(labels2);
/*      */ 
/*      */     
/* 2970 */     for (int k = 0; k < labelImage1.getSize(); k++) {
/*      */       
/* 2972 */       ImageProcessor l1 = labelImage1.getProcessor(k + 1);
/* 2973 */       ImageProcessor l2 = labelImage2.getProcessor(k + 1);
/* 2974 */       for (int m = 0; m < labelImage1.getWidth(); m++) {
/* 2975 */         for (int n = 0; n < labelImage1.getHeight(); n++) {
/* 2976 */           if (l1.getf(m, n) > 0.0F)
/*      */           {
/* 2978 */             if (l1.getf(m, n) == l2.getf(m, n))
/* 2979 */               intersection[((Integer)labelIndices1.get(Integer.valueOf((int)l1.getf(m, n)))).intValue()] = intersection[((Integer)labelIndices1.get(Integer.valueOf((int)l1.getf(m, n)))).intValue()] + 1.0D;  } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2983 */     for (int i = 0; i < intersection.length; i++) {
/*      */       
/* 2985 */       int num2 = (labelIndices2.get(Integer.valueOf(labels1[i])) != null) ? numPix2[((Integer)labelIndices2.get(Integer.valueOf(labels1[i]))).intValue()] : 0;
/* 2986 */       intersection[i] = 2.0D * intersection[i] / (numPix1[i] + num2);
/*      */     } 
/*      */     
/* 2989 */     ResultsTable table = new ResultsTable();
/* 2990 */     for (int j = 0; j < labels1.length; j++) {
/* 2991 */       table.incrementCounter();
/* 2992 */       table.addLabel(Integer.toString(labels1[j]));
/* 2993 */       table.addValue("DiceCoefficient", intersection[j]);
/*      */     } 
/* 2995 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getDiceCoefficient(ImagePlus labelImage1, ImagePlus labelImage2) {
/* 3008 */     return getDiceCoefficient(labelImage1.getImageStack(), labelImage2.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getDiceCoefficientPerLabel(ImagePlus labelImage1, ImagePlus labelImage2) {
/* 3022 */     return getDiceCoefficientPerLabel(labelImage1.getImageStack(), labelImage2.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getVolumeSimilarity(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3037 */     double numPixSource = 0.0D;
/* 3038 */     double numPixTarget = 0.0D;
/* 3039 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3040 */     int[] sourcePixPerLabel = pixelCount(sourceImage, sourceLabels);
/*      */     
/* 3042 */     int[] targetLabels = findAllLabels(targetImage);
/* 3043 */     int[] targetPixPerLabel = pixelCount(targetImage, targetLabels);
/*      */     int i;
/* 3045 */     for (i = 0; i < sourceLabels.length; i++)
/* 3046 */       numPixSource += sourcePixPerLabel[i]; 
/* 3047 */     for (i = 0; i < targetLabels.length; i++) {
/* 3048 */       numPixTarget += targetPixPerLabel[i];
/*      */     }
/*      */     
/* 3051 */     return 2.0D * (numPixSource - numPixTarget) / (numPixSource + numPixTarget);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getVolumeSimilarityPerLabel(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3067 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3068 */     int[] numPixSource = pixelCount(sourceImage, sourceLabels);
/* 3069 */     double[] volumeSim = new double[sourceLabels.length];
/*      */     
/* 3071 */     int[] targetLabels = findAllLabels(targetImage);
/* 3072 */     int[] numPixTarget = pixelCount(targetImage, targetLabels);
/*      */ 
/*      */     
/* 3075 */     HashMap<Integer, Integer> targetLabelIndices = mapLabelIndices(targetLabels);
/*      */ 
/*      */     
/* 3078 */     for (int i = 0; i < sourceLabels.length; i++) {
/* 3079 */       volumeSim[i] = (targetLabelIndices.get(Integer.valueOf(sourceLabels[i])) != null) ? (
/* 3080 */         2.0D * (numPixSource[i] - numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()]) / (
/* 3081 */         numPixSource[i] + numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()])) : 
/* 3082 */         0.0D;
/*      */     }
/* 3084 */     ResultsTable table = new ResultsTable();
/* 3085 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 3086 */       table.incrementCounter();
/* 3087 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 3088 */       table.addValue("VolumeSimilarity", volumeSim[j]);
/*      */     } 
/* 3090 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getVolumeSimilarity(ImageStack sourceImage, ImageStack targetImage) {
/* 3105 */     double numPixSource = 0.0D;
/* 3106 */     double numPixTarget = 0.0D;
/* 3107 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3108 */     int[] sourcePixPerLabel = voxelCount(sourceImage, sourceLabels);
/*      */     
/* 3110 */     int[] targetLabels = findAllLabels(targetImage);
/* 3111 */     int[] targetPixPerLabel = voxelCount(targetImage, targetLabels);
/*      */     int i;
/* 3113 */     for (i = 0; i < sourceLabels.length; i++)
/* 3114 */       numPixSource += sourcePixPerLabel[i]; 
/* 3115 */     for (i = 0; i < targetLabels.length; i++) {
/* 3116 */       numPixTarget += targetPixPerLabel[i];
/*      */     }
/*      */     
/* 3119 */     return 2.0D * (numPixSource - numPixTarget) / (numPixSource + numPixTarget);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getVolumeSimilarityPerLabel(ImageStack sourceImage, ImageStack targetImage) {
/* 3135 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3136 */     int[] numPixSource = voxelCount(sourceImage, sourceLabels);
/* 3137 */     double[] volumeSim = new double[sourceLabels.length];
/*      */     
/* 3139 */     int[] targetLabels = findAllLabels(targetImage);
/* 3140 */     int[] numPixTarget = voxelCount(targetImage, targetLabels);
/*      */ 
/*      */     
/* 3143 */     HashMap<Integer, Integer> targetLabelIndices = mapLabelIndices(targetLabels);
/*      */ 
/*      */     
/* 3146 */     for (int i = 0; i < sourceLabels.length; i++) {
/* 3147 */       volumeSim[i] = (targetLabelIndices.get(Integer.valueOf(sourceLabels[i])) != null) ? (
/* 3148 */         2.0D * (numPixSource[i] - numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()]) / (
/* 3149 */         numPixSource[i] + numPixTarget[((Integer)targetLabelIndices.get(Integer.valueOf(sourceLabels[i]))).intValue()])) : 
/* 3150 */         0.0D;
/*      */     }
/* 3152 */     ResultsTable table = new ResultsTable();
/* 3153 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 3154 */       table.incrementCounter();
/* 3155 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 3156 */       table.addValue("VolumeSimilarity", volumeSim[j]);
/*      */     } 
/* 3158 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getVolumeSimilarity(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3173 */     return getVolumeSimilarity(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getVolumeSimilarityPerLabel(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3189 */     return getVolumeSimilarityPerLabel(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalseNegativeError(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3204 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3205 */       sourceImage.getHeight() != targetImage.getHeight())
/* 3206 */       return -1.0D; 
/* 3207 */     return 1.0D - getTotalOverlap(sourceImage, targetImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalseNegativeErrorPerLabel(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3223 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3224 */       sourceImage.getHeight() != targetImage.getHeight()) {
/* 3225 */       return null;
/*      */     }
/* 3227 */     ResultsTable toTable = getTargetOverlapPerLabel(sourceImage, targetImage);
/*      */     
/* 3229 */     ResultsTable fneTable = new ResultsTable();
/* 3230 */     for (int i = 0; i < toTable.getCounter(); i++) {
/* 3231 */       fneTable.incrementCounter();
/* 3232 */       fneTable.addLabel(toTable.getLabel(i));
/* 3233 */       fneTable.addValue("FalseNegativeError", 1.0D - toTable.getValue("TargetOverlap", i));
/*      */     } 
/* 3235 */     return fneTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalseNegativeError(ImageStack sourceImage, ImageStack targetImage) {
/* 3250 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3251 */       sourceImage.getHeight() != targetImage.getHeight() || 
/* 3252 */       sourceImage.getSize() != targetImage.getSize())
/* 3253 */       return -1.0D; 
/* 3254 */     return 1.0D - getTotalOverlap(sourceImage, targetImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalseNegativeErrorPerLabel(ImageStack sourceImage, ImageStack targetImage) {
/* 3270 */     ResultsTable toTable = getTargetOverlapPerLabel(sourceImage, targetImage);
/*      */     
/* 3272 */     ResultsTable fneTable = new ResultsTable();
/* 3273 */     for (int i = 0; i < toTable.getCounter(); i++) {
/* 3274 */       fneTable.incrementCounter();
/* 3275 */       fneTable.addLabel(toTable.getLabel(i));
/* 3276 */       fneTable.addValue("FalseNegativeError", 1.0D - toTable.getValue("TargetOverlap", i));
/*      */     } 
/* 3278 */     return fneTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalseNegativeError(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3294 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3295 */       sourceImage.getHeight() != targetImage.getHeight() || 
/* 3296 */       sourceImage.getNSlices() != targetImage.getNSlices())
/* 3297 */       return -1.0D; 
/* 3298 */     return 1.0D - getTotalOverlap(sourceImage, targetImage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalseNegativeErrorPerLabel(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3314 */     return getFalseNegativeErrorPerLabel(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalsePositiveError(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3329 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3330 */       sourceImage.getHeight() != targetImage.getHeight())
/* 3331 */       return -1.0D; 
/* 3332 */     double setDiff = 0.0D;
/* 3333 */     double numPixSource = 0.0D;
/*      */     
/* 3335 */     for (int i = 0; i < sourceImage.getWidth(); i++) {
/* 3336 */       for (int j = 0; j < sourceImage.getHeight(); j++) {
/*      */         
/* 3338 */         if (sourceImage.getf(i, j) > 0.0F) {
/*      */           
/* 3340 */           numPixSource++;
/* 3341 */           if (sourceImage.getf(i, j) != targetImage.getf(i, j))
/* 3342 */             setDiff++; 
/*      */         } 
/*      */       } 
/*      */     } 
/* 3346 */     return setDiff / numPixSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalsePositiveErrorPerLabel(ImageProcessor sourceImage, ImageProcessor targetImage) {
/* 3362 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3363 */       sourceImage.getHeight() != targetImage.getHeight()) {
/* 3364 */       return null;
/*      */     }
/* 3366 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3367 */     double[] setDiff = new double[sourceLabels.length];
/*      */     
/* 3369 */     HashMap<Integer, Integer> sourceLabelIndices = mapLabelIndices(sourceLabels);
/* 3370 */     int[] numPixSource = pixelCount(sourceImage, sourceLabels);
/*      */     
/*      */     int i;
/* 3373 */     for (i = 0; i < sourceImage.getWidth(); i++) {
/* 3374 */       for (int k = 0; k < sourceImage.getHeight(); k++) {
/* 3375 */         if (sourceImage.getf(i, k) > 0.0F)
/*      */         {
/* 3377 */           if (sourceImage.getf(i, k) != targetImage.getf(i, k))
/* 3378 */             setDiff[((Integer)sourceLabelIndices.get(Integer.valueOf((int)sourceImage.getf(i, k)))).intValue()] = setDiff[((Integer)sourceLabelIndices.get(Integer.valueOf((int)sourceImage.getf(i, k)))).intValue()] + 1.0D;  } 
/*      */       } 
/*      */     } 
/* 3381 */     for (i = 0; i < setDiff.length; i++) {
/* 3382 */       setDiff[i] = setDiff[i] / numPixSource[i];
/*      */     }
/*      */     
/* 3385 */     ResultsTable table = new ResultsTable();
/* 3386 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 3387 */       table.incrementCounter();
/* 3388 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 3389 */       table.addValue("FalsePositiveError", setDiff[j]);
/*      */     } 
/* 3391 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalsePositiveError(ImageStack sourceImage, ImageStack targetImage) {
/* 3406 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3407 */       sourceImage.getHeight() != targetImage.getHeight() || 
/* 3408 */       sourceImage.getSize() != targetImage.getSize())
/* 3409 */       return -1.0D; 
/* 3410 */     double setDiff = 0.0D;
/* 3411 */     double numPixSource = 0.0D;
/*      */     
/* 3413 */     for (int k = 0; k < sourceImage.getSize(); k++) {
/*      */       
/* 3415 */       ImageProcessor ls = sourceImage.getProcessor(k + 1);
/* 3416 */       ImageProcessor lt = targetImage.getProcessor(k + 1);
/* 3417 */       for (int i = 0; i < sourceImage.getWidth(); i++) {
/* 3418 */         for (int j = 0; j < sourceImage.getHeight(); j++) {
/*      */           
/* 3420 */           if (ls.getf(i, j) > 0.0F) {
/*      */             
/* 3422 */             numPixSource++;
/* 3423 */             if (ls.getf(i, j) != lt.getf(i, j))
/* 3424 */               setDiff++; 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 3429 */     return setDiff / numPixSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalsePositiveErrorPerLabel(ImageStack sourceImage, ImageStack targetImage) {
/* 3445 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3446 */       sourceImage.getHeight() != targetImage.getHeight() || 
/* 3447 */       sourceImage.getSize() != targetImage.getSize())
/* 3448 */       return null; 
/* 3449 */     int[] sourceLabels = findAllLabels(sourceImage);
/* 3450 */     double[] setDiff = new double[sourceLabels.length];
/*      */     
/* 3452 */     HashMap<Integer, Integer> sourceLabelIndices = mapLabelIndices(sourceLabels);
/* 3453 */     int[] numPixSource = voxelCount(sourceImage, sourceLabels);
/*      */ 
/*      */     
/* 3456 */     for (int k = 0; k < sourceImage.getSize(); k++) {
/*      */       
/* 3458 */       ImageProcessor ls = sourceImage.getProcessor(k + 1);
/* 3459 */       ImageProcessor lt = targetImage.getProcessor(k + 1);
/* 3460 */       for (int m = 0; m < sourceImage.getWidth(); m++) {
/* 3461 */         for (int n = 0; n < sourceImage.getHeight(); n++) {
/* 3462 */           if (ls.getf(m, n) > 0.0F)
/*      */           {
/* 3464 */             if (ls.getf(m, n) != lt.getf(m, n))
/* 3465 */               setDiff[((Integer)sourceLabelIndices.get(Integer.valueOf((int)ls.getf(m, n)))).intValue()] = setDiff[((Integer)sourceLabelIndices.get(Integer.valueOf((int)ls.getf(m, n)))).intValue()] + 1.0D; 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 3470 */     for (int i = 0; i < setDiff.length; i++) {
/* 3471 */       setDiff[i] = setDiff[i] / numPixSource[i];
/*      */     }
/*      */     
/* 3474 */     ResultsTable table = new ResultsTable();
/* 3475 */     for (int j = 0; j < sourceLabels.length; j++) {
/* 3476 */       table.incrementCounter();
/* 3477 */       table.addLabel(Integer.toString(sourceLabels[j]));
/* 3478 */       table.addValue("FalsePositiveError", setDiff[j]);
/*      */     } 
/* 3480 */     return table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final double getFalsePositiveError(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3495 */     if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 3496 */       sourceImage.getHeight() != targetImage.getHeight() || 
/* 3497 */       sourceImage.getNSlices() != targetImage.getNSlices())
/* 3498 */       return -1.0D; 
/* 3499 */     return getFalsePositiveError(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final ResultsTable getFalsePositiveErrorPerLabel(ImagePlus sourceImage, ImagePlus targetImage) {
/* 3515 */     return getFalsePositiveErrorPerLabel(sourceImage.getImageStack(), targetImage.getImageStack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static final Point[] findPositionOfMaxValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 3536 */     return LabelValues.findPositionOfMaxValues(valueImage, labelImage, labels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static final Point[] findPositionOfMinValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 3558 */     return LabelValues.findPositionOfMinValues(valueImage, labelImage, labels);
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/LabelImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */