/*     */ package inra.ijpb.label;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import java.awt.Point;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelValues
/*     */ {
/*     */   public static final double maxValueWithinLabels(ImageProcessor valueImage, ImageProcessor labelImage) {
/*  40 */     int sizeX = valueImage.getWidth();
/*  41 */     int sizeY = valueImage.getHeight();
/*     */ 
/*     */     
/*  44 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY)
/*     */     {
/*  46 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/*  50 */     double maxValue = Double.NEGATIVE_INFINITY;
/*  51 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/*  53 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/*  56 */         if (labelImage.getf(x, y) > 0.0F)
/*     */         {
/*  58 */           maxValue = Math.max(maxValue, valueImage.getf(x, y));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  63 */     return maxValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double maxValueWithinLabels(ImageStack valueImage, ImageStack labelImage) {
/*  81 */     int sizeX = valueImage.getWidth();
/*  82 */     int sizeY = valueImage.getHeight();
/*  83 */     int sizeZ = valueImage.getSize();
/*     */ 
/*     */     
/*  86 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/*  88 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/*  92 */     double maxValue = Double.NEGATIVE_INFINITY;
/*  93 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/*  95 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/*  97 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 100 */           if (labelImage.getVoxel(x, y, z) > 0.0D)
/*     */           {
/* 102 */             maxValue = Math.max(maxValue, valueImage.getVoxel(x, y, z));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 107 */     return maxValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] maxValues(ImageProcessor image, ImageProcessor labelImage, int[] labels) {
/* 128 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 131 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 134 */     double[] maxValues = new double[nLabels];
/* 135 */     for (int i = 0; i < nLabels; i++) {
/* 136 */       maxValues[i] = Double.NEGATIVE_INFINITY;
/*     */     }
/*     */     
/* 139 */     int sizeX = labelImage.getWidth();
/* 140 */     int sizeY = labelImage.getHeight();
/* 141 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 143 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 145 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 148 */         if (label != 0)
/*     */         {
/*     */           
/* 151 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */             
/* 153 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */             
/* 156 */             double value = image.getf(x, y);
/* 157 */             if (value > maxValues[index])
/* 158 */               maxValues[index] = value; 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 163 */     return maxValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] maxValues(ImageStack image, ImageStack labelImage, int[] labels) {
/* 182 */     int sizeX = labelImage.getWidth();
/* 183 */     int sizeY = labelImage.getHeight();
/* 184 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 187 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/* 189 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/* 193 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 196 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 199 */     double[] maxValues = new double[nLabels];
/* 200 */     for (int i = 0; i < nLabels; i++) {
/* 201 */       maxValues[i] = Double.NEGATIVE_INFINITY;
/*     */     }
/*     */     
/* 204 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 206 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 208 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 210 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 213 */           if (label != 0)
/*     */           {
/*     */             
/* 216 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */               
/* 218 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */               
/* 221 */               double value = image.getVoxel(x, y, z);
/* 222 */               if (value > maxValues[index])
/* 223 */                 maxValues[index] = value; 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 229 */     return maxValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final PositionValuePair[] findMaxValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 249 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 252 */     int nLabels = labels.length;
/* 253 */     PositionValuePair[] pairs = new PositionValuePair[nLabels];
/* 254 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 256 */       pairs[i] = new PositionValuePair(new Point(-1, -1), Double.NEGATIVE_INFINITY);
/*     */     }
/*     */ 
/*     */     
/* 260 */     int sizeX = labelImage.getWidth();
/* 261 */     int sizeY = labelImage.getHeight();
/* 262 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 264 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 266 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 269 */         if (label != 0)
/*     */         {
/* 271 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */             
/* 275 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 276 */             PositionValuePair pair = pairs[index];
/*     */ 
/*     */             
/* 279 */             double value = valueImage.getf(x, y);
/* 280 */             if (value > pair.value) {
/*     */               
/* 282 */               pair.position.setLocation(x, y);
/* 283 */               pair.value = value;
/*     */             } 
/*     */           }  } 
/*     */       } 
/*     */     } 
/* 288 */     return pairs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Position3DValuePair[] findMaxValues(ImageStack valueImage, ImageStack labelImage, int[] labels) {
/* 308 */     int sizeX = labelImage.getWidth();
/* 309 */     int sizeY = labelImage.getHeight();
/* 310 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 313 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/* 315 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/* 319 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 322 */     int nLabels = labels.length;
/* 323 */     Position3DValuePair[] pairs = new Position3DValuePair[nLabels];
/* 324 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 326 */       pairs[i] = new Position3DValuePair(new Cursor3D(-1, -1, -1), Double.NEGATIVE_INFINITY);
/*     */     }
/*     */ 
/*     */     
/* 330 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 332 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 334 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 336 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 339 */           if (label != 0)
/*     */           {
/* 341 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */               
/* 345 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 346 */               Position3DValuePair pair = pairs[index];
/*     */ 
/*     */               
/* 349 */               double value = valueImage.getVoxel(x, y, z);
/* 350 */               if (value > pair.value) {
/*     */                 
/* 352 */                 pair.position = new Cursor3D(x, y, z);
/* 353 */                 pair.value = value;
/*     */               } 
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 359 */     return pairs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final PositionValuePair[] findMinValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 379 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 382 */     int nLabels = labels.length;
/* 383 */     PositionValuePair[] pairs = new PositionValuePair[nLabels];
/* 384 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 386 */       pairs[i] = new PositionValuePair(new Point(-1, -1), Double.POSITIVE_INFINITY);
/*     */     }
/*     */ 
/*     */     
/* 390 */     int sizeX = labelImage.getWidth();
/* 391 */     int sizeY = labelImage.getHeight();
/* 392 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 394 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 396 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 399 */         if (label != 0)
/*     */         {
/* 401 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */             
/* 405 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 406 */             PositionValuePair pair = pairs[index];
/*     */ 
/*     */             
/* 409 */             double value = valueImage.getf(x, y);
/* 410 */             if (value < pair.value) {
/*     */               
/* 412 */               pair.position.setLocation(x, y);
/* 413 */               pair.value = value;
/*     */             } 
/*     */           }  } 
/*     */       } 
/*     */     } 
/* 418 */     return pairs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Position3DValuePair[] findMinValues(ImageStack valueImage, ImageStack labelImage, int[] labels) {
/* 438 */     int sizeX = labelImage.getWidth();
/* 439 */     int sizeY = labelImage.getHeight();
/* 440 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 443 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/* 445 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/* 449 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 452 */     int nLabels = labels.length;
/* 453 */     Position3DValuePair[] pairs = new Position3DValuePair[nLabels];
/* 454 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 456 */       pairs[i] = new Position3DValuePair(new Cursor3D(-1, -1, -1), Double.POSITIVE_INFINITY);
/*     */     }
/*     */ 
/*     */     
/* 460 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 462 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 464 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 466 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 469 */           if (label != 0)
/*     */           {
/* 471 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */               
/* 475 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 476 */               Position3DValuePair pair = pairs[index];
/*     */ 
/*     */               
/* 479 */               double value = valueImage.getVoxel(x, y, z);
/* 480 */               if (value < pair.value) {
/*     */                 
/* 482 */                 pair.position = new Cursor3D(x, y, z);
/* 483 */                 pair.value = value;
/*     */               } 
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 489 */     return pairs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Point[] findPositionOfMaxValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 509 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 512 */     int nLabels = labels.length;
/* 513 */     Point[] posMax = new Point[nLabels];
/* 514 */     float[] maxValues = new float[nLabels];
/* 515 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 517 */       maxValues[i] = Float.NEGATIVE_INFINITY;
/* 518 */       posMax[i] = new Point(-1, -1);
/*     */     } 
/*     */ 
/*     */     
/* 522 */     int width = labelImage.getWidth();
/* 523 */     int height = labelImage.getHeight();
/* 524 */     for (int y = 0; y < height; y++) {
/*     */       
/* 526 */       for (int x = 0; x < width; x++) {
/*     */         
/* 528 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 531 */         if (label != 0) {
/*     */ 
/*     */           
/* 534 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */           
/* 537 */           float value = valueImage.getf(x, y);
/* 538 */           if (value > maxValues[index]) {
/*     */             
/* 540 */             posMax[index].setLocation(x, y);
/* 541 */             maxValues[index] = value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 546 */     return posMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Cursor3D[] findPositionOfMaxValues(ImageStack valueImage, ImageStack labelImage, int[] labels) {
/* 566 */     int sizeX = labelImage.getWidth();
/* 567 */     int sizeY = labelImage.getHeight();
/* 568 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 571 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/* 573 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/* 577 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 580 */     int nLabels = labels.length;
/* 581 */     Cursor3D[] posMax = new Cursor3D[nLabels];
/* 582 */     double[] maxValues = new double[nLabels];
/* 583 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 585 */       maxValues[i] = Double.NEGATIVE_INFINITY;
/* 586 */       posMax[i] = new Cursor3D(-1, -1, -1);
/*     */     } 
/*     */ 
/*     */     
/* 590 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 592 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 594 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 596 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 599 */           if (label != 0) {
/*     */ 
/*     */             
/* 602 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */             
/* 605 */             double value = valueImage.getVoxel(x, y, z);
/* 606 */             if (value > maxValues[index]) {
/*     */               
/* 608 */               posMax[index] = new Cursor3D(x, y, z);
/* 609 */               maxValues[index] = value;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 615 */     return posMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Point[] findPositionOfMinValues(ImageProcessor valueImage, ImageProcessor labelImage, int[] labels) {
/* 635 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 638 */     int nLabels = labels.length;
/* 639 */     Point[] posMax = new Point[nLabels];
/* 640 */     float[] maxValues = new float[nLabels];
/* 641 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 643 */       maxValues[i] = Float.POSITIVE_INFINITY;
/* 644 */       posMax[i] = new Point(-1, -1);
/*     */     } 
/*     */ 
/*     */     
/* 648 */     int width = labelImage.getWidth();
/* 649 */     int height = labelImage.getHeight();
/* 650 */     for (int y = 0; y < height; y++) {
/*     */       
/* 652 */       for (int x = 0; x < width; x++) {
/*     */         
/* 654 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 657 */         if (label != 0) {
/*     */ 
/*     */           
/* 660 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */           
/* 663 */           float value = valueImage.getf(x, y);
/* 664 */           if (value < maxValues[index]) {
/*     */             
/* 666 */             posMax[index].setLocation(x, y);
/* 667 */             maxValues[index] = value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 672 */     return posMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Cursor3D[] findPositionOfMinValues(ImageStack valueImage, ImageStack labelImage, int[] labels) {
/* 692 */     int sizeX = labelImage.getWidth();
/* 693 */     int sizeY = labelImage.getHeight();
/* 694 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 697 */     if (labelImage.getWidth() != sizeX || labelImage.getHeight() != sizeY || labelImage.getSize() != sizeZ)
/*     */     {
/* 699 */       throw new IllegalArgumentException("Both images must have same dimensions");
/*     */     }
/*     */ 
/*     */     
/* 703 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 706 */     int nLabels = labels.length;
/* 707 */     Cursor3D[] posMax = new Cursor3D[nLabels];
/* 708 */     double[] maxValues = new double[nLabels];
/* 709 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 711 */       maxValues[i] = Double.POSITIVE_INFINITY;
/* 712 */       posMax[i] = new Cursor3D(-1, -1, -1);
/*     */     } 
/*     */ 
/*     */     
/* 716 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 718 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 720 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 722 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 725 */           if (label != 0) {
/*     */ 
/*     */             
/* 728 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */             
/* 731 */             double value = valueImage.getVoxel(x, y, z);
/* 732 */             if (value < maxValues[index]) {
/*     */               
/* 734 */               posMax[index] = new Cursor3D(x, y, z);
/* 735 */               maxValues[index] = value;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 741 */     return posMax;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class PositionValuePair
/*     */   {
/*     */     Point position;
/*     */     double value;
/*     */     
/*     */     public PositionValuePair(Point position, double value) {
/* 751 */       this.position = position;
/* 752 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Point getPosition() {
/* 757 */       return this.position;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getValue() {
/* 762 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Position3DValuePair
/*     */   {
/*     */     Cursor3D position;
/*     */     double value;
/*     */     
/*     */     public Position3DValuePair(Cursor3D position, double value) {
/* 773 */       this.position = position;
/* 774 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Cursor3D getPosition() {
/* 779 */       return this.position;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getValue() {
/* 784 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/LabelValues.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */