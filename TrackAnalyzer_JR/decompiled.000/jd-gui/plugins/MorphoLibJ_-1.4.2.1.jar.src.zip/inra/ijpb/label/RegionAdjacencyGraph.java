/*     */ package inra.ijpb.label;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionAdjacencyGraph
/*     */ {
/*     */   public static final Set<LabelPair> computeAdjacencies(ImagePlus image) {
/*  88 */     if (image.getStackSize() == 1) {
/*  89 */       return computeAdjacencies(image.getProcessor());
/*     */     }
/*  91 */     return computeAdjacencies(image.getStack());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Set<LabelPair> computeAdjacencies(ImageProcessor image) {
/* 103 */     int width = image.getWidth();
/* 104 */     int height = image.getHeight();
/*     */     
/* 106 */     TreeSet<LabelPair> list = new TreeSet<LabelPair>();
/*     */     
/*     */     int y;
/* 109 */     for (y = 0; y < height; y++) {
/*     */       
/* 111 */       for (int x = 0; x < width - 2; x++) {
/*     */         
/* 113 */         int label = (int)image.getf(x, y);
/* 114 */         if (label != 0) {
/*     */           
/* 116 */           int label2 = (int)image.getf(x + 2, y);
/* 117 */           if (label2 != 0 && label2 != label) {
/*     */ 
/*     */             
/* 120 */             LabelPair pair = new LabelPair(label, label2);
/* 121 */             list.add(pair);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 126 */     for (y = 0; y < height - 2; y++) {
/*     */       
/* 128 */       for (int x = 0; x < width; x++) {
/*     */         
/* 130 */         int label = (int)image.getf(x, y);
/* 131 */         if (label != 0) {
/*     */           
/* 133 */           int label2 = (int)image.getf(x, y + 2);
/* 134 */           if (label2 != 0 && label2 != label) {
/*     */ 
/*     */             
/* 137 */             LabelPair pair = new LabelPair(label, label2);
/* 138 */             list.add(pair);
/*     */           } 
/*     */         } 
/*     */       } 
/* 142 */     }  return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Set<LabelPair> computeAdjacencies(ImageStack image) {
/* 154 */     int width = image.getWidth();
/* 155 */     int height = image.getHeight();
/* 156 */     int depth = image.getSize();
/*     */     
/* 158 */     TreeSet<LabelPair> list = new TreeSet<LabelPair>();
/*     */     
/*     */     int z;
/* 161 */     for (z = 0; z < depth; z++) {
/*     */       
/* 163 */       for (int y = 0; y < height; y++) {
/*     */         
/* 165 */         for (int x = 0; x < width - 2; x++) {
/*     */           
/* 167 */           int label = (int)image.getVoxel(x, y, z);
/* 168 */           if (label != 0) {
/*     */             
/* 170 */             int label2 = (int)image.getVoxel(x + 2, y, z);
/* 171 */             if (label2 != 0 && label2 != label) {
/*     */ 
/*     */               
/* 174 */               LabelPair pair = new LabelPair(label, label2);
/* 175 */               list.add(pair);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 181 */     for (z = 0; z < depth; z++) {
/*     */       
/* 183 */       for (int y = 0; y < height - 2; y++) {
/*     */         
/* 185 */         for (int x = 0; x < width; x++) {
/*     */           
/* 187 */           int label = (int)image.getVoxel(x, y, z);
/* 188 */           if (label != 0) {
/*     */             
/* 190 */             int label2 = (int)image.getVoxel(x, y + 2, z);
/* 191 */             if (label2 != 0 && label2 != label) {
/*     */ 
/*     */               
/* 194 */               LabelPair pair = new LabelPair(label, label2);
/* 195 */               list.add(pair);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 201 */     for (z = 0; z < depth - 2; z++) {
/*     */       
/* 203 */       for (int y = 0; y < height; y++) {
/*     */         
/* 205 */         for (int x = 0; x < width; x++) {
/*     */           
/* 207 */           int label = (int)image.getVoxel(x, y, z);
/* 208 */           if (label != 0) {
/*     */             
/* 210 */             int label2 = (int)image.getVoxel(x, y, z + 2);
/* 211 */             if (label2 != 0 && label2 != label) {
/*     */ 
/*     */               
/* 214 */               LabelPair pair = new LabelPair(label, label2);
/* 215 */               list.add(pair);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 220 */     }  return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class LabelPair
/*     */     implements Comparable<LabelPair>
/*     */   {
/*     */     public int label1;
/*     */ 
/*     */     
/*     */     public int label2;
/*     */ 
/*     */ 
/*     */     
/*     */     public LabelPair(int label1, int label2) {
/* 236 */       if (label1 < label2) {
/*     */         
/* 238 */         this.label1 = label1;
/* 239 */         this.label2 = label2;
/*     */       }
/*     */       else {
/*     */         
/* 243 */         this.label1 = label2;
/* 244 */         this.label2 = label1;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(LabelPair pair) {
/* 251 */       if (this.label1 < pair.label1)
/* 252 */         return -1; 
/* 253 */       if (this.label1 > pair.label1)
/* 254 */         return 1; 
/* 255 */       if (this.label2 < pair.label2)
/* 256 */         return -1; 
/* 257 */       if (this.label2 > pair.label2)
/* 258 */         return 1; 
/* 259 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/RegionAdjacencyGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */