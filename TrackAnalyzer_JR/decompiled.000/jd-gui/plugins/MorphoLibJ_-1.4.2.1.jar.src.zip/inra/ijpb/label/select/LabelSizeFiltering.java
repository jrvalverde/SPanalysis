/*     */ package inra.ijpb.label.select;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelSizeFiltering
/*     */   extends AlgoStub
/*     */ {
/*     */   RelationalOperator operator;
/*     */   int sizeLimit;
/*     */   
/*     */   public LabelSizeFiltering(RelationalOperator operator, int sizeLimit) {
/*  32 */     this.operator = operator;
/*  33 */     this.sizeLimit = sizeLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus imagePlus) {
/*  39 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-sizeFilt";
/*  40 */     ImagePlus resultPlus = null;
/*     */     
/*  42 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  44 */       ImageProcessor result = process(imagePlus.getProcessor());
/*  45 */       resultPlus = new ImagePlus(newName, result);
/*     */     }
/*     */     else {
/*     */       
/*  49 */       ImageStack result = process(imagePlus.getStack());
/*  50 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */     
/*  53 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor labelImage) {
/*  59 */     int[] labels = LabelImages.findAllLabels(labelImage);
/*  60 */     int[] areas = LabelImages.pixelCount(labelImage, labels);
/*     */ 
/*     */     
/*  63 */     ArrayList<Integer> labelsToKeep = new ArrayList<Integer>(labels.length);
/*  64 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/*  66 */       if (this.operator.evaluate(areas[i], this.sizeLimit))
/*     */       {
/*  68 */         labelsToKeep.add(Integer.valueOf(labels[i]));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  73 */     int[] labels2 = new int[labelsToKeep.size()];
/*  74 */     for (int j = 0; j < labelsToKeep.size(); j++)
/*     */     {
/*  76 */       labels2[j] = ((Integer)labelsToKeep.get(j)).intValue();
/*     */     }
/*     */ 
/*     */     
/*  80 */     ImageProcessor result = LabelImages.keepLabels(labelImage, labels2);
/*     */     
/*  82 */     if (!(result instanceof ij.process.ColorProcessor))
/*  83 */       result.setLut(labelImage.getLut()); 
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack process(ImageStack labelImage) {
/*  90 */     int[] labels = LabelImages.findAllLabels(labelImage);
/*  91 */     int[] areas = LabelImages.voxelCount(labelImage, labels);
/*     */ 
/*     */     
/*  94 */     ArrayList<Integer> labelsToKeep = new ArrayList<Integer>(labels.length);
/*  95 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/*  97 */       if (this.operator.evaluate(areas[i], this.sizeLimit))
/*     */       {
/*  99 */         labelsToKeep.add(Integer.valueOf(labels[i]));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 104 */     int[] labels2 = new int[labelsToKeep.size()];
/* 105 */     for (int j = 0; j < labelsToKeep.size(); j++)
/*     */     {
/* 107 */       labels2[j] = ((Integer)labelsToKeep.get(j)).intValue();
/*     */     }
/*     */ 
/*     */     
/* 111 */     ImageStack result = LabelImages.keepLabels(labelImage, labels2);
/*     */     
/* 113 */     result.setColorModel(labelImage.getColorModel());
/* 114 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/select/LabelSizeFiltering.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */