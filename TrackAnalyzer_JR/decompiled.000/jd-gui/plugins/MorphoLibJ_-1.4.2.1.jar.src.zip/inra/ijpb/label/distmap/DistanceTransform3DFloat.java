/*     */ package inra.ijpb.label.distmap;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.data.image.Image3D;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransform3DFloat
/*     */   extends AlgoStub
/*     */   implements DistanceTransform3D
/*     */ {
/*     */   private float[] weights;
/*     */   private boolean normalizeMap = true;
/*     */   private int sizeX;
/*     */   private int sizeY;
/*     */   private int sizeZ;
/*     */   private Image3D labels;
/*     */   private Image3D distmap;
/*     */   
/*     */   public DistanceTransform3DFloat(ChamferWeights3D weights) {
/*  80 */     this(weights.getFloatWeights());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(float[] weights) {
/*  89 */     this.weights = weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(ChamferWeights3D weights, boolean normalize) {
/* 102 */     this(weights.getFloatWeights(), normalize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DistanceTransform3DFloat(float[] weights, boolean normalize) {
/* 115 */     this.weights = weights;
/* 116 */     this.normalizeMap = normalize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageStack distanceMap(ImageStack image) {
/* 137 */     this.sizeX = image.getWidth();
/* 138 */     this.sizeY = image.getHeight();
/* 139 */     this.sizeZ = image.getSize();
/*     */ 
/*     */     
/* 142 */     this.labels = Images3D.createWrapper(image);
/*     */ 
/*     */     
/* 145 */     ImageStack resultStack = ImageStack.create(this.sizeX, this.sizeY, this.sizeZ, 32);
/* 146 */     this.distmap = Images3D.createWrapper(resultStack);
/*     */ 
/*     */     
/* 149 */     initializeResultSlices();
/*     */ 
/*     */     
/* 152 */     forwardScan();
/* 153 */     backwardScan();
/*     */ 
/*     */     
/* 156 */     if (this.normalizeMap)
/*     */     {
/* 158 */       normalizeResultSlices();
/*     */     }
/*     */     
/* 161 */     fireStatusChanged(this, "");
/* 162 */     return resultStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeResultSlices() {
/* 175 */     fireStatusChanged(this, "Initialization...");
/*     */ 
/*     */     
/* 178 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 180 */       fireProgressChanged(this, z, this.sizeZ);
/*     */       
/* 182 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 184 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 186 */           int val = this.labels.get(x, y, z);
/* 187 */           this.distmap.setValue(x, y, z, ((val == 0) ? 0.0F : Float.MAX_VALUE));
/*     */         } 
/*     */       } 
/*     */     } 
/* 191 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void forwardScan() {
/* 196 */     fireStatusChanged(this, "Forward scan...");
/*     */ 
/*     */     
/* 199 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 202 */     offsets.add(new WeightedOffset(-1, -1, -1, this.weights[2]));
/* 203 */     offsets.add(new WeightedOffset(0, -1, -1, this.weights[1]));
/* 204 */     offsets.add(new WeightedOffset(1, -1, -1, this.weights[2]));
/* 205 */     offsets.add(new WeightedOffset(-1, 0, -1, this.weights[1]));
/* 206 */     offsets.add(new WeightedOffset(0, 0, -1, this.weights[0]));
/* 207 */     offsets.add(new WeightedOffset(1, 0, -1, this.weights[1]));
/* 208 */     offsets.add(new WeightedOffset(-1, 1, -1, this.weights[2]));
/* 209 */     offsets.add(new WeightedOffset(0, 1, -1, this.weights[1]));
/* 210 */     offsets.add(new WeightedOffset(1, 1, -1, this.weights[2]));
/*     */ 
/*     */     
/* 213 */     offsets.add(new WeightedOffset(-1, -1, 0, this.weights[1]));
/* 214 */     offsets.add(new WeightedOffset(0, -1, 0, this.weights[0]));
/* 215 */     offsets.add(new WeightedOffset(1, -1, 0, this.weights[1]));
/* 216 */     offsets.add(new WeightedOffset(-1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 219 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 221 */       fireProgressChanged(this, z, this.sizeZ);
/* 222 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 224 */         for (int x = 0; x < this.sizeX; x++) {
/*     */ 
/*     */           
/* 227 */           int label = this.labels.get(x, y, z);
/*     */ 
/*     */           
/* 230 */           if (label != 0) {
/*     */ 
/*     */ 
/*     */             
/* 234 */             double currentDist = this.distmap.getValue(x, y, z);
/* 235 */             double newDist = currentDist;
/*     */ 
/*     */             
/* 238 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 240 */               int x2 = x + offset.dx;
/* 241 */               int y2 = y + offset.dy;
/* 242 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 245 */               if (x2 < 0 || x2 >= this.sizeX)
/*     */                 continue; 
/* 247 */               if (y2 < 0 || y2 >= this.sizeY)
/*     */                 continue; 
/* 249 */               if (z2 < 0 || z2 >= this.sizeZ) {
/*     */                 continue;
/*     */               }
/* 252 */               if (this.labels.get(x2, y2, z2) != label) {
/*     */ 
/*     */                 
/* 255 */                 newDist = offset.weight;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 260 */               newDist = Math.min(newDist, this.distmap.getValue(x2, y2, z2) + offset.weight);
/*     */             } 
/*     */ 
/*     */             
/* 264 */             if (newDist < currentDist)
/*     */             {
/* 266 */               this.distmap.setValue(x, y, z, newDist); } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 271 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void backwardScan() {
/* 276 */     fireStatusChanged(this, "Backward scan...");
/*     */ 
/*     */     
/* 279 */     ArrayList<WeightedOffset> offsets = new ArrayList<WeightedOffset>();
/*     */ 
/*     */     
/* 282 */     offsets.add(new WeightedOffset(-1, -1, 1, this.weights[2]));
/* 283 */     offsets.add(new WeightedOffset(0, -1, 1, this.weights[1]));
/* 284 */     offsets.add(new WeightedOffset(1, -1, 1, this.weights[2]));
/* 285 */     offsets.add(new WeightedOffset(-1, 0, 1, this.weights[1]));
/* 286 */     offsets.add(new WeightedOffset(0, 0, 1, this.weights[0]));
/* 287 */     offsets.add(new WeightedOffset(1, 0, 1, this.weights[1]));
/* 288 */     offsets.add(new WeightedOffset(-1, 1, 1, this.weights[2]));
/* 289 */     offsets.add(new WeightedOffset(0, 1, 1, this.weights[1]));
/* 290 */     offsets.add(new WeightedOffset(1, 1, 1, this.weights[2]));
/*     */ 
/*     */     
/* 293 */     offsets.add(new WeightedOffset(-1, 1, 0, this.weights[1]));
/* 294 */     offsets.add(new WeightedOffset(0, 1, 0, this.weights[0]));
/* 295 */     offsets.add(new WeightedOffset(1, 1, 0, this.weights[1]));
/* 296 */     offsets.add(new WeightedOffset(1, 0, 0, this.weights[0]));
/*     */ 
/*     */     
/* 299 */     for (int z = this.sizeZ - 1; z >= 0; z--) {
/*     */       
/* 301 */       fireProgressChanged(this, (this.sizeZ - 1 - z), this.sizeZ);
/*     */       
/* 303 */       for (int y = this.sizeY - 1; y >= 0; y--) {
/*     */         
/* 305 */         for (int x = this.sizeX - 1; x >= 0; x--) {
/*     */ 
/*     */           
/* 308 */           int label = this.labels.get(x, y, z);
/*     */ 
/*     */           
/* 311 */           if (label != 0) {
/*     */ 
/*     */ 
/*     */             
/* 315 */             double currentDist = this.distmap.getValue(x, y, z);
/* 316 */             double newDist = currentDist;
/*     */ 
/*     */             
/* 319 */             for (WeightedOffset offset : offsets) {
/*     */               
/* 321 */               int x2 = x + offset.dx;
/* 322 */               int y2 = y + offset.dy;
/* 323 */               int z2 = z + offset.dz;
/*     */ 
/*     */               
/* 326 */               if (x2 < 0 || x2 >= this.sizeX)
/*     */                 continue; 
/* 328 */               if (y2 < 0 || y2 >= this.sizeY)
/*     */                 continue; 
/* 330 */               if (z2 < 0 || z2 >= this.sizeZ) {
/*     */                 continue;
/*     */               }
/* 333 */               if (this.labels.get(x2, y2, z2) != label) {
/*     */ 
/*     */                 
/* 336 */                 newDist = offset.weight;
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 341 */               newDist = Math.min(newDist, this.distmap.getValue(x2, y2, z2) + offset.weight);
/*     */             } 
/*     */ 
/*     */             
/* 345 */             if (newDist < currentDist)
/*     */             {
/* 347 */               this.distmap.setValue(x, y, z, newDist);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 354 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void normalizeResultSlices() {
/* 359 */     fireStatusChanged(this, "Normalize map...");
/* 360 */     for (int z = 0; z < this.sizeZ; z++) {
/*     */       
/* 362 */       fireProgressChanged(this, z, this.sizeZ);
/* 363 */       for (int y = 0; y < this.sizeY; y++) {
/*     */         
/* 365 */         for (int x = 0; x < this.sizeX; x++) {
/*     */           
/* 367 */           if (this.labels.get(x, y, z) != 0)
/*     */           {
/* 369 */             this.distmap.setValue(x, y, z, this.distmap.getValue(x, y, z) / this.weights[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 374 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private class WeightedOffset
/*     */   {
/*     */     int dx;
/*     */     int dy;
/*     */     int dz;
/*     */     float weight;
/*     */     
/*     */     public WeightedOffset(int dx, int dy, int dz, float weight) {
/* 386 */       this.dx = dx;
/* 387 */       this.dy = dy;
/* 388 */       this.dz = dz;
/* 389 */       this.weight = weight;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/label/distmap/DistanceTransform3DFloat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */