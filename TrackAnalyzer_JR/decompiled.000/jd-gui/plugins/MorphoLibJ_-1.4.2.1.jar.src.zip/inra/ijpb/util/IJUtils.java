/*     */ package inra.ijpb.util;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.text.TextWindow;
/*     */ import java.awt.Frame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IJUtils
/*     */ {
/*     */   public static final String showElapsedTime(String opName, double timeInMillis, ImagePlus refImage) {
/*     */     double nElements;
/*     */     String elementName;
/*  65 */     if (refImage.getImageStackSize() == 1) {
/*     */       
/*  67 */       nElements = (refImage.getWidth() * refImage.getHeight());
/*  68 */       elementName = "pixels";
/*     */     }
/*     */     else {
/*     */       
/*  72 */       nElements = refImage.getWidth() * refImage.getHeight() * refImage.getStackSize();
/*  73 */       elementName = "voxels";
/*     */     } 
/*     */     
/*  76 */     double timeInSecs = timeInMillis / 1000.0D;
/*  77 */     int elementsPerSecond = (int)(nElements / timeInSecs);
/*     */     
/*  79 */     String pattern = "%s: %.3f seconds, %d %s/second";
/*  80 */     String status = String.format(Locale.ENGLISH, pattern, new Object[] { opName, Double.valueOf(timeInSecs), Integer.valueOf(elementsPerSecond), elementName });
/*     */     
/*  82 */     IJ.showStatus(status);
/*  83 */     return status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final TextWindow[] getTableWindows() {
/*  94 */     Frame[] frames = WindowManager.getNonImageWindows();
/*     */     
/*  96 */     ArrayList<TextWindow> windows = new ArrayList<TextWindow>(frames.length); byte b; int i;
/*     */     Frame[] arrayOfFrame1;
/*  98 */     for (i = (arrayOfFrame1 = frames).length, b = 0; b < i; ) { Frame frame = arrayOfFrame1[b];
/*     */       
/* 100 */       if (frame instanceof TextWindow) {
/*     */         
/* 102 */         TextWindow tw = (TextWindow)frame;
/* 103 */         if (tw.getTextPanel().getResultsTable() != null)
/*     */         {
/* 105 */           windows.add(tw);
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */     
/* 110 */     return windows.<TextWindow>toArray(new TextWindow[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] parseLabelList(String string) {
/* 122 */     String[] tokens = string.split("[, ]+");
/* 123 */     int n = tokens.length;
/*     */     
/* 125 */     int[] labels = new int[n];
/* 126 */     for (int i = 0; i < n; i++)
/*     */     {
/* 128 */       labels[i] = Integer.parseInt(tokens[i]);
/*     */     }
/* 130 */     return labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void printImage(ImageProcessor image) {
/* 141 */     for (int y = 0; y < image.getHeight(); y++) {
/*     */       
/* 143 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */         
/* 145 */         System.out.print(String.format("%3d ", new Object[] { Integer.valueOf((int)image.getf(x, y)) }));
/*     */       } 
/* 147 */       System.out.println("");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/util/IJUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */