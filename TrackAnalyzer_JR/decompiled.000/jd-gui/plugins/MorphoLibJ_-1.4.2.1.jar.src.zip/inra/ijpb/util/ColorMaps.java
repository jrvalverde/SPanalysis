/*     */ package inra.ijpb.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.IndexColorModel;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorMaps
/*     */ {
/*     */   public enum CommonLabelMaps
/*     */   {
/*  43 */     GRAYS("Grays"),
/*  44 */     FIRE("Fire"),
/*  45 */     GLASBEY("Glasbey"),
/*  46 */     GOLDEN_ANGLE("Golden angle"),
/*  47 */     ICE("Ice"),
/*  48 */     SPECTRUM("Spectrum"),
/*  49 */     JET("Jet"),
/*  50 */     RGB332("RGB 3-3-2"),
/*  51 */     MAIN_COLORS("Main Colors"),
/*  52 */     MIXED_COLORS("Mixed Colors"),
/*  53 */     REDGREEN("Red-Green");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     CommonLabelMaps(String label) {
/*  58 */       this.label = label;
/*     */     }
/*     */     
/*     */     public String getLabel() {
/*  62 */       return this.label;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  66 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[][] computeLut(int nValues, boolean shuffle) {
/*     */       byte[][] lut;
/*  72 */       if (this == GRAYS) {
/*  73 */         lut = ColorMaps.createGrayLut();
/*  74 */       } else if (this == FIRE) {
/*  75 */         lut = ColorMaps.createFireLut(nValues);
/*  76 */       } else if (this == GLASBEY) {
/*  77 */         lut = ColorMaps.createGlasbeyLut();
/*  78 */       } else if (this == GOLDEN_ANGLE) {
/*  79 */         lut = ColorMaps.createGoldenAngleLut(nValues);
/*  80 */       } else if (this == ICE) {
/*  81 */         lut = ColorMaps.createIceLut(nValues);
/*  82 */       } else if (this == SPECTRUM) {
/*  83 */         lut = ColorMaps.createSpectrumLut();
/*  84 */       } else if (this == JET) {
/*  85 */         lut = ColorMaps.createJetLut(nValues);
/*  86 */       } else if (this == RGB332) {
/*  87 */         lut = ColorMaps.createRGB332Lut();
/*  88 */       } else if (this == MAIN_COLORS) {
/*  89 */         lut = ColorMaps.createMainColorsLut();
/*  90 */         if (lut.length != nValues) {
/*  91 */           lut = ColorMaps.circularLut(lut, nValues);
/*     */         }
/*  93 */       } else if (this == MIXED_COLORS) {
/*  94 */         lut = ColorMaps.createMixedColorsLut();
/*  95 */         if (lut.length != nValues) {
/*  96 */           lut = ColorMaps.circularLut(lut, nValues);
/*     */         }
/*  98 */       } else if (this == REDGREEN) {
/*  99 */         lut = ColorMaps.createRedGreenLut();
/*     */       } else {
/* 101 */         throw new RuntimeException("Could not create lut for name: " + this.label);
/*     */       } 
/*     */       
/* 104 */       if (lut.length != nValues) {
/* 105 */         lut = ColorMaps.interpolateLut(lut, nValues);
/*     */       }
/*     */       
/* 108 */       if (shuffle) {
/* 109 */         lut = ColorMaps.shuffleLut(lut, 42L);
/*     */       }
/*     */       
/* 112 */       return lut;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/* 116 */       int n = (values()).length;
/* 117 */       String[] result = new String[n];
/*     */       
/* 119 */       int i = 0; byte b; int j; CommonLabelMaps[] arrayOfCommonLabelMaps;
/* 120 */       for (j = (arrayOfCommonLabelMaps = values()).length, b = 0; b < j; ) { CommonLabelMaps map = arrayOfCommonLabelMaps[b];
/* 121 */         result[i++] = map.label; b++; }
/*     */       
/* 123 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static CommonLabelMaps fromLabel(String label) {
/* 136 */       if (label != null)
/* 137 */         label = label.toLowerCase();  byte b; int i; CommonLabelMaps[] arrayOfCommonLabelMaps;
/* 138 */       for (i = (arrayOfCommonLabelMaps = values()).length, b = 0; b < i; ) { CommonLabelMaps map = arrayOfCommonLabelMaps[b];
/* 139 */         String cmp = map.label.toLowerCase();
/* 140 */         if (cmp.equals(label))
/* 141 */           return map;  b++; }
/*     */       
/* 143 */       throw new IllegalArgumentException("Unable to parse CommonLabelMaps with label: " + label);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ColorModel createColorModel(byte[][] cmap) {
/* 163 */     int n = cmap.length;
/* 164 */     return new IndexColorModel(8, n, cmap[0], cmap[1], cmap[2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ColorModel createColorModel(byte[][] cmap, Color bg) {
/* 177 */     int n = cmap.length;
/* 178 */     byte[] r = new byte[n + 1];
/* 179 */     byte[] g = new byte[n + 1];
/* 180 */     byte[] b = new byte[n + 1];
/*     */     
/* 182 */     r[0] = (byte)bg.getRed();
/* 183 */     g[0] = (byte)bg.getGreen();
/* 184 */     b[0] = (byte)bg.getBlue();
/*     */     
/* 186 */     for (int i = 0; i < n; i++) {
/* 187 */       r[i + 1] = cmap[i][0];
/* 188 */       g[i + 1] = cmap[i][1];
/* 189 */       b[i + 1] = cmap[i][2];
/*     */     } 
/* 191 */     return new IndexColorModel(8, n + 1, r, g, b);
/*     */   }
/*     */   
/*     */   public static final byte[][] createFireLut(int nColors) {
/* 195 */     byte[][] lut = createFireLut();
/* 196 */     if (nColors != lut.length)
/* 197 */       lut = interpolateLut(lut, nColors); 
/* 198 */     return lut;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createFireLut() {
/* 203 */     int[] r = { 0, 0, 1, 25, 49, 73, 98, 122, 146, 162, 173, 184, 195, 207, 
/* 204 */         217, 229, 240, 252, 255, 255, 255, 255, 255, 255, 255, 255, 
/* 205 */         255, 255, 255, 255, 255, 255 };
/* 206 */     int[] g = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 35, 57, 79, 101, 
/* 207 */         117, 133, 147, 161, 175, 190, 205, 219, 234, 248, 255, 255, 
/* 208 */         255, 255 };
/* 209 */     int[] b = { 0, 61, 96, 130, 165, 192, 220, 227, 210, 181, 151, 122, 93, 
/* 210 */         64, 35, 5, 35, 98, 160, 223, 
/* 211 */         255 };
/*     */ 
/*     */     
/* 214 */     byte[][] map = new byte[r.length][3];
/*     */ 
/*     */     
/* 217 */     for (int i = 0; i < r.length; i++) {
/* 218 */       map[i][0] = (byte)r[i];
/* 219 */       map[i][1] = (byte)g[i];
/* 220 */       map[i][2] = (byte)b[i];
/*     */     } 
/*     */     
/* 223 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] createGlasbeyLut() {
/* 238 */     int[] r = { 255, 255, 255, 255, 154, 120, 31, 255, 
/* 239 */         177, 241, 254, 221, 32, 114, 118, 2, 200, 136, 255, 133, 161, 
/* 240 */         20, 220, 147, 57, 238, 171, 161, 164, 255, 71, 212, 
/* 241 */         251, 171, 117, 166, 165, 98, 86, 159, 66, 255, 252, 
/* 242 */         159, 167, 74, 145, 207, 195, 253, 66, 106, 181, 132, 96, 255, 
/* 243 */         102, 254, 228, 17, 210, 91, 32, 180, 226, 93, 166, 97, 98, 
/* 244 */         126, 255, 7, 180, 148, 204, 55, 150, 39, 206, 150, 180, 
/* 245 */         110, 147, 199, 115, 15, 172, 182, 216, 87, 216, 243, 216, 1, 
/* 246 */         52, 255, 87, 198, 255, 123, 120, 162, 105, 198, 121, 231, 217, 
/* 247 */         255, 209, 36, 87, 211, 203, 62, 112, 209, 105, 255, 233, 
/* 248 */         191, 69, 171, 14, 118, 255, 94, 238, 159, 80, 189, 88, 71, 
/* 249 */         1, 99, 2, 139, 171, 141, 85, 150, 255, 222, 107, 30, 173, 
/* 250 */         255, 138, 111, 225, 255, 229, 114, 111, 134, 99, 105, 200, 
/* 251 */         209, 198, 79, 174, 170, 199, 255, 146, 102, 111, 92, 172, 210, 
/* 252 */         199, 255, 250, 49, 254, 254, 68, 201, 199, 68, 147, 22, 8, 116, 
/* 253 */         104, 64, 164, 207, 118, 83, 43, 160, 176, 29, 122, 214, 160, 
/* 254 */         106, 153, 192, 125, 149, 213, 22, 166, 109, 86, 255, 255, 255, 
/* 255 */         202, 67, 234, 191, 38, 85, 121, 254, 139, 141, 63, 255, 17, 
/* 256 */         154, 149, 126, 58, 189 };
/* 257 */     int[] g = { 255, 255, 83, 211, 159, 77, 255, 63, 150, 172, 
/* 258 */         204, 8, 143, 26, 108, 173, 255, 108, 183, 133, 3, 249, 71, 
/* 259 */         94, 212, 76, 66, 167, 112, 245, 146, 255, 206, 173, 118, 
/* 260 */         188, 115, 93, 132, 121, 255, 53, 45, 242, 93, 255, 191, 
/* 261 */         84, 39, 16, 78, 149, 187, 68, 78, 1, 131, 233, 217, 111, 75, 
/* 262 */         100, 3, 199, 129, 118, 59, 84, 8, 1, 132, 250, 123, 190, 60, 
/* 263 */         253, 197, 167, 186, 187, 40, 122, 136, 130, 164, 32, 86, 
/* 264 */         48, 102, 187, 164, 117, 220, 141, 85, 196, 165, 255, 24, 66, 
/* 265 */         154, 95, 241, 95, 172, 100, 133, 255, 82, 26, 238, 207, 128, 
/* 266 */         211, 255, 163, 231, 111, 24, 117, 176, 24, 30, 200, 203, 194, 
/* 267 */         129, 42, 76, 117, 30, 73, 169, 55, 230, 54, 144, 109, 223, 
/* 268 */         80, 93, 48, 206, 83, 42, 83, 255, 152, 138, 69, 109, 76, 
/* 269 */         134, 35, 205, 202, 75, 176, 232, 16, 82, 137, 38, 38, 110, 164, 
/* 270 */         210, 103, 165, 45, 81, 89, 102, 134, 152, 255, 137, 34, 207, 
/* 271 */         185, 148, 34, 81, 141, 54, 162, 232, 152, 172, 75, 84, 45, 60, 
/* 272 */         41, 113, 1, 82, 92, 217, 26, 3, 58, 209, 100, 157, 219, 
/* 273 */         56, 255, 162, 131, 249, 105, 188, 109, 3, 109, 170, 
/* 274 */         165, 44, 185, 182, 236, 165, 254, 60, 17, 221, 26, 66, 157, 
/* 275 */         130, 6, 117 };
/* 276 */     int[] b = { 255, 255, 51, 182, 255, 66, 190, 193, 152, 253, 
/* 277 */         113, 92, 66, 255, 1, 85, 149, 36, 159, 103, 255, 158, 
/* 278 */         147, 255, 255, 80, 106, 254, 100, 204, 255, 115, 113, 21, 197, 
/* 279 */         111, 215, 154, 254, 174, 2, 168, 131, 63, 66, 187, 67, 
/* 280 */         124, 186, 19, 108, 166, 109, 255, 64, 32, 84, 147, 211, 
/* 281 */         63, 127, 174, 139, 124, 106, 255, 210, 20, 68, 255, 201, 122, 
/* 282 */         58, 183, 226, 57, 138, 160, 49, 1, 129, 38, 180, 196, 128, 
/* 283 */         180, 185, 61, 255, 253, 100, 250, 254, 113, 34, 103, 105, 182, 
/* 284 */         219, 54, 1, 79, 133, 240, 49, 204, 220, 100, 64, 70, 69, 233, 
/* 285 */         209, 141, 3, 193, 201, 79, 223, 88, 107, 197, 255, 137, 
/* 286 */         46, 145, 194, 61, 25, 127, 200, 217, 138, 33, 148, 128, 126, 96, 
/* 287 */         103, 159, 60, 148, 37, 255, 135, 148, 123, 203, 200, 230, 68, 
/* 288 */         138, 161, 60, 157, 253, 77, 57, 255, 101, 48, 80, 32, 255, 
/* 289 */         86, 77, 166, 101, 175, 172, 78, 184, 255, 159, 178, 98, 147, 30, 
/* 290 */         141, 78, 97, 100, 23, 84, 240, 58, 28, 121, 255, 38, 215, 
/* 291 */         155, 35, 88, 232, 87, 146, 229, 36, 159, 207, 105, 160, 113, 207, 
/* 292 */         89, 34, 223, 204, 69, 97, 78, 81, 248, 73, 35, 18, 173, 51, 
/* 293 */         2, 158, 212, 89, 193, 43, 40, 246, 146, 84, 238, 72, 101, 101 };
/*     */ 
/*     */     
/* 296 */     byte[][] map = new byte[r.length][3];
/*     */ 
/*     */     
/* 299 */     for (int i = 0; i < r.length; i++) {
/* 300 */       map[i][0] = (byte)r[i];
/* 301 */       map[i][1] = (byte)g[i];
/* 302 */       map[i][2] = (byte)b[i];
/*     */     } 
/*     */     
/* 305 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] createGoldenAngleLut(int nColors) {
/* 318 */     float hue = 0.5F;
/*     */     
/* 320 */     float saturation = 0.75F;
/*     */ 
/*     */ 
/*     */     
/* 324 */     Color[] colors = new Color[nColors];
/* 325 */     for (int i = 0; i < nColors; i++) {
/*     */ 
/*     */       
/* 328 */       colors[i] = Color.getHSBColor(hue, saturation, 1.0F);
/*     */ 
/*     */       
/* 331 */       hue += 0.38197F;
/* 332 */       if (hue > 1.0F)
/* 333 */         hue--; 
/* 334 */       saturation += 0.38197F;
/* 335 */       if (saturation > 1.0F)
/* 336 */         saturation--; 
/* 337 */       saturation = 0.5F * saturation + 0.5F;
/*     */     } 
/*     */ 
/*     */     
/* 341 */     byte[][] map = new byte[nColors][3];
/*     */ 
/*     */     
/* 344 */     for (int j = 0; j < nColors; j++) {
/*     */       
/* 346 */       Color color = colors[j];
/* 347 */       map[j][0] = (byte)color.getRed();
/* 348 */       map[j][1] = (byte)color.getGreen();
/* 349 */       map[j][2] = (byte)color.getBlue();
/*     */     } 
/*     */     
/* 352 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createGrayLut() {
/* 357 */     byte[][] map = new byte[256][3];
/*     */ 
/*     */     
/* 360 */     for (int i = 0; i < 256; i++) {
/* 361 */       map[i][0] = (byte)i;
/* 362 */       map[i][1] = (byte)i;
/* 363 */       map[i][2] = (byte)i;
/*     */     } 
/*     */     
/* 366 */     return map;
/*     */   }
/*     */   
/*     */   public static final byte[][] createJetLut(int nColors) {
/* 370 */     byte[][] lut = createJetLut();
/* 371 */     if (nColors != lut.length)
/* 372 */       lut = interpolateLut(lut, nColors); 
/* 373 */     return lut;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createJetLut() {
/* 378 */     byte[][] map = new byte[256][3];
/*     */     
/*     */     int i;
/* 381 */     for (i = 0; i < 32; i++)
/* 382 */       map[i][2] = (byte)(127 + i * 4); 
/* 383 */     for (i = 32; i < 96; i++) {
/* 384 */       map[i][1] = (byte)((i - 32) * 4);
/* 385 */       map[i][2] = -1;
/*     */     } 
/* 387 */     for (i = 96; i < 160; i++) {
/* 388 */       map[i][0] = (byte)((i - 96) * 4);
/* 389 */       map[i][1] = -1;
/* 390 */       map[i][2] = (byte)(255 - (i - 96) * 4);
/*     */     } 
/* 392 */     for (i = 160; i < 224; i++) {
/* 393 */       map[i][0] = -1;
/* 394 */       map[i][1] = (byte)(255 - (i - 160) * 4);
/* 395 */       map[i][2] = 0;
/*     */     } 
/* 397 */     for (i = 224; i < 256; i++) {
/* 398 */       map[i][0] = (byte)(255 - (i - 224) * 4);
/*     */     }
/* 400 */     return map;
/*     */   }
/*     */   
/*     */   public static final byte[][] createIceLut(int nColors) {
/* 404 */     byte[][] lut = createIceLut();
/* 405 */     if (nColors != lut.length)
/* 406 */       lut = interpolateLut(lut, nColors); 
/* 407 */     return lut;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createIceLut() {
/* 412 */     int[] r = { 0, 0, 0, 0, 0, 0, 19, 29, 50, 48, 79, 112, 134, 158, 186, 
/* 413 */         201, 217, 229, 242, 250, 250, 250, 250, 251, 250, 250, 250, 
/* 414 */         250, 251, 251, 243, 230 };
/* 415 */     int[] g = { 156, 165, 176, 184, 190, 196, 193, 184, 171, 162, 146, 125, 
/* 416 */         107, 93, 81, 87, 92, 97, 95, 93, 93, 90, 85, 69, 64, 54, 47, 
/* 417 */         35, 19, 4 };
/* 418 */     int[] b = { 140, 147, 158, 166, 170, 176, 209, 220, 234, 225, 236, 246, 
/* 419 */         250, 251, 250, 250, 245, 230, 230, 222, 202, 180, 163, 142, 
/* 420 */         123, 114, 106, 94, 84, 64, 26, 27 };
/*     */ 
/*     */     
/* 423 */     byte[][] map = new byte[r.length][3];
/*     */ 
/*     */     
/* 426 */     for (int i = 0; i < r.length; i++) {
/* 427 */       map[i][0] = (byte)r[i];
/* 428 */       map[i][1] = (byte)g[i];
/* 429 */       map[i][2] = (byte)b[i];
/*     */     } 
/*     */     
/* 432 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createSpectrumLut() {
/* 437 */     byte[][] map = new byte[256][3];
/*     */ 
/*     */     
/* 440 */     for (int i = 0; i < 256; i++) {
/* 441 */       Color c = Color.getHSBColor(i / 255.0F, 1.0F, 1.0F);
/* 442 */       map[i][0] = (byte)c.getRed();
/* 443 */       map[i][1] = (byte)c.getGreen();
/* 444 */       map[i][2] = (byte)c.getBlue();
/*     */     } 
/*     */     
/* 447 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createRGB332Lut() {
/* 452 */     byte[][] map = new byte[256][3];
/*     */ 
/*     */     
/* 455 */     for (int i = 0; i < 256; i++) {
/* 456 */       map[i][0] = (byte)(i & 0xE0);
/* 457 */       map[i][1] = (byte)(i << 3 & 0xE0);
/* 458 */       map[i][2] = (byte)(i << 6 & 0xC0);
/*     */     } 
/*     */     
/* 461 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] createRedGreenLut() {
/* 466 */     byte[][] map = new byte[256][3];
/*     */     int i;
/* 468 */     for (i = 0; i < 128; i++) {
/* 469 */       map[i][0] = (byte)(i * 2);
/* 470 */       map[i][1] = 0;
/* 471 */       map[i][2] = 0;
/*     */     } 
/* 473 */     for (i = 128; i < 256; i++) {
/* 474 */       map[i][0] = 0;
/* 475 */       map[i][1] = (byte)(i * 2);
/* 476 */       map[i][2] = 0;
/*     */     } 
/* 478 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] createMainColorsLut() {
/* 487 */     return new byte[][] {
/* 488 */         { -1
/* 489 */         }, { 0, -1
/* 490 */         }, { 0, 0, -1
/* 491 */         }, { 0, -1, -1
/* 492 */         }, { -1, -1
/* 493 */         }, { -1, -1 }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] createMixedColorsLut() {
/* 503 */     return new byte[][] { 
/* 504 */         { -1
/* 505 */         }, { 0, -1
/* 506 */         }, { 0, 0, -1
/*     */         },
/* 508 */         { 0, -1, -1
/* 509 */         }, { -1, -1
/* 510 */         }, { -1, -1
/*     */         },
/* 512 */         { Byte.MAX_VALUE
/* 513 */         }, { 0, Byte.MAX_VALUE
/* 514 */         }, { 0, 0, Byte.MAX_VALUE
/*     */         },
/* 516 */         { Byte.MAX_VALUE, Byte.MAX_VALUE }, 
/* 517 */         { 0, Byte.MAX_VALUE, Byte.MAX_VALUE
/* 518 */         }, { Byte.MAX_VALUE, Byte.MAX_VALUE
/*     */         },
/* 520 */         { Byte.MAX_VALUE, Byte.MAX_VALUE, -1
/* 521 */         }, { -1, Byte.MAX_VALUE, Byte.MAX_VALUE
/* 522 */         }, { Byte.MAX_VALUE, -1, Byte.MAX_VALUE
/*     */         },
/* 524 */         { Byte.MAX_VALUE, -1
/* 525 */         }, { Byte.MAX_VALUE, -1
/* 526 */         }, { Byte.MAX_VALUE, -1, -1
/*     */         },
/* 528 */         { 0, Byte.MAX_VALUE, -1
/* 529 */         }, { -1, Byte.MAX_VALUE }, 
/* 530 */         { -1, Byte.MAX_VALUE, -1
/*     */         },
/* 532 */         { 0, -1, Byte.MAX_VALUE
/* 533 */         }, { -1, Byte.MAX_VALUE
/* 534 */         }, { -1, -1, Byte.MAX_VALUE } };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] interpolateLut(byte[][] baseLut, int nColors) {
/* 540 */     int n0 = baseLut.length;
/*     */     
/* 542 */     byte[][] lut = new byte[nColors][3];
/*     */ 
/*     */     
/* 545 */     for (int i = 0; i < nColors; i++) {
/*     */       
/* 547 */       float i0 = i * n0 / nColors;
/* 548 */       int i1 = (int)Math.floor(i0);
/*     */ 
/*     */       
/* 551 */       byte[] col1 = baseLut[i1];
/* 552 */       byte[] col2 = baseLut[Math.min(i1 + 1, n0 - 1)];
/*     */ 
/*     */       
/* 555 */       float f = i0 - i1;
/*     */ 
/*     */       
/* 558 */       lut[i][0] = (byte)(int)((1.0D - f) * (col1[0] & 0xFF) + (f * (col2[0] & 0xFF)));
/* 559 */       lut[i][1] = (byte)(int)((1.0D - f) * (col1[1] & 0xFF) + (f * (col2[1] & 0xFF)));
/* 560 */       lut[i][2] = (byte)(int)((1.0D - f) * (col1[2] & 0xFF) + (f * (col2[2] & 0xFF)));
/*     */     } 
/*     */     
/* 563 */     return lut;
/*     */   }
/*     */   
/*     */   public static final byte[][] circularLut(byte[][] baseLut, int nColors) {
/* 567 */     int n0 = baseLut.length;
/*     */     
/* 569 */     byte[][] lut = new byte[nColors][3];
/*     */ 
/*     */     
/* 572 */     for (int i = 0; i < nColors; i++) {
/* 573 */       lut[i] = baseLut[i % n0];
/*     */     }
/* 575 */     return lut;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[][] shuffleLut(byte[][] lut) {
/* 580 */     int n = lut.length;
/* 581 */     double[] values = new double[n];
/* 582 */     Random random = new Random();
/* 583 */     for (int i = 0; i < n; i++) {
/* 584 */       values[i] = random.nextDouble();
/*     */     }
/*     */     
/* 587 */     int[] indices = sort(values);
/*     */ 
/*     */     
/* 590 */     byte[][] result = new byte[n][];
/* 591 */     for (int j = 0; j < n; j++)
/* 592 */       result[j] = lut[indices[j]]; 
/* 593 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] shuffleLut(byte[][] lut, long seed) {
/* 608 */     int n = lut.length;
/* 609 */     double[] values = new double[n];
/* 610 */     Random random = new Random(seed);
/* 611 */     for (int i = 0; i < n; i++) {
/* 612 */       values[i] = random.nextDouble();
/*     */     }
/*     */     
/* 615 */     int[] indices = sort(values);
/*     */ 
/*     */     
/* 618 */     byte[][] result = new byte[n][];
/* 619 */     for (int j = 0; j < n; j++)
/* 620 */       result[j] = lut[indices[j]]; 
/* 621 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int[] sort(double[] array) {
/* 632 */     DoubleArrayIndexComparator comparator = new DoubleArrayIndexComparator(array);
/* 633 */     Integer[] indices = comparator.createIndexArray();
/* 634 */     Arrays.sort(indices, comparator);
/*     */ 
/*     */     
/* 637 */     int[] sortedIndices = new int[indices.length];
/* 638 */     for (int i = 0; i < indices.length; i++) {
/* 639 */       sortedIndices[i] = indices[i].intValue();
/*     */     }
/* 641 */     return sortedIndices;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DoubleArrayIndexComparator
/*     */     implements Comparator<Integer>
/*     */   {
/*     */     private final double[] array;
/*     */ 
/*     */     
/*     */     public DoubleArrayIndexComparator(double[] array) {
/* 652 */       this.array = array;
/*     */     }
/*     */     
/*     */     public Integer[] createIndexArray() {
/* 656 */       Integer[] indexes = new Integer[this.array.length];
/* 657 */       for (int i = 0; i < this.array.length; i++) {
/* 658 */         indexes[i] = Integer.valueOf(i);
/*     */       }
/* 660 */       return indexes;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compare(Integer index1, Integer index2) {
/* 665 */       return Double.compare(this.array[index1.intValue()], this.array[index2.intValue()]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/util/ColorMaps.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */