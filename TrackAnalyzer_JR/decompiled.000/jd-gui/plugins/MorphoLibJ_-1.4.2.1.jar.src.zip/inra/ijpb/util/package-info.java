package inra.ijpb.util;

interface package-info {}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/util/package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */