/*     */ package inra.ijpb.util;
/*     */ 
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CommonColors
/*     */ {
/*  47 */   WHITE("White", Color.WHITE),
/*  48 */   BLACK("Black", Color.BLACK),
/*  49 */   RED("Red", Color.RED),
/*  50 */   GREEN("Green", Color.GREEN),
/*  51 */   BLUE("Blue", Color.BLUE),
/*  52 */   CYAN("Cyan", Color.CYAN),
/*  53 */   MAGENTA("Magenta", Color.MAGENTA),
/*  54 */   YELLOW("Yellow", Color.YELLOW),
/*  55 */   GRAY("Gray", Color.GRAY),
/*  56 */   DARK_GRAY("Dark Gray", Color.DARK_GRAY),
/*  57 */   LIGHT_GRAY("Light Gray", Color.LIGHT_GRAY);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String label;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Color color;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CommonColors(String label, Color color) {
/*  72 */     this.label = label;
/*  73 */     this.color = color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  81 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/*  89 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     return this.label;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] getAllLabels() {
/* 102 */     int n = (values()).length;
/* 103 */     String[] result = new String[n];
/*     */     
/* 105 */     int i = 0; byte b; int j; CommonColors[] arrayOfCommonColors;
/* 106 */     for (j = (arrayOfCommonColors = values()).length, b = 0; b < j; ) { CommonColors color = arrayOfCommonColors[b];
/* 107 */       result[i++] = color.label; b++; }
/*     */     
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CommonColors fromLabel(String label) {
/* 123 */     if (label != null)
/* 124 */       label = label.toLowerCase();  byte b; int i; CommonColors[] arrayOfCommonColors;
/* 125 */     for (i = (arrayOfCommonColors = values()).length, b = 0; b < i; ) { CommonColors color = arrayOfCommonColors[b];
/*     */       
/* 127 */       String cmp = color.label.toLowerCase();
/* 128 */       if (cmp.equals(label))
/* 129 */         return color;  b++; }
/*     */     
/* 131 */     throw new IllegalArgumentException("Unable to parse Color with label: " + label);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/util/CommonColors.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */