/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransform;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat5x5;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ import java.awt.Point;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDiameter
/*     */   extends RegionAnalyzer2D<GeodesicDiameter.Result>
/*     */ {
/*     */   GeodesicDistanceTransform geodesicDistanceTransform;
/*     */   
/*     */   public static final Result[] geodesicDiameters(ImageProcessor labelImage, int[] labels, Calibration calib) {
/* 106 */     return (new GeodesicDiameter()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean computePaths = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   int[][] shifts = new int[][] { 
/* 126 */       { -1, -2 }, { 0, -2 }, { 1, -2
/* 127 */       }, { -2, -1 }, { -1, -1 }, { 0, -1 }, { 1, -1 }, { 2, -1
/* 128 */       }, { -2 }, { -1 }, { 1 }, { 2
/* 129 */       }, { -2, 1 }, { -1, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1
/* 130 */       }, { -1, 2 }, { 0, 2 }, { 1, 2 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter() {
/* 142 */     this((GeodesicDistanceTransform)new GeodesicDistanceTransformFloat5x5(ChamferWeights.CHESSKNIGHT.getFloatWeights(), true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter(ChamferWeights weights) {
/* 154 */     this((GeodesicDistanceTransform)new GeodesicDistanceTransformFloat5x5(weights, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter(float[] weights) {
/* 166 */     this((GeodesicDistanceTransform)new GeodesicDistanceTransformFloat5x5(weights, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeodesicDiameter(GeodesicDistanceTransform gdt) {
/* 178 */     this.geodesicDistanceTransform = gdt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, Result> analyzeRegions(ImageProcessor labelImage) {
/* 195 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 196 */     Result[] geodDiams = analyzeRegions(labelImage, labels, new Calibration());
/*     */ 
/*     */     
/* 199 */     Map<Integer, Result> map = new TreeMap<Integer, Result>();
/* 200 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/* 202 */       map.put(Integer.valueOf(labels[i]), geodDiams[i]);
/*     */     }
/*     */     
/* 205 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getComputePaths() {
/* 214 */     return this.computePaths;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComputePaths(boolean bool) {
/* 219 */     this.computePaths = bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChamferWeights(float[] weights) {
/* 224 */     this.geodesicDistanceTransform = (GeodesicDistanceTransform)new GeodesicDistanceTransformFloat5x5(weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Result> map) {
/* 243 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 247 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 250 */       Result res = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 253 */       table.incrementCounter();
/* 254 */       table.addLabel(Integer.toString(label));
/* 255 */       table.addValue("GeodesicDiameter", res.diameter);
/*     */ 
/*     */       
/* 258 */       table.addValue("Radius", res.innerRadius);
/* 259 */       table.addValue("InitPoint.X", res.initialPoint.getX());
/* 260 */       table.addValue("InitPoint.Y", res.initialPoint.getY());
/* 261 */       table.addValue("GeodesicElongation", Math.max(res.diameter / res.innerRadius * 2.0D, 1.0D));
/*     */ 
/*     */       
/* 264 */       table.addValue("Extremity1.X", res.firstExtremity.getX());
/* 265 */       table.addValue("Extremity1.Y", res.firstExtremity.getY());
/* 266 */       table.addValue("Extremity2.X", res.secondExtremity.getX());
/* 267 */       table.addValue("Extremity2.Y", res.secondExtremity.getY()); }
/*     */ 
/*     */     
/* 270 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result[] analyzeRegions(ImageProcessor labelImage, int[] labels, Calibration calib) {
/* 289 */     if (calib.pixelWidth != calib.pixelHeight)
/*     */     {
/* 291 */       throw new RuntimeException("Requires image with square pixels");
/*     */     }
/*     */ 
/*     */     
/* 295 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 298 */     int sizeX = labelImage.getWidth();
/* 299 */     int sizeY = labelImage.getHeight();
/* 300 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX, sizeY);
/*     */ 
/*     */ 
/*     */     
/* 304 */     fireStatusChanged(this, "Initializing pseudo geodesic centers...");
/* 305 */     float[] weights = ChamferWeights.CHESSKNIGHT.getFloatWeights();
/* 306 */     FloatProcessor floatProcessor = BinaryImages.distanceMap(labelImage, weights, true);
/*     */ 
/*     */     
/* 309 */     LabelValues.PositionValuePair[] innerCircles = LabelValues.findMaxValues((ImageProcessor)floatProcessor, labelImage, labels);
/*     */ 
/*     */     
/* 312 */     byteProcessor.setValue(0.0D);
/* 313 */     byteProcessor.fill();
/* 314 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 316 */       Point center = innerCircles[i].getPosition();
/* 317 */       if (center.x == -1) {
/*     */         
/* 319 */         IJ.showMessage("Particle Not Found", 
/* 320 */             "Could not find maximum for particle label " + labels[i]);
/*     */       } else {
/*     */         
/* 323 */         byteProcessor.set(center.x, center.y, 255);
/*     */       } 
/*     */     } 
/* 326 */     fireStatusChanged(this, "Computing first geodesic extremities...");
/*     */ 
/*     */     
/* 329 */     ImageProcessor imageProcessor = this.geodesicDistanceTransform.geodesicDistanceMap((ImageProcessor)byteProcessor, labelImage);
/*     */ 
/*     */ 
/*     */     
/* 333 */     Point[] firstGeodesicExtremities = LabelValues.findPositionOfMaxValues(imageProcessor, labelImage, labels);
/*     */ 
/*     */     
/* 336 */     byteProcessor.setValue(0.0D);
/* 337 */     byteProcessor.fill();
/* 338 */     for (int j = 0; j < nLabels; j++) {
/*     */       
/* 340 */       if ((firstGeodesicExtremities[j]).x == -1) {
/*     */         
/* 342 */         IJ.showMessage("Particle Not Found", 
/* 343 */             "Could not find maximum for particle label " + labels[j]);
/*     */       } else {
/*     */         
/* 346 */         byteProcessor.set((firstGeodesicExtremities[j]).x, (firstGeodesicExtremities[j]).y, 255);
/*     */       } 
/*     */     } 
/* 349 */     fireStatusChanged(this, "Computing second geodesic extremities...");
/*     */ 
/*     */     
/* 352 */     imageProcessor = this.geodesicDistanceTransform.geodesicDistanceMap((ImageProcessor)byteProcessor, labelImage);
/*     */ 
/*     */     
/* 355 */     LabelValues.PositionValuePair[] secondGeodesicExtremities = LabelValues.findMaxValues(imageProcessor, labelImage, labels);
/*     */ 
/*     */     
/* 358 */     Result[] result = new Result[nLabels]; int k;
/* 359 */     for (k = 0; k < nLabels; k++) {
/*     */       
/* 361 */       Result res = new Result();
/*     */ 
/*     */ 
/*     */       
/* 365 */       res.diameter = secondGeodesicExtremities[k].getValue() + Math.sqrt(2.0D);
/*     */ 
/*     */       
/* 368 */       res.initialPoint = innerCircles[k].getPosition();
/* 369 */       res.innerRadius = innerCircles[k].getValue();
/* 370 */       res.firstExtremity = firstGeodesicExtremities[k];
/* 371 */       res.secondExtremity = secondGeodesicExtremities[k].getPosition();
/*     */ 
/*     */       
/* 374 */       result[k] = res;
/*     */     } 
/*     */     
/* 377 */     if (this.computePaths) {
/*     */       
/* 379 */       fireStatusChanged(this, "Computing geodesic paths...");
/*     */ 
/*     */       
/* 382 */       for (k = 0; k < nLabels; k++) {
/*     */ 
/*     */ 
/*     */         
/* 386 */         Point2D pos1 = (result[k]).firstExtremity;
/*     */ 
/*     */         
/* 389 */         List<Point2D> path = new ArrayList<Point2D>();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 394 */         if (Double.isInfinite((result[k]).diameter)) {
/*     */           
/* 396 */           (result[k]).path = path;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 402 */           Point pos = (Point)(result[k]).secondExtremity;
/* 403 */           path.add(pos);
/*     */ 
/*     */           
/* 406 */           while (!pos.equals(pos1)) {
/*     */             
/* 408 */             pos = findLowestNeighborPosition(labelImage, imageProcessor, pos);
/* 409 */             path.add(pos);
/*     */           } 
/*     */           
/* 412 */           (result[k]).path = path;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 417 */     if (calib.scaled()) {
/*     */       
/* 419 */       fireStatusChanged(this, "Re-calibrating results");
/* 420 */       for (k = 0; k < nLabels; k++)
/*     */       {
/* 422 */         result[k] = result[k].recalibrate(calib);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 427 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point findLowestNeighborPosition(ImageProcessor labelImage, ImageProcessor distanceMap, Point pos) {
/* 441 */     int refLabel = (int)labelImage.getf(pos.x, pos.y);
/* 442 */     float minDist = distanceMap.getf(pos.x, pos.y);
/*     */ 
/*     */     
/* 445 */     int sizeX = distanceMap.getWidth();
/* 446 */     int sizeY = distanceMap.getHeight();
/*     */ 
/*     */ 
/*     */     
/* 450 */     Point nextPos = pos; byte b; int i, arrayOfInt[][];
/* 451 */     for (i = (arrayOfInt = this.shifts).length, b = 0; b < i; ) { int[] shift = arrayOfInt[b];
/*     */ 
/*     */       
/* 454 */       int x = pos.x + shift[0];
/* 455 */       int y = pos.y + shift[1];
/*     */ 
/*     */       
/* 458 */       if (x >= 0 && x < sizeX)
/*     */       {
/*     */ 
/*     */         
/* 462 */         if (y >= 0 && y < sizeY)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 468 */           if ((int)labelImage.getf(x, y) == refLabel) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 474 */             float dist = distanceMap.getf(x, y);
/* 475 */             if (dist < minDist) {
/*     */               
/* 477 */               minDist = dist;
/* 478 */               nextPos = new Point(x, y);
/*     */             } 
/*     */           }  }  }  b++; }
/*     */     
/* 482 */     if (nextPos.equals(pos))
/*     */     {
/* 484 */       throw new RuntimeException("Could not find a neighbor with smaller value at (" + pos.x + "," + pos.y + ")");
/*     */     }
/*     */     
/* 487 */     return nextPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Result
/*     */   {
/*     */     public double diameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Point2D initialPoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double innerRadius;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Point2D firstExtremity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Point2D secondExtremity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 532 */     public List<Point2D> path = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Result recalibrate(Calibration calib) {
/* 544 */       double size = calib.pixelWidth;
/* 545 */       Result res = new Result();
/*     */ 
/*     */       
/* 548 */       this.diameter *= size;
/*     */ 
/*     */       
/* 551 */       res.initialPoint = calibrate(this.initialPoint, calib);
/* 552 */       this.innerRadius *= size;
/*     */ 
/*     */       
/* 555 */       res.firstExtremity = calibrate(this.firstExtremity, calib);
/* 556 */       res.secondExtremity = calibrate(this.secondExtremity, calib);
/*     */ 
/*     */       
/* 559 */       if (this.path != null) {
/*     */         
/* 561 */         List<Point2D> newPath = new ArrayList<Point2D>(this.path.size());
/* 562 */         for (Point2D point : this.path)
/*     */         {
/* 564 */           newPath.add(calibrate(point, calib));
/*     */         }
/* 566 */         res.path = newPath;
/*     */       } 
/*     */ 
/*     */       
/* 570 */       return res;
/*     */     }
/*     */ 
/*     */     
/*     */     private Point2D calibrate(Point2D point, Calibration calib) {
/* 575 */       return new Point2D.Double(
/* 576 */           point.getX() * calib.pixelWidth + calib.xOrigin, 
/* 577 */           point.getY() * calib.pixelHeight + calib.yOrigin);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/GeodesicDiameter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */