/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.geometry.Sphere;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.label.LabelValues;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LargestInscribedBall
/*     */   extends RegionAnalyzer3D<Sphere>
/*     */ {
/*     */   public static final Sphere[] largestInscribedBalls(ImageStack labelImage, int[] labels, Calibration calib) {
/*  45 */     return (new LargestInscribedBall()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Sphere> map) {
/*  70 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/*  74 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  77 */       Sphere ball = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  80 */       table.incrementCounter();
/*  81 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/*  84 */       table.addValue("InscrBall.Center.X", ball.center().getX());
/*  85 */       table.addValue("InscrBall.Center.Y", ball.center().getY());
/*  86 */       table.addValue("InscrBall.Center.Z", ball.center().getZ());
/*     */ 
/*     */       
/*  89 */       table.addValue("InscrBall.Radius", ball.radius()); }
/*     */ 
/*     */     
/*  92 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sphere[] analyzeRegions(ImageStack labelImage, int[] labels, Calibration calib) {
/* 112 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 115 */     fireStatusChanged(this, "Compute distance map");
/* 116 */     ImageStack distanceMap = LabelImages.distanceMap(labelImage);
/*     */ 
/*     */     
/* 119 */     fireStatusChanged(this, "Find inscribed balls center");
/*     */     
/* 121 */     Cursor3D[] posCenter = LabelValues.findPositionOfMaxValues(distanceMap, labelImage, labels);
/* 122 */     float[] radii = getValues(distanceMap, posCenter);
/*     */ 
/*     */     
/* 125 */     fireStatusChanged(this, "Create ball data");
/* 126 */     Sphere[] balls = new Sphere[nLabels];
/* 127 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 129 */       double xc = posCenter[i].getX() * calib.pixelWidth + calib.xOrigin;
/* 130 */       double yc = posCenter[i].getY() * calib.pixelHeight + calib.yOrigin;
/* 131 */       double zc = posCenter[i].getZ() * calib.pixelDepth + calib.zOrigin;
/* 132 */       Point3D center = new Point3D(xc, yc, zc);
/* 133 */       balls[i] = new Sphere(center, radii[i] * calib.pixelWidth);
/*     */     } 
/*     */     
/* 136 */     return balls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float[] getValues(ImageStack image, Cursor3D[] positions) {
/* 145 */     float[] values = new float[positions.length];
/*     */ 
/*     */     
/* 148 */     for (int i = 0; i < positions.length; i++)
/*     */     {
/* 150 */       values[i] = (float)image.getVoxel(positions[i].getX(), 
/* 151 */           positions[i].getY(), positions[i].getZ());
/*     */     }
/*     */     
/* 154 */     return values;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/LargestInscribedBall.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */