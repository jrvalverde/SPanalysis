/*    */ package inra.ijpb.measure;
/*    */ 
/*    */ import ij.measure.ResultsTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultsBuilder
/*    */ {
/*    */   private ResultsTable allResults;
/*    */   
/*    */   public ResultsBuilder() {
/* 20 */     this.allResults = new ResultsTable();
/*    */   }
/*    */ 
/*    */   
/*    */   public ResultsBuilder(ResultsTable rt) {
/* 25 */     this.allResults = rt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResultsBuilder addResult(ResultsTable rt) {
/* 34 */     if (this.allResults.size() == rt.size()) {
/* 35 */       for (int c = 0; c <= rt.getLastColumn(); c++) {
/* 36 */         String colName = rt.getColumnHeading(c);
/* 37 */         if (!this.allResults.columnExists(colName)) {
/* 38 */           for (int i = 0; i < rt.getCounter(); i++) {
/* 39 */             this.allResults.setValue(colName, i, rt.getValue(colName, i));
/*    */           }
/*    */         }
/*    */       } 
/*    */     } else {
/* 44 */       this.allResults = rt;
/*    */     } 
/*    */     
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResultsTable getResultsTable() {
/* 55 */     return this.allResults;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/ResultsBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */