/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabeledVoxelsMeasure
/*     */ {
/*     */   ArrayList<Double>[] objectVoxels;
/*     */   int[] labels;
/*     */   Calibration calibration;
/*  51 */   HashMap<Integer, Integer> labelIndices = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LabeledVoxelsMeasure(ImagePlus inputImage, ImagePlus labelImage) {
/*  64 */     int width = inputImage.getWidth();
/*  65 */     int height = inputImage.getHeight();
/*     */     
/*  67 */     if (width != labelImage.getWidth() || height != labelImage.getHeight()) {
/*  68 */       throw new IllegalArgumentException("Input and label images must have the same size");
/*     */     }
/*  70 */     this.calibration = inputImage.getCalibration();
/*     */ 
/*     */     
/*  73 */     this.labels = LabelImages.findAllLabels(labelImage.getImageStack());
/*  74 */     int numLabels = this.labels.length;
/*     */ 
/*     */     
/*  77 */     this.labelIndices = LabelImages.mapLabelIndices(this.labels);
/*     */ 
/*     */ 
/*     */     
/*  81 */     this.objectVoxels = (ArrayList<Double>[])new ArrayList[numLabels];
/*     */     
/*  83 */     for (int i = 0; i < numLabels; i++) {
/*  84 */       this.objectVoxels[i] = new ArrayList<Double>();
/*     */     }
/*     */ 
/*     */     
/*  88 */     IJ.showStatus("Extracting voxel information...");
/*     */ 
/*     */     
/*  91 */     int numSlices = inputImage.getImageStackSize();
/*  92 */     for (int z = 1; z <= numSlices; z++) {
/*     */       
/*  94 */       ImageProcessor grayIP = inputImage.getImageStack().getProcessor(z);
/*  95 */       ImageProcessor labelsIP = labelImage.getImageStack().getProcessor(z);
/*     */       
/*  97 */       for (int x = 0; x < width; x++) {
/*  98 */         for (int y = 0; y < height; y++) {
/*     */           
/* 100 */           int labelValue = (int)labelsIP.getf(x, y);
/* 101 */           if (labelValue != 0)
/* 102 */             this.objectVoxels[((Integer)this.labelIndices.get(Integer.valueOf(labelValue))).intValue()].add(Double.valueOf(grayIP.getf(x, y))); 
/*     */         } 
/*     */       } 
/* 105 */       IJ.showProgress(z, numSlices);
/*     */     } 
/*     */     
/* 108 */     IJ.showProgress(1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNumberOfVoxels() {
/* 120 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */     
/* 123 */     ResultsTable table = new ResultsTable();
/* 124 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 126 */       table.incrementCounter();
/* 127 */       table.addLabel(Integer.toString(this.labels[i]));
/* 128 */       table.addValue("NumberOfVoxels", this.objectVoxels[i].size());
/*     */     } 
/*     */     
/* 131 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getSumOfVoxels() {
/* 140 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */     
/* 143 */     ResultsTable table = new ResultsTable();
/* 144 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 146 */       table.incrementCounter();
/* 147 */       table.addLabel(Integer.toString(this.labels[i]));
/*     */ 
/*     */       
/* 150 */       double voxelSum = 0.0D;
/* 151 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double value = ((Double)iterator.next()).doubleValue();
/*     */         
/* 153 */         voxelSum += value; }
/*     */       
/* 155 */       table.addValue("Voxels Sum", voxelSum);
/*     */     } 
/* 157 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getVolume() {
/* 168 */     int numLabels = this.objectVoxels.length;
/*     */     
/* 170 */     double volumePerVoxel = this.calibration.pixelWidth * this.calibration.pixelHeight * this.calibration.pixelDepth;
/*     */ 
/*     */     
/* 173 */     ResultsTable table = new ResultsTable();
/* 174 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 176 */       table.incrementCounter();
/* 177 */       table.addLabel(Integer.toString(this.labels[i]));
/* 178 */       table.addValue("Volume", this.objectVoxels[i].size() * volumePerVoxel);
/*     */     } 
/*     */     
/* 181 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/LabeledVoxelsMeasure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */