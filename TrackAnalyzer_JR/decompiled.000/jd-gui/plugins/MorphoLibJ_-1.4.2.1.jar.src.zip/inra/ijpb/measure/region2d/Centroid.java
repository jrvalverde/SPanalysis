/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Centroid
/*     */   extends RegionAnalyzer2D<Point2D>
/*     */ {
/*     */   public static final Point2D[] centroids(ImageProcessor labelImage, int[] labels, Calibration calib) {
/*  45 */     return (new Centroid()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[][] centroids(ImageProcessor labelImage, int[] labels) {
/*  65 */     int nLabels = labels.length;
/*  66 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/*  69 */     int[] counts = new int[nLabels];
/*  70 */     double[][] centroids = new double[nLabels][2];
/*     */ 
/*     */     
/*  73 */     int sizeX = labelImage.getWidth();
/*  74 */     int sizeY = labelImage.getHeight();
/*  75 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/*  77 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/*  79 */         int label = (int)labelImage.getf(x, y);
/*  80 */         if (label != 0)
/*     */         {
/*     */ 
/*     */           
/*  84 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */             
/*  87 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*  88 */             centroids[index][0] = centroids[index][0] + x;
/*  89 */             centroids[index][1] = centroids[index][1] + y;
/*  90 */             counts[index] = counts[index] + 1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*  95 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/*  97 */       centroids[i][0] = centroids[i][0] / counts[i];
/*  98 */       centroids[i][1] = centroids[i][1] / counts[i];
/*     */     } 
/*     */     
/* 101 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Point2D> map) {
/* 130 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 134 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 137 */       Point2D point = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 140 */       table.incrementCounter();
/* 141 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 144 */       table.addValue("Centroid.X", point.getX());
/* 145 */       table.addValue("Centroid.Y", point.getY()); }
/*     */ 
/*     */     
/* 148 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/* 166 */     if (image == null) {
/* 167 */       return null;
/*     */     }
/*     */     
/* 170 */     int width = image.getWidth();
/* 171 */     int height = image.getHeight();
/*     */ 
/*     */     
/* 174 */     double sx = 1.0D, sy = 1.0D;
/* 175 */     double ox = 0.0D, oy = 0.0D;
/* 176 */     if (calib != null) {
/*     */       
/* 178 */       sx = calib.pixelWidth;
/* 179 */       sy = calib.pixelHeight;
/* 180 */       ox = calib.xOrigin;
/* 181 */       oy = calib.yOrigin;
/*     */     } 
/*     */ 
/*     */     
/* 185 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 188 */     int nLabels = labels.length;
/* 189 */     int[] counts = new int[nLabels];
/* 190 */     double[] cx = new double[nLabels];
/* 191 */     double[] cy = new double[nLabels];
/*     */     
/* 193 */     fireStatusChanged(this, "Compute centroids");
/*     */     
/* 195 */     for (int y = 0; y < height; y++) {
/*     */       
/* 197 */       for (int x = 0; x < width; x++) {
/*     */         
/* 199 */         int label = (int)image.getf(x, y);
/* 200 */         if (label != 0) {
/*     */ 
/*     */           
/* 203 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 204 */           cx[index] = cx[index] + x * sx;
/* 205 */           cy[index] = cy[index] + y * sy;
/* 206 */           counts[index] = counts[index] + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 211 */     Point2D[] points = new Point2D[nLabels];
/* 212 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 214 */       points[i] = new Point2D.Double(cx[i] / counts[i] + ox, cy[i] / counts[i] + oy);
/*     */     }
/*     */     
/* 217 */     return points;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/Centroid.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */