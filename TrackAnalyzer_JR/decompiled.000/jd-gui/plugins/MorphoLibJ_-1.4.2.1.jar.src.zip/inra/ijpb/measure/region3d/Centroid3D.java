/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Centroid3D
/*     */   extends RegionAnalyzer3D<Point3D>
/*     */ {
/*     */   public static final Point3D[] centroids(ImageStack labelImage, int[] labels, Calibration calib) {
/*  41 */     return (new Centroid3D()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[][] centroids(ImageStack labelImage, int[] labels) {
/*  62 */     int nLabels = labels.length;
/*  63 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/*  66 */     int[] counts = new int[nLabels];
/*  67 */     double[][] centroids = new double[nLabels][3];
/*     */ 
/*     */     
/*  70 */     int sizeX = labelImage.getWidth();
/*  71 */     int sizeY = labelImage.getHeight();
/*  72 */     int sizeZ = labelImage.getSize();
/*     */     
/*  74 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/*  76 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/*  78 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/*  80 */           int label = (int)labelImage.getVoxel(x, y, z);
/*  81 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/*  85 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */               
/*  88 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*  89 */               centroids[index][0] = centroids[index][0] + x;
/*  90 */               centroids[index][1] = centroids[index][1] + y;
/*  91 */               centroids[index][2] = centroids[index][2] + z;
/*  92 */               counts[index] = counts[index] + 1;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 100 */       centroids[i][0] = centroids[i][0] / counts[i];
/* 101 */       centroids[i][1] = centroids[i][1] / counts[i];
/* 102 */       centroids[i][2] = centroids[i][2] / counts[i];
/*     */     } 
/*     */     
/* 105 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Point3D> map) {
/* 132 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 136 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 139 */       Point3D point = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 142 */       table.incrementCounter();
/* 143 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 146 */       table.addValue("Centroid.X", point.getX());
/* 147 */       table.addValue("Centroid.Y", point.getY());
/* 148 */       table.addValue("Centroid.Z", point.getZ()); }
/*     */ 
/*     */     
/* 151 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point3D[] analyzeRegions(ImageStack image, int[] labels, Calibration calib) {
/* 169 */     if (image == null) {
/* 170 */       return null;
/*     */     }
/*     */     
/* 173 */     int sizeX = image.getWidth();
/* 174 */     int sizeY = image.getHeight();
/* 175 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 178 */     double sx = 1.0D, sy = 1.0D, sz = 1.0D;
/* 179 */     double ox = 0.0D, oy = 0.0D, oz = 0.0D;
/* 180 */     if (calib != null) {
/*     */       
/* 182 */       sx = calib.pixelWidth;
/* 183 */       sy = calib.pixelHeight;
/* 184 */       sz = calib.pixelDepth;
/* 185 */       ox = calib.xOrigin;
/* 186 */       oy = calib.yOrigin;
/* 187 */       oz = calib.zOrigin;
/*     */     } 
/*     */ 
/*     */     
/* 191 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 194 */     int nLabels = labels.length;
/* 195 */     int[] counts = new int[nLabels];
/* 196 */     double[] cx = new double[nLabels];
/* 197 */     double[] cy = new double[nLabels];
/* 198 */     double[] cz = new double[nLabels];
/*     */     
/* 200 */     fireStatusChanged(this, "Compute centroids");
/*     */     
/* 202 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 204 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 206 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 208 */           int label = (int)image.getVoxel(x, y, z);
/* 209 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/* 213 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */               
/* 216 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 217 */               cx[index] = cx[index] + x * sx;
/* 218 */               cy[index] = cy[index] + y * sy;
/* 219 */               cz[index] = cz[index] + z * sz;
/* 220 */               counts[index] = counts[index] + 1;
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 225 */     Point3D[] points = new Point3D[nLabels];
/* 226 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 228 */       points[i] = new Point3D(cx[i] / counts[i] + ox, cy[i] / counts[i] + oy, cz[i] / counts[i] + oz);
/*     */     }
/*     */     
/* 231 */     return points;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/Centroid3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */