/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumes2DUtils
/*     */ {
/*     */   public static final double[] areaLut(Calibration calib) {
/*  21 */     double[] lut = { 0.0D, 0.25D, 0.25D, 0.5D, 0.25D, 0.5D, 0.5D, 0.75D, 0.25D, 0.5D, 0.5D, 0.75D, 0.5D, 0.75D, 0.75D, 1.0D };
/*     */ 
/*     */     
/*  24 */     double pixelArea = calib.pixelWidth * calib.pixelHeight;
/*  25 */     for (int i = 0; i < lut.length; i++)
/*     */     {
/*  27 */       lut[i] = lut[i] * pixelArea;
/*     */     }
/*     */     
/*  30 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] perimeterLut(Calibration calib, int nDirs) {
/*  50 */     double d1 = calib.pixelWidth;
/*  51 */     double d2 = calib.pixelHeight;
/*  52 */     double d12 = Math.hypot(d1, d2);
/*  53 */     double area = d1 * d2;
/*     */ 
/*     */ 
/*     */     
/*  57 */     double[] weights = null;
/*  58 */     if (nDirs == 4)
/*     */     {
/*  60 */       weights = computeDirectionWeightsD4(d1, d2);
/*     */     }
/*     */ 
/*     */     
/*  64 */     int nConfigs = 16;
/*  65 */     double[] tab = new double[16];
/*     */ 
/*     */     
/*  68 */     for (int i = 0; i < 16; i++) {
/*     */ 
/*     */       
/*  71 */       boolean[][] im = new boolean[2][2];
/*  72 */       im[0][0] = ((i & 0x1) > 0);
/*  73 */       im[0][1] = ((i & 0x2) > 0);
/*  74 */       im[1][0] = ((i & 0x4) > 0);
/*  75 */       im[1][1] = ((i & 0x8) > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       for (int y = 0; y < 2; y++) {
/*     */         
/*  86 */         for (int x = 0; x < 2; x++) {
/*     */           
/*  88 */           if (im[y][x]) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  93 */             double ke1 = im[y][1 - x] ? 0.0D : (area / d1 / 2.0D);
/*  94 */             double ke2 = im[1 - y][x] ? 0.0D : (area / d2 / 2.0D);
/*     */             
/*  96 */             if (nDirs == 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 101 */               tab[i] = tab[i] + (ke1 + ke2) / 4.0D;
/*     */             
/*     */             }
/* 104 */             else if (nDirs == 4) {
/*     */ 
/*     */               
/* 107 */               double ke12 = im[1 - y][1 - x] ? 0.0D : (area / d12 / 2.0D);
/*     */ 
/*     */ 
/*     */               
/* 111 */               tab[i] = tab[i] + ke1 / 2.0D * weights[0] + ke2 / 2.0D * 
/* 112 */                 weights[1] + ke12 * weights[2];
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 118 */       tab[i] = tab[i] * Math.PI;
/*     */     } 
/*     */     
/* 121 */     return tab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] computeDirectionWeightsD4(double dx, double dy) {
/* 137 */     double theta = Math.atan2(dy, dx);
/*     */ 
/*     */     
/* 140 */     double alpha1 = theta / Math.PI;
/*     */ 
/*     */     
/* 143 */     double alpha2 = (1.5707963267948966D - theta) / Math.PI;
/*     */ 
/*     */     
/* 146 */     double alpha34 = 0.25D;
/*     */ 
/*     */     
/* 149 */     return new double[] { alpha1, alpha2, alpha34, alpha34 };
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double[] computeCircularities(IntrinsicVolumesAnalyzer2D.Result[] morphos) {
/* 154 */     int n = morphos.length;
/* 155 */     double[] circularities = new double[n];
/* 156 */     for (int i = 0; i < n; i++)
/*     */     {
/* 158 */       circularities[i] = morphos[i].circularity();
/*     */     }
/* 160 */     return circularities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] eulerNumberLut(int conn) {
/* 175 */     switch (conn) {
/*     */       
/*     */       case 4:
/* 178 */         return eulerNumberLutC4();
/*     */       case 8:
/* 180 */         return eulerNumberLutC8();
/*     */     } 
/* 182 */     throw new IllegalArgumentException("Connectivity must be 4 or 8, not " + conn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] eulerNumberLutC4() {
/* 188 */     return new double[] { 
/* 189 */         0.0D, 0.25D, 0.25D, 0.0D, 0.25D, 0.0D, 0.5D, -0.25D, 
/* 190 */         0.25D, 0.5D, 0.0D, -0.25D, 0.0D, -0.25D, -0.25D, 0.0D };
/*     */   }
/*     */ 
/*     */   
/*     */   private static final double[] eulerNumberLutC8() {
/* 195 */     return new double[] { 
/* 196 */         0.0D, 0.25D, 0.25D, 0.0D, 0.25D, 0.0D, -0.5D, -0.25D, 
/* 197 */         0.25D, -0.5D, 0.0D, -0.25D, 0.0D, -0.25D, -0.25D, 0.0D };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] eulerNumberIntLut(int conn) {
/* 212 */     switch (conn) {
/*     */       
/*     */       case 4:
/* 215 */         return eulerNumberIntLutC4();
/*     */       case 8:
/* 217 */         return eulerNumberIntLutC8();
/*     */     } 
/* 219 */     throw new IllegalArgumentException("Connectivity must be 4 or 8, not " + conn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int[] eulerNumberIntLutC4() {
/* 225 */     return new int[] { 
/* 226 */         0, 1, 1, 1, 2, -1, 
/* 227 */         1, 2, -1, -1, -1 };
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int[] eulerNumberIntLutC8() {
/* 232 */     return new int[] { 
/* 233 */         0, 1, 1, 1, -2, -1, 
/* 234 */         1, -2, -1, -1, -1 };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/IntrinsicVolumes2DUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */