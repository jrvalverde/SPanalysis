/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.label.RegionAdjacencyGraph;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntensityMeasures
/*     */   extends LabeledVoxelsMeasure
/*     */ {
/*  44 */   Set<RegionAdjacencyGraph.LabelPair> adjList = null;
/*     */   
/*  46 */   ArrayList<Double>[] neighborVoxels = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   double[][] mode = null;
/*     */   
/*  53 */   double[] max = null;
/*     */   
/*  55 */   double[] min = null;
/*     */   
/*  57 */   double[] mean = null;
/*     */   
/*  59 */   double[] neighborsMean = null;
/*     */   
/*  61 */   HashMap<Double, Integer>[] histogramPerLabel = null;
/*     */   
/*  63 */   ImagePlus labelImage = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntensityMeasures(ImagePlus inputImage, ImagePlus labelImage) {
/*  76 */     super(inputImage, labelImage);
/*  77 */     this.labelImage = labelImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getMean() {
/*  88 */     this.mean = meanPerLabel();
/*     */ 
/*     */     
/*  91 */     ResultsTable table = new ResultsTable();
/*  92 */     for (int i = 0; i < this.mean.length; i++) {
/*  93 */       table.incrementCounter();
/*  94 */       table.addLabel(Integer.toString(this.labels[i]));
/*  95 */       table.addValue("Mean", this.mean[i]);
/*     */     } 
/*     */     
/*  98 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] meanPerLabel() {
/* 106 */     double[] mean = new double[this.objectVoxels.length];
/*     */ 
/*     */     
/* 109 */     for (int i = 0; i < mean.length; i++) {
/*     */       
/* 111 */       mean[i] = 0.0D;
/* 112 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double v = ((Double)iterator.next()).doubleValue();
/* 113 */         mean[i] = mean[i] + v; }
/* 114 */        mean[i] = mean[i] / this.objectVoxels[i].size();
/*     */     } 
/* 116 */     return mean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsMean() {
/* 125 */     this.neighborsMean = neighborsMeanPerLabel();
/*     */ 
/*     */     
/* 128 */     ResultsTable table = new ResultsTable();
/* 129 */     for (int i = 0; i < this.neighborsMean.length; i++) {
/* 130 */       table.incrementCounter();
/* 131 */       table.addLabel(Integer.toString(this.labels[i]));
/* 132 */       table.addValue("NeighborsMean", this.neighborsMean[i]);
/*     */     } 
/*     */     
/* 135 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] neighborsMeanPerLabel() {
/* 144 */     if (this.adjList == null) {
/* 145 */       this.adjList = RegionAdjacencyGraph.computeAdjacencies(this.labelImage);
/*     */     }
/* 147 */     if (this.mean == null) {
/* 148 */       this.mean = meanPerLabel();
/*     */     }
/* 150 */     int numLabels = this.objectVoxels.length;
/*     */     
/* 152 */     double[] neighborsMean = new double[numLabels];
/* 153 */     double[] neighborsNumVox = new double[numLabels];
/*     */ 
/*     */     
/* 156 */     for (RegionAdjacencyGraph.LabelPair pair : this.adjList) {
/*     */ 
/*     */       
/* 159 */       int ind1 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label1))).intValue();
/* 160 */       int ind2 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label2))).intValue();
/*     */       
/* 162 */       neighborsMean[ind1] = neighborsMean[ind1] + this.mean[ind2] * this.objectVoxels[ind2].size();
/* 163 */       neighborsMean[ind2] = neighborsMean[ind2] + this.mean[ind1] * this.objectVoxels[ind1].size();
/*     */       
/* 165 */       neighborsNumVox[ind1] = neighborsNumVox[ind1] + this.objectVoxels[ind2].size();
/* 166 */       neighborsNumVox[ind2] = neighborsNumVox[ind2] + this.objectVoxels[ind1].size();
/*     */     } 
/*     */ 
/*     */     
/* 170 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 172 */       if (neighborsNumVox[i] > 0.0D) {
/* 173 */         neighborsMean[i] = neighborsMean[i] / neighborsNumVox[i];
/*     */       } else {
/* 175 */         neighborsMean[i] = Double.NaN;
/*     */       } 
/* 177 */     }  return neighborsMean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getMedian() {
/* 186 */     int numLabels = this.objectVoxels.length;
/*     */     
/* 188 */     double[] median = new double[numLabels];
/*     */ 
/*     */     
/* 191 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 193 */       Collections.sort(this.objectVoxels[i]);
/* 194 */       median[i] = ((Double)this.objectVoxels[i].get(this.objectVoxels[i].size() / 2)).doubleValue();
/*     */     } 
/*     */ 
/*     */     
/* 198 */     ResultsTable table = new ResultsTable();
/* 199 */     for (int j = 0; j < numLabels; j++) {
/* 200 */       table.incrementCounter();
/* 201 */       table.addLabel(Integer.toString(this.labels[j]));
/* 202 */       table.addValue("Median", median[j]);
/*     */     } 
/*     */     
/* 205 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsMedian() {
/* 214 */     if (this.neighborVoxels == null) {
/* 215 */       this.neighborVoxels = computeNeighborVoxels();
/*     */     }
/* 217 */     int numLabels = this.objectVoxels.length;
/* 218 */     double[] median = new double[numLabels];
/*     */ 
/*     */     
/* 221 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 223 */       Collections.sort(this.neighborVoxels[i]);
/* 224 */       if (this.neighborVoxels[i].size() > 0) {
/* 225 */         median[i] = ((Double)this.neighborVoxels[i].get(this.neighborVoxels[i].size() / 2)).doubleValue();
/*     */       } else {
/* 227 */         median[i] = Double.NaN;
/*     */       } 
/*     */     } 
/*     */     
/* 231 */     ResultsTable table = new ResultsTable();
/* 232 */     for (int j = 0; j < numLabels; j++) {
/* 233 */       table.incrementCounter();
/* 234 */       table.addLabel(Integer.toString(this.labels[j]));
/* 235 */       table.addValue("NeighborsMedian", median[j]);
/*     */     } 
/*     */     
/* 238 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getMode() {
/* 247 */     int numLabels = this.objectVoxels.length;
/* 248 */     double[] mode = new double[numLabels];
/*     */ 
/*     */     
/* 251 */     if (this.histogramPerLabel == null) {
/* 252 */       this.histogramPerLabel = getHistogramPerLabel();
/*     */     }
/*     */     
/* 255 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 257 */       int max = 1;
/* 258 */       double temp = ((Double)this.objectVoxels[i].get(0)).doubleValue();
/*     */       
/* 260 */       for (Map.Entry<Double, Integer> entry : this.histogramPerLabel[i].entrySet()) {
/*     */         
/* 262 */         if (((Integer)entry.getValue()).intValue() > max) {
/*     */           
/* 264 */           max = ((Integer)entry.getValue()).intValue();
/* 265 */           temp = ((Double)entry.getKey()).doubleValue();
/*     */         } 
/*     */       } 
/* 268 */       mode[i] = temp;
/*     */     } 
/*     */ 
/*     */     
/* 272 */     ResultsTable table = new ResultsTable();
/* 273 */     for (int j = 0; j < numLabels; j++) {
/* 274 */       table.incrementCounter();
/* 275 */       table.addLabel(Integer.toString(this.labels[j]));
/* 276 */       table.addValue("Mode", mode[j]);
/*     */     } 
/*     */     
/* 279 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<Double, Integer>[] getHistogramPerLabel() {
/* 288 */     HashMap[] hm = new HashMap[this.objectVoxels.length];
/* 289 */     for (int i = 0; i < this.objectVoxels.length; i++) {
/*     */       
/* 291 */       hm[i] = new HashMap<Object, Object>();
/*     */       
/* 293 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double val = ((Double)iterator.next()).doubleValue();
/*     */         
/* 295 */         if (hm[i].get(Double.valueOf(val)) != null) {
/*     */           
/* 297 */           int count = ((Integer)hm[i].get(Double.valueOf(val))).intValue();
/* 298 */           count++;
/* 299 */           hm[i].put(Double.valueOf(val), Integer.valueOf(count));
/*     */           continue;
/*     */         } 
/* 302 */         hm[i].put(Double.valueOf(val), Integer.valueOf(1)); }
/*     */     
/*     */     } 
/* 305 */     return (HashMap<Double, Integer>[])hm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsMode() {
/* 315 */     if (this.histogramPerLabel == null) {
/* 316 */       this.histogramPerLabel = getHistogramPerLabel();
/*     */     }
/* 318 */     int numLabels = this.objectVoxels.length;
/* 319 */     double[] mode = new double[numLabels];
/*     */ 
/*     */     
/* 322 */     if (this.adjList == null) {
/* 323 */       this.adjList = RegionAdjacencyGraph.computeAdjacencies(this.labelImage);
/*     */     }
/*     */     
/* 326 */     HashMap[] hm = new HashMap[numLabels]; int i;
/* 327 */     for (i = 0; i < numLabels; i++) {
/* 328 */       hm[i] = new HashMap<Object, Object>();
/*     */     }
/* 330 */     for (RegionAdjacencyGraph.LabelPair pair : this.adjList) {
/*     */ 
/*     */       
/* 333 */       int ind1 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label1))).intValue();
/* 334 */       int ind2 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label2))).intValue();
/*     */ 
/*     */       
/* 337 */       for (Map.Entry<Double, Integer> entry : this.histogramPerLabel[ind1].entrySet()) {
/*     */         
/* 339 */         double val = ((Double)entry.getKey()).doubleValue();
/* 340 */         int count = ((Integer)entry.getValue()).intValue();
/* 341 */         if (hm[ind2].get(Double.valueOf(val)) != null) {
/* 342 */           hm[ind2].put(Double.valueOf(val), Integer.valueOf(count + ((Integer)hm[ind2].get(Double.valueOf(val))).intValue())); continue;
/*     */         } 
/* 344 */         hm[ind2].put(Double.valueOf(val), Integer.valueOf(count));
/*     */       } 
/*     */       
/* 347 */       for (Map.Entry<Double, Integer> entry : this.histogramPerLabel[ind2].entrySet()) {
/*     */         
/* 349 */         double val = ((Double)entry.getKey()).doubleValue();
/* 350 */         int count = ((Integer)entry.getValue()).intValue();
/* 351 */         if (hm[ind1].get(Double.valueOf(val)) != null) {
/* 352 */           hm[ind1].put(Double.valueOf(val), Integer.valueOf(count + ((Integer)hm[ind1].get(Double.valueOf(val))).intValue())); continue;
/*     */         } 
/* 354 */         hm[ind1].put(Double.valueOf(val), Integer.valueOf(count));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 359 */     for (i = 0; i < numLabels; i++) {
/*     */       
/* 361 */       int max = 1;
/* 362 */       double temp = Double.NaN;
/*     */       
/* 364 */       for (Map.Entry<Double, Integer> entry : hm[i].entrySet()) {
/*     */         
/* 366 */         if (((Integer)entry.getValue()).intValue() > max) {
/*     */           
/* 368 */           max = ((Integer)entry.getValue()).intValue();
/* 369 */           temp = ((Double)entry.getKey()).doubleValue();
/*     */         } 
/*     */       } 
/* 372 */       mode[i] = temp;
/*     */     } 
/*     */ 
/*     */     
/* 376 */     ResultsTable table = new ResultsTable();
/* 377 */     for (int j = 0; j < numLabels; j++) {
/*     */       
/* 379 */       table.incrementCounter();
/* 380 */       table.addLabel(Integer.toString(this.labels[j]));
/* 381 */       table.addValue("NeighborsMode", mode[j]);
/*     */     } 
/*     */     
/* 384 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getSkewness() {
/* 393 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */     
/* 396 */     if (this.mean == null) {
/* 397 */       this.mean = meanPerLabel();
/*     */     }
/* 399 */     double[] skewness = new double[numLabels];
/*     */ 
/*     */     
/* 402 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 404 */       double voxelCount = this.objectVoxels[i].size();
/* 405 */       double sum2 = 0.0D, sum3 = 0.0D;
/* 406 */       for (int k = 0; k < voxelCount; k++) {
/*     */         
/* 408 */         double v = ((Double)this.objectVoxels[i].get(k)).doubleValue() + Double.MIN_VALUE;
/* 409 */         double v2 = v * v;
/* 410 */         sum2 += v2;
/* 411 */         sum3 += v * v2;
/*     */       } 
/* 413 */       double mean2 = this.mean[i] * this.mean[i];
/* 414 */       double variance = sum2 / voxelCount - mean2;
/* 415 */       double sDeviation = Math.sqrt(variance);
/* 416 */       skewness[i] = (Double.compare(variance, 0.0D) == 0) ? 0.0D : (((
/* 417 */         sum3 - 3.0D * this.mean[i] * sum2) / voxelCount + 
/* 418 */         2.0D * this.mean[i] * mean2) / variance * sDeviation);
/*     */     } 
/*     */ 
/*     */     
/* 422 */     ResultsTable table = new ResultsTable();
/* 423 */     for (int j = 0; j < numLabels; j++) {
/* 424 */       table.incrementCounter();
/* 425 */       table.addLabel(Integer.toString(this.labels[j]));
/* 426 */       table.addValue("Skewness", skewness[j]);
/*     */     } 
/*     */     
/* 429 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsSkewness() {
/* 438 */     if (this.neighborVoxels == null) {
/* 439 */       this.neighborVoxels = computeNeighborVoxels();
/*     */     }
/* 441 */     int numLabels = this.objectVoxels.length;
/* 442 */     double[] skewness = new double[numLabels];
/*     */ 
/*     */     
/* 445 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 447 */       double voxelCount = this.neighborVoxels[i].size();
/* 448 */       if (voxelCount > 0.0D) {
/*     */         
/* 450 */         double sum2 = 0.0D, sum3 = 0.0D;
/* 451 */         double mean = 0.0D;
/* 452 */         for (int k = 0; k < voxelCount; k++) {
/*     */           
/* 454 */           mean += ((Double)this.neighborVoxels[i].get(k)).doubleValue();
/* 455 */           double v = ((Double)this.neighborVoxels[i].get(k)).doubleValue() + Double.MIN_VALUE;
/* 456 */           double v2 = v * v;
/* 457 */           sum2 += v2;
/* 458 */           sum3 += v * v2;
/*     */         } 
/* 460 */         mean /= voxelCount;
/* 461 */         double mean2 = mean * mean;
/* 462 */         double variance = sum2 / voxelCount - mean2;
/* 463 */         double sDeviation = Math.sqrt(variance);
/* 464 */         skewness[i] = (Double.compare(variance, 0.0D) == 0) ? 0.0D : (((
/* 465 */           sum3 - 3.0D * mean * sum2) / voxelCount + 
/* 466 */           2.0D * mean * mean2) / variance * sDeviation);
/*     */       } else {
/*     */         
/* 469 */         skewness[i] = Double.NaN;
/*     */       } 
/*     */     } 
/*     */     
/* 473 */     ResultsTable table = new ResultsTable();
/* 474 */     for (int j = 0; j < numLabels; j++) {
/*     */       
/* 476 */       table.incrementCounter();
/* 477 */       table.addLabel(Integer.toString(this.labels[j]));
/* 478 */       table.addValue("NeighborsSkewness", skewness[j]);
/*     */     } 
/*     */     
/* 481 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<Double>[] computeNeighborVoxels() {
/* 489 */     if (this.adjList == null) {
/* 490 */       this.adjList = RegionAdjacencyGraph.computeAdjacencies(this.labelImage);
/*     */     }
/* 492 */     int numLabels = this.labels.length;
/*     */ 
/*     */ 
/*     */     
/* 496 */     ArrayList[] neighborVoxels = new ArrayList[numLabels];
/* 497 */     for (int i = 0; i < neighborVoxels.length; i++) {
/* 498 */       neighborVoxels[i] = new ArrayList();
/*     */     }
/*     */     
/* 501 */     for (RegionAdjacencyGraph.LabelPair pair : this.adjList) {
/*     */ 
/*     */       
/* 504 */       int ind1 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label1))).intValue();
/* 505 */       int ind2 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label2))).intValue();
/*     */       
/* 507 */       neighborVoxels[ind1].addAll(this.objectVoxels[ind2]);
/* 508 */       neighborVoxels[ind2].addAll(this.objectVoxels[ind1]);
/*     */     } 
/* 510 */     return (ArrayList<Double>[])neighborVoxels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getKurtosis() {
/* 519 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */     
/* 522 */     if (this.mean == null) {
/* 523 */       this.mean = meanPerLabel();
/*     */     }
/* 525 */     double[] kurtosis = new double[numLabels];
/*     */ 
/*     */     
/* 528 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 530 */       double voxelCount = this.objectVoxels[i].size();
/* 531 */       double sum2 = 0.0D, sum3 = 0.0D, sum4 = 0.0D;
/* 532 */       for (int k = 0; k < voxelCount; k++) {
/*     */         
/* 534 */         double v = ((Double)this.objectVoxels[i].get(k)).doubleValue() + Double.MIN_VALUE;
/* 535 */         double v2 = v * v;
/* 536 */         sum2 += v2;
/* 537 */         sum3 += v * v2;
/* 538 */         sum4 += v2 * v2;
/*     */       } 
/*     */       
/* 541 */       double mean2 = this.mean[i] * this.mean[i];
/* 542 */       double variance = sum2 / voxelCount - mean2;
/* 543 */       kurtosis[i] = (Double.compare(variance, 0.0D) == 0) ? -1.2D : (((
/* 544 */         sum4 - 4.0D * this.mean[i] * sum3 + 6.0D * mean2 * sum2) / 
/* 545 */         voxelCount - 3.0D * mean2 * mean2) / 
/* 546 */         variance * variance - 3.0D);
/*     */     } 
/*     */ 
/*     */     
/* 550 */     ResultsTable table = new ResultsTable();
/* 551 */     for (int j = 0; j < numLabels; j++) {
/* 552 */       table.incrementCounter();
/* 553 */       table.addLabel(Integer.toString(this.labels[j]));
/* 554 */       table.addValue("Kurtosis", kurtosis[j]);
/*     */     } 
/*     */     
/* 557 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsKurtosis() {
/* 566 */     if (this.neighborVoxels == null)
/* 567 */       this.neighborVoxels = computeNeighborVoxels(); 
/* 568 */     int numLabels = this.objectVoxels.length;
/* 569 */     double[] kurtosis = new double[numLabels];
/*     */ 
/*     */     
/* 572 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 574 */       double voxelCount = this.neighborVoxels[i].size();
/* 575 */       if (voxelCount > 0.0D) {
/*     */         
/* 577 */         double sum2 = 0.0D, sum3 = 0.0D, sum4 = 0.0D;
/* 578 */         double mean = 0.0D;
/* 579 */         for (int k = 0; k < voxelCount; k++) {
/*     */           
/* 581 */           mean += ((Double)this.neighborVoxels[i].get(k)).doubleValue();
/* 582 */           double v = ((Double)this.neighborVoxels[i].get(k)).doubleValue() + Double.MIN_VALUE;
/* 583 */           double v2 = v * v;
/* 584 */           sum2 += v2;
/* 585 */           sum3 += v * v2;
/* 586 */           sum4 += v2 * v2;
/*     */         } 
/* 588 */         mean /= voxelCount;
/* 589 */         double mean2 = mean * mean;
/* 590 */         double variance = sum2 / voxelCount - mean2;
/* 591 */         kurtosis[i] = (Double.compare(variance, 0.0D) == 0) ? -1.2D : (((
/* 592 */           sum4 - 4.0D * mean * sum3 + 6.0D * mean2 * sum2) / 
/* 593 */           voxelCount - 3.0D * mean2 * mean2) / 
/* 594 */           variance * variance - 3.0D);
/*     */       } else {
/*     */         
/* 597 */         kurtosis[i] = Double.NaN;
/*     */       } 
/*     */     } 
/*     */     
/* 601 */     ResultsTable table = new ResultsTable();
/* 602 */     for (int j = 0; j < numLabels; j++) {
/*     */       
/* 604 */       table.incrementCounter();
/* 605 */       table.addLabel(Integer.toString(this.labels[j]));
/* 606 */       table.addValue("NeighborsKurtosis", kurtosis[j]);
/*     */     } 
/*     */     
/* 609 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getStdDev() {
/* 618 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */ 
/*     */     
/* 622 */     if (this.mean == null)
/* 623 */       this.mean = meanPerLabel(); 
/* 624 */     double[] sd = new double[numLabels];
/*     */ 
/*     */     
/* 627 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 629 */       sd[i] = 0.0D;
/*     */       
/* 631 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double v = ((Double)iterator.next()).doubleValue();
/*     */         
/* 633 */         double diff = v - this.mean[i];
/* 634 */         sd[i] = sd[i] + diff * diff; }
/*     */       
/* 636 */       sd[i] = sd[i] / this.objectVoxels[i].size();
/* 637 */       sd[i] = Math.sqrt(sd[i]);
/*     */     } 
/*     */ 
/*     */     
/* 641 */     ResultsTable table = new ResultsTable();
/* 642 */     for (int j = 0; j < numLabels; j++) {
/* 643 */       table.incrementCounter();
/* 644 */       table.addLabel(Integer.toString(this.labels[j]));
/* 645 */       table.addValue("StdDev", sd[j]);
/*     */     } 
/*     */     
/* 648 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsStdDev() {
/* 658 */     if (this.neighborsMean == null) {
/* 659 */       this.neighborsMean = neighborsMeanPerLabel();
/*     */     }
/* 661 */     if (this.neighborVoxels == null)
/* 662 */       this.neighborVoxels = computeNeighborVoxels(); 
/* 663 */     int numLabels = this.neighborsMean.length;
/*     */     
/* 665 */     double[] sd = new double[numLabels];
/*     */ 
/*     */     
/* 668 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 670 */       if (this.neighborVoxels[i].size() > 0) {
/*     */         
/* 672 */         for (Iterator<Double> iterator = this.neighborVoxels[i].iterator(); iterator.hasNext(); ) { double v = ((Double)iterator.next()).doubleValue();
/*     */           
/* 674 */           double diff = v - this.neighborsMean[i];
/* 675 */           sd[i] = sd[i] + diff * diff; }
/*     */         
/* 677 */         sd[i] = sd[i] / this.neighborVoxels[i].size();
/* 678 */         sd[i] = Math.sqrt(sd[i]);
/*     */       } else {
/*     */         
/* 681 */         sd[i] = Double.NaN;
/*     */       } 
/*     */     } 
/*     */     
/* 685 */     ResultsTable table = new ResultsTable();
/* 686 */     for (int j = 0; j < numLabels; j++) {
/* 687 */       table.incrementCounter();
/* 688 */       table.addLabel(Integer.toString(this.labels[j]));
/* 689 */       table.addValue("NeighborsStdDev", sd[j]);
/*     */     } 
/*     */     
/* 692 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getMax() {
/* 701 */     this.max = maxPerLabel();
/*     */ 
/*     */     
/* 704 */     ResultsTable table = new ResultsTable();
/* 705 */     for (int i = 0; i < this.objectVoxels.length; i++) {
/* 706 */       table.incrementCounter();
/* 707 */       table.addLabel(Integer.toString(this.labels[i]));
/* 708 */       table.addValue("Max", this.max[i]);
/*     */     } 
/*     */     
/* 711 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] maxPerLabel() {
/* 719 */     int numLabels = this.objectVoxels.length;
/* 720 */     double[] max = new double[numLabels];
/*     */ 
/*     */     
/* 723 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 725 */       max[i] = Double.MIN_VALUE;
/* 726 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double v = ((Double)iterator.next()).doubleValue();
/* 727 */         if (v > max[i])
/* 728 */           max[i] = v;  }
/*     */     
/* 730 */     }  return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsMax() {
/* 740 */     if (this.adjList == null) {
/* 741 */       this.adjList = RegionAdjacencyGraph.computeAdjacencies(this.labelImage);
/*     */     }
/* 743 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */ 
/*     */     
/* 747 */     if (this.max == null) {
/* 748 */       this.max = maxPerLabel();
/*     */     }
/*     */     
/* 751 */     double[] adjacentMax = new double[numLabels];
/* 752 */     for (int i = 0; i < numLabels; i++) {
/* 753 */       adjacentMax[i] = Double.NaN;
/*     */     }
/*     */     
/* 756 */     for (RegionAdjacencyGraph.LabelPair pair : this.adjList) {
/*     */ 
/*     */       
/* 759 */       int ind1 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label1))).intValue();
/* 760 */       int ind2 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label2))).intValue();
/*     */ 
/*     */       
/* 763 */       if (Double.isNaN(adjacentMax[ind1]))
/* 764 */         adjacentMax[ind1] = Double.MIN_VALUE; 
/* 765 */       if (Double.isNaN(adjacentMax[ind2])) {
/* 766 */         adjacentMax[ind2] = Double.MIN_VALUE;
/*     */       }
/*     */ 
/*     */       
/* 770 */       if (this.max[ind2] > adjacentMax[ind1]) {
/* 771 */         adjacentMax[ind1] = this.max[ind2];
/*     */       }
/* 773 */       if (this.max[ind1] > adjacentMax[ind2]) {
/* 774 */         adjacentMax[ind2] = this.max[ind1];
/*     */       }
/*     */     } 
/*     */     
/* 778 */     ResultsTable table = new ResultsTable();
/* 779 */     for (int j = 0; j < numLabels; j++) {
/* 780 */       table.incrementCounter();
/* 781 */       table.addLabel(Integer.toString(this.labels[j]));
/* 782 */       table.addValue("NeighborsMax", adjacentMax[j]);
/*     */     } 
/*     */     
/* 785 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getMin() {
/* 794 */     this.min = minPerLabel();
/*     */ 
/*     */     
/* 797 */     ResultsTable table = new ResultsTable();
/* 798 */     for (int i = 0; i < this.objectVoxels.length; i++) {
/* 799 */       table.incrementCounter();
/* 800 */       table.addLabel(Integer.toString(this.labels[i]));
/* 801 */       table.addValue("Min", this.min[i]);
/*     */     } 
/*     */     
/* 804 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] minPerLabel() {
/* 812 */     int numLabels = this.objectVoxels.length;
/* 813 */     double[] min = new double[numLabels];
/*     */ 
/*     */     
/* 816 */     for (int i = 0; i < numLabels; i++) {
/*     */       
/* 818 */       min[i] = Double.MAX_VALUE;
/* 819 */       for (Iterator<Double> iterator = this.objectVoxels[i].iterator(); iterator.hasNext(); ) { double v = ((Double)iterator.next()).doubleValue();
/* 820 */         if (v < min[i])
/* 821 */           min[i] = v;  }
/*     */     
/* 823 */     }  return min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable getNeighborsMin() {
/* 833 */     if (this.adjList == null) {
/* 834 */       this.adjList = RegionAdjacencyGraph.computeAdjacencies(this.labelImage);
/*     */     }
/* 836 */     int numLabels = this.objectVoxels.length;
/*     */ 
/*     */ 
/*     */     
/* 840 */     if (this.min == null) {
/* 841 */       this.min = minPerLabel();
/*     */     }
/*     */     
/* 844 */     double[] adjacentMin = new double[numLabels];
/* 845 */     for (int i = 0; i < numLabels; i++) {
/* 846 */       adjacentMin[i] = Double.NaN;
/*     */     }
/*     */     
/* 849 */     for (RegionAdjacencyGraph.LabelPair pair : this.adjList) {
/*     */ 
/*     */       
/* 852 */       int ind1 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label1))).intValue();
/* 853 */       int ind2 = ((Integer)this.labelIndices.get(Integer.valueOf(pair.label2))).intValue();
/*     */ 
/*     */       
/* 856 */       if (Double.isNaN(adjacentMin[ind1]))
/* 857 */         adjacentMin[ind1] = Double.MAX_VALUE; 
/* 858 */       if (Double.isNaN(adjacentMin[ind2])) {
/* 859 */         adjacentMin[ind2] = Double.MAX_VALUE;
/*     */       }
/*     */ 
/*     */       
/* 863 */       if (this.min[ind2] < adjacentMin[ind1]) {
/* 864 */         adjacentMin[ind1] = this.min[ind2];
/*     */       }
/* 866 */       if (this.min[ind1] < adjacentMin[ind2]) {
/* 867 */         adjacentMin[ind2] = this.min[ind1];
/*     */       }
/*     */     } 
/*     */     
/* 871 */     ResultsTable table = new ResultsTable();
/* 872 */     for (int j = 0; j < numLabels; j++) {
/* 873 */       table.incrementCounter();
/* 874 */       table.addLabel(Integer.toString(this.labels[j]));
/* 875 */       table.addValue("NeighborsMin", adjacentMin[j]);
/*     */     } 
/*     */     
/* 878 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/IntensityMeasures.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */