/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.geometry.Ellipsoid;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region3d.BoundingBox3D;
/*     */ import inra.ijpb.measure.region3d.InertiaEllipsoid;
/*     */ import inra.ijpb.measure.region3d.LargestInscribedBall;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GeometricMeasures3D
/*     */ {
/*     */   @Deprecated
/*     */   public static final ResultsTable boundingBox(ImageStack labelImage) {
/*  97 */     Calibration calib = new Calibration();
/*  98 */     BoundingBox3D algo = new BoundingBox3D();
/*  99 */     return algo.createTable(algo.analyzeRegions(labelImage, calib));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[][] boundingBox(ImageStack labelImage, int[] labels) {
/* 115 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 118 */     int nLabels = labels.length;
/* 119 */     double[][] boxes = new double[nLabels][6];
/* 120 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 122 */       boxes[i][0] = Double.POSITIVE_INFINITY;
/* 123 */       boxes[i][1] = Double.NEGATIVE_INFINITY;
/* 124 */       boxes[i][2] = Double.POSITIVE_INFINITY;
/* 125 */       boxes[i][3] = Double.NEGATIVE_INFINITY;
/* 126 */       boxes[i][4] = Double.POSITIVE_INFINITY;
/* 127 */       boxes[i][5] = Double.NEGATIVE_INFINITY;
/*     */     } 
/*     */ 
/*     */     
/* 131 */     int sizeX = labelImage.getWidth();
/* 132 */     int sizeY = labelImage.getHeight();
/* 133 */     int sizeZ = labelImage.getSize();
/*     */ 
/*     */     
/* 136 */     IJ.showStatus("Compute Bounding boxes");
/* 137 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 139 */       IJ.showProgress(z, sizeZ);
/* 140 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 142 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 144 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 147 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/* 151 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */               
/* 155 */               int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 156 */               boxes[labelIndex][0] = Math.min(boxes[labelIndex][0], x);
/* 157 */               boxes[labelIndex][1] = Math.max(boxes[labelIndex][1], x);
/* 158 */               boxes[labelIndex][2] = Math.min(boxes[labelIndex][2], y);
/* 159 */               boxes[labelIndex][3] = Math.max(boxes[labelIndex][3], y);
/* 160 */               boxes[labelIndex][4] = Math.min(boxes[labelIndex][4], z);
/* 161 */               boxes[labelIndex][5] = Math.max(boxes[labelIndex][5], z);
/*     */             }  } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 166 */     IJ.showStatus("");
/* 167 */     return boxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable volume(ImageStack labelImage, double[] resol) {
/* 183 */     Calibration calib = new Calibration();
/* 184 */     calib.pixelWidth = resol[0];
/* 185 */     calib.pixelHeight = resol[1];
/* 186 */     calib.pixelDepth = resol[2];
/*     */     
/* 188 */     IJ.showStatus("Compute volume...");
/* 189 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 190 */     int nbLabels = labels.length;
/*     */     
/* 192 */     double[] volumes = IntrinsicVolumes3D.volumes(labelImage, labels, calib);
/*     */ 
/*     */     
/* 195 */     ResultsTable table = new ResultsTable();
/* 196 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 198 */       table.incrementCounter();
/* 199 */       table.addLabel(Integer.toString(labels[i]));
/* 200 */       table.addValue("Volume", volumes[i]);
/*     */     } 
/*     */     
/* 203 */     IJ.showStatus("");
/* 204 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] volume(ImageStack labelImage, int[] labels, double[] resol) {
/* 220 */     Calibration calib = new Calibration();
/* 221 */     calib.pixelWidth = resol[0];
/* 222 */     calib.pixelHeight = resol[1];
/* 223 */     calib.pixelDepth = resol[2];
/*     */     
/* 225 */     return IntrinsicVolumes3D.volumes(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] computeSphericity(double[] volumes, double[] surfaces) {
/* 253 */     return IntrinsicVolumes3D.sphericity(volumes, surfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ResultsTable surfaceArea(ImageStack labelImage, double[] resol, int nDirs) {
/* 278 */     Calibration calib = new Calibration();
/* 279 */     calib.pixelWidth = resol[0];
/* 280 */     calib.pixelHeight = resol[1];
/* 281 */     calib.pixelDepth = resol[2];
/*     */     
/* 283 */     IJ.showStatus("Count labels...");
/* 284 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 285 */     int nbLabels = labels.length;
/*     */ 
/*     */     
/* 288 */     double[] surfaces = IntrinsicVolumes3D.surfaceAreas(labelImage, labels, calib, nDirs);
/*     */ 
/*     */     
/* 291 */     ResultsTable table = new ResultsTable();
/* 292 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 294 */       table.incrementCounter();
/* 295 */       table.addLabel(Integer.toString(labels[i]));
/* 296 */       table.addValue("SurfaceArea", surfaces[i]);
/*     */     } 
/*     */     
/* 299 */     IJ.showStatus("");
/* 300 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] surfaceAreaCrofton(ImageStack image, int[] labels, double[] resol, int nDirs) {
/* 322 */     Calibration calib = new Calibration();
/* 323 */     calib.pixelWidth = resol[0];
/* 324 */     calib.pixelHeight = resol[1];
/* 325 */     calib.pixelDepth = resol[2];
/*     */     
/* 327 */     return IntrinsicVolumes3D.surfaceAreas(image, labels, calib, nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double surfaceAreaCrofton(ImageStack image, int label, double[] resol, int nDirs) {
/* 352 */     Calibration calib = new Calibration();
/* 353 */     calib.pixelWidth = resol[0];
/* 354 */     calib.pixelHeight = resol[1];
/* 355 */     calib.pixelDepth = resol[2];
/*     */     
/* 357 */     image = LabelImages.cropLabel(image, label, 0);
/* 358 */     return IntrinsicVolumes3D.surfaceArea(image, calib, nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double surfaceAreaCroftonD3(ImageStack image, double[] resol) {
/* 375 */     Calibration calib = new Calibration();
/* 376 */     calib.pixelWidth = resol[0];
/* 377 */     calib.pixelHeight = resol[1];
/* 378 */     calib.pixelDepth = resol[2];
/* 379 */     return IntrinsicVolumes3D.surfaceArea(image, calib, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] eulerNumber(ImageStack image, int[] labels, int conn) {
/* 404 */     return IntrinsicVolumes3D.eulerNumbers(image, labels, conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[][] centroids(ImageStack labelImage, int[] labels) {
/* 422 */     int nLabels = labels.length;
/* 423 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 426 */     int[] counts = new int[nLabels];
/* 427 */     double[][] centroids = new double[nLabels][3];
/*     */ 
/*     */     
/* 430 */     int sizeX = labelImage.getWidth();
/* 431 */     int sizeY = labelImage.getHeight();
/* 432 */     int sizeZ = labelImage.getSize();
/* 433 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 435 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 437 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 439 */           int label = (int)labelImage.getVoxel(x, y, z);
/* 440 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/* 444 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */ 
/*     */               
/* 448 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 449 */               centroids[index][0] = centroids[index][0] + x;
/* 450 */               centroids[index][1] = centroids[index][1] + y;
/* 451 */               centroids[index][2] = centroids[index][2] + z;
/* 452 */               counts[index] = counts[index] + 1;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 458 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 460 */       centroids[i][0] = centroids[i][0] / counts[i];
/* 461 */       centroids[i][1] = centroids[i][1] / counts[i];
/* 462 */       centroids[i][2] = centroids[i][2] / counts[i];
/*     */     } 
/*     */     
/* 465 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable inertiaEllipsoid(ImageStack image) {
/* 481 */     return inertiaEllipsoid(image, new double[] { 1.0D, 1.0D, 1.0D });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable inertiaEllipsoid(ImageStack image, double[] resol) {
/* 510 */     Calibration calib = new Calibration();
/* 511 */     calib.pixelWidth = resol[0];
/* 512 */     calib.pixelHeight = resol[1];
/* 513 */     calib.pixelDepth = resol[2];
/*     */     
/* 515 */     InertiaEllipsoid algo = new InertiaEllipsoid();
/* 516 */     return algo.createTable(algo.analyzeRegions(image, calib));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[][] inertiaEllipsoid(ImageStack image, int[] labels, double[] resol) {
/* 559 */     Calibration calib = new Calibration();
/* 560 */     calib.pixelWidth = resol[0];
/* 561 */     calib.pixelHeight = resol[1];
/* 562 */     calib.pixelDepth = resol[2];
/*     */     
/* 564 */     Ellipsoid[] ellipsoids = InertiaEllipsoid.inertiaEllipsoids(image, labels, calib);
/*     */     
/* 566 */     int nLabels = labels.length;
/* 567 */     double[][] results = new double[nLabels][9];
/* 568 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 570 */       Ellipsoid elli = ellipsoids[i];
/* 571 */       results[i][0] = elli.center().getX();
/* 572 */       results[i][1] = elli.center().getY();
/* 573 */       results[i][2] = elli.center().getZ();
/* 574 */       results[i][3] = elli.radius1();
/* 575 */       results[i][4] = elli.radius2();
/* 576 */       results[i][5] = elli.radius3();
/* 577 */       results[i][6] = elli.phi();
/* 578 */       results[i][7] = elli.theta();
/* 579 */       results[i][8] = elli.psi();
/*     */     } 
/* 581 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[][] computeEllipsoidElongations(double[][] ellipsoids) {
/* 611 */     int nLabels = ellipsoids.length;
/* 612 */     double[][] res = new double[nLabels][3];
/*     */     
/* 614 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 616 */       double ra = ellipsoids[i][3];
/* 617 */       double rb = ellipsoids[i][4];
/* 618 */       double rc = ellipsoids[i][5];
/*     */       
/* 620 */       res[i][0] = ra / rb;
/* 621 */       res[i][1] = ra / rc;
/* 622 */       res[i][2] = rb / rc;
/*     */     } 
/*     */     
/* 625 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable maximumInscribedSphere(ImageStack labelImage, double[] resol) {
/* 644 */     Calibration calib = new Calibration();
/* 645 */     calib.pixelWidth = resol[0];
/* 646 */     calib.pixelHeight = resol[1];
/* 647 */     calib.pixelDepth = resol[2];
/* 648 */     LargestInscribedBall algo = new LargestInscribedBall();
/*     */     
/* 650 */     return algo.createTable(algo.analyzeRegions(labelImage, calib));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[][] maximumInscribedSphere(ImageStack labelImage, int[] labels, double[] resol) {
/* 670 */     int nbLabels = labels.length;
/*     */ 
/*     */     
/* 673 */     ImageStack mask = BinaryImages.binarize(labelImage);
/*     */ 
/*     */     
/* 676 */     ImageStack distanceMap = BinaryImages.distanceMap(mask);
/*     */ 
/*     */ 
/*     */     
/* 680 */     Cursor3D[] posCenter = findPositionOfMaxValues(distanceMap, labelImage, labels);
/* 681 */     float[] radii = getValues(distanceMap, posCenter);
/*     */ 
/*     */     
/* 684 */     double[][] res = new double[nbLabels][4];
/* 685 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 687 */       res[i][0] = posCenter[i].getX() * resol[0];
/* 688 */       res[i][1] = posCenter[i].getY() * resol[1];
/* 689 */       res[i][2] = posCenter[i].getZ() * resol[2];
/* 690 */       res[i][3] = radii[i] * resol[0];
/*     */     } 
/*     */     
/* 693 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Cursor3D[] findPositionOfMaxValues(ImageStack image, ImageStack labelImage, int[] labels) {
/* 711 */     int width = labelImage.getWidth();
/* 712 */     int height = labelImage.getHeight();
/* 713 */     int depth = labelImage.getSize();
/*     */ 
/*     */     
/* 716 */     int nbLabel = labels.length;
/* 717 */     int maxLabel = 0;
/* 718 */     for (int i = 0; i < nbLabel; i++)
/*     */     {
/* 720 */       maxLabel = Math.max(maxLabel, labels[i]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 725 */     int[] labelIndex = new int[maxLabel + 1];
/* 726 */     for (int j = 0; j < nbLabel; j++)
/*     */     {
/* 728 */       labelIndex[labels[j]] = j;
/*     */     }
/*     */ 
/*     */     
/* 732 */     Cursor3D[] posMax = new Cursor3D[nbLabel];
/* 733 */     double[] maxValues = new double[nbLabel];
/* 734 */     for (int k = 0; k < nbLabel; k++) {
/*     */       
/* 736 */       maxValues[k] = -1.0D;
/* 737 */       posMax[k] = new Cursor3D(-1, -1, -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 745 */     for (int z = 0; z < depth; z++) {
/*     */       
/* 747 */       for (int y = 0; y < height; y++) {
/*     */         
/* 749 */         for (int x = 0; x < width; x++) {
/*     */           
/* 751 */           int label = (int)labelImage.getVoxel(x, y, z);
/*     */ 
/*     */           
/* 754 */           if (label != 0) {
/*     */ 
/*     */             
/* 757 */             int index = labelIndex[label];
/*     */ 
/*     */             
/* 760 */             double value = image.getVoxel(x, y, z);
/* 761 */             if (value > maxValues[index]) {
/*     */               
/* 763 */               posMax[index].set(x, y, z);
/* 764 */               maxValues[index] = value;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 770 */     return posMax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float[] getValues(ImageStack image, Cursor3D[] positions) {
/* 779 */     float[] values = new float[positions.length];
/*     */ 
/*     */     
/* 782 */     for (int i = 0; i < positions.length; i++)
/*     */     {
/* 784 */       values[i] = (float)image.getVoxel(positions[i].getX(), 
/* 785 */           positions[i].getY(), positions[i].getZ());
/*     */     }
/*     */     
/* 788 */     return values;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/GeometricMeasures3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */