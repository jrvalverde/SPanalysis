/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.RegionAnalyzer;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegionAnalyzer3D<T>
/*     */   extends AlgoStub
/*     */   implements RegionAnalyzer<T>
/*     */ {
/*     */   public static final <T2> Map<Integer, T2> createMap(int[] labels, Object[] data) {
/*  44 */     int nLabels = labels.length;
/*  45 */     if (data.length != nLabels)
/*     */     {
/*  47 */       throw new IllegalArgumentException("Require same number of elements for label array and data array");
/*     */     }
/*     */ 
/*     */     
/*  51 */     Map<Integer, T2> map = new TreeMap<Integer, T2>();
/*  52 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/*  54 */       map.put(Integer.valueOf(labels[i]), (T2)data[i]);
/*     */     }
/*  56 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract T[] analyzeRegions(ImageStack paramImageStack, int[] paramArrayOfint, Calibration paramCalibration);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, T> analyzeRegions(ImageStack image, Calibration calib) {
/*  86 */     fireStatusChanged(this, "Find Labels");
/*  87 */     int[] labels = LabelImages.findAllLabels(image);
/*     */ 
/*     */     
/*  90 */     fireStatusChanged(this, "Analyze regions");
/*  91 */     Object[] results = (Object[])analyzeRegions(image, labels, calib);
/*     */ 
/*     */     
/*  94 */     fireStatusChanged(this, "Convert to map");
/*  95 */     Map<Integer, T> map = createMap(labels, (T[])results);
/*     */ 
/*     */     
/*  98 */     fireStatusChanged(this, "");
/*  99 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, T> analyzeRegions(ImagePlus labelPlus) {
/* 115 */     fireStatusChanged(this, "Find Labels");
/* 116 */     int[] labels = LabelImages.findAllLabels(labelPlus);
/*     */ 
/*     */     
/* 119 */     fireStatusChanged(this, "Analyze regions");
/* 120 */     Object[] results = (Object[])analyzeRegions(labelPlus.getImageStack(), labels, labelPlus.getCalibration());
/*     */ 
/*     */     
/* 123 */     fireStatusChanged(this, "Convert to map");
/* 124 */     Map<Integer, T> map = createMap(labels, (T[])results);
/*     */ 
/*     */     
/* 127 */     fireStatusChanged(this, "");
/* 128 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable computeTable(ImagePlus labelPlus) {
/* 142 */     return createTable(analyzeRegions(labelPlus));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/RegionAnalyzer3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */