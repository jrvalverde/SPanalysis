/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import inra.ijpb.geometry.Vector3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumes3DUtils
/*     */ {
/*     */   public static final double[] volumeLut(Calibration calib) {
/*  31 */     int nbConfigs = 256;
/*  32 */     double[] lut = new double[nbConfigs];
/*     */ 
/*     */     
/*  35 */     boolean[][][] im = new boolean[2][2][2];
/*     */ 
/*     */     
/*  38 */     double voxelVolume = calib.pixelWidth * calib.pixelHeight * calib.pixelDepth;
/*     */ 
/*     */     
/*  41 */     for (int iConfig = 0; iConfig < nbConfigs; iConfig++) {
/*     */ 
/*     */       
/*  44 */       updateTile(im, iConfig);
/*     */       
/*  46 */       int nVoxels = 0;
/*  47 */       if (im[0][0][0]) nVoxels++; 
/*  48 */       if (im[1][0][0]) nVoxels++; 
/*  49 */       if (im[0][1][0]) nVoxels++; 
/*  50 */       if (im[1][1][0]) nVoxels++; 
/*  51 */       if (im[0][0][1]) nVoxels++; 
/*  52 */       if (im[1][0][1]) nVoxels++; 
/*  53 */       if (im[0][1][1]) nVoxels++; 
/*  54 */       if (im[1][1][1]) nVoxels++;
/*     */       
/*  56 */       lut[iConfig] = nVoxels * voxelVolume / 8.0D;
/*     */     } 
/*     */     
/*  59 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] surfaceAreaLut(Calibration calib, int nDirs) {
/*  74 */     if (nDirs == 3)
/*     */     {
/*  76 */       return surfaceAreaLutD3(calib);
/*     */     }
/*  78 */     if (nDirs == 13)
/*     */     {
/*  80 */       return surfaceAreaLutD13(calib);
/*     */     }
/*     */ 
/*     */     
/*  84 */     throw new IllegalArgumentException("Number of directions should be either 3 or 13, not " + nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] surfaceAreaLutD3(Calibration calib) {
/* 104 */     double d1 = calib.pixelWidth;
/* 105 */     double d2 = calib.pixelHeight;
/* 106 */     double d3 = calib.pixelDepth;
/* 107 */     double vol = d1 * d2 * d3;
/*     */ 
/*     */     
/* 110 */     int nbConfigs = 256;
/* 111 */     double[] tab = new double[nbConfigs];
/*     */ 
/*     */     
/* 114 */     boolean[][][] im = new boolean[2][2][2];
/*     */ 
/*     */     
/* 117 */     for (int iConfig = 0; iConfig < nbConfigs; iConfig++) {
/*     */ 
/*     */       
/* 120 */       updateTile(im, iConfig);
/*     */ 
/*     */       
/* 123 */       for (int z = 0; z < 2; z++) {
/*     */         
/* 125 */         for (int y = 0; y < 2; y++) {
/*     */           
/* 127 */           for (int x = 0; x < 2; x++) {
/*     */             
/* 129 */             if (im[z][y][x]) {
/*     */ 
/*     */ 
/*     */               
/* 133 */               double ke1 = im[z][y][1 - x] ? 0.0D : (vol / d1 / 2.0D);
/* 134 */               double ke2 = im[z][1 - y][x] ? 0.0D : (vol / d2 / 2.0D);
/* 135 */               double ke3 = im[1 - z][y][x] ? 0.0D : (vol / d3 / 2.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 140 */               tab[iConfig] = tab[iConfig] + (ke1 + ke2 + ke3) / 3.0D;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 145 */     }  return tab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] surfaceAreaLutD13(Calibration calib) {
/* 163 */     double d1 = calib.pixelWidth;
/* 164 */     double d2 = calib.pixelHeight;
/* 165 */     double d3 = calib.pixelDepth;
/* 166 */     double vol = d1 * d2 * d3;
/*     */     
/* 168 */     double d12 = Math.hypot(d1, d2);
/* 169 */     double d13 = Math.hypot(d1, d3);
/* 170 */     double d23 = Math.hypot(d2, d3);
/* 171 */     double d123 = Math.hypot(d12, d3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     double[] weights = directionWeights3d13(calib);
/*     */ 
/*     */     
/* 179 */     int nbConfigs = 256;
/* 180 */     double[] tab = new double[nbConfigs];
/*     */ 
/*     */     
/* 183 */     boolean[][][] im = new boolean[2][2][2];
/*     */ 
/*     */     
/* 186 */     double[] kei = new double[7];
/*     */ 
/*     */     
/* 189 */     for (int iConfig = 0; iConfig < nbConfigs; iConfig++) {
/*     */ 
/*     */       
/* 192 */       updateTile(im, iConfig);
/*     */ 
/*     */       
/* 195 */       for (int z = 0; z < 2; z++) {
/*     */         
/* 197 */         for (int y = 0; y < 2; y++) {
/*     */           
/* 199 */           for (int x = 0; x < 2; x++) {
/*     */             
/* 201 */             if (im[z][y][x]) {
/*     */ 
/*     */ 
/*     */               
/* 205 */               kei[0] = im[z][y][1 - x] ? 0.0D : (vol / d1 / 8.0D);
/* 206 */               kei[1] = im[z][1 - y][x] ? 0.0D : (vol / d2 / 8.0D);
/* 207 */               kei[2] = im[1 - z][y][x] ? 0.0D : (vol / d3 / 8.0D);
/*     */ 
/*     */               
/* 210 */               kei[3] = im[z][1 - y][1 - x] ? 0.0D : (vol / d12 / 4.0D);
/* 211 */               kei[4] = im[1 - z][y][1 - x] ? 0.0D : (vol / d13 / 4.0D);
/* 212 */               kei[5] = im[1 - z][1 - y][x] ? 0.0D : (vol / d23 / 4.0D);
/*     */ 
/*     */               
/* 215 */               kei[6] = im[1 - z][1 - y][1 - x] ? 0.0D : (vol / d123 / 2.0D);
/*     */ 
/*     */               
/* 218 */               for (int i = 0; i < 7; i++)
/* 219 */                 tab[iConfig] = tab[iConfig] + 4.0D * kei[i] * weights[i]; 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 224 */     }  return tab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] meanBreadthLut(Calibration calib, int nDirs, int conn2d) {
/* 240 */     if (nDirs == 3)
/*     */     {
/* 242 */       return meanBreadthLutD3(calib, conn2d);
/*     */     }
/* 244 */     if (nDirs == 13)
/*     */     {
/* 246 */       return meanBreadthLutD13(calib, conn2d);
/*     */     }
/*     */ 
/*     */     
/* 250 */     throw new IllegalArgumentException("Number of directions should be either 3 or 13, not " + nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] meanBreadthLutD3(Calibration calib, int conn2d) {
/* 268 */     double d1 = calib.pixelWidth;
/* 269 */     double d2 = calib.pixelHeight;
/* 270 */     double d3 = calib.pixelDepth;
/* 271 */     double vol = d1 * d2 * d3;
/*     */ 
/*     */     
/* 274 */     double a1 = d2 * d3;
/* 275 */     double a2 = d1 * d3;
/* 276 */     double a3 = d1 * d2;
/*     */ 
/*     */     
/* 279 */     int[][] coord = { new int[3], { 0, 1 }, { 1 }, { 1, 1 }, { 0, 0, 1 }, { 0, 1, 1 }, { 1, 1 }, { 1, 1, 1 } };
/*     */ 
/*     */     
/* 282 */     int nbConfigs = 256;
/* 283 */     double[] lut = new double[nbConfigs];
/*     */ 
/*     */     
/* 286 */     boolean[][][] im = new boolean[2][2][2];
/*     */ 
/*     */ 
/*     */     
/* 290 */     for (int iConfig = 1; iConfig < nbConfigs - 1; iConfig++) {
/*     */ 
/*     */       
/* 293 */       im[0][0][0] = ((iConfig & 0x1) > 0);
/* 294 */       im[0][0][1] = ((iConfig & 0x2) > 0);
/* 295 */       im[0][1][0] = ((iConfig & 0x4) > 0);
/* 296 */       im[0][1][1] = ((iConfig & 0x8) > 0);
/* 297 */       im[1][0][0] = ((iConfig & 0x10) > 0);
/* 298 */       im[1][0][1] = ((iConfig & 0x20) > 0);
/* 299 */       im[1][1][0] = ((iConfig & 0x40) > 0);
/* 300 */       im[1][1][1] = ((iConfig & 0x80) > 0);
/*     */ 
/*     */       
/* 303 */       for (int iVoxel = 0; iVoxel < 8; iVoxel++) {
/*     */ 
/*     */         
/* 306 */         int p1 = coord[iVoxel][0];
/* 307 */         int p2 = coord[iVoxel][1];
/* 308 */         int p3 = coord[iVoxel][2];
/*     */ 
/*     */         
/* 311 */         if (im[p1][p2][p3]) {
/*     */ 
/*     */ 
/*     */           
/* 315 */           boolean[] face1 = { im[p1][p2][p3], im[p1][1 - p2][p3], im[p1][p2][1 - p3], im[p1][1 - p2][1 - p3] };
/* 316 */           boolean[] face2 = { im[p1][p2][p3], im[1 - p1][p2][p3], im[p1][p2][1 - p3], im[1 - p1][p2][1 - p3] };
/* 317 */           boolean[] face3 = { im[p1][p2][p3], im[1 - p1][p2][p3], im[p1][1 - p2][p3], im[1 - p1][1 - p2][p3] };
/*     */ 
/*     */           
/* 320 */           double f1 = eulerContribTile2d(face1, conn2d, d3, d2);
/* 321 */           double f2 = eulerContribTile2d(face2, conn2d, d3, d1);
/* 322 */           double f3 = eulerContribTile2d(face3, conn2d, d2, d1);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 327 */           lut[iConfig] = lut[iConfig] + vol * (f1 / a1 + f2 / a2 + f3 / a3) / 6.0D;
/*     */         } 
/*     */       } 
/*     */     } 
/* 331 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] meanBreadthLutD13(Calibration calib, int conn2d) {
/* 348 */     double d1 = calib.pixelWidth;
/* 349 */     double d2 = calib.pixelHeight;
/* 350 */     double d3 = calib.pixelDepth;
/* 351 */     double vol = d1 * d2 * d3;
/*     */     
/* 353 */     double d12 = Math.hypot(d1, d2);
/* 354 */     double d13 = Math.hypot(d1, d3);
/* 355 */     double d23 = Math.hypot(d2, d3);
/*     */ 
/*     */     
/* 358 */     double s = (d12 + d13 + d23) / 2.0D;
/* 359 */     double[] areas = {
/* 360 */         d2 * d3, d1 * d3, d1 * d2, 
/* 361 */         d3 * d12, d2 * d13, d1 * d23, 
/* 362 */         2.0D * Math.sqrt(s * (s - d12) * (s - d13) * (s - d23))
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 367 */     double[] weights = directionWeights3d13(calib);
/*     */ 
/*     */     
/* 370 */     double[] diams = new double[7];
/*     */ 
/*     */     
/* 373 */     int[][] coord = { new int[3], { 0, 1 }, { 1 }, { 1, 1 }, { 0, 0, 1 }, { 0, 1, 1 }, { 1, 1 }, { 1, 1, 1 } };
/*     */ 
/*     */     
/* 376 */     int nbConfigs = 256;
/* 377 */     double[] lut = new double[nbConfigs];
/*     */ 
/*     */     
/* 380 */     boolean[][][] im = new boolean[2][2][2];
/*     */ 
/*     */ 
/*     */     
/* 384 */     for (int iConfig = 1; iConfig < nbConfigs - 1; iConfig++) {
/*     */ 
/*     */       
/* 387 */       updateTile(im, iConfig);
/*     */ 
/*     */       
/* 390 */       for (int iVoxel = 0; iVoxel < 8; iVoxel++) {
/*     */ 
/*     */         
/* 393 */         int p1 = coord[iVoxel][0];
/* 394 */         int p2 = coord[iVoxel][1];
/* 395 */         int p3 = coord[iVoxel][2];
/*     */ 
/*     */         
/* 398 */         if (im[p1][p2][p3]) {
/*     */ 
/*     */ 
/*     */           
/* 402 */           boolean[] face1 = { im[p1][p2][p3], im[p1][1 - p2][p3], im[p1][p2][1 - p3], im[p1][1 - p2][1 - p3] };
/* 403 */           boolean[] face2 = { im[p1][p2][p3], im[1 - p1][p2][p3], im[p1][p2][1 - p3], im[1 - p1][p2][1 - p3] };
/* 404 */           boolean[] face3 = { im[p1][p2][p3], im[1 - p1][p2][p3], im[p1][1 - p2][p3], im[1 - p1][1 - p2][p3] };
/*     */ 
/*     */           
/* 407 */           diams[0] = eulerContribTile2d(face1, conn2d, d3, d2) / 2.0D;
/* 408 */           diams[1] = eulerContribTile2d(face2, conn2d, d3, d1) / 2.0D;
/* 409 */           diams[2] = eulerContribTile2d(face3, conn2d, d2, d1) / 2.0D;
/*     */ 
/*     */ 
/*     */           
/* 413 */           boolean[] face4 = { im[p1][p2][p3], im[1 - p1][1 - p2][p3], im[p1][p2][1 - p3], im[1 - p1][1 - p2][1 - p3] };
/* 414 */           boolean[] face6 = { im[p1][p2][p3], im[1 - p1][p2][1 - p3], im[p1][1 - p2][p3], im[1 - p1][1 - p2][1 - p3] };
/* 415 */           boolean[] face8 = { im[p1][p2][p3], im[p1][1 - p2][1 - p3], im[1 - p1][p2][p3], im[1 - p1][1 - p2][1 - p3] };
/*     */ 
/*     */           
/* 418 */           diams[3] = eulerContribTile2d(face4, conn2d, d12, d3);
/* 419 */           diams[4] = eulerContribTile2d(face6, conn2d, d13, d2);
/* 420 */           diams[5] = eulerContribTile2d(face8, conn2d, d23, d1);
/*     */ 
/*     */           
/* 423 */           boolean[] faceA = { im[p1][p2][p3], im[1 - p1][1 - p2][p3], im[1 - p1][p2][1 - p3] };
/* 424 */           boolean[] faceB = { im[p1][p2][p3], im[1 - p1][p2][1 - p3], im[p1][1 - p2][1 - p3] };
/* 425 */           boolean[] faceC = { im[p1][p2][p3], im[1 - p1][1 - p2][p3], im[p1][1 - p2][1 - p3] };
/*     */ 
/*     */           
/* 428 */           double fa = eulerContribTriangleTile(faceA, d12, d13, d23);
/* 429 */           double fb = eulerContribTriangleTile(faceB, d13, d23, d12);
/* 430 */           double fc = eulerContribTriangleTile(faceC, d12, d23, d13);
/* 431 */           diams[6] = fa + fb + fc;
/*     */ 
/*     */ 
/*     */           
/* 435 */           for (int i = 0; i < 7; i++)
/*     */           {
/* 437 */             lut[iConfig] = lut[iConfig] + vol * diams[i] / areas[i] * weights[i];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 442 */     return lut;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final double eulerContribTile2d(boolean[] face, int conn2d, double d1, double d2) {
/* 447 */     if (conn2d == 4)
/*     */     {
/* 449 */       return eulerContribTile2dC4(face, d1, d2);
/*     */     }
/* 451 */     if (conn2d == 8)
/*     */     {
/* 453 */       return eulerContribTile2dC8(face, d1, d2);
/*     */     }
/*     */ 
/*     */     
/* 457 */     throw new IllegalArgumentException("Connectivity mustbe either 4 or 8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double eulerContribTile2dC4(boolean[] face, double d1, double d2) {
/* 477 */     if (!face[0])
/*     */     {
/* 479 */       return 0.0D;
/*     */     }
/*     */ 
/*     */     
/* 483 */     int nPixels = 0;
/* 484 */     for (int i = 0; i < face.length; i++) {
/*     */       
/* 486 */       if (face[i]) nPixels++;
/*     */     
/*     */     } 
/* 489 */     switch (nPixels) {
/*     */ 
/*     */       
/*     */       case 1:
/* 493 */         return 0.25D;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 499 */         return face[3] ? 0.25D : 0.0D;
/*     */       
/*     */       case 3:
/* 502 */         if (face[3])
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 509 */           return 0.0D;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 516 */         return -0.25D;
/*     */ 
/*     */       
/*     */       case 4:
/* 520 */         return 0.0D;
/*     */     } 
/*     */     
/* 523 */     throw new RuntimeException("Uncatched number of pixels: " + nPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double eulerContribTile2dC8(boolean[] face, double d1, double d2) {
/* 543 */     if (!face[0])
/*     */     {
/* 545 */       return 0.0D;
/*     */     }
/*     */ 
/*     */     
/* 549 */     int nPixels = 0;
/* 550 */     for (int i = 0; i < face.length; i++) {
/*     */       
/* 552 */       if (face[i]) nPixels++;
/*     */     
/*     */     } 
/* 555 */     switch (nPixels) {
/*     */ 
/*     */       
/*     */       case 1:
/* 559 */         return 0.25D;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 565 */         return face[3] ? -0.25D : 0.0D;
/*     */       
/*     */       case 3:
/* 568 */         if (face[3]) {
/*     */ 
/*     */ 
/*     */           
/* 572 */           double alpha = face[2] ? Math.atan2(d2, d1) : Math.atan2(d1, d2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 579 */           return (Math.PI - alpha) / 6.283185307179586D - 0.5D;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 584 */         return 0.0D;
/*     */ 
/*     */       
/*     */       case 4:
/* 588 */         return 0.0D;
/*     */     } 
/* 590 */     throw new RuntimeException("Uncatched number of pixels: " + nPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double eulerContribTriangleTile(boolean[] face, double d1, double d2, double d3) {
/*     */     double alpha;
/* 612 */     if (!face[0])
/*     */     {
/* 614 */       return 0.0D;
/*     */     }
/*     */ 
/*     */     
/* 618 */     int nPixels = 1;
/* 619 */     if (face[1]) nPixels++; 
/* 620 */     if (face[2]) nPixels++;
/*     */ 
/*     */     
/* 623 */     switch (nPixels) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 629 */         return 0.16666666666666666D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 637 */         return -0.08333333333333333D;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 642 */         alpha = Math.acos((d1 * d1 + d2 * d2 - d3 * d3) / 2.0D * d1 * d2);
/*     */         
/* 644 */         return (Math.PI - alpha) / 6.283185307179586D - 0.3333333333333333D;
/*     */     } 
/* 646 */     throw new RuntimeException("Uncatched number of pixels: " + nPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void updateTile(boolean[][][] tile, int tileIndex) {
/* 653 */     tile[0][0][0] = ((tileIndex & 0x1) > 0);
/* 654 */     tile[0][0][1] = ((tileIndex & 0x2) > 0);
/* 655 */     tile[0][1][0] = ((tileIndex & 0x4) > 0);
/* 656 */     tile[0][1][1] = ((tileIndex & 0x8) > 0);
/* 657 */     tile[1][0][0] = ((tileIndex & 0x10) > 0);
/* 658 */     tile[1][0][1] = ((tileIndex & 0x20) > 0);
/* 659 */     tile[1][1][0] = ((tileIndex & 0x40) > 0);
/* 660 */     tile[1][1][1] = ((tileIndex & 0x80) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] directionWeights3d3(Calibration calib) {
/* 676 */     double third = 0.3333333333333333D;
/* 677 */     return new double[] { 0.3333333333333333D, 0.3333333333333333D, 0.3333333333333333D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] directionWeights3d13(Calibration calib) {
/* 691 */     double dx = calib.pixelWidth;
/* 692 */     double dy = calib.pixelHeight;
/* 693 */     double dz = calib.pixelDepth;
/*     */ 
/*     */     
/* 696 */     double[] weights = new double[7];
/*     */ 
/*     */     
/* 699 */     if (dx == dy && dx == dz) {
/*     */ 
/*     */       
/* 702 */       weights[0] = 0.09155578240952D;
/* 703 */       weights[1] = 0.09155578240952D;
/* 704 */       weights[2] = 0.09155578240952D;
/* 705 */       weights[3] = 0.07396125575216D;
/* 706 */       weights[4] = 0.07396125575216D;
/* 707 */       weights[5] = 0.07396125575216D;
/* 708 */       weights[6] = 0.07039127956464D;
/* 709 */       return weights;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 719 */     Vector3D vPNN = (new Vector3D(dx, -dy, -dz)).normalize();
/* 720 */     Vector3D vPZN = (new Vector3D(dx, 0.0D, -dz)).normalize();
/* 721 */     Vector3D vNPN = (new Vector3D(-dx, dy, -dz)).normalize();
/* 722 */     Vector3D vZPN = (new Vector3D(0.0D, dy, -dz)).normalize();
/* 723 */     Vector3D vPPN = (new Vector3D(dx, dy, -dz)).normalize();
/*     */ 
/*     */     
/* 726 */     Vector3D vPNZ = (new Vector3D(dx, -dy, 0.0D)).normalize();
/* 727 */     Vector3D vPZZ = (new Vector3D(dx, 0.0D, 0.0D)).normalize();
/* 728 */     Vector3D vNPZ = (new Vector3D(-dx, dy, 0.0D)).normalize();
/* 729 */     Vector3D vZPZ = (new Vector3D(0.0D, dy, 0.0D)).normalize();
/* 730 */     Vector3D vPPZ = (new Vector3D(dx, dy, 0.0D)).normalize();
/*     */ 
/*     */     
/* 733 */     Vector3D vNNP = (new Vector3D(-dx, -dy, dz)).normalize();
/* 734 */     Vector3D vZNP = (new Vector3D(0.0D, -dy, dz)).normalize();
/* 735 */     Vector3D vPNP = (new Vector3D(dx, -dy, dz)).normalize();
/* 736 */     Vector3D vNZP = (new Vector3D(-dx, 0.0D, dz)).normalize();
/* 737 */     Vector3D vZZP = (new Vector3D(0.0D, 0.0D, dz)).normalize();
/* 738 */     Vector3D vPZP = (new Vector3D(dx, 0.0D, dz)).normalize();
/* 739 */     Vector3D vNPP = (new Vector3D(-dx, dy, dz)).normalize();
/* 740 */     Vector3D vZPP = (new Vector3D(0.0D, dy, dz)).normalize();
/* 741 */     Vector3D vPPP = (new Vector3D(dx, dy, dz)).normalize();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 746 */     Vector3D[] neighbors = { vPNN, vPNZ, vPNP, vPZP, vPPP, vPPZ, vPPN, vPZN };
/* 747 */     weights[0] = GeometryUtils.sphericalVoronoiDomainArea(vPZZ, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 750 */     neighbors = new Vector3D[] { vPPZ, vPPP, vZPP, vNPP, vNPZ, vNPN, vZPN, vPPN };
/* 751 */     weights[1] = GeometryUtils.sphericalVoronoiDomainArea(vZPZ, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 754 */     neighbors = new Vector3D[] { vPZP, vPPP, vZPP, vNPP, vNZP, vNNP, vZNP, vPNP };
/* 755 */     weights[2] = GeometryUtils.sphericalVoronoiDomainArea(vZZP, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 758 */     neighbors = new Vector3D[] { vPZZ, vPPP, vZPZ, vPPN };
/* 759 */     weights[3] = GeometryUtils.sphericalVoronoiDomainArea(vPPZ, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 762 */     neighbors = new Vector3D[] { vPZZ, vPPP, vZZP, vPNP };
/* 763 */     weights[4] = GeometryUtils.sphericalVoronoiDomainArea(vPZP, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 766 */     neighbors = new Vector3D[] { vZPZ, vNPP, vZZP, vPPP };
/* 767 */     weights[5] = GeometryUtils.sphericalVoronoiDomainArea(vZPP, neighbors) / 6.283185307179586D;
/*     */ 
/*     */     
/* 770 */     neighbors = new Vector3D[] { vPZP, vZZP, vZPP, vZPZ, vPPZ, vPZZ };
/* 771 */     weights[6] = GeometryUtils.sphericalVoronoiDomainArea(vPPP, neighbors) / 6.283185307179586D;
/*     */     
/* 773 */     return weights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] eulerNumberLut(int conn) {
/* 790 */     if (conn == 6)
/*     */     {
/* 792 */       return eulerNumberLutC6();
/*     */     }
/* 794 */     if (conn == 26)
/*     */     {
/* 796 */       return eulerNumberLutC26();
/*     */     }
/*     */ 
/*     */     
/* 800 */     throw new IllegalArgumentException("Connectivity must be either 6 or 26, not " + conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] eulerNumberLutC6() {
/* 812 */     double[] lut = { 
/* 813 */         0.0D, 1.0D, 1.0D, 0.0D, 1.0D, 0.0D, 2.0D, -1.0D, 1.0D, 2.0D, 0.0D, -1.0D, 0.0D, -1.0D, -1.0D, 0.0D, 
/* 814 */         1.0D, 0.0D, 2.0D, -1.0D, 2.0D, -1.0D, 3.0D, -2.0D, 2.0D, 1.0D, 1.0D, -2.0D, 1.0D, -2.0D, 0.0D, -1.0D, 
/* 815 */         1.0D, 2.0D, 0.0D, -1.0D, 2.0D, 1.0D, 1.0D, -2.0D, 2.0D, 3.0D, -1.0D, -2.0D, 1.0D, 0.0D, -2.0D, -1.0D, 
/* 816 */         0.0D, -1.0D, -1.0D, 0.0D, 1.0D, -2.0D, 0.0D, -1.0D, 1.0D, 0.0D, -2.0D, -1.0D, 0.0D, -3.0D, -3.0D, 0.0D, 
/* 817 */         1.0D, 2.0D, 2.0D, 1.0D, 0.0D, -1.0D, 1.0D, -2.0D, 2.0D, 3.0D, 1.0D, 0.0D, -1.0D, -2.0D, -2.0D, -1.0D, 
/* 818 */         0.0D, -1.0D, 1.0D, -2.0D, -1.0D, 0.0D, 0.0D, -1.0D, 1.0D, 0.0D, 0.0D, -3.0D, -2.0D, -1.0D, -3.0D, 0.0D, 
/* 819 */         2.0D, 3.0D, 1.0D, 0.0D, 1.0D, 0.0D, 0.0D, -3.0D, 3.0D, 4.0D, 0.0D, -1.0D, 0.0D, -1.0D, -3.0D, -2.0D, 
/* 820 */         -1.0D, -2.0D, -2.0D, -1.0D, -2.0D, -1.0D, -3.0D, 0.0D, 0.0D, -1.0D, -3.0D, -2.0D, -3.0D, -2.0D, -6.0D, 1.0D, 
/*     */         
/* 822 */         1.0D, 2.0D, 2.0D, 1.0D, 2.0D, 1.0D, 3.0D, 0.0D, 0.0D, 1.0D, -1.0D, -2.0D, -1.0D, -2.0D, -2.0D, -1.0D, 
/* 823 */         2.0D, 1.0D, 3.0D, 0.0D, 3.0D, 0.0D, 4.0D, -1.0D, 1.0D, 0.0D, 0.0D, -3.0D, 0.0D, -3.0D, -1.0D, -2.0D, 
/* 824 */         0.0D, 1.0D, -1.0D, -2.0D, 1.0D, 0.0D, 0.0D, -3.0D, -1.0D, 0.0D, 0.0D, -1.0D, -2.0D, -3.0D, -1.0D, 0.0D, 
/* 825 */         -1.0D, -2.0D, -2.0D, -1.0D, 0.0D, -3.0D, -1.0D, -2.0D, -2.0D, -3.0D, -1.0D, 0.0D, -3.0D, -6.0D, -2.0D, 1.0D, 
/* 826 */         0.0D, 1.0D, 1.0D, 0.0D, -1.0D, -2.0D, 0.0D, -3.0D, -1.0D, 0.0D, -2.0D, -3.0D, 0.0D, -1.0D, -1.0D, 0.0D, 
/* 827 */         -1.0D, -2.0D, 0.0D, -3.0D, -2.0D, -1.0D, -1.0D, -2.0D, -2.0D, -3.0D, -3.0D, -6.0D, -1.0D, 0.0D, -2.0D, 1.0D, 
/* 828 */         -1.0D, 0.0D, -2.0D, -3.0D, -2.0D, -3.0D, -3.0D, -6.0D, -2.0D, -1.0D, -1.0D, -2.0D, -1.0D, -2.0D, 0.0D, 1.0D, 
/* 829 */         0.0D, -1.0D, -1.0D, 0.0D, -1.0D, 0.0D, -2.0D, 1.0D, -1.0D, -2.0D, 0.0D, 1.0D, 0.0D, 1.0D, 1.0D, 0.0D };
/*     */ 
/*     */     
/* 832 */     for (int i = 0; i < lut.length; i++)
/*     */     {
/* 834 */       lut[i] = lut[i] / 8.0D;
/*     */     }
/*     */     
/* 837 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] eulerNumberLutC26() {
/* 848 */     double[] lut = { 
/* 849 */         0.0D, 1.0D, 1.0D, 0.0D, 1.0D, 0.0D, -2.0D, -1.0D, 1.0D, 2.0D, 0.0D, -1.0D, 0.0D, -1.0D, -1.0D, 0.0D, 
/* 850 */         1.0D, 0.0D, -2.0D, -1.0D, 2.0D, -1.0D, -1.0D, -2.0D, -6.0D, -3.0D, -3.0D, -2.0D, -3.0D, -2.0D, 0.0D, -1.0D, 
/* 851 */         1.0D, -2.0D, 0.0D, -1.0D, -6.0D, -3.0D, -3.0D, -2.0D, -2.0D, -1.0D, -1.0D, -2.0D, -3.0D, 0.0D, -2.0D, -1.0D, 
/* 852 */         0.0D, -1.0D, -1.0D, 0.0D, -3.0D, -2.0D, 0.0D, -1.0D, -3.0D, 0.0D, -2.0D, -1.0D, 0.0D, 1.0D, 1.0D, 0.0D, 
/* 853 */         1.0D, -2.0D, -6.0D, -3.0D, 0.0D, -1.0D, -3.0D, -2.0D, -2.0D, -1.0D, -3.0D, 0.0D, -1.0D, -2.0D, -2.0D, -1.0D, 
/* 854 */         0.0D, -1.0D, -3.0D, -2.0D, -1.0D, 0.0D, 0.0D, -1.0D, -3.0D, 0.0D, 0.0D, 1.0D, -2.0D, -1.0D, 1.0D, 0.0D, 
/* 855 */         -2.0D, -1.0D, -3.0D, 0.0D, -3.0D, 0.0D, 0.0D, 1.0D, -1.0D, 4.0D, 0.0D, 3.0D, 0.0D, 3.0D, 1.0D, 2.0D, 
/* 856 */         -1.0D, -2.0D, -2.0D, -1.0D, -2.0D, -1.0D, 1.0D, 0.0D, 0.0D, 3.0D, 1.0D, 2.0D, 1.0D, 2.0D, 2.0D, 1.0D, 
/*     */         
/* 858 */         1.0D, -6.0D, -2.0D, -3.0D, -2.0D, -3.0D, -1.0D, 0.0D, 0.0D, -3.0D, -1.0D, -2.0D, -1.0D, -2.0D, -2.0D, -1.0D, 
/* 859 */         -2.0D, -3.0D, -1.0D, 0.0D, -1.0D, 0.0D, 4.0D, 3.0D, -3.0D, 0.0D, 0.0D, 1.0D, 0.0D, 1.0D, 3.0D, 2.0D, 
/* 860 */         0.0D, -3.0D, -1.0D, -2.0D, -3.0D, 0.0D, 0.0D, 1.0D, -1.0D, 0.0D, 0.0D, -1.0D, -2.0D, 1.0D, -1.0D, 0.0D, 
/* 861 */         -1.0D, -2.0D, -2.0D, -1.0D, 0.0D, 1.0D, 3.0D, 2.0D, -2.0D, 1.0D, -1.0D, 0.0D, 1.0D, 2.0D, 2.0D, 1.0D, 
/* 862 */         0.0D, -3.0D, -3.0D, 0.0D, -1.0D, -2.0D, 0.0D, 1.0D, -1.0D, 0.0D, -2.0D, 1.0D, 0.0D, -1.0D, -1.0D, 0.0D, 
/* 863 */         -1.0D, -2.0D, 0.0D, 1.0D, -2.0D, -1.0D, 3.0D, 2.0D, -2.0D, 1.0D, 1.0D, 2.0D, -1.0D, 0.0D, 2.0D, 1.0D, 
/* 864 */         -1.0D, 0.0D, -2.0D, 1.0D, -2.0D, 1.0D, 1.0D, 2.0D, -2.0D, 3.0D, -1.0D, 2.0D, -1.0D, 2.0D, 0.0D, 1.0D, 
/* 865 */         0.0D, -1.0D, -1.0D, 0.0D, -1.0D, 0.0D, 2.0D, 1.0D, -1.0D, 2.0D, 0.0D, 1.0D, 0.0D, 1.0D, 1.0D, 0.0D };
/*     */ 
/*     */     
/* 868 */     for (int i = 0; i < lut.length; i++)
/*     */     {
/* 870 */       lut[i] = lut[i] / 8.0D;
/*     */     }
/*     */     
/* 873 */     return lut;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double samplingVolume(ImageStack image, Calibration calib) {
/* 879 */     int sizeX = image.getWidth();
/* 880 */     int sizeY = image.getHeight();
/* 881 */     int sizeZ = image.getSize();
/* 882 */     return (sizeX - 1) * calib.pixelWidth * (sizeY - 1) * calib.pixelHeight * (sizeZ - 1) * calib.pixelDepth;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/IntrinsicVolumes3DUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */