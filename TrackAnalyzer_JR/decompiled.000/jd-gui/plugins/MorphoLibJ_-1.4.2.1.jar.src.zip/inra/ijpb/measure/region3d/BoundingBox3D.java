/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.geometry.Box3D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingBox3D
/*     */   extends RegionAnalyzer3D<Box3D>
/*     */ {
/*     */   public static final Box3D[] boundingBoxes(ImageStack labelImage, int[] labels, Calibration calib) {
/*  41 */     return (new BoundingBox3D()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box3D[] analyzeRegions(ImageStack image, int[] labels, Calibration calib) {
/*  73 */     int sizeX = image.getWidth();
/*  74 */     int sizeY = image.getHeight();
/*  75 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/*  78 */     double sx = 1.0D, sy = 1.0D, sz = 1.0D;
/*  79 */     double ox = 0.0D, oy = 0.0D, oz = 0.0D;
/*  80 */     if (calib != null) {
/*     */       
/*  82 */       sx = calib.pixelWidth;
/*  83 */       sy = calib.pixelHeight;
/*  84 */       sz = calib.pixelDepth;
/*  85 */       ox = calib.xOrigin;
/*  86 */       oy = calib.yOrigin;
/*  87 */       oz = calib.zOrigin;
/*     */     } 
/*     */ 
/*     */     
/*  91 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/*  94 */     int nLabels = labels.length;
/*  95 */     double[] xmin = new double[nLabels];
/*  96 */     double[] xmax = new double[nLabels];
/*  97 */     double[] ymin = new double[nLabels];
/*  98 */     double[] ymax = new double[nLabels];
/*  99 */     double[] zmin = new double[nLabels];
/* 100 */     double[] zmax = new double[nLabels];
/*     */ 
/*     */     
/* 103 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 105 */       xmin[i] = Double.POSITIVE_INFINITY;
/* 106 */       xmax[i] = Double.NEGATIVE_INFINITY;
/* 107 */       ymin[i] = Double.POSITIVE_INFINITY;
/* 108 */       ymax[i] = Double.NEGATIVE_INFINITY;
/* 109 */       zmin[i] = Double.POSITIVE_INFINITY;
/* 110 */       zmax[i] = Double.NEGATIVE_INFINITY;
/*     */     } 
/*     */ 
/*     */     
/* 114 */     fireStatusChanged(this, "Compute bounds");
/* 115 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 117 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 119 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 121 */           int label = (int)image.getVoxel(x, y, z);
/* 122 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/* 126 */             if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */               
/* 128 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */               
/* 130 */               xmin[index] = Math.min(xmin[index], x);
/* 131 */               xmax[index] = Math.max(xmax[index], (x + 1));
/* 132 */               ymin[index] = Math.min(ymin[index], y);
/* 133 */               ymax[index] = Math.max(ymax[index], (y + 1));
/* 134 */               zmin[index] = Math.min(zmin[index], z);
/* 135 */               zmax[index] = Math.max(zmax[index], (z + 1));
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 141 */     Box3D[] boxes = new Box3D[nLabels];
/* 142 */     for (int j = 0; j < nLabels; j++)
/*     */     {
/* 144 */       boxes[j] = new Box3D(
/* 145 */           xmin[j] * sx + ox, xmax[j] * sx + ox, 
/* 146 */           ymin[j] * sy + oy, ymax[j] * sy + oy, 
/* 147 */           zmin[j] * sz + oz, zmax[j] * sz + oz);
/*     */     }
/* 149 */     return boxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Box3D> map) {
/* 163 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 167 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 170 */       Box3D box = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 173 */       table.incrementCounter();
/* 174 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 177 */       table.addValue("Box.XMin", box.getXMin());
/* 178 */       table.addValue("Box.XMax", box.getXMax());
/* 179 */       table.addValue("Box.YMin", box.getYMin());
/* 180 */       table.addValue("Box.YMax", box.getYMax());
/* 181 */       table.addValue("Box.ZMin", box.getZMin());
/* 182 */       table.addValue("Box.ZMax", box.getZMax()); }
/*     */ 
/*     */     
/* 185 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/BoundingBox3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */