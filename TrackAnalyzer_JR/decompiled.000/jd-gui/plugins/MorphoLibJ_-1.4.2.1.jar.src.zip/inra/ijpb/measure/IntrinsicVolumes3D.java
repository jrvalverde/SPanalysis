/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region3d.BinaryConfigurationsHistogram3D;
/*     */ import inra.ijpb.measure.region3d.InterfaceSurfaceArea;
/*     */ import inra.ijpb.measure.region3d.IntrinsicVolumes3DUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumes3D
/*     */ {
/*     */   public static final double volume(ImageStack image, Calibration calib) {
/*  52 */     double voxelVolume = calib.pixelWidth * calib.pixelHeight * calib.pixelDepth;
/*     */ 
/*     */     
/*  55 */     int voxelCount = BinaryImages.countForegroundVoxels(image);
/*     */ 
/*     */     
/*  58 */     double volume = voxelCount * voxelVolume;
/*  59 */     return volume;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] volumes(ImageStack labelImage, int[] labels, Calibration calib) {
/*  76 */     int nLabels = labels.length;
/*     */ 
/*     */     
/*  79 */     double voxelVolume = calib.pixelWidth * calib.pixelHeight * calib.pixelDepth;
/*     */ 
/*     */     
/*  82 */     int[] voxelCounts = LabelImages.voxelCount(labelImage, labels);
/*     */ 
/*     */     
/*  85 */     double[] volumes = new double[nLabels];
/*  86 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/*  88 */       volumes[i] = voxelCounts[i] * voxelVolume;
/*     */     }
/*  90 */     return volumes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double volumeDensity(ImageStack image) {
/* 103 */     double voxelCount = BinaryImages.countForegroundVoxels(image);
/*     */ 
/*     */     
/* 106 */     double voxelNumber = (image.getWidth() * image.getWidth() * image.getSize());
/* 107 */     return voxelCount / voxelNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double interfaceSurfaceArea(ImageStack image, int label1, int label2, Calibration calib, int nDirs) {
/* 129 */     InterfaceSurfaceArea algo = new InterfaceSurfaceArea(nDirs);
/* 130 */     return algo.process(image, label1, label2, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double surfaceArea(ImageStack image, Calibration calib, int nDirs) {
/* 150 */     double[] lut = IntrinsicVolumes3DUtils.surfaceAreaLut(calib, nDirs);
/*     */ 
/*     */ 
/*     */     
/* 154 */     int[] histo = (new BinaryConfigurationsHistogram3D()).process(image);
/* 155 */     return BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] surfaceAreas(ImageStack image, int[] labels, Calibration calib, int nDirs) {
/* 179 */     double[] lut = IntrinsicVolumes3DUtils.surfaceAreaLut(calib, nDirs);
/*     */ 
/*     */ 
/*     */     
/* 183 */     int[][] histos = (new BinaryConfigurationsHistogram3D()).process(image, labels);
/* 184 */     return BinaryConfigurationsHistogram3D.applyLut(histos, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double surfaceAreaDensity(ImageStack image, Calibration calib, int nDirs) {
/* 204 */     double[] lut = IntrinsicVolumes3DUtils.surfaceAreaLut(calib, nDirs);
/*     */ 
/*     */ 
/*     */     
/* 208 */     int[] histo = (new BinaryConfigurationsHistogram3D()).processInnerFrame(image);
/* 209 */     double surf = BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */ 
/*     */     
/* 212 */     double vol = samplingVolume(image, calib);
/* 213 */     return surf / vol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double sphericity(double volume, double surface) {
/* 239 */     double c = 113.09733552923255D;
/*     */ 
/*     */     
/* 242 */     return c * volume * volume / surface * surface * surface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] sphericity(double[] volumes, double[] surfaces) {
/* 267 */     int n = volumes.length;
/* 268 */     if (surfaces.length != n)
/*     */     {
/* 270 */       throw new IllegalArgumentException("Volume and surface arrays must have the same length");
/*     */     }
/*     */ 
/*     */     
/* 274 */     double[] sphericities = new double[n];
/* 275 */     for (int i = 0; i < n; i++)
/*     */     {
/* 277 */       sphericities[i] = sphericity(volumes[i], surfaces[i]);
/*     */     }
/*     */     
/* 280 */     return sphericities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double meanBreadth(ImageStack image, Calibration calib, int nDirs, int conn2d) {
/* 302 */     double[] lut = IntrinsicVolumes3DUtils.meanBreadthLut(calib, nDirs, conn2d);
/*     */ 
/*     */ 
/*     */     
/* 306 */     int[] histo = (new BinaryConfigurationsHistogram3D()).process(image);
/* 307 */     return BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] meanBreadths(ImageStack image, int[] labels, Calibration calib, int nDirs, int conn2d) {
/* 333 */     double[] lut = IntrinsicVolumes3DUtils.meanBreadthLut(calib, nDirs, conn2d);
/*     */ 
/*     */ 
/*     */     
/* 337 */     int[][] histos = (new BinaryConfigurationsHistogram3D()).process(image, labels);
/* 338 */     return BinaryConfigurationsHistogram3D.applyLut(histos, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double meanBreadthDensity(ImageStack image, Calibration calib, int nDirs, int conn2d) {
/* 360 */     double[] lut = IntrinsicVolumes3DUtils.meanBreadthLut(calib, nDirs, conn2d);
/*     */ 
/*     */ 
/*     */     
/* 364 */     int[] histo = (new BinaryConfigurationsHistogram3D()).processInnerFrame(image);
/* 365 */     double meanBreadth = BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */ 
/*     */     
/* 368 */     double vol = samplingVolume(image, calib);
/* 369 */     return meanBreadth / vol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double eulerNumber(ImageStack image, int conn) {
/* 385 */     double[] lut = IntrinsicVolumes3DUtils.eulerNumberLut(conn);
/*     */ 
/*     */ 
/*     */     
/* 389 */     int[] histo = (new BinaryConfigurationsHistogram3D()).process(image);
/* 390 */     return BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] eulerNumbers(ImageStack image, int[] labels, int conn) {
/* 409 */     double[] lut = IntrinsicVolumes3DUtils.eulerNumberLut(conn);
/*     */ 
/*     */ 
/*     */     
/* 413 */     int[][] histos = (new BinaryConfigurationsHistogram3D()).process(image, labels);
/* 414 */     return BinaryConfigurationsHistogram3D.applyLut(histos, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double eulerNumberDensity(ImageStack image, Calibration calib, int conn) {
/* 432 */     double[] lut = IntrinsicVolumes3DUtils.eulerNumberLut(conn);
/*     */ 
/*     */ 
/*     */     
/* 436 */     int[] histo = (new BinaryConfigurationsHistogram3D()).processInnerFrame(image);
/* 437 */     double euler = BinaryConfigurationsHistogram3D.applyLut(histo, lut);
/*     */ 
/*     */     
/* 440 */     double vol = samplingVolume(image, calib);
/* 441 */     return euler / vol;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double samplingVolume(ImageStack image, Calibration calib) {
/* 447 */     int sizeX = image.getWidth();
/* 448 */     int sizeY = image.getHeight();
/* 449 */     int sizeZ = image.getSize();
/* 450 */     return (sizeX - 1) * calib.pixelWidth * (sizeY - 1) * calib.pixelHeight * (sizeZ - 1) * calib.pixelDepth;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/IntrinsicVolumes3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */