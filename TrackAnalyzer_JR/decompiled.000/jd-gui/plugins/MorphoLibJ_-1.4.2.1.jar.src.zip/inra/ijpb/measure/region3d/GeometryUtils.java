/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import inra.ijpb.geometry.Vector3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeometryUtils
/*     */ {
/*     */   public static final double sphericalVoronoiDomainArea(Vector3D germ, Vector3D[] neighbors) {
/*  44 */     germ = germ.normalize();
/*     */     
/*  46 */     int nNeighbors = neighbors.length;
/*     */ 
/*     */ 
/*     */     
/*  50 */     Vector3D[] planeNormals = new Vector3D[nNeighbors];
/*  51 */     for (int i = 0; i < nNeighbors; i++)
/*     */     {
/*  53 */       planeNormals[i] = neighbors[i].normalize().minus(germ).normalize();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  58 */     Vector3D[] lineDirections = new Vector3D[nNeighbors];
/*  59 */     for (int j = 0; j < nNeighbors; j++) {
/*     */       
/*  61 */       Vector3D v1 = planeNormals[j];
/*  62 */       Vector3D v2 = planeNormals[(j + 1) % nNeighbors];
/*  63 */       lineDirections[j] = Vector3D.crossProduct(v1, v2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  68 */     double[] angles = new double[nNeighbors];
/*  69 */     for (int k = 0; k < nNeighbors; k++) {
/*     */       
/*  71 */       Vector3D v1 = lineDirections[k];
/*  72 */       Vector3D v2 = lineDirections[(k + 1) % nNeighbors];
/*  73 */       Vector3D v3 = lineDirections[(k + 2) % nNeighbors];
/*  74 */       angles[k] = sphericalAngle(v1, v2, v3);
/*     */ 
/*     */       
/*  77 */       if (angles[k] > Math.PI)
/*     */       {
/*  79 */         angles[k] = 6.283185307179586D - angles[k];
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  85 */     double area = 0.0D;
/*  86 */     for (int m = 0; m < nNeighbors; m++)
/*     */     {
/*  88 */       area += angles[m];
/*     */     }
/*  90 */     area -= Math.PI * (nNeighbors - 2);
/*     */     
/*  92 */     return area;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double sphericalAngle(Vector3D v1, Vector3D v2, Vector3D v3) {
/*  98 */     Vector3D normal12 = Vector3D.crossProduct(v1, v2);
/*  99 */     Vector3D normal23 = Vector3D.crossProduct(v2, v3);
/*     */ 
/*     */     
/* 102 */     Vector3D v21o = Vector3D.crossProduct(v2, normal12);
/* 103 */     Vector3D v23o = Vector3D.crossProduct(normal23, v2);
/*     */ 
/*     */     
/* 106 */     double theta = Vector3D.angle(v21o, v23o);
/*     */     
/* 108 */     return theta;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/GeometryUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */