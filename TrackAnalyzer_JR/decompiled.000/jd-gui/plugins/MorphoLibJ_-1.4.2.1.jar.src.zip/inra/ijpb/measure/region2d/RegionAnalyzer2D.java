/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.RegionAnalyzer;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegionAnalyzer2D<T>
/*     */   extends AlgoStub
/*     */   implements RegionAnalyzer<T>
/*     */ {
/*     */   public abstract T[] analyzeRegions(ImageProcessor paramImageProcessor, int[] paramArrayOfint, Calibration paramCalibration);
/*     */   
/*     */   public Map<Integer, T> analyzeRegions(ImageProcessor image, Calibration calib) {
/*  56 */     fireStatusChanged(this, "Find Labels");
/*  57 */     int[] labels = LabelImages.findAllLabels(image);
/*  58 */     int nLabels = labels.length;
/*     */ 
/*     */     
/*  61 */     fireStatusChanged(this, "Analyze regions");
/*  62 */     Object[] results = (Object[])analyzeRegions(image, labels, calib);
/*     */ 
/*     */     
/*  65 */     fireStatusChanged(this, "Convert to map");
/*  66 */     Map<Integer, T> map = new TreeMap<Integer, T>();
/*  67 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/*  69 */       map.put(Integer.valueOf(labels[i]), (T)results[i]);
/*     */     }
/*     */     
/*  72 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, T> analyzeRegions(ImagePlus labelPlus) {
/*  88 */     ImageProcessor labelImage = labelPlus.getProcessor();
/*  89 */     int[] labels = LabelImages.findAllLabels(labelImage);
/*     */     
/*  91 */     Object[] results = (Object[])analyzeRegions(labelImage, labels, labelPlus.getCalibration());
/*     */ 
/*     */     
/*  94 */     Map<Integer, T> map = new TreeMap<Integer, T>();
/*  95 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/*  97 */       map.put(Integer.valueOf(labels[i]), (T)results[i]);
/*     */     }
/*     */     
/* 100 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable computeTable(ImagePlus labelPlus) {
/* 115 */     return createTable(analyzeRegions(labelPlus));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/RegionAnalyzer2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */