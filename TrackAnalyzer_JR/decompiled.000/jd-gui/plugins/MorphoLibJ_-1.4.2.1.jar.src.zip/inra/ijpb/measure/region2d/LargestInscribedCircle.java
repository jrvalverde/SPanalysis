/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.geometry.Circle2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LargestInscribedCircle
/*     */   extends RegionAnalyzer2D<Circle2D>
/*     */ {
/*     */   public static final Circle2D[] largestInscribedCircles(ImageProcessor labelImage, int[] labels, Calibration calib) {
/*  43 */     return (new LargestInscribedCircle()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Circle2D> map) {
/*  67 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/*  71 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  74 */       Circle2D circle = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  77 */       table.incrementCounter();
/*  78 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/*  81 */       table.addValue("InscrCircle.Center.X", circle.getCenter().getX());
/*  82 */       table.addValue("InscrCircle.Center.Y", circle.getCenter().getY());
/*     */ 
/*     */       
/*  85 */       table.addValue("InscrCircle.Radius", circle.getRadius()); }
/*     */ 
/*     */     
/*  88 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Circle2D[] analyzeRegions(ImageProcessor labelImage, int[] labels, Calibration calib) {
/* 107 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 110 */     fireStatusChanged(this, "Compute distance map");
/* 111 */     ImageProcessor distanceMap = BinaryImages.distanceMap(labelImage);
/*     */ 
/*     */     
/* 114 */     fireStatusChanged(this, "Find inscribed disks center");
/*     */     
/* 116 */     Point[] posCenter = findPositionOfMaxValues(distanceMap, labelImage, labels);
/* 117 */     float[] radii = getValues(distanceMap, posCenter);
/*     */ 
/*     */     
/* 120 */     Circle2D[] circles = new Circle2D[nLabels];
/* 121 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 123 */       double xc = (posCenter[i]).x * calib.pixelWidth + calib.xOrigin;
/* 124 */       double yc = (posCenter[i]).y * calib.pixelHeight + calib.yOrigin;
/* 125 */       Point2D center = new Point2D.Double(xc, yc);
/* 126 */       circles[i] = new Circle2D(center, radii[i] * calib.pixelWidth);
/*     */     } 
/*     */     
/* 129 */     return circles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final float[] getValues(ImageProcessor image, Point[] positions) {
/* 145 */     float[] values = new float[positions.length];
/*     */ 
/*     */     
/* 148 */     for (int i = 0; i < positions.length; i++)
/*     */     {
/* 150 */       values[i] = image.getf((positions[i]).x, (positions[i]).y);
/*     */     }
/*     */     
/* 153 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Point[] findPositionOfMaxValues(ImageProcessor image, ImageProcessor labelImage, int[] labels) {
/* 171 */     int width = labelImage.getWidth();
/* 172 */     int height = labelImage.getHeight();
/*     */ 
/*     */     
/* 175 */     int nbLabel = labels.length;
/* 176 */     int maxLabel = 0;
/* 177 */     for (int i = 0; i < nbLabel; i++)
/*     */     {
/* 179 */       maxLabel = Math.max(maxLabel, labels[i]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 184 */     int[] labelIndex = new int[maxLabel + 1];
/* 185 */     for (int j = 0; j < nbLabel; j++)
/*     */     {
/* 187 */       labelIndex[labels[j]] = j;
/*     */     }
/*     */ 
/*     */     
/* 191 */     Point[] posMax = new Point[nbLabel];
/* 192 */     int[] maxValues = new int[nbLabel];
/* 193 */     for (int k = 0; k < nbLabel; k++) {
/*     */       
/* 195 */       maxValues[k] = -1;
/* 196 */       posMax[k] = new Point(-1, -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     for (int y = 0; y < height; y++) {
/*     */       
/* 206 */       for (int x = 0; x < width; x++) {
/*     */         
/* 208 */         int label = (int)labelImage.getf(x, y);
/*     */ 
/*     */         
/* 211 */         if (label != 0) {
/*     */ 
/*     */           
/* 214 */           int index = labelIndex[label];
/*     */ 
/*     */           
/* 217 */           int value = image.get(x, y);
/* 218 */           if (value > maxValues[index]) {
/*     */             
/* 220 */             posMax[index].setLocation(x, y);
/* 221 */             maxValues[index] = value;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 226 */     return posMax;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/LargestInscribedCircle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */