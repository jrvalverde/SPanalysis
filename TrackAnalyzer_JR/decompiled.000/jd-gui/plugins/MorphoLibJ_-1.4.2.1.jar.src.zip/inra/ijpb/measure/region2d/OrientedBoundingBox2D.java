/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.geometry.AngleDiameterPair;
/*     */ import inra.ijpb.geometry.FeretDiameters;
/*     */ import inra.ijpb.geometry.OrientedBox2D;
/*     */ import inra.ijpb.geometry.Polygon2D;
/*     */ import inra.ijpb.geometry.Polygons2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrientedBoundingBox2D
/*     */   extends RegionAnalyzer2D<OrientedBox2D>
/*     */ {
/*     */   public static final OrientedBox2D orientedBoundingBox(ArrayList<? extends Point2D> points) {
/*  38 */     Polygon2D convexHull = Polygons2D.convexHull(points);
/*     */ 
/*     */     
/*  41 */     Point2D center = convexHull.centroid();
/*  42 */     double cx = center.getX();
/*  43 */     double cy = center.getY();
/*     */     
/*  45 */     AngleDiameterPair minFeret = FeretDiameters.minFeretDiameter(convexHull.vertices());
/*     */ 
/*     */     
/*  48 */     ArrayList<Point2D> centeredHull = new ArrayList<Point2D>(convexHull.vertexNumber());
/*  49 */     for (Point2D p : convexHull)
/*     */     {
/*  51 */       centeredHull.add(new Point2D.Double(p.getX() - cx, p.getY() - cy));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  56 */     double cot = Math.cos(minFeret.angle);
/*  57 */     double sit = Math.sin(minFeret.angle);
/*     */ 
/*     */     
/*  60 */     double xmin = Double.MAX_VALUE;
/*  61 */     double ymin = Double.MAX_VALUE;
/*  62 */     double xmax = Double.MIN_VALUE;
/*  63 */     double ymax = Double.MIN_VALUE;
/*  64 */     for (Point2D p : centeredHull) {
/*     */ 
/*     */       
/*  67 */       double x = p.getX();
/*  68 */       double y = p.getY();
/*     */ 
/*     */       
/*  71 */       double x2 = x * cot + y * sit;
/*  72 */       double y2 = -x * sit + y * cot;
/*     */ 
/*     */       
/*  75 */       xmin = Math.min(xmin, x2);
/*  76 */       ymin = Math.min(ymin, y2);
/*  77 */       xmax = Math.max(xmax, x2);
/*  78 */       ymax = Math.max(ymax, y2);
/*     */     } 
/*     */ 
/*     */     
/*  82 */     double dl = (xmax + xmin) / 2.0D;
/*  83 */     double dw = (ymax + ymin) / 2.0D;
/*     */ 
/*     */     
/*  86 */     double dx = dl * cot - dw * sit;
/*  87 */     double dy = dl * sit + dw * cot;
/*     */ 
/*     */     
/*  90 */     cx += dx;
/*  91 */     cy += dy;
/*     */ 
/*     */     
/*  94 */     double length = ymax - ymin;
/*  95 */     double width = xmax - xmin;
/*     */ 
/*     */     
/*  98 */     double angle = (Math.toDegrees(minFeret.angle) + 270.0D) % 180.0D;
/*     */ 
/*     */     
/* 101 */     return new OrientedBox2D(cx, cy, length, width, angle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final OrientedBox2D orientedBoundingBox(ArrayList<? extends Point2D> points, Calibration calib) {
/* 119 */     Polygon2D convexHull = Polygons2D.convexHull(points);
/*     */     
/* 121 */     Polygon2D calibratedHull = new Polygon2D(calibrate(convexHull.vertices(), calib));
/*     */ 
/*     */     
/* 124 */     Point2D center = calibratedHull.centroid();
/* 125 */     double cx = center.getX();
/* 126 */     double cy = center.getY();
/*     */ 
/*     */     
/* 129 */     ArrayList<Point2D> centeredHull = new ArrayList<Point2D>(convexHull.vertexNumber());
/* 130 */     for (Point2D p : calibratedHull) {
/*     */       
/* 132 */       double x = p.getX() - cx;
/* 133 */       double y = p.getY() - cy;
/* 134 */       centeredHull.add(new Point2D.Double(x, y));
/*     */     } 
/*     */     
/* 137 */     AngleDiameterPair minFeret = FeretDiameters.minFeretDiameter(centeredHull);
/*     */ 
/*     */ 
/*     */     
/* 141 */     double cot = Math.cos(minFeret.angle);
/* 142 */     double sit = Math.sin(minFeret.angle);
/*     */ 
/*     */     
/* 145 */     double xmin = Double.MAX_VALUE;
/* 146 */     double ymin = Double.MAX_VALUE;
/* 147 */     double xmax = Double.MIN_VALUE;
/* 148 */     double ymax = Double.MIN_VALUE;
/* 149 */     for (Point2D p : centeredHull) {
/*     */ 
/*     */       
/* 152 */       double x = p.getX();
/* 153 */       double y = p.getY();
/*     */ 
/*     */       
/* 156 */       double x2 = x * cot + y * sit;
/* 157 */       double y2 = -x * sit + y * cot;
/*     */ 
/*     */       
/* 160 */       xmin = Math.min(xmin, x2);
/* 161 */       ymin = Math.min(ymin, y2);
/* 162 */       xmax = Math.max(xmax, x2);
/* 163 */       ymax = Math.max(ymax, y2);
/*     */     } 
/*     */ 
/*     */     
/* 167 */     double dl = (xmax + xmin) / 2.0D;
/* 168 */     double dw = (ymax + ymin) / 2.0D;
/*     */ 
/*     */     
/* 171 */     double dx = dl * cot - dw * sit;
/* 172 */     double dy = dl * sit + dw * cot;
/*     */ 
/*     */     
/* 175 */     cx += dx;
/* 176 */     cy += dy;
/*     */ 
/*     */     
/* 179 */     double length = ymax - ymin;
/* 180 */     double width = xmax - xmin;
/*     */ 
/*     */     
/* 183 */     double angle = (Math.toDegrees(minFeret.angle) + 270.0D) % 180.0D;
/*     */ 
/*     */     
/* 186 */     return new OrientedBox2D(cx, cy, length, width, angle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, OrientedBox2D> results) {
/* 206 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/* 209 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */       
/* 211 */       table.incrementCounter();
/* 212 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 215 */       OrientedBox2D obox = results.get(Integer.valueOf(label));
/* 216 */       Point2D center = obox.center();
/* 217 */       table.addValue("Box.Center.X", center.getX());
/* 218 */       table.addValue("Box.Center.Y", center.getY());
/* 219 */       table.addValue("Box.Length", obox.length());
/* 220 */       table.addValue("Box.Width", obox.width());
/* 221 */       table.addValue("Box.Orientation", obox.orientation()); }
/*     */ 
/*     */     
/* 224 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OrientedBox2D[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/* 232 */     fireStatusChanged(this, "Find Label Corner Points");
/* 233 */     ArrayList[] cornerPointsArrays = (ArrayList[])RegionBoundaries.runlengthsCorners(image, labels);
/*     */ 
/*     */     
/* 236 */     int nLabels = labels.length;
/* 237 */     OrientedBox2D[] boxes = new OrientedBox2D[nLabels];
/*     */ 
/*     */     
/* 240 */     fireStatusChanged(this, "Compute oriented boxes");
/* 241 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 243 */       fireProgressChanged(this, i, nLabels);
/*     */       
/* 245 */       boxes[i] = orientedBoundingBox(cornerPointsArrays[i], calib);
/*     */     } 
/*     */     
/* 248 */     fireStatusChanged(this, "");
/* 249 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */     
/* 251 */     return boxes;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final ArrayList<Point2D> calibrate(ArrayList<Point2D> points, Calibration calib) {
/* 256 */     if (!calib.scaled())
/*     */     {
/* 258 */       return points;
/*     */     }
/*     */     
/* 261 */     ArrayList<Point2D> res = new ArrayList<Point2D>(points.size());
/* 262 */     for (Point2D point : points) {
/*     */       
/* 264 */       double x = point.getX() * calib.pixelWidth + calib.xOrigin;
/* 265 */       double y = point.getY() * calib.pixelHeight + calib.yOrigin;
/* 266 */       res.add(new Point2D.Double(x, y));
/*     */     } 
/* 268 */     return res;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/OrientedBoundingBox2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */