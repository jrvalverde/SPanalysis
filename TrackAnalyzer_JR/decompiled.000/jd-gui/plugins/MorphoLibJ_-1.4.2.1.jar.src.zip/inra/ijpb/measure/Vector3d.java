/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Vector3d
/*     */ {
/*     */   private final double x;
/*     */   private final double y;
/*     */   private final double z;
/*     */   
/*     */   public Vector3d() {
/*  55 */     this.x = 0.0D;
/*  56 */     this.y = 0.0D;
/*  57 */     this.z = 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d(double x, double y, double z) {
/*  69 */     this.x = x;
/*  70 */     this.y = y;
/*  71 */     this.z = z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Vector3d crossProduct(Vector3d v1, Vector3d v2) {
/*  88 */     return new Vector3d(
/*  89 */         v1.y * v2.z - v1.z * v2.y, 
/*  90 */         v1.z * v2.x - v1.x * v2.z, 
/*  91 */         v1.x * v2.y - v1.y * v2.x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double dotProduct(Vector3d v1, Vector3d v2) {
/* 109 */     return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double angle(Vector3d v1, Vector3d v2) {
/* 125 */     double norm = crossProduct(v1, v2).getNorm();
/* 126 */     double det = dotProduct(v1, v2);
/* 127 */     return Math.atan2(norm, det);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/* 141 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/* 151 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZ() {
/* 161 */     return this.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d plus(Vector3d v) {
/* 175 */     double x = this.x + v.x;
/* 176 */     double y = this.y + v.y;
/* 177 */     double z = this.z + v.z;
/* 178 */     return new Vector3d(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d minus(Vector3d v) {
/* 189 */     double x = this.x - v.x;
/* 190 */     double y = this.y - v.y;
/* 191 */     double z = this.z - v.z;
/* 192 */     return new Vector3d(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d times(double k) {
/* 204 */     double x = this.x * k;
/* 205 */     double y = this.y * k;
/* 206 */     double z = this.z * k;
/* 207 */     return new Vector3d(x, y, z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d normalize() {
/* 217 */     double norm = getNorm();
/* 218 */     return new Vector3d(this.x / norm, this.y / norm, this.z / norm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getNorm() {
/* 229 */     double norm = Math.hypot(this.x, this.y);
/* 230 */     norm = Math.hypot(norm, this.z);
/* 231 */     return norm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean almostEquals(Vector3d v, double eps) {
/* 246 */     if (Math.abs(this.x - v.x) > eps) return false; 
/* 247 */     if (Math.abs(this.y - v.y) > eps) return false; 
/* 248 */     if (Math.abs(this.z - v.z) > eps) return false; 
/* 249 */     return true;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/Vector3d.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */