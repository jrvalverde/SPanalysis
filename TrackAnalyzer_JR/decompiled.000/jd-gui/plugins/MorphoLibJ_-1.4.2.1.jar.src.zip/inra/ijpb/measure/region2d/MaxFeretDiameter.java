/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.geometry.FeretDiameters;
/*     */ import inra.ijpb.geometry.PointPair2D;
/*     */ import inra.ijpb.geometry.Polygon2D;
/*     */ import inra.ijpb.geometry.Polygons2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxFeretDiameter
/*     */   extends RegionAnalyzer2D<PointPair2D>
/*     */ {
/*     */   public static final PointPair2D[] maxFeretDiameters(ImageProcessor image, int[] labels, Calibration calib) {
/*  31 */     return (new MaxFeretDiameter()).analyzeRegions(image, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, PointPair2D> maxDiamsMap) {
/*  59 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/*  62 */     for (Iterator<Integer> iterator = maxDiamsMap.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */       
/*  64 */       table.incrementCounter();
/*  65 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/*  68 */       PointPair2D maxDiam = maxDiamsMap.get(Integer.valueOf(label));
/*  69 */       table.addValue("Diameter", maxDiam.diameter());
/*  70 */       table.addValue("Orientation", Math.toDegrees(maxDiam.angle()));
/*  71 */       table.addValue("P1.x", maxDiam.p1.getX());
/*  72 */       table.addValue("P1.y", maxDiam.p1.getY());
/*  73 */       table.addValue("P2.x", maxDiam.p2.getX());
/*  74 */       table.addValue("p2.y", maxDiam.p2.getY()); }
/*     */ 
/*     */ 
/*     */     
/*  78 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointPair2D[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/*  99 */     if (image == null) {
/* 100 */       return null;
/*     */     }
/*     */     
/* 103 */     double sx = 1.0D, sy = 1.0D;
/* 104 */     double ox = 0.0D, oy = 0.0D;
/* 105 */     if (calib != null) {
/*     */       
/* 107 */       sx = calib.pixelWidth;
/* 108 */       sy = calib.pixelHeight;
/* 109 */       ox = calib.xOrigin;
/* 110 */       oy = calib.yOrigin;
/*     */     } 
/*     */     
/* 113 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 116 */     fireStatusChanged(this, "Find Label Corner Points");
/* 117 */     ArrayList[] cornerPointsArrays = (ArrayList[])RegionBoundaries.runlengthsCorners(image, labels);
/*     */ 
/*     */     
/* 120 */     PointPair2D[] labelMaxDiams = new PointPair2D[nLabels];
/* 121 */     fireStatusChanged(this, "Compute feret Diameters");
/* 122 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 124 */       fireProgressChanged(this, i, nLabels);
/*     */       
/* 126 */       ArrayList<Point2D> corners = cornerPointsArrays[i];
/*     */       
/* 128 */       for (int iv = 0; iv < corners.size(); iv++) {
/*     */         
/* 130 */         Point2D vertex = corners.get(iv);
/* 131 */         vertex = new Point2D.Double(vertex.getX() * sx + ox, vertex.getY() * sy + oy);
/* 132 */         corners.set(iv, vertex);
/*     */       } 
/*     */ 
/*     */       
/* 136 */       labelMaxDiams[i] = FeretDiameters.maxFeretDiameter(corners);
/*     */     } 
/*     */     
/* 139 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 140 */     fireStatusChanged(this, "");
/* 141 */     return labelMaxDiams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointPair2D analyzeBinary(ImageProcessor image, double[] calib) {
/* 159 */     ArrayList<Point2D> points = RegionBoundaries.runLengthsCorners(image);
/* 160 */     Polygon2D convHull = Polygons2D.convexHull(points);
/*     */ 
/*     */     
/* 163 */     for (int i = 0; i < convHull.vertexNumber(); i++) {
/*     */       
/* 165 */       Point2D vertex = convHull.getVertex(i);
/* 166 */       vertex = new Point2D.Double(vertex.getX() * calib[0], vertex.getY() * calib[1]);
/* 167 */       convHull.setVertex(i, vertex);
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return FeretDiameters.maxFeretDiameter(convHull.vertices());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/MaxFeretDiameter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */