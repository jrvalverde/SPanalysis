/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.geometry.Box2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingBox
/*     */   extends RegionAnalyzer2D<Box2D>
/*     */ {
/*     */   public static final Box2D[] boundingBoxes(ImageProcessor labelImage, int[] labels, Calibration calib) {
/*  40 */     return (new BoundingBox()).analyzeRegions(labelImage, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box2D[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/*  72 */     int sizeX = image.getWidth();
/*  73 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/*  76 */     double sx = 1.0D, sy = 1.0D;
/*  77 */     double ox = 0.0D, oy = 0.0D;
/*  78 */     if (calib != null) {
/*     */       
/*  80 */       sx = calib.pixelWidth;
/*  81 */       sy = calib.pixelHeight;
/*  82 */       ox = calib.xOrigin;
/*  83 */       oy = calib.yOrigin;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/*  90 */     int nLabels = labels.length;
/*  91 */     double[] xmin = new double[nLabels];
/*  92 */     double[] xmax = new double[nLabels];
/*  93 */     double[] ymin = new double[nLabels];
/*  94 */     double[] ymax = new double[nLabels];
/*     */ 
/*     */     
/*  97 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/*  99 */       xmin[i] = Double.POSITIVE_INFINITY;
/* 100 */       xmax[i] = Double.NEGATIVE_INFINITY;
/* 101 */       ymin[i] = Double.POSITIVE_INFINITY;
/* 102 */       ymax[i] = Double.NEGATIVE_INFINITY;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     fireStatusChanged(this, "Compute bounds");
/* 107 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 109 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 111 */         int label = (int)image.getf(x, y);
/* 112 */         if (label != 0)
/*     */         {
/*     */ 
/*     */           
/* 116 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */             
/* 119 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */             
/* 121 */             xmin[index] = Math.min(xmin[index], x);
/* 122 */             xmax[index] = Math.max(xmax[index], x);
/* 123 */             ymin[index] = Math.min(ymin[index], y);
/* 124 */             ymax[index] = Math.max(ymax[index], y);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 129 */     Box2D[] boxes = new Box2D[nLabels];
/* 130 */     for (int j = 0; j < nLabels; j++)
/*     */     {
/* 132 */       boxes[j] = new Box2D(
/* 133 */           xmin[j] * sx + ox, (xmax[j] + 1.0D) * sx + ox, 
/* 134 */           ymin[j] * sy + oy, (ymax[j] + 1.0D) * sy + oy);
/*     */     }
/* 136 */     return boxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Box2D> map) {
/* 150 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 154 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 157 */       Box2D box = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 160 */       table.incrementCounter();
/* 161 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 164 */       table.addValue("Box2D.XMin", box.getXMin());
/* 165 */       table.addValue("Box2D.XMax", box.getXMax());
/* 166 */       table.addValue("Box2D.YMin", box.getYMin());
/* 167 */       table.addValue("Box2D.YMax", box.getYMax()); }
/*     */ 
/*     */     
/* 170 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/BoundingBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */