/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionBoundaries
/*     */ {
/*     */   public static final ArrayList<Point2D> runLengthsCorners(ImageProcessor image) {
/*  45 */     int sizeX = image.getWidth();
/*  46 */     int sizeY = image.getHeight();
/*     */     
/*  48 */     ArrayList<Point2D> points = new ArrayList<Point2D>();
/*     */ 
/*     */     
/*  51 */     for (int y = 0; y < sizeY; y++) {
/*     */ 
/*     */       
/*  54 */       boolean inside = false;
/*  55 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/*  57 */         int pixel = image.get(x, y);
/*  58 */         if (pixel > 0 && !inside) {
/*     */ 
/*     */           
/*  61 */           Point2D p = new Point2D.Double(x, y);
/*  62 */           if (!points.contains(p))
/*     */           {
/*  64 */             points.add(p);
/*     */           }
/*  66 */           points.add(new Point2D.Double(x, (y + 1)));
/*  67 */           inside = true;
/*     */         }
/*  69 */         else if (pixel == 0 && inside) {
/*     */ 
/*     */           
/*  72 */           Point2D p = new Point2D.Double(x, y);
/*  73 */           if (!points.contains(p))
/*     */           {
/*  75 */             points.add(p);
/*     */           }
/*  77 */           points.add(new Point2D.Double(x, (y + 1)));
/*  78 */           inside = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  83 */       if (inside) {
/*     */         
/*  85 */         Point2D p = new Point2D.Double(sizeX, y);
/*  86 */         if (!points.contains(p))
/*     */         {
/*  88 */           points.add(p);
/*     */         }
/*  90 */         points.add(new Point2D.Double(sizeX, (y + 1)));
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     return points;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<Point2D>[] runlengthsCorners(ImageProcessor image, int[] labels) {
/* 115 */     Map<Integer, ArrayList<Point2D>> cornerPointsMap = runLengthsCornersMap(image, labels);
/*     */ 
/*     */     
/* 118 */     int nLabels = labels.length;
/*     */     
/* 120 */     ArrayList[] labelCornerPoints = new ArrayList[nLabels];
/*     */ 
/*     */     
/* 123 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 125 */       labelCornerPoints[i] = cornerPointsMap.get(Integer.valueOf(labels[i]));
/*     */     }
/*     */     
/* 128 */     return (ArrayList<Point2D>[])labelCornerPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Map<Integer, ArrayList<Point2D>> runLengthsCornersMap(ImageProcessor image, int[] labels) {
/* 146 */     int sizeX = image.getWidth();
/* 147 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 150 */     Map<Integer, ArrayList<Point2D>> labelCornerPoints = new TreeMap<Integer, ArrayList<Point2D>>(); byte b; int i, arrayOfInt[];
/* 151 */     for (i = (arrayOfInt = labels).length, b = 0; b < i; ) { int label = arrayOfInt[b];
/*     */       
/* 153 */       labelCornerPoints.put(Integer.valueOf(label), new ArrayList<Point2D>());
/*     */       
/*     */       b++; }
/*     */     
/* 157 */     for (int y = 0; y < sizeY; y++) {
/*     */ 
/*     */       
/* 160 */       int previous = 0;
/*     */ 
/*     */       
/* 163 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 165 */         int current = (int)image.getf(x, y);
/*     */ 
/*     */         
/* 168 */         if (current != previous) {
/*     */ 
/*     */           
/* 171 */           if (previous > 0 && labelCornerPoints.containsKey(Integer.valueOf(previous))) {
/*     */             
/* 173 */             ArrayList<Point2D> corners = labelCornerPoints.get(Integer.valueOf(previous));
/* 174 */             Point2D p = new Point2D.Double(x, y);
/* 175 */             if (!corners.contains(p))
/*     */             {
/* 177 */               corners.add(p);
/*     */             }
/* 179 */             corners.add(new Point2D.Double(x, (y + 1)));
/*     */           } 
/*     */ 
/*     */           
/* 183 */           if (current > 0 && labelCornerPoints.containsKey(Integer.valueOf(current))) {
/*     */ 
/*     */             
/* 186 */             ArrayList<Point2D> corners = labelCornerPoints.get(Integer.valueOf(current));
/* 187 */             Point2D p = new Point2D.Double(x, y);
/* 188 */             if (!corners.contains(p))
/*     */             {
/* 190 */               corners.add(p);
/*     */             }
/* 192 */             corners.add(new Point2D.Double(x, (y + 1)));
/*     */           } 
/*     */ 
/*     */           
/* 196 */           previous = current;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 201 */       if (previous > 0 && labelCornerPoints.containsKey(Integer.valueOf(previous))) {
/*     */         
/* 203 */         ArrayList<Point2D> corners = labelCornerPoints.get(Integer.valueOf(previous));
/* 204 */         Point2D p = new Point2D.Double(sizeX, y);
/* 205 */         if (!corners.contains(p))
/*     */         {
/* 207 */           corners.add(p);
/*     */         }
/* 209 */         corners.add(new Point2D.Double(sizeX, (y + 1)));
/*     */       } 
/*     */     } 
/*     */     
/* 213 */     return labelCornerPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<Point2D> boundaryPixelsMiddleEdges(ImageProcessor binaryImage) {
/* 239 */     int sizeX = binaryImage.getWidth();
/* 240 */     int sizeY = binaryImage.getHeight();
/*     */     
/* 242 */     ArrayList<Point2D> points = new ArrayList<Point2D>();
/*     */ 
/*     */     
/* 245 */     boolean[] configValues = new boolean[4];
/*     */ 
/*     */     
/* 248 */     for (int y = 0; y < sizeY + 1; y++) {
/*     */ 
/*     */       
/* 251 */       configValues[2] = false;
/*     */       
/* 253 */       for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */         
/* 256 */         configValues[1] = ((((x < sizeX) ? 1 : 0) & ((y > 0) ? 1 : 0)) != 0) ? (((int)binaryImage.getf(x, y - 1) > 0)) : false;
/* 257 */         configValues[3] = ((((x < sizeX) ? 1 : 0) & ((y < sizeY) ? 1 : 0)) != 0) ? (((int)binaryImage.getf(x, y) > 0)) : false;
/*     */ 
/*     */         
/* 260 */         if (configValues[1] != configValues[3])
/*     */         {
/* 262 */           points.add(new Point2D.Double(x + 0.5D, y));
/*     */         }
/* 264 */         if (configValues[2] != configValues[3])
/*     */         {
/* 266 */           points.add(new Point2D.Double(x, y + 0.5D));
/*     */         }
/*     */ 
/*     */         
/* 270 */         configValues[2] = configValues[3];
/*     */       } 
/*     */     } 
/*     */     
/* 274 */     return points;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<Point2D>[] boundaryPixelsMiddleEdges(ImageProcessor labelImage, int[] labels) {
/* 301 */     int sizeX = labelImage.getWidth();
/* 302 */     int sizeY = labelImage.getHeight();
/*     */     
/* 304 */     int nLabels = labels.length;
/* 305 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */ 
/*     */     
/* 309 */     ArrayList[] pointArrays = new ArrayList[nLabels];
/* 310 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 312 */       pointArrays[i] = new ArrayList();
/*     */     }
/*     */ 
/*     */     
/* 316 */     int label = 0;
/* 317 */     int labelUp = 0;
/* 318 */     int labelLeft = 0;
/*     */ 
/*     */     
/* 321 */     int[] configValues = new int[4];
/*     */ 
/*     */     
/* 324 */     for (int y = 0; y < sizeY + 1; y++) {
/*     */ 
/*     */       
/* 327 */       configValues[2] = 0;
/*     */       
/* 329 */       for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */         
/* 332 */         label = ((((x < sizeX) ? 1 : 0) & ((y < sizeY) ? 1 : 0)) != 0) ? (int)labelImage.getf(x, y) : 0;
/* 333 */         labelUp = ((((x < sizeX) ? 1 : 0) & ((y > 0) ? 1 : 0)) != 0) ? (int)labelImage.getf(x, y - 1) : 0;
/*     */ 
/*     */         
/* 336 */         if (labelUp != label) {
/*     */           
/* 338 */           Point2D p = new Point2D.Double(x + 0.5D, y);
/* 339 */           if (label != 0) {
/*     */             
/* 341 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 342 */             pointArrays[index].add(p);
/*     */           } 
/* 344 */           if (labelUp != 0) {
/*     */             
/* 346 */             int index = ((Integer)labelIndices.get(Integer.valueOf(labelUp))).intValue();
/* 347 */             pointArrays[index].add(p);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 352 */         if (labelLeft != label) {
/*     */           
/* 354 */           Point2D p = new Point2D.Double(x, y + 0.5D);
/* 355 */           if (label != 0) {
/*     */             
/* 357 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 358 */             pointArrays[index].add(p);
/*     */           } 
/* 360 */           if (labelLeft != 0) {
/*     */             
/* 362 */             int index = ((Integer)labelIndices.get(Integer.valueOf(labelLeft))).intValue();
/* 363 */             pointArrays[index].add(p);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 368 */         labelLeft = label;
/*     */       } 
/*     */     } 
/*     */     
/* 372 */     return (ArrayList<Point2D>[])pointArrays;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/RegionBoundaries.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */