/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryConfigurationsHistogram3D
/*     */   extends AlgoStub
/*     */ {
/*     */   public static final double applyLut(int[] histogram, double[] lut) {
/*  28 */     double sum = 0.0D;
/*  29 */     for (int i = 0; i < histogram.length; i++)
/*     */     {
/*  31 */       sum += histogram[i] * lut[i];
/*     */     }
/*  33 */     return sum;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double[] applyLut(int[][] histograms, double[] lut) {
/*  38 */     double[] sums = new double[histograms.length];
/*  39 */     for (int iLabel = 0; iLabel < histograms.length; iLabel++)
/*     */     {
/*  41 */       sums[iLabel] = applyLut(histograms[iLabel], lut);
/*     */     }
/*  43 */     return sums;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] process(ImageStack image) {
/*  82 */     int[] histo = new int[256];
/*     */ 
/*     */     
/*  85 */     int sizeX = image.getWidth();
/*  86 */     int sizeY = image.getHeight();
/*  87 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/*  90 */     boolean[] configValues = new boolean[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     for (int z = 0; z < sizeZ + 1; z++) {
/*     */       
/*  98 */       fireProgressChanged(this, z, (sizeZ + 1));
/*     */       
/* 100 */       for (int y = 0; y < sizeY + 1; y++) {
/*     */ 
/*     */         
/* 103 */         configValues[0] = false;
/* 104 */         configValues[2] = false;
/* 105 */         configValues[4] = false;
/* 106 */         configValues[6] = false;
/*     */         
/* 108 */         for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */           
/* 111 */           if (x < sizeX) {
/*     */             
/* 113 */             configValues[1] = ((((y > 0) ? 1 : 0) & ((z > 0) ? 1 : 0)) != 0) ? ((image.getVoxel(x, y - 1, z - 1) > 0.0D)) : false;
/* 114 */             configValues[3] = ((((y < sizeY) ? 1 : 0) & ((z > 0) ? 1 : 0)) != 0) ? ((image.getVoxel(x, y, z - 1) > 0.0D)) : false;
/* 115 */             configValues[5] = ((((y > 0) ? 1 : 0) & ((z < sizeZ) ? 1 : 0)) != 0) ? ((image.getVoxel(x, y - 1, z) > 0.0D)) : false;
/* 116 */             configValues[7] = ((((y < sizeY) ? 1 : 0) & ((z < sizeZ) ? 1 : 0)) != 0) ? ((image.getVoxel(x, y, z) > 0.0D)) : false;
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 122 */             configValues[7] = false; configValues[5] = false; configValues[3] = false; configValues[1] = false;
/*     */           } 
/*     */ 
/*     */           
/* 126 */           int index = configIndex(configValues);
/*     */ 
/*     */           
/* 129 */           histo[index] = histo[index] + 1;
/*     */ 
/*     */           
/* 132 */           configValues[0] = configValues[1];
/* 133 */           configValues[2] = configValues[3];
/* 134 */           configValues[4] = configValues[5];
/* 135 */           configValues[6] = configValues[7];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 140 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */ 
/*     */     
/* 143 */     return histo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] processInnerFrame(ImageStack image) {
/* 168 */     int sizeX = image.getWidth();
/* 169 */     int sizeY = image.getHeight();
/* 170 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 173 */     int[] histo = new int[256];
/*     */ 
/*     */     
/* 176 */     boolean[] configValues = new boolean[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     for (int z = 1; z < sizeZ; z++) {
/*     */       
/* 184 */       fireProgressChanged(this, z, (sizeZ + 1));
/*     */       
/* 186 */       for (int y = 1; y < sizeY; y++) {
/*     */ 
/*     */         
/* 189 */         configValues[0] = (image.getVoxel(0, y - 1, z - 1) > 0.0D);
/* 190 */         configValues[2] = (image.getVoxel(0, y, z - 1) > 0.0D);
/* 191 */         configValues[4] = (image.getVoxel(0, y - 1, z) > 0.0D);
/* 192 */         configValues[6] = (image.getVoxel(0, y, z) > 0.0D);
/*     */         
/* 194 */         for (int x = 1; x < sizeX; x++) {
/*     */ 
/*     */           
/* 197 */           configValues[1] = (image.getVoxel(x, y - 1, z - 1) > 0.0D);
/* 198 */           configValues[3] = (image.getVoxel(x, y, z - 1) > 0.0D);
/* 199 */           configValues[5] = (image.getVoxel(x, y - 1, z) > 0.0D);
/* 200 */           configValues[7] = (image.getVoxel(x, y, z) > 0.0D);
/*     */ 
/*     */           
/* 203 */           int index = configIndex(configValues);
/*     */ 
/*     */           
/* 206 */           histo[index] = histo[index] + 1;
/*     */ 
/*     */           
/* 209 */           configValues[0] = configValues[1];
/* 210 */           configValues[2] = configValues[3];
/* 211 */           configValues[4] = configValues[5];
/* 212 */           configValues[6] = configValues[7];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 217 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */ 
/*     */     
/* 220 */     return histo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int configIndex(boolean[] configValues) {
/* 226 */     int index = 0;
/* 227 */     index += configValues[0] ? 1 : 0;
/* 228 */     index += configValues[1] ? 2 : 0;
/* 229 */     index += configValues[2] ? 4 : 0;
/* 230 */     index += configValues[3] ? 8 : 0;
/* 231 */     index += configValues[4] ? 16 : 0;
/* 232 */     index += configValues[5] ? 32 : 0;
/* 233 */     index += configValues[6] ? 64 : 0;
/* 234 */     index += configValues[7] ? 128 : 0;
/* 235 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] process(ImageStack image, int[] labels) {
/* 263 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 266 */     int nLabels = labels.length;
/* 267 */     int[][] histos = new int[nLabels][256];
/*     */ 
/*     */     
/* 270 */     int sizeX = image.getWidth();
/* 271 */     int sizeY = image.getHeight();
/* 272 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 275 */     ArrayList<Integer> localLabels = new ArrayList<Integer>(8);
/*     */ 
/*     */     
/* 278 */     int[] configValues = new int[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     for (int z = 0; z < sizeZ + 1; z++) {
/*     */       
/* 286 */       fireProgressChanged(this, z, (sizeZ + 1));
/*     */       
/* 288 */       for (int y = 0; y < sizeY + 1; y++) {
/*     */ 
/*     */         
/* 291 */         configValues[0] = 0;
/* 292 */         configValues[2] = 0;
/* 293 */         configValues[4] = 0;
/* 294 */         configValues[6] = 0;
/*     */         
/* 296 */         for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */           
/* 299 */           if (x < sizeX) {
/*     */             
/* 301 */             configValues[1] = ((((y > 0) ? 1 : 0) & ((z > 0) ? 1 : 0)) != 0) ? (int)image.getVoxel(x, y - 1, z - 1) : 0;
/* 302 */             configValues[3] = ((((y < sizeY) ? 1 : 0) & ((z > 0) ? 1 : 0)) != 0) ? (int)image.getVoxel(x, y, z - 1) : 0;
/* 303 */             configValues[5] = ((((y > 0) ? 1 : 0) & ((z < sizeZ) ? 1 : 0)) != 0) ? (int)image.getVoxel(x, y - 1, z) : 0;
/* 304 */             configValues[7] = ((((y < sizeY) ? 1 : 0) & ((z < sizeZ) ? 1 : 0)) != 0) ? (int)image.getVoxel(x, y, z) : 0;
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 310 */             configValues[7] = 0; configValues[5] = 0; configValues[3] = 0; configValues[1] = 0;
/*     */           } 
/*     */ 
/*     */           
/* 314 */           localLabels.clear(); byte b; int i, arrayOfInt[];
/* 315 */           for (i = (arrayOfInt = configValues).length, b = 0; b < i; ) { int label = arrayOfInt[b];
/*     */             
/* 317 */             if (label != 0)
/*     */             {
/*     */               
/* 320 */               if (!localLabels.contains(Integer.valueOf(label)))
/* 321 */                 localLabels.add(Integer.valueOf(label)); 
/*     */             }
/*     */             b++; }
/*     */           
/* 325 */           for (Iterator<Integer> iterator = localLabels.iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */             
/* 328 */             int index = configIndex(configValues, label);
/*     */ 
/*     */             
/* 331 */             int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */ 
/*     */             
/* 335 */             histos[labelIndex][index] = histos[labelIndex][index] + 1; }
/*     */ 
/*     */ 
/*     */           
/* 339 */           configValues[0] = configValues[1];
/* 340 */           configValues[2] = configValues[3];
/* 341 */           configValues[4] = configValues[5];
/* 342 */           configValues[6] = configValues[7];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */ 
/*     */     
/* 350 */     return histos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int configIndex(int[] configValues, int label) {
/* 356 */     int index = 0;
/* 357 */     index += (configValues[0] == label) ? 1 : 0;
/* 358 */     index += (configValues[1] == label) ? 2 : 0;
/* 359 */     index += (configValues[2] == label) ? 4 : 0;
/* 360 */     index += (configValues[3] == label) ? 8 : 0;
/* 361 */     index += (configValues[4] == label) ? 16 : 0;
/* 362 */     index += (configValues[5] == label) ? 32 : 0;
/* 363 */     index += (configValues[6] == label) ? 64 : 0;
/* 364 */     index += (configValues[7] == label) ? 128 : 0;
/* 365 */     return index;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/BinaryConfigurationsHistogram3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */