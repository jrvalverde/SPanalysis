/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoListener;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumesAnalyzer3D
/*     */   extends RegionAnalyzer3D<IntrinsicVolumesAnalyzer3D.Result>
/*     */   implements AlgoListener
/*     */ {
/*     */   @Deprecated
/*     */   public static final double[] volumeLut(Calibration calib) {
/*  43 */     return IntrinsicVolumes3DUtils.volumeLut(calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] surfaceAreaLut(Calibration calib, int nDirs) {
/*  61 */     return IntrinsicVolumes3DUtils.surfaceAreaLut(calib, nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] meanBreadthLut(Calibration calib, int nDirs, int conn2d) {
/*  80 */     return IntrinsicVolumes3DUtils.meanBreadthLut(calib, nDirs, conn2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] eulerNumberLut(int conn) {
/* 100 */     return IntrinsicVolumes3DUtils.eulerNumberLut(conn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean computeVolume = true;
/*     */ 
/*     */   
/*     */   boolean computeSurfaceArea = true;
/*     */ 
/*     */   
/*     */   boolean computeMeanBreadth = true;
/*     */ 
/*     */   
/*     */   boolean computeEulerNumber = true;
/*     */   
/* 116 */   int directionNumber = 13;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDirectionNumber() {
/* 140 */     return this.directionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectionNumber(int directionNumber) {
/* 150 */     this.directionNumber = directionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/* 158 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int connectivity) {
/* 168 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Result> results) {
/* 179 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 183 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 186 */       Result res = results.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 189 */       table.incrementCounter();
/* 190 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 193 */       table.addValue("Volume", res.volume);
/* 194 */       table.addValue("SurfaceArea", res.surfaceArea);
/* 195 */       table.addValue("MeanBreadth", res.meanBreadth);
/* 196 */       table.addValue("EulerNumber", res.eulerNumber); }
/*     */ 
/*     */     
/* 199 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result[] analyzeRegions(ImageStack image, int[] labels, Calibration calib) {
/* 206 */     BinaryConfigurationsHistogram3D algo = new BinaryConfigurationsHistogram3D();
/* 207 */     algo.addAlgoListener(this);
/* 208 */     int[][] histograms = algo.process(image, labels);
/*     */ 
/*     */     
/* 211 */     Result[] results = new Result[labels.length];
/* 212 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/* 214 */       results[i] = new Result();
/*     */     }
/*     */ 
/*     */     
/* 218 */     if (this.computeVolume) {
/*     */       
/* 220 */       double[] volumeLut = IntrinsicVolumes3DUtils.volumeLut(calib);
/* 221 */       double[] volumes = BinaryConfigurationsHistogram3D.applyLut(histograms, volumeLut);
/* 222 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 224 */         (results[j]).volume = volumes[j];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 229 */     if (this.computeVolume) {
/*     */       
/* 231 */       double[] areaLut = IntrinsicVolumes3DUtils.surfaceAreaLut(calib, this.directionNumber);
/* 232 */       double[] areas = BinaryConfigurationsHistogram3D.applyLut(histograms, areaLut);
/* 233 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 235 */         (results[j]).surfaceArea = areas[j];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 240 */     if (this.computeMeanBreadth) {
/*     */       
/* 242 */       double[] breadthLut = IntrinsicVolumes3DUtils.meanBreadthLut(calib, this.directionNumber, 8);
/* 243 */       double[] breadths = BinaryConfigurationsHistogram3D.applyLut(histograms, breadthLut);
/* 244 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 246 */         (results[j]).meanBreadth = breadths[j];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 251 */     if (this.computeEulerNumber) {
/*     */       
/* 253 */       double[] eulerLut = IntrinsicVolumes3DUtils.eulerNumberLut(this.connectivity);
/* 254 */       double[] eulers = BinaryConfigurationsHistogram3D.applyLut(histograms, eulerLut);
/* 255 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 257 */         (results[j]).eulerNumber = eulers[j];
/*     */       }
/*     */     } 
/*     */     
/* 261 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoProgressChanged(AlgoEvent evt) {
/* 273 */     fireProgressChanged(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoStatusChanged(AlgoEvent evt) {
/* 282 */     fireStatusChanged(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Result
/*     */   {
/* 290 */     public double volume = Double.NaN;
/* 291 */     public double surfaceArea = Double.NaN;
/* 292 */     public double meanBreadth = Double.NaN;
/* 293 */     public double eulerNumber = Double.NaN;
/*     */ 
/*     */ 
/*     */     
/*     */     public Result() {}
/*     */ 
/*     */     
/*     */     public Result(double volume, double surf, double breadth, double euler) {
/* 301 */       this.volume = volume;
/* 302 */       this.surfaceArea = surf;
/* 303 */       this.meanBreadth = breadth;
/* 304 */       this.eulerNumber = euler;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/IntrinsicVolumesAnalyzer3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */