/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.geometry.Ellipse;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquivalentEllipse
/*     */   extends RegionAnalyzer2D<Ellipse>
/*     */ {
/*     */   public static final Ellipse[] equivalentEllipses(ImageProcessor image, int[] labels, Calibration calib) {
/*  49 */     return (new EquivalentEllipse()).analyzeRegions(image, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Ellipse> map) {
/*  77 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/*  80 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  83 */       Ellipse ellipse = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  86 */       table.incrementCounter();
/*  87 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/*  90 */       Point2D center = ellipse.center();
/*  91 */       table.addValue("Ellipse.Center.X", center.getX());
/*  92 */       table.addValue("Ellipse.Center.Y", center.getY());
/*     */ 
/*     */       
/*  95 */       table.addValue("Ellipse.Radius1", ellipse.radius1());
/*  96 */       table.addValue("Ellipse.Radius2", ellipse.radius2());
/*     */ 
/*     */       
/*  99 */       table.addValue("Ellipse.Orientation", ellipse.orientation()); }
/*     */ 
/*     */     
/* 102 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipse[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/* 121 */     int sizeX = image.getWidth();
/* 122 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 125 */     double sx = 1.0D, sy = 1.0D;
/* 126 */     double ox = 0.0D, oy = 0.0D;
/* 127 */     if (calib != null) {
/*     */       
/* 129 */       sx = calib.pixelWidth;
/* 130 */       sy = calib.pixelHeight;
/* 131 */       ox = calib.xOrigin;
/* 132 */       oy = calib.yOrigin;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 139 */     int nLabels = labels.length;
/* 140 */     int[] counts = new int[nLabels];
/* 141 */     double[] cx = new double[nLabels];
/* 142 */     double[] cy = new double[nLabels];
/* 143 */     double[] Ixx = new double[nLabels];
/* 144 */     double[] Iyy = new double[nLabels];
/* 145 */     double[] Ixy = new double[nLabels];
/*     */     
/* 147 */     fireStatusChanged(this, "Compute centroids");
/*     */     
/* 149 */     for (int k = 0; k < sizeY; k++) {
/*     */       
/* 151 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 153 */         int label = (int)image.getf(x, k);
/* 154 */         if (label != 0)
/*     */         {
/*     */ 
/*     */           
/* 158 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */             
/* 161 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 162 */             cx[index] = cx[index] + x * sx;
/* 163 */             cy[index] = cy[index] + k * sy;
/* 164 */             counts[index] = counts[index] + 1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 169 */     for (int j = 0; j < nLabels; j++) {
/*     */       
/* 171 */       cx[j] = cx[j] / counts[j];
/* 172 */       cy[j] = cy[j] / counts[j];
/*     */     } 
/*     */ 
/*     */     
/* 176 */     fireStatusChanged(this, "Compute Inertia Matrices");
/* 177 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 179 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 181 */         int label = (int)image.getf(x, y);
/* 182 */         if (label != 0) {
/*     */ 
/*     */           
/* 185 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 186 */           double x2 = x * sx - cx[index];
/* 187 */           double y2 = y * sy - cy[index];
/* 188 */           Ixx[index] = Ixx[index] + x2 * x2;
/* 189 */           Ixy[index] = Ixy[index] + x2 * y2;
/* 190 */           Iyy[index] = Iyy[index] + y2 * y2;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 195 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 197 */       Ixx[i] = Ixx[i] / counts[i] + sx / 12.0D;
/* 198 */       Ixy[i] = Ixy[i] / counts[i];
/* 199 */       Iyy[i] = Iyy[i] / counts[i] + sy / 12.0D;
/*     */     } 
/*     */ 
/*     */     
/* 203 */     Ellipse[] ellipses = new Ellipse[nLabels];
/*     */ 
/*     */     
/* 206 */     fireStatusChanged(this, "Compute Ellipses");
/* 207 */     double sqrt2 = Math.sqrt(2.0D);
/* 208 */     for (int m = 0; m < nLabels; m++) {
/*     */       
/* 210 */       double xx = Ixx[m];
/* 211 */       double xy = Ixy[m];
/* 212 */       double yy = Iyy[m];
/*     */ 
/*     */       
/* 215 */       double common = Math.sqrt((xx - yy) * (xx - yy) + 4.0D * xy * xy);
/* 216 */       double ra = sqrt2 * Math.sqrt(xx + yy + common);
/* 217 */       double rb = sqrt2 * Math.sqrt(xx + yy - common);
/*     */ 
/*     */       
/* 220 */       double theta = Math.toDegrees(Math.atan2(2.0D * xy, xx - yy) / 2.0D);
/*     */       
/* 222 */       Point2D center = new Point2D.Double(cx[m] + sx / 2.0D + ox, cy[m] + sy / 2.0D + oy);
/* 223 */       ellipses[m] = new Ellipse(center, ra, rb, theta);
/*     */     } 
/*     */     
/* 226 */     return ellipses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/EquivalentEllipse.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */