package inra.ijpb.measure;

import ij.ImagePlus;
import ij.measure.ResultsTable;
import java.util.Map;

public interface RegionAnalyzer<T> {
  Map<Integer, T> analyzeRegions(ImagePlus paramImagePlus);
  
  ResultsTable computeTable(ImagePlus paramImagePlus);
  
  ResultsTable createTable(Map<Integer, T> paramMap);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/RegionAnalyzer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */