/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.BinaryConfigurationsHistogram2D;
/*     */ import inra.ijpb.measure.region2d.IntrinsicVolumes2DUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumes2D
/*     */ {
/*     */   public static final double area(ImageProcessor image, Calibration calib) {
/*  47 */     double pixelArea = calib.pixelWidth * calib.pixelHeight;
/*     */ 
/*     */     
/*  50 */     int count = BinaryImages.countForegroundPixels(image);
/*  51 */     double area = count * pixelArea;
/*  52 */     return area;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] areas(ImageProcessor image, int[] labels, Calibration calib) {
/*  72 */     double pixelArea = calib.pixelWidth * calib.pixelHeight;
/*     */ 
/*     */     
/*  75 */     int nLabels = labels.length;
/*  76 */     double[] areas = new double[nLabels];
/*     */ 
/*     */     
/*  79 */     int[] counts = LabelImages.pixelCount(image, labels);
/*     */ 
/*     */     
/*  82 */     for (int i = 0; i < areas.length; i++)
/*     */     {
/*  84 */       areas[i] = counts[i] * pixelArea;
/*     */     }
/*     */     
/*  87 */     return areas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double areaDensity(ImageProcessor image) {
/* 100 */     int sizeX = image.getWidth();
/* 101 */     int sizeY = image.getHeight();
/* 102 */     double totalArea = (sizeX * sizeY);
/*     */ 
/*     */     
/* 105 */     double count = BinaryImages.countForegroundPixels(image);
/*     */ 
/*     */     
/* 108 */     return count / totalArea;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double perimeter(ImageProcessor image, Calibration calib, int nDirs) {
/* 129 */     double[] lut = IntrinsicVolumes2DUtils.perimeterLut(calib, nDirs);
/*     */ 
/*     */     
/* 132 */     int[] histo = (new BinaryConfigurationsHistogram2D()).process(image);
/*     */ 
/*     */     
/* 135 */     return BinaryConfigurationsHistogram2D.applyLut(histo, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] perimeters(ImageProcessor image, int[] labels, Calibration calib, int nDirs) {
/* 157 */     double[] lut = IntrinsicVolumes2DUtils.perimeterLut(calib, nDirs);
/*     */ 
/*     */     
/* 160 */     int[][] histos = (new BinaryConfigurationsHistogram2D()).process(image, labels);
/*     */ 
/*     */     
/* 163 */     return BinaryConfigurationsHistogram2D.applyLut(histos, lut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double perimeterDensity(ImageProcessor image, Calibration calib, int nDirs) {
/* 181 */     double[] lut = IntrinsicVolumes2DUtils.perimeterLut(calib, nDirs);
/*     */ 
/*     */     
/* 184 */     int[] histo = (new BinaryConfigurationsHistogram2D()).processInnerFrame(image);
/*     */ 
/*     */     
/* 187 */     double perim = BinaryConfigurationsHistogram2D.applyLut(histo, lut);
/* 188 */     return perim / samplingArea(image, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int eulerNumber(ImageProcessor image, int conn) {
/* 204 */     int[] lut = IntrinsicVolumes2DUtils.eulerNumberIntLut(conn);
/*     */ 
/*     */     
/* 207 */     int[] histo = (new BinaryConfigurationsHistogram2D()).process(image);
/*     */ 
/*     */     
/* 210 */     return BinaryConfigurationsHistogram2D.applyLut(histo, lut) / 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] eulerNumbers(ImageProcessor image, int[] labels, int conn) {
/* 228 */     int[] lut = IntrinsicVolumes2DUtils.eulerNumberIntLut(conn);
/*     */ 
/*     */     
/* 231 */     int[][] histos = (new BinaryConfigurationsHistogram2D()).process(image, labels);
/*     */ 
/*     */     
/* 234 */     int[] euler = BinaryConfigurationsHistogram2D.applyLut(histos, lut);
/* 235 */     for (int i = 0; i < euler.length; i++)
/*     */     {
/* 237 */       euler[i] = euler[i] / 4;
/*     */     }
/*     */     
/* 240 */     return euler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double eulerNumberDensity(ImageProcessor image, Calibration calib, int conn) {
/* 258 */     double[] lut = IntrinsicVolumes2DUtils.eulerNumberLut(conn);
/*     */ 
/*     */     
/* 261 */     int[] histo = (new BinaryConfigurationsHistogram2D()).processInnerFrame(image);
/*     */ 
/*     */     
/* 264 */     double euler = BinaryConfigurationsHistogram2D.applyLut(histo, lut);
/* 265 */     return euler / samplingArea(image, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double samplingArea(ImageProcessor image, Calibration calib) {
/* 280 */     int sizeX = image.getWidth();
/* 281 */     int sizeY = image.getHeight();
/* 282 */     return (sizeX - 1) * calib.pixelWidth * (sizeY - 1) * calib.pixelHeight;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/IntrinsicVolumes2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */