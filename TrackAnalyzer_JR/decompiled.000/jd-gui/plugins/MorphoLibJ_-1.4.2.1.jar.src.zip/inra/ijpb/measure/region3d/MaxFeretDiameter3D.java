/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.geometry.PointPair3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxFeretDiameter3D
/*     */   extends RegionAnalyzer3D<PointPair3D>
/*     */ {
/*     */   public static final PointPair3D[] maxFeretDiameters(ImageStack image, int[] labels, Calibration calib) {
/*  29 */     return (new MaxFeretDiameter3D()).analyzeRegions(image, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final PointPair3D maxFeretDiameter(ArrayList<? extends Point3D> points) {
/*  44 */     double distMax = Double.NEGATIVE_INFINITY;
/*  45 */     PointPair3D maxDiam = null;
/*     */     
/*  47 */     int n = points.size();
/*  48 */     for (int i1 = 0; i1 < n - 1; i1++) {
/*     */       
/*  50 */       Point3D p1 = points.get(i1);
/*  51 */       for (int i2 = i1 + 1; i2 < n; i2++) {
/*     */         
/*  53 */         Point3D p2 = points.get(i2);
/*     */         
/*  55 */         double dist = p1.distance(p2);
/*  56 */         if (dist > distMax) {
/*     */           
/*  58 */           maxDiam = new PointPair3D(p1, p2);
/*  59 */           distMax = dist;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  64 */     return maxDiam;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, PointPair3D> maxDiamsMap) {
/*  92 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/*  95 */     for (Iterator<Integer> iterator = maxDiamsMap.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */       
/*  97 */       table.incrementCounter();
/*  98 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 101 */       PointPair3D maxDiam = maxDiamsMap.get(Integer.valueOf(label));
/* 102 */       table.addValue("Diameter", maxDiam.diameter());
/* 103 */       table.addValue("P1.x", maxDiam.p1.getX());
/* 104 */       table.addValue("P1.y", maxDiam.p1.getY());
/* 105 */       table.addValue("P1.z", maxDiam.p1.getZ());
/* 106 */       table.addValue("P2.x", maxDiam.p2.getX());
/* 107 */       table.addValue("p2.y", maxDiam.p2.getY());
/* 108 */       table.addValue("p2.z", maxDiam.p2.getZ()); }
/*     */ 
/*     */ 
/*     */     
/* 112 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointPair3D[] analyzeRegions(ImageStack image, int[] labels, Calibration calib) {
/* 133 */     if (image == null) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     double sx = 1.0D, sy = 1.0D, sz = 1.0D;
/* 138 */     double ox = 0.0D, oy = 0.0D, oz = 0.0D;
/* 139 */     if (calib != null) {
/*     */       
/* 141 */       sx = calib.pixelWidth;
/* 142 */       sy = calib.pixelHeight;
/* 143 */       sz = calib.pixelDepth;
/* 144 */       ox = calib.xOrigin;
/* 145 */       oy = calib.yOrigin;
/* 146 */       oz = calib.zOrigin;
/*     */     } 
/*     */     
/* 149 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 152 */     fireStatusChanged(this, "Find Label Corner Points");
/* 153 */     ArrayList[] labelCornerPointsArray = (ArrayList[])RegionBoundaries3D.regionsCornersArray(image, labels);
/*     */ 
/*     */     
/* 156 */     PointPair3D[] labelMaxDiams = new PointPair3D[nLabels];
/* 157 */     fireStatusChanged(this, "Compute feret Diameters");
/* 158 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 160 */       fireProgressChanged(this, i, nLabels);
/*     */       
/* 162 */       ArrayList<Point3D> hull = labelCornerPointsArray[i];
/*     */       
/* 164 */       for (int iv = 0; iv < hull.size(); iv++) {
/*     */         
/* 166 */         Point3D vertex = hull.get(iv);
/* 167 */         vertex = new Point3D(vertex.getX() * sx + ox, vertex.getY() * sy + oy, vertex.getZ() * sz + oz);
/* 168 */         hull.set(iv, vertex);
/*     */       } 
/*     */ 
/*     */       
/* 172 */       labelMaxDiams[i] = maxFeretDiameter(hull);
/*     */     } 
/*     */     
/* 175 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 176 */     fireStatusChanged(this, "");
/* 177 */     return labelMaxDiams;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/MaxFeretDiameter3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */