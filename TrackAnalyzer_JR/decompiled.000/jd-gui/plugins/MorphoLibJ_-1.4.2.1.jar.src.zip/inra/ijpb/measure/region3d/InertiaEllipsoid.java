/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import Jama.Matrix;
/*     */ import Jama.SingularValueDecomposition;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import inra.ijpb.geometry.Ellipsoid;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.geometry.Vector3D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class InertiaEllipsoid
/*     */   extends RegionAnalyzer3D<Ellipsoid>
/*     */ {
/*     */   public static final Ellipsoid[] inertiaEllipsoids(ImageStack image, int[] labels, Calibration calib) {
/*  52 */     return (new InertiaEllipsoid()).analyzeRegions(image, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Ellipsoid> map) {
/*  81 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/*  85 */     for (Iterator<Integer> iterator = map.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  88 */       Ellipsoid ellipse = map.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  91 */       table.incrementCounter();
/*  92 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/*  95 */       Point3D center = ellipse.center();
/*  96 */       table.addValue("Ellipsoid.Center.X", center.getX());
/*  97 */       table.addValue("Ellipsoid.Center.Y", center.getY());
/*  98 */       table.addValue("Ellipsoid.Center.Z", center.getZ());
/*     */ 
/*     */       
/* 101 */       table.addValue("Ellipsoid.Radius1", ellipse.radius1());
/* 102 */       table.addValue("Ellipsoid.Radius2", ellipse.radius2());
/* 103 */       table.addValue("Ellipsoid.Radius3", ellipse.radius3());
/*     */ 
/*     */       
/* 106 */       table.addValue("Ellipsoid.Phi", ellipse.phi());
/* 107 */       table.addValue("Ellipsoid.Theta", ellipse.theta());
/* 108 */       table.addValue("Ellipsoid.Psi", ellipse.psi()); }
/*     */ 
/*     */     
/* 111 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ellipsoid[] analyzeRegions(ImageStack image, int[] labels, Calibration calib) {
/*     */     try {
/* 131 */       Class.forName("Jama.Matrix");
/*     */     }
/* 133 */     catch (Exception e) {
/*     */       
/* 135 */       throw new RuntimeException("Requires the JAMA package to work properly");
/*     */     } 
/*     */ 
/*     */     
/* 139 */     InertiaMoments3D[] moments = computeMoments(image, labels, calib);
/*     */ 
/*     */     
/* 142 */     Ellipsoid[] ellipsoids = momentsToEllipsoids(moments);
/*     */ 
/*     */     
/* 145 */     fireStatusChanged(this, "");
/*     */     
/* 147 */     return ellipsoids;
/*     */   }
/*     */ 
/*     */   
/*     */   private Ellipsoid[] momentsToEllipsoids(InertiaMoments3D[] moments) {
/* 152 */     int n = moments.length;
/* 153 */     Ellipsoid[] ellipsoids = new Ellipsoid[n];
/*     */ 
/*     */     
/* 156 */     fireStatusChanged(this, "Ellipsoid: compute SVD");
/* 157 */     for (int i = 0; i < n; i++) {
/*     */       
/* 159 */       fireProgressChanged(this, i, n);
/*     */       
/* 161 */       ellipsoids[i] = moments[i].equivalentEllipsoid();
/*     */     } 
/* 163 */     fireProgressChanged(this, 1.0D, 1.0D);
/*     */     
/* 165 */     return ellipsoids;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InertiaMoments3D[] computeMoments(ImageStack image, int[] labels, Calibration calib) {
/* 171 */     int sizeX = image.getWidth();
/* 172 */     int sizeY = image.getHeight();
/* 173 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 176 */     double sx = 1.0D, sy = 1.0D, sz = 1.0D;
/* 177 */     double ox = 0.0D, oy = 0.0D, oz = 0.0D;
/* 178 */     if (calib != null) {
/*     */       
/* 180 */       sx = calib.pixelWidth;
/* 181 */       sy = calib.pixelHeight;
/* 182 */       sz = calib.pixelDepth;
/* 183 */       ox = calib.xOrigin;
/* 184 */       oy = calib.yOrigin;
/* 185 */       oz = calib.zOrigin;
/*     */     } 
/*     */     
/* 188 */     fireStatusChanged(this, "Ellipsoid: compute Moments");
/*     */ 
/*     */     
/* 191 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 194 */     int nLabels = labels.length;
/* 195 */     InertiaMoments3D[] moments = new InertiaMoments3D[nLabels];
/* 196 */     for (int m = 0; m < nLabels; m++)
/*     */     {
/* 198 */       moments[m] = new InertiaMoments3D();
/*     */     }
/*     */ 
/*     */     
/* 202 */     fireStatusChanged(this, "Ellipsoid: compute centroids");
/* 203 */     for (int k = 0; k < sizeZ; k++) {
/*     */       
/* 205 */       fireProgressChanged(this, k, sizeZ);
/* 206 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 208 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 211 */           int label = (int)image.getVoxel(x, y, k);
/* 212 */           if (label != 0)
/*     */           {
/*     */ 
/*     */             
/* 216 */             if (!labelIndices.containsKey(Integer.valueOf(label))) {
/*     */               
/* 218 */               System.err.println("Label image contains unknown label: " + label);
/*     */             } else {
/*     */               
/* 221 */               int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */               
/* 224 */               InertiaMoments3D moment = moments[index];
/* 225 */               moment.cx += x * sx;
/* 226 */               moment.cy += y * sy;
/* 227 */               moment.cz += k * sz;
/* 228 */               moment.count++;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 234 */     for (int j = 0; j < nLabels; j++) {
/*     */       
/* 236 */       (moments[j]).cx /= (moments[j]).count;
/* 237 */       (moments[j]).cy /= (moments[j]).count;
/* 238 */       (moments[j]).cz /= (moments[j]).count;
/*     */     } 
/*     */ 
/*     */     
/* 242 */     fireStatusChanged(this, "Ellipsoid: compute inertia matrices");
/* 243 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 245 */       fireProgressChanged(this, z, sizeZ);
/* 246 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 248 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 251 */           int label = (int)image.getVoxel(x, y, z);
/* 252 */           if (label != 0) {
/*     */ 
/*     */ 
/*     */             
/* 256 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 257 */             InertiaMoments3D moment = moments[index];
/*     */ 
/*     */             
/* 260 */             double x2 = x * sx - moment.cx;
/* 261 */             double y2 = y * sy - moment.cy;
/* 262 */             double z2 = z * sz - moment.cz;
/*     */ 
/*     */             
/* 265 */             moment.Ixx += x2 * x2;
/* 266 */             moment.Iyy += y2 * y2;
/* 267 */             moment.Izz += z2 * z2;
/* 268 */             moment.Ixy += x2 * y2;
/* 269 */             moment.Ixz += x2 * z2;
/* 270 */             moment.Iyz += y2 * z2;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     int i;
/* 276 */     for (i = 0; i < nLabels; i++) {
/*     */       
/* 278 */       (moments[i]).Ixx /= (moments[i]).count;
/* 279 */       (moments[i]).Iyy /= (moments[i]).count;
/* 280 */       (moments[i]).Izz /= (moments[i]).count;
/* 281 */       (moments[i]).Ixy /= (moments[i]).count;
/* 282 */       (moments[i]).Ixz /= (moments[i]).count;
/* 283 */       (moments[i]).Iyz /= (moments[i]).count;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 288 */     for (i = 0; i < nLabels; i++) {
/*     */       
/* 290 */       (moments[i]).Ixx += sx / 12.0D;
/* 291 */       (moments[i]).Iyy += sy / 12.0D;
/* 292 */       (moments[i]).Izz += sz / 12.0D;
/*     */     } 
/*     */ 
/*     */     
/* 296 */     for (i = 0; i < nLabels; i++) {
/*     */       
/* 298 */       (moments[i]).cx += 0.5D * sx + ox;
/* 299 */       (moments[i]).cy += 0.5D * sy + oy;
/* 300 */       (moments[i]).cz += 0.5D * sz + oz;
/*     */     } 
/*     */     
/* 303 */     return moments;
/*     */   }
/*     */ 
/*     */   
/*     */   public class InertiaMoments3D
/*     */   {
/* 309 */     int count = 0;
/*     */ 
/*     */     
/* 312 */     double cx = 0.0D;
/* 313 */     double cy = 0.0D;
/* 314 */     double cz = 0.0D;
/*     */ 
/*     */     
/* 317 */     double Ixx = 0.0D;
/* 318 */     double Ixy = 0.0D;
/* 319 */     double Ixz = 0.0D;
/* 320 */     double Iyy = 0.0D;
/* 321 */     double Iyz = 0.0D;
/* 322 */     double Izz = 0.0D;
/*     */ 
/*     */     
/*     */     public Ellipsoid equivalentEllipsoid() {
/*     */       double phi, theta, psi;
/* 327 */       SingularValueDecomposition svd = computeSVD();
/* 328 */       Matrix values = svd.getS();
/*     */ 
/*     */       
/* 331 */       double r1 = Math.sqrt(5.0D) * Math.sqrt(values.get(0, 0));
/* 332 */       double r2 = Math.sqrt(5.0D) * Math.sqrt(values.get(1, 1));
/* 333 */       double r3 = Math.sqrt(5.0D) * Math.sqrt(values.get(2, 2));
/*     */ 
/*     */       
/* 336 */       Matrix mat = svd.getU();
/* 337 */       double tmp = Math.hypot(mat.get(0, 0), mat.get(1, 0));
/*     */ 
/*     */ 
/*     */       
/* 341 */       if (tmp > 7.9E-323D) {
/*     */ 
/*     */         
/* 344 */         psi = Math.atan2(mat.get(2, 1), mat.get(2, 2));
/* 345 */         theta = Math.atan2(-mat.get(2, 0), tmp);
/* 346 */         phi = Math.atan2(mat.get(1, 0), mat.get(0, 0));
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 351 */         psi = Math.atan2(-mat.get(1, 2), mat.get(1, 1));
/* 352 */         theta = Math.atan2(-mat.get(2, 0), tmp);
/* 353 */         phi = 0.0D;
/*     */       } 
/*     */ 
/*     */       
/* 357 */       return new Ellipsoid(this.cx, this.cy, this.cz, r1, r2, r3, Math.toDegrees(phi), Math.toDegrees(theta), Math.toDegrees(psi));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayList<Vector3D> eigenVectors() {
/* 363 */       Matrix mat = computeSVD().getU();
/*     */       
/* 365 */       ArrayList<Vector3D> res = new ArrayList<Vector3D>(3);
/* 366 */       for (int i = 0; i < 3; i++)
/*     */       {
/* 368 */         res.add(new Vector3D(mat.get(0, i), mat.get(1, i), mat.get(2, i)));
/*     */       }
/* 370 */       return res;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private SingularValueDecomposition computeSVD() {
/* 376 */       Matrix matrix = new Matrix(3, 3);
/* 377 */       matrix.set(0, 0, this.Ixx);
/* 378 */       matrix.set(0, 1, this.Ixy);
/* 379 */       matrix.set(0, 2, this.Ixz);
/* 380 */       matrix.set(1, 0, this.Ixy);
/* 381 */       matrix.set(1, 1, this.Iyy);
/* 382 */       matrix.set(1, 2, this.Iyz);
/* 383 */       matrix.set(2, 0, this.Ixz);
/* 384 */       matrix.set(2, 1, this.Iyz);
/* 385 */       matrix.set(2, 2, this.Izz);
/*     */ 
/*     */       
/* 388 */       return new SingularValueDecomposition(matrix);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/InertiaEllipsoid.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */