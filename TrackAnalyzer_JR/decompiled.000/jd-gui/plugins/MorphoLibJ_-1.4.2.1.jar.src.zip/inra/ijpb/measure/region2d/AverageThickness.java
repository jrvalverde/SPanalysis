/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AverageThickness
/*     */   extends RegionAnalyzer2D<AverageThickness.Result>
/*     */ {
/*     */   public ResultsTable createTable(Map<Integer, Result> results) {
/*  42 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/*  46 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  49 */       Result res = results.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  52 */       table.incrementCounter();
/*  53 */       table.addLabel(Integer.toString(label));
/*  54 */       table.addValue("AverageThickness", res.avgThickness); }
/*     */ 
/*     */     
/*  57 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/*  64 */     Map<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/*  67 */     ImageProcessor distanceMap = BinaryImages.distanceMap(image);
/*     */ 
/*     */     
/*  70 */     ImageProcessor skeleton = BinaryImages.skeleton(image);
/*     */ 
/*     */     
/*  73 */     int nLabels = labels.length;
/*  74 */     double[] sums = new double[nLabels];
/*  75 */     int[] counts = new int[nLabels];
/*     */ 
/*     */     
/*  78 */     int sizeX = image.getWidth();
/*  79 */     int sizeY = image.getHeight();
/*  80 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/*  82 */       for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */         
/*  85 */         int label = (int)skeleton.getf(x, y);
/*  86 */         if (label != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  91 */           int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */           
/*  94 */           sums[index] = sums[index] + distanceMap.getf(x, y);
/*  95 */           counts[index] = counts[index] + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     Result[] results = new Result[nLabels];
/* 101 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 103 */       Result res = new Result();
/* 104 */       res.meanDist = sums[i] / counts[i];
/* 105 */       res.avgThickness = res.meanDist * 2.0D - 1.0D;
/* 106 */       results[i] = res;
/*     */     } 
/* 108 */     return results;
/*     */   }
/*     */   
/*     */   public class Result {
/*     */     public double meanDist;
/*     */     public double avgThickness;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/AverageThickness.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */