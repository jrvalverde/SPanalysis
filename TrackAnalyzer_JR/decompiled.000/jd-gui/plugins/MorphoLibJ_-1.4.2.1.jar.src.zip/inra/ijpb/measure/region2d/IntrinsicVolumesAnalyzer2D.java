/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoEvent;
/*     */ import inra.ijpb.algo.AlgoListener;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrinsicVolumesAnalyzer2D
/*     */   extends RegionAnalyzer2D<IntrinsicVolumesAnalyzer2D.Result>
/*     */   implements AlgoListener
/*     */ {
/*     */   @Deprecated
/*     */   public static final double[] areaLut(Calibration calib) {
/*  35 */     return IntrinsicVolumes2DUtils.areaLut(calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] perimeterLut(Calibration calib, int nDirs) {
/*  55 */     return IntrinsicVolumes2DUtils.perimeterLut(calib, nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] computeCircularities(Result[] morphos) {
/*  62 */     int n = morphos.length;
/*  63 */     double[] circularities = new double[n];
/*  64 */     for (int i = 0; i < n; i++)
/*     */     {
/*  66 */       circularities[i] = morphos[i].circularity();
/*     */     }
/*  68 */     return circularities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] eulerNumberLut(int conn) {
/*  86 */     return IntrinsicVolumes2DUtils.eulerNumberLut(conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int[] eulerNumberIntLut(int conn) {
/* 104 */     return IntrinsicVolumes2DUtils.eulerNumberIntLut(conn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean computeArea = true;
/*     */ 
/*     */   
/*     */   boolean computePerimeter = true;
/*     */ 
/*     */   
/*     */   boolean computeEulerNumber = true;
/*     */ 
/*     */   
/* 118 */   int directionNumber = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDirectionNumber() {
/* 142 */     return this.directionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectionNumber(int directionNumber) {
/* 152 */     this.directionNumber = directionNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/* 160 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int connectivity) {
/* 170 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Result> results) {
/* 181 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/* 185 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 188 */       Result res = results.get(Integer.valueOf(label));
/*     */ 
/*     */       
/* 191 */       table.incrementCounter();
/* 192 */       table.addLabel(Integer.toString(label));
/*     */ 
/*     */       
/* 195 */       table.addValue("Area", res.area);
/* 196 */       table.addValue("Perimeter", res.perimeter);
/* 197 */       table.addValue("EulerNumber", res.eulerNumber); }
/*     */ 
/*     */     
/* 200 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/* 208 */     BinaryConfigurationsHistogram2D algo = new BinaryConfigurationsHistogram2D();
/* 209 */     algo.addAlgoListener(this);
/* 210 */     int[][] histograms = algo.process(image, labels);
/*     */ 
/*     */     
/* 213 */     Result[] results = new Result[labels.length];
/* 214 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/* 216 */       results[i] = new Result();
/*     */     }
/*     */ 
/*     */     
/* 220 */     if (this.computeArea) {
/*     */       
/* 222 */       double[] areaLut = IntrinsicVolumes2DUtils.areaLut(calib);
/* 223 */       double[] areas = BinaryConfigurationsHistogram2D.applyLut(histograms, areaLut);
/* 224 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 226 */         (results[j]).area = areas[j];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 231 */     if (this.computePerimeter) {
/*     */       
/* 233 */       double[] perimLut = IntrinsicVolumes2DUtils.perimeterLut(calib, this.directionNumber);
/* 234 */       double[] perims = BinaryConfigurationsHistogram2D.applyLut(histograms, perimLut);
/* 235 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 237 */         (results[j]).perimeter = perims[j];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 242 */     if (this.computeEulerNumber) {
/*     */       
/* 244 */       double[] eulerLut = IntrinsicVolumes2DUtils.eulerNumberLut(this.connectivity);
/* 245 */       double[] eulers = BinaryConfigurationsHistogram2D.applyLut(histograms, eulerLut);
/* 246 */       for (int j = 0; j < labels.length; j++)
/*     */       {
/* 248 */         (results[j]).eulerNumber = eulers[j];
/*     */       }
/*     */     } 
/*     */     
/* 252 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoProgressChanged(AlgoEvent evt) {
/* 263 */     fireProgressChanged(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void algoStatusChanged(AlgoEvent evt) {
/* 269 */     fireStatusChanged(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Result
/*     */   {
/* 278 */     public double area = Double.NaN;
/* 279 */     public double perimeter = Double.NaN;
/* 280 */     public double eulerNumber = Double.NaN;
/*     */ 
/*     */ 
/*     */     
/*     */     public Result() {}
/*     */ 
/*     */     
/*     */     public Result(double area, double perim, double euler) {
/* 288 */       this.area = area;
/* 289 */       this.perimeter = perim;
/* 290 */       this.eulerNumber = euler;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public double circularity() {
/* 304 */       return 12.566370614359172D * this.area / this.perimeter * this.perimeter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/IntrinsicVolumesAnalyzer2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */