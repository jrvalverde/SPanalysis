/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.geometry.Box2D;
/*     */ import inra.ijpb.geometry.Polygon2D;
/*     */ import inra.ijpb.geometry.Polygons2D;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Convexity
/*     */   extends RegionAnalyzer2D<Convexity.Result>
/*     */ {
/*     */   public static final ImageProcessor convexify(ImageProcessor binaryImage) {
/*  41 */     ArrayList<Point2D> points = RegionBoundaries.boundaryPixelsMiddleEdges(binaryImage);
/*  42 */     Polygon2D convexHull = Polygons2D.convexHull(points);
/*     */ 
/*     */     
/*  45 */     int sizeX = binaryImage.getWidth();
/*  46 */     int sizeY = binaryImage.getHeight();
/*  47 */     ByteProcessor byteProcessor = new ByteProcessor(sizeX, sizeY);
/*     */ 
/*     */     
/*  50 */     Box2D box = convexHull.boundingBox();
/*  51 */     int ymin = (int)Math.max(0.0D, Math.floor(box.getYMin()));
/*  52 */     int ymax = (int)Math.min(sizeY, Math.ceil(box.getYMax()));
/*  53 */     int xmin = (int)Math.max(0.0D, Math.floor(box.getXMin()));
/*  54 */     int xmax = (int)Math.min(sizeX, Math.ceil(box.getXMax()));
/*     */ 
/*     */     
/*  57 */     for (int y = ymin; y < ymax; y++) {
/*     */       
/*  59 */       for (int x = xmin; x < xmax; x++) {
/*     */         
/*  61 */         if (convexHull.contains(new Point2D.Double(x + 0.5D, y + 0.5D)))
/*     */         {
/*  63 */           byteProcessor.set(x, y, 255);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     return (ImageProcessor)byteProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable createTable(Map<Integer, Result> results) {
/*  75 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */ 
/*     */     
/*  79 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/*  82 */       Result res = results.get(Integer.valueOf(label));
/*     */ 
/*     */       
/*  85 */       table.incrementCounter();
/*  86 */       table.addLabel(Integer.toString(label));
/*  87 */       table.addValue("Area", res.area);
/*  88 */       table.addValue("ConvexArea", res.convexArea);
/*  89 */       table.addValue("Convexity", res.convexity); }
/*     */ 
/*     */     
/*  92 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result[] analyzeRegions(ImageProcessor image, int[] labels, Calibration calib) {
/* 100 */     int sizeX = image.getWidth();
/* 101 */     int sizeY = image.getHeight();
/*     */ 
/*     */     
/* 104 */     double pixelArea = calib.pixelWidth * calib.pixelHeight;
/*     */ 
/*     */     
/* 107 */     Result[] res = new Result[labels.length];
/*     */ 
/*     */     
/* 110 */     ArrayList[] pointArrays = (ArrayList[])RegionBoundaries.boundaryPixelsMiddleEdges(image, labels);
/*     */ 
/*     */     
/* 113 */     for (int i = 0; i < labels.length; i++) {
/*     */ 
/*     */       
/* 116 */       Polygon2D convexHull = Polygons2D.convexHull(pointArrays[i]);
/*     */ 
/*     */       
/* 119 */       Box2D box = convexHull.boundingBox();
/* 120 */       int xmin = (int)Math.max(0.0D, Math.floor(box.getXMin()));
/* 121 */       int xmax = (int)Math.min(sizeX, Math.ceil(box.getXMax()));
/* 122 */       int ymin = (int)Math.max(0.0D, Math.floor(box.getYMin()));
/* 123 */       int ymax = (int)Math.min(sizeY, Math.ceil(box.getYMax()));
/*     */       
/* 125 */       double area = 0.0D;
/* 126 */       double convexArea = 0.0D;
/*     */ 
/*     */       
/* 129 */       for (int y = ymin; y < ymax; y++) {
/*     */         
/* 131 */         for (int x = xmin; x < xmax; x++) {
/*     */           
/* 133 */           if ((int)image.getf(x, y) == labels[i])
/*     */           {
/* 135 */             area++;
/*     */           }
/* 137 */           if (convexHull.contains(new Point2D.Double(x + 0.5D, y + 0.5D)))
/*     */           {
/* 139 */             convexArea++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 145 */       area *= pixelArea;
/* 146 */       convexArea *= pixelArea;
/*     */ 
/*     */       
/* 149 */       res[i] = new Result(area, convexArea);
/*     */     } 
/*     */     
/* 152 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Result
/*     */   {
/*     */     public double area;
/*     */ 
/*     */ 
/*     */     
/*     */     public double convexArea;
/*     */ 
/*     */ 
/*     */     
/*     */     public double convexity;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Result(double area, double convexArea) {
/* 174 */       this.area = area;
/* 175 */       this.convexArea = convexArea;
/* 176 */       this.convexity = area / convexArea;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/Convexity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */