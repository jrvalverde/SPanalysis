/*     */ package inra.ijpb.measure;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.InertiaEllipse;
/*     */ import inra.ijpb.measure.region2d.LargestInscribedCircle;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GeometricMeasures2D
/*     */ {
/*     */   public static boolean debug = false;
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable analyzeRegions(ImageProcessor labelImage, double[] resol) {
/*  81 */     return analyzeRegions(labelImage, resol, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable analyzeRegions(ImageProcessor labelImage, double[] resol, int nDirs) {
/* 102 */     if (labelImage == null) {
/* 103 */       return null;
/*     */     }
/*     */     
/* 106 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 107 */     int nbLabels = labels.length;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     Calibration calib = new Calibration();
/* 113 */     calib.pixelWidth = resol[0];
/* 114 */     calib.pixelHeight = resol[1];
/* 115 */     double[] areas = IntrinsicVolumes2D.areas(labelImage, labels, calib);
/* 116 */     double[] perims = IntrinsicVolumes2D.perimeters(labelImage, labels, calib, nDirs);
/*     */ 
/*     */     
/* 119 */     ResultsTable table = new ResultsTable();
/* 120 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 122 */       int label = labels[i];
/*     */       
/* 124 */       table.incrementCounter();
/* 125 */       table.addLabel(Integer.toString(label));
/*     */       
/* 127 */       table.addValue("Area", areas[i]);
/* 128 */       table.addValue("Perimeter", perims[i]);
/*     */ 
/*     */       
/* 131 */       double p = perims[i];
/* 132 */       double circu = Math.min(12.566370614359172D * areas[i] / p * p, 1.0D);
/* 133 */       table.addValue("Circularity", circu);
/* 134 */       table.addValue("Elong.", 1.0D / circu);
/*     */     } 
/* 136 */     IJ.showStatus("");
/*     */     
/* 138 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable boundingBox(ImageProcessor labelImage) {
/* 157 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 158 */     int nbLabels = labels.length;
/*     */     
/* 160 */     double[][] boxes = boundingBox(labelImage, labels);
/*     */ 
/*     */     
/* 163 */     ResultsTable table = new ResultsTable();
/* 164 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 166 */       table.incrementCounter();
/* 167 */       table.addLabel(Integer.toString(labels[i]));
/* 168 */       table.addValue("XMin", boxes[i][0]);
/* 169 */       table.addValue("XMax", boxes[i][1]);
/* 170 */       table.addValue("YMin", boxes[i][2]);
/* 171 */       table.addValue("YMax", boxes[i][3]);
/*     */     } 
/*     */     
/* 174 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[][] boundingBox(ImageProcessor labelImage, int[] labels) {
/* 195 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 198 */     int nLabels = labels.length;
/* 199 */     double[][] boxes = new double[nLabels][6];
/* 200 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 202 */       boxes[i][0] = Double.POSITIVE_INFINITY;
/* 203 */       boxes[i][1] = Double.NEGATIVE_INFINITY;
/* 204 */       boxes[i][2] = Double.POSITIVE_INFINITY;
/* 205 */       boxes[i][3] = Double.NEGATIVE_INFINITY;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 210 */     int sizeX = labelImage.getWidth();
/* 211 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 214 */     IJ.showStatus("Compute Bounding boxes");
/* 215 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 217 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 219 */         int label = labelImage.get(x, y);
/*     */         
/* 221 */         if (label != 0) {
/*     */           
/* 223 */           int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */           
/* 226 */           boxes[labelIndex][0] = Math.min(boxes[labelIndex][0], x);
/* 227 */           boxes[labelIndex][1] = Math.max(boxes[labelIndex][1], x);
/* 228 */           boxes[labelIndex][2] = Math.min(boxes[labelIndex][2], y);
/* 229 */           boxes[labelIndex][3] = Math.max(boxes[labelIndex][3], y);
/*     */         } 
/*     */       } 
/*     */     } 
/* 233 */     IJ.showStatus("");
/* 234 */     return boxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] area(ImageProcessor image, int[] labels, double[] resol) {
/* 258 */     if (resol == null || resol.length != 2) {
/* 259 */       throw new IllegalArgumentException(
/* 260 */           "Resolution must be a double array of length 2");
/*     */     }
/*     */     
/* 263 */     Calibration calib = new Calibration();
/* 264 */     calib.pixelWidth = resol[0];
/* 265 */     calib.pixelHeight = resol[1];
/*     */     
/* 267 */     return IntrinsicVolumes2D.areas(image, labels, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int particleArea(ImageProcessor image, int label) {
/* 282 */     int[] counts = LabelImages.pixelCount(image, new int[] { label });
/* 283 */     return counts[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable croftonPerimeter(ImageProcessor labelImage, double[] resol, int nDirs) {
/* 305 */     if (labelImage == null) {
/* 306 */       return null;
/*     */     }
/* 308 */     int[] labels = LabelImages.findAllLabels(labelImage);
/* 309 */     int nbLabels = labels.length;
/*     */     
/* 311 */     Calibration calib = new Calibration();
/* 312 */     calib.pixelWidth = resol[0];
/* 313 */     calib.pixelHeight = resol[1];
/* 314 */     double[] areas = IntrinsicVolumes2D.areas(labelImage, labels, calib);
/* 315 */     double[] perims = IntrinsicVolumes2D.perimeters(labelImage, labels, calib, nDirs);
/*     */ 
/*     */     
/* 318 */     ResultsTable table = new ResultsTable();
/* 319 */     for (int i = 0; i < nbLabels; i++) {
/*     */       
/* 321 */       int label = labels[i];
/*     */       
/* 323 */       table.incrementCounter();
/* 324 */       table.addLabel(Integer.toString(label));
/*     */       
/* 326 */       table.addValue("Area", areas[i]);
/* 327 */       table.addValue("Perimeter", perims[i]);
/*     */ 
/*     */       
/* 330 */       double p = perims[i];
/* 331 */       double circu = Math.min(12.566370614359172D * areas[i] / p * p, 1.0D);
/* 332 */       table.addValue("Circularity", circu);
/* 333 */       table.addValue("Elong.", 1.0D / circu);
/*     */     } 
/* 335 */     IJ.showStatus("");
/*     */     
/* 337 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] croftonPerimeter(ImageProcessor image, int[] labels, double[] resol, int nDirs) {
/* 363 */     Calibration calib = new Calibration();
/* 364 */     calib.pixelWidth = resol[0];
/* 365 */     calib.pixelHeight = resol[1];
/*     */     
/* 367 */     return IntrinsicVolumes2D.perimeters(image, labels, calib, nDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] croftonPerimeterD2(ImageProcessor labelImage, int[] labels, double[] resol) {
/* 395 */     Calibration calib = new Calibration();
/* 396 */     calib.pixelWidth = resol[0];
/* 397 */     calib.pixelHeight = resol[1];
/*     */     
/* 399 */     return IntrinsicVolumes2D.perimeters(labelImage, labels, calib, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[] croftonPerimeterD4(ImageProcessor labelImage, int[] labels, double[] resol) {
/* 425 */     Calibration calib = new Calibration();
/* 426 */     calib.pixelWidth = resol[0];
/* 427 */     calib.pixelHeight = resol[1];
/*     */     
/* 429 */     return IntrinsicVolumes2D.perimeters(labelImage, labels, calib, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable perimeterDensity(ImageProcessor image, double[] resol, int nDirs) {
/* 446 */     if (nDirs == 2) {
/* 447 */       return perimeterDensity_D2(image, resol);
/*     */     }
/* 449 */     return perimeterDensity_D4(image, resol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private static final ResultsTable perimeterDensity_D2(ImageProcessor image, double[] resol) {
/* 468 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/* 471 */     double d1 = resol[0];
/* 472 */     double d2 = resol[1];
/*     */ 
/*     */     
/* 475 */     double pixelArea = d1 * d2;
/*     */ 
/*     */     
/* 478 */     double[] weights = computeDirectionWeightsD4(resol);
/*     */     
/* 480 */     double area = particleArea(image, 255) * pixelArea;
/*     */ 
/*     */     
/* 483 */     int n1 = countTransitionsD00(image, 255, false);
/* 484 */     int n2 = countTransitionsD90(image, 255, false);
/*     */ 
/*     */ 
/*     */     
/* 488 */     double wd1 = n1 / d1 * weights[0];
/* 489 */     double wd2 = n2 / d2 * weights[1];
/*     */ 
/*     */     
/* 492 */     double perim = (wd1 + wd2) * pixelArea * Math.PI / 2.0D;
/*     */ 
/*     */     
/* 495 */     table.incrementCounter();
/*     */ 
/*     */     
/* 498 */     table.addValue("Area", area);
/*     */ 
/*     */     
/* 501 */     int pixelCount = image.getWidth() * image.getHeight();
/* 502 */     double refArea = pixelCount * pixelArea;
/* 503 */     table.addValue("A. Density", area / refArea);
/*     */     
/* 505 */     if (debug) {
/*     */ 
/*     */       
/* 508 */       table.addValue("N1", n1);
/* 509 */       table.addValue("N2", n2);
/*     */     } 
/*     */ 
/*     */     
/* 513 */     table.addValue("Perimeter", perim);
/*     */ 
/*     */     
/* 516 */     double refArea2 = (image.getWidth() - 1) * resol[0] * (
/* 517 */       image.getHeight() - 1) * resol[1];
/* 518 */     double perimDensity = perim / refArea2;
/* 519 */     table.addValue("P. Density", perimDensity);
/*     */     
/* 521 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ResultsTable perimeterDensity_D4(ImageProcessor image, double[] resol) {
/* 538 */     ResultsTable table = new ResultsTable();
/*     */ 
/*     */     
/* 541 */     double d1 = resol[0];
/* 542 */     double d2 = resol[1];
/* 543 */     double d12 = Math.hypot(d1, d2);
/*     */ 
/*     */     
/* 546 */     double pixelArea = d1 * d2;
/*     */ 
/*     */     
/* 549 */     double[] weights = computeDirectionWeightsD4(resol);
/*     */     
/* 551 */     double area = particleArea(image, 255) * pixelArea;
/*     */ 
/*     */     
/* 554 */     int n1 = countTransitionsD00(image, 255, false);
/* 555 */     int n2 = countTransitionsD90(image, 255, false);
/* 556 */     int n3 = countTransitionsD45(image, 255, false);
/* 557 */     int n4 = countTransitionsD135(image, 255, false);
/*     */ 
/*     */ 
/*     */     
/* 561 */     double wd1 = n1 / d1 * weights[0];
/* 562 */     double wd2 = n2 / d2 * weights[1];
/* 563 */     double wd3 = n3 / d12 * weights[2];
/* 564 */     double wd4 = n4 / d12 * weights[3];
/*     */ 
/*     */     
/* 567 */     double perim = (wd1 + wd2 + wd3 + wd4) * pixelArea * Math.PI / 2.0D;
/*     */ 
/*     */     
/* 570 */     table.incrementCounter();
/*     */ 
/*     */     
/* 573 */     table.addValue("Area", area);
/*     */ 
/*     */     
/* 576 */     int pixelCount = image.getWidth() * image.getHeight();
/* 577 */     double refArea = pixelCount * pixelArea;
/* 578 */     table.addValue("A. Density", area / refArea);
/*     */     
/* 580 */     if (debug) {
/*     */ 
/*     */       
/* 583 */       table.addValue("N1", n1);
/* 584 */       table.addValue("N2", n2);
/* 585 */       table.addValue("N3", n3);
/* 586 */       table.addValue("N4", n4);
/*     */     } 
/*     */ 
/*     */     
/* 590 */     table.addValue("Perimeter", perim);
/*     */ 
/*     */     
/* 593 */     double refArea2 = ((image.getWidth() - 1) * (image.getHeight() - 1)) * 
/* 594 */       pixelArea;
/* 595 */     double perimDensity = perim / refArea2;
/* 596 */     table.addValue("P. Density", perimDensity);
/*     */     
/* 598 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int countTransitionsD00(ImageProcessor image, int label, boolean countBorder) {
/* 608 */     int width = image.getWidth();
/* 609 */     int height = image.getHeight();
/*     */     
/* 611 */     int count = 0;
/* 612 */     int previous = 0;
/*     */ 
/*     */ 
/*     */     
/* 616 */     for (int y = 0; y < height; y++) {
/*     */ 
/*     */       
/* 619 */       previous = (int)image.getf(0, y);
/* 620 */       if (countBorder && previous == label) {
/* 621 */         count++;
/*     */       }
/*     */       
/* 624 */       for (int x = 0; x < width; x++) {
/* 625 */         int current = (int)image.getf(x, y);
/* 626 */         if ((((previous == label) ? 1 : 0) ^ ((current == label) ? 1 : 0)) != 0)
/* 627 */           count++; 
/* 628 */         previous = current;
/*     */       } 
/*     */ 
/*     */       
/* 632 */       if (countBorder && previous == label) {
/* 633 */         count++;
/*     */       }
/*     */     } 
/* 636 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int countTransitionsD90(ImageProcessor image, int label, boolean countBorder) {
/* 646 */     int width = image.getWidth();
/* 647 */     int height = image.getHeight();
/*     */     
/* 649 */     int count = 0;
/* 650 */     int previous = 0;
/*     */ 
/*     */ 
/*     */     
/* 654 */     for (int x = 0; x < width; x++) {
/*     */ 
/*     */       
/* 657 */       previous = (int)image.getf(x, 0);
/* 658 */       if (countBorder && previous == label) {
/* 659 */         count++;
/*     */       }
/*     */       
/* 662 */       for (int y = 0; y < height; y++) {
/*     */         
/* 664 */         int current = (int)image.getf(x, y);
/* 665 */         if ((((previous == label) ? 1 : 0) ^ ((current == label) ? 1 : 0)) != 0)
/* 666 */           count++; 
/* 667 */         previous = current;
/*     */       } 
/*     */       
/* 670 */       if (countBorder && previous == label) {
/* 671 */         count++;
/*     */       }
/*     */     } 
/* 674 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int countTransitionsD45(ImageProcessor image, int label, boolean countBorder) {
/* 684 */     int width = image.getWidth();
/* 685 */     int height = image.getHeight();
/* 686 */     int nDiags = width + height - 1;
/*     */     
/* 688 */     int count = 0;
/* 689 */     int previous = 0;
/*     */ 
/*     */ 
/*     */     
/* 693 */     for (int i = 0; i < nDiags; i++) {
/*     */       
/* 695 */       int x0 = Math.max(width - i - 1, 0);
/* 696 */       int x1 = Math.min(nDiags - i, width);
/* 697 */       int y0 = Math.max(i + 1 - width, 0);
/* 698 */       int y1 = Math.min(i + 1, height);
/*     */ 
/*     */       
/* 701 */       previous = (int)image.getf(x0, y0);
/* 702 */       if (countBorder && previous == label) {
/* 703 */         count++;
/*     */       }
/*     */       
/* 706 */       int lineLength = x1 - x0;
/* 707 */       int lineLength2 = y1 - y0;
/* 708 */       assert lineLength == lineLength2 : "Bounds must be equal (upper diagonal " + 
/* 709 */         i + ")";
/*     */ 
/*     */       
/* 712 */       for (int j = 1; j < lineLength; j++) {
/*     */         
/* 714 */         int current = (int)image.getf(x0 + j, y0 + j);
/* 715 */         if ((((previous == label) ? 1 : 0) ^ ((current == label) ? 1 : 0)) != 0)
/* 716 */           count++; 
/* 717 */         previous = current;
/*     */       } 
/*     */ 
/*     */       
/* 721 */       if (countBorder && previous == label) {
/* 722 */         count++;
/*     */       }
/*     */     } 
/* 725 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int countTransitionsD135(ImageProcessor image, int label, boolean countBorder) {
/* 735 */     int width = image.getWidth();
/* 736 */     int height = image.getHeight();
/* 737 */     int nDiags = width + height - 1;
/*     */     
/* 739 */     int count = 0;
/* 740 */     int previous = 0;
/*     */ 
/*     */ 
/*     */     
/* 744 */     for (int i = 0; i < nDiags; i++) {
/*     */       
/* 746 */       int x0 = Math.max(i + 1 - height, 0);
/* 747 */       int x1 = Math.min(i, width - 1);
/* 748 */       int y0 = Math.min(i, height - 1);
/* 749 */       int y1 = Math.max(i + 1 - width, 0);
/*     */ 
/*     */       
/* 752 */       previous = (int)image.getf(x0, y0);
/* 753 */       if (countBorder && previous == label) {
/* 754 */         count++;
/*     */       }
/*     */       
/* 757 */       int lineLength = x1 - x0;
/* 758 */       int lineLength2 = y0 - y1;
/* 759 */       assert lineLength == lineLength2 : "Bounds must be equal (lower diagonal " + 
/* 760 */         i + ")";
/*     */ 
/*     */       
/* 763 */       for (int j = 1; j <= lineLength; j++) {
/*     */         
/* 765 */         int current = (int)image.getf(x0 + j, y0 - j);
/* 766 */         if ((((previous == label) ? 1 : 0) ^ ((current == label) ? 1 : 0)) != 0)
/* 767 */           count++; 
/* 768 */         previous = current;
/*     */       } 
/*     */ 
/*     */       
/* 772 */       if (countBorder && previous == label) {
/* 773 */         count++;
/*     */       }
/*     */     } 
/* 776 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] computeDirectionWeightsD4(double[] resol) {
/* 790 */     double d1 = resol[0];
/* 791 */     double d2 = resol[1];
/*     */ 
/*     */     
/* 794 */     double theta = Math.atan2(d2, d1);
/*     */ 
/*     */     
/* 797 */     double alpha1 = theta / Math.PI;
/*     */ 
/*     */     
/* 800 */     double alpha2 = (1.5707963267948966D - theta) / Math.PI;
/*     */ 
/*     */     
/* 803 */     double alpha34 = 0.25D;
/*     */ 
/*     */     
/* 806 */     return new double[] { alpha1, alpha2, alpha34, alpha34 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final double[][] centroids(ImageProcessor labelImage, int[] labels) {
/* 830 */     int nLabels = labels.length;
/* 831 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 834 */     int[] counts = new int[nLabels];
/* 835 */     double[][] centroids = new double[nLabels][2];
/*     */ 
/*     */     
/* 838 */     int sizeX = labelImage.getWidth();
/* 839 */     int sizeY = labelImage.getHeight();
/* 840 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 842 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 844 */         int label = (int)labelImage.getf(x, y);
/* 845 */         if (label != 0)
/*     */         {
/*     */ 
/*     */           
/* 849 */           if (labelIndices.containsKey(Integer.valueOf(label))) {
/*     */ 
/*     */             
/* 852 */             int index = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/* 853 */             centroids[index][0] = centroids[index][0] + x;
/* 854 */             centroids[index][1] = centroids[index][1] + y;
/* 855 */             counts[index] = counts[index] + 1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 860 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 862 */       centroids[i][0] = centroids[i][0] / counts[i];
/* 863 */       centroids[i][1] = centroids[i][1] / counts[i];
/*     */     } 
/*     */     
/* 866 */     return centroids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable inertiaEllipse(ImageProcessor image) {
/* 883 */     if (image == null) {
/* 884 */       return null;
/*     */     }
/* 886 */     Calibration calib = new Calibration();
/* 887 */     InertiaEllipse op = new InertiaEllipse();
/* 888 */     return op.createTable(op.analyzeRegions(image, calib));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable maximumInscribedCircle(ImageProcessor labelImage) {
/* 905 */     return maximumInscribedCircle(labelImage, new double[] { 1.0D, 1.0D });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final ResultsTable maximumInscribedCircle(ImageProcessor labelImage, double[] resol) {
/* 924 */     Calibration calib = new Calibration();
/* 925 */     calib.pixelWidth = resol[0];
/* 926 */     calib.pixelHeight = resol[1];
/*     */     
/* 928 */     LargestInscribedCircle op = new LargestInscribedCircle();
/* 929 */     return op.createTable(op.analyzeRegions(labelImage, calib));
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/GeometricMeasures2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */