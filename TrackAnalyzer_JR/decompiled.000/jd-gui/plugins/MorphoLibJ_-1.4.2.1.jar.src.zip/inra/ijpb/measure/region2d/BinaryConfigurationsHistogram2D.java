/*     */ package inra.ijpb.measure.region2d;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.AlgoStub;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryConfigurationsHistogram2D
/*     */   extends AlgoStub
/*     */ {
/*     */   public static final double applyLut(int[] histogram, double[] lut) {
/*  29 */     double sum = 0.0D;
/*  30 */     for (int i = 0; i < histogram.length; i++)
/*     */     {
/*  32 */       sum += histogram[i] * lut[i];
/*     */     }
/*  34 */     return sum;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int applyLut(int[] histogram, int[] lut) {
/*  39 */     int sum = 0;
/*  40 */     for (int i = 0; i < histogram.length; i++)
/*     */     {
/*  42 */       sum += histogram[i] * lut[i];
/*     */     }
/*  44 */     return sum;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final double[] applyLut(int[][] histograms, double[] lut) {
/*  49 */     double[] sums = new double[histograms.length];
/*  50 */     for (int iLabel = 0; iLabel < histograms.length; iLabel++)
/*     */     {
/*  52 */       sums[iLabel] = applyLut(histograms[iLabel], lut);
/*     */     }
/*  54 */     return sums;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int[] applyLut(int[][] histograms, int[] lut) {
/*  59 */     int[] sums = new int[histograms.length];
/*  60 */     for (int iLabel = 0; iLabel < histograms.length; iLabel++)
/*     */     {
/*  62 */       sums[iLabel] = applyLut(histograms[iLabel], lut);
/*     */     }
/*  64 */     return sums;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] process(ImageProcessor binaryImage) {
/*  97 */     int[] histogram = new int[16];
/*     */ 
/*     */     
/* 100 */     int sizeX = binaryImage.getWidth();
/* 101 */     int sizeY = binaryImage.getHeight();
/*     */ 
/*     */ 
/*     */     
/* 105 */     boolean[] configValues = new boolean[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     for (int y = 0; y < sizeY + 1; y++) {
/*     */       
/* 113 */       fireProgressChanged(this, y, (sizeY + 1));
/*     */       
/* 115 */       configValues[0] = false;
/* 116 */       configValues[2] = false;
/*     */       
/* 118 */       for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */         
/* 121 */         configValues[1] = ((((x < sizeX) ? 1 : 0) & ((y > 0) ? 1 : 0)) != 0) ? (((int)binaryImage.getf(x, y - 1) > 0)) : false;
/* 122 */         configValues[3] = ((((x < sizeX) ? 1 : 0) & ((y < sizeY) ? 1 : 0)) != 0) ? (((int)binaryImage.getf(x, y) > 0)) : false;
/*     */ 
/*     */         
/* 125 */         int index = configIndex(configValues);
/*     */ 
/*     */         
/* 128 */         histogram[index] = histogram[index] + 1;
/*     */ 
/*     */         
/* 131 */         configValues[0] = configValues[1];
/* 132 */         configValues[2] = configValues[3];
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 137 */     return histogram;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] processInnerFrame(ImageProcessor binaryImage) {
/* 143 */     int[] histogram = new int[16];
/*     */ 
/*     */     
/* 146 */     int sizeX = binaryImage.getWidth();
/* 147 */     int sizeY = binaryImage.getHeight();
/*     */ 
/*     */ 
/*     */     
/* 151 */     boolean[] configValues = new boolean[4];
/*     */ 
/*     */     
/* 154 */     for (int y = 1; y < sizeY; y++) {
/*     */       
/* 156 */       fireProgressChanged(this, y, sizeY);
/*     */       
/* 158 */       configValues[0] = (binaryImage.getf(0, y - 1) > 0.0F);
/* 159 */       configValues[2] = (binaryImage.getf(0, y) > 0.0F);
/*     */       
/* 161 */       for (int x = 1; x < sizeX; x++) {
/*     */ 
/*     */         
/* 164 */         configValues[1] = (binaryImage.getf(x, y - 1) > 0.0F);
/* 165 */         configValues[3] = (binaryImage.getf(x, y) > 0.0F);
/*     */ 
/*     */         
/* 168 */         int index = configIndex(configValues);
/*     */ 
/*     */         
/* 171 */         histogram[index] = histogram[index] + 1;
/*     */ 
/*     */         
/* 174 */         configValues[0] = configValues[1];
/* 175 */         configValues[2] = configValues[3];
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 180 */     return histogram;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int configIndex(boolean[] configValues) {
/* 186 */     int index = 0;
/* 187 */     index += configValues[0] ? 1 : 0;
/* 188 */     index += configValues[1] ? 2 : 0;
/* 189 */     index += configValues[2] ? 4 : 0;
/* 190 */     index += configValues[3] ? 8 : 0;
/* 191 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] process(ImageProcessor labelImage, int[] labels) {
/* 211 */     int nLabels = labels.length;
/* 212 */     HashMap<Integer, Integer> labelIndices = LabelImages.mapLabelIndices(labels);
/*     */ 
/*     */     
/* 215 */     int[][] histograms = new int[nLabels][16];
/*     */ 
/*     */     
/* 218 */     int sizeX = labelImage.getWidth();
/* 219 */     int sizeY = labelImage.getHeight();
/*     */ 
/*     */     
/* 222 */     ArrayList<Integer> localLabels = new ArrayList<Integer>(4);
/*     */ 
/*     */ 
/*     */     
/* 226 */     int[] configValues = new int[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     for (int y = 0; y < sizeY + 1; y++) {
/*     */       
/* 234 */       fireProgressChanged(this, y, (sizeY + 1));
/*     */       
/* 236 */       configValues[0] = 0;
/* 237 */       configValues[2] = 0;
/*     */       
/* 239 */       for (int x = 0; x < sizeX + 1; x++) {
/*     */ 
/*     */         
/* 242 */         configValues[1] = ((((x < sizeX) ? 1 : 0) & ((y > 0) ? 1 : 0)) != 0) ? (int)labelImage.getf(x, y - 1) : 0;
/* 243 */         configValues[3] = ((((x < sizeX) ? 1 : 0) & ((y < sizeY) ? 1 : 0)) != 0) ? (int)labelImage.getf(x, y) : 0;
/*     */ 
/*     */         
/* 246 */         localLabels.clear(); byte b; int i, arrayOfInt[];
/* 247 */         for (i = (arrayOfInt = configValues).length, b = 0; b < i; ) { int label = arrayOfInt[b];
/*     */           
/* 249 */           if (label != 0)
/*     */           {
/*     */             
/* 252 */             if (!localLabels.contains(Integer.valueOf(label)))
/* 253 */               localLabels.add(Integer.valueOf(label)); 
/*     */           }
/*     */           b++; }
/*     */         
/* 257 */         for (Iterator<Integer> iterator = localLabels.iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */           
/* 260 */           int index = configIndex(configValues, label);
/*     */ 
/*     */           
/* 263 */           int labelIndex = ((Integer)labelIndices.get(Integer.valueOf(label))).intValue();
/*     */ 
/*     */           
/* 266 */           histograms[labelIndex][index] = histograms[labelIndex][index] + 1; }
/*     */ 
/*     */ 
/*     */         
/* 270 */         configValues[0] = configValues[1];
/* 271 */         configValues[2] = configValues[3];
/*     */       } 
/*     */     } 
/*     */     
/* 275 */     fireProgressChanged(this, 1.0D, 1.0D);
/* 276 */     return histograms;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int configIndex(int[] configValues, int label) {
/* 282 */     int index = 0;
/* 283 */     index += (configValues[0] == label) ? 1 : 0;
/* 284 */     index += (configValues[1] == label) ? 2 : 0;
/* 285 */     index += (configValues[2] == label) ? 4 : 0;
/* 286 */     index += (configValues[3] == label) ? 8 : 0;
/* 287 */     return index;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region2d/BinaryConfigurationsHistogram2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */