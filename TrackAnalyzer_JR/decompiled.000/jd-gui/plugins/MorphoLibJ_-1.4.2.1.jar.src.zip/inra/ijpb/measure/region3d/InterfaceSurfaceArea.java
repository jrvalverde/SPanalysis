/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceSurfaceArea
/*     */ {
/*     */   private static final double[] interceptsContributions(Calibration calib, int nDirs) {
/*  41 */     if (nDirs == 3)
/*     */     {
/*  43 */       return interceptsContributionsD3(calib);
/*     */     }
/*  45 */     if (nDirs == 13)
/*     */     {
/*  47 */       return interceptsContributionsD13(calib);
/*     */     }
/*     */ 
/*     */     
/*  51 */     throw new IllegalArgumentException("Direction number mus be either 3 or 13");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] interceptsContributionsD3(Calibration calib) {
/*  57 */     double c1 = 0.3333333333333333D;
/*  58 */     return new double[] { c1, c1, c1, 0.0D, 0.0D, 0.0D, 0.0D };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double[] interceptsContributionsD13(Calibration calib) {
/*  67 */     double d1 = calib.pixelWidth;
/*  68 */     double d2 = calib.pixelHeight;
/*  69 */     double d3 = calib.pixelDepth;
/*  70 */     double vol = d1 * d2 * d3;
/*     */     
/*  72 */     double d12 = Math.hypot(d1, d2);
/*  73 */     double d13 = Math.hypot(d1, d3);
/*  74 */     double d23 = Math.hypot(d2, d3);
/*  75 */     double d123 = Math.hypot(d12, d3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     double[] weights = IntrinsicVolumes3DUtils.directionWeights3d13(calib);
/*     */ 
/*     */     
/*  83 */     double[] kei = new double[7];
/*     */     
/*  85 */     kei[0] = 4.0D * weights[0] * vol / d1 / 8.0D;
/*  86 */     kei[1] = 4.0D * weights[1] * vol / d2 / 8.0D;
/*  87 */     kei[2] = 4.0D * weights[2] * vol / d3 / 8.0D;
/*  88 */     kei[3] = 4.0D * weights[3] * vol / d12 / 4.0D;
/*  89 */     kei[4] = 4.0D * weights[4] * vol / d13 / 4.0D;
/*  90 */     kei[5] = 4.0D * weights[5] * vol / d23 / 4.0D;
/*  91 */     kei[6] = 4.0D * weights[6] * vol / d123 / 2.0D;
/*     */     
/*  93 */     return kei;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   int directionNumber = 13;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InterfaceSurfaceArea() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InterfaceSurfaceArea(int nDirs) {
/* 115 */     setDirectionNumber(nDirs);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDirectionNumber(int nDirs) {
/* 120 */     if (nDirs == 3 || nDirs == 13) {
/*     */       
/* 122 */       this.directionNumber = nDirs;
/*     */     }
/*     */     else {
/*     */       
/* 126 */       throw new IllegalArgumentException("Number of directions should be either 3 or 13.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double process(ImageStack stack, int label1, int label2, Calibration calib) {
/* 133 */     int[][] posList = {
/* 134 */         new int[3], {
/* 135 */           1
/* 136 */         }, { 0, 1
/* 137 */         }, { 1, 1
/* 138 */         }, { 0, 0, 1
/* 139 */         }, { 1, 1
/* 140 */         }, { 0, 1, 1
/* 141 */         }, { 1, 1, 1 }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 146 */     int[][] shifts = {
/* 147 */         { 1
/* 148 */         }, { 0, 1
/* 149 */         }, { 0, 0, 1
/* 150 */         }, { 1, 1
/* 151 */         }, { 1, 1
/* 152 */         }, { 0, 1, 1
/* 153 */         }, { 1, 1, 1 }
/*     */       };
/*     */ 
/*     */     
/* 157 */     double[] contribs = interceptsContributions(calib, this.directionNumber);
/* 158 */     int nNeighs = (this.directionNumber == 3) ? 3 : 7;
/*     */ 
/*     */     
/* 161 */     int sizeX = stack.getWidth();
/* 162 */     int sizeY = stack.getHeight();
/* 163 */     int sizeZ = stack.getSize();
/*     */     
/* 165 */     double value = 0.0D;
/*     */ 
/*     */     
/* 168 */     for (int z = 0; z < sizeZ - 1; z++) {
/*     */       
/* 170 */       for (int y = 0; y < sizeY - 1; y++) {
/*     */         
/* 172 */         for (int x = 0; x < sizeX - 1; x++) {
/*     */ 
/*     */           
/* 175 */           for (int iPos = 0; iPos < 8; iPos++) {
/*     */ 
/*     */             
/* 178 */             int[] pos = posList[iPos];
/* 179 */             int x1 = x + pos[0];
/* 180 */             int y1 = y + pos[1];
/* 181 */             int z1 = z + pos[2];
/* 182 */             int v1 = (int)stack.getVoxel(x1, y1, z1);
/* 183 */             if (v1 == label1)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 189 */               for (int iNeigh = 0; iNeigh < nNeighs; iNeigh++) {
/*     */ 
/*     */                 
/* 192 */                 int[] shift = shifts[iNeigh];
/* 193 */                 int x2 = (shift[0] > 0) ? (x + 1 - pos[0]) : x1;
/* 194 */                 int y2 = (shift[1] > 0) ? (y + 1 - pos[1]) : y1;
/* 195 */                 int z2 = (shift[2] > 0) ? (z + 1 - pos[2]) : z1;
/*     */ 
/*     */                 
/* 198 */                 int v2 = (int)stack.getVoxel(x2, y2, z2);
/* 199 */                 if (v2 == label2)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 205 */                   value += contribs[iNeigh]; } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 212 */     return value;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/InterfaceSurfaceArea.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */