/*     */ package inra.ijpb.measure.region3d;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionBoundaries3D
/*     */ {
/*     */   public static final Map<Integer, ArrayList<Point3D>> regionsCorners(ImageStack image, int[] labels) {
/*  41 */     int sizeX = image.getWidth();
/*  42 */     int sizeY = image.getHeight();
/*  43 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/*  46 */     Map<Integer, ArrayList<Point3D>> labelCornerPoints = new TreeMap<Integer, ArrayList<Point3D>>(); byte b; int i, arrayOfInt[];
/*  47 */     for (i = (arrayOfInt = labels).length, b = 0; b < i; ) { int label = arrayOfInt[b];
/*     */       
/*  49 */       labelCornerPoints.put(Integer.valueOf(label), new ArrayList<Point3D>());
/*     */       
/*     */       b++; }
/*     */     
/*  53 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/*  55 */       for (int y = 0; y < sizeY; y++) {
/*     */ 
/*     */         
/*  58 */         int currentLabel = 0;
/*     */ 
/*     */         
/*  61 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/*  63 */           int pixel = (int)image.getVoxel(x, y, z);
/*  64 */           if (pixel != currentLabel) {
/*     */ 
/*     */ 
/*     */             
/*  68 */             ArrayList<Point3D> newPoints = new ArrayList<Point3D>(4);
/*  69 */             newPoints.add(new Point3D(x, y, z));
/*  70 */             newPoints.add(new Point3D(x, (y + 1), z));
/*  71 */             newPoints.add(new Point3D(x, y, (z + 1)));
/*  72 */             newPoints.add(new Point3D(x, (y + 1), (z + 1)));
/*     */ 
/*     */             
/*  75 */             if (currentLabel > 0 && labelCornerPoints.containsKey(Integer.valueOf(currentLabel))) {
/*     */               
/*  77 */               ArrayList<Point3D> corners = labelCornerPoints.get(Integer.valueOf(currentLabel));
/*  78 */               for (Point3D p : newPoints) {
/*     */                 
/*  80 */                 if (!corners.contains(p))
/*     */                 {
/*  82 */                   corners.add(p);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*  88 */             if (pixel > 0 && labelCornerPoints.containsKey(Integer.valueOf(pixel))) {
/*     */               
/*  90 */               ArrayList<Point3D> corners = labelCornerPoints.get(Integer.valueOf(pixel));
/*  91 */               for (Point3D p : newPoints) {
/*     */                 
/*  93 */                 if (!corners.contains(p))
/*     */                 {
/*  95 */                   corners.add(p);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 100 */           currentLabel = pixel;
/*     */         } 
/*     */ 
/*     */         
/* 104 */         if (currentLabel > 0 && labelCornerPoints.containsKey(Integer.valueOf(currentLabel))) {
/*     */ 
/*     */ 
/*     */           
/* 108 */           ArrayList<Point3D> newPoints = new ArrayList<Point3D>(4);
/* 109 */           newPoints.add(new Point3D(sizeX, y, z));
/* 110 */           newPoints.add(new Point3D(sizeX, (y + 1), z));
/* 111 */           newPoints.add(new Point3D(sizeX, y, (z + 1)));
/* 112 */           newPoints.add(new Point3D(sizeX, (y + 1), (z + 1)));
/*     */           
/* 114 */           ArrayList<Point3D> corners = labelCornerPoints.get(Integer.valueOf(currentLabel));
/* 115 */           for (Point3D p : newPoints) {
/*     */             
/* 117 */             if (!corners.contains(p))
/*     */             {
/* 119 */               corners.add(p);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     return labelCornerPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ArrayList<Point3D>[] regionsCornersArray(ImageStack image, int[] labels) {
/* 142 */     Map<Integer, ArrayList<Point3D>> cornerPointsMap = regionsCorners(image, labels);
/*     */ 
/*     */     
/* 145 */     int nLabels = labels.length;
/*     */     
/* 147 */     ArrayList[] labelCornerPoints = new ArrayList[nLabels];
/*     */ 
/*     */     
/* 150 */     for (int i = 0; i < nLabels; i++)
/*     */     {
/* 152 */       labelCornerPoints[i] = cornerPointsMap.get(Integer.valueOf(labels[i]));
/*     */     }
/*     */     
/* 155 */     return (ArrayList<Point3D>[])labelCornerPoints;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/measure/region3d/RegionBoundaries3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */