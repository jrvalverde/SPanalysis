/*     */ package inra.ijpb.data;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PixelRecord
/*     */   implements Comparable<PixelRecord>
/*     */ {
/*  55 */   Cursor2D cursor = null;
/*  56 */   double value = 0.0D;
/*  57 */   static final AtomicLong seq = new AtomicLong();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long seqNum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelRecord(Cursor2D cursor, double value) {
/*  69 */     this.cursor = cursor;
/*  70 */     this.value = value;
/*  71 */     this.seqNum = seq.getAndIncrement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PixelRecord(int x, int y, double value) {
/*  79 */     this.cursor = new Cursor2D(x, y);
/*  80 */     this.value = value;
/*  81 */     this.seqNum = seq.getAndIncrement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Cursor2D getCursor() {
/*  87 */     return this.cursor;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  92 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(PixelRecord v2) {
/* 107 */     int res = Double.compare(this.value, v2.value);
/* 108 */     if (res == 0) {
/* 109 */       res = (this.seqNum < v2.seqNum) ? -1 : 1;
/*     */     }
/* 111 */     return res;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/PixelRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */