/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeriodicBorder3D
/*    */   implements BorderManager3D
/*    */ {
/*    */   ImageStack image;
/*    */   
/*    */   public PeriodicBorder3D(ImageStack image) {
/* 40 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y, int z) {
/* 49 */     x %= this.image.getWidth();
/* 50 */     y %= this.image.getHeight();
/* 51 */     z %= this.image.getSize();
/* 52 */     if (x < 0)
/* 53 */       x += this.image.getWidth(); 
/* 54 */     if (y < 0)
/* 55 */       y += this.image.getHeight(); 
/* 56 */     if (z < 0)
/* 57 */       z += this.image.getSize(); 
/* 58 */     return (int)this.image.getVoxel(x, y, z);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/PeriodicBorder3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */