/*    */ package inra.ijpb.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Neighborhood2D
/*    */ {
/*    */   Cursor2D cursor;
/*    */   
/*    */   public abstract Iterable<Cursor2D> getNeighbors();
/*    */   
/*    */   public void setCursor(Cursor2D cursor) {
/* 32 */     this.cursor = cursor;
/*    */   }
/*    */ 
/*    */   
/*    */   public Cursor2D getCursor() {
/* 37 */     return this.cursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Neighborhood2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */