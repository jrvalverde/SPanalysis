/*    */ package inra.ijpb.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cursor3D
/*    */ {
/* 30 */   private int x = 0;
/* 31 */   private int y = 0;
/* 32 */   private int z = 0;
/*    */ 
/*    */   
/*    */   public Cursor3D(int x, int y, int z) {
/* 36 */     this.x = x;
/* 37 */     this.y = y;
/* 38 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(int x, int y, int z) {
/* 43 */     this.x = x;
/* 44 */     this.y = y;
/* 45 */     this.z = z;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getX() {
/* 50 */     return this.x;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getY() {
/* 55 */     return this.y;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getZ() {
/* 60 */     return this.z;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object other) {
/* 66 */     if (other == null) return false; 
/* 67 */     if (other == this) return true; 
/* 68 */     if (!(other instanceof Cursor3D))
/* 69 */       return false; 
/* 70 */     Cursor3D c = (Cursor3D)other;
/* 71 */     return (c.x == this.x && c.y == this.y && c.z == this.z);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Cursor3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */