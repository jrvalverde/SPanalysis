/*     */ package inra.ijpb.data.image;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatStackWrapper
/*     */   implements Image3D
/*     */ {
/*     */   float[][] slices;
/*     */   int sizeX;
/*     */   int sizeY;
/*     */   int sizeZ;
/*     */   
/*     */   public FloatStackWrapper(ImageStack stack) {
/*  56 */     if (stack.getBitDepth() != 32)
/*     */     {
/*  58 */       throw new IllegalArgumentException("Requires a 32-bits stack");
/*     */     }
/*     */ 
/*     */     
/*  62 */     this.sizeX = stack.getWidth();
/*  63 */     this.sizeY = stack.getHeight();
/*  64 */     this.sizeZ = stack.getSize();
/*     */ 
/*     */     
/*  67 */     this.slices = new float[this.sizeZ][];
/*  68 */     Object[] array = stack.getImageArray();
/*  69 */     for (int i = 0; i < this.sizeZ; i++)
/*     */     {
/*  71 */       this.slices[i] = (float[])array[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize(int dim) {
/*  78 */     switch (dim) {
/*     */       case 0:
/*  80 */         return this.sizeX;
/*  81 */       case 1: return this.sizeY;
/*  82 */       case 2: return this.sizeZ;
/*     */     } 
/*  84 */     throw new IllegalArgumentException("Dimension must be comprised between 0 and 2, not " + dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(int x, int y, int z) {
/*  94 */     return (int)this.slices[z][y * this.sizeX + x];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int x, int y, int z, int value) {
/* 103 */     this.slices[z][y * this.sizeX + x] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(int x, int y, int z) {
/* 112 */     return this.slices[z][y * this.sizeX + x];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(Cursor3D pos) {
/* 118 */     return getValue(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int x, int y, int z, double value) {
/* 127 */     this.slices[z][y * this.sizeX + x] = (float)value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Cursor3D pos, double value) {
/* 133 */     setValue(pos.getX(), pos.getY(), pos.getZ(), value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/FloatStackWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */