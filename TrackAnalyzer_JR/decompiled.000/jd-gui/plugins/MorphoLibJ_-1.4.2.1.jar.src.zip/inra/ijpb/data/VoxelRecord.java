/*     */ package inra.ijpb.data;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VoxelRecord
/*     */   implements Comparable<VoxelRecord>
/*     */ {
/*  55 */   Cursor3D cursor = null;
/*  56 */   double value = 0.0D;
/*  57 */   static final AtomicLong seq = new AtomicLong();
/*     */ 
/*     */   
/*     */   final long seqNum;
/*     */ 
/*     */   
/*     */   public VoxelRecord(Cursor3D cursor, double value) {
/*  64 */     this.cursor = cursor;
/*  65 */     this.value = value;
/*  66 */     this.seqNum = seq.getAndIncrement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VoxelRecord(int x, int y, int z, double value) {
/*  75 */     this.cursor = new Cursor3D(x, y, z);
/*  76 */     this.value = value;
/*  77 */     this.seqNum = seq.getAndIncrement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Cursor3D getCursor() {
/*  83 */     return this.cursor;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  88 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(VoxelRecord v2) {
/* 103 */     int res = Double.compare(this.value, v2.value);
/* 104 */     if (res == 0) {
/* 105 */       res = (this.seqNum < v2.seqNum) ? -1 : 1;
/*     */     }
/* 107 */     return res;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/VoxelRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */