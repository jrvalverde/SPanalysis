/*     */ package inra.ijpb.data.image;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Images3D
/*     */ {
/*     */   public static final Image3D createWrapper(ImageStack stack) {
/*  53 */     switch (stack.getBitDepth()) {
/*     */       case 8:
/*  55 */         return new ByteStackWrapper(stack);
/*     */       case 16:
/*  57 */         return new ShortStackWrapper(stack);
/*     */       case 32:
/*  59 */         return new FloatStackWrapper(stack);
/*     */     } 
/*  61 */     throw new IllegalArgumentException(
/*  62 */         "Can not manage image stacks with bit depth " + 
/*  63 */         stack.getBitDepth());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isSameSize(ImageStack image1, ImageStack image2) {
/*  79 */     if (image1.getWidth() != image2.getWidth())
/*  80 */       return false; 
/*  81 */     if (image1.getHeight() != image2.getHeight())
/*  82 */       return false; 
/*  83 */     if (image1.getSize() != image2.getSize())
/*  84 */       return false; 
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isSameType(ImageStack image1, ImageStack image2) {
/* 100 */     return (image1.getBitDepth() == image2.getBitDepth());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] findMinAndMax(ImagePlus image) {
/* 111 */     return findMinAndMax(image.getImageStack());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final double[] findMinAndMax(ImageStack image) {
/* 122 */     double min = Double.MAX_VALUE;
/* 123 */     double max = Double.MIN_VALUE;
/* 124 */     for (int slice = 1; slice <= image.getSize(); slice++) {
/*     */       
/* 126 */       ImageProcessor ip = image.getProcessor(slice);
/*     */       
/* 128 */       for (int x = 0; x < ip.getWidth(); x++) {
/* 129 */         for (int y = 0; y < ip.getHeight(); y++) {
/*     */           
/* 131 */           float val = ip.getf(x, y);
/* 132 */           if (max < val)
/* 133 */             max = val; 
/* 134 */           if (min > val)
/* 135 */             min = val; 
/*     */         } 
/*     */       } 
/* 138 */     }  return new double[] { min, max };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void optimizeDisplayRange(ImagePlus image) {
/* 148 */     double[] extremeValue = findMinAndMax(image);
/* 149 */     image.setDisplayRange(extremeValue[0], extremeValue[1]);
/* 150 */     image.updateAndDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack adjustDynamic(ImageStack image, double vmin, double vmax) {
/* 169 */     int sizeX = image.getWidth();
/* 170 */     int sizeY = image.getHeight();
/* 171 */     int sizeZ = image.getSize();
/*     */ 
/*     */     
/* 174 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 8);
/*     */ 
/*     */     
/* 177 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 179 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 181 */         for (int x = 0; x < sizeX; x++) {
/*     */ 
/*     */           
/* 184 */           double value = image.getVoxel(x, y, z);
/* 185 */           value = 255.0D * (value - vmin) / (vmax - vmin);
/* 186 */           value = Math.max(Math.min(value, 255.0D), 0.0D);
/* 187 */           result.setVoxel(x, y, z, value);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 192 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void replaceValue(ImagePlus image, double initialValue, double finalValue) {
/* 197 */     if (image.getStackSize() == 1) {
/*     */       
/* 199 */       ImageProcessor img = image.getProcessor();
/* 200 */       for (int y = 0; y < img.getHeight(); y++) {
/*     */         
/* 202 */         for (int x = 0; x < img.getWidth(); x++)
/*     */         {
/* 204 */           if (img.getf(x, y) == initialValue)
/*     */           {
/* 206 */             img.setf(x, y, (float)finalValue);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 213 */       ImageStack img = image.getStack();
/* 214 */       for (int z = 0; z < img.getSize(); z++) {
/*     */         
/* 216 */         for (int y = 0; y < img.getHeight(); y++) {
/*     */           
/* 218 */           for (int x = 0; x < img.getWidth(); x++) {
/*     */             
/* 220 */             if (img.getVoxel(x, y, z) == initialValue)
/*     */             {
/* 222 */               img.setVoxel(x, y, z, finalValue);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void fill(ImageStack image, double value) {
/* 238 */     for (int z = 0; z < image.getSize(); z++) {
/*     */       
/* 240 */       for (int y = 0; y < image.getHeight(); y++) {
/*     */         
/* 242 */         for (int x = 0; x < image.getWidth(); x++)
/*     */         {
/* 244 */           image.setVoxel(x, y, z, value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void print(ImageStack image) {
/* 258 */     int nSlices = image.getSize();
/* 259 */     for (int z = 0; z < nSlices; z++) {
/*     */       
/* 261 */       System.out.println(String.format("slice %d/%d", new Object[] { Integer.valueOf(z), Integer.valueOf(nSlices - 1) }));
/* 262 */       for (int y = 0; y < image.getHeight(); y++) {
/*     */         
/* 264 */         for (int x = 0; x < image.getWidth(); x++) {
/*     */           
/* 266 */           System.out.print(String.format("%3d ", new Object[] { Integer.valueOf((int)image.getVoxel(x, y, z)) }));
/*     */         } 
/* 268 */         System.out.println("");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void invert(ImageStack image) {
/* 280 */     double[] extrema = findMinAndMax(image);
/* 281 */     int nSlices = image.getSize();
/* 282 */     for (int z = 0; z < nSlices; z++) {
/*     */       
/* 284 */       ImageProcessor ip = image.getProcessor(z + 1);
/* 285 */       for (int y = 0; y < image.getHeight(); y++) {
/*     */         
/* 287 */         for (int x = 0; x < image.getWidth(); x++) {
/*     */           
/* 289 */           float value = ip.getf(x, y);
/* 290 */           ip.setf(x, y, (float)(extrema[1] - value - extrema[0]));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final byte[][] getByteArrays(ImageStack image) {
/* 307 */     if (image.getBitDepth() != 8)
/*     */     {
/* 309 */       throw new IllegalArgumentException("Bit depth of input ImageStack must be 8");
/*     */     }
/*     */ 
/*     */     
/* 313 */     int nSlices = image.getSize();
/* 314 */     byte[][] slices = new byte[nSlices][];
/*     */ 
/*     */     
/* 317 */     Object[] array = image.getImageArray();
/* 318 */     for (int i = 0; i < nSlices; i++)
/*     */     {
/* 320 */       slices[i] = (byte[])array[i];
/*     */     }
/*     */ 
/*     */     
/* 324 */     return slices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final short[][] getShortArrays(ImageStack image) {
/* 338 */     if (image.getBitDepth() != 16)
/*     */     {
/* 340 */       throw new IllegalArgumentException("Bit depth of input ImageStack must be 16");
/*     */     }
/*     */ 
/*     */     
/* 344 */     int nSlices = image.getSize();
/* 345 */     short[][] slices = new short[nSlices][];
/*     */ 
/*     */     
/* 348 */     Object[] array = image.getImageArray();
/* 349 */     for (int i = 0; i < nSlices; i++)
/*     */     {
/* 351 */       slices[i] = (short[])array[i];
/*     */     }
/*     */ 
/*     */     
/* 355 */     return slices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final float[][] getFloatArrays(ImageStack image) {
/* 369 */     if (image.getBitDepth() != 32)
/*     */     {
/* 371 */       throw new IllegalArgumentException("Bit depth of input ImageStack must be 32");
/*     */     }
/*     */ 
/*     */     
/* 375 */     int nSlices = image.getSize();
/* 376 */     float[][] slices = new float[nSlices][];
/*     */ 
/*     */     
/* 379 */     Object[] array = image.getImageArray();
/* 380 */     for (int i = 0; i < nSlices; i++)
/*     */     {
/* 382 */       slices[i] = (float[])array[i];
/*     */     }
/*     */ 
/*     */     
/* 386 */     return slices;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/Images3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */