/*     */ package inra.ijpb.data.image;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShortStackWrapper
/*     */   implements Image3D
/*     */ {
/*     */   short[][] slices;
/*     */   int sizeX;
/*     */   int sizeY;
/*     */   int sizeZ;
/*     */   
/*     */   public ShortStackWrapper(ImageStack stack) {
/*  58 */     if (stack.getBitDepth() != 16)
/*     */     {
/*  60 */       throw new IllegalArgumentException("Requires a 16-bits stack");
/*     */     }
/*     */ 
/*     */     
/*  64 */     this.sizeX = stack.getWidth();
/*  65 */     this.sizeY = stack.getHeight();
/*  66 */     this.sizeZ = stack.getSize();
/*     */ 
/*     */     
/*  69 */     this.slices = new short[this.sizeZ][];
/*  70 */     Object[] array = stack.getImageArray();
/*  71 */     for (int i = 0; i < this.sizeZ; i++)
/*     */     {
/*  73 */       this.slices[i] = (short[])array[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize(int dim) {
/*  80 */     switch (dim) {
/*     */       case 0:
/*  82 */         return this.sizeX;
/*  83 */       case 1: return this.sizeY;
/*  84 */       case 2: return this.sizeZ;
/*     */     } 
/*  86 */     throw new IllegalArgumentException("Dimension must be comprised between 0 and 2, not " + dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(int x, int y, int z) {
/*  96 */     return this.slices[z][y * this.sizeX + x] & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int x, int y, int z, int value) {
/* 105 */     this.slices[z][y * this.sizeX + x] = (short)Math.max(Math.min(value, 65535), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(int x, int y, int z) {
/* 114 */     return (this.slices[z][y * this.sizeX + x] & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(Cursor3D pos) {
/* 120 */     return getValue(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int x, int y, int z, double value) {
/* 129 */     this.slices[z][y * this.sizeX + x] = (short)(int)Math.max(Math.min(value, 65535.0D), 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Cursor3D pos, double value) {
/* 135 */     setValue(pos.getX(), pos.getY(), pos.getZ(), value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/ShortStackWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */