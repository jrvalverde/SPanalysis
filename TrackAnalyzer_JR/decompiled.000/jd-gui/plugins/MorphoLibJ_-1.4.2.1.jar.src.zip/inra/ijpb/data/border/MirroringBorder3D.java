/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MirroringBorder3D
/*    */   implements BorderManager3D
/*    */ {
/*    */   ImageStack image;
/*    */   
/*    */   public MirroringBorder3D(ImageStack image) {
/* 40 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y, int z) {
/* 49 */     int width = this.image.getWidth();
/* 50 */     int height = this.image.getHeight();
/* 51 */     int depth = this.image.getSize();
/* 52 */     x %= 2 * width;
/* 53 */     y %= 2 * height;
/* 54 */     z %= 2 * depth;
/* 55 */     if (x < 0)
/* 56 */       x = -x - 1; 
/* 57 */     if (y < 0)
/* 58 */       y = -y - 1; 
/* 59 */     if (z < 0)
/* 60 */       z = -z - 1; 
/* 61 */     if (x >= width)
/* 62 */       x = 2 * width - 1 - x; 
/* 63 */     if (y >= height)
/* 64 */       y = 2 * height - 1 - y; 
/* 65 */     if (z >= depth)
/* 66 */       z = 2 * depth - 1 - y; 
/* 67 */     return (int)this.image.getVoxel(x, y, z);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/MirroringBorder3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */