/*     */ package inra.ijpb.data.image;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteStackWrapper
/*     */   implements Image3D
/*     */ {
/*     */   byte[][] slices;
/*     */   int sizeX;
/*     */   int sizeY;
/*     */   int sizeZ;
/*     */   
/*     */   public ByteStackWrapper(ImageStack stack) {
/*  56 */     if (stack.getBitDepth() != 8)
/*     */     {
/*  58 */       throw new IllegalArgumentException("Requires a 8-bits stack");
/*     */     }
/*     */ 
/*     */     
/*  62 */     this.sizeX = stack.getWidth();
/*  63 */     this.sizeY = stack.getHeight();
/*  64 */     this.sizeZ = stack.getSize();
/*     */ 
/*     */     
/*  67 */     this.slices = new byte[this.sizeZ][];
/*  68 */     Object[] array = stack.getImageArray();
/*  69 */     for (int i = 0; i < this.sizeZ; i++)
/*     */     {
/*  71 */       this.slices[i] = (byte[])array[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize(int dim) {
/*  78 */     switch (dim) {
/*     */       case 0:
/*  80 */         return this.sizeX;
/*  81 */       case 1: return this.sizeY;
/*  82 */       case 2: return this.sizeZ;
/*     */     } 
/*  84 */     throw new IllegalArgumentException("Dimension must be comprised between 0 and 2, not " + dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(int x, int y, int z) {
/*  94 */     return this.slices[z][y * this.sizeX + x] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int x, int y, int z, int value) {
/* 103 */     if (value > 255) {
/* 104 */       value = 255;
/* 105 */     } else if (value < 0) {
/* 106 */       value = 0;
/* 107 */     }  this.slices[z][y * this.sizeX + x] = (byte)value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(int x, int y, int z) {
/* 116 */     return (this.slices[z][y * this.sizeX + x] & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue(Cursor3D pos) {
/* 122 */     return getValue(pos.getX(), pos.getY(), pos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int x, int y, int z, double value) {
/* 131 */     if (value > 255.0D) {
/* 132 */       value = 255.0D;
/* 133 */     } else if (value < 0.0D) {
/* 134 */       value = 0.0D;
/* 135 */     }  this.slices[z][y * this.sizeX + x] = (byte)(int)(value + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Cursor3D pos, double value) {
/* 141 */     setValue(pos.getX(), pos.getY(), pos.getZ(), value);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/ByteStackWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */