/*    */ package inra.ijpb.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Neighborhood3DC26
/*    */   extends Neighborhood3D
/*    */ {
/* 28 */   ArrayList<Cursor3D> neighbors = new ArrayList<Cursor3D>();
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterable<Cursor3D> getNeighbors() {
/* 33 */     this.neighbors.clear();
/*    */     
/* 35 */     int x = this.cursor.getX();
/* 36 */     int y = this.cursor.getY();
/* 37 */     int z = this.cursor.getZ();
/*    */     
/* 39 */     this.neighbors.add(new Cursor3D(x - 1, y - 1, z - 1));
/* 40 */     this.neighbors.add(new Cursor3D(x - 1, y, z - 1));
/* 41 */     this.neighbors.add(new Cursor3D(x - 1, y + 1, z - 1));
/* 42 */     this.neighbors.add(new Cursor3D(x, y - 1, z - 1));
/* 43 */     this.neighbors.add(new Cursor3D(x, y, z - 1));
/* 44 */     this.neighbors.add(new Cursor3D(x, y + 1, z - 1));
/* 45 */     this.neighbors.add(new Cursor3D(x + 1, y - 1, z - 1));
/* 46 */     this.neighbors.add(new Cursor3D(x + 1, y, z - 1));
/* 47 */     this.neighbors.add(new Cursor3D(x + 1, y + 1, z - 1));
/*    */     
/* 49 */     this.neighbors.add(new Cursor3D(x - 1, y - 1, z));
/* 50 */     this.neighbors.add(new Cursor3D(x - 1, y, z));
/* 51 */     this.neighbors.add(new Cursor3D(x - 1, y + 1, z));
/* 52 */     this.neighbors.add(new Cursor3D(x, y - 1, z));
/* 53 */     this.neighbors.add(new Cursor3D(x, y + 1, z));
/* 54 */     this.neighbors.add(new Cursor3D(x + 1, y - 1, z));
/* 55 */     this.neighbors.add(new Cursor3D(x + 1, y, z));
/* 56 */     this.neighbors.add(new Cursor3D(x + 1, y + 1, z));
/*    */     
/* 58 */     this.neighbors.add(new Cursor3D(x - 1, y - 1, z + 1));
/* 59 */     this.neighbors.add(new Cursor3D(x - 1, y, z + 1));
/* 60 */     this.neighbors.add(new Cursor3D(x - 1, y + 1, z + 1));
/* 61 */     this.neighbors.add(new Cursor3D(x, y - 1, z + 1));
/* 62 */     this.neighbors.add(new Cursor3D(x, y, z + 1));
/* 63 */     this.neighbors.add(new Cursor3D(x, y + 1, z + 1));
/* 64 */     this.neighbors.add(new Cursor3D(x + 1, y - 1, z + 1));
/* 65 */     this.neighbors.add(new Cursor3D(x + 1, y, z + 1));
/* 66 */     this.neighbors.add(new Cursor3D(x + 1, y + 1, z + 1));
/*    */ 
/*    */     
/* 69 */     return this.neighbors;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Neighborhood3DC26.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */