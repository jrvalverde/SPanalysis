/*     */ package inra.ijpb.data.image;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ByteProcessor;
/*     */ import ij.process.ColorProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorImages
/*     */ {
/*     */   public static final void print(ColorProcessor image) {
/*  60 */     for (int y = 0; y < image.getHeight(); y++) {
/*     */       
/*  62 */       for (int x = 0; x < image.getWidth(); x++) {
/*     */         
/*  64 */         int intCode = image.get(x, y);
/*  65 */         int r = (intCode & 0xFF0000) >> 16;
/*  66 */         int g = (intCode & 0xFF00) >> 8;
/*  67 */         int b = intCode & 0xFF;
/*  68 */         System.out.print(String.format("(%3d,%3d,%3d) ", new Object[] { Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b) }));
/*     */       } 
/*  70 */       System.out.println("");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Collection<ByteProcessor> splitChannels(ImageProcessor image) {
/*  84 */     if (!(image instanceof ColorProcessor))
/*     */     {
/*  86 */       throw new IllegalArgumentException("Requires an instance of ColorProcessor");
/*     */     }
/*     */ 
/*     */     
/*  90 */     int width = image.getWidth();
/*  91 */     int height = image.getHeight();
/*  92 */     int size = width * height;
/*     */ 
/*     */     
/*  95 */     byte[] redArray = new byte[size];
/*  96 */     byte[] greenArray = new byte[size];
/*  97 */     byte[] blueArray = new byte[size];
/*  98 */     ((ColorProcessor)image).getRGB(redArray, greenArray, blueArray);
/*     */ 
/*     */     
/* 101 */     ByteProcessor red = new ByteProcessor(width, height, redArray, null);
/* 102 */     ByteProcessor green = new ByteProcessor(width, height, greenArray, null);
/* 103 */     ByteProcessor blue = new ByteProcessor(width, height, blueArray, null);
/*     */ 
/*     */     
/* 106 */     ArrayList<ByteProcessor> result = new ArrayList<ByteProcessor>(3);
/* 107 */     result.add(red);
/* 108 */     result.add(green);
/* 109 */     result.add(blue);
/*     */     
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Collection<ImageStack> splitChannels(ImageStack image) {
/* 124 */     if (!(image.getProcessor(1) instanceof ColorProcessor))
/*     */     {
/* 126 */       throw new IllegalArgumentException("Requires a Stack containing instances of ColorProcessor");
/*     */     }
/*     */ 
/*     */     
/* 130 */     int width = image.getWidth();
/* 131 */     int height = image.getHeight();
/* 132 */     int depth = image.getSize();
/*     */ 
/*     */     
/* 135 */     ImageStack redStack = ImageStack.create(width, height, depth, 8);
/* 136 */     ImageStack greenStack = ImageStack.create(width, height, depth, 8);
/* 137 */     ImageStack blueStack = ImageStack.create(width, height, depth, 8);
/*     */     
/* 139 */     for (int z = 1; z <= depth; z++) {
/*     */ 
/*     */       
/* 142 */       ColorProcessor rgb = (ColorProcessor)image.getProcessor(z);
/*     */ 
/*     */       
/* 145 */       ByteProcessor red = (ByteProcessor)redStack.getProcessor(z);
/* 146 */       ByteProcessor green = (ByteProcessor)greenStack.getProcessor(z);
/* 147 */       ByteProcessor blue = (ByteProcessor)blueStack.getProcessor(z);
/*     */ 
/*     */       
/* 150 */       for (int y = 0; y < height; y++) {
/*     */         
/* 152 */         for (int x = 0; x < width; x++) {
/*     */           
/* 154 */           int intCode = rgb.get(x, y);
/* 155 */           red.set(x, y, intCode >> 16 & 0xFF);
/* 156 */           green.set(x, y, intCode >> 8 & 0xFF);
/* 157 */           blue.set(x, y, intCode & 0xFF);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 162 */       redStack.setProcessor((ImageProcessor)red, z);
/* 163 */       greenStack.setProcessor((ImageProcessor)green, z);
/* 164 */       blueStack.setProcessor((ImageProcessor)blue, z);
/*     */     } 
/*     */ 
/*     */     
/* 168 */     ArrayList<ImageStack> result = new ArrayList<ImageStack>(3);
/* 169 */     result.add(redStack);
/* 170 */     result.add(greenStack);
/* 171 */     result.add(blueStack);
/*     */     
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final HashMap<String, ByteProcessor> mapChannels(ImageProcessor image) {
/* 192 */     if (!(image instanceof ColorProcessor))
/*     */     {
/* 194 */       throw new IllegalArgumentException("Requires an instance of ColorProcessor");
/*     */     }
/*     */ 
/*     */     
/* 198 */     int width = image.getWidth();
/* 199 */     int height = image.getHeight();
/* 200 */     int size = width * height;
/*     */ 
/*     */     
/* 203 */     byte[] redArray = new byte[size];
/* 204 */     byte[] greenArray = new byte[size];
/* 205 */     byte[] blueArray = new byte[size];
/* 206 */     ((ColorProcessor)image).getRGB(redArray, greenArray, blueArray);
/*     */ 
/*     */     
/* 209 */     ByteProcessor red = new ByteProcessor(width, height, redArray, null);
/* 210 */     ByteProcessor green = new ByteProcessor(width, height, greenArray, null);
/* 211 */     ByteProcessor blue = new ByteProcessor(width, height, blueArray, null);
/*     */ 
/*     */     
/* 214 */     HashMap<String, ByteProcessor> map = new HashMap<String, ByteProcessor>(3);
/* 215 */     map.put("red", red);
/* 216 */     map.put("green", green);
/* 217 */     map.put("blue", blue);
/*     */     
/* 219 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final HashMap<String, ImageStack> mapChannels(ImageStack image) {
/* 232 */     if (!(image.getProcessor(1) instanceof ColorProcessor))
/*     */     {
/* 234 */       throw new IllegalArgumentException("Requires a Stack containing instances of ColorProcessor");
/*     */     }
/*     */ 
/*     */     
/* 238 */     int width = image.getWidth();
/* 239 */     int height = image.getHeight();
/* 240 */     int depth = image.getSize();
/*     */ 
/*     */     
/* 243 */     ImageStack redStack = ImageStack.create(width, height, depth, 8);
/* 244 */     ImageStack greenStack = ImageStack.create(width, height, depth, 8);
/* 245 */     ImageStack blueStack = ImageStack.create(width, height, depth, 8);
/*     */     
/* 247 */     for (int z = 1; z <= depth; z++) {
/*     */ 
/*     */       
/* 250 */       ColorProcessor rgb = (ColorProcessor)image.getProcessor(z);
/*     */ 
/*     */       
/* 253 */       ByteProcessor red = (ByteProcessor)redStack.getProcessor(z);
/* 254 */       ByteProcessor green = (ByteProcessor)greenStack.getProcessor(z);
/* 255 */       ByteProcessor blue = (ByteProcessor)blueStack.getProcessor(z);
/*     */ 
/*     */       
/* 258 */       for (int y = 0; y < height; y++) {
/*     */         
/* 260 */         for (int x = 0; x < width; x++) {
/*     */           
/* 262 */           int intCode = rgb.get(x, y);
/* 263 */           red.set(x, y, intCode >> 16 & 0xFF);
/* 264 */           green.set(x, y, intCode >> 8 & 0xFF);
/* 265 */           blue.set(x, y, intCode & 0xFF);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 270 */       redStack.setProcessor((ImageProcessor)red, z);
/* 271 */       greenStack.setProcessor((ImageProcessor)green, z);
/* 272 */       blueStack.setProcessor((ImageProcessor)blue, z);
/*     */     } 
/*     */ 
/*     */     
/* 276 */     HashMap<String, ImageStack> map = new HashMap<String, ImageStack>(3);
/* 277 */     map.put("red", redStack);
/* 278 */     map.put("green", greenStack);
/* 279 */     map.put("blue", blueStack);
/*     */     
/* 281 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ColorProcessor mergeChannels(Collection<ImageProcessor> channels) {
/* 297 */     if (channels.size() < 3) {
/* 298 */       throw new IllegalArgumentException("Requires at least three channels in the collection");
/*     */     }
/*     */     
/* 301 */     Iterator<ImageProcessor> iterator = channels.iterator();
/* 302 */     ImageProcessor red = iterator.next();
/* 303 */     ImageProcessor green = iterator.next();
/* 304 */     ImageProcessor blue = iterator.next();
/*     */ 
/*     */     
/* 307 */     return mergeChannels(red, green, blue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ColorProcessor mergeChannels(ImageProcessor red, ImageProcessor green, ImageProcessor blue) {
/* 329 */     if (!(red instanceof ByteProcessor))
/* 330 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor"); 
/* 331 */     if (!(green instanceof ByteProcessor))
/* 332 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor"); 
/* 333 */     if (!(blue instanceof ByteProcessor)) {
/* 334 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor");
/*     */     }
/*     */     
/* 337 */     byte[] redArray = (byte[])red.getPixels();
/* 338 */     byte[] greenArray = (byte[])green.getPixels();
/* 339 */     byte[] blueArray = (byte[])blue.getPixels();
/*     */ 
/*     */     
/* 342 */     int width = red.getWidth();
/* 343 */     int height = red.getHeight();
/*     */ 
/*     */     
/* 346 */     ColorProcessor result = new ColorProcessor(width, height);
/* 347 */     result.setRGB(redArray, greenArray, blueArray);
/*     */     
/* 349 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack mergeChannels(ImageStack red, ImageStack green, ImageStack blue) {
/* 371 */     if (!(red.getProcessor(1) instanceof ByteProcessor))
/* 372 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor"); 
/* 373 */     if (!(green.getProcessor(1) instanceof ByteProcessor))
/* 374 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor"); 
/* 375 */     if (!(blue.getProcessor(1) instanceof ByteProcessor)) {
/* 376 */       throw new IllegalArgumentException("Input channels must be instances of ByteProcessor");
/*     */     }
/* 378 */     int width = red.getWidth();
/* 379 */     int height = red.getHeight();
/* 380 */     int depth = red.getSize();
/* 381 */     ImageStack result = ImageStack.create(width, height, depth, 24);
/*     */     
/* 383 */     for (int z = 1; z <= depth; z++) {
/*     */ 
/*     */       
/* 386 */       ByteProcessor redSlice = (ByteProcessor)red.getProcessor(z);
/* 387 */       ByteProcessor greenSlice = (ByteProcessor)green.getProcessor(z);
/* 388 */       ByteProcessor blueSlice = (ByteProcessor)blue.getProcessor(z);
/* 389 */       ColorProcessor rgbSlice = (ColorProcessor)result.getProcessor(z);
/*     */       
/* 391 */       for (int y = 0; y < height; y++) {
/*     */         
/* 393 */         for (int x = 0; x < width; x++) {
/*     */           
/* 395 */           int r = redSlice.get(x, y);
/* 396 */           int g = greenSlice.get(x, y);
/* 397 */           int b = blueSlice.get(x, y);
/* 398 */           int rgbCode = r << 16 | g << 8 | b;
/* 399 */           rgbSlice.set(x, y, rgbCode);
/*     */         } 
/*     */       } 
/*     */       
/* 403 */       result.setProcessor((ImageProcessor)rgbSlice, z);
/*     */     } 
/*     */     
/* 406 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus binaryOverlay(ImagePlus imagePlus, ImagePlus maskPlus, Color color) {
/*     */     ImagePlus resultPlus;
/* 424 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-ovr";
/*     */ 
/*     */     
/* 427 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/* 429 */       ImageProcessor image = imagePlus.getProcessor();
/* 430 */       ImageProcessor mask = maskPlus.getProcessor();
/* 431 */       ImageProcessor result = binaryOverlay(image, mask, color);
/* 432 */       resultPlus = new ImagePlus(newName, result);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 437 */       ImageStack image = imagePlus.getStack();
/*     */ 
/*     */       
/* 440 */       if (imagePlus.getBitDepth() != 24) {
/*     */         
/* 442 */         double grayMin = imagePlus.getDisplayRangeMin();
/* 443 */         double grayMax = imagePlus.getDisplayRangeMax();
/* 444 */         image = Images3D.adjustDynamic(image, grayMin, grayMax);
/*     */       } 
/*     */ 
/*     */       
/* 448 */       ImageStack mask = maskPlus.getStack();
/*     */ 
/*     */       
/* 451 */       ImageStack result = binaryOverlay(image, mask, color);
/* 452 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */ 
/*     */     
/* 456 */     resultPlus.copyScale(imagePlus);
/* 457 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor binaryOverlay(ImageProcessor refImage, ImageProcessor mask, Color color) {
/*     */     ByteProcessor byteProcessor;
/* 475 */     if (refImage instanceof ColorProcessor)
/*     */     {
/* 477 */       return binaryOverlayRGB(refImage, mask, color);
/*     */     }
/*     */ 
/*     */     
/* 481 */     if (!(refImage instanceof ByteProcessor))
/*     */     {
/* 483 */       byteProcessor = refImage.convertToByteProcessor();
/*     */     }
/* 485 */     return binaryOverlayGray8((ImageProcessor)byteProcessor, mask, color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageProcessor binaryOverlayGray8(ImageProcessor refImage, ImageProcessor mask, Color color) {
/* 495 */     int width = refImage.getWidth();
/* 496 */     int height = refImage.getHeight();
/* 497 */     ColorProcessor result = new ColorProcessor(width, height);
/*     */ 
/*     */     
/* 500 */     int rgbValue = color.getRGB();
/*     */ 
/*     */     
/* 503 */     for (int y = 0; y < height; y++) {
/* 504 */       for (int x = 0; x < width; x++) {
/* 505 */         if (mask.get(x, y) == 0) {
/*     */           
/* 507 */           int value = refImage.get(x, y);
/*     */           
/* 509 */           value = (value & 0xFF) << 16 | (value & 0xFF) << 8 | value & 0xFF;
/* 510 */           result.set(x, y, value);
/*     */         }
/*     */         else {
/*     */           
/* 514 */           result.set(x, y, rgbValue);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 519 */     return (ImageProcessor)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageProcessor binaryOverlayRGB(ImageProcessor refImage, ImageProcessor mask, Color color) {
/* 529 */     int width = refImage.getWidth();
/* 530 */     int height = refImage.getHeight();
/* 531 */     ColorProcessor result = new ColorProcessor(width, height);
/*     */ 
/*     */     
/* 534 */     int rgbValue = color.getRGB();
/*     */ 
/*     */     
/* 537 */     for (int y = 0; y < height; y++) {
/* 538 */       for (int x = 0; x < width; x++) {
/* 539 */         if (mask.get(x, y) == 0) {
/*     */           
/* 541 */           int value = refImage.get(x, y);
/* 542 */           result.set(x, y, value);
/*     */         }
/*     */         else {
/*     */           
/* 546 */           result.set(x, y, rgbValue);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 551 */     return (ImageProcessor)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack binaryOverlay(ImageStack refImage, ImageStack mask, Color color) {
/* 569 */     int sizeX = refImage.getWidth();
/* 570 */     int sizeY = refImage.getHeight();
/* 571 */     int sizeZ = refImage.getSize();
/*     */     
/* 573 */     int bitDepth = refImage.getBitDepth();
/*     */     
/* 575 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, 24);
/*     */ 
/*     */     
/* 578 */     int rgbValue = color.getRGB();
/*     */ 
/*     */     
/* 581 */     double vmin = Double.MAX_VALUE, vmax = Double.MIN_VALUE;
/* 582 */     if (bitDepth == 16 || bitDepth == 32)
/*     */     {
/* 584 */       for (int i = 0; i < sizeZ; i++) {
/* 585 */         for (int y = 0; y < sizeY; y++) {
/* 586 */           for (int x = 0; x < sizeX; x++) {
/* 587 */             double value = refImage.getVoxel(x, y, i);
/* 588 */             vmin = Math.min(vmin, value);
/* 589 */             vmax = Math.max(vmax, value);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 596 */     for (int z = 0; z < sizeZ; z++) {
/* 597 */       for (int y = 0; y < sizeY; y++) {
/* 598 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 600 */           if (mask.getVoxel(x, y, z) > 0.0D) {
/* 601 */             result.setVoxel(x, y, z, rgbValue);
/*     */           } else {
/*     */             int intVal;
/*     */             double value;
/* 605 */             switch (bitDepth) {
/*     */               
/*     */               case 8:
/* 608 */                 intVal = (int)refImage.getVoxel(x, y, z);
/* 609 */                 intVal = (intVal & 0xFF) << 16 | (intVal & 0xFF) << 8 | 
/* 610 */                   intVal & 0xFF;
/* 611 */                 result.setVoxel(x, y, z, intVal);
/*     */                 break;
/*     */ 
/*     */               
/*     */               case 16:
/*     */               case 32:
/* 617 */                 value = refImage.getVoxel(x, y, z);
/* 618 */                 intVal = (int)(255.0D * (value - vmin) / (vmax - vmin));
/* 619 */                 intVal = (intVal & 0xFF) << 16 | (intVal & 0xFF) << 8 | 
/* 620 */                   intVal & 0xFF;
/* 621 */                 result.setVoxel(x, y, z, intVal);
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               case 24:
/* 627 */                 result.setVoxel(x, y, z, refImage.getVoxel(x, y, z));
/*     */                 break;
/*     */             } 
/*     */ 
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 636 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/ColorImages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */