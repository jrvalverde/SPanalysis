package inra.ijpb.data.image;

import inra.ijpb.data.Cursor3D;

public interface Image3D {
  int getSize(int paramInt);
  
  int get(int paramInt1, int paramInt2, int paramInt3);
  
  void set(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  double getValue(int paramInt1, int paramInt2, int paramInt3);
  
  double getValue(Cursor3D paramCursor3D);
  
  void setValue(int paramInt1, int paramInt2, int paramInt3, double paramDouble);
  
  void setValue(Cursor3D paramCursor3D, double paramDouble);
}


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/image/Image3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */