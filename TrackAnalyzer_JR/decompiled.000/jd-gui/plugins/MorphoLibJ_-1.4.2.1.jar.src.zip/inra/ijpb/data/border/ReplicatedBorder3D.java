/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicatedBorder3D
/*    */   implements BorderManager3D
/*    */ {
/*    */   ImageStack image;
/*    */   
/*    */   public ReplicatedBorder3D(ImageStack image) {
/* 40 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y, int z) {
/* 52 */     if (x < 0)
/* 53 */       x = 0; 
/* 54 */     if (y < 0)
/* 55 */       y = 0; 
/* 56 */     if (z < 0)
/* 57 */       z = 0; 
/* 58 */     x = Math.min(x, this.image.getWidth() - 1);
/* 59 */     y = Math.min(y, this.image.getHeight() - 1);
/* 60 */     z = Math.min(z, this.image.getSize() - 1);
/* 61 */     return (int)this.image.getVoxel(x, y, z);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/ReplicatedBorder3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */