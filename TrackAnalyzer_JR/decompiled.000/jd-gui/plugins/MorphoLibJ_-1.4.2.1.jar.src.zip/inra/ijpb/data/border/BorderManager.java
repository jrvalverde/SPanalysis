/*     */ package inra.ijpb.data.border;
/*     */ 
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BorderManager
/*     */ {
/*     */   int get(int paramInt1, int paramInt2);
/*     */   
/*     */   float getf(int paramInt1, int paramInt2);
/*     */   
/*     */   public enum Type
/*     */   {
/*  64 */     REPLICATED("Replicate"),
/*  65 */     PERIODIC("Periodic"),
/*  66 */     MIRRORED("Mirrored"),
/*  67 */     BLACK("Black"),
/*  68 */     WHITE("White"),
/*  69 */     GRAY("Gray"); String label;
/*     */     
/*     */     Type(String label) {
/*  72 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  78 */       return this.label;
/*     */     }
/*     */     
/*     */     public String getLabel() {
/*  82 */       return this.label;
/*     */     }
/*     */     
/*     */     public BorderManager createBorderManager(ImageProcessor image) {
/*  86 */       switch (this) {
/*     */         case REPLICATED:
/*  88 */           return new ReplicatedBorder(image);
/*     */         case PERIODIC:
/*  90 */           return new PeriodicBorder(image);
/*     */         case MIRRORED:
/*  92 */           return new MirroringBorder(image);
/*     */         case null:
/*  94 */           return new ConstantBorder(image, 0.0F);
/*     */         case WHITE:
/*  96 */           return new ConstantBorder(image, 1.6777215E7F);
/*     */         case GRAY:
/*  98 */           if (image instanceof ij.process.ColorProcessor)
/*  99 */             return new ConstantBorder(image, 8355711.0F); 
/* 100 */           if (image instanceof ij.process.ShortProcessor)
/* 101 */             return new ConstantBorder(image, 32767.0F); 
/* 102 */           return new ConstantBorder(image, 127.0F);
/*     */       } 
/* 104 */       throw new RuntimeException("Unknown border manager for type " + this);
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 109 */       int n = (values()).length;
/* 110 */       String[] result = new String[n];
/*     */       
/* 112 */       int i = 0; byte b; int j; Type[] arrayOfType;
/* 113 */       for (j = (arrayOfType = values()).length, b = 0; b < j; ) { Type value = arrayOfType[b];
/* 114 */         result[i++] = value.label; b++; }
/*     */       
/* 116 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type fromLabel(String label) {
/* 129 */       if (label != null)
/* 130 */         label = label.toLowerCase();  byte b; int i; Type[] arrayOfType;
/* 131 */       for (i = (arrayOfType = values()).length, b = 0; b < i; ) { Type value = arrayOfType[b];
/* 132 */         String cmp = value.label.toLowerCase();
/* 133 */         if (cmp.equals(label))
/* 134 */           return value;  b++; }
/*     */       
/* 136 */       throw new IllegalArgumentException("Unable to parse Value with label: " + label);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/BorderManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */