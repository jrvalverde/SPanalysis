/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.process.ImageProcessor;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MirroringBorder
/*    */   implements BorderManager
/*    */ {
/*    */   ImageProcessor image;
/*    */   
/*    */   public MirroringBorder(ImageProcessor image) {
/* 40 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y) {
/* 49 */     Point p = computeCoords(x, y);
/* 50 */     return this.image.get(p.x, p.y);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public float getf(int x, int y) {
/* 56 */     Point p = computeCoords(x, y);
/* 57 */     return this.image.getf(p.x, p.y);
/*    */   }
/*    */ 
/*    */   
/*    */   private Point computeCoords(int x, int y) {
/* 62 */     int width = this.image.getWidth();
/* 63 */     int height = this.image.getHeight();
/* 64 */     x %= 2 * width;
/* 65 */     y %= 2 * height;
/* 66 */     if (x < 0)
/* 67 */       x = -x - 1; 
/* 68 */     if (y < 0)
/* 69 */       y = -y - 1; 
/* 70 */     if (x >= width)
/* 71 */       x = 2 * width - 1 - x; 
/* 72 */     if (y >= height)
/* 73 */       y = 2 * height - 1 - y; 
/* 74 */     return new Point(x, y);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/MirroringBorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */