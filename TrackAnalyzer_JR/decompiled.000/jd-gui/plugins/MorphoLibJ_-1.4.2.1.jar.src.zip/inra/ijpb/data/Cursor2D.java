/*    */ package inra.ijpb.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cursor2D
/*    */ {
/* 25 */   private int x = 0;
/* 26 */   private int y = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Cursor2D(int x, int y) {
/* 32 */     this.x = x;
/* 33 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(int x, int y) {
/* 40 */     this.x = x;
/* 41 */     this.y = y;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getX() {
/* 46 */     return this.x;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getY() {
/* 51 */     return this.y;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object other) {
/* 57 */     if (other == null) return false; 
/* 58 */     if (other == this) return true; 
/* 59 */     if (!(other instanceof Cursor2D))
/* 60 */       return false; 
/* 61 */     Cursor2D c = (Cursor2D)other;
/* 62 */     return (c.x == this.x && c.y == this.y);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Cursor2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */