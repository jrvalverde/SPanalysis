/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.ImageStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantBorder3D
/*    */   implements BorderManager3D
/*    */ {
/*    */   ImageStack image;
/*    */   int value;
/*    */   
/*    */   public ConstantBorder3D(ImageStack image, int value) {
/* 41 */     this.image = image;
/* 42 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y, int z) {
/* 54 */     if (x < 0)
/* 55 */       return this.value; 
/* 56 */     if (y < 0)
/* 57 */       return this.value; 
/* 58 */     if (z < 0)
/* 59 */       return this.value; 
/* 60 */     if (x >= this.image.getWidth())
/* 61 */       return this.value; 
/* 62 */     if (y >= this.image.getHeight())
/* 63 */       return this.value; 
/* 64 */     if (z >= this.image.getSize())
/* 65 */       return this.value; 
/* 66 */     return (int)this.image.getVoxel(x, y, z);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/ConstantBorder3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */