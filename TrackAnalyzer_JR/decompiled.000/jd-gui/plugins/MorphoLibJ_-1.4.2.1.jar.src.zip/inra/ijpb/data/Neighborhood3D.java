/*    */ package inra.ijpb.data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Neighborhood3D
/*    */ {
/*    */   Cursor3D cursor;
/*    */   
/*    */   public abstract Iterable<Cursor3D> getNeighbors();
/*    */   
/*    */   public void setCursor(Cursor3D cursor) {
/* 32 */     this.cursor = cursor;
/*    */   }
/*    */ 
/*    */   
/*    */   public Cursor3D getCursor() {
/* 37 */     return this.cursor;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Neighborhood3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */