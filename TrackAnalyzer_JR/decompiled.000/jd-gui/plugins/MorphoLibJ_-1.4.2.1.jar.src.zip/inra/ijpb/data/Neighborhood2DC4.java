/*    */ package inra.ijpb.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Neighborhood2DC4
/*    */   extends Neighborhood2D
/*    */ {
/* 28 */   ArrayList<Cursor2D> neighbors = new ArrayList<Cursor2D>();
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterable<Cursor2D> getNeighbors() {
/* 33 */     this.neighbors.clear();
/*    */     
/* 35 */     int x = this.cursor.getX();
/* 36 */     int y = this.cursor.getY();
/*    */     
/* 38 */     this.neighbors.add(new Cursor2D(x - 1, y));
/* 39 */     this.neighbors.add(new Cursor2D(x, y - 1));
/* 40 */     this.neighbors.add(new Cursor2D(x + 1, y));
/* 41 */     this.neighbors.add(new Cursor2D(x, y + 1));
/*    */     
/* 43 */     return this.neighbors;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Neighborhood2DC4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */