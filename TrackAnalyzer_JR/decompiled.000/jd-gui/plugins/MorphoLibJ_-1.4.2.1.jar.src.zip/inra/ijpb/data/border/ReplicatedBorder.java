/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.process.ImageProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicatedBorder
/*    */   implements BorderManager
/*    */ {
/*    */   ImageProcessor image;
/*    */   
/*    */   public ReplicatedBorder(ImageProcessor image) {
/* 39 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y) {
/* 51 */     if (x < 0)
/* 52 */       x = 0; 
/* 53 */     if (y < 0)
/* 54 */       y = 0; 
/* 55 */     x = Math.min(x, this.image.getWidth() - 1);
/* 56 */     y = Math.min(y, this.image.getHeight() - 1);
/* 57 */     return this.image.get(x, y);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getf(int x, int y) {
/* 69 */     if (x < 0)
/* 70 */       x = 0; 
/* 71 */     if (y < 0)
/* 72 */       y = 0; 
/* 73 */     x = Math.min(x, this.image.getWidth() - 1);
/* 74 */     y = Math.min(y, this.image.getHeight() - 1);
/* 75 */     return this.image.getf(x, y);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/ReplicatedBorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */