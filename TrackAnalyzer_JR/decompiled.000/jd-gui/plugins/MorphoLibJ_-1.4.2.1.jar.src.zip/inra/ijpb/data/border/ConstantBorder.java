/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.process.ImageProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantBorder
/*    */   implements BorderManager
/*    */ {
/*    */   ImageProcessor image;
/*    */   float value;
/*    */   
/*    */   public ConstantBorder(ImageProcessor image, float value) {
/* 40 */     this.image = image;
/* 41 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y) {
/* 53 */     if (x < 0)
/* 54 */       return (int)this.value; 
/* 55 */     if (y < 0)
/* 56 */       return (int)this.value; 
/* 57 */     if (x >= this.image.getWidth())
/* 58 */       return (int)this.value; 
/* 59 */     if (y >= this.image.getHeight())
/* 60 */       return (int)this.value; 
/* 61 */     return this.image.get(x, y);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getf(int x, int y) {
/* 73 */     if (x < 0)
/* 74 */       return this.value; 
/* 75 */     if (y < 0)
/* 76 */       return this.value; 
/* 77 */     if (x >= this.image.getWidth())
/* 78 */       return this.value; 
/* 79 */     if (y >= this.image.getHeight())
/* 80 */       return this.value; 
/* 81 */     return this.image.getf(x, y);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/ConstantBorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */