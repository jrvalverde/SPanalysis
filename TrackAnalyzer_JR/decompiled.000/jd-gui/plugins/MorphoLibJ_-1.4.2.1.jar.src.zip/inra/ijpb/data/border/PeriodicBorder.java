/*    */ package inra.ijpb.data.border;
/*    */ 
/*    */ import ij.process.ImageProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PeriodicBorder
/*    */   implements BorderManager
/*    */ {
/*    */   ImageProcessor image;
/*    */   
/*    */   public PeriodicBorder(ImageProcessor image) {
/* 38 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int get(int x, int y) {
/* 46 */     x %= this.image.getWidth();
/* 47 */     y %= this.image.getHeight();
/* 48 */     if (x < 0)
/* 49 */       x += this.image.getWidth(); 
/* 50 */     if (y < 0)
/* 51 */       y += this.image.getHeight(); 
/* 52 */     return this.image.get(x, y);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public float getf(int x, int y) {
/* 60 */     x %= this.image.getWidth();
/* 61 */     y %= this.image.getHeight();
/* 62 */     if (x < 0)
/* 63 */       x += this.image.getWidth(); 
/* 64 */     if (y < 0)
/* 65 */       y += this.image.getHeight(); 
/* 66 */     return this.image.getf(x, y);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/PeriodicBorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */