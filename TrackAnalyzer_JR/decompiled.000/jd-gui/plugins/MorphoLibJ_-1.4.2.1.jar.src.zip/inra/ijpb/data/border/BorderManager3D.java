/*     */ package inra.ijpb.data.border;
/*     */ 
/*     */ import ij.ImageStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BorderManager3D
/*     */ {
/*     */   int get(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   public enum Type
/*     */   {
/*  63 */     REPLICATED("Replicate"), PERIODIC("Periodic"), MIRRORED("Mirrored"), BLACK(
/*  64 */       "Black"), WHITE("White"), GRAY("Gray");
/*     */     String label;
/*     */     
/*     */     Type(String label) {
/*  68 */       this.label = label;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  75 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLabel() {
/*  80 */       return this.label;
/*     */     }
/*     */ 
/*     */     
/*     */     public BorderManager3D createBorderManager(ImageStack image) {
/*  85 */       switch (this) {
/*     */         
/*     */         case REPLICATED:
/*  88 */           return new ReplicatedBorder3D(image);
/*     */         case PERIODIC:
/*  90 */           return new PeriodicBorder3D(image);
/*     */         case MIRRORED:
/*  92 */           return new MirroringBorder3D(image);
/*     */         case null:
/*  94 */           return new ConstantBorder3D(image, 0);
/*     */         case WHITE:
/*  96 */           return new ConstantBorder3D(image, 16777215);
/*     */         case GRAY:
/*  98 */           if (image.getBitDepth() == 24)
/*  99 */             return new ConstantBorder3D(image, 8355711); 
/* 100 */           if (image.getBitDepth() == 16)
/* 101 */             return new ConstantBorder3D(image, 32767); 
/* 102 */           return new ConstantBorder3D(image, 127);
/*     */       } 
/* 104 */       throw new RuntimeException("Unknown border manager for type " + this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 110 */       int n = (values()).length;
/* 111 */       String[] result = new String[n];
/*     */       
/* 113 */       int i = 0; byte b; int j; Type[] arrayOfType;
/* 114 */       for (j = (arrayOfType = values()).length, b = 0; b < j; ) { Type value = arrayOfType[b];
/* 115 */         result[i++] = value.label; b++; }
/*     */       
/* 117 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type fromLabel(String label) {
/* 131 */       if (label != null)
/* 132 */         label = label.toLowerCase();  byte b; int i; Type[] arrayOfType;
/* 133 */       for (i = (arrayOfType = values()).length, b = 0; b < i; ) { Type value = arrayOfType[b];
/*     */         
/* 135 */         String cmp = value.label.toLowerCase();
/* 136 */         if (cmp.equals(label))
/* 137 */           return value;  b++; }
/*     */       
/* 139 */       throw new IllegalArgumentException(
/* 140 */           "Unable to parse Value with label: " + label);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/border/BorderManager3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */