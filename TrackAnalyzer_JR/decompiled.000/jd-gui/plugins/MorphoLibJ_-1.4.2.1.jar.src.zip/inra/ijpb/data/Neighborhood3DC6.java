/*    */ package inra.ijpb.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Neighborhood3DC6
/*    */   extends Neighborhood3D
/*    */ {
/* 28 */   ArrayList<Cursor3D> neighbors = new ArrayList<Cursor3D>();
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterable<Cursor3D> getNeighbors() {
/* 33 */     this.neighbors.clear();
/*    */     
/* 35 */     int x = this.cursor.getX();
/* 36 */     int y = this.cursor.getY();
/* 37 */     int z = this.cursor.getZ();
/*    */ 
/*    */     
/* 40 */     this.neighbors.add(new Cursor3D(x, y, z - 1));
/*    */     
/* 42 */     this.neighbors.add(new Cursor3D(x - 1, y, z));
/* 43 */     this.neighbors.add(new Cursor3D(x, y - 1, z));
/* 44 */     this.neighbors.add(new Cursor3D(x, y + 1, z));
/* 45 */     this.neighbors.add(new Cursor3D(x + 1, y, z));
/*    */     
/* 47 */     this.neighbors.add(new Cursor3D(x, y, z + 1));
/*    */     
/* 49 */     return this.neighbors;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/data/Neighborhood3DC6.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */