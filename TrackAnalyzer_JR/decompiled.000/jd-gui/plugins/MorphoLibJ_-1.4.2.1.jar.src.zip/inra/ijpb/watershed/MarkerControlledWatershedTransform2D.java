/*      */ package inra.ijpb.watershed;
/*      */ 
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.process.FloatProcessor;
/*      */ import ij.process.ImageProcessor;
/*      */ import inra.ijpb.data.Cursor2D;
/*      */ import inra.ijpb.data.Neighborhood2D;
/*      */ import inra.ijpb.data.Neighborhood2DC4;
/*      */ import inra.ijpb.data.Neighborhood2DC8;
/*      */ import inra.ijpb.data.PixelRecord;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.PriorityQueue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MarkerControlledWatershedTransform2D
/*      */   extends WatershedTransform2D
/*      */ {
/*   53 */   ImageProcessor markerImage = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerControlledWatershedTransform2D(ImageProcessor input, ImageProcessor marker, ImageProcessor mask) {
/*   67 */     super(input, mask);
/*   68 */     this.markerImage = marker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerControlledWatershedTransform2D(ImageProcessor input, ImageProcessor marker, ImageProcessor mask, int connectivity) {
/*   85 */     super(input, mask, connectivity);
/*   86 */     this.markerImage = marker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImageProcessor applyWithSortedList() {
/*  104 */     int size1 = this.inputImage.getWidth();
/*  105 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  107 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/*  109 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  113 */     if (this.connectivity != 4 && this.connectivity != 8) {
/*  114 */       throw new RuntimeException(
/*  115 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  116 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  120 */     LinkedList<PixelRecord> pixelList = null;
/*      */     
/*  122 */     int[][] tabLabels = new int[size1][size2];
/*      */ 
/*      */     
/*  125 */     IJ.showStatus("Extracting pixel values...");
/*  126 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  127 */     long t0 = System.currentTimeMillis();
/*      */     
/*  129 */     pixelList = extractPixelValues(this.inputImage, this.markerImage, tabLabels);
/*  130 */     if (pixelList == null) {
/*  131 */       return null;
/*      */     }
/*  133 */     long t1 = System.currentTimeMillis();
/*  134 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  135 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/*  136 */     IJ.showStatus("Sorting pixels by value...");
/*  137 */     Collections.sort(pixelList);
/*  138 */     long t2 = System.currentTimeMillis();
/*  139 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  142 */     boolean found = false;
/*      */     
/*  144 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  147 */     Cursor2D cursor = new Cursor2D(0, 0);
/*      */ 
/*      */     
/*  150 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  151 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/*  153 */     boolean change = true;
/*  154 */     while (!pixelList.isEmpty() && change) {
/*      */       
/*  156 */       if (Thread.currentThread().isInterrupted()) {
/*  157 */         return null;
/*      */       }
/*  159 */       change = false;
/*  160 */       int count = pixelList.size();
/*  161 */       IJ.log("  Flooding " + count + " pixels...");
/*  162 */       IJ.showStatus("Flooding " + count + " pixels...");
/*      */       
/*  164 */       for (int p = 0; p < count; p++) {
/*      */         
/*  166 */         IJ.showProgress(p, count);
/*  167 */         PixelRecord pixelRecord = pixelList.removeFirst();
/*  168 */         Cursor2D p2 = pixelRecord.getCursor();
/*  169 */         int i = p2.getX();
/*  170 */         int j = p2.getY();
/*      */ 
/*      */         
/*  173 */         if (tabLabels[i][j] == 0) {
/*      */           
/*  175 */           found = false;
/*  176 */           double pixelValue = pixelRecord.getValue();
/*      */ 
/*      */           
/*  179 */           cursor.set(i, j);
/*  180 */           neigh.setCursor(cursor);
/*      */           
/*  182 */           for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */             
/*  186 */             int u = c.getX();
/*  187 */             int v = c.getY();
/*      */             
/*  189 */             if (u >= 0 && u < size1 && v >= 0 && v < size2)
/*      */             {
/*  191 */               if (tabLabels[u][v] != 0 && this.inputImage.getf(u, v) <= pixelValue) {
/*      */                 
/*  193 */                 tabLabels[i][j] = tabLabels[u][v];
/*  194 */                 pixelValue = this.inputImage.getf(u, v);
/*  195 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  200 */           if (!found) {
/*  201 */             pixelList.addLast(pixelRecord);
/*      */           } else {
/*  203 */             change = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  208 */     long end = System.currentTimeMillis();
/*  209 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  210 */     IJ.showProgress(1.0D);
/*      */     
/*  212 */     return (ImageProcessor)new FloatProcessor(tabLabels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImagePlus getAnimationSortedList() {
/*  231 */     int size1 = this.inputImage.getWidth();
/*  232 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  234 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/*  236 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  240 */     if (this.connectivity != 4 && this.connectivity != 8) {
/*  241 */       throw new RuntimeException(
/*  242 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  243 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  247 */     ImageStack animation = new ImageStack(size1, size2);
/*      */ 
/*      */     
/*  250 */     LinkedList<PixelRecord> pixelList = null;
/*      */     
/*  252 */     int[][] tabLabels = new int[size1][size2];
/*      */ 
/*      */     
/*  255 */     IJ.showStatus("Extracting pixel values...");
/*  256 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  257 */     long t0 = System.currentTimeMillis();
/*      */     
/*  259 */     pixelList = extractPixelValues(this.inputImage, this.markerImage, tabLabels);
/*  260 */     if (pixelList == null) {
/*  261 */       return null;
/*      */     }
/*  263 */     long t1 = System.currentTimeMillis();
/*  264 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  265 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/*  266 */     IJ.showStatus("Sorting pixels by value...");
/*  267 */     Collections.sort(pixelList);
/*  268 */     long t2 = System.currentTimeMillis();
/*  269 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  272 */     double h = 0.0D;
/*      */ 
/*      */     
/*  275 */     animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */ 
/*      */     
/*  278 */     boolean found = false;
/*      */     
/*  280 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  283 */     Cursor2D cursor = new Cursor2D(0, 0);
/*      */ 
/*      */     
/*  286 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  287 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/*  289 */     boolean change = true;
/*  290 */     while (!pixelList.isEmpty() && change) {
/*      */       
/*  292 */       if (Thread.currentThread().isInterrupted()) {
/*  293 */         return null;
/*      */       }
/*  295 */       change = false;
/*  296 */       int count = pixelList.size();
/*  297 */       if (this.verbose) IJ.log("  Flooding " + count + " pixels..."); 
/*  298 */       IJ.showStatus("Flooding " + count + " pixels...");
/*      */       
/*  300 */       for (int p = 0; p < count; p++) {
/*      */         
/*  302 */         IJ.showProgress(p, count);
/*  303 */         PixelRecord pixelRecord = pixelList.removeFirst();
/*  304 */         Cursor2D p2 = pixelRecord.getCursor();
/*  305 */         int k = p2.getX();
/*  306 */         int j = p2.getY();
/*      */ 
/*      */         
/*  309 */         if (tabLabels[k][j] == 0) {
/*      */           
/*  311 */           found = false;
/*  312 */           double pixelValue = pixelRecord.getValue();
/*      */ 
/*      */           
/*  315 */           cursor.set(k, j);
/*  316 */           neigh.setCursor(cursor);
/*      */           
/*  318 */           for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */             
/*  322 */             int u = c.getX();
/*  323 */             int v = c.getY();
/*      */             
/*  325 */             if (u >= 0 && u < size1 && v >= 0 && v < size2)
/*      */             {
/*  327 */               if (tabLabels[u][v] != 0 && this.inputImage.getf(u, v) <= pixelValue) {
/*      */                 
/*  329 */                 tabLabels[k][j] = tabLabels[u][v];
/*  330 */                 pixelValue = this.inputImage.getf(u, v);
/*  331 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  336 */           if (!found) {
/*  337 */             pixelList.addLast(pixelRecord);
/*      */           } else {
/*  339 */             change = true;
/*      */           } 
/*      */           
/*  342 */           if (pixelValue > h) {
/*      */             
/*  344 */             h = pixelValue;
/*  345 */             animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  351 */       h = 0.0D;
/*      */     } 
/*      */     
/*  354 */     long end = System.currentTimeMillis();
/*  355 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  356 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  359 */     FloatProcessor labelProcessor = new FloatProcessor(size1, size2);
/*  360 */     for (int i = 0; i < size1; i++) {
/*  361 */       for (int j = 0; j < size2; j++) {
/*      */         
/*  363 */         if (tabLabels[i][j] == -1)
/*  364 */         { labelProcessor.setf(i, j, 0.0F); }
/*      */         else
/*  366 */         { labelProcessor.setf(i, j, tabLabels[i][j]); } 
/*      */       } 
/*  368 */     }  animation.addSlice("h=" + h, (ImageProcessor)labelProcessor);
/*      */     
/*  370 */     return new ImagePlus("Watersed flooding with sorted list", animation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImageProcessor applyWithSortedListAndDams() {
/*  389 */     int size1 = this.inputImage.getWidth();
/*  390 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  392 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight()) {
/*  393 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  397 */     if (this.connectivity != 4 && this.connectivity != 8) {
/*  398 */       throw new RuntimeException(
/*  399 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  400 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  404 */     int[][] tabLabels = new int[size1][size2];
/*      */ 
/*      */     
/*  407 */     IJ.showStatus("Extracting pixel values...");
/*  408 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  409 */     long t0 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */     
/*  413 */     LinkedList<PixelRecord> pixelList = extractPixelValues(this.inputImage, this.markerImage, tabLabels);
/*  414 */     if (pixelList == null) {
/*  415 */       return null;
/*      */     }
/*  417 */     long t1 = System.currentTimeMillis();
/*  418 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  419 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/*  420 */     IJ.showStatus("Sorting pixels by value...");
/*  421 */     Collections.sort(pixelList);
/*  422 */     long t2 = System.currentTimeMillis();
/*  423 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  426 */     boolean found = false;
/*      */     
/*  428 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  431 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  432 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */ 
/*      */     
/*  435 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  437 */     boolean change = true;
/*  438 */     while (!pixelList.isEmpty() && change) {
/*      */       
/*  440 */       if (Thread.currentThread().isInterrupted()) {
/*  441 */         return null;
/*      */       }
/*  443 */       change = false;
/*  444 */       int count = pixelList.size();
/*  445 */       if (this.verbose) IJ.log("  Flooding " + count + " pixels..."); 
/*  446 */       IJ.showStatus("Flooding " + count + " pixels...");
/*      */       
/*  448 */       for (int p = 0; p < count; p++) {
/*      */         
/*  450 */         IJ.showProgress(p, count);
/*  451 */         PixelRecord pixelRecord = pixelList.removeFirst();
/*  452 */         Cursor2D p2 = pixelRecord.getCursor();
/*  453 */         int i = p2.getX();
/*  454 */         int j = p2.getY();
/*      */ 
/*      */         
/*  457 */         if (tabLabels[i][j] == 0) {
/*      */           
/*  459 */           found = false;
/*      */ 
/*      */           
/*  462 */           neigh.setCursor(p2);
/*      */ 
/*      */           
/*  465 */           neighborLabels.clear();
/*      */           
/*  467 */           for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */             
/*  470 */             int u = c.getX();
/*  471 */             int v = c.getY();
/*      */             
/*  473 */             if (u >= 0 && u < size1 && v >= 0 && v < size2)
/*      */             {
/*  475 */               if (tabLabels[u][v] > 0) {
/*      */ 
/*      */                 
/*  478 */                 if (!neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*  479 */                   neighborLabels.add(Integer.valueOf(tabLabels[u][v])); 
/*  480 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  485 */           if (!found) {
/*  486 */             pixelList.addLast(pixelRecord);
/*      */           } else {
/*      */             
/*  489 */             change = true;
/*      */ 
/*      */ 
/*      */             
/*  493 */             if (neighborLabels.size() == 1) {
/*  494 */               tabLabels[i][j] = ((Integer)neighborLabels.get(0)).intValue();
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  500 */     long end = System.currentTimeMillis();
/*  501 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  502 */     IJ.showProgress(1.0D);
/*      */     
/*  504 */     return (ImageProcessor)new FloatProcessor(tabLabels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImagePlus getAnimationSortedListAndDams() {
/*  523 */     int size1 = this.inputImage.getWidth();
/*  524 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  526 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight()) {
/*  527 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  531 */     if (this.connectivity != 4 && this.connectivity != 8) {
/*  532 */       throw new RuntimeException(
/*  533 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  534 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  538 */     ImageStack animation = new ImageStack(size1, size2);
/*      */ 
/*      */     
/*  541 */     int[][] tabLabels = new int[size1][size2];
/*      */ 
/*      */     
/*  544 */     IJ.showStatus("Extracting pixel values...");
/*  545 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  546 */     long t0 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */     
/*  550 */     LinkedList<PixelRecord> pixelList = extractPixelValues(this.inputImage, this.markerImage, tabLabels);
/*  551 */     if (pixelList == null) {
/*  552 */       return null;
/*      */     }
/*  554 */     long t1 = System.currentTimeMillis();
/*  555 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  556 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/*  557 */     IJ.showStatus("Sorting pixels by value...");
/*  558 */     Collections.sort(pixelList);
/*  559 */     long t2 = System.currentTimeMillis();
/*  560 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  563 */     double h = 0.0D;
/*      */ 
/*      */     
/*  566 */     animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */ 
/*      */     
/*  569 */     boolean found = false;
/*      */     
/*  571 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  574 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  575 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */ 
/*      */     
/*  578 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  580 */     boolean change = true;
/*  581 */     while (!pixelList.isEmpty() && change) {
/*      */       
/*  583 */       if (Thread.currentThread().isInterrupted()) {
/*  584 */         return null;
/*      */       }
/*  586 */       change = false;
/*  587 */       int count = pixelList.size();
/*  588 */       IJ.log("  Flooding " + count + " pixels...");
/*  589 */       IJ.showStatus("Flooding " + count + " pixels...");
/*      */       
/*  591 */       for (int p = 0; p < count; p++) {
/*      */         
/*  593 */         IJ.showProgress(p, count);
/*  594 */         PixelRecord pixelRecord = pixelList.removeFirst();
/*  595 */         Cursor2D p2 = pixelRecord.getCursor();
/*  596 */         int k = p2.getX();
/*  597 */         int j = p2.getY();
/*      */ 
/*      */         
/*  600 */         if (tabLabels[k][j] == 0) {
/*      */           
/*  602 */           found = false;
/*      */ 
/*      */           
/*  605 */           neigh.setCursor(p2);
/*      */ 
/*      */           
/*  608 */           neighborLabels.clear();
/*      */           
/*  610 */           for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */             
/*  613 */             int u = c.getX();
/*  614 */             int v = c.getY();
/*      */             
/*  616 */             if (u >= 0 && u < size1 && v >= 0 && v < size2)
/*      */             {
/*  618 */               if (tabLabels[u][v] > 0) {
/*      */ 
/*      */                 
/*  621 */                 if (!neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*  622 */                   neighborLabels.add(Integer.valueOf(tabLabels[u][v])); 
/*  623 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  628 */           if (!found) {
/*  629 */             pixelList.addLast(pixelRecord);
/*      */           } else {
/*      */             
/*  632 */             change = true;
/*      */ 
/*      */ 
/*      */             
/*  636 */             if (neighborLabels.size() == 1) {
/*  637 */               tabLabels[k][j] = ((Integer)neighborLabels.get(0)).intValue();
/*      */             }
/*      */           } 
/*      */           
/*  641 */           if (pixelRecord.getValue() > h) {
/*      */             
/*  643 */             h = pixelRecord.getValue();
/*  644 */             animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  650 */       h = 0.0D;
/*      */     } 
/*      */     
/*  653 */     long end = System.currentTimeMillis();
/*  654 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  655 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  658 */     FloatProcessor labelProcessor = new FloatProcessor(size1, size2);
/*  659 */     for (int i = 0; i < size1; i++) {
/*  660 */       for (int j = 0; j < size2; j++) {
/*      */         
/*  662 */         if (tabLabels[i][j] == -1)
/*  663 */         { labelProcessor.setf(i, j, 0.0F); }
/*      */         else
/*  665 */         { labelProcessor.setf(i, j, tabLabels[i][j]); } 
/*      */       } 
/*  667 */     }  animation.addSlice("h=" + h, (ImageProcessor)labelProcessor);
/*      */     
/*  669 */     return new ImagePlus("Watershed flooding with sorted list", animation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageProcessor applyWithPriorityQueue() {
/*  684 */     int size1 = this.inputImage.getWidth();
/*  685 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  687 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/*  689 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  693 */     if (this.connectivity != 4 && this.connectivity != 8)
/*      */     {
/*  695 */       throw new RuntimeException(
/*  696 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  697 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  701 */     PriorityQueue<PixelRecord> pixelList = null;
/*      */     
/*  703 */     int[][] tabLabels = new int[size1][size2];
/*      */     
/*  705 */     if (this.maskImage == null) {
/*      */       
/*  707 */       for (int i = 0; i < size1; i++) {
/*  708 */         Arrays.fill(tabLabels[i], -1);
/*      */       }
/*      */     } else {
/*      */       
/*  712 */       for (int i = 0; i < size1; i++) {
/*  713 */         for (int j = 0; j < size2; j++) {
/*  714 */           if (this.maskImage.getf(i, j) > 0.0F)
/*  715 */             tabLabels[i][j] = -1; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  719 */     IJ.showStatus("Extracting pixel values...");
/*  720 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  721 */     long t0 = System.currentTimeMillis();
/*      */     
/*  723 */     pixelList = extractPixelValuesPriorityQueue(this.inputImage, this.markerImage, tabLabels);
/*  724 */     if (pixelList == null) {
/*  725 */       return null;
/*      */     }
/*  727 */     long t1 = System.currentTimeMillis();
/*  728 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/*  731 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  734 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  735 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/*  737 */     int count = pixelList.size();
/*  738 */     if (this.verbose) IJ.log("  Flooding from " + count + " pixels..."); 
/*  739 */     IJ.showStatus("Flooding from " + count + " pixels...");
/*      */     
/*  741 */     double maxValue = this.inputImage.getMax();
/*      */ 
/*      */     
/*  744 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  746 */     ArrayList<PixelRecord> neighborPixels = new ArrayList<PixelRecord>();
/*      */ 
/*      */     
/*  749 */     if (this.maskImage != null) {
/*      */       
/*  751 */       while (!pixelList.isEmpty()) {
/*      */         
/*  753 */         if (Thread.currentThread().isInterrupted()) {
/*  754 */           return null;
/*      */         }
/*  756 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/*  758 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  760 */         Cursor2D p = pixelRecord.getCursor();
/*  761 */         int i = p.getX();
/*  762 */         int j = p.getY();
/*      */ 
/*      */         
/*  765 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  768 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  771 */         neighborPixels.clear();
/*      */         
/*  773 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  777 */           int u = c.getX();
/*  778 */           int v = c.getY();
/*      */           
/*  780 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */ 
/*      */             
/*  784 */             if (tabLabels[u][v] == -1 && 
/*  785 */               this.maskImage.getf(u, v) > 0.0F) {
/*      */               
/*  787 */               neighborPixels.add(
/*  788 */                   new PixelRecord(
/*  789 */                     c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/*  791 */             if (tabLabels[u][v] > 0 && 
/*  792 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/*  795 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  800 */         if (neighborLabels.size() > 0) {
/*      */           
/*  802 */           tabLabels[i][j] = ((Integer)neighborLabels.get(0)).intValue();
/*      */ 
/*      */           
/*  805 */           for (PixelRecord v : neighborPixels)
/*      */           {
/*  807 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/*  808 */             pixelList.add(v);
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/*  815 */       while (!pixelList.isEmpty()) {
/*      */         
/*  817 */         if (Thread.currentThread().isInterrupted()) {
/*  818 */           return null;
/*      */         }
/*  820 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/*  822 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  824 */         Cursor2D p = pixelRecord.getCursor();
/*  825 */         int i = p.getX();
/*  826 */         int j = p.getY();
/*      */ 
/*      */         
/*  829 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  832 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  835 */         neighborPixels.clear();
/*      */         
/*  837 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  841 */           int u = c.getX();
/*  842 */           int v = c.getY();
/*      */           
/*  844 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */ 
/*      */             
/*  848 */             if (tabLabels[u][v] == -1) {
/*      */               
/*  850 */               neighborPixels.add(
/*  851 */                   new PixelRecord(
/*  852 */                     c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/*  854 */             if (tabLabels[u][v] > 0 && 
/*  855 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/*  858 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  863 */         if (neighborLabels.size() > 0) {
/*      */           
/*  865 */           tabLabels[i][j] = ((Integer)neighborLabels.get(0)).intValue();
/*      */ 
/*      */           
/*  868 */           for (PixelRecord v : neighborPixels) {
/*      */             
/*  870 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/*  871 */             pixelList.add(v);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  877 */     long end = System.currentTimeMillis();
/*  878 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  879 */     IJ.showProgress(1.0D);
/*      */     
/*  881 */     return (ImageProcessor)new FloatProcessor(tabLabels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImagePlus getAnimationPriorityQueue() {
/*  895 */     int size1 = this.inputImage.getWidth();
/*  896 */     int size2 = this.inputImage.getHeight();
/*      */     
/*  898 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/*  900 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  904 */     if (this.connectivity != 4 && this.connectivity != 8)
/*      */     {
/*  906 */       throw new RuntimeException(
/*  907 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/*  908 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  912 */     ImageStack animation = new ImageStack(size1, size2);
/*      */ 
/*      */     
/*  915 */     PriorityQueue<PixelRecord> pixelList = null;
/*      */     
/*  917 */     int[][] tabLabels = new int[size1][size2];
/*      */ 
/*      */     
/*  920 */     IJ.showStatus("Extracting pixel values...");
/*  921 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/*  922 */     long t0 = System.currentTimeMillis();
/*      */     
/*  924 */     pixelList = extractPixelValuesPriorityQueue(this.inputImage, this.markerImage, tabLabels);
/*  925 */     if (pixelList == null) {
/*  926 */       return null;
/*      */     }
/*  928 */     long t1 = System.currentTimeMillis();
/*  929 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/*  932 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  935 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/*  936 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/*  938 */     int count = pixelList.size();
/*  939 */     if (this.verbose) IJ.log("  Flooding from " + count + " pixels..."); 
/*  940 */     IJ.showStatus("Flooding from " + count + " pixels...");
/*      */     
/*  942 */     int numPixels = size1 * size2;
/*      */ 
/*      */     
/*  945 */     double h = 0.0D;
/*      */     
/*  947 */     animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */ 
/*      */     
/*  950 */     if (this.maskImage != null) {
/*      */       
/*  952 */       while (!pixelList.isEmpty()) {
/*      */         
/*  954 */         if (Thread.currentThread().isInterrupted()) {
/*  955 */           return null;
/*      */         }
/*  957 */         IJ.showProgress(numPixels - pixelList.size(), numPixels);
/*      */         
/*  959 */         PixelRecord pixelRecord = pixelList.poll();
/*  960 */         Cursor2D p = pixelRecord.getCursor();
/*  961 */         int k = p.getX();
/*  962 */         int j = p.getY();
/*      */         
/*  964 */         double pixelValue = pixelRecord.getValue();
/*      */ 
/*      */         
/*  967 */         neigh.setCursor(p);
/*      */         
/*  969 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  973 */           int u = c.getX();
/*  974 */           int v = c.getY();
/*      */           
/*  976 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/*  979 */             if (tabLabels[u][v] == 0 && this.maskImage.getf(u, v) > 0.0F) {
/*      */               
/*  981 */               pixelList.add(new PixelRecord(u, v, this.inputImage.getf(u, v)));
/*  982 */               tabLabels[u][v] = -3; continue;
/*      */             } 
/*  984 */             if (tabLabels[u][v] > 0 && this.inputImage.getf(u, v) <= pixelValue) {
/*      */ 
/*      */               
/*  987 */               tabLabels[k][j] = tabLabels[u][v];
/*  988 */               pixelValue = this.inputImage.getf(u, v);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  994 */         if (pixelValue > h)
/*      */         {
/*  996 */           h = pixelValue;
/*  997 */           animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/* 1003 */       while (!pixelList.isEmpty()) {
/*      */         
/* 1005 */         if (Thread.currentThread().isInterrupted()) {
/* 1006 */           return null;
/*      */         }
/* 1008 */         IJ.showProgress(numPixels - pixelList.size(), numPixels);
/*      */         
/* 1010 */         PixelRecord pixelRecord = pixelList.poll();
/* 1011 */         Cursor2D p = pixelRecord.getCursor();
/* 1012 */         int k = p.getX();
/* 1013 */         int j = p.getY();
/*      */         
/* 1015 */         double pixelValue = pixelRecord.getValue();
/*      */ 
/*      */         
/* 1018 */         neigh.setCursor(p);
/*      */         
/* 1020 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/* 1024 */           int u = c.getX();
/* 1025 */           int v = c.getY();
/*      */           
/* 1027 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/* 1030 */             if (tabLabels[u][v] == 0) {
/*      */               
/* 1032 */               pixelList.add(new PixelRecord(u, v, this.inputImage.getf(u, v)));
/* 1033 */               tabLabels[u][v] = -3; continue;
/*      */             } 
/* 1035 */             if (tabLabels[u][v] > 0 && this.inputImage.getf(u, v) <= pixelValue) {
/*      */ 
/*      */               
/* 1038 */               tabLabels[k][j] = tabLabels[u][v];
/* 1039 */               pixelValue = this.inputImage.getf(u, v);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1044 */         if (pixelValue > h) {
/*      */           
/* 1046 */           h = pixelValue;
/* 1047 */           animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1053 */     long end = System.currentTimeMillis();
/* 1054 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/* 1055 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/* 1058 */     FloatProcessor labelProcessor = new FloatProcessor(size1, size2);
/* 1059 */     for (int i = 0; i < size1; i++) {
/* 1060 */       for (int j = 0; j < size2; j++) {
/*      */         
/* 1062 */         if (tabLabels[i][j] == -1)
/* 1063 */         { labelProcessor.setf(i, j, 0.0F); }
/*      */         else
/* 1065 */         { labelProcessor.setf(i, j, tabLabels[i][j]); } 
/*      */       } 
/* 1067 */     }  animation.addSlice("h=" + h, (ImageProcessor)labelProcessor);
/*      */     
/* 1069 */     return new ImagePlus("Watershed flooding with priority queue", animation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImagePlus getAnimationPriorityQueueAndDams() {
/* 1101 */     if (Thread.currentThread().isInterrupted()) {
/* 1102 */       return null;
/*      */     }
/* 1104 */     int size1 = this.inputImage.getWidth();
/* 1105 */     int size2 = this.inputImage.getHeight();
/*      */     
/* 1107 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/* 1109 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/* 1113 */     if (this.connectivity != 4 && this.connectivity != 8)
/*      */     {
/* 1115 */       throw new RuntimeException(
/* 1116 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/* 1117 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/* 1121 */     ImageStack animation = new ImageStack(size1, size2);
/*      */ 
/*      */     
/* 1124 */     PriorityQueue<PixelRecord> pixelList = null;
/*      */ 
/*      */     
/* 1127 */     int[][] tabLabels = new int[size1][size2];
/*      */     
/* 1129 */     for (int i = 0; i < size1; i++) {
/* 1130 */       Arrays.fill(tabLabels[i], -1);
/*      */     }
/*      */     
/* 1133 */     IJ.showStatus("Extracting pixel values...");
/* 1134 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/* 1135 */     long t0 = System.currentTimeMillis();
/*      */     
/* 1137 */     pixelList = extractPixelValuesPriorityQueue(this.inputImage, this.markerImage, tabLabels);
/* 1138 */     if (pixelList == null) {
/* 1139 */       return null;
/*      */     }
/* 1141 */     long t1 = System.currentTimeMillis();
/* 1142 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/* 1145 */     double h = 0.0D;
/*      */     
/* 1147 */     animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */ 
/*      */     
/* 1150 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/* 1153 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/* 1154 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/* 1156 */     int count = pixelList.size();
/* 1157 */     if (this.verbose) IJ.log("  Flooding from " + count + " pixels..."); 
/* 1158 */     IJ.showStatus("Flooding from " + count + " pixels...");
/*      */     
/* 1160 */     double maxValue = this.inputImage.getMax();
/*      */ 
/*      */     
/* 1163 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/* 1165 */     ArrayList<PixelRecord> neighborPixels = new ArrayList<PixelRecord>();
/*      */ 
/*      */     
/* 1168 */     if (this.maskImage != null) {
/*      */       
/* 1170 */       if (Thread.currentThread().isInterrupted()) {
/* 1171 */         return null;
/*      */       }
/* 1173 */       while (!pixelList.isEmpty())
/*      */       {
/* 1175 */         if (Thread.currentThread().isInterrupted()) {
/* 1176 */           return null;
/*      */         }
/* 1178 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/* 1180 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/* 1182 */         Cursor2D p = pixelRecord.getCursor();
/* 1183 */         int k = p.getX();
/* 1184 */         int m = p.getY();
/*      */ 
/*      */         
/* 1187 */         neigh.setCursor(p);
/*      */ 
/*      */         
/* 1190 */         neighborLabels.clear();
/*      */ 
/*      */         
/* 1193 */         neighborPixels.clear();
/*      */         
/* 1195 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/* 1199 */           int u = c.getX();
/* 1200 */           int v = c.getY();
/*      */           
/* 1202 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/* 1205 */             if (tabLabels[u][v] == -1 && this.maskImage.getf(u, v) > 0.0F) {
/*      */               
/* 1207 */               neighborPixels.add(new PixelRecord(c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/* 1209 */             if (tabLabels[u][v] > 0 && 
/* 1210 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/* 1213 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1219 */         if (neighborLabels.size() == 1) {
/*      */           
/* 1221 */           tabLabels[k][m] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/* 1223 */           for (PixelRecord v : neighborPixels)
/*      */           {
/* 1225 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/* 1226 */             pixelList.add(v);
/*      */           }
/*      */         
/* 1229 */         } else if (neighborLabels.size() > 1) {
/* 1230 */           tabLabels[k][m] = 0;
/*      */         } 
/*      */         
/* 1233 */         if (pixelRecord.getValue() > h)
/*      */         {
/* 1235 */           h = pixelRecord.getValue();
/* 1236 */           animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1243 */       while (!pixelList.isEmpty()) {
/*      */         
/* 1245 */         if (Thread.currentThread().isInterrupted()) {
/* 1246 */           return null;
/*      */         }
/* 1248 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/* 1250 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/* 1252 */         Cursor2D p = pixelRecord.getCursor();
/* 1253 */         int k = p.getX();
/* 1254 */         int m = p.getY();
/*      */ 
/*      */         
/* 1257 */         neigh.setCursor(p);
/*      */ 
/*      */         
/* 1260 */         neighborLabels.clear();
/*      */ 
/*      */         
/* 1263 */         neighborPixels.clear();
/*      */ 
/*      */         
/* 1266 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/* 1270 */           int u = c.getX();
/* 1271 */           int v = c.getY();
/* 1272 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/* 1275 */             if (tabLabels[u][v] == -1) {
/*      */               
/* 1277 */               neighborPixels.add(new PixelRecord(c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/* 1279 */             if (tabLabels[u][v] > 0 && 
/* 1280 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/* 1283 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1289 */         if (neighborLabels.size() == 1) {
/*      */           
/* 1291 */           tabLabels[k][m] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/* 1293 */           for (PixelRecord v : neighborPixels)
/*      */           {
/* 1295 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/* 1296 */             pixelList.add(v);
/*      */           }
/*      */         
/* 1299 */         } else if (neighborLabels.size() > 1) {
/* 1300 */           tabLabels[k][m] = 0;
/*      */         } 
/*      */         
/* 1303 */         if (pixelRecord.getValue() > h) {
/*      */           
/* 1305 */           h = pixelRecord.getValue();
/* 1306 */           animation.addSlice("h=" + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1311 */     long end = System.currentTimeMillis();
/* 1312 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/* 1313 */     IJ.showStatus("");
/* 1314 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/* 1317 */     FloatProcessor labelProcessor = new FloatProcessor(size1, size2);
/* 1318 */     for (int j = 0; j < size1; j++) {
/* 1319 */       for (int k = 0; k < size2; k++) {
/*      */         
/* 1321 */         if (tabLabels[j][k] == -1)
/* 1322 */         { labelProcessor.setf(j, k, 0.0F); }
/*      */         else
/* 1324 */         { labelProcessor.setf(j, k, tabLabels[j][k]); } 
/*      */       } 
/* 1326 */     }  animation.addSlice("h=" + h, (ImageProcessor)labelProcessor);
/*      */     
/* 1328 */     return new ImagePlus("Watershed flooding with priority queue", animation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImageProcessor applyWithPriorityQueueAndDams() {
/* 1359 */     if (Thread.currentThread().isInterrupted()) {
/*      */       
/* 1361 */       IJ.log("Watershed flooding was interrupted!");
/* 1362 */       return null;
/*      */     } 
/*      */     
/* 1365 */     int size1 = this.inputImage.getWidth();
/* 1366 */     int size2 = this.inputImage.getHeight();
/*      */     
/* 1368 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight())
/*      */     {
/* 1370 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/* 1374 */     if (this.connectivity != 4 && this.connectivity != 8)
/*      */     {
/* 1376 */       throw new RuntimeException(
/* 1377 */           "Connectivity for 2D images must be either 4 or 8, not " + 
/* 1378 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/* 1382 */     PriorityQueue<PixelRecord> pixelList = null;
/*      */ 
/*      */     
/* 1385 */     int[][] tabLabels = new int[size1][size2];
/*      */     
/* 1387 */     for (int i = 0; i < size1; i++) {
/* 1388 */       Arrays.fill(tabLabels[i], -1);
/*      */     }
/*      */     
/* 1391 */     IJ.showStatus("Extracting pixel values...");
/* 1392 */     if (this.verbose) IJ.log("  Extracting pixel values..."); 
/* 1393 */     long t0 = System.currentTimeMillis();
/*      */     
/* 1395 */     pixelList = extractPixelValuesPriorityQueue(this.inputImage, this.markerImage, tabLabels);
/* 1396 */     if (pixelList == null) {
/*      */       
/* 1398 */       IJ.log("Error while extracting values from input image!");
/* 1399 */       return null;
/*      */     } 
/*      */     
/* 1402 */     long t1 = System.currentTimeMillis();
/* 1403 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/* 1406 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/* 1409 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/* 1410 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/* 1412 */     int count = pixelList.size();
/* 1413 */     if (this.verbose) IJ.log("  Flooding from " + count + " pixels..."); 
/* 1414 */     IJ.showStatus("Flooding from " + count + " pixels...");
/*      */     
/* 1416 */     double maxValue = this.inputImage.getMax();
/*      */ 
/*      */     
/* 1419 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/* 1421 */     ArrayList<PixelRecord> neighborPixels = new ArrayList<PixelRecord>();
/*      */ 
/*      */     
/* 1424 */     if (this.maskImage != null) {
/*      */       
/* 1426 */       if (Thread.currentThread().isInterrupted()) {
/*      */         
/* 1428 */         IJ.log("Watershed flooding was interrupted!");
/* 1429 */         return null;
/*      */       } 
/*      */       
/* 1432 */       while (!pixelList.isEmpty()) {
/*      */         
/* 1434 */         if (Thread.currentThread().isInterrupted()) {
/*      */           
/* 1436 */           IJ.log("Watershed flooding was interrupted!");
/* 1437 */           return null;
/*      */         } 
/*      */         
/* 1440 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/* 1442 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/* 1444 */         Cursor2D p = pixelRecord.getCursor();
/* 1445 */         int k = p.getX();
/* 1446 */         int m = p.getY();
/*      */ 
/*      */         
/* 1449 */         neigh.setCursor(p);
/*      */ 
/*      */         
/* 1452 */         neighborLabels.clear();
/*      */ 
/*      */         
/* 1455 */         neighborPixels.clear();
/*      */         
/* 1457 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/* 1461 */           int u = c.getX();
/* 1462 */           int v = c.getY();
/*      */           
/* 1464 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/* 1467 */             if (tabLabels[u][v] == -1 && this.maskImage.getf(u, v) > 0.0F) {
/*      */               
/* 1469 */               neighborPixels.add(new PixelRecord(c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/* 1471 */             if (tabLabels[u][v] > 0 && 
/* 1472 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/* 1475 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1481 */         if (neighborLabels.size() == 1) {
/*      */           
/* 1483 */           tabLabels[k][m] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/* 1485 */           for (PixelRecord v : neighborPixels) {
/*      */             
/* 1487 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/* 1488 */             pixelList.add(v);
/*      */           }  continue;
/*      */         } 
/* 1491 */         if (neighborLabels.size() > 1) {
/* 1492 */           tabLabels[k][m] = 0;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1497 */       while (!pixelList.isEmpty()) {
/*      */         
/* 1499 */         if (Thread.currentThread().isInterrupted()) {
/*      */           
/* 1501 */           IJ.log("Watershed flooding was interrupted!");
/* 1502 */           return null;
/*      */         } 
/*      */         
/* 1505 */         PixelRecord pixelRecord = pixelList.poll();
/*      */         
/* 1507 */         IJ.showProgress((pixelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/* 1509 */         Cursor2D p = pixelRecord.getCursor();
/* 1510 */         int k = p.getX();
/* 1511 */         int m = p.getY();
/*      */ 
/*      */         
/* 1514 */         neigh.setCursor(p);
/*      */ 
/*      */         
/* 1517 */         neighborLabels.clear();
/*      */ 
/*      */         
/* 1520 */         neighborPixels.clear();
/*      */ 
/*      */         
/* 1523 */         for (Cursor2D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/* 1527 */           int u = c.getX();
/* 1528 */           int v = c.getY();
/* 1529 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*      */ 
/*      */             
/* 1532 */             if (tabLabels[u][v] == -1) {
/*      */               
/* 1534 */               neighborPixels.add(new PixelRecord(c, this.inputImage.getf(u, v))); continue;
/*      */             } 
/* 1536 */             if (tabLabels[u][v] > 0 && 
/* 1537 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v])))
/*      */             {
/*      */               
/* 1540 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1546 */         if (neighborLabels.size() == 1) {
/*      */           
/* 1548 */           tabLabels[k][m] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/* 1550 */           for (PixelRecord v : neighborPixels) {
/*      */             
/* 1552 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()] = -3;
/* 1553 */             pixelList.add(v);
/*      */           }  continue;
/*      */         } 
/* 1556 */         if (neighborLabels.size() > 1) {
/* 1557 */           tabLabels[k][m] = 0;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1562 */     long end = System.currentTimeMillis();
/* 1563 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/* 1564 */     IJ.showStatus("");
/* 1565 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/* 1568 */     ImageProcessor labelProcessor = this.markerImage.duplicate();
/* 1569 */     for (int j = 0; j < size1; j++) {
/* 1570 */       for (int k = 0; k < size2; k++) {
/*      */         
/* 1572 */         if (tabLabels[j][k] == -1) {
/* 1573 */           labelProcessor.setf(j, k, 0.0F);
/*      */         } else {
/* 1575 */           labelProcessor.setf(j, k, tabLabels[j][k]);
/*      */         } 
/*      */       } 
/* 1578 */     }  return labelProcessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PriorityQueue<PixelRecord> extractPixelValuesPriorityQueue(ImageProcessor inputImage, ImageProcessor seedImage, int[][] tabLabels) {
/* 1595 */     if (Thread.currentThread().isInterrupted()) {
/*      */       
/* 1597 */       IJ.log("Pixel extraction was interrupted!");
/* 1598 */       return null;
/*      */     } 
/*      */     
/* 1601 */     int size1 = inputImage.getWidth();
/* 1602 */     int size2 = inputImage.getHeight();
/*      */     
/* 1604 */     PriorityQueue<PixelRecord> pixelList = new PriorityQueue<PixelRecord>();
/*      */ 
/*      */     
/* 1607 */     Cursor2D cursor = new Cursor2D(0, 0);
/*      */ 
/*      */     
/* 1610 */     Neighborhood2D neigh = (this.connectivity == 8) ? 
/* 1611 */       (Neighborhood2D)new Neighborhood2DC8() : (Neighborhood2D)new Neighborhood2DC4();
/*      */     
/* 1613 */     if (this.maskImage != null) {
/*      */       
/* 1615 */       for (int x = 0; x < size1; x++) {
/* 1616 */         for (int y = 0; y < size2; y++) {
/* 1617 */           if (this.maskImage.getf(x, y) > 0.0F) {
/*      */             
/* 1619 */             int label = (int)seedImage.getf(x, y);
/* 1620 */             if (label > 0) {
/*      */               
/* 1622 */               cursor.set(x, y);
/* 1623 */               neigh.setCursor(cursor);
/*      */ 
/*      */               
/* 1626 */               for (Cursor2D c : neigh.getNeighbors()) {
/*      */                 
/* 1628 */                 int u = c.getX();
/* 1629 */                 int v = c.getY();
/*      */                 
/* 1631 */                 if (u >= 0 && u < size1 && 
/* 1632 */                   v >= 0 && v < size2 && 
/* 1633 */                   (int)seedImage.getf(u, v) == 0 && 
/* 1634 */                   tabLabels[u][v] != -3) {
/*      */                   
/* 1636 */                   pixelList.add(new PixelRecord(u, v, inputImage.getf(u, v)));
/* 1637 */                   tabLabels[u][v] = -3;
/*      */                 } 
/*      */               } 
/*      */               
/* 1641 */               tabLabels[x][y] = label;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1647 */       for (int x = 0; x < size1; x++) {
/* 1648 */         for (int y = 0; y < size2; y++) {
/*      */           
/* 1650 */           int label = (int)seedImage.getf(x, y);
/* 1651 */           if (label > 0) {
/*      */             
/* 1653 */             cursor.set(x, y);
/* 1654 */             neigh.setCursor(cursor);
/*      */ 
/*      */             
/* 1657 */             for (Cursor2D c : neigh.getNeighbors()) {
/*      */               
/* 1659 */               int u = c.getX();
/* 1660 */               int v = c.getY();
/* 1661 */               if (u >= 0 && u < size1 && 
/* 1662 */                 v >= 0 && v < size2 && 
/* 1663 */                 (int)seedImage.getf(u, v) == 0 && 
/* 1664 */                 tabLabels[u][v] != -3) {
/*      */                 
/* 1666 */                 pixelList.add(new PixelRecord(u, v, inputImage.getf(u, v)));
/* 1667 */                 tabLabels[u][v] = -3;
/*      */               } 
/*      */             } 
/*      */             
/* 1671 */             tabLabels[x][y] = label;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1676 */     return pixelList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedList<PixelRecord> extractPixelValues(ImageProcessor inputImage, ImageProcessor markerImage, int[][] tabLabels) {
/* 1695 */     int size1 = inputImage.getWidth();
/* 1696 */     int size2 = inputImage.getHeight();
/*      */     
/* 1698 */     LinkedList<PixelRecord> list = new LinkedList<PixelRecord>();
/*      */     
/* 1700 */     if (this.maskImage != null) {
/*      */       
/* 1702 */       for (int x = 0; x < size1; x++) {
/* 1703 */         for (int y = 0; y < size2; y++) {
/* 1704 */           if (this.maskImage.getf(x, y) > 0.0F) {
/*      */             
/* 1706 */             list.addLast(new PixelRecord(x, y, inputImage.getf(x, y)));
/* 1707 */             tabLabels[x][y] = (int)markerImage.getf(x, y);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1712 */       for (int x = 0; x < size1; x++) {
/* 1713 */         for (int y = 0; y < size2; y++) {
/*      */           
/* 1715 */           list.addLast(new PixelRecord(x, y, inputImage.getf(x, y)));
/* 1716 */           tabLabels[x][y] = (int)markerImage.getf(x, y);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1721 */     return list;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/MarkerControlledWatershedTransform2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */