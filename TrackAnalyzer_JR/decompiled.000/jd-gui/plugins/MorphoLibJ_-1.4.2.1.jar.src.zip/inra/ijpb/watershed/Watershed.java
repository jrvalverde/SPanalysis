/*     */ package inra.ijpb.watershed;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Watershed
/*     */ {
/*     */   public static ImagePlus computeWatershed(ImagePlus input, ImagePlus mask, int connectivity) {
/*  50 */     WatershedTransform3D wt = new WatershedTransform3D(input, mask, connectivity);
/*     */     
/*  52 */     return wt.apply();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus computeWatershed(ImagePlus input, ImagePlus mask, int connectivity, double hMin, double hMax) {
/*  75 */     if (connectivity == 6 || connectivity == 26) {
/*     */       
/*  77 */       WatershedTransform3D wt = new WatershedTransform3D(input, mask, connectivity);
/*  78 */       return wt.apply(hMin, hMax);
/*     */     } 
/*  80 */     if (connectivity == 4 || connectivity == 8) {
/*     */       
/*  82 */       WatershedTransform2D wt = 
/*  83 */         new WatershedTransform2D(input.getProcessor(), 
/*  84 */           (mask != null) ? mask.getProcessor() : null, connectivity);
/*  85 */       ImageProcessor ip = wt.apply(hMin, hMax);
/*  86 */       if (ip != null) {
/*     */         
/*  88 */         String title = input.getTitle();
/*  89 */         String ext = "";
/*  90 */         int index = title.lastIndexOf(".");
/*  91 */         if (index != -1) {
/*     */           
/*  93 */           ext = title.substring(index);
/*  94 */           title = title.substring(0, index);
/*     */         } 
/*     */         
/*  97 */         ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, ip);
/*  98 */         ws.setCalibration(input.getCalibration());
/*  99 */         return ws;
/*     */       } 
/*     */       
/* 102 */       return null;
/*     */     } 
/*     */     
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageStack computeWatershed(ImageStack input, ImageStack mask, int connectivity) {
/* 124 */     ImagePlus inputIP = new ImagePlus("input", input);
/* 125 */     ImagePlus binaryMaskIP = (mask != null) ? new ImagePlus("binary mask", mask) : null;
/* 126 */     WatershedTransform3D wt = new WatershedTransform3D(inputIP, binaryMaskIP, connectivity);
/*     */     
/* 128 */     ImagePlus ws = wt.apply();
/* 129 */     if (ws != null) {
/* 130 */       return ws.getImageStack();
/*     */     }
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor computeWatershed(ImageProcessor input, ImageProcessor mask, int connectivity) {
/* 151 */     WatershedTransform2D wt = new WatershedTransform2D(input, mask, connectivity);
/* 152 */     return wt.apply();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus computeWatershed(ImagePlus input, ImagePlus marker, ImagePlus binaryMask, int connectivity, boolean getDams) {
/* 173 */     return computeWatershed(input, marker, binaryMask, connectivity, 
/* 174 */         getDams, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus computeWatershed(ImagePlus input, ImagePlus marker, ImagePlus binaryMask, int connectivity, boolean getDams, boolean verbose) {
/* 196 */     if (connectivity == 6 || connectivity == 26) {
/*     */       
/* 198 */       MarkerControlledWatershedTransform3D wt = 
/* 199 */         new MarkerControlledWatershedTransform3D(input, marker, 
/* 200 */           binaryMask, connectivity);
/* 201 */       wt.setVerbose(verbose);
/* 202 */       if (getDams) {
/* 203 */         return wt.applyWithPriorityQueueAndDams();
/*     */       }
/* 205 */       return wt.applyWithPriorityQueue();
/*     */     } 
/* 207 */     if (connectivity == 4 || connectivity == 8) {
/*     */       ImageProcessor ip;
/* 209 */       MarkerControlledWatershedTransform2D wt = 
/* 210 */         new MarkerControlledWatershedTransform2D(
/* 211 */           input.getProcessor(), marker.getProcessor(), 
/* 212 */           (binaryMask != null) ? binaryMask.getProcessor() : 
/* 213 */           null, connectivity);
/* 214 */       wt.setVerbose(verbose);
/*     */       
/* 216 */       if (getDams) {
/* 217 */         ip = wt.applyWithPriorityQueueAndDams();
/*     */       } else {
/* 219 */         ip = wt.applyWithPriorityQueue();
/*     */       } 
/* 221 */       if (ip != null) {
/*     */         
/* 223 */         String title = input.getTitle();
/* 224 */         String ext = "";
/* 225 */         int index = title.lastIndexOf(".");
/* 226 */         if (index != -1) {
/*     */           
/* 228 */           ext = title.substring(index);
/* 229 */           title = title.substring(0, index);
/*     */         } 
/*     */         
/* 232 */         ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, ip);
/* 233 */         ws.setCalibration(input.getCalibration());
/* 234 */         return ws;
/*     */       } 
/*     */       
/* 237 */       return null;
/*     */     } 
/*     */     
/* 240 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageStack computeWatershed(ImageStack input, ImageStack marker, ImageStack binaryMask, int connectivity, boolean getDams) {
/* 261 */     return computeWatershed(input, marker, binaryMask, connectivity, 
/* 262 */         getDams, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageStack computeWatershed(ImageStack input, ImageStack marker, ImageStack binaryMask, int connectivity, boolean getDams, boolean verbose) {
/* 285 */     ImagePlus inputIP = new ImagePlus("input", input);
/* 286 */     ImagePlus markerIP = new ImagePlus("marker", marker);
/* 287 */     ImagePlus binaryMaskIP = (binaryMask != null) ? 
/* 288 */       new ImagePlus("binary mask", binaryMask) : null;
/*     */     
/* 290 */     ImagePlus ws = computeWatershed(inputIP, markerIP, binaryMaskIP, 
/* 291 */         connectivity, getDams, verbose);
/* 292 */     if (ws != null) {
/* 293 */       return ws.getImageStack();
/*     */     }
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor computeWatershed(ImageProcessor input, ImageProcessor marker, ImageProcessor binaryMask, int connectivity, boolean getDams) {
/* 315 */     return computeWatershed(input, marker, binaryMask, connectivity, 
/* 316 */         getDams, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor computeWatershed(ImageProcessor input, ImageProcessor marker, ImageProcessor binaryMask, int connectivity, boolean getDams, boolean verbose) {
/* 339 */     MarkerControlledWatershedTransform2D wt = 
/* 340 */       new MarkerControlledWatershedTransform2D(input, marker, 
/* 341 */         binaryMask, connectivity);
/* 342 */     wt.setVerbose(verbose);
/* 343 */     if (getDams) {
/* 344 */       return wt.applyWithPriorityQueueAndDams();
/*     */     }
/* 346 */     return wt.applyWithPriorityQueue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImagePlus computeWatershed(ImagePlus input, ImagePlus marker, int connectivity, boolean getDams) {
/* 364 */     MarkerControlledWatershedTransform3D wt = new MarkerControlledWatershedTransform3D(input, marker, null, connectivity);
/* 365 */     if (getDams) {
/* 366 */       return wt.applyWithPriorityQueueAndDams();
/*     */     }
/* 368 */     return wt.applyWithPriorityQueue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageStack computeWatershed(ImageStack input, ImageStack marker, int connectivity, boolean getDams) {
/* 386 */     if (Thread.currentThread().isInterrupted()) {
/* 387 */       return null;
/*     */     }
/* 389 */     ImagePlus inputIP = new ImagePlus("input", input);
/* 390 */     ImagePlus markerIP = new ImagePlus("marker", marker);
/*     */     
/* 392 */     MarkerControlledWatershedTransform3D wt = new MarkerControlledWatershedTransform3D(inputIP, markerIP, null, connectivity);
/*     */     
/* 394 */     ImagePlus ws = null;
/*     */     
/* 396 */     if (getDams) {
/* 397 */       ws = wt.applyWithPriorityQueueAndDams();
/*     */     } else {
/* 399 */       ws = wt.applyWithPriorityQueue();
/*     */     } 
/* 401 */     if (ws == null)
/* 402 */       return null; 
/* 403 */     return ws.getImageStack();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageProcessor computeWatershed(ImageProcessor input, ImageProcessor marker, int connectivity, boolean getDams) {
/* 421 */     MarkerControlledWatershedTransform2D wt = 
/* 422 */       new MarkerControlledWatershedTransform2D(input, marker, 
/* 423 */         null, connectivity);
/* 424 */     if (getDams) {
/* 425 */       return wt.applyWithPriorityQueueAndDams();
/*     */     }
/* 427 */     return wt.applyWithPriorityQueue();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/Watershed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */