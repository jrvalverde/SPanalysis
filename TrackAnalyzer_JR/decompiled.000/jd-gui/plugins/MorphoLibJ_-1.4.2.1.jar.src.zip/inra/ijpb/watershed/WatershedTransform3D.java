/*     */ package inra.ijpb.watershed;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.Prefs;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.util.ThreadUtil;
/*     */ import inra.ijpb.data.Cursor3D;
/*     */ import inra.ijpb.data.Neighborhood3D;
/*     */ import inra.ijpb.data.Neighborhood3DC26;
/*     */ import inra.ijpb.data.Neighborhood3DC6;
/*     */ import inra.ijpb.data.VoxelRecord;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WatershedTransform3D
/*     */ {
/*  75 */   ImagePlus inputImage = null;
/*     */ 
/*     */   
/*  78 */   ImagePlus maskImage = null;
/*     */ 
/*     */   
/*  81 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int MASK = -2;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int WSHED = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INIT = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INQUEUE = -3;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean verbose = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WatershedTransform3D(ImagePlus input, ImagePlus mask) {
/* 107 */     this.inputImage = input;
/* 108 */     this.maskImage = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WatershedTransform3D(ImagePlus input, ImagePlus mask, int connectivity) {
/* 123 */     this.inputImage = input;
/* 124 */     this.maskImage = mask;
/* 125 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/* 133 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int conn) {
/* 141 */     this.connectivity = conn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 149 */     this.verbose = verbose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus apply() {
/* 162 */     if (this.maskImage != null) {
/* 163 */       return applyWithMask();
/*     */     }
/* 165 */     return applyWithoutMask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus apply(double hMin, double hMax) {
/* 183 */     if (this.maskImage != null) {
/* 184 */       return applyWithMask(hMin, hMax);
/*     */     }
/* 186 */     return applyWithoutMask(hMin, hMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus applyWithMask() {
/* 202 */     double[] extrema = Images3D.findMinAndMax(this.inputImage);
/* 203 */     return applyWithMask(extrema[0], extrema[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus applyWithMask(double hMin, double hMax) {
/* 222 */     ImageStack inputStack = this.inputImage.getStack();
/* 223 */     int size1 = inputStack.getWidth();
/* 224 */     int size2 = inputStack.getHeight();
/* 225 */     int size3 = inputStack.getSize();
/*     */ 
/*     */     
/* 228 */     ImageStack mask = this.maskImage.getImageStack();
/*     */ 
/*     */     
/* 231 */     int[][][] tabLabels = new int[size1][size2][size3];
/*     */ 
/*     */     
/* 234 */     for (int i = 0; i < size1; i++) {
/* 235 */       for (int j = 0; j < size2; j++)
/* 236 */         Arrays.fill(tabLabels[i][j], -1); 
/*     */     } 
/* 238 */     int currentLabel = 0;
/*     */     
/* 240 */     boolean flag = false;
/*     */ 
/*     */     
/* 243 */     IJ.showStatus("Extracting voxel values...");
/* 244 */     if (this.verbose) IJ.log("  Extracting voxel values (h_min = " + hMin + ", h_max = " + hMax + ")..."); 
/* 245 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 248 */     ArrayList<VoxelRecord> voxelList = extractVoxelValues(inputStack, hMin, hMax);
/*     */     
/* 250 */     long t1 = System.currentTimeMillis();
/* 251 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/* 252 */     if (this.verbose) IJ.log("  Sorting voxels by value..."); 
/* 253 */     IJ.showStatus("Sorting voxels by value...");
/* 254 */     Collections.sort(voxelList);
/* 255 */     long t2 = System.currentTimeMillis();
/* 256 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*     */     
/* 258 */     IJ.log("  Flooding...");
/* 259 */     IJ.showStatus("Flooding...");
/* 260 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 263 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/* 264 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*     */     
/* 266 */     LinkedList<Cursor3D> fifo = new LinkedList<Cursor3D>();
/*     */ 
/*     */     
/* 269 */     int currentIndex = 0;
/*     */     
/* 271 */     int heightIndex1 = currentIndex;
/* 272 */     int heightIndex2 = currentIndex;
/*     */ 
/*     */     
/* 275 */     while (currentIndex < voxelList.size()) {
/*     */       
/* 277 */       double h = ((VoxelRecord)voxelList.get(currentIndex)).getValue();
/*     */       int voxelIndex;
/* 279 */       for (voxelIndex = heightIndex1; voxelIndex < voxelList.size(); voxelIndex++) {
/*     */         
/* 281 */         VoxelRecord voxelRecord = voxelList.get(voxelIndex);
/*     */         
/* 283 */         if (voxelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 286 */           heightIndex1 = voxelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 290 */         Cursor3D p = voxelRecord.getCursor();
/* 291 */         int m = p.getX();
/* 292 */         int j = p.getY();
/* 293 */         int n = p.getZ();
/*     */ 
/*     */         
/* 296 */         tabLabels[m][j][n] = -2;
/*     */ 
/*     */         
/* 299 */         neigh.setCursor(p);
/* 300 */         for (Cursor3D c : neigh.getNeighbors()) {
/*     */           
/* 302 */           int u = c.getX();
/* 303 */           int v = c.getY();
/* 304 */           int w = c.getZ();
/*     */ 
/*     */           
/* 307 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3 && 
/* 308 */             tabLabels[u][v][w] >= 0 && 
/* 309 */             mask.getVoxel(u, v, w) > 0.0D) {
/*     */ 
/*     */             
/* 312 */             fifo.addLast(p);
/* 313 */             tabLabels[m][j][n] = -3;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 319 */       while (!fifo.isEmpty()) {
/*     */ 
/*     */         
/* 322 */         Cursor3D p = fifo.poll();
/* 323 */         int m = p.getX();
/* 324 */         int j = p.getY();
/* 325 */         int n = p.getZ();
/*     */ 
/*     */         
/* 328 */         neigh.setCursor(p);
/*     */         
/* 330 */         for (Cursor3D c : neigh.getNeighbors()) {
/*     */ 
/*     */           
/* 333 */           int u = c.getX();
/* 334 */           int v = c.getY();
/* 335 */           int w = c.getZ();
/*     */           
/* 337 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3 && 
/* 338 */             mask.getVoxel(u, v, w) > 0.0D) {
/*     */             
/* 340 */             if (tabLabels[u][v][w] > 0) {
/*     */               
/* 342 */               if (tabLabels[m][j][n] == -3 || (tabLabels[m][j][n] == 0 && flag)) {
/*     */                 
/* 344 */                 tabLabels[m][j][n] = tabLabels[u][v][w]; continue;
/*     */               } 
/* 346 */               if (tabLabels[m][j][n] > 0 && tabLabels[m][j][n] != tabLabels[u][v][w]) {
/*     */                 
/* 348 */                 tabLabels[m][j][n] = 0;
/* 349 */                 flag = false;
/*     */               }  continue;
/*     */             } 
/* 352 */             if (tabLabels[u][v][w] == 0) {
/*     */               
/* 354 */               if (tabLabels[m][j][n] == -3) {
/*     */                 
/* 356 */                 tabLabels[m][j][n] = 0;
/* 357 */                 flag = true;
/*     */               }  continue;
/*     */             } 
/* 360 */             if (tabLabels[u][v][w] == -2) {
/*     */               
/* 362 */               tabLabels[u][v][w] = -3;
/* 363 */               fifo.addLast(c);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 372 */       for (voxelIndex = heightIndex2; voxelIndex < voxelList.size(); voxelIndex++, currentIndex++) {
/*     */         
/* 374 */         VoxelRecord voxelRecord = voxelList.get(voxelIndex);
/*     */         
/* 376 */         if (voxelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 379 */           heightIndex2 = voxelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 383 */         Cursor3D p = voxelRecord.getCursor();
/* 384 */         int m = p.getX();
/* 385 */         int j = p.getY();
/* 386 */         int n = p.getZ();
/*     */         
/* 388 */         if (tabLabels[m][j][n] == -2) {
/*     */           
/* 390 */           currentLabel++;
/* 391 */           fifo.addLast(p);
/* 392 */           tabLabels[m][j][n] = currentLabel;
/*     */           
/* 394 */           while (!fifo.isEmpty()) {
/*     */             
/* 396 */             Cursor3D p2 = fifo.poll();
/*     */ 
/*     */             
/* 399 */             neigh.setCursor(p2);
/*     */             
/* 401 */             for (Cursor3D c : neigh.getNeighbors()) {
/*     */               
/* 403 */               int u = c.getX();
/* 404 */               int v = c.getY();
/* 405 */               int w = c.getZ();
/*     */               
/* 407 */               if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3 && 
/* 408 */                 tabLabels[u][v][w] == -2 && 
/* 409 */                 mask.getVoxel(u, v, w) > 0.0D) {
/*     */                 
/* 411 */                 fifo.addLast(c);
/* 412 */                 tabLabels[u][v][w] = currentLabel;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 419 */       IJ.showProgress(h / hMax);
/*     */     } 
/*     */ 
/*     */     
/* 423 */     IJ.showProgress(1.0D);
/*     */     
/* 425 */     long end = System.currentTimeMillis();
/* 426 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms");
/*     */ 
/*     */     
/* 429 */     ImageStack labelStack = new ImageStack(size1, size2);
/*     */     
/* 431 */     for (int k = 0; k < size3; k++) {
/*     */ 
/*     */       
/* 434 */       FloatProcessor fp = new FloatProcessor(size1, size2);
/* 435 */       for (int j = 0; j < size1; j++) {
/* 436 */         for (int m = 0; m < size2; m++) {
/*     */           
/* 438 */           if (tabLabels[j][m][k] == -1)
/* 439 */           { fp.setf(j, m, 0.0F); }
/*     */           else
/* 441 */           { fp.setf(j, m, tabLabels[j][m][k]); } 
/*     */         } 
/* 443 */       }  labelStack.addSlice((ImageProcessor)fp);
/*     */     } 
/*     */     
/* 446 */     ImagePlus ws = new ImagePlus("watershed", labelStack);
/* 447 */     ws.setCalibration(this.inputImage.getCalibration());
/* 448 */     return ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus applyWithoutMask() {
/* 462 */     double[] extrema = Images3D.findMinAndMax(this.inputImage);
/* 463 */     return applyWithoutMask(extrema[0], extrema[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus applyWithoutMask(double hMin, double hMax) {
/* 480 */     ImageStack inputStack = this.inputImage.getStack();
/* 481 */     int size1 = inputStack.getWidth();
/* 482 */     int size2 = inputStack.getHeight();
/* 483 */     int size3 = inputStack.getSize();
/*     */ 
/*     */     
/* 486 */     int[][][] tabLabels = new int[size1][size2][size3];
/*     */ 
/*     */     
/* 489 */     for (int i = 0; i < size1; i++) {
/* 490 */       for (int j = 0; j < size2; j++)
/* 491 */         Arrays.fill(tabLabels[i][j], -1); 
/*     */     } 
/* 493 */     int currentLabel = 0;
/*     */     
/* 495 */     boolean flag = false;
/*     */ 
/*     */     
/* 498 */     IJ.showStatus("Extracting voxel values...");
/* 499 */     if (this.verbose) IJ.log("  Extracting voxel values (h_min = " + hMin + ", h_max = " + hMax + ")..."); 
/* 500 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 503 */     ArrayList<VoxelRecord> voxelList = extractVoxelValues(inputStack, hMin, hMax);
/*     */     
/* 505 */     long t1 = System.currentTimeMillis();
/* 506 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/* 507 */     if (this.verbose) IJ.log("  Sorting voxels by value..."); 
/* 508 */     IJ.showStatus("Sorting voxels by value...");
/* 509 */     Collections.sort(voxelList);
/* 510 */     long t2 = System.currentTimeMillis();
/* 511 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*     */     
/* 513 */     IJ.log("  Flooding...");
/* 514 */     IJ.showStatus("Flooding...");
/* 515 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 518 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/* 519 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*     */     
/* 521 */     LinkedList<Cursor3D> fifo = new LinkedList<Cursor3D>();
/*     */ 
/*     */     
/* 524 */     int currentIndex = 0;
/*     */     
/* 526 */     int heightIndex1 = currentIndex;
/* 527 */     int heightIndex2 = currentIndex;
/*     */ 
/*     */     
/* 530 */     while (currentIndex < voxelList.size()) {
/*     */       
/* 532 */       double h = ((VoxelRecord)voxelList.get(currentIndex)).getValue();
/*     */       int voxelIndex;
/* 534 */       for (voxelIndex = heightIndex1; voxelIndex < voxelList.size(); voxelIndex++) {
/*     */         
/* 536 */         VoxelRecord voxelRecord = voxelList.get(voxelIndex);
/*     */         
/* 538 */         if (voxelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 541 */           heightIndex1 = voxelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 545 */         Cursor3D p = voxelRecord.getCursor();
/* 546 */         int m = p.getX();
/* 547 */         int j = p.getY();
/* 548 */         int n = p.getZ();
/*     */ 
/*     */         
/* 551 */         tabLabels[m][j][n] = -2;
/*     */ 
/*     */         
/* 554 */         neigh.setCursor(p);
/* 555 */         for (Cursor3D c : neigh.getNeighbors()) {
/*     */           
/* 557 */           int u = c.getX();
/* 558 */           int v = c.getY();
/* 559 */           int w = c.getZ();
/*     */ 
/*     */           
/* 562 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3 && 
/* 563 */             tabLabels[u][v][w] >= 0) {
/*     */             
/* 565 */             fifo.addLast(p);
/* 566 */             tabLabels[m][j][n] = -3;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 572 */       while (!fifo.isEmpty()) {
/*     */ 
/*     */         
/* 575 */         Cursor3D p = fifo.poll();
/* 576 */         int m = p.getX();
/* 577 */         int j = p.getY();
/* 578 */         int n = p.getZ();
/*     */ 
/*     */         
/* 581 */         neigh.setCursor(p);
/*     */         
/* 583 */         for (Cursor3D c : neigh.getNeighbors()) {
/*     */ 
/*     */           
/* 586 */           int u = c.getX();
/* 587 */           int v = c.getY();
/* 588 */           int w = c.getZ();
/*     */           
/* 590 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3) {
/*     */             
/* 592 */             if (tabLabels[u][v][w] > 0) {
/*     */               
/* 594 */               if (tabLabels[m][j][n] == -3 || (tabLabels[m][j][n] == 0 && flag)) {
/*     */                 
/* 596 */                 tabLabels[m][j][n] = tabLabels[u][v][w]; continue;
/*     */               } 
/* 598 */               if (tabLabels[m][j][n] > 0 && tabLabels[m][j][n] != tabLabels[u][v][w]) {
/*     */                 
/* 600 */                 tabLabels[m][j][n] = 0;
/* 601 */                 flag = false;
/*     */               }  continue;
/*     */             } 
/* 604 */             if (tabLabels[u][v][w] == 0) {
/*     */               
/* 606 */               if (tabLabels[m][j][n] == -3) {
/*     */                 
/* 608 */                 tabLabels[m][j][n] = 0;
/* 609 */                 flag = true;
/*     */               }  continue;
/*     */             } 
/* 612 */             if (tabLabels[u][v][w] == -2) {
/*     */               
/* 614 */               tabLabels[u][v][w] = -3;
/* 615 */               fifo.addLast(c);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 623 */       for (voxelIndex = heightIndex2; voxelIndex < voxelList.size(); voxelIndex++, currentIndex++) {
/*     */         
/* 625 */         VoxelRecord voxelRecord = voxelList.get(voxelIndex);
/*     */         
/* 627 */         if (voxelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 630 */           heightIndex2 = voxelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 634 */         Cursor3D p = voxelRecord.getCursor();
/* 635 */         int m = p.getX();
/* 636 */         int j = p.getY();
/* 637 */         int n = p.getZ();
/*     */         
/* 639 */         if (tabLabels[m][j][n] == -2) {
/*     */           
/* 641 */           currentLabel++;
/* 642 */           fifo.addLast(p);
/* 643 */           tabLabels[m][j][n] = currentLabel;
/*     */           
/* 645 */           while (!fifo.isEmpty()) {
/*     */             
/* 647 */             Cursor3D p2 = fifo.poll();
/*     */ 
/*     */             
/* 650 */             neigh.setCursor(p2);
/*     */             
/* 652 */             for (Cursor3D c : neigh.getNeighbors()) {
/*     */               
/* 654 */               int u = c.getX();
/* 655 */               int v = c.getY();
/* 656 */               int w = c.getZ();
/*     */               
/* 658 */               if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3 && 
/* 659 */                 tabLabels[u][v][w] == -2) {
/*     */                 
/* 661 */                 fifo.addLast(c);
/* 662 */                 tabLabels[u][v][w] = currentLabel;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 669 */       IJ.showProgress(h / hMax);
/*     */     } 
/*     */ 
/*     */     
/* 673 */     IJ.showProgress(1.0D);
/*     */     
/* 675 */     long end = System.currentTimeMillis();
/* 676 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms");
/*     */ 
/*     */     
/* 679 */     ImageStack labelStack = new ImageStack(size1, size2);
/*     */     
/* 681 */     for (int k = 0; k < size3; k++) {
/*     */ 
/*     */       
/* 684 */       FloatProcessor fp = new FloatProcessor(size1, size2);
/* 685 */       for (int j = 0; j < size1; j++) {
/* 686 */         for (int m = 0; m < size2; m++) {
/*     */           
/* 688 */           if (tabLabels[j][m][k] == -1)
/* 689 */           { fp.setf(j, m, 0.0F); }
/*     */           else
/* 691 */           { fp.setf(j, m, tabLabels[j][m][k]); } 
/*     */         } 
/* 693 */       }  labelStack.addSlice((ImageProcessor)fp);
/*     */     } 
/*     */     
/* 696 */     ImagePlus ws = new ImagePlus("watershed", labelStack);
/* 697 */     ws.setCalibration(this.inputImage.getCalibration());
/* 698 */     return ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<VoxelRecord> extractVoxelValues(final ImageStack inputStack, final double hMin, final double hMax) {
/* 718 */     final int size1 = inputStack.getWidth();
/* 719 */     final int size2 = inputStack.getHeight();
/* 720 */     final int size3 = inputStack.getSize();
/*     */     
/* 722 */     final AtomicInteger ai = new AtomicInteger(0);
/* 723 */     final int n_cpus = Prefs.getThreads();
/*     */     
/* 725 */     final int dec = (int)Math.ceil(size3 / n_cpus);
/*     */     
/* 727 */     Thread[] threads = ThreadUtil.createThreadArray(n_cpus);
/*     */ 
/*     */     
/* 730 */     final ArrayList[] lists = new ArrayList[n_cpus];
/*     */     
/* 732 */     if (this.maskImage != null) {
/*     */       
/* 734 */       final ImageStack mask = this.maskImage.getImageStack();
/*     */       
/* 736 */       for (int i = 0; i < threads.length; i++) {
/*     */         
/* 738 */         lists[i] = new ArrayList();
/*     */         
/* 740 */         threads[i] = new Thread() {
/*     */             public void run() {
/* 742 */               for (int k = ai.getAndIncrement(); k < n_cpus; k = ai.getAndIncrement()) {
/*     */                 
/* 744 */                 int zmin = dec * k;
/* 745 */                 int zmax = dec * (k + 1);
/* 746 */                 if (zmin < 0)
/* 747 */                   zmin = 0; 
/* 748 */                 if (zmax > size3) {
/* 749 */                   zmax = size3;
/*     */                 }
/* 751 */                 for (int z = zmin; z < zmax; z++) {
/*     */                   
/* 753 */                   if (zmin == 0) {
/* 754 */                     IJ.showProgress(z + 1, zmax);
/*     */                   }
/* 756 */                   ImageProcessor ipMask = mask.getProcessor(z + 1);
/* 757 */                   ImageProcessor ipInput = inputStack.getProcessor(z + 1);
/*     */                   
/* 759 */                   for (int x = 0; x < size1; x++) {
/* 760 */                     for (int y = 0; y < size2; y++) {
/*     */                       
/* 762 */                       double h = ipInput.getf(x, y);
/* 763 */                       if (ipMask.getf(x, y) > 0.0F && h >= hMin && h <= hMax)
/*     */                       {
/* 765 */                         lists[k].add(new VoxelRecord(x, y, z, h));
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/* 774 */       ThreadUtil.startAndJoin(threads);
/*     */     }
/*     */     else {
/*     */       
/* 778 */       for (int i = 0; i < threads.length; i++) {
/*     */         
/* 780 */         lists[i] = new ArrayList();
/*     */         
/* 782 */         threads[i] = new Thread() {
/*     */             public void run() {
/* 784 */               for (int k = ai.getAndIncrement(); k < n_cpus; k = ai.getAndIncrement()) {
/*     */                 
/* 786 */                 int zmin = dec * k;
/* 787 */                 int zmax = dec * (k + 1);
/* 788 */                 if (zmin < 0)
/* 789 */                   zmin = 0; 
/* 790 */                 if (zmax > size3) {
/* 791 */                   zmax = size3;
/*     */                 }
/* 793 */                 for (int z = zmin; z < zmax; z++) {
/*     */                   
/* 795 */                   if (zmin == 0) {
/* 796 */                     IJ.showProgress(z + 1, zmax);
/*     */                   }
/* 798 */                   ImageProcessor ipInput = inputStack.getProcessor(z + 1);
/*     */                   
/* 800 */                   for (int x = 0; x < size1; x++) {
/* 801 */                     for (int y = 0; y < size2; y++) {
/*     */                       
/* 803 */                       double h = ipInput.getf(x, y);
/* 804 */                       if (h >= hMin && h <= hMax)
/* 805 */                         lists[k].add(new VoxelRecord(x, y, z, h)); 
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           };
/*     */       } 
/* 813 */       ThreadUtil.startAndJoin(threads);
/*     */     } 
/*     */     
/* 816 */     ArrayList<VoxelRecord> voxelList = lists[0];
/* 817 */     for (int ithread = 1; ithread < threads.length; ithread++) {
/* 818 */       voxelList.addAll(lists[ithread]);
/*     */     }
/* 820 */     IJ.showProgress(1.0D);
/*     */     
/* 822 */     return voxelList;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/WatershedTransform3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */