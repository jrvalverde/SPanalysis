/*     */ package inra.ijpb.watershed;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.data.Cursor2D;
/*     */ import inra.ijpb.data.Neighborhood2D;
/*     */ import inra.ijpb.data.Neighborhood2DC4;
/*     */ import inra.ijpb.data.Neighborhood2DC8;
/*     */ import inra.ijpb.data.PixelRecord;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WatershedTransform2D
/*     */ {
/*  71 */   ImageProcessor inputImage = null;
/*     */ 
/*     */   
/*  74 */   ImageProcessor maskImage = null;
/*     */ 
/*     */   
/*  77 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int MASK = -2;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int WSHED = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INIT = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INQUEUE = -3;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean verbose = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WatershedTransform2D(ImageProcessor input, ImageProcessor mask) {
/* 103 */     this.inputImage = input;
/* 104 */     this.maskImage = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WatershedTransform2D(ImageProcessor input, ImageProcessor mask, int connectivity) {
/* 119 */     this.inputImage = input;
/* 120 */     this.maskImage = mask;
/*     */     
/* 122 */     if (connectivity != 4 && connectivity != 8)
/*     */     {
/* 124 */       throw new IllegalArgumentException("Illegal connectivity value: it must be 4 or 8!");
/*     */     }
/*     */     
/* 127 */     this.connectivity = connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConnectivity() {
/* 135 */     return this.connectivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectivity(int conn) {
/* 143 */     if (conn == 4 || conn == 8) {
/* 144 */       this.connectivity = conn;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 152 */     this.verbose = verbose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor apply() {
/* 165 */     if (this.maskImage != null) {
/* 166 */       return applyWithMask();
/*     */     }
/* 168 */     return applyWithoutMask();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor apply(double hMin, double hMax) {
/* 187 */     if (this.maskImage != null) {
/* 188 */       return applyWithMask(hMin, hMax);
/*     */     }
/* 190 */     return applyWithoutMask(hMin, hMax);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor applyWithMask() {
/* 207 */     return applyWithMask(this.inputImage.getMin(), this.inputImage.getMax());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor applyWithoutMask() {
/* 220 */     return applyWithoutMask(this.inputImage.getMin(), this.inputImage.getMax());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor applyWithMask(double hMin, double hMax) {
/* 242 */     int size1 = this.inputImage.getWidth();
/* 243 */     int size2 = this.inputImage.getHeight();
/*     */ 
/*     */     
/* 246 */     int[][] tabLabels = new int[size1][size2];
/*     */ 
/*     */     
/* 249 */     for (int i = 0; i < size1; i++) {
/* 250 */       Arrays.fill(tabLabels[i], -1);
/*     */     }
/* 252 */     int currentLabel = 0;
/*     */     
/* 254 */     boolean flag = false;
/*     */ 
/*     */     
/* 257 */     IJ.showStatus("Extracting pixel values...");
/* 258 */     if (this.verbose) IJ.log("  Extracting pixel values (h_min = " + hMin + ", h_max = " + hMax + ")..."); 
/* 259 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 262 */     ArrayList<PixelRecord> pixelList = extractPixelValues(this.inputImage, hMin, hMax);
/*     */     
/* 264 */     long t1 = System.currentTimeMillis();
/* 265 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/* 266 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/* 267 */     IJ.showStatus("Sorting pixels by value...");
/* 268 */     Collections.sort(pixelList);
/* 269 */     long t2 = System.currentTimeMillis();
/* 270 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*     */     
/* 272 */     IJ.log("  Flooding...");
/* 273 */     IJ.showStatus("Flooding...");
/* 274 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 277 */     Neighborhood2D neigh = (this.connectivity == 4) ? 
/* 278 */       (Neighborhood2D)new Neighborhood2DC4() : (Neighborhood2D)new Neighborhood2DC8();
/*     */     
/* 280 */     LinkedList<Cursor2D> fifo = new LinkedList<Cursor2D>();
/*     */ 
/*     */     
/* 283 */     int currentIndex = 0;
/*     */     
/* 285 */     int heightIndex1 = currentIndex;
/* 286 */     int heightIndex2 = currentIndex;
/*     */ 
/*     */     
/* 289 */     while (currentIndex < pixelList.size()) {
/*     */       
/* 291 */       double h = ((PixelRecord)pixelList.get(currentIndex)).getValue();
/*     */       int pixelIndex;
/* 293 */       for (pixelIndex = heightIndex1; pixelIndex < pixelList.size(); pixelIndex++) {
/*     */         
/* 295 */         PixelRecord pixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 297 */         if (pixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 300 */           heightIndex1 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 304 */         Cursor2D p = pixelRecord.getCursor();
/* 305 */         int k = p.getX();
/* 306 */         int m = p.getY();
/*     */ 
/*     */         
/* 309 */         tabLabels[k][m] = -2;
/*     */ 
/*     */         
/* 312 */         neigh.setCursor(p);
/* 313 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */           
/* 315 */           int u = c.getX();
/* 316 */           int v = c.getY();
/*     */ 
/*     */           
/* 319 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 320 */             tabLabels[u][v] >= 0 && 
/* 321 */             this.maskImage.getf(u, v) > 0.0F) {
/*     */ 
/*     */             
/* 324 */             fifo.addLast(p);
/* 325 */             tabLabels[k][m] = -3;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 331 */       while (!fifo.isEmpty()) {
/*     */ 
/*     */         
/* 334 */         Cursor2D p = fifo.poll();
/* 335 */         int k = p.getX();
/* 336 */         int m = p.getY();
/*     */ 
/*     */         
/* 339 */         neigh.setCursor(p);
/*     */         
/* 341 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */ 
/*     */           
/* 344 */           int u = c.getX();
/* 345 */           int v = c.getY();
/*     */           
/* 347 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && this.maskImage.getf(u, v) > 0.0F) {
/*     */             
/* 349 */             if (tabLabels[u][v] > 0) {
/*     */               
/* 351 */               if (tabLabels[k][m] == -3 || (tabLabels[k][m] == 0 && flag)) {
/*     */                 
/* 353 */                 tabLabels[k][m] = tabLabels[u][v]; continue;
/*     */               } 
/* 355 */               if (tabLabels[k][m] > 0 && tabLabels[k][m] != tabLabels[u][v]) {
/*     */                 
/* 357 */                 tabLabels[k][m] = 0;
/* 358 */                 flag = false;
/*     */               }  continue;
/*     */             } 
/* 361 */             if (tabLabels[u][v] == 0) {
/*     */               
/* 363 */               if (tabLabels[k][m] == -3) {
/*     */                 
/* 365 */                 tabLabels[k][m] = 0;
/* 366 */                 flag = true;
/*     */               }  continue;
/*     */             } 
/* 369 */             if (tabLabels[u][v] == -2) {
/*     */               
/* 371 */               tabLabels[u][v] = -3;
/* 372 */               fifo.addLast(c);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 380 */       for (pixelIndex = heightIndex2; pixelIndex < pixelList.size(); pixelIndex++, currentIndex++) {
/*     */         
/* 382 */         PixelRecord pixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 384 */         if (pixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 387 */           heightIndex2 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 391 */         Cursor2D p = pixelRecord.getCursor();
/* 392 */         int k = p.getX();
/* 393 */         int m = p.getY();
/*     */         
/* 395 */         if (tabLabels[k][m] == -2) {
/*     */           
/* 397 */           currentLabel++;
/* 398 */           fifo.addLast(p);
/* 399 */           tabLabels[k][m] = currentLabel;
/*     */           
/* 401 */           while (!fifo.isEmpty()) {
/*     */             
/* 403 */             Cursor2D p2 = fifo.poll();
/*     */ 
/*     */             
/* 406 */             neigh.setCursor(p2);
/*     */             
/* 408 */             for (Cursor2D c : neigh.getNeighbors()) {
/*     */               
/* 410 */               int u = c.getX();
/* 411 */               int v = c.getY();
/*     */               
/* 413 */               if (u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 414 */                 tabLabels[u][v] == -2 && 
/* 415 */                 this.maskImage.getf(u, v) > 0.0F) {
/*     */                 
/* 417 */                 fifo.addLast(c);
/* 418 */                 tabLabels[u][v] = currentLabel;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 425 */       IJ.showProgress(h / hMax);
/*     */     } 
/*     */ 
/*     */     
/* 429 */     IJ.showProgress(1.0D);
/*     */     
/* 431 */     long end = System.currentTimeMillis();
/* 432 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms");
/*     */ 
/*     */ 
/*     */     
/* 436 */     FloatProcessor fp = new FloatProcessor(size1, size2);
/* 437 */     for (int j = 0; j < size1; j++) {
/* 438 */       for (int k = 0; k < size2; k++) {
/*     */         
/* 440 */         if (tabLabels[j][k] == -1) {
/* 441 */           fp.setf(j, k, 0.0F);
/*     */         } else {
/* 443 */           fp.setf(j, k, tabLabels[j][k]);
/*     */         } 
/*     */       } 
/* 446 */     }  return (ImageProcessor)fp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor applyWithoutMask(double hMin, double hMax) {
/* 465 */     int size1 = this.inputImage.getWidth();
/* 466 */     int size2 = this.inputImage.getHeight();
/*     */ 
/*     */     
/* 469 */     int[][] tabLabels = new int[size1][size2];
/*     */ 
/*     */     
/* 472 */     for (int i = 0; i < size1; i++) {
/* 473 */       Arrays.fill(tabLabels[i], -1);
/*     */     }
/* 475 */     int currentLabel = 0;
/*     */     
/* 477 */     boolean flag = false;
/*     */ 
/*     */     
/* 480 */     IJ.showStatus("Extracting pixel values...");
/* 481 */     if (this.verbose) IJ.log("  Extracting pixel values (h_min = " + hMin + ", h_max = " + hMax + ")..."); 
/* 482 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 485 */     ArrayList<PixelRecord> pixelList = extractPixelValues(this.inputImage, hMin, hMax);
/*     */     
/* 487 */     long t1 = System.currentTimeMillis();
/* 488 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/* 489 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/* 490 */     IJ.showStatus("Sorting pixels by value...");
/* 491 */     Collections.sort(pixelList);
/* 492 */     long t2 = System.currentTimeMillis();
/* 493 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*     */     
/* 495 */     IJ.log("  Flooding...");
/* 496 */     IJ.showStatus("Flooding...");
/* 497 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 500 */     Neighborhood2D neigh = (this.connectivity == 4) ? 
/* 501 */       (Neighborhood2D)new Neighborhood2DC4() : (Neighborhood2D)new Neighborhood2DC8();
/*     */     
/* 503 */     LinkedList<Cursor2D> fifo = new LinkedList<Cursor2D>();
/*     */ 
/*     */     
/* 506 */     int currentIndex = 0;
/*     */     
/* 508 */     int heightIndex1 = currentIndex;
/* 509 */     int heightIndex2 = currentIndex;
/*     */ 
/*     */     
/* 512 */     while (currentIndex < pixelList.size()) {
/*     */       
/* 514 */       double h = ((PixelRecord)pixelList.get(currentIndex)).getValue();
/*     */       int pixelIndex;
/* 516 */       for (pixelIndex = heightIndex1; pixelIndex < pixelList.size(); pixelIndex++) {
/*     */         
/* 518 */         PixelRecord pixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 520 */         if (pixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 523 */           heightIndex1 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 527 */         Cursor2D p = pixelRecord.getCursor();
/* 528 */         int k = p.getX();
/* 529 */         int m = p.getY();
/*     */ 
/*     */         
/* 532 */         tabLabels[k][m] = -2;
/*     */ 
/*     */         
/* 535 */         neigh.setCursor(p);
/* 536 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */           
/* 538 */           int u = c.getX();
/* 539 */           int v = c.getY();
/*     */ 
/*     */           
/* 542 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 543 */             tabLabels[u][v] >= 0) {
/*     */ 
/*     */             
/* 546 */             fifo.addLast(p);
/* 547 */             tabLabels[k][m] = -3;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 553 */       while (!fifo.isEmpty()) {
/*     */ 
/*     */         
/* 556 */         Cursor2D p = fifo.poll();
/* 557 */         int k = p.getX();
/* 558 */         int m = p.getY();
/*     */ 
/*     */         
/* 561 */         neigh.setCursor(p);
/*     */         
/* 563 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */ 
/*     */           
/* 566 */           int u = c.getX();
/* 567 */           int v = c.getY();
/*     */           
/* 569 */           if (u >= 0 && u < size1 && v >= 0 && v < size2) {
/*     */             
/* 571 */             if (tabLabels[u][v] > 0) {
/*     */               
/* 573 */               if (tabLabels[k][m] == -3 || (tabLabels[k][m] == 0 && flag)) {
/*     */                 
/* 575 */                 tabLabels[k][m] = tabLabels[u][v]; continue;
/*     */               } 
/* 577 */               if (tabLabels[k][m] > 0 && tabLabels[k][m] != tabLabels[u][v]) {
/*     */                 
/* 579 */                 tabLabels[k][m] = 0;
/* 580 */                 flag = false;
/*     */               }  continue;
/*     */             } 
/* 583 */             if (tabLabels[u][v] == 0) {
/*     */               
/* 585 */               if (tabLabels[k][m] == -3) {
/*     */                 
/* 587 */                 tabLabels[k][m] = 0;
/* 588 */                 flag = true;
/*     */               }  continue;
/*     */             } 
/* 591 */             if (tabLabels[u][v] == -2) {
/*     */               
/* 593 */               tabLabels[u][v] = -3;
/* 594 */               fifo.addLast(c);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 602 */       for (pixelIndex = heightIndex2; pixelIndex < pixelList.size(); pixelIndex++, currentIndex++) {
/*     */         
/* 604 */         PixelRecord pixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 606 */         if (pixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 609 */           heightIndex2 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 613 */         Cursor2D p = pixelRecord.getCursor();
/* 614 */         int k = p.getX();
/* 615 */         int m = p.getY();
/*     */         
/* 617 */         if (tabLabels[k][m] == -2) {
/*     */           
/* 619 */           currentLabel++;
/* 620 */           fifo.addLast(p);
/* 621 */           tabLabels[k][m] = currentLabel;
/*     */           
/* 623 */           while (!fifo.isEmpty()) {
/*     */             
/* 625 */             Cursor2D p2 = fifo.poll();
/*     */ 
/*     */             
/* 628 */             neigh.setCursor(p2);
/*     */             
/* 630 */             for (Cursor2D c : neigh.getNeighbors()) {
/*     */               
/* 632 */               int u = c.getX();
/* 633 */               int v = c.getY();
/*     */               
/* 635 */               if (u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 636 */                 tabLabels[u][v] == -2) {
/*     */                 
/* 638 */                 fifo.addLast(c);
/* 639 */                 tabLabels[u][v] = currentLabel;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 646 */       IJ.showProgress(h / hMax);
/*     */     } 
/*     */ 
/*     */     
/* 650 */     IJ.showProgress(1.0D);
/*     */     
/* 652 */     long end = System.currentTimeMillis();
/* 653 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms");
/*     */ 
/*     */ 
/*     */     
/* 657 */     FloatProcessor fp = new FloatProcessor(size1, size2);
/* 658 */     for (int j = 0; j < size1; j++) {
/* 659 */       for (int k = 0; k < size2; k++) {
/*     */         
/* 661 */         if (tabLabels[j][k] == -1) {
/* 662 */           fp.setf(j, k, 0.0F);
/*     */         } else {
/* 664 */           fp.setf(j, k, tabLabels[j][k]);
/*     */         } 
/*     */       } 
/* 667 */     }  return (ImageProcessor)fp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<PixelRecord> extractPixelValues(ImageProcessor inputImage, double hMin, double hMax) {
/* 688 */     int size1 = inputImage.getWidth();
/* 689 */     int size2 = inputImage.getHeight();
/*     */     
/* 691 */     ArrayList<PixelRecord> list = new ArrayList<PixelRecord>();
/*     */     
/* 693 */     if (this.maskImage != null) {
/*     */ 
/*     */       
/* 696 */       for (int x = 0; x < size1; x++) {
/* 697 */         for (int y = 0; y < size2; y++)
/*     */         {
/* 699 */           double h = inputImage.getf(x, y);
/* 700 */           if (this.maskImage.getf(x, y) > 0.0F && h >= hMin && h <= hMax)
/*     */           {
/* 702 */             list.add(new PixelRecord(x, y, h));
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 709 */       for (int x = 0; x < size1; x++) {
/* 710 */         for (int y = 0; y < size2; y++) {
/*     */           
/* 712 */           double h = inputImage.getf(x, y);
/* 713 */           if (h >= hMin && h <= hMax) {
/* 714 */             list.add(new PixelRecord(x, y, h));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 719 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus getAnimation(double hMin, double hMax) {
/* 739 */     int size1 = this.inputImage.getWidth();
/* 740 */     int size2 = this.inputImage.getHeight();
/*     */     
/* 742 */     ImageStack animation = new ImageStack(size1, size2);
/*     */     
/* 744 */     boolean useMask = (this.maskImage != null);
/*     */ 
/*     */     
/* 747 */     int[][] tabLabels = new int[size1][size2];
/*     */ 
/*     */     
/* 750 */     for (int i = 0; i < size1; i++) {
/* 751 */       Arrays.fill(tabLabels[i], -1);
/*     */     }
/* 753 */     int currentLabel = 0;
/*     */     
/* 755 */     boolean flag = false;
/*     */ 
/*     */     
/* 758 */     IJ.showStatus("Extracting pixel values...");
/* 759 */     if (this.verbose) IJ.log("  Extracting pixel values (h_min = " + hMin + ", h_max = " + hMax + ")..."); 
/* 760 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 763 */     ArrayList<PixelRecord> pixelList = extractPixelValues(this.inputImage, hMin, hMax);
/*     */     
/* 765 */     long t1 = System.currentTimeMillis();
/* 766 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/* 767 */     if (this.verbose) IJ.log("  Sorting pixels by value..."); 
/* 768 */     IJ.showStatus("Sorting pixels by value...");
/* 769 */     Collections.sort(pixelList);
/* 770 */     long t2 = System.currentTimeMillis();
/* 771 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*     */     
/* 773 */     IJ.log("  Flooding...");
/* 774 */     IJ.showStatus("Flooding...");
/* 775 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 778 */     Neighborhood2D neigh = (this.connectivity == 4) ? 
/* 779 */       (Neighborhood2D)new Neighborhood2DC4() : (Neighborhood2D)new Neighborhood2DC8();
/*     */     
/* 781 */     LinkedList<Cursor2D> fifo = new LinkedList<Cursor2D>();
/*     */ 
/*     */     
/* 784 */     double h = hMin;
/*     */ 
/*     */     
/* 787 */     int currentIndex = 0;
/* 788 */     while (h < hMin) {
/*     */       
/* 790 */       h = ((PixelRecord)pixelList.get(currentIndex)).getValue();
/* 791 */       currentIndex++;
/*     */     } 
/*     */     
/* 794 */     int heightIndex1 = currentIndex;
/* 795 */     int heightIndex2 = currentIndex;
/*     */ 
/*     */     
/* 798 */     while (currentIndex < pixelList.size() && h <= hMax) {
/*     */       
/* 800 */       h = ((PixelRecord)pixelList.get(currentIndex)).getValue();
/*     */       int pixelIndex;
/* 802 */       for (pixelIndex = heightIndex1; pixelIndex < pixelList.size(); pixelIndex++) {
/*     */         
/* 804 */         PixelRecord pixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 806 */         if (pixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 809 */           heightIndex1 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 813 */         Cursor2D p = pixelRecord.getCursor();
/* 814 */         int k = p.getX();
/* 815 */         int j = p.getY();
/*     */ 
/*     */         
/* 818 */         tabLabels[k][j] = -2;
/*     */ 
/*     */         
/* 821 */         neigh.setCursor(p);
/* 822 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */           
/* 824 */           int u = c.getX();
/* 825 */           int v = c.getY();
/*     */ 
/*     */           
/* 828 */           if ((!useMask || this.maskImage.getf(u, v) > 0.0F) && 
/* 829 */             u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 830 */             tabLabels[u][v] >= 0) {
/*     */             
/* 832 */             fifo.addLast(p);
/* 833 */             tabLabels[k][j] = -3;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 839 */       while (!fifo.isEmpty()) {
/*     */ 
/*     */         
/* 842 */         Cursor2D p = fifo.poll();
/* 843 */         int k = p.getX();
/* 844 */         int j = p.getY();
/*     */ 
/*     */         
/* 847 */         neigh.setCursor(p);
/*     */         
/* 849 */         for (Cursor2D c : neigh.getNeighbors()) {
/*     */ 
/*     */           
/* 852 */           int u = c.getX();
/* 853 */           int v = c.getY();
/*     */           
/* 855 */           if ((!useMask || this.maskImage.getf(u, v) > 0.0F) && 
/* 856 */             u >= 0 && u < size1 && v >= 0 && v < size2) {
/*     */             
/* 858 */             if (tabLabels[u][v] > 0) {
/*     */               
/* 860 */               if (tabLabels[k][j] == -3 || (tabLabels[k][j] == 0 && flag)) {
/*     */                 
/* 862 */                 tabLabels[k][j] = tabLabels[u][v]; continue;
/*     */               } 
/* 864 */               if (tabLabels[k][j] > 0 && tabLabels[k][j] != tabLabels[u][v]) {
/*     */                 
/* 866 */                 tabLabels[k][j] = 0;
/* 867 */                 flag = false;
/*     */               }  continue;
/*     */             } 
/* 870 */             if (tabLabels[u][v] == 0) {
/*     */               
/* 872 */               if (tabLabels[k][j] == -3) {
/*     */                 
/* 874 */                 tabLabels[k][j] = 0;
/* 875 */                 flag = true;
/*     */               }  continue;
/*     */             } 
/* 878 */             if (tabLabels[u][v] == -2) {
/*     */               
/* 880 */               tabLabels[u][v] = -3;
/* 881 */               fifo.addLast(c);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 889 */       for (pixelIndex = heightIndex2; pixelIndex < pixelList.size(); pixelIndex++, currentIndex++) {
/*     */         
/* 891 */         PixelRecord PixelRecord = pixelList.get(pixelIndex);
/*     */         
/* 893 */         if (PixelRecord.getValue() != h) {
/*     */ 
/*     */           
/* 896 */           heightIndex2 = pixelIndex;
/*     */           
/*     */           break;
/*     */         } 
/* 900 */         Cursor2D p = PixelRecord.getCursor();
/* 901 */         int k = p.getX();
/* 902 */         int j = p.getY();
/*     */         
/* 904 */         if (tabLabels[k][j] == -2) {
/*     */           
/* 906 */           currentLabel++;
/* 907 */           fifo.addLast(p);
/* 908 */           tabLabels[k][j] = currentLabel;
/*     */           
/* 910 */           while (!fifo.isEmpty()) {
/*     */             
/* 912 */             Cursor2D p2 = fifo.poll();
/*     */ 
/*     */             
/* 915 */             neigh.setCursor(p2);
/*     */             
/* 917 */             for (Cursor2D c : neigh.getNeighbors()) {
/*     */               
/* 919 */               int u = c.getX();
/* 920 */               int v = c.getY();
/* 921 */               if ((!useMask || this.maskImage.getf(u, v) > 0.0F) && 
/* 922 */                 u >= 0 && u < size1 && v >= 0 && v < size2 && 
/* 923 */                 tabLabels[u][v] == -2) {
/*     */                 
/* 925 */                 fifo.addLast(c);
/* 926 */                 tabLabels[u][v] = currentLabel;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 935 */       animation.addSlice("h = " + h, (ImageProcessor)new FloatProcessor(tabLabels));
/*     */       
/* 937 */       IJ.showProgress(h / hMax);
/*     */     } 
/*     */ 
/*     */     
/* 941 */     IJ.showProgress(1.0D);
/*     */     
/* 943 */     long end = System.currentTimeMillis();
/* 944 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms");
/*     */     
/* 946 */     ImagePlus result = new ImagePlus("Watershed flooding", animation);
/* 947 */     Images3D.optimizeDisplayRange(result);
/* 948 */     return result;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/WatershedTransform2D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */