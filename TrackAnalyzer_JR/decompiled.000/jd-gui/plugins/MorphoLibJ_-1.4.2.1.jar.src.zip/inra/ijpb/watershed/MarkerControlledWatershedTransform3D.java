/*      */ package inra.ijpb.watershed;
/*      */ 
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.Prefs;
/*      */ import ij.process.ImageProcessor;
/*      */ import ij.util.ThreadUtil;
/*      */ import inra.ijpb.data.Cursor3D;
/*      */ import inra.ijpb.data.Neighborhood3D;
/*      */ import inra.ijpb.data.Neighborhood3DC26;
/*      */ import inra.ijpb.data.Neighborhood3DC6;
/*      */ import inra.ijpb.data.VoxelRecord;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.PriorityQueue;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MarkerControlledWatershedTransform3D
/*      */   extends WatershedTransform3D
/*      */ {
/*   56 */   ImagePlus markerImage = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerControlledWatershedTransform3D(ImagePlus input, ImagePlus marker, ImagePlus mask) {
/*   70 */     super(input, mask);
/*   71 */     this.markerImage = marker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerControlledWatershedTransform3D(ImagePlus input, ImagePlus marker, ImagePlus mask, int connectivity) {
/*   88 */     super(input, mask, connectivity);
/*   89 */     this.markerImage = marker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImagePlus applyWithSortedList() {
/*  107 */     ImageStack inputStack = this.inputImage.getStack();
/*  108 */     int size1 = inputStack.getWidth();
/*  109 */     int size2 = inputStack.getHeight();
/*  110 */     int size3 = inputStack.getSize();
/*      */     
/*  112 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight() || 
/*  113 */       size3 != this.markerImage.getStackSize()) {
/*  114 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  118 */     if (this.connectivity != 6 && this.connectivity != 26) {
/*  119 */       throw new RuntimeException(
/*  120 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  121 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  125 */     LinkedList<VoxelRecord> voxelList = null;
/*      */     
/*  127 */     int[][][] tabLabels = new int[size1][size2][size3];
/*      */ 
/*      */     
/*  130 */     IJ.showStatus("Extracting voxel values...");
/*  131 */     if (this.verbose) IJ.log("  Extracting voxel values..."); 
/*  132 */     long t0 = System.currentTimeMillis();
/*      */     
/*  134 */     voxelList = extractVoxelValues(inputStack, this.markerImage.getStack(), tabLabels);
/*  135 */     if (voxelList == null) {
/*  136 */       return null;
/*      */     }
/*  138 */     long t1 = System.currentTimeMillis();
/*  139 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  140 */     if (this.verbose) IJ.log("  Sorting voxels by value..."); 
/*  141 */     IJ.showStatus("Sorting voxels by value...");
/*  142 */     Collections.sort(voxelList);
/*  143 */     long t2 = System.currentTimeMillis();
/*  144 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  147 */     boolean found = false;
/*      */     
/*  149 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  152 */     Cursor3D cursor = new Cursor3D(0, 0, 0);
/*      */ 
/*      */     
/*  155 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/*  156 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*      */     
/*  158 */     boolean change = true;
/*  159 */     while (!voxelList.isEmpty() && change) {
/*      */       
/*  161 */       if (Thread.currentThread().isInterrupted()) {
/*  162 */         return null;
/*      */       }
/*  164 */       change = false;
/*  165 */       int count = voxelList.size();
/*  166 */       if (this.verbose) IJ.log("  Flooding " + count + " voxels..."); 
/*  167 */       IJ.showStatus("Flooding " + count + " voxels...");
/*      */       
/*  169 */       for (int p = 0; p < count; p++) {
/*      */         
/*  171 */         IJ.showProgress(p, count);
/*  172 */         VoxelRecord voxelRecord = voxelList.removeFirst();
/*  173 */         Cursor3D p2 = voxelRecord.getCursor();
/*  174 */         int m = p2.getX();
/*  175 */         int j = p2.getY();
/*  176 */         int k = p2.getZ();
/*      */ 
/*      */         
/*  179 */         if (tabLabels[m][j][k] == 0) {
/*      */           
/*  181 */           found = false;
/*  182 */           double voxelValue = voxelRecord.getValue();
/*      */ 
/*      */           
/*  185 */           cursor.set(m, j, k);
/*  186 */           neigh.setCursor(cursor);
/*      */           
/*  188 */           for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */             
/*  192 */             int u = c.getX();
/*  193 */             int v = c.getY();
/*  194 */             int w = c.getZ();
/*      */             
/*  196 */             if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3)
/*      */             {
/*  198 */               if (tabLabels[u][v][w] != 0 && inputStack.getVoxel(u, v, w) <= voxelValue) {
/*      */                 
/*  200 */                 tabLabels[m][j][k] = tabLabels[u][v][w];
/*  201 */                 voxelValue = inputStack.getVoxel(u, v, w);
/*  202 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  207 */           if (!found) {
/*  208 */             voxelList.addLast(voxelRecord);
/*      */           } else {
/*  210 */             change = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  215 */     long end = System.currentTimeMillis();
/*  216 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  217 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  220 */     ImageStack labelStack = this.markerImage.duplicate().getStack();
/*      */     
/*  222 */     for (int i = 0; i < size1; i++) {
/*  223 */       for (int j = 0; j < size2; j++) {
/*  224 */         for (int k = 0; k < size3; k++)
/*  225 */           labelStack.setVoxel(i, j, k, tabLabels[i][j][k]); 
/*      */       } 
/*  227 */     }  String title = this.inputImage.getTitle();
/*  228 */     String ext = "";
/*  229 */     int index = title.lastIndexOf(".");
/*  230 */     if (index != -1) {
/*      */       
/*  232 */       ext = title.substring(index);
/*  233 */       title = title.substring(0, index);
/*      */     } 
/*      */     
/*  236 */     ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, labelStack);
/*  237 */     ws.setCalibration(this.inputImage.getCalibration());
/*  238 */     return ws;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ImagePlus applyWithSortedListAndDams() {
/*  257 */     ImageStack inputStack = this.inputImage.getStack();
/*  258 */     int size1 = inputStack.getWidth();
/*  259 */     int size2 = inputStack.getHeight();
/*  260 */     int size3 = inputStack.getSize();
/*      */     
/*  262 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight() || 
/*  263 */       size3 != this.markerImage.getStackSize()) {
/*  264 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  268 */     if (this.connectivity != 6 && this.connectivity != 26) {
/*  269 */       throw new RuntimeException(
/*  270 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  271 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  275 */     int[][][] tabLabels = new int[size1][size2][size3];
/*      */ 
/*      */     
/*  278 */     IJ.showStatus("Extracting voxel values...");
/*  279 */     if (this.verbose) IJ.log("  Extracting voxel values..."); 
/*  280 */     long t0 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */     
/*  284 */     LinkedList<VoxelRecord> voxelList = extractVoxelValues(inputStack, this.markerImage.getStack(), tabLabels);
/*  285 */     if (voxelList == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     long t1 = System.currentTimeMillis();
/*  289 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms."); 
/*  290 */     if (this.verbose) IJ.log("  Sorting voxels by value..."); 
/*  291 */     IJ.showStatus("Sorting voxels by value...");
/*  292 */     Collections.sort(voxelList);
/*  293 */     long t2 = System.currentTimeMillis();
/*  294 */     if (this.verbose) IJ.log("  Sorting took " + (t2 - t1) + " ms.");
/*      */ 
/*      */     
/*  297 */     boolean found = false;
/*      */     
/*  299 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  302 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/*  303 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*      */ 
/*      */     
/*  306 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  308 */     boolean change = true;
/*  309 */     while (!voxelList.isEmpty() && change) {
/*      */       
/*  311 */       if (Thread.currentThread().isInterrupted()) {
/*  312 */         return null;
/*      */       }
/*  314 */       change = false;
/*  315 */       int count = voxelList.size();
/*  316 */       if (this.verbose) IJ.log("  Flooding " + count + " voxels..."); 
/*  317 */       IJ.showStatus("Flooding " + count + " voxels...");
/*      */       
/*  319 */       for (int p = 0; p < count; p++) {
/*      */         
/*  321 */         IJ.showProgress(p, count);
/*  322 */         VoxelRecord voxelRecord = voxelList.removeFirst();
/*  323 */         Cursor3D p2 = voxelRecord.getCursor();
/*  324 */         int m = p2.getX();
/*  325 */         int j = p2.getY();
/*  326 */         int k = p2.getZ();
/*      */ 
/*      */         
/*  329 */         if (tabLabels[m][j][k] == 0) {
/*      */           
/*  331 */           found = false;
/*      */ 
/*      */           
/*  334 */           neigh.setCursor(p2);
/*      */ 
/*      */           
/*  337 */           neighborLabels.clear();
/*      */           
/*  339 */           for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */             
/*  342 */             int u = c.getX();
/*  343 */             int v = c.getY();
/*  344 */             int w = c.getZ();
/*      */             
/*  346 */             if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3)
/*      */             {
/*  348 */               if (tabLabels[u][v][w] > 0) {
/*      */ 
/*      */                 
/*  351 */                 if (!neighborLabels.contains(Integer.valueOf(tabLabels[u][v][w])))
/*  352 */                   neighborLabels.add(Integer.valueOf(tabLabels[u][v][w])); 
/*  353 */                 found = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  358 */           if (!found) {
/*  359 */             voxelList.addLast(voxelRecord);
/*      */           } else {
/*      */             
/*  362 */             change = true;
/*      */ 
/*      */ 
/*      */             
/*  366 */             if (neighborLabels.size() == 1) {
/*  367 */               tabLabels[m][j][k] = ((Integer)neighborLabels.get(0)).intValue();
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  373 */     long end = System.currentTimeMillis();
/*  374 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  375 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  378 */     ImageStack labelStack = this.markerImage.duplicate().getStack();
/*      */     
/*  380 */     for (int i = 0; i < size1; i++) {
/*  381 */       for (int j = 0; j < size2; j++) {
/*  382 */         for (int k = 0; k < size3; k++)
/*  383 */           labelStack.setVoxel(i, j, k, tabLabels[i][j][k]); 
/*      */       } 
/*  385 */     }  String title = this.inputImage.getTitle();
/*  386 */     String ext = "";
/*  387 */     int index = title.lastIndexOf(".");
/*  388 */     if (index != -1) {
/*      */       
/*  390 */       ext = title.substring(index);
/*  391 */       title = title.substring(0, index);
/*      */     } 
/*      */     
/*  394 */     ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, labelStack);
/*  395 */     ws.setCalibration(this.inputImage.getCalibration());
/*  396 */     return ws;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImagePlus applyWithPriorityQueue() {
/*  409 */     ImageStack inputStack = this.inputImage.getStack();
/*  410 */     int size1 = inputStack.getWidth();
/*  411 */     int size2 = inputStack.getHeight();
/*  412 */     int size3 = inputStack.getSize();
/*      */     
/*  414 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight() || 
/*  415 */       size3 != this.markerImage.getStackSize())
/*      */     {
/*  417 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  421 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  423 */       throw new RuntimeException(
/*  424 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  425 */           this.connectivity);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  430 */     PriorityQueue<VoxelRecord> voxelList = null;
/*      */     
/*  432 */     int[][][] tabLabels = new int[size1][size2][size3];
/*      */     
/*  434 */     if (this.maskImage == null) {
/*      */       
/*  436 */       for (int j = 0; j < size1; j++) {
/*  437 */         for (int k = 0; k < size2; k++) {
/*  438 */           Arrays.fill(tabLabels[j][k], -1);
/*      */         }
/*      */       } 
/*      */     } else {
/*  442 */       for (int j = 0; j < size1; j++) {
/*  443 */         for (int k = 0; k < size2; k++) {
/*  444 */           for (int m = 0; m < size3; m++)
/*  445 */             tabLabels[j][k][m] = -1; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  449 */     IJ.showStatus("Extracting voxel values...");
/*  450 */     if (this.verbose) IJ.log("  Extracting voxel values..."); 
/*  451 */     long t0 = System.currentTimeMillis();
/*      */     
/*  453 */     voxelList = extractVoxelValuesPriorityQueue(
/*  454 */         inputStack, this.markerImage.getStack(), tabLabels);
/*  455 */     if (voxelList == null) {
/*  456 */       return null;
/*      */     }
/*  458 */     long t1 = System.currentTimeMillis();
/*  459 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/*  462 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  465 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/*  466 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*      */     
/*  468 */     int count = voxelList.size();
/*  469 */     if (this.verbose) IJ.log("  Flooding from " + count + " voxels..."); 
/*  470 */     IJ.showStatus("Flooding from " + count + " voxels...");
/*      */     
/*  472 */     double[] extent = Images3D.findMinAndMax(this.inputImage);
/*  473 */     double maxValue = extent[1];
/*      */ 
/*      */     
/*  476 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  478 */     ArrayList<VoxelRecord> neighborVoxels = 
/*  479 */       new ArrayList<VoxelRecord>();
/*      */ 
/*      */     
/*  482 */     if (this.maskImage != null) {
/*      */       
/*  484 */       ImageStack maskStack = this.maskImage.getStack();
/*      */       
/*  486 */       while (!voxelList.isEmpty()) {
/*      */         
/*  488 */         if (Thread.currentThread().isInterrupted()) {
/*  489 */           return null;
/*      */         }
/*  491 */         VoxelRecord voxelRecord = voxelList.poll();
/*      */         
/*  493 */         IJ.showProgress((voxelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  495 */         Cursor3D p = voxelRecord.getCursor();
/*  496 */         int m = p.getX();
/*  497 */         int j = p.getY();
/*  498 */         int k = p.getZ();
/*      */ 
/*      */         
/*  501 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  504 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  507 */         neighborVoxels.clear();
/*      */ 
/*      */         
/*  510 */         for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */           
/*  513 */           int u = c.getX();
/*  514 */           int v = c.getY();
/*  515 */           int w = c.getZ();
/*      */           
/*  517 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3) {
/*      */ 
/*      */ 
/*      */             
/*  521 */             if (tabLabels[u][v][w] == -1 && 
/*  522 */               maskStack.getVoxel(u, v, w) > 0.0D) {
/*      */               
/*  524 */               neighborVoxels.add(
/*  525 */                   new VoxelRecord(
/*  526 */                     c, inputStack.getVoxel(u, v, w))); continue;
/*      */             } 
/*  528 */             if (tabLabels[u][v][w] > 0 && 
/*  529 */               !neighborLabels.contains(
/*  530 */                 Integer.valueOf(tabLabels[u][v][w])))
/*      */             {
/*      */               
/*  533 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v][w]));
/*      */             }
/*      */           } 
/*      */         } 
/*  537 */         if (neighborLabels.size() > 0) {
/*      */           
/*  539 */           tabLabels[m][j][k] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/*  541 */           for (VoxelRecord v : neighborVoxels)
/*      */           {
/*  543 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()][v.getCursor().getZ()] = -3;
/*  544 */             voxelList.add(v);
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/*  551 */       while (!voxelList.isEmpty()) {
/*      */         
/*  553 */         if (Thread.currentThread().isInterrupted()) {
/*  554 */           return null;
/*      */         }
/*  556 */         VoxelRecord voxelRecord = voxelList.poll();
/*      */         
/*  558 */         IJ.showProgress((voxelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  560 */         Cursor3D p = voxelRecord.getCursor();
/*  561 */         int m = p.getX();
/*  562 */         int j = p.getY();
/*  563 */         int k = p.getZ();
/*      */ 
/*      */         
/*  566 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  569 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  572 */         neighborVoxels.clear();
/*      */ 
/*      */         
/*  575 */         for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  579 */           int u = c.getX();
/*  580 */           int v = c.getY();
/*  581 */           int w = c.getZ();
/*  582 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3) {
/*      */ 
/*      */             
/*  585 */             if (tabLabels[u][v][w] == -1) {
/*      */               
/*  587 */               neighborVoxels.add(
/*  588 */                   new VoxelRecord(
/*  589 */                     c, inputStack.getVoxel(u, v, w))); continue;
/*      */             } 
/*  591 */             if (tabLabels[u][v][w] > 0 && 
/*  592 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v][w])))
/*      */             {
/*      */ 
/*      */               
/*  596 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v][w]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  601 */         if (neighborLabels.size() > 0) {
/*      */           
/*  603 */           tabLabels[m][j][k] = ((Integer)neighborLabels.get(0)).intValue();
/*      */ 
/*      */           
/*  606 */           for (VoxelRecord v : neighborVoxels) {
/*      */             
/*  608 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()][v.getCursor().getZ()] = -3;
/*  609 */             voxelList.add(v);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  615 */     long end = System.currentTimeMillis();
/*  616 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  617 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  620 */     ImageStack labelStack = this.markerImage.duplicate().getStack();
/*      */     
/*  622 */     for (int i = 0; i < size1; i++) {
/*  623 */       for (int j = 0; j < size2; j++) {
/*  624 */         for (int k = 0; k < size3; k++)
/*  625 */           labelStack.setVoxel(i, j, k, tabLabels[i][j][k]); 
/*      */       } 
/*      */     } 
/*  628 */     String title = this.inputImage.getTitle();
/*  629 */     String ext = "";
/*  630 */     int index = title.lastIndexOf(".");
/*  631 */     if (index != -1) {
/*      */       
/*  633 */       ext = title.substring(index);
/*  634 */       title = title.substring(0, index);
/*      */     } 
/*      */     
/*  637 */     ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, labelStack);
/*  638 */     ws.setCalibration(this.inputImage.getCalibration());
/*  639 */     return ws;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImagePlus applyWithPriorityQueueAndDams() {
/*  670 */     if (Thread.currentThread().isInterrupted()) {
/*  671 */       return null;
/*      */     }
/*  673 */     ImageStack inputStack = this.inputImage.getStack();
/*  674 */     int size1 = inputStack.getWidth();
/*  675 */     int size2 = inputStack.getHeight();
/*  676 */     int size3 = inputStack.getSize();
/*      */     
/*  678 */     if (size1 != this.markerImage.getWidth() || size2 != this.markerImage.getHeight() || 
/*  679 */       size3 != this.markerImage.getStackSize())
/*      */     {
/*  681 */       throw new IllegalArgumentException("Marker and input images must have the same size");
/*      */     }
/*      */ 
/*      */     
/*  685 */     if (this.connectivity != 6 && this.connectivity != 26)
/*      */     {
/*  687 */       throw new RuntimeException(
/*  688 */           "Connectivity for stacks must be either 6 or 26, not " + 
/*  689 */           this.connectivity);
/*      */     }
/*      */ 
/*      */     
/*  693 */     PriorityQueue<VoxelRecord> voxelList = null;
/*      */ 
/*      */     
/*  696 */     int[][][] tabLabels = new int[size1][size2][size3];
/*      */     
/*  698 */     for (int i = 0; i < size1; i++) {
/*  699 */       for (int j = 0; j < size2; j++) {
/*  700 */         Arrays.fill(tabLabels[i][j], -1);
/*      */       }
/*      */     } 
/*  703 */     IJ.showStatus("Extracting voxel values...");
/*  704 */     if (this.verbose) IJ.log("  Extracting voxel values..."); 
/*  705 */     long t0 = System.currentTimeMillis();
/*      */     
/*  707 */     voxelList = extractVoxelValuesPriorityQueue(inputStack, this.markerImage.getStack(), tabLabels);
/*  708 */     if (voxelList == null) {
/*  709 */       return null;
/*      */     }
/*  711 */     long t1 = System.currentTimeMillis();
/*  712 */     if (this.verbose) IJ.log("  Extraction took " + (t1 - t0) + " ms.");
/*      */ 
/*      */     
/*  715 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/*  718 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/*  719 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*      */     
/*  721 */     int count = voxelList.size();
/*  722 */     if (this.verbose) IJ.log("  Flooding from " + count + " voxels..."); 
/*  723 */     IJ.showStatus("Flooding from " + count + " voxels...");
/*      */ 
/*      */ 
/*      */     
/*  727 */     double[] extent = Images3D.findMinAndMax(this.inputImage);
/*  728 */     double maxValue = extent[1];
/*      */ 
/*      */     
/*  731 */     ArrayList<Integer> neighborLabels = new ArrayList<Integer>();
/*      */     
/*  733 */     ArrayList<VoxelRecord> neighborVoxels = new ArrayList<VoxelRecord>();
/*      */ 
/*      */     
/*  736 */     if (this.maskImage != null) {
/*      */       
/*  738 */       if (Thread.currentThread().isInterrupted())
/*  739 */         return null; 
/*  740 */       ImageStack maskStack = this.maskImage.getStack();
/*      */       
/*  742 */       while (!voxelList.isEmpty()) {
/*      */         
/*  744 */         if (Thread.currentThread().isInterrupted()) {
/*  745 */           return null;
/*      */         }
/*      */ 
/*      */         
/*  749 */         VoxelRecord voxelRecord = voxelList.poll();
/*      */         
/*  751 */         IJ.showProgress((voxelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  753 */         Cursor3D p = voxelRecord.getCursor();
/*  754 */         int m = p.getX();
/*  755 */         int j = p.getY();
/*  756 */         int n = p.getZ();
/*      */ 
/*      */ 
/*      */         
/*  760 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  763 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  766 */         neighborVoxels.clear();
/*      */         
/*  768 */         for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  772 */           int u = c.getX();
/*  773 */           int v = c.getY();
/*  774 */           int w = c.getZ();
/*      */           
/*  776 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3) {
/*      */ 
/*      */             
/*  779 */             if (tabLabels[u][v][w] == -1 && maskStack.getVoxel(u, v, w) > 0.0D) {
/*      */ 
/*      */ 
/*      */               
/*  783 */               neighborVoxels.add(new VoxelRecord(c, inputStack.getVoxel(u, v, w))); continue;
/*      */             } 
/*  785 */             if (tabLabels[u][v][w] > 0 && 
/*  786 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v][w])))
/*      */             {
/*      */               
/*  789 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v][w]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  795 */         if (neighborLabels.size() == 1) {
/*      */           
/*  797 */           tabLabels[m][j][n] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/*  799 */           for (VoxelRecord v : neighborVoxels) {
/*      */             
/*  801 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()][v.getCursor().getZ()] = -3;
/*  802 */             voxelList.add(v);
/*      */           }  continue;
/*      */         } 
/*  805 */         if (neighborLabels.size() > 1) {
/*  806 */           tabLabels[m][j][n] = 0;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/*  811 */       while (!voxelList.isEmpty()) {
/*      */         
/*  813 */         if (Thread.currentThread().isInterrupted()) {
/*  814 */           return null;
/*      */         }
/*      */ 
/*      */         
/*  818 */         VoxelRecord voxelRecord = voxelList.poll();
/*      */         
/*  820 */         IJ.showProgress((voxelRecord.getValue() + 1.0D) / (maxValue + 1.0D));
/*      */         
/*  822 */         Cursor3D p = voxelRecord.getCursor();
/*  823 */         int m = p.getX();
/*  824 */         int j = p.getY();
/*  825 */         int n = p.getZ();
/*      */ 
/*      */         
/*  828 */         neigh.setCursor(p);
/*      */ 
/*      */         
/*  831 */         neighborLabels.clear();
/*      */ 
/*      */         
/*  834 */         neighborVoxels.clear();
/*      */ 
/*      */         
/*  837 */         for (Cursor3D c : neigh.getNeighbors()) {
/*      */ 
/*      */ 
/*      */           
/*  841 */           int u = c.getX();
/*  842 */           int v = c.getY();
/*  843 */           int w = c.getZ();
/*  844 */           if (u >= 0 && u < size1 && v >= 0 && v < size2 && w >= 0 && w < size3) {
/*      */ 
/*      */             
/*  847 */             if (tabLabels[u][v][w] == -1) {
/*      */ 
/*      */ 
/*      */               
/*  851 */               neighborVoxels.add(new VoxelRecord(c, inputStack.getVoxel(u, v, w))); continue;
/*      */             } 
/*  853 */             if (tabLabels[u][v][w] > 0 && 
/*  854 */               !neighborLabels.contains(Integer.valueOf(tabLabels[u][v][w])))
/*      */             {
/*      */               
/*  857 */               neighborLabels.add(Integer.valueOf(tabLabels[u][v][w]));
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  863 */         if (neighborLabels.size() == 1) {
/*      */           
/*  865 */           tabLabels[m][j][n] = ((Integer)neighborLabels.get(0)).intValue();
/*      */           
/*  867 */           for (VoxelRecord v : neighborVoxels) {
/*      */             
/*  869 */             tabLabels[v.getCursor().getX()][v.getCursor().getY()][v.getCursor().getZ()] = -3;
/*  870 */             voxelList.add(v);
/*      */           }  continue;
/*      */         } 
/*  873 */         if (neighborLabels.size() > 1) {
/*  874 */           tabLabels[m][j][n] = 0;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  879 */     long end = System.currentTimeMillis();
/*  880 */     if (this.verbose) IJ.log("  Flooding took: " + (end - start) + " ms"); 
/*  881 */     IJ.showStatus("");
/*  882 */     IJ.showProgress(1.0D);
/*      */ 
/*      */     
/*  885 */     ImageStack labelStack = this.markerImage.duplicate().getStack();
/*      */     
/*  887 */     for (int k = 0; k < size3; k++) {
/*      */       
/*  889 */       if (Thread.currentThread().isInterrupted()) {
/*  890 */         return null;
/*      */       }
/*  892 */       ImageProcessor labelProcessor = labelStack.getProcessor(k + 1);
/*  893 */       for (int j = 0; j < size1; j++) {
/*  894 */         for (int m = 0; m < size2; m++) {
/*      */           
/*  896 */           if (tabLabels[j][m][k] == -1) {
/*  897 */             labelProcessor.setf(j, m, 0.0F);
/*      */           } else {
/*  899 */             labelProcessor.setf(j, m, tabLabels[j][m][k]);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  904 */     String title = this.inputImage.getTitle();
/*  905 */     String ext = "";
/*  906 */     int index = title.lastIndexOf(".");
/*  907 */     if (index != -1) {
/*      */       
/*  909 */       ext = title.substring(index);
/*  910 */       title = title.substring(0, index);
/*      */     } 
/*      */     
/*  913 */     ImagePlus ws = new ImagePlus(String.valueOf(title) + "-watershed" + ext, labelStack);
/*  914 */     ws.setCalibration(this.inputImage.getCalibration());
/*  915 */     return ws;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PriorityQueue<VoxelRecord> extractVoxelValuesPriorityQueue(ImageStack inputStack, ImageStack seedStack, int[][][] tabLabels) {
/*  932 */     if (Thread.currentThread().isInterrupted()) {
/*  933 */       return null;
/*      */     }
/*  935 */     int size1 = inputStack.getWidth();
/*  936 */     int size2 = inputStack.getHeight();
/*  937 */     int size3 = inputStack.getSize();
/*      */ 
/*      */     
/*  940 */     PriorityQueue<VoxelRecord> voxelList = new PriorityQueue<VoxelRecord>();
/*      */ 
/*      */     
/*  943 */     Cursor3D cursor = new Cursor3D(0, 0, 0);
/*      */ 
/*      */     
/*  946 */     Neighborhood3D neigh = (this.connectivity == 26) ? 
/*  947 */       (Neighborhood3D)new Neighborhood3DC26() : (Neighborhood3D)new Neighborhood3DC6();
/*      */     
/*  949 */     if (this.maskImage != null) {
/*      */       
/*  951 */       ImageStack mask = this.maskImage.getImageStack();
/*      */       
/*  953 */       for (int z = 0; z < size3; z++) {
/*      */         
/*  955 */         IJ.showProgress(z + 1, size3);
/*      */         
/*  957 */         if (Thread.currentThread().isInterrupted()) {
/*      */           
/*  959 */           IJ.showProgress(1.0D);
/*  960 */           return null;
/*      */         } 
/*      */         
/*  963 */         ImageProcessor ipMask = mask.getProcessor(z + 1);
/*  964 */         ImageProcessor ipSeed = seedStack.getProcessor(z + 1);
/*      */         
/*  966 */         for (int x = 0; x < size1; x++) {
/*  967 */           for (int y = 0; y < size2; y++) {
/*  968 */             if (ipMask.getf(x, y) > 0.0F) {
/*      */               
/*  970 */               int label = (int)ipSeed.getf(x, y);
/*  971 */               if (label > 0) {
/*      */                 
/*  973 */                 cursor.set(x, y, z);
/*  974 */                 neigh.setCursor(cursor);
/*      */ 
/*      */                 
/*  977 */                 for (Cursor3D c : neigh.getNeighbors()) {
/*      */                   
/*  979 */                   int u = c.getX();
/*  980 */                   int v = c.getY();
/*  981 */                   int w = c.getZ();
/*  982 */                   if (u >= 0 && u < size1 && 
/*  983 */                     v >= 0 && v < size2 && 
/*  984 */                     w >= 0 && w < size3 && 
/*  985 */                     (int)seedStack.getVoxel(u, v, w) == 0 && 
/*  986 */                     tabLabels[u][v][w] != -3) {
/*      */                     
/*  988 */                     voxelList.add(new VoxelRecord(u, v, w, inputStack.getVoxel(u, v, w)));
/*  989 */                     tabLabels[u][v][w] = -3;
/*      */                   } 
/*      */                 } 
/*      */                 
/*  993 */                 tabLabels[x][y][z] = label;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1000 */       for (int z = 0; z < size3; z++) {
/*      */         
/* 1002 */         if (Thread.currentThread().isInterrupted()) {
/*      */           
/* 1004 */           IJ.showProgress(1.0D);
/* 1005 */           return null;
/*      */         } 
/*      */         
/* 1008 */         IJ.showProgress(z + 1, size3);
/*      */         
/* 1010 */         ImageProcessor ipSeed = seedStack.getProcessor(z + 1);
/*      */         
/* 1012 */         for (int x = 0; x < size1; x++) {
/* 1013 */           for (int y = 0; y < size2; y++) {
/*      */             
/* 1015 */             int label = (int)ipSeed.getf(x, y);
/* 1016 */             if (label > 0) {
/*      */               
/* 1018 */               cursor.set(x, y, z);
/* 1019 */               neigh.setCursor(cursor);
/*      */ 
/*      */               
/* 1022 */               for (Cursor3D c : neigh.getNeighbors()) {
/*      */                 
/* 1024 */                 int u = c.getX();
/* 1025 */                 int v = c.getY();
/* 1026 */                 int w = c.getZ();
/* 1027 */                 if (u >= 0 && u < size1 && 
/* 1028 */                   v >= 0 && v < size2 && 
/* 1029 */                   w >= 0 && w < size3 && 
/* 1030 */                   (int)seedStack.getVoxel(u, v, w) == 0 && 
/* 1031 */                   tabLabels[u][v][w] != -3) {
/*      */                   
/* 1033 */                   voxelList.add(new VoxelRecord(u, v, w, inputStack.getVoxel(u, v, w)));
/* 1034 */                   tabLabels[u][v][w] = -3;
/*      */                 } 
/*      */               } 
/*      */               
/* 1038 */               tabLabels[x][y][z] = label;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1046 */     IJ.showProgress(1.0D);
/*      */     
/* 1048 */     return voxelList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedList<VoxelRecord> extractVoxelValues(final ImageStack inputStack, final ImageStack markerStack, final int[][][] tabLabels) {
/* 1067 */     final int size1 = inputStack.getWidth();
/* 1068 */     final int size2 = inputStack.getHeight();
/* 1069 */     final int size3 = inputStack.getSize();
/*      */     
/* 1071 */     final AtomicInteger ai = new AtomicInteger(0);
/* 1072 */     final int n_cpus = Prefs.getThreads();
/*      */     
/* 1074 */     final int dec = (int)Math.ceil(size3 / n_cpus);
/*      */     
/* 1076 */     Thread[] threads = ThreadUtil.createThreadArray(n_cpus);
/*      */ 
/*      */     
/* 1079 */     final LinkedList[] lists = new LinkedList[n_cpus];
/*      */     
/* 1081 */     if (this.maskImage != null) {
/*      */       
/* 1083 */       final ImageStack mask = this.maskImage.getImageStack();
/*      */       
/* 1085 */       for (int i = 0; i < threads.length; i++) {
/*      */         
/* 1087 */         lists[i] = new LinkedList();
/*      */         
/* 1089 */         threads[i] = new Thread()
/*      */           {
/* 1091 */             public void run() { for (int k = ai.getAndIncrement(); k < n_cpus; k = ai.getAndIncrement()) {
/*      */                 
/* 1093 */                 int zmin = dec * k;
/* 1094 */                 int zmax = dec * (k + 1);
/* 1095 */                 if (zmin < 0)
/* 1096 */                   zmin = 0; 
/* 1097 */                 if (zmax > size3) {
/* 1098 */                   zmax = size3;
/*      */                 }
/* 1100 */                 for (int z = zmin; z < zmax; z++) {
/*      */                   
/* 1102 */                   if (Thread.currentThread().isInterrupted()) {
/*      */                     return;
/*      */                   }
/* 1105 */                   if (zmin == 0) {
/* 1106 */                     IJ.showProgress(z + 1, zmax);
/*      */                   }
/* 1108 */                   ImageProcessor ipMask = mask.getProcessor(z + 1);
/* 1109 */                   ImageProcessor ipInput = inputStack.getProcessor(z + 1);
/* 1110 */                   ImageProcessor ipMarker = markerStack.getProcessor(z + 1);
/*      */                   
/* 1112 */                   for (int x = 0; x < size1; x++) {
/* 1113 */                     for (int y = 0; y < size2; y++) {
/* 1114 */                       if (ipMask.getf(x, y) > 0.0F) {
/*      */                         
/* 1116 */                         lists[k].addLast(new VoxelRecord(x, y, z, ipInput.getf(x, y)));
/* 1117 */                         tabLabels[x][y][z] = (int)ipMarker.getf(x, y);
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               }  } };
/*      */       } 
/* 1124 */       ThreadUtil.startAndJoin(threads);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1129 */       for (int i = 0; i < threads.length; i++) {
/*      */         
/* 1131 */         lists[i] = new LinkedList();
/*      */         
/* 1133 */         threads[i] = new Thread() {
/*      */             public void run() {
/* 1135 */               for (int k = ai.getAndIncrement(); k < n_cpus; k = ai.getAndIncrement()) {
/*      */                 
/* 1137 */                 int zmin = dec * k;
/* 1138 */                 int zmax = dec * (k + 1);
/* 1139 */                 if (zmin < 0)
/* 1140 */                   zmin = 0; 
/* 1141 */                 if (zmax > size3) {
/* 1142 */                   zmax = size3;
/*      */                 }
/* 1144 */                 for (int z = zmin; z < zmax; z++) {
/*      */                   
/* 1146 */                   if (Thread.currentThread().isInterrupted()) {
/*      */                     return;
/*      */                   }
/* 1149 */                   if (zmin == 0) {
/* 1150 */                     IJ.showProgress(z + 1, zmax);
/*      */                   }
/* 1152 */                   ImageProcessor ipInput = inputStack.getProcessor(z + 1);
/* 1153 */                   ImageProcessor ipMarker = markerStack.getProcessor(z + 1);
/*      */                   
/* 1155 */                   for (int x = 0; x < size1; x++) {
/* 1156 */                     for (int y = 0; y < size2; y++) {
/*      */                       
/* 1158 */                       lists[k].addLast(new VoxelRecord(x, y, z, ipInput.getf(x, y)));
/* 1159 */                       tabLabels[x][y][z] = (int)ipMarker.getf(x, y);
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           };
/*      */       } 
/* 1167 */       ThreadUtil.startAndJoin(threads);
/*      */     } 
/*      */ 
/*      */     
/* 1171 */     LinkedList<VoxelRecord> voxelList = lists[0];
/* 1172 */     for (int ithread = 1; ithread < threads.length; ithread++) {
/* 1173 */       voxelList.addAll(lists[ithread]);
/*      */     }
/* 1175 */     IJ.showProgress(1.0D);
/*      */     
/* 1177 */     return voxelList;
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/MarkerControlledWatershedTransform3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */