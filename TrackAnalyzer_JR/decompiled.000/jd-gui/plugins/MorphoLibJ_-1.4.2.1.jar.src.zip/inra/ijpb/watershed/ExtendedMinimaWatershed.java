/*     */ package inra.ijpb.watershed;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedMinimaWatershed
/*     */ {
/*     */   public static final ImagePlus extendedMinimaWatershed(ImagePlus imagePlus, int dynamic, int connectivity) {
/*     */     ImagePlus resultPlus;
/*  69 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-watershed";
/*  70 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  72 */       ImageProcessor image = imagePlus.getProcessor();
/*  73 */       ImageProcessor result = extendedMinimaWatershed(image, dynamic, connectivity);
/*  74 */       resultPlus = new ImagePlus(newName, result);
/*     */     }
/*     */     else {
/*     */       
/*  78 */       ImageStack image = imagePlus.getStack();
/*  79 */       ImageStack result = extendedMinimaWatershed(image, dynamic, connectivity);
/*  80 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */     
/*  83 */     resultPlus.setCalibration(imagePlus.getCalibration());
/*  84 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinimaWatershed(ImageProcessor image, int dynamic, int connectivity, int outputType) {
/* 106 */     ImageProcessor minima = MinimaAndMaxima.extendedMinima(image, dynamic, connectivity);
/* 107 */     ImageProcessor imposedMinima = MinimaAndMaxima.imposeMinima(image, minima, connectivity);
/* 108 */     ImageProcessor labels = BinaryImages.componentsLabeling(minima, connectivity, outputType);
/* 109 */     ImageProcessor basins = Watershed.computeWatershed(imposedMinima, labels, connectivity, true);
/* 110 */     return basins;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinimaWatershed(ImageProcessor image, ImageProcessor mask, int dynamic, int connectivity, int outputType, boolean verbose) {
/* 142 */     ImageProcessor minima = 
/* 143 */       MinimaAndMaxima.extendedMinima(image, dynamic, connectivity);
/* 144 */     ImageProcessor imposedMinima = 
/* 145 */       MinimaAndMaxima.imposeMinima(image, minima, connectivity);
/* 146 */     ImageProcessor labels = 
/* 147 */       BinaryImages.componentsLabeling(minima, connectivity, outputType);
/* 148 */     ImageProcessor basins = 
/* 149 */       Watershed.computeWatershed(imposedMinima, labels, mask, 
/* 150 */         connectivity, true, verbose);
/* 151 */     return basins;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinimaWatershed(ImageStack image, ImageStack mask, int dynamic, int connectivity, int outputType, boolean verbose) {
/* 182 */     ImageStack minima = 
/* 183 */       MinimaAndMaxima3D.extendedMinima(image, dynamic, connectivity);
/* 184 */     ImageStack imposedMinima = 
/* 185 */       MinimaAndMaxima3D.imposeMinima(image, minima, connectivity);
/* 186 */     ImageStack labels = 
/* 187 */       BinaryImages.componentsLabeling(minima, connectivity, outputType);
/* 188 */     ImageStack basins = 
/* 189 */       Watershed.computeWatershed(imposedMinima, labels, mask, 
/* 190 */         connectivity, true, verbose);
/* 191 */     return basins;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinimaWatershed(ImageStack image, int dynamic, int connectivity, int outputType) {
/* 213 */     ImageStack minima = MinimaAndMaxima3D.extendedMinima(image, dynamic, connectivity);
/* 214 */     ImageStack imposedMinima = MinimaAndMaxima3D.imposeMinima(image, minima, connectivity);
/* 215 */     ImageStack labels = BinaryImages.componentsLabeling(minima, connectivity, outputType);
/* 216 */     ImageStack basins = Watershed.computeWatershed(imposedMinima, labels, connectivity, true);
/* 217 */     return basins;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinimaWatershed(ImageProcessor image, int dynamic, int connectivity) {
/* 236 */     return extendedMinimaWatershed(image, dynamic, connectivity, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageProcessor extendedMinimaWatershed(ImageProcessor image, ImageProcessor mask, int dynamic, int connectivity, boolean verbose) {
/* 265 */     return extendedMinimaWatershed(image, mask, dynamic, connectivity, 32, verbose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinimaWatershed(ImageStack image, ImageStack mask, int dynamic, int connectivity, boolean verbose) {
/* 293 */     return extendedMinimaWatershed(image, mask, dynamic, connectivity, 32, verbose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImageStack extendedMinimaWatershed(ImageStack image, int dynamic, int connectivity) {
/* 313 */     return extendedMinimaWatershed(image, dynamic, connectivity, 32);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/watershed/ExtendedMinimaWatershed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */