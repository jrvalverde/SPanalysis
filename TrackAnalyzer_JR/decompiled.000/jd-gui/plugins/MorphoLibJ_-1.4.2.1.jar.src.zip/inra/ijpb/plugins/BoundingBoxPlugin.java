/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.Box2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.BoundingBox;
/*     */ import java.awt.Color;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundingBoxPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String args) {
/*  61 */     int[] indices = WindowManager.getIDList();
/*  62 */     if (indices == null) {
/*     */       
/*  64 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  69 */     String[] imageNames = new String[indices.length];
/*  70 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  72 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  76 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  79 */     GenericDialog gd = new GenericDialog("Bounding Box");
/*  80 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*  81 */     gd.addCheckbox("Show Overlay Result", true);
/*  82 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  83 */     gd.showDialog();
/*     */     
/*  85 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  89 */     int labelImageIndex = gd.getNextChoiceIndex();
/*  90 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/*  91 */     boolean showOverlay = gd.getNextBoolean();
/*  92 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/*  95 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/*  97 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 102 */     BoundingBox op = new BoundingBox();
/* 103 */     Map<Integer, Box2D> boxes = op.analyzeRegions(labelImage);
/* 104 */     ResultsTable results = op.createTable(boxes);
/*     */ 
/*     */     
/* 107 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-BBox";
/* 108 */     results.show(tableName);
/*     */ 
/*     */     
/* 111 */     if (showOverlay) {
/*     */ 
/*     */       
/* 114 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 115 */       showResultsAsOverlay(boxes, resultImage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showResultsAsOverlay(Map<Integer, Box2D> results, ImagePlus target) {
/* 131 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 134 */     Overlay overlay = new Overlay();
/*     */ 
/*     */ 
/*     */     
/* 138 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 141 */       Box2D box = results.get(Integer.valueOf(label));
/* 142 */       box = uncalibrate(box, calib);
/* 143 */       Roi roi = createRoi(box);
/*     */ 
/*     */       
/* 146 */       roi.setStrokeColor(Color.BLUE);
/* 147 */       overlay.add(roi); }
/*     */ 
/*     */     
/* 150 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Box2D uncalibrate(Box2D box, Calibration calib) {
/* 166 */     double xmin = (box.getXMin() - calib.xOrigin) / calib.pixelWidth;
/* 167 */     double xmax = (box.getXMax() - calib.xOrigin) / calib.pixelWidth;
/* 168 */     double ymin = (box.getYMin() - calib.yOrigin) / calib.pixelHeight;
/* 169 */     double ymax = (box.getYMax() - calib.yOrigin) / calib.pixelHeight;
/* 170 */     return new Box2D(xmin, xmax, ymin, ymax);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createRoi(Box2D box) {
/* 176 */     double xmin = box.getXMin();
/* 177 */     double xmax = box.getXMax();
/* 178 */     double ymin = box.getYMin();
/* 179 */     double ymax = box.getYMax();
/*     */     
/* 181 */     return new Roi(xmin, ymin, xmax - xmin, ymax - ymin);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/BoundingBoxPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */