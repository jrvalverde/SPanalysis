/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.OvalRoi;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.Roi;
/*     */ import ij.gui.TextRoi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.Circle2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.LargestInscribedCircle;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxInscribedCirclePlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  61 */     int[] indices = WindowManager.getIDList();
/*  62 */     if (indices == null) {
/*     */       
/*  64 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  69 */     String[] imageNames = new String[indices.length];
/*  70 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  72 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  76 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  79 */     GenericDialog gd = new GenericDialog("Max. Inscribed Circle");
/*  80 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*     */ 
/*     */ 
/*     */     
/*  84 */     gd.addCheckbox("Show Overlay Result", true);
/*  85 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  86 */     gd.showDialog();
/*     */     
/*  88 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  92 */     int labelImageIndex = gd.getNextChoiceIndex();
/*  93 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/*     */     
/*  95 */     boolean showOverlay = gd.getNextBoolean();
/*  96 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/*  99 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/* 101 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 106 */     LargestInscribedCircle op = new LargestInscribedCircle();
/* 107 */     Map<Integer, Circle2D> results = op.analyzeRegions(labelImage);
/*     */ 
/*     */     
/* 110 */     ResultsTable table = op.createTable(results);
/* 111 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-MaxInscribedCircle";
/* 112 */     table.show(tableName);
/*     */ 
/*     */     
/* 115 */     if (showOverlay) {
/*     */ 
/*     */       
/* 118 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 119 */       showResultsAsOverlay(results, resultImage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus imagePlus, short[] weights) {
/* 137 */     if (imagePlus == null)
/* 138 */       return null; 
/* 139 */     ResultsTable results = (new LargestInscribedCircle()).computeTable(imagePlus);
/* 140 */     return new Object[] { "Morphometry", results };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ResultsTable process(ImagePlus imagePlus, short[] weights) {
/* 158 */     if (imagePlus == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     LargestInscribedCircle algo = new LargestInscribedCircle();
/* 162 */     ResultsTable table = algo.createTable(algo.analyzeRegions(imagePlus));
/*     */ 
/*     */     
/* 165 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showResultsAsOverlay(Map<Integer, Circle2D> results, ImagePlus target) {
/* 182 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 185 */     Overlay overlay = new Overlay();
/*     */ 
/*     */ 
/*     */     
/* 189 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 192 */       Circle2D circle = uncalibrate(results.get(Integer.valueOf(label)), calib);
/* 193 */       Point2D center = circle.getCenter();
/* 194 */       double xi = center.getX();
/* 195 */       double yi = center.getY();
/* 196 */       double ri = circle.getRadius();
/*     */ 
/*     */       
/* 199 */       int width = (int)Math.round(2.0D * ri);
/* 200 */       OvalRoi ovalRoi = new OvalRoi((int)(xi - ri), (int)(yi - ri), width, width);
/* 201 */       ovalRoi.setStrokeColor(Color.BLUE);
/* 202 */       overlay.add((Roi)ovalRoi);
/*     */ 
/*     */       
/* 205 */       TextRoi textRoi = new TextRoi((int)xi, (int)yi, Integer.toString(label));
/* 206 */       textRoi.setStrokeColor(Color.BLUE);
/* 207 */       overlay.add((Roi)textRoi); }
/*     */ 
/*     */     
/* 210 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Circle2D uncalibrate(Circle2D circle, Calibration calib) {
/* 225 */     Point2D center = circle.getCenter();
/* 226 */     double xc = (center.getX() - calib.xOrigin) / calib.pixelWidth;
/* 227 */     double yc = (center.getY() - calib.yOrigin) / calib.pixelHeight;
/* 228 */     double radius = circle.getRadius() / calib.pixelWidth;
/* 229 */     return new Circle2D(new Point2D.Double(xc, yc), radius);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MaxInscribedCirclePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */