/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.OrientedBox2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.OrientedBoundingBox2D;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrientedBoundingBoxPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String args) {
/*  63 */     int[] indices = WindowManager.getIDList();
/*  64 */     if (indices == null) {
/*     */       
/*  66 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  71 */     String[] imageNames = new String[indices.length];
/*  72 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  74 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  78 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  81 */     GenericDialog gd = new GenericDialog("Oriented Bounding Box");
/*  82 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*  83 */     gd.addCheckbox("Show Overlay Result", true);
/*  84 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  85 */     gd.showDialog();
/*     */     
/*  87 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     int labelImageIndex = gd.getNextChoiceIndex();
/*  92 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/*  93 */     boolean showOverlay = gd.getNextBoolean();
/*  94 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/*  97 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/*  99 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 104 */     OrientedBoundingBox2D op = new OrientedBoundingBox2D();
/* 105 */     Map<Integer, OrientedBox2D> boxes = op.analyzeRegions(labelImage);
/* 106 */     ResultsTable results = op.createTable(boxes);
/*     */ 
/*     */     
/* 109 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-OBox";
/* 110 */     results.show(tableName);
/*     */ 
/*     */     
/* 113 */     if (showOverlay) {
/*     */ 
/*     */       
/* 116 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 117 */       showResultsAsOverlay(boxes, resultImage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showResultsAsOverlay(Map<Integer, OrientedBox2D> results, ImagePlus target) {
/* 133 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 136 */     Overlay overlay = new Overlay();
/*     */ 
/*     */ 
/*     */     
/* 140 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 143 */       OrientedBox2D box = results.get(Integer.valueOf(label));
/* 144 */       Roi roi = createUncalibratedRoi(box, calib);
/*     */ 
/*     */       
/* 147 */       roi.setStrokeColor(Color.GREEN);
/* 148 */       overlay.add(roi); }
/*     */ 
/*     */     
/* 151 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createUncalibratedRoi(OrientedBox2D box, Calibration calib) {
/* 166 */     Point2D center = box.center();
/* 167 */     double xc = center.getX();
/* 168 */     double yc = center.getY();
/* 169 */     double dx = box.length() / 2.0D;
/* 170 */     double dy = box.width() / 2.0D;
/* 171 */     double theta = Math.toRadians(box.orientation());
/* 172 */     double cot = Math.cos(theta);
/* 173 */     double sit = Math.sin(theta);
/*     */ 
/*     */     
/* 176 */     float[] xp = new float[4];
/* 177 */     float[] yp = new float[4];
/*     */ 
/*     */ 
/*     */     
/* 181 */     double x = xc + dx * cot - dy * sit;
/* 182 */     double y = yc + dx * sit + dy * cot;
/* 183 */     xp[0] = (float)((x - calib.xOrigin) / calib.pixelWidth);
/* 184 */     yp[0] = (float)((y - calib.yOrigin) / calib.pixelHeight);
/* 185 */     x = xc - dx * cot - dy * sit;
/* 186 */     y = yc - dx * sit + dy * cot;
/* 187 */     xp[1] = (float)((x - calib.xOrigin) / calib.pixelWidth);
/* 188 */     yp[1] = (float)((y - calib.yOrigin) / calib.pixelHeight);
/* 189 */     x = xc - dx * cot + dy * sit;
/* 190 */     y = yc - dx * sit - dy * cot;
/* 191 */     xp[2] = (float)((x - calib.xOrigin) / calib.pixelWidth);
/* 192 */     yp[2] = (float)((y - calib.yOrigin) / calib.pixelHeight);
/* 193 */     x = xc + dx * cot + dy * sit;
/* 194 */     y = yc + dx * sit - dy * cot;
/* 195 */     xp[3] = (float)((x - calib.xOrigin) / calib.pixelWidth);
/* 196 */     yp[3] = (float)((y - calib.yOrigin) / calib.pixelHeight);
/* 197 */     return (Roi)new PolygonRoi(xp, yp, 4, 2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/OrientedBoundingBoxPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */