/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.binary.BinaryImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelingPlugin
/*    */   implements PlugIn
/*    */ {
/* 40 */   private static final String[] conn2DLabels = new String[] { "4", "8" };
/* 41 */   private static final int[] conn2DValues = new int[] { 4, 8 };
/* 42 */   private static final String[] conn3DLabels = new String[] { "6", "26" };
/* 43 */   private static final int[] conn3DValues = new int[] { 6, 26 };
/*    */ 
/*    */   
/* 46 */   private static final String[] resultBitDepthLabels = new String[] { "8 bits", "16 bits", "float" };
/* 47 */   private static final int[] resultBitDepthList = new int[] { 8, 16, 32 };
/*    */ 
/*    */ 
/*    */   
/*    */   public void run(String arg) {
/* 52 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*    */     
/* 54 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/*    */ 
/*    */     
/* 57 */     GenericDialog gd = new GenericDialog("Connected Components Labeling");
/* 58 */     String[] connLabels = isPlanar ? conn2DLabels : conn3DLabels;
/* 59 */     gd.addChoice("Connectivity", connLabels, connLabels[0]);
/* 60 */     gd.addChoice("Type of result", resultBitDepthLabels, resultBitDepthLabels[1]);
/*    */ 
/*    */     
/* 63 */     gd.showDialog();
/* 64 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/*    */     
/* 68 */     int connIndex = gd.getNextChoiceIndex();
/* 69 */     int bitDepth = resultBitDepthList[gd.getNextChoiceIndex()];
/* 70 */     int conn = isPlanar ? conn2DValues[connIndex] : conn3DValues[connIndex];
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 76 */       resultPlus = BinaryImages.componentsLabeling(imagePlus, conn, bitDepth);
/*    */     }
/* 78 */     catch (RuntimeException ex) {
/*    */       
/* 80 */       IJ.error("Components Labeling Error", String.valueOf(ex.getMessage()) + "\nTry with larger data type (short or float)");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 85 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-lbl";
/* 86 */     resultPlus.setTitle(newName);
/* 87 */     resultPlus.copyScale(imagePlus);
/*    */ 
/*    */     
/* 90 */     resultPlus.show();
/*    */ 
/*    */     
/* 93 */     if (!isPlanar) {
/*    */       
/* 95 */       resultPlus.setZ(imagePlus.getZ());
/* 96 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelingPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */