/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.util.ColorMaps;
/*     */ import inra.ijpb.util.CommonColors;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.ColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetLabelMapPlugin
/*     */   implements PlugIn, DialogListener
/*     */ {
/*     */   ImagePlus imagePlus;
/*     */   String lutName;
/*  68 */   Color bgColor = Color.WHITE;
/*     */   
/*     */   boolean shuffleLut = true;
/*  71 */   int labelMax = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   byte[][] colorMap;
/*     */ 
/*     */ 
/*     */   
/*     */   ColorModel oldColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String args) {
/*  85 */     this.imagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  88 */     if (isColorImage(this.imagePlus)) {
/*     */       
/*  90 */       IJ.error("Image Type Error", "Requires a label image as input");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  95 */     if (this.imagePlus.getStackSize() == 1) {
/*     */       
/*  97 */       this.oldColorModel = this.imagePlus.getProcessor().getColorModel();
/*     */     }
/*     */     else {
/*     */       
/* 101 */       this.oldColorModel = this.imagePlus.getStack().getColorModel();
/*     */     } 
/*     */ 
/*     */     
/* 105 */     GenericDialog gd = showDialog();
/* 106 */     if (gd.wasCanceled()) {
/*     */       
/* 108 */       setColorModel(this.oldColorModel);
/* 109 */       this.imagePlus.updateAndDraw();
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     parseDialogParameters(gd);
/*     */     
/* 115 */     ColorModel cm = ColorMaps.createColorModel(this.colorMap, this.bgColor);
/* 116 */     setColorModel(cm);
/* 117 */     this.imagePlus.updateAndDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isColorImage(ImagePlus imagePlus) {
/* 129 */     if (imagePlus.getStackSize() == 1)
/*     */     {
/* 131 */       return imagePlus.getProcessor() instanceof ij.process.ColorProcessor;
/*     */     }
/*     */ 
/*     */     
/* 135 */     return imagePlus.getStack().getProcessor(1) instanceof ij.process.ColorProcessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericDialog showDialog() {
/* 143 */     GenericDialog gd = new GenericDialog("Set Label Map");
/* 144 */     gd.addChoice("Colormap", ColorMaps.CommonLabelMaps.getAllLabels(), ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel());
/* 145 */     gd.addChoice("Background", CommonColors.getAllLabels(), CommonColors.WHITE.toString());
/* 146 */     gd.addCheckbox("Shuffle", true);
/*     */     
/* 148 */     gd.addPreviewCheckbox(null);
/* 149 */     gd.addDialogListener(this);
/* 150 */     parseDialogParameters(gd);
/* 151 */     gd.showDialog();
/*     */     
/* 153 */     return gd;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 158 */     parseDialogParameters(gd);
/* 159 */     if (evt == null)
/* 160 */       return true; 
/* 161 */     if (gd.getPreviewCheckbox().getState()) {
/*     */       
/* 163 */       updatePreview();
/*     */     }
/*     */     else {
/*     */       
/* 167 */       removePreview();
/*     */     } 
/*     */     
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updatePreview() {
/* 175 */     ColorModel cm = ColorMaps.createColorModel(this.colorMap, this.bgColor);
/* 176 */     setColorModel(cm);
/* 177 */     this.imagePlus.updateAndDraw();
/*     */   }
/*     */ 
/*     */   
/*     */   private void removePreview() {
/* 182 */     setColorModel(this.oldColorModel);
/* 183 */     this.imagePlus.updateAndDraw();
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 188 */     this.lutName = gd.getNextChoice();
/* 189 */     String bgColorName = gd.getNextChoice();
/* 190 */     this.bgColor = CommonColors.fromLabel(bgColorName).getColor();
/* 191 */     this.shuffleLut = gd.getNextBoolean();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     this.colorMap = ColorMaps.CommonLabelMaps.fromLabel(this.lutName).computeLut(255, this.shuffleLut);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setColorModel(ColorModel cm) {
/* 201 */     ImageProcessor baseImage = this.imagePlus.getProcessor();
/* 202 */     baseImage.setColorModel(cm);
/* 203 */     if (this.imagePlus.getStackSize() > 1) {
/*     */       
/* 205 */       ImageStack stack = this.imagePlus.getStack();
/* 206 */       stack.setColorModel(cm);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/SetLabelMapPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */