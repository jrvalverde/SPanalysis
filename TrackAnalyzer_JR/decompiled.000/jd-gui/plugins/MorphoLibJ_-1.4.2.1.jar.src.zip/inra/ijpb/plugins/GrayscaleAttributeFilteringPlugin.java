/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.attrfilt.AreaOpeningQueue;
/*     */ import inra.ijpb.morphology.attrfilt.BoxDiagonalOpeningQueue;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrayscaleAttributeFilteringPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*     */   enum Operation
/*     */   {
/*     */     CLOSING("Closing"),
/*     */     OPENING("Opening"),
/*     */     TOP_HAT("Top Hat"),
/*     */     BOTTOM_HAT("Bottom Hat");
/*     */     String label;
/*     */     
/*     */     Operation(String label) {
/*     */       this.label = label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*     */       int n = (values()).length;
/*     */       String[] result = new String[n];
/*     */       int i = 0;
/*     */       byte b;
/*     */       int j;
/*     */       Operation[] arrayOfOperation;
/*     */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) {
/*     */         Operation op = arrayOfOperation[b];
/*     */         result[i++] = op.label;
/*     */         b++;
/*     */       } 
/*     */       return result;
/*     */     }
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*     */       if (opLabel != null)
/*     */         opLabel = opLabel.toLowerCase(); 
/*     */       byte b;
/*     */       int i;
/*     */       Operation[] arrayOfOperation;
/*     */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) {
/*     */         Operation op = arrayOfOperation[b];
/*     */         String cmp = op.label.toLowerCase();
/*     */         if (cmp.equals(opLabel))
/*     */           return op; 
/*     */         b++;
/*     */       } 
/*     */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/*     */   enum Attribute
/*     */   {
/*     */     AREA("Area"),
/*     */     BOX_DIAGONAL("Box Diagonal");
/*     */     String label;
/*     */     
/*     */     Attribute(String label) {
/*     */       this.label = label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*     */       int n = (values()).length;
/*     */       String[] result = new String[n];
/*     */       int i = 0;
/*     */       byte b;
/*     */       int j;
/*     */       Attribute[] arrayOfAttribute;
/*     */       for (j = (arrayOfAttribute = values()).length, b = 0; b < j; ) {
/*     */         Attribute att = arrayOfAttribute[b];
/*     */         result[i++] = att.label;
/*     */         b++;
/*     */       } 
/*     */       return result;
/*     */     }
/*     */     
/*     */     public static Attribute fromLabel(String attrLabel) {
/*     */       if (attrLabel != null)
/*     */         attrLabel = attrLabel.toLowerCase(); 
/*     */       byte b;
/*     */       int i;
/*     */       Attribute[] arrayOfAttribute;
/*     */       for (i = (arrayOfAttribute = values()).length, b = 0; b < i; ) {
/*     */         Attribute op = arrayOfAttribute[b];
/*     */         String cmp = op.label.toLowerCase();
/*     */         if (cmp.equals(attrLabel))
/*     */           return op; 
/*     */         b++;
/*     */       } 
/*     */       throw new IllegalArgumentException("Unable to parse Attribute with label: " + attrLabel);
/*     */     }
/*     */   }
/*     */   private static final String[] connectivityLabels = new String[] { "4", "8" };
/*     */   private static final int[] connectivityValues = new int[] { 4, 8 };
/*     */   
/*     */   public GrayscaleAttributeFilteringPlugin() {
/* 148 */     this.flags = 16842911;
/*     */ 
/*     */ 
/*     */     
/* 152 */     this.previewing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     this.operation = Operation.OPENING;
/* 166 */     this.attribute = Attribute.AREA;
/* 167 */     this.minimumValue = 100;
/* 168 */     this.connectivity = 4;
/*     */   }
/*     */   private int flags; PlugInFilterRunner pfr; int nPasses;
/*     */   boolean previewing;
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 175 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/* 178 */       resetPreview();
/* 179 */       this.imagePlus.updateAndDraw();
/*     */ 
/*     */       
/* 182 */       String newName = String.valueOf(this.imagePlus.getShortTitle()) + "-attrFilt";
/* 183 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*     */ 
/*     */       
/* 186 */       resPlus.copyScale(this.imagePlus);
/* 187 */       this.result.setColorModel(this.baseImage.getColorModel());
/* 188 */       resPlus.show();
/* 189 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/* 193 */     this.imagePlus = imp;
/* 194 */     this.baseImage = imp.getProcessor().duplicate();
/*     */     
/* 196 */     return this.flags;
/*     */   }
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   private ImageProcessor result;
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 203 */     GenericDialog gd = new GenericDialog("Gray Scale Attribute Filtering");
/*     */     
/* 205 */     gd.addChoice("Operation", Operation.getAllLabels(), Operation.OPENING.label);
/* 206 */     gd.addChoice("Attribute", Attribute.getAllLabels(), Attribute.AREA.label);
/* 207 */     gd.addNumericField("Minimum Value", 100.0D, 0, 10, "pixels");
/* 208 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/*     */     
/* 210 */     gd.addPreviewCheckbox(pfr);
/* 211 */     gd.addDialogListener(this);
/* 212 */     this.previewing = true;
/* 213 */     gd.showDialog();
/* 214 */     this.previewing = false;
/*     */     
/* 216 */     if (gd.wasCanceled()) {
/*     */       
/* 218 */       resetPreview();
/* 219 */       return 4096;
/*     */     } 
/* 221 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 224 */     gd.dispose();
/* 225 */     return this.flags;
/*     */   }
/*     */   Operation operation; Attribute attribute;
/*     */   int minimumValue;
/*     */   int connectivity;
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 232 */     ImageProcessor image2 = this.baseImage;
/* 233 */     if (this.operation == Operation.CLOSING || this.operation == Operation.BOTTOM_HAT) {
/*     */       
/* 235 */       image2 = image2.duplicate();
/* 236 */       image2.invert();
/*     */     } 
/*     */ 
/*     */     
/* 240 */     if (this.attribute == Attribute.AREA) {
/*     */       
/* 242 */       AreaOpeningQueue algo = new AreaOpeningQueue();
/* 243 */       algo.setConnectivity(this.connectivity);
/* 244 */       DefaultAlgoListener.monitor((Algo)algo);
/* 245 */       this.result = algo.process(image2, this.minimumValue);
/*     */     }
/*     */     else {
/*     */       
/* 249 */       BoxDiagonalOpeningQueue algo = new BoxDiagonalOpeningQueue();
/* 250 */       algo.setConnectivity(this.connectivity);
/* 251 */       DefaultAlgoListener.monitor((Algo)algo);
/* 252 */       this.result = algo.process(image2, this.minimumValue);
/*     */     } 
/*     */ 
/*     */     
/* 256 */     if (this.operation == Operation.TOP_HAT || 
/* 257 */       this.operation == Operation.BOTTOM_HAT) {
/*     */       
/* 259 */       double maxDiff = 0.0D;
/* 260 */       for (int i = 0; i < image.getPixelCount(); i++) {
/*     */         
/* 262 */         float diff = Math.abs(this.result.getf(i) - image2.getf(i));
/* 263 */         this.result.setf(i, diff);
/* 264 */         maxDiff = Math.max(diff, maxDiff);
/*     */       } 
/*     */       
/* 267 */       this.result.setMinAndMax(0.0D, maxDiff);
/*     */ 
/*     */     
/*     */     }
/* 271 */     else if (this.operation == Operation.CLOSING) {
/*     */       
/* 273 */       this.result.invert();
/*     */     } 
/*     */     
/* 276 */     if (this.previewing) {
/*     */ 
/*     */       
/* 279 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 281 */         image.setf(i, this.result.getf(i));
/*     */       }
/* 283 */       image.setMinAndMax(this.result.getMin(), this.result.getMax());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent e) {
/* 290 */     boolean wasPreview = this.previewing;
/* 291 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 294 */     if (wasPreview && !this.previewing)
/*     */     {
/* 296 */       resetPreview();
/*     */     }
/* 298 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetPreview() {
/* 303 */     ImageProcessor image = this.imagePlus.getProcessor();
/* 304 */     if (image instanceof ij.process.FloatProcessor) {
/*     */       
/* 306 */       for (int i = 0; i < image.getPixelCount(); i++) {
/* 307 */         image.setf(i, this.baseImage.getf(i));
/*     */       }
/*     */     } else {
/*     */       
/* 311 */       for (int i = 0; i < image.getPixelCount(); i++)
/* 312 */         image.set(i, this.baseImage.get(i)); 
/*     */     } 
/* 314 */     image.resetMinAndMax();
/* 315 */     this.imagePlus.updateAndDraw();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 324 */     this.operation = Operation.fromLabel(gd.getNextChoice());
/* 325 */     this.attribute = Attribute.fromLabel(gd.getNextChoice());
/* 326 */     this.minimumValue = (int)gd.getNextNumber();
/* 327 */     this.connectivity = connectivityValues[gd.getNextChoiceIndex()];
/* 328 */     this.previewing = gd.getPreviewCheckbox().getState();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 334 */     this.nPasses = nPasses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GrayscaleAttributeFilteringPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */