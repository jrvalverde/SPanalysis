/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.ShortProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.watershed.ExtendedMinimaWatershed;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DistanceTransformWatershed
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  51 */   private int flags = 16842753;
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ChamferWeights weights;
/*     */   
/*     */   private static boolean floatProcessing = true;
/*     */   private static boolean normalize = true;
/*  67 */   private static int dynamic = 1;
/*  68 */   private static String connLabel = Conn2D.C4.label;
/*  69 */   private static String weightLabel = ChamferWeights.BORGEFORS.toString();
/*     */   
/*  71 */   private int connectivity = 4;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*     */   enum Conn2D
/*     */   {
/*  77 */     C4("4", 4),
/*  78 */     C8("8", 8);
/*     */     
/*     */     private final String label;
/*     */     private final int value;
/*     */     
/*     */     Conn2D(String label, int value) {
/*  84 */       this.label = label;
/*  85 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  89 */       return this.label;
/*     */     }
/*     */     
/*     */     public int getValue() {
/*  93 */       return this.value;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  97 */       int n = (values()).length;
/*  98 */       String[] result = new String[n];
/*     */       
/* 100 */       int i = 0; byte b; int j; Conn2D[] arrayOfConn2D;
/* 101 */       for (j = (arrayOfConn2D = values()).length, b = 0; b < j; ) { Conn2D op = arrayOfConn2D[b];
/* 102 */         result[i++] = op.label; b++; }
/*     */       
/* 104 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn2D fromLabel(String opLabel) {
/* 112 */       if (opLabel != null)
/* 113 */         opLabel = opLabel.toLowerCase();  byte b; int i; Conn2D[] arrayOfConn2D;
/* 114 */       for (i = (arrayOfConn2D = values()).length, b = 0; b < i; ) { Conn2D op = arrayOfConn2D[b];
/* 115 */         String cmp = op.label.toLowerCase();
/* 116 */         if (cmp.equals(opLabel))
/* 117 */           return op;  b++; }
/*     */       
/* 119 */       throw new IllegalArgumentException("Unable to parse Conn2D with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 133 */     if (arg.equals("final")) {
/*     */       
/* 135 */       this.imagePlus.setProcessor(this.baseImage);
/* 136 */       this.imagePlus.draw();
/*     */ 
/*     */       
/* 139 */       String newName = createResultImageName(this.imagePlus);
/* 140 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/* 141 */       resPlus.copyScale(this.imagePlus);
/* 142 */       resPlus.show();
/* 143 */       return 4096;
/*     */     } 
/*     */     
/* 146 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 154 */     if (!BinaryImages.isBinaryImage(imp)) {
/*     */       
/* 156 */       IJ.error("Distance Transform Watershed", "Input image is not binary (8-bit with only 0 or 255 values)");
/*     */       
/* 158 */       return 4096;
/*     */     } 
/*     */     
/* 161 */     this.imagePlus = imp;
/* 162 */     this.baseImage = imp.getProcessor().duplicate();
/* 163 */     this.pfr = pfr;
/*     */ 
/*     */     
/* 166 */     GenericDialog gd = new GenericDialog("Distance Transform Watershed");
/* 167 */     gd.setInsets(0, 0, 0);
/* 168 */     gd.addMessage("Distance map options:", 
/* 169 */         new Font("SansSerif", 1, 12));
/* 170 */     gd.addChoice("Distances", ChamferWeights.getAllLabels(), weightLabel);
/* 171 */     String[] outputTypes = { "32 bits", "16 bits" };
/* 172 */     gd.addChoice("Output Type", outputTypes, outputTypes[floatProcessing ? 0 : 1]);
/* 173 */     gd.setInsets(0, 0, 0);
/* 174 */     gd.addCheckbox("Normalize weights", normalize);
/* 175 */     gd.setInsets(20, 0, 0);
/* 176 */     gd.addMessage("Watershed options:", 
/* 177 */         new Font("SansSerif", 1, 12));
/* 178 */     gd.addNumericField("Dynamic", dynamic, 2);
/* 179 */     gd.addChoice("Connectivity", Conn2D.getAllLabels(), connLabel);
/* 180 */     gd.setInsets(20, 0, 0);
/* 181 */     gd.addPreviewCheckbox(pfr);
/* 182 */     gd.addDialogListener(this);
/* 183 */     this.previewing = true;
/* 184 */     gd.addHelp("http://imagej.net/MorphoLibJ#Utilities_for_binary_images");
/* 185 */     gd.showDialog();
/* 186 */     this.previewing = false;
/*     */ 
/*     */     
/* 189 */     if (gd.wasCanceled()) {
/* 190 */       return 4096;
/*     */     }
/*     */     
/* 193 */     weightLabel = gd.getNextChoice();
/* 194 */     floatProcessing = (gd.getNextChoiceIndex() == 0);
/* 195 */     normalize = gd.getNextBoolean();
/* 196 */     dynamic = (int)gd.getNextNumber();
/* 197 */     connLabel = gd.getNextChoice();
/* 198 */     this.connectivity = Conn2D.fromLabel(connLabel).getValue();
/*     */ 
/*     */     
/* 201 */     this.weights = ChamferWeights.fromLabel(weightLabel);
/*     */     
/* 203 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 212 */     synchronized (this) {
/*     */       
/* 214 */       weightLabel = gd.getNextChoice();
/* 215 */       floatProcessing = (gd.getNextChoiceIndex() == 0);
/* 216 */       normalize = gd.getNextBoolean();
/* 217 */       dynamic = (int)gd.getNextNumber();
/* 218 */       connLabel = gd.getNextChoice();
/* 219 */       this.connectivity = Conn2D.fromLabel(connLabel).getValue();
/*     */ 
/*     */       
/* 222 */       this.weights = ChamferWeights.fromLabel(weightLabel);
/*     */     } 
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 229 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 237 */     synchronized (this) {
/* 238 */       if (floatProcessing) {
/* 239 */         this.result = processFloat(image, this.weights.getFloatWeights(), normalize);
/*     */       } else {
/* 241 */         this.result = processShort(image, this.weights.getShortWeights(), normalize);
/*     */       } 
/* 243 */     }  if (this.previewing) {
/*     */ 
/*     */       
/* 246 */       double valMax = this.result.getMax();
/* 247 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 249 */         image.set(i, (int)((255.0F * this.result.getf(i)) / valMax));
/*     */       }
/* 251 */       image.resetMinAndMax();
/* 252 */       if (image.isInvertedLut()) {
/* 253 */         image.invertLut();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor processFloat(ImageProcessor image, float[] weights, boolean normalize) {
/* 262 */     FloatProcessor floatProcessor = 
/* 263 */       BinaryImages.distanceMap(image, weights, normalize);
/* 264 */     floatProcessor.invert();
/*     */     
/* 266 */     return ExtendedMinimaWatershed.extendedMinimaWatershed(
/* 267 */         (ImageProcessor)floatProcessor, image, dynamic, this.connectivity, 32, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageProcessor processShort(ImageProcessor image, short[] weights, boolean normalize) {
/* 276 */     ShortProcessor shortProcessor = 
/* 277 */       BinaryImages.distanceMap(image, weights, normalize);
/* 278 */     shortProcessor.invert();
/*     */     
/* 280 */     return ExtendedMinimaWatershed.extendedMinimaWatershed(
/* 281 */         (ImageProcessor)shortProcessor, image, dynamic, this.connectivity, 16, false);
/*     */   }
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 285 */     return String.valueOf(baseImage.getShortTitle()) + "-dist-watershed";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/DistanceTransformWatershed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */