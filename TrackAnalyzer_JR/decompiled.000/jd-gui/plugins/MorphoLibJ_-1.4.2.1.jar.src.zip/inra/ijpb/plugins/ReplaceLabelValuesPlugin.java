/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplaceLabelValuesPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 44 */     ImagePlus imagePlus = IJ.getImage();
/*    */     
/* 46 */     GenericDialog gd = new GenericDialog("Remove/Replace Label(s)");
/* 47 */     gd.addStringField("Label(s)", "1", 12);
/* 48 */     gd.addMessage("Separate label values by \",\"");
/* 49 */     gd.addNumericField("Final Value", 0.0D, 0);
/* 50 */     gd.addMessage("Replacing by value 0\n will remove labels");
/* 51 */     gd.showDialog();
/*    */     
/* 53 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/* 56 */     String labelListString = gd.getNextString();
/* 57 */     double finalValue = gd.getNextNumber();
/*    */     
/* 59 */     float[] labelArray = parseLabels(labelListString);
/*    */ 
/*    */     
/* 62 */     LabelImages.replaceLabels(imagePlus, labelArray, (float)finalValue);
/* 63 */     imagePlus.updateAndDraw();
/*    */   }
/*    */ 
/*    */   
/*    */   private static final float[] parseLabels(String string) {
/* 68 */     String[] tokens = string.split("[, ]+");
/* 69 */     int n = tokens.length;
/*    */     
/* 71 */     float[] labels = new float[n];
/* 72 */     for (int i = 0; i < n; i++)
/*    */     {
/* 74 */       labels[i] = (float)Double.parseDouble(tokens[i]);
/*    */     }
/* 76 */     return labels;
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ReplaceLabelValuesPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */