/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.process.LUT;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ import inra.ijpb.binary.ChamferWeights;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformFloat5x5;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDistanceTransformShort5x5;
/*     */ import inra.ijpb.util.ColorMaps;
/*     */ import java.awt.image.IndexColorModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDistanceMapPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*     */     ImagePlus res;
/*  62 */     int[] indices = WindowManager.getIDList();
/*  63 */     if (indices == null) {
/*     */       
/*  65 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  70 */     String[] imageNames = new String[indices.length];
/*  71 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  73 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  77 */     GenericDialog gd = new GenericDialog("Geodesic Distance Map");
/*     */     
/*  79 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/*  80 */     gd.addChoice("Mask Image", imageNames, IJ.getImage().getTitle());
/*     */     
/*  82 */     gd.addChoice("Distances", ChamferWeights.getAllLabels(), 
/*  83 */         ChamferWeights.CHESSKNIGHT.toString());
/*  84 */     String[] outputTypes = { "32 bits", "16 bits" };
/*  85 */     gd.addChoice("Output Type", outputTypes, outputTypes[0]);
/*  86 */     gd.addCheckbox("Normalize weights", true);
/*     */     
/*  88 */     gd.showDialog();
/*     */     
/*  90 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     int markerImageIndex = gd.getNextChoiceIndex();
/*  95 */     ImagePlus markerImage = WindowManager.getImage(markerImageIndex + 1);
/*  96 */     int maskImageIndex = gd.getNextChoiceIndex();
/*  97 */     ImagePlus maskImage = WindowManager.getImage(maskImageIndex + 1);
/*  98 */     String weightLabel = gd.getNextChoice();
/*     */ 
/*     */     
/* 101 */     ChamferWeights weights = ChamferWeights.fromLabel(weightLabel);
/* 102 */     boolean resultAsFloat = (gd.getNextChoiceIndex() == 0);
/* 103 */     boolean normalizeWeights = gd.getNextBoolean();
/*     */ 
/*     */     
/* 106 */     if (markerImage.getType() != 0) {
/*     */       
/* 108 */       IJ.showMessage("Marker image should be binary");
/*     */       return;
/*     */     } 
/* 111 */     if (maskImage.getType() != 0) {
/*     */       
/* 113 */       IJ.showMessage("Mask image should be binary");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 118 */     String newName = createResultImageName(maskImage);
/*     */     
/* 120 */     if (resultAsFloat) {
/*     */       
/* 122 */       res = process(markerImage, maskImage, newName, 
/* 123 */           weights.getFloatWeights(), normalizeWeights);
/*     */     } else {
/*     */       
/* 126 */       res = process(markerImage, maskImage, newName, 
/* 127 */           weights.getShortWeights(), normalizeWeights);
/*     */     } 
/*     */     
/* 130 */     res.show();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus marker, ImagePlus mask, String newName, float[] weights) {
/* 137 */     return exec(marker, mask, newName, weights, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus marker, ImagePlus mask, String newName, float[] weights, boolean normalize) {
/* 165 */     if (marker == null)
/*     */     {
/* 167 */       throw new IllegalArgumentException("Marker image not specified");
/*     */     }
/* 169 */     if (mask == null)
/*     */     {
/* 171 */       throw new IllegalArgumentException("Mask image not specified");
/*     */     }
/* 173 */     if (newName == null)
/* 174 */       newName = createResultImageName(mask); 
/* 175 */     if (weights == null)
/*     */     {
/* 177 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */     
/* 181 */     int width = mask.getWidth();
/* 182 */     int height = mask.getHeight();
/*     */ 
/*     */     
/* 185 */     if (marker.getWidth() != width || marker.getHeight() != height) {
/*     */       
/* 187 */       IJ.showMessage("Error", 
/* 188 */           "Input and marker images\nshould have the same size");
/* 189 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 193 */     ImagePlus resultPlus = BinaryImages.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 196 */     return new Object[] { newName, resultPlus };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus marker, ImagePlus mask, String newName, short[] weights, boolean normalize) {
/* 224 */     if (marker == null)
/*     */     {
/* 226 */       throw new IllegalArgumentException("Marker image not specified");
/*     */     }
/* 228 */     if (mask == null)
/*     */     {
/* 230 */       throw new IllegalArgumentException("Mask image not specified");
/*     */     }
/* 232 */     if (newName == null)
/* 233 */       newName = createResultImageName(mask); 
/* 234 */     if (weights == null)
/*     */     {
/* 236 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */     
/* 240 */     int width = mask.getWidth();
/* 241 */     int height = mask.getHeight();
/*     */ 
/*     */     
/* 244 */     if (marker.getWidth() != width || marker.getHeight() != height) {
/*     */       
/* 246 */       IJ.showMessage("Error", 
/* 247 */           "Input and marker images\nshould have the same size");
/* 248 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 252 */     ImageProcessor result = BinaryImages.geodesicDistanceMap(marker.getProcessor(), mask.getProcessor(), weights, normalize);
/* 253 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 256 */     return new Object[] { newName, resultPlus };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus markerPlus, ImagePlus maskPlus, String newName, float[] weights, boolean normalize) {
/* 282 */     if (markerPlus == null)
/*     */     {
/* 284 */       throw new IllegalArgumentException("Marker image not specified");
/*     */     }
/* 286 */     if (maskPlus == null)
/*     */     {
/* 288 */       throw new IllegalArgumentException("Mask image not specified");
/*     */     }
/* 290 */     if (newName == null)
/* 291 */       newName = createResultImageName(maskPlus); 
/* 292 */     if (weights == null)
/*     */     {
/* 294 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */     
/* 298 */     int width = maskPlus.getWidth();
/* 299 */     int height = maskPlus.getHeight();
/*     */ 
/*     */     
/* 302 */     if (markerPlus.getWidth() != width || markerPlus.getHeight() != height) {
/*     */       
/* 304 */       IJ.showMessage("Error", 
/* 305 */           "Input and marker images\nshould have the same size");
/* 306 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 310 */     GeodesicDistanceTransformFloat5x5 geodesicDistanceTransformFloat5x5 = new GeodesicDistanceTransformFloat5x5(weights, normalize);
/* 311 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransformFloat5x5);
/*     */ 
/*     */ 
/*     */     
/* 315 */     ImageProcessor marker = markerPlus.getProcessor();
/* 316 */     ImageProcessor mask = maskPlus.getProcessor();
/* 317 */     ImageProcessor result = geodesicDistanceTransformFloat5x5.geodesicDistanceMap(marker, mask);
/* 318 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 321 */     double maxVal = result.getMax();
/* 322 */     resultPlus.setLut(createFireLUT(maxVal));
/* 323 */     resultPlus.setDisplayRange(0.0D, maxVal);
/*     */ 
/*     */     
/* 326 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageProcessor process(ImageProcessor marker, ImageProcessor mask, float[] weights, boolean normalize) {
/* 332 */     if (weights == null)
/*     */     {
/* 334 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */     
/* 338 */     int width = mask.getWidth();
/* 339 */     int height = mask.getHeight();
/*     */ 
/*     */     
/* 342 */     if (marker.getWidth() != width || marker.getHeight() != height) {
/*     */       
/* 344 */       IJ.showMessage("Error", 
/* 345 */           "Input and marker images\nshould have the same size");
/* 346 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 350 */     GeodesicDistanceTransformFloat5x5 geodesicDistanceTransformFloat5x5 = new GeodesicDistanceTransformFloat5x5(
/* 351 */         weights, normalize);
/* 352 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransformFloat5x5);
/*     */ 
/*     */ 
/*     */     
/* 356 */     ImageProcessor result = geodesicDistanceTransformFloat5x5.geodesicDistanceMap(marker, mask);
/*     */ 
/*     */     
/* 359 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImagePlus process(ImagePlus marker, ImagePlus mask, String newName, short[] weights, boolean normalize) {
/* 385 */     if (marker == null)
/*     */     {
/* 387 */       throw new IllegalArgumentException("Marker image not specified");
/*     */     }
/* 389 */     if (mask == null)
/*     */     {
/* 391 */       throw new IllegalArgumentException("Mask image not specified");
/*     */     }
/* 393 */     if (newName == null)
/* 394 */       newName = createResultImageName(mask); 
/* 395 */     if (weights == null)
/*     */     {
/* 397 */       throw new IllegalArgumentException("Weights not specified");
/*     */     }
/*     */ 
/*     */     
/* 401 */     int width = mask.getWidth();
/* 402 */     int height = mask.getHeight();
/*     */ 
/*     */     
/* 405 */     if (marker.getWidth() != width || marker.getHeight() != height) {
/*     */       
/* 407 */       IJ.showMessage("Error", 
/* 408 */           "Input and marker images\nshould have the same size");
/* 409 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 413 */     GeodesicDistanceTransformShort5x5 geodesicDistanceTransformShort5x5 = new GeodesicDistanceTransformShort5x5(weights, normalize);
/*     */     
/* 415 */     DefaultAlgoListener.monitor((Algo)geodesicDistanceTransformShort5x5);
/*     */ 
/*     */     
/* 418 */     ImageProcessor result = geodesicDistanceTransformShort5x5.geodesicDistanceMap(marker.getProcessor(), 
/* 419 */         mask.getProcessor());
/* 420 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */     
/* 423 */     double maxVal = result.getMax();
/* 424 */     resultPlus.setLut(createFireLUT(maxVal));
/* 425 */     resultPlus.setDisplayRange(0.0D, maxVal);
/*     */ 
/*     */     
/* 428 */     return resultPlus;
/*     */   }
/*     */ 
/*     */   
/*     */   private LUT createFireLUT(double maxVal) {
/* 433 */     byte[][] lut = ColorMaps.createFireLut(256);
/* 434 */     byte[] red = new byte[256];
/* 435 */     byte[] green = new byte[256];
/* 436 */     byte[] blue = new byte[256];
/* 437 */     for (int i = 0; i < 256; i++) {
/*     */       
/* 439 */       red[i] = lut[i][0];
/* 440 */       green[i] = lut[i][1];
/* 441 */       blue[i] = lut[i][2];
/*     */     } 
/* 443 */     IndexColorModel cm = new IndexColorModel(8, 256, red, green, blue);
/* 444 */     return new LUT(cm, 0.0D, maxVal);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createResultImageName(ImagePlus baseImage) {
/* 449 */     return String.valueOf(baseImage.getShortTitle()) + "-geoddist";
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GeodesicDistanceMapPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */