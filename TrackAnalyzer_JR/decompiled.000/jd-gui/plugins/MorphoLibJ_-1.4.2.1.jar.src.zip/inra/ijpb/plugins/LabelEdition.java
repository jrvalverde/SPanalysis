/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.ImageCanvas;
/*     */ import ij.gui.StackWindow;
/*     */ import ij.gui.Toolbar;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.morphology.Morphology;
/*     */ import inra.ijpb.morphology.Strel;
/*     */ import inra.ijpb.morphology.Strel3D;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelEdition
/*     */   implements PlugIn
/*     */ {
/*     */   private CustomWindow win;
/*  66 */   ImagePlus inputImage = null;
/*     */   
/*  68 */   ImageStack inputStackCopy = null;
/*     */ 
/*     */   
/*  71 */   ImagePlus displayImage = null;
/*     */ 
/*     */   
/*     */   boolean inputIs2D = false;
/*     */ 
/*     */   
/*  77 */   final ExecutorService exec = Executors.newFixedThreadPool(1);
/*     */ 
/*     */ 
/*     */   
/*  81 */   JButton mergeButton = null;
/*     */   
/*  83 */   JButton dilateButton = null;
/*     */   
/*  85 */   JButton erodeButton = null;
/*     */   
/*  87 */   JButton openButton = null;
/*     */   
/*  89 */   JButton closeButton = null;
/*     */   
/*  91 */   JButton removeSelectedButton = null;
/*     */   
/*  93 */   JButton removeLargestButton = null;
/*     */   
/*  95 */   JButton removeBorderLabelsButton = null;
/*     */   
/*  97 */   JButton sizeOpeningButton = null;
/*     */   
/*  99 */   JButton resetButton = null;
/*     */   
/* 101 */   JButton doneButton = null;
/*     */ 
/*     */   
/* 104 */   JPanel buttonsPanel = new JPanel();
/*     */ 
/*     */   
/* 107 */   Panel all = new Panel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CustomWindow
/*     */     extends StackWindow
/*     */   {
/*     */     private static final long serialVersionUID = 7356632113911531536L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     private ActionListener listener = new ActionListener()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(final ActionEvent e)
/*     */         {
/* 130 */           (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.this)).exec.submit(new Runnable()
/*     */               {
/*     */                 
/*     */                 public void run()
/*     */                 {
/* 135 */                   if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).mergeButton) {
/*     */                     
/* 137 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 138 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).mergeLabels();
/* 139 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 141 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).dilateButton) {
/*     */                     
/* 143 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 144 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).dilateLabels();
/* 145 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 147 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).erodeButton) {
/*     */                     
/* 149 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 150 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).erodeLabels();
/* 151 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 153 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).openButton) {
/*     */                     
/* 155 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 156 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).openLabels();
/* 157 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 159 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).closeButton) {
/*     */                     
/* 161 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 162 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).closeLabels();
/* 163 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 165 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).removeSelectedButton) {
/*     */                     
/* 167 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 168 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).removeSelectedLabels();
/* 169 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 171 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).removeLargestButton) {
/*     */                     
/* 173 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 174 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).removeLargestLabel();
/* 175 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 177 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).removeBorderLabelsButton) {
/*     */                     
/* 179 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 180 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).removeBorderLabels();
/* 181 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 183 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).sizeOpeningButton) {
/*     */                     
/* 185 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(false);
/* 186 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).labelSizeOpening();
/* 187 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).setButtonsEnabled(true);
/*     */                   }
/* 189 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).resetButton) {
/*     */                     
/* 191 */                     LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this).resetLabels();
/*     */                   }
/* 193 */                   else if (e.getSource() == (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).doneButton) {
/*     */                     
/* 195 */                     (LabelEdition.CustomWindow.access$0(LabelEdition.CustomWindow.null.access$0(LabelEdition.CustomWindow.null.this))).win.windowClosing((WindowEvent)null);
/*     */                   } 
/*     */                 }
/*     */               });
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CustomWindow(ImagePlus imp) {
/* 209 */       super(imp, new ImageCanvas(imp));
/*     */       
/* 211 */       ImageCanvas canvas = getCanvas();
/*     */       
/* 213 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 214 */       double screenWidth = screenSize.getWidth();
/* 215 */       double screenHeight = screenSize.getHeight();
/*     */ 
/*     */       
/* 218 */       while (this.ic.getWidth() < screenWidth / 2.0D && 
/* 219 */         this.ic.getHeight() < screenHeight / 2.0D && 
/* 220 */         this.ic.getMagnification() < 32.0D) {
/*     */         
/* 222 */         int canvasWidth = this.ic.getWidth();
/* 223 */         this.ic.zoomIn(0, 0);
/*     */         
/* 225 */         if (canvasWidth == this.ic.getWidth()) {
/*     */           
/* 227 */           this.ic.zoomOut(0, 0);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 232 */       while ((this.ic.getWidth() > 0.75D * screenWidth || 
/* 233 */         this.ic.getHeight() > 0.75D * screenHeight) && 
/* 234 */         this.ic.getMagnification() > 0.013888888888888888D) {
/*     */         
/* 236 */         int canvasWidth = this.ic.getWidth();
/* 237 */         this.ic.zoomOut(0, 0);
/*     */         
/* 239 */         if (canvasWidth == this.ic.getWidth()) {
/*     */           
/* 241 */           this.ic.zoomIn(0, 0);
/*     */           break;
/*     */         } 
/*     */       } 
/* 245 */       setTitle("Label Edition");
/*     */       
/* 247 */       LabelEdition.this.mergeButton = new JButton("Merge");
/* 248 */       LabelEdition.this.mergeButton.addActionListener(this.listener);
/* 249 */       LabelEdition.this.mergeButton.setToolTipText("Merge labels selected by point or freehand ROIs");
/*     */ 
/*     */       
/* 252 */       LabelEdition.this.dilateButton = new JButton("Dilate");
/* 253 */       LabelEdition.this.dilateButton.addActionListener(this.listener);
/* 254 */       LabelEdition.this.dilateButton.setToolTipText("Dilate all labels");
/*     */       
/* 256 */       LabelEdition.this.erodeButton = new JButton("Erode");
/* 257 */       LabelEdition.this.erodeButton.addActionListener(this.listener);
/* 258 */       LabelEdition.this.erodeButton.setToolTipText("Erode all labels");
/*     */       
/* 260 */       LabelEdition.this.openButton = new JButton("Open");
/* 261 */       LabelEdition.this.openButton.addActionListener(this.listener);
/* 262 */       LabelEdition.this.openButton.setToolTipText("Apply morphological opening to all labels");
/*     */ 
/*     */       
/* 265 */       LabelEdition.this.closeButton = new JButton("Close");
/* 266 */       LabelEdition.this.closeButton.addActionListener(this.listener);
/* 267 */       LabelEdition.this.closeButton.setToolTipText("Apply morphological closing to all labels");
/*     */ 
/*     */       
/* 270 */       LabelEdition.this.removeSelectedButton = new JButton("Remove selected");
/* 271 */       LabelEdition.this.removeSelectedButton.addActionListener(this.listener);
/* 272 */       LabelEdition.this.removeSelectedButton.setToolTipText("Remove selected label(s)");
/*     */       
/* 274 */       LabelEdition.this.removeLargestButton = new JButton("Remove largest");
/* 275 */       LabelEdition.this.removeLargestButton.addActionListener(this.listener);
/* 276 */       LabelEdition.this.removeLargestButton.setToolTipText("Remove largest label");
/*     */       
/* 278 */       LabelEdition.this.removeBorderLabelsButton = new JButton("Remove in border");
/* 279 */       LabelEdition.this.removeBorderLabelsButton.addActionListener(this.listener);
/* 280 */       LabelEdition.this.removeBorderLabelsButton.setToolTipText("Remove labels in the borders of the image");
/*     */ 
/*     */       
/* 283 */       LabelEdition.this.sizeOpeningButton = new JButton("Size opening");
/* 284 */       LabelEdition.this.sizeOpeningButton.addActionListener(this.listener);
/* 285 */       LabelEdition.this.sizeOpeningButton.setToolTipText("Remove labels under a certain size");
/*     */ 
/*     */       
/* 288 */       LabelEdition.this.resetButton = new JButton("Reset");
/* 289 */       LabelEdition.this.resetButton.addActionListener(this.listener);
/* 290 */       LabelEdition.this.resetButton.setToolTipText("Reset labels to initial state");
/*     */       
/* 292 */       LabelEdition.this.doneButton = new JButton("Done");
/* 293 */       LabelEdition.this.doneButton.addActionListener(this.listener);
/* 294 */       LabelEdition.this.doneButton.setToolTipText("Close plugin and return result");
/*     */ 
/*     */       
/* 297 */       LabelEdition.this.buttonsPanel.setBorder(
/* 298 */           BorderFactory.createTitledBorder("Options"));
/* 299 */       GridBagLayout buttonsLayout = new GridBagLayout();
/* 300 */       GridBagConstraints buttonsConstraints = new GridBagConstraints();
/* 301 */       buttonsConstraints.anchor = 18;
/* 302 */       buttonsConstraints.fill = 2;
/* 303 */       buttonsConstraints.gridwidth = 1;
/* 304 */       buttonsConstraints.gridheight = 1;
/* 305 */       buttonsConstraints.gridx = 0;
/* 306 */       buttonsConstraints.gridy = 0;
/* 307 */       buttonsConstraints.insets = new Insets(5, 5, 6, 6);
/* 308 */       LabelEdition.this.buttonsPanel.setLayout(buttonsLayout);
/*     */       
/* 310 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.mergeButton, buttonsConstraints);
/* 311 */       buttonsConstraints.gridy++;
/* 312 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.dilateButton, buttonsConstraints);
/* 313 */       buttonsConstraints.gridy++;
/* 314 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.erodeButton, buttonsConstraints);
/* 315 */       buttonsConstraints.gridy++;
/* 316 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.openButton, buttonsConstraints);
/* 317 */       buttonsConstraints.gridy++;
/* 318 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.closeButton, buttonsConstraints);
/* 319 */       buttonsConstraints.gridy++;
/* 320 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.removeSelectedButton, buttonsConstraints);
/* 321 */       buttonsConstraints.gridy++;
/* 322 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.removeLargestButton, buttonsConstraints);
/* 323 */       buttonsConstraints.gridy++;
/* 324 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.removeBorderLabelsButton, buttonsConstraints);
/* 325 */       buttonsConstraints.gridy++;
/* 326 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.sizeOpeningButton, buttonsConstraints);
/* 327 */       buttonsConstraints.gridy++;
/* 328 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.resetButton, buttonsConstraints);
/* 329 */       buttonsConstraints.gridy++;
/* 330 */       LabelEdition.this.buttonsPanel.add(LabelEdition.this.doneButton, buttonsConstraints);
/* 331 */       buttonsConstraints.gridy++;
/*     */       
/* 333 */       GridBagLayout layout = new GridBagLayout();
/* 334 */       GridBagConstraints allConstraints = new GridBagConstraints();
/* 335 */       LabelEdition.this.all.setLayout(layout);
/*     */       
/* 337 */       allConstraints.anchor = 18;
/* 338 */       allConstraints.fill = 1;
/* 339 */       allConstraints.gridwidth = 1;
/* 340 */       allConstraints.gridheight = 2;
/* 341 */       allConstraints.gridx = 0;
/* 342 */       allConstraints.gridy = 0;
/* 343 */       allConstraints.weightx = 0.0D;
/* 344 */       allConstraints.weighty = 0.0D;
/*     */       
/* 346 */       LabelEdition.this.all.add(LabelEdition.this.buttonsPanel, allConstraints);
/*     */       
/* 348 */       allConstraints.gridx++;
/* 349 */       allConstraints.weightx = 1.0D;
/* 350 */       allConstraints.weighty = 1.0D;
/* 351 */       allConstraints.gridheight = 1;
/* 352 */       LabelEdition.this.all.add((Component)canvas, allConstraints);
/*     */       
/* 354 */       allConstraints.gridy++;
/* 355 */       allConstraints.weightx = 0.0D;
/* 356 */       allConstraints.weighty = 0.0D;
/*     */ 
/*     */       
/* 359 */       if (this.sliceSelector != null) {
/*     */         
/* 361 */         this.sliceSelector.setValue(LabelEdition.this.inputImage.getCurrentSlice());
/* 362 */         LabelEdition.this.displayImage.setSlice(LabelEdition.this.inputImage.getCurrentSlice());
/*     */         
/* 364 */         LabelEdition.this.all.add(this.sliceSelector, allConstraints);
/*     */         
/* 366 */         if (this.zSelector != null)
/* 367 */           LabelEdition.this.all.add((Component)this.zSelector, allConstraints); 
/* 368 */         if (this.tSelector != null)
/* 369 */           LabelEdition.this.all.add((Component)this.tSelector, allConstraints); 
/* 370 */         if (this.cSelector != null) {
/* 371 */           LabelEdition.this.all.add((Component)this.cSelector, allConstraints);
/*     */         }
/*     */       } 
/* 374 */       allConstraints.gridy--;
/*     */       
/* 376 */       GridBagLayout wingb = new GridBagLayout();
/* 377 */       GridBagConstraints winc = new GridBagConstraints();
/* 378 */       winc.anchor = 18;
/* 379 */       winc.fill = 1;
/* 380 */       winc.weightx = 1.0D;
/* 381 */       winc.weighty = 1.0D;
/* 382 */       setLayout(wingb);
/* 383 */       add(LabelEdition.this.all, winc);
/*     */ 
/*     */       
/* 386 */       pack();
/* 387 */       setMinimumSize(getPreferredSize());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void windowClosing(WindowEvent e) {
/* 397 */       super.windowClosing(e);
/*     */       
/* 399 */       if (LabelEdition.this.displayImage != null) {
/*     */         
/* 401 */         ImagePlus result = LabelEdition.this.displayImage.duplicate();
/* 402 */         result.setTitle(String.valueOf(LabelEdition.this.inputImage.getShortTitle()) + "-edited");
/* 403 */         result.setSlice(LabelEdition.this.displayImage.getCurrentSlice());
/* 404 */         result.show();
/*     */       } 
/*     */       
/* 407 */       LabelEdition.this.inputImage.changes = false;
/* 408 */       LabelEdition.this.inputImage.getWindow().setVisible(true);
/*     */ 
/*     */       
/* 411 */       LabelEdition.this.mergeButton.removeActionListener(this.listener);
/* 412 */       LabelEdition.this.dilateButton.removeActionListener(this.listener);
/* 413 */       LabelEdition.this.erodeButton.removeActionListener(this.listener);
/* 414 */       LabelEdition.this.doneButton.removeActionListener(this.listener);
/*     */ 
/*     */       
/* 417 */       LabelEdition.this.exec.shutdownNow();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void mergeLabels() {
/* 426 */       LabelImages.mergeLabels(LabelEdition.this.displayImage, LabelEdition.this.displayImage.getRoi(), 
/* 427 */           true);
/* 428 */       LabelEdition.this.displayImage.deleteRoi();
/* 429 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void dilateLabels() {
/* 437 */       if (LabelEdition.this.inputIs2D) {
/*     */         
/* 439 */         LabelEdition.this.displayImage.setProcessor(Morphology.dilation(
/* 440 */               LabelEdition.this.displayImage.getProcessor(), 
/* 441 */               Strel.Shape.SQUARE.fromRadius(1)));
/*     */       }
/*     */       else {
/*     */         
/* 445 */         LabelEdition.this.displayImage.setStack(Morphology.dilation(
/* 446 */               LabelEdition.this.displayImage.getImageStack(), 
/* 447 */               Strel3D.Shape.CUBE.fromRadius(1)));
/*     */       } 
/* 449 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void erodeLabels() {
/* 457 */       if (LabelEdition.this.inputIs2D) {
/*     */         
/* 459 */         LabelEdition.this.displayImage.setProcessor(Morphology.erosion(
/* 460 */               LabelEdition.this.displayImage.getProcessor(), 
/* 461 */               Strel.Shape.SQUARE.fromRadius(1)));
/*     */       }
/*     */       else {
/*     */         
/* 465 */         LabelEdition.this.displayImage.setStack(Morphology.erosion(
/* 466 */               LabelEdition.this.displayImage.getImageStack(), 
/* 467 */               Strel3D.Shape.CUBE.fromRadius(1)));
/*     */       } 
/* 469 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void openLabels() {
/* 477 */       if (LabelEdition.this.inputIs2D) {
/*     */         
/* 479 */         LabelEdition.this.displayImage.setProcessor(Morphology.opening(
/* 480 */               LabelEdition.this.displayImage.getProcessor(), 
/* 481 */               Strel.Shape.SQUARE.fromRadius(1)));
/*     */       }
/*     */       else {
/*     */         
/* 485 */         LabelEdition.this.displayImage.setStack(Morphology.opening(
/* 486 */               LabelEdition.this.displayImage.getImageStack(), 
/* 487 */               Strel3D.Shape.CUBE.fromRadius(1)));
/*     */       } 
/* 489 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void closeLabels() {
/* 497 */       if (LabelEdition.this.inputIs2D) {
/*     */         
/* 499 */         LabelEdition.this.displayImage.setProcessor(Morphology.closing(
/* 500 */               LabelEdition.this.displayImage.getProcessor(), 
/* 501 */               Strel.Shape.SQUARE.fromRadius(1)));
/*     */       }
/*     */       else {
/*     */         
/* 505 */         LabelEdition.this.displayImage.setStack(Morphology.closing(
/* 506 */               LabelEdition.this.displayImage.getImageStack(), 
/* 507 */               Strel3D.Shape.CUBE.fromRadius(1)));
/*     */       } 
/* 509 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeSelectedLabels() {
/* 517 */       LabelImages.removeLabels(LabelEdition.this.displayImage, LabelEdition.this.displayImage.getRoi(), 
/* 518 */           true);
/* 519 */       LabelEdition.this.displayImage.deleteRoi();
/* 520 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeLargestLabel() {
/* 527 */       LabelImages.removeLargestLabel(LabelEdition.this.displayImage);
/* 528 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeBorderLabels() {
/* 535 */       LabelImages.removeBorderLabels(LabelEdition.this.displayImage);
/* 536 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void labelSizeOpening() {
/* 543 */       String title = LabelEdition.this.inputIs2D ? "Area Opening" : "Volume Opening";
/* 544 */       GenericDialog gd = new GenericDialog(title);
/* 545 */       String label = LabelEdition.this.inputIs2D ? "Min Pixel Number:" : 
/* 546 */         "Min Voxel Number:";
/* 547 */       gd.addNumericField(label, 100.0D, 0);
/* 548 */       gd.showDialog();
/*     */ 
/*     */       
/* 551 */       if (gd.wasCanceled()) {
/*     */         return;
/*     */       }
/* 554 */       int nPixelMin = (int)gd.getNextNumber();
/*     */ 
/*     */       
/* 557 */       ImagePlus res = LabelImages.sizeOpening(LabelEdition.this.displayImage, nPixelMin);
/* 558 */       LabelEdition.this.displayImage.setStack(res.getImageStack());
/* 559 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void resetLabels() {
/* 567 */       LabelEdition.this.displayImage.setStack(LabelEdition.this.inputImage.getImageStack().duplicate());
/* 568 */       LabelEdition.this.displayImage.updateAndDraw();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setButtonsEnabled(boolean enable) {
/* 578 */       LabelEdition.this.mergeButton.setEnabled(enable);
/* 579 */       LabelEdition.this.erodeButton.setEnabled(enable);
/* 580 */       LabelEdition.this.dilateButton.setEnabled(enable);
/* 581 */       LabelEdition.this.openButton.setEnabled(enable);
/* 582 */       LabelEdition.this.closeButton.setEnabled(enable);
/* 583 */       LabelEdition.this.removeSelectedButton.setEnabled(enable);
/* 584 */       LabelEdition.this.removeLargestButton.setEnabled(enable);
/* 585 */       LabelEdition.this.removeBorderLabelsButton.setEnabled(enable);
/* 586 */       LabelEdition.this.sizeOpeningButton.setEnabled(enable);
/* 587 */       LabelEdition.this.resetButton.setEnabled(enable);
/* 588 */       LabelEdition.this.doneButton.setEnabled(enable);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 600 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*     */       
/* 602 */       IJ.error("Label Edition", "ERROR: detected ImageJ version " + 
/* 603 */           IJ.getVersion() + ".\nLabel Edition requires" + 
/* 604 */           " version 1.48a or superior, please update ImageJ!");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 609 */     if (WindowManager.getCurrentImage() == null) {
/*     */       
/* 611 */       this.inputImage = IJ.openImage();
/* 612 */       if (this.inputImage == null) {
/*     */         return;
/*     */       }
/*     */     } else {
/* 616 */       this.inputImage = WindowManager.getCurrentImage();
/*     */     } 
/*     */     
/* 619 */     if (!LabelImages.isLabelImageType(this.inputImage)) {
/*     */       
/* 621 */       IJ.error("Label Edition", "This plugin only works on label images.\nPlease convert it to 8, 16 or 32-bit.");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 627 */     Toolbar.getInstance().setTool(7);
/*     */     
/* 629 */     this.inputStackCopy = this.inputImage.getImageStack().duplicate();
/* 630 */     this.displayImage = new ImagePlus(this.inputImage.getTitle(), 
/* 631 */         this.inputStackCopy);
/* 632 */     this.displayImage.setTitle("Label Edition");
/* 633 */     this.displayImage.setSlice(this.inputImage.getCurrentSlice());
/* 634 */     this.displayImage.setCalibration(this.inputImage.getCalibration());
/*     */ 
/*     */     
/* 637 */     this.inputImage.getWindow().setVisible(false);
/*     */ 
/*     */     
/* 640 */     this.inputIs2D = (this.inputImage.getImageStackSize() == 1);
/*     */ 
/*     */     
/* 643 */     if (!this.inputIs2D && 
/* 644 */       !this.displayImage.isHyperStack() && 
/* 645 */       this.displayImage.getNSlices() == 1)
/*     */     {
/*     */       
/* 648 */       this.displayImage.setDimensions(1, this.displayImage.getNFrames(), 1);
/*     */     }
/*     */ 
/*     */     
/* 652 */     SwingUtilities.invokeLater(
/* 653 */         new Runnable() {
/*     */           public void run() {
/* 655 */             LabelEdition.this.win = new LabelEdition.CustomWindow(LabelEdition.this.displayImage);
/* 656 */             LabelEdition.this.win.pack();
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelEdition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */