/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.measure.IntrinsicVolumes3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterfaceSurfaceArea3D
/*     */   implements PlugIn
/*     */ {
/*  52 */   private static final String[] surfaceAreaMethods = new String[] {
/*  53 */       "Crofton  (3 dirs.)", 
/*  54 */       "Crofton (13 dirs.)"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static final int[] dirNumbers = new int[] {
/*  61 */       3, 13
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   String surfaceAreaMethod = surfaceAreaMethods[1];
/*  69 */   int nDirs = 13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String args) {
/*  81 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/*  83 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  85 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  90 */     GenericDialog gd = new GenericDialog("Interface Surface Area");
/*  91 */     gd.addNumericField("Label 1", 1.0D, 0);
/*  92 */     gd.addNumericField("Label 2", 2.0D, 0);
/*  93 */     gd.addMessage("");
/*  94 */     gd.addChoice("Surface_area_method:", surfaceAreaMethods, surfaceAreaMethods[1]);
/*  95 */     gd.showDialog();
/*     */ 
/*     */     
/*  98 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 102 */     int label1 = (int)gd.getNextNumber();
/* 103 */     int label2 = (int)gd.getNextNumber();
/* 104 */     this.nDirs = dirNumbers[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 107 */     ImageStack image = imagePlus.getStack();
/* 108 */     Calibration calib = imagePlus.getCalibration();
/*     */     
/* 110 */     double S12 = IntrinsicVolumes3D.interfaceSurfaceArea(image, label1, label2, calib, this.nDirs);
/*     */ 
/*     */     
/* 113 */     ResultsTable table = new ResultsTable();
/* 114 */     table.incrementCounter();
/* 115 */     table.addValue("Label1", label1);
/* 116 */     table.addValue("Label2", label2);
/* 117 */     table.addValue("Interf.Surf", S12);
/*     */ 
/*     */     
/* 120 */     String tableName = String.valueOf(imagePlus.getShortTitle()) + "-Interface";
/*     */ 
/*     */     
/* 123 */     table.show(tableName);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InterfaceSurfaceArea3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */