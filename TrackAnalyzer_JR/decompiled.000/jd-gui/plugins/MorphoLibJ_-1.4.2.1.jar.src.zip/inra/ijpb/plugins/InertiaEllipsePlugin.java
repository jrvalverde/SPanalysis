/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.gui.Line;
/*     */ import ij.gui.Overlay;
/*     */ import ij.gui.PolygonRoi;
/*     */ import ij.gui.Roi;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.geometry.Ellipse;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.InertiaEllipse;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class InertiaEllipsePlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String args) {
/*  70 */     int[] indices = WindowManager.getIDList();
/*  71 */     if (indices == null) {
/*     */       
/*  73 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  78 */     String[] imageNames = new String[indices.length];
/*  79 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  81 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  85 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  88 */     GenericDialog gd = new GenericDialog("Inertia Ellipse");
/*  89 */     gd.addChoice("Label Image:", imageNames, selectedImageName);
/*  90 */     gd.addCheckbox("Overlay Ellipse", true);
/*  91 */     gd.addCheckbox("Overlay Axes", true);
/*  92 */     gd.addChoice("Image to overlay:", imageNames, selectedImageName);
/*  93 */     gd.showDialog();
/*     */     
/*  95 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     int labelImageIndex = gd.getNextChoiceIndex();
/* 100 */     ImagePlus labelImage = WindowManager.getImage(labelImageIndex + 1);
/* 101 */     boolean showEllipse = gd.getNextBoolean();
/* 102 */     boolean showAxes = gd.getNextBoolean();
/* 103 */     int resultImageIndex = gd.getNextChoiceIndex();
/*     */ 
/*     */     
/* 106 */     if (!LabelImages.isLabelImageType(labelImage)) {
/*     */       
/* 108 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 113 */     InertiaEllipse op = new InertiaEllipse();
/* 114 */     Map<Integer, Ellipse> ellipses = op.analyzeRegions(labelImage);
/* 115 */     ResultsTable results = op.createTable(ellipses);
/*     */ 
/*     */     
/* 118 */     String tableName = String.valueOf(labelImage.getShortTitle()) + "-Ellipses";
/* 119 */     results.show(tableName);
/*     */ 
/*     */     
/* 122 */     if (showEllipse || showAxes) {
/*     */ 
/*     */       
/* 125 */       ImagePlus resultImage = WindowManager.getImage(resultImageIndex + 1);
/* 126 */       showResultsAsOverlay(ellipses, resultImage, showEllipse, showAxes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void showResultsAsOverlay(Map<Integer, Ellipse> results, ImagePlus target, boolean showEllipse, boolean showAxes) {
/* 144 */     Calibration calib = target.getCalibration();
/*     */ 
/*     */     
/* 147 */     Overlay overlay = new Overlay();
/*     */ 
/*     */     
/* 150 */     for (Iterator<Integer> iterator = results.keySet().iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */ 
/*     */       
/* 153 */       Ellipse ellipse = results.get(Integer.valueOf(label));
/* 154 */       ellipse = uncalibrate(ellipse, calib);
/*     */ 
/*     */       
/* 157 */       if (showEllipse)
/*     */       {
/* 159 */         addRoiToOverlay(overlay, createRoi(ellipse), Color.BLUE);
/*     */       }
/*     */ 
/*     */       
/* 163 */       if (showAxes) {
/*     */         
/* 165 */         addRoiToOverlay(overlay, createMajorAxisRoi(ellipse), Color.BLUE);
/* 166 */         addRoiToOverlay(overlay, createMinorAxisRoi(ellipse), Color.BLUE);
/*     */       }  }
/*     */ 
/*     */     
/* 170 */     target.setOverlay(overlay);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void addRoiToOverlay(Overlay overlay, Roi roi, Color color) {
/* 175 */     roi.setStrokeColor(color);
/* 176 */     overlay.add(roi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Ellipse uncalibrate(Ellipse ellipse, Calibration calib) {
/* 191 */     Point2D center = ellipse.center();
/* 192 */     double xc = (center.getX() - calib.xOrigin) / calib.pixelWidth;
/* 193 */     double yc = (center.getY() - calib.yOrigin) / calib.pixelHeight;
/* 194 */     double radius1 = ellipse.radius1() / calib.pixelWidth;
/* 195 */     double radius2 = ellipse.radius2() / calib.pixelWidth;
/* 196 */     return new Ellipse(xc, yc, radius1, radius2, ellipse.orientation());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createRoi(Ellipse ellipse) {
/* 202 */     Point2D center = ellipse.center();
/* 203 */     double xc = center.getX();
/* 204 */     double yc = center.getY();
/*     */     
/* 206 */     double r1 = ellipse.radius1();
/* 207 */     double r2 = ellipse.radius2();
/* 208 */     double theta = Math.toRadians(ellipse.orientation());
/*     */     
/* 210 */     double cot = Math.cos(theta);
/* 211 */     double sit = Math.sin(theta);
/*     */     
/* 213 */     int nVertices = 100;
/* 214 */     float[] xv = new float[nVertices];
/* 215 */     float[] yv = new float[nVertices];
/* 216 */     for (int i = 0; i < nVertices; i++) {
/*     */       
/* 218 */       double t = i * Math.PI * 2.0D / nVertices;
/* 219 */       double x = Math.cos(t) * r1;
/* 220 */       double y = Math.sin(t) * r2;
/*     */       
/* 222 */       xv[i] = (float)(x * cot - y * sit + xc);
/* 223 */       yv[i] = (float)(x * sit + y * cot + yc);
/*     */     } 
/*     */     
/* 226 */     return (Roi)new PolygonRoi(xv, yv, nVertices, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createMajorAxisRoi(Ellipse ellipse) {
/* 232 */     Point2D center = ellipse.center();
/* 233 */     double xc = center.getX();
/* 234 */     double yc = center.getY();
/*     */     
/* 236 */     double r1 = ellipse.radius1();
/* 237 */     double theta = Math.toRadians(ellipse.orientation());
/*     */     
/* 239 */     double cot = Math.cos(theta);
/* 240 */     double sit = Math.sin(theta);
/*     */     
/* 242 */     double x1 = xc + r1 * cot;
/* 243 */     double y1 = yc + r1 * sit;
/* 244 */     double x2 = xc - r1 * cot;
/* 245 */     double y2 = yc - r1 * sit;
/* 246 */     return (Roi)new Line(x1, y1, x2, y2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Roi createMinorAxisRoi(Ellipse ellipse) {
/* 252 */     Point2D center = ellipse.center();
/* 253 */     double xc = center.getX();
/* 254 */     double yc = center.getY();
/*     */     
/* 256 */     double r2 = ellipse.radius2();
/* 257 */     double theta = Math.toRadians(ellipse.orientation() + 90.0D);
/*     */     
/* 259 */     double cot = Math.cos(theta);
/* 260 */     double sit = Math.sin(theta);
/*     */     
/* 262 */     double x1 = xc + r2 * cot;
/* 263 */     double y1 = yc + r2 * sit;
/* 264 */     double x2 = xc - r2 * cot;
/* 265 */     double y2 = yc - r2 * sit;
/* 266 */     return (Roi)new Line(x1, y1, x2, y2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InertiaEllipsePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */