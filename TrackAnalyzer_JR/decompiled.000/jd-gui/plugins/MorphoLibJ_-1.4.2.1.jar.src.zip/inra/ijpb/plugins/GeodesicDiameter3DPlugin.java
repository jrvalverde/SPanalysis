/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.binary.geodesic.GeodesicDiameter3DFloat;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeodesicDiameter3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  59 */     int[] indices = WindowManager.getIDList();
/*  60 */     if (indices == null) {
/*     */       
/*  62 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  67 */     String[] imageNames = new String[indices.length];
/*  68 */     for (int i = 0; i < indices.length; i++)
/*     */     {
/*  70 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/*  74 */     String selectedImageName = IJ.getImage().getTitle();
/*     */ 
/*     */     
/*  77 */     GenericDialog gd = new GenericDialog("Geodesic Diameter 3D");
/*  78 */     gd.addChoice("Label Image (3D):", imageNames, selectedImageName);
/*     */     
/*  80 */     gd.addChoice("Distances", ChamferWeights3D.getAllLabels(), 
/*  81 */         ChamferWeights3D.WEIGHTS_3_4_5_7.toString());
/*  82 */     gd.showDialog();
/*     */     
/*  84 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  88 */     int labelImageIndex = gd.getNextChoiceIndex();
/*  89 */     ImagePlus labelPlus = WindowManager.getImage(labelImageIndex + 1);
/*  90 */     ChamferWeights3D weights = ChamferWeights3D.fromLabel(gd.getNextChoice());
/*     */ 
/*     */     
/*  93 */     if (!LabelImages.isLabelImageType(labelPlus)) {
/*     */       
/*  95 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 100 */     ImageStack labelImage = labelPlus.getStack();
/*     */ 
/*     */     
/* 103 */     long start = System.nanoTime();
/* 104 */     ResultsTable table = process(labelImage, weights.getFloatWeights());
/* 105 */     long finalTime = System.nanoTime();
/*     */ 
/*     */     
/* 108 */     float elapsedTime = (float)(finalTime - start) / 1000000.0F;
/*     */ 
/*     */     
/* 111 */     String tableName = String.valueOf(labelPlus.getShortTitle()) + "-GeodDiameters";
/* 112 */     table.show(tableName);
/*     */     
/* 114 */     IJUtils.showElapsedTime("Geodesic Diameter 3D", (long)elapsedTime, labelPlus);
/*     */ 
/*     */ 
/*     */     
/* 118 */     int gdIndex = table.getColumnIndex("Geod. Diam.");
/* 119 */     double[] geodDiamArray = table.getColumnAsDoubles(gdIndex); byte b;
/*     */     int j;
/*     */     double[] arrayOfDouble1;
/* 122 */     for (j = (arrayOfDouble1 = geodDiamArray).length, b = 0; b < j; ) { double geodDiam = arrayOfDouble1[b];
/*     */       
/* 124 */       if (Float.isInfinite((float)geodDiam)) {
/*     */         
/* 126 */         IJ.showMessage("Geodesic Diameter Warning", "Some geodesic diameters are infinite,\nmeaning that some particles are not connected.\nMaybe labeling was not performed?");
/*     */         break;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImageStack labels, float[] weights) {
/* 150 */     GeodesicDiameter3DFloat algo = new GeodesicDiameter3DFloat(weights);
/* 151 */     DefaultAlgoListener.monitor((Algo)algo);
/* 152 */     ResultsTable table = algo.process(labels);
/* 153 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GeodesicDiameter3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */