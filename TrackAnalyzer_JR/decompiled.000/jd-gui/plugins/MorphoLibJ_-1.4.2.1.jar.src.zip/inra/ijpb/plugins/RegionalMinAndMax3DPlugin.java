/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionalMinAndMax3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  48 */     REGIONAL_MAXIMA("Regional Maxima", "rmax"),
/*  49 */     REGIONAL_MINIMA("Regional Minima", "rmin");
/*     */     
/*     */     private final String label;
/*     */     private final String suffix;
/*     */     
/*     */     Operation(String label, String suffix) {
/*  55 */       this.label = label;
/*  56 */       this.suffix = suffix;
/*     */     }
/*     */     
/*     */     public ImageStack apply(ImageStack image, int connectivity) {
/*  60 */       if (this == REGIONAL_MAXIMA)
/*  61 */         return MinimaAndMaxima3D.regionalMaxima(image, connectivity); 
/*  62 */       if (this == REGIONAL_MINIMA) {
/*  63 */         return MinimaAndMaxima3D.regionalMinima(image, connectivity);
/*     */       }
/*  65 */       throw new RuntimeException(
/*  66 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  70 */       return this.label;
/*     */     }
/*     */     
/*     */     public String getSuffix() {
/*  74 */       return this.suffix;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  78 */       int n = (values()).length;
/*  79 */       String[] result = new String[n];
/*     */       
/*  81 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  82 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  83 */         result[i++] = op.label; b++; }
/*     */       
/*  85 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  98 */       if (opLabel != null)
/*  99 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 100 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 101 */         String cmp = op.label.toLowerCase();
/* 102 */         if (cmp.equals(opLabel))
/* 103 */           return op;  b++; }
/*     */       
/* 105 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 109 */   private static final String[] connectivityLabels = new String[] { "6", "26" };
/* 110 */   private static final int[] connectivityValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 116 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/* 118 */     if (imagePlus.getStackSize() == 1) {
/* 119 */       IJ.error("Requires a Stack");
/*     */     }
/*     */     
/* 122 */     ImageStack stack = imagePlus.getStack();
/*     */ 
/*     */     
/* 125 */     GenericDialog gd = new GenericDialog("Regional Min & Max 3D");
/* 126 */     gd.addChoice("Operation", Operation.getAllLabels(), 
/* 127 */         Operation.REGIONAL_MINIMA.label);
/* 128 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/*     */     
/* 130 */     gd.showDialog();
/* 131 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 135 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 136 */     int conn = connectivityValues[gd.getNextChoiceIndex()];
/*     */     
/* 138 */     long t0 = System.currentTimeMillis();
/*     */     
/* 140 */     ImageStack result = op.apply(stack, conn);
/*     */     
/* 142 */     String newName = createResultImageName(imagePlus, op);
/* 143 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/* 144 */     resultPlus.copyScale(imagePlus);
/* 145 */     resultPlus.show();
/*     */     
/* 147 */     resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     
/* 149 */     long t1 = System.currentTimeMillis();
/* 150 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), imagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createResultImageName(ImagePlus baseImage, Operation op) {
/* 158 */     return String.valueOf(baseImage.getShortTitle()) + "-" + op.getSuffix();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RegionalMinAndMax3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */