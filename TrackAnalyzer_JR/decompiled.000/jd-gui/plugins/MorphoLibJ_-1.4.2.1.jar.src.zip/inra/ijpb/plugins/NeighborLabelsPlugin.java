/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.morphology.strel.CubeStrel;
/*     */ import inra.ijpb.morphology.strel.SquareStrel;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeighborLabelsPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   ImagePlus labelImagePlus;
/*     */   ImagePlus resultPlus;
/*  61 */   GenericDialog gd = null;
/*     */ 
/*     */ 
/*     */   
/*  65 */   String labelString = "";
/*     */ 
/*     */   
/*     */   int[] labelList;
/*     */ 
/*     */   
/*  71 */   int radius = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean keepInitialLabels = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg0) {
/*  85 */     this.labelImagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  88 */     initResultImage();
/*     */ 
/*     */     
/*  91 */     createDialog();
/*  92 */     this.gd.showDialog();
/*     */ 
/*     */     
/*  95 */     if (this.gd.wasCanceled())
/*     */       return; 
/*  97 */     parseDialogOptions();
/*     */     
/*  99 */     ImagePlus resultPlus = computeResultImage();
/* 100 */     if (resultPlus == null) {
/*     */       return;
/*     */     }
/* 103 */     this.resultPlus.copyScale(this.labelImagePlus);
/*     */     
/* 105 */     String newName = String.valueOf(this.labelImagePlus.getShortTitle()) + "-NeighborLabels";
/* 106 */     resultPlus.setTitle(newName);
/* 107 */     resultPlus.show();
/*     */ 
/*     */     
/* 110 */     if (this.labelImagePlus.getStackSize() > 1)
/*     */     {
/* 112 */       resultPlus.setSlice(this.labelImagePlus.getCurrentSlice());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void initResultImage() {
/* 118 */     if (this.labelImagePlus.getStackSize() == 1) {
/*     */       
/* 120 */       ImageProcessor labelImage = this.labelImagePlus.getProcessor();
/* 121 */       int sizeX = labelImage.getWidth();
/* 122 */       int sizeY = labelImage.getHeight();
/*     */       
/* 124 */       FloatProcessor floatProcessor = new FloatProcessor(sizeX, sizeY);
/* 125 */       this.resultPlus = new ImagePlus("Result", (ImageProcessor)floatProcessor);
/*     */     }
/*     */     else {
/*     */       
/* 129 */       ImageStack labelImage = this.labelImagePlus.getStack();
/* 130 */       int sizeX = labelImage.getWidth();
/* 131 */       int sizeY = labelImage.getHeight();
/* 132 */       int sizeZ = labelImage.getSize();
/*     */       
/* 134 */       ImageStack resultImage = ImageStack.create(sizeX, sizeY, sizeZ, 32);
/* 135 */       this.resultPlus = new ImagePlus("Result", resultImage);
/*     */     } 
/*     */     
/* 138 */     this.resultPlus.copyScale(this.labelImagePlus);
/*     */   }
/*     */ 
/*     */   
/*     */   private GenericDialog createDialog() {
/* 143 */     this.gd = new GenericDialog("Extract Neighbor Label");
/* 144 */     this.gd.addStringField("Labels", "0");
/* 145 */     this.gd.addMessage("Add labels seperated by comma.\nEx: [1, 2, 6, 9]");
/* 146 */     this.gd.addNumericField("Radius", 2.0D, 0, 10, null);
/* 147 */     this.gd.addCheckbox("Keep Initial Labels", false);
/* 148 */     return this.gd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDialogOptions() {
/* 156 */     this.labelString = this.gd.getNextString();
/* 157 */     this.labelList = IJUtils.parseLabelList(this.labelString);
/*     */     
/* 159 */     this.radius = (int)this.gd.getNextNumber();
/*     */     
/* 161 */     this.keepInitialLabels = this.gd.getNextBoolean();
/*     */   }
/*     */   
/*     */   private ImagePlus computeResultImage() {
/*     */     Set<Integer> labelSet;
/* 166 */     int[] labels = IJUtils.parseLabelList(this.labelString);
/*     */ 
/*     */ 
/*     */     
/* 170 */     if (this.resultPlus.getStackSize() == 1) {
/*     */ 
/*     */       
/* 173 */       ImageProcessor labelImage = this.labelImagePlus.getProcessor();
/*     */ 
/*     */       
/* 176 */       ImageProcessor mask = selectedLabelsToMask(labelImage, labels);
/*     */ 
/*     */       
/* 179 */       SquareStrel squareStrel = SquareStrel.fromRadius(this.radius);
/* 180 */       mask = squareStrel.dilation(mask);
/*     */ 
/*     */       
/* 183 */       labelSet = findLabelsWithinMask(labelImage, mask);
/*     */     }
/*     */     else {
/*     */       
/* 187 */       ImageStack labelImage = this.labelImagePlus.getStack();
/*     */ 
/*     */       
/* 190 */       ImageStack mask = selectedLabelsToMask(labelImage, labels);
/*     */ 
/*     */       
/* 193 */       CubeStrel cubeStrel = CubeStrel.fromRadius(this.radius);
/* 194 */       mask = cubeStrel.dilation(mask);
/*     */ 
/*     */       
/* 197 */       labelSet = findLabelsWithinMask(labelImage, mask);
/*     */     } 
/*     */ 
/*     */     
/* 201 */     if (labelSet.contains(Integer.valueOf(0)))
/*     */     {
/* 203 */       labelSet.remove(Integer.valueOf(0));
/*     */     }
/*     */ 
/*     */     
/* 207 */     if (!this.keepInitialLabels) {
/*     */       byte b; int i; int[] arrayOfInt;
/* 209 */       for (i = (arrayOfInt = labels).length, b = 0; b < i; ) { int label = arrayOfInt[b];
/*     */         
/* 211 */         labelSet.remove(Integer.valueOf(label));
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 216 */     int[] labelsToKeep = new int[labelSet.size()];
/* 217 */     int ind = 0;
/* 218 */     for (Iterator<Integer> iterator = labelSet.iterator(); iterator.hasNext(); ) { int label = ((Integer)iterator.next()).intValue();
/*     */       
/* 220 */       labelsToKeep[ind++] = label; }
/*     */ 
/*     */     
/* 223 */     this.resultPlus = LabelImages.keepLabels(this.labelImagePlus, labelsToKeep);
/*     */     
/* 225 */     return this.resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ImagePlus selectedLabelsToMask(ImagePlus imagePlus, int[] labels) {
/*     */     ImagePlus resultPlus;
/* 241 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-keepLabels";
/*     */ 
/*     */     
/* 244 */     if (imagePlus.getStackSize() == 1) {
/*     */ 
/*     */       
/* 247 */       ImageProcessor image = imagePlus.getProcessor();
/* 248 */       ImageProcessor result = selectedLabelsToMask(image, labels);
/* 249 */       resultPlus = new ImagePlus(newName, result);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 254 */       ImageStack image = imagePlus.getStack();
/* 255 */       ImageStack result = selectedLabelsToMask(image, labels);
/* 256 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */     
/* 259 */     resultPlus.copyScale(imagePlus);
/* 260 */     return resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageProcessor selectedLabelsToMask(ImageProcessor image, int[] labels) {
/* 275 */     int sizeX = image.getWidth();
/* 276 */     int sizeY = image.getHeight();
/*     */     
/* 278 */     ImageProcessor result = image.createProcessor(sizeX, sizeY);
/*     */     
/* 280 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 281 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/* 283 */       labelSet.add(Integer.valueOf(labels[i]));
/*     */     }
/*     */     
/* 286 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 288 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 290 */         int value = (int)image.getf(x, y);
/* 291 */         if (labelSet.contains(Integer.valueOf(value))) {
/* 292 */           result.setf(x, y, 255.0F);
/*     */         }
/*     */       } 
/*     */     } 
/* 296 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ImageStack selectedLabelsToMask(ImageStack image, int[] labels) {
/* 311 */     int sizeX = image.getWidth();
/* 312 */     int sizeY = image.getHeight();
/* 313 */     int sizeZ = image.getSize();
/*     */     
/* 315 */     ImageStack result = ImageStack.create(sizeX, sizeY, sizeZ, image.getBitDepth());
/*     */     
/* 317 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 318 */     for (int i = 0; i < labels.length; i++)
/*     */     {
/* 320 */       labelSet.add(Integer.valueOf(labels[i]));
/*     */     }
/*     */     
/* 323 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 325 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 327 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 329 */           int value = (int)image.getVoxel(x, y, z);
/* 330 */           if (value != 0)
/*     */           {
/* 332 */             if (labelSet.contains(Integer.valueOf(value)))
/* 333 */               result.setVoxel(x, y, z, value); 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 338 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Set<Integer> findLabelsWithinMask(ImageProcessor image, ImageProcessor mask) {
/* 343 */     int sizeX = image.getWidth();
/* 344 */     int sizeY = image.getHeight();
/*     */     
/* 346 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 347 */     for (int y = 0; y < sizeY; y++) {
/*     */       
/* 349 */       for (int x = 0; x < sizeX; x++) {
/*     */         
/* 351 */         if (mask.get(x, y) > 0) {
/*     */           
/* 353 */           int label = (int)image.getf(x, y);
/* 354 */           labelSet.add(Integer.valueOf(label));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 359 */     return labelSet;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Set<Integer> findLabelsWithinMask(ImageStack image, ImageStack mask) {
/* 364 */     int sizeX = image.getWidth();
/* 365 */     int sizeY = image.getHeight();
/* 366 */     int sizeZ = image.getSize();
/*     */     
/* 368 */     TreeSet<Integer> labelSet = new TreeSet<Integer>();
/* 369 */     for (int z = 0; z < sizeZ; z++) {
/*     */       
/* 371 */       for (int y = 0; y < sizeY; y++) {
/*     */         
/* 373 */         for (int x = 0; x < sizeX; x++) {
/*     */           
/* 375 */           if (mask.getVoxel(x, y, z) > 0.0D) {
/*     */             
/* 377 */             int label = (int)image.getVoxel(x, y, z);
/* 378 */             labelSet.add(Integer.valueOf(label));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 384 */     return labelSet;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/NeighborLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */