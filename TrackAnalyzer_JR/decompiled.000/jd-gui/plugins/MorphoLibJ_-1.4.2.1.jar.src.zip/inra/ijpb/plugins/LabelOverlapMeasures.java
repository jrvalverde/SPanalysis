/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.ResultsBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelOverlapMeasures
/*     */   implements PlugIn
/*     */ {
/*  40 */   static int sourceIndex = 0;
/*  41 */   static int targetIndex = 1;
/*  42 */   static String[] measureLabels = new String[] { "Overlap", "Jaccard index", "Dice coefficient", 
/*  43 */       "Volume Similarity", "False Negative Error", "False Positive Error" };
/*     */   
/*  45 */   static boolean[] measureStates = new boolean[] { true, true, true, true, true, true };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/*  51 */     int nbima = WindowManager.getImageCount();
/*     */     
/*  53 */     if (nbima < 2) {
/*     */       
/*  55 */       IJ.error("Label Overlap Measures input error", 
/*  56 */           "ERROR: At least two images need to be open to run Intensity Measures 2D/3D");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  61 */     String[] names = new String[nbima];
/*     */     
/*  63 */     for (int i = 0; i < nbima; i++) {
/*  64 */       names[i] = WindowManager.getImage(i + 1).getTitle();
/*     */     }
/*  66 */     if (sourceIndex > nbima - 1)
/*  67 */       sourceIndex = nbima - 1; 
/*  68 */     if (targetIndex > nbima - 1) {
/*  69 */       targetIndex = nbima - 1;
/*     */     }
/*  71 */     GenericDialog gd = new GenericDialog("Label Overlap Measures");
/*  72 */     gd.addChoice("Source image", names, names[sourceIndex]);
/*  73 */     gd.addChoice("Target image", names, names[targetIndex]);
/*  74 */     gd.addMessage("Label Overlap and Agreement Measures:");
/*  75 */     gd.addCheckboxGroup(measureLabels.length / 2 + 1, 2, measureLabels, 
/*  76 */         measureStates);
/*     */     
/*  78 */     gd.showDialog();
/*     */     
/*  80 */     if (gd.wasOKed()) {
/*     */       
/*  82 */       sourceIndex = gd.getNextChoiceIndex();
/*  83 */       targetIndex = gd.getNextChoiceIndex();
/*     */       
/*  85 */       for (int j = 0; j < measureStates.length; j++) {
/*  86 */         measureStates[j] = gd.getNextBoolean();
/*     */       }
/*  88 */       boolean calculateMeasures = false;
/*  89 */       for (int k = 0; k < 6; k++) {
/*  90 */         if (measureStates[k])
/*  91 */           calculateMeasures = true; 
/*     */       } 
/*  93 */       if (!calculateMeasures) {
/*     */         return;
/*     */       }
/*  96 */       ImagePlus sourceImage = WindowManager.getImage(sourceIndex + 1);
/*  97 */       ImagePlus targetImage = WindowManager.getImage(targetIndex + 1);
/*     */       
/*  99 */       if (sourceImage.getWidth() != targetImage.getWidth() || 
/* 100 */         sourceImage.getHeight() != targetImage.getHeight()) {
/*     */         
/* 102 */         IJ.error("Label Overlap Measures input error", "Error: input and label images must have the same size");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 107 */       ResultsBuilder rb = new ResultsBuilder();
/* 108 */       ResultsTable totalTable = new ResultsTable();
/* 109 */       totalTable.incrementCounter();
/* 110 */       totalTable.setPrecision(6);
/*     */       
/* 112 */       if (measureStates[0]) {
/*     */         
/* 114 */         rb.addResult(LabelImages.getTargetOverlapPerLabel(sourceImage, targetImage));
/* 115 */         totalTable.addValue("TotalOverlap", LabelImages.getTotalOverlap(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 118 */       if (measureStates[1]) {
/*     */         
/* 120 */         rb.addResult(LabelImages.getJaccardIndexPerLabel(sourceImage, targetImage));
/* 121 */         totalTable.addValue("JaccardIndex", LabelImages.getJaccardIndex(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 124 */       if (measureStates[2]) {
/*     */         
/* 126 */         rb.addResult(LabelImages.getDiceCoefficientPerLabel(sourceImage, targetImage));
/* 127 */         totalTable.addValue("DiceCoefficient", LabelImages.getDiceCoefficient(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 130 */       if (measureStates[3]) {
/*     */         
/* 132 */         rb.addResult(LabelImages.getVolumeSimilarityPerLabel(sourceImage, targetImage));
/* 133 */         totalTable.addValue("VolumeSimilarity", LabelImages.getVolumeSimilarity(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 136 */       if (measureStates[4]) {
/*     */         
/* 138 */         rb.addResult(LabelImages.getFalseNegativeErrorPerLabel(sourceImage, targetImage));
/* 139 */         totalTable.addValue("FalseNegativeError", LabelImages.getFalseNegativeError(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 142 */       if (measureStates[5]) {
/*     */         
/* 144 */         rb.addResult(LabelImages.getFalsePositiveErrorPerLabel(sourceImage, targetImage));
/* 145 */         totalTable.addValue("FalsePositiveError", LabelImages.getFalsePositiveError(sourceImage, targetImage));
/*     */       } 
/*     */       
/* 148 */       totalTable.show(String.valueOf(sourceImage.getShortTitle()) + 
/* 149 */           "-all-labels-overlap-measurements");
/*     */       
/* 151 */       rb.getResultsTable().setPrecision(6);
/*     */       
/* 153 */       rb.getResultsTable().show(String.valueOf(sourceImage.getShortTitle()) + 
/* 154 */           "-individual-labels-overlap-measurements");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelOverlapMeasures.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */