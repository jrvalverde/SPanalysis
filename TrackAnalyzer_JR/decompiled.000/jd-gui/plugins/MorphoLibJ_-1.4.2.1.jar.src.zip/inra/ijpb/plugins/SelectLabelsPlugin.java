/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ import inra.ijpb.util.IJUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectLabelsPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public boolean debug = false;
/*    */   ImagePlus imagePlus;
/*    */   
/*    */   public void run(String args) {
/* 63 */     ImagePlus imagePlus = IJ.getImage();
/*    */ 
/*    */     
/* 66 */     GenericDialog gd = new GenericDialog("Select Label(s)");
/* 67 */     gd.addMessage("Add labels seperated by comma.\nEx: [1, 2, 6, 9]");
/* 68 */     gd.addStringField("Label(s)", "1");
/* 69 */     gd.showDialog();
/*    */ 
/*    */     
/* 72 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/*    */     
/* 76 */     String labelString = gd.getNextString();
/*    */     
/* 78 */     int[] labels = IJUtils.parseLabelList(labelString);
/* 79 */     ImagePlus selectedPlus = LabelImages.keepLabels(imagePlus, labels);
/*    */ 
/*    */     
/* 82 */     selectedPlus.copyScale(imagePlus);
/* 83 */     selectedPlus.setDisplayRange(imagePlus.getDisplayRangeMin(), imagePlus.getDisplayRangeMax());
/* 84 */     selectedPlus.setLut(imagePlus.getProcessor().getLut());
/*    */ 
/*    */     
/* 87 */     selectedPlus.show();
/* 88 */     if (imagePlus.getStackSize() > 1)
/*    */     {
/* 90 */       selectedPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/SelectLabelsPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */