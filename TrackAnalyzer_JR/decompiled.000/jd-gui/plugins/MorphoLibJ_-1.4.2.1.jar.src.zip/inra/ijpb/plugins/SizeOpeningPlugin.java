/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.binary.BinaryImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SizeOpeningPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg0) {
/*  46 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  49 */     boolean isPlanar = (imagePlus.getStackSize() == 1);
/*  50 */     String title = "Size Opening 2D/3D";
/*  51 */     GenericDialog gd = new GenericDialog(title);
/*  52 */     String label = isPlanar ? "Min Pixel Number:" : "Min Voxel Number:";
/*  53 */     gd.addNumericField(label, 100.0D, 0);
/*  54 */     gd.showDialog();
/*     */ 
/*     */     
/*  57 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*  60 */     int nPixelMin = (int)gd.getNextNumber();
/*     */ 
/*     */     
/*  63 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-sizeOpen";
/*     */     
/*  65 */     if (isPlanar) {
/*     */       
/*  67 */       ImageProcessor image = imagePlus.getProcessor();
/*  68 */       ImageProcessor result = null;
/*     */       
/*     */       try {
/*  71 */         result = BinaryImages.areaOpening(image, nPixelMin);
/*     */       }
/*  73 */       catch (RuntimeException ex) {
/*     */         
/*  75 */         IJ.error("Too many particles", ex.getMessage());
/*     */         
/*     */         return;
/*     */       } 
/*  79 */       if (!(result instanceof ij.process.ColorProcessor))
/*  80 */         result.setLut(image.getLut()); 
/*  81 */       resultPlus = new ImagePlus(newName, result);
/*     */     }
/*     */     else {
/*     */       
/*  85 */       ImageStack image = imagePlus.getStack();
/*  86 */       ImageStack result = null;
/*     */       
/*     */       try {
/*  89 */         result = BinaryImages.volumeOpening(image, nPixelMin);
/*     */       }
/*  91 */       catch (RuntimeException ex) {
/*     */         
/*  93 */         IJ.error("Too many particles", ex.getMessage());
/*     */         return;
/*     */       } 
/*  96 */       result.setColorModel(image.getColorModel());
/*  97 */       resultPlus = new ImagePlus(newName, result);
/*     */     } 
/*     */     
/* 100 */     resultPlus.copyScale(imagePlus);
/* 101 */     resultPlus.show();
/*     */     
/* 103 */     if (imagePlus.getStackSize() > 1)
/* 104 */       resultPlus.setSlice(imagePlus.getCurrentSlice()); 
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/SizeOpeningPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */