/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeepLargestLabelPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 44 */     ImagePlus resultPlus, imagePlus = IJ.getImage();
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 49 */       resultPlus = LabelImages.keepLargestLabel(imagePlus);
/*    */     }
/* 51 */     catch (RuntimeException ex) {
/*    */ 
/*    */       
/* 54 */       IJ.error("MorphoLibJ Error", ex.getMessage());
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 59 */     resultPlus.show();
/* 60 */     if (imagePlus.getStackSize() > 1) {
/* 61 */       resultPlus.setZ(imagePlus.getZ());
/* 62 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/KeepLargestLabelPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */