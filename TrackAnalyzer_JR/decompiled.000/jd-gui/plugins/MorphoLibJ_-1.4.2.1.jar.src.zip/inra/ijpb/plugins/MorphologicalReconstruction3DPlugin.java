/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.Reconstruction3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphologicalReconstruction3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  48 */     BY_DILATION("By Dilation"),
/*  49 */     BY_EROSION("By Erosion");
/*     */     
/*     */     private final String label;
/*     */     
/*     */     Operation(String label) {
/*  54 */       this.label = label;
/*     */     }
/*     */     
/*     */     public ImageStack applyTo(ImageStack marker, ImageStack mask, int conn) {
/*  58 */       if (this == BY_DILATION)
/*  59 */         return Reconstruction3D.reconstructByDilation(marker, mask, conn); 
/*  60 */       if (this == BY_EROSION) {
/*  61 */         return Reconstruction3D.reconstructByErosion(marker, mask, conn);
/*     */       }
/*  63 */       throw new RuntimeException(
/*  64 */           "Unable to process the " + this + " operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  68 */       return this.label;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  72 */       int n = (values()).length;
/*  73 */       String[] result = new String[n];
/*     */       
/*  75 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  76 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  77 */         result[i++] = op.label; b++; }
/*     */       
/*  79 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  92 */       if (opLabel != null)
/*  93 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/*  94 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/*  95 */         String cmp = op.label.toLowerCase();
/*  96 */         if (cmp.equals(opLabel))
/*  97 */           return op;  b++; }
/*     */       
/*  99 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   enum Conn3D
/*     */   {
/* 107 */     C6("6", 6),
/* 108 */     C26("26", 26);
/*     */     
/*     */     private final String label;
/*     */     private final int value;
/*     */     
/*     */     Conn3D(String label, int value) {
/* 114 */       this.label = label;
/* 115 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 119 */       return this.label;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 123 */       return this.value;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/* 127 */       int n = (values()).length;
/* 128 */       String[] result = new String[n];
/*     */       
/* 130 */       int i = 0; byte b; int j; Conn3D[] arrayOfConn3D;
/* 131 */       for (j = (arrayOfConn3D = values()).length, b = 0; b < j; ) { Conn3D op = arrayOfConn3D[b];
/* 132 */         result[i++] = op.label; b++; }
/*     */       
/* 134 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Conn3D fromLabel(String opLabel) {
/* 142 */       if (opLabel != null)
/* 143 */         opLabel = opLabel.toLowerCase();  byte b; int i; Conn3D[] arrayOfConn3D;
/* 144 */       for (i = (arrayOfConn3D = values()).length, b = 0; b < i; ) { Conn3D op = arrayOfConn3D[b];
/* 145 */         String cmp = op.label.toLowerCase();
/* 146 */         if (cmp.equals(opLabel))
/* 147 */           return op;  b++; }
/*     */       
/* 149 */       throw new IllegalArgumentException("Unable to parse Conn2D with label: " + opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg) {
/* 161 */     int[] indices = WindowManager.getIDList();
/* 162 */     if (indices == null) {
/* 163 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 168 */     String[] imageNames = new String[indices.length];
/* 169 */     for (int i = 0; i < indices.length; i++) {
/* 170 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*     */     }
/*     */ 
/*     */     
/* 174 */     GenericDialog gd = new GenericDialog("Morphological Reconstruction 3D");
/*     */     
/* 176 */     gd.addChoice("Marker Image", imageNames, IJ.getImage().getTitle());
/* 177 */     gd.addChoice("Mask Image", imageNames, IJ.getImage().getTitle());
/* 178 */     gd.addChoice("Type of Reconstruction", 
/* 179 */         Operation.getAllLabels(), 
/* 180 */         Operation.BY_DILATION.label);
/* 181 */     gd.addChoice("Connectivity", 
/* 182 */         Conn3D.getAllLabels(), 
/* 183 */         Conn3D.C6.label);
/* 184 */     gd.showDialog();
/*     */     
/* 186 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 190 */     int markerImageIndex = gd.getNextChoiceIndex();
/* 191 */     ImagePlus markerPlus = WindowManager.getImage(markerImageIndex + 1);
/* 192 */     int maskImageIndex = gd.getNextChoiceIndex();
/* 193 */     ImagePlus maskPlus = WindowManager.getImage(maskImageIndex + 1);
/* 194 */     Operation op = Operation.fromLabel(gd.getNextChoice());
/* 195 */     int conn = Conn3D.fromLabel(gd.getNextChoice()).getValue();
/*     */ 
/*     */     
/* 198 */     ImageStack marker = markerPlus.getStack();
/* 199 */     ImageStack mask = maskPlus.getStack();
/* 200 */     if (!Images3D.isSameSize(marker, mask))
/*     */     {
/* 202 */       IJ.error("Image Size Error", "Both marker and mask images must have same size");
/*     */     }
/*     */     
/* 205 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */     
/* 208 */     ImageStack result = op.applyTo(marker, mask, conn);
/*     */ 
/*     */     
/* 211 */     result.setColorModel(mask.getColorModel());
/*     */ 
/*     */     
/* 214 */     String newName = String.valueOf(maskPlus.getShortTitle()) + "-geodRec";
/* 215 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/* 216 */     resultPlus.copyScale(maskPlus);
/* 217 */     resultPlus.show();
/*     */     
/* 219 */     resultPlus.setSlice(maskPlus.getCurrentSlice());
/*     */     
/* 221 */     long t1 = System.currentTimeMillis();
/* 222 */     IJUtils.showElapsedTime(op.toString(), (t1 - t0), markerPlus);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MorphologicalReconstruction3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */