/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.morphology.directional.DirectionalFilter;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectionalFilteringPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*  41 */   private int flags = 16842783;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/*  56 */   DirectionalFilter.Type type = DirectionalFilter.Type.MAX;
/*  57 */   DirectionalFilter.Operation op = DirectionalFilter.Operation.OPENING;
/*  58 */   int lineLength = 20;
/*  59 */   int nDirections = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  66 */     if (arg.equals("final")) {
/*     */ 
/*     */       
/*  69 */       this.imagePlus.setProcessor(this.baseImage);
/*  70 */       this.imagePlus.draw();
/*     */ 
/*     */       
/*  73 */       String newName = String.valueOf(this.imagePlus.getShortTitle()) + "-directional";
/*  74 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/*     */ 
/*     */       
/*  77 */       resPlus.copyScale(this.imagePlus);
/*  78 */       resPlus.show();
/*  79 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/*  83 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/*  90 */     this.imagePlus = imp;
/*  91 */     this.baseImage = imp.getProcessor().duplicate();
/*     */ 
/*     */     
/*  94 */     GenericDialog gd = new GenericDialog("Directional Filtering");
/*     */     
/*  96 */     gd.addChoice("Type", DirectionalFilter.Type.getAllLabels(), this.type.toString());
/*  97 */     gd.addChoice("Operation", DirectionalFilter.Operation.getAllLabels(), this.op.toString());
/*  98 */     gd.addNumericField("Line Length", this.lineLength, 0, 8, "pixels");
/*  99 */     gd.addNumericField("Direction Number", this.nDirections, 0);
/*     */     
/* 101 */     gd.addPreviewCheckbox(pfr);
/* 102 */     gd.addDialogListener(this);
/* 103 */     this.previewing = true;
/*     */     
/* 105 */     gd.showDialog();
/* 106 */     this.previewing = false;
/*     */     
/* 108 */     if (gd.wasCanceled())
/*     */     {
/* 110 */       return 4096;
/*     */     }
/*     */     
/* 113 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 116 */     gd.dispose();
/* 117 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent e) {
/* 123 */     parseDialogParameters(gd);
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 129 */     this.type = DirectionalFilter.Type.fromLabel(gd.getNextChoice());
/* 130 */     this.op = DirectionalFilter.Operation.fromLabel(gd.getNextChoice());
/* 131 */     this.lineLength = (int)gd.getNextNumber();
/* 132 */     this.nDirections = (int)gd.getNextNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 138 */     IJ.log("Run directional filter");
/*     */     
/* 140 */     DirectionalFilter filter = new DirectionalFilter(this.type, this.op, this.lineLength, this.nDirections);
/* 141 */     DefaultAlgoListener.monitor((Algo)filter);
/*     */     
/* 143 */     this.result = filter.process(image);
/*     */     
/* 145 */     if (this.previewing)
/*     */     {
/*     */       
/* 148 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 150 */         image.set(i, this.result.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 158 */     this.nPasses = nPasses;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/DirectionalFilteringPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */