/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.binary.ChamferWeights3D;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3D4WeightsFloat;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3D4WeightsShort;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3DFloat;
/*     */ import inra.ijpb.binary.distmap.DistanceTransform3DShort;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.util.IJUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChamferDistanceMap3DPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg) {
/*     */     DistanceTransform3DShort distanceTransform3DShort;
/*  55 */     ImagePlus imagePlus = WindowManager.getCurrentImage();
/*  56 */     if (imagePlus == null) {
/*     */       
/*  58 */       IJ.error("No image", "Need at least one image to work");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  63 */     GenericDialog gd = new GenericDialog("Chamfer Distance Map 3D");
/*  64 */     gd.addChoice("Distances", ChamferWeights3D.getAllLabels(), 
/*  65 */         ChamferWeights3D.WEIGHTS_3_4_5_7.toString());
/*  66 */     String[] outputTypes = { "32 bits", "16 bits" };
/*  67 */     gd.addChoice("Output Type", outputTypes, outputTypes[0]);
/*  68 */     gd.addCheckbox("Normalize weights", true);
/*  69 */     gd.showDialog();
/*     */ 
/*     */     
/*  72 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  76 */     String weightLabel = gd.getNextChoice();
/*  77 */     boolean floatProcessing = (gd.getNextChoiceIndex() == 0);
/*  78 */     boolean normalize = gd.getNextBoolean();
/*     */ 
/*     */     
/*  81 */     ChamferWeights3D chamferWeights = ChamferWeights3D.fromLabel(weightLabel);
/*     */     
/*  83 */     long t0 = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     if (floatProcessing) {
/*     */       
/*  90 */       float[] weights = chamferWeights.getFloatWeights();
/*  91 */       if (weights.length == 4)
/*     */       {
/*  93 */         DistanceTransform3D4WeightsFloat distanceTransform3D4WeightsFloat = new DistanceTransform3D4WeightsFloat(weights, normalize);
/*     */       }
/*     */       else
/*     */       {
/*  97 */         DistanceTransform3DFloat distanceTransform3DFloat = new DistanceTransform3DFloat(weights, normalize);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 102 */       short[] weights = chamferWeights.getShortWeights();
/* 103 */       if (weights.length == 4) {
/*     */         
/* 105 */         DistanceTransform3D4WeightsShort distanceTransform3D4WeightsShort = new DistanceTransform3D4WeightsShort(weights, normalize);
/*     */       }
/*     */       else {
/*     */         
/* 109 */         distanceTransform3DShort = new DistanceTransform3DShort(weights, normalize);
/*     */       } 
/*     */     } 
/* 112 */     DefaultAlgoListener.monitor((Algo)distanceTransform3DShort);
/*     */     
/* 114 */     ImageStack image = imagePlus.getStack();
/* 115 */     ImageStack res = distanceTransform3DShort.distanceMap(image);
/*     */     
/* 117 */     if (res == null) {
/*     */       return;
/*     */     }
/* 120 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-dist";
/* 121 */     ImagePlus resPlus = new ImagePlus(newName, res);
/*     */ 
/*     */     
/* 124 */     double[] distExtent = Images3D.findMinAndMax(resPlus);
/* 125 */     resPlus.setDisplayRange(0.0D, distExtent[1]);
/*     */ 
/*     */     
/* 128 */     resPlus.copyScale(imagePlus);
/*     */ 
/*     */     
/* 131 */     resPlus.show();
/* 132 */     resPlus.setSlice(imagePlus.getCurrentSlice());
/*     */ 
/*     */     
/* 135 */     long t1 = System.currentTimeMillis();
/* 136 */     IJUtils.showElapsedTime("distance map", (t1 - t0), imagePlus);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/ChamferDistanceMap3DPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */