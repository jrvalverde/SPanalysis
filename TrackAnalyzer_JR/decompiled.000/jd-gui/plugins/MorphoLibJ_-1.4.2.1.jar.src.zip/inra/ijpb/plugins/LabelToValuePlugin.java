/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.WindowManager;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.FloatProcessor;
/*     */ import ij.process.ImageProcessor;
/*     */ import ij.text.TextPanel;
/*     */ import ij.text.TextWindow;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Frame;
/*     */ import java.awt.TextField;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelToValuePlugin
/*     */   implements PlugIn, DialogListener
/*     */ {
/*     */   ImagePlus labelImagePlus;
/*     */   ImagePlus resultPlus;
/*  59 */   ResultsTable table = null;
/*     */ 
/*     */   
/*  62 */   GenericDialog gd = null;
/*     */   
/*  64 */   String selectedHeaderName = null;
/*     */   
/*     */   double minValue;
/*     */   
/*     */   double maxValue;
/*     */   
/*  70 */   int nDigits = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg0) {
/*  79 */     this.labelImagePlus = IJ.getImage();
/*     */ 
/*     */     
/*  82 */     TextWindow[] textWindows = getTableWindows();
/*  83 */     if (textWindows.length == 0) {
/*     */       
/*  85 */       IJ.error("Requires at least one Table window");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  90 */     initResultImage();
/*     */ 
/*     */     
/*  93 */     createDialog();
/*  94 */     this.gd.showDialog();
/*     */ 
/*     */     
/*  97 */     if (this.gd.wasCanceled())
/*     */       return; 
/*  99 */     parseDialogOptions();
/*     */     
/* 101 */     ImagePlus resultPlus = computeResultImage();
/* 102 */     if (resultPlus == null) {
/*     */       return;
/*     */     }
/* 105 */     this.resultPlus.copyScale(this.labelImagePlus);
/*     */     
/* 107 */     String newName = String.valueOf(this.labelImagePlus.getShortTitle()) + "-" + this.selectedHeaderName;
/* 108 */     resultPlus.setTitle(newName);
/* 109 */     resultPlus.show();
/*     */ 
/*     */     
/* 112 */     if (this.labelImagePlus.getStackSize() > 1)
/*     */     {
/* 114 */       resultPlus.setSlice(this.labelImagePlus.getCurrentSlice());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void initResultImage() {
/* 120 */     if (this.labelImagePlus.getStackSize() == 1) {
/*     */       
/* 122 */       ImageProcessor labelImage = this.labelImagePlus.getProcessor();
/* 123 */       int sizeX = labelImage.getWidth();
/* 124 */       int sizeY = labelImage.getHeight();
/*     */       
/* 126 */       FloatProcessor floatProcessor = new FloatProcessor(sizeX, sizeY);
/* 127 */       this.resultPlus = new ImagePlus("Result", (ImageProcessor)floatProcessor);
/*     */     }
/*     */     else {
/*     */       
/* 131 */       ImageStack labelImage = this.labelImagePlus.getStack();
/* 132 */       int sizeX = labelImage.getWidth();
/* 133 */       int sizeY = labelImage.getHeight();
/* 134 */       int sizeZ = labelImage.getSize();
/*     */       
/* 136 */       ImageStack resultImage = ImageStack.create(sizeX, sizeY, sizeZ, 32);
/* 137 */       this.resultPlus = new ImagePlus("Result", resultImage);
/*     */     } 
/*     */     
/* 140 */     this.resultPlus.copyScale(this.labelImagePlus);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericDialog createDialog() {
/* 146 */     TextWindow[] textWindows = getTableWindows();
/* 147 */     if (textWindows.length == 0) {
/*     */       
/* 149 */       IJ.error("Requires at least one Table window");
/* 150 */       return null;
/*     */     } 
/* 152 */     String[] tableNames = new String[textWindows.length];
/* 153 */     for (int i = 0; i < textWindows.length; i++) {
/* 154 */       tableNames[i] = textWindows[i].getTitle();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 159 */     TextPanel tp = textWindows[0].getTextPanel();
/* 160 */     ResultsTable table = tp.getResultsTable();
/* 161 */     this.table = table;
/*     */ 
/*     */     
/* 164 */     String[] headings = table.getHeadings();
/* 165 */     String defaultHeading = headings[0];
/* 166 */     if (defaultHeading.equals("Label") && headings.length > 1)
/*     */     {
/* 168 */       defaultHeading = headings[1];
/*     */     }
/*     */     
/* 171 */     double[] extent = computeColumnExtent(table, defaultHeading);
/*     */     
/* 173 */     this.gd = new GenericDialog("Assign Measure to Label");
/* 174 */     this.gd.addChoice("Results Table:", tableNames, tableNames[0]);
/* 175 */     this.gd.addChoice("Column:", headings, defaultHeading);
/* 176 */     this.gd.addNumericField("Min Value", extent[0], this.nDigits, 10, null);
/* 177 */     this.gd.addNumericField("Max Value", extent[1], this.nDigits, 10, null);
/* 178 */     this.gd.addDialogListener(this);
/*     */     
/* 180 */     return this.gd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final TextWindow[] getTableWindows() {
/* 189 */     Frame[] frames = WindowManager.getNonImageWindows();
/*     */     
/* 191 */     ArrayList<TextWindow> windows = new ArrayList<TextWindow>(frames.length); byte b; int i;
/*     */     Frame[] arrayOfFrame1;
/* 193 */     for (i = (arrayOfFrame1 = frames).length, b = 0; b < i; ) { Frame frame = arrayOfFrame1[b];
/*     */       
/* 195 */       if (frame instanceof TextWindow) {
/*     */         
/* 197 */         TextWindow tw = (TextWindow)frame;
/* 198 */         if (tw.getTextPanel().getResultsTable() != null)
/*     */         {
/* 200 */           windows.add(tw);
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */     
/* 205 */     return windows.<TextWindow>toArray(new TextWindow[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDialogOptions() {
/* 213 */     String tableName = this.gd.getNextChoice();
/* 214 */     Frame tableFrame = WindowManager.getFrame(tableName);
/* 215 */     this.table = ((TextWindow)tableFrame).getTextPanel().getResultsTable();
/*     */     
/* 217 */     this.selectedHeaderName = this.gd.getNextChoice();
/*     */     
/* 219 */     this.minValue = this.gd.getNextNumber();
/* 220 */     this.maxValue = this.gd.getNextNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImagePlus computeResultImage() {
/* 226 */     double[] values = getColumnValues(this.table, this.selectedHeaderName);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 231 */       if (this.resultPlus.getStackSize() == 1)
/*     */       {
/* 233 */         ImageProcessor labelImage = this.labelImagePlus.getProcessor();
/* 234 */         FloatProcessor floatProcessor = LabelImages.applyLut(labelImage, values);
/* 235 */         this.resultPlus.setProcessor((ImageProcessor)floatProcessor);
/*     */       }
/*     */       else
/*     */       {
/* 239 */         ImageStack labelImage = this.labelImagePlus.getStack();
/* 240 */         ImageStack resultImage = LabelImages.applyLut(labelImage, values);
/* 241 */         this.resultPlus.setStack(resultImage);
/*     */       }
/*     */     
/* 244 */     } catch (RuntimeException ex) {
/*     */       
/* 246 */       IJ.error("Label to value error", 
/* 247 */           "ERROR: label image values do not \ncorrespond with table values!");
/* 248 */       return null;
/*     */     } 
/*     */     
/* 251 */     this.resultPlus.setDisplayRange(this.minValue, this.maxValue);
/* 252 */     return this.resultPlus;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 258 */     if (gd.wasCanceled() || gd.wasOKed())
/*     */     {
/* 260 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 264 */     Vector<Choice> choices = gd.getChoices();
/* 265 */     if (choices == null) {
/*     */       
/* 267 */       IJ.log("empty choices array...");
/* 268 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 272 */     if (evt.getSource() == choices.get(0)) {
/*     */       
/* 274 */       String tableName = ((Choice)evt.getSource()).getSelectedItem();
/* 275 */       Frame tableFrame = WindowManager.getFrame(tableName);
/* 276 */       this.table = ((TextWindow)tableFrame).getTextPanel().getResultsTable();
/*     */ 
/*     */       
/* 279 */       String[] headings = this.table.getHeadings();
/* 280 */       String defaultHeading = headings[0];
/* 281 */       if (defaultHeading.equals("Label") && headings.length > 1)
/*     */       {
/* 283 */         defaultHeading = headings[1];
/*     */       }
/*     */       
/* 286 */       Choice headingChoice = choices.get(1);
/* 287 */       headingChoice.removeAll(); byte b; int i; String[] arrayOfString1;
/* 288 */       for (i = (arrayOfString1 = headings).length, b = 0; b < i; ) { String heading = arrayOfString1[b];
/*     */         
/* 290 */         headingChoice.add(heading); b++; }
/*     */       
/* 292 */       headingChoice.select(defaultHeading);
/*     */       
/* 294 */       changeColumnHeader(defaultHeading);
/*     */     } 
/*     */ 
/*     */     
/* 298 */     if (evt.getSource() == choices.get(1)) {
/*     */       
/* 300 */       String headerName = ((Choice)evt.getSource()).getSelectedItem();
/* 301 */       changeColumnHeader(headerName);
/*     */     } 
/*     */     
/* 304 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void changeColumnHeader(String headerName) {
/* 309 */     double[] extent = computeColumnExtent(this.table, headerName);
/* 310 */     this.minValue = extent[0];
/* 311 */     this.maxValue = extent[1];
/*     */     
/* 313 */     updateMinMaxFields(extent[0], extent[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMinMaxFields(double minValue, double maxValue) {
/* 328 */     Vector<TextField> numericFields = this.gd.getNumericFields();
/*     */ 
/*     */     
/* 331 */     TextField tf = numericFields.get(0);
/* 332 */     tf.setText(IJ.d2s(minValue, this.nDigits));
/* 333 */     tf = numericFields.get(1);
/* 334 */     tf.setText(IJ.d2s(maxValue, this.nDigits));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] computeColumnExtent(ResultsTable table, String heading) {
/* 344 */     double[] values = getColumnValues(table, heading);
/*     */     
/* 346 */     double minVal = Double.MAX_VALUE;
/* 347 */     double maxVal = Double.MIN_VALUE; byte b; int i; double[] arrayOfDouble1;
/* 348 */     for (i = (arrayOfDouble1 = values).length, b = 0; b < i; ) { double v = arrayOfDouble1[b];
/*     */       
/* 350 */       minVal = Math.min(minVal, v);
/* 351 */       maxVal = Math.max(maxVal, v); b++; }
/*     */     
/* 353 */     return new double[] { minVal, maxVal };
/*     */   }
/*     */ 
/*     */   
/*     */   private double[] getColumnValues(ResultsTable table, String heading) {
/* 358 */     String[] allHeaders = table.getHeadings();
/*     */ 
/*     */     
/* 361 */     boolean hasRowLabels = hasRowLabelColumn(table);
/* 362 */     if (hasRowLabels && heading.equals(allHeaders[0])) {
/*     */ 
/*     */       
/* 365 */       int nr = table.size();
/* 366 */       double[] values = new double[nr];
/* 367 */       for (int r = 0; r < nr; r++) {
/*     */         
/* 369 */         String label = table.getLabel(r);
/* 370 */         values[r] = Double.parseDouble(label);
/*     */       } 
/* 372 */       return values;
/*     */     } 
/*     */ 
/*     */     
/* 376 */     int index = table.getColumnIndex(heading);
/* 377 */     if (index == -1)
/*     */     {
/* 379 */       throw new RuntimeException("Unable to find column index from header: " + heading);
/*     */     }
/* 381 */     return table.getColumnAsDoubles(index);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean hasRowLabelColumn(ResultsTable table) {
/* 386 */     return (table.getLastColumn() == (table.getHeadings()).length - 2);
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelToValuePlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */