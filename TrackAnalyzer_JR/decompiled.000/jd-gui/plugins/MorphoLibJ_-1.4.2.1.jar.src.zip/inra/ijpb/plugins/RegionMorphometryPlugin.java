/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.filter.PlugInFilter;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.GeometricMeasures2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RegionMorphometryPlugin
/*     */   implements PlugInFilter
/*     */ {
/*  43 */   public static final String[] dirNumberLabels = new String[] {
/*  44 */       "2 directions", 
/*  45 */       "4 directions"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final int[] dirNumbers = new int[] {
/*  52 */       2, 4
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean debug = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImagePlus imagePlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  77 */     if (imp == null) {
/*  78 */       IJ.noImage();
/*  79 */       return 4096;
/*     */     } 
/*     */     
/*  82 */     this.imagePlus = imp;
/*  83 */     return 159;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor ip) {
/*  93 */     if (!LabelImages.isLabelImageType(this.imagePlus)) {
/*     */       
/*  95 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 100 */     ResultsTable table = process(this.imagePlus, 4);
/*     */ 
/*     */     
/* 103 */     String tableName = String.valueOf(this.imagePlus.getShortTitle()) + "-Morphometry";
/* 104 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus inputImage, int nDirs) {
/* 110 */     if (inputImage == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     if (this.debug)
/*     */     {
/* 115 */       System.out.println("Compute Crofton perimeter on image '" + 
/* 116 */           inputImage.getTitle());
/*     */     }
/*     */     
/* 119 */     ImageProcessor proc = inputImage.getProcessor();
/*     */ 
/*     */     
/* 122 */     Calibration cal = inputImage.getCalibration();
/* 123 */     double[] resol = { 1.0D, 1.0D };
/* 124 */     if (cal.scaled()) {
/*     */       
/* 126 */       resol[0] = cal.pixelWidth;
/* 127 */       resol[1] = cal.pixelHeight;
/*     */     } 
/*     */     
/* 130 */     ResultsTable results = GeometricMeasures2D.analyzeRegions(proc, resol);
/*     */ 
/*     */     
/* 133 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus inputImage, int nDirs) {
/* 139 */     if (inputImage == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     if (this.debug)
/*     */     {
/* 144 */       System.out.println("Compute Crofton perimeter on image '" + 
/* 145 */           inputImage.getTitle());
/*     */     }
/*     */     
/* 148 */     ImageProcessor proc = inputImage.getProcessor();
/*     */ 
/*     */     
/* 151 */     Calibration cal = inputImage.getCalibration();
/* 152 */     double[] resol = { 1.0D, 1.0D };
/* 153 */     if (cal.scaled()) {
/* 154 */       resol[0] = cal.pixelWidth;
/* 155 */       resol[1] = cal.pixelHeight;
/*     */     } 
/*     */     
/* 158 */     ResultsTable results = GeometricMeasures2D.analyzeRegions(proc, resol);
/*     */ 
/*     */     
/* 161 */     String tableName = String.valueOf(inputImage.getShortTitle()) + "-Morphometry";
/*     */ 
/*     */     
/* 164 */     results.show(tableName);
/*     */ 
/*     */     
/* 167 */     return new Object[] { "Morphometry", results };
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RegionMorphometryPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */