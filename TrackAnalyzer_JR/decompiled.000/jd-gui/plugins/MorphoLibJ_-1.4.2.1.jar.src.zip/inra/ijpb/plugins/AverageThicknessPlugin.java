/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.measure.ResultsTable;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.label.LabelImages;
/*    */ import inra.ijpb.measure.region2d.AverageThickness;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AverageThicknessPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg) {
/* 26 */     ImagePlus currentImage = IJ.getImage();
/*    */ 
/*    */     
/* 29 */     if (!LabelImages.isLabelImageType(currentImage)) {
/*    */       
/* 31 */       IJ.showMessage("Input image should be a label image");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 36 */     AverageThickness op = new AverageThickness();
/* 37 */     Map<Integer, AverageThickness.Result> results = op.analyzeRegions(currentImage);
/*    */ 
/*    */     
/* 40 */     ResultsTable table = op.createTable(results);
/* 41 */     String tableName = String.valueOf(currentImage.getShortTitle()) + "-AvgThickness";
/* 42 */     table.show(tableName);
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/AverageThicknessPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */