/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.filter.PlugInFilter;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.measure.IntrinsicVolumes2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MicrostructureAnalysisPlugin
/*     */   implements PlugInFilter
/*     */ {
/*  42 */   public static final String[] dirNumberLabels = new String[] {
/*  43 */       "Crofton (2 dirs.)", 
/*  44 */       "Crofton (4 dirs.)"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final int[] dirNumbers = new int[] {
/*  51 */       2, 4
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean debug = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImagePlus imagePlus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/*  75 */     if (imp == null) {
/*  76 */       IJ.noImage();
/*  77 */       return 4096;
/*     */     } 
/*     */     
/*  80 */     this.imagePlus = imp;
/*  81 */     return 159;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor ip) {
/*  90 */     GenericDialog gd = new GenericDialog("Binary Microstructure");
/*  91 */     gd.addChoice("Perimeter method:", dirNumberLabels, dirNumberLabels[1]);
/*  92 */     gd.addCheckbox("Add_Porosity", false);
/*  93 */     gd.showDialog();
/*     */ 
/*     */     
/*  96 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     int nDirsIndex = gd.getNextChoiceIndex();
/* 101 */     int nDirs = dirNumbers[nDirsIndex];
/* 102 */     boolean addPorosity = gd.getNextBoolean();
/*     */ 
/*     */     
/* 105 */     if (this.imagePlus.getType() != 0) {
/* 106 */       IJ.showMessage("Input image should be a binary image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 111 */     ResultsTable table = process(this.imagePlus, nDirs, addPorosity);
/*     */ 
/*     */     
/* 114 */     String tableName = String.valueOf(removeImageExtension(this.imagePlus.getShortTitle())) + "-Microstructure";
/* 115 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus image, int nDirs) {
/* 130 */     return exec(image, nDirs, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object[] exec(ImagePlus image, int nDirs, boolean addPorosity) {
/* 151 */     if (image == null) {
/* 152 */       return null;
/*     */     }
/* 154 */     if (this.debug) {
/* 155 */       System.out.println("Compute Crofton densities on image '" + 
/* 156 */           image.getTitle() + "' using " + nDirs + 
/* 157 */           " directions.");
/*     */     }
/*     */     
/* 160 */     ImageProcessor proc = image.getProcessor();
/*     */ 
/*     */     
/* 163 */     Calibration calib = image.getCalibration();
/*     */ 
/*     */     
/* 166 */     double areaDensity = IntrinsicVolumes2D.areaDensity(proc);
/* 167 */     double perimDensity = IntrinsicVolumes2D.perimeterDensity(proc, calib, nDirs);
/* 168 */     ResultsTable table = new ResultsTable();
/* 169 */     table.incrementCounter();
/* 170 */     table.addValue("AreaDensity", areaDensity);
/* 171 */     table.addValue("PerimeterDensity", perimDensity);
/*     */ 
/*     */     
/* 174 */     if (addPorosity)
/*     */     {
/* 176 */       table.addValue("Porosity", 1.0D - areaDensity);
/*     */     }
/*     */ 
/*     */     
/* 180 */     String tableName = String.valueOf(removeImageExtension(image.getTitle())) + "-Densities";
/*     */ 
/*     */     
/* 183 */     table.show(tableName);
/*     */ 
/*     */     
/* 186 */     return new Object[] { "Crofton Densties", table };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus image, int nDirs, boolean addPorosity) {
/* 206 */     if (image == null) {
/* 207 */       return null;
/*     */     }
/* 209 */     if (this.debug)
/*     */     {
/* 211 */       System.out.println("Compute Crofton densities on image '" + 
/* 212 */           image.getTitle() + "' using " + nDirs + 
/* 213 */           " directions.");
/*     */     }
/*     */     
/* 216 */     ImageProcessor proc = image.getProcessor();
/*     */ 
/*     */     
/* 219 */     Calibration calib = image.getCalibration();
/*     */ 
/*     */     
/* 222 */     double areaDensity = IntrinsicVolumes2D.areaDensity(proc);
/* 223 */     double perimDensity = IntrinsicVolumes2D.perimeterDensity(proc, calib, nDirs);
/* 224 */     ResultsTable table = new ResultsTable();
/* 225 */     table.incrementCounter();
/* 226 */     table.addValue("AreaDensity", areaDensity);
/* 227 */     table.addValue("PerimeterDensity", perimDensity);
/*     */ 
/*     */     
/* 230 */     if (addPorosity)
/*     */     {
/* 232 */       table.addValue("Porosity", 1.0D - areaDensity);
/*     */     }
/*     */ 
/*     */     
/* 236 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String removeImageExtension(String name) {
/* 244 */     if (name.endsWith(".tif"))
/* 245 */       name = name.substring(0, name.length() - 4); 
/* 246 */     if (name.endsWith(".png"))
/* 247 */       name = name.substring(0, name.length() - 4); 
/* 248 */     if (name.endsWith(".bmp"))
/* 249 */       name = name.substring(0, name.length() - 4); 
/* 250 */     if (name.endsWith(".mhd"))
/* 251 */       name = name.substring(0, name.length() - 4); 
/* 252 */     return name;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/MicrostructureAnalysisPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */