/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.geometry.Vector3D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region3d.InertiaEllipsoid;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class InertiaEllipsoidPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   ImagePlus imagePlus;
/*     */   
/*     */   public void run(String args) {
/*  63 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/*  65 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/*  67 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  72 */     ImageStack image = imagePlus.getStack();
/*  73 */     int[] labels = LabelImages.findAllLabels(imagePlus);
/*  74 */     Calibration calib = imagePlus.getCalibration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  81 */       InertiaEllipsoid algo = new InertiaEllipsoid();
/*  82 */       DefaultAlgoListener.monitor((Algo)algo);
/*  83 */       ResultsTable table = algo.computeTable(imagePlus);
/*     */       
/*  85 */       String title = String.valueOf(imagePlus.getShortTitle()) + "-ellipsoid";
/*  86 */       table.show(title);
/*     */       
/*  88 */       InertiaEllipsoid.InertiaMoments3D[] moments = algo.computeMoments(image, labels, calib);
/*  89 */       ResultsTable vectorTable = createVectorTable(labels, moments);
/*  90 */       title = String.valueOf(imagePlus.getShortTitle()) + "-eigenVectors";
/*  91 */       vectorTable.show(title);
/*     */     }
/*  93 */     catch (Exception ex) {
/*     */       
/*  95 */       String msg = ex.getMessage();
/*  96 */       IJ.log(msg);
/*  97 */       IJ.error("Problem occured during Inertia Ellipsoid computation:\n" + msg);
/*  98 */       ex.printStackTrace(System.err);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResultsTable createVectorTable(int[] labels, InertiaEllipsoid.InertiaMoments3D[] moments) {
/* 107 */     ResultsTable table = new ResultsTable();
/*     */     
/* 109 */     for (int i = 0; i < labels.length; i++) {
/*     */ 
/*     */       
/* 112 */       table.incrementCounter();
/* 113 */       table.addLabel(Integer.toString(labels[i]));
/*     */       
/* 115 */       ArrayList<Vector3D> vectors = moments[i].eigenVectors();
/*     */       
/* 117 */       Vector3D v1 = vectors.get(0);
/* 118 */       table.addValue("EigenVector1.X", v1.getX());
/* 119 */       table.addValue("EigenVector1.Y", v1.getY());
/* 120 */       table.addValue("EigenVector1.Z", v1.getZ());
/*     */       
/* 122 */       Vector3D v2 = vectors.get(1);
/* 123 */       table.addValue("EigenVector2.X", v2.getX());
/* 124 */       table.addValue("EigenVector2.Y", v2.getY());
/* 125 */       table.addValue("EigenVector2.Z", v2.getZ());
/*     */       
/* 127 */       Vector3D v3 = vectors.get(2);
/* 128 */       table.addValue("EigenVector3.X", v3.getX());
/* 129 */       table.addValue("EigenVector3.Y", v3.getY());
/* 130 */       table.addValue("EigenVector3.Z", v3.getZ());
/*     */     } 
/*     */ 
/*     */     
/* 134 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InertiaEllipsoidPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */