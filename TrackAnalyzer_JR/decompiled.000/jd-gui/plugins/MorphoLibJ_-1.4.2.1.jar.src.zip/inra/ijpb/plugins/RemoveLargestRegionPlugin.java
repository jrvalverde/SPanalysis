/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.binary.BinaryImages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoveLargestRegionPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg0) {
/* 43 */     ImagePlus imagePlus = IJ.getImage();
/*    */     
/* 45 */     ImagePlus resultPlus = imagePlus.duplicate();
/* 46 */     BinaryImages.removeLargestRegion(resultPlus);
/* 47 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-killLargest";
/* 48 */     resultPlus.setTitle(newName);
/*    */ 
/*    */     
/* 51 */     resultPlus.show();
/* 52 */     if (imagePlus.getStackSize() > 1) {
/* 53 */       resultPlus.setZ(imagePlus.getZ());
/* 54 */       resultPlus.setSlice(imagePlus.getCurrentSlice());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RemoveLargestRegionPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */