/*    */ package inra.ijpb.plugins;
/*    */ 
/*    */ import ij.IJ;
/*    */ import ij.ImagePlus;
/*    */ import ij.WindowManager;
/*    */ import ij.gui.GenericDialog;
/*    */ import ij.plugin.PlugIn;
/*    */ import inra.ijpb.data.image.ColorImages;
/*    */ import inra.ijpb.util.CommonColors;
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryOverlayPlugin
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg) {
/* 49 */     int[] indices = WindowManager.getIDList();
/* 50 */     if (indices == null) {
/* 51 */       IJ.error("No image", "Need at least one image to work");
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 56 */     String[] imageNames = new String[indices.length];
/* 57 */     for (int i = 0; i < indices.length; i++) {
/* 58 */       imageNames[i] = WindowManager.getImage(indices[i]).getTitle();
/*    */     }
/*    */ 
/*    */     
/* 62 */     String selectedImageName = IJ.getImage().getTitle();
/*    */ 
/*    */     
/* 65 */     GenericDialog gd = new GenericDialog("Binary Overlay");
/* 66 */     gd.addChoice("Reference Image:", imageNames, selectedImageName);
/* 67 */     gd.addChoice("Binary Mask:", imageNames, selectedImageName);
/* 68 */     gd.addChoice("Overlay Color:", CommonColors.getAllLabels(), CommonColors.RED.getLabel());
/*    */     
/* 70 */     gd.showDialog();
/*    */     
/* 72 */     if (gd.wasCanceled()) {
/*    */       return;
/*    */     }
/*    */     
/* 76 */     int refImageIndex = gd.getNextChoiceIndex();
/* 77 */     ImagePlus refImage = WindowManager.getImage(refImageIndex + 1);
/*    */ 
/*    */     
/* 80 */     int maskIndex = gd.getNextChoiceIndex();
/* 81 */     ImagePlus maskImage = WindowManager.getImage(maskIndex + 1);
/*    */ 
/*    */     
/* 84 */     String colorName = gd.getNextChoice();
/* 85 */     Color color = CommonColors.fromLabel(colorName).getColor();
/*    */ 
/*    */     
/* 88 */     ImagePlus resultPlus = ColorImages.binaryOverlay(refImage, maskImage, color);
/* 89 */     resultPlus.show();
/*    */ 
/*    */     
/* 92 */     if (refImage.getStackSize() > 1)
/* 93 */       resultPlus.setSlice(refImage.getCurrentSlice()); 
/*    */   }
/*    */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/BinaryOverlayPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */