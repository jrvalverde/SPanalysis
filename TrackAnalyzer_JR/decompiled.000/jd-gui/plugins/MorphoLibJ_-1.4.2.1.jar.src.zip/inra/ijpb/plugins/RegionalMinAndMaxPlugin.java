/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.DialogListener;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.filter.ExtendedPlugInFilter;
/*     */ import ij.plugin.filter.PlugInFilterRunner;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.morphology.MinimaAndMaxima;
/*     */ import java.awt.AWTEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionalMinAndMaxPlugin
/*     */   implements ExtendedPlugInFilter, DialogListener
/*     */ {
/*     */   public enum Operation
/*     */   {
/*  50 */     REGIONAL_MAXIMA("Regional Maxima", "rmax"),
/*  51 */     REGIONAL_MINIMA("Regional Minima", "rmin");
/*     */     
/*     */     private final String label;
/*     */     private final String suffix;
/*     */     
/*     */     Operation(String label, String suffix) {
/*  57 */       this.label = label;
/*  58 */       this.suffix = suffix;
/*     */     }
/*     */     
/*     */     public ImageProcessor apply(ImageProcessor image, int connectivity) {
/*  62 */       if (this == REGIONAL_MAXIMA)
/*  63 */         return MinimaAndMaxima.regionalMaxima(image, connectivity); 
/*  64 */       if (this == REGIONAL_MINIMA) {
/*  65 */         return MinimaAndMaxima.regionalMinima(image, connectivity);
/*     */       }
/*  67 */       throw new RuntimeException(
/*  68 */           "Unable to process the " + this + " morphological operation");
/*     */     }
/*     */     
/*     */     public String toString() {
/*  72 */       return this.label;
/*     */     }
/*     */     
/*     */     public String getSuffix() {
/*  76 */       return this.suffix;
/*     */     }
/*     */     
/*     */     public static String[] getAllLabels() {
/*  80 */       int n = (values()).length;
/*  81 */       String[] result = new String[n];
/*     */       
/*  83 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  84 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  85 */         result[i++] = op.label; b++; }
/*     */       
/*  87 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/* 100 */       if (opLabel != null)
/* 101 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/* 102 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/* 103 */         String cmp = op.label.toLowerCase();
/* 104 */         if (cmp.equals(opLabel))
/* 105 */           return op;  b++; }
/*     */       
/* 107 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + opLabel);
/*     */     }
/*     */   }
/*     */   
/* 111 */   private static final String[] connectivityLabels = new String[] { "4", "8" };
/* 112 */   private static final int[] connectivityValues = new int[] { 4, 8 };
/*     */ 
/*     */ 
/*     */   
/* 116 */   private int flags = 16842783;
/*     */ 
/*     */   
/*     */   PlugInFilterRunner pfr;
/*     */ 
/*     */   
/*     */   int nPasses;
/*     */   
/*     */   boolean previewing = false;
/*     */   
/*     */   private ImagePlus imagePlus;
/*     */   
/*     */   private ImageProcessor baseImage;
/*     */   
/*     */   private ImageProcessor result;
/*     */   
/* 132 */   ImagePlus image = null;
/* 133 */   Operation op = Operation.REGIONAL_MINIMA;
/* 134 */   int connectivity = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 141 */     if (arg.equals("about")) {
/* 142 */       showAbout();
/* 143 */       return 4096;
/*     */     } 
/*     */ 
/*     */     
/* 147 */     if (arg.equals("final")) {
/*     */       
/* 149 */       this.imagePlus.setProcessor(this.baseImage);
/* 150 */       this.imagePlus.draw();
/*     */ 
/*     */       
/* 153 */       this.result.invertLut();
/*     */ 
/*     */       
/* 156 */       String newName = createResultImageName(this.imagePlus);
/* 157 */       ImagePlus resPlus = new ImagePlus(newName, this.result);
/* 158 */       resPlus.copyScale(this.imagePlus);
/* 159 */       resPlus.show();
/* 160 */       return 4096;
/*     */     } 
/*     */     
/* 163 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int showDialog(ImagePlus imp, String command, PlugInFilterRunner pfr) {
/* 169 */     this.imagePlus = imp;
/* 170 */     this.baseImage = imp.getProcessor().duplicate();
/*     */ 
/*     */     
/* 173 */     GenericDialog gd = new GenericDialog("Regional Min & Max");
/*     */     
/* 175 */     gd.addChoice("Operation", Operation.getAllLabels(), 
/* 176 */         Operation.REGIONAL_MINIMA.label);
/* 177 */     gd.addChoice("Connectivity", connectivityLabels, connectivityLabels[0]);
/*     */     
/* 179 */     gd.addPreviewCheckbox(pfr);
/* 180 */     gd.addDialogListener(this);
/* 181 */     this.previewing = true;
/* 182 */     gd.addHelp("https://imagej.net/MorphoLibJ");
/* 183 */     gd.showDialog();
/* 184 */     this.previewing = false;
/*     */     
/* 186 */     if (gd.wasCanceled()) {
/* 187 */       return 4096;
/*     */     }
/* 189 */     parseDialogParameters(gd);
/*     */ 
/*     */     
/* 192 */     gd.dispose();
/* 193 */     return this.flags;
/*     */   }
/*     */   
/*     */   public boolean dialogItemChanged(GenericDialog gd, AWTEvent evt) {
/* 197 */     parseDialogParameters(gd);
/* 198 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseDialogParameters(GenericDialog gd) {
/* 203 */     this.op = Operation.fromLabel(gd.getNextChoice());
/* 204 */     this.connectivity = connectivityValues[gd.getNextChoiceIndex()];
/*     */   }
/*     */   
/*     */   public void setNPasses(int nPasses) {
/* 208 */     this.nPasses = nPasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor image) {
/* 215 */     this.result = this.op.apply(image, this.connectivity);
/*     */     
/* 217 */     if (this.previewing) {
/*     */ 
/*     */       
/* 220 */       double valMax = this.result.getMax();
/* 221 */       for (int i = 0; i < image.getPixelCount(); i++) {
/* 222 */         image.set(i, 255 - (int)((255.0F * this.result.getf(i)) / valMax));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void showAbout() {
/* 229 */     IJ.showMessage("Morphological Filters", 
/* 230 */         "Fast Grayscale Morphological Filtering,\nhttp://imagejdocu.tudor.lu/doku.php?id=plugin:morphology:fast_morphological_filters:start\n\nby David Legland\n(david.legland@grignon.inra.fr)");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createResultImageName(ImagePlus baseImage) {
/* 242 */     return String.valueOf(baseImage.getShortTitle()) + "-" + this.op.getSuffix();
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/RegionalMinAndMaxPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */