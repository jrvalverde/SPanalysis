/*      */ package inra.ijpb.plugins;
/*      */ import ij.IJ;
/*      */ import ij.ImagePlus;
/*      */ import ij.ImageStack;
/*      */ import ij.WindowManager;
/*      */ import ij.gui.ImageCanvas;
/*      */ import ij.gui.ImageRoi;
/*      */ import ij.gui.ImageWindow;
/*      */ import ij.gui.Overlay;
/*      */ import ij.gui.PointRoi;
/*      */ import ij.gui.Roi;
/*      */ import ij.plugin.frame.Recorder;
/*      */ import ij.plugin.frame.RoiManager;
/*      */ import ij.process.FloatProcessor;
/*      */ import ij.process.ImageProcessor;
/*      */ import ij.process.LUT;
/*      */ import inra.ijpb.binary.BinaryImages;
/*      */ import inra.ijpb.data.image.Images3D;
/*      */ import inra.ijpb.util.ColorMaps;
/*      */ import inra.ijpb.watershed.Watershed;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Panel;
/*      */ import java.awt.Scrollbar;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.AdjustmentEvent;
/*      */ import java.awt.event.AdjustmentListener;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseWheelEvent;
/*      */ import java.awt.event.MouseWheelListener;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.image.ColorModel;
/*      */ import java.util.Random;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ 
/*      */ public class InteractiveMarkerControlledWatershed implements PlugIn {
/*      */   private CustomWindow win;
/*      */   ImagePlus inputImage;
/*      */   ImageStack inputStackCopy;
/*      */   ImagePlus displayImage;
/*      */   ImageStack gradientStack;
/*      */   ImagePlus resultImage;
/*      */   JPanel paramsPanel;
/*      */   Panel all;
/*      */   boolean inputIs2D;
/*      */   JPanel segmentationPanel;
/*      */   JPanel damsPanel;
/*      */   JCheckBox damsCheckBox;
/*      */   private boolean calculateDams;
/*      */   JPanel connectivityPanel;
/*      */   JLabel connectivityLabel;
/*      */   String[] connectivityOptions;
/*      */   JComboBox<String> connectivityList;
/*      */   JButton segmentButton;
/*      */   JPanel displayPanel;
/*      */   JLabel displayLabel;
/*      */   static String overlaidBasinsText = "Overlaid basins";
/*      */   static String overlaidDamsText = "Overlaid dams";
/*      */   static String catchmentBasinsText = "Catchment basins";
/*      */   static String watershedLinesText = "Watershed lines";
/*      */   String[] resultDisplayOption;
/*      */   JComboBox<String> resultDisplayList;
/*      */   JPanel resultDisplayPanel;
/*      */   JCheckBox toggleOverlayCheckBox;
/*      */   JPanel overlayPanel;
/*      */   JButton resultButton;
/*      */   private boolean showColorOverlay;
/*      */   final ExecutorService exec;
/*      */   JPanel postProcessPanel;
/*      */   JButton mergeButton;
/*      */   JButton shuffleColorsButton;
/*      */   private Thread segmentationThread;
/*      */   private String segmentText;
/*      */   private String segmentTip;
/*      */   private String stopText;
/*      */   private String stopTip;
/*      */   
/*      */   public enum ResultMode {
/*      */     OVERLAID_BASINS, OVERLAID_DAMS, BASINS, LINES;
/*      */   }
/*      */   public static String RUN_SEGMENTATION = "segment";
/*      */   public static String SHOW_RESULT_OVERLAY = "toggleOverlay";
/*      */   public static String CREATE_IMAGE = "createResultImage";
/*      */   
/*      */   public InteractiveMarkerControlledWatershed() {
/*   97 */     this.inputImage = null;
/*      */     
/*   99 */     this.inputStackCopy = null;
/*      */ 
/*      */     
/*  102 */     this.displayImage = null;
/*      */ 
/*      */     
/*  105 */     this.gradientStack = null;
/*      */ 
/*      */     
/*  108 */     this.resultImage = null;
/*      */ 
/*      */     
/*  111 */     this.paramsPanel = new JPanel();
/*      */ 
/*      */     
/*  114 */     this.all = new Panel();
/*      */ 
/*      */     
/*  117 */     this.inputIs2D = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  130 */     this.segmentationPanel = new JPanel();
/*      */ 
/*      */     
/*  133 */     this.damsPanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  137 */     this.calculateDams = true;
/*      */ 
/*      */     
/*  140 */     this.connectivityPanel = new JPanel();
/*      */ 
/*      */ 
/*      */     
/*  144 */     this.connectivityOptions = new String[] { "6", "26" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  162 */     this.displayPanel = new JPanel();
/*      */ 
/*      */     
/*  165 */     this.displayLabel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  177 */     this
/*  178 */       .resultDisplayOption = new String[] { overlaidBasinsText, overlaidDamsText, catchmentBasinsText, watershedLinesText };
/*      */     
/*  180 */     this.resultDisplayList = null;
/*      */     
/*  182 */     this.resultDisplayPanel = new JPanel();
/*      */ 
/*      */     
/*  185 */     this.toggleOverlayCheckBox = null;
/*      */     
/*  187 */     this.overlayPanel = new JPanel();
/*      */ 
/*      */     
/*  190 */     this.resultButton = null;
/*      */ 
/*      */     
/*  193 */     this.showColorOverlay = false;
/*      */ 
/*      */     
/*  196 */     this.exec = Executors.newFixedThreadPool(1);
/*      */ 
/*      */     
/*  199 */     this.postProcessPanel = new JPanel();
/*      */     
/*  201 */     this.mergeButton = null;
/*      */     
/*  203 */     this.shuffleColorsButton = null;
/*      */ 
/*      */     
/*  206 */     this.segmentationThread = null;
/*      */ 
/*      */     
/*  209 */     this.segmentText = "Run";
/*      */     
/*  211 */     this.segmentTip = "Run the marker-controlled watershed segmentation";
/*      */     
/*  213 */     this.stopText = "STOP";
/*      */     
/*  215 */     this.stopTip = "Click to abort segmentation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  246 */     this.opacity = 0.3333333333333333D;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String SET_INPUT_TYPE = "setInputImageType";
/*      */   public static String SHOW_GRADIENT = "setShowGradient";
/*      */   public static String SET_DISPLAY = "setDisplayFormat";
/*      */   public static String SET_RADIUS = "setGradientRadius";
/*      */   public static String MERGE_LABELS = "mergeLabels";
/*      */   public static String SHUFFLE_COLORS = "shuffleColors";
/*      */   double opacity;
/*      */   
/*      */   private class CustomWindow
/*      */     extends StackWindow
/*      */   {
/*  261 */     private ActionListener listener = new ActionListener()
/*      */       {
/*      */ 
/*      */         
/*      */         public void actionPerformed(final ActionEvent e)
/*      */         {
/*  267 */           final String command = e.getActionCommand();
/*      */ 
/*      */ 
/*      */           
/*  271 */           (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).exec.submit(new Runnable()
/*      */               {
/*      */                 
/*      */                 public void run()
/*      */                 {
/*  276 */                   if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).segmentButton) {
/*      */                     
/*  278 */                     InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).runSegmentation(command);
/*      */                   
/*      */                   }
/*  281 */                   else if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).toggleOverlayCheckBox) {
/*      */                     
/*  283 */                     InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).toggleOverlay();
/*      */                     
/*  285 */                     String[] arg = new String[0];
/*  286 */                     InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.SHOW_RESULT_OVERLAY, arg);
/*      */                   
/*      */                   }
/*  289 */                   else if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).resultButton) {
/*      */                     
/*  291 */                     InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).createResultImage();
/*      */                   
/*      */                   }
/*  294 */                   else if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).resultDisplayList) {
/*      */                     
/*  296 */                     if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).showColorOverlay) {
/*  297 */                       InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).updateResultOverlay();
/*      */                     }
/*  299 */                     String[] arg = { (String)(InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).resultDisplayList.getSelectedItem() };
/*  300 */                     InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.SET_DISPLAY, arg);
/*      */                   }
/*  302 */                   else if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).mergeButton) {
/*      */                     
/*  304 */                     InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this)).setParamsEnabled(false);
/*  305 */                     InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).mergeLabels();
/*  306 */                     InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this)).setParamsEnabled(true);
/*      */                   }
/*  308 */                   else if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).shuffleColorsButton) {
/*      */                     
/*  310 */                     InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).shuffleColors();
/*      */                   } 
/*      */                 }
/*      */               });
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final long serialVersionUID = -6201855439028581892L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CustomWindow(ImagePlus imp) {
/*  329 */       super(imp, new ImageCanvas(imp));
/*      */       
/*  331 */       ImageCanvas canvas = getCanvas();
/*      */       
/*  333 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*  334 */       double screenWidth = screenSize.getWidth();
/*  335 */       double screenHeight = screenSize.getHeight();
/*      */ 
/*      */       
/*  338 */       while (this.ic.getWidth() < screenWidth / 2.0D && 
/*  339 */         this.ic.getHeight() < screenHeight / 2.0D && 
/*  340 */         this.ic.getMagnification() < 32.0D) {
/*      */         
/*  342 */         int canvasWidth = this.ic.getWidth();
/*  343 */         this.ic.zoomIn(0, 0);
/*      */         
/*  345 */         if (canvasWidth == this.ic.getWidth()) {
/*      */           
/*  347 */           this.ic.zoomOut(0, 0);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  352 */       while ((this.ic.getWidth() > 0.75D * screenWidth || 
/*  353 */         this.ic.getHeight() > 0.75D * screenHeight) && 
/*  354 */         this.ic.getMagnification() > 0.013888888888888888D) {
/*      */         
/*  356 */         int canvasWidth = this.ic.getWidth();
/*  357 */         this.ic.zoomOut(0, 0);
/*      */         
/*  359 */         if (canvasWidth == this.ic.getWidth()) {
/*      */           
/*  361 */           this.ic.zoomIn(0, 0);
/*      */           break;
/*      */         } 
/*      */       } 
/*  365 */       setTitle("Interactive Marker-controlled Watershed");
/*      */ 
/*      */       
/*  368 */       Toolbar.getInstance().setTool(7);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  373 */       InteractiveMarkerControlledWatershed.this.damsCheckBox = new JCheckBox("Calculate dams", InteractiveMarkerControlledWatershed.this.calculateDams);
/*  374 */       InteractiveMarkerControlledWatershed.this.damsCheckBox.setToolTipText("Calculate watershed dams");
/*  375 */       InteractiveMarkerControlledWatershed.this.damsPanel.add(InteractiveMarkerControlledWatershed.this.damsCheckBox);
/*      */ 
/*      */       
/*  378 */       if (InteractiveMarkerControlledWatershed.this.inputIs2D)
/*  379 */         InteractiveMarkerControlledWatershed.this.connectivityOptions = new String[] { "4", "8" }; 
/*  380 */       InteractiveMarkerControlledWatershed.this.connectivityList = new JComboBox<String>(InteractiveMarkerControlledWatershed.this.connectivityOptions);
/*  381 */       InteractiveMarkerControlledWatershed.this.connectivityList.setToolTipText("Voxel connectivity to use");
/*  382 */       InteractiveMarkerControlledWatershed.this.connectivityLabel = new JLabel("Connectivity");
/*  383 */       InteractiveMarkerControlledWatershed.this.connectivityPanel.add(InteractiveMarkerControlledWatershed.this.connectivityLabel);
/*  384 */       InteractiveMarkerControlledWatershed.this.connectivityPanel.add(InteractiveMarkerControlledWatershed.this.connectivityList);
/*  385 */       InteractiveMarkerControlledWatershed.this.connectivityPanel.setToolTipText("Voxel connectivity to use");
/*      */ 
/*      */       
/*  388 */       InteractiveMarkerControlledWatershed.this.segmentButton = new JButton(InteractiveMarkerControlledWatershed.this.segmentText);
/*  389 */       InteractiveMarkerControlledWatershed.this.segmentButton.setToolTipText(InteractiveMarkerControlledWatershed.this.segmentTip);
/*  390 */       InteractiveMarkerControlledWatershed.this.segmentButton.addActionListener(this.listener);
/*      */ 
/*      */       
/*  393 */       InteractiveMarkerControlledWatershed.this.segmentationPanel.setBorder(BorderFactory.createTitledBorder("Watershed Segmentation"));
/*  394 */       GridBagLayout segmentationLayout = new GridBagLayout();
/*  395 */       GridBagConstraints segmentationConstraints = new GridBagConstraints();
/*  396 */       segmentationConstraints.anchor = 18;
/*  397 */       segmentationConstraints.fill = 2;
/*  398 */       segmentationConstraints.gridwidth = 1;
/*  399 */       segmentationConstraints.gridheight = 1;
/*  400 */       segmentationConstraints.gridx = 0;
/*  401 */       segmentationConstraints.gridy = 0;
/*  402 */       segmentationConstraints.insets = new Insets(5, 5, 6, 6);
/*  403 */       InteractiveMarkerControlledWatershed.this.segmentationPanel.setLayout(segmentationLayout);
/*      */       
/*  405 */       InteractiveMarkerControlledWatershed.this.segmentationPanel.add(InteractiveMarkerControlledWatershed.this.damsPanel, segmentationConstraints);
/*  406 */       segmentationConstraints.gridy++;
/*  407 */       InteractiveMarkerControlledWatershed.this.segmentationPanel.add(InteractiveMarkerControlledWatershed.this.connectivityPanel, segmentationConstraints);
/*      */       
/*  409 */       segmentationConstraints.gridy++;
/*  410 */       segmentationConstraints.anchor = 10;
/*  411 */       segmentationConstraints.fill = 0;
/*  412 */       InteractiveMarkerControlledWatershed.this.segmentationPanel.add(InteractiveMarkerControlledWatershed.this.segmentButton, segmentationConstraints);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  417 */       InteractiveMarkerControlledWatershed.this.displayLabel = new JLabel("Display");
/*  418 */       InteractiveMarkerControlledWatershed.this.displayLabel.setEnabled(false);
/*  419 */       InteractiveMarkerControlledWatershed.this.resultDisplayList = new JComboBox<String>(InteractiveMarkerControlledWatershed.this.resultDisplayOption);
/*  420 */       InteractiveMarkerControlledWatershed.this.resultDisplayList.setEnabled(false);
/*  421 */       InteractiveMarkerControlledWatershed.this.resultDisplayList.setToolTipText("Select how to display segmentation results");
/*  422 */       InteractiveMarkerControlledWatershed.this.resultDisplayList.addActionListener(this.listener);
/*      */       
/*  424 */       InteractiveMarkerControlledWatershed.this.resultDisplayPanel.add(InteractiveMarkerControlledWatershed.this.displayLabel);
/*  425 */       InteractiveMarkerControlledWatershed.this.resultDisplayPanel.add(InteractiveMarkerControlledWatershed.this.resultDisplayList);
/*      */ 
/*      */       
/*  428 */       InteractiveMarkerControlledWatershed.this.showColorOverlay = false;
/*  429 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox = new JCheckBox("Show result overlay");
/*  430 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox.setEnabled(InteractiveMarkerControlledWatershed.this.showColorOverlay);
/*  431 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox.setToolTipText("Toggle overlay with segmentation result");
/*  432 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox.addActionListener(this.listener);
/*  433 */       InteractiveMarkerControlledWatershed.this.overlayPanel.add(InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox);
/*      */ 
/*      */       
/*  436 */       InteractiveMarkerControlledWatershed.this.resultButton = new JButton("Create Image");
/*  437 */       InteractiveMarkerControlledWatershed.this.resultButton.setEnabled(false);
/*  438 */       InteractiveMarkerControlledWatershed.this.resultButton.setToolTipText("Show segmentation result in new window");
/*  439 */       InteractiveMarkerControlledWatershed.this.resultButton.addActionListener(this.listener);
/*      */ 
/*      */       
/*  442 */       InteractiveMarkerControlledWatershed.this.displayPanel.setBorder(BorderFactory.createTitledBorder("Results"));
/*  443 */       GridBagLayout displayLayout = new GridBagLayout();
/*  444 */       GridBagConstraints displayConstraints = new GridBagConstraints();
/*  445 */       displayConstraints.anchor = 18;
/*  446 */       displayConstraints.fill = 2;
/*  447 */       displayConstraints.gridwidth = 1;
/*  448 */       displayConstraints.gridheight = 1;
/*  449 */       displayConstraints.gridx = 0;
/*  450 */       displayConstraints.gridy = 0;
/*  451 */       displayConstraints.insets = new Insets(5, 5, 6, 6);
/*  452 */       InteractiveMarkerControlledWatershed.this.displayPanel.setLayout(displayLayout);
/*      */       
/*  454 */       InteractiveMarkerControlledWatershed.this.displayPanel.add(InteractiveMarkerControlledWatershed.this.resultDisplayPanel, displayConstraints);
/*  455 */       displayConstraints.gridy++;
/*  456 */       InteractiveMarkerControlledWatershed.this.displayPanel.add(InteractiveMarkerControlledWatershed.this.overlayPanel, displayConstraints);
/*  457 */       displayConstraints.gridy++;
/*  458 */       displayConstraints.anchor = 10;
/*  459 */       displayConstraints.fill = 0;
/*  460 */       InteractiveMarkerControlledWatershed.this.displayPanel.add(InteractiveMarkerControlledWatershed.this.resultButton, displayConstraints);
/*      */ 
/*      */       
/*  463 */       InteractiveMarkerControlledWatershed.this.mergeButton = new JButton("Merge labels");
/*  464 */       InteractiveMarkerControlledWatershed.this.mergeButton.setEnabled(false);
/*  465 */       InteractiveMarkerControlledWatershed.this.mergeButton.setToolTipText("Merge labels selected by freehand or point ROI");
/*      */       
/*  467 */       InteractiveMarkerControlledWatershed.this.mergeButton.addActionListener(this.listener);
/*      */       
/*  469 */       InteractiveMarkerControlledWatershed.this.shuffleColorsButton = new JButton("Shuffle colors");
/*  470 */       InteractiveMarkerControlledWatershed.this.shuffleColorsButton.setEnabled(false);
/*  471 */       InteractiveMarkerControlledWatershed.this.shuffleColorsButton.setToolTipText("Shuffle color labels");
/*  472 */       InteractiveMarkerControlledWatershed.this.shuffleColorsButton.addActionListener(this.listener);
/*      */       
/*  474 */       GridBagLayout mergingLayout = new GridBagLayout();
/*  475 */       InteractiveMarkerControlledWatershed.this.postProcessPanel.setLayout(mergingLayout);
/*      */       
/*  477 */       GridBagConstraints ppConstraints = new GridBagConstraints();
/*  478 */       ppConstraints.anchor = 18;
/*  479 */       ppConstraints.fill = 2;
/*  480 */       ppConstraints.gridwidth = 1;
/*  481 */       ppConstraints.gridheight = 1;
/*  482 */       ppConstraints.gridx = 0;
/*  483 */       ppConstraints.gridy = 0;
/*  484 */       ppConstraints.insets = new Insets(5, 5, 6, 6);
/*      */       
/*  486 */       InteractiveMarkerControlledWatershed.this.postProcessPanel.add(InteractiveMarkerControlledWatershed.this.mergeButton, ppConstraints);
/*  487 */       ppConstraints.gridy++;
/*  488 */       InteractiveMarkerControlledWatershed.this.postProcessPanel.add(InteractiveMarkerControlledWatershed.this.shuffleColorsButton, ppConstraints);
/*  489 */       InteractiveMarkerControlledWatershed.this.postProcessPanel.setBorder(BorderFactory.createTitledBorder(
/*  490 */             "Post-processing"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  496 */       GridBagLayout paramsLayout = new GridBagLayout();
/*  497 */       GridBagConstraints paramsConstraints = new GridBagConstraints();
/*  498 */       paramsConstraints.insets = new Insets(5, 5, 6, 6);
/*  499 */       InteractiveMarkerControlledWatershed.this.paramsPanel.setLayout(paramsLayout);
/*  500 */       paramsConstraints.anchor = 18;
/*  501 */       paramsConstraints.fill = 2;
/*  502 */       paramsConstraints.gridwidth = 1;
/*  503 */       paramsConstraints.gridheight = 1;
/*  504 */       paramsConstraints.gridx = 0;
/*  505 */       paramsConstraints.gridy = 0;
/*  506 */       InteractiveMarkerControlledWatershed.this.paramsPanel.add(InteractiveMarkerControlledWatershed.this.segmentationPanel, paramsConstraints);
/*  507 */       paramsConstraints.gridy++;
/*  508 */       InteractiveMarkerControlledWatershed.this.paramsPanel.add(InteractiveMarkerControlledWatershed.this.displayPanel, paramsConstraints);
/*  509 */       paramsConstraints.gridy++;
/*  510 */       InteractiveMarkerControlledWatershed.this.paramsPanel.add(InteractiveMarkerControlledWatershed.this.postProcessPanel, paramsConstraints);
/*  511 */       paramsConstraints.gridy++;
/*      */ 
/*      */ 
/*      */       
/*  515 */       GridBagLayout layout = new GridBagLayout();
/*  516 */       GridBagConstraints allConstraints = new GridBagConstraints();
/*  517 */       InteractiveMarkerControlledWatershed.this.all.setLayout(layout);
/*      */ 
/*      */       
/*  520 */       allConstraints.anchor = 18;
/*  521 */       allConstraints.fill = 1;
/*  522 */       allConstraints.gridwidth = 1;
/*  523 */       allConstraints.gridheight = 1;
/*  524 */       allConstraints.gridx = 0;
/*  525 */       allConstraints.gridy = 0;
/*  526 */       allConstraints.gridheight = 2;
/*  527 */       allConstraints.weightx = 0.0D;
/*  528 */       allConstraints.weighty = 0.0D;
/*      */       
/*  530 */       InteractiveMarkerControlledWatershed.this.all.add(InteractiveMarkerControlledWatershed.this.paramsPanel, allConstraints);
/*      */ 
/*      */       
/*  533 */       allConstraints.gridx++;
/*  534 */       allConstraints.weightx = 1.0D;
/*  535 */       allConstraints.weighty = 1.0D;
/*  536 */       allConstraints.gridheight = 1;
/*  537 */       InteractiveMarkerControlledWatershed.this.all.add((Component)canvas, allConstraints);
/*      */       
/*  539 */       allConstraints.gridy++;
/*  540 */       allConstraints.weightx = 0.0D;
/*  541 */       allConstraints.weighty = 0.0D;
/*      */ 
/*      */ 
/*      */       
/*  545 */       if (this.sliceSelector != null) {
/*      */         
/*  547 */         this.sliceSelector.setValue(InteractiveMarkerControlledWatershed.this.inputImage.getCurrentSlice());
/*  548 */         InteractiveMarkerControlledWatershed.this.displayImage.setSlice(InteractiveMarkerControlledWatershed.this.inputImage.getCurrentSlice());
/*      */         
/*  550 */         InteractiveMarkerControlledWatershed.this.all.add(this.sliceSelector, allConstraints);
/*      */         
/*  552 */         if (this.zSelector != null)
/*  553 */           InteractiveMarkerControlledWatershed.this.all.add((Component)this.zSelector, allConstraints); 
/*  554 */         if (this.tSelector != null)
/*  555 */           InteractiveMarkerControlledWatershed.this.all.add((Component)this.tSelector, allConstraints); 
/*  556 */         if (this.cSelector != null) {
/*  557 */           InteractiveMarkerControlledWatershed.this.all.add((Component)this.cSelector, allConstraints);
/*      */         }
/*      */       } 
/*  560 */       allConstraints.gridy--;
/*      */ 
/*      */       
/*  563 */       GridBagLayout wingb = new GridBagLayout();
/*  564 */       GridBagConstraints winc = new GridBagConstraints();
/*  565 */       winc.anchor = 18;
/*  566 */       winc.fill = 1;
/*  567 */       winc.weightx = 1.0D;
/*  568 */       winc.weighty = 1.0D;
/*  569 */       setLayout(wingb);
/*  570 */       add(InteractiveMarkerControlledWatershed.this.all, winc);
/*      */ 
/*      */       
/*  573 */       pack();
/*  574 */       setMinimumSize(getPreferredSize());
/*      */ 
/*      */       
/*  577 */       if (this.sliceSelector != null) {
/*      */ 
/*      */         
/*  580 */         this.sliceSelector.addAdjustmentListener(new AdjustmentListener()
/*      */             {
/*      */               public void adjustmentValueChanged(final AdjustmentEvent e)
/*      */               {
/*  584 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).exec.submit(new Runnable() {
/*      */                       public void run() {
/*  586 */                         if (e.getSource() == (InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this)).sliceSelector)
/*      */                         {
/*  588 */                           if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).showColorOverlay) {
/*      */                             
/*  590 */                             InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).updateResultOverlay();
/*  591 */                             (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                           } 
/*      */                         }
/*      */                       }
/*      */                     });
/*      */               }
/*      */             });
/*      */ 
/*      */         
/*  600 */         addMouseWheelListener(new MouseWheelListener()
/*      */             {
/*      */               
/*      */               public void mouseWheelMoved(MouseWheelEvent e)
/*      */               {
/*  605 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).exec.submit(new Runnable()
/*      */                     {
/*      */                       public void run() {
/*  608 */                         if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).showColorOverlay) {
/*      */                           
/*  610 */                           InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).updateResultOverlay();
/*  611 */                           (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                         } 
/*      */                       }
/*      */                     });
/*      */               }
/*      */             });
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  621 */         KeyListener keyListener = new KeyListener()
/*      */           {
/*      */             public void keyTyped(KeyEvent e) {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void keyReleased(final KeyEvent e) {
/*  628 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).exec.submit(new Runnable()
/*      */                   {
/*      */                     public void run() {
/*  631 */                       if (e.getKeyCode() == 37 || 
/*  632 */                         e.getKeyCode() == 39 || 
/*  633 */                         e.getKeyCode() == 153 || 
/*  634 */                         e.getKeyCode() == 160 || 
/*  635 */                         e.getKeyCode() == 44 || 
/*  636 */                         e.getKeyCode() == 46)
/*      */                       {
/*  638 */                         if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).showColorOverlay) {
/*      */                           
/*  640 */                           InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this).updateResultOverlay();
/*  641 */                           (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.null.access$0(InteractiveMarkerControlledWatershed.CustomWindow.null.this))).displayImage.updateAndDraw();
/*      */                         } 
/*      */                       }
/*      */                     }
/*      */                   });
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void keyPressed(KeyEvent e) {}
/*      */           };
/*  653 */         addKeyListener(keyListener);
/*  654 */         canvas.addKeyListener(keyListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void windowClosing(WindowEvent e) {
/*  665 */       super.windowClosing(e);
/*      */       
/*  667 */       if (InteractiveMarkerControlledWatershed.this.inputImage != null) {
/*      */         
/*  669 */         if (InteractiveMarkerControlledWatershed.this.displayImage != null) {
/*  670 */           InteractiveMarkerControlledWatershed.this.inputImage.setSlice(InteractiveMarkerControlledWatershed.this.displayImage.getCurrentSlice());
/*      */         }
/*      */         
/*  673 */         InteractiveMarkerControlledWatershed.this.inputImage.getWindow().setVisible(true);
/*      */       } 
/*      */ 
/*      */       
/*  677 */       InteractiveMarkerControlledWatershed.this.segmentButton.removeActionListener(this.listener);
/*  678 */       InteractiveMarkerControlledWatershed.this.resultDisplayList.removeActionListener(this.listener);
/*  679 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox.removeActionListener(this.listener);
/*  680 */       InteractiveMarkerControlledWatershed.this.resultButton.removeActionListener(this.listener);
/*      */       
/*  682 */       if (InteractiveMarkerControlledWatershed.this.displayImage != null)
/*      */       {
/*      */         
/*  685 */         InteractiveMarkerControlledWatershed.this.displayImage = null;
/*      */       }
/*      */       
/*  688 */       InteractiveMarkerControlledWatershed.this.exec.shutdownNow();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setCalculateDams(boolean b) {
/*  698 */       InteractiveMarkerControlledWatershed.this.calculateDams = b;
/*  699 */       InteractiveMarkerControlledWatershed.this.damsCheckBox.setSelected(b);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setConnectivity(int connectivity) {
/*  709 */       if ((InteractiveMarkerControlledWatershed.this.inputImage.getImageStackSize() > 1 && (connectivity == 6 || connectivity == 26)) || (
/*  710 */         InteractiveMarkerControlledWatershed.this.inputImage.getImageStackSize() == 1 && (connectivity == 4 || connectivity == 8))) {
/*  711 */         InteractiveMarkerControlledWatershed.this.connectivityList.setSelectedItem(Integer.toString(connectivity));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getSegmentText() {
/*  720 */       return InteractiveMarkerControlledWatershed.this.segmentText;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void runSegmentation(String command) {
/*  729 */       if (command.equals(InteractiveMarkerControlledWatershed.this.segmentText)) {
/*      */ 
/*      */         
/*  732 */         final int connectivity, readConn = 
/*  733 */           Integer.parseInt(
/*  734 */             (String)InteractiveMarkerControlledWatershed.this.connectivityList.getSelectedItem());
/*      */ 
/*      */ 
/*      */         
/*  738 */         if (InteractiveMarkerControlledWatershed.this.inputIs2D) {
/*  739 */           connectivity = (readConn == 4) ? 6 : 26;
/*      */         } else {
/*  741 */           connectivity = readConn;
/*      */         } 
/*      */         
/*  744 */         InteractiveMarkerControlledWatershed.this.segmentButton.setText(InteractiveMarkerControlledWatershed.this.stopText);
/*  745 */         InteractiveMarkerControlledWatershed.this.segmentButton.setToolTipText(InteractiveMarkerControlledWatershed.this.stopTip);
/*  746 */         InteractiveMarkerControlledWatershed.this.segmentButton.setSize(InteractiveMarkerControlledWatershed.this.segmentButton.getMinimumSize());
/*  747 */         InteractiveMarkerControlledWatershed.this.segmentButton.repaint();
/*      */         
/*  749 */         final Thread oldThread = InteractiveMarkerControlledWatershed.this.segmentationThread;
/*      */ 
/*      */         
/*  752 */         Thread newThread = new Thread()
/*      */           {
/*      */             public void run()
/*      */             {
/*  756 */               if (oldThread != null) {
/*      */                 
/*      */                 try {
/*  759 */                   IJ.log("Waiting for old task to finish...");
/*  760 */                   oldThread.join();
/*      */                 }
/*  762 */                 catch (InterruptedException interruptedException) {}
/*      */               }
/*      */ 
/*      */               
/*  766 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).calculateDams = (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).damsCheckBox.isSelected();
/*      */ 
/*      */               
/*  769 */               InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this).setParamsEnabled(false);
/*      */ 
/*      */               
/*  772 */               Roi roi = (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).displayImage.getRoi();
/*  773 */               if ((roi == null && RoiManager.getInstance() == null) || (
/*  774 */                 RoiManager.getInstance() != null && 
/*  775 */                 RoiManager.getInstance().getSelectedIndex() == -1)) {
/*      */                 
/*  777 */                 IJ.showMessage("Please define the markers using for example the point selection tool.");
/*      */                 
/*  779 */                 IJ.showProgress(1.0D);
/*      */                 
/*  781 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentText);
/*  782 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setToolTipText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentTip);
/*      */                 
/*      */                 return;
/*      */               } 
/*  786 */               long start = System.currentTimeMillis();
/*      */ 
/*      */               
/*  789 */               double maxValue = 3.4028234663852886E38D;
/*      */               
/*  791 */               ImageStack markerStack = 
/*  792 */                 new ImageStack((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getWidth(), (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getHeight());
/*  793 */               ImageProcessor[] markerSlice = 
/*  794 */                 new ImageProcessor[(InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getImageStackSize()]; int n;
/*  795 */               for (n = 0; n < (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getImageStackSize(); n++) {
/*      */                 
/*  797 */                 markerSlice[n] = 
/*  798 */                   (ImageProcessor)new FloatProcessor((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getWidth(), (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getHeight());
/*      */                 
/*  800 */                 markerSlice[n].setValue(3.4028234663852886E38D);
/*  801 */                 markerSlice[n].setColor(3.4028234663852886E38D);
/*      */               } 
/*  803 */               if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputIs2D) {
/*      */ 
/*      */                 
/*  806 */                 if (RoiManager.getInstance() != null) {
/*      */                   
/*  808 */                   RoiManager manager = RoiManager.getInstance();
/*  809 */                   int[] selected = manager.getSelectedIndexes();
/*  810 */                   if (selected.length > 0)
/*      */                   {
/*  812 */                     for (int i = 0; i < selected.length; i++) {
/*      */                       
/*  814 */                       Roi selectedRoi = manager.getRoi(i);
/*  815 */                       if (selectedRoi.isArea()) {
/*  816 */                         markerSlice[0].fill(selectedRoi);
/*      */                       } else {
/*  818 */                         markerSlice[0].draw(selectedRoi);
/*      */                       } 
/*      */                     } 
/*      */                   }
/*  822 */                 } else if (roi.isArea()) {
/*  823 */                   markerSlice[0].fill(roi);
/*      */                 } else {
/*  825 */                   markerSlice[0].draw(roi);
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*  830 */               else if (roi instanceof PointRoi) {
/*      */                 
/*  832 */                 int[] xpoints = (roi.getPolygon()).xpoints;
/*  833 */                 int[] ypoints = (roi.getPolygon()).ypoints;
/*      */                 
/*  835 */                 for (int i = 0; i < xpoints.length; i++)
/*      */                 {
/*  837 */                   markerSlice[((PointRoi)roi).getPointPosition(i) - 1].draw(
/*  838 */                       (Roi)new PointRoi(xpoints[i], ypoints[i]));
/*      */                 
/*      */                 }
/*      */               }
/*  842 */               else if (RoiManager.getInstance() != null) {
/*      */                 
/*  844 */                 RoiManager manager = RoiManager.getInstance();
/*  845 */                 int[] selected = manager.getSelectedIndexes();
/*  846 */                 if (selected.length > 0) {
/*      */                   
/*  848 */                   for (int i = 0; i < selected.length; i++) {
/*      */                     
/*  850 */                     Roi selectedRoi = manager.getRoi(i);
/*  851 */                     int slice = 
/*  852 */                       manager.getSliceNumber(manager.getName(i));
/*  853 */                     if (slice == -1)
/*  854 */                       slice = (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).displayImage.getCurrentSlice(); 
/*  855 */                     if (selectedRoi.isArea()) {
/*  856 */                       markerSlice[slice - 1].fill(selectedRoi);
/*      */                     } else {
/*  858 */                       markerSlice[slice - 1].draw(selectedRoi);
/*      */                     } 
/*      */                   } 
/*      */                 } else {
/*      */                   
/*  863 */                   IJ.error("Please select the ROIs you want to use as markers in the ROI manager.");
/*      */                   
/*  865 */                   IJ.showProgress(1.0D);
/*      */                   
/*  867 */                   (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentText);
/*  868 */                   (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setToolTipText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentTip);
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*      */                   return;
/*      */                 } 
/*      */               } else {
/*  876 */                 int slice = (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).displayImage.getCurrentSlice();
/*      */                 
/*  878 */                 if (roi.isArea()) {
/*  879 */                   markerSlice[slice - 1].fill(roi);
/*      */                 } else {
/*  881 */                   markerSlice[slice - 1].draw(roi);
/*      */                 } 
/*      */               } 
/*      */               
/*  885 */               for (n = 0; n < (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getImageStackSize(); n++)
/*      */               {
/*  887 */                 markerStack.addSlice(markerSlice[n]);
/*      */               }
/*      */               
/*  890 */               markerStack = BinaryImages.componentsLabeling(
/*  891 */                   markerStack, connectivity, 32);
/*  892 */               ImagePlus marker = new ImagePlus("marker", markerStack);
/*      */               
/*      */               try {
/*  895 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage = Watershed.computeWatershed((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage, marker, null, 
/*  896 */                     connectivity, (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).calculateDams, false);
/*      */               }
/*  898 */               catch (Exception ex) {
/*      */                 
/*  900 */                 ex.printStackTrace();
/*  901 */                 IJ.log("Error while runing watershed: " + ex.getMessage());
/*      */               }
/*  903 */               catch (OutOfMemoryError err) {
/*      */                 
/*  905 */                 err.printStackTrace();
/*  906 */                 IJ.log("Error: the plugin run out of memory. Please use a smaller input image.");
/*      */               } 
/*  908 */               if ((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage == null) {
/*      */                 
/*  910 */                 IJ.log("The segmentation was interrupted!");
/*  911 */                 IJ.showStatus("The segmentation was interrupted!");
/*  912 */                 IJ.showProgress(1.0D);
/*      */                 
/*  914 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentText);
/*  915 */                 (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setToolTipText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentTip);
/*      */                 
/*      */                 return;
/*      */               } 
/*  919 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage.setTitle(String.valueOf((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getShortTitle()) + "-Waterhsed");
/*  920 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage.setCalibration((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).inputImage.getCalibration());
/*      */               
/*  922 */               long end = System.currentTimeMillis();
/*  923 */               IJ.showStatus("Whole plugin took " + (end - start) + " ms.");
/*      */ 
/*      */               
/*  926 */               Images3D.optimizeDisplayRange((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage);
/*      */               
/*  928 */               byte[][] colorMap = ColorMaps.CommonLabelMaps.fromLabel(ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel()).computeLut(255, false);
/*  929 */               ColorModel cm = ColorMaps.createColorModel(colorMap, Color.BLACK);
/*  930 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage.getProcessor().setColorModel(cm);
/*  931 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage.getImageStack().setColorModel(cm);
/*  932 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).resultImage.updateAndDraw();
/*      */ 
/*      */               
/*  935 */               InteractiveMarkerControlledWatershed.CustomWindow.this.updateDisplayImage();
/*  936 */               InteractiveMarkerControlledWatershed.CustomWindow.this.updateResultOverlay();
/*      */               
/*  938 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).showColorOverlay = true;
/*  939 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).toggleOverlayCheckBox.setSelected(true);
/*      */ 
/*      */               
/*  942 */               InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this).setParamsEnabled(true);
/*      */               
/*  944 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentText);
/*  945 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentButton.setToolTipText((InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentTip);
/*      */               
/*  947 */               (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).segmentationThread = null;
/*      */ 
/*      */               
/*  950 */               String[] arg = {
/*  951 */                   "calculateDams=" + (InteractiveMarkerControlledWatershed.CustomWindow.access$3(InteractiveMarkerControlledWatershed.CustomWindow.this)).calculateDams, 
/*  952 */                   "connectivity=" + Integer.toString(readConn) };
/*  953 */               InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.RUN_SEGMENTATION, arg);
/*      */             }
/*      */           };
/*      */         
/*  957 */         InteractiveMarkerControlledWatershed.this.segmentationThread = newThread;
/*  958 */         newThread.start();
/*      */       
/*      */       }
/*  961 */       else if (command.equals(InteractiveMarkerControlledWatershed.this.stopText)) {
/*      */         
/*  963 */         if (InteractiveMarkerControlledWatershed.this.segmentationThread != null) {
/*  964 */           InteractiveMarkerControlledWatershed.this.segmentationThread.interrupt();
/*      */         } else {
/*  966 */           IJ.log("Error: interrupting segmentation failed becaused the thread is null!");
/*      */         } 
/*      */         
/*  969 */         InteractiveMarkerControlledWatershed.this.segmentButton.setText(InteractiveMarkerControlledWatershed.this.segmentText);
/*  970 */         InteractiveMarkerControlledWatershed.this.segmentButton.setToolTipText(InteractiveMarkerControlledWatershed.this.segmentTip);
/*      */         
/*  972 */         InteractiveMarkerControlledWatershed.this.setParamsEnabled(true);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void updateDisplayImage() {
/*  981 */       int slice = InteractiveMarkerControlledWatershed.this.displayImage.getCurrentSlice();
/*  982 */       InteractiveMarkerControlledWatershed.this.displayImage.setStack(InteractiveMarkerControlledWatershed.this.inputStackCopy);
/*  983 */       InteractiveMarkerControlledWatershed.this.displayImage.setSlice(slice);
/*  984 */       InteractiveMarkerControlledWatershed.this.displayImage.updateAndDraw();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void toggleOverlay() {
/*  992 */       InteractiveMarkerControlledWatershed.this.showColorOverlay = !InteractiveMarkerControlledWatershed.this.showColorOverlay;
/*      */       
/*  994 */       InteractiveMarkerControlledWatershed.this.toggleOverlayCheckBox.setSelected(InteractiveMarkerControlledWatershed.this.showColorOverlay);
/*      */       
/*  996 */       if (InteractiveMarkerControlledWatershed.this.showColorOverlay) {
/*  997 */         updateResultOverlay();
/*      */       } else {
/*  999 */         InteractiveMarkerControlledWatershed.this.displayImage.setOverlay(null);
/* 1000 */       }  InteractiveMarkerControlledWatershed.this.displayImage.updateAndDraw();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void createResultImage() {
/* 1008 */       if (InteractiveMarkerControlledWatershed.this.resultImage != null) {
/*      */ 
/*      */         
/* 1011 */         String displayOption = (String)InteractiveMarkerControlledWatershed.this.resultDisplayList.getSelectedItem();
/*      */         
/* 1013 */         ImagePlus watershedResult = null;
/*      */ 
/*      */         
/* 1016 */         if (displayOption.equals(InteractiveMarkerControlledWatershed.catchmentBasinsText)) {
/* 1017 */           watershedResult = getResult(InteractiveMarkerControlledWatershed.ResultMode.BASINS);
/* 1018 */         } else if (displayOption.equals(InteractiveMarkerControlledWatershed.overlaidDamsText)) {
/* 1019 */           watershedResult = getResult(InteractiveMarkerControlledWatershed.ResultMode.OVERLAID_DAMS);
/* 1020 */         } else if (displayOption.equals(InteractiveMarkerControlledWatershed.watershedLinesText)) {
/* 1021 */           watershedResult = getResult(InteractiveMarkerControlledWatershed.ResultMode.LINES);
/* 1022 */         } else if (displayOption.equals(InteractiveMarkerControlledWatershed.overlaidBasinsText)) {
/* 1023 */           watershedResult = getResult(InteractiveMarkerControlledWatershed.ResultMode.OVERLAID_BASINS);
/*      */         } 
/* 1025 */         if (watershedResult != null) {
/*      */           
/* 1027 */           watershedResult.show();
/* 1028 */           watershedResult.setSlice(InteractiveMarkerControlledWatershed.this.displayImage.getCurrentSlice());
/*      */         } 
/*      */ 
/*      */         
/* 1032 */         InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.CREATE_IMAGE, new String[0]);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void mergeLabels() {
/* 1040 */       if (InteractiveMarkerControlledWatershed.this.resultImage == null) {
/*      */         
/* 1042 */         IJ.error("You need to run the segmentation before merging labels!");
/*      */         
/*      */         return;
/*      */       } 
/* 1046 */       Roi roi = InteractiveMarkerControlledWatershed.this.displayImage.getRoi();
/* 1047 */       if (roi == null) {
/*      */         
/* 1049 */         IJ.showMessage("Please select some labels to merge using any of the selection tools");
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1055 */       LabelImages.mergeLabels(InteractiveMarkerControlledWatershed.this.resultImage, roi, true);
/*      */       
/* 1057 */       if (InteractiveMarkerControlledWatershed.this.showColorOverlay) {
/* 1058 */         updateResultOverlay();
/*      */       }
/*      */       
/* 1061 */       InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.MERGE_LABELS, new String[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void shuffleColors() {
/* 1069 */       if (InteractiveMarkerControlledWatershed.this.resultImage != null) {
/*      */         
/* 1071 */         byte[][] colorMap = ColorMaps.CommonLabelMaps.fromLabel(
/* 1072 */             ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel())
/* 1073 */           .computeLut(255, false);
/*      */         
/* 1075 */         long seed = (new Random()).nextInt();
/* 1076 */         colorMap = ColorMaps.shuffleLut(colorMap, seed);
/*      */         
/* 1078 */         ColorModel cm = ColorMaps.createColorModel(
/* 1079 */             colorMap, Color.BLACK);
/* 1080 */         InteractiveMarkerControlledWatershed.this.resultImage.getProcessor().setColorModel(cm);
/* 1081 */         InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().setColorModel(cm);
/* 1082 */         InteractiveMarkerControlledWatershed.this.resultImage.updateAndDraw();
/* 1083 */         if (InteractiveMarkerControlledWatershed.this.showColorOverlay) {
/* 1084 */           updateResultOverlay();
/*      */         }
/*      */       } 
/* 1087 */       InteractiveMarkerControlledWatershed.record(InteractiveMarkerControlledWatershed.SHUFFLE_COLORS, new String[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ImagePlus getResult(InteractiveMarkerControlledWatershed.ResultMode mode) {
/*      */       ImageStack is;
/* 1098 */       String title = InteractiveMarkerControlledWatershed.this.inputImage.getTitle();
/* 1099 */       String ext = "";
/* 1100 */       int index = title.lastIndexOf(".");
/* 1101 */       if (index != -1) {
/*      */         
/* 1103 */         ext = title.substring(index);
/* 1104 */         title = title.substring(0, index);
/*      */       } 
/*      */       
/* 1107 */       ImagePlus result = null;
/*      */ 
/*      */       
/* 1110 */       if (!InteractiveMarkerControlledWatershed.this.showColorOverlay) {
/*      */         
/* 1112 */         result = InteractiveMarkerControlledWatershed.this.displayImage.duplicate();
/* 1113 */         result.setTitle(String.valueOf(title) + ext);
/* 1114 */         return result;
/*      */       } 
/*      */ 
/*      */       
/* 1118 */       switch (mode) {
/*      */         case OVERLAID_BASINS:
/* 1120 */           result = InteractiveMarkerControlledWatershed.this.displayImage.duplicate();
/* 1121 */           result.setOverlay(null);
/* 1122 */           is = new ImageStack(InteractiveMarkerControlledWatershed.this.displayImage.getWidth(), InteractiveMarkerControlledWatershed.this.displayImage.getHeight());
/*      */           
/* 1124 */           for (this.slice = 1; this.slice <= result.getImageStackSize(); this.slice++) {
/*      */             
/* 1126 */             ImagePlus aux = new ImagePlus("", result.getImageStack().getProcessor(this.slice));
/* 1127 */             ImageRoi roi = new ImageRoi(0, 0, InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().getProcessor(this.slice));
/* 1128 */             roi.setOpacity(InteractiveMarkerControlledWatershed.this.opacity);
/* 1129 */             aux.setOverlay(new Overlay((Roi)roi));
/* 1130 */             aux = aux.flatten();
/* 1131 */             is.addSlice(aux.getProcessor());
/*      */           } 
/* 1133 */           result.setStack(is);
/* 1134 */           result.setTitle(String.valueOf(title) + "-overlaid-basins" + ext);
/*      */           break;
/*      */         case null:
/* 1137 */           result = InteractiveMarkerControlledWatershed.this.resultImage.duplicate();
/* 1138 */           result.setTitle(String.valueOf(title) + "-catchment-basins" + ext);
/*      */           break;
/*      */         case OVERLAID_DAMS:
/* 1141 */           result = InteractiveMarkerControlledWatershed.this.getWatershedLines(InteractiveMarkerControlledWatershed.this.resultImage);
/* 1142 */           result = ColorImages.binaryOverlay(InteractiveMarkerControlledWatershed.this.displayImage, result, Color.red);
/* 1143 */           result.setTitle(String.valueOf(title) + "-overlaid-dams" + ext);
/*      */           break;
/*      */         case LINES:
/* 1146 */           result = InteractiveMarkerControlledWatershed.this.getWatershedLines(InteractiveMarkerControlledWatershed.this.resultImage);
/* 1147 */           IJ.run(result, "Invert", "stack");
/* 1148 */           result.setTitle(String.valueOf(title) + "-watershed-lines" + ext);
/*      */           break;
/*      */       } 
/*      */       
/* 1152 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setResultDisplayOption(String option) {
/* 1161 */       if (Arrays.<String>asList(InteractiveMarkerControlledWatershed.this.resultDisplayOption).contains(option)) {
/* 1162 */         InteractiveMarkerControlledWatershed.this.resultDisplayList.setSelectedItem(option);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getResultDisplayOption() {
/* 1171 */       return (String)InteractiveMarkerControlledWatershed.this.resultDisplayList.getSelectedItem();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void updateResultOverlay() {
/* 1180 */       if (InteractiveMarkerControlledWatershed.this.resultImage != null) {
/*      */         
/* 1182 */         int slice = InteractiveMarkerControlledWatershed.this.displayImage.getCurrentSlice();
/*      */         
/* 1184 */         String displayOption = (String)InteractiveMarkerControlledWatershed.this.resultDisplayList.getSelectedItem();
/*      */         
/* 1186 */         ImageRoi roi = null;
/*      */         
/* 1188 */         if (displayOption.equals(InteractiveMarkerControlledWatershed.catchmentBasinsText)) {
/*      */           
/* 1190 */           roi = new ImageRoi(0, 0, InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().getProcessor(slice));
/* 1191 */           roi.setOpacity(1.0D);
/*      */         }
/* 1193 */         else if (displayOption.equals(InteractiveMarkerControlledWatershed.overlaidDamsText)) {
/*      */           
/* 1195 */           ImageProcessor lines = BinaryImages.binarize(InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().getProcessor(slice));
/* 1196 */           lines.invert();
/* 1197 */           lines.setLut(LUT.createLutFromColor(Color.red));
/* 1198 */           roi = new ImageRoi(0, 0, lines);
/* 1199 */           roi.setZeroTransparent(true);
/* 1200 */           roi.setOpacity(1.0D);
/*      */         }
/* 1202 */         else if (displayOption.equals(InteractiveMarkerControlledWatershed.watershedLinesText)) {
/*      */           
/* 1204 */           roi = new ImageRoi(0, 0, BinaryImages.binarize(InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().getProcessor(slice)));
/* 1205 */           roi.setOpacity(1.0D);
/*      */         }
/* 1207 */         else if (displayOption.equals(InteractiveMarkerControlledWatershed.overlaidBasinsText)) {
/*      */           
/* 1209 */           roi = new ImageRoi(0, 0, InteractiveMarkerControlledWatershed.this.resultImage.getImageStack().getProcessor(slice));
/* 1210 */           roi.setOpacity(InteractiveMarkerControlledWatershed.this.opacity);
/*      */         } 
/*      */         
/* 1213 */         InteractiveMarkerControlledWatershed.this.displayImage.setOverlay(new Overlay((Roi)roi));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isShowResultOverlaySelected() {
/* 1223 */       return InteractiveMarkerControlledWatershed.this.showColorOverlay;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ImagePlus getWatershedLines(ImagePlus labels) {
/* 1235 */     ImagePlus lines = BinaryImages.binarize(labels);
/* 1236 */     IJ.run(lines, "Invert", "stack");
/* 1237 */     return lines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setParamsEnabled(boolean enabled) {
/* 1248 */     this.toggleOverlayCheckBox.setEnabled(enabled);
/* 1249 */     this.resultButton.setEnabled(enabled);
/* 1250 */     this.resultDisplayList.setEnabled(enabled);
/* 1251 */     this.displayLabel.setEnabled(enabled);
/* 1252 */     this.mergeButton.setEnabled(enabled);
/* 1253 */     this.shuffleColorsButton.setEnabled(enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableAdvancedOptions(boolean enabled) {
/* 1263 */     this.damsCheckBox.setEnabled(enabled);
/* 1264 */     this.connectivityLabel.setEnabled(enabled);
/* 1265 */     this.connectivityList.setEnabled(enabled);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void run(String arg0) {
/* 1271 */     if (IJ.getVersion().compareTo("1.48a") < 0) {
/*      */       
/* 1273 */       IJ.error("Interactive Marker-controlled Watershed", "ERROR: detected ImageJ version " + IJ.getVersion() + 
/* 1274 */           ".\nInteractive Marker-controlled Watershed requires version 1.48a or superior, please update ImageJ!");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1279 */     if (WindowManager.getCurrentImage() == null) {
/*      */       
/* 1281 */       this.inputImage = IJ.openImage();
/* 1282 */       if (this.inputImage == null)
/*      */         return; 
/*      */     } else {
/* 1285 */       this.inputImage = WindowManager.getCurrentImage();
/*      */     } 
/* 1287 */     if (this.inputImage.getType() == 3 || 
/* 1288 */       this.inputImage.getType() == 4) {
/*      */       
/* 1290 */       IJ.error("Interactive Marker-controlled Watershed", 
/* 1291 */           "This plugin only works on grayscale images.\nPlease convert it to 8, 16 or 32-bit.");
/*      */       
/*      */       return;
/*      */     } 
/* 1295 */     this.inputStackCopy = this.inputImage.getImageStack().duplicate();
/* 1296 */     this.displayImage = new ImagePlus(this.inputImage.getTitle(), 
/* 1297 */         this.inputStackCopy);
/* 1298 */     this.displayImage.setTitle("Marker-controlled Watershed");
/* 1299 */     this.displayImage.setSlice(this.inputImage.getCurrentSlice());
/* 1300 */     this.displayImage.setRoi(this.inputImage.getRoi());
/*      */ 
/*      */     
/* 1303 */     this.inputImage.getWindow().setVisible(false);
/*      */ 
/*      */     
/* 1306 */     this.inputIs2D = (this.inputImage.getImageStackSize() == 1);
/*      */ 
/*      */     
/* 1309 */     if (!this.inputIs2D && 
/* 1310 */       !this.displayImage.isHyperStack() && 
/* 1311 */       this.displayImage.getNSlices() == 1)
/*      */     {
/*      */       
/* 1314 */       this.displayImage.setDimensions(1, this.displayImage.getNFrames(), 1);
/*      */     }
/*      */ 
/*      */     
/* 1318 */     SwingUtilities.invokeLater(
/* 1319 */         new Runnable() {
/*      */           public void run() {
/* 1321 */             InteractiveMarkerControlledWatershed.this.win = new InteractiveMarkerControlledWatershed.CustomWindow(InteractiveMarkerControlledWatershed.this.displayImage);
/* 1322 */             InteractiveMarkerControlledWatershed.this.win.pack();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void record(String command, String... args) {
/* 1341 */     command = "call(\"inra.ijpb.plugins.InteractiveMarkerControlledWatershed." + command;
/* 1342 */     for (int i = 0; i < args.length; i++)
/* 1343 */       command = String.valueOf(command) + "\", \"" + args[i]; 
/* 1344 */     command = String.valueOf(command) + "\");\n";
/* 1345 */     if (Recorder.record) {
/* 1346 */       Recorder.recordString(command);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void segment(String calculateDams, String connectivity) {
/* 1359 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1360 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1362 */       CustomWindow win = (CustomWindow)iw;
/* 1363 */       win.setCalculateDams(calculateDams.contains("true"));
/* 1364 */       win.setConnectivity(Integer.parseInt(connectivity.replace("connectivity=", "")));
/* 1365 */       win.runSegmentation(win.getSegmentText());
/*      */     } else {
/*      */       
/* 1368 */       IJ.log("Error: Interactive Marker-controlled Watershed GUI not detected.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void toggleOverlay() {
/* 1375 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1376 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1378 */       CustomWindow win = (CustomWindow)iw;
/* 1379 */       win.toggleOverlay();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void mergeLabels() {
/* 1388 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1389 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1391 */       CustomWindow win = (CustomWindow)iw;
/* 1392 */       win.mergeLabels();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shuffleColors() {
/* 1400 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1401 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1403 */       CustomWindow win = (CustomWindow)iw;
/* 1404 */       win.shuffleColors();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void createResultImage() {
/* 1413 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1414 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1416 */       CustomWindow win = (CustomWindow)iw;
/* 1417 */       String mode = win.getResultDisplayOption();
/*      */       
/* 1419 */       ImagePlus result = null;
/*      */       
/* 1421 */       if (mode.equals(catchmentBasinsText)) {
/* 1422 */         result = win.getResult(ResultMode.BASINS);
/* 1423 */       } else if (mode.equals(overlaidBasinsText)) {
/* 1424 */         result = win.getResult(ResultMode.OVERLAID_BASINS);
/* 1425 */       } else if (mode.equals(watershedLinesText)) {
/* 1426 */         result = win.getResult(ResultMode.LINES);
/* 1427 */       } else if (mode.equals(overlaidDamsText)) {
/* 1428 */         result = win.getResult(ResultMode.OVERLAID_DAMS);
/*      */       } 
/* 1430 */       if (result != null) {
/*      */         
/* 1432 */         result.show();
/* 1433 */         result.setSlice(win.getImagePlus().getCurrentSlice());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDisplayFormat(String format) {
/* 1444 */     ImageWindow iw = WindowManager.getCurrentImage().getWindow();
/* 1445 */     if (iw instanceof CustomWindow) {
/*      */       
/* 1447 */       CustomWindow win = (CustomWindow)iw;
/* 1448 */       win.setResultDisplayOption(format);
/* 1449 */       if (win.isShowResultOverlaySelected())
/* 1450 */         win.updateResultOverlay(); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/InteractiveMarkerControlledWatershed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */