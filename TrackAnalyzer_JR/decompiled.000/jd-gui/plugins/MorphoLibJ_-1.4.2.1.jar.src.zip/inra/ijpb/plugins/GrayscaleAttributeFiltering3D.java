/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.data.image.Images3D;
/*     */ import inra.ijpb.morphology.AttributeFiltering;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrayscaleAttributeFiltering3D
/*     */   implements PlugIn
/*     */ {
/*     */   enum Operation
/*     */   {
/*  48 */     CLOSING("Closing"),
/*  49 */     OPENING("Opening"),
/*  50 */     TOP_HAT("Top Hat"),
/*  51 */     BOTTOM_HAT("Bottom Hat");
/*     */     
/*     */     String label;
/*     */ 
/*     */     
/*     */     Operation(String label) {
/*  57 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/*  62 */       int n = (values()).length;
/*  63 */       String[] result = new String[n];
/*     */       
/*  65 */       int i = 0; byte b; int j; Operation[] arrayOfOperation;
/*  66 */       for (j = (arrayOfOperation = values()).length, b = 0; b < j; ) { Operation op = arrayOfOperation[b];
/*  67 */         result[i++] = op.label; b++; }
/*     */       
/*  69 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operation fromLabel(String opLabel) {
/*  83 */       if (opLabel != null)
/*  84 */         opLabel = opLabel.toLowerCase();  byte b; int i; Operation[] arrayOfOperation;
/*  85 */       for (i = (arrayOfOperation = values()).length, b = 0; b < i; ) { Operation op = arrayOfOperation[b];
/*     */         
/*  87 */         String cmp = op.label.toLowerCase();
/*  88 */         if (cmp.equals(opLabel))
/*  89 */           return op;  b++; }
/*     */       
/*  91 */       throw new IllegalArgumentException("Unable to parse Operation with label: " + 
/*  92 */           opLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   enum Attribute
/*     */   {
/* 100 */     VOLUME("Volume");
/*     */     
/*     */     String label;
/*     */ 
/*     */     
/*     */     Attribute(String label) {
/* 106 */       this.label = label;
/*     */     }
/*     */ 
/*     */     
/*     */     public static String[] getAllLabels() {
/* 111 */       int n = (values()).length;
/* 112 */       String[] result = new String[n];
/*     */       
/* 114 */       int i = 0; byte b; int j; Attribute[] arrayOfAttribute;
/* 115 */       for (j = (arrayOfAttribute = values()).length, b = 0; b < j; ) { Attribute att = arrayOfAttribute[b];
/* 116 */         result[i++] = att.label; b++; }
/* 117 */        return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Attribute fromLabel(String attrLabel) {
/* 131 */       if (attrLabel != null)
/* 132 */         attrLabel = attrLabel.toLowerCase();  byte b; int i; Attribute[] arrayOfAttribute;
/* 133 */       for (i = (arrayOfAttribute = values()).length, b = 0; b < i; ) { Attribute op = arrayOfAttribute[b];
/*     */         
/* 135 */         String cmp = op.label.toLowerCase();
/* 136 */         if (cmp.equals(attrLabel))
/* 137 */           return op;  b++; }
/*     */       
/* 139 */       throw new IllegalArgumentException("Unable to parse Attribute with label: " + 
/* 140 */           attrLabel);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   static final String[] connectivityLabels = new String[] { "6", "26" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   static final int[] connectivityValues = new int[] { 6, 26 };
/*     */   
/* 154 */   static Operation operation = Operation.OPENING;
/* 155 */   static Attribute attribute = Attribute.VOLUME;
/* 156 */   static int nPixelMin = 100;
/* 157 */   static int connectivityChoice = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String arg0) {
/* 165 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/* 167 */     if (imagePlus.getImageStackSize() < 2) {
/*     */       
/* 169 */       IJ.error("Gray Scale Attribute Filtering 3D", 
/* 170 */           "Input image must be 3D");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 175 */     String title = "Gray Scale Attribute Filtering 3D";
/* 176 */     GenericDialog gd = new GenericDialog(title);
/* 177 */     gd.addChoice("Operation", Operation.getAllLabels(), 
/* 178 */         operation.label);
/* 179 */     gd.addChoice("Attribute", Attribute.getAllLabels(), 
/* 180 */         attribute.label);
/* 181 */     String label = "Min Voxel Number:";
/* 182 */     gd.addNumericField(label, nPixelMin, 0);
/* 183 */     gd.addChoice("Connectivity", connectivityLabels, 
/* 184 */         connectivityLabels[connectivityChoice]);
/* 185 */     gd.showDialog();
/*     */ 
/*     */     
/* 188 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 192 */     operation = Operation.fromLabel(gd.getNextChoice());
/* 193 */     attribute = Attribute.fromLabel(gd.getNextChoice());
/* 194 */     nPixelMin = (int)gd.getNextNumber();
/* 195 */     connectivityChoice = gd.getNextChoiceIndex();
/* 196 */     int connectivity = connectivityValues[connectivityChoice];
/*     */ 
/*     */     
/* 199 */     String newName = String.valueOf(imagePlus.getShortTitle()) + "-attrFilt";
/*     */ 
/*     */     
/* 202 */     ImagePlus image2 = imagePlus.duplicate();
/* 203 */     if (operation == Operation.CLOSING || 
/* 204 */       operation == Operation.BOTTOM_HAT)
/*     */     {
/* 206 */       IJ.run(image2, "Invert", "stack");
/*     */     }
/*     */ 
/*     */     
/* 210 */     ImageStack image = image2.getStack();
/* 211 */     ImageStack result = 
/* 212 */       AttributeFiltering.volumeOpening(
/* 213 */         image, nPixelMin, connectivity);
/* 214 */     ImagePlus resultPlus = new ImagePlus(newName, result);
/*     */ 
/*     */ 
/*     */     
/* 218 */     if (operation == Operation.TOP_HAT || 
/* 219 */       operation == Operation.BOTTOM_HAT) {
/*     */       
/* 221 */       for (int x = 0; x < image.getWidth(); x++) {
/* 222 */         for (int y = 0; y < image.getHeight(); y++) {
/* 223 */           for (int z = 0; z < image.getSize(); z++)
/*     */           {
/* 225 */             double diff = Math.abs(result.getVoxel(x, y, z) - 
/* 226 */                 image.getVoxel(x, y, z));
/* 227 */             result.setVoxel(x, y, z, diff);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 232 */     } else if (operation == Operation.CLOSING) {
/* 233 */       IJ.run(resultPlus, "Invert", "stack");
/*     */     } 
/*     */     
/* 236 */     resultPlus.copyScale(imagePlus);
/* 237 */     Images3D.optimizeDisplayRange(resultPlus);
/* 238 */     resultPlus.updateAndDraw();
/* 239 */     resultPlus.show();
/* 240 */     resultPlus.setSlice(imagePlus.getCurrentSlice());
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/GrayscaleAttributeFiltering3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */