/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.PlugIn;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.geometry.Box3D;
/*     */ import inra.ijpb.geometry.Ellipsoid;
/*     */ import inra.ijpb.geometry.Point3D;
/*     */ import inra.ijpb.geometry.Sphere;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.IntrinsicVolumes3D;
/*     */ import inra.ijpb.measure.region3d.BoundingBox3D;
/*     */ import inra.ijpb.measure.region3d.Centroid3D;
/*     */ import inra.ijpb.measure.region3d.EquivalentEllipsoid;
/*     */ import inra.ijpb.measure.region3d.IntrinsicVolumesAnalyzer3D;
/*     */ import inra.ijpb.measure.region3d.LargestInscribedBall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzeRegions3D
/*     */   implements PlugIn
/*     */ {
/*  69 */   private static final String[] connectivityNames = new String[] {
/*  70 */       "C6", "C26"
/*     */     };
/*     */   
/*  73 */   private static final int[] connectivityValues = new int[] { 6, 26 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static final String[] surfaceAreaMethods = new String[] {
/*  79 */       "Crofton  (3 dirs.)", 
/*  80 */       "Crofton (13 dirs.)"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final int[] dirNumbers = new int[] {
/*  87 */       3, 13
/*     */     };
/*     */   
/*     */   public boolean debug = false;
/*     */   
/*     */   boolean computeVolume = true;
/*     */   
/*     */   boolean computeSurface = true;
/*     */   
/*     */   boolean computeMeanBreadth = true;
/*     */   
/*     */   boolean computeEulerNumber = true;
/*     */   
/*     */   boolean computeSphericity = true;
/*     */   
/*     */   boolean computeBoundingBox = true;
/*     */   
/*     */   boolean computeCentroid = true;
/*     */   
/*     */   boolean computeEllipsoid = true;
/*     */   
/*     */   boolean computeElongations = true;
/*     */   
/*     */   boolean computeInscribedBall = true;
/*     */   
/* 112 */   String surfaceAreaMethod = surfaceAreaMethods[1];
/* 113 */   int surfaceAreaDirs = 13;
/* 114 */   int meanBreadthDirs = 13;
/* 115 */   int connectivity = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(String args) {
/* 126 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/* 128 */     if (imagePlus.getStackSize() == 1) {
/*     */       
/* 130 */       IJ.error("Requires a Stack");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 135 */     GenericDialog gd = new GenericDialog("Analyze Regions 3D");
/* 136 */     gd.addCheckbox("Volume", true);
/* 137 */     gd.addCheckbox("Surface_Area", true);
/* 138 */     gd.addCheckbox("Mean_Breadth", true);
/* 139 */     gd.addCheckbox("Sphericity", true);
/* 140 */     gd.addCheckbox("Euler_Number", true);
/* 141 */     gd.addCheckbox("Bounding_Box", true);
/* 142 */     gd.addCheckbox("Centroid", true);
/* 143 */     gd.addCheckbox("Equivalent_Ellipsoid", true);
/* 144 */     gd.addCheckbox("Ellipsoid_Elongations", true);
/* 145 */     gd.addCheckbox("Max._Inscribed Ball", true);
/* 146 */     gd.addMessage("");
/* 147 */     gd.addChoice("Surface_area_method:", surfaceAreaMethods, surfaceAreaMethods[1]);
/* 148 */     gd.addChoice("Euler_Connectivity:", connectivityNames, connectivityNames[1]);
/* 149 */     gd.showDialog();
/*     */ 
/*     */     
/* 152 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 156 */     this.computeVolume = gd.getNextBoolean();
/* 157 */     this.computeSurface = gd.getNextBoolean();
/* 158 */     this.computeMeanBreadth = gd.getNextBoolean();
/* 159 */     this.computeSphericity = gd.getNextBoolean();
/* 160 */     this.computeEulerNumber = gd.getNextBoolean();
/* 161 */     this.computeBoundingBox = gd.getNextBoolean();
/* 162 */     this.computeCentroid = gd.getNextBoolean();
/* 163 */     this.computeEllipsoid = gd.getNextBoolean();
/* 164 */     this.computeElongations = gd.getNextBoolean();
/* 165 */     this.computeInscribedBall = gd.getNextBoolean();
/*     */ 
/*     */ 
/*     */     
/* 169 */     this.surfaceAreaDirs = dirNumbers[gd.getNextChoiceIndex()];
/* 170 */     this.connectivity = connectivityValues[gd.getNextChoiceIndex()];
/*     */ 
/*     */     
/* 173 */     ResultsTable table = process(imagePlus);
/*     */ 
/*     */     
/* 176 */     String tableName = String.valueOf(imagePlus.getShortTitle()) + "-morpho";
/*     */ 
/*     */     
/* 179 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus imagePlus) {
/* 192 */     if (imagePlus == null) {
/* 193 */       return null;
/*     */     }
/*     */     
/* 196 */     ImageStack image = imagePlus.getStack();
/* 197 */     Calibration calib = imagePlus.getCalibration();
/*     */     
/* 199 */     return process(image, calib);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImageStack image, Calibration calib) {
/* 214 */     double[] resol = { 1.0D, 1.0D, 1.0D };
/* 215 */     if (calib != null && calib.scaled()) {
/*     */       
/* 217 */       resol[0] = calib.pixelWidth;
/* 218 */       resol[1] = calib.pixelHeight;
/* 219 */       resol[2] = calib.pixelDepth;
/*     */     } 
/*     */ 
/*     */     
/* 223 */     IntrinsicVolumesAnalyzer3D.Result[] intrinsicVolumes = null;
/* 224 */     Box3D[] boxes = null;
/* 225 */     Point3D[] centroids = null;
/* 226 */     Ellipsoid[] ellipsoids = null;
/* 227 */     double[][] elongations = null;
/* 228 */     Sphere[] inscribedBalls = null;
/*     */ 
/*     */ 
/*     */     
/* 232 */     int[] labels = LabelImages.findAllLabels(image);
/*     */ 
/*     */     
/* 235 */     if (this.computeVolume || this.computeSurface || this.computeEulerNumber || this.computeMeanBreadth || this.computeSphericity) {
/*     */       
/* 237 */       IJ.showStatus("Intrinsic Volumes");
/*     */       
/* 239 */       long tic = System.nanoTime();
/*     */       
/* 241 */       IntrinsicVolumesAnalyzer3D algo = new IntrinsicVolumesAnalyzer3D();
/* 242 */       algo.setDirectionNumber(this.surfaceAreaDirs);
/* 243 */       algo.setConnectivity(this.connectivity);
/* 244 */       DefaultAlgoListener.monitor((Algo)algo);
/*     */ 
/*     */       
/* 247 */       intrinsicVolumes = algo.analyzeRegions(image, labels, calib);
/* 248 */       long toc = System.nanoTime();
/* 249 */       IJ.log(String.format("Intrinsic volumes: %7.2f ms", new Object[] { Double.valueOf((toc - tic) / 1000000.0D) }));
/*     */     } 
/*     */ 
/*     */     
/* 253 */     if (this.computeBoundingBox) {
/*     */       
/* 255 */       IJ.showStatus("Bounding Boxes");
/* 256 */       long tic = System.nanoTime();
/* 257 */       BoundingBox3D algo = new BoundingBox3D();
/* 258 */       DefaultAlgoListener.monitor((Algo)algo);
/* 259 */       boxes = algo.analyzeRegions(image, labels, calib);
/* 260 */       long toc = System.nanoTime();
/* 261 */       IJ.log(String.format("Bounding boxes: %7.2f ms", new Object[] { Double.valueOf((toc - tic) / 1000000.0D) }));
/*     */     } 
/*     */ 
/*     */     
/* 265 */     if (this.computeEllipsoid) {
/*     */       
/* 267 */       IJ.showStatus("Equivalent Ellipsoids");
/* 268 */       long tic = System.nanoTime();
/* 269 */       EquivalentEllipsoid algo = new EquivalentEllipsoid();
/* 270 */       DefaultAlgoListener.monitor((Algo)algo);
/* 271 */       ellipsoids = algo.analyzeRegions(image, labels, calib);
/* 272 */       long toc = System.nanoTime();
/* 273 */       IJ.log(String.format("Equivalent ellipsoids: %7.2f ms", new Object[] { Double.valueOf((toc - tic) / 1000000.0D) }));
/*     */       
/* 275 */       if (this.computeCentroid)
/*     */       {
/*     */         
/* 278 */         centroids = Ellipsoid.centers(ellipsoids);
/*     */       }
/*     */     }
/* 281 */     else if (this.computeCentroid) {
/*     */ 
/*     */       
/* 284 */       IJ.showStatus("Centroid");
/* 285 */       Centroid3D algo = new Centroid3D();
/* 286 */       DefaultAlgoListener.monitor((Algo)algo);
/* 287 */       centroids = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 290 */     if (this.computeElongations) {
/*     */       
/* 292 */       IJ.showStatus("Ellipsoid elongations");
/* 293 */       elongations = Ellipsoid.elongations(ellipsoids);
/*     */     } 
/*     */ 
/*     */     
/* 297 */     if (this.computeInscribedBall) {
/*     */       
/* 299 */       IJ.showStatus("Inscribed Balls");
/* 300 */       long tic = System.nanoTime();
/* 301 */       LargestInscribedBall algo = new LargestInscribedBall();
/* 302 */       DefaultAlgoListener.monitor((Algo)algo);
/* 303 */       inscribedBalls = algo.analyzeRegions(image, labels, calib);
/* 304 */       long toc = System.nanoTime();
/* 305 */       IJ.log(String.format("inscribed balls: %7.2f ms", new Object[] { Double.valueOf((toc - tic) / 1000000.0D) }));
/*     */     } 
/*     */ 
/*     */     
/* 309 */     IJ.showStatus("Create Table");
/* 310 */     ResultsTable table = new ResultsTable();
/* 311 */     for (int i = 0; i < labels.length; i++) {
/*     */       
/* 313 */       IJ.showProgress(i, labels.length);
/*     */       
/* 315 */       table.incrementCounter();
/* 316 */       table.addLabel(Integer.toString(labels[i]));
/*     */ 
/*     */       
/* 319 */       if (this.computeVolume)
/* 320 */         table.addValue("Volume", (intrinsicVolumes[i]).volume); 
/* 321 */       if (this.computeSurface)
/* 322 */         table.addValue("SurfaceArea", (intrinsicVolumes[i]).surfaceArea); 
/* 323 */       if (this.computeMeanBreadth)
/* 324 */         table.addValue("MeanBreadth", (intrinsicVolumes[i]).meanBreadth); 
/* 325 */       if (this.computeSphericity) {
/*     */         
/* 327 */         double vol = (intrinsicVolumes[i]).volume;
/* 328 */         double surf = (intrinsicVolumes[i]).surfaceArea;
/* 329 */         table.addValue("Sphericity", IntrinsicVolumes3D.sphericity(vol, surf));
/*     */       } 
/* 331 */       if (this.computeEulerNumber) {
/* 332 */         table.addValue("EulerNumber", (intrinsicVolumes[i]).eulerNumber);
/*     */       }
/* 334 */       if (this.computeBoundingBox) {
/*     */         
/* 336 */         Box3D box = boxes[i];
/* 337 */         table.addValue("Box.X.Min", box.getXMin());
/* 338 */         table.addValue("Box.X.Max", box.getXMax());
/* 339 */         table.addValue("Box.Y.Min", box.getYMin());
/* 340 */         table.addValue("Box.Y.Max", box.getYMax());
/* 341 */         table.addValue("Box.Z.Min", box.getZMin());
/* 342 */         table.addValue("Box.Z.Max", box.getZMax());
/*     */       } 
/*     */       
/* 345 */       if (this.computeCentroid) {
/*     */         
/* 347 */         Point3D center = centroids[i];
/* 348 */         table.addValue("Centroid.X", center.getX());
/* 349 */         table.addValue("Centroid.Y", center.getY());
/* 350 */         table.addValue("Centroid.Z", center.getZ());
/*     */       } 
/*     */ 
/*     */       
/* 354 */       if (this.computeEllipsoid) {
/*     */ 
/*     */         
/* 357 */         Ellipsoid elli = ellipsoids[i];
/* 358 */         Point3D center = elli.center();
/* 359 */         table.addValue("Elli.Center.X", center.getX());
/* 360 */         table.addValue("Elli.Center.Y", center.getY());
/* 361 */         table.addValue("Elli.Center.Z", center.getZ());
/*     */         
/* 363 */         table.addValue("Elli.R1", elli.radius1());
/* 364 */         table.addValue("Elli.R2", elli.radius2());
/* 365 */         table.addValue("Elli.R3", elli.radius3());
/*     */         
/* 367 */         table.addValue("Elli.Azim", elli.phi());
/* 368 */         table.addValue("Elli.Elev", elli.theta());
/* 369 */         table.addValue("Elli.Roll", elli.psi());
/*     */       } 
/* 371 */       if (this.computeElongations) {
/*     */         
/* 373 */         table.addValue("Elli.R1/R2", elongations[i][0]);
/* 374 */         table.addValue("Elli.R1/R3", elongations[i][1]);
/* 375 */         table.addValue("Elli.R2/R3", elongations[i][2]);
/*     */       } 
/*     */       
/* 378 */       if (this.computeInscribedBall) {
/*     */         
/* 380 */         Sphere ball = inscribedBalls[i];
/* 381 */         Point3D center = ball.center();
/*     */         
/* 383 */         table.addValue("InscrBall.Center.X", center.getX());
/* 384 */         table.addValue("InscrBall.Center.Y", center.getY());
/* 385 */         table.addValue("InscrBall.Center.Z", center.getZ());
/* 386 */         table.addValue("InscrBall.Radius", ball.radius());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 391 */     IJ.showProgress(1, 1);
/* 392 */     IJ.showStatus("");
/*     */     
/* 394 */     return table;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/AnalyzeRegions3D.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */