/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.measure.Calibration;
/*     */ import ij.measure.ResultsTable;
/*     */ import ij.plugin.filter.PlugInFilter;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.algo.Algo;
/*     */ import inra.ijpb.algo.DefaultAlgoListener;
/*     */ import inra.ijpb.geometry.Box2D;
/*     */ import inra.ijpb.geometry.Circle2D;
/*     */ import inra.ijpb.geometry.Ellipse;
/*     */ import inra.ijpb.geometry.OrientedBox2D;
/*     */ import inra.ijpb.geometry.PointPair2D;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.measure.region2d.AverageThickness;
/*     */ import inra.ijpb.measure.region2d.BoundingBox;
/*     */ import inra.ijpb.measure.region2d.Centroid;
/*     */ import inra.ijpb.measure.region2d.Convexity;
/*     */ import inra.ijpb.measure.region2d.EquivalentEllipse;
/*     */ import inra.ijpb.measure.region2d.GeodesicDiameter;
/*     */ import inra.ijpb.measure.region2d.IntrinsicVolumes2DUtils;
/*     */ import inra.ijpb.measure.region2d.IntrinsicVolumesAnalyzer2D;
/*     */ import inra.ijpb.measure.region2d.LargestInscribedCircle;
/*     */ import inra.ijpb.measure.region2d.MaxFeretDiameter;
/*     */ import inra.ijpb.measure.region2d.OrientedBoundingBox2D;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzeRegions
/*     */   implements PlugInFilter
/*     */ {
/*     */   boolean computeArea = true;
/*     */   boolean computePerimeter = true;
/*     */   boolean computeCircularity = true;
/*     */   boolean computeEulerNumber = true;
/*     */   boolean computeBoundingBox = true;
/*     */   boolean computeCentroid = true;
/*     */   boolean computeEquivalentEllipse = true;
/*     */   boolean computeEllipseElongation = true;
/*     */   boolean computeConvexity = true;
/*     */   boolean computeMaxFeretDiameter = true;
/*     */   boolean computeOrientedBox = true;
/*     */   boolean computeOrientedBoxElongation = true;
/*     */   boolean computeGeodesicDiameter = true;
/*     */   boolean computeTortuosity = true;
/*     */   boolean computeMaxInscribedDisc = true;
/*     */   boolean computeAverageThickness = true;
/*     */   boolean computeGeodesicElongation = true;
/*     */   public boolean debug = false;
/*     */   ImagePlus imagePlus;
/*     */   
/*     */   public int setup(String arg, ImagePlus imp) {
/* 100 */     if (imp == null) {
/*     */       
/* 102 */       IJ.noImage();
/* 103 */       return 4096;
/*     */     } 
/*     */     
/* 106 */     this.imagePlus = imp;
/* 107 */     return 159;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(ImageProcessor ip) {
/* 117 */     if (!LabelImages.isLabelImageType(this.imagePlus)) {
/*     */       
/* 119 */       IJ.showMessage("Input image should be a label image");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 124 */     GenericDialog gd = new GenericDialog("Analyze Regions");
/* 125 */     gd.addCheckbox("Area", true);
/* 126 */     gd.addCheckbox("Perimeter", true);
/* 127 */     gd.addCheckbox("Circularity", true);
/* 128 */     gd.addCheckbox("Euler_Number", true);
/* 129 */     gd.addCheckbox("Bounding_Box", true);
/* 130 */     gd.addCheckbox("Centroid", true);
/* 131 */     gd.addCheckbox("Equivalent_Ellipse", true);
/* 132 */     gd.addCheckbox("Ellipse_Elong.", true);
/* 133 */     gd.addCheckbox("Convexity", true);
/* 134 */     gd.addCheckbox("Max._Feret Diameter", true);
/* 135 */     gd.addCheckbox("Oriented_Box", true);
/* 136 */     gd.addCheckbox("Oriented_Box_Elong.", true);
/* 137 */     gd.addCheckbox("Geodesic Diameter", true);
/* 138 */     gd.addCheckbox("Tortuosity", true);
/* 139 */     gd.addCheckbox("Max._Inscribed_Disc", true);
/* 140 */     gd.addCheckbox("Average_Thickness", true);
/* 141 */     gd.addCheckbox("Geodesic_Elong.", true);
/* 142 */     gd.showDialog();
/*     */ 
/*     */     
/* 145 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     this.computeArea = gd.getNextBoolean();
/* 150 */     this.computePerimeter = gd.getNextBoolean();
/* 151 */     this.computeCircularity = gd.getNextBoolean();
/* 152 */     this.computeEulerNumber = gd.getNextBoolean();
/* 153 */     this.computeBoundingBox = gd.getNextBoolean();
/* 154 */     this.computeCentroid = gd.getNextBoolean();
/* 155 */     this.computeEquivalentEllipse = gd.getNextBoolean();
/* 156 */     this.computeEllipseElongation = gd.getNextBoolean();
/* 157 */     this.computeConvexity = gd.getNextBoolean();
/* 158 */     this.computeMaxFeretDiameter = gd.getNextBoolean();
/* 159 */     this.computeOrientedBox = gd.getNextBoolean();
/* 160 */     this.computeOrientedBoxElongation = gd.getNextBoolean();
/* 161 */     this.computeGeodesicDiameter = gd.getNextBoolean();
/* 162 */     this.computeTortuosity = gd.getNextBoolean();
/* 163 */     this.computeMaxInscribedDisc = gd.getNextBoolean();
/* 164 */     this.computeAverageThickness = gd.getNextBoolean();
/* 165 */     this.computeGeodesicElongation = gd.getNextBoolean();
/*     */ 
/*     */ 
/*     */     
/* 169 */     ResultsTable table = process(this.imagePlus);
/*     */ 
/*     */     
/* 172 */     String tableName = String.valueOf(this.imagePlus.getShortTitle()) + "-Morphometry";
/* 173 */     table.show(tableName);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultsTable process(ImagePlus imagePlus) {
/* 178 */     ImageProcessor image = imagePlus.getProcessor();
/*     */     
/* 180 */     Calibration calib = imagePlus.getCalibration();
/*     */     
/* 182 */     int[] labels = LabelImages.findAllLabels(image);
/* 183 */     int nLabels = labels.length;
/*     */ 
/*     */     
/* 186 */     ResultsTable table = new ResultsTable();
/* 187 */     for (int i = 0; i < nLabels; i++) {
/*     */       
/* 189 */       table.incrementCounter();
/* 190 */       table.addLabel(labels[i]);
/*     */     } 
/*     */ 
/*     */     
/* 194 */     IntrinsicVolumesAnalyzer2D.Result[] intrinsicVolumes = null;
/* 195 */     Box2D[] boundingBoxes = null;
/* 196 */     Point2D[] centroids = null;
/* 197 */     Ellipse[] ellipses = null;
/* 198 */     Convexity.Result[] convexities = null;
/* 199 */     PointPair2D[] maxFeretDiams = null;
/* 200 */     OrientedBox2D[] orientedBoxes = null;
/* 201 */     GeodesicDiameter.Result[] geodDiams = null;
/* 202 */     Circle2D[] inscrDiscs = null;
/* 203 */     AverageThickness.Result[] avgThickness = null;
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (this.computeArea || this.computePerimeter || this.computeEulerNumber || this.computeCircularity) {
/*     */       
/* 209 */       IJ.showStatus("Intrinsic Volumes");
/*     */ 
/*     */       
/* 212 */       IntrinsicVolumesAnalyzer2D algo = new IntrinsicVolumesAnalyzer2D();
/* 213 */       algo.setDirectionNumber(4);
/* 214 */       algo.setConnectivity(4);
/* 215 */       DefaultAlgoListener.monitor((Algo)algo);
/*     */ 
/*     */       
/* 218 */       intrinsicVolumes = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 221 */     if (this.computeBoundingBox) {
/*     */       
/* 223 */       IJ.showStatus("Compute bounding boxes");
/* 224 */       BoundingBox algo = new BoundingBox();
/* 225 */       DefaultAlgoListener.monitor((Algo)algo);
/* 226 */       boundingBoxes = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 229 */     if (this.computeEquivalentEllipse || this.computeEllipseElongation) {
/*     */       
/* 231 */       IJ.showStatus("Equivalent Ellipse");
/* 232 */       EquivalentEllipse algo = new EquivalentEllipse();
/* 233 */       DefaultAlgoListener.monitor((Algo)algo);
/* 234 */       ellipses = algo.analyzeRegions(image, labels, calib);
/*     */       
/* 236 */       if (this.computeCentroid)
/*     */       {
/* 238 */         centroids = Ellipse.centers(ellipses);
/*     */       }
/*     */     }
/* 241 */     else if (this.computeCentroid) {
/*     */ 
/*     */       
/* 244 */       IJ.showStatus("Centroids");
/* 245 */       Centroid algo = new Centroid();
/* 246 */       DefaultAlgoListener.monitor((Algo)algo);
/* 247 */       centroids = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 250 */     if (this.computeConvexity) {
/*     */       
/* 252 */       IJ.showStatus("Compute convexity");
/* 253 */       Convexity algo = new Convexity();
/* 254 */       DefaultAlgoListener.monitor((Algo)algo);
/* 255 */       convexities = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 258 */     if (this.computeMaxFeretDiameter || this.computeTortuosity) {
/*     */       
/* 260 */       IJ.showStatus("Max Feret Diameters");
/* 261 */       maxFeretDiams = MaxFeretDiameter.maxFeretDiameters(image, labels, calib);
/*     */     } 
/*     */     
/* 264 */     if (this.computeOrientedBox) {
/*     */       
/* 266 */       IJ.showStatus("Oriented Bounding Boxes");
/* 267 */       OrientedBoundingBox2D algo = new OrientedBoundingBox2D();
/* 268 */       DefaultAlgoListener.monitor((Algo)algo);
/* 269 */       orientedBoxes = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 272 */     if (this.computeGeodesicDiameter || this.computeTortuosity) {
/*     */       
/* 274 */       IJ.showStatus("Compute Geodesic diameters");
/* 275 */       GeodesicDiameter algo = new GeodesicDiameter();
/* 276 */       DefaultAlgoListener.monitor((Algo)algo);
/* 277 */       geodDiams = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 280 */     if (this.computeMaxInscribedDisc || this.computeGeodesicElongation) {
/*     */       
/* 282 */       IJ.showStatus("Compute Inscribed circles");
/* 283 */       LargestInscribedCircle algo = new LargestInscribedCircle();
/* 284 */       DefaultAlgoListener.monitor((Algo)algo);
/* 285 */       inscrDiscs = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */     
/* 288 */     if (this.computeAverageThickness) {
/*     */       
/* 290 */       IJ.showStatus("Compute Average Thickness");
/* 291 */       AverageThickness algo = new AverageThickness();
/* 292 */       DefaultAlgoListener.monitor((Algo)algo);
/* 293 */       avgThickness = algo.analyzeRegions(image, labels, calib);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 298 */     IJ.showStatus("Populate table");
/*     */     
/* 300 */     if (this.computeArea)
/*     */     {
/* 302 */       for (int j = 0; j < nLabels; j++)
/*     */       {
/* 304 */         table.setValue("Area", j, (intrinsicVolumes[j]).area);
/*     */       }
/*     */     }
/*     */     
/* 308 */     if (this.computePerimeter)
/*     */     {
/* 310 */       for (int j = 0; j < nLabels; j++)
/*     */       {
/* 312 */         table.setValue("Perimeter", j, (intrinsicVolumes[j]).perimeter);
/*     */       }
/*     */     }
/*     */     
/* 316 */     if (this.computeCircularity) {
/*     */       
/* 318 */       double[] circularities = IntrinsicVolumes2DUtils.computeCircularities(intrinsicVolumes);
/* 319 */       addColumnToTable(table, "Circularity", circularities);
/*     */     } 
/*     */     
/* 322 */     if (this.computeEulerNumber)
/*     */     {
/* 324 */       for (int j = 0; j < nLabels; j++)
/*     */       {
/* 326 */         table.setValue("EulerNumber", j, (intrinsicVolumes[j]).eulerNumber);
/*     */       }
/*     */     }
/*     */     
/* 330 */     if (this.computeBoundingBox)
/*     */     {
/* 332 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 334 */         Box2D box = boundingBoxes[j];
/* 335 */         table.setValue("Box.X.Min", j, box.getXMin());
/* 336 */         table.setValue("Box.X.Max", j, box.getXMax());
/* 337 */         table.setValue("Box.Y.Min", j, box.getYMin());
/* 338 */         table.setValue("Box.Y.Max", j, box.getYMax());
/*     */       } 
/*     */     }
/*     */     
/* 342 */     if (this.computeCentroid)
/*     */     {
/* 344 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 346 */         Point2D center = centroids[j];
/* 347 */         table.setValue("Centroid.X", j, center.getX());
/* 348 */         table.setValue("Centroid.Y", j, center.getY());
/*     */       } 
/*     */     }
/*     */     
/* 352 */     if (this.computeEquivalentEllipse)
/*     */     {
/* 354 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 356 */         Ellipse elli = ellipses[j];
/* 357 */         Point2D center = elli.center();
/* 358 */         table.setValue("Ellipse.Center.X", j, center.getX());
/* 359 */         table.setValue("Ellipse.Center.Y", j, center.getY());
/* 360 */         table.setValue("Ellipse.Radius1", j, elli.radius1());
/* 361 */         table.setValue("Ellipse.Radius2", j, elli.radius2());
/* 362 */         table.setValue("Ellipse.Orientation", j, elli.orientation());
/*     */       } 
/*     */     }
/*     */     
/* 366 */     if (this.computeEllipseElongation) {
/*     */       
/* 368 */       double[] elong = new double[nLabels];
/* 369 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 371 */         Ellipse elli = ellipses[j];
/* 372 */         elong[j] = elli.radius1() / elli.radius2();
/*     */       } 
/* 374 */       addColumnToTable(table, "Ellipse.Elong", elong);
/*     */     } 
/*     */     
/* 377 */     if (this.computeConvexity)
/*     */     {
/* 379 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 381 */         table.setValue("ConvexArea", j, (convexities[j]).convexArea);
/* 382 */         table.setValue("Convexity", j, (convexities[j]).convexity);
/*     */       } 
/*     */     }
/*     */     
/* 386 */     if (this.computeMaxFeretDiameter)
/*     */     {
/* 388 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 390 */         table.setValue("MaxFeretDiam", j, maxFeretDiams[j].diameter());
/* 391 */         table.setValue("MaxFeretDiamAngle", j, Math.toDegrees(maxFeretDiams[j].angle()));
/*     */       } 
/*     */     }
/*     */     
/* 395 */     if (this.computeOrientedBox)
/*     */     {
/* 397 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 399 */         OrientedBox2D obox = orientedBoxes[j];
/* 400 */         Point2D center = obox.center();
/* 401 */         table.setValue("OBox.Center.X", j, center.getX());
/* 402 */         table.setValue("OBox.Center.Y", j, center.getY());
/* 403 */         table.setValue("OBox.Length", j, obox.length());
/* 404 */         table.setValue("OBox.Width", j, obox.width());
/* 405 */         table.setValue("OBox.Orientation", j, obox.orientation());
/*     */       } 
/*     */     }
/*     */     
/* 409 */     if (this.computeGeodesicDiameter)
/*     */     {
/* 411 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 413 */         GeodesicDiameter.Result result = geodDiams[j];
/* 414 */         table.setValue("GeodesicDiameter", j, result.diameter);
/*     */       } 
/*     */     }
/*     */     
/* 418 */     if (this.computeTortuosity) {
/*     */       
/* 420 */       double[] tortuosity = new double[nLabels];
/* 421 */       for (int j = 0; j < nLabels; j++)
/*     */       {
/* 423 */         tortuosity[j] = (geodDiams[j]).diameter / maxFeretDiams[j].diameter();
/*     */       }
/* 425 */       addColumnToTable(table, "Tortuosity", tortuosity);
/*     */     } 
/*     */     
/* 428 */     if (this.computeMaxInscribedDisc)
/*     */     {
/* 430 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 432 */         Point2D center = inscrDiscs[j].getCenter();
/* 433 */         table.setValue("InscrDisc.Center.X", j, center.getX());
/* 434 */         table.setValue("InscrDisc.Center.Y", j, center.getY());
/* 435 */         table.setValue("InscrDisc.Radius", j, inscrDiscs[j].getRadius());
/*     */       } 
/*     */     }
/*     */     
/* 439 */     if (this.computeAverageThickness)
/*     */     {
/* 441 */       for (int j = 0; j < nLabels; j++) {
/*     */         
/* 443 */         AverageThickness.Result res = avgThickness[j];
/* 444 */         table.setValue("AverageThickness", j, res.avgThickness);
/*     */       } 
/*     */     }
/*     */     
/* 448 */     if (this.computeGeodesicElongation) {
/*     */       
/* 450 */       double[] elong = new double[nLabels];
/* 451 */       for (int j = 0; j < nLabels; j++)
/*     */       {
/* 453 */         elong[j] = (geodDiams[j]).diameter / inscrDiscs[j].getRadius() * 2.0D;
/*     */       }
/* 455 */       addColumnToTable(table, "GeodesicElongation", elong);
/*     */     } 
/*     */     
/* 458 */     IJ.showStatus("");
/* 459 */     return table;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void addColumnToTable(ResultsTable table, String colName, double[] values) {
/* 464 */     for (int i = 0; i < values.length; i++)
/*     */     {
/* 466 */       table.setValue(colName, i, values[i]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/AnalyzeRegions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */