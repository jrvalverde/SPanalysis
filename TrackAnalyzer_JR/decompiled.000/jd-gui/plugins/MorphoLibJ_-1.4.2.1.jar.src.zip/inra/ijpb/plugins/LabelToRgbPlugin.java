/*     */ package inra.ijpb.plugins;
/*     */ 
/*     */ import ij.IJ;
/*     */ import ij.ImagePlus;
/*     */ import ij.ImageStack;
/*     */ import ij.gui.GenericDialog;
/*     */ import ij.plugin.PlugIn;
/*     */ import ij.process.ImageProcessor;
/*     */ import inra.ijpb.label.LabelImages;
/*     */ import inra.ijpb.util.ColorMaps;
/*     */ import inra.ijpb.util.CommonColors;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabelToRgbPlugin
/*     */   implements PlugIn
/*     */ {
/*     */   public void run(String arg) {
/*  51 */     ImagePlus imagePlus = IJ.getImage();
/*     */     
/*  53 */     int maxLabel = computeMaxLabel(imagePlus);
/*     */ 
/*     */     
/*  56 */     GenericDialog gd = new GenericDialog("Labels To RGB");
/*  57 */     gd.addChoice("Colormap", ColorMaps.CommonLabelMaps.getAllLabels(), 
/*  58 */         ColorMaps.CommonLabelMaps.GOLDEN_ANGLE.getLabel());
/*  59 */     gd.addChoice("Background", CommonColors.getAllLabels(), CommonColors.WHITE.getLabel());
/*  60 */     gd.addCheckbox("Shuffle", true);
/*  61 */     gd.showDialog();
/*     */ 
/*     */     
/*  64 */     if (gd.wasCanceled()) {
/*     */       return;
/*     */     }
/*     */     
/*  68 */     String lutName = gd.getNextChoice();
/*  69 */     String bgColorName = gd.getNextChoice();
/*  70 */     Color bgColor = CommonColors.fromLabel(bgColorName).getColor();
/*  71 */     boolean shuffleLut = gd.getNextBoolean();
/*     */ 
/*     */     
/*  74 */     byte[][] lut = ColorMaps.CommonLabelMaps.fromLabel(lutName).computeLut(maxLabel, shuffleLut);
/*     */ 
/*     */     
/*  77 */     ImagePlus resPlus = LabelImages.labelToRgb(imagePlus, lut, bgColor);
/*     */ 
/*     */     
/*  80 */     resPlus.copyScale(imagePlus);
/*  81 */     resPlus.show();
/*  82 */     if (imagePlus.getStackSize() > 1)
/*     */     {
/*  84 */       resPlus.setSlice(imagePlus.getCurrentSlice());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int computeMaxLabel(ImagePlus imagePlus) {
/*  94 */     if (imagePlus.getImageStackSize() == 1)
/*     */     {
/*  96 */       return computeMaxLabel(imagePlus.getProcessor());
/*     */     }
/*     */ 
/*     */     
/* 100 */     return computeMaxLabel(imagePlus.getStack());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int computeMaxLabel(ImageProcessor image) {
/* 106 */     int labelMax = 0;
/* 107 */     if (image instanceof ij.process.FloatProcessor) {
/*     */       
/* 109 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 111 */         labelMax = Math.max(labelMax, (int)image.getf(i));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 116 */       for (int i = 0; i < image.getPixelCount(); i++)
/*     */       {
/* 118 */         labelMax = Math.max(labelMax, image.get(i));
/*     */       }
/*     */     } 
/*     */     
/* 122 */     return labelMax;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int computeMaxLabel(ImageStack image) {
/* 127 */     int labelMax = 0;
/* 128 */     for (int i = 1; i <= image.getSize(); i++) {
/*     */       
/* 130 */       ImageProcessor slice = image.getProcessor(i);
/* 131 */       labelMax = Math.max(labelMax, computeMaxLabel(slice));
/*     */     } 
/*     */     
/* 134 */     return labelMax;
/*     */   }
/*     */ }


/* Location:              /mnt/jr/work/mmellado/TrackAnalyzer/TrackAnalyzer_CNB/jar_expanded/!/plugins/MorphoLibJ_-1.4.2.1.jar!/inra/ijpb/plugins/LabelToRgbPlugin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */